# CSCO MD&A — 0000858877-17-000010


## mdna

[0000858877-17-000010:mdna:1]
[same as prior period, unchanged from 0000858877-17-000004:mdna:1]

[0000858877-17-000010:mdna:2]
[same as prior period, unchanged from 0000858877-17-000004:mdna:2]

[0000858877-17-000010:mdna:3]
[same as prior period, unchanged from 0000858877-17-000004:mdna:3]

[0000858877-17-000010:mdna:4]
[same as prior period, unchanged from 0000858877-17-000004:mdna:4]

[0000858877-17-000010:mdna:5]
[same as prior period, unchanged from 0000858877-17-000004:mdna:5]

[0000858877-17-000010:mdna:6]
|  | Three Months Ended |  | Nine Months Ended |  |
|  | April 29, 2017 |  | April 30, 2016 |  | Variance |  | April 29, 2017 |  | April 30, 2016 |  | Variance |  |
| Revenue (1) | $ | 11,940 |  |  | $ | 12,000 |  |  | (0.5 | )% |  | $ | 35,872 |  |  | $ | 36,609 |  |  | (2.0 | )% |  |
| Gross margin percentage | 63.0 | % |  | 64.3 | % |  | (1.3 | ) | pts | 63.2 | % |  | 62.8 | % |  | 0.4 |  | pts |
| Research and development | $ | 1,507 |  |  | $ | 1,626 |  |  | (7.3 | )% |  | $ | 4,560 |  |  | $ | 4,695 |  |  | (2.9 | )% |  |
| Sales and marketing | $ | 2,226 |  |  | $ | 2,447 |  |  | (9.0 | )% |  | $ | 6,866 |  |  | $ | 7,176 |  |  | (4.3 | )% |  |
| General and administrative | $ | 487 |  |  | $ | 566 |  |  | (14.0 | )% |  | $ | 1,498 |  |  | $ | 1,281 |  |  | 16.9 | % |  |
| Total research and development, sales and marketing, general and administrative | $ | 4,220 |  |  | $ | 4,639 |  |  | (9.0 | )% |  | $ | 12,924 |  |  | $ | 13,152 |  |  | (1.7 | )% |  |
| Total as a percentage of revenue | 35.3 | % |  | 38.7 | % |  | (3.4 | ) | pts | 36.0 | % |  | 35.9 | % |  | 0.1 |  | pts |
| Amortization of purchased intangible assets included in operating expenses | $ | 59 |  |  | $ | 81 |  |  | (27.2 | )% |  | $ | 201 |  |  | $ | 221 |  |  | (9.0 | )% |  |
| Restructuring and other charges included in operating expenses | $ | 70 |  |  | $ | 17 |  |  | 311.8 | % |  | $ | 614 |  |  | $ | 255 |  |  | 140.8 | % |  |
| Operating income as a percentage of revenue | 26.5 | % |  | 24.9 | % |  | 1.6 |  | pts | 24.9 | % |  | 25.6 | % |  | (0.7 | ) | pts |
| Income tax percentage | 21.2 | % |  | 23.8 | % |  | (2.6 | ) | pts | 21.1 | % |  | 16.8 | % |  | 4.3 |  | pts |
| Net income | $ | 2,515 |  |  | $ | 2,349 |  |  | 7.1 | % |  | $ | 7,185 |  |  | $ | 7,926 |  |  | (9.3 | )% |  |
| Net income as a percentage of revenue | 21.1 | % |  | 19.6 | % |  | 1.5 |  | pts | 20.0 | % |  | 21.7 | % |  | (1.7 | ) | pts |
| Earnings per share—diluted | $ | 0.50 |  |  | $ | 0.46 |  |  | 8.7 | % |  | $ | 1.42 |  |  | $ | 1.56 |  |  | (9.0 | )% |  |

[0000858877-17-000010:mdna:7]
(1) During the second quarter of fiscal 2016, we completed the sale of the Customer Premises Equipment portion of our Service Provider Video Connected Devices business (“SP Video CPE Business”). As a result, revenue from this portion of the Service Provider Video product category will not recur in future periods. Includes SP Video CPE Business revenue of $504 million for the first nine months of fiscal 2016.

[0000858877-17-000010:mdna:8]
[same as prior period, unchanged from 0000858877-17-000004:mdna:8]

[0000858877-17-000010:mdna:9]
[same as prior period, unchanged from 0000858877-17-000004:mdna:9]

[0000858877-17-000010:mdna:10]
[same as prior period, unchanged from 0000858877-17-000004:mdna:10]

[0000858877-17-000010:mdna:11]
Three Months Ended April 29, 2017 Compared with Three Months Ended April 30, 2016

[0000858877-17-000010:mdna:12]
In the third quarter of fiscal 2017, we continued to deliver solid profitability and cash flows. We remain focused on accelerating innovation across our portfolio, and we believe that we have made progress over the past year in our strategic priority areas. We continue to operate in a challenging and highly competitive environment, which has impacted, in particular, our NGN Routing and Switching areas. We saw weakness in the service provider customer market and we expect ongoing uncertainty in that area. In addition, we continued to see weakness in emerging countries in the aggregate.  We experienced solid revenue growth in Wireless and Security, and we continued to make progress in the transition of our business model to increased software and subscriptions. To this end, during the third quarter of fiscal 2017, we completed our acquisition of AppDynamics, an application intelligence software company. While the overall environment remains uncertain, we continue to aggressively invest in priority areas to drive profitable growth over the long term.

[0000858877-17-000010:mdna:13]
In the third quarter of fiscal 2017, our revenue decreased by 1% as compared with the third quarter of fiscal 2016. Within total revenue, product revenue was flat while service revenue decreased 2%. The third quarter of fiscal 2017 had 13 weeks, compared with 14 weeks in the third quarter of fiscal 2016, thus our results for the third quarter and the first nine months of fiscal 2017 reflect one less week compared with the corresponding periods in fiscal 2016. We estimate that the additional revenue associated with the extra week was approximately $265 million, $200 million of which was from services, and $65 million from our software-as-a-service (SaaS) offerings such as WebEx, and a small amount from product distribution. Total gross margin decreased by 1.3 percentage points, driven by unfavorable impacts from pricing, lower supplier component remediation adjustment and unfavorable product mix. As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses, collectively, decreased by 3.4 percentage points due in part to the impact of extra week in the third quarter of fiscal 2016. Operating income as a percentage of revenue increased by 1.6 percentage points. Diluted earnings per share increased by 9%, driven by a 7% increase in net income.

[0000858877-17-000010:mdna:14]
In terms of our geographic segments, revenue from both Americas and EMEA was flat. Revenue in our APJC segment decreased slightly, led by a product revenue decrease in China. We experienced revenue declines from many emerging countries. The “BRICM” countries experienced a product revenue decline of 8% in the aggregate, driven by declines in the emerging countries of Brazil, China and Mexico of 28%, 17% and 9%, respectively, partially offset by increased product revenue in Russia and India of 19% and 11%, respectively.

[0000858877-17-000010:mdna:15]
From a customer market standpoint, we had product revenue growth in the enterprise, public sector and commercial markets which was offset by product revenue decline in the service provider market.

[0000858877-17-000010:mdna:16]
From a product category perspective, we had revenue increases in Wireless, Security, Switching and Other category of 13%, 9%, 2% and 57%, respectively, that were offset by revenue decreases in Data Center, Collaboration, NGN Routing and SP Video of 5%, 4%, 2% and 30%, respectively.

[0000858877-17-000010:mdna:17]
[same as prior period, unchanged from 0000858877-17-000004:mdna:17]

[0000858877-17-000010:mdna:18]
[same as prior period, unchanged from 0000858877-17-000004:mdna:18]

[0000858877-17-000010:mdna:19]
Nine Months Ended April 29, 2017 Compared with Nine Months Ended April 30, 2016

[0000858877-17-000010:mdna:20]
Diluted earnings per share decreased by 9% from the prior year, as a result of a 9% decrease in net income. Revenue decreased 2%, with product revenue decreasing 4% and service revenue increasing 3%. Total gross margin increased by 0.4 percentage points driven in part by the sale of the lower margin SP Video CPE Business. As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses collectively increased by 0.1 percentage points. Operating income as a percentage of revenue decreased by 0.7 percentage points. Net income for the first nine months of fiscal 2017 was impacted by a higher effective tax rate in the first nine months of fiscal 2017 compared to the first nine months of fiscal 2016 primarily due to the recognition of a net benefit to the provision for income taxes in the second quarter of fiscal 2016 related to our settlement with the IRS of outstanding items related to the audit of our federal income tax returns covering the period from fiscal 2008 through fiscal 2010 and the permanent reinstatement of the U.S. federal R&D tax credit.

[0000858877-17-000010:mdna:21]
[same as prior period, unchanged from 0000858877-17-000004:mdna:21]

[0000858877-17-000010:mdna:22]
[same as prior period, unchanged from 0000858877-17-000004:mdna:22]

[0000858877-17-000010:mdna:23]
[same as prior period, unchanged from 0000858877-17-000004:mdna:23]

[0000858877-17-000010:mdna:24]
[same as prior period, unchanged from 0000858877-17-000004:mdna:24]

[0000858877-17-000010:mdna:25]
[same as prior period, unchanged from 0000858877-17-000004:mdna:25]

[0000858877-17-000010:mdna:26]
The following is a summary of our other key financial measures for the third quarter and first nine months of fiscal 2017 (in millions, except annualized inventory turns):

[0000858877-17-000010:mdna:27]
|  |  | April 29, 2017 |  | July 30, 2016 |
| Cash and cash equivalents and investments |  | $ | 67,974 |  |  | $ | 65,756 |  |
| Deferred revenue |  | $ | 17,322 |  |  | $ | 16,472 |  |
| Inventories |  | $ | 1,366 |  |  | $ | 1,217 |  |
| Annualized inventory turns |  | 13.5 |  |  | 14.6 |  |

[0000858877-17-000010:mdna:28]
|  |  | Nine Months Ended |
|  |  | April 29, 2017 |  | April 30, 2016 |
| Cash provided by operating activities |  | $ | 9,875 |  |  | $ | 9,752 |  |
| Repurchases of common stock—stock repurchase program |  | $ | 2,505 |  |  | $ | 3,118 |  |
| Dividends |  | $ | 4,063 |  |  | $ | 3,441 |  |

[0000858877-17-000010:mdna:29]
[same as prior period, unchanged from 0000858877-17-000004:mdna:29]

[0000858877-17-000010:mdna:30]
[same as prior period, unchanged from 0000858877-17-000004:mdna:30]

[0000858877-17-000010:mdna:31]
[same as prior period, unchanged from 0000858877-17-000004:mdna:31]

[0000858877-17-000010:mdna:32]
[same as prior period, unchanged from 0000858877-17-000004:mdna:32]

[0000858877-17-000010:mdna:33]
[same as prior period, unchanged from 0000858877-17-000004:mdna:33]

[0000858877-17-000010:mdna:34]
[same as prior period, unchanged from 0000858877-17-000004:mdna:34]

[0000858877-17-000010:mdna:35]
[same as prior period, unchanged from 0000858877-17-000004:mdna:35]

[0000858877-17-000010:mdna:36]
[same as prior period, unchanged from 0000858877-17-000004:mdna:36]

[0000858877-17-000010:mdna:37]
[same as prior period, unchanged from 0000858877-17-000004:mdna:37]

[0000858877-17-000010:mdna:38]
[same as prior period, unchanged from 0000858877-17-000004:mdna:38]

[0000858877-17-000010:mdna:39]
[same as prior period, unchanged from 0000858877-17-000004:mdna:39]

[0000858877-17-000010:mdna:40]
[same as prior period, unchanged from 0000858877-17-000004:mdna:40]

[0000858877-17-000010:mdna:41]
[same as prior period, unchanged from 0000858877-17-000004:mdna:41]

[0000858877-17-000010:mdna:42]
As our business and offerings evolve over time, our pricing practices may be required to be modified accordingly, which could result in changes in selling prices, including both VSOE and ESP, in subsequent periods. There were no material impacts during the first nine months of fiscal 2017, nor do we currently expect a material impact in the next 12 months on our revenue recognition due to any changes in our VSOE, TPE, or ESP.

[0000858877-17-000010:mdna:43]
[same as prior period, unchanged from 0000858877-17-000004:mdna:43]

[0000858877-17-000010:mdna:44]
[same as prior period, unchanged from 0000858877-17-000004:mdna:44]

[0000858877-17-000010:mdna:45]
[same as prior period, unchanged from 0000858877-17-000004:mdna:45]

[0000858877-17-000010:mdna:46]
[same as prior period, unchanged from 0000858877-17-000004:mdna:46]

[0000858877-17-000010:mdna:47]
[same as prior period, unchanged from 0000858877-17-000004:mdna:47]

[0000858877-17-000010:mdna:48]
[same as prior period, unchanged from 0000858877-17-000004:mdna:48]

[0000858877-17-000010:mdna:49]
|  |  | April 29, 2017 |  | July 30, 2016 |
| Allowance for doubtful accounts |  | $ | 213 |  |  | $ | 249 |  |
| Percentage of gross accounts receivable |  | 4.4 | % |  | 4.1 | % |
| Allowance for credit loss—lease receivables |  | $ | 220 |  |  | $ | 230 |  |
| Percentage of gross lease receivables(1) |  | 7.4 | % |  | 6.6 | % |
| Allowance for credit loss—loan receivables |  | $ | 117 |  |  | $ | 97 |  |
| Percentage of gross loan receivables |  | 4.4 | % |  | 4.5 | % |

[0000858877-17-000010:mdna:50]
[same as prior period, unchanged from 0000858877-17-000004:mdna:50]

[0000858877-17-000010:mdna:51]
[same as prior period, unchanged from 0000858877-17-000004:mdna:51]

[0000858877-17-000010:mdna:52]
[same as prior period, unchanged from 0000858877-17-000004:mdna:52]

[0000858877-17-000010:mdna:53]
A reserve for future sales returns is established based on historical trends in product return rates. The reserve for future sales returns as of April 29, 2017 and July 30, 2016 was $121 million and $126 million, respectively, and was recorded as a reduction of our accounts receivable and revenue. If the actual future returns were to deviate from the historical data on which the reserve had been established, our revenue could be adversely affected.

[0000858877-17-000010:mdna:54]
[same as prior period, unchanged from 0000858877-17-000004:mdna:54]

[0000858877-17-000010:mdna:55]
[same as prior period, unchanged from 0000858877-17-000004:mdna:55]

[0000858877-17-000010:mdna:56]
We record a liability for firm, noncancelable, and unconditional purchase commitments with contract manufacturers and suppliers for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of April 29, 2017, the liability for these purchase commitments was $179 million, compared with $159 million as of July 30, 2016, and was included in other current liabilities.

[0000858877-17-000010:mdna:57]
[same as prior period, unchanged from 0000858877-17-000004:mdna:57]

[0000858877-17-000010:mdna:58]
[same as prior period, unchanged from 0000858877-17-000004:mdna:58]

[0000858877-17-000010:mdna:59]
Our provision for inventory was $52 million and $55 million for the first nine months of fiscal 2017 and 2016, respectively. The provision for the liability related to purchase commitments with contract manufacturers and suppliers was $111 million and $108 million for the first nine months of fiscal 2017 and 2016, respectively. If there were to be a sudden and significant decrease in demand for our products, or if there were a higher incidence of inventory obsolescence because of rapidly changing technology and customer requirements, we could be required to increase our inventory write-downs, and our liability for purchase commitments with contract manufacturers and suppliers, and accordingly our profitability, could be adversely affected. We regularly evaluate our exposure for inventory write-downs and the adequacy of our liability for purchase commitments. Inventory and supply chain management remain areas of focus as we balance the need to maintain supply chain flexibility to help ensure competitive lead times with the risk of inventory obsolescence, particularly in light of current macroeconomic uncertainties and conditions and the resulting potential for changes in future demand forecast.

[0000858877-17-000010:mdna:60]
Loss Contingencies and Product Warranties

[0000858877-17-000010:mdna:61]
We are subject to the possibility of various losses arising in the ordinary course of business. We consider the likelihood of impairment of an asset or the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated. We regularly evaluate information available to us to determine whether such accruals should be made or adjusted and whether new accruals are required.

[0000858877-17-000010:mdna:62]
Third parties, including customers, have in the past and may in the future assert claims or initiate litigation related to exclusive patent, copyright, trademark, and other intellectual property rights to technologies and related standards that are relevant to us. These assertions have increased over time as a result of our growth and the general increase in the pace of patent claims assertions, particularly in the United States. If any infringement or other intellectual property claim made against us by any third party is successful, or if we fail to develop non-infringing technology or license the proprietary rights on commercially reasonable terms and conditions, our business, operating results, and financial condition could be materially and adversely affected.

[0000858877-17-000010:mdna:63]
In the second quarter of fiscal 2014, we recorded a charge to product cost of sales of $655 million resulting from failures related to products containing memory components manufactured by a single supplier between 2005 and 2010. We perform regular assessments of the sufficiency of this liability and reduced the amount by a total of $238 million in fiscal 2016 and fiscal 2015 based on updated analyses.  During the second quarter of fiscal 2017, we further reduced the liability by $141 million to reflect lower than expected defects, actual usage history, and estimated lower future remediation costs as more of the impacted products age and near the end of the support period covered by the remediation program.

[0000858877-17-000010:mdna:64]
In addition, during the second quarter of fiscal 2017, we recorded a $125 million charge to product cost of sales related to the expected remediation costs for anticipated failures in future periods of a widely-used component sourced from a third party which is included in several of our products.

[0000858877-17-000010:mdna:65]
The liability related to these matters as of April 29, 2017 and July 30, 2016 was $206 million and $276 million, respectively.

[0000858877-17-000010:mdna:66]
[same as prior period, unchanged from 0000858877-17-000004:mdna:65]

[0000858877-17-000010:mdna:67]
[same as prior period, unchanged from 0000858877-17-000004:mdna:66]

[0000858877-17-000010:mdna:68]
[same as prior period, unchanged from 0000858877-17-000004:mdna:67]

[0000858877-17-000010:mdna:69]
50

[0000858877-17-000010:mdna:70]
[same as prior period, unchanged from 0000858877-17-000004:mdna:68]

[0000858877-17-000010:mdna:71]
[same as prior period, unchanged from 0000858877-17-000004:mdna:69]

[0000858877-17-000010:mdna:72]
[same as prior period, unchanged from 0000858877-17-000004:mdna:70]

[0000858877-17-000010:mdna:73]
Our fixed income and publicly traded equity securities, collectively, are reflected in the Consolidated Balance Sheets at a fair value of $59.9 billion as of April 29, 2017, compared with $58.1 billion as of July 30, 2016. Our fixed income investment portfolio as of April 29, 2017 consisted primarily of high quality investment-grade securities. See Note 8 to the Consolidated Financial Statements.

[0000858877-17-000010:mdna:74]
[same as prior period, unchanged from 0000858877-17-000004:mdna:72]

[0000858877-17-000010:mdna:75]
[same as prior period, unchanged from 0000858877-17-000004:mdna:73]

[0000858877-17-000010:mdna:76]
The inputs and fair value are reviewed for reasonableness, may be further validated by comparison to publicly available information, and could be adjusted based on market indices or other information that management deems material to its estimate of fair value. The assessment of fair value can be difficult and subjective. However, given the relative reliability of the inputs we use to value our investment portfolio, and because substantially all of our valuation inputs are obtained using quoted market prices for similar or identical assets, we do not believe that the nature of estimates and assumptions affected by levels of subjectivity and judgment was material to the valuation of the investment portfolio as of April 29, 2017. Level 3 assets do not represent a significant portion of our total assets measured at fair value on a recurring basis as of April 29, 2017 and July 30, 2016.

[0000858877-17-000010:mdna:77]
[same as prior period, unchanged from 0000858877-17-000004:mdna:75]

[0000858877-17-000010:mdna:78]
[same as prior period, unchanged from 0000858877-17-000004:mdna:76]

[0000858877-17-000010:mdna:79]
[same as prior period, unchanged from 0000858877-17-000004:mdna:77]

[0000858877-17-000010:mdna:80]
[same as prior period, unchanged from 0000858877-17-000004:mdna:78]

[0000858877-17-000010:mdna:81]
We also have investments in privately held companies, some of which are in the startup or development stages. As of April 29, 2017, our investments in privately held companies were $950 million, compared with $1,003 million as of July 30, 2016, and were included in other assets. We monitor these investments for events or circumstances indicative of potential impairment, and we make appropriate reductions in carrying values if we determine that an impairment charge is required, based primarily on the financial condition and near-term prospects of these companies. These investments are inherently risky because the markets for the technologies or products these companies are developing are typically in the early stages and may never materialize.

[0000858877-17-000010:mdna:82]
[same as prior period, unchanged from 0000858877-17-000004:mdna:81]

[0000858877-17-000010:mdna:83]
[same as prior period, unchanged from 0000858877-17-000004:mdna:82]

[0000858877-17-000010:mdna:84]
[same as prior period, unchanged from 0000858877-17-000004:mdna:83]

[0000858877-17-000010:mdna:85]
[same as prior period, unchanged from 0000858877-17-000004:mdna:84]

[0000858877-17-000010:mdna:86]
The goodwill recorded in the Consolidated Balance Sheets as of April 29, 2017 and July 30, 2016 was $29.5 billion and $26.6 billion, respectively. The increase in goodwill for the first nine months of fiscal 2017 was due in large part to our acquisition of AppDynamics. In response to changes in industry and market conditions, we could be required to strategically realign our resources and consider restructuring, disposing of, or otherwise exiting businesses, which could result in an impairment of goodwill. There was no impairment of goodwill in each of the first nine months of fiscal 2017 and 2016.

[0000858877-17-000010:mdna:87]
[same as prior period, unchanged from 0000858877-17-000004:mdna:86]

[0000858877-17-000010:mdna:88]
We make judgments about the recoverability of purchased intangible assets with finite lives whenever events or changes in circumstances indicate that an impairment may exist. Recoverability of purchased intangible assets with finite lives is measured by comparing the carrying amount of the asset to the future undiscounted cash flows the asset is expected to generate. We review indefinite-lived intangible assets for impairment annually or whenever events or changes in circumstances indicate that the asset might be impaired. If the asset is considered to be impaired, the amount of any impairment is measured as the difference between the carrying value and the fair value of the impaired asset. Assumptions and estimates about future values and remaining useful lives of our purchased intangible assets are complex and subjective. They can be affected by a variety of factors, including external factors such as industry and economic trends, and internal factors such as changes in our business strategy and our internal forecasts.  Our impairment charges related to purchased intangible assets were $42 million and $44 million for the first nine months of fiscal 2017 and 2016, respectively. Our ongoing consideration of all the factors described previously could result in additional impairment charges in the future, which could adversely affect our net income.

[0000858877-17-000010:mdna:89]
[same as prior period, unchanged from 0000858877-17-000004:mdna:88]

[0000858877-17-000010:mdna:90]
We are subject to income taxes in the United States and numerous foreign jurisdictions. Our effective tax rates differ from the statutory rate, primarily due to the tax impact of state taxes, foreign operations, R&D tax credits, domestic manufacturing deductions, tax audit settlements, nondeductible compensation, international realignments, and transfer pricing adjustments. Our effective tax rate was 21.2% and 23.8% in the third quarter of fiscal 2017 and 2016, respectively. Our effective tax rate was 21.1% and 16.8% in the first nine months of fiscal 2017 and 2016, respectively.

[0000858877-17-000010:mdna:91]
[same as prior period, unchanged from 0000858877-17-000004:mdna:90]

[0000858877-17-000010:mdna:92]
[same as prior period, unchanged from 0000858877-17-000004:mdna:91]

[0000858877-17-000010:mdna:93]
[same as prior period, unchanged from 0000858877-17-000004:mdna:92]

[0000858877-17-000010:mdna:94]
[same as prior period, unchanged from 0000858877-17-000004:mdna:93]

[0000858877-17-000010:mdna:95]
[same as prior period, unchanged from 0000858877-17-000004:mdna:94]

[0000858877-17-000010:mdna:96]
[same as prior period, unchanged from 0000858877-17-000004:mdna:95]

[0000858877-17-000010:mdna:97]
[same as prior period, unchanged from 0000858877-17-000004:mdna:96]

[0000858877-17-000010:mdna:98]
[same as prior period, unchanged from 0000858877-17-000004:mdna:97]

[0000858877-17-000010:mdna:99]
[same as prior period, unchanged from 0000858877-17-000004:mdna:98]

[0000858877-17-000010:mdna:100]
[same as prior period, unchanged from 0000858877-17-000004:mdna:99]

[0000858877-17-000010:mdna:101]
[same as prior period, unchanged from 0000858877-17-000004:mdna:100]

[0000858877-17-000010:mdna:102]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 29, 2017 |  | April 30, 2016 |  | Variancein Dollars |  | Variance in Percent |  | April 29, 2017 |  | April 30, 2016 |  | Variancein Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 8,885 |  |  | $ | 8,875 |  |  | $ | 10 |  |  | 0.1 | % |  | $ | 26,678 |  |  | $ | 27,702 |  |  | $ | (1,024 | ) |  | (3.7 | )% |
| Percentage of revenue |  | 74.4 | % |  | 74.0 | % |  |  |  |  |  |  |  | 74.4 | % |  | 75.7 | % |  |  |  |  |  |  |
| Service |  | 3,055 |  |  | 3,125 |  |  | (70 | ) |  | (2.2 | )% |  | 9,194 |  |  | 8,907 |  |  | 287 |  |  | 3.2 | % |
| Percentage of revenue |  | 25.6 | % |  | 26.0 | % |  |  |  |  |  |  |  | 25.6 | % |  | 24.3 | % |  |  |  |  |  |  |
| Total |  | $ | 11,940 |  |  | $ | 12,000 |  |  | $ | (60 | ) |  | (0.5 | )% |  | $ | 35,872 |  |  | $ | 36,609 |  |  | $ | (737 | ) |  | (2.0 | )% |

[0000858877-17-000010:mdna:103]
[same as prior period, unchanged from 0000858877-17-000004:mdna:102]

[0000858877-17-000010:mdna:104]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 29, 2017 |  | April 30, 2016 |  | Variancein Dollars |  | Variance in Percent |  | April 29, 2017 |  | April 30, 2016 |  | Variancein Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 7,046 |  |  | $ | 7,056 |  |  | $ | (10 | ) |  | (0.1 | )% |  | $ | 21,149 |  |  | $ | 21,759 |  |  | $ | (610 | ) |  | (2.8 | )% |
| Percentage of revenue |  | 59.0 | % |  | 58.8 | % |  |  |  |  |  | 59.0 | % |  | 59.4 | % |  |  |  |  |
| EMEA |  | 2,999 |  |  | 3,006 |  |  | (7 | ) |  | (0.2 | )% |  | 9,077 |  |  | 9,193 |  |  | (116 | ) |  | (1.3 | )% |
| Percentage of revenue |  | 25.1 | % |  | 25.1 | % |  |  |  |  |  | 25.3 | % |  | 25.1 | % |  |  |  |  |
| APJC |  | 1,895 |  |  | 1,938 |  |  | (43 | ) |  | (2.2 | )% |  | 5,646 |  |  | 5,657 |  |  | (11 | ) |  | (0.2 | )% |
| Percentage of revenue |  | 15.9 | % |  | 16.1 | % |  |  |  |  |  | 15.7 | % |  | 15.5 | % |  |  |  |  |
| Total |  | $ | 11,940 |  |  | $ | 12,000 |  |  | $ | (60 | ) |  | (0.5 | )% |  | $ | 35,872 |  |  | $ | 36,609 |  |  | $ | (737 | ) |  | (2.0 | )% |

[0000858877-17-000010:mdna:105]
Three Months Ended April 29, 2017 Compared with Three Months Ended April 30, 2016

[0000858877-17-000010:mdna:106]
For the third quarter of fiscal 2017, as compared with the third quarter of fiscal 2016, total revenue decreased by 1%.  Product revenue was flat, while service revenue decreased by 2%. The third quarter of fiscal 2017 had 13 weeks, compared with 14 weeks in the third quarter of fiscal 2016, thus our results for the third quarter of fiscal 2017 reflect one less week compared with the third quarter of fiscal 2016. We estimate that the additional revenue associated with the extra week was approximately $265 million, of which $200 million was from our services subscriptions, and $65 million from our SaaS offerings such as WebEx, and a small amount from product distribution. Our total revenue from both the Americas and EMEA segments was flat and revenue from our APJC segment decreased slightly.  The emerging countries of BRICM, in the aggregate, experienced an 8% product revenue decline, with declines in Brazil, China, and Mexico partially offset by increases in the other two BRICM countries.

[0000858877-17-000010:mdna:107]
We conduct business globally in numerous currencies. The direct effect of foreign currency fluctuations on revenue has not been material because our revenue is primarily denominated in U.S. dollars. However, if the U.S. dollar strengthens relative to other currencies, such strengthening could have an indirect effect on our revenue to the extent it raises the cost of our products to non-U.S. customers and thereby reduces demand. A weaker U.S. dollar could have the opposite effect. However, the precise indirect effect of currency fluctuations is difficult to measure or predict because our revenue is influenced by many factors in addition to the impact of such currency fluctuations.

[0000858877-17-000010:mdna:108]
[same as prior period, unchanged from 0000858877-17-000004:mdna:107]

[0000858877-17-000010:mdna:109]
54

[0000858877-17-000010:mdna:110]
[same as prior period, unchanged from 0000858877-17-000004:mdna:108]

[0000858877-17-000010:mdna:111]
[same as prior period, unchanged from 0000858877-17-000004:mdna:109]

[0000858877-17-000010:mdna:112]
Nine Months Ended April 29, 2017 Compared with Nine Months Ended April 30, 2016

[0000858877-17-000010:mdna:113]
For the first nine months of fiscal 2017, as compared with the first nine months of fiscal 2016, total revenue decreased by 2%.  Total company revenue not including SP Video CPE products decreased 1%. Product revenue decreased by 4% while service revenue increased by 3%. Our total revenue decreased in the Americas and EMEA segments and was flat in the APJC segment. The emerging countries of BRICM, in the aggregate, experienced an 11% product revenue decline, with revenue declines in Mexico, China, and Brazil partially offset by increases in the other two BRICM countries.

[0000858877-17-000010:mdna:114]
[same as prior period, unchanged from 0000858877-17-000004:mdna:112]

[0000858877-17-000010:mdna:115]
[same as prior period, unchanged from 0000858877-17-000004:mdna:113]

[0000858877-17-000010:mdna:116]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 29, 2017 |  | April 30, 2016 |  | Variancein Dollars |  | Variance in Percent |  | April 29, 2017 |  | April 30, 2016 |  | Variancein Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 5,094 |  |  | $ | 5,051 |  |  | $ | 43 |  |  | 0.9 | % |  | $ | 15,269 |  |  | $ | 15,988 |  |  | $ | (719 | ) |  | (4.5 | )% |
| Percentage of product revenue |  | 57.3 | % |  | 56.9 | % |  |  |  |  |  | 57.2 | % |  | 57.7 | % |  |  |  |  |
| EMEA |  | 2,345 |  |  | 2,321 |  |  | 24 |  |  | 1.0 | % |  | 7,101 |  |  | 7,264 |  |  | (163 | ) |  | (2.2 | )% |
| Percentage of product revenue |  | 26.4 | % |  | 26.2 | % |  |  |  |  |  | 26.6 | % |  | 26.2 | % |  |  |  |  |
| APJC |  | 1,446 |  |  | 1,503 |  |  | (57 | ) |  | (3.8 | )% |  | 4,308 |  |  | 4,450 |  |  | (142 | ) |  | (3.2 | )% |
| Percentage of product revenue |  | 16.3 | % |  | 16.9 | % |  |  |  |  |  | 16.2 | % |  | 16.1 | % |  |  |  |  |
| Total |  | $ | 8,885 |  |  | $ | 8,875 |  |  | $ | 10 |  |  | 0.1 | % |  | $ | 26,678 |  |  | $ | 27,702 |  |  | $ | (1,024 | ) |  | (3.7 | )% |

[0000858877-17-000010:mdna:117]
During the second quarter of fiscal 2016, we completed the sale of our SP Video CPE Business.  As a result, revenue from this portion of the Service Provider Video product category will not recur in future periods.  SP Video CPE Business revenue was $504 million for the first nine months of fiscal 2016.

[0000858877-17-000010:mdna:118]
[same as prior period, unchanged from 0000858877-17-000004:mdna:116]

[0000858877-17-000010:mdna:119]
Three Months Ended April 29, 2017 Compared with Three Months Ended April 30, 2016

[0000858877-17-000010:mdna:120]
The 1% increase in product revenue for the Americas segment was led by solid growth in the enterprise market and, to a lesser extent, growth in the public sector market. These product revenue increases were partially offset by declines in the service provider and commercial markets. The product revenue increase in the public sector market was due primarily to an increase in sales to state and local governments, partially offset by a decrease in sales to the U.S. federal government. From a country perspective, product revenue increased by 1% in the United States and 9% in Canada, partially offset by product revenue decreases of 28% in Brazil and 9% in Mexico.

[0000858877-17-000010:mdna:121]
Nine Months Ended April 29, 2017 Compared with Nine Months Ended April 30, 2016

[0000858877-17-000010:mdna:122]
The decrease in product revenue in the Americas segment was led by a decline in the service provider market and, to a lesser extent, declines in the public sector and commercial markets. These product revenue declines were partially offset by growth in the enterprise market.  The product revenue decrease in the service provider market was driven primarily by the absence of product sales related to our SP Video CPE Business in the first nine months of fiscal 2017. We had $378 million in product sales related to our SP Video CPE Business in the first nine months of fiscal 2016 in this segment. From a country perspective, product revenue decreased by 4% in the United States, 28% in Mexico, 13% in Brazil and 3% in Canada.

[0000858877-17-000010:mdna:123]
[same as prior period, unchanged from 0000858877-17-000004:mdna:121]

[0000858877-17-000010:mdna:124]
[same as prior period, unchanged from 0000858877-17-000004:mdna:122]

[0000858877-17-000010:mdna:125]
[same as prior period, unchanged from 0000858877-17-000004:mdna:123]

[0000858877-17-000010:mdna:126]
Three Months Ended April 29, 2017 Compared with Three Months Ended April 30, 2016

[0000858877-17-000010:mdna:127]
Product revenue in the EMEA segment increased by 1%, driven by growth in the public sector and commercial markets partially offset by declines in the service provider and enterprise markets.  Product revenue from emerging countries within EMEA increased by 5% and product revenue for the remainder of the EMEA segment, which primarily consists of countries in Western Europe, was flat.

[0000858877-17-000010:mdna:128]
Nine Months Ended April 29, 2017 Compared with Nine Months Ended April 30, 2016

[0000858877-17-000010:mdna:129]
The decrease in product revenue in the EMEA segment of 2% was driven by a decline in the service provider market and, to a lesser extent, a decline in the public sector market. We experienced product revenue growth in the enterprise and commercial markets. The product revenue decrease in the service provider market was driven primarily by the absence of product sales related to our SP Video CPE Business in the first nine months of fiscal 2017. We had $108 million in product sales related to our SP Video CPE Business in the first nine months of fiscal 2016 in this segment. Product revenue from emerging countries within EMEA decreased by 3% and product revenue for the remainder of the EMEA segment decreased by 2%.

[0000858877-17-000010:mdna:130]
[same as prior period, unchanged from 0000858877-17-000004:mdna:128]

[0000858877-17-000010:mdna:131]
Three Months Ended April 29, 2017 Compared with Three Months Ended April 30, 2016

[0000858877-17-000010:mdna:132]
Product revenue in the APJC segment decreased by 4%, led by declines in the service provider and enterprise markets. These product revenue declines were partially offset by solid growth in the commercial market. From a country perspective, product revenue decreased by 17% in China and 14% in Japan, partially offset by product revenue increases of 24% in Australia and 11% in India.

[0000858877-17-000010:mdna:133]
Nine Months Ended April 29, 2017 Compared with Nine Months Ended April 30, 2016

[0000858877-17-000010:mdna:134]
Product revenue in the APJC segment decreased by 3%. The product revenue decline was led by declines in the service provider and public sector markets and, to a lesser extent, a decline in the enterprise market. These decreases were partially offset by product revenue growth in the commercial market. From a country perspective, product revenue decreased by 17% in China while increasing 10% in India, 5% in Australia and 2% in Japan. Product sales for this geographic segment were adversely impacted by an $18 million decrease in product sales related to our SP Video CPE Business.

[0000858877-17-000010:mdna:135]
56

[0000858877-17-000010:mdna:136]
[same as prior period, unchanged from 0000858877-17-000004:mdna:133]

[0000858877-17-000010:mdna:137]
[same as prior period, unchanged from 0000858877-17-000004:mdna:134]

[0000858877-17-000010:mdna:138]
[same as prior period, unchanged from 0000858877-17-000004:mdna:135]

[0000858877-17-000010:mdna:139]
[same as prior period, unchanged from 0000858877-17-000004:mdna:136]

[0000858877-17-000010:mdna:140]
[same as prior period, unchanged from 0000858877-17-000004:mdna:137]

[0000858877-17-000010:mdna:141]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 29, 2017 |  | April 30, 2016 |  | Variancein Dollars |  | Variance in Percent |  | April 29, 2017 |  | April 30, 2016 |  | Variancein Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Switching |  | $ | 3,489 |  |  | $ | 3,435 |  |  | $ | 54 |  |  | 1.6 | % |  | $ | 10,510 |  |  | $ | 10,919 |  |  | $ | (409 | ) |  | (3.7 | )% |
| Percentage of product revenue |  | 39.3 | % |  | 38.7 | % |  |  |  |  |  |  |  | 39.4 | % |  | 39.4 | % |  |  |  |  |  |  |
| NGN Routing |  | 2,032 |  |  | 2,074 |  |  | (42 | ) |  | (2.0 | )% |  | 5,938 |  |  | 6,057 |  |  | (119 | ) |  | (2.0 | )% |
| Percentage of product revenue |  | 22.9 | % |  | 23.4 | % |  |  |  |  |  |  |  | 22.2 | % |  | 21.9 | % |  |  |  |  |  |  |
| Collaboration |  | 1,022 |  |  | 1,069 |  |  | (47 | ) |  | (4.4 | )% |  | 3,165 |  |  | 3,203 |  |  | (38 | ) |  | (1.2 | )% |
| Percentage of product revenue |  | 11.5 | % |  | 12.1 | % |  |  |  |  |  |  |  | 11.9 | % |  | 11.5 | % |  |  |  |  |  |  |
| Data Center |  | 767 |  |  | 811 |  |  | (44 | ) |  | (5.4 | )% |  | 2,391 |  |  | 2,492 |  |  | (101 | ) |  | (4.1 | )% |
| Percentage of product revenue |  | 8.6 | % |  | 9.1 | % |  |  |  |  |  |  |  | 9.0 | % |  | 9.0 | % |  |  |  |  |  |  |
| Wireless |  | 703 |  |  | 620 |  |  | 83 |  |  | 13.4 | % |  | 1,967 |  |  | 1,882 |  |  | 85 |  |  | 4.5 | % |
| Percentage of product revenue |  | 7.9 | % |  | 7.0 | % |  |  |  |  |  | 7.4 | % |  | 6.8 | % |  |  |  |  |
| Security |  | 527 |  |  | 482 |  |  | 45 |  |  | 9.3 | % |  | 1,595 |  |  | 1,429 |  |  | 166 |  |  | 11.6 | % |
| Percentage of product revenue |  | 5.9 | % |  | 5.4 | % |  |  |  |  |  |  |  | 6.0 | % |  | 5.2 | % |  |  |  |  |  |  |
| Service Provider Video (1) |  | 207 |  |  | 296 |  |  | (89 | ) |  | (30.1 | )% |  | 719 |  |  | 1,482 |  |  | (763 | ) |  | (51.5 | )% |
| Percentage of product revenue |  | 2.3 | % |  | 3.3 | % |  |  |  |  |  | 2.7 | % |  | 5.3 | % |  |  |  |  |
| Other |  | 138 |  |  | 88 |  |  | 50 |  |  | 56.8 | % |  | 393 |  |  | 238 |  |  | 155 |  |  | 65.1 | % |
| Percentage of product revenue |  | 1.6 | % |  | 1.0 | % |  |  |  |  |  |  |  | 1.4 | % |  | 0.9 | % |  |  |  |  |  |  |
| Total |  | $ | 8,885 |  |  | $ | 8,875 |  |  | $ | 10 |  |  | 0.1 | % |  | $ | 26,678 |  |  | $ | 27,702 |  |  | $ | (1,024 | ) |  | (3.7 | )% |

[0000858877-17-000010:mdna:142]
(1) Includes SP Video CPE Business revenue of $504 million for the first nine months of fiscal 2016.

[0000858877-17-000010:mdna:143]
[same as prior period, unchanged from 0000858877-17-000004:mdna:140]

[0000858877-17-000010:mdna:144]
[same as prior period, unchanged from 0000858877-17-000004:mdna:141]

[0000858877-17-000010:mdna:145]
Three Months Ended April 29, 2017 Compared with Three Months Ended April 30, 2016

[0000858877-17-000010:mdna:146]
The increase in revenue in our Switching product category of 2%, or $54 million, was driven by an increase in sales of our Switching products used in data center environments which reflected strength in our Application Centric Infrastructure portfolio. We also experienced a slight increase in sales of Switching products used in campus environments.  While we experienced an increase in our Switching revenue, our business momentum with respect to campus switching continues to be impacted by uncertainty in the macro environment which led to a slowdown in customer spending, as well as by a highly competitive landscape.

[0000858877-17-000010:mdna:147]
[same as prior period, unchanged from 0000858877-17-000004:mdna:144]

[0000858877-17-000010:mdna:148]
[same as prior period, unchanged from 0000858877-17-000004:mdna:145]

[0000858877-17-000010:mdna:149]
In terms of subcategories, the increase was driven by an increase in revenue from LAN fixed-configuration switches of 8%, or $189 million, driven primarily by higher sales of our Cisco Nexus 9300 Series Switches, Cisco Catalyst 3850 Series Switches and Cisco Catalyst 3650 Series Switches, partially offset by a decrease in sales of certain other products in this portfolio.  We experienced a 10%, or $96 million, decrease in revenue from our modular switches and a 35%, or $39 million, decrease in sales of storage products. Revenue from our modular switches decreased due primarily to lower sales of most of the Cisco Catalyst Series Switches and Cisco Nexus 7000 Series Switches.

[0000858877-17-000010:mdna:150]
Nine Months Ended April 29, 2017 Compared with Nine Months Ended April 30, 2016

[0000858877-17-000010:mdna:151]
Revenue in our Switching product category decreased by 4%, or $409 million, driven by a 16%, or $522 million, decrease in revenue from our modular switches and a 25%, or $80 million, decrease in sales of storage products. This decline was partially offset by a 3%, or $193 million increase in revenue from our LAN fixed-configuration switches.  Revenue from our modular switches decreased driven by lower sales of most of the Cisco Catalyst Series Switches and Cisco Nexus 7000 Series Switches, partially offset by growth in Cisco Nexus 9500 Series Switches within this product category. Revenue from LAN fixed-configuration switches increased due to higher sales of our Cisco Nexus 9300 Series Switches, Cisco Catalyst 3650 Series Switches and Cisco Catalyst 3850 Series Switches, partially offset by a decrease in sales of certain other products in this portfolio.

[0000858877-17-000010:mdna:152]
[same as prior period, unchanged from 0000858877-17-000004:mdna:149]

[0000858877-17-000010:mdna:153]
Three Months Ended April 29, 2017 Compared with Three Months Ended April 30, 2016

[0000858877-17-000010:mdna:154]
Revenue in our NGN Routing product category decreased by 2%, or $42 million, driven by a 5%, or $54 million, decrease in revenue from our high-end router products and a 2%, or $12 million, decrease in revenue from our midrange and low-end router products. These decreases were partially offset by an 8%, or $24 million, increase in revenue from what we categorize as other NGN Routing products. The decrease in revenue from our high-end router products was driven by a decrease in revenue from our mobility products within our Cisco Aggregation Services Router (ASR) products and our Cisco Carrier Routing System (CRS) products.  The decrease in revenue from our midrange and low-end router products was driven by lower sales of our Cisco Integrated Services Router (ISR) products. Revenue from other NGN Routing products increased due to higher sales of cable access products and certain optical networking products.

[0000858877-17-000010:mdna:155]
Nine Months Ended April 29, 2017 Compared with Nine Months Ended April 30, 2016

[0000858877-17-000010:mdna:156]
The decrease in revenue in our NGN Routing product category of 2%, or $119 million, was driven by a 5%, or $162 million, decrease in revenue from our high-end router products and, a 4%, or $74 million, decrease in revenue from our midrange and low-end router products. This decline was partially offset by a 13%, or $117 million, increase in revenue from other NGN Routing products. Revenue from high-end router products decreased due to a decrease in revenue from most of our ASR products and from our CRS products. The decrease in revenue from our midrange and low-end router products was due to lower sales of our Cisco ISR products and certain of our access router products.  Revenue from other NGN Routing products increased due to higher sales of cable access products and certain optical networking products.

[0000858877-17-000010:mdna:157]
[same as prior period, unchanged from 0000858877-17-000004:mdna:154]

[0000858877-17-000010:mdna:158]
Three Months Ended April 29, 2017 Compared with Three Months Ended April 30, 2016

[0000858877-17-000010:mdna:159]
Revenue from our Collaboration product category decreased by 4%, or $47 million, driven by decreases in sales from Cisco Unified Communications and TelePresence products, partially offset by continued growth in Conferencing revenue.  The decrease in Unified Communications revenue was driven by decreased revenue from phones. Revenue from Cisco TelePresence products declined due to lower revenue from endpoint products. The growth in Conferencing revenue resulted from higher usage and recurring revenue from WebEx, which we include as product revenue in this category. We continue to increase the amount of deferred revenue and the proportion of recurring revenue related to our Collaboration product category.

[0000858877-17-000010:mdna:160]
Nine Months Ended April 29, 2017 Compared with Nine Months Ended April 30, 2016

[0000858877-17-000010:mdna:161]
Revenue in our Collaboration product category decreased 1%, or $38 million, driven by decreases in sales from Cisco Unified Communications and TelePresence products, partially offset by continued growth in Conferencing revenue.  The decrease in Unified Communications revenue was driven by decreased revenue from phones, partially offset by higher software revenue. Revenue from Cisco TelePresence products declined due to lower revenue from endpoint products. The growth in Conferencing revenue resulted from higher usage and recurring revenue from WebEx.

[0000858877-17-000010:mdna:162]
58

[0000858877-17-000010:mdna:163]
[same as prior period, unchanged from 0000858877-17-000004:mdna:159]

[0000858877-17-000010:mdna:164]
[same as prior period, unchanged from 0000858877-17-000004:mdna:160]

[0000858877-17-000010:mdna:165]
[same as prior period, unchanged from 0000858877-17-000004:mdna:161]

[0000858877-17-000010:mdna:166]
Three Months Ended April 29, 2017 Compared with Three Months Ended April 30, 2016

[0000858877-17-000010:mdna:167]
The decrease in revenue in our Data Center product category of 5%, or $44 million, was primarily driven by a decrease in sales of our Cisco Unified Computing System products, with a decline in the enterprise market partially offset by growth in the service provider, public sector and commercial markets. We believe the uncertainty in the macro environment led to a slowdown of customer spending.  Additionally, we are seeing a market transition with computing workloads shifting from blade server systems to rack-based systems.

[0000858877-17-000010:mdna:168]
Nine Months Ended April 29, 2017 Compared with Nine Months Ended April 30, 2016

[0000858877-17-000010:mdna:169]
Revenue in our Data Center product category decreased by 4%, or $101 million, driven by a decrease in sales of our  Cisco Unified Computing System products, with declines in the enterprise, commercial and public sector markets partially offset by growth in the service provider market.

[0000858877-17-000010:mdna:170]
[same as prior period, unchanged from 0000858877-17-000004:mdna:166]

[0000858877-17-000010:mdna:171]
Three Months Ended April 29, 2017 Compared with Three Months Ended April 30, 2016

[0000858877-17-000010:mdna:172]
Revenue in our Wireless product category increased by 13%, or $83 million, due primarily to continued growth in sales of Meraki products within this product category, and an increase in sales of our access point products, partially offset by a decrease in sales of our controller products. We continue to increase the amount of deferred revenue and the proportion of recurring revenue related to our Wireless product category.

[0000858877-17-000010:mdna:173]
Nine Months Ended April 29, 2017 Compared with Nine Months Ended April 30, 2016

[0000858877-17-000010:mdna:174]
Revenue in our Wireless product category increased by 5%, or $85 million, due primarily to an increase in sales from Meraki products and, to a lesser extent, an increase in sales of certain of our access point products. These increases were partially offset by a decrease in sales of our controller products.

[0000858877-17-000010:mdna:175]
[same as prior period, unchanged from 0000858877-17-000004:mdna:171]

[0000858877-17-000010:mdna:176]
Three Months Ended April 29, 2017 Compared with Three Months Ended April 30, 2016

[0000858877-17-000010:mdna:177]
Revenue in our Security product category increased 9%, or $45 million, driven by higher sales of unified threat management, advanced threat security and web security products. We continue to increase the amount of deferred revenue and the proportion of recurring revenue related to our Security product category.

[0000858877-17-000010:mdna:178]
Nine Months Ended April 29, 2017 Compared with Nine Months Ended April 30, 2016

[0000858877-17-000010:mdna:179]
Revenue in our Security product category increased 12%, or $166 million, driven by higher sales of advanced threat security, unified threat management and web security products.

[0000858877-17-000010:mdna:180]
[same as prior period, unchanged from 0000858877-17-000004:mdna:176]

[0000858877-17-000010:mdna:181]
Three Months Ended April 29, 2017 Compared with Three Months Ended April 30, 2016

[0000858877-17-000010:mdna:182]
The decrease in revenue from our Service Provider Video product category of 30%, or $89 million, was driven by a decrease in revenue from Service Provider Video software and solutions driven by a decline in China.

[0000858877-17-000010:mdna:183]
Nine Months Ended April 29, 2017 Compared with Nine Months Ended April 30, 2016

[0000858877-17-000010:mdna:184]
Revenue from our Service Provider Video product category decreased by 51%, or $763 million, due to a $504 million decrease in sales related to the SP Video CPE Business and a decrease in revenue from Service Provider Video software and solutions.

[0000858877-17-000010:mdna:185]
[same as prior period, unchanged from 0000858877-17-000004:mdna:181]

[0000858877-17-000010:mdna:186]
The increase in revenue in our Other Products category for the third quarter and first nine months of fiscal 2017 as compared to the corresponding periods of fiscal 2016 was in large part due to increased revenue from our Internet of Things (“IoT”) products, driven by our fiscal 2016 Jasper acquisition. The acquisition of AppDynamics in the third quarter of fiscal 2017 also contributed to the increase in revenue in this product category.

[0000858877-17-000010:mdna:187]
59

[0000858877-17-000010:mdna:188]
[same as prior period, unchanged from 0000858877-17-000004:mdna:183]

[0000858877-17-000010:mdna:189]
[same as prior period, unchanged from 0000858877-17-000004:mdna:184]

[0000858877-17-000010:mdna:190]
[same as prior period, unchanged from 0000858877-17-000004:mdna:185]

[0000858877-17-000010:mdna:191]
[same as prior period, unchanged from 0000858877-17-000004:mdna:186]

[0000858877-17-000010:mdna:192]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 29, 2017 |  | April 30, 2016 |  | Variancein Dollars |  | Variance in Percent |  | April 29, 2017 |  | April 30, 2016 |  | Variancein Dollars |  | Variance in Percent |
| Service revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 1,952 |  |  | $ | 2,005 |  |  | $ | (53 | ) |  | (2.6 | )% |  | $ | 5,880 |  |  | $ | 5,771 |  |  | $ | 109 |  |  | 1.9 | % |
| Percentage of service revenue |  | 63.9 | % |  | 64.2 | % |  |  |  |  |  | 64.0 | % |  | 64.8 | % |  |  |  |  |
| EMEA |  | 654 |  |  | 685 |  |  | (31 | ) |  | (4.5 | )% |  | 1,976 |  |  | 1,929 |  |  | 47 |  |  | 2.4 | % |
| Percentage of service revenue |  | 21.4 | % |  | 21.9 | % |  |  |  |  |  | 21.5 | % |  | 21.7 | % |  |  |  |  |
| APJC |  | 449 |  |  | 435 |  |  | 14 |  |  | 3.2 | % |  | 1,338 |  |  | 1,207 |  |  | 131 |  |  | 10.9 | % |
| Percentage of service revenue |  | 14.7 | % |  | 13.9 | % |  |  |  |  |  | 14.5 | % |  | 13.5 | % |  |  |  |  |
| Total |  | $ | 3,055 |  |  | $ | 3,125 |  |  | $ | (70 | ) |  | (2.2 | )% |  | $ | 9,194 |  |  | $ | 8,907 |  |  | $ | 287 |  |  | 3.2 | % |

[0000858877-17-000010:mdna:193]
Three Months Ended April 29, 2017 Compared with Three Months Ended April 30, 2016

[0000858877-17-000010:mdna:194]
Service revenue decreased 2%. Excluding the $200 million of additional revenue in the third quarter of fiscal 2016 as a result of the extra week in the third quarter of fiscal 2016, service revenue grew 4%. Service revenue decreased in the Americas and EMEA segments and increased in the APJC segment. Worldwide technical support services revenue and worldwide advanced services revenue each decreased by 2%. Technical support services revenue experienced declines in the Americas and EMEA segments and growth in the APJC segment.  Advanced services revenue, which relates to professional services for specific customer network needs, also decreased in the Americas and EMEA segments and increased in the APJC segment.

[0000858877-17-000010:mdna:195]
Nine Months Ended April 29, 2017 Compared with Nine Months Ended April 30, 2016

[0000858877-17-000010:mdna:196]
Service revenue increased across all geographic segments. Worldwide technical support services revenue increased by 4% and worldwide advanced services increased by 1%. Technical support services revenue had solid growth across all geographic segments. Renewals and technical support service contract initiations associated with product sales provided an installed base of equipment being serviced which, in concert with new service offerings, were the primary factors driving the revenue increases.  Advanced services revenue grew in the APJC and EMEA segments and declined in the Americas segment.

[0000858877-17-000010:mdna:197]
[same as prior period, unchanged from 0000858877-17-000004:mdna:192]

[0000858877-17-000010:mdna:198]
[same as prior period, unchanged from 0000858877-17-000004:mdna:193]

[0000858877-17-000010:mdna:199]
[same as prior period, unchanged from 0000858877-17-000004:mdna:194]

[0000858877-17-000010:mdna:200]
[same as prior period, unchanged from 0000858877-17-000004:mdna:195]

[0000858877-17-000010:mdna:201]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | AMOUNT |  | PERCENTAGE |  | AMOUNT |  | PERCENTAGE |
|  |  | April 29, 2017 |  | April 30, 2016 |  | April 29, 2017 |  | April 30, 2016 |  | April 29, 2017 |  | April 30, 2016 |  | April 29, 2017 |  | April 30, 2016 |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 5,480 |  |  | $ | 5,661 |  |  | 61.7 | % |  | 63.8 | % |  | $ | 16,565 |  |  | $ | 17,155 |  |  | 62.1 | % |  | 61.9 | % |
| Service |  | 2,038 |  |  | 2,060 |  |  | 66.7 | % |  | 65.9 | % |  | 6,113 |  |  | 5,830 |  |  | 66.5 | % |  | 65.5 | % |
| Total |  | $ | 7,518 |  |  | $ | 7,721 |  |  | 63.0 | % |  | 64.3 | % |  | $ | 22,678 |  |  | $ | 22,985 |  |  | 63.2 | % |  | 62.8 | % |

[0000858877-17-000010:mdna:202]
[same as prior period, unchanged from 0000858877-17-000004:mdna:197]

[0000858877-17-000010:mdna:203]
The following table summarizes the key factors that contributed to the change in product gross margin percentage for the third quarter and first nine months of fiscal 2017 as compared with the corresponding prior year periods:

[0000858877-17-000010:mdna:204]
|  |  | Product Gross Margin Percentage |
|  |  | Three Months Ended |  | Nine Months Ended |
| Fiscal 2016 |  | 63.8 | % |  | 61.9 | % |
| Productivity (1) |  | 1.4 | % |  | 2.2 | % |
| Product pricing |  | (2.3 | )% |  | (1.8 | )% |
| Supplier component remediation charge/adjustment, net |  | (0.7 | )% |  | (0.2 | )% |
| Mix of products sold |  | (0.4 | )% |  | (1.0 | )% |
| Amortization of purchased intangible assets |  | (0.1 | )% |  | — | % |
| SP Video CPE Business impact |  | — | % |  | 0.9 | % |
| Other |  | — | % |  | 0.1 | % |
| Fiscal 2017 |  | 61.7 | % |  | 62.1 | % |

[0000858877-17-000010:mdna:205]
[same as prior period, unchanged from 0000858877-17-000004:mdna:200]

[0000858877-17-000010:mdna:206]
Three Months Ended April 29, 2017 Compared with Three Months Ended April 30, 2016

[0000858877-17-000010:mdna:207]
Product gross margin decreased by 2.1 percentage points as compared with the third quarter of fiscal 2016. The decrease in product gross margin was largely due to unfavorable impacts from product pricing, which were driven by typical market factors and impacted each of our geographic segments and customer markets. The decrease was also due to the impact of a lower supplier component remediation adjustment and an unfavorable mix of products sold primarily from our NGN Routing and Service Provider Video products.

[0000858877-17-000010:mdna:208]
The various factors contributing to the product gross margin decrease were partially offset by productivity improvements which were driven by value engineering efforts, lower warranty expenses, favorable component pricing, and continued operational efficiency in manufacturing operations. Productivity improvements were adversely impacted by an increase in the cost of certain memory components which are currently constrained.  Value engineering is the process by which production costs are reduced through component redesign, board configuration, test processes, and transformation processes.

[0000858877-17-000010:mdna:209]
[same as prior period, unchanged from 0000858877-17-000004:mdna:204]

[0000858877-17-000010:mdna:210]
[same as prior period, unchanged from 0000858877-17-000004:mdna:205]

[0000858877-17-000010:mdna:211]
Nine Months Ended April 29, 2017 Compared with Nine Months Ended April 30, 2016

[0000858877-17-000010:mdna:212]
Product gross margin increased by 0.2 percentage points as compared with the first nine months of fiscal 2016. The increase was due to productivity improvements driven by similar factors as discussed in the three-month period immediately above.  Additionally, gross margin increased due to the sale during the second quarter of fiscal 2016 of our lower margin SP Video CPE Business. These factors were partially offset by the unfavorable impacts from product pricing and the mix of products sold. The unfavorable product mix was driven by negative mix impacts from our NGN Routing, Service Provider Video and Cisco Unified Computing System products. Product gross margin was also negatively impacted by the lower supplier component remediation adjustment.

[0000858877-17-000010:mdna:213]
[same as prior period, unchanged from 0000858877-17-000004:mdna:208]

[0000858877-17-000010:mdna:214]
Three Months Ended April 29, 2017 Compared with Three Months Ended April 30, 2016

[0000858877-17-000010:mdna:215]
Our service gross margin percentage increased by 0.8 percentage points as compared with the third quarter of fiscal 2016, due to decreased delivery costs, decreased headcount-related costs and, to a lesser extent, lower share-based compensation expense. These benefits to service gross margin were partially offset by lower sales volume.

[0000858877-17-000010:mdna:216]
[same as prior period, unchanged from 0000858877-17-000004:mdna:211]

[0000858877-17-000010:mdna:217]
Nine Months Ended April 29, 2017 Compared with Nine Months Ended April 30, 2016

[0000858877-17-000010:mdna:218]
Service gross margin percentage increased by 1.0 percentage points, as compared with the first nine months of fiscal 2016, due to higher sales volume, decreased delivery costs, favorable mix and, to a lesser extent, lower share-based compensation expense. These benefits to service gross margin were partially offset by increased headcount-related costs.

[0000858877-17-000010:mdna:219]
[same as prior period, unchanged from 0000858877-17-000004:mdna:214]

[0000858877-17-000010:mdna:220]
[same as prior period, unchanged from 0000858877-17-000004:mdna:215]

[0000858877-17-000010:mdna:221]
|  | Three Months Ended |  | Nine Months Ended |
|  | AMOUNT |  | PERCENTAGE |  | AMOUNT |  | PERCENTAGE |
|  | April 29, 2017 |  | April 30, 2016 |  | April 29, 2017 |  | April 30, 2016 |  | April 29, 2017 |  | April 30, 2016 |  | April 29, 2017 |  | April 30, 2016 |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 4,551 |  |  | $ | 4,677 |  |  | 64.6 | % |  | 66.3 | % |  | $ | 13,672 |  |  | $ | 14,031 |  |  | 64.6 | % |  | 64.5 | % |
| EMEA | 1,963 |  |  | 1,970 |  |  | 65.5 | % |  | 65.5 | % |  | 5,988 |  |  | 5,970 |  |  | 66.0 | % |  | 64.9 | % |
| APJC | 1,171 |  |  | 1,173 |  |  | 61.8 | % |  | 60.5 | % |  | 3,496 |  |  | 3,435 |  |  | 61.9 | % |  | 60.7 | % |
| Segment total | 7,685 |  |  | 7,820 |  |  | 64.4 | % |  | 65.2 | % |  | 23,156 |  |  | 23,436 |  |  | 64.6 | % |  | 64.0 | % |
| Unallocated corporate items (1) | (167 | ) |  | (99 | ) |  |  |  |  |  | (478 | ) |  | (451 | ) |  |  |  |  |
| Total | $ | 7,518 |  |  | $ | 7,721 |  |  | 63.0 | % |  | 64.3 | % |  | $ | 22,678 |  |  | $ | 22,985 |  |  | 63.2 | % |  | 62.8 | % |

[0000858877-17-000010:mdna:222]
(1) The unallocated corporate items include the effects of amortization and impairments of acquisition-related intangible assets, share-based compensation expense, significant litigation and other contingencies, charges related to asset impairments and restructurings, and certain other charges. We do not allocate these items to the gross margin for each segment because management does not include such information in measuring the performance of the operating segments.

[0000858877-17-000010:mdna:223]
Three Months Ended April 29, 2017 Compared with Three Months Ended April 30, 2016

[0000858877-17-000010:mdna:224]
The Americas segment experienced a gross margin percentage decrease due to negative impacts from pricing, an unfavorable product mix and, to a lesser extent, lower productivity. The unfavorable mix of products sold was driven by negative mix impacts from our Data Center, Other and NGN Routing product categories.

[0000858877-17-000010:mdna:225]
The gross margin percentage in our EMEA segment was flat as productivity improvements offset the negative impact from pricing.

[0000858877-17-000010:mdna:226]
[same as prior period, unchanged from 0000858877-17-000004:mdna:218]

[0000858877-17-000010:mdna:227]
[same as prior period, unchanged from 0000858877-17-000004:mdna:219]

[0000858877-17-000010:mdna:228]
[same as prior period, unchanged from 0000858877-17-000004:mdna:220]

[0000858877-17-000010:mdna:229]
Our APJC segment gross margin percentage increased primarily due to productivity improvements, partially offset by the unfavorable impacts from pricing. We also experienced a higher service gross margin in this segment.

[0000858877-17-000010:mdna:230]
[same as prior period, unchanged from 0000858877-17-000004:mdna:225]

[0000858877-17-000010:mdna:231]
Nine Months Ended April 29, 2017 Compared with Nine Months Ended April 30, 2016

[0000858877-17-000010:mdna:232]
We experienced a gross margin percentage increase in our Americas segment due to productivity improvements and the sale of the lower margin SP Video CPE Business, partially offset by unfavorable impacts from pricing and product mix. The unfavorable mix impact in this geographic segment was driven by unfavorable mix from our NGN Routing, Other, and Switching product categories.

[0000858877-17-000010:mdna:233]
The gross margin percentage increase in our EMEA segment was due primarily to the impact of productivity improvements, the sale of the lower margin SP Video CPE Business and a favorable product mix. Partially offsetting these favorable impacts to gross margin were negative impacts from pricing. Higher service gross margin also contributed to the increase in the overall gross margin in this segment.

[0000858877-17-000010:mdna:234]
The APJC segment gross margin percentage increased due primarily to higher service gross margin. Product gross margin in this segment also increased due to productivity improvements, partially offset by unfavorable impacts from pricing and product mix. The unfavorable mix impact was driven by our Cisco Unified Computing System products.

[0000858877-17-000010:mdna:235]
[same as prior period, unchanged from 0000858877-17-000004:mdna:230]

[0000858877-17-000010:mdna:236]
[same as prior period, unchanged from 0000858877-17-000004:mdna:231]

[0000858877-17-000010:mdna:237]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 29, 2017 |  | April 30, 2016 |  | Variancein Dollars |  | Variance in Percent |  | April 29, 2017 |  | April 30, 2016 |  | Variancein Dollars |  | Variance in Percent |
| Research and development | $ | 1,507 |  |  | $ | 1,626 |  |  | $ | (119 | ) |  | (7.3 | )% |  | $ | 4,560 |  |  | $ | 4,695 |  |  | $ | (135 | ) |  | (2.9 | )% |
| Percentage of revenue | 12.6 | % |  | 13.6 | % |  |  |  |  |  | 12.7 | % |  | 12.8 | % |  |  |  |  |
| Sales and marketing | 2,226 |  |  | 2,447 |  |  | (221 | ) |  | (9.0 | )% |  | 6,866 |  |  | 7,176 |  |  | (310 | ) |  | (4.3 | )% |
| Percentage of revenue | 18.6 | % |  | 20.4 | % |  |  |  |  |  | 19.1 | % |  | 19.6 | % |  |  |  |  |
| General and administrative | 487 |  |  | 566 |  |  | (79 | ) |  | (14.0 | )% |  | 1,498 |  |  | 1,281 |  |  | 217 |  |  | 16.9 | % |
| Percentage of revenue | 4.1 | % |  | 4.7 | % |  |  |  |  |  | 4.2 | % |  | 3.5 | % |  |  |  |  |
| Total | $ | 4,220 |  |  | $ | 4,639 |  |  | $ | (419 | ) |  | (9.0 | )% |  | $ | 12,924 |  |  | $ | 13,152 |  |  | $ | (228 | ) |  | (1.7 | )% |
| Percentage of revenue | 35.3 | % |  | 38.7 | % |  |  |  |  |  | 36.0 | % |  | 35.9 | % |  |  |  |  |

[0000858877-17-000010:mdna:238]
Our third quarter of fiscal 2017 had one less week compared with the corresponding period of fiscal 2016 which had an extra week. We estimate that the extra week contributed approximately $116 million of the year-over-year decrease in total operating expenses (not including share-based compensation expense discussed below) during the third quarter and first nine months of fiscal 2017.

[0000858877-17-000010:mdna:239]
[same as prior period, unchanged from 0000858877-17-000004:mdna:233]

[0000858877-17-000010:mdna:240]
R&D expenses decreased for the third quarter and first nine months of fiscal 2017, as compared with the corresponding periods of fiscal 2016, primarily due to lower discretionary spending, lower contracted services, lower acquisition-related costs and lower headcount-related expenses, partially offset by higher share-based compensation expense. Lower headcount related expenses were due to efficiencies related to our restructuring actions and the extra week in the third quarter and first nine months of fiscal 2016.

[0000858877-17-000010:mdna:241]
[same as prior period, unchanged from 0000858877-17-000004:mdna:238]

[0000858877-17-000010:mdna:242]
[same as prior period, unchanged from 0000858877-17-000004:mdna:236]

[0000858877-17-000010:mdna:243]
[same as prior period, unchanged from 0000858877-17-000004:mdna:237]

[0000858877-17-000010:mdna:244]
[same as prior period, unchanged from 0000858877-17-000004:mdna:239]

[0000858877-17-000010:mdna:245]
Sales and marketing expenses decreased for the third quarter and first nine months of fiscal 2017, compared with the corresponding periods of fiscal 2016, due to lower headcount-related expenses, lower contracted services, lower discretionary spending, lower acquisition-related costs and lower share-based compensation expense. Lower headcount related expenses were due to efficiencies related to our restructuring actions. The extra week in the third quarter and first nine months of fiscal 2016 also contributed to the decrease in headcount-related expenses.

[0000858877-17-000010:mdna:246]
[same as prior period, unchanged from 0000858877-17-000004:mdna:241]

[0000858877-17-000010:mdna:247]
G&A expenses decreased in the third quarter of fiscal 2017, as compared with the third quarter of fiscal 2016, primarily due to lower headcount-related expenses and lower contracted services partially offset by higher share-based compensation expense. The extra week in the third quarter of fiscal 2016 also contributed to the decrease in headcount-related expenses.

[0000858877-17-000010:mdna:248]
G&A expenses increased in the first nine months of fiscal 2017, as compared with the first nine months of fiscal 2016, primarily due to the $285 million pre-tax gain from the sale of our SP Video CPE Business recorded during fiscal 2016 and, to a lesser extent, higher share-based compensation expense. The G&A expense increase was partially offset by lower headcount-related expenses and lower contracted services. The extra week in the first nine months of fiscal 2016 also contributed to the headcount-related expense decrease.

[0000858877-17-000010:mdna:249]
[same as prior period, unchanged from 0000858877-17-000004:mdna:243]

[0000858877-17-000010:mdna:250]
In the third quarter of fiscal 2017, foreign currency fluctuations, net of hedging, decreased the combined R&D, sales and marketing, and G&A expenses by approximately $2 million compared with the third quarter of fiscal 2016.

[0000858877-17-000010:mdna:251]
In the first nine months of fiscal 2017, foreign currency fluctuations, net of hedging, decreased the combined R&D, sales and marketing, and G&A expenses by approximately $62 million, or approximately 0.5%, compared with the first nine months of fiscal 2016.

[0000858877-17-000010:mdna:252]
[same as prior period, unchanged from 0000858877-17-000004:mdna:246]

[0000858877-17-000010:mdna:253]
Our headcount as of April 29, 2017 was 73,390, which represents an increase of 1,431 employees in the third quarter of fiscal 2017 and a decrease of 321 employees in the first nine months of fiscal 2017, each as compared with the total headcount at the end of fiscal 2016. The increase in headcount for third quarter of fiscal 2017 was primarily due to headcount additions from our acquisition of AppDynamics. The decrease in headcount for first nine months of fiscal 2017 was driven by our fiscal 2017 restructuring actions that began in the first quarter, partially offset by headcount additions from our investments in key growth areas and from our AppDynamics acquisition.

[0000858877-17-000010:mdna:254]
[same as prior period, unchanged from 0000858877-17-000004:mdna:248]

[0000858877-17-000010:mdna:255]
[same as prior period, unchanged from 0000858877-17-000004:mdna:249]

[0000858877-17-000010:mdna:256]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 29, 2017 |  | April 30, 2016 |  | April 29, 2017 |  | April 30, 2016 |
| Cost of sales—product |  | $ | 22 |  |  | $ | 21 |  |  | $ | 62 |  |  | $ | 50 |  |
| Cost of sales—service |  | 34 |  |  | 37 |  |  | 101 |  |  | 110 |  |
| Share-based compensation expense in cost of sales |  | 56 |  |  | 58 |  |  | 163 |  |  | 160 |  |
| Research and development |  | 137 |  |  | 130 |  |  | 392 |  |  | 351 |  |
| Sales and marketing |  | 133 |  |  | 148 |  |  | 398 |  |  | 413 |  |
| General and administrative |  | 79 |  |  | 59 |  |  | 173 |  |  | 163 |  |
| Restructuring and other charges |  | (5 | ) |  | — |  |  | (2 | ) |  | 14 |  |
| Share-based compensation expense in operating expenses |  | 344 |  |  | 337 |  |  | 961 |  |  | 941 |  |
| Total share-based compensation expense |  | $ | 400 |  |  | $ | 395 |  |  | $ | 1,124 |  |  | $ | 1,101 |  |

[0000858877-17-000010:mdna:257]
The increase in share-based compensation expense in the third quarter and first nine months of fiscal 2017, as compared with the corresponding periods of fiscal 2016, was due primarily to higher expense related to equity awards assumed with respect to our recent acquisitions, partially offset by the impact of extra week in the third quarter of fiscal 2016.

[0000858877-17-000010:mdna:258]
[same as prior period, unchanged from 0000858877-17-000004:mdna:253]

[0000858877-17-000010:mdna:259]
[same as prior period, unchanged from 0000858877-17-000004:mdna:254]

[0000858877-17-000010:mdna:260]
[same as prior period, unchanged from 0000858877-17-000004:mdna:255]

[0000858877-17-000010:mdna:261]
[same as prior period, unchanged from 0000858877-17-000004:mdna:256]

[0000858877-17-000010:mdna:262]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 29, 2017 |  | April 30, 2016 |  | April 29, 2017 |  | April 30, 2016 |
| Amortization of purchased intangible assets: |  |  |  |  |  |  |  |  |
| Cost of sales |  | $ | 141 |  |  | $ | 134 |  |  | $ | 394 |  |  | $ | 419 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Amortization of purchased intangible assets |  | 59 |  |  | 81 |  |  | 201 |  |  | 221 |  |
| Restructuring and other charges |  | — |  |  | — |  |  | 38 |  |  | — |  |
| Total |  | $ | 200 |  |  | $ | 215 |  |  | $ | 633 |  |  | $ | 640 |  |

[0000858877-17-000010:mdna:263]
Amortization of purchased intangible assets decreased for the third quarter of fiscal 2017, as compared with the third quarter of fiscal 2016, due to certain purchased intangible assets having become fully amortized or impaired, partially offset by amortization of purchased intangible assets from our recent acquisitions.

[0000858877-17-000010:mdna:264]
Amortization of purchased intangible assets decreased for the first nine months of fiscal 2017, as compared with the first nine months of fiscal 2016, due to certain purchased intangible assets having become fully amortized, partially offset by higher impairment charges and amortization of purchased intangible assets from our recent acquisitions.

[0000858877-17-000010:mdna:265]
[same as prior period, unchanged from 0000858877-17-000004:mdna:260]

[0000858877-17-000010:mdna:266]
In the third quarter and first nine months of fiscal 2017, we incurred restructuring and other charges of approximately $70 million and $614 million, respectively, which were related primarily to employee severance charges for employees impacted by the restructuring action announced in August 2016. In May 2017, we extended the restructuring action to include an additional 1,100 employees and $150 million of additional estimated pretax charges. Our estimated aggregate pretax charges pursuant to the restructuring action are expected to be approximately $850 million, and we expect the restructuring action to be substantially completed by the end of the first quarter of fiscal 2018. We expect to reinvest substantially all of the cost savings from the restructuring action in our key priority areas such as security, IoT, collaboration, next generation data center and cloud.  As a result, the overall cost savings from the restructuring action are not expected to be material for future periods.

[0000858877-17-000010:mdna:267]
In the third quarter and first nine months of fiscal 2016, we incurred restructuring and other charges of approximately $17 million and $253 million net of a $2 million credit to cost of sales, respectively.  These charges were related primarily to employee severance charges for employees impacted by the restructuring action announced in August 2014. We completed this restructuring action in fiscal 2016.

[0000858877-17-000010:mdna:268]
[same as prior period, unchanged from 0000858877-17-000004:mdna:263]

[0000858877-17-000010:mdna:269]
[same as prior period, unchanged from 0000858877-17-000004:mdna:264]

[0000858877-17-000010:mdna:270]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 29, 2017 |  | April 30, 2016 |  | April 29, 2017 |  | April 30, 2016 |
| Operating income |  | $ | 3,169 |  |  | $ | 2,984 |  |  | $ | 8,939 |  |  | $ | 9,357 |  |
| Operating income as a percentage of revenue |  | 26.5 | % |  | 24.9 | % |  | 24.9 | % |  | 25.6 | % |

[0000858877-17-000010:mdna:271]
For the third quarter of fiscal 2017, as compared with the third quarter of fiscal 2016, operating income increased by 6% and as a percentage of revenue operating income increased by 1.6 percentage points. These increases were due primarily to decrease in operating expenses.

[0000858877-17-000010:mdna:272]
For the first nine months of fiscal 2017, as compared with the first nine months of fiscal 2016, operating income decreased by 4%, and as a percentage of revenue operating income decreased by 0.7 percentage points. The decrease resulted from the $285 million pre-tax gain from the sale of our SP Video CPE Business recorded during fiscal 2016 and an increase in restructuring and other charges related to the restructuring action announced in August 2016.

[0000858877-17-000010:mdna:273]
[same as prior period, unchanged from 0000858877-17-000004:mdna:267]

[0000858877-17-000010:mdna:274]
[same as prior period, unchanged from 0000858877-17-000004:mdna:268]

[0000858877-17-000010:mdna:275]
[same as prior period, unchanged from 0000858877-17-000004:mdna:269]

[0000858877-17-000010:mdna:276]
[same as prior period, unchanged from 0000858877-17-000004:mdna:270]

[0000858877-17-000010:mdna:277]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 29, 2017 |  | April 30, 2016 |  | Variancein Dollars |  | April 29, 2017 |  | April 30, 2016 |  | Variancein Dollars |
| Interest income |  | $ | 354 |  |  | $ | 270 |  |  | $ | 84 |  |  | $ | 978 |  |  | $ | 732 |  |  | $ | 246 |  |
| Interest expense |  | (219 | ) |  | (175 | ) |  | (44 | ) |  | (639 | ) |  | (496 | ) |  | (143 | ) |
| Interest income (expense), net |  | $ | 135 |  |  | $ | 95 |  |  | $ | 40 |  |  | $ | 339 |  |  | $ | 236 |  |  | $ | 103 |  |

[0000858877-17-000010:mdna:278]
For the third quarter and first nine months of fiscal 2017, interest income increased compared with the corresponding periods of fiscal 2016, driven by an increase in our portfolio of cash, cash equivalents, and fixed income investments as well as higher yields on our portfolio.  Interest expense in the third quarter and first nine months of fiscal 2017, as compared with the corresponding periods of fiscal 2016, was higher driven by higher average debt balances and the impact of higher effective interest rates on both floating-rate senior notes and interest rate swaps associated with fixed-rate senior notes.

[0000858877-17-000010:mdna:279]
[same as prior period, unchanged from 0000858877-17-000004:mdna:273]

[0000858877-17-000010:mdna:280]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 29, 2017 |  | April 30, 2016 |  | Variancein Dollars |  | April 29, 2017 |  | April 30, 2016 |  | Variancein Dollars |
| Gains (losses) on investments, net: |  |  |  |  |  |  |  |  |  |  |  |  |
| Publicly traded equity securities |  | $ | (59 | ) |  | $ | 25 |  |  | $ | (84 | ) |  | $ | (50 | ) |  | $ | 18 |  |  | $ | (68 | ) |
| Fixed income securities |  | (17 | ) |  | (31 | ) |  | 14 |  |  | (41 | ) |  | (44 | ) |  | 3 |  |
| Total available-for-sale investments |  | (76 | ) |  | (6 | ) |  | (70 | ) |  | (91 | ) |  | (26 | ) |  | (65 | ) |
| Privately held companies |  | — |  |  | 22 |  |  | (22 | ) |  | (53 | ) |  | (25 | ) |  | (28 | ) |
| Net gains (losses) on investments |  | (76 | ) |  | 16 |  |  | (92 | ) |  | (144 | ) |  | (51 | ) |  | (93 | ) |
| Other gains (losses), net |  | (37 | ) |  | (12 | ) |  | (25 | ) |  | (27 | ) |  | (16 | ) |  | (11 | ) |
| Other income (loss), net |  | $ | (113 | ) |  | $ | 4 |  |  | $ | (117 | ) |  | $ | (171 | ) |  | $ | (67 | ) |  | $ | (104 | ) |

[0000858877-17-000010:mdna:281]
Three Months Ended April 29, 2017 Compared with Three Months Ended April 30, 2016

[0000858877-17-000010:mdna:282]
The change in total net gains (losses) on available-for-sale investments in the third quarter of fiscal 2017, as compared with the third quarter of fiscal 2016, was driven by $73 million of impairment charges on publicly traded equity securities.

[0000858877-17-000010:mdna:283]
The change in net gains (losses) on investments in privately held companies for the third quarter of fiscal 2017, as compared with the third quarter of fiscal 2016, was primarily due to higher impairment charges on investments in privately held companies, partially offset by higher realized gains on investments in privately held companies.

[0000858877-17-000010:mdna:284]
The change in other gains (losses), net in the third quarter of fiscal 2017, as compared with the third quarter of fiscal 2016, was driven by impacts from net unfavorable foreign exchange and customer lease terminations, and higher donation expenses.

[0000858877-17-000010:mdna:285]
Nine Months Ended April 29, 2017 Compared with Nine Months Ended April 30, 2016

[0000858877-17-000010:mdna:286]
The change in total net gains (losses) on available-for-sale investments in the first nine months of fiscal 2017, as compared with the first nine months of fiscal 2016, was driven by the $73 million of impairment charges on publicly traded equity securities.

[0000858877-17-000010:mdna:287]
The change in net gains (losses) on investments in privately held companies for the first nine months of fiscal 2017, as compared with the first nine months of fiscal 2016, was primarily due to higher impairment charges on investments in privately held companies, partially offset by higher realized gains on investments in privately held companies.

[0000858877-17-000010:mdna:288]
The change in other gains (losses), net in the first nine months of fiscal 2017, as compared with the first nine months of fiscal 2016, was driven by impacts from equity derivatives and customer lease terminations.

[0000858877-17-000010:mdna:289]
[same as prior period, unchanged from 0000858877-17-000004:mdna:284]

[0000858877-17-000010:mdna:290]
[same as prior period, unchanged from 0000858877-17-000004:mdna:285]

[0000858877-17-000010:mdna:291]
[same as prior period, unchanged from 0000858877-17-000004:mdna:286]

[0000858877-17-000010:mdna:292]
[same as prior period, unchanged from 0000858877-17-000004:mdna:287]

[0000858877-17-000010:mdna:293]
The provision for income taxes resulted in an effective tax rate of 21.2% for the third quarter of fiscal 2017 compared with 23.8% for the third quarter of fiscal 2016, a net 2.6 percentage point decrease in the effective tax rate for the third quarter of fiscal 2017 as compared with the third quarter of fiscal 2016. The decrease in the effective tax rate was primarily due to an increase in foreign income taxed at lower than U.S. rates for the third quarter of fiscal 2017 as compared with the third quarter of fiscal 2016.

[0000858877-17-000010:mdna:294]
The provision for income taxes resulted in an effective tax rate of 21.1% for the first nine months of fiscal 2017 as compared with 16.8% for the first nine months of fiscal 2016, a net 4.3 percentage point increase in the effective tax rate for the first nine months of fiscal 2017 as compared with the first nine months of fiscal 2016. The increase in the effective tax rate was primarily due to the recognition of a net benefit to the provision for income taxes in the second quarter of fiscal 2016 related to our settlement with the IRS of all outstanding items covering fiscal 2008 through fiscal 2010 and reinstatement of the U.S. federal research and development (“R&D”) tax credit on December 18, 2015.

[0000858877-17-000010:mdna:295]
[same as prior period, unchanged from 0000858877-17-000004:mdna:290]

[0000858877-17-000010:mdna:296]
[same as prior period, unchanged from 0000858877-17-000004:mdna:291]

[0000858877-17-000010:mdna:297]
[same as prior period, unchanged from 0000858877-17-000004:mdna:292]

[0000858877-17-000010:mdna:298]
[same as prior period, unchanged from 0000858877-17-000004:mdna:293]

[0000858877-17-000010:mdna:299]
[same as prior period, unchanged from 0000858877-17-000004:mdna:294]

[0000858877-17-000010:mdna:300]
[same as prior period, unchanged from 0000858877-17-000004:mdna:295]

[0000858877-17-000010:mdna:301]
|  | April 29, 2017 |  | July 30, 2016 |  | Increase (Decrease) |
| Cash and cash equivalents | $ | 8,116 |  |  | $ | 7,631 |  |  | $ | 485 |  |
| Fixed income securities | 58,152 |  |  | 56,621 |  |  | 1,531 |  |
| Publicly traded equity securities | 1,706 |  |  | 1,504 |  |  | 202 |  |
| Total | $ | 67,974 |  |  | $ | 65,756 |  |  | $ | 2,218 |  |

[0000858877-17-000010:mdna:302]
The net increase in cash and cash equivalents and investments in the first nine months of fiscal 2017 was primarily driven by cash provided by operating activities of $9.9 billion and a net increase in debt of $4.1 billion. These sources of cash were partially offset by cash returned to shareholders in the form of cash dividends of $4.1 billion and repurchases of common stock of $2.5 billion under the stock repurchase program; net cash paid for acquisitions of $3.2 billion, the timing of settlements and the change in fair value of investments of $1.0 billion and capital expenditures of $0.8 billion.

[0000858877-17-000010:mdna:303]
Our total in cash and cash equivalents and investments held by various foreign subsidiaries was $65.1 billion and $59.8 billion as of April 29, 2017 and July 30, 2016, respectively. Under current tax laws and regulations, if these assets were to be distributed from the foreign subsidiaries to the United States in the form of dividends or otherwise, we would be subject to additional U.S. income taxes (subject to an adjustment for foreign tax credits) and foreign withholding taxes. The balance of cash and cash equivalents and investments available in the United States as of April 29, 2017 and July 30, 2016 was $2.9 billion and $5.9 billion, respectively.

[0000858877-17-000010:mdna:304]
[same as prior period, unchanged from 0000858877-17-000004:mdna:300]

[0000858877-17-000010:mdna:305]
[same as prior period, unchanged from 0000858877-17-000004:mdna:301]

[0000858877-17-000010:mdna:306]
[same as prior period, unchanged from 0000858877-17-000004:mdna:302]

[0000858877-17-000010:mdna:307]
|  | Nine Months Ended |
|  | April 29, 2017 |  | April 30, 2016 |
| Net cash provided by operating activities | $ | 9,875 |  |  | $ | 9,752 |  |
| Acquisition of property and equipment | (756 | ) |  | (880 | ) |
| Free cash flow | $ | 9,119 |  |  | $ | 8,872 |  |

[0000858877-17-000010:mdna:308]
[same as prior period, unchanged from 0000858877-17-000004:mdna:304]

[0000858877-17-000010:mdna:309]
[same as prior period, unchanged from 0000858877-17-000004:mdna:305]

[0000858877-17-000010:mdna:310]
[same as prior period, unchanged from 0000858877-17-000004:mdna:306]

[0000858877-17-000010:mdna:311]
[same as prior period, unchanged from 0000858877-17-000004:mdna:307]

[0000858877-17-000010:mdna:312]
[same as prior period, unchanged from 0000858877-17-000004:mdna:308]

[0000858877-17-000010:mdna:313]
|  |  | DIVIDENDS |  | STOCK REPURCHASE PROGRAM |  |  |
| Quarter Ended |  | Per Share |  | Amount |  | Shares |  | Weighted-Average Price per Share |  | Amount |  | TOTAL |
| Fiscal 2017 |  |  |  |  |  |  |  |  |  |  |  |  |
| April 29, 2017 |  | $ | 0.29 |  |  | $ | 1,451 |  |  | 15 |  |  | $ | 33.71 |  |  | $ | 503 |  |  | $ | 1,954 |  |
| January 28, 2017 |  | $ | 0.26 |  |  | $ | 1,304 |  |  | 33 |  |  | $ | 30.33 |  |  | $ | 1,001 |  |  | $ | 2,305 |  |
| October 29, 2016 |  | $ | 0.26 |  |  | $ | 1,308 |  |  | 32 |  |  | $ | 31.12 |  |  | $ | 1,001 |  |  | $ | 2,309 |  |
| Fiscal 2016 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| July 30, 2016 |  | $ | 0.26 |  |  | $ | 1,309 |  |  | 28 |  |  | $ | 28.70 |  |  | $ | 800 |  |  | $ | 2,109 |  |
| April 30, 2016 |  | $ | 0.26 |  |  | $ | 1,308 |  |  | 27 |  |  | $ | 24.08 |  |  | $ | 649 |  |  | $ | 1,957 |  |
| January 23, 2016 |  | $ | 0.21 |  |  | $ | 1,065 |  |  | 48 |  |  | $ | 26.12 |  |  | $ | 1,262 |  |  | $ | 2,327 |  |
| October 24, 2015 |  | $ | 0.21 |  |  | $ | 1,068 |  |  | 45 |  |  | $ | 26.83 |  |  | $ | 1,207 |  |  | $ | 2,275 |  |

[0000858877-17-000010:mdna:314]
Any future dividends are subject to the approval of our Board of Directors.

[0000858877-17-000010:mdna:315]
[same as prior period, unchanged from 0000858877-17-000004:mdna:311]

[0000858877-17-000010:mdna:316]
|  | April 29, 2017 |  | July 30, 2016 |  | Increase (Decrease) |
| Accounts receivable, net | $ | 4,635 |  |  | $ | 5,847 |  |  | $ | (1,212 | ) |

[0000858877-17-000010:mdna:317]
Our accounts receivable net, as of April 29, 2017 decreased by approximately 21%, as compared with the end of fiscal 2016, primarily due to product and service billings being more linear in the third quarter of fiscal 2017 compared with the fourth quarter of fiscal 2016.

[0000858877-17-000010:mdna:318]
[same as prior period, unchanged from 0000858877-17-000004:mdna:314]

[0000858877-17-000010:mdna:319]
|  | April 29, 2017 |  | July 30, 2016 |  | Increase (Decrease) |
| Inventories | $ | 1,366 |  |  | $ | 1,217 |  |  | $ | 149 |  |
| Annualized inventory turns | 13.5 |  |  | 14.6 |  |  | (1.1 | ) |
| Purchase commitments with contract manufacturers and suppliers | $ | 4,720 |  |  | $ | 3,896 |  |  | $ | 824 |  |

[0000858877-17-000010:mdna:320]
Inventory as of April 29, 2017 increased by 12% from our inventory balance at the end of fiscal 2016, and for the same period purchase commitments with contract manufacturers and suppliers increased by approximately 21%. On a combined basis, inventories and purchase commitments with contract manufacturers and suppliers increased by 19% compared with the end of fiscal 2016. The increase in inventory and purchase commitments with contract manufacturers and suppliers was due to securing memory supply which is currently constrained and procuring key components for specific product areas.

[0000858877-17-000010:mdna:321]
[same as prior period, unchanged from 0000858877-17-000004:mdna:317]

[0000858877-17-000010:mdna:322]
[same as prior period, unchanged from 0000858877-17-000004:mdna:318]

[0000858877-17-000010:mdna:323]
[same as prior period, unchanged from 0000858877-17-000004:mdna:319]

[0000858877-17-000010:mdna:324]
[same as prior period, unchanged from 0000858877-17-000004:mdna:320]

[0000858877-17-000010:mdna:325]
[same as prior period, unchanged from 0000858877-17-000004:mdna:321]

[0000858877-17-000010:mdna:326]
[same as prior period, unchanged from 0000858877-17-000004:mdna:322]

[0000858877-17-000010:mdna:327]
[same as prior period, unchanged from 0000858877-17-000004:mdna:323]

[0000858877-17-000010:mdna:328]
Financing Receivables and Guarantees We measure our net balance sheet exposure position related to our financing receivables and financing guarantees by reducing the total of gross financing receivables and financing guarantees by the associated allowances for credit loss and deferred revenue. As of April 29, 2017, our net balance sheet exposure position related to financing receivables and financing guarantees was as follows (in millions):

[0000858877-17-000010:mdna:329]
|  | FINANCING RECEIVABLES |  | FINANCING GUARANTEES |  |  |
| April 29, 2017 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts and Other |  | Total |  | Channel Partner |  | End-User Customers |  | Total |  | TOTAL |
| Financing receivables and guarantees | $ | 2,967 |  |  | $ | 2,659 |  |  | $ | 4,096 |  |  | $ | 9,722 |  |  | $ | 260 |  |  | $ | 83 |  |  | $ | 343 |  |  | $ | 10,065 |  |
| Unearned income | (146 | ) |  | — |  |  | — |  |  | (146 | ) |  | — |  |  | — |  |  | — |  |  | (146 | ) |
| Allowance for credit loss | (220 | ) |  | (117 | ) |  | (32 | ) |  | (369 | ) |  | — |  |  | — |  |  | — |  |  | (369 | ) |
| Deferred revenue | (12 | ) |  | (16 | ) |  | (1,965 | ) |  | (1,993 | ) |  | (83 | ) |  | (57 | ) |  | (140 | ) |  | (2,133 | ) |
| Net balance sheet exposure | $ | 2,589 |  |  | $ | 2,526 |  |  | $ | 2,099 |  |  | $ | 7,214 |  |  | $ | 177 |  |  | $ | 26 |  |  | $ | 203 |  |  | $ | 7,417 |  |

[0000858877-17-000010:mdna:330]
Financing Receivables  Financing receivables less unearned income increased by 9% compared with the end of fiscal 2016. The change was due to a 25% increase in loan receivables and a 22% increase in financed service contracts and other, partially offset by a 15% decrease in lease receivables. We provide financing to certain end-user customers and channel partners to enable sales of our products, services, and networking solutions. These financing arrangements include leases, financed service contracts, and loans. Arrangements related to leases are generally collateralized by a security interest in the underlying assets. Lease receivables include sales-type and direct-financing leases. We also provide certain qualified customers financing for long-term service contracts, which primarily relate to technical support services. Our loan financing arrangements may include not only financing the acquisition of our products and services but also providing additional funds for other costs associated with network installation and integration of our products and services. We expect to continue to expand the use of our financing programs in the near term.

[0000858877-17-000010:mdna:331]
[same as prior period, unchanged from 0000858877-17-000004:mdna:327]

[0000858877-17-000010:mdna:332]
The volume of channel partner financing was $19.7 billion and $19.8 billion for the first nine months of fiscal 2017 and 2016, respectively. These financing arrangements facilitate the working capital requirements of the channel partners, and in some cases, we guarantee a portion of these arrangements. The balance of the channel partner financing subject to guarantees was $0.9 billion and $1.1 billion as of April 29, 2017 and July 30, 2016, respectively.

[0000858877-17-000010:mdna:333]
70

[0000858877-17-000010:mdna:334]
[same as prior period, unchanged from 0000858877-17-000004:mdna:329]

[0000858877-17-000010:mdna:335]
[same as prior period, unchanged from 0000858877-17-000004:mdna:330]

[0000858877-17-000010:mdna:336]
We could be called upon to make payments under these guarantees in the event of nonpayment by the channel partners or end-user customers. Historically, our payments under these arrangements have been immaterial. Where we provide a guarantee, we defer the revenue associated with the channel partner and end-user financing arrangement in accordance with revenue recognition policies, or we record a liability for the fair value of the guarantees. In either case, the deferred revenue is recognized as revenue when the guarantee is removed.

[0000858877-17-000010:mdna:337]
[same as prior period, unchanged from 0000858877-17-000004:mdna:332]

[0000858877-17-000010:mdna:338]
[same as prior period, unchanged from 0000858877-17-000004:mdna:333]

[0000858877-17-000010:mdna:339]
[same as prior period, unchanged from 0000858877-17-000004:mdna:334]

[0000858877-17-000010:mdna:340]
|  | Maturity Date |  | April 29, 2017 |  | July 30, 2016 |
| Senior notes: |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |
| Three-month LIBOR plus 0.28% | March 3, 2017 | (1) | $ | — |  |  | $ | 1,000 |  |
| Three-month LIBOR plus 0.60% | February 21, 2018 |  | 1,000 |  |  | 1,000 |  |
| Three-month LIBOR plus 0.31% | June 15, 2018 |  | 900 |  |  | 900 |  |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | 500 |  |  | 500 |  |
| Three-month LIBOR plus 0.34% | September 20, 2019 | (2) | 500 |  |  | — |  |
| Fixed-rate notes: |  |  |  |  |  |
| 1.10% | March 3, 2017 | (1) | — |  |  | 2,400 |  |
| 3.15% | March 14, 2017 | (1) | — |  |  | 750 |  |
| 1.40% | February 28, 2018 |  | 1,250 |  |  | 1,250 |  |
| 1.65% | June 15, 2018 |  | 1,600 |  |  | 1,600 |  |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 2,000 |  |
| 1.60% | February 28, 2019 |  | 1,000 |  |  | 1,000 |  |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 1,750 |  |
| 1.40% | September 20, 2019 | (2) | 1,500 |  |  | — |  |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 2,500 |  |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 1,500 |  |
| 2.20% | February 28, 2021 |  | 2,500 |  |  | 2,500 |  |
| 2.90% | March 4, 2021 |  | 500 |  |  | 500 |  |
| 1.85% | September 20, 2021 | (2) | 2,000 |  |  | — |  |
| 3.00% | June 15, 2022 |  | 500 |  |  | 500 |  |
| 2.60% | February 28, 2023 |  | 500 |  |  | 500 |  |
| 2.20% | September 20, 2023 | (2) | 750 |  |  | — |  |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1,000 |  |
| 3.50% | June 15, 2025 |  | 500 |  |  | 500 |  |
| 2.95% | February 28, 2026 |  | 750 |  |  | 750 |  |
| 2.50% | September 20, 2026 | (2) | 1,500 |  |  | — |  |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 2,000 |  |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 2,000 |  |
| Total |  |  | $ | 30,500 |  |  | $ | 28,400 |  |

[0000858877-17-000010:mdna:341]
(1) In March 2017, we repaid senior notes with an aggregate principal amount of $4.15 billion upon maturity.

[0000858877-17-000010:mdna:342]
(2) In September 2016, we issued senior notes with an aggregate principal amount of $6.25 billion.

[0000858877-17-000010:mdna:343]
[same as prior period, unchanged from 0000858877-17-000004:mdna:339]

[0000858877-17-000010:mdna:344]
[same as prior period, unchanged from 0000858877-17-000004:mdna:340]

[0000858877-17-000010:mdna:345]
Interest is payable semiannually on each class of the senior fixed-rate notes, each of which is redeemable by us at any time, subject to a make-whole premium. Interest is payable quarterly on the floating-rate notes. We were in compliance with all debt covenants as of April 29, 2017.

[0000858877-17-000010:mdna:346]
[same as prior period, unchanged from 0000858877-17-000004:mdna:341]

[0000858877-17-000010:mdna:347]
Commercial Paper  Effective March 31, 2017, we increased our borrowing capacity under our commercial paper program from $3.0 billion to $10.0 billion. We use the proceeds from the issuance of commercial paper notes for general corporate purposes.  We had $2.0 billion and no commercial paper notes outstanding as of April 29, 2017 and July 30, 2016, respectively.

[0000858877-17-000010:mdna:348]
Credit Facilities On May 15, 2015, we entered into a credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 15, 2020. Any advances under the credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (i) the highest of (a) the Federal Funds rate plus 0.50%, (b) Bank of America’s “prime rate” as announced from time to time, or (c) LIBOR, or a comparable or successor rate that is approved by the Administrative Agent (“Eurocurrency Rate”), for an interest period of one month plus 1.00%, or (ii) the Eurocurrency Rate, plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the Eurocurrency Rate be less than zero. We may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and/or extend the expiration date of the credit facility up to May 15, 2022.

[0000858877-17-000010:mdna:349]
In addition, on March 30, 2017 we entered into a 364-Day credit agreement with certain institutional lenders that provides for a $2.0 billion unsecured revolving credit facility that is scheduled to expire on March 29, 2018. The credit agreement also provides us the option to, for a fee, convert any borrowings outstanding thereunder on March 29, 2018 to a term loan maturing no later than March 29, 2019. The interest rate applicable to outstanding balances under the credit agreement will be based on either (i) the higher of (a) the rates on overnight Federal Funds transactions with members of the Federal Reserve System (i.e., Federal Funds rate) plus 0.50%, (b) Bank of America’s “prime rate” as announced from time to time or (c) LIBOR for an interest period of one month plus 1.00%, or (ii) LIBOR plus a margin that is based on our senior debt credit ratings as published by S&P Global Rating, a business unit of Standard & Poor’s Financial Services LLC, and Moody’s Investors Service, Inc.

[0000858877-17-000010:mdna:350]
These credit agreements require that we comply with certain covenants, including that we maintain interest coverage ratios as defined in these agreements. As of April 29, 2017, we were in compliance with the required interest coverage ratios and the other covenants, and we had not borrowed any funds under these credit facilities.

[0000858877-17-000010:mdna:351]
[same as prior period, unchanged from 0000858877-17-000004:mdna:345]

[0000858877-17-000010:mdna:352]
|  | April 29, 2017 |  | July 30, 2016 |  | Increase (Decrease) |
| Service | $ | 10,532 |  |  | $ | 10,621 |  |  | $ | (89 | ) |
| Product: |  |  |  |  |  |  |
| Deferred revenue related to recurring software and subscription businesses | 4,352 |  |  | 3,308 |  |  | 1,044 |  |
| Deferred revenue related to two-tier distributors | 311 |  |  | 377 |  |  | (66 | ) |
| Other product deferred revenue | 2,127 |  |  | 2,166 |  |  | (39 | ) |
| Total product deferred revenue | 6,790 |  |  | 5,851 |  |  | 939 |  |
| Total | $ | 17,322 |  |  | $ | 16,472 |  |  | $ | 850 |  |
| Reported as: |  |  |  |  |  |
| Current | $ | 10,344 |  |  | $ | 10,155 |  |  | $ | 189 |  |
| Noncurrent | 6,978 |  |  | 6,317 |  |  | 661 |  |
| Total | $ | 17,322 |  |  | $ | 16,472 |  |  | $ | 850 |  |

[0000858877-17-000010:mdna:353]
Deferred product revenue increased 16% primarily due to increased deferrals related to recurring software and subscription businesses. The portion of product deferred revenue related to recurring software and subscription businesses grew 57% on a year-over-year basis to $4.4 billion as of April 29, 2017, which includes recurring deferred revenue from the acquisition of AppDynamics.

[0000858877-17-000010:mdna:354]
[same as prior period, unchanged from 0000858877-17-000004:mdna:348]

[0000858877-17-000010:mdna:355]
[same as prior period, unchanged from 0000858877-17-000004:mdna:349]

[0000858877-17-000010:mdna:356]
Product deferred revenue related to recurring software and subscription businesses not including AppDynamics grew 51% on a year-over-year basis. Wireless, Security, and Collaboration were the key product category contributors of this product deferred revenue growth during the period. The 1% decrease in deferred service revenue was driven by the timing of multiyear arrangements and the impact of ongoing amortization of deferred service revenue.

[0000858877-17-000010:mdna:357]
[same as prior period, unchanged from 0000858877-17-000004:mdna:350]

[0000858877-17-000010:mdna:358]
[same as prior period, unchanged from 0000858877-17-000004:mdna:351]

[0000858877-17-000010:mdna:359]
We lease office space in many U.S. locations. Outside the United States, larger leased sites include sites in Belgium, Canada, China, France, Germany, India, Israel, Japan, Poland and the United Kingdom. We also lease equipment and vehicles. The future minimum lease payments under all of our noncancelable operating leases with an initial term in excess of one year as of April 29, 2017 were $1.2 billion.

[0000858877-17-000010:mdna:360]
[same as prior period, unchanged from 0000858877-17-000004:mdna:353]

[0000858877-17-000010:mdna:361]
In connection with our acquisitions, we have agreed to pay certain additional amounts contingent upon the achievement of certain agreed-upon technology, development, product, or other milestones or the continued employment with us of certain employees of the acquired entities. See Note 12 to the Consolidated Financial Statements.

[0000858877-17-000010:mdna:362]
[same as prior period, unchanged from 0000858877-17-000004:mdna:355]

[0000858877-17-000010:mdna:363]
During the first quarter of fiscal 2014, we exercised our call option and entered into an agreement to purchase the remaining interests in Insieme. The acquisition closed in the second quarter of fiscal 2014, at which time the former noncontrolling interest holders became eligible to receive up to two milestone payments, which will be determined using agreed-upon formulas based primarily on revenue for certain of Insieme’s products. During the nine months ended April 29, 2017 and April 30, 2016, we recorded compensation expense of $41 million and $136 million, respectively, related to the fair value of the vested portion of amounts that were earned or are expected to be earned by the former noncontrolling interest holders. Continued vesting will result in additional compensation expense in future periods. Based on the terms of the agreement, we have determined that the maximum amount that could be recorded as compensation expense by us is approximately $831 million (which includes the $824 million that has been expensed to date), net of forfeitures. The former noncontrolling interest holders earned the maximum amount related to these two milestone payments and were paid approximately $436 million and $375 million during the first nine months of fiscal 2017 and fiscal 2016, respectively.  As of April 29, 2017, we paid a total of approximately $825 million pursuant to these two milestone payments.

[0000858877-17-000010:mdna:364]
[same as prior period, unchanged from 0000858877-17-000004:mdna:357]

[0000858877-17-000010:mdna:365]
[same as prior period, unchanged from 0000858877-17-000004:mdna:358]

[0000858877-17-000010:mdna:366]
We also have certain funding commitments primarily related to these variable interest entities, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $170 million as of April 29, 2017.

[0000858877-17-000010:mdna:367]
[same as prior period, unchanged from 0000858877-17-000004:mdna:360]

[0000858877-17-000010:mdna:368]
[same as prior period, unchanged from 0000858877-17-000004:mdna:361]

[0000858877-17-000010:mdna:369]
[same as prior period, unchanged from 0000858877-17-000004:mdna:363]

[0000858877-17-000010:mdna:370]
[same as prior period, unchanged from 0000858877-17-000004:mdna:364]

[0000858877-17-000010:mdna:371]
[same as prior period, unchanged from 0000858877-17-000004:mdna:365]

[0000858877-17-000010:mdna:372]
We periodically engage in securities lending activities with certain of our available for sale investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. The average daily balance of securities lending for the nine months ended April 29, 2017 and April 30, 2016 was $0.8 billion and $0.6 billion, respectively. We require collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. We engage in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify us against collateral losses. As of April 29, 2017 and July 30, 2016, we had no outstanding securities lending transactions. We believe these arrangements do not present a material risk or impact to our liquidity requirements.

[0000858877-17-000010:mdna:373]
[same as prior period, unchanged from 0000858877-17-000004:mdna:367]

[0000858877-17-000010:mdna:374]
[same as prior period, unchanged from 0000858877-17-000004:mdna:368]
