# CSCO 8-K — 0001193125-17-173404 filed 2017-05-17

## item codes, every 8-K on or before 2017-05-23

- 2017-05-17 0001193125-17-173404 — 2.02
- 2017-03-31 0001193125-17-106620 — 1.01, 2.03, 9.01
- 2017-03-29 0001193125-17-101783 — 8.01
- 2017-03-13 0001193125-17-080485 — 5.02
- 2017-02-15 0001193125-17-045265 — 2.02
- 2016-12-22 0001193125-16-802182 — 8.01
- 2016-12-13 0001193125-16-791877 — 5.07
- 2016-11-16 0001193125-16-769785 — 2.02
- 2016-11-03 0001193125-16-758911 — 5.02, 9.01
- 2016-10-17 0001193125-16-739833 — 5.02
- 2016-09-21 0001193125-16-716006 — 8.01
- 2016-09-20 0001193125-16-714189 — 8.01, 9.01
- 2016-09-16 0001193125-16-712320 — 8.01
- 2016-09-15 0001193125-16-711098 — 1.01, 9.01
- 2016-09-13 0001193125-16-708007 — 8.01, 9.01
- 2016-09-06 0001193125-16-702020 — 8.01
- 2016-08-17 0001193125-16-684126 — 2.02, 2.05
- 2016-07-29 0001193125-16-664620 — 5.03, 9.01
- 2016-06-27 0001193125-16-633145 — 8.01
- 2016-06-23 0001193125-16-630146 — 8.01
- 2016-06-07 0001193125-16-615321 — 5.02, 9.01
- 2016-05-18 0001193125-16-594463 — 2.02
- 2016-03-24 0001193125-16-516953 — 8.01
- 2016-02-29 0001193125-16-483780 — 8.01, 9.01
- 2016-02-25 0001193125-16-478442 — 8.01
- 2016-02-24 0001193125-16-474071 — 1.01, 9.01
- 2016-02-22 0001193125-16-470856 — 8.01, 9.01
- 2016-02-10 0001193125-16-457586 — 2.02
- 2016-01-28 0001193125-16-441933 — 5.02
- 2015-12-08 0001193125-15-397797 — 8.01
- 2015-11-20 0001193125-15-383743 — 5.07
- 2015-11-12 0001193125-15-375655 — 2.02
- 2015-09-21 0001193125-15-324465 — 8.01
- 2015-09-17 0001193125-15-322456 — 8.01
- 2015-09-14 0001193125-15-319489 — 8.01
- 2015-08-28 0001193125-15-306843 — 8.01
- 2015-08-12 0001193125-15-288099 — 2.02
- 2015-07-29 0001193125-15-268359 — 5.02 — amendment of 0001193125-15-169227
- 2015-06-18 0001193125-15-227387 — 8.01, 9.01
- 2015-06-12 0001193125-15-221863 — 1.01, 9.01
- 2015-06-10 0001193125-15-218734 — 8.01, 9.01
- 2015-06-01 0001193125-15-209142 — 5.02, 9.01
- 2015-05-13 0001193125-15-185905 — 2.02
- 2015-05-04 0001193125-15-169227 — 5.02
- 2015-03-24 0001193125-15-103369 — 8.01
- 2015-03-19 0001193125-15-098638 — 8.01
- 2015-02-11 0001193125-15-044175 — 2.02
- 2014-12-19 0001193125-14-448754 — 8.01
- 2014-12-18 0001193125-14-447039 — 8.01
- 2014-11-24 0001193125-14-423591 — 5.02, 5.07, 9.01
- 2014-11-14 0001193125-14-413384 — 5.02
- 2014-11-12 0001193125-14-409258 — 2.02
- 2014-09-25 0001193125-14-353210 — 8.01
- 2014-09-12 0001193125-14-340480 — 5.02
- 2014-08-14 0001193125-14-308733 — 2.05
- 2014-08-13 0001193125-14-308403 — 2.02
- 2014-07-31 0001193125-14-289683 — 5.02
- 2014-06-25 0001193125-14-249157 — 8.01
- 2014-05-14 0001193125-14-199056 — 2.02
- 2014-03-26 0001193125-14-116588 — 8.01
- 2014-03-11 0001193125-14-093805 — 8.01
- 2014-03-03 0001193125-14-079163 — 1.01, 8.01, 9.01
- 2014-02-26 0001193125-14-069912 — 1.01, 9.01
- 2014-02-12 0001193125-14-048150 — 2.02
- 2013-12-23 0001193125-13-483099 — 8.01
- 2013-12-04 0001193125-13-462216 — 8.01
- 2013-11-20 0001193125-13-448477 — 5.02, 5.07, 9.01
- 2013-11-13 0001193125-13-440194 — 2.02
- 2013-08-15 0001193125-13-335218 — 2.05
- 2013-08-14 0001193125-13-334648 — 2.02
- 2013-07-23 0001193125-13-298129 — 8.01, 9.01
- 2013-06-24 0001193125-13-269064 — 8.01
- 2013-06-12 0001193125-13-256194 — 8.01
- 2013-06-07 0001193125-13-250920 — 8.01
- 2013-05-15 0001193125-13-222377 — 2.02
- 2013-03-26 0001193125-13-127015 — 8.01
- 2013-02-13 0001193125-13-055377 — 2.02
- 2013-02-01 0001193125-13-034682 — 5.02
- 2013-01-08 0001193125-13-006886 — 5.02, 9.01
- 2012-12-21 0001193125-12-513130 — 8.01
- 2012-12-19 0001193125-12-508424 — 8.01
- 2012-11-16 0001193125-12-474089 — 5.02, 5.07, 9.01
- 2012-11-13 0001193125-12-467422 — 2.02
- 2012-10-04 0001193125-12-415386 — 5.02, 5.03, 9.01
- 2012-09-19 0001193125-12-396875 — 5.02, 8.01
- 2012-08-15 0001193125-12-357479 — 2.02
- 2012-08-02 0001193125-12-332045 — 5.02
- 2012-06-27 0001193125-12-285742 — 8.01
- 2012-06-13 0001193125-12-269642 — 8.01
- 2012-05-09 0001193125-12-222045 — 2.02
- 2012-03-27 0001193125-12-134384 — 8.01
- 2012-03-15 0001193125-12-117538 — 8.01, 9.01
- 2012-02-17 0001193125-12-067542 — 1.01, 1.02, 2.03, 9.01
- 2012-02-08 0001193125-12-046545 — 2.02
- 2011-12-16 0001193125-11-343995 — 8.01
- 2011-12-08 0001193125-11-335127 — 5.02, 5.07, 9.01
- 2011-11-09 0001193125-11-304587 — 2.02
- 2011-09-29 0001193125-11-260065 — 8.01
- 2011-09-20 0001193125-11-252379 — 5.02, 9.01
- 2011-08-24 0001193125-11-231015 — 8.01
- 2011-08-10 0001193125-11-218133 — 2.02
- 2011-07-18 0001193125-11-190246 — 2.05
- 2011-06-22 0001193125-11-170849 — 8.01
- 2011-05-11 0001193125-11-135913 — 2.02
- 2011-03-28 0001193125-11-079927 — 8.01
- 2011-03-22 0001193125-11-073802 — 5.02 — amendment of 0001193125-11-043592
- 2011-03-18 0001193125-11-071279 — 8.01, 9.01
- 2011-03-16 0001193125-11-067985 — 1.01, 5.02, 8.01, 9.01
- 2011-03-15 0001193125-11-067331 — 1.01, 9.01
- 2011-03-09 0001193125-11-060123 — 8.01, 9.01
- 2011-02-23 0001193125-11-043592 — 5.02
- 2011-02-09 0001193125-11-028987 — 2.02
- 2011-01-31 0001193125-11-019101 — 1.01, 2.03
- 2010-12-17 0001193125-10-283392 — 8.01
- 2010-11-19 0001193125-10-265377 — 5.07
- 2010-11-10 0001193125-10-256001 — 2.02
- 2010-09-22 0001193125-10-214707 — 8.01
- 2010-09-16 0001193125-10-211456 — 7.01
- 2010-08-11 0001193125-10-186042 — 2.02
- 2010-06-29 0001193125-10-149956 — 8.01
- 2010-05-12 0001193125-10-117509 — 2.02
- 2010-02-17 0001193125-10-033290 — 5.02, 8.01, 9.01
- 2010-02-03 0001193125-10-020775 — 2.02
- 2009-11-25 0001193125-09-242589 — 8.01
- 2009-11-17 0001193125-09-236335 — 1.01, 8.01, 9.01
- 2009-11-13 0001193125-09-234405 — 1.01, 2.03, 9.01
- 2009-11-13 0001193125-09-234397 — 5.02 — amendment of 0001193125-09-189511
- 2009-11-12 0001193125-09-232971 — 5.02, 7.01, 9.01
- 2009-11-09 0001193125-09-228541 — 8.01, 9.01
- 2009-11-04 0001193125-09-223763 — 2.02
- 2009-10-14 0001193125-09-207912 — 8.01, 9.01
- 2009-10-05 0001193125-09-203556 — 8.01
- 2009-09-10 0001193125-09-189511 — 5.02
- 2009-09-04 0001193125-09-187835 — 5.02
- 2009-08-05 0001193125-09-165404 — 2.02
- 2009-07-27 0001193125-09-155861 — 5.02
- 2009-05-29 0001193125-09-121672 — 8.01
- 2009-05-06 0001193125-09-101570 — 2.02
- 2009-02-26 0001193125-09-038162 — 5.02
- 2009-02-17 0001193125-09-030546 — 1.01, 8.01, 9.01
- 2009-02-13 0001193125-09-029295 — 1.01, 2.03, 9.01
- 2009-02-04 0001193125-09-018793 — 2.02
- 2008-11-05 0001193125-08-225857 — 2.02
- 2008-09-11 0001193125-08-194695 — 7.01
- 2008-08-05 0001193125-08-166496 — 2.02
- 2008-06-20 0001193125-08-137504 — 8.01
- 2008-05-06 0001193125-08-104089 — 2.02
- 2008-03-21 0001193125-08-062838 — 8.01
- 2008-02-06 0001193125-08-021681 — 2.02
- 2008-01-23 0001193125-08-010589 — 5.02
- 2008-01-04 0001193125-08-001680 — 5.02, 9.01
- 2007-12-21 0001193125-07-269613 — 5.02
- 2007-11-19 0001193125-07-250345 — 5.02 — amendment of 0001193125-07-009285
- 2007-11-19 0001193125-07-250343 — 5.02, 9.01
- 2007-11-07 0001193125-07-238464 — 2.02
- 2007-09-24 0001193125-07-206279 — 8.01
- 2007-09-20 0001193125-07-204616 — 5.02, 7.01
- 2007-09-07 0001193125-07-197514 — 8.01
- 2007-08-17 0001193125-07-185320 — 1.01, 2.03, 9.01
- 2007-08-08 0001193125-07-174077 — 5.02
- 2007-08-07 0001193125-07-173689 — 2.02
- 2007-08-01 0001193125-07-168143 — 5.02
- 2007-05-15 0001193125-07-115800 — 8.01
- 2007-05-08 0001193125-07-106059 — 2.02
- 2007-03-23 0001193125-07-063033 — 5.02, 5.03, 8.01, 9.01
- 2007-03-21 0001193125-07-060631 — 1.01, 9.01
- 2007-02-06 0001193125-07-021349 — 2.02
- 2007-01-19 0001193125-07-009285 — 5.02
- 2006-12-22 0001193125-06-259241 — 8.01
- 2006-11-16 0001193125-06-237260 — 5.03, 8.01, 9.01
- 2006-11-08 0001193125-06-228341 — 2.02
- 2006-09-21 0001193125-06-194890 — 1.01, 7.01
- 2006-09-20 0001193125-06-194063 — 1.01
- 2006-09-15 0001193125-06-191845 — 5.02
- 2006-08-18 0001193125-06-176193 — 5.02
- 2006-08-08 0001193125-06-165719 — 2.02
- 2006-07-31 0001193125-06-157106 — 1.01, 9.01
- 2006-07-31 0001193125-06-157102 — 5.02 — amendment of 0001193125-06-017426
- 2006-06-08 0001193125-06-126879 — 5.02
- 2006-05-18 0001193125-06-115516 — 8.01
- 2006-05-12 0001193125-06-110924 — 9.01 — amendment of 0001193125-06-044013
- 2006-05-09 0001193125-06-105419 — 2.02
- 2006-03-29 0001193125-06-066990 — 1.01
- 2006-03-02 0001193125-06-044013 — 1.01, 2.01, 9.01
- 2006-02-28 0001193125-06-041452 — 1.01
- 2006-02-22 0001193125-06-036759 — 8.01
- 2006-02-22 0001193125-06-036433 — 1.01, 8.01, 9.01
- 2006-02-21 0001193125-06-035865 — 1.01, 2.03, 9.01
- 2006-02-10 0001193125-06-026218 — 8.01, 9.01
- 2006-02-07 0001193125-06-022234 — 2.02
- 2006-02-01 0001193125-06-017426 — 5.02
- 2005-11-18 0001193125-05-229535 — 1.01, 9.01
- 2005-11-16 0001193125-05-227987 — 1.01, 9.01
- 2005-11-16 0001193125-05-227983 — 5.02 — amendment of 0001193125-05-008843
- 2005-11-09 0001193125-05-221610 — 2.02
- 2005-09-29 0001193125-05-194217 — 7.01
- 2005-09-27 0001193125-05-192353 — 8.01
- 2005-09-21 0001193125-05-189234 — 1.01, 9.01
- 2005-09-19 0001193125-05-187646 — 8.01
- 2005-09-09 0001193125-05-183273 — 8.01
- 2005-09-08 0001193125-05-182307 — 1.01
- 2005-08-09 0001193125-05-162626 — 2.02
- 2005-07-15 0001193125-05-142738 — 8.01
- 2005-05-10 0001193125-05-102797 — 2.02
- 2005-03-30 0001193125-05-065123 — 1.01, 3.03, 9.01
- 2005-03-04 0001193125-05-042778 — 1.01
- 2005-02-08 0001193125-05-022181 — 2.02
- 2005-01-20 0001193125-05-008843 — 5.02
- 2004-12-23 0001193125-04-219331 — 8.01
- 2004-11-09 0001193125-04-191303 — 2.02
- 2004-08-23 0001193125-04-145198 — 1.01, 7.01
- 2004-08-19 0001193125-04-143859 — 5
- 2004-08-10 0001193125-04-136865 — 12
- 2004-05-11 0001193125-04-084721 — 12
- 2004-02-03 0001193125-04-013750 — 12
- 2003-11-05 0001193125-03-073418 — 12
- 2003-09-02 0001193125-03-044521 — 9
- 2003-08-05 0001193125-03-029223 — 12, 7
- 2003-07-18 0001193125-03-021155 — 5, 7
- 2003-06-05 0001012870-03-002949 — 5
- 2003-05-06 0000891618-03-002315 — 7, 9
- 2003-04-17 0000891618-03-001894 — 5, 7
- 2003-04-11 0000891618-03-001791 — 9
- 2003-03-20 0000891618-03-001326 — 5, 7
- 2003-02-04 0000891618-03-000518 — 7, 9
- 2003-01-28 0000891618-03-000271 — 5, 7
- 2002-12-27 0000891618-02-005686 — 5, 7
- 2002-10-23 0000891618-02-004715 — 5, 7
- 2002-10-11 0000891618-02-004620 — 5, 7
- 2002-09-18 0000891618-02-004352 — 5, 7
- 2002-08-20 0000891618-02-004001 — 5, 7
- 2002-08-05 0000891618-02-003498 — 5, 7
- 2002-07-03 0000891618-02-003099 — 5, 7
- 2002-05-14 0000891618-02-002407 — 5, 7
- 2002-02-05 0000891618-02-000412 — 5, 7
- 2001-09-28 0001095811-01-505261 — 5, 7
- 2001-09-14 0001095811-01-504917 — 5, 7
- 2001-08-24 0001095811-01-504581 — 5, 7
- 2001-07-30 0001095811-01-503468 — 5, 7
- 2001-07-12 0000891618-01-501567 — 5, 7
- 2001-05-11 0000891618-01-500638 — 5, 7
- 2001-02-27 0000891618-01-500076 — 5, 7
- 2001-02-20 0001095811-01-001530 — 5, 7
- 2001-02-08 0001095811-01-000848 — 5, 7
- 2001-02-07 0001095811-01-000768 — 5
- 2000-12-27 0001095811-00-005511 — 5
- 2000-12-21 0001095811-00-005427 — 5
- 2000-12-19 0001095811-00-005368 — 5
- 2000-11-15 0001095811-00-004830 — 5
- 2000-11-15 0001095811-00-004824 — 5
- 2000-11-13 0000891618-00-005023 — 5
- 2000-11-07 0001095811-00-004387 — 5, 7
- 2000-11-06 0001095811-00-004318 — 5
- 2000-09-29 0000891618-00-004739 — 5, 7
- 2000-09-28 0000891618-00-004722 — 5
- 2000-09-26 0001095811-00-003573 — 5
- 2000-09-15 0001095811-00-003413 — 5
- 2000-09-07 0001095811-00-003229 — 5
- 2000-08-15 0000891618-00-004430 — 5
- 2000-08-04 0001095811-00-002304 — 5, 7 — amendment, the index does not say of what
- 2000-07-28 0000891618-00-004132 — 5, 7
- 2000-06-29 0000891618-00-003637 — 5
- 2000-06-07 0000891618-00-003209 — 5
- 2000-05-26 0000891618-00-003054 — 5
- 2000-05-18 0000891618-00-002975 — 5, 7
- 2000-05-15 0000891618-00-002808 — 5, 7
- 2000-05-03 0000891618-00-002473 — 5
- 2000-04-03 0000891618-00-001936 — 5
- 2000-03-28 0000891618-00-001763 — 5
- 2000-03-27 0000891618-00-001722 — 5, 7
- 2000-03-16 0000891618-00-001512 — 5
- 2000-02-17 0000891618-00-001024 — 5, 7
- 2000-02-03 0000891618-00-000468 — 7 — amendment of 0000891618-99-005685
- 1999-12-22 0000891618-99-005792 — 5, 7
- 1999-12-15 0000891618-99-005685 — 5, 7
- 1999-11-17 0000891618-99-005313 — 5, 7
- 1999-11-04 0000891618-99-004862 — 5, 7
- 1999-10-20 0000891618-99-004625 — 5, 7
- 1999-09-27 0000891618-99-004333 — 5, 7
- 1999-08-26 0000891618-99-003978 — 5, 7
- 1999-08-13 0000891618-99-003764 — 5, 7 — amendment of 0000891618-99-003749
- 1999-08-13 0000891618-99-003749 — 5, 7
- 1999-07-02 0000891618-99-002980 — 5, 7
- 1999-05-14 0000891618-99-002221 — 5
- 1998-11-20 0000891618-98-005074 — 5, 7
- 1998-11-20 0000891618-98-005073 — 5, 7
- 1998-10-13 0000891618-98-004462 — 5, 7
- 1998-07-09 0000891618-98-003245 — 5, 7
- 1998-06-11 0000891618-98-002832 — 5, 7
- 1998-05-15 0000891618-98-002457 — 5, 7
- 1998-04-29 0000891618-98-001996 — 5
- 1998-02-11 0000891618-98-000584 — 5, 7
- 1997-09-09 0000891618-97-003723 — 5, 7
- 1997-08-22 0000891618-97-003559 — 5, 7
- 1997-07-01 0000891618-97-002807 — 5, 7
- 1997-01-22 0000891618-97-000120 — 5, 7
- 1996-10-15 0000891618-96-002283 — 5, 7 — amendment of 0000891618-96-002217
- 1996-10-01 0000891618-96-002217 — 5, 7
- 1996-07-23 0000891618-96-001305 — 2, 7
- 1996-04-26 0000891618-96-000253 — 2
- 1996-04-02 0000898430-96-001187 — 2, 7
- 1995-12-06 0000891618-95-000728 — 2, 7
- 1995-12-06 0000891618-95-000727 — 2, 7

## late-filing notifications on or before 2017-05-23

- none on or before 2017-05-23

## item 2.02 — earnings release, exhibit 99.1

[0001193125-17-173404:8k_2_02:1]
EX-99.1
2
d358048dex991.htm
EXHIBIT 99.1

[0001193125-17-173404:8k_2_02:2]
Exhibit 99.1

[0001193125-17-173404:8k_2_02:3]
Exhibit 99.1

[0001193125-17-173404:8k_2_02:4]
| Press Contact: |  |  |  | Investor Relations Contact: |
| Andrea Duffy |  |  |  | Marilyn Mora |
| Cisco |  |  |  | Cisco |
| 1 (646) 295-5241 |  |  |  | 1 (408) 527-7452 |
| anduffy@cisco.com |  |  |  | marilmor@cisco.com |

[0001193125-17-173404:8k_2_02:5]
CISCO REPORTS THIRD QUARTER EARNINGS

[0001193125-17-173404:8k_2_02:6]
|  | • |  | Q3 Revenue: $11.9 billion |

[0001193125-17-173404:8k_2_02:7]
|  | • |  | Decrease of (1)% year over year |

[0001193125-17-173404:8k_2_02:8]
|  | • |  | Recurring revenue was 31% of total revenue, up 2 pts year over year |

[0001193125-17-173404:8k_2_02:9]
|  | • |  | Q3 Earnings per Share: $0.50 GAAP; $0.60 non-GAAP |

[0001193125-17-173404:8k_2_02:10]
|  | • |  | Q4 FY2017 Outlook: |

[0001193125-17-173404:8k_2_02:11]
|  | • |  | Revenue: (6)% to (4)% decline year over year |

[0001193125-17-173404:8k_2_02:12]
|  | • |  | Earnings per Share: GAAP $0.46 to $0.51; Non-GAAP: $0.60 to $0.62 |

[0001193125-17-173404:8k_2_02:13]
SAN JOSE, Calif. — May 17, 2017 — Cisco today reported third quarter results for the period ended April 29, 2017. Cisco reported third
quarter revenue of $11.9 billion, net income on a generally accepted accounting principles (GAAP) basis of $2.5 billion or $0.50 per share, and non-GAAP net income of $3.0 billion or $0.60 per
share.

[0001193125-17-173404:8k_2_02:14]
“I am pleased with the progress we are making on the multi-year transformation of our business,” said Chuck Robbins, CEO, Cisco.
“The Network is becoming even more critical to business success as our customers add billions of new connections to their enterprises. We are laser focused on delivering unparalleled value through highly secure, software-defined, automated and
intelligent infrastructure.”

[0001193125-17-173404:8k_2_02:15]
GAAP Results

[0001193125-17-173404:8k_2_02:16]
|  |  | Q3 FY2017 |  |  | Q3 FY2016 |  |  | Vs. Q3 FY2016 |  |
| Revenue |  | $ | 11.9 billion |  |  | $ | 12.0 billion |  |  |  | (1 | )% |
| Net Income |  | $ | 2.5 billion |  |  | $ | 2.3 billion |  |  |  | 7 | % |
| Diluted Earnings per Share (EPS) |  | $ | 0.50 |  |  | $ | 0.46 |  |  |  | 9 | % |

[0001193125-17-173404:8k_2_02:17]
Non-GAAP Results

[0001193125-17-173404:8k_2_02:18]
|  |  | Q3 FY2017 |  |  | Q3 FY2016 |  |  | Vs. Q3 FY2016 |  |
| Net Income |  | $ | 3.0 billion |  |  | $ | 2.9 billion |  |  |  | 5 | % |
| EPS |  | $ | 0.60 |  |  | $ | 0.57 |  |  |  | 5 | % |

[0001193125-17-173404:8k_2_02:19]
The third quarter of fiscal 2017 had 13 weeks compared with 14 weeks in the third quarter of fiscal 2016.

[0001193125-17-173404:8k_2_02:20]
Reconciliations between net income, EPS and other measures on a GAAP and non-GAAP basis are provided in the tables
located in the section entitled “Reconciliations of GAAP to non-GAAP Measures.”

[0001193125-17-173404:8k_2_02:21]
“We executed well
in Q3, delivering $11.9 billion in total revenue, while driving solid profitability and cash generation as we deliver on our strategic priorities,” said Kelly Kramer, CFO, Cisco. “We will continue to invest in growth areas as we move the
business toward more software and recurring revenue and return value to shareholders.”

[0001193125-17-173404:8k_2_02:22]
1

[0001193125-17-173404:8k_2_02:23]
Financial Summary

[0001193125-17-173404:8k_2_02:24]
All comparative percentages are on a year-over-year basis unless otherwise noted.

[0001193125-17-173404:8k_2_02:25]
Q3 FY 2017 Highlights

[0001193125-17-173404:8k_2_02:26]
Revenue — Total
revenue was $11.9 billion, down 1%, with product revenue flat and service revenue down 2%. 31% of total revenue was from recurring offers, up from 29% for the third quarter of fiscal 2016. Revenue by geographic segment was: Americas flat, EMEA
flat, and APJC down 2%. Product revenue performance was led by Wireless and Security, which increased by 13% and 9%, respectively. Switching revenue increased by 2%. NGN Routing, Collaboration, Data Center, and Service Provider Video revenue
decreased by 2%, 4%, 5%, and 30%, respectively.

[0001193125-17-173404:8k_2_02:27]
Gross Margin — On a GAAP basis, total gross margin and product gross margin
were 63.0% and 61.7%, respectively. The decrease in the product gross margin compared with 63.8% in the third quarter of fiscal 2016 was primarily due to pricing, a supplier component remediation adjustment in the third quarter of fiscal 2016, and
product mix, partially offset by continued productivity improvements.

[0001193125-17-173404:8k_2_02:28]
Non-GAAP total gross margin and product
gross margin were 64.4% and 63.2%, respectively. The decrease in non-GAAP product gross margin compared with 64.5% in the third quarter of fiscal 2016 was primarily due to pricing and product mix, partially
offset by continued productivity improvements.

[0001193125-17-173404:8k_2_02:29]
GAAP service gross margin was 66.7% and non-GAAP service gross
margin was 67.8%.

[0001193125-17-173404:8k_2_02:30]
Total gross margins by geographic segment were: 64.6% for the Americas, 65.5% for EMEA and 61.8% for APJC.

[0001193125-17-173404:8k_2_02:31]
Operating Expenses — On a GAAP basis, operating expenses were $4.3 billion, down 8%.
Non-GAAP operating expenses were $3.8 billion, down 9%, and were 32.1% of revenue.

[0001193125-17-173404:8k_2_02:32]
Operating Income
— GAAP operating income was $3.2 billion, up 6%, with GAAP operating margin of 26.5%. Non-GAAP operating income was $3.9 billion, up 7%, with
non-GAAP operating margin at 32.3%.

[0001193125-17-173404:8k_2_02:33]
Provision for Income Taxes — The GAAP tax provision rate
was 21.2%. The non-GAAP tax provision rate was 22.0%.

[0001193125-17-173404:8k_2_02:34]
Net Income and EPS — On a GAAP basis,
net income was $2.5 billion and EPS was $0.50. On a non-GAAP basis, net income was $3.0 billion, an increase of 5%, and EPS was $0.60, an increase of 5%.

[0001193125-17-173404:8k_2_02:35]
Cash Flow from Operating Activities — was $3.4 billion, an increase of 10% compared with $3.1 billion for the third quarter of
fiscal 2016.

[0001193125-17-173404:8k_2_02:36]
Balance Sheet and Other Financial Highlights

[0001193125-17-173404:8k_2_02:37]
Cash and Cash Equivalents and Investments — were $68.0 billion at the end of the third quarter of fiscal 2017, compared with
$71.8 billion at the end of the second quarter of fiscal 2017, and compared with $65.8 billion at the end of fiscal 2016. The total cash and cash equivalents and investments available in the United States at the end of the third quarter of
fiscal 2017 were $2.9 billion.

[0001193125-17-173404:8k_2_02:38]
Deferred Revenue — was $17.3 billion, up 13% in total, with deferred product revenue up 26%,
driven largely by subscription-based and software offerings. Deferred service revenue was up 7%. The portion of product deferred revenue related to recurring software and subscription businesses grew 57% which includes the acquisition during the
third quarter of fiscal 2017 of AppDynamics. Excluding AppDynamics, the increase was 51%.

[0001193125-17-173404:8k_2_02:39]
Capital Allocation — In the third quarter of
fiscal 2017, Cisco declared and paid a cash dividend of $0.29 per common share, or $1.5 billion. For the third quarter of fiscal 2017, Cisco repurchased approximately 15 million shares of common stock under its stock repurchase program at
an average price of $33.71 per share for an aggregate purchase price of $0.5 billion.

[0001193125-17-173404:8k_2_02:40]
As of April 29, 2017, Cisco had repurchased and retired
4.7 billion shares of Cisco common stock at an average price of $21.21 per share for an aggregate purchase price of approximately $99.1 billion since the inception of the stock repurchase program. The remaining authorized amount for stock
repurchases under this program is approximately $12.9 billion with no termination date.

[0001193125-17-173404:8k_2_02:41]
Acquisitions

[0001193125-17-173404:8k_2_02:42]
In the third quarter of fiscal 2017, Cisco completed its acquisition of AppDynamics, Inc. The AppDynamics acquisition provides cloud application and business
monitoring platforms that are designed to enable companies to improve application and business performance.

[0001193125-17-173404:8k_2_02:43]
On May 1, 2017, Cisco announced its
intent to acquire Viptela, Inc., a privately held software-defined wide area network company. The acquisition is expected to close in the second half of calendar 2017.

[0001193125-17-173404:8k_2_02:44]
On May 4, 2017, Cisco announced its intent to acquire the Advanced Analytics team and associated advanced analytics intellectual property developed by
Saggezza, a privately held technology services company. The acquisition is expected to close in the fourth quarter of fiscal 2017.

[0001193125-17-173404:8k_2_02:45]
On May 11, 2017,
Cisco announced its intent to acquire MindMeld, Inc., a privately held artificial intelligence (AI) company. The acquisition is expected to close in the fourth quarter of fiscal 2017.

[0001193125-17-173404:8k_2_02:46]
Business Outlook for Q4 FY 2017

[0001193125-17-173404:8k_2_02:47]
Cisco expects to achieve
the following results for the fourth quarter of fiscal 2017:

[0001193125-17-173404:8k_2_02:48]
| Q4 FY 2017 |  |  |
| Revenue |  | (6)% to (4)% decline Y/Y |
| Non-GAAP gross margin rate |  | 63% - 64% |
| Non-GAAP operating margin rate |  | 29.5% - 30.5% |
| Non-GAAP tax provision rate |  | 22% |
| Non-GAAP EPS |  | $0.60 - $0.62 |

[0001193125-17-173404:8k_2_02:49]
Cisco estimates that GAAP EPS will be $0.46 to $0.51 which is lower than non-GAAP EPS
by $0.11 to $0.14 per share in the fourth quarter of fiscal 2017.

[0001193125-17-173404:8k_2_02:50]
A reconciliation between the Business Outlook for Q4 FY 2017 on a GAAP and non-GAAP basis is provided in the table entitled “GAAP to non-GAAP Business Outlook for Q4 FY 2017” located in the section entitled “Reconciliations of GAAP to non-GAAP Measures.”

[0001193125-17-173404:8k_2_02:51]
Editor’s Notes:

[0001193125-17-173404:8k_2_02:52]
|  | • |  | Q3 fiscal year 2017 conference call to discuss Cisco’s results along with its business outlook will be held on Wednesday, May 17, 2017 at 1:30 p.m. Pacific Time. Conference call number is 1-888-848-6507 (United States) or 1-212-519-0847 (international). |

[0001193125-17-173404:8k_2_02:53]
|  | • |  | Conference call replay will be available from 4:00 p.m. Pacific Time, May 17, 2017 to 4:00 p.m. Pacific Time, May 24, 2017 at 1-866-443-8010 (United States) or 1-203-369-1121 (international). The replay will also be available via webcast on the Cisco Investor Relations website at http://investor.cisco.com. |

[0001193125-17-173404:8k_2_02:54]
|  | • |  | Additional information regarding Cisco’s financials, as well as a webcast of the conference call with visuals designed to guide participants through the call, will be available at 1:30 p.m. Pacific Time, May 17, 2017. Text of the conference call’s prepared remarks will be available within 24 hours of completion of the call. The webcast will include both the prepared remarks and the question-and-answer session. This information, along with the GAAP to non-GAAP reconciliation information, will be available on the Cisco Investor Relations website at http://investor.cisco.com. |

[0001193125-17-173404:8k_2_02:55]
CISCO SYSTEMS, INC.

[0001193125-17-173404:8k_2_02:56]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-17-173404:8k_2_02:57]
(In millions, except per-share amounts)

[0001193125-17-173404:8k_2_02:58]
(Unaudited)

[0001193125-17-173404:8k_2_02:59]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | April 29,2017 |  |  | April 30,2016 |  |  | April 29,2017 |  |  | April 30,2016 |  |
| REVENUE: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 8,885 |  |  | $ | 8,875 |  |  | $ | 26,678 |  |  | $ | 27,702 |  |
| Service |  |  | 3,055 |  |  |  | 3,125 |  |  |  | 9,194 |  |  |  | 8,907 |  |
| Total revenue |  |  | 11,940 |  |  |  | 12,000 |  |  |  | 35,872 |  |  |  | 36,609 |  |
| COST OF SALES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 3,405 |  |  |  | 3,214 |  |  |  | 10,113 |  |  |  | 10,547 |  |
| Service |  |  | 1,017 |  |  |  | 1,065 |  |  |  | 3,081 |  |  |  | 3,077 |  |
| Total cost of sales |  |  | 4,422 |  |  |  | 4,279 |  |  |  | 13,194 |  |  |  | 13,624 |  |
| GROSS MARGIN |  |  | 7,518 |  |  |  | 7,721 |  |  |  | 22,678 |  |  |  | 22,985 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 1,507 |  |  |  | 1,626 |  |  |  | 4,560 |  |  |  | 4,695 |  |
| Sales and marketing |  |  | 2,226 |  |  |  | 2,447 |  |  |  | 6,866 |  |  |  | 7,176 |  |
| General and administrative |  |  | 487 |  |  |  | 566 |  |  |  | 1,498 |  |  |  | 1,281 |  |
| Amortization of purchased intangible assets |  |  | 59 |  |  |  | 81 |  |  |  | 201 |  |  |  | 221 |  |
| Restructuring and other charges |  |  | 70 |  |  |  | 17 |  |  |  | 614 |  |  |  | 255 |  |
| Total operating expenses |  |  | 4,349 |  |  |  | 4,737 |  |  |  | 13,739 |  |  |  | 13,628 |  |
| OPERATING INCOME |  |  | 3,169 |  |  |  | 2,984 |  |  |  | 8,939 |  |  |  | 9,357 |  |
| Interest income |  |  | 354 |  |  |  | 270 |  |  |  | 978 |  |  |  | 732 |  |
| Interest expense |  |  | (219 | ) |  |  | (175 | ) |  |  | (639 | ) |  |  | (496 | ) |
| Other income (loss), net |  |  | (113 | ) |  |  | 4 |  |  |  | (171 | ) |  |  | (67 | ) |
| Interest and other income (loss), net |  |  | 22 |  |  |  | 99 |  |  |  | 168 |  |  |  | 169 |  |
| INCOME BEFORE PROVISION FOR INCOME TAXES |  |  | 3,191 |  |  |  | 3,083 |  |  |  | 9,107 |  |  |  | 9,526 |  |
| Provision for income taxes |  |  | 676 |  |  |  | 734 |  |  |  | 1,922 |  |  |  | 1,600 |  |
| NET INCOME |  | $ | 2,515 |  |  | $ | 2,349 |  |  | $ | 7,185 |  |  | $ | 7,926 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.50 |  |  | $ | 0.47 |  |  | $ | 1.43 |  |  | $ | 1.57 |  |
| Diluted |  | $ | 0.50 |  |  | $ | 0.46 |  |  | $ | 1.42 |  |  | $ | 1.56 |  |
| Shares used in per-share calculation: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 5,005 |  |  |  | 5,032 |  |  |  | 5,015 |  |  |  | 5,060 |  |
| Diluted |  |  | 5,045 |  |  |  | 5,065 |  |  |  | 5,056 |  |  |  | 5,095 |  |
| Cash dividends declared per common share |  | $ | 0.29 |  |  | $ | 0.26 |  |  | $ | 0.81 |  |  | $ | 0.68 |  |

[0001193125-17-173404:8k_2_02:60]
4

[0001193125-17-173404:8k_2_02:61]
CISCO SYSTEMS, INC.

[0001193125-17-173404:8k_2_02:62]
REVENUE BY SEGMENT

[0001193125-17-173404:8k_2_02:63]
(In
millions, except percentages)

[0001193125-17-173404:8k_2_02:64]
|  |  | April 29, 2017 |  |
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  |  |  |  |  |  |  |  |  |  | Excluding SPVideo CPEBusiness |  |  | Including SPVideo CPEBusiness |  |
|  |  | Amount |  |  | Y/Y% |  |  | Amount |  |  | Y/Y% |  |  | Y/Y% |  |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 7,046 |  |  |  | — % |  |  | $ | 21,149 |  |  |  | (1)% |  |  |  | (3)% |  |
| EMEA |  |  | 2,999 |  |  |  | — % |  |  |  | 9,077 |  |  |  | — % |  |  |  | (1)% |  |
| APJC |  |  | 1,895 |  |  |  | (2)% |  |  |  | 5,646 |  |  |  | — % |  |  |  | — % |  |
| Total |  | $ | 11,940 |  |  |  | (1)% |  |  | $ | 35,872 |  |  |  | (1)% |  |  |  | (2)% |  |

[0001193125-17-173404:8k_2_02:65]
During the second quarter of fiscal 2016 on November 20, 2015, Cisco completed its divestiture of the SP Video CPE
Business. SP Video CPE Business revenue for the nine months ended April 30, 2016 was $504 million.

[0001193125-17-173404:8k_2_02:66]
CISCO SYSTEMS, INC.

[0001193125-17-173404:8k_2_02:67]
GROSS MARGIN PERCENTAGE BY SEGMENT

[0001193125-17-173404:8k_2_02:68]
(In percentages)

[0001193125-17-173404:8k_2_02:69]
|  |  | April 29, 2017 |  |
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
| Gross Margin Percentage: |  |  |  |  |  |  |  |  |
| Americas |  |  | 64.6% |  |  |  | 64.6% |  |
| EMEA |  |  | 65.5% |  |  |  | 66.0% |  |
| APJC |  |  | 61.8% |  |  |  | 61.9% |  |

[0001193125-17-173404:8k_2_02:70]
5

[0001193125-17-173404:8k_2_02:71]
CISCO SYSTEMS, INC.

[0001193125-17-173404:8k_2_02:72]
REVENUE FOR GROUPS OF SIMILAR PRODUCTS AND SERVICES

[0001193125-17-173404:8k_2_02:73]
(In millions, except percentages)

[0001193125-17-173404:8k_2_02:74]
|  |  | April 29, 2017 |  |
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | Amount |  |  | Y/Y% |  |  | Amount |  |  | Y/Y%(1) |  |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Switching |  | $ | 3,489 |  |  |  | 2% |  |  | $ | 10,510 |  |  |  | (4)% |  |
| NGN Routing |  |  | 2,032 |  |  |  | (2)% |  |  |  | 5,938 |  |  |  | (2)% |  |
| Collaboration |  |  | 1,022 |  |  |  | (4)% |  |  |  | 3,165 |  |  |  | (1)% |  |
| Data Center |  |  | 767 |  |  |  | (5)% |  |  |  | 2,391 |  |  |  | (4)% |  |
| Wireless |  |  | 703 |  |  |  | 13% |  |  |  | 1,967 |  |  |  | 5% |  |
| Security |  |  | 527 |  |  |  | 9% |  |  |  | 1,595 |  |  |  | 12% |  |
| Service Provider Video |  |  | 207 |  |  |  | (30)% |  |  |  | 719 |  |  |  | (26)% |  |
| Other |  |  | 138 |  |  |  | 57% |  |  |  | 393 |  |  |  | 65% |  |
| Product |  |  | 8,885 |  |  |  | — % |  |  |  | 26,678 |  |  |  | (2)% |  |
| Service |  |  | 3,055 |  |  |  | (2)% |  |  |  | 9,194 |  |  |  | 3% |  |
| Total |  | $ | 11,940 |  |  |  | (1)% |  |  | $ | 35,872 |  |  |  | (1)% |  |

[0001193125-17-173404:8k_2_02:75]
(1) During the second quarter of fiscal 2016 on November 20, 2015,
Cisco completed its divestiture of the SP Video CPE Business. SP Video CPE Business revenue for the nine months ended April 30, 2016 was $504 million.

[0001193125-17-173404:8k_2_02:76]
6

[0001193125-17-173404:8k_2_02:77]
CISCO SYSTEMS, INC.

[0001193125-17-173404:8k_2_02:78]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001193125-17-173404:8k_2_02:79]
(In millions)

[0001193125-17-173404:8k_2_02:80]
(Unaudited)

[0001193125-17-173404:8k_2_02:81]
|  |  | April 29,2017 |  |  | July 30,2016 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 8,116 |  |  | $ | 7,631 |  |
| Investments |  |  | 59,858 |  |  |  | 58,125 |  |
| Accounts receivable, net of allowance for doubtful accounts of $213 at April 29, 2017 and $249 at July 30, 2016 |  |  | 4,635 |  |  |  | 5,847 |  |
| Inventories |  |  | 1,366 |  |  |  | 1,217 |  |
| Financing receivables, net |  |  | 4,639 |  |  |  | 4,272 |  |
| Other current assets |  |  | 1,348 |  |  |  | 1,627 |  |
| Total current assets |  |  | 79,962 |  |  |  | 78,719 |  |
| Property and equipment, net |  |  | 3,395 |  |  |  | 3,506 |  |
| Financing receivables, net |  |  | 4,568 |  |  |  | 4,158 |  |
| Goodwill |  |  | 29,516 |  |  |  | 26,625 |  |
| Purchased intangible assets, net |  |  | 2,704 |  |  |  | 2,501 |  |
| Deferred tax assets |  |  | 4,351 |  |  |  | 4,299 |  |
| Other assets |  |  | 1,454 |  |  |  | 1,844 |  |
| TOTAL ASSETS |  | $ | 125,950 |  |  | $ | 121,652 |  |
| LIABILITIES AND EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 4,248 |  |  | $ | 4,160 |  |
| Accounts payable |  |  | 1,219 |  |  |  | 1,056 |  |
| Income taxes payable |  |  | 20 |  |  |  | 517 |  |
| Accrued compensation |  |  | 2,825 |  |  |  | 2,951 |  |
| Deferred revenue |  |  | 10,344 |  |  |  | 10,155 |  |
| Other current liabilities |  |  | 4,062 |  |  |  | 6,072 |  |
| Total current liabilities |  |  | 22,718 |  |  |  | 24,911 |  |
| Long-term debt |  |  | 28,222 |  |  |  | 24,483 |  |
| Income taxes payable |  |  | 1,168 |  |  |  | 925 |  |
| Deferred revenue |  |  | 6,978 |  |  |  | 6,317 |  |
| Other long-term liabilities |  |  | 1,482 |  |  |  | 1,431 |  |
| Total liabilities |  |  | 60,568 |  |  |  | 58,067 |  |
| Total equity |  |  | 65,382 |  |  |  | 63,585 |  |
| TOTAL LIABILITIES AND EQUITY |  | $ | 125,950 |  |  | $ | 121,652 |  |

[0001193125-17-173404:8k_2_02:82]
7

[0001193125-17-173404:8k_2_02:83]
CISCO SYSTEMS, INC.

[0001193125-17-173404:8k_2_02:84]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-17-173404:8k_2_02:85]
(In millions)

[0001193125-17-173404:8k_2_02:86]
(Unaudited)

[0001193125-17-173404:8k_2_02:87]
|  |  | Nine Months Ended |  |
|  |  | April 29,2017 |  |  | April 30,2016 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 7,185 |  |  | $ | 7,926 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation, amortization, and other |  |  | 1,708 |  |  |  | 1,546 |  |
| Share-based compensation expense |  |  | 1,124 |  |  |  | 1,101 |  |
| Provision for receivables |  |  | 20 |  |  |  | (27 | ) |
| Deferred income taxes |  |  | (125 | ) |  |  | 229 |  |
| Excess tax benefits from share-based compensation |  |  | (125 | ) |  |  | (103 | ) |
| (Gains) losses on divestitures, investments and other, net |  |  | 156 |  |  |  | (279 | ) |
| Change in operating assets and liabilities, net of effects of acquisitions and divestitures: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 1,253 |  |  |  | 1,412 |  |
| Inventories |  |  | (149 | ) |  |  | 189 |  |
| Financing receivables |  |  | (773 | ) |  |  | (296 | ) |
| Other assets |  |  | 140 |  |  |  | (94 | ) |
| Accounts payable |  |  | 149 |  |  |  | (114 | ) |
| Income taxes, net |  |  | (112 | ) |  |  | (723 | ) |
| Accrued compensation |  |  | (154 | ) |  |  | (318 | ) |
| Deferred revenue |  |  | 592 |  |  |  | 7 |  |
| Other liabilities |  |  | (1,014 | ) |  |  | (704 | ) |
| Net cash provided by operating activities |  |  | 9,875 |  |  |  | 9,752 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of investments |  |  | (35,562 | ) |  |  | (36,366 | ) |
| Proceeds from sales of investments |  |  | 24,414 |  |  |  | 23,806 |  |
| Proceeds from maturities of investments |  |  | 8,390 |  |  |  | 11,790 |  |
| Acquisition of businesses, net of cash and cash equivalents acquired |  |  | (3,211 | ) |  |  | (3,161 | ) |
| Proceeds from business divestiture |  |  | — |  |  |  | 372 |  |
| Purchases of investments in privately held companies |  |  | (172 | ) |  |  | (202 | ) |
| Return of investments in privately held companies |  |  | 168 |  |  |  | 74 |  |
| Acquisition of property and equipment |  |  | (756 | ) |  |  | (880 | ) |
| Proceeds from sales of property and equipment |  |  | 6 |  |  |  | 11 |  |
| Other |  |  | 35 |  |  |  | (195 | ) |
| Net cash used in investing activities |  |  | (6,688 | ) |  |  | (4,751 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Issuances of common stock |  |  | 418 |  |  |  | 771 |  |
| Repurchases of common stock—repurchase program |  |  | (2,516 | ) |  |  | (3,154 | ) |
| Shares repurchased for tax withholdings on vesting of restricted stock units |  |  | (497 | ) |  |  | (469 | ) |
| Short-term borrowings, original maturities less than 90 days, net |  |  | 2,000 |  |  |  | (4 | ) |
| Issuances of debt |  |  | 6,232 |  |  |  | 6,978 |  |
| Repayments of debt |  |  | (4,151 | ) |  |  | (3,863 | ) |
| Excess tax benefits from share-based compensation |  |  | 125 |  |  |  | 103 |  |
| Dividends paid |  |  | (4,063 | ) |  |  | (3,441 | ) |
| Other |  |  | (250 | ) |  |  | 96 |  |
| Net cash used in financing activities |  |  | (2,702 | ) |  |  | (2,983 | ) |
| Net increase in cash and cash equivalents |  |  | 485 |  |  |  | 2,018 |  |
| Cash and cash equivalents, beginning of period |  |  | 7,631 |  |  |  | 6,877 |  |
| Cash and cash equivalents, end of period |  | $ | 8,116 |  |  | $ | 8,895 |  |
| Supplemental cash flow information: |  |  |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 727 |  |  | $ | 691 |  |
| Cash paid for income taxes, net |  | $ | 2,159 |  |  | $ | 2,093 |  |

[0001193125-17-173404:8k_2_02:88]
8

[0001193125-17-173404:8k_2_02:89]
CISCO SYSTEMS, INC.

[0001193125-17-173404:8k_2_02:90]
DEFERRED REVENUE

[0001193125-17-173404:8k_2_02:91]
(In
millions)

[0001193125-17-173404:8k_2_02:92]
|  |  | April 29,2017 |  |  | January 28,2017 |  |  | April 30,2016 |  |
| Deferred revenue: |  |  |  |  |  |  |  |  |  |  |  |  |
| Service |  | $ | 10,532 |  |  | $ | 10,525 |  |  | $ | 9,866 |  |
| Product: |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred revenue related to recurring software and subscription businesses |  |  | 4,352 |  |  |  | 3,997 |  |  |  | 2,771 |  |
| Deferred revenue related to two-tier distributors |  |  | 311 |  |  |  | 401 |  |  |  | 419 |  |
| Other product deferred revenue |  |  | 2,127 |  |  |  | 2,163 |  |  |  | 2,216 |  |
| Total product deferred revenue |  |  | 6,790 |  |  |  | 6,561 |  |  |  | 5,406 |  |
| Total |  | $ | 17,322 |  |  | $ | 17,086 |  |  | $ | 15,272 |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |  |
| Current |  | $ | 10,344 |  |  | $ | 10,243 |  |  | $ | 9,662 |  |
| Noncurrent |  |  | 6,978 |  |  |  | 6,843 |  |  |  | 5,610 |  |
| Total |  | $ | 17,322 |  |  | $ | 17,086 |  |  | $ | 15,272 |  |

[0001193125-17-173404:8k_2_02:93]
CISCO SYSTEMS, INC.

[0001193125-17-173404:8k_2_02:94]
DIVIDENDS PAID AND REPURCHASES OF COMMON STOCK

[0001193125-17-173404:8k_2_02:95]
(In millions, except per-share amounts)

[0001193125-17-173404:8k_2_02:96]
|  |  | DIVIDENDS |  |  | STOCK REPURCHASE PROGRAM |  |  | TOTAL |  |
| Quarter Ended |  | Per Share |  |  | Amount |  |  | Shares |  |  | Weighted-Average Priceper Share |  |  | Amount |  |  | Amount |  |
| Fiscal 2017 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| April 29, 2017 |  | $ | 0.29 |  |  | $ | 1,451 |  |  |  | 15 |  |  | $ | 33.71 |  |  | $ | 503 |  |  | $ | 1,954 |  |
| January 28, 2017 |  |  | 0.26 |  |  |  | 1,304 |  |  |  | 33 |  |  |  | 30.33 |  |  |  | 1,001 |  |  |  | 2,305 |  |
| October 29, 2016 |  |  | 0.26 |  |  |  | 1,308 |  |  |  | 32 |  |  |  | 31.12 |  |  |  | 1,001 |  |  |  | 2,309 |  |
| Total |  | $ | 0.81 |  |  | $ | 4,063 |  |  |  | 80 |  |  | $ | 31.27 |  |  | $ | 2,505 |  |  | $ | 6,568 |  |
| Fiscal 2016 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| July 30, 2016 |  | $ | 0.26 |  |  | $ | 1,309 |  |  |  | 28 |  |  | $ | 28.70 |  |  | $ | 800 |  |  | $ | 2,109 |  |
| April 30, 2016 |  |  | 0.26 |  |  |  | 1,308 |  |  |  | 27 |  |  |  | 24.08 |  |  |  | 649 |  |  |  | 1,957 |  |
| January 23, 2016 |  |  | 0.21 |  |  |  | 1,065 |  |  |  | 48 |  |  |  | 26.12 |  |  |  | 1,262 |  |  |  | 2,327 |  |
| October 24, 2015 |  |  | 0.21 |  |  |  | 1,068 |  |  |  | 45 |  |  |  | 26.83 |  |  |  | 1,207 |  |  |  | 2,275 |  |
| Total |  | $ | 0.94 |  |  | $ | 4,750 |  |  |  | 148 |  |  | $ | 26.45 |  |  | $ | 3,918 |  |  | $ | 8,668 |  |

[0001193125-17-173404:8k_2_02:97]
9

[0001193125-17-173404:8k_2_02:98]
CISCO SYSTEMS, INC.

[0001193125-17-173404:8k_2_02:99]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-17-173404:8k_2_02:100]
GAAP TO NON-GAAP NET INCOME

[0001193125-17-173404:8k_2_02:101]
(In millions, except per-share amounts)

[0001193125-17-173404:8k_2_02:102]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | April 29,2017 |  |  | April 30,2016 |  |  | April 29,2017 |  |  | April 30,2016 |  |
| GAAP net income |  | $ | 2,515 |  |  | $ | 2,349 |  |  | $ | 7,185 |  |  | $ | 7,926 |  |
| Adjustments to cost of sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 56 |  |  |  | 58 |  |  |  | 163 |  |  |  | 160 |  |
| Amortization of acquisition-related intangible assets |  |  | 124 |  |  |  | 115 |  |  |  | 343 |  |  |  | 366 |  |
| Supplier component remediation charge (adjustment), net |  |  | (13 | ) |  |  | (74 | ) |  |  | (29 | ) |  |  | (74 | ) |
| Acquisition-related/divestiture costs |  |  | — |  |  |  | — |  |  |  | 1 |  |  |  | 1 |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (2 | ) |
| Total adjustments to GAAP cost of sales |  |  | 167 |  |  |  | 99 |  |  |  | 478 |  |  |  | 451 |  |
| Adjustments to operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 349 |  |  |  | 337 |  |  |  | 963 |  |  |  | 927 |  |
| Amortization of acquisition-related intangible assets |  |  | 59 |  |  |  | 81 |  |  |  | 201 |  |  |  | 221 |  |
| Acquisition-related/divestiture costs (1) |  |  | 43 |  |  |  | 76 |  |  |  | 157 |  |  |  | (55 | ) |
| Significant asset impairments and restructurings |  |  | 70 |  |  |  | 17 |  |  |  | 614 |  |  |  | 255 |  |
| Total adjustments to GAAP operating expenses |  |  | 521 |  |  |  | 511 |  |  |  | 1,935 |  |  |  | 1,348 |  |
| Total adjustments to GAAP income before provision for income taxes |  |  | 688 |  |  |  | 610 |  |  |  | 2,413 |  |  |  | 1,799 |  |
| Income tax effect of non-GAAP adjustments |  |  | (177 | ) |  |  | (133 | ) |  |  | (612 | ) |  |  | (427 | ) |
| Significant tax matters (2) |  |  | — |  |  |  | 54 |  |  |  | — |  |  |  | (465 | ) |
| Total adjustments to GAAP provision for income taxes |  |  | (177 | ) |  |  | (79 | ) |  |  | (612 | ) |  |  | (892 | ) |
| Non-GAAP net income |  | $ | 3,026 |  |  | $ | 2,880 |  |  | $ | 8,986 |  |  | $ | 8,833 |  |
| Diluted net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | $ | 0.50 |  |  | $ | 0.46 |  |  | $ | 1.42 |  |  | $ | 1.56 |  |
| Non-GAAP |  | $ | 0.60 |  |  | $ | 0.57 |  |  | $ | 1.78 |  |  | $ | 1.73 |  |

[0001193125-17-173404:8k_2_02:103]
(1) During the second quarter of fiscal 2016 on November 20, 2015,
Cisco completed its divestiture of the SP Video CPE Business. This sale resulted in a pre-tax gain of $285 million, net of certain transaction costs incurred. The gain on this transaction was excluded
from non-GAAP net income for the first nine months of fiscal 2016.

[0001193125-17-173404:8k_2_02:104]
(2) Cisco recorded certain net tax benefits totaling $465 million related to prior-year periods that
were excluded from non-GAAP net income for the first nine months of fiscal 2016.

[0001193125-17-173404:8k_2_02:105]
10

[0001193125-17-173404:8k_2_02:106]
CISCO SYSTEMS, INC.

[0001193125-17-173404:8k_2_02:107]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-17-173404:8k_2_02:108]
EFFECTIVE TAX RATE

[0001193125-17-173404:8k_2_02:109]
(In
percentages)

[0001193125-17-173404:8k_2_02:110]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | April 29,2017 |  |  | April 30,2016 |  |  | April 29,2017 |  |  | April 30,2016 |  |
| GAAP effective tax rate |  |  | 21.2 | % |  |  | 23.8 | % |  |  | 21.1 | % |  |  | 16.8 | % |
| Total adjustments to GAAP provision for income taxes |  |  | 0.8 | % |  |  | (1.8 | )% |  |  | 0.9 | % |  |  | 5.2 | % |
| Non-GAAP effective tax rate |  |  | 22.0 | % |  |  | 22.0 | % |  |  | 22.0 | % |  |  | 22.0 | % |

[0001193125-17-173404:8k_2_02:111]
GAAP TO NON-GAAP BUSINESS OUTLOOK FOR Q4 FY 2017

[0001193125-17-173404:8k_2_02:112]
| Q4 FY 2017 |  | Gross MarginRate |  | Operating MarginRate |  | Tax ProvisionRate |  | Earnings perShare (2) |
| GAAP |  | 61.5% - 62.5% |  | 22.5% - 23.5% |  | 21% |  | $0.46 to $0.51 |
| Estimated adjustments for: |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  | 0.5% |  | 3.5% |  | — |  | $0.05 - $0.06 |
| Amortization of purchased intangible assets and other acquisition-related/divestiture costs |  | 1.0% |  | 2.0% |  | — |  | $0.03 - $0.04 |
| Restructuring and other charges (1) |  | — |  | 1.5% |  | — |  | $0.03 - $0.04 |
| Income tax effect of non-GAAP adjustments |  | — |  | — |  | 1% |  |  |
| Non-GAAP |  | 63% - 64% |  | 29.5% - 30.5% |  | 22% |  | $0.60 - $0.62 |

[0001193125-17-173404:8k_2_02:113]
(1) In August 2016, we announced a restructuring plan in order to
reinvest in our key priority areas in which up to 5,500 employees would be impacted, with estimated pretax charges of approximately $700 million. In May 2017, we extended the restructuring plan to include an additional 1,100 employees with
$150 million of estimated additional pretax charges. During the first nine months of fiscal 2017, we have recognized pretax charges of $614 million to our GAAP financial results in relation to this restructuring plan. We expect to
recognize approximately $150 million to $200 million of pretax charges under this plan in the fourth quarter of fiscal 2017. We expect this plan to be substantially completed by the end of the first quarter of fiscal 2018.

[0001193125-17-173404:8k_2_02:114]
(2) Estimated adjustments to GAAP earnings per share are shown after income tax effects.

[0001193125-17-173404:8k_2_02:115]
Except as noted above, this business outlook does not include the effects of any future acquisitions/divestitures, asset impairments, restructurings and
significant tax matters or other events, which may or may not be significant unless specifically stated.

[0001193125-17-173404:8k_2_02:116]
11

[0001193125-17-173404:8k_2_02:117]
Forward Looking Statements, Non-GAAP Information and Additional
Information

[0001193125-17-173404:8k_2_02:118]
This release includes non-GAAP net income, non-GAAP gross margins, non-GAAP operating expenses, non-GAAP operating income and margin, non-GAAP effective tax rates, and
non-GAAP net income per share data for the periods presented. It also includes future estimated ranges for gross margin, operating margin, tax provision rate and EPS on a
non-GAAP basis.

[0001193125-17-173404:8k_2_02:119]
These non-GAAP measures are not in accordance with, or an
alternative for, measures prepared in accordance with generally accepted accounting principles and may be different from non-GAAP measures used by other companies. In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles. Cisco believes that non-GAAP measures have limitations in that they do not reflect
all of the amounts associated with Cisco’s results of operations as determined in accordance with GAAP and that these measures should only be used to evaluate Cisco’s results of operations in conjunction with the corresponding GAAP
measures.

[0001193125-17-173404:8k_2_02:120]
Cisco believes that the presentation of non-GAAP measures when shown in conjunction with the
corresponding GAAP measures, provides useful information to investors and management regarding financial and business trends relating to its financial condition and its historical and projected results of operations.

[0001193125-17-173404:8k_2_02:121]
For its internal budgeting process, Cisco’s management uses financial statements that do not include, when applicable, share-based compensation expense,
amortization of acquisition-related intangible assets, acquisition-related/divestiture costs, significant asset impairments and restructurings, significant litigation and other contingencies, significant gains and losses on investments, the income
tax effects of the foregoing and significant tax matters. Cisco’s management also uses the foregoing non-GAAP measures, in addition to the corresponding GAAP measures, in reviewing the financial results
of Cisco. In prior periods, Cisco has excluded other items that it no longer excludes for purposes of its non-GAAP financial measures. From time to time in the future there may be other items that Cisco may
exclude for purposes of its internal budgeting process and in reviewing its financial results. For additional information on the items excluded by Cisco from one or more of its non-GAAP financial measures,
refer to the Form 8-K regarding this release furnished today to the Securities and Exchange Commission.

[0001193125-17-173404:8k_2_02:122]
12

[0001193125-17-173404:8k_2_02:123]
Cisco divested the Customer Premises Equipment portion of the Service Provider Video Connected Devices business
(“SP Video CPE Business”) during the second quarter of fiscal 2016 on November 20, 2015. This release includes, where indicated, financial measures that exclude the SP Video CPE Business. Cisco believes that the presentation of these
measures provides useful information to investors and management regarding financial and business trends relating to its financial condition and its historical and projected results of operations because the SP Video CPE Business is no longer part
of Cisco and will not be part of Cisco on a go forward basis. Cisco’s management also uses the financial measures excluding the SP Video CPE Business in reviewing the financial results of Cisco.

[0001193125-17-173404:8k_2_02:124]
About Cisco

[0001193125-17-173404:8k_2_02:125]
Cisco (NASDAQ: CSCO) is the worldwide
technology leader that has been making the Internet work since 1984. Our people, products and partners help society securely connect and seize tomorrow’s digital opportunity today. Discover more at thenetwork.cisco.com and follow us on Twitter
at @Cisco.

[0001193125-17-173404:8k_2_02:126]
Copyright © 2017 Cisco and/or its affiliates. All rights reserved. Cisco and the
Cisco logo are trademarks or registered trademarks of Cisco and/or its affiliates in the U.S. and other countries. To view a list of Cisco trademarks, go to: www.cisco.com/go/trademarks. Third-party trademarks mentioned in this document are the
property of their respective owners. The use of the word partner does not imply a partnership relationship between Cisco and any other company. This document is Cisco Public Information.
