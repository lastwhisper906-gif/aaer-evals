# CSCO notes — 0000858877-23-000013


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000858877-23-000013:notes:1]
[same as prior period, unchanged from 0000858877-23-000005:notes:1]

[0000858877-23-000013:notes:2]
We have prepared the accompanying financial data as of April 29, 2023 and for the third quarter and first nine months of fiscal 2023 and 2022, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (SEC). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (GAAP) have been condensed or omitted pursuant to such rules and regulations. The July 30, 2022 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, we believe that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in our Annual Report on Form 10-K for the fiscal year ended July 30, 2022.

[0000858877-23-000013:notes:3]
In the opinion of management, all normal recurring adjustments necessary to state fairly the consolidated balance sheet as of April 29, 2023, the results of operations, the statements of comprehensive income and the statements of equity for the third quarter and first nine months of fiscal 2023 and 2022, and the statements of cash flows for the first nine months of fiscal 2023 and 2022, as applicable, have been made. The results of operations for the third quarter and first nine months of fiscal 2023 are not necessarily indicative of the operating results for the full fiscal year or any future periods.

[0000858877-23-000013:notes:4]
Our consolidated financial statements include our accounts and investments consolidated under the voting interest model. The noncontrolling interests attributed to these investments are not presented as a separate component in the equity section of the Consolidated Balance Sheets as these amounts are not material for any of the fiscal periods presented. The share of earnings attributable to the noncontrolling interests are not presented separately in the Consolidated Statements of Operations as these amounts are not material for any of the fiscal periods presented.

[0000858877-23-000013:notes:5]
Certain reclassifications have been made to the amounts in prior periods in order to conform to the current period’s presentation. We have evaluated subsequent events through the date that the financial statements were issued.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000858877-23-000013:notes:6]
[same as prior period, unchanged from 0000858877-23-000005:notes:6]

[0000858877-23-000013:notes:7]
[same as prior period, unchanged from 0000858877-23-000005:notes:7]


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000858877-23-000013:notes:8]
[same as prior period, unchanged from 0000858877-23-000005:notes:8]

[0000858877-23-000013:notes:9]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of April 29, 2023 and July 30, 2022 was $38 million and $43 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.

[0000858877-23-000013:notes:10]
[same as prior period, unchanged from 0000858877-23-000005:notes:10]

[0000858877-23-000013:notes:11]
[same as prior period, unchanged from 0000858877-23-000005:notes:11]

[0000858877-23-000013:notes:12]
[same as prior period, unchanged from 0000858877-23-000005:notes:12]

[0000858877-23-000013:notes:13]
[same as prior period, unchanged from 0000858877-23-000005:notes:13]

[0000858877-23-000013:notes:14]
[same as prior period, unchanged from 0000858877-23-000005:notes:14]

[0000858877-23-000013:notes:15]
[same as prior period, unchanged from 0000858877-23-000005:notes:15]

[0000858877-23-000013:notes:16]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 29,2023 |  | April 30,2022 |  | April 29, 2023 |  | April 30, 2022 |
| Product revenue: |  |  |  |  |  |  |  |
| Secure, Agile Networks | $ | 7,550 |  |  | $ | 5,870 |  |  | $ | 20,980 |  |  | $ | 17,737 |  |
| Internet for the Future | 1,392 |  |  | 1,324 |  |  | 4,007 |  |  | 4,019 |  |
| Collaboration | 985 |  |  | 1,132 |  |  | 3,029 |  |  | 3,308 |  |
| End-to-End Security | 958 |  |  | 938 |  |  | 2,872 |  |  | 2,716 |  |
| Optimized Application Experiences | 204 |  |  | 183 |  |  | 597 |  |  | 544 |  |
| Other Products | 3 |  |  | 2 |  |  | 7 |  |  | 7 |  |
| Total Product | 11,092 |  |  | 9,448 |  |  | 31,492 |  |  | 28,330 |  |
| Services | 3,479 |  |  | 3,387 |  |  | 10,303 |  |  | 10,125 |  |
| Total | $ | 14,571 |  |  | $ | 12,835 |  |  | $ | 41,795 |  |  | $ | 38,455 |  |

[0000858877-23-000013:notes:17]
[same as prior period, unchanged from 0000858877-23-000005:notes:17]

[0000858877-23-000013:notes:18]
[same as prior period, unchanged from 0000858877-23-000005:notes:18]

[0000858877-23-000013:notes:19]
[same as prior period, unchanged from 0000858877-23-000005:notes:19]

[0000858877-23-000013:notes:20]
[same as prior period, unchanged from 0000858877-23-000005:notes:20]

[0000858877-23-000013:notes:21]
[same as prior period, unchanged from 0000858877-23-000005:notes:21]

[0000858877-23-000013:notes:22]
[same as prior period, unchanged from 0000858877-23-000005:notes:22]

[0000858877-23-000013:notes:23]
[same as prior period, unchanged from 0000858877-23-000005:notes:23]

[0000858877-23-000013:notes:24]
[same as prior period, unchanged from 0000858877-23-000005:notes:24]

[0000858877-23-000013:notes:25]
[same as prior period, unchanged from 0000858877-23-000005:notes:25]

[0000858877-23-000013:notes:26]
[same as prior period, unchanged from 0000858877-23-000005:notes:26]

[0000858877-23-000013:notes:27]
Accounts receivable, net was $5.1 billion as of April 29, 2023 compared to $6.6 billion as of July 30, 2022, as reported on the Consolidated Balance Sheets.

[0000858877-23-000013:notes:28]
[same as prior period, unchanged from 0000858877-23-000005:notes:28]

[0000858877-23-000013:notes:29]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 29, 2023 |  | April 30, 2022 |  | April 29, 2023 |  | April 30, 2022 |
| Allowance for credit loss at beginning of period | $ | 86 |  |  | $ | 70 |  |  | $ | 83 |  |  | $ | 109 |  |
| Provisions (benefits) | 9 |  |  | 17 |  |  | 23 |  |  | 53 |  |
| Recoveries (write-offs), net | (12) |  |  | (9) |  |  | (23) |  |  | (75) |  |
| Foreign exchange and other | — |  |  | — |  |  | — |  |  | (9) |  |
| Allowance for credit loss at end of period | $ | 83 |  |  | $ | 78 |  |  | $ | 83 |  |  | $ | 78 |  |

[0000858877-23-000013:notes:30]
[same as prior period, unchanged from 0000858877-23-000005:notes:30]

[0000858877-23-000013:notes:31]
[same as prior period, unchanged from 0000858877-23-000005:notes:31]

[0000858877-23-000013:notes:32]
|  | April 29,2023 |  | July 30,2022 |
| 1 to 4 | $ | 456 |  |  | $ | 414 |  |
| 5 to 6 | 933 |  |  | 814 |  |
| 7 and Higher | 71 |  |  | 158 |  |
| Total | $ | 1,460 |  |  | $ | 1,386 |  |

[0000858877-23-000013:notes:33]
Contract assets consist of unbilled receivables and are recorded when revenue is recognized in advance of scheduled billings to our customers. These amounts are primarily related to software and service arrangements where transfer of control has occurred but we have not yet invoiced. Our contract assets for these unbilled receivables, net of allowances, was $1.4 billion as of April 29, 2023 and $1.3 billion as of  July 30, 2022, and were included in other current assets and other assets.

[0000858877-23-000013:notes:34]
Contract liabilities consist of deferred revenue. Deferred revenue was $24.3 billion as of April 29, 2023 compared to $23.3 billion as of July 30, 2022. We recognized approximately $2.7 billion and $10.6 billion of revenue during the third quarter and first nine months of fiscal 2023, respectively, that was included in the deferred revenue balance at July 30, 2022. 
(c)Capitalized Contract Acquisition CostsWe capitalize direct and incremental costs incurred to acquire contracts, primarily sales commissions, for which the associated revenue is expected to be recognized in future periods. We incur these costs in connection with both initial contracts and renewals. These costs are initially deferred and typically amortized over the term of the customer contract which corresponds to the period of benefit. Deferred sales commissions were $1.0 billion as of each of April 29, 2023 and July 30, 2022, and were included in other current assets and other assets. The amortization expense associated with these costs was $172 million and $549 million for the third quarter and first nine months of fiscal 2023, respectively, and $175 million and $492 million for the corresponding periods of fiscal 2022, respectively, and was included in sales and marketing expenses.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0000858877-23-000013:notes:35]
[same as prior period, unchanged from 0000858877-23-000005:notes:35]


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0000858877-23-000013:notes:36]
[same as prior period, unchanged from 0000858877-23-000005:notes:36]

[0000858877-23-000013:notes:37]
[same as prior period, unchanged from 0000858877-23-000005:notes:37]

[0000858877-23-000013:notes:38]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 29,2023 |  | April 30,2022 |  | April 29,2023 |  | April 30,2022 |
| Revenue: |  |  |  |  |  |  |  |
| Secure, Agile Networks | $ | 7,550 |  |  | $ | 5,870 |  |  | $ | 20,980 |  |  | $ | 17,737 |  |
| Internet for the Future | 1,392 |  |  | 1,324 |  |  | 4,007 |  |  | 4,019 |  |
| Collaboration | 985 |  |  | 1,132 |  |  | 3,029 |  |  | 3,308 |  |
| End-to-End Security | 958 |  |  | 938 |  |  | 2,872 |  |  | 2,716 |  |
| Optimized Application Experiences | 204 |  |  | 183 |  |  | 597 |  |  | 544 |  |
| Other Products | 3 |  |  | 2 |  |  | 7 |  |  | 7 |  |
| Total Product | 11,092 |  |  | 9,448 |  |  | 31,492 |  |  | 28,330 |  |
| Services | 3,479 |  |  | 3,387 |  |  | 10,303 |  |  | 10,125 |  |
| Total | $ | 14,571 |  |  | $ | 12,835 |  |  | $ | 41,795 |  |  | $ | 38,455 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000858877-23-000013:notes:39]
Acquisitions and Divestitures
We completed two acquisitions during the first nine months of fiscal 2023. A summary of the allocation of the total purchase consideration is presented as follows (in millions):

[0000858877-23-000013:notes:40]
|  | Purchase Consideration |  | Net Tangible Assets Acquired (Liabilities Assumed) |  | Purchased Intangible Assets |  | Goodwill |
| Total acquisitions (two in total) | $ | 96 |  |  | $ | (7) |  |  | $ | 56 |  |  | $ | 47 |  |

[0000858877-23-000013:notes:41]
The total purchase consideration related to our acquisitions completed during the first nine months of fiscal 2023 consisted of cash consideration. Total transaction costs related to acquisition and divestiture activities were $6 million and $44 million for the first nine months of fiscal 2023 and 2022, respectively. These transaction costs were expensed as incurred in general and administrative expenses (“G&A”) in the Consolidated Statements of Operations.

[0000858877-23-000013:notes:42]
The goodwill generated from acquisitions completed during the first nine months of fiscal 2023 is primarily related to expected synergies. The goodwill is generally not deductible for income tax purposes.

[0000858877-23-000013:notes:43]
The Consolidated Financial Statements include the operating results of each acquisition from the date of acquisition. Pro forma results of operations and the revenue and net income subsequent to the acquisition date for the acquisitions completed during the first nine months of fiscal 2023 have not been presented because the effects of the acquisition were not material to our financial results.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000858877-23-000013:notes:44]
[same as prior period, unchanged from 0000858877-23-000005:notes:44]

[0000858877-23-000013:notes:45]
The following table presents the goodwill allocated to our reportable segments as of April 29, 2023 and during the first nine months of fiscal 2023 (in millions):

[0000858877-23-000013:notes:46]
|  | Balance at July 30, 2022 |  | Acquisitions & Divestitures |  | Foreign Currency Translation and Other |  | Balance at April 29, 2023 |
| Americas | $ | 23,882 |  |  | $ | 31 |  |  | $ | 11 |  |  | $ | 23,924 |  |
| EMEA | 9,062 |  |  | 11 |  |  | 4 |  |  | 9,077 |  |
| APJC | 5,360 |  |  | 5 |  |  | 3 |  |  | 5,368 |  |
| Total | $ | 38,304 |  |  | $ | 47 |  |  | $ | 18 |  |  | $ | 38,369 |  |

[0000858877-23-000013:notes:47]
[same as prior period, unchanged from 0000858877-23-000005:notes:47]

[0000858877-23-000013:notes:48]
The following table presents details of our intangible assets acquired through acquisitions completed during the first nine months of fiscal 2023 (in millions, except years):

[0000858877-23-000013:notes:49]
|  | FINITE LIVES |  | INDEFINITE LIVES |  | TOTAL |
|  | TECHNOLOGY |  | CUSTOMERRELATIONSHIPS |  | OTHER |  | IPR&D |  |
|  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Amount |  | Amount |
| Total acquisitions (two in total) | 4.0 |  | $ | 55 |  |  | 1.0 |  | $ | 1 |  |  | — |  |  | $ | — |  |  | $ | — |  |  | $ | 56 |  |

[0000858877-23-000013:notes:50]
[same as prior period, unchanged from 0000858877-23-000005:notes:48]

[0000858877-23-000013:notes:51]
| April 29, 2023 |  | Gross |  | Accumulated Amortization |  | Net |
| Purchased intangible assets with finite lives: |  |  |  |  |  |  |
| Technology |  | $ | 2,873 |  |  | $ | (1,541) |  |  | $ | 1,332 |  |
| Customer relationships |  | 1,259 |  |  | (880) |  |  | 379 |  |
| Other |  | 40 |  |  | (20) |  |  | 20 |  |
| Total purchased intangible assets with finite lives |  | 4,172 |  |  | (2,441) |  |  | 1,731 |  |
| In-process research and development, with indefinite lives |  | 235 |  |  | — |  |  | 235 |  |
| Total |  | $ | 4,407 |  |  | $ | (2,441) |  |  | $ | 1,966 |  |

[0000858877-23-000013:notes:52]
[same as prior period, unchanged from 0000858877-23-000005:notes:50]

[0000858877-23-000013:notes:53]
[same as prior period, unchanged from 0000858877-23-000005:notes:51]

[0000858877-23-000013:notes:54]
[same as prior period, unchanged from 0000858877-23-000005:notes:52]

[0000858877-23-000013:notes:55]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 29, 2023 |  | April 30, 2022 |  | April 29, 2023 |  | April 30, 2022 |
| Amortization of purchased intangible assets: |  |  |  |  |  |  |  |
| Cost of sales | $ | 160 |  |  | $ | 180 |  |  | $ | 476 |  |  | $ | 583 |  |
| Operating expenses | 70 |  |  | 92 |  |  | 212 |  |  | 255 |  |
| Total | $ | 230 |  |  | $ | 272 |  |  | $ | 688 |  |  | $ | 838 |  |

[0000858877-23-000013:notes:56]
The estimated future amortization expense of purchased intangible assets with finite lives as of April 29, 2023 is as follows (in millions):

[0000858877-23-000013:notes:57]
| Fiscal Year | Amount |
| 2023 (remaining three months) | $ | 238 |  |
| 2024 | $ | 832 |  |
| 2025 | $ | 460 |  |
| 2026 | $ | 119 |  |
| 2027 | $ | 55 |  |
| Thereafter | $ | 27 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000858877-23-000013:notes:58]
Restructuring and Other Charges
In the second quarter of fiscal 2023, we announced a restructuring plan (the “Fiscal 2023 Plan”), in order to rebalance the organization and enable further investment in key priority areas. This rebalancing includes talent movement options and restructuring. Additionally, we have begun optimizing our real estate portfolio, aligned to the broader hybrid work strategy. The total pretax charges are estimated to be approximately $600 million and is expected to impact approximately 5% of our global workforce. In connection with the Fiscal 2023 Plan, we incurred charges of $87 million and $330 million for the third quarter and first nine months of fiscal 2023, respectively. These aggregate pretax charges will be primarily cash-based and will consist of severance and other one-time termination benefits, real estate-related charges, and other costs. We expect the plan to be substantially completed by the end of the first quarter of fiscal 2024.

[0000858877-23-000013:notes:59]
[same as prior period, unchanged from 0000858877-23-000005:notes:57]

[0000858877-23-000013:notes:60]
|  |  | FISCAL 2021 AND PRIOR PLANS |  | FISCAL 2023 PLAN |  |  |
|  |  | EmployeeSeverance |  | Other |  | EmployeeSeverance |  | Other |  | Total |
| Liability as of July 30, 2022 |  | $ | 2 |  |  | $ | 7 |  |  | $ | — |  |  | $ | — |  |  | $ | 9 |  |
| Charges |  | — |  |  | (2) |  |  | 300 |  |  | 30 |  |  | 328 |  |
| Cash payments |  | (1) |  |  | (1) |  |  | (263) |  |  | (7) |  |  | (272) |  |
| Non-cash items |  | — |  |  | — |  |  | 1 |  |  | (2) |  |  | (1) |  |
| Liability as of April 29, 2023 |  | $ | 1 |  |  | $ | 4 |  |  | $ | 38 |  |  | $ | 21 |  |  | $ | 64 |  |

[0000858877-23-000013:notes:61]
|  |  | FISCAL 2020 AND PRIOR PLANS |  | FISCAL 2021 PLAN |  |  |
|  |  | EmployeeSeverance |  | Other |  | Employee Severance |  | Other |  | Total |
| Liability as of July 31, 2021 |  | $ | — |  |  | $ | 10 |  |  | $ | 16 |  |  | $ | 8 |  |  | $ | 34 |  |
| Charges |  | — |  |  | (5) |  |  | 10 |  |  | 3 |  |  | 8 |  |
| Cash payments |  | — |  |  | (1) |  |  | (21) |  |  | (1) |  |  | (23) |  |
| Non-cash items |  | — |  |  | — |  |  | — |  |  | (5) |  |  | (5) |  |
| Liability as of April 30, 2022 |  | $ | — |  |  | $ | 4 |  |  | $ | 5 |  |  | $ | 5 |  |  | $ | 14 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000858877-23-000013:notes:62]
[same as prior period, unchanged from 0000858877-23-000005:notes:60]

[0000858877-23-000013:notes:63]
[same as prior period, unchanged from 0000858877-23-000005:notes:61]

[0000858877-23-000013:notes:64]
|  |  | April 29,2023 |  | July 30,2022 |
| Cash and cash equivalents |  | $ | 8,044 |  |  | $ | 7,079 |  |
| Restricted cash and restricted cash equivalents included in other current assets |  | 2 |  |  | — |  |
| Restricted cash and restricted cash equivalents included in other assets |  | 1,500 |  |  | 1,500 |  |
| Total |  | $ | 9,546 |  |  | $ | 8,579 |  |

[0000858877-23-000013:notes:65]
Our restricted cash and restricted cash equivalents are funds primarily related to contractual obligations with suppliers.

[0000858877-23-000013:notes:66]
[same as prior period, unchanged from 0000858877-23-000005:notes:64]

[0000858877-23-000013:notes:67]
|  |  | April 29,2023 |  | July 30,2022 |
| Raw materials |  | $ | 1,502 |  |  | $ | 1,601 |  |
| Work in process |  | 310 |  |  | 150 |  |
| Finished goods: |  |  |  |  |
| Deferred cost of sales |  | 81 |  |  | 86 |  |
| Manufactured finished goods |  | 1,402 |  |  | 631 |  |
| Total finished goods |  | 1,483 |  |  | 717 |  |
| Service-related spares |  | 164 |  |  | 90 |  |
| Demonstration systems |  | 15 |  |  | 10 |  |
| Total |  | $ | 3,474 |  |  | $ | 2,568 |  |

[0000858877-23-000013:notes:68]
[same as prior period, unchanged from 0000858877-23-000005:notes:66]

[0000858877-23-000013:notes:69]
|  |  | April 29,2023 |  | July 30,2022 |
| Gross property and equipment: |  |  |  |  |
| Land, buildings, and building and leasehold improvements |  | $ | 4,258 |  |  | $ | 4,219 |  |
| Computer equipment and related software |  | 747 |  |  | 779 |  |
| Production, engineering, and other equipment |  | 4,604 |  |  | 4,647 |  |
| Operating lease assets |  | 135 |  |  | 185 |  |
| Furniture, fixtures and other |  | 340 |  |  | 335 |  |
| Total gross property and equipment |  | 10,084 |  |  | 10,165 |  |
| Less: accumulated depreciation and amortization |  | (8,037) |  |  | (8,168) |  |
| Total |  | $ | 2,047 |  |  | $ | 1,997 |  |

[0000858877-23-000013:notes:70]
[same as prior period, unchanged from 0000858877-23-000005:notes:68]

[0000858877-23-000013:notes:71]
|  |  | April 29,2023 |  | July 30,2022 |
| Product |  | $ | 14,681 |  |  | $ | 14,090 |  |
| Service |  | 17,401 |  |  | 17,449 |  |
| Total |  | $ | 32,082 |  |  | $ | 31,539 |  |
| Short-term RPO |  | $ | 16,869 |  |  | $ | 16,936 |  |
| Long-term RPO |  | 15,213 |  |  | 14,603 |  |
| Total |  | $ | 32,082 |  |  | $ | 31,539 |  |
| Amount to be recognized as revenue over the next 12 months |  | 53 | % |  | 54 | % |
| Deferred revenue |  | $ | 24,260 |  |  | $ | 23,264 |  |
| Unbilled contract revenue |  | 7,822 |  |  | 8,275 |  |
| Total |  | $ | 32,082 |  |  | $ | 31,539 |  |

[0000858877-23-000013:notes:72]
[same as prior period, unchanged from 0000858877-23-000005:notes:70]

[0000858877-23-000013:notes:73]
[same as prior period, unchanged from 0000858877-23-000005:notes:71]

[0000858877-23-000013:notes:74]
|  |  | April 29,2023 |  | July 30,2022 |
| Product |  | $ | 10,895 |  |  | $ | 10,427 |  |
| Service |  | 13,365 |  |  | 12,837 |  |
| Total |  | $ | 24,260 |  |  | $ | 23,264 |  |
| Reported as: |  |  |  |  |
| Current |  | $ | 13,249 |  |  | $ | 12,784 |  |
| Noncurrent |  | 11,011 |  |  | 10,480 |  |
| Total |  | $ | 24,260 |  |  | $ | 23,264 |  |

[0000858877-23-000013:notes:75]
[same as prior period, unchanged from 0000858877-23-000005:notes:73]

[0000858877-23-000013:notes:76]
[same as prior period, unchanged from 0000858877-23-000005:notes:74]

[0000858877-23-000013:notes:77]
|  |  | April 29,2023 |  | July 30,2022 |
| Current |  | $ | 1,364 |  |  | $ | 727 |  |
| Noncurrent |  | 4,092 |  |  | 5,456 |  |
| Total |  | $ | 5,456 |  |  | $ | 6,183 |  |


## us-gaap:LessorSalesTypeLeasesTextBlock

[0000858877-23-000013:notes:78]
Leases 
(a)Lessee Arrangements

[0000858877-23-000013:notes:79]
The following table presents our operating lease balances (in millions):

[0000858877-23-000013:notes:80]
|  | Balance Sheet Line Item |  | April 29, 2023 |  | July 30, 2022 |
| Operating lease right-of-use assets | Other assets |  | $ | 1,017 |  |  | $ | 1,003 |  |
| Operating lease liabilities | Other current liabilities |  | $ | 321 |  |  | $ | 322 |  |
| Operating lease liabilities | Other long-term liabilities |  | 742 |  |  | 724 |  |
| Total operating lease liabilities |  |  | $ | 1,063 |  |  | $ | 1,046 |  |

[0000858877-23-000013:notes:81]
The components of our lease expenses were as follows (in millions):

[0000858877-23-000013:notes:82]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 29, 2023 |  | April 30, 2022 |  | April 29, 2023 |  | April 30, 2022 |
| Operating lease expense | $ | 106 |  |  | $ | 99 |  |  | $ | 300 |  |  | $ | 292 |  |
| Short-term lease expense | 16 |  |  | 17 |  |  | 50 |  |  | 49 |  |
| Variable lease expense | 61 |  |  | 37 |  |  | 182 |  |  | 127 |  |
| Total lease expense | $ | 183 |  |  | $ | 153 |  |  | $ | 532 |  |  | $ | 468 |  |

[0000858877-23-000013:notes:83]
Supplemental information related to our operating leases is as follows (in millions):

[0000858877-23-000013:notes:84]
|  | Nine Months Ended |
|  | April 29, 2023 |  | April 30, 2022 |
| Cash paid for amounts included in the measurement of lease liabilities — operating cash flows | $ | 290 |  |  | $ | 306 |  |
| Right-of-use assets obtained in exchange for operating leases liabilities | $ | 278 |  |  | $ | 237 |  |

[0000858877-23-000013:notes:85]
The weighted-average lease term was 4.7 years as of each of April 29, 2023 and July 30, 2022. The weighted-average discount rate was 2.9% and 2.2% as of April 29, 2023 and July 30, 2022, respectively.

[0000858877-23-000013:notes:86]
The maturities of our operating leases (undiscounted) as of April 29, 2023 are as follows (in millions):

[0000858877-23-000013:notes:87]
| Fiscal Year | Amount |
| 2023 (remaining three months) | $ | 97 |  |
| 2024 | 327 |  |
| 2025 | 245 |  |
| 2026 | 155 |  |
| 2027 | 92 |  |
| Thereafter | 243 |  |
| Total lease payments | 1,159 |  |
| Less interest | (96) |  |
| Total | $ | 1,063 |  |

[0000858877-23-000013:notes:88]
(b)Lessor Arrangements

[0000858877-23-000013:notes:89]
Our leases primarily represent sales-type leases with terms of four years on average. We provide leasing of our equipment and complementary third-party products primarily through our channel partners and distributors, for which the income arising from these leases is recognized through interest income. Interest income was $13 million and $36 million for the third quarter and first nine months of fiscal 2023, respectively, and $13 million and $42 million for the corresponding periods of fiscal 2022, respectively, and was included in interest income in the Consolidated Statement of Operations. The net investment of our lease receivables is measured at the commencement date as the gross lease receivable, residual value less unearned income and allowance for credit loss. For additional information, see Note 9.

[0000858877-23-000013:notes:90]
Future minimum lease payments on our lease receivables as of April 29, 2023 are summarized as follows (in millions):

[0000858877-23-000013:notes:91]
| Fiscal Year | Amount |
| 2023 (remaining three months) | $ | 157 |  |
| 2024 | 326 |  |
| 2025 | 198 |  |
| 2026 | 140 |  |
| 2027 | 107 |  |
| Thereafter | 64 |  |
| Total | 992 |  |
| Less: Present value of lease payments | 920 |  |
| Unearned income | $ | 72 |  |

[0000858877-23-000013:notes:92]
Actual cash collections may differ from the contractual maturities due to early customer buyouts, refinancings, or defaults.

[0000858877-23-000013:notes:93]
We provide financing of certain equipment through operating leases, and the amounts are included in property and equipment in the Consolidated Balance Sheets. Amounts relating to equipment on operating lease assets held by us and the associated accumulated depreciation are summarized as follows (in millions):

[0000858877-23-000013:notes:94]
|  | April 29, 2023 |  | July 30, 2022 |
| Operating lease assets | $ | 135 |  |  | $ | 185 |  |
| Accumulated depreciation | (82) |  |  | (111) |  |
| Operating lease assets, net | $ | 53 |  |  | $ | 74 |  |

[0000858877-23-000013:notes:95]
Our operating lease income was $18 million and $56 million for the third quarter and first nine months of fiscal 2023, respectively, and $26 million and $87 million for the corresponding periods of fiscal 2022, respectively, and was included in product revenue in the Consolidated Statement of Operations.

[0000858877-23-000013:notes:96]
Minimum future rentals on noncancelable operating leases as of April 29, 2023 are summarized as follows (in millions):

[0000858877-23-000013:notes:97]
| Fiscal Year | Amount |
| 2023 (remaining three months) | $ | 8 |  |
| 2024 | 19 |  |
| 2025 | 7 |  |
| 2026 | 2 |  |
| Total | $ | 36 |  |


## us-gaap:FinancingReceivablesTextBlock

[0000858877-23-000013:notes:98]
[same as prior period, unchanged from 0000858877-23-000005:notes:96]

[0000858877-23-000013:notes:99]
[same as prior period, unchanged from 0000858877-23-000005:notes:97]

[0000858877-23-000013:notes:100]
[same as prior period, unchanged from 0000858877-23-000005:notes:98]

[0000858877-23-000013:notes:101]
| April 29, 2023 | Loan Receivables |  | Lease Receivables |  | Total |
| Gross | $ | 5,879 |  |  | $ | 992 |  |  | $ | 6,871 |  |
| Residual value | — |  |  | 66 |  |  | 66 |  |
| Unearned income | — |  |  | (72) |  |  | (72) |  |
| Allowance for credit loss | (53) |  |  | (17) |  |  | (70) |  |
| Total, net | $ | 5,826 |  |  | $ | 969 |  |  | $ | 6,795 |  |
| Reported as: |  |  |  |  |  |
| Current | $ | 2,949 |  |  | $ | 453 |  |  | $ | 3,402 |  |
| Noncurrent | 2,877 |  |  | 516 |  |  | 3,393 |  |
| Total, net | $ | 5,826 |  |  | $ | 969 |  |  | $ | 6,795 |  |

[0000858877-23-000013:notes:102]
[same as prior period, unchanged from 0000858877-23-000005:notes:100]

[0000858877-23-000013:notes:103]
[same as prior period, unchanged from 0000858877-23-000005:notes:101]

[0000858877-23-000013:notes:104]
[same as prior period, unchanged from 0000858877-23-000005:notes:102]

[0000858877-23-000013:notes:105]
| April 29, 2023 |  |  | Fiscal Year |  | Nine Months Ended |  |  |
| Internal Credit Risk Rating | Prior |  | July 27, 2019 |  | July 25, 2020 |  | July 31, 2021 |  | July 30, 2022 |  | April 29, 2023 |  | Total |
| Loan Receivables: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | 26 |  |  | $ | 82 |  |  | $ | 295 |  |  | $ | 929 |  |  | $ | 1,197 |  |  | $ | 1,442 |  |  | $ | 3,971 |  |
| 5 to 6 | 5 |  |  | 24 |  |  | 146 |  |  | 354 |  |  | 521 |  |  | 763 |  |  | 1,813 |  |
| 7 and Higher | 1 |  |  | 11 |  |  | 19 |  |  | 17 |  |  | 32 |  |  | 15 |  |  | 95 |  |
| Total Loan Receivables | $ | 32 |  |  | $ | 117 |  |  | $ | 460 |  |  | $ | 1,300 |  |  | $ | 1,750 |  |  | $ | 2,220 |  |  | $ | 5,879 |  |
| Lease Receivables: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | 4 |  |  | $ | 32 |  |  | $ | 73 |  |  | $ | 135 |  |  | $ | 90 |  |  | $ | 160 |  |  | $ | 494 |  |
| 5 to 6 | 2 |  |  | 18 |  |  | 56 |  |  | 71 |  |  | 98 |  |  | 160 |  |  | 405 |  |
| 7 and Higher | 1 |  |  | 2 |  |  | 4 |  |  | 4 |  |  | 4 |  |  | 6 |  |  | 21 |  |
| Total Lease Receivables | $ | 7 |  |  | $ | 52 |  |  | $ | 133 |  |  | $ | 210 |  |  | $ | 192 |  |  | $ | 326 |  |  | $ | 920 |  |
| Total | $ | 39 |  |  | $ | 169 |  |  | $ | 593 |  |  | $ | 1,510 |  |  | $ | 1,942 |  |  | $ | 2,546 |  |  | $ | 6,799 |  |

[0000858877-23-000013:notes:106]
[same as prior period, unchanged from 0000858877-23-000005:notes:104]

[0000858877-23-000013:notes:107]
The following tables present the aging analysis of gross receivables as of April 29, 2023 and July 30, 2022 (in millions):

[0000858877-23-000013:notes:108]
|  | DAYS PAST DUE (INCLUDES BILLED AND UNBILLED) |  |  |  |  |  |  |  |  |  |  |
| April 29, 2023 | 31-60 |  | 61-90 |  | 91+ |  | TotalPast Due |  | Current |  | Total |  | 120+ Still Accruing |  | NonaccrualFinancingReceivables |  | ImpairedFinancingReceivables |
| Loan receivables | $ | 94 |  |  | $ | 39 |  |  | $ | 79 |  |  | $ | 212 |  |  | $ | 5,667 |  |  | $ | 5,879 |  |  | $ | 15 |  |  | $ | 15 |  |  | $ | 15 |  |
| Lease receivables | 15 |  |  | 10 |  |  | 24 |  |  | 49 |  |  | 871 |  |  | 920 |  |  | 7 |  |  | 4 |  |  | 4 |  |
| Total | $ | 109 |  |  | $ | 49 |  |  | $ | 103 |  |  | $ | 261 |  |  | $ | 6,538 |  |  | $ | 6,799 |  |  | $ | 22 |  |  | $ | 19 |  |  | $ | 19 |  |

[0000858877-23-000013:notes:109]
[same as prior period, unchanged from 0000858877-23-000005:notes:107]

[0000858877-23-000013:notes:110]
[same as prior period, unchanged from 0000858877-23-000005:notes:108]

[0000858877-23-000013:notes:111]
[same as prior period, unchanged from 0000858877-23-000005:notes:109]

[0000858877-23-000013:notes:112]
[same as prior period, unchanged from 0000858877-23-000005:notes:110]

[0000858877-23-000013:notes:113]
| Three Months Ended April 29, 2023 | CREDIT LOSS ALLOWANCES |
|  | Loan Receivables |  | Lease Receivables |  | Total |
| Allowance for credit loss as of January 28, 2023 | $ | 94 |  |  | $ | 19 |  |  | $ | 113 |  |
| Provisions (benefits) | (3) |  |  | (1) |  |  | (4) |  |
| Recoveries (write-offs), net | (38) |  |  | (1) |  |  | (39) |  |
| Allowance for credit loss as of April 29, 2023 | $ | 53 |  |  | $ | 17 |  |  | $ | 70 |  |

[0000858877-23-000013:notes:114]
| Three Months Ended April 30, 2022 | CREDIT LOSS ALLOWANCES |
|  | Loan Receivables |  | Lease Receivables |  | Total |
| Allowance for credit loss as of January 29, 2022 | $ | 70 |  |  | $ | 27 |  |  | $ | 97 |  |
| Provisions (benefits) | 26 |  |  | (2) |  |  | 24 |  |
| Other | 3 |  |  | — |  |  | 3 |  |
| Allowance for credit loss as of April 30, 2022 | $ | 99 |  |  | $ | 25 |  |  | $ | 124 |  |

[0000858877-23-000013:notes:115]
| Nine Months Ended April 29, 2023 | CREDIT LOSS ALLOWANCES |
|  | Loan Receivables |  | Lease Receivables |  | Total |
| Allowance for credit loss as of July 30, 2022 | $ | 103 |  |  | $ | 23 |  |  | $ | 126 |  |
| Provisions (benefits) | (7) |  |  | (5) |  |  | (12) |  |
| Recoveries (write-offs), net | (38) |  |  | (1) |  |  | (39) |  |
| Other | (5) |  |  | — |  |  | (5) |  |
| Allowance for credit loss as of April 29, 2023 | $ | 53 |  |  | $ | 17 |  |  | $ | 70 |  |

[0000858877-23-000013:notes:116]
| Nine Months Ended April 30, 2022 | CREDIT LOSS ALLOWANCES |
|  | Loan Receivables |  | Lease Receivables |  | Total |
| Allowance for credit loss as of July 31, 2021 | $ | 89 |  |  | $ | 38 |  |  | $ | 127 |  |
| Provisions (benefits) | 7 |  |  | (11) |  |  | (4) |  |
| Recoveries (write-offs), net | — |  |  | (2) |  |  | (2) |  |
| Other | 3 |  |  | — |  |  | 3 |  |
| Allowance for credit loss as of April 30, 2022 | $ | 99 |  |  | $ | 25 |  |  | $ | 124 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000858877-23-000013:notes:117]
Available-for-Sale Debt and Equity Investments
(a)Summary of Available-for-Sale Debt Investments

[0000858877-23-000013:notes:118]
The following tables summarize our available-for-sale debt investments (in millions):

[0000858877-23-000013:notes:119]
| April 29, 2023 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 2,833 |  |  | $ | 9 |  |  | $ | (42) |  |  | $ | 2,800 |  |
| U.S. government agency securities | 365 |  |  | 1 |  |  | (4) |  |  | 362 |  |
| Non-U.S. government and agency securities | 352 |  |  | — |  |  | — |  |  | 352 |  |
| Corporate debt securities | 7,587 |  |  | 8 |  |  | (305) |  |  | 7,290 |  |
| U.S. agency mortgage-backed securities | 2,221 |  |  | 1 |  |  | (208) |  |  | 2,014 |  |
| Commercial paper | 1,595 |  |  | — |  |  | — |  |  | 1,595 |  |
| Certificates of deposit | 485 |  |  | — |  |  | — |  |  | 485 |  |
| Total | $ | 15,438 |  |  | $ | 19 |  |  | $ | (559) |  |  | $ | 14,898 |  |

[0000858877-23-000013:notes:120]
| July 30, 2022 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 1,287 |  |  | $ | — |  |  | $ | (49) |  |  | $ | 1,238 |  |
| U.S. government agency securities | 142 |  |  | — |  |  | (4) |  |  | 138 |  |
| Non-U.S. government and agency securities | 272 |  |  | — |  |  | — |  |  | 272 |  |
| Corporate debt securities | 8,127 |  |  | 2 |  |  | (311) |  |  | 7,818 |  |
| U.S. agency mortgage-backed securities | 2,134 |  |  | — |  |  | (158) |  |  | 1,976 |  |
| Commercial paper | 255 |  |  | — |  |  | — |  |  | 255 |  |
| Certificates of deposit | 250 |  |  | — |  |  | — |  |  | 250 |  |
| Total | $ | 12,467 |  |  | $ | 2 |  |  | $ | (522) |  |  | $ | 11,947 |  |

[0000858877-23-000013:notes:121]
Net unsettled investment purchases were $9 million and net unsettled investment sales were $70 million as of April 29, 2023 and July 30, 2022, respectively, and were included in other current assets and other current liabilities.

[0000858877-23-000013:notes:122]
The following table presents the gross realized gains and gross realized losses related to available-for-sale debt investments (in millions):

[0000858877-23-000013:notes:123]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 29, 2023 |  | April 30, 2022 |  | April 29, 2023 |  | April 30, 2022 |
| Gross realized gains | $ | 1 |  |  | $ | 8 |  |  | $ | 4 |  |  | $ | 27 |  |
| Gross realized losses | (7) |  |  | (6) |  |  | (19) |  |  | (9) |  |
| Total | $ | (6) |  |  | $ | 2 |  |  | $ | (15) |  |  | $ | 18 |  |

[0000858877-23-000013:notes:124]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at April 29, 2023 and July 30, 2022 (in millions):

[0000858877-23-000013:notes:125]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| April 29, 2023 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 360 |  |  | $ | (2) |  |  | $ | 1,125 |  |  | $ | (40) |  |  | $ | 1,485 |  |  | $ | (42) |  |
| U.S. government agency securities | 148 |  |  | (1) |  |  | 110 |  |  | (3) |  |  | 258 |  |  | (4) |  |
| Non-U.S. government and agency securities | 291 |  |  | — |  |  | — |  |  | — |  |  | 291 |  |  | — |  |
| Corporate debt securities | 1,387 |  |  | (14) |  |  | 4,869 |  |  | (261) |  |  | 6,256 |  |  | (275) |  |
| U.S. agency mortgage-backed securities | 343 |  |  | (5) |  |  | 1,514 |  |  | (203) |  |  | 1,857 |  |  | (208) |  |
| Commercial paper | 69 |  |  | — |  |  | — |  |  | — |  |  | 69 |  |  | — |  |
| Certificates of deposit | 5 |  |  | — |  |  | — |  |  | — |  |  | 5 |  |  | — |  |
| Total | $ | 2,603 |  |  | $ | (22) |  |  | $ | 7,618 |  |  | $ | (507) |  |  | $ | 10,221 |  |  | $ | (529) |  |

[0000858877-23-000013:notes:126]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 30, 2022 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 1,110 |  |  | $ | (44) |  |  | $ | 120 |  |  | $ | (5) |  |  | $ | 1,230 |  |  | $ | (49) |  |
| U.S. government agency securities | 114 |  |  | (2) |  |  | 24 |  |  | (2) |  |  | 138 |  |  | (4) |  |
| Non-U.S. government and agency securities | 264 |  |  | — |  |  | — |  |  | — |  |  | 264 |  |  | — |  |
| Corporate debt securities | 6,920 |  |  | (240) |  |  | 422 |  |  | (37) |  |  | 7,342 |  |  | (277) |  |
| U.S. agency mortgage-backed securities | 1,305 |  |  | (96) |  |  | 615 |  |  | (62) |  |  | 1,920 |  |  | (158) |  |
| Total | $ | 9,713 |  |  | $ | (382) |  |  | $ | 1,181 |  |  | $ | (106) |  |  | $ | 10,894 |  |  | $ | (488) |  |

[0000858877-23-000013:notes:127]
The following table summarizes the maturities of our available-for-sale debt investments as of April 29, 2023 (in millions):

[0000858877-23-000013:notes:128]
|  | Amortized Cost |  | Fair Value |
| Within 1 year | $ | 5,821 |  |  | $ | 5,762 |  |
| After 1 year through 5 years | 7,340 |  |  | 7,067 |  |
| After 5 years through 10 years | 54 |  |  | 53 |  |
| After 10 years | 2 |  |  | 2 |  |
| Mortgage-backed securities with no single maturity | 2,221 |  |  | 2,014 |  |
| Total | $ | 15,438 |  |  | $ | 14,898 |  |

[0000858877-23-000013:notes:129]
Actual maturities may differ from the contractual maturities because borrowers may have the right to call or prepay certain obligations.

[0000858877-23-000013:notes:130]
(b)Summary of Equity Investments

[0000858877-23-000013:notes:131]
We held marketable equity securities of $346 million and $241 million as of April 29, 2023 and July 30, 2022, respectively. We recognized a net unrealized loss of $2 million and $11 million during the third quarter and first nine months of fiscal 2023, respectively, and a net unrealized loss of $19 million and $32 million during the corresponding periods of fiscal 2022, respectively, on our marketable securities still held as of the reporting date. Our net adjustments to non-marketable equity securities measured using the measurement alternative still held was a net gain of $7 million and a net loss of $2 million for the third quarter and first nine months of fiscal 2023, respectively, and a net gain of $11 million and $28 million for the corresponding periods of fiscal 2022, respectively. We held equity interests in certain private equity funds of $0.9 billion and $1.1 billion as of April 29, 2023 and July 30, 2022, respectively, which are accounted for under the NAV practical expedient.

[0000858877-23-000013:notes:132]
In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers are evaluated for consolidation under the variable interest or voting interest entity models. We evaluate on an ongoing basis our investments in these privately held companies and our customer financings, and have determined that as of April 29, 2023, there were no significant variable interest or voting interest entities required to be consolidated in our Consolidated Financial Statements.

[0000858877-23-000013:notes:133]
The carrying value of our investments in privately held companies was $1.8 billion and $1.9 billion as of April 29, 2023 and July 30, 2022, respectively. Of the total carrying value of our investments in privately held companies as of April 29, 2023, $1.0 billion of such investments are considered to be in variable interest entities which are unconsolidated. As of April 29, 2023, we have total funding commitments of $0.3 billion related to privately held investments, some of which may be based on the achievement of certain agreed-upon milestones or are required to be funded on demand. The carrying value of these investments and the additional funding commitments, collectively, represent our maximum exposure related to privately held investments.


## us-gaap:FairValueDisclosuresTextBlock

[0000858877-23-000013:notes:134]
[same as prior period, unchanged from 0000858877-23-000005:notes:132]

[0000858877-23-000013:notes:135]
[same as prior period, unchanged from 0000858877-23-000005:notes:133]

[0000858877-23-000013:notes:136]
|  | APRIL 29, 2023 |  | JULY 30, 2022 |
|  | FAIR VALUE MEASUREMENTS |  | FAIR VALUE MEASUREMENTS |
|  | Level 1 |  | Level 2 |  | TotalBalance |  | Level 1 |  | Level 2 |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 4,650 |  |  | $ | — |  |  | $ | 4,650 |  |  | $ | 3,930 |  |  | $ | — |  |  | $ | 3,930 |  |
| Commercial paper | — |  |  | 812 |  |  | 812 |  |  | — |  |  | 72 |  |  | 72 |  |
| Corporate debt securities | — |  |  | 20 |  |  | 20 |  |  | — |  |  | 1 |  |  | 1 |  |
| U.S. government securities | — |  |  | — |  |  | — |  |  | — |  |  | 12 |  |  | 12 |  |
| Certificates of deposit | — |  |  | — |  |  | — |  |  | — |  |  | 32 |  |  | 32 |  |
| Available-for-sale debt investments: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | — |  |  | 2,800 |  |  | 2,800 |  |  | — |  |  | 1,238 |  |  | 1,238 |  |
| U.S. government agency securities | — |  |  | 362 |  |  | 362 |  |  | — |  |  | 138 |  |  | 138 |  |
| Non-U.S. government and agency securities | — |  |  | 352 |  |  | 352 |  |  | — |  |  | 272 |  |  | 272 |  |
| Corporate debt securities | — |  |  | 7,290 |  |  | 7,290 |  |  | — |  |  | 7,818 |  |  | 7,818 |  |
| U.S. agency mortgage-backed securities | — |  |  | 2,014 |  |  | 2,014 |  |  | — |  |  | 1,976 |  |  | 1,976 |  |
| Commercial paper | — |  |  | 1,595 |  |  | 1,595 |  |  | — |  |  | 255 |  |  | 255 |  |
| Certificates of deposit | — |  |  | 485 |  |  | 485 |  |  | — |  |  | 250 |  |  | 250 |  |
| Equity investments: |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities | 346 |  |  | — |  |  | 346 |  |  | 241 |  |  | — |  |  | 241 |  |
| Other assets: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 1,500 |  |  | — |  |  | 1,500 |  |  | 1,500 |  |  | — |  |  | 1,500 |  |
| Derivative assets | — |  |  | 25 |  |  | 25 |  |  | — |  |  | 78 |  |  | 78 |  |
| Total | $ | 6,496 |  |  | $ | 15,755 |  |  | $ | 22,251 |  |  | $ | 5,671 |  |  | $ | 12,142 |  |  | $ | 17,813 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities | $ | — |  |  | $ | 61 |  |  | $ | 61 |  |  | $ | — |  |  | $ | 89 |  |  | $ | 89 |  |
| Total | $ | — |  |  | $ | 61 |  |  | $ | 61 |  |  | $ | — |  |  | $ | 89 |  |  | $ | 89 |  |

[0000858877-23-000013:notes:137]
[same as prior period, unchanged from 0000858877-23-000005:notes:135]

[0000858877-23-000013:notes:138]
[same as prior period, unchanged from 0000858877-23-000005:notes:136]

[0000858877-23-000013:notes:139]
[same as prior period, unchanged from 0000858877-23-000005:notes:137]

[0000858877-23-000013:notes:140]
[same as prior period, unchanged from 0000858877-23-000005:notes:138]

[0000858877-23-000013:notes:141]
The fair value of our short-term loan receivables approximates their carrying value due to their short duration. The aggregate carrying value of our long-term loan receivables as of April 29, 2023 and July 30, 2022 was $2.9 billion and $3.4 billion, respectively. The estimated fair value of our long-term loan receivables approximates their carrying value. We use unobservable inputs in determining discounted cash flows to estimate the fair value of our long-term loan receivables, and therefore they are categorized as Level 3.
As of April 29, 2023, the estimated fair value of our short-term debt approximates its carrying value due to the short maturities. As of April 29, 2023, the fair value of our senior notes was $8.8 billion with a carrying amount of $8.4 billion. This compares to a fair value of $9.7 billion and a carrying amount of $8.9 billion as of July 30, 2022. The fair value of the senior notes was determined based on observable market prices in a less active market and was categorized as Level 2 in the fair value hierarchy.


## us-gaap:DebtDisclosureTextBlock

[0000858877-23-000013:notes:142]
Borrowings 
(a)Short-Term Debt

[0000858877-23-000013:notes:143]
The following table summarizes our short-term debt (in millions, except percentages):

[0000858877-23-000013:notes:144]
|  | April 29, 2023 |  | July 30, 2022 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 1,731 |  |  | 4.26 | % |  | $ | 499 |  |  | 2.68 | % |
| Commercial paper | — |  |  | — |  |  | 600 |  |  | 2.05 | % |
| Total | $ | 1,731 |  |  |  |  | $ | 1,099 |  |  |  |

[0000858877-23-000013:notes:145]
We have a short-term debt financing program of up to $10.0 billion through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes.

[0000858877-23-000013:notes:146]
The effective rates for the short- and long-term debt include the interest on the notes, the accretion of the discount, the issuance costs, and, if applicable, adjustments related to hedging.

[0000858877-23-000013:notes:147]
(b)Long-Term Debt

[0000858877-23-000013:notes:148]
The following table summarizes our long-term debt (in millions, except percentages):

[0000858877-23-000013:notes:149]
|  |  |  | April 29, 2023 |  | July 30, 2022 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 2.60% | February 28, 2023 |  | $ | — |  |  | — |  | $ | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 5.75% |  | 1,000 |  |  | 2.69% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 6.15% |  | 500 |  |  | 3.20% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 8,500 |  |  |  |  | 9,000 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (70) |  |  |  |  | (75) |  |  |  |
| Hedge accounting fair value adjustments |  |  | (36) |  |  |  |  | (10) |  |  |  |
| Total |  |  | $ | 8,394 |  |  |  |  | $ | 8,915 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 1,731 |  |  |  |  | $ | 499 |  |  |  |
| Long-term debt |  |  | 6,663 |  |  |  |  | 8,416 |  |  |  |
| Total |  |  | $ | 8,394 |  |  |  |  | $ | 8,915 |  |  |  |

[0000858877-23-000013:notes:150]
We have entered into interest rate swaps in prior periods with an aggregate notional amount of $1.5 billion designated as fair value hedges of certain of our fixed-rate senior notes. These swaps convert the fixed interest rates of the fixed-rate notes to floating interest rates based on the London InterBank Offered Rate (LIBOR). The gains and losses related to changes in the fair value of the interest rate swaps substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates. For additional information, see Note 13.

[0000858877-23-000013:notes:151]
Interest is payable semiannually on each class of the senior fixed-rate notes. Each of the senior fixed-rate notes is redeemable by us at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to our short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of April 29, 2023, we were in compliance with all debt covenants.

[0000858877-23-000013:notes:152]
As of April 29, 2023, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

[0000858877-23-000013:notes:153]
| Fiscal Year | Amount |
| 2023 (remaining three months) | $ | — |  |
| 2024 | 1,750 |  |
| 2025 | 500 |  |
| 2026 | 750 |  |
| 2027 | 1,500 |  |
| Thereafter | 4,000 |  |
| Total | $ | 8,500 |  |

[0000858877-23-000013:notes:154]
(c)Credit Facility

[0000858877-23-000013:notes:155]
On May 13, 2021, we entered into a 5-year credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 13, 2026. As of April 29, 2023, we were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under the credit

[0000858877-23-000013:notes:156]
agreement. On April 18, 2023, we entered into an amendment to the credit agreement to replace the LIBOR index with Term Secured Overnight Financing Rate (SOFR).

[0000858877-23-000013:notes:157]
Any advances under the 5-year credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (a) with respect to loans in U.S. dollars, (i) Term SOFR (plus a 0.10% credit spread adjustment) or (ii) the Base Rate (to be defined as the highest of (x) the Bank of America prime rate, (y) the Federal Funds rate plus 0.50% and (z) Term SOFR plus 1.0%), (b) with respect to loans in Euros, EURIBOR, (c) with respect to loans in Yen, TIBOR and (d) with respect to loans in Pounds Sterling, SONIA, plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the interest rate be less than 0.0%. We will pay a quarterly commitment fee during the term of the 5-year credit agreement which may vary depending on our senior debt credit ratings. In addition, the 5-year credit agreement incorporates certain sustainability-linked metrics. Specifically, our applicable interest rate and commitment fee are subject to upward or downward adjustments if we achieve, or fail to achieve, certain specified targets based on two key performance indicator metrics: (i) social impact and (ii) foam reduction. We may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and, at our option, extend the maturity of the facility for an additional year up to two times. The credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio as defined in the agreement.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000858877-23-000013:notes:158]
[same as prior period, unchanged from 0000858877-23-000005:notes:154]

[0000858877-23-000013:notes:159]
[same as prior period, unchanged from 0000858877-23-000005:notes:155]

[0000858877-23-000013:notes:160]
[same as prior period, unchanged from 0000858877-23-000005:notes:156]

[0000858877-23-000013:notes:161]
|  | DERIVATIVE ASSETS |  | DERIVATIVE LIABILITIES |
|  | Balance Sheet Line Item |  | April 29,2023 |  | July 30,2022 |  | Balance Sheet Line Item |  | April 29,2023 |  | July 30,2022 |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | $ | 19 |  |  | $ | 55 |  |  | Other current liabilities |  | $ | — |  |  | $ | — |  |
| Foreign currency derivatives | Other assets |  | 2 |  |  | 9 |  |  | Other long-term liabilities |  | 1 |  |  | — |  |
| Interest rate derivatives | Other current assets |  | — |  |  | — |  |  | Other current liabilities |  | 18 |  |  | — |  |
| Interest rate derivatives | Other assets |  | — |  |  | — |  |  | Other long-term liabilities |  | 18 |  |  | 10 |  |
| Total |  |  | 21 |  |  | 64 |  |  |  |  | 37 |  |  | 10 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | 3 |  |  | 14 |  |  | Other current liabilities |  | 21 |  |  | 69 |  |
| Foreign currency derivatives | Other assets |  | 1 |  |  | — |  |  | Other long-term liabilities |  | 2 |  |  | 9 |  |
| Equity derivatives | Other current assets |  | — |  |  | — |  |  | Other current liabilities |  | 1 |  |  | 1 |  |
| Total |  |  | 4 |  |  | 14 |  |  |  |  | 24 |  |  | 79 |  |
| Total |  |  | $ | 25 |  |  | $ | 78 |  |  |  |  | $ | 61 |  |  | $ | 89 |  |

[0000858877-23-000013:notes:162]
[same as prior period, unchanged from 0000858877-23-000005:notes:158]

[0000858877-23-000013:notes:163]
|  |  | CARRYING AMOUNT OF THE HEDGED ASSETS/(LIABILITIES) |  | CUMULATIVE AMOUNT OF FAIR VALUE HEDGING ADJUSTMENT INCLUDED IN THE CARRYING AMOUNT OF THE HEDGED ASSETS/LIABILITIES |
| Balance Sheet Line Item of Hedged Item |  | April 29,2023 |  | July 30,2022 |  | April 29,2023 |  | July 30,2022 |
| Short-term debt |  | $ | (981) |  |  | $ | — |  |  | $ | 18 |  |  | $ | — |  |
| Long-term debt |  | $ | (482) |  |  | $ | (1,487) |  |  | $ | 18 |  |  | $ | 10 |  |

[0000858877-23-000013:notes:164]
[same as prior period, unchanged from 0000858877-23-000005:notes:160]

[0000858877-23-000013:notes:165]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 29, 2023 |  | April 30, 2022 |  | April 29, 2023 |  | April 30, 2022 |
| Interest rate derivatives: |  |  |  |  |  |  |  |  |
| Hedged items |  | $ | (6) |  |  | $ | 54 |  |  | $ | 26 |  |  | $ | 112 |  |
| Derivatives designated as hedging instruments |  | 6 |  |  | (55) |  |  | (26) |  |  | (114) |  |
| Total |  | $ | — |  |  | $ | (1) |  |  | $ | — |  |  | $ | (2) |  |

[0000858877-23-000013:notes:166]
[same as prior period, unchanged from 0000858877-23-000005:notes:162]

[0000858877-23-000013:notes:167]
|  |  |  |  | GAINS (LOSSES) FOR THE THREE MONTHS ENDED |  | GAINS (LOSSES) FOR THE NINE MONTHS ENDED |
| Derivatives Not Designated as Hedging Instruments |  | Line Item in Statements of Operations |  | April 29,2023 |  | April 30,2022 |  | April 29, 2023 |  | April 30,2022 |
| Foreign currency derivatives |  | Other income (loss), net |  | $ | (46) |  |  | $ | (99) |  |  | $ | 22 |  |  | $ | (155) |  |
| Total return swaps—deferred compensation |  | Operating expenses and other |  | (12) |  |  | (38) |  |  | 7 |  |  | (58) |  |
| Equity derivatives |  | Other income (loss), net |  | 4 |  |  | 5 |  |  | 8 |  |  | 6 |  |
| Total |  |  |  | $ | (54) |  |  | $ | (132) |  |  | $ | 37 |  |  | $ | (207) |  |

[0000858877-23-000013:notes:168]
[same as prior period, unchanged from 0000858877-23-000005:notes:164]

[0000858877-23-000013:notes:169]
|  | April 29,2023 |  | July 30,2022 |
| Foreign currency derivatives | $ | 4,880 |  |  | $ | 4,521 |  |
| Interest rate derivatives | 1,500 |  |  | 1,500 |  |
| Total return swaps—deferred compensation | 733 |  |  | 651 |  |
| Total | $ | 7,113 |  |  | $ | 6,672 |  |

[0000858877-23-000013:notes:170]
[same as prior period, unchanged from 0000858877-23-000005:notes:166]

[0000858877-23-000013:notes:171]
[same as prior period, unchanged from 0000858877-23-000005:notes:167]

[0000858877-23-000013:notes:172]
To further limit credit risk, we also enter into collateral security arrangements related to certain derivative instruments whereby cash is posted as collateral between the counterparties based on the fair market value of the derivative instrument. Under these collateral security arrangements, the net cash collateral provided for was $34 million and $14 million as of April 29, 2023 and July 30, 2022, respectively.

[0000858877-23-000013:notes:173]
[same as prior period, unchanged from 0000858877-23-000005:notes:169]

[0000858877-23-000013:notes:174]
[same as prior period, unchanged from 0000858877-23-000005:notes:170]

[0000858877-23-000013:notes:175]
[same as prior period, unchanged from 0000858877-23-000005:notes:171]

[0000858877-23-000013:notes:176]
[same as prior period, unchanged from 0000858877-23-000005:notes:172]

[0000858877-23-000013:notes:177]
[same as prior period, unchanged from 0000858877-23-000005:notes:173]

[0000858877-23-000013:notes:178]
[same as prior period, unchanged from 0000858877-23-000005:notes:174]

[0000858877-23-000013:notes:179]
[same as prior period, unchanged from 0000858877-23-000005:notes:175]

[0000858877-23-000013:notes:180]
[same as prior period, unchanged from 0000858877-23-000005:notes:176]

[0000858877-23-000013:notes:181]
[same as prior period, unchanged from 0000858877-23-000005:notes:177]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000858877-23-000013:notes:182]
Commitments and Contingencies 
(a)Purchase Commitments with Contract Manufacturers and Suppliers

[0000858877-23-000013:notes:183]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these inventory purchase commitments with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.

[0000858877-23-000013:notes:184]
The following table summarizes our inventory purchase commitments with contract manufacturers and suppliers by period (in millions):

[0000858877-23-000013:notes:185]
|  | April 29,2023 |  | July 30,2022 |
| Less than 1 year | $ | 7,073 |  |  | $ | 9,954 |  |
| 1 to 3 years | 1,618 |  |  | 2,240 |  |
| 3 to 5 years | 368 |  |  | 770 |  |
| Total | $ | 9,059 |  |  | $ | 12,964 |  |

[0000858877-23-000013:notes:186]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of April 29, 2023 and July 30, 2022, the liability for these purchase commitments was $525 million and $313 million, respectively, and was included in other current liabilities.

[0000858877-23-000013:notes:187]
(b)Other Commitments

[0000858877-23-000013:notes:188]
In connection with our acquisitions, we have agreed to pay certain additional amounts contingent upon the achievement of certain agreed-upon technology, development, product, or other milestones or upon the continued employment with Cisco of certain employees of the acquired entities.

[0000858877-23-000013:notes:189]
The following table summarizes the compensation expense related to acquisitions (in millions):

[0000858877-23-000013:notes:190]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 29, 2023 |  | April 30, 2022 |  | April 29, 2023 |  | April 30, 2022 |
| Compensation expense related to acquisitions | $ | 53 |  |  | $ | 56 |  |  | $ | 176 |  |  | $ | 220 |  |

[0000858877-23-000013:notes:191]
As of April 29, 2023, we estimated that future cash compensation expense of up to $310 million may be required to be recognized pursuant to the applicable business combination agreements.

[0000858877-23-000013:notes:192]
We also have certain funding commitments, primarily related to our privately held investments, some of which are based on the achievement of certain agreed-upon milestones or are required to be funded on demand. The funding commitments were $0.3 billion and $0.4 billion as of April 29, 2023 and July 30, 2022, respectively.

[0000858877-23-000013:notes:193]
(c)Product Warranties

[0000858877-23-000013:notes:194]
The following table summarizes the activity related to the product warranty liability (in millions):

[0000858877-23-000013:notes:195]
|  | Nine Months Ended |
|  | April 29,2023 |  | April 30,2022 |
| Balance at beginning of period | $ | 333 |  |  | $ | 336 |  |
| Provisions for warranties issued | 285 |  |  | 320 |  |
| Adjustments for pre-existing warranties | 15 |  |  | 1 |  |
| Settlements | (321) |  |  | (322) |  |
| Balance at end of period | $ | 312 |  |  | $ | 335 |  |

[0000858877-23-000013:notes:196]
We accrue for warranty costs as part of our cost of sales based on associated material product costs, labor costs for technical support staff, and associated overhead. Our products are generally covered by a warranty for periods ranging from 90 days to five years, and for some products we provide a limited lifetime warranty.

[0000858877-23-000013:notes:197]
(d)Financing and Other Guarantees

[0000858877-23-000013:notes:198]
In the ordinary course of business, we provide financing guarantees for various third-party financing arrangements extended to channel partners customers. Payments under these financing guarantee arrangements were not material for the periods presented.

[0000858877-23-000013:notes:199]
Channel Partner Financing Guarantees   We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, with payment terms generally ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. The volume of channel partner financing was $8.3 billion and $6.9 billion for the third quarter of fiscal 2023 and 2022, respectively, and $23.4 billion and $20.3 billion for the first nine months of fiscal 2023 and 2022, respectively. The balance of the channel partner financing subject to guarantees was $1.8 billion and $1.4 billion as of April 29, 2023 and July 30, 2022, respectively.

[0000858877-23-000013:notes:200]
Financing Guarantee Summary   The aggregate amounts of channel partner financing guarantees outstanding at April 29, 2023 and July 30, 2022, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

[0000858877-23-000013:notes:201]
|  | April 29,2023 |  | July 30,2022 |
| Maximum potential future payments | $ | 177 |  |  | $ | 188 |  |
| Deferred revenue | (40) |  |  | (9) |  |
| Total | $ | 137 |  |  | $ | 179 |  |

[0000858877-23-000013:notes:202]
(e)Indemnifications

[0000858877-23-000013:notes:203]
In the normal course of business, we have indemnification obligations to other parties, including customers, lessors, and parties to other transactions with us, with respect to certain matters. We have agreed to indemnify against losses arising from a breach of representations or covenants or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time or circumstances within which an indemnification claim can be made and the amount of the claim.

[0000858877-23-000013:notes:204]
It is not possible to determine the maximum potential amount for claims made under the indemnification obligations due to uncertainties in the litigation process, coordination with and contributions by other parties and the defendants in these types of cases, and the unique facts and circumstances involved in each particular case and agreement. Historically, indemnity payments made by us have not had a material effect on our Consolidated Financial Statements.

[0000858877-23-000013:notes:205]
In addition, we have entered into indemnification agreements with our officers and directors, and our Amended and Restated Bylaws contain similar indemnification obligations to our agents.

[0000858877-23-000013:notes:206]
(f)Legal Proceedings

[0000858877-23-000013:notes:207]
Brazil    Brazilian authorities have investigated our Brazilian subsidiary and certain of its former employees, as well as a Brazilian importer of our products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against our Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years. The asserted claims by Brazilian federal tax authorities are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $162 million for the alleged evasion of import and other taxes, $908 million for interest, and $401 million for various penalties, all determined using an exchange rate as of April 29, 2023.

[0000858877-23-000013:notes:208]
We have completed a thorough review of the matters and believe the asserted claims against our Brazilian subsidiary are without merit, and we are defending the claims vigorously. While we believe there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, we are unable to determine the likelihood of an unfavorable outcome against our Brazilian subsidiary and are unable to reasonably estimate a range of loss, if any. We do not expect a final judicial determination for several years.

[0000858877-23-000013:notes:209]
Centripetal     On February 13, 2018, Centripetal Networks, Inc. (“Centripetal”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Virginia, alleging that several of our products and services infringe eleven Centripetal U.S. patents. The district court case went to trial on five asserted patents. Subsequently, on October 5, 2020, the district court issued a judgment finding validity and willful infringement of four of the asserted patents and non-infringement of the fifth patent and awarded $1.9 billion in damages and $14 million in pre-judgment interest, declined to issue an injunction but, instead, awarded Centripetal a royalty against future revenue for an initial three-year term at a 10% rate, with a minimum and maximum annual royalty of $168 million and $300 million, respectively, and for a second three-year term at a 5% rate, with a minimum and maximum annual royalty of $84 million and $150 million, respectively. We appealed and, on June 23, 2022, the U.S. Court of Appeals for the Federal Circuit (“Federal Circuit”) vacated the district court’s final judgment, remanded the case back to the district court to be assigned to a new judge and ordered the district court to conduct additional proceedings and the district court set a hearing to commence on June 22, 2023. On May 24, 2023, the Patent Trial and Appeal Board cancelled all claims of one of the Centripetal patents that is the subject of the hearing set for June 22, 2023. On August 9, 2022, Centripetal filed a petition for writ of certiorari in the U.S. Supreme Court challenging the Federal Circuit’s decision. The Supreme Court denied Centripetal’s petition on December 5, 2022.

[0000858877-23-000013:notes:210]
Between April 2020 and February 2022, Centripetal filed complaints in the District Court of Dusseldorf in Germany (“German Court”), asserting a total of five patents and one utility model. Centripetal sought damages and injunctive relief in all cases. On December 10, 2021, the German Court rejected Centripetal’s complaints on two patents, and Centripetal appealed. A hearing for a Cisco nullity action in the Federal Patent Court in Germany on one of those two patents occurred on August 1, 2022, and we are waiting for the Court’s opinion. On December 21, 2021, the German Court stayed its decision on infringement of the third patent pending a decision by the Federal Patent Court in a related nullity proceeding. On May 17, 2022, Centripetal withdrew its complaint for infringement of the German utility model. The German Court conducted a hearing on the remaining two Centripetal complaints on November 22, 2022. The German Court found no infringement on one patent and stayed the decision in the final case pending a decision by the European Patent Office in a related opposition proceeding.

[0000858877-23-000013:notes:211]
Due to uncertainty surrounding patent litigation processes in the U.S. and Europe, we are unable to reasonably estimate the ultimate outcome of the litigations at this time. If we do not prevail in either litigation, we believe that any damages ultimately assessed would not have a material effect on our Consolidated Financial Statements.

[0000858877-23-000013:notes:212]
Ramot     On June 12, 2019, Ramot at Tel Aviv University Ltd. (“Ramot”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Texas (“E.D. Tex.”), seeking damages, including enhanced damages, and a royalty on future sales. Ramot alleges that certain Cisco optical transceiver modules and line cards infringe three patents. The U.S. Patent and Trademark Office (“PTO”) preliminarily found all asserted claims unpatentable in ex parte reexamination proceedings and the pending District Court case has been stayed. On February 26, 2021, Ramot asserted patent infringement claims against Acacia Communications, Inc. (“Acacia”) in the District of Delaware (“D. Del.”), seeking damages, including enhanced damages, and a royalty on future sales. Ramot alleges that certain Acacia optical transceiver modules and integrated circuits infringe two of the three patents that Ramot asserted in the E.D. Tex. case and this case is also stayed pending reexamination proceedings.

[0000858877-23-000013:notes:213]
On September 28, 2021 and May 24, 2022, Cisco and Acacia filed two declaratory judgment actions of noninfringement against Ramot in D. Del on other Ramot patents in the same family as those involved in the pending cases above. Ramot is asserting

[0000858877-23-000013:notes:214]
counterclaims for infringement of the same patents and seeks damages, including enhanced damages, and a royalty on future sales. While we believe that we have strong non-infringement and invalidity arguments in these litigations, and that Ramot’s damages theories in such cases are not supported by prevailing law, we are unable to reasonably estimate the ultimate outcome of these litigations at this time due to uncertainties in the litigation processes. If we do not prevail in court in these litigations, we believe any damages ultimately assessed would not have a material effect on our Consolidated Financial Statements.

[0000858877-23-000013:notes:215]
Viasat     On November 6, 2019, Viasat, Inc. (“Viasat”) filed suit against Acacia in the California Superior Court for San Diego County (“SDSC”), alleging contract and trade secret claims for certain Acacia products sold from January 1, 2019 forward (“Viasat 2019”). In May 2023, a judgment was entered against Cisco in Viasat 2019 for an amount that did not have a material effect on our Consolidated Financial Statements.

[0000858877-23-000013:notes:216]
On June 9, 2020, Viasat filed a third suit in SDSC alleging contract and trade secrets claims for sales of additional Acacia products (“Viasat 2020”). In October 2022, an amended complaint was filed in Viasat 2020 asserting the same claims but alleging additional information. We are unable to reasonably estimate the ultimate outcome of Viasat 2020 at this time due to uncertainties in the litigation processes. If we do not prevail, we believe that any relief ultimately assessed in Viasat 2020 will not have a material effect on our Consolidated Financial Statements.

[0000858877-23-000013:notes:217]
Egenera     On August 8, 2016, Egenera, Inc. (“Egenera”) asserted infringement claims against us in the U.S. District Court for the District of Massachusetts, alleging that Cisco’s Unified Computing System Manager infringes three patents. Egenera sought damages, including enhanced damages, and an injunction. Two of the asserted patents were dismissed, leaving Egenera’s infringement claim based on one asserted patent. On March 25, 2022, the PTO preliminarily found all of the asserted claims of the remaining patent unpatentable in ex parte reexamination proceedings. On August 15, 2022, after a jury trial for the remaining patent, the jury returned a verdict in favor of Cisco. The District Court denied Egenera’s post-trial motions, and Egenera filed an appeal to the Federal Circuit on January 13, 2023 and those proceedings are ongoing.
In addition to the above matters, we are subject to other legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, we do not believe that the ultimate costs to resolve these matters will have a material effect on our Consolidated Financial Statements. For additional information regarding intellectual property litigation, see “Part II, Item 1A. Risk Factors—We may be found to infringe on intellectual property rights of others” herein.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock

[0000858877-23-000013:notes:218]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these inventory purchase commitments with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000858877-23-000013:notes:219]
[same as prior period, unchanged from 0000858877-23-000005:notes:216]

[0000858877-23-000013:notes:220]
In September 2001, our Board of Directors authorized a stock repurchase program. As of April 29, 2023, the remaining authorized amount for stock repurchases under this program was approximately $12.2 billion with no termination date. A summary of the stock repurchase activity for fiscal 2023 and 2022 under the stock repurchase program, reported based on the trade date, is summarized as follows (in millions, except per-share amounts):

[0000858877-23-000013:notes:221]
| Quarter Ended |  | Shares |  | Weighted-Average Price per Share |  | Amount |
| Fiscal 2023 |  |  |  |  |  |  |
| April 29, 2023 |  | 25 |  | $ | 49.45 |  |  | $ | 1,259 |  |
| January 28, 2023 |  | 26 |  | $ | 47.72 |  |  | $ | 1,256 |  |
| October 29, 2022 |  | 12 |  | $ | 43.76 |  |  | $ | 502 |  |
| Fiscal 2022 |  |  |  |  |  |  |
| July 30, 2022 |  | 54 |  |  | $ | 44.02 |  |  | $ | 2,402 |  |
| April 30, 2022 |  | 5 |  |  | $ | 54.20 |  |  | $ | 252 |  |
| January 29, 2022 |  | 82 |  |  | $ | 58.36 |  |  | $ | 4,824 |  |
| October 30, 2021 |  | 5 |  |  | $ | 56.49 |  |  | $ | 256 |  |

[0000858877-23-000013:notes:222]
There were stock repurchases of $58 million and $70 million that were pending settlement as of April 29, 2023 and July 30, 2022, respectively.

[0000858877-23-000013:notes:223]
[same as prior period, unchanged from 0000858877-23-000005:notes:220]

[0000858877-23-000013:notes:224]
(b)    Dividends Declared

[0000858877-23-000013:notes:225]
On May 17, 2023, our Board of Directors declared a quarterly dividend of $0.39 per common share to be paid on July 26, 2023, to all stockholders of record as of the close of business on July 6, 2023. Future dividends will be subject to the approval of our Board of Directors.

[0000858877-23-000013:notes:226]
[same as prior period, unchanged from 0000858877-23-000005:notes:223]

[0000858877-23-000013:notes:227]
Under the terms of our Amended and Restated Certificate of Incorporation, the Board of Directors is authorized to issue preferred stock in one or more series and, in connection with the creation of such series, to fix by resolution the designation, powers (including voting powers (if any)), preferences and relative, participating, optional or other special rights, if any, of such series, and any qualifications, limitations or restrictions thereof, of the shares of such series. As of April 29, 2023, we had not issued any shares of preferred stock.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000858877-23-000013:notes:228]
[same as prior period, unchanged from 0000858877-23-000005:notes:225]

[0000858877-23-000013:notes:229]
[same as prior period, unchanged from 0000858877-23-000005:notes:226]

[0000858877-23-000013:notes:230]
[same as prior period, unchanged from 0000858877-23-000005:notes:227]

[0000858877-23-000013:notes:231]
Under the 2005 Plan’s share reserve feature, a distinction is made between the number of shares in the reserve attributable to (i) stock options and SARs and (ii) “full value” awards (i.e., stock grants and stock units). Shares issued as stock grants, pursuant to stock units or pursuant to the settlement of dividend equivalents are counted against shares available for issuance under the 2005 Plan on a 1.5-to-1 ratio. For each share awarded as restricted stock or a restricted stock unit award under the 2005 Plan, 1.5 shares was deducted from the available share-based award balance. If awards issued under the 2005 Plan are forfeited or terminated for any reason before being exercised or settled, then the shares underlying such awards, plus the number of additional shares, if any, that counted against shares available for issuance under the 2005 Plan at the time of grant as a result of the application of the share ratio described above, will become available again for issuance under the 2005 Plan. As of April 29, 2023, 139 million shares were authorized for future grant under the 2005 Plan.

[0000858877-23-000013:notes:232]
[same as prior period, unchanged from 0000858877-23-000005:notes:229]

[0000858877-23-000013:notes:233]
We have an Employee Stock Purchase Plan under which eligible employees are offered shares through a 24-month offering period, which consists of four consecutive 6-month purchase periods. Employees may purchase a limited amount of shares of our stock at a discount of up to 15% of the lesser of the fair market value at the beginning of the offering period or the end of each 6-month purchase period. The Employee Stock Purchase Plan is scheduled to terminate on the earlier of (i) January 3, 2030 and (ii) the date on which all shares available for issuance under the Employee Stock Purchase Plan are sold pursuant to exercised purchase rights. No shares were issued under the Employee Stock Purchase Plan during each of the third quarters of fiscal 2023 and 2022. We issued 9 million and 8 million shares during the first nine months of fiscal 2023 and 2022, respectively. As of April 29, 2023, 98 million shares were available for issuance under the Employee Stock Purchase Plan.

[0000858877-23-000013:notes:234]
[same as prior period, unchanged from 0000858877-23-000005:notes:231]

[0000858877-23-000013:notes:235]
[same as prior period, unchanged from 0000858877-23-000005:notes:232]

[0000858877-23-000013:notes:236]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 29, 2023 |  | April 30, 2022 |  | April 29, 2023 |  | April 30, 2022 |
| Cost of sales—product | $ | 40 |  |  | $ | 30 |  |  | $ | 111 |  |  | $ | 84 |  |
| Cost of sales—service | 66 |  |  | 53 |  |  | 182 |  |  | 149 |  |
| Share-based compensation expense in cost of sales | 106 |  |  | 83 |  |  | 293 |  |  | 233 |  |
| Research and development | 272 |  |  | 205 |  |  | 737 |  |  | 591 |  |
| Sales and marketing | 175 |  |  | 139 |  |  | 494 |  |  | 421 |  |
| General and administrative | 71 |  |  | 50 |  |  | 200 |  |  | 161 |  |
| Restructuring and other charges | (1) |  |  | — |  |  | (4) |  |  | 1 |  |
| Share-based compensation expense in operating expenses | 517 |  |  | 394 |  |  | 1,427 |  |  | 1,174 |  |
| Total share-based compensation expense | $ | 623 |  |  | $ | 477 |  |  | $ | 1,720 |  |  | $ | 1,407 |  |
| Income tax benefit for share-based compensation | $ | 111 |  |  | $ | 122 |  |  | $ | 319 |  |  | $ | 378 |  |

[0000858877-23-000013:notes:237]
As of April 29, 2023, the total compensation cost related to unvested share-based awards not yet recognized was $4.6 billion which is expected to be recognized over approximately 2.3 years on a weighted-average basis.

[0000858877-23-000013:notes:238]
[same as prior period, unchanged from 0000858877-23-000005:notes:235]

[0000858877-23-000013:notes:239]
[same as prior period, unchanged from 0000858877-23-000005:notes:236]

[0000858877-23-000013:notes:240]
|  | Restricted Stock/Stock Units |  | Weighted-AverageGrant Date FairValue per Share |  | Aggregate Fair Value |
| Unvested balance at July 31, 2021 | 94 |  |  | $ | 42.93 |  |  |  |
| Granted and assumed | 52 |  |  | 50.06 |  |  |  |
| Vested | (37) |  |  | 42.27 |  |  | $ | 1,979 |  |
| Canceled/forfeited/other | (12) |  |  | 45.63 |  |  |  |
| Unvested balance at July 30, 2022 | 97 |  |  | $ | 46.67 |  |  |  |
| Granted and assumed | 58 |  |  | 40.87 |  |  |  |
| Vested | (29) |  |  | 47.24 |  |  | $ | 1,303 |  |
| Canceled/forfeited/other | (8) |  |  | 45.34 |  |  |  |
| Unvested balance at April 29, 2023 | 118 |  |  | $ | 43.76 |  |  |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000858877-23-000013:notes:241]
Comprehensive Income (Loss)
The components of AOCI, net of tax, and the other comprehensive income (loss), for the first nine months of fiscal 2023 and 2022 are summarized as follows (in millions):

[0000858877-23-000013:notes:242]
|  | Net Unrealized Gains (Losses) on Available-for-Sale Investments |  | Net Unrealized Gains (Losses) Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Actuarial Gains (Losses) |  | Accumulated Other Comprehensive Income (Loss) |
| Balance at July 30, 2022 | $ | (379) |  |  | $ | 44 |  |  | $ | (1,287) |  |  | $ | (1,622) |  |
| Other comprehensive income (loss) before reclassifications | (39) |  |  | 5 |  |  | 42 |  |  | 8 |  |
| (Gains) losses reclassified out of AOCI | 15 |  |  | (50) |  |  | — |  |  | (35) |  |
| Tax benefit (expense) | 8 |  |  | 11 |  |  | 24 |  |  | 43 |  |
| Balance at April 29, 2023 | $ | (395) |  |  | $ | 10 |  |  | $ | (1,221) |  |  | $ | (1,606) |  |

[0000858877-23-000013:notes:243]
|  | Net Unrealized Gains (Losses) on Available-for-Sale Investments |  | Net Unrealized Gains (Losses) Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Actuarial Gains (Losses) |  | Accumulated Other Comprehensive Income (Loss) |
| Balance at July 31, 2021 | $ | 182 |  |  | $ | (1) |  |  | $ | (598) |  |  | $ | (417) |  |
| Other comprehensive income (loss) before reclassifications | (717) |  |  | 63 |  |  | (485) |  |  | (1,139) |  |
| (Gains) losses reclassified out of AOCI | (18) |  |  | (15) |  |  | 1 |  |  | (32) |  |
| Tax benefit (expense) | 127 |  |  | (11) |  |  | 9 |  |  | 125 |  |
| Balance at April 30, 2022 | $ | (426) |  |  | $ | 36 |  |  | $ | (1,073) |  |  | $ | (1,463) |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000858877-23-000013:notes:244]
[same as prior period, unchanged from 0000858877-23-000005:notes:241]

[0000858877-23-000013:notes:245]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 29,2023 |  | April 30,2022 |  | April 29,2023 |  | April 30,2022 |
| Income before provision for income taxes | $ | 3,957 |  |  | $ | 3,801 |  |  | $ | 10,847 |  |  | $ | 11,061 |  |
| Provision for income taxes | $ | 745 |  |  | $ | 757 |  |  | $ | 2,192 |  |  | $ | 2,064 |  |
| Effective tax rate | 18.8 | % |  | 19.9 | % |  | 20.2 | % |  | 18.7 | % |

[0000858877-23-000013:notes:246]
As of April 29, 2023, we had $3.4 billion of unrecognized tax benefits, of which $2.4 billion, if recognized, would favorably impact the effective tax rate. We regularly engage in discussions and negotiations with tax authorities regarding tax matters in various jurisdictions. We believe it is reasonably possible that certain federal, foreign, and state tax matters may be concluded in the next 12 months. Specific positions that may be resolved include issues involving transfer pricing and various other matters.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000858877-23-000013:notes:247]
[same as prior period, unchanged from 0000858877-23-000005:notes:244]

[0000858877-23-000013:notes:248]
We conduct business globally and are primarily managed on a geographic basis consisting of three segments: the Americas, EMEA, and APJC. Our management makes financial decisions and allocates resources based on the information it receives from our internal management system. Sales are attributed to a segment based on the ordering location of the customer. We do not allocate research and development, sales and marketing, or general and administrative expenses to our segments in this internal management system because management does not include the information in our measurement of the performance of the operating segments. In addition, we do not allocate amortization and impairment of acquisition-related intangible assets, share-based compensation expense, significant litigation settlements and other contingencies, charges related to asset impairments and restructurings, and certain other charges to the gross margin for each segment because management does not include this information in our measurement of the performance of the operating segments.

[0000858877-23-000013:notes:249]
Summarized financial information by segment for the third quarter and first nine months of fiscal 2023 and 2022, based on our internal management system and as utilized by our Chief Operating Decision Maker (“CODM”), is as follows (in millions):

[0000858877-23-000013:notes:250]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 29,2023 |  | April 30,2022 |  | April 29,2023 |  | April 30,2022 |
| Revenue: |  |  |  |  |  |  |  |
| Americas | $ | 8,634 |  |  | $ | 7,638 |  |  | $ | 24,372 |  |  | $ | 22,344 |  |
| EMEA | 3,806 |  |  | 3,271 |  |  | 11,209 |  |  | 10,138 |  |
| APJC | 2,131 |  |  | 1,926 |  |  | 6,214 |  |  | 5,972 |  |
| Total | $ | 14,571 |  |  | $ | 12,835 |  |  | $ | 41,795 |  |  | $ | 38,455 |  |
| Gross margin: |  |  |  |  |  |  |  |
| Americas | $ | 5,545 |  |  | $ | 4,952 |  |  | $ | 15,449 |  |  | $ | 14,438 |  |
| EMEA | 2,536 |  |  | 2,154 |  |  | 7,330 |  |  | 6,664 |  |
| APJC | 1,415 |  |  | 1,279 |  |  | 3,986 |  |  | 3,934 |  |
| Segment total | 9,495 |  |  | 8,386 |  |  | 26,764 |  |  | 25,035 |  |
| Unallocated corporate items | (263) |  |  | (265) |  |  | (759) |  |  | (812) |  |
| Total | $ | 9,232 |  |  | $ | 8,121 |  |  | $ | 26,005 |  |  | $ | 24,223 |  |

[0000858877-23-000013:notes:251]
[same as prior period, unchanged from 0000858877-23-000005:notes:248]

[0000858877-23-000013:notes:252]
Revenue in the United States was $7.7 billion and $6.9 billion for the third quarter of fiscal 2023 and 2022, respectively, and $21.7 billion and $20.1 billion for the first nine months of fiscal 2023 and 2022, respectively.

[0000858877-23-000013:notes:253]
[same as prior period, unchanged from 0000858877-23-000005:notes:250]

[0000858877-23-000013:notes:254]
[same as prior period, unchanged from 0000858877-23-000005:notes:251]


## us-gaap:EarningsPerShareTextBlock

[0000858877-23-000013:notes:255]
[same as prior period, unchanged from 0000858877-23-000005:notes:252]

[0000858877-23-000013:notes:256]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 29,2023 |  | April 30,2022 |  | April 29,2023 |  | April 30,2022 |
| Net income | $ | 3,212 |  |  | $ | 3,044 |  |  | $ | 8,655 |  |  | $ | 8,997 |  |
| Weighted-average shares—basic | 4,089 |  |  | 4,152 |  |  | 4,100 |  |  | 4,184 |  |
| Effect of dilutive potential common shares | 21 |  |  | 18 |  |  | 11 |  |  | 20 |  |
| Weighted-average shares—diluted | 4,110 |  |  | 4,170 |  |  | 4,111 |  |  | 4,204 |  |
| Net income per share—basic | $ | 0.79 |  |  | $ | 0.73 |  |  | $ | 2.11 |  |  | $ | 2.15 |  |
| Net income per share—diluted | $ | 0.78 |  |  | $ | 0.73 |  |  | $ | 2.11 |  |  | $ | 2.14 |  |
| Antidilutive employee share-based awards, excluded | 24 |  |  | 11 |  |  | 75 |  |  | 46 |  |
