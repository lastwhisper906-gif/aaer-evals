# CSCO MD&A — 0000858877-23-000013


## mdna

[0000858877-23-000013:mdna:1]
[same as prior period, unchanged from 0000858877-23-000005:mdna:1]

[0000858877-23-000013:mdna:2]
[same as prior period, unchanged from 0000858877-23-000005:mdna:2]

[0000858877-23-000013:mdna:3]
[same as prior period, unchanged from 0000858877-23-000005:mdna:3]

[0000858877-23-000013:mdna:4]
[same as prior period, unchanged from 0000858877-23-000005:mdna:4]

[0000858877-23-000013:mdna:5]
[same as prior period, unchanged from 0000858877-23-000005:mdna:5]

[0000858877-23-000013:mdna:6]
|  | Three Months Ended |  | Nine Months Ended |  |
|  | April 29,2023 |  | April 30,2022 |  | % Variance |  | April 29,2023 |  | April 30,2022 |  | % Variance |  |
| Revenue | $ | 14,571 |  |  | $ | 12,835 |  |  | 14 | % |  | $ | 41,795 |  |  | $ | 38,455 |  |  | 9 | % |  |
| Gross margin percentage | 63.4 | % |  | 63.3 | % |  | 0.1 |  | pts | 62.2 | % |  | 63.0 | % |  | (0.8) |  | pts |
| Research and development | $ | 1,962 |  |  | $ | 1,708 |  |  | 15 | % |  | $ | 5,598 |  |  | $ | 5,092 |  |  | 10 | % |  |
| Sales and marketing | $ | 2,526 |  |  | $ | 2,209 |  |  | 14 | % |  | $ | 7,301 |  |  | $ | 6,736 |  |  | 8 | % |  |
| General and administrative | $ | 641 |  |  | $ | 517 |  |  | 24 | % |  | $ | 1,788 |  |  | $ | 1,612 |  |  | 11 | % |  |
| Total research and development, sales and marketing, general and administrative | $ | 5,129 |  |  | $ | 4,434 |  |  | 16 | % |  | $ | 14,687 |  |  | $ | 13,440 |  |  | 9 | % |  |
| Total as a percentage of revenue | 35.2 | % |  | 34.5 | % |  | 0.7 |  | pts | 35.1 | % |  | 34.9 | % |  | 0.2 |  | pts |
| Amortization of purchased intangible assets included in operating expenses | $ | 70 |  |  | $ | 77 |  |  | (9) | % |  | $ | 212 |  |  | $ | 240 |  |  | (12) | % |  |
| Restructuring and other charges included in operating expenses | $ | 87 |  |  | $ | — |  |  | NM |  | $ | 328 |  |  | $ | 8 |  |  | NM |  |
| Operating income as a percentage of revenue | 27.1 | % |  | 28.1 | % |  | (1.0) |  | pts | 25.8 | % |  | 27.4 | % |  | (1.6) |  | pts |
| Interest and other income (loss), net | $ | 11 |  |  | $ | 191 |  |  | (94) | % |  | $ | 69 |  |  | $ | 526 |  |  | (87) | % |  |
| Income tax percentage | 18.8 | % |  | 19.9 | % |  | (1.1) |  | pts | 20.2 | % |  | 18.7 | % |  | 1.5 |  | pts |
| Net income | $ | 3,212 |  |  | $ | 3,044 |  |  | 6 | % |  | $ | 8,655 |  |  | $ | 8,997 |  |  | (4) | % |  |
| Net income as a percentage of revenue | 22.0 | % |  | 23.7 | % |  | (1.7) |  | pts | 20.7 | % |  | 23.4 | % |  | (2.7) |  | pts |
| Earnings per share—diluted | $ | 0.78 |  |  | $ | 0.73 |  |  | 7 | % |  | $ | 2.11 |  |  | $ | 2.14 |  |  | (1) | % |  |

[0000858877-23-000013:mdna:7]
[same as prior period, unchanged from 0000858877-23-000005:mdna:7]

[0000858877-23-000013:mdna:8]
[same as prior period, unchanged from 0000858877-23-000005:mdna:8]

[0000858877-23-000013:mdna:9]
[same as prior period, unchanged from 0000858877-23-000005:mdna:9]

[0000858877-23-000013:mdna:10]
[same as prior period, unchanged from 0000858877-23-000005:mdna:10]

[0000858877-23-000013:mdna:11]
Three Months Ended April 29, 2023 Compared with Three Months Ended April 30, 2022

[0000858877-23-000013:mdna:12]
In the third quarter of fiscal 2023, we delivered strong results with growth in revenue and profitability. We remain focused on delivering innovation across our technologies to assist our customers in executing on their digital transformations. Over the last several quarters, we have taken multiple steps in order to mitigate the component shortages and address the supply constraints seen industry-wide. While supply constraints for certain components still remain, we continued to see an overall improvement of such constraints in the third quarter of fiscal 2023 and, as a result, we were able to increase the delivery of products to our customers, which positively impacted product revenue. Further, we continued to make progress in the transition of our business model delivering increased software and subscriptions. We remain focused on accelerating innovation across our portfolio, and we believe that we have made continued progress on our strategic priorities. We continue to operate in a challenging macroeconomic and highly competitive environment. While the overall environment remains uncertain, we continue to aggressively invest in priority areas with the objective of driving profitable growth over the long term.

[0000858877-23-000013:mdna:13]
Total revenue increased by 14% compared with the third quarter of fiscal 2022. Within total revenue, product revenue increased by 17% and service revenue increased by 3%. In the third quarter of fiscal 2023, total software revenue was $4.3 billion across all product areas and service, an increase of 18%. Within total software revenue, subscription revenue increased 17%. Total gross margin increased by 0.1 percentage points. Product gross margin increased by 0.9 percentage points, largely driven by favorable pricing and product mix partially offset by increased component and other costs. As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses, collectively, increased by 0.7 percentage points. Operating income as a percentage of revenue decreased by 1.0 percentage points. We incurred restructuring and other charges of $87 million in the third quarter of fiscal 2023. Diluted earnings per share increased 7%, driven by an increase of 6% in net income and a decrease in diluted share count of 60 million shares.

[0000858877-23-000013:mdna:14]
In terms of our geographic segments, revenue from the Americas increased $996 million, EMEA revenue increased by $535 million and APJC revenue increased by $205 million. From a customer market standpoint, we experienced product revenue growth in each of our customer markets. From a product category perspective, the product revenue increase of 17% was driven by growth in revenue for Secure, Agile Networks of 29%; Internet for the Future of 5%; End-to-End Security of 2%; and Optimized Application Experiences of 12%; partially offset by a product revenue decline in Collaboration of 13%.

[0000858877-23-000013:mdna:15]
We were able to increase the delivery of products to our customers as the overall supply constraints continued to improve during the third quarter of fiscal 2023. Although total revenue increased, we saw a decline in product demand compared to the third quarter of fiscal 2022. We believe this was due to customers absorbing recently shipped products prior to placing new orders, customers adjusting to significant reductions in product lead times reducing the need for extensive advanced ordering by our customers, and macroeconomic conditions.

[0000858877-23-000013:mdna:16]
[same as prior period, unchanged from 0000858877-23-000005:mdna:17]

[0000858877-23-000013:mdna:17]
[same as prior period, unchanged from 0000858877-23-000005:mdna:18]

[0000858877-23-000013:mdna:18]
Nine Months Ended April 29, 2023 Compared with Nine Months Ended April 30, 2022

[0000858877-23-000013:mdna:19]
Total revenue increased 9%, with product revenue increasing 11% and service revenue increasing 2%. Total gross margin decreased 0.8 percentage points due to increased costs related to supply constraints, partially offset by favorable pricing and favorable impacts from product mix. As a percentage of revenue, research, and development, sales and marketing, and general and administrative expenses collectively increased by 0.2 percentage points. Operating income as a percentage of revenue decreased by 1.6 percentage points. We incurred restructuring and other charges of $328 million in the first nine months of fiscal 2023. Diluted earnings per share decreased 1%, driven by a decrease of 4% in net income, partially offset by a decrease in diluted share count of 93 million shares.

[0000858877-23-000013:mdna:20]
[same as prior period, unchanged from 0000858877-23-000005:mdna:21]

[0000858877-23-000013:mdna:21]
[same as prior period, unchanged from 0000858877-23-000005:mdna:22]

[0000858877-23-000013:mdna:22]
[same as prior period, unchanged from 0000858877-23-000005:mdna:23]

[0000858877-23-000013:mdna:23]
[same as prior period, unchanged from 0000858877-23-000005:mdna:24]

[0000858877-23-000013:mdna:24]
The following is a summary of our other key financial measures for the third quarter of fiscal 2023 (in millions):

[0000858877-23-000013:mdna:25]
|  |  | April 29,2023 |  | July 30,2022 |
| Cash and cash equivalents and investments |  | $ | 23,288 |  |  | $ | 19,267 |  |
| Remaining performance obligations |  | $ | 32,082 |  |  | $ | 31,539 |  |
| Inventories |  | $ | 3,474 |  |  | $ | 2,568 |  |

[0000858877-23-000013:mdna:26]
|  |  | Nine Months Ended |
|  |  | April 29,2023 |  | April 30,2022 |
| Cash provided by operating activities |  | $ | 13,920 |  |  | $ | 9,549 |  |
| Repurchases of common stock—stock repurchase program |  | $ | 3,017 |  |  | $ | 5,332 |  |
| Dividends paid |  | $ | 4,713 |  |  | $ | 4,657 |  |

[0000858877-23-000013:mdna:27]
[same as prior period, unchanged from 0000858877-23-000005:mdna:28]

[0000858877-23-000013:mdna:28]
[same as prior period, unchanged from 0000858877-23-000005:mdna:29]

[0000858877-23-000013:mdna:29]
[same as prior period, unchanged from 0000858877-23-000005:mdna:30]

[0000858877-23-000013:mdna:30]
[same as prior period, unchanged from 0000858877-23-000005:mdna:31]

[0000858877-23-000013:mdna:31]
[same as prior period, unchanged from 0000858877-23-000005:mdna:32]

[0000858877-23-000013:mdna:32]
[same as prior period, unchanged from 0000858877-23-000005:mdna:33]

[0000858877-23-000013:mdna:33]
[same as prior period, unchanged from 0000858877-23-000005:mdna:34]

[0000858877-23-000013:mdna:34]
[same as prior period, unchanged from 0000858877-23-000005:mdna:35]

[0000858877-23-000013:mdna:35]
[same as prior period, unchanged from 0000858877-23-000005:mdna:36]

[0000858877-23-000013:mdna:36]
[same as prior period, unchanged from 0000858877-23-000005:mdna:37]

[0000858877-23-000013:mdna:37]
[same as prior period, unchanged from 0000858877-23-000005:mdna:38]

[0000858877-23-000013:mdna:38]
[same as prior period, unchanged from 0000858877-23-000005:mdna:39]

[0000858877-23-000013:mdna:39]
[same as prior period, unchanged from 0000858877-23-000005:mdna:40]

[0000858877-23-000013:mdna:40]
[same as prior period, unchanged from 0000858877-23-000005:mdna:41]

[0000858877-23-000013:mdna:41]
[same as prior period, unchanged from 0000858877-23-000005:mdna:42]

[0000858877-23-000013:mdna:42]
[same as prior period, unchanged from 0000858877-23-000005:mdna:43]

[0000858877-23-000013:mdna:43]
Our provision for inventory was $174 million and $72 million for the first nine months of fiscal 2023 and 2022, respectively. The provision for the liability related to purchase commitments with contract manufacturers and suppliers was $333 million and $130 million for the first nine months of fiscal 2023 and 2022, respectively. If there were to be a sudden and significant decrease in demand for our products, if there were a higher incidence of inventory obsolescence because of rapidly changing technology and customer requirements, or if supply constraints were to continue, we could be required to increase our inventory write-downs, and our liability for purchase commitments with contract manufacturers and suppliers, and accordingly our profitability, could be adversely affected. We regularly evaluate our exposure for inventory write-downs and the adequacy of our liability for purchase commitments. While supply constraints for certain components still remain, we continued to see an overall improvement of such constraints in the third quarter of fiscal 2023. We continue to manage through remaining supply constraints seen industry-wide due to shortages of certain components. For further discussion around the Supply Constraints Impacts and Risks, see “Result of Operations—Product Gross Margin—Supply Constraints Impact and Risks” and “Liquidity and Capital Resources—Inventory Supply Chain.”

[0000858877-23-000013:mdna:44]
Loss Contingencies

[0000858877-23-000013:mdna:45]
We are subject to the possibility of various losses arising in the ordinary course of business. We consider the likelihood of the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that a liability has been incurred and the amount of loss can be reasonably estimated. We regularly evaluate information available to us to determine whether such accruals should be made or adjusted and whether new accruals are required.

[0000858877-23-000013:mdna:46]
Third parties, including customers, have in the past and may in the future assert claims or initiate litigation related to exclusive patent, copyright, trademark, and other intellectual property rights to technologies and related standards that are relevant to us. These assertions have increased over time as a result of our growth and the general increase in the pace of patent claims assertions, particularly in the United States. If any infringement or other intellectual property claim made against us by any third party is successful, or if we fail to develop non-infringing technology or license the proprietary rights on commercially reasonable terms and conditions, our business, operating results, and financial condition could be materially and adversely affected.

[0000858877-23-000013:mdna:47]
[same as prior period, unchanged from 0000858877-23-000005:mdna:48]

[0000858877-23-000013:mdna:48]
[same as prior period, unchanged from 0000858877-23-000005:mdna:49]

[0000858877-23-000013:mdna:49]
In response to changes in industry and market conditions, we could be required to strategically realign our resources and consider restructuring, disposing of, or otherwise exiting businesses, which could result in an impairment of goodwill. There was no impairment of goodwill in each of the first nine months of fiscal 2023 and 2022.

[0000858877-23-000013:mdna:50]
[same as prior period, unchanged from 0000858877-23-000005:mdna:51]

[0000858877-23-000013:mdna:51]
We make judgments about the recoverability of purchased intangible assets with finite lives whenever events or changes in circumstances indicate that an impairment may exist. Recoverability of purchased intangible assets with finite lives is measured by comparing the carrying amount of the asset to the future undiscounted cash flows the asset is expected to generate. We review indefinite-lived intangible assets for impairment annually or whenever events or changes in circumstances indicate that the asset might be impaired. If the asset is considered to be impaired, the amount of any impairment is measured as the difference between the carrying value and the fair value of the impaired asset. Assumptions and estimates about future values and remaining useful lives of our purchased intangible assets are complex and subjective. They can be affected by a variety of

[0000858877-23-000013:mdna:52]
[same as prior period, unchanged from 0000858877-23-000005:mdna:53]

[0000858877-23-000013:mdna:53]
[same as prior period, unchanged from 0000858877-23-000005:mdna:54]

[0000858877-23-000013:mdna:54]
factors, including external factors such as industry and economic trends, and internal factors such as changes in our business strategy and our internal forecasts. Our ongoing consideration of all the factors described previously could result in impairment charges in the future, which could adversely affect our net income.

[0000858877-23-000013:mdna:55]
[same as prior period, unchanged from 0000858877-23-000005:mdna:56]

[0000858877-23-000013:mdna:56]
We are subject to income taxes in the United States and numerous foreign jurisdictions. Our effective tax rates differ from the statutory rate, primarily due to the tax impact of state taxes, foreign operations, R&D tax credits, foreign-derived intangible income deductions, global intangible low-taxed income, tax audit settlements, nondeductible compensation, and international realignments. Our effective tax rate was 18.8% and 19.9% in the third quarter of fiscal 2023 and 2022, respectively, and 20.2% and 18.7% in the first nine months of fiscal 2023 and 2022, respectively.

[0000858877-23-000013:mdna:57]
[same as prior period, unchanged from 0000858877-23-000005:mdna:58]

[0000858877-23-000013:mdna:58]
[same as prior period, unchanged from 0000858877-23-000005:mdna:59]

[0000858877-23-000013:mdna:59]
[same as prior period, unchanged from 0000858877-23-000005:mdna:60]

[0000858877-23-000013:mdna:60]
[same as prior period, unchanged from 0000858877-23-000005:mdna:61]

[0000858877-23-000013:mdna:61]
[same as prior period, unchanged from 0000858877-23-000005:mdna:62]

[0000858877-23-000013:mdna:62]
[same as prior period, unchanged from 0000858877-23-000005:mdna:63]

[0000858877-23-000013:mdna:63]
[same as prior period, unchanged from 0000858877-23-000005:mdna:64]

[0000858877-23-000013:mdna:64]
[same as prior period, unchanged from 0000858877-23-000005:mdna:65]

[0000858877-23-000013:mdna:65]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 29,2023 |  | April 30,2022 |  | Variancein Dollars |  | Variance in Percent |  | April 29,2023 |  | April 30,2022 |  | Variancein Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 11,092 |  |  | $ | 9,448 |  |  | $ | 1,644 |  |  | 17 | % |  | $ | 31,492 |  |  | $ | 28,330 |  |  | $ | 3,162 |  |  | 11 | % |
| Percentage of revenue |  | 76.1 | % |  | 73.6 | % |  |  |  |  |  | 75.3 | % |  | 73.7 | % |  |  |  |  |
| Service |  | 3,479 |  |  | 3,387 |  |  | 92 |  |  | 3 | % |  | 10,303 |  |  | 10,125 |  |  | 178 |  |  | 2 | % |
| Percentage of revenue |  | 23.9 | % |  | 26.4 | % |  |  |  |  |  | 24.7 | % |  | 26.3 | % |  |  |  |  |
| Total |  | $ | 14,571 |  |  | $ | 12,835 |  |  | $ | 1,736 |  |  | 14 | % |  | $ | 41,795 |  |  | $ | 38,455 |  |  | $ | 3,340 |  |  | 9 | % |

[0000858877-23-000013:mdna:66]
[same as prior period, unchanged from 0000858877-23-000005:mdna:67]

[0000858877-23-000013:mdna:67]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 29,2023 |  | April 30,2022 |  | Variancein Dollars |  | Variance in Percent |  | April 29,2023 |  | April 30,2022 |  | Variancein Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 8,634 |  |  | $ | 7,638 |  |  | $ | 996 |  |  | 13 | % |  | $ | 24,372 |  |  | $ | 22,344 |  |  | $ | 2,028 |  |  | 9 | % |
| Percentage of revenue |  | 59.3 | % |  | 59.5 | % |  |  |  |  |  | 58.3 | % |  | 58.1 | % |  |  |  |  |
| EMEA |  | 3,806 |  |  | 3,271 |  |  | 535 |  |  | 16 | % |  | 11,209 |  |  | 10,138 |  |  | 1,071 |  |  | 11 | % |
| Percentage of revenue |  | 26.1 | % |  | 25.5 | % |  |  |  |  |  | 26.8 | % |  | 26.4 | % |  |  |  |  |
| APJC |  | 2,131 |  |  | 1,926 |  |  | 205 |  |  | 11 | % |  | 6,214 |  |  | 5,972 |  |  | 242 |  |  | 4 | % |
| Percentage of revenue |  | 14.6 | % |  | 15.0 | % |  |  |  |  |  | 14.9 | % |  | 15.5 | % |  |  |  |  |
| Total |  | $ | 14,571 |  |  | $ | 12,835 |  |  | $ | 1,736 |  |  | 14 | % |  | $ | 41,795 |  |  | $ | 38,455 |  |  | $ | 3,340 |  |  | 9 | % |

[0000858877-23-000013:mdna:68]
[same as prior period, unchanged from 0000858877-23-000005:mdna:69]

[0000858877-23-000013:mdna:69]
Three Months Ended April 29, 2023 Compared with Three Months Ended April 30, 2022

[0000858877-23-000013:mdna:70]
Total revenue increased by 14%. Product revenue increased by 17% and service revenue increased by 3%. Our total revenue reflected growth across each of our geographic segments.

[0000858877-23-000013:mdna:71]
In the third quarter of fiscal 2022, in connection with the Russian invasion of Ukraine, Cisco announced its intention to stop business operations in Russia and Belarus. The negative impact to total revenue was approximately $200 million in the third quarter of fiscal 2022, which included committed revenue we would have otherwise recognized, charges for uncollectible receivables, and other items.

[0000858877-23-000013:mdna:72]
[same as prior period, unchanged from 0000858877-23-000005:mdna:72]

[0000858877-23-000013:mdna:73]
Nine Months Ended April 29, 2023 Compared with Nine Months Ended April 30, 2022

[0000858877-23-000013:mdna:74]
Total revenue increased by 9%. Product revenue increased by 11% and service revenue increased by 2%. Our total revenue reflected growth across each of our geographic segments.

[0000858877-23-000013:mdna:75]
[same as prior period, unchanged from 0000858877-23-000005:mdna:75]

[0000858877-23-000013:mdna:76]
[same as prior period, unchanged from 0000858877-23-000005:mdna:76]

[0000858877-23-000013:mdna:77]
[same as prior period, unchanged from 0000858877-23-000005:mdna:77]

[0000858877-23-000013:mdna:78]
[same as prior period, unchanged from 0000858877-23-000005:mdna:78]

[0000858877-23-000013:mdna:79]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 29,2023 |  | April 30,2022 |  | Variancein Dollars |  | Variance in Percent |  | April 29,2023 |  | April 30,2022 |  | Variancein Dollars |  | Variancein Dollars |
| Product revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 6,519 |  |  | $ | 5,573 |  |  | $ | 946 |  |  | 17 | % |  | $ | 18,093 |  |  | $ | 16,223 |  |  | $ | 1,870 |  |  | 12 | % |
| Percentage of product revenue |  | 58.8 | % |  | 59.0 | % |  |  |  |  |  | 57.5 | % |  | 57.3 | % |  |  |  |  |
| EMEA |  | 2,989 |  |  | 2,492 |  |  | 497 |  |  | 20 | % |  | 8,791 |  |  | 7,765 |  |  | 1,026 |  |  | 13 | % |
| Percentage of product revenue |  | 26.9 | % |  | 26.4 | % |  |  |  |  |  | 27.9 | % |  | 27.4 | % |  |  |  |  |
| APJC |  | 1,584 |  |  | 1,383 |  |  | 201 |  |  | 15 | % |  | 4,607 |  |  | 4,343 |  |  | 264 |  |  | 6 | % |
| Percentage of product revenue |  | 14.3 | % |  | 14.6 | % |  |  |  |  |  | 14.6 | % |  | 15.3 | % |  |  |  |  |
| Total |  | $ | 11,092 |  |  | $ | 9,448 |  |  | $ | 1,644 |  |  | 17 | % |  | $ | 31,492 |  |  | $ | 28,330 |  |  | $ | 3,162 |  |  | 11 | % |

[0000858877-23-000013:mdna:80]
[same as prior period, unchanged from 0000858877-23-000005:mdna:80]

[0000858877-23-000013:mdna:81]
[same as prior period, unchanged from 0000858877-23-000005:mdna:81]

[0000858877-23-000013:mdna:82]
Three Months Ended April 29, 2023 Compared with Three Months Ended April 30, 2022

[0000858877-23-000013:mdna:83]
Product revenue in the Americas segment increased by 17%, with growth across all customer markets. From a country perspective, product revenue increased in the United States, Canada, Mexico and Brazil by 16%, 7%, 55% and 30%, respectively.

[0000858877-23-000013:mdna:84]
Nine Months Ended April 29, 2023 Compared with Nine Months Ended April 30, 2022

[0000858877-23-000013:mdna:85]
Product revenue in the Americas segment increased by 12%, with growth across all customer markets. From a country perspective, product revenue increased in the United States, Canada, Mexico and Brazil by 11%, 10%, 29% and 29%, respectively.

[0000858877-23-000013:mdna:86]
[same as prior period, unchanged from 0000858877-23-000005:mdna:86]

[0000858877-23-000013:mdna:87]
Three Months Ended April 29, 2023 Compared with Three Months Ended April 30, 2022

[0000858877-23-000013:mdna:88]
Product revenue in the EMEA segment increased by 20%, driven by growth in the public sector, enterprise and commercial markets, partially offset by a decline in the service provider market. From a country perspective, product revenue increased in Germany, the United Kingdom and France by 20%, 17% and 12%, respectively.

[0000858877-23-000013:mdna:89]
Nine Months Ended April 29, 2023 Compared with Nine Months Ended April 30, 2022

[0000858877-23-000013:mdna:90]
Product revenue in the EMEA segment increased by 13%, driven by growth in the public sector, enterprise and commercial markets, partially offset by a decline in the service provider market. From a country perspective, product revenue increased in Germany, the United Kingdom and France by 21%, 8% and 23%, respectively.

[0000858877-23-000013:mdna:91]
[same as prior period, unchanged from 0000858877-23-000005:mdna:91]

[0000858877-23-000013:mdna:92]
Three Months Ended April 29, 2023 Compared with Three Months Ended April 30, 2022

[0000858877-23-000013:mdna:93]
Product revenue in the APJC segment increased by 15%, driven by growth across all customer markets. From a country perspective, product revenue increased in Japan, India, and Australia by 11%, 78%, and 25%, respectively. Product revenue for China was flat.

[0000858877-23-000013:mdna:94]
Nine Months Ended April 29, 2023 Compared with Nine Months Ended April 30, 2022

[0000858877-23-000013:mdna:95]
Product revenue in the APJC segment increased by 6%, driven by growth in the commercial and public sector markets, partially offset by a decline in the enterprise market. Product revenue in the service provider market was flat. From a country perspective, product revenue increased in India, Australia and China by 59%, 7% and 17%, respectively, partially offset by a decline in Japan of 4%.

[0000858877-23-000013:mdna:96]
[same as prior period, unchanged from 0000858877-23-000005:mdna:96]

[0000858877-23-000013:mdna:97]
[same as prior period, unchanged from 0000858877-23-000005:mdna:97]

[0000858877-23-000013:mdna:98]
[same as prior period, unchanged from 0000858877-23-000005:mdna:98]

[0000858877-23-000013:mdna:99]
[same as prior period, unchanged from 0000858877-23-000005:mdna:99]

[0000858877-23-000013:mdna:100]
[same as prior period, unchanged from 0000858877-23-000005:mdna:100]

[0000858877-23-000013:mdna:101]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 29,2023 |  | April 30,2022 |  | Variancein Dollars |  | Variance in Percent |  | April 29,2023 |  | April 30,2022 |  | Variancein Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Secure, Agile Networks |  | $ | 7,550 |  |  | $ | 5,870 |  |  | $ | 1,680 |  |  | 29 | % |  | $ | 20,980 |  |  | $ | 17,737 |  |  | $ | 3,243 |  |  | 18 | % |
| Internet for the Future |  | 1,392 |  |  | 1,324 |  |  | 68 |  |  | 5 | % |  | 4,007 |  |  | 4,019 |  |  | (12) |  |  | — | % |
| Collaboration |  | 985 |  |  | 1,132 |  |  | (147) |  |  | (13) | % |  | 3,029 |  |  | 3,308 |  |  | (279) |  |  | (8) | % |
| End-to-End Security |  | 958 |  |  | 938 |  |  | 20 |  |  | 2 | % |  | 2,872 |  |  | 2,716 |  |  | 156 |  |  | 6 | % |
| Optimized Application Experiences |  | 204 |  |  | 183 |  |  | 21 |  |  | 12 | % |  | 597 |  |  | 544 |  |  | 53 |  |  | 10 | % |
| Other Products |  | 3 |  |  | 2 |  |  | 1 |  |  | 19 | % |  | 7 |  |  | 7 |  |  | — |  |  | (7) | % |
| Total |  | $ | 11,092 |  |  | $ | 9,448 |  |  | $ | 1,644 |  |  | 17 | % |  | $ | 31,492 |  |  | $ | 28,330 |  |  | $ | 3,162 |  |  | 11 | % |

[0000858877-23-000013:mdna:102]
[same as prior period, unchanged from 0000858877-23-000005:mdna:102]

[0000858877-23-000013:mdna:103]
[same as prior period, unchanged from 0000858877-23-000005:mdna:103]

[0000858877-23-000013:mdna:104]
Three Months Ended April 29, 2023 Compared with Three Months Ended April 30, 2022

[0000858877-23-000013:mdna:105]
The Secure, Agile Networks product category represents our core networking offerings related to switching, enterprise routing, wireless, and compute. Secure, Agile Networks revenue increased by 29%, or $1.7 billion, with growth across the portfolio except servers. Revenue grew in both campus switching and data center switching. This was primarily driven by strong growth in our Catalyst 9000 series, Nexus 9000 series and Meraki switching offerings. The increase in enterprise routing was primarily driven by growth in our Catalyst 8000 routers, SD-WAN and IoT routing offerings. Wireless had strong double-digit growth driven by our WiFi-6 products and Meraki offerings.

[0000858877-23-000013:mdna:106]
Nine Months Ended April 29, 2023 Compared with Nine Months Ended April 30, 2022

[0000858877-23-000013:mdna:107]
Revenue from the Secure, Agile Networks product category increased by 18%, or $3.2 billion, with growth across the portfolio except servers. Revenue grew in both campus switching and data center switching, primarily driven by growth in our Catalyst 9000 series, Nexus 9000 series and Meraki switching offerings. Enterprise routing increased primarily driven by growth in our Catalyst 8000 series, SD-WAN and IoT routing offerings. Wireless had strong double-digit growth driven by our WiFi-6 products and Meraki offerings.

[0000858877-23-000013:mdna:108]
[same as prior period, unchanged from 0000858877-23-000005:mdna:108]

[0000858877-23-000013:mdna:109]
Three Months Ended April 29, 2023 Compared with Three Months Ended April 30, 2022

[0000858877-23-000013:mdna:110]
The Internet for the Future product category includes our routed optical networking, public 5G, silicon and optics offerings. Revenue in our Internet for the Future product category increased by 5%, or $68 million, primarily driven by growth in our Core routing portfolio, including our Cisco 8000 series offerings. We also saw double-digit growth in the webscale provider market.

[0000858877-23-000013:mdna:111]
Nine Months Ended April 29, 2023 Compared with Nine Months Ended April 30, 2022

[0000858877-23-000013:mdna:112]
Revenue in our Internet for the Future product category was flat, primarily driven by growth in our Cisco 8000 series offerings offset by declines in our Optical, Cable, and Edge portfolio. We also saw growth in the webscale provider market.

[0000858877-23-000013:mdna:113]
[same as prior period, unchanged from 0000858877-23-000005:mdna:113]

[0000858877-23-000013:mdna:114]
Three Months Ended April 29, 2023 Compared with Three Months Ended April 30, 2022

[0000858877-23-000013:mdna:115]
The Collaboration product category consists of our Collaboration Devices, Meetings, Calling and Contact Center offerings. Revenue in our Collaboration product category decreased by 13%, or $147 million, primarily driven by declines in Collaboration Devices and Meetings, partially offset by growth in Calling and our Contact Center offerings.

[0000858877-23-000013:mdna:116]
[same as prior period, unchanged from 0000858877-23-000005:mdna:116]

[0000858877-23-000013:mdna:117]
[same as prior period, unchanged from 0000858877-23-000005:mdna:117]

[0000858877-23-000013:mdna:118]
Nine Months Ended April 29, 2023 Compared with Nine Months Ended April 30, 2022

[0000858877-23-000013:mdna:119]
Revenue in our Collaboration product category decreased by 8%, or $279 million, primarily driven by declines in Meetings and Collaboration Devices.

[0000858877-23-000013:mdna:120]
[same as prior period, unchanged from 0000858877-23-000005:mdna:120]

[0000858877-23-000013:mdna:121]
Three Months Ended April 29, 2023 Compared with Three Months Ended April 30, 2022

[0000858877-23-000013:mdna:122]
Revenue in our End-to-End Security product category increased 2%, or $20 million primarily driven by growth in our Unified Threat Management and Zero Trust offerings.

[0000858877-23-000013:mdna:123]
Nine Months Ended April 29, 2023 Compared with Nine Months Ended April 30, 2022

[0000858877-23-000013:mdna:124]
Revenue in our End-to-End Security product category increased 6%, or $156 million primarily driven by growth in our Unified Threat Management offerings.

[0000858877-23-000013:mdna:125]
[same as prior period, unchanged from 0000858877-23-000005:mdna:125]

[0000858877-23-000013:mdna:126]
Three Months Ended April 29, 2023 Compared with Three Months Ended April 30, 2022

[0000858877-23-000013:mdna:127]
The Optimized Application Experiences product category includes our full stack observability and cloud-native platforms offerings. Revenue in our Optimized Application Experiences product category increased 12%, or $21 million, driven by growth across the portfolio, including double-digit growth in our ThousandEyes offerings.

[0000858877-23-000013:mdna:128]
Nine Months Ended April 29, 2023 Compared with Nine Months Ended April 30, 2022

[0000858877-23-000013:mdna:129]
Revenue in our Optimized Application Experiences product category increased 10%, or $53 million, driven by growth in our ThousandEyes offerings.

[0000858877-23-000013:mdna:130]
[same as prior period, unchanged from 0000858877-23-000005:mdna:130]

[0000858877-23-000013:mdna:131]
[same as prior period, unchanged from 0000858877-23-000005:mdna:131]

[0000858877-23-000013:mdna:132]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 29,2023 |  | April 30,2022 |  | Variancein Dollars |  | Variance in Percent |  | April 29,2023 |  | April 30,2022 |  | Variancein Dollars |  | Variance in Percent |
| Service revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 2,115 |  |  | $ | 2,064 |  |  | $ | 51 |  |  | 2 | % |  | $ | 6,279 |  |  | $ | 6,122 |  |  | $ | 157 |  |  | 3 | % |
| Percentage of service revenue |  | 60.8 | % |  | 60.9 | % |  |  |  |  |  | 60.9 | % |  | 60.5 | % |  |  |  |  |
| EMEA |  | 817 |  |  | 778 |  |  | 39 |  |  | 5 | % |  | 2,417 |  |  | 2,373 |  |  | 44 |  |  | 2 | % |
| Percentage of service revenue |  | 23.5 | % |  | 23.0 | % |  |  |  |  |  | 23.5 | % |  | 23.4 | % |  |  |  |  |
| APJC |  | 547 |  |  | 544 |  |  | 3 |  |  | 1 | % |  | 1,606 |  |  | 1,629 |  |  | (23) |  |  | (1) | % |
| Percentage of service revenue |  | 15.7 | % |  | 16.1 | % |  |  |  |  |  | 15.6 | % |  | 16.1 | % |  |  |  |  |
| Total |  | $ | 3,479 |  |  | $ | 3,387 |  |  | $ | 92 |  |  | 3 | % |  | $ | 10,303 |  |  | $ | 10,125 |  |  | $ | 178 |  |  | 2 | % |

[0000858877-23-000013:mdna:133]
[same as prior period, unchanged from 0000858877-23-000005:mdna:133]

[0000858877-23-000013:mdna:134]
Service revenue increased 3% in the third quarter of fiscal 2023 compared with the third quarter of fiscal 2022, primarily driven by revenue growth in our solution support offerings and maintenance business, partially offset by declines in our advisory services. Service revenue increased across each of our geographic segments for the third quarter of fiscal 2023.

[0000858877-23-000013:mdna:135]
Service revenue increased 2% in the first nine months of fiscal 2023 compared to the first nine months of fiscal 2022, primarily driven by revenue growth in our solution support offerings and maintenance business, partially offset by declines in our advisory services and software support offerings. Service revenue increased in the Americas and EMEA segments, partially offset by a decline in the APJC segment for the first nine months of fiscal 2023.

[0000858877-23-000013:mdna:136]
[same as prior period, unchanged from 0000858877-23-000005:mdna:136]

[0000858877-23-000013:mdna:137]
[same as prior period, unchanged from 0000858877-23-000005:mdna:137]

[0000858877-23-000013:mdna:138]
[same as prior period, unchanged from 0000858877-23-000005:mdna:138]

[0000858877-23-000013:mdna:139]
[same as prior period, unchanged from 0000858877-23-000005:mdna:139]

[0000858877-23-000013:mdna:140]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | AMOUNT |  | PERCENTAGE |  | AMOUNT |  | PERCENTAGE |
|  |  | April 29,2023 |  | April 30,2022 |  | April 29,2023 |  | April 30,2022 |  | April 29,2023 |  | April 30,2022 |  | April 29,2023 |  | April 30,2022 |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 6,956 |  |  | $ | 5,842 |  |  | 62.7 | % |  | 61.8 | % |  | $ | 19,139 |  |  | $ | 17,482 |  |  | 60.8 | % |  | 61.7 | % |
| Service |  | 2,276 |  |  | 2,279 |  |  | 65.4 | % |  | 67.3 | % |  | 6,866 |  |  | 6,741 |  |  | 66.6 | % |  | 66.6 | % |
| Total |  | $ | 9,232 |  |  | $ | 8,121 |  |  | 63.4 | % |  | 63.3 | % |  | $ | 26,005 |  |  | $ | 24,223 |  |  | 62.2 | % |  | 63.0 | % |

[0000858877-23-000013:mdna:141]
[same as prior period, unchanged from 0000858877-23-000005:mdna:141]

[0000858877-23-000013:mdna:142]
The following table summarizes the key factors that contributed to the change in product gross margin percentage for the third quarter and first nine months of fiscal 2023, as compared with the corresponding prior year periods:

[0000858877-23-000013:mdna:143]
|  |  | Product Gross Margin Percentage |
|  |  | Three Months Ended |  | Nine Months Ended |
| Fiscal 2022 |  | 61.8 | % |  | 61.7 | % |
| Productivity (1) |  | (1.4) | % |  | (3.5) | % |
| Product pricing |  | 1.1 | % |  | 1.4 | % |
| Mix of products sold |  | 0.8 | % |  | 0.7 | % |
| Others |  | 0.4 | % |  | 0.5 | % |
| Fiscal 2023 |  | 62.7 | % |  | 60.8 | % |

[0000858877-23-000013:mdna:144]
[same as prior period, unchanged from 0000858877-23-000005:mdna:144]

[0000858877-23-000013:mdna:145]
Three Months Ended April 29, 2023 Compared with Three Months Ended April 30, 2022

[0000858877-23-000013:mdna:146]
Product gross margin increased by 0.9 percentage points primarily driven by favorable pricing and product mix, partially offset by negative impacts from productivity, largely driven by increased costs from component and other costs. The favorable pricing was primarily driven by price increases implemented during fiscal 2022 as we ship our products. We implemented the price increases to partially offset increases in commodity and other costs.

[0000858877-23-000013:mdna:147]
Nine Months Ended April 29, 2023 Compared with Nine Months Ended April 30, 2022

[0000858877-23-000013:mdna:148]
Product gross margin decreased by 0.9 percentage points primarily driven by negative impacts from productivity, largely driven by increased costs from component, freight, logistics and other costs. These impacts were partially offset by favorable pricing. The benefit we saw from favorable pricing was primarily driven by price increases implemented during fiscal 2022. We also saw benefits from product mix.

[0000858877-23-000013:mdna:149]
[same as prior period, unchanged from 0000858877-23-000005:mdna:149]

[0000858877-23-000013:mdna:150]
While supply constraints for certain components still remain, we continued to see an overall improvement of such constraints in the third quarter of fiscal 2023. We continue to manage through remaining supply constraints seen industry-wide due to shortages of certain components. In recent past periods, these shortages have resulted in increased costs (i.e., component and other commodity costs, freight, expedite fees, etc.) which have had a negative impact on our product gross margin and have resulted in extended lead times for us and our customers. We have taken a number of steps in order to mitigate the supply constraint related impacts including: partnering with several of our key suppliers utilizing our volume purchasing ability and extending supply coverage, including, in certain cases, revising supplier arrangements; paying significantly higher component and logistics costs to secure supply; modifying our product designs in order to leverage alternate suppliers, where possible; and continually optimizing our inventory build and customer delivery plans, among others. We believe these actions are helping us to optimize our access to critical components and meet customer demand for our products. As a result of these past actions, in order to secure supply to meet customer demand, we increased our inventory balances, inventory purchase commitments, and

[0000858877-23-000013:mdna:151]
51

[0000858877-23-000013:mdna:152]
[same as prior period, unchanged from 0000858877-23-000005:mdna:151]

[0000858877-23-000013:mdna:153]
[same as prior period, unchanged from 0000858877-23-000005:mdna:152]

[0000858877-23-000013:mdna:154]
inventory deposits and prepayments compared to prior fiscal years, which, in turn, has increased our supply chain exposure. Additionally, in certain situations, we have prepaid or made deposits with suppliers to secure future supply. We have seen supply constraints improve in the current quarter and recent past quarters. As the overall supply constraints continue to improve, we have taken and are continuing to take operational measures to work with contract manufacturers and suppliers to optimize our combined inventory and purchase commitment levels. However, our higher level of supply chain balances increases the risk of material excess and obsolete inventory and related losses if customer demand were to suddenly and significantly decrease in future periods and we are unable to further mitigate our supply chain exposures.

[0000858877-23-000013:mdna:155]
[same as prior period, unchanged from 0000858877-23-000005:mdna:154]

[0000858877-23-000013:mdna:156]
Three Months Ended April 29, 2023 Compared with Three Months Ended April 30, 2022

[0000858877-23-000013:mdna:157]
Our service gross margin percentage decreased by 1.9 percentage points primarily due to higher headcount-related and delivery costs, partially offset by higher sales volume and favorable mix of service offerings.

[0000858877-23-000013:mdna:158]
[same as prior period, unchanged from 0000858877-23-000005:mdna:157]

[0000858877-23-000013:mdna:159]
Nine Months Ended April 29, 2023 Compared with Nine Months Ended April 30, 2022

[0000858877-23-000013:mdna:160]
Service gross margin was flat primarily due to higher sales volume and favorable mix of service offerings offset by higher headcount-related and delivery costs.

[0000858877-23-000013:mdna:161]
[same as prior period, unchanged from 0000858877-23-000005:mdna:160]

[0000858877-23-000013:mdna:162]
[same as prior period, unchanged from 0000858877-23-000005:mdna:161]

[0000858877-23-000013:mdna:163]
|  | Three Months Ended |  | Nine Months Ended |
|  | AMOUNT |  | PERCENTAGE |  | AMOUNT |  | PERCENTAGE |
|  | April 29,2023 |  | April 30,2022 |  | April 29,2023 |  | April 30,2022 |  | April 29,2023 |  | April 30,2022 |  | April 29,2023 |  | April 30,2022 |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 5,545 |  |  | $ | 4,952 |  |  | 64.2 | % |  | 64.8 | % |  | $ | 15,449 |  |  | $ | 14,438 |  |  | 63.4 | % |  | 64.6 | % |
| EMEA | 2,536 |  |  | 2,154 |  |  | 66.6 | % |  | 65.9 | % |  | 7,330 |  |  | 6,664 |  |  | 65.4 | % |  | 65.7 | % |
| APJC | 1,415 |  |  | 1,279 |  |  | 66.4 | % |  | 66.4 | % |  | 3,986 |  |  | 3,934 |  |  | 64.2 | % |  | 65.9 | % |
| Segment total | 9,495 |  |  | 8,386 |  |  | 65.2 | % |  | 65.3 | % |  | 26,764 |  |  | 25,035 |  |  | 64.0 | % |  | 65.1 | % |
| Unallocated corporate items (1) | (263) |  |  | (265) |  |  |  |  |  |  | (759) |  |  | (812) |  |  |  |  |  |
| Total | $ | 9,232 |  |  | $ | 8,121 |  |  | 63.4 | % |  | 63.3 | % |  | $ | 26,005 |  |  | $ | 24,223 |  |  | 62.2 | % |  | 63.0 | % |

[0000858877-23-000013:mdna:164]
(1) The unallocated corporate items include the effects of amortization and impairments of acquisition-related intangible assets, share-based compensation expense, significant litigation settlements and other contingencies, charges related to asset impairments and restructurings, and certain other charges. We do not allocate these items to the gross margin for each segment because management does not include such information in measuring the performance of the operating segments.

[0000858877-23-000013:mdna:165]
[same as prior period, unchanged from 0000858877-23-000005:mdna:164]

[0000858877-23-000013:mdna:166]
Three Months Ended April 29, 2023 Compared with Three Months Ended April 30, 2022

[0000858877-23-000013:mdna:167]
[same as prior period, unchanged from 0000858877-23-000005:mdna:166]

[0000858877-23-000013:mdna:168]
Gross margin in our EMEA segment increased primarily due to favorable pricing, positive impacts from productivity improvements and favorable product mix, partially offset by lower service gross margin.

[0000858877-23-000013:mdna:169]
The APJC segment gross margin percentage was flat primarily due to negative impacts from productivity offset by favorable product mix and favorable pricing.

[0000858877-23-000013:mdna:170]
[same as prior period, unchanged from 0000858877-23-000005:mdna:169]

[0000858877-23-000013:mdna:171]
[same as prior period, unchanged from 0000858877-23-000005:mdna:171]

[0000858877-23-000013:mdna:172]
[same as prior period, unchanged from 0000858877-23-000005:mdna:172]

[0000858877-23-000013:mdna:173]
Nine Months Ended April 29, 2023 Compared with Nine Months Ended April 30, 2022

[0000858877-23-000013:mdna:174]
[same as prior period, unchanged from 0000858877-23-000005:mdna:174]

[0000858877-23-000013:mdna:175]
The gross margin percentage decrease in our EMEA segment was primarily due to negative impacts from productivity, partially offset by favorable pricing.

[0000858877-23-000013:mdna:176]
The APJC segment gross margin percentage decrease was driven by negative impacts from productivity and, to a lesser extent, unfavorable impacts from pricing, partially offset by favorable product mix.

[0000858877-23-000013:mdna:177]
[same as prior period, unchanged from 0000858877-23-000005:mdna:177]

[0000858877-23-000013:mdna:178]
[same as prior period, unchanged from 0000858877-23-000005:mdna:178]

[0000858877-23-000013:mdna:179]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 29,2023 |  | April 30,2022 |  | Variancein Dollars |  | Variance in Percent |  | April 29,2023 |  | April 30,2022 |  | Variancein Dollars |  | Variance in Percent |
| Research and development | $ | 1,962 |  |  | $ | 1,708 |  |  | $ | 254 |  |  | 15 | % |  | $ | 5,598 |  |  | $ | 5,092 |  |  | $ | 506 |  |  | 10 | % |
| Percentage of revenue | 13.5 | % |  | 13.3 | % |  |  |  |  |  | 13.4 | % |  | 13.2 | % |  |  |  |  |
| Sales and marketing | 2,526 |  |  | 2,209 |  |  | 317 |  |  | 14 | % |  | 7,301 |  |  | 6,736 |  |  | 565 |  |  | 8 | % |
| Percentage of revenue | 17.3 | % |  | 17.2 | % |  |  |  |  |  | 17.5 | % |  | 17.5 | % |  |  |  |  |
| General and administrative | 641 |  |  | 517 |  |  | 124 |  |  | 24 | % |  | 1,788 |  |  | 1,612 |  |  | 176 |  |  | 11 | % |
| Percentage of revenue | 4.4 | % |  | 4.0 | % |  |  |  |  |  | 4.3 | % |  | 4.2 | % |  |  |  |  |
| Total | $ | 5,129 |  |  | $ | 4,434 |  |  | $ | 695 |  |  | 16 | % |  | $ | 14,687 |  |  | $ | 13,440 |  |  | $ | 1,247 |  |  | 9 | % |
| Percentage of revenue | 35.2 | % |  | 34.5 | % |  |  |  |  |  | 35.1 | % |  | 34.9 | % |  |  |  |  |

[0000858877-23-000013:mdna:180]
[same as prior period, unchanged from 0000858877-23-000005:mdna:180]

[0000858877-23-000013:mdna:181]
Three Months Ended April 29, 2023 Compared with Three Months Ended April 30, 2022

[0000858877-23-000013:mdna:182]
[same as prior period, unchanged from 0000858877-23-000005:mdna:182]

[0000858877-23-000013:mdna:183]
[same as prior period, unchanged from 0000858877-23-000005:mdna:183]

[0000858877-23-000013:mdna:184]
Nine Months Ended April 29, 2023 Compared with Nine Months Ended April 30, 2022

[0000858877-23-000013:mdna:185]
R&D expenses increased due to higher headcount-related expenses, higher share-based compensation expense and higher discretionary spending, partially offset by lower contracted services spending and lower acquisition and divestitures related costs.

[0000858877-23-000013:mdna:186]
[same as prior period, unchanged from 0000858877-23-000005:mdna:186]

[0000858877-23-000013:mdna:187]
Three Months Ended April 29, 2023 Compared with Three Months Ended April 30, 2022

[0000858877-23-000013:mdna:188]
Sales and marketing expenses increased primarily due to higher headcount-related expenses, driven by higher variable compensation expense, higher share-based compensation expense and higher discretionary spending, partially offset by lower contracted services spending.

[0000858877-23-000013:mdna:189]
Nine Months Ended April 29, 2023 Compared with Nine Months Ended April 30, 2022

[0000858877-23-000013:mdna:190]
[same as prior period, unchanged from 0000858877-23-000005:mdna:190]

[0000858877-23-000013:mdna:191]
[same as prior period, unchanged from 0000858877-23-000005:mdna:191]

[0000858877-23-000013:mdna:192]
Three Months Ended April 29, 2023 Compared with Three Months Ended April 30, 2022

[0000858877-23-000013:mdna:193]
G&A expenses increased due to higher headcount-related expenses, higher discretionary spending, higher share-based

[0000858877-23-000013:mdna:194]
53

[0000858877-23-000013:mdna:195]
[same as prior period, unchanged from 0000858877-23-000005:mdna:193]

[0000858877-23-000013:mdna:196]
[same as prior period, unchanged from 0000858877-23-000005:mdna:194]

[0000858877-23-000013:mdna:197]
compensation expense, higher acquisition and divestitures related costs and higher contracted services spending. The increase was partially offset by the impact from certain non-recurring charges recognized due to the Russia and Ukraine war in the third quarter of fiscal 2022.

[0000858877-23-000013:mdna:198]
Nine Months Ended April 29, 2023 Compared with Nine Months Ended April 30, 2022

[0000858877-23-000013:mdna:199]
G&A expenses increased due to higher headcount-related expenses, higher discretionary spending and higher share-based compensation expense, partially offset by lower acquisition and divestitures related costs, lower contracted services spending and the impact from certain non-recurring charges recognized due to the Russia and Ukraine war in the first nine months of fiscal 2022.

[0000858877-23-000013:mdna:200]
[same as prior period, unchanged from 0000858877-23-000005:mdna:195]

[0000858877-23-000013:mdna:201]
In the third quarter of fiscal 2023, foreign currency fluctuations, net of hedging, decreased the combined R&D, sales and marketing, and G&A expenses by approximately $86 million, or 1.9%, compared with the third quarter of fiscal 2022.

[0000858877-23-000013:mdna:202]
In the first nine months of fiscal 2023, foreign currency fluctuations, net of hedging, decreased the combined R&D, sales and marketing, and G&A expenses by approximately $349 million, or 2.6%, compared with the first nine months of fiscal 2022.

[0000858877-23-000013:mdna:203]
[same as prior period, unchanged from 0000858877-23-000005:mdna:198]

[0000858877-23-000013:mdna:204]
[same as prior period, unchanged from 0000858877-23-000005:mdna:199]

[0000858877-23-000013:mdna:205]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 29,2023 |  | April 30,2022 |  | April 29,2023 |  | April 30,2022 |
| Amortization of purchased intangible assets: |  |  |  |  |  |  |  |  |
| Cost of sales |  | $ | 160 |  |  | $ | 180 |  |  | $ | 476 |  |  | $ | 583 |  |
| Operating expenses |  | 70 |  |  | 92 |  |  | 212 |  |  | 255 |  |
| Total |  | $ | 230 |  |  | $ | 272 |  |  | $ | 688 |  |  | $ | 838 |  |

[0000858877-23-000013:mdna:206]
For each of the third quarter and first nine months of fiscal 2023, the decrease in amortization of purchased intangible assets was primarily due to certain purchased intangible assets that became fully amortized, partially offset by amortization of purchased intangibles from our recent acquisitions.

[0000858877-23-000013:mdna:207]
[same as prior period, unchanged from 0000858877-23-000005:mdna:202]

[0000858877-23-000013:mdna:208]
In the second quarter of fiscal 2023, we announced a restructuring plan in order to rebalance the organization and enable further investment in key priority areas. This rebalancing includes talent movement options and restructuring. Additionally, we have begun optimizing our real estate portfolio, aligned to the broader hybrid work strategy. The total pretax charges are estimated to be approximately $600 million and is expected to impact approximately 5% of our global workforce. In connection with this restructuring plan, we incurred charges of $87 million and $330 million in the third quarter and the first nine months of fiscal 2023, respectively. We expect the plan to be substantially completed by the end of the first quarter of fiscal 2024. We expect to reinvest substantially all of the cost savings from this restructuring plan in our key priority areas. As a result, the overall cost savings from this restructuring plan are not expected to be material for future periods.

[0000858877-23-000013:mdna:209]
[same as prior period, unchanged from 0000858877-23-000005:mdna:204]

[0000858877-23-000013:mdna:210]
[same as prior period, unchanged from 0000858877-23-000005:mdna:205]

[0000858877-23-000013:mdna:211]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 29,2023 |  | April 30,2022 |  | April 29,2023 |  | April 30,2022 |
| Operating income |  | $ | 3,946 |  |  | $ | 3,610 |  |  | $ | 10,778 |  |  | $ | 10,535 |  |
| Operating income as a percentage of revenue |  | 27.1 | % |  | 28.1 | % |  | 25.8 | % |  | 27.4 | % |

[0000858877-23-000013:mdna:212]
Three Months Ended April 29, 2023 Compared with Three Months Ended April 30, 2022

[0000858877-23-000013:mdna:213]
Operating income increased by 9%, and operating income as a percentage of revenue decreased by 1.0 percentage points. The increase in operating income was primarily due to a revenue increase partially offset by higher operating expenses. The decrease in operating income as a percentage of revenue was primarily due to an operating expenses percentage increase.

[0000858877-23-000013:mdna:214]
[same as prior period, unchanged from 0000858877-23-000005:mdna:211]

[0000858877-23-000013:mdna:215]
[same as prior period, unchanged from 0000858877-23-000005:mdna:212]

[0000858877-23-000013:mdna:216]
[same as prior period, unchanged from 0000858877-23-000005:mdna:213]

[0000858877-23-000013:mdna:217]
Nine Months Ended April 29, 2023 Compared with Nine Months Ended April 30, 2022

[0000858877-23-000013:mdna:218]
Operating income increased by 2%, and operating income as a percentage of revenue decreased by 1.6 percentage points. The increase in operating income was primarily due to a revenue increase, partially offset by a gross margin percentage decrease (driven by negative impacts from productivity partially offset by favorable pricing and favorable product mix) and higher operating expenses. The decrease in operating income as a percentage of revenue was primarily due to a gross margin percentage decrease and operating expenses percentage increase.

[0000858877-23-000013:mdna:219]
[same as prior period, unchanged from 0000858877-23-000005:mdna:214]

[0000858877-23-000013:mdna:220]
[same as prior period, unchanged from 0000858877-23-000005:mdna:215]

[0000858877-23-000013:mdna:221]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 29,2023 |  | April 30,2022 |  | Variancein Dollars |  | April 29,2023 |  | April 30,2022 |  | Variancein Dollars |
| Interest income |  | $ | 262 |  |  | $ | 115 |  |  | $ | 147 |  |  | $ | 650 |  |  | $ | 347 |  |  | $ | 303 |  |
| Interest expense |  | (109) |  |  | (90) |  |  | (19) |  |  | (316) |  |  | (267) |  |  | (49) |  |
| Interest income (expense), net |  | $ | 153 |  |  | $ | 25 |  |  | $ | 128 |  |  | $ | 334 |  |  | $ | 80 |  |  | $ | 254 |  |

[0000858877-23-000013:mdna:222]
For the each of the third quarter and first nine months of fiscal 2023, the increase in interest income was driven by higher average balance of cash and available-for-sale debt investments and higher interest rates. The increase in interest expense was primarily driven by higher interest rates, partially offset by a lower average debt balance.

[0000858877-23-000013:mdna:223]
[same as prior period, unchanged from 0000858877-23-000005:mdna:218]

[0000858877-23-000013:mdna:224]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 29,2023 |  | April 30,2022 |  | Variancein Dollars |  | April 29,2023 |  | April 30,2022 |  | Variancein Dollars |
| Gains (losses) on investments, net: |  |  |  |  |  |  |  |  |  |  |  |  |
| Available-for-sale debt investments |  | $ | (6) |  |  | $ | 2 |  |  | $ | (8) |  |  | $ | (15) |  |  | $ | 18 |  |  | $ | (33) |  |
| Marketable equity investments |  | (8) |  |  | (19) |  |  | 11 |  |  | (10) |  |  | (32) |  |  | 22 |  |
| Privately held investments |  | (120) |  |  | 166 |  |  | (286) |  |  | (193) |  |  | 492 |  |  | (685) |  |
| Net gains (losses) on investments |  | (134) |  |  | 149 |  |  | (283) |  |  | (218) |  |  | 478 |  |  | (696) |  |
| Other gains (losses), net |  | (8) |  |  | 17 |  |  | (25) |  |  | (47) |  |  | (32) |  |  | (15) |  |
| Other income (loss), net |  | $ | (142) |  |  | $ | 166 |  |  | $ | (308) |  |  | $ | (265) |  |  | $ | 446 |  |  | $ | (711) |  |

[0000858877-23-000013:mdna:225]
Three Months Ended April 29, 2023 Compared with Three Months Ended April 30, 2022

[0000858877-23-000013:mdna:226]
The decrease in our other income (loss), net was primarily driven by impairment charges and higher unrealized losses on our privately held investments, changes in net gains (losses) on available-for-sale debt investments and marketable equity investments and unfavorable impacts from foreign exchange.

[0000858877-23-000013:mdna:227]
Nine Months Ended April 29, 2023 Compared with Nine Months Ended April 30, 2022

[0000858877-23-000013:mdna:228]
The decrease in our other income (loss), net was primarily driven by realized and unrealized losses and impairment charges on our privately held investments.

[0000858877-23-000013:mdna:229]
[same as prior period, unchanged from 0000858877-23-000005:mdna:224]

[0000858877-23-000013:mdna:230]
Three Months Ended April 29, 2023 Compared with Three Months Ended April 30, 2022

[0000858877-23-000013:mdna:231]
The provision for income taxes resulted in an effective tax rate of 18.8% for the third quarter of fiscal 2023 compared with 19.9% for the third quarter of fiscal 2022. The decrease in the effective tax rate was primarily due to an increase in a U.S. foreign-derived intangible income deduction benefit driven by the capitalization and amortization of R&D expenses effective for fiscal 2023 as required by the Tax Cuts and Jobs Act, partially offset by a decrease in federal research credit benefit.

[0000858877-23-000013:mdna:232]
Nine Months Ended April 29, 2023 Compared with Nine Months Ended April 30, 2022

[0000858877-23-000013:mdna:233]
The provision for income taxes resulted in an effective tax rate of 20.2% for the first nine months of fiscal 2023 compared with 18.7% for the first nine months of fiscal 2022. The increase in the effective tax rate was primarily due to an increase in net

[0000858877-23-000013:mdna:234]
[same as prior period, unchanged from 0000858877-23-000005:mdna:230]

[0000858877-23-000013:mdna:235]
[same as prior period, unchanged from 0000858877-23-000005:mdna:231]

[0000858877-23-000013:mdna:236]
discrete tax expenses, a decrease in stock based compensation windfall, and the impact of new U.S. foreign tax credit regulations effective for fiscal 2023. The increase was partially offset by a U.S. foreign-derived intangible income deduction benefit driven by the capitalization and amortization of R&D expenses effective for fiscal 2023 as required by the Tax Cuts and Jobs Act.

[0000858877-23-000013:mdna:237]
56

[0000858877-23-000013:mdna:238]
[same as prior period, unchanged from 0000858877-23-000005:mdna:245]

[0000858877-23-000013:mdna:239]
[same as prior period, unchanged from 0000858877-23-000005:mdna:246]

[0000858877-23-000013:mdna:240]
[same as prior period, unchanged from 0000858877-23-000005:mdna:232]

[0000858877-23-000013:mdna:241]
[same as prior period, unchanged from 0000858877-23-000005:mdna:233]

[0000858877-23-000013:mdna:242]
[same as prior period, unchanged from 0000858877-23-000005:mdna:234]

[0000858877-23-000013:mdna:243]
[same as prior period, unchanged from 0000858877-23-000005:mdna:235]

[0000858877-23-000013:mdna:244]
|  | April 29,2023 |  | July 30,2022 |  | Increase (Decrease) |
| Cash and cash equivalents | $ | 8,044 |  |  | $ | 7,079 |  |  | $ | 965 |  |
| Available-for-sale debt investments | 14,898 |  |  | 11,947 |  |  | 2,951 |  |
| Marketable equity securities | 346 |  |  | 241 |  |  | 105 |  |
| Total | $ | 23,288 |  |  | $ | 19,267 |  |  | $ | 4,021 |  |

[0000858877-23-000013:mdna:245]
The net increase in cash and cash equivalents and investments in the first nine months of fiscal 2023 was primarily driven by cash provided by operating activities of $13.9 billion. This source of cash was partially offset by cash returned to stockholders in the form of repurchases of common stock of $3.0 billion and cash dividends of $4.7 billion, a net decrease of debt of $1.1 billion and capital expenditures of $0.6 billion.

[0000858877-23-000013:mdna:246]
Beginning in fiscal 2023, we were required to capitalize and amortize R&D expenses as required by the Tax Cuts and Jobs Act. This change will result in significantly higher cash paid for income taxes. In February 2023, an IRS announcement related to the California floods (IR-2023-33) postponed our remaining fiscal 2023 U.S. federal income tax payment deadlines until October 2023. As of April 29, 2023, we have deferred approximately $1.7 billion of federal tax payments. We expect to defer an additional federal tax payment in the fourth quarter of fiscal 2023. Our cash paid for income taxes for the first quarter of fiscal 2024 will significantly increase as a result of these deferred federal tax payments.

[0000858877-23-000013:mdna:247]
[same as prior period, unchanged from 0000858877-23-000005:mdna:239]

[0000858877-23-000013:mdna:248]
Securities Lending   We periodically engage in securities lending activities with certain of our available-for-sale debt investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. We require collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. We engage in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify us against collateral losses. We did not experience any losses in connection with the secured lending of securities during the periods presented. As of April 29, 2023 and July 30, 2022, we had no outstanding securities lending transactions.

[0000858877-23-000013:mdna:249]
[same as prior period, unchanged from 0000858877-23-000005:mdna:241]

[0000858877-23-000013:mdna:250]
[same as prior period, unchanged from 0000858877-23-000005:mdna:242]

[0000858877-23-000013:mdna:251]
|  | Nine Months Ended |
|  | April 29,2023 |  | April 30,2022 |
| Net cash provided by operating activities | $ | 13,920 |  |  | $ | 9,549 |  |
| Acquisition of property and equipment | (616) |  |  | (338) |  |
| Free cash flow | $ | 13,304 |  |  | $ | 9,211 |  |

[0000858877-23-000013:mdna:252]
[same as prior period, unchanged from 0000858877-23-000005:mdna:256]

[0000858877-23-000013:mdna:253]
[same as prior period, unchanged from 0000858877-23-000005:mdna:257]

[0000858877-23-000013:mdna:254]
We expect that cash provided by operating activities may fluctuate in future periods as a result of a number of factors, including fluctuations in our operating results, the rate at which products are shipped during the quarter (which we refer to as shipment linearity), the timing and collection of accounts receivable and financing receivables, inventory and supply chain management, deferred revenue, and the timing and amount of tax and other payments. For additional discussion, see “Part II, Item 1A. Risk Factors” in this report.

[0000858877-23-000013:mdna:255]
[same as prior period, unchanged from 0000858877-23-000005:mdna:248]

[0000858877-23-000013:mdna:256]
[same as prior period, unchanged from 0000858877-23-000005:mdna:249]

[0000858877-23-000013:mdna:257]
|  |  | DIVIDENDS |  | STOCK REPURCHASE PROGRAM |  |  |
| Quarter Ended |  | Per Share |  | Amount |  | Shares |  | Weighted-Average Price per Share |  | Amount |  | TOTAL |
| Fiscal 2023 |  |  |  |  |  |  |  |  |  |  |  |  |
| April 29, 2023 |  | $ | 0.39 |  |  | $ | 1,593 |  |  | 25 |  |  | $ | 49.45 |  |  | $ | 1,259 |  |  | $ | 2,852 |  |
| January 28, 2023 |  | $ | 0.38 |  |  | $ | 1,560 |  |  | 26 |  |  | $ | 47.72 |  |  | $ | 1,256 |  |  | $ | 2,816 |  |
| October 29, 2022 |  | $ | 0.38 |  |  | $ | 1,560 |  |  | 12 |  |  | $ | 43.76 |  |  | $ | 502 |  |  | $ | 2,062 |  |
| Fiscal 2022 |  |  |  |  |  |  |  |  |  |  |  |  |
| July 30, 2022 |  | $ | 0.38 |  |  | $ | 1,567 |  |  | 54 |  |  | $ | 44.02 |  |  | $ | 2,402 |  |  | $ | 3,969 |  |
| April 30, 2022 |  | $ | 0.38 |  |  | $ | 1,555 |  |  | 5 |  |  | $ | 54.20 |  |  | $ | 252 |  |  | $ | 1,807 |  |
| January 29, 2022 |  | $ | 0.37 |  |  | $ | 1,541 |  |  | 82 |  |  | $ | 58.36 |  |  | $ | 4,824 |  |  | $ | 6,365 |  |
| October 30, 2021 |  | $ | 0.37 |  |  | $ | 1,561 |  |  | 5 |  |  | $ | 56.49 |  |  | $ | 256 |  |  | $ | 1,817 |  |

[0000858877-23-000013:mdna:258]
On May 17, 2023, our Board of Directors declared a quarterly dividend of $0.39 per common share to be paid on July 26, 2023, to all stockholders of record as of the close of business on July 6, 2023. Future dividends will be subject to the approval of our Board of Directors.

[0000858877-23-000013:mdna:259]
The remaining authorized amount for stock repurchases under this program is approximately $12.2 billion, with no termination date.

[0000858877-23-000013:mdna:260]
[same as prior period, unchanged from 0000858877-23-000005:mdna:253]

[0000858877-23-000013:mdna:261]
|  | April 29,2023 |  | July 30,2022 |  | Increase (Decrease) |
| Accounts receivable, net | $ | 5,104 |  |  | $ | 6,622 |  |  | $ | (1,518) |  |

[0000858877-23-000013:mdna:262]
Our accounts receivable net, as of April 29, 2023 decreased by approximately 23%, as compared with the end of fiscal 2022, primarily due to timing and amount of product and service billings in the third quarter of fiscal 2023 compared with the fourth quarter of fiscal 2022.

[0000858877-23-000013:mdna:263]
[same as prior period, unchanged from 0000858877-23-000005:mdna:269]

[0000858877-23-000013:mdna:264]
[same as prior period, unchanged from 0000858877-23-000005:mdna:270]

[0000858877-23-000013:mdna:265]
[same as prior period, unchanged from 0000858877-23-000005:mdna:258]

[0000858877-23-000013:mdna:266]
|  | April 29,2023 |  | July 30,2022 |  | July 31,2021 |  | Variance vs. July 30, 2022 |  | Variance vs. July 31, 2021 |
| Inventories | $ | 3,474 |  |  | $ | 2,568 |  |  | $ | 1,559 |  |  | $ | 906 |  |  | $ | 1,915 |  |
| Inventory purchase commitments | $ | 9,059 |  |  | $ | 12,964 |  |  | $ | 10,254 |  |  | $ | (3,905) |  |  | $ | (1,195) |  |
| Inventory deposits and prepayments | $ | 1,642 |  |  | $ | 1,484 |  |  | $ | 162 |  |  | $ | 158 |  |  | $ | 1,480 |  |

[0000858877-23-000013:mdna:267]
[same as prior period, unchanged from 0000858877-23-000005:mdna:260]

[0000858877-23-000013:mdna:268]
|  | April 29,2023 |  | July 30,2022 |  | July 31,2021 |  | Variance vs. July 30, 2022 |  | Variance vs.July 31, 2021 |
| Less than 1 year | $ | 7,073 |  |  | $ | 9,954 |  |  | $ | 6,903 |  |  | $ | (2,881) |  |  | $ | 170 |  |
| 1 to 3 years | 1,618 |  |  | 2,240 |  |  | 1,806 |  |  | (622) |  |  | (188) |  |
| 3 to 5 years | 368 |  |  | 770 |  |  | 1,545 |  |  | (402) |  |  | (1,177) |  |
| Total | $ | 9,059 |  |  | $ | 12,964 |  |  | $ | 10,254 |  |  | $ | (3,905) |  |  | $ | (1,195) |  |

[0000858877-23-000013:mdna:269]
Inventory as of April 29, 2023 increased by 35% and inventory purchase commitments with contract manufacturers and suppliers decreased by 30% from our balances at the end of fiscal 2022. The combined decrease of 19% in our inventory and inventory purchase commitments as compared with the end of fiscal 2022 was primarily due to fulfillment of customer demand as overall supply constraints continued to improve and our continued efforts to work with contract manufacturers and suppliers to optimize our inventory and purchase commitment levels.

[0000858877-23-000013:mdna:270]
We increased our balances in prior fiscal years in order to address significant supply constraints seen industry-wide. The increases were primarily due to arrangements to secure supply and pricing for certain product components and commitments with contract manufacturers to meet customer demand and to address extended lead times, as well as advance payments with suppliers to secure future supply, as a result of the supply constraints. We have partnered with several of our key suppliers utilizing our volume purchasing and extending supply coverage, including revising supplier arrangements. As discussed, our risks of future material excess and obsolete inventory and related losses are further outlined in the Result of Operations—Product Gross Margin section.

[0000858877-23-000013:mdna:271]
[same as prior period, unchanged from 0000858877-23-000005:mdna:263]

[0000858877-23-000013:mdna:272]
[same as prior period, unchanged from 0000858877-23-000005:mdna:264]

[0000858877-23-000013:mdna:273]
[same as prior period, unchanged from 0000858877-23-000005:mdna:265]

[0000858877-23-000013:mdna:274]
[same as prior period, unchanged from 0000858877-23-000005:mdna:266]

[0000858877-23-000013:mdna:275]
|  | April 29,2023 |  | July 30,2022 |  | Increase (Decrease) |
| Loan receivables, net | $ | 5,826 |  |  | $ | 6,739 |  |  | $ | (913) |  |
| Lease receivables, net | 969 |  |  | 1,175 |  |  | (206) |  |
| Total, net | $ | 6,795 |  |  | $ | 7,914 |  |  | $ | (1,119) |  |

[0000858877-23-000013:mdna:276]
[same as prior period, unchanged from 0000858877-23-000005:mdna:280]

[0000858877-23-000013:mdna:277]
[same as prior period, unchanged from 0000858877-23-000005:mdna:281]

[0000858877-23-000013:mdna:278]
Financing Receivables  Our financing arrangements include loans and leases. Our loan receivables include customer financing for purchases of our hardware, software and services (including technical support and advanced services), and also may include additional funds for other costs associated with network installation and integration of our products and services. Lease receivables include sales-type leases. Arrangements related to leases are generally collateralized by a security interest in the underlying assets. Financing receivables decreased by 14%, as compared with the end of fiscal 2022.

[0000858877-23-000013:mdna:279]
[same as prior period, unchanged from 0000858877-23-000005:mdna:272]

[0000858877-23-000013:mdna:280]
The volume of channel partner financing was $23.4 billion and $20.3 billion for the first nine months of fiscal 2023 and 2022, respectively. These financing arrangements facilitate the working capital requirements of the channel partners, and in some cases, we guarantee a portion of these arrangements. The balance of the channel partner financing subject to guarantees was $1.8 billion and $1.4 billion as of April 29, 2023 and July 30, 2022, respectively. We could be called upon to make payments under these guarantees in the event of nonpayment by the channel partners. Historically, our payments under these arrangements have been immaterial. Where we provide a guarantee, we defer the revenue associated with the channel partner financing arrangement in accordance with revenue recognition policies, or we record a liability for the fair value of the guarantees. In either case, the deferred revenue is recognized as revenue when the guarantee is removed. As of April 29, 2023, the total maximum potential future payments related to these guarantees was approximately $177 million, of which approximately $40 million was recorded as deferred revenue.

[0000858877-23-000013:mdna:281]
[same as prior period, unchanged from 0000858877-23-000005:mdna:274]

[0000858877-23-000013:mdna:282]
[same as prior period, unchanged from 0000858877-23-000005:mdna:275]

[0000858877-23-000013:mdna:283]
|  | Maturity Date |  | April 29,2023 |  | July 30,2022 |
| Senior notes: |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |
| 2.60% | February 28, 2023 |  | $ | — |  |  | $ | 500 |  |
| 2.20% | September 20, 2023 |  | 750 |  |  | 750 |  |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1,000 |  |
| 3.50% | June 15, 2025 |  | 500 |  |  | 500 |  |
| 2.95% | February 28, 2026 |  | 750 |  |  | 750 |  |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 1,500 |  |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 2,000 |  |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 2,000 |  |
| Total |  |  | $ | 8,500 |  |  | $ | 9,000 |  |

[0000858877-23-000013:mdna:284]
Interest is payable semiannually on each class of the senior fixed-rate notes, each of which is redeemable by us at any time, subject to a make-whole premium. We were in compliance with all debt covenants as of April 29, 2023.

[0000858877-23-000013:mdna:285]
Commercial Paper  We have a short-term debt financing program in which up to $10.0 billion is available through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes. We had no commercial paper notes outstanding as of April 29, 2023 and $0.6 billion in commercial paper outstanding as of July 30, 2022.

[0000858877-23-000013:mdna:286]
Credit Facility  On May 13, 2021, we entered into a 5-year credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 13, 2026. As of April 29, 2023, we were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under the credit agreement. On April 18, 2023, we entered into an amendment to the credit agreement to replace the LIBOR index with Term SOFR.

[0000858877-23-000013:mdna:287]
Any advances under the 5-year credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (a) with respect to loans in U.S. dollars, (i) Term SOFR (plus a 0.10% credit spread adjustment) or (ii) the Base Rate (to be

[0000858877-23-000013:mdna:288]
[same as prior period, unchanged from 0000858877-23-000005:mdna:294]

[0000858877-23-000013:mdna:289]
[same as prior period, unchanged from 0000858877-23-000005:mdna:295]

[0000858877-23-000013:mdna:290]
defined as the highest of (x) the Bank of America prime rate, (y) the Federal Funds rate plus 0.50% and (z) Term SOFR plus 1.0%), (b) with respect to loans in Euros, EURIBOR, (c) with respect to loans in Yen, TIBOR and (d) with respect to loans in Pounds Sterling, SONIA, plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the interest rate be less than 0.0%. We will pay a quarterly commitment fee during the term of the 5-year credit agreement which may vary depending on our senior debt credit ratings. In addition, the 5-year credit agreement incorporates certain sustainability-linked metrics. Specifically, our applicable interest rate and commitment fee are subject to upward or downward adjustments if we achieve, or fail to achieve, certain specified targets based on two key performance indicator metrics: (i) social impact and (ii) foam reduction. We may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and, at our option, extend the maturity of the facility for an additional year up to two times. The credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio as defined in the agreement.

[0000858877-23-000013:mdna:291]
[same as prior period, unchanged from 0000858877-23-000005:mdna:283]

[0000858877-23-000013:mdna:292]
|  | April 29,2023 |  | July 30,2022 |  | Increase (Decrease) |
| Product | $ | 14,681 |  |  | $ | 14,090 |  |  | $ | 591 |  |
| Service | 17,401 |  |  | 17,449 |  |  | (48) |  |
| Total | $ | 32,082 |  |  | $ | 31,539 |  |  | $ | 543 |  |
| Short-term RPO | $ | 16,869 |  |  | $ | 16,936 |  |  | $ | (67) |  |
| Long-term RPO | 15,213 |  |  | 14,603 |  |  | 610 |  |
| Total | $ | 32,082 |  |  | $ | 31,539 |  |  | $ | 543 |  |

[0000858877-23-000013:mdna:293]
Total remaining performance obligations as of April 29, 2023 increased 2% compared to the end of fiscal 2022. Remaining performance obligations for product increased by 4% compared to the end of fiscal 2022. Remaining performance obligations for service was flat. We expect approximately 53% of total remaining performance obligations to be recognized as revenue over the next 12 months.

[0000858877-23-000013:mdna:294]
[same as prior period, unchanged from 0000858877-23-000005:mdna:286]

[0000858877-23-000013:mdna:295]
|  | April 29,2023 |  | July 30,2022 |  | Increase (Decrease) |
| Product | $ | 10,895 |  |  | $ | 10,427 |  |  | $ | 468 |  |
| Service | 13,365 |  |  | 12,837 |  |  | 528 |  |
| Total | $ | 24,260 |  |  | $ | 23,264 |  |  | $ | 996 |  |
| Reported as: |  |  |  |  |  |
| Current | $ | 13,249 |  |  | $ | 12,784 |  |  | $ | 465 |  |
| Noncurrent | 11,011 |  |  | 10,480 |  |  | 531 |  |
| Total | $ | 24,260 |  |  | $ | 23,264 |  |  | $ | 996 |  |

[0000858877-23-000013:mdna:296]
Total deferred revenue increased 4% compared to the end of fiscal 2022. The increase in deferred product revenue was primarily due to increased deferrals related to our recurring software offerings. The increase in deferred service revenue of 4% was driven by the impact of contract renewals, partially offset by amortization of deferred service revenue.

[0000858877-23-000013:mdna:297]
[same as prior period, unchanged from 0000858877-23-000005:mdna:289]

[0000858877-23-000013:mdna:298]
[same as prior period, unchanged from 0000858877-23-000005:mdna:290]

[0000858877-23-000013:mdna:299]
The income tax payable outstanding as of April 29, 2023 for the U.S. transition tax on accumulated earnings for foreign subsidiaries was $5.5 billion. Approximately $1.4 billion is payable in less than one year and $4.1 billion is payable between 1 to 3 years.

[0000858877-23-000013:mdna:300]
[same as prior period, unchanged from 0000858877-23-000005:mdna:292]

[0000858877-23-000013:mdna:301]
CISCO SYSTEMS, INC.

[0000858877-23-000013:mdna:302]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-23-000013:mdna:303]
[same as prior period, unchanged from 0000858877-23-000005:mdna:296]

[0000858877-23-000013:mdna:304]
[same as prior period, unchanged from 0000858877-23-000005:mdna:297]

[0000858877-23-000013:mdna:305]
We also have certain funding commitments primarily related to our privately held investments, some of which may be based on the achievement of certain agreed-upon milestones or are required to be funded on demand. The funding commitments were $0.3 billion and $0.4 billion as of April 29, 2023 and July 30, 2022, respectively.

[0000858877-23-000013:mdna:306]
In the ordinary course of business, we have privately held investments and provide financing to certain customers. Certain of these investments are considered to be variable interest entities. We evaluate on an ongoing basis our privately held investments and customer financings, and we have determined that as of April 29, 2023 there were no material unconsolidated variable interest entities.

[0000858877-23-000013:mdna:307]
[same as prior period, unchanged from 0000858877-23-000005:mdna:300]

[0000858877-23-000013:mdna:308]
[same as prior period, unchanged from 0000858877-23-000005:mdna:301]

[0000858877-23-000013:mdna:309]
[same as prior period, unchanged from 0000858877-23-000005:mdna:302]

[0000858877-23-000013:mdna:310]
[same as prior period, unchanged from 0000858877-23-000005:mdna:303]
