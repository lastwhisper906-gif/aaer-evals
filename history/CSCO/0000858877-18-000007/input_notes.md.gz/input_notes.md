# CSCO notes — 0000858877-18-000007


## csco:CompensationexpensesrelatedtobusinesscombinationsTableTextBlock

[0000858877-18-000007:notes:1]
[same as prior period, unchanged from 0000858877-18-000004:notes:1]

[0000858877-18-000007:notes:2]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 28, 2018 |  | April 29, 2017 |  | April 28, 2018 |  | April 29, 2017 |
| Compensation expense related to acquisitions | $ | 53 |  |  | $ | 36 |  |  | $ | 141 |  |  | $ | 173 |  |


## csco:IncometaxprovisionTableTextBlock

[0000858877-18-000007:notes:3]
[same as prior period, unchanged from 0000858877-18-000004:notes:3]

[0000858877-18-000007:notes:4]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 28, 2018 |  | April 29, 2017 |  | April 28, 2018 |  | April 29, 2017 |
| Income before provision for income taxes | $ | 3,253 |  |  | $ | 3,191 |  |  | $ | 9,447 |  |  | $ | 9,107 |  |
| Provision for income taxes | $ | 562 |  |  | $ | 676 |  |  | $ | 13,140 |  |  | $ | 1,922 |  |
| Effective tax rate | 17.3 | % |  | 21.2 | % |  | 139.1 | % |  | 21.1 | % |


## csco:NetSalesForGroupsOfSimilarProductsAndServicesTableTextBlock

[0000858877-18-000007:notes:5]
[same as prior period, unchanged from 0000858877-18-000004:notes:5]

[0000858877-18-000007:notes:6]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 28, 2018 |  | April 29, 2017 |  | April 28, 2018 |  | April 29, 2017 |
| Revenue: |  |  |  |  |  |  |  |
| Infrastructure Platforms | $ | 7,163 |  |  | $ | 6,992 |  |  | $ | 20,827 |  |  | $ | 20,810 |  |
| Applications | 1,309 |  |  | 1,100 |  |  | 3,696 |  |  | 3,352 |  |
| Security | 583 |  |  | 527 |  |  | 1,726 |  |  | 1,595 |  |
| Other Products | 249 |  |  | 266 |  |  | 818 |  |  | 921 |  |
| Total Product | 9,304 |  |  | 8,885 |  |  | 27,067 |  |  | 26,678 |  |
| Services | 3,159 |  |  | 3,055 |  |  | 9,419 |  |  | 9,194 |  |
| Total | $ | 12,463 |  |  | $ | 11,940 |  |  | $ | 36,486 |  |  | $ | 35,872 |  |


## csco:ScheduleOfCommonStockRepurchasedTextBlock

[0000858877-18-000007:notes:7]
[same as prior period, unchanged from 0000858877-18-000004:notes:7]

[0000858877-18-000007:notes:8]
| Quarter Ended |  | Shares |  | Weighted-Average Price per Share |  | Amount |
| Fiscal 2018 |  |  |  |  |  |  |
| April 28, 2018 |  | 140 |  |  | $ | 42.83 |  |  | $ | 6,015 |  |
| January 27, 2018 |  | 103 |  |  | $ | 39.07 |  |  | $ | 4,011 |  |
| October 28, 2017 |  | 51 |  |  | $ | 31.80 |  |  | $ | 1,620 |  |
| Fiscal 2017 |  |  |  |  |  |  |
| July 29, 2017 |  | 38 |  |  | $ | 31.61 |  |  | $ | 1,201 |  |
| April 29, 2017 |  | 15 |  |  | $ | 33.71 |  |  | $ | 503 |  |
| January 28, 2017 |  | 33 |  |  | $ | 30.33 |  |  | $ | 1,001 |  |
| October 29, 2016 |  | 32 |  |  | $ | 31.12 |  |  | $ | 1,001 |  |


## csco:ScheduleOfDerivativeFairValueHedgeInstrumentsGainLossInStatementOfFinancialPerformanceTableTextBlock

[0000858877-18-000007:notes:9]
[same as prior period, unchanged from 0000858877-18-000004:notes:9]

[0000858877-18-000007:notes:10]
|  |  |  |  | GAINS (LOSSES) ONDERIVATIVEINSTRUMENTS FOR THETHREE MONTHS ENDED |  | GAINS (LOSSES)RELATED TO HEDGEDITEMS FOR THE THREE MONTHS ENDED |
| Derivatives Designated as Fair Value Hedging Instruments |  | Line Item in Statements of Operations |  | April 28, 2018 |  | April 29, 2017 |  | April 28, 2018 |  | April 29, 2017 |
| Interest rate derivatives |  | Interest expense |  | $ | (59 | ) |  | $ | (6 | ) |  | $ | 58 |  |  | $ | 7 |  |
| Equity derivatives |  | Other income (loss), net |  | 25 |  |  | — |  |  | (25 | ) |  | — |  |
| Total |  |  |  | $ | (34 | ) |  | $ | (6 | ) |  | $ | 33 |  |  | $ | 7 |  |

[0000858877-18-000007:notes:11]
|  |  |  |  | GAINS (LOSSES) ONDERIVATIVEINSTRUMENTS FOR THENINE MONTHS ENDED |  | GAINS (LOSSES)RELATED TO HEDGEDITEMS FOR THE NINE MONTHS ENDED |
| Derivatives Designated as Fair Value Hedging Instruments |  | Line Item in Statements of Operations |  | April 28, 2018 |  | April 29, 2017 |  | April 28, 2018 |  | April 29, 2017 |
| Interest rate derivatives |  | Interest expense |  | $ | (168 | ) |  | $ | (272 | ) |  | $ | 167 |  |  | $ | 269 |  |
| Equity derivatives |  | Other income (loss), net |  | (24 | ) |  | — |  |  | 24 |  |  | — |  |
| Total |  |  |  | $ | (192 | ) |  | $ | (272 | ) |  | $ | 191 |  |  | $ | 269 |  |


## csco:ScheduleOfFiniteLivedIntangibleAssetsAmortizationExpenseTableTextBlock

[0000858877-18-000007:notes:12]
[same as prior period, unchanged from 0000858877-18-000004:notes:12]

[0000858877-18-000007:notes:13]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 28, 2018 |  | April 29, 2017 |  | April 28, 2018 |  | April 29, 2017 |
| Amortization of purchased intangible assets: |  |  |  |  |  |  |  |
| Cost of sales | $ | 177 |  |  | $ | 141 |  |  | $ | 491 |  |  | $ | 394 |  |
| Operating expenses |  |  |  |  |  |  |  |  |
| Amortization of purchased intangible assets | 67 |  |  | 59 |  |  | 188 |  |  | 201 |  |
| Restructuring and other charges | — |  |  | — |  |  | — |  |  | 38 |  |
| Total | $ | 244 |  |  | $ | 200 |  |  | $ | 679 |  |  | $ | 633 |  |


## csco:ScheduleOfIntangibleAssetsAcquiredAsPartOfBusinessCombinationTextBlock

[0000858877-18-000007:notes:14]
The following table presents details of the Company’s intangible assets acquired through acquisitions completed during the nine months ended April 28, 2018 (in millions, except years):

[0000858877-18-000007:notes:15]
|  | FINITE LIVES |  | INDEFINITE LIVES |  | TOTAL |
|  | TECHNOLOGY |  | CUSTOMERRELATIONSHIPS |  | OTHER |  | IPR&D |  |
|  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Amount |  | Amount |
| Viptela | 5.0 |  | $ | 144 |  |  | 6.0 |  | $ | 35 |  |  | 1.0 |  | $ | 1 |  |  | $ | — |  |  | $ | 180 |  |
| Springpath | 4.0 |  | 157 |  |  | 0.0 |  | — |  |  | 0.0 |  | — |  |  | 3 |  |  | 160 |  |
| BroadSoft | 4.0 |  | 255 |  |  | 6.0 |  | 169 |  |  | 2.0 |  | 6 |  |  | — |  |  | 430 |  |
| Others (four in total) | 3.9 |  | 39 |  |  | 4.0 |  | 3 |  |  | 0.0 |  | — |  |  | — |  |  | 42 |  |
| Total |  |  | $ | 595 |  |  |  |  | $ | 207 |  |  |  |  | $ | 7 |  |  | $ | 3 |  |  | $ | 812 |  |


## csco:ScheduleOfIntangibleAssetsByMajorClassTextBlock

[0000858877-18-000007:notes:16]
[same as prior period, unchanged from 0000858877-18-000004:notes:16]

[0000858877-18-000007:notes:17]
| April 28, 2018 |  | Gross |  | Accumulated Amortization |  | Net |
| Purchased intangible assets with finite lives: |  |  |  |  |  |  |
| Technology |  | $ | 3,657 |  |  | $ | (1,738 | ) |  | $ | 1,919 |  |
| Customer relationships |  | 1,538 |  |  | (909 | ) |  | 629 |  |
| Other |  | 63 |  |  | (34 | ) |  | 29 |  |
| Total purchased intangible assets with finite lives |  | 5,258 |  |  | (2,681 | ) |  | 2,577 |  |
| In-process research and development, with indefinite lives |  | 104 |  |  | — |  |  | 104 |  |
| Total |  | $ | 5,362 |  |  | $ | (2,681 | ) |  | $ | 2,681 |  |

[0000858877-18-000007:notes:18]
[same as prior period, unchanged from 0000858877-18-000004:notes:18]


## csco:SegmentReportingProductAndServicesNetSalesTextBlock

[0000858877-18-000007:notes:19]
[same as prior period, unchanged from 0000858877-18-000004:notes:19]

[0000858877-18-000007:notes:20]
[same as prior period, unchanged from 0000858877-18-000004:notes:20]

[0000858877-18-000007:notes:21]
The Company conducts business globally and is primarily managed on a geographic basis consisting of three segments: the Americas, EMEA, and APJC. The Company’s management makes financial decisions and allocates resources based on the information it receives from its internal management system. Sales are attributed to a segment based on the ordering location of the customer. The Company does not allocate research and development, sales and marketing, or general and administrative expenses to its segments in this internal management system because management does not include the information in its measurement of the performance of the operating segments. In addition, the Company does not allocate amortization and impairment of acquisition-related intangible assets, share-based compensation expense, significant litigation settlements and other contingencies, charges related to asset impairments and restructurings, and certain other charges to the gross margin for each segment because management does not include this information in its measurement of the performance of the operating segments.

[0000858877-18-000007:notes:22]
Summarized financial information by segment for the three and nine months ended April 28, 2018 and April 29, 2017, based on the Company’s internal management system and as utilized by the Company’s Chief Operating Decision Maker ("CODM"), is as follows (in millions):

[0000858877-18-000007:notes:23]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 28, 2018 |  | April 29, 2017 |  | April 28, 2018 |  | April 29, 2017 |
| Revenue: |  |  |  |  |  |  |  |
| Americas | $ | 7,161 |  |  | $ | 7,046 |  |  | $ | 21,515 |  |  | $ | 21,149 |  |
| EMEA | 3,281 |  |  | 2,999 |  |  | 9,252 |  |  | 9,077 |  |
| APJC | 2,021 |  |  | 1,895 |  |  | 5,719 |  |  | 5,646 |  |
| Total | $ | 12,463 |  |  | $ | 11,940 |  |  | $ | 36,486 |  |  | $ | 35,872 |  |
| Gross margin: |  |  |  |  |  |  |  |
| Americas | $ | 4,614 |  |  | $ | 4,551 |  |  | $ | 13,950 |  |  | $ | 13,672 |  |
| EMEA | 2,109 |  |  | 1,963 |  |  | 5,925 |  |  | 5,988 |  |
| APJC | 1,247 |  |  | 1,171 |  |  | 3,506 |  |  | 3,496 |  |
| Segment total | 7,970 |  |  | 7,685 |  |  | 23,381 |  |  | 23,156 |  |
| Unallocated corporate items | (211 | ) |  | (167 | ) |  | (697 | ) |  | (478 | ) |
| Total | $ | 7,759 |  |  | $ | 7,518 |  |  | $ | 22,684 |  |  | $ | 22,678 |  |

[0000858877-18-000007:notes:24]
Revenue in the United States was $6.2 billion for each of the three months ended April 28, 2018 and April 29, 2017, and was $18.8 billion and $18.7 billion for the nine months ended April 28, 2018 and April 29, 2017, respectively.

[0000858877-18-000007:notes:25]
[same as prior period, unchanged from 0000858877-18-000004:notes:25]

[0000858877-18-000007:notes:26]
The Company designs, manufactures, and sells Internet Protocol (IP)-based networking and other products related to the communications and information technology (IT) industry and provides services associated with these products and their use. Effective in the first quarter of fiscal 2018, the Company began reporting its product and service revenue in the following five categories: Infrastructure Platforms, Applications, Security, Other Products, and Services. The change better aligns the Company's product categories with its evolving business model.  Prior period amounts have been reclassified to conform to the current period's presentation. These products, primarily integrated by Cisco IOS Software, link geographically dispersed local-area networks (LANs), metropolitan-area networks (MANs), and wide-area networks (WANs).

[0000858877-18-000007:notes:27]
[same as prior period, unchanged from 0000858877-18-000004:notes:27]

[0000858877-18-000007:notes:28]
The majority of the Company’s assets was attributable to its U.S. operations as of each of April 28, 2018 and July 29, 2017. The Company’s total cash and cash equivalents and investments held by various foreign subsidiaries were $6.9 billion and $67.5 billion as of April 28, 2018 and July 29, 2017, respectively, and the remaining $47.5 billion and $3.0 billion at the respective period ends were available in the United States.

[0000858877-18-000007:notes:29]
[same as prior period, unchanged from 0000858877-18-000004:notes:29]

[0000858877-18-000007:notes:30]
|  | April 28, 2018 |  | July 29, 2017 |
| Property and equipment, net: |  |  |  |
| United States | $ | 2,533 |  |  | $ | 2,711 |  |
| International | 549 |  |  | 611 |  |
| Total | $ | 3,082 |  |  | $ | 3,322 |  |


## us-gaap:AllowanceForCreditLossesOnFinancingReceivablesTableTextBlock

[0000858877-18-000007:notes:31]
[same as prior period, unchanged from 0000858877-18-000004:notes:31]

[0000858877-18-000007:notes:32]
| Three months ended April 28, 2018 | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Allowance for credit loss as of January 27, 2018 | $ | 165 |  |  | $ | 94 |  |  | $ | 13 |  |  | $ | 272 |  |
| Provisions | 1 |  |  | (8 | ) |  | (1 | ) |  | (8 | ) |
| Foreign exchange and other | (1 | ) |  | (1 | ) |  | — |  |  | (2 | ) |
| Allowance for credit loss as of April 28, 2018 | $ | 165 |  |  | $ | 85 |  |  | $ | 12 |  |  | $ | 262 |  |

[0000858877-18-000007:notes:33]
| Nine months ended April 28, 2018 | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Allowance for credit loss as of July 29, 2017 | $ | 162 |  |  | $ | 103 |  |  | $ | 30 |  |  | $ | 295 |  |
| Provisions | 2 |  |  | (19 | ) |  | (17 | ) |  | (34 | ) |
| Foreign exchange and other | 1 |  |  | 1 |  |  | (1 | ) |  | 1 |  |
| Allowance for credit loss as of April 28, 2018 | $ | 165 |  |  | $ | 85 |  |  | $ | 12 |  |  | $ | 262 |  |

[0000858877-18-000007:notes:34]
| Three months ended April 29, 2017 | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Allowance for credit loss as of January 28, 2017 | $ | 225 |  |  | $ | 106 |  |  | $ | 47 |  |  | $ | 378 |  |
| Provisions | 3 |  |  | 10 |  |  | (14 | ) |  | (1 | ) |
| Recoveries (write-offs), net | (8 | ) |  | — |  |  | (1 | ) |  | (9 | ) |
| Foreign exchange and other | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Allowance for credit loss as of April 29, 2017 | $ | 220 |  |  | $ | 117 |  |  | $ | 32 |  |  | $ | 369 |  |

[0000858877-18-000007:notes:35]
| Nine months ended April 29, 2017 | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Allowance for credit loss as of July 30, 2016 | $ | 230 |  |  | $ | 97 |  |  | $ | 48 |  |  | $ | 375 |  |
| Provisions | 1 |  |  | 22 |  |  | (15 | ) |  | 8 |  |
| Recoveries (write-offs), net | (10 | ) |  | (4 | ) |  | (1 | ) |  | (15 | ) |
| Foreign exchange and other | (1 | ) |  | 2 |  |  | — |  |  | 1 |  |
| Allowance for credit loss as of April 29, 2017 | $ | 220 |  |  | $ | 117 |  |  | $ | 32 |  |  | $ | 369 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0000858877-18-000007:notes:36]
[same as prior period, unchanged from 0000858877-18-000004:notes:36]

[0000858877-18-000007:notes:37]
The accompanying financial data as of April 28, 2018 and for the three and nine months ended April 28, 2018 and April 29, 2017 has been prepared by the Company, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission ("SEC"). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States ("GAAP") have been condensed or omitted pursuant to such rules and regulations. The July 29, 2017 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, the Company believes that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended July 29, 2017.

[0000858877-18-000007:notes:38]
[same as prior period, unchanged from 0000858877-18-000004:notes:38]

[0000858877-18-000007:notes:39]
In the opinion of management, all normal recurring adjustments necessary to present fairly the consolidated balance sheet as of April 28, 2018; the results of operations and the statements of comprehensive income (loss) for the three and nine months ended April 28, 2018 and April 29, 2017; the statements of cash flows and equity for the nine months ended April 28, 2018 and April 29, 2017, as applicable, have been made. The results of operations for the three and nine months ended April 28, 2018 are not necessarily indicative of the operating results for the full fiscal year or any future periods.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000858877-18-000007:notes:40]
[same as prior period, unchanged from 0000858877-18-000004:notes:40]

[0000858877-18-000007:notes:41]
The Company completed seven acquisitions during the nine months ended April 28, 2018. A summary of the allocation of the total purchase consideration is presented as follows (in millions):

[0000858877-18-000007:notes:42]
|  | Purchase Consideration |  | Net Tangible Assets Acquired (Liabilities Assumed) |  | Purchased Intangible Assets |  | Goodwill |
| Viptela | $ | 497 |  |  | $ | (18 | ) |  | $ | 180 |  |  | $ | 335 |  |
| Springpath | 248 |  |  | (11 | ) |  | 160 |  |  | 99 |  |
| BroadSoft | 2,179 |  |  | 353 |  |  | 430 |  |  | 1,396 |  |
| Others (four in total) | 72 |  |  | 4 |  |  | 42 |  |  | 26 |  |
| Total | $ | 2,996 |  |  | $ | 328 |  |  | $ | 812 |  |  | $ | 1,856 |  |

[0000858877-18-000007:notes:43]
[same as prior period, unchanged from 0000858877-18-000004:notes:43]

[0000858877-18-000007:notes:44]
[same as prior period, unchanged from 0000858877-18-000004:notes:44]

[0000858877-18-000007:notes:45]
On February 1, 2018, the Company completed its acquisition of publicly held BroadSoft, Inc. ("BroadSoft"), a cloud calling and contact center solutions company. Revenue from the BroadSoft acquisition has been included in the Company's Applications product category.

[0000858877-18-000007:notes:46]
The total purchase consideration related to acquisitions completed during the nine months ended April 28, 2018 consisted of cash consideration and vested share-based awards assumed. The total cash and cash equivalents acquired from these acquisitions was approximately $174 million. Total transaction costs related to acquisition and divestiture activities were $25 million and $7 million for the nine months ended April 28, 2018 and April 29, 2017, respectively. These transaction costs were expensed as incurred in general and administrative expenses ("G&A") in the Consolidated Statements of Operations. For the nine months ended April 28, 2018, the Company recognized a gain of $46 million in connection with a step acquisition. This gain was recognized in other income (loss), net in the Consolidated Statement of Operations.

[0000858877-18-000007:notes:47]
[same as prior period, unchanged from 0000858877-18-000004:notes:46]

[0000858877-18-000007:notes:48]
The goodwill generated from acquisitions completed during the nine months ended April 28, 2018 is primarily related to expected synergies. The goodwill is generally not deductible for income tax purposes.

[0000858877-18-000007:notes:49]
The Consolidated Financial Statements include the operating results of each acquisition from the date of acquisition. Pro forma results of operations for the acquisitions completed during the nine months ended April 28, 2018 have not been presented because the effects of the acquisitions, individually and in the aggregate, were not material to the Company’s financial results.

[0000858877-18-000007:notes:50]
The Company completed two divestitures during the second quarter of fiscal 2018. The financial statement impact of these divestitures was not material for the nine months ended April 28, 2018.

[0000858877-18-000007:notes:51]
Pending Divestiture     On May 1, 2018, the Company announced a definitive agreement to sell its Service Provider Video Software Solutions ("SPVSS") business. As of April 28, 2018, this business had tangible assets of approximately $200 million (primarily comprised of accounts receivables, inventories and various other current and long-term assets) and net intangible assets and goodwill (based on relative fair value) of $300 million. In addition, the business had total liabilities of approximately $370 million (primarily comprised of deferred revenue and various other current and long-term liabilities). These assets and liabilities were held for sale and were not presented separately as the amounts were not material to the Consolidated Balance Sheet. The transaction is expected to close in the first quarter of fiscal 2019, subject to regulatory approvals and customary closing conditions.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000858877-18-000007:notes:52]
Commitments and Contingencies

[0000858877-18-000007:notes:53]
| (a) | Operating Leases |

[0000858877-18-000007:notes:54]
The Company leases office space in many U.S. locations. Outside the United States, larger leased sites include sites in Belgium, Canada, China, Germany, India, Israel, Japan, Mexico, Poland and the United Kingdom. The Company also leases equipment and vehicles. Future minimum lease payments under all noncancelable operating leases with an initial term in excess of one year as of April 28, 2018 are as follows (in millions):

[0000858877-18-000007:notes:55]
| Fiscal Year | Amount |
| 2018 (remaining three months) | $ | 110 |  |
| 2019 | 343 |  |
| 2020 | 251 |  |
| 2021 | 164 |  |
| 2022 | 131 |  |
| Thereafter | 194 |  |
| Total | $ | 1,193 |  |

[0000858877-18-000007:notes:56]
| (b) | Purchase Commitments with Contract Manufacturers and Suppliers |

[0000858877-18-000007:notes:57]
The Company purchases components from a variety of suppliers and uses several contract manufacturers to provide manufacturing services for its products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, the Company enters into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by the Company or establish the parameters defining the Company’s requirements. A significant portion of the Company’s reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these purchase commitments with contract manufacturers and suppliers relate to arrangements to secure long-term pricing for certain product components for multi-year periods. In certain instances, these agreements allow the Company the option to cancel, reschedule, and adjust the Company’s requirements based on its business needs prior to firm orders being placed.

[0000858877-18-000007:notes:58]
The following table summarizes the Company's purchase commitments with contract manufacturers and suppliers as of the respective period ends (in millions):

[0000858877-18-000007:notes:59]
| Commitments by Period | April 28, 2018 |  | July 29, 2017 |
| Less than 1 year | $ | 5,077 |  |  | $ | 4,620 |  |
| 1 to 3 years | 700 |  |  | 20 |  |
| 3 to 5 years | 450 |  |  | — |  |
| Total | $ | 6,227 |  |  | $ | 4,640 |  |

[0000858877-18-000007:notes:60]
The Company records a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of its future demand forecasts consistent with the valuation of the Company’s excess and obsolete inventory. As of April 28, 2018 and July 29, 2017, the liability for these purchase commitments was $163 million and $162 million, respectively, and was included in other current liabilities.

[0000858877-18-000007:notes:61]
| (c) | Other Commitments |

[0000858877-18-000007:notes:62]
In connection with the Company’s acquisitions, the Company has agreed to pay certain additional amounts contingent upon the achievement of certain agreed-upon technology, development, product, or other milestones or upon the continued employment with the Company of certain employees of the acquired entities.

[0000858877-18-000007:notes:63]
As of April 28, 2018, the Company estimated that future cash compensation expense of up to $370 million may be required to be recognized pursuant to the applicable business combination agreements.

[0000858877-18-000007:notes:64]
Insieme Networks, Inc.    In fiscal 2012, the Company made an investment in Insieme, an early stage company focused on research and development in the data center market. This investment included $100 million of funding and a license to certain of the Company’s technology. During fiscal 2014, the Company acquired the remaining interests in Insieme, at which time the former noncontrolling interest holders became eligible to receive up to two milestone payments, which were determined using agreed-upon formulas based primarily on revenue for certain of Insieme’s products. The former noncontrolling interest holders earned the maximum amount related to these two milestone payments and were paid approximately $436 million during the nine months ended April 29, 2017. The Company recorded compensation expense of $9 million and $41 million during the three and nine months ended April 29, 2017, respectively, related to these milestone payments. The Company does not expect a material amount of future compensation expense or further milestone payments related to this acquisition.

[0000858877-18-000007:notes:65]
The Company also has certain funding commitments, primarily related to its investments in privately held companies and venture funds, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $212 million and $216 million as of April 28, 2018 and July 29, 2017, respectively.

[0000858877-18-000007:notes:66]
| (d) | Product Warranties |

[0000858877-18-000007:notes:67]
The following table summarizes the activity related to the product warranty liability (in millions):

[0000858877-18-000007:notes:68]
|  | Nine Months Ended |
|  | April 28, 2018 |  | April 29, 2017 |
| Balance at beginning of period | $ | 407 |  |  | $ | 414 |  |
| Provisions for warranty issued | 431 |  |  | 528 |  |
| Adjustments for pre-existing warranties | (32 | ) |  | (17 | ) |
| Settlements | (441 | ) |  | (511 | ) |
| Balance at end of period | $ | 365 |  |  | $ | 414 |  |

[0000858877-18-000007:notes:69]
The Company accrues for warranty costs as part of its cost of sales based on associated material product costs, labor costs for technical support staff, and associated overhead. The Company’s products are generally covered by a warranty for periods ranging from 90 days to five years, and for some products the Company provides a limited lifetime warranty.

[0000858877-18-000007:notes:70]
| (e) | Financing and Other Guarantees |

[0000858877-18-000007:notes:71]
In the ordinary course of business, the Company provides financing guarantees for various third-party financing arrangements extended to channel partners and end-user customers. Payments under these financing guarantee arrangements were not material for the periods presented.

[0000858877-18-000007:notes:72]
Channel Partner Financing Guarantees   The Company facilitates arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, generally with payment terms ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, the Company guarantees a portion of these arrangements. The volume of channel partner financing was $7.1 billion and $6.6 billion for the three months ended April 28, 2018 and April 29, 2017, respectively, and was $20.7 billion and $19.7 billion for the nine months ended April 28, 2018 and April 29, 2017, respectively. The balance of the channel partner financing subject to guarantees was $1.0 billion as of each of April 28, 2018 and July 29, 2017.

[0000858877-18-000007:notes:73]
End-User Financing Guarantees   The Company also provides financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. The volume of financing provided by third parties for leases and loans as to which the Company had provided guarantees was $3 million and $10 million for the three months ended April 28, 2018 and April 29, 2017, respectively, and was $29 million and $47 million for the nine months ended April 28, 2018 and April 29, 2017, respectively.

[0000858877-18-000007:notes:74]
Financing Guarantee Summary   The aggregate amounts of financing guarantees outstanding at April 28, 2018 and July 29, 2017, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

[0000858877-18-000007:notes:75]
|  | April 28, 2018 |  | July 29, 2017 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 262 |  |  | $ | 240 |  |
| End user | 41 |  |  | 74 |  |
| Total | $ | 303 |  |  | $ | 314 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (90 | ) |  | $ | (82 | ) |
| End user | (32 | ) |  | (52 | ) |
| Total | $ | (122 | ) |  | $ | (134 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue | $ | 181 |  |  | $ | 180 |  |

[0000858877-18-000007:notes:76]
Other Guarantees   The Company’s other guarantee arrangements as of April 28, 2018 and July 29, 2017 that were subject to recognition and disclosure requirements were not material.

[0000858877-18-000007:notes:77]
| (f) | Supplier Component Remediation Liabilities |

[0000858877-18-000007:notes:78]
In fiscal 2014, the Company recorded a charge to product cost of sales of $655 million resulting from failures related to products containing memory components manufactured by a single supplier between 2005 and 2010. The Company performs regular assessments of the sufficiency of this liability and reduced the amount by $74 million and $164 million in fiscal 2016 and fiscal 2015, respectively based on updated analyses. During the second quarter of fiscal 2017, the Company further reduced the liability by $141 million to reflect lower than expected defects, actual usage history, and estimated lower future remediation costs as more of the impacted products age and near the end of the support period covered by the remediation program. In addition, during the second quarter of fiscal 2017, the Company recorded a charge to product cost of sales of $125 million related to the expected remediation costs for anticipated failures in future periods of a widely-used component sourced from a third party which is included in several of the Company’s products. The liabilities related to the supplier component remediation matters as of April 28, 2018 and July 29, 2017 were $98 million and $174 million, respectively.

[0000858877-18-000007:notes:79]
| (g) | Indemnifications |

[0000858877-18-000007:notes:80]
In the normal course of business, the Company indemnifies other parties, including customers, lessors, and parties to other transactions with the Company, with respect to certain matters. The Company has agreed to hold such parties harmless against losses arising from a breach of representations or covenants or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim.

[0000858877-18-000007:notes:81]
The Company has been asked to indemnify certain of the Company’s service provider customers that have been subject to patent infringement claims asserted by Sprint Communications Company, L.P. in federal court in Kansas and Delaware. Sprint alleges that the service provider customers infringed Sprint’s patents by offering VoIP telephone services utilizing products provided by the Company generally in combination with those of other manufacturers. Sprint seeks monetary damages. Following a trial on March 3, 2017 against Time Warner Inc., a jury in Kansas found that Time Warner Cable willfully infringed five Sprint patents and awarded Sprint $139.8 million in damages. On March 14, 2017, the Kansas court declined Sprint's request for enhanced damages and entered judgment in favor of Sprint for $139.8 million plus 1.06% in post-judgment interest. On May 30, 2017, the Court awarded Sprint $20.3 million in pre-judgment interest and denied Time Warner Cable's post-trial motions. Time Warner Cable has appealed. On October 16, 2017, Sprint and Comcast Cable Communications, LLC reached resolution of the claims in Sprint's lawsuit against Comcast and, on October 19, 2017, the Kansas court dismissed Sprint's lawsuit. On December 6, 2017, Sprint and Cox Communications, Inc. reached resolution of the claims in Sprint's lawsuit against Cox, and the Delaware court dismissed Sprint's lawsuit against Cox on December 7, 2017.

[0000858877-18-000007:notes:82]
The Company believes that Time Warner Cable continues to have strong non-infringement and invalidity defenses and arguments and/or that Sprint’s damages claims are inconsistent with prevailing law at trial and/or on appeal. Due to the uncertainty surrounding the litigation process, the Company is unable to reasonably estimate the ultimate outcome of the Time Warner Cable litigation at this time. Should Sprint prevail in litigation, mediation, or settlement, the Company, in accordance with its agreements, may have an obligation to indemnify Time Warner Cable for damages, mediation awards, or settlement amounts arising from its use of Cisco products.

[0000858877-18-000007:notes:83]
On January 15, 2016, Huawei Technologies Co. Ltd. (“Huawei”) filed four patent infringement actions against T-Mobile US, Inc. and T-Mobile USA, Inc. (collectively, “T-Mobile”) in federal court in the Eastern District of Texas. Huawei alleged that T-Mobile’s use of 3GPP standards to implement its 3G and 4G cellular networks infringed 12 patents. Huawei's infringement allegations for some of the patents were based on T-Mobile's use of products provided by the Company in combination with those of other manufacturers. T-Mobile requested indemnity by the Company with respect to portions of the network that use the Company's equipment. On December 22, 2017, the Eastern District of Texas court dismissed Huawei's four lawsuits after the parties reached settlement, and T-Mobile's indemnity request was subsequently resolved.

[0000858877-18-000007:notes:84]
For the nine months ended April 28, 2018, the Company recorded legal and indemnification settlement charges of $127 million to product cost of sales in relation to these matters. At this time, the Company does not anticipate that its obligations regarding the final outcome of the above matters would be material.

[0000858877-18-000007:notes:85]
In addition, the Company has entered into indemnification agreements with its officers and directors, and the Company’s Amended and Restated Bylaws contain similar indemnification obligations to the Company’s agents.

[0000858877-18-000007:notes:86]
It is not possible to determine the maximum potential amount under these indemnification agreements due to the Company’s limited history with prior indemnification claims and the unique facts and circumstances involved in each particular agreement. Historically, payments made by the Company under these agreements have not had a material effect on the Company’s operating results, financial position, or cash flows.

[0000858877-18-000007:notes:87]
| (h) | Legal Proceedings |

[0000858877-18-000007:notes:88]
Brazil    Brazilian authorities have investigated the Company’s Brazilian subsidiary and certain of its former employees, as well as a Brazilian importer of the Company’s products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against the Company’s Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years.

[0000858877-18-000007:notes:89]
The asserted claims by Brazilian federal tax authorities that remain are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $234 million for the alleged evasion of import and other taxes, $1.5 billion for interest, and $1.1 billion for various penalties, all determined using an exchange rate as of April 28, 2018. The Company has completed a thorough review of the matters and believes the asserted claims against the Company’s Brazilian subsidiary are without merit, and the Company is defending the claims vigorously. While the Company believes there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, the Company is unable to determine the likelihood of an unfavorable outcome against its Brazilian subsidiary and is unable to reasonably estimate a range of loss, if any. The Company does not expect a final judicial determination for several years.

[0000858877-18-000007:notes:90]
SRI International     On September 4, 2013, SRI International, Inc. (“SRI”) asserted patent infringement claims against the Company in the U.S. District Court for the District of Delaware, accusing the Company's products and services in the area of network intrusion detection of infringing two U.S. patents. SRI sought monetary damages of at least a reasonable royalty and enhanced damages. The trial on these claims began on May 2, 2016 and on May 12, 2016, the jury returned a verdict finding willful infringement of the asserted patents. The jury awarded SRI damages of $23.7 million. On May 25, 2017, the Court awarded SRI enhanced damages and attorneys’ fees, entered judgment in the new amount of $57.0 million, and ordered an ongoing royalty of 3.5% through the expiration of the patents in 2018. The Company has appealed to the United States Court of Appeals for the Federal Circuit on various grounds. The Company believes it has strong arguments to overturn the jury verdict and/or reduce the damages award. While the ultimate outcome of the case may still result in a loss, the Company does not expect it to be material.

[0000858877-18-000007:notes:91]
SSL     SSL Services, LLC (“SSL”) has asserted claims for patent infringement against the Company in the U.S. District Court for the Eastern District of Texas. The proceeding was instituted on March 25, 2015. SSL alleges that the Company's AnyConnect products that include Virtual Private Networking functions infringed a U.S. patent owned by SSL. SSL seeks money damages from the Company. On August 18, 2015, the Company petitioned the Patent Trial and Appeal Board (“PTAB”) of the United States Patent and Trademark Office to review whether the patent SSL has asserted against the Company is valid over prior art. On February 23, 2016, a PTAB multi-judge panel found a reasonable likelihood that the Company would prevail in showing that SSL’s patent claims are unpatentable and instituted proceedings. On June 28, 2016, in light of the PTAB’s decision to review the patent’s validity, the district court issued an order staying the district court case pending the final written decision from the PTAB. On February 22, 2017, following a hearing, the PTAB issued its Final Written Decision that the patent’s claims are unpatentable. SSL appealed this decision to the Court of Appeals for the Federal Circuit and, on May 7, 2018, the Federal Circuit summarily affirmed the PTAB's decision of unpatentability.

[0000858877-18-000007:notes:92]
Straight Path     On September 24, 2014, Straight Path IP Group, Inc. (“Straight Path”) asserted patent infringement claims against the Company in the U.S. District Court for the Northern District of California, accusing the Company’s 9971 IP Phone, Unified Communications Manager working in conjunction with 9971 IP Phones, and Video Communication Server products of infringement. All of the asserted patents have expired and Straight Path was therefore limited to seeking monetary damages for the alleged past infringement. On November 13, 2017, the Court granted the Company's motion for summary judgment of non-infringement, thereby dismissing Straight Path's claims against the Company and cancelling a trial which had been set for March 12, 2018. On January 16, 2018, Straight Path appealed to the U.S. Court of Appeal for the Federal Circuit.

[0000858877-18-000007:notes:93]
DXC Technology     On August 21, 2015, the Company and Cisco Systems Capital Corporation (“Cisco Capital”) filed an action in Santa Clara County Superior Court for declaratory judgment and breach of contract against HP Inc. (“HP”) regarding a services agreement for management services of a third party’s network. HP had prepaid the service agreement through a financing arrangement with Cisco Capital, and had terminated its agreement with the Company. Pursuant to the terms of the service agreement with HP, the Company determined the credit HP was entitled to receive under the agreement for certain prepaid amounts. HP disputed the Company’s credit calculation and contended that the Company owes a larger credit to HP than the Company had calculated. In December 2015, the Company filed an amended complaint which dropped the breach of contract claim in light of HP’s continuing payments to Cisco Capital under the financing arrangement. On January 19, 2016, HP Inc. filed a counterclaim for breach of contract simultaneously with its answer to the amended complaint. DXC Technology Corporation (“DXC”) reported that it is the party in interest in this matter pursuant to the Separation and Distribution Agreement between the then Hewlett-Packard Co. and Hewlett Packard Enterprise Company (“HPE") and the subsequent Separation and Distribution Agreement between HPE and DXC. On January 8, 2018, the court continued the trial date from March 12, 2018 to June 11, 2018. The Company is unable to reasonably estimate the ultimate outcome of this litigation due to uncertainty surrounding the litigation process. However, the Company does not anticipate that its obligation, if any, regarding the final outcome of the dispute would be material.

[0000858877-18-000007:notes:94]
Arista Networks, Inc.     On February 24, 2016, Arista Networks, Inc. (“Arista”) filed a complaint against the Company in the U.S. District Court for the Northern District of California asserting monopolization claims in violation of Section 2 of the Sherman Act and an unfair competition claim under California Bus. and Prof. Code § 17200. On October 31, 2017, Arista filed an amended complaint for Sherman Act monopolization and § 17200 claims, alleging an anticompetitive scheme comprising the Company's copyright infringement action against Arista (which was based on Arista’s copying of the Company's copyright-protected user interfaces) and communications related to that litigation. Arista seeks injunctive relief, lost profits, enhanced damages, and restitution. A jury trial is scheduled for August 6, 2018.  The Company believes it has strong arguments that its conduct was lawful, legally protected, and not anticompetitive, as well as strong defenses to defeat Arista’s claims. However, due to uncertainty surrounding litigation processes, the Company is unable to reasonably estimate the ultimate outcome of this litigation at this time. However, the Company does not anticipate that any final outcome of the dispute would be material.

[0000858877-18-000007:notes:95]
Oyster Optics     On November 24, 2016, Oyster Optics, LLC (“Oyster”) asserted patent infringement claims against the Company in the U.S. District Court for the Eastern District of Texas. Oyster alleges that certain Cisco ONS 15454 and NCS 2000 line cards infringe U.S. Patent No. 7,620,327 (“the ‘327 Patent”). Oyster seeks monetary damages. Oyster filed infringement claims based on the ‘327 Patent against other defendants, including ZTE, Nokia, NEC, Infinera, Huawei, Ciena, Alcatel-Lucent, and Fujitsu, and the court consolidated the cases alleging infringement of the ‘327 Patent. The court set a trial date of June 4, 2018 for the cases against Infinera, Alcatel-Lucent, the Company and Huawei. While the Company believes that it has strong non-infringement arguments and that the patent is invalid, if the Company does not prevail in the District Court, the Company believes damages ultimately assessed would not be material. Due to uncertainty surrounding patent litigation processes, the Company is unable to reasonably estimate the ultimate outcome of this litigation at this time. However, the Company does not anticipate that any final outcome of the dispute would be material.

[0000858877-18-000007:notes:96]
In addition, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, the Company does not expect that the ultimate costs to resolve these matters will have a material adverse effect on its consolidated financial position, results of operations, or cash flows.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock

[0000858877-18-000007:notes:97]
The Company records a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of its future demand forecasts consistent with the valuation of the Company’s excess and obsolete inventory.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000858877-18-000007:notes:98]
[same as prior period, unchanged from 0000858877-18-000004:notes:96]

[0000858877-18-000007:notes:99]
The components of AOCI, net of tax, and the other comprehensive income (loss), excluding noncontrolling interest, for the nine months ended April 28, 2018 and April 29, 2017 are summarized as follows (in millions):

[0000858877-18-000007:notes:100]
|  | Net Unrealized Gains (Losses) on Available-for-Sale Investments |  | Net Unrealized Gains (Losses) Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Actuarial Gains (Losses) |  | Accumulated Other Comprehensive Income (Loss) |
| BALANCE AT JULY 29, 2017 | $ | 373 |  |  | $ | 32 |  |  | $ | (359 | ) |  | $ | 46 |  |
| Other comprehensive income (loss) before reclassifications attributable to Cisco Systems, Inc. | (620 | ) |  | 28 |  |  | 34 |  |  | (558 | ) |
| (Gains) losses reclassified out of AOCI | (108 | ) |  | (59 | ) |  | 5 |  |  | (162 | ) |
| Tax benefit (expense) | 24 |  |  | 4 |  |  | (3 | ) |  | 25 |  |
| Total change for the period | (704 | ) |  | (27 | ) |  | 36 |  |  | (695 | ) |
| Effect of adoption of accounting standard | 54 |  |  | — |  |  | (9 | ) |  | 45 |  |
| BALANCE AT APRIL 28, 2018 | $ | (277 | ) |  | $ | 5 |  |  | $ | (332 | ) |  | $ | (604 | ) |

[0000858877-18-000007:notes:101]
|  | Net Unrealized Gains (Losses) on Available-for-Sale Investments |  | Net Unrealized Gains (Losses) Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Actuarial Gains (Losses) |  | Accumulated Other Comprehensive Income (Loss) |
| BALANCE AT JULY 30, 2016 | $ | 413 |  |  | $ | (59 | ) |  | $ | (680 | ) |  | $ | (326 | ) |
| Other comprehensive income (loss) before reclassifications attributable to Cisco Systems, Inc. | (298 | ) |  | (23 | ) |  | 69 |  |  | (252 | ) |
| (Gains) losses reclassified out of AOCI | 91 |  |  | 66 |  |  | 1 |  |  | 158 |  |
| Tax benefit (expense) | 91 |  |  | (6 | ) |  | (7 | ) |  | 78 |  |
| Total change for the period | (116 | ) |  | 37 |  |  | 63 |  |  | (16 | ) |
| BALANCE AT APRIL 29, 2017 | $ | 297 |  |  | $ | (22 | ) |  | $ | (617 | ) |  | $ | (342 | ) |

[0000858877-18-000007:notes:102]
[same as prior period, unchanged from 0000858877-18-000004:notes:100]

[0000858877-18-000007:notes:103]
|  |  | Three Months Ended |  | Nine Months Ended |  |
|  |  | April 28, 2018 |  | April 29, 2017 |  | April 28, 2018 |  | April 29, 2017 |  |
| Comprehensive Income Components |  | Income Before Taxes |  | Income Before Taxes | Line Item in Statements of Operations |
| Net unrealized gains and losses on available-for-sale investments |  | $ | 17 |  |  | $ | (76 | ) |  | $ | 108 |  |  | $ | (91 | ) | Other income (loss), net |
| Net unrealized gains and losses on cash flow hedging instruments |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | 21 |  |  | (20 | ) |  | 45 |  |  | (50 | ) | Operating expenses |
| Foreign currency derivatives |  | 7 |  |  | (7 | ) |  | 14 |  |  | (16 | ) | Cost of sales—service |
|  |  | 28 |  |  | (27 | ) |  | 59 |  |  | (66 | ) |  |
| Cumulative translation adjustment and actuarial gains and losses |  | — |  |  | (2 | ) |  | (5 | ) |  | (1 | ) | Operating expenses |
| Total amounts reclassified out of AOCI |  | $ | 45 |  |  | $ | (105 | ) |  | $ | 162 |  |  | $ | (158 | ) |  |


## us-gaap:DebtDisclosureTextBlock

[0000858877-18-000007:notes:104]
Borrowings

[0000858877-18-000007:notes:105]
| (a) | Short-Term Debt |

[0000858877-18-000007:notes:106]
The following table summarizes the Company’s short-term debt (in millions, except percentages):

[0000858877-18-000007:notes:107]
|  | April 28, 2018 |  | July 29, 2017 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 7,736 |  |  | 2.91 | % |  | $ | 4,747 |  |  | 1.66 | % |
| Commercial paper | — |  |  | — | % |  | 3,245 |  |  | 1.16 | % |
| Total short-term debt | $ | 7,736 |  |  |  |  | $ | 7,992 |  |  |  |

[0000858877-18-000007:notes:108]
The Company has a short-term debt financing program of up to $10.0 billion through the issuance of commercial paper notes. The Company uses the proceeds from the issuance of commercial paper notes for general corporate purposes.

[0000858877-18-000007:notes:109]
The effective rates for the short- and long-term debt include the interest on the notes, the accretion of the discount, the issuance costs, and, if applicable, adjustments related to hedging.

[0000858877-18-000007:notes:110]
| (b) | Long-Term Debt |

[0000858877-18-000007:notes:111]
The following table summarizes the Company’s long-term debt (in millions, except percentages):

[0000858877-18-000007:notes:112]
|  |  |  | April 28, 2018 |  | July 29, 2017 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.60% | February 21, 2018 |  | $ | — |  |  | — |  | $ | 1,000 |  |  | 1.84% |
| Three-month LIBOR plus 0.31% | June 15, 2018 |  | 900 |  |  | 2.50% |  | 900 |  |  | 1.62% |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | 500 |  |  | 2.57% |  | 500 |  |  | 1.76% |
| Three-month LIBOR plus 0.34% | September 20, 2019 |  | 500 |  |  | 2.58% |  | 500 |  |  | 1.66% |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 1.40% | February 28, 2018 |  | — |  |  | — |  | 1,250 |  |  | 1.47% |
| 1.65% | June 15, 2018 |  | 1,600 |  |  | 1.72% |  | 1,600 |  |  | 1.72% |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 5.12% |  | 2,000 |  |  | 4.96% |
| 1.60% | February 28, 2019 |  | 1,000 |  |  | 1.67% |  | 1,000 |  |  | 1.67% |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 2.50% |  | 1,750 |  |  | 1.84% |
| 1.40% | September 20, 2019 |  | 1,500 |  |  | 1.48% |  | 1,500 |  |  | 1.48% |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 4.38% |  | 2,500 |  |  | 3.84% |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 2.54% |  | 1,500 |  |  | 2.54% |
| 2.20% | February 28, 2021 |  | 2,500 |  |  | 2.30% |  | 2,500 |  |  | 2.30% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 2.66% |  | 500 |  |  | 2.00% |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 1.90% |  | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 2.94% |  | 500 |  |  | 2.26% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 2.78% |  | 1,000 |  |  | 2.12% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 3.10% |  | 500 |  |  | 2.43% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 28,250 |  |  |  |  | 30,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (119 | ) |  |  |  | (136 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | (59 | ) |  |  |  | 108 |  |  |  |
| Total |  |  | $ | 28,072 |  |  |  |  | $ | 30,472 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 7,736 |  |  |  |  | $ | 4,747 |  |  |  |
| Long-term debt |  |  | 20,336 |  |  |  |  | 25,725 |  |  |  |
| Total |  |  | $ | 28,072 |  |  |  |  | $ | 30,472 |  |  |  |

[0000858877-18-000007:notes:113]
The Company entered into interest rate swaps in prior periods with an aggregate notional amount of $6.75 billion designated as fair value hedges of certain of its fixed-rate senior notes. These swaps convert the fixed interest rates of the fixed-rate notes to floating interest rates based on the London InterBank Offered Rate ("LIBOR"). The gains and losses related to changes in the fair value of the interest rate swaps substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates. For additional information, see Note 11.

[0000858877-18-000007:notes:114]
Interest is payable semiannually on each class of the senior fixed-rate notes and payable quarterly on the floating-rate notes. Each of the senior fixed-rate notes is redeemable by the Company at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that have been issued in the future pursuant to the Company’s short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of April 28, 2018, the Company was in compliance with all debt covenants.

[0000858877-18-000007:notes:115]
As of April 28, 2018, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

[0000858877-18-000007:notes:116]
| Fiscal Year | Amount |
| 2018 (remaining three months) | $ | 2,500 |  |
| 2019 | 5,250 |  |
| 2020 | 6,000 |  |
| 2021 | 3,000 |  |
| 2022 | 2,500 |  |
| Thereafter | 9,000 |  |
| Total | $ | 28,250 |  |

[0000858877-18-000007:notes:117]
| (c) | Credit Facility |

[0000858877-18-000007:notes:118]
On May 15, 2015, the Company entered into a credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 15, 2020. Any advances under the credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (i) the highest of (a) the Federal Funds rate plus 0.50%, (b) Bank of America’s “prime rate” as announced from time to time, or (c) LIBOR, or a comparable or successor rate that is approved by the Administrative Agent (“Eurocurrency Rate”), for an interest period of one-month plus 1.00%, or (ii) the Eurocurrency Rate, plus a margin that is based on the Company’s senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the Eurocurrency Rate be less than zero. The Company may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and/or extend the expiration date of the credit facility up to May 15, 2022.

[0000858877-18-000007:notes:119]
This credit agreement requires that the Company comply with certain covenants, including that the Company maintains an interest coverage ratio as defined in the agreement. As of April 28, 2018, the Company was in compliance with the required interest coverage ratio and the other covenants, and the Company had not borrowed any funds under this credit facility.


## us-gaap:DeferredRevenueByArrangementDisclosureTextBlock

[0000858877-18-000007:notes:120]
| Deferred revenue: |  |  |  |  |
| Service |  | $ | 10,960 |  |  | $ | 11,302 |  |
| Product: |  |  |  |  |
| Deferred revenue related to recurring software and subscription offers |  | 5,635 |  |  | 4,971 |  |
| Other product deferred revenue |  | 2,358 |  |  | 2,221 |  |
| Total product deferred revenue |  | 7,993 |  |  | 7,192 |  |
| Total |  | $ | 18,953 |  |  | $ | 18,494 |  |
| Reported as: |  |  |  |  |
| Current |  | $ | 11,301 |  |  | $ | 10,821 |  |
| Noncurrent |  | 7,652 |  |  | 7,673 |  |
| Total |  | $ | 18,953 |  |  | $ | 18,494 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000858877-18-000007:notes:121]
[same as prior period, unchanged from 0000858877-18-000004:notes:120]

[0000858877-18-000007:notes:122]
[same as prior period, unchanged from 0000858877-18-000004:notes:121]

[0000858877-18-000007:notes:123]
[same as prior period, unchanged from 0000858877-18-000004:notes:122]

[0000858877-18-000007:notes:124]
[same as prior period, unchanged from 0000858877-18-000004:notes:123]

[0000858877-18-000007:notes:125]
|  | DERIVATIVE ASSETS |  | DERIVATIVE LIABILITIES |
|  | Balance Sheet Line Item |  | April 28, 2018 |  | July 29, 2017 |  | Balance Sheet Line Item |  | April 28, 2018 |  | July 29, 2017 |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | $ | 12 |  |  | $ | 46 |  |  | Other current liabilities |  | $ | 1 |  |  | $ | 1 |  |
| Equity derivatives | Other current assets |  | — |  |  | — |  |  | Other current liabilities |  | 24 |  |  | — |  |
| Interest rate derivatives | Other current assets |  | — |  |  | — |  |  | Other current liabilities |  | 12 |  |  | — |  |
| Interest rate derivatives | Other assets |  | — |  |  | 102 |  |  | Other long-term liabilities |  | 54 |  |  | — |  |
| Total |  |  | 12 |  |  | 148 |  |  |  |  | 91 |  |  | 1 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | 1 |  |  | 1 |  |  | Other current liabilities |  | 1 |  |  | 3 |  |
| Total return swaps—deferred compensation | Other current assets |  | — |  |  | — |  |  | Other current liabilities |  | — |  |  | — |  |
| Total |  |  | 1 |  |  | 1 |  |  |  |  | 1 |  |  | 3 |  |
| Total |  |  | $ | 13 |  |  | $ | 149 |  |  |  |  | $ | 92 |  |  | $ | 4 |  |

[0000858877-18-000007:notes:126]
[same as prior period, unchanged from 0000858877-18-000004:notes:125]

[0000858877-18-000007:notes:127]
| GAINS (LOSSES) RECOGNIZEDIN OCI ON DERIVATIVES FOR THE THREE MONTHS ENDED (EFFECTIVE PORTION) |  | GAINS (LOSSES) RECLASSIFIED FROMAOCI INTO INCOME FOR THETHREE MONTHS ENDED (EFFECTIVE PORTION) |
|  |  | April 28, 2018 |  | April 29, 2017 |  | Line Item in Statements of Operations |  | April 28, 2018 |  | April 29, 2017 |
| Derivatives designated as cash flow hedging instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | (10 | ) |  | $ | 25 |  |  | Operating expenses |  | $ | 21 |  |  | $ | (20 | ) |
|  |  |  |  |  |  | Cost of sales—service |  | 7 |  |  | (7 | ) |
| Total |  | $ | (10 | ) |  | $ | 25 |  |  |  |  | $ | 28 |  |  | $ | (27 | ) |
| Derivatives designated as net investment hedging instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | 7 |  |  | $ | (10 | ) |  | Other income (loss), net |  | $ | — |  |  | $ | — |  |

[0000858877-18-000007:notes:128]
| GAINS (LOSSES) RECOGNIZEDIN OCI ON DERIVATIVES FOR THE NINE MONTHS ENDED (EFFECTIVE PORTION) |  | GAINS (LOSSES) RECLASSIFIED FROMAOCI INTO INCOME FOR THENINE MONTHS ENDED (EFFECTIVE PORTION) |
|  |  | April 28, 2018 |  | April 29, 2017 |  | Line Item in Statements of Operations |  | April 28, 2018 |  | April 29, 2017 |
| Derivatives designated as cash flow hedging instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | 28 |  |  | $ | (23 | ) |  | Operating expenses |  | $ | 45 |  |  | $ | (50 | ) |
|  |  |  |  |  |  | Cost of sales—service |  | 14 |  |  | (16 | ) |
| Total |  | $ | 28 |  |  | $ | (23 | ) |  |  |  | $ | 59 |  |  | $ | (66 | ) |
| Derivatives designated as net investment hedging instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | (10 | ) |  | $ | (4 | ) |  | Other income (loss), net |  | $ | — |  |  | $ | — |  |

[0000858877-18-000007:notes:129]
As of April 28, 2018, the Company estimates that approximately $18 million of net derivative gains related to its cash flow hedges included in AOCI will be reclassified into earnings within the next 12 months when the underlying hedged item impacts earnings.

[0000858877-18-000007:notes:130]
[same as prior period, unchanged from 0000858877-18-000004:notes:129]

[0000858877-18-000007:notes:131]
|  |  |  |  | GAINS (LOSSES) FOR THETHREE MONTHS ENDED |  | GAINS (LOSSES) FOR THENINE MONTHS ENDED |
| Derivatives Not Designated as Hedging Instruments |  | Line Item in Statements of Operations |  | April 28, 2018 |  | April 29, 2017 |  | April 28, 2018 |  | April 29, 2017 |
| Foreign currency derivatives |  | Other income (loss), net |  | $ | (53 | ) |  | $ | 4 |  |  | $ | 20 |  |  | $ | (32 | ) |
| Total return swaps—deferred compensation |  | Operating expenses |  | (28 | ) |  | 19 |  |  | 29 |  |  | 42 |  |
| Equity derivatives |  | Other income (loss), net |  | (7 | ) |  | 1 |  |  | (4 | ) |  | 10 |  |
| Total |  |  |  | $ | (88 | ) |  | $ | 24 |  |  | $ | 45 |  |  | $ | 20 |  |

[0000858877-18-000007:notes:132]
[same as prior period, unchanged from 0000858877-18-000004:notes:131]

[0000858877-18-000007:notes:133]
|  | April 28, 2018 |  | July 29, 2017 |
| Derivatives designated as hedging instruments: |  |  |  |
| Foreign currency derivatives—cash flow hedges | $ | 326 |  |  | $ | 1,696 |  |
| Interest rate derivatives | 6,750 |  |  | 6,750 |  |
| Net investment hedging instruments | 455 |  |  | 351 |  |
| Equity derivatives | 302 |  |  | — |  |
| Derivatives not designated as hedging instruments: |  |  |  |
| Foreign currency derivatives | 2,199 |  |  | 2,258 |  |
| Total return swaps—deferred compensation | 553 |  |  | 535 |  |
| Total | $ | 10,585 |  |  | $ | 11,590 |  |

[0000858877-18-000007:notes:134]
[same as prior period, unchanged from 0000858877-18-000004:notes:133]

[0000858877-18-000007:notes:135]
[same as prior period, unchanged from 0000858877-18-000004:notes:134]

[0000858877-18-000007:notes:136]
|  | April 28, 2018 |
|  | GROSS AMOUNTS OFFSET IN THE CONSOLIDATED BALANCE SHEETS |  | GROSS AMOUNTS NOT OFFSET IN THE CONSOLIDATED BALANCE SHEETSBUT WITH LEGAL RIGHTS TO OFFSET |
|  | Gross Amounts Recognized |  | Gross Amounts Offset |  | Net Amounts Presented |  | Gross Derivative Amounts |  | Cash Collateral |  | Net Amount |
| Derivatives assets | $ | 13 |  |  | $ | — |  |  | $ | 13 |  |  | $ | (8 | ) |  | $ | — |  |  | $ | 5 |  |
| Derivatives liabilities | $ | 92 |  |  | $ | — |  |  | $ | 92 |  |  | $ | (8 | ) |  | $ | (50 | ) |  | $ | 34 |  |

[0000858877-18-000007:notes:137]
[same as prior period, unchanged from 0000858877-18-000004:notes:136]

[0000858877-18-000007:notes:138]
[same as prior period, unchanged from 0000858877-18-000004:notes:137]

[0000858877-18-000007:notes:139]
[same as prior period, unchanged from 0000858877-18-000004:notes:138]

[0000858877-18-000007:notes:140]
[same as prior period, unchanged from 0000858877-18-000004:notes:139]

[0000858877-18-000007:notes:141]
[same as prior period, unchanged from 0000858877-18-000004:notes:140]

[0000858877-18-000007:notes:142]
[same as prior period, unchanged from 0000858877-18-000004:notes:141]

[0000858877-18-000007:notes:143]
[same as prior period, unchanged from 0000858877-18-000004:notes:142]

[0000858877-18-000007:notes:144]
Interest Rate Derivatives, Investments   The Company’s primary objective for holding fixed income securities is to achieve an appropriate investment return consistent with preserving principal and managing risk. To realize these objectives, the Company may utilize interest rate swaps or other derivatives designated as fair value or cash flow hedges. As of April 28, 2018 and July 29, 2017, the Company did not have any outstanding interest rate derivatives related to its fixed income securities.

[0000858877-18-000007:notes:145]
Interest Rate Derivatives Designated as Fair Value Hedges, Long-Term Debt  In the nine months ended April 28, 2018, the Company did not enter into any interest rate swaps. In prior fiscal years, the Company entered into interest rate swaps designated as fair value hedges related to fixed-rate senior notes that are due in fiscal 2019 through 2025. Under these interest rate swaps, the Company receives fixed-rate interest payments and makes interest payments based on LIBOR plus a fixed number of basis points. The effect of such swaps is to convert the fixed interest rates of the senior fixed-rate notes to floating interest rates based on LIBOR. The gains and losses related to changes in the fair value of the interest rate swaps are included in interest expense and substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates. The fair value of the interest rate swaps was reflected in other current assets and other assets.

[0000858877-18-000007:notes:146]
[same as prior period, unchanged from 0000858877-18-000004:notes:145]

[0000858877-18-000007:notes:147]
[same as prior period, unchanged from 0000858877-18-000004:notes:146]

[0000858877-18-000007:notes:148]
[same as prior period, unchanged from 0000858877-18-000004:notes:147]

[0000858877-18-000007:notes:149]
[same as prior period, unchanged from 0000858877-18-000004:notes:148]

[0000858877-18-000007:notes:150]
[same as prior period, unchanged from 0000858877-18-000004:notes:149]


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000858877-18-000007:notes:151]
[same as prior period, unchanged from 0000858877-18-000004:notes:150]

[0000858877-18-000007:notes:152]
[same as prior period, unchanged from 0000858877-18-000004:notes:151]

[0000858877-18-000007:notes:153]
Stock Incentive Plan Program Description    As of April 28, 2018, the Company had one stock incentive plan: the 2005 Stock Incentive Plan (the “2005 Plan”). In addition, the Company has, in connection with the acquisitions of various companies, assumed the share-based awards granted under stock incentive plans of the acquired companies or issued share-based awards in replacement thereof. Share-based awards are designed to reward employees for their long-term contributions to the Company and provide incentives for them to remain with the Company.  The number and frequency of share-based awards are based on competitive practices, operating results of the Company, government regulations, and other factors. The Company’s primary stock incentive plan is summarized as follows:

[0000858877-18-000007:notes:154]
2005 Plan    As of April 28, 2018, the maximum number of shares issuable under the 2005 Plan over its term was 694 million shares, plus shares from certain previous plans that are forfeited or are terminated for any other reason before being exercised or settled. If any awards granted under the 2005 Plan are forfeited or are terminated for any other reason before being exercised or settled, the unexercised or unsettled shares underlying the awards will again be available under the 2005 Plan. In addition, starting November 19, 2013, shares withheld by the Company from an award other than a stock option or stock appreciation right to satisfy withholding tax liabilities resulting from such award will again be available for issuance, based on the fungible share ratio in effect on the date of grant.

[0000858877-18-000007:notes:155]
[same as prior period, unchanged from 0000858877-18-000004:notes:154]

[0000858877-18-000007:notes:156]
[same as prior period, unchanged from 0000858877-18-000004:notes:155]

[0000858877-18-000007:notes:157]
[same as prior period, unchanged from 0000858877-18-000004:notes:156]

[0000858877-18-000007:notes:158]
The Company has an Employee Stock Purchase Plan, which includes its subplan named the International Employee Stock Purchase Plan (together, the “Purchase Plan”), under which 621 million shares of the Company’s common stock have been reserved for issuance as of April 28, 2018. Eligible employees are offered shares through a 24-month offering period, which consists of four consecutive 6-month purchase periods. Employees may purchase a limited number of shares of the Company’s stock at a discount of up to 15% of the lesser of the market value at the beginning of the offering period or the end of each 6-month purchase period.  The Purchase Plan is scheduled to terminate on January 3, 2020. The Company issued 12 million shares under the Purchase Plan during each of the nine months ended April 28, 2018 and April 29, 2017. As of April 28, 2018, 88 million shares were available for issuance under the Purchase Plan.

[0000858877-18-000007:notes:159]
[same as prior period, unchanged from 0000858877-18-000004:notes:158]

[0000858877-18-000007:notes:160]
[same as prior period, unchanged from 0000858877-18-000004:notes:159]

[0000858877-18-000007:notes:161]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 28, 2018 |  | April 29, 2017 |  | April 28, 2018 |  | April 29, 2017 |
| Cost of sales—product | $ | 24 |  |  | $ | 22 |  |  | $ | 70 |  |  | $ | 62 |  |
| Cost of sales—service | 33 |  |  | 34 |  |  | 98 |  |  | 101 |  |
| Share-based compensation expense in cost of sales | 57 |  |  | 56 |  |  | 168 |  |  | 163 |  |
| Research and development | 139 |  |  | 137 |  |  | 409 |  |  | 392 |  |
| Sales and marketing | 142 |  |  | 133 |  |  | 412 |  |  | 398 |  |
| General and administrative | 61 |  |  | 79 |  |  | 189 |  |  | 173 |  |
| Restructuring and other charges | 6 |  |  | (5 | ) |  | 24 |  |  | (2 | ) |
| Share-based compensation expense in operating expenses | 348 |  |  | 344 |  |  | 1,034 |  |  | 961 |  |
| Total share-based compensation expense | $ | 405 |  |  | $ | 400 |  |  | $ | 1,202 |  |  | $ | 1,124 |  |
| Income tax benefit for share-based compensation | $ | 140 |  |  | $ | 120 |  |  | $ | 411 |  |  | $ | 327 |  |

[0000858877-18-000007:notes:162]
As of April 28, 2018, the total compensation cost related to unvested share-based awards not yet recognized was $3.0 billion which is expected to be recognized over approximately 2.5 years on a weighted-average basis.

[0000858877-18-000007:notes:163]
[same as prior period, unchanged from 0000858877-18-000004:notes:162]

[0000858877-18-000007:notes:164]
[same as prior period, unchanged from 0000858877-18-000004:notes:163]

[0000858877-18-000007:notes:165]
|  | Share-Based Awards Available for Grant |
| BALANCE AT JULY 30, 2016 | 242 |  |
| Restricted stock, stock units, and other share-based awards granted | (76 | ) |
| Share-based awards canceled/forfeited/expired | 78 |  |
| Shares withheld for taxes and not issued | 28 |  |
| BALANCE AT JULY 29, 2017 | 272 |  |
| Restricted stock, stock units, and other share-based awards granted | (50 | ) |
| Share-based awards canceled/forfeited/expired | 14 |  |
| Shares withheld for taxes and not issued | 20 |  |
| BALANCE AT APRIL 28, 2018 | 256 |  |

[0000858877-18-000007:notes:166]
[same as prior period, unchanged from 0000858877-18-000004:notes:165]

[0000858877-18-000007:notes:167]
[same as prior period, unchanged from 0000858877-18-000004:notes:166]

[0000858877-18-000007:notes:168]
[same as prior period, unchanged from 0000858877-18-000004:notes:167]

[0000858877-18-000007:notes:169]
|  | Restricted Stock/Stock Units |  | Weighted-AverageGrant Date FairValue per Share |  | Aggregate Fair Value |
| UNVESTED BALANCE AT JULY 30, 2016 | 145 |  |  | $ | 24.26 |  |  |  |
| Granted | 50 |  |  | 27.89 |  |  |  |
| Assumed from acquisitions | 15 |  |  | 32.21 |  |  |  |
| Vested | (54 | ) |  | 23.14 |  |  | $ | 1,701 |  |
| Canceled/forfeited | (15 | ) |  | 23.56 |  |  |  |
| UNVESTED BALANCE AT JULY 29, 2017 | 141 |  |  | 26.94 |  |  |  |
| Granted | 33 |  |  | 33.82 |  |  |  |
| Assumed from acquisitions | 1 |  |  | 28.26 |  |  |  |
| Vested | (43 | ) |  | 25.44 |  |  | $ | 1,450 |  |
| Canceled/forfeited | (13 | ) |  | 28.14 |  |  |  |
| UNVESTED BALANCE AT APRIL 28, 2018 | 119 |  |  | $ | 29.26 |  |  |  |

[0000858877-18-000007:notes:170]
[same as prior period, unchanged from 0000858877-18-000004:notes:169]

[0000858877-18-000007:notes:171]
[same as prior period, unchanged from 0000858877-18-000004:notes:170]

[0000858877-18-000007:notes:172]
|  | STOCK OPTIONS OUTSTANDING |
|  | NumberOutstanding |  | Weighted-AverageExercise Price per Share |
| BALANCE AT JULY 30, 2016 | 73 |  |  | $ | 26.78 |  |
| Assumed from acquisitions | 8 |  |  | 4.47 |  |
| Exercised | (14 | ) |  | 12.11 |  |
| Canceled/forfeited/expired | (55 | ) |  | 31.83 |  |
| BALANCE AT JULY 29, 2017 | 12 |  |  | 6.15 |  |
| Assumed from acquisitions | 3 |  |  | 8.20 |  |
| Exercised | (6 | ) |  | 5.79 |  |
| Canceled/forfeited/expired | (1 | ) |  | 8.48 |  |
| BALANCE AT APRIL 28, 2018 | 8 |  |  | $ | 7.02 |  |

[0000858877-18-000007:notes:173]
The following table summarizes significant ranges of outstanding and exercisable stock options as of April 28, 2018 (in millions, except years and share prices):

[0000858877-18-000007:notes:174]
|  |  | STOCK OPTIONS OUTSTANDING |  | STOCK OPTIONS EXERCISABLE |
| Range of Exercise Prices |  | NumberOutstanding |  | Weighted-AverageRemainingContractualLife(in Years) |  | Weighted-AverageExercisePrice perShare |  | AggregateIntrinsicValue |  | NumberExercisable |  | Weighted-AverageExercisePrice perShare |  | AggregateIntrinsicValue |
| $ 0.01 – 35.00 |  | 8 |  |  | 6.2 |  | $ | 7.02 |  |  | $ | 300 |  |  | 5 |  |  | $ | 6.61 |  |  | $ | 174 |  |

[0000858877-18-000007:notes:175]
The aggregate intrinsic value in the preceding table represents the total pretax intrinsic value, based on the Company’s closing stock price of $44.71 as of April 27, 2018, that would have been received by the option holders had those option holders exercised their stock options as of that date. The total number of in-the-money stock options exercisable as of April 28, 2018 was 5 million. As of July 29, 2017, 6 million outstanding stock options were exercisable and the weighted-average exercise price was $5.61.

[0000858877-18-000007:notes:176]
[same as prior period, unchanged from 0000858877-18-000004:notes:175]

[0000858877-18-000007:notes:177]
[same as prior period, unchanged from 0000858877-18-000004:notes:176]

[0000858877-18-000007:notes:178]
|  | RESTRICTED STOCK UNITS |  | PERFORMANCE BASEDRESTRICTED STOCK UNITS |
| Three Months Ended | April 28, 2018 |  | April 29, 2017 |  | April 28, 2018 |  | April 29, 2017 |
| Number of shares granted (in millions) | 2 |  |  | 1 |  |  | — |  |  | — |  |
| Grant date fair value per share | $ | 39.31 |  |  | $ | 30.91 |  |  | $ | 43.44 |  |  | $ | 31.65 |  |
| Weighted-average assumptions/inputs: |  |  |  |  |  |  |  |
| Expected dividend yield | 2.9 | % |  | 3.4 | % |  | 3.0 | % |  | 3.4 | % |
| Range of risk-free interest rates | 0.0% – 2.6% |  |  | 0.0% – 1.5% |  |  | 1.5% – 2.5% |  |  | 0.8%-1.5% |  |
| Range of expected volatilities for index | N/A |  |  | N/A |  |  | 12.5% – 82.8% |  |  | N/A |  |

[0000858877-18-000007:notes:179]
|  | RESTRICTED STOCK UNITS |  | PERFORMANCE BASEDRESTRICTED STOCK UNITS |
| Nine Months Ended | April 28, 2018 |  | April 29, 2017 |  | April 28, 2018 |  | April 29, 2017 |
| Number of shares granted (in millions) | 30 |  |  | 23 |  |  | 3 |  |  | 7 |  |
| Grant date fair value per share | $ | 33.97 |  |  | $ | 28.05 |  |  | $ | 31.96 |  |  | $ | 28.90 |  |
| Weighted-average assumptions/inputs: |  |  |  |  |  |  |  |
| Expected dividend yield | 3.2 | % |  | 3.4 | % |  | 3.5 | % |  | 3.4 | % |
| Range of risk-free interest rates | 0.0% – 2.6% |  |  | 0.0% – 1.5% |  |  | 1.0% – 2.5% |  |  | 0.1% – 1.5% |  |
| Range of expected volatilities for index | N/A |  |  | N/A |  |  | 12.5% – 82.8% |  |  | 16.7% – 46.8% |  |

[0000858877-18-000007:notes:180]
[same as prior period, unchanged from 0000858877-18-000004:notes:179]


## us-gaap:EarningsPerSharePolicyTextBlock

[0000858877-18-000007:notes:181]
[same as prior period, unchanged from 0000858877-18-000004:notes:180]


## us-gaap:EarningsPerShareTextBlock

[0000858877-18-000007:notes:182]
[same as prior period, unchanged from 0000858877-18-000004:notes:181]

[0000858877-18-000007:notes:183]
[same as prior period, unchanged from 0000858877-18-000004:notes:182]

[0000858877-18-000007:notes:184]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 28, 2018 |  | April 29, 2017 |  | April 28, 2018 |  | April 29, 2017 |
| Net income (loss) | $ | 2,691 |  |  | $ | 2,515 |  |  | $ | (3,693 | ) |  | $ | 7,185 |  |
| Weighted-average shares—basic | 4,791 |  |  | 5,005 |  |  | 4,892 |  |  | 5,015 |  |
| Effect of dilutive potential common shares | 53 |  |  | 40 |  |  | — |  |  | 41 |  |
| Weighted-average shares—diluted | 4,844 |  |  | 5,045 |  |  | 4,892 |  |  | 5,056 |  |
| Net income (loss) per share—basic | $ | 0.56 |  |  | $ | 0.50 |  |  | $ | (0.76 | ) |  | $ | 1.43 |  |
| Net income (loss) per share—diluted | $ | 0.56 |  |  | $ | 0.50 |  |  | $ | (0.76 | ) |  | $ | 1.42 |  |

[0000858877-18-000007:notes:185]
The Company excluded antidilutive employee-share based awards of 5 million and 6 million for the three months ended April 28, 2018 and April 29, 2017, respectively. The Company excluded antidilutive employee-share based awards of 118 million for the nine months ended April 29, 2017.  For the nine months ended April 28, 2018, the Company excluded the impact of potentially dilutive common shares from the calculation of net income (loss) per share as the inclusion would have an antidilutive effect.


## us-gaap:FairValueAssetsMeasuredOnNonrecurringBasisTextBlock

[0000858877-18-000007:notes:186]
[same as prior period, unchanged from 0000858877-18-000004:notes:185]

[0000858877-18-000007:notes:187]
|  | TOTAL GAINS (LOSSES) FOR THE THREE MONTHS ENDED |  | TOTAL GAINS (LOSSES) FOR THE NINE MONTHS ENDED |
|  | April 28, 2018 |  | April 29, 2017 |  | April 28, 2018 |  | April 29, 2017 |
| Investments in privately held companies (impaired) | $ | (12 | ) |  | $ | (51 | ) |  | $ | (51 | ) |  | $ | (162 | ) |
| Purchased intangible assets (impaired) | (1 | ) |  | — |  |  | (1 | ) |  | (42 | ) |
| Property held for sale—land and buildings | — |  |  | — |  |  | 20 |  |  | (24 | ) |
| Gains (losses) on assets no longer held | (5 | ) |  | — |  |  | (5 | ) |  | — |  |
| Total gains (losses) for nonrecurring measurements | $ | (18 | ) |  | $ | (51 | ) |  | $ | (37 | ) |  | $ | (228 | ) |


## us-gaap:FairValueDisclosuresTextBlock

[0000858877-18-000007:notes:188]
[same as prior period, unchanged from 0000858877-18-000004:notes:187]

[0000858877-18-000007:notes:189]
[same as prior period, unchanged from 0000858877-18-000004:notes:188]

[0000858877-18-000007:notes:190]
[same as prior period, unchanged from 0000858877-18-000004:notes:189]

[0000858877-18-000007:notes:191]
[same as prior period, unchanged from 0000858877-18-000004:notes:190]

[0000858877-18-000007:notes:192]
[same as prior period, unchanged from 0000858877-18-000004:notes:191]

[0000858877-18-000007:notes:193]
[same as prior period, unchanged from 0000858877-18-000004:notes:192]

[0000858877-18-000007:notes:194]
[same as prior period, unchanged from 0000858877-18-000004:notes:193]

[0000858877-18-000007:notes:195]
[same as prior period, unchanged from 0000858877-18-000004:notes:194]

[0000858877-18-000007:notes:196]
Assets and liabilities measured at fair value on a recurring basis as of April 28, 2018 and July 29, 2017 were as follows (in millions):

[0000858877-18-000007:notes:197]
|  | APRIL 28, 2018FAIR VALUE MEASUREMENTS |  | JULY 29, 2017FAIR VALUE MEASUREMENTS |
|  | Level 1 |  | Level 2 |  | Level 3 |  | TotalBalance |  | Level 1 |  | Level 2 |  | Level 3 |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 4,732 |  |  | $ | — |  |  | $ | — |  |  | $ | 4,732 |  |  | $ | 9,567 |  |  | $ | — |  |  | $ | — |  |  | $ | 9,567 |  |
| U.S. government securities | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 139 |  |  | — |  |  | 139 |  |
| Commercial paper | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 160 |  |  | — |  |  | 160 |  |
| Certificates of deposit | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 25 |  |  | — |  |  | 25 |  |
| Available-for-sale investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | — |  |  | 13,531 |  |  | — |  |  | 13,531 |  |  | — |  |  | 19,823 |  |  | — |  |  | 19,823 |  |
| U.S. government agency securities | — |  |  | 1,156 |  |  | — |  |  | 1,156 |  |  | — |  |  | 2,052 |  |  | — |  |  | 2,052 |  |
| Non-U.S. government and agency securities | — |  |  | 281 |  |  | — |  |  | 281 |  |  | — |  |  | 388 |  |  | — |  |  | 388 |  |
| Corporate debt securities | — |  |  | 29,238 |  |  | — |  |  | 29,238 |  |  | — |  |  | 31,735 |  |  | — |  |  | 31,735 |  |
| U.S. agency mortgage-backed securities | — |  |  | 1,936 |  |  | — |  |  | 1,936 |  |  | — |  |  | 2,023 |  |  | — |  |  | 2,023 |  |
| Commercial paper | — |  |  | 195 |  |  | — |  |  | 195 |  |  | — |  |  | 996 |  |  | — |  |  | 996 |  |
| Certificates of deposit | — |  |  | 50 |  |  | — |  |  | 50 |  |  | — |  |  | 60 |  |  | — |  |  | 60 |  |
| Publicly traded equity securities | 1,325 |  |  | — |  |  | — |  |  | 1,325 |  |  | 1,707 |  |  | — |  |  | — |  |  | 1,707 |  |
| Derivative assets | — |  |  | 13 |  |  | — |  |  | 13 |  |  | — |  |  | 149 |  |  | — |  |  | 149 |  |
| Total | $ | 6,057 |  |  | $ | 46,400 |  |  | $ | — |  |  | $ | 52,457 |  |  | $ | 11,274 |  |  | $ | 57,550 |  |  | $ | — |  |  | $ | 68,824 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities | $ | — |  |  | $ | 92 |  |  | $ | — |  |  | $ | 92 |  |  | $ | — |  |  | $ | 4 |  |  | $ | — |  |  | $ | 4 |  |
| Total | $ | — |  |  | $ | 92 |  |  | $ | — |  |  | $ | 92 |  |  | $ | — |  |  | $ | 4 |  |  | $ | — |  |  | $ | 4 |  |

[0000858877-18-000007:notes:198]
[same as prior period, unchanged from 0000858877-18-000004:notes:197]

[0000858877-18-000007:notes:199]
[same as prior period, unchanged from 0000858877-18-000004:notes:198]

[0000858877-18-000007:notes:200]
[same as prior period, unchanged from 0000858877-18-000004:notes:199]

[0000858877-18-000007:notes:201]
[same as prior period, unchanged from 0000858877-18-000004:notes:200]

[0000858877-18-000007:notes:202]
The fair value measurement of the impaired investments was classified as Level 3 because significant unobservable inputs were used in the valuation due to the absence of quoted market prices and inherent lack of liquidity. Significant unobservable inputs, which included financial metrics of comparable private and public companies, financial condition and near-term prospects of the investees, recent financing activities of the investees, and the investees’ capital structure as well as other economic variables, reflected the assumptions market participants would use in pricing these assets. The impairment charges, representing the difference between the net book value and the fair value as a result of the evaluation, were recorded to other income (loss), net. The remaining carrying value of the investments that were impaired was $56 million and $92 million as of April 28, 2018 and April 29, 2017, respectively.

[0000858877-18-000007:notes:203]
The fair value for purchased intangible assets measured at fair value on a nonrecurring basis was categorized as Level 3 due to the use of significant unobservable inputs in the valuation. Significant unobservable inputs that were used included expected revenues and net income related to the assets and the expected life of the assets. The difference between the estimated fair value and the carrying value of the assets was recorded as an impairment charge, which was included in product cost of sales and operating expenses as applicable. See Note 4. The remaining carrying value of the specific purchased intangible assets that were impaired was zero and $7 million as of April 28, 2018 and April 29, 2017, respectively.

[0000858877-18-000007:notes:204]
The fair value of property held for sale was measured with the assistance of third-party valuation models, which used discounted cash flow techniques as part of their analysis. The fair value measurement was categorized as Level 3, as significant unobservable inputs were used in the valuation report. The impairment charge as a result of the valuations, which represented the difference between the fair value less cost to sell and the carrying amount of the assets held for sale, was included in restructuring and other charges. The remaining carrying value of the property held for sale that was impaired was zero and $11 million as of April 28, 2018 and April 29, 2017, respectively.

[0000858877-18-000007:notes:205]
[same as prior period, unchanged from 0000858877-18-000004:notes:204]

[0000858877-18-000007:notes:206]
The carrying value of investments in privately held companies that were accounted for under the cost method was $851 million and $859 million as of April 28, 2018 and July 29, 2017, respectively. It was not practicable to estimate the fair value of this portfolio.

[0000858877-18-000007:notes:207]
The fair value of short-term loan receivables and financed service contracts approximates their carrying value due to their short duration. The aggregate carrying value of long-term loan receivables and financed service contracts as of April 28, 2018 and July 29, 2017 was $3.6 billion and $3.4 billion, respectively. The estimated fair value of long-term loan receivables and financed service contracts approximates their carrying value. The Company uses significant unobservable inputs in determining discounted cash flows to estimate the fair value of its long-term loan receivables and financed service contracts, and therefore they are categorized as Level 3.

[0000858877-18-000007:notes:208]
As of April 28, 2018, the estimated fair value of the short-term debt approximates its carrying value due to the short maturities. As of April 28, 2018, the fair value of the Company’s senior notes and other long-term debt was $29.0 billion with a carrying amount of $28.1 billion. This compares to a fair value of $32.1 billion and a carrying amount of $30.5 billion as of July 29, 2017. The fair value of the senior notes and other long-term debt was determined based on observable market prices in a less active market and was categorized as Level 2 in the fair value hierarchy.


## us-gaap:FinancingReceivableCreditQualityIndicatorsTableTextBlock

[0000858877-18-000007:notes:209]
Gross receivables, excluding residual value, less unearned income categorized by the Company’s internal credit risk rating as of April 28, 2018 and July 29, 2017 are summarized as follows (in millions):

[0000858877-18-000007:notes:210]
|  | INTERNAL CREDIT RISK RATING |
| April 28, 2018 | 1 to 4 |  | 5 to 6 |  | 7 and Higher |  | Total |
| Lease receivables | $ | 1,207 |  |  | $ | 1,248 |  |  | $ | 63 |  |  | $ | 2,518 |  |
| Loan receivables | 3,234 |  |  | 1,654 |  |  | 75 |  |  | 4,963 |  |
| Financed service contracts | 1,519 |  |  | 863 |  |  | 16 |  |  | 2,398 |  |
| Total | $ | 5,960 |  |  | $ | 3,765 |  |  | $ | 154 |  |  | $ | 9,879 |  |

[0000858877-18-000007:notes:211]
[same as prior period, unchanged from 0000858877-18-000004:notes:210]


## us-gaap:FinancingReceivablesTextBlock

[0000858877-18-000007:notes:212]
[same as prior period, unchanged from 0000858877-18-000004:notes:211]

[0000858877-18-000007:notes:213]
[same as prior period, unchanged from 0000858877-18-000004:notes:212]

[0000858877-18-000007:notes:214]
[same as prior period, unchanged from 0000858877-18-000004:notes:213]

[0000858877-18-000007:notes:215]
[same as prior period, unchanged from 0000858877-18-000004:notes:214]

[0000858877-18-000007:notes:216]
| April 28, 2018 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Gross | $ | 2,660 |  |  | $ | 4,963 |  |  | $ | 2,398 |  |  | $ | 10,021 |  |
| Residual value | 166 |  |  | — |  |  | — |  |  | 166 |  |
| Unearned income | (142 | ) |  | — |  |  | — |  |  | (142 | ) |
| Allowance for credit loss | (165 | ) |  | (85 | ) |  | (12 | ) |  | (262 | ) |
| Total, net | $ | 2,519 |  |  | $ | 4,878 |  |  | $ | 2,386 |  |  | $ | 9,783 |  |
| Reported as: |  |  |  |  |  |  |  |
| Current | $ | 1,223 |  |  | $ | 2,288 |  |  | $ | 1,357 |  |  | $ | 4,868 |  |
| Noncurrent | 1,296 |  |  | 2,590 |  |  | 1,029 |  |  | 4,915 |  |
| Total, net | $ | 2,519 |  |  | $ | 4,878 |  |  | $ | 2,386 |  |  | $ | 9,783 |  |

[0000858877-18-000007:notes:217]
[same as prior period, unchanged from 0000858877-18-000004:notes:216]

[0000858877-18-000007:notes:218]
Future minimum lease payments to the Company on lease receivables as of April 28, 2018 are summarized as follows (in millions):

[0000858877-18-000007:notes:219]
| Fiscal Year | Amount |
| 2018 (remaining three months) | $ | 324 |  |
| 2019 | 1,158 |  |
| 2020 | 673 |  |
| 2021 | 348 |  |
| 2022 | 134 |  |
| Thereafter | 23 |  |
| Total | $ | 2,660 |  |

[0000858877-18-000007:notes:220]
[same as prior period, unchanged from 0000858877-18-000004:notes:219]

[0000858877-18-000007:notes:221]
[same as prior period, unchanged from 0000858877-18-000004:notes:220]

[0000858877-18-000007:notes:222]
[same as prior period, unchanged from 0000858877-18-000004:notes:221]

[0000858877-18-000007:notes:223]
[same as prior period, unchanged from 0000858877-18-000004:notes:222]

[0000858877-18-000007:notes:224]
[same as prior period, unchanged from 0000858877-18-000004:notes:223]

[0000858877-18-000007:notes:225]
The following tables present the aging analysis of gross receivables, excluding residual value and less unearned income as of April 28, 2018 and July 29, 2017 (in millions):

[0000858877-18-000007:notes:226]
|  | DAYS PAST DUE (INCLUDES BILLED AND UNBILLED) |  |  |  |  |  |  |  |  |
| April 28, 2018 | 31-60 |  | 61-90 |  | 91+ |  | TotalPast Due |  | Current |  | Total |  | NonaccrualFinancingReceivables |  | ImpairedFinancingReceivables |
| Lease receivables | $ | 32 |  |  | $ | 42 |  |  | $ | 282 |  |  | $ | 356 |  |  | $ | 2,162 |  |  | $ | 2,518 |  |  | $ | 15 |  |  | $ | 15 |  |
| Loan receivables | 92 |  |  | 74 |  |  | 353 |  |  | 519 |  |  | 4,444 |  |  | 4,963 |  |  | 37 |  |  | 37 |  |
| Financed service contracts | 94 |  |  | 121 |  |  | 321 |  |  | 536 |  |  | 1,862 |  |  | 2,398 |  |  | 3 |  |  | 3 |  |
| Total | $ | 218 |  |  | $ | 237 |  |  | $ | 956 |  |  | $ | 1,411 |  |  | $ | 8,468 |  |  | $ | 9,879 |  |  | $ | 55 |  |  | $ | 55 |  |

[0000858877-18-000007:notes:227]
[same as prior period, unchanged from 0000858877-18-000004:notes:226]

[0000858877-18-000007:notes:228]
Past due financing receivables are those that are 31 days or more past due according to their contractual payment terms. The data in the preceding tables is presented by contract, and the aging classification of each contract is based on the oldest outstanding receivable, and therefore past due amounts also include unbilled and current receivables within the same contract. The balances of either unbilled or current financing receivables included in the category of 91 days plus past due for financing receivables were $618 million and $666 million as of April 28, 2018 and July 29, 2017, respectively.

[0000858877-18-000007:notes:229]
As of April 28, 2018, the Company had financing receivables of $311 million, net of unbilled or current receivables, that were in the category of 91 days plus past due but remained on accrual status as they are well secured and in the process of collection. Such balance was $315 million as of July 29, 2017.

[0000858877-18-000007:notes:230]
[same as prior period, unchanged from 0000858877-18-000004:notes:229]

[0000858877-18-000007:notes:231]
[same as prior period, unchanged from 0000858877-18-000004:notes:230]

[0000858877-18-000007:notes:232]
Typically, the Company also considers receivables with a risk rating of 8 or higher to be impaired and will include them in the individual assessment for allowance. These balances, as of April 28, 2018 and July 29, 2017, are presented under “(b) Credit Quality of Financing Receivables” above.

[0000858877-18-000007:notes:233]
[same as prior period, unchanged from 0000858877-18-000004:notes:232]

[0000858877-18-000007:notes:234]
[same as prior period, unchanged from 0000858877-18-000004:notes:233]

[0000858877-18-000007:notes:235]
[same as prior period, unchanged from 0000858877-18-000004:notes:234]

[0000858877-18-000007:notes:236]
|  | April 28, 2018 |  | July 29, 2017 |
| Operating lease assets | $ | 370 |  |  | $ | 356 |  |
| Accumulated depreciation | (242 | ) |  | (212 | ) |
| Operating lease assets, net | $ | 128 |  |  | $ | 144 |  |

[0000858877-18-000007:notes:237]
Minimum future rentals on noncancelable operating leases as of April 28, 2018 are summarized as follows (in millions):

[0000858877-18-000007:notes:238]
| Fiscal Year | Amount |
| 2018 (remaining three months) | $ | 54 |  |
| 2019 | 168 |  |
| 2020 | 85 |  |
| 2021 | 21 |  |
| Thereafter | 2 |  |
| Total | $ | 330 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000858877-18-000007:notes:239]
[same as prior period, unchanged from 0000858877-18-000004:notes:238]

[0000858877-18-000007:notes:240]
[same as prior period, unchanged from 0000858877-18-000004:notes:239]

[0000858877-18-000007:notes:241]
The following table presents the goodwill allocated to the Company’s reportable segments as of and during the nine months ended April 28, 2018 (in millions):

[0000858877-18-000007:notes:242]
|  | Balance at |  |  |  |  |  | Balance at |
|  | July 29, 2017 |  | Acquisitions |  | Other |  | April 28, 2018 |
| Americas | $ | 18,691 |  |  | $ | 1,194 |  |  | $ | 17 |  |  | $ | 19,902 |  |
| EMEA | 7,057 |  |  | 491 |  |  | 9 |  |  | 7,557 |  |
| APJC | 4,018 |  |  | 171 |  |  | 6 |  |  | 4,195 |  |
| Total | $ | 29,766 |  |  | $ | 1,856 |  |  | $ | 32 |  |  | $ | 31,654 |  |

[0000858877-18-000007:notes:243]
[same as prior period, unchanged from 0000858877-18-000004:notes:242]

[0000858877-18-000007:notes:244]
[same as prior period, unchanged from 0000858877-18-000004:notes:243]

[0000858877-18-000007:notes:245]
[same as prior period, unchanged from 0000858877-18-000004:notes:244]

[0000858877-18-000007:notes:246]
Impairment charges related to purchased intangible assets for the three and nine months ended April 28, 2018 were $1 million. Impairment charges related to purchased intangible assets for the three and nine months ended April 29, 2017 were zero and $42 million, respectively. Of these impairment charges, $38 million was recorded to restructuring and other charges in connection with the Company's decision to exit certain product lines, and the corresponding elimination of future associated cash flows. Impairment charges were primarily as a result of declines in estimated fair values of certain purchased intangible assets resulting from the reduction or elimination of expected future cash flows associated with certain of the Company’s technology and IPR&D intangible assets.

[0000858877-18-000007:notes:247]
The estimated future amortization expense of purchased intangible assets with finite lives as of April 28, 2018 is as follows (in millions):

[0000858877-18-000007:notes:248]
| Fiscal Year | Amount |
| 2018 (remaining three months) | $ | 235 |  |
| 2019 | 883 |  |
| 2020 | 665 |  |
| 2021 | 463 |  |
| 2022 | 212 |  |
| Thereafter | 119 |  |
| Total | $ | 2,577 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000858877-18-000007:notes:249]
[same as prior period, unchanged from 0000858877-18-000004:notes:248]

[0000858877-18-000007:notes:250]
[same as prior period, unchanged from 0000858877-18-000004:notes:249]

[0000858877-18-000007:notes:251]
As a result of the decrease in the federal tax rate from 35% to 21% effective January 1, 2018, the Company has computed its income tax expense for the July 28, 2018 fiscal year using a blended federal tax rate of 27%. The 21% federal tax rate will apply to the Company’s fiscal year ending July 27, 2019 and each year thereafter. The Company must remeasure its deferred tax assets and liabilities ("DTA") using the federal tax rate that will apply when the related temporary differences are expected to reverse.

[0000858877-18-000007:notes:252]
As of December 31, 2017, the Company had approximately $75 billion in undistributed earnings for certain foreign subsidiaries. These undistributed earnings were subject to the U.S. mandatory one-time transition tax and are eligible to be repatriated to the U.S. without additional U.S. tax under the Tax Act. The Company has historically asserted its intention to indefinitely reinvest foreign earnings in certain foreign subsidiaries. The Company has reevaluated its historic assertion as a result of enactment of the Tax Act and no longer considers these earnings to be indefinitely reinvested in its foreign subsidiaries. As a result of this change in assertion, the Company recorded a $1.2 billion tax expense for foreign withholding tax in the second quarter of fiscal 2018. In the third quarter of fiscal 2018, the Company repatriated $67 billion of foreign subsidiary earnings to the U.S. and paid foreign withholding tax of $1.2 billion.

[0000858877-18-000007:notes:253]
In the third quarter of fiscal 2018, the Company recorded adjustments to the provisional amounts related to the U.S. transition tax on accumulated earnings of foreign subsidiaries and re-measurement of net DTA. During the nine months ended April 28, 2018, the Company recorded a provisional tax expense of $11.1 billion related to the Tax Act, comprised of $8.9 billion of U.S. transition tax, $1.2 billion of foreign withholding tax (discussed above), and $1.0 billion re-measurement of net DTA. The Company plans to pay the transition tax in installments over eight years in accordance with the Tax Act. The $1.2 billion foreign withholding tax was paid in February 2018.

[0000858877-18-000007:notes:254]
In December 2017, the Securities and Exchange Commission staff issued Staff Accounting Bulletin No. 118, which addresses how a company recognizes provisional estimates when a company does not have the necessary information available, prepared or analyzed (including computations) in reasonable detail to complete its accounting for the effect of the changes in the Tax Act. The measurement period ends when a company has obtained, prepared, and analyzed the information necessary to finalize its accounting, but cannot extend beyond one year. The final impact of the Tax Act may differ from the above provisional estimates due to changes in interpretations of the Tax Act, any legislative action to address questions that arise because of the Tax Act, by changes in accounting standard for income taxes and related interpretations in response to the Tax Act, and any updates or changes to estimates used in the provisional amounts. The Company has determined that the $8.9 billion of tax expense for the U.S. transition tax on accumulated earnings of foreign subsidiaries, the $1.2 billion of foreign withholding tax, and the $1.0 billion of tax expense for DTA re-measurement were each provisional amounts and reasonable estimates as of April 28, 2018. Estimates used in the provisional amounts include: the anticipated reversal pattern of the gross DTAs; and earnings, cash positions, foreign taxes and withholding taxes attributable to foreign subsidiaries.

[0000858877-18-000007:notes:255]
As of April 28, 2018, the Company had $2.0 billion of unrecognized tax benefit, of which $1.7 billion, if recognized, would favorably impact the effective tax rate. The Company regularly engages in discussions and negotiations with tax authorities regarding tax matters in various jurisdictions. The Company believes it is reasonably possible that certain federal, foreign and state tax matters may be concluded in the next 12 months. Specific positions that may be resolved include issues involving transfer pricing and various other matters.  The Company estimates that the unrecognized tax benefits at April 28, 2018 could be reduced by approximately $250 million in the next 12 months.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0000858877-18-000007:notes:256]
The following table summarizes the maturities of the Company’s fixed income securities as of April 28, 2018 (in millions):

[0000858877-18-000007:notes:257]
|  | Amortized Cost |  | Fair Value |
| Less than 1 year | $ | 13,959 |  |  | $ | 13,908 |  |
| Due in 1 to 2 years | 10,521 |  |  | 10,414 |  |
| Due in 2 to 5 years | 18,552 |  |  | 18,230 |  |
| Due after 5 years | 1,972 |  |  | 1,900 |  |
| Mortgage-backed securities with no single maturity | 2,009 |  |  | 1,935 |  |
| Total | $ | 47,013 |  |  | $ | 46,387 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000858877-18-000007:notes:258]
Investments

[0000858877-18-000007:notes:259]
| (a) | Summary of Available-for-Sale Investments |

[0000858877-18-000007:notes:260]
The following tables summarize the Company’s available-for-sale investments (in millions):

[0000858877-18-000007:notes:261]
| April 28, 2018 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| Fixed income securities: |  |  |  |  |  |  |  |
| U.S. government securities | $ | 13,672 |  |  | $ | — |  |  | $ | (141 | ) |  | $ | 13,531 |  |
| U.S. government agency securities | 1,166 |  |  | — |  |  | (10 | ) |  | 1,156 |  |
| Non-U.S. government and agency securities | 282 |  |  | — |  |  | (1 | ) |  | 281 |  |
| Corporate debt securities | 29,639 |  |  | 53 |  |  | (454 | ) |  | 29,238 |  |
| U.S. agency mortgage-backed securities | 2,009 |  |  | — |  |  | (73 | ) |  | 1,936 |  |
| Commercial paper | 195 |  |  | — |  |  | — |  |  | 195 |  |
| Certificates of deposit | 50 |  |  | — |  |  | — |  |  | 50 |  |
| Total fixed income securities | 47,013 |  |  | 53 |  |  | (679 | ) |  | 46,387 |  |
| Publicly traded equity securities | 843 |  |  | 486 |  |  | (4 | ) |  | 1,325 |  |
| Total (1) | $ | 47,856 |  |  | $ | 539 |  |  | $ | (683 | ) |  | $ | 47,712 |  |

[0000858877-18-000007:notes:262]
| July 29, 2017 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| Fixed income securities: |  |  |  |  |  |  |  |
| U.S. government securities | $ | 19,880 |  |  | $ | 3 |  |  | $ | (60 | ) |  | $ | 19,823 |  |
| U.S. government agency securities | 2,057 |  |  | — |  |  | (5 | ) |  | 2,052 |  |
| Non-U.S. government and agency securities | 389 |  |  | — |  |  | (1 | ) |  | 388 |  |
| Corporate debt securities | 31,626 |  |  | 202 |  |  | (93 | ) |  | 31,735 |  |
| U.S. agency mortgage-backed securities | 2,037 |  |  | 3 |  |  | (17 | ) |  | 2,023 |  |
| Commercial paper | 996 |  |  | — |  |  | — |  |  | 996 |  |
| Certificates of deposit | 60 |  |  | — |  |  | — |  |  | 60 |  |
| Total fixed income securities | 57,045 |  |  | 208 |  |  | (176 | ) |  | 57,077 |  |
| Publicly traded equity securities | 1,180 |  |  | 554 |  |  | (27 | ) |  | 1,707 |  |
| Total (1) | $ | 58,225 |  |  | $ | 762 |  |  | $ | (203 | ) |  | $ | 58,784 |  |

[0000858877-18-000007:notes:263]
(1) Includes investments that were pending settlement as of the respective fiscal years. The net unsettled investment purchases (sales) were $(7) million and $(30) million as of April 28, 2018 and July 29, 2017, respectively.

[0000858877-18-000007:notes:264]
Non-U.S. government and agency securities include agency and corporate debt securities that are guaranteed by non-U.S. governments.

[0000858877-18-000007:notes:265]
| (b) | Gains and Losses on Available-for-Sale Investments |

[0000858877-18-000007:notes:266]
The following table presents the gross realized gains and gross realized losses related to available-for-sale investments (in millions):

[0000858877-18-000007:notes:267]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 28, 2018 |  | April 29, 2017 |  | April 28, 2018 |  | April 29, 2017 |
| Gross realized gains | $ | 101 |  |  | $ | 43 |  |  | $ | 333 |  |  | $ | 91 |  |
| Gross realized losses | (84 | ) |  | (119 | ) |  | (225 | ) |  | (182 | ) |
| Total | $ | 17 |  |  | $ | (76 | ) |  | $ | 108 |  |  | $ | (91 | ) |

[0000858877-18-000007:notes:268]
The following table presents the realized net gains (losses) related to available-for-sale investments by security type (in millions):

[0000858877-18-000007:notes:269]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 28, 2018 |  | April 29, 2017 |  | April 28, 2018 |  | April 29, 2017 |
| Net gains (losses) on investments in publicly traded equity securities | $ | 56 |  |  | $ | (59 | ) |  | $ | 239 |  |  | $ | (50 | ) |
| Net gains (losses) on investments in fixed income securities | (39 | ) |  | (17 | ) |  | (131 | ) |  | (41 | ) |
| Total | $ | 17 |  |  | $ | (76 | ) |  | $ | 108 |  |  | $ | (91 | ) |

[0000858877-18-000007:notes:270]
The following tables present the breakdown of the available-for-sale investments with gross unrealized losses and the duration that those losses had been unrealized at April 28, 2018 and July 29, 2017 (in millions):

[0000858877-18-000007:notes:271]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| April 28, 2018 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| Fixed income securities: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | $ | 7,585 |  |  | $ | (99 | ) |  | $ | 5,508 |  |  | $ | (42 | ) |  | $ | 13,093 |  |  | $ | (141 | ) |
| U.S. government agency securities | 473 |  |  | (5 | ) |  | 682 |  |  | (5 | ) |  | 1,155 |  |  | (10 | ) |
| Non-U.S. government and agency securities | 110 |  |  | — |  |  | 171 |  |  | (1 | ) |  | 281 |  |  | (1 | ) |
| Corporate debt securities | 18,094 |  |  | (348 | ) |  | 3,706 |  |  | (106 | ) |  | 21,800 |  |  | (454 | ) |
| U.S. agency mortgage-backed securities | 1,104 |  |  | (32 | ) |  | 827 |  |  | (41 | ) |  | 1,931 |  |  | (73 | ) |
| Total fixed income securities | 27,366 |  |  | (484 | ) |  | 10,894 |  |  | (195 | ) |  | 38,260 |  |  | (679 | ) |
| Publicly traded equity securities | 41 |  |  | (4 | ) |  | — |  |  | — |  |  | 41 |  |  | (4 | ) |
| Total | $ | 27,407 |  |  | $ | (488 | ) |  | $ | 10,894 |  |  | $ | (195 | ) |  | $ | 38,301 |  |  | $ | (683 | ) |

[0000858877-18-000007:notes:272]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 29, 2017 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| Fixed income securities: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | $ | 14,962 |  |  | $ | (55 | ) |  | $ | 771 |  |  | $ | (5 | ) |  | $ | 15,733 |  |  | $ | (60 | ) |
| U.S. government agency securities | 1,791 |  |  | (4 | ) |  | 130 |  |  | (1 | ) |  | 1,921 |  |  | (5 | ) |
| Non-U.S. government and agency securities | 368 |  |  | (1 | ) |  | — |  |  | — |  |  | 368 |  |  | (1 | ) |
| Corporate debt securities | 9,487 |  |  | (92 | ) |  | 101 |  |  | (1 | ) |  | 9,588 |  |  | (93 | ) |
| U.S. agency mortgage-backed securities | 1,485 |  |  | (16 | ) |  | 38 |  |  | (1 | ) |  | 1,523 |  |  | (17 | ) |
| Total fixed income securities | 28,093 |  |  | (168 | ) |  | 1,040 |  |  | (8 | ) |  | 29,133 |  |  | (176 | ) |
| Publicly traded equity securities | 122 |  |  | (27 | ) |  | — |  |  | — |  |  | 122 |  |  | (27 | ) |
| Total | $ | 28,215 |  |  | $ | (195 | ) |  | $ | 1,040 |  |  | $ | (8 | ) |  | $ | 29,255 |  |  | $ | (203 | ) |

[0000858877-18-000007:notes:273]
The net realized losses related to the Company's available-for-sale investments included impairment charges of $26 million and $52 million for the three and nine months ended April 28, 2018, respectively. For the three and nine months ended April 29, 2017, the net realized losses related to the Company's available-for-sale investments included impairment charges of $73 million. These impairment charges related primarily to publicly traded equity securities and were due to a decline in the fair value of those securities below their cost basis that were determined to be other than temporary.

[0000858877-18-000007:notes:274]
As of April 28, 2018, for fixed income securities that were in unrealized loss positions, the Company has determined that (i) it does not have the intent to sell any of these investments and (ii) it is not more likely than not that it will be required to sell any of these investments before recovery of the entire amortized cost basis. In addition, as of April 28, 2018, the Company anticipates that it will recover the entire amortized cost basis of such fixed income securities and has determined that no other-than-temporary impairments associated with credit losses were required to be recognized during the nine months ended April 28, 2018.

[0000858877-18-000007:notes:275]
The Company has evaluated its publicly traded equity securities as of April 28, 2018 and has determined that there were no additional other-than-temporary impairments in the respective categories of unrealized losses. This determination was based on several factors, which include the length of time and extent to which fair value has been less than the cost basis, the financial condition and near-term prospects of the issuer, and the Company’s intent and ability to hold the publicly traded equity securities for a period of time sufficient to allow for any anticipated recovery in market value.

[0000858877-18-000007:notes:276]
| (c) | Maturities of Fixed Income Securities |

[0000858877-18-000007:notes:277]
Actual maturities may differ from the contractual maturities because borrowers may have the right to call or prepay certain obligations.

[0000858877-18-000007:notes:278]
| (d) | Securities Lending |

[0000858877-18-000007:notes:279]
The Company periodically engages in securities lending activities with certain of its available for sale investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. The average daily balance of securities lending for the nine months ended April 28, 2018 and April 29, 2017 was $0.3 billion and $0.8 billion, respectively. The Company requires collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. The Company engages in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify the Company against collateral losses. The Company did not experience any losses in connection with the secured lending of securities during the periods presented. As of April 28, 2018 and July 29, 2017, the Company had no outstanding securities lending transactions.

[0000858877-18-000007:notes:280]
| (e) | Investments in Privately Held Companies |

[0000858877-18-000007:notes:281]
The carrying value of the investments in privately held companies was included in other assets. For such investments that were accounted for under the equity and cost method as of April 28, 2018 and July 29, 2017, the amounts are summarized in the following table (in millions):

[0000858877-18-000007:notes:282]
|  | April 28, 2018 |  | July 29, 2017 |
| Equity method investments | $ | 118 |  |  | $ | 124 |  |
| Cost method investments | 851 |  |  | 859 |  |
| Total | $ | 969 |  |  | $ | 983 |  |

[0000858877-18-000007:notes:283]
For additional information on impairment charges related to investments in privately held companies, see Note 9.

[0000858877-18-000007:notes:284]
Variable Interest Entities  In the ordinary course of business, the Company has investments in privately held companies and provides financing to certain customers. These privately held companies and customers may be considered to be variable interest entities. The Company evaluates on an ongoing basis its investments in these privately held companies and its customer financings, and has determined that as of April 28, 2018, except as disclosed in Note 1, there were no significant variable interest entities required to be consolidated in the Company’s Consolidated Financial Statements.

[0000858877-18-000007:notes:285]
As of April 28, 2018, the carrying value of investments in privately held companies was $969 million, of which $511 million of such investments are considered to be in variable interest entities which are unconsolidated. In addition, the Company has additional funding commitments of $212 million related to these investments, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The carrying value of these investments and the additional funding commitments collectively represent the Company's maximum exposure related to these variable interest entities.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000858877-18-000007:notes:286]
New Accounting Updates Recently Adopted

[0000858877-18-000007:notes:287]
Share-Based Compensation  In March 2016, the FASB issued an accounting standard update that impacts the accounting for share-based payment transactions, including income tax consequences, classification of awards as either equity or liabilities, and classification on the Consolidated Statements of Cash Flows. Cisco adopted this accounting standard update beginning the first quarter of fiscal 2018 on a prospective basis. This resulted in an overall decrease in the effective tax rate for the nine months ended April 28, 2018 due to recognition of excess tax benefits from share-based compensation. The application of this accounting standard update did not have a material impact on the Company's Consolidated Financial Statements.

[0000858877-18-000007:notes:288]
Reclassification of Certain Tax Effects from Accumulated Other Comprehensive Income  In February 2018, the FASB issued an accounting standard update that allows companies to reclassify from accumulated other comprehensive income ("AOCI") to retained earnings stranded tax effects resulting from the enactment of the Tax Cuts and Jobs Act (the "Tax Act"). The guidance is effective January 1, 2019 with early adoption permitted. Cisco early adopted this accounting standard update in the third quarter of fiscal 2018 and elected not to reclassify prior periods. Adoption of this standard resulted in a decrease of $45 million to retained earnings due to the reclassification from AOCI to retained earnings.

[0000858877-18-000007:notes:289]
| (b) | Recent Accounting Standards or Updates Not Yet Effective as of Period End |

[0000858877-18-000007:notes:290]
Revenue Recognition  In May 2014, the FASB issued a new accounting standard related to revenue recognition. The new standard will supersede nearly all U.S. GAAP on revenue recognition and eliminate industry-specific guidance. The underlying principle of the new standard is to recognize revenue when a customer obtains control of promised goods or services at an amount that reflects the consideration that is expected to be received in exchange for those goods or services. It also requires increased disclosures including the nature, amount, timing, and uncertainty of revenues and cash flows related to contracts with customers.

[0000858877-18-000007:notes:291]
The standard allows two methods of adoption: i) retrospectively to each prior period presented (“full retrospective method”), or ii) retrospectively with the cumulative effect recognized in retained earnings as of the date of adoption ("modified retrospective method"). Cisco will adopt the new standard using the modified retrospective method at the beginning of its first quarter of fiscal 2019.

[0000858877-18-000007:notes:292]
Cisco is on schedule in establishing new accounting policies, implementing systems and processes (including more extensive use of estimates), and internal controls necessary to support the requirements of the new standard. Cisco has completed its preliminary assessment of the financial statement impact of the new standard, as discussed below, and will continue to update that assessment as more information becomes available.

[0000858877-18-000007:notes:293]
The new standard will primarily impact Cisco’s revenue recognition for software arrangements and sales to two-tier distributors. In both areas, the new standard will accelerate the recognition of revenue. The table below details the timing of when revenue is typically recognized under the current revenue standard compared to the timing of when revenue will typically be recognized under the New Revenue Standard for these major areas:

[0000858877-18-000007:notes:294]
|  |  | Current Revenue Standard |  | New Revenue Standard |
| Software arrangements: |  |  |  |  |
| Perpetual software licenses |  | Upfront |  | Upfront |
| Term software licenses |  | Ratable |  | Upfront |
| Security software licenses |  | Ratable |  | Ratable |
| Enterprise license agreements |  | Ratable |  | Upfront |
| Software support services |  | Ratable |  | Ratable |
| Software-as-a-service |  | Ratable |  | Ratable |
| Two-tier distribution |  | Sell-Through |  | Sell-In |

[0000858877-18-000007:notes:295]
Cisco expects that the new standard will not have a material impact on total revenue in the year of adoption based on two factors: i) revenue will be accelerated consistent with the changes in timing as indicated in the preceding table, largely offset by ii) the reduction of revenue from software arrangements where revenue was previously deferred in prior periods and recognized ratably over time as required under the current standard. This preliminary assessment is based on the types and number of revenue arrangements currently in place. The exact impact of the new standard will be dependent on facts and circumstances at adoption and could vary from quarter to quarter.

[0000858877-18-000007:notes:296]
In addition to the above revenue recognition timing impacts, the new standard will require incremental contract acquisition costs (such as sales commissions) for customer contracts to be capitalized and amortized over the contract period. Currently, these costs are expensed as incurred.

[0000858877-18-000007:notes:297]
Cisco will be required to record cumulative effect adjustments to retained earnings (net of tax) upon adopting the new standard at the beginning of fiscal 2019. The most significant of these adjustments will be to reduce product deferred revenue and increase retained earnings at the date of adoption to reflect revenue that would have been already recognized under the new standard related to existing arrangements. There will also be an adjustment to increase accounts receivable and reduce inventories related to the changes in revenue recognition on sales to two-tier distributors. Lastly, an adjustment will be recorded to establish an asset and increase retained earnings related to the requirement to capitalize incremental contract acquisition costs for customer contracts.

[0000858877-18-000007:notes:298]
Financial Instruments  In January 2016, the FASB issued an accounting standard update that changes the accounting for equity investments, financial liabilities under the fair value option, and the presentation and disclosure requirements for financial instruments. The accounting standard update will be effective for Cisco beginning in the first quarter of fiscal 2019, and early adoption is permitted. The most significant impact of this accounting standard update for Cisco is that it will require the remeasurement of investments that are not accounted for under the equity method at fair value at the end of each reporting period with the changes recorded to the income statement. While Cisco is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements, Cisco expects that this accounting standard update will increase the variability of other income (loss), net.

[0000858877-18-000007:notes:299]
Leases  In February 2016, the FASB issued an accounting standard update and subsequent amendments related to leases requiring lessees to recognize operating and financing lease liabilities on the balance sheet, as well as corresponding right-of-use assets. The new lease standard also makes some changes to lessor accounting and aligns key aspects of the lessor accounting model with the revenue recognition standard. In addition, disclosures will be required to enable users of financial statements to assess the amount, timing, and uncertainty of cash flows arising from leases. The accounting standard update will be effective for Cisco beginning in the first quarter of fiscal 2020 on a modified retrospective basis, and early adoption is permitted. Cisco is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.

[0000858877-18-000007:notes:300]
Credit Losses of Financial Instruments  In June 2016, the FASB issued an accounting standard update that requires measurement and recognition of expected credit losses for financial assets held based on historical experience, current conditions, and reasonable and supportable forecasts that affect the collectibility of the reported amount. The accounting standard update will be effective for Cisco beginning in the first quarter of fiscal 2021 on a modified retrospective basis, and early adoption in fiscal 2020 is permitted. Cisco is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.

[0000858877-18-000007:notes:301]
Classification of Cash Flow Elements  In August 2016, the FASB issued an accounting standard update related to the classification of certain cash receipts and cash payments on the statement of cash flows. The accounting standard update will be effective for Cisco beginning in the first quarter of fiscal 2019 on a retrospective basis, and early adoption is permitted. Cisco is currently evaluating the impact of this accounting standard update on its Consolidated Statements of Cash Flows.

[0000858877-18-000007:notes:302]
Income Taxes on Intra-Entity Transfers of Assets  In October 2016, the FASB issued an accounting standard update that requires recognition of the income tax consequences of intra-entity transfers of assets (other than inventory) at the transaction date. The accounting standard update will be effective for Cisco beginning in the first quarter of fiscal 2019 on a modified retrospective basis, and early adoption is permitted. Cisco currently estimates a net increase of approximately $1.3 billion to net deferred tax assets and retained earnings upon adoption of the standard related to the unrecognized income tax effects of asset transfers that occurred prior to the adoption date. The ongoing impact of this standard will be facts and circumstances dependent on any transactions within its scope.

[0000858877-18-000007:notes:303]
Restricted Cash in Statement of Cash Flow  In November 2016, the FASB issued an accounting standard update that provides guidance on the classification and presentation of changes in restricted cash and cash equivalents in the statement of cash flows. The accounting standard update will be effective for Cisco beginning in the first quarter of fiscal 2019 using a retrospective transition method to each period presented, and early adoption is permitted. Cisco does not expect that this accounting standard update will have a material impact on its Consolidated Statements of Cash Flows.

[0000858877-18-000007:notes:304]
Definition of a Business  In January 2017, the FASB issued an accounting standard update that clarifies the definition of a business to help companies evaluate whether acquisition or disposal transactions should be accounted for as asset groups or as businesses. The accounting standard update will be effective for Cisco beginning in the first quarter of fiscal 2019 on a prospective basis. The impact of this accounting standard update will be fact dependent, but Cisco expects that some transactions that were previously accounted for as business combinations or disposal transactions will be accounted for as asset purchases or asset sales under the accounting standard update.

[0000858877-18-000007:notes:305]
Simplifying the Test for Goodwill Impairment  In January 2017, the FASB issued an accounting standard update that removes Step 2 of the goodwill impairment test, which requires the assessment of fair value of individual assets and liabilities of a reporting unit to measure goodwill impairments. Goodwill impairment will now be the amount by which a reporting unit's carrying value exceeds its fair value. The accounting standard update will be effective for Cisco beginning in the first quarter of fiscal 2021 on a prospective basis, and early adoption is permitted. Cisco does not expect that this accounting standard update will impact its Consolidated Financial Statements.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000858877-18-000007:notes:306]
[same as prior period, unchanged from 0000858877-18-000004:notes:305]

[0000858877-18-000007:notes:307]
[same as prior period, unchanged from 0000858877-18-000004:notes:306]

[0000858877-18-000007:notes:308]
Certain reclassifications have been made to the amounts in prior periods in order to conform to the current period’s presentation.  The Company has evaluated subsequent events through the date that the financial statements were issued.


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0000858877-18-000007:notes:309]
| Property and equipment, net: |  |  |  |  |
| Gross property and equipment: |  |  |  |  |
| Land, buildings, and building and leasehold improvements |  | $ | 4,768 |  |  | $ | 4,926 |  |
| Computer equipment and related software |  | 1,111 |  |  | 1,258 |  |
| Production, engineering, and other equipment |  | 5,709 |  |  | 5,707 |  |
| Operating lease assets |  | 370 |  |  | 356 |  |
| Furniture and fixtures |  | 368 |  |  | 572 |  |
| Total gross property and equipment |  | 12,326 |  |  | 12,819 |  |
| Less: accumulated depreciation and amortization |  | (9,244 | ) |  | (9,497 | ) |
| Total |  | $ | 3,082 |  |  | $ | 3,322 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000858877-18-000007:notes:310]
[same as prior period, unchanged from 0000858877-18-000004:notes:309]

[0000858877-18-000007:notes:311]
Fiscal 2018 Plan    The Company initiated a restructuring plan in the third quarter of fiscal 2018 (the "Fiscal 2018 Plan") in order to realign the organization and enable further investment in key priority areas. The total pretax charges are estimated to be approximately $300 million. In connection with the Fiscal 2018 Plan, the Company incurred charges of $82 million for the three and nine months ended April 28, 2018. These aggregate pretax charges are primarily cash based and consist of employee severance and other one-time termination benefits, and other associated costs. The Company expects the Fiscal 2018 Plan to be substantially completed in fiscal 2019.

[0000858877-18-000007:notes:312]
Fiscal 2017 Plan    The Company began taking action under a restructuring plan in August 2016 (the "Fiscal 2017 Plan"), in order to reinvest in its key priority areas. In the first quarter of fiscal 2018, the Company extended the Fiscal 2017 Plan to include an additional $150 million of estimated additional pretax charges for employee severance and other one-time termination benefits. The Company incurred cumulative charges of approximately $1.0 billion, which were primarily cash based and consisted of employee severance and other one-time termination benefits, and other associated costs. The Company completed the Fiscal 2017 Plan in the third quarter of fiscal 2018.

[0000858877-18-000007:notes:313]
[same as prior period, unchanged from 0000858877-18-000004:notes:311]

[0000858877-18-000007:notes:314]
|  |  | FISCAL 2017 PLAN |  | FISCAL 2018 PLAN |  |  |
|  |  | EmployeeSeverance |  | Other |  | EmployeeSeverance |  | Other |  | Total |
| Liability as of July 29, 2017 |  | $ | 74 |  |  | $ | 43 |  |  | $ | — |  |  | $ | — |  |  | $ | 117 |  |
| Charges |  | 223 |  |  | 27 |  |  | 75 |  |  | 7 |  |  | 332 |  |
| Cash payments |  | (245 | ) |  | (30 | ) |  | (49 | ) |  | (1 | ) |  | (325 | ) |
| Non-cash items |  | 4 |  |  | (18 | ) |  | — |  |  | (6 | ) |  | (20 | ) |
| Liability as of April 28, 2018 |  | $ | 56 |  |  | $ | 22 |  |  | $ | 26 |  |  | $ | — |  |  | $ | 104 |  |

[0000858877-18-000007:notes:315]
|  |  | FISCAL 2017 AND PRIOR PLANS |  |  |
|  |  | EmployeeSeverance |  | Other |  | Total |
| Liability as of July 30, 2016 |  | $ | 21 |  |  | $ | 24 |  |  | $ | 45 |  |
| Charges |  | 510 |  |  | 104 |  |  | 614 |  |
| Cash payments |  | (463 | ) |  | (26 | ) |  | (489 | ) |
| Non-cash items |  | (7 | ) |  | (57 | ) |  | (64 | ) |
| Liability as of April 29, 2017 |  | $ | 61 |  |  | $ | 45 |  |  | $ | 106 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0000858877-18-000007:notes:316]
[same as prior period, unchanged from 0000858877-18-000004:notes:314]

[0000858877-18-000007:notes:317]
|  |  | April 28, 2018 |  | July 29, 2017 |
| Inventories: |  |  |  |  |
| Raw materials |  | $ | 459 |  |  | $ | 289 |  |
| Work in Process |  | — |  |  | 1 |  |
| Finished goods: |  |  |  |  |
| Distributor inventory and deferred cost of sales |  | 476 |  |  | 451 |  |
| Manufactured finished goods |  | 659 |  |  | 552 |  |
| Total finished goods |  | 1,135 |  |  | 1,003 |  |
| Service-related spares |  | 273 |  |  | 300 |  |
| Demonstration systems |  | 33 |  |  | 23 |  |
| Total |  | $ | 1,900 |  |  | $ | 1,616 |  |

[0000858877-18-000007:notes:318]
For such investments that were accounted for under the equity and cost method as of April 28, 2018 and July 29, 2017, the amounts are summarized in the following table (in millions):


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000858877-18-000007:notes:319]
[same as prior period, unchanged from 0000858877-18-000004:notes:317]

[0000858877-18-000007:notes:320]
| (a) | New Accounting Updates Recently Adopted |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000858877-18-000007:notes:321]
[same as prior period, unchanged from 0000858877-18-000004:notes:318]

[0000858877-18-000007:notes:322]
[same as prior period, unchanged from 0000858877-18-000004:notes:319]

[0000858877-18-000007:notes:323]
During the nine months ended April 28, 2018, the Company declared and paid cash dividends of $0.91 per common share, or $4.4 billion, on the Company’s outstanding common stock. During the nine months ended April 29, 2017, the Company declared and paid cash dividends of $0.81 per common share, or $4.1 billion, on the Company’s outstanding common stock.

[0000858877-18-000007:notes:324]
Any future dividends will be subject to the approval of the Company's Board of Directors.

[0000858877-18-000007:notes:325]
[same as prior period, unchanged from 0000858877-18-000004:notes:322]

[0000858877-18-000007:notes:326]
In September 2001, the Company’s Board of Directors authorized a stock repurchase program. On February 14, 2018, the Company’s Board of Directors authorized a $25 billion increase to the stock repurchase program. As of April 28, 2018, the remaining authorized amount for stock repurchases under this program, including the additional authorization, is approximately $25.1 billion, with no termination date. A summary of the stock repurchase activity for fiscal year 2018 and 2017 under the stock repurchase program, reported based on the trade date, is summarized as follows (in millions, except per-share amounts):

[0000858877-18-000007:notes:327]
There were $150 million stock repurchases pending settlement as of April 28, 2018. There were $66 million of stock repurchases that were pending settlement as of July 29, 2017.

[0000858877-18-000007:notes:328]
[same as prior period, unchanged from 0000858877-18-000004:notes:325]

[0000858877-18-000007:notes:329]
[same as prior period, unchanged from 0000858877-18-000004:notes:326]

[0000858877-18-000007:notes:330]
The Company repurchased approximately 16 million shares for each of the nine months ended April 28, 2018 and April 29, 2017, or $541 million and $497 million of common stock, respectively, in settlement of employee tax withholding obligations due upon the vesting of restricted stock or stock units.

[0000858877-18-000007:notes:331]
[same as prior period, unchanged from 0000858877-18-000004:notes:328]

[0000858877-18-000007:notes:332]
[same as prior period, unchanged from 0000858877-18-000004:notes:329]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000858877-18-000007:notes:333]
[same as prior period, unchanged from 0000858877-18-000004:notes:330]
