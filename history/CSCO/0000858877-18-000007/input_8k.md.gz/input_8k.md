# CSCO 8-K — 0001193125-18-165248 filed 2018-05-16

## item codes, every 8-K on or before 2018-05-22

- 2018-05-16 0001193125-18-165248 — 2.02, 9.01
- 2018-05-01 0001193125-18-146602 — 5.02
- 2018-04-12 0001193125-18-115646 — 5.02
- 2018-02-14 0001193125-18-045716 — 2.02, 9.01
- 2017-12-14 0001193125-17-368869 — 5.02
- 2017-12-12 0001193125-17-367515 — 5.02, 5.07, 9.01
- 2017-11-15 0001193125-17-344129 — 2.02, 9.01
- 2017-10-23 0001193125-17-316071 — 8.01, 9.01
- 2017-09-18 0001193125-17-286857 — 5.02, 9.01
- 2017-09-01 0001193125-17-275671 — 8.01
- 2017-08-16 0001193125-17-259825 — 2.02
- 2017-06-23 0001193125-17-211825 — 8.01
- 2017-06-15 0001193125-17-204753 — 8.01
- 2017-05-17 0001193125-17-173404 — 2.02
- 2017-03-31 0001193125-17-106620 — 1.01, 2.03, 9.01
- 2017-03-29 0001193125-17-101783 — 8.01
- 2017-03-13 0001193125-17-080485 — 5.02
- 2017-02-15 0001193125-17-045265 — 2.02
- 2016-12-22 0001193125-16-802182 — 8.01
- 2016-12-13 0001193125-16-791877 — 5.07
- 2016-11-16 0001193125-16-769785 — 2.02
- 2016-11-03 0001193125-16-758911 — 5.02, 9.01
- 2016-10-17 0001193125-16-739833 — 5.02
- 2016-09-21 0001193125-16-716006 — 8.01
- 2016-09-20 0001193125-16-714189 — 8.01, 9.01
- 2016-09-16 0001193125-16-712320 — 8.01
- 2016-09-15 0001193125-16-711098 — 1.01, 9.01
- 2016-09-13 0001193125-16-708007 — 8.01, 9.01
- 2016-09-06 0001193125-16-702020 — 8.01
- 2016-08-17 0001193125-16-684126 — 2.02, 2.05
- 2016-07-29 0001193125-16-664620 — 5.03, 9.01
- 2016-06-27 0001193125-16-633145 — 8.01
- 2016-06-23 0001193125-16-630146 — 8.01
- 2016-06-07 0001193125-16-615321 — 5.02, 9.01
- 2016-05-18 0001193125-16-594463 — 2.02
- 2016-03-24 0001193125-16-516953 — 8.01
- 2016-02-29 0001193125-16-483780 — 8.01, 9.01
- 2016-02-25 0001193125-16-478442 — 8.01
- 2016-02-24 0001193125-16-474071 — 1.01, 9.01
- 2016-02-22 0001193125-16-470856 — 8.01, 9.01
- 2016-02-10 0001193125-16-457586 — 2.02
- 2016-01-28 0001193125-16-441933 — 5.02
- 2015-12-08 0001193125-15-397797 — 8.01
- 2015-11-20 0001193125-15-383743 — 5.07
- 2015-11-12 0001193125-15-375655 — 2.02
- 2015-09-21 0001193125-15-324465 — 8.01
- 2015-09-17 0001193125-15-322456 — 8.01
- 2015-09-14 0001193125-15-319489 — 8.01
- 2015-08-28 0001193125-15-306843 — 8.01
- 2015-08-12 0001193125-15-288099 — 2.02
- 2015-07-29 0001193125-15-268359 — 5.02 — amendment of 0001193125-15-169227
- 2015-06-18 0001193125-15-227387 — 8.01, 9.01
- 2015-06-12 0001193125-15-221863 — 1.01, 9.01
- 2015-06-10 0001193125-15-218734 — 8.01, 9.01
- 2015-06-01 0001193125-15-209142 — 5.02, 9.01
- 2015-05-13 0001193125-15-185905 — 2.02
- 2015-05-04 0001193125-15-169227 — 5.02
- 2015-03-24 0001193125-15-103369 — 8.01
- 2015-03-19 0001193125-15-098638 — 8.01
- 2015-02-11 0001193125-15-044175 — 2.02
- 2014-12-19 0001193125-14-448754 — 8.01
- 2014-12-18 0001193125-14-447039 — 8.01
- 2014-11-24 0001193125-14-423591 — 5.02, 5.07, 9.01
- 2014-11-14 0001193125-14-413384 — 5.02
- 2014-11-12 0001193125-14-409258 — 2.02
- 2014-09-25 0001193125-14-353210 — 8.01
- 2014-09-12 0001193125-14-340480 — 5.02
- 2014-08-14 0001193125-14-308733 — 2.05
- 2014-08-13 0001193125-14-308403 — 2.02
- 2014-07-31 0001193125-14-289683 — 5.02
- 2014-06-25 0001193125-14-249157 — 8.01
- 2014-05-14 0001193125-14-199056 — 2.02
- 2014-03-26 0001193125-14-116588 — 8.01
- 2014-03-11 0001193125-14-093805 — 8.01
- 2014-03-03 0001193125-14-079163 — 1.01, 8.01, 9.01
- 2014-02-26 0001193125-14-069912 — 1.01, 9.01
- 2014-02-12 0001193125-14-048150 — 2.02
- 2013-12-23 0001193125-13-483099 — 8.01
- 2013-12-04 0001193125-13-462216 — 8.01
- 2013-11-20 0001193125-13-448477 — 5.02, 5.07, 9.01
- 2013-11-13 0001193125-13-440194 — 2.02
- 2013-08-15 0001193125-13-335218 — 2.05
- 2013-08-14 0001193125-13-334648 — 2.02
- 2013-07-23 0001193125-13-298129 — 8.01, 9.01
- 2013-06-24 0001193125-13-269064 — 8.01
- 2013-06-12 0001193125-13-256194 — 8.01
- 2013-06-07 0001193125-13-250920 — 8.01
- 2013-05-15 0001193125-13-222377 — 2.02
- 2013-03-26 0001193125-13-127015 — 8.01
- 2013-02-13 0001193125-13-055377 — 2.02
- 2013-02-01 0001193125-13-034682 — 5.02
- 2013-01-08 0001193125-13-006886 — 5.02, 9.01
- 2012-12-21 0001193125-12-513130 — 8.01
- 2012-12-19 0001193125-12-508424 — 8.01
- 2012-11-16 0001193125-12-474089 — 5.02, 5.07, 9.01
- 2012-11-13 0001193125-12-467422 — 2.02
- 2012-10-04 0001193125-12-415386 — 5.02, 5.03, 9.01
- 2012-09-19 0001193125-12-396875 — 5.02, 8.01
- 2012-08-15 0001193125-12-357479 — 2.02
- 2012-08-02 0001193125-12-332045 — 5.02
- 2012-06-27 0001193125-12-285742 — 8.01
- 2012-06-13 0001193125-12-269642 — 8.01
- 2012-05-09 0001193125-12-222045 — 2.02
- 2012-03-27 0001193125-12-134384 — 8.01
- 2012-03-15 0001193125-12-117538 — 8.01, 9.01
- 2012-02-17 0001193125-12-067542 — 1.01, 1.02, 2.03, 9.01
- 2012-02-08 0001193125-12-046545 — 2.02
- 2011-12-16 0001193125-11-343995 — 8.01
- 2011-12-08 0001193125-11-335127 — 5.02, 5.07, 9.01
- 2011-11-09 0001193125-11-304587 — 2.02
- 2011-09-29 0001193125-11-260065 — 8.01
- 2011-09-20 0001193125-11-252379 — 5.02, 9.01
- 2011-08-24 0001193125-11-231015 — 8.01
- 2011-08-10 0001193125-11-218133 — 2.02
- 2011-07-18 0001193125-11-190246 — 2.05
- 2011-06-22 0001193125-11-170849 — 8.01
- 2011-05-11 0001193125-11-135913 — 2.02
- 2011-03-28 0001193125-11-079927 — 8.01
- 2011-03-22 0001193125-11-073802 — 5.02 — amendment of 0001193125-11-043592
- 2011-03-18 0001193125-11-071279 — 8.01, 9.01
- 2011-03-16 0001193125-11-067985 — 1.01, 5.02, 8.01, 9.01
- 2011-03-15 0001193125-11-067331 — 1.01, 9.01
- 2011-03-09 0001193125-11-060123 — 8.01, 9.01
- 2011-02-23 0001193125-11-043592 — 5.02
- 2011-02-09 0001193125-11-028987 — 2.02
- 2011-01-31 0001193125-11-019101 — 1.01, 2.03
- 2010-12-17 0001193125-10-283392 — 8.01
- 2010-11-19 0001193125-10-265377 — 5.07
- 2010-11-10 0001193125-10-256001 — 2.02
- 2010-09-22 0001193125-10-214707 — 8.01
- 2010-09-16 0001193125-10-211456 — 7.01
- 2010-08-11 0001193125-10-186042 — 2.02
- 2010-06-29 0001193125-10-149956 — 8.01
- 2010-05-12 0001193125-10-117509 — 2.02
- 2010-02-17 0001193125-10-033290 — 5.02, 8.01, 9.01
- 2010-02-03 0001193125-10-020775 — 2.02
- 2009-11-25 0001193125-09-242589 — 8.01
- 2009-11-17 0001193125-09-236335 — 1.01, 8.01, 9.01
- 2009-11-13 0001193125-09-234405 — 1.01, 2.03, 9.01
- 2009-11-13 0001193125-09-234397 — 5.02 — amendment of 0001193125-09-189511
- 2009-11-12 0001193125-09-232971 — 5.02, 7.01, 9.01
- 2009-11-09 0001193125-09-228541 — 8.01, 9.01
- 2009-11-04 0001193125-09-223763 — 2.02
- 2009-10-14 0001193125-09-207912 — 8.01, 9.01
- 2009-10-05 0001193125-09-203556 — 8.01
- 2009-09-10 0001193125-09-189511 — 5.02
- 2009-09-04 0001193125-09-187835 — 5.02
- 2009-08-05 0001193125-09-165404 — 2.02
- 2009-07-27 0001193125-09-155861 — 5.02
- 2009-05-29 0001193125-09-121672 — 8.01
- 2009-05-06 0001193125-09-101570 — 2.02
- 2009-02-26 0001193125-09-038162 — 5.02
- 2009-02-17 0001193125-09-030546 — 1.01, 8.01, 9.01
- 2009-02-13 0001193125-09-029295 — 1.01, 2.03, 9.01
- 2009-02-04 0001193125-09-018793 — 2.02
- 2008-11-05 0001193125-08-225857 — 2.02
- 2008-09-11 0001193125-08-194695 — 7.01
- 2008-08-05 0001193125-08-166496 — 2.02
- 2008-06-20 0001193125-08-137504 — 8.01
- 2008-05-06 0001193125-08-104089 — 2.02
- 2008-03-21 0001193125-08-062838 — 8.01
- 2008-02-06 0001193125-08-021681 — 2.02
- 2008-01-23 0001193125-08-010589 — 5.02
- 2008-01-04 0001193125-08-001680 — 5.02, 9.01
- 2007-12-21 0001193125-07-269613 — 5.02
- 2007-11-19 0001193125-07-250345 — 5.02 — amendment of 0001193125-07-009285
- 2007-11-19 0001193125-07-250343 — 5.02, 9.01
- 2007-11-07 0001193125-07-238464 — 2.02
- 2007-09-24 0001193125-07-206279 — 8.01
- 2007-09-20 0001193125-07-204616 — 5.02, 7.01
- 2007-09-07 0001193125-07-197514 — 8.01
- 2007-08-17 0001193125-07-185320 — 1.01, 2.03, 9.01
- 2007-08-08 0001193125-07-174077 — 5.02
- 2007-08-07 0001193125-07-173689 — 2.02
- 2007-08-01 0001193125-07-168143 — 5.02
- 2007-05-15 0001193125-07-115800 — 8.01
- 2007-05-08 0001193125-07-106059 — 2.02
- 2007-03-23 0001193125-07-063033 — 5.02, 5.03, 8.01, 9.01
- 2007-03-21 0001193125-07-060631 — 1.01, 9.01
- 2007-02-06 0001193125-07-021349 — 2.02
- 2007-01-19 0001193125-07-009285 — 5.02
- 2006-12-22 0001193125-06-259241 — 8.01
- 2006-11-16 0001193125-06-237260 — 5.03, 8.01, 9.01
- 2006-11-08 0001193125-06-228341 — 2.02
- 2006-09-21 0001193125-06-194890 — 1.01, 7.01
- 2006-09-20 0001193125-06-194063 — 1.01
- 2006-09-15 0001193125-06-191845 — 5.02
- 2006-08-18 0001193125-06-176193 — 5.02
- 2006-08-08 0001193125-06-165719 — 2.02
- 2006-07-31 0001193125-06-157106 — 1.01, 9.01
- 2006-07-31 0001193125-06-157102 — 5.02 — amendment of 0001193125-06-017426
- 2006-06-08 0001193125-06-126879 — 5.02
- 2006-05-18 0001193125-06-115516 — 8.01
- 2006-05-12 0001193125-06-110924 — 9.01 — amendment of 0001193125-06-044013
- 2006-05-09 0001193125-06-105419 — 2.02
- 2006-03-29 0001193125-06-066990 — 1.01
- 2006-03-02 0001193125-06-044013 — 1.01, 2.01, 9.01
- 2006-02-28 0001193125-06-041452 — 1.01
- 2006-02-22 0001193125-06-036759 — 8.01
- 2006-02-22 0001193125-06-036433 — 1.01, 8.01, 9.01
- 2006-02-21 0001193125-06-035865 — 1.01, 2.03, 9.01
- 2006-02-10 0001193125-06-026218 — 8.01, 9.01
- 2006-02-07 0001193125-06-022234 — 2.02
- 2006-02-01 0001193125-06-017426 — 5.02
- 2005-11-18 0001193125-05-229535 — 1.01, 9.01
- 2005-11-16 0001193125-05-227987 — 1.01, 9.01
- 2005-11-16 0001193125-05-227983 — 5.02 — amendment of 0001193125-05-008843
- 2005-11-09 0001193125-05-221610 — 2.02
- 2005-09-29 0001193125-05-194217 — 7.01
- 2005-09-27 0001193125-05-192353 — 8.01
- 2005-09-21 0001193125-05-189234 — 1.01, 9.01
- 2005-09-19 0001193125-05-187646 — 8.01
- 2005-09-09 0001193125-05-183273 — 8.01
- 2005-09-08 0001193125-05-182307 — 1.01
- 2005-08-09 0001193125-05-162626 — 2.02
- 2005-07-15 0001193125-05-142738 — 8.01
- 2005-05-10 0001193125-05-102797 — 2.02
- 2005-03-30 0001193125-05-065123 — 1.01, 3.03, 9.01
- 2005-03-04 0001193125-05-042778 — 1.01
- 2005-02-08 0001193125-05-022181 — 2.02
- 2005-01-20 0001193125-05-008843 — 5.02
- 2004-12-23 0001193125-04-219331 — 8.01
- 2004-11-09 0001193125-04-191303 — 2.02
- 2004-08-23 0001193125-04-145198 — 1.01, 7.01
- 2004-08-19 0001193125-04-143859 — 5
- 2004-08-10 0001193125-04-136865 — 12
- 2004-05-11 0001193125-04-084721 — 12
- 2004-02-03 0001193125-04-013750 — 12
- 2003-11-05 0001193125-03-073418 — 12
- 2003-09-02 0001193125-03-044521 — 9
- 2003-08-05 0001193125-03-029223 — 12, 7
- 2003-07-18 0001193125-03-021155 — 5, 7
- 2003-06-05 0001012870-03-002949 — 5
- 2003-05-06 0000891618-03-002315 — 7, 9
- 2003-04-17 0000891618-03-001894 — 5, 7
- 2003-04-11 0000891618-03-001791 — 9
- 2003-03-20 0000891618-03-001326 — 5, 7
- 2003-02-04 0000891618-03-000518 — 7, 9
- 2003-01-28 0000891618-03-000271 — 5, 7
- 2002-12-27 0000891618-02-005686 — 5, 7
- 2002-10-23 0000891618-02-004715 — 5, 7
- 2002-10-11 0000891618-02-004620 — 5, 7
- 2002-09-18 0000891618-02-004352 — 5, 7
- 2002-08-20 0000891618-02-004001 — 5, 7
- 2002-08-05 0000891618-02-003498 — 5, 7
- 2002-07-03 0000891618-02-003099 — 5, 7
- 2002-05-14 0000891618-02-002407 — 5, 7
- 2002-02-05 0000891618-02-000412 — 5, 7
- 2001-09-28 0001095811-01-505261 — 5, 7
- 2001-09-14 0001095811-01-504917 — 5, 7
- 2001-08-24 0001095811-01-504581 — 5, 7
- 2001-07-30 0001095811-01-503468 — 5, 7
- 2001-07-12 0000891618-01-501567 — 5, 7
- 2001-05-11 0000891618-01-500638 — 5, 7
- 2001-02-27 0000891618-01-500076 — 5, 7
- 2001-02-20 0001095811-01-001530 — 5, 7
- 2001-02-08 0001095811-01-000848 — 5, 7
- 2001-02-07 0001095811-01-000768 — 5
- 2000-12-27 0001095811-00-005511 — 5
- 2000-12-21 0001095811-00-005427 — 5
- 2000-12-19 0001095811-00-005368 — 5
- 2000-11-15 0001095811-00-004830 — 5
- 2000-11-15 0001095811-00-004824 — 5
- 2000-11-13 0000891618-00-005023 — 5
- 2000-11-07 0001095811-00-004387 — 5, 7
- 2000-11-06 0001095811-00-004318 — 5
- 2000-09-29 0000891618-00-004739 — 5, 7
- 2000-09-28 0000891618-00-004722 — 5
- 2000-09-26 0001095811-00-003573 — 5
- 2000-09-15 0001095811-00-003413 — 5
- 2000-09-07 0001095811-00-003229 — 5
- 2000-08-15 0000891618-00-004430 — 5
- 2000-08-04 0001095811-00-002304 — 5, 7 — amendment, the index does not say of what
- 2000-07-28 0000891618-00-004132 — 5, 7
- 2000-06-29 0000891618-00-003637 — 5
- 2000-06-07 0000891618-00-003209 — 5
- 2000-05-26 0000891618-00-003054 — 5
- 2000-05-18 0000891618-00-002975 — 5, 7
- 2000-05-15 0000891618-00-002808 — 5, 7
- 2000-05-03 0000891618-00-002473 — 5
- 2000-04-03 0000891618-00-001936 — 5
- 2000-03-28 0000891618-00-001763 — 5
- 2000-03-27 0000891618-00-001722 — 5, 7
- 2000-03-16 0000891618-00-001512 — 5
- 2000-02-17 0000891618-00-001024 — 5, 7
- 2000-02-03 0000891618-00-000468 — 7 — amendment of 0000891618-99-005685
- 1999-12-22 0000891618-99-005792 — 5, 7
- 1999-12-15 0000891618-99-005685 — 5, 7
- 1999-11-17 0000891618-99-005313 — 5, 7
- 1999-11-04 0000891618-99-004862 — 5, 7
- 1999-10-20 0000891618-99-004625 — 5, 7
- 1999-09-27 0000891618-99-004333 — 5, 7
- 1999-08-26 0000891618-99-003978 — 5, 7
- 1999-08-13 0000891618-99-003764 — 5, 7 — amendment of 0000891618-99-003749
- 1999-08-13 0000891618-99-003749 — 5, 7
- 1999-07-02 0000891618-99-002980 — 5, 7
- 1999-05-14 0000891618-99-002221 — 5
- 1998-11-20 0000891618-98-005074 — 5, 7
- 1998-11-20 0000891618-98-005073 — 5, 7
- 1998-10-13 0000891618-98-004462 — 5, 7
- 1998-07-09 0000891618-98-003245 — 5, 7
- 1998-06-11 0000891618-98-002832 — 5, 7
- 1998-05-15 0000891618-98-002457 — 5, 7
- 1998-04-29 0000891618-98-001996 — 5
- 1998-02-11 0000891618-98-000584 — 5, 7
- 1997-09-09 0000891618-97-003723 — 5, 7
- 1997-08-22 0000891618-97-003559 — 5, 7
- 1997-07-01 0000891618-97-002807 — 5, 7
- 1997-01-22 0000891618-97-000120 — 5, 7
- 1996-10-15 0000891618-96-002283 — 5, 7 — amendment of 0000891618-96-002217
- 1996-10-01 0000891618-96-002217 — 5, 7
- 1996-07-23 0000891618-96-001305 — 2, 7
- 1996-04-26 0000891618-96-000253 — 2
- 1996-04-02 0000898430-96-001187 — 2, 7
- 1995-12-06 0000891618-95-000728 — 2, 7
- 1995-12-06 0000891618-95-000727 — 2, 7

## late-filing notifications on or before 2018-05-22

- none on or before 2018-05-22

## item 2.02 — earnings release, exhibit 99.1

[0001193125-18-165248:8k_2_02:1]
EX-99.1
2
d566498dex991.htm
EX-99.1

[0001193125-18-165248:8k_2_02:2]
EX-99.1

[0001193125-18-165248:8k_2_02:3]
Exhibit 99.1

[0001193125-18-165248:8k_2_02:4]
| Press Contact: |  |  |  | Investor Relations Contact: |
| Robyn Blum |  |  |  | Marilyn Mora |
| Cisco |  |  |  | Cisco |
| 1 (408) 853-9848 |  |  |  | 1 (408) 527-7452 |
| rojenkin@cisco.com |  |  |  | marilmor@cisco.com |

[0001193125-18-165248:8k_2_02:5]
CISCO REPORTS THIRD QUARTER EARNINGS

[0001193125-18-165248:8k_2_02:6]
|  | • |  | Q3 Revenue: $12.5 billion |

[0001193125-18-165248:8k_2_02:7]
|  | • |  | Increase of 4% year over year |

[0001193125-18-165248:8k_2_02:8]
|  | • |  | Recurring revenue was 32% of total revenue, up 2 points year over year |

[0001193125-18-165248:8k_2_02:9]
|  | • |  | Q3 Earnings per Share: $0.56 GAAP; $0.66 non-GAAP |

[0001193125-18-165248:8k_2_02:10]
|  | • |  | Q4 FY 2018 Guidance: |

[0001193125-18-165248:8k_2_02:11]
|  | • |  | Revenue: 4% to 6% growth year over year |

[0001193125-18-165248:8k_2_02:12]
|  | • |  | Earnings per Share: GAAP: $0.55 to $0.60; Non-GAAP: $0.68 to $0.70 |

[0001193125-18-165248:8k_2_02:13]
SAN JOSE, Calif. — May 16, 2018 — Cisco today reported third quarter results for the period ended April 28, 2018. Cisco reported third
quarter revenue of $12.5 billion, net income on a generally accepted accounting principles (GAAP) basis of $2.7 billion or $0.56 per share, and non-GAAP net income of $3.2 billion or $0.66 per
share.

[0001193125-18-165248:8k_2_02:14]
“We are executing well against our strategy, our innovation pipeline has never been stronger, and we continue to make great progress in
transforming towards more software and subscriptions,” said Chuck Robbins, Chairman and CEO, Cisco. “I am confident with our position in the industry and the impact we will continue to drive with our customers.”

[0001193125-18-165248:8k_2_02:15]
GAAP Results

[0001193125-18-165248:8k_2_02:16]
|  |  | Q3 FY 2018 |  |  | Q3 FY 2017 |  |  | Vs. Q3 FY 2017 |  |
| Revenue |  | $ | 12.5 billion |  |  | $ | 11.9 billion |  |  |  | 4 | % |
| Net Income |  | $ | 2.7 billion |  |  | $ | 2.5 billion |  |  |  | 7 | % |
| Diluted Earnings per Share (EPS) |  | $ | 0.56 |  |  | $ | 0.50 |  |  |  | 12 | % |
| Non-GAAP Results |  |
|  |  | Q3 FY 2018 |  |  | Q3 FY 2017 |  |  | Vs. Q3 FY 2017 |  |
| Net Income |  | $ | 3.2 billion |  |  | $ | 3.0 billion |  |  |  | 6 | % |
| EPS |  | $ | 0.66 |  |  | $ | 0.60 |  |  |  | 10 | % |

[0001193125-18-165248:8k_2_02:17]
Reconciliations between net income, EPS, and other measures on a GAAP and non-GAAP
basis are provided in the tables located in the section entitled “Reconciliations of GAAP to non-GAAP Measures.”

[0001193125-18-165248:8k_2_02:18]
“We delivered strong results in Q3 with solid revenue growth of 4% and non-GAAP EPS growth of 10%, said Kelly Kramer, CFO of Cisco. Our investment
in innovation and continued execution are paying off. We saw broad-based strength across our portfolio, while continuing to shift our business model and deliver value for shareholders.”

[0001193125-18-165248:8k_2_02:19]
1

[0001193125-18-165248:8k_2_02:20]
Financial Summary

[0001193125-18-165248:8k_2_02:21]
All comparative percentages are on a year-over-year basis unless otherwise noted.

[0001193125-18-165248:8k_2_02:22]
Q3 FY 2018 Highlights

[0001193125-18-165248:8k_2_02:23]
Revenue — Total
revenue was $12.5 billion, up 4%, with product revenue up 5% and service revenue up 3%. 32% of total revenue was from recurring offers, up 2 percentage points from the third quarter of fiscal 2017. Revenue by geographic segment was: Americas up
2%, EMEA up 9%, and APJC up 7%. Product revenue performance was broad based with growth in Infrastructure Platforms which increased by 2%, Applications which increased by 19%, and Security which increased by 11%.

[0001193125-18-165248:8k_2_02:24]
Gross Margin — On a GAAP basis, total gross margin and product gross margin were 62.3% and 61.0%, respectively. Product gross margin
decreased compared with 61.7% in the third quarter of fiscal 2017.

[0001193125-18-165248:8k_2_02:25]
Non-GAAP total gross margin and product gross
margin were 63.9% and 62.9%, respectively. Non-GAAP product gross margin decreased compared with 63.2% in the third quarter of fiscal 2017. The decrease was primarily due to pricing and higher memory costs
partially offset by improved productivity benefits.

[0001193125-18-165248:8k_2_02:26]
GAAP service gross margin was 65.8% and non-GAAP service
gross margin was 66.9%.

[0001193125-18-165248:8k_2_02:27]
Total gross margins by geographic segment were: 64.4% for the Americas, 64.3% for EMEA and 61.7% for APJC.

[0001193125-18-165248:8k_2_02:28]
Operating Expenses — On a GAAP basis, operating expenses were $4.6 billion, up 6%.
Non-GAAP operating expenses were $4.0 billion, up 6%, and were 32.5% of revenue.

[0001193125-18-165248:8k_2_02:29]
Operating Income
— GAAP operating income was $3.1 billion, down 1%, with GAAP operating margin of 25.1%. Non-GAAP operating income was $3.9 billion, up 2%, with
non-GAAP operating margin of 31.5%.

[0001193125-18-165248:8k_2_02:30]
Provision for Income Taxes — The GAAP tax provision rate
was 17.3%. The non-GAAP tax provision rate was 21.0%.

[0001193125-18-165248:8k_2_02:31]
Net Income and EPS — On a GAAP basis,
net income was $2.7 billion and EPS was $0.56. On a non-GAAP basis, net income was $3.2 billion, an increase of 6%, and EPS was $0.66, an increase of 10%.

[0001193125-18-165248:8k_2_02:32]
Cash Flow from Operating Activities — was $2.4 billion, a decrease of 28% compared with $3.4 billion for the third quarter of
fiscal 2017. Operating cash flow includes the payment of $1.3 billion of one-time foreign taxes as related to the Tax Cuts and Jobs Act. Operating cash flow increased 11%, normalized for these tax
payments.

[0001193125-18-165248:8k_2_02:33]
Balance Sheet and Other Financial Highlights

[0001193125-18-165248:8k_2_02:34]
Cash and Cash Equivalents and Investments — were $54.4 billion at the end of the third quarter of fiscal 2018, compared with
$73.7 billion at the end of the second quarter of fiscal 2018, and compared with $70.5 billion at the end of fiscal 2017. The total cash and cash equivalents and investments available in the United States at the end of the third quarter of
fiscal 2018 were $47.5 billion.

[0001193125-18-165248:8k_2_02:35]
Deferred Revenue — was $19.0 billion, up 9% in total, with deferred product revenue up 18%,
driven largely by subscription-based and software offers, and deferred service revenue was up 4%. The portion of deferred product revenue related to recurring software and subscription offers increased 29%.

[0001193125-18-165248:8k_2_02:36]
Capital Allocation — In the third quarter of fiscal 2018, Cisco declared and paid a cash dividend of $0.33 per common share, or
$1.6 billion. For the third quarter of fiscal 2018, Cisco repurchased approximately 140 million shares of common stock under its stock repurchase program at an average price of $42.83 per share for an aggregate purchase price of
$6.0 billion. The remaining authorized amount for stock repurchases under the program is $25.1 billion with no termination date.

[0001193125-18-165248:8k_2_02:37]
Acquisitions and Divestitures

[0001193125-18-165248:8k_2_02:38]
On May 1, 2018, we
announced our intent to acquire Accompany, a privately held company that provides an AI-driven relationship intelligence platform. The Accompany acquisition closed in the fourth quarter of fiscal 2018. We also
announced an agreement to sell our Service Provider Video Software Solutions (SPVSS) business. We expect this transaction to close in the first quarter of fiscal 2019 subject to regulatory approvals and customary closing conditions.

[0001193125-18-165248:8k_2_02:39]
2

[0001193125-18-165248:8k_2_02:40]
In the third quarter of 2018, we closed our acquisition of BroadSoft, Inc., a publicly held company that offers
cloud calling and contact center solutions. We also closed our acquisition of Skyport Systems, Inc., a privately held company providing cloud-managed, hyper-converged systems that run and protect business critical applications.

[0001193125-18-165248:8k_2_02:41]
Guidance for Q4 FY 2018

[0001193125-18-165248:8k_2_02:42]
Cisco expects to achieve the
following results for the fourth quarter of fiscal 2018:

[0001193125-18-165248:8k_2_02:43]
| Q4 FY 2018 |  |  |
| Revenue |  | 4% - 6% growth Y/Y |
| Non-GAAP gross margin rate |  | 63% - 64% |
| Non-GAAP operating margin rate |  | 29.5% - 30.5% |
| Non-GAAP tax provision rate |  | 21% |
| Non-GAAP EPS |  | $0.68 - $0.70 |

[0001193125-18-165248:8k_2_02:44]
Cisco estimates that GAAP EPS will be $0.55 to $0.60 in the fourth quarter of fiscal 2018.

[0001193125-18-165248:8k_2_02:45]
A reconciliation between the Guidance for Q4 FY 2018 on a GAAP and non-GAAP basis is provided in the table entitled
“GAAP to non-GAAP Guidance for Q4 FY 2018” located in the section entitled “Reconciliations of GAAP to non-GAAP Measures.”

[0001193125-18-165248:8k_2_02:46]
Editor’s Notes:

[0001193125-18-165248:8k_2_02:47]
|  | • |  | Q3 fiscal year 2018 conference call to discuss Cisco’s results along with its guidance will be held on Wednesday, May 16, 2018 at 1:30 p.m. Pacific Time. Conference call number is 1-888-848-6507 (United States) or 1-212-519-0847 (international). |

[0001193125-18-165248:8k_2_02:48]
|  | • |  | Conference call replay will be available from 4:00 p.m. Pacific Time, May 16, 2018 to 4:00 p.m. Pacific Time, May 23, 2018 at 1-888-568-0890 (United States) or 1-402-998-1566 (international). The replay will also be available via webcast on the Cisco Investor Relations website at https://investor.cisco.com. |

[0001193125-18-165248:8k_2_02:49]
|  | • |  | Additional information regarding Cisco’s financials, as well as a webcast of the conference call with visuals designed to guide participants through the call, will be available at 1:30 p.m. Pacific Time, May 16, 2018. Text of the conference call’s prepared remarks will be available within 24 hours of completion of the call. The webcast will include both the prepared remarks and the question-and-answer session. This information, along with the GAAP to non-GAAP reconciliation information, will be available on the Cisco Investor Relations website at https://investor.cisco.com. |

[0001193125-18-165248:8k_2_02:50]
3

[0001193125-18-165248:8k_2_02:51]
CISCO SYSTEMS, INC.

[0001193125-18-165248:8k_2_02:52]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-18-165248:8k_2_02:53]
(In millions, except per-share amounts)

[0001193125-18-165248:8k_2_02:54]
(Unaudited)

[0001193125-18-165248:8k_2_02:55]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | April 28,2018 |  |  | April 29,2017 |  |  | April 28,2018 |  |  | April 29,2017 |  |
| REVENUE: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 9,304 |  |  | $ | 8,885 |  |  | $ | 27,067 |  |  | $ | 26,678 |  |
| Service |  |  | 3,159 |  |  |  | 3,055 |  |  |  | 9,419 |  |  |  | 9,194 |  |
| Total revenue |  |  | 12,463 |  |  |  | 11,940 |  |  |  | 36,486 |  |  |  | 35,872 |  |
| COST OF SALES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 3,625 |  |  |  | 3,405 |  |  |  | 10,594 |  |  |  | 10,113 |  |
| Service |  |  | 1,079 |  |  |  | 1,017 |  |  |  | 3,208 |  |  |  | 3,081 |  |
| Total cost of sales |  |  | 4,704 |  |  |  | 4,422 |  |  |  | 13,802 |  |  |  | 13,194 |  |
| GROSS MARGIN |  |  | 7,759 |  |  |  | 7,518 |  |  |  | 22,684 |  |  |  | 22,678 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 1,590 |  |  |  | 1,507 |  |  |  | 4,706 |  |  |  | 4,560 |  |
| Sales and marketing |  |  | 2,325 |  |  |  | 2,226 |  |  |  | 6,894 |  |  |  | 6,866 |  |
| General and administrative |  |  | 561 |  |  |  | 487 |  |  |  | 1,601 |  |  |  | 1,498 |  |
| Amortization of purchased intangible assets |  |  | 67 |  |  |  | 59 |  |  |  | 188 |  |  |  | 201 |  |
| Restructuring and other charges |  |  | 82 |  |  |  | 70 |  |  |  | 332 |  |  |  | 614 |  |
| Total operating expenses |  |  | 4,625 |  |  |  | 4,349 |  |  |  | 13,721 |  |  |  | 13,739 |  |
| OPERATING INCOME |  |  | 3,134 |  |  |  | 3,169 |  |  |  | 8,963 |  |  |  | 8,939 |  |
| Interest income |  |  | 380 |  |  |  | 354 |  |  |  | 1,155 |  |  |  | 978 |  |
| Interest expense |  |  | (237 | ) |  |  | (219 | ) |  |  | (719 | ) |  |  | (639 | ) |
| Other income (loss), net |  |  | (24 | ) |  |  | (113 | ) |  |  | 48 |  |  |  | (171 | ) |
| Interest and other income (loss), net |  |  | 119 |  |  |  | 22 |  |  |  | 484 |  |  |  | 168 |  |
| INCOME BEFORE PROVISION FOR INCOME TAXES |  |  | 3,253 |  |  |  | 3,191 |  |  |  | 9,447 |  |  |  | 9,107 |  |
| Provision for income taxes (1) |  |  | 562 |  |  |  | 676 |  |  |  | 13,140 |  |  |  | 1,922 |  |
| NET INCOME (LOSS) |  | $ | 2,691 |  |  | $ | 2,515 |  |  | $ | (3,693 | ) |  | $ | 7,185 |  |
| Net income (loss) per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.56 |  |  | $ | 0.50 |  |  | $ | (0.76 | ) |  | $ | 1.43 |  |
| Diluted |  | $ | 0.56 |  |  | $ | 0.50 |  |  | $ | (0.76 | ) |  | $ | 1.42 |  |
| Shares used in per-share calculation: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 4,791 |  |  |  | 5,005 |  |  |  | 4,892 |  |  |  | 5,015 |  |
| Diluted |  |  | 4,844 |  |  |  | 5,045 |  |  |  | 4,892 |  |  |  | 5,056 |  |
| Cash dividends declared per common share |  | $ | 0.33 |  |  | $ | 0.29 |  |  | $ | 0.91 |  |  | $ | 0.81 |  |

[0001193125-18-165248:8k_2_02:56]
| (1) | For the nine months ended April 28, 2018, the provision for income taxes includes an $11.1 billion charge as related to the enactment of the Tax Cuts and Jobs Act. |

[0001193125-18-165248:8k_2_02:57]
4

[0001193125-18-165248:8k_2_02:58]
CISCO SYSTEMS, INC.

[0001193125-18-165248:8k_2_02:59]
REVENUE BY SEGMENT

[0001193125-18-165248:8k_2_02:60]
(In
millions, except percentages)

[0001193125-18-165248:8k_2_02:61]
|  |  | April 28, 2018 |  |
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | Amount |  |  | Y/Y% |  |  | Amount |  |  | Y/Y% |  |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 7,161 |  |  |  | 2 | % |  | $ | 21,515 |  |  |  | 2 | % |
| EMEA |  |  | 3,281 |  |  |  | 9 | % |  |  | 9,252 |  |  |  | 2 | % |
| APJC |  |  | 2,021 |  |  |  | 7 | % |  |  | 5,719 |  |  |  | 1 | % |
| Total |  | $ | 12,463 |  |  |  | 4 | % |  | $ | 36,486 |  |  |  | 2 | % |

[0001193125-18-165248:8k_2_02:62]
CISCO SYSTEMS, INC.

[0001193125-18-165248:8k_2_02:63]
GROSS MARGIN PERCENTAGE BY SEGMENT

[0001193125-18-165248:8k_2_02:64]
(In percentages)

[0001193125-18-165248:8k_2_02:65]
|  |  | April 28, 2018 |  |
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
| Gross Margin Percentage: |  |  |  |  |  |  |  |  |
| Americas |  |  | 64.4 | % |  |  | 64.8 | % |
| EMEA |  |  | 64.3 | % |  |  | 64.0 | % |
| APJC |  |  | 61.7 | % |  |  | 61.3 | % |

[0001193125-18-165248:8k_2_02:66]
CISCO SYSTEMS, INC.

[0001193125-18-165248:8k_2_02:67]
REVENUE FOR GROUPS OF SIMILAR PRODUCTS AND SERVICES

[0001193125-18-165248:8k_2_02:68]
(In millions, except percentages)

[0001193125-18-165248:8k_2_02:69]
|  |  | April 28, 2018 |  |
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | Amount |  |  | Y/Y% |  |  | Amount |  |  | Y/Y% |  |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Infrastructure Platforms |  | $ | 7,163 |  |  |  | 2 | % |  | $ | 20,827 |  |  |  | — | % |
| Applications |  |  | 1,309 |  |  |  | 19 | % |  |  | 3,696 |  |  |  | 10 | % |
| Security |  |  | 583 |  |  |  | 11 | % |  |  | 1,726 |  |  |  | 8 | % |
| Other Products |  |  | 249 |  |  |  | (6 | )% |  |  | 818 |  |  |  | (11 | )% |
| Total Product |  |  | 9,304 |  |  |  | 5 | % |  |  | 27,067 |  |  |  | 1 | % |
| Services |  |  | 3,159 |  |  |  | 3 | % |  |  | 9,419 |  |  |  | 2 | % |
| Total |  | $ | 12,463 |  |  |  | 4 | % |  | $ | 36,486 |  |  |  | 2 | % |

[0001193125-18-165248:8k_2_02:70]
5

[0001193125-18-165248:8k_2_02:71]
CISCO SYSTEMS, INC.

[0001193125-18-165248:8k_2_02:72]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001193125-18-165248:8k_2_02:73]
(In millions)

[0001193125-18-165248:8k_2_02:74]
(Unaudited)

[0001193125-18-165248:8k_2_02:75]
|  |  | April 28, 2018 |  |  | July 29, 2017 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 6,719 |  |  | $ | 11,708 |  |
| Investments |  |  | 47,712 |  |  |  | 58,784 |  |
| Accounts receivable, net of allowance for doubtful accounts of $115 at April 28, 2018 and $211 at July 29, 2017 |  |  | 4,274 |  |  |  | 5,146 |  |
| Inventories |  |  | 1,900 |  |  |  | 1,616 |  |
| Financing receivables, net |  |  | 4,868 |  |  |  | 4,856 |  |
| Other current assets |  |  | 1,668 |  |  |  | 1,593 |  |
| Total current assets |  |  | 67,141 |  |  |  | 83,703 |  |
| Property and equipment, net |  |  | 3,082 |  |  |  | 3,322 |  |
| Financing receivables, net |  |  | 4,915 |  |  |  | 4,738 |  |
| Goodwill |  |  | 31,654 |  |  |  | 29,766 |  |
| Purchased intangible assets, net |  |  | 2,681 |  |  |  | 2,539 |  |
| Deferred tax assets |  |  | 3,044 |  |  |  | 4,239 |  |
| Other assets |  |  | 1,491 |  |  |  | 1,511 |  |
| TOTAL ASSETS |  | $ | 114,008 |  |  | $ | 129,818 |  |
| LIABILITIES AND EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 7,736 |  |  | $ | 7,992 |  |
| Accounts payable |  |  | 1,552 |  |  |  | 1,385 |  |
| Income taxes payable |  |  | 962 |  |  |  | 98 |  |
| Accrued compensation |  |  | 2,966 |  |  |  | 2,895 |  |
| Deferred revenue |  |  | 11,301 |  |  |  | 10,821 |  |
| Other current liabilities |  |  | 4,125 |  |  |  | 4,392 |  |
| Total current liabilities |  |  | 28,642 |  |  |  | 27,583 |  |
| Long-term debt |  |  | 20,336 |  |  |  | 25,725 |  |
| Income taxes payable |  |  | 9,076 |  |  |  | 1,250 |  |
| Deferred revenue |  |  | 7,652 |  |  |  | 7,673 |  |
| Other long-term liabilities |  |  | 1,641 |  |  |  | 1,450 |  |
| Total liabilities |  |  | 67,347 |  |  |  | 63,681 |  |
| Total equity |  |  | 46,661 |  |  |  | 66,137 |  |
| TOTAL LIABILITIES AND EQUITY |  | $ | 114,008 |  |  | $ | 129,818 |  |

[0001193125-18-165248:8k_2_02:76]
6

[0001193125-18-165248:8k_2_02:77]
CISCO SYSTEMS, INC.

[0001193125-18-165248:8k_2_02:78]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-18-165248:8k_2_02:79]
(In millions)

[0001193125-18-165248:8k_2_02:80]
(Unaudited)

[0001193125-18-165248:8k_2_02:81]
|  |  | Nine Months Ended |  |
|  |  | April 28,2018 |  |  | April 29,2017 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income (loss) |  | $ | (3,693 | ) |  | $ | 7,185 |  |
| Adjustments to reconcile net income (loss) to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation, amortization, and other |  |  | 1,676 |  |  |  | 1,708 |  |
| Share-based compensation expense |  |  | 1,184 |  |  |  | 1,124 |  |
| Provision for receivables |  |  | (104 | ) |  |  | 20 |  |
| Deferred income taxes |  |  | 1,013 |  |  |  | (125 | ) |
| Excess tax benefits from share-based compensation |  |  | — |  |  |  | (125 | ) |
| (Gains) losses on divestitures, investments and other, net |  |  | (159 | ) |  |  | 156 |  |
| Change in operating assets and liabilities, net of effects of acquisitions and divestitures: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 1,064 |  |  |  | 1,253 |  |
| Inventories |  |  | (289 | ) |  |  | (149 | ) |
| Financing receivables |  |  | (165 | ) |  |  | (773 | ) |
| Other assets |  |  | (135 | ) |  |  | 140 |  |
| Accounts payable |  |  | 148 |  |  |  | 149 |  |
| Income taxes, net |  |  | 8,795 |  |  |  | (112 | ) |
| Accrued compensation |  |  | 53 |  |  |  | (154 | ) |
| Deferred revenue |  |  | 415 |  |  |  | 592 |  |
| Other liabilities |  |  | (237 | ) |  |  | (1,014 | ) |
| Net cash provided by operating activities |  |  | 9,566 |  |  |  | 9,875 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of investments |  |  | (14,132 | ) |  |  | (35,562 | ) |
| Proceeds from sales of investments |  |  | 12,422 |  |  |  | 24,414 |  |
| Proceeds from maturities of investments |  |  | 12,259 |  |  |  | 8,390 |  |
| Acquisition of businesses, net of cash and cash equivalents acquired |  |  | (2,789 | ) |  |  | (3,211 | ) |
| Proceeds from business divestitures |  |  | 27 |  |  |  | — |  |
| Purchases of investments in privately held companies |  |  | (126 | ) |  |  | (172 | ) |
| Return of investments in privately held companies |  |  | 163 |  |  |  | 168 |  |
| Acquisition of property and equipment |  |  | (620 | ) |  |  | (756 | ) |
| Proceeds from sales of property and equipment |  |  | 54 |  |  |  | 6 |  |
| Other |  |  | (3 | ) |  |  | 35 |  |
| Net cash provided by (used in) investing activities |  |  | 7,255 |  |  |  | (6,688 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Issuances of common stock |  |  | 318 |  |  |  | 418 |  |
| Repurchases of common stock - repurchase program |  |  | (11,562 | ) |  |  | (2,516 | ) |
| Shares repurchased for tax withholdings on vesting of restricted stock units |  |  | (541 | ) |  |  | (497 | ) |
| Short-term borrowings, original maturities of 90 days or less, net |  |  | (2,502 | ) |  |  | 2,000 |  |
| Issuances of debt |  |  | 6,877 |  |  |  | 6,232 |  |
| Repayments of debt |  |  | (9,875 | ) |  |  | (4,151 | ) |
| Excess tax benefits from share-based compensation |  |  | — |  |  |  | 125 |  |
| Dividends paid |  |  | (4,433 | ) |  |  | (4,063 | ) |
| Other |  |  | (92 | ) |  |  | (250 | ) |
| Net cash used in financing activities |  |  | (21,810 | ) |  |  | (2,702 | ) |
| Net increase (decrease) in cash and cash equivalents |  |  | (4,989 | ) |  |  | 485 |  |
| Cash and cash equivalents, beginning of period |  |  | 11,708 |  |  |  | 7,631 |  |
| Cash and cash equivalents, end of period |  | $ | 6,719 |  |  | $ | 8,116 |  |
| Supplemental cash flow information: |  |  |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 739 |  |  | $ | 727 |  |
| Cash paid for income taxes, net |  | $ | 3,332 |  |  | $ | 2,159 |  |

[0001193125-18-165248:8k_2_02:82]
7

[0001193125-18-165248:8k_2_02:83]
CISCO SYSTEMS, INC.

[0001193125-18-165248:8k_2_02:84]
DEFERRED REVENUE

[0001193125-18-165248:8k_2_02:85]
(In
millions)

[0001193125-18-165248:8k_2_02:86]
|  |  | April 28,2018 |  |  | January 27,2018 |  |  | April 29,2017 |  |
| Deferred revenue: |  |  |  |  |  |  |  |  |  |  |  |  |
| Service |  | $ | 10,960 |  |  | $ | 10,963 |  |  | $ | 10,532 |  |
| Product: |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred revenue related to recurring software and subscription offers |  |  | 5,635 |  |  |  | 5,451 |  |  |  | 4,352 |  |
| Other product deferred revenue |  |  | 2,358 |  |  |  | 2,374 |  |  |  | 2,438 |  |
| Total product deferred revenue |  |  | 7,993 |  |  |  | 7,825 |  |  |  | 6,790 |  |
| Total |  | $ | 18,953 |  |  | $ | 18,788 |  |  | $ | 17,322 |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |  |
| Current |  | $ | 11,301 |  |  | $ | 11,102 |  |  | $ | 10,344 |  |
| Noncurrent |  |  | 7,652 |  |  |  | 7,686 |  |  |  | 6,978 |  |
| Total |  | $ | 18,953 |  |  | $ | 18,788 |  |  | $ | 17,322 |  |

[0001193125-18-165248:8k_2_02:87]
CISCO SYSTEMS, INC.

[0001193125-18-165248:8k_2_02:88]
DIVIDENDS PAID AND REPURCHASES OF COMMON STOCK

[0001193125-18-165248:8k_2_02:89]
(In millions, except per-share amounts)

[0001193125-18-165248:8k_2_02:90]
|  |  | DIVIDENDS |  |  | STOCK REPURCHASE PROGRAM |  |  | TOTAL |  |
| Quarter Ended |  | Per Share |  |  | Amount |  |  | Shares |  |  | Weighted-Average Priceper Share |  |  | Amount |  |  | Amount |  |
| Fiscal 2018 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| April 28, 2018 |  | $ | 0.33 |  |  | $ | 1,572 |  |  |  | 140 |  |  | $ | 42.83 |  |  | $ | 6,015 |  |  | $ | 7,587 |  |
| January 27, 2018 |  | $ | 0.29 |  |  | $ | 1,425 |  |  |  | 103 |  |  | $ | 39.07 |  |  | $ | 4,011 |  |  | $ | 5,436 |  |
| October 28, 2017 |  | $ | 0.29 |  |  | $ | 1,436 |  |  |  | 51 |  |  | $ | 31.80 |  |  | $ | 1,620 |  |  | $ | 3,056 |  |
| Fiscal 2017 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| July 29, 2017 |  | $ | 0.29 |  |  | $ | 1,448 |  |  |  | 38 |  |  | $ | 31.61 |  |  | $ | 1,201 |  |  | $ | 2,649 |  |
| April 29, 2017 |  | $ | 0.29 |  |  | $ | 1,451 |  |  |  | 15 |  |  | $ | 33.71 |  |  | $ | 503 |  |  | $ | 1,954 |  |
| January 28, 2017 |  | $ | 0.26 |  |  | $ | 1,304 |  |  |  | 33 |  |  | $ | 30.33 |  |  | $ | 1,001 |  |  | $ | 2,305 |  |
| October 29, 2016 |  | $ | 0.26 |  |  | $ | 1,308 |  |  |  | 32 |  |  | $ | 31.12 |  |  | $ | 1,001 |  |  | $ | 2,309 |  |

[0001193125-18-165248:8k_2_02:91]
8

[0001193125-18-165248:8k_2_02:92]
CISCO SYSTEMS, INC.

[0001193125-18-165248:8k_2_02:93]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-18-165248:8k_2_02:94]
GAAP NET INCOME (LOSS) TO NON-GAAP NET INCOME

[0001193125-18-165248:8k_2_02:95]
(In millions, except per-share amounts)

[0001193125-18-165248:8k_2_02:96]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | April 28,2018 |  |  | April 29,2017 |  |  | April 28,2018 |  |  | April 29,2017 |  |
| GAAP net income (loss) |  | $ | 2,691 |  |  | $ | 2,515 |  |  | $ | (3,693 | ) |  | $ | 7,185 |  |
| Adjustments to cost of sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 57 |  |  |  | 56 |  |  |  | 168 |  |  |  | 163 |  |
| Amortization of acquisition-related intangible assets |  |  | 161 |  |  |  | 124 |  |  |  | 444 |  |  |  | 343 |  |
| Supplier component remediation charge (adjustment), net |  |  | (9 | ) |  |  | (13 | ) |  |  | (41 | ) |  |  | (29 | ) |
| Acquisition-related/divestiture costs |  |  | 2 |  |  |  | — |  |  |  | 4 |  |  |  | 1 |  |
| Legal and indemnification settlements |  |  | — |  |  |  | — |  |  |  | 122 |  |  |  | — |  |
| Total adjustments to GAAP cost of sales |  |  | 211 |  |  |  | 167 |  |  |  | 697 |  |  |  | 478 |  |
| Adjustments to operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 342 |  |  |  | 349 |  |  |  | 1,010 |  |  |  | 963 |  |
| Amortization of acquisition-related intangible assets |  |  | 67 |  |  |  | 59 |  |  |  | 188 |  |  |  | 201 |  |
| Acquisition-related/divestiture costs |  |  | 89 |  |  |  | 43 |  |  |  | 195 |  |  |  | 157 |  |
| Significant asset impairments and restructurings |  |  | 82 |  |  |  | 70 |  |  |  | 332 |  |  |  | 614 |  |
| Total adjustments to GAAP operating expenses |  |  | 580 |  |  |  | 521 |  |  |  | 1,725 |  |  |  | 1,935 |  |
| Total adjustments to GAAP income (loss) before provision for income taxes |  |  | 791 |  |  |  | 688 |  |  |  | 2,422 |  |  |  | 2,413 |  |
| Income tax effect of non-GAAP adjustments |  |  | (168 | ) |  |  | (177 | ) |  |  | (613 | ) |  |  | (612 | ) |
| Significant tax matters (1) |  |  | (119 | ) |  |  | — |  |  |  | 11,261 |  |  |  | — |  |
| Total adjustments to GAAP provision for income taxes |  |  | (287 | ) |  |  | (177 | ) |  |  | 10,648 |  |  |  | (612 | ) |
| Non-GAAP net income |  | $ | 3,195 |  |  | $ | 3,026 |  |  | $ | 9,377 |  |  | $ | 8,986 |  |
| Net income (loss) per share: (2) |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | $ | 0.56 |  |  | $ | 0.50 |  |  | $ | (0.76 | ) |  | $ | 1.42 |  |
| Non-GAAP |  | $ | 0.66 |  |  | $ | 0.60 |  |  | $ | 1.90 |  |  | $ | 1.78 |  |

[0001193125-18-165248:8k_2_02:97]
| (1) | Cisco recorded charges relating to significant tax matters that were excluded from non-GAAP net income for the first nine months of fiscal 2018. $11.1 billion of these charges were provisional amounts related to the enactment of the Tax Cuts and Jobs Act comprised of $8.9 billion related to the U.S. transition tax, $1.2 billion related to foreign withholding tax and $1.0 billion related to the re-measurement of net deferred tax assets. The amounts are provisional based on Securities and Exchange Commission Staff Accounting Bulletin No. 118. The remaining $0.2 billion was related to other significant tax matters. |

[0001193125-18-165248:8k_2_02:98]
| (2) | GAAP net loss per share for the nine months ended April 28, 2018 is calculated using basic shares of 4,892 million, due to the net loss resulting from the tax charge as discussed in footnote (1). Non-GAAP net income per share for the period is calculated using diluted shares of 4,936 million, as the Company had non-GAAP net income for this period. |

[0001193125-18-165248:8k_2_02:99]
9

[0001193125-18-165248:8k_2_02:100]
CISCO SYSTEMS, INC.

[0001193125-18-165248:8k_2_02:101]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-18-165248:8k_2_02:102]
GROSS MARGINS, OPERATING EXPENSES, OPERATING MARGINS, AND NET INCOME

[0001193125-18-165248:8k_2_02:103]
(In millions, except percentages)

[0001193125-18-165248:8k_2_02:104]
|  |  | Three Months Ended |  |
|  |  | April 28, 2018 |  |
|  |  | ProductGrossMargin |  |  | ServiceGrossMargin |  |  | TotalGrossMargin |  |  | OperatingExpenses |  |  | Y/Y |  |  | OperatingIncome |  |  | Y/Y |  |  | NetIncome |  |  | Y/Y |  |
| GAAP amount |  | $ | 5,679 |  |  | $ | 2,080 |  |  | $ | 7,759 |  |  | $ | 4,625 |  |  |  | 6 | % |  | $ | 3,134 |  |  |  | (1 | )% |  | $ | 2,691 |  |  |  | 7 | % |
| % of revenue |  |  | 61.0 | % |  |  | 65.8 | % |  |  | 62.3 | % |  |  | 37.1 | % |  |  |  |  |  |  | 25.1 | % |  |  |  |  |  |  | 21.6 | % |  |  |  |  |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 24 |  |  |  | 33 |  |  |  | 57 |  |  |  | 342 |  |  |  |  |  |  |  | 399 |  |  |  |  |  |  |  | 399 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  |  | 161 |  |  |  | — |  |  |  | 161 |  |  |  | 67 |  |  |  |  |  |  |  | 228 |  |  |  |  |  |  |  | 228 |  |  |  |  |  |
| Supplier component remediation charge (adjustment), net |  |  | (9 | ) |  |  | — |  |  |  | (9 | ) |  |  | — |  |  |  |  |  |  |  | (9 | ) |  |  |  |  |  |  | (9 | ) |  |  |  |  |
| Acquisition/divestiture-related costs |  |  | 1 |  |  |  | 1 |  |  |  | 2 |  |  |  | 89 |  |  |  |  |  |  |  | 91 |  |  |  |  |  |  |  | 91 |  |  |  |  |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 82 |  |  |  |  |  |  |  | 82 |  |  |  |  |  |  |  | 82 |  |  |  |  |  |
| Income tax effect/significant tax matters |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | (287 | ) |  |  |  |  |
| Non-GAAP amount |  | $ | 5,856 |  |  | $ | 2,114 |  |  | $ | 7,970 |  |  | $ | 4,045 |  |  |  | 6 | % |  | $ | 3,925 |  |  |  | 2 | % |  | $ | 3,195 |  |  |  | 6 | % |
| % of revenue |  |  | 62.9 | % |  |  | 66.9 | % |  |  | 63.9 | % |  |  | 32.5 | % |  |  |  |  |  |  | 31.5 | % |  |  |  |  |  |  | 25.6 | % |  |  |  |  |

[0001193125-18-165248:8k_2_02:105]
|  |  | Three Months Ended |  |
|  |  | April 29, 2017 |  |
|  |  | Product GrossMargin |  |  | Service GrossMargin |  |  | Total GrossMargin |  |  | OperatingExpenses |  |  | OperatingIncome |  |  | NetIncome |  |
| GAAP amount |  | $ | 5,480 |  |  | $ | 2,038 |  |  | $ | 7,518 |  |  | $ | 4,349 |  |  | $ | 3,169 |  |  | $ | 2,515 |  |
| % of revenue |  |  | 61.7 | % |  |  | 66.7 | % |  |  | 63.0 | % |  |  | 36.4 | % |  |  | 26.5 | % |  |  | 21.1 | % |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 22 |  |  |  | 34 |  |  |  | 56 |  |  |  | 349 |  |  |  | 405 |  |  |  | 405 |  |
| Amortization of acquisition-related intangible assets |  |  | 124 |  |  |  | — |  |  |  | 124 |  |  |  | 59 |  |  |  | 183 |  |  |  | 183 |  |
| Supplier component remediation charge (adjustment), net |  |  | (13 | ) |  |  | — |  |  |  | (13 | ) |  |  | — |  |  |  | (13 | ) |  |  | (13 | ) |
| Acquisition/divestiture-related costs |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 43 |  |  |  | 43 |  |  |  | 43 |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 70 |  |  |  | 70 |  |  |  | 70 |  |
| Income tax effect |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (177 | ) |
| Non-GAAP amount |  | $ | 5,613 |  |  | $ | 2,072 |  |  | $ | 7,685 |  |  | $ | 3,828 |  |  | $ | 3,857 |  |  | $ | 3,026 |  |
| % of revenue |  |  | 63.2 | % |  |  | 67.8 | % |  |  | 64.4 | % |  |  | 32.1 | % |  |  | 32.3 | % |  |  | 25.3 | % |

[0001193125-18-165248:8k_2_02:106]
10

[0001193125-18-165248:8k_2_02:107]
CISCO SYSTEMS, INC.

[0001193125-18-165248:8k_2_02:108]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-18-165248:8k_2_02:109]
GROSS MARGINS, OPERATING EXPENSES, OPERATING MARGINS, AND NET INCOME (LOSS)

[0001193125-18-165248:8k_2_02:110]
(In millions, except percentages)

[0001193125-18-165248:8k_2_02:111]
|  |  | Nine Months Ended |  |
|  |  | April 28, 2018 |  |
|  |  | ProductGrossMargin |  |  | ServiceGrossMargin |  |  | TotalGrossMargin |  |  | OperatingExpenses |  |  | Y/Y |  |  | OperatingIncome |  |  | Y/Y |  |  | NetIncome(Loss) |  |  | Y/Y |  |
| GAAP amount |  | $ | 16,473 |  |  | $ | 6,211 |  |  | $ | 22,684 |  |  | $ | 13,721 |  |  |  | — | % |  | $ | 8,963 |  |  |  | — | % |  | $ | (3,693 | ) |  |  | (151 | )% |
| % of revenue |  |  | 60.9 | % |  |  | 65.9 | % |  |  | 62.2 | % |  |  | 37.6 | % |  |  |  |  |  |  | 24.6 | % |  |  |  |  |  |  | (10.1 | )% |  |  |  |  |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 70 |  |  |  | 98 |  |  |  | 168 |  |  |  | 1,010 |  |  |  |  |  |  |  | 1,178 |  |  |  |  |  |  |  | 1,178 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  |  | 444 |  |  |  | — |  |  |  | 444 |  |  |  | 188 |  |  |  |  |  |  |  | 632 |  |  |  |  |  |  |  | 632 |  |  |  |  |  |
| Supplier component remediation charge (adjustment), net |  |  | (41 | ) |  |  | — |  |  |  | (41 | ) |  |  | — |  |  |  |  |  |  |  | (41 | ) |  |  |  |  |  |  | (41 | ) |  |  |  |  |
| Legal and indemnification settlements |  |  | 122 |  |  |  | — |  |  |  | 122 |  |  |  | — |  |  |  |  |  |  |  | 122 |  |  |  |  |  |  |  | 122 |  |  |  |  |  |
| Acquisition/divestiture-related costs |  |  | 1 |  |  |  | 3 |  |  |  | 4 |  |  |  | 195 |  |  |  |  |  |  |  | 199 |  |  |  |  |  |  |  | 199 |  |  |  |  |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 332 |  |  |  |  |  |  |  | 332 |  |  |  |  |  |  |  | 332 |  |  |  |  |  |
| Income tax effect/significant tax matters (1) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | 10,648 | (1) |  |  |  |  |
| Non-GAAP amount |  | $ | 17,069 |  |  | $ | 6,312 |  |  | $ | 23,381 |  |  | $ | 11,996 |  |  |  | 2 | % |  | $ | 11,385 |  |  |  | — | % |  | $ | 9,377 |  |  |  | 4 | % |
| % of revenue |  |  | 63.1 | % |  |  | 67.0 | % |  |  | 64.1 | % |  |  | 32.9 | % |  |  |  |  |  |  | 31.2 | % |  |  |  |  |  |  | 25.7 | % |  |  |  |  |

[0001193125-18-165248:8k_2_02:112]
| (1) | Includes an $11.1 billion charge as related to the enactment of the Tax Cuts and Jobs Act. |

[0001193125-18-165248:8k_2_02:113]
|  |  | Nine Months Ended |  |
|  |  | April 29, 2017 |  |
|  |  | ProductGrossMargin |  |  | ServiceGrossMargin |  |  | TotalGrossMargin |  |  | OperatingExpenses |  |  | OperatingIncome |  |  | NetIncome |  |
| GAAP amount |  | $ | 16,565 |  |  | $ | 6,113 |  |  | $ | 22,678 |  |  | $ | 13,739 |  |  | $ | 8,939 |  |  | $ | 7,185 |  |
| % of revenue |  |  | 62.1 | % |  |  | 66.5 | % |  |  | 63.2 | % |  |  | 38.3 | % |  |  | 24.9 | % |  |  | 20.0 | % |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 62 |  |  |  | 101 |  |  |  | 163 |  |  |  | 963 |  |  |  | 1,126 |  |  |  | 1,126 |  |
| Amortization of acquisition-related intangible assets |  |  | 343 |  |  |  | — |  |  |  | 343 |  |  |  | 201 |  |  |  | 544 |  |  |  | 544 |  |
| Supplier component remediation charge (adjustment), net |  |  | (29 | ) |  |  | — |  |  |  | (29 | ) |  |  | — |  |  |  | (29 | ) |  |  | (29 | ) |
| Acquisition/divestiture-related costs |  |  | — |  |  |  | 1 |  |  |  | 1 |  |  |  | 157 |  |  |  | 158 |  |  |  | 158 |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 614 |  |  |  | 614 |  |  |  | 614 |  |
| Income tax effect |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (612 | ) |
| Non-GAAP amount |  | $ | 16,941 |  |  | $ | 6,215 |  |  | $ | 23,156 |  |  | $ | 11,804 |  |  | $ | 11,352 |  |  | $ | 8,986 |  |
| % of revenue |  |  | 63.5 | % |  |  | 67.6 | % |  |  | 64.6 | % |  |  | 32.9 | % |  |  | 31.6 | % |  |  | 25.1 | % |

[0001193125-18-165248:8k_2_02:114]
11

[0001193125-18-165248:8k_2_02:115]
CISCO SYSTEMS, INC.

[0001193125-18-165248:8k_2_02:116]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-18-165248:8k_2_02:117]
EFFECTIVE TAX RATE

[0001193125-18-165248:8k_2_02:118]
(In
percentages)

[0001193125-18-165248:8k_2_02:119]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | April 28, 2018 |  |  | April 29, 2017 |  |  | April 28, 2018 |  |  | April 29, 2017 |  |
| GAAP effective tax rate (1) |  |  | 17.3% |  |  |  | 21.2% |  |  |  | 139.1% |  |  |  | 21.1% |  |
| Total adjustments to GAAP provision for income taxes |  |  | 3.7% |  |  |  | 0.8% |  |  |  | (118.1)% |  |  |  | 0.9% |  |
| Non-GAAP effective tax rate |  |  | 21.0% |  |  |  | 22.0% |  |  |  | 21.0% |  |  |  | 22.0% |  |

[0001193125-18-165248:8k_2_02:120]
| (1) | Includes an $11.1 billion charge as related to the enactment of the Tax Cuts and Jobs Act for the nine months ended April 28, 2018. |

[0001193125-18-165248:8k_2_02:121]
GAAP TO NON-GAAP GUIDANCE FOR Q4 FY 2018

[0001193125-18-165248:8k_2_02:122]
| Q4 FY 2018 |  | Gross MarginRate |  | Operating MarginRate |  | Tax ProvisionRate |  | Earnings perShare (2) |  |
| GAAP |  | 61.5% - 62.5% |  | 24% - 25% |  | 20% |  | $ | 0.55 - $0.60 |  |
| Estimated adjustments for: |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  | 0.5% |  | 3.0% |  | — |  | $ | 0.05 - $0.06 |  |
| Amortization of purchased intangible assets and other acquisition-related/divestiture costs |  | 1.0% |  | 2.5% |  | — |  | $ | 0.05 - $0.06 |  |
| Restructuring and other charges (1) |  | — |  | — |  | — |  | $ | 0.00 - $0.01 |  |
| Income tax effect of non-GAAP adjustments |  | — |  | — |  | 1% |  |  |  |  |
| Non-GAAP |  | 63% - 64% |  | 29.5% - 30.5% |  | 21% |  | $ | 0.68 - $0.70 |  |

[0001193125-18-165248:8k_2_02:123]
| (1) | In the third quarter of fiscal 2018, Cisco initiated a restructuring plan in order to realign the organization and enable further investment in key priority areas. The total pre-tax cash charges to the GAAP financial results is estimated to be approximately $300 million consisting of severance and other one-time benefits, and other associated costs. We expect to recognize up to $50 million of these charges in the fourth quarter of fiscal 2018 with the remaining amount to be recognized through fiscal 2019. |

[0001193125-18-165248:8k_2_02:124]
| (2) | Estimated adjustments to GAAP earnings per share are shown after income tax effects. |

[0001193125-18-165248:8k_2_02:125]
Except as noted above,
this guidance does not include the effects of any future acquisitions/divestitures, asset impairments, restructurings and significant tax matters or other events, which may or may not be significant unless specifically stated.

[0001193125-18-165248:8k_2_02:126]
12

[0001193125-18-165248:8k_2_02:127]
Forward Looking Statements, Non-GAAP Information and Additional
Information

[0001193125-18-165248:8k_2_02:128]
This release includes non-GAAP net income, non-GAAP gross margins, non-GAAP operating expenses, non-GAAP operating income and margin, non-GAAP effective tax rates, and
non-GAAP net income per share data for the periods presented. It also includes future estimated ranges for gross margin, operating margin, tax provision rate and EPS on a
non-GAAP basis.

[0001193125-18-165248:8k_2_02:129]
These non-GAAP measures are not in accordance with, or an
alternative for, measures prepared in accordance with generally accepted accounting principles and may be different from non-GAAP measures used by other companies. In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles. Cisco believes that non-GAAP measures have limitations in that they do not reflect
all of the amounts associated with Cisco’s results of operations as determined in accordance with GAAP and that these measures should only be used to evaluate Cisco’s results of operations in conjunction with the corresponding GAAP
measures.

[0001193125-18-165248:8k_2_02:130]
Cisco believes that the presentation of non-GAAP measures when shown in conjunction with the
corresponding GAAP measures, provides useful information to investors and management regarding financial and business trends relating to its financial condition and its historical and projected results of operations.

[0001193125-18-165248:8k_2_02:131]
For its internal budgeting process, Cisco’s management uses financial statements that do not include, when
applicable, share-based compensation expense, amortization of acquisition-related intangible assets, acquisition-related/divestiture costs, significant asset impairments and restructurings, significant litigation settlements and other contingencies,
significant gains and losses on investments, the income tax effects of the foregoing and significant tax matters. Cisco’s management also uses the foregoing non-GAAP measures, in addition to the
corresponding GAAP measures, in reviewing the financial results of Cisco. In prior periods, Cisco has excluded other items that it no longer excludes for purposes of its non-GAAP financial measures. From time
to time in the future there may be other items that Cisco may exclude for purposes of its internal budgeting process and in reviewing its financial results. For additional information on the items excluded by Cisco from one or more of its non-GAAP financial measures, refer to the Form 8-K regarding this release furnished today to the Securities and Exchange Commission.

[0001193125-18-165248:8k_2_02:132]
About Cisco

[0001193125-18-165248:8k_2_02:133]
Cisco (NASDAQ: CSCO) is the worldwide
technology leader that has been making the Internet work since 1984. Our people, products and partners help society securely connect and seize tomorrow’s digital opportunity today. Discover more at thenetwork.cisco.com and follow us on Twitter
at @Cisco.

[0001193125-18-165248:8k_2_02:134]
Copyright © 2018 Cisco and/or its affiliates. All rights reserved. Cisco and the
Cisco logo are trademarks or registered trademarks of Cisco and/or its affiliates in the U.S. and other countries. To view a list of Cisco trademarks, go to: www.cisco.com/go/trademarks. Third-party trademarks mentioned in this document are the
property of their respective owners. The use of the word partner does not imply a partnership relationship between Cisco and any other company. This document is Cisco Public Information.

[0001193125-18-165248:8k_2_02:135]
14
