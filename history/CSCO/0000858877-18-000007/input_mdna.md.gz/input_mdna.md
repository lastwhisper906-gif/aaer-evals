# CSCO MD&A — 0000858877-18-000007


## mdna

[0000858877-18-000007:mdna:1]
[same as prior period, unchanged from 0000858877-18-000004:mdna:1]

[0000858877-18-000007:mdna:2]
[same as prior period, unchanged from 0000858877-18-000004:mdna:2]

[0000858877-18-000007:mdna:3]
[same as prior period, unchanged from 0000858877-18-000004:mdna:3]

[0000858877-18-000007:mdna:4]
[same as prior period, unchanged from 0000858877-18-000004:mdna:4]

[0000858877-18-000007:mdna:5]
[same as prior period, unchanged from 0000858877-18-000004:mdna:5]

[0000858877-18-000007:mdna:6]
|  | Three Months Ended |  |  | Nine Months Ended |  |
|  | April 28, 2018 |  | April 29, 2017 |  | Variance |  |  | April 28, 2018 |  | April 29, 2017 |  | Variance |  |
| Revenue | $ | 12,463 |  |  | $ | 11,940 |  |  | 4 | % |  |  | $ | 36,486 |  |  | $ | 35,872 |  |  | 2 | % |  |
| Gross margin percentage | 62.3 | % |  | 63.0 | % |  | (0.7 | ) | pts |  | 62.2 | % |  | 63.2 | % |  | (1.0 | ) | pts |
| Research and development | $ | 1,590 |  |  | $ | 1,507 |  |  | 6 | % |  |  | $ | 4,706 |  |  | $ | 4,560 |  |  | 3 | % |  |
| Sales and marketing | $ | 2,325 |  |  | $ | 2,226 |  |  | 4 | % |  |  | $ | 6,894 |  |  | $ | 6,866 |  |  | — | % |  |
| General and administrative | $ | 561 |  |  | $ | 487 |  |  | 15 | % |  |  | $ | 1,601 |  |  | $ | 1,498 |  |  | 7 | % |  |
| Total research and development, sales and marketing, general and administrative | $ | 4,476 |  |  | $ | 4,220 |  |  | 6 | % |  |  | $ | 13,201 |  |  | $ | 12,924 |  |  | 2 | % |  |
| Total as a percentage of revenue | 35.9 | % |  | 35.3 | % |  | 0.6 |  | pts |  | 36.2 | % |  | 36.0 | % |  | 0.2 |  | pts |
| Amortization of purchased intangible assets included in operating expenses | $ | 67 |  |  | $ | 59 |  |  | 14 | % |  |  | $ | 188 |  |  | $ | 201 |  |  | (6 | )% |  |
| Restructuring and other charges included in operating expenses | $ | 82 |  |  | $ | 70 |  |  | 17 | % |  |  | $ | 332 |  |  | $ | 614 |  |  | (46 | )% |  |
| Operating income as a percentage of revenue | 25.1 | % |  | 26.5 | % |  | (1.4 | ) | pts |  | 24.6 | % |  | 24.9 | % |  | (0.3 | ) | pts |
| Income tax percentage | 17.3 | % |  | 21.2 | % |  | (3.9 | ) | pts |  | 139.1 | % |  | 21.1 | % |  | 118.0 |  | pts |
| Net income (loss) | $ | 2,691 |  |  | $ | 2,515 |  |  | 7 | % |  |  | $ | (3,693 | ) |  | $ | 7,185 |  |  | (151 | )% |  |
| Net income (loss) as a percentage of revenue | 21.6 | % |  | 21.1 | % |  | 0.5 |  | pts |  | (10.1 | )% |  | 20.0 | % |  | (30.1 | ) | pts |
| Earnings (loss) per share | $ | 0.56 |  |  | $ | 0.50 |  |  | 12 | % |  |  | $ | (0.76 | ) |  | $ | 1.42 |  |  | (154 | )% |  |

[0000858877-18-000007:mdna:7]
48

[0000858877-18-000007:mdna:8]
[same as prior period, unchanged from 0000858877-18-000004:mdna:7]

[0000858877-18-000007:mdna:9]
[same as prior period, unchanged from 0000858877-18-000004:mdna:8]

[0000858877-18-000007:mdna:10]
Three Months Ended April 28, 2018 Compared with Three Months Ended April 29, 2017

[0000858877-18-000007:mdna:11]
In the third quarter of fiscal 2018, we saw broad strength across the business and delivered strong revenue growth and solid margins.  We remain focused on accelerating innovation across our portfolio, and we believe that we have made continued progress on our strategic priorities. Our product revenue reflected growth in Infrastructure Platforms, Applications and Security, and we continued to make progress in the transition of our business model to increased software and subscriptions. We continue to operate in a challenging and highly competitive environment, which has negatively impacted routing products within our Infrastructure Platforms product category. We continued to see weakness in the service provider market and we expect ongoing uncertainty in that area. While the overall environment remains uncertain, we continue to aggressively invest in priority areas with the objective of driving profitable growth over the long term.

[0000858877-18-000007:mdna:12]
Total revenue increased by 4% compared with the third quarter of fiscal 2017. Within total revenue, product revenue increased by 5% and service revenue increased by 3%. Total gross margin decreased by 0.7 percentage points, driven primarily by unfavorable impacts from pricing, higher memory costs and higher amortization expense from purchased intangible assets, partially offset by productivity improvements. As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses, collectively, increased by 0.6 percentage points. Operating income as a percentage of revenue decreased by 1.4 percentage points. Diluted earnings per share increased by 12%, driven by a 7% increase in net income and a decrease in diluted share count of 201 million shares.

[0000858877-18-000007:mdna:13]
In terms of our geographic segments, revenue from the Americas increased $115 million, EMEA revenue increased by $282 million, and revenue in our APJC segment increased by $126 million. These increases reflect broad strength across several countries within these segments. The “BRICM” countries experienced product revenue growth of 5% in the aggregate, driven by increased product revenue in the emerging countries of Russia, Brazil, India and China of 28%, 22%, 5% and 4%, respectively, partially offset by a product revenue decline of 16% in Mexico.

[0000858877-18-000007:mdna:14]
From a customer market standpoint, we experienced solid product revenue growth in the commercial market and to a lesser extent in the enterprise and public sector markets. Product revenue in the service provider market continued to decline with ongoing uncertainty in that area.

[0000858877-18-000007:mdna:15]
From a product category perspective, the product revenue increase of 5% was driven by a 2% product revenue increase in Infrastructure Platforms and solid product revenue growth in Applications and Security, which grew by 19% and 11%, respectively. We saw broad strength across the portfolio with the exception of routing related to the weakness in the service provider market.

[0000858877-18-000007:mdna:16]
[same as prior period, unchanged from 0000858877-18-000004:mdna:15]

[0000858877-18-000007:mdna:17]
[same as prior period, unchanged from 0000858877-18-000004:mdna:16]

[0000858877-18-000007:mdna:18]
Nine Months Ended April 28, 2018 Compared with Nine Months Ended April 29, 2017

[0000858877-18-000007:mdna:19]
Total revenue increased 2%, with product revenue increasing 1% and service revenue increasing 2%. Total gross margin decreased by 1.0 percentage points due to unfavorable impacts from pricing and a $127 million legal and indemnification settlement charge, partially offset by productivity benefits and favorable product mix. As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses collectively increased by 0.2 percentage points. Operating income as a percentage of revenue decreased by 0.3 percentage points. We had a net loss of $3.7 billion and a net loss per share of $0.76, primarily due to the $11.1 billion provisional tax expense related to the enactment of the Tax Cuts and Jobs Act (the “Tax Act”), comprised of $8.9 billion of U.S. transition tax, $1.2 billion of foreign withholding tax, and $1.0 billion of net deferred tax assets re-measurement.

[0000858877-18-000007:mdna:20]
[same as prior period, unchanged from 0000858877-18-000004:mdna:19]

[0000858877-18-000007:mdna:21]
[same as prior period, unchanged from 0000858877-18-000004:mdna:20]

[0000858877-18-000007:mdna:22]
[same as prior period, unchanged from 0000858877-18-000004:mdna:21]

[0000858877-18-000007:mdna:23]
[same as prior period, unchanged from 0000858877-18-000004:mdna:22]

[0000858877-18-000007:mdna:24]
The following is a summary of our other key financial measures for the third quarter and first nine months of fiscal 2018 (in millions):

[0000858877-18-000007:mdna:25]
|  |  | April 28, 2018 |  | July 29, 2017 |
| Cash and cash equivalents and investments |  | $ | 54,431 |  |  | $ | 70,492 |  |
| Deferred revenue |  | $ | 18,953 |  |  | $ | 18,494 |  |
| Inventories |  | $ | 1,900 |  |  | $ | 1,616 |  |

[0000858877-18-000007:mdna:26]
|  |  | Nine Months Ended |
|  |  | April 28, 2018 |  | April 29, 2017 |
| Cash provided by operating activities |  | $ | 9,566 |  |  | $ | 9,875 |  |
| Repurchases of common stock—stock repurchase program |  | $ | 11,646 |  |  | $ | 2,505 |  |
| Dividends |  | $ | 4,433 |  |  | $ | 4,063 |  |

[0000858877-18-000007:mdna:27]
[same as prior period, unchanged from 0000858877-18-000004:mdna:26]

[0000858877-18-000007:mdna:28]
[same as prior period, unchanged from 0000858877-18-000004:mdna:27]

[0000858877-18-000007:mdna:29]
[same as prior period, unchanged from 0000858877-18-000004:mdna:28]

[0000858877-18-000007:mdna:30]
[same as prior period, unchanged from 0000858877-18-000004:mdna:29]

[0000858877-18-000007:mdna:31]
[same as prior period, unchanged from 0000858877-18-000004:mdna:30]

[0000858877-18-000007:mdna:32]
[same as prior period, unchanged from 0000858877-18-000004:mdna:31]

[0000858877-18-000007:mdna:33]
[same as prior period, unchanged from 0000858877-18-000004:mdna:32]

[0000858877-18-000007:mdna:34]
[same as prior period, unchanged from 0000858877-18-000004:mdna:33]

[0000858877-18-000007:mdna:35]
[same as prior period, unchanged from 0000858877-18-000004:mdna:34]

[0000858877-18-000007:mdna:36]
[same as prior period, unchanged from 0000858877-18-000004:mdna:35]

[0000858877-18-000007:mdna:37]
[same as prior period, unchanged from 0000858877-18-000004:mdna:36]

[0000858877-18-000007:mdna:38]
[same as prior period, unchanged from 0000858877-18-000004:mdna:37]

[0000858877-18-000007:mdna:39]
As our business and offerings evolve over time, our pricing practices may be required to be modified accordingly, which could result in changes in selling prices, including both VSOE and ESP, in subsequent periods.

[0000858877-18-000007:mdna:40]
[same as prior period, unchanged from 0000858877-18-000004:mdna:42]

[0000858877-18-000007:mdna:41]
[same as prior period, unchanged from 0000858877-18-000004:mdna:39]

[0000858877-18-000007:mdna:42]
[same as prior period, unchanged from 0000858877-18-000004:mdna:40]

[0000858877-18-000007:mdna:43]
[same as prior period, unchanged from 0000858877-18-000004:mdna:41]

[0000858877-18-000007:mdna:44]
[same as prior period, unchanged from 0000858877-18-000004:mdna:43]

[0000858877-18-000007:mdna:45]
[same as prior period, unchanged from 0000858877-18-000004:mdna:44]

[0000858877-18-000007:mdna:46]
|  |  | April 28, 2018 |  | July 29, 2017 |
| Allowance for doubtful accounts |  | $ | 115 |  |  | $ | 211 |  |
| Percentage of gross accounts receivable |  | 2.6 | % |  | 3.9 | % |
| Allowance for credit loss—lease receivables |  | $ | 165 |  |  | $ | 162 |  |
| Percentage of gross lease receivables(1) |  | 5.8 | % |  | 5.5 | % |
| Allowance for credit loss—loan receivables |  | $ | 85 |  |  | $ | 103 |  |
| Percentage of gross loan receivables |  | 1.7 | % |  | 2.3 | % |

[0000858877-18-000007:mdna:47]
[same as prior period, unchanged from 0000858877-18-000004:mdna:46]

[0000858877-18-000007:mdna:48]
[same as prior period, unchanged from 0000858877-18-000004:mdna:47]

[0000858877-18-000007:mdna:49]
[same as prior period, unchanged from 0000858877-18-000004:mdna:48]

[0000858877-18-000007:mdna:50]
A reserve for future sales returns is established based on historical trends in product return rates. The reserve for future sales returns was $122 million as of each of April 28, 2018 and July 29, 2017, and was recorded as a reduction of our accounts receivable and revenue. If the actual future returns were to deviate from the historical data on which the reserve had been established, our revenue could be adversely affected.

[0000858877-18-000007:mdna:51]
[same as prior period, unchanged from 0000858877-18-000004:mdna:50]

[0000858877-18-000007:mdna:52]
[same as prior period, unchanged from 0000858877-18-000004:mdna:51]

[0000858877-18-000007:mdna:53]
We record a liability for firm, noncancelable, and unconditional purchase commitments with contract manufacturers and suppliers for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory.

[0000858877-18-000007:mdna:54]
[same as prior period, unchanged from 0000858877-18-000004:mdna:53]

[0000858877-18-000007:mdna:55]
[same as prior period, unchanged from 0000858877-18-000004:mdna:54]

[0000858877-18-000007:mdna:56]
Our provision for inventory was $42 million and $52 million for the first nine months of fiscal 2018 and 2017, respectively. The provision for the liability related to purchase commitments with contract manufacturers and suppliers was $77 million and $111 million for the first nine months of fiscal 2018 and 2017, respectively. If there were to be a sudden and significant decrease in demand for our products, or if there were a higher incidence of inventory obsolescence because of rapidly changing technology and customer requirements, we could be required to increase our inventory write-downs, and our liability for purchase commitments with contract manufacturers and suppliers, and accordingly our profitability, could be adversely affected. We regularly evaluate our exposure for inventory write-downs and the adequacy of our liability for purchase commitments. Inventory and supply chain management remain areas of focus as we balance the need to maintain supply chain flexibility to help ensure competitive lead times with the risk of inventory obsolescence, particularly in light of current macroeconomic uncertainties and conditions and the resulting potential for changes in future demand forecast.

[0000858877-18-000007:mdna:57]
Loss Contingencies and Product Warranties

[0000858877-18-000007:mdna:58]
We are subject to the possibility of various losses arising in the ordinary course of business. We consider the likelihood of impairment of an asset or the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated. We regularly evaluate information available to us to determine whether such accruals should be made or adjusted and whether new accruals are required.

[0000858877-18-000007:mdna:59]
Third parties, including customers, have in the past and may in the future assert claims or initiate litigation related to exclusive patent, copyright, trademark, and other intellectual property rights to technologies and related standards that are relevant to us. These assertions have increased over time as a result of our growth and the general increase in the pace of patent claims assertions, particularly in the United States. If any infringement or other intellectual property claim made against us by any third party is successful, or if we fail to develop non-infringing technology or license the proprietary rights on commercially reasonable terms and conditions, our business, operating results, and financial condition could be materially and adversely affected.

[0000858877-18-000007:mdna:60]
In fiscal 2014, we recorded a charge to product cost of sales of $655 million resulting from failures related to products containing memory components manufactured by a single supplier between 2005 and 2010. We perform regular assessments of the sufficiency of this liability and reduced the amount by $74 million and $164 million in fiscal 2016 and fiscal 2015, respectively based on updated analyses.  During the second quarter of fiscal 2017, we further reduced the liability by $141 million to reflect lower than expected defects, actual usage history, and estimated lower future remediation costs as more of the impacted products age and near the end of the support period covered by the remediation program. In addition, during the second quarter of fiscal 2017, we recorded a $125 million charge to product cost of sales related to the expected remediation costs for anticipated failures in future periods of a widely-used component sourced from a third party which is included in several of our products.  The liabilities related to the supplier component remediation matters as of April 28, 2018 and July 29, 2017 were $98 million and $174 million, respectively.

[0000858877-18-000007:mdna:61]
[same as prior period, unchanged from 0000858877-18-000004:mdna:60]

[0000858877-18-000007:mdna:62]
[same as prior period, unchanged from 0000858877-18-000004:mdna:61]

[0000858877-18-000007:mdna:63]
[same as prior period, unchanged from 0000858877-18-000004:mdna:62]

[0000858877-18-000007:mdna:64]
[same as prior period, unchanged from 0000858877-18-000004:mdna:63]

[0000858877-18-000007:mdna:65]
Our fixed income and publicly traded equity securities, collectively, are reflected in the Consolidated Balance Sheets at a fair value of $47.7 billion as of April 28, 2018, compared with $58.8 billion as of July 29, 2017. Our fixed income investment portfolio as of April 28, 2018 consisted primarily of high quality investment-grade securities. See Note 8 to the Consolidated Financial Statements.

[0000858877-18-000007:mdna:66]
[same as prior period, unchanged from 0000858877-18-000004:mdna:66]

[0000858877-18-000007:mdna:67]
[same as prior period, unchanged from 0000858877-18-000004:mdna:67]

[0000858877-18-000007:mdna:68]
[same as prior period, unchanged from 0000858877-18-000004:mdna:68]

[0000858877-18-000007:mdna:69]
[same as prior period, unchanged from 0000858877-18-000004:mdna:69]

[0000858877-18-000007:mdna:70]
The inputs and fair value are reviewed for reasonableness, may be further validated by comparison to publicly available information, and could be adjusted based on market indices or other information that management deems material to its estimate of fair value. The assessment of fair value can be difficult and subjective. However, given the relative reliability of the inputs we use to value our investment portfolio, and because substantially all of our valuation inputs are obtained using quoted market prices for similar or identical assets, we do not believe that the nature of estimates and assumptions affected by levels of subjectivity and judgment was material to the valuation of the investment portfolio as of April 28, 2018. Level 3 assets do not represent a significant portion of our total assets measured at fair value on a recurring basis as of April 28, 2018 and July 29, 2017.

[0000858877-18-000007:mdna:71]
[same as prior period, unchanged from 0000858877-18-000004:mdna:71]

[0000858877-18-000007:mdna:72]
[same as prior period, unchanged from 0000858877-18-000004:mdna:72]

[0000858877-18-000007:mdna:73]
[same as prior period, unchanged from 0000858877-18-000004:mdna:73]

[0000858877-18-000007:mdna:74]
[same as prior period, unchanged from 0000858877-18-000004:mdna:74]

[0000858877-18-000007:mdna:75]
We also have investments in privately held companies, some of which are in the startup or development stages. As of April 28, 2018, our investments in privately held companies were $969 million, compared with $983 million as of July 29, 2017, and were included in other assets. We monitor these investments for events or circumstances indicative of potential impairment, and we make appropriate reductions in carrying values if we determine that an impairment charge is required, based primarily on the financial condition and near-term prospects of these companies. These investments are inherently risky because the markets for the technologies or products these companies are developing are typically in the early stages and may never materialize.

[0000858877-18-000007:mdna:76]
[same as prior period, unchanged from 0000858877-18-000004:mdna:77]

[0000858877-18-000007:mdna:77]
[same as prior period, unchanged from 0000858877-18-000004:mdna:78]

[0000858877-18-000007:mdna:78]
[same as prior period, unchanged from 0000858877-18-000004:mdna:79]

[0000858877-18-000007:mdna:79]
[same as prior period, unchanged from 0000858877-18-000004:mdna:80]

[0000858877-18-000007:mdna:80]
The goodwill recorded in the Consolidated Balance Sheets as of April 28, 2018 and July 29, 2017 was $31.7 billion and $29.8 billion, respectively. In response to changes in industry and market conditions, we could be required to strategically realign our resources and consider restructuring, disposing of, or otherwise exiting businesses, which could result in an impairment of goodwill. There was no impairment of goodwill in each of the first nine months of fiscal 2018 and 2017.

[0000858877-18-000007:mdna:81]
[same as prior period, unchanged from 0000858877-18-000004:mdna:82]

[0000858877-18-000007:mdna:82]
[same as prior period, unchanged from 0000858877-18-000004:mdna:83]

[0000858877-18-000007:mdna:83]
Our impairment charges related to purchased intangible assets were $1 million and $42 million for the first nine months of fiscal 2018 and 2017, respectively. Our ongoing consideration of all the factors described previously could result in additional impairment charges in the future, which could adversely affect our net income.

[0000858877-18-000007:mdna:84]
[same as prior period, unchanged from 0000858877-18-000004:mdna:85]

[0000858877-18-000007:mdna:85]
We are subject to income taxes in the United States and numerous foreign jurisdictions. Our effective tax rates differ from the statutory rate, primarily due to the tax impact of state taxes, foreign operations, R&D tax credits, domestic manufacturing deductions, tax audit settlements, nondeductible compensation, international realignments, and transfer pricing adjustments. Our effective tax rate was 17.3% and 21.2% in the third quarter of fiscal 2018 and 2017, respectively. Our effective tax rate was 139.1% and 21.1% in the first nine months of fiscal 2018 and 2017, respectively.

[0000858877-18-000007:mdna:86]
The Tax Act, enacted on December 22, 2017, lowered the U.S. federal corporation income tax rate from 35% to 21% effective January 1, 2018, while also imposing a mandatory one-time transition tax on accumulated earnings of foreign subsidiaries. During the nine months ended April 28, 2018, we recorded a provisional tax expense of $11.1 billion related to the Tax Act, comprised of $8.9 billion of U.S. transition tax, $1.2 billion of foreign withholding tax and $1.0 billion of DTA re-measurement.

[0000858877-18-000007:mdna:87]
In December 2017, the Securities and Exchange Commission staff issued Staff Accounting Bulletin No. 118, which addresses how a company recognizes provisional estimates when a company does not have the necessary information available, prepared or analyzed (including computations) in reasonable detail to complete its accounting for the effect of the changes in the Tax Act. The measurement period ends when a company has obtained, prepared, and analyzed the information necessary to finalize its accounting, but cannot extend beyond one year. The final impact of the Tax Act may differ from the provisional estimates due to changes in interpretations of the Tax Act, any legislative action to address questions that arise because of the Tax Act, by changes in accounting standard for income taxes and related interpretations in response to the Tax Act, and any updates or changes to estimates used in the provisional amounts. We have determined that the $8.9 billion of tax expense for the U.S. transition tax on accumulated earnings of foreign subsidiaries, the $1.2 billion of foreign withholding tax, and the $1.0 billion of tax expense for DTA re-measurement were each provisional amounts and reasonable estimates as of April 28, 2018. Estimates used in the provisional amounts include: the anticipated reversal pattern of the gross DTAs; and earnings, cash positions, foreign taxes and withholding taxes attributable to foreign subsidiaries.

[0000858877-18-000007:mdna:88]
[same as prior period, unchanged from 0000858877-18-000004:mdna:89]

[0000858877-18-000007:mdna:89]
[same as prior period, unchanged from 0000858877-18-000004:mdna:90]

[0000858877-18-000007:mdna:90]
[same as prior period, unchanged from 0000858877-18-000004:mdna:91]

[0000858877-18-000007:mdna:91]
[same as prior period, unchanged from 0000858877-18-000004:mdna:92]

[0000858877-18-000007:mdna:92]
Our provision for income taxes is subject to volatility and could be adversely impacted by earnings being lower than anticipated in countries that have lower tax rates and higher than anticipated in countries that have higher tax rates; by changes in the valuation of our deferred tax assets and liabilities; by changes to domestic manufacturing deduction laws, regulations, or interpretations thereof; by expiration of or lapses in tax incentives; by transfer pricing adjustments, including the effect of acquisitions on our legal structure; by tax effects of nondeductible compensation; by tax costs related to intercompany realignments; by changes in accounting principles; or by changes in tax laws and regulations, treaties, or interpretations thereof, including changes to the taxation of earnings of our foreign subsidiaries, the deductibility of expenses attributable to foreign income, and the foreign tax credit rules. Significant judgment is required to determine the recognition and measurement attributes prescribed in the accounting guidance for uncertainty in income taxes. The Organisation for Economic Co-operation and Development (OECD), an international association comprised of 35 countries, including the United States, has made changes to numerous long-standing tax principles. There can be no assurance that these changes, once adopted by countries, will not have an adverse impact on our provision for income taxes. As a result of certain of our ongoing employment and capital investment actions and commitments, our income in certain countries is subject to reduced tax rates. Our failure to meet these commitments could adversely impact our provision for income taxes. In addition, we are subject to the continuous examination of our income tax returns by the Internal Revenue Service (IRS) and other tax authorities. We regularly assess the likelihood of adverse outcomes resulting from these examinations to determine the adequacy of our provision for income taxes. There can be no assurance that the outcomes from these continuous examinations will not have an adverse impact on our operating results and financial condition.

[0000858877-18-000007:mdna:93]
[same as prior period, unchanged from 0000858877-18-000004:mdna:94]

[0000858877-18-000007:mdna:94]
[same as prior period, unchanged from 0000858877-18-000004:mdna:95]

[0000858877-18-000007:mdna:95]
[same as prior period, unchanged from 0000858877-18-000004:mdna:96]

[0000858877-18-000007:mdna:96]
[same as prior period, unchanged from 0000858877-18-000004:mdna:97]

[0000858877-18-000007:mdna:97]
[same as prior period, unchanged from 0000858877-18-000004:mdna:98]

[0000858877-18-000007:mdna:98]
[same as prior period, unchanged from 0000858877-18-000004:mdna:99]

[0000858877-18-000007:mdna:99]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 28, 2018 |  | April 29, 2017 |  | Variancein Dollars |  | Variance in Percent |  | April 28, 2018 |  | April 29, 2017 |  | Variancein Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 9,304 |  |  | $ | 8,885 |  |  | $ | 419 |  |  | 5 | % |  | $ | 27,067 |  |  | $ | 26,678 |  |  | $ | 389 |  |  | 1 | % |
| Percentage of revenue |  | 74.7 | % |  | 74.4 | % |  |  |  |  |  |  |  | 74.2 | % |  | 74.4 | % |  |  |  |  |  |  |
| Service |  | 3,159 |  |  | 3,055 |  |  | 104 |  |  | 3 | % |  | 9,419 |  |  | 9,194 |  |  | 225 |  |  | 2 | % |
| Percentage of revenue |  | 25.3 | % |  | 25.6 | % |  |  |  |  |  |  |  | 25.8 | % |  | 25.6 | % |  |  |  |  |  |  |
| Total |  | $ | 12,463 |  |  | $ | 11,940 |  |  | $ | 523 |  |  | 4 | % |  | $ | 36,486 |  |  | $ | 35,872 |  |  | $ | 614 |  |  | 2 | % |

[0000858877-18-000007:mdna:100]
[same as prior period, unchanged from 0000858877-18-000004:mdna:101]

[0000858877-18-000007:mdna:101]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 28, 2018 |  | April 29, 2017 |  | Variancein Dollars |  | Variance in Percent |  | April 28, 2018 |  | April 29, 2017 |  | Variancein Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 7,161 |  |  | $ | 7,046 |  |  | $ | 115 |  |  | 2 | % |  | $ | 21,515 |  |  | $ | 21,149 |  |  | $ | 366 |  |  | 2 | % |
| Percentage of revenue |  | 57.5 | % |  | 59.0 | % |  |  |  |  |  | 59.0 | % |  | 59.0 | % |  |  |  |  |
| EMEA |  | 3,281 |  |  | 2,999 |  |  | 282 |  |  | 9 | % |  | 9,252 |  |  | 9,077 |  |  | 175 |  |  | 2 | % |
| Percentage of revenue |  | 26.3 | % |  | 25.1 | % |  |  |  |  |  | 25.3 | % |  | 25.3 | % |  |  |  |  |
| APJC |  | 2,021 |  |  | 1,895 |  |  | 126 |  |  | 7 | % |  | 5,719 |  |  | 5,646 |  |  | 73 |  |  | 1 | % |
| Percentage of revenue |  | 16.2 | % |  | 15.9 | % |  |  |  |  |  | 15.7 | % |  | 15.7 | % |  |  |  |  |
| Total |  | $ | 12,463 |  |  | $ | 11,940 |  |  | $ | 523 |  |  | 4 | % |  | $ | 36,486 |  |  | $ | 35,872 |  |  | $ | 614 |  |  | 2 | % |

[0000858877-18-000007:mdna:102]
Three Months Ended April 28, 2018 Compared with Three Months Ended April 29, 2017

[0000858877-18-000007:mdna:103]
Total revenue increased by 4%. Product revenue increased by 5% and service revenue increased by 3%. The increase in total revenue reflected growth across each of our geographic segments. The emerging countries of BRICM, in the aggregate, experienced 5% product revenue growth, with increases in Russia, Brazil, China and India partially offset by a decrease in Mexico.

[0000858877-18-000007:mdna:104]
[same as prior period, unchanged from 0000858877-18-000004:mdna:105]

[0000858877-18-000007:mdna:105]
Nine Months Ended April 28, 2018 Compared with Nine Months Ended April 29, 2017

[0000858877-18-000007:mdna:106]
Total revenue increased by 2%. Product revenue increased by 1% and service revenue increased by 2%. Our total revenue reflected growth across each of our geographic segments. Product revenue for the emerging countries of BRICM, in the aggregate, experienced 2% product revenue growth, with increases in Brazil, Russia and China partially offset by decreases in the other two BRICM countries.

[0000858877-18-000007:mdna:107]
57

[0000858877-18-000007:mdna:108]
[same as prior period, unchanged from 0000858877-18-000004:mdna:108]

[0000858877-18-000007:mdna:109]
[same as prior period, unchanged from 0000858877-18-000004:mdna:109]

[0000858877-18-000007:mdna:110]
[same as prior period, unchanged from 0000858877-18-000004:mdna:110]

[0000858877-18-000007:mdna:111]
[same as prior period, unchanged from 0000858877-18-000004:mdna:111]

[0000858877-18-000007:mdna:112]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 28, 2018 |  | April 29, 2017 |  | Variancein Dollars |  | Variance in Percent |  | April 28, 2018 |  | April 29, 2017 |  | Variancein Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 5,167 |  |  | $ | 5,094 |  |  | $ | 73 |  |  | 1 | % |  | $ | 15,547 |  |  | $ | 15,269 |  |  | $ | 278 |  |  | 2 | % |
| Percentage of product revenue |  | 55.5 | % |  | 57.3 | % |  |  |  |  |  | 57.5 | % |  | 57.2 | % |  |  |  |  |
| EMEA |  | 2,594 |  |  | 2,345 |  |  | 249 |  |  | 11 | % |  | 7,208 |  |  | 7,101 |  |  | 107 |  |  | 2 | % |
| Percentage of product revenue |  | 27.9 | % |  | 26.4 | % |  |  |  |  |  | 26.6 | % |  | 26.6 | % |  |  |  |  |
| APJC |  | 1,543 |  |  | 1,446 |  |  | 97 |  |  | 7 | % |  | 4,312 |  |  | 4,308 |  |  | 4 |  |  | — | % |
| Percentage of product revenue |  | 16.6 | % |  | 16.3 | % |  |  |  |  |  | 15.9 | % |  | 16.2 | % |  |  |  |  |
| Total |  | $ | 9,304 |  |  | $ | 8,885 |  |  | $ | 419 |  |  | 5 | % |  | $ | 27,067 |  |  | $ | 26,678 |  |  | $ | 389 |  |  | 1 | % |

[0000858877-18-000007:mdna:113]
[same as prior period, unchanged from 0000858877-18-000004:mdna:113]

[0000858877-18-000007:mdna:114]
Three Months Ended April 28, 2018 Compared with Three Months Ended April 29, 2017

[0000858877-18-000007:mdna:115]
Product revenue in the Americas segment increased by 1%, led by solid growth in the commercial market, partially offset by product revenue declines in the service provider and enterprise markets. Product revenue in the public sector market was flat. From a country perspective, product revenue increased by 16% in Canada and 22% in Brazil, partially offset by a decrease of 16% in Mexico.

[0000858877-18-000007:mdna:116]
Nine Months Ended April 28, 2018 Compared with Nine Months Ended April 29, 2017

[0000858877-18-000007:mdna:117]
The increase in product revenue in the Americas segment was led by solid growth in the commercial market and, to a lesser extent, growth in the public sector market. These increases were partially offset by a product revenue decline in the enterprise market. Product revenue in the service provider market was flat. From a country perspective, product revenue increased by 1% in the United States, 11% in Canada and 21% in Brazil, partially offset by a decrease of 16% in Mexico.

[0000858877-18-000007:mdna:118]
[same as prior period, unchanged from 0000858877-18-000004:mdna:118]

[0000858877-18-000007:mdna:119]
Three Months Ended April 28, 2018 Compared with Three Months Ended April 29, 2017

[0000858877-18-000007:mdna:120]
Product revenue in the EMEA segment increased by 11%, with solid growth across each of our customer markets. Product revenue from emerging countries within EMEA increased by 5% and product revenue for the remainder of the EMEA segment increased by 12%.

[0000858877-18-000007:mdna:121]
Nine Months Ended April 28, 2018 Compared with Nine Months Ended April 29, 2017

[0000858877-18-000007:mdna:122]
The increase in product revenue in the EMEA segment of 2% was driven by solid growth in the commercial and public sector markets. These increases were partially offset by a product revenue decline in the service provider market. Product revenue in the enterprise market was flat. Product revenue from emerging countries within EMEA increased by 2% and product revenue for the remainder of the EMEA segment increased by 1%.

[0000858877-18-000007:mdna:123]
[same as prior period, unchanged from 0000858877-18-000004:mdna:124]

[0000858877-18-000007:mdna:124]
[same as prior period, unchanged from 0000858877-18-000004:mdna:125]

[0000858877-18-000007:mdna:125]
[same as prior period, unchanged from 0000858877-18-000004:mdna:126]

[0000858877-18-000007:mdna:126]
Three Months Ended April 28, 2018 Compared with Three Months Ended April 29, 2017

[0000858877-18-000007:mdna:127]
Product revenue in the APJC segment increased by 7%. The product revenue increase was led by solid growth in the commercial and enterprise markets. These increases were partially offset by product revenue declines in the service provider and public sector markets. From a country perspective, product revenue increased by 12% in Australia, 4% in China, 4% in Japan and 5% in India.

[0000858877-18-000007:mdna:128]
Nine Months Ended April 28, 2018 Compared with Nine Months Ended April 29, 2017

[0000858877-18-000007:mdna:129]
Product revenue in the APJC segment was flat as product revenue growth in the commercial and enterprise markets was offset by product revenue declines in the service provider and public sector markets. From a country perspective, product revenue increased 3% in China while product revenue decreased by 9% in Japan and 2% in India.

[0000858877-18-000007:mdna:130]
[same as prior period, unchanged from 0000858877-18-000004:mdna:131]

[0000858877-18-000007:mdna:131]
[same as prior period, unchanged from 0000858877-18-000004:mdna:132]

[0000858877-18-000007:mdna:132]
[same as prior period, unchanged from 0000858877-18-000004:mdna:133]

[0000858877-18-000007:mdna:133]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 28, 2018 |  | April 29, 2017 |  | Variancein Dollars |  | Variance in Percent |  | April 28, 2018 |  | April 29, 2017 |  | Variancein Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Infrastructure Platforms |  | $ | 7,163 |  |  | $ | 6,992 |  |  | $ | 171 |  |  | 2 | % |  | $ | 20,827 |  |  | $ | 20,810 |  |  | $ | 17 |  |  | — | % |
| Applications |  | 1,309 |  |  | 1,100 |  |  | 209 |  |  | 19 | % |  | 3,696 |  |  | 3,352 |  |  | 344 |  |  | 10 | % |
| Security |  | 583 |  |  | 527 |  |  | 56 |  |  | 11 | % |  | 1,726 |  |  | 1,595 |  |  | 131 |  |  | 8 | % |
| Other Products |  | 249 |  |  | 266 |  |  | (17 | ) |  | (6 | )% |  | 818 |  |  | 921 |  |  | (103 | ) |  | (11 | )% |
| Total |  | $ | 9,304 |  |  | $ | 8,885 |  |  | $ | 419 |  |  | 5 | % |  | $ | 27,067 |  |  | $ | 26,678 |  |  | $ | 389 |  |  | 1 | % |

[0000858877-18-000007:mdna:134]
[same as prior period, unchanged from 0000858877-18-000004:mdna:135]

[0000858877-18-000007:mdna:135]
Three Months Ended April 28, 2018 Compared with Three Months Ended April 29, 2017

[0000858877-18-000007:mdna:136]
The Infrastructure Platforms product category represents our core networking offerings related to switching, routing, wireless, and the data center. Infrastructure Platforms revenue increased by 2%, or $171 million, with strength across the portfolio with the exception of routing. Switching returned to growth with revenue growth in our data center and campus switching. Revenue growth from our campus switching was driven by our intent-based networking Catalyst 9000 Series. We also experienced solid revenue growth from wireless products driven by Meraki as well as our Wave 2 offerings. Our revenue from data center had strong double digit growth driven by higher sales of server products and our hyperconverged data center offering, HyperFlex. We had a decrease in sales of routing products driven by continued weakness in the service provider market.

[0000858877-18-000007:mdna:137]
Nine Months Ended April 28, 2018 Compared with Nine Months Ended April 29, 2017

[0000858877-18-000007:mdna:138]
Revenue from the Infrastructure Platforms product category was flat as the increases in sales of switching, data center and wireless products were offset by the decreased revenue in routing. Within switching, we experienced an increase in sales of data center switches, driven by strength in our Application Centric Infrastructure (ACI) portfolio. Revenue from campus switching decreased modestly but we saw solid momentum with our intent-based networking Catalyst 9000 Series. We experienced strong revenue growth in our data center products driven by higher sales of server products and HyperFlex and solid revenue growth from wireless products. The decrease in routing revenue was driven by continued weakness in the service provider market and a slowdown in enterprise routing sales.

[0000858877-18-000007:mdna:139]
59

[0000858877-18-000007:mdna:140]
[same as prior period, unchanged from 0000858877-18-000004:mdna:140]

[0000858877-18-000007:mdna:141]
[same as prior period, unchanged from 0000858877-18-000004:mdna:141]

[0000858877-18-000007:mdna:142]
[same as prior period, unchanged from 0000858877-18-000004:mdna:142]

[0000858877-18-000007:mdna:143]
Three Months Ended April 28, 2018 Compared with Three Months Ended April 29, 2017

[0000858877-18-000007:mdna:144]
The Applications product category includes our collaboration offerings (unified communications, Cisco TelePresence and conferencing) as well as the Internet of Things (IoT) and analytics software offerings from AppDynamics and Jasper.  Revenue in our Applications product category increased by 19%, or $209 million, driven by increased revenue in Telepresence endpoints, unified communications infrastructure and analytics from our fiscal 2017 acquisition of AppDynamics.  We continue to increase the amount of deferred revenue and the proportion of recurring revenue related to our Applications product category.

[0000858877-18-000007:mdna:145]
Nine Months Ended April 28, 2018 Compared with Nine Months Ended April 29, 2017

[0000858877-18-000007:mdna:146]
Revenue in our Applications product category increased by 10%, or $344 million, with analytics from our fiscal 2017 acquisition of AppDynamics driving the majority of the increase along with revenue increases across our collaboration offerings.

[0000858877-18-000007:mdna:147]
[same as prior period, unchanged from 0000858877-18-000004:mdna:147]

[0000858877-18-000007:mdna:148]
Three Months Ended April 28, 2018 Compared with Three Months Ended April 29, 2017

[0000858877-18-000007:mdna:149]
Revenue in our Security product category increased 11%, or $56 million, driven by higher sales of unified threat management, advanced threat and web security products. We continue to increase the amount of deferred revenue and the proportion of recurring revenue related to our Security product category.

[0000858877-18-000007:mdna:150]
Nine Months Ended April 28, 2018 Compared with Nine Months Ended April 29, 2017

[0000858877-18-000007:mdna:151]
Revenue in our Security product category increased 8%, or $131 million, driven by higher sales of unified threat management, web security and advanced threat security products.

[0000858877-18-000007:mdna:152]
[same as prior period, unchanged from 0000858877-18-000004:mdna:152]

[0000858877-18-000007:mdna:153]
The decrease in revenue from our Other Products category for the third quarter and first nine months of fiscal 2018 as compared to the corresponding periods of fiscal 2017 was primarily driven by a decrease in revenue from Service Provider Video Software and Solutions (“SPVSS”).

[0000858877-18-000007:mdna:154]
On May 1, 2018, we announced a definitive agreement to sell the  SPVSS business.  We expect this transaction to close in the first quarter of fiscal 2019 subject to regulatory approvals and customary closing conditions.

[0000858877-18-000007:mdna:155]
[same as prior period, unchanged from 0000858877-18-000004:mdna:158]

[0000858877-18-000007:mdna:156]
[same as prior period, unchanged from 0000858877-18-000004:mdna:159]

[0000858877-18-000007:mdna:157]
[same as prior period, unchanged from 0000858877-18-000004:mdna:160]

[0000858877-18-000007:mdna:158]
[same as prior period, unchanged from 0000858877-18-000004:mdna:161]

[0000858877-18-000007:mdna:159]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 28, 2018 |  | April 29, 2017 |  | Variancein Dollars |  | Variance in Percent |  | April 28, 2018 |  | April 29, 2017 |  | Variancein Dollars |  | Variance in Percent |
| Service revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 1,994 |  |  | $ | 1,952 |  |  | $ | 42 |  |  | 2 | % |  | $ | 5,968 |  |  | $ | 5,880 |  |  | $ | 88 |  |  | 1 | % |
| Percentage of service revenue |  | 63.1 | % |  | 63.9 | % |  |  |  |  |  | 63.4 | % |  | 64.0 | % |  |  |  |  |
| EMEA |  | 687 |  |  | 654 |  |  | 33 |  |  | 5 | % |  | 2,044 |  |  | 1,976 |  |  | 68 |  |  | 3 | % |
| Percentage of service revenue |  | 21.8 | % |  | 21.4 | % |  |  |  |  |  | 21.7 | % |  | 21.5 | % |  |  |  |  |
| APJC |  | 478 |  |  | 449 |  |  | 29 |  |  | 6 | % |  | 1,407 |  |  | 1,338 |  |  | 69 |  |  | 5 | % |
| Percentage of service revenue |  | 15.1 | % |  | 14.7 | % |  |  |  |  |  | 14.9 | % |  | 14.5 | % |  |  |  |  |
| Total |  | $ | 3,159 |  |  | $ | 3,055 |  |  | $ | 104 |  |  | 3 | % |  | $ | 9,419 |  |  | $ | 9,194 |  |  | $ | 225 |  |  | 2 | % |

[0000858877-18-000007:mdna:160]
Three Months Ended April 28, 2018 Compared with Three Months Ended April 29, 2017

[0000858877-18-000007:mdna:161]
Service revenue increased 3%.  Technical support services revenue increased by 3% and advanced services revenue increased by 6%. Technical support services revenue had solid growth in the APJC and EMEA segments and increased modestly in our Americas segment. The increase in technical support services revenue was driven by an increase in software and solution support offerings. Advanced services revenue, which relates to professional services for specific customer network needs, had solid revenue growth in the EMEA and Americas segments and increased to a lesser extent in our APJC segment.

[0000858877-18-000007:mdna:162]
Nine Months Ended April 28, 2018 Compared with Nine Months Ended April 29, 2017

[0000858877-18-000007:mdna:163]
Service revenue increased across all geographic segments. Technical support services revenue increased by 2% and advanced services increased by 4%. Technical support services revenue had solid growth in APJC and increased to a lesser extent in our Americas and EMEA segments. Advanced services revenue had solid growth in the EMEA segment and increased to a lesser extent in our Americas and APJC segments.

[0000858877-18-000007:mdna:164]
[same as prior period, unchanged from 0000858877-18-000004:mdna:167]

[0000858877-18-000007:mdna:165]
[same as prior period, unchanged from 0000858877-18-000004:mdna:168]

[0000858877-18-000007:mdna:166]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | AMOUNT |  | PERCENTAGE |  | AMOUNT |  | PERCENTAGE |
|  |  | April 28, 2018 |  | April 29, 2017 |  | April 28, 2018 |  | April 29, 2017 |  | April 28, 2018 |  | April 29, 2017 |  | April 28, 2018 |  | April 29, 2017 |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 5,679 |  |  | $ | 5,480 |  |  | 61.0 | % |  | 61.7 | % |  | $ | 16,473 |  |  | $ | 16,565 |  |  | 60.9 | % |  | 62.1 | % |
| Service |  | 2,080 |  |  | 2,038 |  |  | 65.8 | % |  | 66.7 | % |  | 6,211 |  |  | 6,113 |  |  | 65.9 | % |  | 66.5 | % |
| Total |  | $ | 7,759 |  |  | $ | 7,518 |  |  | 62.3 | % |  | 63.0 | % |  | $ | 22,684 |  |  | $ | 22,678 |  |  | 62.2 | % |  | 63.2 | % |

[0000858877-18-000007:mdna:167]
61

[0000858877-18-000007:mdna:168]
[same as prior period, unchanged from 0000858877-18-000004:mdna:170]

[0000858877-18-000007:mdna:169]
[same as prior period, unchanged from 0000858877-18-000004:mdna:171]

[0000858877-18-000007:mdna:170]
[same as prior period, unchanged from 0000858877-18-000004:mdna:172]

[0000858877-18-000007:mdna:171]
The following table summarizes the key factors that contributed to the change in product gross margin percentage for the third quarter and first nine months of fiscal 2018 as compared with the corresponding prior year periods:

[0000858877-18-000007:mdna:172]
|  |  | Product Gross Margin Percentage |
|  |  | Three Months Ended |  | Nine Months Ended |
| Fiscal 2017 |  | 61.7 | % |  | 62.1 | % |
| Product pricing |  | (1.4 | )% |  | (1.5 | )% |
| Legal and indemnification settlements |  | — | % |  | (0.5 | )% |
| Amortization of purchased intangible assets |  | (0.4 | )% |  | (0.4 | )% |
| Mix of products sold |  | 0.1 | % |  | 0.2 | % |
| Productivity (1) |  | 1.1 | % |  | 0.9 | % |
| Other |  | (0.1 | )% |  | 0.1 | % |
| Fiscal 2018 |  | 61.0 | % |  | 60.9 | % |

[0000858877-18-000007:mdna:173]
[same as prior period, unchanged from 0000858877-18-000004:mdna:175]

[0000858877-18-000007:mdna:174]
Three Months Ended April 28, 2018 Compared with Three Months Ended April 29, 2017

[0000858877-18-000007:mdna:175]
Product gross margin decreased by 0.7 percentage points driven by unfavorable impacts from product pricing, higher memory costs and higher amortization expense from purchased intangible assets, partially offset by productivity improvements.

[0000858877-18-000007:mdna:176]
The negative pricing impact was driven by typical market factors and impacted each of our geographic segments and customer markets. Productivity improvements were driven by value engineering efforts (e.g. component redesign, board configuration, test processes, and transformation processes), lower warranty expenses and continued operational efficiency in manufacturing operations. Our productivity continued to be negatively impacted by an increase in the cost of certain memory components which are currently constrained. We expect the higher costs on these memory components to continue to impact productivity in the near term.

[0000858877-18-000007:mdna:177]
Nine Months Ended April 28, 2018 Compared with Nine Months Ended April 29, 2017

[0000858877-18-000007:mdna:178]
Product gross margin decreased by 1.2 percentage points due largely to unfavorable impacts from product pricing and a charge of $127 million to product cost of sales recorded in the first nine months of fiscal 2018 related to legal and indemnification settlements, partially offset by productivity benefits and a favorable product mix.

[0000858877-18-000007:mdna:179]
The negative pricing impact was driven by typical market factors and impacted each of our geographic segments and customer markets. While productivity was positive to overall product gross margin, the benefit was lower than the prior year as these improvements were adversely impacted by an increase in the cost of certain memory components which are currently constrained.  In addition, productivity was negatively impacted by decreases in revenue of certain Infrastructure Platforms offerings which limited our ability to generate cost savings. Productivity improvements were driven by value engineering efforts, lower warranty expenses and continued operational efficiency in manufacturing operations. Our product gross margin was also negatively impacted by higher amortization expense from purchased intangible assets.

[0000858877-18-000007:mdna:180]
62

[0000858877-18-000007:mdna:181]
[same as prior period, unchanged from 0000858877-18-000004:mdna:183]

[0000858877-18-000007:mdna:182]
[same as prior period, unchanged from 0000858877-18-000004:mdna:184]

[0000858877-18-000007:mdna:183]
[same as prior period, unchanged from 0000858877-18-000004:mdna:185]

[0000858877-18-000007:mdna:184]
Three Months Ended April 28, 2018 Compared with Three Months Ended April 29, 2017

[0000858877-18-000007:mdna:185]
Our service gross margin percentage decreased by 0.9 percentage points due to increased headcount-related costs and, to a lesser extent, unfavorable mix and increased delivery costs. These cost impacts were partially offset by the resulting benefit to gross margin of higher sales volume in both advanced services and technical support services.

[0000858877-18-000007:mdna:186]
[same as prior period, unchanged from 0000858877-18-000004:mdna:188]

[0000858877-18-000007:mdna:187]
Nine Months Ended April 28, 2018 Compared with Nine Months Ended April 29, 2017

[0000858877-18-000007:mdna:188]
Service gross margin percentage decreased by 0.6 percentage points due largely to increased headcount-related costs and, to a lesser extent, unfavorable mix and increased delivery costs. These cost impacts were partially offset by the resulting benefit to gross margin of higher sales volume in both advanced services and technical support services.

[0000858877-18-000007:mdna:189]
[same as prior period, unchanged from 0000858877-18-000004:mdna:191]

[0000858877-18-000007:mdna:190]
[same as prior period, unchanged from 0000858877-18-000004:mdna:192]

[0000858877-18-000007:mdna:191]
|  | Three Months Ended |  | Nine Months Ended |
|  | AMOUNT |  | PERCENTAGE |  | AMOUNT |  | PERCENTAGE |
|  | April 28, 2018 |  | April 29, 2017 |  | April 28, 2018 |  | April 29, 2017 |  | April 28, 2018 |  | April 29, 2017 |  | April 28, 2018 |  | April 29, 2017 |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 4,614 |  |  | $ | 4,551 |  |  | 64.4 | % |  | 64.6 | % |  | $ | 13,950 |  |  | $ | 13,672 |  |  | 64.8 | % |  | 64.6 | % |
| EMEA | 2,109 |  |  | 1,963 |  |  | 64.3 | % |  | 65.5 | % |  | 5,925 |  |  | 5,988 |  |  | 64.0 | % |  | 66.0 | % |
| APJC | 1,247 |  |  | 1,171 |  |  | 61.7 | % |  | 61.8 | % |  | 3,506 |  |  | 3,496 |  |  | 61.3 | % |  | 61.9 | % |
| Segment total | 7,970 |  |  | 7,685 |  |  | 63.9 | % |  | 64.4 | % |  | 23,381 |  |  | 23,156 |  |  | 64.1 | % |  | 64.6 | % |
| Unallocated corporate items (1) | (211 | ) |  | (167 | ) |  |  |  |  |  | (697 | ) |  | (478 | ) |  |  |  |  |
| Total | $ | 7,759 |  |  | $ | 7,518 |  |  | 62.3 | % |  | 63.0 | % |  | $ | 22,684 |  |  | $ | 22,678 |  |  | 62.2 | % |  | 63.2 | % |

[0000858877-18-000007:mdna:192]
(1) The unallocated corporate items include the effects of amortization and impairments of acquisition-related intangible assets, share-based compensation expense, significant litigation settlements and other contingencies, charges related to asset impairments and restructurings, and certain other charges. We do not allocate these items to the gross margin for each segment because management does not include such information in measuring the performance of the operating segments.

[0000858877-18-000007:mdna:193]
Three Months Ended April 28, 2018 Compared with Three Months Ended April 29, 2017

[0000858877-18-000007:mdna:194]
The Americas segment experienced a slight gross margin percentage decrease due to negative impacts from pricing and product mix, partially offset by productivity improvements. The unfavorable mix impact was driven by our products within the Infrastructure Platforms product category.

[0000858877-18-000007:mdna:195]
[same as prior period, unchanged from 0000858877-18-000004:mdna:197]

[0000858877-18-000007:mdna:196]
Our APJC segment gross margin percentage decreased slightly due primarily to lower service gross margin. Product gross margin in this segment increased due to productivity improvements and favorable mix, partially offset by negative impacts from pricing.

[0000858877-18-000007:mdna:197]
[same as prior period, unchanged from 0000858877-18-000004:mdna:200]

[0000858877-18-000007:mdna:198]
[same as prior period, unchanged from 0000858877-18-000004:mdna:201]

[0000858877-18-000007:mdna:199]
Nine Months Ended April 28, 2018 Compared with Nine Months Ended April 29, 2017

[0000858877-18-000007:mdna:200]
We experienced a slight gross margin percentage increase in our Americas segment due to productivity improvements partially offset by unfavorable impacts from pricing.

[0000858877-18-000007:mdna:201]
The gross margin percentage decrease in our EMEA segment was due primarily to the negative impacts from pricing and an unfavorable product mix partially offset by productivity improvements. Lower service gross margin also contributed to the decrease in the gross margin in this geographic segment.

[0000858877-18-000007:mdna:202]
The APJC segment gross margin percentage decreased due primarily to negative impacts from pricing and, to a lesser extent, an unfavorable product mix, partially offset by productivity improvements. Lower service gross margin also contributed to the decrease in the gross margin in this geographic segment.

[0000858877-18-000007:mdna:203]
[same as prior period, unchanged from 0000858877-18-000004:mdna:206]

[0000858877-18-000007:mdna:204]
[same as prior period, unchanged from 0000858877-18-000004:mdna:207]

[0000858877-18-000007:mdna:205]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 28, 2018 |  | April 29, 2017 |  | Variancein Dollars |  | Variance in Percent |  | April 28, 2018 |  | April 29, 2017 |  | Variancein Dollars |  | Variance in Percent |
| Research and development | $ | 1,590 |  |  | $ | 1,507 |  |  | $ | 83 |  |  | 6 | % |  | $ | 4,706 |  |  | $ | 4,560 |  |  | $ | 146 |  |  | 3 | % |
| Percentage of revenue | 12.8 | % |  | 12.6 | % |  |  |  |  |  | 12.9 | % |  | 12.7 | % |  |  |  |  |
| Sales and marketing | 2,325 |  |  | 2,226 |  |  | 99 |  |  | 4 | % |  | 6,894 |  |  | 6,866 |  |  | 28 |  |  | — | % |
| Percentage of revenue | 18.7 | % |  | 18.6 | % |  |  |  |  |  | 18.9 | % |  | 19.1 | % |  |  |  |  |
| General and administrative | 561 |  |  | 487 |  |  | 74 |  |  | 15 | % |  | 1,601 |  |  | 1,498 |  |  | 103 |  |  | 7 | % |
| Percentage of revenue | 4.5 | % |  | 4.1 | % |  |  |  |  |  | 4.4 | % |  | 4.2 | % |  |  |  |  |
| Total | $ | 4,476 |  |  | $ | 4,220 |  |  | $ | 256 |  |  | 6 | % |  | $ | 13,201 |  |  | $ | 12,924 |  |  | $ | 277 |  |  | 2 | % |
| Percentage of revenue | 35.9 | % |  | 35.3 | % |  |  |  |  |  | 36.2 | % |  | 36.0 | % |  |  |  |  |

[0000858877-18-000007:mdna:206]
[same as prior period, unchanged from 0000858877-18-000004:mdna:209]

[0000858877-18-000007:mdna:207]
R&D expenses increased in the third quarter of fiscal 2018, as compared with the third quarter of fiscal 2017, primarily due to higher headcount-related expenses, higher discretionary spending and, to a lesser extent, higher acquisition-related costs and higher share-based compensation expense, partially offset by lower contracted services.

[0000858877-18-000007:mdna:208]
R&D expenses increased in the first nine months of fiscal 2018, as compared with the first nine months of fiscal 2017, primarily due to higher headcount-related expenses, higher discretionary spending and, to a lesser extent, higher share-based compensation expense, partially offset by lower contracted services and lower acquisition-related costs.

[0000858877-18-000007:mdna:209]
[same as prior period, unchanged from 0000858877-18-000004:mdna:211]

[0000858877-18-000007:mdna:210]
[same as prior period, unchanged from 0000858877-18-000004:mdna:212]

[0000858877-18-000007:mdna:211]
Sales and marketing expenses increased in the third quarter of fiscal 2018, as compared with the third quarter of fiscal 2017, due to increases in headcount-related expenses, discretionary spending and contracted services and, to a lesser extent, higher share-based compensation expense and higher acquisition-related costs.

[0000858877-18-000007:mdna:212]
Sales and marketing expenses were flat in the first nine months of fiscal 2018, as compared with the first nine months of fiscal 2017, as the increases in headcount-related expenses, share-based compensation expense and acquisition-related costs substantially offset decreases in contracted services and discretionary spending.

[0000858877-18-000007:mdna:213]
[same as prior period, unchanged from 0000858877-18-000004:mdna:215]

[0000858877-18-000007:mdna:214]
G&A expenses increased in the third quarter of fiscal 2018, as compared with the third quarter of fiscal 2017, due to increases in headcount-related expenses, acquisition-related/divestiture costs, contracted services and discretionary spending, partially offset by lower share-based compensation expense.

[0000858877-18-000007:mdna:215]
[same as prior period, unchanged from 0000858877-18-000004:mdna:219]

[0000858877-18-000007:mdna:216]
[same as prior period, unchanged from 0000858877-18-000004:mdna:220]

[0000858877-18-000007:mdna:217]
G&A expenses increased in the first nine months of fiscal 2018, as compared with the first nine months of fiscal 2017, due to increases in acquisition-related/divestiture costs, contracted services, discretionary spending, headcount-related expenses and share-based compensation expense, partially offset by gains on divestitures.

[0000858877-18-000007:mdna:218]
[same as prior period, unchanged from 0000858877-18-000004:mdna:221]

[0000858877-18-000007:mdna:219]
In the third quarter of fiscal 2018, foreign currency fluctuations, net of hedging, increased the combined R&D, sales and marketing, and G&A expenses by approximately $52 million, or 1.2%, compared with the third quarter of fiscal 2017.

[0000858877-18-000007:mdna:220]
In the first nine months of fiscal 2018, foreign currency fluctuations, net of hedging, increased the combined R&D, sales and marketing, and G&A expenses by approximately $93 million, or 0.7%, compared with the first nine months of fiscal 2017.

[0000858877-18-000007:mdna:221]
[same as prior period, unchanged from 0000858877-18-000004:mdna:224]

[0000858877-18-000007:mdna:222]
[same as prior period, unchanged from 0000858877-18-000004:mdna:225]

[0000858877-18-000007:mdna:223]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 28, 2018 |  | April 29, 2017 |  | April 28, 2018 |  | April 29, 2017 |
| Cost of sales—product |  | $ | 24 |  |  | $ | 22 |  |  | $ | 70 |  |  | $ | 62 |  |
| Cost of sales—service |  | 33 |  |  | 34 |  |  | 98 |  |  | 101 |  |
| Share-based compensation expense in cost of sales |  | 57 |  |  | 56 |  |  | 168 |  |  | 163 |  |
| Research and development |  | 139 |  |  | 137 |  |  | 409 |  |  | 392 |  |
| Sales and marketing |  | 142 |  |  | 133 |  |  | 412 |  |  | 398 |  |
| General and administrative |  | 61 |  |  | 79 |  |  | 189 |  |  | 173 |  |
| Restructuring and other charges |  | 6 |  |  | (5 | ) |  | 24 |  |  | (2 | ) |
| Share-based compensation expense in operating expenses |  | 348 |  |  | 344 |  |  | 1,034 |  |  | 961 |  |
| Total share-based compensation expense |  | $ | 405 |  |  | $ | 400 |  |  | $ | 1,202 |  |  | $ | 1,124 |  |

[0000858877-18-000007:mdna:224]
The increase in share-based compensation expense in the third quarter and first nine months of fiscal 2018, as compared with the corresponding periods of fiscal 2017, was due primarily to higher restructuring charges and higher expense related to equity awards assumed with respect to our recent acquisitions.

[0000858877-18-000007:mdna:225]
[same as prior period, unchanged from 0000858877-18-000004:mdna:228]

[0000858877-18-000007:mdna:226]
[same as prior period, unchanged from 0000858877-18-000004:mdna:229]

[0000858877-18-000007:mdna:227]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 28, 2018 |  | April 29, 2017 |  | April 28, 2018 |  | April 29, 2017 |
| Amortization of purchased intangible assets: |  |  |  |  |  |  |  |  |
| Cost of sales |  | $ | 177 |  |  | $ | 141 |  |  | $ | 491 |  |  | $ | 394 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Amortization of purchased intangible assets |  | 67 |  |  | 59 |  |  | 188 |  |  | 201 |  |
| Restructuring and other charges |  | — |  |  | — |  |  | — |  |  | 38 |  |
| Total |  | $ | 244 |  |  | $ | 200 |  |  | $ | 679 |  |  | $ | 633 |  |

[0000858877-18-000007:mdna:228]
Amortization of purchased intangible assets increased for the third quarter of fiscal 2018, as compared with the third quarter of fiscal 2017, due to amortization of purchased intangible assets from our recent acquisitions.

[0000858877-18-000007:mdna:229]
Amortization of purchased intangible assets increased for the first nine months of fiscal 2018, as compared with the first nine months of fiscal 2017, due to amortization of purchased intangible assets from our recent acquisitions, partially offset by the impact of the impairment charges in the prior period.

[0000858877-18-000007:mdna:230]
[same as prior period, unchanged from 0000858877-18-000004:mdna:234]

[0000858877-18-000007:mdna:231]
[same as prior period, unchanged from 0000858877-18-000004:mdna:235]

[0000858877-18-000007:mdna:232]
[same as prior period, unchanged from 0000858877-18-000004:mdna:236]

[0000858877-18-000007:mdna:233]
Fiscal 2018 Plan. We initiated a restructuring plan in the third quarter of fiscal 2018 in order to realign our organization and enable further investment in key priority areas, with estimated pretax charges of approximately $300 million. In connection with this restructuring plan, we incurred charges of $82 million in the third quarter and first nine months of fiscal 2018. These aggregate pretax charges are primarily cash based and consist of employee severance and other one-time termination benefits, and other associated costs. We expect this restructuring plan to be substantially completed in fiscal 2019.

[0000858877-18-000007:mdna:234]
Fiscal 2017 Plan. In the third quarter and first nine months of fiscal 2017, we incurred restructuring and other charges of $70 million and $614 million, respectively, which were related primarily to employee severance charges for employees impacted by the restructuring action announced in August 2016. We extended this restructuring action to include an additional $150 million of estimated additional pretax charges for employee severance and other one-time termination benefits. We have completed this restructuring action and have incurred cumulative charges of $1.0 billion as of April 28, 2018.

[0000858877-18-000007:mdna:235]
We expect to reinvest substantially all of the cost savings from these restructuring actions in our key priority areas.  As a result, the overall cost savings from these restructuring actions are not expected to be material for future periods.

[0000858877-18-000007:mdna:236]
[same as prior period, unchanged from 0000858877-18-000004:mdna:239]

[0000858877-18-000007:mdna:237]
[same as prior period, unchanged from 0000858877-18-000004:mdna:240]

[0000858877-18-000007:mdna:238]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 28, 2018 |  | April 29, 2017 |  | April 28, 2018 |  | April 29, 2017 |
| Operating income |  | $ | 3,134 |  |  | $ | 3,169 |  |  | $ | 8,963 |  |  | $ | 8,939 |  |
| Operating income as a percentage of revenue |  | 25.1 | % |  | 26.5 | % |  | 24.6 | % |  | 24.9 | % |

[0000858877-18-000007:mdna:239]
For the third quarter of fiscal 2018, as compared with the third quarter of fiscal 2017, operating income decreased by 1% and as a percentage of revenue operating income decreased by 1.4 percentage points. These decreases resulted primarily from a gross margin percentage decrease and an increase in operating expenses.

[0000858877-18-000007:mdna:240]
For the first nine months of fiscal 2018, as compared with the first nine months of fiscal 2017, operating income was flat and as a percentage of revenue operating income decreased by 0.3 percentage points. These changes resulted primarily from a gross margin percentage decrease (driven primarily by unfavorable impacts from pricing and a charge of $127 million for legal and indemnification settlements partially offset by productivity benefits) and a decrease in restructuring and other charges.

[0000858877-18-000007:mdna:241]
[same as prior period, unchanged from 0000858877-18-000004:mdna:244]

[0000858877-18-000007:mdna:242]
[same as prior period, unchanged from 0000858877-18-000004:mdna:245]

[0000858877-18-000007:mdna:243]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 28, 2018 |  | April 29, 2017 |  | Variancein Dollars |  | April 28, 2018 |  | April 29, 2017 |  | Variancein Dollars |
| Interest income |  | $ | 380 |  |  | $ | 354 |  |  | $ | 26 |  |  | $ | 1,155 |  |  | $ | 978 |  |  | $ | 177 |  |
| Interest expense |  | (237 | ) |  | (219 | ) |  | (18 | ) |  | (719 | ) |  | (639 | ) |  | (80 | ) |
| Interest income (expense), net |  | $ | 143 |  |  | $ | 135 |  |  | $ | 8 |  |  | $ | 436 |  |  | $ | 339 |  |  | $ | 97 |  |

[0000858877-18-000007:mdna:244]
Interest income increased driven by higher yields on our portfolio. The increase in interest expense was driven by the impact of higher effective interest rates.

[0000858877-18-000007:mdna:245]
[same as prior period, unchanged from 0000858877-18-000004:mdna:248]

[0000858877-18-000007:mdna:246]
[same as prior period, unchanged from 0000858877-18-000004:mdna:249]

[0000858877-18-000007:mdna:247]
[same as prior period, unchanged from 0000858877-18-000004:mdna:250]

[0000858877-18-000007:mdna:248]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 28, 2018 |  | April 29, 2017 |  | Variancein Dollars |  | April 28, 2018 |  | April 29, 2017 |  | Variancein Dollars |
| Gains (losses) on investments, net: |  |  |  |  |  |  |  |  |  |  |  |  |
| Publicly traded equity securities |  | $ | 56 |  |  | $ | (59 | ) |  | $ | 115 |  |  | $ | 239 |  |  | $ | (50 | ) |  | $ | 289 |  |
| Fixed income securities |  | (39 | ) |  | (17 | ) |  | (22 | ) |  | (131 | ) |  | (41 | ) |  | (90 | ) |
| Total available-for-sale investments |  | 17 |  |  | (76 | ) |  | 93 |  |  | 108 |  |  | (91 | ) |  | 199 |  |
| Privately held companies |  | (11 | ) |  | — |  |  | (11 | ) |  | 26 |  |  | (53 | ) |  | 79 |  |
| Net gains (losses) on investments |  | 6 |  |  | (76 | ) |  | 82 |  |  | 134 |  |  | (144 | ) |  | 278 |  |
| Other gains (losses), net |  | (30 | ) |  | (37 | ) |  | 7 |  |  | (86 | ) |  | (27 | ) |  | (59 | ) |
| Other income (loss), net |  | $ | (24 | ) |  | $ | (113 | ) |  | $ | 89 |  |  | $ | 48 |  |  | $ | (171 | ) |  | $ | 219 |  |

[0000858877-18-000007:mdna:249]
Three Months Ended April 28, 2018 Compared with Three Months Ended April 29, 2017

[0000858877-18-000007:mdna:250]
The change in total net gains (losses) on available-for-sale investments was primarily attributable to higher realized gains on publicly traded equity securities and lower impairment charges on publicly traded equity securities, partially offset by higher realized losses on fixed income securities as a result of market conditions and the timing of sales of these securities.

[0000858877-18-000007:mdna:251]
The change in net gains (losses) on investments in privately held companies was primarily due to lower realized gains on investments in privately held companies partially offset by lower impairment charges on investments in privately held companies.

[0000858877-18-000007:mdna:252]
The change in other gains (losses), net was primarily driven by net favorable foreign exchange impacts partially offset by higher donations.

[0000858877-18-000007:mdna:253]
Nine Months Ended April 28, 2018 Compared with Nine Months Ended April 29, 2017

[0000858877-18-000007:mdna:254]
The change in total net gains (losses) on available-for-sale investments was primarily attributable to higher realized gains on publicly traded equity securities and lower impairment charges on publicly traded equity securities, partially offset by higher realized losses on fixed income securities as a result of market conditions and the timing of sales of these securities.

[0000858877-18-000007:mdna:255]
The change in net gains (losses) on investments in privately held companies was primarily due to lower impairment charges partially offset by lower realized gains on investments in privately held companies.

[0000858877-18-000007:mdna:256]
The change in other gains (losses), net was primarily driven by higher donations, impacts from equity derivatives and net unfavorable foreign exchange impacts.

[0000858877-18-000007:mdna:257]
[same as prior period, unchanged from 0000858877-18-000004:mdna:260]

[0000858877-18-000007:mdna:258]
[same as prior period, unchanged from 0000858877-18-000004:mdna:261]

[0000858877-18-000007:mdna:259]
[same as prior period, unchanged from 0000858877-18-000004:mdna:262]

[0000858877-18-000007:mdna:260]
[same as prior period, unchanged from 0000858877-18-000004:mdna:263]

[0000858877-18-000007:mdna:261]
[same as prior period, unchanged from 0000858877-18-000004:mdna:264]

[0000858877-18-000007:mdna:262]
[same as prior period, unchanged from 0000858877-18-000004:mdna:265]

[0000858877-18-000007:mdna:263]
As of December 31, 2017, we had approximately $75 billion in undistributed earnings for certain foreign subsidiaries. These undistributed earnings are subject to the U.S. mandatory one-time transition tax and are eligible to be repatriated to the U.S. without additional U.S. tax under the Tax Act. We have historically asserted our intention to indefinitely reinvest foreign earnings in certain foreign subsidiaries. We have reevaluated our historic assertion as a result of enactment of the Tax Act and no longer consider these earnings to be indefinitely reinvested in our foreign subsidiaries.  As a result of this change in assertion, we recorded a $1.2 billion tax expense for foreign withholding tax in the second quarter of fiscal 2018.  In the third quarter of fiscal 2018, we repatriated $67 billion of foreign subsidiary earnings to the U.S. and paid foreign withholding tax of $1.2 billion. We also paid approximately $100 million of other one-time foreign taxes as a result of the Tax Act.

[0000858877-18-000007:mdna:264]
In the third quarter of fiscal 2018, the Company recorded adjustments to the provisional amounts related to the U.S. transition tax on accumulated earnings of foreign subsidiaries and re-measurement of net DTA. During the nine months ended April 28, 2018, we recorded a provisional tax expense of $11.1 billion related to the Tax Act, comprised of $8.9 billion of U.S. transition tax, $1.2 billion of foreign withholding tax (discussed above), and $1.0 billion re-measurement of net DTA. We plan to pay the transition tax in installments over eight years in accordance with the Tax Act. The $1.2 billion foreign withholding tax was paid in February 2018. The Tax Act is discussed more fully in Note 16 to the Consolidated Financial Statements.

[0000858877-18-000007:mdna:265]
The provision for income taxes resulted in an effective tax rate of 17.3% for the third quarter of fiscal 2018 compared with 21.2% for the third quarter of fiscal 2017, a net 3.9 percentage point decrease for the third quarter of fiscal 2018 as compared with the third quarter of fiscal 2017.  The decrease in the effective tax rate was primarily due to a decrease in the provisional one-time transition tax on accumulated earnings of foreign subsidiaries and a provision to tax return true-up tax benefit related to the U.S. federal research tax credit in the third quarter of fiscal 2018 as compared to the third quarter of fiscal 2017.

[0000858877-18-000007:mdna:266]
The provision for income taxes resulted in an effective tax rate of 139.1% for the first nine months of fiscal 2018 as compared with 21.1% for the first nine months of fiscal 2017, a net 118.0 percentage point increase for the first nine months of fiscal 2018 as compared with the first nine months of fiscal 2017. The increase in the effective tax rate was primarily due to the mandatory one-time transition tax on accumulated earnings of foreign subsidiaries, foreign withholding tax, and DTA re-measurement during the first nine months of fiscal 2018.

[0000858877-18-000007:mdna:267]
[same as prior period, unchanged from 0000858877-18-000004:mdna:269]

[0000858877-18-000007:mdna:268]
[same as prior period, unchanged from 0000858877-18-000004:mdna:270]

[0000858877-18-000007:mdna:269]
[same as prior period, unchanged from 0000858877-18-000004:mdna:271]

[0000858877-18-000007:mdna:270]
[same as prior period, unchanged from 0000858877-18-000004:mdna:272]

[0000858877-18-000007:mdna:271]
[same as prior period, unchanged from 0000858877-18-000004:mdna:273]

[0000858877-18-000007:mdna:272]
[same as prior period, unchanged from 0000858877-18-000004:mdna:274]

[0000858877-18-000007:mdna:273]
[same as prior period, unchanged from 0000858877-18-000004:mdna:275]

[0000858877-18-000007:mdna:274]
[same as prior period, unchanged from 0000858877-18-000004:mdna:276]

[0000858877-18-000007:mdna:275]
|  | April 28, 2018 |  | July 29, 2017 |  | Increase (Decrease) |
| Cash and cash equivalents | $ | 6,719 |  |  | $ | 11,708 |  |  | $ | (4,989 | ) |
| Fixed income securities | 46,387 |  |  | 57,077 |  |  | (10,690 | ) |
| Publicly traded equity securities | 1,325 |  |  | 1,707 |  |  | (382 | ) |
| Total | $ | 54,431 |  |  | $ | 70,492 |  |  | $ | (16,061 | ) |

[0000858877-18-000007:mdna:276]
The decrease in cash and cash equivalents and investments in the first nine months of fiscal 2018 was primarily driven by cash returned to shareholders in the form of repurchases of common stock of $11.6 billion under the stock repurchase program and cash dividends of $4.4 billion; a net decrease in debt of $5.5 billion; net cash paid for acquisitions of $2.8 billion; and capital expenditures of $0.6 billion. These uses of cash were partially offset by cash provided by operating activities of $9.6 billion.

[0000858877-18-000007:mdna:277]
Our total in cash and cash equivalents and investments held by various foreign subsidiaries was $6.9 billion and $67.5 billion as of April 28, 2018 and July 29, 2017, respectively. The balance of cash and cash equivalents and investments available in the United States as of April 28, 2018 and July 29, 2017 was $47.5 billion and $3.0 billion, respectively.

[0000858877-18-000007:mdna:278]
During the nine months ended April 28, 2018, as a result of the Tax Act, all historical undistributed foreign subsidiary earnings through December 31, 2017 were subject to a mandatory one-time transition tax, which resulted in a provisional tax expense of $8.9 billion. We plan to pay the transition tax in installments over eight years in accordance with the Tax Act. Approximately $0.7 billion is payable in less than one year; $1.4 billion is payable between 1 to 3 years; another $1.4 billion is payable between 3 to 5 years; and the remaining $5.4 billion is payable in more than 5 years. In the third quarter of fiscal 2018, we repatriated $67 billion of historical undistributed foreign subsidiary earnings to the U.S. and paid foreign withholding tax of $1.2 billion. We also paid approximately $100 million of other one-time foreign taxes as a result of the Tax Act. Future repatriation of cash and other property held by our foreign subsidiaries will generally not be subject to U.S. federal tax. As we evaluate the impact of the Tax Act and the future cash needs of our global operations, we may revise the amount of foreign earnings considered to be permanently reinvested in our foreign subsidiaries.

[0000858877-18-000007:mdna:279]
[same as prior period, unchanged from 0000858877-18-000004:mdna:281]

[0000858877-18-000007:mdna:280]
69

[0000858877-18-000007:mdna:281]
[same as prior period, unchanged from 0000858877-18-000004:mdna:282]

[0000858877-18-000007:mdna:282]
[same as prior period, unchanged from 0000858877-18-000004:mdna:283]

[0000858877-18-000007:mdna:283]
[same as prior period, unchanged from 0000858877-18-000004:mdna:284]

[0000858877-18-000007:mdna:284]
[same as prior period, unchanged from 0000858877-18-000004:mdna:285]

[0000858877-18-000007:mdna:285]
|  | Nine Months Ended |
|  | April 28, 2018 |  | April 29, 2017 |
| Net cash provided by operating activities | $ | 9,566 |  |  | $ | 9,875 |  |
| Acquisition of property and equipment | (620 | ) |  | (756 | ) |
| Free cash flow | $ | 8,946 |  |  | $ | 9,119 |  |

[0000858877-18-000007:mdna:286]
[same as prior period, unchanged from 0000858877-18-000004:mdna:287]

[0000858877-18-000007:mdna:287]
[same as prior period, unchanged from 0000858877-18-000004:mdna:288]

[0000858877-18-000007:mdna:288]
[same as prior period, unchanged from 0000858877-18-000004:mdna:289]

[0000858877-18-000007:mdna:289]
|  |  | DIVIDENDS |  | STOCK REPURCHASE PROGRAM |  |  |
| Quarter Ended |  | Per Share |  | Amount |  | Shares |  | Weighted-Average Price per Share |  | Amount |  | TOTAL |
| Fiscal 2018 |  |  |  |  |  |  |  |  |  |  |  |  |
| April 28, 2018 |  | $ | 0.33 |  |  | $ | 1,572 |  |  | 140 |  |  | $ | 42.83 |  |  | $ | 6,015 |  |  | $ | 7,587 |  |
| January 27, 2018 |  | $ | 0.29 |  |  | $ | 1,425 |  |  | 103 |  |  | $ | 39.07 |  |  | $ | 4,011 |  |  | $ | 5,436 |  |
| October 28, 2017 |  | $ | 0.29 |  |  | $ | 1,436 |  |  | 51 |  |  | $ | 31.80 |  |  | $ | 1,620 |  |  | $ | 3,056 |  |
| Fiscal 2017 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| July 29, 2017 |  | $ | 0.29 |  |  | $ | 1,448 |  |  | 38 |  |  | $ | 31.61 |  |  | $ | 1,201 |  |  | $ | 2,649 |  |
| April 29, 2017 |  | $ | 0.29 |  |  | $ | 1,451 |  |  | 15 |  |  | $ | 33.71 |  |  | $ | 503 |  |  | $ | 1,954 |  |
| January 28, 2017 |  | $ | 0.26 |  |  | $ | 1,304 |  |  | 33 |  |  | $ | 30.33 |  |  | $ | 1,001 |  |  | $ | 2,305 |  |
| October 29, 2016 |  | $ | 0.26 |  |  | $ | 1,308 |  |  | 32 |  |  | $ | 31.12 |  |  | $ | 1,001 |  |  | $ | 2,309 |  |

[0000858877-18-000007:mdna:290]
Any future dividends are subject to the approval of our Board of Directors.

[0000858877-18-000007:mdna:291]
On February 14, 2018, our Board of Directors authorized a $25 billion increase to the stock repurchase program. The remaining authorized amount for stock repurchases under this program, including the additional authorization, is approximately $25.1 billion, with no termination date.  We expect to utilize this remaining authorized amount for stock repurchases over the next 15 to 21 months.

[0000858877-18-000007:mdna:292]
70

[0000858877-18-000007:mdna:293]
[same as prior period, unchanged from 0000858877-18-000004:mdna:293]

[0000858877-18-000007:mdna:294]
[same as prior period, unchanged from 0000858877-18-000004:mdna:294]

[0000858877-18-000007:mdna:295]
[same as prior period, unchanged from 0000858877-18-000004:mdna:295]

[0000858877-18-000007:mdna:296]
|  | April 28, 2018 |  | July 29, 2017 |  | Increase (Decrease) |
| Accounts receivable, net | $ | 4,274 |  |  | $ | 5,146 |  |  | $ | (872 | ) |

[0000858877-18-000007:mdna:297]
Our accounts receivable net, as of April 28, 2018 decreased by approximately 17%, as compared with the end of fiscal 2017, primarily due to product billings being more linear and the amount and timing of service billings in the third quarter of fiscal 2018 compared with the fourth quarter of fiscal 2017.

[0000858877-18-000007:mdna:298]
[same as prior period, unchanged from 0000858877-18-000004:mdna:298]

[0000858877-18-000007:mdna:299]
|  | April 28, 2018 |  | July 29, 2017 |  | Increase (Decrease) |
| Inventories | $ | 1,900 |  |  | $ | 1,616 |  |  | $ | 284 |  |

[0000858877-18-000007:mdna:300]
Inventory as of April 28, 2018 increased by 18% from our inventory balance at the end of fiscal 2017. The increase in inventory was due to higher levels of manufactured finished goods in support of current order activity and an increase in raw materials due to securing memory supply which is currently constrained.

[0000858877-18-000007:mdna:301]
[same as prior period, unchanged from 0000858877-18-000004:mdna:301]

[0000858877-18-000007:mdna:302]
[same as prior period, unchanged from 0000858877-18-000004:mdna:302]

[0000858877-18-000007:mdna:303]
| Commitments by Period | April 28, 2018 |  | July 29, 2017 |
| Less than 1 year | $ | 5,077 |  |  | $ | 4,620 |  |
| 1 to 3 years | 700 |  |  | 20 |  |
| 3 to 5 years | 450 |  |  | — |  |
| Total | $ | 6,227 |  |  | $ | 4,640 |  |

[0000858877-18-000007:mdna:304]
Purchase commitments with contract manufacturers and suppliers increased by approximately 34% compared to the end of fiscal 2017.  On a combined basis, inventories and purchase commitments with contract manufacturers and suppliers increased by 30% compared with the end of fiscal 2017.

[0000858877-18-000007:mdna:305]
We record a liability, included in other current liabilities, for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory.  As of April 28, 2018, the liability for these purchase commitments was $163 million, compared with $162 million as of July 29, 2017, and was included in other current liabilities.

[0000858877-18-000007:mdna:306]
[same as prior period, unchanged from 0000858877-18-000004:mdna:306]

[0000858877-18-000007:mdna:307]
[same as prior period, unchanged from 0000858877-18-000004:mdna:307]

[0000858877-18-000007:mdna:308]
[same as prior period, unchanged from 0000858877-18-000004:mdna:308]

[0000858877-18-000007:mdna:309]
[same as prior period, unchanged from 0000858877-18-000004:mdna:309]

[0000858877-18-000007:mdna:310]
|  | April 28, 2018 |  | July 29, 2017 |  | Increase (Decrease) |
| Lease receivables, net | $ | 2,519 |  |  | $ | 2,650 |  |  | $ | (131 | ) |
| Loan receivables, net | 4,878 |  |  | 4,457 |  |  | 421 |  |
| Financed service contracts, net | 2,386 |  |  | 2,487 |  |  | (101 | ) |
| Total, net | $ | 9,783 |  |  | $ | 9,594 |  |  | $ | 189 |  |

[0000858877-18-000007:mdna:311]
Financing Receivables  Our financing arrangements include leases, loans, and financed service contracts. Lease receivables include sales-type and direct-financing leases. Arrangements related to leases are generally collateralized by a security interest in the underlying assets. Our loan receivables include customers financing purchases of our hardware, software and services and also may include additional funds for other costs associated with network installation and integration of our products and services. We also provide financing to certain qualified customers for long-term service contracts, which primarily relate to technical support services.  The majority of the revenue from these financed service contracts is deferred and is recognized ratably over the period during which the services are performed.  Financing receivables increased by 2%. We expect to continue to expand the use of our financing programs in the near term.

[0000858877-18-000007:mdna:312]
[same as prior period, unchanged from 0000858877-18-000004:mdna:312]

[0000858877-18-000007:mdna:313]
The volume of channel partner financing was $20.7 billion and $19.7 billion for the first nine months of fiscal 2018 and 2017, respectively. These financing arrangements facilitate the working capital requirements of the channel partners, and in some cases, we guarantee a portion of these arrangements. The balance of the channel partner financing subject to guarantees was $1.0 billion as of each of April 28, 2018 and July 29, 2017. We could be called upon to make payments under these guarantees in the event of nonpayment by the channel partners or end-user customers. Historically, our payments under these arrangements have been immaterial. Where we provide a guarantee, we defer the revenue associated with the channel partner and end-user financing arrangement in accordance with revenue recognition policies, or we record a liability for the fair value of the guarantees. In either case, the deferred revenue is recognized as revenue when the guarantee is removed. As of April 28, 2018, the total maximum potential future payments related to these guarantees was approximately $303 million, of which approximately $122 million was recorded as deferred revenue.

[0000858877-18-000007:mdna:314]
[same as prior period, unchanged from 0000858877-18-000004:mdna:315]

[0000858877-18-000007:mdna:315]
[same as prior period, unchanged from 0000858877-18-000004:mdna:316]

[0000858877-18-000007:mdna:316]
[same as prior period, unchanged from 0000858877-18-000004:mdna:317]

[0000858877-18-000007:mdna:317]
[same as prior period, unchanged from 0000858877-18-000004:mdna:318]

[0000858877-18-000007:mdna:318]
|  | Maturity Date |  | April 28, 2018 |  | July 29, 2017 |
| Senior notes: |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |
| Three-month LIBOR plus 0.60% | February 21, 2018 |  | $ | — |  |  | $ | 1,000 |  |
| Three-month LIBOR plus 0.31% | June 15, 2018 |  | 900 |  |  | 900 |  |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | 500 |  |  | 500 |  |
| Three-month LIBOR plus 0.34% | September 20, 2019 |  | 500 |  |  | 500 |  |
| Fixed-rate notes: |  |  |  |  |  |
| 1.40% | February 28, 2018 |  | — |  |  | 1,250 |  |
| 1.65% | June 15, 2018 |  | 1,600 |  |  | 1,600 |  |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 2,000 |  |
| 1.60% | February 28, 2019 |  | 1,000 |  |  | 1,000 |  |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 1,750 |  |
| 1.40% | September 20, 2019 |  | 1,500 |  |  | 1,500 |  |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 2,500 |  |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 1,500 |  |
| 2.20% | February 28, 2021 |  | 2,500 |  |  | 2,500 |  |
| 2.90% | March 4, 2021 |  | 500 |  |  | 500 |  |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 2,000 |  |
| 3.00% | June 15, 2022 |  | 500 |  |  | 500 |  |
| 2.60% | February 28, 2023 |  | 500 |  |  | 500 |  |
| 2.20% | September 20, 2023 |  | 750 |  |  | 750 |  |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1,000 |  |
| 3.50% | June 15, 2025 |  | 500 |  |  | 500 |  |
| 2.95% | February 28, 2026 |  | 750 |  |  | 750 |  |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 1,500 |  |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 2,000 |  |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 2,000 |  |
| Total |  |  | $ | 28,250 |  |  | $ | 30,500 |  |

[0000858877-18-000007:mdna:319]
Interest is payable semiannually on each class of the senior fixed-rate notes, each of which is redeemable by us at any time, subject to a make-whole premium. Interest is payable quarterly on the floating-rate notes. We were in compliance with all debt covenants as of April 28, 2018.

[0000858877-18-000007:mdna:320]
Commercial Paper  We have a short-term debt financing program in which up to $10.0 billion is available through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes.  We had no commercial paper notes outstanding as of April 28, 2018 and $3.2 billion commercial paper notes outstanding as of July 29, 2017.

[0000858877-18-000007:mdna:321]
Credit Facility On May 15, 2015, we entered into a credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 15, 2020. Any advances under the credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (i) the highest of (a) the Federal Funds rate plus 0.50%, (b) Bank of America’s “prime rate” as announced from time to time, or (c) LIBOR, or a comparable or successor rate that is approved by the Administrative Agent (“Eurocurrency Rate”), for an interest period of one month plus 1.00%, or (ii) the Eurocurrency Rate, plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the Eurocurrency Rate be less than zero.

[0000858877-18-000007:mdna:322]
73

[0000858877-18-000007:mdna:323]
[same as prior period, unchanged from 0000858877-18-000004:mdna:323]

[0000858877-18-000007:mdna:324]
[same as prior period, unchanged from 0000858877-18-000004:mdna:324]

[0000858877-18-000007:mdna:325]
We may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and/or extend the expiration date of the credit facility up to May 15, 2022. The credit agreement requires that we comply with certain covenants, including that we maintain interest coverage ratios as defined in the agreement.  As of April 28, 2018, we were in compliance with the required interest coverage ratios and the other covenants, and we had not borrowed any funds under the credit facility.

[0000858877-18-000007:mdna:326]
[same as prior period, unchanged from 0000858877-18-000004:mdna:327]

[0000858877-18-000007:mdna:327]
|  | April 28, 2018 |  | July 29, 2017 |  | Increase (Decrease) |
| Service | $ | 10,960 |  |  | $ | 11,302 |  |  | $ | (342 | ) |
| Product: |  |  |  |  |  |  |
| Deferred revenue related to recurring software and subscription offers | 5,635 |  |  | 4,971 |  |  | 664 |  |
| Other product deferred revenue | 2,358 |  |  | 2,221 |  |  | 137 |  |
| Total product deferred revenue | 7,993 |  |  | 7,192 |  |  | 801 |  |
| Total | $ | 18,953 |  |  | $ | 18,494 |  |  | $ | 459 |  |
| Reported as: |  |  |  |  |  |
| Current | $ | 11,301 |  |  | $ | 10,821 |  |  | $ | 480 |  |
| Noncurrent | 7,652 |  |  | 7,673 |  |  | (21 | ) |
| Total | $ | 18,953 |  |  | $ | 18,494 |  |  | $ | 459 |  |

[0000858877-18-000007:mdna:328]
Deferred product revenue increased 11% primarily due to increased deferrals related to recurring software and subscription offers. The portion of product deferred revenue related to recurring software and subscription offers grew 29% on a year-over-year basis to $5.6 billion as of April 28, 2018. Security and Applications continued to experience strong product deferred revenue growth during the period. The 3% decrease in deferred service revenue was driven by the impact of ongoing amortization of deferred service revenue.

[0000858877-18-000007:mdna:329]
[same as prior period, unchanged from 0000858877-18-000004:mdna:330]

[0000858877-18-000007:mdna:330]
[same as prior period, unchanged from 0000858877-18-000004:mdna:331]

[0000858877-18-000007:mdna:331]
We lease office space in many U.S. locations. Outside the United States, larger leased sites include sites in Belgium, Canada, China, Germany, India, Israel, Japan, Mexico, Poland and the United Kingdom. We also lease equipment and vehicles. The future minimum lease payments under all of our noncancelable operating leases with an initial term in excess of one year as of April 28, 2018 were $1.2 billion.

[0000858877-18-000007:mdna:332]
[same as prior period, unchanged from 0000858877-18-000004:mdna:333]

[0000858877-18-000007:mdna:333]
[same as prior period, unchanged from 0000858877-18-000004:mdna:334]

[0000858877-18-000007:mdna:334]
Other Funding Commitments  We also have certain funding commitments primarily related to our investments in privately held companies and venture funds, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $212 million as of April 28, 2018, compared with $216 million as of July 29, 2017.

[0000858877-18-000007:mdna:335]
[same as prior period, unchanged from 0000858877-18-000004:mdna:339]

[0000858877-18-000007:mdna:336]
We consider our investments in unconsolidated variable interest entities to be off-balance sheet arrangements. In the ordinary course of business, we have investments in privately held companies including venture funds and provide financing to certain customers. Certain of these investments are considered to be variable interest entities. We evaluate on an ongoing basis our investments in these privately held companies and customer financings, and we have determined that as of April 28, 2018 there were no material unconsolidated variable interest entities.

[0000858877-18-000007:mdna:337]
[same as prior period, unchanged from 0000858877-18-000004:mdna:341]

[0000858877-18-000007:mdna:338]
74

[0000858877-18-000007:mdna:339]
[same as prior period, unchanged from 0000858877-18-000004:mdna:336]

[0000858877-18-000007:mdna:340]
[same as prior period, unchanged from 0000858877-18-000004:mdna:337]

[0000858877-18-000007:mdna:341]
[same as prior period, unchanged from 0000858877-18-000004:mdna:342]

[0000858877-18-000007:mdna:342]
[same as prior period, unchanged from 0000858877-18-000004:mdna:343]

[0000858877-18-000007:mdna:343]
We periodically engage in securities lending activities with certain of our available for sale investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. The average daily balance of securities lending for the nine months ended April 28, 2018 and April 29, 2017 was $0.3 billion and $0.8 billion, respectively. We require collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. We engage in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify us against collateral losses. As of April 28, 2018 and July 29, 2017, we had no outstanding securities lending transactions. We believe these arrangements do not present a material risk or impact to our liquidity requirements.

[0000858877-18-000007:mdna:344]
[same as prior period, unchanged from 0000858877-18-000004:mdna:345]

[0000858877-18-000007:mdna:345]
[same as prior period, unchanged from 0000858877-18-000004:mdna:346]
