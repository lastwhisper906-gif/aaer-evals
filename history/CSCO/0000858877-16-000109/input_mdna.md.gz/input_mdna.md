# CSCO MD&A — 0000858877-16-000109


## mdna

[0000858877-16-000109:mdna:1]
[same as prior period, unchanged from 0000858877-16-000090:mdna:1]

[0000858877-16-000109:mdna:2]
[same as prior period, unchanged from 0000858877-16-000090:mdna:2]

[0000858877-16-000109:mdna:3]
[same as prior period, unchanged from 0000858877-16-000090:mdna:3]

[0000858877-16-000109:mdna:4]
[same as prior period, unchanged from 0000858877-16-000090:mdna:4]

[0000858877-16-000109:mdna:5]
[same as prior period, unchanged from 0000858877-16-000090:mdna:5]

[0000858877-16-000109:mdna:6]
|  | Three Months Ended |  | Nine Months Ended |  |
|  | April 30, 2016 |  | April 25, 2015 |  | Variance |  | April 30, 2016 |  | April 25, 2015 |  | Variance |  |
| Revenue (1) | $ | 12,000 |  |  | $ | 12,137 |  |  | (1.1 | )% |  | $ | 36,609 |  |  | $ | 36,318 |  |  | 0.8 | % |  |
| Gross margin percentage | 64.3 | % |  | 62.0 | % |  | 2.3 |  | pts | 62.8 | % |  | 60.4 | % |  | 2.4 |  | pts |
| Research and development | $ | 1,626 |  |  | $ | 1,547 |  |  | 5.1 | % |  | $ | 4,695 |  |  | $ | 4,659 |  |  | 0.8 | % |  |
| Sales and marketing | $ | 2,447 |  |  | $ | 2,449 |  |  | (0.1 | )% |  | $ | 7,176 |  |  | $ | 7,272 |  |  | (1.3 | )% |  |
| General and administrative | $ | 566 |  |  | $ | 510 |  |  | 11.0 | % |  | $ | 1,281 |  |  | $ | 1,504 |  |  | (14.8 | )% |  |
| Total research and development, sales and marketing, general and administrative | $ | 4,639 |  |  | $ | 4,506 |  |  | 3.0 | % |  | $ | 13,152 |  |  | $ | 13,435 |  |  | (2.1 | )% |  |
| Total as a percentage of revenue | 38.7 | % |  | 37.1 | % |  | 1.6 |  | pts | 35.9 | % |  | 37.0 | % |  | (1.1 | ) | pts |
| Amortization of purchased intangible assets included in operating expenses | $ | 81 |  |  | $ | 70 |  |  | 15.7 | % |  | $ | 221 |  |  | $ | 213 |  |  | 3.8 | % |  |
| Restructuring and other charges included in operating expenses | $ | 17 |  |  | $ | 24 |  |  | (29.2 | )% |  | $ | 255 |  |  | $ | 411 |  |  | (38.0 | )% |  |
| Operating income as a percentage of revenue | 24.9 | % |  | 24.1 | % |  | 0.8 |  | pts | 25.6 | % |  | 21.7 | % |  | 3.9 |  | pts |
| Income tax percentage | 23.8 | % |  | 19.7 | % |  | 4.1 |  | pts | 16.8 | % |  | 19.4 | % |  | (2.6 | ) | pts |
| Net income | $ | 2,349 |  |  | $ | 2,437 |  |  | (3.6 | )% |  | $ | 7,926 |  |  | $ | 6,662 |  |  | 19.0 | % |  |
| Net income as a percentage of revenue | 19.6 | % |  | 20.1 | % |  | (0.5 | ) | pts | 21.7 | % |  | 18.3 | % |  | 3.4 |  | pts |
| Earnings per share—diluted | $ | 0.46 |  |  | $ | 0.47 |  |  | (2.1 | )% |  | $ | 1.56 |  |  | $ | 1.29 |  |  | 20.9 | % |  |

[0000858877-16-000109:mdna:7]
(1) During the second quarter of fiscal 2016, we completed the sale of the Customer Premises Equipment portion of our Service Provider Video Connected Devices business ("SP Video CPE Business"). As a result, revenue from this portion of the Service Provider Video product category will not recur in future periods. Includes SP Video CPE Business revenue of $519 million for the third quarter of fiscal 2015 and $504 million and $1,359 million for the first nine months of fiscal 2016 and 2015, respectively.

[0000858877-16-000109:mdna:8]
[same as prior period, unchanged from 0000858877-16-000090:mdna:29]

[0000858877-16-000109:mdna:9]
[same as prior period, unchanged from 0000858877-16-000090:mdna:8]

[0000858877-16-000109:mdna:10]
[same as prior period, unchanged from 0000858877-16-000090:mdna:9]

[0000858877-16-000109:mdna:11]
Three Months Ended April 30, 2016 Compared with Three Months Ended April 25, 2015

[0000858877-16-000109:mdna:12]
In the third quarter of fiscal 2016, our revenue decreased by 1% as compared with the third quarter of fiscal 2015. Within total revenue, product revenue decreased 5%, while service revenue increased 11%. In the second quarter of fiscal 2016, on November 20, 2015, we completed the sale of our SP Video CPE Business. Total company revenue for the third quarter of fiscal 2016 increased 3% not including revenue from SP Video CPE products in the prior year period. The third quarter of fiscal 2016 had 14 weeks, compared with 13 weeks in the third quarter of fiscal 2015, thus our results for the third quarter and the first nine months of fiscal 2016 reflect an extra week compared with the corresponding periods in fiscal 2015. We estimate that the additional revenue associated with the extra week was approximately $265 million, $200 million of which was from our services subscriptions, and $65 million from our software-as-a-service offerings (SaaS) such as WebEx, and a small amount from product distribution. Total gross margin increased by 2.3 percentage points, driven by the sale of the lower margin SP Video CPE Business, along with higher service gross margin. As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses, collectively, increased by 1.6 percentage points due in large part to the impact of the extra week in the third quarter of fiscal 2016. Operating income as a percentage of revenue increased by 0.8 percentage points, driven by the factors discussed above. Diluted earnings per share decreased by 2% from the prior year, driven by a 4% decrease in net income.

[0000858877-16-000109:mdna:13]
In the third quarter of fiscal 2016, revenue from the Americas decreased by $0.2 billion compared with the third quarter of fiscal 2015, driven in large part by the sale of the SP Video CPE Business which led to lower product revenue in the United States. EMEA revenue decreased by $0.1 billion, led by product revenue declines in Russia and the United Kingdom. Revenue in our APJC segment increased $0.2 billion, led by product revenue growth in China. We saw improvements in our revenue from many emerging countries, and in particular we experienced increased product revenue growth in the emerging countries of China and India of 44% and 16%, respectively. Overall, the “BRICM” countries experienced, in the aggregate, product revenue growth of 5%, despite decreased product revenue in Russia, Mexico and Brazil of 31%, 26% and 20%, respectively.

[0000858877-16-000109:mdna:14]
From a customer market standpoint, in the third quarter of fiscal 2016 we experienced a significant product revenue decline in the service provider market due to the sale of the SP Video CPE Business. Product revenue also declined in the enterprise market, which we believe was impacted by uncertainty in the macro environment, which led to a slowdown in customer spending. These decreases were partially offset by increased product revenue from the public sector and commercial markets.

[0000858877-16-000109:mdna:15]
From a product category perspective, total company product revenue, not including SP Video CPE products in the prior year period, increased 1% year over year. This increase was led by product revenue growth in Security and Collaboration products which grew 17% and 10%, respectively. We also experienced an 18% increase in revenue from Service Provider Video (excluding the CPE Business from the prior year period), as well as Data Center and Wireless products which each grew by 1%.  Offsetting these increases were product revenue decreases in our core NGN Routing and Switching categories which declined by 5% and 3%, respectively.  The decline in sales of NGN Routing products was driven primarily by a decrease in sales of our high-end router products. In addition, we believe a cautious Service Provider capital expenditure spending environment negatively impacted sales in this product category. The decline in sales of our Switching products was driven in large part by lower sales of switches used in campus environments (which comprises the majority of this product category), and we believe this was largely driven by the continued uncertainty in the macro environment, which led to a slowdown in customer spending.

[0000858877-16-000109:mdna:16]
Nine Months Ended April 30, 2016 Compared with Nine Months Ended April 25, 2015

[0000858877-16-000109:mdna:17]
Diluted earnings per share increased by 21% from the prior year, a result of a 19% increase in net income. Revenue increased 1%, with service revenue increasing 5% and product revenue decreasing slightly. Total gross margin increased by 2.4 percentage points driven by the sale of our lower margin SP Video CPE Business, lower amortization expense and impairment charges related to acquisition-related intangible assets and the Rockstar patent portfolio charge of $188 million (or 0.8 percentage points of the prior period revenue) recorded in the first quarter of fiscal 2015. As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses collectively decreased by 1.1 percentage points driven by the $285 million pre-tax gain from the sale of our SP Video CPE Business and a decrease in restructuring and other charges related to the restructuring action announced in August 2014. Operating income as a percentage of revenue increased by 3.9 percentage points.

[0000858877-16-000109:mdna:18]
During the prior two fiscal years we have encountered business challenges in the service provider market and certain emerging countries.  Although we saw positive business momentum in these areas during the first nine months of fiscal 2016, we continue to monitor and assess the sustainability of improvements in these areas.

[0000858877-16-000109:mdna:19]
[same as prior period, unchanged from 0000858877-16-000090:mdna:44]

[0000858877-16-000109:mdna:20]
[same as prior period, unchanged from 0000858877-16-000090:mdna:19]

[0000858877-16-000109:mdna:21]
[same as prior period, unchanged from 0000858877-16-000090:mdna:20]

[0000858877-16-000109:mdna:22]
[same as prior period, unchanged from 0000858877-16-000090:mdna:21]

[0000858877-16-000109:mdna:23]
[same as prior period, unchanged from 0000858877-16-000090:mdna:22]

[0000858877-16-000109:mdna:24]
[same as prior period, unchanged from 0000858877-16-000090:mdna:23]

[0000858877-16-000109:mdna:25]
[same as prior period, unchanged from 0000858877-16-000090:mdna:24]

[0000858877-16-000109:mdna:26]
[same as prior period, unchanged from 0000858877-16-000090:mdna:25]

[0000858877-16-000109:mdna:27]
The following is a summary of our other key financial measures for the third quarter and first nine months of fiscal 2016 (in millions, except days sales outstanding in accounts receivable (DSO) and annualized inventory turns):

[0000858877-16-000109:mdna:28]
|  |  | April 30, 2016 |  | July 25, 2015 |
| Cash and cash equivalents and investments |  | $ | 63,512 |  |  | $ | 60,416 |  |
| Deferred revenue |  | $ | 15,272 |  |  | $ | 15,183 |  |
| DSO |  | 33 days |  |  | 38 days |  |
| Inventories |  | $ | 1,343 |  |  | $ | 1,627 |  |
| Annualized inventory turns |  | 12.0 |  |  | 12.1 |  |

[0000858877-16-000109:mdna:29]
|  |  | Nine Months Ended |
|  |  | April 30, 2016 |  | April 25, 2015 |
| Cash provided by operating activities |  | $ | 9,752 |  |  | $ | 8,414 |  |
| Repurchases of common stock—stock repurchase program |  | $ | 3,118 |  |  | $ | 3,229 |  |
| Dividends |  | $ | 3,441 |  |  | $ | 3,017 |  |

[0000858877-16-000109:mdna:30]
[same as prior period, unchanged from 0000858877-16-000090:mdna:56]

[0000858877-16-000109:mdna:31]
[same as prior period, unchanged from 0000858877-16-000090:mdna:30]

[0000858877-16-000109:mdna:32]
[same as prior period, unchanged from 0000858877-16-000090:mdna:31]

[0000858877-16-000109:mdna:33]
[same as prior period, unchanged from 0000858877-16-000090:mdna:32]

[0000858877-16-000109:mdna:34]
[same as prior period, unchanged from 0000858877-16-000090:mdna:33]

[0000858877-16-000109:mdna:35]
[same as prior period, unchanged from 0000858877-16-000090:mdna:34]

[0000858877-16-000109:mdna:36]
[same as prior period, unchanged from 0000858877-16-000090:mdna:35]

[0000858877-16-000109:mdna:37]
[same as prior period, unchanged from 0000858877-16-000090:mdna:36]

[0000858877-16-000109:mdna:38]
[same as prior period, unchanged from 0000858877-16-000090:mdna:37]

[0000858877-16-000109:mdna:39]
[same as prior period, unchanged from 0000858877-16-000090:mdna:38]

[0000858877-16-000109:mdna:40]
[same as prior period, unchanged from 0000858877-16-000090:mdna:39]

[0000858877-16-000109:mdna:41]
[same as prior period, unchanged from 0000858877-16-000090:mdna:40]

[0000858877-16-000109:mdna:42]
[same as prior period, unchanged from 0000858877-16-000090:mdna:41]

[0000858877-16-000109:mdna:43]
[same as prior period, unchanged from 0000858877-16-000090:mdna:42]

[0000858877-16-000109:mdna:44]
As our business and offerings evolve over time, our pricing practices may be required to be modified accordingly, which could result in changes in selling prices, including both VSOE and ESP, in subsequent periods. There were no material impacts during the first nine months of fiscal 2016, nor do we currently expect a material impact in the next 12 months on our revenue recognition due to any changes in our VSOE, TPE, or ESP.

[0000858877-16-000109:mdna:45]
[same as prior period, unchanged from 0000858877-16-000090:mdna:69]

[0000858877-16-000109:mdna:46]
[same as prior period, unchanged from 0000858877-16-000090:mdna:45]

[0000858877-16-000109:mdna:47]
[same as prior period, unchanged from 0000858877-16-000090:mdna:46]

[0000858877-16-000109:mdna:48]
Revenue deferrals relate to the timing of revenue recognition for specific transactions based on financing arrangements, service, support, and other factors. Financing arrangements may include sales-type, direct-financing, and operating leases, loans, and guarantees of third-party financing. Our deferred revenue for products was $5.4 billion as of each of April 30, 2016 and July 25, 2015. Technical support services revenue is deferred and recognized ratably over the period during which the services are to be performed, which typically is from one to three years. Advanced services revenue is recognized upon delivery or completion of performance milestones. Our deferred revenue for services was $9.9 billion and $9.8 billion as of April 30, 2016 and July 25, 2015, respectively.

[0000858877-16-000109:mdna:49]
[same as prior period, unchanged from 0000858877-16-000090:mdna:48]

[0000858877-16-000109:mdna:50]
[same as prior period, unchanged from 0000858877-16-000090:mdna:49]

[0000858877-16-000109:mdna:51]
[same as prior period, unchanged from 0000858877-16-000090:mdna:50]

[0000858877-16-000109:mdna:52]
|  |  | April 30, 2016 |  | July 25, 2015 |
| Allowance for doubtful accounts |  | $ | 244 |  |  | $ | 302 |  |
| Percentage of gross accounts receivable |  | 5.7 | % |  | 5.4 | % |
| Allowance for credit loss—lease receivables |  | $ | 250 |  |  | $ | 259 |  |
| Percentage of gross lease receivables(1) |  | 7.2 | % |  | 7.2 | % |
| Allowance for credit loss—loan receivables |  | $ | 93 |  |  | $ | 87 |  |
| Percentage of gross loan receivables |  | 4.2 | % |  | 4.9 | % |

[0000858877-16-000109:mdna:53]
[same as prior period, unchanged from 0000858877-16-000090:mdna:52]

[0000858877-16-000109:mdna:54]
[same as prior period, unchanged from 0000858877-16-000090:mdna:53]

[0000858877-16-000109:mdna:55]
[same as prior period, unchanged from 0000858877-16-000090:mdna:54]

[0000858877-16-000109:mdna:56]
A reserve for future sales returns is established based on historical trends in product return rates. The reserve for future sales returns as of April 30, 2016 and July 25, 2015 was $119 million and $129 million, respectively, and was recorded as a reduction of our accounts receivable. If the actual future returns were to deviate from the historical data on which the reserve had been established, our revenue could be adversely affected.

[0000858877-16-000109:mdna:57]
[same as prior period, unchanged from 0000858877-16-000090:mdna:57]

[0000858877-16-000109:mdna:58]
[same as prior period, unchanged from 0000858877-16-000090:mdna:58]

[0000858877-16-000109:mdna:59]
[same as prior period, unchanged from 0000858877-16-000090:mdna:59]

[0000858877-16-000109:mdna:60]
Our inventory balance was $1.3 billion and $1.6 billion as of April 30, 2016 and July 25, 2015, respectively. Inventory is written down based on excess and obsolete inventories, determined primarily by future demand forecasts. Inventory write-downs are measured as the difference between the cost of the inventory and market, based upon assumptions about future demand, and are charged to the provision for inventory, which is a component of our cost of sales. At the point of the loss recognition, a new, lower cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis.

[0000858877-16-000109:mdna:61]
We record a liability for firm, noncancelable, and unconditional purchase commitments with contract manufacturers and suppliers for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of April 30, 2016, the liability for these purchase commitments was $160 million, compared with $156 million as of July 25, 2015, and was included in other current liabilities.

[0000858877-16-000109:mdna:62]
Our provision for inventory was $55 million and $42 million for the first nine months of fiscal 2016 and 2015, respectively. The provision for the liability related to purchase commitments with contract manufacturers and suppliers was $108 million and $79 million for the first nine months of fiscal 2016 and 2015, respectively. If there were to be a sudden and significant decrease in demand for our products, or if there were a higher incidence of inventory obsolescence because of rapidly changing technology and customer requirements, we could be required to increase our inventory write-downs, and our liability for purchase commitments with contract manufacturers and suppliers, and accordingly our profitability, could be adversely affected. We regularly evaluate our exposure for inventory write-downs and the adequacy of our liability for purchase commitments. Inventory and supply chain management remain areas of focus as we balance the need to maintain supply chain flexibility to help ensure competitive lead times with the risk of inventory obsolescence, particularly in light of current macroeconomic uncertainties and conditions and the resulting potential for changes in future demand forecast.

[0000858877-16-000109:mdna:63]
Loss Contingencies and Product Warranties

[0000858877-16-000109:mdna:64]
We are subject to the possibility of various losses arising in the ordinary course of business. We consider the likelihood of impairment of an asset or the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated. We regularly evaluate information available to us to determine whether such accruals should be made or adjusted and whether new accruals are required.

[0000858877-16-000109:mdna:65]
Third parties, including customers, have in the past and may in the future assert claims or initiate litigation related to exclusive patent, copyright, trademark, and other intellectual property rights to technologies and related standards that are relevant to us. These assertions have increased over time as a result of our growth and the general increase in the pace of patent claims assertions, particularly in the United States. If any infringement or other intellectual property claim made against us by any third party is successful, or if we fail to develop non-infringing technology or license the proprietary rights on commercially reasonable terms and conditions, our business, operating results, and financial condition could be materially and adversely affected.

[0000858877-16-000109:mdna:66]
We have recorded a liability for the expected remediation cost for certain products sold in prior fiscal years containing memory components manufactured by a single supplier between 2005 and 2010. In February 2014, on the basis of the growing number of failures as described in Note 12 (f) to the Consolidated Financial Statements, we decided to expand our approach, which resulted in a charge to product cost of sales of $655 million being recorded for the second quarter of fiscal 2014. During the third quarters of fiscal 2016 and 2015, we recorded adjustments to product cost of sales of $74 million and $164 million, respectively to reduce the liability, reflecting net lower than previously estimated future costs to remediate the impacted customer products. Estimating this liability is complex and subjective, and if we experience changes in a number of underlying assumptions and estimates such as a change in claims compared with our expectations, or if the cost of servicing these claims is different than expected, our estimated liability may be impacted.

[0000858877-16-000109:mdna:67]
Our liability for product warranties, included in other current liabilities, was $409 million as of April 30, 2016, compared with $449 million as of July 25, 2015. Our products are generally covered by a warranty for periods ranging from 90 days to five years, and for some products we provide a limited lifetime warranty. We accrue for warranty costs as part of our cost of sales based on associated material costs, technical support labor costs, and associated overhead. Material cost is estimated based primarily upon historical trends in the volume of product returns within the warranty period and the cost to repair or replace the equipment. Technical support labor cost is estimated based primarily upon historical trends in the rate of customer cases and the cost to support the customer cases within the warranty period. Overhead cost is applied based on estimated time to support warranty activities.

[0000858877-16-000109:mdna:68]
The provision for product warranties during the first nine months of fiscal 2016 and 2015 was $512 million and $517 million, respectively. If we experience an increase in warranty claims compared with our historical experience, or if the cost of servicing warranty claims is greater than expected, our profitability could be adversely affected.

[0000858877-16-000109:mdna:69]
[same as prior period, unchanged from 0000858877-16-000090:mdna:93]

[0000858877-16-000109:mdna:70]
[same as prior period, unchanged from 0000858877-16-000090:mdna:70]

[0000858877-16-000109:mdna:71]
[same as prior period, unchanged from 0000858877-16-000090:mdna:71]

[0000858877-16-000109:mdna:72]
[same as prior period, unchanged from 0000858877-16-000090:mdna:72]

[0000858877-16-000109:mdna:73]
Our fixed income and publicly traded equity securities, collectively, are reflected in the Consolidated Balance Sheets at a fair value of $54.6 billion as of April 30, 2016, compared with $53.5 billion as of July 25, 2015. Our fixed income investment portfolio as of April 30, 2016 consisted primarily of high quality investment-grade securities. See Note 8 to the Consolidated Financial Statements.

[0000858877-16-000109:mdna:74]
[same as prior period, unchanged from 0000858877-16-000090:mdna:74]

[0000858877-16-000109:mdna:75]
[same as prior period, unchanged from 0000858877-16-000090:mdna:75]

[0000858877-16-000109:mdna:76]
The inputs and fair value are reviewed for reasonableness, may be further validated by comparison to publicly available information, and could be adjusted based on market indices or other information that management deems material to its estimate of fair value. The assessment of fair value can be difficult and subjective. However, given the relative reliability of the inputs we use to value our investment portfolio, and because substantially all of our valuation inputs are obtained using quoted market prices for similar or identical assets, we do not believe that the nature of estimates and assumptions affected by levels of subjectivity and judgment was material to the valuation of the investment portfolio as of April 30, 2016. Level 3 assets do not represent a significant portion of our total assets measured at fair value on a recurring basis as of April 30, 2016 and July 25, 2015.

[0000858877-16-000109:mdna:77]
[same as prior period, unchanged from 0000858877-16-000090:mdna:77]

[0000858877-16-000109:mdna:78]
[same as prior period, unchanged from 0000858877-16-000090:mdna:78]

[0000858877-16-000109:mdna:79]
[same as prior period, unchanged from 0000858877-16-000090:mdna:79]

[0000858877-16-000109:mdna:80]
[same as prior period, unchanged from 0000858877-16-000090:mdna:80]

[0000858877-16-000109:mdna:81]
There were no impairment charges on our investments in publicly traded equity securities in the first nine months of fiscal 2016 and 2015. For the first nine months of fiscal 2016, we recognized impairment charges of $3 million on our investments in fixed income securities, while there were no such impairment charges recognized in the first nine months of fiscal 2015. Our ongoing consideration of all the factors described previously could result in additional impairment charges in the future, which could adversely affect our net income.

[0000858877-16-000109:mdna:82]
[same as prior period, unchanged from 0000858877-16-000090:mdna:97]

[0000858877-16-000109:mdna:83]
[same as prior period, unchanged from 0000858877-16-000090:mdna:82]

[0000858877-16-000109:mdna:84]
[same as prior period, unchanged from 0000858877-16-000090:mdna:83]

[0000858877-16-000109:mdna:85]
We also have investments in privately held companies, some of which are in the startup or development stages. Our investments in privately held companies as of April 30, 2016 were $976 million, compared with $897 million as of July 25, 2015, and were included in other assets. We monitor these investments for events or circumstances indicative of potential impairment, and we make appropriate reductions in carrying values if we determine that an impairment charge is required, based primarily on the financial condition and near-term prospects of these companies. These investments are inherently risky because the markets for the technologies or products these companies are developing are typically in the early stages and may never materialize. Our impairment charges on investments in privately held companies were $63 million and $20 million for the first nine months of fiscal 2016 and 2015, respectively.

[0000858877-16-000109:mdna:86]
[same as prior period, unchanged from 0000858877-16-000090:mdna:85]

[0000858877-16-000109:mdna:87]
[same as prior period, unchanged from 0000858877-16-000090:mdna:86]

[0000858877-16-000109:mdna:88]
The goodwill recorded in the Consolidated Balance Sheets as of April 30, 2016 and July 25, 2015 was $26.8 billion and $24.5 billion, respectively. In response to changes in industry and market conditions, we could be required to strategically realign our resources and consider restructuring, disposing of, or otherwise exiting businesses, which could result in an impairment of goodwill. There was no impairment of goodwill in the first nine months of fiscal 2016 and 2015.

[0000858877-16-000109:mdna:89]
We make judgments about the recoverability of purchased intangible assets with finite lives whenever events or changes in circumstances indicate that an impairment may exist. Recoverability of purchased intangible assets with finite lives is measured by comparing the carrying amount of the asset to the future undiscounted cash flows the asset is expected to generate. We review indefinite-lived intangible assets for impairment annually or whenever events or changes in circumstances indicate that the asset might be impaired. If the asset is considered to be impaired, the amount of any impairment is measured as the difference between the carrying value and the fair value of the impaired asset. Assumptions and estimates about future values and remaining useful lives of our purchased intangible assets are complex and subjective. They can be affected by a variety of factors, including external factors such as industry and economic trends, and internal factors such as changes in our business strategy and our internal forecasts.  Our impairment charges on purchased intangible assets were $44 million and $57 million for the first nine months of fiscal 2016 and 2015, respectively. Our ongoing consideration of all the factors described previously could result in additional impairment charges in the future, which could adversely affect our net income.

[0000858877-16-000109:mdna:90]
[same as prior period, unchanged from 0000858877-16-000090:mdna:89]

[0000858877-16-000109:mdna:91]
We are subject to income taxes in the United States and numerous foreign jurisdictions. Our effective tax rates differ from the statutory rate, primarily due to the tax impact of state taxes, foreign operations, R&D tax credits, domestic manufacturing deductions, tax audit settlements, nondeductible compensation, international realignments, and transfer pricing adjustments. Our effective tax rate was 23.8% and 19.7% in the third quarter of fiscal 2016 and 2015, respectively. Our effective tax rate was 16.8% and 19.4% in the first nine months of fiscal 2016 and 2015, respectively.

[0000858877-16-000109:mdna:92]
[same as prior period, unchanged from 0000858877-16-000090:mdna:91]

[0000858877-16-000109:mdna:93]
[same as prior period, unchanged from 0000858877-16-000090:mdna:92]

[0000858877-16-000109:mdna:94]
52

[0000858877-16-000109:mdna:95]
[same as prior period, unchanged from 0000858877-16-000090:mdna:94]

[0000858877-16-000109:mdna:96]
[same as prior period, unchanged from 0000858877-16-000090:mdna:95]

[0000858877-16-000109:mdna:97]
[same as prior period, unchanged from 0000858877-16-000090:mdna:96]

[0000858877-16-000109:mdna:98]
53

[0000858877-16-000109:mdna:99]
[same as prior period, unchanged from 0000858877-16-000090:mdna:98]

[0000858877-16-000109:mdna:100]
[same as prior period, unchanged from 0000858877-16-000090:mdna:99]

[0000858877-16-000109:mdna:101]
[same as prior period, unchanged from 0000858877-16-000090:mdna:100]

[0000858877-16-000109:mdna:102]
[same as prior period, unchanged from 0000858877-16-000090:mdna:101]

[0000858877-16-000109:mdna:103]
[same as prior period, unchanged from 0000858877-16-000090:mdna:102]

[0000858877-16-000109:mdna:104]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 30, 2016 |  | April 25, 2015 |  | Variancein Dollars |  | Variance in Percent |  | April 30, 2016 |  | April 25, 2015 |  | Variancein Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 8,875 |  |  | $ | 9,326 |  |  | $ | (451 | ) |  | (4.8 | )% |  | $ | 27,702 |  |  | $ | 27,839 |  |  | $ | (137 | ) |  | (0.5 | )% |
| Percentage of revenue |  | 74.0 | % |  | 76.8 | % |  |  |  |  |  | 75.7 | % |  | 76.7 | % |  |  |  |  |  |  |
| Service |  | 3,125 |  |  | 2,811 |  |  | 314 |  |  | 11.2 | % |  | 8,907 |  |  | 8,479 |  |  | 428 |  |  | 5.0 | % |
| Percentage of revenue |  | 26.0 | % |  | 23.2 | % |  |  |  |  |  | 24.3 | % |  | 23.3 | % |  |  |  |  |  |  |
| Total |  | $ | 12,000 |  |  | $ | 12,137 |  |  | $ | (137 | ) |  | (1.1 | )% |  | $ | 36,609 |  |  | $ | 36,318 |  |  | $ | 291 |  |  | 0.8 | % |

[0000858877-16-000109:mdna:105]
[same as prior period, unchanged from 0000858877-16-000090:mdna:104]

[0000858877-16-000109:mdna:106]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 30, 2016 |  | April 25, 2015 |  | Variancein Dollars |  | Variance in Percent |  | April 30, 2016 |  | April 25, 2015 |  | Variancein Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 7,062 |  |  | $ | 7,252 |  |  | $ | (190 | ) |  | (2.6 | )% |  | $ | 21,773 |  |  | $ | 21,854 |  |  | $ | (81 | ) |  | (0.4 | )% |
| Percentage of revenue |  | 58.9 | % |  | 59.7 | % |  |  |  |  |  | 59.5 | % |  | 60.2 | % |  |  |  |  |
| EMEA |  | 3,001 |  |  | 3,119 |  |  | (118 | ) |  | (3.8 | )% |  | 9,176 |  |  | 9,212 |  |  | (36 | ) |  | (0.4 | )% |
| Percentage of revenue |  | 25.0 | % |  | 25.7 | % |  |  |  |  |  | 25.1 | % |  | 25.4 | % |  |  |  |  |
| APJC |  | 1,937 |  |  | 1,766 |  |  | 171 |  |  | 9.7 | % |  | 5,660 |  |  | 5,252 |  |  | 408 |  |  | 7.8 | % |
| Percentage of revenue |  | 16.1 | % |  | 14.6 | % |  |  |  |  |  | 15.4 | % |  | 14.4 | % |  |  |  |  |
| Total |  | $ | 12,000 |  |  | $ | 12,137 |  |  | $ | (137 | ) |  | (1.1 | )% |  | $ | 36,609 |  |  | $ | 36,318 |  |  | $ | 291 |  |  | 0.8 | % |

[0000858877-16-000109:mdna:107]
Three Months Ended April 30, 2016 Compared with Three Months Ended April 25, 2015

[0000858877-16-000109:mdna:108]
For the third quarter of fiscal 2016, as compared with the third quarter of fiscal 2015, total revenue decreased by 1%. Total company revenue not including SP Video CPE products increased 3%. Product revenue decreased by 5% in total, but increased by 1% for total company product revenue not including SP Video CPE products in the prior year period. Service revenue increased by 11%.  The third quarter of fiscal 2016 had 14 weeks, compared with 13 weeks in the third quarter of fiscal 2015, thus our results for the third quarter of fiscal 2016 reflect an extra week compared with the third quarter of fiscal 2015. We estimate that the additional revenue associated with the extra week was approximately $265 million, $200 million of which was from our services subscriptions, and $65 million from our SaaS offerings such as WebEx, and a small amount from product distribution. Our total revenue grew in our APJC geographic segment, while revenue declined in the Americas and EMEA geographic segments.  The emerging countries of BRICM, in the aggregate, experienced 5% product revenue growth, with growth in China and India, partially offset by decreases in the other three BRICM countries.

[0000858877-16-000109:mdna:109]
We conduct business globally in numerous currencies. The direct effect of foreign currency fluctuations on revenue has not been material because our revenue is primarily denominated in U.S. dollars. However, if the U.S. dollar strengthens relative to other currencies, as was the case during the third quarter of fiscal 2016 on a year-over year basis, such strengthening could have an indirect effect on our revenue to the extent it raises the cost of our products to non-U.S. customers and thereby reduces demand. A weaker U.S. dollar could have the opposite effect. However, the precise indirect effect of currency fluctuations is difficult to measure or predict because our revenue is influenced by many factors in addition to the impact of such currency fluctuations. Our revenue in the third quarter of fiscal 2016 was adversely affected on a year-over-year basis by the depreciation of certain currencies relative to the U.S. dollar and especially currencies in certain emerging countries, although the indirect effects are difficult to measure.

[0000858877-16-000109:mdna:110]
[same as prior period, unchanged from 0000858877-16-000090:mdna:110]

[0000858877-16-000109:mdna:111]
[same as prior period, unchanged from 0000858877-16-000090:mdna:111]

[0000858877-16-000109:mdna:112]
[same as prior period, unchanged from 0000858877-16-000090:mdna:109]

[0000858877-16-000109:mdna:113]
Nine Months Ended April 30, 2016 Compared with Nine Months Ended April 25, 2015

[0000858877-16-000109:mdna:114]
For the first nine months of fiscal 2016, as compared with the first nine months of fiscal 2015, total revenue increased by 1%.  Product revenue decreased slightly, while service revenue increased by 5%.  Our total revenue grew in our APJC geographic segment, while revenue slightly declined in the Americas and EMEA geographic segments.  The emerging countries of BRICM, in the aggregate, experienced 8% product revenue growth, with revenue growth in China, India and Mexico partially offset by decreases in the other two BRICM countries.

[0000858877-16-000109:mdna:115]
[same as prior period, unchanged from 0000858877-16-000090:mdna:114]

[0000858877-16-000109:mdna:116]
[same as prior period, unchanged from 0000858877-16-000090:mdna:115]

[0000858877-16-000109:mdna:117]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 30, 2016 |  | April 25, 2015 |  | Variancein Dollars |  | Variance in Percent |  | April 30, 2016 |  | April 25, 2015 |  | Variancein Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 5,056 |  |  | $ | 5,429 |  |  | $ | (373 | ) |  | (6.9 | )% |  | $ | 16,001 |  |  | $ | 16,356 |  |  | $ | (355 | ) |  | (2.2 | )% |
| Percentage of product revenue |  | 57.0 | % |  | 58.2 | % |  |  |  |  |  | 57.8 | % |  | 58.8 | % |  |  |  |  |
| EMEA |  | 2,315 |  |  | 2,512 |  |  | (197 | ) |  | (7.8 | )% |  | 7,245 |  |  | 7,388 |  |  | (143 | ) |  | (1.9 | )% |
| Percentage of product revenue |  | 26.1 | % |  | 26.9 | % |  |  |  |  |  | 26.1 | % |  | 26.5 | % |  |  |  |  |
| APJC |  | 1,504 |  |  | 1,385 |  |  | 119 |  |  | 8.6 | % |  | 4,456 |  |  | 4,095 |  |  | 361 |  |  | 8.8 | % |
| Percentage of product revenue |  | 16.9 | % |  | 14.9 | % |  |  |  |  |  | 16.1 | % |  | 14.7 | % |  |  |  |  |
| Total |  | $ | 8,875 |  |  | $ | 9,326 |  |  | $ | (451 | ) |  | (4.8 | )% |  | $ | 27,702 |  |  | $ | 27,839 |  |  | $ | (137 | ) |  | (0.5 | )% |

[0000858877-16-000109:mdna:118]
During the second quarter of fiscal 2016, on November 20, 2015, we completed the sale of our SP Video CPE Business.  As a result, revenue from this portion of the Service Provider Video product category will not recur in future periods.  SP Video CPE Business revenue for the third quarter of fiscal 2015 was $519 million. Such revenue was $504 million and $1,359 million for the first nine months of fiscal 2016 and 2015, respectively.

[0000858877-16-000109:mdna:119]
[same as prior period, unchanged from 0000858877-16-000090:mdna:117]

[0000858877-16-000109:mdna:120]
Three Months Ended April 30, 2016 Compared with Three Months Ended April 25, 2015

[0000858877-16-000109:mdna:121]
The decrease in product revenue for the Americas segment was driven in large part by the absence of product sales related to our SP Video CPE Business in the third quarter of fiscal 2016. We had $439 million in product sales related to our SP Video CPE Business in the third quarter of fiscal 2015. From a customer markets perspective, the decrease in product revenue in the Americas segment of 7% was led by a significant decline in the service provider market and, to a lesser extent, a decline in the enterprise market. The product revenue decline in the service provider market was due to the sale of the SP Video CPE Business. We experienced product revenue growth in the public sector and commercial markets. The product revenue growth in the public sector market was due primarily to higher sales to state and local governments and, to a lesser extent, higher sales to the U.S. federal government. From a country perspective, product revenue decreased by 5% in the United States, 26% in Mexico, 20% in Brazil and 19% in Canada.

[0000858877-16-000109:mdna:122]
55

[0000858877-16-000109:mdna:123]
[same as prior period, unchanged from 0000858877-16-000090:mdna:122]

[0000858877-16-000109:mdna:124]
[same as prior period, unchanged from 0000858877-16-000090:mdna:123]

[0000858877-16-000109:mdna:125]
Nine Months Ended April 30, 2016 Compared with Nine Months Ended April 25, 2015

[0000858877-16-000109:mdna:126]
Product revenue in the Americas segment decreased by 2%, led by a significant decline in the service provider market partially offset by product revenue growth in the commercial, public sector and, to a lesser extent, in the enterprise market. The decline in revenue in the service provider market was due to lower revenue from SP Video CPE products, due to the sale of this business.  From a country perspective, product revenue decreased by 35% in Brazil and 24% in Canada partially offset by increases of 1% in the United States and 13% in Mexico.

[0000858877-16-000109:mdna:127]
[same as prior period, unchanged from 0000858877-16-000090:mdna:124]

[0000858877-16-000109:mdna:128]
Three Months Ended April 30, 2016 Compared with Three Months Ended April 25, 2015

[0000858877-16-000109:mdna:129]
The decrease in product revenue for the EMEA segment was driven by the absence of product sales related to our SP Video CPE Business in the third quarter of fiscal 2016.  We had $68 million in product sales related to our SP Video CPE Business in the third quarter of fiscal 2015. Product revenue in the EMEA segment decreased by 8%, with declines across all customer markets. The decline in sales to the service provider market was due primarily to the sale of the SP Video CPE Business. Product revenue from emerging countries within EMEA decreased by 19%, led by a decline in Russia of 31%. Product revenue for the remainder of the EMEA segment, which primarily consists of countries in Western Europe, decreased by 4%.

[0000858877-16-000109:mdna:130]
Nine Months Ended April 30, 2016 Compared with Nine Months Ended April 25, 2015

[0000858877-16-000109:mdna:131]
Product revenue in the EMEA segment decreased by 2%, led by declines in the service provider, public sector and enterprise markets. The decline in sales to the service provider market was due primarily to the sale of the SP Video CPE Business. We experienced product revenue growth in the commercial market in this segment. Product revenue from the emerging countries within EMEA declined by 8%, led by a 33% decrease in Russia, while the product revenue in the remainder of EMEA was flat.

[0000858877-16-000109:mdna:132]
[same as prior period, unchanged from 0000858877-16-000090:mdna:129]

[0000858877-16-000109:mdna:133]
Three Months Ended April 30, 2016 Compared with Three Months Ended April 25, 2015

[0000858877-16-000109:mdna:134]
The increase in product revenue in the APJC segment of 9% was led by strong growth in the service provider market and, to a lesser extent, growth in the enterprise market. These increases were partially offset by declines in the public sector and commercial markets. From a country perspective, product revenue increased by 44% in China, 16% in India, and 1% in Japan, partially offset by a product revenue decrease of 25% in Australia.  Product sales for this geographic segment were adversely impacted by a $12 million decrease in product sales related to the absence of our SP Video CPE Business.

[0000858877-16-000109:mdna:135]
Nine Months Ended April 30, 2016 Compared with Nine Months Ended April 25, 2015

[0000858877-16-000109:mdna:136]
Product revenue in the APJC segment increased by 9%. The product revenue growth was led by strong growth in the service provider market and, to a lesser extent, growth in the commercial and enterprise markets. Product revenue growth in the public sector market was flat. From a country perspective, product revenue increased by 37% in China and 20% in India, partially offset by product revenue declines of 6% in Japan and 5% in Australia.

[0000858877-16-000109:mdna:137]
[same as prior period, unchanged from 0000858877-16-000090:mdna:159]

[0000858877-16-000109:mdna:138]
[same as prior period, unchanged from 0000858877-16-000090:mdna:135]

[0000858877-16-000109:mdna:139]
[same as prior period, unchanged from 0000858877-16-000090:mdna:136]

[0000858877-16-000109:mdna:140]
[same as prior period, unchanged from 0000858877-16-000090:mdna:137]

[0000858877-16-000109:mdna:141]
In addition to the primary view on a geographic basis, we also prepare financial information related to groups of similar products and customer markets for various purposes. Our product categories consist of the following categories (with subcategories in parentheses): Switching (fixed switching, modular switching, and storage); NGN Routing (high-end routers, mid-range and low-end routers, and other NGN Routing products); Collaboration (unified communications, Cisco TelePresence, and conferencing); Data Center; Service Provider Video (video software and solutions, and cable access); Wireless; Security; and Other Products. The Other Products category consists primarily of emerging technology products and other networking products.

[0000858877-16-000109:mdna:142]
[same as prior period, unchanged from 0000858877-16-000090:mdna:139]

[0000858877-16-000109:mdna:143]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 30, 2016 |  | April 25, 2015 |  | Variancein Dollars |  | Variance in Percent |  | April 30, 2016 |  | April 25, 2015 |  | Variancein Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Switching |  | $ | 3,447 |  |  | $ | 3,560 |  |  | $ | (113 | ) |  | (3.2 | )% |  | $ | 10,952 |  |  | $ | 11,021 |  |  | $ | (69 | ) |  | (0.6 | )% |
| Percentage of product revenue |  | 38.8 | % |  | 38.2 | % |  |  |  |  |  |  |  | 39.5 | % |  | 39.6 | % |  |  |  |  |  |  |
| NGN Routing |  | 1,894 |  |  | 1,999 |  |  | (105 | ) |  | (5.3 | )% |  | 5,532 |  |  | 5,712 |  |  | (180 | ) |  | (3.2 | )% |
| Percentage of product revenue |  | 21.4 | % |  | 21.4 | % |  |  |  |  |  |  |  | 20.0 | % |  | 20.5 | % |  |  |  |  |  |  |
| Collaboration |  | 1,069 |  |  | 974 |  |  | 95 |  |  | 9.8 | % |  | 3,203 |  |  | 2,915 |  |  | 288 |  |  | 9.9 | % |
| Percentage of product revenue |  | 12.1 | % |  | 10.4 | % |  |  |  |  |  |  |  | 11.6 | % |  | 10.5 | % |  |  |  |  |  |  |
| Data Center |  | 811 |  |  | 801 |  |  | 10 |  |  | 1.2 | % |  | 2,492 |  |  | 2,339 |  |  | 153 |  |  | 6.5 | % |
| Percentage of product revenue |  | 9.1 | % |  | 8.6 | % |  |  |  |  |  |  |  | 9.0 | % |  | 8.4 | % |  |  |  |  |  |  |
| Service ProviderVideo (1) |  | 468 |  |  | 914 |  |  | (446 | ) |  | (48.8 | )% |  | 1,980 |  |  | 2,561 |  |  | (581 | ) |  | (22.7 | )% |
| Percentage of product revenue |  | 5.3 | % |  | 9.8 | % |  |  |  |  |  | 7.1 | % |  | 9.2 | % |  |  |  |  |
| Wireless |  | 615 |  |  | 611 |  |  | 4 |  |  | 0.7 | % |  | 1,873 |  |  | 1,827 |  |  | 46 |  |  | 2.5 | % |
| Percentage of product revenue |  | 6.9 | % |  | 6.6 | % |  |  |  |  |  | 6.8 | % |  | 6.6 | % |  |  |  |  |
| Security |  | 482 |  |  | 412 |  |  | 70 |  |  | 17.0 | % |  | 1,429 |  |  | 1,283 |  |  | 146 |  |  | 11.4 | % |
| Percentage of product revenue |  | 5.4 | % |  | 4.4 | % |  |  |  |  |  |  |  | 5.2 | % |  | 4.6 | % |  |  |  |  |  |  |
| Other |  | 89 |  |  | 55 |  |  | 34 |  |  | 61.8 | % |  | 241 |  |  | 181 |  |  | 60 |  |  | 33.1 | % |
| Percentage of product revenue |  | 1.0 | % |  | 0.6 | % |  |  |  |  |  |  |  | 0.8 | % |  | 0.6 | % |  |  |  |  |  |  |
| Total |  | $ | 8,875 |  |  | $ | 9,326 |  |  | $ | (451 | ) |  | (4.8 | )% |  | $ | 27,702 |  |  | $ | 27,839 |  |  | $ | (137 | ) |  | (0.5 | )% |

[0000858877-16-000109:mdna:144]
(1) Includes SP Video CPE Business revenue of $519 million for the third quarter of fiscal 2015 and $504 million and $1,359 million for the first nine months of fiscal 2016 and 2015, respectively.

[0000858877-16-000109:mdna:145]
[same as prior period, unchanged from 0000858877-16-000090:mdna:142]

[0000858877-16-000109:mdna:146]
[same as prior period, unchanged from 0000858877-16-000090:mdna:143]

[0000858877-16-000109:mdna:147]
[same as prior period, unchanged from 0000858877-16-000090:mdna:144]

[0000858877-16-000109:mdna:148]
[same as prior period, unchanged from 0000858877-16-000090:mdna:145]

[0000858877-16-000109:mdna:149]
Three Months Ended April 30, 2016 Compared with Three Months Ended April 25, 2015

[0000858877-16-000109:mdna:150]
We believe the decrease in revenue in our Switching product category of 3%, or $113 million was driven in large part by the uncertainty in the macro environment which led to a slowdown of customer spending, impacting sales for our Switching products used in campus environments which comprise the majority of this portfolio. This impact was partially offset by an increase in sales of our Switching products used in data center environments which reflects strength in our Application Centric Infrastructure portfolio.

[0000858877-16-000109:mdna:151]
In terms of subcategories, the decrease was driven by a 17%, or $188 million, decrease in revenue from our modular switches due primarily to lower sales of most of our Cisco Catalyst Series Switches and also due to lower sales of our Cisco Nexus 7000 Series Switches, partially offset by sales growth in Cisco Nexus 9500 Series Switches within this product category.  We experienced an increase in revenue from LAN fixed-configuration switches of 2%, or $51 million, and an increase in revenue of a 27%, or $24 million, in sales of storage products. Revenue from our LAN-fixed configuration switches increased due primarily to higher sales of our Cisco Catalyst 3850 Series Switches, Cisco Catalyst 3650 Series Switches, Cisco Nexus 9300 Series Switches, and Cisco Nexus 3000 Series Switches, partially offset by a decrease in sales of certain other products in this portfolio.

[0000858877-16-000109:mdna:152]
Nine Months Ended April 30, 2016 Compared with Nine Months Ended April 25, 2015

[0000858877-16-000109:mdna:153]
Revenue in our Switching product category decreased by 1%, or $69 million, driven by a 10%, or $336 million, decrease in revenue from our modular switches and an 18%, or $71 million, decrease in sales of storage products, partially offset by a 5%, or $337 million, increase in revenue from our LAN fixed-configuration switches. Revenue from our modular switches decreased driven by lower sales of Cisco Catalyst 6500-E Series Switches and Cisco Nexus 7000 Series Switches, partially offset by growth in Cisco Nexus 9500 Series Switches within this product category.  Revenue from LAN fixed-configuration switches increased due to higher sales of our Cisco Catalyst 3850 Series Switches, Cisco Catalyst 3650 Series Switches, Cisco Nexus 9300 Series Switches and Cisco Nexus 3000 Series Switches partially offset by a decrease in sales of certain other products in this portfolio.

[0000858877-16-000109:mdna:154]
[same as prior period, unchanged from 0000858877-16-000090:mdna:151]

[0000858877-16-000109:mdna:155]
Three Months Ended April 30, 2016 Compared with Three Months Ended April 25, 2015

[0000858877-16-000109:mdna:156]
We believe a cautious Service Provider capital expenditure spending environment negatively impacted sales in this product category. Revenue in our NGN Routing product category decreased by 5%, or $105 million, driven by an 8%, or $97 million, decrease in revenue from our high-end router products and a decrease in revenue from what we categorize as other NGN Routing products.     The decrease in revenue from our high-end router products was driven by a decrease in revenue of our Cisco Carrier Routing System (CRS) products, Cisco Network Convergence System (NCS) platform and our legacy high-end router products.  The decrease in revenue from other NGN Routing products was due in large part to lower sales of certain optical networking products. Revenue from our midrange and low-end router products was flat, with higher sales of our Cisco Integrated Services Router (ISR) products being offset by lower sales of certain of our access products.

[0000858877-16-000109:mdna:157]
Nine Months Ended April 30, 2016 Compared with Nine Months Ended April 25, 2015

[0000858877-16-000109:mdna:158]
The decrease in revenue in our NGN Routing product category of 3%, or $180 million, was driven by a 7%, or $254 million, decrease in revenue from our high-end router products, partially offset by a 12%, or $39 million, increase in revenue from other NGN Routing products and a 2%, or $35 million, increase in revenue from our midrange and low-end router products. Revenue from high-end router products decreased due to a decrease in revenue from most of our high-end router products partially offset by higher sales of our CRS-X products. Revenue from other NGN Routing products increased due to higher sales of certain optical networking products. The increase in revenue from our midrange and low-end router products was due to higher sales of our Cisco ISR products and certain of our access products.

[0000858877-16-000109:mdna:159]
[same as prior period, unchanged from 0000858877-16-000090:mdna:156]

[0000858877-16-000109:mdna:160]
Three Months Ended April 30, 2016 Compared with Three Months Ended April 25, 2015

[0000858877-16-000109:mdna:161]
Revenue from our Collaboration product category increased by 10%, or $95 million, driven by growth broadly across the various subcategories within this product category.  The increase in Unified Communications revenue was driven by higher software revenue and increased revenue from phones due to customer migration to our newer endpoints. The growth in Conferencing revenue resulted from higher usage and recurring revenue from WebEx. Revenue from Cisco TelePresence products grew due to higher revenue in endpoint products as a result of new product introductions. We continue to increase the amount of deferred revenue and the proportion of recurring revenue related to our Collaboration product category.

[0000858877-16-000109:mdna:162]
58

[0000858877-16-000109:mdna:163]
[same as prior period, unchanged from 0000858877-16-000090:mdna:160]

[0000858877-16-000109:mdna:164]
[same as prior period, unchanged from 0000858877-16-000090:mdna:161]

[0000858877-16-000109:mdna:165]
Nine Months Ended April 30, 2016 Compared with Nine Months Ended April 25, 2015

[0000858877-16-000109:mdna:166]
Revenue in our Collaboration product category increased by 10%, or $288 million, driven by similar factors as discussed in the three-month period immediately above.

[0000858877-16-000109:mdna:167]
[same as prior period, unchanged from 0000858877-16-000090:mdna:164]

[0000858877-16-000109:mdna:168]
Three Months Ended April 30, 2016 Compared with Three Months Ended April 25, 2015

[0000858877-16-000109:mdna:169]
The increase in revenue in our Data Center product category of 1%, or $10 million, was primarily driven by an increase in sales of our Cisco Unified Computing System products, with growth in the public sector and enterprise markets substantially offset by declines in the service provider and commercial markets.  We believe the uncertainty in the macro environment led to a slowdown of customer spending.  Additionally, we are seeing a market transition with computing workloads shifting from blade server systems to rack-based systems.  Both of these factors we believe adversely impacted the sales of this product category.

[0000858877-16-000109:mdna:170]
Nine Months Ended April 30, 2016 Compared with Nine Months Ended April 25, 2015

[0000858877-16-000109:mdna:171]
Revenue in our Data Center product category grew by 7%, or $153 million, with sales growth of our Cisco Unified Computing System products occurring across all geographic segments and customer markets.

[0000858877-16-000109:mdna:172]
[same as prior period, unchanged from 0000858877-16-000090:mdna:174]

[0000858877-16-000109:mdna:173]
Three Months Ended April 30, 2016 Compared with Three Months Ended April 25, 2015

[0000858877-16-000109:mdna:174]
The decrease in revenue from our Service Provider Video product category of 49%, or $446 million, was driven by a decrease in product sales of $519 million related to our SP Video CPE Business which we sold during the second quarter of fiscal 2016. This decrease was partially offset by an increase in revenue from our video software and solutions driven in large part by strength in APJC, particularly in China, as well as an increase in revenue from certain of our cable access products.

[0000858877-16-000109:mdna:175]
Nine Months Ended April 30, 2016 Compared with Nine Months Ended April 25, 2015

[0000858877-16-000109:mdna:176]
Revenue from our Service Provider Video product category decreased by 23%, or $581 million, due to a decrease in sales of $855 million related to the SP Video CPE Business, partially offset by an increase in revenue from Service Provider Video software and solutions and cable access products.

[0000858877-16-000109:mdna:177]
[same as prior period, unchanged from 0000858877-16-000090:mdna:169]

[0000858877-16-000109:mdna:178]
Three Months Ended April 30, 2016 Compared with Three Months Ended April 25, 2015

[0000858877-16-000109:mdna:179]
Revenue in our Wireless product category increased by 1%, or $4 million, due primarily to continued growth in sales of Meraki products within this product category, partially offset by a decrease in sales of our controllers and access point products. We continue to increase the amount of deferred revenue and the proportion of recurring revenue related to our Wireless product category.

[0000858877-16-000109:mdna:180]
Nine Months Ended April 30, 2016 Compared with Nine Months Ended April 25, 2015

[0000858877-16-000109:mdna:181]
Revenue in our Wireless product category increased by 3%, or $46 million, driven by similar factors as discussed in the three-month period immediately above.

[0000858877-16-000109:mdna:182]
[same as prior period, unchanged from 0000858877-16-000090:mdna:179]

[0000858877-16-000109:mdna:183]
Three Months Ended April 30, 2016 Compared with Three Months Ended April 25, 2015

[0000858877-16-000109:mdna:184]
Revenue in our Security product category was up 17%, or $70 million, driven by higher sales of unified threat management, advanced threat security and web security products. We continue to increase the amount of deferred revenue and the proportion of recurring revenue related to our Security product category.

[0000858877-16-000109:mdna:185]
Nine Months Ended April 30, 2016 Compared with Nine Months Ended April 25, 2015

[0000858877-16-000109:mdna:186]
Revenue from our Security product category grew 11%, or $146 million, driven by higher sales of unified threat management, advanced threat security and web security products, partially offset by a decrease in revenue from our traditional firewall products.

[0000858877-16-000109:mdna:187]
[same as prior period, unchanged from 0000858877-16-000090:mdna:205]

[0000858877-16-000109:mdna:188]
[same as prior period, unchanged from 0000858877-16-000090:mdna:184]

[0000858877-16-000109:mdna:189]
[same as prior period, unchanged from 0000858877-16-000090:mdna:185]

[0000858877-16-000109:mdna:190]
[same as prior period, unchanged from 0000858877-16-000090:mdna:186]

[0000858877-16-000109:mdna:191]
[same as prior period, unchanged from 0000858877-16-000090:mdna:187]

[0000858877-16-000109:mdna:192]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 30, 2016 |  | April 25, 2015 |  | Variancein Dollars |  | Variance in Percent |  | April 30, 2016 |  | April 25, 2015 |  | Variancein Dollars |  | Variance in Percent |
| Service revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 2,006 |  |  | $ | 1,823 |  |  | $ | 183 |  |  | 10.0 | % |  | $ | 5,772 |  |  | $ | 5,498 |  |  | $ | 274 |  |  | 5.0 | % |
| Percentage of service revenue |  | 64.2 | % |  | 64.8 | % |  |  |  |  |  | 64.8 | % |  | 64.9 | % |  |  |  |  |
| EMEA |  | 686 |  |  | 607 |  |  | 79 |  |  | 13.0 | % |  | 1,931 |  |  | 1,824 |  |  | 107 |  |  | 5.9 | % |
| Percentage of service revenue |  | 21.9 | % |  | 21.6 | % |  |  |  |  |  | 21.7 | % |  | 21.5 | % |  |  |  |  |
| APJC |  | 433 |  |  | 381 |  |  | 52 |  |  | 13.6 | % |  | 1,204 |  |  | 1,157 |  |  | 47 |  |  | 4.1 | % |
| Percentage of service revenue |  | 13.9 | % |  | 13.6 | % |  |  |  |  |  | 13.5 | % |  | 13.6 | % |  |  |  |  |
| Total |  | $ | 3,125 |  |  | $ | 2,811 |  |  | $ | 314 |  |  | 11.2 | % |  | $ | 8,907 |  |  | $ | 8,479 |  |  | $ | 428 |  |  | 5.0 | % |

[0000858877-16-000109:mdna:193]
Three Months Ended April 30, 2016 Compared with Three Months Ended April 25, 2015

[0000858877-16-000109:mdna:194]
Service revenue grew 11%, which includes the $200 million, or a 7% year over year increase as a result of the impact of the extra week in the third quarter of fiscal 2016. Service revenue had solid growth across all of our geographic segments. Worldwide technical support services revenue and worldwide advanced services revenue each increased by 11%. Technical support services revenue increased across all geographic segments. Renewals and technical support service contract initiations associated with product sales provided an installed base of equipment being serviced which, in concert with new service offerings, were the primary factors driving the revenue increases. Advanced services revenue, which relates to professional services for specific customer network needs, grew across all geographic segments.

[0000858877-16-000109:mdna:195]
Nine Months Ended April 30, 2016 Compared with Nine Months Ended April 25, 2015

[0000858877-16-000109:mdna:196]
Service revenue increased across all of our geographic segments. Worldwide technical support services revenue increased 4% and worldwide advanced services revenue increased 9% revenue growth. Technical support services revenue experienced relatively balanced growth across all geographic segments.  Advanced services revenue had a solid growth in the Americas and EMEA segments but was flat in the APJC segment.

[0000858877-16-000109:mdna:197]
[same as prior period, unchanged from 0000858877-16-000090:mdna:220]

[0000858877-16-000109:mdna:198]
[same as prior period, unchanged from 0000858877-16-000090:mdna:193]

[0000858877-16-000109:mdna:199]
[same as prior period, unchanged from 0000858877-16-000090:mdna:194]

[0000858877-16-000109:mdna:200]
[same as prior period, unchanged from 0000858877-16-000090:mdna:195]

[0000858877-16-000109:mdna:201]
[same as prior period, unchanged from 0000858877-16-000090:mdna:196]

[0000858877-16-000109:mdna:202]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | AMOUNT |  | PERCENTAGE |  | AMOUNT |  | PERCENTAGE |
|  |  | April 30, 2016 |  | April 25, 2015 |  | April 30, 2016 |  | April 25, 2015 |  | April 30, 2016 |  | April 25, 2015 |  | April 30, 2016 |  | April 25, 2015 |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 5,661 |  |  | $ | 5,742 |  |  | 63.8 | % |  | 61.6 | % |  | $ | 17,155 |  |  | $ | 16,530 |  |  | 61.9 | % |  | 59.4 | % |
| Service |  | 2,060 |  |  | 1,783 |  |  | 65.9 | % |  | 63.4 | % |  | 5,830 |  |  | 5,418 |  |  | 65.5 | % |  | 63.9 | % |
| Total |  | $ | 7,721 |  |  | $ | 7,525 |  |  | 64.3 | % |  | 62.0 | % |  | $ | 22,985 |  |  | $ | 21,948 |  |  | 62.8 | % |  | 60.4 | % |

[0000858877-16-000109:mdna:203]
[same as prior period, unchanged from 0000858877-16-000090:mdna:198]

[0000858877-16-000109:mdna:204]
The following table summarizes the key factors that contributed to the change in product gross margin percentage for the third quarter and first nine months of fiscal 2016 as compared with the corresponding prior year period:

[0000858877-16-000109:mdna:205]
|  |  | Product Gross Margin Percentage |
|  |  | Three Months Ended |  | Nine Months Ended |
| Fiscal 2015 |  | 61.6 | % |  | 59.4 | % |
| Productivity (1) |  | 3.3 | % |  | 3.6 | % |
| SP Video CPE Business impact |  | 2.7 | % |  | 1.3 | % |
| Amortization of purchased intangible assets |  | 0.5 | % |  | 0.7 | % |
| Rockstar patent portfolio charge |  | — | % |  | 0.7 | % |
| Product pricing |  | (2.4 | )% |  | (2.2 | )% |
| Mix of products sold |  | (0.9 | )% |  | (1.2 | )% |
| Supplier component remediation adjustment |  | (0.9 | )% |  | (0.3 | )% |
| Other |  | (0.1 | )% |  | (0.1 | )% |
| Fiscal 2016 |  | 63.8 | % |  | 61.9 | % |

[0000858877-16-000109:mdna:206]
[same as prior period, unchanged from 0000858877-16-000090:mdna:201]

[0000858877-16-000109:mdna:207]
Three Months Ended April 30, 2016 Compared with Three Months Ended April 25, 2015

[0000858877-16-000109:mdna:208]
Product gross margin increased by 2.2 percentage points as compared with the third quarter of fiscal 2015. The increase in product gross margin was due to productivity improvements, which were driven by value engineering efforts; favorable component pricing; and continued operational efficiency in manufacturing operations. Value engineering is the process by which production costs are reduced through component redesign, board configuration, test processes, and transformation processes. Our product gross margin also benefited from the sale during the second quarter of fiscal 2016 of our lower margin SP Video CPE Business, and lower amortization expense related to acquisition-related intangible assets. The various factors contributing to the product gross margin increase were partially offset by unfavorable impacts from product pricing, which were driven by typical market factors and impacted each of our geographic segments and customer markets, an unfavorable mix of products sold and a lower supplier component remediation adjustment. The unfavorable mix of products sold was due to a negative mix impact from our relatively lower margin Cisco Unified Computing System products, higher sales of Service Provider Video products (not including the CPE Business) and lower sales of Switching products.

[0000858877-16-000109:mdna:209]
[same as prior period, unchanged from 0000858877-16-000090:mdna:206]

[0000858877-16-000109:mdna:210]
[same as prior period, unchanged from 0000858877-16-000090:mdna:207]

[0000858877-16-000109:mdna:211]
Our future gross margins could be impacted by our product mix and could be adversely affected by further growth in sales of products that have lower gross margins, such as Cisco Unified Computing System products. Our gross margins may also be impacted by the geographic mix of our revenue and, as was the case in the first nine months of fiscal 2016 and in fiscal 2015, may be adversely affected by product pricing attributable to competitive factors. Additionally, our manufacturing-related costs may be negatively impacted by constraints in our supply chain, which in turn could negatively affect gross margin. If any of the preceding factors that in the past have negatively impacted our gross margins arise in future periods, our gross margins could continue to decline.

[0000858877-16-000109:mdna:212]
Nine Months Ended April 30, 2016 Compared with Nine Months Ended April 25, 2015

[0000858877-16-000109:mdna:213]
Product gross margin increased by 2.5 percentage points as compared with the first nine months of fiscal 2015. The increase was due to productivity improvements driven by similar factors as discussed in the three-month period immediately above.  Additionally, gross margin increased due to the impact of the sale during the second quarter of fiscal 2016 of our lower margin SP Video CPE Business, lower amortization expense and impairment charges related to acquisition-related intangible assets and a $188 million charge to product cost of sales recorded in the first quarter of fiscal 2015 related to the Rockstar patent portfolio. These factors were partially offset by unfavorable impacts from product pricing, unfavorable mix of products sold and the impact of a lower supplier component remediation adjustment. The unfavorable product mix impact was due to an unfavorable mix impact from our core products, increased revenue from our relatively lower margin Cisco Unified Computing System products and higher sales from our Service Provider Video products (not including the SP Video CPE Business).

[0000858877-16-000109:mdna:214]
[same as prior period, unchanged from 0000858877-16-000090:mdna:210]

[0000858877-16-000109:mdna:215]
Three Months Ended April 30, 2016 Compared with Three Months Ended April 25, 2015

[0000858877-16-000109:mdna:216]
Our service gross margin percentage increased by 2.5 percentage points as compared with the third quarter of fiscal 2015 due to higher sales volume and, to a lesser extent, lower headcount-related costs. These benefits to gross margin were partially offset by increased outside services costs and partner delivery costs.

[0000858877-16-000109:mdna:217]
[same as prior period, unchanged from 0000858877-16-000090:mdna:213]

[0000858877-16-000109:mdna:218]
Nine Months Ended April 30, 2016 Compared with Nine Months Ended April 25, 2015

[0000858877-16-000109:mdna:219]
Service gross margin percentage increased by 1.6 percentage points, as compared with the first nine months of fiscal 2015, due to higher sales volume and decreased headcount-related costs. These benefits to gross margin were partially offset by increased partner delivery costs and unfavorable mix. The mix impacts were due to our lower gross margin advanced services business contributing a higher proportion of service revenue for the first nine months of fiscal 2016 as compared with the first nine months of fiscal 2015

[0000858877-16-000109:mdna:220]
[same as prior period, unchanged from 0000858877-16-000090:mdna:221]

[0000858877-16-000109:mdna:221]
[same as prior period, unchanged from 0000858877-16-000090:mdna:222]

[0000858877-16-000109:mdna:222]
[same as prior period, unchanged from 0000858877-16-000090:mdna:216]

[0000858877-16-000109:mdna:223]
[same as prior period, unchanged from 0000858877-16-000090:mdna:217]

[0000858877-16-000109:mdna:224]
|  | Three Months Ended |  | Nine Months Ended |
|  | AMOUNT |  | PERCENTAGE |  | AMOUNT |  | PERCENTAGE |
|  | April 30, 2016 |  | April 25, 2015 |  | April 30, 2016 |  | April 25, 2015 |  | April 30, 2016 |  | April 25, 2015 |  | April 30, 2016 |  | April 25, 2015 |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 4,684 |  |  | $ | 4,560 |  |  | 66.3 | % |  | 62.9 | % |  | $ | 14,046 |  |  | $ | 13,776 |  |  | 64.5 | % |  | 63.0 | % |
| EMEA | 1,966 |  |  | 1,949 |  |  | 65.5 | % |  | 62.5 | % |  | 5,953 |  |  | 5,774 |  |  | 64.9 | % |  | 62.7 | % |
| APJC | 1,170 |  |  | 1,080 |  |  | 60.4 | % |  | 61.2 | % |  | 3,437 |  |  | 3,157 |  |  | 60.7 | % |  | 60.1 | % |
| Segment total | 7,820 |  |  | 7,589 |  |  | 65.2 | % |  | 62.5 | % |  | 23,436 |  |  | 22,707 |  |  | 64.0 | % |  | 62.5 | % |
| Unallocated corporate items (1) | (99 | ) |  | (64 | ) |  |  |  |  |  | (451 | ) |  | (759 | ) |  |  |  |  |
| Total | $ | 7,721 |  |  | $ | 7,525 |  |  | 64.3 | % |  | 62.0 | % |  | $ | 22,985 |  |  | $ | 21,948 |  |  | 62.8 | % |  | 60.4 | % |

[0000858877-16-000109:mdna:225]
(1) The unallocated corporate items for the periods presented include the effects of amortization and impairments of acquisition-related intangible assets, share-based compensation expense, significant litigation and other contingencies, charges related to asset impairments and restructurings, and certain other charges. We do not allocate these items to the gross margin for each segment because management does not include such information in measuring the performance of the operating segments.

[0000858877-16-000109:mdna:226]
Three Months Ended April 30, 2016 Compared with Three Months Ended April 25, 2015

[0000858877-16-000109:mdna:227]
The Americas segment experienced a gross margin percentage increase due primarily to the sale of the lower margin SP Video CPE Business. In this geographic segment, productivity improvements were substantially offset by unfavorable impacts from pricing and product mix. The unfavorable mix of products sold was due to a negative mix impact from our relatively lower margin Cisco Unified Computing System products and from Service Provider Video products (not including the SP Video CPE Business).

[0000858877-16-000109:mdna:228]
The gross margin percentage increase in our EMEA segment was due primarily to the impact of productivity improvements in this geographic segment and the sale of the SP Video CPE Business. Partially offsetting these favorable impacts to gross margin were negative impacts from pricing and an unfavorable product mix. Higher service gross margin also contributed to the increase in the overall gross margin in this geographic segment.

[0000858877-16-000109:mdna:229]
Our APJC segment gross margin percentage decreased primarily due to unfavorable impacts from pricing and mix partially offset by productivity improvements. The mix impact was driven primarily by unfavorable mix within our NGN routing products and an increase in revenue from our relatively lower margin Cisco Unified Computing System products.

[0000858877-16-000109:mdna:230]
[same as prior period, unchanged from 0000858877-16-000090:mdna:227]

[0000858877-16-000109:mdna:231]
Nine Months Ended April 30, 2016 Compared with Nine Months Ended April 25, 2015

[0000858877-16-000109:mdna:232]
We experienced a gross margin percentage increase in our Americas segment due to productivity improvements and the sale of the SP Video CPE Business, partially offset by unfavorable impacts from pricing and mix. The product mix impact was due to an unfavorable mix impact from our core products, increased revenue from our relatively lower margin Cisco Unified Computing System products and higher sales from our Service Provider Video products (not including the SP Video CPE Business).

[0000858877-16-000109:mdna:233]
The gross margin percentage increase in our EMEA segment was due primarily to the impact of productivity improvements in this geographic segment and the sale of the lower margin SP Video CPE Business. Partially offsetting these favorable impacts to gross margin were negative impacts from pricing and an unfavorable product mix. The unfavorable mix of products sold was due to increased revenue from our relatively lower margin Cisco Unified Computing System products and lower sales of Switching products. Higher service gross margin also contributed to the increase in the overall gross margin in this geographic segment.

[0000858877-16-000109:mdna:234]
The APJC segment gross margin percentage increased due to productivity improvements partially offset by unfavorable impacts from pricing and mix. The product mix impact was due to an unfavorable mix impact from our core products, higher sales from our Service Provider Video products (not including the SP Video CPE Business) and increased revenue from our relatively lower margin Cisco Unified Computing System products.

[0000858877-16-000109:mdna:235]
[same as prior period, unchanged from 0000858877-16-000090:mdna:232]

[0000858877-16-000109:mdna:236]
[same as prior period, unchanged from 0000858877-16-000090:mdna:233]

[0000858877-16-000109:mdna:237]
[same as prior period, unchanged from 0000858877-16-000090:mdna:234]

[0000858877-16-000109:mdna:238]
[same as prior period, unchanged from 0000858877-16-000090:mdna:235]

[0000858877-16-000109:mdna:239]
[same as prior period, unchanged from 0000858877-16-000090:mdna:236]

[0000858877-16-000109:mdna:240]
[same as prior period, unchanged from 0000858877-16-000090:mdna:237]

[0000858877-16-000109:mdna:241]
[same as prior period, unchanged from 0000858877-16-000090:mdna:238]

[0000858877-16-000109:mdna:242]
[same as prior period, unchanged from 0000858877-16-000090:mdna:239]

[0000858877-16-000109:mdna:243]
[same as prior period, unchanged from 0000858877-16-000090:mdna:240]

[0000858877-16-000109:mdna:244]
[same as prior period, unchanged from 0000858877-16-000090:mdna:241]

[0000858877-16-000109:mdna:245]
[same as prior period, unchanged from 0000858877-16-000090:mdna:242]

[0000858877-16-000109:mdna:246]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 30, 2016 |  | April 25, 2015 |  | Variancein Dollars |  | Variance in Percent |  | April 30, 2016 |  | April 25, 2015 |  | Variancein Dollars |  | Variance in Percent |
| Research and development | $ | 1,626 |  |  | $ | 1,547 |  |  | $ | 79 |  |  | 5.1 | % |  | $ | 4,695 |  |  | $ | 4,659 |  |  | $ | 36 |  |  | 0.8 | % |
| Percentage of revenue | 13.6 | % |  | 12.7 | % |  |  |  |  |  | 12.8 | % |  | 12.8 | % |  |  |  |  |
| Sales and marketing | 2,447 |  |  | 2,449 |  |  | (2 | ) |  | (0.1 | )% |  | 7,176 |  |  | 7,272 |  |  | (96 | ) |  | (1.3 | )% |
| Percentage of revenue | 20.4 | % |  | 20.2 | % |  |  |  |  |  | 19.6 | % |  | 20.0 | % |  |  |  |  |
| General and administrative | 566 |  |  | 510 |  |  | 56 |  |  | 11.0 | % |  | 1,281 |  |  | 1,504 |  |  | (223 | ) |  | (14.8 | )% |
| Percentage of revenue | 4.7 | % |  | 4.2 | % |  |  |  |  |  | 3.5 | % |  | 4.1 | % |  |  |  |  |
| Total | $ | 4,639 |  |  | $ | 4,506 |  |  | $ | 133 |  |  | 3.0 | % |  | $ | 13,152 |  |  | $ | 13,435 |  |  | $ | (283 | ) |  | (2.1 | )% |
| Percentage of revenue | 38.7 | % |  | 37.1 | % |  |  |  |  |  | 35.9 | % |  | 37.0 | % |  |  |  |  |

[0000858877-16-000109:mdna:247]
Our third quarter of fiscal 2016 had an extra week compared with the corresponding period of fiscal 2015. We estimate that the extra week contributed approximately $116 million of the year-over-year increase in total operating expenses (not including share-based compensation expense discussed below) during the third quarter and first nine months of fiscal 2016.

[0000858877-16-000109:mdna:248]
[same as prior period, unchanged from 0000858877-16-000090:mdna:244]

[0000858877-16-000109:mdna:249]
R&D expenses increased for the third quarter and first nine months of fiscal 2016, as compared with the corresponding periods of fiscal 2015, primarily due to higher headcount-related expenses attributable in large part to the impact of the extra week in the third quarter and first nine months of fiscal 2016 and, to a lesser extent, higher share-based compensation expense and higher contracted services. These increases were partially offset by lower acquisition-related costs and lower discretionary spending.

[0000858877-16-000109:mdna:250]
[same as prior period, unchanged from 0000858877-16-000090:mdna:246]

[0000858877-16-000109:mdna:251]
[same as prior period, unchanged from 0000858877-16-000090:mdna:247]

[0000858877-16-000109:mdna:252]
Sales and marketing expenses decreased for the third quarter and first nine months of fiscal 2016, compared with the corresponding periods of fiscal 2015, due to lower discretionary spending and lower contracted services partially offset by higher headcount-related expenses. The extra week in the third quarter and first nine months of fiscal 2016 contributed to the increased headcount-related expenses.

[0000858877-16-000109:mdna:253]
[same as prior period, unchanged from 0000858877-16-000090:mdna:249]

[0000858877-16-000109:mdna:254]
G&A expenses increased in the third quarter of fiscal 2016, as compared with the third quarter of fiscal 2015, due to higher headcount-related expenses and, to a lesser extent, higher share-based compensation expense.  The extra week in the third quarter of fiscal 2016 contributed to the increased headcount-related expenses. The timing of corporate-level expenses, which tend to vary from period to period, also contributed to the increase. Corporate-level expenses included operational infrastructure activities such as IT project implementations, which included investments in our global data center infrastructure, and investments related to operational and financial systems.

[0000858877-16-000109:mdna:255]
G&A expenses decreased in the first nine months of fiscal 2016, as compared with the first nine months of fiscal 2015, primarily due to the $285 million pre-tax gain from the sale of our SP Video CPE Business and, to a lesser extent, lower contracted services partially offset by higher headcount-related expenses and higher share-based compensation expense. The extra week in the first nine months of fiscal 2016 contributed to the increased headcount-related expenses.

[0000858877-16-000109:mdna:256]
[same as prior period, unchanged from 0000858877-16-000090:mdna:251]

[0000858877-16-000109:mdna:257]
In the third quarter of fiscal 2016, foreign currency fluctuations, net of hedging, decreased the combined R&D, sales and marketing, and G&A expenses by approximately $125 million, or approximately 2.8%, compared with the third quarter of fiscal 2015.

[0000858877-16-000109:mdna:258]
In the first nine months of fiscal 2016, foreign currency fluctuations, net of hedging, decreased the combined R&D, sales and marketing, and G&A expenses by approximately $481 million, or approximately 3.6%, compared with the first nine months of fiscal 2015.

[0000858877-16-000109:mdna:259]
[same as prior period, unchanged from 0000858877-16-000090:mdna:255]

[0000858877-16-000109:mdna:260]
[same as prior period, unchanged from 0000858877-16-000090:mdna:256]

[0000858877-16-000109:mdna:261]
[same as prior period, unchanged from 0000858877-16-000090:mdna:257]

[0000858877-16-000109:mdna:262]
Our headcount as of April 30, 2016 was 73,104, which represents an increase of 1,447 employees in the third quarter of fiscal 2016 and an increase of 1,271 employees in the first nine months of fiscal 2016, as compared with the total headcount at the end of fiscal 2015. The increase for both periods was due to headcount additions from targeted hiring in key growth areas in engineering, services and sales, and headcount additions from our recent acquisitions. These headcount additions were partially offset by headcount reductions from attrition, from our restructuring plan announced in August 2014, and from the sale of the SP Video CPE Business.

[0000858877-16-000109:mdna:263]
[same as prior period, unchanged from 0000858877-16-000090:mdna:259]

[0000858877-16-000109:mdna:264]
[same as prior period, unchanged from 0000858877-16-000090:mdna:260]

[0000858877-16-000109:mdna:265]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 30, 2016 |  | April 25, 2015 |  | April 30, 2016 |  | April 25, 2015 |
| Cost of sales—product | $ | 21 |  |  | $ | 12 |  |  | $ | 50 |  |  | $ | 34 |  |
| Cost of sales—service | 37 |  |  | 44 |  |  | 110 |  |  | 115 |  |
| Share-based compensation expense in cost of sales | 58 |  |  | 56 |  |  | 160 |  |  | 149 |  |
| Research and development | 130 |  |  | 114 |  |  | 351 |  |  | 338 |  |
| Sales and marketing | 148 |  |  | 147 |  |  | 413 |  |  | 408 |  |
| General and administrative | 59 |  |  | 50 |  |  | 163 |  |  | 151 |  |
| Restructuring and other charges | — |  |  | — |  |  | 14 |  |  | (2 | ) |
| Share-based compensation expense in operating expenses | 337 |  |  | 311 |  |  | 941 |  |  | 895 |  |
| Total share-based compensation expense | $ | 395 |  |  | $ | 367 |  |  | $ | 1,101 |  |  | $ | 1,044 |  |

[0000858877-16-000109:mdna:266]
The increase in share-based compensation expense in the third quarter of fiscal 2016, as compared with the third quarter of fiscal 2015, was due primarily to the impact of the extra week in the third quarter of fiscal 2016 and higher expense related to equity awards assumed with respect to our recent acquisitions. The increase in share-based compensation expense in the first nine months of fiscal 2016, as compared with the corresponding period of fiscal 2015, was due primarily to the timing of the RSU grants and the impact of the extra week in the first nine months of fiscal 2016, partially offset by lower expense associated with accelerated and modified awards.

[0000858877-16-000109:mdna:267]
[same as prior period, unchanged from 0000858877-16-000090:mdna:263]

[0000858877-16-000109:mdna:268]
[same as prior period, unchanged from 0000858877-16-000090:mdna:264]

[0000858877-16-000109:mdna:269]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 30, 2016 |  | April 25, 2015 |  | April 30, 2016 |  | April 25, 2015 |
| Amortization of purchased intangible assets: |  |  |  |  |  |  |  |
| Cost of sales | $ | 134 |  |  | $ | 187 |  |  | $ | 419 |  |  | $ | 618 |  |
| Operating expenses | 81 |  |  | 70 |  |  | 221 |  |  | 213 |  |
| Total | $ | 215 |  |  | $ | 257 |  |  | $ | 640 |  |  | $ | 831 |  |

[0000858877-16-000109:mdna:270]
Amortization of purchased intangible assets decreased for the third quarter and first nine months of fiscal 2016, as compared with the corresponding periods of fiscal 2015, due to certain purchased intangible assets having become fully amortized or impaired partially offset by amortization of purchased intangible assets from our recent acquisitions. Lower impairment charges for the first nine months of fiscal 2016 also contributed to the decrease.

[0000858877-16-000109:mdna:271]
[same as prior period, unchanged from 0000858877-16-000090:mdna:267]

[0000858877-16-000109:mdna:272]
[same as prior period, unchanged from 0000858877-16-000090:mdna:268]

[0000858877-16-000109:mdna:273]
[same as prior period, unchanged from 0000858877-16-000090:mdna:269]

[0000858877-16-000109:mdna:274]
[same as prior period, unchanged from 0000858877-16-000090:mdna:270]

[0000858877-16-000109:mdna:275]
In the third quarter and first nine months of fiscal 2016, we incurred restructuring and other charges of approximately $17 million and $253 million, net of a $2 million credit to cost of sales, respectively. These charges were related primarily to employee severance charges for employees impacted by the restructuring action announced in August 2014, which is substantially complete. We plan to reinvest substantially all of the cost savings from the restructuring actions in key growth areas of our business such as data center, software, security, and cloud. The overall cost savings from these restructuring actions were not material for the periods presented and are not expected to be material for future periods.

[0000858877-16-000109:mdna:276]
In the third quarter and first nine months of fiscal 2015, we incurred restructuring and other charges of approximately $24 million and $411 million, respectively, which were related primarily to employee severance charges for employees impacted by the restructuring action announced in August 2014. See Note 5 to the Consolidated Financial Statements.

[0000858877-16-000109:mdna:277]
[same as prior period, unchanged from 0000858877-16-000090:mdna:273]

[0000858877-16-000109:mdna:278]
[same as prior period, unchanged from 0000858877-16-000090:mdna:274]

[0000858877-16-000109:mdna:279]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 30, 2016 |  | April 25, 2015 |  | April 30, 2016 |  | April 25, 2015 |
| Operating income |  | $ | 2,984 |  |  | $ | 2,925 |  |  | $ | 9,357 |  |  | $ | 7,889 |  |
| Operating income as a percentage of revenue |  | 24.9 | % |  | 24.1 | % |  | 25.6 | % |  | 21.7 | % |

[0000858877-16-000109:mdna:280]
For the third quarter of fiscal 2016, as compared with the third quarter of fiscal 2015, operating income increased by 2%, and as a percentage of revenue operating income increased by 0.8 percentage points. The increase as a percentage of revenue resulted primarily from a gross margin increase driven by the sale of the lower margin SP Video CPE Business during the second quarter of fiscal 2016 and lower amortization expense related to acquisition-related intangible assets.

[0000858877-16-000109:mdna:281]
For the first nine months of fiscal 2016, as compared with the first nine months of fiscal 2015, operating income increased by 19%, and as a percentage of revenue operating income increased by 3.9 percentage points. The increase resulted from the following: an increase in revenue; a gross margin percentage increase, driven by similar factors as discussed in the three month period immediately above and in part by the Rockstar patent portfolio charge of $188 million (or 0.8 percentage points of the prior period revenue); the $285 million pre-tax gain from the sale of our SP Video CPE Business; and a decrease in restructuring and other charges related to the restructuring action announced in August 2014.

[0000858877-16-000109:mdna:282]
[same as prior period, unchanged from 0000858877-16-000090:mdna:278]

[0000858877-16-000109:mdna:283]
[same as prior period, unchanged from 0000858877-16-000090:mdna:279]

[0000858877-16-000109:mdna:284]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 30, 2016 |  | April 25, 2015 |  | Variancein Dollars |  | April 30, 2016 |  | April 25, 2015 |  | Variancein Dollars |
| Interest income |  | $ | 270 |  |  | $ | 190 |  |  | $ | 80 |  |  | $ | 732 |  |  | $ | 558 |  |  | $ | 174 |  |
| Interest expense |  | (175 | ) |  | (139 | ) |  | (36 | ) |  | (496 | ) |  | (417 | ) |  | (79 | ) |
| Interest income (expense), net |  | $ | 95 |  |  | $ | 51 |  |  | $ | 44 |  |  | $ | 236 |  |  | $ | 141 |  |  | $ | 95 |  |

[0000858877-16-000109:mdna:285]
For the third quarter and first nine months of fiscal 2016, interest income increased compared with the corresponding periods in fiscal 2015, driven by an increase in our portfolio of cash, cash equivalents, and fixed income investments as well as higher yields on our portfolio of cash and investments. Interest expense in the third quarter and first nine months of fiscal 2016, compared with the corresponding periods in fiscal 2015, was higher driven by higher average debt balances.

[0000858877-16-000109:mdna:286]
[same as prior period, unchanged from 0000858877-16-000090:mdna:282]

[0000858877-16-000109:mdna:287]
[same as prior period, unchanged from 0000858877-16-000090:mdna:283]

[0000858877-16-000109:mdna:288]
[same as prior period, unchanged from 0000858877-16-000090:mdna:284]

[0000858877-16-000109:mdna:289]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 30, 2016 |  | April 25, 2015 |  | Variancein Dollars |  | April 30, 2016 |  | April 25, 2015 |  | Variancein Dollars |
| Gains (losses) on investments, net: |  |  |  |  |  |  |  |  |  |  |  |  |
| Publicly traded equity securities |  | $ | 25 |  |  | $ | 38 |  |  | $ | (13 | ) |  | $ | 18 |  |  | $ | 94 |  |  | $ | (76 | ) |
| Fixed income securities |  | (31 | ) |  | 6 |  |  | (37 | ) |  | (44 | ) |  | 26 |  |  | (70 | ) |
| Total available-for-sale investments |  | (6 | ) |  | 44 |  |  | (50 | ) |  | (26 | ) |  | 120 |  |  | (146 | ) |
| Privately held companies |  | 22 |  |  | 3 |  |  | 19 |  |  | (25 | ) |  | 104 |  |  | (129 | ) |
| Net gains (losses) on investments |  | 16 |  |  | 47 |  |  | (31 | ) |  | (51 | ) |  | 224 |  |  | (275 | ) |
| Other gains (losses), net |  | (12 | ) |  | 12 |  |  | (24 | ) |  | (16 | ) |  | 14 |  |  | (30 | ) |
| Other income (loss), net |  | $ | 4 |  |  | $ | 59 |  |  | $ | (55 | ) |  | $ | (67 | ) |  | $ | 238 |  |  | $ | (305 | ) |

[0000858877-16-000109:mdna:290]
The change in total net gains (losses) on available-for-sale investments in the third quarter and first nine months of fiscal 2016, as compared with the corresponding periods in fiscal 2015, was primarily attributable to lower realized gains on publicly traded equity securities and higher losses on fixed income securities in the current periods as a result of market conditions and the timing of sales of these securities.

[0000858877-16-000109:mdna:291]
The change in net gains (losses) on investments in privately held companies for the third quarter of fiscal 2016, as compared with the third quarter of fiscal 2015, was primarily due to higher realized gains from equity method investments and lower impairment charges on investments in privately held companies. The change in net gains (losses) on investments in privately held companies for the first nine months of fiscal 2016, as compared with the first nine months of fiscal 2015, was primarily due to a gain of $126 million related to the reorganization of our investment in VCE Company, LLC, which was recorded in the second quarter of fiscal 2015, higher impairment charges on investments in privately held companies, and lower realized gains from cost method investments partially offset by higher realized gains from equity method investments.

[0000858877-16-000109:mdna:292]
The change in other gains (losses), net in the third quarter and first nine months of fiscal 2016, as compared with the corresponding periods in fiscal 2015, was driven by net unfavorable foreign exchange impacts, higher donation expenses and impacts from equity derivatives.

[0000858877-16-000109:mdna:293]
[same as prior period, unchanged from 0000858877-16-000090:mdna:289]

[0000858877-16-000109:mdna:294]
[same as prior period, unchanged from 0000858877-16-000090:mdna:290]

[0000858877-16-000109:mdna:295]
The provision for income taxes resulted in an effective tax rate of 23.8% for the third quarter of fiscal 2016 compared with 19.7% for the third quarter of fiscal 2015, a net 4.1 percentage point increase in the effective tax rate for the third quarter of fiscal 2016 as compared with the third quarter of fiscal 2015. The increase in the effective tax rates was primarily due to an increase in net tax charges associated with tax settlements in certain foreign jurisdictions and a decrease in tax benefits related to lapses in statute of limitations in certain foreign jurisdictions.

[0000858877-16-000109:mdna:296]
The provision for income taxes resulted in an effective tax rate of 16.8% for the first nine months of fiscal 2016, as compared with an effective tax rate of 19.4% for the first nine months of fiscal 2015, a net 2.6 percentage point decrease in the effective tax rate for the first nine months of fiscal 2016 as compared with the first nine months of fiscal 2015. The decrease in the effective tax rates was primarily due to the recognition of a net benefit to the provision for income taxes of $367 million related to our settlement with the IRS in January 2016, offset by a decrease in foreign income taxed at lower than U.S. rates.  See Note 16 to the Consolidated Financial Statements.

[0000858877-16-000109:mdna:297]
[same as prior period, unchanged from 0000858877-16-000090:mdna:292]

[0000858877-16-000109:mdna:298]
[same as prior period, unchanged from 0000858877-16-000090:mdna:293]

[0000858877-16-000109:mdna:299]
[same as prior period, unchanged from 0000858877-16-000090:mdna:294]

[0000858877-16-000109:mdna:300]
[same as prior period, unchanged from 0000858877-16-000090:mdna:295]

[0000858877-16-000109:mdna:301]
[same as prior period, unchanged from 0000858877-16-000090:mdna:296]

[0000858877-16-000109:mdna:302]
[same as prior period, unchanged from 0000858877-16-000090:mdna:297]

[0000858877-16-000109:mdna:303]
|  | April 30, 2016 |  | July 25, 2015 |  | Increase (Decrease) |
| Cash and cash equivalents | $ | 8,895 |  |  | $ | 6,877 |  |  | $ | 2,018 |  |
| Fixed income securities | 53,075 |  |  | 51,974 |  |  | 1,101 |  |
| Publicly traded equity securities | 1,542 |  |  | 1,565 |  |  | (23 | ) |
| Total | $ | 63,512 |  |  | $ | 60,416 |  |  | $ | 3,096 |  |

[0000858877-16-000109:mdna:304]
The net increase in cash and cash equivalents and investments in the first nine months of fiscal 2016 was primarily the result of cash provided by operating activities of $9.8 billion, a net increase in debt of $3.1 billion, net proceeds from issuance of common stock of $0.8 billion pursuant to employee stock incentive and purchase plans, and net proceeds from the sale of our SP Video CPE Business of $0.4 billion. These sources of cash were partially offset by cash returned to shareholders in the form of cash dividends of $3.4 billion and repurchase of common stock of $3.2 billion under the stock repurchase program, net cash paid for acquisitions of $3.2 billion, and capital expenditures of $0.9 billion.

[0000858877-16-000109:mdna:305]
Our total in cash and cash equivalents and investments held by various foreign subsidiaries was $57.2 billion and $53.4 billion as of April 30, 2016 and July 25, 2015, respectively. Under current tax laws and regulations, if these assets were to be distributed from the foreign subsidiaries to the United States in the form of dividends or otherwise, we would be subject to additional U.S. income taxes (subject to an adjustment for foreign tax credits) and foreign withholding taxes. The balance of cash and cash equivalents and investments available in the United States as of April 30, 2016 and July 25, 2015 was $6.3 billion and $7.0 billion, respectively.

[0000858877-16-000109:mdna:306]
[same as prior period, unchanged from 0000858877-16-000090:mdna:301]

[0000858877-16-000109:mdna:307]
[same as prior period, unchanged from 0000858877-16-000090:mdna:302]

[0000858877-16-000109:mdna:308]
[same as prior period, unchanged from 0000858877-16-000090:mdna:303]

[0000858877-16-000109:mdna:309]
|  | Nine Months Ended |
|  | April 30, 2016 |  | April 25, 2015 |
| Net cash provided by operating activities | $ | 9,752 |  |  | $ | 8,414 |  |
| Acquisition of property and equipment | (880 | ) |  | (907 | ) |
| Free cash flow | $ | 8,872 |  |  | $ | 7,507 |  |

[0000858877-16-000109:mdna:310]
[same as prior period, unchanged from 0000858877-16-000090:mdna:305]

[0000858877-16-000109:mdna:311]
[same as prior period, unchanged from 0000858877-16-000090:mdna:306]

[0000858877-16-000109:mdna:312]
[same as prior period, unchanged from 0000858877-16-000090:mdna:307]

[0000858877-16-000109:mdna:313]
[same as prior period, unchanged from 0000858877-16-000090:mdna:308]

[0000858877-16-000109:mdna:314]
[same as prior period, unchanged from 0000858877-16-000090:mdna:309]

[0000858877-16-000109:mdna:315]
|  |  | DIVIDENDS |  | STOCK REPURCHASE PROGRAM |  |  |
| Quarter Ended |  | Per Share |  | Amount |  | Shares |  | Weighted-Average Price per Share |  | Amount |  | TOTAL |
| Fiscal 2016 |  |  |  |  |  |  |  |  |  |  |  |  |
| April 30, 2016 |  | $ | 0.26 |  |  | $ | 1,308 |  |  | 27 |  |  | $ | 24.08 |  |  | $ | 649 |  |  | $ | 1,957 |  |
| January 23, 2016 |  | $ | 0.21 |  |  | $ | 1,065 |  |  | 48 |  |  | $ | 26.12 |  |  | $ | 1,262 |  |  | $ | 2,327 |  |
| October 24, 2015 |  | $ | 0.21 |  |  | $ | 1,068 |  |  | 45 |  |  | $ | 26.83 |  |  | $ | 1,207 |  |  | $ | 2,275 |  |
| Fiscal 2015 |  |  |  |  |  |  |  |  |  |  |  |  |
| July 25, 2015 |  | $ | 0.21 |  |  | $ | 1,069 |  |  | 35 |  |  | $ | 28.62 |  |  | $ | 1,005 |  |  | $ | 2,074 |  |
| April 25, 2015 |  | $ | 0.21 |  |  | $ | 1,070 |  |  | 35 |  |  | $ | 28.39 |  |  | $ | 1,008 |  |  | $ | 2,078 |  |
| January 24, 2015 |  | $ | 0.19 |  |  | $ | 974 |  |  | 44 |  |  | $ | 27.63 |  |  | $ | 1,208 |  |  | $ | 2,182 |  |
| October 25, 2014 |  | $ | 0.19 |  |  | $ | 973 |  |  | 41 |  |  | $ | 24.58 |  |  | $ | 1,013 |  |  | $ | 1,986 |  |

[0000858877-16-000109:mdna:316]
Any future dividends will be subject to the approval of our Board of Directors.

[0000858877-16-000109:mdna:317]
[same as prior period, unchanged from 0000858877-16-000090:mdna:313]

[0000858877-16-000109:mdna:318]
|  | April 30, 2016 |  | July 25, 2015 |  | Increase (Decrease) |
| Accounts receivable, net | $ | 4,047 |  |  | $ | 5,344 |  |  | $ | (1,297 | ) |
| DSO | 33 |  |  | 38 |  |  | (5 | ) |

[0000858877-16-000109:mdna:319]
Our accounts receivable net, as of April 30, 2016 decreased by approximately 24% compared with the end of fiscal 2015. Our DSO as of April 30, 2016 was lower by five days as compared with the end of fiscal 2015, primarily due to product and service billings being more linear in the third quarter of fiscal 2016 compared with the fourth quarter of fiscal 2015.

[0000858877-16-000109:mdna:320]
[same as prior period, unchanged from 0000858877-16-000090:mdna:316]

[0000858877-16-000109:mdna:321]
|  | April 30, 2016 |  | July 25, 2015 |  | Increase (Decrease) |
| Inventories | $ | 1,343 |  |  | $ | 1,627 |  |  | $ | (284 | ) |
| Annualized inventory turns | 12.0 |  |  | 12.1 |  |  | (0.1 | ) |
| Purchase commitments with contract manufacturers and suppliers | $ | 3,794 |  |  | $ | 4,078 |  |  | $ | (284 | ) |

[0000858877-16-000109:mdna:322]
Inventory as of April 30, 2016 decreased by 17% from our inventory balance at the end of fiscal 2015, and for the same period purchase commitments with contract manufacturers and suppliers decreased by approximately 7%.  On a combined basis, inventories and purchase commitments with contract manufacturers and suppliers decreased by 10% compared with the end of fiscal 2015.  The decrease in inventory and purchase commitments with contract manufacturers and suppliers was due in part to the sale of the SP Video CPE Business. We believe our inventory and purchase commitments levels are in line with our current demand forecasts.

[0000858877-16-000109:mdna:323]
70

[0000858877-16-000109:mdna:324]
[same as prior period, unchanged from 0000858877-16-000090:mdna:318]

[0000858877-16-000109:mdna:325]
[same as prior period, unchanged from 0000858877-16-000090:mdna:319]

[0000858877-16-000109:mdna:326]
[same as prior period, unchanged from 0000858877-16-000090:mdna:321]

[0000858877-16-000109:mdna:327]
[same as prior period, unchanged from 0000858877-16-000090:mdna:322]

[0000858877-16-000109:mdna:328]
[same as prior period, unchanged from 0000858877-16-000090:mdna:323]

[0000858877-16-000109:mdna:329]
[same as prior period, unchanged from 0000858877-16-000090:mdna:324]

[0000858877-16-000109:mdna:330]
Financing Receivables and Guarantees We measure our net balance sheet exposure position related to our financing receivables and financing guarantees by reducing the total of gross financing receivables and financing guarantees by the associated allowances for credit loss and deferred revenue. As of April 30, 2016, our net balance sheet exposure position related to financing receivables and financing guarantees was as follows (in millions):

[0000858877-16-000109:mdna:331]
|  | FINANCING RECEIVABLES |  | FINANCING GUARANTEES |  |  |
| April 30, 2016 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts and Other |  | Total |  | Channel Partner |  | End-User Customers |  | Total |  | TOTAL |
| Financing receivables and guarantees | $ | 3,450 |  |  | $ | 2,223 |  |  | $ | 3,504 |  |  | $ | 9,177 |  |  | $ | 228 |  |  | $ | 104 |  |  | $ | 332 |  |  | $ | 9,509 |  |
| Unearned income | (178 | ) |  | — |  |  | — |  |  | (178 | ) |  | — |  |  | — |  |  | — |  |  | (178 | ) |
| Allowance for credit loss | (250 | ) |  | (93 | ) |  | (40 | ) |  | (383 | ) |  | — |  |  | — |  |  | — |  |  | (383 | ) |
| Deferred revenue | (4 | ) |  | (16 | ) |  | (1,822 | ) |  | (1,842 | ) |  | (98 | ) |  | (82 | ) |  | (180 | ) |  | (2,022 | ) |
| Net balance sheet exposure | $ | 3,018 |  |  | $ | 2,114 |  |  | $ | 1,642 |  |  | $ | 6,774 |  |  | $ | 130 |  |  | $ | 22 |  |  | $ | 152 |  |  | $ | 6,926 |  |

[0000858877-16-000109:mdna:332]
Financing Receivables  Financing receivables less unearned income increased by 3% compared with the end of fiscal 2015. The change was due to a 26% increase in loan receivables partially offset by a 4% decrease in lease receivables and a 2% decrease in financed service contracts and other. We provide financing to certain end-user customers and channel partners to enable sales of our products, services, and networking solutions. These financing arrangements include leases, financed service contracts, and loans. Arrangements related to leases are generally collateralized by a security interest in the underlying assets. Lease receivables include sales-type and direct-financing leases. We also provide certain qualified customers financing for long-term service contracts, which primarily relate to technical support services. Our loan financing arrangements may include not only financing the acquisition of our products and services but also providing additional funds for other costs associated with network installation and integration of our products and services. We expect to continue to expand the use of our financing programs in the near term.

[0000858877-16-000109:mdna:333]
[same as prior period, unchanged from 0000858877-16-000090:mdna:328]

[0000858877-16-000109:mdna:334]
The volume of channel partner financing was $19.8 billion and $19.0 billion for the first nine months of fiscal 2016 and 2015, respectively. These financing arrangements facilitate the working capital requirements of the channel partners, and in some cases, we guarantee a portion of these arrangements. The balance of the channel partner financing subject to guarantees was $1.0 billion and $1.2 billion as of April 30, 2016 and July 25, 2015, respectively. We could be called upon to make payments under these

[0000858877-16-000109:mdna:335]
[same as prior period, unchanged from 0000858877-16-000090:mdna:330]

[0000858877-16-000109:mdna:336]
[same as prior period, unchanged from 0000858877-16-000090:mdna:331]

[0000858877-16-000109:mdna:337]
guarantees in the event of nonpayment by the channel partners or end-user customers. Historically, our payments under these arrangements have been immaterial. Where we provide a guarantee, we defer the revenue associated with the channel partner and end-user financing arrangement in accordance with revenue recognition policies, or we record a liability for the fair value of the guarantees. In either case, the deferred revenue is recognized as revenue when the guarantee is removed.

[0000858877-16-000109:mdna:338]
[same as prior period, unchanged from 0000858877-16-000090:mdna:333]

[0000858877-16-000109:mdna:339]
[same as prior period, unchanged from 0000858877-16-000090:mdna:334]

[0000858877-16-000109:mdna:340]
[same as prior period, unchanged from 0000858877-16-000090:mdna:335]

[0000858877-16-000109:mdna:341]
|  | Maturity Date |  | April 30, 2016 |  | July 25, 2015 |
| Senior notes: |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |
| Three-month LIBOR plus 0.05% | September 3, 2015 |  | $ | — |  |  | $ | 850 |  |
| Three-month LIBOR plus 0.28% | March 3, 2017 |  | 1,000 |  |  | 1,000 |  |
| Three-month LIBOR plus 0.60% | February 21, 2018 | (1) | 1,000 |  |  | — |  |
| Three-month LIBOR plus 0.31% | June 15, 2018 |  | 900 |  |  | 900 |  |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | 500 |  |  | 500 |  |
| Fixed-rate notes: |  |  |  |  |  |
| 5.50% | February 22, 2016 |  | — |  |  | 3,000 |  |
| 1.10% | March 3, 2017 |  | 2,400 |  |  | 2,400 |  |
| 3.15% | March 14, 2017 |  | 750 |  |  | 750 |  |
| 1.40% | February 28, 2018 | (1) | 1,250 |  |  | — |  |
| 1.65% | June 15, 2018 |  | 1,600 |  |  | 1,600 |  |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 2,000 |  |
| 1.60% | February 28, 2019 | (1) | 1,000 |  |  | — |  |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 1,750 |  |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 2,500 |  |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 1,500 |  |
| 2.20% | February 28, 2021 | (1) | 2,500 |  |  | — |  |
| 2.90% | March 4, 2021 |  | 500 |  |  | 500 |  |
| 3.00% | June 15, 2022 |  | 500 |  |  | 500 |  |
| 2.60% | February 28, 2023 | (1) | 500 |  |  | — |  |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1,000 |  |
| 3.50% | June 15, 2025 |  | 500 |  |  | 500 |  |
| 2.95% | February 28, 2026 | (1) | 750 |  |  | — |  |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 2,000 |  |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 2,000 |  |
| Total |  |  | $ | 28,400 |  |  | $ | 25,250 |  |

[0000858877-16-000109:mdna:342]
(1) In February 2016, we issued senior notes with aggregate principal amount of $7.0 billion

[0000858877-16-000109:mdna:343]
Interest is payable semiannually on each class of the senior fixed-rate notes, each of which is redeemable by us at any time, subject to a make-whole premium. Interest is payable quarterly on the floating-rate notes. We were in compliance with all debt covenants as of April 30, 2016.

[0000858877-16-000109:mdna:344]
We repaid the fixed-rate notes (5.50%) due on February 22, 2016 for an aggregate principal amount of $3.0 billion upon maturity.

[0000858877-16-000109:mdna:345]
[same as prior period, unchanged from 0000858877-16-000090:mdna:338]

[0000858877-16-000109:mdna:346]
[same as prior period, unchanged from 0000858877-16-000090:mdna:340]

[0000858877-16-000109:mdna:347]
[same as prior period, unchanged from 0000858877-16-000090:mdna:341]

[0000858877-16-000109:mdna:348]
Other Debt  Other debt as of April 30, 2016 and July 25, 2015 includes secured borrowings associated with customer financing arrangements. The amount of borrowings outstanding under these arrangements was $1 million and $4 million as of April 30, 2016 and July 25, 2015, respectively.

[0000858877-16-000109:mdna:349]
Commercial Paper  We established a short-term debt financing program of up to $3.0 billion through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes. We had no commercial paper notes outstanding as of each of April 30, 2016 and July 25, 2015.

[0000858877-16-000109:mdna:350]
Credit Facility On May 15, 2015, we entered into a credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 15, 2020. Any advances under the credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (i) the highest of (a) the Federal Funds rate plus 0.50%, (b) Bank of America’s “prime rate” as announced from time to time, or (c) LIBOR, or a comparable or successor rate that is approved by the Administrative Agent (“Eurocurrency Rate”), for an interest period of one month plus 1.00%, or (ii) the Eurocurrency Rate, plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the Eurocurrency Rate be less than zero. The credit agreement requires that we comply with certain covenants, including that it maintains an interest coverage ratio as defined in the agreement.

[0000858877-16-000109:mdna:351]
We may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and/or extend the expiration date of the credit facility up to May 15, 2022. We were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under the credit facility.

[0000858877-16-000109:mdna:352]
[same as prior period, unchanged from 0000858877-16-000090:mdna:345]

[0000858877-16-000109:mdna:353]
|  | April 30, 2016 |  | July 25, 2015 |  | Increase (Decrease) |
| Service | $ | 9,866 |  |  | $ | 9,757 |  |  | $ | 109 |  |
| Product | 5,406 |  |  | 5,426 |  |  | (20 | ) |
| Total | $ | 15,272 |  |  | $ | 15,183 |  |  | $ | 89 |  |
| Reported as: |  |  |  |  |  |
| Current | $ | 9,662 |  |  | $ | 9,824 |  |  | $ | (162 | ) |
| Noncurrent | 5,610 |  |  | 5,359 |  |  | 251 |  |
| Total | $ | 15,272 |  |  | $ | 15,183 |  |  | $ | 89 |  |

[0000858877-16-000109:mdna:354]
The 1% increase in deferred service revenue was driven by the timing of multiyear arrangements, the impact of ongoing amortization of deferred service revenue and the impact of the extra week in the third quarter of fiscal 2016. Deferred product revenue was flat as increased deferrals related to subscription revenue arrangements were offset by lower deferred revenue related to two-tier distributors.

[0000858877-16-000109:mdna:355]
[same as prior period, unchanged from 0000858877-16-000090:mdna:348]

[0000858877-16-000109:mdna:356]
[same as prior period, unchanged from 0000858877-16-000090:mdna:349]

[0000858877-16-000109:mdna:357]
We lease office space in many U.S. locations. Outside the United States, larger leased sites include sites in Belgium, Canada, China, France, Germany, India, Israel, Japan, Poland and the United Kingdom. We also lease equipment and vehicles. The future minimum lease payments under all of our noncancelable operating leases with an initial term in excess of one year as of April 30, 2016 were $1.1 billion.

[0000858877-16-000109:mdna:358]
[same as prior period, unchanged from 0000858877-16-000090:mdna:351]

[0000858877-16-000109:mdna:359]
[same as prior period, unchanged from 0000858877-16-000090:mdna:352]

[0000858877-16-000109:mdna:360]
Insieme Networks, Inc.  In the third quarter of fiscal 2012, we made an investment in Insieme, an early stage company focused on research and development in the data center market. As set forth in the agreement between Cisco and Insieme, this investment included $100 million of funding and a license to certain of our technology. Immediately prior to the call option exercise and acquisition described below, we owned approximately 83% of Insieme as a result of these investments and have consolidated the results of Insieme in our Consolidated Financial Statements. In connection with this investment, we entered into a put/call option

[0000858877-16-000109:mdna:361]
[same as prior period, unchanged from 0000858877-16-000090:mdna:355]

[0000858877-16-000109:mdna:362]
[same as prior period, unchanged from 0000858877-16-000090:mdna:356]

[0000858877-16-000109:mdna:363]
agreement that provided us with the right to purchase the remaining interests in Insieme. In addition, the noncontrolling interest holders could require us to purchase their shares upon the occurrence of certain events.

[0000858877-16-000109:mdna:364]
During the first quarter of fiscal 2014, we exercised our call option and entered into an agreement to purchase the remaining interests in Insieme. The acquisition closed in the second quarter of fiscal 2014, at which time the former noncontrolling interest holders became eligible to receive up to two milestone payments, which will be determined using agreed-upon formulas based primarily on revenue for certain of Insieme’s products. During the nine months ended April 30, 2016 and April 25, 2015, we recorded compensation expense of $136 million and $155 million, respectively, related to the fair value of the vested portion of amounts that were earned or are expected to be earned by the former noncontrolling interest holders. Continued vesting and changes to the fair value of the amounts probable of being earned will result in adjustments to the recorded compensation expense in future periods. Based on the terms of the agreement, we have determined that the maximum amount that could be recorded as compensation expense by us is approximately $839 million (which includes the $759 million that has been expensed to date), net of forfeitures.

[0000858877-16-000109:mdna:365]
The former noncontrolling interest holders earned the maximum amount related to the first milestone payment and were paid   approximately $375 million for a portion of this amount during the first nine months of fiscal 2016. The balance of the first milestone payment is expected to be paid primarily through the end of fiscal 2016. The second milestone payment, to the extent earned, is expected to be paid primarily during the first half of fiscal 2017.

[0000858877-16-000109:mdna:366]
Other Funding Commitments  We also have certain funding commitments primarily related to our investments in privately held companies and venture funds, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $199 million as of April 30, 2016, compared with $205 million as of July 25, 2015.

[0000858877-16-000109:mdna:367]
[same as prior period, unchanged from 0000858877-16-000090:mdna:360]

[0000858877-16-000109:mdna:368]
We consider our investments in unconsolidated variable interest entities to be off-balance sheet arrangements. In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers may be considered to be variable interest entities. We evaluate on an ongoing basis our investments in these privately held companies and customer financings, and we have determined that as of April 30, 2016 there were no material unconsolidated variable interest entities.

[0000858877-16-000109:mdna:369]
[same as prior period, unchanged from 0000858877-16-000090:mdna:362]

[0000858877-16-000109:mdna:370]
[same as prior period, unchanged from 0000858877-16-000090:mdna:363]

[0000858877-16-000109:mdna:371]
[same as prior period, unchanged from 0000858877-16-000090:mdna:364]

[0000858877-16-000109:mdna:372]
We periodically engage in securities lending activities with certain of our available for sale investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. The average daily balance of securities lending for the nine months ended April 30, 2016 and April 25, 2015 was $0.9 billion and $0.5 billion, respectively. We require collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. We engage in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify us against collateral losses. As of April 30, 2016 and July 25, 2015, we had no outstanding securities lending transactions. We believe these arrangements do not present a material risk or impact to our liquidity requirements.

[0000858877-16-000109:mdna:373]
[same as prior period, unchanged from 0000858877-16-000090:mdna:366]

[0000858877-16-000109:mdna:374]
Based on past performance and current expectations, we believe our cash and cash equivalents, investments, cash generated from operations, and ability to access capital markets and committed credit lines will satisfy, through at least the next 12 months, our liquidity requirements, both in total and domestically, including the following: working capital needs, capital expenditures, investment requirements, stock repurchases, cash dividends, contractual obligations, commitments,  principal and interest payments on debt, future customer financings, and other liquidity requirements associated with our operations. There are no other transactions, arrangements, or relationships with unconsolidated entities or other persons that are reasonably likely to materially affect the liquidity and the availability of, as well as our requirements for, capital resources.
