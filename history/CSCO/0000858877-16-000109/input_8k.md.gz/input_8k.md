# CSCO 8-K — 0001193125-16-594463 filed 2016-05-18

## item codes, every 8-K on or before 2016-05-24

- 2016-05-18 0001193125-16-594463 — 2.02
- 2016-03-24 0001193125-16-516953 — 8.01
- 2016-02-29 0001193125-16-483780 — 8.01, 9.01
- 2016-02-25 0001193125-16-478442 — 8.01
- 2016-02-24 0001193125-16-474071 — 1.01, 9.01
- 2016-02-22 0001193125-16-470856 — 8.01, 9.01
- 2016-02-10 0001193125-16-457586 — 2.02
- 2016-01-28 0001193125-16-441933 — 5.02
- 2015-12-08 0001193125-15-397797 — 8.01
- 2015-11-20 0001193125-15-383743 — 5.07
- 2015-11-12 0001193125-15-375655 — 2.02
- 2015-09-21 0001193125-15-324465 — 8.01
- 2015-09-17 0001193125-15-322456 — 8.01
- 2015-09-14 0001193125-15-319489 — 8.01
- 2015-08-28 0001193125-15-306843 — 8.01
- 2015-08-12 0001193125-15-288099 — 2.02
- 2015-07-29 0001193125-15-268359 — 5.02 — amendment of 0001193125-15-169227
- 2015-06-18 0001193125-15-227387 — 8.01, 9.01
- 2015-06-12 0001193125-15-221863 — 1.01, 9.01
- 2015-06-10 0001193125-15-218734 — 8.01, 9.01
- 2015-06-01 0001193125-15-209142 — 5.02, 9.01
- 2015-05-13 0001193125-15-185905 — 2.02
- 2015-05-04 0001193125-15-169227 — 5.02
- 2015-03-24 0001193125-15-103369 — 8.01
- 2015-03-19 0001193125-15-098638 — 8.01
- 2015-02-11 0001193125-15-044175 — 2.02
- 2014-12-19 0001193125-14-448754 — 8.01
- 2014-12-18 0001193125-14-447039 — 8.01
- 2014-11-24 0001193125-14-423591 — 5.02, 5.07, 9.01
- 2014-11-14 0001193125-14-413384 — 5.02
- 2014-11-12 0001193125-14-409258 — 2.02
- 2014-09-25 0001193125-14-353210 — 8.01
- 2014-09-12 0001193125-14-340480 — 5.02
- 2014-08-14 0001193125-14-308733 — 2.05
- 2014-08-13 0001193125-14-308403 — 2.02
- 2014-07-31 0001193125-14-289683 — 5.02
- 2014-06-25 0001193125-14-249157 — 8.01
- 2014-05-14 0001193125-14-199056 — 2.02
- 2014-03-26 0001193125-14-116588 — 8.01
- 2014-03-11 0001193125-14-093805 — 8.01
- 2014-03-03 0001193125-14-079163 — 1.01, 8.01, 9.01
- 2014-02-26 0001193125-14-069912 — 1.01, 9.01
- 2014-02-12 0001193125-14-048150 — 2.02
- 2013-12-23 0001193125-13-483099 — 8.01
- 2013-12-04 0001193125-13-462216 — 8.01
- 2013-11-20 0001193125-13-448477 — 5.02, 5.07, 9.01
- 2013-11-13 0001193125-13-440194 — 2.02
- 2013-08-15 0001193125-13-335218 — 2.05
- 2013-08-14 0001193125-13-334648 — 2.02
- 2013-07-23 0001193125-13-298129 — 8.01, 9.01
- 2013-06-24 0001193125-13-269064 — 8.01
- 2013-06-12 0001193125-13-256194 — 8.01
- 2013-06-07 0001193125-13-250920 — 8.01
- 2013-05-15 0001193125-13-222377 — 2.02
- 2013-03-26 0001193125-13-127015 — 8.01
- 2013-02-13 0001193125-13-055377 — 2.02
- 2013-02-01 0001193125-13-034682 — 5.02
- 2013-01-08 0001193125-13-006886 — 5.02, 9.01
- 2012-12-21 0001193125-12-513130 — 8.01
- 2012-12-19 0001193125-12-508424 — 8.01
- 2012-11-16 0001193125-12-474089 — 5.02, 5.07, 9.01
- 2012-11-13 0001193125-12-467422 — 2.02
- 2012-10-04 0001193125-12-415386 — 5.02, 5.03, 9.01
- 2012-09-19 0001193125-12-396875 — 5.02, 8.01
- 2012-08-15 0001193125-12-357479 — 2.02
- 2012-08-02 0001193125-12-332045 — 5.02
- 2012-06-27 0001193125-12-285742 — 8.01
- 2012-06-13 0001193125-12-269642 — 8.01
- 2012-05-09 0001193125-12-222045 — 2.02
- 2012-03-27 0001193125-12-134384 — 8.01
- 2012-03-15 0001193125-12-117538 — 8.01, 9.01
- 2012-02-17 0001193125-12-067542 — 1.01, 1.02, 2.03, 9.01
- 2012-02-08 0001193125-12-046545 — 2.02
- 2011-12-16 0001193125-11-343995 — 8.01
- 2011-12-08 0001193125-11-335127 — 5.02, 5.07, 9.01
- 2011-11-09 0001193125-11-304587 — 2.02
- 2011-09-29 0001193125-11-260065 — 8.01
- 2011-09-20 0001193125-11-252379 — 5.02, 9.01
- 2011-08-24 0001193125-11-231015 — 8.01
- 2011-08-10 0001193125-11-218133 — 2.02
- 2011-07-18 0001193125-11-190246 — 2.05
- 2011-06-22 0001193125-11-170849 — 8.01
- 2011-05-11 0001193125-11-135913 — 2.02
- 2011-03-28 0001193125-11-079927 — 8.01
- 2011-03-22 0001193125-11-073802 — 5.02 — amendment of 0001193125-11-043592
- 2011-03-18 0001193125-11-071279 — 8.01, 9.01
- 2011-03-16 0001193125-11-067985 — 1.01, 5.02, 8.01, 9.01
- 2011-03-15 0001193125-11-067331 — 1.01, 9.01
- 2011-03-09 0001193125-11-060123 — 8.01, 9.01
- 2011-02-23 0001193125-11-043592 — 5.02
- 2011-02-09 0001193125-11-028987 — 2.02
- 2011-01-31 0001193125-11-019101 — 1.01, 2.03
- 2010-12-17 0001193125-10-283392 — 8.01
- 2010-11-19 0001193125-10-265377 — 5.07
- 2010-11-10 0001193125-10-256001 — 2.02
- 2010-09-22 0001193125-10-214707 — 8.01
- 2010-09-16 0001193125-10-211456 — 7.01
- 2010-08-11 0001193125-10-186042 — 2.02
- 2010-06-29 0001193125-10-149956 — 8.01
- 2010-05-12 0001193125-10-117509 — 2.02
- 2010-02-17 0001193125-10-033290 — 5.02, 8.01, 9.01
- 2010-02-03 0001193125-10-020775 — 2.02
- 2009-11-25 0001193125-09-242589 — 8.01
- 2009-11-17 0001193125-09-236335 — 1.01, 8.01, 9.01
- 2009-11-13 0001193125-09-234405 — 1.01, 2.03, 9.01
- 2009-11-13 0001193125-09-234397 — 5.02 — amendment of 0001193125-09-189511
- 2009-11-12 0001193125-09-232971 — 5.02, 7.01, 9.01
- 2009-11-09 0001193125-09-228541 — 8.01, 9.01
- 2009-11-04 0001193125-09-223763 — 2.02
- 2009-10-14 0001193125-09-207912 — 8.01, 9.01
- 2009-10-05 0001193125-09-203556 — 8.01
- 2009-09-10 0001193125-09-189511 — 5.02
- 2009-09-04 0001193125-09-187835 — 5.02
- 2009-08-05 0001193125-09-165404 — 2.02
- 2009-07-27 0001193125-09-155861 — 5.02
- 2009-05-29 0001193125-09-121672 — 8.01
- 2009-05-06 0001193125-09-101570 — 2.02
- 2009-02-26 0001193125-09-038162 — 5.02
- 2009-02-17 0001193125-09-030546 — 1.01, 8.01, 9.01
- 2009-02-13 0001193125-09-029295 — 1.01, 2.03, 9.01
- 2009-02-04 0001193125-09-018793 — 2.02
- 2008-11-05 0001193125-08-225857 — 2.02
- 2008-09-11 0001193125-08-194695 — 7.01
- 2008-08-05 0001193125-08-166496 — 2.02
- 2008-06-20 0001193125-08-137504 — 8.01
- 2008-05-06 0001193125-08-104089 — 2.02
- 2008-03-21 0001193125-08-062838 — 8.01
- 2008-02-06 0001193125-08-021681 — 2.02
- 2008-01-23 0001193125-08-010589 — 5.02
- 2008-01-04 0001193125-08-001680 — 5.02, 9.01
- 2007-12-21 0001193125-07-269613 — 5.02
- 2007-11-19 0001193125-07-250345 — 5.02 — amendment of 0001193125-07-009285
- 2007-11-19 0001193125-07-250343 — 5.02, 9.01
- 2007-11-07 0001193125-07-238464 — 2.02
- 2007-09-24 0001193125-07-206279 — 8.01
- 2007-09-20 0001193125-07-204616 — 5.02, 7.01
- 2007-09-07 0001193125-07-197514 — 8.01
- 2007-08-17 0001193125-07-185320 — 1.01, 2.03, 9.01
- 2007-08-08 0001193125-07-174077 — 5.02
- 2007-08-07 0001193125-07-173689 — 2.02
- 2007-08-01 0001193125-07-168143 — 5.02
- 2007-05-15 0001193125-07-115800 — 8.01
- 2007-05-08 0001193125-07-106059 — 2.02
- 2007-03-23 0001193125-07-063033 — 5.02, 5.03, 8.01, 9.01
- 2007-03-21 0001193125-07-060631 — 1.01, 9.01
- 2007-02-06 0001193125-07-021349 — 2.02
- 2007-01-19 0001193125-07-009285 — 5.02
- 2006-12-22 0001193125-06-259241 — 8.01
- 2006-11-16 0001193125-06-237260 — 5.03, 8.01, 9.01
- 2006-11-08 0001193125-06-228341 — 2.02
- 2006-09-21 0001193125-06-194890 — 1.01, 7.01
- 2006-09-20 0001193125-06-194063 — 1.01
- 2006-09-15 0001193125-06-191845 — 5.02
- 2006-08-18 0001193125-06-176193 — 5.02
- 2006-08-08 0001193125-06-165719 — 2.02
- 2006-07-31 0001193125-06-157106 — 1.01, 9.01
- 2006-07-31 0001193125-06-157102 — 5.02 — amendment of 0001193125-06-017426
- 2006-06-08 0001193125-06-126879 — 5.02
- 2006-05-18 0001193125-06-115516 — 8.01
- 2006-05-12 0001193125-06-110924 — 9.01 — amendment of 0001193125-06-044013
- 2006-05-09 0001193125-06-105419 — 2.02
- 2006-03-29 0001193125-06-066990 — 1.01
- 2006-03-02 0001193125-06-044013 — 1.01, 2.01, 9.01
- 2006-02-28 0001193125-06-041452 — 1.01
- 2006-02-22 0001193125-06-036759 — 8.01
- 2006-02-22 0001193125-06-036433 — 1.01, 8.01, 9.01
- 2006-02-21 0001193125-06-035865 — 1.01, 2.03, 9.01
- 2006-02-10 0001193125-06-026218 — 8.01, 9.01
- 2006-02-07 0001193125-06-022234 — 2.02
- 2006-02-01 0001193125-06-017426 — 5.02
- 2005-11-18 0001193125-05-229535 — 1.01, 9.01
- 2005-11-16 0001193125-05-227987 — 1.01, 9.01
- 2005-11-16 0001193125-05-227983 — 5.02 — amendment of 0001193125-05-008843
- 2005-11-09 0001193125-05-221610 — 2.02
- 2005-09-29 0001193125-05-194217 — 7.01
- 2005-09-27 0001193125-05-192353 — 8.01
- 2005-09-21 0001193125-05-189234 — 1.01, 9.01
- 2005-09-19 0001193125-05-187646 — 8.01
- 2005-09-09 0001193125-05-183273 — 8.01
- 2005-09-08 0001193125-05-182307 — 1.01
- 2005-08-09 0001193125-05-162626 — 2.02
- 2005-07-15 0001193125-05-142738 — 8.01
- 2005-05-10 0001193125-05-102797 — 2.02
- 2005-03-30 0001193125-05-065123 — 1.01, 3.03, 9.01
- 2005-03-04 0001193125-05-042778 — 1.01
- 2005-02-08 0001193125-05-022181 — 2.02
- 2005-01-20 0001193125-05-008843 — 5.02
- 2004-12-23 0001193125-04-219331 — 8.01
- 2004-11-09 0001193125-04-191303 — 2.02
- 2004-08-23 0001193125-04-145198 — 1.01, 7.01
- 2004-08-19 0001193125-04-143859 — 5
- 2004-08-10 0001193125-04-136865 — 12
- 2004-05-11 0001193125-04-084721 — 12
- 2004-02-03 0001193125-04-013750 — 12
- 2003-11-05 0001193125-03-073418 — 12
- 2003-09-02 0001193125-03-044521 — 9
- 2003-08-05 0001193125-03-029223 — 12, 7
- 2003-07-18 0001193125-03-021155 — 5, 7
- 2003-06-05 0001012870-03-002949 — 5
- 2003-05-06 0000891618-03-002315 — 7, 9
- 2003-04-17 0000891618-03-001894 — 5, 7
- 2003-04-11 0000891618-03-001791 — 9
- 2003-03-20 0000891618-03-001326 — 5, 7
- 2003-02-04 0000891618-03-000518 — 7, 9
- 2003-01-28 0000891618-03-000271 — 5, 7
- 2002-12-27 0000891618-02-005686 — 5, 7
- 2002-10-23 0000891618-02-004715 — 5, 7
- 2002-10-11 0000891618-02-004620 — 5, 7
- 2002-09-18 0000891618-02-004352 — 5, 7
- 2002-08-20 0000891618-02-004001 — 5, 7
- 2002-08-05 0000891618-02-003498 — 5, 7
- 2002-07-03 0000891618-02-003099 — 5, 7
- 2002-05-14 0000891618-02-002407 — 5, 7
- 2002-02-05 0000891618-02-000412 — 5, 7
- 2001-09-28 0001095811-01-505261 — 5, 7
- 2001-09-14 0001095811-01-504917 — 5, 7
- 2001-08-24 0001095811-01-504581 — 5, 7
- 2001-07-30 0001095811-01-503468 — 5, 7
- 2001-07-12 0000891618-01-501567 — 5, 7
- 2001-05-11 0000891618-01-500638 — 5, 7
- 2001-02-27 0000891618-01-500076 — 5, 7
- 2001-02-20 0001095811-01-001530 — 5, 7
- 2001-02-08 0001095811-01-000848 — 5, 7
- 2001-02-07 0001095811-01-000768 — 5
- 2000-12-27 0001095811-00-005511 — 5
- 2000-12-21 0001095811-00-005427 — 5
- 2000-12-19 0001095811-00-005368 — 5
- 2000-11-15 0001095811-00-004830 — 5
- 2000-11-15 0001095811-00-004824 — 5
- 2000-11-13 0000891618-00-005023 — 5
- 2000-11-07 0001095811-00-004387 — 5, 7
- 2000-11-06 0001095811-00-004318 — 5
- 2000-09-29 0000891618-00-004739 — 5, 7
- 2000-09-28 0000891618-00-004722 — 5
- 2000-09-26 0001095811-00-003573 — 5
- 2000-09-15 0001095811-00-003413 — 5
- 2000-09-07 0001095811-00-003229 — 5
- 2000-08-15 0000891618-00-004430 — 5
- 2000-08-04 0001095811-00-002304 — 5, 7 — amendment, the index does not say of what
- 2000-07-28 0000891618-00-004132 — 5, 7
- 2000-06-29 0000891618-00-003637 — 5
- 2000-06-07 0000891618-00-003209 — 5
- 2000-05-26 0000891618-00-003054 — 5
- 2000-05-18 0000891618-00-002975 — 5, 7
- 2000-05-15 0000891618-00-002808 — 5, 7
- 2000-05-03 0000891618-00-002473 — 5
- 2000-04-03 0000891618-00-001936 — 5
- 2000-03-28 0000891618-00-001763 — 5
- 2000-03-27 0000891618-00-001722 — 5, 7
- 2000-03-16 0000891618-00-001512 — 5
- 2000-02-17 0000891618-00-001024 — 5, 7
- 2000-02-03 0000891618-00-000468 — 7 — amendment of 0000891618-99-005685
- 1999-12-22 0000891618-99-005792 — 5, 7
- 1999-12-15 0000891618-99-005685 — 5, 7
- 1999-11-17 0000891618-99-005313 — 5, 7
- 1999-11-04 0000891618-99-004862 — 5, 7
- 1999-10-20 0000891618-99-004625 — 5, 7
- 1999-09-27 0000891618-99-004333 — 5, 7
- 1999-08-26 0000891618-99-003978 — 5, 7
- 1999-08-13 0000891618-99-003764 — 5, 7 — amendment of 0000891618-99-003749
- 1999-08-13 0000891618-99-003749 — 5, 7
- 1999-07-02 0000891618-99-002980 — 5, 7
- 1999-05-14 0000891618-99-002221 — 5
- 1998-11-20 0000891618-98-005074 — 5, 7
- 1998-11-20 0000891618-98-005073 — 5, 7
- 1998-10-13 0000891618-98-004462 — 5, 7
- 1998-07-09 0000891618-98-003245 — 5, 7
- 1998-06-11 0000891618-98-002832 — 5, 7
- 1998-05-15 0000891618-98-002457 — 5, 7
- 1998-04-29 0000891618-98-001996 — 5
- 1998-02-11 0000891618-98-000584 — 5, 7
- 1997-09-09 0000891618-97-003723 — 5, 7
- 1997-08-22 0000891618-97-003559 — 5, 7
- 1997-07-01 0000891618-97-002807 — 5, 7
- 1997-01-22 0000891618-97-000120 — 5, 7
- 1996-10-15 0000891618-96-002283 — 5, 7 — amendment of 0000891618-96-002217
- 1996-10-01 0000891618-96-002217 — 5, 7
- 1996-07-23 0000891618-96-001305 — 2, 7
- 1996-04-26 0000891618-96-000253 — 2
- 1996-04-02 0000898430-96-001187 — 2, 7
- 1995-12-06 0000891618-95-000728 — 2, 7
- 1995-12-06 0000891618-95-000727 — 2, 7

## late-filing notifications on or before 2016-05-24

- none on or before 2016-05-24

## item 2.02 — earnings release, exhibit 99.1

[0001193125-16-594463:8k_2_02:1]
EX-99.1
2
d90849dex991.htm
EX-99.1

[0001193125-16-594463:8k_2_02:2]
EX-99.1

[0001193125-16-594463:8k_2_02:3]
Exhibit 99.1

[0001193125-16-594463:8k_2_02:4]
| Press Contact: |  |  |  | Investor Relations Contact: |
| Andrea Duffy |  |  |  | Marilyn Mora |
| Cisco |  |  |  | Cisco |
| 1 (646) 295-5241 |  |  |  | 1 (408) 527-7452 |
| anduffy@cisco.com |  |  |  | marilmor@cisco.com |

[0001193125-16-594463:8k_2_02:5]
CISCO REPORTS THIRD QUARTER EARNINGS

[0001193125-16-594463:8k_2_02:6]
Solid Quarter Driven by Strong Execution; Continued Strong Margins and Momentum in Growth Areas

[0001193125-16-594463:8k_2_02:7]
|  | • |  | Q3 Revenue: $12.0 billion |

[0001193125-16-594463:8k_2_02:8]
|  | • |  | Growth of 3% year over year — Q3 guidance was 1% to 4% growth year over year (normalized to exclude the SP Video CPE Business for Q3 2015) |

[0001193125-16-594463:8k_2_02:9]
|  | • |  | Q3 Earnings per Share: $0.46 GAAP; $0.57 non-GAAP |

[0001193125-16-594463:8k_2_02:10]
|  | • |  | Q4 Guidance: |

[0001193125-16-594463:8k_2_02:11]
|  | • |  | Revenue: 0% - 3% growth year over year (normalized to exclude the SP Video CPE Business for Q4 2015) |

[0001193125-16-594463:8k_2_02:12]
|  | • |  | Earnings per Share: GAAP $0.48 - $0.53; Non-GAAP: $0.59 to $0.61 |

[0001193125-16-594463:8k_2_02:13]
SAN JOSE, Calif. — May 18,
2016 — Cisco today reported third quarter results for the period ended April 30, 2016. Cisco reported third quarter revenue of $12.0 billion, net income on a generally accepted accounting principles (GAAP) basis of $2.3 billion or $0.46
per share, and non-GAAP net income of $2.9 billion or $0.57 per share.

[0001193125-16-594463:8k_2_02:14]
“We delivered a strong Q3, executing well despite the challenging
environment,” said Chuck Robbins, Cisco chief executive officer. “I’m pleased with our performance today as well as the progress we’re making in transitioning our business to a more software and subscription focus, which
we’ll continue to apply across our entire portfolio.”

[0001193125-16-594463:8k_2_02:15]
GAAP Results

[0001193125-16-594463:8k_2_02:16]
|  |  | Q3 2016 |  |  | Q3 2015 |  |  | Vs. Q3 2015 |  |
| Revenue (including SP Video CPE Business for all periods) |  | $ | 12.0 billion |  |  | $ | 12.1 billion |  |  |  | (1 | )% |
| Revenue (excluding SP Video CPE Business for all periods) |  | $ | 12.0 billion |  |  | $ | 11.6 billion |  |  |  | 3 | % |
| Net Income |  | $ | 2.3 billion |  |  | $ | 2.4 billion |  |  |  | (4 | )% |
| Diluted Earnings per Share (EPS) |  | $ | 0.46 |  |  | $ | 0.47 |  |  |  | (2 | )% |

[0001193125-16-594463:8k_2_02:17]
Non-GAAP Results

[0001193125-16-594463:8k_2_02:18]
|  |  | Q3 2016 |  |  | Q3 2015 |  |  | Vs. Q3 2015 |  |
| Net Income |  | $ | 2.9 billion |  |  | $ | 2.8 billion |  |  |  | 3 | % |
| EPS |  | $ | 0.57 |  |  | $ | 0.54 |  |  |  | 6 | % |

[0001193125-16-594463:8k_2_02:19]
The third quarter of fiscal 2016 had 14 weeks compared with 13 weeks in the third quarter of fiscal 2015.

[0001193125-16-594463:8k_2_02:20]
A reconciliation between net income and EPS on a GAAP and non-GAAP basis is provided in the table following the Consolidated Statements of Operations.
Supplementary information related to other GAAP and non-GAAP measures is also provided in the tables following.

[0001193125-16-594463:8k_2_02:21]
“Once again we delivered a solid
quarter in Q3, with 3% top line growth, and even faster non-GAAP EPS growth and strong margins,” said Kelly Kramer, Cisco executive vice president and chief financial officer. “We executed well on our financial strategy, allowing us
to invest in our business model transition to software and recurring revenues so that our customers are able to consume Cisco technology in the way that is best for their business.”

[0001193125-16-594463:8k_2_02:22]
1

[0001193125-16-594463:8k_2_02:23]
Financial Highlights for Q3 Fiscal 2016

[0001193125-16-594463:8k_2_02:24]
All comparative percentages are on a year-over-year basis unless otherwise noted.

[0001193125-16-594463:8k_2_02:25]
All revenue, non-GAAP, and geographic financial information in this “Financial Highlights for Q3 Fiscal 2016” section are presented excluding the
SP Video CPE Business for prior periods as it was divested during the second quarter of fiscal 2016 on November 20, 2015.

[0001193125-16-594463:8k_2_02:26]
Revenue — Revenue was $12.0 billion, up 3% with product revenue up 1% and service revenue up 11%. Revenue
by geographic segment was: Americas up 4%, EMEA down 2%, and APJC up 10%. Product revenue growth was led by Security, Collaboration and SP Video which increased by 17%, 10% and 18%, respectively. Wireless and Data Center each increased by 1%, while
Switching and NGN Routing decreased by 3% and 5%, respectively.

[0001193125-16-594463:8k_2_02:27]
Gross Margin — On a GAAP basis, total gross margin and product
gross margin were 64.3% and 63.8%, respectively. The increase in the product gross margin compared with 61.6% in the third quarter of fiscal 2015 was primarily due to continued productivity improvements and the divestiture of the SP Video CPE
Business, partially offset by pricing and to a lesser extent product mix.

[0001193125-16-594463:8k_2_02:28]
Non-GAAP total gross margin and product gross margin were 65.2% and 64.5%,
respectively. The non-GAAP product gross margin was unchanged compared to the third quarter of fiscal 2015 as continued productivity improvements were offset by pricing and to a lesser extent product mix.

[0001193125-16-594463:8k_2_02:29]
GAAP service margin was 65.9% and non-GAAP service gross margin was 67.1%.

[0001193125-16-594463:8k_2_02:30]
Total gross margins by geographic segment were: 66.3% for the Americas, 65.5% for EMEA and 60.4% for APJC.

[0001193125-16-594463:8k_2_02:31]
Operating Expenses — On a GAAP basis, operating expenses were $4.7 billion, up 3%. Non-GAAP operating expenses were $4.2 billion, up
4%, and at 35.2% of revenue. Headcount compared with the end of the second quarter of fiscal 2016 increased by 1,447 to 73,104, driven by additional headcount from acquisitions and investments in key growth areas such as security, cloud and
software.

[0001193125-16-594463:8k_2_02:32]
Operating Income — GAAP operating income was $3.0 billion, up 2%, with GAAP operating margin of 24.9%. Non-GAAP operating
income was $3.6 billion, up 5%, with non-GAAP operating margin at 30.0%.

[0001193125-16-594463:8k_2_02:33]
Provision for Income Taxes — The GAAP tax provision rate was
23.8%. The non-GAAP tax provision rate was 22.0%.

[0001193125-16-594463:8k_2_02:34]
Net Income and EPS — On a GAAP basis, net income was $2.3 billion and EPS was $0.46.
On a non-GAAP basis, net income was $2.9 billion, an increase of 4%, and EPS was $0.57, an increase of 6%.

[0001193125-16-594463:8k_2_02:35]
Cash Flow from Operating Activities
— was $3.1 billion an increase of 1% compared with $3.0 billion for the third quarter of fiscal 2015.

[0001193125-16-594463:8k_2_02:36]
Cash and Cash Equivalents and
Investments — were $63.5 billion at the end of the third quarter of fiscal 2016, compared with $60.4 billion at the end of the second quarter of fiscal 2016, and compared with $60.4 billion at the end of fiscal 2015. The total cash and
cash equivalents and investments available in the United States at the end of the third quarter of fiscal 2016 were $6.3 billion.

[0001193125-16-594463:8k_2_02:37]
Deferred Revenue
— was $15.3 billion, up 8% in total, with deferred product revenue up 9%, driven largely by subscription-based and software offerings, and deferred service revenue up 7%. Cisco continued to build a greater mix of recurring revenue as
reflected in deferred revenue.

[0001193125-16-594463:8k_2_02:38]
Days Sales Outstanding in Accounts Receivable (DSO) — was 33 days at the end of the third quarter of
fiscal 2016, compared with 33 days at the end of the second quarter of fiscal 2016, and compared with 37 days at the end of the third quarter of fiscal 2015.

[0001193125-16-594463:8k_2_02:39]
Other Financial Highlights

[0001193125-16-594463:8k_2_02:40]
In the third quarter of
fiscal 2016, Cisco declared and paid a cash dividend of $0.26 per common share, or $1.3 billion. For the third quarter of fiscal 2016, Cisco repurchased approximately 27 million shares of common stock under its stock repurchase program at an average
price of $24.08 per share for an aggregate purchase price of $649 million.

[0001193125-16-594463:8k_2_02:41]
As of April 30, 2016, Cisco had repurchased and retired 4.6 billion
shares of Cisco common stock at an average price of $20.99 per share for an aggregate purchase price of approximately $95.8 billion since the inception of the stock repurchase program. The remaining authorized amount for stock repurchases under this
program is approximately $16.2 billion with no termination date.

[0001193125-16-594463:8k_2_02:42]
Acquisitions

[0001193125-16-594463:8k_2_02:43]
During the third quarter of fiscal 2016, Cisco completed the following acquisitions:

[0001193125-16-594463:8k_2_02:44]
Jasper Technologies — provides a cloud-based Internet of Things (IoT) service platform to help enterprises
and service providers launch, manage and monetize IoT services on a global scale.

[0001193125-16-594463:8k_2_02:45]
Acano — provides
on-premises and cloud-based video infrastructure and collaboration software.

[0001193125-16-594463:8k_2_02:46]
Synata — will enable us
to deliver search capabilities for collaboration cloud applications.

[0001193125-16-594463:8k_2_02:47]
Leaba — a fabless semiconductor
company whose semiconductor expertise is expected to help to accelerate Cisco’s next generation product portfolio and bring new capabilities to the market faster.

[0001193125-16-594463:8k_2_02:48]
CliQr — provides an application-defined cloud orchestration platform that is expected to help Cisco
customers simplify and accelerate their private, public and hybrid cloud deployments.

[0001193125-16-594463:8k_2_02:49]
2

[0001193125-16-594463:8k_2_02:50]
Business Outlook for Q4 Fiscal 2016

[0001193125-16-594463:8k_2_02:51]
Cisco estimates that GAAP EPS will be $0.48 to $0.53 which is lower than non-GAAP EPS by $0.08 to $0.11 per share in the fourth quarter of fiscal 2016 as
follows:

[0001193125-16-594463:8k_2_02:52]
| Q4 2016 |  |  |  |
| Share-based compensation expense |  | $ | 0.05 - $0.06 |  |
| Amortization of purchased intangible assets and other acquisition-related/divestiture costs |  |  | 0.03 - 0.05 |  |
| Total |  | $ | 0.08 - $0.11 |  |

[0001193125-16-594463:8k_2_02:53]
Share-based compensation expense is expected to impact Cisco’s results of operations in similar proportions as the third
quarter of fiscal 2016. Amortization of purchased intangible assets and other acquisition-related/divestiture costs will be reported as GAAP operating expenses, cost of sales, or other income/(loss) as applicable. Except as noted above, this
guidance does not include the effects of any future acquisitions/divestitures, asset impairments, restructurings and tax or other events, which may or may not be significant unless specifically stated.

[0001193125-16-594463:8k_2_02:54]
On November 20, 2015, during the second quarter of fiscal 2016, Cisco completed its divestiture of the SP Video CPE Business. In order to provide a clear view
of Cisco’s continuing expected financial performance, the revenue guidance for the fourth quarter of fiscal 2016 is normalized to exclude the SP Video CPE Business for the fourth quarter of fiscal 2015. The corresponding revenue in the
fourth quarter of fiscal 2015 for the SP Video CPE Business was $487 million.

[0001193125-16-594463:8k_2_02:55]
Cisco expects to achieve the following results for the fourth quarter of
fiscal year 2016:

[0001193125-16-594463:8k_2_02:56]
| Business Outlook for Q4 2016 |  |  |
| Revenue (normalized to exclude SP Video CPE Business for Q4 FY15) |  | 0% - 3% |
| Non-GAAP gross margin rate |  | 63% - 64% |
| Non-GAAP operating margin rate |  | 29% - 30% |
| Non-GAAP tax provision rate |  | 22% |
| Non-GAAP EPS |  | $0.59 - $0.61 |

[0001193125-16-594463:8k_2_02:57]
Editor’s Notes:

[0001193125-16-594463:8k_2_02:58]
|  | • |  | Q3 fiscal year 2016 conference call to discuss Cisco’s results along with its business outlook will be held on Wednesday, May 18, 2016 at 1:30 p.m. Pacific Time. Conference call number is 1-888-848-6507 (United States) or 1-212-519-0847 (international). |

[0001193125-16-594463:8k_2_02:59]
|  | • |  | Conference call replay will be available from 4:00 p.m. Pacific Time, May 18, 2016 to 4:00 p.m. Pacific Time, May 25, 2016 at 1-866-457-5715 (United States) or 1-203-369-1293 (international). The replay will also be available via webcast on the Cisco Investor Relations website at http://investor.cisco.com. |

[0001193125-16-594463:8k_2_02:60]
|  | • |  | Additional information regarding Cisco’s financials, as well as a webcast of the conference call with visuals designed to guide participants through the call, will be available at 1:30 p.m. Pacific Time, May 18, 2016. Text of the conference call’s prepared remarks will be available within 24 hours of completion of the call. The webcast will include both the prepared remarks and the question-and-answer session. This information, along with the GAAP to non-GAAP reconciliation information, will be available on the Cisco Investor Relations website at http://investor.cisco.com. |

[0001193125-16-594463:8k_2_02:61]
3

[0001193125-16-594463:8k_2_02:62]
CISCO SYSTEMS, INC.

[0001193125-16-594463:8k_2_02:63]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-16-594463:8k_2_02:64]
(In millions, except per-share amounts)

[0001193125-16-594463:8k_2_02:65]
(Unaudited)

[0001193125-16-594463:8k_2_02:66]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | April 30,2016 |  |  | April 25,2015 |  |  | April 30,2016 |  |  | April 25,2015 |  |
| REVENUE: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 8,875 |  |  | $ | 9,326 |  |  | $ | 27,702 |  |  | $ | 27,839 |  |
| Service |  |  | 3,125 |  |  |  | 2,811 |  |  |  | 8,907 |  |  |  | 8,479 |  |
| Total revenue |  |  | 12,000 |  |  |  | 12,137 |  |  |  | 36,609 |  |  |  | 36,318 |  |
| COST OF SALES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 3,214 |  |  |  | 3,584 |  |  |  | 10,547 |  |  |  | 11,309 |  |
| Service |  |  | 1,065 |  |  |  | 1,028 |  |  |  | 3,077 |  |  |  | 3,061 |  |
| Total cost of sales |  |  | 4,279 |  |  |  | 4,612 |  |  |  | 13,624 |  |  |  | 14,370 |  |
| GROSS MARGIN |  |  | 7,721 |  |  |  | 7,525 |  |  |  | 22,985 |  |  |  | 21,948 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 1,626 |  |  |  | 1,547 |  |  |  | 4,695 |  |  |  | 4,659 |  |
| Sales and marketing |  |  | 2,447 |  |  |  | 2,449 |  |  |  | 7,176 |  |  |  | 7,272 |  |
| General and administrative |  |  | 566 |  |  |  | 510 |  |  |  | 1,281 |  |  |  | 1,504 |  |
| Amortization of purchased intangible assets |  |  | 81 |  |  |  | 70 |  |  |  | 221 |  |  |  | 213 |  |
| Restructuring and other charges |  |  | 17 |  |  |  | 24 |  |  |  | 255 |  |  |  | 411 |  |
| Total operating expenses |  |  | 4,737 |  |  |  | 4,600 |  |  |  | 13,628 |  |  |  | 14,059 |  |
| OPERATING INCOME |  |  | 2,984 |  |  |  | 2,925 |  |  |  | 9,357 |  |  |  | 7,889 |  |
| Interest income |  |  | 270 |  |  |  | 190 |  |  |  | 732 |  |  |  | 558 |  |
| Interest expense |  |  | (175 | ) |  |  | (139 | ) |  |  | (496 | ) |  |  | (417 | ) |
| Other income (loss), net |  |  | 4 |  |  |  | 59 |  |  |  | (67 | ) |  |  | 238 |  |
| Interest and other income (loss), net |  |  | 99 |  |  |  | 110 |  |  |  | 169 |  |  |  | 379 |  |
| INCOME BEFORE PROVISION FOR INCOME TAXES |  |  | 3,083 |  |  |  | 3,035 |  |  |  | 9,526 |  |  |  | 8,268 |  |
| Provision for income taxes |  |  | 734 |  |  |  | 598 |  |  |  | 1,600 |  |  |  | 1,606 |  |
| NET INCOME |  | $ | 2,349 |  |  | $ | 2,437 |  |  | $ | 7,926 |  |  | $ | 6,662 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.47 |  |  | $ | 0.48 |  |  | $ | 1.57 |  |  | $ | 1.30 |  |
| Diluted |  | $ | 0.46 |  |  | $ | 0.47 |  |  | $ | 1.56 |  |  | $ | 1.29 |  |
| Shares used in per-share calculation: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 5,032 |  |  |  | 5,102 |  |  |  | 5,060 |  |  |  | 5,110 |  |
| Diluted |  |  | 5,065 |  |  |  | 5,148 |  |  |  | 5,095 |  |  |  | 5,154 |  |
| Cash dividends declared per common share |  | $ | 0.26 |  |  | $ | 0.21 |  |  | $ | 0.68 |  |  | $ | 0.59 |  |

[0001193125-16-594463:8k_2_02:67]
The Consolidated Statements of Operations include the results of the SP Video CPE Business prior to its divestiture during the
second quarter of fiscal 2016 on November 20, 2015. Accordingly, the nine months ended April 30, 2016 include four months of financial results for this business.

[0001193125-16-594463:8k_2_02:68]
4

[0001193125-16-594463:8k_2_02:69]
CISCO SYSTEMS, INC.

[0001193125-16-594463:8k_2_02:70]
RECONCILIATION OF GAAP TO NON-GAAP NET INCOME

[0001193125-16-594463:8k_2_02:71]
(In millions, except per-share amounts)

[0001193125-16-594463:8k_2_02:72]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | April 30,2016 |  |  | April 25,2015 |  |  | April 30,2016 |  |  | April 25,2015 |  |
| GAAP net income |  | $ | 2,349 |  |  | $ | 2,437 |  |  | $ | 7,926 |  |  | $ | 6,662 |  |
| Adjustments to cost of sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 58 |  |  |  | 56 |  |  |  | 160 |  |  |  | 149 |  |
| Amortization of acquisition-related intangible assets |  |  | 115 |  |  |  | 172 |  |  |  | 366 |  |  |  | 586 |  |
| Supplier component remediation adjustment |  |  | (74 | ) |  |  | (164 | ) |  |  | (74 | ) |  |  | (164 | ) |
| Rockstar patent portfolio charge |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 188 |  |
| Acquisition-related/divestiture costs |  |  | — |  |  |  | — |  |  |  | 1 |  |  |  | — |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | (2 | ) |  |  | — |  |
| Total adjustments to GAAP cost of sales |  |  | 99 |  |  |  | 64 |  |  |  | 451 |  |  |  | 759 |  |
| Adjustments to operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 337 |  |  |  | 311 |  |  |  | 927 |  |  |  | 897 |  |
| Amortization of acquisition-related intangible assets |  |  | 81 |  |  |  | 70 |  |  |  | 221 |  |  |  | 213 |  |
| Acquisition-related/divestiture costs (1) |  |  | 76 |  |  |  | 79 |  |  |  | (55 | ) |  |  | 272 |  |
| Significant asset impairments and restructurings |  |  | 17 |  |  |  | 24 |  |  |  | 255 |  |  |  | 411 |  |
| Total adjustments to GAAP operating expenses |  |  | 511 |  |  |  | 484 |  |  |  | 1,348 |  |  |  | 1,793 |  |
| Adjustments to other income (loss), net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Gain on VCE reorganization |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (126 | ) |
| Total adjustments to GAAP income before provision for income taxes |  |  | 610 |  |  |  | 548 |  |  |  | 1,799 |  |  |  | 2,426 |  |
| Income tax effect of non-GAAP adjustments |  |  | (133 | ) |  |  | (124 | ) |  |  | (427 | ) |  |  | (546 | ) |
| Significant tax matters (2) |  |  | 54 |  |  |  | (66 | ) |  |  | (465 | ) |  |  | (200 | ) |
| Total adjustments to GAAP provision for income taxes |  |  | (79 | ) |  |  | (190 | ) |  |  | (892 | ) |  |  | (746 | ) |
| Non-GAAP net income |  | $ | 2,880 |  |  | $ | 2,795 |  |  | $ | 8,833 |  |  | $ | 8,342 |  |
| Diluted net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | $ | 0.46 |  |  | $ | 0.47 |  |  | $ | 1.56 |  |  | $ | 1.29 |  |
| Non-GAAP |  | $ | 0.57 |  |  | $ | 0.54 |  |  | $ | 1.73 |  |  | $ | 1.62 |  |

[0001193125-16-594463:8k_2_02:73]
(1) During the second quarter of fiscal 2016 on November 20, 2015, Cisco
completed its divestiture of the SP Video CPE Business. This sale resulted in a pre-tax gain of $285 million, net of certain transaction costs incurred. The gain on this transaction was excluded from non-GAAP net income for the first nine
months of fiscal 2016.

[0001193125-16-594463:8k_2_02:74]
(2) Cisco recorded certain net tax benefits totaling $465 million related to
prior-year periods that were excluded from non-GAAP net income for the first nine months of fiscal 2016.

[0001193125-16-594463:8k_2_02:75]
5

[0001193125-16-594463:8k_2_02:76]
CISCO SYSTEMS, INC.

[0001193125-16-594463:8k_2_02:77]
REVENUE BY SEGMENT

[0001193125-16-594463:8k_2_02:78]
(In
millions, except percentages)

[0001193125-16-594463:8k_2_02:79]
|  |  | April 30, 2016 |
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | Amount |  |  | Y/Y % |  | Amount |  |  | Y/Y % |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |
| Including SP Video CPE Business for all periods: |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 7,062 |  |  | (3)% |  | $ | 21,773 |  |  | — % |
| EMEA |  |  | 3,001 |  |  | (4)% |  |  | 9,176 |  |  | — % |
| APJC |  |  | 1,937 |  |  | 10% |  |  | 5,660 |  |  | 8% |
| Total |  | $ | 12,000 |  |  | (1)% |  | $ | 36,609 |  |  | 1% |
| Excluding SP Video CPE Business for all periods: |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 7,062 |  |  | 4% |  | $ | 21,395 |  |  | 3% |
| EMEA |  |  | 3,001 |  |  | (2)% |  |  | 9,068 |  |  | — % |
| APJC |  |  | 1,937 |  |  | 10% |  |  | 5,642 |  |  | 8% |
| Total |  | $ | 12,000 |  |  | 3% |  | $ | 36,105 |  |  | 3% |

[0001193125-16-594463:8k_2_02:80]
During the second quarter of fiscal 2016 on November 20, 2015, Cisco completed its divestiture of the SP Video CPE Business.
SP Video CPE Business revenue for the three months ended April 25, 2015 was $519 million and for the nine months ended April 30, 2016 and April 25, 2015 was $504 million and $1,359 million, respectively.

[0001193125-16-594463:8k_2_02:81]
CISCO SYSTEMS, INC.

[0001193125-16-594463:8k_2_02:82]
GROSS MARGIN PERCENTAGE BY SEGMENT

[0001193125-16-594463:8k_2_02:83]
(In percentages)

[0001193125-16-594463:8k_2_02:84]
|  |  | April 30, 2016 |
|  |  | Three Months Ended |  | Nine Months Ended |
| Gross Margin Percentage: |  |  |  |  |
| Including SP Video CPE Business for all periods: |  |  |  |  |
| Americas |  | 66.3% |  | 64.5% |
| EMEA |  | 65.5% |  | 64.9% |
| APJC |  | 60.4% |  | 60.7% |
| Excluding SP Video CPE Business for all periods (1): |  |  |  |  |
| Americas |  | 66.3% |  | 65.5% |
| EMEA |  | 65.5% |  | 65.5% |
| APJC |  | 60.4% |  | 60.9% |

[0001193125-16-594463:8k_2_02:85]
(1) During the second quarter of fiscal 2016 on November 20, 2015,
Cisco completed its divestiture of the SP Video CPE Business. SP Video CPE Business gross profit for the nine months ended April 30, 2016 was $41 million and $15 million for the Americas and EMEA, respectively.

[0001193125-16-594463:8k_2_02:86]
6

[0001193125-16-594463:8k_2_02:87]
CISCO SYSTEMS, INC.

[0001193125-16-594463:8k_2_02:88]
REVENUE FOR GROUPS OF SIMILAR PRODUCTS AND SERVICES

[0001193125-16-594463:8k_2_02:89]
(In millions, except percentages)

[0001193125-16-594463:8k_2_02:90]
|  |  | April 30, 2016 |  |
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | Amount |  |  | Y/Y % |  |  | Amount |  |  | Y/Y % |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Switching |  | $ | 3,447 |  |  |  | (3)% |  |  | $ | 10,952 |  |  |  | (1)% |  |
| NGN Routing |  |  | 1,894 |  |  |  | (5)% |  |  |  | 5,532 |  |  |  | (3)% |  |
| Collaboration |  |  | 1,069 |  |  |  | 10% |  |  |  | 3,203 |  |  |  | 10% |  |
| Data Center |  |  | 811 |  |  |  | 1% |  |  |  | 2,492 |  |  |  | 7% |  |
| Wireless |  |  | 615 |  |  |  | 1% |  |  |  | 1,873 |  |  |  | 3% |  |
| Service Provider Video(1) |  |  | 468 |  |  |  | 18% |  |  |  | 1,476 |  |  |  | 23% |  |
| Security |  |  | 482 |  |  |  | 17% |  |  |  | 1,429 |  |  |  | 11% |  |
| Other |  |  | 89 |  |  |  | 62% |  |  |  | 241 |  |  |  | 33% |  |
| Product - excluding SP Video CPE Business |  |  | 8,875 |  |  |  | 1% |  |  |  | 27,198 |  |  |  | 3% |  |
| Service |  |  | 3,125 |  |  |  | 11% |  |  |  | 8,907 |  |  |  | 5% |  |
| Total - excluding SP Video CPE Business |  |  | 12,000 |  |  |  | 3% |  |  |  | 36,105 |  |  |  | 3% |  |
| SP Video CPE Business (2) |  |  | — |  |  |  |  |  |  |  | 504 |  |  |  |  |  |
| Total |  | $ | 12,000 |  |  |  | (1)% |  |  | $ | 36,609 |  |  |  | 1% |  |

[0001193125-16-594463:8k_2_02:91]
(1) Excludes SP Video CPE Business revenue for all periods presented as
it was divested during the second quarter of fiscal 2016 on November 20, 2015. SP Video CPE Business revenue was $519 million and $1,359 million for the three and nine months ended April 25, 2015, respectively.

[0001193125-16-594463:8k_2_02:92]
(2) Includes SP Video CPE Business revenue through the date of divestiture of November 20, 2015.

[0001193125-16-594463:8k_2_02:93]
7

[0001193125-16-594463:8k_2_02:94]
CISCO SYSTEMS, INC.

[0001193125-16-594463:8k_2_02:95]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001193125-16-594463:8k_2_02:96]
(In millions)

[0001193125-16-594463:8k_2_02:97]
(Unaudited)

[0001193125-16-594463:8k_2_02:98]
|  |  | April 30,2016 |  |  | July 25,2015 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 8,895 |  |  | $ | 6,877 |  |
| Investments |  |  | 54,617 |  |  |  | 53,539 |  |
| Accounts receivable, net of allowance for doubtful accounts of $244 at April 30, 2016 and $302 at July 25, 2015 |  |  | 4,047 |  |  |  | 5,344 |  |
| Inventories |  |  | 1,343 |  |  |  | 1,627 |  |
| Financing receivables, net |  |  | 4,716 |  |  |  | 4,491 |  |
| Deferred tax assets |  |  | 2,723 |  |  |  | 2,915 |  |
| Other current assets |  |  | 2,230 |  |  |  | 1,490 |  |
| Total current assets |  |  | 78,571 |  |  |  | 76,283 |  |
| Property and equipment, net |  |  | 3,529 |  |  |  | 3,332 |  |
| Financing receivables, net |  |  | 3,900 |  |  |  | 3,858 |  |
| Goodwill |  |  | 26,762 |  |  |  | 24,469 |  |
| Purchased intangible assets, net |  |  | 2,744 |  |  |  | 2,376 |  |
| Other assets |  |  | 3,148 |  |  |  | 3,163 |  |
| TOTAL ASSETS |  | $ | 118,654 |  |  | $ | 113,481 |  |
| LIABILITIES AND EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 4,164 |  |  | $ | 3,897 |  |
| Accounts payable |  |  | 1,007 |  |  |  | 1,104 |  |
| Income taxes payable |  |  | 152 |  |  |  | 62 |  |
| Accrued compensation |  |  | 2,745 |  |  |  | 3,049 |  |
| Deferred revenue |  |  | 9,662 |  |  |  | 9,824 |  |
| Other current liabilities |  |  | 6,273 |  |  |  | 5,687 |  |
| Total current liabilities |  |  | 24,003 |  |  |  | 23,623 |  |
| Long-term debt |  |  | 24,431 |  |  |  | 21,457 |  |
| Income taxes payable |  |  | 891 |  |  |  | 1,876 |  |
| Deferred revenue |  |  | 5,610 |  |  |  | 5,359 |  |
| Other long-term liabilities |  |  | 1,361 |  |  |  | 1,459 |  |
| Total liabilities |  |  | 56,296 |  |  |  | 53,774 |  |
| Total equity |  |  | 62,358 |  |  |  | 59,707 |  |
| TOTAL LIABILITIES AND EQUITY |  | $ | 118,654 |  |  | $ | 113,481 |  |

[0001193125-16-594463:8k_2_02:99]
8

[0001193125-16-594463:8k_2_02:100]
CISCO SYSTEMS, INC.

[0001193125-16-594463:8k_2_02:101]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-16-594463:8k_2_02:102]
(In millions)

[0001193125-16-594463:8k_2_02:103]
(Unaudited)

[0001193125-16-594463:8k_2_02:104]
|  |  | Nine Months Ended |  |
|  |  | April 30,2016 |  |  | April 25,2015 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 7,926 |  |  | $ | 6,662 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation, amortization, and other |  |  | 1,546 |  |  |  | 1,799 |  |
| Share-based compensation expense |  |  | 1,101 |  |  |  | 1,044 |  |
| Provision for receivables |  |  | (27 | ) |  |  | 82 |  |
| Deferred income taxes |  |  | 229 |  |  |  | 438 |  |
| Excess tax benefits from share-based compensation |  |  | (103 | ) |  |  | (102 | ) |
| (Gains) losses on divestitures, investments and other, net |  |  | (279 | ) |  |  | (231 | ) |
| Change in operating assets and liabilities, net of effects of acquisitions and divestitures: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 1,412 |  |  |  | 97 |  |
| Inventories |  |  | 189 |  |  |  | (235 | ) |
| Financing receivables |  |  | (296 | ) |  |  | 36 |  |
| Other assets |  |  | (94 | ) |  |  | (349 | ) |
| Accounts payable |  |  | (114 | ) |  |  | 101 |  |
| Income taxes, net |  |  | (723 | ) |  |  | (511 | ) |
| Accrued compensation |  |  | (318 | ) |  |  | (324 | ) |
| Deferred revenue |  |  | 7 |  |  |  | 217 |  |
| Other liabilities |  |  | (704 | ) |  |  | (310 | ) |
| Net cash provided by operating activities |  |  | 9,752 |  |  |  | 8,414 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of investments |  |  | (36,366 | ) |  |  | (30,617 | ) |
| Proceeds from sales of investments |  |  | 23,806 |  |  |  | 13,890 |  |
| Proceeds from maturities of investments |  |  | 11,790 |  |  |  | 11,632 |  |
| Acquisition of businesses, net of cash and cash equivalents acquired |  |  | (3,161 | ) |  |  | (238 | ) |
| Proceeds from business divestiture |  |  | 372 |  |  |  | — |  |
| Purchases of investments in privately held companies |  |  | (202 | ) |  |  | (155 | ) |
| Return of investments in privately held companies |  |  | 74 |  |  |  | 274 |  |
| Acquisition of property and equipment |  |  | (880 | ) |  |  | (907 | ) |
| Proceeds from sales of property and equipment |  |  | 11 |  |  |  | 8 |  |
| Other |  |  | (195 | ) |  |  | (115 | ) |
| Net cash used in investing activities |  |  | (4,751 | ) |  |  | (6,228 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Issuances of common stock |  |  | 771 |  |  |  | 1,584 |  |
| Repurchases of common stock—repurchase program |  |  | (3,154 | ) |  |  | (3,325 | ) |
| Shares repurchased for tax withholdings on vesting of restricted stock units |  |  | (469 | ) |  |  | (415 | ) |
| Short-term borrowings, original maturities less than 90 days, net |  |  | (4 | ) |  |  | 496 |  |
| Issuances of debt |  |  | 6,978 |  |  |  | — |  |
| Repayments of debt |  |  | (3,863 | ) |  |  | (507 | ) |
| Excess tax benefits from share-based compensation |  |  | 103 |  |  |  | 102 |  |
| Dividends paid |  |  | (3,441 | ) |  |  | (3,017 | ) |
| Other |  |  | 96 |  |  |  | 40 |  |
| Net cash used in financing activities |  |  | (2,983 | ) |  |  | (5,042 | ) |
| Net increase (decrease) in cash and cash equivalents |  |  | 2,018 |  |  |  | (2,856 | ) |
| Cash and cash equivalents, beginning of period |  |  | 6,877 |  |  |  | 6,726 |  |
| Cash and cash equivalents, end of period |  | $ | 8,895 |  |  | $ | 3,870 |  |
| Supplemental cash flow information: |  |  |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 691 |  |  | $ | 646 |  |
| Cash paid for income taxes, net |  | $ | 2,093 |  |  | $ | 1,680 |  |

[0001193125-16-594463:8k_2_02:105]
Certain reclassifications have been made to prior year amounts to conform to the current year’s
presentation.

[0001193125-16-594463:8k_2_02:106]
9

[0001193125-16-594463:8k_2_02:107]
CISCO SYSTEMS, INC.

[0001193125-16-594463:8k_2_02:108]
DEFERRED REVENUE

[0001193125-16-594463:8k_2_02:109]
(In
millions)

[0001193125-16-594463:8k_2_02:110]
|  |  | April 30,2016 |  |  | January 23,2016 |  |  | April 25,2015 |  |
| Deferred revenue: |  |  |  |  |  |  |  |  |  |  |  |  |
| Service |  | $ | 9,866 |  |  | $ | 9,657 |  |  | $ | 9,236 |  |
| Product: |  |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized revenue on product shipments and other deferred revenue |  |  | 4,987 |  |  |  | 4,974 |  |  |  | 4,258 |  |
| Cash receipts related to unrecognized revenue from two-tier distributors |  |  | 419 |  |  |  | 554 |  |  |  | 687 |  |
| Total product deferred revenue |  |  | 5,406 |  |  |  | 5,528 |  |  |  | 4,945 |  |
| Total |  | $ | 15,272 |  |  | $ | 15,185 |  |  | $ | 14,181 |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |  |
| Current |  | $ | 9,662 |  |  | $ | 9,796 |  |  | $ | 9,371 |  |
| Noncurrent |  |  | 5,610 |  |  |  | 5,389 |  |  |  | 4,810 |  |
| Total |  | $ | 15,272 |  |  | $ | 15,185 |  |  | $ | 14,181 |  |

[0001193125-16-594463:8k_2_02:111]
CISCO SYSTEMS, INC.

[0001193125-16-594463:8k_2_02:112]
INVENTORIES AND INVENTORY TURNS

[0001193125-16-594463:8k_2_02:113]
(In millions, except annualized inventory turns)

[0001193125-16-594463:8k_2_02:114]
|  |  | April 30,2016 |  |  | January 23,2016 |  |  | April 25,2015 |  |
| Inventories: |  |  |  |  |  |  |  |  |  |  |  |  |
| Raw materials |  | $ | 108 |  |  | $ | 99 |  |  | $ | 264 |  |
| Work in process |  |  | — |  |  |  | 1 |  |  |  | 2 |  |
| Finished goods: |  |  |  |  |  |  |  |  |  |  |  |  |
| Distributor inventory and deferred cost of sales |  |  | 513 |  |  |  | 564 |  |  |  | 635 |  |
| Manufactured finished goods |  |  | 469 |  |  |  | 446 |  |  |  | 547 |  |
| Total finished goods |  |  | 982 |  |  |  | 1,010 |  |  |  | 1,182 |  |
| Service-related spares |  |  | 234 |  |  |  | 224 |  |  |  | 268 |  |
| Demonstration systems |  |  | 19 |  |  |  | 28 |  |  |  | 44 |  |
| Total |  | $ | 1,343 |  |  | $ | 1,362 |  |  | $ | 1,760 |  |
| Annualized inventory turns - GAAP |  |  | 12.0 |  |  |  | 12.6 |  |  |  | 10.1 |  |
| Cost of sales adjustments |  |  | (0.3 | ) |  |  | (0.4 | ) |  |  | (0.1 | ) |
| Annualized inventory turns - non-GAAP |  |  | 11.7 |  |  |  | 12.2 |  |  |  | 10.0 |  |

[0001193125-16-594463:8k_2_02:115]
CISCO SYSTEMS, INC.

[0001193125-16-594463:8k_2_02:116]
DIVIDENDS PAID AND REPURCHASES OF COMMON STOCK

[0001193125-16-594463:8k_2_02:117]
(In millions, except per-share amounts)

[0001193125-16-594463:8k_2_02:118]
|  |  | DIVIDENDS |  |  | STOCK REPURCHASE PROGRAM |  |  | TOTAL |  |
| Quarter Ended |  | Per Share |  |  | Amount |  |  | Shares |  |  | Weighted-Average Priceper Share |  |  | Amount |  |  | Amount |  |
| Fiscal 2016 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| April 30, 2016 |  | $ | 0.26 |  |  | $ | 1,308 |  |  |  | 27 |  |  | $ | 24.08 |  |  | $ | 649 |  |  | $ | 1,957 |  |
| January 23, 2016 |  |  | 0.21 |  |  |  | 1,065 |  |  |  | 48 |  |  |  | 26.12 |  |  |  | 1,262 |  |  |  | 2,327 |  |
| October 24, 2015 |  |  | 0.21 |  |  |  | 1,068 |  |  |  | 45 |  |  |  | 26.83 |  |  |  | 1,207 |  |  |  | 2,275 |  |
|  |  | $ | 0.68 |  |  | $ | 3,441 |  |  |  | 120 |  |  | $ | 25.93 |  |  | $ | 3,118 |  |  | $ | 6,559 |  |
| Fiscal 2015 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| July 25, 2015 |  | $ | 0.21 |  |  | $ | 1,069 |  |  |  | 35 |  |  | $ | 28.62 |  |  | $ | 1,005 |  |  | $ | 2,074 |  |
| April 25, 2015 |  |  | 0.21 |  |  |  | 1,070 |  |  |  | 35 |  |  |  | 28.39 |  |  |  | 1,008 |  |  |  | 2,078 |  |
| January 24, 2015 |  |  | 0.19 |  |  |  | 974 |  |  |  | 44 |  |  |  | 27.63 |  |  |  | 1,208 |  |  |  | 2,182 |  |
| October 25, 2014 |  |  | 0.19 |  |  |  | 973 |  |  |  | 41 |  |  |  | 24.58 |  |  |  | 1,013 |  |  |  | 1,986 |  |
| Total |  | $ | 0.80 |  |  | $ | 4,086 |  |  |  | 155 |  |  | $ | 27.22 |  |  | $ | 4,234 |  |  | $ | 8,320 |  |

[0001193125-16-594463:8k_2_02:119]
CISCO SYSTEMS, INC.

[0001193125-16-594463:8k_2_02:120]
FREE CASH FLOW

[0001193125-16-594463:8k_2_02:121]
(In
millions)

[0001193125-16-594463:8k_2_02:122]
|  |  | Three Months Ended |  |
|  |  | April 30, 2016 |  |  | January 23, 2016 |  |  | April 25, 2015 |  |
| Net cash provided by operating activities |  | $ | 3,064 |  |  | $ | 3,922 |  |  | $ | 3,040 |  |
| Acquisition of property and equipment |  |  | (304 | ) |  |  | (314 | ) |  |  | (357 | ) |
| Free cash flow |  | $ | 2,760 |  |  | $ | 3,608 |  |  | $ | 2,683 |  |

[0001193125-16-594463:8k_2_02:123]
11

[0001193125-16-594463:8k_2_02:124]
CISCO SYSTEMS, INC.

[0001193125-16-594463:8k_2_02:125]
SUPPLEMENTARY INFORMATION - RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-16-594463:8k_2_02:126]
GROSS MARGINS, OPERATING EXPENSES, OPERATING MARGINS, AND NET INCOME

[0001193125-16-594463:8k_2_02:127]
(In millions, except percentages)

[0001193125-16-594463:8k_2_02:128]
|  |  | Three Months Ended April 30, 2016 |  |
|  |  |  | ProductGross Margin |  |  |  | ServiceGross Margin |  |  |  | TotalGross Margin |  |  |  | Operating Expenses |  |  |  | Y/Y |  |  |  | Operating Income |  |  |  | Y/Y |  |  |  | Net Income |  |  |  | Y/Y |  |
| GAAP amount |  | $ | 5,661 |  |  | $ | 2,060 |  |  | $ | 7,721 |  |  | $ | 4,737 |  |  |  | 3% |  |  | $ | 2,984 |  |  |  | 2% |  |  | $ | 2,349 |  |  |  | (4)% |  |
| % of revenue |  |  | 63.8% |  |  |  | 65.9% |  |  |  | 64.3% |  |  |  | 39.5% |  |  |  |  |  |  |  | 24.9% |  |  |  |  |  |  |  | 19.6% |  |  |  |  |  |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 21 |  |  |  | 37 |  |  |  | 58 |  |  |  | 337 |  |  |  |  |  |  |  | 395 |  |  |  |  |  |  |  | 395 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  |  | 115 |  |  |  | — |  |  |  | 115 |  |  |  | 81 |  |  |  |  |  |  |  | 196 |  |  |  |  |  |  |  | 196 |  |  |  |  |  |
| Supplier component remediation adjustment |  |  | (74) |  |  |  | — |  |  |  | (74) |  |  |  | — |  |  |  |  |  |  |  | (74) |  |  |  |  |  |  |  | (74) |  |  |  |  |  |
| Acquisition/divestiture-related costs |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 76 |  |  |  |  |  |  |  | 76 |  |  |  |  |  |  |  | 76 |  |  |  |  |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 17 |  |  |  |  |  |  |  | 17 |  |  |  |  |  |  |  | 17 |  |  |  |  |  |
| Income tax/significant tax matters |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | (79) |  |  |  |  |  |
| Non-GAAP amount |  | $ | 5,723 |  |  | $ | 2,097 |  |  | $ | 7,820 |  |  | $ | 4,226 |  |  |  | 4% |  |  | $ | 3,594 |  |  |  | 5% |  |  | $ | 2,880 |  |  |  | 4% |  |
| % of revenue |  |  | 64.5% |  |  |  | 67.1% |  |  |  | 65.2% |  |  |  | 35.2% |  |  |  |  |  |  |  | 30.0% |  |  |  |  |  |  |  | 24.0% |  |  |  |  |  |

[0001193125-16-594463:8k_2_02:129]
On November 20, 2015, during the second quarter of fiscal 2016, Cisco completed its divestiture of the SP Video CPE Business.
Accordingly, the growth rates above are normalized to exclude the SP Video CPE Business for the third quarter of fiscal 2015 as detailed in the table below.

[0001193125-16-594463:8k_2_02:130]
|  |  | Three Months EndedApril 25, 2015 |  |
|  |  | ProductGross Margin |  |  | ServiceGross Margin |  |  | TotalGross Margin |  |  | Operating Expenses |  |  | Operating Income |  |  | Net Income |  |
| GAAP amount |  | $ | 5,742 |  |  | $ | 1,783 |  |  | $ | 7,525 |  |  | $ | 4,600 |  |  | $ | 2,925 |  |  | $ | 2,437 |  |
| % of revenue |  |  | 61.6% |  |  |  | 63.4% |  |  |  | 62.0% |  |  |  | 37.9% |  |  |  | 24.1% |  |  |  | 20.1% |  |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 12 |  |  |  | 44 |  |  |  | 56 |  |  |  | 311 |  |  |  | 367 |  |  |  | 367 |  |
| Amortization of acquisition-related intangible assets |  |  | 172 |  |  |  | — |  |  |  | 172 |  |  |  | 70 |  |  |  | 242 |  |  |  | 242 |  |
| Supplier component remediation adjustment |  |  | (164) |  |  |  | — |  |  |  | (164) |  |  |  | — |  |  |  | (164) |  |  |  | (164) |  |
| Acquisition/divestiture-related costs |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 79 |  |  |  | 79 |  |  |  | 79 |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 24 |  |  |  | 24 |  |  |  | 24 |  |
| Income tax/significant tax matters |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (190) |  |
| Non-GAAP amount |  | $ | 5,762 |  |  | $ | 1,827 |  |  | $ | 7,589 |  |  | $ | 4,116 |  |  | $ | 3,473 |  |  | $ | 2,795 |  |
| Less: SP Video CPE Business |  |  | (84) |  |  |  | — |  |  |  | (84) |  |  |  | (37) |  |  |  | (47) |  |  |  | (36) |  |
| Non-GAAP amount (excluding SP Video CPE Business) |  | $ | 5,678 |  |  | $ | 1,827 |  |  | $ | 7,505 |  |  | $ | 4,079 |  |  | $ | 3,426 |  |  | $ | 2,759 |  |
| % of revenue |  |  | 64.5% |  |  |  | 65.0% |  |  |  | 64.6% |  |  |  | 35.1% |  |  |  | 29.5% |  |  |  | 23.7% |  |

[0001193125-16-594463:8k_2_02:131]
12

[0001193125-16-594463:8k_2_02:132]
EFFECTIVE TAX RATE

[0001193125-16-594463:8k_2_02:133]
(In percentages)

[0001193125-16-594463:8k_2_02:134]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | April 30,2016 |  |  | April 25,2015 |  |  | April 30,2016 |  |  | April 25,2015 |  |
| GAAP effective tax rate |  |  | 23.8 | % |  |  | 19.7 | % |  |  | 16.8 | % |  |  | 19.4 | % |
| Tax effect of non-GAAP adjustments to net income |  |  | (1.8 | )% |  |  | 2.3 | % |  |  | 5.2 | % |  |  | 2.6 | % |
| Non-GAAP effective tax rate |  |  | 22.0 | % |  |  | 22.0 | % |  |  | 22.0 | % |  |  | 22.0 | % |

[0001193125-16-594463:8k_2_02:135]
COST OF SALES USED IN INVENTORY TURNS

[0001193125-16-594463:8k_2_02:136]
(In millions)

[0001193125-16-594463:8k_2_02:137]
|  |  | Three Months Ended |  |
|  |  | April 30,2016 |  |  | January 23,2016 |  |  | April 25,2015 |  |
| GAAP cost of sales |  | $ | 4,279 |  |  | $ | 4,495 |  |  | $ | 4,612 |  |
| Cost of sales adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | (58 | ) |  |  | (51 | ) |  |  | (56 | ) |
| Amortization of acquisition-related intangible assets |  |  | (115 | ) |  |  | (123 | ) |  |  | (172 | ) |
| Supplier component remediation adjustment |  |  | 74 |  |  |  | — |  |  |  | 164 |  |
| Acquisition-related/divestiture costs |  |  | — |  |  |  | (1 | ) |  |  | — |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | 1 |  |  |  | — |  |
| Non-GAAP cost of sales |  | $ | 4,180 |  |  | $ | 4,321 |  |  | $ | 4,548 |  |

[0001193125-16-594463:8k_2_02:138]
13

[0001193125-16-594463:8k_2_02:139]
Forward Looking Statements, Non-GAAP Information and Additional Information

[0001193125-16-594463:8k_2_02:140]
This release includes non-GAAP net income, non-GAAP gross margins, non-GAAP operating expenses, non-GAAP operating income
and margin, non-GAAP effective tax rates, non-GAAP net income per share data, non-GAAP inventory turns and free cash flow for the periods presented. It also includes future estimated ranges for gross margin, operating margin, tax provision rate and
EPS on a non-GAAP basis.

[0001193125-16-594463:8k_2_02:141]
These non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with generally
accepted accounting principles and may be different from non-GAAP measures used by other companies. In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles. Cisco believes that non-GAAP measures
have limitations in that they do not reflect all of the amounts associated with Cisco’s results of operations as determined in accordance with GAAP and that these measures should only be used to evaluate Cisco’s results of operations in
conjunction with the corresponding GAAP measures.

[0001193125-16-594463:8k_2_02:142]
Cisco believes that the presentation of non-GAAP measures when shown in conjunction with the
corresponding GAAP measures, provides useful information to investors and management regarding financial and business trends relating to its financial condition and its historical and projected results of operations. In addition, Cisco believes that
the presentation of non-GAAP inventory turns provides useful information to investors and management regarding financial and business trends relating to inventory management based on the operating activities of the periods presented. Cisco believes
that the presentation of free cash flow, which it defines as the net cash provided by operating activities less cash used to acquire property and equipment, to be a liquidity measure that provides useful information to management and investors
because of its intent to return a stated percentage of free cash flow to shareholders in the form of dividends and stock repurchases. Cisco further regards free cash flow as a useful measure because it reflects cash that can be used to, among other
things, invest in its business, make strategic acquisitions, repurchase common stock and pay dividends on its common stock, after deducting capital investments.

[0001193125-16-594463:8k_2_02:143]
For its internal budgeting process, Cisco’s management uses financial statements that do not include, when applicable, share-based compensation expense,
amortization of acquisition-related intangible assets, impact to cost of sales from purchase accounting adjustments to inventory, acquisition-related/divestiture costs, significant asset impairments and restructurings,

[0001193125-16-594463:8k_2_02:144]
significant litigation and other contingencies, significant gains and losses on investments, the income tax effects of the foregoing and significant tax matters. Cisco’s management also uses
the foregoing non-GAAP measures, in addition to the corresponding GAAP measures, in reviewing the financial results of Cisco. In prior periods, Cisco has excluded other items that it no longer excludes for purposes of its non-GAAP financial
measures. From time to time in the future there may be other items that Cisco may exclude for purposes of its internal budgeting process and in reviewing its financial results. For additional information on the items excluded by Cisco from one or
more of its non-GAAP financial measures, refer to the Form 8-K regarding this release furnished today to the Securities and Exchange Commission.

[0001193125-16-594463:8k_2_02:145]
Cisco
divested the Customer Premises Equipment portion of the Service Provider Video Connected Devices business (“SP Video CPE Business”) during the second quarter of fiscal 2016 on November 20, 2015. This release includes, where indicated,
financial measures that exclude the SP Video CPE Business. Cisco believes that the presentation of these measures provides useful information to investors and management regarding financial and business trends relating to its financial condition and
its historical and projected results of operations because the SP Video CPE Business is no longer part of Cisco and will not be part of Cisco on a go forward basis. Cisco’s management also uses the financial measures excluding the SP Video CPE
Business in reviewing the financial results of Cisco.

[0001193125-16-594463:8k_2_02:146]
About Cisco

[0001193125-16-594463:8k_2_02:147]
Cisco (NASDAQ: CSCO) is the worldwide technology leader that has been making the Internet work since 1984. Our people, products and partners help society
securely connect and seize tomorrow’s digital opportunity today. Discover more at thenetwork.cisco.com and follow us on Twitter at @Cisco.

[0001193125-16-594463:8k_2_02:148]
Copyright
© 2016 Cisco and/or its affiliates. All rights reserved. Cisco and the Cisco logo are trademarks or registered trademarks of Cisco and/or its affiliates in the U.S. and other countries. To
view a list of Cisco trademarks, go to: www.cisco.com/go/trademarks. Third-party trademarks mentioned in this document are the property of their respective owners. The use of the word partner does not imply a partnership relationship between Cisco
and any other company. This document is Cisco Public Information.

[0001193125-16-594463:8k_2_02:149]
15
