# CSCO notes — 0000858877-16-000109


## csco:CompensationexpensesrelatedtobusinesscombinationsTableTextBlock

[0000858877-16-000109:notes:1]
[same as prior period, unchanged from 0000858877-16-000090:notes:1]

[0000858877-16-000109:notes:2]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 30, 2016 |  | April 25, 2015 |  | April 30, 2016 |  | April 25, 2015 |
| Compensation expense related to acquisitions | $ | 68 |  |  | $ | 72 |  |  | $ | 212 |  |  | $ | 264 |  |


## csco:DescriptionOfNewAccountingPronouncementsNotYetAdoptedPolicyTextBlock

[0000858877-16-000109:notes:3]
Recent Accounting Standards or Updates Not Yet Effective

[0000858877-16-000109:notes:4]
Revenue Recognition  In May 2014, the Financial Accounting Standards Board (FASB) issued an accounting standard update related to revenue from contracts with customers, which will supersede nearly all current U.S. GAAP guidance on this topic and eliminate industry-specific guidance. The underlying principle is to recognize revenue when promised goods or services are transferred to customers in an amount that reflects the consideration that is expected to be received for those goods or services. This accounting standard update, as amended, will be effective for the Company beginning in the first quarter of fiscal 2019. The new revenue standard may be applied retrospectively to each prior period presented or retrospectively with the cumulative effect recognized as of the date of adoption. Early adoption is permitted, but no earlier than fiscal 2018. The Company expects to adopt this accounting standard update in the first quarter of fiscal 2019, and it is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.

[0000858877-16-000109:notes:5]
Consolidation of Certain Types of Legal Entities  In February 2015, the FASB issued an accounting standard update that changes the analysis that a reporting entity must perform to determine whether it should consolidate certain types of legal entities. The accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2017, and early adoption is permitted. The application of this accounting standard update is not expected to have a material impact on the Company's Consolidated Financial Statements.

[0000858877-16-000109:notes:6]
Classification of Deferred Taxes  In November 2015, the FASB issued an accounting standard update that requires that all deferred tax assets and liabilities, along with any related valuation allowance, be classified as noncurrent on the balance sheet. The accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2018, and early adoption is permitted. The accounting standard update is a change in balance sheet presentation only.

[0000858877-16-000109:notes:7]
Financial Instruments  In January 2016, the FASB issued an accounting standard update that changes the accounting for equity investments, financial liabilities under the fair value option, and the presentation and disclosure requirements for financial instruments.  The accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2019, and early adoption is permitted. The Company is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.

[0000858877-16-000109:notes:8]
Leases  In February 2016, the FASB issued an accounting standard update related to leases requiring lessees to recognize operating and financing lease liabilities on the balance sheet, as well as corresponding right-of-use assets.  The new lease standard also makes some changes to lessor accounting and aligns key aspects of the lessor accounting model with the revenue recognition standard. In addition, disclosures will be required to enable users of financial statements to assess the amount, timing, and uncertainty of cash flows arising from leases. The accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2020 on a modified retrospective basis, and early adoption is permitted. The Company is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.

[0000858877-16-000109:notes:9]
Share-Based Compensation  In March 2016, the FASB issued an accounting standard update that impacts the accounting for share-based payment transactions, including income tax consequences, classification of awards as either equity or liabilities, and classification on the Consolidated Statements of Cash Flows.  The accounting standard will be effective for the Company beginning the first quarter of fiscal 2018, and early adoption is permitted. The Company is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.


## csco:EntityWideDisclosureOnGeographicAreasLongLivedAssetsTableTextBlock

[0000858877-16-000109:notes:10]
[same as prior period, unchanged from 0000858877-16-000090:notes:7]

[0000858877-16-000109:notes:11]
|  | April 30, 2016 |  | July 25, 2015 |
| Property and equipment, net: |  |  |  |
| United States | $ | 2,823 |  |  | $ | 2,733 |  |
| International | 706 |  |  | 599 |  |
| Total | $ | 3,529 |  |  | $ | 3,332 |  |


## csco:IncometaxprovisionTableTextBlock

[0000858877-16-000109:notes:12]
[same as prior period, unchanged from 0000858877-16-000090:notes:9]

[0000858877-16-000109:notes:13]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 30, 2016 |  | April 25, 2015 |  | April 30, 2016 |  | April 25, 2015 |
| Income before provision for income taxes | $ | 3,083 |  |  | $ | 3,035 |  |  | $ | 9,526 |  |  | $ | 8,268 |  |
| Provision for income taxes | $ | 734 |  |  | $ | 598 |  |  | $ | 1,600 |  |  | $ | 1,606 |  |
| Effective tax rate | 23.8 | % |  | 19.7 | % |  | 16.8 | % |  | 19.4 | % |


## csco:NetSalesForGroupsOfSimilarProductsAndServicesTableTextBlock

[0000858877-16-000109:notes:14]
[same as prior period, unchanged from 0000858877-16-000090:notes:11]

[0000858877-16-000109:notes:15]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 30, 2016 |  | April 25, 2015 |  | April 30, 2016 |  | April 25, 2015 |
| Revenue: |  |  |  |  |  |  |  |
| Switching | $ | 3,447 |  |  | $ | 3,560 |  |  | $ | 10,952 |  |  | $ | 11,021 |  |
| NGN Routing | 1,894 |  |  | 1,999 |  |  | 5,532 |  |  | 5,712 |  |
| Collaboration | 1,069 |  |  | 974 |  |  | 3,203 |  |  | 2,915 |  |
| Data Center | 811 |  |  | 801 |  |  | 2,492 |  |  | 2,339 |  |
| Service Provider Video (1) | 468 |  |  | 914 |  |  | 1,980 |  |  | 2,561 |  |
| Wireless | 615 |  |  | 611 |  |  | 1,873 |  |  | 1,827 |  |
| Security | 482 |  |  | 412 |  |  | 1,429 |  |  | 1,283 |  |
| Other | 89 |  |  | 55 |  |  | 241 |  |  | 181 |  |
| Product | 8,875 |  |  | 9,326 |  |  | 27,702 |  |  | 27,839 |  |
| Service | 3,125 |  |  | 2,811 |  |  | 8,907 |  |  | 8,479 |  |
| Total | $ | 12,000 |  |  | $ | 12,137 |  |  | $ | 36,609 |  |  | $ | 36,318 |  |

[0000858877-16-000109:notes:16]
(1) Includes SP Video CPE Business revenue of zero and $519 million for the third quarters of fiscal 2016 and 2015, respectively and $504 million and $1,359 million for the first nine months of fiscal 2016 and 2015, respectively.


## csco:ScheduleOfCommonStockRepurchasedTextBlock

[0000858877-16-000109:notes:17]
[same as prior period, unchanged from 0000858877-16-000090:notes:13]

[0000858877-16-000109:notes:18]
|  | SharesRepurchased |  | Weighted-Average Priceper Share |  | AmountRepurchased |
| Cumulative balance at July 25, 2015 | 4,443 |  |  | $ | 20.86 |  |  | $ | 92,679 |  |
| Repurchase of common stock under the stock repurchase program (1) | 120 |  |  | 25.93 |  |  | 3,118 |  |
| Cumulative balance at April 30, 2016 | 4,563 |  |  | $ | 20.99 |  |  | $ | 95,797 |  |

[0000858877-16-000109:notes:19]
(1) There were no stock repurchases pending settlement as of April 30, 2016. There were $36 million of stock repurchases that were pending settlement as of July 25, 2015.


## csco:ScheduleOfDerivativeFairValueHedgeInstrumentsGainLossInStatementOfFinancialPerformanceTableTextBlock

[0000858877-16-000109:notes:20]
[same as prior period, unchanged from 0000858877-16-000090:notes:16]

[0000858877-16-000109:notes:21]
|  |  |  |  | GAINS (LOSSES) ONDERIVATIVEINSTRUMENTS FOR THETHREE MONTHS ENDED |  | GAINS (LOSSES)RELATED TO HEDGEDITEMS FOR THE THREE MONTHS ENDED |
| Derivatives Designated as Fair Value Hedging Instruments |  | Line Item in Statements of Operations |  | April 30, 2016 |  | April 25, 2015 |  | April 30, 2016 |  | April 25, 2015 |
| Equity derivatives |  | Other income (loss), net |  | $ | — |  |  | $ | (8 | ) |  | $ | — |  |  | $ | 8 |  |
| Interest rate derivatives |  | Interest expense |  | 19 |  |  | (9 | ) |  | (18 | ) |  | 9 |  |
| Total |  |  |  | $ | 19 |  |  | $ | (17 | ) |  | $ | (18 | ) |  | $ | 17 |  |

[0000858877-16-000109:notes:22]
|  |  |  |  | GAINS (LOSSES) ONDERIVATIVEINSTRUMENTS FOR THENINE MONTHS ENDED |  | GAINS (LOSSES)RELATED TO HEDGEDITEMS FOR THE NINE MONTHS ENDED |
| Derivatives Designated as Fair Value Hedging Instruments |  | Line Item in Statements of Operations |  | April 30, 2016 |  | April 25, 2015 |  | April 30, 2016 |  | April 25, 2015 |
| Equity derivatives |  | Other income (loss), net |  | $ | — |  |  | $ | (20 | ) |  | $ | — |  |  | $ | 20 |  |
| Interest rate derivatives |  | Interest expense |  | 130 |  |  | 122 |  |  | (125 | ) |  | (125 | ) |
| Total |  |  |  | $ | 130 |  |  | $ | 102 |  |  | $ | (125 | ) |  | $ | (105 | ) |


## csco:ScheduleOfFiniteLivedIntangibleAssetsAmortizationExpenseTableTextBlock

[0000858877-16-000109:notes:23]
[same as prior period, unchanged from 0000858877-16-000090:notes:19]

[0000858877-16-000109:notes:24]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 30, 2016 |  | April 25, 2015 |  | April 30, 2016 |  | April 25, 2015 |
| Amortization of purchased intangible assets: |  |  |  |  |  |  |  |
| Cost of sales | $ | 134 |  |  | $ | 187 |  |  | $ | 419 |  |  | $ | 618 |  |
| Operating expenses | 81 |  |  | 70 |  |  | 221 |  |  | 213 |  |
| Total | $ | 215 |  |  | $ | 257 |  |  | $ | 640 |  |  | $ | 831 |  |


## csco:ScheduleOfIntangibleAssetsAcquiredAsPartOfBusinessCombinationTextBlock

[0000858877-16-000109:notes:25]
[same as prior period, unchanged from 0000858877-16-000090:notes:21]

[0000858877-16-000109:notes:26]
The following table presents details of the Company’s intangible assets acquired through acquisitions completed during the nine months ended April 30, 2016 (in millions, except years):

[0000858877-16-000109:notes:27]
|  | FINITE LIVES |  | INDEFINITELIVES |  | TOTAL |
|  | TECHNOLOGY |  | CUSTOMERRELATIONSHIPS |  | OTHER |  | IPR&D |  |
|  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Amount |  | Amount |
| MaintenanceNet | 5.0 |  | $ | 50 |  |  | 5.0 |  | $ | 2 |  |  | 2.0 |  | $ | 2 |  |  | $ | 11 |  |  | $ | 65 |  |
| OpenDNS | 5.0 |  | 43 |  |  | 7.0 |  | 15 |  |  | 1.0 |  | 2 |  |  | 1 |  |  | 61 |  |
| Lancope | 5.0 |  | 79 |  |  | 6.0 |  | 29 |  |  | 3.0 |  | 3 |  |  | 10 |  |  | 121 |  |
| Acano | 5.0 |  | 9 |  |  | 5.0 |  | 12 |  |  | 0.0 |  | — |  |  | 82 |  |  | 103 |  |
| Leaba | 0.0 |  | — |  |  | 0.0 |  | — |  |  | 0.0 |  | — |  |  | 96 |  |  | 96 |  |
| Jasper | 6.0 |  | 240 |  |  | 7.0 |  | 75 |  |  | 2.0 |  | 23 |  |  | 23 |  |  | 361 |  |
| CliQr | 6.0 |  | 65 |  |  | 6.0 |  | 3 |  |  | 2.0 |  | 1 |  |  | — |  |  | 69 |  |
| Others (five in total) | 4.1 |  | 58 |  |  | 6.3 |  | 6 |  |  | 0.0 |  | — |  |  | — |  |  | 64 |  |
| Total |  |  | $ | 544 |  |  |  |  | $ | 142 |  |  |  |  | $ | 31 |  |  | $ | 223 |  |  | $ | 940 |  |


## csco:ScheduleOfIntangibleAssetsByMajorClassTextBlock

[0000858877-16-000109:notes:28]
[same as prior period, unchanged from 0000858877-16-000090:notes:24]

[0000858877-16-000109:notes:29]
| April 30, 2016 |  | Gross |  | Accumulated Amortization |  | Net |
| Purchased intangible assets with finite lives: |  |  |  |  |  |  |
| Technology |  | $ | 3,103 |  |  | $ | (1,297 | ) |  | $ | 1,806 |  |
| Customer relationships |  | 1,821 |  |  | (1,156 | ) |  | 665 |  |
| Other |  | 85 |  |  | (36 | ) |  | 49 |  |
| Total purchased intangible assets with finite lives |  | 5,009 |  |  | (2,489 | ) |  | 2,520 |  |
| In-process research and development, with indefinite lives |  | 224 |  |  | — |  |  | 224 |  |
| Total |  | $ | 5,233 |  |  | $ | (2,489 | ) |  | $ | 2,744 |  |

[0000858877-16-000109:notes:30]
[same as prior period, unchanged from 0000858877-16-000090:notes:26]


## csco:SegmentReportingProductAndServicesNetSalesTextBlock

[0000858877-16-000109:notes:31]
[same as prior period, unchanged from 0000858877-16-000090:notes:27]

[0000858877-16-000109:notes:32]
[same as prior period, unchanged from 0000858877-16-000090:notes:28]

[0000858877-16-000109:notes:33]
The Company conducts business globally and is primarily managed on a geographic basis consisting of three segments: the Americas, EMEA, and APJC. The Company’s management makes financial decisions and allocates resources based on the information it receives from its internal management system. Sales are attributed to a segment based on the ordering location of the customer. The Company does not allocate research and development, sales and marketing, or general and administrative expenses to its segments in this internal management system because management does not include the information in its measurement of the performance of the operating segments. In addition, the Company does not allocate amortization and impairment of acquisition-related intangible assets, share-based compensation expense, significant litigation and other contingencies, impacts to cost of sales from purchase accounting adjustments to inventory, charges related to asset impairments and restructurings, and certain other charges to the gross margin for each segment because management does not include this information in its measurement of the performance of the operating segments.

[0000858877-16-000109:notes:34]
Summarized financial information by segment for the three and nine months ended April 30, 2016 and April 25, 2015, based on the Company’s internal management system and as utilized by the Company’s Chief Operating Decision Maker ("CODM"), is as follows (in millions):

[0000858877-16-000109:notes:35]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 30, 2016 |  | April 25, 2015 |  | April 30, 2016 |  | April 25, 2015 |
| Revenue: |  |  |  |  |  |  |  |
| Americas | $ | 7,062 |  |  | $ | 7,252 |  |  | $ | 21,773 |  |  | $ | 21,854 |  |
| EMEA | 3,001 |  |  | 3,119 |  |  | 9,176 |  |  | 9,212 |  |
| APJC | 1,937 |  |  | 1,766 |  |  | 5,660 |  |  | 5,252 |  |
| Total | $ | 12,000 |  |  | $ | 12,137 |  |  | $ | 36,609 |  |  | $ | 36,318 |  |
| Gross margin: |  |  |  |  |  |  |  |
| Americas | $ | 4,684 |  |  | $ | 4,560 |  |  | $ | 14,046 |  |  | $ | 13,776 |  |
| EMEA | 1,966 |  |  | 1,949 |  |  | 5,953 |  |  | 5,774 |  |
| APJC | 1,170 |  |  | 1,080 |  |  | 3,437 |  |  | 3,157 |  |
| Segment total | 7,820 |  |  | 7,589 |  |  | 23,436 |  |  | 22,707 |  |
| Unallocated corporate items | (99 | ) |  | (64 | ) |  | (451 | ) |  | (759 | ) |
| Total | $ | 7,721 |  |  | $ | 7,525 |  |  | $ | 22,985 |  |  | $ | 21,948 |  |

[0000858877-16-000109:notes:36]
Revenue in the United States was $6.2 billion and $6.4 billion for the three months ended April 30, 2016 and April 25, 2015, respectively, and was $19.2 billion and $19.1 billion for the nine months ended April 30, 2016 and April 25, 2015, respectively.

[0000858877-16-000109:notes:37]
[same as prior period, unchanged from 0000858877-16-000090:notes:33]

[0000858877-16-000109:notes:38]
The Company designs and sells broad lines of products, provides services, and delivers integrated solutions to develop and connect networks around the world, building the Internet. The Company groups its products and technologies into the following categories: Switching, NGN Routing, Collaboration, Data Center, Service Provider Video, Wireless, Security, and Other Products. These products, primarily integrated by Cisco IOS Software, link geographically dispersed local-area networks (LANs), metropolitan-area networks (MANs), and wide-area networks (WANs).

[0000858877-16-000109:notes:39]
[same as prior period, unchanged from 0000858877-16-000090:notes:36]

[0000858877-16-000109:notes:40]
[same as prior period, unchanged from 0000858877-16-000090:notes:37]

[0000858877-16-000109:notes:41]
The majority of the Company’s assets, excluding cash and cash equivalents and investments, were attributable to its U.S. operations as of each of April 30, 2016 and July 25, 2015.  The Company’s total cash and cash equivalents and investments held by various foreign subsidiaries were $57.2 billion and $53.4 billion as of April 30, 2016 and July 25, 2015, respectively, and the remaining $6.3 billion and $7.0 billion at the respective period ends were available in the United States.


## csco:StockRepurchasesSinceInceptionOfProgramTableTextBlock

[0000858877-16-000109:notes:42]
[same as prior period, unchanged from 0000858877-16-000090:notes:39]

[0000858877-16-000109:notes:43]
|  | Shares ofCommonStock |  | Common Stockand AdditionalPaid-In Capital |  | RetainedEarnings |  | Total CiscoShareholders’Equity |
| Repurchases of common stock under the repurchase program | 4,563 |  |  | $ | 23,651 |  |  | $ | 72,146 |  |  | $ | 95,797 |  |


## us-gaap:AllowanceForCreditLossesOnFinancingReceivablesTableTextBlock

[0000858877-16-000109:notes:44]
[same as prior period, unchanged from 0000858877-16-000090:notes:41]

[0000858877-16-000109:notes:45]
|  | CREDIT LOSS ALLOWANCES |
| Three months ended April 30, 2016 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts and Other |  | Total |
| Allowance for credit loss as of January 23, 2016 | $ | 248 |  |  | $ | 80 |  |  | $ | 37 |  |  | $ | 365 |  |
| Provisions | 7 |  |  | 8 |  |  | 2 |  |  | 17 |  |
| Recoveries (write-offs), net | (6 | ) |  | — |  |  | — |  |  | (6 | ) |
| Foreign exchange and other | 1 |  |  | 5 |  |  | 1 |  |  | 7 |  |
| Allowance for credit loss as of April 30, 2016 | $ | 250 |  |  | $ | 93 |  |  | $ | 40 |  |  | $ | 383 |  |

[0000858877-16-000109:notes:46]
|  | CREDIT LOSS ALLOWANCES |
| Nine months ended April 30, 2016 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts and Other |  | Total |
| Allowance for credit loss as of July 25, 2015 | $ | 259 |  |  | $ | 87 |  |  | $ | 36 |  |  | $ | 382 |  |
| Provisions | 3 |  |  | 2 |  |  | 7 |  |  | 12 |  |
| Recoveries (write-offs), net | (10 | ) |  | — |  |  | (4 | ) |  | (14 | ) |
| Foreign exchange and other | (2 | ) |  | 4 |  |  | 1 |  |  | 3 |  |
| Allowance for credit loss as of April 30, 2016 | $ | 250 |  |  | $ | 93 |  |  | $ | 40 |  |  | $ | 383 |  |

[0000858877-16-000109:notes:47]
|  | CREDIT LOSS ALLOWANCES |
| Three months ended April 25, 2015 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts and Other |  | Total |
| Allowance for credit loss as of January 24, 2015 | $ | 250 |  |  | $ | 85 |  |  | $ | 40 |  |  | $ | 375 |  |
| Provisions | (4 | ) |  | (5 | ) |  | (2 | ) |  | (11 | ) |
| Recoveries (write-offs), net | (1 | ) |  | — |  |  | — |  |  | (1 | ) |
| Foreign exchange and other | (3 | ) |  | — |  |  | (1 | ) |  | (4 | ) |
| Allowance for credit loss as of April 25, 2015 | $ | 242 |  |  | $ | 80 |  |  | $ | 37 |  |  | $ | 359 |  |

[0000858877-16-000109:notes:48]
|  | CREDIT LOSS ALLOWANCES |
| Nine months ended April 25, 2015 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts and Other |  | Total |
| Allowance for credit loss as of July 26, 2014 | $ | 233 |  |  | $ | 98 |  |  | $ | 18 |  |  | $ | 349 |  |
| Provisions | 25 |  |  | (15 | ) |  | 21 |  |  | 31 |  |
| Recoveries (write-offs), net | (6 | ) |  | 1 |  |  | — |  |  | (5 | ) |
| Foreign exchange and other | (10 | ) |  | (4 | ) |  | (2 | ) |  | (16 | ) |
| Allowance for credit loss as of April 25, 2015 | $ | 242 |  |  | $ | 80 |  |  | $ | 37 |  |  | $ | 359 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000858877-16-000109:notes:49]
[same as prior period, unchanged from 0000858877-16-000090:notes:46]

[0000858877-16-000109:notes:50]
The Company completed 12 acquisitions during the nine months ended April 30, 2016. A summary of the allocation of the total purchase consideration is presented as follows (in millions):

[0000858877-16-000109:notes:51]
|  | Purchase Consideration |  | Net Tangible Assets Acquired (Liabilities Assumed) |  | Purchased Intangible Assets |  | Goodwill |
| MaintenanceNet | $ | 105 |  |  | $ | (21 | ) |  | $ | 65 |  |  | $ | 61 |  |
| OpenDNS | 545 |  |  | (9 | ) |  | 61 |  |  | 493 |  |
| Lancope | 410 |  |  | (34 | ) |  | 121 |  |  | 323 |  |
| Acano | 528 |  |  | (27 | ) |  | 103 |  |  | 452 |  |
| Leaba | 219 |  |  | (18 | ) |  | 96 |  |  | 141 |  |
| Jasper | 1,234 |  |  | 5 |  |  | 361 |  |  | 868 |  |
| CliQr | 225 |  |  | (3 | ) |  | 69 |  |  | 159 |  |
| Others (five in total) | 112 |  |  | (17 | ) |  | 64 |  |  | 65 |  |
| Total | $ | 3,378 |  |  | $ | (124 | ) |  | $ | 940 |  |  | $ | 2,562 |  |

[0000858877-16-000109:notes:52]
[same as prior period, unchanged from 0000858877-16-000090:notes:49]

[0000858877-16-000109:notes:53]
[same as prior period, unchanged from 0000858877-16-000090:notes:50]

[0000858877-16-000109:notes:54]
On December 21, 2015, the Company completed its acquisition of privately held Lancope, Inc. ("Lancope"), a provider of network behavior analytics, threat visibility, and security intelligence. With the Lancope acquisition, the Company aims to advance its "security everywhere" strategy with an additional capability of network behavior analytics that extend protection further into the network.  Revenue from the Lancope acquisition has been included in the Company's Security product category.

[0000858877-16-000109:notes:55]
On January 29, 2016, the Company completed its acquisition of privately held, London-based Acano (UK) Limited ("Acano"), a collaboration infrastructure and conferencing software provider. With the Acano acquisition, the Company aims to enhance its collaboration strategy to deliver video across both cloud and hybrid environments. Revenue from the Acano acquisition has been included in the Company's Collaboration product category.

[0000858877-16-000109:notes:56]
On March 3, 2016, the Company completed its acquisition of privately held Leaba Semiconductor, Ltd. ("Leaba"), an Israeli-based fabless semiconductor provider whose semiconductor expertise is expected to be leveraged to accelerate the Company's next-generation product portfolio. This acquisition is a component of the Company's strategy to enhance its product offerings in the networking chipset market.

[0000858877-16-000109:notes:57]
On March 18, 2016, the Company completed its acquisition of privately held Jasper Technologies, Inc. ("Jasper"), a provider of a cloud-based Internet of Things (IoT) software-as-a-service platform to help enterprises and service providers launch, manage, and monetize IoT services on a global scale.  With the Jasper acquisition, the Company aims to offer an IoT solution that is interoperable across devices and works with IoT service providers, application developers, and an ecosystem of partners. Revenue from the Jasper acquisition has been included in the Company's Other product category.

[0000858877-16-000109:notes:58]
On April 15, 2016, the Company completed its acquisition of privately held CliQr Technologies, Inc. ("CliQr"), an application-defined cloud orchestration platform provider. With the CliQr acquisition, the Company aims to help its customers simplify and accelerate their private, public, and hybrid cloud deployments.

[0000858877-16-000109:notes:59]
The total purchase consideration related to the Company’s acquisitions completed during the nine months ended April 30, 2016 consisted of cash consideration and the assumption of vested share-based awards. The total cash and cash equivalents acquired from these business combinations was approximately $44 million. Total transaction costs related to the Company’s acquisition activities were $29 million and $5 million for the nine months ended April 30, 2016 and April 25, 2015, respectively. These transaction costs were expensed as incurred in general and administrative expenses ("G&A") in the Consolidated Statements of Operations.

[0000858877-16-000109:notes:60]
[same as prior period, unchanged from 0000858877-16-000090:notes:53]

[0000858877-16-000109:notes:61]
The goodwill generated from the Company’s acquisitions completed during the nine months ended April 30, 2016 is primarily related to expected synergies. The goodwill is generally not deductible for income tax purposes.

[0000858877-16-000109:notes:62]
The Consolidated Financial Statements include the operating results of each acquisition from the date of acquisition. Pro forma results of operations for the acquisitions completed during the nine months ended April 30, 2016 have not been presented because the effects of the acquisitions, individually and in the aggregate, were not material to the Company’s financial results.

[0000858877-16-000109:notes:63]
Divestiture of SP Video CPE Business  On November 20, 2015, the Company completed the sale of the assets comprising the customer premises equipment portion of its Service Provider Video connected devices business ("SP Video CPE Business") to Technicolor SA. As a result of the transaction, the Company received aggregate consideration of $542 million consisting of $372 million in cash and $170 million in Technicolor stock (as of the divestiture date) and the transaction resulted in a gain of $285 million, net of certain transaction costs incurred to date.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000858877-16-000109:notes:64]
| 12. | Commitments and Contingencies |

[0000858877-16-000109:notes:65]
| (a) | Operating Leases |

[0000858877-16-000109:notes:66]
The Company leases office space in many U.S. locations. Outside the United States, larger leased sites include sites in Belgium, Canada, China, France, Germany, India, Israel, Japan, Poland and the United Kingdom. The Company also leases equipment and vehicles. Future minimum lease payments under all noncancelable operating leases with an initial term in excess of one year as of April 30, 2016 are as follows (in millions):

[0000858877-16-000109:notes:67]
| Fiscal Year | Amount |
| 2016 (remaining three months) | $ | 95 |  |
| 2017 | 288 |  |
| 2018 | 220 |  |
| 2019 | 130 |  |
| 2020 | 106 |  |
| Thereafter | 229 |  |
| Total | $ | 1,068 |  |

[0000858877-16-000109:notes:68]
| (b) | Purchase Commitments with Contract Manufacturers and Suppliers |

[0000858877-16-000109:notes:69]
The Company purchases components from a variety of suppliers and uses several contract manufacturers to provide manufacturing services for its products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, the Company enters into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by the Company or establish the parameters defining the Company’s requirements.  A significant portion of the Company’s reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. In certain instances, these agreements allow the Company the option to cancel, reschedule, and adjust the Company’s requirements based on its business needs prior to firm orders being placed.  As of April 30, 2016 and July 25, 2015, the Company had total purchase commitments for inventory of $3,794 million and $4,078 million, respectively.

[0000858877-16-000109:notes:70]
The Company records a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of its future demand forecasts consistent with the valuation of the Company’s excess and obsolete inventory. As of April 30, 2016 and July 25, 2015, the liability for these purchase commitments was $160 million and $156 million, respectively, and was included in other current liabilities.

[0000858877-16-000109:notes:71]
| (c) | Other Commitments |

[0000858877-16-000109:notes:72]
In connection with the Company’s acquisitions, the Company has agreed to pay certain additional amounts contingent upon the achievement of certain agreed-upon technology, development, product, or other milestones or upon the continued employment with the Company of certain employees of the acquired entities.

[0000858877-16-000109:notes:73]
As of April 30, 2016, the Company estimated that future cash compensation expense of up to $400 million may be required to be recognized pursuant to the applicable business combination agreements, which included the remaining potential compensation expense related to Insieme Networks, Inc. ("Insieme"), as more fully discussed immediately below.

[0000858877-16-000109:notes:74]
Insieme Networks, Inc.    In the third quarter of fiscal 2012, the Company made an investment in Insieme, an early stage company focused on research and development in the data center market. As set forth in the agreement between the Company and Insieme, this investment included $100 million of funding and a license to certain of the Company’s technology. Immediately prior to the call option exercise and acquisition described below, the Company owned approximately 83% of Insieme as a result of these investments and consolidated the results of Insieme in its Consolidated Financial Statements. In connection with this investment, the Company and Insieme entered into a put/call option agreement that provided the Company with the right to purchase the remaining interests in Insieme.  In addition, the noncontrolling interest holders could require the Company to purchase their shares upon the occurrence of certain events.

[0000858877-16-000109:notes:75]
During the first quarter of fiscal 2014, the Company exercised its call option and entered into an agreement to purchase the remaining interests in Insieme. The acquisition closed in the second quarter of fiscal 2014, at which time the former noncontrolling interest holders became eligible to receive up to two milestone payments, which will be determined using agreed-upon formulas based primarily on revenue for certain of Insieme’s products. The Company recorded compensation expense of $35 million and $51 million during the three months ended April 30, 2016 and April 25, 2015, respectively, and $136 million and $155 million during the nine months ended April 30, 2016 and April 25, 2015, respectively, related to the fair value of the vested portion of amounts that were earned or are expected to be earned by the former noncontrolling interest holders. Continued vesting and changes to the fair value of the amounts probable of being earned will result in adjustments to the recorded compensation expense in future periods.  Based on the terms of the agreement, the Company has determined that the maximum amount that could be recorded as compensation expense by the Company is approximately $839 million (which includes the $759 million that has been expensed to date), net of forfeitures.

[0000858877-16-000109:notes:76]
The former noncontrolling interest holders earned the maximum amount related to the first milestone payment and were paid   approximately $375 million for a portion of this amount during the nine months ended April 30, 2016. The balance of the first milestone payment is expected to be paid primarily through the end of fiscal 2016. The second milestone payment, to the extent earned, is expected to be paid primarily during the first half of fiscal 2017.

[0000858877-16-000109:notes:77]
The Company also has certain funding commitments, primarily related to its investments in privately held companies and venture funds, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $199 million and $205 million as of April 30, 2016 and July 25, 2015, respectively.

[0000858877-16-000109:notes:78]
| (d) | Product Warranties |

[0000858877-16-000109:notes:79]
The following table summarizes the activity related to the product warranty liability (in millions):

[0000858877-16-000109:notes:80]
|  | Nine Months Ended |
|  | April 30, 2016 |  | April 25, 2015 |
| Balance at beginning of period | $ | 449 |  |  | $ | 446 |  |
| Provision for warranties issued | 512 |  |  | 517 |  |
| Payments | (524 | ) |  | (512 | ) |
| Divestitures | (28 | ) |  | — |  |
| Balance at end of period | $ | 409 |  |  | $ | 451 |  |

[0000858877-16-000109:notes:81]
The Company accrues for warranty costs as part of its cost of sales based on associated material product costs, labor costs for technical support staff, and associated overhead. The Company’s products are generally covered by a warranty for periods ranging from 90 days to five years, and for some products the Company provides a limited lifetime warranty.

[0000858877-16-000109:notes:82]
| (e) | Financing and Other Guarantees |

[0000858877-16-000109:notes:83]
In the ordinary course of business, the Company provides financing guarantees for various third-party financing arrangements extended to channel partners and end-user customers. Payments under these financing guarantee arrangements were not material for the periods presented.

[0000858877-16-000109:notes:84]
Channel Partner Financing Guarantees   The Company facilitates arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, generally with payment terms ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, the Company guarantees a portion of these arrangements. The volume of channel partner financing was $6.4 billion and $6.3 billion for the three months ended April 30, 2016 and April 25, 2015, respectively, and was $19.8 billion and $19.0 billion for the nine months ended April 30, 2016 and April 25, 2015, respectively. The balance of the channel partner financing subject to guarantees was $1.0 billion and $1.2 billion as of April 30, 2016 and July 25, 2015, respectively.

[0000858877-16-000109:notes:85]
End-User Financing Guarantees   The Company also provides financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. The volume of financing provided by third parties for leases and loans as to which the Company had provided guarantees was $18 million and $22 million for the three months ended April 30, 2016 and April 25, 2015, respectively, and was $57 million and $87 million for the nine months ended April 30, 2016 and April 25, 2015, respectively.

[0000858877-16-000109:notes:86]
Financing Guarantee Summary   The aggregate amounts of financing guarantees outstanding at April 30, 2016 and July 25, 2015, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

[0000858877-16-000109:notes:87]
|  | April 30, 2016 |  | July 25, 2015 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 228 |  |  | $ | 288 |  |
| End user | 104 |  |  | 129 |  |
| Total | $ | 332 |  |  | $ | 417 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (98 | ) |  | $ | (127 | ) |
| End user | (82 | ) |  | (107 | ) |
| Total | $ | (180 | ) |  | $ | (234 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue | $ | 152 |  |  | $ | 183 |  |

[0000858877-16-000109:notes:88]
Other Guarantees   The Company’s other guarantee arrangements as of April 30, 2016 and July 25, 2015 that were subject to recognition and disclosure requirements were not material.

[0000858877-16-000109:notes:89]
| (f) | Supplier Component Remediation Liability |

[0000858877-16-000109:notes:90]
The Company has recorded in other current liabilities a liability for the expected remediation cost for certain products sold in prior fiscal years containing memory components manufactured by a single supplier between 2005 and 2010. These components were widely used across the industry and are included in a number of the Company's products. Defects in some of these components have caused products to fail after a power cycle event. Defect rates due to this issue have been and are expected to be low. However, the Company has seen a small number of its customers experience a growing number of failures in their networks as a result of this component problem. Although the majority of these products was beyond the Company's warranty terms, the Company has been proactively working with customers on mitigation. Prior to the second quarter of fiscal 2014, the Company had a liability of $63 million related to this issue for expected remediation costs based on the intended approach at that time. In February 2014, on the basis of the growing number of failures described above, the Company decided to expand its approach, which resulted in a charge to product cost of sales of $655 million being recorded for the second quarter of fiscal 2014. During the third quarters of fiscal 2016 and 2015, adjustments to product cost of sales of $74 million and $164 million, respectively, were recorded to reduce the liability, reflecting net lower than previously estimated future costs to remediate the impacted customer products. The supplier component remediation liability as of April 30, 2016 and July 25, 2015 was $286 million and $408 million, respectively.

[0000858877-16-000109:notes:91]
| (g) | Indemnifications |

[0000858877-16-000109:notes:92]
In the normal course of business, the Company indemnifies other parties, including customers, lessors, and parties to other transactions with the Company, with respect to certain matters. The Company has agreed to hold such parties harmless against losses arising from a breach of representations or covenants or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim.

[0000858877-16-000109:notes:93]
The Company is providing such indemnifications, among other cases, in matters involving certain of the Company’s service provider customers that are subject to patent infringement claims asserted by Sprint Communications Company, L.P. (“Sprint”) now pending in Kansas and Delaware. Sprint alleges that the service provider customers infringe Sprint’s patents by offering Voice over Internet Protocol-based telephone services utilizing products provided by the Company and other manufacturers. Sprint seeks monetary damages. Sprint’s cases in Kansas include claims against Comcast and Time Warner Cable, and the case in Delaware for which the Company is providing indemnification involves Cox Communications. On May 15, 2015, the judge in Sprint's Delaware action against Cox ruled invalid six of the asserted patents and a final judgment was entered on August 27, 2015, of invalidity, which Sprint appealed on October 1, 2015. In light of the invalidity rulings against Sprint in Delaware, the judge in Sprint’s Kansas actions stayed the Kansas actions until resolution of Sprint's appeal from the Delaware action. On March 21, 2016, the judge in Sprint's Delaware action also granted a partial summary judgment for Cox, finding that Cox does not literally infringe five of the remaining patents Sprint has asserted against Cox.  Additionally, Comcast has also won a judgment of non-infringement, now being appealed by Sprint, in a separate case brought against it by Sprint in Delaware.

[0000858877-16-000109:notes:94]
The Company believes that the service providers have strong defenses and that its products do not infringe the patents subject to the claims and/or that Sprint's patents are invalid. Due to the uncertainty surrounding the litigation process, which involves numerous defendants, the Company is unable to reasonably estimate the ultimate outcome of this litigation at this time. Should the plaintiff prevail in litigation, mediation, or settlement, the Company, in accordance with its agreements, may have an obligation to indemnify its service provider customers for damages, mediation awards, or settlement amounts arising from their use of Cisco products.

[0000858877-16-000109:notes:95]
In addition, the Company has entered into indemnification agreements with its officers and directors, and the Company’s Amended and Restated Bylaws contain similar indemnification obligations to the Company’s agents.

[0000858877-16-000109:notes:96]
It is not possible to determine the maximum potential amount under these indemnification agreements due to the Company’s limited history with prior indemnification claims and the unique facts and circumstances involved in each particular agreement.  Historically, payments made by the Company under these agreements have not had a material effect on the Company’s operating results, financial position, or cash flows.

[0000858877-16-000109:notes:97]
| (h) | Legal Proceedings |

[0000858877-16-000109:notes:98]
Brazil    Brazilian authorities have investigated the Company’s Brazilian subsidiary and certain of its current and former employees, as well as a Brazilian importer of the Company’s products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against the Company’s Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years. In the first quarter of fiscal 2013, the Brazilian federal tax authorities asserted an additional claim against the Company’s Brazilian subsidiary based on a theory of joint liability with respect to an alleged underpayment of income taxes, social taxes, interest, and penalties by a Brazilian distributor.  This claim was dismissed on its merits during the third quarter of fiscal 2016.

[0000858877-16-000109:notes:99]
The asserted claims by Brazilian federal tax authorities which remain are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $233 million for the alleged evasion of import and other taxes, $1.2 billion for interest, and $1.1 billion for various penalties, all determined using an exchange rate as of April 30, 2016. The Company has completed a thorough review of the matters and believes the asserted claims against the Company’s Brazilian subsidiary are without merit, and the Company is defending the claims vigorously. While the Company believes there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, the Company is unable to determine the likelihood of an unfavorable outcome against its Brazilian subsidiary and is unable to reasonably estimate a range of loss, if any. The Company does not expect a final judicial determination for several years.

[0000858877-16-000109:notes:100]
Russia and the Commonwealth of Independent States    At the request of the U.S. Securities and Exchange Commission ("SEC") and the U.S. Department of Justice, the Company is conducting an investigation into allegations which the Company and those agencies received regarding possible violations of the U.S. Foreign Corrupt Practices Act involving business activities of the Company's operations in Russia and certain of the Commonwealth of Independent States, and by certain resellers of the Company’s products in those countries. The Company takes any such allegations very seriously and is fully cooperating with and sharing the results of its investigation with the SEC and the Department of Justice. While the outcome of the Company's investigation is currently not determinable, the Company does not expect that it will have a material adverse effect on its consolidated financial position, results of operations, or cash flows. The countries that are the subject of the investigation collectively comprise less than 2% of the Company’s revenues.

[0000858877-16-000109:notes:101]
Backflip Software     Backflip Software, Inc. (“Backflip”) has asserted contract, tort, and fraud claims against the Company in Santa Clara County, California Superior Court. The proceeding was instituted on March 5, 2013. Backflip alleges that Cisco conspired with Backflip's then-CEO to allow the Company to access and use Backflip's source code via a pre-existing source code escrow agreement, and that, subsequently, the Company used that source code in violation of trade secret law and the parties' software license agreement. Backflip has also sued the escrow company, NCC Group, Inc., for breach of contract based on the same allegations. Backflip seeks compensatory and punitive damages. Trial is set for September 12, 2016. The Company believes that it has strong arguments that it was entitled to the source code under the parties’ software license agreement. In addition, if the jury were to find for Backflip on some or all of its claims, the Company believes that damages would not be material given the minimal value of Backflip and its intellectual property that the Company is alleged to have misappropriated. However, due to the uncertainty surrounding the litigation process, the Company is unable to reasonably estimate the ultimate outcome of this litigation at this time.

[0000858877-16-000109:notes:102]
SRI International     On September 4, 2013, SRI International, Inc. (“SRI”) asserted patent infringement claims against the Company in the U.S. District Court for the District of Delaware, accusing Cisco products and services in the area of network intrusion detection of infringing two U.S. patents. SRI sought monetary damages of at least a reasonable royalty and enhanced damages. The trial on these claims began on May 2, 2016 and on May 12, 2016 the jury returned a verdict finding willful infringement of the asserted patents. The jury awarded SRI damages of $23.7 million and the Court will decide whether to award enhanced damages and attorneys’ fees and whether an ongoing royalty should be awarded through the expiration of the patents in 2018. In June 2016, the Company plans to file post-trial motions and the Company also intends to pursue an appeal to the United States Court of Appeals for the Federal Circuit on various grounds. The Company believes it has strong arguments to overturn the jury verdict and/or reduce the damages award. While the ultimate outcome of the case may still result in a loss, the Company does not expect it to be material.

[0000858877-16-000109:notes:103]
SSL     SSL Services, LLC (“SSL”) has asserted claims for patent infringement against the Company in the U.S. District Court for the Eastern District of Texas.  The proceeding was instituted on March 25, 2015. SSL alleges that the Company's AnyConnect products that include Virtual Private Networking functions infringed a U.S. patent owned by SSL. SSL seeks money damages from the Company. A trial is set for September 6, 2016. The Company believes it has strong arguments that its products do not infringe and the patent is invalid. If a jury were to find that the Company's AnyConnect products infringe and the patent is not invalid, the Company believes damages, as appropriately measured, would be immaterial. Due to uncertainty surrounding the litigation process, however, the Company is unable to reasonably estimate the ultimate outcome of this litigation at this time. The Company also notes that on February 23, 2016, a multi-judge panel of the Patent Trial and Appeal Board (“PTAB”) of the United States Patent and Trademark Office instituted proceedings to review whether the patent SSL has asserted against the Company is valid over prior art. The PTAB found a reasonable likelihood that the Company would prevail in showing that the patent claims are unpatentable. The PTAB has scheduled the hearing on the Company's review petition for November 16, 2016.

[0000858877-16-000109:notes:104]
Kangtega     Cisco Systems GmbH (“Cisco GmbH”) is subject to patent claims by Kangtega GmbH (“Kangtega”), instituted on June 6, 2013, alleging that Cisco GmbH infringes in Germany a European Patent by marketing, in Germany, network intrusion-detection, or firewall, products known as the “ASA” firewall offering. On April 29, 2014, the Mannheim Regional Court dismissed the infringement action finding no infringement by Cisco GmbH of the asserted patent. On July 13, 2016, a court of appeal in Germany (Oberlandesgericht Karlsruhe) will hear an appeal of that judgment.  Kangtega seeks an injunction which would prohibit Cisco GmbH’s activities in Germany with respect to the ASA firewall offering unless Cisco GmbH takes a license from Kangtega or the Company redesigns the products.  The Company believes that the lower court ruling was correct and should be affirmed.  The Company does not anticipate that the outcome of the case would be material. However, due to uncertainty surrounding the litigation process, the Company is unable to reasonably estimate the outcome of the appeal and any subsequent appeals to a higher court at this time.

[0000858877-16-000109:notes:105]
In addition, we are subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, we do not expect that the ultimate costs to resolve these matters will have a material adverse effect on our consolidated financial position, results of operations, or cash flows.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000858877-16-000109:notes:106]
[same as prior period, unchanged from 0000858877-16-000090:notes:97]

[0000858877-16-000109:notes:107]
The components of AOCI, net of tax, and the other comprehensive income (loss), excluding noncontrolling interest, for the nine months ended April 30, 2016 and April 25, 2015 are summarized as follows (in millions):

[0000858877-16-000109:notes:108]
|  | Net Unrealized Gains (Losses) on Available-for-Sale Investments |  | Net Unrealized Gains (Losses) Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Actuarial Gains and Losses |  | Accumulated Other Comprehensive Income (Loss) |
| BALANCE AT JULY 25, 2015 | $ | 310 |  |  | $ | (16 | ) |  | $ | (233 | ) |  | $ | 61 |  |
| Other comprehensive income (loss) before reclassifications attributable to Cisco Systems, Inc. | (145 | ) |  | (3 | ) |  | (190 | ) |  | (338 | ) |
| (Gains) losses reclassified out of AOCI | 26 |  |  | 17 |  |  | 2 |  |  | 45 |  |
| Tax benefit (expense) | 50 |  |  | (2 | ) |  | (43 | ) |  | 5 |  |
| BALANCE AT APRIL 30, 2016 | $ | 241 |  |  | $ | (4 | ) |  | $ | (464 | ) |  | $ | (227 | ) |

[0000858877-16-000109:notes:109]
|  | Net Unrealized Gains (Losses) on Available-for-Sale Investments |  | Net Unrealized Gains (Losses) Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Actuarial Gains and Losses |  | Accumulated Other Comprehensive Income (Loss) |
| BALANCE AT JULY 26, 2014 | $ | 424 |  |  | $ | (12 | ) |  | $ | 265 |  |  | $ | 677 |  |
| Other comprehensive income (loss) before reclassifications attributable to Cisco Systems, Inc. | 111 |  |  | (163 | ) |  | (473 | ) |  | (525 | ) |
| (Gains) losses reclassified out of AOCI | (120 | ) |  | 94 |  |  | — |  |  | (26 | ) |
| Tax benefit (expense) | 8 |  |  | 3 |  |  | 50 |  |  | 61 |  |
| BALANCE AT APRIL 25, 2015 | $ | 423 |  |  | $ | (78 | ) |  | $ | (158 | ) |  | $ | 187 |  |

[0000858877-16-000109:notes:110]
[same as prior period, unchanged from 0000858877-16-000090:notes:101]

[0000858877-16-000109:notes:111]
|  |  | Three Months Ended |  | Nine Months Ended |  |  |
|  |  | April 30, 2016 |  | April 25, 2015 |  | April 30, 2016 |  | April 25, 2015 |  |  |
| Comprehensive Income Components |  | Income Before Taxes |  | Income Before Taxes |  | Line Item in Statements of Operations |
| Net unrealized gains on available-for-sale investments |  |  |  |  |  |  |  |  |  |  |
|  |  | $ | (6 | ) |  | $ | 44 |  |  | $ | (26 | ) |  | $ | 120 |  |  | Other income (loss), net |
| Net unrealized losses on cash flow hedging instruments |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | (7 | ) |  | (50 | ) |  | (13 | ) |  | (74 | ) |  | Operating expenses |
| Foreign currency derivatives |  | (2 | ) |  | (14 | ) |  | (4 | ) |  | (20 | ) |  | Cost of sales—service |
|  |  | (9 | ) |  | (64 | ) |  | (17 | ) |  | (94 | ) |  |  |
| Cumulative translation adjustment and actuarial gains and losses |  |  |  |  |  |  |  |  |  |  |
|  |  | (1 | ) |  | — |  |  | (2 | ) |  | — |  |  | Operating expenses |
| Total amounts reclassified out of AOCI |  | $ | (16 | ) |  | $ | (20 | ) |  | $ | (45 | ) |  | $ | 26 |  |  |  |


## us-gaap:DebtDisclosureTextBlock

[0000858877-16-000109:notes:112]
| 10. | Borrowings |

[0000858877-16-000109:notes:113]
| (a) | Short-Term Debt |

[0000858877-16-000109:notes:114]
The following table summarizes the Company’s short-term debt (in millions, except percentages):

[0000858877-16-000109:notes:115]
|  | April 30, 2016 |  | July 25, 2015 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 4,163 |  |  | 0.94 | % |  | $ | 3,894 |  |  | 2.48 | % |
| Other short-term debt | 1 |  |  | 2.08 | % |  | 3 |  |  | 2.44 | % |
| Total | $ | 4,164 |  |  |  |  | $ | 3,897 |  |  |  |

[0000858877-16-000109:notes:116]
The effective interest rate on the current portion of long-term debt includes the impact of interest rate swaps, as discussed further in "

[0000858877-16-000109:notes:117]
| (b) | Long-Term Debt |

[0000858877-16-000109:notes:118]
." Other notes and borrowings consist of the short-term portion of secured borrowings associated with customer financing arrangements. These notes and credit facilities were subject to various terms and foreign currency market interest rates pursuant to individual financial arrangements between the financing institution and the applicable foreign subsidiary.

[0000858877-16-000109:notes:119]
On September 3, 2015, the Company repaid an aggregate principal amount of $850 million upon the maturity of its 2015 Floating-Rate Notes.  On February 22, 2016, the Company repaid an aggregate principal amount of $3.0 billion upon the maturity of its 2016 Fixed Rate Notes.

[0000858877-16-000109:notes:120]
The Company has established a short-term debt financing program of up to $3.0 billion through the issuance of commercial paper notes. The Company uses the proceeds from the issuance of commercial paper notes for general corporate purposes. The Company had no commercial paper notes outstanding as of each of April 30, 2016 and July 25, 2015.

[0000858877-16-000109:notes:121]
(b)

[0000858877-16-000109:notes:122]
Long-Term Debt

[0000858877-16-000109:notes:123]
The following table summarizes the Company’s long-term debt (in millions, except percentages):

[0000858877-16-000109:notes:124]
|  |  |  | April 30, 2016 |  | July 25, 2015 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.05% | September 3, 2015 |  | $ | — |  |  | — |  | $ | 850 |  |  | 0.43% |
| Three-month LIBOR plus 0.28% | March 3, 2017 |  | 1,000 |  |  | 0.98% |  | 1,000 |  |  | 0.63% |
| Three-month LIBOR plus 0.60% | February 21, 2018 | (1) | 1,000 |  |  | 1.30% |  | — |  |  | — |
| Three-month LIBOR plus 0.31% | June 15, 2018 |  | 900 |  |  | 1.01% |  | 900 |  |  | 0.65% |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | 500 |  |  | 1.20% |  | 500 |  |  | 0.84% |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 5.50% | February 22, 2016 |  | — |  |  | — |  | 3,000 |  |  | 3.07% |
| 1.10% | March 3, 2017 |  | 2,400 |  |  | 0.84% |  | 2,400 |  |  | 0.59% |
| 3.15% | March 14, 2017 |  | 750 |  |  | 1.20% |  | 750 |  |  | 0.85% |
| 1.40% | February 28, 2018 | (1) | 1,250 |  |  | 1.47% |  | — |  |  | — |
| 1.65% | June 15, 2018 |  | 1,600 |  |  | 1.72% |  | 1,600 |  |  | 1.72% |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 4.76% |  | 2,000 |  |  | 4.70% |
| 1.60% | February 28, 2019 | (1) | 1,000 |  |  | 1.67% |  | — |  |  | — |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 1.05% |  | 1,750 |  |  | 0.80% |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 3.21% |  | 2,500 |  |  | 3.01% |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 2.54% |  | 1,500 |  |  | 2.54% |
| 2.20% | February 28, 2021 | (1) | 2,500 |  |  | 2.30% |  | — |  |  | — |
| 2.90% | March 4, 2021 |  | 500 |  |  | 1.21% |  | 500 |  |  | 0.96% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 1.46% |  | 500 |  |  | 1.21% |
| 2.60% | February 28, 2023 | (1) | 500 |  |  | 2.68% |  | — |  |  | — |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1.33% |  | 1,000 |  |  | 1.08% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 1.62% |  | 500 |  |  | 1.37% |
| 2.95% | February 28, 2026 | (1) | 750 |  |  | 3.01% |  | — |  |  | — |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Other long-term debt |  |  | — |  |  |  |  | 1 |  |  | 2.08% |
| Total |  |  | 28,400 |  |  |  |  | 25,251 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (141 | ) |  |  |  | (131 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 335 |  |  |  |  | 231 |  |  |  |
| Total |  |  | $ | 28,594 |  |  |  |  | $ | 25,351 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 4,163 |  |  |  |  | $ | 3,894 |  |  |  |
| Long-term debt |  |  | 24,431 |  |  |  |  | 21,457 |  |  |  |
| Total |  |  | $ | 28,594 |  |  |  |  | $ | 25,351 |  |  |  |

[0000858877-16-000109:notes:125]
(1) In February 2016, the Company issued senior notes for an aggregate principal amount of $7.0 billion.

[0000858877-16-000109:notes:126]
To achieve its interest rate risk management objectives, the Company entered into interest rate swaps in prior periods with an aggregate notional amount of $9.9 billion designated as fair value hedges of certain of its fixed-rate senior notes.  In effect, these swaps convert the fixed interest rates of the fixed-rate notes to floating interest rates based on the London InterBank Offered Rate (LIBOR). The gains and losses related to changes in the fair value of the interest rate swaps substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates.  For additional information, see Note 11.

[0000858877-16-000109:notes:127]
The effective rates for the fixed-rate debt include the interest on the notes, the accretion of the discount and issuance costs, and, if applicable, adjustments related to hedging. Interest is payable semiannually on each class of the senior fixed-rate notes and payable quarterly on the floating-rate notes. Each of the senior fixed-rate notes is redeemable by the Company at any time, subject to a make-whole premium.

[0000858877-16-000109:notes:128]
The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to the Company’s short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of April 30, 2016, the Company was in compliance with all debt covenants.

[0000858877-16-000109:notes:129]
As of April 30, 2016, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

[0000858877-16-000109:notes:130]
| Fiscal Year | Amount |
| 2016 (remaining three months) | $ | — |  |
| 2017 | 4,150 |  |
| 2018 | 4,750 |  |
| 2019 | 5,250 |  |
| 2020 | 4,000 |  |
| Thereafter | 10,250 |  |
| Total | $ | 28,400 |  |

[0000858877-16-000109:notes:131]
| (c) | Credit Facility |

[0000858877-16-000109:notes:132]
On May 15, 2015, the Company entered into a credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 15, 2020. Any advances under the credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (i) the highest of (a) the Federal Funds rate plus 0.50%, (b) Bank of America’s “prime rate” as announced from time to time, or (c) LIBOR, or a comparable or successor rate that is approved by the Administrative Agent (“Eurocurrency Rate”), for an interest period of one-month plus 1.00%, or (ii) the Eurocurrency Rate, plus a margin that is based on the Company’s senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the Eurocurrency Rate be less than zero.  The credit agreement requires the Company to comply with certain covenants, including that it maintain an interest coverage ratio as defined in the agreement.

[0000858877-16-000109:notes:133]
The Company may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and/or extend the expiration date of the credit facility up to May 15, 2022.  The Company was in compliance with the required interest coverage ratio and the other covenants, and the Company had not borrowed any funds under the credit facility.


## us-gaap:DeferredRevenueByArrangementDisclosureTextBlock

[0000858877-16-000109:notes:134]
| Deferred revenue: |  |  |  |  |
| Service |  | $ | 9,866 |  |  | $ | 9,757 |  |
| Product: |  |  |  |  |
| Unrecognized revenue on product shipments and other deferred revenue |  | 4,987 |  |  | 4,766 |  |
| Cash receipts related to unrecognized revenue from two-tier distributors |  | 419 |  |  | 660 |  |
| Total product deferred revenue |  | 5,406 |  |  | 5,426 |  |
| Total |  | $ | 15,272 |  |  | $ | 15,183 |  |
| Reported as: |  |  |  |  |
| Current |  | $ | 9,662 |  |  | $ | 9,824 |  |
| Noncurrent |  | 5,610 |  |  | 5,359 |  |
| Total |  | $ | 15,272 |  |  | $ | 15,183 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000858877-16-000109:notes:135]
[same as prior period, unchanged from 0000858877-16-000090:notes:125]

[0000858877-16-000109:notes:136]
[same as prior period, unchanged from 0000858877-16-000090:notes:126]

[0000858877-16-000109:notes:137]
[same as prior period, unchanged from 0000858877-16-000090:notes:127]

[0000858877-16-000109:notes:138]
[same as prior period, unchanged from 0000858877-16-000090:notes:128]

[0000858877-16-000109:notes:139]
|  | DERIVATIVE ASSETS |  | DERIVATIVE LIABILITIES |
|  | Balance Sheet Line Item |  | April 30, 2016 |  | July 25, 2015 |  | Balance Sheet Line Item |  | April 30, 2016 |  | July 25, 2015 |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | $ | 13 |  |  | $ | 10 |  |  | Other current liabilities |  | $ | 3 |  |  | $ | 11 |  |
| Interest rate derivatives | Other assets |  | 332 |  |  | 202 |  |  | Other long-term liabilities |  | — |  |  | — |  |
| Total |  |  | 345 |  |  | 212 |  |  |  |  | 3 |  |  | 11 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | — |  |  | 2 |  |  | Other current liabilities |  | 1 |  |  | 1 |  |
| Equity derivatives | Other assets |  | — |  |  | 4 |  |  | Other long-term liabilities |  | — |  |  | — |  |
| Total |  |  | — |  |  | 6 |  |  |  |  | 1 |  |  | 1 |  |
| Total |  |  | $ | 345 |  |  | $ | 218 |  |  |  |  | $ | 4 |  |  | $ | 12 |  |

[0000858877-16-000109:notes:140]
[same as prior period, unchanged from 0000858877-16-000090:notes:130]

[0000858877-16-000109:notes:141]
| GAINS (LOSSES) RECOGNIZEDIN OCI ON DERIVATIVES FOR THE THREE MONTHS ENDED (EFFECTIVE PORTION) |  | GAINS (LOSSES) RECLASSIFIED FROMAOCI INTO INCOME FOR THETHREE MONTHS ENDED (EFFECTIVE PORTION) |
|  |  | April 30, 2016 |  | April 25, 2015 |  | Line Item in Statements of Operations |  | April 30, 2016 |  | April 25, 2015 |
| Derivatives designated as cash flow hedging instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | 21 |  |  | $ | (32 | ) |  | Operating expenses |  | $ | (7 | ) |  | $ | (50 | ) |
|  |  |  |  |  |  | Cost of sales—service |  | (2 | ) |  | (14 | ) |
| Total |  | $ | 21 |  |  | $ | (32 | ) |  |  |  | $ | (9 | ) |  | $ | (64 | ) |
| Derivatives designated as net investment hedging instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | (15 | ) |  | $ | 2 |  |  | Other income (loss), net |  | $ | — |  |  | $ | — |  |

[0000858877-16-000109:notes:142]
| GAINS (LOSSES) RECOGNIZEDIN OCI ON DERIVATIVES FOR THE NINE MONTHS ENDED (EFFECTIVE PORTION) |  | GAINS (LOSSES) RECLASSIFIED FROMAOCI INTO INCOME FOR THENINE MONTHS ENDED (EFFECTIVE PORTION) |
|  |  | April 30, 2016 |  | April 25, 2015 |  | Line Item in Statements of Operations |  | April 30, 2016 |  | April 25, 2015 |
| Derivatives designated as cash flow hedging instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | (3 | ) |  | $ | (163 | ) |  | Operating expenses |  | $ | (13 | ) |  | $ | (74 | ) |
|  |  |  |  |  |  | Cost of sales—service |  | (4 | ) |  | (20 | ) |
| Total |  | $ | (3 | ) |  | $ | (163 | ) |  |  |  | $ | (17 | ) |  | $ | (94 | ) |
| Derivatives designated as net investment hedging instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | (4 | ) |  | $ | 46 |  |  | Other income (loss), net |  | $ | — |  |  | $ | — |  |

[0000858877-16-000109:notes:143]
As of April 30, 2016, the Company estimates that approximately $9 million of net derivative gains related to its cash flow hedges included in accumulated other comprehensive income/loss (AOCI) will be reclassified into earnings within the next 12 months when the underlying hedged item impacts earnings.

[0000858877-16-000109:notes:144]
[same as prior period, unchanged from 0000858877-16-000090:notes:134]

[0000858877-16-000109:notes:145]
|  |  |  |  | GAINS (LOSSES) FOR THETHREE MONTHS ENDED |  | GAINS (LOSSES) FOR THENINE MONTHS ENDED |
| Derivatives Not Designated as Hedging Instruments |  | Line Item in Statements of Operations |  | April 30, 2016 |  | April 25, 2015 |  | April 30, 2016 |  | April 25, 2015 |
| Foreign currency derivatives |  | Other income (loss), net |  | $ | 80 |  |  | $ | (56 | ) |  | $ | 26 |  |  | $ | (165 | ) |
| Total return swaps—deferred compensation |  | Operating expenses |  | 46 |  |  | 23 |  |  | (8 | ) |  | 23 |  |
| Equity derivatives |  | Other income (loss), net |  | 1 |  |  | 6 |  |  | 14 |  |  | 10 |  |
| Total |  |  |  | $ | 127 |  |  | $ | (27 | ) |  | $ | 32 |  |  | $ | (132 | ) |

[0000858877-16-000109:notes:146]
[same as prior period, unchanged from 0000858877-16-000090:notes:136]

[0000858877-16-000109:notes:147]
|  | April 30, 2016 |  | July 25, 2015 |
| Derivatives designated as hedging instruments: |  |  |  |
| Foreign currency derivatives—cash flow hedges | $ | 958 |  |  | $ | 1,201 |  |
| Interest rate derivatives | 9,900 |  |  | 11,400 |  |
| Net investment hedging instruments | 180 |  |  | 192 |  |
| Derivatives not designated as hedging instruments: |  |  |  |
| Foreign currency derivatives | 1,925 |  |  | 2,023 |  |
| Total return swaps—deferred compensation | 470 |  |  | 462 |  |
| Total | $ | 13,433 |  |  | $ | 15,278 |  |

[0000858877-16-000109:notes:148]
[same as prior period, unchanged from 0000858877-16-000090:notes:138]

[0000858877-16-000109:notes:149]
[same as prior period, unchanged from 0000858877-16-000090:notes:139]

[0000858877-16-000109:notes:150]
|  | April 30, 2016 |
|  | Gross Amounts Offset in the Consolidated Balance Sheets |  | Gross Amounts Not Offset in the Consolidated Balance Sheets, but with Legal Rights to Offset |
|  | Gross Amounts Recognized |  | Gross Amounts Offset |  | Net Amounts Presented |  | Gross Derivative Amounts |  | Cash Collateral |  | Net Amount |
| Derivatives assets | $ | 345 |  |  | $ | — |  |  | $ | 345 |  |  | $ | (4 | ) |  | $ | (247 | ) |  | $ | 94 |  |
| Derivatives liabilities | $ | 4 |  |  | $ | — |  |  | $ | 4 |  |  | $ | (4 | ) |  | $ | — |  |  | $ | — |  |

[0000858877-16-000109:notes:151]
[same as prior period, unchanged from 0000858877-16-000090:notes:141]

[0000858877-16-000109:notes:152]
[same as prior period, unchanged from 0000858877-16-000090:notes:142]

[0000858877-16-000109:notes:153]
[same as prior period, unchanged from 0000858877-16-000090:notes:143]

[0000858877-16-000109:notes:154]
[same as prior period, unchanged from 0000858877-16-000090:notes:144]

[0000858877-16-000109:notes:155]
[same as prior period, unchanged from 0000858877-16-000090:notes:145]

[0000858877-16-000109:notes:156]
[same as prior period, unchanged from 0000858877-16-000090:notes:146]

[0000858877-16-000109:notes:157]
[same as prior period, unchanged from 0000858877-16-000090:notes:147]

[0000858877-16-000109:notes:158]
Interest Rate Derivatives, Investments   The Company’s primary objective for holding fixed income securities is to achieve an appropriate investment return consistent with preserving principal and managing risk. To realize these objectives, the Company may utilize interest rate swaps or other derivatives designated as fair value or cash flow hedges. As of April 30, 2016 and July 25, 2015, the Company did not have any outstanding interest rate derivatives related to its fixed income securities.

[0000858877-16-000109:notes:159]
Interest Rate Derivatives Designated as Fair Value Hedges, Long-Term Debt   In fiscal 2016, the Company did not enter into any interest rate swaps. In prior fiscal years, the Company entered into interest rate swaps designated as fair value hedges related to fixed-rate senior notes that are due in fiscal years 2017 through 2025. Under these interest rate swaps, the Company receives fixed-rate interest payments and makes interest payments based on LIBOR plus a fixed number of basis points. The effect of such swaps is to convert the fixed interest rates of the senior fixed-rate notes to floating interest rates based on LIBOR. The gains and losses related to changes in the fair value of the interest rate swaps are included in interest expense and substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates. The fair value of the interest rate swaps was reflected in other assets and other long-term liabilities.

[0000858877-16-000109:notes:160]
[same as prior period, unchanged from 0000858877-16-000090:notes:150]

[0000858877-16-000109:notes:161]
[same as prior period, unchanged from 0000858877-16-000090:notes:151]

[0000858877-16-000109:notes:162]
[same as prior period, unchanged from 0000858877-16-000090:notes:152]

[0000858877-16-000109:notes:163]
[same as prior period, unchanged from 0000858877-16-000090:notes:153]

[0000858877-16-000109:notes:164]
[same as prior period, unchanged from 0000858877-16-000090:notes:154]


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000858877-16-000109:notes:165]
[same as prior period, unchanged from 0000858877-16-000090:notes:158]

[0000858877-16-000109:notes:166]
[same as prior period, unchanged from 0000858877-16-000090:notes:159]

[0000858877-16-000109:notes:167]
Stock Incentive Plan Program Description    As of April 30, 2016, the Company had three stock incentive plans: the 2005 Stock Incentive Plan (the “2005 Plan”); the Cisco Systems, Inc. SA Acquisition Long-Term Incentive Plan (the “SA Acquisition Plan”); and the Cisco Systems, Inc. WebEx Acquisition Long-Term Incentive Plan (the “WebEx Acquisition Plan”). In addition, the Company has, in connection with the acquisitions of various companies, assumed the share-based awards granted under stock incentive plans of the acquired companies or issued share-based awards in replacement thereof. Share-based awards are designed to reward employees for their long-term contributions to the Company and provide incentives for them to remain with the Company.  The number and frequency of share-based awards are based on competitive practices, operating results of the Company, government regulations, and other factors. The Company’s primary stock incentive plans are summarized as follows:

[0000858877-16-000109:notes:168]
2005 Plan    As of April 30, 2016, the maximum number of shares issuable under the 2005 Plan over its term was 694 million shares, plus the 1996 Stock Incentive Plan, the SA Acquisition Plan, and the WebEx Acquisition Plan that are forfeited or are terminated for any other reason before being exercised or settled. If any awards granted under the 2005 Plan are forfeited or are terminated for any other reason before being exercised or settled, the unexercised or unsettled shares underlying the awards will again be available under the 2005 Plan. Starting November 19, 2013, shares withheld by the Company from an award other than a stock option or stock appreciation right to satisfy withholding tax liabilities resulting from such award will again be available for issuance, based on the fungible share ratio in effect on the date of grant.

[0000858877-16-000109:notes:169]
[same as prior period, unchanged from 0000858877-16-000090:notes:162]

[0000858877-16-000109:notes:170]
[same as prior period, unchanged from 0000858877-16-000090:notes:163]

[0000858877-16-000109:notes:171]
[same as prior period, unchanged from 0000858877-16-000090:notes:164]

[0000858877-16-000109:notes:172]
[same as prior period, unchanged from 0000858877-16-000090:notes:165]

[0000858877-16-000109:notes:173]
The Company has an Employee Stock Purchase Plan, which includes its subplan named the International Employee Stock Purchase Plan (together, the “Purchase Plan”), under which 621 million shares of the Company’s common stock have been reserved for issuance as of April 30, 2016. Eligible employees are offered shares through a 24-month offering period, which consists of four consecutive 6-month purchase periods. Employees may purchase a limited number of shares of the Company’s stock at a discount of up to 15% of the lesser of the market value at the beginning of the offering period or the end of each 6-month purchase period.  The Purchase Plan is scheduled to terminate on January 3, 2020. The Company issued 14 million shares under the Purchase Plan during each of the nine months ended April 30, 2016 and April 25, 2015. As of April 30, 2016, 134 million shares were available for issuance under the Purchase Plan.

[0000858877-16-000109:notes:174]
[same as prior period, unchanged from 0000858877-16-000090:notes:167]

[0000858877-16-000109:notes:175]
[same as prior period, unchanged from 0000858877-16-000090:notes:168]

[0000858877-16-000109:notes:176]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 30, 2016 |  | April 25, 2015 |  | April 30, 2016 |  | April 25, 2015 |
| Cost of sales—product | $ | 21 |  |  | $ | 12 |  |  | $ | 50 |  |  | $ | 34 |  |
| Cost of sales—service | 37 |  |  | 44 |  |  | 110 |  |  | 115 |  |
| Share-based compensation expense in cost of sales | 58 |  |  | 56 |  |  | 160 |  |  | 149 |  |
| Research and development | 130 |  |  | 114 |  |  | 351 |  |  | 338 |  |
| Sales and marketing | 148 |  |  | 147 |  |  | 413 |  |  | 408 |  |
| General and administrative | 59 |  |  | 50 |  |  | 163 |  |  | 151 |  |
| Restructuring and other charges | — |  |  | — |  |  | 14 |  |  | (2 | ) |
| Share-based compensation expense in operating expenses | 337 |  |  | 311 |  |  | 941 |  |  | 895 |  |
| Total share-based compensation expense | $ | 395 |  |  | $ | 367 |  |  | $ | 1,101 |  |  | $ | 1,044 |  |
| Income tax benefit for share-based compensation | $ | 91 |  |  | $ | 88 |  |  | $ | 289 |  |  | $ | 267 |  |

[0000858877-16-000109:notes:177]
As of April 30, 2016, the total compensation cost related to unvested share-based awards not yet recognized was $2.8 billion, which is expected to be recognized over approximately 2.5 years on a weighted-average basis.

[0000858877-16-000109:notes:178]
[same as prior period, unchanged from 0000858877-16-000090:notes:171]

[0000858877-16-000109:notes:179]
[same as prior period, unchanged from 0000858877-16-000090:notes:172]

[0000858877-16-000109:notes:180]
|  | Share-Based Awards Available for Grant |
| BALANCE AT JULY 26, 2014 | 310 |  |
| Restricted stock, stock units, and other share-based awards granted | (101 | ) |
| Share-based awards canceled/forfeited/expired | 40 |  |
| Shares withheld for taxes and not issued | 27 |  |
| BALANCE AT JULY 25, 2015 | 276 |  |
| Restricted stock, stock units, and other share-based awards granted | (68 | ) |
| Share-based awards canceled/forfeited/expired | 26 |  |
| Shares withheld for taxes and not issued | 26 |  |
| Other | 1 |  |
| BALANCE AT APRIL 30, 2016 | 261 |  |

[0000858877-16-000109:notes:181]
[same as prior period, unchanged from 0000858877-16-000090:notes:174]

[0000858877-16-000109:notes:182]
[same as prior period, unchanged from 0000858877-16-000090:notes:175]

[0000858877-16-000109:notes:183]
[same as prior period, unchanged from 0000858877-16-000090:notes:176]

[0000858877-16-000109:notes:184]
|  | Restricted Stock/Stock Units |  | Weighted-AverageGrant Date FairValue per Share |  | Aggregate Fair Value |
| UNVESTED BALANCE AT JULY 26, 2014 | 149 |  |  | $ | 19.54 |  |  |  |
| Granted and assumed | 67 |  |  | 25.29 |  |  |  |
| Vested | (57 | ) |  | 19.82 |  |  | $ | 1,517 |  |
| Canceled/forfeited | (16 | ) |  | 20.17 |  |  |  |
| UNVESTED BALANCE AT JULY 25, 2015 | 143 |  |  | 22.08 |  |  |  |
| Granted and assumed | 51 |  |  | 24.73 |  |  |  |
| Vested | (46 | ) |  | 20.33 |  |  | $ | 1,188 |  |
| Canceled/forfeited | (12 | ) |  | 22.75 |  |  |  |
| UNVESTED BALANCE AT APRIL 30, 2016 | 136 |  |  | $ | 23.60 |  |  |  |

[0000858877-16-000109:notes:185]
[same as prior period, unchanged from 0000858877-16-000090:notes:178]

[0000858877-16-000109:notes:186]
[same as prior period, unchanged from 0000858877-16-000090:notes:179]

[0000858877-16-000109:notes:187]
|  | STOCK OPTIONS OUTSTANDING |
|  | NumberOutstanding |  | Weighted-AverageExercise Price per Share |
| BALANCE AT JULY 26, 2014 | 187 |  |  | $ | 26.03 |  |
| Assumed from acquisitions | 1 |  |  | 2.60 |  |
| Exercised | (71 | ) |  | 21.15 |  |
| Canceled/forfeited/expired | (14 | ) |  | 29.68 |  |
| BALANCE AT JULY 25, 2015 | 103 |  |  | 28.68 |  |
| Assumed from acquisitions | 18 |  |  | 5.14 |  |
| Exercised | (25 | ) |  | 19.60 |  |
| Canceled/forfeited/expired | (13 | ) |  | 29.62 |  |
| BALANCE AT APRIL 30, 2016 | 83 |  |  | $ | 26.16 |  |

[0000858877-16-000109:notes:188]
The following table summarizes significant ranges of outstanding and exercisable stock options as of April 30, 2016 (in millions, except years and share prices):

[0000858877-16-000109:notes:189]
|  |  | STOCK OPTIONS OUTSTANDING |  | STOCK OPTIONS EXERCISABLE |
| Range of Exercise Prices |  | NumberOutstanding |  | Weighted-AverageRemainingContractualLife(in Years) |  | Weighted-AverageExercisePrice perShare |  | AggregateIntrinsicValue |  | NumberExercisable |  | Weighted-AverageExercisePrice perShare |  | AggregateIntrinsicValue |
| $ 0.01 – 20.00 |  | 17 |  |  | 6.4 |  | $ | 5.49 |  |  | $ | 366 |  |  | 6 |  |  | $ | 5.11 |  |  | $ | 138 |  |
| $ 20.01 – 25.00 |  | 2 |  |  | 0.6 |  | 22.97 |  |  | 7 |  |  | 2 |  |  | 22.97 |  |  | 7 |  |
| $ 25.01 – 30.00 |  | 7 |  |  | 0.7 |  | 26.88 |  |  | 8 |  |  | 7 |  |  | 26.88 |  |  | 8 |  |
| $ 30.01 – 35.00 |  | 57 |  |  | 0.4 |  | 32.16 |  |  | — |  |  | 57 |  |  | 32.16 |  |  | — |  |
| Total |  | 83 |  |  | 1.6 |  | $ | 26.16 |  |  | $ | 381 |  |  | 72 |  |  | $ | 29.12 |  |  | $ | 153 |  |

[0000858877-16-000109:notes:190]
The aggregate intrinsic value in the preceding table represents the total pretax intrinsic value, based on the Company’s closing stock price of $27.49 as of April 29, 2016, that would have been received by the option holders had those option holders exercised their stock options as of that date. The total number of in-the-money stock options exercisable as of April 30, 2016 was 12 million.  As of July 25, 2015, 102 million outstanding stock options were exercisable and the weighted-average exercise price was $29.02.

[0000858877-16-000109:notes:191]
[same as prior period, unchanged from 0000858877-16-000090:notes:184]

[0000858877-16-000109:notes:192]
[same as prior period, unchanged from 0000858877-16-000090:notes:185]

[0000858877-16-000109:notes:193]
|  | RESTRICTED STOCK UNITS |  | PERFORMANCE RESTRICTED STOCK UNITS |
| Three Months Ended | April 30, 2016 |  | April 25, 2015 |  | April 30, 2016 |  | April 25, 2015 |
| Number of shares granted (in millions) | 2 |  |  | 33 |  |  | 1 |  |  | 1 |  |
| Grant date fair value per share | $ | 24.01 |  |  | $ | 25.31 |  |  | $ | 23.32 |  |  | $ | 25.87 |  |
| Weighted-average assumptions/inputs: |  |  |  |  |  |  |  |
| Expected dividend yield | 3.6 | % |  | 2.8 | % |  | 3.6 | % |  | 3.0 | % |
| Range of risk-free interest rates | 0.2% – 1.1% |  |  | 0.0% – 1.4% |  |  | 0.2% – 1.1% |  |  | 0.0% – 1.4% |  |
| Range of expected volatilities for index | N/A |  |  | N/A |  |  | N/A |  |  | N/A |  |

[0000858877-16-000109:notes:194]
|  | RESTRICTED STOCK UNITS |  | PERFORMANCE RESTRICTED STOCK UNITS |
| Nine Months Ended | April 30, 2016 |  | April 25, 2015 |  | April 30, 2016 |  | April 25, 2015 |
| Number of shares granted (in millions) | 38 |  |  | 44 |  |  | 5 |  |  | 8 |  |
| Grant date fair value per share | $ | 24.87 |  |  | $ | 24.83 |  |  | $ | 24.56 |  |  | $ | 23.97 |  |
| Weighted-average assumptions/inputs: |  |  |  |  |  |  |  |
| Expected dividend yield | 3.2 | % |  | 2.9 | % |  | 3.0 | % |  | 3.0 | % |
| Range of risk-free interest rates | 0.0% – 1.2% |  |  | 0.0% – 1.8% |  |  | 0.0% – 1.2% |  |  | 0.0% – 1.8% |  |
| Range of expected volatilities for index | N/A |  |  | N/A |  |  | 15.3% – 54.3% |  |  | 14.4% – 70.0% |  |

[0000858877-16-000109:notes:195]
[same as prior period, unchanged from 0000858877-16-000090:notes:188]


## us-gaap:EarningsPerShareTextBlock

[0000858877-16-000109:notes:196]
[same as prior period, unchanged from 0000858877-16-000090:notes:189]

[0000858877-16-000109:notes:197]
[same as prior period, unchanged from 0000858877-16-000090:notes:190]

[0000858877-16-000109:notes:198]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 30, 2016 |  | April 25, 2015 |  | April 30, 2016 |  | April 25, 2015 |
| Net income | $ | 2,349 |  |  | $ | 2,437 |  |  | $ | 7,926 |  |  | $ | 6,662 |  |
| Weighted-average shares—basic | 5,032 |  |  | 5,102 |  |  | 5,060 |  |  | 5,110 |  |
| Effect of dilutive potential common shares | 33 |  |  | 46 |  |  | 35 |  |  | 44 |  |
| Weighted-average shares—diluted | 5,065 |  |  | 5,148 |  |  | 5,095 |  |  | 5,154 |  |
| Net income per share—basic | $ | 0.47 |  |  | $ | 0.48 |  |  | $ | 1.57 |  |  | $ | 1.30 |  |
| Net income per share—diluted | $ | 0.46 |  |  | $ | 0.47 |  |  | $ | 1.56 |  |  | $ | 1.29 |  |
| Antidilutive employee share-based awards, excluded | 75 |  |  | 75 |  |  | 149 |  |  | 156 |  |

[0000858877-16-000109:notes:199]
[same as prior period, unchanged from 0000858877-16-000090:notes:192]


## us-gaap:EquityMethodInvestmentsTextBlock

[0000858877-16-000109:notes:200]
For such investments that were accounted for under the equity and cost method as of April 30, 2016 and July 25, 2015, the amounts are summarized in the following table (in millions):

[0000858877-16-000109:notes:201]
|  | April 30, 2016 |  | July 25, 2015 |
| Equity method investments | $ | 609 |  |  | $ | 578 |  |
| Cost method investments | 367 |  |  | 319 |  |
| Total | $ | 976 |  |  | $ | 897 |  |


## us-gaap:FairValueAssetsMeasuredOnNonrecurringBasisTextBlock

[0000858877-16-000109:notes:202]
[same as prior period, unchanged from 0000858877-16-000090:notes:195]

[0000858877-16-000109:notes:203]
|  | LOSSES FOR THETHREE MONTHS ENDED |  | LOSSES FOR THENINE MONTHS ENDED |
|  | April 30, 2016 |  | April 25, 2015 |  | April 30, 2016 |  | April 25, 2015 |
| Investments in privately held companies (impaired) | $ | (7 | ) |  | $ | (17 | ) |  | $ | (63 | ) |  | $ | (20 | ) |
| Purchased intangible assets (impaired) | (7 | ) |  | (1 | ) |  | (44 | ) |  | (57 | ) |
| Property held for sale - land and buildings | — |  |  | (5 | ) |  | — |  |  | (5 | ) |
| Total | $ | (14 | ) |  | $ | (23 | ) |  | $ | (107 | ) |  | $ | (82 | ) |


## us-gaap:FairValueDisclosuresTextBlock

[0000858877-16-000109:notes:204]
[same as prior period, unchanged from 0000858877-16-000090:notes:197]

[0000858877-16-000109:notes:205]
[same as prior period, unchanged from 0000858877-16-000090:notes:198]

[0000858877-16-000109:notes:206]
[same as prior period, unchanged from 0000858877-16-000090:notes:199]

[0000858877-16-000109:notes:207]
[same as prior period, unchanged from 0000858877-16-000090:notes:200]

[0000858877-16-000109:notes:208]
[same as prior period, unchanged from 0000858877-16-000090:notes:201]

[0000858877-16-000109:notes:209]
[same as prior period, unchanged from 0000858877-16-000090:notes:202]

[0000858877-16-000109:notes:210]
[same as prior period, unchanged from 0000858877-16-000090:notes:203]

[0000858877-16-000109:notes:211]
[same as prior period, unchanged from 0000858877-16-000090:notes:204]

[0000858877-16-000109:notes:212]
Assets and liabilities measured at fair value on a recurring basis as of April 30, 2016 and July 25, 2015 were as follows (in millions):

[0000858877-16-000109:notes:213]
|  | APRIL 30, 2016FAIR VALUE MEASUREMENTS |  | JULY 25, 2015FAIR VALUE MEASUREMENTS |
|  | Level 1 |  | Level 2 |  | Level 3 |  | TotalBalance |  | Level 1 |  | Level 2 |  | Level 3 |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 7,178 |  |  | $ | — |  |  | $ | — |  |  | $ | 7,178 |  |  | $ | 5,336 |  |  | $ | — |  |  | $ | — |  |  | $ | 5,336 |  |
| Corporate debt securities | — |  |  | 3 |  |  | — |  |  | 3 |  |  | — |  |  | 14 |  |  | — |  |  | 14 |  |
| Available-for-sale investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | — |  |  | 24,044 |  |  | — |  |  | 24,044 |  |  | — |  |  | 29,939 |  |  | — |  |  | 29,939 |  |
| U.S. government agency securities | — |  |  | 2,888 |  |  | — |  |  | 2,888 |  |  | — |  |  | 3,663 |  |  | — |  |  | 3,663 |  |
| Non-U.S. government and agency securities | — |  |  | 1,065 |  |  | — |  |  | 1,065 |  |  | — |  |  | 1,128 |  |  | — |  |  | 1,128 |  |
| Corporate debt securities | — |  |  | 23,316 |  |  | — |  |  | 23,316 |  |  | — |  |  | 15,783 |  |  | — |  |  | 15,783 |  |
| U.S. agency mortgage-backed securities | — |  |  | 1,762 |  |  | — |  |  | 1,762 |  |  | — |  |  | 1,461 |  |  | — |  |  | 1,461 |  |
| Publicly traded equity securities | 1,542 |  |  | — |  |  | — |  |  | 1,542 |  |  | 1,565 |  |  | — |  |  | — |  |  | 1,565 |  |
| Derivative assets | — |  |  | 345 |  |  | — |  |  | 345 |  |  | — |  |  | 214 |  |  | 4 |  |  | 218 |  |
| Total | $ | 8,720 |  |  | $ | 53,423 |  |  | $ | — |  |  | $ | 62,143 |  |  | $ | 6,901 |  |  | $ | 52,202 |  |  | $ | 4 |  |  | $ | 59,107 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities | $ | — |  |  | $ | 4 |  |  | $ | — |  |  | $ | 4 |  |  | $ | — |  |  | $ | 12 |  |  | $ | — |  |  | $ | 12 |  |
| Total | $ | — |  |  | $ | 4 |  |  | $ | — |  |  | $ | 4 |  |  | $ | — |  |  | $ | 12 |  |  | $ | — |  |  | $ | 12 |  |

[0000858877-16-000109:notes:214]
[same as prior period, unchanged from 0000858877-16-000090:notes:207]

[0000858877-16-000109:notes:215]
[same as prior period, unchanged from 0000858877-16-000090:notes:208]

[0000858877-16-000109:notes:216]
[same as prior period, unchanged from 0000858877-16-000090:notes:209]

[0000858877-16-000109:notes:217]
[same as prior period, unchanged from 0000858877-16-000090:notes:210]

[0000858877-16-000109:notes:218]
The fair value measurement of the impaired investments was classified as Level 3 because significant unobservable inputs were used in the valuation due to the absence of quoted market prices and inherent lack of liquidity. Significant unobservable inputs, which included financial metrics of comparable private and public companies, financial condition and near-term prospects of the investees, recent financing activities of the investees, and the investees’ capital structure as well as other economic variables, reflected the assumptions market participants would use in pricing these assets. The impairment charges, representing the difference between the net book value and the fair value as a result of the evaluation, were recorded to other income (loss), net. The remaining carrying value of the investments that were impaired was $20 million and $4 million as of April 30, 2016 and April 25, 2015, respectively.

[0000858877-16-000109:notes:219]
The fair value for purchased intangibles for which the carrying amount was not deemed to be recoverable was determined using the future discounted cash flows that the assets are expected to generate. The difference between the estimated fair value and the carrying value of the assets was recorded as an impairment charge, which was included in product cost of sales and operating expenses as applicable. See Note 4. The remaining carrying value of the specific purchased intangible assets that were impaired was zero as of each April 30, 2016 and April 25, 2015.

[0000858877-16-000109:notes:220]
The fair value of property held for sale was measured with the assistance of third-party valuation models which used discounted cash flow techniques as part of their analysis. The fair value measurement was categorized as Level 3, as significant unobservable inputs were used in the valuation report. The impairment charges as a result of the valuations, which represented the difference between the fair value less cost to sell and the carrying amount of the assets held for sale, were included in G&A expenses. The remaining carrying value of property held for sale was zero and $11 million as of April 30, 2016 and April 25, 2015, respectively.

[0000858877-16-000109:notes:221]
[same as prior period, unchanged from 0000858877-16-000090:notes:213]

[0000858877-16-000109:notes:222]
The carrying value of the Company’s investments in privately held companies that were accounted for under the cost method was $367 million and $319 million as of April 30, 2016 and July 25, 2015, respectively. It was not practicable to estimate the fair value of this portfolio.

[0000858877-16-000109:notes:223]
The fair value of the Company’s short-term loan receivables and financed service contracts approximates their carrying value due to their short duration. The aggregate carrying value of the Company’s long-term loan receivables and financed service contracts and other as of April 30, 2016 and July 25, 2015 was $2.4 billion and $2.2 billion, respectively. The estimated fair value of the Company’s long-term loan receivables and financed service contracts and other approximates their carrying value. The Company uses significant unobservable inputs in determining discounted cash flows to estimate the fair value of its long-term loan receivables and financed service contracts, and therefore they are categorized as Level 3.

[0000858877-16-000109:notes:224]
As of April 30, 2016, the estimated fair value of the short-term debt approximates its carrying value due to the short maturities.  As of April 30, 2016, the fair value of the Company’s senior notes and other long-term debt was $30.6 billion with a carrying amount of $28.6 billion. This compares to a fair value of $26.6 billion and a carrying amount of $25.4 billion as of July 25, 2015.  The fair value of the senior notes and other long-term debt was determined based on observable market prices in a less active market and was categorized as Level 2 in the fair value hierarchy.


## us-gaap:FinancingReceivableCreditQualityIndicatorsTableTextBlock

[0000858877-16-000109:notes:225]
Gross receivables, excluding residual value, less unearned income categorized by the Company’s internal credit risk rating as of April 30, 2016 and July 25, 2015 are summarized as follows (in millions):

[0000858877-16-000109:notes:226]
|  | INTERNAL CREDIT RISK RATING |
| April 30, 2016 | 1 to 4 |  | 5 to 6 |  | 7 and Higher |  | Total |
| Lease receivables | $ | 1,677 |  |  | $ | 1,276 |  |  | $ | 114 |  |  | $ | 3,067 |  |
| Loan receivables | 991 |  |  | 1,079 |  |  | 153 |  |  | 2,223 |  |
| Financed service contracts and other | 2,216 |  |  | 1,242 |  |  | 46 |  |  | 3,504 |  |
| Total | $ | 4,884 |  |  | $ | 3,597 |  |  | $ | 313 |  |  | $ | 8,794 |  |

[0000858877-16-000109:notes:227]
[same as prior period, unchanged from 0000858877-16-000090:notes:219]


## us-gaap:FinancingReceivablesTextBlock

[0000858877-16-000109:notes:228]
[same as prior period, unchanged from 0000858877-16-000090:notes:220]

[0000858877-16-000109:notes:229]
[same as prior period, unchanged from 0000858877-16-000090:notes:221]

[0000858877-16-000109:notes:230]
[same as prior period, unchanged from 0000858877-16-000090:notes:222]

[0000858877-16-000109:notes:231]
[same as prior period, unchanged from 0000858877-16-000090:notes:223]

[0000858877-16-000109:notes:232]
| April 30, 2016 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts and Other |  | Total |
| Gross | $ | 3,245 |  |  | $ | 2,223 |  |  | $ | 3,504 |  |  | $ | 8,972 |  |
| Residual value | 205 |  |  | — |  |  | — |  |  | 205 |  |
| Unearned income | (178 | ) |  | — |  |  | — |  |  | (178 | ) |
| Allowance for credit loss | (250 | ) |  | (93 | ) |  | (40 | ) |  | (383 | ) |
| Total, net | $ | 3,022 |  |  | $ | 2,130 |  |  | $ | 3,464 |  |  | $ | 8,616 |  |
| Reported as: |  |  |  |  |  |  |  |
| Current | $ | 1,495 |  |  | $ | 1,052 |  |  | $ | 2,169 |  |  | $ | 4,716 |  |
| Noncurrent | 1,527 |  |  | 1,078 |  |  | 1,295 |  |  | 3,900 |  |
| Total, net | $ | 3,022 |  |  | $ | 2,130 |  |  | $ | 3,464 |  |  | $ | 8,616 |  |

[0000858877-16-000109:notes:233]
[same as prior period, unchanged from 0000858877-16-000090:notes:225]

[0000858877-16-000109:notes:234]
As of April 30, 2016 and July 25, 2015, the deferred service revenue related to "Financed Service Contracts and Other" was $1,822 million and $1,853 million, respectively.

[0000858877-16-000109:notes:235]
Future minimum lease payments to the Company on lease receivables as of April 30, 2016 are summarized as follows (in millions):

[0000858877-16-000109:notes:236]
| Fiscal Year | Amount |
| 2016 (remaining three months) | $ | 408 |  |
| 2017 | 1,430 |  |
| 2018 | 833 |  |
| 2019 | 402 |  |
| 2020 | 152 |  |
| Thereafter | 20 |  |
| Total | $ | 3,245 |  |

[0000858877-16-000109:notes:237]
[same as prior period, unchanged from 0000858877-16-000090:notes:229]

[0000858877-16-000109:notes:238]
[same as prior period, unchanged from 0000858877-16-000090:notes:230]

[0000858877-16-000109:notes:239]
[same as prior period, unchanged from 0000858877-16-000090:notes:231]

[0000858877-16-000109:notes:240]
[same as prior period, unchanged from 0000858877-16-000090:notes:232]

[0000858877-16-000109:notes:241]
In circumstances when collectibility is not deemed reasonably assured, the associated revenue is deferred in accordance with the Company’s revenue recognition policies, and the related allowance for credit loss, if any, is included in deferred revenue. The Company also records deferred revenue associated with financing receivables when there are remaining performance obligations, as it does for financed service contracts. Total allowances for credit loss and deferred revenue as of April 30, 2016 and July 25, 2015 were $2,225 million and $2,253 million, respectively, and they were associated with total financing receivables before allowance for credit loss of $8,999 million and $8,731 million as of their respective period ends.

[0000858877-16-000109:notes:242]
The following tables present the aging analysis of gross receivables, excluding residual value and less unearned income as of April 30, 2016 and July 25, 2015 (in millions):

[0000858877-16-000109:notes:243]
|  | DAYS PAST DUE (INCLUDES BILLED AND UNBILLED) |  |  |  |  |  |  |  |  |
| April 30, 2016 | 31-60 |  | 61-90 |  | 91+ |  | TotalPast Due |  | Current |  | Total |  | NonaccrualFinancingReceivables |  | ImpairedFinancingReceivables |
| Lease receivables | $ | 41 |  |  | $ | 44 |  |  | $ | 181 |  |  | $ | 266 |  |  | $ | 2,801 |  |  | $ | 3,067 |  |  | $ | 67 |  |  | $ | 65 |  |
| Loan receivables | 51 |  |  | 11 |  |  | 78 |  |  | 140 |  |  | 2,083 |  |  | 2,223 |  |  | 47 |  |  | 47 |  |
| Financed service contracts and other | 79 |  |  | 115 |  |  | 237 |  |  | 431 |  |  | 3,073 |  |  | 3,504 |  |  | 36 |  |  | 16 |  |
| Total | $ | 171 |  |  | $ | 170 |  |  | $ | 496 |  |  | $ | 837 |  |  | $ | 7,957 |  |  | $ | 8,794 |  |  | $ | 150 |  |  | $ | 128 |  |

[0000858877-16-000109:notes:244]
[same as prior period, unchanged from 0000858877-16-000090:notes:236]

[0000858877-16-000109:notes:245]
Past due financing receivables are those that are 31 days or more past due according to their contractual payment terms.  The data in the preceding tables is presented by contract, and the aging classification of each contract is based on the oldest outstanding receivable, and therefore past due amounts also include unbilled and current receivables within the same contract.  The balances of either unbilled or current financing receivables included in the category of 91 days plus past due for financing receivables were $298 million and $496 million as of April 30, 2016 and July 25, 2015, respectively.

[0000858877-16-000109:notes:246]
As of April 30, 2016, the Company had financing receivables of $165 million, net of unbilled or current receivables from the same contract, that were in the category of 91 days plus past due but remained on accrual status as they are well-secured and in the process of collection. Such balance was $70 million as of July 25, 2015.

[0000858877-16-000109:notes:247]
[same as prior period, unchanged from 0000858877-16-000090:notes:239]

[0000858877-16-000109:notes:248]
[same as prior period, unchanged from 0000858877-16-000090:notes:240]

[0000858877-16-000109:notes:249]
Typically, the Company also considers receivables with a risk rating of 8 or higher to be impaired and will include them in the individual assessment for allowance. These balances, as of April 30, 2016 and July 25, 2015, are presented under “(b) Credit Quality of Financing Receivables” above.

[0000858877-16-000109:notes:250]
[same as prior period, unchanged from 0000858877-16-000090:notes:242]

[0000858877-16-000109:notes:251]
[same as prior period, unchanged from 0000858877-16-000090:notes:243]

[0000858877-16-000109:notes:252]
[same as prior period, unchanged from 0000858877-16-000090:notes:244]

[0000858877-16-000109:notes:253]
|  | April 30, 2016 |  | July 25, 2015 |
| Operating lease assets | $ | 325 |  |  | $ | 372 |  |
| Accumulated depreciation | (184 | ) |  | (205 | ) |
| Operating lease assets, net | $ | 141 |  |  | $ | 167 |  |

[0000858877-16-000109:notes:254]
Minimum future rentals on noncancelable operating leases as of April 30, 2016 are summarized as follows (in millions):

[0000858877-16-000109:notes:255]
| Fiscal Year | Amount |
| 2016 (remaining three months) | $ | 54 |  |
| 2017 | 189 |  |
| 2018 | 129 |  |
| 2019 | 39 |  |
| 2020 | 8 |  |
| Thereafter | 5 |  |
| Total | $ | 424 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000858877-16-000109:notes:256]
[same as prior period, unchanged from 0000858877-16-000090:notes:247]

[0000858877-16-000109:notes:257]
[same as prior period, unchanged from 0000858877-16-000090:notes:248]

[0000858877-16-000109:notes:258]
The following table presents the goodwill allocated to the Company’s reportable segments as of and during the nine months ended April 30, 2016 (in millions):

[0000858877-16-000109:notes:259]
|  | Balance at |  |  |  |  |  |  |  | Balance at |
|  | July 25, 2015 |  | Acquisitions |  | Divestiture |  | Other |  | April 30, 2016 |
| Americas | $ | 15,212 |  |  | $ | 1,607 |  |  | $ | (126 | ) |  | $ | (80 | ) |  | $ | 16,613 |  |
| EMEA | 5,791 |  |  | 554 |  |  | (12 | ) |  | (31 | ) |  | 6,302 |  |
| APJC | 3,466 |  |  | 401 |  |  | (3 | ) |  | (17 | ) |  | 3,847 |  |
| Total | $ | 24,469 |  |  | $ | 2,562 |  |  | $ | (141 | ) |  | $ | (128 | ) |  | $ | 26,762 |  |

[0000858877-16-000109:notes:260]
[same as prior period, unchanged from 0000858877-16-000090:notes:251]

[0000858877-16-000109:notes:261]
[same as prior period, unchanged from 0000858877-16-000090:notes:252]

[0000858877-16-000109:notes:262]
[same as prior period, unchanged from 0000858877-16-000090:notes:253]

[0000858877-16-000109:notes:263]
Impairment charges related to purchased intangible assets for the three months ended April 30, 2016 and April 25, 2015 were $7 million and $1 million, respectively. Impairment charges related to purchased intangible assets for the nine months ended April 30, 2016 and April 25, 2015 were  $44 million and $57 million, respectively.

[0000858877-16-000109:notes:264]
The estimated future amortization expense of purchased intangible assets with finite lives as of April 30, 2016 is as follows (in millions):

[0000858877-16-000109:notes:265]
| Fiscal Year | Amount |
| 2016 (remaining three months) | $ | 211 |  |
| 2017 | 742 |  |
| 2018 | 595 |  |
| 2019 | 502 |  |
| 2020 | 276 |  |
| Thereafter | 194 |  |
| Total | $ | 2,520 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000858877-16-000109:notes:266]
[same as prior period, unchanged from 0000858877-16-000090:notes:257]

[0000858877-16-000109:notes:267]
As discussed further below, the effective tax rate for the nine months ended April 30, 2016 reflected the Company's recognition of total benefits of approximately $558 million related to a tax settlement with the Internal Revenue Service ("IRS") in January 2016 and the reinstatement of the U.S. federal research and development ("R&D") tax credit on December 18, 2015.

[0000858877-16-000109:notes:268]
In the second quarter of fiscal 2016, the Protecting Americans from Tax Hikes Act of 2015 reinstated the U.S. federal R&D tax credit permanently.  As a result, the effective tax rate for the nine months ended April 30, 2016 reflected a tax benefit of $107 million related to fiscal 2016 R&D expenses and a tax benefit of $84 million related to fiscal 2015 R&D expenses.

[0000858877-16-000109:notes:269]
[same as prior period, unchanged from 0000858877-16-000090:notes:260]

[0000858877-16-000109:notes:270]
As a result of the IRS tax settlement, the amount of gross unrecognized tax benefits was reduced in the second quarter of fiscal 2016 by approximately $563 million, of which $188 million became certain as a result of completing the audit. As of April 30, 2016, the Company had $1.6 billion of unrecognized tax benefits, of which $1.4 billion, if recognized, would favorably impact the effective tax rate. The Company regularly engages in discussions and negotiations with tax authorities regarding tax matters in various jurisdictions. The Company believes it is reasonably possible that certain foreign and state tax matters may be concluded in the next 12 months. Specific positions that may be resolved include issues involving transfer pricing and various other matters.  The Company estimates that the unrecognized tax benefits at April 30, 2016 could be reduced by approximately $150 million in the next 12 months.


## us-gaap:InventoryDisclosureTextBlock

[0000858877-16-000109:notes:271]
[same as prior period, unchanged from 0000858877-16-000090:notes:262]

[0000858877-16-000109:notes:272]
|  |  | April 30, 2016 |  | July 25, 2015 |
| Inventories: |  |  |  |  |
| Raw materials |  | $ | 108 |  |  | $ | 114 |  |
| Work in process |  | — |  |  | 2 |  |
| Finished goods: |  |  |  |  |
| Distributor inventory and deferred cost of sales |  | 513 |  |  | 610 |  |
| Manufactured finished goods |  | 469 |  |  | 593 |  |
| Total finished goods |  | 982 |  |  | 1,203 |  |
| Service-related spares |  | 234 |  |  | 258 |  |
| Demonstration systems |  | 19 |  |  | 50 |  |
| Total |  | $ | 1,343 |  |  | $ | 1,627 |  |


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0000858877-16-000109:notes:273]
The following table summarizes the maturities of the Company’s fixed income securities as of April 30, 2016 (in millions):

[0000858877-16-000109:notes:274]
|  | Amortized Cost |  | Fair Value |
| Less than 1 year | $ | 13,883 |  |  | $ | 13,890 |  |
| Due in 1 to 2 years | 17,460 |  |  | 17,487 |  |
| Due in 2 to 5 years | 19,610 |  |  | 19,745 |  |
| Due after 5 years | 1,935 |  |  | 1,953 |  |
| Total | $ | 52,888 |  |  | $ | 53,075 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000858877-16-000109:notes:275]
| 8. | Investments |

[0000858877-16-000109:notes:276]
| (a) | Summary of Available-for-Sale Investments |

[0000858877-16-000109:notes:277]
The following tables summarize the Company’s available-for-sale investments (in millions):

[0000858877-16-000109:notes:278]
| April 30, 2016 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| Fixed income securities: |  |  |  |  |  |  |  |
| U.S. government securities | $ | 24,003 |  |  | $ | 44 |  |  | $ | (3 | ) |  | $ | 24,044 |  |
| U.S. government agency securities | 2,883 |  |  | 5 |  |  | — |  |  | 2,888 |  |
| Non-U.S. government and agency securities | 1,063 |  |  | 2 |  |  | — |  |  | 1,065 |  |
| Corporate debt securities | 23,193 |  |  | 160 |  |  | (37 | ) |  | 23,316 |  |
| U.S. agency mortgage-backed securities | 1,746 |  |  | 16 |  |  | — |  |  | 1,762 |  |
| Total fixed income securities | 52,888 |  |  | 227 |  |  | (40 | ) |  | 53,075 |  |
| Publicly traded equity securities | 1,354 |  |  | 218 |  |  | (30 | ) |  | 1,542 |  |
| Total | $ | 54,242 |  |  | $ | 445 |  |  | $ | (70 | ) |  | $ | 54,617 |  |

[0000858877-16-000109:notes:279]
| July 25, 2015 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| Fixed income securities: |  |  |  |  |  |  |  |
| U.S. government securities | $ | 29,904 |  |  | $ | 41 |  |  | $ | (6 | ) |  | $ | 29,939 |  |
| U.S. government agency securities | 3,662 |  |  | 2 |  |  | (1 | ) |  | 3,663 |  |
| Non-U.S. government and agency securities | 1,128 |  |  | 1 |  |  | (1 | ) |  | 1,128 |  |
| Corporate debt securities | 15,802 |  |  | 34 |  |  | (53 | ) |  | 15,783 |  |
| U.S. agency mortgage-backed securities | 1,456 |  |  | 8 |  |  | (3 | ) |  | 1,461 |  |
| Total fixed income securities | 51,952 |  |  | 86 |  |  | (64 | ) |  | 51,974 |  |
| Publicly traded equity securities | 1,092 |  |  | 480 |  |  | (7 | ) |  | 1,565 |  |
| Total | $ | 53,044 |  |  | $ | 566 |  |  | $ | (71 | ) |  | $ | 53,539 |  |

[0000858877-16-000109:notes:280]
Non-U.S. government and agency securities include agency and corporate debt securities that are guaranteed by non-U.S. governments.

[0000858877-16-000109:notes:281]
| (b) | Gains and Losses on Available-for-Sale Investments |

[0000858877-16-000109:notes:282]
The following table presents the gross realized gains and gross realized losses related to the Company’s available-for-sale investments (in millions):

[0000858877-16-000109:notes:283]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 30, 2016 |  | April 25, 2015 |  | April 30, 2016 |  | April 25, 2015 |
| Gross realized gains | $ | 68 |  |  | $ | 55 |  |  | $ | 119 |  |  | $ | 168 |  |
| Gross realized losses | (74 | ) |  | (11 | ) |  | (145 | ) |  | (48 | ) |
| Total | $ | (6 | ) |  | $ | 44 |  |  | $ | (26 | ) |  | $ | 120 |  |

[0000858877-16-000109:notes:284]
The following table presents the realized net gains (losses) related to the Company’s available-for-sale investments by security type (in millions):

[0000858877-16-000109:notes:285]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 30, 2016 |  | April 25, 2015 |  | April 30, 2016 |  | April 25, 2015 |
| Net gains/(losses) on investments in publicly traded equity securities | $ | 25 |  |  | $ | 38 |  |  | $ | 18 |  |  | $ | 94 |  |
| Net gains/(losses) on investments in fixed income securities | (31 | ) |  | 6 |  |  | (44 | ) |  | 26 |  |
| Total | $ | (6 | ) |  | $ | 44 |  |  | $ | (26 | ) |  | $ | 120 |  |

[0000858877-16-000109:notes:286]
For the three and nine months ended April 30, 2016, the realized net losses related to the Company's available-for-sale investments included impairment charges of zero and $3 million, respectively, for fixed income securities. The impairment charges were due to a decline in the fair value of those securities below their cost basis that were determined to be other than temporary. There were no impairment charges on available-for-sale investments for the corresponding periods in fiscal 2015.

[0000858877-16-000109:notes:287]
The following tables present the breakdown of the available-for-sale investments with gross unrealized losses and the duration that those losses had been unrealized at April 30, 2016 and July 25, 2015 (in millions):

[0000858877-16-000109:notes:288]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| April 30, 2016 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| Fixed income securities: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | $ | 4,315 |  |  | $ | (3 | ) |  | $ | — |  |  | $ | — |  |  | $ | 4,315 |  |  | $ | (3 | ) |
| U.S. government agency securities | 287 |  |  | — |  |  | — |  |  | — |  |  | 287 |  |  | — |  |
| Non-U.S. government and agency securities | 192 |  |  | — |  |  | — |  |  | — |  |  | 192 |  |  | — |  |
| Corporate debt securities | 5,145 |  |  | (27 | ) |  | 1,089 |  |  | (10 | ) |  | 6,234 |  |  | (37 | ) |
| U.S. agency mortgage-backed securities | 137 |  |  | — |  |  | 18 |  |  | — |  |  | 155 |  |  | — |  |
| Total fixed income securities | 10,076 |  |  | (30 | ) |  | 1,107 |  |  | (10 | ) |  | 11,183 |  |  | (40 | ) |
| Publicly traded equity securities | 320 |  |  | (30 | ) |  | — |  |  | — |  |  | 320 |  |  | (30 | ) |
| Total | $ | 10,396 |  |  | $ | (60 | ) |  | $ | 1,107 |  |  | $ | (10 | ) |  | $ | 11,503 |  |  | $ | (70 | ) |

[0000858877-16-000109:notes:289]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 25, 2015 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| Fixed income securities: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | $ | 6,412 |  |  | $ | (6 | ) |  | $ | — |  |  | $ | — |  |  | $ | 6,412 |  |  | $ | (6 | ) |
| U.S. government agency securities | 1,433 |  |  | (1 | ) |  | — |  |  | — |  |  | 1,433 |  |  | (1 | ) |
| Non-U.S. government and agency securities | 515 |  |  | (1 | ) |  | 4 |  |  | — |  |  | 519 |  |  | (1 | ) |
| Corporate debt securities | 9,552 |  |  | (49 | ) |  | 312 |  |  | (4 | ) |  | 9,864 |  |  | (53 | ) |
| U.S. agency mortgage-backed securities | 579 |  |  | (3 | ) |  | — |  |  | — |  |  | 579 |  |  | (3 | ) |
| Total fixed income securities | 18,491 |  |  | (60 | ) |  | 316 |  |  | (4 | ) |  | 18,807 |  |  | (64 | ) |
| Publicly traded equity securities | 108 |  |  | (7 | ) |  | 2 |  |  | — |  |  | 110 |  |  | (7 | ) |
| Total | $ | 18,599 |  |  | $ | (67 | ) |  | $ | 318 |  |  | $ | (4 | ) |  | $ | 18,917 |  |  | $ | (71 | ) |

[0000858877-16-000109:notes:290]
As of April 30, 2016, for fixed income securities that were in unrealized loss positions, the Company has determined that (i) it does not have the intent to sell any of these investments and (ii) it is not more likely than not that it will be required to sell any of these investments before recovery of the entire amortized cost basis. In addition, as of April 30, 2016, the Company anticipates that it will recover the entire amortized cost basis of such fixed income securities and has determined that no other-than-temporary impairments associated with credit losses were required to be recognized during the nine months ended April 30, 2016.

[0000858877-16-000109:notes:291]
The Company has evaluated its publicly traded equity securities as of April 30, 2016 and has determined that there was no indication of other-than-temporary impairments in the respective categories of unrealized losses. This determination was based on several factors, which include the length of time and extent to which fair value has been less than the cost basis, the financial condition and near-term prospects of the issuer, and the Company’s intent and ability to hold the publicly traded equity securities for a period of time sufficient to allow for any anticipated recovery in market value.

[0000858877-16-000109:notes:292]
| (c) | Maturities of Fixed Income Securities |

[0000858877-16-000109:notes:293]
Actual maturities may differ from the contractual maturities because borrowers may have the right to call or prepay certain obligations.  The remaining contractual principal maturities for mortgage-backed securities were allocated assuming no prepayments.

[0000858877-16-000109:notes:294]
| (d) | Securities Lending |

[0000858877-16-000109:notes:295]
The Company periodically engages in securities lending activities with certain of its available for sale investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. The average daily balance of securities lending for the nine months ended April 30, 2016 and April 25, 2015 was $0.9 billion and $0.5 billion, respectively. The Company requires collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. The Company engages in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify the Company against collateral losses. The Company did not experience any losses in connection with the secured lending of securities during the periods presented. As of April 30, 2016 and July 25, 2015, the Company had no outstanding securities lending transactions.

[0000858877-16-000109:notes:296]
| (e) | Investments in Privately Held Companies |

[0000858877-16-000109:notes:297]
The carrying value of the Company’s investments in privately held companies was included in other assets.  For such investments that were accounted for under the equity and cost method as of April 30, 2016 and July 25, 2015, the amounts are summarized in the following table (in millions):

[0000858877-16-000109:notes:298]
For additional information on impairment charges related to investments in privately held companies, see Note 9.

[0000858877-16-000109:notes:299]
Variable Interest Entities  In the ordinary course of business, the Company has investments in privately held companies and provides financing to certain customers. These privately held companies and customers may be considered to be variable interest entities. The Company evaluates on an ongoing basis its investments in these privately held companies and its customer financings and has determined that as of April 30, 2016, except as disclosed herein, there were no variable interest entities required to be consolidated in the Company’s Consolidated Financial Statements.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000858877-16-000109:notes:300]
[same as prior period, unchanged from 0000858877-16-000090:notes:291]

[0000858877-16-000109:notes:301]
The fiscal year for Cisco Systems, Inc. (the “Company” or “Cisco”) is the 52 or 53 weeks ending on the last Saturday in July. Fiscal 2016 is a 53-week fiscal year, and fiscal 2015 was a 52-week fiscal year. The Consolidated Financial Statements include the accounts of Cisco and its subsidiaries. All intercompany accounts and transactions have been eliminated. The Company conducts business globally and is primarily managed on a geographic basis in the following three geographic segments: the Americas; Europe, Middle East, and Africa (EMEA); and Asia Pacific, Japan, and China (APJC).

[0000858877-16-000109:notes:302]
The accompanying financial data as of April 30, 2016 and for the three and nine months ended April 30, 2016 and April 25, 2015 has been prepared by the Company, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (SEC).  Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (GAAP) have been condensed or omitted pursuant to such rules and regulations.  The July 25, 2015 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, the Company believes that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended July 25, 2015.

[0000858877-16-000109:notes:303]
[same as prior period, unchanged from 0000858877-16-000090:notes:294]

[0000858877-16-000109:notes:304]
In the opinion of management, all normal recurring adjustments necessary to present fairly the consolidated balance sheet as of April 30, 2016; the results of operations and the statements of comprehensive income for the three and nine months ended April 30, 2016 and April 25, 2015; and the statements of cash flows and equity for the nine months ended April 30, 2016 and April 25, 2015, as applicable, have been made. The results of operations for the three and nine months ended April 30, 2016 are not necessarily indicative of the operating results for the full fiscal year or any future periods.

[0000858877-16-000109:notes:305]
Certain reclassifications have been made to the amounts in prior periods in order to conform to the current period’s presentation.  The Company has evaluated subsequent events through the date that the financial statements were issued.


## us-gaap:OtherAssetsDisclosureTextBlock

[0000858877-16-000109:notes:306]
| Other assets: |  |  |  |  |
| Deferred tax assets |  | $ | 1,345 |  |  | $ | 1,648 |  |
| Investments in privately held companies |  | 976 |  |  | 897 |  |
| Other |  | 827 |  |  | 618 |  |
| Total |  | $ | 3,148 |  |  | $ | 3,163 |  |


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0000858877-16-000109:notes:307]
| Property and equipment, net: |  |  |  |  |
| Gross property and equipment: |  |  |  |  |
| Land, buildings, and building and leasehold improvements |  | $ | 4,706 |  |  | $ | 4,495 |  |
| Computer equipment and related software |  | 1,384 |  |  | 1,310 |  |
| Production, engineering, and other equipment |  | 5,700 |  |  | 5,753 |  |
| Operating lease assets |  | 325 |  |  | 372 |  |
| Furniture and fixtures |  | 527 |  |  | 497 |  |
| Total gross property and equipment |  | 12,642 |  |  | 12,427 |  |
| Less: accumulated depreciation and amortization |  | (9,113 | ) |  | (9,095 | ) |
| Total |  | $ | 3,529 |  |  | $ | 3,332 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000858877-16-000109:notes:308]
[same as prior period, unchanged from 0000858877-16-000090:notes:299]

[0000858877-16-000109:notes:309]
Fiscal 2015 Plan  The Company announced a restructuring action in August 2014 (the "Fiscal 2015 Plan"), in order to realign its workforce towards key growth areas of its business such as data center, software, security, and cloud. The Company's aggregate pre-tax estimated charges pursuant to the restructuring plan are expected to be approximately $750 million, consisting of severance and other one-time termination benefits and other associated costs, and the Company has incurred cumulative charges of approximately $743 million in connection with this plan, which is substantially complete. The Company incurred charges of $18 million and $24 million for the three months ended April 30, 2016 and April 25, 2015, respectively, and $254 million, net of a $2 million credit to cost of sales, and $411 million for the nine months ended April 30, 2016 and April 25, 2015, respectively.

[0000858877-16-000109:notes:310]
Fiscal 2014 Plan  In connection with a restructuring action announced in August 2013 (the "Fiscal 2014 Plan"), the Company incurred cumulative charges of approximately $417 million, of which a $1 million credit was recognized during the three and nine months ended April 30, 2016.  No charges were incurred in the corresponding periods of fiscal 2015.  The Company completed the Fiscal 2014 Plan at the end of fiscal 2014.

[0000858877-16-000109:notes:311]
[same as prior period, unchanged from 0000858877-16-000090:notes:302]

[0000858877-16-000109:notes:312]
|  |  | FISCAL 2014 PLAN |  | FISCAL 2015 PLAN |  |  |
|  |  | EmployeeSeverance |  | Other |  | EmployeeSeverance |  | Other |  | Total |
| Liability as of July 25, 2015 |  | $ | 11 |  |  | $ | 14 |  |  | $ | 49 |  |  | $ | 15 |  |  | $ | 89 |  |
| Charges |  | — |  |  | (1 | ) |  | 224 |  |  | 32 |  |  | 255 |  |
| Cash payments |  | (11 | ) |  | (3 | ) |  | (227 | ) |  | (10 | ) |  | (251 | ) |
| Non-cash items |  | — |  |  | — |  |  | — |  |  | (21 | ) |  | (21 | ) |
| Liability as of April 30, 2016 |  | $ | — |  |  | $ | 10 |  |  | $ | 46 |  |  | $ | 16 |  |  | $ | 72 |  |


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000858877-16-000109:notes:313]
[same as prior period, unchanged from 0000858877-16-000090:notes:304]


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000858877-16-000109:notes:314]
[same as prior period, unchanged from 0000858877-16-000090:notes:305]

[0000858877-16-000109:notes:315]
[same as prior period, unchanged from 0000858877-16-000090:notes:306]

[0000858877-16-000109:notes:316]
During the nine months ended April 30, 2016, the Company declared and paid cash dividends of $0.68 per common share, or $3.4 billion, on the Company’s outstanding common stock. During the nine months ended April 25, 2015, the Company declared and paid cash dividends of $0.59 per common share, or $3.0 billion, on the Company’s outstanding common stock.

[0000858877-16-000109:notes:317]
Any future dividends will be subject to the approval of the Company's Board of Directors.

[0000858877-16-000109:notes:318]
[same as prior period, unchanged from 0000858877-16-000090:notes:309]

[0000858877-16-000109:notes:319]
In September 2001, the Company’s Board of Directors authorized a stock repurchase program. As of April 30, 2016, the Company’s Board of Directors had authorized an aggregate repurchase of up to $112 billion of common stock under this program, and the remaining authorized repurchase amount was $16.2 billion, with no termination date. A summary of the stock repurchase activity under the stock repurchase program, reported based on the trade date, is summarized as follows (in millions, except per-share amounts):

[0000858877-16-000109:notes:320]
[same as prior period, unchanged from 0000858877-16-000090:notes:312]

[0000858877-16-000109:notes:321]
[same as prior period, unchanged from 0000858877-16-000090:notes:313]

[0000858877-16-000109:notes:322]
For the nine months ended April 30, 2016 and April 25, 2015, the Company repurchased approximately 18 million and 17 million shares, or $469 million and $415 million, of common stock, respectively, in settlement of employee tax withholding obligations due upon the vesting of restricted stock or stock units.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000858877-16-000109:notes:323]
[same as prior period, unchanged from 0000858877-16-000090:notes:315]


## us-gaap:TreasuryStockTextBlock

[0000858877-16-000109:notes:324]
[same as prior period, unchanged from 0000858877-16-000090:notes:316]

[0000858877-16-000109:notes:325]
In September 2001, the Company’s Board of Directors authorized a stock repurchase program. As of April 30, 2016, the Company’s Board of Directors had authorized an aggregate repurchase of up to $112 billion of common stock under this program with no termination date. For additional information regarding stock repurchase, see Note 13 to the Consolidated Financial Statements. The stock repurchases since the inception of this program and the related impacts on Cisco shareholders’ equity are summarized in the following table (in millions):
