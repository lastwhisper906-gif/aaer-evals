# CSCO MD&A — 0000858877-19-000007


## mdna

[0000858877-19-000007:mdna:1]
[same as prior period, unchanged from 0000858877-19-000003:mdna:1]

[0000858877-19-000007:mdna:2]
[same as prior period, unchanged from 0000858877-19-000003:mdna:2]

[0000858877-19-000007:mdna:3]
[same as prior period, unchanged from 0000858877-19-000003:mdna:3]

[0000858877-19-000007:mdna:4]
[same as prior period, unchanged from 0000858877-19-000003:mdna:4]

[0000858877-19-000007:mdna:5]
|  | Three Months Ended |  | Nine Months Ended |  |
|  | April 27, 2019 |  | April 28, 2018 |  | % Variance |  | April 27, 2019 |  | April 28, 2018 |  | % Variance |  |
| Revenue (1) | $ | 12,958 |  |  | $ | 12,463 |  |  | 4 | % |  | $ | 38,476 |  |  | $ | 36,486 |  |  | 5 | % |  |
| Gross margin percentage | 63.1 | % |  | 62.3 | % |  | 0.8 |  | pts | 62.6 | % |  | 62.2 | % |  | 0.4 |  | pts |
| Research and development | $ | 1,659 |  |  | $ | 1,590 |  |  | 4 | % |  | $ | 4,824 |  |  | $ | 4,706 |  |  | 3 | % |  |
| Sales and marketing | $ | 2,403 |  |  | $ | 2,325 |  |  | 3 | % |  | $ | 7,084 |  |  | $ | 6,894 |  |  | 3 | % |  |
| General and administrative | $ | 541 |  |  | $ | 561 |  |  | (4 | )% |  | $ | 1,261 |  |  | $ | 1,601 |  |  | (21 | )% |  |
| Total research and development, sales and marketing, general and administrative | $ | 4,603 |  |  | $ | 4,476 |  |  | 3 | % |  | $ | 13,169 |  |  | $ | 13,201 |  |  | — | % |  |
| Total as a percentage of revenue | 35.5 | % |  | 35.9 | % |  | (0.4 | ) | pts | 34.2 | % |  | 36.2 | % |  | (2.0 | ) | pts |
| Amortization of purchased intangible assets included in operating expenses | $ | 39 |  |  | $ | 67 |  |  | (42 | )% |  | $ | 112 |  |  | $ | 188 |  |  | (40 | )% |  |
| Restructuring and other charges included in operating expenses | $ | 18 |  |  | $ | 82 |  |  | (78 | )% |  | $ | 282 |  |  | $ | 332 |  |  | (15 | )% |  |
| Operating income as a percentage of revenue | 27.1 | % |  | 25.1 | % |  | 2.0 |  | pts | 27.4 | % |  | 24.6 | % |  | 2.8 |  | pts |
| Interest and other income (loss), net | $ | 102 |  |  | $ | 119 |  |  | (14 | )% |  | $ | 338 |  |  | $ | 484 |  |  | (30 | )% |  |
| Income tax percentage (2) | 15.8 | % |  | 17.3 | % |  | (1.5 | ) | pts | 13.4 | % |  | 139.1 | % |  | NM |  |  |
| Net income (loss) (2) | $ | 3,044 |  |  | $ | 2,691 |  |  | 13 | % |  | $ | 9,415 |  |  | $ | (3,693 | ) |  | NM |  |  |
| Net income (loss) as a percentage of revenue (2) | 23.5 | % |  | 21.6 | % |  | 1.9 |  | pts | 24.5 | % |  | (10.1 | )% |  | NM |  |  |
| Earnings (loss) per share—diluted (2) | $ | 0.69 |  |  | $ | 0.56 |  |  | 23 | % |  | $ | 2.09 |  |  | $ | (0.76 | ) |  | NM |  |  |

[0000858877-19-000007:mdna:6]
NM - Not meaningful; we recognized a net loss for the first nine months of fiscal 2018 related to the enactment of the Tax Cuts and Jobs Act.

[0000858877-19-000007:mdna:7]
We adopted ASC 606 in the first quarter of fiscal 2019 using the modified retrospective method. See Note 2 to the Consolidated Financial Statements for impact of this adoption on our operating results for the third quarter and first nine months of fiscal 2019.

[0000858877-19-000007:mdna:8]
(1) During the second quarter of fiscal 2019, we completed the sale of our Service Provider Video Software Solutions (“SPVSS”) business. As a result, revenue from this business will not recur in future periods. Includes SPVSS business revenue of $0 and $219 million for the third quarter of fiscal 2019 and 2018, respectively, and $168 million and $697 million for the first nine months of fiscal 2019 and 2018, respectively.

[0000858877-19-000007:mdna:9]
(2) The first nine months of fiscal 2018 results include an $11.1 billion charge related to the enactment of the Tax Cuts and Jobs Act.

[0000858877-19-000007:mdna:10]
[same as prior period, unchanged from 0000858877-19-000003:mdna:10]

[0000858877-19-000007:mdna:11]
[same as prior period, unchanged from 0000858877-19-000003:mdna:11]

[0000858877-19-000007:mdna:12]
Three Months Ended April 27, 2019 Compared with Three Months Ended April 28, 2018

[0000858877-19-000007:mdna:13]
In the third quarter of fiscal 2019, we had strong performance across the business and delivered strong revenue growth, margins and operating cash flow. We remain focused on accelerating innovation across our portfolio, and we believe that we have made continued progress on our strategic priorities. Our product revenue reflected growth in Infrastructure Platforms, Applications and Security, and we continued to make progress in the transition of our business model to increased software and subscriptions. Notwithstanding the third quarter fiscal 2019 results, we continue to operate in a challenging and highly competitive environment. While the overall environment remains uncertain, we continue to aggressively invest in priority areas with the objective of driving profitable growth over the long term.

[0000858877-19-000007:mdna:14]
Total revenue increased by 4% compared with the third quarter of fiscal 2018. Within total revenue, product revenue increased by 4% and service revenue increased by 2%. In the second quarter of fiscal 2019, on October 28, 2018, we completed the sale of our SPVSS business. Total revenue for the third quarter of fiscal 2019 increased 6% not including revenue from the SPVSS business in the prior year period. Total gross margin increased by 0.8 percentage points, driven by productivity improvements partially offset by unfavorable impacts from pricing and mix. Our gross margin also benefited from the sale of our lower margin SPVSS business during the second quarter of fiscal 2019. As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses decreased by 0.4 percentage points. Operating income as a percentage of revenue increased by 2.0 percentage points. Diluted earnings per share increased by 23%, driven by a 13% increase in net income and a decrease in diluted share count of 429 million shares.

[0000858877-19-000007:mdna:15]
In terms of our geographic segments, revenue from the Americas increased $534 million, driven in large part by product revenue growth in the United States. EMEA revenue increased by $75 million, led by a product revenue growth in the United Kingdom. Revenue in our APJC segment decreased by $114 million, led by a product revenue decline in China. The “BRICM” countries experienced a product revenue decline of 15% in the aggregate, driven by decreased product revenue in the emerging countries of Russia, China, India, Mexico and Brazil of 25%, 21%, 10%, 6% and 5%, respectively.

[0000858877-19-000007:mdna:16]
[same as prior period, unchanged from 0000858877-19-000003:mdna:16]

[0000858877-19-000007:mdna:17]
From a product category perspective, total product revenue, not including SPVSS products in the prior year period, increased 7% year over year. The increase was driven by a 5% product revenue increase in Infrastructure Platforms, solid product revenue growth in Applications of 9%, and strong growth in Security of 21%.

[0000858877-19-000007:mdna:18]
[same as prior period, unchanged from 0000858877-19-000003:mdna:19]

[0000858877-19-000007:mdna:19]
[same as prior period, unchanged from 0000858877-19-000003:mdna:20]

[0000858877-19-000007:mdna:20]
Nine Months Ended April 27, 2019 Compared with Nine Months Ended April 28, 2018

[0000858877-19-000007:mdna:21]
Total revenue increased 5%, with product revenue increasing 7% and service revenue increasing 2%. Total gross margin increased by 0.4 percentage points. As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses collectively decreased by 2.0 percentage points due to lower general and administrative expenses. General and administrative expenses decreased due to a benefit from the $400 million litigation settlement with Arista in the first quarter of fiscal 2019. Operating income as a percentage of revenue increased by 2.8 percentage points. The net loss and net loss per share in the prior year period were driven by the one-time transition tax on accumulated earnings of foreign subsidiaries, foreign withholding taxes, and re-measurement of net deferred tax assets and liabilities recorded during the first nine months of fiscal 2018 as related to the Tax Cuts and Jobs Act.

[0000858877-19-000007:mdna:22]
[same as prior period, unchanged from 0000858877-19-000003:mdna:23]

[0000858877-19-000007:mdna:23]
[same as prior period, unchanged from 0000858877-19-000003:mdna:24]

[0000858877-19-000007:mdna:24]
[same as prior period, unchanged from 0000858877-19-000003:mdna:25]

[0000858877-19-000007:mdna:25]
[same as prior period, unchanged from 0000858877-19-000003:mdna:26]

[0000858877-19-000007:mdna:26]
The following is a summary of our other key financial measures for the third quarter and first nine months of fiscal 2019 (in millions):

[0000858877-19-000007:mdna:27]
|  |  | April 27, 2019 |  | July 28, 2018 |
| Cash and cash equivalents and investments |  | $ | 34,643 |  |  | $ | 46,548 |  |
| Deferred revenue |  | $ | 17,456 |  |  | $ | 19,685 |  |
| Inventories |  | $ | 1,513 |  |  | $ | 1,846 |  |

[0000858877-19-000007:mdna:28]
|  |  | Nine Months Ended |
|  |  | April 27, 2019 |  | April 28, 2018 |
| Cash provided by operating activities |  | $ | 11,889 |  |  | $ | 9,566 |  |
| Repurchases of common stock—stock repurchase program |  | $ | 16,062 |  |  | $ | 11,646 |  |
| Dividends |  | $ | 4,489 |  |  | $ | 4,433 |  |

[0000858877-19-000007:mdna:29]
[same as prior period, unchanged from 0000858877-19-000003:mdna:18]

[0000858877-19-000007:mdna:30]
[same as prior period, unchanged from 0000858877-19-000003:mdna:31]

[0000858877-19-000007:mdna:31]
[same as prior period, unchanged from 0000858877-19-000003:mdna:32]

[0000858877-19-000007:mdna:32]
[same as prior period, unchanged from 0000858877-19-000003:mdna:33]

[0000858877-19-000007:mdna:33]
[same as prior period, unchanged from 0000858877-19-000003:mdna:34]

[0000858877-19-000007:mdna:34]
[same as prior period, unchanged from 0000858877-19-000003:mdna:35]

[0000858877-19-000007:mdna:35]
[same as prior period, unchanged from 0000858877-19-000003:mdna:36]

[0000858877-19-000007:mdna:36]
[same as prior period, unchanged from 0000858877-19-000003:mdna:37]

[0000858877-19-000007:mdna:37]
[same as prior period, unchanged from 0000858877-19-000003:mdna:38]

[0000858877-19-000007:mdna:38]
[same as prior period, unchanged from 0000858877-19-000003:mdna:39]

[0000858877-19-000007:mdna:39]
[same as prior period, unchanged from 0000858877-19-000003:mdna:40]

[0000858877-19-000007:mdna:40]
[same as prior period, unchanged from 0000858877-19-000003:mdna:41]

[0000858877-19-000007:mdna:41]
[same as prior period, unchanged from 0000858877-19-000003:mdna:42]

[0000858877-19-000007:mdna:42]
[same as prior period, unchanged from 0000858877-19-000003:mdna:43]

[0000858877-19-000007:mdna:43]
[same as prior period, unchanged from 0000858877-19-000003:mdna:45]

[0000858877-19-000007:mdna:44]
[same as prior period, unchanged from 0000858877-19-000003:mdna:46]

[0000858877-19-000007:mdna:45]
[same as prior period, unchanged from 0000858877-19-000003:mdna:47]

[0000858877-19-000007:mdna:46]
[same as prior period, unchanged from 0000858877-19-000003:mdna:48]

[0000858877-19-000007:mdna:47]
|  |  | April 27, 2019 |  | July 28, 2018 |
| Allowance for doubtful accounts |  | $ | 124 |  |  | $ | 129 |  |
| Percentage of gross accounts receivable |  | 3.2 | % |  | 2.3 | % |
| Allowance for credit loss—lease receivables |  | $ | 68 |  |  | $ | 135 |  |
| Percentage of gross lease receivables(1) |  | 2.6 | % |  | 4.7 | % |
| Allowance for credit loss—loan receivables |  | $ | 77 |  |  | $ | 60 |  |
| Percentage of gross loan receivables |  | 1.5 | % |  | 1.2 | % |

[0000858877-19-000007:mdna:48]
[same as prior period, unchanged from 0000858877-19-000003:mdna:50]

[0000858877-19-000007:mdna:49]
[same as prior period, unchanged from 0000858877-19-000003:mdna:51]

[0000858877-19-000007:mdna:50]
[same as prior period, unchanged from 0000858877-19-000003:mdna:52]

[0000858877-19-000007:mdna:51]
A reserve for future sales returns is established based on historical trends in product return rates. The reserve for future sales returns as of April 27, 2019 and July 28, 2018 was $82 million and $123 million, respectively, and was recorded as a reduction of our accounts receivable and revenue. If the actual future returns were to deviate from the historical data on which the reserve had been established, our revenue could be adversely affected.

[0000858877-19-000007:mdna:52]
[same as prior period, unchanged from 0000858877-19-000003:mdna:54]

[0000858877-19-000007:mdna:53]
[same as prior period, unchanged from 0000858877-19-000003:mdna:55]

[0000858877-19-000007:mdna:54]
[same as prior period, unchanged from 0000858877-19-000003:mdna:56]

[0000858877-19-000007:mdna:55]
Our provision for inventory was $55 million and $42 million for the first nine months of fiscal 2019 and 2018, respectively. The provision for the liability related to purchase commitments with contract manufacturers and suppliers was $65 million and $77 million for the first nine months of fiscal 2019 and 2018, respectively. If there were to be a sudden and significant decrease in demand for our products, or if there were a higher incidence of inventory obsolescence because of rapidly changing technology and customer requirements, we could be required to increase our inventory write-downs, and our liability for purchase commitments with contract manufacturers and suppliers, and accordingly our profitability, could be adversely affected. We regularly evaluate our exposure for inventory write-downs and the adequacy of our liability for purchase commitments.

[0000858877-19-000007:mdna:56]
[same as prior period, unchanged from 0000858877-19-000003:mdna:59]

[0000858877-19-000007:mdna:57]
[same as prior period, unchanged from 0000858877-19-000003:mdna:60]

[0000858877-19-000007:mdna:58]
Loss Contingencies and Product Warranties

[0000858877-19-000007:mdna:59]
We are subject to the possibility of various losses arising in the ordinary course of business. We consider the likelihood of impairment of an asset or the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated. We regularly evaluate information available to us to determine whether such accruals should be made or adjusted and whether new accruals are required.

[0000858877-19-000007:mdna:60]
Third parties, including customers, have in the past and may in the future assert claims or initiate litigation related to exclusive patent, copyright, trademark, and other intellectual property rights to technologies and related standards that are relevant to us. These assertions have increased over time as a result of our growth and the general increase in the pace of patent claims assertions, particularly in the United States. If any infringement or other intellectual property claim made against us by any third party is successful, or if we fail to develop non-infringing technology or license the proprietary rights on commercially reasonable terms and conditions, our business, operating results, and financial condition could be materially and adversely affected.

[0000858877-19-000007:mdna:61]
[same as prior period, unchanged from 0000858877-19-000003:mdna:64]

[0000858877-19-000007:mdna:62]
[same as prior period, unchanged from 0000858877-19-000003:mdna:65]

[0000858877-19-000007:mdna:63]
[same as prior period, unchanged from 0000858877-19-000003:mdna:66]

[0000858877-19-000007:mdna:64]
[same as prior period, unchanged from 0000858877-19-000003:mdna:67]

[0000858877-19-000007:mdna:65]
[same as prior period, unchanged from 0000858877-19-000003:mdna:68]

[0000858877-19-000007:mdna:66]
We hold non-marketable equity and other investments, some of which are in the startup or development stages. As of April 27, 2019, our non-marketable equity and other investments were $1.3 billion, compared with $1.1 billion as of July 28, 2018, and were included in other assets. We monitor these investments for events or circumstances indicative of potential impairment, and we make appropriate reductions in carrying values if we determine that an impairment charge is required, based primarily on the financial condition and near-term prospects of these companies. These investments are inherently risky because the markets for the technologies or products these companies are developing are typically in the early stages and may never materialize.

[0000858877-19-000007:mdna:67]
[same as prior period, unchanged from 0000858877-19-000003:mdna:70]

[0000858877-19-000007:mdna:68]
[same as prior period, unchanged from 0000858877-19-000003:mdna:71]

[0000858877-19-000007:mdna:69]
[same as prior period, unchanged from 0000858877-19-000003:mdna:58]

[0000858877-19-000007:mdna:70]
[same as prior period, unchanged from 0000858877-19-000003:mdna:72]

[0000858877-19-000007:mdna:71]
[same as prior period, unchanged from 0000858877-19-000003:mdna:73]

[0000858877-19-000007:mdna:72]
The goodwill recorded in the Consolidated Balance Sheets as of April 27, 2019 and July 28, 2018 was $33.5 billion and $31.7 billion, respectively. In response to changes in industry and market conditions, we could be required to strategically realign our resources and consider restructuring, disposing of, or otherwise exiting businesses, which could result in an impairment of goodwill. There was no impairment of goodwill in each of the first nine months of fiscal 2019 and 2018.

[0000858877-19-000007:mdna:73]
[same as prior period, unchanged from 0000858877-19-000003:mdna:75]

[0000858877-19-000007:mdna:74]
[same as prior period, unchanged from 0000858877-19-000003:mdna:76]

[0000858877-19-000007:mdna:75]
There were no impairment charges related to purchased intangible assets for the first nine months of fiscal 2019 and $1 million of such impairment charges for the first nine months of fiscal 2018. Our ongoing consideration of all the factors described previously could result in additional impairment charges in the future, which could adversely affect our net income.

[0000858877-19-000007:mdna:76]
[same as prior period, unchanged from 0000858877-19-000003:mdna:78]

[0000858877-19-000007:mdna:77]
We are subject to income taxes in the United States and numerous foreign jurisdictions. Our effective tax rates differ from the statutory rate, primarily due to the tax impact of state taxes, foreign operations, R&D tax credits, domestic manufacturing deductions, foreign-derived intangible income deductions, global intangible low-taxed income, tax audit settlements, nondeductible compensation, international realignments, and transfer pricing adjustments. Our effective tax rate was 15.8% and 17.3% in the third quarter of fiscal 2019 and 2018, respectively. Our effective tax rate was 13.4% and 139.1% in the first nine months of fiscal 2019 and 2018, respectively.

[0000858877-19-000007:mdna:78]
[same as prior period, unchanged from 0000858877-19-000003:mdna:80]

[0000858877-19-000007:mdna:79]
[same as prior period, unchanged from 0000858877-19-000003:mdna:81]

[0000858877-19-000007:mdna:80]
[same as prior period, unchanged from 0000858877-19-000003:mdna:82]

[0000858877-19-000007:mdna:81]
[same as prior period, unchanged from 0000858877-19-000003:mdna:83]

[0000858877-19-000007:mdna:82]
[same as prior period, unchanged from 0000858877-19-000003:mdna:84]

[0000858877-19-000007:mdna:83]
[same as prior period, unchanged from 0000858877-19-000003:mdna:85]

[0000858877-19-000007:mdna:84]
56

[0000858877-19-000007:mdna:85]
[same as prior period, unchanged from 0000858877-19-000003:mdna:87]

[0000858877-19-000007:mdna:86]
[same as prior period, unchanged from 0000858877-19-000003:mdna:88]

[0000858877-19-000007:mdna:87]
[same as prior period, unchanged from 0000858877-19-000003:mdna:89]

[0000858877-19-000007:mdna:88]
[same as prior period, unchanged from 0000858877-19-000003:mdna:90]

[0000858877-19-000007:mdna:89]
[same as prior period, unchanged from 0000858877-19-000003:mdna:91]

[0000858877-19-000007:mdna:90]
|  |  | Three Months Ended (1) |  | Nine Months Ended |
|  |  | April 27, 2019 |  | April 28, 2018 |  | Variancein Dollars |  | Variance in Percent |  | April 27, 2019 |  | April 28, 2018 |  | Variancein Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 9,722 |  |  | $ | 9,304 |  |  | $ | 418 |  |  | 4 | % |  | $ | 28,885 |  |  | $ | 27,067 |  |  | $ | 1,818 |  |  | 7 | % |
| Percentage of revenue |  | 75.0 | % |  | 74.7 | % |  |  |  |  |  |  |  | 75.1 | % |  | 74.2 | % |  |  |  |  |  |  |
| Service |  | 3,236 |  |  | 3,159 |  |  | 77 |  |  | 2 | % |  | 9,591 |  |  | 9,419 |  |  | 172 |  |  | 2 | % |
| Percentage of revenue |  | 25.0 | % |  | 25.3 | % |  |  |  |  |  |  |  | 24.9 | % |  | 25.8 | % |  |  |  |  |  |  |
| Total |  | $ | 12,958 |  |  | $ | 12,463 |  |  | $ | 495 |  |  | 4 | % |  | $ | 38,476 |  |  | $ | 36,486 |  |  | $ | 1,990 |  |  | 5 | % |

[0000858877-19-000007:mdna:91]
(1) Total revenue, product revenue and service revenue not including the SPVSS business in the prior year period increased 6%, 7% and 3%, respectively.

[0000858877-19-000007:mdna:92]
[same as prior period, unchanged from 0000858877-19-000003:mdna:94]

[0000858877-19-000007:mdna:93]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 27, 2019 |  | April 28, 2018 |  | Variancein Dollars |  | Variance in Percent |  | April 27, 2019 |  | April 28, 2018 |  | Variancein Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 7,695 |  |  | $ | 7,161 |  |  | $ | 534 |  |  | 7 | % |  | $ | 22,798 |  |  | $ | 21,515 |  |  | $ | 1,283 |  |  | 6 | % |
| Percentage of revenue |  | 59.4 | % |  | 57.5 | % |  |  |  |  |  | 59.2 | % |  | 59.0 | % |  |  |  |  |
| EMEA |  | 3,356 |  |  | 3,281 |  |  | 75 |  |  | 2 | % |  | 9,803 |  |  | 9,252 |  |  | 551 |  |  | 6 | % |
| Percentage of revenue |  | 25.9 | % |  | 26.3 | % |  |  |  |  |  | 25.5 | % |  | 25.3 | % |  |  |  |  |
| APJC |  | 1,907 |  |  | 2,021 |  |  | (114 | ) |  | (6 | )% |  | 5,875 |  |  | 5,719 |  |  | 156 |  |  | 3 | % |
| Percentage of revenue |  | 14.7 | % |  | 16.2 | % |  |  |  |  |  | 15.3 | % |  | 15.7 | % |  |  |  |  |
| Total |  | $ | 12,958 |  |  | $ | 12,463 |  |  | $ | 495 |  |  | 4 | % |  | $ | 38,476 |  |  | $ | 36,486 |  |  | $ | 1,990 |  |  | 5 | % |

[0000858877-19-000007:mdna:94]
[same as prior period, unchanged from 0000858877-19-000003:mdna:96]

[0000858877-19-000007:mdna:95]
Three Months Ended April 27, 2019 Compared with Three Months Ended April 28, 2018

[0000858877-19-000007:mdna:96]
Total revenue increased by 4%. Product revenue increased by 4% and service revenue increased by 2%. Total revenue reflected growth in the Americas and EMEA segments while revenue declined in the APJC segment. Product revenue for the emerging countries of BRICM, in the aggregate, experienced a 15% product revenue decline, with decreases across each of these countries.

[0000858877-19-000007:mdna:97]
[same as prior period, unchanged from 0000858877-19-000003:mdna:99]

[0000858877-19-000007:mdna:98]
Nine Months Ended April 27, 2019 Compared with Nine Months Ended April 28, 2018

[0000858877-19-000007:mdna:99]
Total revenue increased by 5%. Product revenue increased by 7% and service revenue increased by 2%. Our total revenue reflected growth across each of our geographic segments. Product revenue for the emerging countries of BRICM, in the aggregate, experienced 5% product revenue growth, with increases in Mexico, India, and Brazil, partially offset by a decrease in China. Product revenue in Russia was flat.

[0000858877-19-000007:mdna:100]
[same as prior period, unchanged from 0000858877-19-000003:mdna:86]

[0000858877-19-000007:mdna:101]
[same as prior period, unchanged from 0000858877-19-000003:mdna:102]

[0000858877-19-000007:mdna:102]
[same as prior period, unchanged from 0000858877-19-000003:mdna:103]

[0000858877-19-000007:mdna:103]
[same as prior period, unchanged from 0000858877-19-000003:mdna:104]

[0000858877-19-000007:mdna:104]
[same as prior period, unchanged from 0000858877-19-000003:mdna:105]

[0000858877-19-000007:mdna:105]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 27, 2019 |  | April 28, 2018 |  | Variancein Dollars |  | Variance in Percent |  | April 27, 2019 |  | April 28, 2018 |  | Variancein Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 5,658 |  |  | $ | 5,167 |  |  | $ | 491 |  |  | 10 | % |  | $ | 16,719 |  |  | $ | 15,547 |  |  | $ | 1,172 |  |  | 8 | % |
| Percentage of product revenue |  | 58.2 | % |  | 55.5 | % |  |  |  |  |  | 57.9 | % |  | 57.5 | % |  |  |  |  |
| EMEA |  | 2,642 |  |  | 2,594 |  |  | 48 |  |  | 2 | % |  | 7,681 |  |  | 7,208 |  |  | 473 |  |  | 7 | % |
| Percentage of product revenue |  | 27.2 | % |  | 27.9 | % |  |  |  |  |  | 26.6 | % |  | 26.6 | % |  |  |  |  |
| APJC |  | 1,422 |  |  | 1,543 |  |  | (121 | ) |  | (8 | )% |  | 4,486 |  |  | 4,312 |  |  | 174 |  |  | 4 | % |
| Percentage of product revenue |  | 14.6 | % |  | 16.6 | % |  |  |  |  |  | 15.5 | % |  | 15.9 | % |  |  |  |  |
| Total |  | $ | 9,722 |  |  | $ | 9,304 |  |  | $ | 418 |  |  | 4 | % |  | $ | 28,885 |  |  | $ | 27,067 |  |  | $ | 1,818 |  |  | 7 | % |

[0000858877-19-000007:mdna:106]
[same as prior period, unchanged from 0000858877-19-000003:mdna:107]

[0000858877-19-000007:mdna:107]
[same as prior period, unchanged from 0000858877-19-000003:mdna:108]

[0000858877-19-000007:mdna:108]
Three Months Ended April 27, 2019 Compared with Three Months Ended April 28, 2018

[0000858877-19-000007:mdna:109]
Product revenue in the Americas segment increased by 10%, led by growth in the enterprise, public sector and commercial markets, partially offset by a decline in the service provider market. From a country perspective, product revenue increased by 12% in the United States while product revenue in Canada, Mexico and Brazil decreased by 8%, 6% and 5%, respectively.

[0000858877-19-000007:mdna:110]
Nine Months Ended April 27, 2019 Compared with Nine Months Ended April 28, 2018

[0000858877-19-000007:mdna:111]
The increase in product revenue in the Americas segment was led by growth in the enterprise, public sector and commercial markets. These increases were partially offset by a product revenue decline in the service provider market. From a country perspective, product revenue increased by 9% in the United States, 32% in Mexico, 7% in Canada and 3% in Brazil.

[0000858877-19-000007:mdna:112]
[same as prior period, unchanged from 0000858877-19-000003:mdna:113]

[0000858877-19-000007:mdna:113]
Three Months Ended April 27, 2019 Compared with Three Months Ended April 28, 2018

[0000858877-19-000007:mdna:114]
Product revenue in the EMEA segment increased by 2%, with growth in the public sector and enterprise markets partially offset by declines in the service provider and commercial markets. From a country perspective, product revenue growth was driven by a 13% increase in the United Kingdom. Product revenue from emerging countries within EMEA increased by 10% while product revenue for the remainder of the EMEA segment, which primarily consists of countries in Western Europe, was flat.

[0000858877-19-000007:mdna:115]
Nine Months Ended April 27, 2019 Compared with Nine Months Ended April 28, 2018

[0000858877-19-000007:mdna:116]
Product revenue in the EMEA segment increased by 7%, with growth in the public sector and enterprise markets partially offset by declines in the service provider and commercial markets. Product revenue from emerging countries within EMEA increased by 7%, and product revenue for the remainder of the EMEA segment also increased by 7%.

[0000858877-19-000007:mdna:117]
[same as prior period, unchanged from 0000858877-19-000003:mdna:120]

[0000858877-19-000007:mdna:118]
Three Months Ended April 27, 2019 Compared with Three Months Ended April 28, 2018

[0000858877-19-000007:mdna:119]
Product revenue in the APJC segment decreased by 8%, driven by declines in the commercial, service provider and enterprise markets, partially offset by growth in the public sector market. From a country perspective, the product revenue decline was driven  by a 21% decrease in China. We also saw decreases of 18% in Australia and 10% in India, partially offset by a product revenue increase in Japan of 6%.

[0000858877-19-000007:mdna:120]
Nine Months Ended April 27, 2019 Compared with Nine Months Ended April 28, 2018

[0000858877-19-000007:mdna:121]
Product revenue in the APJC segment increased 4%, with growth in the public sector, enterprise and commercial markets partially offset by a decline in the service provider market. From a country perspective, product revenue increased by 18% in India and 10% in Japan, while product revenue in China decreased by 12%.

[0000858877-19-000007:mdna:122]
58

[0000858877-19-000007:mdna:123]
[same as prior period, unchanged from 0000858877-19-000003:mdna:118]

[0000858877-19-000007:mdna:124]
[same as prior period, unchanged from 0000858877-19-000003:mdna:119]

[0000858877-19-000007:mdna:125]
[same as prior period, unchanged from 0000858877-19-000003:mdna:125]

[0000858877-19-000007:mdna:126]
[same as prior period, unchanged from 0000858877-19-000003:mdna:126]

[0000858877-19-000007:mdna:127]
[same as prior period, unchanged from 0000858877-19-000003:mdna:127]

[0000858877-19-000007:mdna:128]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 27, 2019 |  | April 28, 2018 |  | Variancein Dollars |  | Variance in Percent |  | April 27, 2019 |  | April 28, 2018 |  | Variancein Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Infrastructure Platforms |  | $ | 7,545 |  |  | $ | 7,180 |  |  | $ | 365 |  |  | 5 | % |  | $ | 22,315 |  |  | $ | 20,870 |  |  | $ | 1,445 |  |  | 7 | % |
| Applications |  | 1,431 |  |  | 1,310 |  |  | 121 |  |  | 9 | % |  | 4,315 |  |  | 3,697 |  |  | 618 |  |  | 17 | % |
| Security |  | 707 |  |  | 583 |  |  | 124 |  |  | 21 | % |  | 2,016 |  |  | 1,725 |  |  | 291 |  |  | 17 | % |
| Other Products |  | 39 |  |  | 231 |  |  | (192 | ) |  | (83 | )% |  | 239 |  |  | 775 |  |  | (536 | ) |  | (69 | )% |
| Total |  | $ | 9,722 |  |  | $ | 9,304 |  |  | $ | 418 |  |  | 4 | % |  | $ | 28,885 |  |  | $ | 27,067 |  |  | $ | 1,818 |  |  | 7 | % |

[0000858877-19-000007:mdna:129]
[same as prior period, unchanged from 0000858877-19-000003:mdna:129]

[0000858877-19-000007:mdna:130]
[same as prior period, unchanged from 0000858877-19-000003:mdna:130]

[0000858877-19-000007:mdna:131]
Three Months Ended April 27, 2019 Compared with Three Months Ended April 28, 2018

[0000858877-19-000007:mdna:132]
The Infrastructure Platforms product category represents our core networking offerings related to switching, routing, wireless, and the data center. Infrastructure Platforms revenue increased by 5%, or $365 million, with solid growth across the portfolio. The growth in switching was driven by an increase in sales of our intent-based networking Catalyst 9000 Series and strength in our Application Centric Infrastructure (ACI) portfolio. Revenue from our routing products increased driven by growth in our software-defined wide area network (SD-WAN) products. We experienced solid revenue growth from wireless products driven by growth across the portfolio.  Revenue from data center also increased driven by higher sales of our hyperconverged data center offering, HyperFlex, and our server products.

[0000858877-19-000007:mdna:133]
Nine Months Ended April 27, 2019 Compared with Nine Months Ended April 28, 2018

[0000858877-19-000007:mdna:134]
Revenue from the Infrastructure Platforms product category increased 7%, or $1,445 million, with growth across the portfolio. Switching had solid growth, with solid revenue growth in campus switching driven by an increase in sales of our intent-based networking Catalyst 9000 Series, and with revenue growth in data center switching driven by increased revenue from our ACI portfolio. Routing experienced revenue growth driven by an increase in sales of SD-WAN products. We experienced double digit revenue growth from wireless products driven by growth across the portfolio. Revenue from data center increased driven by higher sales of HyperFlex and our server products.

[0000858877-19-000007:mdna:135]
[same as prior period, unchanged from 0000858877-19-000003:mdna:138]

[0000858877-19-000007:mdna:136]
Three Months Ended April 27, 2019 Compared with Three Months Ended April 28, 2018

[0000858877-19-000007:mdna:137]
The Applications product category includes our collaboration offerings (unified communications, Cisco TelePresence and conferencing) as well as the Internet of Things (IoT) and analytics software offerings from Jasper and AppDynamics, respectively. Revenue in our Applications product category increased by 9%, or $121 million, with growth across all of the business. We had solid revenue growth in unified communications software, TelePresence and analytics from AppDynamics.

[0000858877-19-000007:mdna:138]
Nine Months Ended April 27, 2019 Compared with Nine Months Ended April 28, 2018

[0000858877-19-000007:mdna:139]
Revenue in our Applications product category increased by 17%, or $618 million, with strong revenue growth in unified communications, TelePresence and analytics from AppDynamics.

[0000858877-19-000007:mdna:140]
[same as prior period, unchanged from 0000858877-19-000003:mdna:143]

[0000858877-19-000007:mdna:141]
Three Months Ended April 27, 2019 Compared with Three Months Ended April 28, 2018

[0000858877-19-000007:mdna:142]
Revenue in our Security product category increased 21%, or $124 million, driven by strong sales of our identity and access, advanced threat security and unified threat management products. The acquisition of Duo Security in the first quarter of fiscal 2019 also contributed to the revenue increase in this product category.

[0000858877-19-000007:mdna:143]
59

[0000858877-19-000007:mdna:144]
[same as prior period, unchanged from 0000858877-19-000003:mdna:136]

[0000858877-19-000007:mdna:145]
[same as prior period, unchanged from 0000858877-19-000003:mdna:137]

[0000858877-19-000007:mdna:146]
Nine Months Ended April 27, 2019 Compared with Nine Months Ended April 28, 2018

[0000858877-19-000007:mdna:147]
Revenue in our Security product category increased 17%, or $291 million, driven by higher sales of identity and access, advanced threat security, unified threat management and web security products. The acquisition of Duo Security in the first quarter of fiscal 2019 also contributed to the revenue increase in this product category.

[0000858877-19-000007:mdna:148]
[same as prior period, unchanged from 0000858877-19-000003:mdna:148]

[0000858877-19-000007:mdna:149]
The decrease in revenue from our Other Products category for the third quarter and first nine months of fiscal 2019, compared to the corresponding periods of fiscal 2018, was primarily driven by a decrease in revenue from the SPVSS business which we divested on October 28, 2018.

[0000858877-19-000007:mdna:150]
[same as prior period, unchanged from 0000858877-19-000003:mdna:150]

[0000858877-19-000007:mdna:151]
[same as prior period, unchanged from 0000858877-19-000003:mdna:151]

[0000858877-19-000007:mdna:152]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 27, 2019 |  | April 28, 2018 |  | Variancein Dollars |  | Variance in Percent |  | April 27, 2019 |  | April 28, 2018 |  | Variancein Dollars |  | Variance in Percent |
| Service revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 2,036 |  |  | $ | 1,994 |  |  | $ | 42 |  |  | 2 | % |  | $ | 6,079 |  |  | $ | 5,968 |  |  | $ | 111 |  |  | 2 | % |
| Percentage of service revenue |  | 62.9 | % |  | 63.1 | % |  |  |  |  |  | 63.4 | % |  | 63.4 | % |  |  |  |  |
| EMEA |  | 715 |  |  | 687 |  |  | 28 |  |  | 4 | % |  | 2,123 |  |  | 2,044 |  |  | 79 |  |  | 4 | % |
| Percentage of service revenue |  | 22.1 | % |  | 21.8 | % |  |  |  |  |  | 22.1 | % |  | 21.7 | % |  |  |  |  |
| APJC |  | 485 |  |  | 478 |  |  | 7 |  |  | 2 | % |  | 1,389 |  |  | 1,407 |  |  | (18 | ) |  | (1 | )% |
| Percentage of service revenue |  | 15.0 | % |  | 15.1 | % |  |  |  |  |  | 14.5 | % |  | 14.9 | % |  |  |  |  |
| Total |  | $ | 3,236 |  |  | $ | 3,159 |  |  | $ | 77 |  |  | 2 | % |  | $ | 9,591 |  |  | $ | 9,419 |  |  | $ | 172 |  |  | 2 | % |

[0000858877-19-000007:mdna:153]
[same as prior period, unchanged from 0000858877-19-000003:mdna:153]

[0000858877-19-000007:mdna:154]
Three Months Ended April 27, 2019 Compared with Three Months Ended April 28, 2018

[0000858877-19-000007:mdna:155]
Service revenue increased 2%, driven by an increase in software and solution support offerings. Service revenue not including the SPVSS business in the prior year period increased by 3%. Service revenue increased across all geographic segments.

[0000858877-19-000007:mdna:156]
Nine Months Ended April 27, 2019 Compared with Nine Months Ended April 28, 2018

[0000858877-19-000007:mdna:157]
[same as prior period, unchanged from 0000858877-19-000003:mdna:157]

[0000858877-19-000007:mdna:158]
[same as prior period, unchanged from 0000858877-19-000003:mdna:161]

[0000858877-19-000007:mdna:159]
[same as prior period, unchanged from 0000858877-19-000003:mdna:162]

[0000858877-19-000007:mdna:160]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | AMOUNT |  | PERCENTAGE |  | AMOUNT |  | PERCENTAGE |
|  |  | April 27, 2019 |  | April 28, 2018 |  | April 27, 2019 |  | April 28, 2018 |  | April 27, 2019 |  | April 28, 2018 |  | April 27, 2019 |  | April 28, 2018 |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 6,029 |  |  | $ | 5,679 |  |  | 62.0 | % |  | 61.0 | % |  | $ | 17,779 |  |  | $ | 16,473 |  |  | 61.6 | % |  | 60.9 | % |
| Service |  | 2,144 |  |  | 2,080 |  |  | 66.3 | % |  | 65.8 | % |  | 6,313 |  |  | 6,211 |  |  | 65.8 | % |  | 65.9 | % |
| Total |  | $ | 8,173 |  |  | $ | 7,759 |  |  | 63.1 | % |  | 62.3 | % |  | $ | 24,092 |  |  | $ | 22,684 |  |  | 62.6 | % |  | 62.2 | % |

[0000858877-19-000007:mdna:161]
[same as prior period, unchanged from 0000858877-19-000003:mdna:135]

[0000858877-19-000007:mdna:162]
[same as prior period, unchanged from 0000858877-19-000003:mdna:159]

[0000858877-19-000007:mdna:163]
[same as prior period, unchanged from 0000858877-19-000003:mdna:160]

[0000858877-19-000007:mdna:164]
[same as prior period, unchanged from 0000858877-19-000003:mdna:164]

[0000858877-19-000007:mdna:165]
The following table summarizes the key factors that contributed to the change in product gross margin percentage for the third quarter and first nine months of fiscal 2019, as compared with the corresponding prior year periods:

[0000858877-19-000007:mdna:166]
|  |  | Product Gross Margin Percentage |
|  |  | Three Months Ended |  | Nine Months Ended |
| Fiscal 2018 |  | 61.0 | % |  | 60.9 | % |
| Productivity (1) |  | 1.9 | % |  | 1.5 | % |
| Product pricing |  | (1.1 | )% |  | (1.3 | )% |
| Mix of products sold |  | (0.7 | )% |  | (0.5 | )% |
| Impact from divestiture of SPVSS business |  | 0.7 | % |  | 0.6 | % |
| Legal and indemnification settlements |  | — | % |  | 0.4 | % |
| Other |  | 0.2 | % |  | — | % |
| Fiscal 2019 |  | 62.0 | % |  | 61.6 | % |

[0000858877-19-000007:mdna:167]
[same as prior period, unchanged from 0000858877-19-000003:mdna:167]

[0000858877-19-000007:mdna:168]
Three Months Ended April 27, 2019 Compared with Three Months Ended April 28, 2018

[0000858877-19-000007:mdna:169]
Product gross margin increased by 1.0 percentage point driven by productivity improvements, partially offset by unfavorable impacts from product pricing and product mix. Our product gross margin also benefited from the sale of our lower margin SPVSS business during the second quarter of fiscal 2019.

[0000858877-19-000007:mdna:170]
Productivity improvements were driven by cost reductions including value engineering efforts (e.g. component redesign, board configuration, test processes and transformation processes) and continued operational efficiency in manufacturing operations. The negative pricing impact, which was lower than the year-over-year impact we experienced in the third quarter of fiscal 2018, was driven by typical market factors and impacted each of our geographic segments and customer markets. The unfavorable product mix impact was driven by our products within the Infrastructure Platforms product category. Our product gross margin also benefited from lower amortization expense from purchased intangible assets related to the divestiture of the SPVSS business on October 28, 2018.

[0000858877-19-000007:mdna:171]
Nine Months Ended April 27, 2019 Compared with Nine Months Ended April 28, 2018

[0000858877-19-000007:mdna:172]
Product gross margin increased by 0.7 percentage points driven by productivity improvements, partially offset by unfavorable impacts from product pricing and product mix. Our product gross margin also benefited from the sale of our lower margin SPVSS business during the second quarter of fiscal 2019. A charge of $127 million to product cost of sales recorded in the first nine months of fiscal 2018 related to legal and indemnification settlements also contributed to the increase.

[0000858877-19-000007:mdna:173]
[same as prior period, unchanged from 0000858877-19-000003:mdna:177]

[0000858877-19-000007:mdna:174]
Three Months Ended April 27, 2019 Compared with Three Months Ended April 28, 2018

[0000858877-19-000007:mdna:175]
Our service gross margin percentage increased by 0.5 percentage points due to higher sales volume, partially offset by increased delivery costs.

[0000858877-19-000007:mdna:176]
[same as prior period, unchanged from 0000858877-19-000003:mdna:180]

[0000858877-19-000007:mdna:177]
Nine Months Ended April 27, 2019 Compared with Nine Months Ended April 28, 2018

[0000858877-19-000007:mdna:178]
Service gross margin percentage decreased by 0.1 percentage points due to increased headcount-related costs and increased delivery costs. These cost impacts were partially offset by the resulting benefit to gross margin of higher sales volume.

[0000858877-19-000007:mdna:179]
[same as prior period, unchanged from 0000858877-19-000003:mdna:158]

[0000858877-19-000007:mdna:180]
[same as prior period, unchanged from 0000858877-19-000003:mdna:175]

[0000858877-19-000007:mdna:181]
[same as prior period, unchanged from 0000858877-19-000003:mdna:176]

[0000858877-19-000007:mdna:182]
[same as prior period, unchanged from 0000858877-19-000003:mdna:183]

[0000858877-19-000007:mdna:183]
[same as prior period, unchanged from 0000858877-19-000003:mdna:184]

[0000858877-19-000007:mdna:184]
|  | Three Months Ended |  | Nine Months Ended |
|  | AMOUNT |  | PERCENTAGE |  | AMOUNT |  | PERCENTAGE |
|  | April 27, 2019 |  | April 28, 2018 |  | April 27, 2019 |  | April 28, 2018 |  | April 27, 2019 |  | April 28, 2018 |  | April 27, 2019 |  | April 28, 2018 |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 5,046 |  |  | $ | 4,614 |  |  | 65.6 | % |  | 64.4 | % |  | $ | 14,911 |  |  | $ | 13,950 |  |  | 65.4 | % |  | 64.8 | % |
| EMEA | 2,166 |  |  | 2,109 |  |  | 64.5 | % |  | 64.3 | % |  | 6,307 |  |  | 5,925 |  |  | 64.3 | % |  | 64.0 | % |
| APJC | 1,158 |  |  | 1,247 |  |  | 60.7 | % |  | 61.7 | % |  | 3,467 |  |  | 3,506 |  |  | 59.0 | % |  | 61.3 | % |
| Segment total | 8,370 |  |  | 7,970 |  |  | 64.6 | % |  | 63.9 | % |  | 24,686 |  |  | 23,381 |  |  | 64.2 | % |  | 64.1 | % |
| Unallocated corporate items (1) | (197 | ) |  | (211 | ) |  |  |  |  |  | (594 | ) |  | (697 | ) |  |  |  |  |
| Total | $ | 8,173 |  |  | $ | 7,759 |  |  | 63.1 | % |  | 62.3 | % |  | $ | 24,092 |  |  | $ | 22,684 |  |  | 62.6 | % |  | 62.2 | % |

[0000858877-19-000007:mdna:185]
(1) The unallocated corporate items include the effects of amortization and impairments of acquisition-related intangible assets, share-based compensation expense, significant litigation settlements and other contingencies, charges related to asset impairments and restructurings, and certain other charges. We do not allocate these items to the gross margin for each segment because management does not include such information in measuring the performance of the operating segments.

[0000858877-19-000007:mdna:186]
[same as prior period, unchanged from 0000858877-19-000003:mdna:187]

[0000858877-19-000007:mdna:187]
Three Months Ended April 27, 2019 Compared with Three Months Ended April 28, 2018

[0000858877-19-000007:mdna:188]
We experienced a gross margin percentage increase in our Americas segment due to productivity improvements partially offset by unfavorable impacts from pricing and mix. The unfavorable product mix impact was driven by our products within the Infrastructure Platforms product category.

[0000858877-19-000007:mdna:189]
Product gross margin in our EMEA segment increased due to productivity improvements, partially offset by negative impacts from pricing and mix.

[0000858877-19-000007:mdna:190]
The APJC segment gross margin percentage decrease was due to negative impacts from pricing, partially offset by productivity improvements.

[0000858877-19-000007:mdna:191]
[same as prior period, unchanged from 0000858877-19-000003:mdna:192]

[0000858877-19-000007:mdna:192]
Nine Months Ended April 27, 2019 Compared with Nine Months Ended April 28, 2018

[0000858877-19-000007:mdna:193]
[same as prior period, unchanged from 0000858877-19-000003:mdna:196]

[0000858877-19-000007:mdna:194]
The gross margin percentage increase in our EMEA segment was due to productivity improvements, partially offset by negative impacts from pricing.

[0000858877-19-000007:mdna:195]
The APJC segment gross margin percentage decrease was due to negative impacts from pricing.

[0000858877-19-000007:mdna:196]
[same as prior period, unchanged from 0000858877-19-000003:mdna:193]

[0000858877-19-000007:mdna:197]
[same as prior period, unchanged from 0000858877-19-000003:mdna:194]

[0000858877-19-000007:mdna:198]
[same as prior period, unchanged from 0000858877-19-000003:mdna:199]

[0000858877-19-000007:mdna:199]
[same as prior period, unchanged from 0000858877-19-000003:mdna:200]

[0000858877-19-000007:mdna:200]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 27, 2019 |  | April 28, 2018 |  | Variancein Dollars |  | Variance in Percent |  | April 27, 2019 |  | April 28, 2018 |  | Variancein Dollars |  | Variance in Percent |
| Research and development | $ | 1,659 |  |  | $ | 1,590 |  |  | $ | 69 |  |  | 4 | % |  | $ | 4,824 |  |  | $ | 4,706 |  |  | $ | 118 |  |  | 3 | % |
| Percentage of revenue | 12.8 | % |  | 12.8 | % |  |  |  |  |  | 12.5 | % |  | 12.9 | % |  |  |  |  |
| Sales and marketing | 2,403 |  |  | 2,325 |  |  | 78 |  |  | 3 | % |  | 7,084 |  |  | 6,894 |  |  | 190 |  |  | 3 | % |
| Percentage of revenue | 18.5 | % |  | 18.7 | % |  |  |  |  |  | 18.4 | % |  | 18.9 | % |  |  |  |  |
| General and administrative | 541 |  |  | 561 |  |  | (20 | ) |  | (4 | )% |  | 1,261 |  |  | 1,601 |  |  | (340 | ) |  | (21 | )% |
| Percentage of revenue | 4.2 | % |  | 4.5 | % |  |  |  |  |  | 3.3 | % |  | 4.4 | % |  |  |  |  |
| Total | $ | 4,603 |  |  | $ | 4,476 |  |  | $ | 127 |  |  | 3 | % |  | $ | 13,169 |  |  | $ | 13,201 |  |  | $ | (32 | ) |  | — | % |
| Percentage of revenue | 35.5 | % |  | 35.9 | % |  |  |  |  |  | 34.2 | % |  | 36.2 | % |  |  |  |  |

[0000858877-19-000007:mdna:201]
[same as prior period, unchanged from 0000858877-19-000003:mdna:202]

[0000858877-19-000007:mdna:202]
Three Months Ended April 27, 2019 Compared with Three Months Ended April 28, 2018

[0000858877-19-000007:mdna:203]
R&D expenses increased primarily due to increases in headcount-related expenses, acquisition-related/divestiture costs, contracted services and discretionary spending. These increases were partially offset by lower share-based compensation expense.

[0000858877-19-000007:mdna:204]
[same as prior period, unchanged from 0000858877-19-000003:mdna:205]

[0000858877-19-000007:mdna:205]
Nine Months Ended April 27, 2019 Compared with Nine Months Ended April 28, 2018

[0000858877-19-000007:mdna:206]
R&D expenses increased due to higher headcount-related expenses, contracted services and acquisition-related/divestiture costs. These increases were partially offset by lower share-based compensation expense and discretionary spending.

[0000858877-19-000007:mdna:207]
[same as prior period, unchanged from 0000858877-19-000003:mdna:208]

[0000858877-19-000007:mdna:208]
Three Months Ended April 27, 2019 Compared with Three Months Ended April 28, 2018

[0000858877-19-000007:mdna:209]
Sales and marketing expenses increased due to higher headcount-related expenses and higher discretionary spending, partially offset by lower share-based compensation expense.

[0000858877-19-000007:mdna:210]
Nine Months Ended April 27, 2019 Compared with Nine Months Ended April 28, 2018

[0000858877-19-000007:mdna:211]
[same as prior period, unchanged from 0000858877-19-000003:mdna:212]

[0000858877-19-000007:mdna:212]
[same as prior period, unchanged from 0000858877-19-000003:mdna:216]

[0000858877-19-000007:mdna:213]
Three Months Ended April 27, 2019 Compared with Three Months Ended April 28, 2018

[0000858877-19-000007:mdna:214]
G&A expenses decreased due to lower contracted services and lower acquisition-related/divestiture costs, partially offset by higher discretionary spending and, to a lesser extent, higher headcount-related expenses.

[0000858877-19-000007:mdna:215]
Nine Months Ended April 27, 2019 Compared with Nine Months Ended April 28, 2018

[0000858877-19-000007:mdna:216]
G&A expenses decreased due to a benefit from the $400 million litigation settlement with Arista and lower contracted services, partially offset by higher discretionary spending and higher headcount-related expenses.

[0000858877-19-000007:mdna:217]
63

[0000858877-19-000007:mdna:218]
[same as prior period, unchanged from 0000858877-19-000003:mdna:214]

[0000858877-19-000007:mdna:219]
[same as prior period, unchanged from 0000858877-19-000003:mdna:215]

[0000858877-19-000007:mdna:220]
[same as prior period, unchanged from 0000858877-19-000003:mdna:221]

[0000858877-19-000007:mdna:221]
In the third quarter of fiscal 2019, foreign currency fluctuations, net of hedging, decreased the combined R&D, sales and marketing, and G&A expenses by approximately $78 million, or 1.7%, compared with the third quarter of fiscal 2018.

[0000858877-19-000007:mdna:222]
In the first nine months of fiscal 2019, foreign currency fluctuations, net of hedging, decreased the combined R&D, sales and marketing, and G&A expenses by approximately $180 million, or 1.4%, compared with the first nine months of fiscal 2018.

[0000858877-19-000007:mdna:223]
[same as prior period, unchanged from 0000858877-19-000003:mdna:224]

[0000858877-19-000007:mdna:224]
[same as prior period, unchanged from 0000858877-19-000003:mdna:225]

[0000858877-19-000007:mdna:225]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 27, 2019 |  | April 28, 2018 |  | April 27, 2019 |  | April 28, 2018 |
| Cost of sales—product |  | $ | 22 |  |  | $ | 24 |  |  | $ | 67 |  |  | $ | 70 |  |
| Cost of sales—service |  | 32 |  |  | 33 |  |  | 96 |  |  | 98 |  |
| Share-based compensation expense in cost of sales |  | 54 |  |  | 57 |  |  | 163 |  |  | 168 |  |
| Research and development |  | 135 |  |  | 139 |  |  | 398 |  |  | 409 |  |
| Sales and marketing |  | 124 |  |  | 142 |  |  | 386 |  |  | 412 |  |
| General and administrative |  | 63 |  |  | 61 |  |  | 190 |  |  | 189 |  |
| Restructuring and other charges |  | 3 |  |  | 6 |  |  | 45 |  |  | 24 |  |
| Share-based compensation expense in operating expenses |  | 325 |  |  | 348 |  |  | 1,019 |  |  | 1,034 |  |
| Total share-based compensation expense |  | $ | 379 |  |  | $ | 405 |  |  | $ | 1,182 |  |  | $ | 1,202 |  |

[0000858877-19-000007:mdna:226]
Three Months Ended April 27, 2019 Compared with Three Months Ended April 28, 2018

[0000858877-19-000007:mdna:227]
The decrease in share-based compensation expense was due primarily to higher forfeitures.

[0000858877-19-000007:mdna:228]
Nine Months Ended April 27, 2019 Compared with Nine Months Ended April 28, 2018

[0000858877-19-000007:mdna:229]
The decrease in share-based compensation expense was due primarily to higher forfeitures, partially offset by higher restructuring charges.

[0000858877-19-000007:mdna:230]
[same as prior period, unchanged from 0000858877-19-000003:mdna:231]

[0000858877-19-000007:mdna:231]
[same as prior period, unchanged from 0000858877-19-000003:mdna:232]

[0000858877-19-000007:mdna:232]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 27, 2019 |  | April 28, 2018 |  | April 27, 2019 |  | April 28, 2018 |
| Amortization of purchased intangible assets: |  |  |  |  |  |  |  |  |
| Cost of sales |  | $ | 157 |  |  | $ | 177 |  |  | $ | 464 |  |  | $ | 491 |  |
| Operating expenses |  | 39 |  |  | 67 |  |  | 112 |  |  | 188 |  |
| Total |  | $ | 196 |  |  | $ | 244 |  |  | $ | 576 |  |  | $ | 679 |  |

[0000858877-19-000007:mdna:233]
The decrease in amortization of purchased intangible assets in the third quarter and first nine months of fiscal 2019, as compared with the corresponding periods of fiscal 2018, was due largely to the purchased intangible assets related to the divestiture of SPVSS business on October 28, 2018, partially offset by amortization from our recent acquisitions.

[0000858877-19-000007:mdna:234]
[same as prior period, unchanged from 0000858877-19-000003:mdna:241]

[0000858877-19-000007:mdna:235]
We initiated a restructuring plan during fiscal 2018 in order to realign our organization and enable further investment in key priority areas, with estimated pretax charges of approximately $600 million. In connection with this restructuring plan, we incurred charges of $18 million and $282 million for the third quarter and first nine months of fiscal 2019, respectively, and have incurred cumulative charges of $390 million since inception. We expect this restructuring plan to be substantially completed in the first half of fiscal 2020.

[0000858877-19-000007:mdna:236]
We incurred restructuring and other charges of $82 million and $332 million for the third quarter and first nine months of fiscal 2018, respectively, in connection with restructuring plans initiated during fiscal 2018 and fiscal 2017.

[0000858877-19-000007:mdna:237]
[same as prior period, unchanged from 0000858877-19-000003:mdna:213]

[0000858877-19-000007:mdna:238]
[same as prior period, unchanged from 0000858877-19-000003:mdna:235]

[0000858877-19-000007:mdna:239]
[same as prior period, unchanged from 0000858877-19-000003:mdna:236]

[0000858877-19-000007:mdna:240]
[same as prior period, unchanged from 0000858877-19-000003:mdna:244]

[0000858877-19-000007:mdna:241]
[same as prior period, unchanged from 0000858877-19-000003:mdna:245]

[0000858877-19-000007:mdna:242]
[same as prior period, unchanged from 0000858877-19-000003:mdna:246]

[0000858877-19-000007:mdna:243]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 27, 2019 |  | April 28, 2018 |  | April 27, 2019 |  | April 28, 2018 |
| Operating income |  | $ | 3,513 |  |  | $ | 3,134 |  |  | $ | 10,529 |  |  | $ | 8,963 |  |
| Operating income as a percentage of revenue |  | 27.1 | % |  | 25.1 | % |  | 27.4 | % |  | 24.6 | % |

[0000858877-19-000007:mdna:244]
Three Months Ended April 27, 2019 Compared with Three Months Ended April 28, 2018

[0000858877-19-000007:mdna:245]
Operating income increased by 12%, and as a percentage of revenue operating income increased by 2.0 percentage points. These increases resulted primarily from: a revenue increase, a gross margin percentage increase (driven by productivity improvements and sale of our lower margin SPVSS business during the second quarter of fiscal 2019, partially offset by unfavorable impacts from pricing and mix), and lower restructuring and other charges.

[0000858877-19-000007:mdna:246]
Nine Months Ended April 27, 2019 Compared with Nine Months Ended April 28, 2018

[0000858877-19-000007:mdna:247]
Operating income increased by 17% and as a percentage of revenue operating income increased by 2.8 percentage points. These increases resulted primarily from: a revenue increase, a gross margin percentage increase, a benefit from the $400 million litigation settlement with Arista in the first quarter of fiscal 2019, and lower restructuring and other charges.

[0000858877-19-000007:mdna:248]
[same as prior period, unchanged from 0000858877-19-000003:mdna:252]

[0000858877-19-000007:mdna:249]
[same as prior period, unchanged from 0000858877-19-000003:mdna:253]

[0000858877-19-000007:mdna:250]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 27, 2019 |  | April 28, 2018 |  | Variancein Dollars |  | April 27, 2019 |  | April 28, 2018 |  | Variancein Dollars |
| Interest income |  | $ | 331 |  |  | $ | 380 |  |  | $ | (49 | ) |  | $ | 1,003 |  |  | $ | 1,155 |  |  | $ | (152 | ) |
| Interest expense |  | (211 | ) |  | (237 | ) |  | 26 |  |  | (655 | ) |  | (719 | ) |  | 64 |  |
| Interest income (expense), net |  | $ | 120 |  |  | $ | 143 |  |  | $ | (23 | ) |  | $ | 348 |  |  | $ | 436 |  |  | $ | (88 | ) |

[0000858877-19-000007:mdna:251]
[same as prior period, unchanged from 0000858877-19-000003:mdna:255]

[0000858877-19-000007:mdna:252]
[same as prior period, unchanged from 0000858877-19-000003:mdna:258]

[0000858877-19-000007:mdna:253]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 27, 2019 |  | April 28, 2018 |  | Variancein Dollars |  | April 27, 2019 |  | April 28, 2018 |  | Variancein Dollars |
| Gains (losses) on investments, net: |  |  |  |  |  |  |  |  |  |  |  |  |
| Available-for-sale debt investments |  | $ | (7 | ) |  | $ | (39 | ) |  | $ | 32 |  |  | $ | (18 | ) |  | $ | (131 | ) |  | $ | 113 |  |
| Marketable equity investments |  | (57 | ) |  | 56 |  |  | (113 | ) |  | — |  |  | 239 |  |  | (239 | ) |
| Non-marketable equity and other investments |  | 58 |  |  | (11 | ) |  | 69 |  |  | 59 |  |  | 26 |  |  | 33 |  |
| Net gains (losses) on investments |  | (6 | ) |  | 6 |  |  | (12 | ) |  | 41 |  |  | 134 |  |  | (93 | ) |
| Other gains (losses), net |  | (12 | ) |  | (30 | ) |  | 18 |  |  | (51 | ) |  | (86 | ) |  | 35 |  |
| Other income (loss), net |  | $ | (18 | ) |  | $ | (24 | ) |  | $ | 6 |  |  | $ | (10 | ) |  | $ | 48 |  |  | $ | (58 | ) |

[0000858877-19-000007:mdna:254]
[same as prior period, unchanged from 0000858877-19-000003:mdna:256]

[0000858877-19-000007:mdna:255]
[same as prior period, unchanged from 0000858877-19-000003:mdna:257]

[0000858877-19-000007:mdna:256]
Three Months Ended April 27, 2019 Compared with Three Months Ended April 28, 2018

[0000858877-19-000007:mdna:257]
[same as prior period, unchanged from 0000858877-19-000003:mdna:261]

[0000858877-19-000007:mdna:258]
[same as prior period, unchanged from 0000858877-19-000003:mdna:262]

[0000858877-19-000007:mdna:259]
The change in net gains (losses) on non-marketable equity and other investments was primarily due to higher realized and unrealized gains and lower impairment charges.

[0000858877-19-000007:mdna:260]
The change in other gains (losses), net was primarily driven by higher donation expense in the prior year, partially offset by net unfavorable foreign exchange impacts.

[0000858877-19-000007:mdna:261]
Nine Months Ended April 27, 2019 Compared with Nine Months Ended April 28, 2018

[0000858877-19-000007:mdna:262]
[same as prior period, unchanged from 0000858877-19-000003:mdna:266]

[0000858877-19-000007:mdna:263]
[same as prior period, unchanged from 0000858877-19-000003:mdna:267]

[0000858877-19-000007:mdna:264]
The change in net gains (losses) on non-marketable equity and other investments was primarily due to higher unrealized gains and lower impairment charges partially offset by lower realized gains.

[0000858877-19-000007:mdna:265]
The change in other gains (losses), net was driven by higher donation expense in the prior year, and favorable foreign exchange impacts.

[0000858877-19-000007:mdna:266]
[same as prior period, unchanged from 0000858877-19-000003:mdna:270]

[0000858877-19-000007:mdna:267]
Three Months Ended April 27, 2019 Compared with Three Months Ended April 28, 2018

[0000858877-19-000007:mdna:268]
The provision for income taxes resulted in an effective tax rate of 15.8% for the third quarter of fiscal 2019 compared with 17.3% for the third quarter of fiscal 2018. The decrease in the effective tax rate was primarily due to a decrease in the U.S. federal tax rate from 27% to 21% as the result of enactment of Tax Act, partially offset by a provisional tax adjustment recorded in the third quarter of fiscal 2018 relating to U.S transition tax on accumulated earnings of foreign subsidiaries and re-measurement of net DTA.

[0000858877-19-000007:mdna:269]
[same as prior period, unchanged from 0000858877-19-000003:mdna:273]

[0000858877-19-000007:mdna:270]
Nine Months Ended April 27, 2019 Compared with Nine Months Ended April 28, 2018

[0000858877-19-000007:mdna:271]
The provision for income taxes resulted in an effective tax rate of 13.4% for the first nine months of fiscal 2019 compared with 139.1% for the first nine months of fiscal 2018. The decrease in the effective tax rate was primarily due to the one-time transition tax on accumulated earnings of foreign subsidiaries, foreign withholding tax, and DTA re-measurement recorded during the first nine months of fiscal 2018.

[0000858877-19-000007:mdna:272]
[same as prior period, unchanged from 0000858877-19-000003:mdna:275]

[0000858877-19-000007:mdna:273]
[same as prior period, unchanged from 0000858877-19-000003:mdna:276]

[0000858877-19-000007:mdna:274]
[same as prior period, unchanged from 0000858877-19-000003:mdna:279]

[0000858877-19-000007:mdna:275]
[same as prior period, unchanged from 0000858877-19-000003:mdna:280]

[0000858877-19-000007:mdna:276]
[same as prior period, unchanged from 0000858877-19-000003:mdna:281]

[0000858877-19-000007:mdna:277]
[same as prior period, unchanged from 0000858877-19-000003:mdna:282]

[0000858877-19-000007:mdna:278]
|  | April 27, 2019 |  | July 28, 2018 |  | Increase (Decrease) |
| Cash and cash equivalents | $ | 10,251 |  |  | $ | 8,934 |  |  | $ | 1,317 |  |
| Available-for-sale debt investments | 24,387 |  |  | 37,009 |  |  | (12,622 | ) |
| Marketable equity securities | 5 |  |  | 605 |  |  | (600 | ) |
| Total | $ | 34,643 |  |  | $ | 46,548 |  |  | $ | (11,905 | ) |

[0000858877-19-000007:mdna:279]
The decrease in cash and cash equivalents and investments in the first nine months of fiscal 2019 was primarily driven by cash returned to shareholders in the form of repurchases of common stock of $16.0 billion under the stock repurchase program and cash dividends of $4.5 billion; net cash paid for acquisitions and divestitures of $2.2 billion; a net decrease in debt of $2.0 billion and capital expenditures of $0.7 billion. These uses of cash were partially offset by cash provided by operating activities of $11.9 billion and timing of settlements of investments and other of $1.8 billion.

[0000858877-19-000007:mdna:280]
In addition to cash requirements in the normal course of business, approximately $0.7 billion of the U.S. transition tax on accumulated earnings for foreign subsidiaries is payable in less than one year. Additionally, $4.5 billion of long-term debt and approximately $3.3 billion of commercial paper notes outstanding at April 27, 2019 will mature within the next 12 months from the balance sheet date. See further discussion of liquidity under “Liquidity and Capital Resource Requirements” below.

[0000858877-19-000007:mdna:281]
[same as prior period, unchanged from 0000858877-19-000003:mdna:286]

[0000858877-19-000007:mdna:282]
[same as prior period, unchanged from 0000858877-19-000003:mdna:287]

[0000858877-19-000007:mdna:283]
[same as prior period, unchanged from 0000858877-19-000003:mdna:288]

[0000858877-19-000007:mdna:284]
|  | Nine Months Ended |
|  | April 27, 2019 |  | April 28, 2018 |
| Net cash provided by operating activities | $ | 11,889 |  |  | $ | 9,566 |  |
| Acquisition of property and equipment | (701 | ) |  | (620 | ) |
| Free cash flow | $ | 11,188 |  |  | $ | 8,946 |  |

[0000858877-19-000007:mdna:285]
[same as prior period, unchanged from 0000858877-19-000003:mdna:292]

[0000858877-19-000007:mdna:286]
[same as prior period, unchanged from 0000858877-19-000003:mdna:274]

[0000858877-19-000007:mdna:287]
[same as prior period, unchanged from 0000858877-19-000003:mdna:290]

[0000858877-19-000007:mdna:288]
[same as prior period, unchanged from 0000858877-19-000003:mdna:291]

[0000858877-19-000007:mdna:289]
We consider free cash flow to be a liquidity measure that provides useful information to management and investors because of our intent to return a stated percentage of free cash flow to shareholders in the form of dividends and stock repurchases. We further regard free cash flow as a useful measure because it reflects cash that can be used to, among other things, invest in our business, make strategic acquisitions, repurchase common stock, and pay dividends on our common stock, after deducting capital investments. A limitation of the utility of free cash flow as a measure of financial performance and liquidity is that the free cash flow does not represent the total increase or decrease in our cash balance for the period. In addition, we have other required uses of cash, including repaying the principal of our outstanding indebtedness. Free cash flow is not a measure calculated in accordance with U.S. generally accepted accounting principles and should not be regarded in isolation or as an alternative for net cash provided by operating activities or any other measure calculated in accordance with such principles, and other companies may calculate free cash flow in a different manner than we do.

[0000858877-19-000007:mdna:290]
[same as prior period, unchanged from 0000858877-19-000003:mdna:294]

[0000858877-19-000007:mdna:291]
|  |  | DIVIDENDS |  | STOCK REPURCHASE PROGRAM |  |  |
| Quarter Ended |  | Per Share |  | Amount |  | Shares |  | Weighted-Average Price per Share |  | Amount |  | TOTAL |
| Fiscal 2019 |  |  |  |  |  |  |  |  |  |  |  |  |
| April 27, 2019 |  | $ | 0.35 |  |  | $ | 1,519 |  |  | 116 |  |  | $ | 52.14 |  |  | $ | 6,020 |  |  | $ | 7,539 |  |
| January 26, 2019 |  | $ | 0.33 |  |  | $ | 1,470 |  |  | 111 |  |  | $ | 45.09 |  |  | $ | 5,016 |  |  | $ | 6,486 |  |
| October 27, 2018 |  | $ | 0.33 |  |  | $ | 1,500 |  |  | 109 |  |  | $ | 46.01 |  |  | $ | 5,026 |  |  | $ | 6,526 |  |
| Fiscal 2018 |  |  |  |  |  |  |  |  |  |  |  |  |
| July 28, 2018 |  | $ | 0.33 |  |  | $ | 1,535 |  |  | 138 |  |  | $ | 43.58 |  |  | $ | 6,015 |  |  | $ | 7,550 |  |
| April 28, 2018 |  | $ | 0.33 |  |  | $ | 1,572 |  |  | 140 |  |  | $ | 42.83 |  |  | $ | 6,015 |  |  | $ | 7,587 |  |
| January 27, 2018 |  | $ | 0.29 |  |  | $ | 1,425 |  |  | 103 |  |  | $ | 39.07 |  |  | $ | 4,011 |  |  | $ | 5,436 |  |
| October 28, 2017 |  | $ | 0.29 |  |  | $ | 1,436 |  |  | 51 |  |  | $ | 31.80 |  |  | $ | 1,620 |  |  | $ | 3,056 |  |

[0000858877-19-000007:mdna:292]
On February 13, 2019, our Board of Directors authorized a $15 billion increase to the stock repurchase program. The remaining authorized amount for stock repurchases under this program, including the additional authorization, is approximately $18 billion, with no termination date.

[0000858877-19-000007:mdna:293]
The purchase price for the shares of our stock repurchased is reflected as a reduction to shareholders’ equity. We are required to allocate the purchase price of the repurchased shares as (i) a reduction to retained earnings/increase to accumulated deficit and (ii) a reduction of common stock and additional paid-in capital. As a result of future stock repurchases, we may continue to report an accumulated deficit in future periods in shareholders’ equity.

[0000858877-19-000007:mdna:294]
[same as prior period, unchanged from 0000858877-19-000003:mdna:299]

[0000858877-19-000007:mdna:295]
|  | April 27, 2019 |  | July 28, 2018 |  | Increase (Decrease) |
| Accounts receivable, net | $ | 3,795 |  |  | $ | 5,554 |  |  | $ | (1,759 | ) |

[0000858877-19-000007:mdna:296]
Our accounts receivable net, as of April 27, 2019 decreased by approximately 32%, as compared with the end of fiscal 2018, primarily due to product and service billings being more linear in the third quarter of fiscal 2019 compared with the fourth quarter of fiscal 2018.

[0000858877-19-000007:mdna:297]
[same as prior period, unchanged from 0000858877-19-000003:mdna:305]

[0000858877-19-000007:mdna:298]
|  | April 27, 2019 |  | July 28, 2018 |  | Increase (Decrease) |
| Inventories | $ | 1,513 |  |  | $ | 1,846 |  |  | $ | (333 | ) |

[0000858877-19-000007:mdna:299]
Inventory as of April 27, 2019 decreased by 18% from our inventory balance at the end of fiscal 2018. The decrease in inventory was due primarily to lower deferred cost of sales related to the adoption of ASC 606 in the beginning of our first quarter of fiscal 2019.

[0000858877-19-000007:mdna:300]
68

[0000858877-19-000007:mdna:301]
[same as prior period, unchanged from 0000858877-19-000003:mdna:303]

[0000858877-19-000007:mdna:302]
[same as prior period, unchanged from 0000858877-19-000003:mdna:304]

[0000858877-19-000007:mdna:303]
[same as prior period, unchanged from 0000858877-19-000003:mdna:308]

[0000858877-19-000007:mdna:304]
[same as prior period, unchanged from 0000858877-19-000003:mdna:309]

[0000858877-19-000007:mdna:305]
| Commitments by Period | April 27, 2019 |  | July 28, 2018 |
| Less than 1 year | $ | 4,738 |  |  | $ | 5,407 |  |
| 1 to 3 years | 734 |  |  | 710 |  |
| 3 to 5 years | 90 |  |  | 360 |  |
| Total | $ | 5,562 |  |  | $ | 6,477 |  |

[0000858877-19-000007:mdna:306]
Purchase commitments with contract manufacturers and suppliers decreased 14% compared to the end of fiscal 2018.  On a combined basis, inventories and purchase commitments with contract manufacturers and suppliers decreased by 15% compared with the end of fiscal 2018.

[0000858877-19-000007:mdna:307]
[same as prior period, unchanged from 0000858877-19-000003:mdna:312]

[0000858877-19-000007:mdna:308]
[same as prior period, unchanged from 0000858877-19-000003:mdna:313]

[0000858877-19-000007:mdna:309]
|  | April 27, 2019 |  | July 28, 2018 |  | Increase (Decrease) |
| Lease receivables, net | $ | 2,387 |  |  | $ | 2,576 |  |  | $ | (189 | ) |
| Loan receivables, net | 5,163 |  |  | 4,939 |  |  | 224 |  |
| Financed service contracts, net | 2,341 |  |  | 2,316 |  |  | 25 |  |
| Total, net | $ | 9,891 |  |  | $ | 9,831 |  |  | $ | 60 |  |

[0000858877-19-000007:mdna:310]
Financing Receivables  Our financing arrangements include leases, loans, and financed service contracts. Lease receivables include sales-type and direct-financing leases. Arrangements related to leases are generally collateralized by a security interest in the underlying assets. Our loan receivables include customer financing for purchases of our hardware, software and services and also may include additional funds for other costs associated with network installation and integration of our products and services. We also provide financing to certain qualified customers for long-term service contracts, which primarily relate to technical support services.  The majority of the revenue from these financed service contracts is deferred and is recognized ratably over the period during which the services are performed.  Financing receivables increased by 1%. We expect to continue to expand the use of our financing programs in the near term.

[0000858877-19-000007:mdna:311]
[same as prior period, unchanged from 0000858877-19-000003:mdna:319]

[0000858877-19-000007:mdna:312]
[same as prior period, unchanged from 0000858877-19-000003:mdna:302]

[0000858877-19-000007:mdna:313]
[same as prior period, unchanged from 0000858877-19-000003:mdna:317]

[0000858877-19-000007:mdna:314]
[same as prior period, unchanged from 0000858877-19-000003:mdna:318]

[0000858877-19-000007:mdna:315]
The volume of channel partner financing was $21.7 billion and $20.7 billion for the first nine months of fiscal 2019 and 2018, respectively. These financing arrangements facilitate the working capital requirements of the channel partners, and in some cases, we guarantee a portion of these arrangements. The balance of the channel partner financing subject to guarantees was $1.3 billion and $1.0 billion as of April 27, 2019 and July 28, 2018, respectively. We could be called upon to make payments under these guarantees in the event of nonpayment by the channel partners or end-user customers. Historically, our payments under these arrangements have been immaterial. Where we provide a guarantee, we defer the revenue associated with the channel partner and end-user financing arrangement in accordance with revenue recognition policies, or we record a liability for the fair value of the guarantees. In either case, the deferred revenue is recognized as revenue when the guarantee is removed. As of April 27, 2019, the total maximum potential future payments related to these guarantees was approximately $240 million, of which approximately $81 million was recorded as deferred revenue.

[0000858877-19-000007:mdna:316]
[same as prior period, unchanged from 0000858877-19-000003:mdna:321]

[0000858877-19-000007:mdna:317]
[same as prior period, unchanged from 0000858877-19-000003:mdna:322]

[0000858877-19-000007:mdna:318]
|  | Maturity Date |  | April 27, 2019 |  | July 28, 2018 |
| Senior notes: |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | $ | — |  |  | $ | 500 |  |
| Three-month LIBOR plus 0.34% | September 20, 2019 |  | 500 |  |  | 500 |  |
| Fixed-rate notes: |  |  |  |  |  |
| 4.95% | February 15, 2019 |  | — |  |  | 2,000 |  |
| 1.60% | February 28, 2019 |  | — |  |  | 1,000 |  |
| 2.125% | March 1, 2019 |  | — |  |  | 1,750 |  |
| 1.40% | September 20, 2019 |  | 1,500 |  |  | 1,500 |  |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 2,500 |  |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 1,500 |  |
| 2.20% | February 28, 2021 |  | 2,500 |  |  | 2,500 |  |
| 2.90% | March 4, 2021 |  | 500 |  |  | 500 |  |
| 1.85% | September 20, 2021 |  | 2,000 |  |  | 2,000 |  |
| 3.00% | June 15, 2022 |  | 500 |  |  | 500 |  |
| 2.60% | February 28, 2023 |  | 500 |  |  | 500 |  |
| 2.20% | September 20, 2023 |  | 750 |  |  | 750 |  |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1,000 |  |
| 3.50% | June 15, 2025 |  | 500 |  |  | 500 |  |
| 2.95% | February 28, 2026 |  | 750 |  |  | 750 |  |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 1,500 |  |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 2,000 |  |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 2,000 |  |
| Total |  |  | $ | 20,500 |  |  | $ | 25,750 |  |

[0000858877-19-000007:mdna:319]
Interest is payable semiannually on each class of the senior fixed-rate notes, each of which is redeemable by us at any time, subject to a make-whole premium. Interest is payable quarterly on the floating-rate notes. We were in compliance with all debt covenants as of April 27, 2019.

[0000858877-19-000007:mdna:320]
Commercial Paper  We have a short-term debt financing program in which up to $10.0 billion is available through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes.  We had $3.3 billion in commercial paper notes outstanding as of April 27, 2019 and no commercial paper notes outstanding as of July 28, 2018.

[0000858877-19-000007:mdna:321]
[same as prior period, unchanged from 0000858877-19-000003:mdna:316]

[0000858877-19-000007:mdna:322]
[same as prior period, unchanged from 0000858877-19-000003:mdna:326]

[0000858877-19-000007:mdna:323]
[same as prior period, unchanged from 0000858877-19-000003:mdna:327]

[0000858877-19-000007:mdna:324]
Credit Facility On May 15, 2015, we entered into a credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 15, 2020. Any advances under the credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (i) the highest of (a) the Federal Funds rate plus 0.50%, (b) Bank of America’s “prime rate” as announced from time to time, or (c) LIBOR, or a comparable or successor rate that is approved by the Administrative Agent (“Eurocurrency Rate”), for an interest period of one month plus 1.00%, or (ii) the Eurocurrency Rate, plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the Eurocurrency Rate be less than zero. We may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and/or extend the expiration date of the credit facility up to May 15, 2022. This credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio as defined in the agreement.  As of April 27, 2019, we were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under the credit facility.

[0000858877-19-000007:mdna:325]
[same as prior period, unchanged from 0000858877-19-000003:mdna:330]

[0000858877-19-000007:mdna:326]
|  | April 27, 2019 |  | July 28, 2018 |  | Increase (Decrease) |
| Service | $ | 11,297 |  |  | $ | 11,431 |  |  | $ | (134 | ) |
| Product | 6,159 |  |  | 8,254 |  |  | (2,095 | ) |
| Total | $ | 17,456 |  |  | $ | 19,685 |  |  | $ | (2,229 | ) |
| Reported as: |  |  |  |  |  |
| Current | $ | 10,117 |  |  | $ | 11,490 |  |  | $ | (1,373 | ) |
| Noncurrent | 7,339 |  |  | 8,195 |  |  | (856 | ) |
| Total | $ | 17,456 |  |  | $ | 19,685 |  |  | $ | (2,229 | ) |

[0000858877-19-000007:mdna:327]
Deferred revenue decreased primarily due to the adoption of ASC 606 in the beginning of our first quarter of fiscal 2019. Of the total deferred revenue decrease related to ASC 606 of $2.8 billion, $2.6 billion relates to deferred product revenue and $0.2 billion relates to deferred service revenue. Of the adjustment to deferred product revenue, $1.3 billion related to our recurring software and subscription offers, $0.6 billion related to two-tier distribution, and the remainder related to non-recurring software and other adjustments.

[0000858877-19-000007:mdna:328]
[same as prior period, unchanged from 0000858877-19-000003:mdna:333]

[0000858877-19-000007:mdna:329]
[same as prior period, unchanged from 0000858877-19-000003:mdna:334]

[0000858877-19-000007:mdna:330]
We lease office space in many U.S. locations. Outside the United States, larger leased sites include sites in Australia, Belgium, Canada, China, Germany, India, Japan, Mexico, Poland and the United Kingdom. We also lease equipment and vehicles. The future minimum lease payments under all of our noncancelable operating leases with an initial term in excess of one year as of April 27, 2019 were $1.2 billion.

[0000858877-19-000007:mdna:331]
[same as prior period, unchanged from 0000858877-19-000003:mdna:336]

[0000858877-19-000007:mdna:332]
The income tax payable outstanding as of April 27, 2019 for the U.S. transition tax on accumulated earnings for foreign subsidiaries is $7.4 billion. Approximately $0.7 billion is payable in less than one year; $1.3 billion is payable between 1 to 3 years; $1.9 billion is payable between 3 to 5 years; and the remaining $3.5 billion is payable in more than 5 years. See Note 17 to the Consolidated Financial Statements.

[0000858877-19-000007:mdna:333]
[same as prior period, unchanged from 0000858877-19-000003:mdna:341]

[0000858877-19-000007:mdna:334]
[same as prior period, unchanged from 0000858877-19-000003:mdna:342]

[0000858877-19-000007:mdna:335]
Other Funding Commitments  We also have certain funding commitments primarily related to our non-marketable equity and other investments, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $345 million as of April 27, 2019, compared with $223 million as of July 28, 2018.

[0000858877-19-000007:mdna:336]
[same as prior period, unchanged from 0000858877-19-000003:mdna:339]

[0000858877-19-000007:mdna:337]
[same as prior period, unchanged from 0000858877-19-000003:mdna:340]

[0000858877-19-000007:mdna:338]
[same as prior period, unchanged from 0000858877-19-000003:mdna:344]

[0000858877-19-000007:mdna:339]
We consider our investments in unconsolidated variable interest entities to be off-balance sheet arrangements. In the ordinary course of business, we have non-marketable equity and other investments and provide financing to certain customers. Certain of these investments are considered to be variable interest entities. We evaluate on an ongoing basis our non-marketable equity and other investments and customer financings, and we have determined that as of April 27, 2019 there were no material unconsolidated variable interest entities.

[0000858877-19-000007:mdna:340]
[same as prior period, unchanged from 0000858877-19-000003:mdna:346]

[0000858877-19-000007:mdna:341]
[same as prior period, unchanged from 0000858877-19-000003:mdna:347]

[0000858877-19-000007:mdna:342]
[same as prior period, unchanged from 0000858877-19-000003:mdna:348]

[0000858877-19-000007:mdna:343]
[same as prior period, unchanged from 0000858877-19-000003:mdna:349]
