# CSCO 8-K — 0001193125-19-147994 filed 2019-05-15

## item codes, every 8-K on or before 2019-05-21

- 2019-05-15 0001193125-19-147994 — 2.02, 9.01
- 2019-03-07 0001193125-19-067296 — 8.01
- 2019-02-13 0001193125-19-037964 — 2.02, 9.01
- 2018-12-13 0001193125-18-348864 — 5.02, 5.07, 9.01
- 2018-11-14 0001193125-18-326716 — 2.02, 9.01
- 2018-10-18 0001193125-18-301990 — 5.02
- 2018-09-12 0001193125-18-271829 — 5.02, 9.01
- 2018-08-15 0001193125-18-249746 — 2.02, 9.01
- 2018-08-06 0001193125-18-239193 — 8.01
- 2018-06-25 0001193125-18-202535 — 8.01
- 2018-06-07 0001193125-18-186858 — 8.01
- 2018-05-16 0001193125-18-165248 — 2.02, 9.01
- 2018-05-01 0001193125-18-146602 — 5.02
- 2018-04-12 0001193125-18-115646 — 5.02
- 2018-02-14 0001193125-18-045716 — 2.02, 9.01
- 2017-12-14 0001193125-17-368869 — 5.02
- 2017-12-12 0001193125-17-367515 — 5.02, 5.07, 9.01
- 2017-11-15 0001193125-17-344129 — 2.02, 9.01
- 2017-10-23 0001193125-17-316071 — 8.01, 9.01
- 2017-09-18 0001193125-17-286857 — 5.02, 9.01
- 2017-09-01 0001193125-17-275671 — 8.01
- 2017-08-16 0001193125-17-259825 — 2.02
- 2017-06-23 0001193125-17-211825 — 8.01
- 2017-06-15 0001193125-17-204753 — 8.01
- 2017-05-17 0001193125-17-173404 — 2.02
- 2017-03-31 0001193125-17-106620 — 1.01, 2.03, 9.01
- 2017-03-29 0001193125-17-101783 — 8.01
- 2017-03-13 0001193125-17-080485 — 5.02
- 2017-02-15 0001193125-17-045265 — 2.02
- 2016-12-22 0001193125-16-802182 — 8.01
- 2016-12-13 0001193125-16-791877 — 5.07
- 2016-11-16 0001193125-16-769785 — 2.02
- 2016-11-03 0001193125-16-758911 — 5.02, 9.01
- 2016-10-17 0001193125-16-739833 — 5.02
- 2016-09-21 0001193125-16-716006 — 8.01
- 2016-09-20 0001193125-16-714189 — 8.01, 9.01
- 2016-09-16 0001193125-16-712320 — 8.01
- 2016-09-15 0001193125-16-711098 — 1.01, 9.01
- 2016-09-13 0001193125-16-708007 — 8.01, 9.01
- 2016-09-06 0001193125-16-702020 — 8.01
- 2016-08-17 0001193125-16-684126 — 2.02, 2.05
- 2016-07-29 0001193125-16-664620 — 5.03, 9.01
- 2016-06-27 0001193125-16-633145 — 8.01
- 2016-06-23 0001193125-16-630146 — 8.01
- 2016-06-07 0001193125-16-615321 — 5.02, 9.01
- 2016-05-18 0001193125-16-594463 — 2.02
- 2016-03-24 0001193125-16-516953 — 8.01
- 2016-02-29 0001193125-16-483780 — 8.01, 9.01
- 2016-02-25 0001193125-16-478442 — 8.01
- 2016-02-24 0001193125-16-474071 — 1.01, 9.01
- 2016-02-22 0001193125-16-470856 — 8.01, 9.01
- 2016-02-10 0001193125-16-457586 — 2.02
- 2016-01-28 0001193125-16-441933 — 5.02
- 2015-12-08 0001193125-15-397797 — 8.01
- 2015-11-20 0001193125-15-383743 — 5.07
- 2015-11-12 0001193125-15-375655 — 2.02
- 2015-09-21 0001193125-15-324465 — 8.01
- 2015-09-17 0001193125-15-322456 — 8.01
- 2015-09-14 0001193125-15-319489 — 8.01
- 2015-08-28 0001193125-15-306843 — 8.01
- 2015-08-12 0001193125-15-288099 — 2.02
- 2015-07-29 0001193125-15-268359 — 5.02 — amendment of 0001193125-15-169227
- 2015-06-18 0001193125-15-227387 — 8.01, 9.01
- 2015-06-12 0001193125-15-221863 — 1.01, 9.01
- 2015-06-10 0001193125-15-218734 — 8.01, 9.01
- 2015-06-01 0001193125-15-209142 — 5.02, 9.01
- 2015-05-13 0001193125-15-185905 — 2.02
- 2015-05-04 0001193125-15-169227 — 5.02
- 2015-03-24 0001193125-15-103369 — 8.01
- 2015-03-19 0001193125-15-098638 — 8.01
- 2015-02-11 0001193125-15-044175 — 2.02
- 2014-12-19 0001193125-14-448754 — 8.01
- 2014-12-18 0001193125-14-447039 — 8.01
- 2014-11-24 0001193125-14-423591 — 5.02, 5.07, 9.01
- 2014-11-14 0001193125-14-413384 — 5.02
- 2014-11-12 0001193125-14-409258 — 2.02
- 2014-09-25 0001193125-14-353210 — 8.01
- 2014-09-12 0001193125-14-340480 — 5.02
- 2014-08-14 0001193125-14-308733 — 2.05
- 2014-08-13 0001193125-14-308403 — 2.02
- 2014-07-31 0001193125-14-289683 — 5.02
- 2014-06-25 0001193125-14-249157 — 8.01
- 2014-05-14 0001193125-14-199056 — 2.02
- 2014-03-26 0001193125-14-116588 — 8.01
- 2014-03-11 0001193125-14-093805 — 8.01
- 2014-03-03 0001193125-14-079163 — 1.01, 8.01, 9.01
- 2014-02-26 0001193125-14-069912 — 1.01, 9.01
- 2014-02-12 0001193125-14-048150 — 2.02
- 2013-12-23 0001193125-13-483099 — 8.01
- 2013-12-04 0001193125-13-462216 — 8.01
- 2013-11-20 0001193125-13-448477 — 5.02, 5.07, 9.01
- 2013-11-13 0001193125-13-440194 — 2.02
- 2013-08-15 0001193125-13-335218 — 2.05
- 2013-08-14 0001193125-13-334648 — 2.02
- 2013-07-23 0001193125-13-298129 — 8.01, 9.01
- 2013-06-24 0001193125-13-269064 — 8.01
- 2013-06-12 0001193125-13-256194 — 8.01
- 2013-06-07 0001193125-13-250920 — 8.01
- 2013-05-15 0001193125-13-222377 — 2.02
- 2013-03-26 0001193125-13-127015 — 8.01
- 2013-02-13 0001193125-13-055377 — 2.02
- 2013-02-01 0001193125-13-034682 — 5.02
- 2013-01-08 0001193125-13-006886 — 5.02, 9.01
- 2012-12-21 0001193125-12-513130 — 8.01
- 2012-12-19 0001193125-12-508424 — 8.01
- 2012-11-16 0001193125-12-474089 — 5.02, 5.07, 9.01
- 2012-11-13 0001193125-12-467422 — 2.02
- 2012-10-04 0001193125-12-415386 — 5.02, 5.03, 9.01
- 2012-09-19 0001193125-12-396875 — 5.02, 8.01
- 2012-08-15 0001193125-12-357479 — 2.02
- 2012-08-02 0001193125-12-332045 — 5.02
- 2012-06-27 0001193125-12-285742 — 8.01
- 2012-06-13 0001193125-12-269642 — 8.01
- 2012-05-09 0001193125-12-222045 — 2.02
- 2012-03-27 0001193125-12-134384 — 8.01
- 2012-03-15 0001193125-12-117538 — 8.01, 9.01
- 2012-02-17 0001193125-12-067542 — 1.01, 1.02, 2.03, 9.01
- 2012-02-08 0001193125-12-046545 — 2.02
- 2011-12-16 0001193125-11-343995 — 8.01
- 2011-12-08 0001193125-11-335127 — 5.02, 5.07, 9.01
- 2011-11-09 0001193125-11-304587 — 2.02
- 2011-09-29 0001193125-11-260065 — 8.01
- 2011-09-20 0001193125-11-252379 — 5.02, 9.01
- 2011-08-24 0001193125-11-231015 — 8.01
- 2011-08-10 0001193125-11-218133 — 2.02
- 2011-07-18 0001193125-11-190246 — 2.05
- 2011-06-22 0001193125-11-170849 — 8.01
- 2011-05-11 0001193125-11-135913 — 2.02
- 2011-03-28 0001193125-11-079927 — 8.01
- 2011-03-22 0001193125-11-073802 — 5.02 — amendment of 0001193125-11-043592
- 2011-03-18 0001193125-11-071279 — 8.01, 9.01
- 2011-03-16 0001193125-11-067985 — 1.01, 5.02, 8.01, 9.01
- 2011-03-15 0001193125-11-067331 — 1.01, 9.01
- 2011-03-09 0001193125-11-060123 — 8.01, 9.01
- 2011-02-23 0001193125-11-043592 — 5.02
- 2011-02-09 0001193125-11-028987 — 2.02
- 2011-01-31 0001193125-11-019101 — 1.01, 2.03
- 2010-12-17 0001193125-10-283392 — 8.01
- 2010-11-19 0001193125-10-265377 — 5.07
- 2010-11-10 0001193125-10-256001 — 2.02
- 2010-09-22 0001193125-10-214707 — 8.01
- 2010-09-16 0001193125-10-211456 — 7.01
- 2010-08-11 0001193125-10-186042 — 2.02
- 2010-06-29 0001193125-10-149956 — 8.01
- 2010-05-12 0001193125-10-117509 — 2.02
- 2010-02-17 0001193125-10-033290 — 5.02, 8.01, 9.01
- 2010-02-03 0001193125-10-020775 — 2.02
- 2009-11-25 0001193125-09-242589 — 8.01
- 2009-11-17 0001193125-09-236335 — 1.01, 8.01, 9.01
- 2009-11-13 0001193125-09-234405 — 1.01, 2.03, 9.01
- 2009-11-13 0001193125-09-234397 — 5.02 — amendment of 0001193125-09-189511
- 2009-11-12 0001193125-09-232971 — 5.02, 7.01, 9.01
- 2009-11-09 0001193125-09-228541 — 8.01, 9.01
- 2009-11-04 0001193125-09-223763 — 2.02
- 2009-10-14 0001193125-09-207912 — 8.01, 9.01
- 2009-10-05 0001193125-09-203556 — 8.01
- 2009-09-10 0001193125-09-189511 — 5.02
- 2009-09-04 0001193125-09-187835 — 5.02
- 2009-08-05 0001193125-09-165404 — 2.02
- 2009-07-27 0001193125-09-155861 — 5.02
- 2009-05-29 0001193125-09-121672 — 8.01
- 2009-05-06 0001193125-09-101570 — 2.02
- 2009-02-26 0001193125-09-038162 — 5.02
- 2009-02-17 0001193125-09-030546 — 1.01, 8.01, 9.01
- 2009-02-13 0001193125-09-029295 — 1.01, 2.03, 9.01
- 2009-02-04 0001193125-09-018793 — 2.02
- 2008-11-05 0001193125-08-225857 — 2.02
- 2008-09-11 0001193125-08-194695 — 7.01
- 2008-08-05 0001193125-08-166496 — 2.02
- 2008-06-20 0001193125-08-137504 — 8.01
- 2008-05-06 0001193125-08-104089 — 2.02
- 2008-03-21 0001193125-08-062838 — 8.01
- 2008-02-06 0001193125-08-021681 — 2.02
- 2008-01-23 0001193125-08-010589 — 5.02
- 2008-01-04 0001193125-08-001680 — 5.02, 9.01
- 2007-12-21 0001193125-07-269613 — 5.02
- 2007-11-19 0001193125-07-250345 — 5.02 — amendment of 0001193125-07-009285
- 2007-11-19 0001193125-07-250343 — 5.02, 9.01
- 2007-11-07 0001193125-07-238464 — 2.02
- 2007-09-24 0001193125-07-206279 — 8.01
- 2007-09-20 0001193125-07-204616 — 5.02, 7.01
- 2007-09-07 0001193125-07-197514 — 8.01
- 2007-08-17 0001193125-07-185320 — 1.01, 2.03, 9.01
- 2007-08-08 0001193125-07-174077 — 5.02
- 2007-08-07 0001193125-07-173689 — 2.02
- 2007-08-01 0001193125-07-168143 — 5.02
- 2007-05-15 0001193125-07-115800 — 8.01
- 2007-05-08 0001193125-07-106059 — 2.02
- 2007-03-23 0001193125-07-063033 — 5.02, 5.03, 8.01, 9.01
- 2007-03-21 0001193125-07-060631 — 1.01, 9.01
- 2007-02-06 0001193125-07-021349 — 2.02
- 2007-01-19 0001193125-07-009285 — 5.02
- 2006-12-22 0001193125-06-259241 — 8.01
- 2006-11-16 0001193125-06-237260 — 5.03, 8.01, 9.01
- 2006-11-08 0001193125-06-228341 — 2.02
- 2006-09-21 0001193125-06-194890 — 1.01, 7.01
- 2006-09-20 0001193125-06-194063 — 1.01
- 2006-09-15 0001193125-06-191845 — 5.02
- 2006-08-18 0001193125-06-176193 — 5.02
- 2006-08-08 0001193125-06-165719 — 2.02
- 2006-07-31 0001193125-06-157106 — 1.01, 9.01
- 2006-07-31 0001193125-06-157102 — 5.02 — amendment of 0001193125-06-017426
- 2006-06-08 0001193125-06-126879 — 5.02
- 2006-05-18 0001193125-06-115516 — 8.01
- 2006-05-12 0001193125-06-110924 — 9.01 — amendment of 0001193125-06-044013
- 2006-05-09 0001193125-06-105419 — 2.02
- 2006-03-29 0001193125-06-066990 — 1.01
- 2006-03-02 0001193125-06-044013 — 1.01, 2.01, 9.01
- 2006-02-28 0001193125-06-041452 — 1.01
- 2006-02-22 0001193125-06-036759 — 8.01
- 2006-02-22 0001193125-06-036433 — 1.01, 8.01, 9.01
- 2006-02-21 0001193125-06-035865 — 1.01, 2.03, 9.01
- 2006-02-10 0001193125-06-026218 — 8.01, 9.01
- 2006-02-07 0001193125-06-022234 — 2.02
- 2006-02-01 0001193125-06-017426 — 5.02
- 2005-11-18 0001193125-05-229535 — 1.01, 9.01
- 2005-11-16 0001193125-05-227987 — 1.01, 9.01
- 2005-11-16 0001193125-05-227983 — 5.02 — amendment of 0001193125-05-008843
- 2005-11-09 0001193125-05-221610 — 2.02
- 2005-09-29 0001193125-05-194217 — 7.01
- 2005-09-27 0001193125-05-192353 — 8.01
- 2005-09-21 0001193125-05-189234 — 1.01, 9.01
- 2005-09-19 0001193125-05-187646 — 8.01
- 2005-09-09 0001193125-05-183273 — 8.01
- 2005-09-08 0001193125-05-182307 — 1.01
- 2005-08-09 0001193125-05-162626 — 2.02
- 2005-07-15 0001193125-05-142738 — 8.01
- 2005-05-10 0001193125-05-102797 — 2.02
- 2005-03-30 0001193125-05-065123 — 1.01, 3.03, 9.01
- 2005-03-04 0001193125-05-042778 — 1.01
- 2005-02-08 0001193125-05-022181 — 2.02
- 2005-01-20 0001193125-05-008843 — 5.02
- 2004-12-23 0001193125-04-219331 — 8.01
- 2004-11-09 0001193125-04-191303 — 2.02
- 2004-08-23 0001193125-04-145198 — 1.01, 7.01
- 2004-08-19 0001193125-04-143859 — 5
- 2004-08-10 0001193125-04-136865 — 12
- 2004-05-11 0001193125-04-084721 — 12
- 2004-02-03 0001193125-04-013750 — 12
- 2003-11-05 0001193125-03-073418 — 12
- 2003-09-02 0001193125-03-044521 — 9
- 2003-08-05 0001193125-03-029223 — 12, 7
- 2003-07-18 0001193125-03-021155 — 5, 7
- 2003-06-05 0001012870-03-002949 — 5
- 2003-05-06 0000891618-03-002315 — 7, 9
- 2003-04-17 0000891618-03-001894 — 5, 7
- 2003-04-11 0000891618-03-001791 — 9
- 2003-03-20 0000891618-03-001326 — 5, 7
- 2003-02-04 0000891618-03-000518 — 7, 9
- 2003-01-28 0000891618-03-000271 — 5, 7
- 2002-12-27 0000891618-02-005686 — 5, 7
- 2002-10-23 0000891618-02-004715 — 5, 7
- 2002-10-11 0000891618-02-004620 — 5, 7
- 2002-09-18 0000891618-02-004352 — 5, 7
- 2002-08-20 0000891618-02-004001 — 5, 7
- 2002-08-05 0000891618-02-003498 — 5, 7
- 2002-07-03 0000891618-02-003099 — 5, 7
- 2002-05-14 0000891618-02-002407 — 5, 7
- 2002-02-05 0000891618-02-000412 — 5, 7
- 2001-09-28 0001095811-01-505261 — 5, 7
- 2001-09-14 0001095811-01-504917 — 5, 7
- 2001-08-24 0001095811-01-504581 — 5, 7
- 2001-07-30 0001095811-01-503468 — 5, 7
- 2001-07-12 0000891618-01-501567 — 5, 7
- 2001-05-11 0000891618-01-500638 — 5, 7
- 2001-02-27 0000891618-01-500076 — 5, 7
- 2001-02-20 0001095811-01-001530 — 5, 7
- 2001-02-08 0001095811-01-000848 — 5, 7
- 2001-02-07 0001095811-01-000768 — 5
- 2000-12-27 0001095811-00-005511 — 5
- 2000-12-21 0001095811-00-005427 — 5
- 2000-12-19 0001095811-00-005368 — 5
- 2000-11-15 0001095811-00-004830 — 5
- 2000-11-15 0001095811-00-004824 — 5
- 2000-11-13 0000891618-00-005023 — 5
- 2000-11-07 0001095811-00-004387 — 5, 7
- 2000-11-06 0001095811-00-004318 — 5
- 2000-09-29 0000891618-00-004739 — 5, 7
- 2000-09-28 0000891618-00-004722 — 5
- 2000-09-26 0001095811-00-003573 — 5
- 2000-09-15 0001095811-00-003413 — 5
- 2000-09-07 0001095811-00-003229 — 5
- 2000-08-15 0000891618-00-004430 — 5
- 2000-08-04 0001095811-00-002304 — 5, 7 — amendment, the index does not say of what
- 2000-07-28 0000891618-00-004132 — 5, 7
- 2000-06-29 0000891618-00-003637 — 5
- 2000-06-07 0000891618-00-003209 — 5
- 2000-05-26 0000891618-00-003054 — 5
- 2000-05-18 0000891618-00-002975 — 5, 7
- 2000-05-15 0000891618-00-002808 — 5, 7
- 2000-05-03 0000891618-00-002473 — 5
- 2000-04-03 0000891618-00-001936 — 5
- 2000-03-28 0000891618-00-001763 — 5
- 2000-03-27 0000891618-00-001722 — 5, 7
- 2000-03-16 0000891618-00-001512 — 5
- 2000-02-17 0000891618-00-001024 — 5, 7
- 2000-02-03 0000891618-00-000468 — 7 — amendment of 0000891618-99-005685
- 1999-12-22 0000891618-99-005792 — 5, 7
- 1999-12-15 0000891618-99-005685 — 5, 7
- 1999-11-17 0000891618-99-005313 — 5, 7
- 1999-11-04 0000891618-99-004862 — 5, 7
- 1999-10-20 0000891618-99-004625 — 5, 7
- 1999-09-27 0000891618-99-004333 — 5, 7
- 1999-08-26 0000891618-99-003978 — 5, 7
- 1999-08-13 0000891618-99-003764 — 5, 7 — amendment of 0000891618-99-003749
- 1999-08-13 0000891618-99-003749 — 5, 7
- 1999-07-02 0000891618-99-002980 — 5, 7
- 1999-05-14 0000891618-99-002221 — 5
- 1998-11-20 0000891618-98-005074 — 5, 7
- 1998-11-20 0000891618-98-005073 — 5, 7
- 1998-10-13 0000891618-98-004462 — 5, 7
- 1998-07-09 0000891618-98-003245 — 5, 7
- 1998-06-11 0000891618-98-002832 — 5, 7
- 1998-05-15 0000891618-98-002457 — 5, 7
- 1998-04-29 0000891618-98-001996 — 5
- 1998-02-11 0000891618-98-000584 — 5, 7
- 1997-09-09 0000891618-97-003723 — 5, 7
- 1997-08-22 0000891618-97-003559 — 5, 7
- 1997-07-01 0000891618-97-002807 — 5, 7
- 1997-01-22 0000891618-97-000120 — 5, 7
- 1996-10-15 0000891618-96-002283 — 5, 7 — amendment of 0000891618-96-002217
- 1996-10-01 0000891618-96-002217 — 5, 7
- 1996-07-23 0000891618-96-001305 — 2, 7
- 1996-04-26 0000891618-96-000253 — 2
- 1996-04-02 0000898430-96-001187 — 2, 7
- 1995-12-06 0000891618-95-000728 — 2, 7
- 1995-12-06 0000891618-95-000727 — 2, 7

## late-filing notifications on or before 2019-05-21

- none on or before 2019-05-21

## item 2.02 — earnings release, exhibit 99.1

[0001193125-19-147994:8k_2_02:1]
EX-99.1
2
d727489dex991.htm
EX-99.1

[0001193125-19-147994:8k_2_02:2]
EX-99.1

[0001193125-19-147994:8k_2_02:3]
Exhibit 99.1

[0001193125-19-147994:8k_2_02:4]
| Press Contact: |  |  |  | Investor Relations Contact: |
| Robyn Blum |  |  |  | Marilyn Mora |
| Cisco |  |  |  | Cisco |
| 1 (408) 930-8548 |  |  |  | 1 (408) 527-7452 |
| rojenkin@cisco.com |  |  |  | marilmor@cisco.com |

[0001193125-19-147994:8k_2_02:5]
CISCO REPORTS THIRD QUARTER EARNINGS

[0001193125-19-147994:8k_2_02:6]
|  | • |  | Q3 Results: |

[0001193125-19-147994:8k_2_02:7]
|  | • |  | Revenue: $13.0 billion |

[0001193125-19-147994:8k_2_02:8]
|  | • |  | Growth of 6% year over year (normalized to exclude the divested SPVSS business for Q3 FY 2018) |

[0001193125-19-147994:8k_2_02:9]
|  | • |  | Earnings per Share: GAAP: $0.69; Non-GAAP: $0.78 |

[0001193125-19-147994:8k_2_02:10]
|  | • |  | Non-GAAP EPS increased 18% year over year |

[0001193125-19-147994:8k_2_02:11]
|  | • |  | Q4 Guidance (normalized to exclude the divested SPVSS business for Q4 FY 2018): |

[0001193125-19-147994:8k_2_02:12]
|  | • |  | Revenue: 4.5% to 6.5% growth year over year |

[0001193125-19-147994:8k_2_02:13]
|  | • |  | Earnings per Share: GAAP: $0.66 to $0.71; Non-GAAP: $0.80 to $0.82 |

[0001193125-19-147994:8k_2_02:14]
SAN JOSE, Calif. — May 15, 2019 — Cisco today reported third quarter results for the period ended April 27, 2019.
Cisco reported third quarter revenue of $13.0 billion, net income on a generally accepted accounting principles (GAAP) basis of $3.0 billion or $0.69 per share, and non-GAAP net income of
$3.5 billion or $0.78 per share.

[0001193125-19-147994:8k_2_02:15]
As previously disclosed, Cisco completed the divestiture of the Service Provider Video Software Solutions (SPVSS)
business in the second quarter of fiscal 2019 on October 28, 2018. Revenue, non-GAAP financial information, and Q4 FY 2019 guidance have been normalized to exclude the SPVSS business from prior periods
for comparative purposes.

[0001193125-19-147994:8k_2_02:16]
“Our strong performance in the quarter was across the business, reflecting our customers’ confidence in our strategy,
business model and market-leading portfolio,” said Chuck Robbins, chairman and CEO of Cisco. “Technology is at the heart of our customers’ strategies and we are building the technology to help them achieve their business
objectives.”

[0001193125-19-147994:8k_2_02:17]
GAAP Results

[0001193125-19-147994:8k_2_02:18]
|  |  | Q3 FY 2019 |  |  | Q3 FY 2018 |  |  | Vs. Q3 FY 2018 |  |
| Revenue (including SPVSS business for all periods) |  | $ | 13.0 billion |  |  | $ | 12.5 billion |  |  |  | 4 | % |
| Revenue (excluding SPVSS business for all periods) |  | $ | 13.0 billion |  |  | $ | 12.2 billion |  |  |  | 6 | % |
| Net Income |  | $ | 3.0 billion |  |  | $ | 2.7 billion |  |  |  | 13 | % |
| Diluted Earnings per Share (EPS) |  | $ | 0.69 |  |  | $ | 0.56 |  |  |  | 23 | % |

[0001193125-19-147994:8k_2_02:19]
Non-GAAP Results

[0001193125-19-147994:8k_2_02:20]
|  |  | Q3 FY 2019 |  |  | Q3 FY 2018 |  |  | Vs. Q3 FY 2018 |  |
| Net Income (excluding SPVSS business for all periods) |  | $ | 3.5 billion |  |  | $ | 3.2 billion |  |  |  | 8 | % |
| EPS (excluding SPVSS business for all periods) |  | $ | 0.78 |  |  | $ | 0.66 |  |  |  | 18 | % |

[0001193125-19-147994:8k_2_02:21]
Reconciliations between net income, EPS, and other measures on a GAAP and non-GAAP
basis are provided in the tables located in the section entitled “Reconciliations of GAAP to non-GAAP Measures.”

[0001193125-19-147994:8k_2_02:22]
“We executed well in Q3, delivering revenue growth of 6%, non-GAAP EPS growth of 18%, as well as strong margins and cash flow,” said Kelly Kramer,
CFO of Cisco. “We continue to invest in our innovation pipeline to drive long-term profitable growth, while successfully evolving our business model through software offerings and subscriptions and delivering value for shareholders.”

[0001193125-19-147994:8k_2_02:23]
1

[0001193125-19-147994:8k_2_02:24]
Financial Summary

[0001193125-19-147994:8k_2_02:25]
All comparative percentages are on a year-over-year basis unless otherwise noted.

[0001193125-19-147994:8k_2_02:26]
All revenue, non-GAAP, and geographic financial information in the “Q3 FY 2019 Highlights” section are
presented excluding the SPVSS business for all periods as it was divested during the second quarter, on October 28, 2018.

[0001193125-19-147994:8k_2_02:27]
Q3 FY 2019
Highlights

[0001193125-19-147994:8k_2_02:28]
Revenue — Total revenue was $13.0 billion, up 6%, with product revenue up 7% and service revenue up 3%. Revenue by
geographic segment was: Americas up 9%, EMEA up 5%, and APJC down 4%. Product revenue performance was broad based with growth in Security, up 21%, Applications, up 9%, and Infrastructure Platforms, up 5%.

[0001193125-19-147994:8k_2_02:29]
Gross Margin — On a GAAP basis, total gross margin, product gross margin, and service gross margin were 63.1%, 62.0%, and 66.3%,
respectively, as compared with 62.3%, 61.0%, and 65.8%, respectively, in the third quarter of fiscal 2018.

[0001193125-19-147994:8k_2_02:30]
On a
non-GAAP basis, total gross margin, product gross margin, and service gross margin were 64.6%, 63.7%, and 67.3%, respectively, as compared with 64.5%, 63.7%, and 67.1%, respectively, in the third quarter of
fiscal 2018.

[0001193125-19-147994:8k_2_02:31]
Total gross margins by geographic segment were: 65.6% for the Americas, 64.5% for EMEA and 60.7% for APJC.

[0001193125-19-147994:8k_2_02:32]
Operating Expenses — On a GAAP basis, operating expenses were $4.7 billion, up 1%.
Non-GAAP operating expenses were $4.2 billion, up 6%, and were 32.4% of revenue.

[0001193125-19-147994:8k_2_02:33]
Operating Income
— GAAP operating income was $3.5 billion, up 12%, with GAAP operating margin of 27.1%. Non-GAAP operating income was $4.2 billion, up 6%, with
non-GAAP operating margin at 32.2%.

[0001193125-19-147994:8k_2_02:34]
Provision for Income Taxes — The GAAP tax provision rate
was 15.8%. The non-GAAP tax provision rate was 19.0%.

[0001193125-19-147994:8k_2_02:35]
Net Income and EPS — On a GAAP basis,
net income was $3.0 billion and EPS was $0.69. On a non-GAAP basis, net income was $3.5 billion, an increase of 8%, and EPS was $0.78, an increase of 18%.

[0001193125-19-147994:8k_2_02:36]
Cash Flow from Operating Activities — $4.3 billion for the third quarter of fiscal 2019, an increase of 79% compared with
$2.4 billion for the third quarter of fiscal 2018. Operating cash flow for the third quarter of fiscal 2018 included the payment of $1.3 billion of one-time foreign taxes as related to the Tax Cuts
and Jobs Act. Operating cash flow increased 16%, normalized for these tax payments.

[0001193125-19-147994:8k_2_02:37]
Balance Sheet and Other Financial Highlights

[0001193125-19-147994:8k_2_02:38]
Cash and Cash Equivalents and Investments — $34.6 billion at the end of the third quarter of fiscal 2019, compared with
$40.4 billion at the end of the second quarter of fiscal 2019, and compared with $46.5 billion at the end of fiscal 2018.

[0001193125-19-147994:8k_2_02:39]
Deferred
Revenue — $17.5 billion, down 8% in total, with deferred product revenue down 23%. Deferred service revenue was up 3%.

[0001193125-19-147994:8k_2_02:40]
Capital
Allocation — In the third quarter of fiscal 2019, we returned $7.5 billion to shareholders through share buybacks and dividends. We declared and paid a cash dividend of $0.35 per common share, or $1.5 billion, and repurchased
approximately 116 million shares of common stock under our stock repurchase program at an average price of $52.14 per share for an aggregate purchase price of $6.0 billion. The remaining authorized amount for stock repurchases under the
program is $18.0 billion with no termination date.

[0001193125-19-147994:8k_2_02:41]
Acquisitions

[0001193125-19-147994:8k_2_02:42]
In the third quarter of fiscal 2019, we closed the acquisitions of Luxtera, Inc., a privately held semiconductor company, and Singularity Networks, a privately
held network infrastructure analytics company.

[0001193125-19-147994:8k_2_02:43]
2

[0001193125-19-147994:8k_2_02:44]
Guidance for Q4 FY 2019

[0001193125-19-147994:8k_2_02:45]
Cisco expects to achieve the following results for the fourth quarter of fiscal 2019 (normalized to exclude the divested SPVSS business):

[0001193125-19-147994:8k_2_02:46]
| Q4 FY 2019 |  |  |
| Revenue |  | 4.5% - 6.5% growth Y/Y |
| Non-GAAP gross margin rate |  | 64% - 65% |
| Non-GAAP operating margin rate |  | 31% - 32% |
| Non-GAAP tax provision rate |  | 19% |
| Non-GAAP EPS |  | $0.80 - $0.82 |

[0001193125-19-147994:8k_2_02:47]
Revenue for the divested SPVSS business for the fourth quarter of fiscal 2018 was $206 million.

[0001193125-19-147994:8k_2_02:48]
Cisco estimates that GAAP EPS will be $0.66 to $0.71 in the fourth quarter of fiscal 2019.

[0001193125-19-147994:8k_2_02:49]
A reconciliation between the Guidance for Q4 FY 2019 on a GAAP and non-GAAP basis is provided in the table entitled
“GAAP to non-GAAP Guidance for Q4 FY 2019” located in the section entitled “Reconciliations of GAAP to non-GAAP Measures.”

[0001193125-19-147994:8k_2_02:50]
Editor’s Notes:

[0001193125-19-147994:8k_2_02:51]
|  | • |  | Q3 fiscal year 2019 conference call to discuss Cisco’s results along with its guidance will be held on Wednesday, May 15, 2019 at 1:30 p.m. Pacific Time. Conference call number is 1-888-848-6507 (United States) or 1-212-519-0847 (international). |

[0001193125-19-147994:8k_2_02:52]
|  | • |  | Conference call replay will be available from 4:00 p.m. Pacific Time, May 15, 2019 to 4:00 p.m. Pacific Time, May 22, 2019 at 1-888-446-2545 (United States) or 1-402-998-1344 (international). The replay will also be available via webcast on the Cisco Investor Relations website at https://investor.cisco.com. |

[0001193125-19-147994:8k_2_02:53]
|  | • |  | Additional information regarding Cisco’s financials, as well as a webcast of the conference call with visuals designed to guide participants through the call, will be available at 1:30 p.m. Pacific Time, May 15, 2019. Text of the conference call’s prepared remarks will be available within 24 hours of completion of the call. The webcast will include both the prepared remarks and the question-and-answer session. This information, along with the GAAP to non-GAAP reconciliation information, will be available on the Cisco Investor Relations website at https://investor.cisco.com. |

[0001193125-19-147994:8k_2_02:54]
|  | • |  | Cisco is hosting Cisco Live, its premier annual customer and partner conference June 9-13 in San Diego, Calif. Register now for keynotes, hands-on learnings experiences, expert demonstrations and networking. |

[0001193125-19-147994:8k_2_02:55]
3

[0001193125-19-147994:8k_2_02:56]
CISCO SYSTEMS, INC.

[0001193125-19-147994:8k_2_02:57]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-19-147994:8k_2_02:58]
(In millions, except per-share amounts)

[0001193125-19-147994:8k_2_02:59]
(Unaudited)

[0001193125-19-147994:8k_2_02:60]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | April 27,2019 |  |  | April 28,2018 |  |  | April 27,2019 |  |  | April 28,2018 |  |
| REVENUE: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 9,722 |  |  | $ | 9,304 |  |  | $ | 28,885 |  |  | $ | 27,067 |  |
| Service |  |  | 3,236 |  |  |  | 3,159 |  |  |  | 9,591 |  |  |  | 9,419 |  |
| Total revenue |  |  | 12,958 |  |  |  | 12,463 |  |  |  | 38,476 |  |  |  | 36,486 |  |
| COST OF SALES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 3,693 |  |  |  | 3,625 |  |  |  | 11,106 |  |  |  | 10,594 |  |
| Service |  |  | 1,092 |  |  |  | 1,079 |  |  |  | 3,278 |  |  |  | 3,208 |  |
| Total cost of sales |  |  | 4,785 |  |  |  | 4,704 |  |  |  | 14,384 |  |  |  | 13,802 |  |
| GROSS MARGIN |  |  | 8,173 |  |  |  | 7,759 |  |  |  | 24,092 |  |  |  | 22,684 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 1,659 |  |  |  | 1,590 |  |  |  | 4,824 |  |  |  | 4,706 |  |
| Sales and marketing |  |  | 2,403 |  |  |  | 2,325 |  |  |  | 7,084 |  |  |  | 6,894 |  |
| General and administrative |  |  | 541 |  |  |  | 561 |  |  |  | 1,261 |  |  |  | 1,601 |  |
| Amortization of purchased intangible assets |  |  | 39 |  |  |  | 67 |  |  |  | 112 |  |  |  | 188 |  |
| Restructuring and other charges |  |  | 18 |  |  |  | 82 |  |  |  | 282 |  |  |  | 332 |  |
| Total operating expenses |  |  | 4,660 |  |  |  | 4,625 |  |  |  | 13,563 |  |  |  | 13,721 |  |
| OPERATING INCOME |  |  | 3,513 |  |  |  | 3,134 |  |  |  | 10,529 |  |  |  | 8,963 |  |
| Interest income |  |  | 331 |  |  |  | 380 |  |  |  | 1,003 |  |  |  | 1,155 |  |
| Interest expense |  |  | (211 | ) |  |  | (237 | ) |  |  | (655 | ) |  |  | (719 | ) |
| Other income (loss), net |  |  | (18 | ) |  |  | (24 | ) |  |  | (10 | ) |  |  | 48 |  |
| Interest and other income (loss), net |  |  | 102 |  |  |  | 119 |  |  |  | 338 |  |  |  | 484 |  |
| INCOME BEFORE PROVISION FOR INCOME TAXES |  |  | 3,615 |  |  |  | 3,253 |  |  |  | 10,867 |  |  |  | 9,447 |  |
| Provision for income taxes (1) |  |  | 571 |  |  |  | 562 |  |  |  | 1,452 |  |  |  | 13,140 |  |
| NET INCOME (LOSS) |  | $ | 3,044 |  |  | $ | 2,691 |  |  | $ | 9,415 |  |  | $ | (3,693 | ) |
| Net income (loss) per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.70 |  |  | $ | 0.56 |  |  | $ | 2.11 |  |  | $ | (0.76 | ) |
| Diluted |  | $ | 0.69 |  |  | $ | 0.56 |  |  | $ | 2.09 |  |  | $ | (0.76 | ) |
| Shares used in per-share calculation: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 4,370 |  |  |  | 4,791 |  |  |  | 4,468 |  |  |  | 4,892 |  |
| Diluted |  |  | 4,415 |  |  |  | 4,844 |  |  |  | 4,509 |  |  |  | 4,892 |  |

[0001193125-19-147994:8k_2_02:61]
The Consolidated Statements of Operations include the results of the SPVSS business prior to its divestiture during the second
quarter of fiscal 2019 on October 28, 2018. Accordingly, the nine months ended April 27, 2019 includes three months of financial results for this business.

[0001193125-19-147994:8k_2_02:62]
| (1) | The provision for income taxes for the nine months ended April 28, 2018 includes an $11.1 billion charge related to the enactment of the Tax Cuts and Jobs Act. |

[0001193125-19-147994:8k_2_02:63]
4

[0001193125-19-147994:8k_2_02:64]
CISCO SYSTEMS, INC.

[0001193125-19-147994:8k_2_02:65]
REVENUE BY SEGMENT

[0001193125-19-147994:8k_2_02:66]
(In
millions, except percentages)

[0001193125-19-147994:8k_2_02:67]
|  |  | April 27, 2019 |  |
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | Amount |  |  | Y/Y% |  |  | Amount |  |  | Y/Y% |  |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Including SPVSS business for all periods: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 7,695 |  |  |  | 7 | % |  | $ | 22,798 |  |  |  | 6 | % |
| EMEA |  |  | 3,356 |  |  |  | 2 | % |  |  | 9,803 |  |  |  | 6 | % |
| APJC |  |  | 1,907 |  |  |  | (6 | )% |  |  | 5,875 |  |  |  | 3 | % |
| Total |  | $ | 12,958 |  |  |  | 4 | % |  | $ | 38,476 |  |  |  | 5 | % |
| Excluding SPVSS business for all periods: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 7,695 |  |  |  | 9 | % |  | $ | 22,721 |  |  |  | 7 | % |
| EMEA |  |  | 3,356 |  |  |  | 5 | % |  |  | 9,737 |  |  |  | 8 | % |
| APJC |  |  | 1,907 |  |  |  | (4 | )% |  |  | 5,851 |  |  |  | 5 | % |
| Total |  | $ | 12,958 |  |  |  | 6 | % |  | $ | 38,309 |  |  |  | 7 | % |

[0001193125-19-147994:8k_2_02:68]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-19-147994:8k_2_02:69]
During the second quarter of fiscal 2019 on October 28, 2018, we completed the divestiture of the SPVSS business. SPVSS business revenue for the three
months ended April 28, 2018 was $219 million and for the nine months ended April 27, 2019 and April 28, 2018 was $168 million and $697 million, respectively.

[0001193125-19-147994:8k_2_02:70]
CISCO SYSTEMS, INC.

[0001193125-19-147994:8k_2_02:71]
GROSS MARGIN PERCENTAGE BY SEGMENT

[0001193125-19-147994:8k_2_02:72]
(In percentages)

[0001193125-19-147994:8k_2_02:73]
|  |  | April 27, 2019 |  |
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
| Gross Margin Percentage: |  |  |  |  |  |  |  |  |
| Including SPVSS business for all periods: |  |  |  |  |  |  |  |  |
| Americas |  |  | 65.6 | % |  |  | 65.4 | % |
| EMEA |  |  | 64.5 | % |  |  | 64.3 | % |
| APJC |  |  | 60.7 | % |  |  | 59.0 | % |
| Excluding SPVSS business for all periods (1): |  |  |  |  |  |  |  |  |
| Americas |  |  | 65.6 | % |  |  | 65.6 | % |
| EMEA |  |  | 64.5 | % |  |  | 64.4 | % |
| APJC |  |  | 60.7 | % |  |  | 59.1 | % |

[0001193125-19-147994:8k_2_02:74]
| (1) | During the second quarter of fiscal 2019 on October 28, 2018, we completed the divestiture of the SPVSS business. |

[0001193125-19-147994:8k_2_02:75]
5

[0001193125-19-147994:8k_2_02:76]
CISCO SYSTEMS, INC.

[0001193125-19-147994:8k_2_02:77]
REVENUE FOR GROUPS OF SIMILAR PRODUCTS AND SERVICES

[0001193125-19-147994:8k_2_02:78]
(In millions, except percentages)

[0001193125-19-147994:8k_2_02:79]
|  |  | April 27, 2019 |  |
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | Amount |  |  | Y/Y% |  |  | Amount |  |  | Y/Y% |  |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Including SPVSS business for all periods: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Infrastructure Platforms |  | $ | 7,545 |  |  |  | 5 | % |  | $ | 22,315 |  |  |  | 7 | % |
| Applications |  |  | 1,431 |  |  |  | 9 | % |  |  | 4,315 |  |  |  | 17 | % |
| Security |  |  | 707 |  |  |  | 21 | % |  |  | 2,016 |  |  |  | 17 | % |
| Other Products |  |  | 39 |  |  |  | (83 | )% |  |  | 239 |  |  |  | (69 | )% |
| Total Product |  |  | 9,722 |  |  |  | 4 | % |  |  | 28,885 |  |  |  | 7 | % |
| Services |  |  | 3,236 |  |  |  | 2 | % |  |  | 9,591 |  |  |  | 2 | % |
| Total |  | $ | 12,958 |  |  |  | 4 | % |  | $ | 38,476 |  |  |  | 5 | % |
| Excluding SPVSS business for all periods: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Infrastructure Platforms |  | $ | 7,545 |  |  |  | 5 | % |  | $ | 22,315 |  |  |  | 7 | % |
| Applications |  |  | 1,431 |  |  |  | 9 | % |  |  | 4,315 |  |  |  | 17 | % |
| Security |  |  | 707 |  |  |  | 21 | % |  |  | 2,016 |  |  |  | 17 | % |
| Other Products |  |  | 39 |  |  |  | 3 | % |  |  | 93 |  |  |  | (39 | )% |
| Total Product |  |  | 9,722 |  |  |  | 7 | % |  |  | 28,739 |  |  |  | 9 | % |
| Services |  |  | 3,236 |  |  |  | 3 | % |  |  | 9,570 |  |  |  | 2 | % |
| Total |  | $ | 12,958 |  |  |  | 6 | % |  | $ | 38,309 |  |  |  | 7 | % |

[0001193125-19-147994:8k_2_02:80]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-19-147994:8k_2_02:81]
During the second quarter of fiscal 2019 on October 28, 2018, we completed the divestiture of the SPVSS business. SPVSS business revenue for the three
months ended April 28, 2018 was $219 million and for the nine months ended April 27, 2019 and April 28, 2018 was $168 million and $697 million, respectively.

[0001193125-19-147994:8k_2_02:82]
6

[0001193125-19-147994:8k_2_02:83]
CISCO SYSTEMS, INC.

[0001193125-19-147994:8k_2_02:84]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001193125-19-147994:8k_2_02:85]
(In millions)

[0001193125-19-147994:8k_2_02:86]
(Unaudited)

[0001193125-19-147994:8k_2_02:87]
|  |  | April 27,2019 |  |  | July 28,2018 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 10,251 |  |  | $ | 8,934 |  |
| Investments |  |  | 24,392 |  |  |  | 37,614 |  |
| Accounts receivable, net of allowance for doubtful accounts of $124 at April 27, 2019 and $129 at July 28, 2018 |  |  | 3,795 |  |  |  | 5,554 |  |
| Inventories |  |  | 1,513 |  |  |  | 1,846 |  |
| Financing receivables, net |  |  | 5,029 |  |  |  | 4,949 |  |
| Other current assets |  |  | 2,331 |  |  |  | 2,940 |  |
| Total current assets |  |  | 47,311 |  |  |  | 61,837 |  |
| Property and equipment, net |  |  | 2,834 |  |  |  | 3,006 |  |
| Financing receivables, net |  |  | 4,862 |  |  |  | 4,882 |  |
| Goodwill |  |  | 33,544 |  |  |  | 31,706 |  |
| Purchased intangible assets, net |  |  | 2,398 |  |  |  | 2,552 |  |
| Deferred tax assets |  |  | 4,023 |  |  |  | 3,219 |  |
| Other assets |  |  | 2,315 |  |  |  | 1,582 |  |
| TOTAL ASSETS |  | $ | 97,287 |  |  | $ | 108,784 |  |
| LIABILITIES AND EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 7,777 |  |  | $ | 5,238 |  |
| Accounts payable |  |  | 2,022 |  |  |  | 1,904 |  |
| Income taxes payable |  |  | 953 |  |  |  | 1,004 |  |
| Accrued compensation |  |  | 2,872 |  |  |  | 2,986 |  |
| Deferred revenue |  |  | 10,117 |  |  |  | 11,490 |  |
| Other current liabilities |  |  | 4,172 |  |  |  | 4,413 |  |
| Total current liabilities |  |  | 27,913 |  |  |  | 27,035 |  |
| Long-term debt |  |  | 15,921 |  |  |  | 20,331 |  |
| Income taxes payable |  |  | 8,038 |  |  |  | 8,585 |  |
| Deferred revenue |  |  | 7,339 |  |  |  | 8,195 |  |
| Other long-term liabilities |  |  | 1,272 |  |  |  | 1,434 |  |
| Total liabilities |  |  | 60,483 |  |  |  | 65,580 |  |
| Total equity |  |  | 36,804 |  |  |  | 43,204 |  |
| TOTAL LIABILITIES AND EQUITY |  | $ | 97,287 |  |  | $ | 108,784 |  |

[0001193125-19-147994:8k_2_02:88]
7

[0001193125-19-147994:8k_2_02:89]
CISCO SYSTEMS, INC.

[0001193125-19-147994:8k_2_02:90]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-19-147994:8k_2_02:91]
(In millions)

[0001193125-19-147994:8k_2_02:92]
(Unaudited)

[0001193125-19-147994:8k_2_02:93]
|  |  | Nine Months Ended |  |
|  |  | April 27,2019 |  |  | April 28,2018 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income (loss) |  | $ | 9,415 |  |  | $ | (3,693 | ) |
| Adjustments to reconcile net income (loss) to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation, amortization, and other |  |  | 1,433 |  |  |  | 1,676 |  |
| Share-based compensation expense |  |  | 1,166 |  |  |  | 1,184 |  |
| Provision (benefit) for receivables |  |  | 32 |  |  |  | (104 | ) |
| Deferred income taxes |  |  | (281 | ) |  |  | 1,013 |  |
| (Gains) losses on divestitures, investments and other, net |  |  | (79 | ) |  |  | (159 | ) |
| Change in operating assets and liabilities, net of effects of acquisitions and divestitures: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 1,560 |  |  |  | 1,064 |  |
| Inventories |  |  | (1 | ) |  |  | (289 | ) |
| Financing receivables |  |  | (112 | ) |  |  | (165 | ) |
| Other assets |  |  | (736 | ) |  |  | (135 | ) |
| Accounts payable |  |  | 52 |  |  |  | 148 |  |
| Income taxes, net |  |  | (759 | ) |  |  | 8,795 |  |
| Accrued compensation |  |  | (68 | ) |  |  | 53 |  |
| Deferred revenue |  |  | 421 |  |  |  | 415 |  |
| Other liabilities |  |  | (154 | ) |  |  | (237 | ) |
| Net cash provided by operating activities |  |  | 11,889 |  |  |  | 9,566 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of investments |  |  | (1,176 | ) |  |  | (14,132 | ) |
| Proceeds from sales of investments |  |  | 5,391 |  |  |  | 12,422 |  |
| Proceeds from maturities of investments |  |  | 10,797 |  |  |  | 12,259 |  |
| Acquisitions and divestitures |  |  | (2,175 | ) |  |  | (2,762 | ) |
| Purchases of investments in privately held companies |  |  | (118 | ) |  |  | (126 | ) |
| Return of investments in privately held companies |  |  | 127 |  |  |  | 163 |  |
| Acquisition of property and equipment |  |  | (701 | ) |  |  | (620 | ) |
| Proceeds from sales of property and equipment |  |  | 15 |  |  |  | 54 |  |
| Other |  |  | (12 | ) |  |  | (16 | ) |
| Net cash provided by investing activities |  |  | 12,148 |  |  |  | 7,242 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Issuances of common stock |  |  | 321 |  |  |  | 318 |  |
| Repurchases of common stock—repurchase program |  |  | (16,042 | ) |  |  | (11,562 | ) |
| Shares repurchased for tax withholdings on vesting of restricted stock units |  |  | (601 | ) |  |  | (541 | ) |
| Short-term borrowings, original maturities of 90 days or less, net |  |  | 1,723 |  |  |  | (2,502 | ) |
| Issuances of debt |  |  | 1,530 |  |  |  | 6,877 |  |
| Repayments of debt |  |  | (5,250 | ) |  |  | (9,875 | ) |
| Dividends paid |  |  | (4,489 | ) |  |  | (4,433 | ) |
| Other |  |  | 51 |  |  |  | (92 | ) |
| Net cash used in financing activities |  |  | (22,757 | ) |  |  | (21,810 | ) |
| Net increase (decrease) in cash, cash equivalents, and restricted cash |  |  | 1,280 |  |  |  | (5,002 | ) |
| Cash, cash equivalents, and restricted cash, beginning of period |  |  | 8,993 |  |  |  | 11,773 |  |
| Cash, cash equivalents, and restricted cash, end of period |  | $ | 10,273 |  |  | $ | 6,771 |  |
| Supplemental cash flow information: |  |  |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 690 |  |  | $ | 739 |  |
| Cash paid for income taxes, net |  | $ | 2,491 |  |  | $ | 3,332 |  |

[0001193125-19-147994:8k_2_02:94]
Prior period information has been retrospectively adjusted due to the adoption of ASU
2016-18, Statement of Cash Flows, Restricted Cash at the beginning of the first quarter of fiscal 2019.

[0001193125-19-147994:8k_2_02:95]
8

[0001193125-19-147994:8k_2_02:96]
CISCO SYSTEMS, INC.

[0001193125-19-147994:8k_2_02:97]
DEFERRED REVENUE

[0001193125-19-147994:8k_2_02:98]
(In
millions)

[0001193125-19-147994:8k_2_02:99]
|  |  | April 27,2019 |  |  | January 26,2019 |  |  | April 28,2018 |  |
| Deferred revenue: |  |  |  |  |  |  |  |  |  |  |  |  |
| Service |  | $ | 11,297 |  |  | $ | 11,246 |  |  | $ | 10,960 |  |
| Product |  |  | 6,159 |  |  |  | 6,015 |  |  |  | 7,993 |  |
| Total |  | $ | 17,456 |  |  | $ | 17,261 |  |  | $ | 18,953 |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |  |
| Current |  | $ | 10,117 |  |  | $ | 9,976 |  |  | $ | 11,301 |  |
| Noncurrent |  |  | 7,339 |  |  |  | 7,285 |  |  |  | 7,652 |  |
| Total |  | $ | 17,456 |  |  | $ | 17,261 |  |  | $ | 18,953 |  |

[0001193125-19-147994:8k_2_02:100]
CISCO SYSTEMS, INC.

[0001193125-19-147994:8k_2_02:101]
DIVIDENDS PAID AND REPURCHASES OF COMMON STOCK

[0001193125-19-147994:8k_2_02:102]
(In millions, except per-share amounts)

[0001193125-19-147994:8k_2_02:103]
|  |  | DIVIDENDS |  |  | STOCK REPURCHASE PROGRAM |  |  | TOTAL |  |
| Quarter Ended |  | Per Share |  |  | Amount |  |  | Shares |  |  | Weighted-Average Priceper Share |  |  | Amount |  |  | Amount |  |
| Fiscal 2019 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| April 27, 2019 |  | $ | 0.35 |  |  | $ | 1,519 |  |  |  | 116 |  |  | $ | 52.14 |  |  | $ | 6,020 |  |  | $ | 7,539 |  |
| January 26, 2019 |  | $ | 0.33 |  |  | $ | 1,470 |  |  |  | 111 |  |  | $ | 45.09 |  |  | $ | 5,016 |  |  | $ | 6,486 |  |
| October 27, 2018 |  | $ | 0.33 |  |  | $ | 1,500 |  |  |  | 109 |  |  | $ | 46.01 |  |  | $ | 5,026 |  |  | $ | 6,526 |  |
| Fiscal 2018 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| July 28, 2018 |  | $ | 0.33 |  |  | $ | 1,535 |  |  |  | 138 |  |  | $ | 43.58 |  |  | $ | 6,015 |  |  | $ | 7,550 |  |
| April 28, 2018 |  | $ | 0.33 |  |  | $ | 1,572 |  |  |  | 140 |  |  | $ | 42.83 |  |  | $ | 6,015 |  |  | $ | 7,587 |  |
| January 27, 2018 |  | $ | 0.29 |  |  | $ | 1,425 |  |  |  | 103 |  |  | $ | 39.07 |  |  | $ | 4,011 |  |  | $ | 5,436 |  |
| October 28, 2017 |  | $ | 0.29 |  |  | $ | 1,436 |  |  |  | 51 |  |  | $ | 31.80 |  |  | $ | 1,620 |  |  | $ | 3,056 |  |

[0001193125-19-147994:8k_2_02:104]
9

[0001193125-19-147994:8k_2_02:105]
CISCO SYSTEMS, INC.

[0001193125-19-147994:8k_2_02:106]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-19-147994:8k_2_02:107]
GAAP NET INCOME (LOSS) TO NON-GAAP NET INCOME

[0001193125-19-147994:8k_2_02:108]
(In millions, except per-share amounts)

[0001193125-19-147994:8k_2_02:109]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | April 27,2019 |  |  | April 28,2018 |  |  | April 27,2019 |  |  | April 28,2018 |  |
| GAAP net income (loss) |  | $ | 3,044 |  |  | $ | 2,691 |  |  | $ | 9,415 |  |  | $ | (3,693 | ) |
| Adjustments to cost of sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 54 |  |  |  | 57 |  |  |  | 163 |  |  |  | 168 |  |
| Amortization of acquisition-related intangible assets |  |  | 141 |  |  |  | 161 |  |  |  | 418 |  |  |  | 444 |  |
| Supplier component remediation charge (adjustment), net |  |  | — |  |  |  | (9 | ) |  |  | (1 | ) |  |  | (41 | ) |
| Acquisition-related/divestiture costs |  |  | 2 |  |  |  | 2 |  |  |  | 9 |  |  |  | 4 |  |
| Legal and indemnification settlements |  |  | — |  |  |  | — |  |  |  | 5 |  |  |  | 122 |  |
| Total adjustments to GAAP cost of sales |  |  | 197 |  |  |  | 211 |  |  |  | 594 |  |  |  | 697 |  |
| Adjustments to operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 322 |  |  |  | 342 |  |  |  | 974 |  |  |  | 1,010 |  |
| Amortization of acquisition-related intangible assets |  |  | 39 |  |  |  | 67 |  |  |  | 112 |  |  |  | 188 |  |
| Acquisition-related/divestiture costs |  |  | 78 |  |  |  | 89 |  |  |  | 238 |  |  |  | 195 |  |
| Legal and indemnification settlements |  |  | (1 | ) |  |  | — |  |  |  | (396 | ) |  |  | — |  |
| Significant asset impairments and restructurings |  |  | 18 |  |  |  | 82 |  |  |  | 282 |  |  |  | 332 |  |
| Total adjustments to GAAP operating expenses |  |  | 456 |  |  |  | 580 |  |  |  | 1,210 |  |  |  | 1,725 |  |
| Adjustments to GAAP interest and other income (loss), net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| (Gains) and losses on equity investments |  |  | (4 | ) |  |  | — |  |  |  | (77 | ) |  |  | — |  |
| Total adjustments to GAAP income (loss) before provision for income taxes |  |  | 649 |  |  |  | 791 |  |  |  | 1,727 |  |  |  | 2,422 |  |
| Income tax effect of non-GAAP adjustments |  |  | (160 | ) |  |  | (168 | ) |  |  | (554 | ) |  |  | (613 | ) |
| Significant tax matters (1) |  |  | (79 | ) |  |  | (119 | ) |  |  | (387 | ) |  |  | 11,261 |  |
| Total adjustments to GAAP provision for income taxes |  |  | (239 | ) |  |  | (287 | ) |  |  | (941 | ) |  |  | 10,648 |  |
| Non-GAAP net income |  | $ | 3,454 |  |  | $ | 3,195 |  |  | $ | 10,201 |  |  | $ | 9,377 |  |
| Net income (loss) per share (2): |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | $ | 0.69 |  |  | $ | 0.56 |  |  | $ | 2.09 |  |  | $ | (0.76 | ) |
| Non-GAAP |  | $ | 0.78 |  |  | $ | 0.66 |  |  | $ | 2.26 |  |  | $ | 1.90 |  |

[0001193125-19-147994:8k_2_02:110]
| (1) | For the first nine months of fiscal 2018, we recorded charges relating to significant tax matters that were excluded from non-GAAP net income. $11.1 billion of these charges were provisional amounts related to the enactment of the Tax Cuts and Jobs Act comprised of $8.9 billion related to the U.S. transition tax, $1.2 billion related to foreign withholding tax and $1.0 billion related to the re-measurement of net deferred tax assets. The amounts were provisional based on Securities and Exchange Commission Staff Accounting Bulletin No. 118. The remaining $0.2 billion was related to other significant tax matters. |

[0001193125-19-147994:8k_2_02:111]
| (2) | GAAP net loss per share for the nine months ended April 28, 2018 was calculated using basic shares of 4,892 million, due to the net loss resulting from the tax charge as discussed in footnote (1). Non-GAAP net income per share for the period was calculated using diluted shares of 4,936 million, as we had non-GAAP net income for this period. |

[0001193125-19-147994:8k_2_02:112]
10

[0001193125-19-147994:8k_2_02:113]
CISCO SYSTEMS, INC.

[0001193125-19-147994:8k_2_02:114]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-19-147994:8k_2_02:115]
GROSS MARGINS, OPERATING EXPENSES, OPERATING MARGINS, INTEREST AND OTHER INCOME (LOSS), NET, AND NET INCOME

[0001193125-19-147994:8k_2_02:116]
(In millions, except percentages)

[0001193125-19-147994:8k_2_02:117]
|  |  | Three Months Ended |  |
|  |  | April 27, 2019 |  |
|  |  | ProductGrossMargin |  |  | ServiceGrossMargin |  |  | TotalGrossMargin |  |  | OperatingExpenses |  |  | Y/Y |  |  | OperatingIncome |  |  | Y/Y |  |  | Interestand otherincome(loss),net |  |  | Y/Y |  |  | NetIncome |  |  | Y/Y |  |
| GAAP amount |  | $ | 6,029 |  |  | $ | 2,144 |  |  | $ | 8,173 |  |  | $ | 4,660 |  |  |  | 1 | % |  | $ | 3,513 |  |  |  | 12 | % |  | $ | 102 |  |  |  | (14 | )% |  | $ | 3,044 |  |  |  | 13 | % |
| % of revenue |  |  | 62.0 | % |  |  | 66.3 | % |  |  | 63.1 | % |  |  | 36.0 | % |  |  |  |  |  |  | 27.1 | % |  |  |  |  |  |  | 0.8 | % |  |  |  |  |  |  | 23.5 | % |  |  |  |  |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 22 |  |  |  | 32 |  |  |  | 54 |  |  |  | 322 |  |  |  |  |  |  |  | 376 |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | 376 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  |  | 141 |  |  |  | — |  |  |  | 141 |  |  |  | 39 |  |  |  |  |  |  |  | 180 |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | 180 |  |  |  |  |  |
| Legal and indemnification settlements |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (1 | ) |  |  |  |  |  |  | (1 | ) |  |  |  |  |  |  | — |  |  |  |  |  |  |  | (1 | ) |  |  |  |  |
| Acquisition/divestiture-related costs |  |  | 1 |  |  |  | 1 |  |  |  | 2 |  |  |  | 78 |  |  |  |  |  |  |  | 80 |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | 80 |  |  |  |  |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 18 |  |  |  |  |  |  |  | 18 |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | 18 |  |  |  |  |  |
| (Gains) and losses on equity investments |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | (4 | ) |  |  |  |  |  |  | (4 | ) |  |  |  |  |
| Income tax effect/significant tax matters |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | (239 | ) |  |  |  |  |
| Non-GAAP amount |  | $ | 6,193 |  |  | $ | 2,177 |  |  | $ | 8,370 |  |  | $ | 4,204 |  |  |  | 6 | % |  | $ | 4,166 |  |  |  | 6 | % |  | $ | 98 |  |  |  | (18 | )% |  | $ | 3,454 |  |  |  | 8 | % |
| % of revenue |  |  | 63.7 | % |  |  | 67.3 | % |  |  | 64.6 | % |  |  | 32.4 | % |  |  |  |  |  |  | 32.2 | % |  |  |  |  |  |  | 0.8 | % |  |  |  |  |  |  | 26.7 | % |  |  |  |  |

[0001193125-19-147994:8k_2_02:118]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-19-147994:8k_2_02:119]
During the second quarter of fiscal 2019 on October 28, 2018, we completed the divestiture of the SPVSS business. Accordingly, the non-GAAP growth rates are normalized to exclude the SPVSS business for the third quarter of fiscal 2018.

[0001193125-19-147994:8k_2_02:120]
|  |  | Three Months Ended |  |
|  |  | April 28, 2018 |  |
|  |  | ProductGrossMargin |  |  | ServiceGrossMargin |  |  | TotalGrossMargin |  |  | OperatingExpenses |  |  | OperatingIncome |  |  | NetIncome |  |
| GAAP amount |  | $ | 5,679 |  |  | $ | 2,080 |  |  | $ | 7,759 |  |  | $ | 4,625 |  |  | $ | 3,134 |  |  | $ | 2,691 |  |
| % of revenue |  |  | 61.0 | % |  |  | 65.8 | % |  |  | 62.3 | % |  |  | 37.1 | % |  |  | 25.1 | % |  |  | 21.6 | % |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 24 |  |  |  | 33 |  |  |  | 57 |  |  |  | 342 |  |  |  | 399 |  |  |  | 399 |  |
| Amortization of acquisition-related intangible assets |  |  | 161 |  |  |  | — |  |  |  | 161 |  |  |  | 67 |  |  |  | 228 |  |  |  | 228 |  |
| Supplier component remediation charge (adjustment), net |  |  | (9 | ) |  |  | — |  |  |  | (9 | ) |  |  | — |  |  |  | (9 | ) |  |  | (9 | ) |
| Acquisition/divestiture-related costs |  |  | 1 |  |  |  | 1 |  |  |  | 2 |  |  |  | 89 |  |  |  | 91 |  |  |  | 91 |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 82 |  |  |  | 82 |  |  |  | 82 |  |
| Income tax effect/significant tax matters |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (287 | ) |
| Non-GAAP amount |  | $ | 5,856 |  |  | $ | 2,114 |  |  | $ | 7,970 |  |  | $ | 4,045 |  |  | $ | 3,925 |  |  | $ | 3,195 |  |
| Less: SPVSS business (1) |  |  | (56 | ) |  |  | (11 | ) |  |  | (66 | ) |  |  | (61 | ) |  |  | (5 | ) |  |  | (4 | ) |
| Non-GAAP amount (excluding SPVSS business) |  | $ | 5,800 |  |  | $ | 2,103 |  |  | $ | 7,903 |  |  | $ | 3,984 |  |  | $ | 3,919 |  |  | $ | 3,191 |  |
| % of revenue |  |  | 63.7 | % |  |  | 67.1 | % |  |  | 64.5 | % |  |  | 32.5 | % |  |  | 32.0 | % |  |  | 26.1 | % |

[0001193125-19-147994:8k_2_02:121]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-19-147994:8k_2_02:122]
| (1) | Reflects three months of operations for the SPVSS business. |

[0001193125-19-147994:8k_2_02:123]
12

[0001193125-19-147994:8k_2_02:124]
CISCO SYSTEMS, INC.

[0001193125-19-147994:8k_2_02:125]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-19-147994:8k_2_02:126]
GROSS MARGINS, OPERATING EXPENSES, OPERATING MARGINS, INTEREST AND OTHER INCOME (LOSS), NET, AND NET INCOME (LOSS)

[0001193125-19-147994:8k_2_02:127]
(In millions, except percentages)

[0001193125-19-147994:8k_2_02:128]
|  |  | Nine Months Ended |  |
|  |  | April 27, 2019 |  |
|  |  | ProductGrossMargin |  |  | ServiceGrossMargin |  |  | TotalGrossMargin |  |  | OperatingExpenses |  |  | Y/Y |  |  | OperatingIncome |  |  | Y/Y |  |  | Interestand otherincome(loss),net |  |  | Y/Y |  |  | NetIncome |  |  | Y/Y |  |
| GAAP amount |  | $ | 17,779 |  |  | $ | 6,313 |  |  | $ | 24,092 |  |  | $ | 13,563 |  |  |  | (1 | )% |  | $ | 10,529 |  |  |  | 17 | % |  | $ | 338 |  |  |  | (30 | )% |  | $ | 9,415 |  |  |  | NM |  |
| % of revenue |  |  | 61.6 | % |  |  | 65.8 | % |  |  | 62.6 | % |  |  | 35.3 | % |  |  |  |  |  |  | 27.4 | % |  |  |  |  |  |  | 0.9 | % |  |  |  |  |  |  | 24.5 | % |  |  |  |  |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 67 |  |  |  | 96 |  |  |  | 163 |  |  |  | 974 |  |  |  |  |  |  |  | 1,137 |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | 1,137 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  |  | 418 |  |  |  | — |  |  |  | 418 |  |  |  | 112 |  |  |  |  |  |  |  | 530 |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | 530 |  |  |  |  |  |
| Supplier component remediation charge (adjustment), net |  |  | (1 | ) |  |  | — |  |  |  | (1 | ) |  |  | — |  |  |  |  |  |  |  | (1 | ) |  |  |  |  |  |  | — |  |  |  |  |  |  |  | (1 | ) |  |  |  |  |
| Legal and indemnification settlements |  |  | 5 |  |  |  | — |  |  |  | 5 |  |  |  | (396 | ) |  |  |  |  |  |  | (391 | ) |  |  |  |  |  |  | — |  |  |  |  |  |  |  | (391 | ) |  |  |  |  |
| Acquisition/divestiture-related costs |  |  | 4 |  |  |  | 5 |  |  |  | 9 |  |  |  | 238 |  |  |  |  |  |  |  | 247 |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | 247 |  |  |  |  |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 282 |  |  |  |  |  |  |  | 282 |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | 282 |  |  |  |  |  |
| (Gains) and losses on equity investments |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | (77 | ) |  |  |  |  |  |  | (77 | ) |  |  |  |  |
| Income tax effect/significant tax matters |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | (941 | ) |  |  |  |  |
| Non-GAAP amount |  | $ | 18,272 |  |  | $ | 6,414 |  |  | $ | 24,686 |  |  | $ | 12,353 |  |  |  |  |  |  | $ | 12,333 |  |  |  |  |  |  | $ | 261 |  |  |  |  |  |  | $ | 10,201 |  |  |  |  |  |
| % of revenue |  |  | 63.3 | % |  |  | 66.9 | % |  |  | 64.2 | % |  |  | 32.1 | % |  |  |  |  |  |  | 32.1 | % |  |  |  |  |  |  | 0.7 | % |  |  |  |  |  |  | 26.5 | % |  |  |  |  |
| Less: SPVSS business (1) |  |  | (52 | ) |  |  | (9 | ) |  |  | (61 | ) |  |  | (59 | ) |  |  |  |  |  |  | (1 | ) |  |  |  |  |  |  | — |  |  |  |  |  |  |  | (1 | ) |  |  |  |  |
| Non-GAAP amount (excluding SPVSS business) |  | $ | 18,220 |  |  | $ | 6,405 |  |  | $ | 24,625 |  |  | $ | 12,293 |  |  |  | 4 | % |  | $ | 12,332 |  |  |  | 9 | % |  | $ | 261 |  |  |  | (46 | )% |  | $ | 10,200 |  |  |  | 9 | % |
| % of revenue |  |  | 63.4 | % |  |  | 66.9 | % |  |  | 64.3 | % |  |  | 32.1 | % |  |  |  |  |  |  | 32.2 | % |  |  |  |  |  |  | 0.7 | % |  |  |  |  |  |  | 26.6 | % |  |  |  |  |

[0001193125-19-147994:8k_2_02:129]
NM — Not meaningful

[0001193125-19-147994:8k_2_02:130]
| (1) | Reflects three months of operations for the SPVSS business. |

[0001193125-19-147994:8k_2_02:131]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-19-147994:8k_2_02:132]
During the second quarter of fiscal 2019 on October 28, 2018, we completed the divestiture of the SPVSS business. Accordingly, the non-GAAP growth rates are normalized to exclude the SPVSS business for the first nine months of fiscal 2018.

[0001193125-19-147994:8k_2_02:133]
13

[0001193125-19-147994:8k_2_02:134]
|  |  | Nine Months Ended |  |
|  |  | April 28, 2018 |  |
|  |  | ProductGrossMargin |  |  | ServiceGrossMargin |  |  | TotalGrossMargin |  |  | OperatingExpenses |  |  | OperatingIncome |  |  | NetIncome(Loss) |  |
| GAAP amount |  | $ | 16,473 |  |  | $ | 6,211 |  |  | $ | 22,684 |  |  | $ | 13,721 |  |  | $ | 8,963 |  |  | $ | (3,693 | ) |
| % of revenue |  |  | 60.9 | % |  |  | 65.9 | % |  |  | 62.2 | % |  |  | 37.6 | % |  |  | 24.6 | % |  |  | (10.1 | )% |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 70 |  |  |  | 98 |  |  |  | 168 |  |  |  | 1,010 |  |  |  | 1,178 |  |  |  | 1,178 |  |
| Amortization of acquisition-related intangible assets |  |  | 444 |  |  |  | — |  |  |  | 444 |  |  |  | 188 |  |  |  | 632 |  |  |  | 632 |  |
| Supplier component remediation charge (adjustment), net |  |  | (41 | ) |  |  | — |  |  |  | (41 | ) |  |  | — |  |  |  | (41 | ) |  |  | (41 | ) |
| Legal and indemnification settlements |  |  | 122 |  |  |  | — |  |  |  | 122 |  |  |  | — |  |  |  | 122 |  |  |  | 122 |  |
| Acquisition/divestiture-related costs |  |  | 1 |  |  |  | 3 |  |  |  | 4 |  |  |  | 195 |  |  |  | 199 |  |  |  | 199 |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 332 |  |  |  | 332 |  |  |  | 332 |  |
| Income tax effect/significant tax matters (1) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 10,648 |  |
| Non-GAAP amount |  | $ | 17,069 |  |  | $ | 6,312 |  |  | $ | 23,381 |  |  | $ | 11,996 |  |  | $ | 11,385 |  |  | $ | 9,377 |  |
| Less: SPVSS business (2) |  |  | (200 | ) |  |  | (27 | ) |  |  | (226 | ) |  |  | (192 | ) |  |  | (34 | ) |  |  | (27 | ) |
| Non-GAAP amount (excluding SPVSS business) |  | $ | 16,870 |  |  | $ | 6,284 |  |  | $ | 23,154 |  |  | $ | 11,805 |  |  | $ | 11,349 |  |  | $ | 9,348 |  |
| % of revenue |  |  | 63.8 | % |  |  | 67.3 | % |  |  | 64.7 | % |  |  | 33.0 | % |  |  | 31.7 | % |  |  | 26.1 | % |

[0001193125-19-147994:8k_2_02:135]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-19-147994:8k_2_02:136]
| (1) | Includes an $11.1 billion charge related to the enactment of the Tax Cuts and Jobs Act. |

[0001193125-19-147994:8k_2_02:137]
| (2) | Reflects nine months of operations for the SPVSS business. |

[0001193125-19-147994:8k_2_02:138]
14

[0001193125-19-147994:8k_2_02:139]
CISCO SYSTEMS, INC.

[0001193125-19-147994:8k_2_02:140]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-19-147994:8k_2_02:141]
EFFECTIVE TAX RATE

[0001193125-19-147994:8k_2_02:142]
(In
percentages)

[0001193125-19-147994:8k_2_02:143]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | April 27, 2019 |  |  | April 28, 2018 |  |  | April 27, 2019 |  |  | April 28, 2018 |  |
| GAAP effective tax rate (1) |  |  | 15.8 | % |  |  | 17.3 | % |  |  | 13.4 | % |  |  | 139.1 | % |
| Total adjustments to GAAP provision for income taxes |  |  | 3.2 | % |  |  | 3.7 | % |  |  | 5.6 | % |  |  | (118.1 | )% |
| Non-GAAP effective tax rate |  |  | 19.0 | % |  |  | 21.0 | % |  |  | 19.0 | % |  |  | 21.0 | % |

[0001193125-19-147994:8k_2_02:144]
| (1) | Includes an $11.1 billion charge related to the enactment of the Tax Cuts and Jobs Act for the nine months ended April 28, 2018. |

[0001193125-19-147994:8k_2_02:145]
GAAP TO NON-GAAP GUIDANCE FOR Q4 FY 2019

[0001193125-19-147994:8k_2_02:146]
| Q4 FY 2019 |  | Gross MarginRate |  | OperatingMargin Rate |  | Tax ProvisionRate |  | Earnings perShare (1) |
| GAAP |  | 62.5% - 63.5% |  | 26% - 27% |  | 17% |  | $0.66 - $0.71 |
| Estimated adjustments for: |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  | 0.5% |  | 3.0% |  | — |  | $0.06 - $0.07 |
| Amortization of acquisition-related intangible assets and acquisition/divestiture-related costs |  | 1.0% |  | 2.0% |  | — |  | $0.05 - $0.06 |
| Significant asset impairments and restructurings |  | — |  | 0.0% |  | — |  | $0.00 - $0.01 |
| Income tax effect of non-GAAP adjustments |  |  |  |  |  | 2% |  |  |
| Non-GAAP |  | 64% - 65% |  | 31% - 32% |  | 19% |  | $0.80 - $0.82 |

[0001193125-19-147994:8k_2_02:147]
| (1) | Estimated adjustments to GAAP earnings per share are shown after income tax effects. |

[0001193125-19-147994:8k_2_02:148]
Except as noted above, this guidance does not include the effects of any future acquisitions/divestitures, asset impairments, restructurings and significant
tax matters or other events, which may or may not be significant unless specifically stated.

[0001193125-19-147994:8k_2_02:149]
15

[0001193125-19-147994:8k_2_02:150]
Forward Looking Statements, Non-GAAP Information and Additional
Information

[0001193125-19-147994:8k_2_02:151]
This release includes
non-GAAP net income, non-GAAP gross margins, non-GAAP operating expenses, non-GAAP
operating income and margin, non-GAAP effective tax rates, non-GAAP interest and other income (loss), net, and non-GAAP net
income per share data for the periods presented. It also includes future estimated ranges for gross margin, operating margin, tax provision rate and EPS on a non-GAAP basis.

[0001193125-19-147994:8k_2_02:152]
These non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with
generally accepted accounting principles and may be different from non-GAAP measures used by other companies. In addition, these non-GAAP measures are not based on any
comprehensive set of accounting rules or principles. Cisco believes that non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Cisco’s results of operations as
determined in accordance with GAAP and that these measures should only be used to evaluate Cisco’s results of operations in conjunction with the corresponding GAAP measures.

[0001193125-19-147994:8k_2_02:153]
Cisco believes that the presentation of non-GAAP measures when shown in conjunction with the corresponding GAAP
measures, provides useful information to investors and management regarding financial and business trends relating to its financial condition and its historical and projected results of operations.

[0001193125-19-147994:8k_2_02:154]
16

[0001193125-19-147994:8k_2_02:155]
For its internal budgeting process, Cisco’s management uses financial statements that do not include,
when applicable, share-based compensation expense, amortization of acquisition-related intangible assets, acquisition-related/divestiture costs, significant asset impairments and restructurings, significant litigation settlements and other
contingencies, gains and losses on equity investments, the income tax effects of the foregoing and significant tax matters. Cisco’s management also uses the foregoing non-GAAP measures, in addition to the
corresponding GAAP measures, in reviewing the financial results of Cisco. In prior periods, Cisco has excluded other items that it no longer excludes for purposes of its non-GAAP financial measures. From time
to time in the future there may be other items that Cisco may exclude for purposes of its internal budgeting process and in reviewing its financial results. For additional information on the items excluded by Cisco from one or more of its non-GAAP financial measures, refer to the Form 8-K regarding this release furnished today to the Securities and Exchange Commission.

[0001193125-19-147994:8k_2_02:156]
Cisco divested its Service Provider Video Software Solutions business (SPVSS) during the second quarter of fiscal 2019 on October 28, 2018. This release
includes, where indicated, financial measures that exclude the SPVSS business. Cisco believes that the presentation of these measures provides useful information to investors and management regarding financial and business trends relating to its
financial condition and its historical and projected results of operations because the SPVSS business will not be part of Cisco on a go forward basis. Cisco’s management also uses the financial measures excluding the SPVSS business in reviewing
the financial results of Cisco.

[0001193125-19-147994:8k_2_02:157]
About Cisco

[0001193125-19-147994:8k_2_02:158]
Cisco
(Nasdaq: CSCO) is the worldwide technology leader that has been making the Internet work since 1984. Our people, products and partners help society securely connect and seize tomorrow’s digital opportunity today. Discover more at
newsroom.cisco.com and follow us on Twitter at @Cisco.

[0001193125-19-147994:8k_2_02:159]
Copyright © 2019 Cisco and/or its
affiliates. All rights reserved. Cisco and the Cisco logo are trademarks or registered trademarks of Cisco and/or its affiliates in the U.S. and other countries. To view a list of Cisco trademarks, go to: www.cisco.com/go/trademarks. Third-party
trademarks mentioned in this document are the property of their respective owners. The use of the word partner does not imply a partnership relationship between Cisco and any other company. This document is Cisco Public Information.

[0001193125-19-147994:8k_2_02:160]
17
