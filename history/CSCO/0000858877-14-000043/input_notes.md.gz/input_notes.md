# CSCO notes — 0000858877-14-000043


## us-gaap:AllowanceForCreditLossesOnFinancingReceivablesTableTextBlock

[0000858877-14-000043:notes:1]
[same as prior period, unchanged from 0000858877-14-000014:notes:1]

[0000858877-14-000043:notes:2]
|  | CREDIT LOSS ALLOWANCES |
| Three Months Ended October 25, 2014 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts and Other |  | Total |
| Allowance for credit loss as of July 26, 2014 | $ | 233 |  |  | $ | 98 |  |  | $ | 18 |  |  | $ | 349 |  |
| Provisions | 22 |  |  | (13 | ) |  | 19 |  |  | 28 |  |
| Recoveries (write-offs), net | (4 | ) |  | 1 |  |  | — |  |  | (3 | ) |
| Foreign exchange and other | (3 | ) |  | (2 | ) |  | (1 | ) |  | (6 | ) |
| Allowance for credit loss as of October 25, 2014 | $ | 248 |  |  | $ | 84 |  |  | $ | 36 |  |  | $ | 368 |  |
| Financing receivables as of October 25, 2014 (1) | $ | 3,509 |  |  | $ | 1,744 |  |  | $ | 3,071 |  |  | $ | 8,324 |  |

[0000858877-14-000043:notes:3]
|  | CREDIT LOSS ALLOWANCES |
| Three Months Ended October 26, 2013 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts and Other |  | Total |
| Allowance for credit loss as of July 27, 2013 | $ | 238 |  |  | $ | 86 |  |  | $ | 20 |  |  | $ | 344 |  |
| Provisions | (3 | ) |  | 6 |  |  | — |  |  | 3 |  |
| Foreign exchange and other | 2 |  |  | 1 |  |  | — |  |  | 3 |  |
| Allowance for credit loss as of October 26, 2013 | $ | 237 |  |  | $ | 93 |  |  | $ | 20 |  |  | $ | 350 |  |
| Financing receivables as of October 26, 2013 (1) | $ | 3,549 |  |  | $ | 1,808 |  |  | $ | 3,018 |  |  | $ | 8,375 |  |

[0000858877-14-000043:notes:4]
(1) Total financing receivables before allowance for credit loss.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000858877-14-000043:notes:5]
[same as prior period, unchanged from 0000858877-14-000014:notes:10]

[0000858877-14-000043:notes:6]
The Company completed two business combinations during the three months ended October 25, 2014.  A summary of the allocation of the total purchase consideration is presented as follows (in millions):

[0000858877-14-000043:notes:7]
|  | Purchase Consideration |  | Net LiabilitiesAssumed |  | Purchased Intangible Assets |  | Goodwill |
| Metacloud, Inc. | $ | 149 |  |  | $ | (7 | ) |  | $ | 29 |  |  | $ | 127 |  |
| Other | 38 |  |  | (10 | ) |  | 29 |  |  | 19 |  |
| Total acquisitions | $ | 187 |  |  | $ | (17 | ) |  | $ | 58 |  |  | $ | 146 |  |

[0000858877-14-000043:notes:8]
On September 29, 2014, the Company completed its acquisition of Metacloud, Inc. ("Metacloud"), a provider of private clouds for global organizations.  With its acquisition of Metacloud, the Company aims to advance its Intercloud strategy to deliver a globally distributed, highly secure cloud platform capable of meeting customer demands.

[0000858877-14-000043:notes:9]
The total purchase consideration related to the Company’s business combinations completed during the three months ended October 25, 2014 consisted of cash consideration along with vested share-based awards assumed. The total cash and cash equivalents acquired from these business combinations was approximately $3 million. Total transaction costs related to the Company’s business combination activities were $2 million and $6 million for the three months ended October 25, 2014 and October 26, 2013, respectively. These transaction costs were expensed as incurred in general and administrative (G&A) expenses in the Consolidated Statements of Operations.

[0000858877-14-000043:notes:10]
The Company’s purchase price allocation for business combinations completed during recent periods is preliminary and subject to revision as additional information about fair value of assets and liabilities becomes available. Additional information, which existed as of the acquisition date but at that time was unknown to the Company may become known to the Company during the remainder of the measurement period, a period not to exceed 12 months from the acquisition date. Adjustments in the purchase price allocation may require a recasting of the amounts allocated to goodwill retroactive to the period in which the acquisition occurred.

[0000858877-14-000043:notes:11]
The goodwill generated from the Company’s business combinations completed during the three months ended October 25, 2014 is primarily related to expected synergies. The goodwill is generally not deductible for income tax purposes.

[0000858877-14-000043:notes:12]
The Consolidated Financial Statements include the operating results of each business combination from the date of acquisition. Pro forma results of operations for the acquisitions completed during the three months ended October 25, 2014 have not been presented because the effects of the acquisitions, individually and in the aggregate, were not material to the Company’s financial results.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000858877-14-000043:notes:13]
| 12. | Commitments and Contingencies |

[0000858877-14-000043:notes:14]
| (a) | Operating Leases |

[0000858877-14-000043:notes:15]
The Company leases office space in many U.S. locations. Outside the United States, larger leased sites include sites in Belgium, Canada, China, France, Germany, India, Israel, Japan, Norway, and the United Kingdom.  The Company also leases equipment and vehicles. Future minimum lease payments under all noncancelable operating leases with an initial term in excess of one year as of October 25, 2014 are as follows (in millions):

[0000858877-14-000043:notes:16]
| Fiscal Year | Amount |
| 2015 (remaining nine months) | $ | 292 |  |
| 2016 | 282 |  |
| 2017 | 185 |  |
| 2018 | 132 |  |
| 2019 | 65 |  |
| Thereafter | 183 |  |
| Total | $ | 1,139 |  |

[0000858877-14-000043:notes:17]
| (b) | Purchase Commitments with Contract Manufacturers and Suppliers |

[0000858877-14-000043:notes:18]
The Company purchases components from a variety of suppliers and uses several contract manufacturers to provide manufacturing services for its products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, the Company enters into agreements with contract manufacturers and suppliers that allow them to either procure inventory based upon criteria as defined by the Company or establish the parameters defining the Company’s requirements. A significant portion of the Company’s reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. In certain instances, these agreements allow the Company the option to cancel, reschedule, and adjust the Company’s requirements based on its business needs prior to firm orders being placed. As of October 25, 2014 and July 26, 2014, the Company had total purchase commitments for inventory of $4,299 million and $4,169 million, respectively.

[0000858877-14-000043:notes:19]
The Company records a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of its future demand forecasts consistent with the valuation of the Company’s excess and obsolete inventory. As of October 25, 2014 and July 26, 2014, the liability for these purchase commitments was $169 million and $162 million, respectively, and was included in other current liabilities.

[0000858877-14-000043:notes:20]
| (c) | Other Commitments |

[0000858877-14-000043:notes:21]
In connection with the Company’s business combinations, the Company has agreed to pay certain additional amounts contingent upon the achievement of certain agreed-upon technology, development, product, or other milestones or upon the continued employment with the Company of certain employees of the acquired entities.

[0000858877-14-000043:notes:22]
The following table summarizes the compensation expense related to acquisitions (in millions):

[0000858877-14-000043:notes:23]
|  | Three Months Ended |
|  | October 25, 2014 |  | October 26, 2013 |
| Compensation expense related to acquisitions | $ | 98 |  |  | $ | 304 |  |

[0000858877-14-000043:notes:24]
As of October 25, 2014, the Company estimated that future cash compensation expense of up to $528 million may be required to be recognized pursuant to the applicable business combination agreements, which included the remaining potential compensation expense related to Insieme Networks, Inc., as more fully discussed immediately below.

[0000858877-14-000043:notes:25]
Insieme Networks, Inc.    In the third quarter of fiscal 2012, the Company made an investment in Insieme Networks, Inc. ("Insieme"), an early stage company focused on research and development in the data center market.  As set forth in the agreement between the Company and Insieme, this investment included $100 million of funding and a license to certain of the Company’s technology.  Immediately prior to the call option exercise and acquisition described below, the Company owned approximately 83% of Insieme as a result of these investments and consolidated the results of Insieme in its Consolidated Financial Statements.  In connection with this investment, the Company and Insieme entered into a put/call option agreement that provided the Company with the right to purchase the remaining interests in Insieme.  In addition, the noncontrolling interest holders could require the Company to purchase their shares upon the occurrence of certain events.

[0000858877-14-000043:notes:26]
During the first quarter of fiscal 2014, the Company exercised its call option and entered into an agreement to purchase the remaining interests in Insieme.  The acquisition closed in the second quarter of fiscal 2014, at which time the former noncontrolling interest holders became eligible to receive up to two milestone payments, which will be determined using agreed-upon formulas based primarily on revenue for certain of Insieme’s products.  During the three months ended October 25, 2014 and October 26, 2013, the Company recorded compensation expense of $53 million and $257 million, respectively, related to the fair value of the vested portion of amounts that are expected to be earned by the former noncontrolling interest holders.  Continued vesting and changes to the fair value of the amounts probable of being earned will result in adjustments to the recorded compensation expense in future periods.  Based on the terms of the agreement, the Company has determined that the maximum amount that could be recorded as compensation expense by the Company is approximately $853 million, net of forfeitures and including the $469 million that has been expensed to date.  The milestone payments, if earned, are expected to be paid primarily during fiscal 2016 and fiscal 2017.

[0000858877-14-000043:notes:27]
The Company also has certain funding commitments, primarily related to its investments in privately held companies and venture funds, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $252 million and $255 million as of October 25, 2014 and July 26, 2014, respectively.

[0000858877-14-000043:notes:28]
| (d) | Product Warranties |

[0000858877-14-000043:notes:29]
The following table summarizes the activity related to the product warranty liability (in millions):

[0000858877-14-000043:notes:30]
|  | Three Months Ended |
|  | October 25, 2014 |  | October 26, 2013 |
| Balance at beginning of period | $ | 446 |  |  | $ | 402 |  |
| Provision for warranties issued | 143 |  |  | 196 |  |
| Payments | (153 | ) |  | (169 | ) |
| Balance at end of period | $ | 436 |  |  | $ | 429 |  |

[0000858877-14-000043:notes:31]
The Company accrues for warranty costs as part of its cost of sales based on associated material product costs, labor costs for technical support staff, and associated overhead. The Company’s products are generally covered by a warranty for periods ranging from 90 days to five years, and for some products the Company provides a limited lifetime warranty.

[0000858877-14-000043:notes:32]
| (e) | Financing and Other Guarantees |

[0000858877-14-000043:notes:33]
In the ordinary course of business, the Company provides financing guarantees for various third-party financing arrangements extended to channel partners and end-user customers. Payments under these financing guarantee arrangements were not material for the periods presented.

[0000858877-14-000043:notes:34]
Channel Partner Financing Guarantees   The Company facilitates arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, generally with payment terms ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, the Company guarantees a portion of these arrangements. The volume of channel partner financing was $6.3 billion for each of the three months ended October 25, 2014 and October 26, 2013. The balance of the channel partner financing subject to guarantees was $1.3 billion and $1.2 billion as of October 25, 2014 and July 26, 2014, respectively.

[0000858877-14-000043:notes:35]
End-User Financing Guarantees   The Company also provides financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. The volume of financing provided by third parties for leases and loans as to which the Company had provided guarantees was $26 million and $25 million for the three months ended October 25, 2014 and October 26, 2013.

[0000858877-14-000043:notes:36]
Financing Guarantee Summary   The aggregate amounts of financing guarantees outstanding at October 25, 2014 and July 26, 2014, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

[0000858877-14-000043:notes:37]
|  | October 25, 2014 |  | July 26, 2014 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 285 |  |  | $ | 263 |  |
| End user | 161 |  |  | 202 |  |
| Total | $ | 446 |  |  | $ | 465 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (126 | ) |  | $ | (127 | ) |
| End user | (130 | ) |  | (166 | ) |
| Total | $ | (256 | ) |  | $ | (293 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue | $ | 190 |  |  | $ | 172 |  |

[0000858877-14-000043:notes:38]
Other Guarantees   The Company’s other guarantee arrangements as of October 25, 2014 and July 26, 2014 that were subject to recognition and disclosure requirements were not material.

[0000858877-14-000043:notes:39]
| (f) | Supplier Component Remediation Liability |

[0000858877-14-000043:notes:40]
The Company has recorded in other current liabilities a liability for the expected remediation cost for certain products sold in prior fiscal years containing memory components manufactured by a single supplier between 2005 and 2010. These components are widely used across the industry and are included in a number of the Company's products. Defects in some of these components have caused products to fail after a power cycle event.  Defect rates due to this issue have been and are expected to be low. However, the Company has seen a small number of its customers experience a growing number of failures in their networks as a result of this component problem. Although the majority of these products are beyond the Company's warranty terms, the Company is proactively working with customers on mitigation.  Prior to the second quarter of fiscal 2014, the Company had a liability of $63 million related to this issue for expected remediation costs based on the intended approach at that time. In February 2014, on the basis of the growing number of failures described above, the Company decided to expand its approach, which resulted in an additional charge to product cost of sales of $655 million being recorded for the second quarter of fiscal 2014.  The remaining supplier component remediation liability as of October 25, 2014 and July 26, 2014 was $639 million and $670 million, respectively.

[0000858877-14-000043:notes:41]
| (g) | Indemnifications |

[0000858877-14-000043:notes:42]
In the normal course of business, the Company indemnifies other parties, including customers, lessors, and parties to other transactions with the Company, with respect to certain matters. The Company has agreed to hold such parties harmless against losses arising from a breach of representations or covenants or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim.

[0000858877-14-000043:notes:43]
The Company has an obligation to indemnify certain expenses pursuant to such agreements in a case involving certain of the Company’s service provider customers that are subject to patent infringement claims asserted by Sprint Communications Company, L.P. (“Sprint”) in the United States District Court for the District of Kansas filed on December 19, 2011 (including one case that was later transferred to the District of Delaware).  Sprint alleges that the service providers infringe Sprint’s patents by offering Voice over Internet Protocol-based telephone services utilizing products provided by the Company and other manufacturers.  Sprint is seeking monetary damages.  Trial dates have been set for the first half of calendar year 2015.  The parties intend to conduct a mediation process later this calendar year, and the Company may be asked to participate.  The mediation could result in a resolution of the case for some or all of the Company's service provider customers.  The Company believes that the service providers have strong defenses and that its products do not infringe the patents subject to the claims.  Due to the uncertainty surrounding the litigation process, which involves numerous defendants, the Company is unable to reasonably estimate the ultimate outcome of this litigation at this time.  Should the plaintiff prevail in litigation, mediation, or settlement, the Company may have an obligation to indemnify its service provider customers for damages, mediation awards, or settlement amounts arising from their use of Cisco products.

[0000858877-14-000043:notes:44]
In addition, the Company has entered into indemnification agreements with its officers and directors, and the Company’s Amended and Restated Bylaws contain similar indemnification obligations to the Company’s agents.

[0000858877-14-000043:notes:45]
It is not possible to determine the maximum potential amount under these indemnification agreements due to the Company’s limited history with prior indemnification claims and the unique facts and circumstances involved in each particular agreement. Historically, payments made by the Company under these agreements have not had a material effect on the Company’s operating results, financial position, or cash flows.

[0000858877-14-000043:notes:46]
| (h) | Legal Proceedings |

[0000858877-14-000043:notes:47]
Brazil    Brazilian authorities have investigated the Company’s Brazilian subsidiary and certain of its current and former employees, as well as a Brazilian importer of the Company’s products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against the Company’s Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years. In the first quarter of fiscal 2013, the Brazilian federal tax authorities asserted an additional claim against the Company’s Brazilian subsidiary based on a theory of joint liability with respect to an alleged underpayment of income taxes, social taxes, interest, and penalties by a Brazilian distributor.

[0000858877-14-000043:notes:48]
The asserted claims by Brazilian federal tax authorities are for calendar years 2003 through 2008, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to approximately $348 million for the alleged evasion of import and other taxes, approximately $1.3 billion for interest, and approximately $1.5 billion for various penalties, all determined using an exchange rate as of October 25, 2014. The Company has completed a thorough review of the matters and believes the asserted claims against the Company’s Brazilian subsidiary are without merit, and the Company is defending the claims vigorously. While the Company believes there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, the Company is unable to determine the likelihood of an unfavorable outcome against its Brazilian subsidiary and is unable to reasonably estimate a range of loss, if any. The Company does not expect a final judicial determination for several years.

[0000858877-14-000043:notes:49]
Russia and the Commonwealth of Independent States    At the request of the U.S. Securities and Exchange Commission (SEC) and the U.S. Department of Justice, the Company is conducting an investigation into allegations which the Company and those agencies received regarding possible violations of the U.S. Foreign Corrupt Practices Act involving business activities of the Company's operations in Russia and certain of the Commonwealth of Independent States, and by certain resellers of the Company’s products in those countries.  The Company takes any such allegations very seriously and is fully cooperating with and sharing the results of its investigation with the SEC and the Department of Justice.  While the outcome of the Company's investigation is currently not determinable, the Company does not expect that it will have a material adverse effect on its consolidated financial position, results of operations, or cash flows. The countries that are the subject of the investigation collectively comprise less than 2% of the Company’s revenues.

[0000858877-14-000043:notes:50]
Rockstar    The Company and some of its service provider customers are subject to patent claims asserted in December 2013 in the Eastern District of Texas and the District of Delaware by subsidiaries of the Rockstar Consortium ("Rockstar").  Rockstar, whose members include Apple, Microsoft, LM Ericsson, Sony, and Blackberry, purchased a portfolio of patents out of the Nortel Networks’ bankruptcy proceedings (the “Nortel Portfolio”). Rockstar’s subsidiaries allege that some of the Company’s NGN Routing, Switching and Collaboration products, as well as video solutions deployed by its service provider customers, infringe some of the patents in the Nortel Portfolio.  A binding letter of intent has been executed with Rockstar regarding the Nortel Portfolio.  The transaction, which is subject to various closing conditions, will result in various technology companies, including but not limited to the Company and the various service provider customers described above, obtaining a license to that portfolio. The parties agreed to stay the litigation pending negotiation of agreements, and when the transaction closes, Rockstar will dismiss all litigation brought against the participating companies.  In connection with this matter, during the first quarter of fiscal 2015 the Company recorded a charge to product cost of sales of $188 million.

[0000858877-14-000043:notes:51]
In addition, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, the Company does not expect that the ultimate costs to resolve these matters will have a material adverse effect on its consolidated financial position, results of operations, or cash flows.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000858877-14-000043:notes:52]
[same as prior period, unchanged from 0000858877-14-000014:notes:65]

[0000858877-14-000043:notes:53]
The components of AOCI, net of tax, and the other comprehensive income (loss), excluding noncontrolling interest, for the three months ended October 25, 2014 and October 26, 2013 are summarized as follows (in millions):

[0000858877-14-000043:notes:54]
| October 25, 2014 | Net Unrealized Gains on Investments |  | Net Unrealized Gains (Losses) Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Other |  | Accumulated Other Comprehensive Income |
| BALANCE AT JULY 26, 2014 | $ | 424 |  |  | $ | (12 | ) |  | $ | 265 |  |  | $ | 677 |  |
| Other comprehensive income (loss) before reclassifications attributable to Cisco Systems, Inc. | (36 | ) |  | (56 | ) |  | (161 | ) |  | (253 | ) |
| (Gains) losses reclassified out of other comprehensive income | (7 | ) |  | 4 |  |  | — |  |  | (3 | ) |
| Tax benefit (expense) | 16 |  |  | 3 |  |  | 11 |  |  | 30 |  |
| BALANCE AT OCTOBER 25, 2014 | $ | 397 |  |  | $ | (61 | ) |  | $ | 115 |  |  | $ | 451 |  |

[0000858877-14-000043:notes:55]
| October 26, 2013 | Net Unrealized Gains on Investments |  | Net Unrealized Gains (Losses) Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Other |  | Accumulated Other Comprehensive Income |
| BALANCE AT JULY 27, 2013 | $ | 379 |  |  | $ | 8 |  |  | $ | 221 |  |  | $ | 608 |  |
| Other comprehensive income (loss) before reclassifications attributable to Cisco Systems, Inc. | 170 |  |  | 38 |  |  | 76 |  |  | 284 |  |
| (Gains) losses reclassified out of other comprehensive income | (83 | ) |  | (9 | ) |  | — |  |  | (92 | ) |
| Tax benefit (expense) | (22 | ) |  | (3 | ) |  | (3 | ) |  | (28 | ) |
| BALANCE AT OCTOBER 26, 2013 | $ | 444 |  |  | $ | 34 |  |  | $ | 294 |  |  | $ | 772 |  |

[0000858877-14-000043:notes:56]
[same as prior period, unchanged from 0000858877-14-000014:notes:68]

[0000858877-14-000043:notes:57]
|  |  | Three Months Ended |  |  |
|  |  | October 25, 2014 |  | October 26, 2013 |  |  |
| Comprehensive Income Components |  | Income Before Taxes |  | Line Item in Statements of Operations |
| Net unrealized gains on available-for-sale investments |  |  |  |  |  |  |
|  |  | $ | 7 |  |  | $ | 83 |  |  | Other income (loss), net |
| Net unrealized gains and (losses) on cash flow hedging instruments: |  |  |  |  |  |  |
| Foreign currency derivatives |  | (3 | ) |  | 7 |  |  | Operating expenses |
| Foreign currency derivatives |  | (1 | ) |  | 2 |  |  | Cost of sales—service |
|  |  | (4 | ) |  | 9 |  |  |  |
| Total amounts reclassified out of other comprehensive income |  | $ | 3 |  |  | $ | 92 |  |  |  |


## us-gaap:DebtDisclosureTextBlock

[0000858877-14-000043:notes:58]
| 10. | Borrowings |

[0000858877-14-000043:notes:59]
| (a) | Short-Term Debt |

[0000858877-14-000043:notes:60]
The following table summarizes the Company’s short-term debt (in millions, except percentages):

[0000858877-14-000043:notes:61]
|  | October 25, 2014 |  | July 26, 2014 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 1,350 |  |  | 1.38 | % |  | $ | 500 |  |  | 3.11 | % |
| Other short-term debt | 7 |  |  | 2.76 | % |  | 8 |  |  | 2.67 | % |
| Total short-term debt | $ | 1,357 |  |  |  |  | $ | 508 |  |  |  |

[0000858877-14-000043:notes:62]
In fiscal 2011, the Company established a short-term debt financing program of up to $3.0 billion through the issuance of commercial paper notes. The Company uses the proceeds from the issuance of commercial paper notes for general corporate purposes. The Company had no commercial paper notes outstanding as of each of October 25, 2014 and July 26, 2014.

[0000858877-14-000043:notes:63]
The effective interest rate on the current portion of long-term debt includes the impact of interest rate swaps, as discussed further in "

[0000858877-14-000043:notes:64]
| (b) | Long-Term Debt |

[0000858877-14-000043:notes:65]
."  Other notes and borrowings consist of the short-term portion of secured borrowings associated with customer financing arrangements.  These notes and credit facilities were subject to various terms and foreign currency market interest rates pursuant to individual financial arrangements between the financing institution and the applicable foreign subsidiary.

[0000858877-14-000043:notes:66]
On November 17, 2014, upon the maturity of the Company’s 2014 Fixed-Rate Notes (2.90%), the Company repaid an aggregate principal amount of $500 million.

[0000858877-14-000043:notes:67]
(b)

[0000858877-14-000043:notes:68]
Long-Term Debt

[0000858877-14-000043:notes:69]
The following table summarizes the Company’s long-term debt (in millions, except percentages):

[0000858877-14-000043:notes:70]
|  |  |  | October 25, 2014 |  | July 26, 2014 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.05% | September 3, 2015 |  | $ | 850 |  |  | 0.36% |  | $ | 850 |  |  | 0.35% |
| Three-month LIBOR plus 0.28% | March 3, 2017 |  | 1,000 |  |  | 0.57% |  | 1,000 |  |  | 0.56% |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | 500 |  |  | 0.79% |  | 500 |  |  | 0.78% |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 2.90% | November 17, 2014 |  | 500 |  |  | 3.11% |  | 500 |  |  | 3.11% |
| 5.50% | February 22, 2016 |  | 3,000 |  |  | 3.05% |  | 3,000 |  |  | 3.04% |
| 1.10% | March 3, 2017 |  | 2,400 |  |  | 0.55% |  | 2,400 |  |  | 0.56% |
| 3.15% | March 14, 2017 |  | 750 |  |  | 0.80% |  | 750 |  |  | 0.79% |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 4.69% |  | 2,000 |  |  | 4.69% |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 0.77% |  | 1,750 |  |  | 0.77% |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 2.98% |  | 2,500 |  |  | 2.98% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 0.93% |  | 500 |  |  | 0.93% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1.04% |  | 1,000 |  |  | 1.05% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Other long-term debt |  |  | 2 |  |  | 2.08% |  | 4 |  |  | 2.39% |
| Total |  |  | 20,752 |  |  |  |  | 20,754 |  |  |  |
| Unaccreted discount |  |  | (62 | ) |  |  |  | (63 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 275 |  |  |  |  | 210 |  |  |  |
| Total |  |  | $ | 20,965 |  |  |  |  | $ | 20,901 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 1,350 |  |  |  |  | $ | 500 |  |  |  |
| Long-term debt |  |  | 19,615 |  |  |  |  | 20,401 |  |  |  |
| Total |  |  | $ | 20,965 |  |  |  |  | $ | 20,901 |  |  |  |

[0000858877-14-000043:notes:71]
To achieve its interest rate risk management objectives, the Company entered into interest rate swaps in prior periods with an aggregate notional amount of $10.4 billion designated as fair value hedges of certain of its fixed-rate senior notes. In effect, these swaps convert the fixed interest rates of the fixed-rate notes to floating interest rates based on the London InterBank Offered Rate (LIBOR). The gains and losses related to changes in the fair value of the interest rate swaps substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates. For additional information, see Note 11.

[0000858877-14-000043:notes:72]
The effective rates for the fixed-rate debt include the interest on the notes, the accretion of the discount, and, if applicable, adjustments related to hedging. Interest is payable semiannually on each class of the senior fixed-rate notes and payable quarterly on the floating-rate notes. Each of the senior fixed-rate notes is redeemable by the Company at any time, subject to a make-whole premium.

[0000858877-14-000043:notes:73]
The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to the Company’s short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of October 25, 2014, the Company was in compliance with all debt covenants.

[0000858877-14-000043:notes:74]
As of October 25, 2014, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

[0000858877-14-000043:notes:75]
| Fiscal Year | Amount |
| 2015 (remaining nine months) | $ | 500 |  |
| 2016 | 3,851 |  |
| 2017 | 4,151 |  |
| 2018 | — |  |
| 2019 | 4,250 |  |
| Thereafter | 8,000 |  |
| Total | $ | 20,752 |  |

[0000858877-14-000043:notes:76]
| (c) | Credit Facility |

[0000858877-14-000043:notes:77]
On February 17, 2012, the Company entered into a credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on February 17, 2017. Any advances under the credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (i) the higher of the Federal Funds rate plus 0.50%, Bank of America’s “prime rate” as announced from time to time, or one-month LIBOR plus 1.00% or (ii) LIBOR plus a margin that is based on the Company’s senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc. The credit agreement requires the Company to comply with certain covenants, including that it maintain an interest coverage ratio as defined in the agreement. As of October 25, 2014, the Company was in compliance with the required interest coverage ratio and the other covenants, and the Company had not borrowed any funds under the credit facility.

[0000858877-14-000043:notes:78]
The Company may also, upon the agreement of either the existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and/or extend the expiration date of the credit facility by up to two additional years, or up to February 17, 2019.


## us-gaap:DeferredRevenueByArrangementDisclosureTextBlock

[0000858877-14-000043:notes:79]
| Deferred revenue: |  |  |  |  |
| Service |  | $ | 9,029 |  |  | $ | 9,640 |  |
| Product: |  |  |  |  |
| Unrecognized revenue on product shipments and other deferred revenue |  | 4,056 |  |  | 3,924 |  |
| Cash receipts related to unrecognized revenue from two-tier distributors |  | 659 |  |  | 578 |  |
| Total product deferred revenue |  | 4,715 |  |  | 4,502 |  |
| Total |  | $ | 13,744 |  |  | $ | 14,142 |  |
| Reported as: |  |  |  |  |
| Current |  | $ | 9,449 |  |  | $ | 9,478 |  |
| Noncurrent |  | 4,295 |  |  | 4,664 |  |
| Total |  | $ | 13,744 |  |  | $ | 14,142 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000858877-14-000043:notes:80]
[same as prior period, unchanged from 0000858877-14-000014:notes:93]

[0000858877-14-000043:notes:81]
[same as prior period, unchanged from 0000858877-14-000014:notes:94]

[0000858877-14-000043:notes:82]
[same as prior period, unchanged from 0000858877-14-000014:notes:95]

[0000858877-14-000043:notes:83]
[same as prior period, unchanged from 0000858877-14-000014:notes:96]

[0000858877-14-000043:notes:84]
|  | DERIVATIVE ASSETS |  | DERIVATIVE LIABILITIES |
|  | Balance Sheet Line Item |  | October 25, 2014 |  | July 26, 2014 |  | Balance Sheet Line Item |  | October 25, 2014 |  | July 26, 2014 |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | $ | 8 |  |  | $ | 7 |  |  | Other current liabilities |  | $ | 46 |  |  | $ | 6 |  |
| Interest rate derivatives | Other assets |  | 217 |  |  | 148 |  |  | Other long-term liabilities |  | — |  |  | 3 |  |
| Equity derivatives | Other current assets |  | — |  |  | — |  |  | Other current liabilities |  | 50 |  |  | 56 |  |
| Total |  |  | 225 |  |  | 155 |  |  |  |  | 96 |  |  | 65 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | 2 |  |  | 3 |  |  | Other current liabilities |  | 3 |  |  | 2 |  |
| Equity derivatives | Other assets |  | — |  |  | 2 |  |  | Other long-term liabilities |  | — |  |  | — |  |
| Total |  |  | 2 |  |  | 5 |  |  |  |  | 3 |  |  | 2 |  |
| Total |  |  | $ | 227 |  |  | $ | 160 |  |  |  |  | $ | 99 |  |  | $ | 67 |  |

[0000858877-14-000043:notes:85]
[same as prior period, unchanged from 0000858877-14-000014:notes:98]

[0000858877-14-000043:notes:86]
| GAINS (LOSSES) RECOGNIZEDIN OCI ON DERIVATIVES FOR THE THREE MONTHS ENDED (EFFECTIVE PORTION) |  | GAINS (LOSSES) RECLASSIFIED FROMAOCI INTO INCOME FOR THETHREE MONTHS ENDED (EFFECTIVE PORTION) |
|  |  | October 25, 2014 |  | October 26, 2013 |  | Line Item in Statements of Operations |  | October 25, 2014 |  | October 26, 2013 |
| Derivatives designated as cash flow hedging instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | (56 | ) |  | $ | 38 |  |  | Operating expenses |  | $ | (3 | ) |  | $ | 7 |  |
|  |  |  |  |  |  | Cost of sales—service |  | (1 | ) |  | 2 |  |
| Total |  | $ | (56 | ) |  | $ | 38 |  |  |  |  | $ | (4 | ) |  | $ | 9 |  |
| Derivatives designated as net investment hedging instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | 20 |  |  | $ | (19 | ) |  | Other income (loss), net |  | $ | — |  |  | $ | — |  |

[0000858877-14-000043:notes:87]
As of October 25, 2014, the Company estimates that approximately $52 million of net derivative losses related to its cash flow hedges included in accumulated other comprehensive income (AOCI) will be reclassified into earnings within the next 12 months.

[0000858877-14-000043:notes:88]
[same as prior period, unchanged from 0000858877-14-000014:notes:102]

[0000858877-14-000043:notes:89]
|  |  |  |  | GAINS (LOSSES) ONDERIVATIVEINSTRUMENTS FOR THETHREE MONTHS ENDED |  | GAINS (LOSSES)RELATED TO HEDGEDITEMS FOR THE THREEMONTHS ENDED |
| Derivatives Designated as Fair Value Hedging Instruments |  | Line Item in Statements of Operations |  | October 25, 2014 |  | October 26, 2013 |  | October 25, 2014 |  | October 26, 2013 |
| Equity derivatives |  | Other income (loss), net |  | $ | 6 |  |  | $ | (35 | ) |  | $ | (6 | ) |  | $ | 35 |  |
| Interest rate derivatives |  | Interest expense |  | 70 |  |  | 18 |  |  | (73 | ) |  | (20 | ) |
| Total |  |  |  | $ | 76 |  |  | $ | (17 | ) |  | $ | (79 | ) |  | $ | 15 |  |

[0000858877-14-000043:notes:90]
[same as prior period, unchanged from 0000858877-14-000014:notes:105]

[0000858877-14-000043:notes:91]
|  |  |  |  | GAINS (LOSSES) FOR THETHREE MONTHS ENDED |
| Derivatives Not Designated as Hedging Instruments |  | Line Item in Statements of Operations |  | October 25, 2014 |  | October 26, 2013 |
| Foreign currency derivatives |  | Other income (loss), net |  | $ | (58 | ) |  | $ | 43 |  |
| Total return swaps—deferred compensation |  | Operating expenses |  | (13 | ) |  | 17 |  |
| Equity derivatives |  | Other income (loss), net |  | (4 | ) |  | 11 |  |
| Total |  |  |  | $ | (75 | ) |  | $ | 71 |  |

[0000858877-14-000043:notes:92]
[same as prior period, unchanged from 0000858877-14-000014:notes:107]

[0000858877-14-000043:notes:93]
|  | October 25, 2014 |  | July 26, 2014 |
| Derivatives designated as hedging instruments: |  |  |  |
| Foreign currency derivatives—cash flow hedges | $ | 2,614 |  |  | $ | 1,618 |  |
| Interest rate derivatives | 10,400 |  |  | 10,400 |  |
| Net investment hedging instruments | 372 |  |  | 345 |  |
| Equity derivatives | 238 |  |  | 238 |  |
| Derivatives not designated as hedging instruments: |  |  |  |
| Foreign currency derivatives | 2,445 |  |  | 2,528 |  |
| Total return swaps—deferred compensation | 438 |  |  | 428 |  |
| Total | $ | 16,507 |  |  | $ | 15,557 |  |

[0000858877-14-000043:notes:94]
[same as prior period, unchanged from 0000858877-14-000014:notes:109]

[0000858877-14-000043:notes:95]
[same as prior period, unchanged from 0000858877-14-000014:notes:110]

[0000858877-14-000043:notes:96]
|  | OFFSETTING OF DERIVATIVE ASSETS |
|  | Gross Amounts Offset in Consolidated Balance Sheets |  | Gross Amounts Not Offset in the Consolidated Balance Sheets, but with Legal Rights to Offset |
| October 25, 2014 | Gross Amount of Recognized Assets |  | Gross Amounts Offset in Consolidated Balance Sheets |  | Net Amount Presented on Consolidated Balance Sheets |  | Gross Derivative Amounts with Legal Rights to Offset |  | Cash Collateral Received |  | Net Amount |
| Derivatives | $ | 227 |  |  | $ | — |  |  | $ | 227 |  |  | $ | (59 | ) |  | $ | (115 | ) |  | $ | 53 |  |

[0000858877-14-000043:notes:97]
|  | OFFSETTING OF DERIVATIVE LIABILITIES |
|  | Gross Amounts Offset in Consolidated Balance Sheets |  | Gross Amounts Not Offset in the Consolidated Balance Sheets, but with Legal Rights to Offset |
| October 25, 2014 | Gross Amount of Recognized Liabilities |  | Gross Amounts Offset in Consolidated Balance Sheets |  | Net Amount Presented on Consolidated Balance Sheets |  | Gross Derivative Amounts with Legal Rights to Offset |  | Cash Collateral Pledged |  | Net Amount |
| Derivatives | $ | 99 |  |  | $ | — |  |  | $ | 99 |  |  | $ | (59 | ) |  | $ | — |  |  | $ | 40 |  |

[0000858877-14-000043:notes:98]
|  | OFFSETTING OF DERIVATIVE ASSETS |
|  | Gross Amounts Offset in Consolidated Balance Sheets |  | Gross Amounts Not Offset in the Consolidated Balance Sheets, but with Legal Rights to Offset |
| July 26, 2014 | Gross Amount of Recognized Assets |  | Gross Amounts Offset in Consolidated Balance Sheets |  | Net Amount Presented on Consolidated Balance Sheets |  | Gross Derivative Amounts with Legal Rights to Offset |  | Cash Collateral Received |  | Net Amount |
| Derivatives | $ | 160 |  |  | $ | — |  |  | $ | 160 |  |  | $ | (39 | ) |  | $ | (60 | ) |  | $ | 61 |  |

[0000858877-14-000043:notes:99]
|  | OFFSETTING OF DERIVATIVE LIABILITIES |
|  | Gross Amounts Offset in Consolidated Balance Sheets |  | Gross Amounts Not Offset in the Consolidated Balance Sheets, but with Legal Rights to Offset |
| July 26, 2014 | Gross Amount of Recognized Liabilities |  | Gross Amounts Offset in Consolidated Balance Sheets |  | Net Amount Presented on Consolidated Balance Sheets |  | Gross Derivative Amounts with Legal Rights to Offset |  | Cash Collateral Pledged |  | Net Amount |
| Derivatives | $ | 67 |  |  | $ | — |  |  | $ | 67 |  |  | $ | (39 | ) |  | $ | (1 | ) |  | $ | 27 |  |

[0000858877-14-000043:notes:100]
[same as prior period, unchanged from 0000858877-14-000014:notes:115]

[0000858877-14-000043:notes:101]
[same as prior period, unchanged from 0000858877-14-000014:notes:116]

[0000858877-14-000043:notes:102]
The Company hedges forecasted foreign currency transactions related to certain operating expenses and service cost of sales with currency options and forward contracts. These currency options and forward contracts, designated as cash flow hedges, generally have maturities of less than 18 months. The Company assesses effectiveness based on changes in total fair value of the derivatives. The effective portion of the derivative instrument’s gain or loss is initially reported as a component of AOCI and subsequently reclassified into earnings when the hedged exposure affects earnings. The ineffective portion, if any, of the gain or loss is reported in earnings immediately. During the periods presented, the Company did not discontinue any cash flow hedges for which it was probable that a forecasted transaction would not occur.

[0000858877-14-000043:notes:103]
[same as prior period, unchanged from 0000858877-14-000014:notes:118]

[0000858877-14-000043:notes:104]
[same as prior period, unchanged from 0000858877-14-000014:notes:119]

[0000858877-14-000043:notes:105]
[same as prior period, unchanged from 0000858877-14-000014:notes:120]

[0000858877-14-000043:notes:106]
Interest Rate Derivatives, Investments   The Company’s primary objective for holding fixed income securities is to achieve an appropriate investment return consistent with preserving principal and managing risk. To realize these objectives, the Company may utilize interest rate swaps or other derivatives designated as fair value or cash flow hedges. As of October 25, 2014 and July 26, 2014, the Company did not have any outstanding interest rate derivatives related to its fixed income securities.

[0000858877-14-000043:notes:107]
Interest Rate Derivatives Designated as Fair Value Hedge, Long-Term Debt   In fiscal 2014 and 2013, the Company entered into interest rate swaps designated as fair value hedges related to fixed-rate senior notes that are due on various dates from 2017 through 2024. In the periods prior to fiscal 2013, the Company entered into interest rate swaps designated as fair value hedges related to fixed-rate senior notes that are due in 2016 and 2017. Under these interest rate swaps, the Company receives fixed-rate interest payments and makes interest payments based on LIBOR plus a fixed number of basis points. The effect of such swaps is to convert the fixed interest rates of the senior fixed-rate notes to floating interest rates based on LIBOR. The gains and losses related to changes in the fair value of the interest rate swaps are included in interest expense and substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates. The fair value of the interest rate swaps was reflected in other assets and other long-term liabilities.

[0000858877-14-000043:notes:108]
[same as prior period, unchanged from 0000858877-14-000014:notes:123]

[0000858877-14-000043:notes:109]
The Company may hold equity securities for strategic purposes or to diversify its overall investment portfolio. The publicly traded equity securities in the Company’s portfolio are subject to price risk. To manage its exposure to changes in the fair value of certain equity securities, the Company has entered into equity derivatives that are designated as fair value hedges. The changes in the value of the hedging instruments are included in other income (loss), net, and offset the change in the fair value of the underlying hedged investment. In addition, the Company periodically enters into equity derivatives that are not designated as accounting hedges. The changes in the fair value of these derivatives are also included in other income (loss), net.

[0000858877-14-000043:notes:110]
[same as prior period, unchanged from 0000858877-14-000014:notes:125]

[0000858877-14-000043:notes:111]
[same as prior period, unchanged from 0000858877-14-000014:notes:126]

[0000858877-14-000043:notes:112]
For the periods presented, amounts excluded from the assessment of hedge effectiveness were not material for fair value, cash flow, and net investment hedges. In addition, hedge ineffectiveness for fair value, cash flow, and net investment hedges was not material for any of the periods presented.

[0000858877-14-000043:notes:113]
[same as prior period, unchanged from 0000858877-14-000014:notes:128]

[0000858877-14-000043:notes:114]
For certain derivative instruments, the Company and its counterparties have entered into arrangements requiring the party that is in a liability position from a mark-to-market standpoint to post cash collateral to the other party.  See further discussion under “(b) Offsetting of Derivative Instruments” above.

[0000858877-14-000043:notes:115]
In addition, certain derivative instruments are executed under agreements that have provisions requiring the Company and the counterparty to maintain a specified credit rating from certain credit-rating agencies. Under such agreements, if the Company’s or the counterparty’s credit rating falls below a specified credit rating, either party has the right to request collateral on the derivatives’ net liability position. No such derivatives were in a net liability position as of October 25, 2014.  The fair market value of such derivatives was $3 million as of July 26, 2014.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000858877-14-000043:notes:116]
[same as prior period, unchanged from 0000858877-14-000014:notes:131]

[0000858877-14-000043:notes:117]
[same as prior period, unchanged from 0000858877-14-000014:notes:132]

[0000858877-14-000043:notes:118]
Stock Incentive Plan Program Description    As of October 25, 2014, the Company had four stock incentive plans: the 2005 Stock Incentive Plan (the “2005 Plan”); the 1996 Stock Incentive Plan (the “1996 Plan”); the Cisco Systems, Inc. SA Acquisition Long-Term Incentive Plan (the “SA Acquisition Plan”); and the Cisco Systems, Inc. WebEx Acquisition Long-Term Incentive Plan (the “WebEx Acquisition Plan”). In addition, the Company has, in connection with the acquisitions of various companies, assumed the share-based awards granted under stock incentive plans of the acquired companies or issued share-based awards in replacement thereof. Share-based awards are designed to reward employees for their long-term contributions to the Company and provide incentives for them to remain with the Company. The number and frequency of share-based awards are based on competitive practices, operating results of the Company, government regulations, and other factors. Since the inception of the stock incentive plans, the Company has granted share-based awards to a significant percentage of its employees, and the majority has been granted to employees below the vice president level. The Company’s primary stock incentive plans are summarized as follows:

[0000858877-14-000043:notes:119]
2005 Plan    As of October 25, 2014, the maximum number of shares issuable under the 2005 Plan over its term was 694 million shares, plus the number of any shares underlying awards outstanding on November 15, 2007 under the 1996 Plan, the SA Acquisition Plan, and the WebEx Acquisition Plan that are forfeited or are terminated for any other reason before being exercised or settled. If any awards granted under the 2005 Plan are forfeited or are terminated for any other reason before being exercised or settled, the unexercised or unsettled shares underlying the awards will again be available under the 2005 Plan.  Starting November 19, 2013, shares withheld by the Company from an award other than a stock option or stock appreciation right to satisfy withholding tax liabilities resulting from such award will again be available for issuance, based on the fungible share ratio in effect on the date of grant.

[0000858877-14-000043:notes:120]
[same as prior period, unchanged from 0000858877-14-000014:notes:135]

[0000858877-14-000043:notes:121]
The stock options will generally become exercisable for 20% or 25% of the option shares one year from the date of grant and then ratably over the following 48 months or 36 months, respectively. Time-based stock grants and time-based RSUs will generally vest with respect to 20% or 25% of the shares or share units covered by the grant on each of the first through fifth or fourth anniversaries of the date of the grant, respectively. Performance-based and market-based RSUs typically vest at the end of the three-year requisite service period or earlier if the award recipient meets certain retirement eligibility conditions. The Compensation and Management Development Committee of the Board of Directors has the discretion to use different vesting schedules. Stock appreciation rights may be awarded in combination with stock options or stock grants, and such awards shall provide that the stock appreciation rights will not be exercisable unless the related stock options or stock grants are forfeited. Stock grants may be awarded in combination with non-statutory stock options, and such awards may provide that the stock grants will be forfeited in the event that the related non-statutory stock options are exercised.

[0000858877-14-000043:notes:122]
1996 Plan   The 1996 Plan expired on December 31, 2006, and the Company can no longer make equity awards under the 1996 Plan. The maximum number of shares issuable over the term of the 1996 Plan was 2.5 billion shares. Stock options granted under the 1996 Plan have an exercise price of at least 100% of the fair market value of the underlying stock on the grant date and expire no later than nine years from the grant date. The stock options generally became exercisable for 20% or 25% of the option shares one year from the date of grant and then ratably over the following 48 months or 36 months, respectively.  Certain other grants utilized a 60-month ratable vesting schedule. In addition, the Board of Directors, or other committees administering the 1996 Plan, had the discretion to use a different vesting schedule and did so from time to time.

[0000858877-14-000043:notes:123]
[same as prior period, unchanged from 0000858877-14-000014:notes:138]

[0000858877-14-000043:notes:124]
[same as prior period, unchanged from 0000858877-14-000014:notes:139]

[0000858877-14-000043:notes:125]
The Company has an Employee Stock Purchase Plan, which includes its subplan named the International Employee Stock Purchase Plan (together, the “Purchase Plan”), under which 471.4 million shares of the Company’s common stock have been reserved for issuance as of October 25, 2014. Eligible employees are offered shares through a 24-month offering period, which consists of four consecutive 6-month purchase periods. Employees may purchase a limited number of shares of the Company’s stock at a discount of up to 15% of the lesser of the market value at the beginning of the offering period or the end of each 6-month purchase period. The Purchase Plan is scheduled to terminate on January 3, 2020. No shares were issued under the Purchase Plan during either of the three months ended October 25, 2014 and October 26, 2013.  As of October 25, 2014, 25 million shares were available for issuance under the Purchase Plan.

[0000858877-14-000043:notes:126]
[same as prior period, unchanged from 0000858877-14-000014:notes:141]

[0000858877-14-000043:notes:127]
[same as prior period, unchanged from 0000858877-14-000014:notes:142]

[0000858877-14-000043:notes:128]
|  | Three Months Ended |
|  | October 25, 2014 |  | October 26, 2013 |
| Cost of sales—product | $ | 11 |  |  | $ | 10 |  |
| Cost of sales—service | 37 |  |  | 33 |  |
| Share-based compensation expense in cost of sales | 48 |  |  | 43 |  |
| Research and development | 119 |  |  | 92 |  |
| Sales and marketing | 147 |  |  | 123 |  |
| General and administrative | 59 |  |  | 54 |  |
| Restructuring and other charges | (4 | ) |  | (3 | ) |
| Share-based compensation expense in operating expenses | 321 |  |  | 266 |  |
| Total share-based compensation expense | $ | 369 |  |  | $ | 309 |  |
| Income tax benefit for share-based compensation | $ | 94 |  |  | $ | 78 |  |

[0000858877-14-000043:notes:129]
As of October 25, 2014, the total compensation cost related to unvested share-based awards not yet recognized was $2.3 billion, which is expected to be recognized over approximately 2.4 years on a weighted-average basis.

[0000858877-14-000043:notes:130]
[same as prior period, unchanged from 0000858877-14-000014:notes:145]

[0000858877-14-000043:notes:131]
[same as prior period, unchanged from 0000858877-14-000014:notes:146]

[0000858877-14-000043:notes:132]
|  | Share-BasedAwards Availablefor Grant |
| BALANCE AT July 27, 2013 | 228 |  |
| Restricted stock, stock units, and other share-based awards granted | (98 | ) |
| Share-based awards canceled/forfeited/expired | 36 |  |
| Additional shares reserved | 135 |  |
| Shares withheld for taxes and not issued | 6 |  |
| Other | 3 |  |
| BALANCE AT July 26, 2014 | 310 |  |
| Restricted stock, stock units, and other share-based awards granted | (27 | ) |
| Share-based awards canceled/forfeited/expired | 16 |  |
| Shares withheld for taxes and not issued | 20 |  |
| BALANCE AT October 25, 2014 | 319 |  |

[0000858877-14-000043:notes:133]
[same as prior period, unchanged from 0000858877-14-000014:notes:148]

[0000858877-14-000043:notes:134]
[same as prior period, unchanged from 0000858877-14-000014:notes:149]

[0000858877-14-000043:notes:135]
[same as prior period, unchanged from 0000858877-14-000014:notes:150]

[0000858877-14-000043:notes:136]
|  | Restricted Stock/Stock Units |  | Weighted-AverageGrant Date FairValue per Share |  | Aggregated FairMarket Value |
| UNVESTED BALANCE AT JULY 27, 2013 | 143 |  |  | $ | 18.80 |  |  |  |
| Granted and assumed | 72 |  |  | 20.85 |  |  |  |
| Vested | (53 | ) |  | 19.55 |  |  | $ | 1,229 |  |
| Canceled/forfeited | (13 | ) |  | 18.61 |  |  |  |
| UNVESTED BALANCE AT JULY 26, 2014 | 149 |  |  | 19.54 |  |  |  |
| Granted and assumed | 15 |  |  | 23.17 |  |  |  |
| Vested | (38 | ) |  | 19.51 |  |  | $ | 968 |  |
| Canceled/forfeited | (6 | ) |  | 19.48 |  |  |  |
| UNVESTED BALANCE AT OCTOBER 25, 2014 | 120 |  |  | $ | 20.02 |  |  |  |

[0000858877-14-000043:notes:137]
[same as prior period, unchanged from 0000858877-14-000014:notes:152]

[0000858877-14-000043:notes:138]
[same as prior period, unchanged from 0000858877-14-000014:notes:153]

[0000858877-14-000043:notes:139]
|  | STOCK OPTIONS OUTSTANDING |
|  | NumberOutstanding |  | Weighted-AverageExercise Price per Share |
| BALANCE AT JULY 27, 2013 | 276 |  |  | $ | 24.44 |  |
| Assumed from acquisitions | 6 |  |  | 3.60 |  |
| Exercised | (78 | ) |  | 18.30 |  |
| Canceled/forfeited/expired | (17 | ) |  | 27.53 |  |
| BALANCE AT JULY 26, 2014 | 187 |  |  | 26.03 |  |
| Assumed from acquisitions | 1 |  |  | 2.72 |  |
| Exercised | (19 | ) |  | 18.66 |  |
| Canceled/forfeited/expired | (6 | ) |  | 29.05 |  |
| BALANCE AT OCTOBER 25, 2014 | 163 |  |  | $ | 26.63 |  |

[0000858877-14-000043:notes:140]
The following table summarizes significant ranges of outstanding and exercisable stock options as of October 25, 2014 (in millions, except years and share prices):

[0000858877-14-000043:notes:141]
|  |  | STOCK OPTIONS OUTSTANDING |  | STOCK OPTIONS EXERCISABLE |
| Range of Exercise Prices |  | NumberOutstanding |  | Weighted-AverageRemainingContractualLife(in Years) |  | Weighted-AverageExercisePrice perShare |  | AggregateIntrinsicValue |  | NumberExercisable |  | Weighted-AverageExercisePrice perShare |  | AggregateIntrinsicValue |
| $ 0.01 – 15.00 |  | 7 |  |  | 5.3 |  | $ | 4.07 |  |  | $ | 145 |  |  | 4 |  |  | $ | 5.41 |  |  | $ | 74 |  |
| 15.01 – 18.00 |  | 1 |  |  | 1.0 |  | 17.32 |  |  | 7 |  |  | 1 |  |  | 17.32 |  |  | 7 |  |
| 18.01 – 20.00 |  | 2 |  |  | 0.5 |  | 19.60 |  |  | 9 |  |  | 2 |  |  | 19.60 |  |  | 9 |  |
| 20.01 – 25.00 |  | 55 |  |  | 1.0 |  | 22.87 |  |  | 51 |  |  | 54 |  |  | 22.87 |  |  | 51 |  |
| 25.01 – 30.00 |  | 26 |  |  | 1.7 |  | 26.59 |  |  | — |  |  | 26 |  |  | 26.59 |  |  | — |  |
| 30.01 – 35.00 |  | 72 |  |  | 1.8 |  | 32.16 |  |  | — |  |  | 72 |  |  | 32.16 |  |  | — |  |
| Total |  | 163 |  |  | 1.6 |  | $ | 26.63 |  |  | $ | 212 |  |  | 159 |  |  | $ | 27.13 |  |  | $ | 141 |  |

[0000858877-14-000043:notes:142]
The aggregate intrinsic value in the preceding table represents the total pretax intrinsic value, based on the Company’s closing stock price of $23.78 as of October 24, 2014, that would have been received by the option holders had those option holders exercised their stock options as of that date. The total number of in-the-money stock options exercisable as of October 25, 2014 was 61 million. As of July 26, 2014, 183 million outstanding stock options were exercisable and the weighted-average exercise price was $26.50.

[0000858877-14-000043:notes:143]
[same as prior period, unchanged from 0000858877-14-000014:notes:158]

[0000858877-14-000043:notes:144]
Time-based restricted stock units and performance-based restricted stock units (PRSUs) that are based on the Company’s financial performance metrics or non-financial operating goals are valued using the market value of the Company’s common stock on the date of grant, discounted for the present value of expected dividends. On the date of grant, the Company estimated the fair value of the total shareholder return (TSR) component of the PRSUs using a Monte Carlo simulation model. The assumptions for the valuation of time-based RSUs and PRSUs are summarized as follows:

[0000858877-14-000043:notes:145]
|  | RESTRICTED STOCK UNITS |  | PERFORMANCE RESTRICTED STOCK UNITS |
| Three Months Ended | October 25, 2014 |  | October 26, 2013 |  | October 25, 2014 |  | October 26, 2013 |
| Number of shares granted (in millions) | 9 |  |  | 10 |  |  | 6 |  |  | 4 |  |
| Grant date fair value per share | $ | 23.10 |  |  | $ | 23.11 |  |  | $ | 23.31 |  |  | $ | 22.70 |  |
| Weighted-average assumptions/inputs: |  |  |  |  |  |  |  |
| Expected dividend yield | 3.0 | % |  | 2.7 | % |  | 3.0 | % |  | 2.3 | % |
| Range of risk-free interest rates | 0.0% – 1.8% |  |  | 0.0% – 1.4% |  |  | 0.0% – 1.8% |  |  | 0.0% – 1.4% |  |
| Range of expected volatilities for index | N/A |  |  | N/A |  |  | 15.1% – 70.0% |  |  | 17.4% – 70.5% |  |

[0000858877-14-000043:notes:146]
The PRSUs granted during the first quarter of each of fiscal 2015 and fiscal 2014 are contingent on the achievement of the Company’s financial performance metrics, its comparative market-based returns, or the achievement of non-financial operating goals.  For the awards based on financial performance metrics or comparative market-based returns, generally 50% of the PRSUs are earned based on the average of annual operating cash flow and earnings per share goals established at the beginning of each fiscal year over a three-year performance period. Generally, the remaining 50% of the PRSUs are earned based on the Company’s TSR measured against the benchmark TSR of a peer group over the same period. Each PRSU recipient could vest in 0% to 150% of the target shares granted contingent on the achievement of the Company's financial performance metrics or its comparative market-based returns, and 0% or 100% of the target shares granted contingent on the achievement of non-financial operating goals.


## us-gaap:EarningsPerShareTextBlock

[0000858877-14-000043:notes:147]
[same as prior period, unchanged from 0000858877-14-000014:notes:163]

[0000858877-14-000043:notes:148]
[same as prior period, unchanged from 0000858877-14-000014:notes:164]

[0000858877-14-000043:notes:149]
|  | Three Months Ended |
|  | October 25, 2014 |  | October 26, 2013 |
| Net income | $ | 1,828 |  |  | $ | 1,996 |  |
| Weighted-average shares—basic | 5,112 |  |  | 5,378 |  |
| Effect of dilutive potential common shares | 44 |  |  | 52 |  |
| Weighted-average shares—diluted | 5,156 |  |  | 5,430 |  |
| Net income per share—basic | $ | 0.36 |  |  | $ | 0.37 |  |
| Net income per share—diluted | $ | 0.35 |  |  | $ | 0.37 |  |
| Antidilutive employee share-based awards, excluded | 114 |  |  | 174 |  |

[0000858877-14-000043:notes:150]
[same as prior period, unchanged from 0000858877-14-000014:notes:166]


## us-gaap:EquityMethodInvestmentsTextBlock

[0000858877-14-000043:notes:151]
|  | October 25, 2014 |  | July 26, 2014 |
| Equity method investments | $ | 559 |  |  | $ | 630 |  |
| Cost method investments | 327 |  |  | 269 |  |
| Total | $ | 886 |  |  | $ | 899 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000858877-14-000043:notes:152]
9.Fair Value

[0000858877-14-000043:notes:153]
[same as prior period, unchanged from 0000858877-14-000014:notes:170]

[0000858877-14-000043:notes:154]
[same as prior period, unchanged from 0000858877-14-000014:notes:171]

[0000858877-14-000043:notes:155]
[same as prior period, unchanged from 0000858877-14-000014:notes:172]

[0000858877-14-000043:notes:156]
[same as prior period, unchanged from 0000858877-14-000014:notes:173]

[0000858877-14-000043:notes:157]
Level 2 applies to assets or liabilities for which there are inputs other than quoted prices that are observable for the asset or liability, such as quoted prices for similar assets or liabilities in active markets; quoted prices for identical assets or liabilities in markets with insufficient volume or infrequent transactions (less active markets); or model-derived valuations in which significant inputs are observable or can be derived principally from, or corroborated by, observable market data.

[0000858877-14-000043:notes:158]
[same as prior period, unchanged from 0000858877-14-000014:notes:175]

[0000858877-14-000043:notes:159]
[same as prior period, unchanged from 0000858877-14-000014:notes:176]

[0000858877-14-000043:notes:160]
Assets and liabilities measured at fair value on a recurring basis as of October 25, 2014 and July 26, 2014 were as follows (in millions):

[0000858877-14-000043:notes:161]
|  | OCTOBER 25, 2014FAIR VALUE MEASUREMENTS |  | JULY 26, 2014FAIR VALUE MEASUREMENTS |
|  | Level 1 |  | Level 2 |  | TotalBalance |  | Level 1 |  | Level 2 |  | Level 3 |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 2,461 |  |  | $ | — |  |  | $ | 2,461 |  |  | $ | 4,935 |  |  | $ | — |  |  | $ | — |  |  | $ | 4,935 |  |
| Available-for-sale investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | — |  |  | 32,414 |  |  | 32,414 |  |  | — |  |  | 31,734 |  |  | — |  |  | 31,734 |  |
| U.S. government agency securities | — |  |  | 1,341 |  |  | 1,341 |  |  | — |  |  | 1,063 |  |  | — |  |  | 1,063 |  |
| Non-U.S. government and agency securities | — |  |  | 1,051 |  |  | 1,051 |  |  | — |  |  | 861 |  |  | — |  |  | 861 |  |
| Corporate debt securities | — |  |  | 10,233 |  |  | 10,233 |  |  | — |  |  | 9,159 |  |  | — |  |  | 9,159 |  |
| U.S. agency mortgage-backed securities | — |  |  | 884 |  |  | 884 |  |  | — |  |  | 579 |  |  | — |  |  | 579 |  |
| Publicly traded equity securities | 1,797 |  |  | — |  |  | 1,797 |  |  | 1,952 |  |  | — |  |  | — |  |  | 1,952 |  |
| Derivative assets | — |  |  | 227 |  |  | 227 |  |  | — |  |  | 158 |  |  | 2 |  |  | 160 |  |
| Total | $ | 4,258 |  |  | $ | 46,150 |  |  | $ | 50,408 |  |  | $ | 6,887 |  |  | $ | 43,554 |  |  | $ | 2 |  |  | $ | 50,443 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities | $ | — |  |  | $ | 99 |  |  | $ | 99 |  |  | $ | — |  |  | $ | 67 |  |  | $ | — |  |  | $ | 67 |  |
| Total | $ | — |  |  | $ | 99 |  |  | $ | 99 |  |  | $ | — |  |  | $ | 67 |  |  | $ | — |  |  | $ | 67 |  |

[0000858877-14-000043:notes:162]
[same as prior period, unchanged from 0000858877-14-000014:notes:179]

[0000858877-14-000043:notes:163]
Level 3 assets include certain derivative instruments, the values of which are determined based on discounted cash flow models using inputs that the Company could not corroborate with market data.

[0000858877-14-000043:notes:164]
[same as prior period, unchanged from 0000858877-14-000014:notes:180]

[0000858877-14-000043:notes:165]
The Company recognized $1 million of losses related to the impairment of privately held investments for each of the three months ended October 25, 2014 and October 26, 2013. These assets were measured at fair value due to events or circumstances the Company identified as having significant impact on their fair value during the respective periods.  To arrive at the valuation of these assets, the Company considers any significant changes in the financial metrics and economic variables and also uses third-party valuation reports to assist in the valuation as necessary.

[0000858877-14-000043:notes:166]
The fair value measurement of the impaired investments was classified as Level 3 because significant unobservable inputs were used in the valuation due to the absence of quoted market prices and inherent lack of liquidity. Significant unobservable inputs, which included financial metrics of comparable private and public companies, financial condition and near-term prospects of the investees, recent  financing activities of the investees, and the investees’ capital structure as well as other economic variables, reflected the assumptions market participants would use in pricing these assets. The impairment charges, representing the difference between the net book value and the fair value as a result of the evaluation, were recorded to other income (loss), net.

[0000858877-14-000043:notes:167]
[same as prior period, unchanged from 0000858877-14-000014:notes:185]

[0000858877-14-000043:notes:168]
The carrying value of the Company’s investments in privately held companies that were accounted for under the cost method was $327 million and $269 million as of October 25, 2014 and July 26, 2014, respectively. It was not practicable to estimate the fair value of this portfolio.

[0000858877-14-000043:notes:169]
The fair value of the Company’s short-term loan receivables and financed service contracts approximates their carrying value due to their short duration.  The aggregate carrying value of the Company’s long-term loan receivables and financed service contracts and other as of October 25, 2014 and July 26, 2014 was $1.9 billion and $2.1 billion, respectively.  The estimated fair value of the Company’s long-term loan receivables and financed service contracts and other approximates their carrying value. The Company uses significant unobservable inputs in determining discounted cash flows to estimate the fair value of its long-term loan receivables and financed service contracts, and therefore they are categorized as Level 3.

[0000858877-14-000043:notes:170]
As of October 25, 2014, the estimated fair value of the short-term debt approximates its carrying value due to the short maturities.  As of October 25, 2014, the fair value of the Company’s senior notes and other long-term debt was $22.4 billion with a carrying amount of $21.0 billion.  This compares to a fair value of $22.4 billion and a carrying amount of $20.9 billion as of July 26, 2014.  The fair value of the senior notes and other long-term debt was determined based on observable market prices in a less active market and was categorized as Level 2 in the fair value hierarchy.


## us-gaap:FinancingReceivableCreditQualityIndicatorsTableTextBlock

[0000858877-14-000043:notes:171]
Gross receivables less unearned income categorized by the Company’s internal credit risk rating as of October 25, 2014 and July 26, 2014 are summarized as follows (in millions):

[0000858877-14-000043:notes:172]
|  | INTERNAL CREDIT RISK RATING |
| October 25, 2014 | 1 to 4 |  | 5 to 6 |  | 7 and Higher |  | Total |
| Lease receivables | $ | 1,665 |  |  | $ | 1,482 |  |  | $ | 128 |  |  | $ | 3,275 |  |
| Loan receivables | 953 |  |  | 637 |  |  | 154 |  |  | 1,744 |  |
| Financed service contracts and other | 1,677 |  |  | 1,296 |  |  | 98 |  |  | 3,071 |  |
| Total | $ | 4,295 |  |  | $ | 3,415 |  |  | $ | 380 |  |  | $ | 8,090 |  |

[0000858877-14-000043:notes:173]
|  | INTERNAL CREDIT RISK RATING |
| July 26, 2014 | 1 to 4 |  | 5 to 6 |  | 7 and Higher |  | Total |
| Lease receivables | $ | 1,615 |  |  | $ | 1,538 |  |  | $ | 141 |  |  | $ | 3,294 |  |
| Loan receivables | 953 |  |  | 593 |  |  | 137 |  |  | 1,683 |  |
| Financed service contracts and other | 1,744 |  |  | 1,367 |  |  | 99 |  |  | 3,210 |  |
| Total | $ | 4,312 |  |  | $ | 3,498 |  |  | $ | 377 |  |  | $ | 8,187 |  |


## us-gaap:FinancingReceivablesTextBlock

[0000858877-14-000043:notes:174]
| 7. | Financing Receivables and Operating Leases |

[0000858877-14-000043:notes:175]
[same as prior period, unchanged from 0000858877-14-000014:notes:193]

[0000858877-14-000043:notes:176]
[same as prior period, unchanged from 0000858877-14-000014:notes:194]

[0000858877-14-000043:notes:177]
A summary of the Company's financing receivables is presented as follows (in millions):

[0000858877-14-000043:notes:178]
| October 25, 2014 | LeaseReceivables |  | LoanReceivables |  | FinancedServiceContracts and Other |  | Total |
| Gross | $ | 3,498 |  |  | $ | 1,744 |  |  | $ | 3,071 |  |  | $ | 8,313 |  |
| Residual value | 234 |  |  | — |  |  | — |  |  | 234 |  |
| Unearned income | (223 | ) |  | — |  |  | — |  |  | (223 | ) |
| Allowance for credit loss | (248 | ) |  | (84 | ) |  | (36 | ) |  | (368 | ) |
| Total, net | $ | 3,261 |  |  | $ | 1,660 |  |  | $ | 3,035 |  |  | $ | 7,956 |  |
| Reported as: |  |  |  |  |  |  |  |
| Current | $ | 1,496 |  |  | $ | 827 |  |  | $ | 1,942 |  |  | $ | 4,265 |  |
| Noncurrent | 1,765 |  |  | 833 |  |  | 1,093 |  |  | 3,691 |  |
| Total, net | $ | 3,261 |  |  | $ | 1,660 |  |  | $ | 3,035 |  |  | $ | 7,956 |  |

[0000858877-14-000043:notes:179]
| July 26, 2014 | LeaseReceivables |  | LoanReceivables |  | FinancedServiceContracts and Other |  | Total |
| Gross | $ | 3,532 |  |  | $ | 1,683 |  |  | $ | 3,210 |  |  | $ | 8,425 |  |
| Residual value | 233 |  |  | — |  |  | — |  |  | 233 |  |
| Unearned income | (238 | ) |  | — |  |  | — |  |  | (238 | ) |
| Allowance for credit loss | (233 | ) |  | (98 | ) |  | (18 | ) |  | (349 | ) |
| Total, net | $ | 3,294 |  |  | $ | 1,585 |  |  | $ | 3,192 |  |  | $ | 8,071 |  |
| Reported as: |  |  |  |  |  |  |  |
| Current | $ | 1,476 |  |  | $ | 728 |  |  | $ | 1,949 |  |  | $ | 4,153 |  |
| Noncurrent | 1,818 |  |  | 857 |  |  | 1,243 |  |  | 3,918 |  |
| Total, net | $ | 3,294 |  |  | $ | 1,585 |  |  | $ | 3,192 |  |  | $ | 8,071 |  |

[0000858877-14-000043:notes:180]
As of October 25, 2014 and July 26, 2014, the deferred service revenue related to the financed service contracts and other was $1,672 million and $1,843 million, respectively.

[0000858877-14-000043:notes:181]
Future minimum lease payments at October 25, 2014 are summarized as follows (in millions):

[0000858877-14-000043:notes:182]
| Fiscal Year | Amount |
| 2015 (remaining nine months) | $ | 1,303 |  |
| 2016 | 1,144 |  |
| 2017 | 681 |  |
| 2018 | 281 |  |
| 2019 | 87 |  |
| Thereafter | 2 |  |
| Total | $ | 3,498 |  |

[0000858877-14-000043:notes:183]
[same as prior period, unchanged from 0000858877-14-000014:notes:201]

[0000858877-14-000043:notes:184]
[same as prior period, unchanged from 0000858877-14-000014:notes:202]

[0000858877-14-000043:notes:185]
[same as prior period, unchanged from 0000858877-14-000014:notes:203]

[0000858877-14-000043:notes:186]
[same as prior period, unchanged from 0000858877-14-000014:notes:204]

[0000858877-14-000043:notes:187]
In circumstances when collectibility is not deemed reasonably assured, the associated revenue is deferred in accordance with the Company’s revenue recognition policies, and the related allowance for credit loss, if any, is included in deferred revenue. The Company also records deferred revenue associated with financing receivables when there are remaining performance obligations, as it does for financed service contracts. Total allowances for credit loss and deferred revenue as of October 25, 2014 and July 26, 2014 were $2,054 million and $2,220 million, respectively, and they were associated with total financing receivables before allowance for credit loss of $8,324 million and $8,420 million as of their respective period ends.

[0000858877-14-000043:notes:188]
The following tables present the aging analysis of gross receivables less unearned income as of October 25, 2014 and July 26, 2014 (in millions):

[0000858877-14-000043:notes:189]
|  | DAYS PAST DUE (INCLUDES BILLED AND UNBILLED) |  |  |  |  |  |  |  |  |
| October 25, 2014 | 31-60 |  | 61-90 |  | 91+ |  | TotalPast Due |  | Current |  | Total |  | NonaccrualFinancingReceivables |  | ImpairedFinancingReceivables |
| Lease receivables | $ | 80 |  |  | $ | 54 |  |  | $ | 196 |  |  | $ | 330 |  |  | $ | 2,945 |  |  | $ | 3,275 |  |  | $ | 47 |  |  | $ | 39 |  |
| Loan receivables | 17 |  |  | 41 |  |  | 89 |  |  | 147 |  |  | 1,597 |  |  | 1,744 |  |  | 41 |  |  | 37 |  |
| Financed service contracts and other | 144 |  |  | 163 |  |  | 532 |  |  | 839 |  |  | 2,232 |  |  | 3,071 |  |  | 12 |  |  | 7 |  |
| Total | $ | 241 |  |  | $ | 258 |  |  | $ | 817 |  |  | $ | 1,316 |  |  | $ | 6,774 |  |  | $ | 8,090 |  |  | $ | 100 |  |  | $ | 83 |  |

[0000858877-14-000043:notes:190]
|  | DAYS PAST DUE (INCLUDES BILLED AND UNBILLED) |  |  |  |  |  |  |  |  |
| July 26, 2014 | 31-60 |  | 61-90 |  | 91+ |  | TotalPast Due |  | Current |  | Total |  | NonaccrualFinancingReceivables |  | ImpairedFinancingReceivables |
| Lease receivables | $ | 104 |  |  | $ | 43 |  |  | $ | 165 |  |  | $ | 312 |  |  | $ | 2,982 |  |  | $ | 3,294 |  |  | $ | 48 |  |  | $ | 41 |  |
| Loan receivables | 2 |  |  | 1 |  |  | 16 |  |  | 19 |  |  | 1,664 |  |  | 1,683 |  |  | 19 |  |  | 19 |  |
| Financed service contracts and other | 301 |  |  | 238 |  |  | 230 |  |  | 769 |  |  | 2,441 |  |  | 3,210 |  |  | 12 |  |  | 9 |  |
| Total | $ | 407 |  |  | $ | 282 |  |  | $ | 411 |  |  | $ | 1,100 |  |  | $ | 7,087 |  |  | $ | 8,187 |  |  | $ | 79 |  |  | $ | 69 |  |

[0000858877-14-000043:notes:191]
Past due financing receivables are those that are 31 days or more past due according to their contractual payment terms. The data in the preceding tables are presented by contract, and the aging classification of each contract is based on the oldest outstanding receivable, and therefore past due amounts also include unbilled and current receivables within the same contract. The balances of either unbilled or current financing receivables included in the category of 91 days plus past due for financing receivables were $661 million and $296 million as of October 25, 2014 and July 26, 2014, respectively.

[0000858877-14-000043:notes:192]
As of October 25, 2014, the Company had financing receivables of $111 million, net of unbilled or current receivables from the same contract, that were in the category of 91 days plus past due but remained on accrual status. Such balance was $78 million as of July 26, 2014. A financing receivable may be placed on nonaccrual status earlier if, in management’s opinion, a timely collection of the full principal and interest becomes uncertain.

[0000858877-14-000043:notes:193]
[same as prior period, unchanged from 0000858877-14-000014:notes:211]

[0000858877-14-000043:notes:194]
[same as prior period, unchanged from 0000858877-14-000014:notes:212]

[0000858877-14-000043:notes:195]
Typically, the Company also considers receivables with a risk rating of 8 or higher to be impaired and will include them in the individual assessment for allowance. These balances, as of October 25, 2014 and July 26, 2014, are presented under “(b) Credit Quality of Financing Receivables” above.

[0000858877-14-000043:notes:196]
[same as prior period, unchanged from 0000858877-14-000014:notes:214]

[0000858877-14-000043:notes:197]
| (d) | Operating Leases |

[0000858877-14-000043:notes:198]
The Company provides financing of certain equipment through operating leases, and the amounts are included in property and equipment in the Consolidated Balance Sheets.  Amounts relating to equipment on operating lease assets and the associated accumulated depreciation are summarized as follows (in millions):

[0000858877-14-000043:notes:199]
|  | October 25, 2014 |  | July 26, 2014 |
| Operating lease assets | $ | 349 |  |  | $ | 362 |  |
| Accumulated depreciation | (197 | ) |  | (202 | ) |
| Operating lease assets, net | $ | 152 |  |  | $ | 160 |  |

[0000858877-14-000043:notes:200]
Minimum future rentals on noncancelable operating leases at October 25, 2014 were approximately $0.2 billion for the remaining nine months of fiscal 2015, $0.1 billion for fiscal 2016, and less than $0.1 billion per year for each of fiscal 2017 through fiscal 2019.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000858877-14-000043:notes:201]
[same as prior period, unchanged from 0000858877-14-000014:notes:221]

[0000858877-14-000043:notes:202]
[same as prior period, unchanged from 0000858877-14-000014:notes:222]

[0000858877-14-000043:notes:203]
The following table presents the goodwill allocated to the Company’s reportable segments as of and during the three months ended October 25, 2014 (in millions):

[0000858877-14-000043:notes:204]
|  | Balance at July 26, 2014 |  | Acquisitions |  | Other |  | Balance at October 25, 2014 |
| Americas | $ | 15,080 |  |  | $ | 75 |  |  | $ | (11 | ) |  | $ | 15,144 |  |
| EMEA | 5,715 |  |  | 60 |  |  | (6 | ) |  | 5,769 |  |
| APJC | 3,444 |  |  | 11 |  |  | (4 | ) |  | 3,451 |  |
| Total | $ | 24,239 |  |  | $ | 146 |  |  | $ | (21 | ) |  | $ | 24,364 |  |

[0000858877-14-000043:notes:205]
The column entitled “Other” primarily includes purchase accounting adjustments.

[0000858877-14-000043:notes:206]
[same as prior period, unchanged from 0000858877-14-000014:notes:225]

[0000858877-14-000043:notes:207]
The following table presents details of the Company’s intangible assets acquired through business combinations completed during the three months ended October 25, 2014 (in millions, except years):

[0000858877-14-000043:notes:208]
|  | FINITE LIVES |  | INDEFINITELIVES |  | TOTAL |
|  | TECHNOLOGY |  | CUSTOMERRELATIONSHIPS |  | IPR&D |  |
|  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Amount |  | Amount |
| Metacloud, Inc. | 3.0 |  | $ | 24 |  |  | 5.0 |  | $ | 3 |  |  | $ | 2 |  |  | $ | 29 |  |
| Other | 5.0 |  | 21 |  |  | 5.0 |  | 4 |  |  | 4 |  |  | 29 |  |
| Total |  |  | $ | 45 |  |  |  |  | $ | 7 |  |  | $ | 6 |  |  | $ | 58 |  |

[0000858877-14-000043:notes:209]
[same as prior period, unchanged from 0000858877-14-000014:notes:228]

[0000858877-14-000043:notes:210]
| October 25, 2014 |  | Gross |  | Accumulated Amortization |  | Net |
| Purchased intangible assets with finite lives: |  |  |  |  |  |  |
| Technology |  | $ | 4,150 |  |  | $ | (2,166 | ) |  | $ | 1,984 |  |
| Customer relationships |  | 1,713 |  |  | (788 | ) |  | 925 |  |
| Other |  | 51 |  |  | (16 | ) |  | 35 |  |
| Total purchased intangible assets with finite lives |  | 5,914 |  |  | (2,970 | ) |  | 2,944 |  |
| In-process research and development, with indefinite lives |  | 122 |  |  | — |  |  | 122 |  |
| Total |  | $ | 6,036 |  |  | $ | (2,970 | ) |  | $ | 3,066 |  |

[0000858877-14-000043:notes:211]
| July 26, 2014 |  | Gross |  | AccumulatedAmortization |  | Net |
| Purchased intangible assets with finite lives: |  |  |  |  |  |  |
| Technology |  | $ | 4,100 |  |  | $ | (1,976 | ) |  | $ | 2,124 |  |
| Customer relationships |  | 1,706 |  |  | (720 | ) |  | 986 |  |
| Other |  | 51 |  |  | (13 | ) |  | 38 |  |
| Total purchased intangible assets with finite lives |  | 5,857 |  |  | (2,709 | ) |  | 3,148 |  |
| In-process research and development, with indefinite lives |  | 132 |  |  | — |  |  | 132 |  |
| Total |  | $ | 5,989 |  |  | $ | (2,709 | ) |  | $ | 3,280 |  |

[0000858877-14-000043:notes:212]
[same as prior period, unchanged from 0000858877-14-000014:notes:231]

[0000858877-14-000043:notes:213]
[same as prior period, unchanged from 0000858877-14-000014:notes:232]

[0000858877-14-000043:notes:214]
|  |  | Three Months Ended |
|  |  | October 25, 2014 |  | October 26, 2013 |
| Amortization of purchased intangible assets: |  |  |  |  |
| Cost of sales |  | $ | 189 |  |  | $ | 174 |  |
| Operating expenses |  | 71 |  |  | 65 |  |
| Total |  | $ | 260 |  |  | $ | 239 |  |

[0000858877-14-000043:notes:215]
[same as prior period, unchanged from 0000858877-14-000014:notes:234]

[0000858877-14-000043:notes:216]
The estimated future amortization expense of purchased intangible assets with finite lives as of October 25, 2014 is as follows (in millions):

[0000858877-14-000043:notes:217]
| Fiscal Year | Amount |
| 2015 (remaining nine months) | $ | 728 |  |
| 2016 | 754 |  |
| 2017 | 580 |  |
| 2018 | 421 |  |
| 2019 | 315 |  |
| Thereafter | 146 |  |
| Total | $ | 2,944 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000858877-14-000043:notes:218]
[same as prior period, unchanged from 0000858877-14-000014:notes:237]

[0000858877-14-000043:notes:219]
[same as prior period, unchanged from 0000858877-14-000014:notes:238]

[0000858877-14-000043:notes:220]
|  | Three Months Ended |
|  | October 25, 2014 |  | October 26, 2013 |
| Income before provision for income taxes | $ | 2,360 |  |  | $ | 2,540 |  |
| Provision for income taxes | $ | 532 |  |  | $ | 544 |  |
| Effective tax rate | 22.5 | % |  | 21.4 | % |

[0000858877-14-000043:notes:221]
As of October 25, 2014, the Company had $2.0 billion of unrecognized tax benefits, of which $1.7 billion, if recognized, would favorably impact the effective tax rate. The Company regularly engages in discussions and negotiations with tax authorities regarding tax matters in various jurisdictions. The Company believes it is reasonably possible that certain federal, foreign, and state tax matters may be concluded in the next 12 months. Specific positions that may be resolved include issues involving transfer pricing and various other matters. Accordingly, the Company estimates that it is reasonably possible that the unrecognized tax benefits at October 25, 2014 could be reduced by $300 million in the next 12 months.


## us-gaap:InventoryDisclosureTextBlock

[0000858877-14-000043:notes:222]
[same as prior period, unchanged from 0000858877-14-000014:notes:241]

[0000858877-14-000043:notes:223]
|  |  | October 25, 2014 |  | July 26, 2014 |
| Inventories: |  |  |  |  |
| Raw materials |  | $ | 173 |  |  | $ | 77 |  |
| Work in process |  | 3 |  |  | 5 |  |
| Finished goods: |  |  |  |  |
| Distributor inventory and deferred cost of sales |  | 654 |  |  | 595 |  |
| Manufactured finished goods |  | 535 |  |  | 606 |  |
| Total finished goods |  | 1,189 |  |  | 1,201 |  |
| Service-related spares |  | 275 |  |  | 273 |  |
| Demonstration systems |  | 36 |  |  | 35 |  |
| Total |  | $ | 1,676 |  |  | $ | 1,591 |  |


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0000858877-14-000043:notes:224]
The following table summarizes the maturities of the Company’s fixed income securities at October 25, 2014 (in millions):

[0000858877-14-000043:notes:225]
|  | Amortized Cost |  | Fair Value |
| Less than 1 year | $ | 16,643 |  |  | $ | 16,656 |  |
| Due in 1 to 2 years | 14,222 |  |  | 14,270 |  |
| Due in 2 to 5 years | 13,884 |  |  | 13,957 |  |
| Due after 5 years | 1,026 |  |  | 1,040 |  |
| Total | $ | 45,775 |  |  | $ | 45,923 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000858877-14-000043:notes:226]
| 8. | Investments |

[0000858877-14-000043:notes:227]
| (a) | Summary of Available-for-Sale Investments |

[0000858877-14-000043:notes:228]
The following tables summarize the Company’s available-for-sale investments (in millions):

[0000858877-14-000043:notes:229]
| October 25, 2014 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| Fixed income securities: |  |  |  |  |  |  |  |
| U.S. government securities | $ | 32,343 |  |  | $ | 71 |  |  | $ | — |  |  | $ | 32,414 |  |
| U.S. government agency securities | 1,338 |  |  | 3 |  |  | — |  |  | 1,341 |  |
| Non-U.S. government and agency securities | 1,049 |  |  | 2 |  |  | — |  |  | 1,051 |  |
| Corporate debt securities | 10,170 |  |  | 73 |  |  | (10 | ) |  | 10,233 |  |
| U.S. agency mortgage-backed securities | 875 |  |  | 9 |  |  | — |  |  | 884 |  |
| Total fixed income securities | 45,775 |  |  | 158 |  |  | (10 | ) |  | 45,923 |  |
| Publicly traded equity securities | 1,263 |  |  | 545 |  |  | (11 | ) |  | 1,797 |  |
| Total | $ | 47,038 |  |  | $ | 703 |  |  | $ | (21 | ) |  | $ | 47,720 |  |
| July 26, 2014 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| Fixed income securities: |  |  |  |  |  |  |  |
| U.S. government securities | $ | 31,717 |  |  | $ | 29 |  |  | $ | (12 | ) |  | $ | 31,734 |  |
| U.S. government agency securities | 1,062 |  |  | 1 |  |  | — |  |  | 1,063 |  |
| Non-U.S. government and agency securities | 860 |  |  | 2 |  |  | (1 | ) |  | 861 |  |
| Corporate debt securities | 9,092 |  |  | 74 |  |  | (7 | ) |  | 9,159 |  |
| U.S. agency mortgage-backed securities | 574 |  |  | 5 |  |  | — |  |  | 579 |  |
| Total fixed income securities | 43,305 |  |  | 111 |  |  | (20 | ) |  | 43,396 |  |
| Publicly traded equity securities | 1,314 |  |  | 648 |  |  | (10 | ) |  | 1,952 |  |
| Total | $ | 44,619 |  |  | $ | 759 |  |  | $ | (30 | ) |  | $ | 45,348 |  |

[0000858877-14-000043:notes:230]
Non-U.S. government and agency securities include agency and corporate debt securities that are guaranteed by non-U.S. governments.

[0000858877-14-000043:notes:231]
| (b) | Gains and Losses on Available-for-Sale Investments |

[0000858877-14-000043:notes:232]
The following table presents the gross realized gains and gross realized losses related to the Company’s available-for-sale investments (in millions):

[0000858877-14-000043:notes:233]
|  | Three Months Ended |
|  | October 25, 2014 |  | October 26, 2013 |
| Gross realized gains | $ | 21 |  |  | $ | 95 |  |
| Gross realized losses | (14 | ) |  | (12 | ) |
| Total | $ | 7 |  |  | $ | 83 |  |

[0000858877-14-000043:notes:234]
The following table presents the realized net gains (losses) related to the Company’s available-for-sale investments by security type (in millions):

[0000858877-14-000043:notes:235]
|  | Three Months Ended |
|  | October 25, 2014 |  | October 26, 2013 |
| Net gains (losses) on investments in publicly traded equity securities | $ | (4 | ) |  | $ | 75 |  |
| Net gains on investments in fixed income securities | 11 |  |  | 8 |  |
| Total | $ | 7 |  |  | $ | 83 |  |

[0000858877-14-000043:notes:236]
There were no impairment charges on available-for-sale investments for the periods presented.

[0000858877-14-000043:notes:237]
The following tables present the breakdown of the available-for-sale investments with gross unrealized losses and the duration that those losses had been unrealized at October 25, 2014 and July 26, 2014 (in millions):

[0000858877-14-000043:notes:238]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| October 25, 2014 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| Fixed income securities: |  |  |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | $ | 2,491 |  |  | $ | (8 | ) |  | $ | 383 |  |  | $ | (2 | ) |  | $ | 2,874 |  |  | $ | (10 | ) |
| Total fixed income securities | 2,491 |  |  | (8 | ) |  | 383 |  |  | (2 | ) |  | 2,874 |  |  | (10 | ) |
| Publicly traded equity securities | 131 |  |  | (11 | ) |  | 1 |  |  | — |  |  | 132 |  |  | (11 | ) |
| Total | $ | 2,622 |  |  | $ | (19 | ) |  | $ | 384 |  |  | $ | (2 | ) |  | $ | 3,006 |  |  | $ | (21 | ) |

[0000858877-14-000043:notes:239]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 26, 2014 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| Fixed income securities: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | $ | 7,676 |  |  | $ | (12 | ) |  | $ | 45 |  |  | $ | — |  |  | $ | 7,721 |  |  | $ | (12 | ) |
| Non-U.S. government and agency securities | 361 |  |  | (1 | ) |  | 22 |  |  | — |  |  | 383 |  |  | (1 | ) |
| Corporate debt securities | 1,875 |  |  | (3 | ) |  | 491 |  |  | (4 | ) |  | 2,366 |  |  | (7 | ) |
| Total fixed income securities | 9,912 |  |  | (16 | ) |  | 558 |  |  | (4 | ) |  | 10,470 |  |  | (20 | ) |
| Publicly traded equity securities | 132 |  |  | (10 | ) |  | — |  |  | — |  |  | 132 |  |  | (10 | ) |
| Total | $ | 10,044 |  |  | $ | (26 | ) |  | $ | 558 |  |  | $ | (4 | ) |  | $ | 10,602 |  |  | $ | (30 | ) |

[0000858877-14-000043:notes:240]
As of October 25, 2014, for fixed income securities that were in unrealized loss positions, the Company has determined that (i) it does not have the intent to sell any of these investments, and (ii) it is not more likely than not that it will be required to sell any of these investments before recovery of the entire amortized cost basis. In addition, as of October 25, 2014, the Company anticipates that it will recover the entire amortized cost basis of such fixed income securities and has determined that no other-than-temporary impairments associated with credit losses were required to be recognized during the three months ended October 25, 2014.

[0000858877-14-000043:notes:241]
The Company has evaluated its publicly traded equity securities as of October 25, 2014 and has determined that there was no indication of other-than-temporary impairments in the respective categories of unrealized losses. This determination was based on several factors, which include the length of time and extent to which fair value has been less than the cost basis, the financial condition and near-term prospects of the issuer, and the Company’s intent and ability to hold the publicly traded equity securities for a period of time sufficient to allow for any anticipated recovery in market value.

[0000858877-14-000043:notes:242]
| (c) | Maturities of Fixed Income Securities |

[0000858877-14-000043:notes:243]
Actual maturities may differ from the contractual maturities because borrowers may have the right to call or prepay certain obligations.  The remaining contractual principal maturities for mortgage-backed securities were allocated assuming no prepayments.

[0000858877-14-000043:notes:244]
| (d) | Securities Lending |

[0000858877-14-000043:notes:245]
The Company periodically engages in securities lending activities with certain of its available-for-sale investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. The average daily balance of securities lending for the three months ended October 25, 2014 and October 26, 2013 was $1.0 billion and $0.6 billion, respectively. The Company requires collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. The Company engages in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify the Company against collateral losses. The Company did not experience any losses in connection with the secured lending of securities during the periods presented. As of October 25, 2014 and July 26, 2014, the Company had no outstanding securities lending transactions.

[0000858877-14-000043:notes:246]
| (e) | Investments in Privately Held Companies |

[0000858877-14-000043:notes:247]
The carrying value of the Company’s investments in privately held companies was included in other assets. For such investments that were accounted for under the equity and cost method as of October 25, 2014 and July 26, 2014, the amounts are summarized in the following table (in millions):

[0000858877-14-000043:notes:248]
Variable Interest Entities

[0000858877-14-000043:notes:249]
VCE Joint Venture   VCE is a joint venture that the Company formed in fiscal 2010 with EMC Corporation (“EMC”), with investments from VMware, Inc. (“VMware”) and Intel Capital Corporation ("Intel"). VCE helps organizations leverage best-in-class technologies and disciplines from Cisco, EMC, and VMware to enable the transformation to cloud computing.

[0000858877-14-000043:notes:250]
As of October 25, 2014, the Company’s cumulative gross investment in VCE was approximately $716 million, inclusive of accrued interest on convertible notes, and its ownership percentage was approximately 35%.  The Company did not make any investments in VCE during the three months ended October 25, 2014.  As of October 25, 2014, the Company had recorded cumulative losses from VCE under the equity method of $691 million since inception, of which losses of $47 million and $53 million were recorded for the three months ended October 25, 2014 and October 26, 2013, respectively.  The Company’s carrying value in VCE as of October 25, 2014 was $25 million.

[0000858877-14-000043:notes:251]
EMC and the Company have entered into guarantee agreements on behalf of VCE to indemnify certain customers (the "Guarantees") for monetary damages. Such Guarantees were not material as of October 25, 2014.

[0000858877-14-000043:notes:252]
In October 2014, the Company, EMC, VMware, and Intel agreed to restructure the VCE joint venture.  Under the terms of the agreement, VCE will undergo a reorganization and recapitalization whereby VCE will pay approximately $150 million to the Company for a portion of the outstanding principal balance of the convertible notes and accrued interest on such notes.  The Company also agreed to cancel the remaining principal balance of the convertible notes held by it and the accrued interest on such notes, and to have VCE redeem a portion of the Company’s equity interest in VCE.   EMC also agreed to indemnify the Company for any liabilities incurred by the Company under the Guarantees.  Following this reorganization and recapitalization, the Company’s ownership interest in VCE will be approximately 10%.  The transaction is expected to close in the second quarter of the Company's fiscal year 2015, subject to customary regulatory approvals.

[0000858877-14-000043:notes:253]
Other Variable Interest Entities    In the ordinary course of business, the Company has investments in other privately held companies and provides financing to certain customers. These other privately held companies and customers may be considered to be variable interest entities. The Company evaluates on an ongoing basis its investments in these other privately held companies and its customer financings, and has determined that as of October 25, 2014 there were no other variable interest entities required to be consolidated in the Company’s Consolidated Financial Statements.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000858877-14-000043:notes:254]
[same as prior period, unchanged from 0000858877-14-000014:notes:266]

[0000858877-14-000043:notes:255]
The fiscal year for Cisco Systems, Inc. (the “Company” or “Cisco”) is the 52 or 53 weeks ending on the last Saturday in July. Fiscal 2015 and fiscal 2014 are each 52-week fiscal years. The Consolidated Financial Statements include the accounts of Cisco and its subsidiaries. All intercompany accounts and transactions have been eliminated. The Company conducts business globally and is primarily managed on a geographic basis in the following three geographic segments: the Americas; Europe, Middle East, and Africa (EMEA); and Asia Pacific, Japan, and China (APJC).

[0000858877-14-000043:notes:256]
The accompanying financial data as of October 25, 2014 and for the three months ended October 25, 2014 and October 26, 2013 has been prepared by the Company, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (SEC). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (GAAP) have been condensed or omitted pursuant to such rules and regulations. The July 26, 2014 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, the Company believes that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended July 26, 2014.

[0000858877-14-000043:notes:257]
The Company consolidates its investments in a venture fund managed by SOFTBANK Corp. and its affiliates (“SOFTBANK”) as this is a variable interest entity and the Company is the primary beneficiary.  The noncontrolling interests attributed to SOFTBANK are presented as a separate component from the Company’s equity in the equity section of the Consolidated Balance Sheets. SOFTBANK’s share of the earnings in the venture fund are not presented separately in the Consolidated Statements of Operations as these amounts are not material for any of the fiscal periods presented.

[0000858877-14-000043:notes:258]
In the opinion of management, all adjustments (which include normal recurring adjustments, except as disclosed herein) necessary to present fairly the consolidated balance sheet as of October 25, 2014; the results of operations; statements of comprehensive income, cash flows, and equity for the three months ended October 25, 2014 and October 26, 2013, as applicable, have been made. The results of operations for the three months ended October 25, 2014 are not necessarily indicative of the operating results for the full fiscal year or any future periods.

[0000858877-14-000043:notes:259]
Certain reclassifications have been made to the amounts in prior periods in order to conform to the current period’s presentation.  The Company has evaluated subsequent events through the date that the financial statements were issued.


## us-gaap:OtherAssetsDisclosureTextBlock

[0000858877-14-000043:notes:260]
| Other assets: |  |  |  |  |
| Deferred tax assets |  | $ | 1,553 |  |  | $ | 1,700 |  |
| Investments in privately held companies |  | 886 |  |  | 899 |  |
| Other |  | 789 |  |  | 732 |  |
| Total |  | $ | 3,228 |  |  | $ | 3,331 |  |


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0000858877-14-000043:notes:261]
| Property and equipment, net: |  |  |  |  |
| Land, buildings, and building and leasehold improvements |  | $ | 4,471 |  |  | $ | 4,468 |  |
| Computer equipment and related software |  | 1,423 |  |  | 1,425 |  |
| Production, engineering, and other equipment |  | 5,728 |  |  | 5,756 |  |
| Operating lease assets |  | 349 |  |  | 362 |  |
| Furniture and fixtures |  | 498 |  |  | 509 |  |
|  |  | 12,469 |  |  | 12,520 |  |
| Less accumulated depreciation and amortization |  | (9,236 | ) |  | (9,268 | ) |
| Total |  | $ | 3,233 |  |  | $ | 3,252 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000858877-14-000043:notes:262]
[same as prior period, unchanged from 0000858877-14-000014:notes:273]

[0000858877-14-000043:notes:263]
Fiscal 2015 Plan

[0000858877-14-000043:notes:264]
In connection with a restructuring action announced in August 2014, the Company incurred cumulative charges of $318 million for the first quarter of fiscal 2015.  The Company estimates that it will recognize aggregate pre-tax charges pursuant to the restructuring action in an amount not expected to exceed $600 million, consisting of severance and other one-time termination benefits and other associated costs.  These charges are primarily cash-based and the Company expects the remaining amount to be recognized during the remainder of fiscal 2015.

[0000858877-14-000043:notes:265]
Fiscal 2014 Plan

[0000858877-14-000043:notes:266]
The Fiscal 2014 Plan is a workforce reduction plan the Company announced in August 2013. In connection with this restructuring action, the Company incurred cumulative charges of approximately $418 million, of which $237 million was incurred during the three months ended October 26, 2013.  The Company completed the Fiscal 2014 Plan at the end of fiscal 2014.

[0000858877-14-000043:notes:267]
The following table summarizes the activities related to the restructuring and other charges as discussed above (in millions):

[0000858877-14-000043:notes:268]
|  |  | Fiscal 2014 and Prior Plans |  | Fiscal 2015 Plan |  |  |
|  |  | EmployeeSeverance |  | Other |  | EmployeeSeverance |  | Other |  | Total |
| Liability as of July 26, 2014 |  | $ | 40 |  |  | $ | 29 |  |  | $ | — |  |  | $ | — |  |  | $ | 69 |  |
| Gross charges in fiscal 2015 |  | — |  |  | — |  |  | 322 |  |  | (4 | ) |  | 318 |  |
| Cash payments |  | (13 | ) |  | — |  |  | (142 | ) |  | — |  |  | (155 | ) |
| Non-cash items |  | — |  |  | (4 | ) |  | — |  |  | 4 |  |  | — |  |
| Liability as of October 25, 2014 |  | $ | 27 |  |  | $ | 25 |  |  | $ | 180 |  |  | $ | — |  |  | $ | 232 |  |


## us-gaap:ScheduleOfNewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000858877-14-000043:notes:269]
New Accounting Updates Recently Adopted

[0000858877-14-000043:notes:270]
In March 2013, the FASB issued an accounting standard update requiring an entity to release into net income the entire amount of a cumulative translation adjustment related to its investment in a foreign entity when as a parent it sells either a part or all of its investment in the foreign entity or no longer holds a controlling financial interest in a subsidiary or group of assets within the foreign entity.  This accounting standard update became effective for the Company beginning in the first quarter of fiscal 2015. The application of this accounting standard update did not have any impact to the Company's Consolidated Financial Statements.

[0000858877-14-000043:notes:271]
In July 2013, the FASB issued an accounting standard update that provides explicit guidance on the financial statement presentation of an unrecognized tax benefit when a net operating loss carryforward or a tax credit carryforward exists. Under the new standard update, an unrecognized tax benefit, or a portion of an unrecognized tax benefit, is to be presented in the financial statements as a reduction to a deferred tax asset for a net operating loss carryforward or a tax credit carryforward.  This accounting standard update became effective for the Company beginning in the first quarter of fiscal 2015 and applied prospectively. The application of this accounting standard update did not have a material impact to the Company's Consolidated Financial Statements.


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000858877-14-000043:notes:272]
Summarized financial information by segment for the three months ended October 25, 2014 and October 26, 2013, based on the Company’s internal management system and as utilized by the Company’s Chief Operating Decision Maker ("CODM"), is as follows (in millions):

[0000858877-14-000043:notes:273]
|  | Three Months Ended |
|  | October 25, 2014 |  | October 26, 2013 |
| Revenue: |  |  |  |
| Americas | $ | 7,501 |  |  | $ | 7,316 |  |
| EMEA | 3,002 |  |  | 2,933 |  |
| APJC | 1,742 |  |  | 1,836 |  |
| Total | $ | 12,245 |  |  | $ | 12,085 |  |
| Gross margin: |  |  |  |
| Americas | $ | 4,810 |  |  | $ | 4,650 |  |
| EMEA | 1,915 |  |  | 1,888 |  |
| APJC | 1,025 |  |  | 1,079 |  |
| Segment total | 7,750 |  |  | 7,617 |  |
| Unallocated corporate items | (417 | ) |  | (210 | ) |
| Total | $ | 7,333 |  |  | $ | 7,407 |  |


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000858877-14-000043:notes:274]
[same as prior period, unchanged from 0000858877-14-000014:notes:299]

[0000858877-14-000043:notes:275]
[same as prior period, unchanged from 0000858877-14-000014:notes:300]

[0000858877-14-000043:notes:276]
[same as prior period, unchanged from 0000858877-14-000014:notes:301]

[0000858877-14-000043:notes:277]
In April 2014, the FASB issued an accounting standard update that changes the criteria for reporting discontinued operations.  This accounting standard update raises the threshold for a disposal transaction to qualify as a discontinued operation and requires additional disclosures about discontinued operations and disposals of individually significant components that do not qualify as discontinued operations.  This accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2016.  Early adoption is permitted, but only for disposals that have not been reported in financial statements previously issued.  The Company is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.

[0000858877-14-000043:notes:278]
In May 2014, the FASB issued an accounting standard update related to revenue from contracts with customers, which will supersede nearly all current U.S. GAAP guidance on this topic and eliminate industry-specific guidance.  The underlying principle is to recognize revenue when promised goods or services are transferred to customers in an amount that reflects the consideration that is expected to be received for those goods or services. This accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2018. The new revenue standard may be applied retrospectively to each prior period presented or retrospectively with the cumulative effect recognized as of the date of adoption.  Early adoption is not permitted.  The Company is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000858877-14-000043:notes:279]
[same as prior period, unchanged from 0000858877-14-000014:notes:305]

[0000858877-14-000043:notes:280]
[same as prior period, unchanged from 0000858877-14-000014:notes:306]

[0000858877-14-000043:notes:281]
During the three months ended October 25, 2014, the Company declared and paid cash dividends of $0.19 per common share, or $973 million, on the Company’s outstanding common stock.  During the three months ended October 26, 2013, the Company declared and paid cash dividends of $0.17 per common share, or $914 million, on the Company’s outstanding common stock.

[0000858877-14-000043:notes:282]
[same as prior period, unchanged from 0000858877-14-000014:notes:308]

[0000858877-14-000043:notes:283]
[same as prior period, unchanged from 0000858877-14-000014:notes:309]

[0000858877-14-000043:notes:284]
In September 2001, the Company’s Board of Directors authorized a stock repurchase program. As of October 25, 2014, the Company’s Board of Directors had authorized an aggregate repurchase of up to $97 billion of common stock under this program, and the remaining authorized repurchase amount was $7.5 billion, with no termination date. A summary of the stock repurchase activity under the stock repurchase program, reported based on the trade date, is summarized as follows (in millions, except per-share amounts):

[0000858877-14-000043:notes:285]
|  | SharesRepurchased |  | Weighted-Average Priceper Share |  | AmountRepurchased |
| Cumulative balance at July 26, 2014 | 4,288 |  |  | $ | 20.63 |  |  | $ | 88,445 |  |
| Repurchase of common stock under the stock repurchase program (1) | 41 |  |  | 24.58 |  |  | 1,013 |  |
| Cumulative balance at October 25, 2014 | 4,329 |  |  | $ | 20.66 |  |  | $ | 89,458 |  |

[0000858877-14-000043:notes:286]
(1) Includes stock repurchases of $51 million, which were pending settlement as of October 25, 2014. There were $126 million of stock repurchases that were pending settlement as of July 26, 2014.

[0000858877-14-000043:notes:287]
[same as prior period, unchanged from 0000858877-14-000014:notes:313]

[0000858877-14-000043:notes:288]
[same as prior period, unchanged from 0000858877-14-000014:notes:314]

[0000858877-14-000043:notes:289]
For the three months ended October 25, 2014 and October 26, 2013, the Company repurchased approximately 14 million and 12 million shares, or $342 million and $286 million, of common stock, respectively, in settlement of employee tax withholding obligations due upon the vesting of restricted stock or stock units.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000858877-14-000043:notes:290]
| 6. | Balance Sheet Details |


## us-gaap:TreasuryStockTextBlock

[0000858877-14-000043:notes:291]
Supplemental Information

[0000858877-14-000043:notes:292]
In September 2001, the Company’s Board of Directors authorized a stock repurchase program. As of October 25, 2014, the Company’s Board of Directors had authorized an aggregate repurchase of up to $97 billion of common stock under this program with no termination date. The stock repurchases since the inception of this program and the related impacts on Cisco shareholders’ equity are summarized in the following table (in millions):

[0000858877-14-000043:notes:293]
|  | Shares ofCommonStock |  | Common Stockand AdditionalPaid-In Capital |  | RetainedEarnings |  | Total CiscoShareholders’Equity |
| Repurchases of common stock under the repurchase program | 4,329 |  |  | $ | 21,662 |  |  | $ | 67,796 |  |  | $ | 89,458 |  |


## csco:EntityWideDisclosureOnGeographicAreasLongLivedAssetsTableTextBlock

[0000858877-14-000043:notes:294]
Property and equipment information is based on the physical location of the assets. The following table presents property and equipment information for geographic areas (in millions):

[0000858877-14-000043:notes:295]
|  | October 25, 2014 |  | July 26, 2014 |
| Property and equipment, net: |  |  |  |
| United States | $ | 2,687 |  |  | $ | 2,697 |  |
| International | 546 |  |  | 555 |  |
| Total | $ | 3,233 |  |  | $ | 3,252 |  |


## csco:NetSalesForGroupsOfSimilarProductsAndServicesTableTextBlock

[0000858877-14-000043:notes:296]
The following table presents revenue for groups of similar products and services (in millions):

[0000858877-14-000043:notes:297]
|  | Three Months Ended |
|  | October 25, 2014 |  | October 26, 2013 |
| Revenue: |  |  |  |
| Switching | $ | 3,846 |  |  | $ | 3,740 |  |
| NGN Routing | 1,949 |  |  | 2,026 |  |
| Collaboration | 949 |  |  | 1,051 |  |
| Service Provider Video | 871 |  |  | 987 |  |
| Data Center | 693 |  |  | 601 |  |
| Wireless | 605 |  |  | 547 |  |
| Security | 455 |  |  | 365 |  |
| Other | 67 |  |  | 80 |  |
| Product | 9,435 |  |  | 9,397 |  |
| Service | 2,810 |  |  | 2,688 |  |
| Total | $ | 12,245 |  |  | $ | 12,085 |  |


## csco:SegmentReportingProductAndServicesNetSalesTextBlock

[0000858877-14-000043:notes:298]
| 17. | Segment Information and Major Customers |

[0000858877-14-000043:notes:299]
| (a) | Revenue and Gross Margin by Segment |

[0000858877-14-000043:notes:300]
The Company conducts business globally and is primarily managed on a geographic basis consisting of three segments: the Americas, EMEA, and APJC. The Company’s management makes financial decisions and allocates resources based on the information it receives from its internal management system. Sales are attributed to a segment based on the ordering location of the customer. The Company does not allocate research and development, sales and marketing, or general and administrative expenses to its segments in this internal management system because management does not include the information in its measurement of the performance of the operating segments. In addition, the Company does not allocate amortization and impairment of acquisition-related intangible assets, share-based compensation expense, significant litigation and other contingencies, impacts to cost of sales from purchase accounting adjustments to inventory, charges related to asset impairments and restructurings, and certain other charges to the gross margin for each segment because management does not include this information in its measurement of the performance of the operating segments.

[0000858877-14-000043:notes:301]
Revenue in the United States was $6.6 billion and $6.4 billion for the three months ended October 25, 2014 and October 26, 2013, respectively.

[0000858877-14-000043:notes:302]
| (b) | Revenue for Groups of Similar Products and Services |

[0000858877-14-000043:notes:303]
The Company designs, manufactures, and sells Internet Protocol (IP)-based networking and other products related to the communications and IT industry and provides services associated with these products and their use. The Company groups its products and technologies into the following categories: Switching, NGN Routing, Collaboration, Service Provider Video, Data Center, Wireless, Security, and Other Products. These products, primarily integrated by Cisco IOS Software, link geographically dispersed local-area networks (LANs), metropolitan-area networks (MANs), and wide-area networks (WANs).

[0000858877-14-000043:notes:304]
The Company has made certain reclassifications to the product revenue amounts for prior periods to conform to the current period’s presentation.

[0000858877-14-000043:notes:305]
| (c) | Additional Segment Information |

[0000858877-14-000043:notes:306]
The majority of the Company’s assets, excluding cash and cash equivalents and investments, as of October 25, 2014 and July 26, 2014 were attributable to its U.S. operations. The Company’s total cash and cash equivalents and investments held by various foreign subsidiaries were $48.3 billion and $47.4 billion as of October 25, 2014 and July 26, 2014, respectively, and the remaining $3.8 billion and $4.7 billion at the respective period ends were available in the United States.
