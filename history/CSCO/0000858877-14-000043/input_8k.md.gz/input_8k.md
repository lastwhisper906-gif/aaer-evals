# CSCO 8-K — 0001193125-14-409258 filed 2014-11-12

## item codes, every 8-K on or before 2014-11-20

- 2014-11-14 0001193125-14-413384 — 5.02
- 2014-11-12 0001193125-14-409258 — 2.02
- 2014-09-25 0001193125-14-353210 — 8.01
- 2014-09-12 0001193125-14-340480 — 5.02
- 2014-08-14 0001193125-14-308733 — 2.05
- 2014-08-13 0001193125-14-308403 — 2.02
- 2014-07-31 0001193125-14-289683 — 5.02
- 2014-06-25 0001193125-14-249157 — 8.01
- 2014-05-14 0001193125-14-199056 — 2.02
- 2014-03-26 0001193125-14-116588 — 8.01
- 2014-03-11 0001193125-14-093805 — 8.01
- 2014-03-03 0001193125-14-079163 — 1.01, 8.01, 9.01
- 2014-02-26 0001193125-14-069912 — 1.01, 9.01
- 2014-02-12 0001193125-14-048150 — 2.02
- 2013-12-23 0001193125-13-483099 — 8.01
- 2013-12-04 0001193125-13-462216 — 8.01
- 2013-11-20 0001193125-13-448477 — 5.02, 5.07, 9.01
- 2013-11-13 0001193125-13-440194 — 2.02
- 2013-08-15 0001193125-13-335218 — 2.05
- 2013-08-14 0001193125-13-334648 — 2.02
- 2013-07-23 0001193125-13-298129 — 8.01, 9.01
- 2013-06-24 0001193125-13-269064 — 8.01
- 2013-06-12 0001193125-13-256194 — 8.01
- 2013-06-07 0001193125-13-250920 — 8.01
- 2013-05-15 0001193125-13-222377 — 2.02
- 2013-03-26 0001193125-13-127015 — 8.01
- 2013-02-13 0001193125-13-055377 — 2.02
- 2013-02-01 0001193125-13-034682 — 5.02
- 2013-01-08 0001193125-13-006886 — 5.02, 9.01
- 2012-12-21 0001193125-12-513130 — 8.01
- 2012-12-19 0001193125-12-508424 — 8.01
- 2012-11-16 0001193125-12-474089 — 5.02, 5.07, 9.01
- 2012-11-13 0001193125-12-467422 — 2.02
- 2012-10-04 0001193125-12-415386 — 5.02, 5.03, 9.01
- 2012-09-19 0001193125-12-396875 — 5.02, 8.01
- 2012-08-15 0001193125-12-357479 — 2.02
- 2012-08-02 0001193125-12-332045 — 5.02
- 2012-06-27 0001193125-12-285742 — 8.01
- 2012-06-13 0001193125-12-269642 — 8.01
- 2012-05-09 0001193125-12-222045 — 2.02
- 2012-03-27 0001193125-12-134384 — 8.01
- 2012-03-15 0001193125-12-117538 — 8.01, 9.01
- 2012-02-17 0001193125-12-067542 — 1.01, 1.02, 2.03, 9.01
- 2012-02-08 0001193125-12-046545 — 2.02
- 2011-12-16 0001193125-11-343995 — 8.01
- 2011-12-08 0001193125-11-335127 — 5.02, 5.07, 9.01
- 2011-11-09 0001193125-11-304587 — 2.02
- 2011-09-29 0001193125-11-260065 — 8.01
- 2011-09-20 0001193125-11-252379 — 5.02, 9.01
- 2011-08-24 0001193125-11-231015 — 8.01
- 2011-08-10 0001193125-11-218133 — 2.02
- 2011-07-18 0001193125-11-190246 — 2.05
- 2011-06-22 0001193125-11-170849 — 8.01
- 2011-05-11 0001193125-11-135913 — 2.02
- 2011-03-28 0001193125-11-079927 — 8.01
- 2011-03-22 0001193125-11-073802 — 5.02 — amendment of 0001193125-11-043592
- 2011-03-18 0001193125-11-071279 — 8.01, 9.01
- 2011-03-16 0001193125-11-067985 — 1.01, 5.02, 8.01, 9.01
- 2011-03-15 0001193125-11-067331 — 1.01, 9.01
- 2011-03-09 0001193125-11-060123 — 8.01, 9.01
- 2011-02-23 0001193125-11-043592 — 5.02
- 2011-02-09 0001193125-11-028987 — 2.02
- 2011-01-31 0001193125-11-019101 — 1.01, 2.03
- 2010-12-17 0001193125-10-283392 — 8.01
- 2010-11-19 0001193125-10-265377 — 5.07
- 2010-11-10 0001193125-10-256001 — 2.02
- 2010-09-22 0001193125-10-214707 — 8.01
- 2010-09-16 0001193125-10-211456 — 7.01
- 2010-08-11 0001193125-10-186042 — 2.02
- 2010-06-29 0001193125-10-149956 — 8.01
- 2010-05-12 0001193125-10-117509 — 2.02
- 2010-02-17 0001193125-10-033290 — 5.02, 8.01, 9.01
- 2010-02-03 0001193125-10-020775 — 2.02
- 2009-11-25 0001193125-09-242589 — 8.01
- 2009-11-17 0001193125-09-236335 — 1.01, 8.01, 9.01
- 2009-11-13 0001193125-09-234405 — 1.01, 2.03, 9.01
- 2009-11-13 0001193125-09-234397 — 5.02 — amendment of 0001193125-09-189511
- 2009-11-12 0001193125-09-232971 — 5.02, 7.01, 9.01
- 2009-11-09 0001193125-09-228541 — 8.01, 9.01
- 2009-11-04 0001193125-09-223763 — 2.02
- 2009-10-14 0001193125-09-207912 — 8.01, 9.01
- 2009-10-05 0001193125-09-203556 — 8.01
- 2009-09-10 0001193125-09-189511 — 5.02
- 2009-09-04 0001193125-09-187835 — 5.02
- 2009-08-05 0001193125-09-165404 — 2.02
- 2009-07-27 0001193125-09-155861 — 5.02
- 2009-05-29 0001193125-09-121672 — 8.01
- 2009-05-06 0001193125-09-101570 — 2.02
- 2009-02-26 0001193125-09-038162 — 5.02
- 2009-02-17 0001193125-09-030546 — 1.01, 8.01, 9.01
- 2009-02-13 0001193125-09-029295 — 1.01, 2.03, 9.01
- 2009-02-04 0001193125-09-018793 — 2.02
- 2008-11-05 0001193125-08-225857 — 2.02
- 2008-09-11 0001193125-08-194695 — 7.01
- 2008-08-05 0001193125-08-166496 — 2.02
- 2008-06-20 0001193125-08-137504 — 8.01
- 2008-05-06 0001193125-08-104089 — 2.02
- 2008-03-21 0001193125-08-062838 — 8.01
- 2008-02-06 0001193125-08-021681 — 2.02
- 2008-01-23 0001193125-08-010589 — 5.02
- 2008-01-04 0001193125-08-001680 — 5.02, 9.01
- 2007-12-21 0001193125-07-269613 — 5.02
- 2007-11-19 0001193125-07-250345 — 5.02 — amendment of 0001193125-07-009285
- 2007-11-19 0001193125-07-250343 — 5.02, 9.01
- 2007-11-07 0001193125-07-238464 — 2.02
- 2007-09-24 0001193125-07-206279 — 8.01
- 2007-09-20 0001193125-07-204616 — 5.02, 7.01
- 2007-09-07 0001193125-07-197514 — 8.01
- 2007-08-17 0001193125-07-185320 — 1.01, 2.03, 9.01
- 2007-08-08 0001193125-07-174077 — 5.02
- 2007-08-07 0001193125-07-173689 — 2.02
- 2007-08-01 0001193125-07-168143 — 5.02
- 2007-05-15 0001193125-07-115800 — 8.01
- 2007-05-08 0001193125-07-106059 — 2.02
- 2007-03-23 0001193125-07-063033 — 5.02, 5.03, 8.01, 9.01
- 2007-03-21 0001193125-07-060631 — 1.01, 9.01
- 2007-02-06 0001193125-07-021349 — 2.02
- 2007-01-19 0001193125-07-009285 — 5.02
- 2006-12-22 0001193125-06-259241 — 8.01
- 2006-11-16 0001193125-06-237260 — 5.03, 8.01, 9.01
- 2006-11-08 0001193125-06-228341 — 2.02
- 2006-09-21 0001193125-06-194890 — 1.01, 7.01
- 2006-09-20 0001193125-06-194063 — 1.01
- 2006-09-15 0001193125-06-191845 — 5.02
- 2006-08-18 0001193125-06-176193 — 5.02
- 2006-08-08 0001193125-06-165719 — 2.02
- 2006-07-31 0001193125-06-157106 — 1.01, 9.01
- 2006-07-31 0001193125-06-157102 — 5.02 — amendment of 0001193125-06-017426
- 2006-06-08 0001193125-06-126879 — 5.02
- 2006-05-18 0001193125-06-115516 — 8.01
- 2006-05-12 0001193125-06-110924 — 9.01 — amendment of 0001193125-06-044013
- 2006-05-09 0001193125-06-105419 — 2.02
- 2006-03-29 0001193125-06-066990 — 1.01
- 2006-03-02 0001193125-06-044013 — 1.01, 2.01, 9.01
- 2006-02-28 0001193125-06-041452 — 1.01
- 2006-02-22 0001193125-06-036759 — 8.01
- 2006-02-22 0001193125-06-036433 — 1.01, 8.01, 9.01
- 2006-02-21 0001193125-06-035865 — 1.01, 2.03, 9.01
- 2006-02-10 0001193125-06-026218 — 8.01, 9.01
- 2006-02-07 0001193125-06-022234 — 2.02
- 2006-02-01 0001193125-06-017426 — 5.02
- 2005-11-18 0001193125-05-229535 — 1.01, 9.01
- 2005-11-16 0001193125-05-227987 — 1.01, 9.01
- 2005-11-16 0001193125-05-227983 — 5.02 — amendment of 0001193125-05-008843
- 2005-11-09 0001193125-05-221610 — 2.02
- 2005-09-29 0001193125-05-194217 — 7.01
- 2005-09-27 0001193125-05-192353 — 8.01
- 2005-09-21 0001193125-05-189234 — 1.01, 9.01
- 2005-09-19 0001193125-05-187646 — 8.01
- 2005-09-09 0001193125-05-183273 — 8.01
- 2005-09-08 0001193125-05-182307 — 1.01
- 2005-08-09 0001193125-05-162626 — 2.02
- 2005-07-15 0001193125-05-142738 — 8.01
- 2005-05-10 0001193125-05-102797 — 2.02
- 2005-03-30 0001193125-05-065123 — 1.01, 3.03, 9.01
- 2005-03-04 0001193125-05-042778 — 1.01
- 2005-02-08 0001193125-05-022181 — 2.02
- 2005-01-20 0001193125-05-008843 — 5.02
- 2004-12-23 0001193125-04-219331 — 8.01
- 2004-11-09 0001193125-04-191303 — 2.02
- 2004-08-23 0001193125-04-145198 — 1.01, 7.01
- 2004-08-19 0001193125-04-143859 — 5
- 2004-08-10 0001193125-04-136865 — 12
- 2004-05-11 0001193125-04-084721 — 12
- 2004-02-03 0001193125-04-013750 — 12
- 2003-11-05 0001193125-03-073418 — 12
- 2003-09-02 0001193125-03-044521 — 9
- 2003-08-05 0001193125-03-029223 — 12, 7
- 2003-07-18 0001193125-03-021155 — 5, 7
- 2003-06-05 0001012870-03-002949 — 5
- 2003-05-06 0000891618-03-002315 — 7, 9
- 2003-04-17 0000891618-03-001894 — 5, 7
- 2003-04-11 0000891618-03-001791 — 9
- 2003-03-20 0000891618-03-001326 — 5, 7
- 2003-02-04 0000891618-03-000518 — 7, 9
- 2003-01-28 0000891618-03-000271 — 5, 7
- 2002-12-27 0000891618-02-005686 — 5, 7
- 2002-10-23 0000891618-02-004715 — 5, 7
- 2002-10-11 0000891618-02-004620 — 5, 7
- 2002-09-18 0000891618-02-004352 — 5, 7
- 2002-08-20 0000891618-02-004001 — 5, 7
- 2002-08-05 0000891618-02-003498 — 5, 7
- 2002-07-03 0000891618-02-003099 — 5, 7
- 2002-05-14 0000891618-02-002407 — 5, 7
- 2002-02-05 0000891618-02-000412 — 5, 7
- 2001-09-28 0001095811-01-505261 — 5, 7
- 2001-09-14 0001095811-01-504917 — 5, 7
- 2001-08-24 0001095811-01-504581 — 5, 7
- 2001-07-30 0001095811-01-503468 — 5, 7
- 2001-07-12 0000891618-01-501567 — 5, 7
- 2001-05-11 0000891618-01-500638 — 5, 7
- 2001-02-27 0000891618-01-500076 — 5, 7
- 2001-02-20 0001095811-01-001530 — 5, 7
- 2001-02-08 0001095811-01-000848 — 5, 7
- 2001-02-07 0001095811-01-000768 — 5
- 2000-12-27 0001095811-00-005511 — 5
- 2000-12-21 0001095811-00-005427 — 5
- 2000-12-19 0001095811-00-005368 — 5
- 2000-11-15 0001095811-00-004830 — 5
- 2000-11-15 0001095811-00-004824 — 5
- 2000-11-13 0000891618-00-005023 — 5
- 2000-11-07 0001095811-00-004387 — 5, 7
- 2000-11-06 0001095811-00-004318 — 5
- 2000-09-29 0000891618-00-004739 — 5, 7
- 2000-09-28 0000891618-00-004722 — 5
- 2000-09-26 0001095811-00-003573 — 5
- 2000-09-15 0001095811-00-003413 — 5
- 2000-09-07 0001095811-00-003229 — 5
- 2000-08-15 0000891618-00-004430 — 5
- 2000-08-04 0001095811-00-002304 — 5, 7 — amendment, the index does not say of what
- 2000-07-28 0000891618-00-004132 — 5, 7
- 2000-06-29 0000891618-00-003637 — 5
- 2000-06-07 0000891618-00-003209 — 5
- 2000-05-26 0000891618-00-003054 — 5
- 2000-05-18 0000891618-00-002975 — 5, 7
- 2000-05-15 0000891618-00-002808 — 5, 7
- 2000-05-03 0000891618-00-002473 — 5
- 2000-04-03 0000891618-00-001936 — 5
- 2000-03-28 0000891618-00-001763 — 5
- 2000-03-27 0000891618-00-001722 — 5, 7
- 2000-03-16 0000891618-00-001512 — 5
- 2000-02-17 0000891618-00-001024 — 5, 7
- 2000-02-03 0000891618-00-000468 — 7 — amendment of 0000891618-99-005685
- 1999-12-22 0000891618-99-005792 — 5, 7
- 1999-12-15 0000891618-99-005685 — 5, 7
- 1999-11-17 0000891618-99-005313 — 5, 7
- 1999-11-04 0000891618-99-004862 — 5, 7
- 1999-10-20 0000891618-99-004625 — 5, 7
- 1999-09-27 0000891618-99-004333 — 5, 7
- 1999-08-26 0000891618-99-003978 — 5, 7
- 1999-08-13 0000891618-99-003764 — 5, 7 — amendment of 0000891618-99-003749
- 1999-08-13 0000891618-99-003749 — 5, 7
- 1999-07-02 0000891618-99-002980 — 5, 7
- 1999-05-14 0000891618-99-002221 — 5
- 1998-11-20 0000891618-98-005074 — 5, 7
- 1998-11-20 0000891618-98-005073 — 5, 7
- 1998-10-13 0000891618-98-004462 — 5, 7
- 1998-07-09 0000891618-98-003245 — 5, 7
- 1998-06-11 0000891618-98-002832 — 5, 7
- 1998-05-15 0000891618-98-002457 — 5, 7
- 1998-04-29 0000891618-98-001996 — 5
- 1998-02-11 0000891618-98-000584 — 5, 7
- 1997-09-09 0000891618-97-003723 — 5, 7
- 1997-08-22 0000891618-97-003559 — 5, 7
- 1997-07-01 0000891618-97-002807 — 5, 7
- 1997-01-22 0000891618-97-000120 — 5, 7
- 1996-10-15 0000891618-96-002283 — 5, 7 — amendment of 0000891618-96-002217
- 1996-10-01 0000891618-96-002217 — 5, 7
- 1996-07-23 0000891618-96-001305 — 2, 7
- 1996-04-26 0000891618-96-000253 — 2
- 1996-04-02 0000898430-96-001187 — 2, 7
- 1995-12-06 0000891618-95-000728 — 2, 7
- 1995-12-06 0000891618-95-000727 — 2, 7

## late-filing notifications on or before 2014-11-20

- none on or before 2014-11-20

## item 2.02 — earnings release, exhibit 99.1

[0001193125-14-409258:8k_2_02:1]
EX-99.1
2
d820464dex991.htm
EX-99.1

[0001193125-14-409258:8k_2_02:2]
EX-99.1

[0001193125-14-409258:8k_2_02:3]
Exhibit 99.1

[0001193125-14-409258:8k_2_02:4]
| Press Contact: |  |  |  | Investor Relations Contact: |
| Robyn Jenkins-Blum |  |  |  | Marilyn Mora |
| Cisco |  |  |  | Cisco |
| 1 (408) 853-9848 |  |  |  | 1 (408) 527-7452 |
| rojenkin@cisco.com |  |  |  | marilmor@cisco.com |

[0001193125-14-409258:8k_2_02:5]
CISCO REPORTS FIRST QUARTER EARNINGS

[0001193125-14-409258:8k_2_02:6]
Return to Growth, Strongest Q1 Revenue in History

[0001193125-14-409258:8k_2_02:7]
|  | • |  | Q1 Revenue: $12.2 billion (increase of 1% year over year) |

[0001193125-14-409258:8k_2_02:8]
|  | • |  | Q1 Earnings per Share: $0.35 GAAP; $0.54 non-GAAP |

[0001193125-14-409258:8k_2_02:9]
SAN JOSE, Calif. – November 12, 2014
– Cisco, the worldwide leader in networking that transforms how people connect, communicate and collaborate, today reported its first quarter results for the period ended October 25, 2014. Cisco reported first quarter revenue of $12.2
billion, net income on a generally accepted accounting principles (GAAP) basis of $1.8 billion or $0.35 per share, and non-GAAP net income of $2.8 billion or $0.54 per share.

[0001193125-14-409258:8k_2_02:10]
“We are pleased with our results and are very comfortable in our strategy to deliver innovative solutions which enable the next generation of IT and the
Internet of Everything. This was our strongest Q1 ever in terms of revenue, non-GAAP operating income, and non-GAAP EPS,” stated Cisco chairman and CEO John Chambers. “We continue to make progress towards becoming the #1 IT company in the
world. We are still in a tough environment, but seeing encouraging trends as cities, businesses, governments and schools are becoming more digitized. Our solutions continue to drive positive outcomes and enable productivity through the combination
of collaboration, mobility, security and efficiency across our customers’ businesses.”

[0001193125-14-409258:8k_2_02:11]
GAAP Results

[0001193125-14-409258:8k_2_02:12]
|  |  | Q1 2015 |  |  | Q1 2014 |  |  | Vs. Q1 2014 |  |
| Revenue |  | $ | 12.2 billion |  |  | $ | 12.1 billion |  |  |  | 1.3 | % |
| Net Income |  | $ | 1.8 billion |  |  | $ | 2.0 billion |  |  |  | (8.4 | )% |
| Earnings per Share |  | $ | 0.35 |  |  | $ | 0.37 |  |  |  | (5.4 | )% |

[0001193125-14-409258:8k_2_02:13]
Non-GAAP Results

[0001193125-14-409258:8k_2_02:14]
|  |  | Q1 2015 |  |  | Q1 2014 |  |  | Vs. Q1 2014 |  |
| Net Income |  | $ | 2.8 billion |  |  | $ | 2.9 billion |  |  |  | (2.3 | )% |
| Earnings per Share |  | $ | 0.54 |  |  | $ | 0.53 |  |  |  | 1.9 | % |

[0001193125-14-409258:8k_2_02:15]
A reconciliation between net income on a GAAP basis and non-GAAP net income is provided in the table following the
Consolidated Statements of Operations.

[0001193125-14-409258:8k_2_02:16]
Cisco will discuss first quarter results and business outlook on a conference call and webcast at 1:30 p.m.
Pacific Time today. Call information and related charts are available at http://investor.cisco.com.

[0001193125-14-409258:8k_2_02:17]
CFO Transition

[0001193125-14-409258:8k_2_02:18]
Frank Calderoni recently notified Cisco of his decision to step down as executive vice president and chief financial officer of Cisco, effective January 1,
2015. Cisco plans to appoint Kelly A. Kramer to succeed Mr. Calderoni. She is currently senior vice president, Business Technology and Operations Finance of Cisco.

[0001193125-14-409258:8k_2_02:19]
Cash and Cash Equivalents and Investments

[0001193125-14-409258:8k_2_02:20]
|  | • |  | Cash flows from operations were $2.5 billion for the first quarter of fiscal 2015, compared with $3.6 billion for the fourth quarter of fiscal 2014, and compared with $2.6 billion for the first quarter of fiscal 2014. |

[0001193125-14-409258:8k_2_02:21]
|  | • |  | Cash and cash equivalents and investments were $52.1 billion at the end of the first quarter of fiscal 2015, compared with $52.1 billion at the end of the fourth quarter of fiscal 2014, and compared with $48.2 billion at the end of the first quarter of fiscal 2014. |

[0001193125-14-409258:8k_2_02:22]
Dividends and Stock Repurchase Program

[0001193125-14-409258:8k_2_02:23]
|  | • |  | During the first quarter of fiscal 2015, Cisco paid a cash dividend of $0.19 per common share, or $973 million. |

[0001193125-14-409258:8k_2_02:24]
|  | • |  | Cisco repurchased approximately 41 million shares of common stock under the stock repurchase program at an average price of $24.58 per share for an aggregate purchase price of $1.0 billion during the first quarter of fiscal 2015. As of October 25, 2014, Cisco had repurchased and retired 4.3 billion shares of Cisco common stock at an average price of $20.66 per share for an aggregate purchase price of approximately $89.5 billion since the inception of the stock repurchase program. The remaining authorized amount for stock repurchases under this program is approximately $7.5 billion with no termination date. |

[0001193125-14-409258:8k_2_02:25]
“We had a solid quarter delivering results for Q1 consistent with our expectations,” stated Frank Calderoni, Cisco executive vice
president and chief financial officer. “Our strong cash flow, balance sheet, and ongoing commitment to return capital to shareholders demonstrates the strength of our strategy.”

[0001193125-14-409258:8k_2_02:26]
Internet of Everything

[0001193125-14-409258:8k_2_02:27]
|  | • |  | Cisco unveiled new Cisco® Connected Transportation Solutions designed to offer a safer and more productive commuter experience via the Internet of Everything (IoE). |

[0001193125-14-409258:8k_2_02:28]
|  | • |  | Cisco and the City of Berlin announced an IoE Innovation Center, to be located in Berlin, which will focus on manufacturing, transport and logistics. |

[0001193125-14-409258:8k_2_02:29]
|  | • |  | Marking the next phase of its expansion in India, Cisco unveiled the “Cisco Smart City” as a blueprint for the future of smart and connected communities in India. |

[0001193125-14-409258:8k_2_02:30]
|  | • |  | Cisco announced new Connected Safety and Security solutions that add intelligence and analytics from the core to the edge to help protect cities and businesses. |

[0001193125-14-409258:8k_2_02:31]
|  | • |  | Cisco outlined an expansion of its fog computing strategy with the second phase of its IOx platform for industrial scale Internet of Things (IoT) deployments. |

[0001193125-14-409258:8k_2_02:32]
|  | • |  | Addressing the growing demand for IoE skills, the Cisco Networking Academy announced the first global IoE curriculum. |

[0001193125-14-409258:8k_2_02:33]
Fast IT

[0001193125-14-409258:8k_2_02:34]
|  | • |  | Cisco broadened its storage networking portfolio to address the massive data growth across small-to cloud-scale storage networks. |

[0001193125-14-409258:8k_2_02:35]
|  | • |  | Cisco introduced innovations to its Unified Computing System™ business, delivering a broader and more powerful portfolio of technologies to help customers capitalize on rapidly changing landscapes in business and IT. |

[0001193125-14-409258:8k_2_02:36]
|  | • |  | Cisco introduced ASA with FirePOWER — the industry’s first threat-focused next-generation firewall. |

[0001193125-14-409258:8k_2_02:37]
|  | • |  | Cisco announced that it has added the support of more than 30 additional companies to its Intercloud ecosystem, expanding the reach of the global Intercloud by 250 additional data centers in 50 countries. |

[0001193125-14-409258:8k_2_02:38]
|  | • |  | Cisco announced that Shell has deployed the Cisco Secure Ops Solution to increase security maturity level by improving its cyber security and risk management while lowering costs of delivery and operations. |

[0001193125-14-409258:8k_2_02:39]
|  | • |  | Cisco expanded its Videoscape™ Virtualized Video Processing solution, the industry’s first fully orchestrated and virtualized solution, to enable faster, cost-effective scaling for multi-screen video workers. |

[0001193125-14-409258:8k_2_02:40]
Innovation

[0001193125-14-409258:8k_2_02:41]
|  | • |  | Cisco and Red Hat announced a new integrated infrastructure solution for OpenStack-based cloud deployments. |

[0001193125-14-409258:8k_2_02:42]
|  | • |  | Cisco completed the acquisition of Metacloud, Inc. Metacloud’s OpenStack-based cloud platform is expected to help accelerate Cisco’s strategy to build the world’s largest global Intercloud. |

[0001193125-14-409258:8k_2_02:43]
|  | • |  | Cisco completed the acquisition of Memoir Systems enabling the proliferation of affordable, fast memory for existing Cisco switch ASICs and helping advance Cisco’s ASIC innovations necessary to meet next-generation IT requirements. |

[0001193125-14-409258:8k_2_02:44]
2

[0001193125-14-409258:8k_2_02:45]
Editor’s Notes:

[0001193125-14-409258:8k_2_02:46]
|  | • |  | Q1 fiscal year 2015 conference call to discuss Cisco’s results along with its business outlook will be held on Wednesday, November 12, 2014 at 1:30 p.m. Pacific Time. Conference call number is 1-888-848-6507 (United States) or 1-212-519-0847 (international). |

[0001193125-14-409258:8k_2_02:47]
|  | • |  | Conference call replay will be available from 4:00 p.m. Pacific Time, November 12, 2014 to 11:59 p.m. Pacific Time, on November 19, 2014 at 1-800-835-3804 (United States) or 1-402-280-1654 (international). The replay will also be available via webcast from November 12, 2014 through January 16, 2015 on the Cisco Investor Relations website at http://investor.cisco.com. |

[0001193125-14-409258:8k_2_02:48]
|  | • |  | Additional information regarding Cisco’s financials, as well as a webcast of the conference call with visuals designed to guide participants through the call, will be available at 1:30 p.m. Pacific Time, November 12, 2014. Text of the conference call’s prepared remarks will be available within 24 hours of completion of the call. The webcast will include both the prepared remarks and the question-and-answer session. This information, along with GAAP reconciliation information, will be available on the Cisco Investor Relations website at http://investor.cisco.com. |

[0001193125-14-409258:8k_2_02:49]
About
Cisco

[0001193125-14-409258:8k_2_02:50]
Cisco (NASDAQ: CSCO) is the worldwide leader in IT that helps companies seize the opportunities of tomorrow by proving that amazing things can
happen when you connect the previously unconnected. For ongoing news, please go to http://thenetwork.cisco.com.

[0001193125-14-409258:8k_2_02:51]
###

[0001193125-14-409258:8k_2_02:52]
This release includes non-GAAP net income, non-GAAP effective tax rates, non-GAAP net income per share data, non-GAAP inventory turns and free cash flow.

[0001193125-14-409258:8k_2_02:53]
These non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with generally accepted accounting principles and
may be different from non-GAAP measures used by other companies. In addition, these non-

[0001193125-14-409258:8k_2_02:54]
3

[0001193125-14-409258:8k_2_02:55]
GAAP measures are not based on any comprehensive set of accounting rules or principles. Cisco believes that non-GAAP measures have limitations in that they do not reflect all of the amounts
associated with Cisco’s results of operations as determined in accordance with GAAP and that these measures should only be used to evaluate Cisco’s results of operations in conjunction with the corresponding GAAP measures.

[0001193125-14-409258:8k_2_02:56]
Cisco believes that the presentation of non-GAAP net income, non-GAAP effective tax rates, and non-GAAP net income per share data, when shown in conjunction
with the corresponding GAAP measures, provides useful information to investors and management regarding financial and business trends relating to its financial condition and results of operations. In addition, Cisco believes that the presentation of
non-GAAP inventory turns provides useful information to investors and management regarding financial and business trends relating to inventory management based on the operating activities of the periods presented. Cisco believes that the
presentation of free cash flow, which it defines as the net cash provided by operating activities less cash used to acquire property and equipment, to be a liquidity measure that provides useful information to management and investors because of its
intent to return a stated percentage of free cash flow to shareholders in the form of dividends and stock repurchases. Cisco further regards free cash flow as a useful measure because it reflects cash that can be used to, among other things, invest
in its business, make strategic acquisitions, repurchase common stock, and pay dividends on its common stock, after deducting capital investments.

[0001193125-14-409258:8k_2_02:57]
For
its internal budgeting process, Cisco’s management uses financial statements that do not include, when applicable, share-based compensation expense, amortization of acquisition-related intangible assets, impact to cost of sales from purchase
accounting adjustments to inventory, acquisition-related/divestiture costs, significant asset impairments and restructurings, significant litigation and other contingencies, the income tax effects of the foregoing, and significant tax matters.
Cisco’s management also uses the foregoing non-GAAP measures, in addition to the corresponding GAAP measures, in reviewing the financial results of Cisco. In prior periods, Cisco has excluded other items that it no longer excludes for purposes
of its non-GAAP financial measures. From time to time in the future there may be other items that Cisco may exclude for purposes of its internal budgeting process and in reviewing its financial results. For additional information on the items
excluded by Cisco from one or more of its non-GAAP financial measures, refer to the Form 8-K regarding this release furnished today to the Securities and Exchange Commission.

[0001193125-14-409258:8k_2_02:58]
Copyright © 2014 Cisco and/or its affiliates. All rights reserved. Cisco, the Cisco logo, Unified
Computing System, and Videoscape are trademarks or registered trademarks of Cisco and/or its affiliates in the U.S. and other countries. To view a list of Cisco trademarks, go to: www.cisco.com/go/trademarks. Third-party trademarks mentioned in this
document are the property of their respective owners. The use of the word partner does not imply a partnership relationship between Cisco and any other company. This document is Cisco Public Information.

[0001193125-14-409258:8k_2_02:59]
4

[0001193125-14-409258:8k_2_02:60]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-14-409258:8k_2_02:61]
(In millions, except per-share amounts)

[0001193125-14-409258:8k_2_02:62]
(Unaudited)

[0001193125-14-409258:8k_2_02:63]
|  |  | Three Months Ended |  |
|  |  | October 25,2014 |  |  | October 26,2013 |  |
| REVENUE: |  |  |  |  |
| Product |  | $ | 9,435 |  |  | $ | 9,397 |  |
| Service |  |  | 2,810 |  |  |  | 2,688 |  |
| Total revenue |  |  | 12,245 |  |  |  | 12,085 |  |
| COST OF SALES: |  |  |  |  |
| Product |  |  | 3,919 |  |  |  | 3,747 |  |
| Service |  |  | 993 |  |  |  | 931 |  |
| Total cost of sales |  |  | 4,912 |  |  |  | 4,678 |  |
| GROSS MARGIN |  |  | 7,333 |  |  |  | 7,407 |  |
| OPERATING EXPENSES: |  |  |  |  |
| Research and development |  |  | 1,583 |  |  |  | 1,724 |  |
| Sales and marketing |  |  | 2,515 |  |  |  | 2,411 |  |
| General and administrative |  |  | 504 |  |  |  | 515 |  |
| Amortization of purchased intangible assets |  |  | 71 |  |  |  | 65 |  |
| Restructuring and other charges |  |  | 318 |  |  |  | 237 |  |
| Total operating expenses |  |  | 4,991 |  |  |  | 4,952 |  |
| OPERATING INCOME |  |  | 2,342 |  |  |  | 2,455 |  |
| Interest income |  |  | 179 |  |  |  | 169 |  |
| Interest expense |  |  | (139 | ) |  |  | (140 | ) |
| Other income (loss), net |  |  | (22 | ) |  |  | 56 |  |
| Interest and other income (loss), net |  |  | 18 |  |  |  | 85 |  |
| INCOME BEFORE PROVISION FOR INCOME TAXES |  |  | 2,360 |  |  |  | 2,540 |  |
| Provision for income taxes |  |  | 532 |  |  |  | 544 |  |
| NET INCOME |  | $ | 1,828 |  |  | $ | 1,996 |  |
| Net income per share: |  |  |  |  |
| Basic |  | $ | 0.36 |  |  | $ | 0.37 |  |
| Diluted |  | $ | 0.35 |  |  | $ | 0.37 |  |
| Shares used in per-share calculation: |  |  |  |  |
| Basic |  |  | 5,112 |  |  |  | 5,378 |  |
| Diluted |  |  | 5,156 |  |  |  | 5,430 |  |
| Cash dividends declared per common share |  | $ | 0.19 |  |  | $ | 0.17 |  |

[0001193125-14-409258:8k_2_02:64]
5

[0001193125-14-409258:8k_2_02:65]
RECONCILIATION OF GAAP TO NON-GAAP NET INCOME

[0001193125-14-409258:8k_2_02:66]
(In millions, except per-share amounts)

[0001193125-14-409258:8k_2_02:67]
|  |  | Three Months Ended |  |
|  |  | October 25,2014 |  |  | October 26,2013 |  |
| GAAP net income |  | $ | 1,828 |  |  | $ | 1,996 |  |
| Adjustments to cost of sales: |  |  |  |  |
| Share-based compensation expense |  |  | 48 |  |  |  | 43 |  |
| Amortization of acquisition-related intangible assets |  |  | 181 |  |  |  | 167 |  |
| Patent portfolio charge |  |  | 188 |  |  |  | — |  |
| Total adjustments to GAAP cost of sales |  |  | 417 |  |  |  | 210 |  |
| Adjustments to operating expenses: |  |  |  |  |
| Share-based compensation expense |  |  | 325 |  |  |  | 269 |  |
| Amortization of acquisition-related intangible assets |  |  | 71 |  |  |  | 65 |  |
| Acquisition-related/divestiture costs |  |  | 101 |  |  |  | 308 |  |
| Significant asset impairments and restructurings |  |  | 318 |  |  |  | 237 |  |
| Total adjustments to GAAP operating expenses |  |  | 815 |  |  |  | 879 |  |
| Total adjustments to GAAP income before provision for income taxes |  |  | 1,232 |  |  |  | 1,089 |  |
| Income tax effect of non-GAAP adjustments |  |  | (258 | ) |  |  | (218 | ) |
| Non-GAAP net income |  | $ | 2,802 |  |  | $ | 2,867 |  |
| Diluted net income per share: |  |  |  |  |
| GAAP |  | $ | 0.35 |  |  | $ | 0.37 |  |
| Non-GAAP |  | $ | 0.54 |  |  | $ | 0.53 |  |

[0001193125-14-409258:8k_2_02:68]
RECONCILIATION OF GAAP TO NON-GAAP EFFECTIVE TAX RATE

[0001193125-14-409258:8k_2_02:69]
|  |  | Three Months Ended |  |
|  |  | October 25,2014 |  |  | October 26,2013 |  |
| GAAP effective tax rate |  |  | 22.5 | % |  |  | 21.4 | % |
| Tax effect of non-GAAP adjustments to net income |  |  | (0.5 | )% |  |  | (0.4 | )% |
| Non-GAAP effective tax rate |  |  | 22.0 | % |  |  | 21.0 | % |

[0001193125-14-409258:8k_2_02:70]
6

[0001193125-14-409258:8k_2_02:71]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001193125-14-409258:8k_2_02:72]
(In millions)

[0001193125-14-409258:8k_2_02:73]
(Unaudited)

[0001193125-14-409258:8k_2_02:74]
|  |  | October 25,2014 |  |  | July 26,2014 |  |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 4,387 |  |  | $ | 6,726 |  |
| Investments |  |  | 47,720 |  |  |  | 45,348 |  |
| Accounts receivable, net of allowance for doubtful accounts of $276 at October 25, 2014 and $265 at July 26, 2014 |  |  | 4,375 |  |  |  | 5,157 |  |
| Inventories |  |  | 1,676 |  |  |  | 1,591 |  |
| Financing receivables, net |  |  | 4,265 |  |  |  | 4,153 |  |
| Deferred tax assets |  |  | 2,689 |  |  |  | 2,808 |  |
| Other current assets |  |  | 1,284 |  |  |  | 1,331 |  |
| Total current assets |  |  | 66,396 |  |  |  | 67,114 |  |
| Property and equipment, net |  |  | 3,233 |  |  |  | 3,252 |  |
| Financing receivables, net |  |  | 3,691 |  |  |  | 3,918 |  |
| Goodwill |  |  | 24,364 |  |  |  | 24,239 |  |
| Purchased intangible assets, net |  |  | 3,066 |  |  |  | 3,280 |  |
| Other assets |  |  | 3,228 |  |  |  | 3,331 |  |
| TOTAL ASSETS |  | $ | 103,978 |  |  | $ | 105,134 |  |
| LIABILITIES AND EQUITY |  |  |  |  |
| Current liabilities: |  |  |  |  |
| Short-term debt |  | $ | 1,357 |  |  | $ | 508 |  |
| Accounts payable |  |  | 1,022 |  |  |  | 1,032 |  |
| Income taxes payable |  |  | 94 |  |  |  | 159 |  |
| Accrued compensation |  |  | 2,638 |  |  |  | 3,181 |  |
| Deferred revenue |  |  | 9,449 |  |  |  | 9,478 |  |
| Other current liabilities |  |  | 5,496 |  |  |  | 5,451 |  |
| Total current liabilities |  |  | 20,056 |  |  |  | 19,809 |  |
| Long-term debt |  |  | 19,615 |  |  |  | 20,401 |  |
| Income taxes payable |  |  | 1,504 |  |  |  | 1,851 |  |
| Deferred revenue |  |  | 4,295 |  |  |  | 4,664 |  |
| Other long-term liabilities |  |  | 1,793 |  |  |  | 1,748 |  |
| Total liabilities |  |  | 47,263 |  |  |  | 48,473 |  |
| Total equity |  |  | 56,715 |  |  |  | 56,661 |  |
| TOTAL LIABILITIES AND EQUITY |  | $ | 103,978 |  |  | $ | 105,134 |  |

[0001193125-14-409258:8k_2_02:75]
7

[0001193125-14-409258:8k_2_02:76]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-14-409258:8k_2_02:77]
(In millions)

[0001193125-14-409258:8k_2_02:78]
(Unaudited)

[0001193125-14-409258:8k_2_02:79]
|  |  | Three Months Ended |  |
|  |  | October 25,2014 |  |  | October 26,2013 |  |
| Cash flows from operating activities: |  |  |  |  |
| Net income |  | $ | 1,828 |  |  | $ | 1,996 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Depreciation, amortization, and other |  |  | 596 |  |  |  | 591 |  |
| Share-based compensation expense |  |  | 369 |  |  |  | 309 |  |
| Provision for receivables |  |  | 43 |  |  |  | 23 |  |
| Deferred income taxes |  |  | 236 |  |  |  | 130 |  |
| Excess tax benefits from share-based compensation |  |  | (71 | ) |  |  | (55 | ) |
| (Gains) losses on investments and other, net |  |  | 29 |  |  |  | (108 | ) |
| Change in operating assets and liabilities, net of effects of acquisitions and divestitures: |  |  |  |  |
| Accounts receivable |  |  | 723 |  |  |  | 361 |  |
| Inventories |  |  | (107 | ) |  |  | 22 |  |
| Financing receivables |  |  | (2 | ) |  |  | (37 | ) |
| Other assets |  |  | 5 |  |  |  | 28 |  |
| Accounts payable |  |  | (5 | ) |  |  | (29 | ) |
| Income taxes, net |  |  | (398 | ) |  |  | (389 | ) |
| Accrued compensation |  |  | (495 | ) |  |  | (460 | ) |
| Deferred revenue |  |  | (328 | ) |  |  | (307 | ) |
| Other liabilities |  |  | 68 |  |  |  | 574 |  |
| Net cash provided by operating activities |  |  | 2,491 |  |  |  | 2,649 |  |
| Cash flows from investing activities: |  |  |  |  |
| Purchases of investments |  |  | (9,761 | ) |  |  | (8,835 | ) |
| Proceeds from sales of investments |  |  | 3,450 |  |  |  | 4,733 |  |
| Proceeds from maturities of investments |  |  | 3,906 |  |  |  | 4,058 |  |
| Acquisition of businesses, net of cash and cash equivalents acquired |  |  | (184 | ) |  |  | (2,447 | ) |
| Purchases of investments in privately held companies |  |  | (50 | ) |  |  | (134 | ) |
| Return of investments in privately held companies |  |  | 42 |  |  |  | 33 |  |
| Acquisition of property and equipment |  |  | (285 | ) |  |  | (315 | ) |
| Proceeds from sales of property and equipment |  |  | 3 |  |  |  | 156 |  |
| Other |  |  | 2 |  |  |  | (4 | ) |
| Net cash used in investing activities |  |  | (2,877 | ) |  |  | (2,755 | ) |
| Cash flows from financing activities: |  |  |  |  |
| Issuances of common stock |  |  | 353 |  |  |  | 444 |  |
| Repurchases of common stock - repurchase program |  |  | (1,088 | ) |  |  | (1,898 | ) |
| Shares repurchased for tax withholdings on vesting of restricted stock units |  |  | (342 | ) |  |  | (286 | ) |
| Short-term borrowings, original maturities less than 90 days, net |  |  | (4 | ) |  |  | (2 | ) |
| Issuances of debt |  |  | — |  |  |  | 4 |  |
| Repayments of debt |  |  | (3 | ) |  |  | — |  |
| Excess tax benefits from share-based compensation |  |  | 71 |  |  |  | 55 |  |
| Dividends paid |  |  | (973 | ) |  |  | (914 | ) |
| Other |  |  | 33 |  |  |  | 32 |  |
| Net cash used in financing activities |  |  | (1,953 | ) |  |  | (2,565 | ) |
| Net decrease in cash and cash equivalents |  |  | (2,339 | ) |  |  | (2,671 | ) |
| Cash and cash equivalents, beginning of period |  |  | 6,726 |  |  |  | 7,925 |  |
| Cash and cash equivalents, end of period |  | $ | 4,387 |  |  | $ | 5,254 |  |
| Supplemental cash flow information: |  |  |  |  |
| Cash paid for interest |  | $ | 263 |  |  | $ | 221 |  |
| Cash paid for income taxes, net |  | $ | 694 |  |  | $ | 803 |  |

[0001193125-14-409258:8k_2_02:80]
8

[0001193125-14-409258:8k_2_02:81]
CASH AND CASH EQUIVALENTS AND INVESTMENTS

[0001193125-14-409258:8k_2_02:82]
(In millions)

[0001193125-14-409258:8k_2_02:83]
|  |  | October 25,2014 |  |  | July 26,2014 |  |
| Cash and cash equivalents and investments: |  |  |  |  |
| Cash and cash equivalents |  | $ | 4,387 |  |  | $ | 6,726 |  |
| Fixed income securities |  |  | 45,923 |  |  |  | 43,396 |  |
| Publicly traded equity securities |  |  | 1,797 |  |  |  | 1,952 |  |
| Total |  | $ | 52,107 |  |  | $ | 52,074 |  |

[0001193125-14-409258:8k_2_02:84]
RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES

[0001193125-14-409258:8k_2_02:85]
TO FREE CASH FLOW (NON-GAAP)

[0001193125-14-409258:8k_2_02:86]
(In millions)

[0001193125-14-409258:8k_2_02:87]
|  |  | Three Months Ended |  |
|  |  | October 25,2014 |  |  | July 26,2014 |  |  | October 26,2013 |  |
| Net cash provided by operating activities |  | $ | 2,491 |  |  | $ | 3,612 |  |  | $ | 2,649 |  |
| Acquisition of property and equipment |  |  | (285 | ) |  |  | (325 | ) |  |  | (315 | ) |
| Free cash flow |  | $ | 2,206 |  |  | $ | 3,287 |  |  | $ | 2,334 |  |

[0001193125-14-409258:8k_2_02:88]
DIVIDENDS PAID AND REPURCHASES OF COMMON STOCK

[0001193125-14-409258:8k_2_02:89]
(In millions, except per-share amounts)

[0001193125-14-409258:8k_2_02:90]
|  |  | DIVIDENDS |  |  | STOCK REPURCHASE PROGRAM |  |  | TOTAL |  |
| Quarter Ended |  | Per Share |  |  | Amount |  |  | Shares |  |  | Weighted-Average Priceper Share |  |  | Amount |  |  | Amount |  |
| Fiscal 2015 |  |  |  |  |  |  |  |  |  |  |  |  |
| October 25, 2014 |  | $ | 0.19 |  |  | $ | 973 |  |  |  | 41 |  |  | $ | 24.58 |  |  | $ | 1,013 |  |  | $ | 1,986 |  |
| Fiscal 2014 |  |  |  |  |  |  |  |  |  |  |  |  |
| July 26, 2014 |  | $ | 0.19 |  |  | $ | 974 |  |  |  | 61 |  |  | $ | 25.11 |  |  | $ | 1,514 |  |  | $ | 2,488 |  |
| April 26, 2014 |  |  | 0.19 |  |  |  | 974 |  |  |  | 90 |  |  | $ | 22.24 |  |  |  | 2,005 |  |  |  | 2,979 |  |
| January 25, 2014 |  |  | 0.17 |  |  |  | 896 |  |  |  | 185 |  |  | $ | 21.73 |  |  |  | 4,020 |  |  |  | 4,916 |  |
| October 26, 2013 |  |  | 0.17 |  |  |  | 914 |  |  |  | 84 |  |  | $ | 23.65 |  |  |  | 2,000 |  |  |  | 2,914 |  |
| Total |  | $ | 0.72 |  |  | $ | 3,758 |  |  |  | 420 |  |  | $ | 22.71 |  |  | $ | 9,539 |  |  | $ | 13,297 |  |

[0001193125-14-409258:8k_2_02:91]
ACCOUNTS RECEIVABLE AND DSO

[0001193125-14-409258:8k_2_02:92]
(In millions, except DSO)

[0001193125-14-409258:8k_2_02:93]
|  |  | October 25,2014 |  |  | July 26,2014 |  |  | October 26,2013 |  |
| Accounts receivable, net |  | $ | 4,375 |  |  | $ | 5,157 |  |  | $ | 5,188 |  |
| Days sales outstanding in accounts receivable (DSO) |  |  | 33 |  |  |  | 38 |  |  |  | 39 |  |

[0001193125-14-409258:8k_2_02:94]
INVENTORIES

[0001193125-14-409258:8k_2_02:95]
(In millions)

[0001193125-14-409258:8k_2_02:96]
|  |  | October 25,2014 |  |  | July 26,2014 |  |  | October 26,2013 |  |
| Inventories: |  |  |  |  |
| Raw materials |  | $ | 173 |  |  | $ | 77 |  |  | $ | 80 |  |
| Work in process |  |  | 3 |  |  |  | 5 |  |  |  | 7 |  |
| Finished goods: |  |  |  |  |
| Distributor inventory and deferred cost of sales |  |  | 654 |  |  |  | 595 |  |  |  | 619 |  |
| Manufactured finished goods |  |  | 535 |  |  |  | 606 |  |  |  | 464 |  |
| Total finished goods |  |  | 1,189 |  |  |  | 1,201 |  |  |  | 1,083 |  |
| Service-related spares |  |  | 275 |  |  |  | 273 |  |  |  | 257 |  |
| Demonstration systems |  |  | 36 |  |  |  | 35 |  |  |  | 39 |  |
| Total |  | $ | 1,676 |  |  | $ | 1,591 |  |  | $ | 1,466 |  |

[0001193125-14-409258:8k_2_02:97]
INVENTORY TURNS AND RECONCILIATION OF GAAP TO NON-GAAP

[0001193125-14-409258:8k_2_02:98]
COST OF SALES USED IN INVENTORY TURNS

[0001193125-14-409258:8k_2_02:99]
(In millions, except annualized inventory turns)

[0001193125-14-409258:8k_2_02:100]
|  |  | Three Months Ended |  |
|  |  | October 25,2014 |  |  | July 26,2014 |  |  | October 26,2013 |  |
| Annualized inventory turns - GAAP |  |  | 12.0 |  |  |  | 12.7 |  |  |  | 12.7 |  |
| Cost of sales adjustments |  |  | (1.0 | ) |  |  | (0.6 | ) |  |  | (0.6 | ) |
| Annualized inventory turns - non-GAAP |  |  | 11.0 |  |  |  | 12.1 |  |  |  | 12.1 |  |
| GAAP cost of sales |  | $ | 4,912 |  |  | $ | 4,952 |  |  | $ | 4,678 |  |
| Cost of sales adjustments: |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | (48 | ) |  |  | (49 | ) |  |  | (43 | ) |
| Amortization of acquisition-related intangible assets |  |  | (181 | ) |  |  | (180 | ) |  |  | (167 | ) |
| Acquisition-related/divestiture costs |  |  | — |  |  |  | (1 | ) |  |  | — |  |
| Patent portfolio charge |  |  | (188 | ) |  |  | — |  |  |  | — |  |
| Non-GAAP cost of sales |  | $ | 4,495 |  |  | $ | 4,722 |  |  | $ | 4,468 |  |

[0001193125-14-409258:8k_2_02:101]
10

[0001193125-14-409258:8k_2_02:102]
DEFERRED REVENUE

[0001193125-14-409258:8k_2_02:103]
(In millions)

[0001193125-14-409258:8k_2_02:104]
|  |  | October 25,2014 |  |  | July 26,2014 |  |  | October 26,2013 |  |
| Deferred revenue: |  |  |  |  |
| Service |  | $ | 9,029 |  |  | $ | 9,640 |  |  | $ | 8,896 |  |
| Product: |  |  |  |  |
| Unrecognized revenue on product shipments and other deferred revenue |  |  | 4,056 |  |  |  | 3,924 |  |  |  | 3,628 |  |
| Cash receipts related to unrecognized revenue from two-tier distributors |  |  | 659 |  |  |  | 578 |  |  |  | 683 |  |
| Total product deferred revenue |  |  | 4,715 |  |  |  | 4,502 |  |  |  | 4,311 |  |
| Total |  | $ | 13,744 |  |  | $ | 14,142 |  |  | $ | 13,207 |  |
| Reported as: |  |  |  |  |
| Current |  | $ | 9,449 |  |  | $ | 9,478 |  |  | $ | 9,212 |  |
| Noncurrent |  |  | 4,295 |  |  |  | 4,664 |  |  |  | 3,995 |  |
| Total |  | $ | 13,744 |  |  | $ | 14,142 |  |  | $ | 13,207 |  |

[0001193125-14-409258:8k_2_02:105]
SUMMARY OF SHARE-BASED COMPENSATION EXPENSE

[0001193125-14-409258:8k_2_02:106]
(In millions)

[0001193125-14-409258:8k_2_02:107]
|  |  | Three Months Ended |  |
|  |  | October 25,2014 |  |  | October 26,2013 |  |
| Cost of sales - product |  | $ | 11 |  |  | $ | 10 |  |
| Cost of sales - service |  |  | 37 |  |  |  | 33 |  |
| Share-based compensation expense in cost of sales |  |  | 48 |  |  |  | 43 |  |
| Research and development |  |  | 119 |  |  |  | 92 |  |
| Sales and marketing |  |  | 147 |  |  |  | 123 |  |
| General and administrative |  |  | 59 |  |  |  | 54 |  |
| Restructuring and other charges |  |  | (4 | ) |  |  | (3 | ) |
| Share-based compensation expense in operating expenses |  |  | 321 |  |  |  | 266 |  |
| Total share-based compensation expense |  | $ | 369 |  |  | $ | 309 |  |
| Income tax benefit for share-based compensation |  | $ | 94 |  |  | $ | 78 |  |

[0001193125-14-409258:8k_2_02:108]
11
