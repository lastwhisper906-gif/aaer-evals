# CSCO MD&A — 0000858877-14-000043


## mdna

[0000858877-14-000043:mdna:1]
[same as prior period, unchanged from 0000858877-14-000014:mdna:1]

[0000858877-14-000043:mdna:2]
[same as prior period, unchanged from 0000858877-14-000014:mdna:2]

[0000858877-14-000043:mdna:3]
[same as prior period, unchanged from 0000858877-14-000014:mdna:3]

[0000858877-14-000043:mdna:4]
We design, manufacture, and sell Internet Protocol (IP) based networking products and services related to the communications and information technology (IT) industry. Our customers include businesses of all sizes, public institutions, telecommunications companies, other service providers and individuals. We connect people, process, data and things with products that transport data, voice, and video within buildings, across campuses, and around the world. We are a key strategic partner to companies that helps them as they seek to make the most of the Internet of Everything (IoE) and connect the unconnected.

[0000858877-14-000043:mdna:5]
[same as prior period, unchanged from 0000858877-14-000014:mdna:5]

[0000858877-14-000043:mdna:6]
|  | Three Months Ended |  |
|  | October 25, 2014 |  | October 26, 2013 |  | Variance |  |
| Revenue | $ | 12,245 |  |  | $ | 12,085 |  |  | 1.3 | % |  |
| Gross margin percentage | 59.9 | % |  | 61.3 | % |  | (1.4 | ) | pts |
| Research and development | $ | 1,583 |  |  | $ | 1,724 |  |  | (8.2 | )% |  |
| Sales and marketing | $ | 2,515 |  |  | $ | 2,411 |  |  | 4.3 | % |  |
| General and administrative | $ | 504 |  |  | $ | 515 |  |  | (2.1 | )% |  |
| Total R&D, sales and marketing, general and administrative | $ | 4,602 |  |  | $ | 4,650 |  |  | (1.0 | )% |  |
| Total as a percentage of revenue | 37.6 | % |  | 38.5 | % |  | (0.9 | ) | pts |
| Amortization of purchased intangible assets | $ | 71 |  |  | $ | 65 |  |  | 9.2 | % |  |
| Restructuring and other charges | $ | 318 |  |  | $ | 237 |  |  | 34.2 | % |  |
| Operating income as a percentage of revenue | 19.1 | % |  | 20.3 | % |  | (1.2 | ) | pts |
| Income tax percentage | 22.5 | % |  | 21.4 | % |  | 1.1 |  | pts |
| Net income | $ | 1,828 |  |  | $ | 1,996 |  |  | (8.4 | )% |  |
| Net income as a percentage of revenue | 14.9 | % |  | 16.5 | % |  | (1.6 | ) | pts |
| Earnings per share—diluted | $ | 0.35 |  |  | $ | 0.37 |  |  | (5.4 | )% |  |

[0000858877-14-000043:mdna:7]
40

[0000858877-14-000043:mdna:8]
[same as prior period, unchanged from 0000858877-14-000014:mdna:8]

[0000858877-14-000043:mdna:9]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-14-000043:mdna:10]
Three Months Ended October 25, 2014 Compared with Three Months Ended October 26, 2013

[0000858877-14-000043:mdna:11]
In the first quarter of fiscal 2015, revenue increased by 1% as compared with the first quarter of fiscal 2014. Within the total revenue change, product revenue was flat while service revenue increased 5%. Total gross margin decreased by 1.4 percentage points, driven by unfavorable impacts from pricing and the $188 million Rockstar patent portfolio charge partially offset by productivity improvement and the favorable impact of mix.  As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses, collectively, decreased by 0.9 percentage points. Operating income as a percentage of revenue decreased by 1.2 percentage points, primarily as a result of the increase in restructuring and other charges. Diluted earnings per share decreased by 5% from the prior year, driven by an 8% decrease in net income.

[0000858877-14-000043:mdna:12]
In the first quarter of fiscal 2015, total revenue increased by $0.2 billion as compared to the first quarter of fiscal 2014. Revenue from the Americas increased by $0.2 billion, reflecting higher product revenue in the United States. EMEA revenue increased by $0.1 billion, led by higher product revenue in the United Kingdom. Revenue in our APJC segment decreased by $0.1 billion, led by a product revenue decline in China. The weakness we encountered in emerging countries in fiscal 2014 continued in certain  of the emerging countries in the first quarter of fiscal 2015.  We experienced mixed results in the emerging countries of Brazil, Russia, India, China, and Mexico (“BRICM”), which in the aggregate, experienced a 7% product revenue decline, as product revenue declines in China and Russia were only partially offset by increases in the other three countries.  We believe that the product revenue declines in various emerging countries were driven by the impact of economic and geopolitical challenges in these countries.

[0000858877-14-000043:mdna:13]
From a customer market standpoint, in the first quarter of fiscal 2015, while the service provider market continued to experience a decline in product revenue, we had solid product revenue growth in the public sector and commercial markets, and modest growth in the enterprise market. The product revenue increase in the public sector market was led by higher spending from the U.S. federal government.

[0000858877-14-000043:mdna:14]
From a product category perspective, product revenue was flat year over year. Overall, our product revenue from our core product areas was relatively flat as the increase in product revenue from our Switching products was substantially offset by the decrease in revenue from our NGN Routing products. Our other major product categories experienced revenue changes ranging from a 12% decrease in Service Provider Video to a 25% increase in Security. Service revenue increased by 5% year over year.

[0000858877-14-000043:mdna:15]
In summary, in the first quarter of fiscal 2015, we continued to see some improved business momentum. We also continued to experience several of the challenges we have encountered in recent quarters including reduced spending by our service provider customers and weakness in certain emerging countries. We did see our product transitions in certain areas start to improve. We are not expecting the challenges in service provider and emerging countries to improve for at least a few quarters.

[0000858877-14-000043:mdna:16]
41

[0000858877-14-000043:mdna:17]
[same as prior period, unchanged from 0000858877-14-000014:mdna:18]

[0000858877-14-000043:mdna:18]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-14-000043:mdna:19]
[same as prior period, unchanged from 0000858877-14-000014:mdna:20]

[0000858877-14-000043:mdna:20]
Our strategy is to deliver the integrated architectures, solutions, and outcomes to help our customers grow, manage costs, and mitigate risk. We see our customers, in almost every industry, becoming increasingly reliant on technology—and specifically the network—to meet their business objectives and compete successfully in the market.

[0000858877-14-000043:mdna:21]
Our focus continues to be on capitalizing on market transitions to maintain leadership in our core markets and to enter new markets where the network is foundational.  We believe this focus best positions us to become a more relevant and trusted partner to our customers and to expand our share of our customers’ IT spending.  We are focused on driving the innovation, speed, agility, and efficiencies in our company required to deliver leading technology solutions for our customers and shareholder value for our investors.

[0000858877-14-000043:mdna:22]
Over the last few years, we have been working to transform our business to move from selling individual products and services to selling products and services integrated into architectures and solutions, as well as to meet customers' business outcomes. As a part of this transformation, we are making changes to how we are organized and how we deliver our technology.  We believe these changes enable us to better meet our customers’ requirements and help them stay ahead of market transitions.

[0000858877-14-000043:mdna:23]
For a full discussion of our strategy and focus areas, see Item 1. Business in our Annual Report on Form 10-K for the year ended July 26, 2014.

[0000858877-14-000043:mdna:24]
[same as prior period, unchanged from 0000858877-14-000014:mdna:28]

[0000858877-14-000043:mdna:25]
The following is a summary of our other key financial measures for the first quarter of fiscal 2015 (in millions, except days sales outstanding in accounts receivable (DSO) and annualized inventory turns):

[0000858877-14-000043:mdna:26]
|  |  | October 25, 2014 |  | July 26, 2014 |
| Cash and cash equivalents and investments |  | $ | 52,107 |  |  | $ | 52,074 |  |
| Deferred revenue |  | $ | 13,744 |  |  | $ | 14,142 |  |
| DSO |  | 33 days |  |  | 38 days |  |
| Inventories |  | $ | 1,676 |  |  | $ | 1,591 |  |
| Annualized inventory turns |  | 12.0 |  |  | 12.7 |  |

[0000858877-14-000043:mdna:27]
|  |  | Three Months Ended |
|  |  | October 25, 2014 |  | October 26, 2013 |
| Cash provided by operating activities |  | $ | 2,491 |  |  | $ | 2,649 |  |
| Repurchases of common stock—stock repurchase program |  | $ | 1,013 |  |  | $ | 2,000 |  |
| Dividends |  | $ | 973 |  |  | $ | 914 |  |

[0000858877-14-000043:mdna:28]
[same as prior period, unchanged from 0000858877-14-000014:mdna:33]

[0000858877-14-000043:mdna:29]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-14-000043:mdna:30]
[same as prior period, unchanged from 0000858877-14-000014:mdna:35]

[0000858877-14-000043:mdna:31]
The preparation of financial statements and related disclosures in conformity with accounting principles generally accepted in the United States requires us to make judgments, assumptions, and estimates that affect the amounts reported in the Consolidated Financial Statements and accompanying notes.  Note 2 to the Consolidated Financial Statements in our Annual Report on Form 10-K for the year ended July 26, 2014, as updated as applicable in Note 2 to the Consolidated Financial Statements herein, describes the significant accounting policies and methods used in the preparation of the Consolidated Financial Statements.  The accounting policies described below are significantly affected by critical accounting estimates.  Such accounting policies require significant judgments, assumptions, and estimates used in the preparation of the Consolidated Financial Statements, and actual results could differ materially from the amounts reported based on these policies.

[0000858877-14-000043:mdna:32]
[same as prior period, unchanged from 0000858877-14-000014:mdna:37]

[0000858877-14-000043:mdna:33]
[same as prior period, unchanged from 0000858877-14-000014:mdna:38]

[0000858877-14-000043:mdna:34]
[same as prior period, unchanged from 0000858877-14-000014:mdna:39]

[0000858877-14-000043:mdna:35]
[same as prior period, unchanged from 0000858877-14-000014:mdna:40]

[0000858877-14-000043:mdna:36]
[same as prior period, unchanged from 0000858877-14-000014:mdna:41]

[0000858877-14-000043:mdna:37]
[same as prior period, unchanged from 0000858877-14-000014:mdna:42]

[0000858877-14-000043:mdna:38]
In instances where final acceptance of the product, system, or solution is specified by the customer, revenue is deferred until all acceptance criteria have been met.  When a sale involves multiple deliverables, such as sales of products that include services, the multiple deliverables are evaluated to determine the unit of accounting, and the entire fee from the arrangement is allocated to each unit of accounting based on the relative selling price.  Revenue is recognized when the revenue recognition criteria for each unit of accounting are met.  For hosting arrangements, we recognize subscription revenue ratably over the subscription period, while usage revenue is recognized based on utilization. Software subscription revenue is deferred and recognized ratably over the subscription term upon delivery of the first product and commencement of the term.

[0000858877-14-000043:mdna:39]
The amount of product and service revenue recognized in a given period is affected by our judgment as to whether an arrangement includes multiple deliverables and, if so, our valuation of the units of accounting for multiple deliverables. According to the accounting guidance prescribed in Accounting Standards Codification (ASC) 605, Revenue Recognition, we use vendor-specific objective evidence of selling price (VSOE) for each of those units, when available. We determine VSOE based on our normal pricing and discounting practices for the specific product or service when sold separately.  In determining VSOE, we require that a substantial majority of the historical standalone transactions have the selling prices for a product or service fall within a reasonably narrow pricing range, generally evidenced by approximately 80% of such historical standalone transactions falling within plus or minus 15% of the median rates. When VSOE does not exist, we apply the selling price hierarchy to applicable multiple-deliverable arrangements.  Under the selling price hierarchy, third-party evidence of selling price (TPE) will be considered if VSOE does not exist, and estimated selling price (ESP) will be used if neither VSOE nor TPE is available.  Generally, we are not able to determine TPE because our go-to-market strategy differs from that of others in our markets, and the extent of our proprietary technology varies among comparable products or services from those of our peers.  In determining ESP, we apply significant judgment as we weigh a variety of factors, based on the facts and circumstances of the arrangement.  We typically arrive at an ESP for a product or service that is not sold separately by considering company-specific factors such as geographies, competitive landscape, internal costs, profitability objectives, pricing practices used to establish bundled pricing, and existing portfolio pricing and discounting.

[0000858877-14-000043:mdna:40]
[same as prior period, unchanged from 0000858877-14-000014:mdna:45]

[0000858877-14-000043:mdna:41]
As our business and offerings evolve over time, our pricing practices may be required to be modified accordingly, which could result in changes in selling prices, including both VSOE and ESP, in subsequent periods. There were no material impacts during the first quarter of fiscal 2015, nor do we currently expect a material impact in the next 12 months on our revenue recognition due to any changes in our VSOE, TPE, or ESP.

[0000858877-14-000043:mdna:42]
Revenue deferrals relate to the timing of revenue recognition for specific transactions based on financing arrangements, service, support, and other factors. Financing arrangements may include sales-type, direct-financing, and operating leases, loans, and guarantees of third-party financing. Our deferred revenue for products was $4.7 billion and $4.5 billion as of October 25, 2014 and July 26, 2014, respectively. Technical support services revenue is deferred and recognized ratably over the period during which the services are to be performed, which typically is from one to three years. Advanced services revenue is recognized upon delivery

[0000858877-14-000043:mdna:43]
43

[0000858877-14-000043:mdna:44]
[same as prior period, unchanged from 0000858877-14-000014:mdna:48]

[0000858877-14-000043:mdna:45]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-14-000043:mdna:46]
or completion of performance. Our deferred revenue for services was $9.0 billion and $9.6 billion as of October 25, 2014 and July 26, 2014, respectively.

[0000858877-14-000043:mdna:47]
We make sales to distributors which we refer to as two-tier systems of sales to the end customer.  Revenue from distributors is recognized based on a sell-through method using information provided by them.  Our distributors participate in various cooperative marketing and other programs, and we maintain estimated accruals and allowances for these programs.  If actual credits received by our distributors under these programs were to deviate significantly from our estimates, which are based on historical experience, our revenue could be adversely affected.

[0000858877-14-000043:mdna:48]
[same as prior period, unchanged from 0000858877-14-000014:mdna:52]

[0000858877-14-000043:mdna:49]
[same as prior period, unchanged from 0000858877-14-000014:mdna:53]

[0000858877-14-000043:mdna:50]
|  |  | October 25, 2014 |  | July 26, 2014 |
| Allowance for doubtful accounts |  | $ | 276 |  |  | $ | 265 |  |
| Percentage of gross accounts receivable |  | 5.9 | % |  | 4.9 | % |
| Allowance for credit loss—lease receivables |  | $ | 248 |  |  | $ | 233 |  |
| Percentage of gross lease receivables(1) |  | 6.6 | % |  | 6.2 | % |
| Allowance for credit loss—loan receivables |  | $ | 84 |  |  | $ | 98 |  |
| Percentage of gross loan receivables |  | 4.8 | % |  | 5.8 | % |

[0000858877-14-000043:mdna:51]
(1) Calculated as allowance for credit loss on lease receivables as a percentage of gross lease receivables before unearned income.

[0000858877-14-000043:mdna:52]
[same as prior period, unchanged from 0000858877-14-000014:mdna:55]

[0000858877-14-000043:mdna:53]
[same as prior period, unchanged from 0000858877-14-000014:mdna:56]

[0000858877-14-000043:mdna:54]
A reserve for future sales returns is established based on historical trends in product return rates. The reserve for future sales returns as of October 25, 2014 and July 26, 2014 was $123 million and $135 million, respectively, and was recorded as a reduction of our accounts receivable.  If the actual future returns were to deviate from the historical data on which the reserve had been established, our revenue could be adversely affected.

[0000858877-14-000043:mdna:55]
[same as prior period, unchanged from 0000858877-14-000014:mdna:60]

[0000858877-14-000043:mdna:56]
Our inventory balance was $1.7 billion and $1.6 billion as of October 25, 2014 and July 26, 2014, respectively. Inventory is written down based on excess and obsolete inventories, determined primarily by future demand forecasts. Inventory write-downs are measured as the difference between the cost of the inventory and market, based upon assumptions about future demand, and are charged to the provision for inventory, which is a component of our cost of sales. At the point of the loss recognition, a new, lower cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis.

[0000858877-14-000043:mdna:57]
We record a liability for firm, noncancelable, and unconditional purchase commitments with contract manufacturers and suppliers for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of

[0000858877-14-000043:mdna:58]
[same as prior period, unchanged from 0000858877-14-000014:mdna:58]

[0000858877-14-000043:mdna:59]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-14-000043:mdna:60]
October 25, 2014, the liability for these purchase commitments was $169 million, compared with $162 million as of July 26, 2014, and was included in other current liabilities.

[0000858877-14-000043:mdna:61]
Our provision for inventory was $11 million and $18 million for the first quarter of fiscal 2015 and 2014, respectively. The provision for the liability related to purchase commitments with contract manufacturers and suppliers was $32 million and $30 million for the first quarter of fiscal 2015 and 2014, respectively. If there were to be a sudden and significant decrease in demand for our products, or if there were a higher incidence of inventory obsolescence because of rapidly changing technology and customer requirements, we could be required to increase our inventory write-downs, and our liability for purchase commitments with contract manufacturers and suppliers, and accordingly our profitability, could be adversely affected. We regularly evaluate our exposure for inventory write-downs and the adequacy of our liability for purchase commitments. Inventory and supply chain management remain areas of focus as we balance the need to maintain supply chain flexibility to help ensure competitive lead times with the risk of inventory obsolescence, particularly in light of current macroeconomic uncertainties and conditions and the resulting potential for changes in future demand forecast.

[0000858877-14-000043:mdna:62]
Loss Contingencies and Product Warranties

[0000858877-14-000043:mdna:63]
We are subject to the possibility of various losses arising in the ordinary course of business. We consider the likelihood of impairment of an asset or the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated. We regularly evaluate information available to us to determine whether such accruals should be made or adjusted and whether new accruals are required.

[0000858877-14-000043:mdna:64]
Third parties, including customers, have in the past and may in the future assert claims or initiate litigation related to exclusive patent, copyright, trademark, and other intellectual property rights to technologies and related standards that are relevant to us. These assertions have increased over time as a result of our growth and the general increase in the pace of patent claims assertions, particularly in the United States. If any infringement or other intellectual property claim made against us by any third party is successful, or if we fail to develop non-infringing technology or license the proprietary rights on commercially reasonable terms and conditions, our business, operating results, and financial condition could be materially and adversely affected.

[0000858877-14-000043:mdna:65]
[same as prior period, unchanged from 0000858877-14-000014:mdna:67]

[0000858877-14-000043:mdna:66]
Our liability for product warranties, included in other current liabilities, was $436 million as of October 25, 2014, compared with $446 million as of July 26, 2014. Our products are generally covered by a warranty for periods ranging from 90 days to five years, and for some products we provide a limited lifetime warranty. We accrue for warranty costs as part of our cost of sales based on associated material costs, technical support labor costs, and associated overhead. Material cost is estimated based primarily upon historical trends in the volume of product returns within the warranty period and the cost to repair or replace the equipment. Technical support labor cost is estimated based primarily upon historical trends in the rate of customer cases and the cost to support the customer cases within the warranty period. Overhead cost is applied based on estimated time to support warranty activities.

[0000858877-14-000043:mdna:67]
The provision for product warranties during the first quarter of fiscal 2015 and 2014 was $143 million and $196 million,  respectively. If we experience an increase in warranty claims compared with our historical experience, or if the cost of servicing warranty claims is greater than expected, our profitability could be adversely affected.

[0000858877-14-000043:mdna:68]
[same as prior period, unchanged from 0000858877-14-000014:mdna:78]

[0000858877-14-000043:mdna:69]
Our fixed income and publicly traded equity securities, collectively, are reflected in the Consolidated Balance Sheets at a fair value of $47.7 billion as of October 25, 2014, compared with $45.3 billion as of July 26, 2014. Our fixed income investment portfolio as of October 25, 2014 consisted primarily of high quality investment-grade securities. See Note 8 to the Consolidated Financial Statements.

[0000858877-14-000043:mdna:70]
As described more fully in Note 9 to the Consolidated Financial Statements, a valuation hierarchy is based on the level of independent, objective evidence available regarding the value of the investments. It encompasses three classes of investments: Level 1 consists of securities for which there are quoted prices in active markets for identical securities; Level 2 consists of securities for which observable inputs other than Level 1 inputs are used, such as quoted prices for similar securities in active markets or quoted prices for identical securities in less active markets and model-derived valuations for which the variables are derived from,

[0000858877-14-000043:mdna:71]
[same as prior period, unchanged from 0000858877-14-000014:mdna:69]

[0000858877-14-000043:mdna:72]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-14-000043:mdna:73]
or corroborated by, observable market data; and Level 3 consists of securities for which there are unobservable inputs to the valuation methodology that are significant to the measurement of the fair value.

[0000858877-14-000043:mdna:74]
Our Level 2 securities are valued using quoted market prices for similar instruments or nonbinding market prices that are corroborated by observable market data. We use inputs such as actual trade data, benchmark yields, broker/dealer quotes, and other similar data, which are obtained from independent pricing vendors, quoted market prices, or other sources to determine the ultimate fair value of our assets and liabilities. We use such pricing data as the primary input, to which we have not made any material adjustments during the periods presented, to make our assessments and determinations as to the ultimate valuation of our investment portfolio. We are ultimately responsible for the financial statements and underlying estimates.

[0000858877-14-000043:mdna:75]
The inputs and fair value are reviewed for reasonableness, may be further validated by comparison to publicly available information, and could be adjusted based on market indices or other information that management deems material to its estimate of fair value. The assessment of fair value can be difficult and subjective. However, given the relative reliability of the inputs we use to value our investment portfolio, and because substantially all of our valuation inputs are obtained using quoted market prices for similar or identical assets, we do not believe that the nature of estimates and assumptions affected by levels of subjectivity and judgment was material to the valuation of the investment portfolio as of October 25, 2014. We had no Level 3 assets measured at fair value on a recurring basis as of October 25, 2014.

[0000858877-14-000043:mdna:76]
[same as prior period, unchanged from 0000858877-14-000014:mdna:85]

[0000858877-14-000043:mdna:77]
[same as prior period, unchanged from 0000858877-14-000014:mdna:86]

[0000858877-14-000043:mdna:78]
[same as prior period, unchanged from 0000858877-14-000014:mdna:87]

[0000858877-14-000043:mdna:79]
[same as prior period, unchanged from 0000858877-14-000014:mdna:88]

[0000858877-14-000043:mdna:80]
There were no impairment charges on our investments in publicly traded equity securities and fixed income securities in the first quarters of fiscal 2015 and 2014. Our ongoing consideration of all the factors described previously could result in additional impairment charges in the future, which could adversely affect our net income.

[0000858877-14-000043:mdna:81]
We also have investments in privately held companies, some of which are in the startup or development stages. Our investments in privately held companies as of October 25, 2014 were $886 million, compared with $899 million as of July 26, 2014, and were included in other assets. We monitor these investments for events or circumstances indicative of potential impairment, and we make appropriate reductions in carrying values if we determine that an impairment charge is required, based primarily on the financial condition and near-term prospects of these companies. These investments are inherently risky because the markets for the technologies or products these companies are developing are typically in the early stages and may never materialize. Our impairment charge on investments in privately held companies was $1 million for the first quarter of each of fiscal 2015 and 2014.

[0000858877-14-000043:mdna:82]
[same as prior period, unchanged from 0000858877-14-000014:mdna:91]

[0000858877-14-000043:mdna:83]
[same as prior period, unchanged from 0000858877-14-000014:mdna:92]

[0000858877-14-000043:mdna:84]
[same as prior period, unchanged from 0000858877-14-000014:mdna:82]

[0000858877-14-000043:mdna:85]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-14-000043:mdna:86]
The goodwill recorded in the Consolidated Balance Sheets as of October 25, 2014 and July 26, 2014 was $24.4 billion and $24.2 billion, respectively.  In response to changes in industry and market conditions, we could be required to strategically realign our resources and consider restructuring, disposing of, or otherwise exiting businesses, which could result in an impairment of goodwill. There was no impairment of goodwill in the first quarters of fiscal 2015 and 2014.

[0000858877-14-000043:mdna:87]
We make judgments about the recoverability of purchased intangible assets with finite lives whenever events or changes in circumstances indicate that an impairment may exist. Recoverability of purchased intangible assets with finite lives is measured by comparing the carrying amount of the asset to the future undiscounted cash flows the asset is expected to generate. We review indefinite-lived intangible assets for impairment annually or whenever events or changes in circumstances indicate that the asset might be impaired. If the asset is considered to be impaired, the amount of any impairment is measured as the difference between the carrying value and the fair value of the impaired asset. Assumptions and estimates about future values and remaining useful lives of our purchased intangible assets are complex and subjective. They can be affected by a variety of factors, including external factors such as industry and economic trends, and internal factors such as changes in our business strategy and our internal forecasts. There were no impairment charges related to purchased intangible assets for the first quarters of fiscal 2015 and 2014. Our ongoing consideration of all the factors described previously could result in additional impairment charges in the future, which could adversely affect our net income.

[0000858877-14-000043:mdna:88]
[same as prior period, unchanged from 0000858877-14-000014:mdna:98]

[0000858877-14-000043:mdna:89]
We are subject to income taxes in the United States and numerous foreign jurisdictions. Our effective tax rates differ from the statutory rate, primarily due to the tax impact of state taxes, foreign operations, R&D tax credits, domestic manufacturing deductions, tax audit settlements, nondeductible compensation, international realignments, and transfer pricing adjustments. Our effective tax rate was 22.5% and 21.4% in the first quarter of fiscal 2015 and 2014, respectively.

[0000858877-14-000043:mdna:90]
[same as prior period, unchanged from 0000858877-14-000014:mdna:100]

[0000858877-14-000043:mdna:91]
[same as prior period, unchanged from 0000858877-14-000014:mdna:101]

[0000858877-14-000043:mdna:92]
[same as prior period, unchanged from 0000858877-14-000014:mdna:102]

[0000858877-14-000043:mdna:93]
[same as prior period, unchanged from 0000858877-14-000014:mdna:95]

[0000858877-14-000043:mdna:94]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-14-000043:mdna:95]
[same as prior period, unchanged from 0000858877-14-000014:mdna:106]

[0000858877-14-000043:mdna:96]
[same as prior period, unchanged from 0000858877-14-000014:mdna:107]

[0000858877-14-000043:mdna:97]
[same as prior period, unchanged from 0000858877-14-000014:mdna:108]

[0000858877-14-000043:mdna:98]
|  |  | Three Months Ended |
|  |  | October 25, 2014 |  | October 26, 2013 |  | Variance in Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |
| Product |  | $ | 9,435 |  |  | $ | 9,397 |  |  | $ | 38 |  |  | 0.4 | % |
| Percentage of revenue |  | 77.1 | % |  | 77.8 | % |  |  |  |  |  |  |
| Service |  | 2,810 |  |  | 2,688 |  |  | 122 |  |  | 4.5 | % |
| Percentage of revenue |  | 22.9 | % |  | 22.2 | % |  |  |  |  |  |  |
| Total |  | $ | 12,245 |  |  | $ | 12,085 |  |  | $ | 160 |  |  | 1.3 | % |

[0000858877-14-000043:mdna:99]
[same as prior period, unchanged from 0000858877-14-000014:mdna:110]

[0000858877-14-000043:mdna:100]
|  |  | Three Months Ended |
|  |  | October 25, 2014 |  | October 26, 2013 |  | Variance in Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 7,501 |  |  | $ | 7,316 |  |  | $ | 185 |  |  | 2.5 | % |
| Percentage of revenue |  | 61.3 | % |  | 60.5 | % |  |  |  |  |
| EMEA |  | 3,002 |  |  | 2,933 |  |  | 69 |  |  | 2.4 | % |
| Percentage of revenue |  | 24.5 | % |  | 24.3 | % |  |  |  |  |
| APJC |  | 1,742 |  |  | 1,836 |  |  | (94 | ) |  | (5.1 | )% |
| Percentage of revenue |  | 14.2 | % |  | 15.2 | % |  |  |  |  |
| Total |  | $ | 12,245 |  |  | $ | 12,085 |  |  | $ | 160 |  |  | 1.3 | % |

[0000858877-14-000043:mdna:101]
Three Months Ended October 25, 2014 Compared with Three Months Ended October 26, 2013

[0000858877-14-000043:mdna:102]
For the first quarter of fiscal 2015, as compared with the first quarter of fiscal 2014, total revenue increased by 1%.  Product revenue was flat, while service revenue increased by 5%.  Our total revenue reflected growth in our Americas and EMEA geographic segments, while revenue declined in the APJC segment. The emerging countries of BRICM, in the aggregate, experienced a 7% product revenue decline, with declines in China and Russia only partially offset by increases in the other three countries.

[0000858877-14-000043:mdna:103]
We conduct business globally in numerous currencies. The direct effect of foreign currency fluctuations on revenue has not been material because our revenue is primarily denominated in U.S. dollars. However, if the U.S. dollar strengthens relative to other currencies, such strengthening could have an indirect effect on our revenue to the extent it raises the cost of our products to non-U.S. customers and thereby reduces demand. A weaker U.S. dollar could have the opposite effect. However, the precise indirect effect of currency fluctuations is difficult to measure or predict because our revenue is influenced by many factors in addition to the impact of such currency fluctuations. Our revenue in first quarter of fiscal 2015 may have been adversely affected by the depreciation of the local currency relative to the U.S. dollar in certain emerging countries, although as noted above, such indirect effects are difficult to measure.

[0000858877-14-000043:mdna:104]
In addition to the impact of macroeconomic factors, such as a reduced IT spending environment and budget-driven reductions in spending by government entities, revenue by segment in a particular period may be significantly impacted by several factors related to revenue recognition, including the complexity of transactions such as multiple-element arrangements; the mix of financing arrangements provided to our channel partners and customers; and final acceptance of the product, system, or solution, among other factors. In addition, certain customers tend to make large and sporadic purchases, and the revenue related to these transactions may also be affected by the timing of revenue recognition, which in turn would impact the revenue of the relevant segment. As has been the case in certain of our emerging countries from time to time, customers require greater levels of financing arrangements, service, and support, and these activities may occur in future periods, which may also impact the timing of the recognition of revenue.

[0000858877-14-000043:mdna:105]
48

[0000858877-14-000043:mdna:106]
[same as prior period, unchanged from 0000858877-14-000014:mdna:104]

[0000858877-14-000043:mdna:107]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-14-000043:mdna:108]
[same as prior period, unchanged from 0000858877-14-000014:mdna:121]

[0000858877-14-000043:mdna:109]
[same as prior period, unchanged from 0000858877-14-000014:mdna:122]

[0000858877-14-000043:mdna:110]
|  |  | Three Months Ended |
|  |  | October 25, 2014 |  | October 26, 2013 |  | Variance in Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 5,684 |  |  | $ | 5,533 |  |  | $ | 151 |  |  | 2.7 | % |
| Percentage of product revenue |  | 60.2 | % |  | 58.9 | % |  |  |  |  |
| EMEA |  | 2,396 |  |  | 2,381 |  |  | 15 |  |  | 0.6 | % |
| Percentage of product revenue |  | 25.4 | % |  | 25.3 | % |  |  |  |  |
| APJC |  | 1,355 |  |  | 1,483 |  |  | (128 | ) |  | (8.6 | )% |
| Percentage of product revenue |  | 14.4 | % |  | 15.8 | % |  |  |  |  |
| Total |  | $ | 9,435 |  |  | $ | 9,397 |  |  | $ | 38 |  |  | 0.4 | % |

[0000858877-14-000043:mdna:111]
Three Months Ended October 25, 2014 Compared with Three Months Ended October 26, 2013

[0000858877-14-000043:mdna:112]
[same as prior period, unchanged from 0000858877-14-000014:mdna:124]

[0000858877-14-000043:mdna:113]
Product revenue in the Americas segment increased by 3%, led by solid growth in the public sector market and, to a lesser extent, growth in the commercial and enterprise markets. Product revenue increased in the U.S. public sector market, led by higher sales to the U.S. federal government. Within the Americas segment, we continued to experience a product revenue decline in the service provider market.  From a country perspective, product revenue increased by 3% in the United States, 1% in Canada, 12% in Mexico and 8% in Brazil, partially offset by product revenue declines in certain countries within Latin America.

[0000858877-14-000043:mdna:114]
[same as prior period, unchanged from 0000858877-14-000014:mdna:129]

[0000858877-14-000043:mdna:115]
Product revenue in the EMEA segment increased by 1%, led by growth in the commercial market and, to a lesser extent, growth in the service provider market. We experienced product revenue declines in the enterprise and public sector markets. Product revenue from emerging countries within EMEA decreased by 5%, led by a 22% decrease in Russia.  Product revenue for the remainder of EMEA, which primarily comprises countries in western Europe, grew by 3%.

[0000858877-14-000043:mdna:116]
[same as prior period, unchanged from 0000858877-14-000014:mdna:136]

[0000858877-14-000043:mdna:117]
Product revenue in the APJC segment decreased by 9%. The decrease in product revenue was across all customer markets, led by a significant decline in the service provider market. From a country perspective, product revenue decreased in China, Australia, and Japan by 24%, 13%, and 4%, respectively. These decreases were partially offset by an increase in product revenue of 27% in India.

[0000858877-14-000043:mdna:118]
[same as prior period, unchanged from 0000858877-14-000014:mdna:116]

[0000858877-14-000043:mdna:119]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-14-000043:mdna:120]
[same as prior period, unchanged from 0000858877-14-000014:mdna:144]

[0000858877-14-000043:mdna:121]
In addition to the primary view on a geographic basis, we also prepare financial information related to groups of similar products and customer markets for various purposes. Our product categories consist of the following categories (with subcategories in parentheses): Switching (fixed switching, modular switching, and storage); NGN Routing (high-end routers, mid-range and low-end routers, and other NGN Routing products); Collaboration (unified communications, Cisco TelePresence, and conferencing); Service Provider Video (infrastructure, video software and solutions); Data Center; Wireless; Security; and Other Products. The Other Products category consists primarily of emerging technology products and other networking products.

[0000858877-14-000043:mdna:122]
[same as prior period, unchanged from 0000858877-14-000014:mdna:146]

[0000858877-14-000043:mdna:123]
|  |  | Three Months Ended |
|  |  | October 25, 2014 |  | October 26, 2013 |  | Variance in Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |
| Switching |  | $ | 3,846 |  |  | $ | 3,740 |  |  | $ | 106 |  |  | 2.8 | % |
| Percentage of product revenue |  | 40.8 | % |  | 39.8 | % |  |  |  |  |  |  |
| NGN Routing |  | 1,949 |  |  | 2,026 |  |  | (77 | ) |  | (3.8 | )% |
| Percentage of product revenue |  | 20.7 | % |  | 21.6 | % |  |  |  |  |  |  |
| Collaboration |  | 949 |  |  | 1,051 |  |  | (102 | ) |  | (9.7 | )% |
| Percentage of product revenue |  | 10.1 | % |  | 11.2 | % |  |  |  |  |  |  |
| Service Provider Video |  | 871 |  |  | 987 |  |  | (116 | ) |  | (11.8 | )% |
| Percentage of product revenue |  | 9.2 | % |  | 10.5 | % |  |  |  |  |  |  |
| Data Center |  | 693 |  |  | 601 |  |  | 92 |  |  | 15.3 | % |
| Percentage of product revenue |  | 7.3 | % |  | 6.4 | % |  |  |  |  |
| Wireless |  | 605 |  |  | 547 |  |  | 58 |  |  | 10.6 | % |
| Percentage of product revenue |  | 6.4 | % |  | 5.8 | % |  |  |  |  |  |  |
| Security |  | 455 |  |  | 365 |  |  | 90 |  |  | 24.7 | % |
| Percentage of product revenue |  | 4.8 | % |  | 3.9 | % |  |  |  |  |  |  |
| Other |  | 67 |  |  | 80 |  |  | (13 | ) |  | (16.3 | )% |
| Percentage of product revenue |  | 0.7 | % |  | 0.8 | % |  |  |  |  |  |  |
| Total |  | $ | 9,435 |  |  | $ | 9,397 |  |  | $ | 38 |  |  | 0.4 | % |

[0000858877-14-000043:mdna:124]
Certain reclassifications have been made to the prior period amounts to conform to the current period’s presentation.

[0000858877-14-000043:mdna:125]
Three Months Ended October 25, 2014 Compared with Three Months Ended October 26, 2013

[0000858877-14-000043:mdna:126]
[same as prior period, unchanged from 0000858877-14-000014:mdna:149]

[0000858877-14-000043:mdna:127]
Revenue in our Switching product category increased by 3%, or $106 million, driven by a 7%, or $170 million, increase in revenue from our LAN fixed-configuration switches. Revenue from our LAN fixed-configuration switches increased due to the continued adoption of Cisco Catalyst 3650 Series Switches and Cisco Catalyst 3850 Series Switches. Higher revenue from fixed-configuration Cisco Nexus Series Switches also contributed to the increase. We also experienced a 63%, or $60 million, increase in sales of storage products within this category. Partially offsetting these increases was a decrease in revenue from our modular switches of 9%, or $124 million, due primarily to lower sales of Cisco Catalyst 6500-E Series Switches.

[0000858877-14-000043:mdna:128]
[same as prior period, unchanged from 0000858877-14-000014:mdna:156]

[0000858877-14-000043:mdna:129]
The decrease in revenue in our NGN Routing product category of 4%, or $77 million, was driven by a 39%, or $70 million, decrease in revenue from what we categorize as other NGN Routing products and a 7%, or $49 million, decrease in revenue from our midrange and low-end router products. These decreases were partially offset by a 4%, or $42 million, increase in revenue from our high-end products.  Revenue from other NGN Routing products decreased due to lower sales of certain optical networking products. The decrease in revenue from our midrange and low-end router products was due to lower sales of our Cisco Integrated Services Routers products. Within the high-end router product category, we experienced increased sales of mobility products within our Cisco Aggregation Services Routers category and the adoption of our Cisco Network Convergence System platform partially offset by lower sales of Cisco Carrier Routing System products and our legacy high-end router products.

[0000858877-14-000043:mdna:130]
[same as prior period, unchanged from 0000858877-14-000014:mdna:132]

[0000858877-14-000043:mdna:131]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-14-000043:mdna:132]
[same as prior period, unchanged from 0000858877-14-000014:mdna:167]

[0000858877-14-000043:mdna:133]
Overall, revenue in our Collaboration product category decreased by 10%, or $102 million, primarily due to decreased revenue from our Cisco TelePresence and Unified Communications products, driven by lower revenue in endpoint products such as phones. These decreases were partially offset by higher revenue from our conferencing products. We continue to increase the amount of deferred revenue related to our Collaboration product category.

[0000858877-14-000043:mdna:134]
[same as prior period, unchanged from 0000858877-14-000014:mdna:162]

[0000858877-14-000043:mdna:135]
Revenue in our Service Provider Video product category decreased by 12%, or $116 million,  driven by a decrease in sales of our Service Provider Video infrastructure products. The revenue decline in Service Provider Video infrastructure products was due to a decrease in revenue from connected devices and cable access products. The decrease in revenue from connected devices products was due primarily to lower sales of set-top boxes.

[0000858877-14-000043:mdna:136]
[same as prior period, unchanged from 0000858877-14-000014:mdna:175]

[0000858877-14-000043:mdna:137]
We continue to experience solid growth in our Data Center product category, which grew by 15%, or $92 million, with sales growth of our Cisco Unified Computing System products occurring across most geographic segments and customer markets. The increase was due in large part to the continued momentum we are experiencing in both data center and cloud environments, as current customers increase their data center build-outs and as new customers deploy these offerings.

[0000858877-14-000043:mdna:138]
[same as prior period, unchanged from 0000858877-14-000014:mdna:181]

[0000858877-14-000043:mdna:139]
Revenue in our Wireless product category increased by 11%, or $58 million, driven by continued growth in our 802.11ac portfolio and an increase in sales of Meraki products. We continue to increase the proportion of recurring revenue in our Wireless product category.

[0000858877-14-000043:mdna:140]
[same as prior period, unchanged from 0000858877-14-000014:mdna:186]

[0000858877-14-000043:mdna:141]
Revenue in our Security product category experienced growth of 25%, or $90 million, driven by higher network security sales as we combined products from Sourcefire, which we acquired in the first quarter of fiscal 2014, more closely with our other products. We continue to increase the proportion of recurring revenue in our Security product category.

[0000858877-14-000043:mdna:142]
Other Products

[0000858877-14-000043:mdna:143]
We experienced a year-over-year decrease in revenue in our Other Products category, due in large part to the decrease in sales of our other networking products.

[0000858877-14-000043:mdna:144]
[same as prior period, unchanged from 0000858877-14-000014:mdna:142]

[0000858877-14-000043:mdna:145]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-14-000043:mdna:146]
[same as prior period, unchanged from 0000858877-14-000014:mdna:195]

[0000858877-14-000043:mdna:147]
[same as prior period, unchanged from 0000858877-14-000014:mdna:196]

[0000858877-14-000043:mdna:148]
|  | Three Months Ended |
|  | October 25, 2014 |  | October 26, 2013 |  | Variance in Dollars |  | Variance in Percent |
| Service revenue: |  |  |  |  |  |  |  |
| Americas | $ | 1,817 |  |  | $ | 1,783 |  |  | $ | 34 |  |  | 1.9 | % |
| Percentage of service revenue | 64.6 | % |  | 66.4 | % |  |  |  |  |
| EMEA | 606 |  |  | 552 |  |  | 54 |  |  | 9.8 | % |
| Percentage of service revenue | 21.6 | % |  | 20.5 | % |  |  |  |  |
| APJC | 387 |  |  | 353 |  |  | 34 |  |  | 9.6 | % |
| Percentage of service revenue | 13.8 | % |  | 13.1 | % |  |  |  |  |
| Total | $ | 2,810 |  |  | $ | 2,688 |  |  | $ | 122 |  |  | 4.5 | % |

[0000858877-14-000043:mdna:149]
Three Months Ended October 25, 2014 Compared with Three Months Ended October 26, 2013

[0000858877-14-000043:mdna:150]
Service revenue experienced growth across all of our geographic segments. Worldwide technical support services revenue increased by 5% while worldwide advanced services revenue increased by 3% driven by growth in subscription revenues. Technical support service revenue experienced growth across all geographic segments, led by solid growth in our APJC segment. Renewals and technical support service contract initiations associated with product sales provided an installed base of equipment being serviced which, in concert with new service offerings, were the primary factors driving the revenue increases. Advanced services revenue, which relates to consulting support services for specific customer network needs, experienced strong growth in our EMEA segment, increased slightly in our APJC segment, and decreased slightly in our Americas segment.

[0000858877-14-000043:mdna:151]
[same as prior period, unchanged from 0000858877-14-000014:mdna:103]

[0000858877-14-000043:mdna:152]
[same as prior period, unchanged from 0000858877-14-000014:mdna:152]

[0000858877-14-000043:mdna:153]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-14-000043:mdna:154]
[same as prior period, unchanged from 0000858877-14-000014:mdna:206]

[0000858877-14-000043:mdna:155]
[same as prior period, unchanged from 0000858877-14-000014:mdna:207]

[0000858877-14-000043:mdna:156]
|  | Three Months Ended |
|  | AMOUNT |  | PERCENTAGE |
|  | October 25, 2014 |  | October 26, 2013 |  | October 25, 2014 |  | October 26, 2013 |
| Gross margin: |  |  |  |  |  |  |  |
| Product | $ | 5,516 |  |  | $ | 5,650 |  |  | 58.5 | % |  | 60.1 | % |
| Service | 1,817 |  |  | 1,757 |  |  | 64.7 | % |  | 65.4 | % |
| Total | $ | 7,333 |  |  | $ | 7,407 |  |  | 59.9 | % |  | 61.3 | % |

[0000858877-14-000043:mdna:157]
[same as prior period, unchanged from 0000858877-14-000014:mdna:209]

[0000858877-14-000043:mdna:158]
The following table summarizes the key factors that contributed to the change in product gross margin percentage for the first quarter of fiscal 2015 as compared with the corresponding prior year period:

[0000858877-14-000043:mdna:159]
|  |  | Product Gross Margin Percentage |
| First Quarter of Fiscal 2014 |  | 60.1 | % |
| Product pricing |  | (2.5 | )% |
| Rockstar patent portfolio charge |  | (2.0 | )% |
| Amortization of purchased intangible assets |  | (0.1 | )% |
| Mix of products sold |  | 0.9 | % |
| Productivity (1) |  | 2.1 | % |
| First Quarter of Fiscal 2015 |  | 58.5 | % |

[0000858877-14-000043:mdna:160]
[same as prior period, unchanged from 0000858877-14-000014:mdna:212]

[0000858877-14-000043:mdna:161]
Three Months Ended October 25, 2014 Compared with Three Months Ended October 26, 2013

[0000858877-14-000043:mdna:162]
Product gross margin decreased by 1.6 percentage points compared with the first quarter of fiscal 2014.

[0000858877-14-000043:mdna:163]
The decrease in product gross margin was driven by unfavorable impacts from product pricing, which were driven by typical market factors and impacted each of our geographic segments and customer markets. The decrease was also due to a charge of $188 million to product cost of sales recorded in the first quarter fiscal 2015 related to the Rockstar patent portfolio.  Our product gross margin for the first quarter of fiscal 2015 was also negatively impacted by higher amortization expense from purchased intangible assets.

[0000858877-14-000043:mdna:164]
These amounts were partially offset by benefits from productivity and the mix of products sold. The productivity benefits we experienced in the first quarter of fiscal 2015 were driven by value engineering efforts; favorable component pricing; continued operational efficiency in manufacturing operations; and lower warranty expense. Value engineering is the process by which production costs are reduced through component redesign, board configuration, test processes, and transformation processes. The shift in the mix of products sold increased our product gross margin, primarily as a result of a revenue increase from certain of our higher margin core products and decreased revenue from our relatively lower margin Service Provider Video products, partially offset by a revenue increase in our relatively lower margin Cisco Unified Computing System products.

[0000858877-14-000043:mdna:165]
Our future gross margins could be impacted by our product mix and could be adversely affected by further growth in sales of products that have lower gross margins, such as Cisco Unified Computing System products. Our gross margins may also be impacted by the geographic mix of our revenue and may be adversely affected by product pricing attributable to competitive factors. Additionally, our manufacturing-related costs may be negatively impacted by constraints in our supply chain, which in turn could negatively affect gross margin. If any of the preceding factors that in the past have negatively impacted our gross margins arise in future periods, our gross margins could continue to decline.

[0000858877-14-000043:mdna:166]
[same as prior period, unchanged from 0000858877-14-000014:mdna:173]

[0000858877-14-000043:mdna:167]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-14-000043:mdna:168]
[same as prior period, unchanged from 0000858877-14-000014:mdna:221]

[0000858877-14-000043:mdna:169]
Three Months Ended October 25, 2014 Compared with Three Months Ended October 26, 2013

[0000858877-14-000043:mdna:170]
Our service gross margin percentage decreased by 0.7 percentage points for the first quarter of fiscal 2015, as compared with the first quarter of fiscal 2014, driven by increased cost impacts such as partner delivery costs and headcount-related costs. These cost impacts were partially offset by the resulting benefit to gross margin of higher sales volume in both advanced services and technical support services.

[0000858877-14-000043:mdna:171]
[same as prior period, unchanged from 0000858877-14-000014:mdna:224]

[0000858877-14-000043:mdna:172]
[same as prior period, unchanged from 0000858877-14-000014:mdna:229]

[0000858877-14-000043:mdna:173]
[same as prior period, unchanged from 0000858877-14-000014:mdna:230]

[0000858877-14-000043:mdna:174]
|  |  | Three Months Ended |
|  |  | AMOUNT |  | PERCENTAGE |
|  |  | October 25, 2014 |  | October 26, 2013 |  | October 25, 2014 |  | October 26, 2013 |
| Gross margin: |  |  |  |  |  |  |  |  |
| Americas |  | $ | 4,810 |  |  | $ | 4,650 |  |  | 64.1 | % |  | 63.6 | % |
| EMEA |  | 1,915 |  |  | 1,888 |  |  | 63.8 | % |  | 64.4 | % |
| APJC |  | 1,025 |  |  | 1,079 |  |  | 58.8 | % |  | 58.8 | % |
| Segment total |  | 7,750 |  |  | 7,617 |  |  | 63.3 | % |  | 63.0 | % |
| Unallocated corporate items (1) |  | (417 | ) |  | (210 | ) |  |  |  |  |
| Total |  | $ | 7,333 |  |  | $ | 7,407 |  |  | 59.9 | % |  | 61.3 | % |

[0000858877-14-000043:mdna:175]
(1) The unallocated corporate items for the periods presented include the effects of amortization and impairments of acquisition-related intangible assets, share-based compensation expense, significant litigation and other contingencies, and certain other charges. We do not allocate these items to the gross margin for each segment because management does not include such information in measuring the performance of the operating segments.

[0000858877-14-000043:mdna:176]
Three Months Ended October 25, 2014 Compared with Three Months Ended October 26, 2013

[0000858877-14-000043:mdna:177]
The Americas segment experienced a gross margin percentage increase due to productivity improvements from lower overall manufacturing costs and, to a lesser extent, a favorable mix impact. The favorable mix impact in this geographic segment was driven by lower sales of our relatively lower margin Service Provider Video products and an increase in revenue from certain of our higher margin core products, partially offset by an increase in revenue from our relatively lower margin Cisco Unified Computing System products. Partially offsetting these favorable impacts to gross margin were negative impacts from pricing.

[0000858877-14-000043:mdna:178]
The gross margin percentage decrease in our EMEA segment was due primarily to the unfavorable impacts from pricing, as well as an unfavorable mix impact, partially offset by productivity improvements in this geographic segment. The unfavorable mix impact was driven by an increase in revenue from our lower margin Cisco Unified Computing System products.

[0000858877-14-000043:mdna:179]
Our APJC segment gross margin percentage was unchanged, as a favorable impact of mix and productivity improvements offset the unfavorable impacts from pricing. The favorable mix impact was driven by an increase in revenue from certain of our higher margin core products and a decrease in revenue from our relatively lower margin Service Provider Video products.

[0000858877-14-000043:mdna:180]
The gross margin percentage for a particular segment may fluctuate, and period-to-period changes in such percentages may or may not be indicative of a trend for that segment. Our product and service gross margins may be impacted by economic downturns or uncertain economic conditions as well as our movement into new market opportunities, and could decline if any of the factors that impact our gross margins are adversely affected in future periods.

[0000858877-14-000043:mdna:181]
54

[0000858877-14-000043:mdna:182]
[same as prior period, unchanged from 0000858877-14-000014:mdna:193]

[0000858877-14-000043:mdna:183]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-14-000043:mdna:184]
[same as prior period, unchanged from 0000858877-14-000014:mdna:244]

[0000858877-14-000043:mdna:185]
[same as prior period, unchanged from 0000858877-14-000014:mdna:245]

[0000858877-14-000043:mdna:186]
[same as prior period, unchanged from 0000858877-14-000014:mdna:246]

[0000858877-14-000043:mdna:187]
[same as prior period, unchanged from 0000858877-14-000014:mdna:247]

[0000858877-14-000043:mdna:188]
Product gross margin may be adversely affected in the future by changes in the mix of products sold, including periods of increased growth of some of our lower margin products; introduction of new products, including products with price-performance advantages and new business models for our offerings such as other-as-a-service (“XaaS”); our ability to reduce production costs; entry into new markets, including markets with different pricing structures and cost structures, as a result of internal development or through acquisitions; changes in distribution channels; price competition, including competitors from Asia, especially those from China; changes in geographic mix of our product revenue; the timing of revenue recognition and revenue deferrals; sales discounts; increases in material or labor costs, including share-based compensation expense; excess inventory and obsolescence charges; warranty costs; changes in shipment volume; loss of cost savings due to changes in component pricing; effects of value engineering; inventory holding charges; and the extent to which we successfully execute on our strategy and operating plans. Additionally, our manufacturing-related costs may be negatively impacted by constraints in our supply chain. Service gross margin may be impacted by various factors such as the change in mix between technical support services and advanced services; the timing of technical support service contract initiations and renewals; share-based compensation expense; and the timing of our strategic investments in headcount and resources to support this business.

[0000858877-14-000043:mdna:189]
[same as prior period, unchanged from 0000858877-14-000014:mdna:204]

[0000858877-14-000043:mdna:190]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-14-000043:mdna:191]
[same as prior period, unchanged from 0000858877-14-000014:mdna:252]

[0000858877-14-000043:mdna:192]
[same as prior period, unchanged from 0000858877-14-000014:mdna:253]

[0000858877-14-000043:mdna:193]
|  |  | Three Months Ended |
|  |  | October 25, 2014 |  | October 26, 2013 |  | Variance in Dollars |  | Variance in Percent |
| Research and development |  | $ | 1,583 |  |  | $ | 1,724 |  |  | $ | (141 | ) |  | (8.2 | )% |
| Percentage of revenue |  | 12.9 | % |  | 14.3 | % |  |  |  |  |
| Sales and marketing |  | 2,515 |  |  | 2,411 |  |  | 104 |  |  | 4.3 | % |
| Percentage of revenue |  | 20.5 | % |  | 20.0 | % |  |  |  |  |
| General and administrative |  | 504 |  |  | 515 |  |  | (11 | ) |  | (2.1 | )% |
| Percentage of revenue |  | 4.1 | % |  | 4.3 | % |  |  |  |  |
| Total |  | $ | 4,602 |  |  | $ | 4,650 |  |  | $ | (48 | ) |  | (1.0 | )% |
| Percentage of revenue |  | 37.6 | % |  | 38.5 | % |  |  |  |  |

[0000858877-14-000043:mdna:194]
[same as prior period, unchanged from 0000858877-14-000014:mdna:255]

[0000858877-14-000043:mdna:195]
R&D expenses decreased for the first quarter of fiscal 2015, as compared with the corresponding period in fiscal 2014, primarily due to compensation expense recorded in the first quarter of fiscal 2014 in connection with our acquisition of the remaining interest in Insieme. See Note 12 to the Consolidated Financial Statements. Efficiencies related to our restructuring actions also contributed to the decrease.

[0000858877-14-000043:mdna:196]
[same as prior period, unchanged from 0000858877-14-000014:mdna:257]

[0000858877-14-000043:mdna:197]
[same as prior period, unchanged from 0000858877-14-000014:mdna:258]

[0000858877-14-000043:mdna:198]
Sales and marketing expenses increased for the first quarter of fiscal 2015, as compared with the corresponding period in fiscal 2014, due to higher discretionary spending, higher headcount-related expenses and higher share-based compensation expense.

[0000858877-14-000043:mdna:199]
[same as prior period, unchanged from 0000858877-14-000014:mdna:260]

[0000858877-14-000043:mdna:200]
G&A expenses decreased in the first quarter of fiscal 2015, as compared with the corresponding period in fiscal 2014, primarily due to compensation expense recorded in the first quarter of fiscal 2014 in connection with our acquisition of the remaining interest in Insieme and due to lower discretionary spending and lower contracted services in the first quarter of fiscal 2015. Lower headcount-related expenses also contributed to the decrease in G&A expenses. The lower headcount-related expenses were due to efficiencies related to our restructuring actions.

[0000858877-14-000043:mdna:201]
[same as prior period, unchanged from 0000858877-14-000014:mdna:262]

[0000858877-14-000043:mdna:202]
In the first quarter of fiscal 2015, foreign currency fluctuations, net of hedging, increased the combined R&D, sales and marketing, and G&A expenses by $4 million, or approximately 0.1%, compared with the first quarter of fiscal 2014.  In the first quarter of fiscal 2014, foreign currency fluctuations, net of hedging, decreased the combined R&D, sales and marketing, and G&A expenses by $44 million, or approximately 1.0%, compared with the first quarter of fiscal 2013.

[0000858877-14-000043:mdna:203]
[same as prior period, unchanged from 0000858877-14-000014:mdna:265]

[0000858877-14-000043:mdna:204]
Our headcount decreased by approximately 1,800 employees in the first quarter of fiscal 2015 as compared with the total headcount at the end of fiscal 2014.  The decrease was due to headcount reductions from our workforce reduction under the Fiscal 2015 Plan. These headcount reductions were partially offset by headcount additions from targeted hiring in engineering, services and sales, and also by headcount additions from our recent acquisitions.

[0000858877-14-000043:mdna:205]
56

[0000858877-14-000043:mdna:206]
[same as prior period, unchanged from 0000858877-14-000014:mdna:217]

[0000858877-14-000043:mdna:207]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-14-000043:mdna:208]
[same as prior period, unchanged from 0000858877-14-000014:mdna:72]

[0000858877-14-000043:mdna:209]
[same as prior period, unchanged from 0000858877-14-000014:mdna:270]

[0000858877-14-000043:mdna:210]
|  |  | Three Months Ended |
|  |  | October 25, 2014 |  | October 26, 2013 |
| Cost of sales—product |  | $ | 11 |  |  | $ | 10 |  |
| Cost of sales—service |  | 37 |  |  | 33 |  |
| Share-based compensation expense in cost of sales |  | 48 |  |  | 43 |  |
| Research and development |  | 119 |  |  | 92 |  |
| Sales and marketing |  | 147 |  |  | 123 |  |
| General and administrative |  | 59 |  |  | 54 |  |
| Restructuring and other charges |  | (4 | ) |  | (3 | ) |
| Share-based compensation expense in operating expenses |  | 321 |  |  | 266 |  |
| Total share-based compensation expense |  | $ | 369 |  |  | $ | 309 |  |

[0000858877-14-000043:mdna:211]
The increase in share-based compensation expense for the first quarter of fiscal 2015, as compared with the first quarter of fiscal 2014, was due primarily to share-based compensation expense attributable to equity awards assumed with respect to our acquisitions and higher expense associated with the ESPP and PRSUs.

[0000858877-14-000043:mdna:212]
[same as prior period, unchanged from 0000858877-14-000014:mdna:273]

[0000858877-14-000043:mdna:213]
The following table presents the amortization of purchased intangible assets (in millions):

[0000858877-14-000043:mdna:214]
|  |  | Three Months Ended |
|  |  | October 25, 2014 |  | October 26, 2013 |
| Amortization of purchased intangible assets: |  |  |  |  |
| Cost of sales |  | $ | 189 |  |  | $ | 174 |  |
| Operating expenses |  | 71 |  |  | 65 |  |
| Total |  | $ | 260 |  |  | $ | 239 |  |

[0000858877-14-000043:mdna:215]
Amortization of purchased intangible assets increased for the first quarter of fiscal 2015, as compared with the first quarter of fiscal 2014, due to amortization of purchased intangible assets from our recent acquisitions partially offset by certain purchased intangible assets having become fully amortized.

[0000858877-14-000043:mdna:216]
[same as prior period, unchanged from 0000858877-14-000014:mdna:277]

[0000858877-14-000043:mdna:217]
[same as prior period, unchanged from 0000858877-14-000014:mdna:278]

[0000858877-14-000043:mdna:218]
In the first quarter of fiscal 2015, we incurred within operating expenses restructuring and other charges of approximately $318 million which were related primarily to employee severance charges for employees impacted by our workforce reduction under the Fiscal 2015 Plan.  We expect the remaining charges under this plan to be incurred within the remainder of fiscal 2015. We plan to reinvest substantially all of the cost savings from the restructuring actions in key growth areas of our business such as data center, software, security, and cloud.

[0000858877-14-000043:mdna:219]
In the first quarter of fiscal 2014, we incurred within operating expenses net restructuring and other charges of $237 million, which were related primarily to employee severance charges for employees impacted by our workforce reduction under the Fiscal 2014 Plan. See Note 5 to the Consolidated Financial Statements.

[0000858877-14-000043:mdna:220]
[same as prior period, unchanged from 0000858877-14-000014:mdna:227]

[0000858877-14-000043:mdna:221]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-14-000043:mdna:222]
[same as prior period, unchanged from 0000858877-14-000014:mdna:283]

[0000858877-14-000043:mdna:223]
[same as prior period, unchanged from 0000858877-14-000014:mdna:284]

[0000858877-14-000043:mdna:224]
|  |  | Three Months Ended |
|  |  | October 25, 2014 |  | October 26, 2013 |
| Operating income |  | $ | 2,342 |  |  | $ | 2,455 |  |
| Operating income as a percentage of revenue |  | 19.1 | % |  | 20.3 | % |

[0000858877-14-000043:mdna:225]
For the first quarter of fiscal 2015, as compared with the first quarter of fiscal 2014, operating income decreased by 5%, and as a percentage of revenue operating income decreased by 1.2 percentage points. The decrease resulted from a gross margin percentage decline, driven in part by the Rockstar patent portfolio charge of $188 million (or 1.5 percentage points) and an increase in restructuring and other charges related to the workforce reduction under the Fiscal 2015 Plan.

[0000858877-14-000043:mdna:226]
[same as prior period, unchanged from 0000858877-14-000014:mdna:288]

[0000858877-14-000043:mdna:227]
Interest Income (Expense), Net   The following table summarizes interest income and interest expense (in millions):

[0000858877-14-000043:mdna:228]
|  | Three Months Ended |
|  | October 25, 2014 |  | October 26, 2013 |  | Variance |
| Interest income | $ | 179 |  |  | $ | 169 |  |  | $ | 10 |  |
| Interest expense | (139 | ) |  | (140 | ) |  | 1 |  |
| Interest income (expense), net | $ | 40 |  |  | $ | 29 |  |  | $ | 11 |  |

[0000858877-14-000043:mdna:229]
Interest income increased in the first quarter of fiscal 2015, as compared with the first quarter of fiscal 2014, primarily due to the increase in our portfolio of cash, cash equivalents, and fixed income investments. Interest expense in the first quarter of fiscal 2015, as compared with the first quarter of fiscal 2014, was relatively flat.

[0000858877-14-000043:mdna:230]
Other Income (Loss), Net   The components of other income (loss), net, are summarized as follows (in millions):

[0000858877-14-000043:mdna:231]
|  | Three Months Ended |
|  | October 25, 2014 |  | October 26, 2013 |  | Variance |
| Gains (losses) on investments, net: |  |  |  |  |  |
| Publicly traded equity securities | $ | (4 | ) |  | $ | 75 |  |  | $ | (79 | ) |
| Fixed income securities | 11 |  |  | 8 |  |  | 3 |  |
| Total available-for-sale investments | 7 |  |  | 83 |  |  | (76 | ) |
| Privately held companies | (33 | ) |  | (31 | ) |  | (2 | ) |
| Net gains (losses) on investments | (26 | ) |  | 52 |  |  | (78 | ) |
| Other gains (losses), net | 4 |  |  | 4 |  |  | — |  |
| Other income (loss), net | $ | (22 | ) |  | $ | 56 |  |  | $ | (78 | ) |

[0000858877-14-000043:mdna:232]
The decrease in total net gains on available-for-sale investments in the first quarter of fiscal 2015, compared with the first quarter of fiscal 2014, was primarily attributable to losses on publicly traded equity securities in the current period as a result of market conditions and the timing of sales of these securities.

[0000858877-14-000043:mdna:233]
The change in net losses on investments in privately held companies for the first quarter of fiscal 2015, as compared with the first quarter of fiscal 2014, was primarily due to higher net losses recognized from our equity method investments, partially offset by higher realized gains from various investments in privately held companies.

[0000858877-14-000043:mdna:234]
Other gains (losses), net was flat in the first quarter of fiscal 2015 as compared with the first quarter of fiscal 2014, as favorable foreign exchange impacts were offset by unfavorable impacts from equity derivatives.

[0000858877-14-000043:mdna:235]
58

[0000858877-14-000043:mdna:236]
[same as prior period, unchanged from 0000858877-14-000014:mdna:242]

[0000858877-14-000043:mdna:237]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-14-000043:mdna:238]
[same as prior period, unchanged from 0000858877-14-000014:mdna:299]

[0000858877-14-000043:mdna:239]
Our provision for income taxes is subject to volatility and could be adversely impacted by earnings being lower than anticipated in countries that have lower tax rates, higher than anticipated in countries that have higher tax rates, and expiration of or lapses in tax incentives. Our provision for income taxes does not include provisions for U.S. income taxes and foreign withholding taxes associated with the repatriation of undistributed earnings of certain foreign subsidiaries that we intend to reinvest indefinitely in our foreign subsidiaries. If these earnings were distributed from the foreign subsidiaries to the United States in the form of dividends or otherwise, or if the shares of the relevant foreign subsidiaries were sold or otherwise transferred, we would be subject to additional U.S. income taxes (subject to an adjustment for foreign tax credits) and foreign withholding taxes. Further, as a result of certain of our ongoing employment and capital investment actions and commitments, our income in certain countries is subject to reduced tax rates and in some cases is wholly exempt from tax. Our failure to meet these commitments could adversely impact our provision for income taxes.  The provision for income taxes resulted in an effective tax rate of 22.5% for the first quarter of fiscal 2015, compared with 21.4% for the first quarter of fiscal 2014. The net 1.1 percentage point increase in the effective tax rate for the first quarter of fiscal 2015 was primarily due to expiration of the U.S. federal R&D tax credit and a decrease in foreign income taxed at other than U.S. tax rates.

[0000858877-14-000043:mdna:240]
[same as prior period, unchanged from 0000858877-14-000014:mdna:203]

[0000858877-14-000043:mdna:241]
[same as prior period, unchanged from 0000858877-14-000014:mdna:250]

[0000858877-14-000043:mdna:242]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-14-000043:mdna:243]
[same as prior period, unchanged from 0000858877-14-000014:mdna:305]

[0000858877-14-000043:mdna:244]
[same as prior period, unchanged from 0000858877-14-000014:mdna:306]

[0000858877-14-000043:mdna:245]
[same as prior period, unchanged from 0000858877-14-000014:mdna:307]

[0000858877-14-000043:mdna:246]
Cash and Cash Equivalents and Investments  The following table summarizes our cash and cash equivalents and investments (in millions):

[0000858877-14-000043:mdna:247]
|  | October 25, 2014 |  | July 26, 2014 |  | Increase (Decrease) |
| Cash and cash equivalents | $ | 4,387 |  |  | $ | 6,726 |  |  | $ | (2,339 | ) |
| Fixed income securities | 45,923 |  |  | 43,396 |  |  | 2,527 |  |
| Publicly traded equity securities | 1,797 |  |  | 1,952 |  |  | (155 | ) |
| Total | $ | 52,107 |  |  | $ | 52,074 |  |  | $ | 33 |  |

[0000858877-14-000043:mdna:248]
The slight net increase in cash and cash equivalents and investments in the first quarter of fiscal 2015 was primarily the result of cash provided by operating activities of $2.5 billion and proceeds from the issuance of common stock of $0.4 billion pursuant to employee stock incentive plans. These sources of cash were substantially offset by the repurchase of common stock of $1.1 billion under the stock repurchase program, cash dividends paid of $1.0 billion, capital expenditures of $0.3 billion, and net cash paid for acquisitions of $0.2 billion.

[0000858877-14-000043:mdna:249]
Our total in cash and cash equivalents and investments held by various foreign subsidiaries was $48.3 billion and $47.4 billion as of October 25, 2014 and July 26, 2014, respectively. Under current tax laws and regulations, if these assets were to be distributed from the foreign subsidiaries to the United States in the form of dividends or otherwise, we would be subject to additional U.S. income taxes (subject to an adjustment for foreign tax credits) and foreign withholding taxes. The balance of cash and cash equivalents and investments available in the United States as of October 25, 2014 and July 26, 2014 was $3.8 billion and $4.7 billion, respectively.

[0000858877-14-000043:mdna:250]
We maintain an investment portfolio of various holdings, types, and maturities. We classify our investments as short-term investments based on their nature and their availability for use in current operations. We believe the overall credit quality of our portfolio is strong, with our cash equivalents and our fixed income investment portfolio consisting primarily of high quality investment-grade securities. We believe that our strong cash and cash equivalents and investments position allows us to use our cash resources for strategic investments to gain access to new technologies, for acquisitions, for customer financing activities, for working capital needs, and for the repurchase of shares of common stock and payment of dividends as discussed below.

[0000858877-14-000043:mdna:251]
Free Cash Flow and Capital Allocation   As part of our capital allocation strategy, we intend to return a minimum of 50% of our free cash flow annually to our shareholders through cash dividends and repurchases of common stock.

[0000858877-14-000043:mdna:252]
[same as prior period, unchanged from 0000858877-14-000014:mdna:314]

[0000858877-14-000043:mdna:253]
|  | Three Months Ended |
|  | October 25, 2014 |  | October 26, 2013 |
| Net cash provided by operating activities | $ | 2,491 |  |  | $ | 2,649 |  |
| Acquisition of property and equipment | (285 | ) |  | (315 | ) |
| Free cash flow | $ | 2,206 |  |  | $ | 2,334 |  |

[0000858877-14-000043:mdna:254]
[same as prior period, unchanged from 0000858877-14-000014:mdna:316]

[0000858877-14-000043:mdna:255]
We consider free cash flow to be a liquidity measure that provides useful information to management and investors because of our intent to return a stated percentage of free cash flow to shareholders in the form of dividends and stock repurchases.  We further regard free cash flow as a useful measure because it reflects cash that can be used to, among other things, invest in our business,

[0000858877-14-000043:mdna:256]
[same as prior period, unchanged from 0000858877-14-000014:mdna:267]

[0000858877-14-000043:mdna:257]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-14-000043:mdna:258]
make strategic acquisitions, repurchase common stock, and pay dividends on our common stock, after deducting capital investments. A limitation of the utility of free cash flow as a measure of financial performance and liquidity is that the free cash flow does not represent the total increase or decrease in our cash balance for the period.  In addition, we have other required uses of cash, including repaying the principal of our outstanding indebtedness.  Free cash flow is not a measure calculated in accordance with U.S. generally accepted accounting principles and should not be regarded in isolation or as an alternative for net income provided by operating activities or any other measure calculated in accordance with such principles, and other companies may calculate free cash flow in a different manner than we do.

[0000858877-14-000043:mdna:259]
[same as prior period, unchanged from 0000858877-14-000014:mdna:321]

[0000858877-14-000043:mdna:260]
|  |  | DIVIDENDS |  | STOCK REPURCHASE PROGRAM |  |  |
| Quarter Ended |  | Per Share |  | Amount |  | Shares |  | Weighted-Average Price per Share |  | Amount |  | TOTAL |
| Fiscal 2015 |  |  |  |  |  |  |  |  |  |  |  |  |
| October 25, 2014 |  | $ | 0.19 |  |  | $ | 973 |  |  | 41 |  |  | $ | 24.58 |  |  | $ | 1,013 |  |  | $ | 1,986 |  |
| Fiscal 2014 |  |  |  |  |  |  |  |  |  |  |  |  |
| July 26, 2014 |  | $ | 0.19 |  |  | $ | 974 |  |  | 61 |  |  | $ | 25.11 |  |  | $ | 1,514 |  |  | $ | 2,488 |  |
| April 26, 2014 |  | $ | 0.19 |  |  | $ | 974 |  |  | 90 |  |  | $ | 22.24 |  |  | $ | 2,005 |  |  | $ | 2,979 |  |
| January 25, 2014 |  | $ | 0.17 |  |  | $ | 896 |  |  | 185 |  |  | $ | 21.73 |  |  | $ | 4,020 |  |  | $ | 4,916 |  |
| October 26, 2013 |  | $ | 0.17 |  |  | $ | 914 |  |  | 84 |  |  | $ | 23.65 |  |  | $ | 2,000 |  |  | $ | 2,914 |  |

[0000858877-14-000043:mdna:261]
[same as prior period, unchanged from 0000858877-14-000014:mdna:323]

[0000858877-14-000043:mdna:262]
Accounts Receivable, Net The following table summarizes our accounts receivable, net (in millions), and DSO:

[0000858877-14-000043:mdna:263]
|  | October 25, 2014 |  | July 26, 2014 |  | Increase (Decrease) |
| Accounts receivable, net | $ | 4,375 |  |  | $ | 5,157 |  |  | $ | (782 | ) |
| DSO | 33 |  |  | 38 |  |  | (5 | ) |

[0000858877-14-000043:mdna:264]
Our accounts receivable net, as of October 25, 2014 decreased by approximately 15% compared with the end of fiscal 2014. Our DSO as of October 25, 2014 was lower by 5 days compared with the end of fiscal 2014, primarily due to service and product  billings being more linear in the first quarter of fiscal 2015 compared with the fourth quarter of fiscal 2014.

[0000858877-14-000043:mdna:265]
Inventory Supply Chain  The following table summarizes our inventories and purchase commitments with contract manufacturers and suppliers (in millions, except annualized inventory turns):

[0000858877-14-000043:mdna:266]
|  | October 25, 2014 |  | July 26, 2014 |  | Increase (Decrease) |
| Inventories | $ | 1,676 |  |  | $ | 1,591 |  |  | $ | 85 |  |
| Annualized inventory turns | 12.0 |  |  | 12.7 |  |  | (0.7 | ) |
| Purchase commitments with contract manufacturers and suppliers | $ | 4,299 |  |  | $ | 4,169 |  |  | $ | 130 |  |

[0000858877-14-000043:mdna:267]
Inventory as of October 25, 2014 increased by 5% from our inventory balance at the end of fiscal 2014, and for the same period purchase commitments with contract manufacturers and suppliers increased by approximately 3%. On a combined basis, inventories and purchase commitments with contract manufacturers and suppliers increased by 4% compared with the end of fiscal 2014.  We believe our inventory and purchase commitments levels are in line with our current demand forecasts.

[0000858877-14-000043:mdna:268]
[same as prior period, unchanged from 0000858877-14-000014:mdna:333]

[0000858877-14-000043:mdna:269]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that allow them to procure inventory based upon criteria as defined by us or that establish the parameters defining our requirements and our commitment to securing manufacturing capacity. A significant portion of our reported purchase commitments arising from these agreements are firm,

[0000858877-14-000043:mdna:270]
61

[0000858877-14-000043:mdna:271]
[same as prior period, unchanged from 0000858877-14-000014:mdna:281]

[0000858877-14-000043:mdna:272]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-14-000043:mdna:273]
noncancelable, and unconditional commitments. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed. Our purchase commitments are for short-term product manufacturing requirements as well as for commitments to suppliers to secure manufacturing capacity.

[0000858877-14-000043:mdna:274]
[same as prior period, unchanged from 0000858877-14-000014:mdna:335]

[0000858877-14-000043:mdna:275]
[same as prior period, unchanged from 0000858877-14-000014:mdna:336]

[0000858877-14-000043:mdna:276]
Financing Receivables and Guarantees We measure our net balance sheet exposure position related to our financing receivables and financing guarantees by reducing the total of gross financing receivables and financing guarantees by the associated allowances for credit loss and deferred revenue. As of October 25, 2014, our net balance sheet exposure position related to financing receivables and financing guarantees was as follows (in millions):

[0000858877-14-000043:mdna:277]
|  | FINANCING RECEIVABLES |  | FINANCING GUARANTEES |  |  |
| October 25, 2014 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts and Other |  | Total |  | Channel Partner |  | End-User Customers |  | Total |  | TOTAL |
| Financing receivables less unearned income | $ | 3,509 |  |  | $ | 1,744 |  |  | $ | 3,071 |  |  | $ | 8,324 |  |  | $ | 285 |  |  | $ | 161 |  |  | $ | 446 |  |  | $ | 8,770 |  |
| Allowance for credit loss | (248 | ) |  | (84 | ) |  | (36 | ) |  | (368 | ) |  | — |  |  | — |  |  | — |  |  | (368 | ) |
| Deferred revenue | (10 | ) |  | (4 | ) |  | (1,672 | ) |  | (1,686 | ) |  | (126 | ) |  | (130 | ) |  | (256 | ) |  | (1,942 | ) |
| Net balance sheet exposure | $ | 3,251 |  |  | $ | 1,656 |  |  | $ | 1,363 |  |  | $ | 6,270 |  |  | $ | 159 |  |  | $ | 31 |  |  | $ | 190 |  |  | $ | 6,460 |  |

[0000858877-14-000043:mdna:278]
Financing Receivables  Financing receivables less unearned income decreased by 1% compared with the end of fiscal 2014. The change was primarily due to a 1% decrease in lease receivables and 4% decrease in financed service contracts and other, partially offset by a 4% increase in loan receivables. We provide financing to certain end-user customers and channel partners to enable sales of our products, services, and networking solutions. These financing arrangements include leases, financed service contracts, and loans. Arrangements related to leases are generally collateralized by a security interest in the underlying assets. Lease receivables include sales-type and direct-financing leases. We also provide certain qualified customers financing for long-term service contracts, which primarily relate to technical support services and advanced services. Our loan financing arrangements may include not only financing the acquisition of our products and services but also providing additional funds for other costs associated with network installation and integration of our products and services. We expect to continue to expand the use of our financing programs in the near term.

[0000858877-14-000043:mdna:279]
Financing Guarantees  In the normal course of business, third parties may provide financing arrangements to our customers and channel partners under financing programs. The financing arrangements to customers provided by third parties are related to leases and loans and typically have terms of up to three years. In some cases, we provide guarantees to third parties for these lease and loan arrangements. The financing arrangements to channel partners consist of revolving short-term financing provided by third parties, generally with payment terms ranging from 60 to 90 days. In certain instances, these financing arrangements result in a transfer of our receivables to the third party. The receivables are derecognized upon transfer, as these transfers qualify as true sales, and we receive payments for the receivables from the third party based on our standard payment terms. These financing arrangements facilitate the working capital requirements of the channel partners, and in some cases, we guarantee a portion of these arrangements. We could be called upon to make payments under these guarantees in the event of nonpayment by the channel partners or end-user customers. Historically, our payments under these arrangements have been immaterial. Where we provide a guarantee, we defer the revenue associated with the channel partner and end-user financing arrangement in accordance with revenue recognition policies, or we record a liability for the fair value of the guarantees. In either case, the deferred revenue is recognized as revenue when the guarantee is removed.

[0000858877-14-000043:mdna:280]
[same as prior period, unchanged from 0000858877-14-000014:mdna:344]

[0000858877-14-000043:mdna:281]
[same as prior period, unchanged from 0000858877-14-000014:mdna:294]

[0000858877-14-000043:mdna:282]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-14-000043:mdna:283]
[same as prior period, unchanged from 0000858877-14-000014:mdna:345]

[0000858877-14-000043:mdna:284]
Senior Notes  The following table summarizes the principal amount of our senior notes (in millions):

[0000858877-14-000043:mdna:285]
|  | Maturity Date |  | October 25, 2014 |  | July 26, 2014 |
| Senior notes: |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |
| Three-month LIBOR plus 0.05% | September 3, 2015 |  | $ | 850 |  |  | $ | 850 |  |
| Three-month LIBOR plus 0.28% | March 3, 2017 |  | 1,000 |  |  | 1,000 |  |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | 500 |  |  | 500 |  |
| Fixed-rate notes: |  |  |  |  |  |
| 2.90% | November 17, 2014 |  | 500 |  |  | 500 |  |
| 5.50% | February 22, 2016 |  | 3,000 |  |  | 3,000 |  |
| 1.10% | March 3, 2017 |  | 2,400 |  |  | 2,400 |  |
| 3.15% | March 14, 2017 |  | 750 |  |  | 750 |  |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 2,000 |  |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 1,750 |  |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 2,500 |  |
| 2.90% | March 4, 2021 |  | 500 |  |  | 500 |  |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1,000 |  |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 2,000 |  |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 2,000 |  |
| Total |  |  | $ | 20,750 |  |  | $ | 20,750 |  |

[0000858877-14-000043:mdna:286]
Interest is payable semiannually on each class of the senior fixed-rate notes, each of which is redeemable by us at any time, subject to a make-whole premium. Interest is payable quarterly on the floating-rate notes. We were in compliance with all debt covenants as of October 25, 2014.

[0000858877-14-000043:mdna:287]
On November 17, 2014, upon the maturity of our 2014 Fixed-Rate Notes (2.90%), we repaid an aggregate principal amount of $500 million.

[0000858877-14-000043:mdna:288]
Other Debt  Other debt as of October 25, 2014 and July 26, 2014 included secured borrowings associated with customer financing arrangements.  The amount of borrowings outstanding under these arrangements was $9 million and $12 million as of October 25, 2014 and July 26, 2014, respectively.

[0000858877-14-000043:mdna:289]
Commercial Paper  In fiscal 2011, we established a short-term debt financing program of up to $3.0 billion through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes. We had no commercial paper notes outstanding as of each of October 25, 2014 and July 26, 2014.

[0000858877-14-000043:mdna:290]
Credit Facility  On February 17, 2012, we entered into a credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on February 17, 2017. Any advances under the credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (i) the higher of the Federal Funds rate plus 0.50%, Bank of America’s “prime rate” as announced from time to time, or one-month LIBOR plus 1.00% or (ii) LIBOR plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc. The credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio as defined in the agreement. As of October 25, 2014, we were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under the credit facility.

[0000858877-14-000043:mdna:291]
We may also, upon the agreement of either the existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and/or extend the expiration date of the credit facility by up to two additional years, or up to February 17, 2019.

[0000858877-14-000043:mdna:292]
[same as prior period, unchanged from 0000858877-14-000014:mdna:303]

[0000858877-14-000043:mdna:293]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-14-000043:mdna:294]
Deferred Revenue   The following table presents the breakdown of deferred revenue (in millions):

[0000858877-14-000043:mdna:295]
|  | October 25, 2014 |  | July 26, 2014 |  | Increase (Decrease) |
| Service | $ | 9,029 |  |  | $ | 9,640 |  |  | $ | (611 | ) |
| Product | 4,715 |  |  | 4,502 |  |  | 213 |  |
| Total | $ | 13,744 |  |  | $ | 14,142 |  |  | $ | (398 | ) |
| Reported as: |  |  |  |  |  |
| Current | $ | 9,449 |  |  | $ | 9,478 |  |  | $ | (29 | ) |
| Noncurrent | 4,295 |  |  | 4,664 |  |  | (369 | ) |
| Total | $ | 13,744 |  |  | $ | 14,142 |  |  | $ | (398 | ) |

[0000858877-14-000043:mdna:296]
The 6% decrease in deferred service revenue in the first quarter of fiscal 2015 as compared with the fourth quarter of fiscal 2014 reflects what, in our view, is a typical seasonal decline as we tend to experience higher service initiations as well as renewals in our fourth quarter. The 5% increase in deferred product revenue was primarily due to increased deferrals related to subscription revenue arrangements and, to a lesser extent, also due to an increase in shipments not having met revenue recognition criteria as of October 25, 2014.

[0000858877-14-000043:mdna:297]
[same as prior period, unchanged from 0000858877-14-000014:mdna:361]

[0000858877-14-000043:mdna:298]
[same as prior period, unchanged from 0000858877-14-000014:mdna:362]

[0000858877-14-000043:mdna:299]
We lease office space in many U.S. locations. Outside the United States, larger leased sites include sites in Belgium, Canada, China, France, Germany, India, Israel, Japan, Norway, and the United Kingdom. We also lease equipment and vehicles. The future minimum lease payments under all of our noncancelable operating leases with an initial term in excess of one year as of October 25, 2014 were $1.1 billion.

[0000858877-14-000043:mdna:300]
[same as prior period, unchanged from 0000858877-14-000014:mdna:364]

[0000858877-14-000043:mdna:301]
[same as prior period, unchanged from 0000858877-14-000014:mdna:365]

[0000858877-14-000043:mdna:302]
Insieme Networks, Inc.  In the third quarter of fiscal 2012, we made an investment in Insieme, an early stage company focused on research and development in the data center market.  As set forth in the agreement between Cisco and Insieme, this investment included $100 million of funding and a license to certain of our technology.  Immediately prior to the call option exercise and acquisition described below, we owned approximately 83% of Insieme as a result of these investments and have consolidated the results of Insieme in our Consolidated Financial Statements. In connection with this investment, we entered into a put/call option agreement that provided us with the right to purchase the remaining interests in Insieme.  In addition, the noncontrolling interest holders could require us to purchase their shares upon the occurrence of certain events.

[0000858877-14-000043:mdna:303]
During the first quarter of fiscal 2014, we exercised our call option and entered into an agreement to purchase the remaining interests in Insieme. The acquisition closed in the second quarter of fiscal 2014, at which time the former noncontrolling interest holders became eligible to receive up to two milestone payments, which will be determined using agreed-upon formulas based primarily on revenue for certain of Insieme’s products.  During the three months ended October 25, 2014 and October 26, 2013, we recorded compensation expense of $53 million and $257 million, respectively, related to the fair value of the vested portion of amounts that are expected to be earned by the former noncontrolling interest holders. Continued vesting and changes to the fair value of the amounts probable of being earned will result in adjustments to the recorded compensation expense in future periods. Based on the terms of the agreement, we have determined that the maximum amount that could be recorded as compensation expense by us is approximately $853 million, net of forfeitures and including the $469 million that has been expensed to date.  The milestone payments, if earned, are expected to be paid primarily during fiscal 2016 and fiscal 2017.

[0000858877-14-000043:mdna:304]
Other Funding Commitments  We also have certain funding commitments primarily related to our investments in privately held companies and venture funds, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $252 million as of October 25, 2014, compared with $255 million as of July 26, 2014.

[0000858877-14-000043:mdna:305]
[same as prior period, unchanged from 0000858877-14-000014:mdna:318]

[0000858877-14-000043:mdna:306]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-14-000043:mdna:307]
[same as prior period, unchanged from 0000858877-14-000014:mdna:372]

[0000858877-14-000043:mdna:308]
We consider our investments in unconsolidated variable interest entities to be off-balance sheet arrangements. In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers may be considered to be variable interest entities. We evaluate on an ongoing basis our investments in these privately held companies and customer financings, and we have determined that as of October 25, 2014 there were no material unconsolidated variable interest entities.

[0000858877-14-000043:mdna:309]
VCE is a joint venture that we formed in fiscal 2010 with EMC Corporation (“EMC”), with investments from VMware, Inc. (“VMware”) and Intel Capital Corporation (“Intel”). VCE helps organizations leverage best-in-class technologies and disciplines from Cisco, EMC, and VMware to enable the transformation to cloud computing.  As of October 25, 2014, our cumulative gross investment in VCE was approximately $716 million, inclusive of accrued interest on convertible notes, and our ownership percentage was approximately 35%. We did not make any investments in VCE during the three months ended October 25, 2014. As of October 25, 2014, we have recorded cumulative losses from VCE under the equity method of $691 million since inception. Our carrying value in VCE as of October 25, 2014 was $25 million.

[0000858877-14-000043:mdna:310]
EMC and Cisco have entered into guarantee agreements on behalf of VCE to indemnify certain customers (the “Guarantees”), for monetary damages. Such Guarantees were not material as of October 25, 2014.

[0000858877-14-000043:mdna:311]
In October 2014, Cisco, EMC, VMware and Intel agreed to restructure the VCE joint venture.  Under the terms of the agreement, VCE will undergo a reorganization and recapitalization whereby VCE will pay approximately $150 million to us for a portion of the outstanding principal balance of the convertible notes and accrued interest on such notes.  We also agreed to cancel the remaining principal balance of the convertible notes held by us and the accrued interest on such notes, and to have VCE redeem a portion of our equity interest in VCE.  EMC also agreed to indemnify Cisco for any liabilities incurred by us under the Guarantees.  Following this reorganization and recapitalization, our ownership interest in VCE will be approximately 10%.  The transaction is expected to close in the second quarter of our fiscal year 2015, subject to customary regulatory approvals.

[0000858877-14-000043:mdna:312]
[same as prior period, unchanged from 0000858877-14-000014:mdna:376]

[0000858877-14-000043:mdna:313]
[same as prior period, unchanged from 0000858877-14-000014:mdna:377]

[0000858877-14-000043:mdna:314]
[same as prior period, unchanged from 0000858877-14-000014:mdna:378]

[0000858877-14-000043:mdna:315]
We periodically engage in securities lending activities with certain of our available-for-sale investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. The average daily balance of securities lending for the three months ended October 25, 2014 and October 26, 2013 was $1.0 billion and $0.6 billion, respectively. We require collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. We engage in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify us against collateral losses. As of October 25, 2014 and July 26, 2014, we had no outstanding securities lending transactions. We believe these arrangements do not present a material risk or impact to our liquidity requirements.

[0000858877-14-000043:mdna:316]
[same as prior period, unchanged from 0000858877-14-000014:mdna:382]

[0000858877-14-000043:mdna:317]
Based on past performance and current expectations, we believe our cash and cash equivalents, investments, cash generated from operations, and ability to access capital markets and committed credit lines will satisfy, through at least the next 12 months, our liquidity requirements, both in total and domestically, including the following: working capital needs, capital expenditures, investment requirements, stock repurchases, cash dividends, contractual obligations, commitments, principal and interest payments on debt, future customer financings, and other liquidity requirements associated with our operations. There are no other transactions, arrangements, or relationships with unconsolidated entities or other persons that are reasonably likely to materially affect the liquidity and the availability of, as well as our requirements for, capital resources.

[0000858877-14-000043:mdna:318]
65
