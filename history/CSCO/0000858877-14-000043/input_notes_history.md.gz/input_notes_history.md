# CSCO note change history — 0000858877-14-000014 → 0000858877-14-000043


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2014-11-20):
[0000858877-14-000043:note_history:1]
The Company leases office space in many U.S. locations. Outside the United States, larger leased sites include sites in Belgium, Canada, China, France, Germany, India, Israel, Japan, Norway, and the United Kingdom.  The Company also leases equipment and vehicles. Future minimum lease payments under all noncancelable operating leases with an initial term in excess of one year as of October 25, 2014 are as follows (in millions):
  (was, 2014-05-22, similarity 0.968):
[0000858877-14-000014:note_history:1]
The Company leases office space in many U.S. locations. Outside the United States, larger leased sites include sites in Belgium, China, France, Germany, India, Israel, Italy, Japan, Norway, and the United Kingdom. The Company also leases equipment and vehicles. Future minimum lease payments under all noncancelable operating leases with an initial term in excess of one year as of April 26, 2014 are as follows (in millions):

- changed (2014-11-20):
[0000858877-14-000043:note_history:2]
| Fiscal Year | Amount |
| 2015 (remaining nine months) | $ | 292 |  |
| 2016 | 282 |  |
| 2017 | 185 |  |
| 2018 | 132 |  |
| 2019 | 65 |  |
| Thereafter | 183 |  |
| Total | $ | 1,139 |  |
  (was, 2014-05-22, similarity 0.9772):
[0000858877-14-000014:note_history:2]
| Fiscal Year | Amount |
| 2014 (remaining three months) | $ | 103 |  |
| 2015 | 332 |  |
| 2016 | 227 |  |
| 2017 | 157 |  |
| 2018 | 121 |  |
| Thereafter | 243 |  |
| Total | $ | 1,183 |  |

- changed (2014-11-20):
[0000858877-14-000043:note_history:3]
The Company purchases components from a variety of suppliers and uses several contract manufacturers to provide manufacturing services for its products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, the Company enters into agreements with contract manufacturers and suppliers that allow them to either procure inventory based upon criteria as defined by the Company or establish the parameters defining the Company’s requirements. A significant portion of the Company’s reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. In certain instances, these agreements allow the Company the option to cancel, reschedule, and adjust the Company’s requirements based on its business needs prior to firm orders being placed. As of October 25, 2014 and July 26, 2014, the Company had total purchase commitments for inventory of $4,299 million and $4,169 million, respectively.
  (was, 2014-05-22, similarity 0.9869):
[0000858877-14-000014:note_history:3]
The Company purchases components from a variety of suppliers and uses several contract manufacturers to provide manufacturing services for its products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, the Company enters into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by the Company or establish the parameters defining the Company’s requirements. A significant portion of the Company’s reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. In certain instances, these agreements allow the Company the option to cancel, reschedule, and adjust the Company’s requirements based on its business needs prior to firm orders being placed. As of April 26, 2014 and July 27, 2013, the Company had total purchase commitments for inventory of $4,038 million and $4,033 million, respectively.

- changed (2014-11-20):
[0000858877-14-000043:note_history:4]
The Company records a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of its future demand forecasts consistent with the valuation of the Company’s excess and obsolete inventory. As of October 25, 2014 and July 26, 2014, the liability for these purchase commitments was $169 million and $162 million, respectively, and was included in other current liabilities.
  (was, 2014-05-22, similarity 0.9848):
[0000858877-14-000014:note_history:4]
The Company records a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of its future demand forecasts consistent with the valuation of the Company’s excess and obsolete inventory. As of April 26, 2014 and July 27, 2013, the liability for these purchase commitments was $156 million and $172 million, respectively, and was included in other current liabilities.

- changed (2014-11-20):
[0000858877-14-000043:note_history:5]
In connection with the Company’s business combinations, the Company has agreed to pay certain additional amounts contingent upon the achievement of certain agreed-upon technology, development, product, or other milestones or upon the continued employment with the Company of certain employees of the acquired entities.
  (was, 2014-05-22, similarity 0.9984):
[0000858877-14-000014:note_history:5]
In connection with the Company’s business combinations, the Company has agreed to pay certain additional amounts contingent upon the achievement of certain agreed-upon technology, development, product, or other milestones, or upon the continued employment with the Company of certain employees of the acquired entities.

- changed (2014-11-20):
[0000858877-14-000043:note_history:6]
|  | Three Months Ended |
|  | October 25, 2014 |  | October 26, 2013 |
| Compensation expense related to acquisitions | $ | 98 |  |  | $ | 304 |  |
  (was, 2014-05-22, similarity 0.7134):
[0000858877-14-000014:note_history:6]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 26, 2014 |  | April 27, 2013 |  | April 26, 2014 |  | April 27, 2013 |
| Compensation expense related to acquisitions | $ | 95 |  |  | $ | 44 |  |  | $ | 505 |  |  | $ | 79 |  |

- changed (2014-11-20):
[0000858877-14-000043:note_history:7]
As of October 25, 2014, the Company estimated that future cash compensation expense of up to $528 million may be required to be recognized pursuant to the applicable business combination agreements, which included the remaining potential compensation expense related to Insieme Networks, Inc., as more fully discussed immediately below.
  (was, 2014-05-22, similarity 0.9801):
[0000858877-14-000014:note_history:7]
As of April 26, 2014, the Company estimated that future cash compensation expense of up to $645 million may be required to be recognized pursuant to the applicable business combination agreements, which included the remaining potential compensation expense related to Insieme Networks, Inc. as more fully discussed immediately below.

- changed (2014-11-20):
[0000858877-14-000043:note_history:8]
Insieme Networks, Inc.    In the third quarter of fiscal 2012, the Company made an investment in Insieme Networks, Inc. ("Insieme"), an early stage company focused on research and development in the data center market.  As set forth in the agreement between the Company and Insieme, this investment included $100 million of funding and a license to certain of the Company’s technology.  Immediately prior to the call option exercise and acquisition described below, the Company owned approximately 83% of Insieme as a result of these investments and consolidated the results of Insieme in its Consolidated Financial Statements.  In connection with this investment, the Company and Insieme entered into a put/call option agreement that provided the Company with the right to purchase the remaining interests in Insieme.  In addition, the noncontrolling interest holders could require the Company to purchase their shares upon the occurrence of certain events.
  (was, 2014-05-22, similarity 0.9989):
[0000858877-14-000014:note_history:8]
Insieme Networks, Inc. In the third quarter of fiscal 2012, the Company made an investment in Insieme Networks, Inc. ("Insieme"), an early-stage company focused on research and development in the data center market.  As set forth in the agreement between the Company and Insieme, this investment included $100 million of funding and a license to certain of the Company’s technology.  Immediately prior to the call option exercise and acquisition described below, the Company owned approximately 83% of Insieme as a result of these investments and consolidated the results of Insieme in its Consolidated Financial Statements.  In connection with this investment, the Company and Insieme entered into a put/call option agreement that provided the Company with the right to purchase the remaining interests in Insieme.  In addition, the noncontrolling interest holders could require the Company to purchase their shares upon the occurrence of certain events.

- changed (2014-11-20):
[0000858877-14-000043:note_history:9]
During the first quarter of fiscal 2014, the Company exercised its call option and entered into an agreement to purchase the remaining interests in Insieme.  The acquisition closed in the second quarter of fiscal 2014, at which time the former noncontrolling interest holders became eligible to receive up to two milestone payments, which will be determined using agreed-upon formulas based primarily on revenue for certain of Insieme’s products.  During the three months ended October 25, 2014 and October 26, 2013, the Company recorded compensation expense of $53 million and $257 million, respectively, related to the fair value of the vested portion of amounts that are expected to be earned by the former noncontrolling interest holders.  Continued vesting and changes to the fair value of the amounts probable of being earned will result in adjustments to the recorded compensation expense in future periods.  Based on the terms of the agreement, the Company has determined that the maximum amount that could be recorded as compensation expense by the Company is approximately $853 million, net of forfeitures and including the $469 million that has been expensed to date.  The milestone payments, if earned, are expected to be paid primarily during fiscal 2016 and fiscal 2017.
  (was, 2014-05-22, similarity 0.9592):
[0000858877-14-000014:note_history:9]
During the first quarter of fiscal 2014, the Company exercised its call option and entered into an agreement to purchase the remaining interests in Insieme.  The acquisition closed in the second quarter of fiscal 2014, at which time the former noncontrolling interest holders became eligible to receive up to two milestone payments, which will be determined using agreed-upon formulas based primarily on revenue for certain of Insieme’s products.  During the three and nine months ended April 26, 2014, the Company recorded compensation expense of $52 million and $363 million related to the fair value of the vested portion of amounts that are expected to be earned by the former noncontrolling interest holders.  Continued vesting and changes to the fair value of the amounts probable of being earned will result in adjustments to the recorded compensation expense in future periods.  Based on the terms of the agreement, the Company has determined that the maximum amount that could be recorded as compensation expense by the Company is approximately $856 million, net of forfeitures and including the $363 million that has been expensed through April 26, 2014.  The milestone payments, if earned, are expected to be paid primarily during fiscal 2016 and fiscal 2017.

- changed (2014-11-20):
[0000858877-14-000043:note_history:10]
The Company also has certain funding commitments, primarily related to its investments in privately held companies and venture funds, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $252 million and $255 million as of October 25, 2014 and July 26, 2014, respectively.
  (was, 2014-05-22, similarity 0.9836):
[0000858877-14-000014:note_history:10]
The Company also has certain funding commitments, primarily related to its investments in privately held companies and venture funds, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $276 million and $263 million as of April 26, 2014 and July 27, 2013, respectively.

- changed (2014-11-20):
[0000858877-14-000043:note_history:11]
| (d) | Product Warranties |
  (was, 2014-05-22, similarity 0.7606):
[0000858877-14-000014:note_history:11]
| (e) | Product Warranties and Guarantees |

- changed (2014-11-20):
[0000858877-14-000043:note_history:12]
The following table summarizes the activity related to the product warranty liability (in millions):
  (was, 2014-05-22, similarity 0.7711):
[0000858877-14-000014:note_history:12]
The following table summarizes the activity related to product warranty liability during the nine months ended April 26, 2014 and April 27, 2013 (in millions):

- changed (2014-11-20):
[0000858877-14-000043:note_history:13]
|  | Three Months Ended |
|  | October 25, 2014 |  | October 26, 2013 |
| Balance at beginning of period | $ | 446 |  |  | $ | 402 |  |
| Provision for warranties issued | 143 |  |  | 196 |  |
| Payments | (153 | ) |  | (169 | ) |
| Balance at end of period | $ | 436 |  |  | $ | 429 |  |
  (was, 2014-05-22, similarity 0.8235):
[0000858877-14-000014:note_history:13]
|  | Nine Months Ended |
|  | April 26, 2014 |  | April 27, 2013 |
| Balance at beginning of period | $ | 402 |  |  | $ | 373 |  |
| Provision for warranties issued | 532 |  |  | 480 |  |
| Payments | (504 | ) |  | (462 | ) |
| Balance at end of period | $ | 430 |  |  | $ | 391 |  |

- added (2014-11-20):
[0000858877-14-000043:note_history:14]
| (e) | Financing and Other Guarantees |

- added (2014-11-20):
[0000858877-14-000043:note_history:15]
In the ordinary course of business, the Company provides financing guarantees for various third-party financing arrangements extended to channel partners and end-user customers. Payments under these financing guarantee arrangements were not material for the periods presented.

- added (2014-11-20):
[0000858877-14-000043:note_history:16]
Channel Partner Financing Guarantees   The Company facilitates arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, generally with payment terms ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, the Company guarantees a portion of these arrangements. The volume of channel partner financing was $6.3 billion for each of the three months ended October 25, 2014 and October 26, 2013. The balance of the channel partner financing subject to guarantees was $1.3 billion and $1.2 billion as of October 25, 2014 and July 26, 2014, respectively.

- added (2014-11-20):
[0000858877-14-000043:note_history:17]
End-User Financing Guarantees   The Company also provides financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. The volume of financing provided by third parties for leases and loans as to which the Company had provided guarantees was $26 million and $25 million for the three months ended October 25, 2014 and October 26, 2013.

- added (2014-11-20):
[0000858877-14-000043:note_history:18]
Financing Guarantee Summary   The aggregate amounts of financing guarantees outstanding at October 25, 2014 and July 26, 2014, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

- added (2014-11-20):
[0000858877-14-000043:note_history:19]
|  | October 25, 2014 |  | July 26, 2014 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 285 |  |  | $ | 263 |  |
| End user | 161 |  |  | 202 |  |
| Total | $ | 446 |  |  | $ | 465 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (126 | ) |  | $ | (127 | ) |
| End user | (130 | ) |  | (166 | ) |
| Total | $ | (256 | ) |  | $ | (293 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue | $ | 190 |  |  | $ | 172 |  |

- added (2014-11-20):
[0000858877-14-000043:note_history:20]
Other Guarantees   The Company’s other guarantee arrangements as of October 25, 2014 and July 26, 2014 that were subject to recognition and disclosure requirements were not material.

- changed (2014-11-20):
[0000858877-14-000043:note_history:21]
| (f) | Supplier Component Remediation Liability |
  (was, 2014-05-22, similarity 0.9362):
[0000858877-14-000014:note_history:21]
(f)  Supplier Component Remediation Liability

- changed (2014-11-20):
[0000858877-14-000043:note_history:22]
The Company has recorded in other current liabilities a liability for the expected remediation cost for certain products sold in prior fiscal years containing memory components manufactured by a single supplier between 2005 and 2010. These components are widely used across the industry and are included in a number of the Company's products. Defects in some of these components have caused products to fail after a power cycle event.  Defect rates due to this issue have been and are expected to be low. However, the Company has seen a small number of its customers experience a growing number of failures in their networks as a result of this component problem. Although the majority of these products are beyond the Company's warranty terms, the Company is proactively working with customers on mitigation.  Prior to the second quarter of fiscal 2014, the Company had a liability of $63 million related to this issue for expected remediation costs based on the intended approach at that time. In February 2014, on the basis of the growing number of failures described above, the Company decided to expand its approach, which resulted in an additional charge to product cost of sales of $655 million being recorded for the second quarter of fiscal 2014.  The remaining supplier component remediation liability as of October 25, 2014 and July 26, 2014 was $639 million and $670 million, respectively.
  (was, 2014-05-22, similarity 0.968):
[0000858877-14-000014:note_history:22]
The Company has recorded in other current liabilities a liability for the expected remediation cost for certain products sold in prior fiscal years containing memory components manufactured by a single supplier between 2005 and 2010. These components are widely used across the industry and are included in a number of the Company's products. Defects in some of these components have caused products to fail after a power cycle event.  Defect rates due to this issue have been and are expected to be low. However, recently the Company has seen a small number of its customers experience a growing number of failures in their networks as a result of this component problem. Although the majority of these products are beyond the Company's warranty terms, the Company is proactively working with customers on mitigation.  Prior to the second quarter of fiscal 2014, the Company had a liability of $63 million related to this issue for expected remediation costs based on the intended approach at that time. In February 2014, on the basis of the growing number of failures described above, the Company decided to expand its approach which resulted in an additional charge to product cost of sales of $655 million being recorded for the second quarter of fiscal 2014.  As of April 26, 2014, the remaining supplier component remediation liability was $702 million.

- changed (2014-11-20):
[0000858877-14-000043:note_history:23]
| (g) | Indemnifications |
  (was, 2014-05-22, similarity 0.8696):
[0000858877-14-000014:note_history:23]
(g)  Indemnifications

- changed (2014-11-20):
[0000858877-14-000043:note_history:24]
The Company has an obligation to indemnify certain expenses pursuant to such agreements in a case involving certain of the Company’s service provider customers that are subject to patent infringement claims asserted by Sprint Communications Company, L.P. (“Sprint”) in the United States District Court for the District of Kansas filed on December 19, 2011 (including one case that was later transferred to the District of Delaware).  Sprint alleges that the service providers infringe Sprint’s patents by offering Voice over Internet Protocol-based telephone services utilizing products provided by the Company and other manufacturers.  Sprint is seeking monetary damages.  Trial dates have been set for the first half of calendar year 2015.  The parties intend to conduct a mediation process later this calendar year, and the Company may be asked to participate.  The mediation could result in a resolution of the case for some or all of the Company's service provider customers.  The Company believes that the service providers have strong defenses and that its products do not infringe the patents subject to the claims.  Due to the uncertainty surrounding the litigation process, which involves numerous defendants, the Company is unable to reasonably estimate the ultimate outcome of this litigation at this time.  Should the plaintiff prevail in litigation, mediation, or settlement, the Company may have an obligation to indemnify its service provider customers for damages, mediation awards, or settlement amounts arising from their use of Cisco products.
  (was, 2014-05-22, similarity 0.9815):
[0000858877-14-000014:note_history:24]
The Company has an obligation to indemnify certain expenses pursuant to such agreements in a case involving certain of the Company’s service provider customers that are subject to patent infringement claims asserted by Sprint Communications Company, L.P. (“Sprint”) in the United States District Court for the District of Kansas filed on December 19, 2011 (including one case that was later transferred to the District of Delaware).  Sprint alleges that the service providers infringe Sprint’s patents by offering Voice over Internet Protocol-based telephone services utilizing products provided by the Company and other manufacturers.  Sprint is seeking monetary damages.  Trial dates have been set for the first half of calendar year 2015.  The parties intend to conduct a mediation later this calendar year and the Company may be asked to participate.  The mediation could result in a resolution of the case for some or all of the Company's service provider customers.  The Company believes that the service providers have strong defenses and that its products do not infringe the patents subject to the claims.  Due to the uncertainty surrounding the litigation process, which involves numerous defendants, the Company is unable to reasonably estimate the ultimate outcome of this litigation at this time.  Should the plaintiff prevail in litigation, mediation, or settlement, the Company may have an obligation to indemnify its service provider customers for damages, mediation awards, or settlement amounts arising from their use of Cisco products.

- changed (2014-11-20):
[0000858877-14-000043:note_history:25]
| (h) | Legal Proceedings |
  (was, 2014-05-22, similarity 0.875):
[0000858877-14-000014:note_history:25]
(h) Legal Proceedings

- changed (2014-11-20):
[0000858877-14-000043:note_history:26]
The asserted claims by Brazilian federal tax authorities are for calendar years 2003 through 2008, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to approximately $348 million for the alleged evasion of import and other taxes, approximately $1.3 billion for interest, and approximately $1.5 billion for various penalties, all determined using an exchange rate as of October 25, 2014. The Company has completed a thorough review of the matters and believes the asserted claims against the Company’s Brazilian subsidiary are without merit, and the Company is defending the claims vigorously. While the Company believes there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, the Company is unable to determine the likelihood of an unfavorable outcome against its Brazilian subsidiary and is unable to reasonably estimate a range of loss, if any. The Company does not expect a final judicial determination for several years.
  (was, 2014-05-22, similarity 0.995):
[0000858877-14-000014:note_history:26]
The asserted claims by Brazilian federal tax authorities are for calendar years 2003 through 2008, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to approximately $389 million for the alleged evasion of import and other taxes, approximately $1.3 billion for interest, and approximately $1.7 billion for various penalties, all determined using an exchange rate as of April 26, 2014. The Company has completed a thorough review of the matters and believes the asserted claims against the Company’s Brazilian subsidiary are without merit, and the Company is defending the claims vigorously. While the Company believes there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, the Company is unable to determine the likelihood of an unfavorable outcome against its Brazilian subsidiary and is unable to reasonably estimate a range of loss, if any. The Company does not expect a final judicial determination for several years.

- changed (2014-11-20):
[0000858877-14-000043:note_history:27]
Russia and the Commonwealth of Independent States    At the request of the U.S. Securities and Exchange Commission (SEC) and the U.S. Department of Justice, the Company is conducting an investigation into allegations which the Company and those agencies received regarding possible violations of the U.S. Foreign Corrupt Practices Act involving business activities of the Company's operations in Russia and certain of the Commonwealth of Independent States, and by certain resellers of the Company’s products in those countries.  The Company takes any such allegations very seriously and is fully cooperating with and sharing the results of its investigation with the SEC and the Department of Justice.  While the outcome of the Company's investigation is currently not determinable, the Company does not expect that it will have a material adverse effect on its consolidated financial position, results of operations, or cash flows. The countries that are the subject of the investigation collectively comprise less than 2% of the Company’s revenues.
  (was, 2014-05-22, similarity 0.9613):
[0000858877-14-000014:note_history:27]
Russia and the Commonwealth of Independent States At the request of the U.S. Securities and Exchange Commission and the U.S. Department of Justice, the Company is conducting an investigation into allegations which the Company and those agencies received regarding possible violations of the U.S. Foreign Corrupt Practices Act involving business activities of the Company's operations in Russia and certain of the Commonwealth of Independent States, and by certain resellers of the Company’s products in those countries.  The Company takes any such allegations very seriously and is fully cooperating with and sharing the results of its investigation with the Commission and the Department.  While the outcome of the Company's investigation is currently not determinable, the Company does not expect that it will have a material adverse effect on its consolidated financial position, results of operations, or cash flows. The countries that are the subject of the investigation collectively comprise less than two percent of the Company’s revenues.

- added (2014-11-20):
[0000858877-14-000043:note_history:28]
Rockstar    The Company and some of its service provider customers are subject to patent claims asserted in December 2013 in the Eastern District of Texas and the District of Delaware by subsidiaries of the Rockstar Consortium ("Rockstar").  Rockstar, whose members include Apple, Microsoft, LM Ericsson, Sony, and Blackberry, purchased a portfolio of patents out of the Nortel Networks’ bankruptcy proceedings (the “Nortel Portfolio”). Rockstar’s subsidiaries allege that some of the Company’s NGN Routing, Switching and Collaboration products, as well as video solutions deployed by its service provider customers, infringe some of the patents in the Nortel Portfolio.  A binding letter of intent has been executed with Rockstar regarding the Nortel Portfolio.  The transaction, which is subject to various closing conditions, will result in various technology companies, including but not limited to the Company and the various service provider customers described above, obtaining a license to that portfolio. The parties agreed to stay the litigation pending negotiation of agreements, and when the transaction closes, Rockstar will dismiss all litigation brought against the participating companies.  In connection with this matter, during the first quarter of fiscal 2015 the Company recorded a charge to product cost of sales of $188 million.

- removed (2014-11-20):
[0000858877-14-000014:note_history:29]
| (d) | Variable Interest Entities |

- removed (2014-11-20):
[0000858877-14-000014:note_history:30]
VCE Joint Venture VCE is a joint venture that the Company formed in fiscal 2010 with EMC Corporation (“EMC”), with investments from VMware, Inc. (“VMware”) and Intel Corporation. VCE helps organizations leverage best-in-class technologies and disciplines from Cisco, EMC, and VMware to enable the transformation to cloud computing.

- removed (2014-11-20):
[0000858877-14-000014:note_history:31]
As of April 26, 2014, the Company’s cumulative gross investment in VCE was approximately $679 million, inclusive of accrued interest, and its ownership percentage was approximately 35%.  The Company invested $147 million during the nine months ended April 26, 2014.

- removed (2014-11-20):
[0000858877-14-000014:note_history:32]
The Company accounts for its investment in VCE under the equity method, and its portion of VCE’s net loss is recognized in other income (loss), net.  The Company’s share of VCE’s losses, based upon its portion of the overall funding, was approximately 36.8% for each of the three and nine months ended April 26, 2014 and April 27, 2013.  As of April 26, 2014, the Company had recorded cumulative losses from VCE of $584 million since inception, of which losses of $52 million and $49 million were recorded for the three months ended April 26, 2014 and April 27, 2013, respectively, and losses of $163 million and $135 million were recorded for the nine months ended April 26, 2014 and April 27, 2013, respectively.  The Company’s carrying value in VCE as of April 26, 2014 of $95 million was recorded in other assets.

- removed (2014-11-20):
[0000858877-14-000014:note_history:33]
Over the next 12 months, as VCE scales its operations, the Company expects that it will make additional investments in VCE and may incur additional losses proportionate with the Company’s share ownership.

- removed (2014-11-20):
[0000858877-14-000014:note_history:34]
From time to time, EMC and Cisco may enter into guarantee agreements on behalf of VCE to indemnify third parties, such as customers, for monetary damages. Such guarantees were not material as of April 26, 2014.

- removed (2014-11-20):
[0000858877-14-000014:note_history:35]
Other Variable Interest Entities In the ordinary course of business, the Company has investments in other privately held companies and provides financing to certain customers. These other privately held companies and customers may be considered to be variable interest entities. The Company evaluates on an ongoing basis its investments in these other privately held companies and its customer financings, and has determined that as of April 26, 2014 there were no other variable interest entities required to be consolidated in the Company’s Consolidated Financial Statements.

- removed (2014-11-20):
[0000858877-14-000014:note_history:36]
The Company also provides financing guarantees, which are generally for various third-party financing arrangements to channel partners and other end-user customers. For additional information, see Note 7. The Company’s other guarantee arrangements as of April 26, 2014 and July 27, 2013 that were subject to recognition and disclosure requirements were not material.

- removed (2014-11-20):
[0000858877-14-000014:note_history:37]
VirnetX  The Company was subject to patent claims asserted by VirnetX, Inc. on August 11, 2010 in the United States District Court for the Eastern District of Texas.  VirnetX alleged that some Cisco products that implement a method for secure communication using virtual private networks infringe certain patents.  VirnetX sought monetary damages.  The trial on these claims began on March 4, 2013. On March 14, 2013, the jury entered a verdict finding that the Company’s accused products do not infringe any of VirnetX’s patents asserted in the lawsuit. On April 3, 2013, VirnetX filed a motion seeking a new trial on the issue of infringement, which the Company opposed. The Court held a hearing on VirnetX’s motion for a new trial in June 2013.  On March 31, 2014 the court denied VirnetX's new trial motion.  VirnetX has not appealed that decision, which is therefore final.

- removed (2014-11-20):
[0000858877-14-000014:note_history:38]
XpertUniverse The Company was subject to numerous patent, tort, and contract claims asserted by XpertUniverse on March 10, 2009 in the United States District Court for the District of Delaware. Shortly before trial, the Court dismissed on summary judgment all claims initially asserted by XpertUniverse except a claim for infringement of two XpertUniverse patents and a claim for fraud by concealment. XpertUniverse’s remaining patent claims alleged that three Cisco products in the field of expertise location software infringed two XpertUniverse patents. XpertUniverse’s fraud by concealment claim alleged that the Company did not disclose its decision not to admit XpertUniverse into a partner program. The trial on these remaining claims began on March 11, 2013. On March 22, 2013, the jury entered a verdict finding that two of the Company’s products infringed two of XpertUniverse’s patents and awarded XpertUniverse damages of less than $35 thousand. The jury also found for XpertUniverse on its fraud by concealment claim and awarded damages of $70 million.  In May and June 2013, the Company filed post-trial motions.  On November 20, 2013 the trial court granted the Company's motion for judgment as a matter of law, overturned the jury’s finding on the fraud by concealment claim, and vacated the $70 million verdict.  Separately, the trial court agreed with the jury that the Company infringed XpertUniverse’s patents, and affirmed the verdict awarding XpertUniverse approximately $35 thousand in damages plus accrued interest.  On February 4, 2014, XpertUniverse filed a notice of appeal from the trial court’s decision.

- removed (2014-11-20):
[0000858877-14-000014:note_history:39]
Rockstar The Company and some of its service provider customers are subject to patent claims asserted in December 2013 in the Eastern District of Texas and the District of Delaware by subsidiaries of the Rockstar Consortium ("Rockstar").  Rockstar, whose members include Apple, Microsoft, LM Ericsson, Sony, and Blackberry, purchased a portfolio of patents out of the Nortel Networks’ bankruptcy proceedings (the “Nortel Portfolio”). Rockstar’s subsidiaries allege that some of the Company’s NGN Routing, Switching and Collaboration products, as well as video solutions deployed by its service provider customers, infringe some of the patents in the Nortel Portfolio.  Rockstar seeks monetary damages.  A trial date for one service provider customer has been set for October 2015; no other trial dates have been set.  The Company has various defenses to the patent infringement allegations, and has various offensive claims against Rockstar and some of its consortium members available to it as well, and the Company will also explore alternative means of resolution.   Due to the uncertainty surrounding the litigation process, which involves numerous lawsuits and parties, the Company is unable to reasonably estimate the ultimate outcome and a range of loss, if any, of these litigations at this time.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2014-11-20):
[0000858877-14-000043:note_history:40]
The fiscal year for Cisco Systems, Inc. (the “Company” or “Cisco”) is the 52 or 53 weeks ending on the last Saturday in July. Fiscal 2015 and fiscal 2014 are each 52-week fiscal years. The Consolidated Financial Statements include the accounts of Cisco and its subsidiaries. All intercompany accounts and transactions have been eliminated. The Company conducts business globally and is primarily managed on a geographic basis in the following three geographic segments: the Americas; Europe, Middle East, and Africa (EMEA); and Asia Pacific, Japan, and China (APJC).
  (was, 2014-05-22, similarity 0.9893):
[0000858877-14-000014:note_history:40]
The fiscal year for Cisco Systems, Inc. (the “Company” or “Cisco”) is the 52 or 53 weeks ending on the last Saturday in July. Fiscal 2014 and fiscal 2013 are each 52-week fiscal years. The Consolidated Financial Statements include the accounts of Cisco and its subsidiaries. All significant intercompany accounts and transactions have been eliminated. The Company conducts business globally and is primarily managed on a geographic basis in the following three geographic segments: the Americas; Europe, Middle East, and Africa (EMEA); and Asia Pacific, Japan, and China (APJC).

- changed (2014-11-20):
[0000858877-14-000043:note_history:41]
The accompanying financial data as of October 25, 2014 and for the three months ended October 25, 2014 and October 26, 2013 has been prepared by the Company, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (SEC). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (GAAP) have been condensed or omitted pursuant to such rules and regulations. The July 26, 2014 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, the Company believes that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended July 26, 2014.
  (was, 2014-05-22, similarity 0.9659):
[0000858877-14-000014:note_history:41]
The accompanying financial data as of April 26, 2014 and for the three and nine months ended April 26, 2014 and April 27, 2013 has been prepared by the Company, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (SEC). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (GAAP) have been condensed or omitted pursuant to such rules and regulations. The July 27, 2013 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, the Company believes that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended July 27, 2013.

- added (2014-11-20):
[0000858877-14-000043:note_history:42]
In the opinion of management, all adjustments (which include normal recurring adjustments, except as disclosed herein) necessary to present fairly the consolidated balance sheet as of October 25, 2014; the results of operations; statements of comprehensive income, cash flows, and equity for the three months ended October 25, 2014 and October 26, 2013, as applicable, have been made. The results of operations for the three months ended October 25, 2014 are not necessarily indicative of the operating results for the full fiscal year or any future periods.

- changed (2014-11-20):
[0000858877-14-000043:note_history:43]
Certain reclassifications have been made to the amounts in prior periods in order to conform to the current period’s presentation.  The Company has evaluated subsequent events through the date that the financial statements were issued.
  (was, 2014-05-22, similarity 0.9):
[0000858877-14-000014:note_history:43]
Certain reclassifications have been made to prior-period amounts in order to conform to the current period’s presentation. The Company has evaluated subsequent events through the date that the financial statements were issued.

- removed (2014-11-20):
[0000858877-14-000014:note_history:44]
In the opinion of management, all adjustments (which include normal recurring adjustments, except as disclosed herein) necessary to present fairly the statement of financial position as of April 26, 2014; the results of operations and statements of comprehensive income for the three and nine months ended April 26, 2014 and April 27, 2013; and the statements of cash flows and equity for the nine months ended April 26, 2014 and April 27, 2013, as applicable, have been made. The results of operations for the three and nine months ended April 26, 2014 are not necessarily indicative of the operating results for the full fiscal year or any future periods.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2014-11-20):
[0000858877-14-000043:note_history:45]
In March 2013, the FASB issued an accounting standard update requiring an entity to release into net income the entire amount of a cumulative translation adjustment related to its investment in a foreign entity when as a parent it sells either a part or all of its investment in the foreign entity or no longer holds a controlling financial interest in a subsidiary or group of assets within the foreign entity.  This accounting standard update became effective for the Company beginning in the first quarter of fiscal 2015. The application of this accounting standard update did not have any impact to the Company's Consolidated Financial Statements.
  (was, 2014-05-22, similarity 0.844):
[0000858877-14-000014:note_history:45]
In March 2013, the FASB issued an accounting standard update requiring an entity to release into net income the entire amount of a cumulative translation adjustment related to its investment in a foreign entity when as a parent it either sells a part or all of its investment in the foreign entity or no longer holds a controlling financial interest in a subsidiary or group of assets within the foreign entity.  This accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2015. The Company is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.

- changed (2014-11-20):
[0000858877-14-000043:note_history:46]
In July 2013, the FASB issued an accounting standard update that provides explicit guidance on the financial statement presentation of an unrecognized tax benefit when a net operating loss carryforward or a tax credit carryforward exists. Under the new standard update, an unrecognized tax benefit, or a portion of an unrecognized tax benefit, is to be presented in the financial statements as a reduction to a deferred tax asset for a net operating loss carryforward or a tax credit carryforward.  This accounting standard update became effective for the Company beginning in the first quarter of fiscal 2015 and applied prospectively. The application of this accounting standard update did not have a material impact to the Company's Consolidated Financial Statements.
  (was, 2014-05-22, similarity 0.6964):
[0000858877-14-000014:note_history:46]
In July 2013, the FASB issued an accounting standard update that provides explicit guidance on the financial statement presentation of an unrecognized tax benefit when a net operating loss carryforward or a tax credit carryforward exists. Under the new standard update, an unrecognized tax benefit, or a portion of an unrecognized tax benefit, is to be presented in the financial statements as a reduction to a deferred tax asset for a net operating loss carryforward or a tax credit carryforward.  This accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2015 and applied prospectively with early adoption permitted. The Company is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.

- added (2014-11-20):
[0000858877-14-000043:note_history:47]
In April 2014, the FASB issued an accounting standard update that changes the criteria for reporting discontinued operations.  This accounting standard update raises the threshold for a disposal transaction to qualify as a discontinued operation and requires additional disclosures about discontinued operations and disposals of individually significant components that do not qualify as discontinued operations.  This accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2016.  Early adoption is permitted, but only for disposals that have not been reported in financial statements previously issued.  The Company is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.

- added (2014-11-20):
[0000858877-14-000043:note_history:48]
In May 2014, the FASB issued an accounting standard update related to revenue from contracts with customers, which will supersede nearly all current U.S. GAAP guidance on this topic and eliminate industry-specific guidance.  The underlying principle is to recognize revenue when promised goods or services are transferred to customers in an amount that reflects the consideration that is expected to be received for those goods or services. This accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2018. The new revenue standard may be applied retrospectively to each prior period presented or retrospectively with the cumulative effect recognized as of the date of adoption.  Early adoption is not permitted.  The Company is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.

- removed (2014-11-20):
[0000858877-14-000014:note_history:49]
In December 2011, the Financial Accounting Standards Board (FASB) issued an accounting standard update requiring enhanced disclosures about certain financial instruments and derivative instruments that are offset in the statement of financial position or that are subject to enforceable master netting arrangements or similar agreements. This accounting standard became effective for the Company in the first quarter of fiscal 2014.  As a result of the application of this accounting standard update, the Company has provided additional disclosures in Note 11.

- removed (2014-11-20):
[0000858877-14-000014:note_history:50]
In July 2012, the FASB issued an accounting standard update intended to simplify how an entity tests indefinite-lived intangible assets other than goodwill for impairment by providing entities with an option to perform a qualitative assessment to determine whether further impairment testing is necessary. This accounting standard update became effective for the Company beginning in the first quarter of fiscal 2014, and its adoption did not have any impact on the Company’s Consolidated Financial Statements.

- removed (2014-11-20):
[0000858877-14-000014:note_history:51]
In February 2013, the FASB issued an accounting standard update to require reclassification adjustments from other comprehensive income to be presented either in the financial statements or in the notes to the financial statements. This accounting standard became effective for the Company in the first quarter of fiscal 2014.  As a result of the application of this accounting standard update, the Company has provided additional disclosures in Note 15.

- removed (2014-11-20):
[0000858877-14-000014:note_history:52]
In April 2014, the FASB issued an accounting standard update that changes the criteria for reporting discontinued operations.  Under the accounting standard update, a disposal of a component of an entity or a group of components of an entity is required to be reported in discontinued operations if the disposal represents a strategic shift that has, or will have, a major effect on an entity's operations and financial results when either it qualifies as held for sale, disposed of by sale, or disposed of other than by sale.  This accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2016.  The Company is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-11-20):
[0000858877-14-000043:note_history:53]
|  | October 25, 2014 |  | July 26, 2014 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 1,350 |  |  | 1.38 | % |  | $ | 500 |  |  | 3.11 | % |
| Other short-term debt | 7 |  |  | 2.76 | % |  | 8 |  |  | 2.67 | % |
| Total short-term debt | $ | 1,357 |  |  |  |  | $ | 508 |  |  |  |
  (was, 2014-05-22, similarity 0.6632):
[0000858877-14-000014:note_history:53]
|  | April 26, 2014 |  | July 27, 2013 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 500 |  |  | 3.11 | % |  | $ | 3,273 |  |  | 0.63 | % |
| Other notes and borrowings | 8 |  |  | 2.60 | % |  | 10 |  |  | 2.52 | % |
| Total short-term debt | $ | 508 |  |  |  |  | $ | 3,283 |  |  |  |

- changed (2014-11-20):
[0000858877-14-000043:note_history:54]
In fiscal 2011, the Company established a short-term debt financing program of up to $3.0 billion through the issuance of commercial paper notes. The Company uses the proceeds from the issuance of commercial paper notes for general corporate purposes. The Company had no commercial paper notes outstanding as of each of October 25, 2014 and July 26, 2014.
  (was, 2014-05-22, similarity 0.7927):
[0000858877-14-000014:note_history:54]
In fiscal 2011, the Company established a short-term debt financing program of up to $3.0 billion through the issuance of commercial paper notes. The Company uses the proceeds from the issuance of commercial paper notes for general corporate purposes. In the third quarter of fiscal 2014, the Company repaid $1.0 billion of indebtedness under commercial paper and had no commercial paper outstanding as of each of April 26, 2014 and July 27, 2013.

- changed (2014-11-20):
[0000858877-14-000043:note_history:55]
."  Other notes and borrowings consist of the short-term portion of secured borrowings associated with customer financing arrangements.  These notes and credit facilities were subject to various terms and foreign currency market interest rates pursuant to individual financial arrangements between the financing institution and the applicable foreign subsidiary.
  (was, 2014-05-22, similarity 0.8154):
[0000858877-14-000014:note_history:55]
."  The Company repaid senior floating-rate and fixed-rate notes upon their maturity in the third quarter of fiscal 2014 for an aggregate principal amount of $3.3 billion.  Other notes and borrowings consist of the short-term portion of secured borrowings associated with customer financing arrangements.  These notes and credit facilities were subject to various terms and foreign currency market interest rates pursuant to individual financial arrangements between the financing institution and the applicable foreign subsidiary.

- added (2014-11-20):
[0000858877-14-000043:note_history:56]
On November 17, 2014, upon the maturity of the Company’s 2014 Fixed-Rate Notes (2.90%), the Company repaid an aggregate principal amount of $500 million.

- changed (2014-11-20):
[0000858877-14-000043:note_history:57]
|  |  |  | October 25, 2014 |  | July 26, 2014 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.05% | September 3, 2015 |  | $ | 850 |  |  | 0.36% |  | $ | 850 |  |  | 0.35% |
| Three-month LIBOR plus 0.28% | March 3, 2017 |  | 1,000 |  |  | 0.57% |  | 1,000 |  |  | 0.56% |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | 500 |  |  | 0.79% |  | 500 |  |  | 0.78% |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 2.90% | November 17, 2014 |  | 500 |  |  | 3.11% |  | 500 |  |  | 3.11% |
| 5.50% | February 22, 2016 |  | 3,000 |  |  | 3.05% |  | 3,000 |  |  | 3.04% |
| 1.10% | March 3, 2017 |  | 2,400 |  |  | 0.55% |  | 2,400 |  |  | 0.56% |
| 3.15% | March 14, 2017 |  | 750 |  |  | 0.80% |  | 750 |  |  | 0.79% |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 4.69% |  | 2,000 |  |  | 4.69% |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 0.77% |  | 1,750 |  |  | 0.77% |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 2.98% |  | 2,500 |  |  | 2.98% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 0.93% |  | 500 |  |  | 0.93% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1.04% |  | 1,000 |  |  | 1.05% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Other long-term debt |  |  | 2 |  |  | 2.08% |  | 4 |  |  | 2.39% |
| Total |  |  | 20,752 |  |  |  |  | 20,754 |  |  |  |
| Unaccreted discount |  |  | (62 | ) |  |  |  | (63 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 275 |  |  |  |  | 210 |  |  |  |
| Total |  |  | $ | 20,965 |  |  |  |  | $ | 20,901 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 1,350 |  |  |  |  | $ | 500 |  |  |  |
| Long-term debt |  |  | 19,615 |  |  |  |  | 20,401 |  |  |  |
| Total |  |  | $ | 20,965 |  |  |  |  | $ | 20,901 |  |  |  |
  (was, 2014-05-22, similarity 0.8258):
[0000858877-14-000014:note_history:57]
|  |  |  | April 26, 2014 |  | July 27, 2013 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.25% | March 14, 2014 |  | $ | — |  |  | — |  | $ | 1,250 |  |  | 0.62% |
| Three-month LIBOR plus 0.05% | September 3, 2015 | (1) | 850 |  |  | 0.38% |  | — |  |  | — |
| Three-month LIBOR plus 0.28% | March 3, 2017 | (1) | 1,000 |  |  | 0.58% |  | — |  |  | — |
| Three-month LIBOR plus 0.50% | March 1, 2019 | (1) | 500 |  |  | 0.79% |  | — |  |  | — |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 1.625% | March 14, 2014 |  | — |  |  | — |  | 2,000 |  |  | 0.64% |
| 2.90% | November 17, 2014 |  | 500 |  |  | 3.11% |  | 500 |  |  | 3.11% |
| 5.50% | February 22, 2016 |  | 3,000 |  |  | 3.05% |  | 3,000 |  |  | 3.07% |
| 1.10% | March 3, 2017 | (1) | 2,400 |  |  | 0.56% |  | — |  |  | — |
| 3.15% | March 14, 2017 |  | 750 |  |  | 0.80% |  | 750 |  |  | 0.84% |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 4.69% |  | 2,000 |  |  | 4.70% |
| 2.125% | March 1, 2019 | (1) | 1,750 |  |  | 0.77% |  | — |  |  | — |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 2.98% |  | 2,500 |  |  | 4.15% |
| 2.90% | March 4, 2021 | (1) | 500 |  |  | 0.93% |  | — |  |  | — |
| 3.625% | March 3, 2024 | (1) | 1,000 |  |  | 1.05% |  | — |  |  | — |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Other long-term debt |  |  | 6 |  |  | 2.52% |  | 21 |  |  | 1.46% |
| Total |  |  | 20,756 |  |  |  |  | 16,021 |  |  |  |
| Unaccreted discount |  |  | (65 | ) |  |  |  | (65 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 193 |  |  |  |  | 245 |  |  |  |
| Total |  |  | $ | 20,884 |  |  |  |  | $ | 16,201 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 500 |  |  |  |  | $ | 3,273 |  |  |  |
| Long-term debt |  |  | 20,384 |  |  |  |  | 12,928 |  |  |  |
| Total |  |  | $ | 20,884 |  |  |  |  | $ | 16,201 |  |  |  |

- changed (2014-11-20):
[0000858877-14-000043:note_history:58]
To achieve its interest rate risk management objectives, the Company entered into interest rate swaps in prior periods with an aggregate notional amount of $10.4 billion designated as fair value hedges of certain of its fixed-rate senior notes. In effect, these swaps convert the fixed interest rates of the fixed-rate notes to floating interest rates based on the London InterBank Offered Rate (LIBOR). The gains and losses related to changes in the fair value of the interest rate swaps substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates. For additional information, see Note 11.
  (was, 2014-05-22, similarity 0.9873):
[0000858877-14-000014:note_history:58]
To achieve its interest rate risk management objectives, the Company entered into interest rate swaps with an aggregate notional amount of $10.4 billion designated as fair value hedges of certain of its fixed-rate senior notes. In effect, these swaps convert the fixed interest rates of the fixed-rate notes to floating interest rates based on the London InterBank Offered Rate (LIBOR). The gains and losses related to changes in the fair value of the interest rate swaps substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates. For additional information, see Note 11.

- changed (2014-11-20):
[0000858877-14-000043:note_history:59]
The effective rates for the fixed-rate debt include the interest on the notes, the accretion of the discount, and, if applicable, adjustments related to hedging. Interest is payable semiannually on each class of the senior fixed-rate notes and payable quarterly on the floating-rate notes. Each of the senior fixed-rate notes is redeemable by the Company at any time, subject to a make-whole premium.
  (was, 2014-05-22, similarity 0.9987):
[0000858877-14-000014:note_history:59]
The effective rates for the fixed-rate debt include the interest on the notes, the accretion of the discount and, if applicable, adjustments related to hedging. Interest is payable semiannually on each class of the senior fixed-rate notes and payable quarterly on the floating-rate notes. Each of the senior fixed-rate notes is redeemable by the Company at any time, subject to a make-whole premium.

- changed (2014-11-20):
[0000858877-14-000043:note_history:60]
The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to the Company’s short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of October 25, 2014, the Company was in compliance with all debt covenants.
  (was, 2014-05-22, similarity 0.9781):
[0000858877-14-000014:note_history:60]
The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to the Company’s short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of April 26, 2014, the Company was in compliance with all debt covenants.

- changed (2014-11-20):
[0000858877-14-000043:note_history:61]
As of October 25, 2014, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):
  (was, 2014-05-22, similarity 0.9627):
[0000858877-14-000014:note_history:61]
As of April 26, 2014, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

- changed (2014-11-20):
[0000858877-14-000043:note_history:62]
| Fiscal Year | Amount |
| 2015 (remaining nine months) | $ | 500 |  |
| 2016 | 3,851 |  |
| 2017 | 4,151 |  |
| 2018 | — |  |
| 2019 | 4,250 |  |
| Thereafter | 8,000 |  |
| Total | $ | 20,752 |  |
  (was, 2014-05-22, similarity 0.899):
[0000858877-14-000014:note_history:62]
| Fiscal Year | Amount |
| 2014 (remaining three months) | $ | — |  |
| 2015 | 502 |  |
| 2016 | 3,853 |  |
| 2017 | 4,151 |  |
| 2018 | — |  |
| Thereafter | 12,250 |  |
| Total | $ | 20,756 |  |

- changed (2014-11-20):
[0000858877-14-000043:note_history:63]
On February 17, 2012, the Company entered into a credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on February 17, 2017. Any advances under the credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (i) the higher of the Federal Funds rate plus 0.50%, Bank of America’s “prime rate” as announced from time to time, or one-month LIBOR plus 1.00% or (ii) LIBOR plus a margin that is based on the Company’s senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc. The credit agreement requires the Company to comply with certain covenants, including that it maintain an interest coverage ratio as defined in the agreement. As of October 25, 2014, the Company was in compliance with the required interest coverage ratio and the other covenants, and the Company had not borrowed any funds under the credit facility.
  (was, 2014-05-22, similarity 0.994):
[0000858877-14-000014:note_history:63]
On February 17, 2012, the Company entered into a credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on February 17, 2017. Any advances under the credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (i) the higher of the Federal Funds rate plus 0.50%, Bank of America’s “prime rate” as announced from time to time, or one-month LIBOR plus 1.00% or (ii) LIBOR plus a margin that is based on the Company’s senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc. The credit agreement requires the Company to comply with certain covenants, including that it maintain an interest coverage ratio as defined in the agreement. As of April 26, 2014, the Company was in compliance with the required interest coverage ratio and the other covenants, and the Company had not borrowed any funds under the credit facility.

- removed (2014-11-20):
[0000858877-14-000014:note_history:64]
As of April 26, 2014, the estimated fair value of the short-term debt approximates its carrying value due to the short maturities.

- removed (2014-11-20):
[0000858877-14-000014:note_history:65]
(1) In March 2014, the Company issued senior notes for an aggregate principal amount of $8.0 billion.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-11-20):
[0000858877-14-000043:note_history:66]
| October 25, 2014 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| Fixed income securities: |  |  |  |  |  |  |  |
| U.S. government securities | $ | 32,343 |  |  | $ | 71 |  |  | $ | — |  |  | $ | 32,414 |  |
| U.S. government agency securities | 1,338 |  |  | 3 |  |  | — |  |  | 1,341 |  |
| Non-U.S. government and agency securities | 1,049 |  |  | 2 |  |  | — |  |  | 1,051 |  |
| Corporate debt securities | 10,170 |  |  | 73 |  |  | (10 | ) |  | 10,233 |  |
| U.S. agency mortgage-backed securities | 875 |  |  | 9 |  |  | — |  |  | 884 |  |
| Total fixed income securities | 45,775 |  |  | 158 |  |  | (10 | ) |  | 45,923 |  |
| Publicly traded equity securities | 1,263 |  |  | 545 |  |  | (11 | ) |  | 1,797 |  |
| Total | $ | 47,038 |  |  | $ | 703 |  |  | $ | (21 | ) |  | $ | 47,720 |  |
| July 26, 2014 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| Fixed income securities: |  |  |  |  |  |  |  |
| U.S. government securities | $ | 31,717 |  |  | $ | 29 |  |  | $ | (12 | ) |  | $ | 31,734 |  |
| U.S. government agency securities | 1,062 |  |  | 1 |  |  | — |  |  | 1,063 |  |
| Non-U.S. government and agency securities | 860 |  |  | 2 |  |  | (1 | ) |  | 861 |  |
| Corporate debt securities | 9,092 |  |  | 74 |  |  | (7 | ) |  | 9,159 |  |
| U.S. agency mortgage-backed securities | 574 |  |  | 5 |  |  | — |  |  | 579 |  |
| Total fixed income securities | 43,305 |  |  | 111 |  |  | (20 | ) |  | 43,396 |  |
| Publicly traded equity securities | 1,314 |  |  | 648 |  |  | (10 | ) |  | 1,952 |  |
| Total | $ | 44,619 |  |  | $ | 759 |  |  | $ | (30 | ) |  | $ | 45,348 |  |
  (was, 2014-05-22, similarity 0.6183):
[0000858877-14-000014:note_history:66]
| April 26, 2014 | Amortized Cost |  | Gross Unrealized Gains |  | Gross Unrealized Losses |  | Fair Value |
| Fixed income securities: |  |  |  |  |  |  |  |
| U.S. government securities | $ | 31,675 |  |  | $ | 34 |  |  | $ | (6 | ) |  | $ | 31,703 |  |
| U.S. government agency securities | 1,060 |  |  | 2 |  |  | (1 | ) |  | 1,061 |  |
| Non-U.S. government and agency securities | 819 |  |  | 2 |  |  | (1 | ) |  | 820 |  |
| Corporate debt securities | 8,050 |  |  | 75 |  |  | (10 | ) |  | 8,115 |  |
| U.S. agency mortgage-backed securities | 567 |  |  | 3 |  |  | — |  |  | 570 |  |
| Total fixed income securities | 42,171 |  |  | 116 |  |  | (18 | ) |  | 42,269 |  |
| Publicly traded equity securities | 1,314 |  |  | 652 |  |  | (7 | ) |  | 1,959 |  |
| Total | $ | 43,485 |  |  | $ | 768 |  |  | $ | (25 | ) |  | $ | 44,228 |  |

- added (2014-11-20):
[0000858877-14-000043:note_history:67]
|  | Three Months Ended |
|  | October 25, 2014 |  | October 26, 2013 |
| Gross realized gains | $ | 21 |  |  | $ | 95 |  |
| Gross realized losses | (14 | ) |  | (12 | ) |
| Total | $ | 7 |  |  | $ | 83 |  |

- changed (2014-11-20):
[0000858877-14-000043:note_history:68]
The following table presents the realized net gains (losses) related to the Company’s available-for-sale investments by security type (in millions):
  (was, 2014-05-22, similarity 0.9686):
[0000858877-14-000014:note_history:68]
The following table presents the realized net gains related to the Company’s available-for-sale investments by security type (in millions):

- changed (2014-11-20):
[0000858877-14-000043:note_history:69]
|  | Three Months Ended |
|  | October 25, 2014 |  | October 26, 2013 |
| Net gains (losses) on investments in publicly traded equity securities | $ | (4 | ) |  | $ | 75 |  |
| Net gains on investments in fixed income securities | 11 |  |  | 8 |  |
| Total | $ | 7 |  |  | $ | 83 |  |
  (was, 2014-05-22, similarity 0.654):
[0000858877-14-000014:note_history:69]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 26, 2014 |  | April 27, 2013 |  | April 26, 2014 |  | April 27, 2013 |
| Net gains (losses) on investments in publicly traded equity securities | $ | 55 |  |  | $ | (2 | ) |  | $ | 199 |  |  | $ | 12 |  |
| Net gains on investments in fixed income securities | 14 |  |  | 8 |  |  | 35 |  |  | 34 |  |
| Total | $ | 69 |  |  | $ | 6 |  |  | $ | 234 |  |  | $ | 46 |  |

- added (2014-11-20):
[0000858877-14-000043:note_history:70]
There were no impairment charges on available-for-sale investments for the periods presented.

- changed (2014-11-20):
[0000858877-14-000043:note_history:71]
The following tables present the breakdown of the available-for-sale investments with gross unrealized losses and the duration that those losses had been unrealized at October 25, 2014 and July 26, 2014 (in millions):
  (was, 2014-05-22, similarity 0.9709):
[0000858877-14-000014:note_history:71]
The following tables present the breakdown of the available-for-sale investments with gross unrealized losses and the duration that those losses had been unrealized at April 26, 2014 and July 27, 2013 (in millions):

- added (2014-11-20):
[0000858877-14-000043:note_history:72]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| October 25, 2014 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| Fixed income securities: |  |  |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | $ | 2,491 |  |  | $ | (8 | ) |  | $ | 383 |  |  | $ | (2 | ) |  | $ | 2,874 |  |  | $ | (10 | ) |
| Total fixed income securities | 2,491 |  |  | (8 | ) |  | 383 |  |  | (2 | ) |  | 2,874 |  |  | (10 | ) |
| Publicly traded equity securities | 131 |  |  | (11 | ) |  | 1 |  |  | — |  |  | 132 |  |  | (11 | ) |
| Total | $ | 2,622 |  |  | $ | (19 | ) |  | $ | 384 |  |  | $ | (2 | ) |  | $ | 3,006 |  |  | $ | (21 | ) |

- changed (2014-11-20):
[0000858877-14-000043:note_history:73]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 26, 2014 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| Fixed income securities: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | $ | 7,676 |  |  | $ | (12 | ) |  | $ | 45 |  |  | $ | — |  |  | $ | 7,721 |  |  | $ | (12 | ) |
| Non-U.S. government and agency securities | 361 |  |  | (1 | ) |  | 22 |  |  | — |  |  | 383 |  |  | (1 | ) |
| Corporate debt securities | 1,875 |  |  | (3 | ) |  | 491 |  |  | (4 | ) |  | 2,366 |  |  | (7 | ) |
| Total fixed income securities | 9,912 |  |  | (16 | ) |  | 558 |  |  | (4 | ) |  | 10,470 |  |  | (20 | ) |
| Publicly traded equity securities | 132 |  |  | (10 | ) |  | — |  |  | — |  |  | 132 |  |  | (10 | ) |
| Total | $ | 10,044 |  |  | $ | (26 | ) |  | $ | 558 |  |  | $ | (4 | ) |  | $ | 10,602 |  |  | $ | (30 | ) |
  (was, 2014-05-22, similarity 0.8586):
[0000858877-14-000014:note_history:73]
|  | UNREALIZED LOSSES LESS THAN 12 MONTHS |  | UNREALIZED LOSSES 12 MONTHS OR GREATER |  | TOTAL |
| July 27, 2013 | Fair Value |  | Gross Unrealized Losses |  | Fair Value |  | Gross Unrealized Losses |  | Fair Value |  | Gross Unrealized Losses |
| Fixed income securities: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | $ | 7,865 |  |  | $ | (13 | ) |  | $ | — |  |  | $ | — |  |  | $ | 7,865 |  |  | $ | (13 | ) |
| U.S. government agency securities | 294 |  |  | (1 | ) |  | — |  |  | — |  |  | 294 |  |  | (1 | ) |
| Non-U.S. government and agency securities | 432 |  |  | (2 | ) |  | — |  |  | — |  |  | 432 |  |  | (2 | ) |
| Corporate debt securities | 3,704 |  |  | (50 | ) |  | 4 |  |  | — |  |  | 3,708 |  |  | (50 | ) |
| Total fixed income securities | 12,295 |  |  | (66 | ) |  | 4 |  |  | — |  |  | 12,299 |  |  | (66 | ) |
| Publicly traded equity securities | 278 |  |  | (4 | ) |  | — |  |  | — |  |  | 278 |  |  | (4 | ) |
| Total | $ | 12,573 |  |  | $ | (70 | ) |  | $ | 4 |  |  | $ | — |  |  | $ | 12,577 |  |  | $ | (70 | ) |

- changed (2014-11-20):
[0000858877-14-000043:note_history:74]
As of October 25, 2014, for fixed income securities that were in unrealized loss positions, the Company has determined that (i) it does not have the intent to sell any of these investments, and (ii) it is not more likely than not that it will be required to sell any of these investments before recovery of the entire amortized cost basis. In addition, as of October 25, 2014, the Company anticipates that it will recover the entire amortized cost basis of such fixed income securities and has determined that no other-than-temporary impairments associated with credit losses were required to be recognized during the three months ended October 25, 2014.
  (was, 2014-05-22, similarity 0.9423):
[0000858877-14-000014:note_history:74]
As of April 26, 2014, for fixed income securities that were in unrealized loss positions, the Company has determined that (i) it does not have the intent to sell any of these investments, and (ii) it is not more likely than not that it will be required to sell any of these investments before recovery of the entire amortized cost basis. In addition, as of April 26, 2014, the Company anticipates that it will recover the entire amortized cost basis of such fixed income securities and has determined that no other-than-temporary impairments associated with credit losses were required to be recognized during the nine months ended April 26, 2014.

- added (2014-11-20):
[0000858877-14-000043:note_history:75]
The Company has evaluated its publicly traded equity securities as of October 25, 2014 and has determined that there was no indication of other-than-temporary impairments in the respective categories of unrealized losses. This determination was based on several factors, which include the length of time and extent to which fair value has been less than the cost basis, the financial condition and near-term prospects of the issuer, and the Company’s intent and ability to hold the publicly traded equity securities for a period of time sufficient to allow for any anticipated recovery in market value.

- changed (2014-11-20):
[0000858877-14-000043:note_history:76]
The following table summarizes the maturities of the Company’s fixed income securities at October 25, 2014 (in millions):
  (was, 2014-05-22, similarity 0.9565):
[0000858877-14-000014:note_history:76]
The following table summarizes the maturities of the Company’s fixed income securities at April 26, 2014 (in millions):

- changed (2014-11-20):
[0000858877-14-000043:note_history:77]
Actual maturities may differ from the contractual maturities because borrowers may have the right to call or prepay certain obligations.  The remaining contractual principal maturities for mortgage-backed securities were allocated assuming no prepayments.
  (was, 2014-05-22, similarity 0.6974):
[0000858877-14-000014:note_history:77]
Actual maturities may differ from the contractual maturities because borrowers may have the right to call or prepay certain obligations.

- changed (2014-11-20):
[0000858877-14-000043:note_history:78]
The Company periodically engages in securities lending activities with certain of its available-for-sale investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. The average daily balance of securities lending for the three months ended October 25, 2014 and October 26, 2013 was $1.0 billion and $0.6 billion, respectively. The Company requires collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. The Company engages in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify the Company against collateral losses. The Company did not experience any losses in connection with the secured lending of securities during the periods presented. As of October 25, 2014 and July 26, 2014, the Company had no outstanding securities lending transactions.
  (was, 2014-05-22, similarity 0.9788):
[0000858877-14-000014:note_history:78]
The Company periodically engages in securities lending activities with certain of its available-for-sale investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. The average daily balance of securities lending for the nine months ended April 26, 2014 and April 27, 2013 was $1.4 billion and $0.7 billion, respectively. The Company requires collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. The Company engages in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify the Company against collateral losses. The Company did not experience any losses in connection with the secured lending of securities during the periods presented. As of April 26, 2014 and July 27, 2013, the Company had no outstanding securities lending transactions.

- added (2014-11-20):
[0000858877-14-000043:note_history:79]
| (e) | Investments in Privately Held Companies |

- added (2014-11-20):
[0000858877-14-000043:note_history:80]
The carrying value of the Company’s investments in privately held companies was included in other assets. For such investments that were accounted for under the equity and cost method as of October 25, 2014 and July 26, 2014, the amounts are summarized in the following table (in millions):

- added (2014-11-20):
[0000858877-14-000043:note_history:81]
|  | October 25, 2014 |  | July 26, 2014 |
| Equity method investments | $ | 559 |  |  | $ | 630 |  |
| Cost method investments | 327 |  |  | 269 |  |
| Total | $ | 886 |  |  | $ | 899 |  |

- added (2014-11-20):
[0000858877-14-000043:note_history:82]
Variable Interest Entities

- added (2014-11-20):
[0000858877-14-000043:note_history:83]
VCE Joint Venture   VCE is a joint venture that the Company formed in fiscal 2010 with EMC Corporation (“EMC”), with investments from VMware, Inc. (“VMware”) and Intel Capital Corporation ("Intel"). VCE helps organizations leverage best-in-class technologies and disciplines from Cisco, EMC, and VMware to enable the transformation to cloud computing.

- added (2014-11-20):
[0000858877-14-000043:note_history:84]
As of October 25, 2014, the Company’s cumulative gross investment in VCE was approximately $716 million, inclusive of accrued interest on convertible notes, and its ownership percentage was approximately 35%.  The Company did not make any investments in VCE during the three months ended October 25, 2014.  As of October 25, 2014, the Company had recorded cumulative losses from VCE under the equity method of $691 million since inception, of which losses of $47 million and $53 million were recorded for the three months ended October 25, 2014 and October 26, 2013, respectively.  The Company’s carrying value in VCE as of October 25, 2014 was $25 million.

- added (2014-11-20):
[0000858877-14-000043:note_history:85]
EMC and the Company have entered into guarantee agreements on behalf of VCE to indemnify certain customers (the "Guarantees") for monetary damages. Such Guarantees were not material as of October 25, 2014.

- added (2014-11-20):
[0000858877-14-000043:note_history:86]
In October 2014, the Company, EMC, VMware, and Intel agreed to restructure the VCE joint venture.  Under the terms of the agreement, VCE will undergo a reorganization and recapitalization whereby VCE will pay approximately $150 million to the Company for a portion of the outstanding principal balance of the convertible notes and accrued interest on such notes.  The Company also agreed to cancel the remaining principal balance of the convertible notes held by it and the accrued interest on such notes, and to have VCE redeem a portion of the Company’s equity interest in VCE.   EMC also agreed to indemnify the Company for any liabilities incurred by the Company under the Guarantees.  Following this reorganization and recapitalization, the Company’s ownership interest in VCE will be approximately 10%.  The transaction is expected to close in the second quarter of the Company's fiscal year 2015, subject to customary regulatory approvals.

- added (2014-11-20):
[0000858877-14-000043:note_history:87]
Other Variable Interest Entities    In the ordinary course of business, the Company has investments in other privately held companies and provides financing to certain customers. These other privately held companies and customers may be considered to be variable interest entities. The Company evaluates on an ongoing basis its investments in these other privately held companies and its customer financings, and has determined that as of October 25, 2014 there were no other variable interest entities required to be consolidated in the Company’s Consolidated Financial Statements.

- removed (2014-11-20):
[0000858877-14-000014:note_history:88]
| July 27, 2013 | Amortized Cost |  | Gross Unrealized Gains |  | Gross Unrealized Losses |  | Fair Value |
| Fixed income securities: |  |  |  |  |  |  |  |
| U.S. government securities | $ | 27,814 |  |  | $ | 22 |  |  | $ | (13 | ) |  | $ | 27,823 |  |
| U.S. government agency securities | 3,083 |  |  | 7 |  |  | (1 | ) |  | 3,089 |  |
| Non-U.S. government and agency securities | 1,094 |  |  | 3 |  |  | (2 | ) |  | 1,095 |  |
| Corporate debt securities | 7,876 |  |  | 55 |  |  | (50 | ) |  | 7,881 |  |
| Total fixed income securities | 39,867 |  |  | 87 |  |  | (66 | ) |  | 39,888 |  |
| Publicly traded equity securities | 2,063 |  |  | 738 |  |  | (4 | ) |  | 2,797 |  |
| Total | $ | 41,930 |  |  | $ | 825 |  |  | $ | (70 | ) |  | $ | 42,685 |  |

- removed (2014-11-20):
[0000858877-14-000014:note_history:89]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 26, 2014 |  | April 27, 2013 |  | April 26, 2014 |  | April 27, 2013 |
| Gross realized gains | $ | 75 |  |  | $ | 55 |  |  | $ | 267 |  |  | $ | 175 |  |
| Gross realized losses | (6 | ) |  | (49 | ) |  | (33 | ) |  | (129 | ) |
| Total | $ | 69 |  |  | $ | 6 |  |  | $ | 234 |  |  | $ | 46 |  |

- removed (2014-11-20):
[0000858877-14-000014:note_history:90]
There were no impairment charges for the three months ended April 26, 2014.  For the nine months ended April 26, 2014, the realized net gains related to the Company's available-for-sale investments included impairment charges of $11 million.  These impairment charges related to publicly traded equity securities and were due to a decline in the fair value of those securities below their cost basis that were determined to be other than temporary. There were no impairment charges on available-for-sale investments for the corresponding periods in fiscal 2013.

- removed (2014-11-20):
[0000858877-14-000014:note_history:91]
|  | UNREALIZED LOSSES LESS THAN 12 MONTHS |  | UNREALIZED LOSSES 12 MONTHS OR GREATER |  | TOTAL |
| April 26, 2014 | Fair Value |  | Gross Unrealized Losses |  | Fair Value |  | Gross Unrealized Losses |  | Fair Value |  | Gross Unrealized Losses |
| Fixed income securities: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | $ | 5,111 |  |  | $ | (6 | ) |  | $ | 8 |  |  | $ | — |  |  | $ | 5,119 |  |  | $ | (6 | ) |
| U.S. government agency securities | 396 |  |  | (1 | ) |  | 3 |  |  | — |  |  | 399 |  |  | (1 | ) |
| Non-U.S. government and agency securities | 378 |  |  | (1 | ) |  | — |  |  | — |  |  | 378 |  |  | (1 | ) |
| Corporate debt securities | 1,654 |  |  | (10 | ) |  | 52 |  |  | — |  |  | 1,706 |  |  | (10 | ) |
| U.S. agency mortgage-backed securities | 158 |  |  | — |  |  | — |  |  | — |  |  | 158 |  |  | — |  |
| Total fixed income securities | 7,697 |  |  | (18 | ) |  | 63 |  |  | — |  |  | 7,760 |  |  | (18 | ) |
| Publicly traded equity securities | 117 |  |  | (7 | ) |  | — |  |  | — |  |  | 117 |  |  | (7 | ) |
| Total | $ | 7,814 |  |  | $ | (25 | ) |  | $ | 63 |  |  | $ | — |  |  | $ | 7,877 |  |  | $ | (25 | ) |

- removed (2014-11-20):
[0000858877-14-000014:note_history:92]
The Company has evaluated its publicly traded equity securities as of April 26, 2014 and has determined that there was no indication of other-than-temporary impairments in the respective categories of unrealized losses. This determination was based on several factors, which include the length of time and extent to which fair value has been less than the cost basis, the financial condition and near-term prospects of the issuer, and the Company’s intent and ability to hold the publicly traded equity securities for a period of time sufficient to allow for any anticipated recovery in market value.


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-11-20):
[0000858877-14-000043:note_history:93]
|  |  |  | October 25, 2014 |  | July 26, 2014 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.05% | September 3, 2015 |  | $ | 850 |  |  | 0.36% |  | $ | 850 |  |  | 0.35% |
| Three-month LIBOR plus 0.28% | March 3, 2017 |  | 1,000 |  |  | 0.57% |  | 1,000 |  |  | 0.56% |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | 500 |  |  | 0.79% |  | 500 |  |  | 0.78% |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 2.90% | November 17, 2014 |  | 500 |  |  | 3.11% |  | 500 |  |  | 3.11% |
| 5.50% | February 22, 2016 |  | 3,000 |  |  | 3.05% |  | 3,000 |  |  | 3.04% |
| 1.10% | March 3, 2017 |  | 2,400 |  |  | 0.55% |  | 2,400 |  |  | 0.56% |
| 3.15% | March 14, 2017 |  | 750 |  |  | 0.80% |  | 750 |  |  | 0.79% |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 4.69% |  | 2,000 |  |  | 4.69% |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 0.77% |  | 1,750 |  |  | 0.77% |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 2.98% |  | 2,500 |  |  | 2.98% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 0.93% |  | 500 |  |  | 0.93% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1.04% |  | 1,000 |  |  | 1.05% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Other long-term debt |  |  | 2 |  |  | 2.08% |  | 4 |  |  | 2.39% |
| Total |  |  | 20,752 |  |  |  |  | 20,754 |  |  |  |
| Unaccreted discount |  |  | (62 | ) |  |  |  | (63 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 275 |  |  |  |  | 210 |  |  |  |
| Total |  |  | $ | 20,965 |  |  |  |  | $ | 20,901 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 1,350 |  |  |  |  | $ | 500 |  |  |  |
| Long-term debt |  |  | 19,615 |  |  |  |  | 20,401 |  |  |  |
| Total |  |  | $ | 20,965 |  |  |  |  | $ | 20,901 |  |  |  |
  (was, 2014-05-22, similarity 0.8258):
[0000858877-14-000014:note_history:93]
|  |  |  | April 26, 2014 |  | July 27, 2013 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.25% | March 14, 2014 |  | $ | — |  |  | — |  | $ | 1,250 |  |  | 0.62% |
| Three-month LIBOR plus 0.05% | September 3, 2015 | (1) | 850 |  |  | 0.38% |  | — |  |  | — |
| Three-month LIBOR plus 0.28% | March 3, 2017 | (1) | 1,000 |  |  | 0.58% |  | — |  |  | — |
| Three-month LIBOR plus 0.50% | March 1, 2019 | (1) | 500 |  |  | 0.79% |  | — |  |  | — |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 1.625% | March 14, 2014 |  | — |  |  | — |  | 2,000 |  |  | 0.64% |
| 2.90% | November 17, 2014 |  | 500 |  |  | 3.11% |  | 500 |  |  | 3.11% |
| 5.50% | February 22, 2016 |  | 3,000 |  |  | 3.05% |  | 3,000 |  |  | 3.07% |
| 1.10% | March 3, 2017 | (1) | 2,400 |  |  | 0.56% |  | — |  |  | — |
| 3.15% | March 14, 2017 |  | 750 |  |  | 0.80% |  | 750 |  |  | 0.84% |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 4.69% |  | 2,000 |  |  | 4.70% |
| 2.125% | March 1, 2019 | (1) | 1,750 |  |  | 0.77% |  | — |  |  | — |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 2.98% |  | 2,500 |  |  | 4.15% |
| 2.90% | March 4, 2021 | (1) | 500 |  |  | 0.93% |  | — |  |  | — |
| 3.625% | March 3, 2024 | (1) | 1,000 |  |  | 1.05% |  | — |  |  | — |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Other long-term debt |  |  | 6 |  |  | 2.52% |  | 21 |  |  | 1.46% |
| Total |  |  | 20,756 |  |  |  |  | 16,021 |  |  |  |
| Unaccreted discount |  |  | (65 | ) |  |  |  | (65 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 193 |  |  |  |  | 245 |  |  |  |
| Total |  |  | $ | 20,884 |  |  |  |  | $ | 16,201 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 500 |  |  |  |  | $ | 3,273 |  |  |  |
| Long-term debt |  |  | 20,384 |  |  |  |  | 12,928 |  |  |  |
| Total |  |  | $ | 20,884 |  |  |  |  | $ | 16,201 |  |  |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-11-20):
[0000858877-14-000043:note_history:94]
As of October 25, 2014, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):
  (was, 2014-05-22, similarity 0.9627):
[0000858877-14-000014:note_history:94]
As of April 26, 2014, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

- changed (2014-11-20):
[0000858877-14-000043:note_history:95]
| Fiscal Year | Amount |
| 2015 (remaining nine months) | $ | 500 |  |
| 2016 | 3,851 |  |
| 2017 | 4,151 |  |
| 2018 | — |  |
| 2019 | 4,250 |  |
| Thereafter | 8,000 |  |
| Total | $ | 20,752 |  |
  (was, 2014-05-22, similarity 0.899):
[0000858877-14-000014:note_history:95]
| Fiscal Year | Amount |
| 2014 (remaining three months) | $ | — |  |
| 2015 | 502 |  |
| 2016 | 3,853 |  |
| 2017 | 4,151 |  |
| 2018 | — |  |
| Thereafter | 12,250 |  |
| Total | $ | 20,756 |  |


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-11-20):
[0000858877-14-000043:note_history:96]
|  | October 25, 2014 |  | July 26, 2014 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 1,350 |  |  | 1.38 | % |  | $ | 500 |  |  | 3.11 | % |
| Other short-term debt | 7 |  |  | 2.76 | % |  | 8 |  |  | 2.67 | % |
| Total short-term debt | $ | 1,357 |  |  |  |  | $ | 508 |  |  |  |
  (was, 2014-05-22, similarity 0.6632):
[0000858877-14-000014:note_history:96]
|  | April 26, 2014 |  | July 27, 2013 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 500 |  |  | 3.11 | % |  | $ | 3,273 |  |  | 0.63 | % |
| Other notes and borrowings | 8 |  |  | 2.60 | % |  | 10 |  |  | 2.52 | % |
| Total short-term debt | $ | 508 |  |  |  |  | $ | 3,283 |  |  |  |
