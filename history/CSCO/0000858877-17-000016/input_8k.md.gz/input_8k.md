# CSCO 8-K — 0001193125-17-259825 filed 2017-08-16

## item codes, every 8-K on or before 2017-09-07

- 2017-09-01 0001193125-17-275671 — 8.01
- 2017-08-16 0001193125-17-259825 — 2.02
- 2017-06-23 0001193125-17-211825 — 8.01
- 2017-06-15 0001193125-17-204753 — 8.01
- 2017-05-17 0001193125-17-173404 — 2.02
- 2017-03-31 0001193125-17-106620 — 1.01, 2.03, 9.01
- 2017-03-29 0001193125-17-101783 — 8.01
- 2017-03-13 0001193125-17-080485 — 5.02
- 2017-02-15 0001193125-17-045265 — 2.02
- 2016-12-22 0001193125-16-802182 — 8.01
- 2016-12-13 0001193125-16-791877 — 5.07
- 2016-11-16 0001193125-16-769785 — 2.02
- 2016-11-03 0001193125-16-758911 — 5.02, 9.01
- 2016-10-17 0001193125-16-739833 — 5.02
- 2016-09-21 0001193125-16-716006 — 8.01
- 2016-09-20 0001193125-16-714189 — 8.01, 9.01
- 2016-09-16 0001193125-16-712320 — 8.01
- 2016-09-15 0001193125-16-711098 — 1.01, 9.01
- 2016-09-13 0001193125-16-708007 — 8.01, 9.01
- 2016-09-06 0001193125-16-702020 — 8.01
- 2016-08-17 0001193125-16-684126 — 2.02, 2.05
- 2016-07-29 0001193125-16-664620 — 5.03, 9.01
- 2016-06-27 0001193125-16-633145 — 8.01
- 2016-06-23 0001193125-16-630146 — 8.01
- 2016-06-07 0001193125-16-615321 — 5.02, 9.01
- 2016-05-18 0001193125-16-594463 — 2.02
- 2016-03-24 0001193125-16-516953 — 8.01
- 2016-02-29 0001193125-16-483780 — 8.01, 9.01
- 2016-02-25 0001193125-16-478442 — 8.01
- 2016-02-24 0001193125-16-474071 — 1.01, 9.01
- 2016-02-22 0001193125-16-470856 — 8.01, 9.01
- 2016-02-10 0001193125-16-457586 — 2.02
- 2016-01-28 0001193125-16-441933 — 5.02
- 2015-12-08 0001193125-15-397797 — 8.01
- 2015-11-20 0001193125-15-383743 — 5.07
- 2015-11-12 0001193125-15-375655 — 2.02
- 2015-09-21 0001193125-15-324465 — 8.01
- 2015-09-17 0001193125-15-322456 — 8.01
- 2015-09-14 0001193125-15-319489 — 8.01
- 2015-08-28 0001193125-15-306843 — 8.01
- 2015-08-12 0001193125-15-288099 — 2.02
- 2015-07-29 0001193125-15-268359 — 5.02 — amendment of 0001193125-15-169227
- 2015-06-18 0001193125-15-227387 — 8.01, 9.01
- 2015-06-12 0001193125-15-221863 — 1.01, 9.01
- 2015-06-10 0001193125-15-218734 — 8.01, 9.01
- 2015-06-01 0001193125-15-209142 — 5.02, 9.01
- 2015-05-13 0001193125-15-185905 — 2.02
- 2015-05-04 0001193125-15-169227 — 5.02
- 2015-03-24 0001193125-15-103369 — 8.01
- 2015-03-19 0001193125-15-098638 — 8.01
- 2015-02-11 0001193125-15-044175 — 2.02
- 2014-12-19 0001193125-14-448754 — 8.01
- 2014-12-18 0001193125-14-447039 — 8.01
- 2014-11-24 0001193125-14-423591 — 5.02, 5.07, 9.01
- 2014-11-14 0001193125-14-413384 — 5.02
- 2014-11-12 0001193125-14-409258 — 2.02
- 2014-09-25 0001193125-14-353210 — 8.01
- 2014-09-12 0001193125-14-340480 — 5.02
- 2014-08-14 0001193125-14-308733 — 2.05
- 2014-08-13 0001193125-14-308403 — 2.02
- 2014-07-31 0001193125-14-289683 — 5.02
- 2014-06-25 0001193125-14-249157 — 8.01
- 2014-05-14 0001193125-14-199056 — 2.02
- 2014-03-26 0001193125-14-116588 — 8.01
- 2014-03-11 0001193125-14-093805 — 8.01
- 2014-03-03 0001193125-14-079163 — 1.01, 8.01, 9.01
- 2014-02-26 0001193125-14-069912 — 1.01, 9.01
- 2014-02-12 0001193125-14-048150 — 2.02
- 2013-12-23 0001193125-13-483099 — 8.01
- 2013-12-04 0001193125-13-462216 — 8.01
- 2013-11-20 0001193125-13-448477 — 5.02, 5.07, 9.01
- 2013-11-13 0001193125-13-440194 — 2.02
- 2013-08-15 0001193125-13-335218 — 2.05
- 2013-08-14 0001193125-13-334648 — 2.02
- 2013-07-23 0001193125-13-298129 — 8.01, 9.01
- 2013-06-24 0001193125-13-269064 — 8.01
- 2013-06-12 0001193125-13-256194 — 8.01
- 2013-06-07 0001193125-13-250920 — 8.01
- 2013-05-15 0001193125-13-222377 — 2.02
- 2013-03-26 0001193125-13-127015 — 8.01
- 2013-02-13 0001193125-13-055377 — 2.02
- 2013-02-01 0001193125-13-034682 — 5.02
- 2013-01-08 0001193125-13-006886 — 5.02, 9.01
- 2012-12-21 0001193125-12-513130 — 8.01
- 2012-12-19 0001193125-12-508424 — 8.01
- 2012-11-16 0001193125-12-474089 — 5.02, 5.07, 9.01
- 2012-11-13 0001193125-12-467422 — 2.02
- 2012-10-04 0001193125-12-415386 — 5.02, 5.03, 9.01
- 2012-09-19 0001193125-12-396875 — 5.02, 8.01
- 2012-08-15 0001193125-12-357479 — 2.02
- 2012-08-02 0001193125-12-332045 — 5.02
- 2012-06-27 0001193125-12-285742 — 8.01
- 2012-06-13 0001193125-12-269642 — 8.01
- 2012-05-09 0001193125-12-222045 — 2.02
- 2012-03-27 0001193125-12-134384 — 8.01
- 2012-03-15 0001193125-12-117538 — 8.01, 9.01
- 2012-02-17 0001193125-12-067542 — 1.01, 1.02, 2.03, 9.01
- 2012-02-08 0001193125-12-046545 — 2.02
- 2011-12-16 0001193125-11-343995 — 8.01
- 2011-12-08 0001193125-11-335127 — 5.02, 5.07, 9.01
- 2011-11-09 0001193125-11-304587 — 2.02
- 2011-09-29 0001193125-11-260065 — 8.01
- 2011-09-20 0001193125-11-252379 — 5.02, 9.01
- 2011-08-24 0001193125-11-231015 — 8.01
- 2011-08-10 0001193125-11-218133 — 2.02
- 2011-07-18 0001193125-11-190246 — 2.05
- 2011-06-22 0001193125-11-170849 — 8.01
- 2011-05-11 0001193125-11-135913 — 2.02
- 2011-03-28 0001193125-11-079927 — 8.01
- 2011-03-22 0001193125-11-073802 — 5.02 — amendment of 0001193125-11-043592
- 2011-03-18 0001193125-11-071279 — 8.01, 9.01
- 2011-03-16 0001193125-11-067985 — 1.01, 5.02, 8.01, 9.01
- 2011-03-15 0001193125-11-067331 — 1.01, 9.01
- 2011-03-09 0001193125-11-060123 — 8.01, 9.01
- 2011-02-23 0001193125-11-043592 — 5.02
- 2011-02-09 0001193125-11-028987 — 2.02
- 2011-01-31 0001193125-11-019101 — 1.01, 2.03
- 2010-12-17 0001193125-10-283392 — 8.01
- 2010-11-19 0001193125-10-265377 — 5.07
- 2010-11-10 0001193125-10-256001 — 2.02
- 2010-09-22 0001193125-10-214707 — 8.01
- 2010-09-16 0001193125-10-211456 — 7.01
- 2010-08-11 0001193125-10-186042 — 2.02
- 2010-06-29 0001193125-10-149956 — 8.01
- 2010-05-12 0001193125-10-117509 — 2.02
- 2010-02-17 0001193125-10-033290 — 5.02, 8.01, 9.01
- 2010-02-03 0001193125-10-020775 — 2.02
- 2009-11-25 0001193125-09-242589 — 8.01
- 2009-11-17 0001193125-09-236335 — 1.01, 8.01, 9.01
- 2009-11-13 0001193125-09-234405 — 1.01, 2.03, 9.01
- 2009-11-13 0001193125-09-234397 — 5.02 — amendment of 0001193125-09-189511
- 2009-11-12 0001193125-09-232971 — 5.02, 7.01, 9.01
- 2009-11-09 0001193125-09-228541 — 8.01, 9.01
- 2009-11-04 0001193125-09-223763 — 2.02
- 2009-10-14 0001193125-09-207912 — 8.01, 9.01
- 2009-10-05 0001193125-09-203556 — 8.01
- 2009-09-10 0001193125-09-189511 — 5.02
- 2009-09-04 0001193125-09-187835 — 5.02
- 2009-08-05 0001193125-09-165404 — 2.02
- 2009-07-27 0001193125-09-155861 — 5.02
- 2009-05-29 0001193125-09-121672 — 8.01
- 2009-05-06 0001193125-09-101570 — 2.02
- 2009-02-26 0001193125-09-038162 — 5.02
- 2009-02-17 0001193125-09-030546 — 1.01, 8.01, 9.01
- 2009-02-13 0001193125-09-029295 — 1.01, 2.03, 9.01
- 2009-02-04 0001193125-09-018793 — 2.02
- 2008-11-05 0001193125-08-225857 — 2.02
- 2008-09-11 0001193125-08-194695 — 7.01
- 2008-08-05 0001193125-08-166496 — 2.02
- 2008-06-20 0001193125-08-137504 — 8.01
- 2008-05-06 0001193125-08-104089 — 2.02
- 2008-03-21 0001193125-08-062838 — 8.01
- 2008-02-06 0001193125-08-021681 — 2.02
- 2008-01-23 0001193125-08-010589 — 5.02
- 2008-01-04 0001193125-08-001680 — 5.02, 9.01
- 2007-12-21 0001193125-07-269613 — 5.02
- 2007-11-19 0001193125-07-250345 — 5.02 — amendment of 0001193125-07-009285
- 2007-11-19 0001193125-07-250343 — 5.02, 9.01
- 2007-11-07 0001193125-07-238464 — 2.02
- 2007-09-24 0001193125-07-206279 — 8.01
- 2007-09-20 0001193125-07-204616 — 5.02, 7.01
- 2007-09-07 0001193125-07-197514 — 8.01
- 2007-08-17 0001193125-07-185320 — 1.01, 2.03, 9.01
- 2007-08-08 0001193125-07-174077 — 5.02
- 2007-08-07 0001193125-07-173689 — 2.02
- 2007-08-01 0001193125-07-168143 — 5.02
- 2007-05-15 0001193125-07-115800 — 8.01
- 2007-05-08 0001193125-07-106059 — 2.02
- 2007-03-23 0001193125-07-063033 — 5.02, 5.03, 8.01, 9.01
- 2007-03-21 0001193125-07-060631 — 1.01, 9.01
- 2007-02-06 0001193125-07-021349 — 2.02
- 2007-01-19 0001193125-07-009285 — 5.02
- 2006-12-22 0001193125-06-259241 — 8.01
- 2006-11-16 0001193125-06-237260 — 5.03, 8.01, 9.01
- 2006-11-08 0001193125-06-228341 — 2.02
- 2006-09-21 0001193125-06-194890 — 1.01, 7.01
- 2006-09-20 0001193125-06-194063 — 1.01
- 2006-09-15 0001193125-06-191845 — 5.02
- 2006-08-18 0001193125-06-176193 — 5.02
- 2006-08-08 0001193125-06-165719 — 2.02
- 2006-07-31 0001193125-06-157106 — 1.01, 9.01
- 2006-07-31 0001193125-06-157102 — 5.02 — amendment of 0001193125-06-017426
- 2006-06-08 0001193125-06-126879 — 5.02
- 2006-05-18 0001193125-06-115516 — 8.01
- 2006-05-12 0001193125-06-110924 — 9.01 — amendment of 0001193125-06-044013
- 2006-05-09 0001193125-06-105419 — 2.02
- 2006-03-29 0001193125-06-066990 — 1.01
- 2006-03-02 0001193125-06-044013 — 1.01, 2.01, 9.01
- 2006-02-28 0001193125-06-041452 — 1.01
- 2006-02-22 0001193125-06-036759 — 8.01
- 2006-02-22 0001193125-06-036433 — 1.01, 8.01, 9.01
- 2006-02-21 0001193125-06-035865 — 1.01, 2.03, 9.01
- 2006-02-10 0001193125-06-026218 — 8.01, 9.01
- 2006-02-07 0001193125-06-022234 — 2.02
- 2006-02-01 0001193125-06-017426 — 5.02
- 2005-11-18 0001193125-05-229535 — 1.01, 9.01
- 2005-11-16 0001193125-05-227987 — 1.01, 9.01
- 2005-11-16 0001193125-05-227983 — 5.02 — amendment of 0001193125-05-008843
- 2005-11-09 0001193125-05-221610 — 2.02
- 2005-09-29 0001193125-05-194217 — 7.01
- 2005-09-27 0001193125-05-192353 — 8.01
- 2005-09-21 0001193125-05-189234 — 1.01, 9.01
- 2005-09-19 0001193125-05-187646 — 8.01
- 2005-09-09 0001193125-05-183273 — 8.01
- 2005-09-08 0001193125-05-182307 — 1.01
- 2005-08-09 0001193125-05-162626 — 2.02
- 2005-07-15 0001193125-05-142738 — 8.01
- 2005-05-10 0001193125-05-102797 — 2.02
- 2005-03-30 0001193125-05-065123 — 1.01, 3.03, 9.01
- 2005-03-04 0001193125-05-042778 — 1.01
- 2005-02-08 0001193125-05-022181 — 2.02
- 2005-01-20 0001193125-05-008843 — 5.02
- 2004-12-23 0001193125-04-219331 — 8.01
- 2004-11-09 0001193125-04-191303 — 2.02
- 2004-08-23 0001193125-04-145198 — 1.01, 7.01
- 2004-08-19 0001193125-04-143859 — 5
- 2004-08-10 0001193125-04-136865 — 12
- 2004-05-11 0001193125-04-084721 — 12
- 2004-02-03 0001193125-04-013750 — 12
- 2003-11-05 0001193125-03-073418 — 12
- 2003-09-02 0001193125-03-044521 — 9
- 2003-08-05 0001193125-03-029223 — 12, 7
- 2003-07-18 0001193125-03-021155 — 5, 7
- 2003-06-05 0001012870-03-002949 — 5
- 2003-05-06 0000891618-03-002315 — 7, 9
- 2003-04-17 0000891618-03-001894 — 5, 7
- 2003-04-11 0000891618-03-001791 — 9
- 2003-03-20 0000891618-03-001326 — 5, 7
- 2003-02-04 0000891618-03-000518 — 7, 9
- 2003-01-28 0000891618-03-000271 — 5, 7
- 2002-12-27 0000891618-02-005686 — 5, 7
- 2002-10-23 0000891618-02-004715 — 5, 7
- 2002-10-11 0000891618-02-004620 — 5, 7
- 2002-09-18 0000891618-02-004352 — 5, 7
- 2002-08-20 0000891618-02-004001 — 5, 7
- 2002-08-05 0000891618-02-003498 — 5, 7
- 2002-07-03 0000891618-02-003099 — 5, 7
- 2002-05-14 0000891618-02-002407 — 5, 7
- 2002-02-05 0000891618-02-000412 — 5, 7
- 2001-09-28 0001095811-01-505261 — 5, 7
- 2001-09-14 0001095811-01-504917 — 5, 7
- 2001-08-24 0001095811-01-504581 — 5, 7
- 2001-07-30 0001095811-01-503468 — 5, 7
- 2001-07-12 0000891618-01-501567 — 5, 7
- 2001-05-11 0000891618-01-500638 — 5, 7
- 2001-02-27 0000891618-01-500076 — 5, 7
- 2001-02-20 0001095811-01-001530 — 5, 7
- 2001-02-08 0001095811-01-000848 — 5, 7
- 2001-02-07 0001095811-01-000768 — 5
- 2000-12-27 0001095811-00-005511 — 5
- 2000-12-21 0001095811-00-005427 — 5
- 2000-12-19 0001095811-00-005368 — 5
- 2000-11-15 0001095811-00-004830 — 5
- 2000-11-15 0001095811-00-004824 — 5
- 2000-11-13 0000891618-00-005023 — 5
- 2000-11-07 0001095811-00-004387 — 5, 7
- 2000-11-06 0001095811-00-004318 — 5
- 2000-09-29 0000891618-00-004739 — 5, 7
- 2000-09-28 0000891618-00-004722 — 5
- 2000-09-26 0001095811-00-003573 — 5
- 2000-09-15 0001095811-00-003413 — 5
- 2000-09-07 0001095811-00-003229 — 5
- 2000-08-15 0000891618-00-004430 — 5
- 2000-08-04 0001095811-00-002304 — 5, 7 — amendment, the index does not say of what
- 2000-07-28 0000891618-00-004132 — 5, 7
- 2000-06-29 0000891618-00-003637 — 5
- 2000-06-07 0000891618-00-003209 — 5
- 2000-05-26 0000891618-00-003054 — 5
- 2000-05-18 0000891618-00-002975 — 5, 7
- 2000-05-15 0000891618-00-002808 — 5, 7
- 2000-05-03 0000891618-00-002473 — 5
- 2000-04-03 0000891618-00-001936 — 5
- 2000-03-28 0000891618-00-001763 — 5
- 2000-03-27 0000891618-00-001722 — 5, 7
- 2000-03-16 0000891618-00-001512 — 5
- 2000-02-17 0000891618-00-001024 — 5, 7
- 2000-02-03 0000891618-00-000468 — 7 — amendment of 0000891618-99-005685
- 1999-12-22 0000891618-99-005792 — 5, 7
- 1999-12-15 0000891618-99-005685 — 5, 7
- 1999-11-17 0000891618-99-005313 — 5, 7
- 1999-11-04 0000891618-99-004862 — 5, 7
- 1999-10-20 0000891618-99-004625 — 5, 7
- 1999-09-27 0000891618-99-004333 — 5, 7
- 1999-08-26 0000891618-99-003978 — 5, 7
- 1999-08-13 0000891618-99-003764 — 5, 7 — amendment of 0000891618-99-003749
- 1999-08-13 0000891618-99-003749 — 5, 7
- 1999-07-02 0000891618-99-002980 — 5, 7
- 1999-05-14 0000891618-99-002221 — 5
- 1998-11-20 0000891618-98-005074 — 5, 7
- 1998-11-20 0000891618-98-005073 — 5, 7
- 1998-10-13 0000891618-98-004462 — 5, 7
- 1998-07-09 0000891618-98-003245 — 5, 7
- 1998-06-11 0000891618-98-002832 — 5, 7
- 1998-05-15 0000891618-98-002457 — 5, 7
- 1998-04-29 0000891618-98-001996 — 5
- 1998-02-11 0000891618-98-000584 — 5, 7
- 1997-09-09 0000891618-97-003723 — 5, 7
- 1997-08-22 0000891618-97-003559 — 5, 7
- 1997-07-01 0000891618-97-002807 — 5, 7
- 1997-01-22 0000891618-97-000120 — 5, 7
- 1996-10-15 0000891618-96-002283 — 5, 7 — amendment of 0000891618-96-002217
- 1996-10-01 0000891618-96-002217 — 5, 7
- 1996-07-23 0000891618-96-001305 — 2, 7
- 1996-04-26 0000891618-96-000253 — 2
- 1996-04-02 0000898430-96-001187 — 2, 7
- 1995-12-06 0000891618-95-000728 — 2, 7
- 1995-12-06 0000891618-95-000727 — 2, 7

## late-filing notifications on or before 2017-09-07

- none on or before 2017-09-07

## item 2.02 — earnings release, exhibit 99.1

[0001193125-17-259825:8k_2_02:1]
EX-99.1
2
d440457dex991.htm
EXHIBIT 99.1

[0001193125-17-259825:8k_2_02:2]
Exhibit 99.1

[0001193125-17-259825:8k_2_02:3]
Exhibit 99.1

[0001193125-17-259825:8k_2_02:4]
| Press Contact: |  |  |  | Investor Relations Contact: |
| Andrea Duffy |  |  |  | Marilyn Mora |
| Cisco |  |  |  | Cisco |
| 1 (646) 295-5241 |  |  |  | 1 (408) 527-7452 |
| anduffy@cisco.com |  |  |  | marilmor@cisco.com |

[0001193125-17-259825:8k_2_02:5]
CISCO REPORTS FOURTH QUARTER AND FISCAL YEAR 2017 EARNINGS

[0001193125-17-259825:8k_2_02:6]
|  | • |  | Q4 Revenue: $12.1 billion |

[0001193125-17-259825:8k_2_02:7]
|  | • |  | Decrease of (4)% year over year |

[0001193125-17-259825:8k_2_02:8]
|  | • |  | Recurring revenue was 31% of total revenue, up 4 pts year over year |

[0001193125-17-259825:8k_2_02:9]
|  | • |  | Q4 Earnings per Share: $0.48 GAAP; $0.61 non-GAAP |

[0001193125-17-259825:8k_2_02:10]
|  | • |  | FY 2017 Earnings per Share: $1.90 GAAP; $2.39 non-GAAP |

[0001193125-17-259825:8k_2_02:11]
|  | • |  | Q1 FY 2018 Outlook: |

[0001193125-17-259825:8k_2_02:12]
|  | • |  | Revenue: (3)% to (1)% decline year over year |

[0001193125-17-259825:8k_2_02:13]
|  | • |  | Earnings per Share: GAAP: $0.48 to $0.53; Non-GAAP: $0.59 to $0.61 |

[0001193125-17-259825:8k_2_02:14]
SAN JOSE, Calif. — August 16, 2017 — Cisco today reported fourth quarter and fiscal year results for the period ended July 29, 2017. Cisco
reported fourth quarter revenue of $12.1 billion, net income on a generally accepted accounting principles (GAAP) basis of $2.4 billion or $0.48 per share, and non-GAAP net income of
$3.1 billion or $0.61 per share.

[0001193125-17-259825:8k_2_02:15]
“We had another strong quarter and a transformative year. We made tremendous progress transitioning our
business to more software and recurring revenue and delivered on our commitment to accelerate innovation in our core and across the portfolio,” said Chuck Robbins, CEO, Cisco. “The network has never been more critical to business success
and we are building the network of the future.”

[0001193125-17-259825:8k_2_02:16]
Q4 GAAP Results

[0001193125-17-259825:8k_2_02:17]
|  |  | Q4 FY 2017 |  |  | Q4 FY 2016 |  |  | Vs. Q4 FY 2016 |  |
| Revenue |  | $ | 12.1 billion |  |  | $ | 12.6 billion |  |  |  | (4 | )% |
| Net Income |  | $ | 2.4 billion |  |  | $ | 2.8 billion |  |  |  | (14 | )% |
| Diluted Earnings per Share (EPS) |  | $ | 0.48 |  |  | $ | 0.56 |  |  |  | (14 | )% |

[0001193125-17-259825:8k_2_02:18]
Q4 Non-GAAP Results

[0001193125-17-259825:8k_2_02:19]
|  |  | Q4 FY 2017 |  |  | Q4 FY 2016 |  |  | Vs. Q4 FY 2016 |  |
| Net Income |  | $ | 3.1 billion |  |  | $ | 3.2 billion |  |  |  | (3 | )% |
| EPS |  | $ | 0.61 |  |  | $ | 0.63 |  |  |  | (3 | )% |

[0001193125-17-259825:8k_2_02:20]
1

[0001193125-17-259825:8k_2_02:21]
Fiscal Year GAAP Results

[0001193125-17-259825:8k_2_02:22]
|  |  | FY 2017 |  |  | FY 2016 |  |  | Vs. FY 2016 |  |
| Revenue (excluding SP Video CPE Business for all periods) |  | $ | 48.0 billion |  |  | $ | 48.7 billion |  |  |  | (2 | )% |
| Revenue (including SP Video CPE Business for all periods) |  | $ | 48.0 billion |  |  | $ | 49.2 billion |  |  |  | (3 | )% |
| Net Income |  | $ | 9.6 billion |  |  | $ | 10.7 billion |  |  |  | (11 | )% |
| EPS |  | $ | 1.90 |  |  | $ | 2.11 |  |  |  | (10 | )% |

[0001193125-17-259825:8k_2_02:23]
Fiscal Year Non-GAAP Results

[0001193125-17-259825:8k_2_02:24]
|  |  | FY 2017 |  |  | FY 2016 |  |  | Vs. FY 2016 |  |
| Net Income (excluding SP Video CPE Business for all periods) |  | $ | 12.1 billion |  |  | $ | 12.0 billion |  |  |  | — | % |
| EPS (excluding SP Video CPE Business for all periods) |  | $ | 2.39 |  |  | $ | 2.36 |  |  |  | 1 | % |

[0001193125-17-259825:8k_2_02:25]
Reconciliations between net income, EPS, and other measures on a GAAP and non-GAAP
basis are provided in the tables located in the section entitled “Reconciliations of GAAP to non-GAAP Measures.”

[0001193125-17-259825:8k_2_02:26]
“We delivered another solid quarter and fiscal year. We executed well, drove solid profitability, strong cash flow, and we continued to deliver on our
strategic growth priorities,” said Kelly Kramer, CFO, Cisco. “We will continue to focus on making the right bets to offer the most innovative technologies to our customers in the way they want to consume it and deliver value to our
shareholders.”

[0001193125-17-259825:8k_2_02:27]
2

[0001193125-17-259825:8k_2_02:28]
Financial Summary

[0001193125-17-259825:8k_2_02:29]
All comparative percentages are on a year-over-year basis unless otherwise noted.

[0001193125-17-259825:8k_2_02:30]
Q4 FY 2017 Highlights

[0001193125-17-259825:8k_2_02:31]
Revenue —
Total revenue was $12.1 billion, down 4%, with product revenue down 5% and service revenue up 1%. 31% of total revenue was from recurring offers, up 4 percentage points from the fourth quarter of fiscal 2016. Revenue by geographic
segment was: Americas down 6%, EMEA down 6%, and APJC up 6%. Product revenue performance was led by Wireless and Security which increased 5% and 3%, respectively. NGN Routing and Switching revenue each decreased 9%. Service Provider Video, Data
Center, and Collaboration revenue decreased 10%, 4%, and 3%, respectively.

[0001193125-17-259825:8k_2_02:32]
Gross Margin — On a GAAP basis, total gross margin
and product gross margin were 62.2% and 60.3%, respectively. The decrease in the product gross margin compared with 62.2% in the fourth quarter of fiscal 2016 was primarily due to pricing, partially offset by productivity improvements and to a
lesser extent product mix.

[0001193125-17-259825:8k_2_02:33]
Non-GAAP total gross margin and product gross margin were 63.7% and 61.9%,
respectively. The decrease in non-GAAP product gross margin compared with 63.9% in the fourth quarter of fiscal 2016 was also primarily due to pricing, partially offset by continued productivity improvements
and to a lesser extent product mix.

[0001193125-17-259825:8k_2_02:34]
GAAP service gross margin was 67.8% and non-GAAP service gross margin was
68.8%.

[0001193125-17-259825:8k_2_02:35]
Total gross margins by geographic segment were: 64.0% for the Americas, 63.8% for EMEA and 62.1% for APJC.

[0001193125-17-259825:8k_2_02:36]
Operating Expenses — On a GAAP basis, operating expenses were $4.5 billion, down 3%.
Non-GAAP operating expenses were $3.9 billion, down 7%, and were 32.2% of revenue.

[0001193125-17-259825:8k_2_02:37]
Operating Income
— GAAP operating income was $3.0 billion, down 8%, with GAAP operating margin of 25.0%. Non-GAAP operating income was $3.8 billion, down 4%, with
non-GAAP operating margin at 31.5%.

[0001193125-17-259825:8k_2_02:38]
Provision for Income Taxes — The GAAP tax provision rate
was 23.8%. The non-GAAP tax provision rate was 22.3%.

[0001193125-17-259825:8k_2_02:39]
Net Income and EPS — On a GAAP basis,
net income was $2.4 billion and EPS was $0.48. On a non-GAAP basis, net income was $3.1 billion, a decrease of 3%, and EPS was $0.61, a decrease of 3%.

[0001193125-17-259825:8k_2_02:40]
Cash Flow from Operating Activities — was $4.0 billion for the fourth quarter of fiscal 2017, an increase of 5% compared with
$3.8 billion for the fourth quarter of fiscal 2016.

[0001193125-17-259825:8k_2_02:41]
FY 2017 Highlights

[0001193125-17-259825:8k_2_02:42]
The revenue and non-GAAP information in this section is presented excluding the SP Video CPE Business for fiscal
2016 as it was divested during the second quarter of fiscal 2016 on November 20, 2015.

[0001193125-17-259825:8k_2_02:43]
Revenue — Total revenue was
$48.0 billion, a decrease of 2%.

[0001193125-17-259825:8k_2_02:44]
Net Income and EPS — On a GAAP basis, net income was $9.6 billion and EPS was $1.90. On a non-GAAP basis, net income was $12.1 billion, flat compared to fiscal 2016, and EPS was $2.39, an increase of 1%.

[0001193125-17-259825:8k_2_02:45]
Cash Flow from Operating Activities — was $13.9 billion for fiscal 2017, compared with $13.6 billion for fiscal 2016, an increase
of 2%.

[0001193125-17-259825:8k_2_02:46]
Balance Sheet and Other Financial Highlights

[0001193125-17-259825:8k_2_02:47]
Cash and Cash Equivalents and Investments — were $70.5 billion at the end of the fourth quarter of fiscal 2017, compared with
$68.0 billion at the end of the third quarter of fiscal 2017, and compared with $65.8 billion at the end of fiscal 2016. The total cash and cash equivalents and investments available in the United States at the end of the fourth quarter of
fiscal 2017 were $3.0 billion.

[0001193125-17-259825:8k_2_02:48]
Deferred Revenue — was $18.5 billion, up 12% in total, with deferred product revenue up 23%,
driven largely by subscription-based and software offerings, and deferred service revenue was up 6%. The portion of product deferred revenue related to recurring software and subscription offers increased 50%.

[0001193125-17-259825:8k_2_02:49]
Product Backlog — was approximately $4.8 billion at the end of fiscal 2017, an increase of 3% compared with the balance at the
end of fiscal 2016.

[0001193125-17-259825:8k_2_02:50]
Capital Allocation — In the fourth quarter of fiscal 2017, Cisco declared and paid a cash dividend of $0.29 per
common share, or $1.4 billion. For the full fiscal year, Cisco declared and paid cash dividends of $1.10 per common share, or $5.5 billion.

[0001193125-17-259825:8k_2_02:51]
For
the fourth quarter of fiscal 2017, Cisco repurchased approximately 38 million shares of common stock under its stock repurchase program at an average price of $31.61 per share for an aggregate purchase price of $1.2 billion. For the full
fiscal year, Cisco repurchased approximately 118 million shares of common stock under its stock repurchase program at an average price of $31.38 per share for an aggregate purchase price of $3.7 billion. As of July 29, 2017, Cisco had
repurchased and retired 4.7 billion shares of Cisco common stock at an average price of $21.30 per share for an aggregate purchase price of approximately $100.3 billion since the inception of the stock repurchase program. The remaining
authorized amount for stock repurchases under this program is approximately $11.7 billion with no termination date.

[0001193125-17-259825:8k_2_02:52]
For the full fiscal year, Cisco
returned $9.2 billion to shareholders through share buybacks and dividends.

[0001193125-17-259825:8k_2_02:53]
Acquisitions — In the fourth quarter of fiscal 2017,
we closed the acquisition of MindMeld, Inc. and the acquisition of the advanced analytics team and associated intellectual property developed by Saggezza. We also announced our intent to acquire Viptela, Inc., a privately held company that provides
software-defined wide area networking products, and Observable Networks, Inc., a privately held company that offers cloud-native network forensics security applications delivered as a service. Both acquisitions closed in the first quarter of fiscal
2018.

[0001193125-17-259825:8k_2_02:54]
Business Outlook for Q1 FY 2018

[0001193125-17-259825:8k_2_02:55]
Cisco expects to achieve the following results for the first quarter of fiscal 2018:

[0001193125-17-259825:8k_2_02:56]
| Q1 FY 2018 |  |  |
| Revenue |  | (3)% to (1)% decline Y/Y |
| Non-GAAP gross margin rate |  | 63% - 64% |
| Non-GAAP operating margin rate |  | 29.5% - 30.5% |
| Non-GAAP tax provision rate |  | 22% |
| Non-GAAP EPS |  | $0.59 - $0.61 |

[0001193125-17-259825:8k_2_02:57]
Cisco estimates that GAAP EPS will be $0.48 to $0.53 which is lower than non-GAAP EPS
by $0.08 to $0.11 per share in the first quarter of fiscal 2018.

[0001193125-17-259825:8k_2_02:58]
A reconciliation between the Business Outlook for Q1 FY 2018 on a GAAP and non-GAAP basis is provided in the table entitled “GAAP to non-GAAP Business Outlook for Q1 FY 2018” located in the section entitled “Reconciliations of GAAP to non-GAAP Measures.”

[0001193125-17-259825:8k_2_02:59]
Editor’s Notes:

[0001193125-17-259825:8k_2_02:60]
|  | • |  | Q4 fiscal year 2017 conference call to discuss Cisco’s results along with its business outlook will be held on Wednesday, August 16, 2017 at 1:30 p.m. Pacific Time. Conference call number is 1-888-848-6507 (United States) or 1-212-519-0847 (international). |

[0001193125-17-259825:8k_2_02:61]
|  | • |  | Conference call replay will be available from 4:00 p.m. Pacific Time, August 16, 2017 to 4:00 p.m. Pacific Time, August 23, 2017 at 1-800-391-9851 (United States) or 1-203-369-3268 (international). The replay will also be available via webcast on the Cisco Investor Relations website at http://investor.cisco.com. |

[0001193125-17-259825:8k_2_02:62]
|  | • |  | Additional information regarding Cisco’s financials, as well as a webcast of the conference call with visuals designed to guide participants through the call, will be available at 1:30 p.m. Pacific Time, August 16, 2017. Text of the conference call’s prepared remarks will be available within 24 hours of completion of the call. The webcast will include both the prepared remarks and the question-and-answer session. This information, along with the GAAP to non-GAAP reconciliation information, will be available on the Cisco Investor Relations website at http://investor.cisco.com. |

[0001193125-17-259825:8k_2_02:63]
5

[0001193125-17-259825:8k_2_02:64]
CISCO SYSTEMS, INC.

[0001193125-17-259825:8k_2_02:65]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-17-259825:8k_2_02:66]
(In millions, except per-share amounts)

[0001193125-17-259825:8k_2_02:67]
(Unaudited)

[0001193125-17-259825:8k_2_02:68]
|  |  | Three Months Ended |  |  | Fiscal Year Ended |  |
|  |  | July 29,2017 |  |  | July 30,2016 |  |  | July 29,2017 |  |  | July 30,2016 |  |
| REVENUE: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 9,027 |  |  | $ | 9,552 |  |  | $ | 35,705 |  |  | $ | 37,254 |  |
| Service |  |  | 3,106 |  |  |  | 3,086 |  |  |  | 12,300 |  |  |  | 11,993 |  |
| Total revenue |  |  | 12,133 |  |  |  | 12,638 |  |  |  | 48,005 |  |  |  | 49,247 |  |
| COST OF SALES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 3,586 |  |  |  | 3,614 |  |  |  | 13,699 |  |  |  | 14,161 |  |
| Service |  |  | 1,001 |  |  |  | 1,049 |  |  |  | 4,082 |  |  |  | 4,126 |  |
| Total cost of sales |  |  | 4,587 |  |  |  | 4,663 |  |  |  | 17,781 |  |  |  | 18,287 |  |
| GROSS MARGIN |  |  | 7,546 |  |  |  | 7,975 |  |  |  | 30,224 |  |  |  | 30,960 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 1,499 |  |  |  | 1,601 |  |  |  | 6,059 |  |  |  | 6,296 |  |
| Sales and marketing |  |  | 2,318 |  |  |  | 2,443 |  |  |  | 9,184 |  |  |  | 9,619 |  |
| General and administrative |  |  | 495 |  |  |  | 533 |  |  |  | 1,993 |  |  |  | 1,814 |  |
| Amortization of purchased intangible assets |  |  | 58 |  |  |  | 82 |  |  |  | 259 |  |  |  | 303 |  |
| Restructuring and other charges |  |  | 142 |  |  |  | 13 |  |  |  | 756 |  |  |  | 268 |  |
| Total operating expenses |  |  | 4,512 |  |  |  | 4,672 |  |  |  | 18,251 |  |  |  | 18,300 |  |
| OPERATING INCOME |  |  | 3,034 |  |  |  | 3,303 |  |  |  | 11,973 |  |  |  | 12,660 |  |
| Interest income |  |  | 360 |  |  |  | 273 |  |  |  | 1,338 |  |  |  | 1,005 |  |
| Interest expense |  |  | (222 | ) |  |  | (180 | ) |  |  | (861 | ) |  |  | (676 | ) |
| Other income (loss), net |  |  | 8 |  |  |  | (2 | ) |  |  | (163 | ) |  |  | (69 | ) |
| Interest and other income (loss), net |  |  | 146 |  |  |  | 91 |  |  |  | 314 |  |  |  | 260 |  |
| INCOME BEFORE PROVISION FOR INCOME TAXES |  |  | 3,180 |  |  |  | 3,394 |  |  |  | 12,287 |  |  |  | 12,920 |  |
| Provision for income taxes |  |  | 756 |  |  |  | 581 |  |  |  | 2,678 |  |  |  | 2,181 |  |
| NET INCOME |  | $ | 2,424 |  |  | $ | 2,813 |  |  | $ | 9,609 |  |  | $ | 10,739 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.49 |  |  | $ | 0.56 |  |  | $ | 1.92 |  |  | $ | 2.13 |  |
| Diluted |  | $ | 0.48 |  |  | $ | 0.56 |  |  | $ | 1.90 |  |  | $ | 2.11 |  |
| Shares used in per-share calculation: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 4,993 |  |  |  | 5,031 |  |  |  | 5,010 |  |  |  | 5,053 |  |
| Diluted |  |  | 5,027 |  |  |  | 5,067 |  |  |  | 5,049 |  |  |  | 5,088 |  |
| Cash dividends declared per common share |  | $ | 0.29 |  |  | $ | 0.26 |  |  | $ | 1.10 |  |  | $ | 0.94 |  |

[0001193125-17-259825:8k_2_02:69]
CISCO SYSTEMS, INC.

[0001193125-17-259825:8k_2_02:70]
REVENUE BY SEGMENT

[0001193125-17-259825:8k_2_02:71]
(In
millions, except percentages)

[0001193125-17-259825:8k_2_02:72]
|  |  | July 29, 2017 |  |
|  |  | Three Months Ended |  |  | Fiscal Year Ended |  |
|  |  |  |  |  |  |  |  |  |  |  | Excluding SPVideo CPEBusiness |  |  | Including SPVideo CPEBusiness |  |
|  |  | Amount |  |  | Y/Y% |  |  | Amount |  |  | Y/Y% |  |  | Y/Y% |  |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 7,202 |  |  |  | (6)% |  |  | $ | 28,351 |  |  |  | (2)% |  |  |  | (4)% |  |
| EMEA |  |  | 2,927 |  |  |  | (6)% |  |  |  | 12,004 |  |  |  | (2)% |  |  |  | (2)% |  |
| APJC |  |  | 2,004 |  |  |  | 6% |  |  |  | 7,650 |  |  |  | 2% |  |  |  | 1% |  |
| Total |  | $ | 12,133 |  |  |  | (4)% |  |  | $ | 48,005 |  |  |  | (2)% |  |  |  | (3)% |  |

[0001193125-17-259825:8k_2_02:73]
During the second quarter of fiscal 2016 on November 20, 2015, Cisco completed its divestiture of the SP Video CPE
Business. SP Video CPE Business revenue for fiscal 2016 was $504 million.

[0001193125-17-259825:8k_2_02:74]
CISCO SYSTEMS, INC.

[0001193125-17-259825:8k_2_02:75]
GROSS MARGIN PERCENTAGE BY SEGMENT

[0001193125-17-259825:8k_2_02:76]
(In percentages)

[0001193125-17-259825:8k_2_02:77]
|  |  | July 29, 2017 |  |
|  |  | Three Months Ended |  |  | Fiscal Year Ended |  |
| Gross Margin Percentage: |  |  |  |  |  |  |  |  |
| Americas |  |  | 64.0% |  |  |  | 64.5% |  |
| EMEA |  |  | 63.8% |  |  |  | 65.4% |  |
| APJC |  |  | 62.1% |  |  |  | 62.0% |  |

[0001193125-17-259825:8k_2_02:78]
7

[0001193125-17-259825:8k_2_02:79]
CISCO SYSTEMS, INC.

[0001193125-17-259825:8k_2_02:80]
REVENUE FOR GROUPS OF SIMILAR PRODUCTS AND SERVICES

[0001193125-17-259825:8k_2_02:81]
(In millions, except percentages)

[0001193125-17-259825:8k_2_02:82]
|  |  | July 29, 2017 |  |
|  |  | Three Months Ended |  |  | Fiscal Year Ended |  |
|  |  | Amount |  |  | Y/Y% |  |  | Amount |  |  | Y/Y %(1) |  |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Switching |  | $ | 3,439 |  |  |  | (9)% |  |  | $ | 13,949 |  |  |  | (5)% |  |
| NGN Routing |  |  | 1,893 |  |  |  | (9)% |  |  |  | 7,831 |  |  |  | (4)% |  |
| Collaboration |  |  | 1,113 |  |  |  | (3)% |  |  |  | 4,278 |  |  |  | (2)% |  |
| Data Center |  |  | 837 |  |  |  | (4)% |  |  |  | 3,228 |  |  |  | (4)% |  |
| Wireless |  |  | 799 |  |  |  | 5% |  |  |  | 2,766 |  |  |  | 5% |  |
| Security |  |  | 558 |  |  |  | 3% |  |  |  | 2,153 |  |  |  | 9% |  |
| Service Provider Video |  |  | 227 |  |  |  | (10)% |  |  |  | 946 |  |  |  | (23)% |  |
| Other |  |  | 161 |  |  |  | 31% |  |  |  | 554 |  |  |  | 53% |  |
| Product |  |  | 9,027 |  |  |  | (5)% |  |  |  | 35,705 |  |  |  | (3)% |  |
| Service |  |  | 3,106 |  |  |  | 1% |  |  |  | 12,300 |  |  |  | 3% |  |
| Total |  | $ | 12,133 |  |  |  | (4)% |  |  | $ | 48,005 |  |  |  | (2)% |  |

[0001193125-17-259825:8k_2_02:83]
(1) During the second quarter of fiscal 2016 on November 20, 2015,
Cisco completed its divestiture of the SP Video CPE Business. SP Video CPE Business revenue for fiscal 2016 was $504 million.

[0001193125-17-259825:8k_2_02:84]
8

[0001193125-17-259825:8k_2_02:85]
CISCO SYSTEMS, INC.

[0001193125-17-259825:8k_2_02:86]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001193125-17-259825:8k_2_02:87]
(In millions)

[0001193125-17-259825:8k_2_02:88]
(Unaudited)

[0001193125-17-259825:8k_2_02:89]
|  |  | July 29,2017 |  |  | July 30,2016 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 11,708 |  |  | $ | 7,631 |  |
| Investments |  |  | 58,784 |  |  |  | 58,125 |  |
| Accounts receivable, net of allowance for doubtful accounts of $211 at July 29, 2017 and $249 at July 30, 2016 |  |  | 5,146 |  |  |  | 5,847 |  |
| Inventories |  |  | 1,616 |  |  |  | 1,217 |  |
| Financing receivables, net |  |  | 4,856 |  |  |  | 4,272 |  |
| Other current assets |  |  | 1,593 |  |  |  | 1,627 |  |
| Total current assets |  |  | 83,703 |  |  |  | 78,719 |  |
| Property and equipment, net |  |  | 3,322 |  |  |  | 3,506 |  |
| Financing receivables, net |  |  | 4,738 |  |  |  | 4,158 |  |
| Goodwill |  |  | 29,766 |  |  |  | 26,625 |  |
| Purchased intangible assets, net |  |  | 2,539 |  |  |  | 2,501 |  |
| Deferred tax assets |  |  | 4,239 |  |  |  | 4,299 |  |
| Other assets |  |  | 1,511 |  |  |  | 1,844 |  |
| TOTAL ASSETS |  | $ | 129,818 |  |  | $ | 121,652 |  |
| LIABILITIES AND EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 7,992 |  |  | $ | 4,160 |  |
| Accounts payable |  |  | 1,385 |  |  |  | 1,056 |  |
| Income taxes payable |  |  | 98 |  |  |  | 517 |  |
| Accrued compensation |  |  | 2,895 |  |  |  | 2,951 |  |
| Deferred revenue |  |  | 10,821 |  |  |  | 10,155 |  |
| Other current liabilities |  |  | 4,392 |  |  |  | 6,072 |  |
| Total current liabilities |  |  | 27,583 |  |  |  | 24,911 |  |
| Long-term debt |  |  | 25,725 |  |  |  | 24,483 |  |
| Income taxes payable |  |  | 1,250 |  |  |  | 925 |  |
| Deferred revenue |  |  | 7,673 |  |  |  | 6,317 |  |
| Other long-term liabilities |  |  | 1,450 |  |  |  | 1,431 |  |
| Total liabilities |  |  | 63,681 |  |  |  | 58,067 |  |
| Total equity |  |  | 66,137 |  |  |  | 63,585 |  |
| TOTAL LIABILITIES AND EQUITY |  | $ | 129,818 |  |  | $ | 121,652 |  |

[0001193125-17-259825:8k_2_02:90]
CISCO SYSTEMS, INC.

[0001193125-17-259825:8k_2_02:91]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-17-259825:8k_2_02:92]
(In millions)

[0001193125-17-259825:8k_2_02:93]
(Unaudited)

[0001193125-17-259825:8k_2_02:94]
|  |  | Fiscal Year Ended |  |
|  |  | July 29,2017 |  |  | July 30,2016 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 9,609 |  |  | $ | 10,739 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation, amortization, and other |  |  | 2,286 |  |  |  | 2,150 |  |
| Share-based compensation expense |  |  | 1,526 |  |  |  | 1,458 |  |
| Provision for receivables |  |  | (8 | ) |  |  | (9 | ) |
| Deferred income taxes |  |  | (124 | ) |  |  | (194 | ) |
| Excess tax benefits from share-based compensation |  |  | (153 | ) |  |  | (129 | ) |
| (Gains) losses on divestitures, investments and other, net |  |  | 154 |  |  |  | (317 | ) |
| Change in operating assets and liabilities, net of effects of acquisitions and divestitures: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 756 |  |  |  | (404 | ) |
| Inventories |  |  | (394 | ) |  |  | 315 |  |
| Financing receivables |  |  | (1,038 | ) |  |  | (150 | ) |
| Other assets |  |  | 15 |  |  |  | (37 | ) |
| Accounts payable |  |  | 311 |  |  |  | (65 | ) |
| Income taxes, net |  |  | 60 |  |  |  | (300 | ) |
| Accrued compensation |  |  | (110 | ) |  |  | (101 | ) |
| Deferred revenue |  |  | 1,683 |  |  |  | 1,219 |  |
| Other liabilities |  |  | (697 | ) |  |  | (605 | ) |
| Net cash provided by operating activities |  |  | 13,876 |  |  |  | 13,570 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of investments |  |  | (42,702 | ) |  |  | (46,760 | ) |
| Proceeds from sales of investments |  |  | 28,827 |  |  |  | 28,778 |  |
| Proceeds from maturities of investments |  |  | 12,143 |  |  |  | 14,115 |  |
| Acquisition of businesses, net of cash and cash equivalents acquired |  |  | (3,324 | ) |  |  | (3,161 | ) |
| Proceeds from business divestiture |  |  | — |  |  |  | 372 |  |
| Purchases of investments in privately held companies |  |  | (222 | ) |  |  | (256 | ) |
| Return of investments in privately held companies |  |  | 203 |  |  |  | 91 |  |
| Acquisition of property and equipment |  |  | (964 | ) |  |  | (1,146 | ) |
| Proceeds from sales of property and equipment |  |  | 7 |  |  |  | 41 |  |
| Other |  |  | 39 |  |  |  | (191 | ) |
| Net cash used in investing activities |  |  | (5,993 | ) |  |  | (8,117 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Issuances of common stock |  |  | 708 |  |  |  | 1,127 |  |
| Repurchases of common stock—repurchase program |  |  | (3,685 | ) |  |  | (3,909 | ) |
| Shares repurchased for tax withholdings on vesting of restricted stock units |  |  | (619 | ) |  |  | (557 | ) |
| Short-term borrowings, original maturities less than 90 days, net |  |  | 2,497 |  |  |  | (4 | ) |
| Issuances of debt |  |  | 6,980 |  |  |  | 6,978 |  |
| Repayments of debt |  |  | (4,151 | ) |  |  | (3,863 | ) |
| Excess tax benefits from share-based compensation |  |  | 153 |  |  |  | 129 |  |
| Dividends paid |  |  | (5,511 | ) |  |  | (4,750 | ) |
| Other |  |  | (178 | ) |  |  | 150 |  |
| Net cash used in financing activities |  |  | (3,806 | ) |  |  | (4,699 | ) |
| Net increase in cash and cash equivalents |  |  | 4,077 |  |  |  | 754 |  |
| Cash and cash equivalents, beginning of fiscal year |  |  | 7,631 |  |  |  | 6,877 |  |
| Cash and cash equivalents, end of fiscal year |  | $ | 11,708 |  |  | $ | 7,631 |  |
| Supplemental cash flow information: |  |  |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 897 |  |  | $ | 859 |  |
| Cash paid for income taxes, net |  | $ | 2,742 |  |  | $ | 2,675 |  |

[0001193125-17-259825:8k_2_02:95]
10

[0001193125-17-259825:8k_2_02:96]
CISCO SYSTEMS, INC.

[0001193125-17-259825:8k_2_02:97]
DEFERRED REVENUE

[0001193125-17-259825:8k_2_02:98]
(In
millions)

[0001193125-17-259825:8k_2_02:99]
|  |  | July 29,2017 |  |  | April 29,2017 |  |  | July 30,2016 |  |
| Deferred revenue: |  |  |  |  |  |  |  |  |  |  |  |  |
| Service |  | $ | 11,302 |  |  | $ | 10,532 |  |  | $ | 10,621 |  |
| Product: |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred revenue related to recurring software and subscription businesses |  |  | 4,971 |  |  |  | 4,352 |  |  |  | 3,308 |  |
| Other product deferred revenue |  |  | 2,221 |  |  |  | 2,438 |  |  |  | 2,543 |  |
| Total product deferred revenue |  |  | 7,192 |  |  |  | 6,790 |  |  |  | 5,851 |  |
| Total |  | $ | 18,494 |  |  | $ | 17,322 |  |  | $ | 16,472 |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |  |
| Current |  | $ | 10,821 |  |  | $ | 10,344 |  |  | $ | 10,155 |  |
| Noncurrent |  |  | 7,673 |  |  |  | 6,978 |  |  |  | 6,317 |  |
| Total |  | $ | 18,494 |  |  | $ | 17,322 |  |  | $ | 16,472 |  |

[0001193125-17-259825:8k_2_02:100]
CISCO SYSTEMS, INC.

[0001193125-17-259825:8k_2_02:101]
DIVIDENDS PAID AND REPURCHASES OF COMMON STOCK

[0001193125-17-259825:8k_2_02:102]
(In millions, except per-share amounts)

[0001193125-17-259825:8k_2_02:103]
|  |  | DIVIDENDS |  |  | STOCK REPURCHASE PROGRAM |  |  | TOTAL |  |
| Quarter Ended |  | Per Share |  |  | Amount |  |  | Shares |  |  | Weighted-Average Priceper Share |  |  | Amount |  |  | Amount |  |
| Fiscal 2017 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| July 29, 2017 |  | $ | 0.29 |  |  | $ | 1,448 |  |  |  | 38 |  |  | $ | 31.61 |  |  | $ | 1,201 |  |  | $ | 2,649 |  |
| April 29, 2017 |  |  | 0.29 |  |  |  | 1,451 |  |  |  | 15 |  |  |  | 33.71 |  |  |  | 503 |  |  |  | 1,954 |  |
| January 28, 2017 |  |  | 0.26 |  |  |  | 1,304 |  |  |  | 33 |  |  |  | 30.33 |  |  |  | 1,001 |  |  |  | 2,305 |  |
| October 29, 2016 |  |  | 0.26 |  |  |  | 1,308 |  |  |  | 32 |  |  |  | 31.12 |  |  |  | 1,001 |  |  |  | 2,309 |  |
|  |  | $ | 1.10 |  |  | $ | 5,511 |  |  |  | 118 |  |  | $ | 31.38 |  |  | $ | 3,706 |  |  | $ | 9,217 |  |
| Fiscal 2016 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| July 30, 2016 |  | $ | 0.26 |  |  | $ | 1,309 |  |  |  | 28 |  |  | $ | 28.70 |  |  | $ | 800 |  |  | $ | 2,109 |  |
| April 30, 2016 |  |  | 0.26 |  |  |  | 1,308 |  |  |  | 27 |  |  |  | 24.08 |  |  |  | 649 |  |  |  | 1,957 |  |
| January 23, 2016 |  |  | 0.21 |  |  |  | 1,065 |  |  |  | 48 |  |  |  | 26.12 |  |  |  | 1,262 |  |  |  | 2,327 |  |
| October 24, 2015 |  |  | 0.21 |  |  |  | 1,068 |  |  |  | 45 |  |  |  | 26.83 |  |  |  | 1,207 |  |  |  | 2,275 |  |
| Total |  | $ | 0.94 |  |  | $ | 4,750 |  |  |  | 148 |  |  | $ | 26.45 |  |  | $ | 3,918 |  |  | $ | 8,668 |  |

[0001193125-17-259825:8k_2_02:104]
CISCO SYSTEMS, INC.

[0001193125-17-259825:8k_2_02:105]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-17-259825:8k_2_02:106]
GAAP TO NON-GAAP NET INCOME

[0001193125-17-259825:8k_2_02:107]
(In millions, except per-share amounts)

[0001193125-17-259825:8k_2_02:108]
|  |  | Three Months Ended |  |  | Fiscal Year Ended |  |
|  |  | July 29,2017 |  |  | July 30,2016 |  |  | July 29,2017 |  |  | July 30,2016 |  |
| GAAP net income |  | $ | 2,424 |  |  | $ | 2,813 |  |  | $ | 9,609 |  |  | $ | 10,739 |  |
| Adjustments to cost of sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 56 |  |  |  | 52 |  |  |  | 219 |  |  |  | 212 |  |
| Amortization of acquisition-related intangible assets |  |  | 140 |  |  |  | 141 |  |  |  | 483 |  |  |  | 507 |  |
| Supplier component remediation charge (adjustment), net |  |  | (18 | ) |  |  | — |  |  |  | (47 | ) |  |  | (74 | ) |
| Acquisition-related/divestiture costs |  |  | — |  |  |  | — |  |  |  | 1 |  |  |  | 1 |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (2 | ) |
| Total adjustments to GAAP cost of sales |  |  | 178 |  |  |  | 193 |  |  |  | 656 |  |  |  | 644 |  |
| Adjustments to operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 344 |  |  |  | 293 |  |  |  | 1,307 |  |  |  | 1,220 |  |
| Amortization of acquisition-related intangible assets |  |  | 58 |  |  |  | 82 |  |  |  | 259 |  |  |  | 303 |  |
| Acquisition-related/divestiture costs (1) |  |  | 62 |  |  |  | 82 |  |  |  | 219 |  |  |  | 27 |  |
| Significant asset impairments and restructurings |  |  | 142 |  |  |  | 13 |  |  |  | 756 |  |  |  | 268 |  |
| Total adjustments to GAAP operating expenses |  |  | 606 |  |  |  | 470 |  |  |  | 2,541 |  |  |  | 1,818 |  |
| Total adjustments to GAAP income before provision for income taxes |  |  | 784 |  |  |  | 663 |  |  |  | 3,197 |  |  |  | 2,462 |  |
| Income tax effect of non-GAAP adjustments |  |  | (235 | ) |  |  | (196 | ) |  |  | (847 | ) |  |  | (623 | ) |
| Significant tax matters |  |  | 108 |  |  |  | (91 | ) |  |  | 108 |  |  |  | (556 | ) |
| Total adjustments to GAAP provision for income taxes |  |  | (127 | ) |  |  | (287 | ) |  |  | (739 | ) |  |  | (1,179 | ) |
| Non-GAAP net income |  | $ | 3,081 |  |  | $ | 3,189 |  |  | $ | 12,067 |  |  | $ | 12,022 |  |
| Diluted net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | $ | 0.48 |  |  | $ | 0.56 |  |  | $ | 1.90 |  |  | $ | 2.11 |  |
| Non-GAAP |  | $ | 0.61 |  |  | $ | 0.63 |  |  | $ | 2.39 |  |  | $ | 2.36 |  |

[0001193125-17-259825:8k_2_02:109]
(1) During the second quarter of fiscal 2016 on November 20, 2015,
Cisco completed its divestiture of the SP Video CPE Business. This sale resulted in a pre-tax gain of $253 million, net of certain transaction costs incurred. The gain on this transaction was excluded
from non-GAAP net income for fiscal 2016.

[0001193125-17-259825:8k_2_02:110]
12

[0001193125-17-259825:8k_2_02:111]
CISCO SYSTEMS, INC.

[0001193125-17-259825:8k_2_02:112]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-17-259825:8k_2_02:113]
GROSS MARGINS, OPERATING EXPENSES, OPERATING MARGINS, AND NET INCOME

[0001193125-17-259825:8k_2_02:114]
(In millions, except percentages)

[0001193125-17-259825:8k_2_02:115]
|  |  | Three Months EndedJuly 29, 2017 |  |
|  |  | ProductGrossMargin |  |  | ServiceGrossMargin |  |  | TotalGrossMargin |  |  | OperatingExpenses |  |  | Y/Y |  |  | OperatingIncome |  |  | Y/Y |  |  | NetIncome |  |  | Y/Y |  |
| GAAP amount |  | $ | 5,441 |  |  | $ | 2,105 |  |  | $ | 7,546 |  |  | $ | 4,512 |  |  |  | (3 | )% |  | $ | 3,034 |  |  |  | (8 | )% |  | $ | 2,424 |  |  |  | (14)% |  |
| % of revenue |  |  | 60.3 | % |  |  | 67.8 | % |  |  | 62.2 | % |  |  | 37.2 | % |  |  |  |  |  |  | 25.0 | % |  |  |  |  |  |  | 20.0 | % |  |  |  |  |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 23 |  |  |  | 33 |  |  |  | 56 |  |  |  | 344 |  |  |  |  |  |  |  | 400 |  |  |  |  |  |  |  | 400 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  |  | 140 |  |  |  | — |  |  |  | 140 |  |  |  | 58 |  |  |  |  |  |  |  | 198 |  |  |  |  |  |  |  | 198 |  |  |  |  |  |
| Supplier component remediation charge (adjustment), net |  |  | (18 | ) |  |  | — |  |  |  | (18 | ) |  |  | — |  |  |  |  |  |  |  | (18 | ) |  |  |  |  |  |  | (18 | ) |  |  |  |  |
| Acquisition/divestiture-related costs |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 62 |  |  |  |  |  |  |  | 62 |  |  |  |  |  |  |  | 62 |  |  |  |  |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 142 |  |  |  |  |  |  |  | 142 |  |  |  |  |  |  |  | 142 |  |  |  |  |  |
| Income tax/significant tax matters |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | (127 | ) |  |  |  |  |
| Non-GAAP amount |  | $ | 5,586 |  |  | $ | 2,138 |  |  | $ | 7,724 |  |  | $ | 3,906 |  |  |  | (7 | )% |  | $ | 3,818 |  |  |  | (4 | )% |  | $ | 3,081 |  |  |  | (3)% |  |
| % of revenue |  |  | 61.9 | % |  |  | 68.8 | % |  |  | 63.7 | % |  |  | 32.2 | % |  |  |  |  |  |  | 31.5 | % |  |  |  |  |  |  | 25.4 | % |  |  |  |  |

[0001193125-17-259825:8k_2_02:116]
|  |  | Three Months EndedJuly 30, 2016 |  |
|  |  | Product GrossMargin |  |  | Service GrossMargin |  |  | Total GrossMargin |  |  | OperatingExpenses |  |  | OperatingIncome |  |  | NetIncome |  |
| GAAP amount |  | $ | 5,938 |  |  | $ | 2,037 |  |  | $ | 7,975 |  |  | $ | 4,672 |  |  | $ | 3,303 |  |  | $ | 2,813 |  |
| % of revenue |  |  | 62.2 | % |  |  | 66.0 | % |  |  | 63.1 | % |  |  | 37.0 | % |  |  | 26.1 | % |  |  | 22.3% |  |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 20 |  |  |  | 32 |  |  |  | 52 |  |  |  | 293 |  |  |  | 345 |  |  |  | 345 |  |
| Amortization of acquisition-related intangible assets |  |  | 141 |  |  |  | — |  |  |  | 141 |  |  |  | 82 |  |  |  | 223 |  |  |  | 223 |  |
| Acquisition/divestiture-related costs |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 82 |  |  |  | 82 |  |  |  | 82 |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 13 |  |  |  | 13 |  |  |  | 13 |  |
| Income tax/significant tax matters |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (287) |  |
| Non-GAAP amount |  | $ | 6,099 |  |  | $ | 2,069 |  |  | $ | 8,168 |  |  | $ | 4,202 |  |  | $ | 3,966 |  |  | $ | 3,189 |  |
| % of revenue |  |  | 63.9 | % |  |  | 67.0 | % |  |  | 64.6 | % |  |  | 33.2 | % |  |  | 31.4 | % |  |  | 25.2% |  |

[0001193125-17-259825:8k_2_02:117]
13

[0001193125-17-259825:8k_2_02:118]
CISCO SYSTEMS, INC.

[0001193125-17-259825:8k_2_02:119]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-17-259825:8k_2_02:120]
GROSS MARGINS, OPERATING EXPENSES, OPERATING MARGINS, AND NET INCOME

[0001193125-17-259825:8k_2_02:121]
(In millions, except percentages)

[0001193125-17-259825:8k_2_02:122]
|  |  | Fiscal Year EndedJuly 29, 2017 |  |
|  |  | ProductGrossMargin |  |  | ServiceGrossMargin |  |  | TotalGrossMargin |  |  | OperatingExpenses |  |  | Y/Y |  |  | OperatingIncome |  |  | Y/Y |  |  | NetIncome |  |  | Y/Y |  |
| GAAP amount |  | $ | 22,006 |  |  | $ | 8,218 |  |  | $ | 30,224 |  |  | $ | 18,251 |  |  |  | — | % |  | $ | 11,973 |  |  |  | (5 | )% |  | $ | 9,609 |  |  |  | (11)% |  |
| % of revenue |  |  | 61.6 | % |  |  | 66.8 | % |  |  | 63.0 | % |  |  | 38.0 | % |  |  |  |  |  |  | 24.9 | % |  |  |  |  |  |  | 20.0 | % |  |  |  |  |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 85 |  |  |  | 134 |  |  |  | 219 |  |  |  | 1,307 |  |  |  |  |  |  |  | 1,526 |  |  |  |  |  |  |  | 1,526 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  |  | 483 |  |  |  | — |  |  |  | 483 |  |  |  | 259 |  |  |  |  |  |  |  | 742 |  |  |  |  |  |  |  | 742 |  |  |  |  |  |
| Supplier component remediation charge (adjustment), net |  |  | (47 | ) |  |  | — |  |  |  | (47 | ) |  |  | — |  |  |  |  |  |  |  | (47 | ) |  |  |  |  |  |  | (47 | ) |  |  |  |  |
| Acquisition/divestiture-related costs |  |  | — |  |  |  | 1 |  |  |  | 1 |  |  |  | 219 |  |  |  |  |  |  |  | 220 |  |  |  |  |  |  |  | 220 |  |  |  |  |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 756 |  |  |  |  |  |  |  | 756 |  |  |  |  |  |  |  | 756 |  |  |  |  |  |
| Income tax/significant tax matters |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | (739 | ) |  |  |  |  |
| Non-GAAP amount |  | $ | 22,527 |  |  | $ | 8,353 |  |  | $ | 30,880 |  |  | $ | 15,710 |  |  |  | (4 | )% |  | $ | 15,170 |  |  |  | — | % |  | $ | 12,067 |  |  |  | — % |  |
| % of revenue |  |  | 63.1 | % |  |  | 67.9 | % |  |  | 64.3 | % |  |  | 32.7 | % |  |  |  |  |  |  | 31.6 | % |  |  |  |  |  |  | 25.1 | % |  |  |  |  |

[0001193125-17-259825:8k_2_02:123]
During the second quarter of fiscal 2016 on November 20, 2015, Cisco completed its divestiture of the SP Video CPE
Business. Accordingly, the non-GAAP growth rates above are normalized to exclude the SP Video CPE Business.

[0001193125-17-259825:8k_2_02:124]
|  |  | Fiscal Year EndedJuly 30, 2016 |  |
|  |  | Product GrossMargin |  |  | Service GrossMargin |  |  | Total GrossMargin |  |  | OperatingExpenses |  |  | OperatingIncome |  |  | NetIncome |  |
| GAAP amount |  | $ | 23,093 |  |  | $ | 7,867 |  |  | $ | 30,960 |  |  | $ | 18,300 |  |  | $ | 12,660 |  |  | $ | 10,739 |  |
| % of revenue |  |  | 62.0 | % |  |  | 65.6 | % |  |  | 62.9 | % |  |  | 37.2 | % |  |  | 25.7 | % |  |  | 21.8% |  |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 70 |  |  |  | 142 |  |  |  | 212 |  |  |  | 1,220 |  |  |  | 1,432 |  |  |  | 1,432 |  |
| Amortization of acquisition-related intangible assets |  |  | 507 |  |  |  | — |  |  |  | 507 |  |  |  | 303 |  |  |  | 810 |  |  |  | 810 |  |
| Supplier component remediation charge (adjustment), net |  |  | (74 | ) |  |  | — |  |  |  | (74 | ) |  |  | — |  |  |  | (74 | ) |  |  | (74) |  |
| Acquisition/divestiture-related costs |  |  | — |  |  |  | 1 |  |  |  | 1 |  |  |  | 27 |  |  |  | 28 |  |  |  | 28 |  |
| Significant asset impairments and restructurings |  |  | (2 | ) |  |  | — |  |  |  | (2 | ) |  |  | 268 |  |  |  | 266 |  |  |  | 266 |  |
| Income tax/significant tax matters |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (1,179) |  |
| Non-GAAP amount |  | $ | 23,594 |  |  | $ | 8,010 |  |  | $ | 31,604 |  |  | $ | 16,482 |  |  | $ | 15,122 |  |  | $ | 12,022 |  |
| Less: SP Video CPE Business (1) |  |  | (56 | ) |  |  | — |  |  |  | (56 | ) |  |  | (43 | ) |  |  | (13 | ) |  |  | (10) |  |
| Non-GAAP amount (excluding SP Video CPE Business) |  | $ | 23,538 |  |  | $ | 8,010 |  |  | $ | 31,548 |  |  | $ | 16,439 |  |  | $ | 15,109 |  |  | $ | 12,012 |  |
| % of revenue |  |  | 64.0 | % |  |  | 66.8 | % |  |  | 64.7 | % |  |  | 33.7 | % |  |  | 31.0 | % |  |  | 24.6% |  |

[0001193125-17-259825:8k_2_02:125]
(1) Reflects four months of operations for the SP Video CPE Business,
which was divested during the second quarter of fiscal 2016 on November 20, 2015.

[0001193125-17-259825:8k_2_02:126]
14

[0001193125-17-259825:8k_2_02:127]
CISCO SYSTEMS, INC.

[0001193125-17-259825:8k_2_02:128]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-17-259825:8k_2_02:129]
EFFECTIVE TAX RATE

[0001193125-17-259825:8k_2_02:130]
(In
percentages)

[0001193125-17-259825:8k_2_02:131]
|  |  | Three Months Ended |  |  | Fiscal Year Ended |  |
|  |  | July 29,2017 |  |  | July 30,2016 |  |  | July 29,2017 |  |  | July 30,2016 |  |
| GAAP effective tax rate |  |  | 23.8 | % |  |  | 17.1 | % |  |  | 21.8 | % |  |  | 16.9 | % |
| Total adjustments to GAAP provision for income taxes |  |  | (1.5 | )% |  |  | 4.3 | % |  |  | 0.3 | % |  |  | 4.9 | % |
| Non-GAAP effective tax rate |  |  | 22.3 | % |  |  | 21.4 | % |  |  | 22.1 | % |  |  | 21.8 | % |

[0001193125-17-259825:8k_2_02:132]
GAAP TO NON-GAAP BUSINESS OUTLOOK FOR Q1 FY 2018

[0001193125-17-259825:8k_2_02:133]
| Q1 FY 2018 |  | Gross MarginRate |  | Operating MarginRate |  | Tax ProvisionRate |  | Earnings perShare (2) |
| GAAP |  | 61.5% - 62.5% |  | 23.5% - 24.5% |  | 18% |  | $0.48 - $0.53 |
| Estimated adjustments for: |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  | 0.5% |  | 3.0% |  |  |  | $0.04 - $0.05 |
| Amortization of purchased intangible assets and other acquisition-related/divestiture costs |  | 1.0% |  | 2.0% |  |  |  | $0.03 - $0.04 |
| Restructuring and other charges (1) |  | — |  | 1.0% |  |  |  | $0.01 - $0.02 |
| Income tax effect of non-GAAP adjustments |  | — |  | — |  | 4% |  |  |
| Non-GAAP |  | 63% - 64% |  | 29.5% - 30.5% |  | 22% |  | $0.59 - $0.61 |

[0001193125-17-259825:8k_2_02:134]
(1) In August 2016, we began taking action under a restructuring plan in
order to reinvest in our key priority areas in which up to 6,600 employees would be impacted, with estimated pretax charges of approximately $850 million. During fiscal 2017, we have recognized pretax charges of $756 million to our GAAP
financial results in relation to this restructuring plan. We expect this plan to be substantially completed by the end of the first quarter of fiscal 2018.

[0001193125-17-259825:8k_2_02:135]
(2) Estimated adjustments to GAAP earnings per share are shown after income tax effects.

[0001193125-17-259825:8k_2_02:136]
Except as noted above, this business outlook does not include the effects of any future acquisitions/divestitures, asset impairments, restructurings and
significant tax matters or other events, which may or may not be significant unless specifically stated.

[0001193125-17-259825:8k_2_02:137]
15

[0001193125-17-259825:8k_2_02:138]
Forward Looking Statements, Non-GAAP Information and Additional
Information

[0001193125-17-259825:8k_2_02:139]
This release includes non-GAAP net income, non-GAAP gross margins, non-GAAP operating expenses, non-GAAP operating
income and margin, non-GAAP effective tax rates, and non-GAAP net income per share data for the periods presented. It also includes future estimated ranges for gross
margin, operating margin, tax provision rate and EPS on a non-GAAP basis.

[0001193125-17-259825:8k_2_02:140]
These
non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with generally accepted accounting principles and may be different from
non-GAAP measures used by other companies. In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles. Cisco believes
that non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Cisco’s results of operations as determined in accordance with GAAP and that these measures should
only be used to evaluate Cisco’s results of operations in conjunction with the corresponding GAAP measures.

[0001193125-17-259825:8k_2_02:141]
Cisco believes that the presentation of non-GAAP measures when shown in conjunction with the corresponding GAAP measures, provides useful information to investors and management regarding financial and business trends relating to its financial condition
and its historical and projected results of operations.

[0001193125-17-259825:8k_2_02:142]
For its internal budgeting process, Cisco’s management uses financial statements that do not
include, when applicable, share-based compensation expense, amortization of acquisition-related intangible assets, acquisition-related/divestiture costs, significant asset impairments and restructurings, significant litigation and other
contingencies, significant gains and losses on investments, the income tax effects of the foregoing and significant tax matters. Cisco’s management also uses the foregoing non-GAAP measures, in addition
to the corresponding GAAP measures, in reviewing the financial results of Cisco. In prior periods, Cisco has excluded other items that it no longer excludes for purposes of its non-GAAP financial measures.
From time to time in the future there may be other items that Cisco may exclude for purposes of its internal budgeting process and in reviewing its financial results. For additional information on the items excluded by Cisco from one or more of its non-GAAP financial measures, refer to the Form 8-K regarding this release furnished today to the Securities and Exchange Commission.

[0001193125-17-259825:8k_2_02:143]
16

[0001193125-17-259825:8k_2_02:144]
Cisco divested the Customer Premises Equipment portion of the Service Provider Video Connected Devices business
(“SP Video CPE Business”) during the second quarter of fiscal 2016 on November 20, 2015. This release includes, where indicated, financial measures that exclude the SP Video CPE Business. Cisco believes that the presentation of these
measures provides useful information to investors and management regarding financial and business trends relating to its financial condition and its historical and projected results of operations because the SP Video CPE Business is no longer part
of Cisco and will not be part of Cisco on a go forward basis. Cisco’s management also uses the financial measures excluding the SP Video CPE Business in reviewing the financial results of Cisco.

[0001193125-17-259825:8k_2_02:145]
About Cisco

[0001193125-17-259825:8k_2_02:146]
Cisco (NASDAQ: CSCO) is the worldwide
technology leader that has been making the Internet work since 1984. Our people, products and partners help society securely connect and seize tomorrow’s digital opportunity today. Discover more at thenetwork.cisco.com and follow us on Twitter
at @Cisco.

[0001193125-17-259825:8k_2_02:147]
Copyright © 2017 Cisco and/or its affiliates. All rights reserved. Cisco and the
Cisco logo are trademarks or registered trademarks of Cisco and/or its affiliates in the U.S. and other countries. To view a list of Cisco trademarks, go to: www.cisco.com/go/trademarks. Third-party trademarks mentioned in this document are the
property of their respective owners. The use of the word partner does not imply a partnership relationship between Cisco and any other company. This document is Cisco Public Information.
