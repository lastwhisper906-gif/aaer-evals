# CSCO notes — 0000858877-17-000016


## csco:CompensationexpensesrelatedtobusinesscombinationsTableTextBlock

[0000858877-17-000016:notes:1]
The following table summarizes the compensation expense related to acquisitions (in millions):

[0000858877-17-000016:notes:2]
|  | July 29, 2017 |  | July 30, 2016 |  | July 25, 2015 |
| Compensation expense related to acquisitions | $ | 212 |  |  | $ | 282 |  |  | $ | 334 |  |


## csco:ConcentrationOfCreditRiskPolicyTextBlock

[0000858877-17-000016:notes:3]
(n) Concentrations of Risk   Cash and cash equivalents are maintained with several financial institutions. Deposits held with banks may exceed the amount of insurance provided on such deposits. Generally, these deposits may be redeemed upon demand and are maintained with financial institutions with reputable credit and therefore bear minimal credit risk. The Company seeks to mitigate its credit risks by spreading such risks across multiple counterparties and monitoring the risk profiles of these counterparties.

[0000858877-17-000016:notes:4]
The Company performs ongoing credit evaluations of its customers and, with the exception of certain financing transactions, does not require collateral from its customers. The Company receives certain of its components from sole suppliers. Additionally, the Company relies on a limited number of contract manufacturers and suppliers to provide manufacturing services for its products. The inability of a contract manufacturer or supplier to fulfill supply requirements of the Company could materially impact future operating results.


## csco:DepreciationAndAmortizationPeriodByTypeOfAssetTextBlock

[0000858877-17-000016:notes:5]
Depreciation and amortization are computed using the straight-line method, generally over the following periods:

[0000858877-17-000016:notes:6]
| Asset Category |  | Period |
| Buildings |  | 25 years |
| Building improvements |  | 10 years |
| Leasehold improvements |  | Shorter of remaining lease term or up to 10 years |
| Computer equipment and related software |  | 30 to 36 months |
| Production, engineering, and other equipment |  | Up to 5 years |
| Operating lease assets |  | Based on lease term |
| Furniture and fixtures |  | 5 years |


## csco:EntityWideDisclosureOnGeographicAreasLongLivedAssetsTableTextBlock

[0000858877-17-000016:notes:7]
The following table presents property and equipment information for geographic areas (in millions):

[0000858877-17-000016:notes:8]
|  | July 29, 2017 |  | July 30, 2016 |  | July 25, 2015 |
| Property and equipment, net: |  |  |  |  |  |
| United States | $ | 2,711 |  |  | $ | 2,822 |  |  | $ | 2,733 |  |
| International | 611 |  |  | 684 |  |  | 599 |  |
| Total | $ | 3,322 |  |  | $ | 3,506 |  |  | $ | 3,332 |  |


## csco:NetSalesForGroupsOfSimilarProductsAndServicesTableTextBlock

[0000858877-17-000016:notes:9]
The following table presents revenue for groups of similar products and services (in millions):

[0000858877-17-000016:notes:10]
| Years Ended | July 29, 2017 |  | July 30, 2016 |  | July 25, 2015 |
| Revenue: |  |  |  |  |  |
| Switching | $ | 13,949 |  |  | $ | 14,700 |  |  | $ | 14,712 |  |
| NGN Routing | 7,831 |  |  | 8,133 |  |  | 8,343 |  |
| Collaboration | 4,278 |  |  | 4,352 |  |  | 4,004 |  |
| Data Center | 3,228 |  |  | 3,365 |  |  | 3,219 |  |
| Wireless | 2,766 |  |  | 2,640 |  |  | 2,551 |  |
| Security | 2,153 |  |  | 1,969 |  |  | 1,747 |  |
| Service Provider Video (1) | 946 |  |  | 1,734 |  |  | 2,941 |  |
| Other | 554 |  |  | 361 |  |  | 233 |  |
| Product | 35,705 |  |  | 37,254 |  |  | 37,750 |  |
| Service | 12,300 |  |  | 11,993 |  |  | 11,411 |  |
| Total | $ | 48,005 |  |  | $ | 49,247 |  |  | $ | 49,161 |  |

[0000858877-17-000016:notes:11]
(1) During the second quarter of fiscal 2016, the Company completed the sale of our SP Video CPE Business. As a result, revenue from this portion of the Service Provider Video product category will not recur in future periods. SP Video CPE Business revenue was $504 million and $1,846 million for fiscal 2016 and 2015, respectively.


## csco:OtherThanTemporaryImpairmentLossesOnInvestmentsPolicyTextBlock

[0000858877-17-000016:notes:12]
(c) Other-than-Temporary Impairments on Investments   When the fair value of a debt security is less than its amortized cost, it is deemed impaired, and the Company will assess whether the impairment is other than temporary. An impairment is considered other than temporary if (i) the Company has the intent to sell the security, (ii) it is more likely than not that the Company will be required to sell the security before recovery of the entire amortized cost basis, or (iii) the Company does not expect to recover the entire amortized cost basis of the security. If impairment is considered other than temporary based on condition (i) or (ii) described earlier, the entire difference between the amortized cost and the fair value of the debt security is recognized in earnings. If an impairment is considered other than temporary based on condition (iii), the amount representing credit losses (defined as the difference between the present value of the cash flows expected to be collected and the amortized cost basis of the debt security) will be recognized in earnings, and the amount relating to all other factors will be recognized in other comprehensive income (OCI).

[0000858877-17-000016:notes:13]
The Company recognizes an impairment charge on publicly traded equity securities when a decline in the fair value of a security below the respective cost basis is judged to be other than temporary. The Company considers various factors in determining whether a decline in the fair value of these investments is other than temporary, including the length of time and extent to which the fair value of the security has been less than the Company’s cost basis, the financial condition and near-term prospects of the issuer, and the Company’s intent and ability to hold the investment for a period of time sufficient to allow for any anticipated recovery in market value.

[0000858877-17-000016:notes:14]
Investments in privately held companies are included in other assets in the Consolidated Balance Sheets and are accounted for using either the cost or equity method. The Company monitors these investments for impairments and makes reductions in carrying values if the Company determines that an impairment charge is required based primarily on the financial condition and near-term prospects of these companies.


## csco:ScheduleOfCommonStockRepurchasedTextBlock

[0000858877-17-000016:notes:15]
A summary of the stock repurchase activity under the stock repurchase program, reported based on the trade date, is summarized as follows (in millions, except per-share amounts):

[0000858877-17-000016:notes:16]
|  | SharesRepurchased |  | Weighted-Average Priceper Share |  | AmountRepurchased |
| Cumulative balance at July 25, 2015 | 4,443 |  |  | $ | 20.86 |  |  | $ | 92,679 |  |
| Repurchase of common stock under the stock repurchase program (1) | 148 |  |  | 26.45 |  |  | 3,918 |  |
| Cumulative balance at July 30, 2016 | 4,591 |  |  | 21.04 |  |  | 96,597 |  |
| Repurchase of common stock under the stock repurchase program (2) | 118 |  |  | 31.38 |  |  | 3,706 |  |
| Cumulative balance at July 29, 2017 | 4,709 |  |  | $ | 21.30 |  |  | $ | 100,303 |  |

[0000858877-17-000016:notes:17]
(1) Includes stock repurchases of $45 million, which were pending settlement as of July 30, 2016.

[0000858877-17-000016:notes:18]
(2) Includes stock repurchases of $66 million, which were pending settlement as of July 29, 2017.


## csco:ScheduleOfDerivativeFairValueHedgeInstrumentsGainLossInStatementOfFinancialPerformanceTableTextBlock

[0000858877-17-000016:notes:19]
The effect on the Consolidated Statements of Operations of derivative instruments designated as fair value hedges and the underlying hedged items is summarized as follows (in millions):

[0000858877-17-000016:notes:20]
|  |  |  |  | GAINS (LOSSES) ONDERIVATIVE INSTRUMENTS FOR THE YEARS ENDED |  | GAINS (LOSSES) RELATED TO HEDGED ITEMS FOR THE YEARS ENDED |
| Derivatives Designated as Fair Value Hedging Instruments |  | Line Item in Statements of Operations |  | July 29, 2017 |  | July 30, 2016 |  | July 25, 2015 |  | July 29, 2017 |  | July 30, 2016 |  | July 25, 2015 |
| Equity derivatives |  | Other income (loss), net |  | $ | — |  |  | $ | — |  |  | $ | 56 |  |  | $ | — |  |  | $ | — |  |  | $ | (56 | ) |
| Interest rate derivatives |  | Interest expense |  | (275 | ) |  | 175 |  |  | 54 |  |  | 271 |  |  | (169 | ) |  | (57 | ) |
| Total |  |  |  | $ | (275 | ) |  | $ | 175 |  |  | $ | 110 |  |  | $ | 271 |  |  | $ | (169 | ) |  | $ | (113 | ) |


## csco:ScheduleOfFiniteLivedIntangibleAssetsAmortizationExpenseTableTextBlock

[0000858877-17-000016:notes:21]
The following table presents the amortization of purchased intangible assets (in millions):

[0000858877-17-000016:notes:22]
| Years Ended |  | July 29, 2017 |  | July 30, 2016 |  | July 25, 2015 |
| Amortization of purchased intangible assets: |  |  |  |  |  |  |
| Cost of sales |  | $ | 556 |  |  | $ | 577 |  |  | $ | 814 |  |
| Operating expenses |  |  |  |  |  |  |
| Amortization of purchased intangible assets |  | 259 |  |  | 303 |  |  | 359 |  |
| Restructuring and other charges |  | 38 |  |  | — |  |  | — |  |
| Total |  | $ | 853 |  |  | $ | 880 |  |  | $ | 1,173 |  |


## csco:ScheduleOfIntangibleAssetsAcquiredAsPartOfBusinessCombinationTextBlock

[0000858877-17-000016:notes:23]
The following tables present details of the Company’s intangible assets acquired through acquisitions completed during fiscal 2017 and 2016 (in millions, except years):

[0000858877-17-000016:notes:24]
|  | FINITE LIVES |  | INDEFINITELIVES |  | TOTAL |
|  | TECHNOLOGY |  | CUSTOMERRELATIONSHIPS |  | OTHER |  | IPR&D |  |
| Fiscal 2017 | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Amount |  | Amount |
| CloudLock | 6.0 |  | $ | 32 |  |  | 4.0 |  | $ | 3 |  |  | 1.5 |  | $ | 1 |  |  | $ | — |  |  | $ | 36 |  |
| AppDynamics | 4.0 |  | 525 |  |  | 7.0 |  | 235 |  |  | 2.3 |  | 25 |  |  | — |  |  | 785 |  |
| MindMeld | 4.0 |  | 51 |  |  | 1.0 |  | — |  |  | 0.0 |  | — |  |  | — |  |  | 51 |  |
| Others (four in total) | 3.0 |  | 6 |  |  | 0.0 |  | — |  |  | 0.0 |  | — |  |  | — |  |  | 6 |  |
| Total |  |  | $ | 614 |  |  |  |  | $ | 238 |  |  |  |  | $ | 26 |  |  | $ | — |  |  | $ | 878 |  |

[0000858877-17-000016:notes:25]
|  | FINITE LIVES |  | INDEFINITELIVES |  | TOTAL |
|  | TECHNOLOGY |  | CUSTOMERRELATIONSHIPS |  | OTHER |  | IPR&D |  |
| Fiscal 2016 | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Amount |  | Amount |
| MaintenanceNet | 5.0 |  | $ | 50 |  |  | 5.0 |  | $ | 2 |  |  | 2.0 |  | $ | 2 |  |  | $ | 11 |  |  | $ | 65 |  |
| OpenDNS | 5.0 |  | 43 |  |  | 7.0 |  | 15 |  |  | 1.0 |  | 2 |  |  | 1 |  |  | 61 |  |
| Lancope | 5.0 |  | 79 |  |  | 6.0 |  | 29 |  |  | 3.0 |  | 3 |  |  | 10 |  |  | 121 |  |
| Acano | 5.0 |  | 9 |  |  | 5.0 |  | 12 |  |  | 0.0 |  | — |  |  | 82 |  |  | 103 |  |
| Leaba | 0.0 |  | — |  |  | 0.0 |  | — |  |  | 0.0 |  | — |  |  | 96 |  |  | 96 |  |
| Jasper | 6.0 |  | 240 |  |  | 7.0 |  | 75 |  |  | 2.0 |  | 23 |  |  | 23 |  |  | 361 |  |
| CliQr | 6.0 |  | 65 |  |  | 6.0 |  | 3 |  |  | 2.0 |  | 1 |  |  | — |  |  | 69 |  |
| Others (five in total) | 4.1 |  | 58 |  |  | 6.3 |  | 6 |  |  | 0.0 |  | — |  |  | — |  |  | 64 |  |
| Total |  |  | $ | 544 |  |  |  |  | $ | 142 |  |  |  |  | $ | 31 |  |  | $ | 223 |  |  | $ | 940 |  |


## csco:ScheduleOfIntangibleAssetsByMajorClassTextBlock

[0000858877-17-000016:notes:26]
The following tables present details of the Company’s purchased intangible assets (in millions):

[0000858877-17-000016:notes:27]
| July 29, 2017 |  | Gross |  | Accumulated Amortization |  | Net |
| Purchased intangible assets with finite lives: |  |  |  |  |  |  |
| Technology |  | $ | 3,182 |  |  | $ | (1,386 | ) |  | $ | 1,796 |  |
| Customer relationships |  | 1,353 |  |  | (765 | ) |  | 588 |  |
| Other |  | 82 |  |  | (38 | ) |  | 44 |  |
| Total purchased intangible assets with finite lives |  | 4,617 |  |  | (2,189 | ) |  | 2,428 |  |
| In-process research and development, with indefinite lives |  | 111 |  |  | — |  |  | 111 |  |
| Total |  | $ | 4,728 |  |  | $ | (2,189 | ) |  | $ | 2,539 |  |

[0000858877-17-000016:notes:28]
| July 30, 2016 |  | Gross |  | Accumulated Amortization |  | Net |
| Purchased intangible assets with finite lives: |  |  |  |  |  |  |
| Technology |  | $ | 3,038 |  |  | $ | (1,391 | ) |  | $ | 1,647 |  |
| Customer relationships |  | 1,793 |  |  | (1,203 | ) |  | 590 |  |
| Other |  | 85 |  |  | (43 | ) |  | 42 |  |
| Total purchased intangible assets with finite lives |  | 4,916 |  |  | (2,637 | ) |  | 2,279 |  |
| In-process research and development, with indefinite lives |  | 222 |  |  | — |  |  | 222 |  |
| Total |  | $ | 5,138 |  |  | $ | (2,637 | ) |  | $ | 2,501 |  |


## csco:SegmentReportingProductAndServicesNetSalesTextBlock

[0000858877-17-000016:notes:29]
Segment Information and Major Customers

[0000858877-17-000016:notes:30]
| (a) | Revenue and Gross Margin by Segment |

[0000858877-17-000016:notes:31]
The Company conducts business globally and is primarily managed on a geographic basis consisting of three segments: the Americas, EMEA, and APJC. The Company’s management makes financial decisions and allocates resources based on the information it receives from its internal management system. Sales are attributed to a segment based on the ordering location of the customer. The Company does not allocate research and development, sales and marketing, or general and administrative expenses to its segments in this internal management system because management does not include the information in its measurement of the performance of the operating segments. In addition, the Company does not allocate amortization and impairment of acquisition-related intangible assets, share-based compensation expense, significant litigation and other contingencies, impacts to cost of sales from purchase accounting adjustments to inventory, charges related to asset impairments and restructurings, and certain other charges to the gross margin for each segment because management does not include this information in its measurement of the performance of the operating segments.

[0000858877-17-000016:notes:32]
Summarized financial information by segment for fiscal 2017, 2016, and 2015, based on the Company’s internal management system and as utilized by the Company’s Chief Operating Decision Maker (“CODM”), is as follows (in millions):

[0000858877-17-000016:notes:33]
| Years Ended | July 29, 2017 |  | July 30, 2016 |  | July 25, 2015 |
| Revenue: |  |  |  |  |  |
| Americas | $ | 28,351 |  |  | $ | 29,392 |  |  | $ | 29,626 |  |
| EMEA | 12,004 |  |  | 12,302 |  |  | 12,348 |  |
| APJC | 7,650 |  |  | 7,553 |  |  | 7,187 |  |
| Total | $ | 48,005 |  |  | $ | 49,247 |  |  | $ | 49,161 |  |
| Gross margin: |  |  |  |  |  |
| Americas | $ | 18,284 |  |  | $ | 18,986 |  |  | $ | 18,638 |  |
| EMEA | 7,855 |  |  | 7,998 |  |  | 7,731 |  |
| APJC | 4,741 |  |  | 4,620 |  |  | 4,313 |  |
| Segment total | 30,880 |  |  | 31,604 |  |  | 30,682 |  |
| Unallocated corporate items | (656 | ) |  | (644 | ) |  | (1,001 | ) |
| Total | $ | 30,224 |  |  | $ | 30,960 |  |  | $ | 29,681 |  |

[0000858877-17-000016:notes:34]
Revenue in the United States was $25.0 billion, $25.9 billion, and $26.2 billion for fiscal 2017, 2016, and 2015, respectively.

[0000858877-17-000016:notes:35]
| (b) | Revenue for Groups of Similar Products and Services |

[0000858877-17-000016:notes:36]
The Company designs, manufactures, and sells IP-based networking and other products related to the communications and IT industry and provides services associated with these products and their use. The Company groups its products and technologies into the following categories: Switching, NGN Routing, Collaboration, Data Center, Wireless, Security, Service Provider Video, and Other Products. These products, primarily integrated by Cisco IOS Software, link geographically dispersed local-area networks (LANs), metropolitan-area networks (MANs), and wide-area networks (WANs).

[0000858877-17-000016:notes:37]
The Company has made certain reclassifications to the product revenue amounts for prior years to conform to the current year’s presentation.

[0000858877-17-000016:notes:38]
| (c) | Additional Segment Information |

[0000858877-17-000016:notes:39]
The majority of the Company’s assets, excluding cash and cash equivalents and investments, as of July 29, 2017 and July 30, 2016 was attributable to its U.S. operations. The Company’s total cash and cash equivalents and investments held by various foreign subsidiaries were $67.5 billion and $59.8 billion as of July 29, 2017 and July 30, 2016, respectively, and the remaining $3.0 billion and $5.9 billion at the respective fiscal year ends were available in the United States. In fiscal 2017, 2016, and 2015, no single customer accounted for 10% or more of revenue.

[0000858877-17-000016:notes:40]
Property and equipment information is based on the physical location of the assets. The following table presents property and equipment information for geographic areas (in millions):


## csco:StockRepurchasesSinceInceptionOfProgramTableTextBlock

[0000858877-17-000016:notes:41]
The stock repurchases since the inception of this program and the related impacts on Cisco shareholders’ equity are summarized in the following table (in millions):

[0000858877-17-000016:notes:42]
|  | Shares ofCommonStock |  | Common Stockand AdditionalPaid-In Capital |  | RetainedEarnings |  | Total CiscoShareholders’Equity |
| Repurchases of common stock under the repurchase program | 4,709 |  |  | $ | 24,945 |  |  | $ | 75,358 |  |  | $ | 100,303 |  |


## us-gaap:AdvertisingCostsPolicyTextBlock

[0000858877-17-000016:notes:43]
(p) Advertising Costs   The Company expenses all advertising costs as incurred.


## us-gaap:AllowanceForCreditLossesOnFinancingReceivablesTableTextBlock

[0000858877-17-000016:notes:44]
The allowances for credit loss and the related financing receivables are summarized as follows (in millions):

[0000858877-17-000016:notes:45]
|  | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Allowance for credit loss as of July 30, 2016 | $ | 230 |  |  | $ | 97 |  |  | $ | 48 |  |  | $ | 375 |  |
| Provisions | (25 | ) |  | 7 |  |  | (17 | ) |  | (35 | ) |
| Recoveries (write-offs), net | (37 | ) |  | (11 | ) |  | (1 | ) |  | (49 | ) |
| Foreign exchange and other | (6 | ) |  | 10 |  |  | — |  |  | 4 |  |
| Allowance for credit loss as of July 29, 2017 | $ | 162 |  |  | $ | 103 |  |  | $ | 30 |  |  | $ | 295 |  |

[0000858877-17-000016:notes:46]
|  | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Allowance for credit loss as of July 25, 2015 | $ | 259 |  |  | $ | 87 |  |  | $ | 36 |  |  | $ | 382 |  |
| Provisions | (13 | ) |  | 13 |  |  | 17 |  |  | 17 |  |
| Recoveries (write-offs), net | (10 | ) |  | — |  |  | (5 | ) |  | (15 | ) |
| Foreign exchange and other | (6 | ) |  | (3 | ) |  | — |  |  | (9 | ) |
| Allowance for credit loss as of July 30, 2016 | $ | 230 |  |  | $ | 97 |  |  | $ | 48 |  |  | $ | 375 |  |

[0000858877-17-000016:notes:47]
|  | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Allowance for credit loss as of July 26, 2014 | $ | 233 |  |  | $ | 98 |  |  | $ | 18 |  |  | $ | 349 |  |
| Provisions | 45 |  |  | (8 | ) |  | 20 |  |  | 57 |  |
| Recoveries (write-offs), net | (7 | ) |  | 1 |  |  | (1 | ) |  | (7 | ) |
| Foreign exchange and other | (12 | ) |  | (4 | ) |  | (1 | ) |  | (17 | ) |
| Allowance for credit loss as of July 25, 2015 | $ | 259 |  |  | $ | 87 |  |  | $ | 36 |  |  | $ | 382 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0000858877-17-000016:notes:48]
The Consolidated Financial Statements include the accounts of Cisco and its subsidiaries. All intercompany accounts and transactions have been eliminated.  The Company conducts business globally and is primarily managed on a geographic basis in the following three geographic segments: the Americas; Europe, Middle East, and Africa (EMEA); and Asia Pacific, Japan, and China (APJC).


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000858877-17-000016:notes:49]
Acquisitions and Divestitures

[0000858877-17-000016:notes:50]
| (a) | Acquisition Summary |

[0000858877-17-000016:notes:51]
The Company completed 7 acquisitions during fiscal 2017. A summary of the allocation of the total purchase consideration is presented as follows (in millions):

[0000858877-17-000016:notes:52]
| Fiscal 2017 | Purchase Consideration |  | Net Tangible Assets Acquired (Liabilities Assumed) |  | Purchased Intangible Assets |  | Goodwill |
| CloudLock | $ | 249 |  |  | $ | — |  |  | $ | 36 |  |  | $ | 213 |  |
| AppDynamics | 3,258 |  |  | (175 | ) |  | 785 |  |  | 2,648 |  |
| MindMeld | 104 |  |  | (11 | ) |  | 51 |  |  | 64 |  |
| Others (four in total) | 26 |  |  | — |  |  | 6 |  |  | 20 |  |
| Total | $ | 3,637 |  |  | $ | (186 | ) |  | $ | 878 |  |  | $ | 2,945 |  |

[0000858877-17-000016:notes:53]
On August 1, 2016, the Company completed its acquisition of privately held CloudLock Inc. ("CloudLock"), a provider of cloud security that specializes in cloud access security broker technology that provides enterprises with visibility and analytics around user behavior and sensitive data in cloud services. Revenue from the CloudLock acquisition has been included in the Company's Security product category.

[0000858877-17-000016:notes:54]
On March 17, 2017, the Company completed its acquisition of privately held AppDynamics, Inc. ("AppDynamics"), an application intelligence software company. AppDynamics's cloud application and business monitoring platform is designed to enable companies to improve application and business performance. With the AppDynamics acquisition, the Company seeks to provide end-to-end visibility and intelligence from the customer's network through to the application. Product revenue from the AppDynamics acquisition has been included in the Company's Other product category.

[0000858877-17-000016:notes:55]
On May 26, 2017, the Company completed its acquisition of privately held MindMeld, Inc. ("MindMeld'), an artificial intelligence (AI) company. MindMeld's unique AI platform enables customers to build intelligent and human-like conversational interfaces for any application or device. Revenue from the MindMeld acquisition has been included in the Company's Collaboration product category.

[0000858877-17-000016:notes:56]
The total purchase consideration related to the Company’s acquisitions completed during fiscal 2017 consisted of cash consideration and vested share-based awards assumed. The total cash and cash equivalents acquired from these acquisitions was approximately $138 million.

[0000858877-17-000016:notes:57]
Fiscal 2016 and 2015 Acquisitions

[0000858877-17-000016:notes:58]
Allocation of the purchase consideration for acquisitions completed in fiscal 2016 is summarized as follows (in millions):

[0000858877-17-000016:notes:59]
| Fiscal 2016 | Purchase Consideration |  | Net Tangible Assets Acquired (Liabilities Assumed) |  | Purchased Intangible Assets |  | Goodwill |
| MaintenanceNet | $ | 105 |  |  | $ | (21 | ) |  | $ | 65 |  |  | $ | 61 |  |
| OpenDNS | 545 |  |  | (9 | ) |  | 61 |  |  | 493 |  |
| Lancope | 410 |  |  | (34 | ) |  | 121 |  |  | 323 |  |
| Acano | 528 |  |  | (27 | ) |  | 103 |  |  | 452 |  |
| Leaba | 219 |  |  | (18 | ) |  | 96 |  |  | 141 |  |
| Jasper | 1,234 |  |  | 5 |  |  | 361 |  |  | 868 |  |
| CliQr | 225 |  |  | (3 | ) |  | 69 |  |  | 159 |  |
| Others (five in total) | 112 |  |  | (17 | ) |  | 64 |  |  | 65 |  |
| Total | $ | 3,378 |  |  | $ | (124 | ) |  | $ | 940 |  |  | $ | 2,562 |  |

[0000858877-17-000016:notes:60]
The Company in the first quarter of fiscal 2016 acquired privately held MaintenanceNet, Inc. ("MaintenanceNet"), a provider of a cloud-based software platform that uses data analytics and automation to manage renewals of recurring customer contracts.  This acquisition is a component of the Company's strategy for its Services organization to simplify and digitize its business processes.

[0000858877-17-000016:notes:61]
The Company in the first quarter of fiscal 2016 acquired privately held OpenDNS, Inc. ("OpenDNS"), a provider of advanced threat protection for endpoint devices. With the OpenDNS acquisition, the Company aims to strengthen its security offerings by adding broad visibility and threat intelligence delivered through a software-as-a-service platform. Revenue from the OpenDNS acquisition has been included in the Company's Security product category.

[0000858877-17-000016:notes:62]
The Company in the second quarter of fiscal 2016 acquired privately held Lancope, Inc. ("Lancope"), a provider of network behavior analytics, threat visibility, and security intelligence. With the Lancope acquisition, the Company aims to advance its "security everywhere" strategy with an additional capability of network behavior analytics that extend protection further into the network. Revenue from the Lancope acquisition has been included in the Company's Security product category.

[0000858877-17-000016:notes:63]
The Company in the third quarter of fiscal 2016 acquired privately held, London-based Acano (UK) Limited ("Acano"), a collaboration infrastructure and conferencing software provider. With the Acano acquisition, the Company aims to enhance its collaboration strategy to deliver video across both cloud and hybrid environments. Revenue from the Acano acquisition has been included in the Company's Collaboration product category.

[0000858877-17-000016:notes:64]
The Company in the third quarter of fiscal 2016 acquired privately held Leaba Semiconductor, Ltd. ("Leaba"), an Israeli-based fabless semiconductor provider whose semiconductor expertise is expected to be leveraged to accelerate the Company's next-generation product portfolio. This acquisition is a component of the Company's strategy to enhance its product offerings in the networking chipset market.

[0000858877-17-000016:notes:65]
The Company in the third quarter of fiscal 2016 acquired privately held Jasper Technologies, Inc. ("Jasper"), a provider of a cloud-based Internet of Things (IoT) software-as-a-service platform to help enterprises and service providers launch, manage, and monetize IoT services on a global scale. With the Jasper acquisition, the Company aims to offer an IoT solution that is interoperable across devices and works with IoT service providers, application developers, and an ecosystem of partners. Revenue from the Jasper acquisition has been included in the Company's Other product category.

[0000858877-17-000016:notes:66]
The Company in the third quarter of fiscal 2016 acquired privately held CliQr Technologies, Inc. ("CliQr"), an application-defined cloud orchestration platform provider. With the CliQr acquisition, the Company aims to help its customers simplify and accelerate their private, public, and hybrid cloud deployments. Revenue from the CliQr acquisition has been included in the Company's Switching product category.

[0000858877-17-000016:notes:67]
The total purchase consideration related to the Company’s acquisitions completed during fiscal 2016 consisted of cash consideration and vested share-based awards assumed.  The total cash and cash equivalents acquired from these acquisitions was approximately $44 million.

[0000858877-17-000016:notes:68]
Allocation of the purchase consideration for acquisitions completed in fiscal 2015 is summarized as follows (in millions):

[0000858877-17-000016:notes:69]
| Fiscal 2015 | Purchase Consideration |  | Net Tangible Assets Acquired (Liabilities Assumed) |  | Purchased Intangible Assets |  | Goodwill |
| Metacloud | $ | 149 |  |  | $ | (7 | ) |  | $ | 29 |  |  | $ | 127 |  |
| Others (five in total) | 185 |  |  | (13 | ) |  | 70 |  |  | 128 |  |
| Total | $ | 334 |  |  | $ | (20 | ) |  | $ | 99 |  |  | $ | 255 |  |

[0000858877-17-000016:notes:70]
The Company in the first quarter of fiscal 2015 acquired privately held Metacloud, Inc. ("Metacloud"). Prior to its acquisition, Metacloud provided private clouds for global organizations. With its acquisition of Metacloud, the Company aims to advance its Intercloud strategy to deliver a globally distributed, highly secure cloud platform. The Company has included revenue from the Metacloud acquisition, subsequent to the acquisition date, in the Company's Service category.

[0000858877-17-000016:notes:71]
The total purchase consideration related to the Company’s acquisitions completed during fiscal 2015 consisted of cash consideration and vested share-based awards assumed. The total cash and cash equivalents acquired from these acquisitions was approximately $5 million.

[0000858877-17-000016:notes:72]
| (b) | Acquisition of Viptela |

[0000858877-17-000016:notes:73]
Acquisition of Viptela  On July 31, 2017, the Company completed its acquisition of Viptela, Inc., a privately held software-defined wide area network company for total consideration of approximately $610 million in cash and assumed equity awards. The Company expects that most of the purchase price will be allocated to goodwill and purchased intangible assets.

[0000858877-17-000016:notes:74]
| (c) | Divestiture of SP Video CPE Business |

[0000858877-17-000016:notes:75]
During the second quarter of fiscal 2016, the Company completed the sale of the assets comprising its SP Video CPE Business to Technicolor SA. As a result of the transaction, the Company received aggregate consideration of $542 million consisting of $372 million in cash and $170 million in Technicolor stock (as of the divestiture date) and the transaction resulted in a gain of $253 million, net of certain transaction costs.

[0000858877-17-000016:notes:76]
(d)   Other Acquisition Information

[0000858877-17-000016:notes:77]
Total transaction costs related to the Company’s acquisitions during fiscal 2017, 2016, and 2015 were $10 million, $32 million, and $10 million, respectively. These transaction costs were expensed as incurred in G&A expenses in the Consolidated Statements of Operations.

[0000858877-17-000016:notes:78]
The Company’s purchase price allocation for acquisitions completed during recent periods is preliminary and subject to revision as additional information about fair value of assets and liabilities becomes available. Additional information that existed as of the acquisition date but at that time was unknown to the Company, may become known to the Company during the remainder of the measurement period, a period not to exceed 12 months from the acquisition date. Adjustments in the purchase price allocation may require a recasting of the amounts allocated to goodwill retroactive to the period in which the acquisition occurred.

[0000858877-17-000016:notes:79]
The goodwill generated from the Company’s acquisitions completed during fiscal 2017 is primarily related to expected synergies. The goodwill is generally not deductible for income tax purposes.

[0000858877-17-000016:notes:80]
The Consolidated Financial Statements include the operating results of each acquisition from the date of acquisition. Pro forma results of operations for the acquisitions completed during the fiscal years presented have not been presented because the effects of the acquisitions, individually and in the aggregate, were not material to the Company’s financial results.


## us-gaap:BusinessCombinationsAndOtherPurchaseOfBusinessTransactionsPolicyTextBlock

[0000858877-17-000016:notes:81]
(h) Business Combinations The Company allocates the fair value of the purchase consideration of its acquisitions to the tangible assets, liabilities, and intangible assets acquired, including in-process research and development (IPR&D), based on their estimated fair values. The excess of the fair value of purchase consideration over the fair values of these identifiable assets and liabilities is recorded as goodwill. IPR&D is initially capitalized at fair value as an intangible asset with an indefinite life and assessed for impairment thereafter. When an IPR&D project is completed, the IPR&D is reclassified as an amortizable purchased intangible asset and amortized over the asset’s estimated useful life. Acquisition-related expenses and related restructuring costs are recognized separately from the business combination and are expensed as incurred.


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0000858877-17-000016:notes:82]
(a) Cash and Cash Equivalents   The Company considers all highly liquid investments purchased with an original or remaining maturity of three months or less at the date of purchase to be cash equivalents. Cash and cash equivalents are maintained with various financial institutions.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000858877-17-000016:notes:83]
Commitments and Contingencies

[0000858877-17-000016:notes:84]
| (a) | Operating Leases |

[0000858877-17-000016:notes:85]
The Company leases office space in many U.S. locations. Outside the United States, larger leased sites include sites in Belgium, Canada, China, France, Germany, India, Israel, Japan, Poland, and the United Kingdom.  The Company also leases equipment and vehicles. Future minimum lease payments under all noncancelable operating leases with an initial term in excess of one year as of July 29, 2017 are as follows (in millions):

[0000858877-17-000016:notes:86]
| Fiscal Year | Amount |
| 2018 | $ | 417 |  |
| 2019 | 277 |  |
| 2020 | 190 |  |
| 2021 | 115 |  |
| 2022 | 95 |  |
| Thereafter | 143 |  |
| Total | $ | 1,237 |  |

[0000858877-17-000016:notes:87]
Rent expense for office space and equipment totaled $403 million, $385 million, and $394 million in fiscal 2017, 2016, and 2015, respectively.

[0000858877-17-000016:notes:88]
| (b) | Purchase Commitments with Contract Manufacturers and Suppliers |

[0000858877-17-000016:notes:89]
The Company purchases components from a variety of suppliers and uses several contract manufacturers to provide manufacturing services for its products.  During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, the Company enters into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by the Company or establish the parameters defining the Company’s requirements.  A significant portion of the Company’s reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. In certain instances, these agreements allow the Company the option to cancel, reschedule, and adjust the Company’s requirements based on its business needs prior to firm orders being placed. As of July 29, 2017 and July 30, 2016, the Company had total purchase commitments for inventory of $4,640 million and $3,896 million, respectively.

[0000858877-17-000016:notes:90]
The Company records a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of its future demand forecasts consistent with the valuation of the Company’s excess and obsolete inventory.  As of July 29, 2017 and July 30, 2016, the liability for these purchase commitments was $162 million and $159 million, respectively, and was included in other current liabilities.

[0000858877-17-000016:notes:91]
| (c) | Other Commitments |

[0000858877-17-000016:notes:92]
In connection with the Company’s acquisitions, the Company has agreed to pay certain additional amounts contingent upon the achievement of certain agreed-upon technology, development, product, or other milestones or upon the continued employment with the Company of certain employees of the acquired entities.

[0000858877-17-000016:notes:93]
As of July 29, 2017, the Company estimated that future cash compensation expense of up to $207 million may be required to be recognized pursuant to the applicable business combination agreements.

[0000858877-17-000016:notes:94]
Insieme Networks, Inc.    In fiscal 2012, the Company made an investment in Insieme, an early stage company focused on research and development in the data center market. This investment included $100 million of funding and a license to certain of the Company’s technology. During fiscal 2014, the Company acquired the remaining interests in Insieme, at which time the former noncontrolling interest holders became eligible to receive up to two milestone payments, which were determined using agreed-upon formulas based primarily on revenue for certain of Insieme’s products. The former noncontrolling interest holders earned the maximum amount related to these two milestone payments and were paid approximately $441 million and $389 million during fiscal 2017 and fiscal 2016, respectively. The Company recorded compensation expense of $47 million, $160 million, and $207 million during fiscal 2017, 2016, and 2015, respectively, related to these milestone payments. The Company does not expect a material amount of future compensation expense or further milestone payments related to this acquisition.

[0000858877-17-000016:notes:95]
The Company also has certain funding commitments, primarily related to its investments in privately held companies and venture funds, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $216 million and $222 million as of July 29, 2017 and July 30, 2016, respectively.

[0000858877-17-000016:notes:96]
| (d) | Product Warranties |

[0000858877-17-000016:notes:97]
The following table summarizes the activity related to the product warranty liability (in millions):

[0000858877-17-000016:notes:98]
|  | July 29, 2017 |  | July 30, 2016 |  | July 25, 2015 |
| Balance at beginning of fiscal year | $ | 414 |  |  | $ | 449 |  |  | $ | 446 |  |
| Provisions for warranty issued | 691 |  |  | 715 |  |  | 686 |  |
| Adjustments for pre-existing warranties | (21 | ) |  | (8 | ) |  | 10 |  |
| Settlements | (677 | ) |  | (714 | ) |  | (693 | ) |
| Divestiture | — |  |  | (28 | ) |  | — |  |
| Balance at end of fiscal year | $ | 407 |  |  | $ | 414 |  |  | $ | 449 |  |

[0000858877-17-000016:notes:99]
The Company accrues for warranty costs as part of its cost of sales based on associated material product costs, labor costs for technical support staff, and associated overhead. The Company’s products are generally covered by a warranty for periods ranging from 90 days to five years, and for some products the Company provides a limited lifetime warranty.

[0000858877-17-000016:notes:100]
| (e) | Financing and Other Guarantees |

[0000858877-17-000016:notes:101]
In the ordinary course of business, the Company provides financing guarantees for various third-party financing arrangements extended to channel partners and end-user customers. Payments under these financing guarantee arrangements were not material for the periods presented.

[0000858877-17-000016:notes:102]
Channel Partner Financing Guarantees   The Company facilitates arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, generally with payment terms ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, the Company guarantees a portion of these arrangements. The volume of channel partner financing was $27.0 billion, $26.9 billion, and $25.9 billion in fiscal 2017, 2016, and 2015, respectively. The balance of the channel partner financing subject to guarantees was $1.0 billion and $1.1 billion as of July 29, 2017 and July 30, 2016, respectively.

[0000858877-17-000016:notes:103]
End-User Financing Guarantees   The Company also provides financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. The volume of financing provided by third parties for leases and loans as to which the Company had provided guarantees was $51 million, $63 million, and $107 million in fiscal 2017, 2016, and 2015, respectively.

[0000858877-17-000016:notes:104]
Financing Guarantee Summary   The aggregate amounts of financing guarantees outstanding at July 29, 2017 and July 30, 2016, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

[0000858877-17-000016:notes:105]
|  | July 29, 2017 |  | July 30, 2016 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 240 |  |  | $ | 281 |  |
| End user | 74 |  |  | 96 |  |
| Total | $ | 314 |  |  | $ | 377 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (82 | ) |  | $ | (85 | ) |
| End user | (52 | ) |  | (76 | ) |
| Total | $ | (134 | ) |  | $ | (161 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue | $ | 180 |  |  | $ | 216 |  |

[0000858877-17-000016:notes:106]
Other Guarantees   The Company’s other guarantee arrangements as of July 29, 2017 and July 30, 2016 that were subject to recognition and disclosure requirements were not material.

[0000858877-17-000016:notes:107]
| (f) | Supplier Component Remediation Liability |

[0000858877-17-000016:notes:108]
In fiscal 2014, the Company recorded a charge to product cost of sales of $655 million resulting from failures related to products containing memory components manufactured by a single supplier between 2005 and 2010. The Company performs regular assessments of the sufficiency of this liability and reduced the amount by $74 million and $164 million in fiscal 2016 and fiscal 2015, respectively based on updated analyses. During the second quarter of fiscal 2017, the Company further reduced the liability by $141 million to reflect lower than expected defects, actual usage history, and estimated lower future remediation costs as more of the impacted products age and near the end of the support period covered by the remediation program. In addition, during the second quarter of fiscal 2017, the Company recorded a charge to product cost of sales of $125 million related to the expected remediation costs for anticipated failures in future periods of a widely-used component sourced from a third party which is included in several of the Company's products. The liabilities related to the supplier component remediation matters were $174 million and $276 million as of July 29, 2017 and July 30, 2016, respectively.

[0000858877-17-000016:notes:109]
| (g) | Indemnifications |

[0000858877-17-000016:notes:110]
In the normal course of business, the Company indemnifies other parties, including customers, lessors, and parties to other transactions with the Company, with respect to certain matters. The Company has agreed to hold such parties harmless against losses arising from a breach of representations or covenants or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim.

[0000858877-17-000016:notes:111]
The Company has been asked to indemnify certain of the Company’s service provider customers that are subject to patent infringement claims asserted by Sprint Communications Company, L.P. in federal court in Kansas and Delaware. Sprint alleges that the service provider customers infringe Sprint’s patents by offering VoIP telephone services utilizing products provided by the Company and other manufacturers. Sprint seeks monetary damages. Following a trial on March 3, 2017, a jury in Kansas found that Time Warner Cable willfully infringed five Sprint patents and awarded Sprint $139.8 million in damages. On March 14, 2017, the Kansas court declined Sprint's request for enhanced damages and entered judgment in favor of Sprint for $139.8 million plus 1.06% in post-judgment interest. On May 30, 2017, the Court awarded Sprint $20.3 million in pre-judgment interest and denied Time Warner Cable's post-trial motions. Time Warner Cable has appealed. Sprint's trial against Comcast in Kansas was continued until October 30, 2017, and its trial against Cox in Delaware is scheduled for December 7, 2017.

[0000858877-17-000016:notes:112]
The Company believes that the service providers have strong defenses and arguments at trial and/or appeal that the Company's products do not infringe the patents and/or that Sprint's patents are invalid and/or that Sprint's damages claims are inconsistent with prevailing law.  Due to the uncertainty surrounding the litigation process, the Company is unable to reasonably estimate the ultimate outcome of this litigation at this time.  Should Sprint prevail in litigation, mediation, or settlement, the Company, in accordance with its agreements, may have an obligation to indemnify its service provider customers for damages, mediation awards, or settlement amounts arising from their use of Cisco products. At this time, the Company does not anticipate that its obligations regarding the final outcome of the matters would be material.

[0000858877-17-000016:notes:113]
On January 15, 2016, Huawei Technologies Co. Ltd. (“Huawei”) filed four patent infringement actions against T-Mobile US, Inc. and T-Mobile USA, Inc. (collectively, “T-Mobile”) in federal court in the Eastern District of Texas. Huawei alleges that T-Mobile’s use of 3GPP standards to implement its 3G and 4G cellular networks infringe 12 patents. Huawei's infringement allegations for some of the patents are based in part on T-Mobile's use of products provided by the Company and other manufacturers. T-Mobile has requested indemnity by the Company with respect to portions of the network that use the Company's equipment. A jury trial is scheduled to commence with jury selection on October 2, 2017.

[0000858877-17-000016:notes:114]
The Company believes that the patents are invalid and/or not infringed, and that Huawei’s claims should be rejected for Huawei's failure to comply with its licensing and disclosure obligations to standards setting organizations that issued the relevant standards. If T-Mobile is found to infringe any of the patents warranting an award of damages, the Company believes damages against T-Mobile, as appropriately measured, should be governed by reasonable and nondiscriminatory licensing principles. Due to uncertainty surrounding patent litigation processes, however, the Company is unable to reasonably estimate the ultimate outcome of this litigation and the Company does not anticipate that its obligations, if any, regarding the final outcome of the matters would be material.

[0000858877-17-000016:notes:115]
In addition, the Company has entered into indemnification agreements with its officers and directors, and the Company’s Amended and Restated Bylaws contain similar indemnification obligations to the Company’s agents.

[0000858877-17-000016:notes:116]
It is not possible to determine the maximum potential amount under these indemnification agreements due to the Company’s limited history with prior indemnification claims and the unique facts and circumstances involved in each particular agreement. Historically, payments made by the Company under these agreements have not had a material effect on the Company’s operating results, financial position, or cash flows.

[0000858877-17-000016:notes:117]
| (h) | Legal Proceedings |

[0000858877-17-000016:notes:118]
Brazil    Brazilian authorities have investigated the Company’s Brazilian subsidiary and certain of its former employees, as well as a Brazilian importer of the Company’s products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against the Company’s Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years.

[0000858877-17-000016:notes:119]
The asserted claims by Brazilian federal tax authorities that remain are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $258 million for the alleged evasion of import and other taxes, $1.5 billion for interest, and $1.2 billion for various penalties, all determined using an exchange rate as of July 29, 2017. The Company has completed a thorough review of the matters and believes the asserted claims against the Company’s Brazilian subsidiary are without merit, and the Company is defending the claims vigorously. While the Company believes there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, the Company is unable to determine the likelihood of an unfavorable outcome against its Brazilian subsidiary and is unable to reasonably estimate a range of loss, if any. The Company does not expect a final judicial determination for several years.

[0000858877-17-000016:notes:120]
SRI International     On September 4, 2013, SRI International, Inc. (“SRI”) asserted patent infringement claims against the Company in the U.S. District Court for the District of Delaware, accusing the Company's products and services in the area of network intrusion detection of infringing two U.S. patents. SRI sought monetary damages of at least a reasonable royalty and enhanced damages. The trial on these claims began on May 2, 2016 and on May 12, 2016, the jury returned a verdict finding willful infringement of the asserted patents. The jury awarded SRI damages of $23.7 million. On May 25, 2017, the Court awarded SRI enhanced damages and attorneys’ fees, entered judgment in the new amount of $57.0 million, and ordered an ongoing royalty of 3.5% through the expiration of the patents in 2018. The Company has appealed to the United States Court of Appeals for the Federal Circuit on various grounds. The Company believes it has strong arguments to overturn the jury verdict and/or reduce the damages award. While the ultimate outcome of the case may still result in a loss, the Company does not expect it to be material.

[0000858877-17-000016:notes:121]
SSL     SSL Services, LLC (“SSL”) has asserted claims for patent infringement against the Company in the U.S. District Court for the Eastern District of Texas. The proceeding was instituted on March 25, 2015. SSL alleges that the Company's AnyConnect products that include Virtual Private Networking functions infringed a U.S. patent owned by SSL. SSL seeks money damages from the Company. On August 18, 2015, the Company petitioned the Patent Trial and Appeal Board (“PTAB”) of the United States Patent and Trademark Office to review whether the patent SSL has asserted against the Company is valid over prior art.  On February 23, 2016, a PTAB multi-judge panel found a reasonable likelihood that the Company would prevail in showing that SSL’s patent claims are unpatentable and instituted proceedings. On June 28, 2016, in light of the PTAB's decision to review the patent's validity, the district court issued an order staying the district court case pending the final written decision from the PTAB. On February 22, 2017, following a hearing, the PTAB issued its Final Written Decision that the patent's claims are unpatentable. SSL has filed a notice that it intends to appeal this decision to the Court of Appeals for the Federal Circuit. The Company believes it has strong arguments that the Company's products do not infringe and the patent is invalid.  If the Company does not prevail and a jury were to find that the Company's AnyConnect products infringe, the Company believes damages, as appropriately measured, would be immaterial. Due to uncertainty surrounding patent litigation processes, the Company is unable to reasonably estimate the ultimate outcome of this litigation at this time.

[0000858877-17-000016:notes:122]
Straight Path     On September 24, 2014, Straight Path IP Group, Inc. (“Straight Path”) asserted patent infringement claims against the Company in U.S. District Court for the Northern District of California, accusing the Company’s 9971 IP Phone, Unified Communications Manager working in conjunction with 9971 IP Phones, and Video Communication Server products of infringement. All of the asserted patents have expired, so Straight Path seeks monetary damages for the alleged past infringement. The Company believes it has strong non-infringement and other defenses. A jury trial is scheduled for December 4, 2017. If the Company does not prevail and a jury were to find that the Company's products infringe, the Company believes damages, as appropriately measured, would be immaterial. Due to uncertainty surrounding patent litigation processes, the Company is unable to reasonably estimate the ultimate outcome of this litigation at this time.

[0000858877-17-000016:notes:123]
DXC Technology     On August 21, 2015, the Company and Cisco Systems Capital Corporation (“Cisco Capital”) filed an action in Santa Clara County Superior Court for declaratory judgment and breach of contract against HP Inc. (“HP”) regarding a services agreement for management services of a third party’s network. HP prepaid the service agreement through a financing arrangement with Cisco Capital. HP terminated its agreement with the Company, and pursuant to the terms of the service agreement with HP, the Company determined the credit HP was entitled to receive under the agreement. HP disputed the Company’s credit calculation and contended that the Company owes a larger credit to HP than the Company had calculated. In December 2015, the Company filed an amended complaint which dropped the breach of contract claim in light of HP’s continuing payments to Cisco Capital under the financing arrangement. On January 19, 2016, HP Inc. filed a counterclaim for breach of contract simultaneously with its answer to the amended complaint. The court has set a trial date of November 6, 2017. DXC Technology Corporation (“DXC”) reported that it is the party in interest in this matter pursuant to the Separation and Distribution Agreement between the then Hewlett-Packard Co. and Hewlett Packard Enterprise Company (“HPE") and the subsequent Separation and Distribution Agreement between HPE and DXC. On August 30, 2017, the Company and DXC attended a court ordered mediation and, on September 1, 2017, the parties jointly informed the court that they are continuing to discuss the details of a business resolution to the dispute. The Company is unable to reasonably estimate the ultimate outcome of this litigation due to uncertainty surrounding the litigation process. However, the Company does not anticipate that its obligation, if any, regarding the final outcome of the dispute would be material.

[0000858877-17-000016:notes:124]
In addition, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, the Company does not expect that the ultimate costs to resolve these matters will have a material adverse effect on its consolidated financial position, results of operations, or cash flows.


## us-gaap:CompensationRelatedCostsPolicyTextBlock

[0000858877-17-000016:notes:125]
(q) Share-Based Compensation Expense   The Company measures and recognizes the compensation expense for all share-based awards made to employees and directors, including employee stock options, restricted stock units (RSUs), PRSUs, and employee stock purchases related to the Employee Stock Purchase Plan (Employee Stock Purchase Rights) based on estimated fair values. The fair value of employee stock options is estimated on the date of grant using a lattice-binomial option-pricing model (Lattice-Binomial Model) or the Black-Scholes model, and for employee stock purchase rights the Company estimates the fair value using the Black-Scholes model. The fair value for time-based stock awards and stock awards that are contingent upon the achievement of financial performance metrics is based on the grant date share price reduced by the present value of the expected dividend yield prior to vesting. The fair value of market-based stock awards is estimated using an option-pricing model on the date of grant. Share-based compensation expense is reduced for forfeitures.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000858877-17-000016:notes:126]
Comprehensive Income

[0000858877-17-000016:notes:127]
The components of AOCI, net of tax, and the other comprehensive income (loss), excluding noncontrolling interest, are summarized as follows (in millions):

[0000858877-17-000016:notes:128]
|  | Net Unrealized Gains (Losses) on Available-for-Sale Investments |  | Net Unrealized Gains (Losses) Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Actuarial Gains and Losses |  | Accumulated Other Comprehensive Income (Loss) |
| BALANCE AT JULY 26, 2014 | $ | 424 |  |  | $ | (12 | ) |  | $ | 265 |  |  | $ | 677 |  |
| Other comprehensive income (loss) before reclassifications attributable to Cisco Systems, Inc. | (28 | ) |  | (159 | ) |  | (563 | ) |  | (750 | ) |
| (Gains) losses reclassified out of AOCI | (157 | ) |  | 154 |  |  | 2 |  |  | (1 | ) |
| Tax benefit (expense) | 71 |  |  | 1 |  |  | 63 |  |  | 135 |  |
| BALANCE AT JULY 25, 2015 | 310 |  |  | (16 | ) |  | (233 | ) |  | 61 |  |
| Other comprehensive income (loss) before reclassifications attributable to Cisco Systems, Inc. | 151 |  |  | (66 | ) |  | (399 | ) |  | (314 | ) |
| (Gains) losses reclassified out of AOCI | 1 |  |  | 20 |  |  | (6 | ) |  | 15 |  |
| Tax benefit (expense) | (49 | ) |  | 3 |  |  | (42 | ) |  | (88 | ) |
| BALANCE AT JULY 30, 2016 | 413 |  |  | (59 | ) |  | (680 | ) |  | (326 | ) |
| Other comprehensive income (loss) before reclassifications attributable to Cisco Systems, Inc. | (164 | ) |  | 22 |  |  | 318 |  |  | 176 |  |
| (Gains) losses reclassified out of AOCI | 87 |  |  | 79 |  |  | 16 |  |  | 182 |  |
| Tax benefit (expense) | 37 |  |  | (10 | ) |  | (13 | ) |  | 14 |  |
| BALANCE AT JULY 29, 2017 | $ | 373 |  |  | $ | 32 |  |  | $ | (359 | ) |  | $ | 46 |  |

[0000858877-17-000016:notes:129]
The net gains (losses) reclassified out of AOCI into the Consolidated Statements of Operations, with line item location, during each period were as follows (in millions):

[0000858877-17-000016:notes:130]
|  |  | July 29, 2017 |  | July 30, 2016 |  | July 25, 2015 |  |  |
| Comprehensive Income Components |  | Income Before Taxes |  | Line Item in Statements of Operations |
| Net unrealized gains and losses on available-for-sale investments |  | $ | (87 | ) |  | $ | (1 | ) |  | $ | 157 |  |  | Other income (loss), net |
| Net unrealized gains and losses on cash flow hedging instruments |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | (59 | ) |  | (15 | ) |  | (121 | ) |  | Operating expenses |
| Foreign currency derivatives |  | (20 | ) |  | (5 | ) |  | (33 | ) |  | Cost of sales—service |
|  |  | (79 | ) |  | (20 | ) |  | (154 | ) |  |  |
| Cumulative translation adjustment and actuarial gains and losses |  | (16 | ) |  | 6 |  |  | (2 | ) |  | Operating expenses |
| Total amounts reclassified out of AOCI |  | $ | (182 | ) |  | $ | (15 | ) |  | $ | 1 |  |  |  |


## us-gaap:DebtDisclosureTextBlock

[0000858877-17-000016:notes:131]
Borrowings

[0000858877-17-000016:notes:132]
| (a) | Short-Term Debt |

[0000858877-17-000016:notes:133]
The following table summarizes the Company’s short-term debt (in millions, except percentages):

[0000858877-17-000016:notes:134]
|  | July 29, 2017 |  | July 30, 2016 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 4,747 |  |  | 1.66 | % |  | $ | 4,159 |  |  | 0.97 | % |
| Commercial paper | 3,245 |  |  | 1.16 | % |  | — |  |  | — | % |
| Other notes and borrowings | — |  |  | — | % |  | 1 |  |  | 2.08 | % |
| Total short-term debt | $ | 7,992 |  |  |  |  | $ | 4,160 |  |  |  |

[0000858877-17-000016:notes:135]
Effective March 31, 2017, the Company increased its borrowing capacity under its existing commercial paper program from $3.0 billion to $10.0 billion. The Company uses the proceeds from the issuance of commercial paper notes for general corporate purposes.

[0000858877-17-000016:notes:136]
The effective rates for the short- and long-term debt include the interest on the notes, the accretion of the discount, the issuance costs, and, if applicable, adjustments related to hedging.

[0000858877-17-000016:notes:137]
| (b) | Long-Term Debt |

[0000858877-17-000016:notes:138]
The following table summarizes the Company’s long-term debt (in millions, except percentages):

[0000858877-17-000016:notes:139]
|  |  |  | July 29, 2017 |  | July 30, 2016 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.28% | March 3, 2017 | (1) | $ | — |  |  | — |  | $ | 1,000 |  |  | 1.03% |
| Three-month LIBOR plus 0.60% | February 21, 2018 |  | 1,000 |  |  | 1.84% |  | 1,000 |  |  | 1.32% |
| Three-month LIBOR plus 0.31% | June 15, 2018 |  | 900 |  |  | 1.62% |  | 900 |  |  | 1.03% |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | 500 |  |  | 1.76% |  | 500 |  |  | 1.23% |
| Three-month LIBOR plus 0.34% | September 20, 2019 | (2) | 500 |  |  | 1.66% |  | — |  |  | — |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 1.10% | March 3, 2017 | (1) | — |  |  | — |  | 2,400 |  |  | 0.87% |
| 3.15% | March 14, 2017 | (1) | — |  |  | — |  | 750 |  |  | 1.22% |
| 1.40% | February 28, 2018 |  | 1,250 |  |  | 1.47% |  | 1,250 |  |  | 1.47% |
| 1.65% | June 15, 2018 |  | 1,600 |  |  | 1.72% |  | 1,600 |  |  | 1.72% |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 4.96% |  | 2,000 |  |  | 4.76% |
| 1.60% | February 28, 2019 |  | 1,000 |  |  | 1.67% |  | 1,000 |  |  | 1.67% |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 1.84% |  | 1,750 |  |  | 1.08% |
| 1.40% | September 20, 2019 | (2) | 1,500 |  |  | 1.48% |  | — |  |  | — |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 3.84% |  | 2,500 |  |  | 3.25% |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 2.54% |  | 1,500 |  |  | 2.54% |
| 2.20% | February 28, 2021 |  | 2,500 |  |  | 2.30% |  | 2,500 |  |  | 2.30% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 2.00% |  | 500 |  |  | 1.24% |
| 1.85% | September 20, 2021 | (2) | 2,000 |  |  | 1.90% |  | — |  |  | — |
| 3.00% | June 15, 2022 |  | 500 |  |  | 2.26% |  | 500 |  |  | 1.51% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 | (2) | 750 |  |  | 2.27% |  | — |  |  | — |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 2.12% |  | 1,000 |  |  | 1.36% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 2.43% |  | 500 |  |  | 1.67% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 | (2) | 1,500 |  |  | 2.55% |  | — |  |  | — |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 30,500 |  |  |  |  | 28,400 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (136 | ) |  |  |  | (137 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 108 |  |  |  |  | 379 |  |  |  |
| Total |  |  | $ | 30,472 |  |  |  |  | $ | 28,642 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 4,747 |  |  |  |  | $ | 4,159 |  |  |  |
| Long-term debt |  |  | 25,725 |  |  |  |  | 24,483 |  |  |  |
| Total |  |  | $ | 30,472 |  |  |  |  | $ | 28,642 |  |  |  |

[0000858877-17-000016:notes:140]
(1) In March 2017, the Company repaid senior notes with an aggregate principal amount of $4.15 billion upon maturity.

[0000858877-17-000016:notes:141]
(2) In September 2016, the Company issued senior notes for an aggregate principal amount of $6.25 billion.

[0000858877-17-000016:notes:142]
The Company entered into interest rate swaps in prior periods with an aggregate notional amount of $6.75 billion designated as fair value hedges of certain of its fixed-rate senior notes.  These swaps convert the fixed interest rates of the fixed-rate notes to floating interest rates based on the London InterBank Offered Rate (LIBOR).  The gains and losses related to changes in the fair value of the interest rate swaps substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates.  For additional information, see Note 11.

[0000858877-17-000016:notes:143]
Interest is payable semiannually on each class of the senior fixed-rate notes and payable quarterly on the floating-rate notes.  Each of the senior fixed-rate notes is redeemable by the Company at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that have been issued in the future pursuant to the Company’s short-term debt financing program, as discussed above under “(a) Short-Term Debt.”  As of July 29, 2017, the Company was in compliance with all debt covenants.

[0000858877-17-000016:notes:144]
As of July 29, 2017, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

[0000858877-17-000016:notes:145]
| Fiscal Year | Amount |
| 2018 | $ | 4,750 |  |
| 2019 | 5,250 |  |
| 2020 | 6,000 |  |
| 2021 | 3,000 |  |
| 2022 | 2,500 |  |
| Thereafter | 9,000 |  |
| Total | $ | 30,500 |  |

[0000858877-17-000016:notes:146]
| (c) | Credit Facilities |

[0000858877-17-000016:notes:147]
On May 15, 2015, the Company entered into a credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 15, 2020. Any advances under the credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (i) the highest of (a) the Federal Funds rate plus 0.50%, (b) Bank of America’s “prime rate” as announced from time to time, or (c) LIBOR, or a comparable or successor rate that is approved by the Administrative Agent (“Eurocurrency Rate”), for an interest period of one-month plus 1.00%, or (ii) the Eurocurrency Rate, plus a margin that is based on the Company’s senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the Eurocurrency Rate be less than zero. The Company may also, upon agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and/or extend the expiration date of the credit facility up to May 15, 2022.

[0000858877-17-000016:notes:148]
In addition, on March 30, 2017, the Company entered into a 364-Day credit agreement with certain institutional lenders that provides for a $2.0 billion unsecured revolving credit facility that is scheduled to expire on March 29, 2018. The credit agreement also provides the Company with the option to, for a fee, convert any borrowings outstanding thereunder on March 29, 2018 to a term loan maturing no later than March 29, 2019. The interest rate applicable to outstanding balances under the credit agreement will be based on either (i) the higher of (a) the rates on overnight Federal Funds transactions with members of the Federal Reserve System (i.e. Federal Funds rate) plus 0.50%, (b) Bank of America's "prime rate" as announced from time to time or (c) LIBOR for an interest period of one month plus 1.00%, or (ii) LIBOR plus a margin that is based on the Company's senior debt credit ratings as published by S&P Global Rating, a business unit of Standard & Poor's Financial Services LLC, and Moody's Investors Service, Inc.

[0000858877-17-000016:notes:149]
These credit agreements require that the Company comply with certain covenants, including that the Company maintains an interest coverage ratio as defined in these agreements. As of July 29, 2017, the Company was in compliance with the required interest coverage ratio and the other covenants, and the Company had not borrowed any funds under the credit facility.


## us-gaap:DeferredRevenueByArrangementDisclosureTextBlock

[0000858877-17-000016:notes:150]
| Deferred revenue: |  |  |  |  |
| Service |  | $ | 11,302 |  |  | $ | 10,621 |  |
| Product: |  |  |  |  |
| Deferred revenue related to recurring software and subscription offers |  | 4,971 |  |  | 3,308 |  |
| Other product deferred revenue |  | 2,221 |  |  | 2,543 |  |
| Total product deferred revenue |  | 7,192 |  |  | 5,851 |  |
| Total |  | $ | 18,494 |  |  | $ | 16,472 |  |
| Reported as: |  |  |  |  |
| Current |  | $ | 10,821 |  |  | $ | 10,155 |  |
| Noncurrent |  | 7,673 |  |  | 6,317 |  |
| Total |  | $ | 18,494 |  |  | $ | 16,472 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000858877-17-000016:notes:151]
Derivative Instruments

[0000858877-17-000016:notes:152]
| (a) | Summary of Derivative Instruments |

[0000858877-17-000016:notes:153]
The Company uses derivative instruments primarily to manage exposures to foreign currency exchange rate, interest rate, and equity price risks. The Company’s primary objective in holding derivatives is to reduce the volatility of earnings and cash flows associated with changes in foreign currency exchange rates, interest rates, and equity prices. The Company’s derivatives expose it to credit risk to the extent that the counterparties may be unable to meet the terms of the agreement. The Company does, however, seek to mitigate such risks by limiting its counterparties to major financial institutions. In addition, the potential risk of loss with any one counterparty resulting from this type of credit risk is monitored. Management does not expect material losses as a result of defaults by counterparties.

[0000858877-17-000016:notes:154]
The fair values of the Company’s derivative instruments and the line items on the Consolidated Balance Sheets to which they were recorded are summarized as follows (in millions):

[0000858877-17-000016:notes:155]
|  | DERIVATIVE ASSETS |  | DERIVATIVE LIABILITIES |
|  | Balance Sheet Line Item |  | July 29, 2017 |  | July 30, 2016 |  | Balance Sheet Line Item |  | July 29, 2017 |  | July 30, 2016 |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | $ | 46 |  |  | $ | 7 |  |  | Other current liabilities |  | $ | 1 |  |  | $ | 53 |  |
| Interest rate derivatives | Other current assets |  | — |  |  | 11 |  |  | Other current liabilities |  | — |  |  | — |  |
| Interest rate derivatives | Other assets |  | 102 |  |  | 366 |  |  | Other long-term liabilities |  | — |  |  | — |  |
| Total |  |  | 148 |  |  | 384 |  |  |  |  | 1 |  |  | 53 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | 1 |  |  | — |  |  | Other current liabilities |  | 3 |  |  | 1 |  |
| Equity derivatives/warrants | Other assets |  | — |  |  | 1 |  |  | Other long-term liabilities |  | — |  |  | — |  |
| Total |  |  | 1 |  |  | 1 |  |  |  |  | 3 |  |  | 1 |  |
| Total |  |  | $ | 149 |  |  | $ | 385 |  |  |  |  | $ | 4 |  |  | $ | 54 |  |

[0000858877-17-000016:notes:156]
The effects of the Company’s cash flow and net investment hedging instruments on other comprehensive income (OCI) and the Consolidated Statements of Operations are summarized as follows (in millions):

[0000858877-17-000016:notes:157]
| GAINS (LOSSES) RECOGNIZEDIN OCI ON DERIVATIVES FORTHE YEARS ENDED (EFFECTIVE PORTION) |  | GAINS (LOSSES) RECLASSIFIED FROMAOCI INTO INCOME FORTHE YEARS ENDED (EFFECTIVE PORTION) |
|  |  | July 29, 2017 |  | July 30, 2016 |  | July 25, 2015 |  | Line Item in Statements of Operations |  | July 29, 2017 |  | July 30, 2016 |  | July 25, 2015 |
| Derivatives designated as cash flow hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | 22 |  |  | $ | (66 | ) |  | $ | (159 | ) |  | Operating expenses |  | $ | (59 | ) |  | $ | (15 | ) |  | $ | (121 | ) |
|  |  |  |  |  |  |  |  | Cost of sales—service |  | (20 | ) |  | (5 | ) |  | (33 | ) |
| Total |  | $ | 22 |  |  | $ | (66 | ) |  | $ | (159 | ) |  | Total |  | $ | (79 | ) |  | $ | (20 | ) |  | $ | (154 | ) |
| Derivatives designated as net investment hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | (15 | ) |  | $ | 16 |  |  | $ | 42 |  |  | Other income (loss), net |  | $ | — |  |  | $ | — |  |  | $ | — |  |

[0000858877-17-000016:notes:158]
As of July 29, 2017, the Company estimates that approximately $49 million of net derivative gains related to its cash flow hedges included in accumulated other comprehensive income (AOCI) will be reclassified into earnings within the next 12 months when the underlying hedged item impacts earnings.

[0000858877-17-000016:notes:159]
The effect on the Consolidated Statements of Operations of derivative instruments not designated as hedges is summarized as follows (in millions):

[0000858877-17-000016:notes:160]
|  |  |  |  | GAINS (LOSSES) FOR THE YEARS ENDED |
| Derivatives Not Designated as Hedging Instruments |  | Line Item in Statements of Operations |  | July 29, 2017 |  | July 30, 2016 |  | July 25, 2015 |
| Foreign currency derivatives |  | Other income (loss), net |  | $ | 13 |  |  | $ | (19 | ) |  | $ | (173 | ) |
| Total return swaps—deferred compensation |  | Operating expenses |  | 58 |  |  | 7 |  |  | 19 |  |
| Equity derivatives |  | Other income (loss), net |  | 11 |  |  | 13 |  |  | 27 |  |
| Total |  |  |  | $ | 82 |  |  | $ | 1 |  |  | $ | (127 | ) |

[0000858877-17-000016:notes:161]
The notional amounts of the Company’s outstanding derivatives are summarized as follows (in millions):

[0000858877-17-000016:notes:162]
|  | July 29, 2017 |  | July 30, 2016 |
| Derivatives designated as hedging instruments: |  |  |  |
| Foreign currency derivatives—cash flow hedges | $ | 1,696 |  |  | $ | 2,683 |  |
| Interest rate derivatives | 6,750 |  |  | 9,900 |  |
| Net investment hedging instruments | 351 |  |  | 298 |  |
| Derivatives not designated as hedging instruments: |  |  |  |
| Foreign currency derivatives | 2,258 |  |  | 2,057 |  |
| Total return swaps—deferred compensation | 535 |  |  | 476 |  |
| Total | $ | 11,590 |  |  | $ | 15,414 |  |

[0000858877-17-000016:notes:163]
| (b) | Offsetting of Derivative Instruments |

[0000858877-17-000016:notes:164]
The Company presents its derivative instruments at gross fair values in the Consolidated Balance Sheets.  However, the Company’s master netting and other similar arrangements with the respective counterparties allow for net settlement under certain conditions, which are designed to reduce credit risk by permitting net settlement with the same counterparty.  To further limit credit risk, the Company also enters into collateral security arrangements related to certain derivative instruments whereby cash is posted as collateral between the counterparties based on the fair market value of the derivative instrument. Information related to these offsetting arrangements is summarized as follows (in millions):

[0000858877-17-000016:notes:165]
|  | GROSS AMOUNTS OFFSET IN THE CONSOLIDATED BALANCE SHEET |  | GROSS AMOUNTS NOT OFFSET IN THE CONSOLIDATED BALANCE SHEETBUT WITH LEGAL RIGHTS TO OFFSET |
| July 29, 2017 | Gross Amounts Recognized |  | Gross Amounts Offset |  | Net Amounts Presented |  | Gross Derivative Amounts |  | Cash Collateral |  | Net Amount |
| Derivatives assets | $ | 149 |  |  | $ | — |  |  | $ | 149 |  |  | $ | (4 | ) |  | $ | (81 | ) |  | $ | 64 |  |
| Derivatives liabilities | $ | 4 |  |  | $ | — |  |  | $ | 4 |  |  | $ | (4 | ) |  | $ | — |  |  | $ | — |  |

[0000858877-17-000016:notes:166]
|  | GROSS AMOUNTS OFFSET IN THE CONSOLIDATED BALANCE SHEET |  | GROSS AMOUNTS NOT OFFSET IN THE CONSOLIDATED BALANCE SHEETBUT WITH LEGAL RIGHTS TO OFFSET |
| July 30, 2016 | Gross Amounts Recognized |  | Gross Amounts Offset |  | Net Amounts Presented |  | Gross Derivative Amounts |  | Cash Collateral |  | Net Amount |
| Derivatives assets | $ | 385 |  |  | $ | — |  |  | $ | 385 |  |  | $ | (23 | ) |  | $ | (305 | ) |  | $ | 57 |  |
| Derivatives liabilities | $ | 54 |  |  | $ | — |  |  | $ | 54 |  |  | $ | (23 | ) |  | $ | — |  |  | $ | 31 |  |

[0000858877-17-000016:notes:167]
| (c) | Foreign Currency Exchange Risk |

[0000858877-17-000016:notes:168]
The Company conducts business globally in numerous currencies. Therefore, it is exposed to adverse movements in foreign currency exchange rates. To limit the exposure related to foreign currency changes, the Company enters into foreign currency contracts. The Company does not enter into such contracts for speculative purposes.

[0000858877-17-000016:notes:169]
The Company hedges forecasted foreign currency transactions related to certain operating expenses and service cost of sales with currency options and forward contracts. These currency options and forward contracts, designated as cash flow hedges, generally have maturities of less than 24 months. The Company assesses effectiveness based on changes in total fair value of the derivatives. The effective portion of the derivative instrument’s gain or loss is initially reported as a component of AOCI and subsequently reclassified into earnings when the hedged exposure affects earnings. The ineffective portion, if any, of the gain or loss is reported in earnings immediately. During the fiscal years presented, the Company did not discontinue any cash flow hedges for which it was probable that a forecasted transaction would not occur.

[0000858877-17-000016:notes:170]
The Company enters into foreign exchange forward and option contracts to reduce the short-term effects of foreign currency fluctuations on assets and liabilities such as foreign currency receivables, including long-term customer financings, investments, and payables. These derivatives are not designated as hedging instruments. Gains and losses on the contracts are included in other income (loss), net, and substantially offset foreign exchange gains and losses from the remeasurement of intercompany balances or other current assets, investments, or liabilities denominated in currencies other than the functional currency of the reporting entity.

[0000858877-17-000016:notes:171]
The Company hedges certain net investments in its foreign operations with forward contracts to reduce the effects of foreign currency fluctuations on the Company’s net investment in those foreign subsidiaries. These derivative instruments generally have maturities of up to six months.

[0000858877-17-000016:notes:172]
| (d) | Interest Rate Risk |

[0000858877-17-000016:notes:173]
Interest Rate Derivatives, Investments   The Company’s primary objective for holding fixed income securities is to achieve an appropriate investment return consistent with preserving principal and managing risk. To realize these objectives, the Company may utilize interest rate swaps or other derivatives designated as fair value or cash flow hedges. As of July 29, 2017 and July 30, 2016, the Company did not have any outstanding interest rate derivatives related to its fixed income securities.

[0000858877-17-000016:notes:174]
Interest Rate Derivatives Designated as Fair Value Hedges, Long-Term Debt   In fiscal 2017, the Company did not enter into any interest rate swaps. In prior fiscal years, the Company entered into interest rate swaps designated as fair value hedges related to fixed-rate senior notes that are due in fiscal 2019 through 2025. Under these interest rate swaps, the Company receives fixed-rate interest payments and makes interest payments based on LIBOR plus a fixed number of basis points. The effect of such swaps is to convert the fixed interest rates of the senior fixed-rate notes to floating interest rates based on LIBOR. The gains and losses related to changes in the fair value of the interest rate swaps are included in interest expense and substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates. The fair value of the interest rate swaps was reflected in other current assets and other assets.

[0000858877-17-000016:notes:175]
| (e) | Equity Price Risk |

[0000858877-17-000016:notes:176]
The Company may hold equity securities for strategic purposes or to diversify its overall investment portfolio. The publicly traded equity securities in the Company’s portfolio are subject to price risk. To manage its exposure to changes in the fair value of certain equity securities, the Company has periodically entered into equity derivatives that are designated as fair value hedges. The changes in the value of the hedging instruments are included in other income (loss), net, and offset the change in the fair value of the underlying hedged investment. In addition, the Company periodically enters into equity derivatives that are not designated as accounting hedges. The changes in the fair value of these derivatives are also included in other income (loss), net.

[0000858877-17-000016:notes:177]
The Company is also exposed to variability in compensation charges related to certain deferred compensation obligations to employees. Although not designated as accounting hedges, the Company utilizes derivatives such as total return swaps to economically hedge this exposure.

[0000858877-17-000016:notes:178]
| (f) | Hedge Effectiveness |

[0000858877-17-000016:notes:179]
For the fiscal years presented, amounts excluded from the assessment of hedge effectiveness were not material for fair value, cash flow, and net investment hedges. In addition, hedge ineffectiveness for fair value, cash flow, and net investment hedges was not material for any of the fiscal years presented.


## us-gaap:DerivativesPolicyTextBlock

[0000858877-17-000016:notes:180]
(l) Derivative Instruments   The Company recognizes derivative instruments as either assets or liabilities and measures those instruments at fair value. The accounting for changes in the fair value of a derivative depends on the intended use of the derivative and the resulting designation. For a derivative instrument designated as a fair value hedge, the gain or loss is recognized in earnings in the period of change together with the offsetting loss or gain on the hedged item attributed to the risk being hedged. For a derivative instrument designated as a cash flow hedge, the effective portion of the derivative’s gain or loss is initially reported as a component of AOCI and subsequently reclassified into earnings when the hedged exposure affects earnings. The ineffective portion of the gain or loss is reported in earnings immediately. For a derivative instrument designated as a net investment hedge of the Company’s foreign operations, the gain or loss is recorded in the cumulative translation adjustment within AOCI together with the offsetting loss or gain of the hedged exposure of the underlying foreign operations. Any ineffective portion of the net investment hedges is reported in earnings during the period of change. For derivative instruments that are not designated as accounting hedges, changes in fair value are recognized in earnings in the period of change. The Company records derivative instruments in the statements of cash flows to operating, investing, or financing activities consistent with the cash flows of the hedged item.

[0000858877-17-000016:notes:181]
Hedge effectiveness for foreign exchange forward contracts used as cash flow hedges is assessed by comparing the change in the fair value of the hedge contract with the change in the fair value of the forecasted cash flows of the hedged item. Hedge effectiveness for equity forward contracts and foreign exchange net investment hedge forward contracts is assessed by comparing changes in fair value due to changes in spot rates for both the derivative and the hedged item. For foreign exchange option contracts, hedge effectiveness is assessed based on the hedging instrument’s entire change in fair value. Hedge effectiveness for interest rate swaps is assessed by comparing the change in fair value of the swap with the change in the fair value of the hedged item due to changes in the benchmark interest rate.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000858877-17-000016:notes:182]
| 14. | Employee Benefit Plans |

[0000858877-17-000016:notes:183]
| (a) | Employee Stock Incentive Plans |

[0000858877-17-000016:notes:184]
Stock Incentive Plan Program Description    As of July 29, 2017, the Company had one stock incentive plan: the 2005 Stock Incentive Plan (the “2005 Plan”). In addition, the Company has, in connection with the acquisitions of various companies, assumed the share-based awards granted under stock incentive plans of the acquired companies or issued share-based awards in replacement thereof. Share-based awards are designed to reward employees for their long-term contributions to the Company and provide incentives for them to remain with the Company. The number and frequency of share-based awards are based on competitive practices, operating results of the Company, government regulations, and other factors. The Company’s primary stock incentive plan is summarized as follows:

[0000858877-17-000016:notes:185]
2005 Plan    As of July 29, 2017, the maximum number of shares issuable under the 2005 Plan over its term was 694 million shares, plus shares from certain previous plans that are forfeited or are terminated for any other reason before being exercised or settled. If any awards granted under the 2005 Plan are forfeited or are terminated for any other reason before being exercised or settled, the unexercised or unsettled shares underlying the awards will again be available under the 2005 Plan. In addition, starting November 19, 2013, shares withheld by the Company from an award other than a stock option or stock appreciation right to satisfy withholding tax liabilities resulting from such award will again be available for issuance, based on the fungible share ratio in effect on the date of grant.

[0000858877-17-000016:notes:186]
Pursuant to an amendment approved by the Company’s shareholders on November 12, 2009, the number of shares available for issuance under the 2005 Plan is reduced by 1.5 shares for each share awarded as a stock grant or a stock unit, and any shares underlying awards outstanding from certain previous plans that expire unexercised at the end of their maximum terms become available for reissuance under the 2005 Plan. The 2005 Plan permits the granting of stock options, restricted stock, and RSUs, the vesting of which may be performance-based or market-based along with the requisite service requirement, and stock appreciation rights to employees (including employee directors and officers), consultants of the Company and its subsidiaries and affiliates, and non-employee directors of the Company. Stock options and stock appreciation rights granted under the 2005 Plan have an exercise price of at least 100% of the fair market value of the underlying stock on the grant date. The expiration date for stock options and stock appreciation rights shall be no later than 10 years from the grant date.

[0000858877-17-000016:notes:187]
The stock options will generally become exercisable for 20% or 25% of the option shares one year from the date of grant and then ratably over the following 48 months or 36 months, respectively. Time-based stock grants and time-based RSUs will generally vest with respect to 20% or 25% of the shares or share units covered by the grant annually over the vesting period.  The majority of the performance-based and market-based RSUs vests at the end of the three-year requisite service period or earlier if the award recipient meets certain retirement eligibility conditions. Certain performance-based RSUs that are based on the achievement of financial and/or non-financial operating goals typically vest upon the achievement of milestones (and may require subsequent service periods), with overall vesting of the shares underlying the award ranging from six months to three years.  The Compensation and Management Development Committee of the Board of Directors has the discretion to use different vesting schedules. Stock appreciation rights may be awarded in combination with stock options or stock grants, and such awards shall provide that the stock appreciation rights will not be exercisable unless the related stock options or stock grants are forfeited. Stock grants may be awarded in combination with non-statutory stock options, and such awards may provide that the stock grants will be forfeited in the event that the related non-statutory stock options are exercised. As of July 29, 2017, there are no outstanding stock options or stock appreciation rights under the 2005 Plan.

[0000858877-17-000016:notes:188]
| (b) | Employee Stock Purchase Plan |

[0000858877-17-000016:notes:189]
The Company has an Employee Stock Purchase Plan, which includes its subplan named the International Employee Stock Purchase Plan (together, the “Purchase Plan”), under which 621 million shares of the Company’s common stock have been reserved for issuance as of July 29, 2017. Eligible employees are offered shares through a 24-month offering period, which consists of four consecutive 6-month purchase periods. Employees may purchase a limited number of shares of the Company’s stock at a discount of up to 15% of the lesser of the market value at the beginning of the offering period or the end of each 6-month purchase period. The Purchase Plan is scheduled to terminate on January 3, 2020. The Company issued 23 million, 25 million, and 27 million shares under the Purchase Plan in fiscal 2017, 2016, and 2015, respectively. As of July 29, 2017, 100 million shares were available for issuance under the Purchase Plan.

[0000858877-17-000016:notes:190]
| (c) | Summary of Share-Based Compensation Expense |

[0000858877-17-000016:notes:191]
Share-based compensation expense consists primarily of expenses for stock options, stock purchase rights, restricted stock, and restricted stock units granted to employees. The following table summarizes share-based compensation expense (in millions):

[0000858877-17-000016:notes:192]
| Years Ended | July 29, 2017 |  | July 30, 2016 |  | July 25, 2015 |
| Cost of sales—product | $ | 85 |  |  | $ | 70 |  |  | $ | 50 |  |
| Cost of sales—service | 134 |  |  | 142 |  |  | 157 |  |
| Share-based compensation expense in cost of sales | 219 |  |  | 212 |  |  | 207 |  |
| Research and development | 529 |  |  | 470 |  |  | 448 |  |
| Sales and marketing | 542 |  |  | 545 |  |  | 559 |  |
| General and administrative | 236 |  |  | 205 |  |  | 228 |  |
| Restructuring and other charges | 3 |  |  | 26 |  |  | (2 | ) |
| Share-based compensation expense in operating expenses | 1,310 |  |  | 1,246 |  |  | 1,233 |  |
| Total share-based compensation expense | $ | 1,529 |  |  | $ | 1,458 |  |  | $ | 1,440 |  |
| Income tax benefit for share-based compensation | $ | 451 |  |  | $ | 429 |  |  | $ | 373 |  |

[0000858877-17-000016:notes:193]
As of July 29, 2017, the total compensation cost related to unvested share-based awards not yet recognized was $3.0 billion, which is expected to be recognized over approximately 2.6 years on a weighted-average basis.

[0000858877-17-000016:notes:194]
| (d) | Share-Based Awards Available for Grant |

[0000858877-17-000016:notes:195]
A summary of share-based awards available for grant is as follows (in millions):

[0000858877-17-000016:notes:196]
| Years Ended | July 29, 2017 |  | July 30, 2016 |  | July 25, 2015 |
| Balance at beginning of fiscal year | 242 |  |  | 276 |  |  | 310 |  |
| Restricted stock, stock units, and other share-based awards granted | (76 | ) |  | (96 | ) |  | (101 | ) |
| Share-based awards canceled/forfeited/expired | 78 |  |  | 30 |  |  | 40 |  |
| Shares withheld for taxes and not issued | 28 |  |  | 30 |  |  | 27 |  |
| Other | — |  |  | 2 |  |  | — |  |
| Balance at end of fiscal year | 272 |  |  | 242 |  |  | 276 |  |

[0000858877-17-000016:notes:197]
For each share awarded as restricted stock or a restricted stock unit award under the 2005 Plan, 1.5 shares was deducted from the available share-based award balance. For restricted stock units that were awarded with vesting contingent upon the achievement of future financial performance or market-based metrics, the maximum awards that can be achieved upon full vesting of such awards were reflected in the preceding table.

[0000858877-17-000016:notes:198]
| (e) | Restricted Stock and Stock Unit Awards |

[0000858877-17-000016:notes:199]
A summary of the restricted stock and stock unit activity, which includes time-based and performance-based or market-based restricted stock units, is as follows (in millions, except per-share amounts):

[0000858877-17-000016:notes:200]
|  | Restricted Stock/Stock Units |  | Weighted-AverageGrant Date FairValue per Share |  | Aggregate Fair Value |
| UNVESTED BALANCE AT JULY 26, 2014 | 149 |  |  | $ | 19.54 |  |  |  |
| Granted | 66 |  |  | 25.23 |  |  |  |
| Assumed from acquisitions | 1 |  |  | 24.85 |  |  |  |
| Vested | (57 | ) |  | 19.82 |  |  | $ | 1,517 |  |
| Canceled/forfeited/other | (16 | ) |  | 19.67 |  |  |  |
| UNVESTED BALANCE AT JULY 25, 2015 | 143 |  |  | 22.08 |  |  |  |
| Granted | 62 |  |  | 25.90 |  |  |  |
| Assumed from acquisitions | 6 |  |  | 24.58 |  |  |  |
| Vested | (54 | ) |  | 20.68 |  |  | $ | 1,428 |  |
| Canceled/forfeited/other | (12 | ) |  | 22.91 |  |  |  |
| UNVESTED BALANCE AT JULY 30, 2016 | 145 |  |  | 24.26 |  |  |  |
| Granted | 50 |  |  | 27.89 |  |  |  |
| Assumed from acquisitions | 15 |  |  | 32.21 |  |  |  |
| Vested | (54 | ) |  | 23.14 |  |  | $ | 1,701 |  |
| Canceled/forfeited/other | (15 | ) |  | 23.56 |  |  |  |
| UNVESTED BALANCE AT JULY 29, 2017 | 141 |  |  | $ | 26.94 |  |  |  |

[0000858877-17-000016:notes:201]
| (f) | Stock Option Awards |

[0000858877-17-000016:notes:202]
A summary of the stock option activity is as follows (in millions, except per-share amounts):

[0000858877-17-000016:notes:203]
|  | STOCK OPTIONS OUTSTANDING |
|  | NumberOutstanding |  | Weighted-AverageExercise Price per Share |
| BALANCE AT JULY 26, 2014 | 187 |  |  | $ | 26.03 |  |
| Assumed from acquisitions | 1 |  |  | 2.60 |  |
| Exercised | (71 | ) |  | 21.15 |  |
| Canceled/forfeited/expired | (14 | ) |  | 29.68 |  |
| BALANCE AT JULY 25, 2015 | 103 |  |  | 28.68 |  |
| Assumed from acquisitions | 18 |  |  | 5.17 |  |
| Exercised | (32 | ) |  | 19.22 |  |
| Canceled/forfeited/expired | (16 | ) |  | 30.01 |  |
| BALANCE AT JULY 30, 2016 | 73 |  |  | 26.78 |  |
| Assumed from acquisitions | 8 |  |  | 4.47 |  |
| Exercised | (14 | ) |  | 12.11 |  |
| Canceled/forfeited/expired | (55 | ) |  | 31.83 |  |
| BALANCE AT JULY 29, 2017 | 12 |  |  | $ | 6.15 |  |

[0000858877-17-000016:notes:204]
The total pretax intrinsic value of stock options exercised during fiscal 2017, 2016, and 2015 was $283 million, $266 million, and $434 million, respectively.

[0000858877-17-000016:notes:205]
The following table summarizes significant ranges of outstanding and exercisable stock options as of July 29, 2017 (in millions, except years and share prices):

[0000858877-17-000016:notes:206]
|  |  | STOCK OPTIONS OUTSTANDING |  | STOCK OPTIONS EXERCISABLE |
| Range of Exercise Prices |  | NumberOutstanding |  | Weighted-AverageRemainingContractualLife(in Years) |  | Weighted-AverageExercisePrice perShare |  | AggregateIntrinsicValue |  | NumberExercisable |  | Weighted-AverageExercisePrice perShare |  | AggregateIntrinsicValue |
| $ 0.01 – 20.00 |  | 12 |  |  | 6.3 |  | $ | 6.15 |  |  | $ | 307 |  |  | 6 |  |  | $ | 5.61 |  |  | $ | 163 |  |

[0000858877-17-000016:notes:207]
The aggregate intrinsic value represents the total pretax intrinsic value, based on Cisco's closing stock price of $31.52 as of July 28, 2017, that would have been received by the option holders had those option holders exercised their stock options as of that date.  The total number of in-the-money stock options exercisable as of July 29, 2017 was 6 million. As of July 30, 2016, 64 million outstanding stock options were exercisable, and the weighted-average exercise price was $29.66.

[0000858877-17-000016:notes:208]
| (g) | Valuation of Employee Share-Based Awards |

[0000858877-17-000016:notes:209]
Time-based restricted stock units and PRSUs that are based on the Company’s financial performance metrics or non-financial operating goals are valued using the market value of the Company’s common stock on the date of grant, discounted for the present value of expected dividends. On the date of grant, the Company estimated the fair value of the total shareholder return (TSR) component of the PRSUs using a Monte Carlo simulation model. The assumptions for the valuation of time-based RSUs and PRSUs are summarized as follows:

[0000858877-17-000016:notes:210]
|  | RESTRICTED STOCK UNITS |
| Years Ended | July 29, 2017 |  | July 30, 2016 |  | July 25, 2015 |
| Number of shares granted (in millions) | 43 |  |  | 57 |  |  | 55 |  |
| Grant date fair value per share | $ | 28.38 |  |  | $ | 26.01 |  |  | $ | 25.30 |  |
| Weighted-average assumptions/inputs: |  |  |  |  |  |
| Expected dividend yield | 3.5 | % |  | 3.2 | % |  | 2.9 | % |
| Range of risk-free interest rates | 0.0% – 1.5% |  |  | 0.0% – 1.2% |  |  | 0.0% – 1.8% |  |

[0000858877-17-000016:notes:211]
|  | PERFORMANCE BASED RESTRICTED STOCK UNITS |
| Years Ended | July 29, 2017 |  | July 30, 2016 |  | July 25, 2015 |
| Number of shares granted (in millions) | 7 |  |  | 5 |  |  | 11 |  |
| Grant date fair value per share | $ | 28.94 |  |  | $ | 24.70 |  |  | $ | 24.85 |  |
| Weighted-average assumptions/inputs: |  |  |  |  |  |
| Expected dividend yield | 3.4 | % |  | 3.1 | % |  | 3.0 | % |
| Range of risk-free interest rates | 0.1% – 1.5% |  |  | 0.0% – 1.2% |  |  | 0.0% – 1.8% |  |
| Range of expected volatilities for index | 16.7% – 46.8% |  |  | 15.3% – 54.3% |  |  | 14.3% – 70.0% |  |

[0000858877-17-000016:notes:212]
The PRSUs granted during the fiscal years presented are contingent on the achievement of the Company’s financial performance metrics, its comparative market-based returns, or the achievement of financial and non-financial operating goals.  For the awards based on financial performance metrics or comparative market-based returns, generally 50% of the PRSUs are earned based on the average of annual operating cash flow and earnings per share goals established at the beginning of each fiscal year over a three-year performance period. Generally, the remaining 50% of the PRSUs are earned based on the Company’s TSR measured against the benchmark TSR of a peer group over the same period. Each PRSU recipient could vest in 0% to 150% of the target shares granted contingent on the achievement of the Company's financial performance metrics or its comparative market-based returns, and 0% to 100% of the target shares granted contingent on the achievement of non-financial operating goals.

[0000858877-17-000016:notes:213]
The assumptions for the valuation of employee stock purchase rights are summarized as follows:

[0000858877-17-000016:notes:214]
|  | EMPLOYEE STOCK PURCHASE RIGHTS |
| Years Ended | July 29, 2017 |  | July 30, 2016 |  | July 25, 2015 |
| Weighted-average assumptions: |  |  |  |  |  |
| Expected volatility | 24.6 | % |  | 23.9 | % |  | 26.0 | % |
| Risk-free interest rate | 0.7 | % |  | 0.4 | % |  | 0.3 | % |
| Expected dividend | 3.2 | % |  | 3.1 | % |  | 2.8 | % |
| Expected life (in years) | 1.3 |  |  | 1.3 |  |  | 1.8 |  |
| Weighted-average estimated grant date fair value per share | $ | 6.52 |  |  | $ | 5.73 |  |  | $ | 6.54 |  |

[0000858877-17-000016:notes:215]
The valuation of employee stock purchase rights and the related assumptions are for the employee stock purchases made during the respective fiscal years.

[0000858877-17-000016:notes:216]
The Company used third-party analyses to assist in developing the assumptions used in, as well as calibrating, its lattice-binomial and Black-Scholes models. The Company is responsible for determining the assumptions used in estimating the fair value of its share-based payment awards.

[0000858877-17-000016:notes:217]
The Company used the implied volatility for traded options (with contract terms corresponding to the expected life of the employee stock purchase rights) on the Company’s stock as the expected volatility assumption required in the Black-Scholes model. The implied volatility is more representative of future stock price trends than historical volatility. The risk-free interest rate assumption is based upon observed interest rates appropriate for the term of the Company’s employee stock purchase rights. The dividend yield assumption is based on the history and expectation of dividend payouts at the grant date.

[0000858877-17-000016:notes:218]
| (h) | Employee 401(k) Plans |

[0000858877-17-000016:notes:219]
The Company sponsors the Cisco Systems, Inc. 401(k) Plan (the “Plan”) to provide retirement benefits for its employees. As allowed under Section 401(k) of the Internal Revenue Code, the Plan provides for tax-deferred salary contributions and after-tax contributions for eligible employees. The Plan allows employees to contribute up to 75% of their annual eligible earnings to the Plan on a pretax and after-tax basis, including Roth contributions. Employee contributions are limited to a maximum annual amount as set periodically by the Internal Revenue Code. The Company matches pretax and Roth employee contributions up to 100% of the first 4.5% of eligible earnings that are contributed by employees. Therefore, the maximum matching contribution that the Company may allocate to each participant’s account will not exceed $12,150 for the 2017 calendar year due to the $270,000 annual limit on eligible earnings imposed by the Internal Revenue Code. All matching contributions vest immediately. The Company’s matching contributions to the Plan totaled $265 million, $262 million, and $244 million in fiscal 2017, 2016, and 2015, respectively.

[0000858877-17-000016:notes:220]
The Plan allows employees who meet the age requirements and reach the Plan contribution limits to make catch-up contributions (pretax or Roth) not to exceed the lesser of 75% of their annual eligible earnings or the limit set forth in the Internal Revenue Code. Catch-up contributions are not eligible for matching contributions. In addition, the Plan provides for discretionary profit-sharing contributions as determined by the Board of Directors. Such contributions to the Plan are allocated among eligible participants in the proportion of their salaries to the total salaries of all participants. There were no discretionary profit-sharing contributions made in fiscal 2017, 2016, and 2015.

[0000858877-17-000016:notes:221]
The Company also sponsors other 401(k) plans as a result of acquisitions of other companies. The Company’s contributions to these plans were not material to the Company on either an individual or aggregate basis for any of the fiscal years presented.

[0000858877-17-000016:notes:222]
| (i) | Deferred Compensation Plans |

[0000858877-17-000016:notes:223]
The Cisco Systems, Inc. Deferred Compensation Plan (the “Deferred Compensation Plan”), a nonqualified deferred compensation plan, became effective in 2007. As required by applicable law, participation in the Deferred Compensation Plan is limited to a select group of the Company’s management employees. Under the Deferred Compensation Plan, which is an unfunded and unsecured deferred compensation arrangement, a participant may elect to defer base salary, bonus, and/or commissions, pursuant to such rules as may be established by the Company, up to the maximum percentages for each deferral election as described in the plan. The Company may also, at its discretion, make a matching contribution to the employee under the Deferred Compensation Plan. A matching contribution equal to 4.5% of eligible compensation in excess of the Internal Revenue Code limit for qualified plans for calendar year 2017 that is deferred by participants under the Deferred Compensation Plan (with a $1.5 million cap on eligible compensation) will be made to eligible participants’ accounts at the end of calendar year 2017. The total deferred compensation liability under the Deferred Compensation Plan, together with deferred compensation plans assumed from acquired companies, was approximately $622 million and $569 million as of July 29, 2017 and July 30, 2016, respectively, and was recorded primarily in other long-term liabilities.


## us-gaap:EarningsPerSharePolicyTextBlock

[0000858877-17-000016:notes:224]
(t) Computation of Net Income per Share   Basic net income per share is computed using the weighted-average number of common shares outstanding during the period. Diluted net income per share is computed using the weighted-average number of common shares and dilutive potential common shares outstanding during the period. Diluted shares outstanding includes the dilutive effect of in-the-money options, unvested restricted stock, and restricted stock units. The dilutive effect of such equity awards is calculated based on the average share price for each fiscal period using the treasury stock method. Under the treasury stock method, the amount the employee must pay for exercising stock options, the amount of compensation cost for future service that the Company has not yet recognized, and the amount of tax benefits that would be recorded in additional paid-in capital when the award becomes deductible are collectively assumed to be used to repurchase shares.

[0000858877-17-000016:notes:225]
Employee equity share options, unvested shares, and similar equity instruments granted and assumed by the Company are treated as potential common shares outstanding in computing diluted earnings per share. Diluted shares outstanding include the dilutive effect of in-the-money options, unvested restricted stock, and restricted stock units. The dilutive effect of such equity awards is calculated based on the average share price for each fiscal period using the treasury stock method. Under the treasury stock method, the amount the employee must pay for exercising stock options, the amount of compensation cost for future service that the Company has not yet recognized, and the amount of tax benefits that would be recorded in additional paid-in capital when the award becomes deductible are collectively assumed to be used to repurchase shares.


## us-gaap:EarningsPerShareTextBlock

[0000858877-17-000016:notes:226]
Net Income per Share

[0000858877-17-000016:notes:227]
The following table presents the calculation of basic and diluted net income per share (in millions, except per-share amounts):

[0000858877-17-000016:notes:228]
| Years Ended | July 29, 2017 |  | July 30, 2016 |  | July 25, 2015 |
| Net income | $ | 9,609 |  |  | $ | 10,739 |  |  | $ | 8,981 |  |
| Weighted-average shares—basic | 5,010 |  |  | 5,053 |  |  | 5,104 |  |
| Effect of dilutive potential common shares | 39 |  |  | 35 |  |  | 42 |  |
| Weighted-average shares—diluted | 5,049 |  |  | 5,088 |  |  | 5,146 |  |
| Net income per share—basic | $ | 1.92 |  |  | $ | 2.13 |  |  | $ | 1.76 |  |
| Net income per share—diluted | $ | 1.90 |  |  | $ | 2.11 |  |  | $ | 1.75 |  |
| Antidilutive employee share-based awards, excluded | 136 |  |  | 148 |  |  | 183 |  |


## us-gaap:EquityMethodInvestmentsTextBlock

[0000858877-17-000016:notes:229]
For such investments that were accounted for under the equity and cost method as of July 29, 2017 and July 30, 2016, the amounts are summarized in the following table (in millions):

[0000858877-17-000016:notes:230]
|  | July 29, 2017 |  | July 30, 2016 |
| Equity method investments | $ | 124 |  |  | $ | 174 |  |
| Cost method investments | 859 |  |  | 829 |  |
| Total | $ | 983 |  |  | $ | 1,003 |  |


## us-gaap:FairValueAssetsMeasuredOnNonrecurringBasisTextBlock

[0000858877-17-000016:notes:231]
The following table presents the Company’s assets that were measured at fair value on a nonrecurring basis during the indicated periods and the related recognized gains and losses for the periods indicated (in millions):

[0000858877-17-000016:notes:232]
|  | TOTAL GAINS (LOSSES) FOR THE YEARS ENDED |
|  | July 29, 2017 |  | July 30, 2016 |  | July 25, 2015 |
| Investments in privately held companies (impaired) | $ | (175 | ) |  | $ | (57 | ) |  | $ | (38 | ) |
| Purchased intangible assets (impaired) | (47 | ) |  | (74 | ) |  | (175 | ) |
| Property held for sale - land and buildings | (30 | ) |  | — |  |  | — |  |
| Gains (losses) on assets no longer held at end of fiscal year | (2 | ) |  | (10 | ) |  | (8 | ) |
| Total gains (losses) for nonrecurring measurements | $ | (254 | ) |  | $ | (141 | ) |  | $ | (221 | ) |


## us-gaap:FairValueDisclosuresTextBlock

[0000858877-17-000016:notes:233]
Fair Value

[0000858877-17-000016:notes:234]
| (a) | Assets and Liabilities Measured at Fair Value on a Recurring Basis |

[0000858877-17-000016:notes:235]
Assets and liabilities measured at fair value on a recurring basis as of July 29, 2017 and July 30, 2016 were as follows (in millions):

[0000858877-17-000016:notes:236]
|  | JULY 29, 2017 |  | JULY 30, 2016 |
|  | FAIR VALUE MEASUREMENTS |  | FAIR VALUE MEASUREMENTS |
|  | Level 1 |  | Level 2 |  | Level 3 |  | TotalBalance |  | Level 1 |  | Level 2 |  | Level 3 |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 9,567 |  |  | $ | — |  |  | $ | — |  |  | $ | 9,567 |  |  | $ | 6,111 |  |  | $ | — |  |  | $ | — |  |  | $ | 6,111 |  |
| U.S. government securities | — |  |  | 139 |  |  | — |  |  | 139 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Corporate debt securities | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 43 |  |  | — |  |  | 43 |  |
| Commercial paper | — |  |  | 160 |  |  | — |  |  | 160 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Certificates of deposit | — |  |  | 25 |  |  | — |  |  | 25 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Available-for-sale investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | — |  |  | 19,823 |  |  | — |  |  | 19,823 |  |  | — |  |  | 26,544 |  |  | — |  |  | 26,544 |  |
| U.S. government agency securities | — |  |  | 2,052 |  |  | — |  |  | 2,052 |  |  | — |  |  | 2,817 |  |  | — |  |  | 2,817 |  |
| Non-U.S. government and agency securities | — |  |  | 388 |  |  | — |  |  | 388 |  |  | — |  |  | 1,100 |  |  | — |  |  | 1,100 |  |
| Corporate debt securities | — |  |  | 31,735 |  |  | — |  |  | 31,735 |  |  | — |  |  | 24,292 |  |  | — |  |  | 24,292 |  |
| U.S. agency mortgage-backed securities | — |  |  | 2,023 |  |  | — |  |  | 2,023 |  |  | — |  |  | 1,868 |  |  | — |  |  | 1,868 |  |
| Commercial paper | — |  |  | 996 |  |  | — |  |  | 996 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Certificates of deposit | — |  |  | 60 |  |  | — |  |  | 60 |  |  | — |  | — |  | — |  |  | — |  |  | — |  |
| Publicly traded equity securities | 1,707 |  |  | — |  |  | — |  |  | 1,707 |  |  | 1,504 |  |  | — |  |  | — |  |  | 1,504 |  |
| Derivative assets | — |  |  | 149 |  |  | — |  |  | 149 |  |  | — |  |  | 384 |  |  | 1 |  |  | 385 |  |
| Total | $ | 11,274 |  |  | $ | 57,550 |  |  | $ | — |  |  | $ | 68,824 |  |  | $ | 7,615 |  |  | $ | 57,048 |  |  | $ | 1 |  |  | $ | 64,664 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities | $ | — |  |  | $ | 4 |  |  | $ | — |  |  | $ | 4 |  |  | $ | — |  |  | $ | 54 |  |  | $ | — |  |  | $ | 54 |  |
| Total | $ | — |  |  | $ | 4 |  |  | $ | — |  |  | $ | 4 |  |  | $ | — |  |  | $ | 54 |  |  | $ | — |  |  | $ | 54 |  |

[0000858877-17-000016:notes:237]
Level 1 publicly traded equity securities are determined by using quoted prices in active markets for identical assets.  Level 2 fixed income securities are priced using quoted market prices for similar instruments or nonbinding market prices that are corroborated by observable market data. The Company uses inputs such as actual trade data, benchmark yields, broker/dealer quotes, and other similar data, which are obtained from quoted market prices, independent pricing vendors, or other sources, to determine the ultimate fair value of these assets and liabilities. The Company uses such pricing data as the primary input to make its assessments and determinations as to the ultimate valuation of its investment portfolio and has not made, during the periods presented, any material adjustments to such inputs. The Company is ultimately responsible for the financial statements and underlying estimates. The Company’s derivative instruments are primarily classified as Level 2, as they are not actively traded and are valued using pricing models that use observable market inputs. The Company did not have any transfers between Level 1 and Level 2 fair value measurements during the periods presented.

[0000858877-17-000016:notes:238]
Level 3 assets include certain derivative instruments, the values of which are determined based on discounted cash flow models using inputs that the Company could not corroborate with market data.

[0000858877-17-000016:notes:239]
| (b) | Assets Measured at Fair Value on a Nonrecurring Basis |

[0000858877-17-000016:notes:240]
These assets were measured at fair value due to events or circumstances the Company identified as having significant impact on their fair value during the respective periods. To arrive at the valuation of these assets, the Company considers any significant changes in the financial metrics and economic variables and also uses third-party valuation reports to assist in the valuation as necessary.

[0000858877-17-000016:notes:241]
The fair value measurement of the impaired investments was classified as Level 3 because significant unobservable inputs were used in the valuation due to the absence of quoted market prices and inherent lack of liquidity.  Significant unobservable inputs, which included financial metrics of comparable private and public companies, financial condition and near-term prospects of the investees, recent financing activities of the investees, and the investees’ capital structure as well as other economic variables, reflected the assumptions market participants would use in pricing these assets.  The impairment charges, representing the difference between the net book value and the fair value as a result of the evaluation, were recorded to other income (loss), net.  The remaining carrying value of the investments that were impaired was $81 million and $24 million as of July 29, 2017 and July 30, 2016, respectively.

[0000858877-17-000016:notes:242]
The fair value for purchased intangibles assets measured at fair value on a nonrecurring basis was categorized as Level 3 due to the use of significant unobservable inputs in the valuation.  Significant unobservable inputs that were used included expected revenues and net income related to the assets and the expected life of the assets.  The difference between the estimated fair value and the carrying value of the assets was recorded as an impairment charge, which was included in product cost of sales and operating expenses as applicable.  See Note 4.  The remaining carrying value of the specific purchased intangible assets that were impaired was $63 million and zero as of July 29, 2017 and July 30, 2016, respectively.

[0000858877-17-000016:notes:243]
The fair value of property held for sale was measured with the assistance of third-party valuation models, which used discounted cash flow techniques as part of their analysis.  The fair value measurement was categorized as Level 3, as significant unobservable inputs were used in the valuation report.  The impairment charges as a result of the valuations, which represented the difference between the fair value less cost to sell and the carrying amount of the assets held for sale, was included in restructuring and other charges. The remaining carrying value of the property held for sale that was impaired was $5 million as of July 29, 2017.

[0000858877-17-000016:notes:244]
| (c) | Other Fair Value Disclosures |

[0000858877-17-000016:notes:245]
The carrying value of the Company’s investments in privately held companies that were accounted for under the cost method was $859 million and $829 million as of July 29, 2017 and July 30, 2016, respectively. It was not practicable to estimate the fair value of this portfolio.

[0000858877-17-000016:notes:246]
The fair value of the Company’s short-term loan receivables and financed service contracts approximates their carrying value due to their short duration.  The aggregate carrying value of the Company’s long-term loan receivables and financed service contracts as of July 29, 2017 and July 30, 2016 was $3.4 billion and $2.6 billion, respectively.  The estimated fair value of the Company’s long-term loan receivables and financed service contracts approximates their carrying value. The Company uses significant unobservable inputs in determining discounted cash flows to estimate the fair value of its long-term loan receivables and financed service contracts, and therefore they are categorized as Level 3.

[0000858877-17-000016:notes:247]
As of July 29, 2017 and July 30, 2016, the estimated fair value of the short-term debt approximates its carrying value due to the short maturities.  As of July 29, 2017, the fair value of the Company’s senior notes and other long-term debt was $32.1 billion, with a carrying amount of $30.5 billion.  This compares to a fair value of $30.9 billion and a carrying amount of $28.6 billion as of July 30, 2016.  The fair value of the senior notes and other long-term debt was determined based on observable market prices in a less active market and was categorized as Level 2 in the fair value hierarchy.


## us-gaap:FinancingReceivableCreditQualityIndicatorsTableTextBlock

[0000858877-17-000016:notes:248]
Gross receivables, excluding residual value, less unearned income categorized by the Company’s internal credit risk rating as of July 29, 2017 and July 30, 2016 are summarized as follows (in millions):

[0000858877-17-000016:notes:249]
|  | INTERNAL CREDIT RISK RATING |
| July 29, 2017 | 1 to 4 |  | 5 to 6 |  | 7 and Higher |  | Total |
| Lease receivables | $ | 1,408 |  |  | $ | 1,181 |  |  | $ | 50 |  |  | $ | 2,639 |  |
| Loan receivables | 2,865 |  |  | 1,516 |  |  | 179 |  |  | 4,560 |  |
| Financed service contracts | 1,593 |  |  | 902 |  |  | 22 |  |  | 2,517 |  |
| Total | $ | 5,866 |  |  | $ | 3,599 |  |  | $ | 251 |  |  | $ | 9,716 |  |

[0000858877-17-000016:notes:250]
|  | INTERNAL CREDIT RISK RATING |
| July 30, 2016 | 1 to 4 |  | 5 to 6 |  | 7 and Higher |  | Total |
| Lease receivables | $ | 1,703 |  |  | $ | 1,294 |  |  | $ | 101 |  |  | $ | 3,098 |  |
| Loan receivables | 1,792 |  |  | 1,464 |  |  | 190 |  |  | 3,446 |  |
| Financed service contracts | 1,271 |  |  | 774 |  |  | 14 |  |  | 2,059 |  |
| Total | $ | 4,766 |  |  | $ | 3,532 |  |  | $ | 305 |  |  | $ | 8,603 |  |


## us-gaap:FinancingReceivablesTextBlock

[0000858877-17-000016:notes:251]
Financing Receivables and Operating Leases

[0000858877-17-000016:notes:252]
| (a) | Financing Receivables |

[0000858877-17-000016:notes:253]
Financing receivables primarily consist of lease receivables, loan receivables, and financed service contracts. Lease receivables represent sales-type and direct-financing leases resulting from the sale of the Company’s and complementary third-party products and are typically collateralized by a security interest in the underlying assets. Lease receivables consist of arrangements with terms of four years on average. Loan receivables represent financing arrangements related to the sale of the Company's hardware, software, and services, which may include additional funding for other costs associated with network installation and integration of the Company's products and services. Loan receivables generally have terms of up to three years. Financed service contracts include financing receivables related to technical support and advanced services. Revenue related to the technical support services is typically deferred and included in deferred service revenue and is recognized ratably over the period during which the related services are to be performed, which typically ranges from one to three years.

[0000858877-17-000016:notes:254]
During the fourth quarter of fiscal 2017, the Company reclassified $1.9 billion of its financing receivables related to software and the financing of indirect costs from financed service contracts and other to loan receivables to better reflect the classification of software receivables which have increased. Balances for prior years have been reclassified to conform to the current period's presentation.

[0000858877-17-000016:notes:255]
A summary of the Company's financing receivables is presented as follows (in millions):

[0000858877-17-000016:notes:256]
| July 29, 2017 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Gross | $ | 2,784 |  |  | $ | 4,560 |  |  | $ | 2,517 |  |  | $ | 9,861 |  |
| Residual value | 173 |  |  | — |  |  | — |  |  | 173 |  |
| Unearned income | (145 | ) |  | — |  |  | — |  |  | (145 | ) |
| Allowance for credit loss | (162 | ) |  | (103 | ) |  | (30 | ) |  | (295 | ) |
| Total, net | $ | 2,650 |  |  | $ | 4,457 |  |  | $ | 2,487 |  |  | $ | 9,594 |  |
| Reported as: |  |  |  |  |  |  |  |
| Current | $ | 1,301 |  |  | $ | 2,104 |  |  | $ | 1,451 |  |  | $ | 4,856 |  |
| Noncurrent | 1,349 |  |  | 2,353 |  |  | 1,036 |  |  | 4,738 |  |
| Total, net | $ | 2,650 |  |  | $ | 4,457 |  |  | $ | 2,487 |  |  | $ | 9,594 |  |

[0000858877-17-000016:notes:257]
| July 30, 2016 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Gross | $ | 3,272 |  |  | $ | 3,446 |  |  | $ | 2,059 |  |  | $ | 8,777 |  |
| Residual value | 202 |  |  | — |  |  | — |  |  | 202 |  |
| Unearned income | (174 | ) |  | — |  |  | — |  |  | (174 | ) |
| Allowance for credit loss | (230 | ) |  | (97 | ) |  | (48 | ) |  | (375 | ) |
| Total, net | $ | 3,070 |  |  | $ | 3,349 |  |  | $ | 2,011 |  |  | $ | 8,430 |  |
| Reported as: |  |  |  |  |  |  |  |
| Current | $ | 1,490 |  |  | $ | 1,580 |  |  | $ | 1,202 |  |  | $ | 4,272 |  |
| Noncurrent | 1,580 |  |  | 1,769 |  |  | 809 |  |  | 4,158 |  |
| Total, net | $ | 3,070 |  |  | $ | 3,349 |  |  | $ | 2,011 |  |  | $ | 8,430 |  |

[0000858877-17-000016:notes:258]
Future minimum lease payments to the Company on lease receivables as of July 29, 2017 are summarized as follows (in millions):

[0000858877-17-000016:notes:259]
| Fiscal Year | Amount |
| 2018 | $ | 1,318 |  |
| 2019 | 813 |  |
| 2020 | 438 |  |
| 2021 | 183 |  |
| 2022 | 9 |  |
| Thereafter | 23 |  |
| Total | $ | 2,784 |  |

[0000858877-17-000016:notes:260]
Actual cash collections may differ from the contractual maturities due to early customer buyouts, refinancings, or defaults.

[0000858877-17-000016:notes:261]
| (b) | Credit Quality of Financing Receivables |

[0000858877-17-000016:notes:262]
The Company determines the adequacy of its allowance for credit loss by assessing the risks and losses inherent in its financing receivables by portfolio segment. The portfolio segment is based on the types of financing offered by the Company to its customers, which consist of the following: lease receivables, loan receivables, and financed service contracts.

[0000858877-17-000016:notes:263]
The Company’s internal credit risk ratings of 1 through 4 correspond to investment-grade ratings, while credit risk ratings of 5 and 6 correspond to non-investment grade ratings. Credit risk ratings of 7 and higher correspond to substandard ratings.

[0000858877-17-000016:notes:264]
In circumstances when collectibility is not deemed reasonably assured, the associated revenue is deferred in accordance with the Company’s revenue recognition policies, and the related allowance for credit loss, if any, is included in deferred revenue. The Company also records deferred revenue associated with financing receivables when there are remaining performance obligations, as it does for financed service contracts.

[0000858877-17-000016:notes:265]
The following tables present the aging analysis of gross receivables, excluding residual value and less unearned income as of July 29, 2017 and July 30, 2016 (in millions):

[0000858877-17-000016:notes:266]
|  | DAYS PAST DUE (INCLUDES BILLED AND UNBILLED) |  |  |  |  |  |  |  |  |
| July 29, 2017 | 31 - 60 |  | 61 - 90 |  | 91+ |  | TotalPast Due |  | Current |  | Total |  | NonaccrualFinancingReceivables |  | ImpairedFinancingReceivables |
| Lease receivables | $ | 160 |  |  | $ | 60 |  |  | $ | 216 |  |  | $ | 436 |  |  | $ | 2,203 |  |  | $ | 2,639 |  |  | $ | 14 |  |  | $ | 14 |  |
| Loan receivables | 230 |  |  | 48 |  |  | 259 |  |  | 537 |  |  | 4,023 |  |  | 4,560 |  |  | 43 |  |  | 43 |  |
| Financed service contracts | 160 |  |  | 77 |  |  | 523 |  |  | 760 |  |  | 1,757 |  |  | 2,517 |  |  | 18 |  |  | 2 |  |
| Total | $ | 550 |  |  | $ | 185 |  |  | $ | 998 |  |  | $ | 1,733 |  |  | $ | 7,983 |  |  | $ | 9,716 |  |  | $ | 75 |  |  | $ | 59 |  |

[0000858877-17-000016:notes:267]
|  | DAYS PAST DUE (INCLUDES BILLED AND UNBILLED) |  |  |  |  |  |  |  |  |
| July 30, 2016 | 31 - 60 |  | 61 - 90 |  | 91+ |  | TotalPast Due |  | Current |  | Total |  | NonaccrualFinancingReceivables |  | ImpairedFinancingReceivables |
| Lease receivables | $ | 111 |  |  | $ | 25 |  |  | $ | 251 |  |  | $ | 387 |  |  | $ | 2,711 |  |  | $ | 3,098 |  |  | $ | 60 |  |  | $ | 60 |  |
| Loan receivables | 83 |  |  | 37 |  |  | 167 |  |  | 287 |  |  | 3,159 |  |  | 3,446 |  |  | 42 |  |  | 42 |  |
| Financed service contracts | 159 |  |  | 124 |  |  | 436 |  |  | 719 |  |  | 1,340 |  |  | 2,059 |  |  | 30 |  |  | 10 |  |
| Total | $ | 353 |  |  | $ | 186 |  |  | $ | 854 |  |  | $ | 1,393 |  |  | $ | 7,210 |  |  | $ | 8,603 |  |  | $ | 132 |  |  | $ | 112 |  |

[0000858877-17-000016:notes:268]
Past due financing receivables are those that are 31 days or more past due according to their contractual payment terms. The data in the preceding tables is presented by contract, and the aging classification of each contract is based on the oldest outstanding receivable, and therefore past due amounts also include unbilled and current receivables within the same contract. The balances of either unbilled or current financing receivables included in the category of 91 days plus past due for financing receivables were $666 million and $670 million as of July 29, 2017 and July 30, 2016, respectively.

[0000858877-17-000016:notes:269]
As of July 29, 2017, the Company had financing receivables of $315 million, net of unbilled or current receivables, that were in the category of 91 days plus past due but remained on accrual status as they are well secured and in the process of collection. Such balance was $144 million as of July 30, 2016.

[0000858877-17-000016:notes:270]
| (c) | Allowance for Credit Loss Rollforward |

[0000858877-17-000016:notes:271]
| (d) | Operating Leases |

[0000858877-17-000016:notes:272]
The Company provides financing of certain equipment through operating leases, and the amounts are included in property and equipment in the Consolidated Balance Sheets. Amounts relating to equipment on operating lease assets and the associated accumulated depreciation are summarized as follows (in millions):

[0000858877-17-000016:notes:273]
|  | July 29, 2017 |  | July 30, 2016 |
| Operating lease assets | $ | 356 |  |  | $ | 296 |  |
| Accumulated depreciation | (212 | ) |  | (161 | ) |
| Operating lease assets, net | $ | 144 |  |  | $ | 135 |  |

[0000858877-17-000016:notes:274]
Minimum future rentals on noncancelable operating leases as of July 29, 2017 are summarized as follows (in millions):

[0000858877-17-000016:notes:275]
| Fiscal Year | Amount |
| 2018 | $ | 183 |  |
| 2019 | 102 |  |
| 2020 | 39 |  |
| 2021 | 5 |  |
| Thereafter | 2 |  |
| Total | $ | 331 |  |


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0000858877-17-000016:notes:276]
(m) Foreign Currency Translation   Assets and liabilities of non-U.S. subsidiaries that operate in a local currency environment, where that local currency is the functional currency, are translated to U.S. dollars at exchange rates in effect at the balance sheet date, with the resulting translation adjustments directly recorded to a separate component of AOCI. Income and expense accounts are translated at average exchange rates during the year. Remeasurement adjustments are recorded in other income (loss), net. The effect of foreign currency exchange rates on cash and cash equivalents was not material for any of the fiscal years presented.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000858877-17-000016:notes:277]
Goodwill and Purchased Intangible Assets

[0000858877-17-000016:notes:278]
| (a) | Goodwill |

[0000858877-17-000016:notes:279]
The following tables present the goodwill allocated to the Company’s reportable segments as of July 29, 2017 and July 30, 2016, as well as the changes to goodwill during fiscal 2017 and 2016 (in millions):

[0000858877-17-000016:notes:280]
|  | Balance at July 30, 2016 |  | Acquisitions |  | Divestiture |  | Other |  | Balance at July 29, 2017 |
| Americas | $ | 16,529 |  |  | $ | 2,042 |  |  | $ | — |  |  | $ | 120 |  |  | $ | 18,691 |  |
| EMEA | 6,269 |  |  | 740 |  |  | — |  |  | 48 |  |  | 7,057 |  |
| APJC | 3,827 |  |  | 163 |  |  | — |  |  | 28 |  |  | 4,018 |  |
| Total | $ | 26,625 |  |  | $ | 2,945 |  |  | $ | — |  |  | $ | 196 |  |  | $ | 29,766 |  |

[0000858877-17-000016:notes:281]
|  | Balance at July 25, 2015 |  | Acquisitions |  | Divestiture |  | Other |  | Balance at July 30, 2016 |
| Americas | $ | 15,212 |  |  | $ | 1,607 |  |  | $ | (126 | ) |  | $ | (164 | ) |  | $ | 16,529 |  |
| EMEA | 5,791 |  |  | 554 |  |  | (12 | ) |  | (64 | ) |  | 6,269 |  |
| APJC | 3,466 |  |  | 401 |  |  | (3 | ) |  | (37 | ) |  | 3,827 |  |
| Total | $ | 24,469 |  |  | $ | 2,562 |  |  | $ | (141 | ) |  | $ | (265 | ) |  | $ | 26,625 |  |

[0000858877-17-000016:notes:282]
“Other” in the tables above primarily consists of foreign currency translation, as well as immaterial purchase accounting adjustments.

[0000858877-17-000016:notes:283]
| (b) | Purchased Intangible Assets |

[0000858877-17-000016:notes:284]
Purchased intangible assets include intangible assets acquired through acquisitions as well as through direct purchases or licenses.

[0000858877-17-000016:notes:285]
Impairment charges related to purchased intangible assets were approximately $47 million, $74 million, and $175 million for fiscal 2017, fiscal 2016, and fiscal 2015, respectively. Impairment charges were as a result of declines in estimated fair value resulting from the reduction or elimination of expected future cash flows associated with certain of the Company’s technology and IPR&D intangible assets.

[0000858877-17-000016:notes:286]
The estimated future amortization expense of purchased intangible assets with finite lives as of July 29, 2017 is as follows (in millions):

[0000858877-17-000016:notes:287]
| Fiscal Year | Amount |
| 2018 | $ | 790 |  |
| 2019 | 700 |  |
| 2020 | 483 |  |
| 2021 | 286 |  |
| 2022 | 102 |  |
| Thereafter | 67 |  |
| Total | $ | 2,428 |  |


## us-gaap:GoodwillAndIntangibleAssetsPolicyTextBlock

[0000858877-17-000016:notes:288]
(i) Goodwill and Purchased Intangible Assets   Goodwill is tested for impairment on an annual basis in the fourth fiscal quarter and, when specific circumstances dictate, between annual tests. When impaired, the carrying value of goodwill is written down to fair value. The goodwill impairment test involves a two-step process. The first step, identifying a potential impairment, compares the fair value of a reporting unit with its carrying amount, including goodwill. If the carrying value of the reporting unit exceeds its fair value, the second step would need to be conducted; otherwise, no further steps are necessary as no potential impairment exists. If necessary, the second step to measure the impairment loss would be to compare the implied fair value of the reporting unit goodwill with the carrying amount of that goodwill. Any excess of the reporting unit goodwill carrying value over the respective implied fair value is recognized as an impairment loss. Purchased intangible assets with finite lives are carried at cost, less accumulated amortization. Amortization is computed over the estimated useful lives of the respective assets. See “Long-Lived Assets” for the Company’s policy regarding impairment testing of purchased intangible assets with finite lives. Purchased intangible assets with indefinite lives are assessed for potential impairment annually or when events or circumstances indicate that their carrying amounts might be impaired.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsPolicyTextBlock

[0000858877-17-000016:notes:289]
(j) Long-Lived Assets   Long-lived assets that are held and used by the Company are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of such assets may not be recoverable. Determination of recoverability of long-lived assets is based on an estimate of the undiscounted future cash flows resulting from the use of the asset and its eventual disposition. Measurement of an impairment loss for long-lived assets that management expects to hold and use is based on the difference between the fair value of the asset and its carrying value. Long-lived assets to be disposed of are reported at the lower of carrying amount or fair value less costs to sell.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000858877-17-000016:notes:290]
Income Taxes

[0000858877-17-000016:notes:291]
| (a) | Provision for Income Taxes |

[0000858877-17-000016:notes:292]
The provision for income taxes consists of the following (in millions):

[0000858877-17-000016:notes:293]
| Years Ended | July 29, 2017 |  | July 30, 2016 |  | July 25, 2015 |
| Federal: |  |  |  |  |  |
| Current | $ | 1,300 |  |  | $ | 865 |  |  | $ | 1,583 |  |
| Deferred | (42 | ) |  | (93 | ) |  | 43 |  |
|  | 1,258 |  |  | 772 |  |  | 1,626 |  |
| State: |  |  |  |  |  |
| Current | 86 |  |  | 78 |  |  | 130 |  |
| Deferred | 56 |  |  | 13 |  |  | (20 | ) |
|  | 142 |  |  | 91 |  |  | 110 |  |
| Foreign: |  |  |  |  |  |
| Current | 1,416 |  |  | 1,432 |  |  | 530 |  |
| Deferred | (138 | ) |  | (114 | ) |  | (46 | ) |
|  | 1,278 |  |  | 1,318 |  |  | 484 |  |
| Total | $ | 2,678 |  |  | $ | 2,181 |  |  | $ | 2,220 |  |

[0000858877-17-000016:notes:294]
Income before provision for income taxes consists of the following (in millions):

[0000858877-17-000016:notes:295]
| Years Ended | July 29, 2017 |  | July 30, 2016 |  | July 25, 2015 |
| United States | $ | 2,393 |  |  | $ | 2,907 |  |  | $ | 3,570 |  |
| International | 9,894 |  |  | 10,013 |  |  | 7,631 |  |
| Total | $ | 12,287 |  |  | $ | 12,920 |  |  | $ | 11,201 |  |

[0000858877-17-000016:notes:296]
The items accounting for the difference between income taxes computed at the federal statutory rate and the provision for income taxes consist of the following:

[0000858877-17-000016:notes:297]
| Years Ended | July 29, 2017 |  | July 30, 2016 |  | July 25, 2015 |
| Federal statutory rate | 35.0 | % |  | 35.0 | % |  | 35.0 | % |
| Effect of: |  |  |  |  |  |
| State taxes, net of federal tax benefit | 1.1 |  |  | 0.5 |  |  | 0.8 |  |
| Foreign income at other than U.S. rates | (13.4 | ) |  | (14.5 | ) |  | (15.2 | ) |
| Tax credits | (1.2 | ) |  | (1.7 | ) |  | (1.2 | ) |
| Domestic manufacturing deduction | (0.4 | ) |  | (0.6 | ) |  | (0.7 | ) |
| Nondeductible compensation | 1.4 |  |  | 1.4 |  |  | 2.0 |  |
| Tax audit settlement | — |  |  | (2.8 | ) |  | — |  |
| Other, net | (0.7 | ) |  | (0.4 | ) |  | (0.9 | ) |
| Total | 21.8 | % |  | 16.9 | % |  | 19.8 | % |

[0000858877-17-000016:notes:298]
During fiscal 2016, the Internal Revenue Service (IRS) and the Company settled all outstanding items related to the audit of the Company's federal income tax returns for the fiscal years ended July 26, 2008 through July 31, 2010.  As a result of the settlement, the Company recognized a net benefit to the provision for income taxes of $367 million, which included a reduction of interest expense of $21 million.  In addition, the Protecting Americans from Tax Hikes Act of 2015 reinstated the U.S. federal R&D tax credit permanently.  As a result, the tax provision in fiscal 2016 included a tax benefit of $226 million related to the U.S. federal R&D tax credit, of which $81 million was attributable to fiscal 2015.

[0000858877-17-000016:notes:299]
During fiscal 2015, the Tax Increase Prevention Act of 2014 reinstated the U.S. federal R&D tax credit for calendar year 2014 R&D expenses.  As a result, the tax provision in fiscal 2015 included a tax benefit of $138 million related to the U.S. federal R&D tax credit, of which $78 million was attributable to fiscal 2014.

[0000858877-17-000016:notes:300]
U.S. income taxes and foreign withholding taxes associated with the repatriation of earnings of foreign subsidiaries were not provided for on a cumulative total of $71.1 billion of undistributed earnings for certain foreign subsidiaries as of the end of fiscal 2017. The Company intends to reinvest these earnings indefinitely in its foreign subsidiaries. If these earnings were distributed to the United States in the form of dividends or otherwise, or if the shares of the relevant foreign subsidiaries were sold or otherwise transferred, the Company would be subject to additional U.S. income taxes (subject to an adjustment for foreign tax credits) and foreign withholding taxes. Determination of the amount of unrecognized deferred income tax liability related to these earnings is not practicable.

[0000858877-17-000016:notes:301]
As a result of certain employment and capital investment actions, the Company’s income in certain foreign countries is subject to reduced tax rates.  A portion of these incentives expired at the end of fiscal 2015.  The majority of the remaining tax incentives are reasonably expected to expire at the end of fiscal 2018.  The gross income tax benefit attributable to tax incentives was estimated to be $1.3 billion ($0.25 per diluted share) in fiscal 2017.  As of the end of fiscal 2016 and 2015, the gross income tax benefits attributable to tax incentives were estimated to be $1.2 billion and $1.4 billion ($0.23 and $0.28 per diluted share) for the respective years. The gross income tax benefits were partially offset by accruals of U.S. income taxes on undistributed earnings.

[0000858877-17-000016:notes:302]
Unrecognized Tax Benefits

[0000858877-17-000016:notes:303]
The aggregate changes in the balance of gross unrecognized tax benefits were as follows (in millions):

[0000858877-17-000016:notes:304]
| Years Ended | July 29, 2017 |  | July 30, 2016 |  | July 25, 2015 |
| Beginning balance | $ | 1,627 |  |  | $ | 2,029 |  |  | $ | 1,938 |  |
| Additions based on tax positions related to the current year | 336 |  |  | 255 |  |  | 276 |  |
| Additions for tax positions of prior years | 180 |  |  | 116 |  |  | 137 |  |
| Reductions for tax positions of prior years | (78 | ) |  | (457 | ) |  | (30 | ) |
| Settlements | (43 | ) |  | (241 | ) |  | (165 | ) |
| Lapse of statute of limitations | (49 | ) |  | (75 | ) |  | (127 | ) |
| Ending balance | $ | 1,973 |  |  | $ | 1,627 |  |  | $ | 2,029 |  |

[0000858877-17-000016:notes:305]
As a result of the IRS tax settlement related to the federal income tax returns for the fiscal years ended July 26, 2008 through July 31, 2010, the amount of gross unrecognized tax benefits in fiscal 2016 was reduced by approximately $563 million.  The Company also reduced the amount of accrued interest by $63 million.

[0000858877-17-000016:notes:306]
As of July 29, 2017, $1.4 billion of the unrecognized tax benefits would affect the effective tax rate if realized. During fiscal 2017, the Company recognized $26 million of net interest expense and a $4 million reduction in penalties.  During fiscal 2016, the Company recognized a $55 million reduction in net interest expense and a $40 million reduction in penalties.  During fiscal 2015, the Company recognized a $37 million reduction in net interest expense and a $3 million reduction in penalties. The Company’s total accrual for interest and penalties was $186 million, $154 million, and $274 million as of the end of fiscal 2017, 2016, and 2015, respectively. The Company is no longer subject to U.S. federal income tax audit for returns covering tax years through fiscal 2010. The Company is no longer subject to foreign, state, or local income tax audits for returns covering tax years through fiscal 2000.

[0000858877-17-000016:notes:307]
The Company regularly engages in discussions and negotiations with tax authorities regarding tax matters in various jurisdictions. The Company believes it is reasonably possible that certain federal, foreign, and state tax matters may be concluded in the next 12 months.  Specific positions that may be resolved include issues involving transfer pricing and various other matters. The Company estimates that the unrecognized tax benefits at July 29, 2017 could be reduced by approximately $100 million in the next 12 months.

[0000858877-17-000016:notes:308]
| (b) | Deferred Tax Assets and Liabilities |

[0000858877-17-000016:notes:309]
The following table presents the breakdown for net deferred tax assets (in millions):

[0000858877-17-000016:notes:310]
|  | July 29, 2017 |  | July 30, 2016 |
| Deferred tax assets | $ | 4,239 |  |  | $ | 4,299 |  |
| Deferred tax liabilities | (271 | ) |  | (278 | ) |
| Total net deferred tax assets | $ | 3,968 |  |  | $ | 4,021 |  |

[0000858877-17-000016:notes:311]
The following table presents the components of the deferred tax assets and liabilities (in millions):

[0000858877-17-000016:notes:312]
|  | July 29, 2017 |  | July 30, 2016 |
| ASSETS |  |  |  |
| Allowance for doubtful accounts and returns | $ | 443 |  |  | $ | 524 |  |
| Sales-type and direct-financing leases | 277 |  |  | 289 |  |
| Inventory write-downs and capitalization | 446 |  |  | 417 |  |
| Investment provisions | 171 |  |  | 126 |  |
| IPR&D, goodwill, and purchased intangible assets | 125 |  |  | 139 |  |
| Deferred revenue | 2,057 |  |  | 1,858 |  |
| Credits and net operating loss carryforwards | 976 |  |  | 863 |  |
| Share-based compensation expense | 273 |  |  | 438 |  |
| Accrued compensation | 504 |  |  | 572 |  |
| Other | 559 |  |  | 516 |  |
| Gross deferred tax assets | 5,831 |  |  | 5,742 |  |
| Valuation allowance | (244 | ) |  | (134 | ) |
| Total deferred tax assets | 5,587 |  |  | 5,608 |  |
| LIABILITIES |  |  |  |
| Purchased intangible assets | (1,037 | ) |  | (995 | ) |
| Depreciation | (340 | ) |  | (289 | ) |
| Unrealized gains on investments | (203 | ) |  | (225 | ) |
| Other | (39 | ) |  | (78 | ) |
| Total deferred tax liabilities | (1,619 | ) |  | (1,587 | ) |
| Total net deferred tax assets | $ | 3,968 |  |  | $ | 4,021 |  |

[0000858877-17-000016:notes:313]
As of July 29, 2017, the Company’s federal, state, and foreign net operating loss carryforwards for income tax purposes were $719 million, $985 million, and $840 million, respectively.  A significant amount of the federal net operating loss carryforwards relates to acquisitions and, as a result, is limited in the amount that can be recognized in any one year. If not utilized, the federal net operating loss will begin to expire in fiscal 2018, and the state and foreign net operating loss carryforwards will begin to expire in fiscal 2018 and 2019, respectively. The Company has provided a valuation allowance of $132 million for deferred tax assets related to foreign net operating losses that are not expected to be realized.

[0000858877-17-000016:notes:314]
As of July 29, 2017, the Company’s federal, state, and foreign tax credit carryforwards for income tax purposes were approximately $18 million, $832 million, and $20 million, respectively. The federal tax credit carryforwards will begin to expire in fiscal 2018.  The majority of state tax credits can be carried forward indefinitely. The foreign tax credits carryforwards will begin to expire in fiscal 2018.  The Company has provided a valuation allowance of $91 million for deferred tax assets related to state and foreign tax credits that are not expected to be realized.


## us-gaap:IncomeTaxPolicyTextBlock

[0000858877-17-000016:notes:315]
(s) Income Taxes   Income tax expense is based on pretax financial accounting income. Deferred tax assets and liabilities are recognized for the expected tax consequences of temporary differences between the tax bases of assets and liabilities and their reported amounts. Valuation allowances are recorded to reduce deferred tax assets to the amount that will more likely than not be realized.

[0000858877-17-000016:notes:316]
The Company accounts for uncertainty in income taxes using a two-step approach to recognizing and measuring uncertain tax positions. The first step is to evaluate the tax position for recognition by determining if the weight of available evidence indicates that it is more likely than not that the position will be sustained on audit, including resolution of related appeals or litigation processes, if any. The second step is to measure the tax benefit as the largest amount that is more than 50% likely of being realized upon settlement. The Company classifies the liability for unrecognized tax benefits as current to the extent that the Company anticipates payment (or receipt) of cash within one year. Interest and penalties related to uncertain tax positions are recognized in the provision for income taxes.


## us-gaap:InventoryDisclosureTextBlock

[0000858877-17-000016:notes:317]
The following tables provide details of selected balance sheet items (in millions):

[0000858877-17-000016:notes:318]
|  |  | July 29, 2017 |  | July 30, 2016 |
| Inventories: |  |  |  |  |
| Raw materials |  | $ | 289 |  |  | $ | 91 |  |
| Work in process |  | 1 |  |  | — |  |
| Finished goods: |  |  |  |  |
| Distributor inventory and deferred cost of sales |  | 451 |  |  | 457 |  |
| Manufactured finished goods |  | 552 |  |  | 415 |  |
| Total finished goods |  | 1,003 |  |  | 872 |  |
| Service-related spares |  | 300 |  |  | 236 |  |
| Demonstration systems |  | 23 |  |  | 18 |  |
| Total |  | $ | 1,616 |  |  | $ | 1,217 |  |


## us-gaap:InventoryPolicyTextBlock

[0000858877-17-000016:notes:319]
(d) Inventories   Inventories are stated at the lower of cost or market. Cost is computed using standard cost, which approximates actual cost, on a first-in, first-out basis. The Company provides inventory write-downs based on excess and obsolete inventories determined primarily by future demand forecasts. The write-down is measured as the difference between the cost of the inventory and market based upon assumptions about future demand and charged to the provision for inventory, which is a component of cost of sales. At the point of the loss recognition, a new, lower cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis. In addition, the Company records a liability for firm, noncancelable, and unconditional purchase commitments with contract manufacturers and suppliers for quantities in excess of the Company’s future demand forecasts consistent with its valuation of excess and obsolete inventory.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0000858877-17-000016:notes:320]
The following table summarizes the maturities of the Company’s fixed income securities at July 29, 2017 (in millions):

[0000858877-17-000016:notes:321]
|  | Amortized Cost |  | Fair Value |
| Less than 1 year | $ | 15,497 |  |  | $ | 15,489 |  |
| Due in 1 to 2 years | 13,983 |  |  | 13,965 |  |
| Due in 2 to 5 years | 21,980 |  |  | 22,077 |  |
| Due after 5 years | 3,548 |  |  | 3,523 |  |
| Mortgage-backed securities with no single maturity | 2,037 |  |  | 2,023 |  |
| Total | $ | 57,045 |  |  | $ | 57,077 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000858877-17-000016:notes:322]
Investments

[0000858877-17-000016:notes:323]
| (a) | Summary of Available-for-Sale Investments |

[0000858877-17-000016:notes:324]
The following tables summarize the Company’s available-for-sale investments (in millions):

[0000858877-17-000016:notes:325]
| July 29, 2017 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| Fixed income securities: |  |  |  |  |  |  |  |
| U.S. government securities | $ | 19,880 |  |  | $ | 3 |  |  | $ | (60 | ) |  | $ | 19,823 |  |
| U.S. government agency securities | 2,057 |  |  | — |  |  | (5 | ) |  | 2,052 |  |
| Non-U.S. government and agency securities | 389 |  |  | — |  |  | (1 | ) |  | 388 |  |
| Corporate debt securities | 31,626 |  |  | 202 |  |  | (93 | ) |  | 31,735 |  |
| U.S. agency mortgage-backed securities | 2,037 |  |  | 3 |  |  | (17 | ) |  | 2,023 |  |
| Commercial paper | 996 |  |  | — |  |  | — |  |  | 996 |  |
| Certificates of deposit | 60 |  |  | — |  |  | — |  |  | 60 |  |
| Total fixed income securities | 57,045 |  |  | 208 |  |  | (176 | ) |  | 57,077 |  |
| Publicly traded equity securities | 1,180 |  |  | 554 |  |  | (27 | ) |  | 1,707 |  |
| Total (1) | $ | 58,225 |  |  | $ | 762 |  |  | $ | (203 | ) |  | $ | 58,784 |  |
| July 30, 2016 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| Fixed income securities: |  |  |  |  |  |  |  |
| U.S. government securities | $ | 26,473 |  |  | $ | 73 |  |  | $ | (2 | ) |  | $ | 26,544 |  |
| U.S. government agency securities | 2,809 |  |  | 8 |  |  | — |  |  | 2,817 |  |
| Non-U.S. government and agency securities | 1,096 |  |  | 4 |  |  | — |  |  | 1,100 |  |
| Corporate debt securities | 24,044 |  |  | 263 |  |  | (15 | ) |  | 24,292 |  |
| U.S. agency mortgage-backed securities | 1,846 |  |  | 22 |  |  | — |  |  | 1,868 |  |
| Total fixed income securities | 56,268 |  |  | 370 |  |  | (17 | ) |  | 56,621 |  |
| Publicly traded equity securities | 1,211 |  |  | 333 |  |  | (40 | ) |  | 1,504 |  |
| Total (1) | $ | 57,479 |  |  | $ | 703 |  |  | $ | (57 | ) |  | $ | 58,125 |  |

[0000858877-17-000016:notes:326]
(1) Includes investments that were pending settlement as of the end of the respective fiscal years. The net unsettled investment purchases (sales) were $(30) million and $654 million as of July 29, 2017 and July 30, 2016, respectively.

[0000858877-17-000016:notes:327]
Non-U.S. government and agency securities include agency and corporate debt securities that are guaranteed by non-U.S. governments.

[0000858877-17-000016:notes:328]
| (b) | Gains and Losses on Available-for-Sale Investments |

[0000858877-17-000016:notes:329]
The following table presents the gross realized gains and gross realized losses related to the Company’s available-for-sale investments (in millions):

[0000858877-17-000016:notes:330]
| Years Ended | July 29, 2017 |  | July 30, 2016 |  | July 25, 2015 |
| Gross realized gains | $ | 114 |  |  | $ | 152 |  |  | $ | 221 |  |
| Gross realized losses | (201 | ) |  | (153 | ) |  | (64 | ) |
| Total | $ | (87 | ) |  | $ | (1 | ) |  | $ | 157 |  |

[0000858877-17-000016:notes:331]
The following table presents the realized net gains and losses related to the Company’s available-for-sale investments by security type (in millions):

[0000858877-17-000016:notes:332]
| Years Ended | July 29, 2017 |  | July 30, 2016 |  | July 25, 2015 |
| Net gains/(losses) on investments in publicly traded equity securities | $ | (45 | ) |  | $ | 33 |  |  | $ | 116 |  |
| Net gains/(losses) on investments in fixed income securities | (42 | ) |  | (34 | ) |  | 41 |  |
| Total | $ | (87 | ) |  | $ | (1 | ) |  | $ | 157 |  |

[0000858877-17-000016:notes:333]
The following tables present the breakdown of the available-for-sale investments with gross unrealized losses and the duration that those losses had been unrealized at July 29, 2017 and July 30, 2016 (in millions):

[0000858877-17-000016:notes:334]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 29, 2017 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| Fixed income securities: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | $ | 14,962 |  |  | $ | (55 | ) |  | $ | 771 |  |  | $ | (5 | ) |  | $ | 15,733 |  |  | $ | (60 | ) |
| U.S. government agency securities | 1,791 |  |  | (4 | ) |  | 130 |  |  | (1 | ) |  | 1,921 |  |  | (5 | ) |
| Non-U.S. government and agency securities | 368 |  |  | (1 | ) |  | — |  |  | — |  |  | 368 |  |  | (1 | ) |
| Corporate debt securities | 9,487 |  |  | (92 | ) |  | 101 |  |  | (1 | ) |  | 9,588 |  |  | (93 | ) |
| U.S. agency mortgage-backed securities | 1,485 |  |  | (16 | ) |  | 38 |  |  | (1 | ) |  | 1,523 |  |  | (17 | ) |
| Total fixed income securities | 28,093 |  |  | (168 | ) |  | 1,040 |  |  | (8 | ) |  | 29,133 |  |  | (176 | ) |
| Publicly traded equity securities | 122 |  |  | (27 | ) |  | — |  |  | — |  |  | 122 |  |  | (27 | ) |
| Total | $ | 28,215 |  |  | $ | (195 | ) |  | $ | 1,040 |  |  | $ | (8 | ) |  | $ | 29,255 |  |  | $ | (203 | ) |

[0000858877-17-000016:notes:335]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 30, 2016 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| Fixed income securities: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | $ | 2,414 |  |  | $ | (2 | ) |  | $ | — |  |  | $ | — |  |  | $ | 2,414 |  |  | $ | (2 | ) |
| U.S. government agency securities | 144 |  |  | — |  |  | — |  |  | — |  |  | 144 |  |  | — |  |
| Non-U.S. government and agency securities | 61 |  |  | — |  |  | — |  |  | — |  |  | 61 |  |  | — |  |
| Corporate debt securities | 2,499 |  |  | (7 | ) |  | 1,208 |  |  | (8 | ) |  | 3,707 |  |  | (15 | ) |
| U.S. agency mortgage-backed securities | 174 |  |  | — |  |  | — |  |  | — |  |  | 174 |  |  | — |  |
| Total fixed income securities | 5,292 |  |  | (9 | ) |  | 1,208 |  |  | (8 | ) |  | 6,500 |  |  | (17 | ) |
| Publicly traded equity securities | 188 |  |  | (40 | ) |  | — |  |  | — |  |  | 188 |  |  | (40 | ) |
| Total | $ | 5,480 |  |  | $ | (49 | ) |  | $ | 1,208 |  |  | $ | (8 | ) |  | $ | 6,688 |  |  | $ | (57 | ) |

[0000858877-17-000016:notes:336]
For fiscal 2017, the realized net losses for available-for-sale investments included impairment charges of $74 million. These impairment charges related primarily to publicly traded equity securities and were due to a decline in the fair value of those securities below their cost basis that were determined to be other than temporary. For fiscal 2016, the realized net losses related to available-for-sale investments included impairment charges of $3 million for fixed income securities. These impairment charges were due to a decline in the fair value of those securities below their cost basis that were determined to be other than temporary. There were no impairment charges on available-for-sale investments for fiscal 2015.

[0000858877-17-000016:notes:337]
As of July 29, 2017, for fixed income securities that were in unrealized loss positions, the Company has determined that (i) it does not have the intent to sell any of these investments, and (ii) it is not more likely than not that it will be required to sell any of these investments before recovery of the entire amortized cost basis. In addition, as of July 29, 2017, the Company anticipates that it will recover the entire amortized cost basis of such fixed income securities and has determined that no other-than-temporary impairments associated with credit losses as of July 29, 2017 were required to be recognized.

[0000858877-17-000016:notes:338]
The Company has evaluated its publicly traded equity securities as of July 29, 2017 and has determined that there were no additional other-than-temporary impairments in the respective categories of unrealized losses. This determination was based on several factors, which include the length of time and extent to which fair value has been less than the cost basis, the financial condition and near-term prospects of the issuer, and the Company’s intent and ability to hold the publicly traded equity securities for a period of time sufficient to allow for any anticipated recovery in market value.

[0000858877-17-000016:notes:339]
| (c) | Maturities of Fixed Income Securities |

[0000858877-17-000016:notes:340]
Actual maturities may differ from the contractual maturities because borrowers may have the right to call or prepay certain obligations. The remaining contractual principal maturities for mortgage-backed securities were allocated assuming no prepayments.

[0000858877-17-000016:notes:341]
| (d) | Securities Lending |

[0000858877-17-000016:notes:342]
The Company periodically engages in securities lending activities with certain of its available-for-sale investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. The average daily balance of securities lending for fiscal 2017 and 2016 was $0.7 billion and $0.6 billion, respectively. The Company requires collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. The Company engages in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify the Company against collateral losses. The Company did not experience any losses in connection with the secured lending of securities during the periods presented.  As of July 29, 2017 and July 30, 2016, the Company had no outstanding securities lending transactions.

[0000858877-17-000016:notes:343]
| (e) | Investments in Privately Held Companies |

[0000858877-17-000016:notes:344]
The carrying value of the Company’s investments in privately held companies was included in other assets. For such investments that were accounted for under the equity and cost method as of July 29, 2017 and July 30, 2016, the amounts are summarized in the following table (in millions):

[0000858877-17-000016:notes:345]
For additional information on impairment charges related to investments in privately held companies, see Note 9.

[0000858877-17-000016:notes:346]
Variable Interest Entities  In the ordinary course of business, the Company has investments in privately held companies and provides financing to certain customers. These privately held companies and customers may be considered to be variable interest entities. The Company evaluates on an ongoing basis its investments in these privately held companies and its customer financings and has determined that as of July 29, 2017, except as disclosed herein, there were no variable interest entities required to be consolidated in the Company’s Consolidated Financial Statements.

[0000858877-17-000016:notes:347]
As discussed in Note 2, during the first quarter of fiscal 2017, the Company adopted a new accounting standard update related to the consolidation of certain types of legal entities. As of July 29, 2017, the carrying value of the Company's investments in privately held companies was $983 million, of which $553 million of such investments are considered to be in variable interest entities which are unconsolidated. In addition, the Company has additional funding commitments of $216 million related to these investments, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The carrying value of these investments and the additional funding commitments collectively represent the Company's maximum exposure related to these variable interest entities.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000858877-17-000016:notes:348]
(w) New Accounting Updates Recently Adopted

[0000858877-17-000016:notes:349]
Consolidation of Certain Types of Legal Entities  In February 2015, the FASB issued an accounting standard update that changes the analysis that a reporting entity must perform to determine whether it should consolidate certain types of legal entities. The accounting standard update became effective for the Company beginning in the first quarter of fiscal 2017. The application of this accounting standard update did not have any impact on the Company's Consolidated Balance Sheet or Statement of Operations upon adoption, but the Company has provided additional disclosures in Note 8 pursuant to this accounting standard update.

[0000858877-17-000016:notes:350]
(x) Recent Accounting Standards or Updates Not Yet Effective as of Fiscal Year End

[0000858877-17-000016:notes:351]
Revenue Recognition  In May 2014, the FASB issued a new accounting standard related to revenue recognition. The new standard will supersede nearly all U.S. GAAP on revenue recognition and eliminate industry-specific guidance. The underlying principle of the new standard is to recognize revenue when a customer obtains control of promised goods or services at an amount that reflects the consideration that is expected to be received in exchange for those goods or services. It also requires increased disclosures including the nature, amount, timing, and uncertainty of revenues and cash flows related to contracts with customers.

[0000858877-17-000016:notes:352]
The standard allows two methods of adoption: i) retrospectively to each prior period presented (“full retrospective method”), or ii) retrospectively with the cumulative effect recognized in retained earnings as of the date of adoption ("modified retrospective method"). Cisco will adopt the new standard using the modified retrospective method at the beginning of its first quarter of fiscal 2019.

[0000858877-17-000016:notes:353]
Cisco is on schedule in establishing new accounting policies, implementing systems and processes (including more extensive use of estimates), and internal controls necessary to support the requirements of the new standard. Cisco has completed its preliminary assessment of the financial statement impact of the new standard, as discussed below, and will continue to update that assessment as more information becomes available.

[0000858877-17-000016:notes:354]
The new standard will primarily impact Cisco’s revenue recognition for software arrangements and sales to two-tier distributors. In both areas, the new standard will accelerate the recognition of revenue. The table below details both the current and expected revenue recognition timing in these areas:

[0000858877-17-000016:notes:355]
|  |  | Current Revenue Standard |  | New Revenue Standard |
| Software arrangements: |  |  |  |  |
| Perpetual software licenses |  | Upfront |  | Upfront |
| Term software licenses |  | Ratable |  | Upfront |
| Security software licenses |  | Ratable |  | Ratable |
| Enterprise license agreements |  | Ratable |  | Upfront |
| Software support services |  | Ratable |  | Ratable |
| Software-as-a-service |  | Ratable |  | Ratable |
| Two-tier distribution |  | Sell-Through |  | Sell-In |

[0000858877-17-000016:notes:356]
Cisco expects that the new standard will not have a material impact on total revenue in the year of adoption based on two factors: i) revenue will be accelerated consistent with the changes in timing as indicated in the preceding table, largely offset by ii) the reduction of revenue from software arrangements where revenue was previously deferred in prior periods and recognized ratably over time as required under the current standard. This preliminary assessment is based on the types and number of revenue arrangements currently in place. The exact impact of the new standard will be dependent on facts and circumstances at adoption and could vary from quarter to quarter.

[0000858877-17-000016:notes:357]
In addition to the above revenue recognition timing impacts, the new standard will require incremental contract acquisition costs (such as sales commissions) for customer contracts to be capitalized and amortized over the contract period. Currently, these costs are expensed as incurred.

[0000858877-17-000016:notes:358]
Cisco will be required to record cumulative effect adjustments to retained earnings upon adopting the new standard at the beginning of fiscal 2019. The most significant of these adjustments will be to reduce product deferred revenue and increase retained earnings at the date of adoption to reflect revenue that would have been already recognized under the new standard related to existing arrangements. There will also be an adjustment to increase accounts receivable and reduce inventories related to the changes in revenue recognition on sales to two-tier distributors. Lastly, an adjustment will be recorded to establish an asset and increase retained earnings related to the requirement to capitalize incremental contract acquisition costs for customer contracts.

[0000858877-17-000016:notes:359]
Financial Instruments  In January 2016, the FASB issued an accounting standard update that changes the accounting for equity investments, financial liabilities under the fair value option, and the presentation and disclosure requirements for financial instruments. The accounting standard update will be effective for Cisco beginning in the first quarter of fiscal 2019, and early adoption is permitted. The most significant impact of this accounting standard update for Cisco is that it will require the remeasurement of equity investments at fair value with the changes recorded to the income statement. While Cisco is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements, Cisco expects that this accounting standard update will increase the variability of other income (loss), net.

[0000858877-17-000016:notes:360]
Leases  In February 2016, the FASB issued an accounting standard update related to leases requiring lessees to recognize operating and financing lease liabilities on the balance sheet, as well as corresponding right-of-use assets. The new lease standard also makes some changes to lessor accounting and aligns key aspects of the lessor accounting model with the revenue recognition standard. In addition, disclosures will be required to enable users of financial statements to assess the amount, timing, and uncertainty of cash flows arising from leases. The accounting standard update will be effective for Cisco beginning in the first quarter of fiscal 2020 on a modified retrospective basis, and early adoption is permitted. Cisco is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.

[0000858877-17-000016:notes:361]
Share-Based Compensation  In March 2016, the FASB issued an accounting standard update that impacts the accounting for share-based payment transactions, including income tax consequences, classification of awards as either equity or liabilities, and classification on the Consolidated Statements of Cash Flows. The accounting standard update became effective for Cisco beginning in the first quarter of fiscal 2018. Cisco does not expect that this accounting standard update will have a material impact on its Consolidated Financial Statements, but this accounting standard update is expected to slightly increase the variability of the provision for income taxes.

[0000858877-17-000016:notes:362]
Credit Losses of Financial Instruments  In June 2016, the FASB issued an accounting standard update that requires measurement and recognition of expected credit losses for financial assets held based on historical experience, current conditions, and reasonable and supportable forecasts that affect the collectibility of the reported amount. The accounting standard update will be effective for Cisco beginning in the first quarter of fiscal 2021 on a modified retrospective basis, and early adoption in fiscal 2020 is permitted. Cisco is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.

[0000858877-17-000016:notes:363]
Classification of Cash Flow Elements  In August 2016, the FASB issued an accounting standard update related to the classification of certain cash receipts and cash payments on the statement of cash flows. The accounting standard update will be effective for Cisco beginning in the first quarter of fiscal 2019 on a retrospective basis, and early adoption is permitted. Cisco is currently evaluating the impact of this accounting standard update on its Consolidated Statements of Cash Flows.

[0000858877-17-000016:notes:364]
Income Taxes on Intra-Entity Transfers of Assets  In October 2016, the FASB issued an accounting standard update that requires recognition of the income tax consequences of intra-entity transfers of assets (other than inventory) at the transaction date. The accounting standard update will be effective for Cisco beginning in the first quarter of fiscal 2019 on a modified retrospective basis, and early adoption is permitted. Cisco is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.

[0000858877-17-000016:notes:365]
Restricted Cash in Statement of Cash Flow  In November 2016, the FASB issued an accounting standard update that provides guidance on the classification and presentation of changes in restricted cash and cash equivalents in the statement of cash flows. The accounting standard update will be effective for Cisco beginning in the first quarter of fiscal 2019 using a retrospective transition method to each period presented, and early adoption is permitted. Cisco does not expect that this accounting standard update will have a material impact on its Consolidated Statements of Cash Flows.

[0000858877-17-000016:notes:366]
Definition of a Business  In January 2017, the FASB issued an accounting standard update that clarifies the definition of a business to help companies evaluate whether acquisition or disposal transactions should be accounted for as asset groups or as businesses. The accounting standard update will be effective for Cisco beginning in the first quarter of fiscal 2019 on a prospective basis. The impact of this accounting standard update will be fact dependent, but Cisco expects that some transactions that were previously accounted for as business combinations or disposal transactions will be accounted for as asset purchases or asset sales under the accounting standard update.

[0000858877-17-000016:notes:367]
Simplifying the Test for Goodwill Impairment  In January 2017, the FASB issued an accounting standard update that removes Step 2 of the goodwill impairment test, which requires the assessment of fair value of individual assets and liabilities of a reporting unit to measure goodwill impairments. Goodwill impairment will now be the amount by which a reporting unit's carrying value exceeds its fair value. The accounting standard update will be effective for Cisco beginning in the first quarter of fiscal 2021 on a prospective basis, and early adoption is permitted. Cisco does not expect that this accounting standard update will impact its Consolidated Financial Statements.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000858877-17-000016:notes:368]
Basis of Presentation

[0000858877-17-000016:notes:369]
The fiscal year for Cisco Systems, Inc. (the “Company” or “Cisco”) is the 52 or 53 weeks ending on the last Saturday in July. Fiscal 2017 and fiscal 2015 were each 52-week fiscal years, while fiscal 2016 was a 53-week fiscal year. The Consolidated Financial Statements include the accounts of Cisco and its subsidiaries. All intercompany accounts and transactions have been eliminated.  The Company conducts business globally and is primarily managed on a geographic basis in the following three geographic segments: the Americas; Europe, Middle East, and Africa (EMEA); and Asia Pacific, Japan, and China (APJC).

[0000858877-17-000016:notes:370]
The Company consolidates its investments in a venture fund managed by SOFTBANK Corp. and its affiliates (“SOFTBANK”) as this is a variable interest entity and the Company is the primary beneficiary. The noncontrolling interests attributed to SOFTBANK are presented as a separate component from the Company’s equity in the equity section of the Consolidated Balance Sheets. SOFTBANK's share of the earnings in the venture fund are not presented separately in the Consolidated Statements of Operations as these amounts are not material for any of the fiscal periods presented.

[0000858877-17-000016:notes:371]
Certain reclassifications have been made to the amounts for prior years in order to conform to the current year’s presentation. The Company has evaluated subsequent events through the date that the financial statements were issued.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0000858877-17-000016:notes:372]
(g) Depreciation and Amortization   Property and equipment are stated at cost, less accumulated depreciation or amortization, whenever applicable. Depreciation and amortization expenses for property and equipment were approximately $1.1 billion, $1.0 billion, and $1.1 billion for fiscal 2017, 2016, and 2015, respectively. Depreciation and amortization are computed using the straight-line method, generally over the following periods:


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0000858877-17-000016:notes:373]
| Property and equipment, net: |  |  |  |  |
| Gross property and equipment: |  |  |  |  |
| Land, buildings, and building and leasehold improvements |  | $ | 4,926 |  |  | $ | 4,778 |  |
| Computer equipment and related software |  | 1,258 |  |  | 1,288 |  |
| Production, engineering, and other equipment |  | 5,707 |  |  | 5,658 |  |
| Operating lease assets |  | 356 |  |  | 296 |  |
| Furniture and fixtures |  | 572 |  |  | 543 |  |
| Total gross property and equipment |  | 12,819 |  |  | 12,563 |  |
| Less: accumulated depreciation and amortization |  | (9,497 | ) |  | (9,057 | ) |
| Total |  | $ | 3,322 |  |  | $ | 3,506 |  |


## us-gaap:QuarterlyFinancialInformationTextBlock

[0000858877-17-000016:notes:374]
Supplementary Financial Data (Unaudited)

[0000858877-17-000016:notes:375]
(in millions, except per-share amounts)

[0000858877-17-000016:notes:376]
| Quarters Ended | July 29, 2017 |  | April 29, 2017 |  | January 28, 2017 |  | October 29, 2016 |
| Revenue | $ | 12,133 |  |  | $ | 11,940 |  |  | $ | 11,580 |  |  | $ | 12,352 |  |
| Gross margin | $ | 7,546 |  |  | $ | 7,518 |  |  | $ | 7,276 |  |  | $ | 7,884 |  |
| Operating income | $ | 3,034 |  |  | $ | 3,169 |  |  | $ | 2,893 |  |  | $ | 2,877 |  |
| Net income | $ | 2,424 |  |  | $ | 2,515 |  |  | $ | 2,348 |  |  | $ | 2,322 |  |
| Net income per share - basic | $ | 0.49 |  |  | $ | 0.50 |  |  | $ | 0.47 |  |  | $ | 0.46 |  |
| Net income per share - diluted | $ | 0.48 |  |  | $ | 0.50 |  |  | $ | 0.47 |  |  | $ | 0.46 |  |
| Cash dividends declared per common share | $ | 0.29 |  |  | $ | 0.29 |  |  | $ | 0.26 |  |  | $ | 0.26 |  |
| Cash and cash equivalents and investments | $ | 70,492 |  |  | $ | 67,974 |  |  | $ | 71,845 |  |  | $ | 70,968 |  |

[0000858877-17-000016:notes:377]
| Quarters Ended | July 30, 2016 |  | April 30, 2016 |  | January 23, 2016 |  | October 24, 2015 |
| Revenue | $ | 12,638 |  |  | $ | 12,000 |  |  | $ | 11,927 |  |  | $ | 12,682 |  |
| Gross margin | $ | 7,975 |  |  | $ | 7,721 |  |  | $ | 7,432 |  |  | $ | 7,832 |  |
| Operating income | $ | 3,303 |  |  | $ | 2,984 |  |  | $ | 3,294 |  |  | $ | 3,079 |  |
| Net income | $ | 2,813 |  |  | $ | 2,349 |  |  | $ | 3,147 |  |  | $ | 2,430 |  |
| Net income per share - basic | $ | 0.56 |  |  | $ | 0.47 |  |  | $ | 0.62 |  |  | $ | 0.48 |  |
| Net income per share - diluted | $ | 0.56 |  |  | $ | 0.46 |  |  | $ | 0.62 |  |  | $ | 0.48 |  |
| Cash dividends declared per common share | $ | 0.26 |  |  | $ | 0.26 |  |  | $ | 0.21 |  |  | $ | 0.21 |  |
| Cash and cash equivalents and investments | $ | 65,756 |  |  | $ | 63,512 |  |  | $ | 60,375 |  |  | $ | 59,107 |  |


## us-gaap:ResearchDevelopmentAndComputerSoftwarePolicyTextBlock

[0000858877-17-000016:notes:378]
(r) Software Development Costs   Software development costs, including costs to develop software sold, leased, or otherwise marketed, that are incurred subsequent to the establishment of technological feasibility are capitalized if significant. Costs incurred during the application development stage for internal-use software are capitalized if significant. Capitalized software development costs are amortized using the straight-line amortization method over the estimated useful life of the applicable software. Such software development costs required to be capitalized have not been material to date.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000858877-17-000016:notes:379]
Restructuring and Other Charges

[0000858877-17-000016:notes:380]
The Company began taking action under a restructuring plan in August 2016 (the "Fiscal 2017 Plan"), in order to reinvest in its key priority areas.  The Company announced that up to 6,600 employees would be impacted, with estimated pretax charges of approximately $850 million. In connection with the Fiscal 2017 Plan, the Company incurred charges of $756 million during fiscal 2017. The Company's estimated aggregate pretax charges of approximately $850 million under the Fiscal 2017 Plan consist primarily of severance and other one-time termination benefits, and other associated costs. These charges are primarily cash-based, and the Company expects the Fiscal 2017 Plan to be substantially completed by the end of the first quarter of fiscal 2018.

[0000858877-17-000016:notes:381]
The Company announced a restructuring action in August 2014 (the “Fiscal 2015 Plan”), in order to realign its workforce towards key growth areas of its business such as data center, software, security, and cloud. In connection with this plan, the Company incurred cumulative charges of approximately $756 million. The Company completed the Fiscal 2015 Plan at the end of fiscal 2016.

[0000858877-17-000016:notes:382]
The following table summarizes the activities related to the restructuring and other charges, as discussed above (in millions):

[0000858877-17-000016:notes:383]
|  |  | FISCAL 2015 AND PRIOR YEAR PLANS |  | FISCAL 2017 PLAN |  |  |
|  |  | EmployeeSeverance |  | Other |  | EmployeeSeverance |  | Other |  | Total |
| Liability as of July 26, 2014 |  | $ | 40 |  |  | $ | 29 |  |  | $ | — |  |  | $ | — |  |  | $ | 69 |  |
| Charges |  | 464 |  |  | 20 |  |  | — |  |  | — |  |  | 484 |  |
| Cash payments |  | (442 | ) |  | (17 | ) |  | — |  |  | — |  |  | (459 | ) |
| Non-cash items |  | (2 | ) |  | (3 | ) |  | — |  |  | — |  |  | (5 | ) |
| Liability as of July 25, 2015 |  | 60 |  |  | 29 |  |  | — |  |  | — |  |  | 89 |  |
| Charges |  | 225 |  |  | 43 |  |  | — |  |  | — |  |  | 268 |  |
| Cash payments |  | (264 | ) |  | (15 | ) |  | — |  |  | — |  |  | (279 | ) |
| Non-cash items |  | — |  |  | (33 | ) |  | — |  |  | — |  |  | (33 | ) |
| Liability as of July 30, 2016 |  | 21 |  |  | 24 |  |  | — |  |  | — |  |  | 45 |  |
| Charges |  | — |  |  | — |  |  | 625 |  |  | 131 |  |  | 756 |  |
| Cash payments |  | (16 | ) |  | (8 | ) |  | (553 | ) |  | (29 | ) |  | (606 | ) |
| Non-cash items |  | (4 | ) |  | (9 | ) |  | 1 |  |  | (66 | ) |  | (78 | ) |
| Liability as of July 29, 2017 |  | $ | 1 |  |  | $ | 7 |  |  | $ | 73 |  |  | $ | 36 |  |  | $ | 117 |  |

[0000858877-17-000016:notes:384]
In addition to the above amounts, the Company incurred $2 million credit and $5 million of restructuring and other charges within cost of sales during fiscal 2016 and fiscal 2015, respectively.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0000858877-17-000016:notes:385]
(o) Revenue Recognition   The Company recognizes revenue when persuasive evidence of an arrangement exists, delivery has occurred, the fee is fixed or determinable, and collectibility is reasonably assured. In instances where final acceptance of the product, system, or solution is specified by the customer, revenue is deferred until all acceptance criteria have been met. For hosting arrangements, the Company recognizes revenue ratably over the hosting period, while usage revenue is recognized based on utilization. Software subscription revenue is deferred and recognized ratably over the subscription term upon delivery of the first product and commencement of the term. Technical support and consulting services revenue is deferred and recognized ratably over the period during which the services are to be performed, which is typically from one to three years. Transactional advanced services revenue is recognized upon delivery or completion of performance milestones.

[0000858877-17-000016:notes:386]
The Company uses distributors that typically stock inventory and sell to systems integrators, service providers, and other resellers.     The Company refers to this as its two-tier sales to the end customer. Revenue from distributors is recognized based on a sell-through method using point-of-sale information provided by the distributors. Distributors and other partners participate in various rebate, cooperative marketing, and other incentive programs, and the Company maintains estimated accruals and allowances for these programs. The ending liability for these programs was included in other current liabilities, and the balance as of July 29, 2017 and July 30, 2016 was $1.0 billion and $1.1 billion, respectively. The Company accrues for warranty costs, sales returns, and other allowances based on its historical experience. Shipping and handling fees billed to customers are included in revenue, with the associated costs included in cost of sales.

[0000858877-17-000016:notes:387]
Many of the Company’s products have both software and non-software components that function together to deliver the products’ essential functionality. The Company also provides technical support and advanced services. The Company has a broad customer base that encompasses virtually all types of public and private entities, including enterprise businesses, service providers, and commercial customers. The Company and its salesforce are not organized by product divisions, and the Company’s products and services can be sold standalone or together in various combinations across the Company’s geographic segments or customer markets. For example, service provider arrangements are typically larger in scale with longer deployment schedules and involve the delivery of a variety of product technologies, including high-end routing, video and network management software, and other product technologies along with technical support and advanced services. The Company’s enterprise and commercial arrangements are unique for each customer and smaller in scale and may include network infrastructure products such as routers and switches or collaboration technologies such as Unified Communications and Cisco TelePresence systems products along with technical support services.

[0000858877-17-000016:notes:388]
The Company enters into revenue arrangements that may consist of multiple deliverables of its product and service offerings due to the needs of its customers. For example, a customer may purchase routing products along with a contract for technical support services. This arrangement would consist of multiple elements, with the products delivered in one reporting period and the technical support services delivered across multiple reporting periods. Another customer may purchase networking products along with advanced service offerings, in which all the elements are delivered within the same reporting period. In addition, distributors purchase products or technical support services on a standalone basis for resale to an end user or for purposes of stocking certain products, and these transactions would not result in a multiple-element arrangement. The Company considers several factors when reviewing multiple purchases made by the same customer within a short time frame in order to identify multiple-element arrangements, including whether the deliverables are closely interrelated, whether the deliverables are essential to each other’s functionality, whether payment terms are linked, whether the customer is entitled to a refund or concession if another purchase is not completed satisfactorily, and/or whether the purchases were negotiated together as one overall arrangement.

[0000858877-17-000016:notes:389]
In many instances, products are sold separately in standalone arrangements as customers may support the products themselves or purchase support on a time-and-materials basis. Advanced services are sometimes sold in standalone engagements such as general consulting, network management, or security advisory projects, and technical support services are sold separately through renewals of annual contracts. The Company determines its vendor-specific objective evidence (VSOE) based on its normal pricing and discounting practices for products or services when sold separately. VSOE determination requires that a substantial majority of the historical standalone transactions has the selling prices for a product or service that fall within a reasonably narrow pricing range, generally evidenced by approximately 80% of such historical standalone transactions falling within plus or minus 15% of the median rates. In addition, the Company considers the geographies in which the products or services are sold, major product and service groups and customer classifications, and other environmental or marketing variables in determining VSOE.

[0000858877-17-000016:notes:390]
When the Company is not able to establish VSOE for all deliverables in an arrangement with multiple elements, which may be due to the Company infrequently selling each element separately, not pricing products within a narrow range, or only having a limited sales history, such as in the case of certain newly introduced product categories, the Company attempts to determine the selling price of each element based on third-party evidence of selling price (TPE). TPE is determined based on competitor prices for similar deliverables when sold separately. Generally, the Company’s go-to-market strategy differs from that of its peers, and its offerings contain a significant level of differentiation such that the comparable pricing of products with similar functionality cannot be obtained. Furthermore, the Company is unable to reliably determine what similar competitor products’ selling prices are on a standalone basis. Therefore, the Company is typically not able to determine TPE.

[0000858877-17-000016:notes:391]
When the Company is unable to establish fair value using VSOE or TPE, the Company uses estimated selling prices (ESP) in its allocation of arrangement consideration. The objective of ESP is to determine the price at which the Company would transact a sale if the product or service were regularly sold on a standalone basis. ESP is generally used for new or highly proprietary offerings and solutions or for offerings not priced within a reasonably narrow range. The Company determines ESP for a product or service by considering multiple factors, including, but not limited to, geographies, market conditions, competitive landscape, internal costs, gross margin objectives, and pricing practices. The determination of ESP is made through consultation with and formal approval by the Company’s management, taking into consideration the go-to-market strategy.

[0000858877-17-000016:notes:392]
The Company regularly reviews VSOE, TPE, and ESP and maintains internal controls over the establishment and updates of these estimates. There were no material impacts during the fiscal year, nor does the Company currently expect a material impact in the near term from changes in VSOE, TPE, or ESP.

[0000858877-17-000016:notes:393]
The Company’s arrangements with multiple deliverables may include one or more software deliverables that are subject to the software revenue recognition guidance. In these cases, revenue for the software is generally recognized upon shipment or electronic delivery and granting of the license. The revenue for these multiple-element arrangements is allocated to the software deliverables and the non-software deliverables based on the relative selling prices of all of the deliverables in the arrangement using the hierarchy in the applicable accounting guidance. In the circumstances where the Company cannot determine VSOE or TPE of the selling price for all of the deliverables in the arrangement, including the software deliverables, ESP is used for the purposes of performing this allocation. VSOE is required to allocate the revenue between multiple software deliverables. If VSOE is available for the undelivered software elements, the Company applies the residual method; where VSOE is not available, software revenue is either recognized when all software elements have been delivered or recognized ratably when post-contract support is the only undelivered software element remaining.


## us-gaap:ScheduleOfBusinessAcquisitionsByAcquisitionTextBlock

[0000858877-17-000016:notes:394]
A summary of the allocation of the total purchase consideration is presented as follows (in millions):


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0000858877-17-000016:notes:395]
SCHEDULE II

[0000858877-17-000016:notes:396]
VALUATION AND QUALIFYING ACCOUNTS

[0000858877-17-000016:notes:397]
(in millions)

[0000858877-17-000016:notes:398]
|  | Allowances For |
|  | FinancingReceivables |  | AccountsReceivable |
| Year ended July 25, 2015 |  |  |  |
| Balance at beginning of fiscal year | $ | 349 |  |  | $ | 265 |  |
| Provisions | 57 |  |  | 77 |  |
| Recoveries (write-offs), net | (7 | ) |  | (40 | ) |
| Foreign exchange and other | (17 | ) |  | — |  |
| Balance at end of fiscal year | $ | 382 |  |  | $ | 302 |  |
| Year ended July 30, 2016 |  |  |  |
| Balance at beginning of fiscal year | $ | 382 |  |  | $ | 302 |  |
| Provisions | 17 |  |  | (26 | ) |
| Recoveries (write-offs), net | (15 | ) |  | (28 | ) |
| Foreign exchange and other | (9 | ) |  | 1 |  |
| Balance at end of fiscal year | $ | 375 |  |  | $ | 249 |  |
| Year ended July 29, 2017 |  |  |  |
| Balance at beginning of fiscal year | $ | 375 |  |  | $ | 249 |  |
| Provisions | (35 | ) |  | 27 |  |
| Recoveries (write-offs), net | (49 | ) |  | (61 | ) |
| Foreign exchange and other | 4 |  |  | (4 | ) |
| Balance at end of fiscal year | $ | 295 |  |  | $ | 211 |  |

[0000858877-17-000016:notes:399]
Foreign exchange and other includes the impact of foreign exchange and certain immaterial reclassifications.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000858877-17-000016:notes:400]
Summary of Significant Accounting Policies

[0000858877-17-000016:notes:401]
(b) Available-for-Sale Investments   The Company classifies its investments in both fixed income securities and publicly traded equity securities as available-for-sale investments. Fixed income securities primarily consist of U.S. government securities, U.S. government agency securities, non-U.S. government and agency securities, corporate debt securities, and U.S. agency mortgage-backed securities. These available-for-sale investments are primarily held in the custody of a major financial institution. A specific identification method is used to determine the cost basis of fixed income and public equity securities sold. These investments are recorded in the Consolidated Balance Sheets at fair value. Unrealized gains and losses on these investments, to the extent the investments are unhedged, are included as a separate component of accumulated other comprehensive income (AOCI), net of tax. The Company classifies its investments as current based on the nature of the investments and their availability for use in current operations.

[0000858877-17-000016:notes:402]
(e) Allowance for Doubtful Accounts   The allowance for doubtful accounts is based on the Company’s assessment of the collectibility of customer accounts. The Company regularly reviews the allowance by considering factors such as historical experience, credit quality, age of the accounts receivable balances, economic conditions that may affect a customer’s ability to pay, and expected default frequency rates. Trade receivables are written off at the point when they are considered uncollectible.

[0000858877-17-000016:notes:403]
(f) Financing Receivables and Guarantees   The Company provides financing arrangements, including leases, financed service contracts, and loans, for certain qualified end-user customers to build, maintain, and upgrade their networks. Lease receivables primarily represent sales-type and direct-financing leases. Leases have on average a four-year term and are usually collateralized by a security interest in the underlying assets. Loan receivables include customers financing purchases of the Company's hardware, software and services and also may include additional funds for other costs associated with network installation and integration of the Company's products and services. Loan receivables generally have terms of up to three years. Financed service contracts typically have terms of one to three years and primarily relate to technical support services.

[0000858877-17-000016:notes:404]
The Company determines the adequacy of its allowance for credit loss by assessing the risks and losses inherent in its financing receivables by portfolio segment. The portfolio segment is based on the types of financing offered by the Company to its customers: lease receivables, loan receivables, and financed service contracts.

[0000858877-17-000016:notes:405]
The Company assesses the allowance for credit loss related to financing receivables on either an individual or a collective basis. The Company considers various factors in evaluating lease and loan receivables and the earned portion of financed service contracts for possible impairment on an individual basis. These factors include the Company’s historical experience, credit quality and age of the receivable balances, and economic conditions that may affect a customer’s ability to pay. When the evaluation indicates that it is probable that all amounts due pursuant to the contractual terms of the financing agreement, including scheduled interest payments, are unable to be collected, the financing receivable is considered impaired. All such outstanding amounts, including any accrued interest, are assessed and fully reserved at the customer level. The Company’s internal credit risk ratings are categorized as 1 through 10, with the lowest credit risk rating representing the highest quality financing receivables. Typically, the Company also considers financing receivables with a risk rating of 8 or higher to be impaired and will include them in the individual assessment for allowance. The Company evaluates the remainder of its financing receivables portfolio for impairment on a collective basis and records an allowance for credit loss at the portfolio segment level. When evaluating the financing receivables on a collective basis, the Company uses historical default rates and expected default frequency rates published by major third-party credit-rating agencies as well as its own historical loss rate in the event of default, while also systematically giving effect to economic conditions, concentration of risk, and correlation.

[0000858877-17-000016:notes:406]
Expected default frequency rates and historical default rates are published quarterly by major third-party credit-rating agencies, and the internal credit risk rating is derived by taking into consideration various customer-specific factors and macroeconomic conditions. These factors, which include the strength of the customer’s business and financial performance, the quality of the customer’s banking relationships, the Company’s specific historical experience with the customer, the performance and outlook of the customer’s industry, the customer’s legal and regulatory environment, the potential sovereign risk of the geographic locations in which the customer is operating, and independent third-party evaluations, are updated regularly or when facts and circumstances indicate that an update is deemed necessary.

[0000858877-17-000016:notes:407]
Financing receivables are written off at the point when they are considered uncollectible, and all outstanding balances, including any previously earned but uncollected interest income, will be reversed and charged against the allowance for credit loss. The Company does not typically have any partially written-off financing receivables.

[0000858877-17-000016:notes:408]
Outstanding financing receivables that are aged 31 days or more from the contractual payment date are considered past due. The Company does not accrue interest on financing receivables that are considered impaired or more than 90 days past due unless either the receivable has not been collected due to administrative reasons or the receivable is well secured and in the process of collection. Financing receivables may be placed on nonaccrual status earlier if, in management’s opinion, a timely collection of the full principal and interest becomes uncertain. After a financing receivable has been categorized as nonaccrual, interest will be recognized when cash is received. A financing receivable may be returned to accrual status after all of the customer’s delinquent balances of principal and interest have been settled, and the customer remains current for an appropriate period.

[0000858877-17-000016:notes:409]
The Company facilitates arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, generally with payment terms ranging from 60 to 90 days. In certain instances, these financing arrangements result in a transfer of the Company’s receivables to the third party. The receivables are derecognized upon transfer, as these transfers qualify as true sales, and the Company receives a payment for the receivables from the third party based on the Company’s standard payment terms. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, the Company guarantees a portion of these arrangements. The Company also provides financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. The Company could be called upon to make payments under these guarantees in the event of nonpayment by the channel partners or end-user customers. Deferred revenue relating to these financing arrangements is recorded in accordance with revenue recognition policies or for the fair value of the financing guarantees.

[0000858877-17-000016:notes:410]
(k) Fair Value   Fair value is defined as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities required or permitted to be either recorded or disclosed at fair value, the Company considers the principal or most advantageous market in which it would transact, and it also considers assumptions that market participants would use when pricing the asset or liability.

[0000858877-17-000016:notes:411]
The accounting guidance for fair value measurement requires an entity to maximize the use of observable inputs and minimize the use of unobservable inputs when measuring fair value. The standard establishes a fair value hierarchy based on the level of independent, objective evidence surrounding the inputs used to measure fair value. A financial instrument’s categorization within the fair value hierarchy is based upon the lowest level of input that is significant to the fair value measurement. The fair value hierarchy is as follows:

[0000858877-17-000016:notes:412]
Level 1 applies to assets or liabilities for which there are quoted prices in active markets for identical assets or liabilities.

[0000858877-17-000016:notes:413]
Level 2 applies to assets or liabilities for which there are inputs other than quoted prices that are observable for the asset or liability such as quoted prices for similar assets or liabilities in active markets; quoted prices for identical assets or liabilities in markets with insufficient volume or infrequent transactions (less active markets); or model-derived valuations in which significant inputs are observable or can be derived principally from, or corroborated by, observable market data.

[0000858877-17-000016:notes:414]
Level 3 applies to assets or liabilities for which there are unobservable inputs to the valuation methodology that are significant to the measurement of the fair value of the assets or liabilities.

[0000858877-17-000016:notes:415]
(p) Advertising Costs   The Company expenses all advertising costs as incurred. Advertising costs included within sales and marketing expenses were approximately $209 million, $186 million, and $202 million for fiscal 2017, 2016, and 2015, respectively.

[0000858877-17-000016:notes:416]
(u) Consolidation of Variable Interest Entities  The Company uses a qualitative approach in assessing the consolidation requirement for variable interest entities. The approach focuses on identifying which enterprise has the power to direct the activities that most significantly impact the variable interest entity’s economic performance and which enterprise has the obligation to absorb losses or the right to receive benefits from the variable interest entity. In the event that the Company is the primary beneficiary of a variable interest entity, the assets, liabilities, and results of operations of the variable interest entity will be included in the Company’s Consolidated Financial Statements.

[0000858877-17-000016:notes:417]
(v) Use of Estimates   The preparation of financial statements and related disclosures in conformity with accounting principles generally accepted in the United States requires management to make estimates and judgments that affect the amounts reported in the Consolidated Financial Statements and accompanying notes. Estimates are used for the following, among others:

[0000858877-17-000016:notes:418]
| ▪ | Revenue recognition |

[0000858877-17-000016:notes:419]
| ▪ | Allowances for accounts receivable, sales returns, and financing receivables |

[0000858877-17-000016:notes:420]
| ▪ | Inventory valuation and liability for purchase commitments with contract manufacturers and suppliers |

[0000858877-17-000016:notes:421]
| ▪ | Loss contingencies and product warranties |

[0000858877-17-000016:notes:422]
| ▪ | Fair value measurements and other-than-temporary impairments |

[0000858877-17-000016:notes:423]
| ▪ | Goodwill and purchased intangible asset impairments |

[0000858877-17-000016:notes:424]
| ▪ | Income taxes |

[0000858877-17-000016:notes:425]
The actual results experienced by the Company may differ materially from management’s estimates.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000858877-17-000016:notes:426]
Shareholders’ Equity

[0000858877-17-000016:notes:427]
| (a) | Cash Dividends on Shares of Common Stock |

[0000858877-17-000016:notes:428]
During fiscal 2017, the Company declared and paid cash dividends of $1.10 per common share, or $5.5 billion, on the Company’s outstanding common stock.  During fiscal 2016, the Company declared and paid cash dividends of $0.94 per common share, or $4.8 billion, on the Company’s outstanding common stock.

[0000858877-17-000016:notes:429]
Any future dividends will be subject to the approval of the Company's Board of Directors.

[0000858877-17-000016:notes:430]
| (b) | Stock Repurchase Program |

[0000858877-17-000016:notes:431]
In September 2001, the Company’s Board of Directors authorized a stock repurchase program. As of July 29, 2017, the Company’s Board of Directors had authorized an aggregate repurchase of up to $112 billion of common stock under this program, and the remaining authorized repurchase amount was $11.7 billion, with no termination date. A summary of the stock repurchase activity under the stock repurchase program, reported based on the trade date, is summarized as follows (in millions, except per-share amounts):

[0000858877-17-000016:notes:432]
| (c) | Restricted Stock Unit Withholdings |

[0000858877-17-000016:notes:433]
For the years ended July 29, 2017 and July 30, 2016, the Company repurchased approximately 20 million and 21 million shares, or $619 million and $557 million, of common stock, respectively, in settlement of employee tax withholding obligations due upon the vesting of restricted stock or stock units.

[0000858877-17-000016:notes:434]
| (d) | Preferred Stock |

[0000858877-17-000016:notes:435]
Under the terms of the Company’s Articles of Incorporation, the Board of Directors may determine the rights, preferences, and terms of the Company’s authorized but unissued shares of preferred stock.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000858877-17-000016:notes:436]
Balance Sheet Details


## us-gaap:TreasuryStockTextBlock

[0000858877-17-000016:notes:437]
Supplemental Information

[0000858877-17-000016:notes:438]
In September 2001, the Company’s Board of Directors authorized a stock repurchase program. As of July 29, 2017, the Company’s Board of Directors had authorized an aggregate repurchase of up to $112 billion of common stock under this program with no termination date. For additional information regarding stock repurchase, see Note 13 to the Consolidated Financial Statements. The stock repurchases since the inception of this program and the related impacts on Cisco shareholders’ equity are summarized in the following table (in millions):

[0000858877-17-000016:notes:439]
See Notes to Consolidated Financial Statements.
