# CSCO note change history — 0000858877-17-000004 → 0000858877-17-000010


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2017-05-23):
[0000858877-17-000010:note_history:1]
The Company leases office space in many U.S. locations. Outside the United States, larger leased sites include sites in Belgium, Canada, China, France, Germany, India, Israel, Japan, Poland and the United Kingdom. The Company also leases equipment and vehicles. Future minimum lease payments under all noncancelable operating leases with an initial term in excess of one year as of April 29, 2017 are as follows (in millions):
  (was, 2017-02-21, similarity 0.9858):
[0000858877-17-000004:note_history:1]
The Company leases office space in many U.S. locations. Outside the United States, larger leased sites include sites in Belgium, Canada, China, France, Germany, India, Israel, Japan, Poland and the United Kingdom. The Company also leases equipment and vehicles. Future minimum lease payments under all noncancelable operating leases with an initial term in excess of one year as of January 28, 2017 are as follows (in millions):

- changed (2017-05-23):
[0000858877-17-000010:note_history:2]
| Fiscal Year | Amount |
| 2017 (remaining three months) | $ | 115 |  |
| 2018 | 355 |  |
| 2019 | 230 |  |
| 2020 | 161 |  |
| 2021 | 98 |  |
| Thereafter | 201 |  |
| Total | $ | 1,160 |  |
  (was, 2017-02-21, similarity 0.9739):
[0000858877-17-000004:note_history:2]
| Fiscal Year | Amount |
| 2017 (remaining six months) | $ | 213 |  |
| 2018 | 334 |  |
| 2019 | 208 |  |
| 2020 | 142 |  |
| 2021 | 83 |  |
| Thereafter | 175 |  |
| Total | $ | 1,155 |  |

- changed (2017-05-23):
[0000858877-17-000010:note_history:3]
The Company purchases components from a variety of suppliers and uses several contract manufacturers to provide manufacturing services for its products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, the Company enters into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by the Company or establish the parameters defining the Company’s requirements.  A significant portion of the Company’s reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. In certain instances, these agreements allow the Company the option to cancel, reschedule, and adjust the Company’s requirements based on its business needs prior to firm orders being placed.  As of April 29, 2017 and July 30, 2016, the Company had total purchase commitments for inventory of $4,720 million and $3,896 million, respectively.
  (was, 2017-02-21, similarity 0.994):
[0000858877-17-000004:note_history:3]
The Company purchases components from a variety of suppliers and uses several contract manufacturers to provide manufacturing services for its products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, the Company enters into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by the Company or establish the parameters defining the Company’s requirements.  A significant portion of the Company’s reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. In certain instances, these agreements allow the Company the option to cancel, reschedule, and adjust the Company’s requirements based on its business needs prior to firm orders being placed.  As of January 28, 2017 and July 30, 2016, the Company had total purchase commitments for inventory of $4,402 million and $3,896 million, respectively.

- changed (2017-05-23):
[0000858877-17-000010:note_history:4]
The Company records a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of its future demand forecasts consistent with the valuation of the Company’s excess and obsolete inventory. As of April 29, 2017 and July 30, 2016, the liability for these purchase commitments was $179 million and $159 million, respectively, and was included in other current liabilities.
  (was, 2017-02-21, similarity 0.9621):
[0000858877-17-000004:note_history:4]
The Company records a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of its future demand forecasts consistent with the valuation of the Company’s excess and obsolete inventory. As of January 28, 2017 and July 30, 2016, the liability for these purchase commitments was $172 million and $159 million, respectively, and was included in other current liabilities.

- changed (2017-05-23):
[0000858877-17-000010:note_history:5]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 29, 2017 |  | April 30, 2016 |  | April 29, 2017 |  | April 30, 2016 |
| Compensation expense related to acquisitions | $ | 36 |  |  | $ | 68 |  |  | $ | 173 |  |  | $ | 212 |  |
  (was, 2017-02-21, similarity 0.7309):
[0000858877-17-000004:note_history:5]
|  | Three Months Ended |  | Six Months Ended |
|  | January 28, 2017 |  | January 23, 2016 |  | January 28, 2017 |  | January 23, 2016 |
| Compensation expense related to acquisitions | $ | 73 |  |  | $ | 71 |  |  | $ | 137 |  |  | $ | 144 |  |

- changed (2017-05-23):
[0000858877-17-000010:note_history:6]
As of April 29, 2017, the Company estimated that future cash compensation expense of up to $222 million may be required to be recognized pursuant to the applicable business combination agreements, which included the remaining potential compensation expense related to Insieme Networks, Inc. ("Insieme"), as more fully discussed immediately below.
  (was, 2017-02-21, similarity 0.9823):
[0000858877-17-000004:note_history:6]
As of January 28, 2017, the Company estimated that future cash compensation expense of up to $220 million may be required to be recognized pursuant to the applicable business combination agreements, which included the remaining potential compensation expense related to Insieme Networks, Inc. ("Insieme"), as more fully discussed immediately below.

- changed (2017-05-23):
[0000858877-17-000010:note_history:7]
During the first quarter of fiscal 2014, the Company exercised its call option and entered into an agreement to purchase the remaining interests in Insieme. The acquisition closed in the second quarter of fiscal 2014, at which time the former noncontrolling interest holders became eligible to receive up to two milestone payments, which will be determined using agreed-upon formulas based primarily on revenue for certain of Insieme’s products. The Company recorded compensation expense of $9 million and $35 million during the three months ended April 29, 2017 and April 30, 2016, respectively, and $41 million and $136 million during the nine months ended April 29, 2017 and April 30, 2016, respectively, related to the fair value of the vested portion of amounts that were earned or are expected to be earned by the former noncontrolling interest holders. Continued vesting will result in additional compensation expense in future periods. Based on the terms of the agreement, the Company has determined that the maximum amount that could be recorded as compensation expense by the Company is approximately $831 million (which includes the $824 million that has been expensed to date), net of forfeitures. The former noncontrolling interest holders earned the maximum amount related to these two milestone payments and were paid approximately $436 million and $375 million during the nine months ended April 29, 2017 and April 30, 2016, respectively. As of April 29, 2017, the Company paid a total of approximately $825 million pursuant to these two milestone payments.
  (was, 2017-02-21, similarity 0.9315):
[0000858877-17-000004:note_history:7]
During the first quarter of fiscal 2014, the Company exercised its call option and entered into an agreement to purchase the remaining interests in Insieme. The acquisition closed in the second quarter of fiscal 2014, at which time the former noncontrolling interest holders became eligible to receive up to two milestone payments, which will be determined using agreed-upon formulas based primarily on revenue for certain of Insieme’s products. The Company recorded compensation expense of $12 million and $50 million during the three months ended January 28, 2017 and January 23, 2016, respectively, and $32 million and $101 million during the six months ended January 28, 2017 and January 23, 2016, respectively, related to the fair value of the vested portion of amounts that were earned or are expected to be earned by the former noncontrolling interest holders. Continued vesting will result in additional compensation expense in future periods. Based on the terms of the agreement, the Company has determined that the maximum amount that could be recorded as compensation expense by the Company is approximately $831 million (which includes the $815 million that has been expensed to date), net of forfeitures. The former noncontrolling interest holders earned the maximum amount related to these two milestone payments and were paid approximately $422 million and $354 million during the six months ended January 28, 2017 and January 23, 2016, respectively.  As of January 28, 2017, the Company paid a total of approximately $811 million pursuant to these two milestone payments.

- added (2017-05-23):
[0000858877-17-000010:note_history:8]
|  | Nine Months Ended |
|  | April 29, 2017 |  | April 30, 2016 |
| Balance at beginning of period | $ | 414 |  |  | $ | 449 |  |
| Provisions for warranty issued | 528 |  |  | 520 |  |
| Adjustments for pre-existing warranties | (17 | ) |  | (8 | ) |
| Settlements | (511 | ) |  | (524 | ) |
| Divestitures | — |  |  | (28 | ) |
| Balance at end of period | $ | 414 |  |  | $ | 409 |  |

- changed (2017-05-23):
[0000858877-17-000010:note_history:9]
Channel Partner Financing Guarantees   The Company facilitates arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, generally with payment terms ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, the Company guarantees a portion of these arrangements. The volume of channel partner financing was $6.6 billion and $6.4 billion for the three months ended April 29, 2017 and April 30, 2016, respectively, and was $19.7 billion and $19.8 billion for the nine months ended April 29, 2017 and April 30, 2016, respectively. The balance of the channel partner financing subject to guarantees was $0.9 billion and $1.1 billion as of April 29, 2017 and July 30, 2016, respectively.
  (was, 2017-02-21, similarity 0.9047):
[0000858877-17-000004:note_history:9]
Channel Partner Financing Guarantees   The Company facilitates arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, generally with payment terms ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, the Company guarantees a portion of these arrangements. The volume of channel partner financing was $6.3 billion and $6.5 billion for the three months ended January 28, 2017 and January 23, 2016, respectively, and was $13.2 billion and $13.4 billion for the six months ended January 28, 2017 and January 23, 2016, respectively. The balance of the channel partner financing subject to guarantees was $1.2 billion and $1.1 billion as of January 28, 2017 and July 30, 2016, respectively.

- changed (2017-05-23):
[0000858877-17-000010:note_history:10]
End-User Financing Guarantees   The Company also provides financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. The volume of financing provided by third parties for leases and loans as to which the Company had provided guarantees was $10 million and $18 million for the three months ended April 29, 2017 and April 30, 2016, respectively, and was $47 million and $57 million for the nine months ended April 29, 2017 and April 30, 2016, respectively.
  (was, 2017-02-21, similarity 0.8897):
[0000858877-17-000004:note_history:10]
End-User Financing Guarantees   The Company also provides financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. The volume of financing provided by third parties for leases and loans as to which the Company had provided guarantees was $30 million and $16 million for the three months ended January 28, 2017 and January 23, 2016, respectively, and was $36 million and $39 million for the six months ended January 28, 2017 and January 23, 2016, respectively.

- changed (2017-05-23):
[0000858877-17-000010:note_history:11]
Financing Guarantee Summary   The aggregate amounts of financing guarantees outstanding at April 29, 2017 and July 30, 2016, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):
  (was, 2017-02-21, similarity 0.9807):
[0000858877-17-000004:note_history:11]
Financing Guarantee Summary   The aggregate amounts of financing guarantees outstanding at January 28, 2017 and July 30, 2016, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

- added (2017-05-23):
[0000858877-17-000010:note_history:12]
|  | April 29, 2017 |  | July 30, 2016 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 260 |  |  | $ | 281 |  |
| End user | 83 |  |  | 96 |  |
| Total | $ | 343 |  |  | $ | 377 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (83 | ) |  | $ | (85 | ) |
| End user | (57 | ) |  | (76 | ) |
| Total | $ | (140 | ) |  | $ | (161 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue | $ | 203 |  |  | $ | 216 |  |

- changed (2017-05-23):
[0000858877-17-000010:note_history:13]
Other Guarantees   The Company’s other guarantee arrangements as of April 29, 2017 and July 30, 2016 that were subject to recognition and disclosure requirements were not material.
  (was, 2017-02-21, similarity 0.9763):
[0000858877-17-000004:note_history:13]
Other Guarantees   The Company’s other guarantee arrangements as of January 28, 2017 and July 30, 2016 that were subject to recognition and disclosure requirements were not material.

- changed (2017-05-23):
[0000858877-17-000010:note_history:14]
In the second quarter of fiscal 2014, the Company recorded a charge to product cost of sales of $655 million resulting from failures related to products containing memory components manufactured by a single supplier between 2005 and 2010. The Company performs regular assessments of the sufficiency of this liability and reduced the amount by a total of $238 million in fiscal 2016 and fiscal 2015 based on updated analyses. During the second quarter of fiscal 2017, the Company further reduced the liability by $141 million to reflect lower than expected defects, actual usage history, and estimated lower future remediation costs as more of the impacted products age and near the end of the support period covered by the remediation program.
  (was, 2017-02-21, similarity 0.9269):
[0000858877-17-000004:note_history:14]
In the second quarter of fiscal 2014, the Company recorded a charge to product cost of sales of $655 million resulting from  failures related to products containing memory components manufactured by a single supplier between 2005 and 2010. The Company performs regular assessments of the sufficiency of this liability and reduced the amount by a total of $238 million in fiscal 2016 and fiscal 2015 based on updated analyses.  During the second quarter of fiscal 2017, the Company further reduced the liability by $141 million to reflect lower than expected defects, actual usage history, and estimated lower future remediation costs as more of the impacted products age and near the end of the support period covered by the remediation program. The liability related to this matter as of January 28, 2017 and July 30, 2016 was $105 million and $276 million, respectively.

- changed (2017-05-23):
[0000858877-17-000010:note_history:15]
In addition, during the second quarter of fiscal 2017, the Company recorded a charge to product cost of sales of $125 million related to the expected remediation costs for anticipated failures in future periods of a widely-used component sourced from a third party which is included in several of the Company’s products.
  (was, 2017-02-21, similarity 0.9797):
[0000858877-17-000004:note_history:15]
In addition, during the second quarter of fiscal 2017, the Company recorded a charge to product cost of sales of $125 million related to the expected remediation costs for anticipated failures in future periods of a widely-used clock-signal component sourced from a third party which is included in several of the Company’s products.

- added (2017-05-23):
[0000858877-17-000010:note_history:16]
The liability related to these matters as of April 29, 2017 and July 30, 2016 was $206 million and $276 million, respectively.

- added (2017-05-23):
[0000858877-17-000010:note_history:17]
The Company has been asked to provide partial indemnification in matters involving certain of the Company’s service provider customers that are subject to patent infringement claims asserted by Sprint Communications Company, L.P. in Kansas and Delaware. Sprint alleges that the service provider customers infringe Sprint’s patents by offering VoIP telephone services utilizing products provided by the Company and other manufacturers. Sprint seeks monetary damages. Sprint’s Kansas cases were stayed pending resolution of Sprint’s appeal of the Delaware court’s judgment that certain Sprint patents were invalid. The Court of Appeals for the Federal Circuit overturned the Delaware court’s judgment on September 23, 2016. As a result, Sprint’s Kansas cases were set for trial on February 13, 2017 against Time Warner Cable, Inc., et al., and March 6, 2017 against Comcast Cable Communications, LLC, et al., and its Delaware case was reset for trial on November 6, 2017 against Cox Communications, Inc., et al. On March 3, 2017, a jury in Kansas found that Time Warner Cable willfully infringed five Sprint patents and awarded Sprint $139.8 million in damages a portion of which if upheld on appeal could be subject to indemnification by the Company. On March 14, 2017, the Kansas court declined Sprint's request for enhanced damages based on the jury's willfulness finding and entered judgment in favor of Sprint for $139.8 million plus 1.06% in post-judgment interest. Sprint has since requested $20.3 million in pre-judgment interest. Time Warner Cable has opposed Sprint's request for pre-judgment interest and has filed post-trial motions to set aside the verdict or seek a new trial. Sprint's trial against Comcast was continued until October 30, 2017.

- changed (2017-05-23):
[0000858877-17-000010:note_history:18]
The asserted claims by Brazilian federal tax authorities that remain are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $255 million for the alleged evasion of import and other taxes, $1.5 billion for interest, and $1.2 billion for various penalties, all determined using an exchange rate as of April 29, 2017. The Company has completed a thorough review of the matters and believes the asserted claims against the Company’s Brazilian subsidiary are without merit, and the Company is defending the claims vigorously. While the Company believes there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, the Company is unable to determine the likelihood of an unfavorable outcome against its Brazilian subsidiary and is unable to reasonably estimate a range of loss, if any. The Company does not expect a final judicial determination for several years.
  (was, 2017-02-21, similarity 0.9949):
[0000858877-17-000004:note_history:18]
The asserted claims by Brazilian federal tax authorities that remain are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $258 million for the alleged evasion of import and other taxes, $1.4 billion for interest, and $1.2 billion for various penalties, all determined using an exchange rate as of January 28, 2017. The Company has completed a thorough review of the matters and believes the asserted claims against the Company’s Brazilian subsidiary are without merit, and the Company is defending the claims vigorously. While the Company believes there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, the Company is unable to determine the likelihood of an unfavorable outcome against its Brazilian subsidiary and is unable to reasonably estimate a range of loss, if any. The Company does not expect a final judicial determination for several years.

- added (2017-05-23):
[0000858877-17-000010:note_history:19]
SSL     SSL Services, LLC (“SSL”) has asserted claims for patent infringement against the Company in the U.S. District Court for the Eastern District of Texas. The proceeding was instituted on March 25, 2015. SSL alleges that the Company's AnyConnect products that include Virtual Private Networking functions infringed a U.S. patent owned by SSL. SSL seeks money damages from the Company. On August 18, 2015, Cisco petitioned the Patent Trial and Appeal Board (“PTAB”) of the United States Patent and Trademark Office to review whether the patent SSL has asserted against the Company is valid over prior art. On February 23, 2016, a PTAB multi-judge panel found a reasonable likelihood that Cisco would prevail in showing that SSL’s patent claims are unpatentable and instituted proceedings. On June 28, 2016, in light of the PTAB’s decision to review the patent’s validity, the district court issued an order staying the district court case pending the final written decision from the PTAB. On February 22, 2017, following a hearing, the PTAB issued its Final Written Decision that the patent’s claims are unpatentable. SSL has filed a notice that it intends to appeal this decision to the Court of Appeals for the Federal Circuit. The Company believes it has strong arguments that the Company's products do not infringe and the patent is invalid. If the Company does not prevail and a jury were to find that the Company's AnyConnect products infringe, the Company believes damages, as appropriately measured, would be immaterial. Due to uncertainty surrounding patent litigation processes, however, the Company is unable to reasonably estimate the ultimate outcome of this litigation at this time.

- removed (2017-05-23):
[0000858877-17-000004:note_history:20]
|  | Six Months Ended |
|  | January 28, 2017 |  | January 23, 2016 |
| Balance at beginning of period | $ | 414 |  |  | $ | 449 |  |
| Provisions for warranty issued | 367 |  |  | 335 |  |
| Adjustments for pre-existing warranties | (3 | ) |  | (13 | ) |
| Settlements | (352 | ) |  | (340 | ) |
| Divestitures | — |  |  | (28 | ) |
| Balance at end of period | $ | 426 |  |  | $ | 403 |  |

- removed (2017-05-23):
[0000858877-17-000004:note_history:21]
|  | January 28, 2017 |  | July 30, 2016 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 318 |  |  | $ | 281 |  |
| End user | 94 |  |  | 96 |  |
| Total | $ | 412 |  |  | $ | 377 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (99 | ) |  | $ | (85 | ) |
| End user | (63 | ) |  | (76 | ) |
| Total | $ | (162 | ) |  | $ | (161 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue | $ | 250 |  |  | $ | 216 |  |

- removed (2017-05-23):
[0000858877-17-000004:note_history:22]
The Company has been asked to provide indemnification in matters involving certain of the Company’s service provider customers that are subject to patent infringement claims asserted by Sprint Communications Company, L.P. in Kansas and Delaware. Sprint alleges that the service provider customers infringe Sprint’s patents by offering VoIP telephone services utilizing products provided by the Company and other manufacturers. Sprint seeks monetary damages. Sprint’s Kansas cases were stayed pending resolution of Sprint’s appeal of the Delaware court’s judgment that certain Sprint patents were invalid. The Court of Appeals for the Federal Circuit overturned the Delaware court’s judgment on September 23, 2016. As a result, Sprint’s Kansas cases are set for trial on February 13 and March 6, 2017 against Time Warner Cable and Comcast respectively, and its Delaware case was reset for trial on November 6, 2017 against Cox Communications.

- removed (2017-05-23):
[0000858877-17-000004:note_history:23]
SSL     SSL Services, LLC (“SSL”) has asserted claims for patent infringement against the Company in the U.S. District Court for the Eastern District of Texas. The proceeding was instituted on March 25, 2015. SSL alleges that the Company's AnyConnect products that include Virtual Private Networking functions infringed a U.S. patent owned by SSL. SSL seeks money damages from the Company. On August 18, 2015, Cisco petitioned the Patent Trial and Appeal Board (“PTAB”) of the United States Patent and Trademark Office to review whether the patent SSL has asserted against the Company is valid over prior art. On February 23, 2016, a PTAB multi-judge panel found a reasonable likelihood that Cisco would prevail in showing that SSL’s patent claims are unpatentable and instituted proceedings. The PTAB held a hearing to review the Company's petition on November 15, 2016 and a decision is expected by February 23, 2017. The district court issued an order on June 28, 2016 staying the district court case pending the final written decision from the PTAB. The Company believes it has strong arguments that the Company's products do not infringe and the patent is invalid. If the Company does not prevail and a jury were to find that the Company's AnyConnect products infringe, the Company believes damages, as appropriately measured, would be immaterial. Due to uncertainty surrounding patent litigation processes, however, the Company is unable to reasonably estimate the ultimate outcome of this litigation at this time.

- removed (2017-05-23):
[0000858877-17-000004:note_history:24]
Kangtega     Cisco Systems GmbH (“Cisco GmbH”) was subject to patent claims by Kangtega GmbH (“Kangtega”), instituted on June 6, 2013, alleging that Cisco GmbH infringed in Germany a European Patent by marketing in Germany network intrusion-detection (or firewall) products known as the “ASA” firewall offering. On April 29, 2014, the Mannheim Regional Court dismissed the infringement action, finding no infringement by Cisco GmbH of the asserted patent. On November 23, 2016, a court of appeal in Germany (Oberlandesgericht Karlsruhe) heard an appeal of that judgment and the parties thereafter executed a settlement agreement resolving all aspects of the proceedings. The resolution did not have a material impact on the Company's results of operations.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-05-23):
[0000858877-17-000010:note_history:25]
The accompanying financial data as of April 29, 2017 and for the three and nine months ended April 29, 2017 and April 30, 2016 has been prepared by the Company, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission ("SEC"). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States ("GAAP") have been condensed or omitted pursuant to such rules and regulations. The July 30, 2016 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, the Company believes that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended July 30, 2016.
  (was, 2017-02-21, similarity 0.9661):
[0000858877-17-000004:note_history:25]
The accompanying financial data as of January 28, 2017 and for the three and six months ended January 28, 2017 and January 23, 2016 has been prepared by the Company, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission ("SEC"). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States ("GAAP") have been condensed or omitted pursuant to such rules and regulations. The July 30, 2016 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, the Company believes that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended July 30, 2016.

- changed (2017-05-23):
[0000858877-17-000010:note_history:26]
In the opinion of management, all normal recurring adjustments necessary to present fairly the consolidated balance sheet as of April 29, 2017; the results of operations and the statements of comprehensive income for the three and nine months ended April 29, 2017 and April 30, 2016; and the statements of cash flows and equity for the nine months ended April 29, 2017 and April 30, 2016, as applicable, have been made. The results of operations for the three and nine months ended April 29, 2017 are not necessarily indicative of the operating results for the full fiscal year or any future periods.
  (was, 2017-02-21, similarity 0.8143):
[0000858877-17-000004:note_history:26]
In the opinion of management, all normal recurring adjustments necessary to present fairly the consolidated balance sheet as of January 28, 2017; the results of operations and the statements of comprehensive income for the three and six months ended January 28, 2017 and January 23, 2016; and the statements of cash flows and equity for the six months ended January 28, 2017 and January 23, 2016, as applicable, have been made. The results of operations for the three and six months ended January 28, 2017 are not necessarily indicative of the operating results for the full fiscal year or any future periods.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-05-23):
[0000858877-17-000010:note_history:27]
Share-Based Compensation  In March 2016, the FASB issued an accounting standard update that impacts the accounting for share-based payment transactions, including income tax consequences, classification of awards as either equity or liabilities, and classification on the Consolidated Statements of Cash Flows. The accounting standard will be effective for the Company beginning the first quarter of fiscal 2018, and early adoption is permitted. The Company does not expect that this accounting standard update will have a material impact on its Consolidated Financial Statements.
  (was, 2017-02-21, similarity 0.87):
[0000858877-17-000004:note_history:27]
Share-Based Compensation  In March 2016, the FASB issued an accounting standard update that impacts the accounting for share-based payment transactions, including income tax consequences, classification of awards as either equity or liabilities, and classification on the Consolidated Statements of Cash Flows. The accounting standard will be effective for the Company beginning the first quarter of fiscal 2018, and early adoption is permitted. The Company is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.

- changed (2017-05-23):
[0000858877-17-000010:note_history:28]
Definition of a Business  In January 2017, the FASB issued an accounting standard update that clarifies the definition of a business to help companies evaluate whether acquisition or disposal transactions should be accounted for as asset groups or as businesses. The accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2019 on a prospective basis. The impact of this accounting standard update will be fact dependent, but the Company expects that some transactions that were previously accounted for as business combinations or disposal transactions will be accounted for as asset purchases or asset sales under the accounting standard update.
  (was, 2017-02-21, similarity 0.9765):
[0000858877-17-000004:note_history:28]
Definition of a Business  In January 2017, the FASB issued an accounting standard update that clarifies the definition of a business to help companies evaluate whether acquisition or disposal transactions should be accounted for as asset groups or as businesses. The accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2019 on a prospective basis. The impact of this accounting standard update will be facts and circumstances dependent, but the Company expects that in some situations transactions that were previously accounted for as business combinations  or disposal transactions will be accounted for as asset purchases or asset sales under the accounting standard update.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-05-23):
[0000858877-17-000010:note_history:29]
|  | April 29, 2017 |  | July 30, 2016 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 2,248 |  |  | 1.58 | % |  | $ | 4,159 |  |  | 0.97 | % |
| Commercial paper | 2,000 |  |  | 0.88 | % |  | — |  |  | — |  |
| Other notes and borrowings | — |  |  | — |  |  | 1 |  |  | 2.08 | % |
| Total short-term debt | $ | 4,248 |  |  |  |  | $ | 4,160 |  |  |  |
  (was, 2017-02-21, similarity 0.9825):
[0000858877-17-000004:note_history:29]
|  | January 28, 2017 |  | July 30, 2016 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 4,151 |  |  | 1.26 | % |  | $ | 4,159 |  |  | 0.97 | % |
| Commercial paper | 300 |  |  | 0.73 | % |  | — |  |  | — |  |
| Other notes and borrowings | — |  |  | — |  |  | 1 |  |  | 2.08 | % |
| Total short-term debt | $ | 4,451 |  |  |  |  | $ | 4,160 |  |  |  |

- added (2017-05-23):
[0000858877-17-000010:note_history:30]
Effective March 31, 2017, the Company increased its borrowing capacity under its existing commercial paper program from $3.0 billion to $10.0 billion. The Company uses the proceeds from the issuance of commercial paper notes for general corporate purposes. The Company had $2.0 billion and no commercial paper notes outstanding as of April 29, 2017 and July 30, 2016, respectively.

- changed (2017-05-23):
[0000858877-17-000010:note_history:31]
|  |  |  | April 29, 2017 |  | July 30, 2016 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.28% | March 3, 2017 | (1) | $ | — |  |  | — |  | $ | 1,000 |  |  | 1.03% |
| Three-month LIBOR plus 0.60% | February 21, 2018 |  | 1,000 |  |  | 1.72% |  | 1,000 |  |  | 1.32% |
| Three-month LIBOR plus 0.31% | June 15, 2018 |  | 900 |  |  | 1.51% |  | 900 |  |  | 1.03% |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | 500 |  |  | 1.62% |  | 500 |  |  | 1.23% |
| Three-month LIBOR plus 0.34% | September 20, 2019 | (2) | 500 |  |  | 1.53% |  | — |  |  | — |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 1.10% | March 3, 2017 | (1) | — |  |  | — |  | 2,400 |  |  | 0.87% |
| 3.15% | March 14, 2017 | (1) | — |  |  | — |  | 750 |  |  | 1.22% |
| 1.40% | February 28, 2018 |  | 1,250 |  |  | 1.47% |  | 1,250 |  |  | 1.47% |
| 1.65% | June 15, 2018 |  | 1,600 |  |  | 1.72% |  | 1,600 |  |  | 1.72% |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 4.90% |  | 2,000 |  |  | 4.76% |
| 1.60% | February 28, 2019 |  | 1,000 |  |  | 1.67% |  | 1,000 |  |  | 1.67% |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 1.60% |  | 1,750 |  |  | 1.08% |
| 1.40% | September 20, 2019 | (2) | 1,500 |  |  | 1.48% |  | — |  |  | — |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 3.66% |  | 2,500 |  |  | 3.25% |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 2.54% |  | 1,500 |  |  | 2.54% |
| 2.20% | February 28, 2021 |  | 2,500 |  |  | 2.30% |  | 2,500 |  |  | 2.30% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 1.76% |  | 500 |  |  | 1.24% |
| 1.85% | September 20, 2021 | (2) | 2,000 |  |  | 1.90% |  | — |  |  | — |
| 3.00% | June 15, 2022 |  | 500 |  |  | 2.03% |  | 500 |  |  | 1.51% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 | (2) | 750 |  |  | 2.27% |  | — |  |  | — |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1.88% |  | 1,000 |  |  | 1.36% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 2.19% |  | 500 |  |  | 1.67% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 | (2) | 1,500 |  |  | 2.55% |  | — |  |  | — |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 30,500 |  |  |  |  | 28,400 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (140 | ) |  |  |  | (137 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 110 |  |  |  |  | 379 |  |  |  |
| Total |  |  | $ | 30,470 |  |  |  |  | $ | 28,642 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 2,248 |  |  |  |  | $ | 4,159 |  |  |  |
| Long-term debt |  |  | 28,222 |  |  |  |  | 24,483 |  |  |  |
| Total |  |  | $ | 30,470 |  |  |  |  | $ | 28,642 |  |  |  |
  (was, 2017-02-21, similarity 0.9794):
[0000858877-17-000004:note_history:31]
|  |  |  | January 28, 2017 |  | July 30, 2016 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.28% | March 3, 2017 |  | $ | 1,000 |  |  | 1.29% |  | $ | 1,000 |  |  | 1.03% |
| Three-month LIBOR plus 0.60% | February 21, 2018 |  | 1,000 |  |  | 1.58% |  | 1,000 |  |  | 1.32% |
| Three-month LIBOR plus 0.31% | June 15, 2018 |  | 900 |  |  | 1.34% |  | 900 |  |  | 1.03% |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | 500 |  |  | 1.49% |  | 500 |  |  | 1.23% |
| Three-month LIBOR plus 0.34% | September 20, 2019 | (1) | 500 |  |  | 1.38% |  | — |  |  | — |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 1.10% | March 3, 2017 |  | 2,400 |  |  | 1.17% |  | 2,400 |  |  | 0.87% |
| 3.15% | March 14, 2017 |  | 750 |  |  | 1.52% |  | 750 |  |  | 1.22% |
| 1.40% | February 28, 2018 |  | 1,250 |  |  | 1.47% |  | 1,250 |  |  | 1.47% |
| 1.65% | June 15, 2018 |  | 1,600 |  |  | 1.72% |  | 1,600 |  |  | 1.72% |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 4.84% |  | 2,000 |  |  | 4.76% |
| 1.60% | February 28, 2019 |  | 1,000 |  |  | 1.67% |  | 1,000 |  |  | 1.67% |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 1.39% |  | 1,750 |  |  | 1.08% |
| 1.40% | September 20, 2019 | (1) | 1,500 |  |  | 1.48% |  | — |  |  | — |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 3.47% |  | 2,500 |  |  | 3.25% |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 2.54% |  | 1,500 |  |  | 2.54% |
| 2.20% | February 28, 2021 |  | 2,500 |  |  | 2.30% |  | 2,500 |  |  | 2.30% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 1.55% |  | 500 |  |  | 1.24% |
| 1.85% | September 20, 2021 | (1) | 2,000 |  |  | 1.90% |  | — |  |  | — |
| 3.00% | June 15, 2022 |  | 500 |  |  | 1.80% |  | 500 |  |  | 1.51% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 | (1) | 750 |  |  | 2.27% |  | — |  |  | — |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1.66% |  | 1,000 |  |  | 1.36% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 1.96% |  | 500 |  |  | 1.67% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 | (1) | 1,500 |  |  | 2.55% |  | — |  |  | — |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 34,650 |  |  |  |  | 28,400 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (145 | ) |  |  |  | (137 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 117 |  |  |  |  | 379 |  |  |  |
| Total |  |  | $ | 34,622 |  |  |  |  | $ | 28,642 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 4,151 |  |  |  |  | $ | 4,159 |  |  |  |
| Long-term debt |  |  | 30,471 |  |  |  |  | 24,483 |  |  |  |
| Total |  |  | $ | 34,622 |  |  |  |  | $ | 28,642 |  |  |  |

- added (2017-05-23):
[0000858877-17-000010:note_history:32]
(1) In March 2017, the Company repaid senior notes with an aggregate principal amount of $4.15 billion upon maturity.

- changed (2017-05-23):
[0000858877-17-000010:note_history:33]
The effective rates for the fixed-rate debt include the interest on the notes, the accretion of the discount, the issuance costs, and, if applicable, adjustments related to hedging. Interest is payable semiannually on each class of the senior fixed-rate notes and payable quarterly on the floating-rate notes. Each of the senior fixed-rate notes is redeemable by the Company at any time, subject to a make-whole premium.
  (was, 2017-02-21, similarity 0.9756):
[0000858877-17-000004:note_history:33]
The effective rates for the fixed-rate debt include the interest on the notes, the accretion of the discount, and, if applicable, adjustments related to hedging. Interest is payable semiannually on each class of the senior fixed-rate notes and payable quarterly on the floating-rate notes. Each of the senior fixed-rate notes is redeemable by the Company at any time, subject to a make-whole premium.

- changed (2017-05-23):
[0000858877-17-000010:note_history:34]
The senior notes rank at par with the commercial paper notes that have been issued pursuant to the Company’s short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of April 29, 2017, the Company was in compliance with all debt covenants.
  (was, 2017-02-21, similarity 0.8976):
[0000858877-17-000004:note_history:34]
The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to the Company’s short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of January 28, 2017, the Company was in compliance with all debt covenants.

- changed (2017-05-23):
[0000858877-17-000010:note_history:35]
As of April 29, 2017, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):
  (was, 2017-02-21, similarity 0.9701):
[0000858877-17-000004:note_history:35]
As of January 28, 2017, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

- changed (2017-05-23):
[0000858877-17-000010:note_history:36]
| Fiscal Year | Amount |
| 2017 (remaining three months) | $ | — |  |
| 2018 | 4,750 |  |
| 2019 | 5,250 |  |
| 2020 | 6,000 |  |
| 2021 | 3,000 |  |
| Thereafter | 11,500 |  |
| Total | $ | 30,500 |  |
  (was, 2017-02-21, similarity 0.9673):
[0000858877-17-000004:note_history:36]
| Fiscal Year | Amount |
| 2017 (remaining six months) | $ | 4,150 |  |
| 2018 | 4,750 |  |
| 2019 | 5,250 |  |
| 2020 | 6,000 |  |
| 2021 | 3,000 |  |
| Thereafter | 11,500 |  |
| Total | $ | 34,650 |  |

- changed (2017-05-23):
[0000858877-17-000010:note_history:37]
| (c) | Credit Facilities |
  (was, 2017-02-21, similarity 0.9231):
[0000858877-17-000004:note_history:37]
| (c) | Credit Facility |

- changed (2017-05-23):
[0000858877-17-000010:note_history:38]
On May 15, 2015, the Company entered into a credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 15, 2020. Any advances under the credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (i) the highest of (a) the Federal Funds rate plus 0.50%, (b) Bank of America’s “prime rate” as announced from time to time, or (c) LIBOR, or a comparable or successor rate that is approved by the Administrative Agent (“Eurocurrency Rate”), for an interest period of one-month plus 1.00%, or (ii) the Eurocurrency Rate, plus a margin that is based on the Company’s senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the Eurocurrency Rate be less than zero. The Company may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and/or extend the expiration date of the credit facility up to May 15, 2022.
  (was, 2017-02-21, similarity 0.8105):
[0000858877-17-000004:note_history:38]
On May 15, 2015, the Company entered into a credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 15, 2020. Any advances under the credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (i) the highest of (a) the Federal Funds rate plus 0.50%, (b) Bank of America’s “prime rate” as announced from time to time, or (c) LIBOR, or a comparable or successor rate that is approved by the Administrative Agent (“Eurocurrency Rate”), for an interest period of one-month plus 1.00%, or (ii) the Eurocurrency Rate, plus a margin that is based on the Company’s senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the Eurocurrency Rate be less than zero.  The credit agreement requires the Company to comply with certain covenants, including that it maintains an interest coverage ratio as defined in the agreement.

- added (2017-05-23):
[0000858877-17-000010:note_history:39]
In addition, on March 30, 2017, the Company entered into a 364-Day credit agreement with certain institutional lenders that  provides for a $2.0 billion unsecured revolving credit facility that is scheduled to expire on March 29, 2018. The credit agreement also provides the Company with the option to, for a fee, convert any borrowing outstanding thereunder on March 29, 2018 to a term loan maturing no later than March 29, 2019. The interest rate applicable to outstanding balances under the credit agreement will be based on either (i) the higher of (a) the rates on overnight Federal Funds transactions with members of the Federal Reserve System (i.e., Federal Funds rate) plus 0.50%, (b) Bank of America’s “prime rate” as announced from time to time or (c) LIBOR for an interest period of one month plus 1.00%, or (ii) LIBOR plus a margin that is based on the Company's senior debt credit ratings as published by S&P Global Rating, a business unit of Standard & Poor’s Financial Services LLC, and Moody’s Investors Service, Inc.

- added (2017-05-23):
[0000858877-17-000010:note_history:40]
These credit agreements require that the Company comply with certain covenants, including that the Company maintains an interest coverage ratio as defined in these agreements. As of April 29, 2017, the Company was in compliance with the required interest coverage ratios and the other covenants, and the Company had not borrowed any funds under these credit facilities.

- removed (2017-05-23):
[0000858877-17-000004:note_history:41]
The Company has established a short-term debt financing program of up to $3.0 billion through the issuance of commercial paper notes. The Company uses the proceeds from the issuance of commercial paper notes for general corporate purposes. The Company had $300 million and no commercial paper notes outstanding as of January 28, 2017 and July 30, 2016, respectively.

- removed (2017-05-23):
[0000858877-17-000004:note_history:42]
The Company may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and/or extend the expiration date of the credit facility up to May 15, 2022. As of January 28, 2017, the Company was in compliance with the required interest coverage ratio and the other covenants, and the Company had not borrowed any funds under the credit facility.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-05-23):
[0000858877-17-000010:note_history:43]
| April 29, 2017 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| Fixed income securities: |  |  |  |  |  |  |  |
| U.S. government securities | $ | 20,951 |  |  | $ | 4 |  |  | $ | (67 | ) |  | $ | 20,888 |  |
| U.S. government agency securities | 2,233 |  |  | — |  |  | (6 | ) |  | 2,227 |  |
| Non-U.S. government and agency securities | 721 |  |  | — |  |  | (2 | ) |  | 719 |  |
| Corporate debt securities | 31,649 |  |  | 145 |  |  | (160 | ) |  | 31,634 |  |
| U.S. agency mortgage-backed securities | 2,038 |  |  | 3 |  |  | (18 | ) |  | 2,023 |  |
| Commercial paper | 635 |  |  | — |  |  | — |  |  | 635 |  |
| Certificates of deposit | 26 |  |  | — |  |  | — |  |  | 26 |  |
| Total fixed income securities | 58,253 |  |  | 152 |  |  | (253 | ) |  | 58,152 |  |
| Publicly traded equity securities | 1,177 |  |  | 533 |  |  | (4 | ) |  | 1,706 |  |
| Total (1) | $ | 59,430 |  |  | $ | 685 |  |  | $ | (257 | ) |  | $ | 59,858 |  |
  (was, 2017-02-21, similarity 0.8718):
[0000858877-17-000004:note_history:43]
| January 28, 2017 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| Fixed income securities: |  |  |  |  |  |  |  |
| U.S. government securities | $ | 22,910 |  |  | $ | 4 |  |  | $ | (82 | ) |  | $ | 22,832 |  |
| U.S. government agency securities | 2,401 |  |  | 1 |  |  | (5 | ) |  | 2,397 |  |
| Non-U.S. government and agency securities | 1,211 |  |  | — |  |  | (6 | ) |  | 1,205 |  |
| Corporate debt securities | 30,878 |  |  | 85 |  |  | (265 | ) |  | 30,698 |  |
| U.S. agency mortgage-backed securities | 2,031 |  |  | 2 |  |  | (27 | ) |  | 2,006 |  |
| Commercial paper | 195 |  |  | — |  |  | — |  |  | 195 |  |
| Total fixed income securities | 59,626 |  |  | 92 |  |  | (385 | ) |  | 59,333 |  |
| Publicly traded equity securities | 1,225 |  |  | 463 |  |  | (74 | ) |  | 1,614 |  |
| Total (1) | $ | 60,851 |  |  | $ | 555 |  |  | $ | (459 | ) |  | $ | 60,947 |  |

- changed (2017-05-23):
[0000858877-17-000010:note_history:44]
(1) Includes investments that were pending settlement as of the respective fiscal years. The net unsettled investment purchases were $80 million and $654 million as of April 29, 2017 and July 30, 2016, respectively.
  (was, 2017-02-21, similarity 0.9257):
[0000858877-17-000004:note_history:44]
(1) Includes investments that were pending settlement as of the respective fiscal years. The net unsettled investment purchases were $6 million and $654 million as of January 28, 2017 and July 30, 2016, respectively.

- changed (2017-05-23):
[0000858877-17-000010:note_history:45]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 29, 2017 |  | April 30, 2016 |  | April 29, 2017 |  | April 30, 2016 |
| Gross realized gains | $ | 43 |  |  | $ | 68 |  |  | $ | 91 |  |  | $ | 119 |  |
| Gross realized losses | (119 | ) |  | (74 | ) |  | (182 | ) |  | (145 | ) |
| Total | $ | (76 | ) |  | $ | (6 | ) |  | $ | (91 | ) |  | $ | (26 | ) |
  (was, 2017-02-21, similarity 0.8299):
[0000858877-17-000004:note_history:45]
|  | Three Months Ended |  | Six Months Ended |
|  | January 28, 2017 |  | January 23, 2016 |  | January 28, 2017 |  | January 23, 2016 |
| Gross realized gains | $ | 18 |  |  | $ | 16 |  |  | $ | 48 |  |  | $ | 51 |  |
| Gross realized losses | (48 | ) |  | (35 | ) |  | (63 | ) |  | (71 | ) |
| Total | $ | (30 | ) |  | $ | (19 | ) |  | $ | (15 | ) |  | $ | (20 | ) |

- changed (2017-05-23):
[0000858877-17-000010:note_history:46]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 29, 2017 |  | April 30, 2016 |  | April 29, 2017 |  | April 30, 2016 |
| Net gains (losses) on investments in publicly traded equity securities | $ | (59 | ) |  | $ | 25 |  |  | $ | (50 | ) |  | $ | 18 |  |
| Net gains (losses) on investments in fixed income securities | (17 | ) |  | (31 | ) |  | (41 | ) |  | (44 | ) |
| Total | $ | (76 | ) |  | $ | (6 | ) |  | $ | (91 | ) |  | $ | (26 | ) |
  (was, 2017-02-21, similarity 0.7598):
[0000858877-17-000004:note_history:46]
|  | Three Months Ended |  | Six Months Ended |
|  | January 28, 2017 |  | January 23, 2016 |  | January 28, 2017 |  | January 23, 2016 |
| Net gains (losses) on investments in publicly traded equity securities | $ | 4 |  |  | $ | 2 |  |  | $ | 9 |  |  | $ | (7 | ) |
| Net gains (losses) on investments in fixed income securities | (34 | ) |  | (21 | ) |  | (24 | ) |  | (13 | ) |
| Total | $ | (30 | ) |  | $ | (19 | ) |  | $ | (15 | ) |  | $ | (20 | ) |

- changed (2017-05-23):
[0000858877-17-000010:note_history:47]
The following tables present the breakdown of the available-for-sale investments with gross unrealized losses and the duration that those losses had been unrealized at April 29, 2017 and July 30, 2016 (in millions):
  (was, 2017-02-21, similarity 0.9709):
[0000858877-17-000004:note_history:47]
The following tables present the breakdown of the available-for-sale investments with gross unrealized losses and the duration that those losses had been unrealized at January 28, 2017 and July 30, 2016 (in millions):

- changed (2017-05-23):
[0000858877-17-000010:note_history:48]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| April 29, 2017 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| Fixed income securities: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | $ | 17,231 |  |  | $ | (67 | ) |  | $ | 16 |  |  | $ | — |  |  | $ | 17,247 |  |  | $ | (67 | ) |
| U.S. government agency securities | 1,980 |  |  | (6 | ) |  | — |  |  | — |  |  | 1,980 |  |  | (6 | ) |
| Non-U.S. government and agency securities | 607 |  |  | (2 | ) |  | 6 |  |  | — |  |  | 613 |  |  | (2 | ) |
| Corporate debt securities | 11,915 |  |  | (159 | ) |  | 78 |  |  | (1 | ) |  | 11,993 |  |  | (160 | ) |
| U.S. agency mortgage-backed securities | 1,448 |  |  | (18 | ) |  | 4 |  |  | — |  |  | 1,452 |  |  | (18 | ) |
| Total fixed income securities | 33,181 |  |  | (252 | ) |  | 104 |  |  | (1 | ) |  | 33,285 |  |  | (253 | ) |
| Publicly traded equity securities | 50 |  |  | (4 | ) |  | — |  |  | — |  |  | 50 |  |  | (4 | ) |
| Total | $ | 33,231 |  |  | $ | (256 | ) |  | $ | 104 |  |  | $ | (1 | ) |  | $ | 33,335 |  |  | $ | (257 | ) |
  (was, 2017-02-21, similarity 0.8669):
[0000858877-17-000004:note_history:48]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| January 28, 2017 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| Fixed income securities: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | $ | 16,303 |  |  | $ | (82 | ) |  | $ | 16 |  |  | $ | — |  |  | $ | 16,319 |  |  | $ | (82 | ) |
| U.S. government agency securities | 1,430 |  |  | (5 | ) |  | — |  |  | — |  |  | 1,430 |  |  | (5 | ) |
| Non-U.S. government and agency securities | 1,107 |  |  | (6 | ) |  | 6 |  |  | — |  |  | 1,113 |  |  | (6 | ) |
| Corporate debt securities | 15,180 |  |  | (264 | ) |  | 325 |  |  | (1 | ) |  | 15,505 |  |  | (265 | ) |
| U.S. agency mortgage-backed securities | 1,780 |  |  | (27 | ) |  | — |  |  | — |  |  | 1,780 |  |  | (27 | ) |
| Total fixed income securities | 35,800 |  |  | (384 | ) |  | 347 |  |  | (1 | ) |  | 36,147 |  |  | (385 | ) |
| Publicly traded equity securities | 63 |  |  | (6 | ) |  | 94 |  |  | (68 | ) |  | 157 |  |  | (74 | ) |
| Total | $ | 35,863 |  |  | $ | (390 | ) |  | $ | 441 |  |  | $ | (69 | ) |  | $ | 36,304 |  |  | $ | (459 | ) |

- added (2017-05-23):
[0000858877-17-000010:note_history:49]
For the three and nine months ended April 29, 2017, the net realized losses related to the Company's available-for-sale investments included impairment charges of $73 million. These impairment charges related primarily to publicly traded equity securities and were due to a decline in the fair value of those securities below their cost basis that were determined to be other than temporary. For the three and nine months ended April 30, 2016, the net realized losses related to the Company's available-for-sale investments included impairment charges of zero and $3 million, respectively, for fixed income securities.

- added (2017-05-23):
[0000858877-17-000010:note_history:50]
As of April 29, 2017, for fixed income securities that were in unrealized loss positions, the Company has determined that (i) it does not have the intent to sell any of these investments and (ii) it is not more likely than not that it will be required to sell any of these investments before recovery of the entire amortized cost basis. In addition, as of April 29, 2017, the Company anticipates that it will recover the entire amortized cost basis of such fixed income securities and has determined that no other-than-temporary impairments associated with credit losses were required to be recognized during the nine months ended April 29, 2017.

- changed (2017-05-23):
[0000858877-17-000010:note_history:51]
The Company has evaluated its publicly traded equity securities as of April 29, 2017 and has determined that there were no additional other-than-temporary impairments in the respective categories of unrealized losses. This determination was based on several factors, which include the length of time and extent to which fair value has been less than the cost basis, the financial condition and near-term prospects of the issuer, and the Company’s intent and ability to hold the publicly traded equity securities for a period of time sufficient to allow for any anticipated recovery in market value.
  (was, 2017-02-21, similarity 0.9805):
[0000858877-17-000004:note_history:51]
The Company has evaluated its publicly traded equity securities as of January 28, 2017 and has determined that there were no other-than-temporary impairments in the respective categories of unrealized losses. This determination was based on several factors, which include the length of time and extent to which fair value has been less than the cost basis, the financial condition and near-term prospects of the issuer, and the Company’s intent and ability to hold the publicly traded equity securities for a period of time sufficient to allow for any anticipated recovery in market value.

- changed (2017-05-23):
[0000858877-17-000010:note_history:52]
The following table summarizes the maturities of the Company’s fixed income securities as of April 29, 2017 (in millions):
  (was, 2017-02-21, similarity 0.9661):
[0000858877-17-000004:note_history:52]
The following table summarizes the maturities of the Company’s fixed income securities as of January 28, 2017 (in millions):

- changed (2017-05-23):
[0000858877-17-000010:note_history:53]
The Company periodically engages in securities lending activities with certain of its available for sale investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. The average daily balance of securities lending for the nine months ended April 29, 2017 and April 30, 2016 was $0.8 billion and $0.6 billion, respectively. The Company requires collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. The Company engages in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify the Company against collateral losses. The Company did not experience any losses in connection with the secured lending of securities during the periods presented. As of April 29, 2017 and July 30, 2016, the Company had no outstanding securities lending transactions.
  (was, 2017-02-21, similarity 0.9787):
[0000858877-17-000004:note_history:53]
The Company periodically engages in securities lending activities with certain of its available for sale investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. The average daily balance of securities lending for the six months ended January 28, 2017 and January 23, 2016 was $1.5 billion and $0.6 billion, respectively. The Company requires collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. The Company engages in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify the Company against collateral losses. The Company did not experience any losses in connection with the secured lending of securities during the periods presented. As of January 28, 2017 and July 30, 2016, the Company had no outstanding securities lending transactions.

- changed (2017-05-23):
[0000858877-17-000010:note_history:54]
The carrying value of the Company’s investments in privately held companies was included in other assets. For such investments that were accounted for under the equity and cost method as of April 29, 2017 and July 30, 2016, the amounts are summarized in the following table (in millions):
  (was, 2017-02-21, similarity 0.9784):
[0000858877-17-000004:note_history:54]
The carrying value of the Company’s investments in privately held companies was included in other assets. For such investments that were accounted for under the equity and cost method as of January 28, 2017 and July 30, 2016, the amounts are summarized in the following table (in millions):

- changed (2017-05-23):
[0000858877-17-000010:note_history:55]
|  | April 29, 2017 |  | July 30, 2016 |
| Equity method investments | $ | 130 |  |  | $ | 174 |  |
| Cost method investments | 820 |  |  | 829 |  |
| Total | $ | 950 |  |  | $ | 1,003 |  |
  (was, 2017-02-21, similarity 0.9742):
[0000858877-17-000004:note_history:55]
|  | January 28, 2017 |  | July 30, 2016 |
| Equity method investments | $ | 176 |  |  | $ | 174 |  |
| Cost method investments | 831 |  |  | 829 |  |
| Total | $ | 1,007 |  |  | $ | 1,003 |  |

- changed (2017-05-23):
[0000858877-17-000010:note_history:56]
Variable Interest Entities  In the ordinary course of business, the Company has investments in privately held companies and provides financing to certain customers. These privately held companies and customers may be considered to be variable interest entities. The Company evaluates on an ongoing basis its investments in these privately held companies and its customer financings, and has determined that as of April 29, 2017, except as disclosed in Note 1, there were no significant variable interest entities required to be consolidated in the Company’s Consolidated Financial Statements.
  (was, 2017-02-21, similarity 0.9897):
[0000858877-17-000004:note_history:56]
Variable Interest Entities  In the ordinary course of business, the Company has investments in privately held companies and provides financing to certain customers. These privately held companies and customers may be considered to be variable interest entities. The Company evaluates on an ongoing basis its investments in these privately held companies and its customer financings, and has determined that as of January 28, 2017, except as disclosed in Note 1, there were no significant variable interest entities required to be consolidated in the Company’s Consolidated Financial Statements.

- changed (2017-05-23):
[0000858877-17-000010:note_history:57]
As discussed in Note 2, during the first quarter of fiscal 2017, the Company adopted a new accounting standard update related to the consolidation of certain types of legal entities. As of April 29, 2017, the carrying value of the Company's investments in privately held companies was $950 million, of which $547 million of such investments are considered to be in variable interest entities which are unconsolidated. In addition, the Company has additional funding commitments of $170 million related to these investments, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The carrying value of these investments and the additional funding commitments collectively represent the Company's maximum exposure related to these variable interest entities.
  (was, 2017-02-21, similarity 0.9927):
[0000858877-17-000004:note_history:57]
As discussed in Note 2, during the first quarter of fiscal 2017, the Company adopted a new accounting standard update related to the consolidation of certain types of legal entities. As of January 28, 2017, the carrying value of the Company's investments in privately held companies was $1,007 million, of which $580 million of such investments are considered to be in variable interest entities which are unconsolidated. In addition, the Company has additional funding commitments of $182 million related to these investments, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The carrying value of these investments and the additional funding commitments collectively represent the Company's maximum exposure related to these variable interest entities.

- removed (2017-05-23):
[0000858877-17-000004:note_history:58]
As of January 28, 2017, for fixed income securities that were in unrealized loss positions, the Company has determined that (i) it does not have the intent to sell any of these investments and (ii) it is not more likely than not that it will be required to sell any of these investments before recovery of the entire amortized cost basis. In addition, as of January 28, 2017, the Company anticipates that it will recover the entire amortized cost basis of such fixed income securities and has determined that no other-than-temporary impairments associated with credit losses were required to be recognized during the six months ended January 28, 2017.


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-05-23):
[0000858877-17-000010:note_history:59]
|  |  |  | April 29, 2017 |  | July 30, 2016 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.28% | March 3, 2017 | (1) | $ | — |  |  | — |  | $ | 1,000 |  |  | 1.03% |
| Three-month LIBOR plus 0.60% | February 21, 2018 |  | 1,000 |  |  | 1.72% |  | 1,000 |  |  | 1.32% |
| Three-month LIBOR plus 0.31% | June 15, 2018 |  | 900 |  |  | 1.51% |  | 900 |  |  | 1.03% |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | 500 |  |  | 1.62% |  | 500 |  |  | 1.23% |
| Three-month LIBOR plus 0.34% | September 20, 2019 | (2) | 500 |  |  | 1.53% |  | — |  |  | — |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 1.10% | March 3, 2017 | (1) | — |  |  | — |  | 2,400 |  |  | 0.87% |
| 3.15% | March 14, 2017 | (1) | — |  |  | — |  | 750 |  |  | 1.22% |
| 1.40% | February 28, 2018 |  | 1,250 |  |  | 1.47% |  | 1,250 |  |  | 1.47% |
| 1.65% | June 15, 2018 |  | 1,600 |  |  | 1.72% |  | 1,600 |  |  | 1.72% |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 4.90% |  | 2,000 |  |  | 4.76% |
| 1.60% | February 28, 2019 |  | 1,000 |  |  | 1.67% |  | 1,000 |  |  | 1.67% |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 1.60% |  | 1,750 |  |  | 1.08% |
| 1.40% | September 20, 2019 | (2) | 1,500 |  |  | 1.48% |  | — |  |  | — |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 3.66% |  | 2,500 |  |  | 3.25% |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 2.54% |  | 1,500 |  |  | 2.54% |
| 2.20% | February 28, 2021 |  | 2,500 |  |  | 2.30% |  | 2,500 |  |  | 2.30% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 1.76% |  | 500 |  |  | 1.24% |
| 1.85% | September 20, 2021 | (2) | 2,000 |  |  | 1.90% |  | — |  |  | — |
| 3.00% | June 15, 2022 |  | 500 |  |  | 2.03% |  | 500 |  |  | 1.51% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 | (2) | 750 |  |  | 2.27% |  | — |  |  | — |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1.88% |  | 1,000 |  |  | 1.36% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 2.19% |  | 500 |  |  | 1.67% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 | (2) | 1,500 |  |  | 2.55% |  | — |  |  | — |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 30,500 |  |  |  |  | 28,400 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (140 | ) |  |  |  | (137 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 110 |  |  |  |  | 379 |  |  |  |
| Total |  |  | $ | 30,470 |  |  |  |  | $ | 28,642 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 2,248 |  |  |  |  | $ | 4,159 |  |  |  |
| Long-term debt |  |  | 28,222 |  |  |  |  | 24,483 |  |  |  |
| Total |  |  | $ | 30,470 |  |  |  |  | $ | 28,642 |  |  |  |
  (was, 2017-02-21, similarity 0.9794):
[0000858877-17-000004:note_history:59]
|  |  |  | January 28, 2017 |  | July 30, 2016 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.28% | March 3, 2017 |  | $ | 1,000 |  |  | 1.29% |  | $ | 1,000 |  |  | 1.03% |
| Three-month LIBOR plus 0.60% | February 21, 2018 |  | 1,000 |  |  | 1.58% |  | 1,000 |  |  | 1.32% |
| Three-month LIBOR plus 0.31% | June 15, 2018 |  | 900 |  |  | 1.34% |  | 900 |  |  | 1.03% |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | 500 |  |  | 1.49% |  | 500 |  |  | 1.23% |
| Three-month LIBOR plus 0.34% | September 20, 2019 | (1) | 500 |  |  | 1.38% |  | — |  |  | — |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 1.10% | March 3, 2017 |  | 2,400 |  |  | 1.17% |  | 2,400 |  |  | 0.87% |
| 3.15% | March 14, 2017 |  | 750 |  |  | 1.52% |  | 750 |  |  | 1.22% |
| 1.40% | February 28, 2018 |  | 1,250 |  |  | 1.47% |  | 1,250 |  |  | 1.47% |
| 1.65% | June 15, 2018 |  | 1,600 |  |  | 1.72% |  | 1,600 |  |  | 1.72% |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 4.84% |  | 2,000 |  |  | 4.76% |
| 1.60% | February 28, 2019 |  | 1,000 |  |  | 1.67% |  | 1,000 |  |  | 1.67% |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 1.39% |  | 1,750 |  |  | 1.08% |
| 1.40% | September 20, 2019 | (1) | 1,500 |  |  | 1.48% |  | — |  |  | — |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 3.47% |  | 2,500 |  |  | 3.25% |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 2.54% |  | 1,500 |  |  | 2.54% |
| 2.20% | February 28, 2021 |  | 2,500 |  |  | 2.30% |  | 2,500 |  |  | 2.30% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 1.55% |  | 500 |  |  | 1.24% |
| 1.85% | September 20, 2021 | (1) | 2,000 |  |  | 1.90% |  | — |  |  | — |
| 3.00% | June 15, 2022 |  | 500 |  |  | 1.80% |  | 500 |  |  | 1.51% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 | (1) | 750 |  |  | 2.27% |  | — |  |  | — |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1.66% |  | 1,000 |  |  | 1.36% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 1.96% |  | 500 |  |  | 1.67% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 | (1) | 1,500 |  |  | 2.55% |  | — |  |  | — |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 34,650 |  |  |  |  | 28,400 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (145 | ) |  |  |  | (137 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 117 |  |  |  |  | 379 |  |  |  |
| Total |  |  | $ | 34,622 |  |  |  |  | $ | 28,642 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 4,151 |  |  |  |  | $ | 4,159 |  |  |  |
| Long-term debt |  |  | 30,471 |  |  |  |  | 24,483 |  |  |  |
| Total |  |  | $ | 34,622 |  |  |  |  | $ | 28,642 |  |  |  |

- added (2017-05-23):
[0000858877-17-000010:note_history:60]
(1) In March 2017, the Company repaid senior notes with an aggregate principal amount of $4.15 billion upon maturity.


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-05-23):
[0000858877-17-000010:note_history:61]
As of April 29, 2017, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):
  (was, 2017-02-21, similarity 0.9701):
[0000858877-17-000004:note_history:61]
As of January 28, 2017, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

- changed (2017-05-23):
[0000858877-17-000010:note_history:62]
| Fiscal Year | Amount |
| 2017 (remaining three months) | $ | — |  |
| 2018 | 4,750 |  |
| 2019 | 5,250 |  |
| 2020 | 6,000 |  |
| 2021 | 3,000 |  |
| Thereafter | 11,500 |  |
| Total | $ | 30,500 |  |
  (was, 2017-02-21, similarity 0.9673):
[0000858877-17-000004:note_history:62]
| Fiscal Year | Amount |
| 2017 (remaining six months) | $ | 4,150 |  |
| 2018 | 4,750 |  |
| 2019 | 5,250 |  |
| 2020 | 6,000 |  |
| 2021 | 3,000 |  |
| Thereafter | 11,500 |  |
| Total | $ | 34,650 |  |


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-05-23):
[0000858877-17-000010:note_history:63]
|  | April 29, 2017 |  | July 30, 2016 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 2,248 |  |  | 1.58 | % |  | $ | 4,159 |  |  | 0.97 | % |
| Commercial paper | 2,000 |  |  | 0.88 | % |  | — |  |  | — |  |
| Other notes and borrowings | — |  |  | — |  |  | 1 |  |  | 2.08 | % |
| Total short-term debt | $ | 4,248 |  |  |  |  | $ | 4,160 |  |  |  |
  (was, 2017-02-21, similarity 0.9825):
[0000858877-17-000004:note_history:63]
|  | January 28, 2017 |  | July 30, 2016 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 4,151 |  |  | 1.26 | % |  | $ | 4,159 |  |  | 0.97 | % |
| Commercial paper | 300 |  |  | 0.73 | % |  | — |  |  | — |  |
| Other notes and borrowings | — |  |  | — |  |  | 1 |  |  | 2.08 | % |
| Total short-term debt | $ | 4,451 |  |  |  |  | $ | 4,160 |  |  |  |
