# CSCO 8-K — 0001193125-22-154039 filed 2022-05-18

## item codes, every 8-K on or before 2022-05-25

- 2022-05-18 0001193125-22-154039 — 2.02, 9.01
- 2022-03-28 0001193125-22-086807 — 8.01
- 2022-02-16 0001193125-22-044372 — 2.02, 9.01
- 2022-02-11 0001193125-22-037227 — 5.02
- 2022-01-31 0001193125-22-023458 — 5.02
- 2021-12-17 0001193125-21-361182 — 8.01
- 2021-12-14 0001193125-21-356837 — 5.07, 8.01
- 2021-11-17 0001193125-21-332467 — 2.02, 9.01
- 2021-09-27 0001193125-21-284199 — 8.01
- 2021-08-18 0001193125-21-250360 — 2.02, 9.01
- 2021-06-29 0001193125-21-203324 — 8.01
- 2021-05-19 0001193125-21-166614 — 2.02, 9.01
- 2021-05-14 0001193125-21-162081 — 1.01, 2.03, 9.01
- 2021-03-08 0001193125-21-073328 — 5.02
- 2021-02-25 0001193125-21-056977 — 5.02
- 2021-02-09 0001193125-21-034339 — 2.02, 9.01
- 2021-01-07 0001193125-21-004250 — 5.02
- 2020-12-17 0001193125-20-320092 — 5.02, 8.01
- 2020-12-11 0001193125-20-315999 — 5.02, 5.07, 9.01
- 2020-11-30 0001193125-20-305352 — 5.02
- 2020-11-13 0001193125-20-293020 — 5.02, 9.01
- 2020-11-12 0001193125-20-291658 — 2.02, 9.01
- 2020-10-09 0001193125-20-267248 — 5.03, 9.01
- 2020-09-23 0001193125-20-252356 — 8.01
- 2020-08-12 0001193125-20-217756 — 5.02
- 2020-08-12 0001193125-20-217658 — 2.02, 2.05, 9.01
- 2020-06-22 0001193125-20-175641 — 8.01
- 2020-05-13 0001193125-20-141598 — 2.02, 9.01
- 2020-03-13 0001193125-20-072960 — 5.02
- 2020-03-06 0001193125-20-065138 — 5.02
- 2020-02-12 0001193125-20-033208 — 2.02, 9.01
- 2020-01-27 0001193125-20-015453 — 5.02
- 2019-12-23 0001193125-19-322662 — 8.01
- 2019-12-12 0001193125-19-312796 — 8.01
- 2019-12-11 0001193125-19-311525 — 5.07
- 2019-12-04 0001193125-19-306229 — 8.01
- 2019-11-13 0001193125-19-291002 — 2.02, 9.01
- 2019-08-22 0001193125-19-226917 — 8.01
- 2019-08-14 0001193125-19-221195 — 2.02, 9.01
- 2019-07-09 0001193125-19-190942 — 8.01, 9.01
- 2019-06-18 0001193125-19-175707 — 8.01
- 2019-06-04 0001193125-19-165092 — 8.01
- 2019-05-22 0001193125-19-154111 — 5.02
- 2019-05-15 0001193125-19-147994 — 2.02, 9.01
- 2019-03-07 0001193125-19-067296 — 8.01
- 2019-02-13 0001193125-19-037964 — 2.02, 9.01
- 2018-12-13 0001193125-18-348864 — 5.02, 5.07, 9.01
- 2018-11-14 0001193125-18-326716 — 2.02, 9.01
- 2018-10-18 0001193125-18-301990 — 5.02
- 2018-09-12 0001193125-18-271829 — 5.02, 9.01
- 2018-08-15 0001193125-18-249746 — 2.02, 9.01
- 2018-08-06 0001193125-18-239193 — 8.01
- 2018-06-25 0001193125-18-202535 — 8.01
- 2018-06-07 0001193125-18-186858 — 8.01
- 2018-05-16 0001193125-18-165248 — 2.02, 9.01
- 2018-05-01 0001193125-18-146602 — 5.02
- 2018-04-12 0001193125-18-115646 — 5.02
- 2018-02-14 0001193125-18-045716 — 2.02, 9.01
- 2017-12-14 0001193125-17-368869 — 5.02
- 2017-12-12 0001193125-17-367515 — 5.02, 5.07, 9.01
- 2017-11-15 0001193125-17-344129 — 2.02, 9.01
- 2017-10-23 0001193125-17-316071 — 8.01, 9.01
- 2017-09-18 0001193125-17-286857 — 5.02, 9.01
- 2017-09-01 0001193125-17-275671 — 8.01
- 2017-08-16 0001193125-17-259825 — 2.02
- 2017-06-23 0001193125-17-211825 — 8.01
- 2017-06-15 0001193125-17-204753 — 8.01
- 2017-05-17 0001193125-17-173404 — 2.02
- 2017-03-31 0001193125-17-106620 — 1.01, 2.03, 9.01
- 2017-03-29 0001193125-17-101783 — 8.01
- 2017-03-13 0001193125-17-080485 — 5.02
- 2017-02-15 0001193125-17-045265 — 2.02
- 2016-12-22 0001193125-16-802182 — 8.01
- 2016-12-13 0001193125-16-791877 — 5.07
- 2016-11-16 0001193125-16-769785 — 2.02
- 2016-11-03 0001193125-16-758911 — 5.02, 9.01
- 2016-10-17 0001193125-16-739833 — 5.02
- 2016-09-21 0001193125-16-716006 — 8.01
- 2016-09-20 0001193125-16-714189 — 8.01, 9.01
- 2016-09-16 0001193125-16-712320 — 8.01
- 2016-09-15 0001193125-16-711098 — 1.01, 9.01
- 2016-09-13 0001193125-16-708007 — 8.01, 9.01
- 2016-09-06 0001193125-16-702020 — 8.01
- 2016-08-17 0001193125-16-684126 — 2.02, 2.05
- 2016-07-29 0001193125-16-664620 — 5.03, 9.01
- 2016-06-27 0001193125-16-633145 — 8.01
- 2016-06-23 0001193125-16-630146 — 8.01
- 2016-06-07 0001193125-16-615321 — 5.02, 9.01
- 2016-05-18 0001193125-16-594463 — 2.02
- 2016-03-24 0001193125-16-516953 — 8.01
- 2016-02-29 0001193125-16-483780 — 8.01, 9.01
- 2016-02-25 0001193125-16-478442 — 8.01
- 2016-02-24 0001193125-16-474071 — 1.01, 9.01
- 2016-02-22 0001193125-16-470856 — 8.01, 9.01
- 2016-02-10 0001193125-16-457586 — 2.02
- 2016-01-28 0001193125-16-441933 — 5.02
- 2015-12-08 0001193125-15-397797 — 8.01
- 2015-11-20 0001193125-15-383743 — 5.07
- 2015-11-12 0001193125-15-375655 — 2.02
- 2015-09-21 0001193125-15-324465 — 8.01
- 2015-09-17 0001193125-15-322456 — 8.01
- 2015-09-14 0001193125-15-319489 — 8.01
- 2015-08-28 0001193125-15-306843 — 8.01
- 2015-08-12 0001193125-15-288099 — 2.02
- 2015-07-29 0001193125-15-268359 — 5.02 — amendment of 0001193125-15-169227
- 2015-06-18 0001193125-15-227387 — 8.01, 9.01
- 2015-06-12 0001193125-15-221863 — 1.01, 9.01
- 2015-06-10 0001193125-15-218734 — 8.01, 9.01
- 2015-06-01 0001193125-15-209142 — 5.02, 9.01
- 2015-05-13 0001193125-15-185905 — 2.02
- 2015-05-04 0001193125-15-169227 — 5.02
- 2015-03-24 0001193125-15-103369 — 8.01
- 2015-03-19 0001193125-15-098638 — 8.01
- 2015-02-11 0001193125-15-044175 — 2.02
- 2014-12-19 0001193125-14-448754 — 8.01
- 2014-12-18 0001193125-14-447039 — 8.01
- 2014-11-24 0001193125-14-423591 — 5.02, 5.07, 9.01
- 2014-11-14 0001193125-14-413384 — 5.02
- 2014-11-12 0001193125-14-409258 — 2.02
- 2014-09-25 0001193125-14-353210 — 8.01
- 2014-09-12 0001193125-14-340480 — 5.02
- 2014-08-14 0001193125-14-308733 — 2.05
- 2014-08-13 0001193125-14-308403 — 2.02
- 2014-07-31 0001193125-14-289683 — 5.02
- 2014-06-25 0001193125-14-249157 — 8.01
- 2014-05-14 0001193125-14-199056 — 2.02
- 2014-03-26 0001193125-14-116588 — 8.01
- 2014-03-11 0001193125-14-093805 — 8.01
- 2014-03-03 0001193125-14-079163 — 1.01, 8.01, 9.01
- 2014-02-26 0001193125-14-069912 — 1.01, 9.01
- 2014-02-12 0001193125-14-048150 — 2.02
- 2013-12-23 0001193125-13-483099 — 8.01
- 2013-12-04 0001193125-13-462216 — 8.01
- 2013-11-20 0001193125-13-448477 — 5.02, 5.07, 9.01
- 2013-11-13 0001193125-13-440194 — 2.02
- 2013-08-15 0001193125-13-335218 — 2.05
- 2013-08-14 0001193125-13-334648 — 2.02
- 2013-07-23 0001193125-13-298129 — 8.01, 9.01
- 2013-06-24 0001193125-13-269064 — 8.01
- 2013-06-12 0001193125-13-256194 — 8.01
- 2013-06-07 0001193125-13-250920 — 8.01
- 2013-05-15 0001193125-13-222377 — 2.02
- 2013-03-26 0001193125-13-127015 — 8.01
- 2013-02-13 0001193125-13-055377 — 2.02
- 2013-02-01 0001193125-13-034682 — 5.02
- 2013-01-08 0001193125-13-006886 — 5.02, 9.01
- 2012-12-21 0001193125-12-513130 — 8.01
- 2012-12-19 0001193125-12-508424 — 8.01
- 2012-11-16 0001193125-12-474089 — 5.02, 5.07, 9.01
- 2012-11-13 0001193125-12-467422 — 2.02
- 2012-10-04 0001193125-12-415386 — 5.02, 5.03, 9.01
- 2012-09-19 0001193125-12-396875 — 5.02, 8.01
- 2012-08-15 0001193125-12-357479 — 2.02
- 2012-08-02 0001193125-12-332045 — 5.02
- 2012-06-27 0001193125-12-285742 — 8.01
- 2012-06-13 0001193125-12-269642 — 8.01
- 2012-05-09 0001193125-12-222045 — 2.02
- 2012-03-27 0001193125-12-134384 — 8.01
- 2012-03-15 0001193125-12-117538 — 8.01, 9.01
- 2012-02-17 0001193125-12-067542 — 1.01, 1.02, 2.03, 9.01
- 2012-02-08 0001193125-12-046545 — 2.02
- 2011-12-16 0001193125-11-343995 — 8.01
- 2011-12-08 0001193125-11-335127 — 5.02, 5.07, 9.01
- 2011-11-09 0001193125-11-304587 — 2.02
- 2011-09-29 0001193125-11-260065 — 8.01
- 2011-09-20 0001193125-11-252379 — 5.02, 9.01
- 2011-08-24 0001193125-11-231015 — 8.01
- 2011-08-10 0001193125-11-218133 — 2.02
- 2011-07-18 0001193125-11-190246 — 2.05
- 2011-06-22 0001193125-11-170849 — 8.01
- 2011-05-11 0001193125-11-135913 — 2.02
- 2011-03-28 0001193125-11-079927 — 8.01
- 2011-03-22 0001193125-11-073802 — 5.02 — amendment of 0001193125-11-043592
- 2011-03-18 0001193125-11-071279 — 8.01, 9.01
- 2011-03-16 0001193125-11-067985 — 1.01, 5.02, 8.01, 9.01
- 2011-03-15 0001193125-11-067331 — 1.01, 9.01
- 2011-03-09 0001193125-11-060123 — 8.01, 9.01
- 2011-02-23 0001193125-11-043592 — 5.02
- 2011-02-09 0001193125-11-028987 — 2.02
- 2011-01-31 0001193125-11-019101 — 1.01, 2.03
- 2010-12-17 0001193125-10-283392 — 8.01
- 2010-11-19 0001193125-10-265377 — 5.07
- 2010-11-10 0001193125-10-256001 — 2.02
- 2010-09-22 0001193125-10-214707 — 8.01
- 2010-09-16 0001193125-10-211456 — 7.01
- 2010-08-11 0001193125-10-186042 — 2.02
- 2010-06-29 0001193125-10-149956 — 8.01
- 2010-05-12 0001193125-10-117509 — 2.02
- 2010-02-17 0001193125-10-033290 — 5.02, 8.01, 9.01
- 2010-02-03 0001193125-10-020775 — 2.02
- 2009-11-25 0001193125-09-242589 — 8.01
- 2009-11-17 0001193125-09-236335 — 1.01, 8.01, 9.01
- 2009-11-13 0001193125-09-234405 — 1.01, 2.03, 9.01
- 2009-11-13 0001193125-09-234397 — 5.02 — amendment of 0001193125-09-189511
- 2009-11-12 0001193125-09-232971 — 5.02, 7.01, 9.01
- 2009-11-09 0001193125-09-228541 — 8.01, 9.01
- 2009-11-04 0001193125-09-223763 — 2.02
- 2009-10-14 0001193125-09-207912 — 8.01, 9.01
- 2009-10-05 0001193125-09-203556 — 8.01
- 2009-09-10 0001193125-09-189511 — 5.02
- 2009-09-04 0001193125-09-187835 — 5.02
- 2009-08-05 0001193125-09-165404 — 2.02
- 2009-07-27 0001193125-09-155861 — 5.02
- 2009-05-29 0001193125-09-121672 — 8.01
- 2009-05-06 0001193125-09-101570 — 2.02
- 2009-02-26 0001193125-09-038162 — 5.02
- 2009-02-17 0001193125-09-030546 — 1.01, 8.01, 9.01
- 2009-02-13 0001193125-09-029295 — 1.01, 2.03, 9.01
- 2009-02-04 0001193125-09-018793 — 2.02
- 2008-11-05 0001193125-08-225857 — 2.02
- 2008-09-11 0001193125-08-194695 — 7.01
- 2008-08-05 0001193125-08-166496 — 2.02
- 2008-06-20 0001193125-08-137504 — 8.01
- 2008-05-06 0001193125-08-104089 — 2.02
- 2008-03-21 0001193125-08-062838 — 8.01
- 2008-02-06 0001193125-08-021681 — 2.02
- 2008-01-23 0001193125-08-010589 — 5.02
- 2008-01-04 0001193125-08-001680 — 5.02, 9.01
- 2007-12-21 0001193125-07-269613 — 5.02
- 2007-11-19 0001193125-07-250345 — 5.02 — amendment of 0001193125-07-009285
- 2007-11-19 0001193125-07-250343 — 5.02, 9.01
- 2007-11-07 0001193125-07-238464 — 2.02
- 2007-09-24 0001193125-07-206279 — 8.01
- 2007-09-20 0001193125-07-204616 — 5.02, 7.01
- 2007-09-07 0001193125-07-197514 — 8.01
- 2007-08-17 0001193125-07-185320 — 1.01, 2.03, 9.01
- 2007-08-08 0001193125-07-174077 — 5.02
- 2007-08-07 0001193125-07-173689 — 2.02
- 2007-08-01 0001193125-07-168143 — 5.02
- 2007-05-15 0001193125-07-115800 — 8.01
- 2007-05-08 0001193125-07-106059 — 2.02
- 2007-03-23 0001193125-07-063033 — 5.02, 5.03, 8.01, 9.01
- 2007-03-21 0001193125-07-060631 — 1.01, 9.01
- 2007-02-06 0001193125-07-021349 — 2.02
- 2007-01-19 0001193125-07-009285 — 5.02
- 2006-12-22 0001193125-06-259241 — 8.01
- 2006-11-16 0001193125-06-237260 — 5.03, 8.01, 9.01
- 2006-11-08 0001193125-06-228341 — 2.02
- 2006-09-21 0001193125-06-194890 — 1.01, 7.01
- 2006-09-20 0001193125-06-194063 — 1.01
- 2006-09-15 0001193125-06-191845 — 5.02
- 2006-08-18 0001193125-06-176193 — 5.02
- 2006-08-08 0001193125-06-165719 — 2.02
- 2006-07-31 0001193125-06-157106 — 1.01, 9.01
- 2006-07-31 0001193125-06-157102 — 5.02 — amendment of 0001193125-06-017426
- 2006-06-08 0001193125-06-126879 — 5.02
- 2006-05-18 0001193125-06-115516 — 8.01
- 2006-05-12 0001193125-06-110924 — 9.01 — amendment of 0001193125-06-044013
- 2006-05-09 0001193125-06-105419 — 2.02
- 2006-03-29 0001193125-06-066990 — 1.01
- 2006-03-02 0001193125-06-044013 — 1.01, 2.01, 9.01
- 2006-02-28 0001193125-06-041452 — 1.01
- 2006-02-22 0001193125-06-036759 — 8.01
- 2006-02-22 0001193125-06-036433 — 1.01, 8.01, 9.01
- 2006-02-21 0001193125-06-035865 — 1.01, 2.03, 9.01
- 2006-02-10 0001193125-06-026218 — 8.01, 9.01
- 2006-02-07 0001193125-06-022234 — 2.02
- 2006-02-01 0001193125-06-017426 — 5.02
- 2005-11-18 0001193125-05-229535 — 1.01, 9.01
- 2005-11-16 0001193125-05-227987 — 1.01, 9.01
- 2005-11-16 0001193125-05-227983 — 5.02 — amendment of 0001193125-05-008843
- 2005-11-09 0001193125-05-221610 — 2.02
- 2005-09-29 0001193125-05-194217 — 7.01
- 2005-09-27 0001193125-05-192353 — 8.01
- 2005-09-21 0001193125-05-189234 — 1.01, 9.01
- 2005-09-19 0001193125-05-187646 — 8.01
- 2005-09-09 0001193125-05-183273 — 8.01
- 2005-09-08 0001193125-05-182307 — 1.01
- 2005-08-09 0001193125-05-162626 — 2.02
- 2005-07-15 0001193125-05-142738 — 8.01
- 2005-05-10 0001193125-05-102797 — 2.02
- 2005-03-30 0001193125-05-065123 — 1.01, 3.03, 9.01
- 2005-03-04 0001193125-05-042778 — 1.01
- 2005-02-08 0001193125-05-022181 — 2.02
- 2005-01-20 0001193125-05-008843 — 5.02
- 2004-12-23 0001193125-04-219331 — 8.01
- 2004-11-09 0001193125-04-191303 — 2.02
- 2004-08-23 0001193125-04-145198 — 1.01, 7.01
- 2004-08-19 0001193125-04-143859 — 5
- 2004-08-10 0001193125-04-136865 — 12
- 2004-05-11 0001193125-04-084721 — 12
- 2004-02-03 0001193125-04-013750 — 12
- 2003-11-05 0001193125-03-073418 — 12
- 2003-09-02 0001193125-03-044521 — 9
- 2003-08-05 0001193125-03-029223 — 12, 7
- 2003-07-18 0001193125-03-021155 — 5, 7
- 2003-06-05 0001012870-03-002949 — 5
- 2003-05-06 0000891618-03-002315 — 7, 9
- 2003-04-17 0000891618-03-001894 — 5, 7
- 2003-04-11 0000891618-03-001791 — 9
- 2003-03-20 0000891618-03-001326 — 5, 7
- 2003-02-04 0000891618-03-000518 — 7, 9
- 2003-01-28 0000891618-03-000271 — 5, 7
- 2002-12-27 0000891618-02-005686 — 5, 7
- 2002-10-23 0000891618-02-004715 — 5, 7
- 2002-10-11 0000891618-02-004620 — 5, 7
- 2002-09-18 0000891618-02-004352 — 5, 7
- 2002-08-20 0000891618-02-004001 — 5, 7
- 2002-08-05 0000891618-02-003498 — 5, 7
- 2002-07-03 0000891618-02-003099 — 5, 7
- 2002-05-14 0000891618-02-002407 — 5, 7
- 2002-02-05 0000891618-02-000412 — 5, 7
- 2001-09-28 0001095811-01-505261 — 5, 7
- 2001-09-14 0001095811-01-504917 — 5, 7
- 2001-08-24 0001095811-01-504581 — 5, 7
- 2001-07-30 0001095811-01-503468 — 5, 7
- 2001-07-12 0000891618-01-501567 — 5, 7
- 2001-05-11 0000891618-01-500638 — 5, 7
- 2001-02-27 0000891618-01-500076 — 5, 7
- 2001-02-20 0001095811-01-001530 — 5, 7
- 2001-02-08 0001095811-01-000848 — 5, 7
- 2001-02-07 0001095811-01-000768 — 5
- 2000-12-27 0001095811-00-005511 — 5
- 2000-12-21 0001095811-00-005427 — 5
- 2000-12-19 0001095811-00-005368 — 5
- 2000-11-15 0001095811-00-004830 — 5
- 2000-11-15 0001095811-00-004824 — 5
- 2000-11-13 0000891618-00-005023 — 5
- 2000-11-07 0001095811-00-004387 — 5, 7
- 2000-11-06 0001095811-00-004318 — 5
- 2000-09-29 0000891618-00-004739 — 5, 7
- 2000-09-28 0000891618-00-004722 — 5
- 2000-09-26 0001095811-00-003573 — 5
- 2000-09-15 0001095811-00-003413 — 5
- 2000-09-07 0001095811-00-003229 — 5
- 2000-08-15 0000891618-00-004430 — 5
- 2000-08-04 0001095811-00-002304 — 5, 7 — amendment, the index does not say of what
- 2000-07-28 0000891618-00-004132 — 5, 7
- 2000-06-29 0000891618-00-003637 — 5
- 2000-06-07 0000891618-00-003209 — 5
- 2000-05-26 0000891618-00-003054 — 5
- 2000-05-18 0000891618-00-002975 — 5, 7
- 2000-05-15 0000891618-00-002808 — 5, 7
- 2000-05-03 0000891618-00-002473 — 5
- 2000-04-03 0000891618-00-001936 — 5
- 2000-03-28 0000891618-00-001763 — 5
- 2000-03-27 0000891618-00-001722 — 5, 7
- 2000-03-16 0000891618-00-001512 — 5
- 2000-02-17 0000891618-00-001024 — 5, 7
- 2000-02-03 0000891618-00-000468 — 7 — amendment of 0000891618-99-005685
- 1999-12-22 0000891618-99-005792 — 5, 7
- 1999-12-15 0000891618-99-005685 — 5, 7
- 1999-11-17 0000891618-99-005313 — 5, 7
- 1999-11-04 0000891618-99-004862 — 5, 7
- 1999-10-20 0000891618-99-004625 — 5, 7
- 1999-09-27 0000891618-99-004333 — 5, 7
- 1999-08-26 0000891618-99-003978 — 5, 7
- 1999-08-13 0000891618-99-003764 — 5, 7 — amendment of 0000891618-99-003749
- 1999-08-13 0000891618-99-003749 — 5, 7
- 1999-07-02 0000891618-99-002980 — 5, 7
- 1999-05-14 0000891618-99-002221 — 5
- 1998-11-20 0000891618-98-005074 — 5, 7
- 1998-11-20 0000891618-98-005073 — 5, 7
- 1998-10-13 0000891618-98-004462 — 5, 7
- 1998-07-09 0000891618-98-003245 — 5, 7
- 1998-06-11 0000891618-98-002832 — 5, 7
- 1998-05-15 0000891618-98-002457 — 5, 7
- 1998-04-29 0000891618-98-001996 — 5
- 1998-02-11 0000891618-98-000584 — 5, 7
- 1997-09-09 0000891618-97-003723 — 5, 7
- 1997-08-22 0000891618-97-003559 — 5, 7
- 1997-07-01 0000891618-97-002807 — 5, 7
- 1997-01-22 0000891618-97-000120 — 5, 7
- 1996-10-15 0000891618-96-002283 — 5, 7 — amendment of 0000891618-96-002217
- 1996-10-01 0000891618-96-002217 — 5, 7
- 1996-07-23 0000891618-96-001305 — 2, 7
- 1996-04-26 0000891618-96-000253 — 2
- 1996-04-02 0000898430-96-001187 — 2, 7
- 1995-12-06 0000891618-95-000728 — 2, 7
- 1995-12-06 0000891618-95-000727 — 2, 7

## late-filing notifications on or before 2022-05-25

- none on or before 2022-05-25

## item 2.02 — earnings release, exhibit 99.1

[0001193125-22-154039:8k_2_02:1]
EX-99.1
2
d354715dex991.htm
EX-99.1

[0001193125-22-154039:8k_2_02:2]
EX-99.1

[0001193125-22-154039:8k_2_02:3]
Exhibit 99.1

[0001193125-22-154039:8k_2_02:4]
| Press Contact: |  | Investor Relations Contact: |
| Robyn Blum |  | Marilyn Mora |
| Cisco |  | Cisco |
| 1 (408) 930-8548 |  | 1 (408) 527-7452 |
| rojenkin@cisco.com |  | marilmor@cisco.com |

[0001193125-22-154039:8k_2_02:5]
CISCO REPORTS THIRD QUARTER EARNINGS

[0001193125-22-154039:8k_2_02:6]
News Summary:

[0001193125-22-154039:8k_2_02:7]
|  | • |  | $12.8 billion in revenue, flat year over year; GAAP EPS $0.73, up 7% year over year, and Non-GAAP EPS $0.87, up 5% year over year |

[0001193125-22-154039:8k_2_02:8]
|  | • |  | Solid demand with product order growth up 8% year over year |

[0001193125-22-154039:8k_2_02:9]
|  | • |  | Progress on business model transformation with total Annualized Recurring Revenue (ARR) at $22.4 billion in the third quarter of fiscal 2022, up 11% year over year |

[0001193125-22-154039:8k_2_02:10]
| • |  | Q3 Results: |

[0001193125-22-154039:8k_2_02:11]
|  | • |  | Revenue: $12.8 billion |

[0001193125-22-154039:8k_2_02:12]
|  | • |  | Flat year over year |

[0001193125-22-154039:8k_2_02:13]
|  | • |  | Earnings per Share: GAAP: $0.73; Non-GAAP: $0.87 |

[0001193125-22-154039:8k_2_02:14]
|  | • |  | GAAP EPS increased 7% year over year |

[0001193125-22-154039:8k_2_02:15]
|  | • |  | Non-GAAP EPS increased 5% year over year |

[0001193125-22-154039:8k_2_02:16]
| • |  | Q4 Guidance: |

[0001193125-22-154039:8k_2_02:17]
|  | • |  | Revenue: (1)% to (5.5)% decline year over year |

[0001193125-22-154039:8k_2_02:18]
|  | • |  | Earnings per Share: GAAP: $0.60 to $0.70; Non-GAAP: $0.76 to $0.84 |

[0001193125-22-154039:8k_2_02:19]
| • |  | FY 2022 Guidance: |

[0001193125-22-154039:8k_2_02:20]
|  | • |  | Revenue: 2% to 3% growth year over year |

[0001193125-22-154039:8k_2_02:21]
|  | • |  | Earnings per Share: GAAP: $2.75 to $2.85; Non-GAAP: $3.29 to $3.37 |

[0001193125-22-154039:8k_2_02:22]
SAN JOSE, Calif. — May 18, 2022 — Cisco today reported third quarter results for the period ended April 30, 2022.
Cisco reported third quarter revenue of $12.8 billion, net income on a generally accepted accounting principles (GAAP) basis of $3.0 billion or $0.73 per share, and non-GAAP net income of
$3.6 billion or $0.87 per share.

[0001193125-22-154039:8k_2_02:23]
“We continued to see solid demand for our technologies and our business transformation is progressing
well,” said Chuck Robbins, chair and CEO of Cisco. “While Covid lockdowns in China and the war in Ukraine impacted our revenue in the quarter, the fundamental drivers across our business are strong and we remain confident in the long
term.”

[0001193125-22-154039:8k_2_02:24]
“We delivered healthy earnings despite unanticipated disruptions through strong pricing and disciplined spend management,” said
Scott Herren, CFO of Cisco. “Our product backlog is well over $15 billion and product ARR and RPO again grew double digits. The continued progress in our business model transformation reflects the success of our strategy and underpins our
long-term confidence.”

[0001193125-22-154039:8k_2_02:25]
GAAP Results

[0001193125-22-154039:8k_2_02:26]
|  |  | Q3 FY 2022 |  |  | Q3 FY 2021 |  |  | Vs. Q3 FY 2021 |  |
| Revenue |  | $ | 12.8 billion |  |  | $ | 12.8 billion |  |  |  | — | % |
| Net Income |  | $ | 3.0 billion |  |  | $ | 2.9 billion |  |  |  | 6 | % |
| Diluted Earnings per Share (EPS) |  | $ | 0.73 |  |  | $ | 0.68 |  |  |  | 7 | % |

[0001193125-22-154039:8k_2_02:27]
1

[0001193125-22-154039:8k_2_02:28]
Non-GAAP Results

[0001193125-22-154039:8k_2_02:29]
|  |  | Q3 FY 2022 |  |  | Q3 FY 2021 |  |  | Vs. Q3 FY 2021 |  |
| Net Income |  | $ | 3.6 billion |  |  | $ | 3.5 billion |  |  |  | 3 | % |
| EPS |  | $ | 0.87 |  |  | $ | 0.83 |  |  |  | 5 | % |

[0001193125-22-154039:8k_2_02:30]
The third quarter of fiscal 2022 had 13 weeks compared with 14 weeks in the third quarter of fiscal 2021.

[0001193125-22-154039:8k_2_02:31]
Reconciliations between net income, EPS, and other measures on a GAAP and non-GAAP basis are provided in the tables
located in the section entitled “Reconciliations of GAAP to non-GAAP Measures.”

[0001193125-22-154039:8k_2_02:32]
2

[0001193125-22-154039:8k_2_02:33]
Financial Summary

[0001193125-22-154039:8k_2_02:34]
All comparative percentages are on a year-over-year basis unless otherwise noted.

[0001193125-22-154039:8k_2_02:35]
Q3 FY 2022 Highlights

[0001193125-22-154039:8k_2_02:36]
Revenue — Total
revenue was flat at $12.8 billion, with product revenue up 3% and service revenue down 8%. Revenue by geographic segment was: Americas up 5%, EMEA down 6%, and APJC down 6%. Product revenue performance was led by growth in Secure, Agile
Networks up 4%, Internet for the Future up 6%, End-to-End Security up 7%, and Optimized Application Experiences up 8%. Collaboration was down 7%.

[0001193125-22-154039:8k_2_02:37]
The third quarter of fiscal 2022 had 13 weeks compared with 14 weeks in the third quarter of fiscal 2021. The total additional revenue associated with the
extra week in the third quarter of fiscal 2021 was approximately 3% of revenue growth.

[0001193125-22-154039:8k_2_02:38]
In March 2022, in connection with the Russian invasion of Ukraine,
Cisco announced its intention to stop business operations in Russia and Belarus for the foreseeable future. The total negative impact to revenue was approximately $200 million in the third quarter of fiscal 2022. Historically, Russia, Belarus
and Ukraine collectively, represented approximately 1% of our total revenue.

[0001193125-22-154039:8k_2_02:39]
Gross Margin — On a GAAP basis, total gross
margin, product gross margin, and service gross margin were 63.3%, 61.8%, and 67.3%, respectively, as compared with 63.9%, 62.6%, and 67.4%, respectively, in the third quarter of fiscal 2021.

[0001193125-22-154039:8k_2_02:40]
On a non-GAAP basis, total gross margin, product gross margin, and service gross margin were 65.3%, 64.1%, and 68.9%,
respectively, as compared with 66.0%, 64.9%, and 68.7%, respectively, in the third quarter of fiscal 2021.

[0001193125-22-154039:8k_2_02:41]
Total gross margins by geographic segment
were: 64.8% for the Americas, 65.9% for EMEA and 66.4% for APJC.

[0001193125-22-154039:8k_2_02:42]
Operating Expenses — On a GAAP basis, operating expenses were
$4.5 billion, down 4%, and were 35.1% of revenue. Non-GAAP operating expenses were $3.9 billion, down 5%, and were 30.7% of revenue.

[0001193125-22-154039:8k_2_02:43]
Operating Income — GAAP operating income was $3.6 billion, up 4%, with GAAP operating margin of 28.1%.
Non-GAAP operating income was $4.5 billion, up 4%, with non-GAAP operating margin at 34.7%.

[0001193125-22-154039:8k_2_02:44]
Provision for Income Taxes — The GAAP tax provision rate was 19.9%. The non-GAAP tax provision rate
was 19.0%.

[0001193125-22-154039:8k_2_02:45]
Net Income and EPS — On a GAAP basis, net income was $3.0 billion, an increase of 6%, and EPS was $0.73, an increase
of 7%. On a non-GAAP basis, net income was $3.6 billion, an increase of 3%, and EPS was $0.87, an increase of 5%.

[0001193125-22-154039:8k_2_02:46]
Cash Flow from Operating Activities — $3.7 billion for the third quarter of fiscal 2022, a decrease of 6% compared with
$3.9 billion for the third quarter of fiscal 2021.

[0001193125-22-154039:8k_2_02:47]
Balance Sheet and Other Financial Highlights

[0001193125-22-154039:8k_2_02:48]
Cash and Cash Equivalents and Investments — $20.1 billion at the end of the third quarter of fiscal 2022, compared with
$24.5 billion at the end of fiscal 2021.

[0001193125-22-154039:8k_2_02:49]
Remaining Performance Obligations (RPO) — $30.2 billion, up 7% in
total, with 54% of this amount to be recognized as revenue over the next 12 months. Product RPO were up 13% and service RPO were up 3%.

[0001193125-22-154039:8k_2_02:50]
Deferred
Revenue — $22.3 billion, up 7% in total, with deferred product revenue up 13%. Deferred service revenue was up 2%.

[0001193125-22-154039:8k_2_02:51]
Capital
Allocation — In the third quarter of fiscal 2022, we returned $1.8 billion to stockholders through share buybacks and dividends. We declared and paid a cash dividend of $0.38 per common share, or $1.6 billion, and repurchased
approximately 5 million shares of common stock under our stock repurchase program at an average price of $54.20 per share for an aggregate purchase price of $252 million. The remaining authorized amount for stock repurchases under the
program is $17.6 billion with no termination date.

[0001193125-22-154039:8k_2_02:52]
Acquisitions

[0001193125-22-154039:8k_2_02:53]
In the third quarter of fiscal 2022, we closed the acquisition of Opsani, a privately held enterprise software company.

[0001193125-22-154039:8k_2_02:54]
3

[0001193125-22-154039:8k_2_02:55]
Guidance

[0001193125-22-154039:8k_2_02:56]
Cisco expects to achieve the following results for the fourth quarter of fiscal 2022:

[0001193125-22-154039:8k_2_02:57]
| Q4 FY 2022 |  |  |
| Revenue |  | (1)% - (5.5)% decline Y/Y |
| Non-GAAP gross margin rate |  | 64% - 65% |
| Non-GAAP operating margin rate |  | 31.5% - 33.5% |
| Non-GAAP EPS |  | $0.76 - $0.84 |

[0001193125-22-154039:8k_2_02:58]
Cisco estimates that GAAP EPS will be $0.60 to $0.70 for the fourth quarter of fiscal 2022.

[0001193125-22-154039:8k_2_02:59]
Cisco expects to achieve the following results for fiscal 2022:

[0001193125-22-154039:8k_2_02:60]
| FY 2022 |  |  |
| Revenue |  | 2% - 3% growth Y/Y |
| Non-GAAP EPS |  | $3.29 - $3.37 |

[0001193125-22-154039:8k_2_02:61]
Cisco estimates that GAAP EPS will be $2.75 to $2.85 for fiscal 2022.

[0001193125-22-154039:8k_2_02:62]
Our fiscal 2022 has 52 weeks compared with 53 weeks in fiscal 2021 which is reflected in the guidance.

[0001193125-22-154039:8k_2_02:63]
Our Q4 FY 2022 and FY 2022 guidance assumes an effective tax provision rate of 19% for GAAP and non-GAAP results.

[0001193125-22-154039:8k_2_02:64]
A reconciliation between the Guidance on a GAAP and non-GAAP basis is provided in the tables entitled “GAAP to non-GAAP Guidance” located in the section entitled “Reconciliations of GAAP to non-GAAP Measures.”

[0001193125-22-154039:8k_2_02:65]
Editor’s Notes:

[0001193125-22-154039:8k_2_02:66]
|  | • |  | Q3 fiscal year 2022 conference call to discuss Cisco’s results along with its guidance will be held on Wednesday, May 18, 2022 at 1:30 p.m. Pacific Time. Conference call number is 1-888-848-6507 (United States) or 1-212-519-0847 (international). |

[0001193125-22-154039:8k_2_02:67]
|  | • |  | Conference call replay will be available from 4:00 p.m. Pacific Time, May 18, 2022 to 4:00 p.m. Pacific Time, May 25, 2022 at 1-800-388-4923 (United States) or 1-203-369-3800 (international). The replay will also be available via webcast on the Cisco Investor Relations website at https://investor.cisco.com. |

[0001193125-22-154039:8k_2_02:68]
|  | • |  | Additional information regarding Cisco’s financials, as well as a webcast of the conference call with visuals designed to guide participants through the call, will be available at 1:30 p.m. Pacific Time, May 18, 2022. Text of the conference call’s prepared remarks will be available within 24 hours of completion of the call. The webcast will include both the prepared remarks and the question-and-answer session. This information, along with the GAAP to non-GAAP reconciliation information, will be available on the Cisco Investor Relations website at https://investor.cisco.com. |

[0001193125-22-154039:8k_2_02:69]
4

[0001193125-22-154039:8k_2_02:70]
CISCO SYSTEMS, INC.

[0001193125-22-154039:8k_2_02:71]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-22-154039:8k_2_02:72]
(In millions, except per-share amounts)

[0001193125-22-154039:8k_2_02:73]
(Unaudited)

[0001193125-22-154039:8k_2_02:74]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | April 30,2022 |  |  | May 1,2021 |  |  | April 30,2022 |  |  | May 1,2021 |  |
| REVENUE: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 9,448 |  |  | $ | 9,139 |  |  | $ | 28,330 |  |  | $ | 26,298 |  |
| Service |  |  | 3,387 |  |  |  | 3,664 |  |  |  | 10,125 |  |  |  | 10,394 |  |
| Total revenue |  |  | 12,835 |  |  |  | 12,803 |  |  |  | 38,455 |  |  |  | 36,692 |  |
| COST OF SALES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 3,606 |  |  |  | 3,422 |  |  |  | 10,848 |  |  |  | 9,672 |  |
| Service |  |  | 1,108 |  |  |  | 1,196 |  |  |  | 3,384 |  |  |  | 3,470 |  |
| Total cost of sales |  |  | 4,714 |  |  |  | 4,618 |  |  |  | 14,232 |  |  |  | 13,142 |  |
| GROSS MARGIN |  |  | 8,121 |  |  |  | 8,185 |  |  |  | 24,223 |  |  |  | 23,550 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 1,708 |  |  |  | 1,697 |  |  |  | 5,092 |  |  |  | 4,836 |  |
| Sales and marketing |  |  | 2,209 |  |  |  | 2,317 |  |  |  | 6,736 |  |  |  | 6,811 |  |
| General and administrative |  |  | 517 |  |  |  | 603 |  |  |  | 1,612 |  |  |  | 1,631 |  |
| Amortization of purchased intangible assets |  |  | 77 |  |  |  | 61 |  |  |  | 240 |  |  |  | 136 |  |
| Restructuring and other charges |  |  | — |  |  |  | 42 |  |  |  | 8 |  |  |  | 878 |  |
| Total operating expenses |  |  | 4,511 |  |  |  | 4,720 |  |  |  | 13,688 |  |  |  | 14,292 |  |
| OPERATING INCOME |  |  | 3,610 |  |  |  | 3,465 |  |  |  | 10,535 |  |  |  | 9,258 |  |
| Interest income |  |  | 115 |  |  |  | 153 |  |  |  | 347 |  |  |  | 488 |  |
| Interest expense |  |  | (90 | ) |  |  | (111 | ) |  |  | (267 | ) |  |  | (336 | ) |
| Other income (loss), net |  |  | 166 |  |  |  | 84 |  |  |  | 446 |  |  |  | 117 |  |
| Interest and other income (loss), net |  |  | 191 |  |  |  | 126 |  |  |  | 526 |  |  |  | 269 |  |
| INCOME BEFORE PROVISION FOR INCOME TAXES |  |  | 3,801 |  |  |  | 3,591 |  |  |  | 11,061 |  |  |  | 9,527 |  |
| Provision for income taxes |  |  | 757 |  |  |  | 728 |  |  |  | 2,064 |  |  |  | 1,945 |  |
| NET INCOME |  | $ | 3,044 |  |  | $ | 2,863 |  |  | $ | 8,997 |  |  | $ | 7,582 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.73 |  |  | $ | 0.68 |  |  | $ | 2.15 |  |  | $ | 1.79 |  |
| Diluted |  | $ | 0.73 |  |  | $ | 0.68 |  |  | $ | 2.14 |  |  | $ | 1.79 |  |
| Shares used in per-share calculation: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 4,152 |  |  |  | 4,219 |  |  |  | 4,184 |  |  |  | 4,224 |  |
| Diluted |  |  | 4,170 |  |  |  | 4,238 |  |  |  | 4,204 |  |  |  | 4,237 |  |

[0001193125-22-154039:8k_2_02:75]
5

[0001193125-22-154039:8k_2_02:76]
CISCO SYSTEMS, INC.

[0001193125-22-154039:8k_2_02:77]
REVENUE BY SEGMENT

[0001193125-22-154039:8k_2_02:78]
(In
millions, except percentages)

[0001193125-22-154039:8k_2_02:79]
|  |  | April 30, 2022 |  |
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | Amount |  |  | Y/Y% |  |  | Amount |  |  | Y/Y% |  |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 7,638 |  |  |  | 5 | % |  | $ | 22,344 |  |  |  | 4 | % |
| EMEA |  |  | 3,271 |  |  |  | (6 | )% |  |  | 10,138 |  |  |  | 5 | % |
| APJC |  |  | 1,926 |  |  |  | (6 | )% |  |  | 5,972 |  |  |  | 6 | % |
| Total |  | $ | 12,835 |  |  |  | — | % |  | $ | 38,455 |  |  |  | 5 | % |

[0001193125-22-154039:8k_2_02:80]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-22-154039:8k_2_02:81]
CISCO SYSTEMS, INC.

[0001193125-22-154039:8k_2_02:82]
GROSS MARGIN PERCENTAGE BY SEGMENT

[0001193125-22-154039:8k_2_02:83]
(In percentages)

[0001193125-22-154039:8k_2_02:84]
|  |  | April 30, 2022 |  |
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
| Gross Margin Percentage: |  |  |  |  |  |  |  |  |
| Americas |  |  | 64.8% |  |  |  | 64.6% |  |
| EMEA |  |  | 65.9% |  |  |  | 65.7% |  |
| APJC |  |  | 66.4% |  |  |  | 65.9% |  |

[0001193125-22-154039:8k_2_02:85]
CISCO SYSTEMS, INC.

[0001193125-22-154039:8k_2_02:86]
REVENUE FOR GROUPS OF SIMILAR PRODUCTS AND SERVICES

[0001193125-22-154039:8k_2_02:87]
(In millions, except percentages)

[0001193125-22-154039:8k_2_02:88]
|  |  | April 30, 2022 |  |
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | Amount |  |  | Y/Y% |  |  | Amount |  |  | Y/Y% |  |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Secure, Agile Networks |  | $ | 5,869 |  |  |  | 4 | % |  | $ | 17,735 |  |  |  | 7 | % |
| Internet for the Future |  |  | 1,324 |  |  |  | 6 | % |  |  | 4,021 |  |  |  | 29 | % |
| Collaboration |  |  | 1,132 |  |  |  | (7 | )% |  |  | 3,308 |  |  |  | (8 | )% |
| End-to-End Security |  |  | 938 |  |  |  | 7 | % |  |  | 2,716 |  |  |  | 6 | % |
| Optimized Application Experiences |  |  | 183 |  |  |  | 8 | % |  |  | 544 |  |  |  | 13 | % |
| Other Products |  |  | 2 |  |  |  | (58 | )% |  |  | 7 |  |  |  | (32 | )% |
| Total Product |  |  | 9,448 |  |  |  | 3 | % |  |  | 28,330 |  |  |  | 8 | % |
| Services |  |  | 3,387 |  |  |  | (8 | )% |  |  | 10,125 |  |  |  | (3 | )% |
| Total |  | $ | 12,835 |  |  |  | — | % |  | $ | 38,455 |  |  |  | 5 | % |

[0001193125-22-154039:8k_2_02:89]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-22-154039:8k_2_02:90]
6

[0001193125-22-154039:8k_2_02:91]
CISCO SYSTEMS, INC.

[0001193125-22-154039:8k_2_02:92]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001193125-22-154039:8k_2_02:93]
(In millions)

[0001193125-22-154039:8k_2_02:94]
(Unaudited)

[0001193125-22-154039:8k_2_02:95]
|  |  | April 30,2022 |  |  | July 31,2021 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 6,952 |  |  | $ | 9,175 |  |
| Investments |  |  | 13,156 |  |  |  | 15,343 |  |
| Accounts receivable, net of allowance of $78 at April 30, 2022 and $109 at July 31, 2021 |  |  | 5,783 |  |  |  | 5,766 |  |
| Inventories |  |  | 2,231 |  |  |  | 1,559 |  |
| Financing receivables, net |  |  | 3,804 |  |  |  | 4,380 |  |
| Other current assets |  |  | 4,055 |  |  |  | 2,889 |  |
| Total current assets |  |  | 35,981 |  |  |  | 39,112 |  |
| Property and equipment, net |  |  | 2,046 |  |  |  | 2,338 |  |
| Financing receivables, net |  |  | 3,959 |  |  |  | 4,884 |  |
| Goodwill |  |  | 38,452 |  |  |  | 38,168 |  |
| Purchased intangible assets, net |  |  | 2,811 |  |  |  | 3,619 |  |
| Deferred tax assets |  |  | 4,276 |  |  |  | 4,360 |  |
| Other assets |  |  | 5,272 |  |  |  | 5,016 |  |
| TOTAL ASSETS |  | $ | 92,797 |  |  | $ | 97,497 |  |
| LIABILITIES AND EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 1,000 |  |  | $ | 2,508 |  |
| Accounts payable |  |  | 2,289 |  |  |  | 2,362 |  |
| Income taxes payable |  |  | 852 |  |  |  | 801 |  |
| Accrued compensation |  |  | 3,032 |  |  |  | 3,818 |  |
| Deferred revenue |  |  | 12,249 |  |  |  | 12,148 |  |
| Other current liabilities |  |  | 4,728 |  |  |  | 4,620 |  |
| Total current liabilities |  |  | 24,150 |  |  |  | 26,257 |  |
| Long-term debt |  |  | 8,418 |  |  |  | 9,018 |  |
| Income taxes payable |  |  | 7,689 |  |  |  | 8,538 |  |
| Deferred revenue |  |  | 10,044 |  |  |  | 10,016 |  |
| Other long-term liabilities |  |  | 2,096 |  |  |  | 2,393 |  |
| Total liabilities |  |  | 52,397 |  |  |  | 56,222 |  |
| Total equity |  |  | 40,400 |  |  |  | 41,275 |  |
| TOTAL LIABILITIES AND EQUITY |  | $ | 92,797 |  |  | $ | 97,497 |  |

[0001193125-22-154039:8k_2_02:96]
7

[0001193125-22-154039:8k_2_02:97]
CISCO SYSTEMS, INC.

[0001193125-22-154039:8k_2_02:98]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-22-154039:8k_2_02:99]
(In millions)

[0001193125-22-154039:8k_2_02:100]
(Unaudited)

[0001193125-22-154039:8k_2_02:101]
|  |  | Nine Months Ended |  |
|  |  | April 30,2022 |  |  | May 1,2021 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 8,997 |  |  | $ | 7,582 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation, amortization, and other |  |  | 1,527 |  |  |  | 1,373 |  |
| Share-based compensation expense |  |  | 1,407 |  |  |  | 1,337 |  |
| Provision (benefit) for receivables |  |  | 49 |  |  |  | (4 | ) |
| Deferred income taxes |  |  | (167 | ) |  |  | (89 | ) |
| (Gains) losses on divestitures, investments and other, net |  |  | (470 | ) |  |  | (201 | ) |
| Change in operating assets and liabilities, net of effects of acquisitions and divestitures: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | (134 | ) |  |  | 1,250 |  |
| Inventories |  |  | (683 | ) |  |  | (260 | ) |
| Financing receivables |  |  | 1,431 |  |  |  | 1,160 |  |
| Other assets |  |  | (1,295 | ) |  |  | (233 | ) |
| Accounts payable |  |  | (54 | ) |  |  | 24 |  |
| Income taxes, net |  |  | (730 | ) |  |  | (828 | ) |
| Accrued compensation |  |  | (730 | ) |  |  | 145 |  |
| Deferred revenue |  |  | 292 |  |  |  | 263 |  |
| Other liabilities |  |  | 109 |  |  |  | (569 | ) |
| Net cash provided by operating activities |  |  | 9,549 |  |  |  | 10,950 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of investments |  |  | (5,383 | ) |  |  | (7,855 | ) |
| Proceeds from sales of investments |  |  | 2,488 |  |  |  | 2,724 |  |
| Proceeds from maturities of investments |  |  | 4,308 |  |  |  | 6,445 |  |
| Acquisitions, net of cash and cash equivalents acquired and divestitures |  |  | (373 | ) |  |  | (6,333 | ) |
| Purchases of investments in privately held companies |  |  | (158 | ) |  |  | (138 | ) |
| Return of investments in privately held companies |  |  | 149 |  |  |  | 96 |  |
| Acquisition of property and equipment |  |  | (338 | ) |  |  | (530 | ) |
| Proceeds from sales of property and equipment |  |  | 6 |  |  |  | 14 |  |
| Other |  |  | (15 | ) |  |  | (56 | ) |
| Net cash provided by (used in) investing activities |  |  | 684 |  |  |  | (5,633 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Issuances of common stock |  |  | 306 |  |  |  | 307 |  |
| Repurchases of common stock - repurchase program |  |  | (5,347 | ) |  |  | (2,096 | ) |
| Shares repurchased for tax withholdings on vesting of restricted stock units |  |  | (546 | ) |  |  | (419 | ) |
| Short-term borrowings, original maturities of 90 days or less, net |  |  | 9 |  |  |  | — |  |
| Issuances of debt |  |  | 1,049 |  |  |  | — |  |
| Repayments of debt |  |  | (3,050 | ) |  |  | (3,000 | ) |
| Dividends paid |  |  | (4,657 | ) |  |  | (4,601 | ) |
| Other |  |  | (230 | ) |  |  | 39 |  |
| Net cash used in financing activities |  |  | (12,466 | ) |  |  | (9,770 | ) |
| Net decrease in cash, cash equivalents, restricted cash and restricted cash equivalents |  |  | (2,233 | ) |  |  | (4,453 | ) |
| Cash, cash equivalents, restricted cash and restricted cash equivalents, beginning of period |  |  | 9,942 |  |  |  | 11,812 |  |
| Cash, cash equivalents, restricted cash and restricted cash equivalents, end of period |  | $ | 7,709 |  |  | $ | 7,359 |  |
| Supplemental cash flow information: |  |  |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 292 |  |  | $ | 377 |  |
| Cash paid for income taxes, net |  | $ | 2,960 |  |  | $ | 2,862 |  |

[0001193125-22-154039:8k_2_02:102]
8

[0001193125-22-154039:8k_2_02:103]
CISCO SYSTEMS, INC.

[0001193125-22-154039:8k_2_02:104]
REMAINING PERFORMANCE OBLIGATIONS

[0001193125-22-154039:8k_2_02:105]
(In millions, except percentages)

[0001193125-22-154039:8k_2_02:106]
|  |  | April 30, 2022 |  |  | January 29, 2022 |  |  | May 1, 2021 |  |
|  |  | Amount |  |  | Y/Y% |  |  | Amount |  |  | Y/Y% |  |  | Amount |  |  | Y/Y% |  |
| Product |  | $ | 13,416 |  |  |  | 13 | % |  | $ | 13,532 |  |  |  | 16 | % |  | $ | 11,903 |  |  |  | 15 | % |
| Service |  |  | 16,789 |  |  |  | 3 | % |  |  | 16,986 |  |  |  | 3 | % |  |  | 16,235 |  |  |  | 7 | % |
| Total |  | $ | 30,205 |  |  |  | 7 | % |  | $ | 30,518 |  |  |  | 8 | % |  | $ | 28,138 |  |  |  | 10 | % |

[0001193125-22-154039:8k_2_02:107]
We expect 54% of total RPO at April 30, 2022 will be recognized as revenue over the next 12 months.

[0001193125-22-154039:8k_2_02:108]
CISCO SYSTEMS, INC.

[0001193125-22-154039:8k_2_02:109]
DEFERRED REVENUE

[0001193125-22-154039:8k_2_02:110]
(In
millions)

[0001193125-22-154039:8k_2_02:111]
|  |  | April 30,2022 |  |  | January 29,2022 |  |  | May 1,2021 |  |
| Deferred revenue: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 9,835 |  |  | $ | 9,767 |  |  | $ | 8,698 |  |
| Service |  |  | 12,458 |  |  |  | 12,546 |  |  |  | 12,191 |  |
| Total |  | $ | 22,293 |  |  | $ | 22,313 |  |  | $ | 20,889 |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |  |
| Current |  | $ | 12,249 |  |  | $ | 12,268 |  |  | $ | 11,492 |  |
| Noncurrent |  |  | 10,044 |  |  |  | 10,045 |  |  |  | 9,397 |  |
| Total |  | $ | 22,293 |  |  | $ | 22,313 |  |  | $ | 20,889 |  |

[0001193125-22-154039:8k_2_02:112]
CISCO SYSTEMS, INC.

[0001193125-22-154039:8k_2_02:113]
DIVIDENDS PAID AND REPURCHASES OF COMMON STOCK

[0001193125-22-154039:8k_2_02:114]
(In millions, except per-share amounts)

[0001193125-22-154039:8k_2_02:115]
|  |  | DIVIDENDS |  |  | STOCK REPURCHASE PROGRAM |  |  | TOTAL |  |
| Quarter Ended |  | Per Share |  |  | Amount |  |  | Shares |  |  | Weighted-Average Priceper Share |  |  | Amount |  |  | Amount |  |
| Fiscal 2022 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| April 30, 2022 |  | $ | 0.38 |  |  | $ | 1,555 |  |  |  | 5 |  |  | $ | 54.20 |  |  | $ | 252 |  |  | $ | 1,807 |  |
| January 29, 2022 |  | $ | 0.37 |  |  | $ | 1,541 |  |  |  | 82 |  |  | $ | 58.36 |  |  | $ | 4,824 |  |  | $ | 6,365 |  |
| October 30, 2021 |  | $ | 0.37 |  |  | $ | 1,561 |  |  |  | 5 |  |  | $ | 56.49 |  |  | $ | 256 |  |  | $ | 1,817 |  |
| Fiscal 2021 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| July 31, 2021 |  | $ | 0.37 |  |  | $ | 1,562 |  |  |  | 15 |  |  | $ | 53.30 |  |  | $ | 791 |  |  | $ | 2,353 |  |
| May 1, 2021 |  | $ | 0.37 |  |  | $ | 1,560 |  |  |  | 10 |  |  | $ | 48.71 |  |  | $ | 510 |  |  | $ | 2,070 |  |
| January 23, 2021 |  | $ | 0.36 |  |  | $ | 1,521 |  |  |  | 19 |  |  | $ | 42.82 |  |  | $ | 801 |  |  | $ | 2,322 |  |
| October 24, 2020 |  | $ | 0.36 |  |  | $ | 1,520 |  |  |  | 20 |  |  | $ | 40.44 |  |  | $ | 800 |  |  | $ | 2,320 |  |

[0001193125-22-154039:8k_2_02:116]
9

[0001193125-22-154039:8k_2_02:117]
CISCO SYSTEMS, INC.

[0001193125-22-154039:8k_2_02:118]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-22-154039:8k_2_02:119]
GAAP TO NON-GAAP NET INCOME

[0001193125-22-154039:8k_2_02:120]
(In millions)

[0001193125-22-154039:8k_2_02:121]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | April 30,2022 |  |  | May 1,2021 |  |  | April 30,2022 |  |  | May 1,2021 |  |
| GAAP net income |  | $ | 3,044 |  |  | $ | 2,863 |  |  | $ | 8,997 |  |  | $ | 7,582 |  |
| Adjustments to cost of sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 83 |  |  |  | 75 |  |  |  | 233 |  |  |  | 208 |  |
| Amortization of acquisition-related intangible assets |  |  | 176 |  |  |  | 184 |  |  |  | 571 |  |  |  | 499 |  |
| Acquisition-related/divestiture costs |  |  | 1 |  |  |  | 1 |  |  |  | 3 |  |  |  | 3 |  |
| Russia-Ukraine war costs |  |  | 5 |  |  |  | — |  |  |  | 5 |  |  |  | — |  |
| Legal and indemnification settlements/charges |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 43 |  |
| Total adjustments to GAAP cost of sales |  |  | 265 |  |  |  | 260 |  |  |  | 812 |  |  |  | 753 |  |
| Adjustments to operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 394 |  |  |  | 383 |  |  |  | 1,173 |  |  |  | 1,103 |  |
| Amortization of acquisition-related intangible assets |  |  | 92 |  |  |  | 61 |  |  |  | 255 |  |  |  | 136 |  |
| Acquisition-related/divestiture costs |  |  | 29 |  |  |  | 86 |  |  |  | 261 |  |  |  | 179 |  |
| Russia-Ukraine war costs |  |  | 62 |  |  |  | — |  |  |  | 62 |  |  |  | — |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | 42 |  |  |  | 8 |  |  |  | 878 |  |
| Total adjustments to GAAP operating expenses |  |  | 577 |  |  |  | 572 |  |  |  | 1,759 |  |  |  | 2,296 |  |
| Adjustments to interest and other income (loss), net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Acquisition-related/divestiture costs |  |  | — |  |  |  | 6 |  |  |  | — |  |  |  | 4 |  |
| (Gains) and losses on equity investments |  |  | (159 | ) |  |  | (96 | ) |  |  | (478 | ) |  |  | (131 | ) |
| Total adjustments to GAAP interest and other income (loss), net |  |  | (159 | ) |  |  | (90 | ) |  |  | (478 | ) |  |  | (127 | ) |
| Total adjustments to GAAP income before provision for income taxes |  |  | 683 |  |  |  | 742 |  |  |  | 2,093 |  |  |  | 2,922 |  |
| Income tax effect of non-GAAP adjustments |  |  | (95 | ) |  |  | (95 | ) |  |  | (435 | ) |  |  | (503 | ) |
| Significant tax matters |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 83 |  |
| Total adjustments to GAAP provision for income taxes |  |  | (95 | ) |  |  | (95 | ) |  |  | (435 | ) |  |  | (420 | ) |
| Non-GAAP net income |  | $ | 3,632 |  |  | $ | 3,510 |  |  | $ | 10,655 |  |  | $ | 10,084 |  |

[0001193125-22-154039:8k_2_02:122]
10

[0001193125-22-154039:8k_2_02:123]
CISCO SYSTEMS, INC.

[0001193125-22-154039:8k_2_02:124]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-22-154039:8k_2_02:125]
GAAP TO NON-GAAP EPS

[0001193125-22-154039:8k_2_02:126]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | April 30,2022 |  |  | May 1,2021 |  |  | April 30,2022 |  |  | May 1,2021 |  |
| GAAP EPS |  | $ | 0.73 |  |  | $ | 0.68 |  |  | $ | 2.14 |  |  | $ | 1.79 |  |
| Adjustments to GAAP: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 0.11 |  |  |  | 0.11 |  |  |  | 0.33 |  |  |  | 0.31 |  |
| Amortization of acquisition-related intangible assets |  |  | 0.06 |  |  |  | 0.06 |  |  |  | 0.20 |  |  |  | 0.15 |  |
| Acquisition-related/divestiture costs |  |  | 0.01 |  |  |  | 0.02 |  |  |  | 0.06 |  |  |  | 0.04 |  |
| Russia-Ukraine war costs |  |  | 0.02 |  |  |  | — |  |  |  | 0.02 |  |  |  | — |  |
| Legal and indemnification settlements/charges |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 0.01 |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | 0.01 |  |  |  | — |  |  |  | 0.21 |  |
| (Gains) and losses on equity investments |  |  | (0.04 | ) |  |  | (0.02 | ) |  |  | (0.11 | ) |  |  | (0.03 | ) |
| Income tax effect of non-GAAP adjustments |  |  | (0.02 | ) |  |  | (0.02 | ) |  |  | (0.10 | ) |  |  | (0.12 | ) |
| Significant tax matters |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 0.02 |  |
| Non-GAAP EPS |  | $ | 0.87 |  |  | $ | 0.83 |  |  | $ | 2.53 |  |  | $ | 2.38 |  |

[0001193125-22-154039:8k_2_02:127]
Amounts may not sum due to rounding.

[0001193125-22-154039:8k_2_02:128]
CISCO SYSTEMS, INC.

[0001193125-22-154039:8k_2_02:129]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-22-154039:8k_2_02:130]
GROSS MARGINS, OPERATING EXPENSES, OPERATING MARGINS, INTEREST AND OTHER INCOME (LOSS), NET, 
AND NET INCOME

[0001193125-22-154039:8k_2_02:131]
(In millions, except percentages)

[0001193125-22-154039:8k_2_02:132]
|  |  | Three Months Ended |  |
|  |  | April 30, 2022 |  |
|  |  | ProductGrossMargin |  |  | ServiceGrossMargin |  |  | TotalGrossMargin |  |  | OperatingExpenses |  |  | Y/Y |  |  | OperatingIncome |  |  | Y/Y |  |  | Interestandotherincome(loss),net |  |  | NetIncome |  |  | Y/Y |  |
| GAAP amount |  | $ | 5,842 |  |  | $ | 2,279 |  |  | $ | 8,121 |  |  | $ | 4,511 |  |  |  | (4 | )% |  | $ | 3,610 |  |  |  | 4 | % |  | $ | 191 |  |  | $ | 3,044 |  |  |  | 6 | % |
| % of revenue |  |  | 61.8 | % |  |  | 67.3 | % |  |  | 63.3 | % |  |  | 35.1 | % |  |  |  |  |  |  | 28.1 | % |  |  |  |  |  |  | 1.5 | % |  |  | 23.7 | % |  |  |  |  |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 30 |  |  |  | 53 |  |  |  | 83 |  |  |  | 394 |  |  |  |  |  |  |  | 477 |  |  |  |  |  |  |  | — |  |  |  | 477 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  |  | 176 |  |  |  | — |  |  |  | 176 |  |  |  | 92 |  |  |  |  |  |  |  | 268 |  |  |  |  |  |  |  | — |  |  |  | 268 |  |  |  |  |  |
| Acquisition/divestiture-related costs |  |  | 1 |  |  |  | — |  |  |  | 1 |  |  |  | 29 |  |  |  |  |  |  |  | 30 |  |  |  |  |  |  |  | — |  |  |  | 30 |  |  |  |  |  |
| Russia-Ukraine war costs |  |  | 4 |  |  |  | 1 |  |  |  | 5 |  |  |  | 62 |  |  |  |  |  |  |  | 67 |  |  |  |  |  |  |  | — |  |  |  | 67 |  |  |  |  |  |
| (Gains) and losses on equity investments |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | (159 | ) |  |  | (159 | ) |  |  |  |  |
| Income tax effect/significant tax matters |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  | (95 | ) |  |  |  |  |
| Non-GAAP amount |  | $ | 6,053 |  |  | $ | 2,333 |  |  | $ | 8,386 |  |  | $ | 3,934 |  |  |  | (5 | )% |  | $ | 4,452 |  |  |  | 4 | % |  | $ | 32 |  |  | $ | 3,632 |  |  |  | 3 | % |
| % of revenue |  |  | 64.1 | % |  |  | 68.9 | % |  |  | 65.3 | % |  |  | 30.7 | % |  |  |  |  |  |  | 34.7 | % |  |  |  |  |  |  | 0.2 | % |  |  | 28.3 | % |  |  |  |  |

[0001193125-22-154039:8k_2_02:133]
|  |  | Three Months Ended |  |
|  |  | May 1, 2021 |  |
|  |  | ProductGrossMargin |  |  | ServiceGrossMargin |  |  | TotalGrossMargin |  |  | OperatingExpenses |  |  | OperatingIncome |  |  | Interestand otherincome(loss), net |  |  | NetIncome |  |
| GAAP amount |  | $ | 5,717 |  |  | $ | 2,468 |  |  | $ | 8,185 |  |  | $ | 4,720 |  |  | $ | 3,465 |  |  | $ | 126 |  |  | $ | 2,863 |  |
| % of revenue |  |  | 62.6 | % |  |  | 67.4 | % |  |  | 63.9 | % |  |  | 36.9 | % |  |  | 27.1 | % |  |  | 1.0 | % |  |  | 22.4 | % |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 26 |  |  |  | 49 |  |  |  | 75 |  |  |  | 383 |  |  |  | 458 |  |  |  | — |  |  |  | 458 |  |
| Amortization of acquisition-related intangible assets |  |  | 184 |  |  |  | — |  |  |  | 184 |  |  |  | 61 |  |  |  | 245 |  |  |  | — |  |  |  | 245 |  |
| Acquisition/divestiture-related costs |  |  | 1 |  |  |  | — |  |  |  | 1 |  |  |  | 86 |  |  |  | 87 |  |  |  | 6 |  |  |  | 93 |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 42 |  |  |  | 42 |  |  |  | — |  |  |  | 42 |  |
| (Gains) and losses on equity investments |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (96 | ) |  |  | (96 | ) |
| Income tax effect/significant tax matters |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (95 | ) |
| Non-GAAP amount |  | $ | 5,928 |  |  | $ | 2,517 |  |  | $ | 8,445 |  |  | $ | 4,148 |  |  | $ | 4,297 |  |  | $ | 36 |  |  | $ | 3,510 |  |
| % of revenue |  |  | 64.9 | % |  |  | 68.7 | % |  |  | 66.0 | % |  |  | 32.4 | % |  |  | 33.6 | % |  |  | 0.3 | % |  |  | 27.4 | % |

[0001193125-22-154039:8k_2_02:134]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-22-154039:8k_2_02:135]
12

[0001193125-22-154039:8k_2_02:136]
CISCO SYSTEMS, INC.

[0001193125-22-154039:8k_2_02:137]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-22-154039:8k_2_02:138]
GROSS MARGINS, OPERATING EXPENSES, OPERATING MARGINS, INTEREST AND OTHER INCOME (LOSS), NET,

[0001193125-22-154039:8k_2_02:139]
AND NET INCOME

[0001193125-22-154039:8k_2_02:140]
(In
millions, except percentages)

[0001193125-22-154039:8k_2_02:141]
|  |  | Nine Months Ended |  |
|  |  | April 30, 2022 |  |
|  |  | ProductGrossMargin |  |  | ServiceGrossMargin |  |  | TotalGrossMargin |  |  | OperatingExpenses |  |  | Y/Y |  |  | OperatingIncome |  |  | Y/Y |  |  | Interestandotherincome(loss),net |  |  | NetIncome |  |  | Y/Y |  |
| GAAP amount |  | $ | 17,482 |  |  | $ | 6,741 |  |  | $ | 24,223 |  |  | $ | 13,688 |  |  |  | (4 | )% |  | $ | 10,535 |  |  |  | 14 | % |  | $ | 526 |  |  | $ | 8,997 |  |  |  | 19 | % |
| % of revenue |  |  | 61.7 | % |  |  | 66.6 | % |  |  | 63.0 | % |  |  | 35.6 | % |  |  |  |  |  |  | 27.4 | % |  |  |  |  |  |  | 1.4 | % |  |  | 23.4 | % |  |  |  |  |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 84 |  |  |  | 149 |  |  |  | 233 |  |  |  | 1,173 |  |  |  |  |  |  |  | 1,406 |  |  |  |  |  |  |  | — |  |  |  | 1,406 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  |  | 571 |  |  |  | — |  |  |  | 571 |  |  |  | 255 |  |  |  |  |  |  |  | 826 |  |  |  |  |  |  |  | — |  |  |  | 826 |  |  |  |  |  |
| Acquisition/divestiture-related costs |  |  | 3 |  |  |  | — |  |  |  | 3 |  |  |  | 261 |  |  |  |  |  |  |  | 264 |  |  |  |  |  |  |  | — |  |  |  | 264 |  |  |  |  |  |
| Russia-Ukraine war costs |  |  | 4 |  |  |  | 1 |  |  |  | 5 |  |  |  | 62 |  |  |  |  |  |  |  | 67 |  |  |  |  |  |  |  | — |  |  |  | 67 |  |  |  |  |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 8 |  |  |  |  |  |  |  | 8 |  |  |  |  |  |  |  | — |  |  |  | 8 |  |  |  |  |  |
| (Gains) and losses on equity investments |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | (478 | ) |  |  | (478 | ) |  |  |  |  |
| Income tax effect/significant tax matters |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  | (435 | ) |  |  |  |  |
| Non-GAAP amount |  | $ | 18,144 |  |  | $ | 6,891 |  |  | $ | 25,035 |  |  | $ | 11,929 |  |  |  | (1 | )% |  | $ | 13,106 |  |  |  | 6 | % |  | $ | 48 |  |  | $ | 10,655 |  |  |  | 6 | % |
| % of revenue |  |  | 64.0 | % |  |  | 68.1 | % |  |  | 65.1 | % |  |  | 31.0 | % |  |  |  |  |  |  | 34.1 | % |  |  |  |  |  |  | 0.1 | % |  |  | 27.7 | % |  |  |  |  |

[0001193125-22-154039:8k_2_02:142]
|  |  | Nine Months Ended |  |
|  |  | May 1, 2021 |  |
|  |  | ProductGrossMargin |  |  | ServiceGrossMargin |  |  | TotalGrossMargin |  |  | OperatingExpenses |  |  | OperatingIncome |  |  | Interestand otherincome(loss), net |  |  | NetIncome |  |
| GAAP amount |  | $ | 16,626 |  |  | $ | 6,924 |  |  | $ | 23,550 |  |  | $ | 14,292 |  |  | $ | 9,258 |  |  | $ | 269 |  |  | $ | 7,582 |  |
| % of revenue |  |  | 63.2 | % |  |  | 66.6 | % |  |  | 64.2 | % |  |  | 39.0 | % |  |  | 25.2 | % |  |  | 0.7 | % |  |  | 20.7 | % |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 75 |  |  |  | 133 |  |  |  | 208 |  |  |  | 1,103 |  |  |  | 1,311 |  |  |  | — |  |  |  | 1,311 |  |
| Amortization of acquisition-related intangible assets |  |  | 499 |  |  |  | — |  |  |  | 499 |  |  |  | 136 |  |  |  | 635 |  |  |  | — |  |  |  | 635 |  |
| Acquisition/divestiture-related costs |  |  | 2 |  |  |  | 1 |  |  |  | 3 |  |  |  | 179 |  |  |  | 182 |  |  |  | 4 |  |  |  | 186 |  |
| Legal and indemnification settlements/charges |  |  | 43 |  |  |  | — |  |  |  | 43 |  |  |  | — |  |  |  | 43 |  |  |  | — |  |  |  | 43 |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 878 |  |  |  | 878 |  |  |  | — |  |  |  | 878 |  |
| (Gains) and losses on equity investments |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (131 | ) |  |  | (131 | ) |
| Income tax effect/significant tax matters |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (420 | ) |
| Non-GAAP amount |  | $ | 17,245 |  |  | $ | 7,058 |  |  | $ | 24,303 |  |  | $ | 11,996 |  |  | $ | 12,307 |  |  | $ | 142 |  |  | $ | 10,084 |  |
| % of revenue |  |  | 65.6 | % |  |  | 67.9 | % |  |  | 66.2 | % |  |  | 32.7 | % |  |  | 33.5 | % |  |  | 0.4 | % |  |  | 27.5 | % |

[0001193125-22-154039:8k_2_02:143]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-22-154039:8k_2_02:144]
13

[0001193125-22-154039:8k_2_02:145]
CISCO SYSTEMS, INC.

[0001193125-22-154039:8k_2_02:146]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-22-154039:8k_2_02:147]
EFFECTIVE TAX RATE

[0001193125-22-154039:8k_2_02:148]
(In
percentages)

[0001193125-22-154039:8k_2_02:149]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | April 30,2022 |  |  | May 1,2021 |  |  | April 30,2022 |  |  | May 1,2021 |  |
| GAAP effective tax rate |  |  | 19.9 | % |  |  | 20.3 | % |  |  | 18.7 | % |  |  | 20.4 | % |
| Total adjustments to GAAP provision for income taxes |  |  | (0.9 | )% |  |  | (1.3 | )% |  |  | 0.3 | % |  |  | (1.4 | )% |
| Non-GAAP effective tax rate |  |  | 19.0 | % |  |  | 19.0 | % |  |  | 19.0 | % |  |  | 19.0 | % |

[0001193125-22-154039:8k_2_02:150]
GAAP TO NON-GAAP GUIDANCE

[0001193125-22-154039:8k_2_02:151]
| Q4 FY 2022 |  | Gross MarginRate |  | Operating MarginRate |  | Earnings perShare (1) |
| GAAP |  | 62% - 63% |  | 25% - 27% |  | $0.60 - $0.70 |
| Estimated adjustments for: |  |  |  |  |  |  |
| Share-based compensation expense |  | 0.5% |  | 4.0% |  | $0.08 - $0.09 |
| Amortization of acquisition-related intangible assets and acquisition/divestiture-related costs |  | 1.5% |  | 2.5% |  | $0.06 - $0.07 |
| Non-GAAP |  | 64% - 65% |  | 31.5% - 33.5% |  | $0.76 - $0.84 |

[0001193125-22-154039:8k_2_02:152]
| FY 2022 |  | Earnings perShare (1) |
| GAAP |  | $2.75 - $2.85 |
| Estimated adjustments for: |  |  |
| Share-based compensation expense |  | $0.33 - $0.34 |
| Amortization of acquisition-related intangible assets and acquisition/divestiture-related costs |  | $0.27 - $0.28 |
| Russia-Ukraine war costs |  | $0.01 |
| (Gains) and losses on equity investments |  | ($0.09) |
| Non-GAAP |  | $3.29 - $3.37 |

[0001193125-22-154039:8k_2_02:153]
| (1) | Estimated adjustments to GAAP earnings per share are shown after income tax effects. |

[0001193125-22-154039:8k_2_02:154]
Except as noted above, this guidance does not include the effects of any future acquisitions/divestitures, asset impairments, Russia-Ukraine war costs,
restructurings, (gains) and losses on equity investments and significant tax matters or other events, which may or may not be significant unless specifically stated.

[0001193125-22-154039:8k_2_02:155]
14

[0001193125-22-154039:8k_2_02:156]
Forward Looking Statements, Non-GAAP Information and Additional
Information

[0001193125-22-154039:8k_2_02:157]
This release includes non-GAAP net income,
non-GAAP gross margins, non-GAAP operating expenses, non-GAAP operating income and margin,
non-GAAP effective tax rates, non-GAAP interest and other income (loss), net, and non-GAAP net income per share data for the
periods presented. It also includes future estimated ranges for gross margin, operating margin, tax provision rate and EPS on a non-GAAP basis.

[0001193125-22-154039:8k_2_02:158]
These non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with
generally accepted accounting principles and may be different from non-GAAP measures used by other companies. In addition, these non-GAAP measures are not based on any
comprehensive set of accounting rules or principles. Cisco believes that non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Cisco’s results of operations as
determined in accordance with GAAP and that these measures should only be used to evaluate Cisco’s results of operations in conjunction with the corresponding GAAP measures.

[0001193125-22-154039:8k_2_02:159]
Cisco believes that the presentation of non-GAAP measures when shown in conjunction with the corresponding GAAP
measures, provides useful information to investors and management regarding financial and business trends relating to its financial condition and its historical and projected results of operations.

[0001193125-22-154039:8k_2_02:160]
15

[0001193125-22-154039:8k_2_02:161]
For its internal budgeting process, Cisco’s management uses financial statements that do not include,
when applicable, share-based compensation expense, amortization of acquisition-related intangible assets, acquisition-related/divestiture costs, significant asset impairments and restructurings, significant litigation settlements and other
contingencies, Russia-Ukraine war costs, gains and losses on equity investments, the income tax effects of the foregoing and significant tax matters. Cisco’s management also uses the foregoing non-GAAP
measures, in addition to the corresponding GAAP measures, in reviewing the financial results of Cisco. In prior periods, Cisco has excluded other items that it no longer excludes for purposes of its non-GAAP
financial measures. From time to time in the future there may be other items that Cisco may exclude for purposes of its internal budgeting process and in reviewing its financial results. For additional information on the items excluded by Cisco from
one or more of its non-GAAP financial measures, refer to the Form 8-K regarding this release furnished today to the Securities and Exchange Commission.

[0001193125-22-154039:8k_2_02:162]
Annualized Recurring Revenue represents the annualized revenue run-rate of active subscriptions, term licenses, and
maintenance contracts at the end of a reporting period, net of rebates to customers and partners as well as certain other revenue adjustments. Includes both revenue recognized ratably as well as upfront on an annualized basis.

[0001193125-22-154039:8k_2_02:163]
About Cisco

[0001193125-22-154039:8k_2_02:164]
Cisco (Nasdaq: CSCO) is the worldwide
leader in technology that powers the Internet. Cisco inspires new possibilities by reimagining your applications, securing your data, transforming your infrastructure, and empowering your teams for a global and inclusive future.
Discover more at newsroom.cisco.com and follow us on Twitter at @Cisco.

[0001193125-22-154039:8k_2_02:165]
Copyright © 2022 Cisco
and/or its affiliates. All rights reserved. Cisco and the Cisco logo are trademarks or registered trademarks of Cisco and/or its affiliates in the U.S. and other countries. To view a list of Cisco trademarks, go to: www.cisco.com/go/trademarks.
Third-party trademarks mentioned in this document are the property of their respective owners. The use of the word partner does not imply a partnership relationship between Cisco and any other company. This document is Cisco Public Information.

[0001193125-22-154039:8k_2_02:166]
RSS Feed for Cisco: https://newsroom.cisco.com/rss-feeds

[0001193125-22-154039:8k_2_02:167]
16
