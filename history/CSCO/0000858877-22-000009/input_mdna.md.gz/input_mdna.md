# CSCO MD&A — 0000858877-22-000009


## mdna

[0000858877-22-000009:mdna:1]
[same as prior period, unchanged from 0000858877-22-000004:mdna:1]

[0000858877-22-000009:mdna:2]
[same as prior period, unchanged from 0000858877-22-000004:mdna:2]

[0000858877-22-000009:mdna:3]
[same as prior period, unchanged from 0000858877-22-000004:mdna:3]

[0000858877-22-000009:mdna:4]
[same as prior period, unchanged from 0000858877-22-000004:mdna:4]

[0000858877-22-000009:mdna:5]
[same as prior period, unchanged from 0000858877-22-000004:mdna:5]

[0000858877-22-000009:mdna:6]
|  | Three Months Ended |  |  | Nine Months Ended |  |  |
|  | April 30,2022 |  | May 1,2021 |  | % Variance |  |  | April 30,2022 |  | May 1,2021 |  | % Variance |  |  |
| Revenue | $ | 12,835 |  |  | $ | 12,803 |  |  | — | % |  |  | $ | 38,455 |  |  | $ | 36,692 |  |  | 5 | % |  |  |
| Gross margin percentage | 63.3 | % |  | 63.9 | % |  | (0.6) |  | pts |  | 63.0 | % |  | 64.2 | % |  | (1.2) |  |  | pts |
| Research and development | $ | 1,708 |  |  | $ | 1,697 |  |  | 1 | % |  |  | $ | 5,092 |  |  | $ | 4,836 |  |  | 5 | % |  |  |
| Sales and marketing | $ | 2,209 |  |  | $ | 2,317 |  |  | (5) | % |  |  | $ | 6,736 |  |  | $ | 6,811 |  |  | (1) | % |  |  |
| General and administrative | $ | 517 |  |  | $ | 603 |  |  | (14) | % |  |  | $ | 1,612 |  |  | $ | 1,631 |  |  | (1) | % |  |  |
| Total research and development, sales and marketing, general and administrative | $ | 4,434 |  |  | $ | 4,617 |  |  | (4) | % |  |  | $ | 13,440 |  |  | $ | 13,278 |  |  | 1 | % |  |  |
| Total as a percentage of revenue | 34.5 | % |  | 36.1 | % |  | (1.6) |  | pts |  | 34.9 | % |  | 36.2 | % |  | (1.3) |  |  | pts |
| Amortization of purchased intangible assets included in operating expenses | $ | 77 |  |  | $ | 61 |  |  | 26 | % |  |  | $ | 240 |  |  | $ | 136 |  |  | 76 | % |  |  |
| Restructuring and other charges included in operating expenses | $ | — |  |  | $ | 42 |  |  | (100) | % |  |  | $ | 8 |  |  | $ | 878 |  |  | (99) | % |  |  |
| Operating income as a percentage of revenue | 28.1 | % |  | 27.1 | % |  | 1.0 |  | pts |  | 27.4 | % |  | 25.2 | % |  | 2.2 |  |  | pts |
| Interest and other income (loss), net | $ | 191 |  |  | $ | 126 |  |  | 52 | % |  |  | $ | 526 |  |  | $ | 269 |  |  | 96 | % |  |  |
| Income tax percentage | 19.9 | % |  | 20.3 | % |  | (0.4) |  | pts |  | 18.7 | % |  | 20.4 | % |  | (1.7) |  |  | pts |
| Net income | $ | 3,044 |  |  | $ | 2,863 |  |  | 6 | % |  |  | $ | 8,997 |  |  | $ | 7,582 |  |  | 19 | % |  |  |
| Net income as a percentage of revenue | 23.7 | % |  | 22.4 | % |  | 1.3 |  | pts |  | 23.4 | % |  | 20.7 | % |  | 2.7 |  |  | pts |
| Earnings per share—diluted | $ | 0.73 |  |  | $ | 0.68 |  |  | 7 | % |  |  | $ | 2.14 |  |  | $ | 1.79 |  |  | 20 | % |  |  |

[0000858877-22-000009:mdna:7]
[same as prior period, unchanged from 0000858877-22-000004:mdna:7]

[0000858877-22-000009:mdna:8]
[same as prior period, unchanged from 0000858877-22-000004:mdna:8]

[0000858877-22-000009:mdna:9]
Three Months Ended April 30, 2022 Compared with Three Months Ended May 1, 2021

[0000858877-22-000009:mdna:10]
In the third quarter of fiscal 2022, we delivered solid profitability in a challenging environment impacted by supply constraints and the Russia and Ukraine war. We remain focused on delivering innovation across our technologies to assist our customers in executing on their digital transformation. Total revenue was flat compared with the third quarter of fiscal 2021. We continue to be negatively impacted by supply constraints seen industry-wide due to component shortages. The duration of such impacts is uncertain. We are taking multiple steps in order to mitigate the component shortages and deliver products to our customers. We also saw additional unanticipated challenges with COVID-19 related lockdowns in China which began in late March through the end of the third quarter of fiscal 2022, resulting in a further severe shortage of certain critical components. These further China-related supply challenges prevented us from shipping products to customers at the levels we originally anticipated, which had a negative impact on our revenue for the third quarter of fiscal 2022. We expect these further China-related supply challenges we experienced in the third quarter of fiscal 2022 to continue at least into the fourth quarter of fiscal 2022. We continued to make progress in the transition of our business model delivering increased software and subscriptions. We remain focused on accelerating innovation across our portfolio, and we believe that we have made continued progress on our strategic priorities. We continue to operate in a challenging macroeconomic and highly competitive environment. While the overall environment remains uncertain, we continue to aggressively invest in priority areas with the objective of driving profitable growth over the long term.

[0000858877-22-000009:mdna:11]
Within total revenue, product revenue increased by 3% and service revenue decreased by 8%. The third quarter of fiscal 2022 had 13 weeks, compared with 14 weeks in the third quarter of fiscal 2021. The total additional revenue associated with the extra week in the third quarter of fiscal 2021 was approximately 3% of revenue growth in the prior year period. The Russia and Ukraine war had a negative impact to our total revenue of approximately 2% in the third quarter of fiscal 2022. The combined negative impact of the extra week in the third quarter of fiscal 2021 and the Russia and Ukraine war to total revenue, product revenue and service revenue was 5%, 3% and 8%, respectively. In the third quarter of fiscal 2022, total software revenue was $3.7 billion across all product areas and service, a decrease of 3%. Within total software revenue, subscription revenue decreased 1%. Total gross margin decreased by 0.6 percentage points. Product gross margin decreased by 0.8 percentage points, largely driven by increased costs related to supply constraints. As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses, collectively, decreased by 1.6 percentage points due in large part to the impact of the extra week in the third quarter of fiscal 2021. The total impact associated with the extra week in the third quarter of fiscal 2021 on our cost of sales and operating expenses was approximately $150 million (excluding the impact of share-based compensation expense). Operating income as a percentage of revenue increased by 1.0 percentage points. Diluted earnings per share increased 7%, driven by a 6% increase in net income and a decrease in diluted share count of 68 million shares.

[0000858877-22-000009:mdna:12]
In terms of our geographic segments, revenue from the Americas increased $376 million, EMEA revenue decreased by $212 million and APJC revenue decreased by $131 million.

[0000858877-22-000009:mdna:13]
From a customer market standpoint, we experienced product revenue growth in the commercial and service provider markets, offset by a product revenue decline in the public sector market. The enterprise market was flat.

[0000858877-22-000009:mdna:14]
From a product category perspective, the product revenue increase of 3% was driven by growth in revenue for Secure, Agile Networks of 4%; Internet for the Future of 6%; End-to-End Security of 7%; and Optimized Application Experiences of 8%; partially offset by a product revenue decline in Collaboration of 7%.

[0000858877-22-000009:mdna:15]
Russia and Ukraine War

[0000858877-22-000009:mdna:16]
In March 2022, in connection with the Russian invasion of Ukraine, Cisco announced its intention to stop business operations in Russia and Belarus for the foreseeable future. Those operations in Russia and Belarus included sales, services and related support functions. We continue to assess and monitor the dynamic situation in the region closely in order to determine any further operational decisions. The safety of our employees is our top priority. We are providing relocation and financial assistance to certain impacted employees, among other humanitarian assistance.

[0000858877-22-000009:mdna:17]
Our business operations in Russia, Belarus and Ukraine, collectively, comprised approximately 1% of our total revenue for the year ended July 31, 2021 and less than 0.2% of our total assets at the end of fiscal 2021. As a result of these events, we have not recognized revenue in these countries effective March 2022. The negative impact to total revenue was approximately $200 million for the third quarter of fiscal 2022, which includes committed revenue we would have otherwise recognized, charges for uncollectible receivables, and other items. Further, we also assessed the risk to the recoverability of our assets and other potential financial exposures in these countries. We have reserved for the non-recoverability of substantially all of our assets in Russia and Belarus. As a result, we recognized certain non-recurring charges of $67 million in cost of sales and operating expenses in the third quarter of fiscal 2022 related to non-recoverability of certain assets and special personnel-related charges in order to support impacted employees.

[0000858877-22-000009:mdna:18]
[same as prior period, unchanged from 0000858877-22-000004:mdna:16]

[0000858877-22-000009:mdna:19]
[same as prior period, unchanged from 0000858877-22-000004:mdna:17]

[0000858877-22-000009:mdna:20]
The ongoing effect of the Russia and Ukraine war are difficult to predict due to the other uncertainties identified in Part II, Item 1A. Risk Factors herein.

[0000858877-22-000009:mdna:21]
Nine Months Ended April 30, 2022 Compared with Nine Months Ended May 1, 2021

[0000858877-22-000009:mdna:22]
Total revenue increased 5%, with product revenue increasing 8% and service revenue decreasing 3%. Total gross margin decreased 1.2 percentage points due to increased costs related to supply constraints, partially offset by favorable pricing. As a percentage of revenue, research, and development, sales and marketing, and general and administrative expenses collectively decreased by 1.3 percentage points. Operating income as a percentage of revenue increased by 2.2 percentage points. Diluted earnings per share increased 20%, driven by a 19% increase in net income, primarily driven by higher revenue and lower restructuring and other charges.

[0000858877-22-000009:mdna:23]
COVID-19 Pandemic

[0000858877-22-000009:mdna:24]
During the COVID-19 pandemic, our priority has been supporting our employees, customers, partners and communities, while positioning Cisco for the future. The pandemic has driven organizations across the globe to digitize their operations and support remote workforces at a faster speed and greater scale than ever before. We remain focused on providing the technology and solutions our customers need to accelerate their digital organizations.

[0000858877-22-000009:mdna:25]
We have moved towards a hybrid work model in certain countries, giving our employees the flexibility to work offsite or at onsite Cisco locations.

[0000858877-22-000009:mdna:26]
[same as prior period, unchanged from 0000858877-22-000004:mdna:35]

[0000858877-22-000009:mdna:27]
[same as prior period, unchanged from 0000858877-22-000004:mdna:36]

[0000858877-22-000009:mdna:28]
[same as prior period, unchanged from 0000858877-22-000004:mdna:37]

[0000858877-22-000009:mdna:29]
[same as prior period, unchanged from 0000858877-22-000004:mdna:38]

[0000858877-22-000009:mdna:30]
The following is a summary of our other key financial measures for the third quarter of fiscal 2022 (in millions):

[0000858877-22-000009:mdna:31]
|  |  | April 30,2022 |  | July 31,2021 |
| Cash and cash equivalents and investments |  | $ | 20,108 |  |  | $ | 24,518 |  |
| Remaining performance obligations |  | $ | 30,205 |  |  | $ | 30,893 |  |
| Inventories |  | $ | 2,231 |  |  | $ | 1,559 |  |

[0000858877-22-000009:mdna:32]
|  |  | Nine Months Ended |
|  |  | April 30,2022 |  | May 1,2021 |
| Cash provided by operating activities |  | $ | 9,549 |  |  | $ | 10,950 |  |
| Repurchases of common stock—stock repurchase program |  | $ | 5,332 |  |  | $ | 2,111 |  |
| Dividends paid |  | $ | 4,657 |  |  | $ | 4,601 |  |

[0000858877-22-000009:mdna:33]
[same as prior period, unchanged from 0000858877-22-000004:mdna:33]

[0000858877-22-000009:mdna:34]
[same as prior period, unchanged from 0000858877-22-000004:mdna:34]

[0000858877-22-000009:mdna:35]
[same as prior period, unchanged from 0000858877-22-000004:mdna:44]

[0000858877-22-000009:mdna:36]
[same as prior period, unchanged from 0000858877-22-000004:mdna:45]

[0000858877-22-000009:mdna:37]
The inputs into certain of our judgments, assumptions, and estimates considered the economic implications of the COVID-19 pandemic, including the associated impact of supply constraints, on our critical and significant accounting estimates. The COVID-19 pandemic did not have a material impact on our significant judgments, assumptions and estimates that are reflected in our results for the third quarter and first nine months of fiscal 2022. These estimates are listed in our Annual Report on Form 10-K for the year ending July 31, 2021, and include: goodwill and identified purchased intangible assets and income taxes, among other items. The actual results that we experience may differ materially from our estimates. As the COVID-19 pandemic continues, many of our estimates could require increased judgment and carry a higher degree of variability and volatility. As events continue to evolve our estimates may change materially in future periods.

[0000858877-22-000009:mdna:38]
[same as prior period, unchanged from 0000858877-22-000004:mdna:47]

[0000858877-22-000009:mdna:39]
[same as prior period, unchanged from 0000858877-22-000004:mdna:48]

[0000858877-22-000009:mdna:40]
[same as prior period, unchanged from 0000858877-22-000004:mdna:49]

[0000858877-22-000009:mdna:41]
[same as prior period, unchanged from 0000858877-22-000004:mdna:50]

[0000858877-22-000009:mdna:42]
[same as prior period, unchanged from 0000858877-22-000004:mdna:51]

[0000858877-22-000009:mdna:43]
46

[0000858877-22-000009:mdna:44]
[same as prior period, unchanged from 0000858877-22-000004:mdna:42]

[0000858877-22-000009:mdna:45]
[same as prior period, unchanged from 0000858877-22-000004:mdna:43]

[0000858877-22-000009:mdna:46]
[same as prior period, unchanged from 0000858877-22-000004:mdna:55]

[0000858877-22-000009:mdna:47]
[same as prior period, unchanged from 0000858877-22-000004:mdna:56]

[0000858877-22-000009:mdna:48]
[same as prior period, unchanged from 0000858877-22-000004:mdna:57]

[0000858877-22-000009:mdna:49]
[same as prior period, unchanged from 0000858877-22-000004:mdna:58]

[0000858877-22-000009:mdna:50]
Our provision for inventory was $72 million and $91 million for the first nine months of fiscal 2022 and 2021, respectively. The provision for the liability related to purchase commitments with contract manufacturers and suppliers was $130 million and $35 million for the first nine months of fiscal 2022 and 2021, respectively. If there were to be a sudden and significant decrease in demand for our products, if there were a higher incidence of inventory obsolescence because of rapidly changing technology and customer requirements, or if supply constraints were to continue, we could be required to increase our inventory write-downs, and our liability for purchase commitments with contract manufacturers and suppliers, and accordingly our profitability, could be adversely affected. We regularly evaluate our exposure for inventory write-downs and the adequacy of our liability for purchase commitments. We continue to manage through significant supply constraints seen industry-wide due to component shortages caused, in part, by the COVID-19 pandemic. For further discussion around the Supply Constraints Impacts and Risks, see Result of Operations—Product Gross Margin and Liquidity and Capital Resources—Inventory Supply Chain.

[0000858877-22-000009:mdna:51]
Loss Contingencies

[0000858877-22-000009:mdna:52]
We are subject to the possibility of various losses arising in the ordinary course of business. We consider the likelihood of the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that a liability has been incurred and the amount of loss can be reasonably estimated. We regularly evaluate information available to us to determine whether such accruals should be made or adjusted and whether new accruals are required.

[0000858877-22-000009:mdna:53]
Third parties, including customers, have in the past and may in the future assert claims or initiate litigation related to exclusive patent, copyright, trademark, and other intellectual property rights to technologies and related standards that are relevant to us. These assertions have increased over time as a result of our growth and the general increase in the pace of patent claims assertions, particularly in the United States. If any infringement or other intellectual property claim made against us by any third party is successful, or if we fail to develop non-infringing technology or license the proprietary rights on commercially reasonable terms and conditions, our business, operating results, and financial condition could be materially and adversely affected.

[0000858877-22-000009:mdna:54]
[same as prior period, unchanged from 0000858877-22-000004:mdna:63]

[0000858877-22-000009:mdna:55]
[same as prior period, unchanged from 0000858877-22-000004:mdna:64]

[0000858877-22-000009:mdna:56]
In response to changes in industry and market conditions, we could be required to strategically realign our resources and consider restructuring, disposing of, or otherwise exiting businesses, which could result in an impairment of goodwill. There was no impairment of goodwill during the first nine months of fiscal 2022 or the first nine months of fiscal 2021.

[0000858877-22-000009:mdna:57]
[same as prior period, unchanged from 0000858877-22-000004:mdna:66]

[0000858877-22-000009:mdna:58]
[same as prior period, unchanged from 0000858877-22-000004:mdna:53]

[0000858877-22-000009:mdna:59]
[same as prior period, unchanged from 0000858877-22-000004:mdna:54]

[0000858877-22-000009:mdna:60]
We make judgments about the recoverability of purchased intangible assets with finite lives whenever events or changes in circumstances indicate that an impairment may exist. Recoverability of purchased intangible assets with finite lives is measured by comparing the carrying amount of the asset to the future undiscounted cash flows the asset is expected to generate. We review indefinite-lived intangible assets for impairment annually or whenever events or changes in circumstances indicate that the asset might be impaired. If the asset is considered to be impaired, the amount of any impairment is measured as the difference between the carrying value and the fair value of the impaired asset. Assumptions and estimates about future values and remaining useful lives of our purchased intangible assets are complex and subjective. They can be affected by a variety of factors, including external factors such as industry and economic trends, and internal factors such as changes in our business strategy and our internal forecasts. Our impairment charges related to purchased intangible assets were $15 million for the third quarter and first nine months of fiscal 2022. Our ongoing consideration of all the factors described previously could result in additional impairment charges in the future, which could adversely affect our net income.

[0000858877-22-000009:mdna:61]
[same as prior period, unchanged from 0000858877-22-000004:mdna:71]

[0000858877-22-000009:mdna:62]
[same as prior period, unchanged from 0000858877-22-000004:mdna:72]

[0000858877-22-000009:mdna:63]
We are subject to income taxes in the United States and numerous foreign jurisdictions. Our effective tax rates differ from the statutory rate, primarily due to the tax impact of state taxes, foreign operations, R&D tax credits, foreign-derived intangible income deductions, global intangible low-taxed income, tax audit settlements, nondeductible compensation, international realignments, and transfer pricing adjustments. Our effective tax rate was 19.9% and 20.3% in the third quarter of fiscal 2022 and 2021, respectively, and 18.7% and 20.4% in the first nine months of fiscal 2022 and 2021, respectively.

[0000858877-22-000009:mdna:64]
[same as prior period, unchanged from 0000858877-22-000004:mdna:74]

[0000858877-22-000009:mdna:65]
[same as prior period, unchanged from 0000858877-22-000004:mdna:75]

[0000858877-22-000009:mdna:66]
[same as prior period, unchanged from 0000858877-22-000004:mdna:76]

[0000858877-22-000009:mdna:67]
[same as prior period, unchanged from 0000858877-22-000004:mdna:68]

[0000858877-22-000009:mdna:68]
[same as prior period, unchanged from 0000858877-22-000004:mdna:69]

[0000858877-22-000009:mdna:69]
[same as prior period, unchanged from 0000858877-22-000004:mdna:79]

[0000858877-22-000009:mdna:70]
[same as prior period, unchanged from 0000858877-22-000004:mdna:80]

[0000858877-22-000009:mdna:71]
[same as prior period, unchanged from 0000858877-22-000004:mdna:81]

[0000858877-22-000009:mdna:72]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 30,2022 |  | May 1,2021 |  | Variancein Dollars |  | Variance in Percent |  | April 30,2022 |  | May 1,2021 |  | Variancein Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 9,448 |  |  | $ | 9,139 |  |  | $ | 309 |  |  | 3 | % |  | $ | 28,330 |  |  | $ | 26,298 |  |  | $ | 2,032 |  |  | 8 | % |
| Percentage of revenue |  | 73.6 | % |  | 71.4 | % |  |  |  |  |  | 73.7 | % |  | 71.7 | % |  |  |  |  |
| Service |  | 3,387 |  |  | 3,664 |  |  | (277) |  |  | (8) | % |  | 10,125 |  |  | 10,394 |  |  | (269) |  |  | (3) | % |
| Percentage of revenue |  | 26.4 | % |  | 28.6 | % |  |  |  |  |  | 26.3 | % |  | 28.3 | % |  |  |  |  |
| Total |  | $ | 12,835 |  |  | $ | 12,803 |  |  | $ | 32 |  |  | — | % |  | $ | 38,455 |  |  | $ | 36,692 |  |  | $ | 1,763 |  |  | 5 | % |

[0000858877-22-000009:mdna:73]
[same as prior period, unchanged from 0000858877-22-000004:mdna:83]

[0000858877-22-000009:mdna:74]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 30,2022 |  | May 1,2021 |  | Variancein Dollars |  | Variance in Percent |  | April 30,2022 |  | May 1,2021 |  | Variancein Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 7,638 |  |  | $ | 7,262 |  |  | $ | 376 |  |  | 5 | % |  | $ | 22,344 |  |  | $ | 21,430 |  |  | $ | 914 |  |  | 4 | % |
| Percentage of revenue |  | 59.5 | % |  | 56.7 | % |  |  |  |  |  | 58.1 | % |  | 58.4 | % |  |  |  |  |
| EMEA |  | 3,271 |  |  | 3,483 |  |  | (212) |  |  | (6) | % |  | 10,138 |  |  | 9,654 |  |  | 484 |  |  | 5 | % |
| Percentage of revenue |  | 25.5 | % |  | 27.2 | % |  |  |  |  |  | 26.4 | % |  | 26.3 | % |  |  |  |  |
| APJC |  | 1,926 |  |  | 2,057 |  |  | (131) |  |  | (6) | % |  | 5,972 |  |  | 5,608 |  |  | 364 |  |  | 6 | % |
| Percentage of revenue |  | 15.0 | % |  | 16.1 | % |  |  |  |  |  | 15.5 | % |  | 15.3 | % |  |  |  |  |
| Total |  | $ | 12,835 |  |  | $ | 12,803 |  |  | $ | 32 |  |  | — | % |  | $ | 38,455 |  |  | $ | 36,692 |  |  | $ | 1,763 |  |  | 5 | % |

[0000858877-22-000009:mdna:75]
[same as prior period, unchanged from 0000858877-22-000004:mdna:85]

[0000858877-22-000009:mdna:76]
Three Months Ended April 30, 2022 Compared with Three Months Ended May 1, 2021

[0000858877-22-000009:mdna:77]
Total revenue was flat. Product revenue increased by 3% and service revenue decreased by 8%. The third quarter of fiscal 2022 had 13 weeks, compared with 14 weeks in the third quarter of fiscal 2021, thus our results for the third quarter of fiscal 2022 reflect one less week compared with the third quarter of fiscal 2021. The total additional revenue associated with the extra week in the third quarter of fiscal 2021 was approximately 3% of revenue growth in the prior year period. Our total revenue reflected growth in the Americas segment, offset by declines in the EMEA and APJC segments.

[0000858877-22-000009:mdna:78]
In March 2022, in connection with the Russian invasion of Ukraine, Cisco announced its intention to stop business operations in Russia and Belarus for the foreseeable future. Our business operations in Russia, Belarus and Ukraine, collectively, comprised approximately 1% of our total revenue for the year ended July 31, 2021. As a result of these events, we have not recognized revenue in these countries effective March 2022. The negative impact to total revenue was approximately $200 million for the third quarter of fiscal 2022, which includes committed revenue we would have otherwise recognized, charges for uncollectible receivables, and other items.

[0000858877-22-000009:mdna:79]
[same as prior period, unchanged from 0000858877-22-000004:mdna:88]

[0000858877-22-000009:mdna:80]
Nine Months Ended April 30, 2022 Compared with Nine Months Ended May 1, 2021

[0000858877-22-000009:mdna:81]
Total revenue increased by 5%. Product revenue increased by 8% and service revenue decreased by 3%. Our total revenue reflected growth across each of our geographic segments.

[0000858877-22-000009:mdna:82]
[same as prior period, unchanged from 0000858877-22-000004:mdna:77]

[0000858877-22-000009:mdna:83]
[same as prior period, unchanged from 0000858877-22-000004:mdna:78]

[0000858877-22-000009:mdna:84]
[same as prior period, unchanged from 0000858877-22-000004:mdna:93]

[0000858877-22-000009:mdna:85]
[same as prior period, unchanged from 0000858877-22-000004:mdna:94]

[0000858877-22-000009:mdna:86]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 30,2022 |  | May 1,2021 |  | Variancein Dollars |  | Variance in Percent |  | April 30,2022 |  | May 1,2021 |  | Variancein Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 5,573 |  |  | $ | 5,014 |  |  | $ | 559 |  |  | 11 | % |  | $ | 16,223 |  |  | $ | 15,031 |  |  | $ | 1,192 |  |  | 8 | % |
| Percentage of product revenue |  | 59.0 | % |  | 54.8 | % |  |  |  |  |  | 57.3 | % |  | 57.2 | % |  |  |  |  |
| EMEA |  | 2,492 |  |  | 2,647 |  |  | (155) |  |  | (6) | % |  | 7,765 |  |  | 7,295 |  |  | 470 |  |  | 6 | % |
| Percentage of product revenue |  | 26.4 | % |  | 29.0 | % |  |  |  |  |  | 27.4 | % |  | 27.7 | % |  |  |  |  |
| APJC |  | 1,383 |  |  | 1,478 |  |  | (95) |  |  | (6) | % |  | 4,343 |  |  | 3,972 |  |  | 371 |  |  | 9 | % |
| Percentage of product revenue |  | 14.6 | % |  | 16.2 | % |  |  |  |  |  | 15.3 | % |  | 15.1 | % |  |  |  |  |
| Total |  | $ | 9,448 |  |  | $ | 9,139 |  |  | $ | 309 |  |  | 3 | % |  | $ | 28,330 |  |  | $ | 26,298 |  |  | $ | 2,032 |  |  | 8 | % |

[0000858877-22-000009:mdna:87]
[same as prior period, unchanged from 0000858877-22-000004:mdna:96]

[0000858877-22-000009:mdna:88]
[same as prior period, unchanged from 0000858877-22-000004:mdna:97]

[0000858877-22-000009:mdna:89]
Three Months Ended April 30, 2022 Compared with Three Months Ended May 1, 2021

[0000858877-22-000009:mdna:90]
Product revenue in the Americas segment increased by 11%, with growth across all customer markets. From a country perspective, product revenue increased in the United States and Mexico by 14% and 8%, respectively, partially offset by declines in Canada and Brazil of 3% and 18%, respectively.

[0000858877-22-000009:mdna:91]
Nine Months Ended April 30, 2022 Compared with Nine Months Ended May 1, 2021

[0000858877-22-000009:mdna:92]
Product revenue in the Americas segment increased by 8%, driven by growth across all customer markets. From a country perspective, product revenue increased in the United States, Canada and Mexico by 9%, 5% and 9%, respectively, partially offset by a decline of 3% in Brazil.

[0000858877-22-000009:mdna:93]
[same as prior period, unchanged from 0000858877-22-000004:mdna:102]

[0000858877-22-000009:mdna:94]
Three Months Ended April 30, 2022 Compared with Three Months Ended May 1, 2021

[0000858877-22-000009:mdna:95]
Product revenue in the EMEA segment decreased by 6%, driven by declines in the public sector, enterprise and service provider markets, partially offset by growth in the commercial market. Russia, Belarus and Ukraine, collectively, had a negative impact of approximately 7% on product revenue in the EMEA segment. From a country perspective, product revenue decreased in the United Kingdom by 8%, partially offset by growth of 8% in Germany.

[0000858877-22-000009:mdna:96]
Nine Months Ended April 30, 2022 Compared with Nine Months Ended May 1, 2021

[0000858877-22-000009:mdna:97]
Product revenue in the EMEA segment increased by 6%, with growth in the commercial, enterprise and service provider markets, partially offset by a decline in the public sector market. Russia, Belarus and Ukraine had a negative impact on product revenue in the EMEA segment. From a country perspective, product revenue increased in Germany and the United Kingdom by 4% and 10%, respectively.

[0000858877-22-000009:mdna:98]
[same as prior period, unchanged from 0000858877-22-000004:mdna:107]

[0000858877-22-000009:mdna:99]
Three Months Ended April 30, 2022 Compared with Three Months Ended May 1, 2021

[0000858877-22-000009:mdna:100]
Product revenue in the APJC segment decreased by 6%, driven by declines in the service provider and public sector markets, partially offset by growth in the commercial and enterprise markets. From a country perspective, product revenue decreased in Japan, Australia and India by 19%, 3% and 30%, respectively, partially offset by growth of 14% in China.

[0000858877-22-000009:mdna:101]
[same as prior period, unchanged from 0000858877-22-000004:mdna:91]

[0000858877-22-000009:mdna:102]
[same as prior period, unchanged from 0000858877-22-000004:mdna:92]

[0000858877-22-000009:mdna:103]
Nine Months Ended April 30, 2022 Compared with Nine Months Ended May 1, 2021

[0000858877-22-000009:mdna:104]
Product revenue in the APJC segment increased by 9%, with growth in the enterprise and commercial markets, partially offset by declines in the service provider and public sector markets. From a country perspective, product revenue increased in Australia and China by 19% and 15%, respectively, partially offset by a decline of 10% in Japan. Product revenue in India was flat.

[0000858877-22-000009:mdna:105]
[same as prior period, unchanged from 0000858877-22-000004:mdna:114]

[0000858877-22-000009:mdna:106]
In addition to the primary view on a geographic basis, we also prepare financial information related to product categories and customer markets for various purposes. Effective fiscal 2022, we began reporting our product revenue in the following categories: Secure, Agile Networks; Internet for the Future; Collaboration; End-to-End Security; Optimized Application Experiences; and Other Products. This change will better align our product categories with our strategic priorities.

[0000858877-22-000009:mdna:107]
[same as prior period, unchanged from 0000858877-22-000004:mdna:116]

[0000858877-22-000009:mdna:108]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 30,2022 |  | May 1,2021 |  | Variancein Dollars |  | Variance in Percent |  | April 30,2022 |  | May 1,2021 |  | Variancein Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Secure, Agile Networks |  | $ | 5,869 |  |  | $ | 5,620 |  |  | $ | 249 |  |  | 4 | % |  | $ | 17,735 |  |  | $ | 16,543 |  |  | $ | 1,192 |  |  | 7 | % |
| Internet for the Future |  | 1,324 |  |  | 1,249 |  |  | 75 |  |  | 6 | % |  | 4,021 |  |  | 3,121 |  |  | 900 |  |  | 29 | % |
| Collaboration |  | 1,132 |  |  | 1,220 |  |  | (88) |  |  | (7) | % |  | 3,308 |  |  | 3,580 |  |  | (272) |  |  | (8) | % |
| End-to-End Security |  | 938 |  |  | 876 |  |  | 62 |  |  | 7 | % |  | 2,716 |  |  | 2,559 |  |  | 157 |  |  | 6 | % |
| Optimized Application Experiences |  | 183 |  |  | 170 |  |  | 13 |  |  | 8 | % |  | 544 |  |  | 483 |  |  | 61 |  |  | 13 | % |
| Other Products |  | 2 |  |  | 5 |  |  | (3) |  |  | (58) | % |  | 7 |  |  | 11 |  |  | (4) |  |  | (32) | % |
| Total |  | $ | 9,448 |  |  | $ | 9,139 |  |  | $ | 309 |  |  | 3 | % |  | $ | 28,330 |  |  | $ | 26,298 |  |  | $ | 2,032 |  |  | 8 | % |

[0000858877-22-000009:mdna:109]
[same as prior period, unchanged from 0000858877-22-000004:mdna:118]

[0000858877-22-000009:mdna:110]
[same as prior period, unchanged from 0000858877-22-000004:mdna:119]

[0000858877-22-000009:mdna:111]
Three Months Ended April 30, 2022 Compared with Three Months Ended May 1, 2021

[0000858877-22-000009:mdna:112]
The Secure, Agile Networks product category represents our core networking offerings related to switching, enterprise routing, wireless, and compute. Secure, Agile Networks revenue increased by 4%, or $249 million, with growth across the portfolio except enterprise routing. Revenue grew in both campus switching and data center switching. This was primarily driven by strong growth in our Catalyst 9000 series, Nexus 9000 series and Meraki switching offerings. We experienced a decrease in sales of our enterprise routing products primarily driven by declines in our Access and Edge offerings, partially offset by growth in our SD-WAN offerings. Wireless had double-digit growth driven by our WiFi-6 products and Meraki offerings. Revenue from compute grew primarily driven by our servers.

[0000858877-22-000009:mdna:113]
Nine Months Ended April 30, 2022 Compared with Nine Months Ended May 1, 2021

[0000858877-22-000009:mdna:114]
Revenue from the Secure, Agile Networks product category increased 7%, or $1.2 billion, with growth across the portfolio except enterprise routing. Revenue grew in both campus switching and data center switching, primarily driven by growth in our Catalyst 9000 series, Nexus 9000 series and Meraki switching offerings. The decrease in enterprise routing was primarily driven by declines in our Access offerings, partially offset by growth in our Edge and SD-WAN offerings. Wireless had strong double-digit growth driven by our WiFi-6 products and Meraki offerings. Revenue from compute grew primarily driven by our servers.

[0000858877-22-000009:mdna:115]
[same as prior period, unchanged from 0000858877-22-000004:mdna:136]

[0000858877-22-000009:mdna:116]
Three Months Ended April 30, 2022 Compared with Three Months Ended May 1, 2021

[0000858877-22-000009:mdna:117]
The Internet for the Future product category includes our routed optical networking, public 5G, silicon and optics offerings. Revenue in our Internet for the Future product category increased by 6%, or $75 million, primarily driven by growth in our Acacia, Optical, Optics and Core portfolio. The growth in Core was driven by strength in our Cisco 8000 series offerings.

[0000858877-22-000009:mdna:118]
[same as prior period, unchanged from 0000858877-22-000004:mdna:110]

[0000858877-22-000009:mdna:119]
[same as prior period, unchanged from 0000858877-22-000004:mdna:111]

[0000858877-22-000009:mdna:120]
Nine Months Ended April 30, 2022 Compared with Nine Months Ended May 1, 2021

[0000858877-22-000009:mdna:121]
Revenue in our Internet for the Future product category increased 29%, or $900 million, driven by growth in our Cisco 8000, NCS 5500 and ASR 9000 series offerings. We also saw a benefit from our acquisition of Acacia in the third quarter of fiscal 2021.

[0000858877-22-000009:mdna:122]
Collaboration

[0000858877-22-000009:mdna:123]
Three Months Ended April 30, 2022 Compared with Three Months Ended May 1, 2021

[0000858877-22-000009:mdna:124]
The Collaboration product category consists of our Collaboration Devices, Meetings, Calling and contact center offerings. Revenue in our Collaboration product category decreased by 7%, or $88 million, driven by declines in our Meetings, Calling and Contact Center offerings, partially offset by growth in our Communication Platform as a Service (CPaaS) offerings.

[0000858877-22-000009:mdna:125]
Nine Months Ended April 30, 2022 Compared with Nine Months Ended May 1, 2021

[0000858877-22-000009:mdna:126]
Revenue in our Collaboration product category decreased by 8%, or $272 million, with declines in our Collaboration Devices, Meetings, Calling and Contact Center offerings, partially offset by growth in our CPaaS offerings.

[0000858877-22-000009:mdna:127]
[same as prior period, unchanged from 0000858877-22-000004:mdna:131]

[0000858877-22-000009:mdna:128]
Three Months Ended April 30, 2022 Compared with Three Months Ended May 1, 2021

[0000858877-22-000009:mdna:129]
Revenue in our End-to-End Security product category increased 7%, or $62 million primarily driven by growth in our Network Security, zero-trust portfolio, and Unified Threat Management offerings. The double-digit growth in our zero-trust portfolio was driven by continued momentum with our Duo offerings.

[0000858877-22-000009:mdna:130]
Nine Months Ended April 30, 2022 Compared with Nine Months Ended May 1, 2021

[0000858877-22-000009:mdna:131]
Revenue in our End-to-End Security product category increased by 6%, or $157 million, primarily driven by growth in our zero-trust portfolio and Unified Threat Management offerings.

[0000858877-22-000009:mdna:132]
[same as prior period, unchanged from 0000858877-22-000004:mdna:141]

[0000858877-22-000009:mdna:133]
Three Months Ended April 30, 2022 Compared with Three Months Ended May 1, 2021

[0000858877-22-000009:mdna:134]
The Optimized Application Experiences product category includes our full stack observability and cloud-native platforms offerings. Revenue in our Optimized Application Experiences product category increased 8%, or $13 million, driven by growth in our ThousandEyes and Intersight offerings.

[0000858877-22-000009:mdna:135]
Nine Months Ended April 30, 2022 Compared with Nine Months Ended May 1, 2021

[0000858877-22-000009:mdna:136]
Revenue in our Optimized Application Experiences product category increased by 13%, or $61 million, driven by growth in our ThousandEyes and Intersight offerings.

[0000858877-22-000009:mdna:137]
52

[0000858877-22-000009:mdna:138]
[same as prior period, unchanged from 0000858877-22-000004:mdna:127]

[0000858877-22-000009:mdna:139]
[same as prior period, unchanged from 0000858877-22-000004:mdna:128]

[0000858877-22-000009:mdna:140]
[same as prior period, unchanged from 0000858877-22-000004:mdna:148]

[0000858877-22-000009:mdna:141]
[same as prior period, unchanged from 0000858877-22-000004:mdna:149]

[0000858877-22-000009:mdna:142]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 30,2022 |  | May 1,2021 |  | Variancein Dollars |  | Variance in Percent |  | April 30,2022 |  | May 1,2021 |  | Variancein Dollars |  | Variance in Percent |
| Service revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 2,064 |  |  | $ | 2,248 |  |  | $ | (184) |  |  | (8) | % |  | $ | 6,122 |  |  | $ | 6,399 |  |  | $ | (277) |  |  | (4) | % |
| Percentage of service revenue |  | 60.9 | % |  | 61.4 | % |  |  |  |  |  | 60.5 | % |  | 61.6 | % |  |  |  |  |
| EMEA |  | 778 |  |  | 836 |  |  | (58) |  |  | (7) | % |  | 2,373 |  |  | 2,359 |  |  | 14 |  |  | 1 | % |
| Percentage of service revenue |  | 23.0 | % |  | 22.8 | % |  |  |  |  |  | 23.4 | % |  | 22.7 | % |  |  |  |  |
| APJC |  | 544 |  |  | 579 |  |  | (35) |  |  | (6) | % |  | 1,629 |  |  | 1,636 |  |  | (7) |  |  | — | % |
| Percentage of service revenue |  | 16.1 | % |  | 15.8 | % |  |  |  |  |  | 16.1 | % |  | 15.7 | % |  |  |  |  |
| Total |  | $ | 3,387 |  |  | $ | 3,664 |  |  | $ | (277) |  |  | (8) | % |  | $ | 10,125 |  |  | $ | 10,394 |  |  | $ | (269) |  |  | (3) | % |

[0000858877-22-000009:mdna:143]
[same as prior period, unchanged from 0000858877-22-000004:mdna:151]

[0000858877-22-000009:mdna:144]
Service revenue decreased 8% in the third quarter of fiscal 2022 compared with the third quarter of fiscal 2021, primarily driven by the impact of the extra week in the third quarter of fiscal 2021 and the negative impact from the Russia and Ukraine war. The combined negative impact of the extra week in the third quarter of fiscal 2021 and the Russia and Ukraine war was approximately 8% to service revenue for the third quarter of fiscal 2022. Service revenue declined across each of our geographic segments.

[0000858877-22-000009:mdna:145]
Service revenue decreased 3% in the first nine months of fiscal 2022 compared to the first nine months of fiscal 2021 primarily driven by declines in our maintenance business, software support offerings and advisory services partially offset by growth in our solution support offerings. The extra week in the third quarter of fiscal 2021 also contributed to the decrease in service revenue for the first nine months of fiscal 2022. Service revenue decreased in the Americas segment, partially offset by growth in the EMEA segment for the first nine months of fiscal 2022. The APJC segment was flat.

[0000858877-22-000009:mdna:146]
[same as prior period, unchanged from 0000858877-22-000004:mdna:153]

[0000858877-22-000009:mdna:147]
[same as prior period, unchanged from 0000858877-22-000004:mdna:154]

[0000858877-22-000009:mdna:148]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | AMOUNT |  | PERCENTAGE |  | AMOUNT |  | PERCENTAGE |
|  |  | April 30,2022 |  | May 1,2021 |  | April 30,2022 |  | May 1,2021 |  | April 30,2022 |  | May 1,2021 |  | April 30,2022 |  | May 1,2021 |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 5,842 |  |  | $ | 5,717 |  |  | 61.8 | % |  | 62.6 | % |  | $ | 17,482 |  |  | $ | 16,626 |  |  | 61.7 | % |  | 63.2 | % |
| Service |  | 2,279 |  |  | 2,468 |  |  | 67.3 | % |  | 67.4 | % |  | 6,741 |  |  | 6,924 |  |  | 66.6 | % |  | 66.6 | % |
| Total |  | $ | 8,121 |  |  | $ | 8,185 |  |  | 63.3 | % |  | 63.9 | % |  | $ | 24,223 |  |  | $ | 23,550 |  |  | 63.0 | % |  | 64.2 | % |

[0000858877-22-000009:mdna:149]
[same as prior period, unchanged from 0000858877-22-000004:mdna:146]

[0000858877-22-000009:mdna:150]
[same as prior period, unchanged from 0000858877-22-000004:mdna:147]

[0000858877-22-000009:mdna:151]
[same as prior period, unchanged from 0000858877-22-000004:mdna:158]

[0000858877-22-000009:mdna:152]
The following table summarizes the key factors that contributed to the change in product gross margin percentage for the third quarter and first nine months of fiscal 2022, as compared with the corresponding prior year periods:

[0000858877-22-000009:mdna:153]
|  |  | Product Gross Margin Percentage |
|  |  | Three Months Ended |  | Nine Months Ended |
| Fiscal 2021 |  | 62.6 | % |  | 63.2 | % |
| Productivity (1) |  | (2.6) | % |  | (1.9) | % |
| Product pricing |  | 1.6 | % |  | 0.5 | % |
| Mix of products sold |  | 0.2 | % |  | — | % |
| Legal and indemnification charge |  | — | % |  | 0.2 | % |
| Others |  | — | % |  | (0.3) | % |
| Fiscal 2022 |  | 61.8 | % |  | 61.7 | % |

[0000858877-22-000009:mdna:154]
[same as prior period, unchanged from 0000858877-22-000004:mdna:161]

[0000858877-22-000009:mdna:155]
Three Months Ended April 30, 2022 Compared with Three Months Ended May 1, 2021

[0000858877-22-000009:mdna:156]
Product gross margin decreased by 0.8 percentage points primarily driven by negative impacts from productivity, largely driven by increased costs related to supply constraints from freight, expedites, and component costs. The Russia and Ukraine war also had a negative 0.6 percentage points impact on our product gross margin, which is included in the negative impacts from productivity. These impacts were partially offset by favorable pricing.

[0000858877-22-000009:mdna:157]
Nine Months Ended April 30, 2022 Compared with Nine Months Ended May 1, 2021

[0000858877-22-000009:mdna:158]
Product gross margin decreased by 1.5 percentage points primarily driven by negative impacts from productivity, largely driven by increased costs related to supply chain constraints from freight, expedites, and component costs, partially offset by favorable pricing.

[0000858877-22-000009:mdna:159]
[same as prior period, unchanged from 0000858877-22-000004:mdna:166]

[0000858877-22-000009:mdna:160]
We continue to manage through significant supply constraints seen industry-wide due to component shortages caused, in part, by the COVID-19 pandemic, and for which the duration of such constraints is uncertain. These shortages have resulted in increased costs (i.e., component and other commodity costs, freight, expedite fees, etc.) which have had a negative impact on our product gross margin and have resulted in extended lead times for us and our customers. We have taken a number of steps in order to mitigate the supply constraint related impacts including: partnering with several of our key suppliers utilizing our volume purchasing ability and extending supply coverage, including, in certain cases, revising supplier arrangements; paying significantly higher component and logistics costs to secure supply; modifying our product designs in order to leverage alternate suppliers, where possible; continually optimizing our inventory build and customer delivery plans; among others. We believe these actions are helping us to optimize our access to critical components and meet customer demand for our products. We continue to see solid demand across the majority of our portfolio. As a result, in order to secure supply to meet customer demand, we have increased our inventory balances and inventory purchase commitments (see Liquidity and Capital Resources—Inventory Supply Chain section), which, in turn, has increased our supply chain exposure. Additionally, in certain situations, we have prepaid or made deposits with suppliers to secure future supply. These actions significantly increase the risk of future material excess and obsolete inventory and related losses if customer demand were to suddenly and significantly decrease in future periods. While we believe we are taking the right strategic and operational actions to address the supply situation, we recognize the increased risks.

[0000858877-22-000009:mdna:161]
[same as prior period, unchanged from 0000858877-22-000004:mdna:168]

[0000858877-22-000009:mdna:162]
Three Months Ended April 30, 2022 Compared with Three Months Ended May 1, 2021

[0000858877-22-000009:mdna:163]
Our service gross margin percentage decreased by 0.1 percentage points primarily due to lower sales volume, partially offset by lower headcount-related and delivery costs and favorable mix of service offerings.

[0000858877-22-000009:mdna:164]
[same as prior period, unchanged from 0000858877-22-000004:mdna:171]

[0000858877-22-000009:mdna:165]
[same as prior period, unchanged from 0000858877-22-000004:mdna:156]

[0000858877-22-000009:mdna:166]
[same as prior period, unchanged from 0000858877-22-000004:mdna:157]

[0000858877-22-000009:mdna:167]
[same as prior period, unchanged from 0000858877-22-000004:mdna:175]

[0000858877-22-000009:mdna:168]
Nine Months Ended April 30, 2022 Compared with Nine Months Ended May 1, 2021

[0000858877-22-000009:mdna:169]
Service gross margin was flat primarily due to favorable mix and lower delivery costs offset by lower sales volume.

[0000858877-22-000009:mdna:170]
[same as prior period, unchanged from 0000858877-22-000004:mdna:178]

[0000858877-22-000009:mdna:171]
[same as prior period, unchanged from 0000858877-22-000004:mdna:179]

[0000858877-22-000009:mdna:172]
|  | Three Months Ended |  | Nine Months Ended |
|  | AMOUNT |  | PERCENTAGE |  | AMOUNT |  | PERCENTAGE |
|  | April 30,2022 |  | May 1,2021 |  | April 30,2022 |  | May 1,2021 |  | April 30,2022 |  | May 1,2021 |  | April 30,2022 |  | May 1,2021 |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 4,952 |  |  | $ | 4,831 |  |  | 64.8 | % |  | 66.5 | % |  | $ | 14,438 |  |  | $ | 14,383 |  |  | 64.6 | % |  | 67.1 | % |
| EMEA | 2,154 |  |  | 2,283 |  |  | 65.9 | % |  | 65.6 | % |  | 6,664 |  |  | 6,322 |  |  | 65.7 | % |  | 65.5 | % |
| APJC | 1,279 |  |  | 1,331 |  |  | 66.4 | % |  | 64.7 | % |  | 3,934 |  |  | 3,599 |  |  | 65.9 | % |  | 64.2 | % |
| Segment total | 8,386 |  |  | 8,445 |  |  | 65.3 | % |  | 66.0 | % |  | 25,035 |  |  | 24,303 |  |  | 65.1 | % |  | 66.2 | % |
| Unallocated corporate items (1) | (265) |  |  | (260) |  |  |  |  |  |  | (812) |  |  | (753) |  |  |  |  |  |
| Total | $ | 8,121 |  |  | $ | 8,185 |  |  | 63.3 | % |  | 63.9 | % |  | $ | 24,223 |  |  | $ | 23,550 |  |  | 63.0 | % |  | 64.2 | % |

[0000858877-22-000009:mdna:173]
(1) The unallocated corporate items include the effects of amortization and impairments of acquisition-related intangible assets, share-based compensation expense, significant litigation settlements and other contingencies, charges related to asset impairments and restructurings, and certain other charges. We do not allocate these items to the gross margin for each segment because management does not include such information in measuring the performance of the operating segments.

[0000858877-22-000009:mdna:174]
[same as prior period, unchanged from 0000858877-22-000004:mdna:182]

[0000858877-22-000009:mdna:175]
Three Months Ended April 30, 2022 Compared with Three Months Ended May 1, 2021

[0000858877-22-000009:mdna:176]
We experienced a gross margin percentage decrease in our Americas segment due to negative impacts from productivity and unfavorable impacts from product mix, partially offset by favorable pricing.

[0000858877-22-000009:mdna:177]
Gross margin in our EMEA segment increased slightly primarily due to favorable pricing and favorable impacts from product mix, partially offset by negative impacts from productivity. Higher service gross margin also contributed to the increase in the gross margin in this geographic segment.

[0000858877-22-000009:mdna:178]
The APJC segment gross margin percentage increase was due to favorable impacts from product mix and favorable pricing, partially offset by negative impacts from productivity.

[0000858877-22-000009:mdna:179]
[same as prior period, unchanged from 0000858877-22-000004:mdna:187]

[0000858877-22-000009:mdna:180]
Nine Months Ended April 30, 2022 Compared with Nine Months Ended May 1, 2021

[0000858877-22-000009:mdna:181]
The Americas segment had a gross margin percentage decrease driven by negative impacts from productivity and unfavorable product mix.

[0000858877-22-000009:mdna:182]
The slight gross margin percentage increase in our EMEA segment was primarily due to higher service gross margin in this geographic segment and favorable product mix, partially offset by negative impacts from productivity.

[0000858877-22-000009:mdna:183]
The APJC segment gross margin percentage increase was driven by favorable product mix and favorable pricing, partially offset by negative impacts from productivity.

[0000858877-22-000009:mdna:184]
[same as prior period, unchanged from 0000858877-22-000004:mdna:173]

[0000858877-22-000009:mdna:185]
[same as prior period, unchanged from 0000858877-22-000004:mdna:174]

[0000858877-22-000009:mdna:186]
[same as prior period, unchanged from 0000858877-22-000004:mdna:194]

[0000858877-22-000009:mdna:187]
[same as prior period, unchanged from 0000858877-22-000004:mdna:195]

[0000858877-22-000009:mdna:188]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 30,2022 |  | May 1,2021 |  | Variancein Dollars |  | Variance in Percent |  | April 30,2022 |  | May 1,2021 |  | Variancein Dollars |  | Variance in Percent |
| Research and development | $ | 1,708 |  |  | $ | 1,697 |  |  | $ | 11 |  |  | 1 | % |  | $ | 5,092 |  |  | $ | 4,836 |  |  | $ | 256 |  |  | 5 | % |
| Percentage of revenue | 13.3 | % |  | 13.3 | % |  |  |  |  |  | 13.2 | % |  | 13.2 | % |  |  |  |  |
| Sales and marketing | 2,209 |  |  | 2,317 |  |  | (108) |  |  | (5) | % |  | 6,736 |  |  | 6,811 |  |  | (75) |  |  | (1) | % |
| Percentage of revenue | 17.2 | % |  | 18.1 | % |  |  |  |  |  | 17.5 | % |  | 18.6 | % |  |  |  |  |
| General and administrative | 517 |  |  | 603 |  |  | (86) |  |  | (14) | % |  | 1,612 |  |  | 1,631 |  |  | (19) |  |  | (1) | % |
| Percentage of revenue | 4.0 | % |  | 4.7 | % |  |  |  |  |  | 4.2 | % |  | 4.4 | % |  |  |  |  |
| Total | $ | 4,434 |  |  | $ | 4,617 |  |  | $ | (183) |  |  | (4) | % |  | $ | 13,440 |  |  | $ | 13,278 |  |  | $ | 162 |  |  | 1 | % |
| Percentage of revenue | 34.5 | % |  | 36.1 | % |  |  |  |  |  | 34.9 | % |  | 36.2 | % |  |  |  |  |

[0000858877-22-000009:mdna:189]
Our third quarter of fiscal 2022 had one less week compared with the corresponding period of fiscal 2021 which had an extra week.

[0000858877-22-000009:mdna:190]
[same as prior period, unchanged from 0000858877-22-000004:mdna:197]

[0000858877-22-000009:mdna:191]
Three Months Ended April 30, 2022 Compared with Three Months Ended May 1, 2021

[0000858877-22-000009:mdna:192]
R&D expenses increased slightly due to higher share-based compensation expense, partially offset by lower contracted services spending and lower headcount-related expenses. The extra week in the third quarter of fiscal 2021 contributed to the decrease in headcount-related expenses.

[0000858877-22-000009:mdna:193]
[same as prior period, unchanged from 0000858877-22-000004:mdna:200]

[0000858877-22-000009:mdna:194]
Nine Months Ended April 30, 2022 Compared with Nine Months Ended May 1, 2021

[0000858877-22-000009:mdna:195]
[same as prior period, unchanged from 0000858877-22-000004:mdna:202]

[0000858877-22-000009:mdna:196]
[same as prior period, unchanged from 0000858877-22-000004:mdna:203]

[0000858877-22-000009:mdna:197]
Three Months Ended April 30, 2022 Compared with Three Months Ended May 1, 2021

[0000858877-22-000009:mdna:198]
Sales and marketing expenses decreased due to lower headcount-related expenses, driven by lower variable compensation expense, and lower contracted services spending, partially offset by higher discretionary spending. The extra week in the third quarter of fiscal 2021 contributed to the decrease in headcount-related expenses.

[0000858877-22-000009:mdna:199]
Nine Months Ended April 30, 2022 Compared with Nine Months Ended May 1, 2021

[0000858877-22-000009:mdna:200]
Sales and marketing expenses decreased primarily due to lower headcount-related expenses and lower contracted services spending, partially offset by higher discretionary spending. The extra week in the first nine months of fiscal 2021 contributed to the decrease in headcount-related expenses.

[0000858877-22-000009:mdna:201]
[same as prior period, unchanged from 0000858877-22-000004:mdna:208]

[0000858877-22-000009:mdna:202]
Three Months Ended April 30, 2022 Compared with Three Months Ended May 1, 2021

[0000858877-22-000009:mdna:203]
G&A expenses decreased due to lower headcount-related expenses, lower contracted services spending, lower discretionary spending and lower acquisition and divestitures related costs, partially offset by certain non-recurring charges recognized due to the Russia and Ukraine war. The extra week in the third quarter of fiscal 2021 contributed to the decrease in headcount-related expenses.

[0000858877-22-000009:mdna:204]
[same as prior period, unchanged from 0000858877-22-000004:mdna:192]

[0000858877-22-000009:mdna:205]
[same as prior period, unchanged from 0000858877-22-000004:mdna:193]

[0000858877-22-000009:mdna:206]
Nine Months Ended April 30, 2022 Compared with Nine Months Ended May 1, 2021

[0000858877-22-000009:mdna:207]
G&A expenses decreased due to lower contracted services spending, lower headcount-related expenses, partially offset by higher acquisition and divestiture related costs and certain non-recurring charges recognized due to the Russia and Ukraine war. The extra week in the first nine months of fiscal 2021 contributed to the decrease in headcount-related expenses.

[0000858877-22-000009:mdna:208]
[same as prior period, unchanged from 0000858877-22-000004:mdna:210]

[0000858877-22-000009:mdna:209]
In the third quarter of fiscal 2022, foreign currency fluctuations, net of hedging, decreased the combined R&D, sales and marketing, and G&A expenses by approximately $51 million, or 1.1%, compared with the third quarter of fiscal 2021.

[0000858877-22-000009:mdna:210]
In the first nine months of fiscal 2022, foreign currency fluctuations, net of hedging, decreased the combined R&D, sales and marketing, and G&A expenses by approximately $50 million, or 0.4%, compared with the first nine months of fiscal 2021.

[0000858877-22-000009:mdna:211]
[same as prior period, unchanged from 0000858877-22-000004:mdna:215]

[0000858877-22-000009:mdna:212]
[same as prior period, unchanged from 0000858877-22-000004:mdna:216]

[0000858877-22-000009:mdna:213]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 30,2022 |  | May 1,2021 |  | April 30,2022 |  | May 1,2021 |
| Amortization of purchased intangible assets: |  |  |  |  |  |  |  |  |
| Cost of sales |  | $ | 180 |  |  | $ | 187 |  |  | $ | 583 |  |  | $ | 513 |  |
| Operating expenses |  | 92 |  |  | 61 |  |  | 255 |  |  | 136 |  |
| Total |  | $ | 272 |  |  | $ | 248 |  |  | $ | 838 |  |  | $ | 649 |  |

[0000858877-22-000009:mdna:214]
For each of the third quarter and first nine months of fiscal 2022, the increase in amortization of purchased intangible assets was due largely to the amortization of purchased intangibles from our recent acquisitions and impairment charges of $15 million recorded in the third quarter and first nine months of fiscal 2022. The impairment charges were primarily due to declines in estimated fair value resulting from reductions in or the elimination of expected future cash flows associated with certain of our technology and IPR&D intangible assets.

[0000858877-22-000009:mdna:215]
[same as prior period, unchanged from 0000858877-22-000004:mdna:219]

[0000858877-22-000009:mdna:216]
[same as prior period, unchanged from 0000858877-22-000004:mdna:220]

[0000858877-22-000009:mdna:217]
[same as prior period, unchanged from 0000858877-22-000004:mdna:221]

[0000858877-22-000009:mdna:218]
[same as prior period, unchanged from 0000858877-22-000004:mdna:222]

[0000858877-22-000009:mdna:219]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 30,2022 |  | May 1,2021 |  | April 30,2022 |  | May 1,2021 |
| Operating income |  | $ | 3,610 |  |  | $ | 3,465 |  |  | $ | 10,535 |  |  | $ | 9,258 |  |
| Operating income as a percentage of revenue |  | 28.1 | % |  | 27.1 | % |  | 27.4 | % |  | 25.2 | % |

[0000858877-22-000009:mdna:220]
Three Months Ended April 30, 2022 Compared with Three Months Ended May 1, 2021

[0000858877-22-000009:mdna:221]
Operating income increased by 4%, and operating income as a percentage of revenue increased by 1.0 percentage points. These changes resulted primarily from a decrease in operating expenses.

[0000858877-22-000009:mdna:222]
Nine Months Ended April 30, 2022 Compared with Nine Months Ended May 1, 2021

[0000858877-22-000009:mdna:223]
Operating income increased by 14%, and operating income as a percentage of revenue increased by 2.2 percentage points. These changes resulted primarily from a revenue increase and lower restructuring and other charges partially offset by a gross margin percentage decrease (driven by negative impacts from productivity partially offset by favorable pricing).

[0000858877-22-000009:mdna:224]
[same as prior period, unchanged from 0000858877-22-000004:mdna:213]

[0000858877-22-000009:mdna:225]
[same as prior period, unchanged from 0000858877-22-000004:mdna:214]

[0000858877-22-000009:mdna:226]
[same as prior period, unchanged from 0000858877-22-000004:mdna:228]

[0000858877-22-000009:mdna:227]
[same as prior period, unchanged from 0000858877-22-000004:mdna:229]

[0000858877-22-000009:mdna:228]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 30,2022 |  | May 1,2021 |  | Variancein Dollars |  | April 30,2022 |  | May 1,2021 |  | Variancein Dollars |
| Interest income |  | $ | 115 |  |  | $ | 153 |  |  | $ | (38) |  |  | $ | 347 |  |  | $ | 488 |  |  | $ | (141) |  |
| Interest expense |  | (90) |  |  | (111) |  |  | 21 |  |  | (267) |  |  | (336) |  |  | 69 |  |
| Interest income (expense), net |  | $ | 25 |  |  | $ | 42 |  |  | $ | (17) |  |  | $ | 80 |  |  | $ | 152 |  |  | $ | (72) |  |

[0000858877-22-000009:mdna:229]
For each of the third quarter and first nine months of fiscal 2022, the decrease in interest income was driven by lower interest rates and lower average balances of cash and available-for-sale debt investments. The decrease in interest expense was driven by a lower average debt balance.

[0000858877-22-000009:mdna:230]
[same as prior period, unchanged from 0000858877-22-000004:mdna:234]

[0000858877-22-000009:mdna:231]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 30,2022 |  | May 1,2021 |  | Variancein Dollars |  | April 30,2022 |  | May 1,2021 |  | Variancein Dollars |
| Gains (losses) on investments, net: |  |  |  |  |  |  |  |  |  |  |  |  |
| Available-for-sale debt investments |  | $ | 2 |  |  | $ | 22 |  |  | $ | (20) |  |  | $ | 18 |  |  | $ | 46 |  |  | $ | (28) |  |
| Marketable equity investments |  | (19) |  |  | 2 |  |  | (21) |  |  | (32) |  |  | 1 |  |  | (33) |  |
| Privately held investments |  | 166 |  |  | 95 |  |  | 71 |  |  | 492 |  |  | 120 |  |  | 372 |  |
| Net gains (losses) on investments |  | 149 |  |  | 119 |  |  | 30 |  |  | 478 |  |  | 167 |  |  | 311 |  |
| Other gains (losses), net |  | 17 |  |  | (35) |  |  | 52 |  |  | (32) |  |  | (50) |  |  | 18 |  |
| Other income (loss), net |  | $ | 166 |  |  | $ | 84 |  |  | $ | 82 |  |  | $ | 446 |  |  | $ | 117 |  |  | $ | 329 |  |

[0000858877-22-000009:mdna:232]
Three Months Ended April 30, 2022 Compared with Three Months Ended May 1, 2021

[0000858877-22-000009:mdna:233]
The change in net gains (losses) on available-for-sale debt investment was primarily attributable to lower realized gains as a result of market conditions, and the timing of sales of these investments. The change in net gains (losses) on marketable equity investments was attributable to market value fluctuations and the timing of recognition of gains and losses. The change in net gains (losses) on privately held investments was primarily due to higher net realized gains and higher net unrealized gains. The change in other gains (losses), net was primarily driven by favorable impacts from foreign exchange.

[0000858877-22-000009:mdna:234]
Nine Months Ended April 30, 2022 Compared with Nine Months Ended May 1, 2021

[0000858877-22-000009:mdna:235]
The change in net gains (losses) on available-for-sale debt investments was primarily attributable to lower realized gains as a result of market conditions, and the timing of sales of these investments. The change in net gains (losses) on marketable equity investments was attributable to market value fluctuations and the timing of recognition of gains and losses. The change in net gains (losses) on privately held investments was primarily due to higher net realized gains and higher net unrealized gains. The change in other gains (losses), net was primarily driven by favorable impacts from foreign exchange, partially offset by higher donation expense and impacts from our equity derivatives.

[0000858877-22-000009:mdna:236]
[same as prior period, unchanged from 0000858877-22-000004:mdna:240]

[0000858877-22-000009:mdna:237]
Three Months Ended April 30, 2022 Compared with Three Months Ended May 1, 2021

[0000858877-22-000009:mdna:238]
The provision for income taxes resulted in an effective tax rate of 19.9% for the third quarter of fiscal 2022 compared with 20.3% for the third quarter of fiscal 2021. The decrease in the effective tax rate was primarily due to a decrease in nondeductible acquisition-related costs in the third quarter of fiscal 2022 as compared to the third quarter of fiscal 2021.

[0000858877-22-000009:mdna:239]
[same as prior period, unchanged from 0000858877-22-000004:mdna:232]

[0000858877-22-000009:mdna:240]
[same as prior period, unchanged from 0000858877-22-000004:mdna:233]

[0000858877-22-000009:mdna:241]
Nine Months Ended April 30, 2022 Compared with Nine Months Ended May 1, 2021

[0000858877-22-000009:mdna:242]
The provision for income taxes resulted in an effective tax rate of 18.7% for the first nine months of fiscal 2022 compared with 20.4% for the first nine months of fiscal 2021. The decrease in the effective tax rate was primarily due to an increase in the tax benefit from share-based compensation windfall and a decrease in audit settlement expense in the first nine months of fiscal 2022 as compared to the first nine months of fiscal 2021.

[0000858877-22-000009:mdna:243]
[same as prior period, unchanged from 0000858877-22-000004:mdna:243]

[0000858877-22-000009:mdna:244]
59

[0000858877-22-000009:mdna:245]
[same as prior period, unchanged from 0000858877-22-000004:mdna:246]

[0000858877-22-000009:mdna:246]
[same as prior period, unchanged from 0000858877-22-000004:mdna:247]

[0000858877-22-000009:mdna:247]
[same as prior period, unchanged from 0000858877-22-000004:mdna:248]

[0000858877-22-000009:mdna:248]
[same as prior period, unchanged from 0000858877-22-000004:mdna:249]

[0000858877-22-000009:mdna:249]
[same as prior period, unchanged from 0000858877-22-000004:mdna:250]

[0000858877-22-000009:mdna:250]
[same as prior period, unchanged from 0000858877-22-000004:mdna:251]

[0000858877-22-000009:mdna:251]
|  | April 30,2022 |  | July 31,2021 |  | Increase (Decrease) |
| Cash and cash equivalents | $ | 6,952 |  |  | $ | 9,175 |  |  | $ | (2,223) |  |
| Available-for-sale debt investments | 12,914 |  |  | 15,206 |  |  | (2,292) |  |
| Marketable equity securities | 242 |  |  | 137 |  |  | 105 |  |
| Total | $ | 20,108 |  |  | $ | 24,518 |  |  | $ | (4,410) |  |

[0000858877-22-000009:mdna:252]
The net decrease in cash and cash equivalents and investments in the first nine months of fiscal 2022 was driven by cash returned to stockholders in the form of repurchases of common stock of $5.3 billion, cash dividends of $4.7 billion, a net decrease in debt of $2.0 billion, net cash paid for acquisitions and divestitures of $0.4 billion and capital expenditures of $0.3 billion. These uses of cash were partially offset by cash provided by operating activities of $9.5 billion.

[0000858877-22-000009:mdna:253]
[same as prior period, unchanged from 0000858877-22-000004:mdna:254]

[0000858877-22-000009:mdna:254]
[same as prior period, unchanged from 0000858877-22-000004:mdna:255]

[0000858877-22-000009:mdna:255]
[same as prior period, unchanged from 0000858877-22-000004:mdna:256]

[0000858877-22-000009:mdna:256]
[same as prior period, unchanged from 0000858877-22-000004:mdna:257]

[0000858877-22-000009:mdna:257]
|  | Nine Months Ended |
|  | April 30,2022 |  | May 1,2021 |
| Net cash provided by operating activities | $ | 9,549 |  |  | $ | 10,950 |  |
| Acquisition of property and equipment | (338) |  |  | (530) |  |
| Free cash flow | $ | 9,211 |  |  | $ | 10,420 |  |

[0000858877-22-000009:mdna:258]
[same as prior period, unchanged from 0000858877-22-000004:mdna:259]

[0000858877-22-000009:mdna:259]
[same as prior period, unchanged from 0000858877-22-000004:mdna:261]

[0000858877-22-000009:mdna:260]
[same as prior period, unchanged from 0000858877-22-000004:mdna:262]

[0000858877-22-000009:mdna:261]
[same as prior period, unchanged from 0000858877-22-000004:mdna:263]

[0000858877-22-000009:mdna:262]
[same as prior period, unchanged from 0000858877-22-000004:mdna:264]

[0000858877-22-000009:mdna:263]
|  |  | DIVIDENDS |  | STOCK REPURCHASE PROGRAM |  |  |
| Quarter Ended |  | Per Share |  | Amount |  | Shares |  | Weighted-Average Price per Share |  | Amount |  | TOTAL |
| Fiscal 2022 |  |  |  |  |  |  |  |  |  |  |  |  |
| April 30, 2022 |  | $ | 0.38 |  |  | $ | 1,555 |  |  | 5 |  |  | $ | 54.20 |  |  | $ | 252 |  |  | $ | 1,807 |  |
| January 29, 2022 |  | $ | 0.37 |  |  | $ | 1,541 |  |  | 82 |  |  | $ | 58.36 |  |  | $ | 4,824 |  |  | $ | 6,365 |  |
| October 30, 2021 |  | $ | 0.37 |  |  | $ | 1,561 |  |  | 5 |  |  | $ | 56.49 |  |  | $ | 256 |  |  | $ | 1,817 |  |
| Fiscal 2021 |  |  |  |  |  |  |  |  |  |  |  |  |
| July 31, 2021 |  | $ | 0.37 |  |  | $ | 1,562 |  |  | 15 |  |  | $ | 53.30 |  |  | $ | 791 |  |  | $ | 2,353 |  |
| May 1, 2021 |  | $ | 0.37 |  |  | $ | 1,560 |  |  | 10 |  |  | $ | 48.71 |  |  | $ | 510 |  |  | $ | 2,070 |  |
| January 23, 2021 |  | $ | 0.36 |  |  | $ | 1,521 |  |  | 19 |  |  | $ | 42.82 |  |  | $ | 801 |  |  | $ | 2,322 |  |
| October 24, 2020 |  | $ | 0.36 |  |  | $ | 1,520 |  |  | 20 |  |  | $ | 40.44 |  |  | $ | 800 |  |  | $ | 2,320 |  |

[0000858877-22-000009:mdna:264]
Any future dividends are subject to the approval of our Board of Directors.

[0000858877-22-000009:mdna:265]
The remaining authorized amount for stock repurchases under this program is approximately $17.6 billion, with no termination date.

[0000858877-22-000009:mdna:266]
[same as prior period, unchanged from 0000858877-22-000004:mdna:268]

[0000858877-22-000009:mdna:267]
|  | April 30,2022 |  | July 31,2021 |  | Increase (Decrease) |
| Accounts receivable, net | $ | 5,783 |  |  | $ | 5,766 |  |  | $ | 17 |  |

[0000858877-22-000009:mdna:268]
Our accounts receivable net, as of April 30, 2022 was flat as compared with the end of fiscal 2021, primarily due to timing and amount of product and service billings in the third quarter of fiscal 2022 compared with the fourth quarter of fiscal 2021.

[0000858877-22-000009:mdna:269]
[same as prior period, unchanged from 0000858877-22-000004:mdna:271]

[0000858877-22-000009:mdna:270]
[same as prior period, unchanged from 0000858877-22-000004:mdna:272]

[0000858877-22-000009:mdna:271]
[same as prior period, unchanged from 0000858877-22-000004:mdna:273]

[0000858877-22-000009:mdna:272]
[same as prior period, unchanged from 0000858877-22-000004:mdna:274]

[0000858877-22-000009:mdna:273]
|  | April 30,2022 |  | July 31,2021 |  | July 25,2020 |  | Variance vs. July 31, 2021 |  | Variance vs. July 25, 2020 |
| Inventories | $ | 2,231 |  |  | $ | 1,559 |  |  | $ | 1,282 |  |  | $ | 672 |  |  | $ | 949 |  |
| Inventory purchase commitments | $ | 13,099 |  |  | $ | 10,254 |  |  | $ | 4,406 |  |  | $ | 2,845 |  |  | $ | 8,693 |  |
| Inventory deposits and prepayments | $ | 1,137 |  |  | $ | 162 |  |  | $ | 117 |  |  | $ | 975 |  |  | $ | 1,020 |  |

[0000858877-22-000009:mdna:274]
[same as prior period, unchanged from 0000858877-22-000004:mdna:276]

[0000858877-22-000009:mdna:275]
|  | April 30,2022 |  | July 31,2021 |  | July 25,2020 |  | Variance vs. July 31, 2021 |  | Variance vs.July 25, 2020 |
| Less than 1 year | $ | 10,698 |  |  | $ | 6,903 |  |  | $ | 3,994 |  |  | $ | 3,795 |  |  | $ | 6,704 |  |
| 1 to 3 years | 2,401 |  |  | 1,806 |  |  | 412 |  |  | 595 |  |  | 1,989 |  |
| 3 to 5 years | — |  |  | 1,545 |  |  | — |  |  | (1,545) |  |  | — |  |
| Total | $ | 13,099 |  |  | $ | 10,254 |  |  | $ | 4,406 |  |  | $ | 2,845 |  |  | $ | 8,693 |  |

[0000858877-22-000009:mdna:276]
Inventories and inventory purchase commitments increased as compared to the prior fiscal periods as we increased our balances in order to address significant supply constraints seen industry-wide. Inventory as of April 30, 2022 increased by 43% and 74% from our inventory balances at the end of fiscal 2021 and fiscal 2020, respectively. Inventory purchase commitments with contract manufacturers and suppliers increased by 28% and 197% from our balances at the end of fiscal 2021 and fiscal 2020, respectively. These increases compared with the end of fiscal 2021 and fiscal 2020 were primarily due to arrangements to secure supply and pricing for certain product components and commitments with contract manufacturers to meet customer demand and to address extended lead times, as a result of the supply constraints. The increase in inventory deposits and prepayments from the end of fiscal 2021 and fiscal 2020 were primarily due to advance payments with suppliers to secure future supply. We have partnered with several of our key suppliers utilizing our volume purchasing and extending supply coverage, including revising supplier arrangements. Our inventory deposits and prepayments are to secure future supply with our contract manufacturers and suppliers. As discussed, our risks of future material excess and obsolete inventory and related losses are further outlined in the Result of Operations—Product Gross Margin section.

[0000858877-22-000009:mdna:277]
[same as prior period, unchanged from 0000858877-22-000004:mdna:279]

[0000858877-22-000009:mdna:278]
[same as prior period, unchanged from 0000858877-22-000004:mdna:280]

[0000858877-22-000009:mdna:279]
[same as prior period, unchanged from 0000858877-22-000004:mdna:281]

[0000858877-22-000009:mdna:280]
[same as prior period, unchanged from 0000858877-22-000004:mdna:282]

[0000858877-22-000009:mdna:281]
|  | April 30,2022 |  | July 31,2021 |  | Increase (Decrease) |
| Lease receivables, net | $ | 1,302 |  |  | $ | 1,697 |  |  | $ | (395) |  |
| Loan receivables, net | 4,412 |  |  | 5,117 |  |  | (705) |  |
| Financed service contracts, net | 2,049 |  |  | 2,450 |  |  | (401) |  |
| Total, net | $ | 7,763 |  |  | $ | 9,264 |  |  | $ | (1,501) |  |

[0000858877-22-000009:mdna:282]
62

[0000858877-22-000009:mdna:283]
[same as prior period, unchanged from 0000858877-22-000004:mdna:284]

[0000858877-22-000009:mdna:284]
[same as prior period, unchanged from 0000858877-22-000004:mdna:285]

[0000858877-22-000009:mdna:285]
Financing Receivables  Our financing arrangements include leases, loans, and financed service contracts. Lease receivables include sales-type leases. Arrangements related to leases are generally collateralized by a security interest in the underlying assets. Our loan receivables include customer financing for purchases of our hardware, software and services and also may include additional funds for other costs associated with network installation and integration of our products and services. We also provide financing to certain qualified customers for long-term service contracts, which primarily relate to technical support services. The majority of the revenue from these financed service contracts is deferred and is recognized ratably over the period during which the services are performed. Financing receivables decreased by 16%, as compared with the end of fiscal 2021.

[0000858877-22-000009:mdna:286]
[same as prior period, unchanged from 0000858877-22-000004:mdna:287]

[0000858877-22-000009:mdna:287]
The volume of channel partner financing was $20.3 billion and $19.5 billion for the first nine months of fiscal 2022 and 2021, respectively. These financing arrangements facilitate the working capital requirements of the channel partners, and in some cases, we guarantee a portion of these arrangements. The balance of the channel partner financing subject to guarantees was $1.3 billion as of each of April 30, 2022 and July 31, 2021. We could be called upon to make payments under these guarantees in the event of nonpayment by the channel partners or end-user customers. Historically, our payments under these arrangements have been immaterial. Where we provide a guarantee, we defer the revenue associated with the channel partner and end-user financing arrangement in accordance with revenue recognition policies, or we record a liability for the fair value of the guarantees. In either case, the deferred revenue is recognized as revenue when the guarantee is removed. As of April 30, 2022, the total maximum potential future payments related to these guarantees was approximately $148 million, of which approximately $19 million was recorded as deferred revenue.

[0000858877-22-000009:mdna:288]
[same as prior period, unchanged from 0000858877-22-000004:mdna:289]

[0000858877-22-000009:mdna:289]
[same as prior period, unchanged from 0000858877-22-000004:mdna:290]

[0000858877-22-000009:mdna:290]
|  | Maturity Date |  | April 30,2022 |  | July 31,2021 |
| Senior notes: |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |
| 1.85% | September 20, 2021 |  | $ | — |  |  | $ | 2,000 |  |
| 3.00% | June 15, 2022 |  | 500 |  |  | 500 |  |
| 2.60% | February 28, 2023 |  | 500 |  |  | 500 |  |
| 2.20% | September 20, 2023 |  | 750 |  |  | 750 |  |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1,000 |  |
| 3.50% | June 15, 2025 |  | 500 |  |  | 500 |  |
| 2.95% | February 28, 2026 |  | 750 |  |  | 750 |  |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 1,500 |  |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 2,000 |  |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 2,000 |  |
| Total |  |  | $ | 9,500 |  |  | $ | 11,500 |  |

[0000858877-22-000009:mdna:291]
Interest is payable semiannually on each class of the senior fixed-rate notes, each of which is redeemable by us at any time, subject to a make-whole premium. We were in compliance with all debt covenants as of April 30, 2022.

[0000858877-22-000009:mdna:292]
Commercial Paper  We have a short-term debt financing program in which up to $10.0 billion is available through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes. We had no commercial paper notes outstanding as of April 30, 2022 and July 31, 2021.

[0000858877-22-000009:mdna:293]
Credit Facility  On May 13, 2021, we entered into a 5-year credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 13, 2026. As of April 30, 2022, we were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under the credit agreement.

[0000858877-22-000009:mdna:294]
[same as prior period, unchanged from 0000858877-22-000004:mdna:294]

[0000858877-22-000009:mdna:295]
[same as prior period, unchanged from 0000858877-22-000004:mdna:295]

[0000858877-22-000009:mdna:296]
Any advances under the 5-year credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (a) with respect to loans in U.S. dollars, (i) LIBOR or (ii) the Base Rate (to be defined as the highest of (x) the Bank of America prime rate, (y) the Federal Funds rate plus 0.50% and (z) a daily rate equal to one-month LIBOR plus 1.0%), (b) with respect to loans in Euros, EURIBOR, (c) with respect to loans in Yen, TIBOR and (d) with respect to loans in Pounds Sterling, SONIA plus a credit spread adjustment, plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the interest rate be less than 0.0%. We will pay a quarterly commitment fee during the term of the 5-year credit agreement which may vary depending on our senior debt credit ratings. In addition, the 5-year credit agreement incorporates certain sustainability-linked metrics. Specifically, our applicable interest rate and commitment fee are subject to upward or downward adjustments if we achieve, or fail to achieve, certain specified targets based on two key performance indicator metrics: (i) social impact and (ii) foam reduction. We may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and, at our option, extend the maturity of the facility for an additional year up to two times. The credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio as defined in the agreement.

[0000858877-22-000009:mdna:297]
[same as prior period, unchanged from 0000858877-22-000004:mdna:298]

[0000858877-22-000009:mdna:298]
|  | April 30,2022 |  | July 31,2021 |  | Increase (Decrease) |
| Product | $ | 13,416 |  |  | $ | 13,270 |  |  | $ | 146 |  |
| Service | 16,789 |  |  | 17,623 |  |  | (834) |  |
| Total | $ | 30,205 |  |  | $ | 30,893 |  |  | $ | (688) |  |
| Short-term RPO | $ | 16,241 |  |  | $ | 16,289 |  |  | $ | (48) |  |
| Long-term RPO | 13,964 |  |  | 14,604 |  |  | (640) |  |
| Total | $ | 30,205 |  |  | $ | 30,893 |  |  | $ | (688) |  |

[0000858877-22-000009:mdna:299]
Total remaining performance obligations as of April 30, 2022 decreased 2% compared to the end of fiscal 2021. Remaining performance obligations for product increased 1% compared to the end of fiscal 2021. Remaining performance obligations for service decreased 5%. We expect approximately 54% of total remaining performance obligations to be recognized as revenue over the next 12 months.

[0000858877-22-000009:mdna:300]
[same as prior period, unchanged from 0000858877-22-000004:mdna:301]

[0000858877-22-000009:mdna:301]
|  | April 30,2022 |  | July 31,2021 |  | Increase (Decrease) |
| Product | $ | 9,835 |  |  | $ | 9,416 |  |  | $ | 419 |  |
| Service | 12,458 |  |  | 12,748 |  |  | (290) |  |
| Total | $ | 22,293 |  |  | $ | 22,164 |  |  | $ | 129 |  |
| Reported as: |  |  |  |  |  |
| Current | $ | 12,249 |  |  | $ | 12,148 |  |  | $ | 101 |  |
| Noncurrent | 10,044 |  |  | 10,016 |  |  | 28 |  |
| Total | $ | 22,293 |  |  | $ | 22,164 |  |  | $ | 129 |  |

[0000858877-22-000009:mdna:302]
[same as prior period, unchanged from 0000858877-22-000004:mdna:303]

[0000858877-22-000009:mdna:303]
[same as prior period, unchanged from 0000858877-22-000004:mdna:306]

[0000858877-22-000009:mdna:304]
[same as prior period, unchanged from 0000858877-22-000004:mdna:307]

[0000858877-22-000009:mdna:305]
The income tax payable outstanding as of April 30, 2022 for the U.S. transition tax on accumulated earnings for foreign subsidiaries is $6.2 billion. Approximately $0.7 billion is payable in less than one year; $3.2 billion is payable between 1 to 3 years; and $2.3 billion is payable between 3 to 5 years.

[0000858877-22-000009:mdna:306]
[same as prior period, unchanged from 0000858877-22-000004:mdna:309]

[0000858877-22-000009:mdna:307]
[same as prior period, unchanged from 0000858877-22-000004:mdna:304]

[0000858877-22-000009:mdna:308]
[same as prior period, unchanged from 0000858877-22-000004:mdna:305]

[0000858877-22-000009:mdna:309]
[same as prior period, unchanged from 0000858877-22-000004:mdna:310]

[0000858877-22-000009:mdna:310]
[same as prior period, unchanged from 0000858877-22-000004:mdna:311]

[0000858877-22-000009:mdna:311]
We also have certain funding commitments primarily related to our privately held investments, some of which may be based on the achievement of certain agreed-upon milestones or are required to be funded on demand. The funding commitments were $0.4 billion and $0.2 billion as of April 30, 2022 and July 31, 2021, respectively.

[0000858877-22-000009:mdna:312]
In the ordinary course of business, we have privately held investments and provide financing to certain customers. Certain of these investments are considered to be variable interest entities. We evaluate on an ongoing basis our privately held investments and customer financings, and we have determined that as of April 30, 2022 there were no material unconsolidated variable interest entities.

[0000858877-22-000009:mdna:313]
[same as prior period, unchanged from 0000858877-22-000004:mdna:314]

[0000858877-22-000009:mdna:314]
[same as prior period, unchanged from 0000858877-22-000004:mdna:315]

[0000858877-22-000009:mdna:315]
[same as prior period, unchanged from 0000858877-22-000004:mdna:316]

[0000858877-22-000009:mdna:316]
While the COVID-19 pandemic and the Russia and Ukraine war have not materially impacted our liquidity and capital resources to date, it has led to increased disruption and volatility in capital markets and credit markets. These events and resulting economic uncertainty could adversely affect our liquidity and capital resources in the future. Based on past performance and current expectations, we believe our cash and cash equivalents, investments, cash generated from operations, and ability to access capital markets and committed credit lines will satisfy, through at least the next 12 months, our liquidity requirements, both in total and domestically, including the following: working capital needs (including inventory and other supply related payments), capital expenditures, investment requirements, stock repurchases, cash dividends, contractual obligations, commitments, principal and interest payments on debt, pending acquisitions, future customer financings, and other liquidity requirements associated with our operations. We expect increased payments related to inventory and other supply related payments through at least the next 12 months. There are no other transactions, arrangements, or relationships with unconsolidated entities or other persons that are reasonably likely to materially affect the liquidity and the availability of, as well as our requirements for, capital resources.
