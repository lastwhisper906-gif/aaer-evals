# CSCO notes — 0000858877-22-000009


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000858877-22-000009:notes:1]
[same as prior period, unchanged from 0000858877-22-000004:notes:1]

[0000858877-22-000009:notes:2]
We have prepared the accompanying financial data as of April 30, 2022 and for the third quarter and first nine months of fiscal 2022 and 2021, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (SEC). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (GAAP) have been condensed or omitted pursuant to such rules and regulations. The July 31, 2021 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, we believe that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in our Annual Report on Form 10-K for the fiscal year ended July 31, 2021.

[0000858877-22-000009:notes:3]
The preparation of financial statements and related disclosures in conformity with GAAP requires us to make judgments, assumptions, and estimates that affect the amounts reported in the Consolidated Financial Statements and accompanying notes. The inputs into certain of our judgments, assumptions, and estimates considered the economic implications of the COVID-19 pandemic, including the associated impact of supply constraints, on our critical and significant accounting estimates. The actual results that we experience may differ materially from our estimates. As these events continue, many of our estimates could require increased judgment and carry a higher degree of variability and volatility. As events continue to evolve our estimates may change materially in future periods.

[0000858877-22-000009:notes:4]
In the opinion of management, all normal recurring adjustments necessary to state fairly the consolidated balance sheet as of April 30, 2022, the results of operations, the statements of comprehensive income and the statements of equity for the third quarter and first nine months of fiscal 2022 and 2021, and the statements of cash flows for the first nine months of fiscal 2022 and 2021, as applicable, have been made. The results of operations for the third quarter and first nine months of fiscal 2022 are not necessarily indicative of the operating results for the full fiscal year or any future periods.

[0000858877-22-000009:notes:5]
[same as prior period, unchanged from 0000858877-22-000004:notes:5]

[0000858877-22-000009:notes:6]
Certain reclassifications have been made to the amounts in prior periods in order to conform to the current period’s presentation. We have evaluated subsequent events through the date that the financial statements were issued.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000858877-22-000009:notes:7]
[same as prior period, unchanged from 0000858877-22-000004:notes:7]

[0000858877-22-000009:notes:8]
[same as prior period, unchanged from 0000858877-22-000004:notes:8]

[0000858877-22-000009:notes:9]
[same as prior period, unchanged from 0000858877-22-000004:notes:9]

[0000858877-22-000009:notes:10]
Reference Rate Reform  In March 2020, the FASB issued an accounting standard update and subsequent amendments that provide optional expedients and exceptions to the current guidance on contract modification and hedging relationships to ease the financial reporting burden of the expected market transition from the London InterBank Offered Rate (LIBOR) and other 
interbank offered rates to alternative reference rates. This accounting standard update was effective upon issuance and may be applied prospectively through December 31, 2022. We are currently evaluating the impact of this accounting standard update on our Consolidated Financial Statements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000858877-22-000009:notes:11]
[same as prior period, unchanged from 0000858877-22-000004:notes:11]

[0000858877-22-000009:notes:12]
[same as prior period, unchanged from 0000858877-22-000004:notes:12]

[0000858877-22-000009:notes:13]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of April 30, 2022 and July 31, 2021 was $42 million and $55 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.

[0000858877-22-000009:notes:14]
[same as prior period, unchanged from 0000858877-22-000004:notes:14]

[0000858877-22-000009:notes:15]
[same as prior period, unchanged from 0000858877-22-000004:notes:15]

[0000858877-22-000009:notes:16]
[same as prior period, unchanged from 0000858877-22-000004:notes:16]

[0000858877-22-000009:notes:17]
[same as prior period, unchanged from 0000858877-22-000004:notes:17]

[0000858877-22-000009:notes:18]
[same as prior period, unchanged from 0000858877-22-000004:notes:18]

[0000858877-22-000009:notes:19]
We disaggregate our revenue into groups of similar products and services that depict the nature, amount, and timing of revenue and cash flows for our various offerings. The sales cycle, contractual obligations, customer requirements, and go-to-market strategies differ for each of our product categories, resulting in different economic risk profiles for each category. Effective fiscal 2022, we began reporting our product and service revenue in the following categories: Secure, Agile Networks; Internet for the Future; Collaboration; End-to-End Security; Optimized Application Experiences; Other Products; and Services. This change will better align our product categories with our strategic priorities. The following table presents this disaggregation of revenue (in millions):

[0000858877-22-000009:notes:20]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 30,2022 |  | May 1,2021 |  | April 30,2022 |  | May 1,2021 |
| Product revenue: |  |  |  |  |  |  |  |
| Secure, Agile Networks | $ | 5,869 |  |  | $ | 5,620 |  |  | $ | 17,735 |  |  | $ | 16,543 |  |
| Internet for the Future | 1,324 |  |  | 1,249 |  |  | 4,021 |  |  | 3,121 |  |
| Collaboration | 1,132 |  |  | 1,220 |  |  | 3,308 |  |  | 3,580 |  |
| End-to-End Security | 938 |  |  | 876 |  |  | 2,716 |  |  | 2,559 |  |
| Optimized Application Experiences | 183 |  |  | 170 |  |  | 544 |  |  | 483 |  |
| Other Products | 2 |  |  | 5 |  |  | 7 |  |  | 11 |  |
| Total Product | 9,448 |  |  | 9,139 |  |  | 28,330 |  |  | 26,298 |  |
| Services | 3,387 |  |  | 3,664 |  |  | 10,125 |  |  | 10,394 |  |
| Total | $ | 12,835 |  |  | $ | 12,803 |  |  | $ | 38,455 |  |  | $ | 36,692 |  |

[0000858877-22-000009:notes:21]
[same as prior period, unchanged from 0000858877-22-000004:notes:21]

[0000858877-22-000009:notes:22]
[same as prior period, unchanged from 0000858877-22-000004:notes:22]

[0000858877-22-000009:notes:23]
[same as prior period, unchanged from 0000858877-22-000004:notes:25]

[0000858877-22-000009:notes:24]
Collaboration consists of our Collaboration Devices, Meetings, Calling and contact center offerings. These products consist primarily of software offerings, including software licenses and SaaS, as well as hardware. Our perpetual software and hardware in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

[0000858877-22-000009:notes:25]
End-to-End Security consists of our overall security offerings. These products consist of both hardware and software offerings, including software licenses and SaaS. Updates and upgrades for the term software licenses are critical for our software to perform its intended commercial purpose because of the continuous need for our software to secure our customers’ network environments against frequent threats. Therefore, security software licenses are generally represented by a single distinct performance obligation with revenue recognized ratably over the contract term. Our hardware and perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. SaaS arrangements

[0000858877-22-000009:notes:26]
in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

[0000858877-22-000009:notes:27]
[same as prior period, unchanged from 0000858877-22-000004:notes:26]

[0000858877-22-000009:notes:28]
[same as prior period, unchanged from 0000858877-22-000004:notes:27]

[0000858877-22-000009:notes:29]
[same as prior period, unchanged from 0000858877-22-000004:notes:28]

[0000858877-22-000009:notes:30]
[same as prior period, unchanged from 0000858877-22-000004:notes:29]

[0000858877-22-000009:notes:31]
[same as prior period, unchanged from 0000858877-22-000004:notes:30]

[0000858877-22-000009:notes:32]
Accounts receivable, net was $5.8 billion as of each of April 30, 2022 and July 31, 2021, as reported on the Consolidated Balance Sheets.

[0000858877-22-000009:notes:33]
[same as prior period, unchanged from 0000858877-22-000004:notes:32]

[0000858877-22-000009:notes:34]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 30, 2022 |  | May 1, 2021 |  | April 30, 2022 |  | May 1, 2021 |
| Allowance for credit loss at beginning of period | $ | 70 |  |  | $ | 102 |  |  | $ | 109 |  |  | $ | 143 |  |
| Provisions (benefits) | 17 |  |  | 16 |  |  | 53 |  |  | 15 |  |
| Recoveries (write-offs), net | (9) |  |  | (8) |  |  | (75) |  |  | (22) |  |
| Foreign exchange and other | — |  |  | — |  |  | (9) |  |  | (26) |  |
| Allowance for credit loss at end of period | $ | 78 |  |  | $ | 110 |  |  | $ | 78 |  |  | $ | 110 |  |

[0000858877-22-000009:notes:35]
[same as prior period, unchanged from 0000858877-22-000004:notes:34]

[0000858877-22-000009:notes:36]
[same as prior period, unchanged from 0000858877-22-000004:notes:35]

[0000858877-22-000009:notes:37]
|  | April 30,2022 |  | July 31,2021 |
| 1 to 4 | $ | 422 |  |  | $ | 521 |  |
| 5 to 6 | 807 |  |  | 770 |  |
| 7 and Higher | 169 |  |  | 166 |  |
| Total | $ | 1,398 |  |  | $ | 1,457 |  |

[0000858877-22-000009:notes:38]
Contract assets consist of unbilled receivables and are recorded when revenue is recognized in advance of scheduled billings to our customers. These amounts are primarily related to software and service arrangements where transfer of control has occurred but we have not yet invoiced. Our contract assets for these unbilled receivables, net of allowances, was $1.3 billion and $1.4 billion as of April 30, 2022 and July 31, 2021, respectively, and were included in other current assets and other assets.

[0000858877-22-000009:notes:39]
Contract liabilities consist of deferred revenue. Deferred revenue was $22.3 billion as of April 30, 2022 compared to $22.2 billion as of July 31, 2021. We recognized approximately $2.5 billion and $9.9 billion of revenue during the third quarter and first nine months of fiscal 2022, respectively, that was included in the deferred revenue balance at July 31, 2021. 
(c)Capitalized Contract Acquisition CostsWe capitalize direct and incremental costs incurred to acquire contracts, primarily sales commissions, for which the associated revenue is expected to be recognized in future periods. We incur these costs in connection with both initial contracts and renewals. These costs are initially deferred and typically amortized over the term of the customer contract which corresponds to the period of benefit. Deferred sales commissions were $1.0 billion and $967 million as of April 30, 2022 and July 31, 2021, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $175 million and $492 million for the third quarter and first nine months of fiscal 2022, respectively, and $134 million and $386 million for the corresponding periods of fiscal 2021, respectively, and was included in sales and marketing expenses.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0000858877-22-000009:notes:40]
[same as prior period, unchanged from 0000858877-22-000004:notes:41]


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0000858877-22-000009:notes:41]
[same as prior period, unchanged from 0000858877-22-000004:notes:42]

[0000858877-22-000009:notes:42]
[same as prior period, unchanged from 0000858877-22-000004:notes:43]

[0000858877-22-000009:notes:43]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 30,2022 |  | May 1,2021 |  | April 30,2022 |  | May 1,2021 |
| Revenue: |  |  |  |  |  |  |  |
| Secure, Agile Networks | $ | 5,869 |  |  | $ | 5,620 |  |  | $ | 17,735 |  |  | $ | 16,543 |  |
| Internet for the Future | 1,324 |  |  | 1,249 |  |  | 4,021 |  |  | 3,121 |  |
| Collaboration | 1,132 |  |  | 1,220 |  |  | 3,308 |  |  | 3,580 |  |
| End-to-End Security | 938 |  |  | 876 |  |  | 2,716 |  |  | 2,559 |  |
| Optimized Application Experiences | 183 |  |  | 170 |  |  | 544 |  |  | 483 |  |
| Other Products | 2 |  |  | 5 |  |  | 7 |  |  | 11 |  |
| Total Product | 9,448 |  |  | 9,139 |  |  | 28,330 |  |  | 26,298 |  |
| Services | 3,387 |  |  | 3,664 |  |  | 10,125 |  |  | 10,394 |  |
| Total | $ | 12,835 |  |  | $ | 12,803 |  |  | $ | 38,455 |  |  | $ | 36,692 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000858877-22-000009:notes:44]
Acquisitions and Divestitures
We completed three acquisitions during the first nine months of fiscal 2022. A summary of the allocation of the total purchase consideration is presented as follows (in millions):

[0000858877-22-000009:notes:45]
|  | Purchase Consideration |  | Net Tangible Assets Acquired (Liabilities Assumed) |  | Purchased Intangible Assets |  | Goodwill |
| Total acquisitions (three in total) | $ | 364 |  |  | $ | 12 |  |  | $ | 20 |  |  | $ | 332 |  |

[0000858877-22-000009:notes:46]
The total purchase consideration related to our acquisitions completed during the first nine months of fiscal 2022 consisted of cash consideration and vested share-based awards assumed. The total cash and cash equivalents acquired from these acquisitions was approximately $7 million. Total transaction costs related to acquisition and divestiture activities were $44 million and $30 million for the first nine months of fiscal 2022 and 2021, respectively. These transaction costs were expensed as incurred in general and administrative expenses (“G&A”) in the Consolidated Statements of Operations.

[0000858877-22-000009:notes:47]
The goodwill generated from acquisitions completed during the first nine months of fiscal 2022 is primarily related to expected synergies. The goodwill is generally not deductible for income tax purposes.
The Consolidated Financial Statements include the operating results of each acquisition from the date of acquisition. Pro forma results of operations and the revenue and net income subsequent to the acquisition date for the acquisitions completed during the first nine months of fiscal 2022 have not been presented because the effects of the acquisitions, individually and in the aggregate, were not material to our financial results.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000858877-22-000009:notes:48]
[same as prior period, unchanged from 0000858877-22-000004:notes:49]

[0000858877-22-000009:notes:49]
The following table presents the goodwill allocated to our reportable segments as of April 30, 2022 and during the first nine months of fiscal 2022 (in millions):

[0000858877-22-000009:notes:50]
|  | Balance at July 31, 2021 |  | Acquisitions & Divestitures |  | Other |  | Balance at April 30, 2022 |
| Americas | $ | 23,673 |  |  | $ | 222 |  |  | $ | 79 |  |  | $ | 23,974 |  |
| EMEA | 9,094 |  |  | 83 |  |  | (80) |  |  | 9,097 |  |
| APJC | 5,401 |  |  | 27 |  |  | (47) |  |  | 5,381 |  |
| Total | $ | 38,168 |  |  | $ | 332 |  |  | $ | (48) |  |  | $ | 38,452 |  |

[0000858877-22-000009:notes:51]
“Other” in the table above consists of foreign currency translation as well as purchase accounting adjustments.

[0000858877-22-000009:notes:52]
[same as prior period, unchanged from 0000858877-22-000004:notes:53]

[0000858877-22-000009:notes:53]
The following table presents details of our intangible assets acquired through acquisitions completed during the first nine months of fiscal 2022 (in millions, except years):

[0000858877-22-000009:notes:54]
|  | FINITE LIVES |  | INDEFINITE LIVES |  | TOTAL |
|  | TECHNOLOGY |  | CUSTOMERRELATIONSHIPS |  | OTHER |  | IPR&D |  |
|  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Amount |  | Amount |
| Total acquisitions (three in total) | 2.7 |  | $ | 16 |  |  | 2.0 |  | $ | 4 |  |  | — |  |  | $ | — |  |  | $ | — |  |  | $ | 20 |  |

[0000858877-22-000009:notes:55]
[same as prior period, unchanged from 0000858877-22-000004:notes:56]

[0000858877-22-000009:notes:56]
| April 30, 2022 |  | Gross |  | Accumulated Amortization |  | Net |
| Purchased intangible assets with finite lives: |  |  |  |  |  |  |
| Technology |  | $ | 2,837 |  |  | $ | (1,140) |  |  | $ | 1,697 |  |
| Customer relationships |  | 1,355 |  |  | (701) |  |  | 654 |  |
| Other |  | 54 |  |  | (24) |  |  | 30 |  |
| Total purchased intangible assets with finite lives |  | 4,246 |  |  | (1,865) |  |  | 2,381 |  |
| In-process research and development, with indefinite lives |  | 430 |  |  | — |  |  | 430 |  |
| Total |  | $ | 4,676 |  |  | $ | (1,865) |  |  | $ | 2,811 |  |

[0000858877-22-000009:notes:57]
[same as prior period, unchanged from 0000858877-22-000004:notes:58]

[0000858877-22-000009:notes:58]
[same as prior period, unchanged from 0000858877-22-000004:notes:59]

[0000858877-22-000009:notes:59]
Impairment charges related to purchased intangible assets for the third quarter and first nine months of fiscal 2022 were $15 million. Impairment charges are primarily a result of declines in estimated fair values of certain purchased intangible assets resulting from the reduction or elimination of expected future cash flows associated with certain of our technology and in-process research and development (IPR&D) intangible assets.

[0000858877-22-000009:notes:60]
[same as prior period, unchanged from 0000858877-22-000004:notes:60]

[0000858877-22-000009:notes:61]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 30, 2022 |  | May 1, 2021 |  | April 30, 2022 |  | May 1, 2021 |
| Amortization of purchased intangible assets: |  |  |  |  |  |  |  |
| Cost of sales | $ | 180 |  |  | $ | 187 |  |  | $ | 583 |  |  | $ | 513 |  |
| Operating expenses | 92 |  |  | 61 |  |  | 255 |  |  | 136 |  |
| Total | $ | 272 |  |  | $ | 248 |  |  | $ | 838 |  |  | $ | 649 |  |

[0000858877-22-000009:notes:62]
The estimated future amortization expense of purchased intangible assets with finite lives as of April 30, 2022 is as follows (in millions):

[0000858877-22-000009:notes:63]
| Fiscal Year | Amount |
| 2022 (remaining three months) | $ | 238 |  |
| 2023 | $ | 902 |  |
| 2024 | $ | 774 |  |
| 2025 | $ | 404 |  |
| 2026 | $ | 61 |  |
| Thereafter | $ | 2 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000858877-22-000009:notes:64]
[same as prior period, unchanged from 0000858877-22-000004:notes:64]

[0000858877-22-000009:notes:65]
[same as prior period, unchanged from 0000858877-22-000004:notes:65]

[0000858877-22-000009:notes:66]
[same as prior period, unchanged from 0000858877-22-000004:notes:66]

[0000858877-22-000009:notes:67]
[same as prior period, unchanged from 0000858877-22-000004:notes:67]

[0000858877-22-000009:notes:68]
|  |  | FISCAL 2020 AND PRIOR PLANS |  | FISCAL 2021 PLAN |  |  |
|  |  | EmployeeSeverance |  | Other |  | EmployeeSeverance |  | Other |  | Total |
| Liability as of July 31, 2021 |  | $ | — |  |  | $ | 10 |  |  | $ | 16 |  |  | $ | 8 |  |  | $ | 34 |  |
| Charges |  | — |  |  | (5) |  |  | 10 |  |  | 3 |  |  | 8 |  |
| Cash payments |  | — |  |  | (1) |  |  | (21) |  |  | (1) |  |  | (23) |  |
| Non-cash items |  | — |  |  | — |  |  | — |  |  | (5) |  |  | (5) |  |
| Liability as of April 30, 2022 |  | $ | — |  |  | $ | 4 |  |  | $ | 5 |  |  | $ | 5 |  |  | $ | 14 |  |

[0000858877-22-000009:notes:69]
|  |  | FISCAL 2020 AND PRIOR PLANS |  | FISCAL 2021 PLAN |  |  |
|  |  | EmployeeSeverance |  | Other |  | Employee Severance |  | Other |  | Total |
| Liability as of July 25, 2020 |  | $ | 58 |  |  | $ | 14 |  |  | $ | — |  |  | $ | — |  |  | $ | 72 |  |
| Charges |  | — |  |  | 9 |  |  | 828 |  |  | 41 |  |  | 878 |  |
| Cash payments |  | (58) |  |  | (5) |  |  | (801) |  |  | (4) |  |  | (868) |  |
| Non-cash items |  | — |  |  | (1) |  |  | — |  |  | (31) |  |  | (32) |  |
| Liability as of May 1, 2021 |  | $ | — |  |  | $ | 17 |  |  | $ | 27 |  |  | $ | 6 |  |  | $ | 50 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000858877-22-000009:notes:70]
[same as prior period, unchanged from 0000858877-22-000004:notes:70]

[0000858877-22-000009:notes:71]
Cash, Cash Equivalents, Restricted Cash and Restricted Cash Equivalents

[0000858877-22-000009:notes:72]
|  |  | April 30,2022 |  | July 31,2021 |
| Cash and cash equivalents |  | $ | 6,952 |  |  | $ | 9,175 |  |
| Restricted cash and restricted cash equivalents included in other current assets |  | 7 |  |  | 14 |  |
| Restricted cash and restricted cash equivalents included in other assets |  | 750 |  |  | 753 |  |
| Total |  | $ | 7,709 |  |  | $ | 9,942 |  |

[0000858877-22-000009:notes:73]
Our restricted cash equivalents are funds primarily related to contractual obligations with suppliers.

[0000858877-22-000009:notes:74]
[same as prior period, unchanged from 0000858877-22-000004:notes:74]

[0000858877-22-000009:notes:75]
|  |  | April 30,2022 |  | July 31,2021 |
| Raw materials |  | $ | 1,414 |  |  | $ | 801 |  |
| Work in process |  | 165 |  |  | 54 |  |
| Finished goods: |  |  |  |  |
| Deferred cost of sales |  | 80 |  |  | 97 |  |
| Manufactured finished goods |  | 462 |  |  | 422 |  |
| Total finished goods |  | 542 |  |  | 519 |  |
| Service-related spares |  | 103 |  |  | 174 |  |
| Demonstration systems |  | 7 |  |  | 11 |  |
| Total |  | $ | 2,231 |  |  | $ | 1,559 |  |

[0000858877-22-000009:notes:76]
[same as prior period, unchanged from 0000858877-22-000004:notes:76]

[0000858877-22-000009:notes:77]
|  |  | April 30,2022 |  | July 31,2021 |
| Gross property and equipment: |  |  |  |  |
| Land, buildings, and building and leasehold improvements |  | $ | 4,243 |  |  | $ | 4,304 |  |
| Computer equipment and related software |  | 834 |  |  | 858 |  |
| Production, engineering, and other equipment |  | 4,733 |  |  | 5,106 |  |
| Operating lease assets |  | 205 |  |  | 273 |  |
| Furniture, fixtures and other |  | 345 |  |  | 377 |  |
| Total gross property and equipment |  | 10,360 |  |  | 10,918 |  |
| Less: accumulated depreciation and amortization |  | (8,314) |  |  | (8,580) |  |
| Total |  | $ | 2,046 |  |  | $ | 2,338 |  |

[0000858877-22-000009:notes:78]
Remaining Performance Obligations (RPO)

[0000858877-22-000009:notes:79]
|  |  | April 30,2022 |  | July 31,2021 |
| Product |  | $ | 13,416 |  |  | $ | 13,270 |  |
| Service |  | 16,789 |  |  | 17,623 |  |
| Total |  | $ | 30,205 |  |  | $ | 30,893 |  |
| Short-term RPO |  | $ | 16,241 |  |  | $ | 16,289 |  |
| Long-term RPO |  | 13,964 |  |  | 14,604 |  |
| Total |  | $ | 30,205 |  |  | $ | 30,893 |  |
| Amount to be recognized as revenue over next 12 months |  | 54 | % |  | 53 | % |
| Deferred revenue |  | $ | 22,293 |  |  | $ | 22,164 |  |
| Unbilled contract revenue |  | 7,912 |  |  | 8,729 |  |
| Total |  | $ | 30,205 |  |  | $ | 30,893 |  |

[0000858877-22-000009:notes:80]
Unbilled contract revenue represents noncancelable contracts for which we have not invoiced, have an obligation to perform, and revenue has not yet been recognized in the financial statements.

[0000858877-22-000009:notes:81]
[same as prior period, unchanged from 0000858877-22-000004:notes:81]

[0000858877-22-000009:notes:82]
|  |  | April 30,2022 |  | July 31,2021 |
| Product |  | $ | 9,835 |  |  | $ | 9,416 |  |
| Service |  | 12,458 |  |  | 12,748 |  |
| Total |  | $ | 22,293 |  |  | $ | 22,164 |  |
| Reported as: |  |  |  |  |
| Current |  | $ | 12,249 |  |  | $ | 12,148 |  |
| Noncurrent |  | 10,044 |  |  | 10,016 |  |
| Total |  | $ | 22,293 |  |  | $ | 22,164 |  |


## us-gaap:LessorSalesTypeLeasesTextBlock

[0000858877-22-000009:notes:83]
Leases 
(a)Lessee Arrangements

[0000858877-22-000009:notes:84]
The following table presents our operating lease balances (in millions):

[0000858877-22-000009:notes:85]
|  | Balance Sheet Line Item |  | April 30, 2022 |  | July 31, 2021 |
| Operating lease right-of-use assets | Other assets |  | $ | 1,024 |  |  | $ | 1,095 |  |
| Operating lease liabilities | Other current liabilities |  | $ | 334 |  |  | $ | 337 |  |
| Operating lease liabilities | Other long-term liabilities |  | 739 |  |  | 831 |  |
| Total operating lease liabilities |  |  | $ | 1,073 |  |  | $ | 1,168 |  |

[0000858877-22-000009:notes:86]
The components of our lease expenses were as follows (in millions):

[0000858877-22-000009:notes:87]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 30, 2022 |  | May 1, 2021 |  | April 30, 2022 |  | May 1, 2021 |
| Operating lease expense | $ | 99 |  |  | $ | 105 |  |  | $ | 292 |  |  | $ | 306 |  |
| Short-term lease expense | 17 |  |  | 14 |  |  | 49 |  |  | 49 |  |
| Variable lease expense | 37 |  |  | 42 |  |  | 127 |  |  | 131 |  |
| Total lease expense | $ | 153 |  |  | $ | 161 |  |  | $ | 468 |  |  | $ | 486 |  |

[0000858877-22-000009:notes:88]
Supplemental information related to our operating leases is as follows (in millions):

[0000858877-22-000009:notes:89]
|  | Nine Months Ended |
|  | April 30, 2022 |  | May 1, 2021 |
| Cash paid for amounts included in the measurement of lease liabilities — operating cash flows | $ | 306 |  |  | $ | 306 |  |
| Right-of-use assets obtained in exchange for operating leases liabilities | $ | 237 |  |  | $ | 270 |  |

[0000858877-22-000009:notes:90]
The weighted-average lease term was 4.6 years and 5.2 years as of April 30, 2022 and July 31, 2021, respectively. The weighted-average discount rate was 1.8% and 1.7% as of April 30, 2022 and July 31, 2021, respectively.

[0000858877-22-000009:notes:91]
The maturities of our operating leases (undiscounted) as of April 30, 2022 are as follows (in millions):

[0000858877-22-000009:notes:92]
| Fiscal Year | Amount |
| 2022 (remaining three months) | $ | 99 |  |
| 2023 | 328 |  |
| 2024 | 242 |  |
| 2025 | 166 |  |
| 2026 | 92 |  |
| Thereafter | 216 |  |
| Total lease payments | 1,143 |  |
| Less interest | (70) |  |
| Total | $ | 1,073 |  |

[0000858877-22-000009:notes:93]
(b)Lessor Arrangements

[0000858877-22-000009:notes:94]
Our leases primarily represent sales-type leases with terms of four years on average. We provide leasing of our equipment and complementary third-party products primarily through our channel partners and distributors, for which the income arising from these leases is recognized through interest income. Interest income for the third quarter and first nine months of fiscal 2022 was $13 million and $42 million, respectively, and $19 million and $59 million for the corresponding periods of fiscal 2021, respectively, and was included in interest income in the Consolidated Statement of Operations. The net investment of our lease receivables is measured at the commencement date as the gross lease receivable, residual value less unearned income and allowance for credit loss. For additional information, see Note 9.

[0000858877-22-000009:notes:95]
Future minimum lease payments on our lease receivables as of April 30, 2022 are summarized as follows (in millions):

[0000858877-22-000009:notes:96]
| Fiscal Year | Amount |
| 2022 (remaining three months) | $ | 249 |  |
| 2023 | 502 |  |
| 2024 | 317 |  |
| 2025 | 154 |  |
| 2026 | 65 |  |
| Thereafter | 17 |  |
| Total | 1,304 |  |
| Less: Present value of lease payments | 1,245 |  |
| Unearned income | $ | 59 |  |

[0000858877-22-000009:notes:97]
Actual cash collections may differ from the contractual maturities due to early customer buyouts, refinancings, or defaults.

[0000858877-22-000009:notes:98]
We provide financing of certain equipment through operating leases, and the amounts are included in property and equipment in the Consolidated Balance Sheets. Amounts relating to equipment on operating lease assets held by us and the associated accumulated depreciation are summarized as follows (in millions):

[0000858877-22-000009:notes:99]
|  | April 30, 2022 |  | July 31, 2021 |
| Operating lease assets | $ | 205 |  |  | $ | 273 |  |
| Accumulated depreciation | (119) |  |  | (165) |  |
| Operating lease assets, net | $ | 86 |  |  | $ | 108 |  |

[0000858877-22-000009:notes:100]
Our operating lease income for the third quarter and first nine months of fiscal 2022 was $26 million and $87 million, respectively, and $36 million and $119 million for the corresponding periods of fiscal 2021, respectively, and was included in product revenue in the Consolidated Statement of Operations.

[0000858877-22-000009:notes:101]
Minimum future rentals on noncancelable operating leases as of April 30, 2022 are summarized as follows (in millions):

[0000858877-22-000009:notes:102]
| Fiscal Year | Amount |
| 2022 (remaining three months) | $ | 11 |  |
| 2023 | 32 |  |
| 2024 | 15 |  |
| 2025 | 4 |  |
| Total | $ | 62 |  |


## us-gaap:FinancingReceivablesTextBlock

[0000858877-22-000009:notes:103]
[same as prior period, unchanged from 0000858877-22-000004:notes:103]

[0000858877-22-000009:notes:104]
[same as prior period, unchanged from 0000858877-22-000004:notes:104]

[0000858877-22-000009:notes:105]
[same as prior period, unchanged from 0000858877-22-000004:notes:105]

[0000858877-22-000009:notes:106]
| April 30, 2022 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Gross | $ | 1,304 |  |  | $ | 4,509 |  |  | $ | 2,051 |  |  | $ | 7,864 |  |
| Residual value | 82 |  |  | — |  |  | — |  |  | 82 |  |
| Unearned income | (59) |  |  | — |  |  | — |  |  | (59) |  |
| Allowance for credit loss | (25) |  |  | (97) |  |  | (2) |  |  | (124) |  |
| Total, net | $ | 1,302 |  |  | $ | 4,412 |  |  | $ | 2,049 |  |  | $ | 7,763 |  |
| Reported as: |  |  |  |  |  |  |  |
| Current | $ | 623 |  |  | $ | 2,144 |  |  | $ | 1,037 |  |  | $ | 3,804 |  |
| Noncurrent | 679 |  |  | 2,268 |  |  | 1,012 |  |  | 3,959 |  |
| Total, net | $ | 1,302 |  |  | $ | 4,412 |  |  | $ | 2,049 |  |  | $ | 7,763 |  |

[0000858877-22-000009:notes:107]
[same as prior period, unchanged from 0000858877-22-000004:notes:107]

[0000858877-22-000009:notes:108]
[same as prior period, unchanged from 0000858877-22-000004:notes:108]

[0000858877-22-000009:notes:109]
[same as prior period, unchanged from 0000858877-22-000004:notes:109]

[0000858877-22-000009:notes:110]
| April 30, 2022 |  |  | Fiscal Year |  | Nine Months Ended |  |  |
| Internal Credit Risk Rating | Prior |  | July 28, 2018 |  | July 27, 2019 |  | July 25, 2020 |  | July 31, 2021 |  | April 30, 2022 |  | Total |
| Lease Receivables: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | 3 |  |  | $ | 38 |  |  | $ | 90 |  |  | $ | 144 |  |  | $ | 192 |  |  | $ | 152 |  |  | $ | 619 |  |
| 5 to 6 | 3 |  |  | 18 |  |  | 83 |  |  | 176 |  |  | 183 |  |  | 129 |  |  | 592 |  |
| 7 and Higher | 1 |  |  | 1 |  |  | 5 |  |  | 13 |  |  | 3 |  |  | 11 |  |  | 34 |  |
| Total Lease Receivables | $ | 7 |  |  | $ | 57 |  |  | $ | 178 |  |  | $ | 333 |  |  | $ | 378 |  |  | $ | 292 |  |  | $ | 1,245 |  |
| Loan Receivables: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | 6 |  |  | $ | 63 |  |  | $ | 173 |  |  | $ | 565 |  |  | $ | 1,018 |  |  | $ | 979 |  |  | $ | 2,804 |  |
| 5 to 6 | 2 |  |  | 22 |  |  | 94 |  |  | 289 |  |  | 547 |  |  | 637 |  |  | 1,591 |  |
| 7 and Higher | 1 |  |  | 1 |  |  | 26 |  |  | 40 |  |  | 36 |  |  | 10 |  |  | 114 |  |
| Total Loan Receivables | $ | 9 |  |  | $ | 86 |  |  | $ | 293 |  |  | $ | 894 |  |  | $ | 1,601 |  |  | $ | 1,626 |  |  | $ | 4,509 |  |
| Financed Service Contracts: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | 1 |  |  | $ | 5 |  |  | $ | 52 |  |  | $ | 99 |  |  | $ | 624 |  |  | $ | 567 |  |  | $ | 1,348 |  |
| 5 to 6 | 1 |  |  | 12 |  |  | 47 |  |  | 135 |  |  | 292 |  |  | 202 |  |  | 689 |  |
| 7 and Higher | — |  |  | — |  |  | 3 |  |  | 5 |  |  | 3 |  |  | 3 |  |  | 14 |  |
| Total Financed Service Contracts | $ | 2 |  |  | $ | 17 |  |  | $ | 102 |  |  | $ | 239 |  |  | $ | 919 |  |  | $ | 772 |  |  | $ | 2,051 |  |
| Total | $ | 18 |  |  | $ | 160 |  |  | $ | 573 |  |  | $ | 1,466 |  |  | $ | 2,898 |  |  | $ | 2,690 |  |  | $ | 7,805 |  |

[0000858877-22-000009:notes:111]
[same as prior period, unchanged from 0000858877-22-000004:notes:111]

[0000858877-22-000009:notes:112]
The following tables present the aging analysis of gross receivables as of April 30, 2022 and July 31, 2021 (in millions):

[0000858877-22-000009:notes:113]
|  | DAYS PAST DUE (INCLUDES BILLED AND UNBILLED) |  |  |  |  |  |  |  |  |  |  |
| April 30, 2022 | 31-60 |  | 61-90 |  | 91+ |  | TotalPast Due |  | Current |  | Total |  | 120+ Still Accruing |  | NonaccrualFinancingReceivables |  | ImpairedFinancingReceivables |
| Lease receivables | $ | 26 |  |  | $ | 10 |  |  | $ | 24 |  |  | $ | 60 |  |  | $ | 1,185 |  |  | $ | 1,245 |  |  | $ | 7 |  |  | $ | 14 |  |  | $ | 14 |  |
| Loan receivables | 87 |  |  | 38 |  |  | 25 |  |  | 150 |  |  | 4,359 |  |  | 4,509 |  |  | 6 |  |  | 53 |  |  | 53 |  |
| Financed service contracts | 45 |  |  | 16 |  |  | 23 |  |  | 84 |  |  | 1,967 |  |  | 2,051 |  |  | 5 |  |  | 2 |  |  | 2 |  |
| Total | $ | 158 |  |  | $ | 64 |  |  | $ | 72 |  |  | $ | 294 |  |  | $ | 7,511 |  |  | $ | 7,805 |  |  | $ | 18 |  |  | $ | 69 |  |  | $ | 69 |  |

[0000858877-22-000009:notes:114]
[same as prior period, unchanged from 0000858877-22-000004:notes:114]

[0000858877-22-000009:notes:115]
[same as prior period, unchanged from 0000858877-22-000004:notes:115]

[0000858877-22-000009:notes:116]
[same as prior period, unchanged from 0000858877-22-000004:notes:116]

[0000858877-22-000009:notes:117]
[same as prior period, unchanged from 0000858877-22-000004:notes:117]

[0000858877-22-000009:notes:118]
| Three months ended April 30, 2022 | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Allowance for credit loss as of January 29, 2022 | $ | 27 |  |  | $ | 67 |  |  | $ | 3 |  |  | $ | 97 |  |
| Provisions (benefits) | (2) |  |  | 27 |  |  | (1) |  |  | 24 |  |
| Other | — |  |  | 3 |  |  | — |  |  | 3 |  |
| Allowance for credit loss as of April 30, 2022 | $ | 25 |  |  | $ | 97 |  |  | $ | 2 |  |  | $ | 124 |  |

[0000858877-22-000009:notes:119]
| Three Months Ended May 1, 2021 | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Allowance for credit loss as of January 23, 2021 | $ | 43 |  |  | $ | 96 |  |  | $ | 9 |  |  | $ | 148 |  |
| Provisions (benefits) | (2) |  |  | (4) |  |  | (4) |  |  | (10) |  |
| Recoveries (write-offs), net | (1) |  |  | (1) |  |  | — |  |  | (2) |  |
| Allowance for credit loss as of May 1, 2021 | $ | 40 |  |  | $ | 91 |  |  | $ | 5 |  |  | $ | 136 |  |

[0000858877-22-000009:notes:120]
| Nine months ended April 30, 2022 | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Allowance for credit loss as of July 31, 2021 | $ | 38 |  |  | $ | 86 |  |  | $ | 3 |  |  | $ | 127 |  |
| Provisions (benefits) | (11) |  |  | 8 |  |  | (1) |  |  | (4) |  |
| Recoveries (write-offs), net | (2) |  |  | — |  |  | — |  |  | (2) |  |
| Other | — |  |  | 3 |  |  | — |  |  | 3 |  |
| Allowance for credit loss as of April 30, 2022 | $ | 25 |  |  | $ | 97 |  |  | $ | 2 |  |  | $ | 124 |  |

[0000858877-22-000009:notes:121]
| Nine months ended May 1, 2021 | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts |  | Total |
| Allowance for credit loss as of July 25, 2020 | $ | 48 |  |  | $ | 81 |  |  | $ | 9 |  |  | $ | 138 |  |
| Provisions (benefits) | (9) |  |  | (7) |  |  | (3) |  |  | (19) |  |
| Recoveries (write-offs), net | (1) |  |  | (1) |  |  | — |  |  | (2) |  |
| Other | 2 |  |  | 18 |  |  | (1) |  |  | 19 |  |
| Allowance for credit loss as of May 1, 2021 | $ | 40 |  |  | $ | 91 |  |  | $ | 5 |  |  | $ | 136 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000858877-22-000009:notes:122]
Available-for-Sale Debt and Equity Investments
(a)Summary of Available-for-Sale Debt Investments

[0000858877-22-000009:notes:123]
The following tables summarize our available-for-sale debt investments (in millions):

[0000858877-22-000009:notes:124]
| April 30, 2022 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 1,346 |  |  | $ | — |  |  | $ | (46) |  |  | $ | 1,300 |  |
| U.S. government agency securities | 150 |  |  | — |  |  | (4) |  |  | 146 |  |
| Non-U.S. government and agency securities | 171 |  |  | — |  |  | — |  |  | 171 |  |
| Corporate debt securities | 8,770 |  |  | 5 |  |  | (296) |  |  | 8,479 |  |
| U.S. agency mortgage-backed securities | 2,234 |  |  | — |  |  | (176) |  |  | 2,058 |  |
| Commercial paper | 548 |  |  | — |  |  | — |  |  | 548 |  |
| Certificates of deposit | 212 |  |  | — |  |  | — |  |  | 212 |  |
| Total | $ | 13,431 |  |  | $ | 5 |  |  | $ | (522) |  |  | $ | 12,914 |  |

[0000858877-22-000009:notes:125]
| July 31, 2021 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 1,773 |  |  | $ | 21 |  |  | $ | — |  |  | $ | 1,794 |  |
| U.S. government agency securities | 152 |  |  | — |  |  | — |  |  | 152 |  |
| Non-U.S. government and agency securities | 3 |  |  | — |  |  | — |  |  | 3 |  |
| Corporate debt securities | 8,727 |  |  | 213 |  |  | (30) |  |  | 8,910 |  |
| U.S. agency mortgage-backed securities | 2,838 |  |  | 34 |  |  | (10) |  |  | 2,862 |  |
| Commercial paper | 1,190 |  |  | — |  |  | — |  |  | 1,190 |  |
| Certificates of deposit | 295 |  |  | — |  |  | — |  |  | 295 |  |
| Total | $ | 14,978 |  |  | $ | 268 |  |  | $ | (40) |  |  | $ | 15,206 |  |

[0000858877-22-000009:notes:126]
The following table presents the gross realized gains and gross realized losses related to available-for-sale debt investments (in millions):

[0000858877-22-000009:notes:127]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 30, 2022 |  | May 1, 2021 |  | April 30, 2022 |  | May 1, 2021 |
| Gross realized gains | $ | 8 |  |  | $ | 24 |  |  | $ | 27 |  |  | $ | 48 |  |
| Gross realized losses | (6) |  |  | (2) |  |  | (9) |  |  | (2) |  |
| Total | $ | 2 |  |  | $ | 22 |  |  | $ | 18 |  |  | $ | 46 |  |

[0000858877-22-000009:notes:128]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at April 30, 2022 and July 31, 2021 (in millions):

[0000858877-22-000009:notes:129]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| April 30, 2022 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 1,185 |  |  | $ | (43) |  |  | $ | 96 |  |  | $ | (3) |  |  | $ | 1,281 |  |  | $ | (46) |  |
| U.S. government agency securities | 121 |  |  | (2) |  |  | 24 |  |  | (2) |  |  | 145 |  |  | (4) |  |
| Non-U.S. government and agency securities | 171 |  |  | — |  |  | — |  |  | — |  |  | 171 |  |  | — |  |
| Corporate debt securities | 6,185 |  |  | (225) |  |  | 367 |  |  | (35) |  |  | 6,552 |  |  | (260) |  |
| U.S. agency mortgage-backed securities | 1,505 |  |  | (118) |  |  | 547 |  |  | (58) |  |  | 2,052 |  |  | (176) |  |
| Total | $ | 9,167 |  |  | $ | (388) |  |  | $ | 1,034 |  |  | $ | (98) |  |  | $ | 10,201 |  |  | $ | (486) |  |

[0000858877-22-000009:notes:130]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 31, 2021 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 468 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 468 |  |  | $ | — |  |
| U.S. government agency securities | 26 |  |  | — |  |  | — |  |  | — |  |  | 26 |  |  | — |  |
| Corporate debt securities | 1,086 |  |  | (5) |  |  | 6 |  |  | — |  |  | 1,092 |  |  | (5) |  |
| U.S. agency mortgage-backed securities | 1,293 |  |  | (10) |  |  | 13 |  |  | — |  |  | 1,306 |  |  | (10) |  |
| Commercial paper | 37 |  |  | — |  |  | — |  |  | — |  |  | 37 |  |  | — |  |
| Total | $ | 2,910 |  |  | $ | (15) |  |  | $ | 19 |  |  | $ | — |  |  | $ | 2,929 |  |  | $ | (15) |  |

[0000858877-22-000009:notes:131]
The following table summarizes the maturities of our available-for-sale debt investments as of April 30, 2022 (in millions):

[0000858877-22-000009:notes:132]
|  | Amortized Cost |  | Fair Value |
| Within 1 year | $ | 3,431 |  |  | $ | 3,397 |  |
| After 1 year through 5 years | 7,619 |  |  | 7,319 |  |
| After 5 years through 10 years | 146 |  |  | 139 |  |
| After 10 years | 1 |  |  | 1 |  |
| Mortgage-backed securities with no single maturity | 2,234 |  |  | 2,058 |  |
| Total | $ | 13,431 |  |  | $ | 12,914 |  |

[0000858877-22-000009:notes:133]
Actual maturities may differ from the contractual maturities because borrowers may have the right to call or prepay certain obligations.

[0000858877-22-000009:notes:134]
(b)Summary of Equity Investments

[0000858877-22-000009:notes:135]
We held marketable equity securities of $242 million and $137 million as of April 30, 2022 and July 31, 2021, respectively. We recognized a net unrealized loss of $19 million and $32 million during the third quarter and first nine months of fiscal 2022, respectively, and net unrealized gains of $3 million for each of the third quarter and first nine months of fiscal 2021, on our marketable securities still held as of the reporting date. Our net adjustments to non-marketable equity securities measured using the measurement alternative still held was a net gain of $11 million and $28 million for the third quarter and first nine months of fiscal 2022, respectively. These adjustments were a net loss of $3 million and a net gain of $1 million for the corresponding periods of fiscal 2021, respectively. We held equity interests in certain private equity funds of $1.2 billion and $0.9 billion as of April 30, 2022 and July 31, 2021, respectively, which are accounted for under the NAV practical expedient.

[0000858877-22-000009:notes:136]
In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers are evaluated for consolidation under the variable interest or voting interest

[0000858877-22-000009:notes:137]
entity models. We evaluate on an ongoing basis our investments in these privately held companies and our customer financings, and have determined that as of April 30, 2022, there were no significant variable interest or voting interest entities required to be consolidated in our Consolidated Financial Statements.

[0000858877-22-000009:notes:138]
The carrying value of our investments in privately held companies was $1.9 billion and $1.5 billion as of April 30, 2022 and July 31, 2021, respectively. Of the total carrying value of our investments in privately held companies as of April 30, 2022, $1.2 billion of such investments are considered to be in variable interest entities which are unconsolidated. As of April 30, 2022, we have total funding commitments of $0.4 billion related to privately held investments, some of which may be based on the achievement of certain agreed-upon milestones or are required to be funded on demand. The carrying value of these investments and the additional funding commitments, collectively, represent our maximum exposure related to privately held investments.


## us-gaap:FairValueDisclosuresTextBlock

[0000858877-22-000009:notes:139]
[same as prior period, unchanged from 0000858877-22-000004:notes:138]

[0000858877-22-000009:notes:140]
[same as prior period, unchanged from 0000858877-22-000004:notes:139]

[0000858877-22-000009:notes:141]
[same as prior period, unchanged from 0000858877-22-000004:notes:140]

[0000858877-22-000009:notes:142]
[same as prior period, unchanged from 0000858877-22-000004:notes:141]

[0000858877-22-000009:notes:143]
[same as prior period, unchanged from 0000858877-22-000004:notes:142]

[0000858877-22-000009:notes:144]
[same as prior period, unchanged from 0000858877-22-000004:notes:143]

[0000858877-22-000009:notes:145]
[same as prior period, unchanged from 0000858877-22-000004:notes:144]

[0000858877-22-000009:notes:146]
[same as prior period, unchanged from 0000858877-22-000004:notes:145]

[0000858877-22-000009:notes:147]
|  | APRIL 30, 2022 |  | JULY 31, 2021 |
|  | FAIR VALUE MEASUREMENTS |  | FAIR VALUE MEASUREMENTS |
|  | Level 1 |  | Level 2 |  | TotalBalance |  | Level 1 |  | Level 2 |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 3,119 |  |  | $ | — |  |  | $ | 3,119 |  |  | $ | 5,694 |  |  | $ | — |  |  | $ | 5,694 |  |
| U.S. government securities | — |  |  | 50 |  |  | 50 |  |  | — |  |  | 300 |  |  | 300 |  |
| Non-U.S. government and agency securities | — |  |  | 23 |  |  | 23 |  |  | — |  |  | — |  |  | — |  |
| Corporate debt securities | — |  |  | 43 |  |  | 43 |  |  | — |  |  | — |  |  | — |  |
| Commercial paper | — |  |  | 238 |  |  | 238 |  |  | — |  |  | 114 |  |  | 114 |  |
| Certificates of deposit | — |  |  | 40 |  |  | 40 |  |  | — |  |  | — |  |  | — |  |
| Available-for-sale debt investments: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | — |  |  | 1,300 |  |  | 1,300 |  |  | — |  |  | 1,794 |  |  | 1,794 |  |
| U.S. government agency securities | — |  |  | 146 |  |  | 146 |  |  | — |  |  | 152 |  |  | 152 |  |
| Non-U.S. government and agency securities | — |  |  | 171 |  |  | 171 |  |  | — |  |  | 3 |  |  | 3 |  |
| Corporate debt securities | — |  |  | 8,479 |  |  | 8,479 |  |  | — |  |  | 8,910 |  |  | 8,910 |  |
| U.S. agency mortgage-backed securities | — |  |  | 2,058 |  |  | 2,058 |  |  | — |  |  | 2,862 |  |  | 2,862 |  |
| Commercial paper | — |  |  | 548 |  |  | 548 |  |  | — |  |  | 1,190 |  |  | 1,190 |  |
| Certificates of deposit | — |  |  | 212 |  |  | 212 |  |  | — |  |  | 295 |  |  | 295 |  |
| Equity investments: |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities | 242 |  |  | — |  |  | 242 |  |  | 137 |  |  | — |  |  | 137 |  |
| Other assets: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 750 |  |  | — |  |  | 750 |  |  | 750 |  |  | — |  |  | 750 |  |
| Derivative assets | — |  |  | 65 |  |  | 65 |  |  | — |  |  | 126 |  |  | 126 |  |
| Total | $ | 4,111 |  |  | $ | 13,373 |  |  | $ | 17,484 |  |  | $ | 6,581 |  |  | $ | 15,746 |  |  | $ | 22,327 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities | $ | — |  |  | $ | 87 |  |  | $ | 87 |  |  | $ | — |  |  | $ | 20 |  |  | $ | 20 |  |
| Total | $ | — |  |  | $ | 87 |  |  | $ | 87 |  |  | $ | — |  |  | $ | 20 |  |  | $ | 20 |  |

[0000858877-22-000009:notes:148]
Level 1 marketable equity securities are determined by using quoted prices in active markets for identical assets. Level 2 available-for-sale debt investments are priced using quoted market prices for similar instruments or nonbinding market prices that are corroborated by observable market data. We use inputs such as actual trade data, benchmark yields, broker/dealer quotes, and other similar data, which are obtained from quoted market prices, independent pricing vendors, or other sources, to determine the ultimate fair value of these assets and liabilities. We use such pricing data as the primary input to make our assessments and determinations as to the ultimate valuation of our investment portfolio and have not made, during the periods presented, any material adjustments to such inputs. We are ultimately responsible for the financial statements and underlying estimates. Our derivative instruments are primarily classified as Level 2, as they are not actively traded and are valued using pricing models that use observable market inputs. We did not have any transfers between Level 1 and Level 2 fair value measurements during the periods presented.

[0000858877-22-000009:notes:149]
[same as prior period, unchanged from 0000858877-22-000004:notes:148]

[0000858877-22-000009:notes:150]
[same as prior period, unchanged from 0000858877-22-000004:notes:149]

[0000858877-22-000009:notes:151]
[same as prior period, unchanged from 0000858877-22-000004:notes:150]

[0000858877-22-000009:notes:152]
The fair value of our short-term loan receivables and financed service contracts approximates their carrying value due to their short duration. The aggregate carrying value of our long-term loan receivables and financed service contracts as of April 30, 2022 and July 31, 2021 was $3.3 billion and $4.0 billion, respectively. The estimated fair value of our long-term loan receivables and financed service contracts approximates their carrying value. We use significant unobservable inputs in determining discounted cash flows to estimate the fair value of our long-term loan receivables and financed service contracts, and therefore they are categorized as Level 3.
As of April 30, 2022, the estimated fair value of our short-term debt approximates its carrying value due to the short maturities. As of April 30, 2022, the fair value of our senior notes was $10.1 billion with a carrying amount of $9.4 billion. This compares to a fair value of $13.7 billion and a carrying amount of $11.5 billion as of July 31, 2021. The fair value of the senior notes was determined based on observable market prices in a less active market and was categorized as Level 2 in the fair value hierarchy.


## us-gaap:DebtDisclosureTextBlock

[0000858877-22-000009:notes:153]
Borrowings 
(a)Short-Term Debt

[0000858877-22-000009:notes:154]
The following table summarizes our short-term debt (in millions, except percentages):

[0000858877-22-000009:notes:155]
|  | April 30, 2022 |  | July 31, 2021 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 1,000 |  |  | 2.13 | % |  | $ | 2,508 |  |  | 1.75 | % |

[0000858877-22-000009:notes:156]
We have a short-term debt financing program of up to $10.0 billion through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes. We had no commercial paper outstanding as of April 30, 2022 and July 31, 2021.

[0000858877-22-000009:notes:157]
The effective rates for the short- and long-term debt include the interest on the notes, the accretion of the discount, the issuance costs, and, if applicable, adjustments related to hedging.

[0000858877-22-000009:notes:158]
(b)Long-Term Debt

[0000858877-22-000009:notes:159]
The following table summarizes our long-term debt (in millions, except percentages):

[0000858877-22-000009:notes:160]
|  |  |  | April 30, 2022 |  | July 31, 2021 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 1.85% | September 20, 2021 |  | $ | — |  |  | — |  | $ | 2,000 |  |  | 1.90% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 1.59% |  | 500 |  |  | 1.13% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1.35% |  | 1,000 |  |  | 1.00% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 1.75% |  | 500 |  |  | 1.29% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 9,500 |  |  |  |  | 11,500 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (76) |  |  |  |  | (80) |  |  |  |
| Hedge accounting fair value adjustments |  |  | (6) |  |  |  |  | 106 |  |  |  |
| Total |  |  | $ | 9,418 |  |  |  |  | $ | 11,526 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 1,000 |  |  |  |  | $ | 2,508 |  |  |  |
| Long-term debt |  |  | 8,418 |  |  |  |  | 9,018 |  |  |  |
| Total |  |  | $ | 9,418 |  |  |  |  | $ | 11,526 |  |  |  |

[0000858877-22-000009:notes:161]
We have entered into interest rate swaps in prior periods with an aggregate notional amount of $2.0 billion designated as fair value hedges of certain of our fixed-rate senior notes. These swaps convert the fixed interest rates of the fixed-rate notes to floating interest rates based on the London InterBank Offered Rate (LIBOR). The gains and losses related to changes in the fair value of the interest rate swaps substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates. For additional information, see Note 13.

[0000858877-22-000009:notes:162]
Interest is payable semiannually on each class of the senior fixed-rate notes. Each of the senior fixed-rate notes is redeemable by us at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to our short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of April 30, 2022, we were in compliance with all debt covenants.

[0000858877-22-000009:notes:163]
As of April 30, 2022, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

[0000858877-22-000009:notes:164]
| Fiscal Year | Amount |
| 2022 (remaining three months) | $ | 500 |  |
| 2023 | 500 |  |
| 2024 | 1,750 |  |
| 2025 | 500 |  |
| 2026 | 750 |  |
| Thereafter | 5,500 |  |
| Total | $ | 9,500 |  |

[0000858877-22-000009:notes:165]
(c)Credit Facility

[0000858877-22-000009:notes:166]
On May 13, 2021, we entered into a 5-year credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 13, 2026. As of April 30, 2022, we were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under the credit agreement.

[0000858877-22-000009:notes:167]
Any advances under the 5-year credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (a) with respect to loans in U.S. dollars, (i) LIBOR or (ii) the Base Rate (to be defined as the highest of (x) the Bank of America prime rate, (y) the Federal Funds rate plus 0.50% and (z) a daily rate equal to one-month LIBOR plus 1.0%), (b) with respect to loans in Euros, EURIBOR, (c) with respect to loans in Yen, TIBOR and (d) with respect to loans in Pounds Sterling, SONIA plus a credit spread adjustment, plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the interest rate be less than 0.0%. We will pay a quarterly commitment fee during the term of the 5-year credit agreement which may vary depending on our senior debt credit ratings. In addition, the 5-year credit agreement incorporates certain sustainability-linked metrics. Specifically, our applicable interest rate and commitment fee are subject to upward or downward adjustments if we achieve, or fail to achieve, certain specified targets based on two key performance indicator metrics: (i) social impact and (ii) foam reduction. We may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and, at our option, extend the maturity of the facility for an additional year up to two times. The credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio as defined in the agreement.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000858877-22-000009:notes:168]
[same as prior period, unchanged from 0000858877-22-000004:notes:167]

[0000858877-22-000009:notes:169]
[same as prior period, unchanged from 0000858877-22-000004:notes:168]

[0000858877-22-000009:notes:170]
[same as prior period, unchanged from 0000858877-22-000004:notes:169]

[0000858877-22-000009:notes:171]
|  | DERIVATIVE ASSETS |  | DERIVATIVE LIABILITIES |
|  | Balance Sheet Line Item |  | April 30,2022 |  | July 31,2021 |  | Balance Sheet Line Item |  | April 30,2022 |  | July 31,2021 |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | $ | 48 |  |  | $ | 14 |  |  | Other current liabilities |  | $ | 1 |  |  | $ | 3 |  |
| Foreign currency derivatives | Other assets |  | 7 |  |  | 1 |  |  | Other long-term liabilities |  | — |  |  | — |  |
| Interest rate derivatives | Other current assets |  | 1 |  |  | 9 |  |  | Other current liabilities |  | — |  |  | — |  |
| Interest rate derivatives | Other assets |  | — |  |  | 99 |  |  | Other long-term liabilities |  | 7 |  |  | — |  |
| Total |  |  | 56 |  |  | 123 |  |  |  |  | 8 |  |  | 3 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | 9 |  |  | 3 |  |  | Other current liabilities |  | 68 |  |  | 16 |  |
| Foreign currency derivatives | Other assets |  | — |  |  | — |  |  | Other long-term liabilities |  | 7 |  |  | 1 |  |
| Equity derivatives | Other current assets |  | — |  |  | — |  |  | Other current liabilities |  | 4 |  |  | — |  |
| Total |  |  | 9 |  |  | 3 |  |  |  |  | 79 |  |  | 17 |  |
| Total |  |  | $ | 65 |  |  | $ | 126 |  |  |  |  | $ | 87 |  |  | $ | 20 |  |

[0000858877-22-000009:notes:172]
[same as prior period, unchanged from 0000858877-22-000004:notes:171]

[0000858877-22-000009:notes:173]
|  |  | CARRYING AMOUNT OF THE HEDGED ASSETS/(LIABILITIES) |  | CUMULATIVE AMOUNT OF FAIR VALUE HEDGING ADJUSTMENT INCLUDED IN THE CARRYING AMOUNT OF THE HEDGED ASSETS/LIABILITIES |
| Balance Sheet Line Item of Hedged Item |  | April 30,2022 |  | July 31,2021 |  | April 30,2022 |  | July 31,2021 |
| Short-term debt |  | $ | (501) |  |  | $ | (508) |  |  | $ | (1) |  |  | $ | (9) |  |
| Long-term debt |  | $ | (1,490) |  |  | $ | (1,594) |  |  | $ | 7 |  |  | $ | (97) |  |

[0000858877-22-000009:notes:174]
[same as prior period, unchanged from 0000858877-22-000004:notes:173]

[0000858877-22-000009:notes:175]
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | April 30, 2022 |  | May 1, 2021 |  | April 30, 2022 |  | May 1, 2021 |
| Interest rate derivatives: |  |  |  |  |  |  |  |  |
| Hedged items |  | $ | 54 |  |  | $ | 25 |  |  | $ | 112 |  |  | $ | 58 |  |
| Derivatives designated as hedging instruments |  | (55) |  |  | (25) |  |  | (114) |  |  | (59) |  |
| Total |  | $ | (1) |  |  | $ | — |  |  | $ | (2) |  |  | $ | (1) |  |

[0000858877-22-000009:notes:176]
[same as prior period, unchanged from 0000858877-22-000004:notes:175]

[0000858877-22-000009:notes:177]
|  |  |  |  | GAINS (LOSSES) FOR THE THREE MONTHS ENDED |  | GAINS (LOSSES) FOR THE NINE MONTHS ENDED |
| Derivatives Not Designated as Hedging Instruments |  | Line Item in Statements of Operations |  | April 30,2022 |  | May 1,2021 |  | April 30,2022 |  | May 1,2021 |
| Foreign currency derivatives |  | Other income (loss), net |  | $ | (99) |  |  | $ | (12) |  |  | $ | (155) |  |  | $ | 35 |  |
| Total return swaps—deferred compensation |  | Operating expenses and other |  | (38) |  |  | 45 |  |  | (58) |  |  | 144 |  |
| Equity derivatives |  | Other income (loss), net |  | 5 |  |  | 5 |  |  | 6 |  |  | 19 |  |
| Total |  |  |  | $ | (132) |  |  | $ | 38 |  |  | $ | (207) |  |  | $ | 198 |  |

[0000858877-22-000009:notes:178]
[same as prior period, unchanged from 0000858877-22-000004:notes:177]

[0000858877-22-000009:notes:179]
|  | April 30,2022 |  | July 31,2021 |
| Foreign currency derivatives | $ | 4,501 |  |  | $ | 4,139 |  |
| Interest rate derivatives | 2,000 |  |  | 2,000 |  |
| Total return swaps—deferred compensation | 689 |  |  | 730 |  |
| Total | $ | 7,190 |  |  | $ | 6,869 |  |

[0000858877-22-000009:notes:180]
[same as prior period, unchanged from 0000858877-22-000004:notes:179]

[0000858877-22-000009:notes:181]
We present our derivative instruments at gross fair values in the Consolidated Balance Sheets. However, our master netting and other similar arrangements with the respective counterparties allow for net settlement under certain conditions, which are designed to reduce credit risk by permitting net settlement with the same counterparty. As of April 30, 2022 and July 31, 2021, the potential effects of these rights of set-off associated with the derivative contracts would be a reduction to both derivative assets and derivative liabilities of $66 million and $17 million, respectively.

[0000858877-22-000009:notes:182]
To further limit credit risk, we also enter into collateral security arrangements related to certain derivative instruments whereby cash is posted as collateral between the counterparties based on the fair market value of the derivative instrument. Under these collateral security arrangements, the net cash collateral provided for was $3 million as of April 30, 2022 and the net cash collateral received as of July 31, 2021 was $109 million. Including the effects of collateral, this results in a net derivative liability of $19 million and $3 million as of April 30, 2022 and July 31, 2021, respectively.

[0000858877-22-000009:notes:183]
[same as prior period, unchanged from 0000858877-22-000004:notes:182]

[0000858877-22-000009:notes:184]
[same as prior period, unchanged from 0000858877-22-000004:notes:183]

[0000858877-22-000009:notes:185]
We hedge forecasted foreign currency transactions related to certain revenues, operating expenses and service cost of sales with currency options and forward contracts. These currency options and forward contracts, designated as cash flow hedges, generally have maturities of less than 24 months. The derivative instrument’s gain or loss is initially reported as a component of accumulated other comprehensive income (AOCI) and subsequently reclassified into earnings when the hedged exposure affects earnings.

[0000858877-22-000009:notes:186]
[same as prior period, unchanged from 0000858877-22-000004:notes:185]

[0000858877-22-000009:notes:187]
[same as prior period, unchanged from 0000858877-22-000004:notes:186]

[0000858877-22-000009:notes:188]
[same as prior period, unchanged from 0000858877-22-000004:notes:187]

[0000858877-22-000009:notes:189]
[same as prior period, unchanged from 0000858877-22-000004:notes:188]

[0000858877-22-000009:notes:190]
[same as prior period, unchanged from 0000858877-22-000004:notes:189]

[0000858877-22-000009:notes:191]
[same as prior period, unchanged from 0000858877-22-000004:notes:190]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000858877-22-000009:notes:192]
Commitments and Contingencies 
(a)Purchase Commitments with Contract Manufacturers and Suppliers

[0000858877-22-000009:notes:193]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these inventory purchase commitments with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.

[0000858877-22-000009:notes:194]
The following table summarizes our inventory purchase commitments with contract manufacturers and suppliers by period (in millions):

[0000858877-22-000009:notes:195]
|  | April 30,2022 |  | July 31,2021 |
| Less than 1 year | $ | 10,698 |  |  | $ | 6,903 |  |
| 1 to 3 years | 2,401 |  |  | 1,806 |  |
| 3 to 5 years | — |  |  | 1,545 |  |
| Total | $ | 13,099 |  |  | $ | 10,254 |  |

[0000858877-22-000009:notes:196]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of April 30, 2022 and July 31, 2021, the liability for these purchase commitments was $236 million and $151 million, respectively, and was included in other current liabilities. For further discussion around the Supply Constraints Impacts and Risks, see Result of Operations—Product Gross Margin and Liquidity and Capital Resources—Inventory Supply Chain.

[0000858877-22-000009:notes:197]
(b)Other Commitments

[0000858877-22-000009:notes:198]
In connection with our acquisitions, we have agreed to pay certain additional amounts contingent upon the achievement of certain agreed-upon technology, development, product, or other milestones or upon the continued employment with Cisco of certain employees of the acquired entities.

[0000858877-22-000009:notes:199]
The following table summarizes the compensation expense related to acquisitions (in millions):

[0000858877-22-000009:notes:200]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 30, 2022 |  | May 1, 2021 |  | April 30, 2022 |  | May 1, 2021 |
| Compensation expense related to acquisitions | $ | 56 |  |  | $ | 66 |  |  | $ | 220 |  |  | $ | 182 |  |

[0000858877-22-000009:notes:201]
As of April 30, 2022, we estimated that future cash compensation expense of up to $534 million may be required to be recognized pursuant to the applicable business combination agreements.

[0000858877-22-000009:notes:202]
We also have certain funding commitments, primarily related to our privately held investments, some of which are based on the achievement of certain agreed-upon milestones or are required to be funded on demand. The funding commitments were $0.4 billion and $0.2 billion as of April 30, 2022 and July 31, 2021, respectively.

[0000858877-22-000009:notes:203]
(c)Product Warranties

[0000858877-22-000009:notes:204]
The following table summarizes the activity related to the product warranty liability (in millions):

[0000858877-22-000009:notes:205]
|  | Nine Months Ended |
|  | April 30,2022 |  | May 1,2021 |
| Balance at beginning of period | $ | 336 |  |  | $ | 331 |  |
| Provisions for warranties issued | 320 |  |  | 382 |  |
| Adjustments for pre-existing warranties | 1 |  |  | 1 |  |
| Settlements | (322) |  |  | (373) |  |
| Balance at end of period | $ | 335 |  |  | $ | 341 |  |

[0000858877-22-000009:notes:206]
We accrue for warranty costs as part of our cost of sales based on associated material product costs, labor costs for technical support staff, and associated overhead. Our products are generally covered by a warranty for periods ranging from 90 days to five years, and for some products we provide a limited lifetime warranty.

[0000858877-22-000009:notes:207]
(d)Financing and Other Guarantees

[0000858877-22-000009:notes:208]
In the ordinary course of business, we provide financing guarantees for various third-party financing arrangements extended to channel partners and end-user customers. Payments under these financing guarantee arrangements were not material for the periods presented.

[0000858877-22-000009:notes:209]
Channel Partner Financing Guarantees   We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, with payment terms generally ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. The volume of channel partner financing was $6.9 billion and $6.6 billion for the third quarter of fiscal 2022 and 2021, respectively, and was $20.3 billion and $19.5 billion for the first nine months of fiscal 2022 and 2021, respectively. The balance of the channel partner financing subject to guarantees was $1.3 billion as of each of April 30, 2022 and July 31, 2021.

[0000858877-22-000009:notes:210]
End-User Financing Guarantees   We also provide financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. The volume of financing provided by third parties for leases and loans as to which we had provided guarantees was $3 million and $1 million for the third quarter of fiscal 2022 and 2021, respectively, and was $9 million and $8 million for the first nine months of fiscal 2022 and 2021, respectively.

[0000858877-22-000009:notes:211]
Financing Guarantee Summary   The aggregate amounts of financing guarantees outstanding at April 30, 2022 and July 31, 2021, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

[0000858877-22-000009:notes:212]
|  | April 30,2022 |  | July 31,2021 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 144 |  |  | $ | 155 |  |
| End user | 4 |  |  | 5 |  |
| Total | $ | 148 |  |  | $ | 160 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (15) |  |  | $ | (16) |  |
| End user | (4) |  |  | (5) |  |
| Total | $ | (19) |  |  | $ | (21) |  |
| Total | $ | 129 |  |  | $ | 139 |  |

[0000858877-22-000009:notes:213]
(e)Indemnifications

[0000858877-22-000009:notes:214]
In the normal course of business, we have indemnification obligations to other parties, including customers, lessors, and parties to other transactions with us, with respect to certain matters. We have agreed to indemnify against losses arising from a breach of representations or covenants or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time or circumstances within which an indemnification claim can be made and the amount of the claim.

[0000858877-22-000009:notes:215]
It is not possible to determine the maximum potential amount for claims made under the indemnification obligations discussed in this section (e) due to uncertainties in the litigation process, coordination with and contributions by other parties and the defendants in these cases, and the unique facts and circumstances involved in each particular case and agreement. We are unable to reasonably estimate the ultimate outcome of the cases discussed below in this section (e), but we do not believe that any potential indemnity liability would be material, and historically, indemnity payments made by us have not had a material effect on our Consolidated Financial Statements.

[0000858877-22-000009:notes:216]
We were asked by seven of our customers to indemnify them in connection with patent infringement claims asserted against them by Estech Systems, Inc. (“Estech”) in the Eastern District of Texas (“E.D. Tex.”) court and the Western District of Texas court between April 24, 2020 and August 25, 2020. Estech alleged that the customer defendants infringe three patents generally related to IP telephony by using collaboration technology from us and other providers. Estech was seeking monetary damages from the customer defendants. Estech and the customer defendants resolved Estech’s claims, and we resolved the customer defendants’ indemnity claims for an amount that did not have a material effect on our Consolidated Financial Statements.

[0000858877-22-000009:notes:217]
In addition, we have entered into indemnification agreements with our officers and directors, and our Amended and Restated Bylaws contain similar indemnification obligations to our agents.

[0000858877-22-000009:notes:218]
(f)Legal Proceedings

[0000858877-22-000009:notes:219]
Brazil    Brazilian authorities have investigated our Brazilian subsidiary and certain of its former employees, as well as a Brazilian importer of our products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against our Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years. The asserted claims by Brazilian federal tax authorities are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $163 million for the alleged evasion of import and other taxes, $840 million for interest, and $402 million for various penalties, all determined using an exchange rate as of April 30, 2022.

[0000858877-22-000009:notes:220]
We have completed a thorough review of the matters and believe the asserted claims against our Brazilian subsidiary are without merit, and we are defending the claims vigorously. While we believe there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, we are unable to determine the likelihood of an unfavorable outcome against our Brazilian subsidiary and are unable to reasonably estimate a range of loss, if any. We do not expect a final judicial determination for several years.

[0000858877-22-000009:notes:221]
China     We have completed our investigation into allegations of a self-enrichment scheme involving now-former employees in China, and shared the results of the investigation with the Securities and Exchange Commission (“SEC”) and the Department of Justice (“DOJ”). Based on the investigation results, both the SEC and the DOJ have informed the Company that they do not plan to take any action against the Company in connection with these allegations.

[0000858877-22-000009:notes:222]
SRI International     On September 4, 2013, SRI International, Inc. (“SRI”) asserted claims against us in the U.S. District Court for the District of Delaware (“D. Del.”), accusing our products and services related to network intrusion detection of infringing two patents. After a trial, SRI obtained a verdict against us, and we appealed to the United States Court of Appeals for the Federal Circuit (“Federal Circuit”) which was ultimately unsuccessful. In resolution of this matter, we have paid the SRI judgments, including attorneys’ fees and post-judgment royalties and interest, in the aggregate amount of approximately $60 million. On May 17, 2022, the District Court entered a final order in the case requiring us to pay SRI additional post-judgment interest of approximately $1 million. We made the payment and the case is now concluded.

[0000858877-22-000009:notes:223]
Centripetal     On February 13, 2018, Centripetal Networks, Inc. (“Centripetal”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Virginia, alleging that several of our products and services (including our Catalyst switches, ASR and ISR series routers, ASAs with FirePOWER services, and Stealthwatch products) infringe eleven Centripetal U.S. patents. We thereafter petitioned the Patent Trial and Appeal Board (“PTAB”) of the United States Patent and Trademark Office (“PTO”) to review the validity of nine of the asserted patents. The PTAB instituted inter partes review proceedings (“IPR Proceedings”) on six asserted patents and certain claims of another asserted patent. The PTAB has issued Final Written Decisions for seven patents in the instituted IPR Proceedings, and all claims of five patents have been found unpatentable and several of the claims of the other two patents have been found unpatentable. The PTAB’s findings of unpatentability have been affirmed on appeal.

[0000858877-22-000009:notes:224]
For the five asserted U.S. patents not subject to the IPR Proceedings, the district court conducted a bench trial by videoconference from May 6, 2020 to June 25, 2020. On October 5, 2020, the district court issued a judgment finding validity and willful infringement of four of the asserted patents and non-infringement of the fifth patent. The district court awarded Centripetal $1.9 billion, comprised of $756 million in damages, $1.1 billion in enhanced damages for willful infringement, and pre-judgment interest in the amount of $14 million. The district court declined to issue an injunction but, instead, awarded Centripetal a running royalty against revenue from the products found to infringe for an initial three-year term at a rate of 10%, with a minimum annual royalty of $168 million and a maximum annual royalty of $300 million, and for a second three-year term at a rate of 5%, with a minimum annual royalty of $84 million and a maximum annual royalty of $150 million. We believe that the district court’s findings of validity, infringement, and willful infringement, its award of damages, including enhanced damages, and its award of an ongoing royalty are not supported by either the law or the evidence presented at trial. We have appealed the district court’s judgment as to the four patents found valid and infringed to the Federal Circuit. On October 28, 2020, by agreement of the parties, the district court stayed execution of the judgment until after resolution of any appeal in the matter and waived the requirement of any bond or security; accordingly, no money is currently due under the judgment.

[0000858877-22-000009:notes:225]
Centripetal has submitted complaints in the District Court of Dusseldorf in Germany (“German Court”) against Cisco Systems GmbH and Cisco Systems, Inc., asserting a total of six patents. On April 29, 2020 and April 30, 2020, Centripetal asserted three European patents, seeking both injunctive relief and damages. Two of the three European patents are counterparts to two U.S. patents Centripetal asserted against us in the U.S. district court proceedings, one of which has been invalidated by the PTAB.

[0000858877-22-000009:notes:226]
On June 22, 2021, Centripetal amended one of its complaints to assert one additional European patent and one additional German Utility Model patent. On December 10, 2021, the German Court rejected Centripetal’s complaints on two patents. Centripetal has appealed. On December 21, 2021, the German Court stayed its decision on infringement of the third patent pending a decision by the Federal Patent Court in a related nullity proceeding. On May 17, 2022, Centripetal withdrew its complaint for infringement of the German Utility Model patent. The proceedings on Centripetal’s European patent filed on June 22, 2021 remains pending.

[0000858877-22-000009:notes:227]
On February 14, 2022, Centripetal filed an additional complaint asserting infringement of a sixth patent issued by the European Patent Office. Centripetal seeks both injunctive relief and damages on these patents. We are assessing the complaint and are preparing our defense.

[0000858877-22-000009:notes:228]
Due to uncertainty surrounding patent litigation processes in the U.S. and Europe, we are unable to reasonably estimate the ultimate outcome of either litigation at this time. If we do not prevail in either litigation, we believe that any damages ultimately assessed would not have a material effect on our Consolidated Financial Statements.

[0000858877-22-000009:notes:229]
Ramot     On June 12, 2019, Ramot at Tel Aviv University Ltd. (“Ramot”) asserted patent infringement claims against us in E.D. Tex., seeking damages, including enhanced damages for allegations of willful infringement, and a running royalty on future sales. Ramot alleges that certain Cisco optical transceiver modules and line cards infringe three patents. As of November 27, 2020, the PTO preliminarily found all asserted claims unpatentable in ex parte reexamination proceedings. On January 13, 2021, the court entered an order staying the case pending the conclusion of the ex parte reexamination proceedings (“Reexamination Proceedings”). While we believe that we have strong non-infringement and invalidity arguments, and that Ramot’s damages theories are not supported by prevailing law, we are unable to reasonably estimate the ultimate outcome of this litigation at this time due to uncertainties in the litigation processes. If we do not prevail in court, we believe that any damages ultimately assessed would not have a material effect on our Consolidated Financial Statements.

[0000858877-22-000009:notes:230]
On February 26, 2021, Ramot asserted patent infringement claims against Acacia Communications, Inc. (“Acacia”) (which we subsequently acquired) in D. Del, seeking damages, including enhanced damages for allegations of willful infringement, and a running royalty on future sales. Ramot alleges that certain Acacia optical transceiver modules and integrated circuits infringe two of the three patents that Ramot has asserted in its E.D. Tex. case. On September 3, 2021, the court stayed the case pending the ultimate resolution of the Reexamination Proceedings. Due to the early stage of the litigation as well as uncertainties in the litigation processes, we are unable, at this time, to reasonably estimate a potential range of loss, if any, or the ultimate outcome of this litigation.

[0000858877-22-000009:notes:231]
Viasat     On January 21, 2016, Viasat, Inc. (“Viasat”) filed suit against Acacia (which we subsequently acquired) in the California Superior Court for San Diego County (“SDSC”) seeking unpaid royalties for breach of contract and the implied covenant of good faith and fair dealing, and damages for trade secret misappropriation for certain products (“Viasat 1”). Acacia counterclaimed for patent and trade secret misappropriation, contract, and unfair competition claims. On July 17, 2019, the jury found for Viasat on its contract claims, and awarded Viasat approximately $49 million for unpaid royalties through 2018. The jury further found that Acacia willfully misappropriated Viasat’s trade secrets and awarded Viasat $1. On Acacia’s counterclaims, the jury found for Acacia on its contract and trade secret claims and awarded Acacia $1. Both Acacia and Viasat appealed to the California Court of Appeal, Fourth Appellate District (“CCA”). On May 23, 2022, the CCA affirmed the judgment of approximately $49 million, plus post-judgment interest and costs, for Viasat on its breach of contract claim for unpaid royalties, but reversed the judgments for Viasat for breach of the implied covenant of good faith and fair dealing, and for trade secret misappropriation. We are currently reviewing the decision of the CCA and assessing whether to seek additional appellate review.

[0000858877-22-000009:notes:232]
On November 6, 2019, Viasat filed a second suit in SDSC, alleging contract and trade secret claims for Acacia products sold from January 1, 2019 forward (“Viasat 2”). On February 28, 2020, the court stayed Viasat 2 pending the appeal in Viasat 1. On June 9, 2020, Viasat filed a third suit in SDSC (“Viasat 3”). In Viasat 3, Viasat alleges contract and trade secrets claims for sales of additional Acacia products. On August 11, 2020, the court stayed Viasat 3 pending the appeal in Viasat 1.

[0000858877-22-000009:notes:233]
On July 28, 2017, Acacia filed suit in the Commonwealth of Massachusetts Superior Court - Business Litigation Session against ViaSat alleging claims for defamation, unfair competition, business torts, and declaratory judgment of no trade secret misappropriation. On April 5, 2018, ViaSat counterclaimed with contract, trade secret, and unfair competition claims (collectively, with Viasat 2 and Viasat 3, the “Viasat Cases”). On December 13, 2018, the Massachusetts court entered an order staying the Massachusetts litigation, which has been extended to June 30, 2022.

[0000858877-22-000009:notes:234]
While we believe Acacia has strong defenses in each of the Viasat Cases, we are unable to reasonably estimate the ultimate outcome of any of the Viasat Cases at this time due to uncertainties in the litigation processes. If Acacia does not prevail, we

[0000858877-22-000009:notes:235]
believe that any relief ultimately assessed in any of the Viasat Cases would not have a material effect on our Consolidated Financial Statements.

[0000858877-22-000009:notes:236]
Egenera     On August 8, 2016, Egenera, Inc. (“Egenera”) asserted infringement claims against us in the U.S. District Court for the District of Massachusetts, alleging that Cisco’s Unified Computing System Manager product infringes three U.S. patents. Egenera seeks damages, including enhanced damages for allegations of willful infringement, and an injunction. Two of the asserted patents have been dismissed, leaving Egenera’s infringement claim based on one asserted patent. The court has scheduled a jury trial on the remaining patent to commence on August 2, 2022. On March 25, 2022, the PTO preliminarily found all of the asserted claims of the remaining patent unpatentable in ex parte reexamination proceedings. While we believe that we have strong non-infringement and invalidity arguments, and that Egenera’s damages theories are not supported by prevailing law, we are unable to reasonably estimate the ultimate outcome of this litigation at this time due to uncertainties in the litigation process. If we do not prevail in court, we believe at this time that any damages ultimately assessed would not have a material effect on our Consolidated Financial Statements.
In addition, we are subject to other legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, we do not believe that the ultimate costs to resolve these matters will have a material effect on our Consolidated Financial Statements. For additional information regarding intellectual property litigation, see “Part II, Item 1A. Risk Factors—We may be found to infringe on intellectual property rights of others” herein.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock

[0000858877-22-000009:notes:237]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these inventory purchase commitments with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000858877-22-000009:notes:238]
[same as prior period, unchanged from 0000858877-22-000004:notes:234]

[0000858877-22-000009:notes:239]
We declared and paid cash dividends of $0.38 and $0.37 per common share, or $1.6 billion, on our outstanding common stock for each of the third quarters of fiscal 2022 and 2021. We declared and paid cash dividends of $1.12 and $1.09 per common share, or $4.7 billion and $4.6 billion, on our outstanding common stock for the first nine months of fiscal 2022 and 2021, respectively.

[0000858877-22-000009:notes:240]
Any future dividends will be subject to the approval of our Board of Directors.

[0000858877-22-000009:notes:241]
[same as prior period, unchanged from 0000858877-22-000004:notes:237]

[0000858877-22-000009:notes:242]
In September 2001, our Board of Directors authorized a stock repurchase program. As of April 30, 2022, the remaining authorized amount for stock repurchases under this program was approximately $17.6 billion with no termination date. A summary of the stock repurchase activity for fiscal 2022 and 2021 under the stock repurchase program, reported based on the trade date, is summarized as follows (in millions, except per-share amounts):

[0000858877-22-000009:notes:243]
| Quarter Ended |  | Shares |  | Weighted-Average Price per Share |  | Amount |
| Fiscal 2022 |  |  |  |  |  |  |
| April 30, 2022 |  | 5 |  |  | $ | 54.20 |  |  | $ | 252 |  |
| January 29, 2022 |  | 82 |  |  | $ | 58.36 |  |  | $ | 4,824 |  |
| October 30, 2021 |  | 5 |  |  | $ | 56.49 |  |  | $ | 256 |  |
| Fiscal 2021 |  |  |  |  |  |  |
| July 31, 2021 |  | 15 |  |  | $ | 53.30 |  |  | $ | 791 |  |
| May 1, 2021 |  | 10 |  |  | $ | 48.71 |  |  | $ | 510 |  |
| January 23, 2021 |  | 19 |  |  | $ | 42.82 |  |  | $ | 801 |  |
| October 24, 2020 |  | 20 |  |  | $ | 40.44 |  |  | $ | 800 |  |

[0000858877-22-000009:notes:244]
There were stock repurchases of $10 million and $25 million that were pending settlement as of April 30, 2022 and July 31, 2021, respectively.

[0000858877-22-000009:notes:245]
[same as prior period, unchanged from 0000858877-22-000004:notes:241]

[0000858877-22-000009:notes:246]
[same as prior period, unchanged from 0000858877-22-000004:notes:242]

[0000858877-22-000009:notes:247]
Under the terms of our Amended and Restated Certificate of Incorporation, the Board of Directors is authorized to issue preferred stock of one or more series and, in connection with the creation of such series, to fix by resolution the designation, powers (including voting powers (if any)), preferences and relative, participating, optional or other special rights of such series, and any qualification, limitations or restrictions thereof, of the shares of such series. As of April 30, 2022, we had not issued any shares of preferred stock.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000858877-22-000009:notes:248]
[same as prior period, unchanged from 0000858877-22-000004:notes:244]

[0000858877-22-000009:notes:249]
[same as prior period, unchanged from 0000858877-22-000004:notes:245]

[0000858877-22-000009:notes:250]
The 2005 Plan provides for the granting of stock options, stock grants, stock units and stock appreciation rights (SARs), the vesting of which may be time-based or upon satisfaction of performance goals, or both, and/or other conditions. Employees (including employee directors and executive officers) and consultants of Cisco and its subsidiaries and affiliates and non-employee directors of Cisco are eligible to participate in the 2005 Plan. As of April 30, 2022, the maximum number of shares issuable under the 2005 Plan over its term was 790 million shares. The 2005 Plan may be terminated by our Board of Directors at any time and for any reason, and is currently set to terminate at the 2030 Annual Meeting unless re-adopted or extended by our stockholders prior to or on such date.

[0000858877-22-000009:notes:251]
Under the 2005 Plan’s share reserve feature, a distinction is made between the number of shares in the reserve attributable to (i) stock options and SARs and (ii) “full value” awards (i.e., stock grants and stock units). Shares issued as stock grants, pursuant to stock units or pursuant to the settlement of dividend equivalents are counted against shares available for issuance under the 2005 Plan on a 1.5-to-1 ratio. For each share awarded as restricted stock or a restricted stock unit award under the 2005 Plan, 1.5 shares was deducted from the available share-based award balance. If awards issued under the 2005 Plan are forfeited or terminated for any reason before being exercised or settled, then the shares underlying such awards, plus the number of additional shares, if any, that counted against shares available for issuance under the 2005 Plan at the time of grant as a result of the application of the share ratio described above, will become available again for issuance under the 2005 Plan. As of April 30, 2022, 219 million shares were authorized for future grant under the 2005 Plan.

[0000858877-22-000009:notes:252]
[same as prior period, unchanged from 0000858877-22-000004:notes:248]

[0000858877-22-000009:notes:253]
We have an Employee Stock Purchase Plan under which 721 million shares of our common stock have been reserved for issuance as of April 30, 2022. Eligible employees are offered shares through a 24-month offering period, which consists of four consecutive 6-month purchase periods. Employees may purchase a limited amount of shares of our stock at a discount of up to 15% of the lesser of the fair market value at the beginning of the offering period or the end of each 6-month purchase period. The Employee Stock Purchase Plan is scheduled to terminate on the earlier of (i) January 3, 2030 and (ii) the date on which all shares available for issuance under the Employee Stock Purchase Plan are sold pursuant to exercised purchase rights. No shares were issued under the Employee Stock Purchase Plan during each of the third quarters of fiscal 2022 and 2021. We issued 8 million shares during each of the first nine months of fiscal 2022 and 2021. As of April 30, 2022, 117 million shares were available for issuance under the Employee Stock Purchase Plan.

[0000858877-22-000009:notes:254]
[same as prior period, unchanged from 0000858877-22-000004:notes:250]

[0000858877-22-000009:notes:255]
[same as prior period, unchanged from 0000858877-22-000004:notes:251]

[0000858877-22-000009:notes:256]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 30, 2022 |  | May 1, 2021 |  | April 30, 2022 |  | May 1, 2021 |
| Cost of sales—product | $ | 30 |  |  | $ | 26 |  |  | $ | 84 |  |  | $ | 75 |  |
| Cost of sales—service | 53 |  |  | 49 |  |  | 149 |  |  | 133 |  |
| Share-based compensation expense in cost of sales | 83 |  |  | 75 |  |  | 233 |  |  | 208 |  |
| Research and development | 205 |  |  | 184 |  |  | 591 |  |  | 522 |  |
| Sales and marketing | 139 |  |  | 140 |  |  | 421 |  |  | 402 |  |
| General and administrative | 50 |  |  | 59 |  |  | 161 |  |  | 179 |  |
| Restructuring and other charges | — |  |  | 5 |  |  | 1 |  |  | 26 |  |
| Share-based compensation expense in operating expenses | 394 |  |  | 388 |  |  | 1,174 |  |  | 1,129 |  |
| Total share-based compensation expense | $ | 477 |  |  | $ | 463 |  |  | $ | 1,407 |  |  | $ | 1,337 |  |
| Income tax benefit for share-based compensation | $ | 122 |  |  | $ | 88 |  |  | $ | 378 |  |  | $ | 264 |  |

[0000858877-22-000009:notes:257]
As of April 30, 2022, the total compensation cost related to unvested share-based awards not yet recognized was $4.0 billion which is expected to be recognized over approximately 2.7 years on a weighted-average basis.

[0000858877-22-000009:notes:258]
[same as prior period, unchanged from 0000858877-22-000004:notes:254]

[0000858877-22-000009:notes:259]
[same as prior period, unchanged from 0000858877-22-000004:notes:255]

[0000858877-22-000009:notes:260]
|  | Restricted Stock/Stock Units |  | Weighted-AverageGrant Date FairValue per Share |  | Aggregate Fair Value |
| Unvested balance at July 25, 2020 | 96 |  |  | $ | 42.03 |  |  |  |
| Granted and assumed | 51 |  |  | 41.89 |  |  |  |
| Vested | (39) |  |  | 39.63 |  |  | $ | 1,813 |  |
| Canceled/forfeited/other | (14) |  |  | 42.13 |  |  |  |
| Unvested balance at July 31, 2021 | 94 |  |  | $ | 42.93 |  |  |  |
| Granted and assumed | 37 |  |  | 53.63 |  |  |  |
| Vested | (27) |  |  | 41.45 |  |  | $ | 1,560 |  |
| Canceled/forfeited/other | (10) |  |  | 45.52 |  |  |  |
| Unvested balance at April 30, 2022 | 94 |  |  | $ | 47.33 |  |  |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000858877-22-000009:notes:261]
Comprehensive Income (Loss)
The components of AOCI, net of tax, and the other comprehensive income (loss), for the first nine months of fiscal 2022 and 2021 are summarized as follows (in millions):

[0000858877-22-000009:notes:262]
|  | Net Unrealized Gains (Losses) on Available-for-Sale Investments |  | Net Unrealized Gains (Losses) Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Actuarial Gains (Losses) |  | Accumulated Other Comprehensive Income (Loss) |
| Balance at July 31, 2021 | $ | 182 |  |  | $ | (1) |  |  | $ | (598) |  |  | $ | (417) |  |
| Other comprehensive income (loss) before reclassifications | (717) |  |  | 63 |  |  | (485) |  |  | (1,139) |  |
| (Gains) losses reclassified out of AOCI | (18) |  |  | (15) |  |  | 1 |  |  | (32) |  |
| Tax benefit (expense) | 127 |  |  | (11) |  |  | 9 |  |  | 125 |  |
| Balance at April 30, 2022 | $ | (426) |  |  | $ | 36 |  |  | $ | (1,073) |  |  | $ | (1,463) |  |

[0000858877-22-000009:notes:263]
|  | Net Unrealized Gains (Losses) on Available-for-Sale Investments |  | Net Unrealized Gains (Losses) Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Actuarial Gains (Losses) |  | Accumulated Other Comprehensive Income (Loss) |
| Balance at July 25, 2020 | $ | 315 |  |  | $ | (6) |  |  | $ | (828) |  |  | $ | (519) |  |
| Other comprehensive income (loss) before reclassifications | (150) |  |  | 16 |  |  | 364 |  |  | 230 |  |
| (Gains) losses reclassified out of AOCI | (46) |  |  | (12) |  |  | 3 |  |  | (55) |  |
| Tax benefit (expense) | 59 |  |  | (2) |  |  | (1) |  |  | 56 |  |
| Balance at May 1, 2021 | $ | 178 |  |  | $ | (4) |  |  | $ | (462) |  |  | $ | (288) |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000858877-22-000009:notes:264]
[same as prior period, unchanged from 0000858877-22-000004:notes:260]

[0000858877-22-000009:notes:265]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 30,2022 |  | May 1,2021 |  | April 30,2022 |  | May 1,2021 |
| Income before provision for income taxes | $ | 3,801 |  |  | $ | 3,591 |  |  | $ | 11,061 |  |  | $ | 9,527 |  |
| Provision for income taxes | $ | 757 |  |  | $ | 728 |  |  | $ | 2,064 |  |  | $ | 1,945 |  |
| Effective tax rate | 19.9 | % |  | 20.3 | % |  | 18.7 | % |  | 20.4 | % |

[0000858877-22-000009:notes:266]
As of April 30, 2022, we had $3.1 billion of unrecognized tax benefits, of which $2.3 billion, if recognized, would favorably impact the effective tax rate. We regularly engage in discussions and negotiations with tax authorities regarding tax matters in various jurisdictions. We believe it is reasonably possible that certain federal, foreign, and state tax matters may be concluded in the next 12 months. Specific positions that may be resolved include issues involving transfer pricing and various other matters.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000858877-22-000009:notes:267]
[same as prior period, unchanged from 0000858877-22-000004:notes:263]

[0000858877-22-000009:notes:268]
We conduct business globally and are primarily managed on a geographic basis consisting of three segments: the Americas, EMEA, and APJC. Our management makes financial decisions and allocates resources based on the information it receives from our internal management system. Sales are attributed to a segment based on the ordering location of the customer. We do not allocate research and development, sales and marketing, or general and administrative expenses to our segments in this internal management system because management does not include the information in our measurement of the performance of the operating segments. In addition, we do not allocate amortization and impairment of acquisition-related intangible assets, share-based compensation expense, significant litigation settlements and other contingencies, charges related to asset impairments and restructurings, and certain other charges to the gross margin for each segment because management does not include this information in our measurement of the performance of the operating segments.

[0000858877-22-000009:notes:269]
Summarized financial information by segment for the third quarter and first nine months of fiscal 2022 and 2021, based on our internal management system and as utilized by our Chief Operating Decision Maker (“CODM”), is as follows (in millions):

[0000858877-22-000009:notes:270]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 30,2022 |  | May 1,2021 |  | April 30,2022 |  | May 1,2021 |
| Revenue: |  |  |  |  |  |  |  |
| Americas | $ | 7,638 |  |  | $ | 7,262 |  |  | $ | 22,344 |  |  | $ | 21,430 |  |
| EMEA | 3,271 |  |  | 3,483 |  |  | 10,138 |  |  | 9,654 |  |
| APJC | 1,926 |  |  | 2,057 |  |  | 5,972 |  |  | 5,608 |  |
| Total | $ | 12,835 |  |  | $ | 12,803 |  |  | $ | 38,455 |  |  | $ | 36,692 |  |
| Gross margin: |  |  |  |  |  |  |  |
| Americas | $ | 4,952 |  |  | $ | 4,831 |  |  | $ | 14,438 |  |  | $ | 14,383 |  |
| EMEA | 2,154 |  |  | 2,283 |  |  | 6,664 |  |  | 6,322 |  |
| APJC | 1,279 |  |  | 1,331 |  |  | 3,934 |  |  | 3,599 |  |
| Segment total | 8,386 |  |  | 8,445 |  |  | 25,035 |  |  | 24,303 |  |
| Unallocated corporate items | (265) |  |  | (260) |  |  | (812) |  |  | (753) |  |
| Total | $ | 8,121 |  |  | $ | 8,185 |  |  | $ | 24,223 |  |  | $ | 23,550 |  |

[0000858877-22-000009:notes:271]
[same as prior period, unchanged from 0000858877-22-000004:notes:267]

[0000858877-22-000009:notes:272]
Revenue in the United States was $6.9 billion and $6.4 billion for the third quarter of fiscal 2022 and 2021, respectively, and $20.1 billion and $19.1 billion for the first nine months of fiscal 2022 and 2021, respectively.

[0000858877-22-000009:notes:273]
[same as prior period, unchanged from 0000858877-22-000004:notes:269]

[0000858877-22-000009:notes:274]
We design and sell Internet Protocol (IP)-based networking and other products related to the communications and IT industry and provide services associated with these products and their use. Effective fiscal 2022, we began reporting our product and service revenue in the following categories: Secure, Agile Networks; Internet for the Future; Collaboration; End-to-End Security; Optimized Application Experiences; Other Products; and Services. This change will better align our product categories with our strategic priorities.


## us-gaap:EarningsPerShareTextBlock

[0000858877-22-000009:notes:275]
[same as prior period, unchanged from 0000858877-22-000004:notes:271]

[0000858877-22-000009:notes:276]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 30,2022 |  | May 1,2021 |  | April 30,2022 |  | May 1,2021 |
| Net income | $ | 3,044 |  |  | $ | 2,863 |  |  | $ | 8,997 |  |  | $ | 7,582 |  |
| Weighted-average shares—basic | 4,152 |  |  | 4,219 |  |  | 4,184 |  |  | 4,224 |  |
| Effect of dilutive potential common shares | 18 |  |  | 19 |  |  | 20 |  |  | 13 |  |
| Weighted-average shares—diluted | 4,170 |  |  | 4,238 |  |  | 4,204 |  |  | 4,237 |  |
| Net income per share—basic | $ | 0.73 |  |  | $ | 0.68 |  |  | $ | 2.15 |  |  | $ | 1.79 |  |
| Net income per share—diluted | $ | 0.73 |  |  | $ | 0.68 |  |  | $ | 2.14 |  |  | $ | 1.79 |  |
| Antidilutive employee share-based awards, excluded | 11 |  |  | 15 |  |  | 46 |  |  | 55 |  |

[0000858877-22-000009:notes:277]
[same as prior period, unchanged from 0000858877-22-000004:notes:273]
