# CSCO MD&A — 0000858877-23-000005


## mdna

[0000858877-23-000005:mdna:1]
[same as prior period, unchanged from 0000858877-22-000025:mdna:1]

[0000858877-23-000005:mdna:2]
[same as prior period, unchanged from 0000858877-22-000025:mdna:2]

[0000858877-23-000005:mdna:3]
[same as prior period, unchanged from 0000858877-22-000025:mdna:3]

[0000858877-23-000005:mdna:4]
[same as prior period, unchanged from 0000858877-22-000025:mdna:4]

[0000858877-23-000005:mdna:5]
[same as prior period, unchanged from 0000858877-22-000025:mdna:5]

[0000858877-23-000005:mdna:6]
|  | Three Months Ended |  | Six Months Ended |  |
|  | January 28,2023 |  | January 29,2022 |  | % Variance |  | January 28,2023 |  | January 29,2022 |  | % Variance |  |
| Revenue | $ | 13,592 |  |  | $ | 12,720 |  |  | 7 | % |  | $ | 27,224 |  |  | $ | 25,620 |  |  | 6 | % |  |
| Gross margin percentage | 62.0 | % |  | 63.3 | % |  | (1.3) |  | pts | 61.6 | % |  | 62.8 | % |  | (1.2) |  | pts |
| Research and development | $ | 1,855 |  |  | $ | 1,670 |  |  | 11 | % |  | $ | 3,636 |  |  | $ | 3,384 |  |  | 7 | % |  |
| Sales and marketing | $ | 2,384 |  |  | $ | 2,266 |  |  | 5 | % |  | $ | 4,775 |  |  | $ | 4,527 |  |  | 5 | % |  |
| General and administrative | $ | 582 |  |  | $ | 544 |  |  | 7 | % |  | $ | 1,147 |  |  | $ | 1,095 |  |  | 5 | % |  |
| Total research and development, sales and marketing, general and administrative | $ | 4,821 |  |  | $ | 4,480 |  |  | 8 | % |  | $ | 9,558 |  |  | $ | 9,006 |  |  | 6 | % |  |
| Total as a percentage of revenue | 35.5 | % |  | 35.2 | % |  | 0.3 |  | pts | 35.1 | % |  | 35.2 | % |  | (0.1) |  | pts |
| Amortization of purchased intangible assets included in operating expenses | $ | 71 |  |  | $ | 79 |  |  | (10) | % |  | $ | 142 |  |  | $ | 163 |  |  | (13) | % |  |
| Restructuring and other charges included in operating expenses | $ | 243 |  |  | $ | 3 |  |  | NM |  | $ | 241 |  |  | $ | 8 |  |  | NM |  |
| Operating income as a percentage of revenue | 24.2 | % |  | 27.4 | % |  | (3.2) |  | pts | 25.1 | % |  | 27.0 | % |  | (1.9) |  | pts |
| Interest and other income (loss), net | $ | 123 |  |  | $ | 116 |  |  | 6 | % |  | $ | 58 |  |  | $ | 335 |  |  | (83) | % |  |
| Income tax percentage | 18.8 | % |  | 17.5 | % |  | 1.3 |  | pts | 21.0 | % |  | 18.0 | % |  | 3.0 |  | pts |
| Net income | $ | 2,773 |  |  | $ | 2,973 |  |  | (7) | % |  | $ | 5,443 |  |  | $ | 5,953 |  |  | (9) | % |  |
| Net income as a percentage of revenue | 20.4 | % |  | 23.4 | % |  | (3.0) |  | pts | 20.0 | % |  | 23.2 | % |  | (3.2) |  | pts |
| Earnings per share—diluted | $ | 0.67 |  |  | $ | 0.71 |  |  | (6) | % |  | $ | 1.32 |  |  | $ | 1.41 |  |  | (6) | % |  |

[0000858877-23-000005:mdna:7]
[same as prior period, unchanged from 0000858877-22-000025:mdna:7]

[0000858877-23-000005:mdna:8]
NM — Not meaningful

[0000858877-23-000005:mdna:9]
[same as prior period, unchanged from 0000858877-22-000025:mdna:8]

[0000858877-23-000005:mdna:10]
[same as prior period, unchanged from 0000858877-22-000025:mdna:9]

[0000858877-23-000005:mdna:11]
Three Months Ended January 28, 2023 Compared with Three Months Ended January 29, 2022

[0000858877-23-000005:mdna:12]
In the second quarter of fiscal 2023, we delivered strong results with growth in revenue. We remain focused on delivering innovation across our technologies to assist our customers in executing on their digital transformations. We have, and continue to take, multiple steps in order to mitigate the component shortages and deliver products to our customers in order to address supply constraints seen industry-wide. We did see further improvements in supply constraints during the second quarter of fiscal 2023. However, we expect the constraints to continue and the duration is uncertain. We continued to make progress in the transition of our business model delivering increased software and subscriptions. We remain focused on accelerating innovation across our portfolio, and we believe that we have made continued progress on our strategic priorities. We continue to operate in a challenging macroeconomic and highly competitive environment. While the overall environment remains uncertain, we continue to aggressively invest in priority areas with the objective of driving profitable growth over the long term.

[0000858877-23-000005:mdna:13]
Total revenue increased by 7% compared with the second quarter of fiscal 2022. Within total revenue, product revenue increased by 9% and service revenue increased by 2%. In the second quarter of fiscal 2023, total software revenue was $4.2 billion across all product areas and service, an increase of 10%. Within total software revenue, subscription revenue increased 15%. Total gross margin decreased by 1.3 percentage points. Product gross margin decreased by 1.6 percentage points, largely driven by increased costs related to supply constraints, partially offset by favorable pricing and product mix. As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses, collectively, increased by 0.3 percentage points. Operating income as a percentage of revenue decreased by 3.2 percentage points. We incurred restructuring and other charges of $243 million in the second quarter of fiscal 2023. Diluted earnings per share decreased 6%, driven by a decrease of 7% in net income, partially offset by a decrease in diluted share count of 89 million shares.

[0000858877-23-000005:mdna:14]
In terms of our geographic segments, revenue from the Americas increased $679 million, EMEA revenue increased by $164 million and APJC revenue increased by $29 million. Although total revenue increased, we saw a decline in product demand compared to the second quarter of fiscal 2022. The decline was against the comparable prior year period in which we experienced unusually high demand. We did see an increase in product demand compared to the first quarter of fiscal 2023.

[0000858877-23-000005:mdna:15]
From a customer market standpoint, we experienced product revenue growth in each of our customer markets.

[0000858877-23-000005:mdna:16]
From a product category perspective, the product revenue increase of 9% was driven by growth in revenue for Secure, Agile Networks of 14%; End-to-End Security of 7%; and Optimized Application Experiences of 11%; partially offset by product revenue declines in Internet for the Future of 1% and Collaboration of 10%.

[0000858877-23-000005:mdna:17]
[same as prior period, unchanged from 0000858877-22-000025:mdna:16]

[0000858877-23-000005:mdna:18]
[same as prior period, unchanged from 0000858877-22-000025:mdna:17]

[0000858877-23-000005:mdna:19]
Six Months Ended January 28, 2023 Compared with Six Months Ended January 29, 2022

[0000858877-23-000005:mdna:20]
Total revenue increased 6%, with product revenue increasing 8% and service revenue increasing 1%. Total gross margin decreased 1.2 percentage points due to increased costs related to supply constraints, partially offset by favorable pricing, and to a lesser extent, favorable impacts from product mix. As a percentage of revenue, research, and development, sales and marketing, and general and administrative expenses collectively decreased by 0.1 percentage points. Operating income as a percentage of revenue decreased by 1.9 percentage points. We incurred restructuring and other charges of $241 million in the first six months of fiscal 2023. Diluted earnings per share decreased 6%, driven by a decrease of 9% in net income, partially offset by a decrease in diluted share count of 107 million shares.

[0000858877-23-000005:mdna:21]
[same as prior period, unchanged from 0000858877-22-000025:mdna:18]

[0000858877-23-000005:mdna:22]
[same as prior period, unchanged from 0000858877-22-000025:mdna:19]

[0000858877-23-000005:mdna:23]
For additional discussion of our strategy and priorities, see Item 1. Business in our Annual Report on Form 10-K for the fiscal year ended July 30, 2022.

[0000858877-23-000005:mdna:24]
[same as prior period, unchanged from 0000858877-22-000025:mdna:21]

[0000858877-23-000005:mdna:25]
The following is a summary of our other key financial measures for the second quarter of fiscal 2023 (in millions):

[0000858877-23-000005:mdna:26]
|  |  | January 28,2023 |  | July 30,2022 |
| Cash and cash equivalents and investments |  | $ | 22,061 |  |  | $ | 19,267 |  |
| Remaining performance obligations |  | $ | 31,772 |  |  | $ | 31,539 |  |
| Inventories |  | $ | 3,140 |  |  | $ | 2,568 |  |

[0000858877-23-000005:mdna:27]
|  |  | Six Months Ended |
|  |  | January 28,2023 |  | January 29,2022 |
| Cash provided by operating activities |  | $ | 8,701 |  |  | $ | 5,888 |  |
| Repurchases of common stock—stock repurchase program |  | $ | 1,758 |  |  | $ | 5,080 |  |
| Dividends paid |  | $ | 3,120 |  |  | $ | 3,102 |  |

[0000858877-23-000005:mdna:28]
[same as prior period, unchanged from 0000858877-22-000025:mdna:25]

[0000858877-23-000005:mdna:29]
[same as prior period, unchanged from 0000858877-22-000025:mdna:26]

[0000858877-23-000005:mdna:30]
[same as prior period, unchanged from 0000858877-22-000025:mdna:27]

[0000858877-23-000005:mdna:31]
The preparation of financial statements and related disclosures in conformity with accounting principles generally accepted in the United States requires us to make judgments, assumptions, and estimates that affect the amounts reported in the Consolidated Financial Statements and accompanying notes. Note 2 to the Consolidated Financial Statements in our Annual Report on Form 10-K for the fiscal year ended July 30, 2022, as updated as applicable in Note 2 to the Consolidated Financial Statements herein, describes the significant accounting policies and methods used in the preparation of the Consolidated Financial Statements. The accounting policies described below are significantly affected by critical accounting estimates. Such accounting policies require significant judgments, assumptions, and estimates used in the preparation of the Consolidated Financial Statements, and actual results could differ materially from the amounts reported based on these policies.

[0000858877-23-000005:mdna:32]
[same as prior period, unchanged from 0000858877-22-000025:mdna:29]

[0000858877-23-000005:mdna:33]
[same as prior period, unchanged from 0000858877-22-000025:mdna:30]

[0000858877-23-000005:mdna:34]
[same as prior period, unchanged from 0000858877-22-000025:mdna:31]

[0000858877-23-000005:mdna:35]
[same as prior period, unchanged from 0000858877-22-000025:mdna:32]

[0000858877-23-000005:mdna:36]
[same as prior period, unchanged from 0000858877-22-000025:mdna:33]

[0000858877-23-000005:mdna:37]
[same as prior period, unchanged from 0000858877-22-000025:mdna:34]

[0000858877-23-000005:mdna:38]
[same as prior period, unchanged from 0000858877-22-000025:mdna:35]

[0000858877-23-000005:mdna:39]
[same as prior period, unchanged from 0000858877-22-000025:mdna:36]

[0000858877-23-000005:mdna:40]
44

[0000858877-23-000005:mdna:41]
[same as prior period, unchanged from 0000858877-22-000025:mdna:37]

[0000858877-23-000005:mdna:42]
[same as prior period, unchanged from 0000858877-22-000025:mdna:38]

[0000858877-23-000005:mdna:43]
[same as prior period, unchanged from 0000858877-22-000025:mdna:39]

[0000858877-23-000005:mdna:44]
Our provision for inventory was $92 million and $45 million for the first six months of fiscal 2023 and 2022, respectively. The provision for the liability related to purchase commitments with contract manufacturers and suppliers was $199 million and $80 million for the first six months of fiscal 2023 and 2022, respectively. If there were to be a sudden and significant decrease in demand for our products, if there were a higher incidence of inventory obsolescence because of rapidly changing technology and customer requirements, or if supply constraints were to continue, we could be required to increase our inventory write-downs, and our liability for purchase commitments with contract manufacturers and suppliers, and accordingly our profitability, could be adversely affected. We regularly evaluate our exposure for inventory write-downs and the adequacy of our liability for purchase commitments. While we saw further improvements in the second quarter of fiscal 2023, we continue to manage through significant supply constraints seen industry-wide due to component shortages caused, in part, by the COVID-19 pandemic. For further discussion around the Supply Constraints Impacts and Risks, see “Result of Operations—Product Gross Margin—Supply Constraints Impact and Risks” and “Liquidity and Capital Resources—Inventory Supply Chain.”

[0000858877-23-000005:mdna:45]
Loss Contingencies

[0000858877-23-000005:mdna:46]
We are subject to the possibility of various losses arising in the ordinary course of business. We consider the likelihood of the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that a liability has been incurred and the amount of loss can be reasonably estimated. We regularly evaluate information available to us to determine whether such accruals should be made or adjusted and whether new accruals are required.

[0000858877-23-000005:mdna:47]
Third parties, including customers, have in the past and may in the future assert claims or initiate litigation related to exclusive patent, copyright, trademark, and other intellectual property rights to technologies and related standards that are relevant to us. These assertions have increased over time as a result of our growth and the general increase in the pace of patent claims assertions, particularly in the United States. If any infringement or other intellectual property claim made against us by any third party is successful, or if we fail to develop non-infringing technology or license the proprietary rights on commercially reasonable terms and conditions, our business, operating results, and financial condition could be materially and adversely affected.

[0000858877-23-000005:mdna:48]
[same as prior period, unchanged from 0000858877-22-000025:mdna:44]

[0000858877-23-000005:mdna:49]
[same as prior period, unchanged from 0000858877-22-000025:mdna:45]

[0000858877-23-000005:mdna:50]
In response to changes in industry and market conditions, we could be required to strategically realign our resources and consider restructuring, disposing of, or otherwise exiting businesses, which could result in an impairment of goodwill. There was no impairment of goodwill in each of the first six months of fiscal 2023 and 2022.

[0000858877-23-000005:mdna:51]
[same as prior period, unchanged from 0000858877-22-000025:mdna:47]

[0000858877-23-000005:mdna:52]
[same as prior period, unchanged from 0000858877-22-000025:mdna:48]

[0000858877-23-000005:mdna:53]
[same as prior period, unchanged from 0000858877-22-000025:mdna:49]

[0000858877-23-000005:mdna:54]
[same as prior period, unchanged from 0000858877-22-000025:mdna:50]

[0000858877-23-000005:mdna:55]
[same as prior period, unchanged from 0000858877-22-000025:mdna:51]

[0000858877-23-000005:mdna:56]
[same as prior period, unchanged from 0000858877-22-000025:mdna:52]

[0000858877-23-000005:mdna:57]
We are subject to income taxes in the United States and numerous foreign jurisdictions. Our effective tax rates differ from the statutory rate, primarily due to the tax impact of state taxes, foreign operations, R&D tax credits, foreign-derived intangible income deductions, global intangible low-taxed income, tax audit settlements, nondeductible compensation, and international realignments. Our effective tax rate was 18.8% and 17.5% in the second quarter of fiscal 2023 and 2022, respectively, and 21.0% and 18.0% in the first six months of fiscal 2023 and 2022, respectively.

[0000858877-23-000005:mdna:58]
[same as prior period, unchanged from 0000858877-22-000025:mdna:54]

[0000858877-23-000005:mdna:59]
[same as prior period, unchanged from 0000858877-22-000025:mdna:55]

[0000858877-23-000005:mdna:60]
[same as prior period, unchanged from 0000858877-22-000025:mdna:56]

[0000858877-23-000005:mdna:61]
[same as prior period, unchanged from 0000858877-22-000025:mdna:57]

[0000858877-23-000005:mdna:62]
[same as prior period, unchanged from 0000858877-22-000025:mdna:58]

[0000858877-23-000005:mdna:63]
[same as prior period, unchanged from 0000858877-22-000025:mdna:59]

[0000858877-23-000005:mdna:64]
[same as prior period, unchanged from 0000858877-22-000025:mdna:60]

[0000858877-23-000005:mdna:65]
[same as prior period, unchanged from 0000858877-22-000025:mdna:61]

[0000858877-23-000005:mdna:66]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 28,2023 |  | January 29,2022 |  | Variancein Dollars |  | Variance in Percent |  | January 28,2023 |  | January 29,2022 |  | Variancein Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 10,155 |  |  | $ | 9,353 |  |  | $ | 802 |  |  | 9 | % |  | $ | 20,400 |  |  | $ | 18,882 |  |  | $ | 1,518 |  |  | 8 | % |
| Percentage of revenue |  | 74.7 | % |  | 73.5 | % |  |  |  |  |  | 74.9 | % |  | 73.7 | % |  |  |  |  |
| Service |  | 3,437 |  |  | 3,367 |  |  | 70 |  |  | 2 | % |  | 6,824 |  |  | 6,738 |  |  | 86 |  |  | 1 | % |
| Percentage of revenue |  | 25.3 | % |  | 26.5 | % |  |  |  |  |  | 25.1 | % |  | 26.3 | % |  |  |  |  |
| Total |  | $ | 13,592 |  |  | $ | 12,720 |  |  | $ | 872 |  |  | 7 | % |  | $ | 27,224 |  |  | $ | 25,620 |  |  | $ | 1,604 |  |  | 6 | % |

[0000858877-23-000005:mdna:67]
[same as prior period, unchanged from 0000858877-22-000025:mdna:63]

[0000858877-23-000005:mdna:68]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 28,2023 |  | January 29,2022 |  | Variancein Dollars |  | Variance in Percent |  | January 28,2023 |  | January 29,2022 |  | Variancein Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 7,825 |  |  | $ | 7,146 |  |  | $ | 679 |  |  | 9 | % |  | $ | 15,738 |  |  | $ | 14,706 |  |  | $ | 1,032 |  |  | 7 | % |
| Percentage of revenue |  | 57.6 | % |  | 56.2 | % |  |  |  |  |  | 57.8 | % |  | 57.4 | % |  |  |  |  |
| EMEA |  | 3,728 |  |  | 3,564 |  |  | 164 |  |  | 5 | % |  | 7,404 |  |  | 6,867 |  |  | 537 |  |  | 8 | % |
| Percentage of revenue |  | 27.4 | % |  | 28.0 | % |  |  |  |  |  | 27.2 | % |  | 26.8 | % |  |  |  |  |
| APJC |  | 2,039 |  |  | 2,010 |  |  | 29 |  |  | 1 | % |  | 4,082 |  |  | 4,046 |  |  | 36 |  |  | 1 | % |
| Percentage of revenue |  | 15.0 | % |  | 15.8 | % |  |  |  |  |  | 15.0 | % |  | 15.8 | % |  |  |  |  |
| Total |  | $ | 13,592 |  |  | $ | 12,720 |  |  | $ | 872 |  |  | 7 | % |  | $ | 27,224 |  |  | $ | 25,620 |  |  | $ | 1,604 |  |  | 6 | % |

[0000858877-23-000005:mdna:69]
[same as prior period, unchanged from 0000858877-22-000025:mdna:65]

[0000858877-23-000005:mdna:70]
Three Months Ended January 28, 2023 Compared with Three Months Ended January 29, 2022

[0000858877-23-000005:mdna:71]
Total revenue increased by 7%. Product revenue increased by 9% and service revenue increased by 2%. Our total revenue reflected growth across each of our geographic segments.

[0000858877-23-000005:mdna:72]
[same as prior period, unchanged from 0000858877-22-000025:mdna:68]

[0000858877-23-000005:mdna:73]
Six Months Ended January 28, 2023 Compared with Six Months Ended January 29, 2022

[0000858877-23-000005:mdna:74]
Total revenue increased by 6%. Product revenue increased by 8% and service revenue increased by 1%. Our total revenue reflected growth across each of our geographic segments.

[0000858877-23-000005:mdna:75]
[same as prior period, unchanged from 0000858877-22-000025:mdna:69]

[0000858877-23-000005:mdna:76]
[same as prior period, unchanged from 0000858877-22-000025:mdna:70]

[0000858877-23-000005:mdna:77]
[same as prior period, unchanged from 0000858877-22-000025:mdna:71]

[0000858877-23-000005:mdna:78]
[same as prior period, unchanged from 0000858877-22-000025:mdna:72]

[0000858877-23-000005:mdna:79]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 28,2023 |  | January 29,2022 |  | Variancein Dollars |  | Variance in Percent |  | January 28,2023 |  | January 29,2022 |  | Variancein Dollars |  | Variancein Dollars |
| Product revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 5,728 |  |  | $ | 5,127 |  |  | $ | 601 |  |  | 12 | % |  | $ | 11,574 |  |  | $ | 10,649 |  |  | $ | 925 |  |  | 9 | % |
| Percentage of product revenue |  | 56.4 | % |  | 54.8 | % |  |  |  |  |  | 56.8 | % |  | 56.4 | % |  |  |  |  |
| EMEA |  | 2,917 |  |  | 2,760 |  |  | 157 |  |  | 6 | % |  | 5,803 |  |  | 5,273 |  |  | 530 |  |  | 10 | % |
| Percentage of product revenue |  | 28.7 | % |  | 29.5 | % |  |  |  |  |  | 28.4 | % |  | 27.9 | % |  |  |  |  |
| APJC |  | 1,510 |  |  | 1,466 |  |  | 44 |  |  | 3 | % |  | 3,023 |  |  | 2,961 |  |  | 62 |  |  | 2 | % |
| Percentage of product revenue |  | 14.9 | % |  | 15.7 | % |  |  |  |  |  | 14.8 | % |  | 15.7 | % |  |  |  |  |
| Total |  | $ | 10,155 |  |  | $ | 9,353 |  |  | $ | 802 |  |  | 9 | % |  | $ | 20,400 |  |  | $ | 18,882 |  |  | $ | 1,518 |  |  | 8 | % |

[0000858877-23-000005:mdna:80]
[same as prior period, unchanged from 0000858877-22-000025:mdna:74]

[0000858877-23-000005:mdna:81]
[same as prior period, unchanged from 0000858877-22-000025:mdna:76]

[0000858877-23-000005:mdna:82]
Three Months Ended January 28, 2023 Compared with Three Months Ended January 29, 2022

[0000858877-23-000005:mdna:83]
Product revenue in the Americas segment increased by 12%, with growth across all customer markets. From a country perspective, product revenue increased in the United States, Canada, Brazil and Mexico by 11%, 9%, 44% and 11%, respectively.

[0000858877-23-000005:mdna:84]
Six Months Ended January 28, 2023 Compared with Six Months Ended January 29, 2022

[0000858877-23-000005:mdna:85]
Product revenue in the Americas segment increased by 9%, with growth across all customer markets. From a country perspective, product revenue increased in the United States, Canada, Brazil and Mexico by 8%, 11%, 29% and 17%, respectively.

[0000858877-23-000005:mdna:86]
[same as prior period, unchanged from 0000858877-22-000025:mdna:78]

[0000858877-23-000005:mdna:87]
Three Months Ended January 28, 2023 Compared with Three Months Ended January 29, 2022

[0000858877-23-000005:mdna:88]
Product revenue in the EMEA segment increased by 6%, driven by growth in the public sector, enterprise and commercial markets, partially offset by a decline in the service provider market. From a country perspective, product revenue increased in Germany and France by 24% and 28%, respectively. Product revenue in the United Kingdom was flat.

[0000858877-23-000005:mdna:89]
Six Months Ended January 28, 2023 Compared with Six Months Ended January 29, 2022

[0000858877-23-000005:mdna:90]
Product revenue in the EMEA segment increased by 10%, driven by growth in the public sector, commercial and enterprise markets, partially offset by a decline in the service provider market. From a country perspective, product revenue increased in Germany, the United Kingdom and France by 22%, 3% and 29%, respectively.

[0000858877-23-000005:mdna:91]
[same as prior period, unchanged from 0000858877-22-000025:mdna:80]

[0000858877-23-000005:mdna:92]
Three Months Ended January 28, 2023 Compared with Three Months Ended January 29, 2022

[0000858877-23-000005:mdna:93]
Product revenue in the APJC segment increased by 3%, driven by growth in the commercial and public sector markets, partially offset by a decline in the enterprise market. The service provider market in this geographic segment was flat. From a country perspective, product revenue increased in India, Australia and China by 59%, 4% and 20%, respectively, partially offset by a decline in Japan of 12%.

[0000858877-23-000005:mdna:94]
Six Months Ended January 28, 2023 Compared with Six Months Ended January 29, 2022

[0000858877-23-000005:mdna:95]
Product revenue in the APJC segment increased by 2%, driven by growth in the commercial and public sector markets, partially offset by declines in the enterprise and service provider markets. From a country perspective, product revenue increased in India and China by 49% and 27%, respectively, partially offset by declines in Japan and Australia of 11% and 2%, respectively.

[0000858877-23-000005:mdna:96]
[same as prior period, unchanged from 0000858877-22-000025:mdna:82]

[0000858877-23-000005:mdna:97]
[same as prior period, unchanged from 0000858877-22-000025:mdna:83]

[0000858877-23-000005:mdna:98]
[same as prior period, unchanged from 0000858877-22-000025:mdna:84]

[0000858877-23-000005:mdna:99]
[same as prior period, unchanged from 0000858877-22-000025:mdna:85]

[0000858877-23-000005:mdna:100]
[same as prior period, unchanged from 0000858877-22-000025:mdna:86]

[0000858877-23-000005:mdna:101]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 28,2023 |  | January 29,2022 |  | Variancein Dollars |  | Variance in Percent |  | January 28,2023 |  | January 29,2022 |  | Variancein Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Secure, Agile Networks |  | $ | 6,746 |  |  | $ | 5,899 |  |  | $ | 847 |  |  | 14 | % |  | $ | 13,430 |  |  | $ | 11,867 |  |  | $ | 1,563 |  |  | 13 | % |
| Internet for the Future |  | 1,306 |  |  | 1,322 |  |  | (16) |  |  | (1) | % |  | 2,616 |  |  | 2,695 |  |  | (79) |  |  | (3) | % |
| Collaboration |  | 958 |  |  | 1,067 |  |  | (109) |  |  | (10) | % |  | 2,044 |  |  | 2,176 |  |  | (132) |  |  | (6) | % |
| End-to-End Security |  | 943 |  |  | 883 |  |  | 60 |  |  | 7 | % |  | 1,914 |  |  | 1,778 |  |  | 136 |  |  | 8 | % |
| Optimized Application Experiences |  | 199 |  |  | 180 |  |  | 19 |  |  | 11 | % |  | 393 |  |  | 361 |  |  | 32 |  |  | 9 | % |
| Other Products |  | 3 |  |  | 2 |  |  | 1 |  |  | 25 | % |  | 4 |  |  | 5 |  |  | (1) |  |  | (17) | % |
| Total |  | $ | 10,155 |  |  | $ | 9,353 |  |  | $ | 802 |  |  | 9 | % |  | $ | 20,400 |  |  | $ | 18,882 |  |  | $ | 1,518 |  |  | 8 | % |

[0000858877-23-000005:mdna:102]
[same as prior period, unchanged from 0000858877-22-000025:mdna:88]

[0000858877-23-000005:mdna:103]
[same as prior period, unchanged from 0000858877-22-000025:mdna:90]

[0000858877-23-000005:mdna:104]
Three Months Ended January 28, 2023 Compared with Three Months Ended January 29, 2022

[0000858877-23-000005:mdna:105]
The Secure, Agile Networks product category represents our core networking offerings related to switching, enterprise routing, wireless, and compute. Secure, Agile Networks revenue increased by 14%, or $847 million, with growth across the portfolio except servers. Revenue grew in campus switching, primarily driven by strong growth in our Catalyst 9000 series and Meraki switching offerings. Data center switching revenue declined, although we had revenue growth in our Nexus 9000 series. Enterprise routing had strong growth primarily driven by our Catalyst 8000 series, SD-WAN and IoT routing offerings. Wireless had strong double-digit growth driven by our WiFi-6 products and Meraki offerings.

[0000858877-23-000005:mdna:106]
Six Months Ended January 28, 2023 Compared with Six Months Ended January 29, 2022

[0000858877-23-000005:mdna:107]
Revenue from the Secure, Agile Networks product category increased by 13%, or $1.6 billion, with growth across the portfolio except servers. Revenue grew in campus switching primarily driven by growth in our Catalyst 9000 series and Meraki switching offerings. Data center switching revenue declined, although we had revenue growth in our Nexus 9000 series. The increase in enterprise routing was primarily driven by growth in our Catalyst 8000 series and SD-WAN offerings. Wireless had strong double-digit growth driven by our WiFi-6 products and Meraki offerings.

[0000858877-23-000005:mdna:108]
[same as prior period, unchanged from 0000858877-22-000025:mdna:92]

[0000858877-23-000005:mdna:109]
Three Months Ended January 28, 2023 Compared with Three Months Ended January 29, 2022

[0000858877-23-000005:mdna:110]
The Internet for the Future product category includes our routed optical networking, public 5G, silicon and optics offerings. Revenue in our Internet for the Future product category decreased by 1%, or $16 million, primarily driven by declines in our Optical and Edge portfolio, partially offset by growth in our Cisco 8000 series offerings. We also saw growth in the webscale provider market.

[0000858877-23-000005:mdna:111]
Six Months Ended January 28, 2023 Compared with Six Months Ended January 29, 2022

[0000858877-23-000005:mdna:112]
Revenue in our Internet for the Future product category decreased by 3%, or $79 million, primarily driven by declines in our Cable, Optical and Edge portfolio, partially offset by growth in our Cisco 8000 series offerings. We also saw growth in the webscale provider market.

[0000858877-23-000005:mdna:113]
[same as prior period, unchanged from 0000858877-22-000025:mdna:94]

[0000858877-23-000005:mdna:114]
Three Months Ended January 28, 2023 Compared with Three Months Ended January 29, 2022

[0000858877-23-000005:mdna:115]
The Collaboration product category consists of our Collaboration Devices, Meetings, Calling and contact center offerings. Revenue in our Collaboration product category decreased by 10%, or $109 million, primarily driven by declines in Meetings and Collaboration Devices, partially offset by growth in our contact center offerings.

[0000858877-23-000005:mdna:116]
[same as prior period, unchanged from 0000858877-22-000025:mdna:100]

[0000858877-23-000005:mdna:117]
[same as prior period, unchanged from 0000858877-22-000025:mdna:101]

[0000858877-23-000005:mdna:118]
Six Months Ended January 28, 2023 Compared with Six Months Ended January 29, 2022

[0000858877-23-000005:mdna:119]
Revenue in our Collaboration product category decreased by 6%, or $132 million, primarily driven by declines in Meetings and Collaboration Devices.

[0000858877-23-000005:mdna:120]
[same as prior period, unchanged from 0000858877-22-000025:mdna:96]

[0000858877-23-000005:mdna:121]
Three Months Ended January 28, 2023 Compared with Three Months Ended January 29, 2022

[0000858877-23-000005:mdna:122]
Revenue in our End-to-End Security product category increased 7%, or $60 million primarily driven by growth in our Unified Threat Management and Zero Trust offerings.

[0000858877-23-000005:mdna:123]
Six Months Ended January 28, 2023 Compared with Six Months Ended January 29, 2022

[0000858877-23-000005:mdna:124]
Revenue in our End-to-End Security product category increased 8%, or $136 million primarily driven by growth in our Unified Threat Management and Zero Trust offerings. The growth in our Zero Trust portfolio was driven by strong growth in our Duo offerings.

[0000858877-23-000005:mdna:125]
[same as prior period, unchanged from 0000858877-22-000025:mdna:98]

[0000858877-23-000005:mdna:126]
Three Months Ended January 28, 2023 Compared with Three Months Ended January 29, 2022

[0000858877-23-000005:mdna:127]
The Optimized Application Experiences product category includes our full stack observability and cloud-native platforms offerings. Revenue in our Optimized Application Experiences product category increased 11%, or $19 million, driven by growth in our ThousandEyes offerings.

[0000858877-23-000005:mdna:128]
Six Months Ended January 28, 2023 Compared with Six Months Ended January 29, 2022

[0000858877-23-000005:mdna:129]
Revenue in our Optimized Application Experiences product category increased 9%, or $32 million, driven by growth in our ThousandEyes offerings.

[0000858877-23-000005:mdna:130]
[same as prior period, unchanged from 0000858877-22-000025:mdna:102]

[0000858877-23-000005:mdna:131]
[same as prior period, unchanged from 0000858877-22-000025:mdna:103]

[0000858877-23-000005:mdna:132]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 28,2023 |  | January 29,2022 |  | Variancein Dollars |  | Variance in Percent |  | January 28,2023 |  | January 29,2022 |  | Variancein Dollars |  | Variance in Percent |
| Service revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 2,097 |  |  | $ | 2,019 |  |  | $ | 78 |  |  | 4 | % |  | $ | 4,164 |  |  | $ | 4,057 |  |  | $ | 107 |  |  | 3 | % |
| Percentage of service revenue |  | 61.0 | % |  | 60.0 | % |  |  |  |  |  | 61.0 | % |  | 60.2 | % |  |  |  |  |
| EMEA |  | 812 |  |  | 804 |  |  | 8 |  |  | 1 | % |  | 1,601 |  |  | 1,594 |  |  | 7 |  |  | — | % |
| Percentage of service revenue |  | 23.6 | % |  | 23.9 | % |  |  |  |  |  | 23.5 | % |  | 23.7 | % |  |  |  |  |
| APJC |  | 529 |  |  | 544 |  |  | (15) |  |  | (3) | % |  | 1,059 |  |  | 1,086 |  |  | (27) |  |  | (2) | % |
| Percentage of service revenue |  | 15.4 | % |  | 16.1 | % |  |  |  |  |  | 15.5 | % |  | 16.1 | % |  |  |  |  |
| Total |  | $ | 3,437 |  |  | $ | 3,367 |  |  | $ | 70 |  |  | 2 | % |  | $ | 6,824 |  |  | $ | 6,738 |  |  | $ | 86 |  |  | 1 | % |

[0000858877-23-000005:mdna:133]
[same as prior period, unchanged from 0000858877-22-000025:mdna:105]

[0000858877-23-000005:mdna:134]
Service revenue increased 2% in the second quarter of fiscal 2023 compared with the second quarter of fiscal 2022, primarily driven by revenue growth in our solution support offerings and maintenance business, partially offset by declines in our advisory services and software support offerings. Service revenue increased in the Americas and EMEA segments, partially offset by a decline in the APJC segment for the second quarter of fiscal 2023.

[0000858877-23-000005:mdna:135]
Service revenue increased 1% in the first six months of fiscal 2023 compared to the first six months of fiscal 2022, primarily driven by revenue growth in our solution support offerings and maintenance business, offset by declines in our advisory services and software support offerings. Service revenue increased in the Americas segment, partially offset by a decline in the APJC segment for the first six months of fiscal 2023. Service revenue for the EMEA segment was flat.

[0000858877-23-000005:mdna:136]
[same as prior period, unchanged from 0000858877-22-000025:mdna:116]

[0000858877-23-000005:mdna:137]
[same as prior period, unchanged from 0000858877-22-000025:mdna:117]

[0000858877-23-000005:mdna:138]
[same as prior period, unchanged from 0000858877-22-000025:mdna:107]

[0000858877-23-000005:mdna:139]
[same as prior period, unchanged from 0000858877-22-000025:mdna:108]

[0000858877-23-000005:mdna:140]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | AMOUNT |  | PERCENTAGE |  | AMOUNT |  | PERCENTAGE |
|  |  | January 28,2023 |  | January 29,2022 |  | January 28,2023 |  | January 29,2022 |  | January 28,2023 |  | January 29,2022 |  | January 28,2023 |  | January 29,2022 |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 6,117 |  |  | $ | 5,784 |  |  | 60.2 | % |  | 61.8 | % |  | $ | 12,183 |  |  | $ | 11,640 |  |  | 59.7 | % |  | 61.6 | % |
| Service |  | 2,310 |  |  | 2,265 |  |  | 67.2 | % |  | 67.3 | % |  | 4,590 |  |  | 4,462 |  |  | 67.3 | % |  | 66.2 | % |
| Total |  | $ | 8,427 |  |  | $ | 8,049 |  |  | 62.0 | % |  | 63.3 | % |  | $ | 16,773 |  |  | $ | 16,102 |  |  | 61.6 | % |  | 62.8 | % |

[0000858877-23-000005:mdna:141]
[same as prior period, unchanged from 0000858877-22-000025:mdna:110]

[0000858877-23-000005:mdna:142]
The following table summarizes the key factors that contributed to the change in product gross margin percentage for the second quarter and first six months of fiscal 2023, as compared with the corresponding prior year periods:

[0000858877-23-000005:mdna:143]
|  |  | Product Gross Margin Percentage |
|  |  | Three Months Ended |  | Six Months Ended |
| Fiscal 2022 |  | 61.8 | % |  | 61.6 | % |
| Productivity (1) |  | (4.3) | % |  | (4.4) | % |
| Product pricing |  | 1.3 | % |  | 1.4 | % |
| Mix of products sold |  | 0.9 | % |  | 0.5 | % |
| Others |  | 0.5 | % |  | 0.6 | % |
| Fiscal 2023 |  | 60.2 | % |  | 59.7 | % |

[0000858877-23-000005:mdna:144]
[same as prior period, unchanged from 0000858877-22-000025:mdna:113]

[0000858877-23-000005:mdna:145]
Three Months Ended January 28, 2023 Compared with Three Months Ended January 29, 2022

[0000858877-23-000005:mdna:146]
Product gross margin decreased by 1.6 percentage points primarily driven by negative impacts from productivity, largely driven by increased costs related to supply constraints from component and other costs. These impacts were partially offset by favorable pricing and product mix. The favorable pricing was primarily driven by price increases implemented during fiscal 2022. These benefits are recognized as we ship our products. We implemented the price increases to partially offset increases in commodity and other costs.

[0000858877-23-000005:mdna:147]
Six Months Ended January 28, 2023 Compared with Six Months Ended January 29, 2022

[0000858877-23-000005:mdna:148]
Product gross margin decreased by 1.9 percentage points primarily driven by negative impacts from productivity, largely driven by increased costs related to supply constraints from component, freight, logistics and other costs. These impacts were partially offset by favorable pricing. The benefit we saw from favorable pricing was primarily driven by price increases implemented during fiscal 2022. We also saw benefits from product mix.

[0000858877-23-000005:mdna:149]
[same as prior period, unchanged from 0000858877-22-000025:mdna:119]

[0000858877-23-000005:mdna:150]
While we saw further improvements in the second quarter of fiscal 2023, we continue to manage through significant supply constraints seen industry-wide due to component shortages caused, in part, by the COVID-19 pandemic, and for which the duration of such constraints is uncertain. These shortages have resulted in increased costs (i.e., component and other commodity costs, freight, expedite fees, etc.) which have had a negative impact on our product gross margin and have resulted in extended lead times for us and our customers. We have taken a number of steps in order to mitigate the supply constraint related impacts including: partnering with several of our key suppliers utilizing our volume purchasing ability and extending supply coverage, including, in certain cases, revising supplier arrangements; paying significantly higher component and logistics costs to secure supply; modifying our product designs in order to leverage alternate suppliers, where possible; and continually optimizing our inventory build and customer delivery plans, among others. We believe these actions are helping us to optimize our access to critical components and meet customer demand for our products. As a result, in order to secure supply to meet customer

[0000858877-23-000005:mdna:151]
[same as prior period, unchanged from 0000858877-22-000025:mdna:131]

[0000858877-23-000005:mdna:152]
[same as prior period, unchanged from 0000858877-22-000025:mdna:132]

[0000858877-23-000005:mdna:153]
demand, we have increased our inventory balances, inventory purchase commitments, and inventory deposits and prepayments (see “Liquidity and Capital Resources—Inventory Supply Chain”), which, in turn, has increased our supply chain exposure. Additionally, in certain situations, we have prepaid or made deposits with suppliers to secure future supply. These actions significantly increase the risk of future material excess and obsolete inventory and related losses if customer demand were to suddenly and significantly decrease in future periods. While we believe we are taking the right strategic and operational actions to address the supply situation, we recognize the increased risks.

[0000858877-23-000005:mdna:154]
[same as prior period, unchanged from 0000858877-22-000025:mdna:121]

[0000858877-23-000005:mdna:155]
Three Months Ended January 28, 2023 Compared with Three Months Ended January 29, 2022

[0000858877-23-000005:mdna:156]
Our service gross margin percentage decreased by 0.1 percentage points primarily due to higher headcount-related and delivery costs, partially offset by higher sales volume and favorable mix of service offerings.

[0000858877-23-000005:mdna:157]
[same as prior period, unchanged from 0000858877-22-000025:mdna:124]

[0000858877-23-000005:mdna:158]
Six Months Ended January 28, 2023 Compared with Six Months Ended January 29, 2022

[0000858877-23-000005:mdna:159]
Service gross margin increased by 1.1 percentage points primarily due to favorable mix of service offerings, higher sales volume and lower headcount-related and delivery costs.

[0000858877-23-000005:mdna:160]
[same as prior period, unchanged from 0000858877-22-000025:mdna:125]

[0000858877-23-000005:mdna:161]
[same as prior period, unchanged from 0000858877-22-000025:mdna:126]

[0000858877-23-000005:mdna:162]
|  | Three Months Ended |  | Six Months Ended |
|  | AMOUNT |  | PERCENTAGE |  | AMOUNT |  | PERCENTAGE |
|  | January 28,2023 |  | January 29,2022 |  | January 28,2023 |  | January 29,2022 |  | January 28,2023 |  | January 29,2022 |  | January 28,2023 |  | January 29,2022 |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 4,920 |  |  | $ | 4,611 |  |  | 62.9 | % |  | 64.5 | % |  | $ | 9,904 |  |  | $ | 9,486 |  |  | 62.9 | % |  | 64.5 | % |
| EMEA | 2,469 |  |  | 2,381 |  |  | 66.2 | % |  | 66.8 | % |  | 4,795 |  |  | 4,509 |  |  | 64.8 | % |  | 65.7 | % |
| APJC | 1,298 |  |  | 1,337 |  |  | 63.6 | % |  | 66.5 | % |  | 2,571 |  |  | 2,654 |  |  | 63.0 | % |  | 65.6 | % |
| Segment total | 8,687 |  |  | 8,328 |  |  | 63.9 | % |  | 65.5 | % |  | 17,269 |  |  | 16,649 |  |  | 63.4 | % |  | 65.0 | % |
| Unallocated corporate items (1) | (260) |  |  | (279) |  |  |  |  |  |  | (496) |  |  | (547) |  |  |  |  |  |
| Total | $ | 8,427 |  |  | $ | 8,049 |  |  | 62.0 | % |  | 63.3 | % |  | $ | 16,773 |  |  | $ | 16,102 |  |  | 61.6 | % |  | 62.8 | % |

[0000858877-23-000005:mdna:163]
(1) The unallocated corporate items include the effects of amortization and impairments of acquisition-related intangible assets, share-based compensation expense, significant litigation settlements and other contingencies, charges related to asset impairments and restructurings, and certain other charges. We do not allocate these items to the gross margin for each segment because management does not include such information in measuring the performance of the operating segments.

[0000858877-23-000005:mdna:164]
[same as prior period, unchanged from 0000858877-22-000025:mdna:129]

[0000858877-23-000005:mdna:165]
Three Months Ended January 28, 2023 Compared with Three Months Ended January 29, 2022

[0000858877-23-000005:mdna:166]
[same as prior period, unchanged from 0000858877-22-000025:mdna:134]

[0000858877-23-000005:mdna:167]
Gross margin in our EMEA segment decreased primarily due to negative impacts from productivity, partially offset by favorable pricing and favorable product mix.

[0000858877-23-000005:mdna:168]
The APJC segment gross margin percentage decrease was primarily due to negative impacts from productivity, and to a lesser extent, unfavorable impacts from product mix, partially offset by favorable pricing and higher service gross margin.

[0000858877-23-000005:mdna:169]
[same as prior period, unchanged from 0000858877-22-000025:mdna:137]

[0000858877-23-000005:mdna:170]
52

[0000858877-23-000005:mdna:171]
[same as prior period, unchanged from 0000858877-22-000025:mdna:149]

[0000858877-23-000005:mdna:172]
[same as prior period, unchanged from 0000858877-22-000025:mdna:150]

[0000858877-23-000005:mdna:173]
Six Months Ended January 28, 2023 Compared with Six Months Ended January 29, 2022

[0000858877-23-000005:mdna:174]
The Americas segment had a gross margin percentage decrease driven by negative impacts from productivity, partially offset by  favorable pricing and favorable product mix.

[0000858877-23-000005:mdna:175]
The gross margin percentage decrease in our EMEA segment was primarily due to negative impacts from productivity, and to a lesser extent, unfavorable impacts from product mix, partially offset by favorable pricing.

[0000858877-23-000005:mdna:176]
The APJC segment gross margin percentage decrease was driven by negative impacts from productivity and unfavorable impacts from pricing, partially offset by favorable product mix.

[0000858877-23-000005:mdna:177]
[same as prior period, unchanged from 0000858877-22-000025:mdna:138]

[0000858877-23-000005:mdna:178]
[same as prior period, unchanged from 0000858877-22-000025:mdna:139]

[0000858877-23-000005:mdna:179]
|  | Three Months Ended |  | Six Months Ended |
|  | January 28,2023 |  | January 29,2022 |  | Variancein Dollars |  | Variance in Percent |  | January 28,2023 |  | January 29,2022 |  | Variancein Dollars |  | Variance in Percent |
| Research and development | $ | 1,855 |  |  | $ | 1,670 |  |  | $ | 185 |  |  | 11 | % |  | $ | 3,636 |  |  | $ | 3,384 |  |  | $ | 252 |  |  | 7 | % |
| Percentage of revenue | 13.6 | % |  | 13.1 | % |  |  |  |  |  | 13.4 | % |  | 13.2 | % |  |  |  |  |
| Sales and marketing | 2,384 |  |  | 2,266 |  |  | 118 |  |  | 5 | % |  | 4,775 |  |  | 4,527 |  |  | 248 |  |  | 5 | % |
| Percentage of revenue | 17.5 | % |  | 17.8 | % |  |  |  |  |  | 17.5 | % |  | 17.7 | % |  |  |  |  |
| General and administrative | 582 |  |  | 544 |  |  | 38 |  |  | 7 | % |  | 1,147 |  |  | 1,095 |  |  | 52 |  |  | 5 | % |
| Percentage of revenue | 4.3 | % |  | 4.3 | % |  |  |  |  |  | 4.2 | % |  | 4.3 | % |  |  |  |  |
| Total | $ | 4,821 |  |  | $ | 4,480 |  |  | $ | 341 |  |  | 8 | % |  | $ | 9,558 |  |  | $ | 9,006 |  |  | $ | 552 |  |  | 6 | % |
| Percentage of revenue | 35.5 | % |  | 35.2 | % |  |  |  |  |  | 35.1 | % |  | 35.2 | % |  |  |  |  |

[0000858877-23-000005:mdna:180]
[same as prior period, unchanged from 0000858877-22-000025:mdna:142]

[0000858877-23-000005:mdna:181]
Three Months Ended January 28, 2023 Compared with Three Months Ended January 29, 2022

[0000858877-23-000005:mdna:182]
R&D expenses increased due to higher headcount-related expenses, higher share-based compensation expense and higher discretionary spending, partially offset by lower contracted services spending.

[0000858877-23-000005:mdna:183]
[same as prior period, unchanged from 0000858877-22-000025:mdna:144]

[0000858877-23-000005:mdna:184]
Six Months Ended January 28, 2023 Compared with Six Months Ended January 29, 2022

[0000858877-23-000005:mdna:185]
[same as prior period, unchanged from 0000858877-22-000025:mdna:143]

[0000858877-23-000005:mdna:186]
[same as prior period, unchanged from 0000858877-22-000025:mdna:145]

[0000858877-23-000005:mdna:187]
Three Months Ended January 28, 2023 Compared with Three Months Ended January 29, 2022

[0000858877-23-000005:mdna:188]
Sales and marketing expenses increased primarily due to higher headcount-related expenses, higher share-based compensation expense and higher discretionary spending, partially offset by lower contracted services spending.

[0000858877-23-000005:mdna:189]
Six Months Ended January 28, 2023 Compared with Six Months Ended January 29, 2022

[0000858877-23-000005:mdna:190]
Sales and marketing expenses increased primarily due to higher headcount-related expenses, higher discretionary spending and higher share-based compensation expense, partially offset by lower contracted services spending.

[0000858877-23-000005:mdna:191]
[same as prior period, unchanged from 0000858877-22-000025:mdna:147]

[0000858877-23-000005:mdna:192]
For each of the second quarter and first six months of fiscal 2023, G&A expenses increased due to higher headcount-related expenses, higher discretionary spending and higher share-based compensation expense, partially offset by lower contracted services spending and lower acquisition and divestitures related costs.

[0000858877-23-000005:mdna:193]
[same as prior period, unchanged from 0000858877-22-000025:mdna:164]

[0000858877-23-000005:mdna:194]
[same as prior period, unchanged from 0000858877-22-000025:mdna:165]

[0000858877-23-000005:mdna:195]
[same as prior period, unchanged from 0000858877-22-000025:mdna:151]

[0000858877-23-000005:mdna:196]
In the second quarter of fiscal 2023, foreign currency fluctuations, net of hedging, decreased the combined R&D, sales and marketing, and G&A expenses by approximately $121 million, or 3.2%, compared with the second quarter of fiscal 2022.

[0000858877-23-000005:mdna:197]
In the first six months of fiscal 2023, foreign currency fluctuations, net of hedging, decreased the combined R&D, sales and marketing, and G&A expenses by approximately $263 million, or 2.9%, compared with the first six months of fiscal 2022.

[0000858877-23-000005:mdna:198]
[same as prior period, unchanged from 0000858877-22-000025:mdna:153]

[0000858877-23-000005:mdna:199]
[same as prior period, unchanged from 0000858877-22-000025:mdna:154]

[0000858877-23-000005:mdna:200]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 28,2023 |  | January 29,2022 |  | January 28,2023 |  | January 29,2022 |
| Amortization of purchased intangible assets: |  |  |  |  |  |  |  |  |
| Cost of sales |  | $ | 158 |  |  | $ | 201 |  |  | $ | 316 |  |  | $ | 403 |  |
| Operating expenses |  | 71 |  |  | 79 |  |  | 142 |  |  | 163 |  |
| Total |  | $ | 229 |  |  | $ | 280 |  |  | $ | 458 |  |  | $ | 566 |  |

[0000858877-23-000005:mdna:201]
For each of the second quarter and first six months of fiscal 2023, the decrease in amortization of purchased intangible assets was primarily due to certain purchased intangible assets that became fully amortized, partially offset by amortization of purchased intangibles from our recent acquisitions.

[0000858877-23-000005:mdna:202]
[same as prior period, unchanged from 0000858877-22-000025:mdna:157]

[0000858877-23-000005:mdna:203]
In the second quarter of fiscal 2023, we announced a restructuring plan in order to rebalance the organization and enable further investment in key priority areas. This rebalancing includes talent movement options and restructuring. Additionally, we have begun optimizing our real estate portfolio, aligned to the broader hybrid work strategy. The total pretax charges are estimated to be approximately $600 million and is expected to impact approximately 5% of our global workforce. In connection with this restructuring plan, we incurred charges of $243 million in the second quarter and the first six months of fiscal 2023. We expect the plan to be substantially completed by the end of the first quarter of fiscal 2024. We expect to reinvest substantially all of the cost savings from this restructuring plan in our key priority areas. As a result, the overall cost savings from this restructuring plan are not expected to be material for future periods.

[0000858877-23-000005:mdna:204]
[same as prior period, unchanged from 0000858877-22-000025:mdna:159]

[0000858877-23-000005:mdna:205]
[same as prior period, unchanged from 0000858877-22-000025:mdna:160]

[0000858877-23-000005:mdna:206]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 28,2023 |  | January 29,2022 |  | January 28,2023 |  | January 29,2022 |
| Operating income |  | $ | 3,292 |  |  | $ | 3,487 |  |  | $ | 6,832 |  |  | $ | 6,925 |  |
| Operating income as a percentage of revenue |  | 24.2 | % |  | 27.4 | % |  | 25.1 | % |  | 27.0 | % |

[0000858877-23-000005:mdna:207]
Three Months Ended January 28, 2023 Compared with Three Months Ended January 29, 2022

[0000858877-23-000005:mdna:208]
Operating income decreased by 6%, and operating income as a percentage of revenue decreased by 3.2 percentage points. These changes resulted primarily due to a gross margin percentage decrease (driven by negative impacts from productivity partially offset by favorable pricing and favorable product mix) and higher restructuring and other charges, partially offset by a revenue increase.

[0000858877-23-000005:mdna:209]
Six Months Ended January 28, 2023 Compared with Six Months Ended January 29, 2022

[0000858877-23-000005:mdna:210]
Operating income decreased by 1%, and operating income as a percentage of revenue decreased by 1.9 percentage points. These changes resulted primarily from a gross margin percentage decrease (driven by negative impacts from productivity, partially offset by favorable pricing, and to a lesser extent, favorable product mix) and higher restructuring and other charges, partially offset by a revenue increase.

[0000858877-23-000005:mdna:211]
[same as prior period, unchanged from 0000858877-22-000025:mdna:214]

[0000858877-23-000005:mdna:212]
[same as prior period, unchanged from 0000858877-22-000025:mdna:177]

[0000858877-23-000005:mdna:213]
[same as prior period, unchanged from 0000858877-22-000025:mdna:178]

[0000858877-23-000005:mdna:214]
[same as prior period, unchanged from 0000858877-22-000025:mdna:166]

[0000858877-23-000005:mdna:215]
[same as prior period, unchanged from 0000858877-22-000025:mdna:167]

[0000858877-23-000005:mdna:216]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 28,2023 |  | January 29,2022 |  | Variancein Dollars |  | January 28,2023 |  | January 29,2022 |  | Variancein Dollars |
| Interest income |  | $ | 219 |  |  | $ | 111 |  |  | $ | 108 |  |  | $ | 388 |  |  | $ | 232 |  |  | $ | 156 |  |
| Interest expense |  | (107) |  |  | (88) |  |  | (19) |  |  | (207) |  |  | (177) |  |  | (30) |  |
| Interest income (expense), net |  | $ | 112 |  |  | $ | 23 |  |  | $ | 89 |  |  | $ | 181 |  |  | $ | 55 |  |  | $ | 126 |  |

[0000858877-23-000005:mdna:217]
For the each of the second quarter and first six months of fiscal 2023, the increase in interest income was driven by higher average balance of cash and available-for-sale debt investments and higher interest rates. The increase in interest expense was primarily driven by higher interest rates, partially offset by a lower average debt balance.

[0000858877-23-000005:mdna:218]
[same as prior period, unchanged from 0000858877-22-000025:mdna:170]

[0000858877-23-000005:mdna:219]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 28,2023 |  | January 29,2022 |  | Variancein Dollars |  | January 28,2023 |  | January 29,2022 |  | Variancein Dollars |
| Gains (losses) on investments, net: |  |  |  |  |  |  |  |  |  |  |  |  |
| Available-for-sale debt investments |  | $ | (3) |  |  | $ | 10 |  |  | $ | (13) |  |  | $ | (9) |  |  | $ | 16 |  |  | $ | (25) |  |
| Marketable equity investments |  | 19 |  |  | (18) |  |  | 37 |  |  | (2) |  |  | (13) |  |  | 11 |  |
| Privately held investments |  | 19 |  |  | 121 |  |  | (102) |  |  | (73) |  |  | 326 |  |  | (399) |  |
| Net gains (losses) on investments |  | 35 |  |  | 113 |  |  | (78) |  |  | (84) |  |  | 329 |  |  | (413) |  |
| Other gains (losses), net |  | (24) |  |  | (20) |  |  | (4) |  |  | (39) |  |  | (49) |  |  | 10 |  |
| Other income (loss), net |  | $ | 11 |  |  | $ | 93 |  |  | $ | (82) |  |  | $ | (123) |  |  | $ | 280 |  |  | $ | (403) |  |

[0000858877-23-000005:mdna:220]
Three Months Ended January 28, 2023 Compared with Three Months Ended January 29, 2022

[0000858877-23-000005:mdna:221]
The decrease in our other income (loss), net was primarily driven by lower unrealized gains on our privately held investments and changes in net gains (losses) on available-for-sale debt investments and marketable equity investments.

[0000858877-23-000005:mdna:222]
Six Months Ended January 28, 2023 Compared with Six Months Ended January 29, 2022

[0000858877-23-000005:mdna:223]
The decrease in our other income (loss), net was primarily driven by realized and unrealized losses on our privately held investments.

[0000858877-23-000005:mdna:224]
[same as prior period, unchanged from 0000858877-22-000025:mdna:174]

[0000858877-23-000005:mdna:225]
Three Months Ended January 28, 2023 Compared with Three Months Ended January 29, 2022

[0000858877-23-000005:mdna:226]
The provision for income taxes resulted in an effective tax rate of 18.8% for the second quarter of fiscal 2023 compared with 17.5% for the second quarter of fiscal 2022. The increase in the effective tax rate was primarily due to a decrease in stock based compensation windfall and the impact of new U.S. foreign tax credit regulations effective for fiscal 2023. The increase was partially offset by a U.S. foreign-derived intangible income deduction benefit driven by the capitalization and amortization of R&D expenses effective for fiscal 2023 as required by the Tax Cuts and Jobs Act.

[0000858877-23-000005:mdna:227]
Six Months Ended January 28, 2023 Compared with Six Months Ended January 29, 2022

[0000858877-23-000005:mdna:228]
The provision for income taxes resulted in an effective tax rate of 21.0% for the first six months of fiscal 2023 compared with 18.0% for the first six months of fiscal 2022. The increase in the effective tax rate was primarily due to an increase in net discrete tax expenses, a decrease in stock based compensation windfall, and the impact of new U.S. foreign tax credit regulations effective for fiscal 2023. The increase was partially offset by a U.S. foreign-derived intangible income deduction benefit driven by the capitalization and amortization of R&D expenses effective for fiscal 2023 as required by the Tax Cuts and Jobs Act.

[0000858877-23-000005:mdna:229]
55

[0000858877-23-000005:mdna:230]
[same as prior period, unchanged from 0000858877-22-000025:mdna:191]

[0000858877-23-000005:mdna:231]
[same as prior period, unchanged from 0000858877-22-000025:mdna:192]

[0000858877-23-000005:mdna:232]
[same as prior period, unchanged from 0000858877-22-000025:mdna:179]

[0000858877-23-000005:mdna:233]
[same as prior period, unchanged from 0000858877-22-000025:mdna:180]

[0000858877-23-000005:mdna:234]
[same as prior period, unchanged from 0000858877-22-000025:mdna:181]

[0000858877-23-000005:mdna:235]
[same as prior period, unchanged from 0000858877-22-000025:mdna:182]

[0000858877-23-000005:mdna:236]
|  | January 28,2023 |  | July 30,2022 |  | Increase (Decrease) |
| Cash and cash equivalents | $ | 9,009 |  |  | $ | 7,079 |  |  | $ | 1,930 |  |
| Available-for-sale debt investments | 12,772 |  |  | 11,947 |  |  | 825 |  |
| Marketable equity securities | 280 |  |  | 241 |  |  | 39 |  |
| Total | $ | 22,061 |  |  | $ | 19,267 |  |  | $ | 2,794 |  |

[0000858877-23-000005:mdna:237]
The net increase in cash and cash equivalents and investments in the first six months of fiscal 2023 was primarily driven by cash provided by operating activities of $8.7 billion. This source of cash was partially offset by cash returned to stockholders in the form of repurchases of common stock of $1.8 billion and cash dividends of $3.1 billion, a net decrease of debt of $0.6 billion and capital expenditures of $0.3 billion.

[0000858877-23-000005:mdna:238]
In the second quarter of fiscal 2023, we deferred our federal tax payment due to the IRS tax relief related to the California floods. We expect our cash paid for income taxes for the second half of fiscal 2023 to increase as a result of payment of the previously deferred second quarter federal tax payment and the effects of capitalization and amortization of R&D expenses as required by the Tax Cuts and Jobs Act.

[0000858877-23-000005:mdna:239]
[same as prior period, unchanged from 0000858877-22-000025:mdna:185]

[0000858877-23-000005:mdna:240]
Securities Lending   We periodically engage in securities lending activities with certain of our available-for-sale debt investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. We require collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. We engage in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify us against collateral losses. We did not experience any losses in connection with the secured lending of securities during the periods presented. As of January 28, 2023 and July 30, 2022, we had no outstanding securities lending transactions.

[0000858877-23-000005:mdna:241]
[same as prior period, unchanged from 0000858877-22-000025:mdna:187]

[0000858877-23-000005:mdna:242]
[same as prior period, unchanged from 0000858877-22-000025:mdna:188]

[0000858877-23-000005:mdna:243]
|  | Six Months Ended |
|  | January 28,2023 |  | January 29,2022 |
| Net cash provided by operating activities | $ | 8,701 |  |  | $ | 5,888 |  |
| Acquisition of property and equipment | (346) |  |  | (232) |  |
| Free cash flow | $ | 8,355 |  |  | $ | 5,656 |  |

[0000858877-23-000005:mdna:244]
We expect that cash provided by operating activities may fluctuate in future periods as a result of a number of factors, including fluctuations in our operating results, the rate at which products are shipped during the quarter (which we refer to as shipment linearity), the timing and collection of accounts receivable and financing receivables, inventory and supply chain management,

[0000858877-23-000005:mdna:245]
[same as prior period, unchanged from 0000858877-22-000025:mdna:201]

[0000858877-23-000005:mdna:246]
[same as prior period, unchanged from 0000858877-22-000025:mdna:202]

[0000858877-23-000005:mdna:247]
deferred revenue, and the timing and amount of tax and other payments. For additional discussion, see “Part II, Item 1A. Risk Factors” in this report.

[0000858877-23-000005:mdna:248]
[same as prior period, unchanged from 0000858877-22-000025:mdna:193]

[0000858877-23-000005:mdna:249]
[same as prior period, unchanged from 0000858877-22-000025:mdna:194]

[0000858877-23-000005:mdna:250]
|  |  | DIVIDENDS |  | STOCK REPURCHASE PROGRAM |  |  |
| Quarter Ended |  | Per Share |  | Amount |  | Shares |  | Weighted-Average Price per Share |  | Amount |  | TOTAL |
| Fiscal 2023 |  |  |  |  |  |  |  |  |  |  |  |  |
| January 28, 2023 |  | $ | 0.38 |  |  | $ | 1,560 |  |  | 26 |  |  | $ | 47.72 |  |  | $ | 1,256 |  |  | $ | 2,816 |  |
| October 29, 2022 |  | $ | 0.38 |  |  | $ | 1,560 |  |  | 12 |  |  | $ | 43.76 |  |  | 502 |  |  | $ | 2,062 |  |
| Fiscal 2022 |  |  |  |  |  |  |  |  |  |  |  |  |
| July 30, 2022 |  | $ | 0.38 |  |  | $ | 1,567 |  |  | 54 |  |  | $ | 44.02 |  |  | $ | 2,402 |  |  | $ | 3,969 |  |
| April 30, 2022 |  | $ | 0.38 |  |  | $ | 1,555 |  |  | 5 |  |  | $ | 54.20 |  |  | $ | 252 |  |  | $ | 1,807 |  |
| January 29, 2022 |  | $ | 0.37 |  |  | $ | 1,541 |  |  | 82 |  |  | $ | 58.36 |  |  | $ | 4,824 |  |  | $ | 6,365 |  |
| October 30, 2021 |  | $ | 0.37 |  |  | $ | 1,561 |  |  | 5 |  |  | $ | 56.49 |  |  | $ | 256 |  |  | $ | 1,817 |  |

[0000858877-23-000005:mdna:251]
On February 15, 2023, our Board of Directors declared a quarterly dividend of $0.39 per common share to be paid on April 26, 2023 to all stockholders of record as of the close of business on April 5, 2023. Any future dividends are subject to the approval of our Board of Directors.

[0000858877-23-000005:mdna:252]
The remaining authorized amount for stock repurchases under this program is approximately $13.4 billion, with no termination date.

[0000858877-23-000005:mdna:253]
[same as prior period, unchanged from 0000858877-22-000025:mdna:198]

[0000858877-23-000005:mdna:254]
|  | January 28,2023 |  | July 30,2022 |  | Increase (Decrease) |
| Accounts receivable, net | $ | 5,237 |  |  | $ | 6,622 |  |  | $ | (1,385) |  |

[0000858877-23-000005:mdna:255]
Our accounts receivable net, as of January 28, 2023 decreased by approximately 21%, as compared with the end of fiscal 2022, primarily due to timing and amount of product and service billings in the second quarter of fiscal 2023 compared with the fourth quarter of fiscal 2022.

[0000858877-23-000005:mdna:256]
[same as prior period, unchanged from 0000858877-22-000025:mdna:215]

[0000858877-23-000005:mdna:257]
[same as prior period, unchanged from 0000858877-22-000025:mdna:216]

[0000858877-23-000005:mdna:258]
[same as prior period, unchanged from 0000858877-22-000025:mdna:203]

[0000858877-23-000005:mdna:259]
|  | January 28,2023 |  | July 30,2022 |  | July 31,2021 |  | Variance vs. July 30, 2022 |  | Variance vs. July 31, 2021 |
| Inventories | $ | 3,140 |  |  | $ | 2,568 |  |  | $ | 1,559 |  |  | $ | 572 |  |  | $ | 1,581 |  |
| Inventory purchase commitments | $ | 10,951 |  |  | $ | 12,964 |  |  | $ | 10,254 |  |  | $ | (2,013) |  |  | $ | 697 |  |
| Inventory deposits and prepayments | $ | 1,688 |  |  | $ | 1,484 |  |  | $ | 162 |  |  | $ | 204 |  |  | $ | 1,526 |  |

[0000858877-23-000005:mdna:260]
[same as prior period, unchanged from 0000858877-22-000025:mdna:205]

[0000858877-23-000005:mdna:261]
|  | January 28,2023 |  | July 30,2022 |  | July 31,2021 |  | Variance vs. July 30, 2022 |  | Variance vs.July 31, 2021 |
| Less than 1 year | $ | 8,651 |  |  | $ | 9,954 |  |  | $ | 6,903 |  |  | $ | (1,303) |  |  | $ | 1,748 |  |
| 1 to 3 years | 1,693 |  |  | 2,240 |  |  | 1,806 |  |  | (547) |  |  | (113) |  |
| 3 to 5 years | 607 |  |  | 770 |  |  | 1,545 |  |  | (163) |  |  | (938) |  |
| Total | $ | 10,951 |  |  | $ | 12,964 |  |  | $ | 10,254 |  |  | $ | (2,013) |  |  | $ | 697 |  |

[0000858877-23-000005:mdna:262]
Inventory as of January 28, 2023 increased by 22% and 101% from our inventory balances at the end of fiscal 2022 and fiscal 2021, respectively. Inventory purchase commitments with contract manufacturers and suppliers decreased by 16% and increased by 7% from our balances at the end of fiscal 2022 and fiscal 2021, respectively. The decrease in inventory purchase commitments as compared with the end of fiscal 2022 was primarily due to fulfillment of customer demand as our supply availability improved and our continued efforts to work with contract manufacturers and suppliers to optimize our inventory and purchase commitments position. We increased our balances in prior fiscal years in order to address significant supply constraints seen industry-wide. The increases were primarily due to arrangements to secure supply and pricing for certain product components and commitments with contract manufacturers to meet customer demand and to address extended lead times, as well as advance payments with suppliers to secure future supply, as a result of the supply constraints. We have partnered with several of our key suppliers utilizing our volume purchasing and extending supply coverage, including revising supplier arrangements. As discussed, our risks of future material excess and obsolete inventory and related losses are further outlined in the Result of Operations—Product Gross Margin section.

[0000858877-23-000005:mdna:263]
[same as prior period, unchanged from 0000858877-22-000025:mdna:208]

[0000858877-23-000005:mdna:264]
[same as prior period, unchanged from 0000858877-22-000025:mdna:209]

[0000858877-23-000005:mdna:265]
[same as prior period, unchanged from 0000858877-22-000025:mdna:210]

[0000858877-23-000005:mdna:266]
[same as prior period, unchanged from 0000858877-22-000025:mdna:211]

[0000858877-23-000005:mdna:267]
|  | January 28,2023 |  | July 30,2022 |  | Increase (Decrease) |
| Loan receivables, net | $ | 6,042 |  |  | $ | 6,739 |  |  | $ | (697) |  |
| Lease receivables, net | 1,069 |  |  | 1,175 |  |  | (106) |  |
| Total, net | $ | 7,111 |  |  | $ | 7,914 |  |  | $ | (803) |  |

[0000858877-23-000005:mdna:268]
58

[0000858877-23-000005:mdna:269]
[same as prior period, unchanged from 0000858877-22-000025:mdna:226]

[0000858877-23-000005:mdna:270]
[same as prior period, unchanged from 0000858877-22-000025:mdna:227]

[0000858877-23-000005:mdna:271]
Financing Receivables  Our financing arrangements include loans and leases. Our loan receivables include customer financing for purchases of our hardware, software and services (including technical support and advanced services), and also may include additional funds for other costs associated with network installation and integration of our products and services. Lease receivables include sales-type leases. Arrangements related to leases are generally collateralized by a security interest in the underlying assets. Financing receivables decreased by 10%, as compared with the end of fiscal 2022.

[0000858877-23-000005:mdna:272]
[same as prior period, unchanged from 0000858877-22-000025:mdna:218]

[0000858877-23-000005:mdna:273]
The volume of channel partner financing was $15.1 billion and $13.4 billion for the first six months of fiscal 2023 and 2022, respectively. These financing arrangements facilitate the working capital requirements of the channel partners, and in some cases, we guarantee a portion of these arrangements. The balance of the channel partner financing subject to guarantees was $1.6 billion and $1.4 billion as of January 28, 2023 and July 30, 2022, respectively. We could be called upon to make payments under these guarantees in the event of nonpayment by the channel partners. Historically, our payments under these arrangements have been immaterial. Where we provide a guarantee, we defer the revenue associated with the channel partner financing arrangement in accordance with revenue recognition policies, or we record a liability for the fair value of the guarantees. In either case, the deferred revenue is recognized as revenue when the guarantee is removed. As of January 28, 2023, the total maximum potential future payments related to these guarantees was approximately $180 million, of which approximately $35 million was recorded as deferred revenue.

[0000858877-23-000005:mdna:274]
[same as prior period, unchanged from 0000858877-22-000025:mdna:220]

[0000858877-23-000005:mdna:275]
[same as prior period, unchanged from 0000858877-22-000025:mdna:221]

[0000858877-23-000005:mdna:276]
|  | Maturity Date |  | January 28,2023 |  | July 30,2022 |
| Senior notes: |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |
| 2.60% | February 28, 2023 |  | $ | 500 |  |  | $ | 500 |  |
| 2.20% | September 20, 2023 |  | 750 |  |  | 750 |  |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1,000 |  |
| 3.50% | June 15, 2025 |  | 500 |  |  | 500 |  |
| 2.95% | February 28, 2026 |  | 750 |  |  | 750 |  |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 1,500 |  |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 2,000 |  |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 2,000 |  |
| Total |  |  | $ | 9,000 |  |  | $ | 9,000 |  |

[0000858877-23-000005:mdna:277]
Interest is payable semiannually on each class of the senior fixed-rate notes, each of which is redeemable by us at any time, subject to a make-whole premium. We were in compliance with all debt covenants as of January 28, 2023.

[0000858877-23-000005:mdna:278]
Commercial Paper  We have a short-term debt financing program in which up to $10.0 billion is available through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes. We had no commercial paper notes outstanding as of January 28, 2023 and $0.6 billion in commercial paper outstanding as of July 30, 2022.

[0000858877-23-000005:mdna:279]
Credit Facility  On May 13, 2021, we entered into a 5-year credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 13, 2026. As of January 28, 2023, we were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under the credit agreement.

[0000858877-23-000005:mdna:280]
[same as prior period, unchanged from 0000858877-22-000025:mdna:239]

[0000858877-23-000005:mdna:281]
[same as prior period, unchanged from 0000858877-22-000025:mdna:240]

[0000858877-23-000005:mdna:282]
Any advances under the 5-year credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (a) with respect to loans in U.S. dollars, (i) LIBOR or (ii) the Base Rate (to be defined as the highest of (x) the Bank of America prime rate, (y) the Federal Funds rate plus 0.50% and (z) a daily rate equal to one-month LIBOR plus 1.0%), (b) with respect to loans in Euros, EURIBOR, (c) with respect to loans in Yen, TIBOR and (d) with respect to loans in Pounds Sterling, SONIA plus a credit spread adjustment, plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the interest rate be less than 0.0%. We will pay a quarterly commitment fee during the term of the 5-year credit agreement which may vary depending on our senior debt credit ratings. In addition, the 5-year credit agreement incorporates certain sustainability-linked metrics. Specifically, our applicable interest rate and commitment fee are subject to upward or downward adjustments if we achieve, or fail to achieve, certain specified targets based on two key performance indicator metrics: (i) social impact and (ii) foam reduction. We may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and, at our option, extend the maturity of the facility for an additional year up to two times. The credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio as defined in the agreement.

[0000858877-23-000005:mdna:283]
[same as prior period, unchanged from 0000858877-22-000025:mdna:229]

[0000858877-23-000005:mdna:284]
|  | January 28,2023 |  | July 30,2022 |  | Increase (Decrease) |
| Product | $ | 14,517 |  |  | $ | 14,090 |  |  | $ | 427 |  |
| Service | 17,255 |  |  | 17,449 |  |  | (194) |  |
| Total | $ | 31,772 |  |  | $ | 31,539 |  |  | $ | 233 |  |
| Short-term RPO | $ | 16,865 |  |  | $ | 16,936 |  |  | $ | (71) |  |
| Long-term RPO | 14,907 |  |  | 14,603 |  |  | 304 |  |
| Total | $ | 31,772 |  |  | $ | 31,539 |  |  | $ | 233 |  |

[0000858877-23-000005:mdna:285]
Total remaining performance obligations as of January 28, 2023 increased 1% compared to the end of fiscal 2022. Remaining performance obligations for product increased by 3% compared to the end of fiscal 2022. Remaining performance obligations for service decreased 1%. We expect approximately 53% of total remaining performance obligations to be recognized as revenue over the next 12 months.

[0000858877-23-000005:mdna:286]
[same as prior period, unchanged from 0000858877-22-000025:mdna:232]

[0000858877-23-000005:mdna:287]
|  | January 28,2023 |  | July 30,2022 |  | Increase (Decrease) |
| Product | $ | 10,679 |  |  | $ | 10,427 |  |  | $ | 252 |  |
| Service | 13,248 |  |  | 12,837 |  |  | 411 |  |
| Total | $ | 23,927 |  |  | $ | 23,264 |  |  | $ | 663 |  |
| Reported as: |  |  |  |  |  |
| Current | $ | 13,109 |  |  | $ | 12,784 |  |  | $ | 325 |  |
| Noncurrent | 10,818 |  |  | 10,480 |  |  | 338 |  |
| Total | $ | 23,927 |  |  | $ | 23,264 |  |  | $ | 663 |  |

[0000858877-23-000005:mdna:288]
Total deferred revenue increased 3% compared to the end of fiscal 2022. The increase in deferred product revenue was primarily due to increased deferrals related to our recurring software offerings. The increase in deferred service revenue of 3% was driven by the impact of contract renewals, partially offset by amortization of deferred service revenue.

[0000858877-23-000005:mdna:289]
[same as prior period, unchanged from 0000858877-22-000025:mdna:235]

[0000858877-23-000005:mdna:290]
[same as prior period, unchanged from 0000858877-22-000025:mdna:236]

[0000858877-23-000005:mdna:291]
The income tax payable outstanding as of January 28, 2023 for the U.S. transition tax on accumulated earnings for foreign subsidiaries is $5.5 billion. Approximately $1.4 billion is payable in less than one year and $4.1 billion is payable between 1 to 3 years.

[0000858877-23-000005:mdna:292]
For our Contractual Obligations see our Annual Report on Form 10-K for the fiscal year ended July 30, 2022.

[0000858877-23-000005:mdna:293]
60

[0000858877-23-000005:mdna:294]
CISCO SYSTEMS, INC.

[0000858877-23-000005:mdna:295]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-23-000005:mdna:296]
[same as prior period, unchanged from 0000858877-22-000025:mdna:241]

[0000858877-23-000005:mdna:297]
[same as prior period, unchanged from 0000858877-22-000025:mdna:242]

[0000858877-23-000005:mdna:298]
We also have certain funding commitments primarily related to our privately held investments, some of which may be based on the achievement of certain agreed-upon milestones or are required to be funded on demand. The funding commitments were $0.3 billion and $0.4 billion as of January 28, 2023 and July 30, 2022, respectively.

[0000858877-23-000005:mdna:299]
In the ordinary course of business, we have privately held investments and provide financing to certain customers. Certain of these investments are considered to be variable interest entities. We evaluate on an ongoing basis our privately held investments and customer financings, and we have determined that as of January 28, 2023 there were no material unconsolidated variable interest entities.

[0000858877-23-000005:mdna:300]
[same as prior period, unchanged from 0000858877-22-000025:mdna:245]

[0000858877-23-000005:mdna:301]
[same as prior period, unchanged from 0000858877-22-000025:mdna:246]

[0000858877-23-000005:mdna:302]
[same as prior period, unchanged from 0000858877-22-000025:mdna:247]

[0000858877-23-000005:mdna:303]
[same as prior period, unchanged from 0000858877-22-000025:mdna:248]
