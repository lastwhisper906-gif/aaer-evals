# CSCO 8-K — 0001193125-23-040212 filed 2023-02-15

## item codes, every 8-K on or before 2023-02-21

- 2023-02-21 0000858877-23-000006 — 5.02
- 2023-02-15 0001193125-23-040212 — 2.02, 9.01
- 2022-12-16 0000858877-22-000029 — 8.01
- 2022-12-09 0000858877-22-000027 — 5.07
- 2022-11-16 0001628280-22-030151 — 5.02
- 2022-11-16 0001193125-22-286782 — 2.02, 2.05, 9.01
- 2022-10-04 0000858877-22-000018 — 1.01, 1.02, 9.01
- 2022-09-15 0000858877-22-000015 — 8.01
- 2022-08-24 0001193125-22-228572 — 5.02
- 2022-08-17 0001193125-22-223250 — 2.02, 9.01
- 2022-06-17 0001193125-22-176552 — 8.01
- 2022-05-18 0001193125-22-154039 — 2.02, 9.01
- 2022-03-28 0001193125-22-086807 — 8.01
- 2022-02-16 0001193125-22-044372 — 2.02, 9.01
- 2022-02-11 0001193125-22-037227 — 5.02
- 2022-01-31 0001193125-22-023458 — 5.02
- 2021-12-17 0001193125-21-361182 — 8.01
- 2021-12-14 0001193125-21-356837 — 5.07, 8.01
- 2021-11-17 0001193125-21-332467 — 2.02, 9.01
- 2021-09-27 0001193125-21-284199 — 8.01
- 2021-08-18 0001193125-21-250360 — 2.02, 9.01
- 2021-06-29 0001193125-21-203324 — 8.01
- 2021-05-19 0001193125-21-166614 — 2.02, 9.01
- 2021-05-14 0001193125-21-162081 — 1.01, 2.03, 9.01
- 2021-03-08 0001193125-21-073328 — 5.02
- 2021-02-25 0001193125-21-056977 — 5.02
- 2021-02-09 0001193125-21-034339 — 2.02, 9.01
- 2021-01-07 0001193125-21-004250 — 5.02
- 2020-12-17 0001193125-20-320092 — 5.02, 8.01
- 2020-12-11 0001193125-20-315999 — 5.02, 5.07, 9.01
- 2020-11-30 0001193125-20-305352 — 5.02
- 2020-11-13 0001193125-20-293020 — 5.02, 9.01
- 2020-11-12 0001193125-20-291658 — 2.02, 9.01
- 2020-10-09 0001193125-20-267248 — 5.03, 9.01
- 2020-09-23 0001193125-20-252356 — 8.01
- 2020-08-12 0001193125-20-217756 — 5.02
- 2020-08-12 0001193125-20-217658 — 2.02, 2.05, 9.01
- 2020-06-22 0001193125-20-175641 — 8.01
- 2020-05-13 0001193125-20-141598 — 2.02, 9.01
- 2020-03-13 0001193125-20-072960 — 5.02
- 2020-03-06 0001193125-20-065138 — 5.02
- 2020-02-12 0001193125-20-033208 — 2.02, 9.01
- 2020-01-27 0001193125-20-015453 — 5.02
- 2019-12-23 0001193125-19-322662 — 8.01
- 2019-12-12 0001193125-19-312796 — 8.01
- 2019-12-11 0001193125-19-311525 — 5.07
- 2019-12-04 0001193125-19-306229 — 8.01
- 2019-11-13 0001193125-19-291002 — 2.02, 9.01
- 2019-08-22 0001193125-19-226917 — 8.01
- 2019-08-14 0001193125-19-221195 — 2.02, 9.01
- 2019-07-09 0001193125-19-190942 — 8.01, 9.01
- 2019-06-18 0001193125-19-175707 — 8.01
- 2019-06-04 0001193125-19-165092 — 8.01
- 2019-05-22 0001193125-19-154111 — 5.02
- 2019-05-15 0001193125-19-147994 — 2.02, 9.01
- 2019-03-07 0001193125-19-067296 — 8.01
- 2019-02-13 0001193125-19-037964 — 2.02, 9.01
- 2018-12-13 0001193125-18-348864 — 5.02, 5.07, 9.01
- 2018-11-14 0001193125-18-326716 — 2.02, 9.01
- 2018-10-18 0001193125-18-301990 — 5.02
- 2018-09-12 0001193125-18-271829 — 5.02, 9.01
- 2018-08-15 0001193125-18-249746 — 2.02, 9.01
- 2018-08-06 0001193125-18-239193 — 8.01
- 2018-06-25 0001193125-18-202535 — 8.01
- 2018-06-07 0001193125-18-186858 — 8.01
- 2018-05-16 0001193125-18-165248 — 2.02, 9.01
- 2018-05-01 0001193125-18-146602 — 5.02
- 2018-04-12 0001193125-18-115646 — 5.02
- 2018-02-14 0001193125-18-045716 — 2.02, 9.01
- 2017-12-14 0001193125-17-368869 — 5.02
- 2017-12-12 0001193125-17-367515 — 5.02, 5.07, 9.01
- 2017-11-15 0001193125-17-344129 — 2.02, 9.01
- 2017-10-23 0001193125-17-316071 — 8.01, 9.01
- 2017-09-18 0001193125-17-286857 — 5.02, 9.01
- 2017-09-01 0001193125-17-275671 — 8.01
- 2017-08-16 0001193125-17-259825 — 2.02
- 2017-06-23 0001193125-17-211825 — 8.01
- 2017-06-15 0001193125-17-204753 — 8.01
- 2017-05-17 0001193125-17-173404 — 2.02
- 2017-03-31 0001193125-17-106620 — 1.01, 2.03, 9.01
- 2017-03-29 0001193125-17-101783 — 8.01
- 2017-03-13 0001193125-17-080485 — 5.02
- 2017-02-15 0001193125-17-045265 — 2.02
- 2016-12-22 0001193125-16-802182 — 8.01
- 2016-12-13 0001193125-16-791877 — 5.07
- 2016-11-16 0001193125-16-769785 — 2.02
- 2016-11-03 0001193125-16-758911 — 5.02, 9.01
- 2016-10-17 0001193125-16-739833 — 5.02
- 2016-09-21 0001193125-16-716006 — 8.01
- 2016-09-20 0001193125-16-714189 — 8.01, 9.01
- 2016-09-16 0001193125-16-712320 — 8.01
- 2016-09-15 0001193125-16-711098 — 1.01, 9.01
- 2016-09-13 0001193125-16-708007 — 8.01, 9.01
- 2016-09-06 0001193125-16-702020 — 8.01
- 2016-08-17 0001193125-16-684126 — 2.02, 2.05
- 2016-07-29 0001193125-16-664620 — 5.03, 9.01
- 2016-06-27 0001193125-16-633145 — 8.01
- 2016-06-23 0001193125-16-630146 — 8.01
- 2016-06-07 0001193125-16-615321 — 5.02, 9.01
- 2016-05-18 0001193125-16-594463 — 2.02
- 2016-03-24 0001193125-16-516953 — 8.01
- 2016-02-29 0001193125-16-483780 — 8.01, 9.01
- 2016-02-25 0001193125-16-478442 — 8.01
- 2016-02-24 0001193125-16-474071 — 1.01, 9.01
- 2016-02-22 0001193125-16-470856 — 8.01, 9.01
- 2016-02-10 0001193125-16-457586 — 2.02
- 2016-01-28 0001193125-16-441933 — 5.02
- 2015-12-08 0001193125-15-397797 — 8.01
- 2015-11-20 0001193125-15-383743 — 5.07
- 2015-11-12 0001193125-15-375655 — 2.02
- 2015-09-21 0001193125-15-324465 — 8.01
- 2015-09-17 0001193125-15-322456 — 8.01
- 2015-09-14 0001193125-15-319489 — 8.01
- 2015-08-28 0001193125-15-306843 — 8.01
- 2015-08-12 0001193125-15-288099 — 2.02
- 2015-07-29 0001193125-15-268359 — 5.02 — amendment of 0001193125-15-169227
- 2015-06-18 0001193125-15-227387 — 8.01, 9.01
- 2015-06-12 0001193125-15-221863 — 1.01, 9.01
- 2015-06-10 0001193125-15-218734 — 8.01, 9.01
- 2015-06-01 0001193125-15-209142 — 5.02, 9.01
- 2015-05-13 0001193125-15-185905 — 2.02
- 2015-05-04 0001193125-15-169227 — 5.02
- 2015-03-24 0001193125-15-103369 — 8.01
- 2015-03-19 0001193125-15-098638 — 8.01
- 2015-02-11 0001193125-15-044175 — 2.02
- 2014-12-19 0001193125-14-448754 — 8.01
- 2014-12-18 0001193125-14-447039 — 8.01
- 2014-11-24 0001193125-14-423591 — 5.02, 5.07, 9.01
- 2014-11-14 0001193125-14-413384 — 5.02
- 2014-11-12 0001193125-14-409258 — 2.02
- 2014-09-25 0001193125-14-353210 — 8.01
- 2014-09-12 0001193125-14-340480 — 5.02
- 2014-08-14 0001193125-14-308733 — 2.05
- 2014-08-13 0001193125-14-308403 — 2.02
- 2014-07-31 0001193125-14-289683 — 5.02
- 2014-06-25 0001193125-14-249157 — 8.01
- 2014-05-14 0001193125-14-199056 — 2.02
- 2014-03-26 0001193125-14-116588 — 8.01
- 2014-03-11 0001193125-14-093805 — 8.01
- 2014-03-03 0001193125-14-079163 — 1.01, 8.01, 9.01
- 2014-02-26 0001193125-14-069912 — 1.01, 9.01
- 2014-02-12 0001193125-14-048150 — 2.02
- 2013-12-23 0001193125-13-483099 — 8.01
- 2013-12-04 0001193125-13-462216 — 8.01
- 2013-11-20 0001193125-13-448477 — 5.02, 5.07, 9.01
- 2013-11-13 0001193125-13-440194 — 2.02
- 2013-08-15 0001193125-13-335218 — 2.05
- 2013-08-14 0001193125-13-334648 — 2.02
- 2013-07-23 0001193125-13-298129 — 8.01, 9.01
- 2013-06-24 0001193125-13-269064 — 8.01
- 2013-06-12 0001193125-13-256194 — 8.01
- 2013-06-07 0001193125-13-250920 — 8.01
- 2013-05-15 0001193125-13-222377 — 2.02
- 2013-03-26 0001193125-13-127015 — 8.01
- 2013-02-13 0001193125-13-055377 — 2.02
- 2013-02-01 0001193125-13-034682 — 5.02
- 2013-01-08 0001193125-13-006886 — 5.02, 9.01
- 2012-12-21 0001193125-12-513130 — 8.01
- 2012-12-19 0001193125-12-508424 — 8.01
- 2012-11-16 0001193125-12-474089 — 5.02, 5.07, 9.01
- 2012-11-13 0001193125-12-467422 — 2.02
- 2012-10-04 0001193125-12-415386 — 5.02, 5.03, 9.01
- 2012-09-19 0001193125-12-396875 — 5.02, 8.01
- 2012-08-15 0001193125-12-357479 — 2.02
- 2012-08-02 0001193125-12-332045 — 5.02
- 2012-06-27 0001193125-12-285742 — 8.01
- 2012-06-13 0001193125-12-269642 — 8.01
- 2012-05-09 0001193125-12-222045 — 2.02
- 2012-03-27 0001193125-12-134384 — 8.01
- 2012-03-15 0001193125-12-117538 — 8.01, 9.01
- 2012-02-17 0001193125-12-067542 — 1.01, 1.02, 2.03, 9.01
- 2012-02-08 0001193125-12-046545 — 2.02
- 2011-12-16 0001193125-11-343995 — 8.01
- 2011-12-08 0001193125-11-335127 — 5.02, 5.07, 9.01
- 2011-11-09 0001193125-11-304587 — 2.02
- 2011-09-29 0001193125-11-260065 — 8.01
- 2011-09-20 0001193125-11-252379 — 5.02, 9.01
- 2011-08-24 0001193125-11-231015 — 8.01
- 2011-08-10 0001193125-11-218133 — 2.02
- 2011-07-18 0001193125-11-190246 — 2.05
- 2011-06-22 0001193125-11-170849 — 8.01
- 2011-05-11 0001193125-11-135913 — 2.02
- 2011-03-28 0001193125-11-079927 — 8.01
- 2011-03-22 0001193125-11-073802 — 5.02 — amendment of 0001193125-11-043592
- 2011-03-18 0001193125-11-071279 — 8.01, 9.01
- 2011-03-16 0001193125-11-067985 — 1.01, 5.02, 8.01, 9.01
- 2011-03-15 0001193125-11-067331 — 1.01, 9.01
- 2011-03-09 0001193125-11-060123 — 8.01, 9.01
- 2011-02-23 0001193125-11-043592 — 5.02
- 2011-02-09 0001193125-11-028987 — 2.02
- 2011-01-31 0001193125-11-019101 — 1.01, 2.03
- 2010-12-17 0001193125-10-283392 — 8.01
- 2010-11-19 0001193125-10-265377 — 5.07
- 2010-11-10 0001193125-10-256001 — 2.02
- 2010-09-22 0001193125-10-214707 — 8.01
- 2010-09-16 0001193125-10-211456 — 7.01
- 2010-08-11 0001193125-10-186042 — 2.02
- 2010-06-29 0001193125-10-149956 — 8.01
- 2010-05-12 0001193125-10-117509 — 2.02
- 2010-02-17 0001193125-10-033290 — 5.02, 8.01, 9.01
- 2010-02-03 0001193125-10-020775 — 2.02
- 2009-11-25 0001193125-09-242589 — 8.01
- 2009-11-17 0001193125-09-236335 — 1.01, 8.01, 9.01
- 2009-11-13 0001193125-09-234405 — 1.01, 2.03, 9.01
- 2009-11-13 0001193125-09-234397 — 5.02 — amendment of 0001193125-09-189511
- 2009-11-12 0001193125-09-232971 — 5.02, 7.01, 9.01
- 2009-11-09 0001193125-09-228541 — 8.01, 9.01
- 2009-11-04 0001193125-09-223763 — 2.02
- 2009-10-14 0001193125-09-207912 — 8.01, 9.01
- 2009-10-05 0001193125-09-203556 — 8.01
- 2009-09-10 0001193125-09-189511 — 5.02
- 2009-09-04 0001193125-09-187835 — 5.02
- 2009-08-05 0001193125-09-165404 — 2.02
- 2009-07-27 0001193125-09-155861 — 5.02
- 2009-05-29 0001193125-09-121672 — 8.01
- 2009-05-06 0001193125-09-101570 — 2.02
- 2009-02-26 0001193125-09-038162 — 5.02
- 2009-02-17 0001193125-09-030546 — 1.01, 8.01, 9.01
- 2009-02-13 0001193125-09-029295 — 1.01, 2.03, 9.01
- 2009-02-04 0001193125-09-018793 — 2.02
- 2008-11-05 0001193125-08-225857 — 2.02
- 2008-09-11 0001193125-08-194695 — 7.01
- 2008-08-05 0001193125-08-166496 — 2.02
- 2008-06-20 0001193125-08-137504 — 8.01
- 2008-05-06 0001193125-08-104089 — 2.02
- 2008-03-21 0001193125-08-062838 — 8.01
- 2008-02-06 0001193125-08-021681 — 2.02
- 2008-01-23 0001193125-08-010589 — 5.02
- 2008-01-04 0001193125-08-001680 — 5.02, 9.01
- 2007-12-21 0001193125-07-269613 — 5.02
- 2007-11-19 0001193125-07-250345 — 5.02 — amendment of 0001193125-07-009285
- 2007-11-19 0001193125-07-250343 — 5.02, 9.01
- 2007-11-07 0001193125-07-238464 — 2.02
- 2007-09-24 0001193125-07-206279 — 8.01
- 2007-09-20 0001193125-07-204616 — 5.02, 7.01
- 2007-09-07 0001193125-07-197514 — 8.01
- 2007-08-17 0001193125-07-185320 — 1.01, 2.03, 9.01
- 2007-08-08 0001193125-07-174077 — 5.02
- 2007-08-07 0001193125-07-173689 — 2.02
- 2007-08-01 0001193125-07-168143 — 5.02
- 2007-05-15 0001193125-07-115800 — 8.01
- 2007-05-08 0001193125-07-106059 — 2.02
- 2007-03-23 0001193125-07-063033 — 5.02, 5.03, 8.01, 9.01
- 2007-03-21 0001193125-07-060631 — 1.01, 9.01
- 2007-02-06 0001193125-07-021349 — 2.02
- 2007-01-19 0001193125-07-009285 — 5.02
- 2006-12-22 0001193125-06-259241 — 8.01
- 2006-11-16 0001193125-06-237260 — 5.03, 8.01, 9.01
- 2006-11-08 0001193125-06-228341 — 2.02
- 2006-09-21 0001193125-06-194890 — 1.01, 7.01
- 2006-09-20 0001193125-06-194063 — 1.01
- 2006-09-15 0001193125-06-191845 — 5.02
- 2006-08-18 0001193125-06-176193 — 5.02
- 2006-08-08 0001193125-06-165719 — 2.02
- 2006-07-31 0001193125-06-157106 — 1.01, 9.01
- 2006-07-31 0001193125-06-157102 — 5.02 — amendment of 0001193125-06-017426
- 2006-06-08 0001193125-06-126879 — 5.02
- 2006-05-18 0001193125-06-115516 — 8.01
- 2006-05-12 0001193125-06-110924 — 9.01 — amendment of 0001193125-06-044013
- 2006-05-09 0001193125-06-105419 — 2.02
- 2006-03-29 0001193125-06-066990 — 1.01
- 2006-03-02 0001193125-06-044013 — 1.01, 2.01, 9.01
- 2006-02-28 0001193125-06-041452 — 1.01
- 2006-02-22 0001193125-06-036759 — 8.01
- 2006-02-22 0001193125-06-036433 — 1.01, 8.01, 9.01
- 2006-02-21 0001193125-06-035865 — 1.01, 2.03, 9.01
- 2006-02-10 0001193125-06-026218 — 8.01, 9.01
- 2006-02-07 0001193125-06-022234 — 2.02
- 2006-02-01 0001193125-06-017426 — 5.02
- 2005-11-18 0001193125-05-229535 — 1.01, 9.01
- 2005-11-16 0001193125-05-227987 — 1.01, 9.01
- 2005-11-16 0001193125-05-227983 — 5.02 — amendment of 0001193125-05-008843
- 2005-11-09 0001193125-05-221610 — 2.02
- 2005-09-29 0001193125-05-194217 — 7.01
- 2005-09-27 0001193125-05-192353 — 8.01
- 2005-09-21 0001193125-05-189234 — 1.01, 9.01
- 2005-09-19 0001193125-05-187646 — 8.01
- 2005-09-09 0001193125-05-183273 — 8.01
- 2005-09-08 0001193125-05-182307 — 1.01
- 2005-08-09 0001193125-05-162626 — 2.02
- 2005-07-15 0001193125-05-142738 — 8.01
- 2005-05-10 0001193125-05-102797 — 2.02
- 2005-03-30 0001193125-05-065123 — 1.01, 3.03, 9.01
- 2005-03-04 0001193125-05-042778 — 1.01
- 2005-02-08 0001193125-05-022181 — 2.02
- 2005-01-20 0001193125-05-008843 — 5.02
- 2004-12-23 0001193125-04-219331 — 8.01
- 2004-11-09 0001193125-04-191303 — 2.02
- 2004-08-23 0001193125-04-145198 — 1.01, 7.01
- 2004-08-19 0001193125-04-143859 — 5
- 2004-08-10 0001193125-04-136865 — 12
- 2004-05-11 0001193125-04-084721 — 12
- 2004-02-03 0001193125-04-013750 — 12
- 2003-11-05 0001193125-03-073418 — 12
- 2003-09-02 0001193125-03-044521 — 9
- 2003-08-05 0001193125-03-029223 — 12, 7
- 2003-07-18 0001193125-03-021155 — 5, 7
- 2003-06-05 0001012870-03-002949 — 5
- 2003-05-06 0000891618-03-002315 — 7, 9
- 2003-04-17 0000891618-03-001894 — 5, 7
- 2003-04-11 0000891618-03-001791 — 9
- 2003-03-20 0000891618-03-001326 — 5, 7
- 2003-02-04 0000891618-03-000518 — 7, 9
- 2003-01-28 0000891618-03-000271 — 5, 7
- 2002-12-27 0000891618-02-005686 — 5, 7
- 2002-10-23 0000891618-02-004715 — 5, 7
- 2002-10-11 0000891618-02-004620 — 5, 7
- 2002-09-18 0000891618-02-004352 — 5, 7
- 2002-08-20 0000891618-02-004001 — 5, 7
- 2002-08-05 0000891618-02-003498 — 5, 7
- 2002-07-03 0000891618-02-003099 — 5, 7
- 2002-05-14 0000891618-02-002407 — 5, 7
- 2002-02-05 0000891618-02-000412 — 5, 7
- 2001-09-28 0001095811-01-505261 — 5, 7
- 2001-09-14 0001095811-01-504917 — 5, 7
- 2001-08-24 0001095811-01-504581 — 5, 7
- 2001-07-30 0001095811-01-503468 — 5, 7
- 2001-07-12 0000891618-01-501567 — 5, 7
- 2001-05-11 0000891618-01-500638 — 5, 7
- 2001-02-27 0000891618-01-500076 — 5, 7
- 2001-02-20 0001095811-01-001530 — 5, 7
- 2001-02-08 0001095811-01-000848 — 5, 7
- 2001-02-07 0001095811-01-000768 — 5
- 2000-12-27 0001095811-00-005511 — 5
- 2000-12-21 0001095811-00-005427 — 5
- 2000-12-19 0001095811-00-005368 — 5
- 2000-11-15 0001095811-00-004830 — 5
- 2000-11-15 0001095811-00-004824 — 5
- 2000-11-13 0000891618-00-005023 — 5
- 2000-11-07 0001095811-00-004387 — 5, 7
- 2000-11-06 0001095811-00-004318 — 5
- 2000-09-29 0000891618-00-004739 — 5, 7
- 2000-09-28 0000891618-00-004722 — 5
- 2000-09-26 0001095811-00-003573 — 5
- 2000-09-15 0001095811-00-003413 — 5
- 2000-09-07 0001095811-00-003229 — 5
- 2000-08-15 0000891618-00-004430 — 5
- 2000-08-04 0001095811-00-002304 — 5, 7 — amendment, the index does not say of what
- 2000-07-28 0000891618-00-004132 — 5, 7
- 2000-06-29 0000891618-00-003637 — 5
- 2000-06-07 0000891618-00-003209 — 5
- 2000-05-26 0000891618-00-003054 — 5
- 2000-05-18 0000891618-00-002975 — 5, 7
- 2000-05-15 0000891618-00-002808 — 5, 7
- 2000-05-03 0000891618-00-002473 — 5
- 2000-04-03 0000891618-00-001936 — 5
- 2000-03-28 0000891618-00-001763 — 5
- 2000-03-27 0000891618-00-001722 — 5, 7
- 2000-03-16 0000891618-00-001512 — 5
- 2000-02-17 0000891618-00-001024 — 5, 7
- 2000-02-03 0000891618-00-000468 — 7 — amendment of 0000891618-99-005685
- 1999-12-22 0000891618-99-005792 — 5, 7
- 1999-12-15 0000891618-99-005685 — 5, 7
- 1999-11-17 0000891618-99-005313 — 5, 7
- 1999-11-04 0000891618-99-004862 — 5, 7
- 1999-10-20 0000891618-99-004625 — 5, 7
- 1999-09-27 0000891618-99-004333 — 5, 7
- 1999-08-26 0000891618-99-003978 — 5, 7
- 1999-08-13 0000891618-99-003764 — 5, 7 — amendment of 0000891618-99-003749
- 1999-08-13 0000891618-99-003749 — 5, 7
- 1999-07-02 0000891618-99-002980 — 5, 7
- 1999-05-14 0000891618-99-002221 — 5
- 1998-11-20 0000891618-98-005074 — 5, 7
- 1998-11-20 0000891618-98-005073 — 5, 7
- 1998-10-13 0000891618-98-004462 — 5, 7
- 1998-07-09 0000891618-98-003245 — 5, 7
- 1998-06-11 0000891618-98-002832 — 5, 7
- 1998-05-15 0000891618-98-002457 — 5, 7
- 1998-04-29 0000891618-98-001996 — 5
- 1998-02-11 0000891618-98-000584 — 5, 7
- 1997-09-09 0000891618-97-003723 — 5, 7
- 1997-08-22 0000891618-97-003559 — 5, 7
- 1997-07-01 0000891618-97-002807 — 5, 7
- 1997-01-22 0000891618-97-000120 — 5, 7
- 1996-10-15 0000891618-96-002283 — 5, 7 — amendment of 0000891618-96-002217
- 1996-10-01 0000891618-96-002217 — 5, 7
- 1996-07-23 0000891618-96-001305 — 2, 7
- 1996-04-26 0000891618-96-000253 — 2
- 1996-04-02 0000898430-96-001187 — 2, 7
- 1995-12-06 0000891618-95-000728 — 2, 7
- 1995-12-06 0000891618-95-000727 — 2, 7

## late-filing notifications on or before 2023-02-21

- none on or before 2023-02-21

## item 2.02 — earnings release, exhibit 99.1

[0001193125-23-040212:8k_2_02:1]
EX-99.1
2
d417697dex991.htm
EX-99.1

[0001193125-23-040212:8k_2_02:2]
EX-99.1

[0001193125-23-040212:8k_2_02:3]
Exhibit 99.1

[0001193125-23-040212:8k_2_02:4]
| Press Contact: |  |  |  | Investor Relations Contact: |
| Robyn Blum |  |  |  | Marilyn Mora |
| Cisco |  |  |  | Cisco |
| 1 (408) 930-8548 |  |  |  | 1 (408) 527-7452 |
| rojenkin@cisco.com |  |  |  | marilmor@cisco.com |

[0001193125-23-040212:8k_2_02:5]
CISCO REPORTS SECOND QUARTER EARNINGS

[0001193125-23-040212:8k_2_02:6]
News Summary:

[0001193125-23-040212:8k_2_02:7]
|  | • |  | $13.6 billion in revenue, up 7% year over year; GAAP EPS $0.67, down 6% year over year, and Non-GAAP EPS $0.88, up 5% year over year |

[0001193125-23-040212:8k_2_02:8]
|  | • |  | Continued progress on business model transformation: |

[0001193125-23-040212:8k_2_02:9]
|  | • |  | Total annualized recurring revenue (ARR) at $23.3 billion, up 6% year over year and product ARR up 11% year over year |

[0001193125-23-040212:8k_2_02:10]
|  | • |  | Total software revenue up 10% year over year and software subscription revenue up 15% year over year |

[0001193125-23-040212:8k_2_02:11]
|  | • |  | Remaining performance obligations (RPO) at $31.8 billion, up 4% year over year and product RPO up 7% year over year |

[0001193125-23-040212:8k_2_02:12]
|  | • |  | Dividend increased 3% |

[0001193125-23-040212:8k_2_02:13]
|  | • |  | Q2 FY 2023 Results: |

[0001193125-23-040212:8k_2_02:14]
|  | • |  | Revenue: $13.6 billion |

[0001193125-23-040212:8k_2_02:15]
|  | • |  | Increase of 7% year over year |

[0001193125-23-040212:8k_2_02:16]
|  | • |  | Earnings per Share: GAAP: $0.67; Non-GAAP: $0.88 |

[0001193125-23-040212:8k_2_02:17]
|  | • |  | GAAP EPS decreased (6)% year over year |

[0001193125-23-040212:8k_2_02:18]
|  | • |  | Non-GAAP EPS increased 5% year over year |

[0001193125-23-040212:8k_2_02:19]
|  | • |  | Q3 FY 2023 Guidance: |

[0001193125-23-040212:8k_2_02:20]
|  | • |  | Revenue: 11% to 13% growth year over year |

[0001193125-23-040212:8k_2_02:21]
|  | • |  | Earnings per Share: GAAP: $0.74 to $0.79; Non-GAAP: $0.96 to $0.98 |

[0001193125-23-040212:8k_2_02:22]
|  | • |  | FY 2023 Guidance: |

[0001193125-23-040212:8k_2_02:23]
|  | • |  | Revenue: 9% to 10.5% growth year over year |

[0001193125-23-040212:8k_2_02:24]
|  | • |  | Earnings per Share: GAAP: $2.85 to $2.96; Non-GAAP: $3.73 to $3.78 |

[0001193125-23-040212:8k_2_02:25]
SAN JOSE, Calif. — February 15, 2023 — Cisco today reported second quarter results for the period ended January 28,
2023. Cisco reported second quarter revenue of $13.6 billion, net income on a generally accepted accounting principles (GAAP) basis of $2.8 billion or $0.67 per share, and non-GAAP net income of
$3.6 billion or $0.88 per share.

[0001193125-23-040212:8k_2_02:26]
“With Cisco’s strong Q2 performance, our fiscal 2023 is shaping up to be a great year,” said Chuck
Robbins, chair and CEO of Cisco. “The modern, highly secure networks we are building serve as the backbone of our customers’ technology strategy. This, combined with the success of our ongoing business transformation and operational
discipline gives me confidence in our future.”

[0001193125-23-040212:8k_2_02:27]
1

[0001193125-23-040212:8k_2_02:28]
GAAP Results

[0001193125-23-040212:8k_2_02:29]
|  |  | Q2 FY 2023 |  |  | Q2 FY 2022 |  |  | Vs. Q2 FY 2022 |  |
| Revenue |  | $ | 13.6 billion |  |  | $ | 12.7 billion |  |  |  | 7 | % |
| Net Income |  | $ | 2.8 billion |  |  | $ | 3.0 billion |  |  |  | (7 | )% |
| Diluted Earnings per Share (EPS) |  | $ | 0.67 |  |  | $ | 0.71 |  |  |  | (6 | )% |

[0001193125-23-040212:8k_2_02:30]
Non-GAAP Results

[0001193125-23-040212:8k_2_02:31]
|  |  | Q2 FY 2023 |  |  | Q2 FY 2022 |  |  | Vs. Q2 FY 2022 |  |
| Net Income |  | $ | 3.6 billion |  |  | $ | 3.5 billion |  |  |  | 3 | % |
| EPS |  | $ | 0.88 |  |  | $ | 0.84 |  |  |  | 5 | % |

[0001193125-23-040212:8k_2_02:32]
Reconciliations between net income, EPS, and other measures on a GAAP and non-GAAP
basis are provided in the tables located in the section entitled “Reconciliations of GAAP to non-GAAP Measures.”

[0001193125-23-040212:8k_2_02:33]
Cisco Increases Quarterly Dividend

[0001193125-23-040212:8k_2_02:34]
Cisco has declared a
quarterly dividend of $0.39 per common share, a 1-cent increase or up 3%, over the previous quarter’s dividend, to be paid on April 26, 2023 to all stockholders of record as of the close of business on April 5, 2023. Future dividends
will be subject to Board approval.

[0001193125-23-040212:8k_2_02:35]
“We continue to execute well, delivering better than expected results in revenue, record non-GAAP EPS and operating cash flow”, said Scott Herren, CFO of Cisco. “We are raising our full year outlook driven by our growing recurring revenue base and RPO, along with our healthy backlog and the
steps we have taken to improve supply. We have once again increased our dividend, reflecting the strength of our cash flow generation and our commitment to shareholder returns.”

[0001193125-23-040212:8k_2_02:36]
2

[0001193125-23-040212:8k_2_02:37]
Financial Summary

[0001193125-23-040212:8k_2_02:38]
All comparative percentages are on a year-over-year basis unless otherwise noted.

[0001193125-23-040212:8k_2_02:39]
Q2 FY 2023 Highlights

[0001193125-23-040212:8k_2_02:40]
Revenue — Total
revenue was up 7% at $13.6 billion, with product revenue up 9% and service revenue was up 2%. Revenue by geographic segment was: Americas up 9%, EMEA up 5%, and APJC was up 1%. Product revenue performance was led by growth in Secure, Agile
Networks up 14%, End-to-End Security up 7%, and Optimized Application Experiences up 11%. Internet for the Future was down 1% and Collaboration was down 10%.

[0001193125-23-040212:8k_2_02:41]
Gross Margin — On a GAAP basis, total gross margin, product gross margin, and service gross margin were 62.0%, 60.2%, and 67.2%,
respectively, as compared with 63.3%, 61.8%, and 67.3%, respectively, in the second quarter of fiscal 2022.

[0001193125-23-040212:8k_2_02:42]
On a
non-GAAP basis, total gross margin, product gross margin, and service gross margin were 63.9%, 62.1%, and 69.1%, respectively, as compared with 65.5%, 64.3%, and 68.8%, respectively, in the second quarter of
fiscal 2022.

[0001193125-23-040212:8k_2_02:43]
Total gross margins by geographic segment were: 62.9% for the Americas, 66.2% for EMEA and 63.6% for APJC.

[0001193125-23-040212:8k_2_02:44]
Operating Expenses — On a GAAP basis, operating expenses were $5.1 billion, up 13%, and were 37.8% of revenue. Non-GAAP operating expenses were $4.3 billion, up 8%, and were 31.4% of revenue.

[0001193125-23-040212:8k_2_02:45]
Operating Income
— GAAP operating income was $3.3 billion, down 6%, with GAAP operating margin of 24.2%. Non-GAAP operating income was $4.4 billion, up 1%, with
non-GAAP operating margin at 32.5%.

[0001193125-23-040212:8k_2_02:46]
Provision for Income Taxes — The GAAP tax provision rate
was 18.8%. The non-GAAP tax provision rate was 19.0%.

[0001193125-23-040212:8k_2_02:47]
Net Income and EPS — On a GAAP basis,
net income was $2.8 billion, a decrease of 7%, and EPS was $0.67, a decrease of 6%. On a non-GAAP basis, net income was $3.6 billion, an increase of 3%, and EPS was $0.88, an increase of 5%.

[0001193125-23-040212:8k_2_02:48]
Cash Flow from Operating Activities — $4.7 billion for the second quarter of fiscal 2023, an increase of 93% compared with
$2.5 billion for the second quarter of fiscal 2022.

[0001193125-23-040212:8k_2_02:49]
Balance Sheet and Other Financial Highlights

[0001193125-23-040212:8k_2_02:50]
Cash and Cash Equivalents and Investments — $22.1 billion at the end of the second quarter of fiscal 2023, compared with
$19.3 billion at the end of fiscal 2022.

[0001193125-23-040212:8k_2_02:51]
Remaining Performance Obligations (RPO) — $31.8 billion, up 4% in
total, with 53% of this amount to be recognized as revenue over the next 12 months. Product RPO were up 7% and service RPO were up 2%.

[0001193125-23-040212:8k_2_02:52]
Deferred
Revenue — $23.9 billion, up 7% in total, with deferred product revenue up 9%. Deferred service revenue was up 6%.

[0001193125-23-040212:8k_2_02:53]
Capital
Allocation — In the second quarter of fiscal 2023, we returned $2.8 billion to stockholders through share buybacks and dividends. We declared and paid a cash dividend of $0.38 per common share, or $1.6 billion, and repurchased
approximately 26 million shares of common stock under our stock repurchase program at an average price of $47.72 per share for an aggregate purchase price of $1.3 billion. The remaining authorized amount for stock repurchases under the
program is $13.4 billion with no termination date.

[0001193125-23-040212:8k_2_02:54]
3

[0001193125-23-040212:8k_2_02:55]
Guidance

[0001193125-23-040212:8k_2_02:56]
Cisco expects to achieve the following results for the third quarter of fiscal 2023:

[0001193125-23-040212:8k_2_02:57]
| Q3 FY 2023 |  |  |
| Revenue |  | 11% – 13% growth Y/Y |
| Non-GAAP gross margin rate |  | 63.5% – 64.5% |
| Non-GAAP operating margin rate |  | 33% – 34% |
| Non-GAAP EPS |  | $0.96 – $0.98 |

[0001193125-23-040212:8k_2_02:58]
Cisco estimates that GAAP EPS will be $0.74 to $0.79 for the third quarter of fiscal 2023.

[0001193125-23-040212:8k_2_02:59]
Cisco expects to achieve the following results for fiscal 2023:

[0001193125-23-040212:8k_2_02:60]
| FY 2023 |  |  |
| Revenue |  | 9% – 10.5% growth Y/Y |
| Non-GAAP EPS |  | $3.73 – $3.78 |

[0001193125-23-040212:8k_2_02:61]
Cisco estimates that GAAP EPS will be $2.85 to $2.96 for fiscal 2023.

[0001193125-23-040212:8k_2_02:62]
Our Q3 FY 2023 guidance assumes an effective tax provision rate of 18% for GAAP and 19% for non-GAAP results. Our FY
2023 guidance assumes an effective tax provision rate of 20% for GAAP and 19% for non-GAAP results.

[0001193125-23-040212:8k_2_02:63]
A
reconciliation between the Guidance on a GAAP and non-GAAP basis is provided in the tables entitled “GAAP to non-GAAP Guidance” located in the section entitled
“Reconciliations of GAAP to non-GAAP Measures.”

[0001193125-23-040212:8k_2_02:64]
Editor’s Notes:

[0001193125-23-040212:8k_2_02:65]
|  | • |  | Q2 fiscal year 2023 conference call to discuss Cisco’s results along with its guidance will be held on Wednesday, February 15, 2023 at 1:30 p.m. Pacific Time. Conference call number is 1-888-848-6507 (United States) or 1-212-519-0847 (international). |

[0001193125-23-040212:8k_2_02:66]
|  | • |  | Conference call replay will be available from 4:00 p.m. Pacific Time, February 15, 2023 to 4:00 p.m. Pacific Time, February 22, 2023 at 1-866-361-4941 (United States) or 1-203-369-0189 (international). The replay will also be available via webcast on the Cisco Investor Relations website at https://investor.cisco.com. |

[0001193125-23-040212:8k_2_02:67]
|  | • |  | Additional information regarding Cisco’s financials, as well as a webcast of the conference call with visuals designed to guide participants through the call, will be available at 1:30 p.m. Pacific Time, February 15, 2023. Text of the conference call’s prepared remarks will be available within 24 hours of completion of the call. The webcast will include both the prepared remarks and the question-and-answer session. This information, along with the GAAP to non-GAAP reconciliation information, will be available on the Cisco Investor Relations website at https://investor.cisco.com. |

[0001193125-23-040212:8k_2_02:68]
4

[0001193125-23-040212:8k_2_02:69]
CISCO SYSTEMS, INC.

[0001193125-23-040212:8k_2_02:70]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-23-040212:8k_2_02:71]
(In millions, except per-share amounts)

[0001193125-23-040212:8k_2_02:72]
(Unaudited)

[0001193125-23-040212:8k_2_02:73]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | January 28,2023 |  |  | January 29,2022 |  |  | January 28,2023 |  |  | January 29,2022 |  |
| REVENUE: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 10,155 |  |  | $ | 9,353 |  |  | $ | 20,400 |  |  | $ | 18,882 |  |
| Service |  |  | 3,437 |  |  |  | 3,367 |  |  |  | 6,824 |  |  |  | 6,738 |  |
| Total revenue |  |  | 13,592 |  |  |  | 12,720 |  |  |  | 27,224 |  |  |  | 25,620 |  |
| COST OF SALES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 4,038 |  |  |  | 3,569 |  |  |  | 8,217 |  |  |  | 7,242 |  |
| Service |  |  | 1,127 |  |  |  | 1,102 |  |  |  | 2,234 |  |  |  | 2,276 |  |
| Total cost of sales |  |  | 5,165 |  |  |  | 4,671 |  |  |  | 10,451 |  |  |  | 9,518 |  |
| GROSS MARGIN |  |  | 8,427 |  |  |  | 8,049 |  |  |  | 16,773 |  |  |  | 16,102 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 1,855 |  |  |  | 1,670 |  |  |  | 3,636 |  |  |  | 3,384 |  |
| Sales and marketing |  |  | 2,384 |  |  |  | 2,266 |  |  |  | 4,775 |  |  |  | 4,527 |  |
| General and administrative |  |  | 582 |  |  |  | 544 |  |  |  | 1,147 |  |  |  | 1,095 |  |
| Amortization of purchased intangible assets |  |  | 71 |  |  |  | 79 |  |  |  | 142 |  |  |  | 163 |  |
| Restructuring and other charges |  |  | 243 |  |  |  | 3 |  |  |  | 241 |  |  |  | 8 |  |
| Total operating expenses |  |  | 5,135 |  |  |  | 4,562 |  |  |  | 9,941 |  |  |  | 9,177 |  |
| OPERATING INCOME |  |  | 3,292 |  |  |  | 3,487 |  |  |  | 6,832 |  |  |  | 6,925 |  |
| Interest income |  |  | 219 |  |  |  | 111 |  |  |  | 388 |  |  |  | 232 |  |
| Interest expense |  |  | (107 | ) |  |  | (88 | ) |  |  | (207 | ) |  |  | (177 | ) |
| Other income (loss), net |  |  | 11 |  |  |  | 93 |  |  |  | (123 | ) |  |  | 280 |  |
| Interest and other income (loss), net |  |  | 123 |  |  |  | 116 |  |  |  | 58 |  |  |  | 335 |  |
| INCOME BEFORE PROVISION FOR INCOME TAXES |  |  | 3,415 |  |  |  | 3,603 |  |  |  | 6,890 |  |  |  | 7,260 |  |
| Provision for income taxes |  |  | 642 |  |  |  | 630 |  |  |  | 1,447 |  |  |  | 1,307 |  |
| NET INCOME |  | $ | 2,773 |  |  | $ | 2,973 |  |  | $ | 5,443 |  |  | $ | 5,953 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.68 |  |  | $ | 0.71 |  |  | $ | 1.33 |  |  | $ | 1.42 |  |
| Diluted |  | $ | 0.67 |  |  | $ | 0.71 |  |  | $ | 1.32 |  |  | $ | 1.41 |  |
| Shares used in per-share calculation: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 4,103 |  |  |  | 4,183 |  |  |  | 4,105 |  |  |  | 4,201 |  |
| Diluted |  |  | 4,116 |  |  |  | 4,205 |  |  |  | 4,115 |  |  |  | 4,222 |  |

[0001193125-23-040212:8k_2_02:74]
5

[0001193125-23-040212:8k_2_02:75]
CISCO SYSTEMS, INC.

[0001193125-23-040212:8k_2_02:76]
REVENUE BY SEGMENT

[0001193125-23-040212:8k_2_02:77]
(In
millions, except percentages)

[0001193125-23-040212:8k_2_02:78]
|  |  | January 28, 2023 |  |
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | Amount |  |  | Y/Y% |  |  | Amount |  |  | Y/Y% |  |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 7,825 |  |  |  | 9 | % |  | $ | 15,738 |  |  |  | 7 | % |
| EMEA |  |  | 3,728 |  |  |  | 5 | % |  |  | 7,404 |  |  |  | 8 | % |
| APJC |  |  | 2,039 |  |  |  | 1 | % |  |  | 4,082 |  |  |  | 1 | % |
| Total |  | $ | 13,592 |  |  |  | 7 | % |  | $ | 27,224 |  |  |  | 6 | % |

[0001193125-23-040212:8k_2_02:79]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-23-040212:8k_2_02:80]
CISCO SYSTEMS, INC.

[0001193125-23-040212:8k_2_02:81]
GROSS MARGIN PERCENTAGE BY SEGMENT

[0001193125-23-040212:8k_2_02:82]
(In percentages)

[0001193125-23-040212:8k_2_02:83]
|  |  | January 28, 2023 |  |
|  |  | Three Months Ended |  |  | Six Months Ended |  |
| Gross Margin Percentage: |  |  |  |  |  |  |  |  |
| Americas |  |  | 62.9% |  |  |  | 62.9% |  |
| EMEA |  |  | 66.2% |  |  |  | 64.8% |  |
| APJC |  |  | 63.6% |  |  |  | 63.0% |  |

[0001193125-23-040212:8k_2_02:84]
CISCO SYSTEMS, INC.

[0001193125-23-040212:8k_2_02:85]
REVENUE FOR GROUPS OF SIMILAR PRODUCTS AND SERVICES

[0001193125-23-040212:8k_2_02:86]
(In millions, except percentages)

[0001193125-23-040212:8k_2_02:87]
|  |  | January 28, 2023 |  |
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | Amount |  |  | Y/Y% |  |  | Amount |  |  | Y/Y% |  |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Secure, Agile Networks |  | $ | 6,746 |  |  |  | 14 | % |  | $ | 13,430 |  |  |  | 13 | % |
| Internet for the Future |  |  | 1,306 |  |  |  | (1 | )% |  |  | 2,616 |  |  |  | (3 | )% |
| Collaboration |  |  | 958 |  |  |  | (10 | )% |  |  | 2,044 |  |  |  | (6 | )% |
| End-to-End Security |  |  | 943 |  |  |  | 7 | % |  |  | 1,914 |  |  |  | 8 | % |
| Optimized Application Experiences |  |  | 199 |  |  |  | 11 | % |  |  | 393 |  |  |  | 9 | % |
| Other Products |  |  | 3 |  |  |  | 25 | % |  |  | 4 |  |  |  | (17 | )% |
| Total Product |  |  | 10,155 |  |  |  | 9 | % |  |  | 20,400 |  |  |  | 8 | % |
| Services |  |  | 3,437 |  |  |  | 2 | % |  |  | 6,824 |  |  |  | 1 | % |
| Total |  | $ | 13,592 |  |  |  | 7 | % |  | $ | 27,224 |  |  |  | 6 | % |

[0001193125-23-040212:8k_2_02:88]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-23-040212:8k_2_02:89]
6

[0001193125-23-040212:8k_2_02:90]
CISCO SYSTEMS, INC.

[0001193125-23-040212:8k_2_02:91]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001193125-23-040212:8k_2_02:92]
(In millions)

[0001193125-23-040212:8k_2_02:93]
(Unaudited)

[0001193125-23-040212:8k_2_02:94]
|  |  | January 28, 2023 |  |  | July 30, 2022 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 9,009 |  |  | $ | 7,079 |  |
| Investments |  |  | 13,052 |  |  |  | 12,188 |  |
| Accounts receivable, net of allowance of $86 at January 28, 2023 and $83 at July 30, 2022 |  |  | 5,237 |  |  |  | 6,622 |  |
| Inventories |  |  | 3,140 |  |  |  | 2,568 |  |
| Financing receivables, net |  |  | 3,557 |  |  |  | 3,905 |  |
| Other current assets |  |  | 4,520 |  |  |  | 4,355 |  |
| Total current assets |  |  | 38,515 |  |  |  | 36,717 |  |
| Property and equipment, net |  |  | 1,964 |  |  |  | 1,997 |  |
| Financing receivables, net |  |  | 3,554 |  |  |  | 4,009 |  |
| Goodwill |  |  | 38,388 |  |  |  | 38,304 |  |
| Purchased intangible assets, net |  |  | 2,134 |  |  |  | 2,569 |  |
| Deferred tax assets |  |  | 5,321 |  |  |  | 4,449 |  |
| Other assets |  |  | 5,964 |  |  |  | 5,957 |  |
| TOTAL ASSETS |  | $ | 95,840 |  |  | $ | 94,002 |  |
| LIABILITIES AND EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 1,250 |  |  | $ | 1,099 |  |
| Accounts payable |  |  | 2,329 |  |  |  | 2,281 |  |
| Income taxes payable |  |  | 2,200 |  |  |  | 961 |  |
| Accrued compensation |  |  | 3,187 |  |  |  | 3,316 |  |
| Deferred revenue |  |  | 13,109 |  |  |  | 12,784 |  |
| Other current liabilities |  |  | 5,177 |  |  |  | 5,199 |  |
| Total current liabilities |  |  | 27,252 |  |  |  | 25,640 |  |
| Long-term debt |  |  | 7,637 |  |  |  | 8,416 |  |
| Income taxes payable |  |  | 6,609 |  |  |  | 7,725 |  |
| Deferred revenue |  |  | 10,818 |  |  |  | 10,480 |  |
| Other long-term liabilities |  |  | 2,050 |  |  |  | 1,968 |  |
| Total liabilities |  |  | 54,366 |  |  |  | 54,229 |  |
| Total equity |  |  | 41,474 |  |  |  | 39,773 |  |
| TOTAL LIABILITIES AND EQUITY |  | $ | 95,840 |  |  | $ | 94,002 |  |

[0001193125-23-040212:8k_2_02:95]
7

[0001193125-23-040212:8k_2_02:96]
CISCO SYSTEMS, INC.

[0001193125-23-040212:8k_2_02:97]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-23-040212:8k_2_02:98]
(In millions)

[0001193125-23-040212:8k_2_02:99]
(Unaudited)

[0001193125-23-040212:8k_2_02:100]
|  |  | Six Months Ended |  |
|  |  | January 28,2023 |  |  | January 29,2022 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 5,443 |  |  | $ | 5,953 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation, amortization, and other |  |  | 853 |  |  |  | 1,049 |  |
| Share-based compensation expense |  |  | 1,097 |  |  |  | 930 |  |
| Provision (benefit) for receivables |  |  | 6 |  |  |  | 8 |  |
| Deferred income taxes |  |  | (845 | ) |  |  | (138 | ) |
| (Gains) losses on divestitures, investments and other, net |  |  | 109 |  |  |  | (323 | ) |
| Change in operating assets and liabilities, net of effects of acquisitions and divestitures: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 1,393 |  |  |  | (308 | ) |
| Inventories |  |  | (569 | ) |  |  | (506 | ) |
| Financing receivables |  |  | 834 |  |  |  | 1,241 |  |
| Other assets |  |  | (210 | ) |  |  | (780 | ) |
| Accounts payable |  |  | 42 |  |  |  | (250 | ) |
| Income taxes, net |  |  | 118 |  |  |  | (876 | ) |
| Accrued compensation |  |  | (146 | ) |  |  | (437 | ) |
| Deferred revenue |  |  | 633 |  |  |  | 202 |  |
| Other liabilities |  |  | (57 | ) |  |  | 123 |  |
| Net cash provided by operating activities |  |  | 8,701 |  |  |  | 5,888 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of investments |  |  | (3,797 | ) |  |  | (3,937 | ) |
| Proceeds from sales of investments |  |  | 587 |  |  |  | 1,402 |  |
| Proceeds from maturities of investments |  |  | 2,316 |  |  |  | 3,185 |  |
| Acquisitions, net of cash and cash equivalents acquired and divestitures |  |  | (3 | ) |  |  | (361 | ) |
| Purchases of investments in privately held companies |  |  | (70 | ) |  |  | (124 | ) |
| Return of investments in privately held companies |  |  | 39 |  |  |  | 104 |  |
| Acquisition of property and equipment |  |  | (346 | ) |  |  | (232 | ) |
| Proceeds from sales of property and equipment |  |  | 1 |  |  |  | 5 |  |
| Other |  |  | (20 | ) |  |  | (11 | ) |
| Net cash (used in) provided by investing activities |  |  | (1,293 | ) |  |  | 31 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Issuances of common stock |  |  | 316 |  |  |  | 306 |  |
| Repurchases of common stock - repurchase program |  |  | (1,760 | ) |  |  | (5,105 | ) |
| Shares repurchased for tax withholdings on vesting of restricted stock units |  |  | (310 | ) |  |  | (411 | ) |
| Short-term borrowings, original maturities of 90 days or less, net |  |  | (602 | ) |  |  | 959 |  |
| Issuances of debt |  |  | — |  |  |  | 1,049 |  |
| Repayments of debt |  |  | — |  |  |  | (2,000 | ) |
| Dividends paid |  |  | (3,120 | ) |  |  | (3,102 | ) |
| Other |  |  | (5 | ) |  |  | (40 | ) |
| Net cash used in financing activities |  |  | (5,481 | ) |  |  | (8,344 | ) |
| Effect of foreign currency exchange rate changes on cash, cash equivalents, restricted cash and restricted cash equivalents |  |  | 3 |  |  |  | (25 | ) |
| Net increase (decrease) in cash, cash equivalents, restricted cash and restricted cash equivalents |  |  | 1,930 |  |  |  | (2,450 | ) |
| Cash, cash equivalents, restricted cash and restricted cash equivalents, beginning of period |  |  | 8,579 |  |  |  | 9,942 |  |
| Cash, cash equivalents, restricted cash and restricted cash equivalents, end of period |  | $ | 10,509 |  |  | $ | 7,492 |  |
| Supplemental cash flow information: |  |  |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 178 |  |  | $ | 184 |  |
| Cash paid for income taxes, net |  | $ | 2,172 |  |  | $ | 2,320 |  |

[0001193125-23-040212:8k_2_02:101]
8

[0001193125-23-040212:8k_2_02:102]
CISCO SYSTEMS, INC.

[0001193125-23-040212:8k_2_02:103]
REMAINING PERFORMANCE OBLIGATIONS

[0001193125-23-040212:8k_2_02:104]
(In millions, except percentages)

[0001193125-23-040212:8k_2_02:105]
|  |  | January 28, 2023 |  |  | October 29, 2022 |  |  | January 29, 2022 |  |
|  |  | Amount |  |  | Y/Y% |  |  | Amount |  |  | Y/Y% |  |  | Amount |  |  | Y/Y% |  |
| Product |  | $ | 14,517 |  |  |  | 7 | % |  | $ | 14,013 |  |  |  | 5 | % |  | $ | 13,532 |  |  |  | 16 | % |
| Service |  |  | 17,255 |  |  |  | 2 | % |  |  | 16,897 |  |  |  | 1 | % |  |  | 16,986 |  |  |  | 3 | % |
| Total |  | $ | 31,772 |  |  |  | 4 | % |  | $ | 30,910 |  |  |  | 3 | % |  | $ | 30,518 |  |  |  | 8 | % |

[0001193125-23-040212:8k_2_02:106]
We expect 53% of total RPO at January 28, 2023 will be recognized as revenue over the next 12 months.

[0001193125-23-040212:8k_2_02:107]
CISCO SYSTEMS, INC.

[0001193125-23-040212:8k_2_02:108]
DEFERRED REVENUE

[0001193125-23-040212:8k_2_02:109]
(In
millions)

[0001193125-23-040212:8k_2_02:110]
|  |  | January 28,2023 |  |  | October 29,2022 |  |  | January 29,2022 |  |
| Deferred revenue: |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 10,679 |  |  | $ | 10,404 |  |  | $ | 9,767 |  |
| Service |  |  | 13,248 |  |  |  | 12,615 |  |  |  | 12,546 |  |
| Total |  | $ | 23,927 |  |  | $ | 23,019 |  |  | $ | 22,313 |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |  |
| Current |  | $ | 13,109 |  |  | $ | 12,578 |  |  | $ | 12,268 |  |
| Noncurrent |  |  | 10,818 |  |  |  | 10,441 |  |  |  | 10,045 |  |
| Total |  | $ | 23,927 |  |  | $ | 23,019 |  |  | $ | 22,313 |  |

[0001193125-23-040212:8k_2_02:111]
CISCO SYSTEMS, INC.

[0001193125-23-040212:8k_2_02:112]
DIVIDENDS PAID AND REPURCHASES OF COMMON STOCK

[0001193125-23-040212:8k_2_02:113]
(In millions, except per-share amounts)

[0001193125-23-040212:8k_2_02:114]
|  |  | DIVIDENDS |  |  | STOCK REPURCHASE PROGRAM |  |  | TOTAL |  |
| Quarter Ended |  | Per Share |  |  | Amount |  |  | Shares |  |  | Weighted-Average Priceper Share |  |  | Amount |  |  | Amount |  |
| Fiscal 2023 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| January 28, 2023 |  | $ | 0.38 |  |  | $ | 1,560 |  |  |  | 26 |  |  | $ | 47.72 |  |  | $ | 1,256 |  |  | $ | 2,816 |  |
| October 29, 2022 |  | $ | 0.38 |  |  | $ | 1,560 |  |  |  | 12 |  |  | $ | 43.76 |  |  | $ | 502 |  |  | $ | 2,062 |  |
| Fiscal 2022 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| July 30, 2022 |  | $ | 0.38 |  |  | $ | 1,567 |  |  |  | 54 |  |  | $ | 44.02 |  |  | $ | 2,402 |  |  | $ | 3,969 |  |
| April 30, 2022 |  | $ | 0.38 |  |  | $ | 1,555 |  |  |  | 5 |  |  | $ | 54.20 |  |  | $ | 252 |  |  | $ | 1,807 |  |
| January 29, 2022 |  | $ | 0.37 |  |  | $ | 1,541 |  |  |  | 82 |  |  | $ | 58.36 |  |  | $ | 4,824 |  |  | $ | 6,365 |  |
| October 30, 2021 |  | $ | 0.37 |  |  | $ | 1,561 |  |  |  | 5 |  |  | $ | 56.49 |  |  | $ | 256 |  |  | $ | 1,817 |  |

[0001193125-23-040212:8k_2_02:115]
9

[0001193125-23-040212:8k_2_02:116]
CISCO SYSTEMS, INC.

[0001193125-23-040212:8k_2_02:117]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-23-040212:8k_2_02:118]
GAAP TO NON-GAAP NET INCOME

[0001193125-23-040212:8k_2_02:119]
(In millions)

[0001193125-23-040212:8k_2_02:120]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | January 28,2023 |  |  | January 29,2022 |  |  | January 28,2023 |  |  | January 29,2022 |  |
| GAAP net income |  | $ | 2,773 |  |  | $ | 2,973 |  |  | $ | 5,443 |  |  | $ | 5,953 |  |
| Adjustments to cost of sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 106 |  |  |  | 81 |  |  |  | 187 |  |  |  | 150 |  |
| Amortization of acquisition-related intangible assets |  |  | 153 |  |  |  | 197 |  |  |  | 306 |  |  |  | 395 |  |
| Acquisition-related/divestiture costs |  |  | 1 |  |  |  | 1 |  |  |  | 3 |  |  |  | 2 |  |
| Total adjustments to GAAP cost of sales |  |  | 260 |  |  |  | 279 |  |  |  | 496 |  |  |  | 547 |  |
| Adjustments to operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 498 |  |  |  | 396 |  |  |  | 913 |  |  |  | 779 |  |
| Amortization of acquisition-related intangible assets |  |  | 71 |  |  |  | 79 |  |  |  | 142 |  |  |  | 163 |  |
| Acquisition-related/divestiture costs |  |  | 48 |  |  |  | 120 |  |  |  | 123 |  |  |  | 232 |  |
| Russia-Ukraine war costs |  |  | 2 |  |  |  | — |  |  |  | 5 |  |  |  | — |  |
| Significant asset impairments and restructurings |  |  | 243 |  |  |  | 3 |  |  |  | 241 |  |  |  | 8 |  |
| Total adjustments to GAAP operating expenses |  |  | 862 |  |  |  | 598 |  |  |  | 1,424 |  |  |  | 1,182 |  |
| Adjustments to interest and other income (loss), net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| (Gains) and losses on equity investments |  |  | (44 | ) |  |  | (100 | ) |  |  | 65 |  |  |  | (319 | ) |
| Total adjustments to GAAP interest and other income (loss), net |  |  | (44 | ) |  |  | (100 | ) |  |  | 65 |  |  |  | (319 | ) |
| Total adjustments to GAAP income before provision for income taxes |  |  | 1,078 |  |  |  | 777 |  |  |  | 1,985 |  |  |  | 1,410 |  |
| Income tax effect of non-GAAP adjustments |  |  | (212 | ) |  |  | (202 | ) |  |  | (404 | ) |  |  | (340 | ) |
| Significant tax matters |  |  | — |  |  |  | — |  |  |  | 164 |  |  |  | — |  |
| Total adjustments to GAAP provision for income taxes |  |  | (212 | ) |  |  | (202 | ) |  |  | (240 | ) |  |  | (340 | ) |
| Non-GAAP net income |  | $ | 3,639 |  |  | $ | 3,548 |  |  | $ | 7,188 |  |  | $ | 7,023 |  |

[0001193125-23-040212:8k_2_02:121]
10

[0001193125-23-040212:8k_2_02:122]
CISCO SYSTEMS, INC.

[0001193125-23-040212:8k_2_02:123]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-23-040212:8k_2_02:124]
GAAP TO NON-GAAP EPS

[0001193125-23-040212:8k_2_02:125]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | January 28,2023 |  |  | January 29,2022 |  |  | January 28,2023 |  |  | January 29,2022 |  |
| GAAP EPS |  | $ | 0.67 |  |  | $ | 0.71 |  |  | $ | 1.32 |  |  | $ | 1.41 |  |
| Adjustments to GAAP: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 0.15 |  |  |  | 0.11 |  |  |  | 0.27 |  |  |  | 0.22 |  |
| Amortization of acquisition-related intangible assets |  |  | 0.05 |  |  |  | 0.07 |  |  |  | 0.11 |  |  |  | 0.13 |  |
| Acquisition-related/divestiture costs |  |  | 0.01 |  |  |  | 0.03 |  |  |  | 0.03 |  |  |  | 0.06 |  |
| Significant asset impairments and restructurings |  |  | 0.06 |  |  |  | — |  |  |  | 0.06 |  |  |  | — |  |
| (Gains) and losses on equity investments |  |  | (0.01 | ) |  |  | (0.02 | ) |  |  | 0.02 |  |  |  | (0.08 | ) |
| Income tax effect of non-GAAP adjustments |  |  | (0.05 | ) |  |  | (0.05 | ) |  |  | (0.10 | ) |  |  | (0.08 | ) |
| Significant tax matters |  |  | — |  |  |  | — |  |  |  | 0.04 |  |  |  | — |  |
| Non-GAAP EPS |  | $ | 0.88 |  |  | $ | 0.84 |  |  | $ | 1.75 |  |  | $ | 1.66 |  |

[0001193125-23-040212:8k_2_02:126]
Amounts may not sum due to rounding.

[0001193125-23-040212:8k_2_02:127]
11

[0001193125-23-040212:8k_2_02:128]
CISCO SYSTEMS, INC.

[0001193125-23-040212:8k_2_02:129]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-23-040212:8k_2_02:130]
GROSS MARGINS, OPERATING EXPENSES, OPERATING MARGINS, INTEREST AND OTHER INCOME (LOSS), NET,

[0001193125-23-040212:8k_2_02:131]
AND NET INCOME

[0001193125-23-040212:8k_2_02:132]
(In
millions, except percentages)

[0001193125-23-040212:8k_2_02:133]
|  |  | Three Months Ended |  |
|  |  | January 28, 2023 |  |
|  |  | ProductGrossMargin |  |  | ServiceGrossMargin |  |  | TotalGrossMargin |  |  | OperatingExpenses |  |  | Y/Y |  |  | OperatingIncome |  |  | Y/Y |  |  | Interestandotherincome(loss),net |  |  | NetIncome |  |  | Y/Y |  |
| GAAP amount |  | $ | 6,117 |  |  | $ | 2,310 |  |  | $ | 8,427 |  |  | $ | 5,135 |  |  |  | 13 | % |  | $ | 3,292 |  |  |  | (6 | )% |  | $ | 123 |  |  | $ | 2,773 |  |  |  | (7 | )% |
| % of revenue |  |  | 60.2 | % |  |  | 67.2 | % |  |  | 62.0 | % |  |  | 37.8 | % |  |  |  |  |  |  | 24.2 | % |  |  |  |  |  |  | 0.9 | % |  |  | 20.4 | % |  |  |  |  |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 40 |  |  |  | 66 |  |  |  | 106 |  |  |  | 498 |  |  |  |  |  |  |  | 604 |  |  |  |  |  |  |  | — |  |  |  | 604 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  |  | 153 |  |  |  | — |  |  |  | 153 |  |  |  | 71 |  |  |  |  |  |  |  | 224 |  |  |  |  |  |  |  | — |  |  |  | 224 |  |  |  |  |  |
| Acquisition/divestiture-related costs |  |  | 1 |  |  |  | — |  |  |  | 1 |  |  |  | 48 |  |  |  |  |  |  |  | 49 |  |  |  |  |  |  |  | — |  |  |  | 49 |  |  |  |  |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 243 |  |  |  |  |  |  |  | 243 |  |  |  |  |  |  |  | — |  |  |  | 243 |  |  |  |  |  |
| Russia-Ukraine war costs |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 2 |  |  |  |  |  |  |  | 2 |  |  |  |  |  |  |  | — |  |  |  | 2 |  |  |  |  |  |
| (Gains) and losses on equity investments |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | (44 | ) |  |  | (44 | ) |  |  |  |  |
| Income tax effect/significant tax matters |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  | (212 | ) |  |  |  |  |
| Non-GAAP amount |  | $ | 6,311 |  |  | $ | 2,376 |  |  | $ | 8,687 |  |  | $ | 4,273 |  |  |  | 8 | % |  | $ | 4,414 |  |  |  | 1 | % |  | $ | 79 |  |  | $ | 3,639 |  |  |  | 3 | % |
| % of revenue |  |  | 62.1 | % |  |  | 69.1 | % |  |  | 63.9 | % |  |  | 31.4 | % |  |  |  |  |  |  | 32.5 | % |  |  |  |  |  |  | 0.6 | % |  |  | 26.8 | % |  |  |  |  |

[0001193125-23-040212:8k_2_02:134]
|  |  | Three Months Ended |  |
|  |  | January 29, 2022 |  |
|  |  | ProductGrossMargin |  |  | ServiceGrossMargin |  |  | Total GrossMargin |  |  | OperatingExpenses |  |  | OperatingIncome |  |  | Interestand otherincome(loss), net |  |  | NetIncome |  |
| GAAP amount |  | $ | 5,784 |  |  | $ | 2,265 |  |  | $ | 8,049 |  |  | $ | 4,562 |  |  | $ | 3,487 |  |  | $ | 116 |  |  | $ | 2,973 |  |
| % of revenue |  |  | 61.8 | % |  |  | 67.3 | % |  |  | 63.3 | % |  |  | 35.9 | % |  |  | 27.4 | % |  |  | 0.9 | % |  |  | 23.4 | % |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 29 |  |  |  | 52 |  |  |  | 81 |  |  |  | 396 |  |  |  | 477 |  |  |  | — |  |  |  | 477 |  |
| Amortization of acquisition-related intangible assets |  |  | 197 |  |  |  | — |  |  |  | 197 |  |  |  | 79 |  |  |  | 276 |  |  |  | — |  |  |  | 276 |  |
| Acquisition/divestiture-related costs |  |  | 1 |  |  |  | — |  |  |  | 1 |  |  |  | 120 |  |  |  | 121 |  |  |  | — |  |  |  | 121 |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 3 |  |  |  | 3 |  |  |  | — |  |  |  | 3 |  |
| (Gains) and losses on equity investments |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (100 | ) |  |  | (100 | ) |
| Income tax effect/significant tax matters |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (202 | ) |
| Non-GAAP amount |  | $ | 6,011 |  |  | $ | 2,317 |  |  | $ | 8,328 |  |  | $ | 3,964 |  |  | $ | 4,364 |  |  | $ | 16 |  |  | $ | 3,548 |  |
| % of revenue |  |  | 64.3 | % |  |  | 68.8 | % |  |  | 65.5 | % |  |  | 31.2 | % |  |  | 34.3 | % |  |  | 0.1 | % |  |  | 27.9 | % |

[0001193125-23-040212:8k_2_02:135]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-23-040212:8k_2_02:136]
12

[0001193125-23-040212:8k_2_02:137]
CISCO SYSTEMS, INC.

[0001193125-23-040212:8k_2_02:138]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-23-040212:8k_2_02:139]
GROSS MARGINS, OPERATING EXPENSES, OPERATING MARGINS, INTEREST AND OTHER INCOME (LOSS), NET,

[0001193125-23-040212:8k_2_02:140]
AND NET INCOME

[0001193125-23-040212:8k_2_02:141]
(In
millions, except percentages)

[0001193125-23-040212:8k_2_02:142]
|  |  | Six Months Ended |  |
|  |  | January 28, 2023 |  |
|  |  | ProductGrossMargin |  |  | ServiceGrossMargin |  |  | TotalGrossMargin |  |  | OperatingExpenses |  |  | Y/Y |  |  | OperatingIncome |  |  | Y/Y |  |  | Interestandotherincome(loss),net |  |  | NetIncome |  |  | Y/Y |  |
| GAAP amount |  | $ | 12,183 |  |  | $ | 4,590 |  |  | $ | 16,773 |  |  | $ | 9,941 |  |  |  | 8 | % |  | $ | 6,832 |  |  |  | (1 | )% |  | $ | 58 |  |  | $ | 5,443 |  |  |  | (9 | )% |
| % of revenue |  |  | 59.7 | % |  |  | 67.3 | % |  |  | 61.6 | % |  |  | 36.5 | % |  |  |  |  |  |  | 25.1 | % |  |  |  |  |  |  | 0.2 | % |  |  | 20.0 | % |  |  |  |  |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 71 |  |  |  | 116 |  |  |  | 187 |  |  |  | 913 |  |  |  |  |  |  |  | 1,100 |  |  |  |  |  |  |  | — |  |  |  | 1,100 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  |  | 306 |  |  |  | — |  |  |  | 306 |  |  |  | 142 |  |  |  |  |  |  |  | 448 |  |  |  |  |  |  |  | — |  |  |  | 448 |  |  |  |  |  |
| Acquisition/divestiture-related costs |  |  | 3 |  |  |  | — |  |  |  | 3 |  |  |  | 123 |  |  |  |  |  |  |  | 126 |  |  |  |  |  |  |  | — |  |  |  | 126 |  |  |  |  |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 241 |  |  |  |  |  |  |  | 241 |  |  |  |  |  |  |  | — |  |  |  | 241 |  |  |  |  |  |
| Russia-Ukraine war costs |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 5 |  |  |  |  |  |  |  | 5 |  |  |  |  |  |  |  | — |  |  |  | 5 |  |  |  |  |  |
| (Gains) and losses on equity investments |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | 65 |  |  |  | 65 |  |  |  |  |  |
| Income tax effect/significant tax matters |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  | (240 | ) |  |  |  |  |
| Non-GAAP amount |  | $ | 12,563 |  |  | $ | 4,706 |  |  | $ | 17,269 |  |  | $ | 8,517 |  |  |  | 7 | % |  | $ | 8,752 |  |  |  | 1 | % |  | $ | 123 |  |  | $ | 7,188 |  |  |  | 2 | % |
| % of revenue |  |  | 61.6 | % |  |  | 69.0 | % |  |  | 63.4 | % |  |  | 31.3 | % |  |  |  |  |  |  | 32.1 | % |  |  |  |  |  |  | 0.5 | % |  |  | 26.4 | % |  |  |  |  |

[0001193125-23-040212:8k_2_02:143]
|  |  | Six Months Ended |  |
|  |  | January 29, 2022 |  |
|  |  | ProductGrossMargin |  |  | ServiceGrossMargin |  |  | Total GrossMargin |  |  | OperatingExpenses |  |  | OperatingIncome |  |  | Interestand otherincome(loss), net |  |  | NetIncome |  |
| GAAP amount |  | $ | 11,640 |  |  | $ | 4,462 |  |  | $ | 16,102 |  |  | $ | 9,177 |  |  | $ | 6,925 |  |  | $ | 335 |  |  | $ | 5,953 |  |
| % of revenue |  |  | 61.6 | % |  |  | 66.2 | % |  |  | 62.8 | % |  |  | 35.8 | % |  |  | 27.0 | % |  |  | 1.3 | % |  |  | 23.2 | % |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 54 |  |  |  | 96 |  |  |  | 150 |  |  |  | 779 |  |  |  | 929 |  |  |  | — |  |  |  | 929 |  |
| Amortization of acquisition-related intangible assets |  |  | 395 |  |  |  | — |  |  |  | 395 |  |  |  | 163 |  |  |  | 558 |  |  |  | — |  |  |  | 558 |  |
| Acquisition/divestiture-related costs |  |  | 2 |  |  |  | — |  |  |  | 2 |  |  |  | 232 |  |  |  | 234 |  |  |  | — |  |  |  | 234 |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 8 |  |  |  | 8 |  |  |  | — |  |  |  | 8 |  |
| (Gains) and losses on equity investments |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (319 | ) |  |  | (319 | ) |
| Income tax effect/significant tax matters |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (340 | ) |
| Non-GAAP amount |  | $ | 12,091 |  |  | $ | 4,558 |  |  | $ | 16,649 |  |  | $ | 7,995 |  |  | $ | 8,654 |  |  | $ | 16 |  |  | $ | 7,023 |  |
| % of revenue |  |  | 64.0 | % |  |  | 67.6 | % |  |  | 65.0 | % |  |  | 31.2 | % |  |  | 33.8 | % |  |  | 0.1 | % |  |  | 27.4 | % |

[0001193125-23-040212:8k_2_02:144]
Amounts may not sum and percentages may not recalculate due to rounding.

[0001193125-23-040212:8k_2_02:145]
13

[0001193125-23-040212:8k_2_02:146]
CISCO SYSTEMS, INC.

[0001193125-23-040212:8k_2_02:147]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-23-040212:8k_2_02:148]
EFFECTIVE TAX RATE

[0001193125-23-040212:8k_2_02:149]
(In
percentages)

[0001193125-23-040212:8k_2_02:150]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | January 28,2023 |  |  | January 29,2022 |  |  | January 28,2023 |  |  | January 29,2022 |  |
| GAAP effective tax rate |  |  | 18.8 | % |  |  | 17.5 | % |  |  | 21.0 | % |  |  | 18.0 | % |
| Total adjustments to GAAP provision for income taxes |  |  | 0.2 | % |  |  | 1.5 | % |  |  | (2.0 | )% |  |  | 1.0 | % |
| Non-GAAP effective tax rate |  |  | 19.0 | % |  |  | 19.0 | % |  |  | 19.0 | % |  |  | 19.0 | % |

[0001193125-23-040212:8k_2_02:151]
GAAP TO NON-GAAP GUIDANCE

[0001193125-23-040212:8k_2_02:152]
| Q3 FY 2023 |  | Gross MarginRate |  | Operating MarginRate |  | Earnings perShare (2) |
| GAAP |  | 61.5% – 62.5% |  | 25.5% – 26.5% |  | $0.74 – $0.79 |
| Estimated adjustments for: |  |  |  |  |  |  |
| Share-based compensation expense |  | 1.0% |  | 4.5% |  | $0.12 – $0.13 |
| Amortization of acquisition-related intangible assets and acquisition/divestiture-related costs |  | 1.0% |  | 2.0% |  | $0.05 – $0.06 |
| Significant asset impairments and restructurings (1) |  | — |  | 1.0% |  | $0.02 – $0.03 |
| Non-GAAP |  | 63.5% – 64.5% |  | 33% – 34% |  | $0.96 – $0.98 |

[0001193125-23-040212:8k_2_02:153]
| FY 2023 |  | Earnings perShare (2) |
| GAAP |  | $2.85 – $2.96 |
| Estimated adjustments for: |  |  |
| Share-based compensation expense |  | $0.46 – $0.48 |
| Amortization of acquisition-related intangible assets and acquisition/divestiture-related costs |  | $0.21 – $0.23 |
| Significant asset impairments and restructurings (1) |  | $0.10 – $0.12 |
| (Gains) and losses on equity investments |  | $0.01 |
| Significant tax matters |  | $0.04 |
| Non-GAAP |  | $3.73 – $3.78 |

[0001193125-23-040212:8k_2_02:154]
| (1) | On November 16, 2022, Cisco announced a restructuring plan in order to rebalance the organization and enable further investment in key priority areas. This rebalancing includes talent movement options and restructuring. Additionally, Cisco has begun optimizing its real estate portfolio, aligned to the broader hybrid work strategy. Cisco estimates that it will recognize pre-tax charges to its GAAP financial results of approximately $600 million consisting of severance and other one-time termination benefits, real estate-related charges, and other costs. These charges are primarily cash-based. We recognized $243 million of these charges during the second quarter of fiscal 2023. We expect to recognize approximately $140 million of these charges in each of the third and fourth quarters of fiscal 2023, and the remaining amount of these charges primarily in the first quarter of fiscal 2024. |

[0001193125-23-040212:8k_2_02:155]
| (2) | Estimated adjustments to GAAP earnings per share are shown after income tax effects. |

[0001193125-23-040212:8k_2_02:156]
Except as noted above, this guidance does not include the effects of any future acquisitions/divestitures, asset impairments, Russia-Ukraine war costs,
restructurings, (gains) and losses on equity investments and significant tax matters or other events, which may or may not be significant unless specifically stated.

[0001193125-23-040212:8k_2_02:157]
14

[0001193125-23-040212:8k_2_02:158]
Forward Looking Statements, Non-GAAP Information and Additional
Information

[0001193125-23-040212:8k_2_02:159]
This release includes non-GAAP net income, non-GAAP gross margins, non-GAAP operating expenses, non-GAAP operating income and margin, non-GAAP effective tax rates,
non-GAAP interest and other income (loss), net, and non-GAAP net income per share data for the periods presented. It also includes future estimated ranges for gross
margin, operating margin, tax provision rate and EPS on a non-GAAP basis.

[0001193125-23-040212:8k_2_02:160]
These
non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with generally accepted accounting principles and may be different from
non-GAAP measures used by other companies. In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles. Cisco believes
that non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Cisco’s results of operations as determined in accordance with GAAP and that these measures should
only be used to evaluate Cisco’s results of operations in conjunction with the corresponding GAAP measures.

[0001193125-23-040212:8k_2_02:161]
Cisco believes that the presentation of non-GAAP measures when shown in conjunction with the corresponding GAAP measures, provides useful information to investors and management regarding financial and business trends relating to its financial condition
and its historical and projected results of operations.

[0001193125-23-040212:8k_2_02:162]
For its internal budgeting process, Cisco’s management uses financial statements that do not
include, when applicable, share-based compensation expense, amortization of acquisition-related intangible assets, acquisition-related/divestiture costs, significant asset impairments and restructurings, significant litigation settlements and other
contingencies, Russia-Ukraine war costs, gains and losses on equity investments, the income tax effects of the foregoing and significant tax matters. Cisco’s management also uses the foregoing non-GAAP
measures, in addition to the corresponding GAAP measures, in reviewing the

[0001193125-23-040212:8k_2_02:163]
financial results of Cisco. In prior periods, Cisco has excluded other items that it no longer excludes for purposes of its non-GAAP financial measures.
From time to time in the future there may be other items that Cisco may exclude for purposes of its internal budgeting process and in reviewing its financial results. For additional information on the items excluded by Cisco from one or more of its non-GAAP financial measures, refer to the Form 8-K regarding this release furnished today to the Securities and Exchange Commission.

[0001193125-23-040212:8k_2_02:164]
Annualized recurring revenue represents the annualized revenue run-rate of active subscriptions, term licenses, and
maintenance contracts at the end of a reporting period, net of rebates to customers and partners as well as certain other revenue adjustments. Includes both revenue recognized ratably as well as upfront on an annualized basis.

[0001193125-23-040212:8k_2_02:165]
About Cisco

[0001193125-23-040212:8k_2_02:166]
Cisco (Nasdaq: CSCO) is the worldwide
leader in technology that powers the Internet. Cisco inspires new possibilities by reimagining your applications, securing your data, transforming your infrastructure, and empowering your teams for a global and inclusive future.
Discover more at newsroom.cisco.com and follow us on Twitter at @Cisco.

[0001193125-23-040212:8k_2_02:167]
Copyright © 2023 Cisco
and/or its affiliates. All rights reserved. Cisco and the Cisco logo are trademarks or registered trademarks of Cisco and/or its affiliates in the U.S. and other countries. To view a list of Cisco trademarks, go to: www.cisco.com/go/trademarks.
Third-party trademarks mentioned in this document are the property of their respective owners. The use of the word partner does not imply a partnership relationship between Cisco and any other company. This document is Cisco Public Information.

[0001193125-23-040212:8k_2_02:168]
RSS Feed for Cisco: https://newsroom.cisco.com/rss-feeds

[0001193125-23-040212:8k_2_02:169]
16
