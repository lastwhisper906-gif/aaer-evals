# CSCO notes — 0000858877-23-000005


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000858877-23-000005:notes:1]
[same as prior period, unchanged from 0000858877-22-000025:notes:1]

[0000858877-23-000005:notes:2]
We have prepared the accompanying financial data as of January 28, 2023 and for the second quarter and first six months of fiscal 2023 and 2022, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (SEC). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (GAAP) have been condensed or omitted pursuant to such rules and regulations. The July 30, 2022 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, we believe that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in our Annual Report on Form 10-K for the fiscal year ended July 30, 2022.

[0000858877-23-000005:notes:3]
In the opinion of management, all normal recurring adjustments necessary to state fairly the consolidated balance sheet as of January 28, 2023, the results of operations, the statements of comprehensive income and the statements of equity for the second quarter and first six months of fiscal 2023 and 2022, and the statements of cash flows for the first six months of fiscal 2023 and 2022, as applicable, have been made. The results of operations for the second quarter and first six months of fiscal 2023 are not necessarily indicative of the operating results for the full fiscal year or any future periods.

[0000858877-23-000005:notes:4]
[same as prior period, unchanged from 0000858877-22-000025:notes:4]

[0000858877-23-000005:notes:5]
Certain reclassifications have been made to the amounts in prior periods in order to conform to the current period’s presentation. We have evaluated subsequent events through the date that the financial statements were issued.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000858877-23-000005:notes:6]
[same as prior period, unchanged from 0000858877-22-000025:notes:6]

[0000858877-23-000005:notes:7]
Reference Rate Reform  In March 2020, the Financial Accounting Standards Board issued an accounting standard update and subsequent amendments that provide optional expedients and exceptions to the current guidance on contract modification and hedging relationships to ease the financial reporting burden of the expected market transition from the London InterBank Offered Rate (LIBOR) and other interbank offered rates to alternative reference rates. This accounting standard update was effective upon issuance and may be applied prospectively through December 31, 2024. We do not expect this accounting standard update will have a material impact on our Consolidated Financial Statements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000858877-23-000005:notes:8]
[same as prior period, unchanged from 0000858877-22-000025:notes:8]

[0000858877-23-000005:notes:9]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of January 28, 2023 and July 30, 2022 was $40 million and $43 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.

[0000858877-23-000005:notes:10]
[same as prior period, unchanged from 0000858877-22-000025:notes:10]

[0000858877-23-000005:notes:11]
[same as prior period, unchanged from 0000858877-22-000025:notes:11]

[0000858877-23-000005:notes:12]
[same as prior period, unchanged from 0000858877-22-000025:notes:12]

[0000858877-23-000005:notes:13]
[same as prior period, unchanged from 0000858877-22-000025:notes:13]

[0000858877-23-000005:notes:14]
[same as prior period, unchanged from 0000858877-22-000025:notes:14]

[0000858877-23-000005:notes:15]
[same as prior period, unchanged from 0000858877-22-000025:notes:15]

[0000858877-23-000005:notes:16]
|  | Three Months Ended |  | Six Months Ended |
|  | January 28,2023 |  | January 29,2022 |  | January 28, 2023 |  | January 29, 2022 |
| Product revenue: |  |  |  |  |  |  |  |
| Secure, Agile Networks | $ | 6,746 |  |  | $ | 5,899 |  |  | $ | 13,430 |  |  | $ | 11,867 |  |
| Internet for the Future | 1,306 |  |  | 1,322 |  |  | 2,616 |  |  | 2,695 |  |
| Collaboration | 958 |  |  | 1,067 |  |  | 2,044 |  |  | 2,176 |  |
| End-to-End Security | 943 |  |  | 883 |  |  | 1,914 |  |  | 1,778 |  |
| Optimized Application Experiences | 199 |  |  | 180 |  |  | 393 |  |  | 361 |  |
| Other Products | 3 |  |  | 2 |  |  | 4 |  |  | 5 |  |
| Total Product | 10,155 |  |  | 9,353 |  |  | 20,400 |  |  | 18,882 |  |
| Services | 3,437 |  |  | 3,367 |  |  | 6,824 |  |  | 6,738 |  |
| Total | $ | 13,592 |  |  | $ | 12,720 |  |  | $ | 27,224 |  |  | $ | 25,620 |  |

[0000858877-23-000005:notes:17]
Amounts may not sum due to rounding. We have made certain reclassifications to the product revenue amounts for prior periods to conform to the current year presentation.

[0000858877-23-000005:notes:18]
[same as prior period, unchanged from 0000858877-22-000025:notes:18]

[0000858877-23-000005:notes:19]
[same as prior period, unchanged from 0000858877-22-000025:notes:19]

[0000858877-23-000005:notes:20]
[same as prior period, unchanged from 0000858877-22-000025:notes:20]

[0000858877-23-000005:notes:21]
[same as prior period, unchanged from 0000858877-22-000025:notes:21]

[0000858877-23-000005:notes:22]
[same as prior period, unchanged from 0000858877-22-000025:notes:22]

[0000858877-23-000005:notes:23]
[same as prior period, unchanged from 0000858877-22-000025:notes:23]

[0000858877-23-000005:notes:24]
[same as prior period, unchanged from 0000858877-22-000025:notes:24]

[0000858877-23-000005:notes:25]
[same as prior period, unchanged from 0000858877-22-000025:notes:25]

[0000858877-23-000005:notes:26]
[same as prior period, unchanged from 0000858877-22-000025:notes:26]

[0000858877-23-000005:notes:27]
Accounts receivable, net was $5.2 billion as of January 28, 2023 compared to $6.6 billion as of July 30, 2022, as reported on the Consolidated Balance Sheets.

[0000858877-23-000005:notes:28]
[same as prior period, unchanged from 0000858877-22-000025:notes:28]

[0000858877-23-000005:notes:29]
|  | Three Months Ended |  | Six Months Ended |
|  | January 28, 2023 |  | January 29, 2022 |  | January 28, 2023 |  | January 29, 2022 |
| Allowance for credit loss at beginning of period | $ | 88 |  |  | $ | 114 |  |  | $ | 83 |  |  | $ | 109 |  |
| Provisions (benefits) | 3 |  |  | 17 |  |  | 14 |  |  | 36 |  |
| Recoveries (write-offs), net | (5) |  |  | (52) |  |  | (11) |  |  | (66) |  |
| Foreign exchange and other | — |  |  | (9) |  |  | — |  |  | (9) |  |
| Allowance for credit loss at end of period | $ | 86 |  |  | $ | 70 |  |  | $ | 86 |  |  | $ | 70 |  |

[0000858877-23-000005:notes:30]
[same as prior period, unchanged from 0000858877-22-000025:notes:30]

[0000858877-23-000005:notes:31]
[same as prior period, unchanged from 0000858877-22-000025:notes:31]

[0000858877-23-000005:notes:32]
|  | January 28,2023 |  | July 30,2022 |
| 1 to 4 | $ | 355 |  |  | $ | 414 |  |
| 5 to 6 | 984 |  |  | 814 |  |
| 7 and Higher | 82 |  |  | 158 |  |
| Total | $ | 1,421 |  |  | $ | 1,386 |  |

[0000858877-23-000005:notes:33]
Contract assets consist of unbilled receivables and are recorded when revenue is recognized in advance of scheduled billings to our customers. These amounts are primarily related to software and service arrangements where transfer of control has occurred but we have not yet invoiced. Our contract assets for these unbilled receivables, net of allowances, was $1.4 billion as of January 28, 2023 and $1.3 billion as of  July 30, 2022, and were included in other current assets and other assets.

[0000858877-23-000005:notes:34]
Contract liabilities consist of deferred revenue. Deferred revenue was $23.9 billion as of January 28, 2023 compared to $23.3 billion as of July 30, 2022. We recognized approximately $3.4 billion and $7.9 billion of revenue during the second quarter and first six months of fiscal 2023 that was included in the deferred revenue balance at July 30, 2022. 
(c)Capitalized Contract Acquisition CostsWe capitalize direct and incremental costs incurred to acquire contracts, primarily sales commissions, for which the associated revenue is expected to be recognized in future periods. We incur these costs in connection with both initial contracts and renewals. These costs are initially deferred and typically amortized over the term of the customer contract which corresponds to the period of benefit. Deferred sales commissions were $1.0 billion as of each of January 28, 2023 and July 30, 2022, and were included in other current assets and other assets. The amortization expense associated with these costs was $201 million and $377 million for the second quarter and first six months of fiscal 2023, respectively, and $147 million and $317 million for the corresponding periods of fiscal 2022, respectively, and was included in sales and marketing expenses.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0000858877-23-000005:notes:35]
[same as prior period, unchanged from 0000858877-22-000025:notes:35]


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0000858877-23-000005:notes:36]
[same as prior period, unchanged from 0000858877-22-000025:notes:36]

[0000858877-23-000005:notes:37]
[same as prior period, unchanged from 0000858877-22-000025:notes:37]

[0000858877-23-000005:notes:38]
|  | Three Months Ended |  | Six Months Ended |
|  | January 28,2023 |  | January 29,2022 |  | January 28,2023 |  | January 29,2022 |
| Revenue: |  |  |  |  |  |  |  |
| Secure, Agile Networks | $ | 6,746 |  |  | $ | 5,899 |  |  | $ | 13,430 |  |  | $ | 11,867 |  |
| Internet for the Future | 1,306 |  |  | 1,322 |  |  | 2,616 |  |  | 2,695 |  |
| Collaboration | 958 |  |  | 1,067 |  |  | 2,044 |  |  | 2,176 |  |
| End-to-End Security | 943 |  |  | 883 |  |  | 1,914 |  |  | 1,778 |  |
| Optimized Application Experiences | 199 |  |  | 180 |  |  | 393 |  |  | 361 |  |
| Other Products | 3 |  |  | 2 |  |  | 4 |  |  | 5 |  |
| Total Product | 10,155 |  |  | 9,353 |  |  | 20,400 |  |  | 18,882 |  |
| Services | 3,437 |  |  | 3,367 |  |  | 6,824 |  |  | 6,738 |  |
| Total | $ | 13,592 |  |  | $ | 12,720 |  |  | $ | 27,224 |  |  | $ | 25,620 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000858877-23-000005:notes:39]
Acquisitions and Divestitures
We completed one acquisition during the first six months of fiscal 2023. A summary of the allocation of the total purchase consideration is presented as follows (in millions):

[0000858877-23-000005:notes:40]
|  | Purchase Consideration |  | Net Tangible Assets Acquired (Liabilities Assumed) |  | Purchased Intangible Assets |  | Goodwill |
| Total acquisitions (one in total) | $ | 3 |  |  | $ | — |  |  | $ | — |  |  | $ | 3 |  |

[0000858877-23-000005:notes:41]
The total purchase consideration related to our acquisition completed during the first six months of fiscal 2023 consisted of cash consideration. Total transaction costs related to acquisition and divestiture activities were $3 million and $38 million for the first six months of fiscal 2023 and 2022, respectively. These transaction costs were expensed as incurred in general and administrative expenses (“G&A”) in the Consolidated Statements of Operations.

[0000858877-23-000005:notes:42]
The goodwill generated from acquisitions completed during the first six months of fiscal 2023 is primarily related to expected synergies. The goodwill is generally not deductible for income tax purposes.

[0000858877-23-000005:notes:43]
The Consolidated Financial Statements include the operating results of each acquisition from the date of acquisition. Pro forma results of operations and the revenue and net income subsequent to the acquisition date for the acquisition completed during the first six months of fiscal 2023 have not been presented because the effects of the acquisition were not material to our financial results.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000858877-23-000005:notes:44]
[same as prior period, unchanged from 0000858877-22-000025:notes:40]

[0000858877-23-000005:notes:45]
The following table presents the goodwill allocated to our reportable segments as of January 28, 2023 and during the first six months of fiscal 2023 (in millions):

[0000858877-23-000005:notes:46]
|  | Balance at July 30, 2022 |  | Acquisitions & Divestitures |  | Foreign Currency Translation and Other |  | Balance at January 28, 2023 |
| Americas | $ | 23,882 |  |  | $ | 3 |  |  | $ | 51 |  |  | $ | 23,936 |  |
| EMEA | 9,062 |  |  | — |  |  | 19 |  |  | 9,081 |  |
| APJC | 5,360 |  |  | — |  |  | 11 |  |  | 5,371 |  |
| Total | $ | 38,304 |  |  | $ | 3 |  |  | $ | 81 |  |  | $ | 38,388 |  |

[0000858877-23-000005:notes:47]
[same as prior period, unchanged from 0000858877-22-000025:notes:43]

[0000858877-23-000005:notes:48]
[same as prior period, unchanged from 0000858877-22-000025:notes:44]

[0000858877-23-000005:notes:49]
| January 28, 2023 |  | Gross |  | Accumulated Amortization |  | Net |
| Purchased intangible assets with finite lives: |  |  |  |  |  |  |
| Technology |  | $ | 2,620 |  |  | $ | (1,384) |  |  | $ | 1,236 |  |
| Customer relationships |  | 1,334 |  |  | (889) |  |  | 445 |  |
| Other |  | 40 |  |  | (17) |  |  | 23 |  |
| Total purchased intangible assets with finite lives |  | 3,994 |  |  | (2,290) |  |  | 1,704 |  |
| In-process research and development, with indefinite lives |  | 430 |  |  | — |  |  | 430 |  |
| Total |  | $ | 4,424 |  |  | $ | (2,290) |  |  | $ | 2,134 |  |

[0000858877-23-000005:notes:50]
[same as prior period, unchanged from 0000858877-22-000025:notes:46]

[0000858877-23-000005:notes:51]
[same as prior period, unchanged from 0000858877-22-000025:notes:47]

[0000858877-23-000005:notes:52]
[same as prior period, unchanged from 0000858877-22-000025:notes:48]

[0000858877-23-000005:notes:53]
|  | Three Months Ended |  | Six Months Ended |
|  | January 28, 2023 |  | January 29, 2022 |  | January 28, 2023 |  | January 29, 2022 |
| Amortization of purchased intangible assets: |  |  |  |  |  |  |  |
| Cost of sales | $ | 158 |  |  | $ | 201 |  |  | $ | 316 |  |  | $ | 403 |  |
| Operating expenses | 71 |  |  | 79 |  |  | 142 |  |  | 163 |  |
| Total | $ | 229 |  |  | $ | 280 |  |  | $ | 458 |  |  | $ | 566 |  |

[0000858877-23-000005:notes:54]
The estimated future amortization expense of purchased intangible assets with finite lives as of January 28, 2023 is as follows (in millions):

[0000858877-23-000005:notes:55]
| Fiscal Year | Amount |
| 2023 (remaining six months) | $ | 450 |  |
| 2024 | $ | 778 |  |
| 2025 | $ | 406 |  |
| 2026 | $ | 65 |  |
| 2027 | $ | 5 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000858877-23-000005:notes:56]
Restructuring and Other Charges
In the second quarter of fiscal 2023, we announced a restructuring plan (the “Fiscal 2023 Plan”), in order to rebalance the organization and enable further investment in key priority areas. This rebalancing includes talent movement options and restructuring. Additionally, we have begun optimizing our real estate portfolio, aligned to the broader hybrid work strategy. The total pretax charges are estimated to be approximately $600 million and is expected to impact approximately 5% of our global workforce. In connection with the Fiscal 2023 Plan, we incurred charges of $243 million for the second quarter and first six months of fiscal 2023. These aggregate pretax charges will be primarily cash-based and will consist of severance and other one-time termination benefits, real estate-related charges, and other costs. We expect the plan to be substantially completed by the end of the first quarter of fiscal 2024.

[0000858877-23-000005:notes:57]
[same as prior period, unchanged from 0000858877-22-000025:notes:53]

[0000858877-23-000005:notes:58]
|  |  | FISCAL 2021 AND PRIOR PLANS |  | FISCAL 2023 PLAN |  |  |
|  |  | EmployeeSeverance |  | Other |  | EmployeeSeverance |  | Other |  | Total |
| Liability as of July 30, 2022 |  | $ | 2 |  |  | $ | 7 |  |  | $ | — |  |  | $ | — |  |  | $ | 9 |  |
| Charges |  | — |  |  | (2) |  |  | 223 |  |  | 20 |  |  | 241 |  |
| Cash payments |  | (1) |  |  | (1) |  |  | (49) |  |  | (1) |  |  | (52) |  |
| Non-cash items |  | — |  |  | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Liability as of January 28, 2023 |  | $ | 1 |  |  | $ | 4 |  |  | $ | 175 |  |  | $ | 19 |  |  | $ | 199 |  |

[0000858877-23-000005:notes:59]
|  |  | FISCAL 2020 AND PRIOR PLANS |  | FISCAL 2021 PLAN |  |  |
|  |  | EmployeeSeverance |  | Other |  | Employee Severance |  | Other |  | Total |
| Liability as of July 31, 2021 |  | $ | — |  |  | $ | 10 |  |  | $ | 16 |  |  | $ | 8 |  |  | $ | 34 |  |
| Charges |  | — |  |  | (5) |  |  | 10 |  |  | 3 |  |  | 8 |  |
| Cash payments |  | — |  |  | (1) |  |  | (16) |  |  | — |  |  | (17) |  |
| Non-cash items |  | — |  |  | — |  |  | — |  |  | (5) |  |  | (5) |  |
| Liability as of January 29, 2022 |  | $ | — |  |  | $ | 4 |  |  | $ | 10 |  |  | $ | 6 |  |  | $ | 20 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000858877-23-000005:notes:60]
Balance Sheet and Other Details 
The following tables provide details of selected balance sheet and other items (in millions, except percentages):

[0000858877-23-000005:notes:61]
[same as prior period, unchanged from 0000858877-22-000025:notes:57]

[0000858877-23-000005:notes:62]
|  |  | January 28,2023 |  | July 30,2022 |
| Cash and cash equivalents |  | $ | 9,009 |  |  | $ | 7,079 |  |
| Restricted cash and restricted cash equivalents included in other assets |  | 1,500 |  |  | 1,500 |  |
| Total |  | $ | 10,509 |  |  | $ | 8,579 |  |

[0000858877-23-000005:notes:63]
[same as prior period, unchanged from 0000858877-22-000025:notes:59]

[0000858877-23-000005:notes:64]
[same as prior period, unchanged from 0000858877-22-000025:notes:60]

[0000858877-23-000005:notes:65]
|  |  | January 28,2023 |  | July 30,2022 |
| Raw materials |  | $ | 1,496 |  |  | $ | 1,601 |  |
| Work in process |  | 230 |  |  | 150 |  |
| Finished goods: |  |  |  |  |
| Deferred cost of sales |  | 70 |  |  | 86 |  |
| Manufactured finished goods |  | 1,222 |  |  | 631 |  |
| Total finished goods |  | 1,292 |  |  | 717 |  |
| Service-related spares |  | 109 |  |  | 90 |  |
| Demonstration systems |  | 13 |  |  | 10 |  |
| Total |  | $ | 3,140 |  |  | $ | 2,568 |  |

[0000858877-23-000005:notes:66]
[same as prior period, unchanged from 0000858877-22-000025:notes:62]

[0000858877-23-000005:notes:67]
|  |  | January 28,2023 |  | July 30,2022 |
| Gross property and equipment: |  |  |  |  |
| Land, buildings, and building and leasehold improvements |  | $ | 4,263 |  |  | $ | 4,219 |  |
| Computer equipment and related software |  | 749 |  |  | 779 |  |
| Production, engineering, and other equipment |  | 4,591 |  |  | 4,647 |  |
| Operating lease assets |  | 149 |  |  | 185 |  |
| Furniture, fixtures and other |  | 340 |  |  | 335 |  |
| Total gross property and equipment |  | 10,092 |  |  | 10,165 |  |
| Less: accumulated depreciation and amortization |  | (8,128) |  |  | (8,168) |  |
| Total |  | $ | 1,964 |  |  | $ | 1,997 |  |

[0000858877-23-000005:notes:68]
[same as prior period, unchanged from 0000858877-22-000025:notes:64]

[0000858877-23-000005:notes:69]
|  |  | January 28,2023 |  | July 30,2022 |
| Product |  | $ | 14,517 |  |  | $ | 14,090 |  |
| Service |  | 17,255 |  |  | 17,449 |  |
| Total |  | $ | 31,772 |  |  | $ | 31,539 |  |
| Short-term RPO |  | $ | 16,865 |  |  | $ | 16,936 |  |
| Long-term RPO |  | 14,907 |  |  | 14,603 |  |
| Total |  | $ | 31,772 |  |  | $ | 31,539 |  |
| Amount to be recognized as revenue over the next 12 months |  | 53 | % |  | 54 | % |
| Deferred revenue |  | $ | 23,927 |  |  | $ | 23,264 |  |
| Unbilled contract revenue |  | 7,845 |  |  | 8,275 |  |
| Total |  | $ | 31,772 |  |  | $ | 31,539 |  |

[0000858877-23-000005:notes:70]
[same as prior period, unchanged from 0000858877-22-000025:notes:66]

[0000858877-23-000005:notes:71]
[same as prior period, unchanged from 0000858877-22-000025:notes:67]

[0000858877-23-000005:notes:72]
|  |  | January 28,2023 |  | July 30,2022 |
| Product |  | $ | 10,679 |  |  | $ | 10,427 |  |
| Service |  | 13,248 |  |  | 12,837 |  |
| Total |  | $ | 23,927 |  |  | $ | 23,264 |  |
| Reported as: |  |  |  |  |
| Current |  | $ | 13,109 |  |  | $ | 12,784 |  |
| Noncurrent |  | 10,818 |  |  | 10,480 |  |
| Total |  | $ | 23,927 |  |  | $ | 23,264 |  |

[0000858877-23-000005:notes:73]
[same as prior period, unchanged from 0000858877-22-000025:notes:69]

[0000858877-23-000005:notes:74]
[same as prior period, unchanged from 0000858877-22-000025:notes:70]

[0000858877-23-000005:notes:75]
|  |  | January 28,2023 |  | July 30,2022 |
| Current |  | $ | 1,364 |  |  | $ | 727 |  |
| Noncurrent |  | 4,092 |  |  | 5,456 |  |
| Total |  | $ | 5,456 |  |  | $ | 6,183 |  |


## us-gaap:LesseeOperatingLeasesTextBlock

[0000858877-23-000005:notes:76]
Leases 
(a)Lessee Arrangements

[0000858877-23-000005:notes:77]
The following table presents our operating lease balances (in millions):

[0000858877-23-000005:notes:78]
|  | Balance Sheet Line Item |  | January 28, 2023 |  | July 30, 2022 |
| Operating lease right-of-use assets | Other assets |  | $ | 978 |  |  | $ | 1,003 |  |
| Operating lease liabilities | Other current liabilities |  | $ | 337 |  |  | $ | 322 |  |
| Operating lease liabilities | Other long-term liabilities |  | 691 |  |  | 724 |  |
| Total operating lease liabilities |  |  | $ | 1,028 |  |  | $ | 1,046 |  |

[0000858877-23-000005:notes:79]
The components of our lease expenses were as follows (in millions):

[0000858877-23-000005:notes:80]
|  | Three Months Ended |  | Six Months Ended |
|  | January 28, 2023 |  | January 29, 2022 |  | January 28, 2023 |  | January 29, 2022 |
| Operating lease expense | $ | 98 |  |  | $ | 98 |  |  | $ | 194 |  |  | $ | 193 |  |
| Short-term lease expense | 17 |  |  | 15 |  |  | 34 |  |  | 32 |  |
| Variable lease expense | 63 |  |  | 41 |  |  | 121 |  |  | 90 |  |
| Total lease expense | $ | 178 |  |  | $ | 154 |  |  | $ | 349 |  |  | $ | 315 |  |

[0000858877-23-000005:notes:81]
Supplemental information related to our operating leases is as follows (in millions):

[0000858877-23-000005:notes:82]
|  | Six Months Ended |
|  | January 28, 2023 |  | January 29, 2022 |
| Cash paid for amounts included in the measurement of lease liabilities — operating cash flows | $ | 192 |  |  | $ | 202 |  |
| Right-of-use assets obtained in exchange for operating leases liabilities | $ | 149 |  |  | $ | 178 |  |

[0000858877-23-000005:notes:83]
The weighted-average lease term was 4.6 years and 4.7 years as of January 28, 2023 and July 30, 2022, respectively. The weighted-average discount rate was 2.7% and 2.2% as of January 28, 2023 and July 30, 2022, respectively.

[0000858877-23-000005:notes:84]
The maturities of our operating leases (undiscounted) as of January 28, 2023 are as follows (in millions):

[0000858877-23-000005:notes:85]
| Fiscal Year | Amount |
| 2023 (remaining six months) | $ | 185 |  |
| 2024 | 297 |  |
| 2025 | 215 |  |
| 2026 | 133 |  |
| 2027 | 76 |  |
| Thereafter | 212 |  |
| Total lease payments | 1,118 |  |
| Less interest | (90) |  |
| Total | $ | 1,028 |  |

[0000858877-23-000005:notes:86]
(b)Lessor Arrangements

[0000858877-23-000005:notes:87]
Our leases primarily represent sales-type leases with terms of four years on average. We provide leasing of our equipment and complementary third-party products primarily through our channel partners and distributors, for which the income arising from these leases is recognized through interest income. Interest income was $12 million and $24 million for the second quarter and first six months of fiscal 2023, respectively, and $14 million and $29 million for the corresponding periods of fiscal 2022, respectively, and was included in interest income in the Consolidated Statement of Operations. The net investment of our lease receivables is measured at the commencement date as the gross lease receivable, residual value less unearned income and allowance for credit loss. For additional information, see Note 9.

[0000858877-23-000005:notes:88]
Future minimum lease payments on our lease receivables as of January 28, 2023 are summarized as follows (in millions):

[0000858877-23-000005:notes:89]
| Fiscal Year | Amount |
| 2023 (remaining six months) | $ | 348 |  |
| 2024 | 365 |  |
| 2025 | 192 |  |
| 2026 | 114 |  |
| 2027 | 51 |  |
| Thereafter | 16 |  |
| Total | 1,086 |  |
| Less: Present value of lease payments | 1,021 |  |
| Unearned income | $ | 65 |  |

[0000858877-23-000005:notes:90]
Actual cash collections may differ from the contractual maturities due to early customer buyouts, refinancings, or defaults.

[0000858877-23-000005:notes:91]
We provide financing of certain equipment through operating leases, and the amounts are included in property and equipment in the Consolidated Balance Sheets. Amounts relating to equipment on operating lease assets held by us and the associated accumulated depreciation are summarized as follows (in millions):

[0000858877-23-000005:notes:92]
|  | January 28, 2023 |  | July 30, 2022 |
| Operating lease assets | $ | 149 |  |  | $ | 185 |  |
| Accumulated depreciation | (90) |  |  | (111) |  |
| Operating lease assets, net | $ | 59 |  |  | $ | 74 |  |

[0000858877-23-000005:notes:93]
Our operating lease income was $18 million and $39 million for the second quarter and first six months of fiscal 2023, respectively, and $29 million and $61 million for the corresponding periods of fiscal 2022, respectively, and was included in product revenue in the Consolidated Statement of Operations.

[0000858877-23-000005:notes:94]
Minimum future rentals on noncancelable operating leases as of January 28, 2023 are summarized as follows (in millions):

[0000858877-23-000005:notes:95]
| Fiscal Year | Amount |
| 2023 (remaining six months) | $ | 15 |  |
| 2024 | 18 |  |
| 2025 | 6 |  |
| Total | $ | 39 |  |


## us-gaap:FinancingReceivablesTextBlock

[0000858877-23-000005:notes:96]
[same as prior period, unchanged from 0000858877-22-000025:notes:92]

[0000858877-23-000005:notes:97]
[same as prior period, unchanged from 0000858877-22-000025:notes:93]

[0000858877-23-000005:notes:98]
[same as prior period, unchanged from 0000858877-22-000025:notes:94]

[0000858877-23-000005:notes:99]
| January 28, 2023 | Loan Receivables |  | Lease Receivables |  | Total |
| Gross | $ | 6,136 |  |  | $ | 1,086 |  |  | $ | 7,222 |  |
| Residual value | — |  |  | 67 |  |  | 67 |  |
| Unearned income | — |  |  | (65) |  |  | (65) |  |
| Allowance for credit loss | (94) |  |  | (19) |  |  | (113) |  |
| Total, net | $ | 6,042 |  |  | $ | 1,069 |  |  | $ | 7,111 |  |
| Reported as: |  |  |  |  |  |
| Current | $ | 3,057 |  |  | $ | 500 |  |  | $ | 3,557 |  |
| Noncurrent | 2,985 |  |  | 569 |  |  | 3,554 |  |
| Total, net | $ | 6,042 |  |  | $ | 1,069 |  |  | $ | 7,111 |  |

[0000858877-23-000005:notes:100]
[same as prior period, unchanged from 0000858877-22-000025:notes:96]

[0000858877-23-000005:notes:101]
[same as prior period, unchanged from 0000858877-22-000025:notes:97]

[0000858877-23-000005:notes:102]
[same as prior period, unchanged from 0000858877-22-000025:notes:98]

[0000858877-23-000005:notes:103]
| January 28, 2023 |  |  | Fiscal Year |  | Six Months Ended |  |  |
| Internal Credit Risk Rating | Prior |  | July 27, 2019 |  | July 25, 2020 |  | July 31, 2021 |  | July 30, 2022 |  | January 28, 2023 |  | Total |
| Loan Receivables: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | 18 |  |  | $ | 108 |  |  | $ | 371 |  |  | $ | 1,086 |  |  | $ | 1,347 |  |  | $ | 978 |  |  | $ | 3,908 |  |
| 5 to 6 | 5 |  |  | 73 |  |  | 199 |  |  | 488 |  |  | 671 |  |  | 651 |  |  | 2,087 |  |
| 7 and Higher | 2 |  |  | 15 |  |  | 36 |  |  | 33 |  |  | 54 |  |  | 1 |  |  | 141 |  |
| Total Loan Receivables | $ | 25 |  |  | $ | 196 |  |  | $ | 606 |  |  | $ | 1,607 |  |  | $ | 2,072 |  |  | $ | 1,630 |  |  | $ | 6,136 |  |
| Lease Receivables: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | 10 |  |  | $ | 49 |  |  | $ | 101 |  |  | $ | 165 |  |  | $ | 105 |  |  | $ | 108 |  |  | $ | 538 |  |
| 5 to 6 | 4 |  |  | 25 |  |  | 74 |  |  | 92 |  |  | 115 |  |  | 149 |  |  | 459 |  |
| 7 and Higher | 1 |  |  | 2 |  |  | 9 |  |  | 2 |  |  | 3 |  |  | 7 |  |  | 24 |  |
| Total Lease Receivables | $ | 15 |  |  | $ | 76 |  |  | $ | 184 |  |  | $ | 259 |  |  | $ | 223 |  |  | $ | 264 |  |  | $ | 1,021 |  |
| Total | $ | 40 |  |  | $ | 272 |  |  | $ | 790 |  |  | $ | 1,866 |  |  | $ | 2,295 |  |  | $ | 1,894 |  |  | $ | 7,157 |  |

[0000858877-23-000005:notes:104]
[same as prior period, unchanged from 0000858877-22-000025:notes:100]

[0000858877-23-000005:notes:105]
The following tables present the aging analysis of gross receivables as of January 28, 2023 and July 30, 2022 (in millions):

[0000858877-23-000005:notes:106]
|  | DAYS PAST DUE (INCLUDES BILLED AND UNBILLED) |  |  |  |  |  |  |  |  |  |  |
| January 28, 2023 | 31-60 |  | 61-90 |  | 91+ |  | TotalPast Due |  | Current |  | Total |  | 120+ Still Accruing |  | NonaccrualFinancingReceivables |  | ImpairedFinancingReceivables |
| Loan receivables | $ | 100 |  |  | $ | 23 |  |  | $ | 46 |  |  | $ | 169 |  |  | $ | 5,967 |  |  | $ | 6,136 |  |  | $ | 14 |  |  | $ | 60 |  |  | $ | 60 |  |
| Lease receivables | 42 |  |  | 36 |  |  | 22 |  |  | 100 |  |  | 921 |  |  | 1,021 |  |  | 8 |  |  | 9 |  |  | 9 |  |
| Total | $ | 142 |  |  | $ | 59 |  |  | $ | 68 |  |  | $ | 269 |  |  | $ | 6,888 |  |  | $ | 7,157 |  |  | $ | 22 |  |  | $ | 69 |  |  | $ | 69 |  |

[0000858877-23-000005:notes:107]
[same as prior period, unchanged from 0000858877-22-000025:notes:103]

[0000858877-23-000005:notes:108]
[same as prior period, unchanged from 0000858877-22-000025:notes:104]

[0000858877-23-000005:notes:109]
[same as prior period, unchanged from 0000858877-22-000025:notes:105]

[0000858877-23-000005:notes:110]
[same as prior period, unchanged from 0000858877-22-000025:notes:106]

[0000858877-23-000005:notes:111]
| Three Months Ended January 28, 2023 | CREDIT LOSS ALLOWANCES |
|  | Loan Receivables |  | Lease Receivables |  | Total |
| Allowance for credit loss as of October 29, 2022 | $ | 101 |  |  | $ | 19 |  |  | $ | 120 |  |
| Provisions (benefits) | (3) |  |  | (1) |  |  | (4) |  |
| Other | (4) |  |  | 1 |  |  | (3) |  |
| Allowance for credit loss as of January 28, 2023 | $ | 94 |  |  | $ | 19 |  |  | $ | 113 |  |

[0000858877-23-000005:notes:112]
| Three Months Ended January 29, 2022 | CREDIT LOSS ALLOWANCES |
|  | Loan Receivables |  | Lease Receivables |  | Total |
| Allowance for credit loss as of October 30, 2021 | $ | 76 |  |  | $ | 33 |  |  | $ | 109 |  |
| Provisions (benefits) | (6) |  |  | (4) |  |  | (10) |  |
| Recoveries (write-offs), net | — |  |  | (2) |  |  | (2) |  |
| Allowance for credit loss as of January 29, 2022 | $ | 70 |  |  | $ | 27 |  |  | $ | 97 |  |

[0000858877-23-000005:notes:113]
| Six Months Ended January 28, 2023 | CREDIT LOSS ALLOWANCES |
|  | Loan Receivables |  | Lease Receivables |  | Total |
| Allowance for credit loss as of July 30, 2022 | $ | 103 |  |  | $ | 23 |  |  | $ | 126 |  |
| Provisions (benefits) | (4) |  |  | (4) |  |  | (8) |  |
| Other | (5) |  |  | — |  |  | (5) |  |
| Allowance for credit loss as of January 28, 2023 | $ | 94 |  |  | $ | 19 |  |  | $ | 113 |  |

[0000858877-23-000005:notes:114]
| Six Months Ended January 29, 2022 | CREDIT LOSS ALLOWANCES |
|  | Loan Receivables |  | Lease Receivables |  | Total |
| Allowance for credit loss as of July 31, 2021 | $ | 89 |  |  | $ | 38 |  |  | $ | 127 |  |
| Provisions (benefits) | (19) |  |  | (9) |  |  | (28) |  |
| Recoveries (write-offs), net | — |  |  | (2) |  |  | (2) |  |
| Allowance for credit loss as of January 29, 2022 | $ | 70 |  |  | $ | 27 |  |  | $ | 97 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000858877-23-000005:notes:115]
Available-for-Sale Debt and Equity Investments
(a)Summary of Available-for-Sale Debt Investments

[0000858877-23-000005:notes:116]
The following tables summarize our available-for-sale debt investments (in millions):

[0000858877-23-000005:notes:117]
| January 28, 2023 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 2,050 |  |  | $ | 2 |  |  | $ | (54) |  |  | $ | 1,998 |  |
| U.S. government agency securities | 169 |  |  | — |  |  | (5) |  |  | 164 |  |
| Non-U.S. government and agency securities | 354 |  |  | — |  |  | (1) |  |  | 353 |  |
| Corporate debt securities | 7,480 |  |  | 5 |  |  | (345) |  |  | 7,140 |  |
| U.S. agency mortgage-backed securities | 2,013 |  |  | 2 |  |  | (188) |  |  | 1,827 |  |
| Commercial paper | 1,029 |  |  | — |  |  | — |  |  | 1,029 |  |
| Certificates of deposit | 261 |  |  | — |  |  | — |  |  | 261 |  |
| Total | $ | 13,356 |  |  | $ | 9 |  |  | $ | (593) |  |  | $ | 12,772 |  |

[0000858877-23-000005:notes:118]
| July 30, 2022 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 1,287 |  |  | $ | — |  |  | $ | (49) |  |  | $ | 1,238 |  |
| U.S. government agency securities | 142 |  |  | — |  |  | (4) |  |  | 138 |  |
| Non-U.S. government and agency securities | 272 |  |  | — |  |  | — |  |  | 272 |  |
| Corporate debt securities | 8,127 |  |  | 2 |  |  | (311) |  |  | 7,818 |  |
| U.S. agency mortgage-backed securities | 2,134 |  |  | — |  |  | (158) |  |  | 1,976 |  |
| Commercial paper | 255 |  |  | — |  |  | — |  |  | 255 |  |
| Certificates of deposit | 250 |  |  | — |  |  | — |  |  | 250 |  |
| Total | $ | 12,467 |  |  | $ | 2 |  |  | $ | (522) |  |  | $ | 11,947 |  |

[0000858877-23-000005:notes:119]
Net unsettled investment purchases were $15 million and net unsettled investment sales were $70 million as of January 28, 2023 and July 30, 2022, respectively, and were included in other current assets and other current liabilities.

[0000858877-23-000005:notes:120]
The following table presents the gross realized gains and gross realized losses related to available-for-sale debt investments (in millions):

[0000858877-23-000005:notes:121]
|  | Three Months Ended |  | Six Months Ended |
|  | January 28, 2023 |  | January 29, 2022 |  | January 28, 2023 |  | January 29, 2022 |
| Gross realized gains | $ | 3 |  |  | $ | 13 |  |  | $ | 3 |  |  | $ | 19 |  |
| Gross realized losses | (6) |  |  | (3) |  |  | (12) |  |  | (3) |  |
| Total | $ | (3) |  |  | $ | 10 |  |  | $ | (9) |  |  | $ | 16 |  |

[0000858877-23-000005:notes:122]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at January 28, 2023 and July 30, 2022 (in millions):

[0000858877-23-000005:notes:123]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| January 28, 2023 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 470 |  |  | $ | (6) |  |  | $ | 1,086 |  |  | $ | (48) |  |  | $ | 1,556 |  |  | $ | (54) |  |
| U.S. government agency securities | 33 |  |  | — |  |  | 121 |  |  | (5) |  |  | 154 |  |  | (5) |  |
| Non-U.S. government and agency securities | 339 |  |  | (1) |  |  | — |  |  | — |  |  | 339 |  |  | (1) |  |
| Corporate debt securities | 2,770 |  |  | (94) |  |  | 3,333 |  |  | (219) |  |  | 6,103 |  |  | (313) |  |
| U.S. agency mortgage-backed securities | 305 |  |  | (12) |  |  | 1,440 |  |  | (176) |  |  | 1,745 |  |  | (188) |  |
| Commercial paper | 40 |  |  | — |  |  | — |  |  | — |  |  | 40 |  |  | — |  |
| Total | $ | 3,957 |  |  | $ | (113) |  |  | $ | 5,980 |  |  | $ | (448) |  |  | $ | 9,937 |  |  | $ | (561) |  |

[0000858877-23-000005:notes:124]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 30, 2022 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 1,110 |  |  | $ | (44) |  |  | $ | 120 |  |  | $ | (5) |  |  | $ | 1,230 |  |  | $ | (49) |  |
| U.S. government agency securities | 114 |  |  | (2) |  |  | 24 |  |  | (2) |  |  | 138 |  |  | (4) |  |
| Non-U.S. government and agency securities | 264 |  |  | — |  |  | — |  |  | — |  |  | 264 |  |  | — |  |
| Corporate debt securities | 6,920 |  |  | (240) |  |  | 422 |  |  | (37) |  |  | 7,342 |  |  | (277) |  |
| U.S. agency mortgage-backed securities | 1,305 |  |  | (96) |  |  | 615 |  |  | (62) |  |  | 1,920 |  |  | (158) |  |
| Total | $ | 9,713 |  |  | $ | (382) |  |  | $ | 1,181 |  |  | $ | (106) |  |  | $ | 10,894 |  |  | $ | (488) |  |

[0000858877-23-000005:notes:125]
The following table summarizes the maturities of our available-for-sale debt investments as of January 28, 2023 (in millions):

[0000858877-23-000005:notes:126]
|  | Amortized Cost |  | Fair Value |
| Within 1 year | $ | 4,806 |  |  | $ | 4,734 |  |
| After 1 year through 5 years | 6,491 |  |  | 6,170 |  |
| After 5 years through 10 years | 46 |  |  | 41 |  |
| Mortgage-backed securities with no single maturity | 2,013 |  |  | 1,827 |  |
| Total | $ | 13,356 |  |  | $ | 12,772 |  |

[0000858877-23-000005:notes:127]
Actual maturities may differ from the contractual maturities because borrowers may have the right to call or prepay certain obligations.

[0000858877-23-000005:notes:128]
(b)Summary of Equity Investments

[0000858877-23-000005:notes:129]
We held marketable equity securities of $280 million and $241 million as of January 28, 2023 and July 30, 2022, respectively. We recognized a net unrealized gain of $11 million and a net unrealized loss of $9 million during the second quarter and first six months of fiscal 2023, respectively, and a net unrealized loss of $18 million and $13 million during the corresponding periods of fiscal 2022, respectively, on our marketable securities still held as of the reporting date. Our net adjustments to non-marketable equity securities measured using the measurement alternative still held was a net gain of $3 million and a net loss of $8 million for the second quarter and first six months of fiscal 2023, respectively, and a net gain of $14 million and $16 million for the corresponding periods of fiscal 2022, respectively. We held equity interests in certain private equity funds of $1.0 billion and $1.1 billion as of January 28, 2023 and July 30, 2022, respectively, which are accounted for under the NAV practical expedient.

[0000858877-23-000005:notes:130]
In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers are evaluated for consolidation under the variable interest or voting interest entity models. We evaluate on an ongoing basis our investments in these privately held companies and our customer financings, and have determined that as of January 28, 2023, there were no significant variable interest or voting interest entities required to be consolidated in our Consolidated Financial Statements.

[0000858877-23-000005:notes:131]
The carrying value of our investments in privately held companies was $1.8 billion and $1.9 billion as of January 28, 2023 and July 30, 2022, respectively. Of the total carrying value of our investments in privately held companies as of January 28, 2023, $1.1 billion of such investments are considered to be in variable interest entities which are unconsolidated. As of January 28, 2023, we have total funding commitments of $0.3 billion related to privately held investments, some of which may be based on the achievement of certain agreed-upon milestones or are required to be funded on demand. The carrying value of these investments and the additional funding commitments, collectively, represent our maximum exposure related to privately held investments.


## us-gaap:FairValueDisclosuresTextBlock

[0000858877-23-000005:notes:132]
[same as prior period, unchanged from 0000858877-22-000025:notes:126]

[0000858877-23-000005:notes:133]
[same as prior period, unchanged from 0000858877-22-000025:notes:127]

[0000858877-23-000005:notes:134]
|  | JANUARY 28, 2023 |  | JULY 30, 2022 |
|  | FAIR VALUE MEASUREMENTS |  | FAIR VALUE MEASUREMENTS |
|  | Level 1 |  | Level 2 |  | TotalBalance |  | Level 1 |  | Level 2 |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 5,038 |  |  | $ | — |  |  | $ | 5,038 |  |  | $ | 3,930 |  |  | $ | — |  |  | $ | 3,930 |  |
| Commercial paper | — |  |  | 1,037 |  |  | 1,037 |  |  | — |  |  | 72 |  |  | 72 |  |
| Corporate debt securities | — |  |  | 41 |  |  | 41 |  |  | — |  |  | 1 |  |  | 1 |  |
| U.S. government securities | — |  |  | 40 |  |  | 40 |  |  | — |  |  | 12 |  |  | 12 |  |
| Certificates of deposit | — |  |  | 31 |  |  | 31 |  |  | — |  |  | 32 |  |  | 32 |  |
| Available-for-sale debt investments: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | — |  |  | 1,998 |  |  | 1,998 |  |  | — |  |  | 1,238 |  |  | 1,238 |  |
| U.S. government agency securities | — |  |  | 164 |  |  | 164 |  |  | — |  |  | 138 |  |  | 138 |  |
| Non-U.S. government and agency securities | — |  |  | 353 |  |  | 353 |  |  | — |  |  | 272 |  |  | 272 |  |
| Corporate debt securities | — |  |  | 7,140 |  |  | 7,140 |  |  | — |  |  | 7,818 |  |  | 7,818 |  |
| U.S. agency mortgage-backed securities | — |  |  | 1,827 |  |  | 1,827 |  |  | — |  |  | 1,976 |  |  | 1,976 |  |
| Commercial paper | — |  |  | 1,029 |  |  | 1,029 |  |  | — |  |  | 255 |  |  | 255 |  |
| Certificates of deposit | — |  |  | 261 |  |  | 261 |  |  | — |  |  | 250 |  |  | 250 |  |
| Equity investments: |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities | 280 |  |  | — |  |  | 280 |  |  | 241 |  |  | — |  |  | 241 |  |
| Other assets: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | 1,500 |  |  | — |  |  | 1,500 |  |  | 1,500 |  |  | — |  |  | 1,500 |  |
| Derivative assets | — |  |  | 36 |  |  | 36 |  |  | — |  |  | 78 |  |  | 78 |  |
| Total | $ | 6,818 |  |  | $ | 13,957 |  |  | $ | 20,775 |  |  | $ | 5,671 |  |  | $ | 12,142 |  |  | $ | 17,813 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities | $ | — |  |  | $ | 73 |  |  | $ | 73 |  |  | $ | — |  |  | $ | 89 |  |  | $ | 89 |  |
| Total | $ | — |  |  | $ | 73 |  |  | $ | 73 |  |  | $ | — |  |  | $ | 89 |  |  | $ | 89 |  |

[0000858877-23-000005:notes:135]
[same as prior period, unchanged from 0000858877-22-000025:notes:129]

[0000858877-23-000005:notes:136]
[same as prior period, unchanged from 0000858877-22-000025:notes:130]

[0000858877-23-000005:notes:137]
[same as prior period, unchanged from 0000858877-22-000025:notes:131]

[0000858877-23-000005:notes:138]
[same as prior period, unchanged from 0000858877-22-000025:notes:132]

[0000858877-23-000005:notes:139]
The fair value of our short-term loan receivables approximates their carrying value due to their short duration. The aggregate carrying value of our long-term loan receivables as of January 28, 2023 and July 30, 2022 was $3.0 billion and $3.4 billion, respectively. The estimated fair value of our long-term loan receivables approximates their carrying value. We use unobservable inputs in determining discounted cash flows to estimate the fair value of our long-term loan receivables, and therefore they are categorized as Level 3.
As of January 28, 2023, the estimated fair value of our short-term debt approximates its carrying value due to the short maturities. As of January 28, 2023, the fair value of our senior notes was $9.4 billion with a carrying amount of $8.9 billion. This compares to a fair value of $9.7 billion and a carrying amount of $8.9 billion as of July 30, 2022. The fair value of the senior notes was determined based on observable market prices in a less active market and was categorized as Level 2 in the fair value hierarchy.


## us-gaap:DebtDisclosureTextBlock

[0000858877-23-000005:notes:140]
Borrowings 
(a)Short-Term Debt

[0000858877-23-000005:notes:141]
The following table summarizes our short-term debt (in millions, except percentages):

[0000858877-23-000005:notes:142]
|  | January 28, 2023 |  | July 30, 2022 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 1,250 |  |  | 2.44 | % |  | $ | 499 |  |  | 2.68 | % |
| Commercial paper | — |  |  | — |  |  | 600 |  |  | 2.05 | % |
| Total | $ | 1,250 |  |  |  |  | $ | 1,099 |  |  |  |

[0000858877-23-000005:notes:143]
We have a short-term debt financing program of up to $10.0 billion through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes.

[0000858877-23-000005:notes:144]
The effective rates for the short- and long-term debt include the interest on the notes, the accretion of the discount, the issuance costs, and, if applicable, adjustments related to hedging.

[0000858877-23-000005:notes:145]
(b)Long-Term Debt

[0000858877-23-000005:notes:146]
The following table summarizes our long-term debt (in millions, except percentages):

[0000858877-23-000005:notes:147]
|  |  |  | January 28, 2023 |  | July 30, 2022 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 2.60% | February 28, 2023 |  | $ | 500 |  |  | 2.68% |  | $ | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 5.28% |  | 1,000 |  |  | 2.69% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 5.65% |  | 500 |  |  | 3.20% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 9,000 |  |  |  |  | 9,000 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (71) |  |  |  |  | (75) |  |  |  |
| Hedge accounting fair value adjustments |  |  | (42) |  |  |  |  | (10) |  |  |  |
| Total |  |  | $ | 8,887 |  |  |  |  | $ | 8,915 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 1,250 |  |  |  |  | $ | 499 |  |  |  |
| Long-term debt |  |  | 7,637 |  |  |  |  | 8,416 |  |  |  |
| Total |  |  | $ | 8,887 |  |  |  |  | $ | 8,915 |  |  |  |

[0000858877-23-000005:notes:148]
We have entered into interest rate swaps in prior periods with an aggregate notional amount of $1.5 billion designated as fair value hedges of certain of our fixed-rate senior notes. These swaps convert the fixed interest rates of the fixed-rate notes to floating interest rates based on the London InterBank Offered Rate (LIBOR). The gains and losses related to changes in the fair value of the interest rate swaps substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates. For additional information, see Note 13.

[0000858877-23-000005:notes:149]
Interest is payable semiannually on each class of the senior fixed-rate notes. Each of the senior fixed-rate notes is redeemable by us at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to our short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of January 28, 2023, we were in compliance with all debt covenants.

[0000858877-23-000005:notes:150]
As of January 28, 2023, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

[0000858877-23-000005:notes:151]
| Fiscal Year | Amount |
| 2023 (remaining six months) | $ | 500 |  |
| 2024 | 1,750 |  |
| 2025 | 500 |  |
| 2026 | 750 |  |
| 2027 | 1,500 |  |
| Thereafter | 4,000 |  |
| Total | $ | 9,000 |  |

[0000858877-23-000005:notes:152]
(c)Credit Facility

[0000858877-23-000005:notes:153]
On May 13, 2021, we entered into a 5-year credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 13, 2026. As of January 28, 2023, we were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under the credit agreement.
Any advances under the 5-year credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (a) with respect to loans in U.S. dollars, (i) LIBOR or (ii) the Base Rate (to be defined as the highest of (x) the Bank of America prime rate, (y) the Federal Funds rate plus 0.50% and (z) a daily rate equal to one-month LIBOR plus 1.0%), (b) with respect to loans in Euros, EURIBOR, (c) with respect to loans in Yen, TIBOR and (d) with respect to loans in Pounds Sterling, SONIA plus a credit spread adjustment, plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the interest rate be less than 0.0%. We will pay a quarterly commitment fee during the term of the 5-year credit agreement which may vary depending on our senior debt credit ratings. In addition, the 5-year credit agreement incorporates certain sustainability-linked metrics. Specifically, our applicable interest rate and commitment fee are subject to upward or downward adjustments if we achieve, or fail to achieve, certain specified targets based on two key performance indicator metrics: (i) social impact and (ii) foam reduction. We may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and, at our option, extend the maturity of the facility for an additional year up to two times. The credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio as defined in the agreement.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000858877-23-000005:notes:154]
[same as prior period, unchanged from 0000858877-22-000025:notes:150]

[0000858877-23-000005:notes:155]
[same as prior period, unchanged from 0000858877-22-000025:notes:151]

[0000858877-23-000005:notes:156]
[same as prior period, unchanged from 0000858877-22-000025:notes:152]

[0000858877-23-000005:notes:157]
|  | DERIVATIVE ASSETS |  | DERIVATIVE LIABILITIES |
|  | Balance Sheet Line Item |  | January 28,2023 |  | July 30,2022 |  | Balance Sheet Line Item |  | January 28,2023 |  | July 30,2022 |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | $ | 21 |  |  | $ | 55 |  |  | Other current liabilities |  | $ | 1 |  |  | $ | — |  |
| Foreign currency derivatives | Other assets |  | 1 |  |  | 9 |  |  | Other long-term liabilities |  | 4 |  |  | — |  |
| Interest rate derivatives | Other assets |  | — |  |  | — |  |  | Other long-term liabilities |  | 42 |  |  | 10 |  |
| Total |  |  | 22 |  |  | 64 |  |  |  |  | 47 |  |  | 10 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | 10 |  |  | 14 |  |  | Other current liabilities |  | 26 |  |  | 69 |  |
| Foreign currency derivatives | Other assets |  | 4 |  |  | — |  |  | Other long-term liabilities |  | — |  |  | 9 |  |
| Equity derivatives | Other current assets |  | — |  |  | — |  |  | Other current liabilities |  | — |  |  | 1 |  |
| Total |  |  | 14 |  |  | 14 |  |  |  |  | 26 |  |  | 79 |  |
| Total |  |  | $ | 36 |  |  | $ | 78 |  |  |  |  | $ | 73 |  |  | $ | 89 |  |

[0000858877-23-000005:notes:158]
[same as prior period, unchanged from 0000858877-22-000025:notes:154]

[0000858877-23-000005:notes:159]
|  |  | CARRYING AMOUNT OF THE HEDGED ASSETS/(LIABILITIES) |  | CUMULATIVE AMOUNT OF FAIR VALUE HEDGING ADJUSTMENT INCLUDED IN THE CARRYING AMOUNT OF THE HEDGED ASSETS/LIABILITIES |
| Balance Sheet Line Item of Hedged Item |  | January 28,2023 |  | July 30,2022 |  | January 28,2023 |  | July 30,2022 |
| Long-term debt |  | $ | (1,456) |  |  | $ | (1,487) |  |  | $ | 42 |  |  | $ | 10 |  |

[0000858877-23-000005:notes:160]
[same as prior period, unchanged from 0000858877-22-000025:notes:156]

[0000858877-23-000005:notes:161]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 28, 2023 |  | January 29, 2022 |  | January 28, 2023 |  | January 29, 2022 |
| Interest rate derivatives: |  |  |  |  |  |  |  |  |
| Hedged items |  | $ | (7) |  |  | $ | 32 |  |  | $ | 32 |  |  | $ | 58 |  |
| Derivatives designated as hedging instruments |  | 7 |  |  | (32) |  |  | (32) |  |  | (59) |  |
| Total |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | (1) |  |

[0000858877-23-000005:notes:162]
[same as prior period, unchanged from 0000858877-22-000025:notes:158]

[0000858877-23-000005:notes:163]
|  |  |  |  | GAINS (LOSSES) FOR THE THREE MONTHS ENDED |  | GAINS (LOSSES) FOR THE SIX MONTHS ENDED |
| Derivatives Not Designated as Hedging Instruments |  | Line Item in Statements of Operations |  | January 28,2023 |  | January 29,2022 |  | January 28, 2023 |  | January 29,2022 |
| Foreign currency derivatives |  | Other income (loss), net |  | $ | 140 |  |  | $ | (36) |  |  | $ | 68 |  |  | $ | (56) |  |
| Total return swaps—deferred compensation |  | Operating expenses and other |  | 44 |  |  | (41) |  |  | 19 |  |  | (20) |  |
| Equity derivatives |  | Other income (loss), net |  | 5 |  |  | (3) |  |  | 4 |  |  | 1 |  |
| Total |  |  |  | $ | 189 |  |  | $ | (80) |  |  | $ | 91 |  |  | $ | (75) |  |

[0000858877-23-000005:notes:164]
[same as prior period, unchanged from 0000858877-22-000025:notes:160]

[0000858877-23-000005:notes:165]
|  | January 28,2023 |  | July 30,2022 |
| Foreign currency derivatives | $ | 4,555 |  |  | $ | 4,521 |  |
| Interest rate derivatives | 1,500 |  |  | 1,500 |  |
| Total return swaps—deferred compensation | 720 |  |  | 651 |  |
| Total | $ | 6,775 |  |  | $ | 6,672 |  |

[0000858877-23-000005:notes:166]
[same as prior period, unchanged from 0000858877-22-000025:notes:162]

[0000858877-23-000005:notes:167]
[same as prior period, unchanged from 0000858877-22-000025:notes:163]

[0000858877-23-000005:notes:168]
To further limit credit risk, we also enter into collateral security arrangements related to certain derivative instruments whereby cash is posted as collateral between the counterparties based on the fair market value of the derivative instrument. Under these collateral security arrangements, the net cash collateral provided for was $42 million and $14 million as of January 28, 2023 and July 30, 2022, respectively.

[0000858877-23-000005:notes:169]
[same as prior period, unchanged from 0000858877-22-000025:notes:165]

[0000858877-23-000005:notes:170]
[same as prior period, unchanged from 0000858877-22-000025:notes:166]

[0000858877-23-000005:notes:171]
[same as prior period, unchanged from 0000858877-22-000025:notes:167]

[0000858877-23-000005:notes:172]
[same as prior period, unchanged from 0000858877-22-000025:notes:168]

[0000858877-23-000005:notes:173]
[same as prior period, unchanged from 0000858877-22-000025:notes:169]

[0000858877-23-000005:notes:174]
[same as prior period, unchanged from 0000858877-22-000025:notes:170]

[0000858877-23-000005:notes:175]
[same as prior period, unchanged from 0000858877-22-000025:notes:171]

[0000858877-23-000005:notes:176]
[same as prior period, unchanged from 0000858877-22-000025:notes:172]

[0000858877-23-000005:notes:177]
[same as prior period, unchanged from 0000858877-22-000025:notes:173]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000858877-23-000005:notes:178]
Commitments and Contingencies 
(a)Purchase Commitments with Contract Manufacturers and Suppliers

[0000858877-23-000005:notes:179]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these inventory purchase commitments with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.

[0000858877-23-000005:notes:180]
The following table summarizes our inventory purchase commitments with contract manufacturers and suppliers by period (in millions):

[0000858877-23-000005:notes:181]
|  | January 28,2023 |  | July 30,2022 |
| Less than 1 year | $ | 8,651 |  |  | $ | 9,954 |  |
| 1 to 3 years | 1,693 |  |  | 2,240 |  |
| 3 to 5 years | 607 |  |  | 770 |  |
| Total | $ | 10,951 |  |  | $ | 12,964 |  |

[0000858877-23-000005:notes:182]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of January 28, 2023 and July 30, 2022, the liability for these purchase commitments was $450 million and $313 million, respectively, and was included in other current liabilities.

[0000858877-23-000005:notes:183]
(b)Other Commitments

[0000858877-23-000005:notes:184]
In connection with our acquisitions, we have agreed to pay certain additional amounts contingent upon the achievement of certain agreed-upon technology, development, product, or other milestones or upon the continued employment with Cisco of certain employees of the acquired entities.

[0000858877-23-000005:notes:185]
The following table summarizes the compensation expense related to acquisitions (in millions):

[0000858877-23-000005:notes:186]
|  | Three Months Ended |  | Six Months Ended |
|  | January 28, 2023 |  | January 29, 2022 |  | January 28, 2023 |  | January 29, 2022 |
| Compensation expense related to acquisitions | $ | 49 |  |  | $ | 75 |  |  | $ | 123 |  |  | $ | 164 |  |

[0000858877-23-000005:notes:187]
As of January 28, 2023, we estimated that future cash compensation expense of up to $338 million may be required to be recognized pursuant to the applicable business combination agreements.

[0000858877-23-000005:notes:188]
We also have certain funding commitments, primarily related to our privately held investments, some of which are based on the achievement of certain agreed-upon milestones or are required to be funded on demand. The funding commitments were $0.3 billion and $0.4 billion as of January 28, 2023 and July 30, 2022, respectively.

[0000858877-23-000005:notes:189]
(c)Product Warranties

[0000858877-23-000005:notes:190]
The following table summarizes the activity related to the product warranty liability (in millions):

[0000858877-23-000005:notes:191]
|  | Six Months Ended |
|  | January 28,2023 |  | January 29,2022 |
| Balance at beginning of period | $ | 333 |  |  | $ | 336 |  |
| Provisions for warranties issued | 188 |  |  | 218 |  |
| Adjustments for pre-existing warranties | 13 |  |  | 2 |  |
| Settlements | (218) |  |  | (222) |  |
| Balance at end of period | $ | 316 |  |  | $ | 334 |  |

[0000858877-23-000005:notes:192]
We accrue for warranty costs as part of our cost of sales based on associated material product costs, labor costs for technical support staff, and associated overhead. Our products are generally covered by a warranty for periods ranging from 90 days to five years, and for some products we provide a limited lifetime warranty.

[0000858877-23-000005:notes:193]
(d)Financing and Other Guarantees

[0000858877-23-000005:notes:194]
In the ordinary course of business, we provide financing guarantees for various third-party financing arrangements extended to channel partners customers. Payments under these financing guarantee arrangements were not material for the periods presented.

[0000858877-23-000005:notes:195]
Channel Partner Financing Guarantees   We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, with payment terms generally ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. The volume of channel partner financing was $7.5 billion and $6.8 billion for the second quarter of fiscal 2023 and 2022, respectively, and $15.1 billion and $13.4 billion for the first six months of fiscal 2023 and 2022, respectively. The balance of the channel partner financing subject to guarantees was $1.6 billion and $1.4 billion as of January 28, 2023 and July 30, 2022, respectively.

[0000858877-23-000005:notes:196]
Financing Guarantee Summary   The aggregate amounts of channel partner financing guarantees outstanding at January 28, 2023 and July 30, 2022, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

[0000858877-23-000005:notes:197]
|  | January 28,2023 |  | July 30,2022 |
| Maximum potential future payments | $ | 180 |  |  | $ | 188 |  |
| Deferred revenue | (35) |  |  | (9) |  |
| Total | $ | 145 |  |  | $ | 179 |  |

[0000858877-23-000005:notes:198]
(e)Indemnifications

[0000858877-23-000005:notes:199]
In the normal course of business, we have indemnification obligations to other parties, including customers, lessors, and parties to other transactions with us, with respect to certain matters. We have agreed to indemnify against losses arising from a breach of representations or covenants or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time or circumstances within which an indemnification claim can be made and the amount of the claim.

[0000858877-23-000005:notes:200]
It is not possible to determine the maximum potential amount for claims made under the indemnification obligations due to uncertainties in the litigation process, coordination with and contributions by other parties and the defendants in these types of cases, and the unique facts and circumstances involved in each particular case and agreement. Historically, indemnity payments made by us have not had a material effect on our Consolidated Financial Statements.

[0000858877-23-000005:notes:201]
In addition, we have entered into indemnification agreements with our officers and directors, and our Amended and Restated Bylaws contain similar indemnification obligations to our agents.

[0000858877-23-000005:notes:202]
(f)Legal Proceedings

[0000858877-23-000005:notes:203]
Brazil    Brazilian authorities have investigated our Brazilian subsidiary and certain of its former employees, as well as a Brazilian importer of our products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against our Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years. The asserted claims by Brazilian federal tax authorities are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $159 million for the alleged evasion of import and other taxes, $873 million for interest, and $394 million for various penalties, all determined using an exchange rate as of January 28, 2023.

[0000858877-23-000005:notes:204]
We have completed a thorough review of the matters and believe the asserted claims against our Brazilian subsidiary are without merit, and we are defending the claims vigorously. While we believe there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, we are unable to determine the likelihood of an unfavorable outcome against our Brazilian subsidiary and are unable to reasonably estimate a range of loss, if any. We do not expect a final judicial determination for several years.

[0000858877-23-000005:notes:205]
Centripetal     On February 13, 2018, Centripetal Networks, Inc. (“Centripetal”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Virginia, alleging that several of our products and services infringe eleven Centripetal U.S. patents. The district court case went to trial on five asserted patents. Subsequently, on October 5, 2020, the district court issued a judgment finding validity and willful infringement of four of the asserted patents and non-infringement of the fifth patent and awarded $1.9 billion in damages and $14 million in pre-judgment interest, declined to issue an injunction but, instead, awarded Centripetal a royalty against future revenue for an initial three-year term at a 10% rate, with a minimum and maximum annual royalty of $168 million and $300 million, respectively, and for a second three-year term at a 5% rate, with a minimum and maximum annual royalty of $84 million and $150 million, respectively. We appealed and, on June 23, 2022, the U.S. Court of Appeals for the Federal Circuit (“Federal Circuit”) vacated the district court’s final judgment, remanded the case back to the district court to be assigned to a new judge and ordered the district court to conduct additional proceedings and the district court set a hearing to commence on June 22, 2023. On August 9, 2022, Centripetal filed a petition for writ of certiorari in the U.S. Supreme Court challenging the Federal Circuit’s decision. The Supreme Court denied Centripetal’s petition on December 5, 2022.

[0000858877-23-000005:notes:206]
Between April 2020 and February 2022, Centripetal filed complaints in the District Court of Dusseldorf in Germany (“German Court”), asserting a total of five patents and one utility model. Centripetal sought damages and injunctive relief in all cases. On December 10, 2021, the German Court rejected Centripetal’s complaints on two patents, and Centripetal appealed. A hearing for a Cisco nullity action in the Federal Patent Court in Germany on one of those two patents occurred on August 1, 2022, and we are waiting for the Court’s opinion. On December 21, 2021, the German Court stayed its decision on infringement of the third patent pending a decision by the Federal Patent Court in a related nullity proceeding. On May 17, 2022, Centripetal withdrew its complaint for infringement of the German utility model. The German Court conducted a hearing on the remaining two Centripetal complaints on November 22, 2022. The German Court found no infringement on one patent and stayed the decision in the final case pending a decision by the European Patent Office in a related opposition proceeding.

[0000858877-23-000005:notes:207]
Due to uncertainty surrounding patent litigation processes in the U.S. and Europe, we are unable to reasonably estimate the ultimate outcome of the litigations at this time. If we do not prevail in either litigation, we believe that any damages ultimately assessed would not have a material effect on our Consolidated Financial Statements.

[0000858877-23-000005:notes:208]
Ramot     On June 12, 2019, Ramot at Tel Aviv University Ltd. (“Ramot”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Texas (“E.D. Tex.”), seeking damages, including enhanced damages, and a royalty on future sales. Ramot alleges that certain Cisco optical transceiver modules and line cards infringe three patents. The U.S. Patent and Trademark Office (“PTO”) preliminarily found all asserted claims unpatentable in ex parte reexamination proceedings and the pending District Court case has been stayed. On February 26, 2021, Ramot asserted patent infringement claims against Acacia Communications, Inc. (“Acacia”) in the District of Delaware (“D. Del.”), seeking damages, including enhanced damages, and a royalty on future sales. Ramot alleges that certain Acacia optical transceiver modules and integrated circuits infringe two of the three patents that Ramot asserted in the E.D. Tex. case and this case is also stayed pending reexamination proceedings.

[0000858877-23-000005:notes:209]
On September 28, 2021 and May 24, 2022, Cisco and Acacia filed two declaratory judgment actions of noninfringement against Ramot in D. Del on other Ramot patents in the same family as those involved in the pending cases above. Ramot is asserting counterclaims for infringement of the same patents and seeks damages, including enhanced damages, and a royalty on future

[0000858877-23-000005:notes:210]
sales. While we believe that we have strong non-infringement and invalidity arguments in these litigations, and that Ramot’s damages theories in such cases are not supported by prevailing law, we are unable to reasonably estimate the ultimate outcome of these litigations at this time due to uncertainties in the litigation processes. If we do not prevail in court in these litigations, we believe any damages ultimately assessed would not have a material effect on our Consolidated Financial Statements.

[0000858877-23-000005:notes:211]
Viasat     On November 6, 2019, Viasat, Inc. (“Viasat”) filed suit against Acacia in the California Superior Court for San Diego County (“SDSC”), alleging contract and trade secret claims for certain Acacia products sold from January 1, 2019 forward (“Viasat 2”). Viasat 2 is similar to a previous suit Viasat filed against Acacia and which resolved in July 2022 for an immaterial amount (“Viasat 1”). On June 9, 2020, Viasat filed a third suit in SDSC alleging contract and trade secrets claims for sales of additional Acacia products (“Viasat 3”, together with Viasat 2, the “Viasat Cases”). In October 2022, an amended complaint was filed in Viasat 3 asserting the same claims but alleging additional information.

[0000858877-23-000005:notes:212]
On July 28, 2017, Acacia filed suit in the Commonwealth of Massachusetts Superior Court against Viasat alleging claims for defamation, unfair competition, business torts, and declaratory judgment of no trade secret misappropriation (the “Massachusetts Action”). On April 5, 2018, Viasat counterclaimed with contract, trade secret, and unfair competition claims. Following resolution of Viasat 1, Acacia and Viasat jointly agreed to dismiss the Massachusetts Action in October 2022, thereby resolving the case.

[0000858877-23-000005:notes:213]
We are unable to reasonably estimate the ultimate outcome of any of the Viasat Cases at this time due to uncertainties in the litigation processes. If we do not prevail, we believe that any relief ultimately assessed in any of the Viasat Cases would not have a material effect on our Consolidated Financial Statements.

[0000858877-23-000005:notes:214]
Egenera     On August 8, 2016, Egenera, Inc. (“Egenera”) asserted infringement claims against us in the U.S. District Court for the District of Massachusetts, alleging that Cisco’s Unified Computing System Manager infringes three patents. Egenera sought damages, including enhanced damages, and an injunction. Two of the asserted patents were dismissed, leaving Egenera’s infringement claim based on one asserted patent. On March 25, 2022, the PTO preliminarily found all of the asserted claims of the remaining patent unpatentable in ex parte reexamination proceedings. On August 15, 2022, after a jury trial for the remaining patent, the jury returned a verdict in favor of Cisco. The District Court denied Egenera’s post-trial motions, and Egenera filed an appeal to the Federal Circuit on January 13, 2023 and those proceedings are ongoing.
In addition to the above matters, we are subject to other legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, we do not believe that the ultimate costs to resolve these matters will have a material effect on our Consolidated Financial Statements. For additional information regarding intellectual property litigation, see “Part II, Item 1A. Risk Factors—We may be found to infringe on intellectual property rights of others” herein.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock

[0000858877-23-000005:notes:215]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. Certain of these inventory purchase commitments with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000858877-23-000005:notes:216]
[same as prior period, unchanged from 0000858877-22-000025:notes:212]

[0000858877-23-000005:notes:217]
In September 2001, our Board of Directors authorized a stock repurchase program. As of January 28, 2023, the remaining authorized amount for stock repurchases under this program was approximately $13.4 billion with no termination date. A summary of the stock repurchase activity for fiscal 2023 and 2022 under the stock repurchase program, reported based on the trade date, is summarized as follows (in millions, except per-share amounts):

[0000858877-23-000005:notes:218]
| Quarter Ended |  | Shares |  | Weighted-Average Price per Share |  | Amount |
| Fiscal 2023 |  |  |  |  |  |  |
| January 28, 2023 |  | 26 |  | $ | 47.72 |  |  | $ | 1,256 |  |
| October 29, 2022 |  | 12 |  | $ | 43.76 |  |  | $ | 502 |  |
| Fiscal 2022 |  |  |  |  |  |  |
| July 30, 2022 |  | 54 |  |  | $ | 44.02 |  |  | $ | 2,402 |  |
| April 30, 2022 |  | 5 |  |  | $ | 54.20 |  |  | $ | 252 |  |
| January 29, 2022 |  | 82 |  |  | $ | 58.36 |  |  | $ | 4,824 |  |
| October 30, 2021 |  | 5 |  |  | $ | 56.49 |  |  | $ | 256 |  |

[0000858877-23-000005:notes:219]
There were stock repurchases of $68 million and $70 million that were pending settlement as of January 28, 2023 and July 30, 2022, respectively.

[0000858877-23-000005:notes:220]
[same as prior period, unchanged from 0000858877-22-000025:notes:216]

[0000858877-23-000005:notes:221]
(b)   Cash Dividends Declared

[0000858877-23-000005:notes:222]
On February 15, 2023, our Board of Directors declared a quarterly dividend of $0.39 per common share to be paid on April 26, 2023 to all stockholders of record as of the close of business on April 5, 2023. Any future dividends will be subject to the approval of our Board of Directors.

[0000858877-23-000005:notes:223]
(c)   Preferred Stock

[0000858877-23-000005:notes:224]
Under the terms of our Amended and Restated Certificate of Incorporation, the Board of Directors is authorized to issue preferred stock in one or more series and, in connection with the creation of such series, to fix by resolution the designation, powers (including voting powers (if any)), preferences and relative, participating, optional or other special rights, if any, of such series, and any qualifications, limitations or restrictions thereof, of the shares of such series. As of January 28, 2023, we had not issued any shares of preferred stock.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000858877-23-000005:notes:225]
[same as prior period, unchanged from 0000858877-22-000025:notes:219]

[0000858877-23-000005:notes:226]
[same as prior period, unchanged from 0000858877-22-000025:notes:220]

[0000858877-23-000005:notes:227]
[same as prior period, unchanged from 0000858877-22-000025:notes:221]

[0000858877-23-000005:notes:228]
Under the 2005 Plan’s share reserve feature, a distinction is made between the number of shares in the reserve attributable to (i) stock options and SARs and (ii) “full value” awards (i.e., stock grants and stock units). Shares issued as stock grants, pursuant to stock units or pursuant to the settlement of dividend equivalents are counted against shares available for issuance under the 2005 Plan on a 1.5-to-1 ratio. For each share awarded as restricted stock or a restricted stock unit award under the 2005 Plan, 1.5 shares was deducted from the available share-based award balance. If awards issued under the 2005 Plan are forfeited or terminated for any reason before being exercised or settled, then the shares underlying such awards, plus the number of additional shares, if any, that counted against shares available for issuance under the 2005 Plan at the time of grant as a result of the application of the share ratio described above, will become available again for issuance under the 2005 Plan. As of January 28, 2023, 133 million shares were authorized for future grant under the 2005 Plan.

[0000858877-23-000005:notes:229]
[same as prior period, unchanged from 0000858877-22-000025:notes:223]

[0000858877-23-000005:notes:230]
We have an Employee Stock Purchase Plan under which eligible employees are offered shares through a 24-month offering period, which consists of four consecutive 6-month purchase periods. Employees may purchase a limited amount of shares of our stock at a discount of up to 15% of the lesser of the fair market value at the beginning of the offering period or the end of each 6-month purchase period. The Employee Stock Purchase Plan is scheduled to terminate on the earlier of (i) January 3, 2030 and (ii) the date on which all shares available for issuance under the Employee Stock Purchase Plan are sold pursuant to exercised purchase rights. Under the Employee Stock Purchase Plan, we issued 9 million shares during the second quarter and first six months of fiscal 2023 and 8 million shares during the second quarter and first six months of fiscal 2022. As of January 28, 2023, 98 million shares were available for issuance under the Employee Stock Purchase Plan.

[0000858877-23-000005:notes:231]
[same as prior period, unchanged from 0000858877-22-000025:notes:225]

[0000858877-23-000005:notes:232]
[same as prior period, unchanged from 0000858877-22-000025:notes:226]

[0000858877-23-000005:notes:233]
|  | Three Months Ended |  | Six Months Ended |
|  | January 28, 2023 |  | January 29, 2022 |  | January 28, 2023 |  | January 29, 2022 |
| Cost of sales—product | $ | 40 |  |  | $ | 29 |  |  | $ | 71 |  |  | $ | 54 |  |
| Cost of sales—service | 66 |  |  | 52 |  |  | 116 |  |  | 96 |  |
| Share-based compensation expense in cost of sales | 106 |  |  | 81 |  |  | 187 |  |  | 150 |  |
| Research and development | 261 |  |  | 205 |  |  | 465 |  |  | 386 |  |
| Sales and marketing | 166 |  |  | 142 |  |  | 319 |  |  | 282 |  |
| General and administrative | 71 |  |  | 49 |  |  | 129 |  |  | 111 |  |
| Restructuring and other charges | (3) |  |  | — |  |  | (3) |  |  | 1 |  |
| Share-based compensation expense in operating expenses | 495 |  |  | 396 |  |  | 910 |  |  | 780 |  |
| Total share-based compensation expense | $ | 601 |  |  | $ | 477 |  |  | $ | 1,097 |  |  | $ | 930 |  |
| Income tax benefit for share-based compensation | $ | 109 |  |  | $ | 152 |  |  | $ | 208 |  |  | $ | 256 |  |

[0000858877-23-000005:notes:234]
As of January 28, 2023, the total compensation cost related to unvested share-based awards not yet recognized was $5.3 billion which is expected to be recognized over approximately 2.5 years on a weighted-average basis.

[0000858877-23-000005:notes:235]
[same as prior period, unchanged from 0000858877-22-000025:notes:229]

[0000858877-23-000005:notes:236]
[same as prior period, unchanged from 0000858877-22-000025:notes:230]

[0000858877-23-000005:notes:237]
|  | Restricted Stock/Stock Units |  | Weighted-AverageGrant Date FairValue per Share |  | Aggregate Fair Value |
| Unvested balance at July 31, 2021 | 94 |  |  | $ | 42.93 |  |  |  |
| Granted and assumed | 52 |  |  | 50.06 |  |  |  |
| Vested | (37) |  |  | 42.27 |  |  | $ | 1,979 |  |
| Canceled/forfeited/other | (12) |  |  | 45.63 |  |  |  |
| Unvested balance at July 30, 2022 | 97 |  |  | $ | 46.67 |  |  |  |
| Granted and assumed | 56 |  |  | 40.62 |  |  |  |
| Vested | (21) |  |  | 47.39 |  |  | $ | 923 |  |
| Canceled/forfeited/other | (5) |  |  | 45.73 |  |  |  |
| Unvested balance at January 28, 2023 | 127 |  |  | $ | 43.92 |  |  |  |


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000858877-23-000005:notes:238]
Comprehensive Income (Loss)
The components of AOCI, net of tax, and the other comprehensive income (loss), for the first six months of fiscal 2023 and 2022 are summarized as follows (in millions):

[0000858877-23-000005:notes:239]
|  | Net Unrealized Gains (Losses) on Available-for-Sale Investments |  | Net Unrealized Gains (Losses) Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Actuarial Gains (Losses) |  | Accumulated Other Comprehensive Income (Loss) |
| Balance at July 30, 2022 | $ | (379) |  |  | $ | 44 |  |  | $ | (1,287) |  |  | $ | (1,622) |  |
| Other comprehensive income (loss) before reclassifications | (76) |  |  | (12) |  |  | 106 |  |  | 18 |  |
| (Gains) losses reclassified out of AOCI | 9 |  |  | (37) |  |  | (1) |  |  | (29) |  |
| Tax benefit (expense) | 11 |  |  | 12 |  |  | 24 |  |  | 47 |  |
| Balance at January 28, 2023 | $ | (435) |  |  | $ | 7 |  |  | $ | (1,158) |  |  | $ | (1,586) |  |

[0000858877-23-000005:notes:240]
|  | Net Unrealized Gains (Losses) on Available-for-Sale Investments |  | Net Unrealized Gains (Losses) Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Actuarial Gains (Losses) |  | Accumulated Other Comprehensive Income (Loss) |
| Balance at July 31, 2021 | $ | 182 |  |  | $ | (1) |  |  | $ | (598) |  |  | $ | (417) |  |
| Other comprehensive income (loss) before reclassifications | (296) |  |  | 18 |  |  | (162) |  |  | (440) |  |
| (Gains) losses reclassified out of AOCI | (16) |  |  | (3) |  |  | 1 |  |  | (18) |  |
| Tax benefit (expense) | 80 |  |  | (3) |  |  | 9 |  |  | 86 |  |
| Balance at January 29, 2022 | $ | (50) |  |  | $ | 11 |  |  | $ | (750) |  |  | $ | (789) |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000858877-23-000005:notes:241]
[same as prior period, unchanged from 0000858877-22-000025:notes:235]

[0000858877-23-000005:notes:242]
|  | Three Months Ended |  | Six Months Ended |
|  | January 28,2023 |  | January 29,2022 |  | January 28,2023 |  | January 29,2022 |
| Income before provision for income taxes | $ | 3,415 |  |  | $ | 3,603 |  |  | $ | 6,890 |  |  | $ | 7,260 |  |
| Provision for income taxes | $ | 642 |  |  | $ | 630 |  |  | $ | 1,447 |  |  | $ | 1,307 |  |
| Effective tax rate | 18.8 | % |  | 17.5 | % |  | 21.0 | % |  | 18.0 | % |

[0000858877-23-000005:notes:243]
As of January 28, 2023, we had $3.4 billion of unrecognized tax benefits, of which $2.4 billion, if recognized, would favorably impact the effective tax rate. We regularly engage in discussions and negotiations with tax authorities regarding tax matters in various jurisdictions. We believe it is reasonably possible that certain federal, foreign, and state tax matters may be concluded in the next 12 months. Specific positions that may be resolved include issues involving transfer pricing and various other matters.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000858877-23-000005:notes:244]
[same as prior period, unchanged from 0000858877-22-000025:notes:238]

[0000858877-23-000005:notes:245]
We conduct business globally and are primarily managed on a geographic basis consisting of three segments: the Americas, EMEA, and APJC. Our management makes financial decisions and allocates resources based on the information it receives from our internal management system. Sales are attributed to a segment based on the ordering location of the customer. We do not allocate research and development, sales and marketing, or general and administrative expenses to our segments in this internal management system because management does not include the information in our measurement of the performance of the operating segments. In addition, we do not allocate amortization and impairment of acquisition-related intangible assets, share-based compensation expense, significant litigation settlements and other contingencies, charges related to asset impairments and restructurings, and certain other charges to the gross margin for each segment because management does not include this information in our measurement of the performance of the operating segments.

[0000858877-23-000005:notes:246]
Summarized financial information by segment for the second quarter and first six months of fiscal 2023 and 2022, based on our internal management system and as utilized by our Chief Operating Decision Maker (“CODM”), is as follows (in millions):

[0000858877-23-000005:notes:247]
|  | Three Months Ended |  | Six Months Ended |
|  | January 28,2023 |  | January 29,2022 |  | January 28,2023 |  | January 29,2022 |
| Revenue: |  |  |  |  |  |  |  |
| Americas | $ | 7,825 |  |  | $ | 7,146 |  |  | $ | 15,738 |  |  | $ | 14,706 |  |
| EMEA | 3,728 |  |  | 3,564 |  |  | 7,404 |  |  | 6,867 |  |
| APJC | 2,039 |  |  | 2,010 |  |  | 4,082 |  |  | 4,046 |  |
| Total | $ | 13,592 |  |  | $ | 12,720 |  |  | $ | 27,224 |  |  | $ | 25,620 |  |
| Gross margin: |  |  |  |  |  |  |  |
| Americas | $ | 4,920 |  |  | $ | 4,611 |  |  | $ | 9,904 |  |  | $ | 9,486 |  |
| EMEA | 2,469 |  |  | 2,381 |  |  | 4,795 |  |  | 4,509 |  |
| APJC | 1,298 |  |  | 1,337 |  |  | 2,571 |  |  | 2,654 |  |
| Segment total | 8,687 |  |  | 8,328 |  |  | 17,269 |  |  | 16,649 |  |
| Unallocated corporate items | (260) |  |  | (279) |  |  | (496) |  |  | (547) |  |
| Total | $ | 8,427 |  |  | $ | 8,049 |  |  | $ | 16,773 |  |  | $ | 16,102 |  |

[0000858877-23-000005:notes:248]
[same as prior period, unchanged from 0000858877-22-000025:notes:242]

[0000858877-23-000005:notes:249]
Revenue in the United States was $7.0 billion and $6.4 billion for the second quarter of fiscal 2023 and 2022, respectively, and $14.0 billion and $13.2 billion for the first six months of fiscal 2023 and 2022, respectively.

[0000858877-23-000005:notes:250]
[same as prior period, unchanged from 0000858877-22-000025:notes:244]

[0000858877-23-000005:notes:251]
[same as prior period, unchanged from 0000858877-22-000025:notes:245]


## us-gaap:EarningsPerShareTextBlock

[0000858877-23-000005:notes:252]
[same as prior period, unchanged from 0000858877-22-000025:notes:246]

[0000858877-23-000005:notes:253]
|  | Three Months Ended |  | Six Months Ended |
|  | January 28,2023 |  | January 29,2022 |  | January 28,2023 |  | January 29,2022 |
| Net income | $ | 2,773 |  |  | $ | 2,973 |  |  | $ | 5,443 |  |  | $ | 5,953 |  |
| Weighted-average shares—basic | 4,103 |  |  | 4,183 |  |  | 4,105 |  |  | 4,201 |  |
| Effect of dilutive potential common shares | 13 |  |  | 22 |  |  | 10 |  |  | 21 |  |
| Weighted-average shares—diluted | 4,116 |  |  | 4,205 |  |  | 4,115 |  |  | 4,222 |  |
| Net income per share—basic | $ | 0.68 |  |  | $ | 0.71 |  |  | $ | 1.33 |  |  | $ | 1.42 |  |
| Net income per share—diluted | $ | 0.67 |  |  | $ | 0.71 |  |  | $ | 1.32 |  |  | $ | 1.41 |  |
| Antidilutive employee share-based awards, excluded | 17 |  |  | 11 |  |  | 91 |  |  | 41 |  |
