# CSCO note change history — 0000858877-22-000025 → 0000858877-23-000005


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2023-02-21):
[0000858877-23-000005:note_history:1]
|  | January 28,2023 |  | July 30,2022 |
| Less than 1 year | $ | 8,651 |  |  | $ | 9,954 |  |
| 1 to 3 years | 1,693 |  |  | 2,240 |  |
| 3 to 5 years | 607 |  |  | 770 |  |
| Total | $ | 10,951 |  |  | $ | 12,964 |  |
  (was, 2022-11-22, similarity 0.9632):
[0000858877-22-000025:note_history:1]
|  | October 29,2022 |  | July 30,2022 |
| Less than 1 year | $ | 10,160 |  |  | $ | 9,954 |  |
| 1 to 3 years | 1,606 |  |  | 2,240 |  |
| 3 to 5 years | 842 |  |  | 770 |  |
| Total | $ | 12,608 |  |  | $ | 12,964 |  |

- changed (2023-02-21):
[0000858877-23-000005:note_history:2]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of January 28, 2023 and July 30, 2022, the liability for these purchase commitments was $450 million and $313 million, respectively, and was included in other current liabilities.
  (was, 2022-11-22, similarity 0.9576):
[0000858877-22-000025:note_history:2]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of October 29, 2022 and July 30, 2022, the liability for these purchase commitments was $380 million and $313 million, respectively, and was included in other current liabilities.

- changed (2023-02-21):
[0000858877-23-000005:note_history:3]
|  | Three Months Ended |  | Six Months Ended |
|  | January 28, 2023 |  | January 29, 2022 |  | January 28, 2023 |  | January 29, 2022 |
| Compensation expense related to acquisitions | $ | 49 |  |  | $ | 75 |  |  | $ | 123 |  |  | $ | 164 |  |
  (was, 2022-11-22, similarity 0.6985):
[0000858877-22-000025:note_history:3]
|  | Three Months Ended |
|  | October 29, 2022 |  | October 30, 2021 |
| Compensation expense related to acquisitions | $ | 74 |  |  | $ | 89 |  |

- changed (2023-02-21):
[0000858877-23-000005:note_history:4]
As of January 28, 2023, we estimated that future cash compensation expense of up to $338 million may be required to be recognized pursuant to the applicable business combination agreements.
  (was, 2022-11-22, similarity 0.9669):
[0000858877-22-000025:note_history:4]
As of October 29, 2022, we estimated that future cash compensation expense of up to $388 million may be required to be recognized pursuant to the applicable business combination agreements.

- changed (2023-02-21):
[0000858877-23-000005:note_history:5]
We also have certain funding commitments, primarily related to our privately held investments, some of which are based on the achievement of certain agreed-upon milestones or are required to be funded on demand. The funding commitments were $0.3 billion and $0.4 billion as of January 28, 2023 and July 30, 2022, respectively.
  (was, 2022-11-22, similarity 0.9775):
[0000858877-22-000025:note_history:5]
We also have certain funding commitments, primarily related to our privately held investments, some of which are based on the achievement of certain agreed-upon milestones or are required to be funded on demand. The funding commitments were $0.3 billion and $0.4 billion as of October 29, 2022 and July 30, 2022, respectively.

- changed (2023-02-21):
[0000858877-23-000005:note_history:6]
|  | Six Months Ended |
|  | January 28,2023 |  | January 29,2022 |
| Balance at beginning of period | $ | 333 |  |  | $ | 336 |  |
| Provisions for warranties issued | 188 |  |  | 218 |  |
| Adjustments for pre-existing warranties | 13 |  |  | 2 |  |
| Settlements | (218) |  |  | (222) |  |
| Balance at end of period | $ | 316 |  |  | $ | 334 |  |
  (was, 2022-11-22, similarity 0.9178):
[0000858877-22-000025:note_history:6]
|  | Three Months Ended |
|  | October 29,2022 |  | October 30,2021 |
| Balance at beginning of period | $ | 333 |  |  | $ | 336 |  |
| Provisions for warranties issued | 97 |  |  | 114 |  |
| Adjustments for pre-existing warranties | 1 |  |  | 2 |  |
| Settlements | (108) |  |  | (111) |  |
| Balance at end of period | $ | 323 |  |  | $ | 341 |  |

- changed (2023-02-21):
[0000858877-23-000005:note_history:7]
Channel Partner Financing Guarantees   We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, with payment terms generally ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. The volume of channel partner financing was $7.5 billion and $6.8 billion for the second quarter of fiscal 2023 and 2022, respectively, and $15.1 billion and $13.4 billion for the first six months of fiscal 2023 and 2022, respectively. The balance of the channel partner financing subject to guarantees was $1.6 billion and $1.4 billion as of January 28, 2023 and July 30, 2022, respectively.
  (was, 2022-11-22, similarity 0.9193):
[0000858877-22-000025:note_history:7]
Channel Partner Financing Guarantees   We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, with payment terms generally ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. The volume of channel partner financing was $7.6 billion and $6.6 billion for the first quarter of fiscal 2023 and 2022, respectively. The balance of the channel partner financing subject to guarantees was $1.5 billion and $1.4 billion as of October 29, 2022 and July 30, 2022, respectively.

- changed (2023-02-21):
[0000858877-23-000005:note_history:8]
Financing Guarantee Summary   The aggregate amounts of channel partner financing guarantees outstanding at January 28, 2023 and July 30, 2022, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):
  (was, 2022-11-22, similarity 0.9787):
[0000858877-22-000025:note_history:8]
Financing Guarantee Summary   The aggregate amounts of channel partner financing guarantees outstanding at October 29, 2022 and July 30, 2022, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

- changed (2023-02-21):
[0000858877-23-000005:note_history:9]
|  | January 28,2023 |  | July 30,2022 |
| Maximum potential future payments | $ | 180 |  |  | $ | 188 |  |
| Deferred revenue | (35) |  |  | (9) |  |
| Total | $ | 145 |  |  | $ | 179 |  |
  (was, 2022-11-22, similarity 0.9618):
[0000858877-22-000025:note_history:9]
|  | October 29,2022 |  | July 30,2022 |
| Maximum potential future payments | $ | 162 |  |  | $ | 188 |  |
| Deferred revenue | (19) |  |  | (9) |  |
| Total | $ | 143 |  |  | $ | 179 |  |

- changed (2023-02-21):
[0000858877-23-000005:note_history:10]
Brazil    Brazilian authorities have investigated our Brazilian subsidiary and certain of its former employees, as well as a Brazilian importer of our products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against our Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years. The asserted claims by Brazilian federal tax authorities are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $159 million for the alleged evasion of import and other taxes, $873 million for interest, and $394 million for various penalties, all determined using an exchange rate as of January 28, 2023.
  (was, 2022-11-22, similarity 0.9941):
[0000858877-22-000025:note_history:10]
Brazil    Brazilian authorities have investigated our Brazilian subsidiary and certain of its former employees, as well as a Brazilian importer of our products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against our Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years. The asserted claims by Brazilian federal tax authorities are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $153 million for the alleged evasion of import and other taxes, $820 million for interest, and $378 million for various penalties, all determined using an exchange rate as of October 29, 2022.

- changed (2023-02-21):
[0000858877-23-000005:note_history:11]
Centripetal     On February 13, 2018, Centripetal Networks, Inc. (“Centripetal”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Virginia, alleging that several of our products and services infringe eleven Centripetal U.S. patents. The district court case went to trial on five asserted patents. Subsequently, on October 5, 2020, the district court issued a judgment finding validity and willful infringement of four of the asserted patents and non-infringement of the fifth patent and awarded $1.9 billion in damages and $14 million in pre-judgment interest, declined to issue an injunction but, instead, awarded Centripetal a royalty against future revenue for an initial three-year term at a 10% rate, with a minimum and maximum annual royalty of $168 million and $300 million, respectively, and for a second three-year term at a 5% rate, with a minimum and maximum annual royalty of $84 million and $150 million, respectively. We appealed and, on June 23, 2022, the U.S. Court of Appeals for the Federal Circuit (“Federal Circuit”) vacated the district court’s final judgment, remanded the case back to the district court to be assigned to a new judge and ordered the district court to conduct additional proceedings and the district court set a hearing to commence on June 22, 2023. On August 9, 2022, Centripetal filed a petition for writ of certiorari in the U.S. Supreme Court challenging the Federal Circuit’s decision. The Supreme Court denied Centripetal’s petition on December 5, 2022.
  (was, 2022-11-22, similarity 0.6886):
[0000858877-22-000025:note_history:11]
Centripetal     On February 13, 2018, Centripetal Networks, Inc. (“Centripetal”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Virginia, alleging that several of our products and services infringe eleven Centripetal U.S. patents. The district court case went to trial on five asserted patents. Subsequently, on October 5, 2020, the district court issued a judgment finding validity and willful infringement of four of the asserted patents and non-infringement of the fifth patent and awarded $1.9 billion in damages and $14 million in pre-judgment interest, declined to issue an injunction but, instead, awarded Centripetal a royalty against future revenue for an initial three-year term at a 10% rate, with a minimum and maximum annual royalty of $168 million and $300 million, respectively, and for a second three-year term at a 5% rate, with a minimum and maximum annual royalty of $84 million and $150 million, respectively. We appealed and, on June 23, 2022, the Federal Circuit vacated the district court’s final judgment, remanded the case back to the district court to be assigned to a new judge and ordered the district court to conduct additional proceedings. On August 9, 2022, Centripetal filed a petition for writ of certiorari in the U.S. Supreme Court challenging the Federal Circuit’s decision. Cisco filed its opposition brief on October 26, 2022 and the proceedings are ongoing.

- changed (2023-02-21):
[0000858877-23-000005:note_history:12]
Between April 2020 and February 2022, Centripetal filed complaints in the District Court of Dusseldorf in Germany (“German Court”), asserting a total of five patents and one utility model. Centripetal sought damages and injunctive relief in all cases. On December 10, 2021, the German Court rejected Centripetal’s complaints on two patents, and Centripetal appealed. A hearing for a Cisco nullity action in the Federal Patent Court in Germany on one of those two patents occurred on August 1, 2022, and we are waiting for the Court’s opinion. On December 21, 2021, the German Court stayed its decision on infringement of the third patent pending a decision by the Federal Patent Court in a related nullity proceeding. On May 17, 2022, Centripetal withdrew its complaint for infringement of the German utility model. The German Court conducted a hearing on the remaining two Centripetal complaints on November 22, 2022. The German Court found no infringement on one patent and stayed the decision in the final case pending a decision by the European Patent Office in a related opposition proceeding.
  (was, 2022-11-22, similarity 0.8966):
[0000858877-22-000025:note_history:12]
Between April 2020 and February 2022, Centripetal filed complaints in the District Court of Dusseldorf in Germany (“German Court”), asserting a total of five patents and one utility model. Centripetal sought damages and injunctive relief in all cases. On December 10, 2021, the German Court rejected Centripetal’s complaints on two patents, and Centripetal appealed. A hearing for a Cisco nullity action in the Federal Patent Court in Germany on one of those two patents occurred on August 1, 2022, and we are waiting for the Court’s opinion. On December 21, 2021, the German Court stayed its decision on infringement of the third patent pending a decision by the Federal Patent Court in a related nullity proceeding. On May 17, 2022, Centripetal withdrew its complaint for infringement of the German utility model. The German Court has set a hearing on the remaining two Centripetal complaints for November 22, 2022.

- changed (2023-02-21):
[0000858877-23-000005:note_history:13]
Ramot     On June 12, 2019, Ramot at Tel Aviv University Ltd. (“Ramot”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Texas (“E.D. Tex.”), seeking damages, including enhanced damages, and a royalty on future sales. Ramot alleges that certain Cisco optical transceiver modules and line cards infringe three patents. The U.S. Patent and Trademark Office (“PTO”) preliminarily found all asserted claims unpatentable in ex parte reexamination proceedings and the pending District Court case has been stayed. On February 26, 2021, Ramot asserted patent infringement claims against Acacia Communications, Inc. (“Acacia”) in the District of Delaware (“D. Del.”), seeking damages, including enhanced damages, and a royalty on future sales. Ramot alleges that certain Acacia optical transceiver modules and integrated circuits infringe two of the three patents that Ramot asserted in the E.D. Tex. case and this case is also stayed pending reexamination proceedings.
  (was, 2022-11-22, similarity 0.978):
[0000858877-22-000025:note_history:13]
Ramot     On June 12, 2019, Ramot at Tel Aviv University Ltd. (“Ramot”) asserted patent infringement claims against us in the U.S. District Court for the Eastern District of Texas (“E.D. Tex.”), seeking damages, including enhanced damages, and a royalty on future sales. Ramot alleges that certain Cisco optical transceiver modules and line cards infringe three patents. The PTO preliminarily found all asserted claims unpatentable in ex parte reexamination proceedings and the pending District Court case has been stayed. On February 26, 2021, Ramot asserted patent infringement claims against Acacia Communications, Inc. (“Acacia”) in the District of Delaware (“D. Del.”), seeking damages, including enhanced damages, and a royalty on future sales. Ramot alleges that certain Acacia optical transceiver modules and integrated circuits infringe two of the three patents that Ramot asserted in the E.D. Tex. case and this case is also stayed pending reexamination proceedings.

- changed (2023-02-21):
[0000858877-23-000005:note_history:14]
On September 28, 2021 and May 24, 2022, Cisco and Acacia filed two declaratory judgment actions of noninfringement against Ramot in D. Del on other Ramot patents in the same family as those involved in the pending cases above. Ramot is asserting counterclaims for infringement of the same patents and seeks damages, including enhanced damages, and a royalty on future
  (was, 2022-11-22, similarity 0.6111):
[0000858877-22-000025:note_history:14]
On September 28, 2021 and May 24, 2022, Cisco and Acacia filed two declaratory judgment actions of noninfringement against Ramot in D. Del on other Ramot patents in the same family as those involved in the pending cases above. Ramot counterclaimed and filed another suit in E.D. Tex. for infringement of the same patents and seeks damages, including enhanced damages, and a royalty on future sales. While we believe that we have strong non-infringement and invalidity arguments in these litigations, and that Ramot’s damages theories in such cases are not supported by prevailing law, we are unable to reasonably estimate the ultimate outcome of these litigations at this time due to uncertainties in the litigation processes. If we do

- added (2023-02-21):
[0000858877-23-000005:note_history:15]
sales. While we believe that we have strong non-infringement and invalidity arguments in these litigations, and that Ramot’s damages theories in such cases are not supported by prevailing law, we are unable to reasonably estimate the ultimate outcome of these litigations at this time due to uncertainties in the litigation processes. If we do not prevail in court in these litigations, we believe any damages ultimately assessed would not have a material effect on our Consolidated Financial Statements.

- changed (2023-02-21):
[0000858877-23-000005:note_history:16]
Egenera     On August 8, 2016, Egenera, Inc. (“Egenera”) asserted infringement claims against us in the U.S. District Court for the District of Massachusetts, alleging that Cisco’s Unified Computing System Manager infringes three patents. Egenera sought damages, including enhanced damages, and an injunction. Two of the asserted patents were dismissed, leaving Egenera’s infringement claim based on one asserted patent. On March 25, 2022, the PTO preliminarily found all of the asserted claims of the remaining patent unpatentable in ex parte reexamination proceedings. On August 15, 2022, after a jury trial for the remaining patent, the jury returned a verdict in favor of Cisco. The District Court denied Egenera’s post-trial motions, and Egenera filed an appeal to the Federal Circuit on January 13, 2023 and those proceedings are ongoing.
In addition to the above matters, we are subject to other legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, we do not believe that the ultimate costs to resolve these matters will have a material effect on our Consolidated Financial Statements. For additional information regarding intellectual property litigation, see “Part II, Item 1A. Risk Factors—We may be found to infringe on intellectual property rights of others” herein.
  (was, 2022-11-22, similarity 0.9107):
[0000858877-22-000025:note_history:16]
Egenera     On August 8, 2016, Egenera, Inc. (“Egenera”) asserted infringement claims against us in the U.S. District Court for the District of Massachusetts, alleging that Cisco’s Unified Computing System Manager infringes three patents. Egenera sought damages, including enhanced damages, and an injunction. Two of the asserted patents were dismissed, leaving Egenera’s infringement claim based on one asserted patent. On March 25, 2022, the PTO preliminarily found all of the asserted claims of the remaining patent unpatentable in ex parte reexamination proceedings. On August 15, 2022, after a jury trial for the remaining patent, the jury returned a verdict in favor of Cisco. On October 27, 2022, Egenera filed a motion for judgment of infringement and a motion for new trial. Cisco opposed those motions and the post-trial proceedings are ongoing.
In addition to the above matters, we are subject to other legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, we do not believe that the ultimate costs to resolve these matters will have a material effect on our Consolidated Financial Statements. For additional information regarding intellectual property litigation, see “Part II, Item 1A. Risk Factors—We may be found to infringe on intellectual property rights of others” herein.

- removed (2023-02-21):
[0000858877-22-000025:note_history:17]
not prevail in court in these litigations, we believe any damages ultimately assessed would not have a material effect on our Consolidated Financial Statements.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-02-21):
[0000858877-23-000005:note_history:18]
We have prepared the accompanying financial data as of January 28, 2023 and for the second quarter and first six months of fiscal 2023 and 2022, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (SEC). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (GAAP) have been condensed or omitted pursuant to such rules and regulations. The July 30, 2022 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, we believe that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in our Annual Report on Form 10-K for the fiscal year ended July 30, 2022.
  (was, 2022-11-22, similarity 0.977):
[0000858877-22-000025:note_history:18]
We have prepared the accompanying financial data as of October 29, 2022 and for the first quarter of fiscal 2023 and 2022, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (SEC). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (GAAP) have been condensed or omitted pursuant to such rules and regulations. The July 30, 2022 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, we believe that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in our Annual Report on Form 10-K for the fiscal year ended July 30, 2022.

- added (2023-02-21):
[0000858877-23-000005:note_history:19]
In the opinion of management, all normal recurring adjustments necessary to state fairly the consolidated balance sheet as of January 28, 2023, the results of operations, the statements of comprehensive income and the statements of equity for the second quarter and first six months of fiscal 2023 and 2022, and the statements of cash flows for the first six months of fiscal 2023 and 2022, as applicable, have been made. The results of operations for the second quarter and first six months of fiscal 2023 are not necessarily indicative of the operating results for the full fiscal year or any future periods.

- removed (2023-02-21):
[0000858877-22-000025:note_history:20]
In the opinion of management, all normal recurring adjustments necessary to state fairly the consolidated balance sheet as of October 29, 2022, the results of operations, the statements of comprehensive income, the statements of cash flows and the statements of equity for the first quarter of fiscal 2023 and 2022, as applicable, have been made. The results of operations for the first quarter of fiscal 2023 are not necessarily indicative of the operating results for the full fiscal year or any future periods.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2023-02-21):
[0000858877-23-000005:note_history:21]
Reference Rate Reform  In March 2020, the Financial Accounting Standards Board issued an accounting standard update and subsequent amendments that provide optional expedients and exceptions to the current guidance on contract modification and hedging relationships to ease the financial reporting burden of the expected market transition from the London InterBank Offered Rate (LIBOR) and other interbank offered rates to alternative reference rates. This accounting standard update was effective upon issuance and may be applied prospectively through December 31, 2024. We do not expect this accounting standard update will have a material impact on our Consolidated Financial Statements.
  (was, 2022-11-22, similarity 0.9713):
[0000858877-22-000025:note_history:21]
Reference Rate Reform  In March 2020, the FASB issued an accounting standard update and subsequent amendments that provide optional expedients and exceptions to the current guidance on contract modification and hedging relationships to ease the financial reporting burden of the expected market transition from the London InterBank Offered Rate (LIBOR) and other interbank offered rates to alternative reference rates. This accounting standard update was effective upon issuance and may be applied prospectively through December 31, 2022. We do not expect this accounting standard update will have a material impact on our Consolidated Financial Statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-02-21):
[0000858877-23-000005:note_history:22]
|  | January 28, 2023 |  | July 30, 2022 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 1,250 |  |  | 2.44 | % |  | $ | 499 |  |  | 2.68 | % |
| Commercial paper | — |  |  | — |  |  | 600 |  |  | 2.05 | % |
| Total | $ | 1,250 |  |  |  |  | $ | 1,099 |  |  |  |
  (was, 2022-11-22, similarity 0.9736):
[0000858877-22-000025:note_history:22]
|  | October 29, 2022 |  | July 30, 2022 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 1,249 |  |  | 2.44 | % |  | $ | 499 |  |  | 2.68 | % |
| Commercial paper | — |  |  | — |  |  | 600 |  |  | 2.05 | % |
| Total | $ | 1,249 |  |  |  |  | $ | 1,099 |  |  |  |

- changed (2023-02-21):
[0000858877-23-000005:note_history:23]
|  |  |  | January 28, 2023 |  | July 30, 2022 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 2.60% | February 28, 2023 |  | $ | 500 |  |  | 2.68% |  | $ | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 5.28% |  | 1,000 |  |  | 2.69% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 5.65% |  | 500 |  |  | 3.20% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 9,000 |  |  |  |  | 9,000 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (71) |  |  |  |  | (75) |  |  |  |
| Hedge accounting fair value adjustments |  |  | (42) |  |  |  |  | (10) |  |  |  |
| Total |  |  | $ | 8,887 |  |  |  |  | $ | 8,915 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 1,250 |  |  |  |  | $ | 499 |  |  |  |
| Long-term debt |  |  | 7,637 |  |  |  |  | 8,416 |  |  |  |
| Total |  |  | $ | 8,887 |  |  |  |  | $ | 8,915 |  |  |  |
  (was, 2022-11-22, similarity 0.9932):
[0000858877-22-000025:note_history:23]
|  |  |  | October 29, 2022 |  | July 30, 2022 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 2.60% | February 28, 2023 |  | $ | 500 |  |  | 2.68% |  | $ | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 4.04% |  | 1,000 |  |  | 2.69% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 4.61% |  | 500 |  |  | 3.20% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 9,000 |  |  |  |  | 9,000 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (73) |  |  |  |  | (75) |  |  |  |
| Hedge accounting fair value adjustments |  |  | (49) |  |  |  |  | (10) |  |  |  |
| Total |  |  | $ | 8,878 |  |  |  |  | $ | 8,915 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 1,249 |  |  |  |  | $ | 499 |  |  |  |
| Long-term debt |  |  | 7,629 |  |  |  |  | 8,416 |  |  |  |
| Total |  |  | $ | 8,878 |  |  |  |  | $ | 8,915 |  |  |  |

- changed (2023-02-21):
[0000858877-23-000005:note_history:24]
Interest is payable semiannually on each class of the senior fixed-rate notes. Each of the senior fixed-rate notes is redeemable by us at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to our short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of January 28, 2023, we were in compliance with all debt covenants.
  (was, 2022-11-22, similarity 0.984):
[0000858877-22-000025:note_history:24]
Interest is payable semiannually on each class of the senior fixed-rate notes. Each of the senior fixed-rate notes is redeemable by us at any time, subject to a make-whole premium. The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to our short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of October 29, 2022, we were in compliance with all debt covenants.

- changed (2023-02-21):
[0000858877-23-000005:note_history:25]
As of January 28, 2023, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):
  (was, 2022-11-22, similarity 0.9556):
[0000858877-22-000025:note_history:25]
As of October 29, 2022, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

- changed (2023-02-21):
[0000858877-23-000005:note_history:26]
| Fiscal Year | Amount |
| 2023 (remaining six months) | $ | 500 |  |
| 2024 | 1,750 |  |
| 2025 | 500 |  |
| 2026 | 750 |  |
| 2027 | 1,500 |  |
| Thereafter | 4,000 |  |
| Total | $ | 9,000 |  |
  (was, 2022-11-22, similarity 0.9836):
[0000858877-22-000025:note_history:26]
| Fiscal Year | Amount |
| 2023 (remaining nine months) | $ | 500 |  |
| 2024 | 1,750 |  |
| 2025 | 500 |  |
| 2026 | 750 |  |
| 2027 | 1,500 |  |
| Thereafter | 4,000 |  |
| Total | $ | 9,000 |  |

- changed (2023-02-21):
[0000858877-23-000005:note_history:27]
On May 13, 2021, we entered into a 5-year credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 13, 2026. As of January 28, 2023, we were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under the credit agreement.
Any advances under the 5-year credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (a) with respect to loans in U.S. dollars, (i) LIBOR or (ii) the Base Rate (to be defined as the highest of (x) the Bank of America prime rate, (y) the Federal Funds rate plus 0.50% and (z) a daily rate equal to one-month LIBOR plus 1.0%), (b) with respect to loans in Euros, EURIBOR, (c) with respect to loans in Yen, TIBOR and (d) with respect to loans in Pounds Sterling, SONIA plus a credit spread adjustment, plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the interest rate be less than 0.0%. We will pay a quarterly commitment fee during the term of the 5-year credit agreement which may vary depending on our senior debt credit ratings. In addition, the 5-year credit agreement incorporates certain sustainability-linked metrics. Specifically, our applicable interest rate and commitment fee are subject to upward or downward adjustments if we achieve, or fail to achieve, certain specified targets based on two key performance indicator metrics: (i) social impact and (ii) foam reduction. We may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and, at our option, extend the maturity of the facility for an additional year up to two times. The credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio as defined in the agreement.
  (was, 2022-11-22, similarity 0.9048):
[0000858877-22-000025:note_history:27]
Any advances under the 5-year credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (a) with respect to loans in U.S. dollars, (i) LIBOR or (ii) the Base Rate (to be defined as the highest of (x) the Bank of America prime rate, (y) the Federal Funds rate plus 0.50% and (z) a daily rate equal to one-month LIBOR plus 1.0%), (b) with respect to loans in Euros, EURIBOR, (c) with respect to loans in Yen, TIBOR and (d) with respect to loans in Pounds Sterling, SONIA plus a credit spread adjustment, plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the interest rate be less than 0.0%. We will pay a quarterly commitment fee during the term of the 5-year credit agreement which may vary depending on our senior debt credit ratings. In addition, the 5-year credit agreement incorporates certain sustainability-linked metrics. Specifically, our applicable interest rate and commitment fee are subject to upward or downward adjustments if we achieve, or fail to achieve, certain specified targets based on two key performance indicator metrics: (i) social impact and (ii) foam reduction. We may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and, at our option, extend the maturity of the facility for an additional year up to two times. The credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio as defined in the agreement.

- removed (2023-02-21):
[0000858877-22-000025:note_history:28]
On May 13, 2021, we entered into a 5-year credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 13, 2026. As of October 29, 2022, we were in compliance

- removed (2023-02-21):
[0000858877-22-000025:note_history:29]
with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under the credit agreement.


## us-gaap:DebtSecuritiesAvailableForSaleUnrealizedLossPositionFairValueTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-02-21):
[0000858877-23-000005:note_history:30]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at January 28, 2023 and July 30, 2022 (in millions):
  (was, 2022-11-22, similarity 0.967):
[0000858877-22-000025:note_history:30]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at October 29, 2022 and July 30, 2022 (in millions):

- changed (2023-02-21):
[0000858877-23-000005:note_history:31]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| January 28, 2023 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 470 |  |  | $ | (6) |  |  | $ | 1,086 |  |  | $ | (48) |  |  | $ | 1,556 |  |  | $ | (54) |  |
| U.S. government agency securities | 33 |  |  | — |  |  | 121 |  |  | (5) |  |  | 154 |  |  | (5) |  |
| Non-U.S. government and agency securities | 339 |  |  | (1) |  |  | — |  |  | — |  |  | 339 |  |  | (1) |  |
| Corporate debt securities | 2,770 |  |  | (94) |  |  | 3,333 |  |  | (219) |  |  | 6,103 |  |  | (313) |  |
| U.S. agency mortgage-backed securities | 305 |  |  | (12) |  |  | 1,440 |  |  | (176) |  |  | 1,745 |  |  | (188) |  |
| Commercial paper | 40 |  |  | — |  |  | — |  |  | — |  |  | 40 |  |  | — |  |
| Total | $ | 3,957 |  |  | $ | (113) |  |  | $ | 5,980 |  |  | $ | (448) |  |  | $ | 9,937 |  |  | $ | (561) |  |
  (was, 2022-11-22, similarity 0.66):
[0000858877-22-000025:note_history:31]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| October 29, 2022 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 530 |  |  | $ | (12) |  |  | $ | 944 |  |  | $ | (58) |  |  | $ | 1,474 |  |  | $ | (70) |  |
| U.S. government agency securities | 101 |  |  | (2) |  |  | 64 |  |  | (4) |  |  | 165 |  |  | (6) |  |
| Non-U.S. government and agency securities | 257 |  |  | (1) |  |  | — |  |  | — |  |  | 257 |  |  | (1) |  |
| Corporate debt securities | 5,065 |  |  | (252) |  |  | 2,090 |  |  | (206) |  |  | 7,155 |  |  | (458) |  |
| U.S. agency mortgage-backed securities | 651 |  |  | (76) |  |  | 1,136 |  |  | (197) |  |  | 1,787 |  |  | (273) |  |
| Commercial paper | 45 |  |  | — |  |  | — |  |  | — |  |  | 45 |  |  | — |  |
| Total | $ | 6,649 |  |  | $ | (343) |  |  | $ | 4,234 |  |  | $ | (465) |  |  | $ | 10,883 |  |  | $ | (808) |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2023-02-21):
[0000858877-23-000005:note_history:32]
| January 28, 2023 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 2,050 |  |  | $ | 2 |  |  | $ | (54) |  |  | $ | 1,998 |  |
| U.S. government agency securities | 169 |  |  | — |  |  | (5) |  |  | 164 |  |
| Non-U.S. government and agency securities | 354 |  |  | — |  |  | (1) |  |  | 353 |  |
| Corporate debt securities | 7,480 |  |  | 5 |  |  | (345) |  |  | 7,140 |  |
| U.S. agency mortgage-backed securities | 2,013 |  |  | 2 |  |  | (188) |  |  | 1,827 |  |
| Commercial paper | 1,029 |  |  | — |  |  | — |  |  | 1,029 |  |
| Certificates of deposit | 261 |  |  | — |  |  | — |  |  | 261 |  |
| Total | $ | 13,356 |  |  | $ | 9 |  |  | $ | (593) |  |  | $ | 12,772 |  |

- changed (2023-02-21):
[0000858877-23-000005:note_history:33]
Net unsettled investment purchases were $15 million and net unsettled investment sales were $70 million as of January 28, 2023 and July 30, 2022, respectively, and were included in other current assets and other current liabilities.
  (was, 2022-11-22, similarity 0.968):
[0000858877-22-000025:note_history:33]
Net unsettled investment purchases were $42 million and net unsettled investment sales were $70 million as of October 29, 2022 and July 30, 2022, respectively, and were included in other current assets and other current liabilities.

- changed (2023-02-21):
[0000858877-23-000005:note_history:34]
|  | Three Months Ended |  | Six Months Ended |
|  | January 28, 2023 |  | January 29, 2022 |  | January 28, 2023 |  | January 29, 2022 |
| Gross realized gains | $ | 3 |  |  | $ | 13 |  |  | $ | 3 |  |  | $ | 19 |  |
| Gross realized losses | (6) |  |  | (3) |  |  | (12) |  |  | (3) |  |
| Total | $ | (3) |  |  | $ | 10 |  |  | $ | (9) |  |  | $ | 16 |  |
  (was, 2022-11-22, similarity 0.6858):
[0000858877-22-000025:note_history:34]
|  | Three Months Ended |
|  | October 29, 2022 |  | October 30, 2021 |
| Gross realized gains | $ | — |  |  | $ | 6 |  |
| Gross realized losses | (6) |  |  | — |  |
| Total | $ | (6) |  |  | $ | 6 |  |

- changed (2023-02-21):
[0000858877-23-000005:note_history:35]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at January 28, 2023 and July 30, 2022 (in millions):
  (was, 2022-11-22, similarity 0.967):
[0000858877-22-000025:note_history:35]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at October 29, 2022 and July 30, 2022 (in millions):

- changed (2023-02-21):
[0000858877-23-000005:note_history:36]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| January 28, 2023 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 470 |  |  | $ | (6) |  |  | $ | 1,086 |  |  | $ | (48) |  |  | $ | 1,556 |  |  | $ | (54) |  |
| U.S. government agency securities | 33 |  |  | — |  |  | 121 |  |  | (5) |  |  | 154 |  |  | (5) |  |
| Non-U.S. government and agency securities | 339 |  |  | (1) |  |  | — |  |  | — |  |  | 339 |  |  | (1) |  |
| Corporate debt securities | 2,770 |  |  | (94) |  |  | 3,333 |  |  | (219) |  |  | 6,103 |  |  | (313) |  |
| U.S. agency mortgage-backed securities | 305 |  |  | (12) |  |  | 1,440 |  |  | (176) |  |  | 1,745 |  |  | (188) |  |
| Commercial paper | 40 |  |  | — |  |  | — |  |  | — |  |  | 40 |  |  | — |  |
| Total | $ | 3,957 |  |  | $ | (113) |  |  | $ | 5,980 |  |  | $ | (448) |  |  | $ | 9,937 |  |  | $ | (561) |  |
  (was, 2022-11-22, similarity 0.66):
[0000858877-22-000025:note_history:36]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| October 29, 2022 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 530 |  |  | $ | (12) |  |  | $ | 944 |  |  | $ | (58) |  |  | $ | 1,474 |  |  | $ | (70) |  |
| U.S. government agency securities | 101 |  |  | (2) |  |  | 64 |  |  | (4) |  |  | 165 |  |  | (6) |  |
| Non-U.S. government and agency securities | 257 |  |  | (1) |  |  | — |  |  | — |  |  | 257 |  |  | (1) |  |
| Corporate debt securities | 5,065 |  |  | (252) |  |  | 2,090 |  |  | (206) |  |  | 7,155 |  |  | (458) |  |
| U.S. agency mortgage-backed securities | 651 |  |  | (76) |  |  | 1,136 |  |  | (197) |  |  | 1,787 |  |  | (273) |  |
| Commercial paper | 45 |  |  | — |  |  | — |  |  | — |  |  | 45 |  |  | — |  |
| Total | $ | 6,649 |  |  | $ | (343) |  |  | $ | 4,234 |  |  | $ | (465) |  |  | $ | 10,883 |  |  | $ | (808) |  |

- changed (2023-02-21):
[0000858877-23-000005:note_history:37]
The following table summarizes the maturities of our available-for-sale debt investments as of January 28, 2023 (in millions):
  (was, 2022-11-22, similarity 0.9504):
[0000858877-22-000025:note_history:37]
The following table summarizes the maturities of our available-for-sale debt investments as of October 29, 2022 (in millions):

- changed (2023-02-21):
[0000858877-23-000005:note_history:38]
|  | Amortized Cost |  | Fair Value |
| Within 1 year | $ | 4,806 |  |  | $ | 4,734 |  |
| After 1 year through 5 years | 6,491 |  |  | 6,170 |  |
| After 5 years through 10 years | 46 |  |  | 41 |  |
| Mortgage-backed securities with no single maturity | 2,013 |  |  | 1,827 |  |
| Total | $ | 13,356 |  |  | $ | 12,772 |  |
  (was, 2022-11-22, similarity 0.9443):
[0000858877-22-000025:note_history:38]
|  | Amortized Cost |  | Fair Value |
| Within 1 year | $ | 4,483 |  |  | $ | 4,399 |  |
| After 1 year through 5 years | 6,478 |  |  | 6,002 |  |
| After 5 years through 10 years | 56 |  |  | 47 |  |
| After 10 years | 1 |  |  | 1 |  |
| Mortgage-backed securities with no single maturity | 2,071 |  |  | 1,798 |  |
| Total | $ | 13,089 |  |  | $ | 12,247 |  |

- added (2023-02-21):
[0000858877-23-000005:note_history:39]
We held marketable equity securities of $280 million and $241 million as of January 28, 2023 and July 30, 2022, respectively. We recognized a net unrealized gain of $11 million and a net unrealized loss of $9 million during the second quarter and first six months of fiscal 2023, respectively, and a net unrealized loss of $18 million and $13 million during the corresponding periods of fiscal 2022, respectively, on our marketable securities still held as of the reporting date. Our net adjustments to non-marketable equity securities measured using the measurement alternative still held was a net gain of $3 million and a net loss of $8 million for the second quarter and first six months of fiscal 2023, respectively, and a net gain of $14 million and $16 million for the corresponding periods of fiscal 2022, respectively. We held equity interests in certain private equity funds of $1.0 billion and $1.1 billion as of January 28, 2023 and July 30, 2022, respectively, which are accounted for under the NAV practical expedient.

- changed (2023-02-21):
[0000858877-23-000005:note_history:40]
In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers are evaluated for consolidation under the variable interest or voting interest entity models. We evaluate on an ongoing basis our investments in these privately held companies and our customer financings, and have determined that as of January 28, 2023, there were no significant variable interest or voting interest entities required to be consolidated in our Consolidated Financial Statements.
  (was, 2022-11-22, similarity 0.9875):
[0000858877-22-000025:note_history:40]
In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers are evaluated for consolidation under the variable interest or voting interest entity models. We evaluate on an ongoing basis our investments in these privately held companies and our customer financings, and have determined that as of October 29, 2022, there were no significant variable interest or voting interest entities required to be consolidated in our Consolidated Financial Statements.

- changed (2023-02-21):
[0000858877-23-000005:note_history:41]
The carrying value of our investments in privately held companies was $1.8 billion and $1.9 billion as of January 28, 2023 and July 30, 2022, respectively. Of the total carrying value of our investments in privately held companies as of January 28, 2023, $1.1 billion of such investments are considered to be in variable interest entities which are unconsolidated. As of January 28, 2023, we have total funding commitments of $0.3 billion related to privately held investments, some of which may be based on the achievement of certain agreed-upon milestones or are required to be funded on demand. The carrying value of these investments and the additional funding commitments, collectively, represent our maximum exposure related to privately held investments.
  (was, 2022-11-22, similarity 0.9589):
[0000858877-22-000025:note_history:41]
The carrying value of our investments in privately held companies was $1.8 billion and $1.9 billion as of October 29, 2022 and July 30, 2022, respectively. Of the total carrying value of our investments in privately held companies as of October 29, 2022, $1.1 billion of such investments are considered to be in variable interest entities which are unconsolidated. As of October 29, 2022, we have total funding commitments of $0.3 billion related to privately held investments, some of which may be based on the achievement of certain agreed-upon milestones or are required to be funded on demand. The carrying value of these investments and the additional funding commitments, collectively, represent our maximum exposure related to privately held investments.

- removed (2023-02-21):
[0000858877-22-000025:note_history:42]
| October 29, 2022 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |
| U.S. government securities | $ | 1,545 |  |  | $ | — |  |  | $ | (70) |  |  | $ | 1,475 |  |
| U.S. government agency securities | 171 |  |  | — |  |  | (6) |  |  | 165 |  |
| Non-U.S. government and agency securities | 275 |  |  | — |  |  | (1) |  |  | 274 |  |
| Corporate debt securities | 7,808 |  |  | — |  |  | (492) |  |  | 7,316 |  |
| U.S. agency mortgage-backed securities | 2,071 |  |  | — |  |  | (273) |  |  | 1,798 |  |
| Commercial paper | 798 |  |  | — |  |  | — |  |  | 798 |  |
| Certificates of deposit | 421 |  |  | — |  |  | — |  |  | 421 |  |
| Total | $ | 13,089 |  |  | $ | — |  |  | $ | (842) |  |  | $ | 12,247 |  |

- removed (2023-02-21):
[0000858877-22-000025:note_history:43]
We held marketable equity securities of $245 million and $241 million as of October 29, 2022 and July 30, 2022, respectively. We recognized a net unrealized loss of $20 million and a net unrealized gain of $5 million during the first quarter of fiscal 2023 and 2022, respectively, on our marketable securities still held as of the reporting date. Our net adjustments to non-marketable equity securities measured using the measurement alternative still held was a net loss of $12 million and a net gain of $2 million for the first quarter of fiscal 2023 and 2022, respectively. We held equity interests in certain private equity funds of $1.0 billion and $1.1 billion as of October 29, 2022 and July 30, 2022, respectively, which are accounted for under the NAV practical expedient.


## us-gaap:ScheduleOfDebtInstrumentsTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-02-21):
[0000858877-23-000005:note_history:44]
|  |  |  | January 28, 2023 |  | July 30, 2022 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 2.60% | February 28, 2023 |  | $ | 500 |  |  | 2.68% |  | $ | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 5.28% |  | 1,000 |  |  | 2.69% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 5.65% |  | 500 |  |  | 3.20% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 9,000 |  |  |  |  | 9,000 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (71) |  |  |  |  | (75) |  |  |  |
| Hedge accounting fair value adjustments |  |  | (42) |  |  |  |  | (10) |  |  |  |
| Total |  |  | $ | 8,887 |  |  |  |  | $ | 8,915 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 1,250 |  |  |  |  | $ | 499 |  |  |  |
| Long-term debt |  |  | 7,637 |  |  |  |  | 8,416 |  |  |  |
| Total |  |  | $ | 8,887 |  |  |  |  | $ | 8,915 |  |  |  |
  (was, 2022-11-22, similarity 0.9932):
[0000858877-22-000025:note_history:44]
|  |  |  | October 29, 2022 |  | July 30, 2022 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 2.60% | February 28, 2023 |  | $ | 500 |  |  | 2.68% |  | $ | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 |  | 750 |  |  | 2.27% |  | 750 |  |  | 2.27% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 4.04% |  | 1,000 |  |  | 2.69% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 4.61% |  | 500 |  |  | 3.20% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 9,000 |  |  |  |  | 9,000 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (73) |  |  |  |  | (75) |  |  |  |
| Hedge accounting fair value adjustments |  |  | (49) |  |  |  |  | (10) |  |  |  |
| Total |  |  | $ | 8,878 |  |  |  |  | $ | 8,915 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 1,249 |  |  |  |  | $ | 499 |  |  |  |
| Long-term debt |  |  | 7,629 |  |  |  |  | 8,416 |  |  |  |
| Total |  |  | $ | 8,878 |  |  |  |  | $ | 8,915 |  |  |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-02-21):
[0000858877-23-000005:note_history:45]
As of January 28, 2023, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):
  (was, 2022-11-22, similarity 0.9556):
[0000858877-22-000025:note_history:45]
As of October 29, 2022, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

- changed (2023-02-21):
[0000858877-23-000005:note_history:46]
| Fiscal Year | Amount |
| 2023 (remaining six months) | $ | 500 |  |
| 2024 | 1,750 |  |
| 2025 | 500 |  |
| 2026 | 750 |  |
| 2027 | 1,500 |  |
| Thereafter | 4,000 |  |
| Total | $ | 9,000 |  |
  (was, 2022-11-22, similarity 0.9836):
[0000858877-22-000025:note_history:46]
| Fiscal Year | Amount |
| 2023 (remaining nine months) | $ | 500 |  |
| 2024 | 1,750 |  |
| 2025 | 500 |  |
| 2026 | 750 |  |
| 2027 | 1,500 |  |
| Thereafter | 4,000 |  |
| Total | $ | 9,000 |  |


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-02-21):
[0000858877-23-000005:note_history:47]
|  | January 28, 2023 |  | July 30, 2022 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 1,250 |  |  | 2.44 | % |  | $ | 499 |  |  | 2.68 | % |
| Commercial paper | — |  |  | — |  |  | 600 |  |  | 2.05 | % |
| Total | $ | 1,250 |  |  |  |  | $ | 1,099 |  |  |  |
  (was, 2022-11-22, similarity 0.9736):
[0000858877-22-000025:note_history:47]
|  | October 29, 2022 |  | July 30, 2022 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 1,249 |  |  | 2.44 | % |  | $ | 499 |  |  | 2.68 | % |
| Commercial paper | — |  |  | — |  |  | 600 |  |  | 2.05 | % |
| Total | $ | 1,249 |  |  |  |  | $ | 1,099 |  |  |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2023-02-21):
[0000858877-23-000005:note_history:48]
|  | Three Months Ended |  | Six Months Ended |
|  | January 28,2023 |  | January 29,2022 |  | January 28, 2023 |  | January 29, 2022 |
| Product revenue: |  |  |  |  |  |  |  |
| Secure, Agile Networks | $ | 6,746 |  |  | $ | 5,899 |  |  | $ | 13,430 |  |  | $ | 11,867 |  |
| Internet for the Future | 1,306 |  |  | 1,322 |  |  | 2,616 |  |  | 2,695 |  |
| Collaboration | 958 |  |  | 1,067 |  |  | 2,044 |  |  | 2,176 |  |
| End-to-End Security | 943 |  |  | 883 |  |  | 1,914 |  |  | 1,778 |  |
| Optimized Application Experiences | 199 |  |  | 180 |  |  | 393 |  |  | 361 |  |
| Other Products | 3 |  |  | 2 |  |  | 4 |  |  | 5 |  |
| Total Product | 10,155 |  |  | 9,353 |  |  | 20,400 |  |  | 18,882 |  |
| Services | 3,437 |  |  | 3,367 |  |  | 6,824 |  |  | 6,738 |  |
| Total | $ | 13,592 |  |  | $ | 12,720 |  |  | $ | 27,224 |  |  | $ | 25,620 |  |

- added (2023-02-21):
[0000858877-23-000005:note_history:49]
|  | Three Months Ended |  | Six Months Ended |
|  | January 28,2023 |  | January 29,2022 |  | January 28,2023 |  | January 29,2022 |
| Revenue: |  |  |  |  |  |  |  |
| Secure, Agile Networks | $ | 6,746 |  |  | $ | 5,899 |  |  | $ | 13,430 |  |  | $ | 11,867 |  |
| Internet for the Future | 1,306 |  |  | 1,322 |  |  | 2,616 |  |  | 2,695 |  |
| Collaboration | 958 |  |  | 1,067 |  |  | 2,044 |  |  | 2,176 |  |
| End-to-End Security | 943 |  |  | 883 |  |  | 1,914 |  |  | 1,778 |  |
| Optimized Application Experiences | 199 |  |  | 180 |  |  | 393 |  |  | 361 |  |
| Other Products | 3 |  |  | 2 |  |  | 4 |  |  | 5 |  |
| Total Product | 10,155 |  |  | 9,353 |  |  | 20,400 |  |  | 18,882 |  |
| Services | 3,437 |  |  | 3,367 |  |  | 6,824 |  |  | 6,738 |  |
| Total | $ | 13,592 |  |  | $ | 12,720 |  |  | $ | 27,224 |  |  | $ | 25,620 |  |

- removed (2023-02-21):
[0000858877-22-000025:note_history:50]
|  | Three Months Ended |
|  | October 29,2022 |  | October 30,2021 |
| Product revenue: |  |  |  |
| Secure, Agile Networks | $ | 6,684 |  |  | $ | 5,968 |  |
| Internet for the Future | 1,310 |  |  | 1,373 |  |
| Collaboration | 1,086 |  |  | 1,109 |  |
| End-to-End Security | 971 |  |  | 895 |  |
| Optimized Application Experiences | 193 |  |  | 181 |  |
| Other Products | 2 |  |  | 3 |  |
| Total Product | 10,245 |  |  | 9,529 |  |
| Services | 3,387 |  |  | 3,371 |  |
| Total | $ | 13,632 |  |  | $ | 12,900 |  |

- removed (2023-02-21):
[0000858877-22-000025:note_history:51]
|  | Three Months Ended |
|  | October 29,2022 |  | October 30,2021 |
| Revenue: |  |  |  |
| Secure, Agile Networks | $ | 6,684 |  |  | $ | 5,968 |  |
| Internet for the Future | 1,310 |  |  | 1,373 |  |
| Collaboration | 1,086 |  |  | 1,109 |  |
| End-to-End Security | 971 |  |  | 895 |  |
| Optimized Application Experiences | 193 |  |  | 181 |  |
| Other Products | 2 |  |  | 3 |  |
| Total Product | 10,245 |  |  | 9,529 |  |
| Services | 3,387 |  |  | 3,371 |  |
| Total | $ | 13,632 |  |  | $ | 12,900 |  |


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-02-21):
[0000858877-23-000005:note_history:52]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of January 28, 2023 and July 30, 2022 was $40 million and $43 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.
  (was, 2022-11-22, similarity 0.9759):
[0000858877-22-000025:note_history:52]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of October 29, 2022 and July 30, 2022 was $47 million and $43 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-02-21):
[0000858877-23-000005:note_history:53]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of January 28, 2023 and July 30, 2022 was $40 million and $43 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.
  (was, 2022-11-22, similarity 0.9759):
[0000858877-22-000025:note_history:53]
An allowance for future sales returns is established based on historical trends in product return rates. The allowance for future sales returns as of October 29, 2022 and July 30, 2022 was $47 million and $43 million, respectively, and was recorded as a reduction of our accounts receivable and revenue.

- added (2023-02-21):
[0000858877-23-000005:note_history:54]
|  | Three Months Ended |  | Six Months Ended |
|  | January 28,2023 |  | January 29,2022 |  | January 28, 2023 |  | January 29, 2022 |
| Product revenue: |  |  |  |  |  |  |  |
| Secure, Agile Networks | $ | 6,746 |  |  | $ | 5,899 |  |  | $ | 13,430 |  |  | $ | 11,867 |  |
| Internet for the Future | 1,306 |  |  | 1,322 |  |  | 2,616 |  |  | 2,695 |  |
| Collaboration | 958 |  |  | 1,067 |  |  | 2,044 |  |  | 2,176 |  |
| End-to-End Security | 943 |  |  | 883 |  |  | 1,914 |  |  | 1,778 |  |
| Optimized Application Experiences | 199 |  |  | 180 |  |  | 393 |  |  | 361 |  |
| Other Products | 3 |  |  | 2 |  |  | 4 |  |  | 5 |  |
| Total Product | 10,155 |  |  | 9,353 |  |  | 20,400 |  |  | 18,882 |  |
| Services | 3,437 |  |  | 3,367 |  |  | 6,824 |  |  | 6,738 |  |
| Total | $ | 13,592 |  |  | $ | 12,720 |  |  | $ | 27,224 |  |  | $ | 25,620 |  |

- changed (2023-02-21):
[0000858877-23-000005:note_history:55]
Amounts may not sum due to rounding. We have made certain reclassifications to the product revenue amounts for prior periods to conform to the current year presentation.
  (was, 2022-11-22, similarity 0.997):
[0000858877-22-000025:note_history:55]
Amounts may not sum due to rounding. We have made certain reclassifications to the product revenue amounts for prior period to conform to the current year presentation.

- changed (2023-02-21):
[0000858877-23-000005:note_history:56]
Accounts receivable, net was $5.2 billion as of January 28, 2023 compared to $6.6 billion as of July 30, 2022, as reported on the Consolidated Balance Sheets.
  (was, 2022-11-22, similarity 0.958):
[0000858877-22-000025:note_history:56]
Accounts receivable, net was $5.4 billion as of October 29, 2022 compared to $6.6 billion as of July 30, 2022, as reported on the Consolidated Balance Sheets.

- changed (2023-02-21):
[0000858877-23-000005:note_history:57]
|  | Three Months Ended |  | Six Months Ended |
|  | January 28, 2023 |  | January 29, 2022 |  | January 28, 2023 |  | January 29, 2022 |
| Allowance for credit loss at beginning of period | $ | 88 |  |  | $ | 114 |  |  | $ | 83 |  |  | $ | 109 |  |
| Provisions (benefits) | 3 |  |  | 17 |  |  | 14 |  |  | 36 |  |
| Recoveries (write-offs), net | (5) |  |  | (52) |  |  | (11) |  |  | (66) |  |
| Foreign exchange and other | — |  |  | (9) |  |  | — |  |  | (9) |  |
| Allowance for credit loss at end of period | $ | 86 |  |  | $ | 70 |  |  | $ | 86 |  |  | $ | 70 |  |
  (was, 2022-11-22, similarity 0.6802):
[0000858877-22-000025:note_history:57]
|  | Three Months Ended |
|  | October 29, 2022 |  | October 30, 2021 |
| Allowance for credit loss at beginning of period | $ | 83 |  |  | $ | 109 |  |
| Provisions (benefits) | 11 |  |  | 19 |  |
| Recoveries (write-offs), net | (6) |  |  | (14) |  |
| Allowance for credit loss at end of period | $ | 88 |  |  | $ | 114 |  |

- changed (2023-02-21):
[0000858877-23-000005:note_history:58]
|  | January 28,2023 |  | July 30,2022 |
| 1 to 4 | $ | 355 |  |  | $ | 414 |  |
| 5 to 6 | 984 |  |  | 814 |  |
| 7 and Higher | 82 |  |  | 158 |  |
| Total | $ | 1,421 |  |  | $ | 1,386 |  |
  (was, 2022-11-22, similarity 0.9592):
[0000858877-22-000025:note_history:58]
|  | October 29,2022 |  | July 30,2022 |
| 1 to 4 | $ | 356 |  |  | $ | 414 |  |
| 5 to 6 | 898 |  |  | 814 |  |
| 7 and Higher | 87 |  |  | 158 |  |
| Total | $ | 1,341 |  |  | $ | 1,386 |  |

- changed (2023-02-21):
[0000858877-23-000005:note_history:59]
Contract assets consist of unbilled receivables and are recorded when revenue is recognized in advance of scheduled billings to our customers. These amounts are primarily related to software and service arrangements where transfer of control has occurred but we have not yet invoiced. Our contract assets for these unbilled receivables, net of allowances, was $1.4 billion as of January 28, 2023 and $1.3 billion as of  July 30, 2022, and were included in other current assets and other assets.
  (was, 2022-11-22, similarity 0.9356):
[0000858877-22-000025:note_history:59]
Contract assets consist of unbilled receivables and are recorded when revenue is recognized in advance of scheduled billings to our customers. These amounts are primarily related to software and service arrangements where transfer of control has occurred but we have not yet invoiced. Our contract assets for these unbilled receivables, net of allowances, was $1.3 billion as of each of October 29, 2022 and July 30, 2022, and were included in other current assets and other assets.

- added (2023-02-21):
[0000858877-23-000005:note_history:60]
Contract liabilities consist of deferred revenue. Deferred revenue was $23.9 billion as of January 28, 2023 compared to $23.3 billion as of July 30, 2022. We recognized approximately $3.4 billion and $7.9 billion of revenue during the second quarter and first six months of fiscal 2023 that was included in the deferred revenue balance at July 30, 2022. 
(c)Capitalized Contract Acquisition CostsWe capitalize direct and incremental costs incurred to acquire contracts, primarily sales commissions, for which the associated revenue is expected to be recognized in future periods. We incur these costs in connection with both initial contracts and renewals. These costs are initially deferred and typically amortized over the term of the customer contract which corresponds to the period of benefit. Deferred sales commissions were $1.0 billion as of each of January 28, 2023 and July 30, 2022, and were included in other current assets and other assets. The amortization expense associated with these costs was $201 million and $377 million for the second quarter and first six months of fiscal 2023, respectively, and $147 million and $317 million for the corresponding periods of fiscal 2022, respectively, and was included in sales and marketing expenses.

- removed (2023-02-21):
[0000858877-22-000025:note_history:61]
|  | Three Months Ended |
|  | October 29,2022 |  | October 30,2021 |
| Product revenue: |  |  |  |
| Secure, Agile Networks | $ | 6,684 |  |  | $ | 5,968 |  |
| Internet for the Future | 1,310 |  |  | 1,373 |  |
| Collaboration | 1,086 |  |  | 1,109 |  |
| End-to-End Security | 971 |  |  | 895 |  |
| Optimized Application Experiences | 193 |  |  | 181 |  |
| Other Products | 2 |  |  | 3 |  |
| Total Product | 10,245 |  |  | 9,529 |  |
| Services | 3,387 |  |  | 3,371 |  |
| Total | $ | 13,632 |  |  | $ | 12,900 |  |

- removed (2023-02-21):
[0000858877-22-000025:note_history:62]
Contract liabilities consist of deferred revenue. Deferred revenue was $23.0 billion as of October 29, 2022 compared to $23.3 billion as of July 30, 2022. We recognized approximately $4.4 billion of revenue during the first quarter of fiscal 2023 that was included in the deferred revenue balance at July 30, 2022. 
(c)Capitalized Contract Acquisition CostsWe capitalize direct and incremental costs incurred to acquire contracts, primarily sales commissions, for which the associated revenue is expected to be recognized in future periods. We incur these costs in connection with both initial contracts and renewals. These costs are initially deferred and typically amortized over the term of the customer contract which corresponds to the period of benefit. Deferred sales commissions were $1.1 billion and $1.0 billion as of October 29, 2022 and July 30, 2022, respectively, and were included in other current assets and other assets. The amortization expense associated with these costs was $176 million and $170 million for the first quarter of fiscal 2023 and 2022, respectively, and was included in sales and marketing expenses.
