# CSCO notes — 0000858877-15-000070


## csco:CompensationexpensesrelatedtobusinesscombinationsTableTextBlock

[0000858877-15-000070:notes:1]
The following table summarizes the compensation expense related to acquisitions (in millions):

[0000858877-15-000070:notes:2]
|  | July 25, 2015 |  | July 26, 2014 |  | July 27, 2013 |
| Compensation expense related to acquisitions | $ | 334 |  |  | $ | 607 |  |  | $ | 123 |  |


## csco:ConcentrationOfCreditRiskPolicyTextBlock

[0000858877-15-000070:notes:3]
(n) Concentrations of Risk   Cash and cash equivalents are maintained with several financial institutions. Deposits held with banks may exceed the amount of insurance provided on such deposits. Generally, these deposits may be redeemed upon demand and are maintained with financial institutions with reputable credit and therefore bear minimal credit risk. The Company seeks to mitigate its credit risks by spreading such risks across multiple counterparties and monitoring the risk profiles of these counterparties.

[0000858877-15-000070:notes:4]
The Company performs ongoing credit evaluations of its customers and, with the exception of certain financing transactions, does not require collateral from its customers. The Company receives certain of its components from sole suppliers. Additionally, the Company relies on a limited number of contract manufacturers and suppliers to provide manufacturing services for its products. The inability of a contract manufacturer or supplier to fulfill supply requirements of the Company could materially impact future operating results.


## csco:DepreciationAndAmortizationPeriodByTypeOfAssetTextBlock

[0000858877-15-000070:notes:5]
Depreciation and amortization are computed using the straight-line method, generally over the following periods:

[0000858877-15-000070:notes:6]
| Asset Category |  | Period |
| Buildings |  | 25 years |
| Building improvements |  | 10 years |
| Leasehold improvements |  | Shorter of remaining lease term or up to 10 years |
| Computer equipment and related software |  | 30 to 36 months |
| Production, engineering, and other equipment |  | Up to 5 years |
| Operating lease assets |  | Based on lease term |
| Furniture and fixtures |  | 5 years |


## csco:DescriptionOfNewAccountingPronouncementsNotYetAdoptedPolicyTextBlock

[0000858877-15-000070:notes:7]
(x) Recent Accounting Standards or Updates Not Yet Effective

[0000858877-15-000070:notes:8]
In May 2014, the FASB issued an accounting standard update related to revenue from contracts with customers, which will supersede nearly all current U.S. GAAP guidance on this topic and eliminate industry-specific guidance.  The underlying principle is to recognize revenue when promised goods or services are transferred to customers in an amount that reflects the consideration that is expected to be received for those goods or services.  This accounting standard update, as amended, will be effective for the Company beginning in the first quarter of fiscal 2019.  The new revenue standard may be applied retrospectively to each prior period presented or retrospectively with the cumulative effect recognized as of the date of adoption.  Early adoption is permitted, but no earlier than fiscal 2018.  The Company is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.

[0000858877-15-000070:notes:9]
In February 2015, the FASB issued an accounting standard update that changes the analysis that a reporting entity must perform to determine whether it should consolidate certain types of legal entities. The accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2017, and early adoption is permitted. The Company is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.


## csco:EntityWideDisclosureOnGeographicAreasLongLivedAssetsTableTextBlock

[0000858877-15-000070:notes:10]
Property and equipment information is based on the physical location of the assets. The following table presents property and equipment information for geographic areas (in millions):

[0000858877-15-000070:notes:11]
|  | July 25, 2015 |  | July 26, 2014 |  | July 27, 2013 |
| Property and equipment, net: |  |  |  |  |  |
| United States | $ | 2,733 |  |  | $ | 2,697 |  |  | $ | 2,780 |  |
| International | 599 |  |  | 555 |  |  | 542 |  |
| Total | $ | 3,332 |  |  | $ | 3,252 |  |  | $ | 3,322 |  |


## csco:NetSalesForGroupsOfSimilarProductsAndServicesTableTextBlock

[0000858877-15-000070:notes:12]
The following table presents revenue for groups of similar products and services (in millions):

[0000858877-15-000070:notes:13]
| Years Ended | July 25, 2015 |  | July 26, 2014 |  | July 27, 2013 |
| Revenue: |  |  |  |  |  |
| Switching | $ | 14,741 |  |  | $ | 14,001 |  |  | $ | 14,711 |  |
| NGN Routing | 7,704 |  |  | 7,609 |  |  | 8,168 |  |
| Collaboration | 4,000 |  |  | 3,815 |  |  | 4,057 |  |
| Service Provider Video | 3,555 |  |  | 3,969 |  |  | 4,855 |  |
| Data Center | 3,220 |  |  | 2,640 |  |  | 2,074 |  |
| Wireless | 2,542 |  |  | 2,293 |  |  | 2,257 |  |
| Security | 1,747 |  |  | 1,566 |  |  | 1,348 |  |
| Other | 241 |  |  | 279 |  |  | 559 |  |
| Product | 37,750 |  |  | 36,172 |  |  | 38,029 |  |
| Service | 11,411 |  |  | 10,970 |  |  | 10,578 |  |
| Total | $ | 49,161 |  |  | $ | 47,142 |  |  | $ | 48,607 |  |


## csco:OtherThanTemporaryImpairmentLossesOnInvestmentsPolicyTextBlock

[0000858877-15-000070:notes:14]
(c) Other-than-Temporary Impairments on Investments   When the fair value of a debt security is less than its amortized cost, it is deemed impaired, and the Company will assess whether the impairment is other than temporary. An impairment is considered other than temporary if (i) the Company has the intent to sell the security, (ii) it is more likely than not that the Company will be required to sell the security before recovery of the entire amortized cost basis, or (iii) the Company does not expect to recover the entire amortized cost basis of the security. If impairment is considered other than temporary based on condition (i) or (ii) described earlier, the entire difference between the amortized cost and the fair value of the debt security is recognized in earnings. If an impairment is considered other than temporary based on condition (iii), the amount representing credit losses (defined as the difference between the present value of the cash flows expected to be collected and the amortized cost basis of the debt security) will be recognized in earnings, and the amount relating to all other factors will be recognized in other comprehensive income (OCI).

[0000858877-15-000070:notes:15]
The Company recognizes an impairment charge on publicly traded equity securities when a decline in the fair value of a security below the respective cost basis is judged to be other than temporary. The Company considers various factors in determining whether a decline in the fair value of these investments is other than temporary, including the length of time and extent to which the fair value of the security has been less than the Company’s cost basis, the financial condition and near-term prospects of the issuer, and the Company’s intent and ability to hold the investment for a period of time sufficient to allow for any anticipated recovery in market value.

[0000858877-15-000070:notes:16]
Investments in privately held companies are included in other assets in the Consolidated Balance Sheets and are primarily accounted for using either the cost or equity method. The Company monitors these investments for impairments and makes reductions in carrying values if the Company determines that an impairment charge is required based primarily on the financial condition and near-term prospects of these companies.


## csco:RecentlyAdoptedAccountingStandardsPolicyTextBlock

[0000858877-15-000070:notes:17]
(w) New Accounting Updates Recently Adopted

[0000858877-15-000070:notes:18]
In March 2013, the Financial Accounting Standards Board (FASB) issued an accounting standard update requiring an entity to release into net income the entire amount of a cumulative translation adjustment related to its investment in a foreign entity when as a parent it sells either a part or all of its investment in the foreign entity or no longer holds a controlling financial interest in a subsidiary or group of assets within the foreign entity.  This accounting standard update became effective for the Company beginning in the first quarter of fiscal 2015.  The application of this accounting standard update did not have any impact to the Company's Consolidated Financial Statements.

[0000858877-15-000070:notes:19]
In July 2013, the FASB issued an accounting standard update that provides explicit guidance on the financial statement presentation of an unrecognized tax benefit when a net operating loss carryforward or a tax credit carryforward exists.  Under the new standard update, an unrecognized tax benefit, or a portion of an unrecognized tax benefit, is to be presented in the financial statements as a reduction to a deferred tax asset for a net operating loss carryforward or a tax credit carryforward.  This accounting standard update became effective for the Company beginning in the first quarter of fiscal 2015 and applied prospectively.  The application of this accounting standard update did not have a material impact to the Company's Consolidated Financial Statements.

[0000858877-15-000070:notes:20]
In April 2014, the FASB issued an accounting standard update that changes the criteria for reporting discontinued operations.  This accounting standard update raises the threshold for a disposal transaction to qualify as a discontinued operation and requires additional disclosures about discontinued operations and disposals of individually significant components that do not qualify as discontinued operations.  The Company adopted this accounting standard update in the second quarter of fiscal 2015, and applied the revised criteria for reporting discontinued operations with respect to transactions subsequent to this date.

[0000858877-15-000070:notes:21]
In April 2015, the FASB issued an accounting standard update requiring debt issuance costs related to a recognized debt liability to be presented in the balance sheet as a direct deduction from the carrying amount of that debt, consistent with debt discounts.  In the fourth quarter of 2015, we adopted the accounting standard update, which was reflected in the balance sheet and cash flow statement. The change was applied to all periods presented, and it did not have a material impact on the Company's Consolidated Financial Statements.


## csco:ScheduleOfCommonStockRepurchasedTextBlock

[0000858877-15-000070:notes:22]
A summary of the stock repurchase activity under the stock repurchase program, reported based on the trade date, is summarized as follows (in millions, except per-share amounts):

[0000858877-15-000070:notes:23]
|  | SharesRepurchased |  | Weighted-Average Priceper Share |  | AmountRepurchased |
| Cumulative balance at July 27, 2013 | 3,868 |  |  | $ | 20.40 |  |  | $ | 78,906 |  |
| Repurchase of common stock under the stock repurchase program (1) | 420 |  |  | 22.71 |  |  | 9,539 |  |
| Cumulative balance at July 26, 2014 | 4,288 |  |  | 20.63 |  |  | 88,445 |  |
| Repurchase of common stock under the stock repurchase program (2) | 155 |  |  | 27.22 |  |  | 4,234 |  |
| Cumulative balance at July 25, 2015 | 4,443 |  |  | $ | 20.86 |  |  | $ | 92,679 |  |

[0000858877-15-000070:notes:24]
(1) Includes stock repurchases of $126 million, which were pending settlement as of July 26, 2014.

[0000858877-15-000070:notes:25]
(2) Includes stock repurchases of $36 million, which were pending settlement as of July 25, 2015.


## csco:ScheduleOfDerivativeFairValueHedgeInstrumentsGainLossInStatementOfFinancialPerformanceTableTextBlock

[0000858877-15-000070:notes:26]
The effect on the Consolidated Statements of Operations of derivative instruments designated as fair value hedges and the underlying hedged items is summarized as follows (in millions):

[0000858877-15-000070:notes:27]
|  |  |  |  | GAINS (LOSSES) ONDERIVATIVE INSTRUMENTS FOR THE YEARS ENDED |  | GAINS (LOSSES) RELATED TO HEDGED ITEMS FOR THE YEARS ENDED |
| Derivatives Designated as Fair Value Hedging Instruments |  | Line Item in Statements of Operations |  | July 25, 2015 |  | July 26, 2014 |  | July 27, 2013 |  | July 25, 2015 |  | July 26, 2014 |  | July 27, 2013 |
| Equity derivatives |  | Other income (loss), net |  | $ | 56 |  |  | $ | (72 | ) |  | $ | (155 | ) |  | $ | (56 | ) |  | $ | 72 |  |  | $ | 155 |  |
| Interest rate derivatives |  | Interest expense |  | 54 |  |  | (2 | ) |  | (78 | ) |  | (57 | ) |  | — |  |  | 78 |  |
| Total |  |  |  | $ | 110 |  |  | $ | (74 | ) |  | $ | (233 | ) |  | $ | (113 | ) |  | $ | 72 |  |  | $ | 233 |  |


## csco:ScheduleOfFiniteLivedIntangibleAssetsAmortizationExpenseTableTextBlock

[0000858877-15-000070:notes:28]
The following table presents the amortization of purchased intangible assets (in millions):

[0000858877-15-000070:notes:29]
| Years Ended |  | July 25, 2015 |  | July 26, 2014 |  | July 27, 2013 |
| Amortization of purchased intangible assets: |  |  |  |  |  |  |
| Cost of sales |  | $ | 814 |  |  | $ | 742 |  |  | $ | 606 |  |
| Operating expenses |  | 359 |  |  | 275 |  |  | 395 |  |
| Total |  | $ | 1,173 |  |  | $ | 1,017 |  |  | $ | 1,001 |  |


## csco:ScheduleOfIntangibleAssetsAcquiredAsPartOfBusinessCombinationTextBlock

[0000858877-15-000070:notes:30]
The following tables present details of the Company’s intangible assets acquired through business combinations completed during fiscal 2015 and 2014 (in millions, except years):

[0000858877-15-000070:notes:31]
|  | FINITE LIVES |  | INDEFINITELIVES |  | TOTAL |
|  | TECHNOLOGY |  | CUSTOMERRELATIONSHIPS |  | OTHER |  | IPR&D |  |
| Fiscal 2015 | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Amount |  | Amount |
| Metacloud | 3.0 |  | $ | 24 |  |  | 5.0 |  | $ | 3 |  |  | 0.0 |  | $ | — |  |  | $ | 2 |  |  | $ | 29 |  |
| All others (five in total) | 4.7 |  | 48 |  |  | 7.8 |  | 12 |  |  | 5.8 |  | 6 |  |  | 4 |  |  | 70 |  |
| Total |  |  | $ | 72 |  |  |  |  | $ | 15 |  |  |  |  | $ | 6 |  |  | $ | 6 |  |  | $ | 99 |  |

[0000858877-15-000070:notes:32]
|  | FINITE LIVES |  | INDEFINITELIVES |  | TOTAL |
|  | TECHNOLOGY |  | CUSTOMERRELATIONSHIPS |  | OTHER |  | IPR&D |  |
| Fiscal 2014 | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Amount |  | Amount |
| Composite Software | 6.0 |  | $ | 60 |  |  | 3.9 |  | $ | 14 |  |  | 0.0 |  | $ | — |  |  | $ | 1 |  |  | $ | 75 |  |
| Sourcefire | 7.0 |  | 400 |  |  | 5.0 |  | 129 |  |  | 3.0 |  | 26 |  |  | 22 |  |  | 577 |  |
| WhipTail | 5.0 |  | 63 |  |  | 5.0 |  | 1 |  |  | 2.7 |  | 3 |  |  | 38 |  |  | 105 |  |
| Tail-f | 7.0 |  | 55 |  |  | 6.8 |  | 6 |  |  | 0.0 |  | — |  |  | — |  |  | 61 |  |
| All others (four in total) | 3.6 |  | 18 |  |  | 4.0 |  | 2 |  |  | 0.0 |  | — |  |  | — |  |  | 20 |  |
| Total |  |  | $ | 596 |  |  |  |  | $ | 152 |  |  |  |  | $ | 29 |  |  | $ | 61 |  |  | $ | 838 |  |


## csco:ScheduleOfIntangibleAssetsByMajorClassTextBlock

[0000858877-15-000070:notes:33]
The following tables present details of the Company’s purchased intangible assets (in millions):

[0000858877-15-000070:notes:34]
| July 25, 2015 |  | Gross |  | Accumulated Amortization |  | Net |
| Purchased intangible assets with finite lives: |  |  |  |  |  |  |
| Technology |  | $ | 3,418 |  |  | $ | (1,818 | ) |  | $ | 1,600 |  |
| Customer relationships |  | 1,699 |  |  | (971 | ) |  | 728 |  |
| Other |  | 55 |  |  | (24 | ) |  | 31 |  |
| Total purchased intangible assets with finite lives |  | 5,172 |  |  | (2,813 | ) |  | 2,359 |  |
| In-process research and development, with indefinite lives |  | 17 |  |  | — |  |  | 17 |  |
| Total |  | $ | 5,189 |  |  | $ | (2,813 | ) |  | $ | 2,376 |  |

[0000858877-15-000070:notes:35]
| July 26, 2014 |  | Gross |  | Accumulated Amortization |  | Net |
| Purchased intangible assets with finite lives: |  |  |  |  |  |  |
| Technology |  | $ | 4,100 |  |  | $ | (1,976 | ) |  | $ | 2,124 |  |
| Customer relationships |  | 1,706 |  |  | (720 | ) |  | 986 |  |
| Other |  | 51 |  |  | (13 | ) |  | 38 |  |
| Total purchased intangible assets with finite lives |  | 5,857 |  |  | (2,709 | ) |  | 3,148 |  |
| In-process research and development, with indefinite lives |  | 132 |  |  | — |  |  | 132 |  |
| Total |  | $ | 5,989 |  |  | $ | (2,709 | ) |  | $ | 3,280 |  |


## csco:SegmentReportingProductAndServicesNetSalesTextBlock

[0000858877-15-000070:notes:36]
| 17. | Segment Information and Major Customers |

[0000858877-15-000070:notes:37]
| (a) | Revenue and Gross Margin by Segment |

[0000858877-15-000070:notes:38]
The Company conducts business globally and is primarily managed on a geographic basis consisting of three segments: the Americas, EMEA, and APJC. The Company’s management makes financial decisions and allocates resources based on the information it receives from its internal management system. Sales are attributed to a segment based on the ordering location of the customer. The Company does not allocate research and development, sales and marketing, or general and administrative expenses to its segments in this internal management system because management does not include the information in its measurement of the performance of the operating segments. In addition, the Company does not allocate amortization and impairment of acquisition-related intangible assets, share-based compensation expense, significant litigation and other contingencies, impacts to cost of sales from purchase accounting adjustments to inventory, charges related to asset impairments and restructurings, and certain other charges to the gross margin for each segment because management does not include this information in its measurement of the performance of the operating segments.

[0000858877-15-000070:notes:39]
Summarized financial information by segment for fiscal 2015, 2014, and 2013, based on the Company’s internal management system and as utilized by the Company’s Chief Operating Decision Maker (“CODM”), is as follows (in millions):

[0000858877-15-000070:notes:40]
| Years Ended | July 25, 2015 |  | July 26, 2014 |  | July 27, 2013 |
| Revenue: |  |  |  |  |  |
| Americas | $ | 29,655 |  |  | $ | 27,781 |  |  | $ | 28,639 |  |
| EMEA | 12,322 |  |  | 12,006 |  |  | 12,210 |  |
| APJC | 7,184 |  |  | 7,355 |  |  | 7,758 |  |
| Total | $ | 49,161 |  |  | $ | 47,142 |  |  | $ | 48,607 |  |
| Gross margin: |  |  |  |  |  |
| Americas | $ | 18,670 |  |  | $ | 17,379 |  |  | $ | 17,887 |  |
| EMEA | 7,705 |  |  | 7,700 |  |  | 7,876 |  |
| APJC | 4,307 |  |  | 4,252 |  |  | 4,637 |  |
| Segment total | 30,682 |  |  | 29,331 |  |  | 30,400 |  |
| Unallocated corporate items | (1,001 | ) |  | (1,562 | ) |  | (960 | ) |
| Total | $ | 29,681 |  |  | $ | 27,769 |  |  | $ | 29,440 |  |

[0000858877-15-000070:notes:41]
Revenue in the United States was $26.0 billion, $24.3 billion, and $24.6 billion for fiscal 2015, 2014, and 2013, respectively.

[0000858877-15-000070:notes:42]
| (b) | Revenue for Groups of Similar Products and Services |

[0000858877-15-000070:notes:43]
The Company designs, manufactures, and sells Internet Protocol (IP)-based networking and other products related to the communications and IT industry and provides services associated with these products and their use. The Company groups its products and technologies into the following categories: Switching, NGN Routing, Collaboration, Service Provider Video,  Data Center, Wireless, Security, and Other Products. These products, primarily integrated by Cisco IOS Software, link geographically dispersed local-area networks (LANs), metropolitan-area networks (MANs), and wide-area networks (WANs).

[0000858877-15-000070:notes:44]
The Company has made certain reclassifications to the product revenue amounts for prior years to conform to the current year’s presentation.

[0000858877-15-000070:notes:45]
| (c) | Additional Segment Information |

[0000858877-15-000070:notes:46]
The majority of the Company’s assets, excluding cash and cash equivalents and investments, as of July 25, 2015 and July 26, 2014 was attributable to its U.S. operations. The Company’s total cash and cash equivalents and investments held by various foreign subsidiaries were $53.4 billion and $47.4 billion as of July 25, 2015 and July 26, 2014, respectively, and the remaining $7.0 billion and $4.7 billion at the respective fiscal year ends were available in the United States.  In fiscal 2015, 2014, and 2013, no single customer accounted for 10% or more of the Company’s revenue.


## csco:StockRepurchasesSinceInceptionOfProgramTableTextBlock

[0000858877-15-000070:notes:47]
The stock repurchases since the inception of this program and the related impacts on Cisco shareholders’ equity are summarized in the following table (in millions):

[0000858877-15-000070:notes:48]
|  | Shares ofCommonStock |  | Common Stockand AdditionalPaid-In Capital |  | RetainedEarnings |  | Total CiscoShareholders’Equity |
| Repurchases of common stock under the repurchase program | 4,443 |  |  | $ | 22,615 |  |  | $ | 70,064 |  |  | $ | 92,679 |  |


## us-gaap:AdvertisingCostsPolicyTextBlock

[0000858877-15-000070:notes:49]
(p) Advertising Costs   The Company expenses all advertising costs as incurred. Advertising costs included within sales and marketing expenses were approximately $202 million, $196 million, and $218 million for fiscal 2015, 2014, and 2013, respectively.


## us-gaap:AllowanceForCreditLossesOnFinancingReceivablesTableTextBlock

[0000858877-15-000070:notes:50]
The allowances for credit loss and the related financing receivables are summarized as follows (in millions):

[0000858877-15-000070:notes:51]
|  | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts and Other |  | Total |
| Allowance for credit loss as of July 26, 2014 | $ | 233 |  |  | $ | 98 |  |  | $ | 18 |  |  | $ | 349 |  |
| Provisions | 45 |  |  | (8 | ) |  | 20 |  |  | 57 |  |
| Recoveries (write-offs), net | (7 | ) |  | 1 |  |  | (1 | ) |  | (7 | ) |
| Foreign exchange and other | (12 | ) |  | (4 | ) |  | (1 | ) |  | (17 | ) |
| Allowance for credit loss as of July 25, 2015 | $ | 259 |  |  | $ | 87 |  |  | $ | 36 |  |  | $ | 382 |  |
| Financing receivables as of July 25, 2015 (1) | $ | 3,395 |  |  | $ | 1,763 |  |  | $ | 3,573 |  |  | $ | 8,731 |  |

[0000858877-15-000070:notes:52]
|  | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts and Other |  | Total |
| Allowance for credit loss as of July 27, 2013 | $ | 238 |  |  | $ | 86 |  |  | $ | 20 |  |  | $ | 344 |  |
| Provisions | 4 |  |  | 9 |  |  | 1 |  |  | 14 |  |
| Recoveries (write-offs), net | (11 | ) |  | 5 |  |  | (3 | ) |  | (9 | ) |
| Foreign exchange and other | 2 |  |  | (2 | ) |  | — |  |  | — |  |
| Allowance for credit loss as of July 26, 2014 | $ | 233 |  |  | $ | 98 |  |  | $ | 18 |  |  | $ | 349 |  |
| Financing receivables as of July 26, 2014 (1) | $ | 3,527 |  |  | $ | 1,683 |  |  | $ | 3,210 |  |  | $ | 8,420 |  |

[0000858877-15-000070:notes:53]
|  | CREDIT LOSS ALLOWANCES |
|  | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts and Other |  | Total |
| Allowance for credit loss as of July 28, 2012 | $ | 247 |  |  | $ | 122 |  |  | $ | 11 |  |  | $ | 380 |  |
| Provisions | 21 |  |  | (20 | ) |  | 10 |  |  | 11 |  |
| Recoveries (write-offs), net | (30 | ) |  | (15 | ) |  | (1 | ) |  | (46 | ) |
| Foreign exchange and other | — |  |  | (1 | ) |  | — |  |  | (1 | ) |
| Allowance for credit loss as of July 27, 2013 | $ | 238 |  |  | $ | 86 |  |  | $ | 20 |  |  | $ | 344 |  |
| Financing receivables as of July 27, 2013 (1) | $ | 3,507 |  |  | $ | 1,649 |  |  | $ | 3,136 |  |  | $ | 8,292 |  |

[0000858877-15-000070:notes:54]
(1) Total financing receivables before allowance for credit loss.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000858877-15-000070:notes:55]
| 3. | Acquisitions and Divestitures |

[0000858877-15-000070:notes:56]
| (a) | Acquisition Summary |

[0000858877-15-000070:notes:57]
The Company completed six business combinations during fiscal 2015.  A summary of the allocation of the total purchase consideration is presented as follows (in millions):

[0000858877-15-000070:notes:58]
| Fiscal 2015 | Purchase Consideration |  | Net Liabilities Assumed |  | Purchased Intangible Assets |  | Goodwill |
| Metacloud | $ | 149 |  |  | $ | (7 | ) |  | $ | 29 |  |  | $ | 127 |  |
| All others (five in total) | 185 |  |  | (13 | ) |  | 70 |  |  | 128 |  |
| Total acquisitions | $ | 334 |  |  | $ | (20 | ) |  | $ | 99 |  |  | $ | 255 |  |

[0000858877-15-000070:notes:59]
On September 29, 2014, the Company completed its acquisition of Metacloud, Inc. ("Metacloud"), a provider of private clouds for global organizations.  With its acquisition of Metacloud, the Company aims to advance its Intercloud strategy to deliver a globally distributed, highly secure cloud platform.  Revenue from the Metacloud acquisition has been included in the Company's Service category.

[0000858877-15-000070:notes:60]
The total purchase consideration related to the Company’s business combinations completed during fiscal 2015 consisted of cash consideration and vested share-based awards assumed.  The total cash and cash equivalents acquired from these business combinations was approximately $5 million.

[0000858877-15-000070:notes:61]
Fiscal 2014 and 2013 Business Combinations

[0000858877-15-000070:notes:62]
Allocation of the purchase consideration for business combinations completed in fiscal 2014 is summarized as follows (in millions):

[0000858877-15-000070:notes:63]
| Fiscal 2014 | Purchase Consideration |  | Net Tangible Assets Acquired (Liabilities Assumed) |  | Purchased Intangible Assets |  | Goodwill |
| Composite Software | $ | 160 |  |  | $ | (10 | ) |  | $ | 75 |  |  | $ | 95 |  |
| Sourcefire | 2,449 |  |  | 81 |  |  | 577 |  |  | 1,791 |  |
| WhipTail | 351 |  |  | (34 | ) |  | 105 |  |  | 280 |  |
| Tail-f | 167 |  |  | (7 | ) |  | 61 |  |  | 113 |  |
| All others (four in total) | 54 |  |  | (5 | ) |  | 20 |  |  | 39 |  |
| Total acquisitions | $ | 3,181 |  |  | $ | 25 |  |  | $ | 838 |  |  | $ | 2,318 |  |

[0000858877-15-000070:notes:64]
The Company acquired privately held Composite Software, Inc. (“Composite Software”) in the first quarter of fiscal 2014.  Prior to its acquisition, Composite Software provided data virtualization software and services that connect many types of data from across the network and make it appear as if the data is in one place.  With its acquisition of Composite Software, the Company intends to extend its next-generation services platform by connecting data and infrastructure.  The Company has included revenue from the Composite Software acquisition, subsequent to the acquisition date, in the Company's Service category.

[0000858877-15-000070:notes:65]
The Company acquired Sourcefire, Inc. (“Sourcefire”) in the first quarter of fiscal 2014.  Prior to its acquisition, Sourcefire delivered innovative, highly automated security through continuous awareness, threat detection, and protection across its portfolio, including next-generation intrusion prevention systems, next-generation firewalls, and advanced malware protection.  With its acquisition of Sourcefire, the Company aims to accelerate its security strategy of defending, discovering, and remediating advanced threats to provide continuous security solutions to the Company’s customers in more places across the network.  The Company has included revenue from the Sourcefire acquisition in its Security product category.

[0000858877-15-000070:notes:66]
The Company acquired privately held WhipTail Technologies, Inc. (“WhipTail”) in the second quarter of fiscal 2014.  Prior to its acquisition, WhipTail was a provider of high-performance, scalable solid state memory systems. In the fourth quarter of fiscal 2015, the Company announced the end-of-sale and end-of-life dates for the Cisco UCS Invicta Series in connection with the decision to shut down the WhipTail unit.

[0000858877-15-000070:notes:67]
The Company acquired privately held Tail-f Systems AB ("Tail-f") in the fourth quarter of fiscal 2014.  Prior to its acquisitions, Tail-f was a provider of multi-vendor network service orchestration solutions for traditional and virtualized networks.  With its acquisition of Tail-f, the Company intends to advance its cloud virtualization strategy.  The Company has included revenue from the Tail-f acquisition in the Company's cloud and virtualization offerings within the Other products.

[0000858877-15-000070:notes:68]
The total purchase consideration related to the Company’s business combinations completed during fiscal 2014 consisted of cash consideration and vested share-based awards assumed.  The total cash and cash equivalents acquired from these business combinations was approximately $134 million.

[0000858877-15-000070:notes:69]
Allocation of the purchase consideration for business combinations completed in fiscal 2013 is summarized as follows (in millions):

[0000858877-15-000070:notes:70]
| Fiscal 2013 | Purchase Consideration |  | Net Liabilities Assumed |  | Purchased Intangible Assets |  | Goodwill |
| NDS | $ | 5,005 |  |  | $ | (185 | ) |  | $ | 1,746 |  |  | $ | 3,444 |  |
| Meraki | 974 |  |  | (59 | ) |  | 289 |  |  | 744 |  |
| Intucell | 360 |  |  | (23 | ) |  | 106 |  |  | 277 |  |
| Ubiquisys | 280 |  |  | (30 | ) |  | 123 |  |  | 187 |  |
| All others (nine in total) | 363 |  |  | (25 | ) |  | 127 |  |  | 261 |  |
| Total acquisitions | $ | 6,982 |  |  | $ | (322 | ) |  | $ | 2,391 |  |  | $ | 4,913 |  |

[0000858877-15-000070:notes:71]
The Company completed its acquisition of NDS Group Limited (“NDS”) in the first quarter of fiscal 2013.  Prior to its acquisition, NDS was a provider of video software and content security solutions that enable service providers and media companies to securely deliver and monetize new video entertainment experiences. With the acquisition of NDS,  the Company enhances its comprehensive content delivery platform that enables service providers and media companies to deliver next-generation entertainment experiences.  The Company has included revenue from the NDS acquisition, subsequent to the acquisition date, in its Service Provider Video product category.

[0000858877-15-000070:notes:72]
The Company acquired privately held Meraki, Inc. (“Meraki”) in the second quarter of fiscal 2013. Prior to its acquisition, Meraki offered mid-market customers on-premise networking solutions centrally managed from the cloud. With its acquisition of Meraki, the Company addresses the shift to cloud networking as a key part of the Company’s overall strategy to accelerate the adoption of software-based business models that provide new consumption options for customers and revenue opportunities for partners.   The Company has included revenue from the Meraki acquisition, subsequent to the acquisition date, in its Wireless product category.

[0000858877-15-000070:notes:73]
The Company acquired privately held Intucell, Ltd. (“Intucell”) in the third quarter of fiscal 2013. Prior to its acquisition, Intucell provided advanced self-optimizing network software for mobile carriers. With its acquisition of Intucell, the Company enhances its commitment to global service providers by adding a critical network intelligence layer to manage and optimize spectrum, coverage, and capacity, and ultimately the quality of the mobile experience. The Company has included revenue from the Intucell acquisition, subsequent to the acquisition date, in its NGN Routing product category.

[0000858877-15-000070:notes:74]
The Company acquired privately held Ubiquisys Limited (“Ubiquisys”) in the fourth quarter of fiscal 2013. Prior to its acquisition, Ubiquisys offered service providers intelligent 3G and long-term evolution (LTE) small-cell technologies for seamless connectivity across mobile networks. With its acquisition of Ubiquisys, the Company strengthens its commitment to global service providers by enabling a comprehensive small-cell solution that supports the transition to next-generation radio access networks. The Company has included revenue from the Ubiquisys acquisition, subsequent to the acquisition date, in its NGN Routing product category.

[0000858877-15-000070:notes:75]
The total purchase consideration related to the Company’s business combinations completed during fiscal 2013 consisted of cash consideration and vested share-based awards assumed. The total cash and cash equivalents acquired from these business combinations was approximately $156 million.

[0000858877-15-000070:notes:76]
| (b) | Pending Acquisitions and Divestitures |

[0000858877-15-000070:notes:77]
Acquisition of OpenDNS  On August 26, 2015, the Company completed its acquisition of privately held OpenDNS, Inc. ("OpenDNS").  Under the terms of the agreement, the Company paid approximately $635 million in cash and share-based awards assumed to acquire OpenDNS. OpenDNS provides advanced threat protection for endpoint devices. With the OpenDNS acquisition, the Company aims to strengthen its security offerings by adding broad visibility and threat intelligence delivered through a software-as-a-service platform.  Revenue from the OpenDNS acquisition will be included in the Company's Security product category. The Company expects that most of the purchase price will be allocated to goodwill and purchased intangible assets.

[0000858877-15-000070:notes:78]
Pending Divestiture  On July 22, 2015, the Company entered into an exclusive agreement to sell the client premises equipment portion of its Service Provider Video connected devices business unit to French-based Technicolor for approximately $600 million in cash and stock subject to certain adjustments provided for in the agreement.  In connection with this transaction, the Company had tangible assets of approximately $190 million which were held for sale (of which the most significant component is inventories of approximately $160 million), and current liabilities of approximately $125 million (primarily comprised of supply chain-related liabilities, warranties, rebates and other accrued liabilities), which were held for sale. The Company estimates that approximately $150 million of goodwill is attributable to this business, based on its relative fair value.  The Company expects the transaction to close at the end of the second quarter of fiscal 2016, subject to customary closing conditions, including regulatory approvals.

[0000858877-15-000070:notes:79]
| (c) | Other Acquisition and Divestiture Information |

[0000858877-15-000070:notes:80]
Total transaction costs related to the Company’s acquisitions during fiscal 2015, 2014, and 2013 were $10 million, $7 million, and $40 million, respectively. These transaction costs were expensed as incurred in general and administrative (G&A) expenses in the Consolidated Statements of Operations.

[0000858877-15-000070:notes:81]
The Company’s purchase price allocation for acquisitions completed during recent periods are preliminary and subject to revision as additional information about fair value of assets and liabilities becomes available. Additional information, which existed as of the acquisition date but at that time was unknown to the Company, may become known to the Company during the remainder of the measurement period, a period not to exceed 12 months from the acquisition date. Adjustments in the purchase price allocation may require a recasting of the amounts allocated to goodwill retroactive to the period in which the acquisition occurred.

[0000858877-15-000070:notes:82]
The goodwill generated from the Company’s acquisitions completed during fiscal 2015 is primarily related to expected synergies. The goodwill is generally not deductible for income tax purposes.

[0000858877-15-000070:notes:83]
The Consolidated Financial Statements include the operating results of each acquisition from the date of acquisition. Pro forma results of operations for the acquisitions completed during the fiscal years presented have not been presented because the effects of the acquisitions, individually and in the aggregate, were not material to the Company’s financial results.

[0000858877-15-000070:notes:84]
During the third quarter of fiscal 2013, the Company completed the sale of its Linksys product line to a third party. The financial statement impact of the Company’s Linksys product line and its resulting sale were not material for any of the fiscal years presented.


## us-gaap:BusinessCombinationsAndOtherPurchaseOfBusinessTransactionsPolicyTextBlock

[0000858877-15-000070:notes:85]
(h) Business Combinations The Company allocates the fair value of the purchase consideration of its acquisitions to the tangible assets, liabilities, and intangible assets acquired, including in-process research and development (IPR&D), based on their estimated fair values. The excess of the fair value of purchase consideration over the fair values of these identifiable assets and liabilities is recorded as goodwill. IPR&D is initially capitalized at fair value as an intangible asset with an indefinite life and assessed for impairment thereafter. When an IPR&D project is completed, the IPR&D is reclassified as an amortizable purchased intangible asset and amortized over the asset’s estimated useful life. Acquisition-related expenses and related restructuring costs are recognized separately from the business combination and are expensed as incurred.


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0000858877-15-000070:notes:86]
(a) Cash and Cash Equivalents   The Company considers all highly liquid investments purchased with an original or remaining maturity of three months or less at the date of purchase to be cash equivalents. Cash and cash equivalents are maintained with various financial institutions.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000858877-15-000070:notes:87]
| 12. | Commitments and Contingencies |

[0000858877-15-000070:notes:88]
| (a) | Operating Leases |

[0000858877-15-000070:notes:89]
The Company leases office space in many U.S. locations. Outside the United States, larger leased sites include sites in Belgium, Canada, China, France, Germany, India, Israel, Japan, Poland and the United Kingdom.  The Company also leases equipment and vehicles. Future minimum lease payments under all noncancelable operating leases with an initial term in excess of one year as of July 25, 2015 are as follows (in millions):

[0000858877-15-000070:notes:90]
| Fiscal Year | Amount |
| 2016 | $ | 346 |  |
| 2017 | 254 |  |
| 2018 | 181 |  |
| 2019 | 99 |  |
| 2020 | 79 |  |
| Thereafter | 183 |  |
| Total | $ | 1,142 |  |

[0000858877-15-000070:notes:91]
Rent expense for office space and equipment totaled $394 million, $413 million, and $416 million in fiscal 2015, 2014, and 2013, respectively.

[0000858877-15-000070:notes:92]
| (b) | Purchase Commitments with Contract Manufacturers and Suppliers |

[0000858877-15-000070:notes:93]
The Company purchases components from a variety of suppliers and uses several contract manufacturers to provide manufacturing services for its products.  During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, the Company enters into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by the Company or establish the parameters defining the Company’s requirements.  A significant portion of the Company’s reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments.  In certain instances, these agreements allow the Company the option to cancel, reschedule, and adjust the Company’s requirements based on its business needs prior to firm orders being placed. As of July 25, 2015 and July 26, 2014, the Company had total purchase commitments for inventory of $4,078 million and $4,169 million, respectively.

[0000858877-15-000070:notes:94]
The Company records a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of its future demand forecasts consistent with the valuation of the Company’s excess and obsolete inventory.  As of July 25, 2015 and July 26, 2014, the liability for these purchase commitments was $156 million and $162 million, respectively, and was included in other current liabilities.

[0000858877-15-000070:notes:95]
| (c) | Other Commitments |

[0000858877-15-000070:notes:96]
In connection with the Company’s business combinations, the Company has agreed to pay certain additional amounts contingent upon the achievement of certain agreed-upon technology, development, product, or other milestones or upon the continued employment with the Company of certain employees of the acquired entities.

[0000858877-15-000070:notes:97]
As of July 25, 2015, the Company estimated that future cash compensation expense of up to $296 million may be required to be recognized pursuant to the applicable business combination agreements, which included the remaining potential compensation expense related to Insieme Networks, Inc., as more fully discussed immediately below.

[0000858877-15-000070:notes:98]
Insieme Networks, Inc.    In the third quarter of fiscal 2012, the Company made an investment in Insieme Networks, Inc. ("Insieme"), an early stage company focused on research and development in the data center market.  As set forth in the agreement between the Company and Insieme, this investment included $100 million of funding and a license to certain of the Company’s technology.  Immediately prior to the call option exercise and acquisition described below, the Company owned approximately 83% of Insieme as a result of these investments and consolidated the results of Insieme in its Consolidated Financial Statements.  In connection with this investment, the Company and Insieme entered into a put/call option agreement that provided the Company with the right to purchase the remaining interests in Insieme.  In addition, the noncontrolling interest holders could require the Company to purchase their shares upon the occurrence of certain events.

[0000858877-15-000070:notes:99]
During the first quarter of fiscal 2014, the Company exercised its call option and entered into an agreement to purchase the remaining interests in Insieme.  The acquisition closed in the second quarter of fiscal 2014, at which time the former noncontrolling interest holders became eligible to receive up to two milestone payments, which will be determined using agreed-upon formulas based primarily on revenue for certain of Insieme’s products. The Company recorded compensation expense of $207 million and $416 million during fiscal 2015 and 2014, respectively, related to the fair value of the vested portion of amounts that were earned or expected to be earned by the former noncontrolling interest holders.  Continued vesting and changes to the fair value of the amounts probable of being earned will result in adjustments to the recorded compensation expense in future periods.  Based on the terms of the agreement, the Company has determined that the maximum amount that could be recorded as compensation expense by the Company is approximately $843 million (which includes the $623 million that has been expensed to date), net of forfeitures.  The milestone payments, to the extent earned, are expected to be paid primarily during the first half of each of fiscal 2016 and fiscal 2017.

[0000858877-15-000070:notes:100]
The Company also has certain funding commitments, primarily related to its investments in privately held companies and venture funds, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $205 million and $255 million as of July 25, 2015 and July 26, 2014, respectively.

[0000858877-15-000070:notes:101]
| (d) | Product Warranties |

[0000858877-15-000070:notes:102]
The following table summarizes the activity related to the product warranty liability (in millions):

[0000858877-15-000070:notes:103]
|  | July 25, 2015 |  | July 26, 2014 |  | July 27, 2013 |
| Balance at beginning of fiscal year | $ | 446 |  |  | $ | 402 |  |  | $ | 373 |  |
| Provision for warranties issued | 696 |  |  | 704 |  |  | 649 |  |
| Payments | (693 | ) |  | (660 | ) |  | (620 | ) |
| Balance at end of fiscal year | $ | 449 |  |  | $ | 446 |  |  | $ | 402 |  |

[0000858877-15-000070:notes:104]
The Company accrues for warranty costs as part of its cost of sales based on associated material product costs, labor costs for technical support staff, and associated overhead. The Company’s products are generally covered by a warranty for periods ranging from 90 days to five years, and for some products the Company provides a limited lifetime warranty.

[0000858877-15-000070:notes:105]
| (e) | Financing and Other Guarantees |

[0000858877-15-000070:notes:106]
In the ordinary course of business, the Company provides financing guarantees for various third-party financing arrangements extended to channel partners and end-user customers. Payments under these financing guarantee arrangements were not material for the periods presented.

[0000858877-15-000070:notes:107]
Channel Partner Financing Guarantees   The Company facilitates arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, generally with payment terms ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, the Company guarantees a portion of these arrangements. The volume of channel partner financing was $25.9 billion, $24.6 billion, and $23.8 billion in fiscal 2015, 2014, and 2013, respectively. The balance of the channel partner financing subject to guarantees was $1.2 billion as of each of July 25, 2015 and July 26, 2014.

[0000858877-15-000070:notes:108]
End-User Financing Guarantees   The Company also provides financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. The volume of financing provided by third parties for leases and loans as to which the Company had provided guarantees was $107 million, $129 million, and $185 million in fiscal 2015, 2014, and 2013, respectively.

[0000858877-15-000070:notes:109]
Financing Guarantee Summary   The aggregate amounts of financing guarantees outstanding at July 25, 2015 and July 26, 2014, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

[0000858877-15-000070:notes:110]
|  | July 25, 2015 |  | July 26, 2014 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 288 |  |  | $ | 263 |  |
| End user | 129 |  |  | 202 |  |
| Total | $ | 417 |  |  | $ | 465 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (127 | ) |  | $ | (127 | ) |
| End user | (107 | ) |  | (166 | ) |
| Total | $ | (234 | ) |  | $ | (293 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue | $ | 183 |  |  | $ | 172 |  |

[0000858877-15-000070:notes:111]
Other Guarantees   The Company’s other guarantee arrangements as of July 25, 2015 and July 26, 2014 that were subject to recognition and disclosure requirements were not material.

[0000858877-15-000070:notes:112]
| (f) | Supplier Component Remediation Liability |

[0000858877-15-000070:notes:113]
The Company has recorded in other current liabilities a liability for the expected remediation cost for certain products sold in prior fiscal years containing memory components manufactured by a single supplier between 2005 and 2010. These components were widely used across the industry and are included in a number of the Company's products. Defects in some of these components have caused products to fail after a power cycle event.  Defect rates due to this issue have been and are expected to be low. However, the Company has seen a small number of its customers experience a growing number of failures in their networks as a result of this component problem. Although the majority of these products was beyond the Company's warranty terms, the Company has been proactively working with customers on mitigation.  Prior to the second quarter of fiscal 2014, the Company had a liability of $63 million related to this issue for expected remediation costs based on the intended approach at that time. In February 2014, on the basis of the growing number of failures described above, the Company decided to expand its approach, which resulted in a charge to product cost of sales of $655 million being recorded for the second quarter of fiscal 2014.  During the third quarter of fiscal 2015, an adjustment to product cost of sales of $164 million was recorded to reduce the liability, reflecting   net lower than previously estimated future costs to remediate the impacted customer products.  The supplier component remediation liability was $408 million and $670 million as of July 25, 2015 and July 26, 2014, respectively.

[0000858877-15-000070:notes:114]
| (g) | Indemnifications |

[0000858877-15-000070:notes:115]
In the normal course of business, the Company indemnifies other parties, including customers, lessors, and parties to other transactions with the Company, with respect to certain matters. The Company has agreed to hold such parties harmless against losses arising from a breach of representations or covenants or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim.

[0000858877-15-000070:notes:116]
The Company has an obligation to indemnify certain expenses pursuant to such an agreement in, among other cases, cases involving certain of the Company’s service provider customers that are subject to patent infringement claims asserted by Sprint Communications Company, L.P. (“Sprint”) in the U.S. District Court for the District of Kansas filed on December 19, 2011 (including one case that was later transferred to the District of Delaware).  Sprint alleges that the service provider customers infringe Sprint’s patents by offering Voice over Internet Protocol-based telephone services utilizing products provided by the Company and other manufacturers.  Sprint seeks monetary damages.  Sprint’s cases in Kansas include claims against Comcast and Time Warner Cable, service provider customers of the Company.  Although trial dates were originally set for the first half of calendar year 2016 in the case proceeding in the District of Kansas, at the request of Sprint and Comcast, the judge in Sprint’s Kansas action ordered a six-month stay of the patent litigation between those parties for them to pursue a resolution of their dispute. In addition, on May 15, 2015 the judge in Sprint's Delaware action against the Company’s service provider customer Cox Communications (“Cox”) granted defendant Cox’s motion for partial summary judgment that six patents owned by Sprint are invalid.  Cox then asked the judge to enter a final judgment on those six patents in order to conclude the district court proceedings on those patents and to allow the parties to pursue any appeals.   In May 2015, the Company filed two declaratory judgment actions against Sprint seeking declarations that the patents Sprint asserted against the Company’s customers are invalid and/or not infringed.  On August 27, 2015 the judge in Delaware granted Cox’s request and entered a final judgment of invalidity on those six patents; the Company expects Sprint to pursue an appeal.

[0000858877-15-000070:notes:117]
The Company believes that the service providers have strong defenses and that its products do not infringe the patents subject to the claims and/or that the remaining patents are invalid.  Due to the uncertainty surrounding the litigation process, which involves numerous defendants, the Company is unable to reasonably estimate the ultimate outcome of this litigation at this time.  Should the plaintiff prevail in litigation, mediation, or settlement, the Company, in accordance with its agreement, may have an obligation to indemnify its service provider customers for damages, mediation awards, or settlement amounts arising from their use of Cisco products.

[0000858877-15-000070:notes:118]
In addition, the Company has entered into indemnification agreements with its officers and directors, and the Company’s Amended and Restated Bylaws contain similar indemnification obligations to the Company’s agents.

[0000858877-15-000070:notes:119]
It is not possible to determine the maximum potential amount under these indemnification agreements due to the Company’s limited history with prior indemnification claims and the unique facts and circumstances involved in each particular agreement. Historically, payments made by the Company under these agreements have not had a material effect on the Company’s operating results, financial position, or cash flows.

[0000858877-15-000070:notes:120]
| (h) | Legal Proceedings |

[0000858877-15-000070:notes:121]
Brazil    Brazilian authorities have investigated the Company’s Brazilian subsidiary and certain of its current and former employees, as well as a Brazilian importer of the Company’s products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against the Company’s Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years. In the first quarter of fiscal 2013, the Brazilian federal tax authorities asserted an additional claim against the Company’s Brazilian subsidiary based on a theory of joint liability with respect to an alleged underpayment of income taxes, social taxes, interest, and penalties by a Brazilian distributor.

[0000858877-15-000070:notes:122]
The asserted claims by Brazilian federal tax authorities are for calendar years 2003 through 2008, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to approximately $262 million for the alleged evasion of import and other taxes, approximately $1.1 billion for interest, and approximately $1.2 billion for various penalties, all determined using an exchange rate as of July 25, 2015. The Company has completed a thorough review of the matters and believes the asserted claims against the Company’s Brazilian subsidiary are without merit, and the Company is defending the claims vigorously. While the Company believes there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, the Company is unable to determine the likelihood of an unfavorable outcome against its Brazilian subsidiary and is unable to reasonably estimate a range of loss, if any. The Company does not expect a final judicial determination for several years.

[0000858877-15-000070:notes:123]
Russia and the Commonwealth of Independent States    At the request of the U.S. Securities and Exchange Commission (SEC) and the U.S. Department of Justice, the Company is conducting an investigation into allegations that the Company and those agencies received regarding possible violations of the U.S. Foreign Corrupt Practices Act involving business activities of the Company's operations in Russia and certain of the Commonwealth of Independent States, and by certain resellers of the Company’s products in those countries.  The Company takes any such allegations very seriously and is fully cooperating with and sharing the results of its investigation with the SEC and the Department of Justice.  While the outcome of the Company's investigation is currently not determinable, the Company does not expect that it will have a material adverse effect on its consolidated financial position, results of operations, or cash flows. The countries that are the subject of the investigation collectively comprise less than 2% of the Company’s revenues.

[0000858877-15-000070:notes:124]
In addition, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, the Company does not expect that the ultimate costs to resolve these matters will have a material adverse effect on its consolidated financial position, results of operations, or cash flows.


## us-gaap:CompensationRelatedCostsPolicyTextBlock

[0000858877-15-000070:notes:125]
(q) Share-Based Compensation Expense   The Company measures and recognizes the compensation expense for all share-based awards made to employees and directors, including employee stock options, restricted stock units (RSUs), performance-based restricted stock units (PRSUs), and employee stock purchases related to the Employee Stock Purchase Plan (“Employee Stock Purchase Rights”) based on estimated fair values. The fair value of employee stock options is estimated on the date of grant using a lattice-binomial option-pricing model (“Lattice-Binomial Model”) or the Black-Scholes model, and for employee stock purchase rights the Company estimates the fair value using the Black-Scholes model. The fair value for time-based stock awards and stock awards that are contingent upon the achievement of financial performance metrics is based on the grant date share price reduced by the present value of the expected dividend yield prior to vesting. The fair value of market-based stock awards is estimated using an option-pricing model on the date of grant. Share-based compensation expense is reduced for forfeitures.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000858877-15-000070:notes:126]
| 15. | Comprehensive Income |

[0000858877-15-000070:notes:127]
The components of AOCI, net of tax, and the other comprehensive income (loss), excluding noncontrolling interest, are summarized as follows (in millions):

[0000858877-15-000070:notes:128]
|  | Net Unrealized Gains on Available-for-Sale Investments |  | Net Unrealized Gains (Losses) Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Actuarial Gains and Losses |  | Accumulated Other Comprehensive Income |
| BALANCE AT JULY 28, 2012 | $ | 409 |  |  | $ | (53 | ) |  | $ | 305 |  |  | $ | 661 |  |
| Other comprehensive income (loss) before reclassifications attributable to Cisco Systems, Inc. | 3 |  |  | 74 |  |  | (83 | ) |  | (6 | ) |
| (Gains) losses reclassified out of AOCI | (48 | ) |  | (12 | ) |  | — |  |  | (60 | ) |
| Tax benefit (expense) | 15 |  |  | (1 | ) |  | (1 | ) |  | 13 |  |
| BALANCE AT JULY 27, 2013 | 379 |  |  | 8 |  |  | 221 |  |  | 608 |  |
| Other comprehensive income (loss) before reclassifications attributable to Cisco Systems, Inc. | 380 |  |  | 48 |  |  | 49 |  |  | 477 |  |
| (Gains) losses reclassified out of AOCI | (300 | ) |  | (68 | ) |  | — |  |  | (368 | ) |
| Tax benefit (expense) | (35 | ) |  | — |  |  | (5 | ) |  | (40 | ) |
| BALANCE AT JULY 26, 2014 | 424 |  |  | (12 | ) |  | 265 |  |  | 677 |  |
| Other comprehensive income (loss) before reclassifications attributable to Cisco Systems, Inc. | (28 | ) |  | (159 | ) |  | (563 | ) |  | (750 | ) |
| (Gains) losses reclassified out of AOCI | (157 | ) |  | 154 |  |  | 2 |  |  | (1 | ) |
| Tax benefit (expense) | 71 |  |  | 1 |  |  | 63 |  |  | 135 |  |
| BALANCE AT JULY 25, 2015 | $ | 310 |  |  | $ | (16 | ) |  | $ | (233 | ) |  | $ | 61 |  |

[0000858877-15-000070:notes:129]
The net gains (losses) reclassified out of AOCI into the Consolidated Statements of Operations, with line item location, during each period were as follows (in millions):

[0000858877-15-000070:notes:130]
|  |  | July 25, 2015 |  | July 26, 2014 |  | July 27, 2013 |  |  |
| Comprehensive Income Components |  | Income Before Taxes |  | Line Item in Statements of Operations |
| Net unrealized gains on available-for-sale investments |  |  |  |  |  |  |  |  |
|  |  | $ | 157 |  |  | $ | 300 |  |  | $ | 48 |  |  | Other income (loss), net |
| Net unrealized gains and losses on cash flow hedging instruments |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | (121 | ) |  | 55 |  |  | 10 |  |  | Operating expenses |
| Foreign currency derivatives |  | (33 | ) |  | 13 |  |  | 2 |  |  | Cost of sales—service |
|  |  | (154 | ) |  | 68 |  |  | 12 |  |  |  |
| Cumulative translation adjustment and actuarial gains and losses |  |  |  |  |  |  |  |  |
|  |  | (2 | ) |  | — |  |  | — |  |  | Operating expenses |
| Total amounts reclassified out of AOCI |  | $ | 1 |  |  | $ | 368 |  |  | $ | 60 |  |  |  |


## us-gaap:DebtDisclosureTextBlock

[0000858877-15-000070:notes:131]
| 10. | Borrowings |

[0000858877-15-000070:notes:132]
| (a) | Short-Term Debt |

[0000858877-15-000070:notes:133]
The following table summarizes the Company’s short-term debt (in millions, except percentages):

[0000858877-15-000070:notes:134]
|  | July 25, 2015 |  | July 26, 2014 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 3,894 |  |  | 2.48 | % |  | $ | 500 |  |  | 3.11 | % |
| Other notes and borrowings | 3 |  |  | 2.44 | % |  | 8 |  |  | 2.67 | % |
| Total short-term debt | $ | 3,897 |  |  |  |  | $ | 508 |  |  |  |

[0000858877-15-000070:notes:135]
The effective interest rate on the current portion of long-term debt includes the impact of interest rate swaps, as discussed further in "

[0000858877-15-000070:notes:136]
| (b) | Long-Term Debt |

[0000858877-15-000070:notes:137]
."  Other notes and borrowings consist of the short-term portion of secured borrowings associated with customer financing arrangements.  These notes and credit facilities were subject to various terms and foreign currency market interest rates pursuant to individual financial arrangements between the financing institution and the applicable foreign subsidiary.

[0000858877-15-000070:notes:138]
The Company repaid the fixed-rate notes (2.90%) due on November 17, 2014 for an aggregate principal amount of $500 million upon maturity.

[0000858877-15-000070:notes:139]
The Company repaid the floating-rate notes due on September 3, 2015 for an aggregate principal amount of $850 million upon maturity.

[0000858877-15-000070:notes:140]
In fiscal 2011, the Company established a short-term debt financing program of up to $3.0 billion through the issuance of commercial paper notes.  The Company uses the proceeds from the issuance of commercial paper notes for general corporate purposes.  The Company did not have any commercial paper notes outstanding as of each of July 25, 2015 and July 26, 2014.

[0000858877-15-000070:notes:141]
(b)

[0000858877-15-000070:notes:142]
Long-Term Debt

[0000858877-15-000070:notes:143]
The following table summarizes the Company’s long-term debt (in millions, except percentages):

[0000858877-15-000070:notes:144]
|  |  |  | July 25, 2015 |  | July 26, 2014 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.05% | September 3, 2015 |  | $ | 850 |  |  | 0.43% |  | $ | 850 |  |  | 0.35% |
| Three-month LIBOR plus 0.28% | March 3, 2017 |  | 1,000 |  |  | 0.63% |  | 1,000 |  |  | 0.56% |
| Three-month LIBOR plus 0.31% | June 15, 2018 | (1) | 900 |  |  | 0.65% |  | — |  |  | — |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | 500 |  |  | 0.84% |  | 500 |  |  | 0.78% |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 2.90% | November 17, 2014 |  | — |  |  | — |  | 500 |  |  | 3.11% |
| 5.50% | February 22, 2016 |  | 3,000 |  |  | 3.07% |  | 3,000 |  |  | 3.04% |
| 1.10% | March 3, 2017 |  | 2,400 |  |  | 0.59% |  | 2,400 |  |  | 0.56% |
| 3.15% | March 14, 2017 |  | 750 |  |  | 0.85% |  | 750 |  |  | 0.79% |
| 1.65% | June 15, 2018 | (1) | 1,600 |  |  | 1.72% |  | — |  |  | — |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 4.70% |  | 2,000 |  |  | 4.69% |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 0.80% |  | 1,750 |  |  | 0.77% |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 3.01% |  | 2,500 |  |  | 2.98% |
| 2.45% | June 15, 2020 | (1) | 1,500 |  |  | 2.54% |  | — |  |  | — |
| 2.90% | March 4, 2021 |  | 500 |  |  | 0.96% |  | 500 |  |  | 0.93% |
| 3.00% | June 15, 2022 | (1) | 500 |  |  | 1.21% |  | — |  |  | — |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1.08% |  | 1,000 |  |  | 1.05% |
| 3.50% | June 15, 2025 | (1) | 500 |  |  | 1.37% |  | — |  |  | — |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Other long-term debt |  |  | 1 |  |  | 2.08% |  | 4 |  |  | 2.39% |
| Total |  |  | 25,251 |  |  |  |  | 20,754 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (131 | ) |  |  |  | (127 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 231 |  |  |  |  | 210 |  |  |  |
| Total |  |  | $ | 25,351 |  |  |  |  | $ | 20,837 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 3,894 |  |  |  |  | $ | 500 |  |  |  |
| Long-term debt |  |  | 21,457 |  |  |  |  | 20,337 |  |  |  |
| Total |  |  | $ | 25,351 |  |  |  |  | $ | 20,837 |  |  |  |

[0000858877-15-000070:notes:145]
(1) In June 2015, the Company issued senior notes for an aggregate principal amount of $5.0 billion.

[0000858877-15-000070:notes:146]
To achieve its interest rate risk management objectives, the Company entered into interest rate swaps in prior periods with an aggregate notional amount of $11.4 billion designated as fair value hedges of certain of its fixed-rate senior notes.  In effect, these swaps convert the fixed interest rates of the fixed-rate notes to floating interest rates based on the London InterBank Offered Rate (LIBOR).  The gains and losses related to changes in the fair value of the interest rate swaps substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates.  For additional information, see Note 11.

[0000858877-15-000070:notes:147]
The effective rates for the fixed-rate debt include the interest on the notes, the accretion of the discount, and, if applicable, adjustments related to hedging.  Interest is payable semiannually on each class of the senior fixed-rate notes and payable quarterly on the floating-rate notes.  Each of the senior fixed-rate notes is redeemable by the Company at any time, subject to a make-whole premium.

[0000858877-15-000070:notes:148]
The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to the Company’s short-term debt financing program, as discussed above under “(a) Short-Term Debt.”  As of July 25, 2015, the Company was in compliance with all debt covenants.

[0000858877-15-000070:notes:149]
As of July 25, 2015, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

[0000858877-15-000070:notes:150]
| Fiscal Year | Amount |
| 2016 | $ | 3,850 |  |
| 2017 | 4,151 |  |
| 2018 | 2,500 |  |
| 2019 | 4,250 |  |
| 2020 | 4,000 |  |
| Thereafter | 6,500 |  |
| Total | $ | 25,251 |  |

[0000858877-15-000070:notes:151]
| (c) | Credit Facility |

[0000858877-15-000070:notes:152]
On May 15, 2015, the Company entered into a credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 15, 2020.  Any advances under the credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (i) the highest of (a) the Federal Funds rate plus 0.50%, (b) Bank of America’s “prime rate” as announced from time to time, or (c) LIBOR, or a comparable or successor rate that is approved by the Administrative Agent (“Eurocurrency Rate”), for an interest period of one-month plus 1.00%, or (ii) the Eurocurrency Rate, plus a margin that is based on the Company’s senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the Eurocurrency Rate be less than zero.  The credit agreement requires the Company to comply with certain covenants, including that it maintain an interest coverage ratio as defined in the agreement.

[0000858877-15-000070:notes:153]
The Company may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and/or extend the expiration date of the credit facility up to May 15, 2022.  As of July 25, 2015, the Company was in compliance with the required interest coverage ratio and the other covenants, and the Company had not borrowed any funds under the credit facility.

[0000858877-15-000070:notes:154]
This credit facility replaces the Company’s prior credit facility that was entered into on February 17, 2012, which was terminated in connection with its entering into the new credit facility.


## us-gaap:DeferredRevenueByArrangementDisclosureTextBlock

[0000858877-15-000070:notes:155]
| Deferred revenue: |  |  |  |  |
| Service |  | $ | 9,757 |  |  | $ | 9,640 |  |
| Product: |  |  |  |  |
| Unrecognized revenue on product shipments and other deferred revenue |  | 4,766 |  |  | 3,924 |  |
| Cash receipts related to unrecognized revenue from two-tier distributors |  | 660 |  |  | 578 |  |
| Total product deferred revenue |  | 5,426 |  |  | 4,502 |  |
| Total |  | $ | 15,183 |  |  | $ | 14,142 |  |
| Reported as: |  |  |  |  |
| Current |  | $ | 9,824 |  |  | $ | 9,478 |  |
| Noncurrent |  | 5,359 |  |  | 4,664 |  |
| Total |  | $ | 15,183 |  |  | $ | 14,142 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000858877-15-000070:notes:156]
| 11. | Derivative Instruments |

[0000858877-15-000070:notes:157]
| (a) | Summary of Derivative Instruments |

[0000858877-15-000070:notes:158]
The Company uses derivative instruments primarily to manage exposures to foreign currency exchange rate, interest rate, and equity price risks. The Company’s primary objective in holding derivatives is to reduce the volatility of earnings and cash flows associated with changes in foreign currency exchange rates, interest rates, and equity prices. The Company’s derivatives expose it to credit risk to the extent that the counterparties may be unable to meet the terms of the agreement. The Company does, however, seek to mitigate such risks by limiting its counterparties to major financial institutions. In addition, the potential risk of loss with any one counterparty resulting from this type of credit risk is monitored. Management does not expect material losses as a result of defaults by counterparties.

[0000858877-15-000070:notes:159]
The fair values of the Company’s derivative instruments and the line items on the Consolidated Balance Sheets to which they were recorded are summarized as follows (in millions):

[0000858877-15-000070:notes:160]
|  | DERIVATIVE ASSETS |  | DERIVATIVE LIABILITIES |
|  | Balance Sheet Line Item |  | July 25, 2015 |  | July 26, 2014 |  | Balance Sheet Line Item |  | July 25, 2015 |  | July 26, 2014 |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | $ | 10 |  |  | $ | 7 |  |  | Other current liabilities |  | $ | 11 |  |  | $ | 6 |  |
| Interest rate derivatives | Other assets |  | 202 |  |  | 148 |  |  | Other long-term liabilities |  | — |  |  | 3 |  |
| Equity derivatives | Other current assets |  | — |  |  | — |  |  | Other current liabilities |  | — |  |  | 56 |  |
| Total |  |  | 212 |  |  | 155 |  |  |  |  | 11 |  |  | 65 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | 2 |  |  | 3 |  |  | Other current liabilities |  | 1 |  |  | 2 |  |
| Equity derivatives | Other assets |  | 4 |  |  | 2 |  |  | Other long-term liabilities |  | — |  |  | — |  |
| Total |  |  | 6 |  |  | 5 |  |  |  |  | 1 |  |  | 2 |  |
| Total |  |  | $ | 218 |  |  | $ | 160 |  |  |  |  | $ | 12 |  |  | $ | 67 |  |

[0000858877-15-000070:notes:161]
The effects of the Company’s cash flow and net investment hedging instruments on other comprehensive income (OCI) and the Consolidated Statements of Operations are summarized as follows (in millions):

[0000858877-15-000070:notes:162]
| GAINS (LOSSES) RECOGNIZEDIN OCI ON DERIVATIVES FORTHE YEARS ENDED (EFFECTIVE PORTION) |  | GAINS (LOSSES) RECLASSIFIED FROMAOCI INTO INCOME FORTHE YEARS ENDED (EFFECTIVE PORTION) |
|  |  | July 25, 2015 |  | July 26, 2014 |  | July 27, 2013 |  | Line Item in Statements of Operations |  | July 25, 2015 |  | July 26, 2014 |  | July 27, 2013 |
| Derivatives designated as cash flow hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | (159 | ) |  | $ | 48 |  |  | $ | 73 |  |  | Operating expenses |  | $ | (121 | ) |  | $ | 55 |  |  | $ | 10 |  |
|  |  |  |  |  |  |  |  | Cost of sales—service |  | (33 | ) |  | 13 |  |  | 2 |  |
| Total |  | $ | (159 | ) |  | $ | 48 |  |  | $ | 73 |  |  | Total |  | $ | (154 | ) |  | $ | 68 |  |  | $ | 12 |  |
| Derivatives designated as net investment hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | 42 |  |  | $ | (15 | ) |  | $ | (1 | ) |  | Other income (loss), net |  | $ | — |  |  | $ | — |  |  | $ | — |  |

[0000858877-15-000070:notes:163]
As of July 25, 2015, the Company estimates that approximately $5 million of net derivative losses related to its cash flow hedges included in accumulated other comprehensive income (AOCI) will be reclassified into earnings within the next 12 months when the underlying hedged item impacts earnings.

[0000858877-15-000070:notes:164]
The effect on the Consolidated Statements of Operations of derivative instruments not designated as hedges is summarized as follows (in millions):

[0000858877-15-000070:notes:165]
|  |  |  |  | GAINS (LOSSES) FOR THE YEARS ENDED |
| Derivatives Not Designated as Hedging Instruments |  | Line Item in Statements of Operations |  | July 25, 2015 |  | July 26, 2014 |  | July 27, 2013 |
| Foreign currency derivatives |  | Other income (loss), net |  | $ | (173 | ) |  | $ | 23 |  |  | $ | (74 | ) |
| Total return swaps—deferred compensation |  | Operating expenses |  | 19 |  |  | 47 |  |  | 61 |  |
| Equity derivatives |  | Other income (loss), net |  | 27 |  |  | 34 |  |  | — |  |
| Total |  |  |  | $ | (127 | ) |  | $ | 104 |  |  | $ | (13 | ) |

[0000858877-15-000070:notes:166]
The notional amounts of the Company’s outstanding derivatives are summarized as follows (in millions):

[0000858877-15-000070:notes:167]
|  | July 25, 2015 |  | July 26, 2014 |
| Derivatives designated as hedging instruments: |  |  |  |
| Foreign currency derivatives—cash flow hedges | $ | 1,201 |  |  | $ | 1,618 |  |
| Interest rate derivatives | 11,400 |  |  | 10,400 |  |
| Net investment hedging instruments | 192 |  |  | 345 |  |
| Equity derivatives | — |  |  | 238 |  |
| Derivatives not designated as hedging instruments: |  |  |  |
| Foreign currency derivatives | 2,023 |  |  | 2,528 |  |
| Total return swaps—deferred compensation | 462 |  |  | 428 |  |
| Total | $ | 15,278 |  |  | $ | 15,557 |  |

[0000858877-15-000070:notes:168]
| (b) | Offsetting of Derivative Instruments |

[0000858877-15-000070:notes:169]
The Company presents its derivative instruments at gross fair values in the Consolidated Balance Sheets.  However, the Company’s master netting and other similar arrangements with the respective counterparties allow for net settlement under certain conditions, which are designed to reduce credit risk by permitting net settlement with the same counterparty.  To further limit credit risk, the Company also enters into collateral security arrangements related to certain derivative instruments whereby cash is posted as collateral between the counterparties based on the fair market value of the derivative instrument.   Information related to these offsetting arrangements is summarized as follows (in millions):

[0000858877-15-000070:notes:170]
|  | GROSS AMOUNTS OFFSET IN THE CONSOLIDATED BALANCE SHEET |  | GROSS AMOUNTS NOT OFFSET IN THE CONSOLIDATED BALANCE SHEETBUT WITH LEGAL RIGHTS TO OFFSET |
| July 25, 2015 | Gross Amounts Recognized |  | Gross Amounts Offset |  | Net Amounts Presented |  | Gross Derivative Amounts |  | Cash Collateral |  | Net Amount |
| Derivatives assets | $ | 218 |  |  | $ | — |  |  | $ | 218 |  |  | $ | (12 | ) |  | $ | (124 | ) |  | $ | 82 |  |
| Derivatives liabilities | $ | 12 |  |  | $ | — |  |  | $ | 12 |  |  | $ | (12 | ) |  | $ | — |  |  | $ | — |  |

[0000858877-15-000070:notes:171]
|  | GROSS AMOUNTS OFFSET IN THE CONSOLIDATED BALANCE SHEET |  | GROSS AMOUNTS NOT OFFSET IN THE CONSOLIDATED BALANCE SHEETBUT WITH LEGAL RIGHTS TO OFFSET |
| July 26, 2014 | Gross Amounts Recognized |  | Gross Amounts Offset |  | Net Amounts Presented |  | Gross Derivative Amounts |  | Cash Collateral |  | Net Amount |
| Derivatives assets | $ | 160 |  |  | $ | — |  |  | $ | 160 |  |  | $ | (39 | ) |  | $ | (60 | ) |  | $ | 61 |  |
| Derivatives liabilities | $ | 67 |  |  | $ | — |  |  | $ | 67 |  |  | $ | (39 | ) |  | $ | (1 | ) |  | $ | 27 |  |

[0000858877-15-000070:notes:172]
| (c) | Foreign Currency Exchange Risk |

[0000858877-15-000070:notes:173]
The Company conducts business globally in numerous currencies. Therefore, it is exposed to adverse movements in foreign currency exchange rates. To limit the exposure related to foreign currency changes, the Company enters into foreign currency contracts. The Company does not enter into such contracts for trading purposes.

[0000858877-15-000070:notes:174]
The Company hedges forecasted foreign currency transactions related to certain operating expenses and service cost of sales with currency options and forward contracts. These currency options and forward contracts, designated as cash flow hedges, generally have maturities of less than 18 months. The Company assesses effectiveness based on changes in total fair value of the derivatives. The effective portion of the derivative instrument’s gain or loss is initially reported as a component of AOCI and subsequently reclassified into earnings when the hedged exposure affects earnings. The ineffective portion, if any, of the gain or loss is reported in earnings immediately. During the fiscal years presented, the Company did not discontinue any cash flow hedges for which it was probable that a forecasted transaction would not occur.

[0000858877-15-000070:notes:175]
The Company enters into foreign exchange forward and option contracts to reduce the short-term effects of foreign currency fluctuations on assets and liabilities such as foreign currency receivables, including long-term customer financings, investments, and payables. These derivatives are not designated as hedging instruments. Gains and losses on the contracts are included in other income (loss), net, and substantially offset foreign exchange gains and losses from the remeasurement of intercompany balances or other current assets, investments, or liabilities denominated in currencies other than the functional currency of the reporting entity.

[0000858877-15-000070:notes:176]
The Company hedges certain net investments in its foreign operations with forward contracts to reduce the effects of foreign currency fluctuations on the Company’s net investment in those foreign subsidiaries. These derivative instruments generally have maturities of up to six months.

[0000858877-15-000070:notes:177]
| (d) | Interest Rate Risk |

[0000858877-15-000070:notes:178]
Interest Rate Derivatives, Investments   The Company’s primary objective for holding fixed income securities is to achieve an appropriate investment return consistent with preserving principal and managing risk. To realize these objectives, the Company may utilize interest rate swaps or other derivatives designated as fair value or cash flow hedges. As of July 25, 2015 and July 26, 2014, the Company did not have any outstanding interest rate derivatives related to its fixed income securities.

[0000858877-15-000070:notes:179]
Interest Rate Derivatives Designated as Fair Value Hedges, Long-Term Debt  In fiscal 2015 and 2014, the Company entered into interest rate swaps designated as fair value hedges related to fixed-rate senior notes that are due on various dates from 2017 through 2025. In the periods prior to fiscal 2013, the Company entered into interest rate swaps designated as fair value hedges related to fixed-rate senior notes that are due in 2016 and 2017. Under these interest rate swaps, the Company receives fixed-rate interest payments and makes interest payments based on LIBOR plus a fixed number of basis points. The effect of such swaps is to convert the fixed interest rates of the senior fixed-rate notes to floating interest rates based on LIBOR. The gains and losses related to changes in the fair value of the interest rate swaps are included in interest expense and substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates. The fair value of the interest rate swaps was reflected in other assets and other long-term liabilities.

[0000858877-15-000070:notes:180]
| (e) | Equity Price Risk |

[0000858877-15-000070:notes:181]
The Company may hold equity securities for strategic purposes or to diversify its overall investment portfolio. The publicly traded equity securities in the Company’s portfolio are subject to price risk. To manage its exposure to changes in the fair value of certain equity securities, the Company has entered into equity derivatives that are designated as fair value hedges. The changes in the value of the hedging instruments are included in other income (loss), net, and offset the change in the fair value of the underlying hedged investment. In addition, the Company periodically enters into equity derivatives that are not designated as accounting hedges. The changes in the fair value of these derivatives are also included in other income (loss), net.

[0000858877-15-000070:notes:182]
The Company is also exposed to variability in compensation charges related to certain deferred compensation obligations to employees. Although not designated as accounting hedges, the Company utilizes derivatives such as total return swaps to economically hedge this exposure.

[0000858877-15-000070:notes:183]
| (f) | Hedge Effectiveness |

[0000858877-15-000070:notes:184]
For the fiscal years presented, amounts excluded from the assessment of hedge effectiveness were not material for fair value, cash flow, and net investment hedges. In addition, hedge ineffectiveness for fair value, cash flow, and net investment hedges was not material for any of the fiscal years presented.

[0000858877-15-000070:notes:185]
| (g) | Collateral and Credit-Risk-Related Contingent Features |

[0000858877-15-000070:notes:186]
For certain derivative instruments, the Company and its counterparties have entered into arrangements requiring the party that is in a liability position from a mark-to-market standpoint to post cash collateral to the other party.  See further discussion under "(b) Offsetting of Derivative Instruments" above.

[0000858877-15-000070:notes:187]
In addition, certain derivative instruments are executed under agreements that have provisions requiring the Company and the counterparty to maintain a specified credit rating from certain credit-rating agencies. Under such agreements, if the Company’s or the counterparty’s credit rating falls below a specified credit rating, either party has the right to request collateral on the derivatives’ net liability position. The fair market value of these derivatives that are in a net liability position as of July 25, 2015 and July 26, 2014 were $0 million and $3 million, respectively.


## us-gaap:DerivativesPolicyTextBlock

[0000858877-15-000070:notes:188]
(l) Derivative Instruments   The Company recognizes derivative instruments as either assets or liabilities and measures those instruments at fair value. The accounting for changes in the fair value of a derivative depends on the intended use of the derivative and the resulting designation. For a derivative instrument designated as a fair value hedge, the gain or loss is recognized in earnings in the period of change together with the offsetting loss or gain on the hedged item attributed to the risk being hedged. For a derivative instrument designated as a cash flow hedge, the effective portion of the derivative’s gain or loss is initially reported as a component of AOCI and subsequently reclassified into earnings when the hedged exposure affects earnings. The ineffective portion of the gain or loss is reported in earnings immediately.  For a derivative instrument designated as a net investment hedge of the Company’s foreign operations, the gain or loss is recorded in the cumulative translation adjustment within AOCI together with the offsetting loss or gain of the hedged exposure of the underlying foreign operations. Any ineffective portion of the net investment hedges is reported in earnings during the period of change. For derivative instruments that are not designated as accounting hedges, changes in fair value are recognized in earnings in the period of change. The Company records derivative instruments in the statements of cash flows to operating, investing, or financing activities consistent with the cash flows of the hedged item.

[0000858877-15-000070:notes:189]
Hedge effectiveness for foreign exchange forward contracts used as cash flow hedges is assessed by comparing the change in the fair value of the hedge contract with the change in the fair value of the forecasted cash flows of the hedged item.  Hedge effectiveness for equity forward contracts and foreign exchange net investment hedge forward contracts is assessed by comparing changes in fair value due to changes in spot rates for both the derivative and the hedged item.   For foreign exchange option contracts, hedge effectiveness is assessed based on the hedging instrument’s entire change in fair value.  Hedge effectiveness for interest rate swaps is assessed by comparing the change in fair value of the swap with the change in the fair value of the hedged item due to changes in the benchmark interest rate.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000858877-15-000070:notes:190]
| 14. | Employee Benefit Plans |

[0000858877-15-000070:notes:191]
| (a) | Employee Stock Incentive Plans |

[0000858877-15-000070:notes:192]
Stock Incentive Plan Program Description    As of July 25, 2015, the Company had four stock incentive plans: the 2005 Stock Incentive Plan (the “2005 Plan”); the 1996 Stock Incentive Plan (the “1996 Plan”); the Cisco Systems, Inc. SA Acquisition Long-Term Incentive Plan (the “SA Acquisition Plan”); and the Cisco Systems, Inc. WebEx Acquisition Long-Term Incentive Plan (the “WebEx Acquisition Plan”). In addition, the Company has, in connection with the acquisitions of various companies, assumed the share-based awards granted under stock incentive plans of the acquired companies or issued share-based awards in replacement thereof. Share-based awards are designed to reward employees for their long-term contributions to the Company and provide incentives for them to remain with the Company. The number and frequency of share-based awards are based on competitive practices, operating results of the Company, government regulations, and other factors. Since the inception of the stock incentive plans, the Company has granted share-based awards to a significant percentage of its employees, and the majority has been granted to employees below the vice president level. The Company’s primary stock incentive plans are summarized as follows:

[0000858877-15-000070:notes:193]
2005 Plan    As of July 25, 2015, the maximum number of shares issuable under the 2005 Plan over its term was 694 million shares, plus the number of any shares underlying awards outstanding on November 15, 2007 under the 1996 Plan, the SA Acquisition Plan, and the WebEx Acquisition Plan that are forfeited or are terminated for any other reason before being exercised or settled. If any awards granted under the 2005 Plan are forfeited or are terminated for any other reason before being exercised or settled, the unexercised or unsettled shares underlying the awards will again be available under the 2005 Plan.  Starting November 19, 2013, shares withheld by the Company from an award other than a stock option or stock appreciation right to satisfy withholding tax liabilities resulting from such award will again be available for issuance, based on the fungible share ratio in effect on the date of grant.

[0000858877-15-000070:notes:194]
Pursuant to an amendment approved by the Company’s shareholders on November 12, 2009, the number of shares available for issuance under the 2005 Plan is reduced by 1.5 shares for each share awarded as a stock grant or a stock unit, and any shares underlying awards outstanding under the 1996 Plan, the SA Acquisition Plan, and the WebEx Acquisition Plan that expire unexercised at the end of their maximum terms become available for reissuance under the 2005 Plan. The 2005 Plan permits the granting of stock options, restricted stock, and RSUs, the vesting of which may be performance-based or market-based along with the requisite service requirement, and stock appreciation rights to employees (including employee directors and officers), consultants of the Company and its subsidiaries and affiliates, and non-employee directors of the Company. Stock options and stock appreciation rights granted under the 2005 Plan have an exercise price of at least 100% of the fair market value of the underlying stock on the grant date and prior to November 12, 2009 have an expiration date no later than nine years from the grant date. The expiration date for stock options and stock appreciation rights granted subsequent to the amendment approved on November 12, 2009 shall be no later than 10 years from the grant date.

[0000858877-15-000070:notes:195]
The stock options will generally become exercisable for 20% or 25% of the option shares one year from the date of grant and then ratably over the following 48 months or 36 months, respectively. Time-based stock grants and time-based RSUs will generally vest with respect to 20% or 25% of the shares or share units covered by the grant on each of the first through fifth or fourth anniversaries of the date of the grant, respectively.  The majority of the performance-based and market-based RSUs vests at the end of the three-year requisite service period or earlier if the award recipient meets certain retirement eligibility conditions. Other performance-based RSUs, that are based on the achievement of financial and/or non-financial operating goals typically award RSUs upon the achievement of milestones (and may require subsequent service periods), with overall vesting of the shares underlying the award ranging from six months to three years.  The Compensation and Management Development Committee of the Board of Directors has the discretion to use different vesting schedules. Stock appreciation rights may be awarded in combination with stock options or stock grants, and such awards shall provide that the stock appreciation rights will not be exercisable unless the related stock options or stock grants are forfeited. Stock grants may be awarded in combination with non-statutory stock options, and such awards may provide that the stock grants will be forfeited in the event that the related non-statutory stock options are exercised.

[0000858877-15-000070:notes:196]
1996 Plan   The 1996 Plan expired on December 31, 2006, and the Company can no longer make equity awards under the 1996 Plan. The maximum number of shares issuable over the term of the 1996 Plan was 2.5 billion shares. Stock options granted under the 1996 Plan have an exercise price of at least 100% of the fair market value of the underlying stock on the grant date and expire no later than nine years from the grant date. The stock options generally became exercisable for 20% or 25% of the option shares one year from the date of grant and then ratably over the following 48 months or 36 months, respectively.  Certain other grants utilized a 60-month ratable vesting schedule. In addition, the Board of Directors, or other committees administering the 1996 Plan, had the discretion to use a different vesting schedule and did so from time to time.

[0000858877-15-000070:notes:197]
Acquisition Plans In connection with the Company’s acquisitions of Scientific-Atlanta, Inc. (“Scientific-Atlanta”) and WebEx Communications, Inc. (“WebEx”), the Company adopted the SA Acquisition Plan and the WebEx Acquisition Plan, respectively, each effective upon completion of the applicable acquisition. These plans constitute assumptions, amendments, restatements, and renamings of the 2003 Long-Term Incentive Plan of Scientific-Atlanta and the WebEx Communications, Inc. Amended and Restated 2000 Stock Incentive Plan, respectively. The plans permit the grant of stock options, stock, stock units, and stock appreciation rights to certain employees of the Company and its subsidiaries and affiliates who had been employed by Scientific-Atlanta or its subsidiaries or WebEx or its subsidiaries, as applicable. As a result of the shareholder approval of the amendment and extension of the 2005 Plan, as of November 15, 2007, the Company will no longer make stock option grants or direct share issuances under either the SA Acquisition Plan or the WebEx Acquisition Plan.

[0000858877-15-000070:notes:198]
| (b) | Employee Stock Purchase Plan |

[0000858877-15-000070:notes:199]
The Company has an Employee Stock Purchase Plan, which includes its subplan named the International Employee Stock Purchase Plan (together, the “Purchase Plan”), under which 621 million shares of the Company’s common stock have been reserved for issuance as of July 25, 2015. Eligible employees are offered shares through a 24-month offering period, which consists of four consecutive 6-month purchase periods. Employees may purchase a limited number of shares of the Company’s stock at a discount of up to 15% of the lesser of the market value at the beginning of the offering period or the end of each 6-month purchase period. The Purchase Plan is scheduled to terminate on January 3, 2020. The Company issued 27 million, 27 million, and 36 million shares under the Purchase Plan in fiscal 2015, 2014, and 2013, respectively. As of July 25, 2015, 148 million shares were available for issuance under the Purchase Plan.

[0000858877-15-000070:notes:200]
| (c) | Summary of Share-Based Compensation Expense |

[0000858877-15-000070:notes:201]
Share-based compensation expense consists primarily of expenses for stock options, stock purchase rights, restricted stock, and restricted stock units granted to employees. The following table summarizes share-based compensation expense (in millions):

[0000858877-15-000070:notes:202]
| Years Ended | July 25, 2015 |  | July 26, 2014 |  | July 27, 2013 |
| Cost of sales—product | $ | 50 |  |  | $ | 45 |  |  | $ | 40 |  |
| Cost of sales—service | 157 |  |  | 150 |  |  | 138 |  |
| Share-based compensation expense in cost of sales | 207 |  |  | 195 |  |  | 178 |  |
| Research and development | 448 |  |  | 411 |  |  | 286 |  |
| Sales and marketing | 559 |  |  | 549 |  |  | 484 |  |
| General and administrative | 228 |  |  | 198 |  |  | 175 |  |
| Restructuring and other charges | (2 | ) |  | (5 | ) |  | (3 | ) |
| Share-based compensation expense in operating expenses | 1,233 |  |  | 1,153 |  |  | 942 |  |
| Total share-based compensation expense | $ | 1,440 |  |  | $ | 1,348 |  |  | $ | 1,120 |  |
| Income tax benefit for share-based compensation | $ | 373 |  |  | $ | 324 |  |  | $ | 285 |  |

[0000858877-15-000070:notes:203]
As of July 25, 2015, the total compensation cost related to unvested share-based awards not yet recognized was $2.4 billion, which is expected to be recognized over approximately 2.6 years on a weighted-average basis.

[0000858877-15-000070:notes:204]
| (d) | Share-Based Awards Available for Grant |

[0000858877-15-000070:notes:205]
A summary of share-based awards available for grant is as follows (in millions):

[0000858877-15-000070:notes:206]
| Years Ended | July 25, 2015 |  | July 26, 2014 |  | July 27, 2013 |
| Balance at beginning of fiscal year | 310 |  |  | 228 |  |  | 218 |  |
| Restricted stock, stock units, and other share-based awards granted | (101 | ) |  | (98 | ) |  | (102 | ) |
| Share-based awards canceled/forfeited/expired | 40 |  |  | 36 |  |  | 115 |  |
| Additional shares reserved | — |  |  | 135 |  |  | — |  |
| Shares withheld for taxes and not issued | 27 |  |  | 6 |  |  | — |  |
| Other | — |  |  | 3 |  |  | (3 | ) |
| Balance at end of fiscal year | 276 |  |  | 310 |  |  | 228 |  |

[0000858877-15-000070:notes:207]
As reflected in the preceding table, for each share awarded as restricted stock or subject to a restricted stock unit award under the 2005 Plan, an equivalent of 1.5 shares was deducted from the available share-based award balance. For restricted stock units that were awarded with vesting contingent upon the achievement of future financial performance or market-based metrics, the maximum awards that can be achieved upon full vesting of such awards were reflected in the preceding table.

[0000858877-15-000070:notes:208]
| (e) | Restricted Stock and Stock Unit Awards |

[0000858877-15-000070:notes:209]
A summary of the restricted stock and stock unit activity, which includes time-based and performance-based or market-based restricted stock units, is as follows (in millions, except per-share amounts):

[0000858877-15-000070:notes:210]
|  | Restricted Stock/Stock Units |  | Weighted-AverageGrant Date FairValue per Share |  | Aggregate Fair Value |
| UNVESTED BALANCE AT JULY 28, 2012 | 128 |  |  | $ | 19.46 |  |  |  |
| Granted and assumed | 72 |  |  | 18.52 |  |  |  |
| Vested | (46 | ) |  | 20.17 |  |  | $ | 932 |  |
| Canceled/forfeited | (11 | ) |  | 18.91 |  |  |  |
| UNVESTED BALANCE AT JULY 27, 2013 | 143 |  |  | 18.80 |  |  |  |
| Granted and assumed | 72 |  |  | 20.85 |  |  |  |
| Vested | (53 | ) |  | 19.55 |  |  | $ | 1,229 |  |
| Canceled/forfeited | (13 | ) |  | 18.61 |  |  |  |
| UNVESTED BALANCE AT JULY 26, 2014 | 149 |  |  | 19.54 |  |  |  |
| Granted and assumed | 67 |  |  | 25.29 |  |  |  |
| Vested | (57 | ) |  | 19.82 |  |  | $ | 1,517 |  |
| Canceled/forfeited | (16 | ) |  | 20.17 |  |  |  |
| UNVESTED BALANCE AT JULY 25, 2015 | 143 |  |  | $ | 22.08 |  |  |  |

[0000858877-15-000070:notes:211]
| (f) | Stock Option Awards |

[0000858877-15-000070:notes:212]
A summary of the stock option activity is as follows (in millions, except per-share amounts):

[0000858877-15-000070:notes:213]
|  | STOCK OPTIONS OUTSTANDING |
|  | NumberOutstanding |  | Weighted-AverageExercise Price per Share |
| BALANCE AT JULY 28, 2012 | 520 |  |  | $ | 22.68 |  |
| Assumed from acquisitions | 10 |  |  | 0.77 |  |
| Exercised | (154 | ) |  | 18.51 |  |
| Canceled/forfeited/expired | (100 | ) |  | 22.18 |  |
| BALANCE AT JULY 27, 2013 | 276 |  |  | 24.44 |  |
| Assumed from acquisitions | 6 |  |  | 3.60 |  |
| Exercised | (78 | ) |  | 18.30 |  |
| Canceled/forfeited/expired | (17 | ) |  | 27.53 |  |
| BALANCE AT JULY 26, 2014 | 187 |  |  | 26.03 |  |
| Assumed from acquisitions | 1 |  |  | 2.60 |  |
| Exercised | (71 | ) |  | 21.15 |  |
| Canceled/forfeited/expired | (14 | ) |  | 29.68 |  |
| BALANCE AT JULY 25, 2015 | 103 |  |  | $ | 28.68 |  |

[0000858877-15-000070:notes:214]
The total pretax intrinsic value of stock options exercised during fiscal 2015, 2014, and 2013 was $434 million, $458 million, and $661 million, respectively.

[0000858877-15-000070:notes:215]
The following table summarizes significant ranges of outstanding and exercisable stock options as of July 25, 2015 (in millions, except years and share prices):

[0000858877-15-000070:notes:216]
|  |  | STOCK OPTIONS OUTSTANDING |  | STOCK OPTIONS EXERCISABLE |
| Range of Exercise Prices |  | NumberOutstanding |  | Weighted-AverageRemainingContractualLife(in Years) |  | Weighted-AverageExercisePrice perShare |  | AggregateIntrinsicValue |  | NumberExercisable |  | Weighted-AverageExercisePrice perShare |  | AggregateIntrinsicValue |
| $ 0.01 – 20.00 |  | 4 |  |  | 5.0 |  | $ | 4.96 |  |  | $ | 97 |  |  | 3 |  |  | $ | 6.15 |  |  | $ | 63 |  |
| $ 20.01 – 25.00 |  | 19 |  |  | 0.3 |  | 23.03 |  |  | 101 |  |  | 19 |  |  | 23.03 |  |  | 101 |  |
| $ 25.01 – 30.00 |  | 14 |  |  | 1.0 |  | 26.83 |  |  | 24 |  |  | 14 |  |  | 26.82 |  |  | 24 |  |
| $ 30.01 – 35.00 |  | 66 |  |  | 1.1 |  | 32.16 |  |  | — |  |  | 66 |  |  | 32.16 |  |  | — |  |
| Total |  | 103 |  |  | 1.1 |  | $ | 28.68 |  |  | $ | 222 |  |  | 102 |  |  | $ | 29.02 |  |  | $ | 188 |  |

[0000858877-15-000070:notes:217]
The aggregate intrinsic value in the preceding table represents the total pretax intrinsic value, based on the Company's closing stock price of $28.40 as of July 24, 2015, that would have been received by the option holders had those option holders exercised their stock options as of that date.  The total number of in-the-money stock options exercisable as of July 25, 2015 was 34 million.  As of July 26, 2014 , 183 million outstanding stock options were exercisable and the weighted-average exercise price was $26.50.

[0000858877-15-000070:notes:218]
| (g) | Valuation of Employee Share-Based Awards |

[0000858877-15-000070:notes:219]
Time-based restricted stock units and PRSUs that are based on the Company’s financial performance metrics or non-financial operating goals are valued using the market value of the Company’s common stock on the date of grant, discounted for the present value of expected dividends. On the date of grant, the Company estimated the fair value of the total shareholder return (TSR) component of the PRSUs using a Monte Carlo simulation model. The assumptions for the valuation of time-based RSUs and PRSUs are summarized as follows:

[0000858877-15-000070:notes:220]
|  | RESTRICTED STOCK UNITS |
| Years Ended | July 25, 2015 |  | July 26, 2014 |  | July 27, 2013 |
| Number of shares granted (in millions) | 55 |  |  | 56 |  |  | 64 |  |
| Grant date fair value per share | $ | 25.30 |  |  | $ | 20.61 |  |  | $ | 18.39 |  |
| Weighted-average assumptions/inputs: |  |  |  |  |  |
| Expected dividend yield | 2.9 | % |  | 3.1 | % |  | 3.0 | % |
| Range of risk-free interest rates | 0.0% – 1.8% |  |  | 0.0% – 1.7% |  |  | 0.0% – 1.1% |  |

[0000858877-15-000070:notes:221]
|  | PERFORMANCE RESTRICTED STOCK UNITS |
| Years Ended | July 25, 2015 |  | July 26, 2014 |  | July 27, 2013 |
| Number of shares granted (in millions) | 11 |  |  | 7 |  |  | 4 |  |
| Grant date fair value per share | $ | 24.85 |  |  | $ | 21.90 |  |  | $ | 19.73 |  |
| Weighted-average assumptions/inputs: |  |  |  |  |  |
| Expected dividend yield | 3.0 | % |  | 3.0 | % |  | 2.9 | % |
| Range of risk-free interest rates | 0.0% – 1.8% |  |  | 0.0% – 1.7% |  |  | 0.1% – 0.7% |  |
| Range of expected volatilities for index | 14.3% – 70.0% |  |  | 14.2% – 70.5% |  |  | 18.3% – 78.3% |  |

[0000858877-15-000070:notes:222]
The PRSUs granted during fiscal 2015, 2014, and 2013 are contingent on the achievement of the Company’s financial performance metrics, its comparative market-based returns, or the achievement of financial and non-financial operating goals.  For the awards based on financial performance metrics or comparative market-based returns, generally 50% of the PRSUs are earned based on the average of annual operating cash flow and earnings per share goals established at the beginning of each fiscal year over a three-year performance period. Generally, the remaining 50% of the PRSUs are earned based on the Company’s TSR measured against the benchmark TSR of a peer group over the same period. Each PRSU recipient could vest in 0% to 150% of the target shares granted contingent on the achievement of the Company's financial performance metrics or its comparative market-based returns, and 0% to 100% of the target shares granted contingent on the achievement of non-financial operating goals.

[0000858877-15-000070:notes:223]
The assumptions for the valuation of employee stock purchase rights are summarized as follows:

[0000858877-15-000070:notes:224]
|  | EMPLOYEE STOCK PURCHASE RIGHTS |
| Years Ended | July 25, 2015 |  | July 26, 2014 |  | July 27, 2013 |
| Weighted-average assumptions: |  |  |  |  |  |
| Expected volatility | 26.0 | % |  | 25.1 | % |  | 28.7 | % |
| Risk-free interest rate | 0.3 | % |  | 0.1 | % |  | 0.4 | % |
| Expected dividend | 2.8 | % |  | 2.8 | % |  | 1.5 | % |
| Expected life (in years) | 1.8 |  |  | 0.8 |  |  | 1.8 |  |
| Weighted-average estimated grant date fair value per share | $ | 6.54 |  |  | $ | 5.54 |  |  | $ | 4.68 |  |

[0000858877-15-000070:notes:225]
The valuation of employee stock purchase rights and the related assumptions are for the employee stock purchases made during the respective fiscal years.

[0000858877-15-000070:notes:226]
The Company uses third-party analyses to assist in developing the assumptions used in, as well as calibrating, its lattice-binomial and Black-Scholes models. The Company is responsible for determining the assumptions used in estimating the fair value of its share-based payment awards.

[0000858877-15-000070:notes:227]
The Company used the implied volatility for traded options (with contract terms corresponding to the expected life of the employee stock purchase rights) on the Company’s stock as the expected volatility assumption required in the Black-Scholes model. The implied volatility is more representative of future stock price trends than historical volatility. The risk-free interest rate assumption is based upon observed interest rates appropriate for the term of the Company’s employee stock purchase rights. The dividend yield assumption is based on the history and expectation of dividend payouts at the grant date.

[0000858877-15-000070:notes:228]
| (h) | Employee 401(k) Plans |

[0000858877-15-000070:notes:229]
The Company sponsors the Cisco Systems, Inc. 401(k) Plan (the “Plan”) to provide retirement benefits for its employees. As allowed under Section 401(k) of the Internal Revenue Code, the Plan provides for tax-deferred salary contributions and after-tax contributions for eligible employees. The Plan allows employees to contribute up to 75% of their annual eligible earnings to the Plan on a pretax and after-tax basis, including Roth contributions. Employee contributions are limited to a maximum annual amount as set periodically by the Internal Revenue Code. The Company matches pretax and Roth employee contributions up to 100% of the first 4.5% of eligible earnings that are contributed by employees. Therefore, the maximum matching contribution that the Company may allocate to each participant’s account will not exceed $11,925 for the 2015 calendar year due to the $265,000 annual limit on eligible earnings imposed by the Internal Revenue Code. All matching contributions vest immediately. The Company’s matching contributions to the Plan totaled $244 million, $236 million, and $234 million in fiscal 2015, 2014, and 2013, respectively.

[0000858877-15-000070:notes:230]
The Plan allows employees who meet the age requirements and reach the Plan contribution limits to make catch-up contributions (pretax or Roth) not to exceed the lesser of 75% of their annual eligible earnings or the limit set forth in the Internal Revenue Code. Catch-up contributions are not eligible for matching contributions. In addition, the Plan provides for discretionary profit-sharing contributions as determined by the Board of Directors. Such contributions to the Plan are allocated among eligible participants in the proportion of their salaries to the total salaries of all participants. There were no discretionary profit-sharing contributions made in fiscal 2015, 2014, and 2013.

[0000858877-15-000070:notes:231]
The Company also sponsors other 401(k) plans as a result of acquisitions of other companies. The Company’s contributions to these plans were not material to the Company on either an individual or aggregate basis for any of the fiscal years presented.

[0000858877-15-000070:notes:232]
| (i) | Deferred Compensation Plans |

[0000858877-15-000070:notes:233]
The Cisco Systems, Inc. Deferred Compensation Plan (the “Deferred Compensation Plan”), a nonqualified deferred compensation plan, became effective in 2007. As required by applicable law, participation in the Deferred Compensation Plan is limited to a select group of the Company’s management employees. Under the Deferred Compensation Plan, which is an unfunded and unsecured deferred compensation arrangement, a participant may elect to defer base salary, bonus, and/or commissions, pursuant to such rules as may be established by the Company, up to the maximum percentages for each deferral election as described in the plan. The Company may also, at its discretion, make a matching contribution to the employee under the Deferred Compensation Plan. A matching contribution equal to 4.5% of eligible compensation in excess of the Internal Revenue Code limit for qualified plans for calendar year 2015 that is deferred by participants under the Deferred Compensation Plan (with a $1.5 million cap on eligible compensation) will be made to eligible participants’ accounts at the end of calendar year 2015. The deferred compensation liability under the Deferred Compensation Plan, together with a deferred compensation plan assumed from Scientific-Atlanta, was approximately $536 million and $509 million as of July 25, 2015 and July 26, 2014, respectively, and was recorded primarily in other long-term liabilities.


## us-gaap:EarningsPerSharePolicyTextBlock

[0000858877-15-000070:notes:234]
(t) Computation of Net Income per Share   Basic net income per share is computed using the weighted-average number of common shares outstanding during the period. Diluted net income per share is computed using the weighted-average number of common shares and dilutive potential common shares outstanding during the period. Diluted shares outstanding includes the dilutive effect of in-the-money options, unvested restricted stock, and restricted stock units. The dilutive effect of such equity awards is calculated based on the average share price for each fiscal period using the treasury stock method. Under the treasury stock method, the amount the employee must pay for exercising stock options, the amount of compensation cost for future service that the Company has not yet recognized, and the amount of tax benefits that would be recorded in additional paid-in capital when the award becomes deductible are collectively assumed to be used to repurchase shares.


## us-gaap:EarningsPerShareTextBlock

[0000858877-15-000070:notes:235]
| 18. | Net Income per Share |

[0000858877-15-000070:notes:236]
The following table presents the calculation of basic and diluted net income per share (in millions, except per-share amounts):

[0000858877-15-000070:notes:237]
| Years Ended | July 25, 2015 |  | July 26, 2014 |  | July 27, 2013 |
| Net income | $ | 8,981 |  |  | $ | 7,853 |  |  | $ | 9,983 |  |
| Weighted-average shares—basic | 5,104 |  |  | 5,234 |  |  | 5,329 |  |
| Effect of dilutive potential common shares | 42 |  |  | 47 |  |  | 51 |  |
| Weighted-average shares—diluted | 5,146 |  |  | 5,281 |  |  | 5,380 |  |
| Net income per share—basic | $ | 1.76 |  |  | $ | 1.50 |  |  | $ | 1.87 |  |
| Net income per share—diluted | $ | 1.75 |  |  | $ | 1.49 |  |  | $ | 1.86 |  |
| Antidilutive employee share-based awards, excluded | 183 |  |  | 254 |  |  | 407 |  |

[0000858877-15-000070:notes:238]
Employee equity share options, unvested shares, and similar equity instruments granted by the Company are treated as potential common shares outstanding in computing diluted earnings per share. Diluted shares outstanding include the dilutive effect of in-the-money options, unvested restricted stock, and restricted stock units. The dilutive effect of such equity awards is calculated based on the average share price for each fiscal period using the treasury stock method. Under the treasury stock method, the amount the employee must pay for exercising stock options, the amount of compensation cost for future service that the Company has not yet recognized, and the amount of tax benefits that would be recorded in additional paid-in capital when the award becomes deductible are collectively assumed to be used to repurchase shares.


## us-gaap:EquityMethodInvestmentsTextBlock

[0000858877-15-000070:notes:239]
|  | July 25, 2015 |  | July 26, 2014 |
| Equity method investments | $ | 578 |  |  | $ | 630 |  |
| Cost method investments | 319 |  |  | 269 |  |
| Total | $ | 897 |  |  | $ | 899 |  |


## us-gaap:FairValueAssetsMeasuredOnNonrecurringBasisTextBlock

[0000858877-15-000070:notes:240]
The following table presents the Company’s assets that were measured at fair value on a nonrecurring basis during the indicated periods and the related recognized gains and losses for the periods indicated (in millions):

[0000858877-15-000070:notes:241]
|  | TOTAL GAINS (LOSSES) FOR THE YEARS ENDED |
|  | July 25, 2015 |  | July 26, 2014 |  | July 27, 2013 |
| Investments in privately held companies (impaired) | $ | (38 | ) |  | $ | (21 | ) |  | $ | (31 | ) |
| Purchased intangible assets (impaired) | (175 | ) |  | — |  |  | — |  |
| Property held for sale—land and buildings | — |  |  | — |  |  | (1 | ) |
| Gains (losses) on assets no longer held at end of fiscal year | (8 | ) |  | (2 | ) |  | 75 |  |
| Total gains (losses) for nonrecurring measurements | $ | (221 | ) |  | $ | (23 | ) |  | $ | 43 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000858877-15-000070:notes:242]
| 9. | Fair Value |

[0000858877-15-000070:notes:243]
| (a) | Assets and Liabilities Measured at Fair Value on a Recurring Basis |

[0000858877-15-000070:notes:244]
Assets and liabilities measured at fair value on a recurring basis as of July 25, 2015 and July 26, 2014 were as follows (in millions):

[0000858877-15-000070:notes:245]
|  | JULY 25, 2015 |  | JULY 26, 2014 |
|  | FAIR VALUE MEASUREMENTS |  | FAIR VALUE MEASUREMENTS |
|  | Level 1 |  | Level 2 |  | Level 3 |  | TotalBalance |  | Level 1 |  | Level 2 |  | Level 3 |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 5,336 |  |  | $ | — |  |  | $ | — |  |  | $ | 5,336 |  |  | $ | 4,935 |  |  | $ | — |  |  | $ | — |  |  | $ | 4,935 |  |
| Corporate debt securities | — |  |  | 14 |  |  | — |  |  | 14 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Available-for-sale investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | — |  |  | 29,939 |  |  | — |  |  | 29,939 |  |  | — |  |  | 31,734 |  |  | — |  |  | 31,734 |  |
| U.S. government agency securities | — |  |  | 3,663 |  |  | — |  |  | 3,663 |  |  | — |  |  | 1,063 |  |  | — |  |  | 1,063 |  |
| Non-U.S. government and agency securities | — |  |  | 1,128 |  |  | — |  |  | 1,128 |  |  | — |  |  | 861 |  |  | — |  |  | 861 |  |
| Corporate debt securities | — |  |  | 15,783 |  |  | — |  |  | 15,783 |  |  | — |  |  | 9,159 |  |  | — |  |  | 9,159 |  |
| U.S. agency mortgage-backed securities | — |  |  | 1,461 |  |  | — |  |  | 1,461 |  |  | — |  |  | 579 |  |  | — |  |  | 579 |  |
| Publicly traded equity securities | 1,565 |  |  | — |  |  | — |  |  | 1,565 |  |  | 1,952 |  |  | — |  |  | — |  |  | 1,952 |  |
| Derivative assets | — |  |  | 214 |  |  | 4 |  |  | 218 |  |  | — |  |  | 158 |  |  | 2 |  |  | 160 |  |
| Total | $ | 6,901 |  |  | $ | 52,202 |  |  | $ | 4 |  |  | $ | 59,107 |  |  | $ | 6,887 |  |  | $ | 43,554 |  |  | $ | 2 |  |  | $ | 50,443 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities | $ | — |  |  | $ | 12 |  |  | $ | — |  |  | $ | 12 |  |  | $ | — |  |  | $ | 67 |  |  | $ | — |  |  | $ | 67 |  |
| Total | $ | — |  |  | $ | 12 |  |  | $ | — |  |  | $ | 12 |  |  | $ | — |  |  | $ | 67 |  |  | $ | — |  |  | $ | 67 |  |

[0000858877-15-000070:notes:246]
Level 1 publicly traded equity securities are determined by using quoted prices in active markets for identical assets.  Level 2 fixed income securities are priced using quoted market prices for similar instruments or nonbinding market prices that are corroborated by observable market data. The Company uses inputs such as actual trade data, benchmark yields, broker/dealer quotes, and other similar data, which are obtained from quoted market prices, independent pricing vendors, or other sources, to determine the ultimate fair value of these assets and liabilities. The Company uses such pricing data as the primary input to make its assessments and determinations as to the ultimate valuation of its investment portfolio and has not made, during the periods presented, any material adjustments to such inputs. The Company is ultimately responsible for the financial statements and underlying estimates. The Company’s derivative instruments are primarily classified as Level 2, as they are not actively traded and are valued using pricing models that use observable market inputs. The Company did not have any transfers between Level 1 and Level 2 fair value measurements during the periods presented.

[0000858877-15-000070:notes:247]
Level 3 assets include certain derivative instruments, the values of which are determined based on discounted cash flow models using inputs that the Company could not corroborate with market data.

[0000858877-15-000070:notes:248]
| (b) | Assets Measured at Fair Value on a Nonrecurring Basis |

[0000858877-15-000070:notes:249]
These assets were measured at fair value due to events or circumstances the Company identified as having significant impact on their fair value during the respective periods.  To arrive at the valuation of these assets, the Company considers any significant changes in the financial metrics and economic variables and also uses third-party valuation reports to assist in the valuation as necessary.

[0000858877-15-000070:notes:250]
The fair value measurement of the impaired investments was classified as Level 3 because significant unobservable inputs were used in the valuation due to the absence of quoted market prices and inherent lack of liquidity.  Significant unobservable inputs, which included financial metrics of comparable private and public companies, financial condition and near-term prospects of the investees, recent  financing activities of the investees, and the investees’ capital structure as well as other economic variables, reflected the assumptions market participants would use in pricing these assets.  The impairment charges, representing the difference between the net book value and the fair value as a result of the evaluation, were recorded to other income (loss), net.  The remaining carrying value of the investments that were impaired was $36 million as of July 25, 2015.

[0000858877-15-000070:notes:251]
The fair value for purchased intangibles assets measured at fair value on a nonrecurring basis was categorized as Level 3 due to the use of significant unobservable inputs in the valuation.  Significant unobservable inputs that were used included expected revenues and net income related to the assets and the expected life of the assets.  The difference between the estimated fair value and the carrying value of the assets was recorded as an impairment charge, which was included in product cost of sales and operating expenses as applicable.  See Note 4.  The remaining carrying value of the specific purchased intangible assets that were impaired was $5 million as of July 25, 2015.

[0000858877-15-000070:notes:252]
The fair value of property held for sale was measured with the assistance of third-party valuation models, which used discounted cash flow techniques as part of their analysis.  The fair value measurement was categorized as Level 3, as significant unobservable inputs were used in the valuation report.  The impairment charges as a result of the valuations, which represented the difference between the fair value less cost to sell and the carrying amount of the assets held for sale, were included in G&A expenses.

[0000858877-15-000070:notes:253]
| (c) | Other Fair Value Disclosures |

[0000858877-15-000070:notes:254]
The carrying value of the Company’s investments in privately held companies that were accounted for under the cost method was $319 million and $269 million as of July 25, 2015 and July 26, 2014, respectively. It was not practicable to estimate the fair value of this portfolio.

[0000858877-15-000070:notes:255]
The fair value of the Company’s short-term loan receivables and financed service contracts approximates their carrying value due to their short duration.  The aggregate carrying value of the Company’s long-term loan receivables and financed service contracts and other as of July 25, 2015 and July 26, 2014 was $2.2 billion and $2.1 billion, respectively.  The estimated fair value of the Company’s long-term loan receivables and financed service contracts and other approximates their carrying value. The Company uses significant unobservable inputs in determining discounted cash flows to estimate the fair value of its long-term loan receivables and financed service contracts, and therefore they are categorized as Level 3.

[0000858877-15-000070:notes:256]
As of July 25, 2015 and July 26, 2014, the estimated fair value of the short-term debt approximates its carrying value due to the short maturities.  As of July 25, 2015, the fair value of the Company’s senior notes and other long-term debt was $26.6 billion, with a carrying amount of $25.4 billion.  This compares to a fair value of $22.4 billion and a carrying amount of $20.8 billion as of July 26, 2014.  The fair value of the senior notes and other long-term debt was determined based on observable market prices in a less active market and was categorized as Level 2 in the fair value hierarchy.


## us-gaap:FinancingReceivableCreditQualityIndicatorsTableTextBlock

[0000858877-15-000070:notes:257]
Gross receivables less unearned income categorized by the Company’s internal credit risk rating as of July 25, 2015 and July 26, 2014 are summarized as follows (in millions):

[0000858877-15-000070:notes:258]
|  | INTERNAL CREDIT RISK RATING |
| July 25, 2015 | 1 to 4 |  | 5 to 6 |  | 7 and Higher |  | Total |
| Lease receivables | $ | 1,688 |  |  | $ | 1,342 |  |  | $ | 141 |  |  | $ | 3,171 |  |
| Loan receivables | 788 |  |  | 823 |  |  | 152 |  |  | 1,763 |  |
| Financed service contracts and other | 2,133 |  |  | 1,389 |  |  | 51 |  |  | 3,573 |  |
| Total | $ | 4,609 |  |  | $ | 3,554 |  |  | $ | 344 |  |  | $ | 8,507 |  |

[0000858877-15-000070:notes:259]
|  | INTERNAL CREDIT RISK RATING |
| July 26, 2014 | 1 to 4 |  | 5 to 6 |  | 7 and Higher |  | Total |
| Lease receivables | $ | 1,615 |  |  | $ | 1,538 |  |  | $ | 141 |  |  | $ | 3,294 |  |
| Loan receivables | 953 |  |  | 593 |  |  | 137 |  |  | 1,683 |  |
| Financed service contracts and other | 1,744 |  |  | 1,367 |  |  | 99 |  |  | 3,210 |  |
| Total | $ | 4,312 |  |  | $ | 3,498 |  |  | $ | 377 |  |  | $ | 8,187 |  |


## us-gaap:FinancingReceivablesTextBlock

[0000858877-15-000070:notes:260]
| 7. | Financing Receivables and Operating Leases |

[0000858877-15-000070:notes:261]
| (a) | Financing Receivables |

[0000858877-15-000070:notes:262]
Financing receivables primarily consist of lease receivables, loan receivables, and financed service contracts and other. Lease receivables represent sales-type and direct-financing leases resulting from the sale of the Company’s and complementary third-party products and are typically collateralized by a security interest in the underlying assets. Loan receivables represent financing arrangements related to the sale of the Company’s products and services, which may include additional funding for other costs associated with network installation and integration of the Company’s products and services. Lease receivables consist of arrangements with terms of four years on average, while loan receivables generally have terms of up to three years. The financed service contracts and other category includes financing receivables related to technical support and advanced services, as well as receivables related to financing of certain indirect costs associated with leases. Revenue related to the technical support services is typically deferred and included in deferred service revenue and is recognized ratably over the period during which the related services are to be performed, which typically ranges from one to three years.

[0000858877-15-000070:notes:263]
A summary of the Company's financing receivables is presented as follows (in millions):

[0000858877-15-000070:notes:264]
| July 25, 2015 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts and Other |  | Total |
| Gross | $ | 3,361 |  |  | $ | 1,763 |  |  | $ | 3,573 |  |  | $ | 8,697 |  |
| Residual value | 224 |  |  | — |  |  | — |  |  | 224 |  |
| Unearned income | (190 | ) |  | — |  |  | — |  |  | (190 | ) |
| Allowance for credit loss | (259 | ) |  | (87 | ) |  | (36 | ) |  | (382 | ) |
| Total, net | $ | 3,136 |  |  | $ | 1,676 |  |  | $ | 3,537 |  |  | $ | 8,349 |  |
| Reported as: |  |  |  |  |  |  |  |
| Current | $ | 1,468 |  |  | $ | 856 |  |  | $ | 2,167 |  |  | $ | 4,491 |  |
| Noncurrent | 1,668 |  |  | 820 |  |  | 1,370 |  |  | 3,858 |  |
| Total, net | $ | 3,136 |  |  | $ | 1,676 |  |  | $ | 3,537 |  |  | $ | 8,349 |  |

[0000858877-15-000070:notes:265]
| July 26, 2014 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts and Other |  | Total |
| Gross | $ | 3,532 |  |  | $ | 1,683 |  |  | $ | 3,210 |  |  | $ | 8,425 |  |
| Residual value | 233 |  |  | — |  |  | — |  |  | 233 |  |
| Unearned income | (238 | ) |  | — |  |  | — |  |  | (238 | ) |
| Allowance for credit loss | (233 | ) |  | (98 | ) |  | (18 | ) |  | (349 | ) |
| Total, net | $ | 3,294 |  |  | $ | 1,585 |  |  | $ | 3,192 |  |  | $ | 8,071 |  |
| Reported as: |  |  |  |  |  |  |  |
| Current | $ | 1,476 |  |  | $ | 728 |  |  | $ | 1,949 |  |  | $ | 4,153 |  |
| Noncurrent | 1,818 |  |  | 857 |  |  | 1,243 |  |  | 3,918 |  |
| Total, net | $ | 3,294 |  |  | $ | 1,585 |  |  | $ | 3,192 |  |  | $ | 8,071 |  |

[0000858877-15-000070:notes:266]
As of July 25, 2015 and July 26, 2014, the deferred service revenue related to "Financed Service Contracts and Other" was $1,853 million and $1,843 million, respectively.

[0000858877-15-000070:notes:267]
Future minimum lease payments to be received as of July 25, 2015 are summarized as follows (in millions):

[0000858877-15-000070:notes:268]
| Fiscal Year | Amount |
| 2016 | $ | 1,613 |  |
| 2017 | 999 |  |
| 2018 | 503 |  |
| 2019 | 202 |  |
| 2020 | 44 |  |
| Total | $ | 3,361 |  |

[0000858877-15-000070:notes:269]
Actual cash collections may differ from the contractual maturities due to early customer buyouts, refinancings, or defaults.

[0000858877-15-000070:notes:270]
| (b) | Credit Quality of Financing Receivables |

[0000858877-15-000070:notes:271]
The Company determines the adequacy of its allowance for credit loss by assessing the risks and losses inherent in its financing receivables by portfolio segment. The portfolio segment is based on the types of financing offered by the Company to its customers, which consist of the following: lease receivables, loan receivables, and financed service contracts and other.

[0000858877-15-000070:notes:272]
The Company’s internal credit risk ratings of 1 through 4 correspond to investment-grade ratings, while credit risk ratings of 5 and 6 correspond to non-investment grade ratings. Credit risk ratings of 7 and higher correspond to substandard ratings.

[0000858877-15-000070:notes:273]
In circumstances when collectibility is not deemed reasonably assured, the associated revenue is deferred in accordance with the Company’s revenue recognition policies, and the related allowance for credit loss, if any, is included in deferred revenue. The Company also records deferred revenue associated with financing receivables when there are remaining performance obligations, as it does for financed service contracts. Total allowances for credit loss and deferred revenue as of July 25, 2015 and July 26, 2014 were $2,253 million and $2,220 million, respectively, and they were associated with total financing receivables before allowance for credit loss of $8,731 million and $8,420 million as of their respective period ends.

[0000858877-15-000070:notes:274]
The following tables present the aging analysis of gross receivables less unearned income as of July 25, 2015 and July 26, 2014 (in millions):

[0000858877-15-000070:notes:275]
|  | DAYS PAST DUE (INCLUDES BILLED AND UNBILLED) |  |  |  |  |  |  |  |  |
| July 25, 2015 | 31 - 60 |  | 61 - 90 |  | 91+ |  | TotalPast Due |  | Current |  | Total |  | NonaccrualFinancingReceivables |  | ImpairedFinancingReceivables |
| Lease receivables | $ | 90 |  |  | $ | 27 |  |  | $ | 185 |  |  | $ | 302 |  |  | $ | 2,869 |  |  | $ | 3,171 |  |  | $ | 73 |  |  | $ | 73 |  |
| Loan receivables | 21 |  |  | 3 |  |  | 25 |  |  | 49 |  |  | 1,714 |  |  | 1,763 |  |  | 32 |  |  | 32 |  |
| Financed service contracts and other | 396 |  |  | 152 |  |  | 414 |  |  | 962 |  |  | 2,611 |  |  | 3,573 |  |  | 29 |  |  | 9 |  |
| Total | $ | 507 |  |  | $ | 182 |  |  | $ | 624 |  |  | $ | 1,313 |  |  | $ | 7,194 |  |  | $ | 8,507 |  |  | $ | 134 |  |  | $ | 114 |  |

[0000858877-15-000070:notes:276]
|  | DAYS PAST DUE (INCLUDES BILLED AND UNBILLED) |  |  |  |  |  |  |  |  |
| July 26, 2014 | 31 - 60 |  | 61 - 90 |  | 91+ |  | TotalPast Due |  | Current |  | Total |  | NonaccrualFinancingReceivables |  | ImpairedFinancingReceivables |
| Lease receivables | $ | 63 |  |  | $ | 46 |  |  | $ | 202 |  |  | $ | 311 |  |  | $ | 2,983 |  |  | $ | 3,294 |  |  | $ | 48 |  |  | $ | 41 |  |
| Loan receivables | 3 |  |  | 21 |  |  | 27 |  |  | 51 |  |  | 1,632 |  |  | 1,683 |  |  | 19 |  |  | 19 |  |
| Financed service contracts and other | 268 |  |  | 230 |  |  | 220 |  |  | 718 |  |  | 2,492 |  |  | 3,210 |  |  | 12 |  |  | 9 |  |
| Total | $ | 334 |  |  | $ | 297 |  |  | $ | 449 |  |  | $ | 1,080 |  |  | $ | 7,107 |  |  | $ | 8,187 |  |  | $ | 79 |  |  | $ | 69 |  |

[0000858877-15-000070:notes:277]
Past due financing receivables are those that are 31 days or more past due according to their contractual payment terms. The data in the preceding tables is presented by contract, and the aging classification of each contract is based on the oldest outstanding receivable, and therefore past due amounts also include unbilled and current receivables within the same contract. The balances of either unbilled or current financing receivables included in the category of 91 days plus past due for financing receivables were $496 million and $334 million as of July 25, 2015 and July 26, 2014, respectively.

[0000858877-15-000070:notes:278]
As of July 25, 2015, the Company had financing receivables of $70 million, net of unbilled or current receivables from the same contract, that were in the category of 91 days plus past due but remained on accrual status as they are well secured and in the process of collection. Such balance was $78 million as of July 26, 2014.

[0000858877-15-000070:notes:279]
| (c) | Allowance for Credit Loss Rollforward |

[0000858877-15-000070:notes:280]
| (d) | Operating Leases |

[0000858877-15-000070:notes:281]
The Company provides financing of certain equipment through operating leases, and the amounts are included in property and equipment in the Consolidated Balance Sheets.  Amounts relating to equipment on operating lease assets and the associated accumulated depreciation are summarized as follows (in millions):

[0000858877-15-000070:notes:282]
|  | July 25, 2015 |  | July 26, 2014 |
| Operating lease assets | $ | 372 |  |  | $ | 362 |  |
| Accumulated depreciation | (205 | ) |  | (202 | ) |
| Operating lease assets, net | $ | 167 |  |  | $ | 160 |  |

[0000858877-15-000070:notes:283]
Minimum future rentals on non-cancelable operating leases at July 25, 2015 are approximately $0.2 billion for fiscal 2016, $0.1 billion for fiscal 2017, and less than $0.1 billion per year for each of fiscal 2018 through fiscal 2020.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0000858877-15-000070:notes:284]
(m) Foreign Currency Translation   Assets and liabilities of non-U.S. subsidiaries that operate in a local currency environment, where that local currency is the functional currency, are translated to U.S. dollars at exchange rates in effect at the balance sheet date, with the resulting translation adjustments directly recorded to a separate component of AOCI. Income and expense accounts are translated at average exchange rates during the year.  Remeasurement adjustments are recorded in other income (loss), net. The effect of foreign currency exchange rates on cash and cash equivalents was not material for any of the fiscal years presented.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000858877-15-000070:notes:285]
| 4. | Goodwill and Purchased Intangible Assets |

[0000858877-15-000070:notes:286]
| (a) | Goodwill |

[0000858877-15-000070:notes:287]
The following tables present the goodwill allocated to the Company’s reportable segments as of July 25, 2015 and July 26, 2014, as well as the changes to goodwill during fiscal 2015 and 2014 (in millions):

[0000858877-15-000070:notes:288]
|  | Balance at July 26, 2014 |  | Acquisitions |  | Other |  | Balance at July 25, 2015 |
| Americas | $ | 15,080 |  |  | $ | 145 |  |  | $ | (13 | ) |  | $ | 15,212 |  |
| EMEA | 5,715 |  |  | 84 |  |  | (8 | ) |  | 5,791 |  |
| APJC | 3,444 |  |  | 26 |  |  | (4 | ) |  | 3,466 |  |
| Total | $ | 24,239 |  |  | $ | 255 |  |  | $ | (25 | ) |  | $ | 24,469 |  |

[0000858877-15-000070:notes:289]
|  | Balance at July 27, 2013 |  | Acquisitions |  | Other |  | Balance at July 26, 2014 |
| Americas | $ | 13,800 |  |  | $ | 1,275 |  |  | $ | 5 |  |  | $ | 15,080 |  |
| EMEA | 5,037 |  |  | 681 |  |  | (3 | ) |  | 5,715 |  |
| APJC | 3,082 |  |  | 362 |  |  | — |  |  | 3,444 |  |
| Total | $ | 21,919 |  |  | $ | 2,318 |  |  | $ | 2 |  |  | $ | 24,239 |  |

[0000858877-15-000070:notes:290]
“Other” in the tables above primarily consists of purchase accounting adjustments.

[0000858877-15-000070:notes:291]
| (b) | Purchased Intangible Assets |

[0000858877-15-000070:notes:292]
Purchased intangible assets include intangible assets acquired through business combinations as well as through direct purchases or licenses.  In fiscal 2015, the Company, along with a number of other companies, entered into an agreement to obtain a license to the patents owned by the Rockstar Consortium, and the Company paid approximately $300 million, of which $188 million was expensed to product cost of sales related to the settlement of patent infringement claims, and the remainder was capitalized as an intangible asset to be amortized over its estimated useful life.

[0000858877-15-000070:notes:293]
Amortization of purchased intangible assets for fiscal 2015 included impairment charges of approximately $175 million as a result of declines in estimated fair value resulting from the reduction or elimination of expected future cash flows associated with certain of the Company’s technology and IPR&D intangible assets.  There were no impairment charges related to purchased intangible assets during fiscal 2014 and 2013.

[0000858877-15-000070:notes:294]
The estimated future amortization expense of purchased intangible assets with finite lives as of July 25, 2015 is as follows (in millions):

[0000858877-15-000070:notes:295]
| Fiscal Year | Amount |
| 2016 | $ | 770 |  |
| 2017 | 596 |  |
| 2018 | 453 |  |
| 2019 | 357 |  |
| 2020 | 140 |  |
| Thereafter | 43 |  |
| Total | $ | 2,359 |  |


## us-gaap:GoodwillAndIntangibleAssetsPolicyTextBlock

[0000858877-15-000070:notes:296]
(i) Goodwill and Purchased Intangible Assets   Goodwill is tested for impairment on an annual basis in the fourth fiscal quarter and, when specific circumstances dictate, between annual tests. When impaired, the carrying value of goodwill is written down to fair value. The goodwill impairment test involves a two-step process. The first step, identifying a potential impairment, compares the fair value of a reporting unit with its carrying amount, including goodwill. If the carrying value of the reporting unit exceeds its fair value, the second step would need to be conducted; otherwise, no further steps are necessary as no potential impairment exists. If necessary, the second step to measure the impairment loss would be to compare the implied fair value of the reporting unit goodwill with the carrying amount of that goodwill. Any excess of the reporting unit goodwill carrying value over the respective implied fair value is recognized as an impairment loss. Purchased intangible assets with finite lives are carried at cost, less accumulated amortization. Amortization is computed over the estimated useful lives of the respective assets. See “Long-Lived Assets” for the Company’s policy regarding impairment testing of purchased intangible assets with finite lives. Purchased intangible assets with indefinite lives are assessed for potential impairment annually or when events or circumstances indicate that their carrying amounts might be impaired.


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsPolicyTextBlock

[0000858877-15-000070:notes:297]
(j) Long-Lived Assets   Long-lived assets that are held and used by the Company are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of such assets may not be recoverable. Determination of recoverability of long-lived assets is based on an estimate of the undiscounted future cash flows resulting from the use of the asset and its eventual disposition. Measurement of an impairment loss for long-lived assets that management expects to hold and use is based on the difference between the fair value of the asset and its carrying value. Long-lived assets to be disposed of are reported at the lower of carrying amount or fair value less costs to sell.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000858877-15-000070:notes:298]
| 16. | Income Taxes |

[0000858877-15-000070:notes:299]
| (a) | Provision for Income Taxes |

[0000858877-15-000070:notes:300]
The provision for income taxes consists of the following (in millions):

[0000858877-15-000070:notes:301]
| Years Ended | July 25, 2015 |  | July 26, 2014 |  | July 27, 2013 |
| Federal: |  |  |  |  |  |
| Current | $ | 1,583 |  |  | $ | 1,672 |  |  | $ | 601 |  |
| Deferred | 43 |  |  | (383 | ) |  | 152 |  |
|  | 1,626 |  |  | 1,289 |  |  | 753 |  |
| State: |  |  |  |  |  |
| Current | 130 |  |  | 176 |  |  | 81 |  |
| Deferred | (20 | ) |  | (64 | ) |  | 48 |  |
|  | 110 |  |  | 112 |  |  | 129 |  |
| Foreign: |  |  |  |  |  |
| Current | 530 |  |  | 692 |  |  | 599 |  |
| Deferred | (46 | ) |  | (231 | ) |  | (237 | ) |
|  | 484 |  |  | 461 |  |  | 362 |  |
| Total | $ | 2,220 |  |  | $ | 1,862 |  |  | $ | 1,244 |  |

[0000858877-15-000070:notes:302]
Income before provision for income taxes consists of the following (in millions):

[0000858877-15-000070:notes:303]
| Years Ended | July 25, 2015 |  | July 26, 2014 |  | July 27, 2013 |
| United States | $ | 3,570 |  |  | $ | 2,734 |  |  | $ | 3,716 |  |
| International | 7,631 |  |  | 6,981 |  |  | 7,511 |  |
| Total | $ | 11,201 |  |  | $ | 9,715 |  |  | $ | 11,227 |  |

[0000858877-15-000070:notes:304]
The items accounting for the difference between income taxes computed at the federal statutory rate and the provision for income taxes consist of the following:

[0000858877-15-000070:notes:305]
| Years Ended | July 25, 2015 |  | July 26, 2014 |  | July 27, 2013 |
| Federal statutory rate | 35.0 | % |  | 35.0 | % |  | 35.0 | % |
| Effect of: |  |  |  |  |  |
| State taxes, net of federal tax benefit | 0.8 |  |  | 0.5 |  |  | 0.8 |  |
| Foreign income at other than U.S. rates | (15.2 | ) |  | (16.4 | ) |  | (16.4 | ) |
| Tax credits | (1.2 | ) |  | (0.7 | ) |  | (1.6 | ) |
| Domestic manufacturing deduction | (0.7 | ) |  | (0.9 | ) |  | (1.0 | ) |
| Nondeductible compensation | 2.0 |  |  | 3.3 |  |  | 1.3 |  |
| Tax audit settlement | — |  |  | — |  |  | (7.1 | ) |
| Other, net | (0.9 | ) |  | (1.6 | ) |  | 0.1 |  |
| Total | 19.8 | % |  | 19.2 | % |  | 11.1 | % |

[0000858877-15-000070:notes:306]
During fiscal 2015, the Tax Increase Prevention Act of 2014 reinstated the U.S. federal R&D tax credit for calendar year 2014 R&D expenses.  As a result, the tax provision in fiscal 2015 included a tax benefit of $138 million related to the U.S. R&D tax credit, of which $78 million was attributable to fiscal 2014.

[0000858877-15-000070:notes:307]
During fiscal 2013, the Internal Revenue Service (IRS) and the Company settled all outstanding items related to the audit of the Company’s federal income tax returns for the fiscal years ended July 27, 2002 through July 28, 2007.  As a result of the settlement, the Company recognized a net benefit to the provision for income taxes of $794 million.  In addition, the American Taxpayer Relief Act reinstated the U.S. federal R&D credit through December 2013, retroactive to January 1, 2012. As a result, the tax provision in fiscal 2013 included a tax benefit of $184 million related to the U.S. federal R&D tax credit, of which $72 million was attributable to fiscal 2012.

[0000858877-15-000070:notes:308]
U.S. income taxes and foreign withholding taxes associated with the repatriation of earnings of foreign subsidiaries were not provided for on a cumulative total of $58.0 billion of undistributed earnings for certain foreign subsidiaries as of the end of fiscal 2015. The Company intends to reinvest these earnings indefinitely in its foreign subsidiaries. If these earnings were distributed to the United States in the form of dividends or otherwise, or if the shares of the relevant foreign subsidiaries were sold or otherwise transferred, the Company would be subject to additional U.S. income taxes (subject to an adjustment for foreign tax credits) and foreign withholding taxes. Determination of the amount of unrecognized deferred income tax liability related to these earnings is not practicable.

[0000858877-15-000070:notes:309]
As a result of certain employment and capital investment actions, the Company’s income in certain foreign countries is subject to reduced tax rates and in some cases is wholly exempt from taxes.  A portion of these incentives expired at the end of fiscal 2015.  The majority of the remaining tax incentives will expire at the end of fiscal 2025.  The gross income tax benefit attributable to tax incentives was estimated to be $1.4 billion ($0.28 per diluted share) in fiscal 2015, of which approximately $0.5 billion ($0.10 per diluted share) is based on tax incentives that expired at the end of fiscal 2015.  As of the end of fiscal 2014 and fiscal 2013, the gross income tax benefits attributable to tax incentives were estimated to be $1.3 billion and $1.4 billion ($0.25 and $0.26 per diluted share) for the respective years. The gross income tax benefits were partially offset by accruals of U.S. income taxes on undistributed earnings.

[0000858877-15-000070:notes:310]
Unrecognized Tax Benefits

[0000858877-15-000070:notes:311]
The aggregate changes in the balance of gross unrecognized tax benefits were as follows (in millions):

[0000858877-15-000070:notes:312]
| Years Ended | July 25, 2015 |  | July 26, 2014 |  | July 27, 2013 |
| Beginning balance | $ | 1,938 |  |  | $ | 1,775 |  |  | $ | 2,819 |  |
| Additions based on tax positions related to the current year | 276 |  |  | 262 |  |  | 138 |  |
| Additions for tax positions of prior years | 137 |  |  | 64 |  |  | 187 |  |
| Reductions for tax positions of prior years | (30 | ) |  | (13 | ) |  | (1,027 | ) |
| Settlements | (165 | ) |  | (17 | ) |  | (199 | ) |
| Lapse of statute of limitations | (127 | ) |  | (133 | ) |  | (143 | ) |
| Ending balance | $ | 2,029 |  |  | $ | 1,938 |  |  | $ | 1,775 |  |

[0000858877-15-000070:notes:313]
As of July 25, 2015, $1.7 billion of the unrecognized tax benefits would affect the effective tax rate if realized. During fiscal 2015 the Company recognized $27 million of net interest expense and $3 million of penalties.  During fiscal 2014, the Company recognized $29 million of net interest expense and $8 million of penalties.  During fiscal 2013, the Company recognized $115 million of net interest expense and $2 million of penalties. The Company’s total accrual for interest and penalties was $274 million, $304 million, and $268 million as of the end of fiscal 2015, 2014, and 2013, respectively. The Company is no longer subject to U.S. federal income tax audit for returns covering tax years through fiscal 2007. With limited exceptions, the Company is no longer subject to foreign, state, or local income tax audits for returns covering tax years through fiscal 2002.

[0000858877-15-000070:notes:314]
The Company regularly engages in discussions and negotiations with tax authorities regarding tax matters in various jurisdictions. The Company believes it is reasonably possible that certain federal, foreign, and state tax matters may be concluded in the next 12 months.  Specific positions that may be resolved include issues involving transfer pricing and various other matters. The Company estimates that the unrecognized tax benefits at July 25, 2015 could be reduced by approximately $900 million in the next 12 months, a portion of which could increase earnings.

[0000858877-15-000070:notes:315]
| (b) | Deferred Tax Assets and Liabilities |

[0000858877-15-000070:notes:316]
The following table presents the breakdown between current and noncurrent net deferred tax assets (in millions):

[0000858877-15-000070:notes:317]
|  | July 25, 2015 |  | July 26, 2014 |
| Deferred tax assets—current | $ | 2,915 |  |  | $ | 2,808 |  |
| Deferred tax liabilities—current | (212 | ) |  | (134 | ) |
| Deferred tax assets—noncurrent | 1,648 |  |  | 1,700 |  |
| Deferred tax liabilities—noncurrent | (246 | ) |  | (369 | ) |
| Total net deferred tax assets | $ | 4,105 |  |  | $ | 4,005 |  |

[0000858877-15-000070:notes:318]
The components of the deferred tax assets and liabilities are as follows (in millions):

[0000858877-15-000070:notes:319]
|  | July 25, 2015 |  | July 26, 2014 |
| ASSETS |  |  |  |
| Allowance for doubtful accounts and returns | $ | 417 |  |  | $ | 464 |  |
| Sales-type and direct-financing leases | 266 |  |  | 231 |  |
| Inventory write-downs and capitalization | 345 |  |  | 307 |  |
| Investment provisions | 112 |  |  | 212 |  |
| IPR&D, goodwill, and purchased intangible assets | 134 |  |  | 135 |  |
| Deferred revenue | 1,795 |  |  | 1,689 |  |
| Credits and net operating loss carryforwards | 746 |  |  | 796 |  |
| Share-based compensation expense | 520 |  |  | 661 |  |
| Accrued compensation | 467 |  |  | 496 |  |
| Other | 670 |  |  | 676 |  |
| Gross deferred tax assets | 5,472 |  |  | 5,667 |  |
| Valuation allowance | (84 | ) |  | (114 | ) |
| Total deferred tax assets | 5,388 |  |  | 5,553 |  |
| LIABILITIES |  |  |  |
| Purchased intangible assets | (950 | ) |  | (1,229 | ) |
| Depreciation | (143 | ) |  | (48 | ) |
| Unrealized gains on investments | (175 | ) |  | (245 | ) |
| Other | (15 | ) |  | (26 | ) |
| Total deferred tax liabilities | (1,283 | ) |  | (1,548 | ) |
| Total net deferred tax assets | $ | 4,105 |  |  | $ | 4,005 |  |

[0000858877-15-000070:notes:320]
As of July 25, 2015, the Company’s federal, state, and foreign net operating loss carryforwards for income tax purposes were $204 million, $536 million, and $697 million, respectively.  A significant amount of the federal net operating loss carryforwards relates to acquisitions and, as a result, is limited in the amount that can be recognized in any one year. If not utilized, the federal net operating loss will begin to expire in fiscal 2018, and the state and foreign net operating loss carryforwards will begin to expire in fiscal 2018 and 2016, respectively. The Company has provided a valuation allowance of $68 million for deferred tax assets related to foreign net operating losses that are not expected to be realized.

[0000858877-15-000070:notes:321]
As of July 25, 2015, the Company’s federal, state, and foreign tax credit carryforwards for income tax purposes were approximately $7 million, $700 million, and $26 million, respectively. The federal and foreign tax credit carryforwards will begin to expire in fiscal 2017 and 2018, respectively.  The majority of state and foreign tax credits can be carried forward indefinitely.  The Company has provided a valuation allowance of $16 million for deferred tax assets related to state and foreign tax credits that are not expected to be realized.


## us-gaap:IncomeTaxPolicyTextBlock

[0000858877-15-000070:notes:322]
(s) Income Taxes   Income tax expense is based on pretax financial accounting income. Deferred tax assets and liabilities are recognized for the expected tax consequences of temporary differences between the tax bases of assets and liabilities and their reported amounts. Valuation allowances are recorded to reduce deferred tax assets to the amount that will more likely than not be realized.

[0000858877-15-000070:notes:323]
The Company accounts for uncertainty in income taxes using a two-step approach to recognizing and measuring uncertain tax positions. The first step is to evaluate the tax position for recognition by determining if the weight of available evidence indicates that it is more likely than not that the position will be sustained on audit, including resolution of related appeals or litigation processes, if any. The second step is to measure the tax benefit as the largest amount that is more than 50% likely of being realized upon settlement. The Company classifies the liability for unrecognized tax benefits as current to the extent that the Company anticipates payment (or receipt) of cash within one year. Interest and penalties related to uncertain tax positions are recognized in the provision for income taxes.


## us-gaap:InventoryDisclosureTextBlock

[0000858877-15-000070:notes:324]
The following tables provide details of selected balance sheet items (in millions):

[0000858877-15-000070:notes:325]
|  |  | July 25, 2015 |  | July 26, 2014 |
| Inventories: |  |  |  |  |
| Raw materials |  | $ | 114 |  |  | $ | 77 |  |
| Work in process |  | 2 |  |  | 5 |  |
| Finished goods: |  |  |  |  |
| Distributor inventory and deferred cost of sales |  | 610 |  |  | 595 |  |
| Manufactured finished goods |  | 593 |  |  | 606 |  |
| Total finished goods |  | 1,203 |  |  | 1,201 |  |
| Service-related spares |  | 258 |  |  | 273 |  |
| Demonstration systems |  | 50 |  |  | 35 |  |
| Total |  | $ | 1,627 |  |  | $ | 1,591 |  |


## us-gaap:InventoryPolicyTextBlock

[0000858877-15-000070:notes:326]
(d) Inventories   Inventories are stated at the lower of cost or market. Cost is computed using standard cost, which approximates actual cost, on a first-in, first-out basis. The Company provides inventory write-downs based on excess and obsolete inventories determined primarily by future demand forecasts. The write-down is measured as the difference between the cost of the inventory and market based upon assumptions about future demand and charged to the provision for inventory, which is a component of cost of sales. At the point of the loss recognition, a new, lower cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis. In addition, the Company records a liability for firm, noncancelable, and unconditional purchase commitments with contract manufacturers and suppliers for quantities in excess of the Company’s future demand forecasts consistent with its valuation of excess and obsolete inventory.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0000858877-15-000070:notes:327]
The following table summarizes the maturities of the Company’s fixed income securities at July 25, 2015 (in millions):

[0000858877-15-000070:notes:328]
|  | Amortized Cost |  | Fair Value |
| Less than 1 year | $ | 16,534 |  |  | $ | 16,540 |  |
| Due in 1 to 2 years | 15,264 |  |  | 15,279 |  |
| Due in 2 to 5 years | 18,501 |  |  | 18,499 |  |
| Due after 5 years | 1,653 |  |  | 1,656 |  |
| Total | $ | 51,952 |  |  | $ | 51,974 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000858877-15-000070:notes:329]
| 8. | Investments |

[0000858877-15-000070:notes:330]
| (a) | Summary of Available-for-Sale Investments |

[0000858877-15-000070:notes:331]
The following tables summarize the Company’s available-for-sale investments (in millions):

[0000858877-15-000070:notes:332]
| July 25, 2015 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| Fixed income securities: |  |  |  |  |  |  |  |
| U.S. government securities | $ | 29,904 |  |  | $ | 41 |  |  | $ | (6 | ) |  | $ | 29,939 |  |
| U.S. government agency securities | 3,662 |  |  | 2 |  |  | (1 | ) |  | 3,663 |  |
| Non-U.S. government and agency securities | 1,128 |  |  | 1 |  |  | (1 | ) |  | 1,128 |  |
| Corporate debt securities | 15,802 |  |  | 34 |  |  | (53 | ) |  | 15,783 |  |
| U.S. agency mortgage-backed securities | 1,456 |  |  | 8 |  |  | (3 | ) |  | 1,461 |  |
| Total fixed income securities | 51,952 |  |  | 86 |  |  | (64 | ) |  | 51,974 |  |
| Publicly traded equity securities | 1,092 |  |  | 480 |  |  | (7 | ) |  | 1,565 |  |
| Total | $ | 53,044 |  |  | $ | 566 |  |  | $ | (71 | ) |  | $ | 53,539 |  |
| July 26, 2014 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| Fixed income securities: |  |  |  |  |  |  |  |
| U.S. government securities | $ | 31,717 |  |  | $ | 29 |  |  | $ | (12 | ) |  | $ | 31,734 |  |
| U.S. government agency securities | 1,062 |  |  | 1 |  |  | — |  |  | 1,063 |  |
| Non-U.S. government and agency securities | 860 |  |  | 2 |  |  | (1 | ) |  | 861 |  |
| Corporate debt securities | 9,092 |  |  | 74 |  |  | (7 | ) |  | 9,159 |  |
| U.S. agency mortgage-backed securities | 574 |  |  | 5 |  |  | — |  |  | 579 |  |
| Total fixed income securities | 43,305 |  |  | 111 |  |  | (20 | ) |  | 43,396 |  |
| Publicly traded equity securities | 1,314 |  |  | 648 |  |  | (10 | ) |  | 1,952 |  |
| Total | $ | 44,619 |  |  | $ | 759 |  |  | $ | (30 | ) |  | $ | 45,348 |  |

[0000858877-15-000070:notes:333]
Non-U.S. government and agency securities include agency and corporate debt securities that are guaranteed by non-U.S. governments.

[0000858877-15-000070:notes:334]
| (b) | Gains and Losses on Available-for-Sale Investments |

[0000858877-15-000070:notes:335]
The following table presents the gross realized gains and gross realized losses related to the Company’s available-for-sale investments (in millions):

[0000858877-15-000070:notes:336]
| Years Ended | July 25, 2015 |  | July 26, 2014 |  | July 27, 2013 |
| Gross realized gains | $ | 221 |  |  | $ | 341 |  |  | $ | 264 |  |
| Gross realized losses | (64 | ) |  | (41 | ) |  | (216 | ) |
| Total | $ | 157 |  |  | $ | 300 |  |  | $ | 48 |  |

[0000858877-15-000070:notes:337]
The following table presents the realized net gains related to the Company’s available-for-sale investments by security type (in millions):

[0000858877-15-000070:notes:338]
| Years Ended | July 25, 2015 |  | July 26, 2014 |  | July 27, 2013 |
| Net gains on investments in publicly traded equity securities | $ | 116 |  |  | $ | 253 |  |  | $ | 17 |  |
| Net gains on investments in fixed income securities | 41 |  |  | 47 |  |  | 31 |  |
| Total | $ | 157 |  |  | $ | 300 |  |  | $ | 48 |  |

[0000858877-15-000070:notes:339]
There were no impairment charges on available-for-sale investments for fiscal 2015.  For fiscal 2014, the realized net gains related to the Company's available-for-sale investments included impairment charges of $11 million.  These impairment charges related to publicly traded equity securities and were due to a decline in the fair value of those securities below their cost basis that were determined to be other than temporary. There were no impairment charges on available-for-sale investments for fiscal 2013.

[0000858877-15-000070:notes:340]
The following tables present the breakdown of the available-for-sale investments with gross unrealized losses and the duration that those losses had been unrealized at July 25, 2015 and July 26, 2014 (in millions):

[0000858877-15-000070:notes:341]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 25, 2015 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| Fixed income securities: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | $ | 6,412 |  |  | $ | (6 | ) |  | $ | — |  |  | $ | — |  |  | $ | 6,412 |  |  | $ | (6 | ) |
| U.S. government agency securities | 1,433 |  |  | (1 | ) |  | — |  |  | — |  |  | 1,433 |  |  | (1 | ) |
| Non-U.S. government and agency securities | 515 |  |  | (1 | ) |  | 4 |  |  | — |  |  | 519 |  |  | (1 | ) |
| Corporate debt securities | 9,552 |  |  | (49 | ) |  | 312 |  |  | (4 | ) |  | 9,864 |  |  | (53 | ) |
| U.S. agency mortgage-backed securities | 579 |  |  | (3 | ) |  | — |  |  | — |  |  | 579 |  |  | (3 | ) |
| Total fixed income securities | 18,491 |  |  | (60 | ) |  | 316 |  |  | (4 | ) |  | 18,807 |  |  | (64 | ) |
| Publicly traded equity securities | 108 |  |  | (7 | ) |  | 2 |  |  | — |  |  | 110 |  |  | (7 | ) |
| Total | $ | 18,599 |  |  | $ | (67 | ) |  | $ | 318 |  |  | $ | (4 | ) |  | $ | 18,917 |  |  | $ | (71 | ) |

[0000858877-15-000070:notes:342]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 26, 2014 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| Fixed income securities: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | $ | 7,676 |  |  | $ | (12 | ) |  | $ | 45 |  |  | $ | — |  |  | $ | 7,721 |  |  | $ | (12 | ) |
| Non-U.S. government and agency securities | 361 |  |  | (1 | ) |  | 22 |  |  | — |  |  | 383 |  |  | (1 | ) |
| Corporate debt securities | 1,875 |  |  | (3 | ) |  | 491 |  |  | (4 | ) |  | 2,366 |  |  | (7 | ) |
| Total fixed income securities | 9,912 |  |  | (16 | ) |  | 558 |  |  | (4 | ) |  | 10,470 |  |  | (20 | ) |
| Publicly traded equity securities | 132 |  |  | (10 | ) |  | — |  |  | — |  |  | 132 |  |  | (10 | ) |
| Total | $ | 10,044 |  |  | $ | (26 | ) |  | $ | 558 |  |  | $ | (4 | ) |  | $ | 10,602 |  |  | $ | (30 | ) |

[0000858877-15-000070:notes:343]
As of July 25, 2015, for fixed income securities that were in unrealized loss positions, the Company has determined that (i) it does not have the intent to sell any of these investments, and (ii) it is not more likely than not that it will be required to sell any of these investments before recovery of the entire amortized cost basis. In addition, as of July 25, 2015, the Company anticipates that it will recover the entire amortized cost basis of such fixed income securities and has determined that no other-than-temporary impairments associated with credit losses were required to be recognized during the year ended July 25, 2015.

[0000858877-15-000070:notes:344]
The Company has evaluated its publicly traded equity securities as of July 25, 2015 and has determined that there was no indication of other-than-temporary impairments in the respective categories of unrealized losses. This determination was based on several factors, which include the length of time and extent to which fair value has been less than the cost basis, the financial condition and near-term prospects of the issuer, and the Company’s intent and ability to hold the publicly traded equity securities for a period of time sufficient to allow for any anticipated recovery in market value.

[0000858877-15-000070:notes:345]
| (c) | Maturities of Fixed Income Securities |

[0000858877-15-000070:notes:346]
Actual maturities may differ from the contractual maturities because borrowers may have the right to call or prepay certain obligations.  The remaining contractual principal maturities for mortgage-backed securities were allocated assuming no prepayments.

[0000858877-15-000070:notes:347]
| (d) | Securities Lending |

[0000858877-15-000070:notes:348]
The Company periodically engages in securities lending activities with certain of its available-for-sale investments.  These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis.  The average daily balance of securities lending for fiscal 2015 and 2014 was $0.4 billion and $1.5 billion, respectively.  The Company requires collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets.  The Company engages in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify the Company against collateral losses.  The Company did not experience any losses in connection with the secured lending of securities during the periods presented.  As of July 25, 2015 and July 26, 2014, the Company had no outstanding securities lending transactions.

[0000858877-15-000070:notes:349]
| (e) | Investments in Privately Held Companies |

[0000858877-15-000070:notes:350]
The carrying value of the Company’s investments in privately held companies was included in other assets. For such investments that were accounted for under the equity and cost method as of July 25, 2015 and July 26, 2014, the amounts are summarized in the following table (in millions):

[0000858877-15-000070:notes:351]
Variable Interest Entities

[0000858877-15-000070:notes:352]
VCE Joint Venture   VCE is a joint venture formed in fiscal 2010 between the Company and EMC Corporation (“EMC”), with investments from VMware, Inc. (“VMware”) and Intel Capital Corporation ("Intel").  In October 2014, the Company, EMC, VMware, and Intel agreed to restructure VCE, and this transaction was completed in the second quarter of fiscal 2015.  Prior to the restructuring, the Company’s cumulative gross investment in VCE was approximately $716 million, inclusive of convertible notes and accrued interest on convertible notes.  The Company recorded cumulative losses from VCE under the equity method of $691 million since inception.  The Company ceased accounting for the VCE investment under the equity method in October 2014, and losses of $47 million, $223 million and $183 million were recorded for the fiscal years ended July 25, 2015, July 26, 2014, and July 27, 2013, respectively.  Under the terms of the restructuring, VCE paid $152 million to the Company for a portion of the outstanding principal balance of the convertible notes held by it and accrued interest on such notes, and the remaining principal balance of other such notes, and the accrued interest thereon, was cancelled.  Pursuant to the restructuring, VCE also redeemed a portion of the Company’s equity interest in VCE, reducing the Company’s ownership interest in VCE from 35% prior to the restructuring to 10%.  In connection with this transaction, the Company has written this investment down to a book value of zero and has recognized a gain in other income (loss), net of $126 million for the fiscal year ended July 25, 2015.

[0000858877-15-000070:notes:353]
Other Variable Interest Entities    In the ordinary course of business, the Company has investments in other privately held companies and provides financing to certain customers. These other privately held companies and customers may be considered to be variable interest entities. The Company evaluates on an ongoing basis its investments in these other privately held companies and its customer financings and has determined that as of July 25, 2015 there were no other variable interest entities required to be consolidated in the Company’s Consolidated Financial Statements.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000858877-15-000070:notes:354]
| 1. | Basis of Presentation |

[0000858877-15-000070:notes:355]
The fiscal year for Cisco Systems, Inc. (the “Company” or “Cisco”) is the 52 or 53 weeks ending on the last Saturday in July. Fiscal 2015, fiscal 2014, and fiscal 2013 are each 52-week fiscal years.  The Consolidated Financial Statements include the accounts of Cisco and its subsidiaries. All intercompany accounts and transactions have been eliminated.  The Company conducts business globally and is primarily managed on a geographic basis in the following three geographic segments: the Americas; Europe, Middle East, and Africa (EMEA); and Asia Pacific, Japan, and China (APJC).

[0000858877-15-000070:notes:356]
The Company consolidates its investments in a venture fund managed by SOFTBANK Corp. and its affiliates (“SOFTBANK”) as this is a variable interest entity and the Company is the primary beneficiary.  The noncontrolling interests attributed to SOFTBANK are presented as a separate component from the Company’s equity in the equity section of the Consolidated Balance Sheets. SOFTBANK’s share of the earnings in the venture fund are not presented separately in the Consolidated Statements of Operations as these amounts are not material for any of the fiscal periods presented.

[0000858877-15-000070:notes:357]
Certain reclassifications have been made to the amounts for prior years in order to conform to the current year’s presentation.  The Company has evaluated subsequent events through the date that the financial statements were issued.


## us-gaap:OtherAssetsDisclosureTextBlock

[0000858877-15-000070:notes:358]
| Other assets: |  |  |  |  |
| Deferred tax assets |  | $ | 1,648 |  |  | $ | 1,700 |  |
| Investments in privately held companies |  | 897 |  |  | 899 |  |
| Other |  | 618 |  |  | 668 |  |
| Total |  | $ | 3,163 |  |  | $ | 3,267 |  |


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0000858877-15-000070:notes:359]
(g) Depreciation and Amortization   Property and equipment are stated at cost, less accumulated depreciation or amortization, whenever applicable. Depreciation and amortization expenses for property and equipment were approximately $1.1 billion, $1.2 billion, and $1.2 billion for fiscal 2015, 2014, and 2013, respectively. Depreciation and amortization are computed using the straight-line method, generally over the following periods:


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0000858877-15-000070:notes:360]
| Property and equipment, net: |  |  |  |  |
| Gross property and equipment: |  |  |  |  |
| Land, buildings, and building and leasehold improvements |  | $ | 4,495 |  |  | $ | 4,468 |  |
| Computer equipment and related software |  | 1,310 |  |  | 1,425 |  |
| Production, engineering, and other equipment |  | 5,753 |  |  | 5,756 |  |
| Operating lease assets |  | 372 |  |  | 362 |  |
| Furniture and fixtures |  | 497 |  |  | 509 |  |
| Total gross property and equipment |  | 12,427 |  |  | 12,520 |  |
| Less: accumulated depreciation and amortization |  | (9,095 | ) |  | (9,268 | ) |
| Total |  | $ | 3,332 |  |  | $ | 3,252 |  |


## us-gaap:ResearchDevelopmentAndComputerSoftwarePolicyTextBlock

[0000858877-15-000070:notes:361]
(r) Software Development Costs   Software development costs, including costs to develop software sold, leased, or otherwise marketed, that are incurred subsequent to the establishment of technological feasibility are capitalized if significant. Costs incurred during the application development stage for internal-use software are capitalized if significant. Capitalized software development costs are amortized using the straight-line amortization method over the estimated useful life of the applicable software. Such software development costs required to be capitalized have not been material to date.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000858877-15-000070:notes:362]
| 5. | Restructuring and Other Charges |

[0000858877-15-000070:notes:363]
Fiscal 2015 Plan   The Company announced a restructuring action in August 2014 (the "Fiscal 2015 Plan"), in order to realign its workforce towards key growth areas of its business such as data center, software, security, and cloud. In connection with the Fiscal 2015 Plan, the Company incurred charges of $489 million during fiscal 2015.  The Company estimates that it will recognize aggregate pretax charges pursuant to the restructuring of approximately $700 million, consisting of severance and other one-time termination benefits and other associated costs.  These charges are primarily cash-based, and the Company expects the Fiscal 2015 Plan to be substantially completed during the first half of fiscal 2016.

[0000858877-15-000070:notes:364]
Fiscal 2014 Plan and Fiscal 2011 Plans   In connection with a restructuring action announced in August 2013 (the "Fiscal 2014 Plan"), the Company incurred cumulative charges of approximately $418 million.  The Company completed the Fiscal 2014 Plan at the end of fiscal 2014.

[0000858877-15-000070:notes:365]
The Fiscal 2011 Plans consist primarily of the realignment and restructuring of the Company’s business announced in July 2011 and of certain consumer product lines as announced during April 2011.  The Company completed the Fiscal 2011 Plans at the end of fiscal 2013, with a total $105 million of charges having been incurred in fiscal 2013. The Company incurred cumulative charges of approximately $1.1 billion in connection with these plans.

[0000858877-15-000070:notes:366]
The following table summarizes the activities related to the restructuring and other charges, as discussed above (in millions):

[0000858877-15-000070:notes:367]
|  |  | FISCAL 2014 AND FISCAL 2011 PLANS |  | FISCAL 2015 PLAN |  |  |
|  |  | EmployeeSeverance |  | Other |  | EmployeeSeverance |  | Other |  | Total |
| Liability as of July 28, 2012 |  | $ | 83 |  |  | $ | 27 |  |  | $ | — |  |  | $ | — |  |  | $ | 110 |  |
| Charges |  | 111 |  |  | (6 | ) |  | — |  |  | — |  |  | 105 |  |
| Cash payments |  | (173 | ) |  | (11 | ) |  | — |  |  | — |  |  | (184 | ) |
| Non-cash items |  | — |  |  | (3 | ) |  | — |  |  | — |  |  | (3 | ) |
| Liability as of July 27, 2013 |  | 21 |  |  | 7 |  |  | — |  |  | — |  |  | 28 |  |
| Charges |  | 366 |  |  | 52 |  |  | — |  |  | — |  |  | 418 |  |
| Cash payments |  | (345 | ) |  | (7 | ) |  | — |  |  | — |  |  | (352 | ) |
| Non-cash items |  | (2 | ) |  | (23 | ) |  | — |  |  | — |  |  | (25 | ) |
| Liability as of July 26, 2014 |  | 40 |  |  | 29 |  |  | — |  |  | — |  |  | 69 |  |
| Charges |  | — |  |  | — |  |  | 464 |  |  | 20 |  |  | 484 |  |
| Cash payments |  | (29 | ) |  | (14 | ) |  | (413 | ) |  | (3 | ) |  | (459 | ) |
| Non-cash items |  | — |  |  | (1 | ) |  | (2 | ) |  | (2 | ) |  | (5 | ) |
| Liability as of July 25, 2015 |  | $ | 11 |  |  | $ | 14 |  |  | $ | 49 |  |  | $ | 15 |  |  | $ | 89 |  |

[0000858877-15-000070:notes:368]
During fiscal 2015, in addition to the above amounts, the Company incurred $5 million of restructuring and other charges within cost of sales.


## us-gaap:RevenueRecognitionPolicyTextBlock

[0000858877-15-000070:notes:369]
(o) Revenue Recognition   The Company recognizes revenue when persuasive evidence of an arrangement exists, delivery has occurred, the fee is fixed or determinable, and collectibility is reasonably assured. In instances where final acceptance of the product, system, or solution is specified by the customer, revenue is deferred until all acceptance criteria have been met. For hosting arrangements, the Company recognizes subscription revenue ratably over the subscription period, while usage revenue is recognized based on utilization. Software subscription revenue is deferred and recognized ratably over the subscription term upon delivery of the first product and commencement of the term.  Technical support services revenue is deferred and recognized ratably over the period during which the services are to be performed, which is typically from one to three years.  Advanced services revenue is recognized upon delivery or completion of performance milestones.

[0000858877-15-000070:notes:370]
The Company uses distributors that stock inventory and typically sell to systems integrators, service providers, and other resellers.     The Company refers to this as its two-tier system of sales to the end customer. Revenue from distributors is recognized based on a sell-through method using information provided by them. Distributors and other partners participate in various rebate, cooperative marketing, and other programs, and the Company maintains estimated accruals and allowances for these programs. The ending liability for these programs was included in other current liabilities, and the balance as of each of July 25, 2015 and July 26, 2014 was $1.3 billion.  The Company accrues for warranty costs, sales returns, and other allowances based on its historical experience. Shipping and handling fees billed to customers are included in revenue, with the associated costs included in cost of sales.

[0000858877-15-000070:notes:371]
Many of the Company’s products have both software and non-software components that function together to deliver the products’ essential functionality. The Company’s product offerings fall into the following categories: Switching, Next-Generation Network (NGN) Routing, Collaboration, Service Provider Video, Data Center, Wireless, Security, and Other Products. The Company also provides technical support and advanced services. The Company has a broad customer base that encompasses virtually all types of public and private entities, including enterprise businesses, service providers, and commercial customers.  The Company and its salesforce are not organized by product divisions, and the Company’s products and services can be sold standalone or together in various combinations across the Company’s geographic segments or customer markets. For example, service provider arrangements are typically larger in scale with longer deployment schedules and involve the delivery of a variety of product technologies, including high-end routing, video and network management software, and other product technologies along with technical support and advanced services. The Company’s enterprise and commercial arrangements are unique for each customer and smaller in scale and may include network infrastructure products such as routers and switches or collaboration technologies such as Unified Communications and Cisco TelePresence systems products along with technical support services.

[0000858877-15-000070:notes:372]
The Company enters into revenue arrangements that may consist of multiple deliverables of its product and service offerings due to the needs of its customers. For example, a customer may purchase routing products along with a contract for technical support services. This arrangement would consist of multiple elements, with the products delivered in one reporting period and the technical support services delivered across multiple reporting periods. Another customer may purchase networking products along with advanced service offerings, in which all the elements are delivered within the same reporting period. In addition, distributors purchase products or technical support services on a standalone basis for resale to an end user or for purposes of stocking certain products, and these transactions would not result in a multiple-element arrangement.  The Company considers several factors when reviewing multiple purchases made by the same customer within a short time frame in order to identify multiple-element arrangements, including whether the deliverables are closely interrelated, whether the deliverables are essential to each other’s functionality, whether payment terms are linked, whether the customer is entitled to a refund or concession if another purchase is not completed satisfactorily, and/or whether the purchases were negotiated together as one overall arrangement.

[0000858877-15-000070:notes:373]
In many instances, products are sold separately in standalone arrangements as customers may support the products themselves or purchase support on a time-and-materials basis. Advanced services are sometimes sold in standalone engagements such as general consulting, network management, or security advisory projects, and technical support services are sold separately through renewals of annual contracts.  The Company determines its vendor-specific objective evidence (VSOE) based on its normal pricing and discounting practices for products or services when sold separately. VSOE determination requires that a substantial majority of the historical standalone transactions has the selling prices for a product or service that fall within a reasonably narrow pricing range, generally evidenced by approximately 80% of such historical standalone transactions falling within plus or minus 15% of the median rates. In addition, the Company considers the geographies in which the products or services are sold, major product and service groups and customer classifications, and other environmental or marketing variables in determining VSOE.

[0000858877-15-000070:notes:374]
When the Company is not able to establish VSOE for all deliverables in an arrangement with multiple elements, which may be due to the Company infrequently selling each element separately, not pricing products within a narrow range, or only having a limited sales history, such as in the case of certain newly introduced product categories, the Company attempts to determine the selling price of each element based on third-party evidence of selling price (TPE). TPE is determined based on competitor prices for similar deliverables when sold separately. Generally, the Company’s go-to-market strategy differs from that of its peers, and its offerings contain a significant level of differentiation such that the comparable pricing of products with similar functionality cannot be obtained. Furthermore, the Company is unable to reliably determine what similar competitor products’ selling prices are on a standalone basis. Therefore, the Company is typically not able to determine TPE.

[0000858877-15-000070:notes:375]
When the Company is unable to establish fair value using VSOE or TPE, the Company uses estimated selling prices (ESP) in its allocation of arrangement consideration. The objective of ESP is to determine the price at which the Company would transact a sale if the product or service were regularly sold on a standalone basis. ESP is generally used for new or highly proprietary offerings and solutions or for offerings not priced within a reasonably narrow range. The Company determines ESP for a product or service by considering multiple factors, including, but not limited to, geographies, market conditions, competitive landscape, internal costs, gross margin objectives, and pricing practices. The determination of ESP is made through consultation with and formal approval by the Company’s management, taking into consideration the go-to-market strategy.

[0000858877-15-000070:notes:376]
The Company regularly reviews VSOE, TPE, and ESP and maintains internal controls over the establishment and updates of these estimates. There were no material impacts during the fiscal year, nor does the Company currently expect a material impact in the near term from changes in VSOE, TPE, or ESP.

[0000858877-15-000070:notes:377]
The Company’s arrangements with multiple deliverables may include one or more software deliverables that are subject to the software revenue recognition guidance. In these cases, revenue for the software is generally recognized upon shipment or electronic delivery and granting of the license. The revenue for these multiple-element arrangements is allocated to the software deliverables and the non-software deliverables based on the relative selling prices of all of the deliverables in the arrangement using the hierarchy in the applicable accounting guidance. In the circumstances where the Company cannot determine VSOE or

[0000858877-15-000070:notes:378]
TPE of the selling price for all of the deliverables in the arrangement, including the software deliverables, ESP is used for the purposes of performing this allocation. VSOE is required to allocate the revenue between multiple software deliverables.  If VSOE is available for the undelivered software elements, the Company applies the residual method; where VSOE is not available, software revenue is either recognized when all software elements have been delivered or recognized ratably when post-contract support is the only undelivered software element remaining.


## us-gaap:ScheduleOfBusinessAcquisitionsByAcquisitionTextBlock

[0000858877-15-000070:notes:379]
A summary of the allocation of the total purchase consideration is presented as follows (in millions):


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0000858877-15-000070:notes:380]
SCHEDULE II

[0000858877-15-000070:notes:381]
VALUATION AND QUALIFYING ACCOUNTS

[0000858877-15-000070:notes:382]
(in millions)

[0000858877-15-000070:notes:383]
|  | Allowances For |
|  | FinancingReceivables |  | AccountsReceivable |
| Year ended July 27, 2013: |  |  |  |
| Balance at beginning of fiscal year | $ | 380 |  |  | $ | 207 |  |
| Provisions | 11 |  |  | 33 |  |
| (Write-offs) recoveries, net | (46 | ) |  | (12 | ) |
| Foreign exchange and other | (1 | ) |  | — |  |
| Balance at end of fiscal year | $ | 344 |  |  | $ | 228 |  |
| Year ended July 26, 2014: |  |  |  |
| Balance at beginning of fiscal year | $ | 344 |  |  | $ | 228 |  |
| Provisions | 14 |  |  | 65 |  |
| (Write-offs) recoveries, net | (9 | ) |  | (28 | ) |
| Balance at end of fiscal year | $ | 349 |  |  | $ | 265 |  |
| Year ended July 25, 2015: |  |  |  |
| Balance at beginning of fiscal year | $ | 349 |  |  | $ | 265 |  |
| Provisions | 57 |  |  | 77 |  |
| (Write-offs) recoveries, net | (7 | ) |  | (40 | ) |
| Foreign exchange and other | (17 | ) |  | — |  |
| Balance at end of fiscal year | $ | 382 |  |  | $ | 302 |  |

[0000858877-15-000070:notes:384]
Foreign exchange and other includes the impact of foreign exchange and certain immaterial reclassifications.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000858877-15-000070:notes:385]
| 2. | Summary of Significant Accounting Policies |

[0000858877-15-000070:notes:386]
(b) Available-for-Sale Investments   The Company classifies its investments in both fixed income securities and publicly traded equity securities as available-for-sale investments. Fixed income securities primarily consist of U.S. government securities, U.S. government agency securities, non-U.S. government and agency securities, corporate debt securities, and U.S. agency mortgage-backed securities. These available-for-sale investments are primarily held in the custody of a major financial institution. A specific identification method is used to determine the cost basis of fixed income and public equity securities sold. These investments are recorded in the Consolidated Balance Sheets at fair value. Unrealized gains and losses on these investments, to the extent the investments are unhedged, are included as a separate component of accumulated other comprehensive income (AOCI), net of tax. The Company classifies its investments as current based on the nature of the investments and their availability for use in current operations.

[0000858877-15-000070:notes:387]
(e) Allowance for Doubtful Accounts   The allowance for doubtful accounts is based on the Company’s assessment of the collectibility of customer accounts. The Company regularly reviews the allowance by considering factors such as historical experience, credit quality, age of the accounts receivable balances, economic conditions that may affect a customer’s ability to pay, and expected default frequency rates. Trade receivables are written off at the point when they are considered uncollectible.

[0000858877-15-000070:notes:388]
(f) Financing Receivables and Guarantees   The Company provides financing arrangements, including leases, financed service contracts, and loans, for certain qualified end-user customers to build, maintain, and upgrade their networks. Lease receivables primarily represent sales-type and direct-financing leases. Leases have on average a four-year term and are usually collateralized by a security interest in the underlying assets, while loan receivables generally have terms of up to three years. Financed service contracts typically have terms of one to three years and primarily relate to technical support services.

[0000858877-15-000070:notes:389]
The Company determines the adequacy of its allowance for credit loss by assessing the risks and losses inherent in its financing receivables by portfolio segment. The portfolio segment is based on the types of financing offered by the Company to its customers: lease receivables, loan receivables, and financed service contracts and other.

[0000858877-15-000070:notes:390]
The Company assesses the allowance for credit loss related to financing receivables on either an individual or a collective basis. The Company considers various factors in evaluating lease and loan receivables and the earned portion of financed service contracts for possible impairment on an individual basis. These factors include the Company’s historical experience, credit quality and age of the receivable balances, and economic conditions that may affect a customer’s ability to pay. When the evaluation indicates that it is probable that all amounts due pursuant to the contractual terms of the financing agreement, including scheduled interest payments, are unable to be collected, the financing receivable is considered impaired. All such outstanding amounts, including any accrued interest, will be assessed and fully reserved at the customer level. The Company’s internal credit risk ratings are categorized as 1 through 10, with the lowest credit risk rating representing the highest quality financing receivables. Typically, the Company also considers receivables with a risk rating of 8 or higher to be impaired and will include them in the individual assessment for allowance. The Company evaluates the remainder of its financing receivables portfolio for impairment on a collective basis and records an allowance for credit loss at the portfolio segment level. When evaluating the financing receivables on a collective basis, the Company uses expected default frequency rates published by a major third-party credit-rating agency as well as its own historical loss rate in the event of default, while also systematically giving effect to economic conditions, concentration of risk, and correlation.

[0000858877-15-000070:notes:391]
Expected default frequency rates are published quarterly by a major third-party credit-rating agency, and the internal credit risk rating is derived by taking into consideration various customer-specific factors and macroeconomic conditions. These factors, which include the strength of the customer’s business and financial performance, the quality of the customer’s banking relationships, the Company’s specific historical experience with the customer, the performance and outlook of the customer’s industry, the customer’s legal and regulatory environment, the potential sovereign risk of the geographic locations in which the customer is operating, and independent third-party evaluations, are updated regularly or when facts and circumstances indicate that an update is deemed necessary.

[0000858877-15-000070:notes:392]
Financing receivables are written off at the point when they are considered uncollectible, and all outstanding balances, including any previously earned but uncollected interest income, will be reversed and charged against the allowance for credit loss. The Company does not typically have any partially written-off financing receivables.

[0000858877-15-000070:notes:393]
Outstanding financing receivables that are aged 31 days or more from the contractual payment date are considered past due. The Company does not accrue interest on financing receivables that are considered impaired or more than 90 days past due unless either the receivable has not been collected due to administrative reasons or the receivable is well secured and in the process of collection.  Financing receivables may be placed on nonaccrual status earlier if, in management’s opinion, a timely collection of the full principal and interest becomes uncertain. After a financing receivable has been categorized as nonaccrual, interest will be recognized when cash is received. A financing receivable may be returned to accrual status after all of the customer’s delinquent balances of principal and interest have been settled, and the customer remains current for an appropriate period.

[0000858877-15-000070:notes:394]
The Company facilitates arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, generally with payment terms ranging from 60 to 90 days. In certain instances, these financing arrangements result in a transfer of the Company’s receivables to the third party. The receivables are derecognized upon transfer, as these transfers qualify as true sales, and the Company receives a payment for the receivables from the third party based on the Company’s standard payment terms. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, the Company guarantees a portion of these arrangements. The Company also provides financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. The Company could be called upon to make payments under these guarantees in the event of nonpayment by the channel partners or end-user customers. Deferred revenue relating to these financing arrangements is recorded in accordance with revenue recognition policies or for the fair value of the financing guarantees.

[0000858877-15-000070:notes:395]
(k) Fair Value   Fair value is defined as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities required or permitted to be either recorded or disclosed at fair value, the Company considers the principal or most advantageous market in which it would transact, and it also considers assumptions that market participants would use when pricing the asset or liability.

[0000858877-15-000070:notes:396]
The accounting guidance for fair value measurement requires an entity to maximize the use of observable inputs and minimize the use of unobservable inputs when measuring fair value. The standard establishes a fair value hierarchy based on the level of independent, objective evidence surrounding the inputs used to measure fair value. A financial instrument’s categorization within the fair value hierarchy is based upon the lowest level of input that is significant to the fair value measurement. The fair value hierarchy is as follows:

[0000858877-15-000070:notes:397]
Level 1 applies to assets or liabilities for which there are quoted prices in active markets for identical assets or liabilities.

[0000858877-15-000070:notes:398]
Level 2 applies to assets or liabilities for which there are inputs other than quoted prices that are observable for the asset or liability such as quoted prices for similar assets or liabilities in active markets; quoted prices for identical assets or liabilities in

[0000858877-15-000070:notes:399]
markets with insufficient volume or infrequent transactions (less active markets); or model-derived valuations in which significant inputs are observable or can be derived principally from, or corroborated by, observable market data.

[0000858877-15-000070:notes:400]
Level 3 applies to assets or liabilities for which there are unobservable inputs to the valuation methodology that are significant to the measurement of the fair value of the assets or liabilities.

[0000858877-15-000070:notes:401]
(u) Consolidation of Variable Interest Entities  The Company uses a qualitative approach in assessing the consolidation requirement for variable interest entities. The approach focuses on identifying which enterprise has the power to direct the activities that most significantly impact the variable interest entity’s economic performance and which enterprise has the obligation to absorb losses or the right to receive benefits from the variable interest entity. In the event that the Company is the primary beneficiary of a variable interest entity, the assets, liabilities, and results of operations of the variable interest entity will be included in the Company’s Consolidated Financial Statements.

[0000858877-15-000070:notes:402]
(v) Use of Estimates   The preparation of financial statements and related disclosures in conformity with accounting principles generally accepted in the United States requires management to make estimates and judgments that affect the amounts reported in the Consolidated Financial Statements and accompanying notes. Estimates are used for the following, among others:

[0000858877-15-000070:notes:403]
| ▪ | Revenue recognition |

[0000858877-15-000070:notes:404]
| ▪ | Allowances for accounts receivable, sales returns, and financing receivables |

[0000858877-15-000070:notes:405]
| ▪ | Inventory valuation and liability for purchase commitments with contract manufacturers and suppliers |

[0000858877-15-000070:notes:406]
| ▪ | Loss contingencies and product warranties |

[0000858877-15-000070:notes:407]
| ▪ | Fair value measurements and other-than-temporary impairments |

[0000858877-15-000070:notes:408]
| ▪ | Goodwill and purchased intangible asset impairments |

[0000858877-15-000070:notes:409]
| ▪ | Income taxes |

[0000858877-15-000070:notes:410]
The actual results experienced by the Company may differ materially from management’s estimates.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000858877-15-000070:notes:411]
| 13. | Shareholders’ Equity |

[0000858877-15-000070:notes:412]
| (a) | Cash Dividends on Shares of Common Stock |

[0000858877-15-000070:notes:413]
During fiscal 2015, the Company declared and paid cash dividends of $0.80 per common share, or $4.1 billion, on the Company’s outstanding common stock.  During fiscal 2014, the Company declared and paid cash dividends of $0.72 per common share, or  $3.8 billion, on the Company’s outstanding common stock.

[0000858877-15-000070:notes:414]
Any future dividends will be subject to the approval of the Company's Board of Directors.

[0000858877-15-000070:notes:415]
| (b) | Stock Repurchase Program |

[0000858877-15-000070:notes:416]
In September 2001, the Company’s Board of Directors authorized a stock repurchase program. As of July 25, 2015, the Company’s Board of Directors had authorized an aggregate repurchase of up to $97 billion of common stock under this program, and the remaining authorized repurchase amount was $4.3 billion, with no termination date. A summary of the stock repurchase activity under the stock repurchase program, reported based on the trade date, is summarized as follows (in millions, except per-share amounts):

[0000858877-15-000070:notes:417]
The purchase price for the shares of the Company’s stock repurchased is reflected as a reduction to shareholders’ equity. The Company is required to allocate the purchase price of the repurchased shares as (i) a reduction to retained earnings and (ii) a reduction of common stock and additional paid-in capital. Issuance of common stock and the tax benefit related to employee stock incentive plans are recorded as an increase to common stock and additional paid-in capital.

[0000858877-15-000070:notes:418]
| (c) | Restricted Stock Unit Withholdings |

[0000858877-15-000070:notes:419]
For the years ended July 25, 2015 and July 26, 2014, the Company repurchased approximately 20 million and 18 million shares, or $502 million and $430 million, of common stock, respectively, in settlement of employee tax withholding obligations due upon the vesting of restricted stock or stock units.

[0000858877-15-000070:notes:420]
| (d) | Preferred Stock |

[0000858877-15-000070:notes:421]
Under the terms of the Company’s Articles of Incorporation, the Board of Directors may determine the rights, preferences, and terms of the Company’s authorized but unissued shares of preferred stock.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000858877-15-000070:notes:422]
| 6. | Balance Sheet Details |


## us-gaap:TreasuryStockTextBlock

[0000858877-15-000070:notes:423]
Supplemental Information

[0000858877-15-000070:notes:424]
In September 2001, the Company’s Board of Directors authorized a stock repurchase program. As of July 25, 2015, the Company’s Board of Directors had authorized an aggregate repurchase of up to $97 billion of common stock under this program with no termination date. The stock repurchases since the inception of this program and the related impacts on Cisco shareholders’ equity are summarized in the following table (in millions):
