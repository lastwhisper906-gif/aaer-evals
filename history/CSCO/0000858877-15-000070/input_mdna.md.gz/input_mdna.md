# CSCO MD&A — 0000858877-15-000070


## mdna

[0000858877-15-000070:mdna:1]
| Item 7. | Management’s Discussion and Analysis of Financial Condition and Results of Operations |

[0000858877-15-000070:mdna:2]
Forward-Looking Statements

[0000858877-15-000070:mdna:3]
OVERVIEW

[0000858877-15-000070:mdna:4]
Cisco designs and sells broad lines of products, provides services and delivers integrated solutions to develop and connect networks around the world, building the Internet.  Over the last 30 plus years, we have been the world’s leader in connecting people, things and technologies - to each other and to the Internet - realizing our vision of changing the way the world works, lives, plays and learns.

[0000858877-15-000070:mdna:5]
Today, we have over 70,000 employees in over 400 offices worldwide who design, produce, sell, and deliver integrated products, services, and solutions. Over time, we have expanded to new markets that are a natural extension of our core networking business, as the network has become the platform for automating, orchestrating, integrating, and delivering an ever-increasing array of information technology (IT)–based products and services.

[0000858877-15-000070:mdna:6]
A summary of our results is as follows (in millions, except percentages and per-share amounts):

[0000858877-15-000070:mdna:7]
|  | Three Months Ended |  | Years Ended |  |
|  | July 25, 2015 |  | July 26, 2014 |  | Variance |  | July 25, 2015 |  | July 26, 2014 |  | Variance |  |
| Revenue | $ | 12,843 |  |  | $ | 12,357 |  |  | 3.9 | % |  | $ | 49,161 |  |  | $ | 47,142 |  |  | 4.3 | % |  |
| Gross margin percentage | 60.2 | % |  | 59.9 | % |  | 0.3 |  | pts | 60.4 | % |  | 58.9 | % |  | 1.5 |  | pts |
| Research and development | $ | 1,548 |  |  | $ | 1,593 |  |  | (2.8 | )% |  | $ | 6,207 |  |  | $ | 6,294 |  |  | (1.4 | )% |  |
| Sales and marketing | $ | 2,549 |  |  | $ | 2,473 |  |  | 3.1 | % |  | $ | 9,821 |  |  | $ | 9,503 |  |  | 3.3 | % |  |
| General and administrative | $ | 536 |  |  | $ | 508 |  |  | 5.5 | % |  | $ | 2,040 |  |  | $ | 1,934 |  |  | 5.5 | % |  |
| Total R&D, sales and marketing, general and administrative | $ | 4,633 |  |  | $ | 4,574 |  |  | 1.3 | % |  | $ | 18,068 |  |  | $ | 17,731 |  |  | 1.9 | % |  |
| Total as a percentage of revenue | 36.1 | % |  | 37.0 | % |  | (0.9 | ) | pts | 36.8 | % |  | 37.6 | % |  | (0.8 | ) | pts |
| Amortization of purchased intangible assets included in operating expenses | $ | 146 |  |  | $ | 68 |  |  | 114.7 | % |  | $ | 359 |  |  | $ | 275 |  |  | 30.5 | % |  |
| Restructuring and other charges | $ | 73 |  |  | $ | 82 |  |  | (11.0 | )% |  | $ | 484 |  |  | $ | 418 |  |  | 15.8 | % |  |
| Operating income as a percentage of revenue | 22.4 | % |  | 21.7 | % |  | 0.7 |  | pts | 21.9 | % |  | 19.8 | % |  | 2.1 |  | pts |
| Income tax percentage | 20.9 | % |  | 19.1 | % |  | 1.8 |  | pts | 19.8 | % |  | 19.2 | % |  | 0.6 |  | pts |
| Net income | $ | 2,319 |  |  | $ | 2,247 |  |  | 3.2 | % |  | $ | 8,981 |  |  | $ | 7,853 |  |  | 14.4 | % |  |
| Net income as a percentage of revenue | 18.1 | % |  | 18.2 | % |  | (0.1 | ) | pts | 18.3 | % |  | 16.7 | % |  | 1.6 |  | pts |
| Earnings per share—diluted | $ | 0.45 |  |  | $ | 0.43 |  |  | 4.7 | % |  | $ | 1.75 |  |  | $ | 1.49 |  |  | 17.4 | % |  |

[0000858877-15-000070:mdna:8]
36

[0000858877-15-000070:mdna:9]
Fiscal 2015 Compared with Fiscal 2014—Financial Performance

[0000858877-15-000070:mdna:10]
Total revenue increased by 4% as compared with fiscal 2014, with product and service revenue each increasing by 4%. Total gross margin increased by 1.5 percentage points, as we experienced stable gross margins and the absence in fiscal 2015 of a $655 million supplier component remediation charge recorded in fiscal 2014. As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses, collectively, decreased by 0.8 percentage points, primarily as a result of higher acquisition-related compensation expense in fiscal 2014. Operating income as a percentage of revenue increased by 2.1 percentage points. Diluted earnings per share increased by 17% from the prior year, as a result of both a 14% increase in net income and a decrease in diluted share count by 135 million shares.

[0000858877-15-000070:mdna:11]
In fiscal 2015, revenue increased by $2.0 billion as compared with fiscal 2014. Revenue from the Americas increased by $1.9 billion, driven in large part by higher product revenue in the United States. EMEA revenue increased $0.3 billion, led by higher product revenue in the United Kingdom. Revenue in our APJC segment decreased $0.2 billion, led by a product revenue decline in China. We experienced decreased product revenue in the emerging countries of China and Russia and increased revenue in Mexico, India and Brazil, as the “BRICM” countries experienced, in the aggregate, a product revenue decline of 4%.  We believe that the product revenue declines we experienced in various emerging countries reflected the impact of economic and geopolitical challenges in those countries.

[0000858877-15-000070:mdna:12]
From a customer market standpoint, in fiscal 2015 we experienced solid product revenue growth in the commercial, public sector and enterprise markets, while the service provider market continued to decline. The decline in service provider market was driven by the product revenue decline in our Service Provider Video category.

[0000858877-15-000070:mdna:13]
From a product category perspective, the product revenue increase of 4% year-over-year was driven in part by product revenue growth in our core Switching and NGN Routing products which grew 5% and 1%, respectively.  We also experienced an increase in revenue from Data Center and Security products which grew 22% and 12%, respectively. Our other major product categories experienced revenue growth with the exception of Service Provider Video which decreased by 10%.  Our deferred product revenue grew 21% year-over-year driven by subscription and software revenue arrangements, with strength in Collaboration, Security and Wireless.  Service revenue increased by 4% year over year.

[0000858877-15-000070:mdna:14]
In summary, during fiscal 2015, we achieved solid and profitable revenue growth despite encountering challenges similar to those we experienced during fiscal 2014 in the service provider market and certain emerging countries.

[0000858877-15-000070:mdna:15]
37

[0000858877-15-000070:mdna:16]
Fourth Quarter Snapshot

[0000858877-15-000070:mdna:17]
For the fourth quarter of fiscal 2015, as compared with the corresponding period in fiscal 2014, total revenue grew 4%, as product and service revenue each increased by 4%. With regard to our geographic segment performance, on a year-over-year basis revenue in the Americas increased by 7%, while EMEA and APJC were both flat. From a product category perspective, product revenue growth was driven by growth from Collaboration and Data Center products, as each grew 14% year over year. Total gross margin increased by 0.3 percentage points. As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses collectively decreased by 0.9 percentage points. Operating income as a percentage of revenue increased by 0.7 percentage points. Diluted earnings per share increased by 5% from the prior year, primarily as a result of both a 3% increase in net income and a decrease in our diluted share count by 41 million shares.

[0000858877-15-000070:mdna:18]
Strategy and Focus Areas

[0000858877-15-000070:mdna:19]
We see our customers, in every industry, increasingly using technology—and, specifically, the network—to grow their business, drive efficiencies, and try to gain a competitive advantage.  In this increasingly digital world, data is the most strategic asset and is increasingly distributed across every organization and ecosystem—on customer premises, at the edge of the network, and in the cloud.  The network also plays an increasingly important role enabling our customers to aggregate, automate, and draw insights from this highly distributed data where there is a premium on security and speed. This is driving them to adopt entirely new IT architectures and organizational structures. We understand how technology can deliver the outcomes our customers want to achieve, and our strategy is to lead our customers in their digital transition with solutions including pervasive, industry-leading security that intelligently connect nearly everything that can be connected.

[0000858877-15-000070:mdna:20]
To deliver on our strategy, we are focused on providing highly secure, automated and intelligent solutions built on infrastructure that connects data that is highly distributed (globally dispersed across organizations).  Together with our ecosystem of partners and developers, we aim to provide the technology, services, and solutions that we believe will enable our customers to gain insight and advantage from this distributed data with scale, security and agility.

[0000858877-15-000070:mdna:21]
For a full discussion of our strategy and focus areas, see Item 1. Business.

[0000858877-15-000070:mdna:22]
Other Key Financial Measures

[0000858877-15-000070:mdna:23]
The following is a summary of our other key financial measures for fiscal 2015 compared with fiscal 2014 (in millions, except days sales outstanding in accounts receivable (DSO) and annualized inventory turns):

[0000858877-15-000070:mdna:24]
|  |  | Fiscal 2015 |  | Fiscal 2014 |
| Cash and cash equivalents and investments |  | $60,416 |  | $52,074 |
| Cash provided by operating activities |  | $12,552 |  | $12,332 |
| Deferred revenue |  | $15,183 |  | $14,142 |
| Repurchases of common stock—stock repurchase program |  | $4,234 |  | $9,539 |
| Dividends |  | $4,086 |  | $3,758 |
| DSO |  | 38 days |  | 38 days |
| Inventories |  | $1,627 |  | $1,591 |
| Annualized inventory turns |  | 12.1 |  | 12.7 |

[0000858877-15-000070:mdna:25]
Our product backlog at the end of fiscal 2015 was $5.1 billion, or 10% of fiscal 2015 total revenue, compared with $5.4 billion at the end of fiscal 2014, or 12% of fiscal 2014 total revenue.

[0000858877-15-000070:mdna:26]
38

[0000858877-15-000070:mdna:27]
CRITICAL ACCOUNTING ESTIMATES

[0000858877-15-000070:mdna:28]
The preparation of financial statements and related disclosures in conformity with accounting principles generally accepted in the United States requires us to make judgments, assumptions, and estimates that affect the amounts reported in the Consolidated Financial Statements and accompanying notes.  Note 2 to the Consolidated Financial Statements describes the significant accounting policies and methods used in the preparation of the Consolidated Financial Statements.  The accounting policies described below are significantly affected by critical accounting estimates.  Such accounting policies require significant judgments, assumptions, and estimates used in the preparation of the Consolidated Financial Statements, and actual results could differ materially from the amounts reported based on these policies.

[0000858877-15-000070:mdna:29]
Revenue Recognition

[0000858877-15-000070:mdna:30]
Revenue is recognized when all of the following criteria have been met:

[0000858877-15-000070:mdna:31]
| • | Persuasive evidence of an arrangement exists. Contracts, Internet commerce agreements, and customer purchase orders are generally used to determine the existence of an arrangement. |

[0000858877-15-000070:mdna:32]
| • | Delivery has occurred. Shipping documents and customer acceptance, when applicable, are used to verify delivery. |

[0000858877-15-000070:mdna:33]
| • | The fee is fixed or determinable. We assess whether the fee is fixed or determinable based on the payment terms associated with the transaction and whether the sales price is subject to refund or adjustment. |

[0000858877-15-000070:mdna:34]
| • | Collectibility is reasonably assured. We assess collectibility based primarily on the creditworthiness of the customer as determined by credit checks and analysis, as well as the customer’s payment history. |

[0000858877-15-000070:mdna:35]
In instances where final acceptance of the product, system, or solution is specified by the customer, revenue is deferred until all acceptance criteria have been met.  When a sale involves multiple deliverables, such as sales of products that include services, the multiple deliverables are evaluated to determine the unit of accounting, and the entire fee from the arrangement is allocated to each unit of accounting based on the relative selling price.  Revenue is recognized when the revenue recognition criteria for each unit of accounting are met.  For hosting arrangements, we recognize subscription revenue ratably over the subscription period, while usage revenue is recognized based on utilization. Software subscription revenue is deferred and recognized ratably over the subscription term upon delivery of the first product and commencement of the term.

[0000858877-15-000070:mdna:36]
The amount of product and service revenue recognized in a given period is affected by our judgment as to whether an arrangement includes multiple deliverables and, if so, our valuation of the units of accounting for multiple deliverables. According to the accounting guidance prescribed in Accounting Standards Codification (ASC) 605, Revenue Recognition, we use vendor-specific objective evidence of selling price (VSOE) for each of those units, when available. We determine VSOE based on our normal pricing and discounting practices for the specific product or service when sold separately.  In determining VSOE, we require that a substantial majority of the historical standalone transactions have the selling prices for a product or service fall within a reasonably narrow pricing range, generally evidenced by approximately 80% of such historical standalone transactions falling within plus or minus 15% of the median rates. When VSOE does not exist, we apply the selling price hierarchy to applicable multiple-deliverable arrangements.  Under the selling price hierarchy, third-party evidence of selling price (TPE) will be considered if VSOE does not exist, and estimated selling price (ESP) will be used if neither VSOE nor TPE is available.  Generally, we are not able to determine TPE because our go-to-market strategy differs from that of others in our markets, and the extent of our proprietary technology varies among comparable products or services from those of our peers.  In determining ESP, we apply significant judgment as we weigh a variety of factors, based on the facts and circumstances of the arrangement.  We typically arrive at an ESP for a product or service that is not sold separately by considering company-specific factors such as geographies, competitive landscape, internal costs, profitability objectives, pricing practices used to establish bundled pricing, and existing portfolio pricing and discounting.

[0000858877-15-000070:mdna:37]
Some of our sales arrangements have multiple deliverables containing software and related software support components. Such sales arrangements are subject to the accounting guidance in ASC 985-605, Software-Revenue Recognition.

[0000858877-15-000070:mdna:38]
As our business and offerings evolve over time, our pricing practices may be required to be modified accordingly, which could result in changes in selling prices, including both VSOE and ESP, in subsequent periods. There were no material impacts during fiscal 2015, nor do we currently expect a material impact in the next 12 months on our revenue recognition due to any changes in our VSOE, TPE, or ESP.

[0000858877-15-000070:mdna:39]
Revenue deferrals relate to the timing of revenue recognition for specific transactions based on financing arrangements, service, support, and other factors. Financing arrangements may include sales-type, direct-financing, and operating leases, loans, and guarantees of third-party financing. Our deferred revenue for products was $5.4 billion and $4.5 billion as of July 25, 2015 and July 26, 2014, respectively. Technical support services revenue is deferred and recognized ratably over the period during which the services are to be performed, which typically is from one to three years. Advanced services revenue is recognized upon delivery or completion of performance milestones. Our deferred revenue for services was $9.8 billion and $9.6 billion as of July 25, 2015 and July 26, 2014, respectively.

[0000858877-15-000070:mdna:40]
We make sales to distributors which we refer to as two-tier systems of sales to the end customer.  Revenue from distributors is recognized based on a sell-through method using information provided by them.  Our distributors participate in various cooperative marketing and other programs, and we maintain estimated accruals and allowances for these programs.  If actual credits received by our distributors under these programs were to deviate significantly from our estimates, which are based on historical experience, our revenue could be adversely affected.

[0000858877-15-000070:mdna:41]
Allowances for Receivables and Sales Returns

[0000858877-15-000070:mdna:42]
The allowances for receivables were as follows (in millions, except percentages):

[0000858877-15-000070:mdna:43]
|  |  | July 25, 2015 |  |  | July 26, 2014 |  |
| Allowance for doubtful accounts |  | $ | 302 |  |  | $ | 265 |  |
| Percentage of gross accounts receivable |  | 5.4 | % |  | 4.9 | % |
| Allowance for credit loss—lease receivables |  | $ | 259 |  |  | $ | 233 |  |
| Percentage of gross lease receivables (1) |  | 7.2 | % |  | 6.2 | % |
| Allowance for credit loss—loan receivables |  | $ | 87 |  |  | $ | 98 |  |
| Percentage of gross loan receivables |  | 4.9 | % |  | 5.8 | % |

[0000858877-15-000070:mdna:44]
(1) Calculated as allowance for credit loss on lease receivables as a percentage of gross lease receivables and residual value before unearned income.

[0000858877-15-000070:mdna:45]
The allowance for doubtful accounts is based on our assessment of the collectibility of customer accounts. We regularly review the adequacy of these allowances by considering internal factors such as historical experience, credit quality and age of the receivable balances as well as external factors such as economic conditions that may affect a customer’s ability to pay and expected default frequency rates, which are published by major third-party credit-rating agencies and are generally updated on a quarterly basis. We also consider the concentration of receivables outstanding with a particular customer in assessing the adequacy of our allowances for doubtful accounts. If a major customer’s creditworthiness deteriorates, if actual defaults are higher than our historical experience, or if other circumstances arise, our estimates of the recoverability of amounts due to us could be overstated, and additional allowances could be required, which could have an adverse impact on our operating results.

[0000858877-15-000070:mdna:46]
The allowance for credit loss on financing receivables is also based on the assessment of collectibility of customer accounts. We regularly review the adequacy of the credit allowances determined either on an individual or a collective basis. When evaluating the financing receivables on an individual basis, we consider historical experience, credit quality and age of receivable balances, and economic conditions that may affect a customer’s ability to pay.   When evaluating financing receivables on a collective basis, we use expected default frequency rates published by a major third-party credit-rating agency as well as our own historical loss rate in the event of default, while also systematically giving effect to economic conditions, concentration of risk and correlation.  Determining expected default frequency rates and loss factors associated with internal credit risk ratings, as well as assessing factors such as economic conditions, concentration of risk, and correlation, are complex and subjective. Our ongoing consideration of all these factors could result in an increase in our allowance for credit loss in the future, which could adversely affect our operating results.  Both accounts receivable and financing receivables are charged off at the point when they are considered uncollectible.

[0000858877-15-000070:mdna:47]
A reserve for future sales returns is established based on historical trends in product return rates. The reserve for future sales returns as of July 25, 2015 and July 26, 2014 was $129 million and $135 million, respectively, and was recorded as a reduction of our accounts receivable.  If the actual future returns were to deviate from the historical data on which the reserve had been established, our revenue could be adversely affected.

[0000858877-15-000070:mdna:48]
Inventory Valuation and Liability for Purchase Commitments with Contract Manufacturers and Suppliers

[0000858877-15-000070:mdna:49]
Our inventory balance was $1.6 billion as of each July 25, 2015 and July 26, 2014. Inventory is written down based on excess and obsolete inventories, determined primarily by future demand forecasts. Inventory write-downs are measured as the difference between the cost of the inventory and market, based upon assumptions about future demand, and are charged to the provision for inventory, which is a component of our cost of sales. At the point of the loss recognition, a new, lower cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis.

[0000858877-15-000070:mdna:50]
We record a liability for firm, noncancelable, and unconditional purchase commitments with contract manufacturers and suppliers for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of July 25, 2015, the liability for these purchase commitments was $156 million, compared with $162 million as of July 26, 2014, and was included in other current liabilities.

[0000858877-15-000070:mdna:51]
40

[0000858877-15-000070:mdna:52]
Our provision for inventory was $54 million, $67 million, and $114 million in fiscal 2015, 2014, and 2013, respectively. The provision for the liability related to purchase commitments with contract manufacturers and suppliers was $102 million, $124 million, and $106 million in fiscal 2015, 2014, and 2013, respectively. If there were to be a sudden and significant decrease in demand for our products, or if there were a higher incidence of inventory obsolescence because of rapidly changing technology and customer requirements, we could be required to increase our inventory write-downs, and our liability for purchase commitments with contract manufacturers and suppliers, and accordingly our profitability, could be adversely affected. We regularly evaluate our exposure for inventory write-downs and the adequacy of our liability for purchase commitments. Inventory and supply chain management remain areas of focus as we balance the need to maintain supply chain flexibility to help ensure competitive lead times with the risk of inventory obsolescence, particularly in light of current macroeconomic uncertainties and conditions and the resulting potential for changes in future demand forecast.

[0000858877-15-000070:mdna:53]
Loss Contingencies and Product Warranties

[0000858877-15-000070:mdna:54]
We are subject to the possibility of various losses arising in the ordinary course of business. We consider the likelihood of impairment of an asset or the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated. We regularly evaluate information available to us to determine whether such accruals should be made or adjusted and whether new accruals are required.

[0000858877-15-000070:mdna:55]
Third parties, including customers, have in the past and may in the future assert claims or initiate litigation related to exclusive patent, copyright, trademark, and other intellectual property rights to technologies and related standards that are relevant to us. These assertions have increased over time as a result of our growth and the general increase in the pace of patent claims assertions, particularly in the United States. If any infringement or other intellectual property claim made against us by any third party is successful, or if we fail to develop non-infringing technology or license the proprietary rights on commercially reasonable terms and conditions, our business, operating results, and financial condition could be materially and adversely affected.

[0000858877-15-000070:mdna:56]
We have recorded a liability for the expected remediation cost for certain products sold in prior fiscal years containing memory components manufactured by a single supplier between 2005 and 2010. In February 2014, on the basis of the growing number of failures as described in Note 12 (f) to the Consolidated Financial Statements, we decided to expand our approach, which resulted in a charge to product cost of sales of $655 million being recorded for the second quarter of fiscal 2014. During the third quarter of fiscal 2015, we recorded an adjustment to product cost of sales of $164 million to reduce the liability, reflecting net lower than previously estimated future costs to remediate the impacted customer products. Estimating this liability is complex and subjective, and if we experience changes in a number of underlying assumptions and estimates such as a change in claims compared with our expectations, or if the cost of servicing these claims is different than expected, our estimated liability may be impacted.

[0000858877-15-000070:mdna:57]
Our liability for product warranties, included in other current liabilities, was $449 million as of July 25, 2015, compared with $446 million as of July 26, 2014. Our products are generally covered by a warranty for periods ranging from 90 days to five years, and for some products we provide a limited lifetime warranty. We accrue for warranty costs as part of our cost of sales based on associated material costs, technical support labor costs, and associated overhead. Material cost is estimated based primarily upon historical trends in the volume of product returns within the warranty period and the cost to repair or replace the equipment. Technical support labor cost is estimated based primarily upon historical trends in the rate of customer cases and the cost to support the customer cases within the warranty period. Overhead cost is applied based on estimated time to support warranty activities.

[0000858877-15-000070:mdna:58]
The provision for product warranties during fiscal 2015, 2014, and 2013 was $696 million, $704 million, and $649 million, respectively. If we experience an increase in warranty claims compared with our historical experience, or if the cost of servicing warranty claims is greater than expected, our profitability could be adversely affected.

[0000858877-15-000070:mdna:59]
Fair Value Measurements

[0000858877-15-000070:mdna:60]
Our fixed income and publicly traded equity securities, collectively, are reflected in the Consolidated Balance Sheets at a fair value of $53.5 billion as of July 25, 2015, compared with $45.3 billion as of July 26, 2014. Our fixed income investment portfolio, as of July 25, 2015, consisted primarily of high quality investment-grade securities. See Note 8 to the Consolidated Financial Statements.

[0000858877-15-000070:mdna:61]
As described more fully in Note 2 to the Consolidated Financial Statements, a valuation hierarchy is based on the level of independent, objective evidence available regarding the value of the investments. It encompasses three classes of investments: Level 1 consists of securities for which there are quoted prices in active markets for identical securities; Level 2 consists of securities for which observable inputs other than Level 1 inputs are used, such as quoted prices for similar securities in active markets or quoted prices for identical securities in less active markets and model-derived valuations for which the variables are derived from, or corroborated by, observable market data; and Level 3 consists of securities for which there are unobservable inputs to the valuation methodology that are significant to the measurement of the fair value.

[0000858877-15-000070:mdna:62]
41

[0000858877-15-000070:mdna:63]
Our Level 2 securities are valued using quoted market prices for similar instruments or nonbinding market prices that are corroborated by observable market data. We use inputs such as actual trade data, benchmark yields, broker/dealer quotes, and other similar data, which are obtained from independent pricing vendors, quoted market prices, or other sources to determine the ultimate fair value of our assets and liabilities. We use such pricing data as the primary input, to which we have not made any material adjustments during fiscal 2015 and 2014, to make our assessments and determinations as to the ultimate valuation of our investment portfolio. We are ultimately responsible for the financial statements and underlying estimates.

[0000858877-15-000070:mdna:64]
The inputs and fair value are reviewed for reasonableness, may be further validated by comparison to publicly available information, and could be adjusted based on market indices or other information that management deems material to its estimate of fair value. The assessment of fair value can be difficult and subjective. However, given the relative reliability of the inputs we use to value our investment portfolio, and because substantially all of our valuation inputs are obtained using quoted market prices for similar or identical assets, we do not believe that the nature of estimates and assumptions affected by levels of subjectivity and judgment was material to the valuation of the investment portfolio as of July 25, 2015. Level 3 assets do not represent a significant portion of our total assets measured at fair value on a recurring basis as of July 25, 2015 and July 26, 2014.

[0000858877-15-000070:mdna:65]
Other-than-Temporary Impairments

[0000858877-15-000070:mdna:66]
We recognize an impairment charge when the declines in the fair values of our fixed income or publicly traded equity securities below their cost basis are judged to be other than temporary. The ultimate value realized on these securities, to the extent unhedged, is subject to market price volatility until they are sold.

[0000858877-15-000070:mdna:67]
If the fair value of a debt security is less than its amortized cost, we assess whether the impairment is other than temporary. An impairment is considered other than temporary if (i) we have the intent to sell the security, (ii) it is more likely than not that we will be required to sell the security before recovery of its entire amortized cost basis, or (iii) we do not expect to recover the entire amortized cost of the security. If an impairment is considered other than temporary based on (i) or (ii) described in the prior sentence, the entire difference between the amortized cost and the fair value of the security is recognized in earnings. If an impairment is considered other than temporary based on condition (iii), the amount representing credit loss, defined as the difference between the present value of the cash flows expected to be collected and the amortized cost basis of the debt security, will be recognized in earnings, and the amount relating to all other factors will be recognized in other comprehensive income (OCI). In estimating the amount and timing of cash flows expected to be collected, we consider all available information, including past events, current conditions, the remaining payment terms of the security, the financial condition of the issuer, expected defaults, and the value of underlying collateral.

[0000858877-15-000070:mdna:68]
For publicly traded equity securities, we consider various factors in determining whether we should recognize an impairment charge, including the length of time and extent to which the fair value has been less than our cost basis, the financial condition and near-term prospects of the issuer, and our intent and ability to hold the investment for a period of time sufficient to allow for any anticipated recovery in market value.

[0000858877-15-000070:mdna:69]
There were no impairment charges on our investments in publicly traded equity securities in fiscal 2015 and 2013, and we recognized $11 million of such impairment charges in earnings for fiscal 2014. There were no impairment charges on our investments in fixed income securities in fiscal 2015, 2014, and 2013. Our ongoing consideration of all the factors described previously could result in additional impairment charges in the future, which could adversely affect our net income.

[0000858877-15-000070:mdna:70]
We also have investments in privately held companies, some of which are in the startup or development stages. As of July 25, 2015, our investments in privately held companies were $897 million, compared with $899 million as of July 26, 2014, and were included in other assets. We monitor these investments for events or circumstances indicative of potential impairment, and we make appropriate reductions in carrying values if we determine that an impairment charge is required, based primarily on the financial condition and near-term prospects of these companies. These investments are inherently risky because the markets for the technologies or products these companies are developing are typically in the early stages and may never materialize. Our impairment charges on investments in privately held companies were $41 million, $23 million, and $33 million in fiscal 2015, 2014, and 2013, respectively.

[0000858877-15-000070:mdna:71]
Goodwill and Purchased Intangible Asset Impairments

[0000858877-15-000070:mdna:72]
Our methodology for allocating the purchase price relating to purchase acquisitions is determined through established valuation techniques. Goodwill represents a residual value as of the acquisition date, which in most cases results in measuring goodwill as an excess of the purchase consideration transferred plus the fair value of any noncontrolling interest in the acquired company over the fair value of net assets acquired, including contingent consideration. We perform goodwill impairment tests on an annual basis in the fourth fiscal quarter and between annual tests in certain circumstances for each reporting unit. The assessment of fair value for goodwill and purchased intangible assets is based on factors that market participants would use in an orderly transaction in accordance with the new accounting guidance for the fair value measurement of nonfinancial assets.

[0000858877-15-000070:mdna:73]
The goodwill recorded in the Consolidated Balance Sheets as of July 25, 2015 and July 26, 2014 was $24.5 billion and $24.2 billion, respectively.  In response to changes in industry and market conditions, we could be required to strategically realign our resources and consider restructuring, disposing of, or otherwise exiting businesses, which could result in an impairment of goodwill. There was no impairment of goodwill resulting from our annual impairment testing in fiscal 2015, 2014, and 2013. For the annual impairment testing in fiscal 2015, the excess of the fair value over the carrying value for each of our reporting units was $40.8 billion for the Americas, $32.6 billion for EMEA, and $12.9 billion for APJC.  During the fourth quarter of fiscal 2015, we performed a sensitivity analysis for goodwill impairment with respect to each of our respective reporting units and determined that a hypothetical 10% decline in the fair value of each reporting unit would not result in an impairment of goodwill for any reporting unit.

[0000858877-15-000070:mdna:74]
We make judgments about the recoverability of purchased intangible assets with finite lives whenever events or changes in circumstances indicate that an impairment may exist. Recoverability of purchased intangible assets with finite lives is measured by comparing the carrying amount of the asset to the future undiscounted cash flows the asset is expected to generate. We review indefinite-lived intangible assets for impairment annually or whenever events or changes in circumstances indicate that the asset might be impaired. If the asset is considered to be impaired, the amount of any impairment is measured as the difference between the carrying value and the fair value of the impaired asset. Assumptions and estimates about future values and remaining useful lives of our purchased intangible assets are complex and subjective. They can be affected by a variety of factors, including external factors such as industry and economic trends, and internal factors such as changes in our business strategy and our internal forecasts. Our impairment charges related to purchased intangible assets were $175 million during fiscal 2015. There were no impairment charges related to purchased intangible assets during fiscal 2014 and fiscal 2013. Our ongoing consideration of all the factors described previously could result in additional impairment charges in the future, which could adversely affect our net income.

[0000858877-15-000070:mdna:75]
Income Taxes

[0000858877-15-000070:mdna:76]
We are subject to income taxes in the United States and numerous foreign jurisdictions. Our effective tax rates differ from the statutory rate, primarily due to the tax impact of state taxes, foreign operations, R&D tax credits, domestic manufacturing deductions, tax audit settlements, nondeductible compensation, international realignments, and transfer pricing adjustments. Our effective tax rate was 19.8%, 19.2%, and 11.1% in fiscal 2015, 2014, and 2013, respectively.

[0000858877-15-000070:mdna:77]
Significant judgment is required in evaluating our uncertain tax positions and determining our provision for income taxes. Although we believe our reserves are reasonable, no assurance can be given that the final tax outcome of these matters will not be different from that which is reflected in our historical income tax provisions and accruals. We adjust these reserves in light of changing facts and circumstances, such as the closing of a tax audit or the refinement of an estimate. To the extent that the final tax outcome of these matters is different than the amounts recorded, such differences will impact the provision for income taxes in the period in which such determination is made. The provision for income taxes includes the impact of reserve provisions and changes to reserves that are considered appropriate, as well as the related net interest and penalties.

[0000858877-15-000070:mdna:78]
Significant judgment is also required in determining any valuation allowance recorded against deferred tax assets. In assessing the need for a valuation allowance, we consider all available evidence, including past operating results, estimates of future taxable income, and the feasibility of tax planning strategies. In the event that we change our determination as to the amount of deferred tax assets that can be realized, we will adjust our valuation allowance with a corresponding impact to the provision for income taxes in the period in which such determination is made.

[0000858877-15-000070:mdna:79]
Our provision for income taxes is subject to volatility and could be adversely impacted by earnings being lower than anticipated in countries that have lower tax rates and higher than anticipated in countries that have higher tax rates; by changes in the valuation of our deferred tax assets and liabilities; by expiration of or lapses in the R&D tax credit or domestic manufacturing deduction laws; by expiration of or lapses in tax incentives; by transfer pricing adjustments, including the effect of acquisitions on our intercompany R&D cost-sharing arrangement and legal structure; by tax effects of nondeductible compensation; by tax costs related to intercompany realignments; by changes in accounting principles; or by changes in tax laws and regulations, treaties, or interpretations thereof, including possible changes to the taxation of earnings of our foreign subsidiaries, the deductibility of expenses attributable to foreign income, or the foreign tax credit rules.  Significant judgment is required to determine the recognition and measurement attributes prescribed in the accounting guidance for uncertainty in income taxes.  The Organisation for Economic Co-operation and Development (OECD), an international association comprised of 34 countries, including the United States, is contemplating changes to numerous long-standing tax principles.  These contemplated changes, if finalized and adopted by countries, will increase tax uncertainty and may adversely affect our provision for income taxes.  As a result of certain of our ongoing employment and capital investment actions and commitments, our income in certain countries is subject to reduced tax rates and in some cases is wholly exempt from tax. Our failure to meet these commitments could adversely impact our provision for income taxes. In addition, we are subject to the continuous examination of our income tax returns by the Internal Revenue Service (IRS) and other tax authorities. We regularly assess the likelihood of adverse outcomes resulting from these examinations to determine the adequacy of our provision for income taxes. There can be no assurance that the outcomes from these continuous examinations will not have an adverse impact on our operating results and financial condition.

[0000858877-15-000070:mdna:80]
RESULTS OF OPERATIONS

[0000858877-15-000070:mdna:81]
Revenue

[0000858877-15-000070:mdna:82]
The following table presents the breakdown of revenue between product and service (in millions, except percentages):

[0000858877-15-000070:mdna:83]
|  |  | Years Ended |  | 2015 vs. 2014 |  | 2014 vs. 2013 |
|  |  | July 25, 2015 |  | July 26, 2014 |  | July 27, 2013 |  | Variance in Dollars |  | Variance in Percent |  | Variance in Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 37,750 |  |  | $ | 36,172 |  |  | $ | 38,029 |  |  | $ | 1,578 |  |  | 4.4 | % |  | $ | (1,857 | ) |  | (4.9 | )% |
| Percentage of revenue |  | 76.8 | % |  | 76.7 | % |  | 78.2 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Service |  | 11,411 |  |  | 10,970 |  |  | 10,578 |  |  | 441 |  |  | 4.0 | % |  | 392 |  |  | 3.7 | % |
| Percentage of revenue |  | 23.2 | % |  | 23.3 | % |  | 21.8 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Total |  | $ | 49,161 |  |  | $ | 47,142 |  |  | $ | 48,607 |  |  | $ | 2,019 |  |  | 4.3 | % |  | $ | (1,465 | ) |  | (3.0 | )% |

[0000858877-15-000070:mdna:84]
We manage our business primarily on a geographic basis, organized into three geographic segments. Our revenue, which includes product and service for each segment, is summarized in the following table (in millions, except percentages):

[0000858877-15-000070:mdna:85]
|  |  | Years Ended |  | 2015 vs. 2014 |  | 2014 vs. 2013 |
|  |  | July 25, 2015 |  | July 26, 2014 |  | July 27, 2013 |  | Variance in Dollars |  | Variance in Percent |  | Variance in Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 29,655 |  |  | $ | 27,781 |  |  | $ | 28,639 |  |  | $ | 1,874 |  |  | 6.7 | % |  | $ | (858 | ) |  | (3.0 | )% |
| Percentage of revenue |  | 60.3 | % |  | 58.9 | % |  | 58.9 | % |  |  |  |  |  |  |  |  |
| EMEA |  | 12,322 |  |  | 12,006 |  |  | 12,210 |  |  | 316 |  |  | 2.6 | % |  | (204 | ) |  | (1.7 | )% |
| Percentage of revenue |  | 25.1 | % |  | 25.5 | % |  | 25.1 | % |  |  |  |  |  |  |  |  |
| APJC |  | 7,184 |  |  | 7,355 |  |  | 7,758 |  |  | (171 | ) |  | (2.3 | )% |  | (403 | ) |  | (5.2 | )% |
| Percentage of revenue |  | 14.6 | % |  | 15.6 | % |  | 16.0 | % |  |  |  |  |  |  |  |  |
| Total |  | $ | 49,161 |  |  | $ | 47,142 |  |  | $ | 48,607 |  |  | $ | 2,019 |  |  | 4.3 | % |  | $ | (1,465 | ) |  | (3.0 | )% |

[0000858877-15-000070:mdna:86]
Fiscal 2015 Compared with Fiscal 2014

[0000858877-15-000070:mdna:87]
For fiscal 2015, as compared with fiscal 2014, total revenue increased by 4%, as product and service revenue each increased by 4%.  Our total revenue grew in our Americas and EMEA geographic segments, while revenue declined in the APJC segment. The emerging countries of BRICM, in the aggregate, experienced a 4% product revenue decline, with declines in China and Russia partially offset by increases in the other three BRICM countries.

[0000858877-15-000070:mdna:88]
We conduct business globally in numerous currencies. The direct effect of foreign currency fluctuations on revenue has not been material because our revenue is primarily denominated in U.S. dollars. However, if the U.S. dollar strengthens relative to other currencies, as was the case during fiscal 2015, such strengthening could have an indirect effect on our revenue to the extent it raises the cost of our products to non-U.S. customers and thereby reduces demand. A weaker U.S. dollar could have the opposite effect. However, the precise indirect effect of currency fluctuations is difficult to measure or predict because our revenue is influenced by many factors in addition to the impact of such currency fluctuations. Our revenue in fiscal 2015, and in particular our revenue for EMEA and APJC, was adversely affected by the depreciation of certain currencies relative to the U.S. dollar especially in certain emerging countries, although the indirect effects are difficult to measure.

[0000858877-15-000070:mdna:89]
In addition to the impact of macroeconomic factors, including a reduced IT spending environment and reductions in spending by government entities, revenue by segment in a particular period may be significantly impacted by several factors related to revenue recognition, including the complexity of transactions such as multiple-element arrangements; the mix of financing arrangements provided to our channel partners and customers; and final acceptance of the product, system, or solution, among other factors. In addition, certain customers tend to make large and sporadic purchases, and the revenue related to these transactions may also be affected by the timing of revenue recognition, which in turn would impact the revenue of the relevant segment. As has been the case in certain of our emerging countries from time to time, customers require greater levels of financing arrangements, service, and support, and these activities may occur in future periods, which may also impact the timing of the recognition of revenue.

[0000858877-15-000070:mdna:90]
Fiscal 2014 Compared with Fiscal 2013

[0000858877-15-000070:mdna:91]
For fiscal 2014, as compared with fiscal 2013, total revenue decreased by 3%. Product revenue decreased by 5%, while service revenue increased by 4%. The decrease in product revenue reflected declines across all geographic segments as well as across all customer markets. Service revenues experienced slower growth in our Americas and APJC geographic segments while we experienced slightly faster growth in the EMEA segment.

[0000858877-15-000070:mdna:92]
Product Revenue by Segment

[0000858877-15-000070:mdna:93]
The following table presents the breakdown of product revenue by segment (in millions, except percentages):

[0000858877-15-000070:mdna:94]
|  |  | Years Ended |  | 2015 vs. 2014 |  | 2014 vs. 2013 |
|  |  | July 25, 2015 |  | July 26, 2014 |  | July 27, 2013 |  | Variance in Dollars |  | Variance in Percent |  | Variance in Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 22,261 |  |  | $ | 20,631 |  |  | $ | 21,653 |  |  | $ | 1,630 |  |  | 7.9 | % |  | $ | (1,022 | ) |  | (4.7 | )% |
| Percentage of product revenue |  | 59.0 | % |  | 57.0 | % |  | 57.0 | % |  |  |  |  |  |  |  |  |
| EMEA |  | 9,856 |  |  | 9,655 |  |  | 10,049 |  |  | 201 |  |  | 2.1 | % |  | (394 | ) |  | (3.9 | )% |
| Percentage of product revenue |  | 26.1 | % |  | 26.7 | % |  | 26.4 | % |  |  |  |  |  |  |  |  |
| APJC |  | 5,633 |  |  | 5,886 |  |  | 6,327 |  |  | (253 | ) |  | (4.3 | )% |  | (441 | ) |  | (7.0 | )% |
| Percentage of product revenue |  | 14.9 | % |  | 16.3 | % |  | 16.6 | % |  |  |  |  |  |  |  |  |
| Total |  | $ | 37,750 |  |  | $ | 36,172 |  |  | $ | 38,029 |  |  | $ | 1,578 |  |  | 4.4 | % |  | $ | (1,857 | ) |  | (4.9 | )% |

[0000858877-15-000070:mdna:95]
Americas

[0000858877-15-000070:mdna:96]
Fiscal 2015 Compared with Fiscal 2014

[0000858877-15-000070:mdna:97]
The increase in product revenue in the Americas segment of 8% was led by solid growth in the public sector, commercial and enterprise markets. The product revenue growth in the public sector market was due primarily to higher sales to the U.S. federal government and, to a lesser extent, higher sales to state and local governments. The product revenue growth in the enterprise and commercial markets was driven by strength in the United States. We experienced a product revenue decline in the service provider market in this segment. From a country perspective, product revenue increased by 8% in the United States, 34% in Mexico, and 2% in Brazil.

[0000858877-15-000070:mdna:98]
Fiscal 2014 Compared with Fiscal 2013

[0000858877-15-000070:mdna:99]
Product revenue in the Americas segment decreased by 5%, led by a significant decline in the service provider market and, to a lesser extent, declines in the public sector and commercial markets.  Product revenue declined in the U.S. public sector market, led by lower sales to the U.S. federal government.  From a country perspective, product revenue decreased by 5% in the United States, 10% in Canada, and 13% in Brazil, partially offset by an increase of 2% in Mexico.

[0000858877-15-000070:mdna:100]
EMEA

[0000858877-15-000070:mdna:101]
Fiscal 2015 Compared with Fiscal 2014

[0000858877-15-000070:mdna:102]
Product revenue in the EMEA segment increased by 2%, driven by growth in the commercial, public sector and enterprise markets. Product revenue in the service provider market was flat. Product revenue from emerging countries within EMEA increased by 1% and product revenue for the remainder of EMEA grew by 2%.

[0000858877-15-000070:mdna:103]
Fiscal 2014 Compared with Fiscal 2013

[0000858877-15-000070:mdna:104]
Product revenue in the EMEA segment decreased by 4%, led by a decline in the service provider market and, to a lesser extent, declines in the enterprise and public sector markets. Product revenue from emerging countries within EMEA decreased by 11%, led by a 24% decrease in Russia.  Product revenue for the remainder of EMEA, which is primarily composed of countries in western Europe, declined by 2%.

[0000858877-15-000070:mdna:105]
45

[0000858877-15-000070:mdna:106]
APJC

[0000858877-15-000070:mdna:107]
Fiscal 2015 Compared with Fiscal 2014

[0000858877-15-000070:mdna:108]
The decrease in product revenue in the APJC segment of 4% was led by a significant decline in the service provider market and, to a lesser degree, in the public sector and enterprise markets.  These decreases were partially offset by growth in the commercial market. From a country perspective, product revenue decreased by 21% in China and 5% in Japan. We experienced product revenue growth of 15% in India and 8% in Australia.

[0000858877-15-000070:mdna:109]
Fiscal 2014 Compared with Fiscal 2013

[0000858877-15-000070:mdna:110]
Product revenue in the APJC segment decreased by 7%, led by declines in the service provider and enterprise markets and, to a lesser extent, a decline in the commercial market. We continued to experience declines in many of the emerging countries within this segment, most notably in India which experienced a year-over-year product revenue decline of 15%.  Other countries that contributed to the weakness in this segment included Japan, Australia, and China, which experienced year-over-year product revenue declines of 11%, 7%, and 6%, respectively.

[0000858877-15-000070:mdna:111]
46

[0000858877-15-000070:mdna:112]
Product Revenue by Groups of Similar Products

[0000858877-15-000070:mdna:113]
In addition to the primary view on a geographic basis, we also prepare financial information related to groups of similar products and customer markets for various purposes. Our product categories consist of the following categories (with subcategories in parentheses): Switching (fixed switching, modular switching, and storage); NGN Routing (high-end routers, mid-range and low-end routers, and other NGN Routing products); Collaboration (unified communications, Cisco TelePresence, and conferencing); Service Provider Video (infrastructure, video software, and solutions and cable access); Data Center; Wireless; Security; and Other Products. The Other Products category consists primarily of emerging technology products and other networking products.

[0000858877-15-000070:mdna:114]
The following table presents revenue for groups of similar products (in millions, except percentages):

[0000858877-15-000070:mdna:115]
|  |  | Years Ended |  | 2015 vs. 2014 |  | 2014 vs. 2013 |
|  |  | July 25, 2015 |  | July 26, 2014 |  | July 27, 2013 |  | Variance in Dollars |  | Variance in Percent |  | Variance in Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Switching |  | $ | 14,741 |  |  | $ | 14,001 |  |  | $ | 14,711 |  |  | $ | 740 |  |  | 5.3 | % |  | $ | (710 | ) |  | (4.8 | )% |
| Percentage of product revenue |  | 39.1 | % |  | 38.7 | % |  | 38.7 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| NGN Routing |  | 7,704 |  |  | 7,609 |  |  | 8,168 |  |  | 95 |  |  | 1.2 | % |  | (559 | ) |  | (6.8 | )% |
| Percentage of product revenue |  | 20.4 | % |  | 21.0 | % |  | 21.5 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Collaboration |  | 4,000 |  |  | 3,815 |  |  | 4,057 |  |  | 185 |  |  | 4.8 | % |  | (242 | ) |  | (6.0 | )% |
| Percentage of product revenue |  | 10.6 | % |  | 10.5 | % |  | 10.7 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Service Provider Video |  | 3,555 |  |  | 3,969 |  |  | 4,855 |  |  | (414 | ) |  | (10.4 | )% |  | (886 | ) |  | (18.2 | )% |
| Percentage of product revenue |  | 9.4 | % |  | 11.0 | % |  | 12.8 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Data Center |  | 3,220 |  |  | 2,640 |  |  | 2,074 |  |  | 580 |  |  | 22.0 | % |  | 566 |  |  | 27.3 | % |
| Percentage of product revenue |  | 8.5 | % |  | 7.3 | % |  | 5.5 | % |  |  |  |  |  |  |  |  |
| Wireless |  | 2,542 |  |  | 2,293 |  |  | 2,257 |  |  | 249 |  |  | 10.9 | % |  | 36 |  |  | 1.6 | % |
| Percentage of product revenue |  | 6.7 | % |  | 6.3 | % |  | 5.9 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Security |  | 1,747 |  |  | 1,566 |  |  | 1,348 |  |  | 181 |  |  | 11.6 | % |  | 218 |  |  | 16.2 | % |
| Percentage of product revenue |  | 4.6 | % |  | 4.3 | % |  | 3.5 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Other |  | 241 |  |  | 279 |  |  | 559 |  |  | (38 | ) |  | (13.6 | )% |  | (280 | ) |  | (50.1 | )% |
| Percentage of product revenue |  | 0.7 | % |  | 0.9 | % |  | 1.4 | % |  |  |  |  |  |  |  |  |  |  |  |  |
| Total |  | $ | 37,750 |  |  | $ | 36,172 |  |  | $ | 38,029 |  |  | $ | 1,578 |  |  | 4.4 | % |  | $ | (1,857 | ) |  | (4.9 | )% |

[0000858877-15-000070:mdna:116]
Certain reclassifications have been made to the prior period amounts to conform to the current period’s presentation.

[0000858877-15-000070:mdna:117]
Switching

[0000858877-15-000070:mdna:118]
Fiscal 2015 Compared with Fiscal 2014

[0000858877-15-000070:mdna:119]
The increase in revenue in our Switching product category of 5%, or $740 million, was driven by a 9%, or $826 million, increase in revenue from our LAN fixed-configuration switches and, to a lesser extent, a 24%, or $102 million, increase in sales of storage products. Revenue from LAN fixed-configuration switches increased due to higher sales of most of our Cisco Nexus Series Switches and Cisco Catalyst Series Switches within this category. We experienced a decrease in revenue from our modular switches of 4%, or $188 million, driven by lower sales of Cisco Catalyst 6500-E Series Switches and Cisco Nexus 7000 Series Switches.

[0000858877-15-000070:mdna:120]
Fiscal 2014 Compared with Fiscal 2013

[0000858877-15-000070:mdna:121]
Revenue in our Switching product category decreased by 5%, or $710 million driven by a 12%, or $656 million, decrease in revenue from our modular switches. Revenue from our modular switches decreased due to lower sales of Cisco Catalyst 6000 Series Switches. We also experienced a 3% decrease in sales of storage products within this category. Revenue from our LAN fixed-configuration switches was relatively flat year over year, as lower sales of most of our fixed-configuration Cisco Catalyst Series Switches and fixed-configuration Cisco Nexus Series Switches were offset by the continued adoption of Cisco Catalyst 3850 Series Switches and Cisco Nexus 6000 Series Switches.

[0000858877-15-000070:mdna:122]
47

[0000858877-15-000070:mdna:123]
NGN Routing

[0000858877-15-000070:mdna:124]
Fiscal 2015 Compared with Fiscal 2014

[0000858877-15-000070:mdna:125]
Revenue in our NGN Routing product category increased by 1%, or $95 million, driven by a 6%, or $248 million, increase in revenue from our high-end router products and a slight increase in revenue from our midrange and low-end router products, partially offset by 28%, or $171 million, decrease in revenue from other NGN Routing products.  Revenue from high-end router products increased due to an increase in revenue from most products within our Cisco ASR category and the adoption of our Cisco NCS platform and CRS-X, partially offset by lower sales of our legacy high-end router products. The slight increase in revenue from our midrange and low-end router products was due to higher sales of our Cisco ISR products, partially offset by lower sales of certain of our access products. Revenue from other NGN Routing products decreased primarily due to lower sales of certain optical networking products.

[0000858877-15-000070:mdna:126]
Fiscal 2014 Compared with Fiscal 2013

[0000858877-15-000070:mdna:127]
The decrease in revenue in our NGN Routing product category of 7%, or $559 million, was driven by a 6%, or $278 million, decrease in revenue from high-end router products; an 8%, or $227 million, decrease in revenue from our midrange and low-end router products; and an 8%, or $54 million, decrease in revenue from other NGN Routing products. Revenue from our high-end products decreased due to lower sales of Cisco CRS-3 Carrier Routing System products and our legacy high-end router products, partially offset by increased sales of our Cisco ASR edge products. The decrease in revenue from our midrange and low-end router products was driven by lower sales of our Cisco ISR products. Revenue from other NGN Routing products decreased due to lower sales of certain optical networking products.

[0000858877-15-000070:mdna:128]
Collaboration

[0000858877-15-000070:mdna:129]
Fiscal 2015 Compared with Fiscal 2014

[0000858877-15-000070:mdna:130]
Revenue in our Collaboration product category increased by 5%, or $185 million, due to increased revenue from our Unified Communications products as a result of higher software revenue and a slight increase in revenue from phones. Higher revenue from our Cisco TelePresence and conferencing products also contributed to the increase. Revenue from Cisco TelePresence products increased due to higher revenue in endpoint products as a result of new product introductions. The increase in conferencing revenue was a result of higher recurring revenue. We continue to increase the amount of deferred revenue and the proportion of recurring revenue related to our Collaboration product category.

[0000858877-15-000070:mdna:131]
Fiscal 2014 Compared with Fiscal 2013

[0000858877-15-000070:mdna:132]
We continue to increase the proportion of recurring revenue in our Collaboration product category. Overall, revenue in our Collaboration product category decreased by 6%, or $242 million, primarily due to decreased revenue from our Cisco TelePresence and Unified Communications products, driven by weakness in endpoint products such as phones. These decreases were partially offset by higher revenue from our conferencing products.

[0000858877-15-000070:mdna:133]
Service Provider Video

[0000858877-15-000070:mdna:134]
Fiscal 2015 Compared with Fiscal 2014

[0000858877-15-000070:mdna:135]
The decrease in revenue from our Service Provider Video product category of 10%, or $414 million, was driven by a 16%, or $332 million, decrease in sales of our Service Provider Video infrastructure products, due primarily to lower sales of set-top boxes. We also experienced a decrease in revenue from cable access products within this product category.

[0000858877-15-000070:mdna:136]
On July 22, 2015, we entered into an exclusive agreement to sell the client premises equipment portion of our Service Provider Video connected devices business unit to French-based Technicolor. We will continue to refocus our investments in Service Provider Video towards cloud, security and software-based services.

[0000858877-15-000070:mdna:137]
Fiscal 2014 Compared with Fiscal 2013

[0000858877-15-000070:mdna:138]
Revenue in our Service Provider Video product category decreased by 18%, or $886 million, with the largest driver of the decline being a 21%, or $812 million, decrease in sales of our Service Provider Video infrastructure products. The revenue decline in Service Provider Video infrastructure products, which includes connected devices products, was due primarily to lower sales of set-top boxes.

[0000858877-15-000070:mdna:139]
48

[0000858877-15-000070:mdna:140]
Data Center

[0000858877-15-000070:mdna:141]
Fiscal 2015 Compared with Fiscal 2014

[0000858877-15-000070:mdna:142]
Revenue in our Data Center product category grew by 22%, or $580 million, with sales growth of our Cisco Unified Computing System products across all geographic segments and customer markets. The increase was due in large part to the continued momentum we are experiencing in both data center and cloud environments, as current customers increase their data center build-outs and as new customers deploy these offerings.

[0000858877-15-000070:mdna:143]
To the extent our data center business grows and further penetrates the market, we expect that, in comparison to what we experienced during the initial rapid growth of this business, the growth rates for our data center product sales will experience more normal seasonality consistent with the overall server market.

[0000858877-15-000070:mdna:144]
Fiscal 2014 Compared with Fiscal 2013

[0000858877-15-000070:mdna:145]
We continue to experience solid growth in our Data Center product category, which grew by 27%, or $566 million, with sales growth of our Cisco Unified Computing System products across all geographic segments and customer markets. The increase was due in large part to the continued momentum we are experiencing in both data center and cloud environments, as current customers increase their data center build-outs and as new customers deploy these offerings.

[0000858877-15-000070:mdna:146]
Wireless

[0000858877-15-000070:mdna:147]
Fiscal 2015 Compared with Fiscal 2014

[0000858877-15-000070:mdna:148]
Revenue in our Wireless product category increased by 11%, or $249 million, driven by continued growth in sales of Meraki products combined with continued strength in our 802.11ac portfolio. We continue to increase the amount of deferred revenue and the proportion of recurring revenue related to our Wireless product category.

[0000858877-15-000070:mdna:149]
Fiscal 2014 Compared with Fiscal 2013

[0000858877-15-000070:mdna:150]
We continue to increase the proportion of recurring revenue in our Wireless product category. Revenue in our Wireless product category increased by 2%, or $36 million, due to an increase in sales of Meraki products, which we acquired in the second quarter of fiscal 2013, partially offset by lower sales of other wireless products.

[0000858877-15-000070:mdna:151]
Security

[0000858877-15-000070:mdna:152]
Fiscal 2015 Compared with Fiscal 2014

[0000858877-15-000070:mdna:153]
Revenue in our Security product category was up 12%, or $181 million, driven primarily by sales of Sourcefire products and, to a lesser extent, by higher sales of our high-end firewall products within our network security product portfolio. This increase was partially offset by a slight decrease in revenue from our content security products due to lower sales of web and e-mail security products. We continue to increase the amount of deferred revenue and the proportion of recurring revenue related to our Security product category.

[0000858877-15-000070:mdna:154]
Fiscal 2014 Compared with Fiscal 2013

[0000858877-15-000070:mdna:155]
We continue to increase the proportion of recurring revenue in our Security product category. Revenue in our Security product category was up 16%, or $218 million, driven primarily by sales of Sourcefire products, which company we acquired in the first quarter of fiscal 2014 and, to a lesser degree, by both higher sales of our high-end firewall products within our network security product portfolio and slightly higher sales of our content security products.

[0000858877-15-000070:mdna:156]
Other Products

[0000858877-15-000070:mdna:157]
We experienced a year-over-year decrease in revenue in our Other Products category for fiscal 2015 due in large part to the decrease in sales of our other networking products. The year-over-year decrease in revenue in our Other Products category for fiscal 2014 was due in large part to the sale of our Linksys product line in the third quarter of fiscal 2013.

[0000858877-15-000070:mdna:158]
Service Revenue by Segment

[0000858877-15-000070:mdna:159]
The following table presents the breakdown of service revenue by segment (in millions, except percentages):

[0000858877-15-000070:mdna:160]
|  | Years Ended |  | 2015 vs. 2014 |  | 2014 vs. 2013 |
| Years Ended | July 25, 2015 |  | July 26, 2014 |  | July 27, 2013 |  | Variance in Dollars |  | Variance in Percent |  | Variance in Dollars |  | Variance in Percent |
| Service revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 7,394 |  |  | $ | 7,150 |  |  | $ | 6,986 |  |  | $ | 244 |  |  | 3.4 | % |  | $ | 164 |  |  | 2.3 | % |
| Percentage of service revenue | 64.8 | % |  | 65.2 | % |  | 66.1 | % |  |  |  |  |  |  |  |  |
| EMEA | 2,466 |  |  | 2,351 |  |  | 2,161 |  |  | 115 |  |  | 4.9 | % |  | 190 |  |  | 8.8 | % |
| Percentage of service revenue | 21.6 | % |  | 21.4 | % |  | 20.4 | % |  |  |  |  |  |  |  |  |
| APJC | 1,551 |  |  | 1,469 |  |  | 1,431 |  |  | 82 |  |  | 5.6 | % |  | 38 |  |  | 2.7 | % |
| Percentage of service revenue | 13.6 | % |  | 13.4 | % |  | 13.5 | % |  |  |  |  |  |  |  |  |
| Total | $ | 11,411 |  |  | $ | 10,970 |  |  | $ | 10,578 |  |  | $ | 441 |  |  | 4.0 | % |  | $ | 392 |  |  | 3.7 | % |

[0000858877-15-000070:mdna:161]
Fiscal 2015 Compared with Fiscal 2014

[0000858877-15-000070:mdna:162]
Service revenue increased across all of our geographic segments. Worldwide technical support services revenue increased by 3% and worldwide advanced services revenue increased by 6%, driven by growth in subscription revenues. Technical support services revenue experienced relatively balanced growth across all geographic segments. Renewals and technical support service contract initiations associated with product sales provided an installed base of equipment being serviced which, in concert with new service offerings, were the primary factors driving the revenue increases. Advanced services revenue, which relates to consulting support services for specific customer network needs, grew across all geographic segments.

[0000858877-15-000070:mdna:163]
Fiscal 2014 Compared with Fiscal 2013

[0000858877-15-000070:mdna:164]
Service revenue continued to experience slower growth than in prior fiscal years, with varying levels of growth across our geographic segments. Worldwide technical support services revenue increased by 4% while worldwide advanced services revenue experienced 3% growth. Technical support services revenue experienced growth across all geographic segments. Renewals and technical support service contract initiations associated with product sales provided an installed base of equipment being serviced which, in concert with new service offerings, were the primary factors driving the revenue increases. Advanced services revenue, slightly declined in the Americas segment but had solid growth in the EMEA and APJC segments due to growth in subscription revenues.

[0000858877-15-000070:mdna:165]
50

[0000858877-15-000070:mdna:166]
Gross Margin

[0000858877-15-000070:mdna:167]
The following table presents the gross margin for products and services (in millions, except percentages):

[0000858877-15-000070:mdna:168]
|  | AMOUNT |  | PERCENTAGE |
| Years Ended | July 25, 2015 |  | July 26, 2014 |  | July 27, 2013 |  | July 25, 2015 |  | July 26, 2014 |  | July 27, 2013 |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 22,373 |  |  | $ | 20,531 |  |  | $ | 22,488 |  |  | 59.3 | % |  | 56.8 | % |  | 59.1 | % |
| Service | 7,308 |  |  | 7,238 |  |  | 6,952 |  |  | 64.0 | % |  | 66.0 | % |  | 65.7 | % |
| Total | $ | 29,681 |  |  | $ | 27,769 |  |  | $ | 29,440 |  |  | 60.4 | % |  | 58.9 | % |  | 60.6 | % |

[0000858877-15-000070:mdna:169]
Product Gross Margin

[0000858877-15-000070:mdna:170]
Fiscal 2015 Compared with Fiscal 2014

[0000858877-15-000070:mdna:171]
The following table summarizes the key factors that contributed to the change in product gross margin percentage from fiscal 2014 to fiscal 2015:

[0000858877-15-000070:mdna:172]
|  |  | Product Gross Margin Percentage |
| Fiscal 2014 |  | 56.8 | % |
| Productivity (1) |  | 2.8 | % |
| Supplier component remediation charge/adjustment |  | 2.2 | % |
| Mix of products sold |  | 0.3 | % |
| Product pricing |  | (2.3 | )% |
| Rockstar patent portfolio charge |  | (0.5 | )% |
| Fiscal 2015 |  | 59.3 | % |

[0000858877-15-000070:mdna:173]
(1) Productivity includes overall manufacturing-related costs, such as component costs, warranty expense, provision for inventory, freight, logistics, shipment volume, and other items not categorized elsewhere.

[0000858877-15-000070:mdna:174]
Product gross margin increased by 2.5 percentage points compared with fiscal 2014. The increase in product gross margin was due to productivity improvements, which were driven by value engineering efforts; favorable component pricing; continued operational efficiency in manufacturing operations and lower warranty expense. Value engineering is the process by which production costs are reduced through component redesign, board configuration, test processes, and transformation processes. The increase was also due to the $655 million charge to product cost of sales in fiscal 2014 related to the expected cost to remediate issues with a supplier component in certain products sold in prior fiscal years and an associated $164 million favorable adjustment recorded in fiscal 2015.

[0000858877-15-000070:mdna:175]
Additionally, gross margin increased due to the mix of products sold. The favorable product mix impact was due to revenue decreases from our relatively lower margin Service Provider Video products and a revenue increase from certain of our higher margin core products, partially offset by increased revenue from our relatively lower margin Cisco Unified Computing System products.  The various factors contributing to the product gross margin increase were partially offset by unfavorable impacts from product pricing, which were driven by typical market factors and impacted each of our geographic segments and customer markets, as well as the unfavorable impact of a $188 million charge to product cost of sales recorded in fiscal 2015 related to the Rockstar patent portfolio, see Note 4(b) to the Consolidated Financial Statements.

[0000858877-15-000070:mdna:176]
Our future gross margins could be impacted by our product mix and could be adversely affected by further growth in sales of products that have lower gross margins, such as Cisco Unified Computing System products. Our gross margins may also be impacted by the geographic mix of our revenue and, as was the case in fiscal 2015, fiscal 2014 and fiscal 2013, may be adversely affected by product pricing attributable to competitive factors. Additionally, our manufacturing-related costs may be negatively impacted by constraints in our supply chain, which in turn could negatively affect gross margin. If any of the preceding factors that in the past have negatively impacted our gross margins arise in future periods, our gross margins could continue to decline.

[0000858877-15-000070:mdna:177]
Fiscal 2014 Compared with Fiscal 2013

[0000858877-15-000070:mdna:178]
The following table summarizes the key factors that contributed to the change in product gross margin percentage from fiscal 2013 to fiscal 2014:

[0000858877-15-000070:mdna:179]
|  |  | Product Gross Margin Percentage |
| Fiscal 2013 |  | 59.1 | % |
| Product pricing |  | (3.1 | )% |
| Supplier component remediation charge |  | (1.8 | )% |
| Mix of products sold |  | (0.5 | )% |
| Amortization of purchased intangible assets |  | (0.5 | )% |
| Productivity (1) |  | 3.0 | % |
| TiVo patent litigation settlement |  | 0.5 | % |
| Acquisition fair value adjustment to inventory and other |  | 0.1 | % |
| Fiscal 2014 |  | 56.8 | % |

[0000858877-15-000070:mdna:180]
Product gross margin decreased by 2.3 percentage points compared with fiscal 2013. The decrease in product gross margin was driven by unfavorable impacts from product pricing, which were driven by typical market factors and impacted each of our geographic segments and customer markets. The decrease was also due, in part, to the supplier component remediation charge of $655 million to product cost of sales recorded in fiscal 2014 discussed above. In addition, the shift in the mix of products sold decreased our product gross margin, primarily as a result of a revenue increase in our Cisco Unified Computing System products and decreased revenue from our higher margin core products, partially offset by decreased revenue from our Service Provider Video products. Our product gross margin for fiscal 2014 was also negatively impacted by higher amortization expense of purchased intangible assets. For further explanation of the increase in amortization of purchased intangible assets, see “Amortization of Purchased Intangible Assets” below.

[0000858877-15-000070:mdna:181]
These amounts were partially offset by productivity benefits and the absence of charges related to the TiVo patent litigation settlement which we incurred in the fourth quarter of fiscal 2013. The productivity benefits we experienced in fiscal 2014 were driven by value engineering efforts; favorable component pricing; and continued operational efficiency in manufacturing operations.

[0000858877-15-000070:mdna:182]
Service Gross Margin

[0000858877-15-000070:mdna:183]
Fiscal 2015 Compared with Fiscal 2014

[0000858877-15-000070:mdna:184]
Service gross margin percentage decreased by 2.0 percentage points for fiscal 2015, as compared with fiscal 2014, driven by increased cost impacts such as partner delivery costs, headcount-related costs and outside services. Headcount-related costs increased due to continued investments in security and cloud managed services and higher variable compensation expense. These cost impacts were partially offset by the resulting benefit to gross margin of higher sales volume in both advanced services and technical support services.

[0000858877-15-000070:mdna:185]
Our service gross margin normally experiences some fluctuations due to various factors such as the timing of contract initiations in our renewals, our strategic investments in headcount, and the resources we deploy to support the overall service business. Other factors include the mix of service offerings, as the gross margin from our advanced services is typically lower than the gross margin from technical support services.

[0000858877-15-000070:mdna:186]
Fiscal 2014 Compared with Fiscal 2013

[0000858877-15-000070:mdna:187]
Our service gross margin percentage increased slightly by 0.3 percentage points for fiscal 2014, as compared with fiscal 2013. The increase was primarily due to higher sales volume in both advanced services and technical support services.  The benefits to gross margin of increased sales volume were partially offset by increased cost impacts such as outside service costs, partner delivery costs, and headcount-related costs.

[0000858877-15-000070:mdna:188]
Gross Margin by Segment

[0000858877-15-000070:mdna:189]
The following table presents the total gross margin for each segment (in millions, except percentages):

[0000858877-15-000070:mdna:190]
|  |  | AMOUNT |  | PERCENTAGE |
| Years Ended |  | July 25, 2015 |  | July 26, 2014 |  | July 27, 2013 |  | July 25, 2015 |  | July 26, 2014 |  | July 27, 2013 |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 18,670 |  |  | $ | 17,379 |  |  | $ | 17,887 |  |  | 63.0 | % |  | 62.6 | % |  | 62.5 | % |
| EMEA |  | 7,705 |  |  | 7,700 |  |  | 7,876 |  |  | 62.5 | % |  | 64.1 | % |  | 64.5 | % |
| APJC |  | 4,307 |  |  | 4,252 |  |  | 4,637 |  |  | 60.0 | % |  | 57.8 | % |  | 59.8 | % |
| Segment total |  | 30,682 |  |  | 29,331 |  |  | 30,400 |  |  | 62.4 | % |  | 62.2 | % |  | 62.5 | % |
| Unallocated corporate items (1) |  | (1,001 | ) |  | (1,562 | ) |  | (960 | ) |  |  |  |  |  |  |
| Total |  | $ | 29,681 |  |  | $ | 27,769 |  |  | $ | 29,440 |  |  | 60.4 | % |  | 58.9 | % |  | 60.6 | % |

[0000858877-15-000070:mdna:191]
(1) The unallocated corporate items for the years presented include the effects of amortization and impairments of acquisition-related intangible assets, share-based compensation expense, significant litigation and other contingencies, impacts to cost of sales from purchase accounting adjustments to inventory, charges related to asset impairments and restructurings, and certain other charges. We do not allocate these items to the gross margin for each segment because management does not include such information in measuring the performance of the operating segments.

[0000858877-15-000070:mdna:192]
Fiscal 2015 Compared with Fiscal 2014

[0000858877-15-000070:mdna:193]
We experienced a gross margin percentage increase in our Americas segment due to productivity improvements partially offset by unfavorable impacts from pricing. The product mix was flat in this geographic segment as the impact of decreased revenue from our relatively lower margin Service Provider Video products offset the increase in revenue from our relatively lower margin Cisco Unified Computing System products.

[0000858877-15-000070:mdna:194]
The gross margin percentage decrease in our EMEA segment was due primarily to unfavorable impacts from pricing and mix. The unfavorable mix impact was driven by an increase in revenue from our relatively lower margin Cisco Unified Computing System products. Lower service gross margin also contributed to the decrease in the overall gross margin in this segment.

[0000858877-15-000070:mdna:195]
The APJC segment gross margin percentage increased due to productivity improvements and a favorable mix impact, partially offset by unfavorable impacts from pricing. The favorable mix impact was driven by a decrease in revenue from our relatively lower margin Service Provider Video products and an increase in revenue from certain of our higher margin core products.

[0000858877-15-000070:mdna:196]
The gross margin percentage for a particular segment may fluctuate, and period-to-period changes in such percentages may or may not be indicative of a trend for that segment. Our product and service gross margins may be impacted by economic downturns or uncertain economic conditions as well as our movement into new market opportunities, and could decline if any of the factors that impact our gross margins are adversely affected in future periods.

[0000858877-15-000070:mdna:197]
Fiscal 2014 Compared with Fiscal 2013

[0000858877-15-000070:mdna:198]
The Americas segment experienced a slight gross margin percentage increase due to the impact of productivity improvements in this geographic segment. Partially offsetting this favorable impact to gross margin were negative impacts from pricing and an unfavorable mix. The unfavorable mix impact was driven by revenue increases in our Cisco Unified Computing System products and lower sales of our higher margin core products, partially offset by decreased revenue from our  Service Provider Video products.

[0000858877-15-000070:mdna:199]
The gross margin percentage decrease in our EMEA segment was due primarily to the unfavorable impacts from pricing, as well as an unfavorable mix impact, partially offset by productivity improvements in this geographic segment. The unfavorable mix impact was driven by an increase in revenue from our Cisco Unified Computing System products.

[0000858877-15-000070:mdna:200]
Our APJC segment gross margin percentage decreased primarily as a result of unfavorable impacts from pricing, and also as a result of an unfavorable mix. The unfavorable mix impact was driven by an increase in revenue from our Cisco Unified Computing System products. Partially offsetting these factors were impacts from productivity improvements and higher service gross margin in this geographic segment.

[0000858877-15-000070:mdna:201]
Factors That May Impact Revenue and Gross Margin

[0000858877-15-000070:mdna:202]
Product revenue may continue to be affected by factors, including global economic downturns and related market uncertainty, that have resulted in reduced IT-related capital spending in certain segments within our enterprise, service provider, public sector, and commercial markets; changes in the geopolitical environment and global economic conditions; competition, including price-focused competitors from Asia, especially from China; new product introductions; sales cycles and product implementation cycles; changes in the mix of our customers between service provider and enterprise markets; changes in the mix of direct sales and indirect sales; variations in sales channels; and final acceptance criteria of the product, system, or solution as specified by the customer. Sales to the service provider market have been and may be in the future characterized by large and sporadic purchases, especially relating to our NGN Routing sales and sales of certain products within our Collaboration, Service Provider Video and Data Center product categories. In addition, service provider customers typically have longer implementation cycles; require a broader range of services, including network design services; and often have acceptance provisions that can lead to a delay in revenue recognition. Certain of our customers in certain emerging countries also tend to make large and sporadic purchases, and the revenue related to these transactions may similarly be affected by the timing of revenue recognition. As we focus on new market opportunities, customers may require greater levels of financing arrangements, service, and support, especially in certain emerging countries, which in turn may result in a delay in the timing of revenue recognition. To improve customer satisfaction, we continue to focus on managing our manufacturing lead-time performance, which may result in corresponding reductions in order backlog. A decline in backlog levels could result in more variability and less predictability in our quarter-to-quarter revenue and operating results.

[0000858877-15-000070:mdna:203]
Product revenue may also be adversely affected by fluctuations in demand for our products, especially with respect to telecommunications service providers and Internet businesses, whether or not driven by any slowdown in capital expenditures in the service provider market; price and product competition in the communications and information technology industry; introduction and market acceptance of new technologies and products; adoption of new networking standards; and financial difficulties experienced by our customers. We may, from time to time, experience manufacturing issues that create a delay in our suppliers’ ability to provide specific components, resulting in delayed shipments. To the extent that manufacturing issues and any related component shortages result in delayed shipments in the future, and particularly in periods when we and our suppliers are operating at higher levels of capacity, it is possible that revenue for a quarter could be adversely affected if such matters are not remediated within the same quarter. For additional factors that may impact product revenue, see “Part I, Item 1A. Risk Factors.”

[0000858877-15-000070:mdna:204]
Our distributors participate in various cooperative marketing and other programs. Increased sales to our distributors generally result in greater difficulty in forecasting the mix of our products and, to a certain degree, the timing of orders from our customers. We recognize revenue for sales to our distributors generally based on a sell-through method using information provided by them, and we maintain estimated accruals and allowances for all cooperative marketing and other programs.

[0000858877-15-000070:mdna:205]
Product gross margin may be adversely affected in the future by changes in the mix of products sold, including periods of increased growth of some of our lower margin products; introduction of new products, including products with price-performance advantages and new business models for our offerings such as XaaS; our ability to reduce production costs; entry into new markets, including markets with different pricing structures and cost structures, as a result of internal development or through acquisitions; changes in distribution channels; price competition, including competitors from Asia, especially those from China; changes in geographic mix of our product revenue; the timing of revenue recognition and revenue deferrals; sales discounts; increases in material or labor costs, including share-based compensation expense; excess inventory and obsolescence charges; warranty costs; changes in shipment volume; loss of cost savings due to changes in component pricing; effects of value engineering; inventory holding charges; and the extent to which we successfully execute on our strategy and operating plans. Additionally, our manufacturing-related costs may be negatively impacted by constraints in our supply chain. Service gross margin may be impacted by various factors such as the change in mix between technical support services and advanced services; the timing of technical support service contract initiations and renewals; share-based compensation expense; and the timing of our strategic investments in headcount and resources to support this business.

[0000858877-15-000070:mdna:206]
54

[0000858877-15-000070:mdna:207]
Research and Development (“R&D”), Sales and Marketing, and General and Administrative (“G&A”) Expenses

[0000858877-15-000070:mdna:208]
R&D, sales and marketing, and G&A expenses are summarized in the following table (in millions, except percentages):

[0000858877-15-000070:mdna:209]
|  |  | Years Ended |  | 2015 vs. 2014 |  | 2014 vs. 2013 |
|  |  | July 25, 2015 |  | July 26, 2014 |  | July 27, 2013 |  | Variance in Dollars |  | Variance in Percent |  | Variance in Dollars |  | Variance in Percent |
| Research and development |  | $ | 6,207 |  |  | $ | 6,294 |  |  | $ | 5,942 |  |  | $ | (87 | ) |  | (1.4 | )% |  | $ | 352 |  |  | 5.9 | % |
| Percentage of revenue |  | 12.6 | % |  | 13.4 | % |  | 12.2 | % |  |  |  |  |  |  |  |  |
| Sales and marketing |  | 9,821 |  |  | 9,503 |  |  | 9,538 |  |  | 318 |  |  | 3.3 | % |  | (35 | ) |  | (0.4 | )% |
| Percentage of revenue |  | 20.0 | % |  | 20.2 | % |  | 19.6 | % |  |  |  |  |  |  |  |  |
| General and administrative |  | 2,040 |  |  | 1,934 |  |  | 2,264 |  |  | 106 |  |  | 5.5 | % |  | (330 | ) |  | (14.6 | )% |
| Percentage of revenue |  | 4.1 | % |  | 4.1 | % |  | 4.7 | % |  |  |  |  |  |  |  |  |
| Total |  | $ | 18,068 |  |  | $ | 17,731 |  |  | $ | 17,744 |  |  | $ | 337 |  |  | 1.9 | % |  | $ | (13 | ) |  | (0.1 | )% |
| Percentage of revenue |  | 36.8 | % |  | 37.6 | % |  | 36.5 | % |  |  |  |  |  |  |  |  |

[0000858877-15-000070:mdna:210]
R&D Expenses

[0000858877-15-000070:mdna:211]
Fiscal 2015 Compared with Fiscal 2014

[0000858877-15-000070:mdna:212]
The decrease in R&D expenses for fiscal 2015, as compared with fiscal 2014, was primarily due to higher compensation expense recorded in fiscal 2014 in connection with our acquisition of the remaining interest in Insieme. See Note 12 to the Consolidated Financial Statements. Efficiencies arising from our restructuring action announced in August 2014 also contributed to the decrease. These decreases were partially offset by higher contracted services and higher share-based compensation expense.

[0000858877-15-000070:mdna:213]
We continue to invest in R&D in order to bring a broad range of products to market in a timely fashion. If we believe that we are unable to enter a particular market in a timely manner with internally developed products, we may purchase or license technology from other businesses, or we may partner with or acquire businesses as an alternative to internal R&D.

[0000858877-15-000070:mdna:214]
Fiscal 2014 Compared with Fiscal 2013

[0000858877-15-000070:mdna:215]
R&D expenses increased for fiscal 2014, as compared with fiscal 2013, primarily due to compensation expense recorded in fiscal 2014 in connection with our acquisition of the remaining interest in Insieme. Higher share-based compensation expense and higher contracted services also contributed to the increase.  These increases were partially offset by reduced variable compensation expense as a result of our financial performance and efficiencies related to our workforce reduction plan announced in August 2013.

[0000858877-15-000070:mdna:216]
Sales and Marketing Expenses

[0000858877-15-000070:mdna:217]
Fiscal 2015 Compared with Fiscal 2014

[0000858877-15-000070:mdna:218]
Sales and marketing expenses increased for fiscal 2015, as compared with fiscal 2014, due to higher headcount-related expenses, driven by increased variable compensation expense and higher discretionary spending, partially offset by lower compensation expense from acquisitions.

[0000858877-15-000070:mdna:219]
Fiscal 2014 Compared with Fiscal 2013

[0000858877-15-000070:mdna:220]
Sales and marketing expenses for fiscal 2014, as compared with fiscal 2013, decreased slightly due to lower advertising expenses, reductions in other discretionary spending, and lower expenses in other areas such as depreciation expense. These decreases were substantially offset by higher share based compensation expense and higher acquisition- related costs.

[0000858877-15-000070:mdna:221]
G&A Expenses

[0000858877-15-000070:mdna:222]
Fiscal 2015 Compared with Fiscal 2014

[0000858877-15-000070:mdna:223]
G&A expenses increased in fiscal 2015, as compared with fiscal 2014,  primarily due to increased variable compensation expense as a result of our financial performance, higher share-based compensation expense and the timing of corporate-level expenses. Corporate-level expenses, which tend to vary from period to period, included operational infrastructure activities such as IT project implementations, which included investments in our global data center infrastructure, and investments related to operational and financial systems.

[0000858877-15-000070:mdna:224]
Fiscal 2014 Compared with Fiscal 2013

[0000858877-15-000070:mdna:225]
G&A expenses decreased in fiscal 2014, as compared with fiscal 2013, due to lower contracted services, lower corporate-level expenses, and lower headcount-related expenses.  The lower headcount-related expenses were due to efficiencies related to our workforce reduction plan announced in August 2013, and also due to reduced variable compensation expense as a result of our lower financial performance.

[0000858877-15-000070:mdna:226]
Effect of Foreign Currency

[0000858877-15-000070:mdna:227]
In fiscal 2015, foreign currency fluctuations, net of hedging, decreased the combined R&D, sales and marketing, and G&A expenses by approximately $278 million, or 1.6%, compared with fiscal 2014. In fiscal 2014, foreign currency fluctuations, net of hedging, decreased the combined R&D, sales and marketing, and G&A expenses by approximately $153 million, or 0.9%, compared with fiscal 2013.

[0000858877-15-000070:mdna:228]
Headcount

[0000858877-15-000070:mdna:229]
Fiscal 2015 Compared with Fiscal 2014

[0000858877-15-000070:mdna:230]
The decrease in headcount of approximately 2,200 employees in fiscal 2015 was due to headcount reductions from attrition and from our restructuring plan announced in August 2014. These headcount reductions were partially offset by headcount additions from targeted hiring in engineering and services, and also by headcount additions from our recent acquisitions.

[0000858877-15-000070:mdna:231]
Fiscal 2014 Compared with Fiscal 2013

[0000858877-15-000070:mdna:232]
Our headcount decreased by approximately 1,000 employees in fiscal 2014.  The decrease was due to headcount reductions from attrition and from our workforce reduction plan announced in August 2013. These headcount reductions were partially offset by the increase in headcount from targeted hiring in engineering, services, sales, and also by increased headcount from our recent acquisitions.

[0000858877-15-000070:mdna:233]
Share-Based Compensation Expense

[0000858877-15-000070:mdna:234]
The following table presents share-based compensation expense (in millions):

[0000858877-15-000070:mdna:235]
| Years Ended |  | July 25, 2015 |  | July 26, 2014 |  | July 27, 2013 |
| Cost of sales—product |  | $ | 50 |  |  | $ | 45 |  |  | $ | 40 |  |
| Cost of sales—service |  | 157 |  |  | 150 |  |  | 138 |  |
| Share-based compensation expense in cost of sales |  | 207 |  |  | 195 |  |  | 178 |  |
| Research and development |  | 448 |  |  | 411 |  |  | 286 |  |
| Sales and marketing |  | 559 |  |  | 549 |  |  | 484 |  |
| General and administrative |  | 228 |  |  | 198 |  |  | 175 |  |
| Restructuring and other charges |  | (2 | ) |  | (5 | ) |  | (3 | ) |
| Share-based compensation expense in operating expenses |  | 1,233 |  |  | 1,153 |  |  | 942 |  |
| Total share-based compensation expense |  | $ | 1,440 |  |  | $ | 1,348 |  |  | $ | 1,120 |  |

[0000858877-15-000070:mdna:236]
The increase in share-based compensation expense for fiscal 2015, as compared with fiscal 2014, was due primarily to higher expense associated with performance-based restricted stock units and charges associated with severance arrangements with certain executives, partially offset by lower expense related to equity awards assumed with respect to our recent acquisitions.

[0000858877-15-000070:mdna:237]
The increase in share-based compensation expense for fiscal 2014, as compared with fiscal 2013, was due primarily to share-based compensation expense attributable to equity awards assumed with respect to our recent acquisitions and higher forfeiture credits in fiscal 2013.

[0000858877-15-000070:mdna:238]
56

[0000858877-15-000070:mdna:239]
Amortization of Purchased Intangible Assets

[0000858877-15-000070:mdna:240]
The following table presents the amortization of purchased intangible assets (in millions):

[0000858877-15-000070:mdna:241]
| Years Ended |  | July 25, 2015 |  | July 26, 2014 |  | July 27, 2013 |
| Amortization of purchased intangible assets: |  |  |  |  |  |  |
| Cost of sales |  | $ | 814 |  |  | $ | 742 |  |  | $ | 606 |  |
| Operating expenses |  | 359 |  |  | 275 |  |  | 395 |  |
| Total |  | $ | 1,173 |  |  | $ | 1,017 |  |  | $ | 1,001 |  |

[0000858877-15-000070:mdna:242]
Amortization of purchased intangible assets increased in fiscal 2015, compared with fiscal 2014, primarily due to the impairment charges of approximately $175 million recorded in fiscal 2015. The impairment charges were primarily due to declines in estimated fair value resulting from reductions in or the elimination of expected future cash flows associated with certain of our technology and IPR&D intangible assets.

[0000858877-15-000070:mdna:243]
Amortization of purchased intangible assets increased in fiscal 2014 as compared with fiscal 2013, primarily due to amortization of purchased intangible assets from our recent acquisitions partially offset by certain purchased intangible assets having become fully amortized.

[0000858877-15-000070:mdna:244]
The fair value of acquired technology and patents, as well as acquired technology under development, is determined at acquisition date primarily using the income approach, which discounts expected future cash flows to present value. The discount rates used in the present value calculations are typically derived from a weighted-average cost of capital analysis and then adjusted to reflect risks inherent in the development lifecycle as appropriate. We consider the pricing model for products related to these acquisitions to be standard within the high-technology communications industry, and the applicable discount rates represent the rates that market participants would use for valuation of such intangible assets.

[0000858877-15-000070:mdna:245]
Restructuring and Other Charges

[0000858877-15-000070:mdna:246]
Fiscal 2015 Plan

[0000858877-15-000070:mdna:247]
In connection with a restructuring action announced in August 2014 (“Fiscal 2015 Plan”), we incurred restructuring and other charges of $489 million during fiscal 2015, which were related primarily to severance and other one-time termination benefits and other associated costs. We expect this plan to be substantially completed during the first half of fiscal 2016. We plan to reinvest substantially all of the cost savings from the restructuring actions in key growth areas of our business such as data center, software, security, and cloud. The overall cost savings from these restructuring actions were not material for the periods presented and are not expected to be material for future periods.

[0000858877-15-000070:mdna:248]
Fiscal 2014 Plan and Fiscal 2011 Plans

[0000858877-15-000070:mdna:249]
In connection with a restructuring action announced in August 2013 (“Fiscal 2014 Plan”), we incurred restructuring and other charges of approximately $418 million during fiscal 2014 which were related primarily to employee severance charges for employees impacted by our workforce reduction under the Fiscal 2014 Plan.  We completed the Fiscal 2014 Plan at the end of fiscal 2014. With regard to the Fiscal 2011 Plans (see Note 5 to the Consolidated Financial Statements), we incurred restructuring and other charges of $105 million during fiscal 2013, which were related primarily to employee severance charges for employees impacted by our workforce reduction under these plans.

[0000858877-15-000070:mdna:250]
Operating Income

[0000858877-15-000070:mdna:251]
The following table presents our operating income and our operating income as a percentage of revenue (in millions, except percentages):

[0000858877-15-000070:mdna:252]
| Years Ended |  | July 25, 2015 |  | July 26, 2014 |  | July 27, 2013 |
| Operating income |  | $ | 10,770 |  |  | $ | 9,345 |  |  | $ | 11,196 |  |
| Operating income as a percentage of revenue |  | 21.9 | % |  | 19.8 | % |  | 23.0 | % |

[0000858877-15-000070:mdna:253]
For fiscal 2015, as compared with fiscal 2014, operating income increased by 15%, and as a percentage of revenue operating income increased by 2.1 percentage points. The increase resulted from the following: an increase in revenue; a gross margin percentage increase, driven in part by the $655 million supplier component remediation charge (or 1.4 percentage points of fiscal 2014 revenue) recorded in fiscal 2014; and higher compensation expense recorded in fiscal 2014 in connection with our acquisition of the remaining interest in Insieme.

[0000858877-15-000070:mdna:254]
57

[0000858877-15-000070:mdna:255]
For fiscal 2014, as compared with fiscal 2013, operating income decreased by 17%, and as a percentage of revenue operating income decreased by 3.2 percentage points. The decrease resulted from the following: a decrease in revenue; a gross margin percentage decline, driven in part by the $655 million supplier component remediation charge (or 1.4 percentage points of fiscal 2014 revenue); the $416 million compensation expense recorded in fiscal 2014 in connection with our acquisition of the remaining interest in Insieme; and an increase in restructuring and other charges related to the workforce reduction under the Fiscal 2014 Plan.

[0000858877-15-000070:mdna:256]
Interest and Other Income (Loss), Net

[0000858877-15-000070:mdna:257]
Interest Income (Expense), Net   The following table summarizes interest income and interest expense (in millions):

[0000858877-15-000070:mdna:258]
|  | Years Ended |  | 2015 vs. 2014 |  | 2014 vs. 2013 |
|  | July 25, 2015 |  | July 26, 2014 |  | July 27, 2013 |  | Variance in Dollars |  | Variance in Dollars |
| Interest income | $ | 769 |  |  | $ | 691 |  |  | $ | 654 |  |  | $ | 78 |  |  | $ | 37 |  |
| Interest expense | (566 | ) |  | (564 | ) |  | (583 | ) |  | (2 | ) |  | 19 |  |
| Interest income (expense), net | $ | 203 |  |  | $ | 127 |  |  | $ | 71 |  |  | $ | 76 |  |  | $ | 56 |  |

[0000858877-15-000070:mdna:259]
Fiscal 2015 Compared with Fiscal 2014

[0000858877-15-000070:mdna:260]
Interest income increased in fiscal 2015 as compared with fiscal 2014, driven by an increase in our portfolio of cash, cash equivalents, and fixed income investments. Interest expense in fiscal 2015 as compared with the prior fiscal year increased slightly, driven by additional interest expense due to the net increase in long-term debt in fiscal 2015.

[0000858877-15-000070:mdna:261]
Fiscal 2014 Compared with Fiscal 2013

[0000858877-15-000070:mdna:262]
Interest income increased in fiscal 2014 as compared with fiscal 2013 due to the increase in our portfolio of cash, cash equivalents, and fixed income investments. The decrease in interest expense in fiscal 2014 as compared with the prior fiscal year was primarily attributable to the favorable impact of incremental interest rate swaps entered into during fiscal 2014 and the fourth quarter of fiscal 2013. This decrease was partially offset by additional interest expense due to the increase in long-term debt in fiscal 2014.

[0000858877-15-000070:mdna:263]
Other Income (Loss), Net   The components of other income (loss), net, are summarized as follows (in millions):

[0000858877-15-000070:mdna:264]
|  | Years Ended |  | 2015 vs. 2014 |  | 2014 vs. 2013 |
|  | July 25, 2015 |  | July 26, 2014 |  | July 27, 2013 |  | Variance in Dollars |  | Variance in Dollars |
| Gains (losses) on investments, net: |  |  |  |  |  |  |  |  |  |
| Publicly traded equity securities | $ | 116 |  |  | $ | 253 |  |  | $ | 17 |  |  | $ | (137 | ) |  | $ | 236 |  |
| Fixed income securities | 41 |  |  | 47 |  |  | 31 |  |  | (6 | ) |  | 16 |  |
| Total available-for-sale investments | 157 |  |  | 300 |  |  | 48 |  |  | (143 | ) |  | 252 |  |
| Privately held companies | 82 |  |  | (60 | ) |  | (57 | ) |  | 142 |  |  | (3 | ) |
| Net gains (losses) on investments | 239 |  |  | 240 |  |  | (9 | ) |  | (1 | ) |  | 249 |  |
| Other gains (losses), net | (11 | ) |  | 3 |  |  | (31 | ) |  | (14 | ) |  | 34 |  |
| Other income (loss), net | $ | 228 |  |  | $ | 243 |  |  | $ | (40 | ) |  | $ | (15 | ) |  | $ | 283 |  |

[0000858877-15-000070:mdna:265]
Fiscal 2015 Compared with Fiscal 2014

[0000858877-15-000070:mdna:266]
The decrease in total net gains on available-for-sale investments in fiscal 2015 compared with fiscal 2014 was primarily attributable to lower gains on publicly traded equity securities in the current period as a result of market conditions and the timing of sales of these securities.

[0000858877-15-000070:mdna:267]
The change in net gains (losses) on investments in privately held companies for the fiscal 2015 as compared with fiscal 2014 was primarily due to a $126 million gain recorded in fiscal 2015 related to the reorganization of our investments in VCE and lower losses related to this investment under the equity method. We ceased accounting for VCE under the equity method in October 2014. These favorable items were partially offset by higher impairment charges and lower realized gains from sales of various investments in privately held companies.

[0000858877-15-000070:mdna:268]
The change in other gains (losses), net in fiscal 2015 as compared with fiscal 2014 was driven by equity derivative impacts and higher donation expenses, partially offset by net favorable foreign exchange impacts in fiscal 2015.

[0000858877-15-000070:mdna:269]
Fiscal 2014 Compared with Fiscal 2013

[0000858877-15-000070:mdna:270]
The increase in total net gains on available-for-sale investments in fiscal 2014 compared with fiscal 2013 was primarily attributable to higher gains on publicly traded equity securities in the current period as a result of market conditions and the timing of sales of these securities.

[0000858877-15-000070:mdna:271]
The change in net losses on investments in privately held companies for the fiscal 2014 as compared with fiscal 2013 was primarily due to an increase of $40 million in our proportional share of losses from our VCE joint venture, partially offset by higher realized gains from various investments in privately held companies.

[0000858877-15-000070:mdna:272]
The change in other gains (losses), net in fiscal 2014 as compared with fiscal 2013 was primarily due to higher gains on equity derivative instruments and lower donation expenses, partially offset by unfavorable foreign exchange impacts in fiscal 2014.

[0000858877-15-000070:mdna:273]
Provision for Income Taxes

[0000858877-15-000070:mdna:274]
Our provision for income taxes is subject to volatility and could be adversely impacted by earnings being lower than anticipated in countries that have lower tax rates, higher than anticipated in countries that have higher tax rates, and expiration of or lapses in tax incentives. Our provision for income taxes does not include provisions for U.S. income taxes and foreign withholding taxes associated with the repatriation of undistributed earnings of certain foreign subsidiaries that we intend to reinvest indefinitely in our foreign subsidiaries. If these earnings were distributed from the foreign subsidiaries to the United States in the form of dividends or otherwise, or if the shares of the relevant foreign subsidiaries were sold or otherwise transferred, we would be subject to additional U.S. income taxes (subject to an adjustment for foreign tax credits) and foreign withholding taxes. Further, as a result of certain of our ongoing employment and capital investment actions and commitments, our income in certain countries is subject to reduced tax rates and in some cases is wholly exempt from tax. Our failure to meet these commitments could adversely impact our provision for income taxes.

[0000858877-15-000070:mdna:275]
Fiscal 2015 Compared with Fiscal 2014

[0000858877-15-000070:mdna:276]
The provision for income taxes resulted in an effective tax rate of 19.8% for fiscal 2015, compared with 19.2% for fiscal 2014. The net 0.6 percentage point increase in the effective tax rate between fiscal years was primarily due to a decrease in foreign income taxed at lower than U.S. rates, partially offset by an increase in U.S. federal R&D tax credit.

[0000858877-15-000070:mdna:277]
For a full reconciliation of our effective tax rate to the U.S. federal statutory rate of 35% and for further explanation of our provision for income taxes, see Note 16 to the Consolidated Financial Statements.

[0000858877-15-000070:mdna:278]
Fiscal 2014 Compared with Fiscal 2013

[0000858877-15-000070:mdna:279]
The provision for income taxes resulted in an effective tax rate of 19.2% for fiscal 2014, compared with 11.1% for fiscal 2013. The net 8.1 percentage point increase in the effective tax rate between fiscal years was primarily attributable to a non-recurring net tax benefit of $794 million, or 7.1 percentage points, due to a tax settlement with the IRS in fiscal 2013.

[0000858877-15-000070:mdna:280]
LIQUIDITY AND CAPITAL RESOURCES

[0000858877-15-000070:mdna:281]
The following sections discuss the effects of changes in our balance sheet, our capital allocation strategy including stock repurchase program and dividends, our contractual obligations, and certain other commitments and activities on our liquidity and capital resources.

[0000858877-15-000070:mdna:282]
Balance Sheet and Cash Flows

[0000858877-15-000070:mdna:283]
Cash and Cash Equivalents and Investments  The following table summarizes our cash and cash equivalents and investments (in millions):

[0000858877-15-000070:mdna:284]
|  | July 25, 2015 |  | July 26, 2014 |  | Increase (Decrease) |
| Cash and cash equivalents | $ | 6,877 |  |  | $ | 6,726 |  |  | $ | 151 |  |
| Fixed income securities | 51,974 |  |  | 43,396 |  |  | 8,578 |  |
| Publicly traded equity securities | 1,565 |  |  | 1,952 |  |  | (387 | ) |
| Total | $ | 60,416 |  |  | $ | 52,074 |  |  | $ | 8,342 |  |

[0000858877-15-000070:mdna:285]
The net increase in cash and cash equivalents and investments from fiscal 2014 to fiscal 2015 was primarily the result of cash provided by operating activities of $12.6 billion, a net increase in debt of $4.5 billion and the net issuance of common stock of $1.5 billion pursuant to employee stock incentive and purchase plans. These sources of cash were partially offset by the repurchase of common stock of $4.3 billion under the stock repurchase program, cash dividends paid of $4.1 billion, capital expenditures of $1.2 billion and net cash paid for acquisitions of $0.3 billion.

[0000858877-15-000070:mdna:286]
Our total in cash and cash equivalents and investments held by various foreign subsidiaries was $53.4 billion and $47.4 billion as of July 25, 2015 and July 26, 2014, respectively. Under current tax laws and regulations, if these assets were to be distributed from the foreign subsidiaries to the United States in the form of dividends or otherwise, we would be subject to additional U.S. income taxes (subject to an adjustment for foreign tax credits) and foreign withholding taxes. The balance of cash and cash equivalents and investments available in the United States as of July 25, 2015 and July 26, 2014 was $7.0 billion and $4.7 billion, respectively.

[0000858877-15-000070:mdna:287]
We maintain an investment portfolio of various holdings, types, and maturities. We classify our investments as short-term investments based on their nature and their availability for use in current operations. We believe the overall credit quality of our portfolio is strong, with our cash equivalents and our fixed income investment portfolio consisting primarily of high quality investment-grade securities. We believe that our strong cash and cash equivalents and investments position allows us to use our cash resources for strategic investments to gain access to new technologies, for acquisitions, for customer financing activities, for working capital needs, and for the repurchase of shares of common stock and payment of dividends as discussed below.

[0000858877-15-000070:mdna:288]
Free Cash Flow and Capital Allocation   As part of our capital allocation strategy, we intend to return a minimum of 50% of our free cash flow annually to our shareholders through cash dividends and repurchases of common stock.

[0000858877-15-000070:mdna:289]
We define free cash flow as net cash provided by operating activities less cash used to acquire property and equipment. The following table reconciles our net cash provided by operating activities to free cash flow (in millions):

[0000858877-15-000070:mdna:290]
| Years Ended | July 25, 2015 |  | July 26, 2014 |  | July 27, 2013 |
| Net cash provided by operating activities | $ | 12,552 |  |  | $ | 12,332 |  |  | $ | 12,894 |  |
| Acquisition of property and equipment | (1,227 | ) |  | (1,275 | ) |  | (1,160 | ) |
| Free cash flow | $ | 11,325 |  |  | $ | 11,057 |  |  | $ | 11,734 |  |

[0000858877-15-000070:mdna:291]
We expect that cash provided by operating activities may fluctuate in future periods as a result of a number of factors, including fluctuations in our operating results, the rate at which products are shipped during the quarter (which we refer to as shipment linearity), the timing and collection of accounts receivable and financing receivables, inventory and supply chain management, deferred revenue, excess tax benefits resulting from share-based compensation, and the timing and amount of tax and other payments. For additional discussion, see “Part I, Item 1A. Risk Factors” in this report.

[0000858877-15-000070:mdna:292]
We consider free cash flow to be a liquidity measure that provides useful information to management and investors because of our intent to return a stated percentage of free cash flow to shareholders in the form of dividends and stock repurchases.  We further regard free cash flow as a useful measure because it reflects cash that can be used to, among other things, invest in our business, make strategic acquisitions, repurchase common stock, and pay dividends on our common stock, after deducting capital investments. A limitation of the utility of free cash flow as a measure of financial performance and liquidity is that the free cash flow does not represent the total increase or decrease in our cash balance for the period.  In addition, we have other required uses of cash, including repaying the principal of our outstanding indebtedness.  Free cash flow is not a measure calculated in

[0000858877-15-000070:mdna:293]
accordance with U.S. generally accepted accounting principles and should not be regarded in isolation or as an alternative for net income provided by operating activities or any other measure calculated in accordance with such principles, and other companies may calculate free cash flow in a different manner than we do.

[0000858877-15-000070:mdna:294]
The following table summarizes the dividends paid and stock repurchases (in millions, except per-share amounts):

[0000858877-15-000070:mdna:295]
|  |  | DIVIDENDS |  | STOCK REPURCHASE PROGRAM |  | TOTAL |
| Years Ended |  | Per Share |  | Amount |  | Shares |  | Weighted-Average Price per Share |  | Amount |  | Amount |
| July 25, 2015 |  | $ | 0.80 |  |  | $ | 4,086 |  |  | 155 |  |  | $ | 27.22 |  |  | $ | 4,234 |  |  | $ | 8,320 |  |
| July 26, 2014 |  | $ | 0.72 |  |  | $ | 3,758 |  |  | 420 |  |  | $ | 22.71 |  |  | $ | 9,539 |  |  | $ | 13,297 |  |
| July 27, 2013 |  | $ | 0.62 |  |  | $ | 3,310 |  |  | 128 |  |  | $ | 21.63 |  |  | $ | 2,773 |  |  | $ | 6,083 |  |

[0000858877-15-000070:mdna:296]
Any future dividends will be subject to the approval of our Board of Directors.

[0000858877-15-000070:mdna:297]
Accounts Receivable, Net The following table summarizes our accounts receivable, net (in millions), and DSO:

[0000858877-15-000070:mdna:298]
|  | July 25, 2015 |  | July 26, 2014 |  | Increase (Decrease) |
| Accounts receivable, net | $ | 5,344 |  |  | $ | 5,157 |  |  | $ | 187 |  |
| DSO | 38 |  |  | 38 |  |  | — |  |

[0000858877-15-000070:mdna:299]
Our accounts receivable net, as of July 25, 2015 increased by approximately 4% compared with the end of fiscal 2014. Our DSO as of July 25, 2015 was flat compared with the end of fiscal 2014, as factors that drive DSO such as shipment linearity and collections were similar for the periods presented.

[0000858877-15-000070:mdna:300]
Inventory Supply Chain  The following table summarizes our inventories and purchase commitments with contract manufacturers and suppliers (in millions, except annualized inventory turns):

[0000858877-15-000070:mdna:301]
|  | July 25, 2015 |  | July 26, 2014 |  | Increase (Decrease) |
| Inventories | $ | 1,627 |  |  | $ | 1,591 |  |  | $ | 36 |  |
| Annualized inventory turns | 12.1 |  |  | 12.7 |  |  | (0.6 | ) |
| Purchase commitments with contract manufacturers and suppliers | $ | 4,078 |  |  | $ | 4,169 |  |  | $ | (91 | ) |

[0000858877-15-000070:mdna:302]
Inventory as of July 25, 2015 increased by 2% from our inventory balance at the end of fiscal 2014, and for the same period purchase commitments with contract manufacturers and suppliers decreased by approximately 2%.  On a combined basis, inventories and purchase commitments with contract manufacturers and suppliers decreased by 1% compared with the end of fiscal 2014. We believe our inventory and purchase commitments levels are in line with our current demand forecasts.

[0000858877-15-000070:mdna:303]
Our finished goods consist of distributor inventory and deferred cost of sales and manufactured finished goods. Distributor inventory and deferred cost of sales are related to unrecognized revenue on shipments to distributors and retail partners as well as shipments to customers. Manufactured finished goods consist primarily of build-to-order and build-to-stock products.

[0000858877-15-000070:mdna:304]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that allow them to procure inventory based upon criteria as defined by us or that establish the parameters defining our requirements and our commitment to securing manufacturing capacity. A significant portion of our reported purchase commitments arising from these agreements are firm, noncancelable, and unconditional commitments. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed. Our purchase commitments are for short-term product manufacturing requirements as well as for commitments to suppliers to secure manufacturing capacity.

[0000858877-15-000070:mdna:305]
Inventory and supply chain management remain areas of focus as we balance the need to maintain supply chain flexibility to help ensure competitive lead times with the risk of inventory obsolescence because of rapidly changing technology and customer requirements. We believe the amount of our inventory and purchase commitments is appropriate for our revenue levels.

[0000858877-15-000070:mdna:306]
Financing Receivables and Guarantees We measure our net balance sheet exposure position related to our financing receivables and financing guarantees by reducing the total of gross financing receivables and financing guarantees by the associated allowances for credit loss and deferred revenue. As of July 25, 2015, our net balance sheet exposure position related to financing receivables and financing guarantees was as follows (in millions):

[0000858877-15-000070:mdna:307]
|  | FINANCING RECEIVABLES |  | FINANCING GUARANTEES |  |  |
| July 25, 2015 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts and Other |  | Total |  | Channel Partner |  | End-User Customers |  | Total |  | TOTAL |
| Financing receivables and guarantees | $ | 3,395 |  |  | $ | 1,763 |  |  | $ | 3,573 |  |  | $ | 8,731 |  |  | $ | 288 |  |  | $ | 129 |  |  | $ | 417 |  |  | $ | 9,148 |  |
| Allowance for credit loss | (259 | ) |  | (87 | ) |  | (36 | ) |  | (382 | ) |  | — |  |  | — |  |  | — |  |  | (382 | ) |
| Deferred revenue | (5 | ) |  | (13 | ) |  | (1,853 | ) |  | (1,871 | ) |  | (127 | ) |  | (107 | ) |  | (234 | ) |  | (2,105 | ) |
| Net balance sheet exposure | $ | 3,131 |  |  | $ | 1,663 |  |  | $ | 1,684 |  |  | $ | 6,478 |  |  | $ | 161 |  |  | $ | 22 |  |  | $ | 183 |  |  | $ | 6,661 |  |

[0000858877-15-000070:mdna:308]
Financing Receivables  Financing receivables less unearned income increased by 4% compared with the end of fiscal 2014. The change was primarily due to an 11% increase in financed service contracts and other, and a 5% increase in loan receivables, partially offset by a 4% decrease in lease receivables. We provide financing to certain end-user customers and channel partners to enable sales of our products, services, and networking solutions. These financing arrangements include leases, financed service contracts, and loans. Arrangements related to leases are generally collateralized by a security interest in the underlying assets. Lease receivables include sales-type and direct-financing leases. We also provide certain qualified customers financing for long-term service contracts, which primarily relate to technical support services.  Our loan financing arrangements may include not only financing the acquisition of our products and services but also providing additional funds for other costs associated with network installation and integration of our products and services. We expect to continue to expand the use of our financing programs in the near term.

[0000858877-15-000070:mdna:309]
Financing Guarantees  In the normal course of business, third parties may provide financing arrangements to our customers and channel partners under financing programs. The financing arrangements to customers provided by third parties are related to leases and loans and typically have terms of up to three years. In some cases, we provide guarantees to third parties for these lease and loan arrangements. The financing arrangements to channel partners consist of revolving short-term financing provided by third parties, generally with payment terms ranging from 60 to 90 days. In certain instances, these financing arrangements result in a transfer of our receivables to the third party. The receivables are derecognized upon transfer, as these transfers qualify as true sales, and we receive payments for the receivables from the third party based on our standard payment terms.  The volume of channel partner financing was $25.9 billion, $24.6 billion, and $23.8 billion in fiscal 2015, 2014, and 2013, respectively. These financing arrangements facilitate the working capital requirements of the channel partners, and in some cases, we guarantee a portion of these arrangements. The balance of the channel partner financing subject to guarantees was $1.2 billion as of each of July 25, 2015 and July 26, 2014.  We could be called upon to make payments under these guarantees in the event of nonpayment by the channel partners or end-user customers. Historically, our payments under these arrangements have been immaterial. Where we provide a guarantee, we defer the revenue associated with the channel partner and end-user financing arrangement in accordance with revenue recognition policies, or we record a liability for the fair value of the guarantees. In either case, the deferred revenue is recognized as revenue when the guarantee is removed.

[0000858877-15-000070:mdna:310]
Deferred Revenue Related to Financing Receivables and Guarantees The majority of the deferred revenue in the preceding table is related to financed service contracts. The majority of the revenue related to financed service contracts, which primarily relates to technical support services, is deferred as the revenue related to financed service contracts is recognized ratably over the period during which the related services are to be performed. A portion of the revenue related to lease and loan receivables is also deferred and included in deferred product revenue based on revenue recognition criteria not currently having been met.

[0000858877-15-000070:mdna:311]
62

[0000858877-15-000070:mdna:312]
Borrowings

[0000858877-15-000070:mdna:313]
Senior Notes  The following table summarizes the principal amount of our senior notes (in millions):

[0000858877-15-000070:mdna:314]
|  | Maturity Date |  | July 25, 2015 |  | July 26, 2014 |  |
| Senior notes: |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |
| Three-month LIBOR plus 0.05% | September 3, 2015 |  | $ | 850 |  |  | $ | 850 |  |  |
| Three-month LIBOR plus 0.28% | March 3, 2017 |  | 1,000 |  |  | 1,000 |  |  |
| Three-month LIBOR plus 0.31% | June 15, 2018 | (1) | 900 |  |  | — |  |  |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | 500 |  |  | 500 |  |  |
| Fixed-rate notes: |  |  |  |  |  |  |
| 2.90% | November 17, 2014 |  | — |  |  | 500 |  |  |
| 5.50% | February 22, 2016 |  | 3,000 |  |  | 3,000 |  |  |
| 1.10% | March 3, 2017 |  | 2,400 |  |  | 2,400 |  |  |
| 3.15% | March 14, 2017 |  | 750 |  |  | 750 |  |  |
| 1.65% | June 15, 2018 | (1) | 1,600 |  |  | — |  |  |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 2,000 |  |  |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 1,750 |  |  |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 2,500 |  |  |
| 2.45% | June 15, 2020 | (1) | 1,500 |  |  | — |  |  |
| 2.90% | March 4, 2021 |  | 500 |  |  | 500 |  |  |
| 3.00% | June 15, 2022 | (1) | 500 |  |  | — |  |  |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1,000 |  |  |
| 3.50% | June 15, 2025 | (1) | 500 |  |  | — |  |  |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 2,000 |  |  |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 2,000 |  |  |
| Total |  |  | $ | 25,250 |  |  | $ | 20,750 |  |  |

[0000858877-15-000070:mdna:315]
(1) In June 2015, we issued senior notes with an aggregate principal amount of $5.0 billion.

[0000858877-15-000070:mdna:316]
Interest is payable semiannually on each class of the senior fixed-rate notes, each of which is redeemable by us at any time, subject to a make-whole premium. Interest is payable quarterly on the floating-rate notes. We were in compliance with all debt covenants as of July 25, 2015.

[0000858877-15-000070:mdna:317]
We repaid the fixed-rate notes (2.90%) due on November 17, 2014, for an aggregate principal amount of $500 million upon maturity.

[0000858877-15-000070:mdna:318]
We repaid the floating-rate notes due on September 3, 2015 for an aggregate principal amount of $850 million upon maturity.

[0000858877-15-000070:mdna:319]
Other Debt  Other debt as of July 25, 2015 and July 26, 2014 includes secured borrowings associated with customer financing arrangements.  The amount of borrowings outstanding under these arrangements was $4 million and $12 million as of July 25, 2015 and July 26, 2014, respectively.

[0000858877-15-000070:mdna:320]
Commercial Paper  In fiscal 2011, we established a short-term debt financing program of up to $3.0 billion through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes. We had no commercial paper notes outstanding as of each of July 25, 2015 and July 26, 2014.

[0000858877-15-000070:mdna:321]
Credit Facility  On May 15, 2015, we entered into a credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 15, 2020. Any advances under the credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (i) the highest of (a) the Federal Funds rate plus 0.50%, (b) Bank of America’s “prime rate” as announced from time to time, or (c) LIBOR, or a comparable or successor rate that is approved by the Administrative Agent (“Eurocurrency Rate”), for an interest period of one month plus 1.00%, or (ii) the Eurocurrency Rate, plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the Eurocurrency Rate be less than zero. The credit agreement requires that we comply with certain covenants, including that it maintains an interest coverage ratio as defined in the agreement.

[0000858877-15-000070:mdna:322]
We may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and/or extend the expiration date of the credit facility up to May 15, 2022.  We were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under the credit facility.

[0000858877-15-000070:mdna:323]
This credit facility replaces our prior credit facility that was entered into on February 17, 2012, which was terminated in connection with its entering into the new credit facility.

[0000858877-15-000070:mdna:324]
Deferred Revenue   The following table presents the breakdown of deferred revenue (in millions):

[0000858877-15-000070:mdna:325]
|  | July 25, 2015 |  | July 26, 2014 |  | Increase (Decrease) |
| Service | $ | 9,757 |  |  | $ | 9,640 |  |  | $ | 117 |  |
| Product | 5,426 |  |  | 4,502 |  |  | 924 |  |
| Total | $ | 15,183 |  |  | $ | 14,142 |  |  | $ | 1,041 |  |
| Reported as: |  |  |  |  |  |
| Current | $ | 9,824 |  |  | $ | 9,478 |  |  | $ | 346 |  |
| Noncurrent | 5,359 |  |  | 4,664 |  |  | 695 |  |
| Total | $ | 15,183 |  |  | $ | 14,142 |  |  | $ | 1,041 |  |

[0000858877-15-000070:mdna:326]
Deferred product revenue increased 21% primarily due to increased deferrals related to subscription and software revenue arrangements and also, to a lesser extent, to an increase in shipments not having met revenue recognition criteria as of July 25, 2015.  The product categories of Collaboration, Security, and Wireless were the key contributors to the increase. The increase in deferred service revenue in fiscal 2015 was driven by the timing of multiyear arrangements, an increase in customers paying technical support service contracts over time and the impact of ongoing amortization of deferred service revenue.

[0000858877-15-000070:mdna:327]
Contractual Obligations

[0000858877-15-000070:mdna:328]
The impact of contractual obligations on our liquidity and capital resources in future periods should be analyzed in conjunction with the factors that impact our cash flows from operations discussed previously. In addition, we plan for and measure our liquidity and capital resources through an annual budgeting process. The following table summarizes our contractual obligations at July 25, 2015 (in millions):

[0000858877-15-000070:mdna:329]
|  | PAYMENTS DUE BY PERIOD |
| July 25, 2015 | Total |  | Less than 1 Year |  | 1 to 3 Years |  | 3 to 5 Years |  | More than 5 Years |
| Operating leases | $ | 1,142 |  |  | $ | 346 |  |  | $ | 435 |  |  | $ | 178 |  |  | $ | 183 |  |
| Purchase commitments with contract manufacturers and suppliers | 4,078 |  |  | 4,078 |  |  | — |  |  | — |  |  | — |  |
| Other purchase obligations | 2,012 |  |  | 604 |  |  | 815 |  |  | 536 |  |  | 57 |  |
| Long-term debt including the current portion | 25,251 |  |  | 3,850 |  |  | 6,651 |  |  | 8,250 |  |  | 6,500 |  |
| Other long-term liabilities | 1,213 |  |  | — |  |  | 350 |  |  | 72 |  |  | 791 |  |
| Total by period | $ | 33,696 |  |  | $ | 8,878 |  |  | $ | 8,251 |  |  | $ | 9,036 |  |  | $ | 7,531 |  |
| Other long-term liabilities (uncertainty in the timing of future payments) | 2,122 |  |  |  |  |  |  |  |  |  |
| Total | $ | 35,818 |  |  |  |  |  |  |  |  |  |

[0000858877-15-000070:mdna:330]
Operating Leases   For more information on our operating leases, see Note 12 to the Consolidated Financial Statements.

[0000858877-15-000070:mdna:331]
Purchase Commitments with Contract Manufacturers and Suppliers   We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. A significant portion of our reported estimated purchase commitments arising from these agreements are firm, noncancelable, and unconditional commitments. We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. See further discussion in “Inventory Supply Chain.” As of July 25, 2015, the liability for these purchase commitments was $156 million and is recorded in other current liabilities and is not included in the preceding table.

[0000858877-15-000070:mdna:332]
Other Purchase Obligations   Other purchase obligations represent an estimate of all contractual obligations in the ordinary course of business, other than operating leases and commitments with contract manufacturers and suppliers, for which we have not received the goods or services.  Purchase orders are not included in the preceding table as they typically represent our authorization to purchase rather than binding contractual purchase obligations.

[0000858877-15-000070:mdna:333]
Long-Term Debt   The amount of long-term debt in the preceding table represents the principal amount of the respective debt instruments. See Note 10 to the Consolidated Financial Statements.

[0000858877-15-000070:mdna:334]
Other Long-Term Liabilities   Other long-term liabilities primarily include noncurrent income taxes payable, accrued liabilities for deferred compensation, noncurrent deferred tax liabilities, and certain other long-term liabilities. Due to the uncertainty in the timing of future payments, our noncurrent income taxes payable of approximately $1,876 million  and noncurrent deferred tax liabilities of $246 million were presented as one aggregated amount in the total column on a separate line in the preceding table. Noncurrent income taxes payable include uncertain tax positions (see Note 16 to the Consolidated Financial Statements).

[0000858877-15-000070:mdna:335]
Other Commitments

[0000858877-15-000070:mdna:336]
In connection with our business combinations and asset purchases, we have agreed to pay certain additional amounts contingent upon the achievement of certain agreed-upon technology, development, product, or other milestones or the continued employment with us of certain employees of the acquired entities. See Note 12 to the Consolidated Financial Statements.

[0000858877-15-000070:mdna:337]
Insieme Networks, Inc.  In the third quarter of fiscal 2012, we made an investment in Insieme, an early stage company focused on research and development in the data center market.  As set forth in the agreement between Cisco and Insieme, this investment included $100 million of funding and a license to certain of our technology.  Immediately prior to the call option exercise and acquisition described below, we owned approximately 83% of Insieme as a result of these investments and have consolidated the results of Insieme in our Consolidated Financial Statements. In connection with this investment, we entered into a put/call option agreement that provided us with the right to purchase the remaining interests in Insieme.  In addition, the noncontrolling interest holders could require us to purchase their shares upon the occurrence of certain events.

[0000858877-15-000070:mdna:338]
During the first quarter of fiscal 2014, we exercised our call option and entered into an agreement to purchase the remaining interests in Insieme. The acquisition closed in the second quarter of fiscal 2014, at which time the former noncontrolling interest holders became eligible to receive up to two milestone payments, which will be determined using agreed-upon formulas based primarily on revenue for certain of Insieme’s products.  During fiscal 2015 and 2014, we recorded compensation expense of $207 million and $416 million, respectively, related to the fair value of the vested portion of amounts that were earned or expected to be earned by the former noncontrolling interest holders. Continued vesting and changes to the fair value of the amounts probable of being earned will result in adjustments to the recorded compensation expense in future periods. Based on the terms of the agreement, we have determined that the maximum amount that could be recorded as compensation expense by us is approximately $843 million (which includes the $623 million that has been expensed to date), net of forfeitures.  The milestone payments, to the extent earned, are expected to be paid primarily during the first half of each of fiscal 2016 and fiscal 2017.

[0000858877-15-000070:mdna:339]
Other Funding Commitments  We also have certain funding commitments primarily related to our investments in privately held companies and venture funds, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $205 million as of July 25, 2015, compared with $255 million as of July 26, 2014.

[0000858877-15-000070:mdna:340]
Off-Balance Sheet Arrangements

[0000858877-15-000070:mdna:341]
We consider our investments in unconsolidated variable interest entities to be off-balance sheet arrangements. In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers may be considered to be variable interest entities. We evaluate on an ongoing basis our investments in these privately held companies and customer financings, and we have determined that as of July 25, 2015 there were no material unconsolidated variable interest entities.

[0000858877-15-000070:mdna:342]
On an ongoing basis, we reassess our investments in privately held companies and customer financings to determine if they are variable interest entities and if we would be regarded as the primary beneficiary pursuant to the applicable accounting guidance. As a result of this ongoing assessment, we may be required to make additional disclosures or consolidate these entities. Because we may not control these entities, we may not have the ability to influence these events.

[0000858877-15-000070:mdna:343]
We provide financing guarantees, which are generally for various third-party financing arrangements extended to our channel partners and end-user customers. We could be called upon to make payments under these guarantees in the event of nonpayment by the channel partners or end-user customers. See the previous discussion of these financing guarantees under “Financing Receivables and Guarantees.”

[0000858877-15-000070:mdna:344]
Securities Lending

[0000858877-15-000070:mdna:345]
We periodically engage in securities lending activities with certain of our available-for-sale investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. The average daily balance of securities lending for fiscal 2015 and 2014 was $0.4 billion and $1.5 billion, respectively. We require collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. We engage in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify us against collateral losses. As of July 25, 2015 and July 26, 2014, we had no outstanding securities lending transactions. We believe these arrangements do not present a material risk or impact to our liquidity requirements.

[0000858877-15-000070:mdna:346]
Liquidity and Capital Resource Requirements

[0000858877-15-000070:mdna:347]
Based on past performance and current expectations, we believe our cash and cash equivalents, investments, cash generated from operations, and ability to access capital markets and committed credit lines will satisfy, through at least the next 12 months, our liquidity requirements, both in total and domestically, including the following: working capital needs, capital expenditures, investment requirements, stock repurchases, cash dividends, contractual obligations, commitments, principal and interest payments on debt, future customer financings, and other liquidity requirements associated with our operations. There are no other transactions, arrangements, or relationships with unconsolidated entities or other persons that are reasonably likely to materially affect the liquidity and the availability of, as well as our requirements for, capital resources.

[0000858877-15-000070:mdna:348]
66
