# CSCO 8-K — 0001193125-15-288099 filed 2015-08-12

## item codes, every 8-K on or before 2015-09-08

- 2015-08-28 0001193125-15-306843 — 8.01
- 2015-08-12 0001193125-15-288099 — 2.02
- 2015-07-29 0001193125-15-268359 — 5.02 — amendment of 0001193125-15-169227
- 2015-06-18 0001193125-15-227387 — 8.01, 9.01
- 2015-06-12 0001193125-15-221863 — 1.01, 9.01
- 2015-06-10 0001193125-15-218734 — 8.01, 9.01
- 2015-06-01 0001193125-15-209142 — 5.02, 9.01
- 2015-05-13 0001193125-15-185905 — 2.02
- 2015-05-04 0001193125-15-169227 — 5.02
- 2015-03-24 0001193125-15-103369 — 8.01
- 2015-03-19 0001193125-15-098638 — 8.01
- 2015-02-11 0001193125-15-044175 — 2.02
- 2014-12-19 0001193125-14-448754 — 8.01
- 2014-12-18 0001193125-14-447039 — 8.01
- 2014-11-24 0001193125-14-423591 — 5.02, 5.07, 9.01
- 2014-11-14 0001193125-14-413384 — 5.02
- 2014-11-12 0001193125-14-409258 — 2.02
- 2014-09-25 0001193125-14-353210 — 8.01
- 2014-09-12 0001193125-14-340480 — 5.02
- 2014-08-14 0001193125-14-308733 — 2.05
- 2014-08-13 0001193125-14-308403 — 2.02
- 2014-07-31 0001193125-14-289683 — 5.02
- 2014-06-25 0001193125-14-249157 — 8.01
- 2014-05-14 0001193125-14-199056 — 2.02
- 2014-03-26 0001193125-14-116588 — 8.01
- 2014-03-11 0001193125-14-093805 — 8.01
- 2014-03-03 0001193125-14-079163 — 1.01, 8.01, 9.01
- 2014-02-26 0001193125-14-069912 — 1.01, 9.01
- 2014-02-12 0001193125-14-048150 — 2.02
- 2013-12-23 0001193125-13-483099 — 8.01
- 2013-12-04 0001193125-13-462216 — 8.01
- 2013-11-20 0001193125-13-448477 — 5.02, 5.07, 9.01
- 2013-11-13 0001193125-13-440194 — 2.02
- 2013-08-15 0001193125-13-335218 — 2.05
- 2013-08-14 0001193125-13-334648 — 2.02
- 2013-07-23 0001193125-13-298129 — 8.01, 9.01
- 2013-06-24 0001193125-13-269064 — 8.01
- 2013-06-12 0001193125-13-256194 — 8.01
- 2013-06-07 0001193125-13-250920 — 8.01
- 2013-05-15 0001193125-13-222377 — 2.02
- 2013-03-26 0001193125-13-127015 — 8.01
- 2013-02-13 0001193125-13-055377 — 2.02
- 2013-02-01 0001193125-13-034682 — 5.02
- 2013-01-08 0001193125-13-006886 — 5.02, 9.01
- 2012-12-21 0001193125-12-513130 — 8.01
- 2012-12-19 0001193125-12-508424 — 8.01
- 2012-11-16 0001193125-12-474089 — 5.02, 5.07, 9.01
- 2012-11-13 0001193125-12-467422 — 2.02
- 2012-10-04 0001193125-12-415386 — 5.02, 5.03, 9.01
- 2012-09-19 0001193125-12-396875 — 5.02, 8.01
- 2012-08-15 0001193125-12-357479 — 2.02
- 2012-08-02 0001193125-12-332045 — 5.02
- 2012-06-27 0001193125-12-285742 — 8.01
- 2012-06-13 0001193125-12-269642 — 8.01
- 2012-05-09 0001193125-12-222045 — 2.02
- 2012-03-27 0001193125-12-134384 — 8.01
- 2012-03-15 0001193125-12-117538 — 8.01, 9.01
- 2012-02-17 0001193125-12-067542 — 1.01, 1.02, 2.03, 9.01
- 2012-02-08 0001193125-12-046545 — 2.02
- 2011-12-16 0001193125-11-343995 — 8.01
- 2011-12-08 0001193125-11-335127 — 5.02, 5.07, 9.01
- 2011-11-09 0001193125-11-304587 — 2.02
- 2011-09-29 0001193125-11-260065 — 8.01
- 2011-09-20 0001193125-11-252379 — 5.02, 9.01
- 2011-08-24 0001193125-11-231015 — 8.01
- 2011-08-10 0001193125-11-218133 — 2.02
- 2011-07-18 0001193125-11-190246 — 2.05
- 2011-06-22 0001193125-11-170849 — 8.01
- 2011-05-11 0001193125-11-135913 — 2.02
- 2011-03-28 0001193125-11-079927 — 8.01
- 2011-03-22 0001193125-11-073802 — 5.02 — amendment of 0001193125-11-043592
- 2011-03-18 0001193125-11-071279 — 8.01, 9.01
- 2011-03-16 0001193125-11-067985 — 1.01, 5.02, 8.01, 9.01
- 2011-03-15 0001193125-11-067331 — 1.01, 9.01
- 2011-03-09 0001193125-11-060123 — 8.01, 9.01
- 2011-02-23 0001193125-11-043592 — 5.02
- 2011-02-09 0001193125-11-028987 — 2.02
- 2011-01-31 0001193125-11-019101 — 1.01, 2.03
- 2010-12-17 0001193125-10-283392 — 8.01
- 2010-11-19 0001193125-10-265377 — 5.07
- 2010-11-10 0001193125-10-256001 — 2.02
- 2010-09-22 0001193125-10-214707 — 8.01
- 2010-09-16 0001193125-10-211456 — 7.01
- 2010-08-11 0001193125-10-186042 — 2.02
- 2010-06-29 0001193125-10-149956 — 8.01
- 2010-05-12 0001193125-10-117509 — 2.02
- 2010-02-17 0001193125-10-033290 — 5.02, 8.01, 9.01
- 2010-02-03 0001193125-10-020775 — 2.02
- 2009-11-25 0001193125-09-242589 — 8.01
- 2009-11-17 0001193125-09-236335 — 1.01, 8.01, 9.01
- 2009-11-13 0001193125-09-234405 — 1.01, 2.03, 9.01
- 2009-11-13 0001193125-09-234397 — 5.02 — amendment of 0001193125-09-189511
- 2009-11-12 0001193125-09-232971 — 5.02, 7.01, 9.01
- 2009-11-09 0001193125-09-228541 — 8.01, 9.01
- 2009-11-04 0001193125-09-223763 — 2.02
- 2009-10-14 0001193125-09-207912 — 8.01, 9.01
- 2009-10-05 0001193125-09-203556 — 8.01
- 2009-09-10 0001193125-09-189511 — 5.02
- 2009-09-04 0001193125-09-187835 — 5.02
- 2009-08-05 0001193125-09-165404 — 2.02
- 2009-07-27 0001193125-09-155861 — 5.02
- 2009-05-29 0001193125-09-121672 — 8.01
- 2009-05-06 0001193125-09-101570 — 2.02
- 2009-02-26 0001193125-09-038162 — 5.02
- 2009-02-17 0001193125-09-030546 — 1.01, 8.01, 9.01
- 2009-02-13 0001193125-09-029295 — 1.01, 2.03, 9.01
- 2009-02-04 0001193125-09-018793 — 2.02
- 2008-11-05 0001193125-08-225857 — 2.02
- 2008-09-11 0001193125-08-194695 — 7.01
- 2008-08-05 0001193125-08-166496 — 2.02
- 2008-06-20 0001193125-08-137504 — 8.01
- 2008-05-06 0001193125-08-104089 — 2.02
- 2008-03-21 0001193125-08-062838 — 8.01
- 2008-02-06 0001193125-08-021681 — 2.02
- 2008-01-23 0001193125-08-010589 — 5.02
- 2008-01-04 0001193125-08-001680 — 5.02, 9.01
- 2007-12-21 0001193125-07-269613 — 5.02
- 2007-11-19 0001193125-07-250345 — 5.02 — amendment of 0001193125-07-009285
- 2007-11-19 0001193125-07-250343 — 5.02, 9.01
- 2007-11-07 0001193125-07-238464 — 2.02
- 2007-09-24 0001193125-07-206279 — 8.01
- 2007-09-20 0001193125-07-204616 — 5.02, 7.01
- 2007-09-07 0001193125-07-197514 — 8.01
- 2007-08-17 0001193125-07-185320 — 1.01, 2.03, 9.01
- 2007-08-08 0001193125-07-174077 — 5.02
- 2007-08-07 0001193125-07-173689 — 2.02
- 2007-08-01 0001193125-07-168143 — 5.02
- 2007-05-15 0001193125-07-115800 — 8.01
- 2007-05-08 0001193125-07-106059 — 2.02
- 2007-03-23 0001193125-07-063033 — 5.02, 5.03, 8.01, 9.01
- 2007-03-21 0001193125-07-060631 — 1.01, 9.01
- 2007-02-06 0001193125-07-021349 — 2.02
- 2007-01-19 0001193125-07-009285 — 5.02
- 2006-12-22 0001193125-06-259241 — 8.01
- 2006-11-16 0001193125-06-237260 — 5.03, 8.01, 9.01
- 2006-11-08 0001193125-06-228341 — 2.02
- 2006-09-21 0001193125-06-194890 — 1.01, 7.01
- 2006-09-20 0001193125-06-194063 — 1.01
- 2006-09-15 0001193125-06-191845 — 5.02
- 2006-08-18 0001193125-06-176193 — 5.02
- 2006-08-08 0001193125-06-165719 — 2.02
- 2006-07-31 0001193125-06-157106 — 1.01, 9.01
- 2006-07-31 0001193125-06-157102 — 5.02 — amendment of 0001193125-06-017426
- 2006-06-08 0001193125-06-126879 — 5.02
- 2006-05-18 0001193125-06-115516 — 8.01
- 2006-05-12 0001193125-06-110924 — 9.01 — amendment of 0001193125-06-044013
- 2006-05-09 0001193125-06-105419 — 2.02
- 2006-03-29 0001193125-06-066990 — 1.01
- 2006-03-02 0001193125-06-044013 — 1.01, 2.01, 9.01
- 2006-02-28 0001193125-06-041452 — 1.01
- 2006-02-22 0001193125-06-036759 — 8.01
- 2006-02-22 0001193125-06-036433 — 1.01, 8.01, 9.01
- 2006-02-21 0001193125-06-035865 — 1.01, 2.03, 9.01
- 2006-02-10 0001193125-06-026218 — 8.01, 9.01
- 2006-02-07 0001193125-06-022234 — 2.02
- 2006-02-01 0001193125-06-017426 — 5.02
- 2005-11-18 0001193125-05-229535 — 1.01, 9.01
- 2005-11-16 0001193125-05-227987 — 1.01, 9.01
- 2005-11-16 0001193125-05-227983 — 5.02 — amendment of 0001193125-05-008843
- 2005-11-09 0001193125-05-221610 — 2.02
- 2005-09-29 0001193125-05-194217 — 7.01
- 2005-09-27 0001193125-05-192353 — 8.01
- 2005-09-21 0001193125-05-189234 — 1.01, 9.01
- 2005-09-19 0001193125-05-187646 — 8.01
- 2005-09-09 0001193125-05-183273 — 8.01
- 2005-09-08 0001193125-05-182307 — 1.01
- 2005-08-09 0001193125-05-162626 — 2.02
- 2005-07-15 0001193125-05-142738 — 8.01
- 2005-05-10 0001193125-05-102797 — 2.02
- 2005-03-30 0001193125-05-065123 — 1.01, 3.03, 9.01
- 2005-03-04 0001193125-05-042778 — 1.01
- 2005-02-08 0001193125-05-022181 — 2.02
- 2005-01-20 0001193125-05-008843 — 5.02
- 2004-12-23 0001193125-04-219331 — 8.01
- 2004-11-09 0001193125-04-191303 — 2.02
- 2004-08-23 0001193125-04-145198 — 1.01, 7.01
- 2004-08-19 0001193125-04-143859 — 5
- 2004-08-10 0001193125-04-136865 — 12
- 2004-05-11 0001193125-04-084721 — 12
- 2004-02-03 0001193125-04-013750 — 12
- 2003-11-05 0001193125-03-073418 — 12
- 2003-09-02 0001193125-03-044521 — 9
- 2003-08-05 0001193125-03-029223 — 12, 7
- 2003-07-18 0001193125-03-021155 — 5, 7
- 2003-06-05 0001012870-03-002949 — 5
- 2003-05-06 0000891618-03-002315 — 7, 9
- 2003-04-17 0000891618-03-001894 — 5, 7
- 2003-04-11 0000891618-03-001791 — 9
- 2003-03-20 0000891618-03-001326 — 5, 7
- 2003-02-04 0000891618-03-000518 — 7, 9
- 2003-01-28 0000891618-03-000271 — 5, 7
- 2002-12-27 0000891618-02-005686 — 5, 7
- 2002-10-23 0000891618-02-004715 — 5, 7
- 2002-10-11 0000891618-02-004620 — 5, 7
- 2002-09-18 0000891618-02-004352 — 5, 7
- 2002-08-20 0000891618-02-004001 — 5, 7
- 2002-08-05 0000891618-02-003498 — 5, 7
- 2002-07-03 0000891618-02-003099 — 5, 7
- 2002-05-14 0000891618-02-002407 — 5, 7
- 2002-02-05 0000891618-02-000412 — 5, 7
- 2001-09-28 0001095811-01-505261 — 5, 7
- 2001-09-14 0001095811-01-504917 — 5, 7
- 2001-08-24 0001095811-01-504581 — 5, 7
- 2001-07-30 0001095811-01-503468 — 5, 7
- 2001-07-12 0000891618-01-501567 — 5, 7
- 2001-05-11 0000891618-01-500638 — 5, 7
- 2001-02-27 0000891618-01-500076 — 5, 7
- 2001-02-20 0001095811-01-001530 — 5, 7
- 2001-02-08 0001095811-01-000848 — 5, 7
- 2001-02-07 0001095811-01-000768 — 5
- 2000-12-27 0001095811-00-005511 — 5
- 2000-12-21 0001095811-00-005427 — 5
- 2000-12-19 0001095811-00-005368 — 5
- 2000-11-15 0001095811-00-004830 — 5
- 2000-11-15 0001095811-00-004824 — 5
- 2000-11-13 0000891618-00-005023 — 5
- 2000-11-07 0001095811-00-004387 — 5, 7
- 2000-11-06 0001095811-00-004318 — 5
- 2000-09-29 0000891618-00-004739 — 5, 7
- 2000-09-28 0000891618-00-004722 — 5
- 2000-09-26 0001095811-00-003573 — 5
- 2000-09-15 0001095811-00-003413 — 5
- 2000-09-07 0001095811-00-003229 — 5
- 2000-08-15 0000891618-00-004430 — 5
- 2000-08-04 0001095811-00-002304 — 5, 7 — amendment, the index does not say of what
- 2000-07-28 0000891618-00-004132 — 5, 7
- 2000-06-29 0000891618-00-003637 — 5
- 2000-06-07 0000891618-00-003209 — 5
- 2000-05-26 0000891618-00-003054 — 5
- 2000-05-18 0000891618-00-002975 — 5, 7
- 2000-05-15 0000891618-00-002808 — 5, 7
- 2000-05-03 0000891618-00-002473 — 5
- 2000-04-03 0000891618-00-001936 — 5
- 2000-03-28 0000891618-00-001763 — 5
- 2000-03-27 0000891618-00-001722 — 5, 7
- 2000-03-16 0000891618-00-001512 — 5
- 2000-02-17 0000891618-00-001024 — 5, 7
- 2000-02-03 0000891618-00-000468 — 7 — amendment of 0000891618-99-005685
- 1999-12-22 0000891618-99-005792 — 5, 7
- 1999-12-15 0000891618-99-005685 — 5, 7
- 1999-11-17 0000891618-99-005313 — 5, 7
- 1999-11-04 0000891618-99-004862 — 5, 7
- 1999-10-20 0000891618-99-004625 — 5, 7
- 1999-09-27 0000891618-99-004333 — 5, 7
- 1999-08-26 0000891618-99-003978 — 5, 7
- 1999-08-13 0000891618-99-003764 — 5, 7 — amendment of 0000891618-99-003749
- 1999-08-13 0000891618-99-003749 — 5, 7
- 1999-07-02 0000891618-99-002980 — 5, 7
- 1999-05-14 0000891618-99-002221 — 5
- 1998-11-20 0000891618-98-005074 — 5, 7
- 1998-11-20 0000891618-98-005073 — 5, 7
- 1998-10-13 0000891618-98-004462 — 5, 7
- 1998-07-09 0000891618-98-003245 — 5, 7
- 1998-06-11 0000891618-98-002832 — 5, 7
- 1998-05-15 0000891618-98-002457 — 5, 7
- 1998-04-29 0000891618-98-001996 — 5
- 1998-02-11 0000891618-98-000584 — 5, 7
- 1997-09-09 0000891618-97-003723 — 5, 7
- 1997-08-22 0000891618-97-003559 — 5, 7
- 1997-07-01 0000891618-97-002807 — 5, 7
- 1997-01-22 0000891618-97-000120 — 5, 7
- 1996-10-15 0000891618-96-002283 — 5, 7 — amendment of 0000891618-96-002217
- 1996-10-01 0000891618-96-002217 — 5, 7
- 1996-07-23 0000891618-96-001305 — 2, 7
- 1996-04-26 0000891618-96-000253 — 2
- 1996-04-02 0000898430-96-001187 — 2, 7
- 1995-12-06 0000891618-95-000728 — 2, 7
- 1995-12-06 0000891618-95-000727 — 2, 7

## late-filing notifications on or before 2015-09-08

- none on or before 2015-09-08

## item 2.02 — earnings release, exhibit 99.1

[0001193125-15-288099:8k_2_02:1]
EX-99.1
2
d24897dex991.htm
EX-99.1

[0001193125-15-288099:8k_2_02:2]
EX-99.1

[0001193125-15-288099:8k_2_02:3]
Exhibit 99.1

[0001193125-15-288099:8k_2_02:4]
| Press Contact: |  | Investor Relations Contact: |
| Robyn Jenkins-Blum |  | Marilyn Mora |
| Cisco |  | Cisco |
| 1 (408) 853-9848 |  | 1 (408) 527-7452 |
| rojenkin@cisco.com |  | marilmor@cisco.com |

[0001193125-15-288099:8k_2_02:5]
CISCO REPORTS FOURTH QUARTER AND FISCAL YEAR 2015 EARNINGS

[0001193125-15-288099:8k_2_02:6]
Record Revenues and Non-GAAP EPS Reflect Strong Execution and Momentum

[0001193125-15-288099:8k_2_02:7]
|  | • |  | Q4 Revenue: $12.8 billion (increase of 4% year over year) |

[0001193125-15-288099:8k_2_02:8]
|  | • |  | Q4 Earnings per Share: $0.45 GAAP; $0.59 non-GAAP |

[0001193125-15-288099:8k_2_02:9]
|  | • |  | FY 2015 Revenue: $49.2 billion (increase of 4% year over year) |

[0001193125-15-288099:8k_2_02:10]
|  | • |  | FY 2015 Earnings per Share: $1.75 GAAP; $2.21 non-GAAP |

[0001193125-15-288099:8k_2_02:11]
|  | • |  | Q1 FY 2016 Revenue Guidance: 2% - 4% growth year over year |

[0001193125-15-288099:8k_2_02:12]
|  | • |  | Q1 FY 2016 non-GAAP Earnings per Share Guidance: $0.55 - $0.57 |

[0001193125-15-288099:8k_2_02:13]
SAN JOSE, Calif. — August 12,
2015 — Cisco, the worldwide leader in networking that transforms how people connect, communicate and collaborate, today reported its fourth quarter and fiscal year results for the period ended July 25, 2015. Cisco reported fourth quarter
revenue of $12.8 billion, net income on a generally accepted accounting principles (GAAP) basis of $2.3 billion or $0.45 per share, and non-GAAP net income of $3.0 billion or $0.59 per share.

[0001193125-15-288099:8k_2_02:14]
“I’m stepping into the CEO role at an incredibly exciting time for Cisco. We closed out our fiscal year with record revenues and record non-GAAP
EPS, for both Q4 and FY15. I’m particularly pleased with the strong growth of deferred revenue which shows we are very effectively driving our business to a more predictable software-based business model, at the same time as growing revenues
and earnings,” said Chuck Robbins, Cisco chief executive officer.

[0001193125-15-288099:8k_2_02:15]
“These strong results show what we are capable of when we’re focused,
and you can expect us to continue to drive the evolution of our portfolio to maximize the value we bring to customers in today’s rapidly changing market. The network’s strategic role at the center of everything becoming digital –
today and in the future – is why I strongly believe Cisco’s best years are ahead of us.”

[0001193125-15-288099:8k_2_02:16]
Q4 GAAP Results

[0001193125-15-288099:8k_2_02:17]
|  |  | Q4 2015 |  |  | Q4 2014 |  |  | Vs. Q4 2014 |  |
| Revenue |  | $ | 12.8 billion |  |  | $ | 12.4 billion |  |  |  | 3.9% |  |
| Net Income |  | $ | 2.3 billion |  |  | $ | 2.2 billion |  |  |  | 3.2% |  |
| Diluted Earnings per Share (EPS) |  | $ | 0.45 |  |  | $ | 0.43 |  |  |  | 4.7% |  |

[0001193125-15-288099:8k_2_02:18]
Q4 Non-GAAP Results

[0001193125-15-288099:8k_2_02:19]
|  |  | Q4 2015 |  |  | Q4 2014 |  |  | Vs. Q4 2014 |  |
| Net Income |  | $ | 3.0 billion |  |  | $ | 2.8 billion |  |  |  | 6.2% |  |
| EPS |  | $ | 0.59 |  |  | $ | 0.55 |  |  |  | 7.3% |  |

[0001193125-15-288099:8k_2_02:20]
Fiscal Year GAAP Results

[0001193125-15-288099:8k_2_02:21]
|  |  | FY 2015 |  |  | FY 2014 |  |  | Vs. FY 2014 |  |
| Revenue |  | $ | 49.2 billion |  |  | $ | 47.1 billion |  |  |  | 4.3% |  |
| Net Income |  | $ | 9.0 billion |  |  | $ | 7.9 billion |  |  |  | 14.4% |  |
| EPS |  | $ | 1.75 |  |  | $ | 1.49 |  |  |  | 17.4% |  |

[0001193125-15-288099:8k_2_02:22]
Fiscal Year Non-GAAP Results

[0001193125-15-288099:8k_2_02:23]
|  |  | FY 2015 |  |  | FY 2014 |  |  | Vs. FY 2014 |  |
| Net Income |  | $ | 11.4 billion |  |  | $ | 10.9 billion |  |  |  | 4.5% |  |
| EPS |  | $ | 2.21 |  |  | $ | 2.06 |  |  |  | 7.3% |  |

[0001193125-15-288099:8k_2_02:24]
A reconciliation between net income and EPS on a GAAP and non-GAAP basis is provided in the table following the Consolidated
Statements of Operations. Supplementary information related to other GAAP and non-GAAP measures is also provided in the tables below.

[0001193125-15-288099:8k_2_02:25]
1

[0001193125-15-288099:8k_2_02:26]
Financial Summary

[0001193125-15-288099:8k_2_02:27]
(All comparative percentages are on a year-over-year basis unless otherwise noted)

[0001193125-15-288099:8k_2_02:28]
Q4 2015 Highlights

[0001193125-15-288099:8k_2_02:29]
Revenue —
Total revenue was $12.8 billion, up 4%. Product revenue and service revenue each increased 4%. In terms of total revenue by geographic segment, Americas was up 7%, while both EMEA and APJC were flat. Product revenue growth was led by
Collaboration and Data Center at 14% each. Switching and NGN Routing grew by 2% and 3%, respectively.

[0001193125-15-288099:8k_2_02:30]
Gross Margin — On
a non-GAAP basis, total gross margin and product gross margin were 62.1% and 61.0% respectively. The decrease in non-GAAP product gross margin as compared to the third quarter of fiscal 2015 was driven by pricing and product mix partially offset by
productivity. Non-GAAP service gross margin was 65.9%. Total gross margins by geographic segment were: 62.7% for the Americas, 62.1% for EMEA, and 59.5% for APJC. On a GAAP basis, total gross margin, product gross margin, and service gross margin
were at 60.2%, 59.0% and 64.5%, respectively.

[0001193125-15-288099:8k_2_02:31]
Operating Expenses — Non-GAAP operating expenses were $4.2 billion, up 1%.
Headcount increased from the third quarter of fiscal 2015 by approximately 900 to 71,833 reflecting investments in key growth areas such as security, cloud and software. On a GAAP basis, operating expenses were $4.9 billion, up 3%.

[0001193125-15-288099:8k_2_02:32]
Operating Income — Non-GAAP operating income was $3.8 billion, up 9%, with non-GAAP operating margin at 29.3%. GAAP operating
income was $2.9 billion, up 7%, with GAAP operating margin of 22.4%.

[0001193125-15-288099:8k_2_02:33]
Provision for Income Taxes — The non-GAAP tax
provision rate was 21.0% for the fourth quarter of fiscal 2015 reflecting fiscal year end true-ups. The GAAP tax provision rate was 20.9%.

[0001193125-15-288099:8k_2_02:34]
Net Income and EPS — On a non-GAAP basis, net income was $3.0 billion, an increase of 6%, and EPS was $0.59, an increase of 7%. On a GAAP
basis, net income was $2.3 billion and EPS was $0.45.

[0001193125-15-288099:8k_2_02:35]
Cash Flow from Operating Activities — was $4.1 billion for the
fourth quarter of fiscal 2015, compared with $3.0 billion for the third quarter of fiscal 2015, and compared with $3.6 billion for the fourth quarter of fiscal 2014.

[0001193125-15-288099:8k_2_02:36]
Fiscal 2015 Highlights

[0001193125-15-288099:8k_2_02:37]
Revenue —
Total revenue was $49.2 billion, an increase of 4%.

[0001193125-15-288099:8k_2_02:38]
Net Income and EPS — On a non-GAAP basis, net income was
$11.4 billion, an increase of 5%, and EPS was $2.21, an increase of 7%. On a GAAP basis, net income was $9.0 billion and EPS was $1.75.

[0001193125-15-288099:8k_2_02:39]
Cash Flow from Operating Activities — was $12.6 billion for fiscal 2015, compared with $12.3 billion for fiscal 2014.

[0001193125-15-288099:8k_2_02:40]
Cash and Cash Equivalents and Investments — were $60.4 billion at the end of the fourth quarter of fiscal 2015, compared with $54.4 billion
at the end of the third quarter of fiscal 2015, and compared with $52.1 billion at the end of the fourth quarter of fiscal 2014. $7.0 billion of cash and cash equivalents and investments was available in the United States at the end of the fourth
quarter of fiscal 2015.

[0001193125-15-288099:8k_2_02:41]
Deferred Revenue — was $15.2 billion, up 7% in total. Product deferred revenue grew in
double-digits again in the fourth quarter of fiscal 2015 at 21%, driven largely by subscription based and software offerings, while services deferred revenue grew 1%. Cisco continued to build a greater mix of recurring revenue as reflected in
deferred revenue.

[0001193125-15-288099:8k_2_02:42]
Product Backlog — was approximately $5.1 billion at the end of fiscal 2015 as compared to
approximately $5.4 billion at the end of fiscal 2014.

[0001193125-15-288099:8k_2_02:43]
Days Sales Outstanding in Accounts Receivable (DSO) — was 38 days
at the end of the fourth quarter of fiscal 2015 consistent with the fourth quarter of fiscal 2014.

[0001193125-15-288099:8k_2_02:44]
Capital Allocation

[0001193125-15-288099:8k_2_02:45]
In the fourth quarter of fiscal 2015, Cisco declared and paid a cash dividend of $0.21 per common share, or $1.1 billion. For the full fiscal year, Cisco
declared and paid cash dividends of $0.80 per common share, or $4.1 billion.

[0001193125-15-288099:8k_2_02:46]
For the fourth quarter of fiscal 2015, Cisco repurchased approximately
35 million shares of common stock under its stock repurchase program at an average price of $28.62 per share for an aggregate purchase price of $1.0 billion. For the full fiscal year, Cisco repurchased approximately 155 million shares of
common stock under its stock repurchase program at an average price of $27.22 per share for an aggregate purchase price of $4.2 billion. As of July 25, 2015, Cisco had repurchased and retired 4.4 billion shares of Cisco common stock at an
average price of $20.86 per share for an aggregate purchase price of approximately $92.7 billion since the inception of the stock repurchase program. The remaining authorized amount for stock repurchases under this program is approximately $4.3
billion with no termination date.

[0001193125-15-288099:8k_2_02:47]
2

[0001193125-15-288099:8k_2_02:48]
For the full fiscal year, Cisco returned $8.3 billion to shareholders through share buybacks and dividends, which
represented 73% of free cash flow.

[0001193125-15-288099:8k_2_02:49]
“We ended this year with another strong quarter. We saw good top line growth in Q4 with record revenue of $12.8
billion, a 4% increase for the quarter bringing our full year 2015 revenue to $49.2 billion – also growth of 4%,” said Kelly Kramer, Cisco executive vice president and chief financial officer. “I am pleased with our
execution on our financial strategy of delivering profitable growth, managing our portfolio and strategic investments, and delivering shareholder value.”

[0001193125-15-288099:8k_2_02:50]
Acquisitions and Divestitures

[0001193125-15-288099:8k_2_02:51]
In the fourth quarter of
fiscal 2015, we announced an agreement to sell the client premises equipment portion of our Service Provider Video connected devices unit to French-based Technicolor for approximately $600 million in cash and stock, subject to certain adjustments.
We will continue to refocus our investments in service provider video towards cloud and software-based services. We expect the transaction to close at the end of the second quarter of fiscal 2016 subject to regulatory approvals.

[0001193125-15-288099:8k_2_02:52]
During the quarter, Cisco also announced its intent to acquire the cloud-based security company OpenDNS to enhance the security portfolio and, along with
this, Cisco announced one additional acquisition and closed two acquisitions to further complement the software, collaboration and cloud offerings.

[0001193125-15-288099:8k_2_02:53]
Business Outlook for the First Quarter of Fiscal Year 2016

[0001193125-15-288099:8k_2_02:54]
Cisco expects to achieve the following results for the first quarter of fiscal year 2016:

[0001193125-15-288099:8k_2_02:55]
| Q1 2016 |  |  |
| Revenue |  | 2% - 4% growth Y/Y |
| Non-GAAP gross margin rate |  | 61% - 62% |
| Non-GAAP operating margin rate |  | 28% - 29% |
| Non-GAAP tax provision rate |  | 23% |
| Non-GAAP EPS |  | $0.55 - $0.57 |

[0001193125-15-288099:8k_2_02:56]
Cisco estimates that GAAP EPS will be lower than non-GAAP EPS by $0.11 to $0.15 cents per share in the first quarter of fiscal
2016 as follows:

[0001193125-15-288099:8k_2_02:57]
| Q1 2016 |  |  |  |
| Share-based compensation expense |  | $ | 0.05 - $0.06 |  |
| Amortization of purchased intangible assets and other acquisition-related/divestiture costs |  |  | 0.04 - 0.06 |  |
| Subtotal |  |  | 0.09 - 0.12 |  |
| Restructuring and other charges |  |  | 0.02 - 0.03 |  |
| Total |  | $ | 0.11 - $0.15 |  |

[0001193125-15-288099:8k_2_02:58]
Share-based compensation expense is expected to impact Cisco’s results of operations in similar proportions as the fourth
quarter of fiscal 2015. Amortization of purchased intangible assets, and other acquisition-related/divestiture costs will be reported as GAAP operating expenses, cost of sales, or other income/(loss) as applicable.

[0001193125-15-288099:8k_2_02:59]
The range for restructuring and other charges includes a pretax charge of up to $200 million as a result of the restructuring that Cisco announced in August
2014. During the fourth quarter of fiscal 2015, Cisco recognized pretax restructuring charges of $78 million to the GAAP financial statements related to these actions and expects that the total charges related to these actions will be approximately
$700 million for the total restructuring plan.

[0001193125-15-288099:8k_2_02:60]
This guidance does not include the effects of any future acquisitions/divestitures, asset impairments,
restructurings, and tax or other events, which may or may not be significant.

[0001193125-15-288099:8k_2_02:61]
Editor’s Notes:

[0001193125-15-288099:8k_2_02:62]
|  | • |  | The Q4 and fiscal year 2015 conference call to discuss Cisco’s results along with its business outlook will be held on Wednesday, August 12, 2015 at 1:30 p.m. Pacific Time. Conference call number is 1-888-848-6507 (United States) or 1-212-519-0847 (international). |

[0001193125-15-288099:8k_2_02:63]
|  | • |  | Conference call replay will be available from 4:00 p.m. Pacific Time, August 12, 2015 to 4:00 p.m. Pacific Time, on August 19, 2015 at 1-866-465-1308 (United States) or 1-203-369-1425 (international). The replay will also be available via webcast from August 12, 2015 through October 16, 2015 on the Cisco Investor Relations website at http://investor.cisco.com. |

[0001193125-15-288099:8k_2_02:64]
3

[0001193125-15-288099:8k_2_02:65]
|  | • |  | Additional information regarding Cisco’s financials, as well as a webcast of the conference call with visuals designed to guide participants through the call, will be available at 1:30 p.m. Pacific Time, August 12, 2015. Text of the conference call’s prepared remarks will be available within 24 hours of completion of the call. The webcast will include both the prepared remarks and the question-and-answer session. This information, along with the GAAP to non-GAAP reconciliation information, will be available on the Cisco Investor Relations website at http://investor.cisco.com. |

[0001193125-15-288099:8k_2_02:66]
4

[0001193125-15-288099:8k_2_02:67]
CISCO SYSTEMS, INC.

[0001193125-15-288099:8k_2_02:68]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-15-288099:8k_2_02:69]
(In millions, except per-share amounts)

[0001193125-15-288099:8k_2_02:70]
(Unaudited)

[0001193125-15-288099:8k_2_02:71]
|  |  | Three Months Ended |  |  | Fiscal Year Ended |  |
|  |  | July 25,2015 |  |  | July 26,2014 |  |  | July 25,2015 |  |  | July 26,2014 |  |
| REVENUE: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 9,911 |  |  | $ | 9,532 |  |  | $ | 37,750 |  |  | $ | 36,172 |  |
| Service |  |  | 2,932 |  |  |  | 2,825 |  |  |  | 11,411 |  |  |  | 10,970 |  |
| Total revenue |  |  | 12,843 |  |  |  | 12,357 |  |  |  | 49,161 |  |  |  | 47,142 |  |
| COST OF SALES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 4,068 |  |  |  | 3,976 |  |  |  | 15,377 |  |  |  | 15,641 |  |
| Service |  |  | 1,042 |  |  |  | 976 |  |  |  | 4,103 |  |  |  | 3,732 |  |
| Total cost of sales |  |  | 5,110 |  |  |  | 4,952 |  |  |  | 19,480 |  |  |  | 19,373 |  |
| GROSS MARGIN |  |  | 7,733 |  |  |  | 7,405 |  |  |  | 29,681 |  |  |  | 27,769 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 1,548 |  |  |  | 1,593 |  |  |  | 6,207 |  |  |  | 6,294 |  |
| Sales and marketing |  |  | 2,549 |  |  |  | 2,473 |  |  |  | 9,821 |  |  |  | 9,503 |  |
| General and administrative |  |  | 536 |  |  |  | 508 |  |  |  | 2,040 |  |  |  | 1,934 |  |
| Amortization of purchased intangible assets |  |  | 146 |  |  |  | 68 |  |  |  | 359 |  |  |  | 275 |  |
| Restructuring and other charges |  |  | 73 |  |  |  | 82 |  |  |  | 484 |  |  |  | 418 |  |
| Total operating expenses |  |  | 4,852 |  |  |  | 4,724 |  |  |  | 18,911 |  |  |  | 18,424 |  |
| OPERATING INCOME |  |  | 2,881 |  |  |  | 2,681 |  |  |  | 10,770 |  |  |  | 9,345 |  |
| Interest income |  |  | 211 |  |  |  | 183 |  |  |  | 769 |  |  |  | 691 |  |
| Interest expense |  |  | (149 | ) |  |  | (142 | ) |  |  | (566 | ) |  |  | (564 | ) |
| Other income (loss), net |  |  | (10 | ) |  |  | 56 |  |  |  | 228 |  |  |  | 243 |  |
| Interest and other income (loss), net |  |  | 52 |  |  |  | 97 |  |  |  | 431 |  |  |  | 370 |  |
| INCOME BEFORE PROVISION FOR INCOME TAXES |  |  | 2,933 |  |  |  | 2,778 |  |  |  | 11,201 |  |  |  | 9,715 |  |
| Provision for income taxes |  |  | 614 |  |  |  | 531 |  |  |  | 2,220 |  |  |  | 1,862 |  |
| NET INCOME |  | $ | 2,319 |  |  | $ | 2,247 |  |  | $ | 8,981 |  |  | $ | 7,853 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.46 |  |  | $ | 0.44 |  |  | $ | 1.76 |  |  | $ | 1.50 |  |
| Diluted |  | $ | 0.45 |  |  | $ | 0.43 |  |  | $ | 1.75 |  |  | $ | 1.49 |  |
| Shares used in per-share calculation: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 5,086 |  |  |  | 5,121 |  |  |  | 5,104 |  |  |  | 5,234 |  |
| Diluted |  |  | 5,131 |  |  |  | 5,172 |  |  |  | 5,146 |  |  |  | 5,281 |  |
| Cash dividends declared per common share |  | $ | 0.21 |  |  | $ | 0.19 |  |  | $ | 0.80 |  |  | $ | 0.72 |  |

[0001193125-15-288099:8k_2_02:72]
5

[0001193125-15-288099:8k_2_02:73]
CISCO SYSTEMS, INC.

[0001193125-15-288099:8k_2_02:74]
RECONCILIATION OF GAAP TO NON-GAAP NET INCOME

[0001193125-15-288099:8k_2_02:75]
(In millions, except per-share amounts)

[0001193125-15-288099:8k_2_02:76]
|  |  | Three Months Ended |  |  | Fiscal Year Ended |  |
|  |  | July 25,2015 |  |  | July 26,2014 |  |  | July 25,2015 |  |  | July 26,2014 |  |
| GAAP net income |  | $ | 2,319 |  |  | $ | 2,247 |  |  | $ | 8,981 |  |  | $ | 7,853 |  |
| Adjustments to cost of sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 58 |  |  |  | 49 |  |  |  | 207 |  |  |  | 195 |  |
| Amortization of acquisition-related intangible assets |  |  | 179 |  |  |  | 180 |  |  |  | 765 |  |  |  | 710 |  |
| Supplier component remediation charge (adjustment) |  |  | — |  |  |  | — |  |  |  | (164 | ) |  |  | 655 |  |
| Rockstar patent portfolio charge |  |  | — |  |  |  | — |  |  |  | 188 |  |  |  | — |  |
| Acquisition-related/divestiture costs |  |  | — |  |  |  | 1 |  |  |  | — |  |  |  | 2 |  |
| Significant asset impairments and restructurings |  |  | 5 |  |  |  | — |  |  |  | 5 |  |  |  | — |  |
| Total adjustments to GAAP cost of sales |  |  | 242 |  |  |  | 230 |  |  |  | 1,001 |  |  |  | 1,562 |  |
| Adjustments to operating expenses: |  |  |  |  |
| Share-based compensation expense |  |  | 338 |  |  |  | 291 |  |  |  | 1,235 |  |  |  | 1,158 |  |
| Amortization of acquisition-related intangible assets |  |  | 146 |  |  |  | 68 |  |  |  | 359 |  |  |  | 275 |  |
| Acquisition-related/divestiture costs |  |  | 79 |  |  |  | 102 |  |  |  | 351 |  |  |  | 585 |  |
| Significant asset impairments and restructurings |  |  | 73 |  |  |  | 82 |  |  |  | 484 |  |  |  | 418 |  |
| Total adjustments to GAAP operating expenses |  |  | 636 |  |  |  | 543 |  |  |  | 2,429 |  |  |  | 2,436 |  |
| Adjustments to other income (loss), net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Gain on VCE reorganization |  |  | — |  |  |  | — |  |  |  | (126 | ) |  |  | — |  |
| Total adjustments to GAAP income before provision for income taxes |  |  | 878 |  |  |  | 773 |  |  |  | 3,304 |  |  |  | 3,998 |  |
| Income tax effect of non-GAAP adjustments |  |  | (185 | ) |  |  | (185 | ) |  |  | (731 | ) |  |  | (834 | ) |
| Significant tax matters |  |  | — |  |  |  | — |  |  |  | (200 | ) |  |  | (154 | ) |
| Total adjustments to GAAP provision for income taxes |  |  | (185 | ) |  |  | (185 | ) |  |  | (931 | ) |  |  | (988 | ) |
| Non-GAAP net income |  | $ | 3,012 |  |  | $ | 2,835 |  |  | $ | 11,354 |  |  | $ | 10,863 |  |
| Diluted net income per share: |  |  |  |  |
| GAAP |  | $ | 0.45 |  |  | $ | 0.43 |  |  | $ | 1.75 |  |  | $ | 1.49 |  |
| Non-GAAP |  | $ | 0.59 |  |  | $ | 0.55 |  |  | $ | 2.21 |  |  | $ | 2.06 |  |

[0001193125-15-288099:8k_2_02:77]
CISCO SYSTEMS, INC.

[0001193125-15-288099:8k_2_02:78]
REVENUE BY SEGMENT

[0001193125-15-288099:8k_2_02:79]
(In
millions, except percentages)

[0001193125-15-288099:8k_2_02:80]
|  |  | July 25, 2015 |  |
|  |  | Three Months Ended |  |  | Fiscal Year Ended |  |
|  |  | Amount |  |  | Y/Y % |  |  | Amount |  |  | Y/Y % |  |
| Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 7,801 |  |  |  | 7 | % |  | $ | 29,655 |  |  |  | 7 | % |
| EMEA |  |  | 3,110 |  |  |  | — | % |  |  | 12,322 |  |  |  | 3 | % |
| APJC |  |  | 1,932 |  |  |  | — | % |  |  | 7,184 |  |  |  | (2 | )% |
| Total |  | $ | 12,843 |  |  |  | 4 | % |  | $ | 49,161 |  |  |  | 4 | % |

[0001193125-15-288099:8k_2_02:81]
CISCO SYSTEMS, INC.

[0001193125-15-288099:8k_2_02:82]
GROSS MARGIN PERCENTAGE BY SEGMENT

[0001193125-15-288099:8k_2_02:83]
(In percentages)

[0001193125-15-288099:8k_2_02:84]
|  |  | July 25, 2015 |  |
|  |  | Three Months Ended |  |  | Fiscal Year Ended |  |
| Gross Margin Percentage |  |  |  |  |  |  |  |  |
| Americas |  |  | 62.7 | % |  |  | 63.0 | % |
| EMEA |  |  | 62.1 | % |  |  | 62.5 | % |
| APJC |  |  | 59.5 | % |  |  | 60.0 | % |

[0001193125-15-288099:8k_2_02:85]
CISCO SYSTEMS, INC.

[0001193125-15-288099:8k_2_02:86]
REVENUE FOR GROUPS OF SIMILAR PRODUCTS AND SERVICES

[0001193125-15-288099:8k_2_02:87]
(In millions, except percentages)

[0001193125-15-288099:8k_2_02:88]
|  |  | July 25, 2015 |  |
|  |  | Three Months Ended |  |  | Fiscal Year Ended |  |
|  |  | Amount |  |  | Y/Y % |  |  | Amount |  |  | Y/Y % |  |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Switching |  | $ | 3,719 |  |  |  | 2 | % |  | $ | 14,741 |  |  |  | 5 | % |
| NGN Routing |  |  | 1,992 |  |  |  | 3 | % |  |  | 7,704 |  |  |  | 1 | % |
| Collaboration |  |  | 1,088 |  |  |  | 14 | % |  |  | 4,000 |  |  |  | 5 | % |
| Service Provider Video |  |  | 994 |  |  |  | (7 | )% |  |  | 3,555 |  |  |  | (10 | )% |
| Data Center |  |  | 880 |  |  |  | 14 | % |  |  | 3,220 |  |  |  | 22 | % |
| Wireless |  |  | 715 |  |  |  | 7 | % |  |  | 2,542 |  |  |  | 11 | % |
| Security |  |  | 464 |  |  |  | 4 | % |  |  | 1,747 |  |  |  | 12 | % |
| Other |  |  | 59 |  |  |  | (3 | )% |  |  | 241 |  |  |  | (14 | )% |
| Product |  |  | 9,911 |  |  |  | 4 | % |  |  | 37,750 |  |  |  | 4 | % |
| Service |  |  | 2,932 |  |  |  | 4 | % |  |  | 11,411 |  |  |  | 4 | % |
| Total |  | $ | 12,843 |  |  |  | 4 | % |  | $ | 49,161 |  |  |  | 4 | % |

[0001193125-15-288099:8k_2_02:89]
7

[0001193125-15-288099:8k_2_02:90]
CISCO SYSTEMS, INC.

[0001193125-15-288099:8k_2_02:91]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001193125-15-288099:8k_2_02:92]
(In millions)

[0001193125-15-288099:8k_2_02:93]
(Unaudited)

[0001193125-15-288099:8k_2_02:94]
|  |  | July 25,2015 |  |  | July 26,2014 |  |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 6,877 |  |  | $ | 6,726 |  |
| Investments |  |  | 53,539 |  |  |  | 45,348 |  |
| Accounts receivable, net of allowance for doubtful accounts of $302 at July 25, 2015 and $265 at July 26, 2014 |  |  | 5,344 |  |  |  | 5,157 |  |
| Inventories |  |  | 1,627 |  |  |  | 1,591 |  |
| Financing receivables, net |  |  | 4,491 |  |  |  | 4,153 |  |
| Deferred tax assets |  |  | 2,915 |  |  |  | 2,808 |  |
| Other current assets |  |  | 1,490 |  |  |  | 1,331 |  |
| Total current assets |  |  | 76,283 |  |  |  | 67,114 |  |
| Property and equipment, net |  |  | 3,332 |  |  |  | 3,252 |  |
| Financing receivables, net |  |  | 3,858 |  |  |  | 3,918 |  |
| Goodwill |  |  | 24,469 |  |  |  | 24,239 |  |
| Purchased intangible assets, net |  |  | 2,376 |  |  |  | 3,280 |  |
| Other assets |  |  | 3,163 |  |  |  | 3,267 |  |
| TOTAL ASSETS |  | $ | 113,481 |  |  | $ | 105,070 |  |
| LIABILITIES AND EQUITY |  |  |  |  |
| Current liabilities: |  |  |  |  |
| Short-term debt |  | $ | 3,897 |  |  | $ | 508 |  |
| Accounts payable |  |  | 1,104 |  |  |  | 1,032 |  |
| Income taxes payable |  |  | 62 |  |  |  | 159 |  |
| Accrued compensation |  |  | 3,049 |  |  |  | 3,181 |  |
| Deferred revenue |  |  | 9,824 |  |  |  | 9,478 |  |
| Other current liabilities |  |  | 5,687 |  |  |  | 5,451 |  |
| Total current liabilities |  |  | 23,623 |  |  |  | 19,809 |  |
| Long-term debt |  |  | 21,457 |  |  |  | 20,337 |  |
| Income taxes payable |  |  | 1,876 |  |  |  | 1,851 |  |
| Deferred revenue |  |  | 5,359 |  |  |  | 4,664 |  |
| Other long-term liabilities |  |  | 1,459 |  |  |  | 1,748 |  |
| Total liabilities |  |  | 53,774 |  |  |  | 48,409 |  |
| Total equity |  |  | 59,707 |  |  |  | 56,661 |  |
| TOTAL LIABILITIES AND EQUITY |  | $ | 113,481 |  |  | $ | 105,070 |  |

[0001193125-15-288099:8k_2_02:95]
Certain reclassifications have been made to prior year amounts to conform to the current year’s
presentation.

[0001193125-15-288099:8k_2_02:96]
8

[0001193125-15-288099:8k_2_02:97]
CISCO SYSTEMS, INC.

[0001193125-15-288099:8k_2_02:98]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-15-288099:8k_2_02:99]
(In millions)

[0001193125-15-288099:8k_2_02:100]
(Unaudited)

[0001193125-15-288099:8k_2_02:101]
|  |  | Fiscal Year Ended |  |
|  |  | July 25,2015 |  |  | July 26,2014 |  |
| Cash flows from operating activities: |  |  |  |  |
| Net income |  | $ | 8,981 |  |  | $ | 7,853 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Depreciation, amortization, and other |  |  | 2,442 |  |  |  | 2,439 |  |
| Share-based compensation expense |  |  | 1,440 |  |  |  | 1,348 |  |
| Provision for receivables |  |  | 134 |  |  |  | 79 |  |
| Deferred income taxes |  |  | (23 | ) |  |  | (678 | ) |
| Excess tax benefits from share-based compensation |  |  | (128 | ) |  |  | (118 | ) |
| (Gains) losses on investments and other, net |  |  | (258 | ) |  |  | (299 | ) |
| Change in operating assets and liabilities, net of effects of acquisitions and divestitures: |  |  |  |  |
| Accounts receivable |  |  | (413 | ) |  |  | 340 |  |
| Inventories |  |  | (116 | ) |  |  | (109 | ) |
| Financing receivables |  |  | (634 | ) |  |  | (119 | ) |
| Other assets |  |  | (370 | ) |  |  | 26 |  |
| Accounts payable |  |  | 87 |  |  |  | (23 | ) |
| Income taxes, net |  |  | 53 |  |  |  | 191 |  |
| Accrued compensation |  |  | 7 |  |  |  | (42 | ) |
| Deferred revenue |  |  | 1,275 |  |  |  | 659 |  |
| Other liabilities |  |  | 75 |  |  |  | 785 |  |
| Net cash provided by operating activities |  |  | 12,552 |  |  |  | 12,332 |  |
| Cash flows from investing activities: |  |  |  |  |
| Purchases of investments |  |  | (43,975 | ) |  |  | (36,317 | ) |
| Proceeds from sales of investments |  |  | 20,237 |  |  |  | 18,193 |  |
| Proceeds from maturities of investments |  |  | 15,293 |  |  |  | 15,660 |  |
| Acquisition of businesses, net of cash and cash equivalents acquired |  |  | (326 | ) |  |  | (2,989 | ) |
| Purchases of investments in privately held companies |  |  | (222 | ) |  |  | (384 | ) |
| Return of investments in privately held companies |  |  | 288 |  |  |  | 213 |  |
| Acquisition of property and equipment |  |  | (1,227 | ) |  |  | (1,275 | ) |
| Proceeds from sales of property and equipment |  |  | 22 |  |  |  | 232 |  |
| Other |  |  | (178 | ) |  |  | 24 |  |
| Net cash used in investing activities |  |  | (10,088 | ) |  |  | (6,643 | ) |
| Cash flows from financing activities: |  |  |  |  |
| Issuances of common stock |  |  | 2,016 |  |  |  | 1,907 |  |
| Repurchases of common stock - repurchase program |  |  | (4,324 | ) |  |  | (9,413 | ) |
| Shares repurchased for tax withholdings on vesting of restricted stock units |  |  | (502 | ) |  |  | (430 | ) |
| Short-term borrowings, original maturities less than 90 days, net |  |  | (4 | ) |  |  | (2 | ) |
| Issuances of debt |  |  | 4,981 |  |  |  | 7,981 |  |
| Repayments of debt |  |  | (508 | ) |  |  | (3,276 | ) |
| Excess tax benefits from share-based compensation |  |  | 128 |  |  |  | 118 |  |
| Dividends paid |  |  | (4,086 | ) |  |  | (3,758 | ) |
| Other |  |  | (14 | ) |  |  | (15 | ) |
| Net cash used in financing activities |  |  | (2,313 | ) |  |  | (6,888 | ) |
| Net increase (decrease) in cash and cash equivalents |  |  | 151 |  |  |  | (1,199 | ) |
| Cash and cash equivalents, beginning of fiscal year |  |  | 6,726 |  |  |  | 7,925 |  |
| Cash and cash equivalents, end of fiscal year |  | $ | 6,877 |  |  | $ | 6,726 |  |
| Supplemental cash flow information: |  |  |  |  |
| Cash paid for interest |  | $ | 760 |  |  | $ | 682 |  |
| Cash paid for income taxes, net |  | $ | 2,190 |  |  | $ | 2,349 |  |

[0001193125-15-288099:8k_2_02:102]
Certain reclassifications have been made to prior year amounts to conform to the current year’s
presentation.

[0001193125-15-288099:8k_2_02:103]
9

[0001193125-15-288099:8k_2_02:104]
CISCO SYSTEMS, INC.

[0001193125-15-288099:8k_2_02:105]
DEFERRED REVENUE

[0001193125-15-288099:8k_2_02:106]
(In
millions)

[0001193125-15-288099:8k_2_02:107]
|  |  | July 25,2015 |  |  | April 25,2015 |  |  | July 26,2014 |  |
| Deferred revenue: |  |  |  |  |
| Service |  | $ | 9,757 |  |  | $ | 9,236 |  |  | $ | 9,640 |  |
| Product: |  |  |  |  |
| Unrecognized revenue on product shipments and other deferred revenue |  |  | 4,766 |  |  |  | 4,258 |  |  |  | 3,924 |  |
| Cash receipts related to unrecognized revenue from two-tier distributors |  |  | 660 |  |  |  | 687 |  |  |  | 578 |  |
| Total product deferred revenue |  |  | 5,426 |  |  |  | 4,945 |  |  |  | 4,502 |  |
| Total |  | $ | 15,183 |  |  | $ | 14,181 |  |  | $ | 14,142 |  |
| Reported as: |  |  |  |  |
| Current |  | $ | 9,824 |  |  | $ | 9,371 |  |  | $ | 9,478 |  |
| Noncurrent |  |  | 5,359 |  |  |  | 4,810 |  |  |  | 4,664 |  |
| Total |  | $ | 15,183 |  |  | $ | 14,181 |  |  | $ | 14,142 |  |

[0001193125-15-288099:8k_2_02:108]
CISCO SYSTEMS, INC.

[0001193125-15-288099:8k_2_02:109]
INVENTORIES AND INVENTORY TURNS

[0001193125-15-288099:8k_2_02:110]
(In millions, except annualized inventory turns)

[0001193125-15-288099:8k_2_02:111]
|  |  | July 25,2015 |  |  | April 25,2015 |  |  | July 26,2014 |  |
| Inventories: |  |  |  |  |
| Raw materials |  | $ | 114 |  |  | $ | 264 |  |  | $ | 77 |  |
| Work in process |  |  | 2 |  |  |  | 2 |  |  |  | 5 |  |
| Finished goods: |  |  |  |  |  |  |  |  |  |  |  |  |
| Distributor inventory and deferred cost of sales |  |  | 610 |  |  |  | 635 |  |  |  | 595 |  |
| Manufactured finished goods |  |  | 593 |  |  |  | 547 |  |  |  | 606 |  |
| Total finished goods |  |  | 1,203 |  |  |  | 1,182 |  |  |  | 1,201 |  |
| Service-related spares |  |  | 258 |  |  |  | 268 |  |  |  | 273 |  |
| Demonstration systems |  |  | 50 |  |  |  | 44 |  |  |  | 35 |  |
| Total |  | $ | 1,627 |  |  | $ | 1,760 |  |  | $ | 1,591 |  |
| Annualized inventory turns - GAAP |  |  | 12.1 |  |  |  | 10.1 |  |  |  | 12.7 |  |
| Cost of sales adjustments |  |  | (0.6 | ) |  |  | (0.1 | ) |  |  | (0.6 | ) |
| Annualized inventory turns - non-GAAP |  |  | 11.5 |  |  |  | 10.0 |  |  |  | 12.1 |  |

[0001193125-15-288099:8k_2_02:112]
10

[0001193125-15-288099:8k_2_02:113]
CISCO SYSTEMS, INC.

[0001193125-15-288099:8k_2_02:114]
DIVIDENDS PAID AND REPURCHASES OF COMMON STOCK

[0001193125-15-288099:8k_2_02:115]
(In millions, except per-share amounts)

[0001193125-15-288099:8k_2_02:116]
|  |  | DIVIDENDS |  |  | STOCK REPURCHASE PROGRAM |  |  | TOTAL |  |
| Quarter Ended |  | Per Share |  |  | Amount |  |  | Shares |  |  | Weighted-Average Priceper Share |  |  | Amount |  |  | Amount |  |
| Fiscal 2015 |  |  |  |  |  |  |  |  |
| July 25, 2015 |  | $ | 0.21 |  |  | $ | 1,069 |  |  |  | 35 |  |  | $ | 28.62 |  |  | $ | 1,005 |  |  | $ | 2,074 |  |
| April 25, 2015 |  |  | 0.21 |  |  |  | 1,070 |  |  |  | 35 |  |  |  | 28.39 |  |  |  | 1,008 |  |  |  | 2,078 |  |
| January 24, 2015 |  |  | 0.19 |  |  |  | 974 |  |  |  | 44 |  |  |  | 27.63 |  |  |  | 1,208 |  |  |  | 2,182 |  |
| October 25, 2014 |  |  | 0.19 |  |  |  | 973 |  |  |  | 41 |  |  |  | 24.58 |  |  |  | 1,013 |  |  |  | 1,986 |  |
| Total |  | $ | 0.80 |  |  | $ | 4,086 |  |  |  | 155 |  |  | $ | 27.22 |  |  | $ | 4,234 |  |  | $ | 8,320 |  |
| Fiscal 2014 |  |  |  |  |  |  |  |  |
| July 26, 2014 |  | $ | 0.19 |  |  | $ | 974 |  |  |  | 61 |  |  | $ | 25.11 |  |  | $ | 1,514 |  |  | $ | 2,488 |  |
| April 26, 2014 |  |  | 0.19 |  |  |  | 974 |  |  |  | 90 |  |  |  | 22.24 |  |  |  | 2,005 |  |  |  | 2,979 |  |
| January 25, 2014 |  |  | 0.17 |  |  |  | 896 |  |  |  | 185 |  |  |  | 21.73 |  |  |  | 4,020 |  |  |  | 4,916 |  |
| October 26, 2013 |  |  | 0.17 |  |  |  | 914 |  |  |  | 84 |  |  |  | 23.65 |  |  |  | 2,000 |  |  |  | 2,914 |  |
| Total |  | $ | 0.72 |  |  | $ | 3,758 |  |  |  | 420 |  |  | $ | 22.71 |  |  | $ | 9,539 |  |  | $ | 13,297 |  |

[0001193125-15-288099:8k_2_02:117]
CISCO SYSTEMS, INC.

[0001193125-15-288099:8k_2_02:118]
FREE CASH FLOW

[0001193125-15-288099:8k_2_02:119]
(In
millions)

[0001193125-15-288099:8k_2_02:120]
|  |  | Three Months Ended |  |  | Fiscal Year Ended |  |
|  |  | July 25,2015 |  |  | July 26,2014 |  |  | July 25,2015 |  |  | July 26,2014 |  |
| Net cash provided by operating activities |  | $ | 4,138 |  |  | $ | 3,612 |  |  | $ | 12,552 |  |  | $ | 12,332 |  |
| Acquisition of property and equipment |  |  | (320 | ) |  |  | (325 | ) |  |  | (1,227 | ) |  |  | (1,275 | ) |
| Free cash flow |  | $ | 3,818 |  |  | $ | 3,287 |  |  | $ | 11,325 |  |  | $ | 11,057 |  |

[0001193125-15-288099:8k_2_02:121]
11

[0001193125-15-288099:8k_2_02:122]
CISCO SYSTEMS, INC.

[0001193125-15-288099:8k_2_02:123]
SUPPLEMENTARY INFORMATION - RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-15-288099:8k_2_02:124]
GROSS MARGINS, OPERATING EXPENSES, AND OPERATING MARGINS

[0001193125-15-288099:8k_2_02:125]
(In millions, except percentages)

[0001193125-15-288099:8k_2_02:126]
|  |  | Three Months Ended |  |
|  |  | July 25, 2015 |  |
|  |  | ProductGrossMargin |  |  | ServiceGrossMargin |  |  | TotalGrossMargin |  |  | OperatingExpenses |  |  | Y/Y |  |  | OperatingIncome |  |  | Y/Y |  |
| GAAP amount |  | $ | 5,843 |  |  | $ | 1,890 |  |  | $ | 7,733 |  |  | $ | 4,852 |  |  |  | 3 | % |  | $ | 2,881 |  |  |  | 7 | % |
| GAAP (% of revenue) |  |  | 59.0 | % |  |  | 64.5 | % |  |  | 60.2 | % |  |  | 37.8 | % |  |  |  |  |  |  | 22.4 | % |  |  |  |  |
| Adjustments to GAAP amounts: |  |  |  |  |
| Share-based compensation expense |  |  | 16 |  |  |  | 42 |  |  |  | 58 |  |  |  | 338 |  |  |  |  |  |  |  | 396 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  |  | 179 |  |  |  | — |  |  |  | 179 |  |  |  | 146 |  |  |  |  |  |  |  | 325 |  |  |  |  |  |
| Acquisition-related/divestiture costs |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 79 |  |  |  |  |  |  |  | 79 |  |  |  |  |  |
| Significant asset impairments and restructurings |  |  | 5 |  |  |  | — |  |  |  | 5 |  |  |  | 73 |  |  |  |  |  |  |  | 78 |  |  |  |  |  |
| Non-GAAP amount |  | $ | 6,043 |  |  | $ | 1,932 |  |  | $ | 7,975 |  |  | $ | 4,216 |  |  |  | 1 | % |  | $ | 3,759 |  |  |  | 9 | % |
| Non-GAAP (% of revenue) |  |  | 61.0 | % |  |  | 65.9 | % |  |  | 62.1 | % |  |  | 32.8 | % |  |  |  |  |  |  | 29.3 | % |  |  |  |  |

[0001193125-15-288099:8k_2_02:127]
EFFECTIVE TAX RATE

[0001193125-15-288099:8k_2_02:128]
(In percentages)

[0001193125-15-288099:8k_2_02:129]
|  |  | Three Months Ended |  |  | Fiscal Year Ended |  |
|  |  | July 25,2015 |  |  | July 26,2014 |  |  | July 25,2015 |  |  | July 26,2014 |  |
| GAAP effective tax rate |  |  | 20.9 | % |  |  | 19.1 | % |  |  | 19.8 | % |  |  | 19.2 | % |
| Tax effect of non-GAAP adjustments to net income |  |  | 0.1 | % |  |  | 1.1 | % |  |  | 1.9 | % |  |  | 1.6 | % |
| Non-GAAP effective tax rate |  |  | 21.0 | % |  |  | 20.2 | % |  |  | 21.7 | % |  |  | 20.8 | % |

[0001193125-15-288099:8k_2_02:130]
COST OF SALES USED IN INVENTORY TURNS

[0001193125-15-288099:8k_2_02:131]
(In millions)

[0001193125-15-288099:8k_2_02:132]
|  |  | Three Months Ended |  |
|  |  | July 25,2015 |  |  | April 25,2015 |  |  | July 26,2014 |  |
| GAAP cost of sales |  | $ | 5,110 |  |  | $ | 4,612 |  |  | $ | 4,952 |  |
| Cost of sales adjustments: |  |  |  |  |
| Share-based compensation expense |  |  | (58 | ) |  |  | (56 | ) |  |  | (49 | ) |
| Amortization of acquisition-related intangible assets |  |  | (179 | ) |  |  | (172 | ) |  |  | (180 | ) |
| Supplier component remediation adjustment |  |  | — |  |  |  | 164 |  |  |  | — |  |
| Acquisition-related/divestiture costs |  |  | — |  |  |  | — |  |  |  | (1 | ) |
| Significant asset impairments and restructurings |  |  | (5 | ) |  |  | — |  |  |  | — |  |
| Non-GAAP cost of sales |  | $ | 4,868 |  |  | $ | 4,548 |  |  | $ | 4,722 |  |

[0001193125-15-288099:8k_2_02:133]
12

[0001193125-15-288099:8k_2_02:134]
Forward Looking Statements and Non-GAAP Information

[0001193125-15-288099:8k_2_02:135]
This release includes non-GAAP net income, non-GAAP gross margins, non-GAAP operating expenses, non-GAAP operating income and margin, non-GAAP effective tax
rates, non-GAAP net income per share data, non-GAAP inventory turns and free cash flow for the periods presented. It also includes future estimated ranges for gross margin, operating margin, tax provision rate and EPS on a non-GAAP basis.

[0001193125-15-288099:8k_2_02:136]
These non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with generally accepted accounting principles and
may be different from non-GAAP measures used by other companies. In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles. Cisco believes that non-GAAP measures have limitations in that they do
not reflect all of the amounts associated with Cisco’s results of operations as determined in accordance with GAAP and that these measures should only be used to evaluate Cisco’s results of operations in conjunction with the corresponding
GAAP measures.

[0001193125-15-288099:8k_2_02:137]
Cisco believes that the presentation of non-GAAP measures when shown in conjunction with the corresponding GAAP measures, provides useful
information to investors and management regarding financial and business trends relating to its financial condition and its historical and projected results of operations. In addition, Cisco believes that the presentation of non-GAAP inventory turns
provides useful information to investors and management regarding financial and business trends relating to inventory management based on the operating activities of the periods presented. Cisco believes that the presentation of free cash flow,
which it defines as the net cash provided by operating activities less cash used to acquire property and equipment, to be a liquidity measure that provides useful information to management and investors because of its intent to return a stated
percentage of free cash flow to shareholders in the form of dividends and stock repurchases. Cisco further regards free cash flow as a useful measure because it reflects cash that can be used to, among other things, invest in its business, make
strategic acquisitions, repurchase common stock, and pay dividends on its common stock, after deducting capital investments.

[0001193125-15-288099:8k_2_02:138]
For its internal budgeting
process, Cisco’s management uses financial statements that do not include, when applicable, share-based compensation expense, amortization of acquisition-related intangible assets, impact to cost of sales from purchase accounting adjustments to
inventory, acquisition-related/divestiture costs, significant asset impairments and restructurings,

[0001193125-15-288099:8k_2_02:139]
13

[0001193125-15-288099:8k_2_02:140]
significant litigation and other contingencies, the income tax effects of the foregoing, and significant tax matters. Cisco’s management also uses the foregoing non-GAAP measures, in
addition to the corresponding GAAP measures, in reviewing the financial results of Cisco. In prior periods, Cisco has excluded other items that it no longer excludes for purposes of its non-GAAP financial measures. From time to time in the future
there may be other items that Cisco may exclude for purposes of its internal budgeting process and in reviewing its financial results. For additional information on the items excluded by Cisco from one or more of its non-GAAP financial measures,
refer to the Form 8-K regarding this release furnished today to the Securities and Exchange Commission.

[0001193125-15-288099:8k_2_02:141]
About Cisco

[0001193125-15-288099:8k_2_02:142]
Cisco (NASDAQ: CSCO) is the worldwide leader in IT that helps companies seize the opportunities of tomorrow by proving that amazing things can happen when you
connect the previously unconnected. For ongoing news, please go to http://thenetwork.cisco.com.

[0001193125-15-288099:8k_2_02:143]
Copyright
© 2015 Cisco and/or its affiliates. All rights reserved. Cisco and the Cisco logo are trademarks or registered trademarks of Cisco and/or its affiliates in the U.S. and other countries. To
view a list of Cisco trademarks, go to: www.cisco.com/go/trademarks. Third-party trademarks mentioned in this document are the property of their respective owners. The use of the word partner does not imply a partnership relationship between Cisco
and any other company. This document is Cisco Public Information.

[0001193125-15-288099:8k_2_02:144]
14
