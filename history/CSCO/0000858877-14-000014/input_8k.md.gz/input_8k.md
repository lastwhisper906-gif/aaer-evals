# CSCO 8-K — 0001193125-14-199056 filed 2014-05-14

## item codes, every 8-K on or before 2014-05-22

- 2014-05-14 0001193125-14-199056 — 2.02
- 2014-03-26 0001193125-14-116588 — 8.01
- 2014-03-11 0001193125-14-093805 — 8.01
- 2014-03-03 0001193125-14-079163 — 1.01, 8.01, 9.01
- 2014-02-26 0001193125-14-069912 — 1.01, 9.01
- 2014-02-12 0001193125-14-048150 — 2.02
- 2013-12-23 0001193125-13-483099 — 8.01
- 2013-12-04 0001193125-13-462216 — 8.01
- 2013-11-20 0001193125-13-448477 — 5.02, 5.07, 9.01
- 2013-11-13 0001193125-13-440194 — 2.02
- 2013-08-15 0001193125-13-335218 — 2.05
- 2013-08-14 0001193125-13-334648 — 2.02
- 2013-07-23 0001193125-13-298129 — 8.01, 9.01
- 2013-06-24 0001193125-13-269064 — 8.01
- 2013-06-12 0001193125-13-256194 — 8.01
- 2013-06-07 0001193125-13-250920 — 8.01
- 2013-05-15 0001193125-13-222377 — 2.02
- 2013-03-26 0001193125-13-127015 — 8.01
- 2013-02-13 0001193125-13-055377 — 2.02
- 2013-02-01 0001193125-13-034682 — 5.02
- 2013-01-08 0001193125-13-006886 — 5.02, 9.01
- 2012-12-21 0001193125-12-513130 — 8.01
- 2012-12-19 0001193125-12-508424 — 8.01
- 2012-11-16 0001193125-12-474089 — 5.02, 5.07, 9.01
- 2012-11-13 0001193125-12-467422 — 2.02
- 2012-10-04 0001193125-12-415386 — 5.02, 5.03, 9.01
- 2012-09-19 0001193125-12-396875 — 5.02, 8.01
- 2012-08-15 0001193125-12-357479 — 2.02
- 2012-08-02 0001193125-12-332045 — 5.02
- 2012-06-27 0001193125-12-285742 — 8.01
- 2012-06-13 0001193125-12-269642 — 8.01
- 2012-05-09 0001193125-12-222045 — 2.02
- 2012-03-27 0001193125-12-134384 — 8.01
- 2012-03-15 0001193125-12-117538 — 8.01, 9.01
- 2012-02-17 0001193125-12-067542 — 1.01, 1.02, 2.03, 9.01
- 2012-02-08 0001193125-12-046545 — 2.02
- 2011-12-16 0001193125-11-343995 — 8.01
- 2011-12-08 0001193125-11-335127 — 5.02, 5.07, 9.01
- 2011-11-09 0001193125-11-304587 — 2.02
- 2011-09-29 0001193125-11-260065 — 8.01
- 2011-09-20 0001193125-11-252379 — 5.02, 9.01
- 2011-08-24 0001193125-11-231015 — 8.01
- 2011-08-10 0001193125-11-218133 — 2.02
- 2011-07-18 0001193125-11-190246 — 2.05
- 2011-06-22 0001193125-11-170849 — 8.01
- 2011-05-11 0001193125-11-135913 — 2.02
- 2011-03-28 0001193125-11-079927 — 8.01
- 2011-03-22 0001193125-11-073802 — 5.02 — amendment of 0001193125-11-043592
- 2011-03-18 0001193125-11-071279 — 8.01, 9.01
- 2011-03-16 0001193125-11-067985 — 1.01, 5.02, 8.01, 9.01
- 2011-03-15 0001193125-11-067331 — 1.01, 9.01
- 2011-03-09 0001193125-11-060123 — 8.01, 9.01
- 2011-02-23 0001193125-11-043592 — 5.02
- 2011-02-09 0001193125-11-028987 — 2.02
- 2011-01-31 0001193125-11-019101 — 1.01, 2.03
- 2010-12-17 0001193125-10-283392 — 8.01
- 2010-11-19 0001193125-10-265377 — 5.07
- 2010-11-10 0001193125-10-256001 — 2.02
- 2010-09-22 0001193125-10-214707 — 8.01
- 2010-09-16 0001193125-10-211456 — 7.01
- 2010-08-11 0001193125-10-186042 — 2.02
- 2010-06-29 0001193125-10-149956 — 8.01
- 2010-05-12 0001193125-10-117509 — 2.02
- 2010-02-17 0001193125-10-033290 — 5.02, 8.01, 9.01
- 2010-02-03 0001193125-10-020775 — 2.02
- 2009-11-25 0001193125-09-242589 — 8.01
- 2009-11-17 0001193125-09-236335 — 1.01, 8.01, 9.01
- 2009-11-13 0001193125-09-234405 — 1.01, 2.03, 9.01
- 2009-11-13 0001193125-09-234397 — 5.02 — amendment of 0001193125-09-189511
- 2009-11-12 0001193125-09-232971 — 5.02, 7.01, 9.01
- 2009-11-09 0001193125-09-228541 — 8.01, 9.01
- 2009-11-04 0001193125-09-223763 — 2.02
- 2009-10-14 0001193125-09-207912 — 8.01, 9.01
- 2009-10-05 0001193125-09-203556 — 8.01
- 2009-09-10 0001193125-09-189511 — 5.02
- 2009-09-04 0001193125-09-187835 — 5.02
- 2009-08-05 0001193125-09-165404 — 2.02
- 2009-07-27 0001193125-09-155861 — 5.02
- 2009-05-29 0001193125-09-121672 — 8.01
- 2009-05-06 0001193125-09-101570 — 2.02
- 2009-02-26 0001193125-09-038162 — 5.02
- 2009-02-17 0001193125-09-030546 — 1.01, 8.01, 9.01
- 2009-02-13 0001193125-09-029295 — 1.01, 2.03, 9.01
- 2009-02-04 0001193125-09-018793 — 2.02
- 2008-11-05 0001193125-08-225857 — 2.02
- 2008-09-11 0001193125-08-194695 — 7.01
- 2008-08-05 0001193125-08-166496 — 2.02
- 2008-06-20 0001193125-08-137504 — 8.01
- 2008-05-06 0001193125-08-104089 — 2.02
- 2008-03-21 0001193125-08-062838 — 8.01
- 2008-02-06 0001193125-08-021681 — 2.02
- 2008-01-23 0001193125-08-010589 — 5.02
- 2008-01-04 0001193125-08-001680 — 5.02, 9.01
- 2007-12-21 0001193125-07-269613 — 5.02
- 2007-11-19 0001193125-07-250345 — 5.02 — amendment of 0001193125-07-009285
- 2007-11-19 0001193125-07-250343 — 5.02, 9.01
- 2007-11-07 0001193125-07-238464 — 2.02
- 2007-09-24 0001193125-07-206279 — 8.01
- 2007-09-20 0001193125-07-204616 — 5.02, 7.01
- 2007-09-07 0001193125-07-197514 — 8.01
- 2007-08-17 0001193125-07-185320 — 1.01, 2.03, 9.01
- 2007-08-08 0001193125-07-174077 — 5.02
- 2007-08-07 0001193125-07-173689 — 2.02
- 2007-08-01 0001193125-07-168143 — 5.02
- 2007-05-15 0001193125-07-115800 — 8.01
- 2007-05-08 0001193125-07-106059 — 2.02
- 2007-03-23 0001193125-07-063033 — 5.02, 5.03, 8.01, 9.01
- 2007-03-21 0001193125-07-060631 — 1.01, 9.01
- 2007-02-06 0001193125-07-021349 — 2.02
- 2007-01-19 0001193125-07-009285 — 5.02
- 2006-12-22 0001193125-06-259241 — 8.01
- 2006-11-16 0001193125-06-237260 — 5.03, 8.01, 9.01
- 2006-11-08 0001193125-06-228341 — 2.02
- 2006-09-21 0001193125-06-194890 — 1.01, 7.01
- 2006-09-20 0001193125-06-194063 — 1.01
- 2006-09-15 0001193125-06-191845 — 5.02
- 2006-08-18 0001193125-06-176193 — 5.02
- 2006-08-08 0001193125-06-165719 — 2.02
- 2006-07-31 0001193125-06-157106 — 1.01, 9.01
- 2006-07-31 0001193125-06-157102 — 5.02 — amendment of 0001193125-06-017426
- 2006-06-08 0001193125-06-126879 — 5.02
- 2006-05-18 0001193125-06-115516 — 8.01
- 2006-05-12 0001193125-06-110924 — 9.01 — amendment of 0001193125-06-044013
- 2006-05-09 0001193125-06-105419 — 2.02
- 2006-03-29 0001193125-06-066990 — 1.01
- 2006-03-02 0001193125-06-044013 — 1.01, 2.01, 9.01
- 2006-02-28 0001193125-06-041452 — 1.01
- 2006-02-22 0001193125-06-036759 — 8.01
- 2006-02-22 0001193125-06-036433 — 1.01, 8.01, 9.01
- 2006-02-21 0001193125-06-035865 — 1.01, 2.03, 9.01
- 2006-02-10 0001193125-06-026218 — 8.01, 9.01
- 2006-02-07 0001193125-06-022234 — 2.02
- 2006-02-01 0001193125-06-017426 — 5.02
- 2005-11-18 0001193125-05-229535 — 1.01, 9.01
- 2005-11-16 0001193125-05-227987 — 1.01, 9.01
- 2005-11-16 0001193125-05-227983 — 5.02 — amendment of 0001193125-05-008843
- 2005-11-09 0001193125-05-221610 — 2.02
- 2005-09-29 0001193125-05-194217 — 7.01
- 2005-09-27 0001193125-05-192353 — 8.01
- 2005-09-21 0001193125-05-189234 — 1.01, 9.01
- 2005-09-19 0001193125-05-187646 — 8.01
- 2005-09-09 0001193125-05-183273 — 8.01
- 2005-09-08 0001193125-05-182307 — 1.01
- 2005-08-09 0001193125-05-162626 — 2.02
- 2005-07-15 0001193125-05-142738 — 8.01
- 2005-05-10 0001193125-05-102797 — 2.02
- 2005-03-30 0001193125-05-065123 — 1.01, 3.03, 9.01
- 2005-03-04 0001193125-05-042778 — 1.01
- 2005-02-08 0001193125-05-022181 — 2.02
- 2005-01-20 0001193125-05-008843 — 5.02
- 2004-12-23 0001193125-04-219331 — 8.01
- 2004-11-09 0001193125-04-191303 — 2.02
- 2004-08-23 0001193125-04-145198 — 1.01, 7.01
- 2004-08-19 0001193125-04-143859 — 5
- 2004-08-10 0001193125-04-136865 — 12
- 2004-05-11 0001193125-04-084721 — 12
- 2004-02-03 0001193125-04-013750 — 12
- 2003-11-05 0001193125-03-073418 — 12
- 2003-09-02 0001193125-03-044521 — 9
- 2003-08-05 0001193125-03-029223 — 12, 7
- 2003-07-18 0001193125-03-021155 — 5, 7
- 2003-06-05 0001012870-03-002949 — 5
- 2003-05-06 0000891618-03-002315 — 7, 9
- 2003-04-17 0000891618-03-001894 — 5, 7
- 2003-04-11 0000891618-03-001791 — 9
- 2003-03-20 0000891618-03-001326 — 5, 7
- 2003-02-04 0000891618-03-000518 — 7, 9
- 2003-01-28 0000891618-03-000271 — 5, 7
- 2002-12-27 0000891618-02-005686 — 5, 7
- 2002-10-23 0000891618-02-004715 — 5, 7
- 2002-10-11 0000891618-02-004620 — 5, 7
- 2002-09-18 0000891618-02-004352 — 5, 7
- 2002-08-20 0000891618-02-004001 — 5, 7
- 2002-08-05 0000891618-02-003498 — 5, 7
- 2002-07-03 0000891618-02-003099 — 5, 7
- 2002-05-14 0000891618-02-002407 — 5, 7
- 2002-02-05 0000891618-02-000412 — 5, 7
- 2001-09-28 0001095811-01-505261 — 5, 7
- 2001-09-14 0001095811-01-504917 — 5, 7
- 2001-08-24 0001095811-01-504581 — 5, 7
- 2001-07-30 0001095811-01-503468 — 5, 7
- 2001-07-12 0000891618-01-501567 — 5, 7
- 2001-05-11 0000891618-01-500638 — 5, 7
- 2001-02-27 0000891618-01-500076 — 5, 7
- 2001-02-20 0001095811-01-001530 — 5, 7
- 2001-02-08 0001095811-01-000848 — 5, 7
- 2001-02-07 0001095811-01-000768 — 5
- 2000-12-27 0001095811-00-005511 — 5
- 2000-12-21 0001095811-00-005427 — 5
- 2000-12-19 0001095811-00-005368 — 5
- 2000-11-15 0001095811-00-004830 — 5
- 2000-11-15 0001095811-00-004824 — 5
- 2000-11-13 0000891618-00-005023 — 5
- 2000-11-07 0001095811-00-004387 — 5, 7
- 2000-11-06 0001095811-00-004318 — 5
- 2000-09-29 0000891618-00-004739 — 5, 7
- 2000-09-28 0000891618-00-004722 — 5
- 2000-09-26 0001095811-00-003573 — 5
- 2000-09-15 0001095811-00-003413 — 5
- 2000-09-07 0001095811-00-003229 — 5
- 2000-08-15 0000891618-00-004430 — 5
- 2000-08-04 0001095811-00-002304 — 5, 7 — amendment, the index does not say of what
- 2000-07-28 0000891618-00-004132 — 5, 7
- 2000-06-29 0000891618-00-003637 — 5
- 2000-06-07 0000891618-00-003209 — 5
- 2000-05-26 0000891618-00-003054 — 5
- 2000-05-18 0000891618-00-002975 — 5, 7
- 2000-05-15 0000891618-00-002808 — 5, 7
- 2000-05-03 0000891618-00-002473 — 5
- 2000-04-03 0000891618-00-001936 — 5
- 2000-03-28 0000891618-00-001763 — 5
- 2000-03-27 0000891618-00-001722 — 5, 7
- 2000-03-16 0000891618-00-001512 — 5
- 2000-02-17 0000891618-00-001024 — 5, 7
- 2000-02-03 0000891618-00-000468 — 7 — amendment of 0000891618-99-005685
- 1999-12-22 0000891618-99-005792 — 5, 7
- 1999-12-15 0000891618-99-005685 — 5, 7
- 1999-11-17 0000891618-99-005313 — 5, 7
- 1999-11-04 0000891618-99-004862 — 5, 7
- 1999-10-20 0000891618-99-004625 — 5, 7
- 1999-09-27 0000891618-99-004333 — 5, 7
- 1999-08-26 0000891618-99-003978 — 5, 7
- 1999-08-13 0000891618-99-003764 — 5, 7 — amendment of 0000891618-99-003749
- 1999-08-13 0000891618-99-003749 — 5, 7
- 1999-07-02 0000891618-99-002980 — 5, 7
- 1999-05-14 0000891618-99-002221 — 5
- 1998-11-20 0000891618-98-005074 — 5, 7
- 1998-11-20 0000891618-98-005073 — 5, 7
- 1998-10-13 0000891618-98-004462 — 5, 7
- 1998-07-09 0000891618-98-003245 — 5, 7
- 1998-06-11 0000891618-98-002832 — 5, 7
- 1998-05-15 0000891618-98-002457 — 5, 7
- 1998-04-29 0000891618-98-001996 — 5
- 1998-02-11 0000891618-98-000584 — 5, 7
- 1997-09-09 0000891618-97-003723 — 5, 7
- 1997-08-22 0000891618-97-003559 — 5, 7
- 1997-07-01 0000891618-97-002807 — 5, 7
- 1997-01-22 0000891618-97-000120 — 5, 7
- 1996-10-15 0000891618-96-002283 — 5, 7 — amendment of 0000891618-96-002217
- 1996-10-01 0000891618-96-002217 — 5, 7
- 1996-07-23 0000891618-96-001305 — 2, 7
- 1996-04-26 0000891618-96-000253 — 2
- 1996-04-02 0000898430-96-001187 — 2, 7
- 1995-12-06 0000891618-95-000728 — 2, 7
- 1995-12-06 0000891618-95-000727 — 2, 7

## late-filing notifications on or before 2014-05-22

- none on or before 2014-05-22

## item 2.02 — earnings release, exhibit 99.1

[0001193125-14-199056:8k_2_02:1]
EX-99.1
2
d726707dex991.htm
EX-99.1

[0001193125-14-199056:8k_2_02:2]
EX-99.1

[0001193125-14-199056:8k_2_02:3]
Exhibit 99.1

[0001193125-14-199056:8k_2_02:4]
| Press Contact: |  | Investor Relations Contact: |
| Robyn Jenkins-Blum |  | Marilyn Mora |
| Cisco |  | Cisco |
| 1 (408) 853-9848 |  | 1 (408) 527-7452 |
| rojenkin@cisco.com |  | marilmor@cisco.com |

[0001193125-14-199056:8k_2_02:5]
Cisco Demonstrates Solid Execution in Q3FY14

[0001193125-14-199056:8k_2_02:6]
New Markets and Technologies Drive Plan to Return to Growth

[0001193125-14-199056:8k_2_02:7]
| • |  | Q3 Revenue: $11.5 billion |

[0001193125-14-199056:8k_2_02:8]
| • |  | Q3 Earnings per Share: $0.42 GAAP; $0.51 non-GAAP |

[0001193125-14-199056:8k_2_02:9]
SAN JOSE, Calif. -- May 14, 2014 -- Cisco, the
worldwide leader in networking that transforms how people connect, communicate and collaborate, today reported its third quarter results for the period ended April 26, 2014. Cisco reported third quarter revenue of $11.5 billion, net income on a
generally accepted accounting principles (GAAP) basis of $2.2 billion or $0.42 per share, and non-GAAP net income of $2.6 billion or $0.51 per share.

[0001193125-14-199056:8k_2_02:10]
“I’m pleased with our performance in Q3. Our financial results exceeded the guidance we provided last quarter as we demonstrated clear progress
on returning to growth. The entire team is focused on moving Cisco forward aggressively and we remain confident in our long-term goal to be the #1 IT company,” stated John Chambers, Cisco chairman and chief executive officer.

[0001193125-14-199056:8k_2_02:11]
GAAP Results

[0001193125-14-199056:8k_2_02:12]
|  |  | Q3 2014 |  | Q3 2013 |  | Vs. Q3 2013 |
| Revenue |  | $11.5 billion |  | $12.2 billion |  | (5.5)% |
| Net Income |  | $2.2 billion |  | $2.5 billion |  | (12.0)% |
| Earnings per Share |  | $ 0.42 |  | $ 0.46 |  | (8.7)% |
| Non-GAAP Results |
|  |  | Q3 2014 |  | Q3 2013 |  | Vs. Q3 2013 |
| Net Income |  | $2.6 billion |  | $2.7 billion |  | (3.2)% |
| Earnings per Share |  | $ 0.51 |  | $ 0.51 |  | —% |

[0001193125-14-199056:8k_2_02:13]
Revenue for the first nine months of fiscal 2014 was $34.8 billion, compared with $36.2 billion for the first nine months of
fiscal 2013. Net income for the first nine months of fiscal 2014, on a GAAP basis, was $5.6 billion or $1.06 per share, compared with $7.7 billion or $1.44 per share for the first nine months of fiscal 2013. Non-GAAP net income for the first nine
months of fiscal 2014 was $8.0 billion or $1.51 per share, compared with $8.0 billion or $1.50 per share for the first nine months of fiscal 2013.

[0001193125-14-199056:8k_2_02:14]
A
reconciliation between net income on a GAAP basis and non-GAAP net income is provided in the table following the Consolidated Statements of Operations.

[0001193125-14-199056:8k_2_02:15]
Cisco will discuss third quarter results and business outlook on a conference call and webcast at 1:30 p.m. Pacific Time today. Call information and related
charts are available at http://investor.cisco.com.

[0001193125-14-199056:8k_2_02:16]
Cash and Cash Equivalents and Investments

[0001193125-14-199056:8k_2_02:17]
|  | • |  | Cash flows from operations were $3.2 billion for the third quarter of fiscal 2014, compared with $2.9 billion for the second quarter of fiscal 2014, and compared with $3.1 billion for the third quarter of fiscal 2013. |

[0001193125-14-199056:8k_2_02:18]
1

[0001193125-14-199056:8k_2_02:19]
|  | • |  | Cash and cash equivalents and investments were $50.5 billion at the end of the third quarter of fiscal 2014, compared with $47.1 billion at the end of the second quarter of fiscal 2014, and compared with $50.6 billion at the end of the fourth quarter of fiscal 2013. |

[0001193125-14-199056:8k_2_02:20]
Dividends and Stock Repurchase Program

[0001193125-14-199056:8k_2_02:21]
|  | • |  | Cisco repurchased approximately 90 million shares of common stock under the stock repurchase program at an average price of $22.24 per share for an aggregate purchase price of $2.0 billion during the third quarter of fiscal 2014. As of April 26, 2014, Cisco had repurchased and retired 4.2 billion shares of Cisco common stock at an average price of $20.56 per share for an aggregate purchase price of approximately $86.9 billion since the inception of the stock repurchase program. The remaining authorized amount for stock repurchases under this program as of April 26, 2014 was approximately $10.1 billion with no termination date. |

[0001193125-14-199056:8k_2_02:22]
|  | • |  | During the third quarter of fiscal 2014, Cisco paid a cash dividend of $0.19 per common share, or $974 million. |

[0001193125-14-199056:8k_2_02:23]
“We executed well this quarter with a focus on operational excellence,” stated Frank Calderoni, Cisco executive vice president and
chief financial officer. “Our strong and consistent cash generation demonstrates the value of our business model.”

[0001193125-14-199056:8k_2_02:24]
Internet of Everything

[0001193125-14-199056:8k_2_02:25]
|  | • |  | Cisco announced plans to build the world’s largest global Intercloud for the Internet of Everything (IoE) together with a set of partners, a distributed network and security architecture designed for high-value application workloads, real-time analytics, “near infinite” scalability and full compliance with local data sovereignty laws. |

[0001193125-14-199056:8k_2_02:26]
|  | • |  | Cisco and AGT International announced a Smart City Global Strategic Alliance that plans to deliver the promise of the IoE through edge analytics and cloud technologies that dramatically change the way cities are managed and safeguarded. |

[0001193125-14-199056:8k_2_02:27]
|  | • |  | Cisco selected Toronto as the location for one of four global Cisco® Internet of Everything Innovation Centers, representing a planned investment of up to $100 million over 10 years. |

[0001193125-14-199056:8k_2_02:28]
Next Generation of IT

[0001193125-14-199056:8k_2_02:29]
|  | • |  | Cisco’s Visual Networking Index™ Global Mobile Data Traffic Forecast Update for 2013 to 2018 projects that worldwide mobile data traffic is expected to increase nearly 11-fold over the next four years and reach an annual run rate of 190 exabytes by 2018. |

[0001193125-14-199056:8k_2_02:30]
|  | • |  | Cisco announced it worked with Fira de Barcelona and the GSMA to successfully provide one of the world’s largest carrier-grade Wi-Fi networks at the GSMA’s Mobile World Congress 2014 at Fira Gran Via in Barcelona, underscoring the growing importance of Wi-Fi to cellular. |

[0001193125-14-199056:8k_2_02:31]
|  | • |  | Cisco, AT&T, GE, IBM and Intel announced the formation of the Industrial Internet Consortium™, an open membership group focused on breaking down the barriers of technology silos to support better access to big data with improved integration of the physical and digital worlds. |

[0001193125-14-199056:8k_2_02:32]
|  | • |  | Cisco announced Managed Threat Defense, a managed security solution that applies real-time, predictive analytics designed to detect attacks and protect against advanced malware across customers’ extended networks. |

[0001193125-14-199056:8k_2_02:33]
Innovation

[0001193125-14-199056:8k_2_02:34]
|  | • |  | Cisco extended Application Centric Infrastructure (ACI) by introducing the Cisco Application Policy Infrastructure Controller (APIC) Enterprise Module, which extends to the WAN and access networks. |

[0001193125-14-199056:8k_2_02:35]
|  | • |  | Cisco continued delivering on its vision for fog computing with the announcement of Cisco IOx, transforming the network edge into a distributed computing infrastructure for applications that take advantage of the billions of devices already connected in the Internet of Things (IoT). |

[0001193125-14-199056:8k_2_02:36]
|  | • |  | Cisco announced OpenAppID, allowing for the ability to create and integrate new open source application identification capabilities into its Snort engine. |

[0001193125-14-199056:8k_2_02:37]
|  | • |  | Cisco announced an agreement with CableLabs to provide them with core infrastructure and Videoscape components for a new IPTV Innovations Lab in Louisville, Colorado designed to provide cable system operator members with a state-of-the-art location for Internet Protocol (IP) video testing. |

[0001193125-14-199056:8k_2_02:38]
|  | • |  | Cisco and Sony became the first companies to publicly demonstrate the live delivery of full-frame rate 4K 60P content at NAB 2014. |

[0001193125-14-199056:8k_2_02:39]
2

[0001193125-14-199056:8k_2_02:40]
Editor’s Notes:

[0001193125-14-199056:8k_2_02:41]
|  | • |  | Q3 fiscal year 2014 conference call to discuss Cisco’s results along with its business outlook will be held on Wednesday, May 14, 2014 at 1:30 p.m. Pacific Time. Conference call number is 1-888-848-6507 (United States) or 1-212-519-0847 (international). |

[0001193125-14-199056:8k_2_02:42]
|  | • |  | Conference call replay will be available from 4:00 p.m. Pacific Time on May 14, 2014 to 11:59 p.m. Pacific Time on June 1, 2014 at 1-800-945-7422 (United States) or 1-203-369-3952 (international). The replay will also be available via webcast from May 14, 2014 through July 19, 2014 on the Cisco Investor Relations website at http://investor.cisco.com. |  |

[0001193125-14-199056:8k_2_02:43]
|  | • |  | Additional information regarding Cisco’s financials as well as a webcast of the conference call with visuals designed to guide participants through the call, will be available at 1:30 p.m. Pacific Time, May 14, 2014. Text of the conference call’s prepared remarks will be available within 24 hours of completion of the call. The webcast will include both the prepared remarks and the question-and-answer session. This information, along with GAAP reconciliation information, will be available on the Cisco Investor Relations website at http://investor.cisco.com. |

[0001193125-14-199056:8k_2_02:44]
About Cisco

[0001193125-14-199056:8k_2_02:45]
Cisco (NASDAQ: CSCO) is the worldwide leader in IT that helps companies seize the opportunities of tomorrow by proving that amazing things can happen
when you connect the previously unconnected. For ongoing news, please go to http://thenetwork.cisco.com.

[0001193125-14-199056:8k_2_02:46]
###

[0001193125-14-199056:8k_2_02:47]
This release includes non-GAAP net income, non-GAAP effective tax rates, non-GAAP net income per share data,
non-GAAP inventory turns and free cash flow.

[0001193125-14-199056:8k_2_02:48]
These non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance
with generally accepted accounting principles and may be different from non-GAAP measures used by other companies. In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles. Cisco believes that
non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Cisco’s results of operations as determined in accordance with GAAP and that these measures should only be used to evaluate Cisco’s results
of operations in conjunction with the corresponding GAAP measures.

[0001193125-14-199056:8k_2_02:49]
Cisco believes that the presentation of non-GAAP net income, non-GAAP effective tax
rates, and non-GAAP net income per share data, when shown in conjunction with the corresponding GAAP measures, provides useful information to investors and management regarding financial and business trends relating to its financial condition and
results of operations. In addition, Cisco believes that the presentation of non-GAAP inventory turns provides useful information to investors and management regarding financial and business trends relating to inventory management based on the
operating activities of the periods presented. Cisco believes that the presentation of free cash flow, which it defines as the net cash provided by operating activities less cash used to acquire property and equipment, to be a liquidity measure that
provides useful information to management and investors because of its intent to return a stated percentage of free cash flow to shareholders in the form of dividends and stock repurchases. Cisco further regards free cash flow as a useful measure
because it reflects cash that can be used to, among other things, invest in its business, make strategic acquisitions, repurchase common stock, and pay dividends on its common stock, after deducting capital investments.

[0001193125-14-199056:8k_2_02:50]
For its internal budgeting process, Cisco’s management uses financial statements that do not include, when applicable, share-based compensation expense,
amortization of acquisition-related intangible assets, impact to cost of sales from purchase accounting adjustments to inventory, acquisition-related/divestiture costs, significant asset impairments and restructurings, significant litigation and
other contingencies (such as the supplier component remediation charge in the second quarter of fiscal 2014 and the patent litigation settlement with TiVo, Inc. incurred in the fourth quarter of fiscal 2013), the income tax effects of the foregoing,
and significant tax matters. Cisco’s management also uses the foregoing non-GAAP

[0001193125-14-199056:8k_2_02:51]
3

[0001193125-14-199056:8k_2_02:52]
measures, in addition to the corresponding GAAP measures, in reviewing the financial results of Cisco. In prior periods, Cisco has excluded other items that it no longer excludes for purposes of
its non-GAAP financial measures. From time to time in the future, there may be other items that Cisco may exclude for purposes of its internal budgeting process and in reviewing its financial results.

[0001193125-14-199056:8k_2_02:53]
For additional information on the items excluded by Cisco from one or more of its non-GAAP financial measures, refer to the Form 8-K regarding this release
furnished today to the Securities and Exchange Commission.

[0001193125-14-199056:8k_2_02:54]
Copyright © 2014 Cisco and/or its affiliates. All rights reserved. Cisco, the Cisco logo,
Videoscape and the Visual Networking Index are trademarks or registered trademarks of Cisco and/or its affiliates in the U.S. and other countries. To view a list of Cisco trademarks, go to: www.cisco.com/go/trademarks. Third-party trademarks
mentioned in this document are the property of their respective owners. The use of the word partner does not imply a partnership relationship between Cisco and any other company. This document is Cisco Public Information.

[0001193125-14-199056:8k_2_02:55]
4

[0001193125-14-199056:8k_2_02:56]
CISCO SYSTEMS, INC.

[0001193125-14-199056:8k_2_02:57]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-14-199056:8k_2_02:58]
(In millions, except per-share amounts)

[0001193125-14-199056:8k_2_02:59]
(Unaudited)

[0001193125-14-199056:8k_2_02:60]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | April 26,2014 |  |  | April 27,2013 |  |  | April 26,2014 |  |  | April 27,2013 |  |
| REVENUE: |  |  |  |  |
| Product |  | $ | 8,820 |  |  | $ | 9,559 |  |  | $ | 26,640 |  |  | $ | 28,293 |  |
| Service |  |  | 2,725 |  |  |  | 2,657 |  |  |  | 8,145 |  |  |  | 7,897 |  |
| Total revenue |  |  | 11,545 |  |  |  | 12,216 |  |  |  | 34,785 |  |  |  | 36,190 |  |
| COST OF SALES: |  |  |  |  |
| Product |  |  | 3,595 |  |  |  | 3,782 |  |  |  | 11,665 |  |  |  | 11,387 |  |
| Service |  |  | 944 |  |  |  | 923 |  |  |  | 2,756 |  |  |  | 2,710 |  |
| Total cost of sales |  |  | 4,539 |  |  |  | 4,705 |  |  |  | 14,421 |  |  |  | 14,097 |  |
| GROSS MARGIN |  |  | 7,006 |  |  |  | 7,511 |  |  |  | 20,364 |  |  |  | 22,093 |  |
| OPERATING EXPENSES: |  |  |  |  |
| Research and development |  |  | 1,565 |  |  |  | 1,542 |  |  |  | 4,701 |  |  |  | 4,425 |  |
| Sales and marketing |  |  | 2,342 |  |  |  | 2,375 |  |  |  | 7,030 |  |  |  | 7,178 |  |
| General and administrative |  |  | 460 |  |  |  | 530 |  |  |  | 1,426 |  |  |  | 1,674 |  |
| Amortization of purchased intangible assets |  |  | 71 |  |  |  | 89 |  |  |  | 207 |  |  |  | 329 |  |
| Restructuring and other charges |  |  | 26 |  |  |  | 33 |  |  |  | 336 |  |  |  | 105 |  |
| Total operating expenses |  |  | 4,464 |  |  |  | 4,569 |  |  |  | 13,700 |  |  |  | 13,711 |  |
| OPERATING INCOME |  |  | 2,542 |  |  |  | 2,942 |  |  |  | 6,664 |  |  |  | 8,382 |  |
| Interest income |  |  | 170 |  |  |  | 162 |  |  |  | 508 |  |  |  | 483 |  |
| Interest expense |  |  | (146) |  |  |  | (145) |  |  |  | (422) |  |  |  | (440) |  |
| Other income (loss), net |  |  | 76 |  |  |  | (14) |  |  |  | 187 |  |  |  | (69) |  |
| Interest and other income (loss), net |  |  | 100 |  |  |  | 3 |  |  |  | 273 |  |  |  | (26) |  |
| INCOME BEFORE PROVISION FOR INCOME TAXES |  |  | 2,642 |  |  |  | 2,945 |  |  |  | 6,937 |  |  |  | 8,356 |  |
| Provision for income taxes |  |  | 461 |  |  |  | 467 |  |  |  | 1,331 |  |  |  | 643 |  |
| NET INCOME |  | $ | 2,181 |  |  | $ | 2,478 |  |  | $ | 5,606 |  |  | $ | 7,713 |  |
| Net income per share: |  |  |  |  |
| Basic |  | $ | 0.42 |  |  | $ | 0.47 |  |  | $ | 1.06 |  |  | $ | 1.45 |  |
| Diluted |  | $ | 0.42 |  |  | $ | 0.46 |  |  | $ | 1.06 |  |  | $ | 1.44 |  |
| Shares used in per-share calculation: |  |  |  |  |
| Basic |  |  | 5,143 |  |  |  | 5,329 |  |  |  | 5,271 |  |  |  | 5,316 |  |
| Diluted |  |  | 5,180 |  |  |  | 5,387 |  |  |  | 5,311 |  |  |  | 5,361 |  |
| Cash dividends declared per common share |  | $ | 0.19 |  |  | $ | 0.17 |  |  | $ | 0.53 |  |  | $ | 0.45 |  |

[0001193125-14-199056:8k_2_02:61]
RECONCILIATION OF GAAP TO NON-GAAP NET INCOME

[0001193125-14-199056:8k_2_02:62]
(In millions, except per-share amounts)

[0001193125-14-199056:8k_2_02:63]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | April 26,2014 |  |  | April 27,2013 |  |  | April 26,2014 |  |  | April 27,2013 |  |
| GAAP net income |  | $ | 2,181 |  |  | $ | 2,478 |  |  | $ | 5,606 |  |  | $ | 7,713 |  |
| Adjustments to cost of sales: |  |  |  |  |
| Share-based compensation expense |  |  | 51 |  |  |  | 44 |  |  |  | 146 |  |  |  | 136 |  |
| Amortization of acquisition-related intangible assets |  |  | 181 |  |  |  | 146 |  |  |  | 530 |  |  |  | 416 |  |
| Supplier component remediation charge |  |  | — |  |  |  | — |  |  |  | 655 |  |  |  | — |  |
| Impact to cost of sales from purchase accounting adjustments to inventory |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 40 |  |
| Acquisition-related/divestiture costs |  |  | 1 |  |  |  | — |  |  |  | 1 |  |  |  | — |  |
| Total adjustments to GAAP cost of sales |  |  | 233 |  |  |  | 190 |  |  |  | 1,332 |  |  |  | 592 |  |
| Adjustments to operating expenses: |  |  |  |  |
| Share-based compensation expense |  |  | 302 |  |  |  | 230 |  |  |  | 867 |  |  |  | 749 |  |
| Amortization of acquisition-related intangible assets |  |  | 71 |  |  |  | 89 |  |  |  | 207 |  |  |  | 329 |  |
| Acquisition-related/divestiture costs |  |  | 68 |  |  |  | 16 |  |  |  | 483 |  |  |  | 70 |  |
| Significant asset impairments and restructurings |  |  | 26 |  |  |  | (17) |  |  |  | 336 |  |  |  | 55 |  |
| Total adjustments to GAAP operating expenses |  |  | 467 |  |  |  | 318 |  |  |  | 1,893 |  |  |  | 1,203 |  |
| Total adjustments to GAAP income before provision for income taxes |  |  | 700 |  |  |  | 508 |  |  |  | 3,225 |  |  |  | 1,795 |  |
| Income tax effect of non-GAAP adjustments |  |  | (156) |  |  |  | (141) |  |  |  | (649) |  |  |  | (506) |  |
| Significant tax matters |  |  | (85) |  |  |  | (117) |  |  |  | (154) |  |  |  | (983) |  |
| Total adjustments to GAAP provision for income taxes |  |  | (241) |  |  |  | (258) |  |  |  | (803) |  |  |  | (1,489) |  |
| Non-GAAP net income |  | $ | 2,640 |  |  | $ | 2,728 |  |  | $ | 8,028 |  |  | $ | 8,019 |  |
| Diluted net income per share: |  |  |  |  |
| GAAP |  | $ | 0.42 |  |  | $ | 0.46 |  |  | $ | 1.06 |  |  | $ | 1.44 |  |
| Non-GAAP |  | $ | 0.51 |  |  | $ | 0.51 |  |  | $ | 1.51 |  |  | $ | 1.50 |  |
| RECONCILIATION OF GAAP TO NON-GAAP EFFECTIVE TAX RATE |  |
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | April 26,2014 |  |  | April 27,2013 |  |  | April 26,2014 |  |  | April 27,2013 |  |
| GAAP effective tax rate |  |  | 17.4% |  |  |  | 15.9% |  |  |  | 19.2% |  |  |  | 7.7% |  |
| Tax effect of non-GAAP adjustments to net income |  |  | 3.6% |  |  |  | 5.1% |  |  |  | 1.8% |  |  |  | 13.3% |  |
| Non-GAAP effective tax rate |  |  | 21.0% |  |  |  | 21.0% |  |  |  | 21.0% |  |  |  | 21.0% |  |

[0001193125-14-199056:8k_2_02:64]
6

[0001193125-14-199056:8k_2_02:65]
CISCO SYSTEMS, INC.

[0001193125-14-199056:8k_2_02:66]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001193125-14-199056:8k_2_02:67]
(In millions)

[0001193125-14-199056:8k_2_02:68]
(Unaudited)

[0001193125-14-199056:8k_2_02:69]
|  |  | April 26, 2014 |  |  | July 27, 2013 |  |
| ASSETS |  |  |  |  |
| Current assets: |  |  |  |  |
| Cash and cash equivalents |  | $ | 6,241 |  |  | $ | 7,925 |  |
| Investments |  |  | 44,228 |  |  |  | 42,685 |  |
| Accounts receivable, net of allowance for doubtful accounts of $247 at April 26, 2014 and $228 at July 27, 2013 |  |  | 4,443 |  |  |  | 5,470 |  |
| Inventories |  |  | 1,528 |  |  |  | 1,476 |  |
| Financing receivables, net |  |  | 4,071 |  |  |  | 4,037 |  |
| Deferred tax assets |  |  | 2,504 |  |  |  | 2,616 |  |
| Other current assets |  |  | 1,273 |  |  |  | 1,312 |  |
| Total current assets |  |  | 64,288 |  |  |  | 65,521 |  |
| Property and equipment, net |  |  | 3,310 |  |  |  | 3,322 |  |
| Financing receivables, net |  |  | 3,537 |  |  |  | 3,911 |  |
| Goodwill |  |  | 24,076 |  |  |  | 21,919 |  |
| Purchased intangible assets, net |  |  | 3,461 |  |  |  | 3,403 |  |
| Other assets |  |  | 3,184 |  |  |  | 3,115 |  |
| TOTAL ASSETS |  | $ | 101,856 |  |  | $ | 101,191 |  |
| LIABILITIES AND EQUITY |  |  |  |  |
| Current liabilities: |  |  |  |  |
| Short-term debt |  | $ | 508 |  |  | $ | 3,283 |  |
| Accounts payable |  |  | 1,051 |  |  |  | 1,029 |  |
| Income taxes payable |  |  | — |  |  |  | 192 |  |
| Accrued compensation |  |  | 2,813 |  |  |  | 3,182 |  |
| Deferred revenue |  |  | 9,198 |  |  |  | 9,262 |  |
| Other current liabilities |  |  | 4,945 |  |  |  | 5,048 |  |
| Total current liabilities |  |  | 18,515 |  |  |  | 21,996 |  |
| Long-term debt |  |  | 20,384 |  |  |  | 12,928 |  |
| Income taxes payable |  |  | 1,530 |  |  |  | 1,748 |  |
| Deferred revenue |  |  | 3,953 |  |  |  | 4,161 |  |
| Other long-term liabilities |  |  | 1,678 |  |  |  | 1,230 |  |
| Total liabilities |  |  | 46,060 |  |  |  | 42,063 |  |
| Total equity |  |  | 55,796 |  |  |  | 59,128 |  |
| TOTAL LIABILITIES AND EQUITY |  | $ | 101,856 |  |  | $ | 101,191 |  |

[0001193125-14-199056:8k_2_02:70]
CISCO SYSTEMS, INC.

[0001193125-14-199056:8k_2_02:71]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-14-199056:8k_2_02:72]
(In millions)

[0001193125-14-199056:8k_2_02:73]
(Unaudited)

[0001193125-14-199056:8k_2_02:74]
|  |  | Nine Months Ended |  |
|  |  | April 26, 2014 |  |  | April 27, 2013 |  |
| Cash flows from operating activities: |  |  |  |  |
| Net income |  | $ | 5,606 |  |  | $ | 7,713 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Depreciation, amortization, and other |  |  | 1,811 |  |  |  | 1,851 |  |
| Share-based compensation expense |  |  | 1,009 |  |  |  | 880 |  |
| Provision for receivables |  |  | 48 |  |  |  | 46 |  |
| Deferred income taxes |  |  | (181) |  |  |  | 48 |  |
| Excess tax benefits from share-based compensation |  |  | (84) |  |  |  | (48) |  |
| (Gains) losses on investments and other, net |  |  | (228) |  |  |  | (68) |  |
| Change in operating assets and liabilities, net of effects of acquisitions and divestitures: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 1,064 |  |  |  | (439) |  |
| Inventories |  |  | (50) |  |  |  | 238 |  |
| Financing receivables |  |  | 332 |  |  |  | (448) |  |
| Other assets |  |  | 180 |  |  |  | (41) |  |
| Accounts payable |  |  | (2) |  |  |  | 91 |  |
| Income taxes, net |  |  | (356) |  |  |  | (642) |  |
| Accrued compensation |  |  | (411) |  |  |  | (48) |  |
| Deferred revenue |  |  | (309) |  |  |  | (169) |  |
| Other liabilities |  |  | 291 |  |  |  | (56) |  |
| Net cash provided by operating activities |  |  | 8,720 |  |  |  | 8,908 |  |
| Cash flows from investing activities: |  |  |  |  |
| Purchases of investments |  |  | (27,884) |  |  |  | (23,969) |  |
| Proceeds from sales of investments |  |  | 14,490 |  |  |  | 7,279 |  |
| Proceeds from maturities of investments |  |  | 12,048 |  |  |  | 13,234 |  |
| Acquisition of property and equipment |  |  | (950) |  |  |  | (843) |  |
| Acquisition of businesses, net of cash and cash equivalents acquired |  |  | (2,784) |  |  |  | (6,371) |  |
| Purchases of investments in privately held companies |  |  | (315) |  |  |  | (140) |  |
| Return of investments in privately held companies |  |  | 119 |  |  |  | 110 |  |
| Proceeds from sales of property and equipment |  |  | 168 |  |  |  | 57 |  |
| Other |  |  | (30) |  |  |  | (10) |  |
| Net cash used in investing activities |  |  | (5,138) |  |  |  | (10,653) |  |
| Cash flows from financing activities: |  |  |  |  |
| Issuances of common stock |  |  | 1,053 |  |  |  | 1,193 |  |
| Repurchases of common stock - repurchase program |  |  | (7,965) |  |  |  | (1,554) |  |
| Shares repurchased for tax withholdings on vesting of restricted stock units |  |  | (345) |  |  |  | (249) |  |
| Short-term borrowings, original maturities less than 90 days, net |  |  | (2) |  |  |  | (20) |  |
| Issuances of debt |  |  | 8,001 |  |  |  | — |  |
| Repayments of debt |  |  | (3,274) |  |  |  | — |  |
| Excess tax benefits from share-based compensation |  |  | 84 |  |  |  | 48 |  |
| Dividends paid |  |  | (2,784) |  |  |  | (2,392) |  |
| Other |  |  | (34) |  |  |  | 42 |  |
| Net cash used in financing activities |  |  | (5,266) |  |  |  | (2,932) |  |
| Net decrease in cash and cash equivalents |  |  | (1,684) |  |  |  | (4,677) |  |
| Cash and cash equivalents, beginning of period |  |  | 7,925 |  |  |  | 9,799 |  |
| Cash and cash equivalents, end of period |  | $ | 6,241 |  |  | $ | 5,122 |  |
| Supplemental cash flow information: |  |  |  |  |
| Cash paid for interest |  | $ | 561 |  |  | $ | 562 |  |
| Cash paid for income taxes, net |  | $ | 1,868 |  |  | $ | 1,236 |  |

[0001193125-14-199056:8k_2_02:75]
Certain reclassifications have been made to prior period amounts to conform to the current period’s
presentation.

[0001193125-14-199056:8k_2_02:76]
8

[0001193125-14-199056:8k_2_02:77]
CASH AND CASH EQUIVALENTS AND INVESTMENTS

[0001193125-14-199056:8k_2_02:78]
(In millions)

[0001193125-14-199056:8k_2_02:79]
|  |  | April 26,2014 |  |  | July 27, 2013 |  |
| Cash and cash equivalents and investments: |  |  |  |  |
| Cash and cash equivalents |  | $ | 6,241 |  |  | $ | 7,925 |  |
| Fixed income securities |  |  | 42,269 |  |  |  | 39,888 |  |
| Publicly traded equity securities |  |  | 1,959 |  |  |  | 2,797 |  |
| Total |  | $ | 50,469 |  |  | $ | 50,610 |  |

[0001193125-14-199056:8k_2_02:80]
RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES

[0001193125-14-199056:8k_2_02:81]
TO FREE CASH FLOW (NON-GAAP)

[0001193125-14-199056:8k_2_02:82]
(In millions)

[0001193125-14-199056:8k_2_02:83]
|  |  | Three Months Ended |  |
|  |  | April 26,2014 |  |  | January 25,2014 |  |  | April 27,2013 |  |
| Net cash provided by operating activities |  | $ | 3,198 |  |  | $ | 2,873 |  |  | $ | 3,094 |  |
| Acquisition of property and equipment |  |  | (373) |  |  |  | (262) |  |  |  | (291) |  |
| Free cash flow |  | $ | 2,825 |  |  | $ | 2,611 |  |  | $ | 2,803 |  |

[0001193125-14-199056:8k_2_02:84]
DIVIDENDS PAID AND REPURCHASES OF COMMON STOCK

[0001193125-14-199056:8k_2_02:85]
(In millions, except per-share amounts)

[0001193125-14-199056:8k_2_02:86]
|  |  | DIVIDENDS |  |  | STOCK REPURCHASE PROGRAM |  |  | TOTAL |  |
| Quarter Ended |  | Per Share |  |  | Amount |  |  | Shares |  |  | Weighted-Average Price per Share |  |  | Amount |  |  | Amount |  |
| Fiscal 2014 |  |  |  |  |  |  |  |  |
| April 26, 2014 |  | $ | 0.19 |  |  | $ | 974 |  |  |  | 90 |  |  | $ | 22.24 |  |  | $ | 2,005 |  |  | $ | 2,979 |  |
| January 25, 2014 |  | $ | 0.17 |  |  | $ | 896 |  |  |  | 185 |  |  | $ | 21.73 |  |  | $ | 4,020 |  |  | $ | 4,916 |  |
| October 26, 2013 |  | $ | 0.17 |  |  | $ | 914 |  |  |  | 84 |  |  | $ | 23.65 |  |  | $ | 2,000 |  |  | $ | 2,914 |  |
| Fiscal 2013 |  |  |  |  |  |  |  |  |
| July 27, 2013 |  | $ | 0.17 |  |  | $ | 918 |  |  |  | 47 |  |  | $ | 24.80 |  |  | $ | 1,160 |  |  | $ | 2,078 |  |
| April 27, 2013 |  | $ | 0.17 |  |  | $ | 905 |  |  |  | 41 |  |  | $ | 20.85 |  |  | $ | 860 |  |  | $ | 1,765 |  |
| January 26, 2013 |  | $ | 0.14 |  |  | $ | 743 |  |  |  | 25 |  |  | $ | 20.15 |  |  | $ | 500 |  |  | $ | 1,243 |  |
| October 27, 2012 |  | $ | 0.14 |  |  | $ | 744 |  |  |  | 15 |  |  | $ | 16.44 |  |  | $ | 253 |  |  | $ | 997 |  |

[0001193125-14-199056:8k_2_02:87]
ACCOUNTS RECEIVABLE AND DSO

[0001193125-14-199056:8k_2_02:88]
(In millions, except DSO)

[0001193125-14-199056:8k_2_02:89]
|  |  | April 26,2014 |  |  | January 25,2014 |  |  | April 27,2013 |  |
| Accounts receivable, net |  | $ | 4,443 |  |  | $ | 4,378 |  |  | $ | 4,942 |  |
| Days sales outstanding in accounts receivable (DSO) |  |  | 35 |  |  |  | 36 |  |  |  | 37 |  |
| INVENTORY TURNS AND RECONCILIATION OF GAAP TO NON-GAAP COST OF SALES USED IN INVENTORY TURNS (In millions, except annualized inventory turns) |  |
|  |  | Three Months Ended |  |
|  |  | April 26, 2014 |  |  | January 25,2014 |  |  | April 27, 2013 |  |
| Annualized inventory turns - GAAP |  |  | 11.8 |  |  |  | 13.8 |  |  |  | 12.4 |  |
| Cost of sales adjustments |  |  | (0.6) |  |  |  | (2.3) |  |  |  | (0.5) |  |
| Annualized inventory turns - non-GAAP |  |  | 11.2 |  |  |  | 11.5 |  |  |  | 11.9 |  |
| GAAP cost of sales |  | $ | 4,539 |  |  | $ | 5,204 |  |  | $ | 4,705 |  |
| Cost of sales adjustments: |  |  |  |  |
| Share-based compensation expense |  |  | (51) |  |  |  | (52) |  |  |  | (44) |  |
| Amortization of acquisition-related intangible assets |  |  | (181) |  |  |  | (182) |  |  |  | (146) |  |
| Supplier component remediation charge |  |  | — |  |  |  | (655) |  |  |  | — |  |
| Acquisition-related/divestiture costs |  |  | (1) |  |  |  | — |  |  |  | — |  |
| Non-GAAP cost of sales |  | $ | 4,306 |  |  | $ | 4,315 |  |  | $ | 4,515 |  |
| DEFERRED REVENUE (In millions) |  |
|  |  | April 26, 2014 |  |  | January 25,2014 |  |  | April 27, 2013 |  |
| Service |  | $ | 8,746 |  |  | $ | 8,843 |  |  | $ | 8,705 |  |
| Product: |  |  |  |  |
| Unrecognized revenue on product shipments and other deferred revenue |  |  | 3,669 |  |  |  | 3,549 |  |  |  | 3,257 |  |
| Cash receipts related to unrecognized revenue from two-tier distributors |  |  | 736 |  |  |  | 852 |  |  |  | 723 |  |
| Total product deferred revenue |  |  | 4,405 |  |  |  | 4,401 |  |  |  | 3,980 |  |
| Total |  | $ | 13,151 |  |  | $ | 13,244 |  |  | $ | 12,685 |  |
| Reported as: |  |  |  |  |
| Current |  | $ | 9,198 |  |  | $ | 9,350 |  |  | $ | 9,055 |  |
| Noncurrent |  |  | 3,953 |  |  |  | 3,894 |  |  |  | 3,630 |  |
| Total |  | $ | 13,151 |  |  | $ | 13,244 |  |  | $ | 12,685 |  |

[0001193125-14-199056:8k_2_02:90]
10
