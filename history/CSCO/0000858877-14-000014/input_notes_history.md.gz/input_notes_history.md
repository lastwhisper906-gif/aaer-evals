# CSCO note change history — 0000858877-14-000009 → 0000858877-14-000014


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2014-05-22):
[0000858877-14-000014:note_history:1]
The Company leases office space in many U.S. locations. Outside the United States, larger leased sites include sites in Belgium, China, France, Germany, India, Israel, Italy, Japan, Norway, and the United Kingdom. The Company also leases equipment and vehicles. Future minimum lease payments under all noncancelable operating leases with an initial term in excess of one year as of April 26, 2014 are as follows (in millions):
  (was, 2014-02-20, similarity 0.628):
[0000858877-14-000009:note_history:1]
The Company leases office space in many U.S. locations. Outside the United States, larger leased sites include sites in Belgium, Canada, China, France, Germany, India, Israel, Italy, Japan, and the United Kingdom. The Company also leases equipment and vehicles. Future minimum lease payments under all noncancelable operating leases with an initial term in excess of one year as of January 25, 2014 are as follows (in millions):

- changed (2014-05-22):
[0000858877-14-000014:note_history:2]
| Fiscal Year | Amount |
| 2014 (remaining three months) | $ | 103 |  |
| 2015 | 332 |  |
| 2016 | 227 |  |
| 2017 | 157 |  |
| 2018 | 121 |  |
| Thereafter | 243 |  |
| Total | $ | 1,183 |  |
  (was, 2014-02-20, similarity 0.9739):
[0000858877-14-000009:note_history:2]
| Fiscal Year | Amount |
| 2014 (remaining six months) | $ | 202 |  |
| 2015 | 311 |  |
| 2016 | 187 |  |
| 2017 | 118 |  |
| 2018 | 91 |  |
| Thereafter | 205 |  |
| Total | $ | 1,114 |  |

- changed (2014-05-22):
[0000858877-14-000014:note_history:3]
The Company purchases components from a variety of suppliers and uses several contract manufacturers to provide manufacturing services for its products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, the Company enters into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by the Company or establish the parameters defining the Company’s requirements. A significant portion of the Company’s reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. In certain instances, these agreements allow the Company the option to cancel, reschedule, and adjust the Company’s requirements based on its business needs prior to firm orders being placed. As of April 26, 2014 and July 27, 2013, the Company had total purchase commitments for inventory of $4,038 million and $4,033 million, respectively.
  (was, 2014-02-20, similarity 0.994):
[0000858877-14-000009:note_history:3]
The Company purchases components from a variety of suppliers and uses several contract manufacturers to provide manufacturing services for its products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, the Company enters into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by the Company or establish the parameters defining the Company’s requirements. A significant portion of the Company’s reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. In certain instances, these agreements allow the Company the option to cancel, reschedule, and adjust the Company’s requirements based on its business needs prior to firm orders being placed. As of January 25, 2014 and July 27, 2013, the Company had total purchase commitments for inventory of $3,946 million and $4,033 million, respectively.

- changed (2014-05-22):
[0000858877-14-000014:note_history:4]
The Company records a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of its future demand forecasts consistent with the valuation of the Company’s excess and obsolete inventory. As of April 26, 2014 and July 27, 2013, the liability for these purchase commitments was $156 million and $172 million, respectively, and was included in other current liabilities.
  (was, 2014-02-20, similarity 0.9621):
[0000858877-14-000009:note_history:4]
The Company records a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of its future demand forecasts consistent with the valuation of the Company’s excess and obsolete inventory. As of January 25, 2014 and July 27, 2013, the liability for these purchase commitments was $173 million and $172 million, respectively, and was included in other current liabilities.

- added (2014-05-22):
[0000858877-14-000014:note_history:5]
In connection with the Company’s business combinations, the Company has agreed to pay certain additional amounts contingent upon the achievement of certain agreed-upon technology, development, product, or other milestones, or upon the continued employment with the Company of certain employees of the acquired entities.

- added (2014-05-22):
[0000858877-14-000014:note_history:6]
The following table summarizes the compensation expense related to acquisitions (in millions):

- added (2014-05-22):
[0000858877-14-000014:note_history:7]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 26, 2014 |  | April 27, 2013 |  | April 26, 2014 |  | April 27, 2013 |
| Compensation expense related to acquisitions | $ | 95 |  |  | $ | 44 |  |  | $ | 505 |  |  | $ | 79 |  |

- added (2014-05-22):
[0000858877-14-000014:note_history:8]
As of April 26, 2014, the Company estimated that future cash compensation expense of up to $645 million may be required to be recognized pursuant to the applicable business combination agreements, which included the remaining potential compensation expense related to Insieme Networks, Inc. as more fully discussed immediately below.

- changed (2014-05-22):
[0000858877-14-000014:note_history:9]
Insieme Networks, Inc. In the third quarter of fiscal 2012, the Company made an investment in Insieme Networks, Inc. ("Insieme"), an early-stage company focused on research and development in the data center market.  As set forth in the agreement between the Company and Insieme, this investment included $100 million of funding and a license to certain of the Company’s technology.  Immediately prior to the call option exercise and acquisition described below, the Company owned approximately 83% of Insieme as a result of these investments and consolidated the results of Insieme in its Consolidated Financial Statements.  In connection with this investment, the Company and Insieme entered into a put/call option agreement that provided the Company with the right to purchase the remaining interests in Insieme.  In addition, the noncontrolling interest holders could require the Company to purchase their shares upon the occurrence of certain events.
  (was, 2014-02-20, similarity 0.9989):
[0000858877-14-000009:note_history:9]
Insieme Networks, Inc. In the third quarter of fiscal 2012, the Company made an investment in Insieme Networks, Inc. ("Insieme"), an early stage company focused on research and development in the data center market.  As set forth in the agreement between the Company and Insieme, this investment included $100 million of funding and a license to certain of the Company’s technology.  Immediately prior to the call option exercise and acquisition described below, the Company owned approximately 83% of Insieme as a result of these investments and consolidated the results of Insieme in its Consolidated Financial Statements.  In connection with this investment, the Company and Insieme entered into a put/call option agreement that provided the Company with the right to purchase the remaining interests in Insieme.  In addition, the noncontrolling interest holders could require the Company to purchase their shares upon the occurrence of certain events.

- changed (2014-05-22):
[0000858877-14-000014:note_history:10]
During the first quarter of fiscal 2014, the Company exercised its call option and entered into an agreement to purchase the remaining interests in Insieme.  The acquisition closed in the second quarter of fiscal 2014, at which time the former noncontrolling interest holders became eligible to receive up to two milestone payments, which will be determined using agreed-upon formulas based primarily on revenue for certain of Insieme’s products.  During the three and nine months ended April 26, 2014, the Company recorded compensation expense of $52 million and $363 million related to the fair value of the vested portion of amounts that are expected to be earned by the former noncontrolling interest holders.  Continued vesting and changes to the fair value of the amounts probable of being earned will result in adjustments to the recorded compensation expense in future periods.  Based on the terms of the agreement, the Company has determined that the maximum amount that could be recorded as compensation expense by the Company is approximately $856 million, net of forfeitures and including the $363 million that has been expensed through April 26, 2014.  The milestone payments, if earned, are expected to be paid primarily during fiscal 2016 and fiscal 2017.
  (was, 2014-02-20, similarity 0.9664):
[0000858877-14-000009:note_history:10]
During the first quarter of fiscal 2014, the Company exercised its call option and entered into an agreement to purchase the remaining interests in Insieme.  The acquisition closed in the second quarter of fiscal 2014, at which time the former noncontrolling interest holders became eligible to receive up to two milestone payments, which will be determined using agreed-upon formulas based primarily on revenue for certain of Insieme’s products.  During the three and six months ended January 25, 2014, the Company recorded compensation expense of $54 million and $311 million related to the fair value of the vested portion of amounts that are expected to be earned by the former noncontrolling interest holders.  Continued vesting and changes to the fair value of the amounts probable of being earned will result in adjustments to the recorded compensation expense in future periods.  Based on the terms of the agreement, the Company has determined that the maximum amount that could be recorded as compensation expense by the Company is approximately $863 million, including the $311 million that has been expensed through January 25, 2014.  The milestone payments, if earned, are expected to be paid primarily during fiscal 2016 and fiscal 2017.

- changed (2014-05-22):
[0000858877-14-000014:note_history:11]
The Company also has certain funding commitments, primarily related to its investments in privately held companies and venture funds, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $276 million and $263 million as of April 26, 2014 and July 27, 2013, respectively.
  (was, 2014-02-20, similarity 0.9589):
[0000858877-14-000009:note_history:11]
The Company also has certain funding commitments, primarily related to its investments in privately held companies and venture funds, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $279 million and $263 million as of January 25, 2014 and July 27, 2013, respectively.

- changed (2014-05-22):
[0000858877-14-000014:note_history:12]
As of April 26, 2014, the Company’s cumulative gross investment in VCE was approximately $679 million, inclusive of accrued interest, and its ownership percentage was approximately 35%.  The Company invested $147 million during the nine months ended April 26, 2014.
  (was, 2014-02-20, similarity 0.7665):
[0000858877-14-000009:note_history:12]
As of January 25, 2014, the Company’s cumulative gross investment in VCE was approximately $669 million, inclusive of accrued interest, and its ownership percentage was approximately 35%.  The Company invested $83 million in VCE during the three months ended January 25, 2014 and $147 million during the six months ended January 25, 2014.

- changed (2014-05-22):
[0000858877-14-000014:note_history:13]
The Company accounts for its investment in VCE under the equity method, and its portion of VCE’s net loss is recognized in other income (loss), net.  The Company’s share of VCE’s losses, based upon its portion of the overall funding, was approximately 36.8% for each of the three and nine months ended April 26, 2014 and April 27, 2013.  As of April 26, 2014, the Company had recorded cumulative losses from VCE of $584 million since inception, of which losses of $52 million and $49 million were recorded for the three months ended April 26, 2014 and April 27, 2013, respectively, and losses of $163 million and $135 million were recorded for the nine months ended April 26, 2014 and April 27, 2013, respectively.  The Company’s carrying value in VCE as of April 26, 2014 of $95 million was recorded in other assets.
  (was, 2014-02-20, similarity 0.8418):
[0000858877-14-000009:note_history:13]
The Company accounts for its investment in VCE under the equity method, and its portion of VCE’s net loss is recognized in other income (loss), net.  The Company’s share of VCE’s losses, based upon its portion of the overall funding, was approximately 36.8% for each of the three and six months ended January 25, 2014 and January 26, 2013. As of January 25, 2014, the Company had recorded cumulative losses from VCE of $533 million since inception, of which losses of $58 million and $44 million were recorded for the three months ended January 25, 2014 and January 26, 2013, respectively, and losses of $111 million and $86 million were recorded for the six months ended January 25, 2014 and January 26, 2013, respectively.  The Company’s carrying value in VCE as of January 25, 2014 of $136 million was recorded in other assets.

- changed (2014-05-22):
[0000858877-14-000014:note_history:14]
From time to time, EMC and Cisco may enter into guarantee agreements on behalf of VCE to indemnify third parties, such as customers, for monetary damages. Such guarantees were not material as of April 26, 2014.
  (was, 2014-02-20, similarity 0.9707):
[0000858877-14-000009:note_history:14]
From time to time, EMC and Cisco may enter into guarantee agreements on behalf of VCE to indemnify third parties, such as customers, for monetary damages. Such guarantees were not material as of January 25, 2014.

- changed (2014-05-22):
[0000858877-14-000014:note_history:15]
Other Variable Interest Entities In the ordinary course of business, the Company has investments in other privately held companies and provides financing to certain customers. These other privately held companies and customers may be considered to be variable interest entities. The Company evaluates on an ongoing basis its investments in these other privately held companies and its customer financings, and has determined that as of April 26, 2014 there were no other variable interest entities required to be consolidated in the Company’s Consolidated Financial Statements.
  (was, 2014-02-20, similarity 0.9895):
[0000858877-14-000009:note_history:15]
Other Variable Interest Entities In the ordinary course of business, the Company has investments in other privately held companies and provides financing to certain customers. These other privately held companies and customers may be considered to be variable interest entities. The Company evaluates on an ongoing basis its investments in these other privately held companies and its customer financings, and has determined that as of January 25, 2014 there were no other variable interest entities required to be consolidated in the Company’s Consolidated Financial Statements.

- changed (2014-05-22):
[0000858877-14-000014:note_history:16]
The following table summarizes the activity related to product warranty liability during the nine months ended April 26, 2014 and April 27, 2013 (in millions):
  (was, 2014-02-20, similarity 0.9302):
[0000858877-14-000009:note_history:16]
The following table summarizes the activity related to product warranty liability during the six months ended January 25, 2014 and January 26, 2013 (in millions):

- changed (2014-05-22):
[0000858877-14-000014:note_history:17]
|  | Nine Months Ended |
|  | April 26, 2014 |  | April 27, 2013 |
| Balance at beginning of period | $ | 402 |  |  | $ | 373 |  |
| Provision for warranties issued | 532 |  |  | 480 |  |
| Payments | (504 | ) |  | (462 | ) |
| Balance at end of period | $ | 430 |  |  | $ | 391 |  |
  (was, 2014-02-20, similarity 0.9002):
[0000858877-14-000009:note_history:17]
|  | Six Months Ended |
|  | January 25, 2014 |  | January 26, 2013 |
| Balance at beginning of period | $ | 402 |  |  | $ | 373 |  |
| Provision for warranties issued | 356 |  |  | 311 |  |
| Payments | (333 | ) |  | (302 | ) |
| Balance at end of period | $ | 425 |  |  | $ | 382 |  |

- changed (2014-05-22):
[0000858877-14-000014:note_history:18]
The Company also provides financing guarantees, which are generally for various third-party financing arrangements to channel partners and other end-user customers. For additional information, see Note 7. The Company’s other guarantee arrangements as of April 26, 2014 and July 27, 2013 that were subject to recognition and disclosure requirements were not material.
  (was, 2014-02-20, similarity 0.9831):
[0000858877-14-000009:note_history:18]
The Company also provides financing guarantees, which are generally for various third-party financing arrangements to channel partners and other end-user customers. For additional information, see Note 7. The Company’s other guarantee arrangements as of January 25, 2014 and July 27, 2013 that were subject to recognition and disclosure requirements were not material.

- changed (2014-05-22):
[0000858877-14-000014:note_history:19]
The Company has recorded in other current liabilities a liability for the expected remediation cost for certain products sold in prior fiscal years containing memory components manufactured by a single supplier between 2005 and 2010. These components are widely used across the industry and are included in a number of the Company's products. Defects in some of these components have caused products to fail after a power cycle event.  Defect rates due to this issue have been and are expected to be low. However, recently the Company has seen a small number of its customers experience a growing number of failures in their networks as a result of this component problem. Although the majority of these products are beyond the Company's warranty terms, the Company is proactively working with customers on mitigation.  Prior to the second quarter of fiscal 2014, the Company had a liability of $63 million related to this issue for expected remediation costs based on the intended approach at that time. In February 2014, on the basis of the growing number of failures described above, the Company decided to expand its approach which resulted in an additional charge to product cost of sales of $655 million being recorded for the second quarter of fiscal 2014.  As of April 26, 2014, the remaining supplier component remediation liability was $702 million.
  (was, 2014-02-20, similarity 0.6756):
[0000858877-14-000009:note_history:19]
The Company has recorded a liability for the expected remediation cost for certain products sold in prior fiscal years containing memory components manufactured by a single supplier between 2005 and 2010. These components are widely used across the industry and are included in a number of the Company's products. Defects in some of these components have caused products to fail after a power cycle event.  Defect rates due to this issue have been and are expected to be low. However, recently the Company has seen a small number of its customers experience a growing number of failures in their networks as a result of this component problem. Although the majority of these products are beyond the Company's warranty terms, the Company is proactively working with customers on mitigation.  Prior to the second quarter of fiscal 2014, the Company had recorded a liability related to this issue for expected remediation costs based on the intended approach at that time. In February 2014, on the basis of the growing number of failures described above, the Company decided to expand its approach which resulted in an additional charge to product cost of sales of $655 million being recorded for the second quarter of fiscal 2014.

- added (2014-05-22):
[0000858877-14-000014:note_history:20]
Brazil Brazilian authorities have investigated the Company’s Brazilian subsidiary and certain of its current and former employees, as well as a Brazilian importer of the Company’s products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against the Company’s Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years. In the first quarter of fiscal 2013, the Brazilian federal tax authorities asserted an additional claim against the Company’s Brazilian subsidiary based on a theory of joint liability with respect to an alleged underpayment of income taxes, social taxes, interest, and penalties by a Brazilian distributor.

- changed (2014-05-22):
[0000858877-14-000014:note_history:21]
The asserted claims by Brazilian federal tax authorities are for calendar years 2003 through 2008, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to approximately $389 million for the alleged evasion of import and other taxes, approximately $1.3 billion for interest, and approximately $1.7 billion for various penalties, all determined using an exchange rate as of April 26, 2014. The Company has completed a thorough review of the matters and believes the asserted claims against the Company’s Brazilian subsidiary are without merit, and the Company is defending the claims vigorously. While the Company believes there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, the Company is unable to determine the likelihood of an unfavorable outcome against its Brazilian subsidiary and is unable to reasonably estimate a range of loss, if any. The Company does not expect a final judicial determination for several years.
  (was, 2014-02-20, similarity 0.9946):
[0000858877-14-000009:note_history:21]
The asserted claims by Brazilian federal tax authorities are for calendar years 2003 through 2008, and the asserted claims by the tax authorities from the state of Sao Paulo, are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to approximately $360 million for the alleged evasion of import and other taxes, approximately $1.1 billion for interest, and approximately $1.6 billion for various penalties, all determined using an exchange rate as of January 25, 2014. The Company has completed a thorough review of the matters and believes the asserted claims against the Company’s Brazilian subsidiary are without merit, and the Company is defending the claims vigorously. While the Company believes there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, the Company is unable to determine the likelihood of an unfavorable outcome against its Brazilian subsidiary and is unable to reasonably estimate a range of loss, if any. The Company does not expect a final judicial determination for several years.

- changed (2014-05-22):
[0000858877-14-000014:note_history:22]
Russia and the Commonwealth of Independent States At the request of the U.S. Securities and Exchange Commission and the U.S. Department of Justice, the Company is conducting an investigation into allegations which the Company and those agencies received regarding possible violations of the U.S. Foreign Corrupt Practices Act involving business activities of the Company's operations in Russia and certain of the Commonwealth of Independent States, and by certain resellers of the Company’s products in those countries.  The Company takes any such allegations very seriously and is fully cooperating with and sharing the results of its investigation with the Commission and the Department.  While the outcome of the Company's investigation is currently not determinable, the Company does not expect that it will have a material adverse effect on its consolidated financial position, results of operations, or cash flows. The countries that are the subject of the investigation collectively comprise less than two percent of the Company’s revenues.
  (was, 2014-02-20, similarity 0.9755):
[0000858877-14-000009:note_history:22]
At the request of the U.S. Securities and Exchange Commission and the U.S. Department of Justice, the Company is conducting an investigation into allegations which the Company and those agencies received regarding possible violations of the U.S. Foreign Corrupt Practices Act involving business activities of the Company's operations in Russia and certain of the Commonwealth of Independent States, and by certain resellers of the Company’s products in those countries.  The Company takes any such allegations very seriously and is fully cooperating with and sharing the results of its investigation with the Commission and the Department.  While the outcome of the Company's investigation is currently not determinable, the Company does not expect that it will have a material adverse effect on its consolidated financial position, results of operations, or cash flows. The countries that are the subject of the investigation collectively comprise less than two percent of the Company’s revenues.

- changed (2014-05-22):
[0000858877-14-000014:note_history:23]
VirnetX  The Company was subject to patent claims asserted by VirnetX, Inc. on August 11, 2010 in the United States District Court for the Eastern District of Texas.  VirnetX alleged that some Cisco products that implement a method for secure communication using virtual private networks infringe certain patents.  VirnetX sought monetary damages.  The trial on these claims began on March 4, 2013. On March 14, 2013, the jury entered a verdict finding that the Company’s accused products do not infringe any of VirnetX’s patents asserted in the lawsuit. On April 3, 2013, VirnetX filed a motion seeking a new trial on the issue of infringement, which the Company opposed. The Court held a hearing on VirnetX’s motion for a new trial in June 2013.  On March 31, 2014 the court denied VirnetX's new trial motion.  VirnetX has not appealed that decision, which is therefore final.
  (was, 2014-02-20, similarity 0.8917):
[0000858877-14-000009:note_history:23]
The Company was subject to patent claims asserted by VirnetX, Inc. on August 11, 2010 in the United States District Court for the Eastern District of Texas.  VirnetX alleged that various Cisco products that implement a method for secure communication using virtual private networks infringe certain patents.  VirnetX sought monetary damages.  The trial on these claims began on March 4, 2013. On March 14, 2013, the jury entered a verdict finding that the Company’s accused products do not infringe any of VirnetX’s patents asserted in the lawsuit. On April 3, 2013, VirnetX filed a motion seeking a new trial on the issue of infringement, which the Company has opposed. The Court held a hearing on VirnetX’s motion for a new trial in June 2013, but has not issued a ruling.

- changed (2014-05-22):
[0000858877-14-000014:note_history:24]
XpertUniverse The Company was subject to numerous patent, tort, and contract claims asserted by XpertUniverse on March 10, 2009 in the United States District Court for the District of Delaware. Shortly before trial, the Court dismissed on summary judgment all claims initially asserted by XpertUniverse except a claim for infringement of two XpertUniverse patents and a claim for fraud by concealment. XpertUniverse’s remaining patent claims alleged that three Cisco products in the field of expertise location software infringed two XpertUniverse patents. XpertUniverse’s fraud by concealment claim alleged that the Company did not disclose its decision not to admit XpertUniverse into a partner program. The trial on these remaining claims began on March 11, 2013. On March 22, 2013, the jury entered a verdict finding that two of the Company’s products infringed two of XpertUniverse’s patents and awarded XpertUniverse damages of less than $35 thousand. The jury also found for XpertUniverse on its fraud by concealment claim and awarded damages of $70 million.  In May and June 2013, the Company filed post-trial motions.  On November 20, 2013 the trial court granted the Company's motion for judgment as a matter of law, overturned the jury’s finding on the fraud by concealment claim, and vacated the $70 million verdict.  Separately, the trial court agreed with the jury that the Company infringed XpertUniverse’s patents, and affirmed the verdict awarding XpertUniverse approximately $35 thousand in damages plus accrued interest.  On February 4, 2014, XpertUniverse filed a notice of appeal from the trial court’s decision.
  (was, 2014-02-20, similarity 0.9905):
[0000858877-14-000009:note_history:24]
The Company was subject to numerous patent, tort, and contract claims asserted by XpertUniverse on March 10, 2009 in the United States District Court for the District of Delaware. Shortly before trial, the Court dismissed on summary judgment all claims initially asserted by XpertUniverse except a claim for infringement of two XpertUniverse patents and a claim for fraud by concealment. XpertUniverse’s remaining patent claims alleged that three Cisco products in the field of expertise location software infringed two XpertUniverse patents. XpertUniverse’s fraud by concealment claim alleged that the Company did not disclose its decision not to admit XpertUniverse into a partner program. The trial on these remaining claims began on March 11, 2013. On March 22, 2013, the jury entered a verdict finding that two of the Company’s products infringed two of XpertUniverse’s patents and awarded XpertUniverse damages of less than $35 thousand. The jury also found for XpertUniverse on its fraud by concealment claim and awarded damages of $70 million.  In May and June 2013, the Company filed post-trial motions.  On November 20, 2013 the trial court granted the Company's motion for judgment as a matter of law, overturned the jury’s finding on the fraud by concealment claim, and vacated the $70 million verdict.  Separately, the trial court agreed with the jury that the Company infringed XpertUniverse’s patents, and affirmed the verdict awarding XpertUniverse approximately $35 thousand in damages plus accrued interest.  XpertUniverse filed a notice of appeal from the trial court’s decision.

- added (2014-05-22):
[0000858877-14-000014:note_history:25]
Rockstar The Company and some of its service provider customers are subject to patent claims asserted in December 2013 in the Eastern District of Texas and the District of Delaware by subsidiaries of the Rockstar Consortium ("Rockstar").  Rockstar, whose members include Apple, Microsoft, LM Ericsson, Sony, and Blackberry, purchased a portfolio of patents out of the Nortel Networks’ bankruptcy proceedings (the “Nortel Portfolio”). Rockstar’s subsidiaries allege that some of the Company’s NGN Routing, Switching and Collaboration products, as well as video solutions deployed by its service provider customers, infringe some of the patents in the Nortel Portfolio.  Rockstar seeks monetary damages.  A trial date for one service provider customer has been set for October 2015; no other trial dates have been set.  The Company has various defenses to the patent infringement allegations, and has various offensive claims against Rockstar and some of its consortium members available to it as well, and the Company will also explore alternative means of resolution.   Due to the uncertainty surrounding the litigation process, which involves numerous lawsuits and parties, the Company is unable to reasonably estimate the ultimate outcome and a range of loss, if any, of these litigations at this time.

- removed (2014-05-22):
[0000858877-14-000009:note_history:26]
In connection with the Company’s business combinations and asset purchases, the Company has agreed to pay certain additional amounts contingent upon the achievement of certain agreed-upon technology, development, product, or other milestones or the continued employment with the Company of certain employees of the acquired entities. The Company recognized such compensation expense of $106 million and $23 million during the three months ended January 25, 2014 and January 26, 2013, respectively, and $410 million and $35 million during the six months ended January 25, 2014 and January 26, 2013, respectively.  As of January 25, 2014, the Company estimated that future cash compensation expense and contingent consideration of up to $751 million may be required to be recognized pursuant to the applicable business combination and asset purchase agreements, which included the remaining potential compensation expense related to Insieme Networks, Inc. as more fully discussed immediately below.

- removed (2014-05-22):
[0000858877-14-000009:note_history:27]
In an unrelated matter, certain of the Company's service provider customers, whom the Company had agreed to indemnify, were subject to patent claims asserted by C-Cation Technologies, LLC (“C-Cation”) in the United States District Court for the Eastern District of Texas filed on January 25, 2011. C-Cation had alleged that the service providers infringe C-Cation’s patent through use of Cable Modem Termination Systems and cable modems provided by the Company and other manufacturers. C-Cation sought monetary damages and injunctive relief.  Prior to the commencement of trial, the parties reached a resolution and dismissal of the matter, which did not have a material effect on the Company’s consolidated financial position, results of operations, or cash flows.

- removed (2014-05-22):
[0000858877-14-000009:note_history:28]
Brazilian authorities have investigated the Company’s Brazilian subsidiary and certain of its current and former employees, as well as a Brazilian importer of the Company’s products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against the Company’s Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years. In the first quarter of fiscal 2013, the Brazilian federal tax authorities asserted an additional claim against the Company’s Brazilian subsidiary based on a theory of joint liability with respect to an alleged underpayment of income taxes, social taxes, interest, and penalties by a Brazilian distributor.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2014-05-22):
[0000858877-14-000014:note_history:29]
The accompanying financial data as of April 26, 2014 and for the three and nine months ended April 26, 2014 and April 27, 2013 has been prepared by the Company, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (SEC). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (GAAP) have been condensed or omitted pursuant to such rules and regulations. The July 27, 2013 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, the Company believes that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended July 27, 2013.
  (was, 2014-02-20, similarity 0.9635):
[0000858877-14-000009:note_history:29]
The accompanying financial data as of January 25, 2014 and for the three and six months ended January 25, 2014 and January 26, 2013 has been prepared by the Company, without audit, pursuant to the rules and regulations of the Securities and Exchange Commission (SEC). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (GAAP) have been condensed or omitted pursuant to such rules and regulations. The July 27, 2013 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, the Company believes that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended July 27, 2013.

- changed (2014-05-22):
[0000858877-14-000014:note_history:30]
In the opinion of management, all adjustments (which include normal recurring adjustments, except as disclosed herein) necessary to present fairly the statement of financial position as of April 26, 2014; the results of operations and statements of comprehensive income for the three and nine months ended April 26, 2014 and April 27, 2013; and the statements of cash flows and equity for the nine months ended April 26, 2014 and April 27, 2013, as applicable, have been made. The results of operations for the three and nine months ended April 26, 2014 are not necessarily indicative of the operating results for the full fiscal year or any future periods.
  (was, 2014-02-20, similarity 0.8311):
[0000858877-14-000009:note_history:30]
In the opinion of management, all adjustments (which include normal recurring adjustments, except as disclosed herein) necessary to present fairly the statement of financial position as of January 25, 2014; the results of operations and statements of comprehensive income for the three and six months ended January 25, 2014 and January 26, 2013; and the statements of cash flows and equity for the six months ended January 25, 2014 and January 26, 2013, as applicable, have been made. The results of operations for the three and six months ended January 25, 2014 are not necessarily indicative of the operating results for the full fiscal year or any future periods.

- changed (2014-05-22):
[0000858877-14-000014:note_history:31]
Certain reclassifications have been made to prior-period amounts in order to conform to the current period’s presentation. The Company has evaluated subsequent events through the date that the financial statements were issued.
  (was, 2014-02-20, similarity 0.9956):
[0000858877-14-000009:note_history:31]
Certain reclassifications have been made to prior period amounts in order to conform to the current period’s presentation. The Company has evaluated subsequent events through the date that the financial statements were issued.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2014-05-22):
[0000858877-14-000014:note_history:32]
In December 2011, the Financial Accounting Standards Board (FASB) issued an accounting standard update requiring enhanced disclosures about certain financial instruments and derivative instruments that are offset in the statement of financial position or that are subject to enforceable master netting arrangements or similar agreements. This accounting standard became effective for the Company in the first quarter of fiscal 2014.  As a result of the application of this accounting standard update, the Company has provided additional disclosures in Note 11.
  (was, 2014-02-20, similarity 0.9594):
[0000858877-14-000009:note_history:32]
In December 2011, the FASB issued an accounting standard update requiring enhanced disclosures about certain financial instruments and derivative instruments that are offset in the statement of financial position or that are subject to enforceable master netting arrangements or similar agreements. This accounting standard became effective for the Company in the first quarter of fiscal 2014.  As a result of the application of this accounting standard update, the Company has provided additional disclosures in Note 11.

- added (2014-05-22):
[0000858877-14-000014:note_history:33]
In April 2014, the FASB issued an accounting standard update that changes the criteria for reporting discontinued operations.  Under the accounting standard update, a disposal of a component of an entity or a group of components of an entity is required to be reported in discontinued operations if the disposal represents a strategic shift that has, or will have, a major effect on an entity's operations and financial results when either it qualifies as held for sale, disposed of by sale, or disposed of other than by sale.  This accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2016.  The Company is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2014-05-22):
[0000858877-14-000014:note_history:34]
|  | April 26, 2014 |  | July 27, 2013 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 500 |  |  | 3.11 | % |  | $ | 3,273 |  |  | 0.63 | % |
| Other notes and borrowings | 8 |  |  | 2.60 | % |  | 10 |  |  | 2.52 | % |
| Total short-term debt | $ | 508 |  |  |  |  | $ | 3,283 |  |  |  |

- changed (2014-05-22):
[0000858877-14-000014:note_history:35]
In fiscal 2011, the Company established a short-term debt financing program of up to $3.0 billion through the issuance of commercial paper notes. The Company uses the proceeds from the issuance of commercial paper notes for general corporate purposes. In the third quarter of fiscal 2014, the Company repaid $1.0 billion of indebtedness under commercial paper and had no commercial paper outstanding as of each of April 26, 2014 and July 27, 2013.
  (was, 2014-02-20, similarity 0.6562):
[0000858877-14-000009:note_history:35]
In fiscal 2011, the Company established a short-term debt financing program of up to $3.0 billion through the issuance of commercial paper notes. The Company uses the proceeds from the issuance of commercial paper notes for general corporate purposes. The outstanding commercial paper as of January 25, 2014 had a maturity date of three months or less.

- added (2014-05-22):
[0000858877-14-000014:note_history:36]
The effective interest rate on the current portion of long-term debt includes the impact of interest rate swaps, as discussed further in "

- changed (2014-05-22):
[0000858877-14-000014:note_history:37]
."  The Company repaid senior floating-rate and fixed-rate notes upon their maturity in the third quarter of fiscal 2014 for an aggregate principal amount of $3.3 billion.  Other notes and borrowings consist of the short-term portion of secured borrowings associated with customer financing arrangements.  These notes and credit facilities were subject to various terms and foreign currency market interest rates pursuant to individual financial arrangements between the financing institution and the applicable foreign subsidiary.
  (was, 2014-02-20, similarity 0.8114):
[0000858877-14-000009:note_history:37]
Other notes and borrowings consist of the short-term portion of secured borrowings associated with customer financing arrangements.  These notes and credit facilities were subject to various terms and foreign currency market interest rates pursuant to individual financial arrangements between the financing institution and the applicable foreign subsidiary.

- changed (2014-05-22):
[0000858877-14-000014:note_history:38]
As of April 26, 2014, the estimated fair value of the short-term debt approximates its carrying value due to the short maturities.
  (was, 2014-02-20, similarity 0.968):
[0000858877-14-000009:note_history:38]
As of January 25, 2014, the estimated fair value of the short-term debt approximates its carrying value due to the short maturities.

- added (2014-05-22):
[0000858877-14-000014:note_history:39]
(b)

- added (2014-05-22):
[0000858877-14-000014:note_history:40]
Long-Term Debt

- added (2014-05-22):
[0000858877-14-000014:note_history:41]
|  |  |  | April 26, 2014 |  | July 27, 2013 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.25% | March 14, 2014 |  | $ | — |  |  | — |  | $ | 1,250 |  |  | 0.62% |
| Three-month LIBOR plus 0.05% | September 3, 2015 | (1) | 850 |  |  | 0.38% |  | — |  |  | — |
| Three-month LIBOR plus 0.28% | March 3, 2017 | (1) | 1,000 |  |  | 0.58% |  | — |  |  | — |
| Three-month LIBOR plus 0.50% | March 1, 2019 | (1) | 500 |  |  | 0.79% |  | — |  |  | — |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 1.625% | March 14, 2014 |  | — |  |  | — |  | 2,000 |  |  | 0.64% |
| 2.90% | November 17, 2014 |  | 500 |  |  | 3.11% |  | 500 |  |  | 3.11% |
| 5.50% | February 22, 2016 |  | 3,000 |  |  | 3.05% |  | 3,000 |  |  | 3.07% |
| 1.10% | March 3, 2017 | (1) | 2,400 |  |  | 0.56% |  | — |  |  | — |
| 3.15% | March 14, 2017 |  | 750 |  |  | 0.80% |  | 750 |  |  | 0.84% |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 4.69% |  | 2,000 |  |  | 4.70% |
| 2.125% | March 1, 2019 | (1) | 1,750 |  |  | 0.77% |  | — |  |  | — |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 2.98% |  | 2,500 |  |  | 4.15% |
| 2.90% | March 4, 2021 | (1) | 500 |  |  | 0.93% |  | — |  |  | — |
| 3.625% | March 3, 2024 | (1) | 1,000 |  |  | 1.05% |  | — |  |  | — |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Other long-term debt |  |  | 6 |  |  | 2.52% |  | 21 |  |  | 1.46% |
| Total |  |  | 20,756 |  |  |  |  | 16,021 |  |  |  |
| Unaccreted discount |  |  | (65 | ) |  |  |  | (65 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 193 |  |  |  |  | 245 |  |  |  |
| Total |  |  | $ | 20,884 |  |  |  |  | $ | 16,201 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 500 |  |  |  |  | $ | 3,273 |  |  |  |
| Long-term debt |  |  | 20,384 |  |  |  |  | 12,928 |  |  |  |
| Total |  |  | $ | 20,884 |  |  |  |  | $ | 16,201 |  |  |  |

- added (2014-05-22):
[0000858877-14-000014:note_history:42]
(1) In March 2014, the Company issued senior notes for an aggregate principal amount of $8.0 billion.

- changed (2014-05-22):
[0000858877-14-000014:note_history:43]
To achieve its interest rate risk management objectives, the Company entered into interest rate swaps with an aggregate notional amount of $10.4 billion designated as fair value hedges of certain of its fixed-rate senior notes. In effect, these swaps convert the fixed interest rates of the fixed-rate notes to floating interest rates based on the London InterBank Offered Rate (LIBOR). The gains and losses related to changes in the fair value of the interest rate swaps substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates. For additional information, see Note 11.
  (was, 2014-02-20, similarity 0.997):
[0000858877-14-000009:note_history:43]
To achieve its interest rate risk management objectives, the Company has entered into interest rate swaps with an aggregate notional amount of $6.25 billion designated as fair value hedges of certain of its fixed-rate senior notes. In effect, these swaps convert the fixed interest rates of the fixed-rate notes to floating interest rates based on the London InterBank Offered Rate (LIBOR). The gains and losses related to changes in the fair value of the interest rate swaps substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates. For additional information, see Note 11.

- changed (2014-05-22):
[0000858877-14-000014:note_history:44]
The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to the Company’s short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of April 26, 2014, the Company was in compliance with all debt covenants.
  (was, 2014-02-20, similarity 0.9781):
[0000858877-14-000009:note_history:44]
The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to the Company’s short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of January 25, 2014, the Company was in compliance with all debt covenants.

- changed (2014-05-22):
[0000858877-14-000014:note_history:45]
As of April 26, 2014, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):
  (was, 2014-02-20, similarity 0.9701):
[0000858877-14-000009:note_history:45]
As of January 25, 2014, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

- changed (2014-05-22):
[0000858877-14-000014:note_history:46]
| Fiscal Year | Amount |
| 2014 (remaining three months) | $ | — |  |
| 2015 | 502 |  |
| 2016 | 3,853 |  |
| 2017 | 4,151 |  |
| 2018 | — |  |
| Thereafter | 12,250 |  |
| Total | $ | 20,756 |  |
  (was, 2014-02-20, similarity 0.9673):
[0000858877-14-000009:note_history:46]
| Fiscal Year | Amount |
| 2014 (remaining six months) | $ | 3,250 |  |
| 2015 | 503 |  |
| 2016 | 3,003 |  |
| 2017 | 750 |  |
| 2018 | — |  |
| Thereafter | 8,500 |  |
| Total | $ | 16,006 |  |

- changed (2014-05-22):
[0000858877-14-000014:note_history:47]
On February 17, 2012, the Company entered into a credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on February 17, 2017. Any advances under the credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (i) the higher of the Federal Funds rate plus 0.50%, Bank of America’s “prime rate” as announced from time to time, or one-month LIBOR plus 1.00% or (ii) LIBOR plus a margin that is based on the Company’s senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc. The credit agreement requires the Company to comply with certain covenants, including that it maintain an interest coverage ratio as defined in the agreement. As of April 26, 2014, the Company was in compliance with the required interest coverage ratio and the other covenants, and the Company had not borrowed any funds under the credit facility.
  (was, 2014-02-20, similarity 0.9935):
[0000858877-14-000009:note_history:47]
On February 17, 2012, the Company entered into a credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on February 17, 2017. Any advances under the credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (i) the higher of the Federal Funds rate plus 0.50%, Bank of America’s “prime rate” as announced from time to time, or one-month LIBOR plus 1.00%, or (ii) LIBOR plus a margin that is based on the Company’s senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc. The credit agreement requires the Company to comply with certain covenants, including that it maintain an interest coverage ratio as defined in the agreement. As of January 25, 2014, the Company was in compliance with the required interest coverage ratio and the other covenants, and the Company had not borrowed any funds under the credit facility.

- removed (2014-05-22):
[0000858877-14-000009:note_history:48]
|  | January 25, 2014 |  | July 27, 2013 |
|  | Amount |  | Weighted-Average Interest Rate |  | Amount |  | Weighted-Average Interest Rate |
| Current portion of long-term debt | $ | 3,752 |  |  | 0.93 | % |  | $ | 3,273 |  |  | 0.63 | % |
| Commercial paper | 1,000 |  |  | 0.12 | % |  | — |  |  | — |  |
| Other notes and borrowings | 10 |  |  | 2.55 | % |  | 10 |  |  | 2.52 | % |
| Total short-term debt | $ | 4,762 |  |  |  |  | $ | 3,283 |  |  |  |

- removed (2014-05-22):
[0000858877-14-000009:note_history:49]
|  | January 25, 2014 |  | July 27, 2013 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior Notes: |  |  |  |  |  |  |  |
| Floating-rate notes, due 2014 | $ | 1,250 |  |  | 0.58% |  | $ | 1,250 |  |  | 0.62% |
| 1.625% fixed-rate notes, due 2014 | 2,000 |  |  | 0.61% |  | 2,000 |  |  | 0.64% |
| 2.90% fixed-rate notes, due 2014 | 500 |  |  | 3.11% |  | 500 |  |  | 3.11% |
| 5.50% fixed-rate notes, due 2016 | 3,000 |  |  | 3.05% |  | 3,000 |  |  | 3.07% |
| 3.15% fixed-rate notes, due 2017 | 750 |  |  | 0.81% |  | 750 |  |  | 0.84% |
| 4.95% fixed-rate notes, due 2019 | 2,000 |  |  | 4.69% |  | 2,000 |  |  | 4.70% |
| 4.45% fixed-rate notes, due 2020 | 2,500 |  |  | 3.37% |  | 2,500 |  |  | 4.15% |
| 5.90% fixed-rate notes, due 2039 | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% fixed-rate notes, due 2040 | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Other long-term debt | 6 |  |  | 2.58% |  | 21 |  |  | 1.46% |
| Total | 16,006 |  |  |  |  | 16,021 |  |  |  |
| Unaccreted discount | (62 | ) |  |  |  | (65 | ) |  |  |
| Hedge accounting fair value adjustments | 193 |  |  |  |  | 245 |  |  |  |
| Total | $ | 16,137 |  |  |  |  | $ | 16,201 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |
| Current portion of long-term debt | $ | 3,752 |  |  |  |  | $ | 3,273 |  |  |  |
| Long-term debt | 12,385 |  |  |  |  | 12,928 |  |  |  |
| Total | $ | 16,137 |  |  |  |  | $ | 16,201 |  |  |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-05-22):
[0000858877-14-000014:note_history:50]
| April 26, 2014 | Amortized Cost |  | Gross Unrealized Gains |  | Gross Unrealized Losses |  | Fair Value |
| Fixed income securities: |  |  |  |  |  |  |  |
| U.S. government securities | $ | 31,675 |  |  | $ | 34 |  |  | $ | (6 | ) |  | $ | 31,703 |  |
| U.S. government agency securities | 1,060 |  |  | 2 |  |  | (1 | ) |  | 1,061 |  |
| Non-U.S. government and agency securities | 819 |  |  | 2 |  |  | (1 | ) |  | 820 |  |
| Corporate debt securities | 8,050 |  |  | 75 |  |  | (10 | ) |  | 8,115 |  |
| U.S. agency mortgage-backed securities | 567 |  |  | 3 |  |  | — |  |  | 570 |  |
| Total fixed income securities | 42,171 |  |  | 116 |  |  | (18 | ) |  | 42,269 |  |
| Publicly traded equity securities | 1,314 |  |  | 652 |  |  | (7 | ) |  | 1,959 |  |
| Total | $ | 43,485 |  |  | $ | 768 |  |  | $ | (25 | ) |  | $ | 44,228 |  |
  (was, 2014-02-20, similarity 0.6917):
[0000858877-14-000009:note_history:50]
| January 25, 2014 | Amortized Cost |  | Gross Unrealized Gains |  | Gross Unrealized Losses |  | Fair Value |
| Fixed income securities: |  |  |  |  |  |  |  |
| U.S. government securities | $ | 29,166 |  |  | $ | 30 |  |  | $ | (5 | ) |  | $ | 29,191 |  |
| U.S. government agency securities | 1,307 |  |  | 2 |  |  | — |  |  | 1,309 |  |
| Non-U.S. government and agency securities | 687 |  |  | 2 |  |  | (1 | ) |  | 688 |  |
| Corporate debt securities | 8,031 |  |  | 74 |  |  | (15 | ) |  | 8,090 |  |
| U.S. agency mortgage-backed securities | 449 |  |  | 4 |  |  | — |  |  | 453 |  |
| Total fixed income securities | 39,640 |  |  | 112 |  |  | (21 | ) |  | 39,731 |  |
| Publicly traded equity securities | 1,280 |  |  | 719 |  |  | (4 | ) |  | 1,995 |  |
| Total | $ | 40,920 |  |  | $ | 831 |  |  | $ | (25 | ) |  | $ | 41,726 |  |

- changed (2014-05-22):
[0000858877-14-000014:note_history:51]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 26, 2014 |  | April 27, 2013 |  | April 26, 2014 |  | April 27, 2013 |
| Gross realized gains | $ | 75 |  |  | $ | 55 |  |  | $ | 267 |  |  | $ | 175 |  |
| Gross realized losses | (6 | ) |  | (49 | ) |  | (33 | ) |  | (129 | ) |
| Total | $ | 69 |  |  | $ | 6 |  |  | $ | 234 |  |  | $ | 46 |  |
  (was, 2014-02-20, similarity 0.8231):
[0000858877-14-000009:note_history:51]
|  | Three Months Ended |  | Six Months Ended |
|  | January 25, 2014 |  | January 26, 2013 |  | January 25, 2014 |  | January 26, 2013 |
| Gross realized gains | $ | 97 |  |  | $ | 57 |  |  | $ | 192 |  |  | $ | 120 |  |
| Gross realized losses | (15 | ) |  | (44 | ) |  | (27 | ) |  | (80 | ) |
| Total | $ | 82 |  |  | $ | 13 |  |  | $ | 165 |  |  | $ | 40 |  |

- changed (2014-05-22):
[0000858877-14-000014:note_history:52]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 26, 2014 |  | April 27, 2013 |  | April 26, 2014 |  | April 27, 2013 |
| Net gains (losses) on investments in publicly traded equity securities | $ | 55 |  |  | $ | (2 | ) |  | $ | 199 |  |  | $ | 12 |  |
| Net gains on investments in fixed income securities | 14 |  |  | 8 |  |  | 35 |  |  | 34 |  |
| Total | $ | 69 |  |  | $ | 6 |  |  | $ | 234 |  |  | $ | 46 |  |
  (was, 2014-02-20, similarity 0.8272):
[0000858877-14-000009:note_history:52]
|  | Three Months Ended |  | Six Months Ended |
|  | January 25, 2014 |  | January 26, 2013 |  | January 25, 2014 |  | January 26, 2013 |
| Net gains on investments in publicly traded equity securities | $ | 69 |  |  | $ | 4 |  |  | $ | 144 |  |  | $ | 14 |  |
| Net gains on investments in fixed income securities | 13 |  |  | 9 |  |  | 21 |  |  | 26 |  |
| Total | $ | 82 |  |  | $ | 13 |  |  | $ | 165 |  |  | $ | 40 |  |

- changed (2014-05-22):
[0000858877-14-000014:note_history:53]
There were no impairment charges for the three months ended April 26, 2014.  For the nine months ended April 26, 2014, the realized net gains related to the Company's available-for-sale investments included impairment charges of $11 million.  These impairment charges related to publicly traded equity securities and were due to a decline in the fair value of those securities below their cost basis that were determined to be other than temporary. There were no impairment charges on available-for-sale investments for the corresponding periods in fiscal 2013.
  (was, 2014-02-20, similarity 0.7928):
[0000858877-14-000009:note_history:53]
For the second quarter and first six months of fiscal 2014, the realized net gains related to the Company's available-for-sale investments included impairment charges of $11 million for publicly traded equity securities, which were due to a decline in the fair value of those securities below their cost basis that were determined to be other than temporary. There were no impairment charges on available-for-sale investments for the corresponding periods in fiscal 2013.

- changed (2014-05-22):
[0000858877-14-000014:note_history:54]
The following tables present the breakdown of the available-for-sale investments with gross unrealized losses and the duration that those losses had been unrealized at April 26, 2014 and July 27, 2013 (in millions):
  (was, 2014-02-20, similarity 0.9709):
[0000858877-14-000009:note_history:54]
The following tables present the breakdown of the available-for-sale investments with gross unrealized losses and the duration that those losses had been unrealized at January 25, 2014 and July 27, 2013 (in millions):

- added (2014-05-22):
[0000858877-14-000014:note_history:55]
|  | UNREALIZED LOSSES LESS THAN 12 MONTHS |  | UNREALIZED LOSSES 12 MONTHS OR GREATER |  | TOTAL |
| April 26, 2014 | Fair Value |  | Gross Unrealized Losses |  | Fair Value |  | Gross Unrealized Losses |  | Fair Value |  | Gross Unrealized Losses |
| Fixed income securities: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | $ | 5,111 |  |  | $ | (6 | ) |  | $ | 8 |  |  | $ | — |  |  | $ | 5,119 |  |  | $ | (6 | ) |
| U.S. government agency securities | 396 |  |  | (1 | ) |  | 3 |  |  | — |  |  | 399 |  |  | (1 | ) |
| Non-U.S. government and agency securities | 378 |  |  | (1 | ) |  | — |  |  | — |  |  | 378 |  |  | (1 | ) |
| Corporate debt securities | 1,654 |  |  | (10 | ) |  | 52 |  |  | — |  |  | 1,706 |  |  | (10 | ) |
| U.S. agency mortgage-backed securities | 158 |  |  | — |  |  | — |  |  | — |  |  | 158 |  |  | — |  |
| Total fixed income securities | 7,697 |  |  | (18 | ) |  | 63 |  |  | — |  |  | 7,760 |  |  | (18 | ) |
| Publicly traded equity securities | 117 |  |  | (7 | ) |  | — |  |  | — |  |  | 117 |  |  | (7 | ) |
| Total | $ | 7,814 |  |  | $ | (25 | ) |  | $ | 63 |  |  | $ | — |  |  | $ | 7,877 |  |  | $ | (25 | ) |

- added (2014-05-22):
[0000858877-14-000014:note_history:56]
As of April 26, 2014, for fixed income securities that were in unrealized loss positions, the Company has determined that (i) it does not have the intent to sell any of these investments, and (ii) it is not more likely than not that it will be required to sell any of these investments before recovery of the entire amortized cost basis. In addition, as of April 26, 2014, the Company anticipates that it will recover the entire amortized cost basis of such fixed income securities and has determined that no other-than-temporary impairments associated with credit losses were required to be recognized during the nine months ended April 26, 2014.

- changed (2014-05-22):
[0000858877-14-000014:note_history:57]
The Company has evaluated its publicly traded equity securities as of April 26, 2014 and has determined that there was no indication of other-than-temporary impairments in the respective categories of unrealized losses. This determination was based on several factors, which include the length of time and extent to which fair value has been less than the cost basis, the financial condition and near-term prospects of the issuer, and the Company’s intent and ability to hold the publicly traded equity securities for a period of time sufficient to allow for any anticipated recovery in market value.
  (was, 2014-02-20, similarity 0.9899):
[0000858877-14-000009:note_history:57]
The Company has evaluated its publicly traded equity securities as of January 25, 2014 and has determined that there was no indication of other-than-temporary impairments in the respective categories of unrealized losses. This determination was based on several factors, which include the length of time and extent to which fair value has been less than the cost basis, the financial condition and near-term prospects of the issuer, and the Company’s intent and ability to hold the publicly traded equity securities for a period of time sufficient to allow for any anticipated recovery in market value.

- changed (2014-05-22):
[0000858877-14-000014:note_history:58]
The following table summarizes the maturities of the Company’s fixed income securities at April 26, 2014 (in millions):
  (was, 2014-02-20, similarity 0.9652):
[0000858877-14-000009:note_history:58]
The following table summarizes the maturities of the Company’s fixed income securities at January 25, 2014 (in millions):

- changed (2014-05-22):
[0000858877-14-000014:note_history:59]
The Company periodically engages in securities lending activities with certain of its available-for-sale investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. The average daily balance of securities lending for the nine months ended April 26, 2014 and April 27, 2013 was $1.4 billion and $0.7 billion, respectively. The Company requires collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. The Company engages in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify the Company against collateral losses. The Company did not experience any losses in connection with the secured lending of securities during the periods presented. As of April 26, 2014 and July 27, 2013, the Company had no outstanding securities lending transactions.
  (was, 2014-02-20, similarity 0.9787):
[0000858877-14-000009:note_history:59]
The Company periodically engages in securities lending activities with certain of its available-for-sale investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. The average daily balance of securities lending for the six months ended January 25, 2014 and January 26, 2013 was $0.9 billion and $0.8 billion, respectively. The Company requires collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. The Company engages in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify the Company against collateral losses. The Company did not experience any losses in connection with the secured lending of securities during the periods presented. As of January 25, 2014 and July 27, 2013, the Company had no outstanding securities lending transactions.

- removed (2014-05-22):
[0000858877-14-000009:note_history:60]
|  | UNREALIZED LOSSES LESS THAN 12 MONTHS |  | UNREALIZED LOSSES 12 MONTHS OR GREATER |  | TOTAL |
| January 25, 2014 | Fair Value |  | Gross Unrealized Losses |  | Fair Value |  | Gross Unrealized Losses |  | Fair Value |  | Gross Unrealized Losses |
| Fixed income securities: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | $ | 3,528 |  |  | $ | (5 | ) |  | $ | 8 |  |  | $ | — |  |  | $ | 3,536 |  |  | $ | (5 | ) |
| U.S. government agency securities | 170 |  |  | — |  |  | — |  |  | — |  |  | 170 |  |  | — |  |
| Non-U.S. government and agency securities | 294 |  |  | (1 | ) |  | 2 |  |  | — |  |  | 296 |  |  | (1 | ) |
| Corporate debt securities | 1,906 |  |  | (14 | ) |  | 69 |  |  | (1 | ) |  | 1,975 |  |  | (15 | ) |
| U.S. agency mortgage-backed securities | 13 |  |  | — |  |  | — |  |  | — |  |  | 13 |  |  | — |  |
| Total fixed income securities | 5,911 |  |  | (20 | ) |  | 79 |  |  | (1 | ) |  | 5,990 |  |  | (21 | ) |
| Publicly traded equity securities | 61 |  |  | (4 | ) |  | — |  |  | — |  |  | 61 |  |  | (4 | ) |
| Total | $ | 5,972 |  |  | $ | (24 | ) |  | $ | 79 |  |  | $ | (1 | ) |  | $ | 6,051 |  |  | $ | (25 | ) |

- removed (2014-05-22):
[0000858877-14-000009:note_history:61]
As of January 25, 2014, for fixed income securities that were in unrealized loss positions, the Company has determined that (i) it does not have the intent to sell any of these investments, and (ii) it is not more likely than not that it will be required to sell any of these investments before recovery of the entire amortized cost basis. In addition, as of January 25, 2014, the Company anticipates that it will recover the entire amortized cost basis of such fixed income securities and has determined that no other-than-temporary impairments associated with credit losses were required to be recognized during the six months ended January 25, 2014.


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2014-05-22):
[0000858877-14-000014:note_history:62]
|  |  |  | April 26, 2014 |  | July 27, 2013 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.25% | March 14, 2014 |  | $ | — |  |  | — |  | $ | 1,250 |  |  | 0.62% |
| Three-month LIBOR plus 0.05% | September 3, 2015 | (1) | 850 |  |  | 0.38% |  | — |  |  | — |
| Three-month LIBOR plus 0.28% | March 3, 2017 | (1) | 1,000 |  |  | 0.58% |  | — |  |  | — |
| Three-month LIBOR plus 0.50% | March 1, 2019 | (1) | 500 |  |  | 0.79% |  | — |  |  | — |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 1.625% | March 14, 2014 |  | — |  |  | — |  | 2,000 |  |  | 0.64% |
| 2.90% | November 17, 2014 |  | 500 |  |  | 3.11% |  | 500 |  |  | 3.11% |
| 5.50% | February 22, 2016 |  | 3,000 |  |  | 3.05% |  | 3,000 |  |  | 3.07% |
| 1.10% | March 3, 2017 | (1) | 2,400 |  |  | 0.56% |  | — |  |  | — |
| 3.15% | March 14, 2017 |  | 750 |  |  | 0.80% |  | 750 |  |  | 0.84% |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 4.69% |  | 2,000 |  |  | 4.70% |
| 2.125% | March 1, 2019 | (1) | 1,750 |  |  | 0.77% |  | — |  |  | — |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 2.98% |  | 2,500 |  |  | 4.15% |
| 2.90% | March 4, 2021 | (1) | 500 |  |  | 0.93% |  | — |  |  | — |
| 3.625% | March 3, 2024 | (1) | 1,000 |  |  | 1.05% |  | — |  |  | — |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Other long-term debt |  |  | 6 |  |  | 2.52% |  | 21 |  |  | 1.46% |
| Total |  |  | 20,756 |  |  |  |  | 16,021 |  |  |  |
| Unaccreted discount |  |  | (65 | ) |  |  |  | (65 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 193 |  |  |  |  | 245 |  |  |  |
| Total |  |  | $ | 20,884 |  |  |  |  | $ | 16,201 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 500 |  |  |  |  | $ | 3,273 |  |  |  |
| Long-term debt |  |  | 20,384 |  |  |  |  | 12,928 |  |  |  |
| Total |  |  | $ | 20,884 |  |  |  |  | $ | 16,201 |  |  |  |

- removed (2014-05-22):
[0000858877-14-000009:note_history:63]
|  | January 25, 2014 |  | July 27, 2013 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior Notes: |  |  |  |  |  |  |  |
| Floating-rate notes, due 2014 | $ | 1,250 |  |  | 0.58% |  | $ | 1,250 |  |  | 0.62% |
| 1.625% fixed-rate notes, due 2014 | 2,000 |  |  | 0.61% |  | 2,000 |  |  | 0.64% |
| 2.90% fixed-rate notes, due 2014 | 500 |  |  | 3.11% |  | 500 |  |  | 3.11% |
| 5.50% fixed-rate notes, due 2016 | 3,000 |  |  | 3.05% |  | 3,000 |  |  | 3.07% |
| 3.15% fixed-rate notes, due 2017 | 750 |  |  | 0.81% |  | 750 |  |  | 0.84% |
| 4.95% fixed-rate notes, due 2019 | 2,000 |  |  | 4.69% |  | 2,000 |  |  | 4.70% |
| 4.45% fixed-rate notes, due 2020 | 2,500 |  |  | 3.37% |  | 2,500 |  |  | 4.15% |
| 5.90% fixed-rate notes, due 2039 | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% fixed-rate notes, due 2040 | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Other long-term debt | 6 |  |  | 2.58% |  | 21 |  |  | 1.46% |
| Total | 16,006 |  |  |  |  | 16,021 |  |  |  |
| Unaccreted discount | (62 | ) |  |  |  | (65 | ) |  |  |
| Hedge accounting fair value adjustments | 193 |  |  |  |  | 245 |  |  |  |
| Total | $ | 16,137 |  |  |  |  | $ | 16,201 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |
| Current portion of long-term debt | $ | 3,752 |  |  |  |  | $ | 3,273 |  |  |  |
| Long-term debt | 12,385 |  |  |  |  | 12,928 |  |  |  |
| Total | $ | 16,137 |  |  |  |  | $ | 16,201 |  |  |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-05-22):
[0000858877-14-000014:note_history:64]
As of April 26, 2014, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):
  (was, 2014-02-20, similarity 0.9701):
[0000858877-14-000009:note_history:64]
As of January 25, 2014, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

- changed (2014-05-22):
[0000858877-14-000014:note_history:65]
| Fiscal Year | Amount |
| 2014 (remaining three months) | $ | — |  |
| 2015 | 502 |  |
| 2016 | 3,853 |  |
| 2017 | 4,151 |  |
| 2018 | — |  |
| Thereafter | 12,250 |  |
| Total | $ | 20,756 |  |
  (was, 2014-02-20, similarity 0.9673):
[0000858877-14-000009:note_history:65]
| Fiscal Year | Amount |
| 2014 (remaining six months) | $ | 3,250 |  |
| 2015 | 503 |  |
| 2016 | 3,003 |  |
| 2017 | 750 |  |
| 2018 | — |  |
| Thereafter | 8,500 |  |
| Total | $ | 16,006 |  |


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2014-05-22):
[0000858877-14-000014:note_history:66]
|  | April 26, 2014 |  | July 27, 2013 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 500 |  |  | 3.11 | % |  | $ | 3,273 |  |  | 0.63 | % |
| Other notes and borrowings | 8 |  |  | 2.60 | % |  | 10 |  |  | 2.52 | % |
| Total short-term debt | $ | 508 |  |  |  |  | $ | 3,283 |  |  |  |

- removed (2014-05-22):
[0000858877-14-000009:note_history:67]
|  | January 25, 2014 |  | July 27, 2013 |
|  | Amount |  | Weighted-Average Interest Rate |  | Amount |  | Weighted-Average Interest Rate |
| Current portion of long-term debt | $ | 3,752 |  |  | 0.93 | % |  | $ | 3,273 |  |  | 0.63 | % |
| Commercial paper | 1,000 |  |  | 0.12 | % |  | — |  |  | — |  |
| Other notes and borrowings | 10 |  |  | 2.55 | % |  | 10 |  |  | 2.52 | % |
| Total short-term debt | $ | 4,762 |  |  |  |  | $ | 3,283 |  |  |  |
