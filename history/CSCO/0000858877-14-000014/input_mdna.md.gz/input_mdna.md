# CSCO MD&A — 0000858877-14-000014


## mdna

[0000858877-14-000014:mdna:1]
[same as prior period, unchanged from 0000858877-14-000009:mdna:1]

[0000858877-14-000014:mdna:2]
[same as prior period, unchanged from 0000858877-14-000009:mdna:2]

[0000858877-14-000014:mdna:3]
[same as prior period, unchanged from 0000858877-14-000009:mdna:3]

[0000858877-14-000014:mdna:4]
[same as prior period, unchanged from 0000858877-14-000009:mdna:4]

[0000858877-14-000014:mdna:5]
[same as prior period, unchanged from 0000858877-14-000009:mdna:5]

[0000858877-14-000014:mdna:6]
|  | Three Months Ended |  | Nine Months Ended |  |
|  | April 26, 2014 |  | April 27, 2013 |  | Variance |  | April 26, 2014 |  | April 27, 2013 |  | Variance |  |
| Revenue | $ | 11,545 |  |  | $ | 12,216 |  |  | (5.5 | )% |  | $ | 34,785 |  |  | $ | 36,190 |  |  | (3.9 | )% |  |
| Gross margin percentage | 60.7 | % |  | 61.5 | % |  | (0.8 | ) | pts | 58.5 | % |  | 61.0 | % |  | (2.5 | ) | pts |
| Research and development | $ | 1,565 |  |  | $ | 1,542 |  |  | 1.5 | % |  | $ | 4,701 |  |  | $ | 4,425 |  |  | 6.2 | % |  |
| Sales and marketing | $ | 2,342 |  |  | $ | 2,375 |  |  | (1.4 | )% |  | $ | 7,030 |  |  | $ | 7,178 |  |  | (2.1 | )% |  |
| General and administrative | $ | 460 |  |  | $ | 530 |  |  | (13.2 | )% |  | $ | 1,426 |  |  | $ | 1,674 |  |  | (14.8 | )% |  |
| Total R&D, sales and marketing, general and administrative | $ | 4,367 |  |  | $ | 4,447 |  |  | (1.8 | )% |  | $ | 13,157 |  |  | $ | 13,277 |  |  | (0.9 | )% |  |
| Total as a percentage of revenue | 37.8 | % |  | 36.4 | % |  | 1.4 |  | pts | 37.8 | % |  | 36.7 | % |  | 1.1 |  | pts |
| Amortization of purchased intangible assets | $ | 71 |  |  | $ | 89 |  |  | (20.2 | )% |  | $ | 207 |  |  | $ | 329 |  |  | (37.1 | )% |  |
| Restructuring and other charges | $ | 26 |  |  | $ | 33 |  |  | (21.2 | )% |  | $ | 336 |  |  | $ | 105 |  |  | 220.0 | % |  |
| Operating income as a percentage of revenue | 22.0 | % |  | 24.1 | % |  | (2.1 | ) | pts | 19.2 | % |  | 23.2 | % |  | (4.0 | ) | pts |
| Income tax percentage | 17.4 | % |  | 15.9 | % |  | 1.5 |  | pts | 19.2 | % |  | 7.7 | % |  | 11.5 |  | pts |
| Net income | $ | 2,181 |  |  | $ | 2,478 |  |  | (12.0 | )% |  | $ | 5,606 |  |  | $ | 7,713 |  |  | (27.3 | )% |  |
| Net income as a percentage of revenue | 18.9 | % |  | 20.3 | % |  | (1.4 | ) | pts | 16.1 | % |  | 21.3 | % |  | (5.2 | ) | pts |
| Earnings per share—diluted | $ | 0.42 |  |  | $ | 0.46 |  |  | (8.7 | )% |  | $ | 1.06 |  |  | $ | 1.44 |  |  | (26.4 | )% |  |

[0000858877-14-000014:mdna:7]
44

[0000858877-14-000014:mdna:8]
[same as prior period, unchanged from 0000858877-14-000009:mdna:7]

[0000858877-14-000014:mdna:9]
[same as prior period, unchanged from 0000858877-14-000009:mdna:8]

[0000858877-14-000014:mdna:10]
Three Months Ended April 26, 2014 Compared with Three Months Ended April 27, 2013

[0000858877-14-000014:mdna:11]
In the third quarter of fiscal 2014, revenue decreased by 5% as compared with the third quarter of fiscal 2013. Within the total revenue change, product revenue decreased 8% and service revenue increased 3%. Total gross margin decreased by 0.8 percentage points, driven by unfavorable impacts from pricing and mix partially offset by productivity improvements.  Research and development, sales and marketing, and general and administrative expenses collectively increased as a percentage of revenue by 1.4 percentage points. Operating income as a percentage of revenue decreased by 2.1 percentage points.  Diluted earnings per share decreased by 9%, driven by a 12% decrease in net income partially offset by a decrease in our diluted share count.

[0000858877-14-000014:mdna:12]
In the third quarter of fiscal 2014, revenue decreased by $0.7 billion as compared with the third quarter of fiscal 2013. Revenue from the Americas decreased by $0.4 billion, driven by lower product revenue in most countries in this segment including the United States. While we continued to experience increased stability across Europe, EMEA revenue decreased $0.1 billion, led by product revenue declines in Russia as well as various other countries in this segment.  Revenue in our APJC segment decreased $0.2 billion, driven by product revenue declines in India and Australia.  The weakness we encountered in emerging countries throughout the world in the first six months of fiscal 2014 continued during the third quarter of fiscal 2014.  Among the emerging countries in which we experienced weakness with respect to product revenue during the third quarter of fiscal 2014 were Brazil within the Americas, India within APJC, and Russia within EMEA.

[0000858877-14-000014:mdna:13]
In the third quarter of fiscal 2014, product revenue declined across all customer markets, with the most significant decline in the service provider market.

[0000858877-14-000014:mdna:14]
From a product category perspective, the product revenue decrease of 8% year-over-year was driven in large part by the lower product revenue from sales of products within our core business. While we saw improvement in business momentum with respect to high-end routers, there was no increase in NGN Routing revenue this quarter as product transitions in this area are still in their early stages. The effects of these product transitions, combined with other challenges, led to a decrease in NGN Routing revenue of 10%. We also experienced a 6% decrease in revenue from our Switching products. The other major product categories experienced revenue changes ranging from a 26% decrease in Service Provider Video to a 29% increase in Data Center.  The decrease in revenue from our Service Provider Video products was driven largely by a decrease in revenue from sales of set-top boxes, which constitute a significant portion of this product category.  Partially offsetting the decline in product revenue was an increase in service revenue.  Service revenue in the third quarter of fiscal 2014 increased by 3%, reflecting continued slower growth which we believe was attributable to the impact of the declines in product revenue in recent quarters.

[0000858877-14-000014:mdna:15]
In summary, in the third quarter of fiscal 2014 while we saw some improved business momentum, we continued to experience many of the same challenges we experienced in the first six months of fiscal 2014, including reduced spending by our service provider customers, weakness in emerging countries, product transitions, and a conservative approach to IT-related capital spending by customers. We expect that the challenges in the emerging countries, the service provider market, and Switching and NGN Routing may continue for at least the next several quarters.

[0000858877-14-000014:mdna:16]
Nine Months Ended April 26, 2014 Compared with Nine Months Ended April 27, 2013

[0000858877-14-000014:mdna:17]
Diluted earnings per share decreased by 26%, driven by a 27% decrease in net income. A significant portion of the decrease in net income was attributable to the fiscal 2013 net tax benefit related to our settlement with the IRS. Revenue decreased 4%, with product revenue decreasing 6% and service revenue increasing 3%. Total gross margin decreased by 2.5 percentage points. As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses collectively increased by 1.1 percentage points. Operating income as a percentage of revenue decreased by 4.0 percentage points.

[0000858877-14-000014:mdna:18]
[same as prior period, unchanged from 0000858877-14-000009:mdna:17]

[0000858877-14-000014:mdna:19]
[same as prior period, unchanged from 0000858877-14-000009:mdna:18]

[0000858877-14-000014:mdna:20]
[same as prior period, unchanged from 0000858877-14-000009:mdna:19]

[0000858877-14-000014:mdna:21]
[same as prior period, unchanged from 0000858877-14-000009:mdna:20]

[0000858877-14-000014:mdna:22]
[same as prior period, unchanged from 0000858877-14-000009:mdna:21]

[0000858877-14-000014:mdna:23]
[same as prior period, unchanged from 0000858877-14-000009:mdna:22]

[0000858877-14-000014:mdna:24]
[same as prior period, unchanged from 0000858877-14-000009:mdna:23]

[0000858877-14-000014:mdna:25]
[same as prior period, unchanged from 0000858877-14-000009:mdna:24]

[0000858877-14-000014:mdna:26]
[same as prior period, unchanged from 0000858877-14-000009:mdna:25]

[0000858877-14-000014:mdna:27]
[same as prior period, unchanged from 0000858877-14-000009:mdna:26]

[0000858877-14-000014:mdna:28]
[same as prior period, unchanged from 0000858877-14-000009:mdna:27]

[0000858877-14-000014:mdna:29]
The following is a summary of our other key financial measures for the third quarter and first nine months of fiscal 2014 (in millions, except days sales outstanding in accounts receivable (DSO) and annualized inventory turns):

[0000858877-14-000014:mdna:30]
|  |  | April 26, 2014 |  | July 27, 2013 |
| Cash and cash equivalents and investments |  | $ | 50,469 |  |  | $ | 50,610 |  |
| Deferred revenue |  | $ | 13,151 |  |  | $ | 13,423 |  |
| DSO |  | 35 days |  |  | 40 days |  |
| Inventories |  | $ | 1,528 |  |  | $ | 1,476 |  |
| Annualized inventory turns |  | 11.8 |  |  | 13.8 |  |

[0000858877-14-000014:mdna:31]
|  |  | Nine Months Ended |
|  |  | April 26, 2014 |  | April 27, 2013 |
| Cash provided by operating activities |  | $ | 8,720 |  |  | $ | 8,908 |  |
| Repurchases of common stock—stock repurchase program |  | $ | 8,025 |  |  | $ | 1,613 |  |
| Dividends |  | $ | 2,784 |  |  | $ | 2,392 |  |

[0000858877-14-000014:mdna:32]
[same as prior period, unchanged from 0000858877-14-000009:mdna:55]

[0000858877-14-000014:mdna:33]
[same as prior period, unchanged from 0000858877-14-000009:mdna:31]

[0000858877-14-000014:mdna:34]
[same as prior period, unchanged from 0000858877-14-000009:mdna:32]

[0000858877-14-000014:mdna:35]
[same as prior period, unchanged from 0000858877-14-000009:mdna:33]

[0000858877-14-000014:mdna:36]
[same as prior period, unchanged from 0000858877-14-000009:mdna:34]

[0000858877-14-000014:mdna:37]
[same as prior period, unchanged from 0000858877-14-000009:mdna:35]

[0000858877-14-000014:mdna:38]
[same as prior period, unchanged from 0000858877-14-000009:mdna:36]

[0000858877-14-000014:mdna:39]
[same as prior period, unchanged from 0000858877-14-000009:mdna:37]

[0000858877-14-000014:mdna:40]
[same as prior period, unchanged from 0000858877-14-000009:mdna:38]

[0000858877-14-000014:mdna:41]
[same as prior period, unchanged from 0000858877-14-000009:mdna:39]

[0000858877-14-000014:mdna:42]
[same as prior period, unchanged from 0000858877-14-000009:mdna:40]

[0000858877-14-000014:mdna:43]
[same as prior period, unchanged from 0000858877-14-000009:mdna:41]

[0000858877-14-000014:mdna:44]
[same as prior period, unchanged from 0000858877-14-000009:mdna:42]

[0000858877-14-000014:mdna:45]
[same as prior period, unchanged from 0000858877-14-000009:mdna:43]

[0000858877-14-000014:mdna:46]
As our business and offerings evolve over time, our pricing practices may be required to be modified accordingly, which could result in changes in selling prices, including both VSOE and ESP, in subsequent periods. There were no material impacts during the third quarter of fiscal 2014 nor do we currently expect a material impact in the next 12 months on our revenue recognition due to any changes in our VSOE, TPE, or ESP.

[0000858877-14-000014:mdna:47]
[same as prior period, unchanged from 0000858877-14-000009:mdna:67]

[0000858877-14-000014:mdna:48]
[same as prior period, unchanged from 0000858877-14-000009:mdna:45]

[0000858877-14-000014:mdna:49]
[same as prior period, unchanged from 0000858877-14-000009:mdna:46]

[0000858877-14-000014:mdna:50]
Revenue deferrals relate to the timing of revenue recognition for specific transactions based on financing arrangements, service, support, and other factors. Financing arrangements may include sales-type, direct-financing, and operating leases, loans, and guarantees of third-party financing. Our deferred revenue for products was $4.4 billion and $4.0 billion as of April 26, 2014 and July 27, 2013, respectively. Technical support services revenue is deferred and recognized ratably over the period during which the services are to be performed, which typically is from one to three years. Advanced services revenue is recognized upon delivery or completion of performance. Our deferred revenue for services was $8.7 billion and $9.4 billion as of April 26, 2014 and July 27, 2013, respectively.

[0000858877-14-000014:mdna:51]
[same as prior period, unchanged from 0000858877-14-000009:mdna:48]

[0000858877-14-000014:mdna:52]
[same as prior period, unchanged from 0000858877-14-000009:mdna:49]

[0000858877-14-000014:mdna:53]
[same as prior period, unchanged from 0000858877-14-000009:mdna:50]

[0000858877-14-000014:mdna:54]
|  |  | April 26, 2014 |  | July 27, 2013 |
| Allowance for doubtful accounts |  | $ | 247 |  |  | $ | 228 |  |
| Percentage of gross accounts receivable |  | 5.3 | % |  | 4.0 | % |
| Allowance for credit loss—lease receivables |  | $ | 249 |  |  | $ | 238 |  |
| Percentage of gross lease receivables |  | 6.6 | % |  | 6.3 | % |
| Allowance for credit loss—loan receivables |  | $ | 92 |  |  | $ | 86 |  |
| Percentage of gross loan receivables |  | 5.7 | % |  | 5.2 | % |

[0000858877-14-000014:mdna:55]
[same as prior period, unchanged from 0000858877-14-000009:mdna:52]

[0000858877-14-000014:mdna:56]
[same as prior period, unchanged from 0000858877-14-000009:mdna:53]

[0000858877-14-000014:mdna:57]
A reserve for future sales returns is established based on historical trends in product return rates. The reserve for future sales returns as of April 26, 2014 and July 27, 2013 was $135 million and $119 million, respectively, and was recorded as a reduction of our accounts receivable.  If the actual future returns were to deviate from the historical data on which the reserve had been established, our revenue could be adversely affected.

[0000858877-14-000014:mdna:58]
[same as prior period, unchanged from 0000858877-14-000009:mdna:56]

[0000858877-14-000014:mdna:59]
[same as prior period, unchanged from 0000858877-14-000009:mdna:57]

[0000858877-14-000014:mdna:60]
[same as prior period, unchanged from 0000858877-14-000009:mdna:58]

[0000858877-14-000014:mdna:61]
Our inventory balance was $1.5 billion as of both April 26, 2014 and July 27, 2013. Inventory is written down based on excess and obsolete inventories determined primarily by future demand forecasts. Inventory write-downs are measured as the difference between the cost of the inventory and market, based upon assumptions about future demand, and are charged to the provision for inventory, which is a component of our cost of sales. At the point of the loss recognition, a new, lower cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis.

[0000858877-14-000014:mdna:62]
We record a liability for firm, noncancelable, and unconditional purchase commitments with contract manufacturers and suppliers for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of April 26, 2014, the liability for these purchase commitments was $156 million, compared with $172 million as of July 27, 2013, and was included in other current liabilities. Our provision for inventory was $53 million and $92 million for the first nine months of fiscal 2014 and 2013, respectively. The provision for the liability related to purchase commitments with contract manufacturers and suppliers was $94 million and $76 million for the first nine months of fiscal 2014 and 2013, respectively.

[0000858877-14-000014:mdna:63]
[same as prior period, unchanged from 0000858877-14-000009:mdna:61]

[0000858877-14-000014:mdna:64]
Loss Contingencies and Product Warranties

[0000858877-14-000014:mdna:65]
We are subject to the possibility of various losses arising in the ordinary course of business. We consider the likelihood of impairment of an asset or the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated. We regularly evaluate information available to us to determine whether such accruals should be adjusted and whether new accruals are required.

[0000858877-14-000014:mdna:66]
Third parties, including customers, have in the past and may in the future assert claims or initiate litigation related to exclusive patent, copyright, trademark, and other intellectual property rights to technologies and related standards that are relevant to us. These assertions have increased over time as a result of our growth and the general increase in the pace of patent claims assertions, particularly in the United States. If any infringement or other intellectual property claim made against us by any third party is successful, or if we fail to develop non-infringing technology or license the proprietary rights on commercially reasonable terms and conditions, our business, operating results, and financial condition could be materially and adversely affected.

[0000858877-14-000014:mdna:67]
We have recorded a liability for the expected remediation cost for certain products sold in prior fiscal years containing memory components manufactured by a single supplier between 2005 and 2010. In February 2014, on the basis of the growing number of failures as described in Note 12 (f) to the Consolidated Financial Statements, we decided to expand our approach, which resulted in an additional charge to product cost of sales of $655 million being recorded for the second quarter of fiscal 2014.  Estimating this liability is complex and subjective, and if we experience changes in a number of underlying assumptions and estimates such as a change in claims compared with our expectations, or if the cost of servicing these claims is different than expected, our estimated liability may be impacted.

[0000858877-14-000014:mdna:68]
Our liability for product warranties, included in other current liabilities, was $430 million as of April 26, 2014, compared with $402 million as of July 27, 2013. See Note 12 to the Consolidated Financial Statements. Our products are generally covered by a warranty for periods ranging from 90 days to five years, and for some products we provide a limited lifetime warranty. We accrue for warranty costs as part of our cost of sales based on associated material costs, technical support labor costs, and associated overhead. Material cost is estimated based primarily upon historical trends in the volume of product returns within the warranty period and the cost to repair or replace the equipment. Technical support labor cost is estimated based primarily upon historical trends in the rate of customer cases and the cost to support the customer cases within the warranty period. Overhead cost is applied based on estimated time to support warranty activities.

[0000858877-14-000014:mdna:69]
[same as prior period, unchanged from 0000858877-14-000009:mdna:68]

[0000858877-14-000014:mdna:70]
[same as prior period, unchanged from 0000858877-14-000009:mdna:69]

[0000858877-14-000014:mdna:71]
The provision for product warranties during the first nine months of fiscal 2014 and 2013 was $532 million and $480 million, respectively.  See Note 12 to the Consolidated Financial Statements.  If we experience an increase in warranty claims compared with our historical experience, or if the cost of servicing warranty claims is greater than expected, our profitability could be adversely affected.

[0000858877-14-000014:mdna:72]
[same as prior period, unchanged from 0000858877-14-000009:mdna:71]

[0000858877-14-000014:mdna:73]
[same as prior period, unchanged from 0000858877-14-000009:mdna:72]

[0000858877-14-000014:mdna:74]
|  | Nine Months Ended |
|  | April 26, 2014 |  | April 27, 2013 |  | Variance |
| Share-based compensation expense | $ | 1,009 |  |  | $ | 880 |  |  | $ | 129 |  |

[0000858877-14-000014:mdna:75]
[same as prior period, unchanged from 0000858877-14-000009:mdna:74]

[0000858877-14-000014:mdna:76]
[same as prior period, unchanged from 0000858877-14-000009:mdna:75]

[0000858877-14-000014:mdna:77]
[same as prior period, unchanged from 0000858877-14-000009:mdna:76]

[0000858877-14-000014:mdna:78]
[same as prior period, unchanged from 0000858877-14-000009:mdna:77]

[0000858877-14-000014:mdna:79]
Our fixed income and publicly traded equity securities, collectively, are reflected in the Consolidated Balance Sheets at a fair value of $44.2 billion as of April 26, 2014, compared with $42.7 billion as of July 27, 2013. Our fixed income investment portfolio, as of April 26, 2014, consisted primarily of high-quality investment-grade securities. See Note 8 to the Consolidated Financial Statements.

[0000858877-14-000014:mdna:80]
[same as prior period, unchanged from 0000858877-14-000009:mdna:79]

[0000858877-14-000014:mdna:81]
[same as prior period, unchanged from 0000858877-14-000009:mdna:80]

[0000858877-14-000014:mdna:82]
[same as prior period, unchanged from 0000858877-14-000009:mdna:83]

[0000858877-14-000014:mdna:83]
[same as prior period, unchanged from 0000858877-14-000009:mdna:84]

[0000858877-14-000014:mdna:84]
The inputs and fair value are reviewed for reasonableness, may be further validated by comparison to publicly available information, and could be adjusted based on market indices or other information that management deems material to its estimate of fair value. The assessment of fair value can be difficult and subjective. However, given the relative reliability of the inputs we use to value our investment portfolio, and because substantially all of our valuation inputs are obtained using quoted market prices for similar or identical assets, we do not believe that the nature of estimates and assumptions affected by levels of subjectivity and judgment was material to the valuation of the investment portfolio as of April 26, 2014. We had no Level 3 investments in our total portfolio as of April 26, 2014.

[0000858877-14-000014:mdna:85]
[same as prior period, unchanged from 0000858877-14-000009:mdna:86]

[0000858877-14-000014:mdna:86]
[same as prior period, unchanged from 0000858877-14-000009:mdna:87]

[0000858877-14-000014:mdna:87]
[same as prior period, unchanged from 0000858877-14-000009:mdna:88]

[0000858877-14-000014:mdna:88]
[same as prior period, unchanged from 0000858877-14-000009:mdna:89]

[0000858877-14-000014:mdna:89]
For the first nine months of fiscal 2014, impairment charges of $11 million on investments in publicly traded equity securities were recognized in earnings, while there were no such impairment charges in the first nine months of fiscal 2013.  There were no impairment charges on our investments in fixed income securities in the first nine months of fiscal 2014 and 2013.  Our ongoing consideration of all the factors described previously could result in additional impairment charges in the future, which could adversely affect our net income.

[0000858877-14-000014:mdna:90]
We also have investments in privately held companies, some of which are in the startup or development stages. As of April 26, 2014, our investments in privately held companies were $923 million, compared with $833 million as of July 27, 2013, and were included in other assets. See Note 6 to the Consolidated Financial Statements. We monitor these investments for events or circumstances indicative of potential impairment, and we make appropriate reductions in carrying values if we determine that an impairment charge is required, based primarily on the financial condition and near-term prospects of these companies. These investments are inherently risky because the markets for the technologies or products these companies are developing are typically in the early stages and may never materialize. Our impairment charges on investments in privately held companies were $10 million and $23 million for the first nine months of fiscal 2014 and 2013, respectively.

[0000858877-14-000014:mdna:91]
[same as prior period, unchanged from 0000858877-14-000009:mdna:92]

[0000858877-14-000014:mdna:92]
[same as prior period, unchanged from 0000858877-14-000009:mdna:93]

[0000858877-14-000014:mdna:93]
The goodwill recorded in the Consolidated Balance Sheets as of April 26, 2014 and July 27, 2013 was $24.1 billion and $21.9 billion, respectively. The increase in goodwill for the first nine months of fiscal 2014 was due in large part to our acquisition of Sourcefire, Inc.  In response to changes in industry and market conditions, we could be required to strategically realign our resources and consider restructuring, disposing of, or otherwise exiting businesses, which could result in an impairment of goodwill. There was no impairment of goodwill in the first nine months of fiscal 2014 and 2013.

[0000858877-14-000014:mdna:94]
51

[0000858877-14-000014:mdna:95]
[same as prior period, unchanged from 0000858877-14-000009:mdna:96]

[0000858877-14-000014:mdna:96]
[same as prior period, unchanged from 0000858877-14-000009:mdna:97]

[0000858877-14-000014:mdna:97]
We make judgments about the recoverability of purchased intangible assets with finite lives whenever events or changes in circumstances indicate that an impairment may exist. Recoverability of purchased intangible assets with finite lives is measured by comparing the carrying amount of the asset to the future undiscounted cash flows the asset is expected to generate. We review indefinite-lived intangible assets for impairment annually or whenever events or changes in circumstances indicate the carrying value may not be recoverable. Recoverability of indefinite-lived intangible assets is measured by comparing the carrying amount of the asset to the future discounted cash flows the asset is expected to generate. If the asset is considered to be impaired, the amount of any impairment is measured as the difference between the carrying value and the fair value of the impaired asset. Assumptions and estimates about future values and remaining useful lives of our purchased intangible assets are complex and subjective. They can be affected by a variety of factors, including external factors such as industry and economic trends and internal factors such as changes in our business strategy and our internal forecasts. There were no impairment charges related to purchased intangible assets for the first nine months of fiscal 2014 and 2013. Our ongoing consideration of all the factors described previously could result in additional impairment charges in the future, which could adversely affect our net income.

[0000858877-14-000014:mdna:98]
[same as prior period, unchanged from 0000858877-14-000009:mdna:99]

[0000858877-14-000014:mdna:99]
We are subject to income taxes in the United States and numerous foreign jurisdictions. Our effective tax rates differ from the statutory rate, primarily due to the tax impact of state taxes, foreign operations, research and development (R&D) tax credits, domestic manufacturing deductions, tax audit settlements, nondeductible compensation, international realignments, and transfer pricing adjustments. Our effective tax rate was 17.4% and 15.9% in the third quarter of fiscal 2014 and 2013, respectively.  Our effective tax rate was 19.2% and 7.7% in the first nine months of fiscal 2014 and 2013, respectively.

[0000858877-14-000014:mdna:100]
[same as prior period, unchanged from 0000858877-14-000009:mdna:101]

[0000858877-14-000014:mdna:101]
[same as prior period, unchanged from 0000858877-14-000009:mdna:102]

[0000858877-14-000014:mdna:102]
[same as prior period, unchanged from 0000858877-14-000009:mdna:103]

[0000858877-14-000014:mdna:103]
[same as prior period, unchanged from 0000858877-14-000009:mdna:129]

[0000858877-14-000014:mdna:104]
[same as prior period, unchanged from 0000858877-14-000009:mdna:104]

[0000858877-14-000014:mdna:105]
[same as prior period, unchanged from 0000858877-14-000009:mdna:105]

[0000858877-14-000014:mdna:106]
[same as prior period, unchanged from 0000858877-14-000009:mdna:106]

[0000858877-14-000014:mdna:107]
[same as prior period, unchanged from 0000858877-14-000009:mdna:107]

[0000858877-14-000014:mdna:108]
[same as prior period, unchanged from 0000858877-14-000009:mdna:108]

[0000858877-14-000014:mdna:109]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 26, 2014 |  | April 27, 2013 |  | Variancein Dollars |  | Variance in Percent |  | April 26, 2014 |  | April 27, 2013 |  | Variancein Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 8,820 |  |  | $ | 9,559 |  |  | $ | (739 | ) |  | (7.7 | )% |  | $ | 26,640 |  |  | $ | 28,293 |  |  | $ | (1,653 | ) |  | (5.8 | )% |
| Percentage of revenue | 76.4 | % |  | 78.2 | % |  |  |  |  |  | 76.6 | % |  | 78.2 | % |  |  |  |  |
| Service | 2,725 |  |  | 2,657 |  |  | 68 |  |  | 2.6 | % |  | 8,145 |  |  | 7,897 |  |  | 248 |  |  | 3.1 | % |
| Percentage of revenue | 23.6 | % |  | 21.8 | % |  |  |  |  |  | 23.4 | % |  | 21.8 | % |  |  |  |  |
| Total | $ | 11,545 |  |  | $ | 12,216 |  |  | $ | (671 | ) |  | (5.5 | )% |  | $ | 34,785 |  |  | $ | 36,190 |  |  | $ | (1,405 | ) |  | (3.9 | )% |

[0000858877-14-000014:mdna:110]
[same as prior period, unchanged from 0000858877-14-000009:mdna:110]

[0000858877-14-000014:mdna:111]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 26, 2014 |  | April 27, 2013 |  | Variancein Dollars |  | Variance in Percent |  | April 26, 2014 |  | April 27, 2013 |  | Variancein Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 6,689 |  |  | $ | 7,127 |  |  | $ | (438 | ) |  | (6.1 | )% |  | $ | 20,465 |  |  | $ | 21,286 |  |  | $ | (821 | ) |  | (3.9 | )% |
| Percentage of revenue | 57.9 | % |  | 58.4 | % |  |  |  |  |  | 58.8 | % |  | 58.9 | % |  |  |  |  |
| EMEA | 3,068 |  |  | 3,131 |  |  | (63 | ) |  | (2.0 | )% |  | 8,897 |  |  | 9,065 |  |  | (168 | ) |  | (1.9 | )% |
| Percentage of revenue | 26.6 | % |  | 25.6 | % |  |  |  |  |  | 25.6 | % |  | 25.0 | % |  |  |  |  |
| APJC | 1,788 |  |  | 1,958 |  |  | (170 | ) |  | (8.7 | )% |  | 5,423 |  |  | 5,839 |  |  | (416 | ) |  | (7.1 | )% |
| Percentage of revenue | 15.5 | % |  | 16.0 | % |  |  |  |  |  | 15.6 | % |  | 16.1 | % |  |  |  |  |
| Total | $ | 11,545 |  |  | $ | 12,216 |  |  | $ | (671 | ) |  | (5.5 | )% |  | $ | 34,785 |  |  | $ | 36,190 |  |  | $ | (1,405 | ) |  | (3.9 | )% |

[0000858877-14-000014:mdna:112]
Three Months Ended April 26, 2014 Compared with Three Months Ended April 27, 2013

[0000858877-14-000014:mdna:113]
For the third quarter of fiscal 2014, as compared with the third quarter of fiscal 2013, total revenue decreased by 5%. Within the total revenue change, product revenue decreased by 8%, while service revenue increased by 3%. Our total revenue reflected declines across all geographic segments. We also experienced product revenue declines across all customer markets.

[0000858877-14-000014:mdna:114]
Across our geographic segments, product revenue for most of our emerging countries experienced a decline. The emerging countries of Brazil, Russia, India, China, and Mexico (“BRICM”), in the aggregate, experienced a 13% product revenue decline, with declines in the service provider and commercial markets, collectively.

[0000858877-14-000014:mdna:115]
[same as prior period, unchanged from 0000858877-14-000009:mdna:115]

[0000858877-14-000014:mdna:116]
[same as prior period, unchanged from 0000858877-14-000009:mdna:116]

[0000858877-14-000014:mdna:117]
[same as prior period, unchanged from 0000858877-14-000009:mdna:117]

[0000858877-14-000014:mdna:118]
[same as prior period, unchanged from 0000858877-14-000009:mdna:118]

[0000858877-14-000014:mdna:119]
Nine Months Ended April 26, 2014 Compared with Nine Months Ended April 27, 2013

[0000858877-14-000014:mdna:120]
For the first nine months of fiscal 2014, as compared with the first nine months of fiscal 2013, revenue decreased by 4%.  Product revenue decreased by 6%, while service revenue increased by 3%. The decrease in product revenue reflected declines across all geographic segments as well as across all customer markets. Service revenues experienced slower growth in our Americas and APJC geographic segments while it grew slightly faster in the EMEA segment.

[0000858877-14-000014:mdna:121]
[same as prior period, unchanged from 0000858877-14-000009:mdna:121]

[0000858877-14-000014:mdna:122]
[same as prior period, unchanged from 0000858877-14-000009:mdna:122]

[0000858877-14-000014:mdna:123]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 26, 2014 |  | April 27, 2013 |  | Variance in Dollars |  | Variance in Percent |  | April 26, 2014 |  | April 27, 2013 |  | Variancein Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 4,925 |  |  | $ | 5,364 |  |  | $ | (439 | ) |  | (8.2 | )% |  | $ | 15,134 |  |  | $ | 16,067 |  |  | $ | (933 | ) |  | (5.8 | )% |
| Percentage of product revenue | 55.9 | % |  | 56.1 | % |  |  |  |  |  | 56.8 | % |  | 56.8 | % |  |  |  |  |
| EMEA | 2,472 |  |  | 2,590 |  |  | (118 | ) |  | (4.6 | )% |  | 7,181 |  |  | 7,469 |  |  | (288 | ) |  | (3.9 | )% |
| Percentage of product revenue | 28.0 | % |  | 27.1 | % |  |  |  |  |  | 27.0 | % |  | 26.4 | % |  |  |  |  |
| APJC | 1,423 |  |  | 1,605 |  |  | (182 | ) |  | (11.3 | )% |  | 4,325 |  |  | 4,757 |  |  | (432 | ) |  | (9.1 | )% |
| Percentage of product revenue | 16.1 | % |  | 16.8 | % |  |  |  |  |  | 16.2 | % |  | 16.8 | % |  |  |  |  |
| Total | $ | 8,820 |  |  | $ | 9,559 |  |  | $ | (739 | ) |  | (7.7 | )% |  | $ | 26,640 |  |  | $ | 28,293 |  |  | $ | (1,653 | ) |  | (5.8 | )% |

[0000858877-14-000014:mdna:124]
[same as prior period, unchanged from 0000858877-14-000009:mdna:124]

[0000858877-14-000014:mdna:125]
Three Months Ended April 26, 2014 Compared with Three Months Ended April 27, 2013

[0000858877-14-000014:mdna:126]
Product revenue in the Americas segment decreased by 8%.  This product revenue decrease was across all of our customer markets, led by a significant decline in the service provider market.  From a country perspective, product revenue decreased by 8% in the United States and 13% in both Canada and Brazil, partially offset by an increase of 8% in Mexico.

[0000858877-14-000014:mdna:127]
Nine Months Ended April 26, 2014 Compared with Nine Months Ended April 27, 2013

[0000858877-14-000014:mdna:128]
The decrease in product revenue in the Americas segment of 6% reflected a product revenue decrease across all of our customer markets, led by a product revenue decline in the service provider market.  From a country perspective, product revenue decreased by 6% in the United States, 8% in Canada, 11% in Brazil, and 1% in Mexico.

[0000858877-14-000014:mdna:129]
[same as prior period, unchanged from 0000858877-14-000009:mdna:132]

[0000858877-14-000014:mdna:130]
Three Months Ended April 26, 2014 Compared with Three Months Ended April 27, 2013

[0000858877-14-000014:mdna:131]
Product revenue in the EMEA segment decreased by 5%. We experienced declines in product revenue across all of our customer markets, led by a decline in the service provider market. Similar to what we observed in our other geographic segments, we experienced weakness with respect to product revenue in the emerging countries within EMEA. From an individual country perspective, product revenue decreased by 29% in Russia, 12% in Italy, 5% in France, and 3% in the United Kingdom, partially offset by an increase of 22% in Spain, 7% in the Netherlands, and 6% in Germany.

[0000858877-14-000014:mdna:132]
[same as prior period, unchanged from 0000858877-14-000009:mdna:130]

[0000858877-14-000014:mdna:133]
[same as prior period, unchanged from 0000858877-14-000009:mdna:131]

[0000858877-14-000014:mdna:134]
Nine Months Ended April 26, 2014 Compared with Nine Months Ended April 27, 2013

[0000858877-14-000014:mdna:135]
Product revenue in the EMEA segment decreased by 4%, driven by declines in the service provider market and, to a lesser extent, in the enterprise market. We experienced slower product revenue growth in the public sector and commercial markets. From an individual country perspective, product revenue decreased by 22% in Russia, 9% in France, and 3% in the United Kingdom, partially offset by an increase of 6% in the Netherlands.

[0000858877-14-000014:mdna:136]
[same as prior period, unchanged from 0000858877-14-000009:mdna:137]

[0000858877-14-000014:mdna:137]
Three Months Ended April 26, 2014 Compared with Three Months Ended April 27, 2013

[0000858877-14-000014:mdna:138]
Product revenue in the APJC segment decreased by 11%. The product revenue decline was across most of our customer markets in the APJC segment, led by declines in the service provider and commercial markets, and to a lesser degree, a decline in the enterprise market. We continued to experience declines in many of the emerging countries in this segment, most notably in India, which experienced a year-over-year product revenue decline of 29%.  Other countries that contributed to the weakness in this segment included Australia, Japan and China, which experienced year-over-year product revenue declines of 28%, 7% and 4%, respectively.

[0000858877-14-000014:mdna:139]
Nine Months Ended April 26, 2014 Compared with Nine Months Ended April 27, 2013

[0000858877-14-000014:mdna:140]
Product revenue in the APJC segment decreased by 9%. The product revenue decline was across all of our customer markets in the APJC segment, led by a product revenue decline in the service provider market. From a country perspective, we experienced year-over-year product revenue declines of 24% in India, 12% in both Japan and Australia, and 7% in China.

[0000858877-14-000014:mdna:141]
[same as prior period, unchanged from 0000858877-14-000009:mdna:174]

[0000858877-14-000014:mdna:142]
[same as prior period, unchanged from 0000858877-14-000009:mdna:143]

[0000858877-14-000014:mdna:143]
[same as prior period, unchanged from 0000858877-14-000009:mdna:144]

[0000858877-14-000014:mdna:144]
[same as prior period, unchanged from 0000858877-14-000009:mdna:145]

[0000858877-14-000014:mdna:145]
In addition to the primary view on a geographic basis, we also prepare financial information related to groups of similar products and customer markets for various purposes. Our product categories consist of the following categories (with subcategories in parentheses): Switching (fixed switching, modular switching, and storage); NGN Routing (high-end routers, mid-range and low-end routers, and other NGN Routing products); Service Provider Video (infrastructure, video software and solutions); Collaboration (unified communications, Cisco TelePresence, and conferencing); Data Center; Wireless; Security; and Other Products. The Other Products category consists primarily of emerging technology products and other networking products.

[0000858877-14-000014:mdna:146]
[same as prior period, unchanged from 0000858877-14-000009:mdna:147]

[0000858877-14-000014:mdna:147]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 26, 2014 |  | April 27, 2013 |  | Variance in Dollars |  | Variance in Percent |  | April 26, 2014 |  | April 27, 2013 |  | Variancein Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Switching | $ | 3,381 |  |  | $ | 3,601 |  |  | $ | (220 | ) |  | (6.1 | )% |  | $ | 10,406 |  |  | $ | 10,962 |  |  | $ | (556 | ) |  | (5.1 | )% |
| Percentage of product revenue | 38.3 | % |  | 37.7 | % |  |  |  |  |  | 39.1 | % |  | 38.8 | % |  |  |  |  |
| NGN Routing | 1,935 |  |  | 2,145 |  |  | (210 | ) |  | (9.8 | )% |  | 5,719 |  |  | 6,147 |  |  | (428 | ) |  | (7.0 | )% |
| Percentage of product revenue | 21.9 | % |  | 22.4 | % |  |  |  |  |  | 21.5 | % |  | 21.7 | % |  |  |  |  |
| Service Provider Video | 961 |  |  | 1,299 |  |  | (338 | ) |  | (26.0 | )% |  | 2,905 |  |  | 3,670 |  |  | (765 | ) |  | (20.8 | )% |
| Percentage of product revenue | 10.9 | % |  | 13.6 | % |  |  |  |  |  | 10.9 | % |  | 13.0 | % |  |  |  |  |
| Collaboration | 892 |  |  | 1,013 |  |  | (121 | ) |  | (11.9 | )% |  | 2,800 |  |  | 2,978 |  |  | (178 | ) |  | (6.0 | )% |
| Percentage of product revenue | 10.1 | % |  | 10.6 | % |  |  |  |  |  | 10.5 | % |  | 10.5 | % |  |  |  |  |
| Data Center | 662 |  |  | 515 |  |  | 147 |  |  | 28.5 | % |  | 1,868 |  |  | 1,480 |  |  | 388 |  |  | 26.2 | % |
| Percentage of product revenue | 7.5 | % |  | 5.4 | % |  |  |  |  |  | 7.0 | % |  | 5.2 | % |  |  |  |  |
| Wireless | 553 |  |  | 539 |  |  | 14 |  |  | 2.6 | % |  | 1,604 |  |  | 1,573 |  |  | 31 |  |  | 2.0 | % |
| Percentage of product revenue | 6.3 | % |  | 5.6 | % |  |  |  |  |  |  |  | 6.0 | % |  | 5.6 | % |  |  |  |  |  |  |
| Security | 361 |  |  | 327 |  |  | 34 |  |  | 10.4 | % |  | 1,119 |  |  | 1,002 |  |  | 117 |  |  | 11.7 | % |
| Percentage of product revenue | 4.1 | % |  | 3.4 | % |  |  |  |  |  | 4.2 | % |  | 3.5 | % |  |  |  |  |
| Other | 75 |  |  | 120 |  |  | (45 | ) |  | (37.5 | )% |  | 219 |  |  | 481 |  |  | (262 | ) |  | (54.5 | )% |
| Percentage of product revenue | 0.9 | % |  | 1.3 | % |  |  |  |  |  | 0.8 | % |  | 1.7 | % |  |  |  |  |
| Total | $ | 8,820 |  |  | $ | 9,559 |  |  | $ | (739 | ) |  | (7.7 | )% |  | $ | 26,640 |  |  | $ | 28,293 |  |  | $ | (1,653 | ) |  | (5.8 | )% |

[0000858877-14-000014:mdna:148]
Certain reclassifications have been made to the prior-period amounts to conform to the current period’s presentation.

[0000858877-14-000014:mdna:149]
[same as prior period, unchanged from 0000858877-14-000009:mdna:150]

[0000858877-14-000014:mdna:150]
Three Months Ended April 26, 2014 Compared with Three Months Ended April 27, 2013

[0000858877-14-000014:mdna:151]
Revenue in our Switching product category decreased by 6%, or $220 million. Revenue from our modular switches declined by 12%, or $152 million, driven primarily by lower sales of Cisco Catalyst 6000 Series Switches. We also experienced a decrease in revenue from our LAN fixed-configuration switches of 2%, or $47 million, resulting from lower sales of our existing products partially offset by the higher sales of our newer Cisco Catalyst 3850 Series Switches and the adoption of Cisco Nexus 6000 Series Switches.  Revenue in our Switching product category was also negatively impacted by an 18% decrease in sales of storage products within this category.

[0000858877-14-000014:mdna:152]
[same as prior period, unchanged from 0000858877-14-000009:mdna:153]

[0000858877-14-000014:mdna:153]
[same as prior period, unchanged from 0000858877-14-000009:mdna:154]

[0000858877-14-000014:mdna:154]
Nine Months Ended April 26, 2014 Compared with Nine Months Ended April 27, 2013

[0000858877-14-000014:mdna:155]
The decrease in revenue in our Switching product category was driven by a 10%, or $418 million, decrease in revenue from our modular switches, and to a lesser degree, a 1%, or $91 million, decrease in revenue from our LAN fixed-configuration switches and a 13%, or $47 million, decrease in revenue from storage products within this category. Revenue from our modular switches decreased due to lower sales of Cisco Catalyst 6000 Series Switches. The decline in revenue from LAN fixed-configuration switches was due to lower sales of most of our Cisco Catalyst Series Switches and Cisco Nexus Series Switches, partially offset by the continued adoption of Cisco Catalyst 3850 Series Switches and Cisco Nexus 6000 Series Switches.

[0000858877-14-000014:mdna:156]
[same as prior period, unchanged from 0000858877-14-000009:mdna:157]

[0000858877-14-000014:mdna:157]
Three Months Ended April 26, 2014 Compared with Three Months Ended April 27, 2013

[0000858877-14-000014:mdna:158]
The decrease in revenue in our NGN Routing product category of 10%, or $210 million, was driven by a 17%, or $125 million, decrease in revenue from our midrange and low-end router products; a 5%, or $68 million, decrease in revenue from high-end router products; and an 11%, or $17 million, decrease in revenue from other NGN Routing products. The decrease in revenue from our midrange and low-end router products was driven by lower sales of our Cisco Integrated Services Routers (ISR) products. Revenue from our high-end products decreased due to lower sales of Cisco CRS-3 Carrier Routing System products and our legacy high-end router products, partially offset by increased sales of our Cisco Aggregation Services Routers (ASR) edge products. Revenue from other NGN Routing products decreased due to lower sales of certain optical networking products.

[0000858877-14-000014:mdna:159]
Nine Months Ended April 26, 2014 Compared with Nine Months Ended April 27, 2013

[0000858877-14-000014:mdna:160]
Revenue in our NGN Routing product category decreased by 7%, or $428 million.  Revenue from high-end router products decreased by 7%, or $239 million, driven by lower sales of our Cisco CRS-3 Carrier Routing System products, and also lower sales of our legacy high-end router products.  These decreases were partially offset by sales growth for several Cisco ASR products.

[0000858877-14-000014:mdna:161]
We also saw declines in revenue from our midrange and low-end router products and from other NGN Routing products.  The decreases in revenue from our midrange and low-end router products were driven by lower sales of our ISR products. Revenue from other NGN Routing products decreased due to lower sales of certain optical networking products.

[0000858877-14-000014:mdna:162]
[same as prior period, unchanged from 0000858877-14-000009:mdna:164]

[0000858877-14-000014:mdna:163]
Three Months Ended April 26, 2014 Compared with Three Months Ended April 27, 2013

[0000858877-14-000014:mdna:164]
Revenue in our Service Provider Video product category decreased by 26%, or $338 million, with the largest driver of the decline being the 28%, or $279 million, decrease in sales of our Service Provider Video infrastructure products. The revenue decline in Service Provider Video infrastructure products, which includes connected devices and cable access products, was due primarily to lower sales of set-top boxes.

[0000858877-14-000014:mdna:165]
Nine Months Ended April 26, 2014 Compared with Nine Months Ended April 27, 2013

[0000858877-14-000014:mdna:166]
The decrease in revenue from our Service Provider Video product category of 21%, or $765 million, was primarily driven by a 23%, or $651 million, decrease in sales of our Service Provider Video infrastructure products. This decline was due primarily to lower sales of set-top boxes.

[0000858877-14-000014:mdna:167]
[same as prior period, unchanged from 0000858877-14-000009:mdna:169]

[0000858877-14-000014:mdna:168]
Three Months Ended April 26, 2014 Compared with Three Months Ended April 27, 2013

[0000858877-14-000014:mdna:169]
Our Collaboration product category continues to shift its focus to recurring revenue streams driven by software-as-a-service (SaaS) offerings, for which revenue is deferred and recognized ratably over the term of the arrangement. Overall, revenue in our Collaboration product category decreased by 12%, or $121 million, primarily due to decreased revenue from our Cisco TelePresence and Unified Communications products, driven by weakness in endpoint products such as phones. These decreases were partially offset by higher revenue from our conferencing products.

[0000858877-14-000014:mdna:170]
Nine Months Ended April 26, 2014 Compared with Nine Months Ended April 27, 2013

[0000858877-14-000014:mdna:171]
Revenue in our Collaboration product category decreased by 6%, or $178 million, primarily due to decreased revenue from our Unified Communications and Cisco TelePresence products, partially offset by increased revenue from our conferencing products.

[0000858877-14-000014:mdna:172]
[same as prior period, unchanged from 0000858877-14-000009:mdna:206]

[0000858877-14-000014:mdna:173]
[same as prior period, unchanged from 0000858877-14-000009:mdna:175]

[0000858877-14-000014:mdna:174]
[same as prior period, unchanged from 0000858877-14-000009:mdna:176]

[0000858877-14-000014:mdna:175]
[same as prior period, unchanged from 0000858877-14-000009:mdna:177]

[0000858877-14-000014:mdna:176]
Three Months Ended April 26, 2014 Compared with Three Months Ended April 27, 2013

[0000858877-14-000014:mdna:177]
We continue to experience solid growth in our Data Center product category, which grew by 29%, or $147 million, with solid sales growth of our Cisco Unified Computing System products across all geographic segments and customer markets. The increase was due in large part to the continued momentum we are experiencing in both data center and cloud environments, as current customers increase their data center build-outs, and as new customers deploy these offerings.

[0000858877-14-000014:mdna:178]
[same as prior period, unchanged from 0000858877-14-000009:mdna:180]

[0000858877-14-000014:mdna:179]
Nine Months Ended April 26, 2014 Compared with Nine Months Ended April 27, 2013

[0000858877-14-000014:mdna:180]
We experienced solid growth in our Data Center product category, which grew by 26%, or $388 million, with solid sales growth of our Cisco Unified Computing System products across all geographic segments and customer markets. The increase in this product category was driven by similar factors as discussed in the three month period immediately above.

[0000858877-14-000014:mdna:181]
[same as prior period, unchanged from 0000858877-14-000009:mdna:183]

[0000858877-14-000014:mdna:182]
Three Months Ended April 26, 2014 Compared with Three Months Ended April 27, 2013

[0000858877-14-000014:mdna:183]
Revenue in our Wireless product category increased 3%, or $14 million, due to an increase in sales of Meraki products, which we acquired in the second quarter of fiscal 2013, partially offset by lower sales of other wireless products.

[0000858877-14-000014:mdna:184]
Nine Months Ended April 26, 2014 Compared with Nine Months Ended April 27, 2013

[0000858877-14-000014:mdna:185]
Revenue in our Wireless product category increased by 2%, or $31 million, due primarily to higher sales of Meraki products, partially offset by a decrease in sales of other wireless products.

[0000858877-14-000014:mdna:186]
[same as prior period, unchanged from 0000858877-14-000009:mdna:188]

[0000858877-14-000014:mdna:187]
Three Months Ended April 26, 2014 Compared with Three Months Ended April 27, 2013

[0000858877-14-000014:mdna:188]
Revenue in our Security product category was up 10%, or $34 million, driven by sales of products from Sourcefire, which we acquired in the first quarter of fiscal 2014.

[0000858877-14-000014:mdna:189]
Nine Months Ended April 26, 2014 Compared with Nine Months Ended April 27, 2013

[0000858877-14-000014:mdna:190]
Revenue in our Security product category was up 12%, or $117 million, driven primarily by sales of Sourcefire products and, to a lesser degree, by both higher sales of our high-end firewall products within our network security product portfolio and slightly higher sales of our content security products.

[0000858877-14-000014:mdna:191]
[same as prior period, unchanged from 0000858877-14-000009:mdna:193]

[0000858877-14-000014:mdna:192]
We experienced a year-over-year decrease in revenue in our Other Products category for the third quarter and for the first nine months of fiscal 2014 due in large part to the sale of our Linksys product line in the third quarter of fiscal 2013.

[0000858877-14-000014:mdna:193]
[same as prior period, unchanged from 0000858877-14-000009:mdna:196]

[0000858877-14-000014:mdna:194]
[same as prior period, unchanged from 0000858877-14-000009:mdna:197]

[0000858877-14-000014:mdna:195]
[same as prior period, unchanged from 0000858877-14-000009:mdna:198]

[0000858877-14-000014:mdna:196]
[same as prior period, unchanged from 0000858877-14-000009:mdna:199]

[0000858877-14-000014:mdna:197]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 26, 2014 |  | April 27, 2013 |  | Variance in Dollars |  | Variance in Percent |  | April 26, 2014 |  | April 27, 2013 |  | Variancein Dollars |  | Variance in Percent |
| Service revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 1,764 |  |  | $ | 1,763 |  |  | $ | 1 |  |  | 0.1 | % |  | $ | 5,331 |  |  | $ | 5,219 |  |  | $ | 112 |  |  | 2.1 | % |
| Percentage of service revenue | 64.7 | % |  | 66.3 | % |  |  |  |  |  | 65.4 | % |  | 66.1 | % |  |  |  |  |
| EMEA | 596 |  |  | 541 |  |  | 55 |  |  | 10.2 | % |  | 1,716 |  |  | 1,596 |  |  | 120 |  |  | 7.5 | % |
| Percentage of service revenue | 21.9 | % |  | 20.4 | % |  |  |  |  |  | 21.1 | % |  | 20.2 | % |  |  |  |  |
| APJC | 365 |  |  | 353 |  |  | 12 |  |  | 3.4 | % |  | 1,098 |  |  | 1,082 |  |  | 16 |  |  | 1.5 | % |
| Percentage of service revenue | 13.4 | % |  | 13.3 | % |  |  |  |  |  | 13.5 | % |  | 13.7 | % |  |  |  |  |
| Total | $ | 2,725 |  |  | $ | 2,657 |  |  | $ | 68 |  |  | 2.6 | % |  | $ | 8,145 |  |  | $ | 7,897 |  |  | $ | 248 |  |  | 3.1 | % |

[0000858877-14-000014:mdna:198]
Three Months Ended April 26, 2014 Compared with Three Months Ended April 27, 2013

[0000858877-14-000014:mdna:199]
Service revenue continued to experience slower growth than in prior fiscal years, with varying levels of growth across our geographic segments. Worldwide technical support services revenue increased by 3% while worldwide advanced services revenue experienced 2% growth. Technical support service revenue experienced slow growth across all geographic segments. Renewals and technical support service contract initiations associated with product sales provided an installed base of equipment being serviced which, in concert with new service offerings, were the primary factors driving the revenue increases. Advanced services revenue, which relates to consulting support services for specific customer network needs, declined in the Americas segment but had solid growth in the APJC and EMEA segments due to growth in subscription revenues.

[0000858877-14-000014:mdna:200]
Nine Months Ended April 26, 2014 Compared with Nine Months Ended April 27, 2013

[0000858877-14-000014:mdna:201]
Service revenue grew by 3%. Both worldwide technical support services revenue and worldwide advanced services revenue increased by 3%. Technical support services revenue grew in our Americas and EMEA segments and was flat in our APJC segment. Advanced services revenue declined slightly in our Americas segment but had solid growth in our EMEA and APJC segments due to growth in subscription revenues.

[0000858877-14-000014:mdna:202]
Our service revenue in the first nine months of fiscal 2014 reflected slower growth than what we had been experiencing in recent fiscal years. We believe that our service revenue growth has a correlation to product revenue growth, and to the extent that our product revenue declines or grows at a slower rate, we expect that our service revenue would be adversely impacted.

[0000858877-14-000014:mdna:203]
59

[0000858877-14-000014:mdna:204]
[same as prior period, unchanged from 0000858877-14-000009:mdna:207]

[0000858877-14-000014:mdna:205]
[same as prior period, unchanged from 0000858877-14-000009:mdna:208]

[0000858877-14-000014:mdna:206]
[same as prior period, unchanged from 0000858877-14-000009:mdna:209]

[0000858877-14-000014:mdna:207]
[same as prior period, unchanged from 0000858877-14-000009:mdna:210]

[0000858877-14-000014:mdna:208]
|  | Three Months Ended |  | Nine Months Ended |
|  | Amount |  | Percentage |  | Amount |  | Percentage |
|  | April 26, 2014 |  | April 27, 2013 |  | April 26, 2014 |  | April 27, 2013 |  | April 26, 2014 |  | April 27, 2013 |  | April 26, 2014 |  | April 27, 2013 |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 5,225 |  |  | $ | 5,777 |  |  | 59.2 | % |  | 60.4 | % |  | $ | 14,975 |  |  | $ | 16,906 |  |  | 56.2 | % |  | 59.8 | % |
| Service | 1,781 |  |  | 1,734 |  |  | 65.4 | % |  | 65.3 | % |  | 5,389 |  |  | 5,187 |  |  | 66.2 | % |  | 65.7 | % |
| Total | $ | 7,006 |  |  | $ | 7,511 |  |  | 60.7 | % |  | 61.5 | % |  | $ | 20,364 |  |  | $ | 22,093 |  |  | 58.5 | % |  | 61.0 | % |

[0000858877-14-000014:mdna:209]
[same as prior period, unchanged from 0000858877-14-000009:mdna:212]

[0000858877-14-000014:mdna:210]
The following table summarizes the key factors that contributed to the change in product gross margin percentage for the third quarter and first nine months of fiscal 2014 as compared with the corresponding prior year periods:

[0000858877-14-000014:mdna:211]
|  | Product Gross Margin Percentage |
|  | Three Months Ended |  | Nine Months Ended |
| Fiscal 2013 | 60.4 | % |  | 59.8 | % |
| Productivity (1) | 3.4 | % |  | 2.9 | % |
| Product pricing | (3.2 | )% |  | (3.1 | )% |
| Mix of products sold | (0.8 | )% |  | (0.5 | )% |
| Supplier component remediation charge | — | % |  | (2.5 | )% |
| Amortization of purchased intangible assets | (0.5 | )% |  | (0.5 | )% |
| Acquisition fair value adjustment to inventory and other | (0.1 | )% |  | 0.1 | % |
| Fiscal 2014 | 59.2 | % |  | 56.2 | % |

[0000858877-14-000014:mdna:212]
[same as prior period, unchanged from 0000858877-14-000009:mdna:215]

[0000858877-14-000014:mdna:213]
Three Months Ended April 26, 2014 Compared with Three Months Ended April 27, 2013

[0000858877-14-000014:mdna:214]
Product gross margin decreased by 1.2 percentage points.  The decrease in product gross margin was driven by unfavorable impacts from product pricing, which were driven by normal market factors and impacted each of our geographic segments and customer markets. In addition, the shift in the mix of products sold decreased our product gross margin, primarily as a result of decreased revenue from of our higher margin Switching products and increased revenue from our relatively lower margin Cisco Unified Computing System products. Our product gross margin for the third quarter of fiscal 2014 was also negatively impacted by higher amortization expense of purchased intangible assets from our recent acquisitions.

[0000858877-14-000014:mdna:215]
These amounts were partially offset by productivity benefits. The productivity benefits we experienced in the third quarter of fiscal 2014 were driven by value engineering efforts; favorable component pricing; and continued operational efficiency in manufacturing operations.  Value engineering is the process by which production costs are reduced through component redesign, board configuration, test processes, and transformation processes.

[0000858877-14-000014:mdna:216]
Our future gross margins could be impacted by our product mix and could be adversely affected by further growth in sales of products that have lower gross margins, such as Cisco Unified Computing System products. Our gross margins may also be impacted by the geographic mix of our revenue and, as was the case in the first nine months of fiscal 2014, in fiscal 2013 and in fiscal 2012, may be adversely affected by product pricing attributable to competitive factors. Additionally, our manufacturing-related costs may be negatively impacted by constraints in our supply chain, which in turn could negatively affect gross margin. If any of the preceding factors that in the past have negatively impacted our gross margins arise in future periods, our gross margins could continue to decline.

[0000858877-14-000014:mdna:217]
[same as prior period, unchanged from 0000858877-14-000009:mdna:219]

[0000858877-14-000014:mdna:218]
[same as prior period, unchanged from 0000858877-14-000009:mdna:220]

[0000858877-14-000014:mdna:219]
Nine Months Ended April 26, 2014 Compared with Nine Months Ended April 27, 2013

[0000858877-14-000014:mdna:220]
Product gross margin decreased by 3.6 percentage points for the period. The decrease was due, in part, to the charge of $655  million to product cost of sales for the second quarter of fiscal 2014 related to the expected cost of remediation of issues with memory components in certain products sold in prior fiscal years.  See Note 12 (f) to the Consolidated Financial Statements. The decrease was also due to the impact of unfavorable product pricing. Additionally, our product gross margin for the first nine months of fiscal 2014 was negatively impacted by the shift in the mix of products sold, primarily as a result of revenue increases in our relatively lower margin Cisco Unified Computing System products and lower sales of our higher margin core products, partially offset by decreased revenue from our relatively lower margin Service Provider Video products. Further, as discussed above, for the first nine months of fiscal 2014 our product gross margin was negatively impacted by amortization expense on purchased intangibles from our recent acquisitions.  These factors were partially offset by productivity improvements driven by similar factors as discussed in the three month period immediately above.

[0000858877-14-000014:mdna:221]
[same as prior period, unchanged from 0000858877-14-000009:mdna:223]

[0000858877-14-000014:mdna:222]
Three Months Ended April 26, 2014 Compared with Three Months Ended April 27, 2013

[0000858877-14-000014:mdna:223]
Our service gross margin percentage increased slightly by 0.1 percentage points for the third quarter of fiscal 2014, as compared with the third quarter of fiscal 2013. The increase was primarily due to higher sales volume in both advanced services and technical support services and, to a lesser degree, a favorable mix impact. The favorable mix impact was due to our higher gross margin technical support services category contributing a higher proportion of service revenue for third quarter of fiscal 2014.  The benefits to gross margin of increased sales volume and mix were partially offset by increased cost impacts such as outside service costs, partner delivery costs and headcount-related costs.

[0000858877-14-000014:mdna:224]
[same as prior period, unchanged from 0000858877-14-000009:mdna:226]

[0000858877-14-000014:mdna:225]
Nine Months Ended April 26, 2014 Compared with Nine Months Ended April 27, 2013

[0000858877-14-000014:mdna:226]
Service gross margin percentage increased by 0.5 percentage points for the period driven by higher sales volume. The benefit to gross margin of increased sales volume was partially offset by increased cost impacts such as outside service costs, headcount-related costs and partner delivery costs.

[0000858877-14-000014:mdna:227]
[same as prior period, unchanged from 0000858877-14-000009:mdna:229]

[0000858877-14-000014:mdna:228]
[same as prior period, unchanged from 0000858877-14-000009:mdna:230]

[0000858877-14-000014:mdna:229]
[same as prior period, unchanged from 0000858877-14-000009:mdna:231]

[0000858877-14-000014:mdna:230]
[same as prior period, unchanged from 0000858877-14-000009:mdna:232]

[0000858877-14-000014:mdna:231]
|  | Three Months Ended |  | Nine Months Ended |
|  | Amount |  | Percentage |  | Amount |  | Percentage |
|  | April 26, 2014 |  | April 27, 2013 |  | April 26, 2014 |  | April 27, 2013 |  | April 26, 2014 |  | April 27, 2013 |  | April 26, 2014 |  | April 27, 2013 |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 4,196 |  |  | $ | 4,460 |  |  | 62.7 | % |  | 62.6 | % |  | $ | 12,823 |  |  | $ | 13,341 |  |  | 62.7 | % |  | 62.7 | % |
| EMEA | 1,967 |  |  | 2,044 |  |  | 64.1 | % |  | 65.3 | % |  | 5,725 |  |  | 5,850 |  |  | 64.3 | % |  | 64.5 | % |
| APJC | 1,076 |  |  | 1,197 |  |  | 60.2 | % |  | 61.1 | % |  | 3,148 |  |  | 3,494 |  |  | 58.0 | % |  | 59.8 | % |
| Segment total | 7,239 |  |  | 7,701 |  |  | 62.7 | % |  | 63.0 | % |  | 21,696 |  |  | 22,685 |  |  | 62.4 | % |  | 62.7 | % |
| Unallocated corporate items (1) | (233 | ) |  | (190 | ) |  |  |  |  |  | (1,332 | ) |  | (592 | ) |  |  |  |  |
| Total | $ | 7,006 |  |  | $ | 7,511 |  |  | 60.7 | % |  | 61.5 | % |  | $ | 20,364 |  |  | $ | 22,093 |  |  | 58.5 | % |  | 61.0 | % |

[0000858877-14-000014:mdna:232]
(1) The unallocated corporate items for the periods presented include the effects of amortization and impairments of acquisition-related intangible assets, share-based compensation expense, significant litigation and other contingencies, impacts to cost of sales from purchase accounting adjustments to inventory, and certain other charges. We do not allocate these items to the gross margin for each segment because management does not include such information in measuring the performance of the operating segments.

[0000858877-14-000014:mdna:233]
Three Months Ended April 26, 2014 Compared with Three Months Ended April 27, 2013

[0000858877-14-000014:mdna:234]
The Americas segment experienced a slight gross margin percentage increase due to the impact of productivity improvements in this geographic segment. Partially offsetting this favorable impact to gross margin were negative impacts from pricing and an unfavorable mix. The unfavorable mix impact was driven by a decrease in revenue from our higher margin Switching products.

[0000858877-14-000014:mdna:235]
The gross margin percentage decrease in our EMEA segment was due primarily to the unfavorable impact from pricing, as well as an unfavorable mix impact, partially offset by productivity improvements in this geographic segment. The unfavorable mix impact was driven by a decrease in revenue from our higher margin Switching products and, to a lesser degree, an increase in revenue from our lower margin Cisco Unified Computing System products.

[0000858877-14-000014:mdna:236]
Our APJC segment gross margin percentage decreased primarily as a result of unfavorable impacts from pricing, and also as a result of an unfavorable mix. The unfavorable mix impact was driven by an increase in revenue from our lower margin Cisco Unified Computing System products. Partially offsetting these factors were impacts from productivity improvements and higher service gross margin in this geographic segment.

[0000858877-14-000014:mdna:237]
The gross margin percentage for a particular segment may fluctuate, and period-to-period changes in such percentages may or may not be indicative of a trend for that segment. Our product and service gross margins may be impacted by economic downturns or uncertain economic conditions, as well as our movement into new market opportunities, and could decline if any of the factors that impact our gross margins are adversely affected in future periods.

[0000858877-14-000014:mdna:238]
Nine Months Ended April 26, 2014 Compared with Nine Months Ended April 27, 2013

[0000858877-14-000014:mdna:239]
The Americas segment gross margin percentage was flat compared to prior year period, as the impact of productivity improvements offset  unfavorable impacts from pricing, as well as the impact of an unfavorable mix in this geographic segment.

[0000858877-14-000014:mdna:240]
The gross margin percentage decrease in our EMEA segment was primarily due to the unfavorable impact from pricing, as well as an unfavorable mix impact, partially offset by productivity improvements from lower overall manufacturing costs.

[0000858877-14-000014:mdna:241]
The APJC segment gross margin percentage decreased due to unfavorable impacts from pricing, and unfavorable mix impacts. Partially offsetting these factors were the impacts of productivity improvements and higher service gross margin in this geographic segment.

[0000858877-14-000014:mdna:242]
[same as prior period, unchanged from 0000858877-14-000009:mdna:245]

[0000858877-14-000014:mdna:243]
[same as prior period, unchanged from 0000858877-14-000009:mdna:246]

[0000858877-14-000014:mdna:244]
[same as prior period, unchanged from 0000858877-14-000009:mdna:247]

[0000858877-14-000014:mdna:245]
[same as prior period, unchanged from 0000858877-14-000009:mdna:248]

[0000858877-14-000014:mdna:246]
[same as prior period, unchanged from 0000858877-14-000009:mdna:249]

[0000858877-14-000014:mdna:247]
[same as prior period, unchanged from 0000858877-14-000009:mdna:250]

[0000858877-14-000014:mdna:248]
[same as prior period, unchanged from 0000858877-14-000009:mdna:251]

[0000858877-14-000014:mdna:249]
63

[0000858877-14-000014:mdna:250]
[same as prior period, unchanged from 0000858877-14-000009:mdna:252]

[0000858877-14-000014:mdna:251]
[same as prior period, unchanged from 0000858877-14-000009:mdna:253]

[0000858877-14-000014:mdna:252]
[same as prior period, unchanged from 0000858877-14-000009:mdna:254]

[0000858877-14-000014:mdna:253]
[same as prior period, unchanged from 0000858877-14-000009:mdna:255]

[0000858877-14-000014:mdna:254]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 26, 2014 |  | April 27, 2013 |  | Variance in Dollars |  | Variance in Percent |  | April 26, 2014 |  | April 27, 2013 |  | Variancein Dollars |  | Variance in Percent |
| Research and development | $ | 1,565 |  |  | $ | 1,542 |  |  | $ | 23 |  |  | 1.5 | % |  | $ | 4,701 |  |  | $ | 4,425 |  |  | $ | 276 |  |  | 6.2 | % |
| Percentage of revenue | 13.6 | % |  | 12.6 | % |  |  |  |  |  | 13.5 | % |  | 12.2 | % |  |  |  |  |
| Sales and marketing | 2,342 |  |  | 2,375 |  |  | (33 | ) |  | (1.4 | )% |  | 7,030 |  |  | 7,178 |  |  | (148 | ) |  | (2.1 | )% |
| Percentage of revenue | 20.3 | % |  | 19.4 | % |  |  |  |  |  | 20.2 | % |  | 19.8 | % |  |  |  |  |
| General and administrative | 460 |  |  | 530 |  |  | (70 | ) |  | (13.2 | )% |  | 1,426 |  |  | 1,674 |  |  | (248 | ) |  | (14.8 | )% |
| Percentage of revenue | 4.0 | % |  | 4.3 | % |  |  |  |  |  | 4.1 | % |  | 4.6 | % |  |  |  |  |
| Total | $ | 4,367 |  |  | $ | 4,447 |  |  | $ | (80 | ) |  | (1.8 | )% |  | $ | 13,157 |  |  | $ | 13,277 |  |  | $ | (120 | ) |  | (0.9 | )% |
| Percentage of revenue | 37.8 | % |  | 36.4 | % |  |  |  |  |  | 37.8 | % |  | 36.7 | % |  |  |  |  |

[0000858877-14-000014:mdna:255]
[same as prior period, unchanged from 0000858877-14-000009:mdna:257]

[0000858877-14-000014:mdna:256]
R&D expenses increased for the third quarter and first nine months of fiscal 2014, as compared with the corresponding periods in fiscal 2013, primarily due to compensation expense recorded in fiscal 2014 in connection with our acquisition of the remaining interest in Insieme Networks, Inc. (“Insieme”). See Note 12 to the Consolidated Financial Statements. Higher contracted services also contributed to the increase.  These increases were partially offset by efficiencies related to our workforce reduction plan and reduced variable compensation expense as a result of our financial performance.

[0000858877-14-000014:mdna:257]
[same as prior period, unchanged from 0000858877-14-000009:mdna:260]

[0000858877-14-000014:mdna:258]
[same as prior period, unchanged from 0000858877-14-000009:mdna:261]

[0000858877-14-000014:mdna:259]
Sales and marketing expenses decreased for the third quarter and first nine months of fiscal 2014, as compared with the corresponding periods in fiscal 2013, due to lower headcount-related expenses, resulting largely from efficiencies related to our workforce reduction plan announced in August 2013, and also due to reduced variable compensation expense as a result of lower financial performance. Lower discretionary spending and lower contracted services also contributed to the decrease.

[0000858877-14-000014:mdna:260]
[same as prior period, unchanged from 0000858877-14-000009:mdna:263]

[0000858877-14-000014:mdna:261]
G&A expenses decreased for the third quarter and first nine months of fiscal 2014, as compared with the corresponding periods in fiscal 2013, primarily due to lower corporate-level expenses, lower contracted services, and lower headcount-related expenses.  The lower headcount-related expenses were due to reduced variable compensation expense as a result of lower financial performance, and also due to efficiencies related to our workforce reduction plan announced in August 2013.

[0000858877-14-000014:mdna:262]
[same as prior period, unchanged from 0000858877-14-000009:mdna:265]

[0000858877-14-000014:mdna:263]
In the third quarter of fiscal 2014, foreign currency fluctuations, net of hedging, decreased the combined R&D, sales and marketing, and G&A expenses by $44 million, or approximately 1.0%, compared with the third quarter of fiscal 2013.

[0000858877-14-000014:mdna:264]
In the first nine months of fiscal 2014, foreign currency fluctuations, net of hedging, decreased the combined R&D, sales and marketing, and G&A expenses by $132 million, or approximately 1.0%, compared with the first nine months of fiscal 2013.

[0000858877-14-000014:mdna:265]
[same as prior period, unchanged from 0000858877-14-000009:mdna:268]

[0000858877-14-000014:mdna:266]
Our headcount decreased by approximately 200 employees in the third quarter of fiscal 2014 and decreased by approximately 1,200 in the first nine months of fiscal 2014 as compared with the total headcount at the end of fiscal 2013. The decrease for the third quarter of fiscal 2014 and the first nine months of fiscal 2014 was due to headcount reductions from our workforce reduction plan announced in August 2013 (see Note 5 to the Consolidated Financial Statements) and from attrition. The headcount reduction for the first nine months of fiscal 2014 was partially offset by the increase in headcount from targeted hiring in engineering and services and from our recent acquisitions.

[0000858877-14-000014:mdna:267]
[same as prior period, unchanged from 0000858877-14-000009:mdna:271]

[0000858877-14-000014:mdna:268]
[same as prior period, unchanged from 0000858877-14-000009:mdna:272]

[0000858877-14-000014:mdna:269]
[same as prior period, unchanged from 0000858877-14-000009:mdna:273]

[0000858877-14-000014:mdna:270]
[same as prior period, unchanged from 0000858877-14-000009:mdna:274]

[0000858877-14-000014:mdna:271]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 26, 2014 |  | April 27, 2013 |  | April 26, 2014 |  | April 27, 2013 |
| Cost of sales—product | $ | 12 |  |  | $ | 10 |  |  | $ | 34 |  |  | $ | 31 |  |
| Cost of sales—service | 39 |  |  | 34 |  |  | 112 |  |  | 105 |  |
| Share-based compensation expense in cost of sales | 51 |  |  | 44 |  |  | 146 |  |  | 136 |  |
| Research and development | 106 |  |  | 72 |  |  | 306 |  |  | 228 |  |
| Sales and marketing | 144 |  |  | 118 |  |  | 408 |  |  | 383 |  |
| General and administrative | 52 |  |  | 38 |  |  | 153 |  |  | 136 |  |
| Restructuring and other charges | — |  |  | — |  |  | (4 | ) |  | (3 | ) |
| Share-based compensation expense in operating expenses | 302 |  |  | 228 |  |  | 863 |  |  | 744 |  |
| Total share-based compensation expense | $ | 353 |  |  | $ | 272 |  |  | $ | 1,009 |  |  | $ | 880 |  |

[0000858877-14-000014:mdna:272]
The year-over-year increase in share-based compensation expense for the third quarter and first nine months of fiscal 2014, as compared with the corresponding periods in fiscal 2013, was due primarily to share-based compensation expense attributable to equity awards assumed with respect to our recent acquisitions and higher forfeiture credits in the corresponding fiscal 2013 periods.

[0000858877-14-000014:mdna:273]
[same as prior period, unchanged from 0000858877-14-000009:mdna:277]

[0000858877-14-000014:mdna:274]
[same as prior period, unchanged from 0000858877-14-000009:mdna:278]

[0000858877-14-000014:mdna:275]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 26, 2014 |  | April 27, 2013 |  | April 26, 2014 |  | April 27, 2013 |
| Amortization of purchased intangible assets included in operating expenses | $ | 71 |  |  | $ | 89 |  |  | $ | 207 |  |  | $ | 329 |  |

[0000858877-14-000014:mdna:276]
The decrease in amortization of purchased intangible assets for the third quarter and first nine months of fiscal 2014, as compared with the corresponding periods in fiscal 2013, was due primarily to certain purchased intangible assets that became fully amortized, partially offset by amortization of purchased intangible assets from our recent acquisitions. For additional information regarding purchased intangible assets, see Note 4 to the Consolidated Financial Statements.

[0000858877-14-000014:mdna:277]
[same as prior period, unchanged from 0000858877-14-000009:mdna:281]

[0000858877-14-000014:mdna:278]
[same as prior period, unchanged from 0000858877-14-000009:mdna:282]

[0000858877-14-000014:mdna:279]
In the third quarter and first nine months of fiscal 2014, we incurred within operating expenses restructuring and other charges of approximately $26 million and $336 million, respectively, which were related primarily to employee severance charges for employees impacted by our workforce reduction plan that we announced in August 2013. We expect substantially all of the remaining charges will be incurred in the fourth quarter of fiscal 2014.  This workforce reduction plan is designed to enable us to rebalance our workforce in order to reinvest in key growth areas such as the cloud, data center, mobility, services, software and security and to drive operational efficiencies.   As we intend to reinvest in these areas, we do not expect significant overall cost savings as a result of this rebalancing of our resources.

[0000858877-14-000014:mdna:280]
In the third quarter and first nine months of fiscal 2013, we incurred within operating expenses restructuring and other charges of $33 million and $105 million, respectively, which were related primarily to employee severance charges for employees impacted by our workforce reduction under Fiscal 2011 Plans. See Note 5 to the Consolidated Financial Statements.

[0000858877-14-000014:mdna:281]
[same as prior period, unchanged from 0000858877-14-000009:mdna:285]

[0000858877-14-000014:mdna:282]
[same as prior period, unchanged from 0000858877-14-000009:mdna:286]

[0000858877-14-000014:mdna:283]
[same as prior period, unchanged from 0000858877-14-000009:mdna:287]

[0000858877-14-000014:mdna:284]
[same as prior period, unchanged from 0000858877-14-000009:mdna:288]

[0000858877-14-000014:mdna:285]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 26, 2014 |  | April 27, 2013 |  | April 26, 2014 |  | April 27, 2013 |
| Operating income | $ | 2,542 |  |  | $ | 2,942 |  |  | $ | 6,664 |  |  | $ | 8,382 |  |
| Operating income as a percentage of revenue | 22.0 | % |  | 24.1 | % |  | 19.2 | % |  | 23.2 | % |

[0000858877-14-000014:mdna:286]
For the third quarter of fiscal 2014, as compared with the third quarter of fiscal 2013, operating income decreased by 14%, and as a percentage of revenue operating income decreased by 2.1 percentage points. The decrease was primarily due to the decrease in revenue and the gross margin percentage decline.

[0000858877-14-000014:mdna:287]
For the first nine months of fiscal 2014, as compared with the first nine months of fiscal 2013, operating income decreased by 20%, and as a percentage of revenue operating income decreased by 4.0 percentage points. The decrease resulted from the following: a decrease in revenue; a gross margin percentage decline, driven in part by the $655 million supplier component remediation charge (or 1.9 percentage points); the $363 million compensation expense recorded in the first nine months of fiscal 2014 in connection with our acquisition of the remaining interest in Insieme; and an increase in restructuring and other charges related to the workforce reduction plan that we announced in August 2013.

[0000858877-14-000014:mdna:288]
[same as prior period, unchanged from 0000858877-14-000009:mdna:292]

[0000858877-14-000014:mdna:289]
[same as prior period, unchanged from 0000858877-14-000009:mdna:293]

[0000858877-14-000014:mdna:290]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 26, 2014 |  | April 27, 2013 |  | Variancein Dollars |  | April 26, 2014 |  | April 27, 2013 |  | Variancein Dollars |
| Interest income | $ | 170 |  |  | $ | 162 |  |  | $ | 8 |  |  | $ | 508 |  |  | $ | 483 |  |  | $ | 25 |  |
| Interest expense | (146 | ) |  | (145 | ) |  | (1 | ) |  | (422 | ) |  | (440 | ) |  | 18 |  |
| Interest income (expense), net | $ | 24 |  |  | $ | 17 |  |  | $ | 7 |  |  | $ | 86 |  |  | $ | 43 |  |  | $ | 43 |  |

[0000858877-14-000014:mdna:291]
For each of the third quarter and first nine months of fiscal 2014, interest income increased 5%, compared with the corresponding periods in fiscal 2013, due to increased interest income earned from our portfolio of cash, cash equivalents and fixed income investments.  The decrease in interest expense in the first nine months of fiscal 2014, as compared with the first nine months of fiscal 2013, was driven by the favorable impact of interest rate swaps and lower expense on our floating-rate notes as the benchmark London InterBank Offered Rates (LIBOR) decreased.

[0000858877-14-000014:mdna:292]
[same as prior period, unchanged from 0000858877-14-000009:mdna:296]

[0000858877-14-000014:mdna:293]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 26, 2014 |  | April 27, 2013 |  | Variancein Dollars |  | April 26, 2014 |  | April 27, 2013 |  | Variancein Dollars |
| Gains (losses) on investments, net: |  |  |  |  |  |  |  |  |  |  |  |
| Publicly traded equity securities | $ | 55 |  |  | $ | (2 | ) |  | $ | 57 |  |  | $ | 199 |  |  | $ | 12 |  |  | $ | 187 |  |
| Fixed income securities | 14 |  |  | 8 |  |  | 6 |  |  | 35 |  |  | 34 |  |  | 1 |  |
| Total available-for-sale investments | 69 |  |  | 6 |  |  | 63 |  |  | 234 |  |  | 46 |  |  | 188 |  |
| Privately held companies | (10 | ) |  | (15 | ) |  | 5 |  |  | (76 | ) |  | (69 | ) |  | (7 | ) |
| Net gains (losses) on investments | 59 |  |  | (9 | ) |  | 68 |  |  | 158 |  |  | (23 | ) |  | 181 |  |
| Other gains (losses), net | 17 |  |  | (5 | ) |  | 22 |  |  | 29 |  |  | (46 | ) |  | 75 |  |
| Other income (loss), net | $ | 76 |  |  | $ | (14 | ) |  | $ | 90 |  |  | $ | 187 |  |  | $ | (69 | ) |  | $ | 256 |  |

[0000858877-14-000014:mdna:294]
[same as prior period, unchanged from 0000858877-14-000009:mdna:299]

[0000858877-14-000014:mdna:295]
[same as prior period, unchanged from 0000858877-14-000009:mdna:300]

[0000858877-14-000014:mdna:296]
The increase in total net gains on available-for-sale investments in the third quarter and first nine months of fiscal 2014 compared with the corresponding periods in fiscal 2013 was primarily attributable to higher gains on publicly traded equity securities in the current period as a result of market conditions and the timing of sales of these securities.

[0000858877-14-000014:mdna:297]
The change in net losses on investments in privately held companies in the third quarter of fiscal 2014 compared with the third quarter of fiscal 2013 was due to impairment charges on certain investments in privately held companies that were recorded in the corresponding prior year period. The change in net losses on investments in privately held companies for the first nine months of fiscal 2014, as compared with the first nine months of fiscal 2013, was primarily due to an increase of $28 million in our proportional share of losses from our VCE joint venture, partially offset by lower impairment charges on investments in privately held companies.

[0000858877-14-000014:mdna:298]
The change in other gains (losses), net in the third quarter and first nine months of fiscal 2014 as compared with the corresponding prior year periods was primarily due to higher gains on equity derivative instruments and lower donation expenses.

[0000858877-14-000014:mdna:299]
Provision for Income Taxes

[0000858877-14-000014:mdna:300]
[same as prior period, unchanged from 0000858877-14-000009:mdna:305]

[0000858877-14-000014:mdna:301]
The provision for income taxes resulted in an effective tax rate of 17.4% for the third quarter of fiscal 2014, as compared with an effective tax rate of 15.9% for the third quarter of fiscal 2013, which resulted in a net 1.5 percentage point increase in the effective tax rate for the third quarter of fiscal 2014, as compared with the third quarter of fiscal 2013.  The increase was primarily attributable to a decrease in tax benefits related to the domestic manufacturing deduction, partially offset by an increase in the U.S. federal R&D tax credit.

[0000858877-14-000014:mdna:302]
The provision for income taxes resulted in an effective tax rate of 19.2% for the first nine months of fiscal 2014, as compared with an effective tax rate of 7.7% for the first nine months of fiscal 2013, which resulted in a net 11.5 percentage point increase in the effective tax rate for the first nine months of fiscal 2014, as compared with the first nine months of fiscal 2013. The increase in the effective tax rate for the first nine months of fiscal 2014, as compared with the first nine months of fiscal 2013, was largely due to a fiscal 2013 net tax benefit related to our settlement with the IRS and a fiscal 2014 tax charge related to nondeductible compensation.

[0000858877-14-000014:mdna:303]
[same as prior period, unchanged from 0000858877-14-000009:mdna:308]

[0000858877-14-000014:mdna:304]
[same as prior period, unchanged from 0000858877-14-000009:mdna:309]

[0000858877-14-000014:mdna:305]
[same as prior period, unchanged from 0000858877-14-000009:mdna:310]

[0000858877-14-000014:mdna:306]
[same as prior period, unchanged from 0000858877-14-000009:mdna:311]

[0000858877-14-000014:mdna:307]
[same as prior period, unchanged from 0000858877-14-000009:mdna:312]

[0000858877-14-000014:mdna:308]
[same as prior period, unchanged from 0000858877-14-000009:mdna:313]

[0000858877-14-000014:mdna:309]
|  | April 26, 2014 |  | July 27, 2013 |  | Increase (Decrease) |
| Cash and cash equivalents | $ | 6,241 |  |  | $ | 7,925 |  |  | $ | (1,684 | ) |
| Fixed income securities | 42,269 |  |  | 39,888 |  |  | 2,381 |  |
| Publicly traded equity securities | 1,959 |  |  | 2,797 |  |  | (838 | ) |
| Total | $ | 50,469 |  |  | $ | 50,610 |  |  | $ | (141 | ) |

[0000858877-14-000014:mdna:310]
The decrease in cash and cash equivalents and investments in the first nine months of fiscal 2014 was primarily the result of repurchases of common stock of $8.0 billion under the stock repurchase program.  Other significant uses of cash in the first nine months of fiscal 2014 included cash dividends paid of $2.8 billion, cash paid for acquisitions of $2.8 billion and capital expenditures of $1.0 billion. Largely offsetting these cash outflows were cash provided by operating activities of $8.7 billion, a net increase in debt of $4.7 billion and the issuance of $1.1 billion of common stock pursuant to employee stock incentive plans.

[0000858877-14-000014:mdna:311]
Our total in cash and cash equivalents and investments held by various foreign subsidiaries was $45.9 billion and $40.4 billion as of April 26, 2014 and July 27, 2013, respectively. Under current tax laws and regulations, if these assets were to be distributed from the foreign subsidiaries to the United States in the form of dividends or otherwise, we would be subject to additional U.S. income taxes (subject to an adjustment for foreign tax credits) and foreign withholding taxes. The balance of cash and cash equivalents and investments available in the United States as of April 26, 2014 and July 27, 2013 was $4.6 billion and $10.2 billion, respectively.

[0000858877-14-000014:mdna:312]
[same as prior period, unchanged from 0000858877-14-000009:mdna:317]

[0000858877-14-000014:mdna:313]
[same as prior period, unchanged from 0000858877-14-000009:mdna:318]

[0000858877-14-000014:mdna:314]
[same as prior period, unchanged from 0000858877-14-000009:mdna:319]

[0000858877-14-000014:mdna:315]
|  | Nine Months Ended |
|  | April 26, 2014 |  | April 27, 2013 |
| Net cash provided by operating activities | $ | 8,720 |  |  | $ | 8,908 |  |
| Acquisition of property and equipment | (950 | ) |  | (843 | ) |
| Free cash flow | $ | 7,770 |  |  | $ | 8,065 |  |

[0000858877-14-000014:mdna:316]
[same as prior period, unchanged from 0000858877-14-000009:mdna:321]

[0000858877-14-000014:mdna:317]
68

[0000858877-14-000014:mdna:318]
[same as prior period, unchanged from 0000858877-14-000009:mdna:322]

[0000858877-14-000014:mdna:319]
[same as prior period, unchanged from 0000858877-14-000009:mdna:323]

[0000858877-14-000014:mdna:320]
[same as prior period, unchanged from 0000858877-14-000009:mdna:324]

[0000858877-14-000014:mdna:321]
[same as prior period, unchanged from 0000858877-14-000009:mdna:325]

[0000858877-14-000014:mdna:322]
|  |  | DIVIDENDS |  | STOCK REPURCHASE PROGRAM |  | TOTAL |
| Quarter Ended |  | Per Share |  | Amount |  | Shares |  | Weighted-Average Price per Share |  | Amount |  | Amount |
| Fiscal 2014 |  |  |  |  |  |  |  |  |  |  |  |  |
| April 26, 2014 |  | $ | 0.19 |  |  | $ | 974 |  |  | 90 |  |  | $ | 22.24 |  |  | $ | 2,005 |  |  | $ | 2,979 |  |
| January 25, 2014 |  | $ | 0.17 |  |  | $ | 896 |  |  | 185 |  |  | $ | 21.73 |  |  | $ | 4,020 |  |  | $ | 4,916 |  |
| October 26, 2013 |  | $ | 0.17 |  |  | $ | 914 |  |  | 84 |  |  | $ | 23.65 |  |  | $ | 2,000 |  |  | $ | 2,914 |  |
| Fiscal 2013 |  |  |  |  |  |  |  |  |  |  |  |  |
| July 27, 2013 |  | $ | 0.17 |  |  | $ | 918 |  |  | 47 |  |  | $ | 24.80 |  |  | $ | 1,160 |  |  | $ | 2,078 |  |
| April 27, 2013 |  | $ | 0.17 |  |  | $ | 905 |  |  | 41 |  |  | $ | 20.85 |  |  | $ | 860 |  |  | $ | 1,765 |  |
| January 26, 2013 |  | $ | 0.14 |  |  | $ | 743 |  |  | 25 |  |  | $ | 20.15 |  |  | $ | 500 |  |  | $ | 1,243 |  |
| October 27, 2012 |  | $ | 0.14 |  |  | $ | 744 |  |  | 15 |  |  | $ | 16.44 |  |  | $ | 253 |  |  | $ | 997 |  |

[0000858877-14-000014:mdna:323]
Any future dividends will be subject to the approval of our Board of Directors.

[0000858877-14-000014:mdna:324]
[same as prior period, unchanged from 0000858877-14-000009:mdna:328]

[0000858877-14-000014:mdna:325]
|  | April 26, 2014 |  | July 27, 2013 |  | Increase (Decrease) |
| Accounts receivable, net | $ | 4,443 |  |  | $ | 5,470 |  |  | $ | (1,027 | ) |
| DSO | 35 |  |  | 40 |  |  | (5 | ) |

[0000858877-14-000014:mdna:326]
Our accounts receivable net, as of April 26, 2014 decreased by approximately 19% compared with the end of fiscal 2013.  Our DSO as of April 26, 2014 was five days lower compared with the end of fiscal 2013.  DSO decreased due to product and service billings being more linear in the third quarter of fiscal 2014 compared with the fourth quarter of fiscal 2013.

[0000858877-14-000014:mdna:327]
[same as prior period, unchanged from 0000858877-14-000009:mdna:331]

[0000858877-14-000014:mdna:328]
|  | April 26, 2014 |  | July 27, 2013 |  | Increase (Decrease) |
| Inventories | $ | 1,528 |  |  | $ | 1,476 |  |  | $ | 52 |  |
| Annualized inventory turns | 11.8 |  |  | 13.8 |  |  | (2.0 | ) |
| Purchase commitments with contract manufacturers and suppliers | $ | 4,038 |  |  | $ | 4,033 |  |  | $ | 5 |  |

[0000858877-14-000014:mdna:329]
Inventory as of April 26, 2014 increased by 4% from our inventory balance at the end of fiscal 2013, and for the same period purchase commitments with contract manufacturers and suppliers were flat. On a combined basis, inventories and purchase commitments with contract manufacturers and suppliers increased by 1% compared with the end of fiscal 2013. We believe our inventory and purchase commitments are in line with our current demand forecasts.

[0000858877-14-000014:mdna:330]
[same as prior period, unchanged from 0000858877-14-000009:mdna:356]

[0000858877-14-000014:mdna:331]
[same as prior period, unchanged from 0000858877-14-000009:mdna:334]

[0000858877-14-000014:mdna:332]
[same as prior period, unchanged from 0000858877-14-000009:mdna:335]

[0000858877-14-000014:mdna:333]
[same as prior period, unchanged from 0000858877-14-000009:mdna:336]

[0000858877-14-000014:mdna:334]
[same as prior period, unchanged from 0000858877-14-000009:mdna:337]

[0000858877-14-000014:mdna:335]
[same as prior period, unchanged from 0000858877-14-000009:mdna:338]

[0000858877-14-000014:mdna:336]
[same as prior period, unchanged from 0000858877-14-000009:mdna:339]

[0000858877-14-000014:mdna:337]
Financing Receivables and Guarantees We measure our net balance sheet exposure position related to our financing receivables and financing guarantees by reducing the total of gross financing receivables and financing guarantees by the associated allowances for credit loss and deferred revenue. As of April 26, 2014, our net balance sheet exposure position related to financing receivables and financing guarantees was as follows (in millions):

[0000858877-14-000014:mdna:338]
|  | FINANCING RECEIVABLES |  | FINANCING GUARANTEES |  |  |
| April 26, 2014 | Lease Receivables |  | Loan Receivables |  | Financed Service Contracts and Other |  | Total |  | Channel Partner |  | End-User Customers |  | Total |  | TOTAL |
| Gross amount less unearned income | $ | 3,537 |  |  | $ | 1,621 |  |  | $ | 2,810 |  |  | $ | 7,968 |  |  | $ | 247 |  |  | $ | 229 |  |  | $ | 476 |  |  | $ | 8,444 |  |
| Allowance for credit loss | (249 | ) |  | (92 | ) |  | (19 | ) |  | (360 | ) |  | — |  |  | — |  |  | — |  |  | (360 | ) |
| Deferred revenue | (26 | ) |  | (11 | ) |  | (1,592 | ) |  | (1,629 | ) |  | (132 | ) |  | (198 | ) |  | (330 | ) |  | (1,959 | ) |
| Net balance sheet exposure | $ | 3,262 |  |  | $ | 1,518 |  |  | $ | 1,199 |  |  | $ | 5,979 |  |  | $ | 115 |  |  | $ | 31 |  |  | $ | 146 |  |  | $ | 6,125 |  |

[0000858877-14-000014:mdna:339]
Financing Receivables Gross financing receivables less unearned income decreased by 4% compared with the end of fiscal 2013. The change was due to a 10% decrease in financed service contracts and other, as well as a 2% decrease in loan receivables, partially offset by a 1% increase in lease receivables. We provide financing to certain end-user customers and channel partners to enable sales of our products, services, and networking solutions. These financing arrangements include leases, financed service contracts, and loans. Arrangements related to leases are generally collateralized by a security interest in the underlying assets. Lease receivables include sales-type and direct-financing leases. We also provide certain qualified customers financing for long-term service contracts, which primarily relate to technical support services and advanced services. Our loan financing arrangements may include not only financing the acquisition of our products and services but also providing additional funds for other costs associated with network installation and integration of our products and services. We expect to continue to expand the use of our financing programs in the near term.

[0000858877-14-000014:mdna:340]
[same as prior period, unchanged from 0000858877-14-000009:mdna:343]

[0000858877-14-000014:mdna:341]
[same as prior period, unchanged from 0000858877-14-000009:mdna:344]

[0000858877-14-000014:mdna:342]
[same as prior period, unchanged from 0000858877-14-000009:mdna:345]

[0000858877-14-000014:mdna:343]
[same as prior period, unchanged from 0000858877-14-000009:mdna:346]

[0000858877-14-000014:mdna:344]
[same as prior period, unchanged from 0000858877-14-000009:mdna:347]

[0000858877-14-000014:mdna:345]
[same as prior period, unchanged from 0000858877-14-000009:mdna:348]

[0000858877-14-000014:mdna:346]
[same as prior period, unchanged from 0000858877-14-000009:mdna:349]

[0000858877-14-000014:mdna:347]
|  | Maturity Date |  | April 26, 2014 |  | July 27, 2013 |
| Senior notes: |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |
| Three-month LIBOR plus 0.25% | March 14, 2014 |  | $ | — |  |  | $ | 1,250 |  |
| Three-month LIBOR plus 0.05% | September 3, 2015 | (1) | 850 |  |  | — |  |
| Three-month LIBOR plus 0.28% | March 3, 2017 | (1) | 1,000 |  |  | — |  |
| Three-month LIBOR plus 0.50% | March 1, 2019 | (1) | 500 |  |  | — |  |
| Fixed-rate notes: |  |  |  |  |  |
| 1.625% | March 14, 2014 |  | — |  |  | 2,000 |  |
| 2.90% | November 17, 2014 |  | 500 |  |  | 500 |  |
| 5.50% | February 22, 2016 |  | 3,000 |  |  | 3,000 |  |
| 1.10% | March 3, 2017 | (1) | 2,400 |  |  | — |  |
| 3.15% | March 14, 2017 |  | 750 |  |  | 750 |  |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 2,000 |  |
| 2.125% | March 1, 2019 | (1) | 1,750 |  |  | — |  |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 2,500 |  |
| 2.90% | March 4, 2021 | (1) | 500 |  |  | — |  |
| 3.625% | March 3, 2024 | (1) | 1,000 |  |  | — |  |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 2,000 |  |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 2,000 |  |
| Total |  |  | $ | 20,750 |  |  | $ | 16,000 |  |

[0000858877-14-000014:mdna:348]
(1) In March 2014, we issued senior notes for an aggregate principal amount of $8.0 billion.

[0000858877-14-000014:mdna:349]
We also repaid senior floating-rate and fixed-rate notes upon their maturity in the third quarter of fiscal 2014 for an aggregate principal amount of $3.3 billion.

[0000858877-14-000014:mdna:350]
Interest is payable semiannually on each class of the senior fixed-rate notes, each of which is redeemable by us at any time, subject to a make-whole premium. Interest is payable quarterly on the floating-rate notes. We were in compliance with all debt covenants as of April 26, 2014.

[0000858877-14-000014:mdna:351]
Other Debt   Other debt as of April 26, 2014 and July 27, 2013 includes secured borrowings associated with customer financing arrangements.  As of July 27, 2013 we also had outstanding notes related to our investment in Insieme. The amount of borrowings outstanding under these arrangements was $13 million and $31 million as of April 26, 2014 and July 27, 2013, respectively.

[0000858877-14-000014:mdna:352]
[same as prior period, unchanged from 0000858877-14-000009:mdna:383]

[0000858877-14-000014:mdna:353]
[same as prior period, unchanged from 0000858877-14-000009:mdna:357]

[0000858877-14-000014:mdna:354]
[same as prior period, unchanged from 0000858877-14-000009:mdna:358]

[0000858877-14-000014:mdna:355]
Commercial Paper In fiscal 2011 we established a short-term debt financing program of up to $3.0 billion through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes. In the third quarter of fiscal 2014, we repaid $1.0 billion of indebtedness under commercial paper and had no commercial paper outstanding as of each of April 26, 2014 and July 27, 2013.

[0000858877-14-000014:mdna:356]
Credit Facility On February 17, 2012, we entered into a credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on February 17, 2017. Any advances under the credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (i) the higher of the Federal Funds rate plus 0.50%, Bank of America’s “prime rate” as announced from time to time, or one-month LIBOR plus 1.00%, or (ii) LIBOR plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc. The credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio as defined in the agreement. As of April 26, 2014, we were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under the credit facility.

[0000858877-14-000014:mdna:357]
We may also, upon the agreement of either the existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and/or extend the expiration date of the credit facility by up to two additional years, or up to February 17, 2019.

[0000858877-14-000014:mdna:358]
[same as prior period, unchanged from 0000858877-14-000009:mdna:360]

[0000858877-14-000014:mdna:359]
|  | April 26, 2014 |  | July 27, 2013 |  | Increase (Decrease) |
| Service | $ | 8,746 |  |  | $ | 9,403 |  |  | $ | (657 | ) |
| Product | 4,405 |  |  | 4,020 |  |  | 385 |  |
| Total | $ | 13,151 |  |  | $ | 13,423 |  |  | $ | (272 | ) |
| Reported as: |  |  |  |  |  |
| Current | $ | 9,198 |  |  | $ | 9,262 |  |  | $ | (64 | ) |
| Noncurrent | 3,953 |  |  | 4,161 |  |  | (208 | ) |
| Total | $ | 13,151 |  |  | $ | 13,423 |  |  | $ | (272 | ) |

[0000858877-14-000014:mdna:360]
The 7% decrease in deferred service revenue in the first nine months of fiscal 2014 was driven by an increase in customers paying technical support service contracts over time and the impact of ongoing amortization of deferred service revenue.  The increase in deferred product revenue was primarily due to increased deferrals related to subscription revenue arrangements and increased deferred revenue from acquisitions.

[0000858877-14-000014:mdna:361]
[same as prior period, unchanged from 0000858877-14-000009:mdna:363]

[0000858877-14-000014:mdna:362]
[same as prior period, unchanged from 0000858877-14-000009:mdna:364]

[0000858877-14-000014:mdna:363]
We lease office space in many U.S. locations. Outside the United States, larger leased sites include sites in Belgium, China, France, Germany, India, Israel, Italy, Japan, Norway, and the United Kingdom. We also lease equipment and vehicles. The future minimum lease payments under all of our noncancelable operating leases with an initial term in excess of one year as of April 26, 2014 were $1.2 billion.

[0000858877-14-000014:mdna:364]
[same as prior period, unchanged from 0000858877-14-000009:mdna:366]

[0000858877-14-000014:mdna:365]
[same as prior period, unchanged from 0000858877-14-000009:mdna:367]

[0000858877-14-000014:mdna:366]
[same as prior period, unchanged from 0000858877-14-000009:mdna:368]

[0000858877-14-000014:mdna:367]
72

[0000858877-14-000014:mdna:368]
[same as prior period, unchanged from 0000858877-14-000009:mdna:371]

[0000858877-14-000014:mdna:369]
[same as prior period, unchanged from 0000858877-14-000009:mdna:372]

[0000858877-14-000014:mdna:370]
During the first quarter of fiscal 2014, we exercised our call option and entered into an agreement to purchase the remaining interests in Insieme. The acquisition closed in the second quarter of fiscal 2014, at which time the former noncontrolling interest holders became eligible to receive up to two milestone payments, which will be determined using agreed-upon formulas based primarily on revenue for certain of Insieme’s products.  During the nine months ended April 26, 2014, we recorded compensation expense of $363 million, related to the fair value of the vested portion of amounts that are expected to be earned by the former noncontrolling interest holders. Continued vesting and changes to the fair value of the amounts probable of being earned will result in adjustments to the recorded compensation expense in future periods. Based on the terms of the agreement, we have determined that the maximum amount that could be recorded as compensation expense by us is approximately $856 million, net of forfeitures and including the $363 million that has been expensed through April 26, 2014.  The milestone payments, if earned, are expected to be paid primarily during fiscal 2016 and fiscal 2017.

[0000858877-14-000014:mdna:371]
We also have certain funding commitments primarily related to our investments in privately held companies and venture funds, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $276 million as of April 26, 2014, compared with $263 million as of July 27, 2013.

[0000858877-14-000014:mdna:372]
[same as prior period, unchanged from 0000858877-14-000009:mdna:373]

[0000858877-14-000014:mdna:373]
We consider our investments in unconsolidated variable interest entities to be off-balance sheet arrangements. In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers may be considered to be variable interest entities. We evaluate on an ongoing basis our investments in these privately held companies and customer financings, and we have determined that as of April 26, 2014 there were no material unconsolidated variable interest entities.

[0000858877-14-000014:mdna:374]
VCE is a joint venture that we formed in fiscal 2010 with EMC Corporation (“EMC”), with investments from VMware, Inc. (“VMware”) and Intel Corporation. VCE helps organizations leverage best-in-class technologies and disciplines from Cisco, EMC, and VMware to enable the transformation to cloud computing.  As of April 26, 2014, our cumulative gross investment in VCE was approximately $679 million, inclusive of accrued interest, and our ownership percentage was approximately 35%. During the nine months ended April 26, 2014, we invested $147 million in VCE.  We account for our investment in VCE under the equity method, and our portion of VCE’s net loss is recognized in other income (loss), net.  As of April 26, 2014, we have recorded cumulative losses from VCE of $584 million since inception. Our carrying value in VCE as of April 26, 2014 was $95 million. Over the next 12 months, as VCE scales its operations, we expect that we will make additional investments in VCE and may incur additional losses proportionate with our share ownership.

[0000858877-14-000014:mdna:375]
From time to time, EMC and Cisco may enter into guarantee agreements on behalf of VCE to indemnify third parties, such as customers, for monetary damages. Such guarantees were not material as of April 26, 2014.

[0000858877-14-000014:mdna:376]
[same as prior period, unchanged from 0000858877-14-000009:mdna:377]

[0000858877-14-000014:mdna:377]
[same as prior period, unchanged from 0000858877-14-000009:mdna:378]

[0000858877-14-000014:mdna:378]
[same as prior period, unchanged from 0000858877-14-000009:mdna:379]

[0000858877-14-000014:mdna:379]
We periodically engage in securities lending activities with certain of our available-for-sale investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. The average daily balance of securities lending for the nine months ended April 26, 2014 and April 27, 2013 was $1.4 billion and $0.7 billion, respectively. We require collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. We engage in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify us against collateral losses. As of April 26, 2014 and July 27, 2013, we had no outstanding securities lending transactions. We believe these arrangements do not present a material risk or impact to our liquidity requirements.

[0000858877-14-000014:mdna:380]
CISCO SYSTEMS, INC.

[0000858877-14-000014:mdna:381]
MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-14-000014:mdna:382]
[same as prior period, unchanged from 0000858877-14-000009:mdna:381]

[0000858877-14-000014:mdna:383]
[same as prior period, unchanged from 0000858877-14-000009:mdna:382]

[0000858877-14-000014:mdna:384]
74
