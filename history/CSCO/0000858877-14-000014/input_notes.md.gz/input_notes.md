# CSCO notes — 0000858877-14-000014


## us-gaap:AllowanceForCreditLossesOnFinancingReceivablesTableTextBlock

[0000858877-14-000014:notes:1]
[same as prior period, unchanged from 0000858877-14-000009:notes:1]

[0000858877-14-000014:notes:2]
|  | CREDIT LOSS ALLOWANCES |
| Three Months Ended April 26, 2014 | Lease Receivables |  | Loan Receivables |  | Financed Service Contracts and Other |  | Total |
| Allowance for credit loss as of January 25, 2014 | $ | 254 |  |  | $ | 98 |  |  | $ | 22 |  |  | $ | 374 |  |
| Provisions | (6 | ) |  | (10 | ) |  | (2 | ) |  | (18 | ) |
| Recoveries (write-offs), net | (1 | ) |  | 4 |  |  | (1 | ) |  | 2 |  |
| Foreign exchange and other | 2 |  |  | — |  |  | — |  |  | 2 |  |
| Allowance for credit loss as of April 26, 2014 | $ | 249 |  |  | $ | 92 |  |  | $ | 19 |  |  | $ | 360 |  |
| Gross receivables as of April 26, 2014, net of unearned income | $ | 3,537 |  |  | $ | 1,621 |  |  | $ | 2,810 |  |  | $ | 7,968 |  |

[0000858877-14-000014:notes:3]
|  | CREDIT LOSS ALLOWANCES |
| Nine Months Ended April 26, 2014 | Lease Receivables |  | Loan Receivables |  | Financed Service Contracts and Other |  | Total |
| Allowance for credit loss as of July 27, 2013 | $ | 238 |  |  | $ | 86 |  |  | $ | 20 |  |  | $ | 344 |  |
| Provisions | 9 |  |  | 5 |  |  | — |  |  | 14 |  |
| Recoveries (write-offs), net | — |  |  | 4 |  |  | (1 | ) |  | 3 |  |
| Foreign exchange and other | 2 |  |  | (3 | ) |  | — |  |  | (1 | ) |
| Allowance for credit loss as of April 26, 2014 | $ | 249 |  |  | $ | 92 |  |  | $ | 19 |  |  | $ | 360 |  |

[0000858877-14-000014:notes:4]
|  | CREDIT LOSS ALLOWANCES |
| Three Months Ended April 27, 2013 | Lease Receivables |  | Loan Receivables |  | Financed Service Contracts and Other |  | Total |
| Allowance for credit loss as of January 26, 2013 | $ | 247 |  |  | $ | 101 |  |  | $ | 13 |  |  | $ | 361 |  |
| Provisions | 30 |  |  | 8 |  |  | 6 |  |  | 44 |  |
| Recoveries (write-offs), net | (29 | ) |  | (15 | ) |  | — |  |  | (44 | ) |
| Foreign exchange and other | (3 | ) |  | (1 | ) |  | — |  |  | (4 | ) |
| Allowance for credit loss as of April 27, 2013 | $ | 245 |  |  | $ | 93 |  |  | $ | 19 |  |  | $ | 357 |  |
| Gross receivables as of April 27, 2013, net of unearned income | $ | 3,478 |  |  | $ | 1,671 |  |  | $ | 2,924 |  |  | $ | 8,073 |  |

[0000858877-14-000014:notes:5]
|  | CREDIT LOSS ALLOWANCES |
| Nine Months Ended April 27, 2013 | Lease Receivables |  | Loan Receivables |  | Financed Service Contracts and Other |  | Total |
| Allowance for credit loss as of July 28, 2012 | $ | 247 |  |  | $ | 122 |  |  | $ | 11 |  |  | $ | 380 |  |
| Provisions | 27 |  |  | (15 | ) |  | 8 |  |  | 20 |  |
| Recoveries (write-offs), net | (29 | ) |  | (15 | ) |  | — |  |  | (44 | ) |
| Foreign exchange and other | — |  |  | 1 |  |  | — |  |  | 1 |  |
| Allowance for credit loss as of April 27, 2013 | $ | 245 |  |  | $ | 93 |  |  | $ | 19 |  |  | $ | 357 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0000858877-14-000014:notes:6]
[same as prior period, unchanged from 0000858877-14-000009:notes:6]

[0000858877-14-000014:notes:7]
In December 2011, the Financial Accounting Standards Board (FASB) issued an accounting standard update requiring enhanced disclosures about certain financial instruments and derivative instruments that are offset in the statement of financial position or that are subject to enforceable master netting arrangements or similar agreements. This accounting standard became effective for the Company in the first quarter of fiscal 2014.  As a result of the application of this accounting standard update, the Company has provided additional disclosures in Note 11.

[0000858877-14-000014:notes:8]
[same as prior period, unchanged from 0000858877-14-000009:notes:8]

[0000858877-14-000014:notes:9]
[same as prior period, unchanged from 0000858877-14-000009:notes:9]


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000858877-14-000014:notes:10]
[same as prior period, unchanged from 0000858877-14-000009:notes:10]

[0000858877-14-000014:notes:11]
[same as prior period, unchanged from 0000858877-14-000009:notes:11]

[0000858877-14-000014:notes:12]
The Company completed five business combinations during the nine months ended April 26, 2014.  A summary of the allocation of the total purchase consideration is presented as follows (in millions):

[0000858877-14-000014:notes:13]
[same as prior period, unchanged from 0000858877-14-000009:notes:13]

[0000858877-14-000014:notes:14]
On July 29, 2013, the Company completed its acquisition of privately held Composite Software, Inc. (“Composite Software”), a provider of data virtualization software and services.  Composite Software provides technology that connects many types of data from across the network and makes it appear as if the data is in one place.  With its acquisition of Composite Software, the Company intends to extend its next-generation services platform by connecting data and infrastructure. Revenue from the Composite Software acquisition has been included in the Company's Services category.

[0000858877-14-000014:notes:15]
[same as prior period, unchanged from 0000858877-14-000009:notes:15]

[0000858877-14-000014:notes:16]
[same as prior period, unchanged from 0000858877-14-000009:notes:16]

[0000858877-14-000014:notes:17]
The total purchase consideration related to the Company’s business combinations completed during the nine months ended April 26, 2014 consisted of either cash consideration or cash consideration along with vested share-based awards assumed. The total cash and cash equivalents acquired from these business combinations was approximately $132 million. Total transaction costs related to the Company’s business combination activities were $7 million and $23 million for the nine months ended April 26, 2014 and April 27, 2013, respectively. These transaction costs were expensed as incurred in general and administrative (G&A) expenses in the Consolidated Statements of Operations.

[0000858877-14-000014:notes:18]
[same as prior period, unchanged from 0000858877-14-000009:notes:18]

[0000858877-14-000014:notes:19]
The goodwill generated from the Company’s business combinations completed during the nine months ended April 26, 2014 is primarily related to expected synergies. The goodwill is generally not deductible for income tax purposes.

[0000858877-14-000014:notes:20]
The Consolidated Financial Statements include the operating results of each business combination from the date of acquisition. Pro forma results of operations for the acquisitions completed during the nine months ended April 26, 2014 have not been presented because the effects of the acquisitions, individually and in the aggregate, were not material to the Company’s financial results.

[0000858877-14-000014:notes:21]
[same as prior period, unchanged from 0000858877-14-000009:notes:21]

[0000858877-14-000014:notes:22]
[same as prior period, unchanged from 0000858877-14-000009:notes:22]


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000858877-14-000014:notes:23]
| 12. | Commitments and Contingencies |

[0000858877-14-000014:notes:24]
| (a) | Operating Leases |

[0000858877-14-000014:notes:25]
The Company leases office space in many U.S. locations. Outside the United States, larger leased sites include sites in Belgium, China, France, Germany, India, Israel, Italy, Japan, Norway, and the United Kingdom. The Company also leases equipment and vehicles. Future minimum lease payments under all noncancelable operating leases with an initial term in excess of one year as of April 26, 2014 are as follows (in millions):

[0000858877-14-000014:notes:26]
| Fiscal Year | Amount |
| 2014 (remaining three months) | $ | 103 |  |
| 2015 | 332 |  |
| 2016 | 227 |  |
| 2017 | 157 |  |
| 2018 | 121 |  |
| Thereafter | 243 |  |
| Total | $ | 1,183 |  |

[0000858877-14-000014:notes:27]
| (b) | Purchase Commitments with Contract Manufacturers and Suppliers |

[0000858877-14-000014:notes:28]
The Company purchases components from a variety of suppliers and uses several contract manufacturers to provide manufacturing services for its products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, the Company enters into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by the Company or establish the parameters defining the Company’s requirements. A significant portion of the Company’s reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. In certain instances, these agreements allow the Company the option to cancel, reschedule, and adjust the Company’s requirements based on its business needs prior to firm orders being placed. As of April 26, 2014 and July 27, 2013, the Company had total purchase commitments for inventory of $4,038 million and $4,033 million, respectively.

[0000858877-14-000014:notes:29]
The Company records a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of its future demand forecasts consistent with the valuation of the Company’s excess and obsolete inventory. As of April 26, 2014 and July 27, 2013, the liability for these purchase commitments was $156 million and $172 million, respectively, and was included in other current liabilities.

[0000858877-14-000014:notes:30]
| (c) | Other Commitments |

[0000858877-14-000014:notes:31]
In connection with the Company’s business combinations, the Company has agreed to pay certain additional amounts contingent upon the achievement of certain agreed-upon technology, development, product, or other milestones, or upon the continued employment with the Company of certain employees of the acquired entities.

[0000858877-14-000014:notes:32]
The following table summarizes the compensation expense related to acquisitions (in millions):

[0000858877-14-000014:notes:33]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 26, 2014 |  | April 27, 2013 |  | April 26, 2014 |  | April 27, 2013 |
| Compensation expense related to acquisitions | $ | 95 |  |  | $ | 44 |  |  | $ | 505 |  |  | $ | 79 |  |

[0000858877-14-000014:notes:34]
As of April 26, 2014, the Company estimated that future cash compensation expense of up to $645 million may be required to be recognized pursuant to the applicable business combination agreements, which included the remaining potential compensation expense related to Insieme Networks, Inc. as more fully discussed immediately below.

[0000858877-14-000014:notes:35]
Insieme Networks, Inc. In the third quarter of fiscal 2012, the Company made an investment in Insieme Networks, Inc. ("Insieme"), an early-stage company focused on research and development in the data center market.  As set forth in the agreement between the Company and Insieme, this investment included $100 million of funding and a license to certain of the Company’s technology.  Immediately prior to the call option exercise and acquisition described below, the Company owned approximately 83% of Insieme as a result of these investments and consolidated the results of Insieme in its Consolidated Financial Statements.  In connection with this investment, the Company and Insieme entered into a put/call option agreement that provided the Company with the right to purchase the remaining interests in Insieme.  In addition, the noncontrolling interest holders could require the Company to purchase their shares upon the occurrence of certain events.

[0000858877-14-000014:notes:36]
During the first quarter of fiscal 2014, the Company exercised its call option and entered into an agreement to purchase the remaining interests in Insieme.  The acquisition closed in the second quarter of fiscal 2014, at which time the former noncontrolling interest holders became eligible to receive up to two milestone payments, which will be determined using agreed-upon formulas based primarily on revenue for certain of Insieme’s products.  During the three and nine months ended April 26, 2014, the Company recorded compensation expense of $52 million and $363 million related to the fair value of the vested portion of amounts that are expected to be earned by the former noncontrolling interest holders.  Continued vesting and changes to the fair value of the amounts probable of being earned will result in adjustments to the recorded compensation expense in future periods.  Based on the terms of the agreement, the Company has determined that the maximum amount that could be recorded as compensation expense by the Company is approximately $856 million, net of forfeitures and including the $363 million that has been expensed through April 26, 2014.  The milestone payments, if earned, are expected to be paid primarily during fiscal 2016 and fiscal 2017.

[0000858877-14-000014:notes:37]
The Company also has certain funding commitments, primarily related to its investments in privately held companies and venture funds, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $276 million and $263 million as of April 26, 2014 and July 27, 2013, respectively.

[0000858877-14-000014:notes:38]
| (d) | Variable Interest Entities |

[0000858877-14-000014:notes:39]
VCE Joint Venture VCE is a joint venture that the Company formed in fiscal 2010 with EMC Corporation (“EMC”), with investments from VMware, Inc. (“VMware”) and Intel Corporation. VCE helps organizations leverage best-in-class technologies and disciplines from Cisco, EMC, and VMware to enable the transformation to cloud computing.

[0000858877-14-000014:notes:40]
As of April 26, 2014, the Company’s cumulative gross investment in VCE was approximately $679 million, inclusive of accrued interest, and its ownership percentage was approximately 35%.  The Company invested $147 million during the nine months ended April 26, 2014.

[0000858877-14-000014:notes:41]
The Company accounts for its investment in VCE under the equity method, and its portion of VCE’s net loss is recognized in other income (loss), net.  The Company’s share of VCE’s losses, based upon its portion of the overall funding, was approximately 36.8% for each of the three and nine months ended April 26, 2014 and April 27, 2013.  As of April 26, 2014, the Company had recorded cumulative losses from VCE of $584 million since inception, of which losses of $52 million and $49 million were recorded for the three months ended April 26, 2014 and April 27, 2013, respectively, and losses of $163 million and $135 million were recorded for the nine months ended April 26, 2014 and April 27, 2013, respectively.  The Company’s carrying value in VCE as of April 26, 2014 of $95 million was recorded in other assets.

[0000858877-14-000014:notes:42]
Over the next 12 months, as VCE scales its operations, the Company expects that it will make additional investments in VCE and may incur additional losses proportionate with the Company’s share ownership.

[0000858877-14-000014:notes:43]
From time to time, EMC and Cisco may enter into guarantee agreements on behalf of VCE to indemnify third parties, such as customers, for monetary damages. Such guarantees were not material as of April 26, 2014.

[0000858877-14-000014:notes:44]
Other Variable Interest Entities In the ordinary course of business, the Company has investments in other privately held companies and provides financing to certain customers. These other privately held companies and customers may be considered to be variable interest entities. The Company evaluates on an ongoing basis its investments in these other privately held companies and its customer financings, and has determined that as of April 26, 2014 there were no other variable interest entities required to be consolidated in the Company’s Consolidated Financial Statements.

[0000858877-14-000014:notes:45]
| (e) | Product Warranties and Guarantees |

[0000858877-14-000014:notes:46]
The following table summarizes the activity related to product warranty liability during the nine months ended April 26, 2014 and April 27, 2013 (in millions):

[0000858877-14-000014:notes:47]
|  | Nine Months Ended |
|  | April 26, 2014 |  | April 27, 2013 |
| Balance at beginning of period | $ | 402 |  |  | $ | 373 |  |
| Provision for warranties issued | 532 |  |  | 480 |  |
| Payments | (504 | ) |  | (462 | ) |
| Balance at end of period | $ | 430 |  |  | $ | 391 |  |

[0000858877-14-000014:notes:48]
The Company accrues for warranty costs as part of its cost of sales based on associated material product costs, labor costs for technical support staff, and associated overhead. The Company’s products are generally covered by a warranty for periods ranging from 90 days to five years, and for some products the Company provides a limited lifetime warranty.

[0000858877-14-000014:notes:49]
The Company also provides financing guarantees, which are generally for various third-party financing arrangements to channel partners and other end-user customers. For additional information, see Note 7. The Company’s other guarantee arrangements as of April 26, 2014 and July 27, 2013 that were subject to recognition and disclosure requirements were not material.

[0000858877-14-000014:notes:50]
(f)  Supplier Component Remediation Liability

[0000858877-14-000014:notes:51]
The Company has recorded in other current liabilities a liability for the expected remediation cost for certain products sold in prior fiscal years containing memory components manufactured by a single supplier between 2005 and 2010. These components are widely used across the industry and are included in a number of the Company's products. Defects in some of these components have caused products to fail after a power cycle event.  Defect rates due to this issue have been and are expected to be low. However, recently the Company has seen a small number of its customers experience a growing number of failures in their networks as a result of this component problem. Although the majority of these products are beyond the Company's warranty terms, the Company is proactively working with customers on mitigation.  Prior to the second quarter of fiscal 2014, the Company had a liability of $63 million related to this issue for expected remediation costs based on the intended approach at that time. In February 2014, on the basis of the growing number of failures described above, the Company decided to expand its approach which resulted in an additional charge to product cost of sales of $655 million being recorded for the second quarter of fiscal 2014.  As of April 26, 2014, the remaining supplier component remediation liability was $702 million.

[0000858877-14-000014:notes:52]
(g)  Indemnifications

[0000858877-14-000014:notes:53]
In the normal course of business, the Company indemnifies other parties, including customers, lessors, and parties to other transactions with the Company, with respect to certain matters. The Company has agreed to hold such parties harmless against losses arising from a breach of representations or covenants or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim.

[0000858877-14-000014:notes:54]
The Company has an obligation to indemnify certain expenses pursuant to such agreements in a case involving certain of the Company’s service provider customers that are subject to patent infringement claims asserted by Sprint Communications Company, L.P. (“Sprint”) in the United States District Court for the District of Kansas filed on December 19, 2011 (including one case that was later transferred to the District of Delaware).  Sprint alleges that the service providers infringe Sprint’s patents by offering Voice over Internet Protocol-based telephone services utilizing products provided by the Company and other manufacturers.  Sprint is seeking monetary damages.  Trial dates have been set for the first half of calendar year 2015.  The parties intend to conduct a mediation later this calendar year and the Company may be asked to participate.  The mediation could result in a resolution of the case for some or all of the Company's service provider customers.  The Company believes that the service providers have strong defenses and that its products do not infringe the patents subject to the claims.  Due to the uncertainty surrounding the litigation process, which involves numerous defendants, the Company is unable to reasonably estimate the ultimate outcome of this litigation at this time.  Should the plaintiff prevail in litigation, mediation, or settlement, the Company may have an obligation to indemnify its service provider customers for damages, mediation awards, or settlement amounts arising from their use of Cisco products.

[0000858877-14-000014:notes:55]
In addition, the Company has entered into indemnification agreements with its officers and directors, and the Company’s Amended and Restated Bylaws contain similar indemnification obligations to the Company’s agents.

[0000858877-14-000014:notes:56]
It is not possible to determine the maximum potential amount under these indemnification agreements due to the Company’s limited history with prior indemnification claims and the unique facts and circumstances involved in each particular agreement. Historically, payments made by the Company under these agreements have not had a material effect on the Company’s operating results, financial position, or cash flows.

[0000858877-14-000014:notes:57]
(h) Legal Proceedings

[0000858877-14-000014:notes:58]
Brazil Brazilian authorities have investigated the Company’s Brazilian subsidiary and certain of its current and former employees, as well as a Brazilian importer of the Company’s products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against the Company’s Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years. In the first quarter of fiscal 2013, the Brazilian federal tax authorities asserted an additional claim against the Company’s Brazilian subsidiary based on a theory of joint liability with respect to an alleged underpayment of income taxes, social taxes, interest, and penalties by a Brazilian distributor.

[0000858877-14-000014:notes:59]
The asserted claims by Brazilian federal tax authorities are for calendar years 2003 through 2008, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to approximately $389 million for the alleged evasion of import and other taxes, approximately $1.3 billion for interest, and approximately $1.7 billion for various penalties, all determined using an exchange rate as of April 26, 2014. The Company has completed a thorough review of the matters and believes the asserted claims against the Company’s Brazilian subsidiary are without merit, and the Company is defending the claims vigorously. While the Company believes there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, the Company is unable to determine the likelihood of an unfavorable outcome against its Brazilian subsidiary and is unable to reasonably estimate a range of loss, if any. The Company does not expect a final judicial determination for several years.

[0000858877-14-000014:notes:60]
Russia and the Commonwealth of Independent States At the request of the U.S. Securities and Exchange Commission and the U.S. Department of Justice, the Company is conducting an investigation into allegations which the Company and those agencies received regarding possible violations of the U.S. Foreign Corrupt Practices Act involving business activities of the Company's operations in Russia and certain of the Commonwealth of Independent States, and by certain resellers of the Company’s products in those countries.  The Company takes any such allegations very seriously and is fully cooperating with and sharing the results of its investigation with the Commission and the Department.  While the outcome of the Company's investigation is currently not determinable, the Company does not expect that it will have a material adverse effect on its consolidated financial position, results of operations, or cash flows. The countries that are the subject of the investigation collectively comprise less than two percent of the Company’s revenues.

[0000858877-14-000014:notes:61]
VirnetX  The Company was subject to patent claims asserted by VirnetX, Inc. on August 11, 2010 in the United States District Court for the Eastern District of Texas.  VirnetX alleged that some Cisco products that implement a method for secure communication using virtual private networks infringe certain patents.  VirnetX sought monetary damages.  The trial on these claims began on March 4, 2013. On March 14, 2013, the jury entered a verdict finding that the Company’s accused products do not infringe any of VirnetX’s patents asserted in the lawsuit. On April 3, 2013, VirnetX filed a motion seeking a new trial on the issue of infringement, which the Company opposed. The Court held a hearing on VirnetX’s motion for a new trial in June 2013.  On March 31, 2014 the court denied VirnetX's new trial motion.  VirnetX has not appealed that decision, which is therefore final.

[0000858877-14-000014:notes:62]
XpertUniverse The Company was subject to numerous patent, tort, and contract claims asserted by XpertUniverse on March 10, 2009 in the United States District Court for the District of Delaware. Shortly before trial, the Court dismissed on summary judgment all claims initially asserted by XpertUniverse except a claim for infringement of two XpertUniverse patents and a claim for fraud by concealment. XpertUniverse’s remaining patent claims alleged that three Cisco products in the field of expertise location software infringed two XpertUniverse patents. XpertUniverse’s fraud by concealment claim alleged that the Company did not disclose its decision not to admit XpertUniverse into a partner program. The trial on these remaining claims began on March 11, 2013. On March 22, 2013, the jury entered a verdict finding that two of the Company’s products infringed two of XpertUniverse’s patents and awarded XpertUniverse damages of less than $35 thousand. The jury also found for XpertUniverse on its fraud by concealment claim and awarded damages of $70 million.  In May and June 2013, the Company filed post-trial motions.  On November 20, 2013 the trial court granted the Company's motion for judgment as a matter of law, overturned the jury’s finding on the fraud by concealment claim, and vacated the $70 million verdict.  Separately, the trial court agreed with the jury that the Company infringed XpertUniverse’s patents, and affirmed the verdict awarding XpertUniverse approximately $35 thousand in damages plus accrued interest.  On February 4, 2014, XpertUniverse filed a notice of appeal from the trial court’s decision.

[0000858877-14-000014:notes:63]
Rockstar The Company and some of its service provider customers are subject to patent claims asserted in December 2013 in the Eastern District of Texas and the District of Delaware by subsidiaries of the Rockstar Consortium ("Rockstar").  Rockstar, whose members include Apple, Microsoft, LM Ericsson, Sony, and Blackberry, purchased a portfolio of patents out of the Nortel Networks’ bankruptcy proceedings (the “Nortel Portfolio”). Rockstar’s subsidiaries allege that some of the Company’s NGN Routing, Switching and Collaboration products, as well as video solutions deployed by its service provider customers, infringe some of the patents in the Nortel Portfolio.  Rockstar seeks monetary damages.  A trial date for one service provider customer has been set for October 2015; no other trial dates have been set.  The Company has various defenses to the patent infringement allegations, and has various offensive claims against Rockstar and some of its consortium members available to it as well, and the Company will also explore alternative means of resolution.   Due to the uncertainty surrounding the litigation process, which involves numerous lawsuits and parties, the Company is unable to reasonably estimate the ultimate outcome and a range of loss, if any, of these litigations at this time.

[0000858877-14-000014:notes:64]
In addition, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, the Company does not expect that the ultimate costs to resolve these matters will have a material adverse effect on its consolidated financial position, results of operations, or cash flows.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000858877-14-000014:notes:65]
[same as prior period, unchanged from 0000858877-14-000009:notes:62]

[0000858877-14-000014:notes:66]
The components of AOCI, net of tax, and the other comprehensive income (loss), excluding noncontrolling interest, for the nine months ended April 26, 2014 and April 27, 2013 are summarized as follows (in millions):

[0000858877-14-000014:notes:67]
|  | Net Unrealized Gains on Investments |  | Net Unrealized Gains (Losses) Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Other |  | Accumulated Other Comprehensive Income |
| BALANCE AT JULY 27, 2013 | $ | 379 |  |  | $ | 8 |  |  | $ | 221 |  |  | $ | 608 |  |
| Other comprehensive income before reclassifications attributable to Cisco Systems, Inc. | 339 |  |  | 46 |  |  | 32 |  |  | 417 |  |
| (Gains) losses reclassified out of other comprehensive income | (234 | ) |  | (44 | ) |  | — |  |  | (278 | ) |
| Tax benefit (expense) | (43 | ) |  | (2 | ) |  | (5 | ) |  | (50 | ) |
| BALANCE AT APRIL 26, 2014 | $ | 441 |  |  | $ | 8 |  |  | $ | 248 |  |  | $ | 697 |  |
|  | Net Unrealized Gains on Investments |  | Net Unrealized Gains (Losses) Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Other |  | Accumulated Other Comprehensive Income |
| BALANCE AT JULY 28, 2012 | $ | 409 |  |  | $ | (53 | ) |  | $ | 305 |  |  | $ | 661 |  |
| Other comprehensive income before reclassifications attributable to Cisco Systems, Inc. | 22 |  |  | 59 |  |  | 6 |  |  | 87 |  |
| (Gains) losses reclassified out of other comprehensive income | (46 | ) |  | (7 | ) |  | — |  |  | (53 | ) |
| Tax benefit (expense) | 9 |  |  | (1 | ) |  | (14 | ) |  | (6 | ) |
| BALANCE AT APRIL 27, 2013 | $ | 394 |  |  | $ | (2 | ) |  | $ | 297 |  |  | $ | 689 |  |

[0000858877-14-000014:notes:68]
[same as prior period, unchanged from 0000858877-14-000009:notes:65]

[0000858877-14-000014:notes:69]
|  |  | Three Months Ended |  | Nine Months Ended |  |  |
|  |  | April 26, 2014 |  | April 27, 2013 |  | April 26, 2014 |  | April 27, 2013 |  |  |
| Comprehensive Income Components |  | Income Before Taxes |  | Income Before Taxes |  | Line Item in Statements of Operations |
| Net unrealized gains on available-for-sale investments |  |  |  |  |  |  |  |  |  |  |
|  |  | $ | 69 |  |  | $ | 6 |  |  | $ | 234 |  |  | $ | 46 |  |  | Other income (loss), net |
| Net unrealized gains and losses on cash flow hedging instruments |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | 13 |  |  | 3 |  |  | 36 |  |  | 5 |  |  | Operating expenses |
| Foreign currency derivatives |  | 3 |  |  | 1 |  |  | 8 |  |  | 2 |  |  | Cost of sales—service |
|  |  | 16 |  |  | 4 |  |  | 44 |  |  | 7 |  |  |  |
| Total amounts reclassified out of other comprehensive income |  | $ | 85 |  |  | $ | 10 |  |  | $ | 278 |  |  | $ | 53 |  |  |  |


## us-gaap:DebtDisclosureTextBlock

[0000858877-14-000014:notes:70]
| 10. | Borrowings |

[0000858877-14-000014:notes:71]
| (a) | Short-Term Debt |

[0000858877-14-000014:notes:72]
The following table summarizes the Company’s short-term debt (in millions, except percentages):

[0000858877-14-000014:notes:73]
|  | April 26, 2014 |  | July 27, 2013 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 500 |  |  | 3.11 | % |  | $ | 3,273 |  |  | 0.63 | % |
| Other notes and borrowings | 8 |  |  | 2.60 | % |  | 10 |  |  | 2.52 | % |
| Total short-term debt | $ | 508 |  |  |  |  | $ | 3,283 |  |  |  |

[0000858877-14-000014:notes:74]
In fiscal 2011, the Company established a short-term debt financing program of up to $3.0 billion through the issuance of commercial paper notes. The Company uses the proceeds from the issuance of commercial paper notes for general corporate purposes. In the third quarter of fiscal 2014, the Company repaid $1.0 billion of indebtedness under commercial paper and had no commercial paper outstanding as of each of April 26, 2014 and July 27, 2013.

[0000858877-14-000014:notes:75]
The effective interest rate on the current portion of long-term debt includes the impact of interest rate swaps, as discussed further in "

[0000858877-14-000014:notes:76]
| (b) | Long-Term Debt |

[0000858877-14-000014:notes:77]
."  The Company repaid senior floating-rate and fixed-rate notes upon their maturity in the third quarter of fiscal 2014 for an aggregate principal amount of $3.3 billion.  Other notes and borrowings consist of the short-term portion of secured borrowings associated with customer financing arrangements.  These notes and credit facilities were subject to various terms and foreign currency market interest rates pursuant to individual financial arrangements between the financing institution and the applicable foreign subsidiary.

[0000858877-14-000014:notes:78]
As of April 26, 2014, the estimated fair value of the short-term debt approximates its carrying value due to the short maturities.

[0000858877-14-000014:notes:79]
(b)

[0000858877-14-000014:notes:80]
Long-Term Debt

[0000858877-14-000014:notes:81]
The following table summarizes the Company’s long-term debt (in millions, except percentages):

[0000858877-14-000014:notes:82]
|  |  |  | April 26, 2014 |  | July 27, 2013 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.25% | March 14, 2014 |  | $ | — |  |  | — |  | $ | 1,250 |  |  | 0.62% |
| Three-month LIBOR plus 0.05% | September 3, 2015 | (1) | 850 |  |  | 0.38% |  | — |  |  | — |
| Three-month LIBOR plus 0.28% | March 3, 2017 | (1) | 1,000 |  |  | 0.58% |  | — |  |  | — |
| Three-month LIBOR plus 0.50% | March 1, 2019 | (1) | 500 |  |  | 0.79% |  | — |  |  | — |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 1.625% | March 14, 2014 |  | — |  |  | — |  | 2,000 |  |  | 0.64% |
| 2.90% | November 17, 2014 |  | 500 |  |  | 3.11% |  | 500 |  |  | 3.11% |
| 5.50% | February 22, 2016 |  | 3,000 |  |  | 3.05% |  | 3,000 |  |  | 3.07% |
| 1.10% | March 3, 2017 | (1) | 2,400 |  |  | 0.56% |  | — |  |  | — |
| 3.15% | March 14, 2017 |  | 750 |  |  | 0.80% |  | 750 |  |  | 0.84% |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 4.69% |  | 2,000 |  |  | 4.70% |
| 2.125% | March 1, 2019 | (1) | 1,750 |  |  | 0.77% |  | — |  |  | — |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 2.98% |  | 2,500 |  |  | 4.15% |
| 2.90% | March 4, 2021 | (1) | 500 |  |  | 0.93% |  | — |  |  | — |
| 3.625% | March 3, 2024 | (1) | 1,000 |  |  | 1.05% |  | — |  |  | — |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Other long-term debt |  |  | 6 |  |  | 2.52% |  | 21 |  |  | 1.46% |
| Total |  |  | 20,756 |  |  |  |  | 16,021 |  |  |  |
| Unaccreted discount |  |  | (65 | ) |  |  |  | (65 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 193 |  |  |  |  | 245 |  |  |  |
| Total |  |  | $ | 20,884 |  |  |  |  | $ | 16,201 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 500 |  |  |  |  | $ | 3,273 |  |  |  |
| Long-term debt |  |  | 20,384 |  |  |  |  | 12,928 |  |  |  |
| Total |  |  | $ | 20,884 |  |  |  |  | $ | 16,201 |  |  |  |

[0000858877-14-000014:notes:83]
(1) In March 2014, the Company issued senior notes for an aggregate principal amount of $8.0 billion.

[0000858877-14-000014:notes:84]
To achieve its interest rate risk management objectives, the Company entered into interest rate swaps with an aggregate notional amount of $10.4 billion designated as fair value hedges of certain of its fixed-rate senior notes. In effect, these swaps convert the fixed interest rates of the fixed-rate notes to floating interest rates based on the London InterBank Offered Rate (LIBOR). The gains and losses related to changes in the fair value of the interest rate swaps substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates. For additional information, see Note 11.

[0000858877-14-000014:notes:85]
The effective rates for the fixed-rate debt include the interest on the notes, the accretion of the discount and, if applicable, adjustments related to hedging. Interest is payable semiannually on each class of the senior fixed-rate notes and payable quarterly on the floating-rate notes. Each of the senior fixed-rate notes is redeemable by the Company at any time, subject to a make-whole premium.

[0000858877-14-000014:notes:86]
The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to the Company’s short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of April 26, 2014, the Company was in compliance with all debt covenants.

[0000858877-14-000014:notes:87]
As of April 26, 2014, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

[0000858877-14-000014:notes:88]
| Fiscal Year | Amount |
| 2014 (remaining three months) | $ | — |  |
| 2015 | 502 |  |
| 2016 | 3,853 |  |
| 2017 | 4,151 |  |
| 2018 | — |  |
| Thereafter | 12,250 |  |
| Total | $ | 20,756 |  |

[0000858877-14-000014:notes:89]
| (c) | Credit Facility |

[0000858877-14-000014:notes:90]
On February 17, 2012, the Company entered into a credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on February 17, 2017. Any advances under the credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (i) the higher of the Federal Funds rate plus 0.50%, Bank of America’s “prime rate” as announced from time to time, or one-month LIBOR plus 1.00% or (ii) LIBOR plus a margin that is based on the Company’s senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc. The credit agreement requires the Company to comply with certain covenants, including that it maintain an interest coverage ratio as defined in the agreement. As of April 26, 2014, the Company was in compliance with the required interest coverage ratio and the other covenants, and the Company had not borrowed any funds under the credit facility.

[0000858877-14-000014:notes:91]
The Company may also, upon the agreement of either the existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and/or extend the expiration date of the credit facility by up to two additional years, or up to February 17, 2019.


## us-gaap:DeferredRevenueByArrangementDisclosureTextBlock

[0000858877-14-000014:notes:92]
| Deferred revenue: |  |  |  |  |
| Service |  | $ | 8,746 |  |  | $ | 9,403 |  |
| Product: |  |  |  |  |
| Unrecognized revenue on product shipments and other deferred revenue |  | 3,669 |  |  | 3,340 |  |
| Cash receipts related to unrecognized revenue from two-tier distributors |  | 736 |  |  | 680 |  |
| Total product deferred revenue |  | 4,405 |  |  | 4,020 |  |
| Total |  | $ | 13,151 |  |  | $ | 13,423 |  |
| Reported as: |  |  |  |  |
| Current |  | $ | 9,198 |  |  | $ | 9,262 |  |
| Noncurrent |  | 3,953 |  |  | 4,161 |  |
| Total |  | $ | 13,151 |  |  | $ | 13,423 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000858877-14-000014:notes:93]
[same as prior period, unchanged from 0000858877-14-000009:notes:86]

[0000858877-14-000014:notes:94]
[same as prior period, unchanged from 0000858877-14-000009:notes:87]

[0000858877-14-000014:notes:95]
[same as prior period, unchanged from 0000858877-14-000009:notes:88]

[0000858877-14-000014:notes:96]
[same as prior period, unchanged from 0000858877-14-000009:notes:89]

[0000858877-14-000014:notes:97]
|  | DERIVATIVE ASSETS |  | DERIVATIVE LIABILITIES |
|  | Balance Sheet Line Item |  | April 26, 2014 |  | July 27, 2013 |  | Balance Sheet Line Item |  | April 26, 2014 |  | July 27, 2013 |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | $ | 17 |  |  | $ | 33 |  |  | Other current liabilities |  | $ | 3 |  |  | $ | 7 |  |
| Interest rate derivatives | Other assets |  | 126 |  |  | 147 |  |  | Other long-term liabilities |  | 8 |  |  | 2 |  |
| Equity derivatives | Other current assets |  | — |  |  | — |  |  | Other current liabilities |  | 39 |  |  | 155 |  |
| Total |  |  | 143 |  |  | 180 |  |  |  |  | 50 |  |  | 164 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | 5 |  |  | 2 |  |  | Other current liabilities |  | 4 |  |  | 7 |  |
| Equity derivatives | Other assets |  | — |  |  | — |  |  | Other long-term liabilities |  | — |  |  | — |  |
| Total |  |  | 5 |  |  | 2 |  |  |  |  | 4 |  |  | 7 |  |
| Total |  |  | $ | 148 |  |  | $ | 182 |  |  |  |  | $ | 54 |  |  | $ | 171 |  |

[0000858877-14-000014:notes:98]
[same as prior period, unchanged from 0000858877-14-000009:notes:91]

[0000858877-14-000014:notes:99]
| GAINS (LOSSES) RECOGNIZEDIN OCI ON DERIVATIVES FOR THETHREE MONTHS ENDED (EFFECTIVE PORTION) |  | GAINS (LOSSES) RECLASSIFIED FROMAOCI INTO INCOME FOR THETHREE MONTHS ENDED (EFFECTIVE PORTION) |
| Derivatives designated as cash flow hedging instruments: |  | April 26, 2014 |  | April 27, 2013 |  | Line Item in Statements of Operations |  | April 26, 2014 |  | April 27, 2013 |
| Foreign currency derivatives |  | $ | 13 |  |  | $ | (11 | ) |  | Operating expenses |  | $ | 13 |  |  | $ | 3 |  |
|  |  |  |  |  |  | Cost of sales—service |  | 3 |  |  | 1 |  |
| Total |  | $ | 13 |  |  | $ | (11 | ) |  |  |  | $ | 16 |  |  | $ | 4 |  |
| Derivatives designated as net investment hedging instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | (10 | ) |  | $ | 20 |  |  | Other income (loss), net |  | $ | — |  |  | $ | — |  |

[0000858877-14-000014:notes:100]
| GAINS (LOSSES) RECOGNIZEDIN OCI ON DERIVATIVES FOR THENINE MONTHS ENDED (EFFECTIVE PORTION) |  | GAINS (LOSSES) RECLASSIFIED FROMAOCI INTO INCOME FOR THENINE MONTHS ENDED (EFFECTIVE PORTION) |
| Derivatives designated as cash flow hedging instruments: |  | April 26, 2014 |  | April 27, 2013 |  | Line Item in Statements of Operations |  | April 26, 2014 |  | April 27, 2013 |
| Foreign currency derivatives |  | $ | 47 |  |  | $ | 58 |  |  | Operating expenses |  | $ | 36 |  |  | $ | 5 |  |
|  |  |  |  |  |  | Cost of sales—service |  | 8 |  |  | 2 |  |
| Total |  | $ | 47 |  |  | $ | 58 |  |  |  |  | $ | 44 |  |  | $ | 7 |  |
| Derivatives designated as net investment hedging instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | (13 | ) |  | $ | (4 | ) |  | Other income (loss), net |  | $ | — |  |  | $ | — |  |

[0000858877-14-000014:notes:101]
As of April 26, 2014, the Company estimates that approximately $22 million of net derivative gains related to its cash flow hedges included in accumulated other comprehensive income (AOCI) will be reclassified into earnings within the next 12 months.

[0000858877-14-000014:notes:102]
[same as prior period, unchanged from 0000858877-14-000009:notes:95]

[0000858877-14-000014:notes:103]
|  |  |  |  | GAINS (LOSSES) ON DERIVATIVEINSTRUMENTS FOR THE THREE MONTHS ENDED |  | GAINS (LOSSES) RELATED TO HEDGEDITEMS FOR THE THREE MONTHS ENDED |
| Derivatives Designated as Fair Value Hedging Instruments |  | Line Item in Statements of Operations |  | April 26, 2014 |  | April 27, 2013 |  | April 26, 2014 |  | April 27, 2013 |
| Equity derivatives |  | Other income (loss), net |  | $ | (8 | ) |  | $ | (45 | ) |  | $ | 8 |  |  | $ | 45 |  |
| Interest rate derivatives |  | Interest expense |  | 8 |  |  | (11 | ) |  | (8 | ) |  | 11 |  |
| Total |  |  |  | $ | — |  |  | $ | (56 | ) |  | $ | — |  |  | $ | 56 |  |

[0000858877-14-000014:notes:104]
|  |  |  |  | GAINS (LOSSES) ON DERIVATIVEINSTRUMENTS FOR THE NINE MONTHS ENDED |  | GAINS (LOSSES) RELATED TO HEDGEDITEMS FOR THE NINE MONTHS ENDED |
| Derivatives Designated as Fair Value Hedging Instruments |  | Line Item in Statements of Operations |  | April 26, 2014 |  | April 27, 2013 |  | April 26, 2014 |  | April 27, 2013 |
| Equity derivatives |  | Other income (loss), net |  | $ | (55 | ) |  | $ | (87 | ) |  | $ | 55 |  |  | $ | 87 |  |
| Interest rate derivatives |  | Interest expense |  | (27 | ) |  | (40 | ) |  | 26 |  |  | 40 |  |
| Total |  |  |  | $ | (82 | ) |  | $ | (127 | ) |  | $ | 81 |  |  | $ | 127 |  |

[0000858877-14-000014:notes:105]
[same as prior period, unchanged from 0000858877-14-000009:notes:98]

[0000858877-14-000014:notes:106]
|  |  |  |  | GAINS (LOSSES) FOR THE THREE MONTHS ENDED |  | GAINS (LOSSES) FOR THE NINE MONTHS ENDED |
| Derivatives Not Designated as Hedging Instruments |  | Line Item in Statements of Operations |  | April 26, 2014 |  | April 27, 2013 |  | April 26, 2014 |  | April 27, 2013 |
| Foreign currency derivatives |  | Other income (loss), net |  | $ | 36 |  |  | $ | (90 | ) |  | $ | 16 |  |  | $ | (78 | ) |
| Total return swaps—deferred compensation |  | Operating expenses |  | 4 |  |  | 12 |  |  | 33 |  |  | 45 |  |
| Equity derivatives |  | Other income (loss), net |  | 9 |  |  | (6 | ) |  | 33 |  |  | 6 |  |
| Total |  |  |  | $ | 49 |  |  | $ | (84 | ) |  | $ | 82 |  |  | $ | (27 | ) |

[0000858877-14-000014:notes:107]
[same as prior period, unchanged from 0000858877-14-000009:notes:100]

[0000858877-14-000014:notes:108]
|  | April 26, 2014 |  | July 27, 2013 |
| Derivatives designated as hedging instruments: |  |  |  |
| Foreign currency derivatives—cash flow hedges | $ | 432 |  |  | $ | 1,885 |  |
| Interest rate derivatives | 10,400 |  |  | 5,250 |  |
| Net investment hedging instruments | 328 |  |  | 662 |  |
| Equity derivatives | 238 |  |  | 1,098 |  |
| Derivatives not designated as hedging instruments: |  |  |  |
| Foreign currency derivatives | 2,864 |  |  | 3,739 |  |
| Total return swaps—deferred compensation | 411 |  |  | 358 |  |
| Total | $ | 14,673 |  |  | $ | 12,992 |  |

[0000858877-14-000014:notes:109]
[same as prior period, unchanged from 0000858877-14-000009:notes:102]

[0000858877-14-000014:notes:110]
The Company presents its derivative instruments at gross fair values in the Consolidated Balance Sheets.  However, the Company’s master netting and other similar arrangements with the respective counterparties allow for net settlement under certain conditions, which are designed to reduce credit risk by permitting net settlement with the same counterparty.  To further limit credit risk, the Company also enters into collateral security arrangements related to certain derivative instruments whereby cash is posted as collateral between the counterparties based on the fair market value of the derivative instrument.   Information related to these offsetting arrangements is summarized as follows (in millions):

[0000858877-14-000014:notes:111]
|  | OFFSETTING OF DERIVATIVE ASSETS |
|  | Gross Amounts Offset in Consolidated Balance Sheets |  | Gross Amounts Not Offset in the Consolidated Balance Sheets, but with Legal Rights to Offset |
| April 26, 2014 | Gross Amount of Recognized Assets |  | Gross Amounts Offset in Consolidated Balance Sheets |  | Net Amount Presented on Consolidated Balance Sheets |  | Gross Derivative Amounts with Legal Rights to Offset |  | Cash Collateral Received |  | Net Amount |
| Derivatives | $ | 148 |  |  | $ | — |  |  | $ | 148 |  |  | $ | (36 | ) |  | $ | (5 | ) |  | $ | 107 |  |

[0000858877-14-000014:notes:112]
|  | OFFSETTING OF DERIVATIVE LIABILITIES |
|  | Gross Amounts Offset in Consolidated Balance Sheets |  | Gross Amounts Not Offset in the Consolidated Balance Sheets, but with Legal Rights to Offset |
| April 26, 2014 | Gross Amount of Recognized Liabilities |  | Gross Amounts Offset in Consolidated Balance Sheets |  | Net Amount Presented on Consolidated Balance Sheets |  | Gross Derivative Amounts with Legal Rights to Offset |  | Cash Collateral Pledged |  | Net Amount |
| Derivatives | $ | 54 |  |  | $ | — |  |  | $ | 54 |  |  | $ | (36 | ) |  | $ | (16 | ) |  | $ | 2 |  |

[0000858877-14-000014:notes:113]
|  | OFFSETTING OF DERIVATIVE ASSETS |
|  | Gross Amounts Offset in Consolidated Balance Sheets |  | Gross Amounts Not Offset in the Consolidated Balance Sheets, but with Legal Rights to Offset |
| July 27, 2013 | Gross Amount of Recognized Assets |  | Gross Amounts Offset in Consolidated Balance Sheets |  | Net Amount Presented on Consolidated Balance Sheets |  | Gross Derivative Amounts with Legal Rights to Offset |  | Cash Collateral Received |  | Net Amount |
| Derivatives | $ | 182 |  |  | $ | — |  |  | $ | 182 |  |  | $ | (120 | ) |  | $ | — |  |  | $ | 62 |  |

[0000858877-14-000014:notes:114]
|  | OFFSETTING OF DERIVATIVE LIABILITIES |
|  | Gross Amounts Offset in Consolidated Balance Sheets |  | Gross Amounts Not Offset in the Consolidated Balance Sheets, but with Legal Rights to Offset |
| July 27, 2013 | Gross Amount of Recognized Liabilities |  | Gross Amounts Offset in Consolidated Balance Sheets |  | Net Amount Presented on Consolidated Balance Sheets |  | Gross Derivative Amounts with Legal Rights to Offset |  | Cash Collateral Pledged |  | Net Amount |
| Derivatives | $ | 171 |  |  | $ | — |  |  | $ | 171 |  |  | $ | (120 | ) |  | $ | — |  |  | $ | 51 |  |

[0000858877-14-000014:notes:115]
[same as prior period, unchanged from 0000858877-14-000009:notes:106]

[0000858877-14-000014:notes:116]
[same as prior period, unchanged from 0000858877-14-000009:notes:107]

[0000858877-14-000014:notes:117]
[same as prior period, unchanged from 0000858877-14-000009:notes:108]

[0000858877-14-000014:notes:118]
[same as prior period, unchanged from 0000858877-14-000009:notes:109]

[0000858877-14-000014:notes:119]
[same as prior period, unchanged from 0000858877-14-000009:notes:110]

[0000858877-14-000014:notes:120]
[same as prior period, unchanged from 0000858877-14-000009:notes:111]

[0000858877-14-000014:notes:121]
Interest Rate Derivatives, Investments   The Company’s primary objective for holding fixed income securities is to achieve an appropriate investment return consistent with preserving principal and managing risk. To realize these objectives, the Company may utilize interest rate swaps or other derivatives designated as fair value or cash flow hedges. As of April 26, 2014 and July 27, 2013, the Company did not have any outstanding interest rate derivatives related to its fixed income securities.

[0000858877-14-000014:notes:122]
Interest Rate Derivatives Designated as Fair Value Hedge, Long-Term Debt   In fiscal 2014 and 2013, the Company entered into interest rate swaps designated as fair value hedges related to fixed-rate senior notes that are due on various dates from 2017 through 2024. In the previous periods, the Company entered into interest rate swaps designated as fair value hedges related to fixed-rate senior notes that are due in 2016 and 2017. Under these interest rate swaps, the Company receives fixed-rate interest payments and makes interest payments based on LIBOR plus a fixed number of basis points. The effect of such swaps is to convert the fixed interest rates of the senior fixed-rate notes to floating interest rates based on LIBOR. The gains and losses related to changes in the fair value of the interest rate swaps are included in interest expense and substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates. The fair value of the interest rate swaps was reflected in other assets and other long-term liabilities.

[0000858877-14-000014:notes:123]
[same as prior period, unchanged from 0000858877-14-000009:notes:114]

[0000858877-14-000014:notes:124]
[same as prior period, unchanged from 0000858877-14-000009:notes:115]

[0000858877-14-000014:notes:125]
[same as prior period, unchanged from 0000858877-14-000009:notes:116]

[0000858877-14-000014:notes:126]
[same as prior period, unchanged from 0000858877-14-000009:notes:117]

[0000858877-14-000014:notes:127]
[same as prior period, unchanged from 0000858877-14-000009:notes:118]

[0000858877-14-000014:notes:128]
| (g) | Collateral and Credit-Risk-Related Contingent Features |

[0000858877-14-000014:notes:129]
For certain derivative instruments, the Company and its counterparties have entered into arrangements requiring the party that is in a liability position from a mark-to-market standpoint to post cash collateral to the other party.  See further discussion under "(b) Offsetting of Derivative Instruments" above.

[0000858877-14-000014:notes:130]
In addition, certain derivative instruments are executed under agreements that have provisions requiring the Company and the counterparty to maintain a specified credit rating from certain credit-rating agencies. Under such agreements, if the Company’s or the counterparty’s credit rating falls below a specified credit rating, either party has the right to request collateral on the derivatives’ net liability position. The fair market value of these derivatives as of April 26, 2014 and July 27, 2013 was $67 million and $88 million, respectively.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000858877-14-000014:notes:131]
[same as prior period, unchanged from 0000858877-14-000009:notes:121]

[0000858877-14-000014:notes:132]
[same as prior period, unchanged from 0000858877-14-000009:notes:122]

[0000858877-14-000014:notes:133]
Stock Incentive Plan Program Description   As of April 26, 2014, the Company had four stock incentive plans: the 2005 Stock Incentive Plan (the “2005 Plan”); the 1996 Stock Incentive Plan (the “1996 Plan”); the Cisco Systems, Inc. SA Acquisition Long-Term Incentive Plan (the “SA Acquisition Plan”); and the Cisco Systems, Inc. WebEx Acquisition Long-Term Incentive Plan (the “WebEx Acquisition Plan”). In addition, the Company has, in connection with the acquisitions of various companies, assumed the share-based awards granted under stock incentive plans of the acquired companies or issued share-based awards in replacement thereof. Share-based awards are designed to reward employees for their long-term contributions to the Company and provide incentives for them to remain with the Company. The number and frequency of share-based awards are based on competitive practices, operating results of the Company, government regulations, and other factors. Since the inception of the stock incentive plans, the Company has granted share-based awards to a significant percentage of its employees, and the majority has been granted to employees below the vice president level. The Company’s primary stock incentive plans are summarized as follows:

[0000858877-14-000014:notes:134]
2005 Plan   As of April 26, 2014, the maximum number of shares issuable under the 2005 Plan over its term was 694 million shares plus the number of any shares underlying awards outstanding on November 15, 2007 under the 1996 Plan, the SA Acquisition Plan, and the WebEx Acquisition Plan that are forfeited or are terminated for any other reason before being exercised or settled. If any awards granted under the 2005 Plan are forfeited or are terminated for any other reason before being exercised or settled, the unexercised or unsettled shares underlying the awards will again be available under the 2005 Plan. Starting November 19, 2013, shares withheld by the Company from an award other than a stock option or stock appreciation right to satisfy withholding tax liabilities resulting from such award will again be available for issuance, based on the fungible share ratio in effect on the date of grant.

[0000858877-14-000014:notes:135]
Pursuant to an amendment approved by the Company’s shareholders on November 12, 2009, the number of shares available for issuance under the 2005 Plan is reduced by 1.5 shares for each share awarded as a stock grant or a stock unit, and any shares underlying awards outstanding under the 1996 Plan, the SA Acquisition Plan, and the WebEx Acquisition Plan that expire unexercised at the end of their maximum terms become available for reissuance under the 2005 Plan. The 2005 Plan permits the granting of stock options, restricted stock, and restricted stock units (RSUs), the vesting of which may be performance-based or market-based along with the requisite service requirement, and stock appreciation rights to employees (including employee directors and officers), consultants of the Company and its subsidiaries and affiliates, and non-employee directors of the Company. Stock options and stock appreciation rights granted under the 2005 Plan have an exercise price of at least 100% of the fair market value of the underlying stock on the grant date and prior to November 12, 2009 have an expiration date no later than nine years from the grant date. The expiration date for stock options and stock appreciation rights granted subsequent to the amendment approved on November 12, 2009 shall be no later than 10 years from the grant date.

[0000858877-14-000014:notes:136]
The stock options will generally become exercisable for 20% or 25% of the option shares one year from the date of grant and then ratably over the following 48 months or 36 months, respectively. Time-based stock grants and time-based RSUs will generally vest with respect to 20% or 25% of the shares or share units covered by the grant on each of the first through fifth or fourth anniversaries of the date of the grant, respectively.  Performance-based and market-based RSUs typically vest at the end of the three-year requisite service period or earlier if the award recipient meets certain retirement eligibility conditions. The Compensation and Management Development Committee of the Board of Directors has the discretion to use different vesting schedules. Stock appreciation rights may be awarded in combination with stock options or stock grants, and such awards shall provide that the stock appreciation rights will not be exercisable unless the related stock options or stock grants are forfeited. Stock grants may be awarded in combination with non-statutory stock options, and such awards may provide that the stock grants will be forfeited in the event that the related non-statutory stock options are exercised.

[0000858877-14-000014:notes:137]
1996 Plan The 1996 Plan expired on December 31, 2006, and the Company can no longer make equity awards under the 1996 Plan. The maximum number of shares issuable over the term of the 1996 Plan was 2.5 billion shares. Stock options granted under the 1996 Plan have an exercise price of at least 100% of the fair market value of the underlying stock on the grant date and expire no later than nine years from the grant date. The stock options generally became exercisable for 20% or 25% of the option shares one year from the date of grant and then ratably over the following 48 months or 36 months, respectively. Certain other grants utilized a 60-month ratable vesting schedule. In addition, the Board of Directors, or other committees administering the 1996 Plan, had the discretion to use a different vesting schedule and did so from time to time.

[0000858877-14-000014:notes:138]
[same as prior period, unchanged from 0000858877-14-000009:notes:129]

[0000858877-14-000014:notes:139]
[same as prior period, unchanged from 0000858877-14-000009:notes:130]

[0000858877-14-000014:notes:140]
The Company has an Employee Stock Purchase Plan, which includes its subplan named the International Employee Stock Purchase Plan (together, the “Purchase Plan”), under which 471.4 million shares of the Company’s common stock have been reserved for issuance as of April 26, 2014.  Eligible employees are offered shares through a 24-month offering period, which consists of four consecutive 6-month purchase periods. Employees may purchase a limited number of shares of the Company’s stock at a discount of up to 15% of the lesser of the market value at the beginning of the offering period or the end of each 6-month purchase period. The Purchase Plan is scheduled to terminate on January 3, 2020. The Company issued 14 million and 18 million shares under the Purchase Plan during the nine months ended April 26, 2014 and April 27, 2013, respectively. As of April 26, 2014, 38 million shares were available for issuance under the Purchase Plan.

[0000858877-14-000014:notes:141]
[same as prior period, unchanged from 0000858877-14-000009:notes:132]

[0000858877-14-000014:notes:142]
[same as prior period, unchanged from 0000858877-14-000009:notes:133]

[0000858877-14-000014:notes:143]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 26, 2014 |  | April 27, 2013 |  | April 26, 2014 |  | April 27, 2013 |
| Cost of sales—product | $ | 12 |  |  | $ | 10 |  |  | $ | 34 |  |  | $ | 31 |  |
| Cost of sales—service | 39 |  |  | 34 |  |  | 112 |  |  | 105 |  |
| Share-based compensation expense in cost of sales | 51 |  |  | 44 |  |  | 146 |  |  | 136 |  |
| Research and development | 106 |  |  | 72 |  |  | 306 |  |  | 228 |  |
| Sales and marketing | 144 |  |  | 118 |  |  | 408 |  |  | 383 |  |
| General and administrative | 52 |  |  | 38 |  |  | 153 |  |  | 136 |  |
| Restructuring and other charges | — |  |  | — |  |  | (4 | ) |  | (3 | ) |
| Share-based compensation expense in operating expenses | 302 |  |  | 228 |  |  | 863 |  |  | 744 |  |
| Total share-based compensation expense | $ | 353 |  |  | $ | 272 |  |  | $ | 1,009 |  |  | $ | 880 |  |
| Income tax benefit for share-based compensation | $ | 86 |  |  | $ | 73 |  |  | $ | 246 |  |  | $ | 232 |  |

[0000858877-14-000014:notes:144]
As of April 26, 2014, the total compensation cost related to unvested share-based awards not yet recognized was $2.7 billion, which is expected to be recognized over approximately 2.4 years on a weighted-average basis.

[0000858877-14-000014:notes:145]
[same as prior period, unchanged from 0000858877-14-000009:notes:136]

[0000858877-14-000014:notes:146]
[same as prior period, unchanged from 0000858877-14-000009:notes:137]

[0000858877-14-000014:notes:147]
|  | Share-Based Awards Available for Grant |
| BALANCE AT JULY 28, 2012 | 218 |  |
| Restricted stock, stock units, and other share-based awards granted | (102 | ) |
| Share-based awards canceled/forfeited/expired | 115 |  |
| Other | (3 | ) |
| BALANCE AT JULY 27, 2013 | 228 |  |
| Restricted stock, stock units, and other share-based awards granted | (92 | ) |
| Share-based awards canceled/forfeited/expired | 29 |  |
| Additional shares reserved | 135 |  |
| Shares withheld for taxes and not issued | 2 |  |
| Other | 1 |  |
| BALANCE AT APRIL 26, 2014 | 303 |  |

[0000858877-14-000014:notes:148]
[same as prior period, unchanged from 0000858877-14-000009:notes:139]

[0000858877-14-000014:notes:149]
[same as prior period, unchanged from 0000858877-14-000009:notes:140]

[0000858877-14-000014:notes:150]
[same as prior period, unchanged from 0000858877-14-000009:notes:141]

[0000858877-14-000014:notes:151]
|  | Restricted Stock/Stock Units |  | Weighted-Average Grant Date Fair Value per Share |  | Aggregated Fair Market Value |
| UNVESTED BALANCE AT JULY 28, 2012 | 128 |  |  | $ | 19.46 |  |  |  |
| Granted and assumed | 72 |  |  | 18.52 |  |  |  |
| Vested | (46 | ) |  | 20.17 |  |  | $ | 932 |  |
| Canceled/forfeited | (11 | ) |  | 18.91 |  |  |  |
| UNVESTED BALANCE AT JULY 27, 2013 | 143 |  |  | 18.80 |  |  |  |
| Granted and assumed | 67 |  |  | 20.74 |  |  |  |
| Vested | (43 | ) |  | 19.56 |  |  | $ | 998 |  |
| Canceled/forfeited | (10 | ) |  | 18.70 |  |  |  |
| UNVESTED BALANCE AT APRIL 26, 2014 | 157 |  |  | $ | 19.43 |  |  |  |

[0000858877-14-000014:notes:152]
[same as prior period, unchanged from 0000858877-14-000009:notes:143]

[0000858877-14-000014:notes:153]
[same as prior period, unchanged from 0000858877-14-000009:notes:144]

[0000858877-14-000014:notes:154]
|  | STOCK OPTIONS OUTSTANDING |
|  | Number Outstanding |  | Weighted-Average Exercise Price per Share |
| BALANCE AT JULY 28, 2012 | 520 |  |  | $ | 22.68 |  |
| Assumed from acquisitions | 10 |  |  | 0.77 |  |
| Exercised | (154 | ) |  | 18.51 |  |
| Canceled/forfeited/expired | (100 | ) |  | 22.18 |  |
| BALANCE AT JULY 27, 2013 | 276 |  |  | 24.44 |  |
| Assumed from acquisitions | 6 |  |  | 3.69 |  |
| Exercised | (45 | ) |  | 17.54 |  |
| Canceled/forfeited/expired | (14 | ) |  | 27.41 |  |
| BALANCE AT APRIL 26, 2014 | 223 |  |  | $ | 25.09 |  |

[0000858877-14-000014:notes:155]
The following table summarizes significant ranges of outstanding and exercisable stock options as of April 26, 2014 (in millions, except years and share prices):

[0000858877-14-000014:notes:156]
|  | STOCK OPTIONS OUTSTANDING |  | STOCK OPTIONS EXERCISABLE |
| Range of Exercise Prices | Number Outstanding |  | Weighted-Average Remaining Contractual Life(in Years) |  | Weighted-Average Exercise Price per Share |  | Aggregate Intrinsic Value |  | Number Exercisable |  | Weighted-Average Exercise Price per Share |  | Aggregate Intrinsic Value |
| $ 0.01 – 15.00 | 9 |  |  | 5.2 |  | $ | 4.29 |  |  | $ | 180 |  |  | 4 |  |  | $ | 6.11 |  |  | $ | 85 |  |
| 15.01 – 18.00 | 25 |  |  | 0.5 |  | 17.81 |  |  | 128 |  |  | 25 |  |  | 17.81 |  |  | 128 |  |
| 18.01 – 20.00 | 7 |  |  | 0.6 |  | 19.22 |  |  | 25 |  |  | 7 |  |  | 19.22 |  |  | 25 |  |
| 20.01 – 25.00 | 76 |  |  | 1.4 |  | 22.85 |  |  | 15 |  |  | 76 |  |  | 22.85 |  |  | 15 |  |
| 25.01 – 30.00 | 28 |  |  | 2.1 |  | 26.59 |  |  | — |  |  | 28 |  |  | 26.59 |  |  | — |  |
| 30.01 – 35.00 | 78 |  |  | 2.2 |  | 32.16 |  |  | — |  |  | 78 |  |  | 32.16 |  |  | — |  |
| Total | 223 |  |  | 1.8 |  | $ | 25.09 |  |  | $ | 348 |  |  | 218 |  |  | $ | 25.57 |  |  | $ | 253 |  |

[0000858877-14-000014:notes:157]
The aggregate intrinsic value in the preceding table represents the total pretax intrinsic value, based on the Company’s closing stock price of $23.00 as of April 25, 2014, that would have been received by the option holders had those option holders exercised their stock options as of that date. The total number of in-the-money stock options exercisable as of April 26, 2014 was 47 million.  As of July 27, 2013, 271 million outstanding stock options were exercisable, and the weighted-average exercise price was $24.84.

[0000858877-14-000014:notes:158]
[same as prior period, unchanged from 0000858877-14-000009:notes:149]

[0000858877-14-000014:notes:159]
Time-based restricted stock units and performance-based restricted stock units (PRSUs) that are based on the Company’s financial performance metrics or non-financial operating goals are valued using the market value of the Company’s common stock on the date of grant, discounted for the present value of expected dividends. On the date of grant, the Company estimated the fair value of the total shareholder return (TSR) component of the PRSUs using a Monte Carlo simulation model. The valuation of time-based RSUs and PRSUs is summarized as follows:

[0000858877-14-000014:notes:160]
|  | RESTRICTED STOCK UNITS |  | PERFORMANCE RESTRICTED STOCK UNITS |
| Three Months Ended | April 26, 2014 |  | April 27, 2013 |  | April 26, 2014 |  | April 27, 2013 |
| Number of shares granted (in millions) | 6 |  |  | 4 |  |  | 2 |  |  | — |  |
| Grant date fair value per share | $ | 19.95 |  |  | $ | 19.59 |  |  | 19.85 |  |  | N/A |  |
| Weighted-average assumptions/inputs: |  |  |  |  |  |  |  |
| Expected dividend yield | 3.1 | % |  | 2.7 | % |  | 3.5 | % |  | N/A |  |
| Range of risk-free interest rates | 0.0% - 1.7% |  |  | 0.1% - 0.9% |  |  | 0.1% - 1.7% |  |  | N/A |  |
| Range of expected volatilities for index | N/A |  |  | N/A |  |  | N/A |  |  | N/A |  |

[0000858877-14-000014:notes:161]
|  | RESTRICTED STOCK UNITS |  | PERFORMANCE RESTRICTED STOCK UNITS |
| Nine Months Ended | April 26, 2014 |  | April 27, 2013 |  | April 26, 2014 |  | April 27, 2013 |
| Number of shares granted (in millions) | 53 |  |  | 56 |  |  | 6 |  |  | 4 |  |
| Grant date fair value per share | $ | 20.50 |  |  | $ | 17.47 |  |  | $ | 21.73 |  |  | $ | 19.26 |  |
| Weighted-average assumptions/inputs: |  |  |  |  |  |  |  |
| Expected dividend yield | 3.1 | % |  | 3.0 | % |  | 2.7 | % |  | 2.9 | % |
| Range of risk-free interest rates | 0.0% - 1.7% |  |  | 0.0% - 0.9% |  |  | 0.0% - 1.7% |  |  | 0.1% - 0.7% |  |
| Range of expected volatilities for index | N/A |  |  | N/A |  |  | 17.4% - 70.5% |  |  | 18.3% - 64.6% |  |

[0000858877-14-000014:notes:162]
The PRSUs granted during the first nine months of fiscal 2014 and fiscal 2013 are contingent on the achievement of the Company’s financial performance metrics, its comparative market-based returns, or the achievement of non-financial operating goals.  For the awards based on financial performance metrics or its comparative market-based returns, generally 50% of the PRSUs are earned based on the average of annual operating cash flow and earnings per share goals established at the beginning of each fiscal year over a three-year performance period. Generally, the remaining 50% of the PRSUs are earned based on the Company’s TSR measured against the benchmark TSR of a peer group over the same period. Each PRSU recipient could vest in 0% to 150% of the target shares granted contingent on the achievement of the Company’s financial performance metrics or its comparative market-based returns, and 0% or 100% of the target shares granted contingent on the achievement of non-financial operating goals.


## us-gaap:EarningsPerShareTextBlock

[0000858877-14-000014:notes:163]
[same as prior period, unchanged from 0000858877-14-000009:notes:154]

[0000858877-14-000014:notes:164]
[same as prior period, unchanged from 0000858877-14-000009:notes:155]

[0000858877-14-000014:notes:165]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 26, 2014 |  | April 27, 2013 |  | April 26, 2014 |  | April 27, 2013 |
| Net income | $ | 2,181 |  |  | $ | 2,478 |  |  | $ | 5,606 |  |  | $ | 7,713 |  |
| Weighted-average shares—basic | 5,143 |  |  | 5,329 |  |  | 5,271 |  |  | 5,316 |  |
| Effect of dilutive potential common shares | 37 |  |  | 58 |  |  | 40 |  |  | 45 |  |
| Weighted-average shares—diluted | 5,180 |  |  | 5,387 |  |  | 5,311 |  |  | 5,361 |  |
| Net income per share—basic | $ | 0.42 |  |  | $ | 0.47 |  |  | $ | 1.06 |  |  | $ | 1.45 |  |
| Net income per share—diluted | $ | 0.42 |  |  | $ | 0.46 |  |  | $ | 1.06 |  |  | $ | 1.44 |  |
| Antidilutive employee share-based awards, excluded | 240 |  |  | 245 |  |  | 331 |  |  | 417 |  |

[0000858877-14-000014:notes:166]
[same as prior period, unchanged from 0000858877-14-000009:notes:157]


## us-gaap:FairValueAssetsMeasuredOnNonrecurringBasisTextBlock

[0000858877-14-000014:notes:167]
For the three and nine months ended April 27, 2013, the Company’s financial instruments and nonfinancial assets that were measured at fair value on a nonrecurring basis are summarized as follows (in millions):

[0000858877-14-000014:notes:168]
|  |  | April 27, 2013 |
|  |  | Net Carrying Value as of End of Period |  | Total Gains (Losses) for the Three Months Ended |  | Total Gains (Losses) for the Nine Months Ended |
| Assets held for sale |  | $ | 72 |  |  | $ | 44 |  |  | $ | 44 |  |
| Investments in privately held companies (impaired) |  | $ | 66 |  |  | (5 | ) |  | (23 | ) |
| Gains on assets no longer held at period end |  |  |  | 34 |  |  | 34 |  |
| Net losses for nonrecurring measurement |  |  |  | $ | 73 |  |  | $ | 55 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000858877-14-000014:notes:169]
[same as prior period, unchanged from 0000858877-14-000009:notes:161]

[0000858877-14-000014:notes:170]
[same as prior period, unchanged from 0000858877-14-000009:notes:162]

[0000858877-14-000014:notes:171]
[same as prior period, unchanged from 0000858877-14-000009:notes:163]

[0000858877-14-000014:notes:172]
[same as prior period, unchanged from 0000858877-14-000009:notes:164]

[0000858877-14-000014:notes:173]
[same as prior period, unchanged from 0000858877-14-000009:notes:165]

[0000858877-14-000014:notes:174]
Level 2 applies to assets or liabilities for which there are inputs other than quoted prices, that are observable for the asset or liability, such as quoted prices for similar assets or liabilities in active markets; quoted prices for identical assets or liabilities in markets with insufficient volume or infrequent transactions (less active markets); or model-derived valuations in which significant inputs are observable or can be derived principally from, or corroborated by, observable market data.

[0000858877-14-000014:notes:175]
[same as prior period, unchanged from 0000858877-14-000009:notes:167]

[0000858877-14-000014:notes:176]
[same as prior period, unchanged from 0000858877-14-000009:notes:168]

[0000858877-14-000014:notes:177]
Assets and liabilities measured at fair value on a recurring basis as of April 26, 2014 and July 27, 2013 were as follows (in millions):

[0000858877-14-000014:notes:178]
|  | APRIL 26, 2014FAIR VALUE MEASUREMENTS |  | JULY 27, 2013FAIR VALUE MEASUREMENTS |
|  | Level 1 |  | Level 2 |  | Total Balance |  | Level 1 |  | Level 2 |  | Total Balance |
| Assets |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 4,475 |  |  | $ | — |  |  | $ | 4,475 |  |  | $ | 6,045 |  |  | $ | — |  |  | $ | 6,045 |  |
| Available-for-sale investments: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | — |  |  | 31,703 |  |  | 31,703 |  |  | — |  |  | 27,823 |  |  | 27,823 |  |
| U.S. government agency securities | — |  |  | 1,061 |  |  | 1,061 |  |  | — |  |  | 3,089 |  |  | 3,089 |  |
| Non-U.S. government and agency securities | — |  |  | 820 |  |  | 820 |  |  | — |  |  | 1,095 |  |  | 1,095 |  |
| Corporate debt securities | — |  |  | 8,115 |  |  | 8,115 |  |  | — |  |  | 7,881 |  |  | 7,881 |  |
| U.S. agency mortgage-backed securities | — |  |  | 570 |  |  | 570 |  |  | — |  |  | — |  |  | — |  |
| Publicly traded equity securities | 1,959 |  |  | — |  |  | 1,959 |  |  | 2,797 |  |  | — |  |  | 2,797 |  |
| Derivative assets | — |  |  | 148 |  |  | 148 |  |  | — |  |  | 182 |  |  | 182 |  |
| Total | $ | 6,434 |  |  | $ | 42,417 |  |  | $ | 48,851 |  |  | $ | 8,842 |  |  | $ | 40,070 |  |  | $ | 48,912 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities | $ | — |  |  | $ | 54 |  |  | $ | 54 |  |  | $ | — |  |  | $ | 171 |  |  | $ | 171 |  |
| Total | $ | — |  |  | $ | 54 |  |  | $ | 54 |  |  | $ | — |  |  | $ | 171 |  |  | $ | 171 |  |

[0000858877-14-000014:notes:179]
Level 1 publicly traded equity securities are determined by using quoted prices in active markets for identical assets.  Level 2 fixed income securities are priced using quoted market prices for similar instruments or nonbinding market prices that are corroborated by observable market data. The Company uses inputs such as actual trade data, benchmark yields, broker/dealer quotes, and other similar data, which are obtained from quoted market prices, independent pricing vendors, or other sources, to determine the ultimate fair value of these assets and liabilities. The Company uses such pricing data as the primary input to make its assessments and determinations as to the ultimate valuation of its investment portfolio and has not made, during the periods presented, any material adjustments to such inputs. The Company is ultimately responsible for the financial statements and underlying estimates. The Company’s derivative instruments are primarily classified as Level 2, as they are not actively traded and are valued using pricing models that use observable market inputs. The Company did not have any transfers between Level 1 and Level 2 fair value measurements during the periods presented.

[0000858877-14-000014:notes:180]
[same as prior period, unchanged from 0000858877-14-000009:notes:172]

[0000858877-14-000014:notes:181]
For the nine months ended April 26, 2014, the Company recognized $10 million of losses related to the impairment of privately held investments.

[0000858877-14-000014:notes:182]
The assets in the preceding table were measured at fair value due to events or circumstances the Company identified as having significant impact on their fair value during the respective periods.  To arrive at the valuation of these assets, the Company considers any significant changes in the financial metrics and economic variables, and also uses third-party valuation reports to assist in the valuation as necessary.

[0000858877-14-000014:notes:183]
[same as prior period, unchanged from 0000858877-14-000009:notes:174]

[0000858877-14-000014:notes:184]
The assets held for sale represent primarily land and buildings, as well as other items which met the criteria to be classified as held for sale.  The fair value of assets held for sale was measured with the assistance of third-party valuation models which used discounted cash flow techniques as part of their analysis.  The fair value measurement was categorized as Level 3 as significant unobservable inputs were used in the valuation report.  The impairment charges as a result of the valuations, which represented the difference between the fair value less cost to sell and the carrying amount of the assets held for sale, were included in G&A expenses.  Substantially all of the assets held for sale as of April 27, 2013 were sold by the end of fiscal 2013.

[0000858877-14-000014:notes:185]
[same as prior period, unchanged from 0000858877-14-000009:notes:175]

[0000858877-14-000014:notes:186]
The carrying value of the Company’s investments in privately held companies that were accounted for under the cost method was $273 million and $242 million as of April 26, 2014 and July 27, 2013, respectively. It was not practicable to estimate the fair value of this portfolio.

[0000858877-14-000014:notes:187]
The fair value of the Company’s short-term loan receivables and financed service contracts approximates their carrying value due to their short duration. The aggregate carrying value of the Company’s long-term loan receivables and financed service contracts and other as of April 26, 2014 and July 27, 2013 was $1.7 billion and $2.1 billion, respectively.  The estimated fair value of the Company’s long-term loan receivables and financed service contracts and other approximates their carrying value. The Company uses significant unobservable inputs in determining discounted cash flows to estimate the fair value of its loan receivables and financed service contracts, and therefore they are categorized as Level 3.

[0000858877-14-000014:notes:188]
As of April 26, 2014, the fair value of the Company’s senior notes and other long-term debt was $22.4 billion with a carrying amount of $20.9 billion.  This compares to a fair value of $17.6 billion and a carrying amount of $16.2 billion as of July 27, 2013.  The fair value of the senior notes and other long-term debt was determined based on observable market prices in a less active market and was categorized as Level 2 in the fair value hierarchy.


## us-gaap:FinancingReceivableCreditQualityIndicatorsTableTextBlock

[0000858877-14-000014:notes:189]
Financing receivables categorized by the Company’s internal credit risk rating as of April 26, 2014 and July 27, 2013 are summarized as follows (in millions):

[0000858877-14-000014:notes:190]
|  | INTERNAL CREDIT RISK RATING |  |  |  |  |  |  |
| April 26, 2014 | 1 to 4 |  | 5 to 6 |  | 7 and Higher |  | Total |  | Residual Value |  | Gross Receivables, Net of Unearned Income |
| Lease receivables | $ | 1,604 |  |  | $ | 1,557 |  |  | $ | 133 |  |  | $ | 3,294 |  |  | $ | 243 |  |  | $ | 3,537 |  |
| Loan receivables | 894 |  |  | 595 |  |  | 132 |  |  | 1,621 |  |  | — |  |  | 1,621 |  |
| Financed service contracts and other | 1,569 |  |  | 1,160 |  |  | 81 |  |  | 2,810 |  |  | — |  |  | 2,810 |  |
| Total | $ | 4,067 |  |  | $ | 3,312 |  |  | $ | 346 |  |  | $ | 7,725 |  |  | $ | 243 |  |  | $ | 7,968 |  |

[0000858877-14-000014:notes:191]
[same as prior period, unchanged from 0000858877-14-000009:notes:181]


## us-gaap:FinancingReceivablesTextBlock

[0000858877-14-000014:notes:192]
[same as prior period, unchanged from 0000858877-14-000009:notes:182]

[0000858877-14-000014:notes:193]
[same as prior period, unchanged from 0000858877-14-000009:notes:183]

[0000858877-14-000014:notes:194]
[same as prior period, unchanged from 0000858877-14-000009:notes:184]

[0000858877-14-000014:notes:195]
[same as prior period, unchanged from 0000858877-14-000009:notes:185]

[0000858877-14-000014:notes:196]
| April 26, 2014 | Lease Receivables |  | Loan Receivables |  | Financed Service Contracts and Other |  | Total Financing Receivables |
| Gross | $ | 3,783 |  |  | $ | 1,621 |  |  | $ | 2,810 |  |  | $ | 8,214 |  |
| Unearned income | (246 | ) |  | — |  |  | — |  |  | (246 | ) |
| Allowance for credit loss | (249 | ) |  | (92 | ) |  | (19 | ) |  | (360 | ) |
| Total, net | $ | 3,288 |  |  | $ | 1,529 |  |  | $ | 2,791 |  |  | $ | 7,608 |  |
| Reported as: |  |  |  |  |  |  |  |
| Current | $ | 1,480 |  |  | $ | 814 |  |  | $ | 1,777 |  |  | $ | 4,071 |  |
| Noncurrent | 1,808 |  |  | 715 |  |  | 1,014 |  |  | 3,537 |  |
| Total, net | $ | 3,288 |  |  | $ | 1,529 |  |  | $ | 2,791 |  |  | $ | 7,608 |  |

[0000858877-14-000014:notes:197]
[same as prior period, unchanged from 0000858877-14-000009:notes:187]

[0000858877-14-000014:notes:198]
As of April 26, 2014 and July 27, 2013, the deferred service revenue related to the financed service contracts and other was $1,592 million and $2,036 million, respectively.

[0000858877-14-000014:notes:199]
Contractual maturities of the gross lease receivables at April 26, 2014 are summarized as follows (in millions):

[0000858877-14-000014:notes:200]
| Fiscal Year |  | Amount |
| 2014 (remaining three months) |  | $ | 589 |  |
| 2015 |  | 1,471 |  |
| 2016 |  | 971 |  |
| 2017 |  | 524 |  |
| 2018 |  | 194 |  |
| Thereafter |  | 34 |  |
| Total |  | $ | 3,783 |  |

[0000858877-14-000014:notes:201]
[same as prior period, unchanged from 0000858877-14-000009:notes:191]

[0000858877-14-000014:notes:202]
[same as prior period, unchanged from 0000858877-14-000009:notes:192]

[0000858877-14-000014:notes:203]
[same as prior period, unchanged from 0000858877-14-000009:notes:193]

[0000858877-14-000014:notes:204]
[same as prior period, unchanged from 0000858877-14-000009:notes:194]

[0000858877-14-000014:notes:205]
In circumstances when collectibility is not deemed reasonably assured, the associated revenue is deferred in accordance with the Company’s revenue recognition policies, and the related allowance for credit loss, if any, is included in deferred revenue. The Company also records deferred revenue associated with financing receivables when there are remaining performance obligations, as it does for financed service contracts. Total allowances for credit loss and deferred revenue as of April 26, 2014 and July 27, 2013 were $1,989 million and $2,453 million, respectively, and they were associated with financing receivables (net of unearned income) of $7,968 million and $8,292 million as of their respective period ends.

[0000858877-14-000014:notes:206]
The following tables present the aging analysis of financing receivables as of April 26, 2014 and July 27, 2013 (in millions):

[0000858877-14-000014:notes:207]
|  | DAYS PAST DUE (INCLUDES BILLED AND UNBILLED) |  |  |  |  |  |  |  |  |
| April 26, 2014 | 31-60 |  | 61-90 |  | 91+ |  | Total Past Due |  | Current |  | Gross Receivables,Net of Unearned Income |  | Nonaccrual Financing Receivables |  | Impaired Financing Receivables |
| Lease receivables | $ | 83 |  |  | $ | 41 |  |  | $ | 165 |  |  | $ | 289 |  |  | $ | 3,248 |  |  | $ | 3,537 |  |  | $ | 67 |  |  | $ | 54 |  |
| Loan receivables | 5 |  |  | 6 |  |  | 15 |  |  | 26 |  |  | 1,595 |  |  | 1,621 |  |  | 8 |  |  | 8 |  |
| Financed service contracts and other | 228 |  |  | 96 |  |  | 239 |  |  | 563 |  |  | 2,247 |  |  | 2,810 |  |  | 11 |  |  | 8 |  |
| Total | $ | 316 |  |  | $ | 143 |  |  | $ | 419 |  |  | $ | 878 |  |  | $ | 7,090 |  |  | $ | 7,968 |  |  | $ | 86 |  |  | $ | 70 |  |

[0000858877-14-000014:notes:208]
[same as prior period, unchanged from 0000858877-14-000009:notes:198]

[0000858877-14-000014:notes:209]
Past due financing receivables are those that are 31 days or more past due according to their contractual payment terms. The data in the preceding tables are presented by contract, and the aging classification of each contract is based on the oldest outstanding receivable, and therefore past due amounts also include unbilled and current receivables within the same contract.  The balances of either unbilled or current financing receivables included in the category of 91 days plus past due for financing receivables were $295 million and $406 million as of April 26, 2014 and July 27, 2013, respectively.

[0000858877-14-000014:notes:210]
As of April 26, 2014, the Company had financing receivables of $88 million, net of unbilled or current receivables from the same contract, that were in the category of 91 days plus past due but remained on accrual status. Such balance was $87 million as of July 27, 2013. A financing receivable may be placed on nonaccrual status earlier if, in management’s opinion, a timely collection of the full principal and interest becomes uncertain.

[0000858877-14-000014:notes:211]
[same as prior period, unchanged from 0000858877-14-000009:notes:201]

[0000858877-14-000014:notes:212]
[same as prior period, unchanged from 0000858877-14-000009:notes:202]

[0000858877-14-000014:notes:213]
Typically, the Company also considers receivables with a risk rating of 8 or higher to be impaired and will include them in the individual assessment for allowance. These balances, as of April 26, 2014 and July 27, 2013, are presented under “(b) Credit Quality of Financing Receivables” above.

[0000858877-14-000014:notes:214]
[same as prior period, unchanged from 0000858877-14-000009:notes:204]

[0000858877-14-000014:notes:215]
[same as prior period, unchanged from 0000858877-14-000009:notes:205]

[0000858877-14-000014:notes:216]
[same as prior period, unchanged from 0000858877-14-000009:notes:206]

[0000858877-14-000014:notes:217]
Channel Partner Financing Guarantees The Company facilitates arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, generally with payment terms ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, the Company guarantees a portion of these arrangements. The volume of channel partner financing was $5.8 billion for each of the three months ended April 26, 2014 and April 27, 2013, respectively.  The volume of channel partner financing was $17.9 billion and $17.2 billion for the nine months ended April 26, 2014 and April 27, 2013, respectively.  The balance of the channel partner financing subject to guarantees was $1.1 billion and $1.4 billion as of April 26, 2014 and July 27, 2013, respectively.

[0000858877-14-000014:notes:218]
End-User Financing Guarantees The Company also provides financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. The volume of financing provided by third parties for leases and loans as to which the Company had provided guarantees was $44 million and $38 million for the three months ended April 26, 2014 and April 27, 2013, respectively, and was $89 million and $137 million for the nine months ended April 26, 2014 and April 27, 2013, respectively.

[0000858877-14-000014:notes:219]
Financing Guarantee Summary  The aggregate amounts of financing guarantees outstanding at April 26, 2014 and July 27, 2013, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

[0000858877-14-000014:notes:220]
|  | April 26, 2014 |  | July 27, 2013 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 247 |  |  | $ | 438 |  |
| End user | 229 |  |  | 237 |  |
| Total | $ | 476 |  |  | $ | 675 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (132 | ) |  | $ | (225 | ) |
| End user | (198 | ) |  | (191 | ) |
| Total | $ | (330 | ) |  | $ | (416 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue | $ | 146 |  |  | $ | 259 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000858877-14-000014:notes:221]
[same as prior period, unchanged from 0000858877-14-000009:notes:211]

[0000858877-14-000014:notes:222]
[same as prior period, unchanged from 0000858877-14-000009:notes:212]

[0000858877-14-000014:notes:223]
The following table presents the goodwill allocated to the Company’s reportable segments as of and during the nine months ended April 26, 2014 (in millions):

[0000858877-14-000014:notes:224]
|  |  | Balance atJuly 27, 2013 |  | Acquisitions |  | Other |  | Balance at April 26, 2014 |
| Americas |  | $ | 13,800 |  |  | $ | 1,198 |  |  | $ | (12 | ) |  | $ | 14,986 |  |
| EMEA |  | 5,037 |  |  | 638 |  |  | (3 | ) |  | 5,672 |  |
| APJC |  | 3,082 |  |  | 336 |  |  | — |  |  | 3,418 |  |
| Total |  | $ | 21,919 |  |  | $ | 2,172 |  |  | $ | (15 | ) |  | $ | 24,076 |  |

[0000858877-14-000014:notes:225]
[same as prior period, unchanged from 0000858877-14-000009:notes:215]

[0000858877-14-000014:notes:226]
The following table presents details of the Company’s intangible assets acquired through business combinations completed during the nine months ended April 26, 2014 (in millions, except years):

[0000858877-14-000014:notes:227]
[same as prior period, unchanged from 0000858877-14-000009:notes:217]

[0000858877-14-000014:notes:228]
[same as prior period, unchanged from 0000858877-14-000009:notes:218]

[0000858877-14-000014:notes:229]
| April 26, 2014 |  | Gross |  | Accumulated Amortization |  | Net |
| Purchased intangible assets with finite lives: |  |  |  |  |  |  |
| Technology |  | $ | 4,117 |  |  | $ | (1,885 | ) |  | $ | 2,232 |  |
| Customer relationships |  | 1,698 |  |  | (653 | ) |  | 1,045 |  |
| Other |  | 56 |  |  | (16 | ) |  | 40 |  |
| Total purchased intangible assets with finite lives |  | 5,871 |  |  | (2,554 | ) |  | 3,317 |  |
| In-process research and development, with indefinite lives |  | 144 |  |  | — |  |  | 144 |  |
| Total |  | $ | 6,015 |  |  | $ | (2,554 | ) |  | $ | 3,461 |  |

[0000858877-14-000014:notes:230]
[same as prior period, unchanged from 0000858877-14-000009:notes:220]

[0000858877-14-000014:notes:231]
[same as prior period, unchanged from 0000858877-14-000009:notes:221]

[0000858877-14-000014:notes:232]
[same as prior period, unchanged from 0000858877-14-000009:notes:222]

[0000858877-14-000014:notes:233]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 26, 2014 |  | April 27, 2013 |  | April 26, 2014 |  | April 27, 2013 |
| Amortization of purchased intangible assets: |  |  |  |  |  |  |  |
| Cost of sales | $ | 190 |  |  | $ | 156 |  |  | $ | 553 |  |  | $ | 444 |  |
| Operating expenses | 71 |  |  | 89 |  |  | 207 |  |  | 329 |  |
| Total | $ | 261 |  |  | $ | 245 |  |  | $ | 760 |  |  | $ | 773 |  |

[0000858877-14-000014:notes:234]
[same as prior period, unchanged from 0000858877-14-000009:notes:224]

[0000858877-14-000014:notes:235]
The estimated future amortization expense of purchased intangible assets with finite lives as of April 26, 2014 is as follows (in millions):

[0000858877-14-000014:notes:236]
| Fiscal Year |  | Amount |
| 2014 (remaining three months) |  | $ | 259 |  |
| 2015 |  | 959 |  |
| 2016 |  | 726 |  |
| 2017 |  | 550 |  |
| 2018 |  | 398 |  |
| Thereafter |  | 425 |  |
| Total |  | $ | 3,317 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000858877-14-000014:notes:237]
[same as prior period, unchanged from 0000858877-14-000009:notes:227]

[0000858877-14-000014:notes:238]
[same as prior period, unchanged from 0000858877-14-000009:notes:228]

[0000858877-14-000014:notes:239]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 26, 2014 |  | April 27, 2013 |  | April 26, 2014 |  | April 27, 2013 |
| Income before provision for income taxes | $ | 2,642 |  |  | $ | 2,945 |  |  | $ | 6,937 |  |  | $ | 8,356 |  |
| Provision for income taxes | $ | 461 |  |  | $ | 467 |  |  | $ | 1,331 |  |  | $ | 643 |  |
| Effective tax rate | 17.4 | % |  | 15.9 | % |  | 19.2 | % |  | 7.7 | % |

[0000858877-14-000014:notes:240]
As of April 26, 2014, the Company had $1.9 billion of unrecognized tax benefits, of which $1.6 billion, if recognized, would favorably impact the effective tax rate. The Company regularly engages in discussions and negotiations with tax authorities regarding tax matters in various jurisdictions. The Company believes it is reasonably possible that certain federal, foreign, and state tax matters may be concluded in the next 12 months. Specific positions that may be resolved include issues involving transfer pricing and various other matters. The Company estimates that it is reasonably possible that the unrecognized tax benefits at April 26, 2014 could be reduced by $300 million in the next 12 months.


## us-gaap:InventoryDisclosureTextBlock

[0000858877-14-000014:notes:241]
[same as prior period, unchanged from 0000858877-14-000009:notes:231]

[0000858877-14-000014:notes:242]
|  |  | April 26, 2014 |  | July 27, 2013 |
| Inventories: |  |  |  |  |
| Raw materials |  | $ | 57 |  |  | $ | 105 |  |
| Work in process |  | 5 |  |  | 24 |  |
| Finished goods: |  |  |  |  |
| Distributor inventory and deferred cost of sales |  | 623 |  |  | 572 |  |
| Manufactured finished goods |  | 550 |  |  | 480 |  |
| Total finished goods |  | 1,173 |  |  | 1,052 |  |
| Service-related spares |  | 255 |  |  | 256 |  |
| Demonstration systems |  | 38 |  |  | 39 |  |
| Total |  | $ | 1,528 |  |  | $ | 1,476 |  |


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0000858877-14-000014:notes:243]
The following table summarizes the maturities of the Company’s fixed income securities at April 26, 2014 (in millions):

[0000858877-14-000014:notes:244]
|  | Amortized Cost |  | Fair Value |
| Less than 1 year | $ | 15,022 |  |  | $ | 15,038 |  |
| Due in 1 to 2 years | 13,061 |  |  | 13,101 |  |
| Due in 2 to 5 years | 13,380 |  |  | 13,415 |  |
| Due after 5 years | 708 |  |  | 715 |  |
| Total | $ | 42,171 |  |  | $ | 42,269 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000858877-14-000014:notes:245]
| 8. | Investments |

[0000858877-14-000014:notes:246]
| (a) | Summary of Available-for-Sale Investments |

[0000858877-14-000014:notes:247]
The following tables summarize the Company’s available-for-sale investments (in millions):

[0000858877-14-000014:notes:248]
| April 26, 2014 | Amortized Cost |  | Gross Unrealized Gains |  | Gross Unrealized Losses |  | Fair Value |
| Fixed income securities: |  |  |  |  |  |  |  |
| U.S. government securities | $ | 31,675 |  |  | $ | 34 |  |  | $ | (6 | ) |  | $ | 31,703 |  |
| U.S. government agency securities | 1,060 |  |  | 2 |  |  | (1 | ) |  | 1,061 |  |
| Non-U.S. government and agency securities | 819 |  |  | 2 |  |  | (1 | ) |  | 820 |  |
| Corporate debt securities | 8,050 |  |  | 75 |  |  | (10 | ) |  | 8,115 |  |
| U.S. agency mortgage-backed securities | 567 |  |  | 3 |  |  | — |  |  | 570 |  |
| Total fixed income securities | 42,171 |  |  | 116 |  |  | (18 | ) |  | 42,269 |  |
| Publicly traded equity securities | 1,314 |  |  | 652 |  |  | (7 | ) |  | 1,959 |  |
| Total | $ | 43,485 |  |  | $ | 768 |  |  | $ | (25 | ) |  | $ | 44,228 |  |

[0000858877-14-000014:notes:249]
| July 27, 2013 | Amortized Cost |  | Gross Unrealized Gains |  | Gross Unrealized Losses |  | Fair Value |
| Fixed income securities: |  |  |  |  |  |  |  |
| U.S. government securities | $ | 27,814 |  |  | $ | 22 |  |  | $ | (13 | ) |  | $ | 27,823 |  |
| U.S. government agency securities | 3,083 |  |  | 7 |  |  | (1 | ) |  | 3,089 |  |
| Non-U.S. government and agency securities | 1,094 |  |  | 3 |  |  | (2 | ) |  | 1,095 |  |
| Corporate debt securities | 7,876 |  |  | 55 |  |  | (50 | ) |  | 7,881 |  |
| Total fixed income securities | 39,867 |  |  | 87 |  |  | (66 | ) |  | 39,888 |  |
| Publicly traded equity securities | 2,063 |  |  | 738 |  |  | (4 | ) |  | 2,797 |  |
| Total | $ | 41,930 |  |  | $ | 825 |  |  | $ | (70 | ) |  | $ | 42,685 |  |

[0000858877-14-000014:notes:250]
Non-U.S. government and agency securities include agency and corporate debt securities that are guaranteed by non-U.S. governments.

[0000858877-14-000014:notes:251]
| (b) | Gains and Losses on Available-for-Sale Investments |

[0000858877-14-000014:notes:252]
The following table presents the gross realized gains and gross realized losses related to the Company’s available-for-sale investments (in millions):

[0000858877-14-000014:notes:253]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 26, 2014 |  | April 27, 2013 |  | April 26, 2014 |  | April 27, 2013 |
| Gross realized gains | $ | 75 |  |  | $ | 55 |  |  | $ | 267 |  |  | $ | 175 |  |
| Gross realized losses | (6 | ) |  | (49 | ) |  | (33 | ) |  | (129 | ) |
| Total | $ | 69 |  |  | $ | 6 |  |  | $ | 234 |  |  | $ | 46 |  |

[0000858877-14-000014:notes:254]
The following table presents the realized net gains related to the Company’s available-for-sale investments by security type (in millions):

[0000858877-14-000014:notes:255]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 26, 2014 |  | April 27, 2013 |  | April 26, 2014 |  | April 27, 2013 |
| Net gains (losses) on investments in publicly traded equity securities | $ | 55 |  |  | $ | (2 | ) |  | $ | 199 |  |  | $ | 12 |  |
| Net gains on investments in fixed income securities | 14 |  |  | 8 |  |  | 35 |  |  | 34 |  |
| Total | $ | 69 |  |  | $ | 6 |  |  | $ | 234 |  |  | $ | 46 |  |

[0000858877-14-000014:notes:256]
There were no impairment charges for the three months ended April 26, 2014.  For the nine months ended April 26, 2014, the realized net gains related to the Company's available-for-sale investments included impairment charges of $11 million.  These impairment charges related to publicly traded equity securities and were due to a decline in the fair value of those securities below their cost basis that were determined to be other than temporary. There were no impairment charges on available-for-sale investments for the corresponding periods in fiscal 2013.

[0000858877-14-000014:notes:257]
The following tables present the breakdown of the available-for-sale investments with gross unrealized losses and the duration that those losses had been unrealized at April 26, 2014 and July 27, 2013 (in millions):

[0000858877-14-000014:notes:258]
|  | UNREALIZED LOSSES LESS THAN 12 MONTHS |  | UNREALIZED LOSSES 12 MONTHS OR GREATER |  | TOTAL |
| April 26, 2014 | Fair Value |  | Gross Unrealized Losses |  | Fair Value |  | Gross Unrealized Losses |  | Fair Value |  | Gross Unrealized Losses |
| Fixed income securities: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | $ | 5,111 |  |  | $ | (6 | ) |  | $ | 8 |  |  | $ | — |  |  | $ | 5,119 |  |  | $ | (6 | ) |
| U.S. government agency securities | 396 |  |  | (1 | ) |  | 3 |  |  | — |  |  | 399 |  |  | (1 | ) |
| Non-U.S. government and agency securities | 378 |  |  | (1 | ) |  | — |  |  | — |  |  | 378 |  |  | (1 | ) |
| Corporate debt securities | 1,654 |  |  | (10 | ) |  | 52 |  |  | — |  |  | 1,706 |  |  | (10 | ) |
| U.S. agency mortgage-backed securities | 158 |  |  | — |  |  | — |  |  | — |  |  | 158 |  |  | — |  |
| Total fixed income securities | 7,697 |  |  | (18 | ) |  | 63 |  |  | — |  |  | 7,760 |  |  | (18 | ) |
| Publicly traded equity securities | 117 |  |  | (7 | ) |  | — |  |  | — |  |  | 117 |  |  | (7 | ) |
| Total | $ | 7,814 |  |  | $ | (25 | ) |  | $ | 63 |  |  | $ | — |  |  | $ | 7,877 |  |  | $ | (25 | ) |

[0000858877-14-000014:notes:259]
|  | UNREALIZED LOSSES LESS THAN 12 MONTHS |  | UNREALIZED LOSSES 12 MONTHS OR GREATER |  | TOTAL |
| July 27, 2013 | Fair Value |  | Gross Unrealized Losses |  | Fair Value |  | Gross Unrealized Losses |  | Fair Value |  | Gross Unrealized Losses |
| Fixed income securities: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | $ | 7,865 |  |  | $ | (13 | ) |  | $ | — |  |  | $ | — |  |  | $ | 7,865 |  |  | $ | (13 | ) |
| U.S. government agency securities | 294 |  |  | (1 | ) |  | — |  |  | — |  |  | 294 |  |  | (1 | ) |
| Non-U.S. government and agency securities | 432 |  |  | (2 | ) |  | — |  |  | — |  |  | 432 |  |  | (2 | ) |
| Corporate debt securities | 3,704 |  |  | (50 | ) |  | 4 |  |  | — |  |  | 3,708 |  |  | (50 | ) |
| Total fixed income securities | 12,295 |  |  | (66 | ) |  | 4 |  |  | — |  |  | 12,299 |  |  | (66 | ) |
| Publicly traded equity securities | 278 |  |  | (4 | ) |  | — |  |  | — |  |  | 278 |  |  | (4 | ) |
| Total | $ | 12,573 |  |  | $ | (70 | ) |  | $ | 4 |  |  | $ | — |  |  | $ | 12,577 |  |  | $ | (70 | ) |

[0000858877-14-000014:notes:260]
As of April 26, 2014, for fixed income securities that were in unrealized loss positions, the Company has determined that (i) it does not have the intent to sell any of these investments, and (ii) it is not more likely than not that it will be required to sell any of these investments before recovery of the entire amortized cost basis. In addition, as of April 26, 2014, the Company anticipates that it will recover the entire amortized cost basis of such fixed income securities and has determined that no other-than-temporary impairments associated with credit losses were required to be recognized during the nine months ended April 26, 2014.

[0000858877-14-000014:notes:261]
The Company has evaluated its publicly traded equity securities as of April 26, 2014 and has determined that there was no indication of other-than-temporary impairments in the respective categories of unrealized losses. This determination was based on several factors, which include the length of time and extent to which fair value has been less than the cost basis, the financial condition and near-term prospects of the issuer, and the Company’s intent and ability to hold the publicly traded equity securities for a period of time sufficient to allow for any anticipated recovery in market value.

[0000858877-14-000014:notes:262]
| (c) | Maturities of Fixed Income Securities |

[0000858877-14-000014:notes:263]
Actual maturities may differ from the contractual maturities because borrowers may have the right to call or prepay certain obligations.

[0000858877-14-000014:notes:264]
| (d) | Securities Lending |

[0000858877-14-000014:notes:265]
The Company periodically engages in securities lending activities with certain of its available-for-sale investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. The average daily balance of securities lending for the nine months ended April 26, 2014 and April 27, 2013 was $1.4 billion and $0.7 billion, respectively. The Company requires collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. The Company engages in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify the Company against collateral losses. The Company did not experience any losses in connection with the secured lending of securities during the periods presented. As of April 26, 2014 and July 27, 2013, the Company had no outstanding securities lending transactions.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000858877-14-000014:notes:266]
[same as prior period, unchanged from 0000858877-14-000009:notes:256]

[0000858877-14-000014:notes:267]
[same as prior period, unchanged from 0000858877-14-000009:notes:257]

[0000858877-14-000014:notes:268]
The accompanying financial data as of April 26, 2014 and for the three and nine months ended April 26, 2014 and April 27, 2013 has been prepared by the Company, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (SEC). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (GAAP) have been condensed or omitted pursuant to such rules and regulations. The July 27, 2013 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, the Company believes that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended July 27, 2013.

[0000858877-14-000014:notes:269]
[same as prior period, unchanged from 0000858877-14-000009:notes:259]

[0000858877-14-000014:notes:270]
In the opinion of management, all adjustments (which include normal recurring adjustments, except as disclosed herein) necessary to present fairly the statement of financial position as of April 26, 2014; the results of operations and statements of comprehensive income for the three and nine months ended April 26, 2014 and April 27, 2013; and the statements of cash flows and equity for the nine months ended April 26, 2014 and April 27, 2013, as applicable, have been made. The results of operations for the three and nine months ended April 26, 2014 are not necessarily indicative of the operating results for the full fiscal year or any future periods.

[0000858877-14-000014:notes:271]
Certain reclassifications have been made to prior-period amounts in order to conform to the current period’s presentation. The Company has evaluated subsequent events through the date that the financial statements were issued.


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0000858877-14-000014:notes:272]
| Property and equipment, net: |  |  |  |  |
| Land, buildings, and building and leasehold improvements |  | $ | 4,496 |  |  | $ | 4,426 |  |
| Computer equipment and related software |  | 1,442 |  |  | 1,416 |  |
| Production, engineering, and other equipment |  | 5,750 |  |  | 5,721 |  |
| Operating lease assets (1) |  | 360 |  |  | 326 |  |
| Furniture and fixtures |  | 508 |  |  | 497 |  |
|  |  | 12,556 |  |  | 12,386 |  |
| Less accumulated depreciation and amortization (1) |  | (9,246 | ) |  | (9,064 | ) |
| Total |  | $ | 3,310 |  |  | $ | 3,322 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000858877-14-000014:notes:273]
[same as prior period, unchanged from 0000858877-14-000009:notes:263]

[0000858877-14-000014:notes:274]
[same as prior period, unchanged from 0000858877-14-000009:notes:264]

[0000858877-14-000014:notes:275]
In August 2013, the Company announced a workforce reduction plan that will impact up to 4,000 employees, or 5%, of the Company’s global workforce. This workforce reduction plan is designed to enable the Company to rebalance its workforce in order to reinvest in key growth areas such as the cloud, data center, mobility, services, software, and security and to drive operational efficiencies.  As the Company intends to reinvest in the above areas, it does not expect significant overall cost savings as a result of this rebalancing of its resources.

[0000858877-14-000014:notes:276]
In connection with this restructuring action, the Company incurred charges of $26 million and $336 million for the three and nine months ended April 26, 2014.  The Company expects total pre-tax charges pursuant to these restructuring actions not to exceed $500 million, and that substantially all of the remaining charges will be incurred in the fourth quarter of fiscal 2014.

[0000858877-14-000014:notes:277]
[same as prior period, unchanged from 0000858877-14-000009:notes:267]

[0000858877-14-000014:notes:278]
| August Fiscal 2014 Plan |  | EmployeeSeverance |  | Other |  | Total |
| Gross charges in fiscal 2014 |  | $ | 331 |  |  | $ | 5 |  |  | $ | 336 |  |
| Cash payments |  | (306 | ) |  | — |  |  | (306 | ) |
| Non-cash items |  | — |  |  | (5 | ) |  | (5 | ) |
| Liability as of April 26, 2014 |  | $ | 25 |  |  | $ | — |  |  | $ | 25 |  |

[0000858877-14-000014:notes:279]
[same as prior period, unchanged from 0000858877-14-000009:notes:269]

[0000858877-14-000014:notes:280]
The Fiscal 2011 Plans consist primarily of the realignment and restructuring of the Company’s business announced in July 2011 and of certain consumer product lines as announced during April 2011.  The Company completed the Fiscal 2011 Plans at the end of fiscal 2013 and does not expect any remaining charges related to these actions. The Company incurred cumulative charges of approximately $1.1 billion in connection with these plans. For the three and nine months ended April 27, 2013, such charges were $33 million and $105 million.  The remaining liability balance as of April 26, 2014 was $4 million inclusive of severance and non-severance activities.


## us-gaap:ScheduleOfOtherAssetsAndOtherLiabilitiesTableTextBlock

[0000858877-14-000014:notes:281]
[same as prior period, unchanged from 0000858877-14-000009:notes:271]

[0000858877-14-000014:notes:282]
(1)      Accumulated depreciation related to operating lease assets was $198 and $203 as of April 26, 2014 and July 27, 2013, respectively.

[0000858877-14-000014:notes:283]
| Other assets: |  |  |  |  |
| Deferred tax assets |  | $ | 1,540 |  |  | $ | 1,539 |  |
| Investments in privately held companies |  | 923 |  |  | 833 |  |
| Other |  | 721 |  |  | 743 |  |
| Total |  | $ | 3,184 |  |  | $ | 3,115 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0000858877-14-000014:notes:284]
Summarized financial information by segment for the three and nine months ended April 26, 2014 and April 27, 2013, based on the Company’s internal management system and as utilized by the Company’s Chief Operating Decision Maker (“CODM”), is as follows (in millions):

[0000858877-14-000014:notes:285]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 26, 2014 |  | April 27, 2013 |  | April 26, 2014 |  | April 27, 2013 |
| Revenue: |  |  |  |  |  |  |  |
| Americas | $ | 6,689 |  |  | $ | 7,127 |  |  | $ | 20,465 |  |  | $ | 21,286 |  |
| EMEA | 3,068 |  |  | 3,131 |  |  | 8,897 |  |  | 9,065 |  |
| APJC | 1,788 |  |  | 1,958 |  |  | 5,423 |  |  | 5,839 |  |
| Total | $ | 11,545 |  |  | $ | 12,216 |  |  | $ | 34,785 |  |  | $ | 36,190 |  |
| Gross margin: |  |  |  |  |  |  |  |
| Americas | 4,196 |  |  | 4,460 |  |  | 12,823 |  |  | 13,341 |  |
| EMEA | 1,967 |  |  | 2,044 |  |  | 5,725 |  |  | 5,850 |  |
| APJC | 1,076 |  |  | 1,197 |  |  | 3,148 |  |  | 3,494 |  |
| Segment total | 7,239 |  |  | 7,701 |  |  | 21,696 |  |  | 22,685 |  |
| Unallocated corporate items | (233 | ) |  | (190 | ) |  | (1,332 | ) |  | (592 | ) |
| Total | $ | 7,006 |  |  | $ | 7,511 |  |  | $ | 20,364 |  |  | $ | 22,093 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0000858877-14-000014:notes:286]
[same as prior period, unchanged from 0000858877-14-000009:notes:276]

[0000858877-14-000014:notes:287]
[same as prior period, unchanged from 0000858877-14-000009:notes:277]

[0000858877-14-000014:notes:288]
The Company conducts business globally and is primarily managed on a geographic basis consisting of three segments: the Americas, EMEA, and APJC. The Company’s management makes financial decisions and allocates resources based on the information it receives from its internal management system. Sales are attributed to a segment based on the ordering location of the customer. The Company does not allocate research and development, sales and marketing, or general and administrative expenses to its segments in this internal management system because management does not include the information in its measurement of the performance of the operating segments. In addition, the Company does not allocate amortization and impairment of acquisition-related intangible assets, share-based compensation expense, significant litigation and other contingencies, impacts to cost of sales from purchase accounting adjustments to inventory, charges related to asset impairments and restructurings, and certain other charges to the gross margin for each segment because management does not include this information in its measurement of the performance of the operating segments.

[0000858877-14-000014:notes:289]
Revenue in the United States, which is included in the Americas, was $5.9 billion and $6.1 billion for the three months ended April 26, 2014 and April 27, 2013, respectively, and was $17.9 billion and $18.3 billion for the nine months ended April 26, 2014 and April 27, 2013.

[0000858877-14-000014:notes:290]
[same as prior period, unchanged from 0000858877-14-000009:notes:280]

[0000858877-14-000014:notes:291]
[same as prior period, unchanged from 0000858877-14-000009:notes:281]

[0000858877-14-000014:notes:292]
[same as prior period, unchanged from 0000858877-14-000009:notes:282]

[0000858877-14-000014:notes:293]
|  | Three Months Ended |  | Nine Months Ended |
|  | April 26, 2014 |  | April 27, 2013 |  | April 26, 2014 |  | April 27, 2013 |
| Revenue: |  |  |  |  |  |  |  |
| Switching | $ | 3,381 |  |  | $ | 3,601 |  |  | $ | 10,406 |  |  | $ | 10,962 |  |
| NGN Routing | 1,935 |  |  | 2,145 |  |  | 5,719 |  |  | 6,147 |  |
| Service Provider Video | 961 |  |  | 1,299 |  |  | 2,905 |  |  | 3,670 |  |
| Collaboration | 892 |  |  | 1,013 |  |  | 2,800 |  |  | 2,978 |  |
| Data Center | 662 |  |  | 515 |  |  | 1,868 |  |  | 1,480 |  |
| Wireless | 553 |  |  | 539 |  |  | 1,604 |  |  | 1,573 |  |
| Security | 361 |  |  | 327 |  |  | 1,119 |  |  | 1,002 |  |
| Other | 75 |  |  | 120 |  |  | 219 |  |  | 481 |  |
| Product | 8,820 |  |  | 9,559 |  |  | 26,640 |  |  | 28,293 |  |
| Service | 2,725 |  |  | 2,657 |  |  | 8,145 |  |  | 7,897 |  |
| Total | $ | 11,545 |  |  | $ | 12,216 |  |  | $ | 34,785 |  |  | $ | 36,190 |  |

[0000858877-14-000014:notes:294]
[same as prior period, unchanged from 0000858877-14-000009:notes:284]

[0000858877-14-000014:notes:295]
[same as prior period, unchanged from 0000858877-14-000009:notes:285]

[0000858877-14-000014:notes:296]
The majority of the Company’s assets, excluding cash and cash equivalents and investments, as of April 26, 2014 and July 27, 2013 were attributable to its U.S. operations. The Company’s total cash and cash equivalents and investments held by various foreign subsidiaries were $45.9 billion and $40.4 billion as of April 26, 2014 and July 27, 2013, respectively, and the remaining $4.6 billion and $10.2 billion at the respective period ends was available in the United States.

[0000858877-14-000014:notes:297]
[same as prior period, unchanged from 0000858877-14-000009:notes:287]

[0000858877-14-000014:notes:298]
|  | April 26, 2014 |  | July 27, 2013 |
| Property and equipment, net: |  |  |  |
| United States | $ | 2,718 |  |  | $ | 2,780 |  |
| International | 592 |  |  | 542 |  |
| Total | $ | 3,310 |  |  | $ | 3,322 |  |


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000858877-14-000014:notes:299]
[same as prior period, unchanged from 0000858877-14-000009:notes:289]

[0000858877-14-000014:notes:300]
[same as prior period, unchanged from 0000858877-14-000009:notes:290]

[0000858877-14-000014:notes:301]
[same as prior period, unchanged from 0000858877-14-000009:notes:291]

[0000858877-14-000014:notes:302]
[same as prior period, unchanged from 0000858877-14-000009:notes:292]

[0000858877-14-000014:notes:303]
[same as prior period, unchanged from 0000858877-14-000009:notes:293]

[0000858877-14-000014:notes:304]
In April 2014, the FASB issued an accounting standard update that changes the criteria for reporting discontinued operations.  Under the accounting standard update, a disposal of a component of an entity or a group of components of an entity is required to be reported in discontinued operations if the disposal represents a strategic shift that has, or will have, a major effect on an entity's operations and financial results when either it qualifies as held for sale, disposed of by sale, or disposed of other than by sale.  This accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2016.  The Company is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000858877-14-000014:notes:305]
[same as prior period, unchanged from 0000858877-14-000009:notes:294]

[0000858877-14-000014:notes:306]
[same as prior period, unchanged from 0000858877-14-000009:notes:295]

[0000858877-14-000014:notes:307]
During the nine months ended April 26, 2014, the Company declared and paid cash dividends of $0.53 per common share, or $2.8 billion, on the Company’s outstanding common stock.  During the nine months ended April 27, 2013, the Company declared and paid cash dividends of $0.45 per common share, or $2.4 billion, on the Company’s outstanding common stock.

[0000858877-14-000014:notes:308]
Any future dividends will be subject to the approval of the Company’s Board of Directors.

[0000858877-14-000014:notes:309]
[same as prior period, unchanged from 0000858877-14-000009:notes:298]

[0000858877-14-000014:notes:310]
In September 2001, the Company’s Board of Directors authorized a stock repurchase program. As of April 26, 2014, the Company’s Board of Directors had authorized an aggregate repurchase of up to $97 billion of common stock under this program, and the remaining authorized repurchase amount was $10.1 billion, with no termination date.  A summary of the stock repurchase activity under the stock repurchase program, reported based on the trade date, is summarized as follows (in millions, except per-share amounts):

[0000858877-14-000014:notes:311]
|  | Shares Repurchased |  | Weighted- Average Price per Share |  | Amount Repurchased |
| Cumulative balance at July 27, 2013 | 3,868 |  |  | $ | 20.40 |  |  | $ | 78,906 |  |
| Repurchase of common stock under the stock repurchase program (1) | 359 |  |  | 22.31 |  |  | 8,025 |  |
| Cumulative balance at April 26, 2014 | 4,227 |  |  | $ | 20.56 |  |  | $ | 86,931 |  |

[0000858877-14-000014:notes:312]
(1) Includes stock repurchases of $60 million, which were pending settlement as of April 26, 2014. There were no stock repurchases pending settlement as of July 27, 2013.

[0000858877-14-000014:notes:313]
[same as prior period, unchanged from 0000858877-14-000009:notes:302]

[0000858877-14-000014:notes:314]
| (c) | Restricted Stock Unit Withholdings |

[0000858877-14-000014:notes:315]
For the nine months ended April 26, 2014 and April 27, 2013, the Company repurchased approximately 14 million and 13 million shares, or $345 million and $249 million, of common stock, respectively, in settlement of employee tax withholding obligations due upon the vesting of restricted stock or stock units.


## us-gaap:TreasuryStockTextBlock

[0000858877-14-000014:notes:316]
In September 2001, the Company’s Board of Directors authorized a stock repurchase program. As of April 26, 2014, the Company’s Board of Directors had authorized an aggregate repurchase of up to $97 billion of common stock under this program, with no termination date.  The stock repurchases since the inception of this program and the related impacts on Cisco shareholders’ equity are summarized in the following table (in millions):

[0000858877-14-000014:notes:317]
|  | Shares of Common Stock |  | Common Stock and Additional Paid-In Capital |  | Retained Earnings |  | Total Cisco Shareholders’ Equity |
| Repurchases of common stock under the repurchase program | 4,227 |  |  | $ | 20,839 |  |  | $ | 66,092 |  |  | $ | 86,931 |  |
