# CSCO MD&A — 0000858877-26-000132


## mdna

[0000858877-26-000132:mdna:1]
| Item 7. | Management’s Discussion and Analysis of Financial Condition and Results of Operations |

[0000858877-26-000132:mdna:2]
Forward-Looking Statements

[0000858877-26-000132:mdna:3]
OVERVIEW

[0000858877-26-000132:mdna:4]
Cisco designs and sells a broad range of technologies including hardware, software, and artificial intelligence (AI) powered digital infrastructure to power, help secure, and draw insights from the Internet. We are incorporating AI into our product portfolios across networking, security, collaboration and observability, as well as integrating our products more tightly together into a platform. We are simplifying how our technology is delivered, managed and optimized and helping customers maximize the business value of their technology investments.

[0000858877-26-000132:mdna:5]
A summary of our results is as follows (in millions, except percentages and per-share amounts):

[0000858877-26-000132:mdna:6]
|  | Three Months Ended |  | Years Ended |  |
|  | July 25, 2026 |  | July 26, 2025 |  | Variance |  | July 25, 2026 |  | July 26, 2025 |  | Variance |  |
| Revenue | $ | 17,252 |  |  | $ | 14,673 |  |  | 18 | % |  | $ | 63,325 |  |  | $ | 56,654 |  |  | 12 | % |  |
| Gross margin percentage | 64.1 | % |  | 63.2 | % |  | 0.9 |  | pts | 64.5 | % |  | 64.9 | % |  | (0.4) |  | pts |
| Research and development | $ | 2,431 |  |  | $ | 2,380 |  |  | 2 | % |  | $ | 9,563 |  |  | $ | 9,300 |  |  | 3 | % |  |
| Sales and marketing | $ | 2,952 |  |  | $ | 2,818 |  |  | 5 | % |  | $ | 11,559 |  |  | $ | 10,966 |  |  | 5 | % |  |
| General and administrative | $ | 679 |  |  | $ | 706 |  |  | (4) | % |  | $ | 2,761 |  |  | $ | 2,992 |  |  | (8) | % |  |
| Total R&D, sales and marketing, general and administrative | $ | 6,062 |  |  | $ | 5,904 |  |  | 3 | % |  | $ | 23,883 |  |  | $ | 23,258 |  |  | 3 | % |  |
| Total as a percentage of revenue | 35.1 | % |  | 40.2 | % |  | (5.1) |  | pts | 37.7 | % |  | 41.1 | % |  | (3.4) |  | pts |
| Restructuring and other charges included in operating expenses | $ | 511 |  |  | $ | 35 |  |  | NM |  | $ | 693 |  |  | $ | 744 |  |  | (7) | % |  |
| Operating income as a percentage of revenue | 24.7 | % |  | 21.0 | % |  | 3.7 |  | pts | 24.3 | % |  | 20.8 | % |  | 3.5 |  | pts |
| Income tax percentage | 21.8 | % |  | 15.0 | % |  | 6.8 |  | pts | 17.1 | % |  | 8.3 | % |  | 8.8 |  | pts |
| Net income | $ | 3,859 |  |  | $ | 2,550 |  |  | 51 | % |  | $ | 13,267 |  |  | $ | 10,180 |  |  | 30 | % |  |
| Net income as a percentage of revenue | 22.4 | % |  | 17.4 | % |  | 5.0 |  | pts | 21.0 | % |  | 18.0 | % |  | 3.0 |  | pts |
| Earnings per share—diluted | $ | 0.97 |  |  | $ | 0.64 |  |  | 52 | % |  | $ | 3.33 |  |  | $ | 2.55 |  |  | 31 | % |  |

[0000858877-26-000132:mdna:7]
Percentages may not recalculate due to rounding.

[0000858877-26-000132:mdna:8]
NM — Not meaningful

[0000858877-26-000132:mdna:9]
30

[0000858877-26-000132:mdna:10]
CISCO SYSTEMS, INC.

[0000858877-26-000132:mdna:11]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-26-000132:mdna:12]
Fiscal 2026 Compared with Fiscal 2025

[0000858877-26-000132:mdna:13]
In fiscal 2026, we delivered strong revenue growth and profitability in a continued positive demand environment. Total revenue was $63.3 billion, an increase of 12% compared with fiscal 2025. Within total revenue, product revenue increased by 16% and services revenue was flat. Total software revenue was $23.2 billion across all product areas and services, an increase of 4%, and total subscription revenue increased 1%.

[0000858877-26-000132:mdna:14]
We saw demand in fiscal 2026 for AI infrastructure from our hyperscaler customers, which represented approximately 6% of total revenue in fiscal 2026 compared with less than 2% in fiscal 2025. We expect this demand to remain a significant driver of our results in fiscal 2027, and we discuss the associated customer concentration and supply considerations in Part I, Item 1A. Risk Factors.

[0000858877-26-000132:mdna:15]
Total gross margin decreased by 0.4 percentage points, primarily driven by a decline in product gross margin, partially offset by an increase in services gross margin. Product gross margin decreased by 0.5 percentage points, primarily driven by negative impacts from product mix and higher memory costs, partially offset by productivity improvements, pricing actions, lower amortization of purchased intangible assets and a charge in fiscal 2025 as a result of a legal dispute with a supplier, which did not recur in fiscal 2026. As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses, collectively, decreased by 3.4 percentage points. Operating income as a percentage of revenue increased by 3.5 percentage points primarily driven by revenue growth, partially offset by lower gross margin and higher operating expenses in fiscal 2026. Diluted earnings per share increased 31%, driven by revenue growth and operating margin improvement.

[0000858877-26-000132:mdna:16]
In terms of our geographic segments, revenue from the Americas increased by $4.1 billion, EMEA revenue increased by $1.8 billion and APJC revenue increased by $0.7 billion. From a customer market standpoint, we experienced product revenue growth across all of our customer markets.

[0000858877-26-000132:mdna:17]
From a product category perspective, the product revenue increase of 16% was driven by growth in Networking of 22%, particularly within our AI Infrastructure and Campus Networking solutions. We also saw product revenue growth in Collaboration of 4%, Observability of 4%, and Security of 2%.

[0000858877-26-000132:mdna:18]
We continue to operate in a highly competitive and complex environment, especially as it relates to memory constraints and costs, and trade policy. Notwithstanding these challenges, we believe that we are making progress on our strategic priorities. We continue to invest in key priority areas with the objective of driving profitable growth over the long term, and we remain focused on delivering innovation across our technologies to assist our customers in executing on their digital transformations.

[0000858877-26-000132:mdna:19]
31

[0000858877-26-000132:mdna:20]
CISCO SYSTEMS, INC.

[0000858877-26-000132:mdna:21]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-26-000132:mdna:22]
Fourth Quarter Snapshot

[0000858877-26-000132:mdna:23]
For the fourth quarter of fiscal 2026, as compared with the fourth quarter of fiscal 2025, total revenue increased by 18% to $17.3 billion. Within total revenue, product revenue increased by 24% to $13.5 billion and services revenue was flat at $3.8 billion. With regard to our geographic segment performance, on a year-over-year basis, revenue from the Americas increased by 18%, EMEA increased by 19% and APJC increased by 14%. From a product category perspective, on a year-over-year basis, product revenue increased in Networking by 28%, Security by 14%, Collaboration by 12% and Observability by 6%. The increase in Networking reflected growth in AI infrastructure and data center switching.

[0000858877-26-000132:mdna:24]
Total gross margin increased by 0.9 percentage points, primarily driven by the absence in the fourth quarter of fiscal 2026 of a charge recorded in the fourth quarter of fiscal 2025 as a result of a legal dispute with a supplier, and by favorable pricing. These impacts were partially offset by negative impacts from product mix and higher memory costs. As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses, collectively, decreased by 5.1 percentage points driven by the revenue growth and disciplined expense management. Operating income as a percentage of revenue increased by 3.7 percentage points, primarily driven by revenue growth and higher gross margin as discussed above, partially offset by higher restructuring and other charges. Diluted earnings per share increased by 52%, primarily driven by a revenue increase and the increase in our operating margin percentage.

[0000858877-26-000132:mdna:25]
Strategy and Priorities

[0000858877-26-000132:mdna:26]
In today’s fast-paced world shaped by AI, businesses and organizations globally are deploying technology to pursue their strategic objectives, from accelerating growth to enhancing operational efficiency and fostering innovation. Our strategy is to securely connect everything to make those desired outcomes possible.

[0000858877-26-000132:mdna:27]
For a full discussion of our strategy and priorities, see “Item 1. Business.”

[0000858877-26-000132:mdna:28]
Other Key Financial Measures

[0000858877-26-000132:mdna:29]
The following is a summary of our other key financial measures for fiscal 2026 compared with fiscal 2025 (in millions):

[0000858877-26-000132:mdna:30]
|  |  | Fiscal 2026 |  | Fiscal 2025 |
| Cash and cash equivalents and investments |  | $15,918 |  | $16,110 |
| Cash provided by operating activities |  | $14,177 |  | $14,193 |
| Remaining performance obligations |  | $46,734 |  | $43,533 |
| Repurchases of common stock—stock repurchase program |  | $6,106 |  | $5,995 |
| Dividends paid |  | $6,553 |  | $6,437 |
| Inventories |  | $5,694 |  | $3,164 |
| Total debt |  | $29,533 |  | $28,093 |

[0000858877-26-000132:mdna:31]
CISCO SYSTEMS, INC.

[0000858877-26-000132:mdna:32]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-26-000132:mdna:33]
CRITICAL ACCOUNTING ESTIMATES

[0000858877-26-000132:mdna:34]
The preparation of financial statements and related disclosures in conformity with accounting principles generally accepted in the United States requires us to make judgments, assumptions, and estimates that affect the amounts reported in the Consolidated Financial Statements and accompanying notes. Note 2 to the Consolidated Financial Statements describes the significant accounting policies and methods used in the preparation of the Consolidated Financial Statements. The accounting policies described below are significantly affected by critical accounting estimates. Such accounting policies require significant judgments, assumptions, and estimates used in the preparation of the Consolidated Financial Statements, and actual results could differ materially from the amounts reported based on these policies.

[0000858877-26-000132:mdna:35]
Revenue Recognition

[0000858877-26-000132:mdna:36]
We enter into contracts with customers that can include various combinations of products and services which are generally distinct and accounted for as separate performance obligations, resulting in contracts that may contain multiple performance obligations. We determine whether arrangements are distinct based on whether the customer can benefit from the product or service on its own or together with other resources that are readily available and whether our commitment to transfer the product or service to the customer is separately identifiable from other obligations in the contract. We classify our hardware, perpetual software licenses, and SaaS as distinct performance obligations. Term software licenses represent multiple obligations, which include software licenses and software maintenance. In transactions where we deliver hardware or software, we are typically the principal and we record revenue and costs of goods sold on a gross basis.

[0000858877-26-000132:mdna:37]
We recognize revenue upon transfer of control of promised goods or services in a contract with a customer in an amount that reflects the consideration we expect to receive in exchange for those products or services. Transfer of control occurs once the customer has the contractual right to use the product, generally upon shipment, electronic delivery (or when the software is available for download by the customer), or once title and risk of loss has transferred to the customer. Transfer of control can also occur over time for software maintenance and services as the customer receives the benefit over the contract term. Our hardware and perpetual software licenses are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses include multiple performance obligations where the term licenses are recognized upfront upon transfer of control, with the associated software maintenance revenue recognized ratably over the contract term as services and software updates are provided. SaaS arrangements do not include the right for the customer to take possession of the software during the term, and therefore have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term as the customer consumes the services. On our product sales, we record consideration from shipping and handling on a gross basis within net product sales. We record our revenue net of any associated sales taxes.

[0000858877-26-000132:mdna:38]
Revenue is allocated among these performance obligations in a manner that reflects the consideration that we expect to be entitled to for the promised goods or services based on standalone selling prices (SSP). SSP is estimated for each distinct performance obligation and judgment may be required in their determination. The best evidence of SSP is the observable price of a product or service when we sell the goods separately in similar circumstances and to similar customers. In instances where SSP is not directly observable, we determine SSP using information that may include market conditions and other observable inputs.

[0000858877-26-000132:mdna:39]
We assess relevant contractual terms in our customer contracts to determine the transaction price. We apply judgment in identifying contractual terms and determining the transaction price as we may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration includes potential contractual penalties and various rebate, cooperative marketing and other incentive programs that we offer to our distributors, channel partners and direct sale customers. When determining the amount of revenue to recognize, we estimate the expected usage of these programs, applying the expected value or most likely estimate and update the estimate at each reporting period as actual utilization becomes available. We also consider the customers’ right of return in determining the transaction price, where applicable. If actual credits received by customers under these programs were to deviate significantly from our estimates, which are based on historical experience, our revenue could be adversely affected.

[0000858877-26-000132:mdna:40]
See Note 3 to the Consolidated Financial Statements for more details.

[0000858877-26-000132:mdna:41]
Inventory Valuation and Liability for Purchase Commitments with Contract Manufacturers and Suppliers

[0000858877-26-000132:mdna:42]
Inventory is written down based on excess and obsolete inventories, determined primarily by future demand forecasts. Inventory write-downs are measured as the difference between the cost of the inventory and net realizable value, based upon assumptions about future demand, and are charged to the provision for inventory. At the point of the loss recognition, a new, lower cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis.

[0000858877-26-000132:mdna:43]
CISCO SYSTEMS, INC.

[0000858877-26-000132:mdna:44]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-26-000132:mdna:45]
We record a provision for firm, noncancelable, and unconditional purchase commitments with contract manufacturers and suppliers for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. Both provisions are a component of cost of sales.

[0000858877-26-000132:mdna:46]
Our total provisions for inventory and the liability related to purchase commitments with contract manufacturers and suppliers were $387 million, $493 million, and $819 million in fiscal 2026, 2025, and 2024, respectively. Inventories were $5.7 billion as of July 25, 2026 compared with $3.2 billion as of July 26, 2025, reflecting increased demand for our Cisco Silicon One and the impact of higher memory prices. If there were to be a sudden and significant decrease in demand for our products, or a higher incidence of inventory obsolescence because of rapidly changing technology or customer requirements, then we could be required to increase our inventory write-downs and our liability for purchase commitments with contract manufacturers and suppliers, and accordingly our profitability could be adversely affected. We regularly evaluate our exposure for inventory write-downs, and the adequacy of our liability for purchase commitments. For further discussion around the supply chain impacts and risks, see “—Results of Operations—Gross Margin—Supply Chain Impacts and Risks” and “—Liquidity and Capital Resources—Inventory Supply Chain” under Item 7 of this report.

[0000858877-26-000132:mdna:47]
Loss Contingencies

[0000858877-26-000132:mdna:48]
We are subject to the possibility of various losses arising in the ordinary course of business. We consider the likelihood of the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that a liability has been incurred and the amount of loss can be reasonably estimated. We regularly evaluate information available to us to determine whether such accruals should be made or adjusted and whether new accruals are required. See Note 13 to the Consolidated Financial Statements for further discussion.

[0000858877-26-000132:mdna:49]
Valuation of Goodwill and Purchased Intangible Assets

[0000858877-26-000132:mdna:50]
Goodwill

[0000858877-26-000132:mdna:51]
Our methodology for allocating the purchase price relating to purchase acquisitions is determined through established valuation techniques. Goodwill represents a residual value as of the acquisition date, which in most cases results in measuring goodwill as an excess of the purchase consideration transferred plus the fair value of any noncontrolling interest in the acquired company over the fair value of net assets acquired, including contingent consideration. We perform goodwill impairment tests on an annual basis in the fourth fiscal quarter and between annual tests in certain circumstances for each reporting unit. The assessment of fair value for goodwill and purchased intangible assets is based on factors that market participants would use in an orderly transaction in accordance with the guidance for the fair value measurement of nonfinancial assets.

[0000858877-26-000132:mdna:52]
Goodwill as of July 25, 2026 was $59.5 billion. There was no impairment of goodwill in fiscal 2026, 2025 or 2024. For the annual impairment testing in fiscal 2026, the excess of the fair value over the carrying value for each of our reporting units was $64.7 billion for the Americas, $88.6 billion for EMEA, and $33.7 billion for APJC.

[0000858877-26-000132:mdna:53]
During the fourth quarter of fiscal 2026, we performed a sensitivity analysis for goodwill impairment with respect to each of our respective reporting units and determined that a hypothetical 10% decline in the fair value of each reporting unit would not result in an impairment of goodwill for any reporting unit.

[0000858877-26-000132:mdna:54]
Purchased Intangible Assets

[0000858877-26-000132:mdna:55]
The accounting for acquisitions requires significant estimates and judgments in the valuation of purchased intangible assets. Critical estimates used in the valuation of purchased intangible assets include, but are not limited to, the amount and timing of expected future cash flows, useful lives and discount rates. While our estimates of fair value are based on assumptions that are believed to be reasonable, these assumptions are inherently uncertain and unpredictable and may not reflect unanticipated events and circumstances that may occur.

[0000858877-26-000132:mdna:56]
We make judgments about the recoverability of purchased intangible assets with finite lives whenever events or changes in circumstances indicate that an impairment may exist. Recoverability of purchased intangible assets with finite lives is measured by comparing the carrying amount of the asset group to the future undiscounted cash flows the asset group is expected to generate. We review indefinite-lived intangible assets for impairment annually or whenever events or changes in circumstances indicate that the asset might be impaired. If the asset is considered impaired, the amount of any impairment is measured as the difference between the carrying value and the fair value of the impaired asset. Assumptions and estimates about future values and remaining useful lives of our purchased intangible assets are complex and subjective. They can be affected by a variety of factors, including external factors such as industry and economic trends, and internal factors such as changes in our business strategy and our internal forecasts. Our ongoing consideration of all the factors described previously could result in impairment charges in the future, which could adversely affect our net income.

[0000858877-26-000132:mdna:57]
CISCO SYSTEMS, INC.

[0000858877-26-000132:mdna:58]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-26-000132:mdna:59]
Income Taxes

[0000858877-26-000132:mdna:60]
We are subject to income taxes in the United States and numerous foreign jurisdictions. Our effective tax rates differ from the statutory rate, primarily due to the tax impact of state taxes, foreign operations, R&D tax credits, foreign-derived intangible income deductions, global intangible low-taxed income, tax audit settlements, nondeductible compensation, and international realignments. Our effective tax rate was 17.1%, 8.3%, and 15.6% in fiscal 2026, 2025, and 2024, respectively.

[0000858877-26-000132:mdna:61]
Significant judgment is required in evaluating our uncertain tax positions and determining our provision for income taxes. Although we believe our reserves are reasonable, no assurance can be given that the final tax outcome of these matters will not be different from that which is reflected in our historical income tax provisions and accruals. We adjust these reserves due to changing facts and circumstances, such as the closing of a tax audit or the refinement of an estimate. To the extent that the final tax outcome of these matters is different than the amounts recorded, such differences will impact the provision for income taxes in the period in which such determination is made. The provision for income taxes includes the impact of reserve provisions and changes to reserves that are considered appropriate, and the related net interest and penalties.

[0000858877-26-000132:mdna:62]
Significant judgment is also required in determining any valuation allowance recorded against deferred tax assets. In assessing the need for a valuation allowance, we consider all available evidence, including past operating results, estimates of future taxable income, and the feasibility of tax planning strategies. If we change our determination as to the amount of deferred tax assets that can be realized, we will adjust our valuation allowance with a corresponding impact to the provision for income taxes in the period in which such determination is made.

[0000858877-26-000132:mdna:63]
Our provision for income taxes is subject to volatility and could be negatively impacted by earnings being lower than anticipated in countries that have lower tax rates and higher than anticipated in countries that have higher tax rates; changes in the valuation of deferred tax assets and liabilities; changes to foreign-derived intangible income, global intangible low-taxed income, base erosion and anti-abuse tax, research and development capitalization and amortization, and corporate alternative minimum tax laws, regulations, or interpretations thereof; expiration of or lapses in tax incentives; transfer pricing adjustments, including those resulting from acquisitions or changes to our legal structure; tax effects of nondeductible compensation; tax costs related to intercompany realignments; by changes in accounting principles; or by changes in tax laws and regulations, treaties, or interpretations thereof, including changes to the taxation of earnings of our foreign subsidiaries, the deductibility of expenses attributable to foreign income, and the foreign tax credit rules. Significant judgment is used in determining our provision for income taxes and evaluating tax positions. In certain countries, our income has benefited from reduced tax rates associated with employment and capital investment actions and commitments. If we do not meet the requirements for these reduced rates, our provision for income taxes could be adversely affected. In addition, we are subject to the continuous examination of our income tax returns by the IRS and other tax authorities. We regularly assess the likelihood of adverse outcomes resulting from these examinations to determine the adequacy of our provision for income taxes. There can be no assurance that the outcomes from these continuous examinations will not have an adverse impact on our results of operations and financial condition.

[0000858877-26-000132:mdna:64]
As of July 25, 2026, our gross unrecognized tax benefits were $2.5 billion, reflecting a $0.2 billion increase during fiscal 2026. Of this amount, $1.7 billion would impact our effective tax rate if recognized. Our accrual for related interest and penalties was $539 million as of July 25, 2026. As of the same date, we had gross deferred tax assets of $11.2 billion. The valuation allowance against these deferred tax assets was $1.4 billion, representing a $0.5 billion increase during fiscal 2026, primarily due to the expectation that our future California taxable income will be insufficient to fully utilize our accumulated California tax credits and net operating loss carryforwards.

[0000858877-26-000132:mdna:65]
35

[0000858877-26-000132:mdna:66]
CISCO SYSTEMS, INC.

[0000858877-26-000132:mdna:67]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-26-000132:mdna:68]
RESULTS OF OPERATIONS

[0000858877-26-000132:mdna:69]
A discussion regarding our financial condition and results of operations for fiscal 2026 compared to fiscal 2025 is presented below. A discussion regarding our financial condition and results of operations for fiscal 2025 compared to fiscal 2024 can be found under Item 7 in our Annual Report on Form 10-K for the fiscal year ended July 26, 2025, filed with the SEC on September 3, 2025.

[0000858877-26-000132:mdna:70]
Revenue

[0000858877-26-000132:mdna:71]
The following table presents the breakdown of revenue between product and services (in millions, except percentages):

[0000858877-26-000132:mdna:72]
|  |  | Years Ended |  | 2026 vs. 2025 |
|  |  | July 25, 2026 |  | July 26, 2025 |  | July 27, 2024 |  | Variance in Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 48,295 |  |  | $ | 41,608 |  |  | $ | 39,253 |  |  | $ | 6,687 |  |  | 16 | % |
| Percentage of revenue |  | 76.3 | % |  | 73.4 | % |  | 73.0 | % |  |  |  |  |
| Services |  | 15,030 |  |  | 15,046 |  |  | 14,550 |  |  | (16) |  |  | — | % |
| Percentage of revenue |  | 23.7 | % |  | 26.6 | % |  | 27.0 | % |  |  |  |  |
| Total |  | $ | 63,325 |  |  | $ | 56,654 |  |  | $ | 53,803 |  |  | $ | 6,671 |  |  | 12 | % |

[0000858877-26-000132:mdna:73]
Amounts may not sum and percentages may not recalculate due to rounding.

[0000858877-26-000132:mdna:74]
We manage our business primarily on a geographic basis, organized into three geographic segments. Our revenue, which includes product and services for each segment, is summarized in the following table (in millions, except percentages):

[0000858877-26-000132:mdna:75]
|  |  | Years Ended |  | 2026 vs. 2025 |
|  |  | July 25, 2026 |  | July 26, 2025 |  | July 27, 2024 |  | Variance in Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 37,799 |  |  | $ | 33,656 |  |  | $ | 31,971 |  |  | $ | 4,143 |  |  | 12 | % |
| Percentage of revenue |  | 59.7 | % |  | 59.4 | % |  | 59.4 | % |  |  |  |  |
| EMEA |  | 16,613 |  |  | 14,824 |  |  | 14,117 |  |  | 1,789 |  |  | 12 | % |
| Percentage of revenue |  | 26.2 | % |  | 26.2 | % |  | 26.2 | % |  |  |  |  |
| APJC |  | 8,914 |  |  | 8,174 |  |  | 7,716 |  |  | 740 |  |  | 9 | % |
| Percentage of revenue |  | 14.1 | % |  | 14.4 | % |  | 14.3 | % |  |  |  |  |
| Total |  | $ | 63,325 |  |  | $ | 56,654 |  |  | $ | 53,803 |  |  | $ | 6,671 |  |  | 12 | % |

[0000858877-26-000132:mdna:76]
Amounts may not sum and percentages may not recalculate due to rounding.

[0000858877-26-000132:mdna:77]
Total revenue in fiscal 2026 increased by 12% compared with fiscal 2025. Product revenue increased by 16% and services revenue was flat. Our total revenue reflected growth across each of our geographic segments.

[0000858877-26-000132:mdna:78]
In addition to the impact of macroeconomic factors, including the IT spending environment and the level of spending by government entities, revenue by segment in a particular period may be significantly impacted by the timing of revenue recognition for complex transactions with multiple performance obligations. In addition, certain customers tend to make large and sporadic purchases, and the revenue related to these transactions may also be affected by the timing of revenue recognition, which in turn would impact the revenue of the relevant segment.

[0000858877-26-000132:mdna:79]
CISCO SYSTEMS, INC.

[0000858877-26-000132:mdna:80]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-26-000132:mdna:81]
Product Revenue by Segment

[0000858877-26-000132:mdna:82]
The following table presents the breakdown of product revenue by segment (in millions, except percentages):

[0000858877-26-000132:mdna:83]
|  |  | Years Ended |  | 2026 vs. 2025 |
|  |  | July 25, 2026 |  | July 26, 2025 |  | July 27, 2024 |  | Variance in Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 28,900 |  |  | $ | 24,637 |  |  | $ | 23,142 |  |  | $ | 4,263 |  |  | 17 | % |
| Percentage of product revenue |  | 59.9 | % |  | 59.2 | % |  | 59.0 | % |  |  |  |  |
| EMEA |  | 12,806 |  |  | 11,122 |  |  | 10,645 |  |  | 1,684 |  |  | 15 | % |
| Percentage of product revenue |  | 26.5 | % |  | 26.7 | % |  | 27.1 | % |  |  |  |  |
| APJC |  | 6,588 |  |  | 5,849 |  |  | 5,466 |  |  | 739 |  |  | 13 | % |
| Percentage of product revenue |  | 13.6 | % |  | 14.1 | % |  | 13.9 | % |  |  |  |  |
| Total |  | $ | 48,295 |  |  | $ | 41,608 |  |  | $ | 39,253 |  |  | $ | 6,687 |  |  | 16 | % |

[0000858877-26-000132:mdna:84]
Amounts may not sum and percentages may not recalculate due to rounding.

[0000858877-26-000132:mdna:85]
Americas

[0000858877-26-000132:mdna:86]
Product revenue in the Americas segment increased by 17%, with growth across each of our customer markets, led by the Service Provider and Cloud customer market which was largely driven by revenue from our AI Infrastructure solutions. From a country perspective, product revenue increased in the United States, Canada and Mexico by 18%, 8% and 25%, respectively, partially offset by a decline in Brazil of 10%.

[0000858877-26-000132:mdna:87]
EMEA

[0000858877-26-000132:mdna:88]
Product revenue in the EMEA segment increased by 15%, driven by growth across each of our customer markets. From a country perspective, product revenue increased in the United Kingdom, Germany, and France by 31%, 16% and 11%, respectively.

[0000858877-26-000132:mdna:89]
APJC

[0000858877-26-000132:mdna:90]
Product revenue in the APJC segment increased by 13%, with growth across each of our customer markets. From a country perspective, product revenue increased in Australia, Japan, India, and China by 13%, 16%, 2% and 23%, respectively.

[0000858877-26-000132:mdna:91]
CISCO SYSTEMS, INC.

[0000858877-26-000132:mdna:92]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-26-000132:mdna:93]
Product Revenue by Category

[0000858877-26-000132:mdna:94]
In addition to the primary view on a geographic basis, we also prepare financial information related to product categories and customer markets for various purposes.

[0000858877-26-000132:mdna:95]
The following table presents product revenue by category (in millions, except percentages):

[0000858877-26-000132:mdna:96]
|  |  | Years Ended |  | 2026 vs. 2025 |
|  |  | July 25, 2026 |  | July 26, 2025 |  | July 27, 2024 |  | Variance in Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |  |  |
| Networking |  | $ | 34,668 |  |  | $ | 28,304 |  |  | $ | 29,229 |  |  | $ | 6,364 |  |  | 22 | % |
| Security |  | 8,232 |  |  | 8,094 |  |  | 5,075 |  |  | 138 |  |  | 2 | % |
| Collaboration |  | 4,300 |  |  | 4,154 |  |  | 4,113 |  |  | 146 |  |  | 4 | % |
| Observability |  | 1,095 |  |  | 1,055 |  |  | 837 |  |  | 40 |  |  | 4 | % |
| Total |  | $ | 48,295 |  |  | $ | 41,608 |  |  | $ | 39,253 |  |  | $ | 6,687 |  |  | 16 | % |

[0000858877-26-000132:mdna:97]
Amounts may not sum and percentages may not recalculate due to rounding.

[0000858877-26-000132:mdna:98]
Networking

[0000858877-26-000132:mdna:99]
The Networking product category consists of our core networking technologies of switching, routing, wireless, and servers. Revenue from the Networking product category increased by 22%, or $6.4 billion primarily driven by our AI Infrastructure solutions, which include Cisco Silicon One based systems and optics. Growth was broad-based across the portfolio, with double digit revenue increases in Service Provider Routing, Data Center Switching, Wireless and servers, and growth in Campus Switching and Enterprise Routing.

[0000858877-26-000132:mdna:100]
Security

[0000858877-26-000132:mdna:101]
The Security product category consists of our Network Security, Identity and Access Management, SASE, and Identity and Agentic Security solutions. Revenue in our Security product category increased by 2%, or $0.1 billion, primarily driven by growth in our SASE and Network Security offerings.

[0000858877-26-000132:mdna:102]
Collaboration

[0000858877-26-000132:mdna:103]
The Collaboration product category consists of our Webex Suite, Collaboration Devices, Contact Center and CPaaS offerings. Revenue in our Collaboration product category increased 4%, or $0.1 billion, with growth across each of our offerings.

[0000858877-26-000132:mdna:104]
Observability

[0000858877-26-000132:mdna:105]
The Observability product category consists of our observability suite and network assurance offerings. Revenue in our Observability product category increased by 4%, or $40 million, primarily due to growth in our network assurance offerings, partially offset by a decline in our observability suite offerings.

[0000858877-26-000132:mdna:106]
CISCO SYSTEMS, INC.

[0000858877-26-000132:mdna:107]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-26-000132:mdna:108]
Services Revenue by Segment

[0000858877-26-000132:mdna:109]
The following table presents the breakdown of services revenue by segment (in millions, except percentages):

[0000858877-26-000132:mdna:110]
|  | Years Ended |  | 2026 vs. 2025 |
|  | July 25, 2026 |  | July 26, 2025 |  | July 27, 2024 |  | Variance in Dollars |  | Variance in Percent |
| Services revenue: |  |  |  |  |  |  |  |  |  |
| Americas | $ | 8,899 |  |  | $ | 9,019 |  |  | $ | 8,829 |  |  | $ | (120) |  |  | (1) | % |
| Percentage of service revenue | 59.2 | % |  | 59.9 | % |  | 60.7 | % |  |  |  |  |
| EMEA | 3,806 |  |  | 3,702 |  |  | 3,472 |  |  | 104 |  |  | 3 | % |
| Percentage of service revenue | 25.3 | % |  | 24.6 | % |  | 23.9 | % |  |  |  |  |
| APJC | 2,326 |  |  | 2,325 |  |  | 2,249 |  |  | 1 |  |  | — | % |
| Percentage of service revenue | 15.5 | % |  | 15.5 | % |  | 15.5 | % |  |  |  |  |
| Total | $ | 15,030 |  |  | $ | 15,046 |  |  | $ | 14,550 |  |  | $ | (16) |  |  | — | % |

[0000858877-26-000132:mdna:111]
Amounts may not sum and percentages may not recalculate due to rounding.

[0000858877-26-000132:mdna:112]
Services revenue was flat compared to fiscal 2025, reflecting lower revenue from support services offset by higher revenue from professional services. Services revenue increased in the EMEA segment offset by a decline in the Americas segment. Services revenue in the APJC segment was flat compared to fiscal 2025.

[0000858877-26-000132:mdna:113]
Gross Margin

[0000858877-26-000132:mdna:114]
The following table presents the gross margin for products and services (in millions, except percentages):

[0000858877-26-000132:mdna:115]
|  | AMOUNT |  | PERCENTAGE |
| Years Ended | July 25, 2026 |  | July 26, 2025 |  | July 27, 2024 |  | July 25, 2026 |  | July 26, 2025 |  | July 27, 2024 |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 30,514 |  |  | $ | 26,487 |  |  | $ | 24,914 |  |  | 63.2 | % |  | 63.7 | % |  | 63.5 | % |
| Services | 10,346 |  |  | 10,303 |  |  | 9,914 |  |  | 68.8 | % |  | 68.5 | % |  | 68.1 | % |
| Total | $ | 40,860 |  |  | $ | 36,790 |  |  | $ | 34,828 |  |  | 64.5 | % |  | 64.9 | % |  | 64.7 | % |

[0000858877-26-000132:mdna:116]
Product Gross Margin

[0000858877-26-000132:mdna:117]
The following table summarizes the key factors that contributed to the change in product gross margin percentage from fiscal 2025 to fiscal 2026:

[0000858877-26-000132:mdna:118]
|  |  | Product Gross Margin Percentage |
| Fiscal 2025 |  | 63.7 | % |
| Productivity (1) |  | 1.1 | % |
| Product pricing |  | 0.2 | % |
| Mix of products sold |  | (3.6) | % |
| Amortization of purchased intangible assets |  | 0.9 | % |
| Legal dispute with supplier |  | 0.8 | % |
| Other |  | 0.1 | % |
| Fiscal 2026 |  | 63.2 | % |

[0000858877-26-000132:mdna:119]
(1) Productivity includes overall manufacturing-related costs, such as component costs (including memory), warranty expense, provisions for inventory and the liability related to the purchase commitments with contract manufacturers and suppliers, freight, logistics, shipment volume, and other items not categorized elsewhere.

[0000858877-26-000132:mdna:120]
Product gross margin decreased by 0.5 percentage points primarily driven by negative impacts from product mix, partially offset by productivity improvements, lower amortization of purchased intangible assets, a charge in the fourth quarter of fiscal

[0000858877-26-000132:mdna:121]
CISCO SYSTEMS, INC.

[0000858877-26-000132:mdna:122]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-26-000132:mdna:123]
2025 as a result of a legal dispute with a supplier, which did not recur in fiscal 2026, and to a lesser extent, pricing. The negative impacts from product mix were primarily due to higher Networking revenue. Productivity benefits were adversely impacted by higher memory costs.

[0000858877-26-000132:mdna:124]
Supply Chain Impacts and Risks

[0000858877-26-000132:mdna:125]
We regularly enter into purchase commitments with contract manufacturers and suppliers and in recent periods have increased such commitments related to manufacturing Cisco Silicon One and other products to meet demand from hyperscalers and other customers. We expect to continue entering into these additional purchase commitments in future periods, including purchase commitments to secure supply and pricing for memory and certain components. We have also increased inventory deposits and prepayments with certain suppliers in connection with these arrangements. These purchase commitments and prepayments have in turn significantly increased our supply chain exposure.

[0000858877-26-000132:mdna:126]
This exposure includes potential material excess and obsolete or other charges if product demand significantly decreases, if customers cancel or reschedule orders or change product architecture, design specifications, or qualification requirements, if we are unable to generate demand for certain products, or if we are otherwise unable to mitigate this exposure. Because we commit to purchasing components based on our current demand forecasts, hyperscalers or other large customers may change their orders or buying patterns with us with limited advance notice, which could result in amounts that we have prepaid or deposited with contract manufacturers and suppliers for such commitments being not fully recoverable if the related orders are not fulfilled.

[0000858877-26-000132:mdna:127]
Additionally, while we are exposed to new and proposed tariffs and other trade policies, the extent of such exposure is uncertain but could be significant if the exposure remains and we are unable to mitigate it.

[0000858877-26-000132:mdna:128]
Services Gross Margin

[0000858877-26-000132:mdna:129]
Our services gross margin percentage increased by 0.3 percentage points primarily due to cost efficiencies.

[0000858877-26-000132:mdna:130]
Our services gross margin normally experiences some fluctuations due to various factors such as the timing of contract initiations and renewals, our strategic investments in headcount, and the resources we deploy to support the overall services business. Other factors include the mix of service offerings, as the gross margin from our professional services is typically lower than the gross margin from technical support services.

[0000858877-26-000132:mdna:131]
Gross Margin by Segment

[0000858877-26-000132:mdna:132]
The following table presents the total gross margin for each segment (in millions, except percentages):

[0000858877-26-000132:mdna:133]
|  |  | AMOUNT |  | PERCENTAGE |
| Years Ended |  | July 25, 2026 |  | July 26, 2025 |  | July 27, 2024 |  | July 25, 2026 |  | July 26, 2025 |  | July 27, 2024 |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 24,625 |  |  | $ | 22,962 |  |  | $ | 21,372 |  |  | 65.1 | % |  | 68.2 | % |  | 66.8 | % |
| EMEA |  | 11,835 |  |  | 10,545 |  |  | 9,755 |  |  | 71.2 | % |  | 71.1 | % |  | 69.1 | % |
| APJC |  | 5,933 |  |  | 5,431 |  |  | 5,187 |  |  | 66.6 | % |  | 66.4 | % |  | 67.2 | % |
| Segment total |  | 42,392 |  |  | 38,938 |  |  | 36,312 |  |  | 66.9 | % |  | 68.7 | % |  | 67.5 | % |
| Unallocated corporate items (1) |  | (1,532) |  |  | (2,148) |  |  | (1,484) |  |  |  |  |  |  |  |
| Total |  | $ | 40,860 |  |  | $ | 36,790 |  |  | $ | 34,828 |  |  | 64.5 | % |  | 64.9 | % |  | 64.7 | % |

[0000858877-26-000132:mdna:134]
(1) The unallocated corporate items include the effects of amortization and impairments of acquisition-related intangible assets, share-based compensation expense, significant litigation settlements and other contingencies, charges related to asset impairments and restructurings, and certain other charges. We do not allocate these items to the gross margin for each segment because management does not include such information in measuring the performance of the operating segments.

[0000858877-26-000132:mdna:135]
Amounts may not sum and percentages may not recalculate due to rounding.

[0000858877-26-000132:mdna:136]
The Americas segment had a gross margin percentage decrease driven by negative impacts from product mix, partially offset by positive impacts from productivity improvements.

[0000858877-26-000132:mdna:137]
The EMEA segment had a slight gross margin percentage increase primarily due to positive impacts from productivity improvements and pricing, partially offset by negative impacts from product mix.

[0000858877-26-000132:mdna:138]
40

[0000858877-26-000132:mdna:139]
CISCO SYSTEMS, INC.

[0000858877-26-000132:mdna:140]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-26-000132:mdna:141]
The APJC segment had a gross margin percentage increase driven primarily by positive impacts from productivity improvements, favorable services gross margin and to a lesser extent, pricing, partially offset by negative impacts from product mix.

[0000858877-26-000132:mdna:142]
Research and Development (“R&D”), Sales and Marketing, and General and Administrative (“G&A”) Expenses

[0000858877-26-000132:mdna:143]
R&D, sales and marketing, and G&A expenses are summarized in the following table (in millions, except percentages):

[0000858877-26-000132:mdna:144]
|  |  | Years Ended |  | 2026 vs. 2025 |
|  |  | July 25, 2026 |  | July 26, 2025 |  | July 27, 2024 |  | Variance in Dollars |  | Variance in Percent |
| Research and development |  | $ | 9,563 |  |  | $ | 9,300 |  |  | $ | 7,983 |  |  | $ | 263 |  |  | 3 | % |
| Percentage of revenue |  | 15.1 | % |  | 16.4 | % |  | 14.8 | % |  |  |  |  |
| Sales and marketing |  | 11,559 |  |  | 10,966 |  |  | 10,364 |  |  | 593 |  |  | 5 | % |
| Percentage of revenue |  | 18.3 | % |  | 19.4 | % |  | 19.3 | % |  |  |  |  |
| General and administrative |  | 2,761 |  |  | 2,992 |  |  | 2,813 |  |  | (231) |  |  | (8) | % |
| Percentage of revenue |  | 4.4 | % |  | 5.3 | % |  | 5.2 | % |  |  |  |  |
| Total |  | $ | 23,883 |  |  | $ | 23,258 |  |  | $ | 21,160 |  |  | $ | 625 |  |  | 3 | % |
| Percentage of revenue |  | 37.7 | % |  | 41.1 | % |  | 39.3 | % |  |  |  |  |

[0000858877-26-000132:mdna:145]
R&D Expenses

[0000858877-26-000132:mdna:146]
R&D expenses increased primarily due to higher headcount-related expenses reflecting our investments in AI, higher discretionary spending and higher share-based compensation expense, partially offset by lower acquisition-related costs and lower contracted services spending.

[0000858877-26-000132:mdna:147]
Sales and Marketing Expenses

[0000858877-26-000132:mdna:148]
Sales and marketing expenses increased primarily due to higher headcount-related expenses, higher share-based compensation expense and higher contracted services spending, partially offset by lower acquisition-related costs and lower discretionary spending.

[0000858877-26-000132:mdna:149]
G&A Expenses

[0000858877-26-000132:mdna:150]
G&A expenses decreased primarily due to lower acquisition-related costs and lower headcount-related expenses, partially offset by higher discretionary spending.

[0000858877-26-000132:mdna:151]
Effect of Foreign Currency

[0000858877-26-000132:mdna:152]
In fiscal 2026, foreign currency fluctuations, net of hedging, increased the combined R&D, sales and marketing, and G&A expenses by approximately $195 million, or 0.8%, compared with fiscal 2025.

[0000858877-26-000132:mdna:153]
Amortization of Purchased Intangible Assets

[0000858877-26-000132:mdna:154]
The following table presents the amortization of purchased intangible assets including impairment charges (in millions):

[0000858877-26-000132:mdna:155]
| Years Ended |  | July 25, 2026 |  | July 26, 2025 |  | July 27, 2024 |
| Amortization of purchased intangible assets: |  |  |  |  |  |  |
| Cost of sales |  | $ | 947 |  |  | $ | 1,174 |  |  | $ | 955 |  |
| Operating expenses |  | 916 |  |  | 1,028 |  |  | 698 |  |
| Total |  | $ | 1,863 |  |  | $ | 2,202 |  |  | $ | 1,653 |  |

[0000858877-26-000132:mdna:156]
The decrease in amortization of purchased intangible assets was primarily due to certain purchased intangible assets that became fully amortized and impairment charges in fiscal 2025, partially offset by amortization of purchased intangibles from our recent acquisitions.

[0000858877-26-000132:mdna:157]
Restructuring and Other Charges

[0000858877-26-000132:mdna:158]
We recognized total restructuring and other charges, which are included in operating expenses, of $693 million and $744 million in fiscal 2026 and 2025, respectively.

[0000858877-26-000132:mdna:159]
CISCO SYSTEMS, INC.

[0000858877-26-000132:mdna:160]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-26-000132:mdna:161]
In the fourth quarter of fiscal 2026, we announced a restructuring plan to allow us to invest in key growth opportunities including silicon, optics, security and AI. The total pre-tax charges are estimated to be up to $1 billion, with the plan expected to be substantially completed by the end of fiscal 2027. In connection with this restructuring plan, we incurred charges of $511 million during fiscal 2026.

[0000858877-26-000132:mdna:162]
In fiscal 2025, we announced a restructuring plan in order to allow us to invest in key growth opportunities and drive more efficiencies in our business. We incurred cumulative charges of $926 million and substantially completed this plan in fiscal 2026.

[0000858877-26-000132:mdna:163]
In fiscal 2024, we initiated a restructuring plan in order to realign the organization and enable further investment in key priority areas. We incurred cumulative charges of $654 million and the plan is complete.

[0000858877-26-000132:mdna:164]
We expect to reinvest substantially all of the cost savings from these restructuring plans in our key growth opportunities and key priority areas. As a result, the overall cost savings from these restructuring plans are not expected to be material.

[0000858877-26-000132:mdna:165]
Operating Income

[0000858877-26-000132:mdna:166]
The following table presents our operating income and our operating income as a percentage of revenue (in millions, except percentages):

[0000858877-26-000132:mdna:167]
| Years Ended |  | July 25, 2026 |  | July 26, 2025 |  | July 27, 2024 |
| Operating income |  | $ | 15,368 |  |  | $ | 11,760 |  |  | $ | 12,181 |  |
| Operating income as a percentage of revenue |  | 24.3 | % |  | 20.8 | % |  | 22.6 | % |

[0000858877-26-000132:mdna:168]
Operating income increased by 31%, and as a percentage of revenue operating income increased by 3.5 percentage points. These changes primarily resulted from revenue growth, partially offset by lower gross margin and higher operating expenses in fiscal 2026.

[0000858877-26-000132:mdna:169]
Interest and Other Income (Loss), Net

[0000858877-26-000132:mdna:170]
Interest Income (Expense), Net   The following table summarizes interest income and interest expense (in millions):

[0000858877-26-000132:mdna:171]
|  | Years Ended |  | 2026 vs. 2025 |
|  | July 25, 2026 |  | July 26, 2025 |  | July 27, 2024 |  | Variance in Dollars |
| Interest income | $ | 866 |  |  | $ | 1,001 |  |  | $ | 1,365 |  |  | $ | (135) |  |
| Interest expense | (1,470) |  |  | (1,593) |  |  | (1,006) |  |  | 123 |  |
| Interest income (expense), net | $ | (604) |  |  | $ | (592) |  |  | $ | 359 |  |  | $ | (12) |  |

[0000858877-26-000132:mdna:172]
The decrease in interest income was driven by a lower average balance of cash and available-for-sale debt investments and lower interest rates. The decrease in interest expense was driven by a lower average balance of debt outstanding and lower effective interest rates on commercial paper.

[0000858877-26-000132:mdna:173]
Other Income (Loss), Net   The components of other income (loss), net, are summarized as follows (in millions):

[0000858877-26-000132:mdna:174]
|  | Years Ended |  | 2026 vs. 2025 |
|  | July 25, 2026 |  | July 26, 2025 |  | July 27, 2024 |  | Variance in Dollars |
| Gains (losses) on investments, net: |  |  |  |  |  |  |  |
| Available-for-sale debt investments | $ | (14) |  |  | $ | (100) |  |  | $ | (67) |  |  | $ | 86 |  |
| Marketable equity securities | (2) |  |  | 126 |  |  | 65 |  |  | (128) |  |
| Non-marketable equity securities | 1,409 |  |  | 56 |  |  | (164) |  |  | 1,353 |  |
| Net gains (losses) on investments | 1,393 |  |  | 82 |  |  | (166) |  |  | 1,311 |  |
| Other gains (losses), net | (148) |  |  | (150) |  |  | (140) |  |  | 2 |  |
| Other income (loss), net | $ | 1,245 |  |  | $ | (68) |  |  | $ | (306) |  |  | $ | 1,313 |  |

[0000858877-26-000132:mdna:175]
CISCO SYSTEMS, INC.

[0000858877-26-000132:mdna:176]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-26-000132:mdna:177]
The change in our other income (loss), net was primarily driven by higher unrealized gains on our non-marketable equity securities and lower losses on our available-for-sale debt investments, partially offset by lower gains on our marketable equity securities. The unrealized gains or losses on our non-marketable equity securities may be impacted by future observable financing rounds at varying valuations.

[0000858877-26-000132:mdna:178]
Provision for Income Taxes

[0000858877-26-000132:mdna:179]
The provision for income taxes resulted in an effective tax rate of 17.1% for fiscal 2026, compared with 8.3% for fiscal 2025. The net 8.8 percentage point increase was primarily due to a $720 million tax benefit recognized in fiscal 2025 related to a U.S. Tax Court opinion regarding the U.S. taxation of deemed foreign dividends in the transition year of the Tax Cuts and Jobs Act (“Tax Act”) (our fiscal 2018) and an increase in state taxes due to a valuation allowance adjustment for California deferred tax assets in fiscal 2026.

[0000858877-26-000132:mdna:180]
For a full reconciliation of our effective tax rate to the U.S. federal statutory rate of 21% and for further explanation of our provision for income taxes, see Note 17 to the Consolidated Financial Statements.

[0000858877-26-000132:mdna:181]
CISCO SYSTEMS, INC.

[0000858877-26-000132:mdna:182]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-26-000132:mdna:183]
LIQUIDITY AND CAPITAL RESOURCES

[0000858877-26-000132:mdna:184]
The following sections discuss the effects of changes in our balance sheet, our capital allocation strategy including stock repurchase program and dividends, our contractual obligations, and certain other commitments and activities on our liquidity and capital resources.

[0000858877-26-000132:mdna:185]
Balance Sheet and Cash Flows

[0000858877-26-000132:mdna:186]
Cash and Cash Equivalents and Investments  The following table summarizes our cash and cash equivalents and investments (in millions):

[0000858877-26-000132:mdna:187]
|  | July 25, 2026 |  | July 26, 2025 |  | Increase (Decrease) |
| Cash and cash equivalents | $ | 7,218 |  |  | $ | 8,346 |  |  | $ | (1,128) |  |
| Available-for-sale debt investments | 8,339 |  |  | 7,381 |  |  | 958 |  |
| Marketable equity securities | 361 |  |  | 383 |  |  | (22) |  |
| Total | $ | 15,918 |  |  | $ | 16,110 |  |  | $ | (192) |  |

[0000858877-26-000132:mdna:188]
The net decrease in cash and cash equivalents and investments from fiscal 2025 to fiscal 2026 was primarily driven by cash returned to stockholders in the form of cash dividends of $6.6 billion and repurchases of common stock of $6.1 billion, shares repurchased for tax withholdings on vesting of restricted stock units of $1.9 billion, repayment of debt of $1.8 billion, capital expenditures of $1.4 billion and net cash paid for acquisitions of $0.5 billion. These uses of cash were partially offset by net cash provided by operating activities of $14.2 billion, $3.2 billion net issuance of commercial paper, and the release to us of approximately $0.6 billion of restricted cash previously held in escrow.

[0000858877-26-000132:mdna:189]
We maintain an investment portfolio of various holdings, types, and maturities. We classify our investments as short-term investments based on their nature and their availability for use in current operations. We believe the overall credit quality of our portfolio is strong, with our cash equivalents and our available-for-sale debt investment portfolio consisting primarily of high quality investment-grade securities. We believe that our strong cash and cash equivalents and investments position allows us to use our cash resources for strategic investments to gain access to new technologies, for acquisitions, for customer financing activities, for working capital needs, and for the repurchase of shares of common stock and payment of dividends as discussed below.

[0000858877-26-000132:mdna:190]
Securities Lending  We periodically engage in securities lending activities with certain of our available-for-sale debt investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. We require collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. We engage in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify us against collateral losses. We did not experience any losses in connection with the secured lending of securities during the periods presented. As of July 25, 2026 and July 26, 2025, we had no outstanding securities lending transactions.

[0000858877-26-000132:mdna:191]
Free Cash Flow and Capital Allocation  As part of our capital allocation strategy, we target to return a minimum of 50% of our free cash flow annually to our stockholders through cash dividends and repurchases of common stock.

[0000858877-26-000132:mdna:192]
We define free cash flow as net cash provided by operating activities less cash used to acquire property and equipment. The following table reconciles our net cash provided by operating activities to free cash flow (in millions):

[0000858877-26-000132:mdna:193]
| Years Ended | July 25, 2026 |  | July 26, 2025 |  | July 27, 2024 |
| Net cash provided by operating activities | $ | 14,177 |  |  | $ | 14,193 |  |  | $ | 10,880 |  |
| Acquisition of property and equipment | (1,410) |  |  | (905) |  |  | (670) |  |
| Free cash flow | $ | 12,767 |  |  | $ | 13,288 |  |  | $ | 10,210 |  |

[0000858877-26-000132:mdna:194]
Our net cash provided by operating activities in fiscal 2026 was flat compared to fiscal 2025, primarily driven by higher cash collections offset by higher payments made to contract manufacturers and suppliers and our final U.S. transition tax payment of $2.3 billion associated with the one-time U.S. transition tax on accumulated earnings for foreign subsidiaries as a result of the Tax Act.

[0000858877-26-000132:mdna:195]
We expect that cash provided by operating activities may fluctuate in future periods as a result of a number of factors, including fluctuations in our operating results, the rate at which products are shipped during the quarter (which we refer to as shipment

[0000858877-26-000132:mdna:196]
CISCO SYSTEMS, INC.

[0000858877-26-000132:mdna:197]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-26-000132:mdna:198]
linearity), the timing and collection of accounts receivable and financing receivables, inventory and supply chain management, deferred revenue and the timing and amount of tax and other payments. For additional discussion, see “Part I, Item 1A. Risk Factors” in this report.

[0000858877-26-000132:mdna:199]
We consider free cash flow to be a liquidity measure that provides useful information to management and investors because of our intent to return a stated percentage of free cash flow to stockholders in the form of dividends and stock repurchases. We further regard free cash flow as a useful measure because it reflects cash that can be used to, among other things, invest in our business, make strategic acquisitions, repurchase common stock, and pay dividends on our common stock, after deducting capital investments. A limitation of the utility of free cash flow as a measure of financial performance and liquidity is that the free cash flow does not represent the total increase or decrease in our cash balance for the period. In addition, we have other required uses of cash, including repaying the principal of our outstanding indebtedness. Free cash flow is not a measure calculated in accordance with U.S. generally accepted accounting principles and should not be regarded in isolation or as an alternative for net cash provided by operating activities or any other measure calculated in accordance with such principles, and other companies may calculate free cash flow in a different manner than we do.

[0000858877-26-000132:mdna:200]
The following table summarizes the dividends paid and stock repurchases (in millions, except per-share amounts):

[0000858877-26-000132:mdna:201]
|  |  | DIVIDENDS |  | STOCK REPURCHASE PROGRAM |  | TOTAL |
| Years Ended |  | Per Share |  | Amount |  | Shares |  | Weighted-Average Price per Share |  | Amount |  | Amount |
| July 25, 2026 |  | $ | 1.66 |  |  | $ | 6,553 |  |  | 76 |  |  | $ | 80.26 |  |  | $ | 6,106 |  |  | $ | 12,659 |  |
| July 26, 2025 |  | $ | 1.62 |  |  | $ | 6,437 |  |  | 105 |  |  | $ | 56.53 |  |  | $ | 5,995 |  |  | $ | 12,432 |  |
| July 27, 2024 |  | $ | 1.58 |  |  | $ | 6,384 |  |  | 117 |  |  | $ | 49.45 |  |  | $ | 5,764 |  |  | $ | 12,148 |  |

[0000858877-26-000132:mdna:202]
On August 12, 2026, our Board of Directors declared a quarterly dividend of $0.42 per common share to be paid on October 21, 2026, to all stockholders of record as of the close of business on October 2, 2026. Future dividends will be subject to the approval of our Board of Directors.

[0000858877-26-000132:mdna:203]
As of July 25, 2026, the remaining authorized amount for stock repurchases under this program is approximately $8.1 billion, with no termination date.

[0000858877-26-000132:mdna:204]
Accounts Receivable, Net  The following table summarizes our accounts receivable, net (in millions):

[0000858877-26-000132:mdna:205]
|  | July 25, 2026 |  | July 26, 2025 |  | Increase (Decrease) |
| Accounts receivable, net | $ | 7,470 |  |  | $ | 6,701 |  |  | $ | 769 |  |

[0000858877-26-000132:mdna:206]
Our accounts receivable net, as of July 25, 2026 increased by approximately 11% year over year primarily due to higher revenue compared with fiscal 2025.

[0000858877-26-000132:mdna:207]
Inventory Supply Chain  The following table summarizes our inventories and balances with contract manufacturers and suppliers (in millions):

[0000858877-26-000132:mdna:208]
|  | July 25, 2026 |  | July 26, 2025 |  | Increase (Decrease) |
| Inventories | $ | 5,694 |  |  | $ | 3,164 |  |  | $ | 2,530 |  |
| Inventory purchase commitments | $ | 17,165 |  |  | $ | 7,599 |  |  | $ | 9,566 |  |
| Inventory deposits and prepayments | $ | 1,104 |  |  | $ | 825 |  |  | $ | 279 |  |

[0000858877-26-000132:mdna:209]
Inventory deposits and prepayments represent amounts paid to suppliers in advance of delivery, principally under arrangements to secure supply and pricing for memory and certain components. These amounts are included in other current assets and other assets on our Consolidated Balance Sheets, and are assessed for recoverability.

[0000858877-26-000132:mdna:210]
CISCO SYSTEMS, INC.

[0000858877-26-000132:mdna:211]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-26-000132:mdna:212]
The following table summarizes our inventory purchase commitments with contract manufacturers and suppliers by period (in millions):

[0000858877-26-000132:mdna:213]
|  | July 25, 2026 |  | July 26, 2025 |  | Increase (Decrease) |
| Less than 1 year | $ | 14,341 |  |  | $ | 7,202 |  |  | $ | 7,139 |  |
| 1 to 3 years | 2,558 |  |  | 320 |  |  | 2,238 |  |
| 3 to 5 years | 266 |  |  | 77 |  |  | 189 |  |
| Total | $ | 17,165 |  |  | $ | 7,599 |  |  | $ | 9,566 |  |

[0000858877-26-000132:mdna:214]
Inventory as of July 25, 2026 increased by 80% and inventory purchase commitments with contract manufacturers and suppliers increased by 126% from our balances at the end of fiscal 2025. The combined increase of 112% in our inventory and inventory purchase commitments as compared with the end of fiscal 2025 was primarily related to commitments with contract manufacturers and suppliers related to manufacturing Cisco Silicon One and other products to meet the demand from hyperscalers and other customers. The impact of higher memory prices and commitments with certain suppliers to help secure supply and pricing for memory and certain components also contributed significantly to this increase. We expect our inventory balances may increase in future quarters as we work to fulfill this demand.

[0000858877-26-000132:mdna:215]
In recent periods, we have increased our levels of inventory and purchase commitments with contract manufacturers and suppliers primarily related to Cisco Silicon One. The increases during fiscal 2026 were primarily due to arrangements to secure supply and pricing for certain product components, including memory, and commitments with contract manufacturers to meet customer demand and help manage lead times. Our risks of future material excess and obsolete inventory and related losses are further outlined in the Results of Operations—Product Gross Margin section and in Note 2 to the Consolidated Financial Statements.

[0000858877-26-000132:mdna:216]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that allow them to procure inventory based upon criteria as defined by us or that establish the parameters defining our requirements and our commitment to securing manufacturing capacity.

[0000858877-26-000132:mdna:217]
Our inventory purchase commitments are for short-term product manufacturing requirements as well as for commitments to suppliers to secure manufacturing capacity. Certain of our inventory purchase commitments are entered into directly with suppliers and relate to fixed-dollar commitments to secure supply and pricing for certain product components for multi-year periods. In addition, certain of these inventory purchase commitments are related to long-term supply agreements for fixed quantities of certain memory components for which pricing is variable based on current market values. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.

[0000858877-26-000132:mdna:218]
Inventory and supply chain management remain areas of focus as we balance the need to maintain supply chain flexibility to help ensure competitive lead times with the risk of inventory obsolescence because of supply constraints, rapidly changing technology and customer requirements. We believe the amount of our inventory and inventory purchase commitments is appropriate for our current and expected customer demand and revenue levels. Because a significant portion of these balances are based on our current demand forecasts, actual requirements may differ, and a significant reduction in or change to those forecasts could result in material excess and obsolete inventory or purchase commitment charges.

[0000858877-26-000132:mdna:219]
Financing Receivables and Guarantees  The following table summarizes our financing receivables (in millions):

[0000858877-26-000132:mdna:220]
|  | July 25, 2026 |  | July 26, 2025 |  | Increase (Decrease) |
| Loan receivables, net | $ | 7,417 |  |  | $ | 5,591 |  |  | $ | 1,826 |  |
| Lease receivables, net | 915 |  |  | 936 |  |  | (21) |  |
| Total, net | $ | 8,332 |  |  | $ | 6,527 |  |  | $ | 1,805 |  |

[0000858877-26-000132:mdna:221]
Financing Receivables  Our financing arrangements include loans and leases. Our loan receivables include customer financing for purchases of our hardware, software and services (including technical support and professional services), and also may include additional funds for other costs associated with network installation and integration of our products and services. Lease receivables include sales-type leases. Arrangements related to leases are generally collateralized by a security interest in the

[0000858877-26-000132:mdna:222]
CISCO SYSTEMS, INC.

[0000858877-26-000132:mdna:223]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-26-000132:mdna:224]
underlying assets. Financing receivables increased by 28% as compared with the end of fiscal 2025, primarily due to an increase in loan receivables reflecting higher customer demand for financing of hardware, software and services.

[0000858877-26-000132:mdna:225]
Financing Guarantees  In the normal course of business, third parties may provide financing arrangements to our channel partners and end users under financing programs. The financing arrangements to channel partners consist of revolving short-term financing provided by third parties, with payment terms generally ranging from 60 to 90 days. In certain instances, these financing arrangements result in a transfer of our receivables to the third party. The receivables are derecognized upon transfer, as these transfers qualify as true sales, and we receive payments for the receivables from the third party based on our standard payment terms. The financing arrangements provided by third parties to end users are related to leases and loans and typically have terms of up to three years. In some cases, we provide guarantees to third parties for these lease and loan arrangements.

[0000858877-26-000132:mdna:226]
The volume of channel partner financing was $29.9 billion, $24.9 billion, and $27.1 billion in fiscal 2026, 2025, and 2024, respectively. These financing arrangements facilitate the working capital requirements of the channel partners, and in some cases, we guarantee a portion of these arrangements. The balance of the channel partner financing subject to guarantees was $1.2 billion and $1.3 billion as of July 25, 2026 and July 26, 2025, respectively. We could be called upon to make payments under these guarantees in the event of nonpayment by the channel partners. Historically, our payments under these arrangements have been immaterial. Where we provide a guarantee, we defer the revenue associated with the channel partner financing arrangement in accordance with revenue recognition policies, or we record a liability for the fair value of the guarantees. In either case, the deferred revenue is recognized as revenue when the guarantee is removed. As of July 25, 2026, the total maximum potential future payments related to these guarantees was approximately $127 million, of which approximately $12 million was recorded as deferred revenue.

[0000858877-26-000132:mdna:227]
Borrowings

[0000858877-26-000132:mdna:228]
Senior Fixed-Rate Notes  The following table summarizes the principal amount of our senior fixed-rate notes (in millions):

[0000858877-26-000132:mdna:229]
|  | Maturity Date |  | July 25, 2026 |  | July 26, 2025 |
| Senior fixed-rate notes: |  |  |  |  |  |
| 4.90% | February 26, 2026 |  | $ | — |  |  | $ | 1,000 |  |
| 2.95% | February 28, 2026 |  | — |  |  | 750 |  |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 1,500 |  |
| 4.80% | February 26, 2027 |  | 2,000 |  |  | 2,000 |  |
| 4.55% | February 24, 2028 |  | 1,000 |  |  | 1,000 |  |
| 4.85% | February 26, 2029 |  | 2,500 |  |  | 2,500 |  |
| 4.75% | February 24, 2030 |  | 1,000 |  |  | 1,000 |  |
| 4.95% | February 26, 2031 |  | 2,500 |  |  | 2,500 |  |
| 4.95% | February 24, 2032 |  | 1,000 |  |  | 1,000 |  |
| 5.05% | February 26, 2034 |  | 2,500 |  |  | 2,500 |  |
| 5.10% | February 24, 2035 |  | 1,250 |  |  | 1,250 |  |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 2,000 |  |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 2,000 |  |
| 5.30% | February 26, 2054 |  | 2,000 |  |  | 2,000 |  |
| 5.50% | February 24, 2055 |  | 750 |  |  | 750 |  |
| 5.35% | February 26, 2064 |  | 1,000 |  |  | 1,000 |  |
| Total |  |  | $ | 23,000 |  |  | $ | 24,750 |  |

[0000858877-26-000132:mdna:230]
Interest is payable semiannually on each class of the senior fixed-rate notes, each of which is redeemable by us at any time, subject to a make-whole premium. We were in compliance with all debt covenants as of July 25, 2026.

[0000858877-26-000132:mdna:231]
Commercial Paper  We have a short-term debt financing program in which up to $15.0 billion is available through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes. We had $6.7 billion and $3.5 billion in commercial paper notes outstanding as of July 25, 2026, and July 26, 2025, respectively.

[0000858877-26-000132:mdna:232]
Credit Facility  On February 2, 2024, we entered into an amended and restated 5-year $5.0 billion unsecured revolving credit agreement. The interest rate for the credit agreement is determined based on a formula using certain market rates. The credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio (defined in the

[0000858877-26-000132:mdna:233]
CISCO SYSTEMS, INC.

[0000858877-26-000132:mdna:234]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-26-000132:mdna:235]
agreement as the ratio of consolidated EBITDA to consolidated interest expense) of not less than 3.0 to 1.0. As of July 25, 2026, we were in compliance with all associated covenants and we had not borrowed any funds under our credit agreement.

[0000858877-26-000132:mdna:236]
Remaining Performance Obligations   The following table presents the breakdown of remaining performance obligations (in millions):

[0000858877-26-000132:mdna:237]
|  | July 25, 2026 |  | July 26, 2025 |  | Increase (Decrease) |
| Product | $ | 23,436 |  |  | $ | 21,572 |  |  | $ | 1,864 |  |
| Services | 23,298 |  |  | 21,961 |  |  | 1,337 |  |
| Total | $ | 46,734 |  |  | $ | 43,533 |  |  | $ | 3,201 |  |
| Short-term RPO | $ | 22,776 |  |  | $ | 21,723 |  |  | $ | 1,053 |  |
| Long-term RPO | 23,958 |  |  | 21,810 |  |  | 2,148 |  |
| Total | $ | 46,734 |  |  | $ | 43,533 |  |  | $ | 3,201 |  |

[0000858877-26-000132:mdna:238]
Total remaining performance obligations increased 7% in fiscal 2026. Remaining performance obligations for product increased 9% and remaining performance obligations for services increased 6%, compared to fiscal 2025.

[0000858877-26-000132:mdna:239]
Deferred Revenue   The following table presents the breakdown of deferred revenue (in millions):

[0000858877-26-000132:mdna:240]
|  | July 25, 2026 |  | July 26, 2025 |  | Increase (Decrease) |
| Product | $ | 13,817 |  |  | $ | 13,490 |  |  | $ | 327 |  |
| Services | 15,964 |  |  | 15,289 |  |  | 675 |  |
| Total | $ | 29,781 |  |  | $ | 28,779 |  |  | $ | 1,002 |  |
| Reported as: |  |  |  |  |  |
| Current | $ | 16,988 |  |  | $ | 16,416 |  |  | $ | 572 |  |
| Noncurrent | 12,793 |  |  | 12,363 |  |  | 430 |  |
| Total | $ | 29,781 |  |  | $ | 28,779 |  |  | $ | 1,002 |  |

[0000858877-26-000132:mdna:241]
Total deferred revenue increased 3% in fiscal 2026. The increase in deferred product revenue of 2% was primarily due to increased deferrals related to our recurring software offerings. The increase in deferred services revenue of 4% was driven by higher business volume, partially offset by ongoing amortization of deferred services revenue.

[0000858877-26-000132:mdna:242]
Contractual Obligations

[0000858877-26-000132:mdna:243]
The impact of contractual obligations on our liquidity and capital resources in future periods should be analyzed in conjunction with the factors that impact our cash flows from operations discussed previously. In addition, we plan for and measure our liquidity and capital resources through an annual budgeting process. The following table summarizes our contractual obligations at July 25, 2026 (in millions):

[0000858877-26-000132:mdna:244]
|  | PAYMENTS DUE BY PERIOD |
| July 25, 2026 | Total |  | Less than 1 Year |  | 1 to 3 Years |  | 3 to 5 Years |  | More than 5 Years |
| Operating leases | $ | 1,874 |  |  | $ | 461 |  |  | $ | 601 |  |  | $ | 401 |  |  | $ | 411 |  |
| Purchase commitments with contract manufacturers and suppliers | 17,165 |  |  | 14,341 |  |  | 2,558 |  |  | 266 |  |  | — |  |
| Other purchase obligations | 7,044 |  |  | 2,460 |  |  | 3,461 |  |  | 956 |  |  | 167 |  |
| Long-term debt | 23,002 |  |  | 3,502 |  |  | 3,500 |  |  | 3,500 |  |  | 12,500 |  |
| Other long-term liabilities | 1,990 |  |  | — |  |  | 323 |  |  | 266 |  |  | 1,401 |  |
| Total by period | $ | 51,075 |  |  | $ | 20,764 |  |  | $ | 10,443 |  |  | $ | 5,389 |  |  | $ | 14,479 |  |
| Other long-term liabilities (uncertainty in the timing of future payments) | 2,424 |  |  |  |  |  |  |  |  |  |
| Total | $ | 53,499 |  |  |  |  |  |  |  |  |  |

[0000858877-26-000132:mdna:245]
CISCO SYSTEMS, INC.

[0000858877-26-000132:mdna:246]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-26-000132:mdna:247]
Operating Leases  For more information on our operating leases, see Note 8 to the Consolidated Financial Statements.

[0000858877-26-000132:mdna:248]
Purchase Commitments with Contract Manufacturers and Suppliers  We enter into agreements with contract manufacturers and suppliers that allow them to procure inventory based upon criteria as defined by us or that establish the parameters defining our requirements and our commitment to securing manufacturing capacity. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. We record a liability for these commitments for quantities in excess of our future demand forecasts, and for commitments relating to components that can no longer be used in a salable product, consistent with the valuation of our excess and obsolete inventory. See further discussion in “Inventory Supply Chain” and in Note 13(a) to the Consolidated Financial Statements.

[0000858877-26-000132:mdna:249]
Other Purchase Obligations  Other purchase obligations represent an estimate of all contractual obligations in the ordinary course of business, other than operating leases and commitments with contract manufacturers and suppliers, for which we have not received the goods or services. Purchase orders are not included in the preceding table as they typically represent our authorization to purchase rather than binding contractual purchase obligations.

[0000858877-26-000132:mdna:250]
Long-Term Debt  The amount of long-term debt in the preceding table represents the principal amount of the respective debt instruments. See Note 11 to the Consolidated Financial Statements.

[0000858877-26-000132:mdna:251]
Other Long-Term Liabilities  Other long-term liabilities primarily include noncurrent income taxes payable, accrued liabilities for deferred compensation, deferred tax liabilities, and certain other long-term liabilities. Due to the uncertainty in the timing of future payments, our noncurrent income taxes payable of approximately $2.3 billion and deferred tax liabilities of $85 million were presented as one aggregated amount in the total column on a separate line in the preceding table. Noncurrent income taxes payable include uncertain tax positions. See Note 17 to the Consolidated Financial Statements.

[0000858877-26-000132:mdna:252]
Other Commitments

[0000858877-26-000132:mdna:253]
In connection with our acquisitions, we have agreed to pay certain additional amounts contingent upon the continued employment with us of certain employees of the acquired entities. See Note 4 to the Consolidated Financial Statements.

[0000858877-26-000132:mdna:254]
Of the total carrying value of our non-marketable equity securities as of July 25, 2026, $1.1 billion of such investments are considered to be in variable interest entities which are unconsolidated. We have total funding commitments of $0.4 billion related to non-marketable equity securities. The carrying value of these investments and the additional funding commitments, collectively, represent our maximum exposure related to non-marketable equity securities. See Note 10 to the Consolidated Financial Statements.

[0000858877-26-000132:mdna:255]
We provide financing guarantees, which are generally for various third-party financing arrangements extended to our channel partners. We could be called upon to make payments under these guarantees in the event of nonpayment by the channel partners. See the previous discussion of these financing guarantees under “Financing Receivables and Guarantees.”

[0000858877-26-000132:mdna:256]
Liquidity and Capital Resource Requirements

[0000858877-26-000132:mdna:257]
Based on past performance and current expectations, we believe our cash and cash equivalents, investments, cash generated from operations, and ability to access capital markets and committed credit lines will satisfy, through at least the next 12 months, our liquidity requirements, both in total and domestically, including the following: working capital needs (including inventory and other supply related payments), capital expenditures, investment requirements, stock repurchases, cash dividends, contractual obligations, commitments, principal and interest payments on debt, pending acquisitions, future and committed customer financings, and other liquidity requirements associated with our operations. There are no other transactions, arrangements, or relationships with unconsolidated entities or other persons that are reasonably likely to materially affect the liquidity and the availability of, as well as our requirements for, capital resources.
