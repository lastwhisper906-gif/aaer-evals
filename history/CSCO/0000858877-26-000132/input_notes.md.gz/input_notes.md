# CSCO notes — 0000858877-26-000132


## dei:DocumentsIncorporatedByReferenceTextBlock

[0000858877-26-000132:notes:1]
Portions of the registrant’s definitive Proxy Statement relating to the 2026 Annual Meeting of Stockholders, to be held on December 15, 2026, are incorporated by reference into Part III of this Annual Report on Form 10-K where indicated.


## cyd:CybersecurityRiskManagementProcessesForAssessingIdentifyingAndManagingThreatsTextBlock

[0000858877-26-000132:notes:2]
We recognize the critical importance of maintaining the trust and confidence of our customers, employees, and other stakeholders. To help mitigate the cybersecurity risks that we face, we maintain processes for identifying, assessing, and managing such risks.

[0000858877-26-000132:notes:3]
Our incident response functions, which include our Security and Trust Organization (“S&TO”) under the leadership of our Chief Security and Trust Officer, have established internal policies, processes, and procedures to monitor, detect, investigate, respond to, and escalate management of internal and external cybersecurity threats and incidents. We maintain policies and procedures for the escalation of cybersecurity incidents, assessed as potentially being or becoming material, to designated members of our senior management for further assessment. We also, as necessary, inform our independent registered public accounting firm of significant cybersecurity matters and any relevant developments.

[0000858877-26-000132:notes:4]
To help identify, assess, and mitigate cybersecurity threats that we face to our business, S&TO, in addition to its own capabilities, partners with Cisco’s Talos Threat Intelligence Group and third parties, including governments and peer companies, to share and receive threat intelligence and other information. S&TO actively monitors for and evaluates cybersecurity vulnerabilities, threats, and incidents observable on the Internet and the dark web. In addition to monitoring risks from threats to our own business, we operate third-party risk management programs to help identify and manage risks from cybersecurity threats arising from third-party suppliers and service providers on which we rely. These programs leverage on-going security-focused risk assessments based on industry practices, audits, and contractual requirements.

[0000858877-26-000132:notes:5]
We strive to embed security into our products and services through the Cisco Secure Development Lifecycle (CSDL). The CSDL introduces security and privacy considerations throughout the lifecycle of our products and services. In addition, S&TO advises business units and functional areas on addressing cybersecurity risks and monitors initiatives to mitigate and manage such risks over time. Our business units or functional areas are responsible for managing risks and ensuring that security policies and standards are implemented within the respective business unit or function. S&TO also conducts mandatory cybersecurity training for our employees and provides employees with tools to report suspected incidents.

[0000858877-26-000132:notes:6]
S&TO engages third parties in connection with our cybersecurity risk management processes, including cybersecurity consultants and auditors, to conduct evaluations of our IT security controls and provide certifications for industry-standard security frameworks. In addition, we maintain a global privacy program to assess and manage privacy risks related to how we are collecting, using, sharing, and storing personal data, which is subject to assessment by an independent, third-party privacy assessor.


## cyd:CybersecurityRiskBoardOfDirectorsOversightTextBlock

[0000858877-26-000132:notes:7]
Our Chief Security and Trust Officer, who reports to our Executive Vice President, Operations, works collaboratively across our business to implement policies and procedures designed to protect our IT environment and our products and services from cybersecurity threats, and to promptly respond to cybersecurity incidents in accordance with our incident response policies and procedures. Our Chief Security and Trust Officer has extensive cybersecurity experience and has served in various roles in information technology and information security for over 25 years.

[0000858877-26-000132:notes:8]
The Chief Security and Trust Officer provides regular reports on the status of cybersecurity risks, priorities, and focus areas to our executive leadership team. In addition, information on cybersecurity risks is further integrated into our broader enterprise risk management program through our internal audit function, which incorporates such information in regular audits of our cybersecurity and data protection controls and processes.

[0000858877-26-000132:notes:9]
Our Board of Directors oversees risks related to cybersecurity threats to our business directly and through its Audit Committee. The Audit Committee receives regular reports on cybersecurity risks, priorities, and focus areas from our Chief Security and Trust Officer at least four times a year and receives a live presentation at least twice a year. Our Board of Directors also regularly receives updates from the Audit Committee on its oversight activities and, on occasion, receives updates directly from our Chief Security and Trust Officer. Additionally, the Chief Security and Trust Officer provides more frequent updates to the Board of Directors and Audit Committee if necessary due to a cybersecurity threat, incident, or other development.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000858877-26-000132:notes:10]
Basis of Presentation
The fiscal year for Cisco Systems, Inc. (the “Company,” “Cisco,” “we,” “us,” or “our”) is the 52 or 53 weeks ending on the last Saturday in July. Fiscal 2026, fiscal 2025 and fiscal 2024 were each 52-week fiscal years. The Consolidated Financial Statements include our accounts and those of our subsidiaries and other entities in which we hold a controlling financial interest. All intercompany accounts and transactions have been eliminated. We conduct business globally and are primarily managed on a geographic basis in the following three geographic segments: the Americas; Europe, Middle East, and Africa (EMEA); and Asia Pacific, Japan, and China (APJC).

[0000858877-26-000132:notes:11]
Certain reclassifications have been made to the amounts for prior years in order to conform to the current year’s presentation.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000858877-26-000132:notes:12]
Summary of Significant Accounting Policies
(a) Cash and Cash Equivalents  We consider all highly liquid investments purchased with an original or remaining maturity of three months or less at the date of purchase to be cash equivalents.

[0000858877-26-000132:notes:13]
(b) Available-for-Sale Debt Investments  We classify our investments in fixed income securities as available-for-sale debt investments. Our available-for-sale debt investments primarily consist of U.S. government, U.S. government agency, non-U.S. government and agency, corporate debt, U.S. agency mortgage-backed securities, commercial paper and certificates of deposit. These available-for-sale debt investments are primarily held in the custody of a major financial institution. A specific identification method is used to determine the cost basis of available-for-sale debt investments sold. These investments are recorded in the Consolidated Balance Sheets at fair value and unrealized gains and losses on these investments are included as a separate component of accumulated other comprehensive income (loss) (AOCI), net of tax. We classify our investments as current based on the nature of the investments and their availability for use in current operations.

[0000858877-26-000132:notes:14]
(c) Marketable equity securities  Our marketable equity securities have readily determinable fair values (RDFV) and are measured at fair value, with changes recognized in other income (loss), net in the Consolidated Statements of Operations.

[0000858877-26-000132:notes:15]
(d) Non-marketable equity securities  Our non-marketable equity securities are investments in privately held entities, venture funds, and publicly traded entities that do not have RDFV. Privately held entities are measured under the measurement alternative. Investments accounted for under the measurement alternative are recorded at cost, less any impairment, plus or minus changes resulting from qualifying observable price changes. We account for non-marketable equity securities, such as our investments in venture funds, where we do not control, but are able to exert significant influence over, the investee, under the equity method. For certain of our investments in venture funds, we have elected to apply the net asset value (NAV) practical expedient to estimate the fair value of these investments. Securities in publicly traded entities that possess restrictions that are at the instrument level (“restricted equity securities”) are valued based on pricing models that use observable market inputs reduced by a discount for lack of marketability (“DLOM”).

[0000858877-26-000132:notes:16]
(e) Impairments of Investments  For our available-for-sale debt securities in an unrealized loss position, we determine whether a credit loss exists. In this assessment, among other factors, we consider the extent to which the fair value is less than the amortized cost, any changes to the rating of the security by a rating agency, and adverse conditions specifically related to the security. If factors indicate a credit loss exists, an allowance for credit loss is recorded to other income (loss), net, limited by the amount that the fair value is less than the amortized cost basis. The amount of fair value change relating to all other factors is recognized in other comprehensive income (OCI).

[0000858877-26-000132:notes:17]
We hold non-marketable equity securities which are included in other assets in the Consolidated Balance Sheets. We monitor these investments for impairments and make reductions in carrying values if we determine that an impairment charge is required based primarily on the financial condition and near-term prospects of these companies.

[0000858877-26-000132:notes:18]
(f) Inventories  Inventories are stated at the lower of cost or net realizable value. Cost is computed using standard cost, which approximates actual cost, on a first-in, first-out basis. We write down inventory for estimated excess and obsolete quantities based on assumptions regarding future demand, product life cycles, planned product transitions, and the extent to which inventory is specific to a particular customer program, product design, or qualification. A significant portion of our inventory, together with the component purchase commitments described in Note 13(a), supports products sold to hyperscalers and other large customers. Purchase commitments with contract manufacturers and suppliers related to orders from these customers are based on our current demand forecasts and may be canceled, rescheduled, or modified with limited notice. Component lead

[0000858877-26-000132:notes:19]
times for these products frequently exceed the notice period we receive for changes to customer orders. Certain of these components are qualified to a specific customer design or program and have limited alternative use, while others, including certain memory components, are more readily deployable across our product portfolio. As a result, reductions in our demand forecasts, changes in product architecture or design specifications, and changes in qualification requirements may cause inventory to be in excess of demand or be unusable in a salable product.

[0000858877-26-000132:notes:20]
We also make deposits and prepayments to certain suppliers in advance of delivery under arrangements to secure supply and pricing for certain product components. These amounts are included in other current assets and other assets on our Consolidated Balance Sheets and are assessed for recoverability.

[0000858877-26-000132:notes:21]
Inventory write-downs are recognized in cost of sales in the period in which the determination is made and establish a new cost basis for the affected inventory. That new cost basis is not subsequently increased if the underlying circumstances improve.

[0000858877-26-000132:notes:22]
(g) Allowance for Accounts Receivable, Contract Assets and Financing Receivables  We estimate our allowances for credit losses using relevant available information from internal and external sources, related to past events, current conditions and reasonable and supportable forecasts. Historical credit loss experience provides the basis for the estimation of expected credit losses. When assessing for credit losses, we determine collectibility by pooling our assets with similar characteristics.

[0000858877-26-000132:notes:23]
The allowances for credit losses are each measured on a collective basis when similar risk characteristics exist. Our internal credit risk ratings are categorized as 1 through 10, with the lowest credit risk rating representing the highest quality. Assets that do not share risk characteristics are evaluated on an individual basis. The allowances for credit losses are each measured by multiplying the exposure probability of default, the probability the asset will default within a given time frame, by the loss given default rate, the percentage of the asset not expected to be collected due to default, based on the pool of assets.

[0000858877-26-000132:notes:24]
Probability of default rates are published quarterly by third-party credit agencies. Adjustments to our internal credit risk ratings may take into account various factors, including, but not limited to, various customer-specific factors, the potential sovereign risk of the geographic locations in which the customer is operating and macroeconomic conditions. These factors are updated regularly or when facts and circumstances indicate that an update is deemed necessary.

[0000858877-26-000132:notes:25]
(h) Financing Receivables and Guarantees  We provide financing arrangements, including loan receivables and lease receivables, for certain qualified end users to build, maintain, and upgrade their networks, and we record accrued interest on the portfolio. Loan receivables represent financing arrangements related to the sale of our hardware, software, and services (including technical support and professional services), and also may include additional funding for other costs associated with network installation and integration of our products and services. Loan receivables have terms of one year to three years on average. Lease receivables represent sales-type leases resulting from the sale of Cisco’s and complementary third-party products and are typically collateralized by a security interest in the underlying assets. Lease receivables consist of arrangements with terms of four years on average.

[0000858877-26-000132:notes:26]
Outstanding financing receivables that are aged 31 days or more from the contractual payment date are considered past due. We do not accrue interest on financing receivables that are more than 120 days past due unless either the receivable has not been collected due to administrative reasons or the receivable is well secured and in the process of collection. Financing receivables may be placed on nonaccrual status earlier if, in management’s opinion, a timely collection of the full principal and interest becomes uncertain. After a financing receivable has been categorized as nonaccrual, interest will be recognized when cash is received. A financing receivable may be returned to accrual status after all of the customer’s delinquent balances of principal and interest have been settled, and the customer remains current for an appropriate period.

[0000858877-26-000132:notes:27]
We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, generally with payment terms ranging from 60 to 90 days. In certain instances, these financing arrangements result in a transfer of our receivables to the third party. The receivables are derecognized upon transfer, as these transfers qualify as a sale, and we receive a payment for the receivables from the third party based on our standard payment terms. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. We could be called upon to make payments under these guarantees if the channel partners do not pay. Deferred revenue relating to these financing arrangements is recorded in accordance with revenue recognition policies or for the fair value of the financing guarantees.

[0000858877-26-000132:notes:28]
(i) Leases  We lease real estate, information technology (IT) and other equipment and vehicles. We also have arrangements with certain suppliers and contract manufacturers which includes the leasing of dedicated space and equipment costs. Certain of our leases include options to extend or terminate. We include those options in the lease term when it is reasonably certain we will exercise them.

[0000858877-26-000132:notes:29]
As a lessee, we determine if an arrangement is a lease at commencement. Our right-of-use (ROU) lease assets represent our right to use an underlying asset for the lease term and lease liabilities represent our obligation to make lease payments related to the lease. Operating lease ROU assets and liabilities are recognized at the commencement date based on the present value of lease payments over the lease term. We use incremental borrowing rates based on information available at the commencement date to determine the present value of our lease payments. Certain of our lease agreements contain variable lease payments. Our variable lease payments can fluctuate depending on the level of activity or the cost of certain services where we have elected to combine lease and non-lease components. While these payments are not included as part of our lease liabilities, they are recognized as variable lease expense in the period they are incurred.

[0000858877-26-000132:notes:30]
We provide leasing of our equipment and complementary third-party products primarily through our channel partners and distributors, for which the income arising from these leases is recognized through interest income. As a lessor, we determine if an arrangement is a lease at inception. We provide leasing arrangements for our equipment to certain qualified customers. Our lease portfolio primarily consists of sales-type leases. We allocate the consideration in a bundled contract with our customers based on relative standalone selling prices of our lease and non-lease components. The residual value on our leased equipment is determined at the inception of the lease based on an analysis of estimates of the value of equipment, market factors and historical customer behavior. Residual value estimates are reviewed on a periodic basis and declines are expensed in the period they occur. Our leases generally provide an end-of-term option for the customer to extend the lease under mutually-agreed terms, return the leased equipment, or purchase the equipment for either the then-market value of the equipment or a pre-determined purchase price. If a customer chooses to terminate their lease prior to the original end of lease term, the customer is required to pay all remaining lease payments in full.

[0000858877-26-000132:notes:31]
(j) Depreciation and Amortization  Property and equipment are stated at cost, less accumulated depreciation or amortization, whenever applicable. Depreciation and amortization expenses for property and equipment were approximately $0.7 billion for each of fiscal 2026, 2025, and 2024. Depreciation and amortization are computed using the straight-line method, generally over the following periods:

[0000858877-26-000132:notes:32]
| Asset Category |  | Period |
| Buildings |  | 25 years |
| Building improvements |  | Up to 15 years |
| Leasehold improvements |  | Shorter of remaining lease term or up to 15 years |
| Production, engineering, computer and other equipment and related software |  | Up to 5 years |
| Operating lease assets |  | Based on lease term |
| Furniture and fixtures |  | 5 years |

[0000858877-26-000132:notes:33]
(k) Business Combinations  We allocate the fair value of the purchase consideration of our acquisitions to the tangible assets, liabilities, and intangible assets acquired, including in-process research and development (IPR&D), based on their estimated fair values. The excess of the fair value of purchase consideration over the fair values of these identifiable assets and liabilities is recorded as goodwill. IPR&D is initially capitalized at fair value as an intangible asset with an indefinite life and assessed for impairment thereafter. When an IPR&D project is completed, the IPR&D is reclassified as an amortizable purchased intangible asset and amortized over the asset’s estimated useful life. Acquisition-related expenses and related restructuring costs are recognized separately from the business combination and are expensed as incurred.

[0000858877-26-000132:notes:34]
(l) Goodwill and Purchased Intangible Assets  Goodwill is tested for impairment on an annual basis in the fourth fiscal quarter and, when specific circumstances dictate, between annual tests. An impairment charge is recognized for the amount by which the reporting unit’s carrying amount exceeds its fair value, limited to the amount of goodwill allocated to that reporting unit. Identifying a potential impairment consists of comparing the fair value of a reporting unit with its carrying amount, including goodwill. Purchased intangible assets with finite lives are carried at cost, less accumulated amortization. Amortization is computed over the estimated useful lives of the respective assets. See “Long-Lived Assets” for our policy regarding impairment testing of purchased intangible assets with finite lives. Purchased intangible assets with indefinite lives are assessed for potential impairment annually or when events or circumstances indicate that their carrying amounts might be impaired.

[0000858877-26-000132:notes:35]
(m) Long-Lived Assets  Long-lived assets that are held and used by us are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of such assets may not be recoverable. Determination of recoverability of long-lived assets is based on an estimate of the undiscounted future cash flows resulting from the use of the asset and its eventual disposition. Measurement of an impairment loss for long-lived assets that management expects to hold and use is based on the difference between the fair value of the asset and its carrying value. Long-lived assets to be disposed of are reported at the lower of carrying amount or fair value less costs to sell.

[0000858877-26-000132:notes:36]
(n) Fair Value  Fair value is defined as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities required or permitted to be either recorded or disclosed at fair value, we consider the principal or most advantageous market in which we would transact, and we also consider assumptions that market participants would use when pricing the asset or liability.

[0000858877-26-000132:notes:37]
Assets and liabilities recorded at fair value are measured and classified in accordance with a three-tier fair value hierarchy based on the observability of the inputs available in the market to measure fair value:

[0000858877-26-000132:notes:38]
Level 1: observable inputs that reflect quoted prices in active markets for identical assets or liabilities.

[0000858877-26-000132:notes:39]
Level 2: inputs other than quoted prices that are observable for the asset or liability such as quoted prices for similar assets or liabilities in active markets; quoted prices for identical assets or liabilities in markets with insufficient volume or infrequent transactions (less active markets); or model-derived valuations in which significant inputs are observable or can be derived principally from, or corroborated by, observable market data. We use inputs such as actual trade data, benchmark yields, broker/dealer quotes, and other similar data, which are obtained from quoted market prices, independent pricing vendors, or other sources, to determine the ultimate fair value of assets or liabilities.

[0000858877-26-000132:notes:40]
Level 3: inputs are generally unobservable that are supported by little or no market data. The fair values are determined based on model-based techniques such as discounted cash flow models using inputs that we could not corroborate with market data.

[0000858877-26-000132:notes:41]
(o) Derivative Instruments  We recognize derivative instruments as either assets or liabilities and measure those instruments at fair value. The accounting for changes in the fair value of a derivative depends on the intended use of the derivative and the resulting designation. For a derivative instrument designated as a fair value hedge, the gain or loss is recognized in earnings in the period of change together with the offsetting loss or gain on the hedged item attributed to the risk being hedged. For a derivative instrument designated as a cash flow hedge, the gain or loss is initially reported as a component of AOCI and subsequently reclassified into earnings when the hedged exposure affects earnings. For a derivative instrument designated as a net investment hedge of our foreign operations, the gain or loss is recorded in the cumulative translation adjustment within AOCI together with the offsetting loss or gain of the hedged exposure of the underlying foreign operations. For derivative instruments that are not designated as accounting hedges, changes in fair value are recognized in earnings in the period of change. We record derivative instruments in the statements of cash flows to operating, investing, or financing activities consistent with the cash flows of the hedged item.

[0000858877-26-000132:notes:42]
Hedge effectiveness for foreign exchange forward contracts used as cash flow hedges is assessed by comparing the change in the fair value of the hedge contract with the change in the fair value of the forecasted cash flows of the hedged item. Hedge effectiveness for equity forward contracts and foreign exchange net investment hedge forward contracts is assessed by comparing changes in fair value due to changes in spot rates for both the derivative and the hedged item. For foreign exchange option contracts, hedge effectiveness is assessed based on the hedging instrument’s entire change in fair value. Hedge effectiveness for interest rate swaps is assessed by comparing the change in fair value of the swap with the change in the fair value of the hedged item due to changes in the benchmark interest rate.

[0000858877-26-000132:notes:43]
(p) Foreign Currency Translation  Assets and liabilities of non-U.S. subsidiaries that operate in a local currency environment, where that local currency is the functional currency, are translated to U.S. dollars at exchange rates in effect at the balance sheet date, with the resulting translation adjustments directly recorded to a separate component of AOCI. Income and expense accounts are translated at average exchange rates during the year. Remeasurement adjustments are recorded in other income (loss), net.

[0000858877-26-000132:notes:44]
(q) Concentrations of Risk  Cash and cash equivalents are maintained with several financial institutions. Deposits held with banks may exceed the amount of insurance provided on such deposits. Generally, these deposits may be redeemed upon demand and are maintained with financial institutions with reputable credit and therefore bear minimal credit risk. We seek to mitigate our credit risks by spreading such risks across multiple counterparties and monitoring the risk profiles of these counterparties.

[0000858877-26-000132:notes:45]
We perform ongoing credit evaluations of our customers and, with the exception of certain financing transactions, do not require collateral from our customers. We receive certain of our components from sole suppliers. Additionally, we rely on a limited number of contract manufacturers and suppliers to provide manufacturing services for our products. The inability of a contract manufacturer or supplier to fulfill our supply requirements could materially impact future operating results.

[0000858877-26-000132:notes:46]
(r) Revenue Recognition  We enter into contracts with customers that can include various combinations of products and services which are generally distinct and accounted for as separate performance obligations, resulting in contracts that may contain multiple performance obligations. We determine whether arrangements are distinct based on whether the customer can

[0000858877-26-000132:notes:47]
benefit from the product or service on its own or together with other resources that are readily available and whether our commitment to transfer the product or service to the customer is separately identifiable from other obligations in the contract. We classify our hardware, perpetual software licenses, and SaaS as distinct performance obligations. Term software licenses represent multiple obligations, which include software licenses and software maintenance. In transactions where we deliver hardware or software, we are typically the principal and we record revenue and costs of goods sold on a gross basis. We refer to our term software licenses, security software licenses, SaaS, and associated service arrangements as subscription offers. Revenue from subscription offers includes revenue recognized over time as well as upfront.

[0000858877-26-000132:notes:48]
We recognize revenue upon transfer of control of promised goods or services in a contract with a customer in an amount that reflects the consideration we expect to receive in exchange for those products or services. Transfer of control occurs once the customer has the contractual right to use the product, generally upon shipment, electronic delivery (or when the software is available for download by the customer), or once title and risk of loss has transferred to the customer. Transfer of control can also occur over time for software maintenance and services as the customer receives the benefit over the contract term. Our hardware and perpetual software licenses are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses include multiple performance obligations where the term licenses are recognized upfront upon transfer of control, with the associated software maintenance revenue recognized ratably over the contract term as services and software updates are provided. SaaS arrangements do not include the right for the customer to take possession of the software during the term, and therefore have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term as the customer consumes the services. On our product sales, we record consideration from shipping and handling on a gross basis within net product sales. We record our revenue net of any associated sales taxes.

[0000858877-26-000132:notes:49]
Revenue is allocated among these performance obligations in a manner that reflects the consideration that we expect to be entitled to for the promised goods or services based on standalone selling prices (SSP). SSP is estimated for each distinct performance obligation and judgment may be required in their determination. The best evidence of SSP is the observable price of a product or service when we sell the goods separately in similar circumstances and to similar customers. In instances where SSP is not directly observable, we determine SSP using information that may include market conditions and other observable inputs.

[0000858877-26-000132:notes:50]
We assess relevant contractual terms in our customer contracts to determine the transaction price. We apply judgment in identifying contractual terms and determining the transaction price as we may be required to estimate variable consideration when determining the amount of revenue to recognize. Variable consideration includes potential contractual penalties and various rebate, cooperative marketing and other incentive programs that we offer to our distributors, channel partners and direct sale customers. When determining the amount of revenue to recognize, we estimate the expected usage of these programs, applying the expected value or most likely estimate and update the estimate at each reporting period as actual utilization becomes available. We also consider the customers’ right of return in determining the transaction price, where applicable.

[0000858877-26-000132:notes:51]
We assess certain software licenses, such as for security software, that contain critical updates or upgrades which customers can download throughout the contract term. Without these updates or upgrades, the functionality of the software would diminish over a relatively short time period. These updates or upgrades provide the customer the full functionality of the purchased security software licenses and are required to maintain the security license’s utility as the risks and threats in the environment are rapidly changing. In these circumstances, the revenue from these software arrangements is recognized as a single performance obligation satisfied over the contract term.

[0000858877-26-000132:notes:52]
(s) Advertising Costs  We expense advertising costs as incurred. Advertising costs included within sales and marketing expenses were approximately $119 million, $186 million, and $210 million for fiscal 2026, 2025, and 2024, respectively.

[0000858877-26-000132:notes:53]
(t) Share-Based Compensation Expense  We measure and recognize the compensation expense for all share-based awards made to employees and directors, including restricted stock units (RSUs), performance-based restricted stock units (PRSUs), employee stock purchases related to the Employee Stock Purchase Plan (Employee Stock Purchase Rights) and employee stock options based on estimated fair values. Share-based compensation expense is reduced for forfeitures as they occur.

[0000858877-26-000132:notes:54]
(u) Software Development Costs  Software development costs, including costs to develop software sold, leased, or otherwise marketed, that are incurred subsequent to the establishment of technological feasibility are capitalized. Costs incurred during the application development stage for internal-use software and cloud-based applications are capitalized. Such software development costs capitalized during the periods presented were not material.

[0000858877-26-000132:notes:55]
(v) Income Taxes  Income tax expense is based on pretax financial accounting income. Deferred tax assets and liabilities are recognized for the expected tax consequences of temporary differences between the tax bases of assets and liabilities and their reported amounts. Valuation allowances are recorded to reduce deferred tax assets to the amount that will more likely than not be realized.

[0000858877-26-000132:notes:56]
We account for uncertainty in income taxes using a two-step approach to recognizing and measuring uncertain tax positions. The first step is to evaluate the tax position for recognition by determining if the weight of available evidence indicates that it is more likely than not that the position will be sustained on audit, including resolution of related appeals or litigation processes, if any. The second step is to measure the tax benefit as the largest amount that is more than 50% likely of being realized upon settlement. We classify the liability for unrecognized tax benefits as current to the extent that we anticipate payment (or receipt) of cash within one year. Interest and penalties related to uncertain tax positions are recognized in the provision for income taxes.

[0000858877-26-000132:notes:57]
(w) Computation of Net Income per Share  Basic net income per share is computed using the weighted-average number of common shares outstanding during the period. Diluted net income per share is computed using the weighted-average number of common shares and dilutive potential common shares outstanding during the period. Diluted shares outstanding includes the dilutive effect of in-the-money options, unvested restricted stock, and restricted stock units. The dilutive effect of such equity awards is calculated based on the average share price for each fiscal period using the treasury stock method. Under the treasury stock method, the amount the employee must pay for exercising stock options and the amount of compensation cost for future service that we have not yet recognized are collectively assumed to be used to repurchase shares.

[0000858877-26-000132:notes:58]
(x) Consolidation of Variable Interest Entities  Our approach in assessing the consolidation requirement for variable interest entities focuses on identifying which enterprise has the power to direct the activities that most significantly impact the variable interest entity’s economic performance and which enterprise has the obligation to absorb losses or the right to receive benefits from the variable interest entity. Should we conclude that we are the primary beneficiary of a variable interest entity, the assets, liabilities, and results of operations of the variable interest entity will be included in our Consolidated Financial Statements.

[0000858877-26-000132:notes:59]
(y) Use of Estimates  The preparation of financial statements and related disclosures in conformity with accounting principles generally accepted in the United States requires management to make estimates and judgments that affect the amounts reported in the Consolidated Financial Statements and accompanying notes. Estimates are used for the following, among others:

[0000858877-26-000132:notes:60]
•Revenue recognition

[0000858877-26-000132:notes:61]
•Allowances for accounts receivable and financing receivables

[0000858877-26-000132:notes:62]
•Inventory valuation and liability for purchase commitments with contract manufacturers and suppliers

[0000858877-26-000132:notes:63]
•Loss contingencies and product warranties

[0000858877-26-000132:notes:64]
•Fair value measurements

[0000858877-26-000132:notes:65]
•Valuation of non-marketable equity securities

[0000858877-26-000132:notes:66]
•Valuation of goodwill and purchased intangible assets

[0000858877-26-000132:notes:67]
•Income taxes

[0000858877-26-000132:notes:68]
The actual results that we experience may differ materially from our estimates.

[0000858877-26-000132:notes:69]
(z) Recent Accounting Updates Recently Adopted

[0000858877-26-000132:notes:70]
Improvements on Income Tax Disclosures  In December 2023, the Financial Accounting Standards Board (FASB) issued an accounting standard update that expands the requirements for disclosure of disaggregated information about the effective tax rate reconciliation and income taxes paid. We adopted this accounting standard update on a prospective basis for our fiscal 2026 Form 10-K. See Note 17.

[0000858877-26-000132:notes:71]
(aa) Recent Accounting Standards or Updates Not Yet Effective as of Fiscal Year End

[0000858877-26-000132:notes:72]
Disaggregation of Income Statement Expenses  In November 2024, the FASB issued an accounting standard update expanding the disclosure requirements about specific expense categories, primarily through disaggregated information on income statement line items. The accounting standard update will be effective for our fiscal 2028 Form 10-K, and early adoption is permitted. We are currently evaluating the impact of this accounting standard update on our Consolidated Financial Statements.

[0000858877-26-000132:notes:73]
Targeted Improvements to the Accounting for Internal-Use Software  In September 2025, the FASB issued an accounting standard update to modernize the accounting for internal-use software costs and clarify the criteria for capitalization. The accounting standard update will be effective for our interim and annual reporting periods of fiscal 2029, with early adoption permitted. We are currently evaluating the impact of this accounting standard update on our Consolidated Financial Statements.


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0000858877-26-000132:notes:74]
Depreciation and amortization are computed using the straight-line method, generally over the following periods:

[0000858877-26-000132:notes:75]
Property and Equipment, Net

[0000858877-26-000132:notes:76]
|  |  | July 25, 2026 |  | July 26, 2025 |
| Gross property and equipment: |  |  |  |  |
| Land, buildings, and building and leasehold improvements |  | $ | 4,093 |  |  | $ | 4,045 |  |
| Production, engineering, computer and other equipment and related software |  | 5,441 |  |  | 5,178 |  |
| Operating lease assets |  | 51 |  |  | 51 |  |
| Furniture, fixtures and other |  | 287 |  |  | 316 |  |
| Total gross property and equipment |  | 9,872 |  |  | 9,590 |  |
| Less: accumulated depreciation and amortization |  | (7,112) |  |  | (7,477) |  |
| Total |  | $ | 2,760 |  |  | $ | 2,113 |  |


## us-gaap:DerivativesPolicyTextBlock

[0000858877-26-000132:notes:77]
(o) Derivative Instruments  We recognize derivative instruments as either assets or liabilities and measure those instruments at fair value. The accounting for changes in the fair value of a derivative depends on the intended use of the derivative and the resulting designation. For a derivative instrument designated as a fair value hedge, the gain or loss is recognized in earnings in the period of change together with the offsetting loss or gain on the hedged item attributed to the risk being hedged. For a derivative instrument designated as a cash flow hedge, the gain or loss is initially reported as a component of AOCI and subsequently reclassified into earnings when the hedged exposure affects earnings. For a derivative instrument designated as a net investment hedge of our foreign operations, the gain or loss is recorded in the cumulative translation adjustment within AOCI together with the offsetting loss or gain of the hedged exposure of the underlying foreign operations. For derivative instruments that are not designated as accounting hedges, changes in fair value are recognized in earnings in the period of change. We record derivative instruments in the statements of cash flows to operating, investing, or financing activities consistent with the cash flows of the hedged item.
Hedge effectiveness for foreign exchange forward contracts used as cash flow hedges is assessed by comparing the change in the fair value of the hedge contract with the change in the fair value of the forecasted cash flows of the hedged item. Hedge effectiveness for equity forward contracts and foreign exchange net investment hedge forward contracts is assessed by comparing changes in fair value due to changes in spot rates for both the derivative and the hedged item. For foreign exchange option contracts, hedge effectiveness is assessed based on the hedging instrument’s entire change in fair value. Hedge effectiveness for interest rate swaps is assessed by comparing the change in fair value of the swap with the change in the fair value of the hedged item due to changes in the benchmark interest rate.
We use derivative instruments primarily to manage exposures to foreign currency exchange rate, interest rate, and equity price risks. Our primary objective in holding derivatives is to reduce the volatility of earnings and cash flows associated with changes in foreign currency exchange rates, interest rates, and equity prices. Our derivatives expose us to credit risk to the extent that the counterparties may be unable to meet the terms of the agreement. We seek to mitigate such risks by limiting our counterparties to major financial institutions and requiring collateral in certain cases. In addition, the potential risk of loss with any one counterparty resulting from credit risk is monitored. Management does not expect material losses as a result of defaults by counterparties.


## us-gaap:RevenueFromContractWithCustomerPolicyTextBlock

[0000858877-26-000132:notes:78]
Observability consists of our observability suite and network assurance offerings. These products consist primarily of software offerings, including software licenses and SaaS. Our perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

[0000858877-26-000132:notes:79]
In addition to our product offerings, we provide a broad range of service and support options for our customers, including technical support services and professional services. Technical support services represent the majority of these offerings which are distinct performance obligations that are satisfied over time with revenue recognized ratably over the contract term. Professional services are distinct performance obligations that are satisfied over time with revenue recognized as services are delivered.

[0000858877-26-000132:notes:80]
The sales arrangements as discussed above are typically made pursuant to customer purchase orders based on master purchase or partner agreements. Cash is received based on our standard payment terms which is typically 30 days. We provide financing arrangements to customers for our hardware, software and service offerings. Refer to Note 9 for additional information. For these arrangements, cash is typically received over time.
Subscription revenue includes revenue recognized from our term software licenses, security software licenses, SaaS, and associated service arrangements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000858877-26-000132:notes:81]
Revenue
(a)Disaggregation of Revenue

[0000858877-26-000132:notes:82]
We disaggregate our revenue into groups of similar products and services that depict the nature, amount, and timing of revenue and cash flows for our various offerings. The sales cycle, contractual obligations, customer requirements, and go-to-market strategies differ for each of our product categories, resulting in different economic risk profiles for each category.

[0000858877-26-000132:notes:83]
The following table presents this disaggregation of revenue (in millions):

[0000858877-26-000132:notes:84]
| Years Ended | July 25, 2026 |  | July 26, 2025 |  | July 27, 2024 |
| Product revenue: |  |  |  |  |  |
| Networking | $ | 34,668 |  |  | $ | 28,304 |  |  | $ | 29,229 |  |
| Security | 8,232 |  |  | 8,094 |  |  | 5,075 |  |
| Collaboration | 4,300 |  |  | 4,154 |  |  | 4,113 |  |
| Observability | 1,095 |  |  | 1,055 |  |  | 837 |  |
| Total Product | 48,295 |  |  | 41,608 |  |  | 39,253 |  |
| Services | 15,030 |  |  | 15,046 |  |  | 14,550 |  |
| Total revenue | $ | 63,325 |  |  | $ | 56,654 |  |  | $ | 53,803 |  |

[0000858877-26-000132:notes:85]
Amounts may not sum due to rounding.

[0000858877-26-000132:notes:86]
Networking consists of our core networking technologies of switching, routing, wireless, and servers. These technologies consist of both hardware and software offerings, including software licenses and SaaS. Our hardware and perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

[0000858877-26-000132:notes:87]
Security consists of our Network Security, Identity and Access Management, SASE, and Identity and Agentic Security offerings. These products consist of both hardware and software offerings, including software licenses and SaaS. Updates and upgrades for the term software licenses are critical for our software to perform its intended commercial purpose because of the continuous need for our software to secure our customers’ network environments against frequent threats. Therefore, security software licenses are generally represented by a single distinct performance obligation with revenue recognized ratably over the contract term. Our hardware and perpetual software in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

[0000858877-26-000132:notes:88]
Collaboration consists of our Webex Suite, Collaboration Devices, Contact Center and CPaaS offerings. These products consist primarily of software offerings, including software licenses and SaaS, as well as hardware. Our perpetual software and hardware in this category are distinct performance obligations where revenue is recognized upfront upon transfer of control. Term software licenses are multiple performance obligations where the term license is recognized upfront upon transfer of control with the associated software maintenance revenue recognized ratably over the contract term. SaaS arrangements in this category have one distinct performance obligation which is satisfied over time with revenue recognized ratably over the contract term.

[0000858877-26-000132:notes:89]
The sales arrangements as discussed above are typically made pursuant to customer purchase orders based on master purchase or partner agreements. Cash is received based on our standard payment terms which is typically 30 days. We provide financing arrangements to customers for our hardware, software and service offerings. Refer to Note 9 for additional information. For these arrangements, cash is typically received over time.

[0000858877-26-000132:notes:90]
Subscription revenue includes revenue recognized from our term software licenses, security software licenses, SaaS, and associated service arrangements. Our subscription revenue is recorded in product and services revenue in our Consolidated Statements of Operations as follows (in millions):

[0000858877-26-000132:notes:91]
| Years Ended | July 25, 2026 |  | July 26, 2025 |  | July 27, 2024 |
| Product | $ | 18,314 |  |  | $ | 17,783 |  |  | $ | 14,078 |  |
| Services | 13,663 |  |  | 13,743 |  |  | 13,302 |  |
| Total | $ | 31,977 |  |  | $ | 31,526 |  |  | $ | 27,380 |  |

[0000858877-26-000132:notes:92]
The majority of our product subscription revenue is recognized over time and the remainder is recognized upfront. Substantially all of our services subscription revenue is recognized over time based on the contract term.

[0000858877-26-000132:notes:93]
(b)Contract Balances

[0000858877-26-000132:notes:94]
Accounts Receivable

[0000858877-26-000132:notes:95]
Accounts receivable, net was $7.5 billion as of July 25, 2026 compared to $6.7 billion as of July 26, 2025, as reported on the Consolidated Balance Sheets. We had a global channel partner that accounted for approximately 15% of accounts receivable as of July 25, 2026.

[0000858877-26-000132:notes:96]
The allowances for credit loss for our accounts receivable are summarized as follows (in millions):

[0000858877-26-000132:notes:97]
|  |  | July 25, 2026 |  | July 26, 2025 |  | July 27, 2024 |
| Allowance for credit loss at beginning of fiscal year |  | $ | 69 |  |  | $ | 87 |  |  | $ | 85 |  |
| Provisions |  | 24 |  |  | 33 |  |  | 36 |  |
| Write-offs, net of recoveries |  | (15) |  |  | (51) |  |  | (34) |  |
| Allowance for credit loss at end of fiscal year |  | $ | 78 |  |  | $ | 69 |  |  | $ | 87 |  |

[0000858877-26-000132:notes:98]
Contract Assets and Liabilities

[0000858877-26-000132:notes:99]
Gross contract assets by our internal risk ratings are summarized as follows (in millions):

[0000858877-26-000132:notes:100]
|  | July 25, 2026 |  | July 26, 2025 |
| 1 to 4 | $ | 1,355 |  |  | $ | 1,358 |  |
| 5 to 6 | 2,015 |  |  | 1,868 |  |
| 7 and Higher | 99 |  |  | 73 |  |
| Total | $ | 3,469 |  |  | $ | 3,299 |  |

[0000858877-26-000132:notes:101]
Contract assets consist of unbilled receivables and are recorded when revenue is recognized in advance of scheduled billings to our customers. These amounts are primarily related to software and service arrangements where transfer of control has occurred but we have not yet invoiced. As of July 25, 2026 and July 26, 2025, our contract assets for these unbilled receivables, net of allowances, were $3.4 billion and $3.2 billion, respectively, of which $1.9 billion and $1.7 billion, respectively, were included in other current assets, with remaining balances included in other assets.

[0000858877-26-000132:notes:102]
Contract liabilities consist of deferred revenue. Deferred revenue was $29.8 billion as of July 25, 2026 compared to $28.8 billion as of July 26, 2025. We recognized approximately $16.4 billion of revenue during fiscal 2026 that was included in the deferred revenue balance at July 26, 2025.

[0000858877-26-000132:notes:103]
(c)Capitalized Contract Acquisition Costs

[0000858877-26-000132:notes:104]
We capitalize direct and incremental costs incurred to acquire contracts, primarily sales commissions, for which the associated revenue is expected to be recognized in future periods. We incur these costs in connection with both initial contracts and renewals. These costs are initially deferred and typically amortized over the term of the customer contract which corresponds to the period of benefit. Capitalized contract acquisition costs were $1.5 billion as of each of July 25, 2026 and July 26, 2025, and were included in other current assets and other assets. The amortization expense associated with these costs was $942 million,

[0000858877-26-000132:notes:105]
$957 million, and $742 million for fiscal 2026, 2025, and 2024, respectively, and was included in sales and marketing expenses.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0000858877-26-000132:notes:106]
Our subscription revenue is recorded in product and services revenue in our Consolidated Statements of Operations as follows (in millions):

[0000858877-26-000132:notes:107]
The following table presents revenue for groups of similar products and services (in millions):

[0000858877-26-000132:notes:108]
| Years Ended | July 25, 2026 |  | July 26, 2025 |  | July 27, 2024 |
| Revenue: |  |  |  |  |  |
| Networking | $ | 34,668 |  |  | $ | 28,304 |  |  | $ | 29,229 |  |
| Security | 8,232 |  |  | 8,094 |  |  | 5,075 |  |
| Collaboration | 4,300 |  |  | 4,154 |  |  | 4,113 |  |
| Observability | 1,095 |  |  | 1,055 |  |  | 837 |  |
| Total Product | 48,295 |  |  | 41,608 |  |  | 39,253 |  |
| Services | 15,030 |  |  | 15,046 |  |  | 14,550 |  |
| Total | $ | 63,325 |  |  | $ | 56,654 |  |  | $ | 53,803 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000858877-26-000132:notes:109]
Acquisitions 
(a)Acquisitions Summary

[0000858877-26-000132:notes:110]
Fiscal 2026 Acquisitions

[0000858877-26-000132:notes:111]
Allocation of the total purchase consideration for acquisitions we completed during fiscal 2026 is summarized as follows (in millions):

[0000858877-26-000132:notes:112]
| Fiscal 2026 | Purchase Consideration |  | Net Tangible Assets Acquired (Liabilities Assumed) |  | Purchased Intangible Assets |  | Goodwill |
| Total acquisitions | $ | 550 |  |  | $ | 10 |  |  | $ | 190 |  |  | $ | 350 |  |

[0000858877-26-000132:notes:113]
The total purchase consideration for acquisitions we completed during fiscal 2026 consisted primarily of cash consideration. The total cash and cash equivalents acquired from these acquisitions was approximately $30 million.

[0000858877-26-000132:notes:114]
The purchase price allocation for acquisitions completed during fiscal 2026 is preliminary and subject to revision as additional information about fair value of assets and liabilities becomes available. Additional information that existed as of the acquisition date but is currently unknown to us may become known during the remainder of the measurement period, a period not to exceed 12 months from the acquisition date.

[0000858877-26-000132:notes:115]
Fiscal 2025 Acquisitions

[0000858877-26-000132:notes:116]
Allocation of the total purchase consideration for acquisitions we completed during fiscal 2025 is summarized as follows (in millions):

[0000858877-26-000132:notes:117]
| Fiscal 2025 | Purchase Consideration |  | Net Tangible Assets Acquired (Liabilities Assumed) |  | Purchased Intangible Assets |  | Goodwill |
| Total acquisitions | $ | 293 |  |  | $ | (21) |  |  | $ | 121 |  |  | $ | 193 |  |

[0000858877-26-000132:notes:118]
The total purchase consideration related to our acquisitions completed during fiscal 2025 consisted primarily of cash consideration. The total cash and cash equivalents acquired from these acquisitions was approximately $15 million.

[0000858877-26-000132:notes:119]
Fiscal 2024 Acquisitions

[0000858877-26-000132:notes:120]
Allocation of the total purchase consideration for acquisitions we completed during fiscal 2024 is summarized as follows (in millions):

[0000858877-26-000132:notes:121]
| Fiscal 2024 | Purchase Consideration |  | Net Tangible Assets Acquired (Liabilities Assumed) |  | Purchased Intangible Assets |  | Goodwill |
| Splunk | $ | 27,090 |  |  | $ | (2,761) |  |  | $ | 10,550 |  |  | $ | 19,301 |  |
| Other acquisitions | 1,370 |  |  | (47) |  |  | 500 |  |  | 917 |  |
| Total acquisitions | $ | 28,460 |  |  | $ | (2,808) |  |  | $ | 11,050 |  |  | $ | 20,218 |  |

[0000858877-26-000132:notes:122]
Acquisition of Splunk Inc.

[0000858877-26-000132:notes:123]
On March 18, 2024, we completed the acquisition of Splunk Inc. (“Splunk”), a public cybersecurity and observability company. Under the terms of the agreement, we agreed to pay $157 per share in cash, representing approximately $27 billion in merger consideration. The total purchase consideration was allocated to $19.3 billion of goodwill, $10.6 billion of purchased intangible assets and $2.8 billion of net liabilities.

[0000858877-26-000132:notes:124]
Our Consolidated Statements of Operations for fiscal 2024 includes revenue of approximately $1.4 billion and a net loss of $557 million attributable to Splunk since the date of acquisition.

[0000858877-26-000132:notes:125]
We incurred $82 million of transaction costs related to the Splunk acquisition and these costs were expensed as incurred in G&A in the Consolidated Statements of Operations. We incurred $79 million of these transaction costs in fiscal 2024.

[0000858877-26-000132:notes:126]
The goodwill generated from Splunk is primarily related to expected synergies. Goodwill is not deductible for income tax purposes.

[0000858877-26-000132:notes:127]
Pro forma Financial Information

[0000858877-26-000132:notes:128]
The unaudited pro forma financial information in the table below summarizes the combined results of our operations and Splunk’s operations, as though the acquisition of Splunk had been completed as of the beginning of fiscal 2024. The pro forma financial information for fiscal 2024 combines our results for this period with the results of Splunk for the period beginning August 1, 2023 through July 27, 2024.

[0000858877-26-000132:notes:129]
The following table summarizes the pro forma financial information (in millions):

[0000858877-26-000132:notes:130]
| Year Ended | July 27, 2024 |
| Total revenue | $ | 56,761 |  |
| Net income | $ | 9,280 |  |

[0000858877-26-000132:notes:131]
The pro forma financial information is presented for informational purposes only and is not indicative of the results of operations that would have been achieved if the acquisition and the cost of financing the acquisition had taken place at the beginning of fiscal 2024. The financial information for the periods presented above includes pro forma adjustments for amortization of purchased intangible assets, costs related to financing the acquisition and transaction costs.

[0000858877-26-000132:notes:132]
(b)Compensation Expense Related to Acquisitions

[0000858877-26-000132:notes:133]
In connection with our acquisitions, we have agreed to pay certain additional amounts contingent upon the continued employment with Cisco of certain employees of the acquired entities.

[0000858877-26-000132:notes:134]
The following table summarizes the compensation expense related to acquisitions (in millions):

[0000858877-26-000132:notes:135]
|  | July 25, 2026 |  | July 26, 2025 |  | July 27, 2024 |
| Compensation expense related to acquisitions | $ | 360 |  |  | $ | 876 |  |  | $ | 618 |  |

[0000858877-26-000132:notes:136]
As of July 25, 2026, we estimated that future cash compensation expense of up to $293 million may be required to be recognized pursuant to applicable acquisition agreements.

[0000858877-26-000132:notes:137]
(c)Other Acquisition and Divestiture Information

[0000858877-26-000132:notes:138]
Total transaction costs related to acquisition and divestiture activities during fiscal 2026, 2025, and 2024, inclusive of Splunk, were $18 million, $12 million and $104 million, respectively. These transaction costs were expensed as incurred in G&A in the Consolidated Statements of Operations.

[0000858877-26-000132:notes:139]
The goodwill generated from acquisitions completed during fiscal 2026, 2025, and 2024 is primarily related to expected synergies. The goodwill is generally not deductible for income tax purposes.

[0000858877-26-000132:notes:140]
The Consolidated Financial Statements include the operating results of each acquisition from the date of acquisition. Pro forma results of operations and the revenue and net income subsequent to the acquisition date for the acquisitions completed during fiscal 2026, 2025, and 2024, with the exception of Splunk, have not been presented because the effects of the acquisitions were not material to our financial results.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000858877-26-000132:notes:141]
Goodwill and Purchased Intangible Assets 
(a)Goodwill

[0000858877-26-000132:notes:142]
The following tables present the goodwill allocated to our reportable segments as of July 25, 2026 and July 26, 2025, as well as the changes to goodwill during fiscal 2026 and 2025 (in millions):

[0000858877-26-000132:notes:143]
|  | Balance at July 26, 2025 |  | Acquisitions |  | Foreign Currency Translation and Other |  | Balance at July 25, 2026 |
| Americas | $ | 36,468 |  |  | $ | 224 |  |  | $ | (6) |  |  | $ | 36,686 |  |
| EMEA | 14,397 |  |  | 87 |  |  | (2) |  |  | 14,482 |  |
| APJC | 8,271 |  |  | 39 |  |  | (1) |  |  | 8,309 |  |
| Total | $ | 59,136 |  |  | $ | 350 |  |  | $ | (9) |  |  | $ | 59,477 |  |

[0000858877-26-000132:notes:144]
|  | Balance at July 27, 2024 |  | Acquisitions, net of Divestitures |  | Foreign Currency Translation and Other |  | Balance at July 26, 2025 |
| Americas | $ | 36,169 |  |  | $ | 121 |  |  | $ | 178 |  |  | $ | 36,468 |  |
| EMEA | 14,283 |  |  | 47 |  |  | 67 |  |  | 14,397 |  |
| APJC | 8,208 |  |  | 23 |  |  | 40 |  |  | 8,271 |  |
| Total | $ | 58,660 |  |  | $ | 191 |  |  | $ | 285 |  |  | $ | 59,136 |  |

[0000858877-26-000132:notes:145]
(b)Purchased Intangible Assets

[0000858877-26-000132:notes:146]
The following tables present details of our intangible assets acquired through acquisitions completed during fiscal 2026 and 2025 (in millions, except years):

[0000858877-26-000132:notes:147]
|  | FINITE LIVES |  | TOTAL |
|  | CUSTOMER RELATED |  | TECHNOLOGY |  |
| Fiscal 2026 | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Amount |
| Total acquisitions | 1.0 |  | $ | 5 |  |  | 3.9 |  | $ | 185 |  |  | $ | 190 |  |

[0000858877-26-000132:notes:148]
|  | FINITE LIVES |  | TOTAL |
|  | CUSTOMER RELATED |  | TECHNOLOGY |  |
| Fiscal 2025 | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Amount |
| Total acquisitions | 3.5 |  | $ | 16 |  |  | 3.8 |  | $ | 105 |  |  | $ | 121 |  |

[0000858877-26-000132:notes:149]
The following tables present details of our purchased intangible assets with finite lives (in millions):

[0000858877-26-000132:notes:150]
| July 25, 2026 |  | Gross |  | Accumulated Amortization |  | Net |
| Customer related |  | $ | 6,243 |  |  | $ | (2,038) |  |  | $ | 4,205 |  |
| Technology |  | 5,067 |  |  | (2,124) |  |  | 2,943 |  |
| Trade name |  | 510 |  |  | (101) |  |  | 409 |  |
| Total |  | $ | 11,820 |  |  | $ | (4,263) |  |  | $ | 7,557 |  |

[0000858877-26-000132:notes:151]
| July 26, 2025 |  | Gross |  | Accumulated Amortization |  | Net |
| Customer related |  | $ | 6,341 |  |  | $ | (1,268) |  |  | $ | 5,073 |  |
| Technology |  | 5,254 |  |  | (1,606) |  |  | 3,648 |  |
| Trade name |  | 526 |  |  | (72) |  |  | 454 |  |
| Total |  | $ | 12,121 |  |  | $ | (2,946) |  |  | $ | 9,175 |  |

[0000858877-26-000132:notes:152]
Purchased intangible assets include intangible assets acquired through acquisitions as well as through direct purchases or licenses.

[0000858877-26-000132:notes:153]
Impairment charges related to purchased intangible assets were $145 million for fiscal 2024. Impairment charges were as a result of declines in estimated fair value resulting from the reductions in or the elimination of expected future cash flows associated with certain in-process research and development and technology intangible assets. The fair value for purchased intangible assets measured at fair value on a nonrecurring basis was categorized as Level 3 due to the use of significant unobservable inputs in the valuation. Significant unobservable inputs that were used included expected revenues and net income related to the assets and the expected life of the assets. The difference between the estimated fair value and the carrying value of the assets was recorded as an impairment charge, which was included in product cost of sales.

[0000858877-26-000132:notes:154]
The following table presents the amortization of purchased intangible assets, including impairment charges (in millions):

[0000858877-26-000132:notes:155]
| Years Ended |  | July 25, 2026 |  | July 26, 2025 |  | July 27, 2024 |
| Amortization of purchased intangible assets: |  |  |  |  |  |  |
| Cost of sales |  | $ | 947 |  |  | $ | 1,174 |  |  | $ | 955 |  |
| Operating expenses |  | 916 |  |  | 1,028 |  |  | 698 |  |
| Total |  | $ | 1,863 |  |  | $ | 2,202 |  |  | $ | 1,653 |  |

[0000858877-26-000132:notes:156]
The estimated future amortization expense of purchased intangible assets with finite lives as of July 25, 2026 is as follows (in millions):

[0000858877-26-000132:notes:157]
| Fiscal Year | Amount |
| 2027 | $ | 1,534 |  |
| 2028 | 1,451 |  |
| 2029 | 1,329 |  |
| 2030 | 1,040 |  |
| 2031 | 586 |  |
| Thereafter | 1,617 |  |
| Total | $ | 7,557 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000858877-26-000132:notes:158]
Restructuring and Other Charges
In the fourth quarter of fiscal 2026, we announced a restructuring plan (the “Fiscal 2026 Plan”) to allow us to invest in key growth opportunities including silicon, optics, security and AI. The total pre-tax charges are estimated to be up to $1 billion consisting of severance and other one-time termination benefits, and other costs. In connection with the Fiscal 2026 Plan, we incurred charges of $511 million in fiscal 2026. The aggregate pre-tax charges are primarily cash-based and consist of severance and other one-time termination benefits, and other costs. We expect this plan to be substantially completed by the end of fiscal 2027.

[0000858877-26-000132:notes:159]
We initiated a restructuring plan in fiscal 2025 (the “Fiscal 2025 Plan”), in order to allow us to invest in key growth opportunities and drive more efficiencies in our business. In connection with the Fiscal 2025 Plan, we incurred charges of $182 million in fiscal 2026. The aggregate pre-tax charges were primarily cash-based and consisted of severance and other one-time termination benefits, and other costs. In connection with the Fiscal 2025 Plan, we incurred cumulative charges of $926 million and the plan is substantially complete.

[0000858877-26-000132:notes:160]
We initiated a restructuring plan in fiscal 2024 (the “Fiscal 2024 Plan”), in order to realign the organization and enable further investment in key priority areas. In connection with the Fiscal 2024 Plan, we incurred cumulative charges of $654 million and

[0000858877-26-000132:notes:161]
the plan is complete. The aggregate pretax charges related to this plan were primarily cash-based and consisted of severance and other one-time termination benefits and other costs.

[0000858877-26-000132:notes:162]
The following table summarizes the activities related to our restructuring liability, which was included in other current liabilities on our Consolidated Balance Sheets (in millions):

[0000858877-26-000132:notes:163]
|  |  | FISCAL 2026 PLAN |  | FISCAL 2025 AND PRIOR PLANS |  |  |
|  |  | Employee Severance |  | Other |  | EmployeeSeverance |  | Other |  | Total |
| Liability as of July 29, 2023 |  | $ | — |  |  | $ | — |  |  | $ | 167 |  |  | $ | 46 |  |  | $ | 213 |  |
| Charges |  | — |  |  | — |  |  | 731 |  |  | 58 |  |  | 789 |  |
| Cash payments |  | — |  |  | — |  |  | (677) |  |  | (14) |  |  | (691) |  |
| Non-cash and other |  | — |  |  | — |  |  | — |  |  | (37) |  |  | (37) |  |
| Liability as of July 27, 2024 |  | — |  |  | — |  |  | 221 |  |  | 53 |  |  | 274 |  |
| Charges |  | — |  |  | — |  |  | 617 |  |  | 127 |  |  | 744 |  |
| Cash payments |  | — |  |  | — |  |  | (752) |  |  | (18) |  |  | (770) |  |
| Non-cash and other |  | — |  |  | — |  |  | 2 |  |  | (103) |  |  | (101) |  |
| Liability as of July 26, 2025 |  | — |  |  | — |  |  | 88 |  |  | 59 |  |  | 147 |  |
| Charges |  | 450 |  |  | 61 |  |  | 142 |  |  | 40 |  |  | 693 |  |
| Cash payments |  | (154) |  |  | (1) |  |  | (178) |  |  | (32) |  |  | (365) |  |
| Non-cash and other |  | — |  |  | (54) |  |  | (3) |  |  | (38) |  |  | (95) |  |
| Liability as of July 25, 2026 |  | $ | 296 |  |  | $ | 6 |  |  | $ | 49 |  |  | $ | 29 |  |  | $ | 380 |  |


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000858877-26-000132:notes:164]
Balance Sheet and Other Details 
The following tables provide details of selected balance sheet and other items (in millions, except percentages):

[0000858877-26-000132:notes:165]
Cash, Cash Equivalents, Restricted Cash and Restricted Cash Equivalents

[0000858877-26-000132:notes:166]
|  |  | July 25, 2026 |  | July 26, 2025 |
| Cash and cash equivalents |  | $ | 7,218 |  |  | $ | 8,346 |  |
| Restricted cash and restricted cash equivalents included in other current assets |  | 9 |  |  | 564 |  |
| Total |  | $ | 7,227 |  |  | $ | 8,910 |  |

[0000858877-26-000132:notes:167]
In the table above, our restricted cash and restricted cash equivalents are funds primarily related to contractual obligations with suppliers.

[0000858877-26-000132:notes:168]
Inventories

[0000858877-26-000132:notes:169]
|  |  | July 25, 2026 |  | July 26, 2025 |
| Raw materials |  | $ | 2,796 |  |  | $ | 1,744 |  |
| Work in process |  | 1,140 |  |  | 261 |  |
| Finished goods |  | 1,525 |  |  | 933 |  |
| Service-related spares |  | 224 |  |  | 220 |  |
| Demonstration systems |  | 9 |  |  | 6 |  |
| Total |  | $ | 5,694 |  |  | $ | 3,164 |  |

[0000858877-26-000132:notes:170]
Remaining Performance Obligations (RPO)

[0000858877-26-000132:notes:171]
|  |  | July 25, 2026 |  | July 26, 2025 |
| Product |  | $ | 23,436 |  |  | $ | 21,572 |  |
| Services |  | 23,298 |  |  | 21,961 |  |
| Total |  | $ | 46,734 |  |  | $ | 43,533 |  |
| Short-term RPO |  | $ | 22,776 |  |  | $ | 21,723 |  |
| Long-term RPO |  | 23,958 |  |  | 21,810 |  |
| Total |  | $ | 46,734 |  |  | $ | 43,533 |  |
| Deferred revenue |  | $ | 29,781 |  |  | $ | 28,779 |  |
| Unbilled contract revenue |  | 16,953 |  |  | 14,754 |  |
| Total |  | $ | 46,734 |  |  | $ | 43,533 |  |

[0000858877-26-000132:notes:172]
RPO is comprised of deferred revenue plus unbilled contract revenue. Unbilled contract revenue represents noncancelable contracts, primarily subscription arrangements, for which we have not invoiced, have an obligation to perform, and revenue has not yet been recognized in the financial statements.

[0000858877-26-000132:notes:173]
As of July 25, 2026, we expect to recognize approximately 49% of total remaining performance obligations as revenue over the next 12 months, approximately 39% between one year and three years, and approximately 12% thereafter.

[0000858877-26-000132:notes:174]
Deferred Revenue

[0000858877-26-000132:notes:175]
|  |  | July 25, 2026 |  | July 26, 2025 |
| Product |  | $ | 13,817 |  |  | $ | 13,490 |  |
| Services |  | 15,964 |  |  | 15,289 |  |
| Total |  | $ | 29,781 |  |  | $ | 28,779 |  |
| Reported as: |  |  |  |  |
| Current |  | $ | 16,988 |  |  | $ | 16,416 |  |
| Noncurrent |  | 12,793 |  |  | 12,363 |  |
| Total |  | $ | 29,781 |  |  | $ | 28,779 |  |


## us-gaap:OperatingLeasesOfLessorDisclosureTextBlock

[0000858877-26-000132:notes:176]
Leases
(a)Lessee Arrangements

[0000858877-26-000132:notes:177]
The following table presents our operating lease balances (in millions):

[0000858877-26-000132:notes:178]
|  | Balance Sheet Line Item |  | July 25, 2026 |  | July 26, 2025 |
| Operating lease ROU assets | Other assets |  | $ | 1,395 |  |  | $ | 1,301 |  |
| Operating lease liabilities | Other current liabilities |  | $ | 404 |  |  | $ | 375 |  |
| Operating lease liabilities | Other long-term liabilities |  | 1,248 |  |  | 1,175 |  |
| Total operating lease liabilities |  |  | $ | 1,652 |  |  | $ | 1,550 |  |

[0000858877-26-000132:notes:179]
The components of our lease expenses were as follows (in millions):

[0000858877-26-000132:notes:180]
| Years Ended |  | July 25, 2026 |  | July 26, 2025 |  | July 27, 2024 |
| Operating lease expense |  | $ | 536 |  |  | $ | 495 |  |  | $ | 420 |  |
| Short-term lease expense |  | 103 |  |  | 77 |  |  | 75 |  |
| Variable lease expense |  | 326 |  |  | 191 |  |  | 194 |  |
| Total lease expense |  | $ | 965 |  |  | $ | 763 |  |  | $ | 689 |  |

[0000858877-26-000132:notes:181]
Supplemental information related to our operating leases is as follows (in millions):

[0000858877-26-000132:notes:182]
| Years Ended |  | July 25, 2026 |  | July 26, 2025 |
| Cash paid for amounts included in the measurement of lease liabilities — operating cash flows |  | $ | 517 |  |  | $ | 457 |  |
| ROU assets obtained in exchange for operating leases liabilities |  | $ | 592 |  |  | $ | 660 |  |

[0000858877-26-000132:notes:183]
The weighted-average lease term was 5.7 years as of each of July 25, 2026 and July 26, 2025. The weighted-average discount rate was 4.0% and 4.1% as of July 25, 2026 and July 26, 2025, respectively.

[0000858877-26-000132:notes:184]
The maturities of our operating leases (undiscounted) as of July 25, 2026 are as follows (in millions):

[0000858877-26-000132:notes:185]
| Fiscal Year | Amount |
| 2027 | $ | 461 |  |
| 2028 | 339 |  |
| 2029 | 262 |  |
| 2030 | 219 |  |
| 2031 | 182 |  |
| Thereafter | 411 |  |
| Total lease payments | 1,874 |  |
| Less interest | (222) |  |
| Total | $ | 1,652 |  |

[0000858877-26-000132:notes:186]
(b)Lessor Arrangements

[0000858877-26-000132:notes:187]
Our leases primarily represent sales-type leases with terms of four years on average. We provide leasing of our equipment and complementary third-party products primarily through our channel partners and distributors, for which the income arising from these leases is recognized through interest income. Interest income for fiscal 2026, 2025, and 2024 was $56 million, $66 million and $65 million, respectively, and was included in interest income in the Consolidated Statement of Operations. The net investment of our lease receivables is measured at the commencement date as the gross lease receivable, residual value less unearned income and allowance for credit loss. For additional information, see Note 9.

[0000858877-26-000132:notes:188]
Future minimum lease payments on our lease receivables as of July 25, 2026 are summarized as follows (in millions):

[0000858877-26-000132:notes:189]
| Fiscal Year | Amount |
| 2027 | $ | 345 |  |
| 2028 | 181 |  |
| 2029 | 127 |  |
| 2030 | 149 |  |
| 2031 | 139 |  |
| Total | 941 |  |
| Less: Present value of lease payments | (858) |  |
| Unearned income | $ | 83 |  |

[0000858877-26-000132:notes:190]
Actual cash collections may differ from the contractual maturities due to early customer buyouts, refinancings, or defaults.


## us-gaap:FinancingReceivablesTextBlock

[0000858877-26-000132:notes:191]
Financing Receivables  
(a)Financing Receivables

[0000858877-26-000132:notes:192]
Financing receivables primarily consist of loan receivables and lease receivables. Loan receivables represent financing arrangements related to the sale of our hardware, software, and services (including technical support and professional services), and also may include additional funding for other costs associated with network installation and integration of our products and services. Loan receivables have terms of one year to three years on average. Lease receivables represent sales-type leases resulting from the sale of Cisco’s and complementary third-party products and are typically collateralized by a security interest in the underlying assets. Lease receivables consist of arrangements with terms of four years on average.

[0000858877-26-000132:notes:193]
A summary of our financing receivables is presented as follows (in millions):

[0000858877-26-000132:notes:194]
| July 25, 2026 | Loan Receivables |  | Lease Receivables |  | Total |
| Gross | $ | 7,457 |  |  | $ | 941 |  |  | $ | 8,398 |  |
| Residual value | — |  |  | 67 |  |  | 67 |  |
| Unearned income | — |  |  | (83) |  |  | (83) |  |
| Allowance for credit loss | (40) |  |  | (10) |  |  | (50) |  |
| Total, net | $ | 7,417 |  |  | $ | 915 |  |  | $ | 8,332 |  |
| Reported as: |  |  |  |  |  |
| Current | $ | 3,024 |  |  | $ | 368 |  |  | $ | 3,392 |  |
| Noncurrent | 4,393 |  |  | 547 |  |  | 4,940 |  |
| Total, net | $ | 7,417 |  |  | $ | 915 |  |  | $ | 8,332 |  |

[0000858877-26-000132:notes:195]
| July 26, 2025 | Loan Receivables |  | Lease Receivables |  | Total |
| Gross | $ | 5,628 |  |  | $ | 982 |  |  | $ | 6,610 |  |
| Residual value | — |  |  | 66 |  |  | 66 |  |
| Unearned income | — |  |  | (99) |  |  | (99) |  |
| Allowance for credit loss | (37) |  |  | (13) |  |  | (50) |  |
| Total, net | $ | 5,591 |  |  | $ | 936 |  |  | $ | 6,527 |  |
| Reported as: |  |  |  |  |  |
| Current | $ | 2,715 |  |  | $ | 346 |  |  | $ | 3,061 |  |
| Noncurrent | 2,876 |  |  | 590 |  |  | 3,466 |  |
| Total, net | $ | 5,591 |  |  | $ | 936 |  |  | $ | 6,527 |  |

[0000858877-26-000132:notes:196]
The fair value of our short-term loan receivables and financed service contracts approximates their carrying value due to their short duration. The aggregate carrying value of our long-term loan receivables and financed service contracts as of July 25,

[0000858877-26-000132:notes:197]
2026 and July 26, 2025 was $4.4 billion and $2.9 billion, respectively. The estimated fair value of our long-term loan receivables and financed service contracts approximates their carrying value. We use significant unobservable inputs in determining discounted cash flows to estimate the fair value of our long-term loan receivables and financed service contracts, and therefore they are categorized as Level 3 in the fair value hierarchy.

[0000858877-26-000132:notes:198]
(b)Credit Quality of Financing Receivables

[0000858877-26-000132:notes:199]
The tables below present our gross financing receivables, excluding residual value, less unearned income, categorized by our internal credit risk rating by period of origination (in millions):

[0000858877-26-000132:notes:200]
| July 25, 2026 |  |  | Fiscal Year |  |  |
| Internal Credit Risk Rating | Prior |  | July 30, 2022 |  | July 29, 2023 |  | July 27, 2024 |  | July 26, 2025 |  | July 25, 2026 |  | Total |
| Loan Receivables: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | 5 |  |  | $ | 39 |  |  | $ | 164 |  |  | $ | 681 |  |  | $ | 1,282 |  |  | $ | 2,479 |  |  | $ | 4,650 |  |
| 5 to 6 | 8 |  |  | 8 |  |  | 79 |  |  | 226 |  |  | 760 |  |  | 1,685 |  |  | 2,766 |  |
| 7 and Higher | — |  |  | 1 |  |  | 2 |  |  | 8 |  |  | 16 |  |  | 14 |  |  | 41 |  |
| Total Loan Receivables | $ | 13 |  |  | $ | 48 |  |  | $ | 245 |  |  | $ | 915 |  |  | $ | 2,058 |  |  | $ | 4,178 |  |  | $ | 7,457 |  |
| Lease Receivables: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | — |  |  | $ | 7 |  |  | $ | 63 |  |  | $ | 139 |  |  | $ | 176 |  |  | $ | 158 |  |  | $ | 543 |  |
| 5 to 6 | — |  |  | 7 |  |  | 39 |  |  | 69 |  |  | 76 |  |  | 115 |  |  | 306 |  |
| 7 and Higher | — |  |  | — |  |  | 1 |  |  | 4 |  |  | 1 |  |  | 3 |  |  | 9 |  |
| Total Lease Receivables | $ | — |  |  | $ | 14 |  |  | $ | 103 |  |  | $ | 212 |  |  | $ | 253 |  |  | $ | 276 |  |  | $ | 858 |  |
| Total | $ | 13 |  |  | $ | 62 |  |  | $ | 348 |  |  | $ | 1,127 |  |  | $ | 2,311 |  |  | $ | 4,454 |  |  | $ | 8,315 |  |

[0000858877-26-000132:notes:201]
| July 26, 2025 |  |  | Fiscal Year |  |  |
| Internal Credit Risk Rating | Prior |  | July 31, 2021 |  | July 30, 2022 |  | July 29, 2023 |  | July 27, 2024 |  | July 26, 2025 |  | Total |
| Loan Receivables: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | 2 |  |  | $ | 83 |  |  | $ | 236 |  |  | $ | 371 |  |  | $ | 1,258 |  |  | $ | 1,556 |  |  | $ | 3,506 |  |
| 5 to 6 | 2 |  |  | 56 |  |  | 53 |  |  | 167 |  |  | 561 |  |  | 1,248 |  |  | 2,087 |  |
| 7 and Higher | — |  |  | — |  |  | 6 |  |  | 9 |  |  | 4 |  |  | 16 |  |  | 35 |  |
| Total Loan Receivables | $ | 4 |  |  | $ | 139 |  |  | $ | 295 |  |  | $ | 547 |  |  | $ | 1,823 |  |  | $ | 2,820 |  |  | $ | 5,628 |  |
| Lease Receivables: |  |  |  |  |  |  |  |  |  |  |  |  |  |
| 1 to 4 | $ | — |  |  | $ | 9 |  |  | $ | 23 |  |  | $ | 112 |  |  | $ | 187 |  |  | $ | 207 |  |  | $ | 538 |  |
| 5 to 6 | — |  |  | 6 |  |  | 25 |  |  | 77 |  |  | 120 |  |  | 103 |  |  | 331 |  |
| 7 and Higher | — |  |  | — |  |  | 1 |  |  | 3 |  |  | 8 |  |  | 2 |  |  | 14 |  |
| Total Lease Receivables | $ | — |  |  | $ | 15 |  |  | $ | 49 |  |  | $ | 192 |  |  | $ | 315 |  |  | $ | 312 |  |  | $ | 883 |  |
| Total | $ | 4 |  |  | $ | 154 |  |  | $ | 344 |  |  | $ | 739 |  |  | $ | 2,138 |  |  | $ | 3,132 |  |  | $ | 6,511 |  |

[0000858877-26-000132:notes:202]
The following tables present the aging analysis of gross receivables as of July 25, 2026 and July 26, 2025 (in millions):

[0000858877-26-000132:notes:203]
|  | DAYS PAST DUE (INCLUDES BILLED AND UNBILLED) |  |  |  |  |  |  |  |  |
| July 25, 2026 | 31 - 60 |  | 61 - 90 |  | 91+ |  | TotalPast Due |  | Current |  | Total |  | 120+ Still Accruing |  | NonaccrualFinancingReceivables |
| Loan receivables | $ | 31 |  |  | $ | 14 |  |  | $ | 12 |  |  | $ | 57 |  |  | $ | 7,400 |  |  | $ | 7,457 |  |  | $ | 7 |  |  | $ | 1 |  |
| Lease receivables | 9 |  |  | 2 |  |  | 3 |  |  | 14 |  |  | 844 |  |  | 858 |  |  | 1 |  |  | — |  |
| Total | $ | 40 |  |  | $ | 16 |  |  | $ | 15 |  |  | $ | 71 |  |  | $ | 8,244 |  |  | $ | 8,315 |  |  | $ | 8 |  |  | $ | 1 |  |

[0000858877-26-000132:notes:204]
|  | DAYS PAST DUE (INCLUDES BILLED AND UNBILLED) |  |  |  |  |  |  |  |  |
| July 26, 2025 | 31 - 60 |  | 61 - 90 |  | 91+ |  | TotalPast Due |  | Current |  | Total |  | 120+ Still Accruing |  | NonaccrualFinancingReceivables |
| Loan receivables | $ | 18 |  |  | $ | 18 |  |  | $ | 16 |  |  | $ | 52 |  |  | $ | 5,576 |  |  | $ | 5,628 |  |  | $ | 4 |  |  | $ | 5 |  |
| Lease receivables | 7 |  |  | 3 |  |  | 6 |  |  | 16 |  |  | 867 |  |  | 883 |  |  | 4 |  |  | 1 |  |
| Total | $ | 25 |  |  | $ | 21 |  |  | $ | 22 |  |  | $ | 68 |  |  | $ | 6,443 |  |  | $ | 6,511 |  |  | $ | 8 |  |  | $ | 6 |  |

[0000858877-26-000132:notes:205]
Past due financing receivables are those that are 31 days or more past due according to their contractual payment terms. The data in the preceding tables is presented by contract, and the aging classification of each contract is based on the oldest outstanding receivable, and therefore past due amounts also include unbilled and current receivables within the same contract.

[0000858877-26-000132:notes:206]
(c)Allowance for Credit Loss Rollforward

[0000858877-26-000132:notes:207]
The allowances for credit loss and the related financing receivables are summarized as follows (in millions):

[0000858877-26-000132:notes:208]
|  | CREDIT LOSS ALLOWANCES |
|  | LoanReceivables |  | LeaseReceivables |  | Total |
| Allowance for credit loss as of July 26, 2025 | $ | 37 |  |  | $ | 13 |  |  | $ | 50 |  |
| Provisions (benefits) | 3 |  |  | (4) |  |  | (1) |  |
| Foreign exchange and other | — |  |  | 1 |  |  | 1 |  |
| Allowance for credit loss as of July 25, 2026 | $ | 40 |  |  | $ | 10 |  |  | $ | 50 |  |

[0000858877-26-000132:notes:209]
|  | CREDIT LOSS ALLOWANCES |
|  | LoanReceivables |  | LeaseReceivables |  | Total |
| Allowance for credit loss as of July 27, 2024 | $ | 50 |  |  | $ | 15 |  |  | $ | 65 |  |
| Provisions (benefits) | (6) |  |  | (3) |  |  | (9) |  |
| Recoveries (write-offs), net | (9) |  |  | — |  |  | (9) |  |
| Foreign exchange and other | 2 |  |  | 1 |  |  | 3 |  |
| Allowance for credit loss as of July 26, 2025 | $ | 37 |  |  | $ | 13 |  |  | $ | 50 |  |

[0000858877-26-000132:notes:210]
|  | CREDIT LOSS ALLOWANCES |
|  | LoanReceivables |  | LeaseReceivables |  | Total |
| Allowance for credit loss as of July 29, 2023 | $ | 53 |  |  | $ | 19 |  |  | $ | 72 |  |
| Provisions (benefits) | 1 |  |  | (3) |  |  | (2) |  |
| Recoveries (write-offs), net | (4) |  |  | (1) |  |  | (5) |  |
| Allowance for credit loss as of July 27, 2024 | $ | 50 |  |  | $ | 15 |  |  | $ | 65 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000858877-26-000132:notes:211]
Investments
Investments Measured on a Recurring Basis

[0000858877-26-000132:notes:212]
The following tables summarize our cash equivalents, available-for-sale debt investments and marketable equity securities measured at fair value on a recurring basis (in millions):

[0000858877-26-000132:notes:213]
|  |  |  | July 25, 2026 |
|  |  |  |  |  |  |  |  |  |  |  | Reported as |
|  | Fair Value Level |  | Cost or AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |  | Cash equivalents |  | Investments |
| U.S. government securities | Level 2 |  | $ | 1,627 |  |  | $ | 1 |  |  | $ | (15) |  |  | $ | 1,613 |  |  | $ | — |  |  | $ | 1,613 |  |
| U.S. government agency securities | Level 2 |  | 41 |  |  | — |  |  | — |  |  | 41 |  |  | — |  |  | 41 |  |
| Non-U.S. government and agency securities | Level 2 |  | 452 |  |  | — |  |  | (1) |  |  | 451 |  |  | 126 |  |  | 325 |  |
| Corporate debt securities | Level 2 |  | 2,493 |  |  | 1 |  |  | (48) |  |  | 2,446 |  |  | 45 |  |  | 2,401 |  |
| Mortgage- and asset-backed securities | Level 2 |  | 156 |  |  | — |  |  | (4) |  |  | 152 |  |  | — |  |  | 152 |  |
| Commercial paper | Level 2 |  | 3,285 |  |  | — |  |  | — |  |  | 3,285 |  |  | 533 |  |  | 2,752 |  |
| Certificates of deposit | Level 2 |  | 1,080 |  |  | — |  |  | — |  |  | 1,080 |  |  | 25 |  |  | 1,055 |  |
| Money market funds | Level 1 |  | 4,868 |  |  | — |  |  | — |  |  | 4,868 |  |  | 4,868 |  |  | — |  |
| Marketable equity securities | Level 1 |  |  |  |  |  |  |  | 361 |  |  | — |  |  | 361 |  |
| Total |  |  | $ | 14,002 |  |  | $ | 2 |  |  | $ | (68) |  |  | $ | 14,297 |  |  | $ | 5,597 |  |  | $ | 8,700 |  |

[0000858877-26-000132:notes:214]
|  |  |  | July 26, 2025 |
|  |  |  |  |  |  |  |  |  |  |  | Reported as |
|  | Fair Value Level |  | Cost or AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealized and Credit Losses |  | FairValue |  | Cash equivalents |  | Investments |  | Other current assets |
| U.S. government securities | Level 2 |  | $ | 1,971 |  |  | $ | 2 |  |  | $ | (12) |  |  | $ | 1,961 |  |  | $ | — |  |  | $ | 1,961 |  |  | $ | — |  |
| U.S. government agency securities | Level 2 |  | 67 |  |  | — |  |  | — |  |  | 67 |  |  | — |  |  | 67 |  |  | — |  |
| Non-U.S. government and agency securities | Level 2 |  | 458 |  |  | — |  |  | — |  |  | 458 |  |  | — |  |  | 458 |  |  | — |  |
| Corporate debt securities | Level 2 |  | 3,139 |  |  | 13 |  |  | (61) |  |  | 3,091 |  |  | 1 |  |  | 3,090 |  |  | — |  |
| Mortgage- and asset-backed securities | Level 2 |  | 320 |  |  | — |  |  | (34) |  |  | 286 |  |  | — |  |  | 286 |  |  | — |  |
| Commercial paper | Level 2 |  | 1,286 |  |  | — |  |  | — |  |  | 1,286 |  |  | 336 |  |  | 950 |  |  | — |  |
| Certificates of deposit | Level 2 |  | 569 |  |  | — |  |  | — |  |  | 569 |  |  | — |  |  | 569 |  |  | — |  |
| Money market funds | Level 1 |  | 6,448 |  |  | — |  |  | — |  |  | 6,448 |  |  | 5,885 |  |  | — |  |  | 563 |  |
| Marketable equity securities | Level 1 |  |  |  |  |  |  |  | 383 |  |  | — |  |  | 383 |  |  | — |  |
| Total |  |  | $ | 14,258 |  |  | $ | 15 |  |  | $ | (107) |  |  | $ | 14,549 |  |  | $ | 6,222 |  |  | $ | 7,764 |  |  | $ | 563 |  |

[0000858877-26-000132:notes:215]
For more discussion on the fair value measurement of our non-marketable equity securities, see below.

[0000858877-26-000132:notes:216]
Available-for-sale Debt Investments

[0000858877-26-000132:notes:217]
The following table presents the gross realized gains and gross realized losses related to available-for-sale debt investments (in millions):

[0000858877-26-000132:notes:218]
| Years Ended | July 25, 2026 |  | July 26, 2025 |  | July 27, 2024 |
| Gross realized gains | $ | 14 |  |  | $ | 10 |  |  | $ | 7 |  |
| Gross realized losses | (28) |  |  | (110) |  |  | (74) |  |
| Total | $ | (14) |  |  | $ | (100) |  |  | $ | (67) |  |

[0000858877-26-000132:notes:219]
The following tables present the breakdown of the available-for-sale debt investments with gross unrealized losses and the duration that those losses had been unrealized at July 25, 2026 and July 26, 2025 (in millions):

[0000858877-26-000132:notes:220]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 25, 2026 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 1,449 |  |  | $ | (15) |  |  | $ | 52 |  |  | $ | — |  |  | $ | 1,501 |  |  | $ | (15) |  |
| U.S. government agency securities | 38 |  |  | — |  |  | — |  |  | — |  |  | 38 |  |  | — |  |
| Non-U.S. government and agency securities | 227 |  |  | (1) |  |  | — |  |  | — |  |  | 227 |  |  | (1) |  |
| Corporate debt securities | 1,549 |  |  | (20) |  |  | 547 |  |  | (2) |  |  | 2,096 |  |  | (22) |  |
| Mortgage- and asset-backed securities | 129 |  |  | (1) |  |  | 20 |  |  | (3) |  |  | 149 |  |  | (4) |  |
| Commercial paper | 99 |  |  | — |  |  | — |  |  | — |  |  | 99 |  |  | — |  |
| Total | $ | 3,491 |  |  | $ | (37) |  |  | $ | 619 |  |  | $ | (5) |  |  | $ | 4,110 |  |  | $ | (42) |  |

[0000858877-26-000132:notes:221]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 26, 2025 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| U.S. government securities | $ | 1,076 |  |  | $ | (6) |  |  | $ | 302 |  |  | $ | (6) |  |  | $ | 1,378 |  |  | $ | (12) |  |
| U.S. government agency securities | 8 |  |  | — |  |  | 21 |  |  | — |  |  | 29 |  |  | — |  |
| Non-U.S. government and agency securities | 292 |  |  | — |  |  | — |  |  | — |  |  | 292 |  |  | — |  |
| Corporate debt securities | 106 |  |  | — |  |  | 1,800 |  |  | (35) |  |  | 1,906 |  |  | (35) |  |
| Mortgage- and asset-backed securities | 5 |  |  | — |  |  | 279 |  |  | (34) |  |  | 284 |  |  | (34) |  |
| Commercial paper | 30 |  |  | — |  |  | — |  |  | — |  |  | 30 |  |  | — |  |
| Total | $ | 1,517 |  |  | $ | (6) |  |  | $ | 2,402 |  |  | $ | (75) |  |  | $ | 3,919 |  |  | $ | (81) |  |

[0000858877-26-000132:notes:222]
The following table summarizes the maturities of our available-for-sale debt investments as of July 25, 2026 (in millions):

[0000858877-26-000132:notes:223]
|  | Amortized Cost |  | Fair Value |
| Within 1 year | $ | 5,217 |  |  | $ | 5,190 |  |
| After 1 year through 5 years | 2,937 |  |  | 2,904 |  |
| After 5 years through 10 years | 95 |  |  | 93 |  |
| Mortgage- and asset-backed securities with no single maturity | 156 |  |  | 152 |  |
| Total | $ | 8,405 |  |  | $ | 8,339 |  |

[0000858877-26-000132:notes:224]
Actual maturities may differ from the contractual maturities because borrowers may have the right to call or prepay certain obligations.

[0000858877-26-000132:notes:225]
Marketable Equity Securities

[0000858877-26-000132:notes:226]
We held marketable equity securities of $361 million and $383 million as of July 25, 2026 and July 26, 2025, respectively. We recognized net unrealized losses of $7 million and net unrealized gains of $108 million and $71 million for fiscal 2026, 2025, and 2024, respectively, on our marketable securities still held as of the reporting date.

[0000858877-26-000132:notes:227]
Non-Marketable Equity Securities

[0000858877-26-000132:notes:228]
Our non-marketable equity securities are investments in privately held entities, venture funds, and publicly traded entities that do not have RDFV. The carrying value of these investments are summarized below (in millions):

[0000858877-26-000132:notes:229]
|  | July 25, 2026 |  | July 26, 2025 |
| Initial cost of non-marketable equity securities measured under the measurement alternative | $ | 1,106 |  |  | $ | 975 |  |
| Cumulative upward adjustments | 893 |  |  | 195 |  |
| Cumulative downward adjustments, including impairments | (637) |  |  | (597) |  |
| Non-marketable equity securities under measurement alternative | 1,362 |  |  | 573 |  |
| Restricted equity securities | 731 |  |  | — |  |
| Consolidated investments | 857 |  |  | 508 |  |
| Non-marketable equity securities under NAV, equity method and other | 1,080 |  |  | 840 |  |
| Total | $ | 4,030 |  |  | $ | 1,921 |  |

[0000858877-26-000132:notes:230]
Our non-marketable equity securities measured using the measurement alternative are recorded to fair value on a non-recurring basis. The carrying value of these securities are adjusted for observable transactions for identical or similar investments of the same issuer or impairment. These securities are classified as Level 3 in the fair value hierarchy because we estimate the value based on valuation methods using the observable transaction price at the transaction date and other unobservable inputs such as volatility, rights, and obligations of the securities we hold.

[0000858877-26-000132:notes:231]
The gross upward adjustments and downward adjustments, including impairments, on our non-marketable equity securities measured under the measurement alternative are summarized below (in millions):

[0000858877-26-000132:notes:232]
| Years Ended | July 25, 2026 |  | July 26, 2025 |  | July 27, 2024 |
| Upward adjustments | $ | 698 |  |  | $ | 11 |  |  | $ | 1 |  |
| Downward adjustments, including impairments | (19) |  |  | (77) |  |  | (166) |  |
| Net adjustments | $ | 679 |  |  | $ | (66) |  |  | $ | (165) |  |

[0000858877-26-000132:notes:233]
Restricted equity securities are measured at fair value on a recurring basis and are classified as Level 2 in the fair value hierarchy, as they are valued based on pricing models that use observable market inputs reduced by a DLOM. The fair value of these restricted equity securities was $731 million as of July 25, 2026, and we recognized unrealized gains of $320 million in fiscal 2026.

[0000858877-26-000132:notes:234]
Our non-marketable equity securities classified as consolidated investments include venture funds that qualified for investment company specific accounting, the accounts of which are consolidated within our financial statements under the voting interest entity model. The noncontrolling interest attributed to these investments was $354 million and $162 million as of July 25, 2026 and July 26, 2025, respectively, and is included in the equity section of the Consolidated Balance Sheets. The share of earnings attributable to the noncontrolling interest attributed to these investments is not material for any of the fiscal years presented and is included in other income (loss), net in the Consolidated Statements of Operations.

[0000858877-26-000132:notes:235]
Of the total carrying value of our non-marketable equity securities as of July 25, 2026, $1.1 billion of such investments are considered to be in variable interest entities which are unconsolidated.


## us-gaap:DebtDisclosureTextBlock

[0000858877-26-000132:notes:236]
Borrowings 
(a)Short-Term Debt

[0000858877-26-000132:notes:237]
The following table summarizes our short-term debt (in millions, except percentages):

[0000858877-26-000132:notes:238]
|  | July 25, 2026 |  | July 26, 2025 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of senior fixed-rate notes | $ | 3,498 |  |  | 3.89 | % |  | $ | 1,749 |  |  | 4.15 | % |
| Commercial paper | 6,661 |  |  | 3.84 | % |  | 3,482 |  |  | 4.37 | % |
| Current portion of other debt | 2 |  |  | 1.13 | % |  | 1 |  |  | 1.13 | % |
| Total | $ | 10,161 |  |  |  |  | $ | 5,232 |  |  |  |

[0000858877-26-000132:notes:239]
We have a short-term debt financing program of up to $15.0 billion through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes.

[0000858877-26-000132:notes:240]
The effective rates for the short- and long-term debt include the interest on the notes, the accretion of the discount, the issuance costs, and, if applicable, adjustments related to hedging.

[0000858877-26-000132:notes:241]
(b)Long-Term Debt

[0000858877-26-000132:notes:242]
The following table summarizes our long-term debt (in millions, except percentages):

[0000858877-26-000132:notes:243]
|  |  |  | July 25, 2026 |  | July 26, 2025 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 4.90% | February 26, 2026 |  | $ | — |  |  | — |  | $ | 1,000 |  |  | 5.00% |
| 2.95% | February 28, 2026 |  | — |  |  | — |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 |  | 1,500 |  |  | 2.55% |  | 1,500 |  |  | 2.55% |
| 4.80% | February 26, 2027 |  | 2,000 |  |  | 4.90% |  | 2,000 |  |  | 4.90% |
| 4.55% | February 24, 2028 |  | 1,000 |  |  | 4.61% |  | 1,000 |  |  | 4.61% |
| 4.85% | February 26, 2029 |  | 2,500 |  |  | 4.91% |  | 2,500 |  |  | 4.91% |
| 4.75% | February 24, 2030 |  | 1,000 |  |  | 4.73% |  | 1,000 |  |  | 4.73% |
| 4.95% | February 26, 2031 |  | 2,500 |  |  | 5.04% |  | 2,500 |  |  | 5.04% |
| 4.95% | February 24, 2032 |  | 1,000 |  |  | 4.94% |  | 1,000 |  |  | 4.94% |
| 5.05% | February 26, 2034 |  | 2,500 |  |  | 4.97% |  | 2,500 |  |  | 4.97% |
| 5.10% | February 24, 2035 |  | 1,250 |  |  | 5.11% |  | 1,250 |  |  | 5.11% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| 5.30% | February 26, 2054 |  | 2,000 |  |  | 5.28% |  | 2,000 |  |  | 5.28% |
| 5.50% | February 24, 2055 |  | 750 |  |  | 5.49% |  | 750 |  |  | 5.49% |
| 5.35% | February 26, 2064 |  | 1,000 |  |  | 5.42% |  | 1,000 |  |  | 5.42% |
| Other debt |  |  | 2 |  |  | 1.13% |  | 3 |  |  | 1.13% |
| Total |  |  | 23,002 |  |  |  |  | 24,753 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (130) |  |  |  |  | (142) |  |  |  |
| Total |  |  | $ | 22,872 |  |  |  |  | $ | 24,611 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 3,500 |  |  |  |  | $ | 1,750 |  |  |  |
| Long-term debt |  |  | 19,372 |  |  |  |  | 22,861 |  |  |  |
| Total |  |  | $ | 22,872 |  |  |  |  | $ | 24,611 |  |  |  |

[0000858877-26-000132:notes:244]
As of July 25, 2026 and July 26, 2025, the estimated fair value of our short-term debt approximates its carrying value due to the short maturities. As of July 25, 2026, the fair value of our senior notes was $22.7 billion, with a carrying amount of $22.9

[0000858877-26-000132:notes:245]
billion. This compares to a fair value of $25.0 billion and a carrying amount of $24.6 billion as of July 26, 2025. The fair value of the senior notes was determined based on observable market prices in a less active market and was categorized as Level 2 in the fair value hierarchy.

[0000858877-26-000132:notes:246]
Our cash paid for interest was $1.4 billion, $1.5 billion and $0.6 billion for fiscal 2026, 2025, and 2024, respectively. Interest is payable semiannually on each class of the senior fixed-rate notes. Each of the senior fixed-rate notes is redeemable by us at any time, subject to a make-whole premium. The senior fixed-rate notes rank at par with the commercial paper notes that have been issued pursuant to our short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of July 25, 2026, we were in compliance with all debt covenants.

[0000858877-26-000132:notes:247]
As of July 25, 2026, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

[0000858877-26-000132:notes:248]
| Fiscal Year | Amount |
| 2027 | $ | 3,502 |  |
| 2028 | 1,000 |  |
| 2029 | 2,500 |  |
| 2030 | 1,000 |  |
| 2031 | 2,500 |  |
| Thereafter | 12,500 |  |
| Total | $ | 23,002 |  |

[0000858877-26-000132:notes:249]
(c)Credit Facility

[0000858877-26-000132:notes:250]
On February 2, 2024, we entered into an amended and restated 5-year $5.0 billion unsecured revolving credit agreement. The interest rate for the credit agreement is determined based on a formula using certain market rates. The credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio (defined in the agreement as the ratio of consolidated EBITDA to consolidated interest expense) of not less than 3.0 to 1.0. As of July 25, 2026, we were in compliance with all associated covenants and we had not borrowed any funds under our credit agreement.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000858877-26-000132:notes:251]
Derivative Instruments 
(a)Summary of Derivative Instruments

[0000858877-26-000132:notes:252]
We use derivative instruments primarily to manage exposures to foreign currency exchange rate, interest rate, and equity price risks. Our primary objective in holding derivatives is to reduce the volatility of earnings and cash flows associated with changes in foreign currency exchange rates, interest rates, and equity prices. Our derivatives expose us to credit risk to the extent that the counterparties may be unable to meet the terms of the agreement. We seek to mitigate such risks by limiting our counterparties to major financial institutions and requiring collateral in certain cases. In addition, the potential risk of loss with any one counterparty resulting from credit risk is monitored. Management does not expect material losses as a result of defaults by counterparties.

[0000858877-26-000132:notes:253]
The fair values of our derivative instruments and the line items on the Consolidated Balance Sheets to which they were recorded are summarized as follows (in millions):

[0000858877-26-000132:notes:254]
|  | DERIVATIVE ASSETS |  | DERIVATIVE LIABILITIES |
|  | Balance Sheet Line Item |  | July 25, 2026 |  | July 26, 2025 |  | Balance Sheet Line Item |  | July 25, 2026 |  | July 26, 2025 |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | $ | 49 |  |  | $ | 17 |  |  | Other current liabilities |  | $ | 2 |  |  | $ | 2 |  |
| Foreign currency derivatives | Other assets |  | 43 |  |  | 10 |  |  | Other long-term liabilities |  | — |  |  | 2 |  |
| Total |  |  | 92 |  |  | 27 |  |  |  |  | 2 |  |  | 4 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | 7 |  |  | 3 |  |  | Other current liabilities |  | 48 |  |  | 17 |  |
| Foreign currency derivatives | Other assets |  | 1 |  |  | 2 |  |  | Other long-term liabilities |  | 43 |  |  | 10 |  |
| Total |  |  | 8 |  |  | 5 |  |  |  |  | 91 |  |  | 27 |  |
| Total |  |  | $ | 100 |  |  | $ | 32 |  |  |  |  | $ | 93 |  |  | $ | 31 |  |

[0000858877-26-000132:notes:255]
Our derivative instruments are primarily classified as Level 2 in the fair value hierarchy, as they are not actively traded and are valued using pricing models that use observable market inputs.

[0000858877-26-000132:notes:256]
The effect on the Consolidated Statements of Operations of derivative instruments not designated as hedges is summarized as follows (in millions):

[0000858877-26-000132:notes:257]
|  |  |  |  | GAINS (LOSSES) FOR THE YEARS ENDED |
| Derivatives Not Designated as Hedging Instruments |  | Line Item in Statements of Operations |  | July 25, 2026 |  | July 26, 2025 |  | July 27, 2024 |
| Foreign currency derivatives |  | Other income (loss), net |  | $ | (81) |  |  | $ | 102 |  |  | $ | (162) |  |
| Total return swaps—deferred compensation |  | Operating expenses and other |  | 147 |  |  | 56 |  |  | 91 |  |
| Equity derivatives |  | Other income (loss), net |  | — |  |  | — |  |  | 2 |  |
| Total |  |  |  | $ | 66 |  |  | $ | 158 |  |  | $ | (69) |  |

[0000858877-26-000132:notes:258]
The notional amounts of our outstanding derivatives are summarized as follows (in millions):

[0000858877-26-000132:notes:259]
|  | July 25, 2026 |  | July 26, 2025 |
| Foreign currency derivatives | $ | 8,686 |  |  | $ | 8,978 |  |
| Total return swaps—deferred compensation | 1,307 |  |  | 1,087 |  |
| Total | $ | 9,993 |  |  | $ | 10,065 |  |

[0000858877-26-000132:notes:260]
(b)Offsetting of Derivative Instruments

[0000858877-26-000132:notes:261]
We present our derivative instruments at gross fair values in the Consolidated Balance Sheets. However, our master netting and other similar arrangements with the respective counterparties allow for net settlement under certain conditions, which are designed to reduce credit risk by permitting net settlement with the same counterparty.

[0000858877-26-000132:notes:262]
(c)Foreign Currency Exchange Risk

[0000858877-26-000132:notes:263]
We conduct business globally in numerous currencies. Therefore, we are exposed to adverse movements in foreign currency exchange rates. To limit the exposure related to foreign currency changes, we enter into foreign currency contracts. We do not enter into such contracts for speculative purposes.

[0000858877-26-000132:notes:264]
We may hedge forecasted foreign currency transactions related to certain revenues, operating expenses and service cost of sales with currency options and forward contracts. These currency options and forward contracts, designated as cash flow hedges, generally have maturities of less than 24 months. The derivative instrument’s gain or loss is initially reported as a component of accumulated other comprehensive income (AOCI) and subsequently reclassified into earnings when the hedged exposure affects earnings.

[0000858877-26-000132:notes:265]
We enter into foreign exchange forward and option contracts to reduce the short-term effects of foreign currency fluctuations on assets and liabilities such as foreign currency receivables, long-term customer financings and payables. These derivatives are

[0000858877-26-000132:notes:266]
not designated as hedging instruments. Gains and losses on the contracts are included in other income (loss), net, and substantially offset foreign exchange gains and losses from the remeasurement of monetary assets and liabilities denominated in currencies other than the functional currency of the reporting entity.

[0000858877-26-000132:notes:267]
We hedge certain net investments in our foreign operations with forward contracts to reduce the effects of foreign currency fluctuations on our net investment in those foreign subsidiaries. These derivative instruments generally have maturities of up to six months.

[0000858877-26-000132:notes:268]
(d)Interest Rate Risk

[0000858877-26-000132:notes:269]
We periodically enter into treasury lock agreements, designated as cash flow hedges, in order to hedge the impact of changes in the U.S. benchmark interest rate on future interest payments in anticipation of future debt offerings. Changes in the fair value of treasury lock agreements are recorded to AOCI and reclassified into earnings when the hedged exposure affects earnings.

[0000858877-26-000132:notes:270]
(e)Equity Price Risk 
We are exposed to variability in compensation charges related to certain deferred compensation obligations to employees and directors. Although not designated as accounting hedges, we utilize derivatives such as total return swaps to economically hedge this exposure and offset the related compensation expense.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000858877-26-000132:notes:271]
Commitments and Contingencies 
(a)Purchase Commitments with Contract Manufacturers and Suppliers

[0000858877-26-000132:notes:272]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments.

[0000858877-26-000132:notes:273]
Certain of these inventory purchase commitments are directly with suppliers, and relate to fixed-dollar commitments to secure supply and pricing for certain product components for multi-year periods. In addition, certain of these inventory purchase commitments are related to long-term supply agreements for fixed quantities of certain memory components for which pricing is variable based on current market values. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.

[0000858877-26-000132:notes:274]
The following table summarizes our inventory purchase commitments with contract manufacturers and suppliers by period (in millions):

[0000858877-26-000132:notes:275]
|  | July 25, 2026 |  | July 26, 2025 |
| Less than 1 year | $ | 14,341 |  |  | $ | 7,202 |  |
| 1 to 3 years | 2,558 |  |  | 320 |  |
| 3 to 5 years | 266 |  |  | 77 |  |
| Total | $ | 17,165 |  |  | $ | 7,599 |  |

[0000858877-26-000132:notes:276]
A significant portion of these commitments supports products sold to hyperscalers and other large customers. Purchase commitments with contract manufacturers and suppliers related to orders from these customers are based on our current demand forecasts and may be canceled, rescheduled, or modified with limited notice. Certain committed components are qualified to a specific customer design and have limited alternative use; others, including certain memory components, are more readily deployable across our product portfolio.

[0000858877-26-000132:notes:277]
We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts, and for commitments related to components that can no longer be used in a salable product, consistent with the valuation of our excess and obsolete inventory. As of July 25, 2026 and July 26, 2025, the liability for these purchase commitments was $294 million and $206 million, respectively, and was included in other current liabilities.

[0000858877-26-000132:notes:278]
(b)Other Commitments

[0000858877-26-000132:notes:279]
We have certain funding commitments, primarily related to our non-marketable equity securities. The funding commitments were $0.4 billion and $0.3 billion as of July 25, 2026 and July 26, 2025, respectively. The funding commitments and the

[0000858877-26-000132:notes:280]
carrying value of our non-marketable equity securities, collectively, represent our maximum exposure related to non-marketable equity securities.

[0000858877-26-000132:notes:281]
(c)Product Warranties

[0000858877-26-000132:notes:282]
The following table summarizes the activity related to the product warranty liability (in millions):

[0000858877-26-000132:notes:283]
|  | July 25, 2026 |  | July 26, 2025 |  | July 27, 2024 |
| Balance at beginning of fiscal year | $ | 399 |  |  | $ | 362 |  |  | $ | 329 |  |
| Provisions for warranties issued | 415 |  |  | 403 |  |  | 425 |  |
| Adjustments for pre-existing warranties | (1) |  |  | 42 |  |  | 22 |  |
| Settlements | (441) |  |  | (408) |  |  | (414) |  |
| Balance at end of fiscal year | $ | 372 |  |  | $ | 399 |  |  | $ | 362 |  |

[0000858877-26-000132:notes:284]
We accrue for warranty costs as part of our cost of sales based on associated material product costs, labor costs for technical support staff, and associated overhead. Our products are generally covered by a warranty for periods ranging from 90 days to five years, and for some products we provide a limited lifetime warranty.

[0000858877-26-000132:notes:285]
(d)Financing and Other Guarantees

[0000858877-26-000132:notes:286]
In the ordinary course of business, we provide financing guarantees for various third-party financing arrangements that are extended to channel partners and end users. Payments under these financing guarantee arrangements were not material for the periods presented.

[0000858877-26-000132:notes:287]
Channel Partner Financing Guarantees   We facilitate arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, with payment terms generally ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, we guarantee a portion of these arrangements. The volume of channel partner financing was $29.9 billion, $24.9 billion, and $27.1 billion in fiscal 2026, 2025, and 2024, respectively. The balance of the channel partner financing subject to guarantees was $1.2 billion and $1.3 billion as of July 25, 2026 and July 26, 2025, respectively.

[0000858877-26-000132:notes:288]
Financing Guarantee Summary   The aggregate amounts of channel partner financing guarantees outstanding at July 25, 2026 and July 26, 2025, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

[0000858877-26-000132:notes:289]
|  | July 25, 2026 |  | July 26, 2025 |
| Maximum potential future payments | $ | 127 |  |  | $ | 123 |  |
| Deferred revenue | (12) |  |  | (13) |  |
| Total | $ | 115 |  |  | $ | 110 |  |

[0000858877-26-000132:notes:290]
(e)Indemnifications

[0000858877-26-000132:notes:291]
In the normal course of business, we have indemnification obligations to other parties, including customers, lessors, and parties to other transactions with us, with respect to certain matters. We have agreed to indemnify against losses arising from a breach of representations or covenants or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time or circumstances within which an indemnification claim can be made and the amount of the claim.

[0000858877-26-000132:notes:292]
It is not possible to determine the maximum potential amount for claims made under the indemnification obligations due to uncertainties in the litigation process, coordination with and contributions by other parties and the defendants in these types of cases, and the unique facts and circumstances involved in each particular case and agreement. Historically, indemnity payments made by us have not had a material effect on our Consolidated Financial Statements.

[0000858877-26-000132:notes:293]
In addition, we have entered into indemnification agreements with our officers and directors, and our Amended and Restated Bylaws contain similar indemnification obligations to our agents.

[0000858877-26-000132:notes:294]
(f)Legal Proceedings

[0000858877-26-000132:notes:295]
Brazil    Brazilian authorities have investigated our Brazilian subsidiary and certain of its former employees, as well as a Brazilian importer of our products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against our Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years.

[0000858877-26-000132:notes:296]
The remaining asserted claims by Brazilian federal tax authorities are for calendar years 2004 through 2007, and the remaining asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total remaining asserted claims by Brazilian state and federal tax authorities aggregate to $153 million for the alleged evasion of import and other taxes, $969 million for interest, and $315 million for various penalties, all determined using an exchange rate as of July 25, 2026.

[0000858877-26-000132:notes:297]
We have completed a thorough review of the matters and believe the asserted claims against our Brazilian subsidiary are without merit, and we are defending the claims vigorously. While we believe there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, we are unable to determine the likelihood of an unfavorable outcome against our Brazilian subsidiary and are unable to reasonably estimate a range of loss, if any. We do not expect a final judicial determination for several years.

[0000858877-26-000132:notes:298]
Centripetal     Centripetal Networks, Inc. (“Centripetal”) filed various patent litigations in the U.S., Germany, and France. These cases have either concluded with findings of non-infringement or invalidity or are in various stages of appeals. In the U.S., there was an appeal from our win in the Eastern District of Virginia that was pending in the Federal Circuit Court of Appeals, and on April 29, 2026, the Federal Circuit affirmed the District Court’s non-infringement decision, and one Patent Trial and Appeal Board (“PTAB”) inter partes review decision that was remanded to the PTAB for further proceedings in which the PTAB found all claims unpatentable. In Germany, there was an infringement hearing on one patent on April 2, 2026, during which the German Court announced its preliminary opinion that Cisco does not infringe, and an appeal hearing in a related invalidity proceeding set for November 10, 2026. In France, Centripetal also filed an infringement case alleging infringement of the French counterpart to U.S. and German patents previously found to not be infringed. Those proceedings are ongoing and there is a final hearing set for October 8, 2026.

[0000858877-26-000132:notes:299]
Ramot     On June 12, 2019 and on February 26, 2021, Ramot at Tel Aviv University Ltd. (“Ramot”) asserted patent infringement claims against Cisco and Acacia in the U.S. District Court for the Eastern District of Texas (“E.D. Tex.”) and in the District of Delaware (“D. Del.”), respectively. Ramot is seeking damages, including enhanced damages, and a royalty on future sales. Ramot alleges that certain optical transceiver modules and line cards infringe three patents. We challenged the validity of the patents in the U.S. Patent and Trademark Office (“PTO”) and the pending District Court cases have been stayed. On September 28, 2021 and May 24, 2022, Cisco and Acacia filed two declaratory judgment actions of noninfringement against Ramot in D. Del on other Ramot patents. The Court rescheduled the trial date in the D. Del. cases for December 1, 2025. Prior to trial, the D. Del. Court granted our motion for summary judgment of non-infringement of all patents-in suit. Ramot appealed that decision to the Federal Circuit and those proceedings are ongoing.

[0000858877-26-000132:notes:300]
While we believe that we have strong non-infringement and invalidity arguments in these litigations, and that Ramot’s damages theories in such cases are not supported by prevailing law, we are unable to reasonably estimate the ultimate outcome of these litigations at this time due to uncertainties in the litigation processes. If we do not prevail in court in these litigations, we believe any damages ultimately assessed would not have a material effect on our Consolidated Financial Statements.

[0000858877-26-000132:notes:301]
In addition to the above matters, we are subject to other legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, we do not believe that the ultimate costs to resolve these matters will have a material effect on our Consolidated Financial Statements. 
For additional information regarding intellectual property litigation, see “Part I, Item 1A. Risk Factors—We may be found to infringe on intellectual property rights of others” herein.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock

[0000858877-26-000132:notes:302]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that allow them to procure inventory based upon criteria as defined by us or establish the parameters defining our requirements. A significant portion of our reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. 
Certain of these inventory purchase commitments are directly with suppliers, and relate to fixed-dollar commitments to secure supply and pricing for certain product components for multi-year periods. In addition, certain of these inventory purchase commitments are related to long-term supply agreements for fixed quantities of certain memory components for which pricing is variable based on current market values. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed.We record a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of our future demand forecasts, and for commitments related to components that can no longer be used in a salable product, consistent with the valuation of our excess and obsolete inventory.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000858877-26-000132:notes:303]
Stockholders’ Equity 
(a)Stock Repurchase Program

[0000858877-26-000132:notes:304]
In September 2001, our Board of Directors authorized a stock repurchase program. As of July 25, 2026, the remaining authorized amount for stock repurchases under this program was approximately $8.1 billion, with no termination date.

[0000858877-26-000132:notes:305]
Our stock repurchase activity under the stock repurchase program, reported based on the trade date, is summarized as follows (in millions, except per-share amounts):

[0000858877-26-000132:notes:306]
| Years Ended |  | Shares |  | Weighted-Average Price per Share |  | Amount |
| July 25, 2026 |  | 76 |  |  | $ | 80.26 |  |  | $ | 6,106 |  |
| July 26, 2025 |  | 105 |  |  | $ | 56.53 |  |  | $ | 5,995 |  |
| July 27, 2024 |  | 117 |  |  | $ | 49.45 |  |  | $ | 5,764 |  |

[0000858877-26-000132:notes:307]
Amounts may not recalculate due to rounding.

[0000858877-26-000132:notes:308]
The purchase price for the shares of our stock repurchased is reflected as a reduction to stockholders’ equity.

[0000858877-26-000132:notes:309]
We are required to allocate the purchase price of the repurchased shares as (i) a reduction to retained earnings or an increase to accumulated deficit and (ii) a reduction of common stock and additional paid-in capital.

[0000858877-26-000132:notes:310]
(b)Dividends Declared

[0000858877-26-000132:notes:311]
On August 12, 2026, our Board of Directors declared a quarterly dividend of $0.42 per common share to be paid on October 21, 2026, to all stockholders of record as of the close of business on October 2, 2026. Future dividends will be subject to the approval of our Board of Directors.

[0000858877-26-000132:notes:312]
(c)Preferred Stock

[0000858877-26-000132:notes:313]
Under the terms of our Amended and Restated Certificate of Incorporation, the Board of Directors is authorized to issue preferred stock in one or more series and, in connection with the creation of such series, to fix by resolution the designation, powers (including voting powers (if any)), preferences and relative, participating, optional or other special rights, if any, of such series, and any qualifications, limitations or restrictions thereof, of the shares of such series. As of July 25, 2026, we have not issued any shares of preferred stock.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000858877-26-000132:notes:314]
Employee Benefit Plans  
(a)Employee Stock Incentive Plans

[0000858877-26-000132:notes:315]
We have one stock incentive plan: the 2005 Stock Incentive Plan (the “2005 Plan”). In addition, we have, in connection with our acquisitions of various companies, assumed the share-based awards granted under stock incentive plans of the acquired companies or issued share-based awards in replacement thereof. Share-based awards are designed to reward employees for their long-term contributions to us and provide incentives for them to remain with us. The number and frequency of share-based awards are based on competitive practices, our operating results, government regulations, and other factors.

[0000858877-26-000132:notes:316]
The 2005 Plan provides for the granting of stock options, stock grants, stock units and stock appreciation rights (SARs), the vesting of which may be time-based or upon satisfaction of performance goals, or both, and/or other conditions. Time-based and performance-based RSUs generally vest over three years with certain awards containing retirement eligible provisions. Employees (including employee directors and executive officers) and consultants of Cisco and its subsidiaries and affiliates and non-employee directors of Cisco are eligible to participate in the 2005 Plan. The 2005 Plan may be terminated by our Board of Directors at any time and for any reason, and is currently set to terminate at the 2030 Annual Meeting unless re-adopted or extended by our stockholders prior to or on such date.

[0000858877-26-000132:notes:317]
Under the 2005 Plan’s share reserve feature, a distinction is made between the number of shares in the reserve attributable to (i) stock options and SARs and (ii) “full value” awards (i.e., stock grants and stock units). Shares issued as stock grants, pursuant to stock units or pursuant to the settlement of dividend equivalents are counted against shares available for issuance under the 2005 Plan on a 1.5-to-1 ratio. For each share awarded as restricted stock or a restricted stock unit award under the 2005 Plan, 1.5 shares was deducted from the available share-based award balance. If awards issued under the 2005 Plan are forfeited or terminated for any reason before being exercised or settled, then the shares underlying such awards, plus the number of additional shares, if any, that counted against shares available for issuance under the 2005 Plan at the time of grant as a result of

[0000858877-26-000132:notes:318]
the application of the share ratio described above, will become available again for issuance under the 2005 Plan. As of July 25, 2026, 131 million shares were authorized for future grant under the 2005 Plan.

[0000858877-26-000132:notes:319]
(b)Employee Stock Purchase Plan

[0000858877-26-000132:notes:320]
We have an Employee Stock Purchase Plan under which eligible employees are offered shares through a 24-month offering period, which consists of four consecutive 6-month purchase periods. Employees may purchase a limited amount of shares of our stock at a discount of up to 15% of the lesser of the fair market value at the beginning of the offering period or the end of each 6-month purchase period. The Employee Stock Purchase Plan is scheduled to terminate on the earlier of (i) January 3, 2030 and (ii) the date on which all shares available for issuance under the Employee Stock Purchase Plan are sold pursuant to exercised purchase rights. We issued 19 million, 18 million, and 20 million shares under the Employee Stock Purchase Plan in fiscal 2026, 2025, and 2024, respectively. As of July 25, 2026, 31 million shares were available for issuance under the Employee Stock Purchase Plan.

[0000858877-26-000132:notes:321]
(c)Summary of Share-Based Compensation Expense

[0000858877-26-000132:notes:322]
Share-based compensation expense consists of expenses for RSUs and stock purchase rights, granted to employees or assumed from acquisitions. The following table summarizes share-based compensation expense and the income tax benefit for share-based compensation (in millions):

[0000858877-26-000132:notes:323]
| Years Ended | July 25, 2026 |  | July 26, 2025 |  | July 27, 2024 |
| Cost of sales—product | $ | 254 |  |  | $ | 255 |  |  | $ | 214 |  |
| Cost of sales—services | 335 |  |  | 329 |  |  | 300 |  |
| Share-based compensation expense in cost of sales | 589 |  |  | 584 |  |  | 514 |  |
| Research and development | 1,734 |  |  | 1,625 |  |  | 1,316 |  |
| Sales and marketing | 999 |  |  | 918 |  |  | 846 |  |
| General and administrative | 448 |  |  | 476 |  |  | 375 |  |
| Restructuring and other charges | 60 |  |  | 38 |  |  | 23 |  |
| Share-based compensation expense in operating expenses | 3,241 |  |  | 3,057 |  |  | 2,560 |  |
| Total share-based compensation expense | $ | 3,830 |  |  | $ | 3,641 |  |  | $ | 3,074 |  |
| Income tax benefit for share-based compensation | $ | 1,175 |  |  | $ | 871 |  |  | $ | 696 |  |

[0000858877-26-000132:notes:324]
As of July 25, 2026, the total compensation cost related to unvested share-based awards not yet recognized was $4.8 billion, which is expected to be recognized over approximately 1.6 years on a weighted-average basis.

[0000858877-26-000132:notes:325]
(d)Restricted Stock Unit Awards

[0000858877-26-000132:notes:326]
A summary of the restricted stock and stock unit activity, which includes time-based and performance-based or market-based RSUs, is as follows (in millions, except per-share amounts):

[0000858877-26-000132:notes:327]
|  | Restricted Stock/Stock Units |  | Weighted-AverageGrant Date FairValue per Share |  | Aggregate Fair Value |
| UNVESTED BALANCE AT JULY 29, 2023 | 122 |  |  | $ | 44.04 |  |  |  |
| Granted and assumed | 63 |  |  | 48.97 |  |  |  |
| Vested | (58) |  |  | 43.46 |  |  | $ | 2,906 |  |
| Canceled/forfeited/other | (10) |  |  | 45.65 |  |  |  |
| UNVESTED BALANCE AT JULY 27, 2024 | 117 |  |  | 46.86 |  |  |  |
| Granted and assumed | 70 |  |  | 55.73 |  |  |  |
| Vested | (65) |  |  | 46.95 |  |  | $ | 3,707 |  |
| Canceled/forfeited/other | (9) |  |  | 48.04 |  |  |  |
| UNVESTED BALANCE AT JULY 26, 2025 | 113 |  |  | 52.26 |  |  |  |
| Granted and assumed | 53 |  |  | 75.75 |  |  |  |
| Vested | (67) |  |  | 50.47 |  |  | $ | 5,435 |  |
| Canceled/forfeited/other | (2) |  |  | 83.39 |  |  |  |
| UNVESTED BALANCE AT JULY 25, 2026 | 97 |  |  | $ | 65.51 |  |  |  |

[0000858877-26-000132:notes:328]
(e)Valuation of Employee Share-Based Awards

[0000858877-26-000132:notes:329]
Time-based restricted stock units and PRSUs that are based on our financial performance metrics or non-financial operating goals are valued using the market value of our common stock on the date of grant, discounted for the present value of expected dividends. For PRSUs granted, we included a relative total shareholder return (TSR) modifier to determine the number of shares earned at the end of the performance period. The TSR modifier is determined using a Monte Carlo simulation model. The PRSUs granted during the fiscal years presented are contingent on the achievement of our financial performance metrics, our comparative market-based returns, or the achievement of financial and non-financial operating goals.

[0000858877-26-000132:notes:330]
The assumptions for the valuation of time-based RSUs and PRSUs are summarized as follows:

[0000858877-26-000132:notes:331]
|  | RESTRICTED STOCK UNITS |
| Years Ended | July 25, 2026 |  | July 26, 2025 |  | July 27, 2024 |
| Number of shares granted (in millions) | 50 |  |  | 65 |  |  | 60 |  |
| Grant date fair value per share | $ | 76.00 |  |  | $ | 55.93 |  |  | $ | 48.71 |  |
| Weighted-average assumptions/inputs: |  |  |  |  |  |
| Expected dividend yield | 2.2 | % |  | 2.7 | % |  | 3.0 | % |
| Range of risk-free interest rates | 3.4% – 4.4% |  | 3.5% – 4.9% |  | 4.2% – 5.6% |

[0000858877-26-000132:notes:332]
|  | PERFORMANCE BASED RESTRICTED STOCK UNITS |
| Years Ended | July 25, 2026 |  | July 26, 2025 |  | July 27, 2024 |
| Number of shares granted (in millions) | 2 |  |  | 4 |  |  | 3 |  |
| Grant date fair value per share | $ | 70.86 |  |  | $ | 54.50 |  |  | $ | 59.31 |  |

[0000858877-26-000132:notes:333]
The assumptions for the valuation of employee stock purchase rights are summarized as follows:

[0000858877-26-000132:notes:334]
|  | EMPLOYEE STOCK PURCHASE RIGHTS |
| Years Ended | July 25, 2026 |  | July 26, 2025 |  | July 27, 2024 |
| Weighted-average assumptions: |  |  |  |  |  |
| Expected volatility | 22.7 | % |  | 22.5 | % |  | 28.3 | % |
| Risk-free interest rate | 4.9 | % |  | 5.0 | % |  | 2.9 | % |
| Expected dividend | 3.3 | % |  | 3.3 | % |  | 3.5 | % |
| Expected life (in years) | 1.3 |  | 1.3 |  | 1.2 |
| Weighted-average estimated grant date fair value per share | $ | 12.52 |  |  | $ | 12.18 |  |  | $ | 11.59 |  |

[0000858877-26-000132:notes:335]
The valuation of employee stock purchase rights and the related assumptions are for the employee stock purchases made during the respective fiscal years.

[0000858877-26-000132:notes:336]
We used the implied volatility for traded options (with contract terms corresponding to the expected life of the employee stock purchase rights) on our stock as the expected volatility assumption required in the Black-Scholes model. The implied volatility is more representative of future stock price trends than historical volatility. The risk-free interest rate assumption is based upon observed interest rates appropriate for the term of our employee stock purchase rights. The dividend yield assumption is based on the history and expectation of dividend payouts at the grant date.

[0000858877-26-000132:notes:337]
(f)Employee 401(k) Plans

[0000858877-26-000132:notes:338]
We sponsor the Cisco Systems, Inc. 401(k) Plan (the “Plan”) to provide retirement benefits for our employees. As allowed under Section 401(k) of the Internal Revenue Code, the Plan provides for tax-deferred salary contributions and after-tax contributions for eligible employees. The Plan allows employees to contribute up to 75% of their annual eligible earnings to the Plan on a pretax and after-tax basis, including Roth contributions. Employee contributions are limited to a maximum annual amount as set periodically by the Internal Revenue Code. We match pretax and Roth employee contributions up to 100% of the first 4.5% of eligible earnings that are contributed by employees. Therefore, the maximum matching contribution that we may allocate to each participant’s account will not exceed $16,200 for the 2026 calendar year due to the $360,000 annual limit on eligible earnings imposed by the Internal Revenue Code. All matching contributions vest immediately. Our matching contributions to the Plan totaled $385 million, $373 million, and $358 million in fiscal 2026, 2025, and 2024, respectively.

[0000858877-26-000132:notes:339]
The Plan allows employees who meet the age requirements and reach the Plan contribution limits to make catch-up contributions (pretax or Roth) not to exceed the lesser of 75% of their annual eligible earnings or the limit set forth in the Internal Revenue Code. Catch-up contributions are not eligible for matching contributions. In addition, the Plan provides for discretionary profit-sharing contributions as determined by the Board of Directors. Such contributions to the Plan are allocated among eligible participants in the proportion of their salaries to the total salaries of all participants. There were no discretionary profit-sharing contributions made in fiscal 2026, 2025, and 2024.

[0000858877-26-000132:notes:340]
We also sponsor other 401(k) plans as a result of acquisitions of other companies. Our contributions to these plans were not material to Cisco on either an individual or aggregate basis for any of the fiscal years presented.

[0000858877-26-000132:notes:341]
(g)Deferred Compensation Plans
The Cisco Systems, Inc. Deferred Compensation Plan (the “Deferred Compensation Plan”), a nonqualified deferred compensation plan, became effective in 2007. As required by applicable law, participation in the Deferred Compensation Plan is limited to a select group of our management employees. Under the Deferred Compensation Plan, which is an unfunded and unsecured deferred compensation arrangement, a participant may elect to defer base salary, bonus, and/or commissions, pursuant to such rules as may be established by Cisco, up to the maximum percentages for each deferral election as described in the plan. We may also, at our discretion, make a matching contribution to the employee under the Deferred Compensation Plan. A matching contribution equal to 4.5% of eligible compensation in excess of the Internal Revenue Code limit for qualified plans for calendar year 2026 that is deferred by participants under the Deferred Compensation Plan (with a $1.5 million cap on eligible compensation) will be made to eligible participants’ accounts at the end of calendar year 2026. The total deferred compensation liability under the Deferred Compensation Plan, together with deferred compensation plans assumed from acquired companies, was approximately $1.5 billion and $1.2 billion as of July 25, 2026 and July 26, 2025, respectively, and was recorded primarily in other long-term liabilities.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000858877-26-000132:notes:342]
Accumulated Other Comprehensive Income (Loss)  
The components of AOCI, net of tax, and the other comprehensive income (loss) are summarized as follows (in millions):

[0000858877-26-000132:notes:343]
|  | Net Unrealized Gains (Losses) on Available-for-Sale Investments |  | Net Unrealized Gains (Losses) Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Actuarial Gains (Losses) |  | Accumulated Other Comprehensive Income (Loss) |
| BALANCE AT JULY 29, 2023 | $ | (440) |  |  | $ | 18 |  |  | $ | (1,153) |  |  | $ | (1,575) |  |
| Other comprehensive income (loss) before reclassifications | 193 |  |  | 128 |  |  | (115) |  |  | 206 |  |
| (Gains) losses reclassified out of AOCI | 67 |  |  | (49) |  |  | (2) |  |  | 16 |  |
| Tax benefit (expense) | (61) |  |  | (18) |  |  | 2 |  |  | (77) |  |
| BALANCE AT JULY 27, 2024 | (241) |  |  | 79 |  |  | (1,268) |  |  | (1,430) |  |
| Other comprehensive income (loss) before reclassifications | 152 |  |  | 29 |  |  | 304 |  |  | 485 |  |
| (Gains) losses reclassified out of AOCI | 100 |  |  | (47) |  |  | — |  |  | 53 |  |
| Tax benefit (expense) | (68) |  |  | 4 |  |  | 2 |  |  | (62) |  |
| BALANCE AT JULY 26, 2025 | (57) |  |  | 65 |  |  | (962) |  |  | (954) |  |
| Other comprehensive income (loss) before reclassifications | 12 |  |  | 104 |  |  | (71) |  |  | 45 |  |
| (Gains) losses reclassified out of AOCI | 14 |  |  | (41) |  |  | 1 |  |  | (26) |  |
| Tax benefit (expense) | — |  |  | (15) |  |  | (6) |  |  | (21) |  |
| BALANCE AT JULY 25, 2026 | $ | (31) |  |  | $ | 113 |  |  | $ | (1,038) |  |  | $ | (956) |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000858877-26-000132:notes:344]
Income Taxes
(a)Provision for Income Taxes

[0000858877-26-000132:notes:345]
The provision for income taxes consists of the following (in millions):

[0000858877-26-000132:notes:346]
| Years Ended | July 25, 2026 |  | July 26, 2025 |  | July 27, 2024 |
| Federal: |  |  |  |  |  |
| Current | $ | 1,385 |  |  | $ | 956 |  |  | $ | 1,939 |  |
| Deferred | (256) |  |  | (838) |  |  | (883) |  |
|  | 1,129 |  |  | 118 |  |  | 1,056 |  |
| State: |  |  |  |  |  |
| Current | 271 |  |  | 431 |  |  | 388 |  |
| Deferred | 452 |  |  | (250) |  |  | 11 |  |
|  | 723 |  |  | 181 |  |  | 399 |  |
| Foreign: |  |  |  |  |  |
| Current | 860 |  |  | 665 |  |  | 559 |  |
| Deferred | 30 |  |  | (44) |  |  | (100) |  |
|  | 890 |  |  | 621 |  |  | 459 |  |
| Total | $ | 2,742 |  |  | $ | 920 |  |  | $ | 1,914 |  |

[0000858877-26-000132:notes:347]
Income before provision for income taxes consists of the following (in millions):

[0000858877-26-000132:notes:348]
| Years Ended | July 25, 2026 |  | July 26, 2025 |  | July 27, 2024 |
| United States | $ | 14,062 |  |  | $ | 9,500 |  |  | $ | 10,790 |  |
| International | 1,947 |  |  | 1,600 |  |  | 1,444 |  |
| Total | $ | 16,009 |  |  | $ | 11,100 |  |  | $ | 12,234 |  |

[0000858877-26-000132:notes:349]
The items accounting for the difference between income taxes computed at the federal statutory rate and the provision for income taxes consist of the following for fiscal 2026 (in millions, except percentages):

[0000858877-26-000132:notes:350]
| Year Ended | July 25, 2026 |
| Federal statutory rate | $ | 3,362 |  |  | 21.0 | % |
| State taxes, net of federal tax benefit (1) | 565 |  |  | 3.5 |  |
| Foreign tax effects | 300 |  |  | 1.9 |  |
| Effect of cross-border tax laws: |  |  |  |
| Foreign-derived intangible income deduction | (625) |  |  | (3.9) |  |
| Subpart F inclusion | 285 |  |  | 1.8 |  |
| Other | 15 |  |  | 0.1 |  |
| Tax credits: |  |  |  |
| R&D tax credits | (430) |  |  | (2.7) |  |
| Foreign tax credits | (592) |  |  | (3.7) |  |
| Other credits | (4) |  |  | — |  |
| Nontaxable or nondeductible items: |  |  |  |
| Stock-based compensation | (292) |  |  | (1.8) |  |
| Other | (19) |  |  | (0.2) |  |
| Changes in unrecognized tax benefits | 177 |  |  | 1.1 |  |
| Total | $ | 2,742 |  |  | 17.1 | % |

[0000858877-26-000132:notes:351]
(1) California state tax made up the majority (greater than 50 percent) of the tax effect in this category.

[0000858877-26-000132:notes:352]
The items accounting for the difference between income taxes computed at the federal statutory rate and the provision for income taxes consist of the following for fiscal 2025 and 2024:

[0000858877-26-000132:notes:353]
| Years Ended |  | July 26, 2025 |  | July 27, 2024 |
| Federal statutory rate |  | 21.0 | % |  | 21.0 | % |
| Effect of: |  |  |  |  |
| State taxes, net of federal tax benefit |  | 1.3 |  |  | 2.8 |  |
| Foreign income at other than U.S. rates |  | 0.7 |  |  | (0.3) |  |
| Tax credits |  | (2.7) |  |  | (2.4) |  |
| Foreign-derived intangible income deduction |  | (6.0) |  |  | (5.5) |  |
| Stock-based compensation |  | 0.7 |  |  | 0.7 |  |
| Impact of the Tax Act |  | (6.5) |  |  | — |  |
| Other, net |  | (0.2) |  |  | (0.7) |  |
| Total |  | 8.3 | % |  | 15.6 | % |

[0000858877-26-000132:notes:354]
On August 26, 2024, the U.S. Tax Court issued an opinion in Varian Medical Systems, Inc. v. Commissioner. The opinion related to the U.S. taxation of deemed foreign dividends in the transition year of the Tax Act (our fiscal 2018). While we were not a party to the case, the opinion resulted in a change to our tax position. As such, we recorded a tax benefit of $720 million as a reduction to the provision for income taxes in fiscal 2025 due to this U.S. Tax Court opinion. The income tax receivable associated with this tax benefit was included in other assets in the Consolidated Balance Sheets.

[0000858877-26-000132:notes:355]
During fiscal 2025, we changed our assertion regarding our intent to indefinitely reinvest $6.5 billion of undistributed earnings for certain foreign subsidiaries and determined that those earnings are no longer considered permanently reinvested.

[0000858877-26-000132:notes:356]
During fiscal 2024, we resolved all remaining items with the IRS related to the audit of our federal income tax returns for the fiscal years ended July 26, 2014 through July 30, 2016. As a result of this resolution, we recognized a net benefit to the provision for income taxes of $55 million, which included a reduction of interest expense of $18 million.

[0000858877-26-000132:notes:357]
Cash paid for income taxes, net of refunds, for fiscal 2026 is as follows (in millions):

[0000858877-26-000132:notes:358]
| Year Ended | July 25, 2026 |
| Federal | $ | 3,672 |  |
| State | 360 |  |
| Foreign | 789 |  |
| Total | $ | 4,821 |  |

[0000858877-26-000132:notes:359]
We made our final transition tax payment of $2.3 billion in fiscal 2026 as a result of the Tax Act.

[0000858877-26-000132:notes:360]
Our cash paid for income taxes, net was $3.9 billion and $7.4 billion for fiscal 2025 and 2024, respectively.

[0000858877-26-000132:notes:361]
Unrecognized Tax Benefits

[0000858877-26-000132:notes:362]
The aggregate changes in the balance of gross unrecognized tax benefits were as follows (in millions):

[0000858877-26-000132:notes:363]
| Years Ended | July 25, 2026 |  | July 26, 2025 |  | July 27, 2024 |
| Beginning balance | $ | 2,337 |  |  | $ | 2,156 |  |  | $ | 2,137 |  |
| Additions based on tax positions related to the current year | 270 |  |  | 283 |  |  | 205 |  |
| Additions for tax positions of prior years | 128 |  |  | 81 |  |  | 256 |  |
| Reductions for tax positions of prior years | (112) |  |  | (68) |  |  | (344) |  |
| Settlements | (37) |  |  | (75) |  |  | (53) |  |
| Lapse of statute of limitations | (96) |  |  | (40) |  |  | (45) |  |
| Ending balance | $ | 2,490 |  |  | $ | 2,337 |  |  | $ | 2,156 |  |

[0000858877-26-000132:notes:364]
As of July 25, 2026, $1.7 billion of the unrecognized tax benefits would affect the effective tax rate if realized. We recognized net interest expense of $44 million, $77 million and $21 million during fiscal 2026, 2025, and 2024, respectively. Our net penalty expense for fiscal 2026, 2025, and 2024 was not material. Our total accrual for interest and penalties was $539 million, $497 million, and $401 million as of the end of fiscal 2026, 2025, and 2024, respectively. We are no longer subject to U.S.

[0000858877-26-000132:notes:365]
federal income tax audit for returns covering tax years through fiscal 2016. We are no longer subject to foreign or state income tax audits for returns covering tax years through fiscal 2003 and fiscal 2015, respectively.

[0000858877-26-000132:notes:366]
As a result of the resolution of the IRS audit of our federal tax income tax returns for the fiscal years ended July 26, 2014 through July 30, 2016, the amount of gross unrecognized tax benefits was reduced by approximately $245 million in fiscal 2024.

[0000858877-26-000132:notes:367]
(b)Deferred Tax Assets and Liabilities

[0000858877-26-000132:notes:368]
The following table presents the breakdown for net deferred tax assets (in millions):

[0000858877-26-000132:notes:369]
|  | July 25, 2026 |  | July 26, 2025 |
| Deferred tax assets | $ | 7,109 |  |  | $ | 7,356 |  |
| Deferred tax liabilities | (85) |  |  | (75) |  |
| Total net deferred tax assets | $ | 7,024 |  |  | $ | 7,281 |  |

[0000858877-26-000132:notes:370]
The following table presents the components of the deferred tax assets and liabilities (in millions):

[0000858877-26-000132:notes:371]
|  | July 25, 2026 |  | July 26, 2025 |
| ASSETS |  |  |  |
| Inventory write-downs and capitalization | $ | 684 |  |  | $ | 532 |  |
| Deferred foreign income | 178 |  |  | 221 |  |
| IPR&D and purchased intangible assets | 878 |  |  | 961 |  |
| Depreciation | 208 |  |  | 242 |  |
| Deferred revenue | 1,819 |  |  | 1,933 |  |
| Credits and net operating loss carryforwards | 1,490 |  |  | 1,350 |  |
| Share-based compensation expense | 360 |  |  | 319 |  |
| Accrued compensation | 248 |  |  | 175 |  |
| Lease liabilities | 400 |  |  | 379 |  |
| Capitalized research expenditures | 4,396 |  |  | 4,182 |  |
| Other | 555 |  |  | 678 |  |
| Gross deferred tax assets | 11,216 |  |  | 10,972 |  |
| Valuation allowance | (1,408) |  |  | (910) |  |
| Total deferred tax assets | 9,808 |  |  | 10,062 |  |
| LIABILITIES |  |  |  |
| Goodwill and purchased intangible assets | (1,946) |  |  | (2,288) |  |
| ROU lease assets | (340) |  |  | (315) |  |
| Unrealized gains on investments | (341) |  |  | (50) |  |
| Other | (157) |  |  | (128) |  |
| Total deferred tax liabilities | (2,784) |  |  | (2,781) |  |
| Total net deferred tax assets | $ | 7,024 |  |  | $ | 7,281 |  |

[0000858877-26-000132:notes:372]
The changes in the valuation allowance for deferred tax assets are summarized as follows (in millions):

[0000858877-26-000132:notes:373]
|  |  | July 25, 2026 |  | July 26, 2025 |  | July 27, 2024 |
| Balance at beginning of fiscal year |  | $ | 910 |  |  | $ | 1,024 |  |  | $ | 754 |  |
| Additions |  | 498 |  |  | 33 |  |  | 148 |  |
| Additions from Splunk |  | — |  |  | — |  |  | 147 |  |
| Deductions |  | (2) |  |  | (4) |  |  | (4) |  |
| Write-offs |  | — |  |  | (145) |  |  | (20) |  |
| Foreign exchange and other |  | 2 |  |  | 2 |  |  | (1) |  |
| Balance at end of fiscal year |  | $ | 1,408 |  |  | $ | 910 |  |  | $ | 1,024 |  |

[0000858877-26-000132:notes:374]
We increased our valuation allowance in fiscal 2026, primarily due to the expectation that our future California taxable income will be insufficient to fully utilize our accumulated California tax credits and net operating loss carryforwards.

[0000858877-26-000132:notes:375]
As of July 25, 2026, our federal, state, and foreign net operating loss carryforwards for income tax purposes were $265 million, $2.3 billion, and $616 million, respectively. A significant amount of the net operating loss carryforwards relates to acquisitions and, as a result, is limited in the amount that can be recognized in any one year. If not utilized, the federal, state, and foreign net operating loss carryforwards will begin to expire in fiscal 2027. We have provided a valuation allowance of $65 million and $102 million for deferred tax assets related to state and foreign net operating losses respectively that are not expected to be realized.
As of July 25, 2026, our federal, state, and foreign tax credit carryforwards for income tax purposes were $5 million, $1.9 billion, and $17 million, respectively. If not utilized, the federal and foreign tax credit carryforwards will begin to expire in fiscal 2027 and fiscal 2032, respectively. The majority of state tax credit carryforwards do not expire. We have provided a valuation allowance of $1.2 billion for deferred tax assets related to state and foreign tax credit carryforwards that are not expected to be realized.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000858877-26-000132:notes:376]
Segment Information and Major Customers 
(a)Revenue and Gross Margin by Segment

[0000858877-26-000132:notes:377]
We conduct business globally and are primarily managed on a geographic basis consisting of three segments: the Americas, EMEA, and APJC. Our chief executive officer is the chief operating decision maker (CODM). The CODM reviews certain financial information for each segment, to evaluate performance and allocate resources by comparing actual performance to our annual targets. Performance of each segment is measured based on segment revenue and segment gross margin. Sales are attributed to a segment based on the location of the customer. Our CODM does not use assets to measure performance of our operating segments.

[0000858877-26-000132:notes:378]
We do not allocate research and development, sales and marketing, or general and administrative expenses to our segments because the CODM does not include this information in our measurement of performance of the operating segments. In addition, we do not allocate amortization and impairment of acquisition-related intangible assets, share-based compensation expense, significant litigation settlements and other contingencies, charges related to asset impairments and restructurings, and certain other charges to the cost of sales and gross margin for each segment because the CODM does not include this information in the measurement of the performance of our operating segments.

[0000858877-26-000132:notes:379]
The following summarizes our revenue and gross margin by segment and the significant expenses by each segment for fiscal 2026, 2025, and 2024 (in millions):

[0000858877-26-000132:notes:380]
| Years Ended | July 25, 2026 |  | July 26, 2025 |  | July 27, 2024 |
| Revenue: |  |  |  |  |  |
| Americas | $ | 37,799 |  |  | $ | 33,656 |  |  | $ | 31,971 |  |
| EMEA | 16,613 |  |  | 14,824 |  |  | 14,117 |  |
| APJC | 8,914 |  |  | 8,174 |  |  | 7,716 |  |
| Total | $ | 63,325 |  |  | $ | 56,654 |  |  | $ | 53,803 |  |
| Gross margin: |  |  |  |  |  |
| Americas | $ | 24,625 |  |  | $ | 22,962 |  |  | $ | 21,372 |  |
| EMEA | 11,835 |  |  | 10,545 |  |  | 9,755 |  |
| APJC | 5,933 |  |  | 5,431 |  |  | 5,187 |  |
| Segment total | 42,392 |  |  | 38,938 |  |  | 36,312 |  |
| Unallocated corporate items | (1,532) |  |  | (2,148) |  |  | (1,484) |  |
| Total | $ | 40,860 |  |  | $ | 36,790 |  |  | $ | 34,828 |  |

[0000858877-26-000132:notes:381]
| Supplemental information about our significant expenses: |  |  |  |  |  |
| Americas: |  |  |  |  |  |
| Cost of sales — product | $ | 10,712 |  |  | $ | 8,206 |  |  | $ | 8,077 |  |
| Cost of sales — services | 2,463 |  |  | 2,487 |  |  | 2,523 |  |
| Segment total | $ | 13,174 |  |  | $ | 10,694 |  |  | $ | 10,600 |  |
| EMEA: |  |  |  |  |  |
| Cost of sales — product | $ | 3,621 |  |  | $ | 3,138 |  |  | $ | 3,264 |  |
| Cost of sales — services | 1,158 |  |  | 1,140 |  |  | 1,098 |  |
| Segment total | $ | 4,778 |  |  | $ | 4,279 |  |  | $ | 4,362 |  |
| APJC: |  |  |  |  |  |
| Cost of sales — product | $ | 2,270 |  |  | $ | 2,010 |  |  | $ | 1,838 |  |
| Cost of sales — services | 711 |  |  | 734 |  |  | 690 |  |
| Segment total | $ | 2,982 |  |  | $ | 2,743 |  |  | $ | 2,529 |  |

[0000858877-26-000132:notes:382]
Revenue in the United States was $34.4 billion, $30.4 billion, and $28.7 billion for fiscal 2026, 2025, and 2024, respectively.

[0000858877-26-000132:notes:383]
(b)Revenue for Groups of Similar Products and Services

[0000858877-26-000132:notes:384]
We design and sell IP-based networking and other products related to the communications and IT industry and provide services associated with these products and their use.

[0000858877-26-000132:notes:385]
(c)Additional Segment Information

[0000858877-26-000132:notes:386]
We had a global channel partner that accounted for approximately 11% of our total revenue in fiscal 2026. No single customer accounted for 10% or more of revenue in fiscal 2025 or 2024.

[0000858877-26-000132:notes:387]
Our long-lived assets are based on the physical location of the assets. The following table presents our long-lived assets, which consists of property and equipment, net and operating lease ROU assets information for geographic areas (in millions):

[0000858877-26-000132:notes:388]
|  | July 25, 2026 |  | July 26, 2025 |
| Long-lived assets: |  |  |  |
| United States | $ | 2,815 |  |  | $ | 2,370 |  |
| International | 1,340 |  |  | 1,044 |  |
| Total | $ | 4,155 |  |  | $ | 3,414 |  |


## us-gaap:EarningsPerShareTextBlock

[0000858877-26-000132:notes:389]
Net Income per Share 
The following table presents the calculation of basic and diluted net income per share (in millions, except per-share amounts):

[0000858877-26-000132:notes:390]
| Years Ended | July 25, 2026 |  | July 26, 2025 |  | July 27, 2024 |
| Net income | $ | 13,267 |  |  | $ | 10,180 |  |  | $ | 10,320 |  |
| Weighted-average shares—basic | 3,953 |  |  | 3,976 |  |  | 4,043 |  |
| Effect of dilutive potential common shares | 34 |  |  | 22 |  |  | 19 |  |
| Weighted-average shares—diluted | 3,987 |  |  | 3,998 |  |  | 4,062 |  |
| Net income per share—basic | $ | 3.36 |  |  | $ | 2.56 |  |  | $ | 2.55 |  |
| Net income per share—diluted | $ | 3.33 |  |  | $ | 2.55 |  |  | $ | 2.54 |  |
| Antidilutive employee share-based awards, excluded | 8 |  |  | 78 |  |  | 82 |  |


## ecd:MtrlTermsOfTrdArrTextBlock

[0000858877-26-000132:notes:391]
On June 6, 2026, Nichlas A. Fink, Cisco’s Senior Vice President and Chief Accounting Officer, adopted a trading plan intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) under the Exchange Act. Mr. Fink’s trading plan provides for the sale of 14,440 gross shares, plus any related dividend-equivalent shares earned with respect to such shares and excluding, as applicable, any shares withheld to satisfy tax withholding obligations in connection with the net settlement of the equity awards. Mr. Fink’s trading plan is scheduled to terminate on June 25, 2027, subject to early termination for certain specified events set forth therein.
