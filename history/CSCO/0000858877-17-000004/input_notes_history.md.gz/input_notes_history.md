# CSCO note change history — 0000858877-16-000123 → 0000858877-17-000004


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2017-02-21):
[0000858877-17-000004:note_history:1]
The Company leases office space in many U.S. locations. Outside the United States, larger leased sites include sites in Belgium, Canada, China, France, Germany, India, Israel, Japan, Poland and the United Kingdom. The Company also leases equipment and vehicles. Future minimum lease payments under all noncancelable operating leases with an initial term in excess of one year as of January 28, 2017 are as follows (in millions):
  (was, 2016-11-22, similarity 0.9371):
[0000858877-16-000123:note_history:1]
The Company leases office space in many U.S. locations. Outside the United States, larger leased sites include sites in Australia, Belgium, Canada, China, Germany, India, Israel, Japan, the Netherlands and the United Kingdom. The Company also leases equipment and vehicles. Future minimum lease payments under all noncancelable operating leases with an initial term in excess of one year as of October 29, 2016 are as follows (in millions):

- changed (2017-02-21):
[0000858877-17-000004:note_history:2]
| Fiscal Year | Amount |
| 2017 (remaining six months) | $ | 213 |  |
| 2018 | 334 |  |
| 2019 | 208 |  |
| 2020 | 142 |  |
| 2021 | 83 |  |
| Thereafter | 175 |  |
| Total | $ | 1,155 |  |
  (was, 2016-11-22, similarity 0.9836):
[0000858877-16-000123:note_history:2]
| Fiscal Year | Amount |
| 2017 (remaining nine months) | $ | 280 |  |
| 2018 | 292 |  |
| 2019 | 178 |  |
| 2020 | 128 |  |
| 2021 | 76 |  |
| Thereafter | 162 |  |
| Total | $ | 1,116 |  |

- changed (2017-02-21):
[0000858877-17-000004:note_history:3]
The Company purchases components from a variety of suppliers and uses several contract manufacturers to provide manufacturing services for its products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, the Company enters into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by the Company or establish the parameters defining the Company’s requirements.  A significant portion of the Company’s reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. In certain instances, these agreements allow the Company the option to cancel, reschedule, and adjust the Company’s requirements based on its business needs prior to firm orders being placed.  As of January 28, 2017 and July 30, 2016, the Company had total purchase commitments for inventory of $4,402 million and $3,896 million, respectively.
  (was, 2016-11-22, similarity 0.993):
[0000858877-16-000123:note_history:3]
The Company purchases components from a variety of suppliers and uses several contract manufacturers to provide manufacturing services for its products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, the Company enters into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by the Company or establish the parameters defining the Company’s requirements.  A significant portion of the Company’s reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. In certain instances, these agreements allow the Company the option to cancel, reschedule, and adjust the Company’s requirements based on its business needs prior to firm orders being placed.  As of October 29, 2016 and July 30, 2016, the Company had total purchase commitments for inventory of $3,920 million and $3,896 million, respectively.

- changed (2017-02-21):
[0000858877-17-000004:note_history:4]
The Company records a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of its future demand forecasts consistent with the valuation of the Company’s excess and obsolete inventory. As of January 28, 2017 and July 30, 2016, the liability for these purchase commitments was $172 million and $159 million, respectively, and was included in other current liabilities.
  (was, 2016-11-22, similarity 0.9597):
[0000858877-16-000123:note_history:4]
The Company records a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of its future demand forecasts consistent with the valuation of the Company’s excess and obsolete inventory. As of October 29, 2016 and July 30, 2016, the liability for these purchase commitments was $161 million and $159 million, respectively, and was included in other current liabilities.

- changed (2017-02-21):
[0000858877-17-000004:note_history:5]
|  | Three Months Ended |  | Six Months Ended |
|  | January 28, 2017 |  | January 23, 2016 |  | January 28, 2017 |  | January 23, 2016 |
| Compensation expense related to acquisitions | $ | 73 |  |  | $ | 71 |  |  | $ | 137 |  |  | $ | 144 |  |
  (was, 2016-11-22, similarity 0.6985):
[0000858877-16-000123:note_history:5]
|  | Three Months Ended |
|  | October 29, 2016 |  | October 24, 2015 |
| Compensation expense related to acquisitions | $ | 64 |  |  | $ | 73 |  |

- changed (2017-02-21):
[0000858877-17-000004:note_history:6]
As of January 28, 2017, the Company estimated that future cash compensation expense of up to $220 million may be required to be recognized pursuant to the applicable business combination agreements, which included the remaining potential compensation expense related to Insieme Networks, Inc. ("Insieme"), as more fully discussed immediately below.
  (was, 2016-11-22, similarity 0.9794):
[0000858877-16-000123:note_history:6]
As of October 29, 2016, the Company estimated that future cash compensation expense of up to $299 million may be required to be recognized pursuant to the applicable business combination agreements, which included the remaining potential compensation expense related to Insieme Networks, Inc. ("Insieme"), as more fully discussed immediately below.

- changed (2017-02-21):
[0000858877-17-000004:note_history:7]
During the first quarter of fiscal 2014, the Company exercised its call option and entered into an agreement to purchase the remaining interests in Insieme. The acquisition closed in the second quarter of fiscal 2014, at which time the former noncontrolling interest holders became eligible to receive up to two milestone payments, which will be determined using agreed-upon formulas based primarily on revenue for certain of Insieme’s products. The Company recorded compensation expense of $12 million and $50 million during the three months ended January 28, 2017 and January 23, 2016, respectively, and $32 million and $101 million during the six months ended January 28, 2017 and January 23, 2016, respectively, related to the fair value of the vested portion of amounts that were earned or are expected to be earned by the former noncontrolling interest holders. Continued vesting will result in additional compensation expense in future periods. Based on the terms of the agreement, the Company has determined that the maximum amount that could be recorded as compensation expense by the Company is approximately $831 million (which includes the $815 million that has been expensed to date), net of forfeitures. The former noncontrolling interest holders earned the maximum amount related to these two milestone payments and were paid approximately $422 million and $354 million during the six months ended January 28, 2017 and January 23, 2016, respectively.  As of January 28, 2017, the Company paid a total of approximately $811 million pursuant to these two milestone payments.
  (was, 2016-11-22, similarity 0.8372):
[0000858877-16-000123:note_history:7]
During the first quarter of fiscal 2014, the Company exercised its call option and entered into an agreement to purchase the remaining interests in Insieme. The acquisition closed in the second quarter of fiscal 2014, at which time the former noncontrolling interest holders became eligible to receive up to two milestone payments, which will be determined using agreed-upon formulas based primarily on revenue for certain of Insieme’s products. The Company recorded compensation expense of $20 million and $51 million during the three months ended October 29, 2016 and October 24, 2015, respectively, related to the fair value of the vested portion of amounts that were earned or are expected to be earned by the former noncontrolling interest holders. Continued vesting will result in additional compensation expense in future periods. Based on the terms of the agreement, the Company has determined that the maximum amount that could be recorded as compensation expense by the Company is approximately $834 million (which includes the $803 million that has been expensed to date), net of forfeitures. The former noncontrolling interest holders earned the maximum amount related to these two milestone payments and were paid approximately $323 million and $291 million during the first quarters of fiscal 2017 and fiscal 2016, respectively.  As of October 29, 2016, the Company paid a total of approximately $712 million pursuant to these two milestone payments.

- changed (2017-02-21):
[0000858877-17-000004:note_history:8]
|  | Six Months Ended |
|  | January 28, 2017 |  | January 23, 2016 |
| Balance at beginning of period | $ | 414 |  |  | $ | 449 |  |
| Provisions for warranty issued | 367 |  |  | 335 |  |
| Adjustments for pre-existing warranties | (3 | ) |  | (13 | ) |
| Settlements | (352 | ) |  | (340 | ) |
| Divestitures | — |  |  | (28 | ) |
| Balance at end of period | $ | 426 |  |  | $ | 403 |  |
  (was, 2016-11-22, similarity 0.7557):
[0000858877-16-000123:note_history:8]
|  | Three Months Ended |
|  | October 29, 2016 |  | October 24, 2015 |
| Balance at beginning of period | $ | 414 |  |  | $ | 449 |  |
| Provisions for warranty issued | 176 |  |  | 160 |  |
| Adjustments for pre-existing warranties | — |  |  | (10 | ) |
| Settlements | (177 | ) |  | (166 | ) |
| Balance at end of period | $ | 413 |  |  | $ | 433 |  |

- changed (2017-02-21):
[0000858877-17-000004:note_history:9]
Channel Partner Financing Guarantees   The Company facilitates arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, generally with payment terms ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, the Company guarantees a portion of these arrangements. The volume of channel partner financing was $6.3 billion and $6.5 billion for the three months ended January 28, 2017 and January 23, 2016, respectively, and was $13.2 billion and $13.4 billion for the six months ended January 28, 2017 and January 23, 2016, respectively. The balance of the channel partner financing subject to guarantees was $1.2 billion and $1.1 billion as of January 28, 2017 and July 30, 2016, respectively.
  (was, 2016-11-22, similarity 0.7117):
[0000858877-16-000123:note_history:9]
Channel Partner Financing Guarantees   The Company facilitates arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, generally with payment terms ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, the Company guarantees a portion of these arrangements. The volume of channel partner financing was $6.9 billion for each of the three months ended October 29, 2016 and October 24, 2015. The balance of the channel partner financing subject to guarantees was $1.0 billion and $1.1 billion as of October 29, 2016 and July 30, 2016, respectively.

- changed (2017-02-21):
[0000858877-17-000004:note_history:10]
End-User Financing Guarantees   The Company also provides financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. The volume of financing provided by third parties for leases and loans as to which the Company had provided guarantees was $30 million and $16 million for the three months ended January 28, 2017 and January 23, 2016, respectively, and was $36 million and $39 million for the six months ended January 28, 2017 and January 23, 2016, respectively.
  (was, 2016-11-22, similarity 0.8508):
[0000858877-16-000123:note_history:10]
End-User Financing Guarantees   The Company also provides financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. The volume of financing provided by third parties for leases and loans as to which the Company had provided guarantees was $6 million and $23 million for the three months ended October 29, 2016 and October 24, 2015, respectively.

- changed (2017-02-21):
[0000858877-17-000004:note_history:11]
Financing Guarantee Summary   The aggregate amounts of financing guarantees outstanding at January 28, 2017 and July 30, 2016, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):
  (was, 2016-11-22, similarity 0.9776):
[0000858877-16-000123:note_history:11]
Financing Guarantee Summary   The aggregate amounts of financing guarantees outstanding at October 29, 2016 and July 30, 2016, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

- added (2017-02-21):
[0000858877-17-000004:note_history:12]
|  | January 28, 2017 |  | July 30, 2016 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 318 |  |  | $ | 281 |  |
| End user | 94 |  |  | 96 |  |
| Total | $ | 412 |  |  | $ | 377 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (99 | ) |  | $ | (85 | ) |
| End user | (63 | ) |  | (76 | ) |
| Total | $ | (162 | ) |  | $ | (161 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue | $ | 250 |  |  | $ | 216 |  |

- changed (2017-02-21):
[0000858877-17-000004:note_history:13]
Other Guarantees   The Company’s other guarantee arrangements as of January 28, 2017 and July 30, 2016 that were subject to recognition and disclosure requirements were not material.
  (was, 2016-11-22, similarity 0.9647):
[0000858877-16-000123:note_history:13]
Other Guarantees   The Company’s other guarantee arrangements as of October 29, 2016 and July 30, 2016 that were subject to recognition and disclosure requirements were not material.

- changed (2017-02-21):
[0000858877-17-000004:note_history:14]
| (f) | Supplier Component Remediation Liabilities |
  (was, 2016-11-22, similarity 0.9608):
[0000858877-16-000123:note_history:14]
| (f) | Supplier Component Remediation Liability |

- added (2017-02-21):
[0000858877-17-000004:note_history:15]
In the second quarter of fiscal 2014, the Company recorded a charge to product cost of sales of $655 million resulting from  failures related to products containing memory components manufactured by a single supplier between 2005 and 2010. The Company performs regular assessments of the sufficiency of this liability and reduced the amount by a total of $238 million in fiscal 2016 and fiscal 2015 based on updated analyses.  During the second quarter of fiscal 2017, the Company further reduced the liability by $141 million to reflect lower than expected defects, actual usage history, and estimated lower future remediation costs as more of the impacted products age and near the end of the support period covered by the remediation program. The liability related to this matter as of January 28, 2017 and July 30, 2016 was $105 million and $276 million, respectively.

- added (2017-02-21):
[0000858877-17-000004:note_history:16]
In addition, during the second quarter of fiscal 2017, the Company recorded a charge to product cost of sales of $125 million related to the expected remediation costs for anticipated failures in future periods of a widely-used clock-signal component sourced from a third party which is included in several of the Company’s products.

- added (2017-02-21):
[0000858877-17-000004:note_history:17]
The Company believes that the service providers have strong defenses and arguments that the Company's products do not infringe the patents and/or that Sprint's patents are invalid and/or that Sprint’s damages claims are inconsistent with prevailing law. Due to the uncertainty surrounding the litigation process, which involves numerous defendants, the Company is unable to reasonably estimate the ultimate outcome of this litigation at this time. Should Sprint prevail in litigation, mediation, or settlement, the Company, in accordance with its agreements, may have an obligation to indemnify its service provider customers for damages, mediation awards, or settlement amounts arising from their use of Cisco products. At this time, the Company does not anticipate that its obligations regarding the final outcome of the matters would be material.

- changed (2017-02-21):
[0000858877-17-000004:note_history:18]
Brazil    Brazilian authorities have investigated the Company’s Brazilian subsidiary and certain of its former employees, as well as a Brazilian importer of the Company’s products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against the Company’s Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years.
  (was, 2016-11-22, similarity 0.9921):
[0000858877-16-000123:note_history:18]
Brazil    Brazilian authorities have investigated the Company’s Brazilian subsidiary and certain of its current and former employees, as well as a Brazilian importer of the Company’s products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against the Company’s Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years.

- added (2017-02-21):
[0000858877-17-000004:note_history:19]
The asserted claims by Brazilian federal tax authorities that remain are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $258 million for the alleged evasion of import and other taxes, $1.4 billion for interest, and $1.2 billion for various penalties, all determined using an exchange rate as of January 28, 2017. The Company has completed a thorough review of the matters and believes the asserted claims against the Company’s Brazilian subsidiary are without merit, and the Company is defending the claims vigorously. While the Company believes there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, the Company is unable to determine the likelihood of an unfavorable outcome against its Brazilian subsidiary and is unable to reasonably estimate a range of loss, if any. The Company does not expect a final judicial determination for several years.

- changed (2017-02-21):
[0000858877-17-000004:note_history:20]
SSL     SSL Services, LLC (“SSL”) has asserted claims for patent infringement against the Company in the U.S. District Court for the Eastern District of Texas. The proceeding was instituted on March 25, 2015. SSL alleges that the Company's AnyConnect products that include Virtual Private Networking functions infringed a U.S. patent owned by SSL. SSL seeks money damages from the Company. On August 18, 2015, Cisco petitioned the Patent Trial and Appeal Board (“PTAB”) of the United States Patent and Trademark Office to review whether the patent SSL has asserted against the Company is valid over prior art. On February 23, 2016, a PTAB multi-judge panel found a reasonable likelihood that Cisco would prevail in showing that SSL’s patent claims are unpatentable and instituted proceedings. The PTAB held a hearing to review the Company's petition on November 15, 2016 and a decision is expected by February 23, 2017. The district court issued an order on June 28, 2016 staying the district court case pending the final written decision from the PTAB. The Company believes it has strong arguments that the Company's products do not infringe and the patent is invalid. If the Company does not prevail and a jury were to find that the Company's AnyConnect products infringe, the Company believes damages, as appropriately measured, would be immaterial. Due to uncertainty surrounding patent litigation processes, however, the Company is unable to reasonably estimate the ultimate outcome of this litigation at this time.
  (was, 2016-11-22, similarity 0.978):
[0000858877-16-000123:note_history:20]
SSL     SSL Services, LLC (“SSL”) has asserted claims for patent infringement against the Company in the U.S. District Court for the Eastern District of Texas. The proceeding was instituted on March 25, 2015. SSL alleges that the Company's AnyConnect products that include Virtual Private Networking functions infringed a U.S. patent owned by SSL. SSL seeks money damages from the Company. On August 18, 2015, Cisco petitioned the Patent Trial and Appeal Board (“PTAB”) of the United States Patent and Trademark Office to review whether the patent SSL has asserted against the Company is valid over prior art. On February 23, 2016, a PTAB multi-judge panel found a reasonable likelihood that Cisco would prevail in showing that SSL’s patent claims are unpatentable and instituted proceedings. The PTAB held a hearing to review the Company's petition on November 15, 2016 and we are awaiting a decision. The district court issued an order on June 28, 2016 staying the district court case pending the final written decision from the PTAB. The Company believes it has strong arguments that the Company's products do not infringe and the patent is invalid. If the Company does not prevail and a jury were to find that the Company's AnyConnect products infringe, the Company believes damages, as appropriately measured, would be immaterial. Due to uncertainty surrounding patent litigation processes, however, the Company is unable to reasonably estimate the ultimate outcome of this litigation at this time.

- added (2017-02-21):
[0000858877-17-000004:note_history:21]
Kangtega     Cisco Systems GmbH (“Cisco GmbH”) was subject to patent claims by Kangtega GmbH (“Kangtega”), instituted on June 6, 2013, alleging that Cisco GmbH infringed in Germany a European Patent by marketing in Germany network intrusion-detection (or firewall) products known as the “ASA” firewall offering. On April 29, 2014, the Mannheim Regional Court dismissed the infringement action, finding no infringement by Cisco GmbH of the asserted patent. On November 23, 2016, a court of appeal in Germany (Oberlandesgericht Karlsruhe) heard an appeal of that judgment and the parties thereafter executed a settlement agreement resolving all aspects of the proceedings. The resolution did not have a material impact on the Company's results of operations.

- removed (2017-02-21):
[0000858877-16-000123:note_history:22]
|  | October 29, 2016 |  | July 30, 2016 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 248 |  |  | $ | 281 |  |
| End user | 88 |  |  | 96 |  |
| Total | $ | 336 |  |  | $ | 377 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (77 | ) |  | $ | (85 | ) |
| End user | (70 | ) |  | (76 | ) |
| Total | $ | (147 | ) |  | $ | (161 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue | $ | 189 |  |  | $ | 216 |  |

- removed (2017-02-21):
[0000858877-16-000123:note_history:23]
The Company has recorded in other current liabilities a liability for the expected remediation cost for certain products sold in prior fiscal years containing memory components manufactured by a single supplier between 2005 and 2010. These components were widely used across the industry and are included in a number of the Company's products. Defects in some of these components have caused products to fail after a power cycle event.  Defect rates due to this issue have been and are expected to be low. However, the Company has seen a small number of its customers experience a growing number of failures in their networks as a result of this component problem. Although the majority of these products were beyond the Company's warranty terms, the Company has been proactively working with customers on mitigation.  Prior to the second quarter of fiscal 2014, the Company had a liability of $63 million related to this issue for expected remediation costs based on the intended approach at that time. In February 2014, on the basis of the growing number of failures described above, the Company decided to expand its approach, which resulted in a charge to product cost of sales of $655 million being recorded for the second quarter of fiscal 2014. During fiscal 2016 and 2015, adjustments to product cost of sales of $74 million and $164 million, respectively, were recorded to reduce the liability, reflecting net lower than previously estimated future costs to remediate the impacted customer products. The supplier component remediation liability as of October 29, 2016 and July 30, 2016 was $265 million and $276 million, respectively.

- removed (2017-02-21):
[0000858877-16-000123:note_history:24]
The Company believes that the service providers have strong defenses and arguments that the Company's products do not infringe the patents and/or that Sprint's patents are invalid.  Due to the uncertainty surrounding the litigation process, which involves numerous defendants, the Company is unable to reasonably estimate the ultimate outcome of this litigation at this time.  Should Sprint prevail in litigation, mediation, or settlement, the Company, in accordance with its agreements, may have an obligation to indemnify its service provider customers for damages, mediation awards, or settlement amounts arising from their use of Cisco products. At this time, the Company does not anticipate that the outcome of the matters would be material.

- removed (2017-02-21):
[0000858877-16-000123:note_history:25]
The asserted claims by Brazilian federal tax authorities that remain are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $253 million for the alleged evasion of import and other taxes, $1.3 billion for interest, and $1.2 billion for various penalties, all determined using an exchange rate as of October 29, 2016. The Company has completed a thorough review of the matters and believes the asserted claims against the Company’s Brazilian subsidiary are without merit, and the Company is defending the claims vigorously. While the Company believes there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, the Company is unable to determine the likelihood of an unfavorable outcome against its Brazilian subsidiary and is unable to reasonably estimate a range of loss, if any. The Company does not expect a final judicial determination for several years.

- removed (2017-02-21):
[0000858877-16-000123:note_history:26]
Backflip Software     Backflip Software, Inc. brought claims against the Company as disclosed in the Company’s Form 10-K filed on September 8, 2016. Prior to the commencement of trial set for September 12, 2016, the parties executed a Settlement and Release Agreement resolving all aspects of the case and the Court dismissed the case in its entirety on October 17, 2016. The settlement did not have a material impact on the Company's results of operations.

- removed (2017-02-21):
[0000858877-16-000123:note_history:27]
Kangtega     Cisco Systems GmbH (“Cisco GmbH”) is subject to patent claims by Kangtega GmbH (“Kangtega”), instituted on June 6, 2013, alleging that Cisco GmbH infringes in Germany a European Patent by marketing in Germany network intrusion-detection (or firewall) products known as the “ASA” firewall offering. On April 29, 2014, the Mannheim Regional Court dismissed the infringement action, finding no infringement by Cisco GmbH of the asserted patent. On November 23, 2016, a court of appeal in Germany (Oberlandesgericht Karlsruhe) will hear an appeal of that judgment. The matter had been set for July 13, 2016, but that hearing was postponed until November 23, 2016. In addition, on July 25, 2016 the German Federal Patent Court issued its grounds for a decision denying Cisco’s nullity request with respect to the Kangtega patent. The nullity decision, which is open to appeal, regards patent validity and was issued in a separate proceeding from the infringement action in which Cisco has previously prevailed. In the infringement action, Kangtega seeks an injunction which would prohibit Cisco GmbH’s activities in Germany with respect to the ASA firewall offering unless Cisco GmbH takes a license from Kangtega or the Company redesigns the products.  The Company believes that the lower court ruling in Cisco's favor in the infringement action was correct and should be affirmed.  The Company does not anticipate that the outcome of the case would be material. However, due to uncertainty surrounding the litigation process, the Company is unable to reasonably estimate the outcome of the appeal and any subsequent appeals to a higher court at this time.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2017-02-21):
[0000858877-17-000004:note_history:28]
The accompanying financial data as of January 28, 2017 and for the three and six months ended January 28, 2017 and January 23, 2016 has been prepared by the Company, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission ("SEC"). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States ("GAAP") have been condensed or omitted pursuant to such rules and regulations. The July 30, 2016 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, the Company believes that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended July 30, 2016.
  (was, 2016-11-22, similarity 0.9637):
[0000858877-16-000123:note_history:28]
The accompanying financial data as of October 29, 2016 and for the three months ended October 29, 2016 and October 24, 2015 has been prepared by the Company, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission ("SEC"). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States ("GAAP") have been condensed or omitted pursuant to such rules and regulations. The July 30, 2016 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, the Company believes that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended July 30, 2016.

- added (2017-02-21):
[0000858877-17-000004:note_history:29]
In the opinion of management, all normal recurring adjustments necessary to present fairly the consolidated balance sheet as of January 28, 2017; the results of operations and the statements of comprehensive income for the three and six months ended January 28, 2017 and January 23, 2016; and the statements of cash flows and equity for the six months ended January 28, 2017 and January 23, 2016, as applicable, have been made. The results of operations for the three and six months ended January 28, 2017 are not necessarily indicative of the operating results for the full fiscal year or any future periods.

- removed (2017-02-21):
[0000858877-16-000123:note_history:30]
In the opinion of management, all normal recurring adjustments necessary to present fairly the consolidated balance sheet as of October 29, 2016; the results of operations, the statements of comprehensive income, the statements of cash flows and equity for the three months ended October 29, 2016 and October 24, 2015 as applicable, have been made. The results of operations for the three months ended October 29, 2016 are not necessarily indicative of the operating results for the full fiscal year or any future periods.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2017-02-21):
[0000858877-17-000004:note_history:31]
Restricted Cash in Statement of Cash Flow  In November 2016, the FASB issued an accounting standard update that provides guidance on the classification and presentation of changes in restricted cash and cash equivalents in the statement of cash flows. The accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2019 using a retrospective transition method to each period presented, and early adoption is permitted. The Company does not expect that this  accounting standard update will have a material impact on its Consolidated Statements of Cash Flows.

- added (2017-02-21):
[0000858877-17-000004:note_history:32]
Definition of a Business  In January 2017, the FASB issued an accounting standard update that clarifies the definition of a business to help companies evaluate whether acquisition or disposal transactions should be accounted for as asset groups or as businesses. The accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2019 on a prospective basis. The impact of this accounting standard update will be facts and circumstances dependent, but the Company expects that in some situations transactions that were previously accounted for as business combinations  or disposal transactions will be accounted for as asset purchases or asset sales under the accounting standard update.

- added (2017-02-21):
[0000858877-17-000004:note_history:33]
Simplifying the Test for Goodwill Impairment  In January 2017, the FASB issued an accounting standard update that removes Step 2 of the goodwill impairment test, which requires the assessment of fair value of individual assets and liabilities of a reporting unit to measure goodwill impairments. Goodwill impairment will now be the amount by which a reporting unit's carrying value exceeds its fair value. The accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2021 on a prospective basis, and early adoption is permitted. The Company does not expect that this accounting standard update will impact its Consolidated Financial Statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-02-21):
[0000858877-17-000004:note_history:34]
|  | January 28, 2017 |  | July 30, 2016 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 4,151 |  |  | 1.26 | % |  | $ | 4,159 |  |  | 0.97 | % |
| Commercial paper | 300 |  |  | 0.73 | % |  | — |  |  | — |  |
| Other notes and borrowings | — |  |  | — |  |  | 1 |  |  | 2.08 | % |
| Total short-term debt | $ | 4,451 |  |  |  |  | $ | 4,160 |  |  |  |
  (was, 2016-11-22, similarity 0.8945):
[0000858877-16-000123:note_history:34]
|  | October 29, 2016 |  | July 30, 2016 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 4,155 |  |  | 1.08 | % |  | $ | 4,159 |  |  | 0.97 | % |
| Other notes and borrowings | — |  |  | — |  |  | 1 |  |  | 2.08 | % |
| Total short-term debt | $ | 4,155 |  |  |  |  | $ | 4,160 |  |  |  |

- changed (2017-02-21):
[0000858877-17-000004:note_history:35]
The Company has established a short-term debt financing program of up to $3.0 billion through the issuance of commercial paper notes. The Company uses the proceeds from the issuance of commercial paper notes for general corporate purposes. The Company had $300 million and no commercial paper notes outstanding as of January 28, 2017 and July 30, 2016, respectively.
  (was, 2016-11-22, similarity 0.7294):
[0000858877-16-000123:note_history:35]
The Company has established a short-term debt financing program of up to $3.0 billion through the issuance of commercial paper notes. The Company uses the proceeds from the issuance of commercial paper notes for general corporate purposes. The Company did not have any commercial paper notes outstanding as of each of October 29, 2016 and July 30, 2016.

- changed (2017-02-21):
[0000858877-17-000004:note_history:36]
|  |  |  | January 28, 2017 |  | July 30, 2016 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.28% | March 3, 2017 |  | $ | 1,000 |  |  | 1.29% |  | $ | 1,000 |  |  | 1.03% |
| Three-month LIBOR plus 0.60% | February 21, 2018 |  | 1,000 |  |  | 1.58% |  | 1,000 |  |  | 1.32% |
| Three-month LIBOR plus 0.31% | June 15, 2018 |  | 900 |  |  | 1.34% |  | 900 |  |  | 1.03% |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | 500 |  |  | 1.49% |  | 500 |  |  | 1.23% |
| Three-month LIBOR plus 0.34% | September 20, 2019 | (1) | 500 |  |  | 1.38% |  | — |  |  | — |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 1.10% | March 3, 2017 |  | 2,400 |  |  | 1.17% |  | 2,400 |  |  | 0.87% |
| 3.15% | March 14, 2017 |  | 750 |  |  | 1.52% |  | 750 |  |  | 1.22% |
| 1.40% | February 28, 2018 |  | 1,250 |  |  | 1.47% |  | 1,250 |  |  | 1.47% |
| 1.65% | June 15, 2018 |  | 1,600 |  |  | 1.72% |  | 1,600 |  |  | 1.72% |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 4.84% |  | 2,000 |  |  | 4.76% |
| 1.60% | February 28, 2019 |  | 1,000 |  |  | 1.67% |  | 1,000 |  |  | 1.67% |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 1.39% |  | 1,750 |  |  | 1.08% |
| 1.40% | September 20, 2019 | (1) | 1,500 |  |  | 1.48% |  | — |  |  | — |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 3.47% |  | 2,500 |  |  | 3.25% |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 2.54% |  | 1,500 |  |  | 2.54% |
| 2.20% | February 28, 2021 |  | 2,500 |  |  | 2.30% |  | 2,500 |  |  | 2.30% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 1.55% |  | 500 |  |  | 1.24% |
| 1.85% | September 20, 2021 | (1) | 2,000 |  |  | 1.90% |  | — |  |  | — |
| 3.00% | June 15, 2022 |  | 500 |  |  | 1.80% |  | 500 |  |  | 1.51% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 | (1) | 750 |  |  | 2.27% |  | — |  |  | — |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1.66% |  | 1,000 |  |  | 1.36% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 1.96% |  | 500 |  |  | 1.67% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 | (1) | 1,500 |  |  | 2.55% |  | — |  |  | — |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 34,650 |  |  |  |  | 28,400 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (145 | ) |  |  |  | (137 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 117 |  |  |  |  | 379 |  |  |  |
| Total |  |  | $ | 34,622 |  |  |  |  | $ | 28,642 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 4,151 |  |  |  |  | $ | 4,159 |  |  |  |
| Long-term debt |  |  | 30,471 |  |  |  |  | 24,483 |  |  |  |
| Total |  |  | $ | 34,622 |  |  |  |  | $ | 28,642 |  |  |  |
  (was, 2016-11-22, similarity 0.9968):
[0000858877-16-000123:note_history:36]
|  |  |  | October 29, 2016 |  | July 30, 2016 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.28% | March 3, 2017 |  | $ | 1,000 |  |  | 1.18% |  | $ | 1,000 |  |  | 1.03% |
| Three-month LIBOR plus 0.60% | February 21, 2018 |  | 1,000 |  |  | 1.48% |  | 1,000 |  |  | 1.32% |
| Three-month LIBOR plus 0.31% | June 15, 2018 |  | 900 |  |  | 1.23% |  | 900 |  |  | 1.03% |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | 500 |  |  | 1.40% |  | 500 |  |  | 1.23% |
| Three-month LIBOR plus 0.34% | September 20, 2019 | (1) | 500 |  |  | 1.24% |  | — |  |  | — |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 1.10% | March 3, 2017 |  | 2,400 |  |  | 0.93% |  | 2,400 |  |  | 0.87% |
| 3.15% | March 14, 2017 |  | 750 |  |  | 1.42% |  | 750 |  |  | 1.22% |
| 1.40% | February 28, 2018 |  | 1,250 |  |  | 1.47% |  | 1,250 |  |  | 1.47% |
| 1.65% | June 15, 2018 |  | 1,600 |  |  | 1.72% |  | 1,600 |  |  | 1.72% |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 4.78% |  | 2,000 |  |  | 4.76% |
| 1.60% | February 28, 2019 |  | 1,000 |  |  | 1.67% |  | 1,000 |  |  | 1.67% |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 1.14% |  | 1,750 |  |  | 1.08% |
| 1.40% | September 20, 2019 | (1) | 1,500 |  |  | 1.48% |  | — |  |  | — |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 3.29% |  | 2,500 |  |  | 3.25% |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 2.54% |  | 1,500 |  |  | 2.54% |
| 2.20% | February 28, 2021 |  | 2,500 |  |  | 2.30% |  | 2,500 |  |  | 2.30% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 1.31% |  | 500 |  |  | 1.24% |
| 1.85% | September 20, 2021 | (1) | 2,000 |  |  | 1.90% |  | — |  |  | — |
| 3.00% | June 15, 2022 |  | 500 |  |  | 1.56% |  | 500 |  |  | 1.51% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 | (1) | 750 |  |  | 2.27% |  | — |  |  | — |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1.42% |  | 1,000 |  |  | 1.36% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 1.72% |  | 500 |  |  | 1.67% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 | (1) | 1,500 |  |  | 2.55% |  | — |  |  | — |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 34,650 |  |  |  |  | 28,400 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (150 | ) |  |  |  | (137 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 289 |  |  |  |  | 379 |  |  |  |
| Total |  |  | $ | 34,789 |  |  |  |  | $ | 28,642 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 4,155 |  |  |  |  | $ | 4,159 |  |  |  |
| Long-term debt |  |  | 30,634 |  |  |  |  | 24,483 |  |  |  |
| Total |  |  | $ | 34,789 |  |  |  |  | $ | 28,642 |  |  |  |

- changed (2017-02-21):
[0000858877-17-000004:note_history:37]
The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to the Company’s short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of January 28, 2017, the Company was in compliance with all debt covenants.
  (was, 2016-11-22, similarity 0.92):
[0000858877-16-000123:note_history:37]
The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to the Company’s short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of October 29, 2016, the Company was in compliance with all debt covenants.

- changed (2017-02-21):
[0000858877-17-000004:note_history:38]
As of January 28, 2017, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):
  (was, 2016-11-22, similarity 0.9556):
[0000858877-16-000123:note_history:38]
As of October 29, 2016, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

- changed (2017-02-21):
[0000858877-17-000004:note_history:39]
| Fiscal Year | Amount |
| 2017 (remaining six months) | $ | 4,150 |  |
| 2018 | 4,750 |  |
| 2019 | 5,250 |  |
| 2020 | 6,000 |  |
| 2021 | 3,000 |  |
| Thereafter | 11,500 |  |
| Total | $ | 34,650 |  |
  (was, 2016-11-22, similarity 0.9836):
[0000858877-16-000123:note_history:39]
| Fiscal Year | Amount |
| 2017 (remaining nine months) | $ | 4,150 |  |
| 2018 | 4,750 |  |
| 2019 | 5,250 |  |
| 2020 | 6,000 |  |
| 2021 | 3,000 |  |
| Thereafter | 11,500 |  |
| Total | $ | 34,650 |  |

- changed (2017-02-21):
[0000858877-17-000004:note_history:40]
The Company may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and/or extend the expiration date of the credit facility up to May 15, 2022. As of January 28, 2017, the Company was in compliance with the required interest coverage ratio and the other covenants, and the Company had not borrowed any funds under the credit facility.
  (was, 2016-11-22, similarity 0.9854):
[0000858877-16-000123:note_history:40]
The Company may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and/or extend the expiration date of the credit facility up to May 15, 2022. As of October 29, 2016, the Company was in compliance with the required interest coverage ratio and the other covenants, and the Company had not borrowed any funds under the credit facility.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2017-02-21):
[0000858877-17-000004:note_history:41]
| January 28, 2017 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| Fixed income securities: |  |  |  |  |  |  |  |
| U.S. government securities | $ | 22,910 |  |  | $ | 4 |  |  | $ | (82 | ) |  | $ | 22,832 |  |
| U.S. government agency securities | 2,401 |  |  | 1 |  |  | (5 | ) |  | 2,397 |  |
| Non-U.S. government and agency securities | 1,211 |  |  | — |  |  | (6 | ) |  | 1,205 |  |
| Corporate debt securities | 30,878 |  |  | 85 |  |  | (265 | ) |  | 30,698 |  |
| U.S. agency mortgage-backed securities | 2,031 |  |  | 2 |  |  | (27 | ) |  | 2,006 |  |
| Commercial paper | 195 |  |  | — |  |  | — |  |  | 195 |  |
| Total fixed income securities | 59,626 |  |  | 92 |  |  | (385 | ) |  | 59,333 |  |
| Publicly traded equity securities | 1,225 |  |  | 463 |  |  | (74 | ) |  | 1,614 |  |
| Total (1) | $ | 60,851 |  |  | $ | 555 |  |  | $ | (459 | ) |  | $ | 60,947 |  |

- changed (2017-02-21):
[0000858877-17-000004:note_history:42]
(1) Includes investments that were pending settlement as of the respective fiscal years. The net unsettled investment purchases were $6 million and $654 million as of January 28, 2017 and July 30, 2016, respectively.
  (was, 2016-11-22, similarity 0.9655):
[0000858877-16-000123:note_history:42]
(1) Includes investments that were pending settlement as of the respective fiscal years. The net unsettled investment purchases were $328 million and $654 million as of October 29, 2016 and July 30, 2016, respectively.

- changed (2017-02-21):
[0000858877-17-000004:note_history:43]
|  | Three Months Ended |  | Six Months Ended |
|  | January 28, 2017 |  | January 23, 2016 |  | January 28, 2017 |  | January 23, 2016 |
| Gross realized gains | $ | 18 |  |  | $ | 16 |  |  | $ | 48 |  |  | $ | 51 |  |
| Gross realized losses | (48 | ) |  | (35 | ) |  | (63 | ) |  | (71 | ) |
| Total | $ | (30 | ) |  | $ | (19 | ) |  | $ | (15 | ) |  | $ | (20 | ) |
  (was, 2016-11-22, similarity 0.6905):
[0000858877-16-000123:note_history:43]
|  | Three Months Ended |
|  | October 29, 2016 |  | October 24, 2015 |
| Gross realized gains | $ | 30 |  |  | $ | 35 |  |
| Gross realized losses | (15 | ) |  | (36 | ) |
| Total | $ | 15 |  |  | $ | (1 | ) |

- added (2017-02-21):
[0000858877-17-000004:note_history:44]
|  | Three Months Ended |  | Six Months Ended |
|  | January 28, 2017 |  | January 23, 2016 |  | January 28, 2017 |  | January 23, 2016 |
| Net gains (losses) on investments in publicly traded equity securities | $ | 4 |  |  | $ | 2 |  |  | $ | 9 |  |  | $ | (7 | ) |
| Net gains (losses) on investments in fixed income securities | (34 | ) |  | (21 | ) |  | (24 | ) |  | (13 | ) |
| Total | $ | (30 | ) |  | $ | (19 | ) |  | $ | (15 | ) |  | $ | (20 | ) |

- changed (2017-02-21):
[0000858877-17-000004:note_history:45]
The following tables present the breakdown of the available-for-sale investments with gross unrealized losses and the duration that those losses had been unrealized at January 28, 2017 and July 30, 2016 (in millions):
  (was, 2016-11-22, similarity 0.9662):
[0000858877-16-000123:note_history:45]
The following tables present the breakdown of the available-for-sale investments with gross unrealized losses and the duration that those losses had been unrealized at October 29, 2016 and July 30, 2016 (in millions):

- added (2017-02-21):
[0000858877-17-000004:note_history:46]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| January 28, 2017 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| Fixed income securities: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | $ | 16,303 |  |  | $ | (82 | ) |  | $ | 16 |  |  | $ | — |  |  | $ | 16,319 |  |  | $ | (82 | ) |
| U.S. government agency securities | 1,430 |  |  | (5 | ) |  | — |  |  | — |  |  | 1,430 |  |  | (5 | ) |
| Non-U.S. government and agency securities | 1,107 |  |  | (6 | ) |  | 6 |  |  | — |  |  | 1,113 |  |  | (6 | ) |
| Corporate debt securities | 15,180 |  |  | (264 | ) |  | 325 |  |  | (1 | ) |  | 15,505 |  |  | (265 | ) |
| U.S. agency mortgage-backed securities | 1,780 |  |  | (27 | ) |  | — |  |  | — |  |  | 1,780 |  |  | (27 | ) |
| Total fixed income securities | 35,800 |  |  | (384 | ) |  | 347 |  |  | (1 | ) |  | 36,147 |  |  | (385 | ) |
| Publicly traded equity securities | 63 |  |  | (6 | ) |  | 94 |  |  | (68 | ) |  | 157 |  |  | (74 | ) |
| Total | $ | 35,863 |  |  | $ | (390 | ) |  | $ | 441 |  |  | $ | (69 | ) |  | $ | 36,304 |  |  | $ | (459 | ) |

- changed (2017-02-21):
[0000858877-17-000004:note_history:47]
As of January 28, 2017, for fixed income securities that were in unrealized loss positions, the Company has determined that (i) it does not have the intent to sell any of these investments and (ii) it is not more likely than not that it will be required to sell any of these investments before recovery of the entire amortized cost basis. In addition, as of January 28, 2017, the Company anticipates that it will recover the entire amortized cost basis of such fixed income securities and has determined that no other-than-temporary impairments associated with credit losses were required to be recognized during the six months ended January 28, 2017.
  (was, 2016-11-22, similarity 0.9385):
[0000858877-16-000123:note_history:47]
As of October 29, 2016, for fixed income securities that were in unrealized loss positions, the Company has determined that (i) it does not have the intent to sell any of these investments and (ii) it is not more likely than not that it will be required to sell any of these investments before recovery of the entire amortized cost basis. In addition, as of October 29, 2016, the Company anticipates that it will recover the entire amortized cost basis of such fixed income securities and has determined that no other-than-temporary impairments associated with credit losses were required to be recognized during the three months ended October 29, 2016.

- changed (2017-02-21):
[0000858877-17-000004:note_history:48]
The Company has evaluated its publicly traded equity securities as of January 28, 2017 and has determined that there were no other-than-temporary impairments in the respective categories of unrealized losses. This determination was based on several factors, which include the length of time and extent to which fair value has been less than the cost basis, the financial condition and near-term prospects of the issuer, and the Company’s intent and ability to hold the publicly traded equity securities for a period of time sufficient to allow for any anticipated recovery in market value.
  (was, 2016-11-22, similarity 0.967):
[0000858877-16-000123:note_history:48]
The Company has evaluated its publicly traded equity securities as of October 29, 2016 and has determined that there was no indication of other-than-temporary impairments in the respective categories of unrealized losses. This determination was based on several factors, which include the length of time and extent to which fair value has been less than the cost basis, the financial condition and near-term prospects of the issuer, and the Company’s intent and ability to hold the publicly traded equity securities for a period of time sufficient to allow for any anticipated recovery in market value.

- changed (2017-02-21):
[0000858877-17-000004:note_history:49]
The following table summarizes the maturities of the Company’s fixed income securities as of January 28, 2017 (in millions):
  (was, 2016-11-22, similarity 0.9496):
[0000858877-16-000123:note_history:49]
The following table summarizes the maturities of the Company’s fixed income securities as of October 29, 2016 (in millions):

- changed (2017-02-21):
[0000858877-17-000004:note_history:50]
Actual maturities may differ from the contractual maturities because borrowers may have the right to call or prepay certain obligations.
  (was, 2016-11-22, similarity 0.6974):
[0000858877-16-000123:note_history:50]
Actual maturities may differ from the contractual maturities because borrowers may have the right to call or prepay certain obligations. The remaining contractual principal maturities for mortgage-backed securities were allocated assuming no prepayments.

- changed (2017-02-21):
[0000858877-17-000004:note_history:51]
The Company periodically engages in securities lending activities with certain of its available for sale investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. The average daily balance of securities lending for the six months ended January 28, 2017 and January 23, 2016 was $1.5 billion and $0.6 billion, respectively. The Company requires collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. The Company engages in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify the Company against collateral losses. The Company did not experience any losses in connection with the secured lending of securities during the periods presented. As of January 28, 2017 and July 30, 2016, the Company had no outstanding securities lending transactions.
  (was, 2016-11-22, similarity 0.9645):
[0000858877-16-000123:note_history:51]
The Company periodically engages in securities lending activities with certain of its available for sale investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. The average daily balance of securities lending for the three months ended October 29, 2016 and October 24, 2015 was $1.5 billion and $0.5 billion, respectively. The Company requires collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. The Company engages in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify the Company against collateral losses. The Company did not experience any losses in connection with the secured lending of securities during the periods presented. As of October 29, 2016 and July 30, 2016, the Company had no outstanding securities lending transactions.

- changed (2017-02-21):
[0000858877-17-000004:note_history:52]
The carrying value of the Company’s investments in privately held companies was included in other assets. For such investments that were accounted for under the equity and cost method as of January 28, 2017 and July 30, 2016, the amounts are summarized in the following table (in millions):
  (was, 2016-11-22, similarity 0.9749):
[0000858877-16-000123:note_history:52]
The carrying value of the Company’s investments in privately held companies was included in other assets.  For such investments that were accounted for under the equity and cost method as of October 29, 2016 and July 30, 2016, the amounts are summarized in the following table (in millions):

- changed (2017-02-21):
[0000858877-17-000004:note_history:53]
|  | January 28, 2017 |  | July 30, 2016 |
| Equity method investments | $ | 176 |  |  | $ | 174 |  |
| Cost method investments | 831 |  |  | 829 |  |
| Total | $ | 1,007 |  |  | $ | 1,003 |  |
  (was, 2016-11-22, similarity 0.9615):
[0000858877-16-000123:note_history:53]
|  | October 29, 2016 |  | July 30, 2016 |
| Equity method investments | $ | 162 |  |  | $ | 174 |  |
| Cost method investments | 829 |  |  | 829 |  |
| Total | $ | 991 |  |  | $ | 1,003 |  |

- changed (2017-02-21):
[0000858877-17-000004:note_history:54]
Variable Interest Entities  In the ordinary course of business, the Company has investments in privately held companies and provides financing to certain customers. These privately held companies and customers may be considered to be variable interest entities. The Company evaluates on an ongoing basis its investments in these privately held companies and its customer financings, and has determined that as of January 28, 2017, except as disclosed in Note 1, there were no significant variable interest entities required to be consolidated in the Company’s Consolidated Financial Statements.
  (was, 2016-11-22, similarity 0.9881):
[0000858877-16-000123:note_history:54]
Variable Interest Entities  In the ordinary course of business, the Company has investments in privately held companies and provides financing to certain customers. These privately held companies and customers may be considered to be variable interest entities. The Company evaluates on an ongoing basis its investments in these privately held companies and its customer financings, and has determined that as of October 29, 2016, except as disclosed in Note 1, there were no significant variable interest entities required to be consolidated in the Company’s Consolidated Financial Statements.

- changed (2017-02-21):
[0000858877-17-000004:note_history:55]
As discussed in Note 2, during the first quarter of fiscal 2017, the Company adopted a new accounting standard update related to the consolidation of certain types of legal entities. As of January 28, 2017, the carrying value of the Company's investments in privately held companies was $1,007 million, of which $580 million of such investments are considered to be in variable interest entities which are unconsolidated. In addition, the Company has additional funding commitments of $182 million related to these investments, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The carrying value of these investments and the additional funding commitments collectively represent the Company's maximum exposure related to these variable interest entities.
  (was, 2016-11-22, similarity 0.9915):
[0000858877-16-000123:note_history:55]
As discussed in Note 2, during the first quarter of fiscal 2017, the Company adopted a new accounting standard update related to the consolidation of certain types of legal entities. As of October 29, 2016, the carrying value of the Company's investments in privately held companies was $991 million, of which $609 million of such investments are considered to be in variable interest entities which are unconsolidated. In addition, the Company has additional funding commitments of $189 million related to these investments, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The carrying value of these investments and the additional funding commitments collectively represent the Company's maximum exposure related to these variable interest entities.

- removed (2017-02-21):
[0000858877-16-000123:note_history:56]
| October 29, 2016 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| Fixed income securities: |  |  |  |  |  |  |  |
| U.S. government securities | $ | 25,905 |  |  | $ | 24 |  |  | $ | (33 | ) |  | $ | 25,896 |  |
| U.S. government agency securities | 2,619 |  |  | 4 |  |  | (1 | ) |  | 2,622 |  |
| Non-U.S. government and agency securities | 1,104 |  |  | 1 |  |  | (1 | ) |  | 1,104 |  |
| Corporate debt securities | 29,046 |  |  | 177 |  |  | (60 | ) |  | 29,163 |  |
| U.S. agency mortgage-backed securities | 2,069 |  |  | 16 |  |  | (2 | ) |  | 2,083 |  |
| Total fixed income securities | 60,743 |  |  | 222 |  |  | (97 | ) |  | 60,868 |  |
| Publicly traded equity securities | 1,225 |  |  | 346 |  |  | (54 | ) |  | 1,517 |  |
| Total (1) | $ | 61,968 |  |  | $ | 568 |  |  | $ | (151 | ) |  | $ | 62,385 |  |

- removed (2017-02-21):
[0000858877-16-000123:note_history:57]
|  | Three Months Ended |
|  | October 29, 2016 |  | October 24, 2015 |
| Net gains/(losses) on investments in publicly traded equity securities | $ | 5 |  |  | $ | (9 | ) |
| Net gains/(losses) on investments in fixed income securities | 10 |  |  | 8 |  |
| Total | $ | 15 |  |  | $ | (1 | ) |

- removed (2017-02-21):
[0000858877-16-000123:note_history:58]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| October 29, 2016 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| Fixed income securities: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | $ | 11,766 |  |  | $ | (33 | ) |  | $ | 100 |  |  | $ | — |  |  | $ | 11,866 |  |  | $ | (33 | ) |
| U.S. government agency securities | 596 |  |  | (1 | ) |  | — |  |  | — |  |  | 596 |  |  | (1 | ) |
| Non-U.S. government and agency securities | 498 |  |  | (1 | ) |  | — |  |  | — |  |  | 498 |  |  | (1 | ) |
| Corporate debt securities | 9,013 |  |  | (57 | ) |  | 572 |  |  | (3 | ) |  | 9,585 |  |  | (60 | ) |
| U.S. agency mortgage-backed securities | 594 |  |  | (2 | ) |  | — |  |  | — |  |  | 594 |  |  | (2 | ) |
| Total fixed income securities | 22,467 |  |  | (94 | ) |  | 672 |  |  | (3 | ) |  | 23,139 |  |  | (97 | ) |
| Publicly traded equity securities | 291 |  |  | (53 | ) |  | 3 |  |  | (1 | ) |  | 294 |  |  | (54 | ) |
| Total | $ | 22,758 |  |  | $ | (147 | ) |  | $ | 675 |  |  | $ | (4 | ) |  | $ | 23,433 |  |  | $ | (151 | ) |


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-02-21):
[0000858877-17-000004:note_history:59]
|  |  |  | January 28, 2017 |  | July 30, 2016 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.28% | March 3, 2017 |  | $ | 1,000 |  |  | 1.29% |  | $ | 1,000 |  |  | 1.03% |
| Three-month LIBOR plus 0.60% | February 21, 2018 |  | 1,000 |  |  | 1.58% |  | 1,000 |  |  | 1.32% |
| Three-month LIBOR plus 0.31% | June 15, 2018 |  | 900 |  |  | 1.34% |  | 900 |  |  | 1.03% |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | 500 |  |  | 1.49% |  | 500 |  |  | 1.23% |
| Three-month LIBOR plus 0.34% | September 20, 2019 | (1) | 500 |  |  | 1.38% |  | — |  |  | — |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 1.10% | March 3, 2017 |  | 2,400 |  |  | 1.17% |  | 2,400 |  |  | 0.87% |
| 3.15% | March 14, 2017 |  | 750 |  |  | 1.52% |  | 750 |  |  | 1.22% |
| 1.40% | February 28, 2018 |  | 1,250 |  |  | 1.47% |  | 1,250 |  |  | 1.47% |
| 1.65% | June 15, 2018 |  | 1,600 |  |  | 1.72% |  | 1,600 |  |  | 1.72% |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 4.84% |  | 2,000 |  |  | 4.76% |
| 1.60% | February 28, 2019 |  | 1,000 |  |  | 1.67% |  | 1,000 |  |  | 1.67% |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 1.39% |  | 1,750 |  |  | 1.08% |
| 1.40% | September 20, 2019 | (1) | 1,500 |  |  | 1.48% |  | — |  |  | — |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 3.47% |  | 2,500 |  |  | 3.25% |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 2.54% |  | 1,500 |  |  | 2.54% |
| 2.20% | February 28, 2021 |  | 2,500 |  |  | 2.30% |  | 2,500 |  |  | 2.30% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 1.55% |  | 500 |  |  | 1.24% |
| 1.85% | September 20, 2021 | (1) | 2,000 |  |  | 1.90% |  | — |  |  | — |
| 3.00% | June 15, 2022 |  | 500 |  |  | 1.80% |  | 500 |  |  | 1.51% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 | (1) | 750 |  |  | 2.27% |  | — |  |  | — |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1.66% |  | 1,000 |  |  | 1.36% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 1.96% |  | 500 |  |  | 1.67% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 | (1) | 1,500 |  |  | 2.55% |  | — |  |  | — |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 34,650 |  |  |  |  | 28,400 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (145 | ) |  |  |  | (137 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 117 |  |  |  |  | 379 |  |  |  |
| Total |  |  | $ | 34,622 |  |  |  |  | $ | 28,642 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 4,151 |  |  |  |  | $ | 4,159 |  |  |  |
| Long-term debt |  |  | 30,471 |  |  |  |  | 24,483 |  |  |  |
| Total |  |  | $ | 34,622 |  |  |  |  | $ | 28,642 |  |  |  |
  (was, 2016-11-22, similarity 0.9968):
[0000858877-16-000123:note_history:59]
|  |  |  | October 29, 2016 |  | July 30, 2016 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.28% | March 3, 2017 |  | $ | 1,000 |  |  | 1.18% |  | $ | 1,000 |  |  | 1.03% |
| Three-month LIBOR plus 0.60% | February 21, 2018 |  | 1,000 |  |  | 1.48% |  | 1,000 |  |  | 1.32% |
| Three-month LIBOR plus 0.31% | June 15, 2018 |  | 900 |  |  | 1.23% |  | 900 |  |  | 1.03% |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | 500 |  |  | 1.40% |  | 500 |  |  | 1.23% |
| Three-month LIBOR plus 0.34% | September 20, 2019 | (1) | 500 |  |  | 1.24% |  | — |  |  | — |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 1.10% | March 3, 2017 |  | 2,400 |  |  | 0.93% |  | 2,400 |  |  | 0.87% |
| 3.15% | March 14, 2017 |  | 750 |  |  | 1.42% |  | 750 |  |  | 1.22% |
| 1.40% | February 28, 2018 |  | 1,250 |  |  | 1.47% |  | 1,250 |  |  | 1.47% |
| 1.65% | June 15, 2018 |  | 1,600 |  |  | 1.72% |  | 1,600 |  |  | 1.72% |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 4.78% |  | 2,000 |  |  | 4.76% |
| 1.60% | February 28, 2019 |  | 1,000 |  |  | 1.67% |  | 1,000 |  |  | 1.67% |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 1.14% |  | 1,750 |  |  | 1.08% |
| 1.40% | September 20, 2019 | (1) | 1,500 |  |  | 1.48% |  | — |  |  | — |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 3.29% |  | 2,500 |  |  | 3.25% |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 2.54% |  | 1,500 |  |  | 2.54% |
| 2.20% | February 28, 2021 |  | 2,500 |  |  | 2.30% |  | 2,500 |  |  | 2.30% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 1.31% |  | 500 |  |  | 1.24% |
| 1.85% | September 20, 2021 | (1) | 2,000 |  |  | 1.90% |  | — |  |  | — |
| 3.00% | June 15, 2022 |  | 500 |  |  | 1.56% |  | 500 |  |  | 1.51% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 | (1) | 750 |  |  | 2.27% |  | — |  |  | — |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1.42% |  | 1,000 |  |  | 1.36% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 1.72% |  | 500 |  |  | 1.67% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 | (1) | 1,500 |  |  | 2.55% |  | — |  |  | — |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 34,650 |  |  |  |  | 28,400 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (150 | ) |  |  |  | (137 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 289 |  |  |  |  | 379 |  |  |  |
| Total |  |  | $ | 34,789 |  |  |  |  | $ | 28,642 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 4,155 |  |  |  |  | $ | 4,159 |  |  |  |
| Long-term debt |  |  | 30,634 |  |  |  |  | 24,483 |  |  |  |
| Total |  |  | $ | 34,789 |  |  |  |  | $ | 28,642 |  |  |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-02-21):
[0000858877-17-000004:note_history:60]
As of January 28, 2017, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):
  (was, 2016-11-22, similarity 0.9556):
[0000858877-16-000123:note_history:60]
As of October 29, 2016, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

- changed (2017-02-21):
[0000858877-17-000004:note_history:61]
| Fiscal Year | Amount |
| 2017 (remaining six months) | $ | 4,150 |  |
| 2018 | 4,750 |  |
| 2019 | 5,250 |  |
| 2020 | 6,000 |  |
| 2021 | 3,000 |  |
| Thereafter | 11,500 |  |
| Total | $ | 34,650 |  |
  (was, 2016-11-22, similarity 0.9836):
[0000858877-16-000123:note_history:61]
| Fiscal Year | Amount |
| 2017 (remaining nine months) | $ | 4,150 |  |
| 2018 | 4,750 |  |
| 2019 | 5,250 |  |
| 2020 | 6,000 |  |
| 2021 | 3,000 |  |
| Thereafter | 11,500 |  |
| Total | $ | 34,650 |  |


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2017-02-21):
[0000858877-17-000004:note_history:62]
|  | January 28, 2017 |  | July 30, 2016 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 4,151 |  |  | 1.26 | % |  | $ | 4,159 |  |  | 0.97 | % |
| Commercial paper | 300 |  |  | 0.73 | % |  | — |  |  | — |  |
| Other notes and borrowings | — |  |  | — |  |  | 1 |  |  | 2.08 | % |
| Total short-term debt | $ | 4,451 |  |  |  |  | $ | 4,160 |  |  |  |
  (was, 2016-11-22, similarity 0.8945):
[0000858877-16-000123:note_history:62]
|  | October 29, 2016 |  | July 30, 2016 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 4,155 |  |  | 1.08 | % |  | $ | 4,159 |  |  | 0.97 | % |
| Other notes and borrowings | — |  |  | — |  |  | 1 |  |  | 2.08 | % |
| Total short-term debt | $ | 4,155 |  |  |  |  | $ | 4,160 |  |  |  |
