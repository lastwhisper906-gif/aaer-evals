# CSCO notes — 0000858877-17-000004


## csco:CompensationexpensesrelatedtobusinesscombinationsTableTextBlock

[0000858877-17-000004:notes:1]
[same as prior period, unchanged from 0000858877-16-000123:notes:1]

[0000858877-17-000004:notes:2]
|  | Three Months Ended |  | Six Months Ended |
|  | January 28, 2017 |  | January 23, 2016 |  | January 28, 2017 |  | January 23, 2016 |
| Compensation expense related to acquisitions | $ | 73 |  |  | $ | 71 |  |  | $ | 137 |  |  | $ | 144 |  |


## csco:EntityWideDisclosureOnGeographicAreasLongLivedAssetsTableTextBlock

[0000858877-17-000004:notes:3]
[same as prior period, unchanged from 0000858877-16-000123:notes:3]

[0000858877-17-000004:notes:4]
|  | January 28, 2017 |  | July 30, 2016 |
| Property and equipment, net: |  |  |  |
| United States | $ | 2,797 |  |  | $ | 2,822 |  |
| International | 625 |  |  | 684 |  |
| Total | $ | 3,422 |  |  | $ | 3,506 |  |


## csco:IncometaxprovisionTableTextBlock

[0000858877-17-000004:notes:5]
[same as prior period, unchanged from 0000858877-16-000123:notes:5]

[0000858877-17-000004:notes:6]
|  | Three Months Ended |  | Six Months Ended |
|  | January 28, 2017 |  | January 23, 2016 |  | January 28, 2017 |  | January 23, 2016 |
| Income before provision for income taxes | $ | 2,963 |  |  | $ | 3,306 |  |  | $ | 5,916 |  |  | $ | 6,443 |  |
| Provision for income taxes | $ | 615 |  |  | $ | 159 |  |  | $ | 1,246 |  |  | $ | 866 |  |
| Effective tax rate | 20.8 | % |  | 4.8 | % |  | 21.1 | % |  | 13.4 | % |


## csco:NetSalesForGroupsOfSimilarProductsAndServicesTableTextBlock

[0000858877-17-000004:notes:7]
[same as prior period, unchanged from 0000858877-16-000123:notes:7]

[0000858877-17-000004:notes:8]
|  | Three Months Ended |  | Six Months Ended |
|  | January 28, 2017 |  | January 23, 2016 |  | January 28, 2017 |  | January 23, 2016 |
| Revenue: |  |  |  |  |  |  |  |
| Switching | $ | 3,305 |  |  | $ | 3,475 |  |  | $ | 7,021 |  |  | $ | 7,484 |  |
| NGN Routing | 1,817 |  |  | 2,014 |  |  | 3,906 |  |  | 3,983 |  |
| Collaboration | 1,062 |  |  | 1,019 |  |  | 2,143 |  |  | 2,134 |  |
| Data Center | 790 |  |  | 822 |  |  | 1,624 |  |  | 1,681 |  |
| Wireless | 632 |  |  | 616 |  |  | 1,264 |  |  | 1,262 |  |
| Security | 528 |  |  | 462 |  |  | 1,068 |  |  | 947 |  |
| Service Provider Video(1) | 241 |  |  | 499 |  |  | 512 |  |  | 1,186 |  |
| Other | 116 |  |  | 76 |  |  | 255 |  |  | 150 |  |
| Product | 8,491 |  |  | 8,983 |  |  | 17,793 |  |  | 18,827 |  |
| Service | 3,089 |  |  | 2,944 |  |  | 6,139 |  |  | 5,782 |  |
| Total | $ | 11,580 |  |  | $ | 11,927 |  |  | $ | 23,932 |  |  | $ | 24,609 |  |

[0000858877-17-000004:notes:9]
(1) During the second quarter of fiscal 2016, the Company completed the sale of the Customer Premises Equipment portion of its Service Provider Video Connected Devices business (“SP Video CPE Business”). As a result, revenue from this portion of the Service Provider Video product category will not recur in future periods. Includes SP Video CPE Business revenue of $93 million for the second quarter of fiscal 2016


## csco:ScheduleOfCommonStockRepurchasedTextBlock

[0000858877-17-000004:notes:10]
[same as prior period, unchanged from 0000858877-16-000123:notes:10]

[0000858877-17-000004:notes:11]
|  | SharesRepurchased |  | Weighted-Average Priceper Share |  | AmountRepurchased |
| Cumulative balance at July 30, 2016 | 4,591 |  |  | $ | 21.04 |  |  | $ | 96,597 |  |
| Repurchase of common stock under the stock repurchase program (1) | 65 |  |  | 30.72 |  |  | 2,002 |  |
| Cumulative balance at January 28, 2017 | 4,656 |  |  | $ | 21.17 |  |  | $ | 98,599 |  |

[0000858877-17-000004:notes:12]
(1) There were $56 million of stock repurchases pending settlement as of January 28, 2017. There were $45 million of stock repurchases that were pending settlement as of July 30, 2016.


## csco:ScheduleOfDerivativeFairValueHedgeInstrumentsGainLossInStatementOfFinancialPerformanceTableTextBlock

[0000858877-17-000004:notes:13]
[same as prior period, unchanged from 0000858877-16-000123:notes:13]

[0000858877-17-000004:notes:14]
|  |  |  |  | GAINS (LOSSES) ONDERIVATIVEINSTRUMENTS FOR THETHREE MONTHS ENDED |  | GAINS (LOSSES)RELATED TO HEDGEDITEMS FOR THE THREE MONTHS ENDED |
| Derivatives Designated as Fair Value Hedging Instruments |  | Line Item in Statements of Operations |  | January 28, 2017 |  | January 23, 2016 |  | January 28, 2017 |  | January 23, 2016 |
| Interest rate derivatives |  | Interest expense |  | $ | (175 | ) |  | $ | (16 | ) |  | $ | 172 |  |  | $ | 18 |  |

[0000858877-17-000004:notes:15]
|  |  |  |  | GAINS (LOSSES) ONDERIVATIVEINSTRUMENTS FOR THESIX MONTHS ENDED |  | GAINS (LOSSES)RELATED TO HEDGEDITEMS FOR THE SIX MONTHS ENDED |
| Derivatives Designated as Fair Value Hedging Instruments |  | Line Item in Statements of Operations |  | January 28, 2017 |  | January 23, 2016 |  | January 28, 2017 |  | January 23, 2016 |
| Interest rate derivatives |  | Interest expense |  | $ | (266 | ) |  | $ | 111 |  |  | $ | 262 |  |  | $ | (107 | ) |


## csco:ScheduleOfFiniteLivedIntangibleAssetsAmortizationExpenseTableTextBlock

[0000858877-17-000004:notes:16]
The following table presents the amortization of purchased intangible assets, including impairment charges (in millions):

[0000858877-17-000004:notes:17]
|  | Three Months Ended |  | Six Months Ended |
|  | January 28, 2017 |  | January 23, 2016 |  | January 28, 2017 |  | January 23, 2016 |
| Amortization of purchased intangible assets: |  |  |  |  |  |  |  |
| Cost of sales | $ | 124 |  |  | $ | 139 |  |  | $ | 253 |  |  | $ | 285 |  |
| Operating expenses |  |  |  |  |  |  |  |  |
| Amortization of purchased intangible assets | 64 |  |  | 71 |  |  | 142 |  |  | 140 |  |
| Restructuring and other charges | — |  |  | — |  |  | 38 |  |  | — |  |
| Total | $ | 188 |  |  | $ | 210 |  |  | $ | 433 |  |  | $ | 425 |  |


## csco:ScheduleOfIntangibleAssetsAcquiredAsPartOfBusinessCombinationTextBlock

[0000858877-17-000004:notes:18]
The following table presents details of the Company’s intangible assets acquired through acquisitions completed during the six months ended January 28, 2017 (in millions, except years):

[0000858877-17-000004:notes:19]
[same as prior period, unchanged from 0000858877-16-000123:notes:18]


## csco:ScheduleOfIntangibleAssetsByMajorClassTextBlock

[0000858877-17-000004:notes:20]
[same as prior period, unchanged from 0000858877-16-000123:notes:19]

[0000858877-17-000004:notes:21]
| January 28, 2017 |  | Gross |  | Accumulated Amortization |  | Net |
| Purchased intangible assets with finite lives: |  |  |  |  |  |  |
| Technology |  | $ | 2,900 |  |  | $ | (1,440 | ) |  | $ | 1,460 |  |
| Customer relationships |  | 1,303 |  |  | (846 | ) |  | 457 |  |
| Other |  | 57 |  |  | (25 | ) |  | 32 |  |
| Total purchased intangible assets with finite lives |  | 4,260 |  |  | (2,311 | ) |  | 1,949 |  |
| In-process research and development, with indefinite lives |  | 168 |  |  | — |  |  | 168 |  |
| Total |  | $ | 4,428 |  |  | $ | (2,311 | ) |  | $ | 2,117 |  |

[0000858877-17-000004:notes:22]
[same as prior period, unchanged from 0000858877-16-000123:notes:21]


## csco:SegmentReportingProductAndServicesNetSalesTextBlock

[0000858877-17-000004:notes:23]
[same as prior period, unchanged from 0000858877-16-000123:notes:22]

[0000858877-17-000004:notes:24]
[same as prior period, unchanged from 0000858877-16-000123:notes:23]

[0000858877-17-000004:notes:25]
The Company conducts business globally and is primarily managed on a geographic basis consisting of three segments: the Americas, EMEA, and APJC. The Company’s management makes financial decisions and allocates resources based on the information it receives from its internal management system. Sales are attributed to a segment based on the ordering location of the customer. The Company does not allocate research and development, sales and marketing, or general and administrative expenses to its segments in this internal management system because management does not include the information in its measurement of the performance of the operating segments. In addition, the Company does not allocate amortization and impairment of acquisition-related intangible assets, share-based compensation expense, significant litigation and other contingencies, charges related to asset impairments and restructurings, and certain other charges to the gross margin for each segment because management does not include this information in its measurement of the performance of the operating segments.

[0000858877-17-000004:notes:26]
Summarized financial information by segment for the three months ended January 28, 2017 and January 23, 2016, based on the Company’s internal management system and as utilized by the Company’s Chief Operating Decision Maker ("CODM"), is as follows (in millions):

[0000858877-17-000004:notes:27]
|  | Three Months Ended |  | Six Months Ended |
|  | January 28, 2017 |  | January 23, 2016 |  | January 28, 2017 |  | January 23, 2016 |
| Revenue: |  |  |  |  |  |  |  |
| Americas | $ | 6,660 |  |  | $ | 6,911 |  |  | $ | 14,103 |  |  | $ | 14,703 |  |
| EMEA | 3,065 |  |  | 3,093 |  |  | 6,078 |  |  | 6,187 |  |
| APJC | 1,855 |  |  | 1,923 |  |  | 3,751 |  |  | 3,719 |  |
| Total | $ | 11,580 |  |  | $ | 11,927 |  |  | $ | 23,932 |  |  | $ | 24,609 |  |
| Gross margin: |  |  |  |  |  |  |  |
| Americas | $ | 4,288 |  |  | $ | 4,411 |  |  | $ | 9,121 |  |  | $ | 9,354 |  |
| EMEA | 2,012 |  |  | 2,011 |  |  | 4,025 |  |  | 4,000 |  |
| APJC | 1,121 |  |  | 1,184 |  |  | 2,325 |  |  | 2,262 |  |
| Segment total | 7,421 |  |  | 7,606 |  |  | 15,471 |  |  | 15,616 |  |
| Unallocated corporate items | (145 | ) |  | (174 | ) |  | (311 | ) |  | (352 | ) |
| Total | $ | 7,276 |  |  | $ | 7,432 |  |  | $ | 15,160 |  |  | $ | 15,264 |  |

[0000858877-17-000004:notes:28]
Revenue in the United States was $5.9 billion and $6.0 billion for the three months ended January 28, 2017 and January 23, 2016, respectively, and was $12.5 billion and $12.9 billion for the six months ended January 28, 2017 and January 23, 2016, respectively.

[0000858877-17-000004:notes:29]
[same as prior period, unchanged from 0000858877-16-000123:notes:28]

[0000858877-17-000004:notes:30]
[same as prior period, unchanged from 0000858877-16-000123:notes:29]

[0000858877-17-000004:notes:31]
(1) During the second quarter of fiscal 2016, the Company completed the sale of the Customer Premises Equipment portion of its Service Provider Video Connected Devices business (“SP Video CPE Business”). As a result, revenue from this portion of the Service Provider Video product category will not recur in future periods. Includes SP Video CPE Business revenue of $93 million for the second quarter of fiscal 2016 and $504 million for the first six months of fiscal 2016.

[0000858877-17-000004:notes:32]
[same as prior period, unchanged from 0000858877-16-000123:notes:30]

[0000858877-17-000004:notes:33]
[same as prior period, unchanged from 0000858877-16-000123:notes:31]

[0000858877-17-000004:notes:34]
The majority of the Company’s assets, excluding cash and cash equivalents and investments, was attributable to its U.S. operations as of each of January 28, 2017 and July 30, 2016.  The Company’s total cash and cash equivalents and investments held by various foreign subsidiaries were $62.3 billion and $59.8 billion as of January 28, 2017 and July 30, 2016, respectively, and the remaining $9.6 billion and $5.9 billion at the respective period ends were available in the United States.

[0000858877-17-000004:notes:35]
[same as prior period, unchanged from 0000858877-16-000123:notes:33]


## csco:StockRepurchasesSinceInceptionOfProgramTableTextBlock

[0000858877-17-000004:notes:36]
[same as prior period, unchanged from 0000858877-16-000123:notes:34]

[0000858877-17-000004:notes:37]
|  | Shares ofCommonStock |  | Common Stockand AdditionalPaid-In Capital |  | RetainedEarnings |  | Total CiscoShareholders’Equity |
| Repurchases of common stock under the repurchase program | 4,656 |  |  | $ | 24,470 |  |  | $ | 74,129 |  |  | $ | 98,599 |  |


## us-gaap:AllowanceForCreditLossesOnFinancingReceivablesTableTextBlock

[0000858877-17-000004:notes:38]
[same as prior period, unchanged from 0000858877-16-000123:notes:36]

[0000858877-17-000004:notes:39]
|  | CREDIT LOSS ALLOWANCES |
| Three months ended January 28, 2017 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts and Other |  | Total |
| Allowance for credit loss as of October 29, 2016 | $ | 227 |  |  | $ | 111 |  |  | $ | 48 |  |  | $ | 386 |  |
| Provisions | 2 |  |  | — |  |  | (1 | ) |  | 1 |  |
| Recoveries (write-offs), net | (2 | ) |  | (4 | ) |  | — |  |  | (6 | ) |
| Foreign exchange and other | (2 | ) |  | (1 | ) |  | — |  |  | (3 | ) |
| Allowance for credit loss as of January 28, 2017 | $ | 225 |  |  | $ | 106 |  |  | $ | 47 |  |  | $ | 378 |  |

[0000858877-17-000004:notes:40]
|  | CREDIT LOSS ALLOWANCES |
| Six months ended January 28, 2017 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts and Other |  | Total |
| Allowance for credit loss as of July 30, 2016 | $ | 230 |  |  | $ | 97 |  |  | $ | 48 |  |  | $ | 375 |  |
| Provisions | (2 | ) |  | 12 |  |  | (1 | ) |  | 9 |  |
| Recoveries (write-offs), net | (2 | ) |  | (4 | ) |  | — |  |  | (6 | ) |
| Foreign exchange and other | (1 | ) |  | 1 |  |  | — |  |  | — |  |
| Allowance for credit loss as of January 28, 2017 | $ | 225 |  |  | $ | 106 |  |  | $ | 47 |  |  | $ | 378 |  |

[0000858877-17-000004:notes:41]
|  | CREDIT LOSS ALLOWANCES |
| Three months ended January 23, 2016 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts and Other |  | Total |
| Allowance for credit loss as of October 24, 2015 | $ | 255 |  |  | $ | 90 |  |  | $ | 33 |  |  | $ | 378 |  |
| Provisions | (4 | ) |  | (10 | ) |  | 5 |  |  | (9 | ) |
| Recoveries (write-offs), net | — |  |  | — |  |  | (1 | ) |  | (1 | ) |
| Foreign exchange and other | (3 | ) |  | — |  |  | — |  |  | (3 | ) |
| Allowance for credit loss as of January 23, 2016 | $ | 248 |  |  | $ | 80 |  |  | $ | 37 |  |  | $ | 365 |  |

[0000858877-17-000004:notes:42]
|  | CREDIT LOSS ALLOWANCES |
| Six months ended January 23, 2016 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts and Other |  | Total |
| Allowance for credit loss as of July 25, 2015 | $ | 259 |  |  | $ | 87 |  |  | $ | 36 |  |  | $ | 382 |  |
| Provisions | (4 | ) |  | (6 | ) |  | 5 |  |  | (5 | ) |
| Recoveries (write-offs), net | (4 | ) |  | — |  |  | (4 | ) |  | (8 | ) |
| Foreign exchange and other | (3 | ) |  | (1 | ) |  | — |  |  | (4 | ) |
| Allowance for credit loss as of January 23, 2016 | $ | 248 |  |  | $ | 80 |  |  | $ | 37 |  |  | $ | 365 |  |


## us-gaap:BasisOfAccountingPolicyPolicyTextBlock

[0000858877-17-000004:notes:43]
[same as prior period, unchanged from 0000858877-16-000123:notes:39]

[0000858877-17-000004:notes:44]
The accompanying financial data as of January 28, 2017 and for the three and six months ended January 28, 2017 and January 23, 2016 has been prepared by the Company, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission ("SEC"). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States ("GAAP") have been condensed or omitted pursuant to such rules and regulations. The July 30, 2016 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, the Company believes that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended July 30, 2016.

[0000858877-17-000004:notes:45]
[same as prior period, unchanged from 0000858877-16-000123:notes:41]

[0000858877-17-000004:notes:46]
In the opinion of management, all normal recurring adjustments necessary to present fairly the consolidated balance sheet as of January 28, 2017; the results of operations and the statements of comprehensive income for the three and six months ended January 28, 2017 and January 23, 2016; and the statements of cash flows and equity for the six months ended January 28, 2017 and January 23, 2016, as applicable, have been made. The results of operations for the three and six months ended January 28, 2017 are not necessarily indicative of the operating results for the full fiscal year or any future periods.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000858877-17-000004:notes:47]
[same as prior period, unchanged from 0000858877-16-000123:notes:43]

[0000858877-17-000004:notes:48]
The Company completed three acquisitions during the six months ended January 28, 2017. A summary of the allocation of the total purchase consideration is presented as follows (in millions):

[0000858877-17-000004:notes:49]
[same as prior period, unchanged from 0000858877-16-000123:notes:45]

[0000858877-17-000004:notes:50]
[same as prior period, unchanged from 0000858877-16-000123:notes:46]

[0000858877-17-000004:notes:51]
The total purchase consideration related to the Company’s acquisitions completed during the six months ended January 28, 2017 consisted of cash consideration and vested share-based awards assumed. The total cash and cash equivalents acquired from these acquisitions was approximately $1 million. Total transaction costs related to the Company’s acquisition activities were $3 million and $14 million for the six months ended January 28, 2017 and January 23, 2016, respectively. These transaction costs were expensed as incurred in general and administrative expenses ("G&A") in the Consolidated Statements of Operations.

[0000858877-17-000004:notes:52]
[same as prior period, unchanged from 0000858877-16-000123:notes:48]

[0000858877-17-000004:notes:53]
The goodwill generated from the Company’s acquisitions completed during the six months ended January 28, 2017 is primarily related to expected synergies. The goodwill is generally not deductible for income tax purposes.

[0000858877-17-000004:notes:54]
The Consolidated Financial Statements include the operating results of each acquisition from the date of acquisition. Pro forma results of operations for the acquisitions completed during the six months ended January 28, 2017 have not been presented because the effects of the acquisitions, individually and in the aggregate, were not material to the Company’s financial results.

[0000858877-17-000004:notes:55]
Pending Acquisition of AppDynamics  On January 24, 2017, the Company announced its intent to acquire privately held AppDynamics, Inc. ("AppDynamics"), an application intelligence software company. AppDynamics's cloud application and business monitoring platform is designed to enable companies to improve application and business performance. Under the terms of the agreement, the Company will pay approximately $3.7 billion in cash and assumed equity awards to acquire AppDynamics. With the AppDynamics acquisition, the Company seeks to provide end-to-end visibility and intelligence from the customers' network through to the application. The acquisition is expected to close in the third quarter of fiscal 2017.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000858877-17-000004:notes:56]
Commitments and Contingencies

[0000858877-17-000004:notes:57]
| (a) | Operating Leases |

[0000858877-17-000004:notes:58]
The Company leases office space in many U.S. locations. Outside the United States, larger leased sites include sites in Belgium, Canada, China, France, Germany, India, Israel, Japan, Poland and the United Kingdom. The Company also leases equipment and vehicles. Future minimum lease payments under all noncancelable operating leases with an initial term in excess of one year as of January 28, 2017 are as follows (in millions):

[0000858877-17-000004:notes:59]
| Fiscal Year | Amount |
| 2017 (remaining six months) | $ | 213 |  |
| 2018 | 334 |  |
| 2019 | 208 |  |
| 2020 | 142 |  |
| 2021 | 83 |  |
| Thereafter | 175 |  |
| Total | $ | 1,155 |  |

[0000858877-17-000004:notes:60]
| (b) | Purchase Commitments with Contract Manufacturers and Suppliers |

[0000858877-17-000004:notes:61]
The Company purchases components from a variety of suppliers and uses several contract manufacturers to provide manufacturing services for its products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, the Company enters into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by the Company or establish the parameters defining the Company’s requirements.  A significant portion of the Company’s reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. In certain instances, these agreements allow the Company the option to cancel, reschedule, and adjust the Company’s requirements based on its business needs prior to firm orders being placed.  As of January 28, 2017 and July 30, 2016, the Company had total purchase commitments for inventory of $4,402 million and $3,896 million, respectively.

[0000858877-17-000004:notes:62]
The Company records a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of its future demand forecasts consistent with the valuation of the Company’s excess and obsolete inventory. As of January 28, 2017 and July 30, 2016, the liability for these purchase commitments was $172 million and $159 million, respectively, and was included in other current liabilities.

[0000858877-17-000004:notes:63]
| (c) | Other Commitments |

[0000858877-17-000004:notes:64]
In connection with the Company’s acquisitions, the Company has agreed to pay certain additional amounts contingent upon the achievement of certain agreed-upon technology, development, product, or other milestones or upon the continued employment with the Company of certain employees of the acquired entities.

[0000858877-17-000004:notes:65]
As of January 28, 2017, the Company estimated that future cash compensation expense of up to $220 million may be required to be recognized pursuant to the applicable business combination agreements, which included the remaining potential compensation expense related to Insieme Networks, Inc. ("Insieme"), as more fully discussed immediately below.

[0000858877-17-000004:notes:66]
Insieme Networks, Inc.    In the third quarter of fiscal 2012, the Company made an investment in Insieme, an early stage company focused on research and development in the data center market. As set forth in the agreement between the Company and Insieme, this investment included $100 million of funding and a license to certain of the Company’s technology. Immediately prior to the call option exercise and acquisition described below, the Company owned approximately 83% of Insieme as a result of these investments and has consolidated the results of Insieme in its Consolidated Financial Statements. In connection with this investment, the Company and Insieme entered into a put/call option agreement that provided the Company with the right to purchase the remaining interests in Insieme.  In addition, the noncontrolling interest holders could require the Company to purchase their shares upon the occurrence of certain events.

[0000858877-17-000004:notes:67]
During the first quarter of fiscal 2014, the Company exercised its call option and entered into an agreement to purchase the remaining interests in Insieme. The acquisition closed in the second quarter of fiscal 2014, at which time the former noncontrolling interest holders became eligible to receive up to two milestone payments, which will be determined using agreed-upon formulas based primarily on revenue for certain of Insieme’s products. The Company recorded compensation expense of $12 million and $50 million during the three months ended January 28, 2017 and January 23, 2016, respectively, and $32 million and $101 million during the six months ended January 28, 2017 and January 23, 2016, respectively, related to the fair value of the vested portion of amounts that were earned or are expected to be earned by the former noncontrolling interest holders. Continued vesting will result in additional compensation expense in future periods. Based on the terms of the agreement, the Company has determined that the maximum amount that could be recorded as compensation expense by the Company is approximately $831 million (which includes the $815 million that has been expensed to date), net of forfeitures. The former noncontrolling interest holders earned the maximum amount related to these two milestone payments and were paid approximately $422 million and $354 million during the six months ended January 28, 2017 and January 23, 2016, respectively.  As of January 28, 2017, the Company paid a total of approximately $811 million pursuant to these two milestone payments.

[0000858877-17-000004:notes:68]
| (d) | Product Warranties |

[0000858877-17-000004:notes:69]
The following table summarizes the activity related to the product warranty liability (in millions):

[0000858877-17-000004:notes:70]
|  | Six Months Ended |
|  | January 28, 2017 |  | January 23, 2016 |
| Balance at beginning of period | $ | 414 |  |  | $ | 449 |  |
| Provisions for warranty issued | 367 |  |  | 335 |  |
| Adjustments for pre-existing warranties | (3 | ) |  | (13 | ) |
| Settlements | (352 | ) |  | (340 | ) |
| Divestitures | — |  |  | (28 | ) |
| Balance at end of period | $ | 426 |  |  | $ | 403 |  |

[0000858877-17-000004:notes:71]
The Company accrues for warranty costs as part of its cost of sales based on associated material product costs, labor costs for technical support staff, and associated overhead. The Company’s products are generally covered by a warranty for periods ranging from 90 days to five years, and for some products the Company provides a limited lifetime warranty.

[0000858877-17-000004:notes:72]
| (e) | Financing and Other Guarantees |

[0000858877-17-000004:notes:73]
In the ordinary course of business, the Company provides financing guarantees for various third-party financing arrangements extended to channel partners and end-user customers. Payments under these financing guarantee arrangements were not material for the periods presented.

[0000858877-17-000004:notes:74]
Channel Partner Financing Guarantees   The Company facilitates arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, generally with payment terms ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, the Company guarantees a portion of these arrangements. The volume of channel partner financing was $6.3 billion and $6.5 billion for the three months ended January 28, 2017 and January 23, 2016, respectively, and was $13.2 billion and $13.4 billion for the six months ended January 28, 2017 and January 23, 2016, respectively. The balance of the channel partner financing subject to guarantees was $1.2 billion and $1.1 billion as of January 28, 2017 and July 30, 2016, respectively.

[0000858877-17-000004:notes:75]
End-User Financing Guarantees   The Company also provides financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. The volume of financing provided by third parties for leases and loans as to which the Company had provided guarantees was $30 million and $16 million for the three months ended January 28, 2017 and January 23, 2016, respectively, and was $36 million and $39 million for the six months ended January 28, 2017 and January 23, 2016, respectively.

[0000858877-17-000004:notes:76]
Financing Guarantee Summary   The aggregate amounts of financing guarantees outstanding at January 28, 2017 and July 30, 2016, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

[0000858877-17-000004:notes:77]
|  | January 28, 2017 |  | July 30, 2016 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 318 |  |  | $ | 281 |  |
| End user | 94 |  |  | 96 |  |
| Total | $ | 412 |  |  | $ | 377 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (99 | ) |  | $ | (85 | ) |
| End user | (63 | ) |  | (76 | ) |
| Total | $ | (162 | ) |  | $ | (161 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue | $ | 250 |  |  | $ | 216 |  |

[0000858877-17-000004:notes:78]
Other Guarantees   The Company’s other guarantee arrangements as of January 28, 2017 and July 30, 2016 that were subject to recognition and disclosure requirements were not material.

[0000858877-17-000004:notes:79]
| (f) | Supplier Component Remediation Liabilities |

[0000858877-17-000004:notes:80]
In the second quarter of fiscal 2014, the Company recorded a charge to product cost of sales of $655 million resulting from  failures related to products containing memory components manufactured by a single supplier between 2005 and 2010. The Company performs regular assessments of the sufficiency of this liability and reduced the amount by a total of $238 million in fiscal 2016 and fiscal 2015 based on updated analyses.  During the second quarter of fiscal 2017, the Company further reduced the liability by $141 million to reflect lower than expected defects, actual usage history, and estimated lower future remediation costs as more of the impacted products age and near the end of the support period covered by the remediation program. The liability related to this matter as of January 28, 2017 and July 30, 2016 was $105 million and $276 million, respectively.

[0000858877-17-000004:notes:81]
In addition, during the second quarter of fiscal 2017, the Company recorded a charge to product cost of sales of $125 million related to the expected remediation costs for anticipated failures in future periods of a widely-used clock-signal component sourced from a third party which is included in several of the Company’s products.

[0000858877-17-000004:notes:82]
| (g) | Indemnifications |

[0000858877-17-000004:notes:83]
In the normal course of business, the Company indemnifies other parties, including customers, lessors, and parties to other transactions with the Company, with respect to certain matters. The Company has agreed to hold such parties harmless against losses arising from a breach of representations or covenants or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim.

[0000858877-17-000004:notes:84]
The Company has been asked to provide indemnification in matters involving certain of the Company’s service provider customers that are subject to patent infringement claims asserted by Sprint Communications Company, L.P. in Kansas and Delaware. Sprint alleges that the service provider customers infringe Sprint’s patents by offering VoIP telephone services utilizing products provided by the Company and other manufacturers. Sprint seeks monetary damages. Sprint’s Kansas cases were stayed pending resolution of Sprint’s appeal of the Delaware court’s judgment that certain Sprint patents were invalid. The Court of Appeals for the Federal Circuit overturned the Delaware court’s judgment on September 23, 2016. As a result, Sprint’s Kansas cases are set for trial on February 13 and March 6, 2017 against Time Warner Cable and Comcast respectively, and its Delaware case was reset for trial on November 6, 2017 against Cox Communications.

[0000858877-17-000004:notes:85]
The Company believes that the service providers have strong defenses and arguments that the Company's products do not infringe the patents and/or that Sprint's patents are invalid and/or that Sprint’s damages claims are inconsistent with prevailing law. Due to the uncertainty surrounding the litigation process, which involves numerous defendants, the Company is unable to reasonably estimate the ultimate outcome of this litigation at this time. Should Sprint prevail in litigation, mediation, or settlement, the Company, in accordance with its agreements, may have an obligation to indemnify its service provider customers for damages, mediation awards, or settlement amounts arising from their use of Cisco products. At this time, the Company does not anticipate that its obligations regarding the final outcome of the matters would be material.

[0000858877-17-000004:notes:86]
In addition, the Company has entered into indemnification agreements with its officers and directors, and the Company’s Amended and Restated Bylaws contain similar indemnification obligations to the Company’s agents.

[0000858877-17-000004:notes:87]
It is not possible to determine the maximum potential amount under these indemnification agreements due to the Company’s limited history with prior indemnification claims and the unique facts and circumstances involved in each particular agreement. Historically, payments made by the Company under these agreements have not had a material effect on the Company’s operating results, financial position, or cash flows.

[0000858877-17-000004:notes:88]
| (h) | Legal Proceedings |

[0000858877-17-000004:notes:89]
Brazil    Brazilian authorities have investigated the Company’s Brazilian subsidiary and certain of its former employees, as well as a Brazilian importer of the Company’s products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against the Company’s Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years.

[0000858877-17-000004:notes:90]
The asserted claims by Brazilian federal tax authorities that remain are for calendar years 2003 through 2007, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $258 million for the alleged evasion of import and other taxes, $1.4 billion for interest, and $1.2 billion for various penalties, all determined using an exchange rate as of January 28, 2017. The Company has completed a thorough review of the matters and believes the asserted claims against the Company’s Brazilian subsidiary are without merit, and the Company is defending the claims vigorously. While the Company believes there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, the Company is unable to determine the likelihood of an unfavorable outcome against its Brazilian subsidiary and is unable to reasonably estimate a range of loss, if any. The Company does not expect a final judicial determination for several years.

[0000858877-17-000004:notes:91]
SRI International     On September 4, 2013, SRI International, Inc. (“SRI”) asserted patent infringement claims against the Company in the U.S. District Court for the District of Delaware, accusing Cisco products and services in the area of network intrusion detection of infringing two U.S. patents. SRI sought monetary damages of at least a reasonable royalty and enhanced damages. On May 12, 2016, the jury returned a verdict finding willful infringement of the asserted patents. The jury awarded SRI damages of $23.7 million, and the Court will decide whether to award enhanced damages and attorneys’ fees and whether an ongoing royalty should be awarded through the expiration of the patents in 2018. In June 2016, the Company filed post-trial motions. The Company also intends to pursue an appeal to the United States Court of Appeals for the Federal Circuit on various grounds. The Company believes it has strong arguments to overturn the jury verdict and/or reduce the damages award. While the ultimate outcome of the case may still result in a loss, the Company does not expect it to be material.

[0000858877-17-000004:notes:92]
SSL     SSL Services, LLC (“SSL”) has asserted claims for patent infringement against the Company in the U.S. District Court for the Eastern District of Texas. The proceeding was instituted on March 25, 2015. SSL alleges that the Company's AnyConnect products that include Virtual Private Networking functions infringed a U.S. patent owned by SSL. SSL seeks money damages from the Company. On August 18, 2015, Cisco petitioned the Patent Trial and Appeal Board (“PTAB”) of the United States Patent and Trademark Office to review whether the patent SSL has asserted against the Company is valid over prior art. On February 23, 2016, a PTAB multi-judge panel found a reasonable likelihood that Cisco would prevail in showing that SSL’s patent claims are unpatentable and instituted proceedings. The PTAB held a hearing to review the Company's petition on November 15, 2016 and a decision is expected by February 23, 2017. The district court issued an order on June 28, 2016 staying the district court case pending the final written decision from the PTAB. The Company believes it has strong arguments that the Company's products do not infringe and the patent is invalid. If the Company does not prevail and a jury were to find that the Company's AnyConnect products infringe, the Company believes damages, as appropriately measured, would be immaterial. Due to uncertainty surrounding patent litigation processes, however, the Company is unable to reasonably estimate the ultimate outcome of this litigation at this time.

[0000858877-17-000004:notes:93]
Kangtega     Cisco Systems GmbH (“Cisco GmbH”) was subject to patent claims by Kangtega GmbH (“Kangtega”), instituted on June 6, 2013, alleging that Cisco GmbH infringed in Germany a European Patent by marketing in Germany network intrusion-detection (or firewall) products known as the “ASA” firewall offering. On April 29, 2014, the Mannheim Regional Court dismissed the infringement action, finding no infringement by Cisco GmbH of the asserted patent. On November 23, 2016, a court of appeal in Germany (Oberlandesgericht Karlsruhe) heard an appeal of that judgment and the parties thereafter executed a settlement agreement resolving all aspects of the proceedings. The resolution did not have a material impact on the Company's results of operations.

[0000858877-17-000004:notes:94]
In addition, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, the Company does not expect that the ultimate costs to resolve these matters will have a material adverse effect on its consolidated financial position, results of operations, or cash flows.


## us-gaap:CommitmentsAndContingenciesPolicyTextBlock

[0000858877-17-000004:notes:95]
The Company records a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of its future demand forecasts consistent with the valuation of the Company’s excess and obsolete inventory.

[0000858877-17-000004:notes:96]
The Company purchases components from a variety of suppliers and uses several contract manufacturers to provide manufacturing services for its products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, the Company enters into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by the Company or establish the parameters defining the Company’s requirements.  A significant portion of the Company’s reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. In certain instances, these agreements allow the Company the option to cancel, reschedule, and adjust the Company’s requirements based on its business needs prior to firm orders being placed.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000858877-17-000004:notes:97]
[same as prior period, unchanged from 0000858877-16-000123:notes:92]

[0000858877-17-000004:notes:98]
The components of AOCI, net of tax, and the other comprehensive income (loss), excluding noncontrolling interest, for the six months ended January 28, 2017 and January 23, 2016 are summarized as follows (in millions):

[0000858877-17-000004:notes:99]
|  | Net Unrealized Gains (Losses) on Available-for-Sale Investments |  | Net Unrealized Gains (Losses) Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Actuarial Gains (Losses) |  | Accumulated Other Comprehensive Income (Loss) |
| BALANCE AT JULY 30, 2016 | $ | 413 |  |  | $ | (59 | ) |  | $ | (680 | ) |  | $ | (326 | ) |
| Other comprehensive income (loss) before reclassifications attributable to Cisco Systems, Inc. | (559 | ) |  | (48 | ) |  | (69 | ) |  | (676 | ) |
| (Gains) losses reclassified out of AOCI | 15 |  |  | 39 |  |  | (1 | ) |  | 53 |  |
| Tax benefit (expense) | 148 |  |  | 1 |  |  | (1 | ) |  | 148 |  |
| BALANCE AT JANUARY 28, 2017 | $ | 17 |  |  | $ | (67 | ) |  | $ | (751 | ) |  | $ | (801 | ) |

[0000858877-17-000004:notes:100]
|  | Net Unrealized Gains (Losses) on Available-for-Sale Investments |  | Net Unrealized Gains (Losses) Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Actuarial Gains (Losses) |  | Accumulated Other Comprehensive Income (Loss) |
| BALANCE AT JULY 25, 2015 | $ | 310 |  |  | $ | (16 | ) |  | $ | (233 | ) |  | $ | 61 |  |
| Other comprehensive income (loss) before reclassifications attributable to Cisco Systems, Inc. | (515 | ) |  | (24 | ) |  | (524 | ) |  | (1,063 | ) |
| (Gains) losses reclassified out of AOCI | 20 |  |  | 8 |  |  | 1 |  |  | 29 |  |
| Tax benefit (expense) | 198 |  |  | 2 |  |  | (34 | ) |  | 166 |  |
| BALANCE AT JANUARY 23, 2016 | $ | 13 |  |  | $ | (30 | ) |  | $ | (790 | ) |  | $ | (807 | ) |

[0000858877-17-000004:notes:101]
[same as prior period, unchanged from 0000858877-16-000123:notes:96]

[0000858877-17-000004:notes:102]
|  |  | Three Months Ended |  | Six Months Ended |  |  |  |
|  |  | January 28, 2017 |  | January 23, 2016 |  | January 28, 2017 |  | January 23, 2016 |  |  |  |
| Comprehensive Income Components |  | Income Before Taxes |  | Income Before Taxes |  |  | Line Item in Statements of Operations |
| Net unrealized gains and losses on available-for-sale investments |  | $ | (30 | ) |  | $ | (19 | ) |  | $ | (15 | ) |  | $ | (20 | ) |  |  | Other income (loss), net |
| Net unrealized gains and losses on cash flow hedging instruments |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | (21 | ) |  | (4 | ) |  | (30 | ) |  | (6 | ) |  |  | Operating expenses |
| Foreign currency derivatives |  | (6 | ) |  | (1 | ) |  | (9 | ) |  | (2 | ) |  |  | Cost of sales—service |
|  |  | (27 | ) |  | (5 | ) |  | (39 | ) |  | (8 | ) |  |  |  |
| Cumulative translation adjustment and actuarial gains and losses |  | 1 |  |  | — |  |  | 1 |  |  | (1 | ) |  |  | Operating expenses |
| Total amounts reclassified out of AOCI |  | $ | (56 | ) |  | $ | (24 | ) |  | $ | (53 | ) |  | $ | (29 | ) |  |  |  |


## us-gaap:DebtDisclosureTextBlock

[0000858877-17-000004:notes:103]
Borrowings

[0000858877-17-000004:notes:104]
| (a) | Short-Term Debt |

[0000858877-17-000004:notes:105]
The following table summarizes the Company’s short-term debt (in millions, except percentages):

[0000858877-17-000004:notes:106]
|  | January 28, 2017 |  | July 30, 2016 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 4,151 |  |  | 1.26 | % |  | $ | 4,159 |  |  | 0.97 | % |
| Commercial paper | 300 |  |  | 0.73 | % |  | — |  |  | — |  |
| Other notes and borrowings | — |  |  | — |  |  | 1 |  |  | 2.08 | % |
| Total short-term debt | $ | 4,451 |  |  |  |  | $ | 4,160 |  |  |  |

[0000858877-17-000004:notes:107]
The effective interest rate on the current portion of long-term debt includes the impact of interest rate swaps, as discussed further in "

[0000858877-17-000004:notes:108]
| (b) | Long-Term Debt |

[0000858877-17-000004:notes:109]
." Other notes and borrowings consist of the short-term portion of secured borrowings associated with customer financing arrangements. These notes and credit facilities were subject to various terms and foreign currency market interest rates pursuant to individual financial arrangements between the financing institution and the applicable foreign subsidiary.

[0000858877-17-000004:notes:110]
The Company has established a short-term debt financing program of up to $3.0 billion through the issuance of commercial paper notes. The Company uses the proceeds from the issuance of commercial paper notes for general corporate purposes. The Company had $300 million and no commercial paper notes outstanding as of January 28, 2017 and July 30, 2016, respectively.

[0000858877-17-000004:notes:111]
(b)

[0000858877-17-000004:notes:112]
Long-Term Debt

[0000858877-17-000004:notes:113]
The following table summarizes the Company’s long-term debt (in millions, except percentages):

[0000858877-17-000004:notes:114]
|  |  |  | January 28, 2017 |  | July 30, 2016 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.28% | March 3, 2017 |  | $ | 1,000 |  |  | 1.29% |  | $ | 1,000 |  |  | 1.03% |
| Three-month LIBOR plus 0.60% | February 21, 2018 |  | 1,000 |  |  | 1.58% |  | 1,000 |  |  | 1.32% |
| Three-month LIBOR plus 0.31% | June 15, 2018 |  | 900 |  |  | 1.34% |  | 900 |  |  | 1.03% |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | 500 |  |  | 1.49% |  | 500 |  |  | 1.23% |
| Three-month LIBOR plus 0.34% | September 20, 2019 | (1) | 500 |  |  | 1.38% |  | — |  |  | — |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 1.10% | March 3, 2017 |  | 2,400 |  |  | 1.17% |  | 2,400 |  |  | 0.87% |
| 3.15% | March 14, 2017 |  | 750 |  |  | 1.52% |  | 750 |  |  | 1.22% |
| 1.40% | February 28, 2018 |  | 1,250 |  |  | 1.47% |  | 1,250 |  |  | 1.47% |
| 1.65% | June 15, 2018 |  | 1,600 |  |  | 1.72% |  | 1,600 |  |  | 1.72% |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 4.84% |  | 2,000 |  |  | 4.76% |
| 1.60% | February 28, 2019 |  | 1,000 |  |  | 1.67% |  | 1,000 |  |  | 1.67% |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 1.39% |  | 1,750 |  |  | 1.08% |
| 1.40% | September 20, 2019 | (1) | 1,500 |  |  | 1.48% |  | — |  |  | — |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 3.47% |  | 2,500 |  |  | 3.25% |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 2.54% |  | 1,500 |  |  | 2.54% |
| 2.20% | February 28, 2021 |  | 2,500 |  |  | 2.30% |  | 2,500 |  |  | 2.30% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 1.55% |  | 500 |  |  | 1.24% |
| 1.85% | September 20, 2021 | (1) | 2,000 |  |  | 1.90% |  | — |  |  | — |
| 3.00% | June 15, 2022 |  | 500 |  |  | 1.80% |  | 500 |  |  | 1.51% |
| 2.60% | February 28, 2023 |  | 500 |  |  | 2.68% |  | 500 |  |  | 2.68% |
| 2.20% | September 20, 2023 | (1) | 750 |  |  | 2.27% |  | — |  |  | — |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1.66% |  | 1,000 |  |  | 1.36% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 1.96% |  | 500 |  |  | 1.67% |
| 2.95% | February 28, 2026 |  | 750 |  |  | 3.01% |  | 750 |  |  | 3.01% |
| 2.50% | September 20, 2026 | (1) | 1,500 |  |  | 2.55% |  | — |  |  | — |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Total |  |  | 34,650 |  |  |  |  | 28,400 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (145 | ) |  |  |  | (137 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 117 |  |  |  |  | 379 |  |  |  |
| Total |  |  | $ | 34,622 |  |  |  |  | $ | 28,642 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 4,151 |  |  |  |  | $ | 4,159 |  |  |  |
| Long-term debt |  |  | 30,471 |  |  |  |  | 24,483 |  |  |  |
| Total |  |  | $ | 34,622 |  |  |  |  | $ | 28,642 |  |  |  |

[0000858877-17-000004:notes:115]
(1) In September 2016, the Company issued senior notes for an aggregate principal amount of $6.25 billion.

[0000858877-17-000004:notes:116]
To achieve its interest rate risk management objectives, the Company entered into interest rate swaps in prior periods with an aggregate notional amount of $9.9 billion designated as fair value hedges of certain of its fixed-rate senior notes.  In effect, these swaps convert the fixed interest rates of the fixed-rate notes to floating interest rates based on the London InterBank Offered Rate ("LIBOR"). The gains and losses related to changes in the fair value of the interest rate swaps substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates.  For additional information, see Note 11.

[0000858877-17-000004:notes:117]
The effective rates for the fixed-rate debt include the interest on the notes, the accretion of the discount, and, if applicable, adjustments related to hedging. Interest is payable semiannually on each class of the senior fixed-rate notes and payable quarterly on the floating-rate notes. Each of the senior fixed-rate notes is redeemable by the Company at any time, subject to a make-whole premium.

[0000858877-17-000004:notes:118]
The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to the Company’s short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of January 28, 2017, the Company was in compliance with all debt covenants.

[0000858877-17-000004:notes:119]
As of January 28, 2017, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

[0000858877-17-000004:notes:120]
| Fiscal Year | Amount |
| 2017 (remaining six months) | $ | 4,150 |  |
| 2018 | 4,750 |  |
| 2019 | 5,250 |  |
| 2020 | 6,000 |  |
| 2021 | 3,000 |  |
| Thereafter | 11,500 |  |
| Total | $ | 34,650 |  |

[0000858877-17-000004:notes:121]
| (c) | Credit Facility |

[0000858877-17-000004:notes:122]
On May 15, 2015, the Company entered into a credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 15, 2020. Any advances under the credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (i) the highest of (a) the Federal Funds rate plus 0.50%, (b) Bank of America’s “prime rate” as announced from time to time, or (c) LIBOR, or a comparable or successor rate that is approved by the Administrative Agent (“Eurocurrency Rate”), for an interest period of one-month plus 1.00%, or (ii) the Eurocurrency Rate, plus a margin that is based on the Company’s senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the Eurocurrency Rate be less than zero.  The credit agreement requires the Company to comply with certain covenants, including that it maintains an interest coverage ratio as defined in the agreement.

[0000858877-17-000004:notes:123]
The Company may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and/or extend the expiration date of the credit facility up to May 15, 2022. As of January 28, 2017, the Company was in compliance with the required interest coverage ratio and the other covenants, and the Company had not borrowed any funds under the credit facility.


## us-gaap:DeferredRevenueByArrangementDisclosureTextBlock

[0000858877-17-000004:notes:124]
| Deferred revenue: |  |  |  |  |
| Service |  | $ | 10,525 |  |  | $ | 10,621 |  |
| Product: |  |  |  |  |
| Deferred revenue related to recurring software and subscription businesses |  | 3,997 |  |  | 3,308 |  |
| Deferred revenue related to two-tier distributors |  | 401 |  |  | 377 |  |
| Other product deferred revenue |  | 2,163 |  |  | 2,166 |  |
| Total product deferred revenue |  | 6,561 |  |  | 5,851 |  |
| Total |  | $ | 17,086 |  |  | $ | 16,472 |  |
| Reported as: |  |  |  |  |
| Current |  | $ | 10,243 |  |  | $ | 10,155 |  |
| Noncurrent |  | 6,843 |  |  | 6,317 |  |
| Total |  | $ | 17,086 |  |  | $ | 16,472 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000858877-17-000004:notes:125]
[same as prior period, unchanged from 0000858877-16-000123:notes:120]

[0000858877-17-000004:notes:126]
[same as prior period, unchanged from 0000858877-16-000123:notes:121]

[0000858877-17-000004:notes:127]
[same as prior period, unchanged from 0000858877-16-000123:notes:122]

[0000858877-17-000004:notes:128]
[same as prior period, unchanged from 0000858877-16-000123:notes:123]

[0000858877-17-000004:notes:129]
|  | DERIVATIVE ASSETS |  | DERIVATIVE LIABILITIES |
|  | Balance Sheet Line Item |  | January 28, 2017 |  | July 30, 2016 |  | Balance Sheet Line Item |  | January 28, 2017 |  | July 30, 2016 |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | $ | 5 |  |  | $ | 7 |  |  | Other current liabilities |  | $ | 58 |  |  | $ | 53 |  |
| Interest rate derivatives | Other current assets |  | 2 |  |  | 11 |  |  | Other current liabilities |  | — |  |  | — |  |
| Interest rate derivatives | Other assets |  | 109 |  |  | 366 |  |  | Other long-term liabilities |  | — |  |  | — |  |
| Total |  |  | 116 |  |  | 384 |  |  |  |  | 58 |  |  | 53 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | 2 |  |  | — |  |  | Other current liabilities |  | 1 |  |  | 1 |  |
| Equity derivatives/warrants | Other assets |  | — |  |  | 1 |  |  | Other long-term liabilities |  | — |  |  | — |  |
| Total |  |  | 2 |  |  | 1 |  |  |  |  | 1 |  |  | 1 |  |
| Total |  |  | $ | 118 |  |  | $ | 385 |  |  |  |  | $ | 59 |  |  | $ | 54 |  |

[0000858877-17-000004:notes:130]
[same as prior period, unchanged from 0000858877-16-000123:notes:125]

[0000858877-17-000004:notes:131]
| GAINS (LOSSES) RECOGNIZEDIN OCI ON DERIVATIVES FOR THE THREE MONTHS ENDED (EFFECTIVE PORTION) |  | GAINS (LOSSES) RECLASSIFIED FROMAOCI INTO INCOME FOR THETHREE MONTHS ENDED (EFFECTIVE PORTION) |
|  |  | January 28, 2017 |  | January 23, 2016 |  | Line Item in Statements of Operations |  | January 28, 2017 |  | January 23, 2016 |
| Derivatives designated as cash flow hedging instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | (2 | ) |  | $ | (20 | ) |  | Operating expenses |  | $ | (21 | ) |  | $ | (4 | ) |
|  |  |  |  |  |  | Cost of sales—service |  | (6 | ) |  | (1 | ) |
| Total |  | $ | (2 | ) |  | $ | (20 | ) |  |  |  | $ | (27 | ) |  | $ | (5 | ) |
| Derivatives designated as net investment hedging instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | (3 | ) |  | $ | 11 |  |  | Other income (loss), net |  | $ | — |  |  | $ | — |  |

[0000858877-17-000004:notes:132]
| GAINS (LOSSES) RECOGNIZEDIN OCI ON DERIVATIVES FOR THE SIX MONTHS ENDED (EFFECTIVE PORTION) |  | GAINS (LOSSES) RECLASSIFIED FROMAOCI INTO INCOME FOR THESIX MONTHS ENDED (EFFECTIVE PORTION) |
|  |  | January 28, 2017 |  | January 23, 2016 |  | Line Item in Statements of Operations |  | January 28, 2017 |  | January 23, 2016 |
| Derivatives designated as cash flow hedging instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | (48 | ) |  | $ | (24 | ) |  | Operating expenses |  | $ | (30 | ) |  | $ | (6 | ) |
|  |  |  |  |  |  | Cost of sales—service |  | (9 | ) |  | (2 | ) |
| Total |  | $ | (48 | ) |  | $ | (24 | ) |  |  |  | $ | (39 | ) |  | $ | (8 | ) |
| Derivatives designated as net investment hedging instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | 6 |  |  | $ | 11 |  |  | Other income (loss), net |  | $ | — |  |  | $ | — |  |

[0000858877-17-000004:notes:133]
As of January 28, 2017, the Company estimates that approximately $59 million of net derivative losses related to its cash flow hedges included in accumulated other comprehensive income ("AOCI") will be reclassified into earnings within the next 12 months when the underlying hedged item impacts earnings.

[0000858877-17-000004:notes:134]
[same as prior period, unchanged from 0000858877-16-000123:notes:128]

[0000858877-17-000004:notes:135]
|  |  |  |  | GAINS (LOSSES) FOR THETHREE MONTHS ENDED |  | GAINS (LOSSES) FOR THESIX MONTHS ENDED |
| Derivatives Not Designated as Hedging Instruments |  | Line Item in Statements of Operations |  | January 28, 2017 |  | January 23, 2016 |  | January 28, 2017 |  | January 23, 2016 |
| Foreign currency derivatives |  | Other income (loss), net |  | $ | (20 | ) |  | $ | (58 | ) |  | $ | (36 | ) |  | $ | (54 | ) |
| Total return swaps—deferred compensation |  | Operating expenses |  | 26 |  |  | (38 | ) |  | 23 |  |  | (54 | ) |
| Equity derivatives |  | Other income (loss), net |  | 8 |  |  | 3 |  |  | 9 |  |  | 13 |  |
| Total |  |  |  | $ | 14 |  |  | $ | (93 | ) |  | $ | (4 | ) |  | $ | (95 | ) |

[0000858877-17-000004:notes:136]
[same as prior period, unchanged from 0000858877-16-000123:notes:130]

[0000858877-17-000004:notes:137]
|  | January 28, 2017 |  | July 30, 2016 |
| Derivatives designated as hedging instruments: |  |  |  |
| Foreign currency derivatives—cash flow hedges | $ | 2,142 |  |  | $ | 2,683 |  |
| Interest rate derivatives | 9,900 |  |  | 9,900 |  |
| Net investment hedging instruments | 236 |  |  | 298 |  |
| Derivatives not designated as hedging instruments: |  |  |  |
| Foreign currency derivatives | 2,002 |  |  | 2,057 |  |
| Total return swaps—deferred compensation | 516 |  |  | 476 |  |
| Total | $ | 14,796 |  |  | $ | 15,414 |  |

[0000858877-17-000004:notes:138]
[same as prior period, unchanged from 0000858877-16-000123:notes:132]

[0000858877-17-000004:notes:139]
[same as prior period, unchanged from 0000858877-16-000123:notes:133]

[0000858877-17-000004:notes:140]
|  | January 28, 2017 |
|  | GROSS AMOUNTS OFFSET IN THE CONSOLIDATED BALANCE SHEETS |  | GROSS AMOUNTS NOT OFFSET IN THE CONSOLIDATED BALANCE SHEETSBUT WITH LEGAL RIGHTS TO OFFSET |
|  | Gross Amounts Recognized |  | Gross Amounts Offset |  | Net Amounts Presented |  | Gross Derivative Amounts |  | Cash Collateral |  | Net Amount |
| Derivatives assets | $ | 118 |  |  | $ | — |  |  | $ | 118 |  |  | $ | (21 | ) |  | $ | (90 | ) |  | $ | 7 |  |
| Derivatives liabilities | $ | 59 |  |  | $ | — |  |  | $ | 59 |  |  | $ | (21 | ) |  | $ | — |  |  | $ | 38 |  |

[0000858877-17-000004:notes:141]
[same as prior period, unchanged from 0000858877-16-000123:notes:135]

[0000858877-17-000004:notes:142]
[same as prior period, unchanged from 0000858877-16-000123:notes:136]

[0000858877-17-000004:notes:143]
[same as prior period, unchanged from 0000858877-16-000123:notes:137]

[0000858877-17-000004:notes:144]
[same as prior period, unchanged from 0000858877-16-000123:notes:138]

[0000858877-17-000004:notes:145]
[same as prior period, unchanged from 0000858877-16-000123:notes:139]

[0000858877-17-000004:notes:146]
[same as prior period, unchanged from 0000858877-16-000123:notes:140]

[0000858877-17-000004:notes:147]
[same as prior period, unchanged from 0000858877-16-000123:notes:141]

[0000858877-17-000004:notes:148]
Interest Rate Derivatives, Investments   The Company’s primary objective for holding fixed income securities is to achieve an appropriate investment return consistent with preserving principal and managing risk. To realize these objectives, the Company may utilize interest rate swaps or other derivatives designated as fair value or cash flow hedges. As of January 28, 2017 and July 30, 2016, the Company did not have any outstanding interest rate derivatives related to its fixed income securities.

[0000858877-17-000004:notes:149]
Interest Rate Derivatives Designated as Fair Value Hedges, Long-Term Debt  In the six months ended January 28, 2017, the Company did not enter into any interest rate swaps. In prior fiscal years, the Company entered into interest rate swaps designated as fair value hedges related to fixed-rate senior notes that are due in fiscal 2017 through 2025. Under these interest rate swaps, the Company receives fixed-rate interest payments and makes interest payments based on LIBOR plus a fixed number of basis points. The effect of such swaps is to convert the fixed interest rates of the senior fixed-rate notes to floating interest rates based on LIBOR. The gains and losses related to changes in the fair value of the interest rate swaps are included in interest expense and substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates. The fair value of the interest rate swaps was reflected in other current assets and other assets.

[0000858877-17-000004:notes:150]
[same as prior period, unchanged from 0000858877-16-000123:notes:144]

[0000858877-17-000004:notes:151]
[same as prior period, unchanged from 0000858877-16-000123:notes:145]

[0000858877-17-000004:notes:152]
[same as prior period, unchanged from 0000858877-16-000123:notes:146]

[0000858877-17-000004:notes:153]
[same as prior period, unchanged from 0000858877-16-000123:notes:147]

[0000858877-17-000004:notes:154]
[same as prior period, unchanged from 0000858877-16-000123:notes:148]


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000858877-17-000004:notes:155]
[same as prior period, unchanged from 0000858877-16-000123:notes:149]

[0000858877-17-000004:notes:156]
[same as prior period, unchanged from 0000858877-16-000123:notes:150]

[0000858877-17-000004:notes:157]
Stock Incentive Plan Program Description    As of January 28, 2017, the Company had one stock incentive plan: the 2005 Stock Incentive Plan (the “2005 Plan”). In addition, the Company has, in connection with the acquisitions of various companies, assumed the share-based awards granted under stock incentive plans of the acquired companies or issued share-based awards in replacement thereof. Share-based awards are designed to reward employees for their long-term contributions to the Company and provide incentives for them to remain with the Company.  The number and frequency of share-based awards are based on competitive practices, operating results of the Company, government regulations, and other factors. The Company’s primary stock incentive plan is summarized as follows:

[0000858877-17-000004:notes:158]
2005 Plan    The 2005 Plan permits the granting of stock options, restricted stock, and restricted stock units ("RSUs"), the vesting of which may be performance-based or market-based along with the requisite service requirement, and stock appreciation rights to employees (including employee directors and officers), consultants of the Company and its subsidiaries and affiliates, and non-employee directors of the Company.  As of January 28, 2017, the maximum number of shares issuable under the 2005 Plan over its term was 694 million shares, plus shares from certain previous plans that were forfeited or were terminated for any other reason before being exercised or settled. If any awards granted under the 2005 Plan are forfeited or are terminated for any other reason before being exercised or settled, the unexercised or unsettled shares underlying the awards will again be available under the 2005 Plan. In addition, starting November 19, 2013, shares withheld by the Company from an award other than a stock option or stock appreciation right to satisfy withholding tax liabilities resulting from such award will again be available for issuance, based on the fungible share ratio in effect on the date of grant.

[0000858877-17-000004:notes:159]
The number of shares available for issuance under the 2005 Plan is reduced by 1.5 shares for each share awarded as a stock grant or a stock unit. Stock options and stock appreciation rights granted under the 2005 Plan have an exercise price of at least 100% of the fair market value of the underlying stock on the grant date and prior to November 12, 2009 have an expiration date no later than nine years from the grant date. The expiration date for stock options and stock appreciation rights granted subsequent to the amendment approved on November 12, 2009 shall be no later than 10 years from the grant date. The stock options will generally become exercisable for 20% or 25% of the option shares one year from the date of grant and then ratably over the following 48 months or 36 months, respectively. Time-based stock grants and time-based RSUs will generally vest with respect to 20% or 25% of the shares or share units covered by the grant annually over the vesting period. The majority of the performance-based and market-based RSUs vests at the end of the three-year requisite service period or earlier if the award recipient meets certain retirement eligibility conditions. Certain performance-based RSUs, that are based on the achievement of financial and/or non-financial operating goals, typically vest upon the achievement of milestones (and may require subsequent service periods), with overall vesting of the shares underlying the award ranging from six months to three years. The Compensation and Management Development Committee of the Board of Directors has the discretion to use different vesting schedules. Stock appreciation rights may be awarded in combination with stock options or stock grants, and such awards shall provide that the stock appreciation rights will not be exercisable unless the related stock options or stock grants are forfeited. Stock grants may be awarded in combination with non-statutory stock options, and such awards may provide that the stock grants will be forfeited in the event that the related non-statutory stock options are exercised.

[0000858877-17-000004:notes:160]
[same as prior period, unchanged from 0000858877-16-000123:notes:156]

[0000858877-17-000004:notes:161]
The Company has an Employee Stock Purchase Plan, which includes its subplan named the International Employee Stock Purchase Plan (together, the “Purchase Plan”), under which 621 million shares of the Company’s common stock have been reserved for issuance as of January 28, 2017. Eligible employees are offered shares through a 24-month offering period, which consists of four consecutive 6-month purchase periods. Employees may purchase a limited number of shares of the Company’s stock at a discount of up to 15% of the lesser of the market value at the beginning of the offering period or the end of each 6-month purchase period.  The Purchase Plan is scheduled to terminate on January 3, 2020. The Company issued 12 million and 14 million shares under the Purchase Plan during the six months ended January 28, 2017 and January 23, 2016, respectively. As of January 28, 2017, 111 million shares were available for issuance under the Purchase Plan.

[0000858877-17-000004:notes:162]
[same as prior period, unchanged from 0000858877-16-000123:notes:158]

[0000858877-17-000004:notes:163]
[same as prior period, unchanged from 0000858877-16-000123:notes:159]

[0000858877-17-000004:notes:164]
|  | Three Months Ended |  | Six Months Ended |
|  | January 28, 2017 |  | January 23, 2016 |  | January 28, 2017 |  | January 23, 2016 |
| Cost of sales—product | $ | 19 |  |  | $ | 16 |  |  | $ | 40 |  |  | $ | 29 |  |
| Cost of sales—service | 34 |  |  | 35 |  |  | 67 |  |  | 73 |  |
| Share-based compensation expense in cost of sales | 53 |  |  | 51 |  |  | 107 |  |  | 102 |  |
| Research and development | 129 |  |  | 107 |  |  | 255 |  |  | 221 |  |
| Sales and marketing | 125 |  |  | 126 |  |  | 265 |  |  | 265 |  |
| General and administrative | 45 |  |  | 47 |  |  | 94 |  |  | 104 |  |
| Restructuring and other charges | — |  |  | (1 | ) |  | 3 |  |  | 14 |  |
| Share-based compensation expense in operating expenses | 299 |  |  | 279 |  |  | 617 |  |  | 604 |  |
| Total share-based compensation expense | $ | 352 |  |  | $ | 330 |  |  | $ | 724 |  |  | $ | 706 |  |
| Income tax benefit for share-based compensation | $ | 102 |  |  | $ | 103 |  |  | $ | 207 |  |  | $ | 198 |  |

[0000858877-17-000004:notes:165]
As of January 28, 2017, the total compensation cost related to unvested share-based awards not yet recognized was $2.8 billion, which is expected to be recognized over approximately 2.6 years on a weighted-average basis.

[0000858877-17-000004:notes:166]
[same as prior period, unchanged from 0000858877-16-000123:notes:162]

[0000858877-17-000004:notes:167]
[same as prior period, unchanged from 0000858877-16-000123:notes:163]

[0000858877-17-000004:notes:168]
|  | Share-Based Awards Available for Grant |
| BALANCE AT JULY 25, 2015 | 276 |  |
| Restricted stock, stock units, and other share-based awards granted | (96 | ) |
| Share-based awards canceled/forfeited/expired | 30 |  |
| Shares withheld for taxes and not issued | 30 |  |
| Other | 2 |  |
| BALANCE AT JULY 30, 2016 | 242 |  |
| Restricted stock, stock units, and other share-based awards granted | (43 | ) |
| Share-based awards canceled/forfeited/expired | 69 |  |
| Shares withheld for taxes and not issued | 20 |  |
| BALANCE AT JANUARY 28, 2017 | 288 |  |

[0000858877-17-000004:notes:169]
[same as prior period, unchanged from 0000858877-16-000123:notes:165]

[0000858877-17-000004:notes:170]
[same as prior period, unchanged from 0000858877-16-000123:notes:166]

[0000858877-17-000004:notes:171]
[same as prior period, unchanged from 0000858877-16-000123:notes:167]

[0000858877-17-000004:notes:172]
|  | Restricted Stock/Stock Units |  | Weighted-AverageGrant Date FairValue per Share |  | Aggregate Fair Value |
| UNVESTED BALANCE AT JULY 25, 2015 | 143 |  |  | $ | 22.08 |  |  |  |
| Granted and assumed | 70 |  |  | 25.69 |  |  |  |
| Vested | (54 | ) |  | 20.68 |  |  | $ | 1,428 |  |
| Canceled/forfeited | (14 | ) |  | 22.86 |  |  |  |
| UNVESTED BALANCE AT JULY 30, 2016 | 145 |  |  | 24.26 |  |  |  |
| Granted and assumed | 29 |  |  | 28.17 |  |  |  |
| Vested | (39 | ) |  | 22.18 |  |  | $ | 1,210 |  |
| Canceled/forfeited | (11 | ) |  | 24.99 |  |  |  |
| UNVESTED BALANCE AT JANUARY 28, 2017 | 124 |  |  | $ | 25.76 |  |  |  |

[0000858877-17-000004:notes:173]
[same as prior period, unchanged from 0000858877-16-000123:notes:169]

[0000858877-17-000004:notes:174]
[same as prior period, unchanged from 0000858877-16-000123:notes:170]

[0000858877-17-000004:notes:175]
|  | STOCK OPTIONS OUTSTANDING |
|  | NumberOutstanding |  | Weighted-AverageExercise Price per Share |
| BALANCE AT JULY 25, 2015 | 103 |  |  | $ | 28.68 |  |
| Assumed from acquisitions | 18 |  |  | 5.17 |  |
| Exercised | (32 | ) |  | 19.22 |  |
| Canceled/forfeited/expired | (16 | ) |  | 30.01 |  |
| BALANCE AT JULY 30, 2016 | 73 |  |  | 26.78 |  |
| Assumed from acquisitions | 1 |  |  | 1.59 |  |
| Exercised | (6 | ) |  | 17.43 |  |
| Canceled/forfeited/expired | (55 | ) |  | 31.95 |  |
| BALANCE AT JANUARY 28, 2017 | 13 |  |  | $ | 8.23 |  |

[0000858877-17-000004:notes:176]
The following table summarizes significant ranges of outstanding and exercisable stock options as of January 28, 2017 (in millions, except years and share prices):

[0000858877-17-000004:notes:177]
|  |  | STOCK OPTIONS OUTSTANDING |  | STOCK OPTIONS EXERCISABLE |
| Range of Exercise Prices |  | NumberOutstanding |  | Weighted-AverageRemainingContractualLife(in Years) |  | Weighted-AverageExercisePrice perShare |  | AggregateIntrinsicValue |  | NumberExercisable |  | Weighted-AverageExercisePrice perShare |  | AggregateIntrinsicValue |
| $ 0.01 – 20.00 |  | 11 |  |  | 6.5 |  | $ | 5.84 |  |  | $ | 280 |  |  | 4 |  |  | $ | 5.73 |  |  | $ | 120 |  |
| $ 20.01 – 25.00 |  | 1 |  |  | 0.1 |  | 23.41 |  |  | 3 |  |  | 1 |  |  | 23.41 |  |  | 2 |  |
| $ 25.01 – 30.00 |  | 1 |  |  | 0.4 |  | 25.55 |  |  | 7 |  |  | 1 |  |  | 25.55 |  |  | 7 |  |
| Total |  | 13 |  |  | 5.8 |  | $ | 8.23 |  |  | $ | 290 |  |  | 6 |  |  | $ | 10.55 |  |  | $ | 129 |  |

[0000858877-17-000004:notes:178]
The aggregate intrinsic value in the preceding table represents the total pretax intrinsic value, based on the Company’s closing stock price of $30.98 as of January 27, 2017, that would have been received by the option holders had those option holders exercised their stock options as of that date. The total number of in-the-money stock options exercisable as of January 28, 2017 was 6 million. As of July 30, 2016, 64 million outstanding stock options were exercisable and the weighted-average exercise price was $29.66.

[0000858877-17-000004:notes:179]
[same as prior period, unchanged from 0000858877-16-000123:notes:175]

[0000858877-17-000004:notes:180]
[same as prior period, unchanged from 0000858877-16-000123:notes:176]

[0000858877-17-000004:notes:181]
|  | RESTRICTED STOCK UNITS |  | PERFORMANCE BASEDRESTRICTED STOCK UNITS |
| Three Months Ended | January 28, 2017 |  | January 23, 2016 |  | January 28, 2017 |  | January 23, 2016 |
| Number of shares granted (in millions) | 15 |  |  | 27 |  |  | 3 |  |  | 1 |  |
| Grant date fair value per share | $ | 27.68 |  |  | $ | 25.25 |  |  | $ | 27.90 |  |  | $ | 25.32 |  |
| Weighted-average assumptions/inputs: |  |  |  |  |  |  |  |
| Expected dividend yield | 3.4 | % |  | 3.1 | % |  | 3.4 | % |  | 3.1 | % |
| Range of risk-free interest rates | 0.0% – 1.5% |  |  | 0.1% – 1.2% |  |  | 0.3% – 1.5% |  |  | 0.0% – 1.2% |  |
| Range of expected volatilities for index | N/A |  |  | N/A |  |  | N/A |  |  | 15.3% – 54.3% |  |

[0000858877-17-000004:notes:182]
|  | RESTRICTED STOCK UNITS |  | PERFORMANCE BASEDRESTRICTED STOCK UNITS |
| Six Months Ended | January 28, 2017 |  | January 23, 2016 |  | January 28, 2017 |  | January 23, 2016 |
| Number of shares granted (in millions) | 23 |  |  | 36 |  |  | 6 |  |  | 5 |  |
| Grant date fair value per share | $ | 27.96 |  |  | $ | 24.93 |  |  | $ | 28.78 |  |  | $ | 24.71 |  |
| Weighted-average assumptions/inputs: |  |  |  |  |  |  |  |
| Expected dividend yield | 3.4 | % |  | 3.1 | % |  | 3.4 | % |  | 3.2 | % |
| Range of risk-free interest rates | 0.0% – 1.5% |  |  | 0.0% – 1.2% |  |  | 0.1% – 1.5% |  |  | 0.0% – 1.2% |  |
| Range of expected volatilities for index | N/A |  |  | N/A |  |  | 16.7% – 46.8% |  |  | 15.3% – 54.3% |  |

[0000858877-17-000004:notes:183]
[same as prior period, unchanged from 0000858877-16-000123:notes:178]


## us-gaap:EarningsPerSharePolicyTextBlock

[0000858877-17-000004:notes:184]
[same as prior period, unchanged from 0000858877-16-000123:notes:179]


## us-gaap:EarningsPerShareTextBlock

[0000858877-17-000004:notes:185]
[same as prior period, unchanged from 0000858877-16-000123:notes:180]

[0000858877-17-000004:notes:186]
[same as prior period, unchanged from 0000858877-16-000123:notes:181]

[0000858877-17-000004:notes:187]
|  | Three Months Ended |  | Six Months Ended |
|  | January 28, 2017 |  | January 23, 2016 |  | January 28, 2017 |  | January 23, 2016 |
| Net income | $ | 2,348 |  |  | $ | 3,147 |  |  | $ | 4,670 |  |  | $ | 5,577 |  |
| Weighted-average shares—basic | 5,015 |  |  | 5,070 |  |  | 5,021 |  |  | 5,075 |  |
| Effect of dilutive potential common shares | 25 |  |  | 27 |  |  | 33 |  |  | 31 |  |
| Weighted-average shares—diluted | 5,040 |  |  | 5,097 |  |  | 5,054 |  |  | 5,106 |  |
| Net income per share—basic | $ | 0.47 |  |  | $ | 0.62 |  |  | $ | 0.93 |  |  | $ | 1.10 |  |
| Net income per share—diluted | $ | 0.47 |  |  | $ | 0.62 |  |  | $ | 0.92 |  |  | $ | 1.09 |  |
| Antidilutive employee share-based awards, excluded | 20 |  |  | 98 |  |  | 103 |  |  | 133 |  |


## us-gaap:EquityMethodInvestmentsTextBlock

[0000858877-17-000004:notes:188]
For such investments that were accounted for under the equity and cost method as of January 28, 2017 and July 30, 2016, the amounts are summarized in the following table (in millions):

[0000858877-17-000004:notes:189]
|  | January 28, 2017 |  | July 30, 2016 |
| Equity method investments | $ | 176 |  |  | $ | 174 |  |
| Cost method investments | 831 |  |  | 829 |  |
| Total | $ | 1,007 |  |  | $ | 1,003 |  |


## us-gaap:FairValueAssetsMeasuredOnNonrecurringBasisTextBlock

[0000858877-17-000004:notes:190]
[same as prior period, unchanged from 0000858877-16-000123:notes:185]

[0000858877-17-000004:notes:191]
|  | TOTAL GAINS (LOSSES) FOR THETHREE MONTHS ENDED |  | TOTAL GAINS (LOSSES) FOR THE SIX MONTHS ENDED |
|  | January 28, 2017 |  | January 23, 2016 |  | January 28, 2017 |  | January 23, 2016 |
| Investments in privately held companies (impaired) | $ | (64 | ) |  | $ | (39 | ) |  | $ | (111 | ) |  | $ | (56 | ) |
| Purchased intangible assets (impaired) | — |  |  | (37 | ) |  | (42 | ) |  | (37 | ) |
| Property held for sale—land and buildings | (24 | ) |  | — |  |  | (24 | ) |  | — |  |
| Total gains (losses) for nonrecurring measurements | $ | (88 | ) |  | $ | (76 | ) |  | $ | (177 | ) |  | $ | (93 | ) |


## us-gaap:FairValueDisclosuresTextBlock

[0000858877-17-000004:notes:192]
[same as prior period, unchanged from 0000858877-16-000123:notes:187]

[0000858877-17-000004:notes:193]
[same as prior period, unchanged from 0000858877-16-000123:notes:188]

[0000858877-17-000004:notes:194]
[same as prior period, unchanged from 0000858877-16-000123:notes:189]

[0000858877-17-000004:notes:195]
[same as prior period, unchanged from 0000858877-16-000123:notes:190]

[0000858877-17-000004:notes:196]
[same as prior period, unchanged from 0000858877-16-000123:notes:191]

[0000858877-17-000004:notes:197]
[same as prior period, unchanged from 0000858877-16-000123:notes:192]

[0000858877-17-000004:notes:198]
[same as prior period, unchanged from 0000858877-16-000123:notes:193]

[0000858877-17-000004:notes:199]
[same as prior period, unchanged from 0000858877-16-000123:notes:194]

[0000858877-17-000004:notes:200]
Assets and liabilities measured at fair value on a recurring basis as of January 28, 2017 and July 30, 2016 were as follows (in millions):

[0000858877-17-000004:notes:201]
|  | JANUARY 28, 2017FAIR VALUE MEASUREMENTS |  | JULY 30, 2016FAIR VALUE MEASUREMENTS |
|  | Level 1 |  | Level 2 |  | Level 3 |  | TotalBalance |  | Level 1 |  | Level 2 |  | Level 3 |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | $ | — |  |  | $ | 50 |  |  | $ | — |  |  | $ | 50 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Corporate debt securities | — |  |  | — |  |  | — |  |  | — |  |  | — |  |  | 43 |  |  | — |  |  | 43 |  |
| Money market funds | 8,635 |  |  | — |  |  | — |  |  | 8,635 |  |  | 6,049 |  |  | — |  |  | — |  |  | 6,049 |  |
| Commercial paper | — |  |  | 276 |  |  | — |  |  | 276 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Certificates of deposit | — |  |  | 30 |  |  | — |  |  | 30 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Available-for-sale investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | — |  |  | 22,832 |  |  | — |  |  | 22,832 |  |  | — |  |  | 26,544 |  |  | — |  |  | 26,544 |  |
| U.S. government agency securities | — |  |  | 2,397 |  |  | — |  |  | 2,397 |  |  | — |  |  | 2,817 |  |  | — |  |  | 2,817 |  |
| Non-U.S. government and agency securities | — |  |  | 1,205 |  |  | — |  |  | 1,205 |  |  | — |  |  | 1,100 |  |  | — |  |  | 1,100 |  |
| Corporate debt securities | — |  |  | 30,698 |  |  | — |  |  | 30,698 |  |  | — |  |  | 24,292 |  |  | — |  |  | 24,292 |  |
| U.S. agency mortgage-backed securities | — |  |  | 2,006 |  |  | — |  |  | 2,006 |  |  | — |  |  | 1,868 |  |  | — |  |  | 1,868 |  |
| Publicly traded equity securities | 1,614 |  |  | — |  |  | — |  |  | 1,614 |  |  | 1,504 |  |  | — |  |  | — |  |  | 1,504 |  |
| Commercial paper | — |  |  | 195 |  |  | — |  |  | 195 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Derivative assets | — |  |  | 118 |  |  | — |  |  | 118 |  |  | — |  |  | 384 |  |  | 1 |  |  | 385 |  |
| Total | $ | 10,249 |  |  | $ | 59,807 |  |  | $ | — |  |  | $ | 70,056 |  |  | $ | 7,553 |  |  | $ | 57,048 |  |  | $ | 1 |  |  | $ | 64,602 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities | $ | — |  |  | $ | 59 |  |  | $ | — |  |  | $ | 59 |  |  | $ | — |  |  | $ | 54 |  |  | $ | — |  |  | $ | 54 |  |
| Total | $ | — |  |  | $ | 59 |  |  | $ | — |  |  | $ | 59 |  |  | $ | — |  |  | $ | 54 |  |  | $ | — |  |  | $ | 54 |  |

[0000858877-17-000004:notes:202]
[same as prior period, unchanged from 0000858877-16-000123:notes:197]

[0000858877-17-000004:notes:203]
[same as prior period, unchanged from 0000858877-16-000123:notes:198]

[0000858877-17-000004:notes:204]
[same as prior period, unchanged from 0000858877-16-000123:notes:199]

[0000858877-17-000004:notes:205]
[same as prior period, unchanged from 0000858877-16-000123:notes:200]

[0000858877-17-000004:notes:206]
The fair value measurement of the impaired investments was classified as Level 3 because significant unobservable inputs were used in the valuation due to the absence of quoted market prices and inherent lack of liquidity. Significant unobservable inputs, which included financial metrics of comparable private and public companies, financial condition and near-term prospects of the investees, recent financing activities of the investees, and the investees’ capital structure as well as other economic variables, reflected the assumptions market participants would use in pricing these assets. The impairment charges, representing the difference between the net book value and the fair value as a result of the evaluation, were recorded to other income (loss), net. The remaining carrying value of the investments that were impaired was $44 million and $11 million as of January 28, 2017 and January 23, 2016, respectively.

[0000858877-17-000004:notes:207]
The fair value for purchased intangible assets measured at fair value on a nonrecurring basis was categorized as Level 3 due to the use of significant unobservable inputs in the valuation. Significant unobservable inputs that were used included expected revenues and net income related to the assets and the expected life of the assets. The difference between the estimated fair value and the carrying value of the assets was recorded as an impairment charge, which was included in product cost of sales and operating expenses as applicable. See Note 4. The remaining carrying value of the specific purchased intangible assets that were impaired was $9 million and zero as of January 28, 2017 and January 23, 2016.

[0000858877-17-000004:notes:208]
The fair value of property held for sale was measured with the assistance of third-party valuation models, which used discounted cash flow techniques as part of their analysis. The fair value measurement was categorized as Level 3, as significant unobservable inputs were used in the valuation report. The impairment charge as a result of the valuations, which represented the difference between the fair value less cost to sell and the carrying amount of the assets held for sale, was included in restructuring and other charges. The remaining carrying value of the property held for sale that was impaired was $11 million as of January 28, 2017.

[0000858877-17-000004:notes:209]
[same as prior period, unchanged from 0000858877-16-000123:notes:203]

[0000858877-17-000004:notes:210]
The carrying value of the Company’s investments in privately held companies that were accounted for under the cost method was $831 million and $829 million as of January 28, 2017 and July 30, 2016, respectively. It was not practicable to estimate the fair value of this portfolio.

[0000858877-17-000004:notes:211]
The fair value of the Company’s short-term loan receivables and financed service contracts approximates their carrying value due to their short duration. The aggregate carrying value of the Company’s long-term loan receivables and financed service contracts and other as of January 28, 2017 and July 30, 2016 was $3.3 billion and $2.6 billion, respectively. The estimated fair value of the Company’s long-term loan receivables and financed service contracts and other approximates their carrying value. The Company uses significant unobservable inputs in determining discounted cash flows to estimate the fair value of its long-term loan receivables and financed service contracts, and therefore they are categorized as Level 3.

[0000858877-17-000004:notes:212]
As of January 28, 2017, the estimated fair value of the short-term debt approximates its carrying value due to the short maturities.  As of January 28, 2017, the fair value of the Company’s senior notes and other long-term debt was $35.9 billion with a carrying amount of $34.6 billion. This compares to a fair value of $30.9 billion and a carrying amount of $28.6 billion as of July 30, 2016. The fair value of the senior notes and other long-term debt was determined based on observable market prices in a less active market and was categorized as Level 2 in the fair value hierarchy.


## us-gaap:FinancingReceivableCreditQualityIndicatorsTableTextBlock

[0000858877-17-000004:notes:213]
Gross receivables, excluding residual value, less unearned income categorized by the Company’s internal credit risk rating as of January 28, 2017 and July 30, 2016 are summarized as follows (in millions):

[0000858877-17-000004:notes:214]
|  | INTERNAL CREDIT RISK RATING |
| January 28, 2017 | 1 to 4 |  | 5 to 6 |  | 7 and Higher |  | Total |
| Lease receivables | $ | 1,505 |  |  | $ | 1,209 |  |  | $ | 99 |  |  | $ | 2,813 |  |
| Loan receivables | 1,259 |  |  | 934 |  |  | 176 |  |  | 2,369 |  |
| Financed service contracts and other | 2,756 |  |  | 1,355 |  |  | 54 |  |  | 4,165 |  |
| Total | $ | 5,520 |  |  | $ | 3,498 |  |  | $ | 329 |  |  | $ | 9,347 |  |

[0000858877-17-000004:notes:215]
[same as prior period, unchanged from 0000858877-16-000123:notes:209]


## us-gaap:FinancingReceivablesTextBlock

[0000858877-17-000004:notes:216]
[same as prior period, unchanged from 0000858877-16-000123:notes:210]

[0000858877-17-000004:notes:217]
[same as prior period, unchanged from 0000858877-16-000123:notes:211]

[0000858877-17-000004:notes:218]
[same as prior period, unchanged from 0000858877-16-000123:notes:212]

[0000858877-17-000004:notes:219]
[same as prior period, unchanged from 0000858877-16-000123:notes:213]

[0000858877-17-000004:notes:220]
| January 28, 2017 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts and Other |  | Total |
| Gross | $ | 2,967 |  |  | $ | 2,369 |  |  | $ | 4,165 |  |  | $ | 9,501 |  |
| Residual value | 191 |  |  | — |  |  | — |  |  | 191 |  |
| Unearned income | (154 | ) |  | — |  |  | — |  |  | (154 | ) |
| Allowance for credit loss | (225 | ) |  | (106 | ) |  | (47 | ) |  | (378 | ) |
| Total, net | $ | 2,779 |  |  | $ | 2,263 |  |  | $ | 4,118 |  |  | $ | 9,160 |  |
| Reported as: |  |  |  |  |  |  |  |
| Current | $ | 1,419 |  |  | $ | 1,040 |  |  | $ | 2,037 |  |  | $ | 4,496 |  |
| Noncurrent | 1,360 |  |  | 1,223 |  |  | 2,081 |  |  | 4,664 |  |
| Total, net | $ | 2,779 |  |  | $ | 2,263 |  |  | $ | 4,118 |  |  | $ | 9,160 |  |

[0000858877-17-000004:notes:221]
[same as prior period, unchanged from 0000858877-16-000123:notes:215]

[0000858877-17-000004:notes:222]
As of January 28, 2017 and July 30, 2016, the deferred service revenue related to "Financed Service Contracts and Other" was $1,922 million and $1,716 million, respectively.

[0000858877-17-000004:notes:223]
Future minimum lease payments to the Company on lease receivables as of January 28, 2017 are summarized as follows (in millions):

[0000858877-17-000004:notes:224]
| Fiscal Year | Amount |
| 2017 (remaining six months) | $ | 768 |  |
| 2018 | 1,141 |  |
| 2019 | 656 |  |
| 2020 | 300 |  |
| 2021 | 95 |  |
| Thereafter | 7 |  |
| Total | $ | 2,967 |  |

[0000858877-17-000004:notes:225]
[same as prior period, unchanged from 0000858877-16-000123:notes:219]

[0000858877-17-000004:notes:226]
[same as prior period, unchanged from 0000858877-16-000123:notes:220]

[0000858877-17-000004:notes:227]
[same as prior period, unchanged from 0000858877-16-000123:notes:221]

[0000858877-17-000004:notes:228]
[same as prior period, unchanged from 0000858877-16-000123:notes:222]

[0000858877-17-000004:notes:229]
In circumstances when collectibility is not deemed reasonably assured, the associated revenue is deferred in accordance with the Company’s revenue recognition policies, and the related allowance for credit loss, if any, is included in deferred revenue. The Company also records deferred revenue associated with financing receivables when there are remaining performance obligations, as it does for financed service contracts. Total allowances for credit loss and deferred revenue as of January 28, 2017 and July 30, 2016 were $2,327 million and $2,112 million, respectively, and they were associated with total financing receivables before allowances for credit loss of $9,538 million and $8,805 million as of their respective period ends.

[0000858877-17-000004:notes:230]
The following tables present the aging analysis of gross receivables, excluding residual value and less unearned income as of January 28, 2017 and July 30, 2016 (in millions):

[0000858877-17-000004:notes:231]
|  | DAYS PAST DUE (INCLUDES BILLED AND UNBILLED) |  |  |  |  |  |  |  |  |
| January 28, 2017 | 31-60 |  | 61-90 |  | 91+ |  | TotalPast Due |  | Current |  | Total |  | NonaccrualFinancingReceivables |  | ImpairedFinancingReceivables |
| Lease receivables | $ | 106 |  |  | $ | 55 |  |  | $ | 237 |  |  | $ | 398 |  |  | $ | 2,415 |  |  | $ | 2,813 |  |  | $ | 66 |  |  | $ | 66 |  |
| Loan receivables | 34 |  |  | 24 |  |  | 67 |  |  | 125 |  |  | 2,244 |  |  | 2,369 |  |  | 56 |  |  | 56 |  |
| Financed service contracts and other | 111 |  |  | 225 |  |  | 494 |  |  | 830 |  |  | 3,335 |  |  | 4,165 |  |  | 29 |  |  | 9 |  |
| Total | $ | 251 |  |  | $ | 304 |  |  | $ | 798 |  |  | $ | 1,353 |  |  | $ | 7,994 |  |  | $ | 9,347 |  |  | $ | 151 |  |  | $ | 131 |  |

[0000858877-17-000004:notes:232]
[same as prior period, unchanged from 0000858877-16-000123:notes:226]

[0000858877-17-000004:notes:233]
Past due financing receivables are those that are 31 days or more past due according to their contractual payment terms.  The data in the preceding tables is presented by contract, and the aging classification of each contract is based on the oldest outstanding receivable, and therefore past due amounts also include unbilled and current receivables within the same contract.  The balances of either unbilled or current financing receivables included in the category of 91 days plus past due for financing receivables were $444 million and $670 million as of January 28, 2017 and July 30, 2016, respectively.

[0000858877-17-000004:notes:234]
As of January 28, 2017, the Company had financing receivables of $316 million, net of unbilled or current receivables, that were in the category of 91 days plus past due but remained on accrual status as they are well secured and in the process of collection. Such balance was $144 million as of July 30, 2016.

[0000858877-17-000004:notes:235]
[same as prior period, unchanged from 0000858877-16-000123:notes:229]

[0000858877-17-000004:notes:236]
[same as prior period, unchanged from 0000858877-16-000123:notes:230]

[0000858877-17-000004:notes:237]
Typically, the Company also considers receivables with a risk rating of 8 or higher to be impaired and will include them in the individual assessment for allowance. These balances, as of January 28, 2017 and July 30, 2016, are presented under “(b) Credit Quality of Financing Receivables” above.

[0000858877-17-000004:notes:238]
[same as prior period, unchanged from 0000858877-16-000123:notes:232]

[0000858877-17-000004:notes:239]
[same as prior period, unchanged from 0000858877-16-000123:notes:233]

[0000858877-17-000004:notes:240]
[same as prior period, unchanged from 0000858877-16-000123:notes:234]

[0000858877-17-000004:notes:241]
|  | January 28, 2017 |  | July 30, 2016 |
| Operating lease assets | $ | 297 |  |  | $ | 296 |  |
| Accumulated depreciation | (169 | ) |  | (161 | ) |
| Operating lease assets, net | $ | 128 |  |  | $ | 135 |  |

[0000858877-17-000004:notes:242]
Minimum future rentals on noncancelable operating leases as of January 28, 2017 are summarized as follows (in millions):

[0000858877-17-000004:notes:243]
| Fiscal Year | Amount |
| 2017 (remaining six months) | $ | 123 |  |
| 2018 | 168 |  |
| 2019 | 76 |  |
| 2020 | 14 |  |
| 2021 | 5 |  |
| Thereafter | 2 |  |
| Total | $ | 388 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000858877-17-000004:notes:244]
[same as prior period, unchanged from 0000858877-16-000123:notes:238]

[0000858877-17-000004:notes:245]
[same as prior period, unchanged from 0000858877-16-000123:notes:239]

[0000858877-17-000004:notes:246]
The following table presents the goodwill allocated to the Company’s reportable segments as of and during the six months ended January 28, 2017 (in millions):

[0000858877-17-000004:notes:247]
|  | Balance at |  |  |  |  |  | Balance at |
|  | July 30, 2016 |  | Acquisitions |  | Other |  | January 28, 2017 |
| Americas | $ | 16,529 |  |  | $ | 132 |  |  | $ | (16 | ) |  | $ | 16,645 |  |
| EMEA | 6,269 |  |  | 62 |  |  | (3 | ) |  | 6,328 |  |
| APJC | 3,827 |  |  | 23 |  |  | (1 | ) |  | 3,849 |  |
| Total | $ | 26,625 |  |  | $ | 217 |  |  | $ | (20 | ) |  | $ | 26,822 |  |

[0000858877-17-000004:notes:248]
[same as prior period, unchanged from 0000858877-16-000123:notes:242]

[0000858877-17-000004:notes:249]
[same as prior period, unchanged from 0000858877-16-000123:notes:243]

[0000858877-17-000004:notes:250]
[same as prior period, unchanged from 0000858877-16-000123:notes:244]

[0000858877-17-000004:notes:251]
Impairment charges related to purchased intangible assets for the three and six months ended January 28, 2017 were zero and $42 million, respectively. Impairment charges were primarily as a result of declines in estimated fair values of certain purchased intangible assets resulting from the reduction or elimination of expected future cash flows associated with certain of the Company’s technology and IPR&D intangible assets. Of these impairment charges, $38 million was recorded to restructuring and other charges in connection with the Company's decision to exit certain product lines, and the corresponding elimination of future associated cash flows. Impairment charges related to purchased intangible assets for the three and six months ended January 23, 2016 were $37 million.

[0000858877-17-000004:notes:252]
The estimated future amortization expense of purchased intangible assets with finite lives as of January 28, 2017 is as follows (in millions):

[0000858877-17-000004:notes:253]
| Fiscal Year | Amount |
| 2017 (remaining six months) | $ | 343 |  |
| 2018 | 591 |  |
| 2019 | 505 |  |
| 2020 | 292 |  |
| 2021 | 148 |  |
| Thereafter | 70 |  |
| Total | $ | 1,949 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000858877-17-000004:notes:254]
[same as prior period, unchanged from 0000858877-16-000123:notes:248]

[0000858877-17-000004:notes:255]
As of January 28, 2017, the Company had $1.8 billion of unrecognized tax benefit, of which $1.3 billion, if recognized, would favorably impact the effective tax rate. The Company regularly engages in discussions and negotiations with tax authorities regarding tax matters in various jurisdictions. The Company believes it is reasonably possible that certain federal, foreign and state tax matters may be concluded in the next 12 months. Specific positions that may be resolved include issues involving transfer pricing and various other matters.  The Company estimates that the unrecognized tax benefits at January 28, 2017 could be reduced by approximately $150 million in the next 12 months.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0000858877-17-000004:notes:256]
The following table summarizes the maturities of the Company’s fixed income securities as of January 28, 2017 (in millions):

[0000858877-17-000004:notes:257]
|  | Amortized Cost |  | Fair Value |
| Less than 1 year | $ | 12,678 |  |  | $ | 12,681 |  |
| Due in 1 to 2 years | 16,678 |  |  | 16,667 |  |
| Due in 2 to 5 years | 24,535 |  |  | 24,407 |  |
| Due after 5 years | 3,704 |  |  | 3,572 |  |
| Mortgage-backed securities with no single maturity | 2,031 |  |  | 2,006 |  |
| Total | $ | 59,626 |  |  | $ | 59,333 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000858877-17-000004:notes:258]
Investments

[0000858877-17-000004:notes:259]
| (a) | Summary of Available-for-Sale Investments |

[0000858877-17-000004:notes:260]
The following tables summarize the Company’s available-for-sale investments (in millions):

[0000858877-17-000004:notes:261]
| January 28, 2017 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| Fixed income securities: |  |  |  |  |  |  |  |
| U.S. government securities | $ | 22,910 |  |  | $ | 4 |  |  | $ | (82 | ) |  | $ | 22,832 |  |
| U.S. government agency securities | 2,401 |  |  | 1 |  |  | (5 | ) |  | 2,397 |  |
| Non-U.S. government and agency securities | 1,211 |  |  | — |  |  | (6 | ) |  | 1,205 |  |
| Corporate debt securities | 30,878 |  |  | 85 |  |  | (265 | ) |  | 30,698 |  |
| U.S. agency mortgage-backed securities | 2,031 |  |  | 2 |  |  | (27 | ) |  | 2,006 |  |
| Commercial paper | 195 |  |  | — |  |  | — |  |  | 195 |  |
| Total fixed income securities | 59,626 |  |  | 92 |  |  | (385 | ) |  | 59,333 |  |
| Publicly traded equity securities | 1,225 |  |  | 463 |  |  | (74 | ) |  | 1,614 |  |
| Total (1) | $ | 60,851 |  |  | $ | 555 |  |  | $ | (459 | ) |  | $ | 60,947 |  |

[0000858877-17-000004:notes:262]
| July 30, 2016 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| Fixed income securities: |  |  |  |  |  |  |  |
| U.S. government securities | $ | 26,473 |  |  | $ | 73 |  |  | $ | (2 | ) |  | $ | 26,544 |  |
| U.S. government agency securities | 2,809 |  |  | 8 |  |  | — |  |  | 2,817 |  |
| Non-U.S. government and agency securities | 1,096 |  |  | 4 |  |  | — |  |  | 1,100 |  |
| Corporate debt securities | 24,044 |  |  | 263 |  |  | (15 | ) |  | 24,292 |  |
| U.S. agency mortgage-backed securities | 1,846 |  |  | 22 |  |  | — |  |  | 1,868 |  |
| Total fixed income securities | 56,268 |  |  | 370 |  |  | (17 | ) |  | 56,621 |  |
| Publicly traded equity securities | 1,211 |  |  | 333 |  |  | (40 | ) |  | 1,504 |  |
| Total (1) | $ | 57,479 |  |  | $ | 703 |  |  | $ | (57 | ) |  | $ | 58,125 |  |

[0000858877-17-000004:notes:263]
(1) Includes investments that were pending settlement as of the respective fiscal years. The net unsettled investment purchases were $6 million and $654 million as of January 28, 2017 and July 30, 2016, respectively.

[0000858877-17-000004:notes:264]
Non-U.S. government and agency securities include agency and corporate debt securities that are guaranteed by non-U.S. governments.

[0000858877-17-000004:notes:265]
| (b) | Gains and Losses on Available-for-Sale Investments |

[0000858877-17-000004:notes:266]
The following table presents the gross realized gains and gross realized losses related to the Company’s available-for-sale investments (in millions):

[0000858877-17-000004:notes:267]
|  | Three Months Ended |  | Six Months Ended |
|  | January 28, 2017 |  | January 23, 2016 |  | January 28, 2017 |  | January 23, 2016 |
| Gross realized gains | $ | 18 |  |  | $ | 16 |  |  | $ | 48 |  |  | $ | 51 |  |
| Gross realized losses | (48 | ) |  | (35 | ) |  | (63 | ) |  | (71 | ) |
| Total | $ | (30 | ) |  | $ | (19 | ) |  | $ | (15 | ) |  | $ | (20 | ) |

[0000858877-17-000004:notes:268]
The following table presents the realized net gains (losses) related to the Company’s available-for-sale investments by security type (in millions):

[0000858877-17-000004:notes:269]
|  | Three Months Ended |  | Six Months Ended |
|  | January 28, 2017 |  | January 23, 2016 |  | January 28, 2017 |  | January 23, 2016 |
| Net gains (losses) on investments in publicly traded equity securities | $ | 4 |  |  | $ | 2 |  |  | $ | 9 |  |  | $ | (7 | ) |
| Net gains (losses) on investments in fixed income securities | (34 | ) |  | (21 | ) |  | (24 | ) |  | (13 | ) |
| Total | $ | (30 | ) |  | $ | (19 | ) |  | $ | (15 | ) |  | $ | (20 | ) |

[0000858877-17-000004:notes:270]
The following tables present the breakdown of the available-for-sale investments with gross unrealized losses and the duration that those losses had been unrealized at January 28, 2017 and July 30, 2016 (in millions):

[0000858877-17-000004:notes:271]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| January 28, 2017 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| Fixed income securities: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | $ | 16,303 |  |  | $ | (82 | ) |  | $ | 16 |  |  | $ | — |  |  | $ | 16,319 |  |  | $ | (82 | ) |
| U.S. government agency securities | 1,430 |  |  | (5 | ) |  | — |  |  | — |  |  | 1,430 |  |  | (5 | ) |
| Non-U.S. government and agency securities | 1,107 |  |  | (6 | ) |  | 6 |  |  | — |  |  | 1,113 |  |  | (6 | ) |
| Corporate debt securities | 15,180 |  |  | (264 | ) |  | 325 |  |  | (1 | ) |  | 15,505 |  |  | (265 | ) |
| U.S. agency mortgage-backed securities | 1,780 |  |  | (27 | ) |  | — |  |  | — |  |  | 1,780 |  |  | (27 | ) |
| Total fixed income securities | 35,800 |  |  | (384 | ) |  | 347 |  |  | (1 | ) |  | 36,147 |  |  | (385 | ) |
| Publicly traded equity securities | 63 |  |  | (6 | ) |  | 94 |  |  | (68 | ) |  | 157 |  |  | (74 | ) |
| Total | $ | 35,863 |  |  | $ | (390 | ) |  | $ | 441 |  |  | $ | (69 | ) |  | $ | 36,304 |  |  | $ | (459 | ) |

[0000858877-17-000004:notes:272]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 30, 2016 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| Fixed income securities: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | $ | 2,414 |  |  | $ | (2 | ) |  | $ | — |  |  | $ | — |  |  | $ | 2,414 |  |  | $ | (2 | ) |
| U.S. government agency securities | 144 |  |  | — |  |  | — |  |  | — |  |  | 144 |  |  | — |  |
| Non-U.S. government and agency securities | 61 |  |  | — |  |  | — |  |  | — |  |  | 61 |  |  | — |  |
| Corporate debt securities | 2,499 |  |  | (7 | ) |  | 1,208 |  |  | (8 | ) |  | 3,707 |  |  | (15 | ) |
| U.S. agency mortgage-backed securities | 174 |  |  | — |  |  | — |  |  | — |  |  | 174 |  |  | — |  |
| Total fixed income securities | 5,292 |  |  | (9 | ) |  | 1,208 |  |  | (8 | ) |  | 6,500 |  |  | (17 | ) |
| Publicly traded equity securities | 188 |  |  | (40 | ) |  | — |  |  | — |  |  | 188 |  |  | (40 | ) |
| Total | $ | 5,480 |  |  | $ | (49 | ) |  | $ | 1,208 |  |  | $ | (8 | ) |  | $ | 6,688 |  |  | $ | (57 | ) |

[0000858877-17-000004:notes:273]
As of January 28, 2017, for fixed income securities that were in unrealized loss positions, the Company has determined that (i) it does not have the intent to sell any of these investments and (ii) it is not more likely than not that it will be required to sell any of these investments before recovery of the entire amortized cost basis. In addition, as of January 28, 2017, the Company anticipates that it will recover the entire amortized cost basis of such fixed income securities and has determined that no other-than-temporary impairments associated with credit losses were required to be recognized during the six months ended January 28, 2017.

[0000858877-17-000004:notes:274]
The Company has evaluated its publicly traded equity securities as of January 28, 2017 and has determined that there were no other-than-temporary impairments in the respective categories of unrealized losses. This determination was based on several factors, which include the length of time and extent to which fair value has been less than the cost basis, the financial condition and near-term prospects of the issuer, and the Company’s intent and ability to hold the publicly traded equity securities for a period of time sufficient to allow for any anticipated recovery in market value.

[0000858877-17-000004:notes:275]
| (c) | Maturities of Fixed Income Securities |

[0000858877-17-000004:notes:276]
Actual maturities may differ from the contractual maturities because borrowers may have the right to call or prepay certain obligations.

[0000858877-17-000004:notes:277]
| (d) | Securities Lending |

[0000858877-17-000004:notes:278]
The Company periodically engages in securities lending activities with certain of its available for sale investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. The average daily balance of securities lending for the six months ended January 28, 2017 and January 23, 2016 was $1.5 billion and $0.6 billion, respectively. The Company requires collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. The Company engages in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify the Company against collateral losses. The Company did not experience any losses in connection with the secured lending of securities during the periods presented. As of January 28, 2017 and July 30, 2016, the Company had no outstanding securities lending transactions.

[0000858877-17-000004:notes:279]
| (e) | Investments in Privately Held Companies |

[0000858877-17-000004:notes:280]
The carrying value of the Company’s investments in privately held companies was included in other assets. For such investments that were accounted for under the equity and cost method as of January 28, 2017 and July 30, 2016, the amounts are summarized in the following table (in millions):

[0000858877-17-000004:notes:281]
For additional information on impairment charges related to investments in privately held companies, see Note 9.

[0000858877-17-000004:notes:282]
Variable Interest Entities  In the ordinary course of business, the Company has investments in privately held companies and provides financing to certain customers. These privately held companies and customers may be considered to be variable interest entities. The Company evaluates on an ongoing basis its investments in these privately held companies and its customer financings, and has determined that as of January 28, 2017, except as disclosed in Note 1, there were no significant variable interest entities required to be consolidated in the Company’s Consolidated Financial Statements.

[0000858877-17-000004:notes:283]
As discussed in Note 2, during the first quarter of fiscal 2017, the Company adopted a new accounting standard update related to the consolidation of certain types of legal entities. As of January 28, 2017, the carrying value of the Company's investments in privately held companies was $1,007 million, of which $580 million of such investments are considered to be in variable interest entities which are unconsolidated. In addition, the Company has additional funding commitments of $182 million related to these investments, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The carrying value of these investments and the additional funding commitments collectively represent the Company's maximum exposure related to these variable interest entities.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0000858877-17-000004:notes:284]
(a) New Accounting Updates Recently Adopted

[0000858877-17-000004:notes:285]
Consolidation of Certain Types of Legal Entities  In February 2015, the FASB issued an accounting standard update that changes the analysis that a reporting entity must perform to determine whether it should consolidate certain types of legal entities. The accounting standard update became effective for the Company beginning in the first quarter of fiscal 2017. The application of this accounting standard update did not have any impact on the Company's Consolidated Balance Sheet or Statement of Operations upon adoption, but the Company has provided additional disclosures in Note 8 pursuant to this accounting standard update.

[0000858877-17-000004:notes:286]
(b) Recent Accounting Standards or Updates Not Yet Effective

[0000858877-17-000004:notes:287]
Revenue Recognition  In May 2014, the Financial Accounting Standards Board ("FASB") issued an accounting standard update related to revenue from contracts with customers, which, along with amendments issued in 2015 and 2016, will supersede nearly all current U.S. GAAP guidance on this topic and eliminate industry-specific guidance. The underlying principle is to recognize revenue when promised goods or services are transferred to customers in an amount that reflects the consideration that is expected to be received for those goods or services. This accounting standard update, as amended, will be effective for the Company beginning in the first quarter of fiscal 2019. The new revenue standard may be applied retrospectively to each prior period presented or retrospectively with the cumulative effect recognized in retained earnings as of the date of adoption ("modified retrospective basis"). Early adoption is permitted, but no earlier than fiscal 2018. The Company expects to adopt this accounting standard update on a modified retrospective basis in the first quarter of fiscal 2019, and it is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.

[0000858877-17-000004:notes:288]
Financial Instruments  In January 2016, the FASB issued an accounting standard update that changes the accounting for equity investments, financial liabilities under the fair value option, and the presentation and disclosure requirements for financial instruments. The accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2019, and early adoption is permitted. The Company is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.

[0000858877-17-000004:notes:289]
Leases  In February 2016, the FASB issued an accounting standard update related to leases requiring lessees to recognize operating and financing lease liabilities on the balance sheet, as well as corresponding right-of-use assets. The new lease standard also makes some changes to lessor accounting and aligns key aspects of the lessor accounting model with the revenue recognition standard. In addition, disclosures will be required to enable users of financial statements to assess the amount, timing, and uncertainty of cash flows arising from leases. The accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2020 on a modified retrospective basis, and early adoption is permitted. The Company is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.

[0000858877-17-000004:notes:290]
Share-Based Compensation  In March 2016, the FASB issued an accounting standard update that impacts the accounting for share-based payment transactions, including income tax consequences, classification of awards as either equity or liabilities, and classification on the Consolidated Statements of Cash Flows. The accounting standard will be effective for the Company beginning the first quarter of fiscal 2018, and early adoption is permitted. The Company is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.

[0000858877-17-000004:notes:291]
Credit Losses of Financial Instruments  In June 2016, the FASB issued an accounting standard update that requires measurement and recognition of expected credit losses for financial assets held based on historical experience, current conditions, and reasonable and supportable forecasts that affect the collectibility of the reported amount. The accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2021 on a modified retrospective basis, and early adoption in fiscal 2020 is permitted. The Company is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.

[0000858877-17-000004:notes:292]
Classification of Cash Flow Elements  In August 2016, the FASB issued an accounting standard update related to the classification of certain cash receipts and cash payments on the statement of cash flows. The accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2019 on a retrospective basis, and early adoption is permitted. The Company is currently evaluating the impact of this accounting standard update on its Consolidated Statements of Cash Flows.

[0000858877-17-000004:notes:293]
Income Taxes on Intra-Entity Transfers of Assets  In October 2016, the FASB issued an accounting standard update that requires recognition of the income tax consequences of intra-entity transfers of assets (other than inventory) at the transaction date. The accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2019 on a modified retrospective basis, and early adoption is permitted. The Company is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.

[0000858877-17-000004:notes:294]
Restricted Cash in Statement of Cash Flow  In November 2016, the FASB issued an accounting standard update that provides guidance on the classification and presentation of changes in restricted cash and cash equivalents in the statement of cash flows. The accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2019 using a retrospective transition method to each period presented, and early adoption is permitted. The Company does not expect that this  accounting standard update will have a material impact on its Consolidated Statements of Cash Flows.

[0000858877-17-000004:notes:295]
Definition of a Business  In January 2017, the FASB issued an accounting standard update that clarifies the definition of a business to help companies evaluate whether acquisition or disposal transactions should be accounted for as asset groups or as businesses. The accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2019 on a prospective basis. The impact of this accounting standard update will be facts and circumstances dependent, but the Company expects that in some situations transactions that were previously accounted for as business combinations  or disposal transactions will be accounted for as asset purchases or asset sales under the accounting standard update.

[0000858877-17-000004:notes:296]
Simplifying the Test for Goodwill Impairment  In January 2017, the FASB issued an accounting standard update that removes Step 2 of the goodwill impairment test, which requires the assessment of fair value of individual assets and liabilities of a reporting unit to measure goodwill impairments. Goodwill impairment will now be the amount by which a reporting unit's carrying value exceeds its fair value. The accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2021 on a prospective basis, and early adoption is permitted. The Company does not expect that this accounting standard update will impact its Consolidated Financial Statements.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000858877-17-000004:notes:297]
[same as prior period, unchanged from 0000858877-16-000123:notes:288]

[0000858877-17-000004:notes:298]
[same as prior period, unchanged from 0000858877-16-000123:notes:289]

[0000858877-17-000004:notes:299]
Certain reclassifications have been made to the amounts in prior periods in order to conform to the current period’s presentation.  The Company has evaluated subsequent events through the date that the financial statements were issued.


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0000858877-17-000004:notes:300]
| Property and equipment, net: |  |  |  |  |
| Gross property and equipment: |  |  |  |  |
| Land, buildings, and building and leasehold improvements |  | $ | 4,800 |  |  | $ | 4,778 |  |
| Computer equipment and related software |  | 1,301 |  |  | 1,288 |  |
| Production, engineering, and other equipment |  | 5,680 |  |  | 5,658 |  |
| Operating lease assets |  | 297 |  |  | 296 |  |
| Furniture and fixtures |  | 560 |  |  | 543 |  |
| Total gross property and equipment |  | 12,638 |  |  | 12,563 |  |
| Less: accumulated depreciation and amortization |  | (9,216 | ) |  | (9,057 | ) |
| Total |  | $ | 3,422 |  |  | $ | 3,506 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000858877-17-000004:notes:301]
[same as prior period, unchanged from 0000858877-16-000123:notes:292]

[0000858877-17-000004:notes:302]
In August 2016, the Company announced a restructuring plan (the "Fiscal 2017 Plan") in order to reinvest in its key priority areas such as security, the Internet of Things (IoT), collaboration, next generation data center and cloud. In connection with this plan, the Company expects that up to 5,500 employees will be impacted, representing approximately 7% of its global workforce. The Company's aggregate pretax estimated charges pursuant to the restructuring plan are expected to be approximately $700 million, consisting primarily of severance and other one-time termination benefits, and other associated costs. These charges are primarily cash-based, and the Company expects the Fiscal 2017 Plan to be substantially completed by the end of fiscal 2017. The Company incurred charges of $133 million, and $95 million, net of a $1 million credit to cost of sales for the three months ended January 28, 2017 and January 23, 2016, respectively, and $544 million and $236 million, net of a $2 million credit to cost of sales for the six months ended January 28, 2017 and January 23, 2016, respectively.

[0000858877-17-000004:notes:303]
[same as prior period, unchanged from 0000858877-16-000123:notes:294]

[0000858877-17-000004:notes:304]
[same as prior period, unchanged from 0000858877-16-000123:notes:295]

[0000858877-17-000004:notes:305]
|  |  | FISCAL 2015 AND PRIOR PLANS |  | FISCAL 2017 PLAN |  |  |
|  |  | EmployeeSeverance |  | Other |  | EmployeeSeverance |  | Other |  | Total |
| Liability as of July 30, 2016 |  | $ | 21 |  |  | $ | 24 |  |  | $ | — |  |  | $ | — |  |  | $ | 45 |  |
| Charges |  | — |  |  | — |  |  | 452 |  |  | 92 |  |  | 544 |  |
| Cash payments |  | (13 | ) |  | (4 | ) |  | (368 | ) |  | (3 | ) |  | (388 | ) |
| Non-cash items |  | (4 | ) |  | (9 | ) |  | (2 | ) |  | (58 | ) |  | (73 | ) |
| Liability as of January 28, 2017 |  | $ | 4 |  |  | $ | 11 |  |  | $ | 82 |  |  | $ | 31 |  |  | $ | 128 |  |

[0000858877-17-000004:notes:306]
|  |  | FISCAL 2015 AND PRIOR PLANS |  |  |
|  |  | EmployeeSeverance |  | Other |  | Total |
| Liability as of July 25, 2015 |  | $ | 60 |  |  | $ | 29 |  |  | $ | 89 |  |
| Charges |  | 206 |  |  | 32 |  |  | 238 |  |
| Cash payments |  | (187 | ) |  | (10 | ) |  | (197 | ) |
| Non-cash items |  | — |  |  | (21 | ) |  | (21 | ) |
| Liability as of January 23, 2016 |  | $ | 79 |  |  | $ | 30 |  |  | $ | 109 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0000858877-17-000004:notes:307]
[same as prior period, unchanged from 0000858877-16-000123:notes:298]

[0000858877-17-000004:notes:308]
|  |  | January 28, 2017 |  | July 30, 2016 |
| Inventories: |  |  |  |  |
| Raw materials |  | $ | 149 |  |  | $ | 91 |  |
| Work in process |  | 1 |  |  | — |  |
| Finished goods: |  |  |  |  |
| Distributor inventory and deferred cost of sales |  | 422 |  |  | 457 |  |
| Manufactured finished goods |  | 413 |  |  | 415 |  |
| Total finished goods |  | 835 |  |  | 872 |  |
| Service-related spares |  | 260 |  |  | 236 |  |
| Demonstration systems |  | 19 |  |  | 18 |  |
| Total |  | $ | 1,264 |  |  | $ | 1,217 |  |


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000858877-17-000004:notes:309]
[same as prior period, unchanged from 0000858877-16-000123:notes:300]


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000858877-17-000004:notes:310]
[same as prior period, unchanged from 0000858877-16-000123:notes:301]

[0000858877-17-000004:notes:311]
[same as prior period, unchanged from 0000858877-16-000123:notes:302]

[0000858877-17-000004:notes:312]
During the six months ended January 28, 2017, the Company declared and paid cash dividends of $0.52 per common share, or $2.6 billion, on the Company’s outstanding common stock. During the six months ended January 23, 2016, the Company declared and paid cash dividends of $0.42 per common share, or $2.1 billion, on the Company’s outstanding common stock.

[0000858877-17-000004:notes:313]
On February 15, 2017, the Company's Board of Directors declared a quarterly dividend of $0.29 per common share to be paid on April 26, 2017 to all shareholders of record as of the close of business on April 6, 2017.  Any future dividends will be subject to the approval of the Company's Board of Directors.

[0000858877-17-000004:notes:314]
[same as prior period, unchanged from 0000858877-16-000123:notes:305]

[0000858877-17-000004:notes:315]
In September 2001, the Company’s Board of Directors authorized a stock repurchase program. As of January 28, 2017, the Company’s Board of Directors had authorized an aggregate repurchase of up to $112 billion of common stock under this program, and the remaining authorized repurchase amount was $13.4 billion, with no termination date. A summary of the stock repurchase activity under the stock repurchase program, reported based on the trade date, is summarized as follows (in millions, except per-share amounts):

[0000858877-17-000004:notes:316]
[same as prior period, unchanged from 0000858877-16-000123:notes:307]

[0000858877-17-000004:notes:317]
[same as prior period, unchanged from 0000858877-16-000123:notes:308]

[0000858877-17-000004:notes:318]
For the six months ended January 28, 2017 and January 23, 2016, the Company repurchased approximately 14 million and 16 million shares, or $432 million and $412 million of common stock, respectively, in settlement of employee tax withholding obligations due upon the vesting of restricted stock or stock units.

[0000858877-17-000004:notes:319]
[same as prior period, unchanged from 0000858877-16-000123:notes:310]

[0000858877-17-000004:notes:320]
[same as prior period, unchanged from 0000858877-16-000123:notes:311]


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000858877-17-000004:notes:321]
[same as prior period, unchanged from 0000858877-16-000123:notes:312]


## us-gaap:TreasuryStockTextBlock

[0000858877-17-000004:notes:322]
[same as prior period, unchanged from 0000858877-16-000123:notes:313]

[0000858877-17-000004:notes:323]
In September 2001, the Company’s Board of Directors authorized a stock repurchase program. As of January 28, 2017, the Company’s Board of Directors had authorized an aggregate repurchase of up to $112 billion of common stock under this program with no termination date. For additional information regarding stock repurchase, see Note 13 to the Consolidated Financial Statements. The stock repurchases since the inception of this program and the related impacts on Cisco shareholders’ equity are summarized in the following table (in millions):
