# CSCO 8-K — 0001193125-17-045265 filed 2017-02-15

## item codes, every 8-K on or before 2017-02-21

- 2017-02-15 0001193125-17-045265 — 2.02
- 2016-12-22 0001193125-16-802182 — 8.01
- 2016-12-13 0001193125-16-791877 — 5.07
- 2016-11-16 0001193125-16-769785 — 2.02
- 2016-11-03 0001193125-16-758911 — 5.02, 9.01
- 2016-10-17 0001193125-16-739833 — 5.02
- 2016-09-21 0001193125-16-716006 — 8.01
- 2016-09-20 0001193125-16-714189 — 8.01, 9.01
- 2016-09-16 0001193125-16-712320 — 8.01
- 2016-09-15 0001193125-16-711098 — 1.01, 9.01
- 2016-09-13 0001193125-16-708007 — 8.01, 9.01
- 2016-09-06 0001193125-16-702020 — 8.01
- 2016-08-17 0001193125-16-684126 — 2.02, 2.05
- 2016-07-29 0001193125-16-664620 — 5.03, 9.01
- 2016-06-27 0001193125-16-633145 — 8.01
- 2016-06-23 0001193125-16-630146 — 8.01
- 2016-06-07 0001193125-16-615321 — 5.02, 9.01
- 2016-05-18 0001193125-16-594463 — 2.02
- 2016-03-24 0001193125-16-516953 — 8.01
- 2016-02-29 0001193125-16-483780 — 8.01, 9.01
- 2016-02-25 0001193125-16-478442 — 8.01
- 2016-02-24 0001193125-16-474071 — 1.01, 9.01
- 2016-02-22 0001193125-16-470856 — 8.01, 9.01
- 2016-02-10 0001193125-16-457586 — 2.02
- 2016-01-28 0001193125-16-441933 — 5.02
- 2015-12-08 0001193125-15-397797 — 8.01
- 2015-11-20 0001193125-15-383743 — 5.07
- 2015-11-12 0001193125-15-375655 — 2.02
- 2015-09-21 0001193125-15-324465 — 8.01
- 2015-09-17 0001193125-15-322456 — 8.01
- 2015-09-14 0001193125-15-319489 — 8.01
- 2015-08-28 0001193125-15-306843 — 8.01
- 2015-08-12 0001193125-15-288099 — 2.02
- 2015-07-29 0001193125-15-268359 — 5.02 — amendment of 0001193125-15-169227
- 2015-06-18 0001193125-15-227387 — 8.01, 9.01
- 2015-06-12 0001193125-15-221863 — 1.01, 9.01
- 2015-06-10 0001193125-15-218734 — 8.01, 9.01
- 2015-06-01 0001193125-15-209142 — 5.02, 9.01
- 2015-05-13 0001193125-15-185905 — 2.02
- 2015-05-04 0001193125-15-169227 — 5.02
- 2015-03-24 0001193125-15-103369 — 8.01
- 2015-03-19 0001193125-15-098638 — 8.01
- 2015-02-11 0001193125-15-044175 — 2.02
- 2014-12-19 0001193125-14-448754 — 8.01
- 2014-12-18 0001193125-14-447039 — 8.01
- 2014-11-24 0001193125-14-423591 — 5.02, 5.07, 9.01
- 2014-11-14 0001193125-14-413384 — 5.02
- 2014-11-12 0001193125-14-409258 — 2.02
- 2014-09-25 0001193125-14-353210 — 8.01
- 2014-09-12 0001193125-14-340480 — 5.02
- 2014-08-14 0001193125-14-308733 — 2.05
- 2014-08-13 0001193125-14-308403 — 2.02
- 2014-07-31 0001193125-14-289683 — 5.02
- 2014-06-25 0001193125-14-249157 — 8.01
- 2014-05-14 0001193125-14-199056 — 2.02
- 2014-03-26 0001193125-14-116588 — 8.01
- 2014-03-11 0001193125-14-093805 — 8.01
- 2014-03-03 0001193125-14-079163 — 1.01, 8.01, 9.01
- 2014-02-26 0001193125-14-069912 — 1.01, 9.01
- 2014-02-12 0001193125-14-048150 — 2.02
- 2013-12-23 0001193125-13-483099 — 8.01
- 2013-12-04 0001193125-13-462216 — 8.01
- 2013-11-20 0001193125-13-448477 — 5.02, 5.07, 9.01
- 2013-11-13 0001193125-13-440194 — 2.02
- 2013-08-15 0001193125-13-335218 — 2.05
- 2013-08-14 0001193125-13-334648 — 2.02
- 2013-07-23 0001193125-13-298129 — 8.01, 9.01
- 2013-06-24 0001193125-13-269064 — 8.01
- 2013-06-12 0001193125-13-256194 — 8.01
- 2013-06-07 0001193125-13-250920 — 8.01
- 2013-05-15 0001193125-13-222377 — 2.02
- 2013-03-26 0001193125-13-127015 — 8.01
- 2013-02-13 0001193125-13-055377 — 2.02
- 2013-02-01 0001193125-13-034682 — 5.02
- 2013-01-08 0001193125-13-006886 — 5.02, 9.01
- 2012-12-21 0001193125-12-513130 — 8.01
- 2012-12-19 0001193125-12-508424 — 8.01
- 2012-11-16 0001193125-12-474089 — 5.02, 5.07, 9.01
- 2012-11-13 0001193125-12-467422 — 2.02
- 2012-10-04 0001193125-12-415386 — 5.02, 5.03, 9.01
- 2012-09-19 0001193125-12-396875 — 5.02, 8.01
- 2012-08-15 0001193125-12-357479 — 2.02
- 2012-08-02 0001193125-12-332045 — 5.02
- 2012-06-27 0001193125-12-285742 — 8.01
- 2012-06-13 0001193125-12-269642 — 8.01
- 2012-05-09 0001193125-12-222045 — 2.02
- 2012-03-27 0001193125-12-134384 — 8.01
- 2012-03-15 0001193125-12-117538 — 8.01, 9.01
- 2012-02-17 0001193125-12-067542 — 1.01, 1.02, 2.03, 9.01
- 2012-02-08 0001193125-12-046545 — 2.02
- 2011-12-16 0001193125-11-343995 — 8.01
- 2011-12-08 0001193125-11-335127 — 5.02, 5.07, 9.01
- 2011-11-09 0001193125-11-304587 — 2.02
- 2011-09-29 0001193125-11-260065 — 8.01
- 2011-09-20 0001193125-11-252379 — 5.02, 9.01
- 2011-08-24 0001193125-11-231015 — 8.01
- 2011-08-10 0001193125-11-218133 — 2.02
- 2011-07-18 0001193125-11-190246 — 2.05
- 2011-06-22 0001193125-11-170849 — 8.01
- 2011-05-11 0001193125-11-135913 — 2.02
- 2011-03-28 0001193125-11-079927 — 8.01
- 2011-03-22 0001193125-11-073802 — 5.02 — amendment of 0001193125-11-043592
- 2011-03-18 0001193125-11-071279 — 8.01, 9.01
- 2011-03-16 0001193125-11-067985 — 1.01, 5.02, 8.01, 9.01
- 2011-03-15 0001193125-11-067331 — 1.01, 9.01
- 2011-03-09 0001193125-11-060123 — 8.01, 9.01
- 2011-02-23 0001193125-11-043592 — 5.02
- 2011-02-09 0001193125-11-028987 — 2.02
- 2011-01-31 0001193125-11-019101 — 1.01, 2.03
- 2010-12-17 0001193125-10-283392 — 8.01
- 2010-11-19 0001193125-10-265377 — 5.07
- 2010-11-10 0001193125-10-256001 — 2.02
- 2010-09-22 0001193125-10-214707 — 8.01
- 2010-09-16 0001193125-10-211456 — 7.01
- 2010-08-11 0001193125-10-186042 — 2.02
- 2010-06-29 0001193125-10-149956 — 8.01
- 2010-05-12 0001193125-10-117509 — 2.02
- 2010-02-17 0001193125-10-033290 — 5.02, 8.01, 9.01
- 2010-02-03 0001193125-10-020775 — 2.02
- 2009-11-25 0001193125-09-242589 — 8.01
- 2009-11-17 0001193125-09-236335 — 1.01, 8.01, 9.01
- 2009-11-13 0001193125-09-234405 — 1.01, 2.03, 9.01
- 2009-11-13 0001193125-09-234397 — 5.02 — amendment of 0001193125-09-189511
- 2009-11-12 0001193125-09-232971 — 5.02, 7.01, 9.01
- 2009-11-09 0001193125-09-228541 — 8.01, 9.01
- 2009-11-04 0001193125-09-223763 — 2.02
- 2009-10-14 0001193125-09-207912 — 8.01, 9.01
- 2009-10-05 0001193125-09-203556 — 8.01
- 2009-09-10 0001193125-09-189511 — 5.02
- 2009-09-04 0001193125-09-187835 — 5.02
- 2009-08-05 0001193125-09-165404 — 2.02
- 2009-07-27 0001193125-09-155861 — 5.02
- 2009-05-29 0001193125-09-121672 — 8.01
- 2009-05-06 0001193125-09-101570 — 2.02
- 2009-02-26 0001193125-09-038162 — 5.02
- 2009-02-17 0001193125-09-030546 — 1.01, 8.01, 9.01
- 2009-02-13 0001193125-09-029295 — 1.01, 2.03, 9.01
- 2009-02-04 0001193125-09-018793 — 2.02
- 2008-11-05 0001193125-08-225857 — 2.02
- 2008-09-11 0001193125-08-194695 — 7.01
- 2008-08-05 0001193125-08-166496 — 2.02
- 2008-06-20 0001193125-08-137504 — 8.01
- 2008-05-06 0001193125-08-104089 — 2.02
- 2008-03-21 0001193125-08-062838 — 8.01
- 2008-02-06 0001193125-08-021681 — 2.02
- 2008-01-23 0001193125-08-010589 — 5.02
- 2008-01-04 0001193125-08-001680 — 5.02, 9.01
- 2007-12-21 0001193125-07-269613 — 5.02
- 2007-11-19 0001193125-07-250345 — 5.02 — amendment of 0001193125-07-009285
- 2007-11-19 0001193125-07-250343 — 5.02, 9.01
- 2007-11-07 0001193125-07-238464 — 2.02
- 2007-09-24 0001193125-07-206279 — 8.01
- 2007-09-20 0001193125-07-204616 — 5.02, 7.01
- 2007-09-07 0001193125-07-197514 — 8.01
- 2007-08-17 0001193125-07-185320 — 1.01, 2.03, 9.01
- 2007-08-08 0001193125-07-174077 — 5.02
- 2007-08-07 0001193125-07-173689 — 2.02
- 2007-08-01 0001193125-07-168143 — 5.02
- 2007-05-15 0001193125-07-115800 — 8.01
- 2007-05-08 0001193125-07-106059 — 2.02
- 2007-03-23 0001193125-07-063033 — 5.02, 5.03, 8.01, 9.01
- 2007-03-21 0001193125-07-060631 — 1.01, 9.01
- 2007-02-06 0001193125-07-021349 — 2.02
- 2007-01-19 0001193125-07-009285 — 5.02
- 2006-12-22 0001193125-06-259241 — 8.01
- 2006-11-16 0001193125-06-237260 — 5.03, 8.01, 9.01
- 2006-11-08 0001193125-06-228341 — 2.02
- 2006-09-21 0001193125-06-194890 — 1.01, 7.01
- 2006-09-20 0001193125-06-194063 — 1.01
- 2006-09-15 0001193125-06-191845 — 5.02
- 2006-08-18 0001193125-06-176193 — 5.02
- 2006-08-08 0001193125-06-165719 — 2.02
- 2006-07-31 0001193125-06-157106 — 1.01, 9.01
- 2006-07-31 0001193125-06-157102 — 5.02 — amendment of 0001193125-06-017426
- 2006-06-08 0001193125-06-126879 — 5.02
- 2006-05-18 0001193125-06-115516 — 8.01
- 2006-05-12 0001193125-06-110924 — 9.01 — amendment of 0001193125-06-044013
- 2006-05-09 0001193125-06-105419 — 2.02
- 2006-03-29 0001193125-06-066990 — 1.01
- 2006-03-02 0001193125-06-044013 — 1.01, 2.01, 9.01
- 2006-02-28 0001193125-06-041452 — 1.01
- 2006-02-22 0001193125-06-036759 — 8.01
- 2006-02-22 0001193125-06-036433 — 1.01, 8.01, 9.01
- 2006-02-21 0001193125-06-035865 — 1.01, 2.03, 9.01
- 2006-02-10 0001193125-06-026218 — 8.01, 9.01
- 2006-02-07 0001193125-06-022234 — 2.02
- 2006-02-01 0001193125-06-017426 — 5.02
- 2005-11-18 0001193125-05-229535 — 1.01, 9.01
- 2005-11-16 0001193125-05-227987 — 1.01, 9.01
- 2005-11-16 0001193125-05-227983 — 5.02 — amendment of 0001193125-05-008843
- 2005-11-09 0001193125-05-221610 — 2.02
- 2005-09-29 0001193125-05-194217 — 7.01
- 2005-09-27 0001193125-05-192353 — 8.01
- 2005-09-21 0001193125-05-189234 — 1.01, 9.01
- 2005-09-19 0001193125-05-187646 — 8.01
- 2005-09-09 0001193125-05-183273 — 8.01
- 2005-09-08 0001193125-05-182307 — 1.01
- 2005-08-09 0001193125-05-162626 — 2.02
- 2005-07-15 0001193125-05-142738 — 8.01
- 2005-05-10 0001193125-05-102797 — 2.02
- 2005-03-30 0001193125-05-065123 — 1.01, 3.03, 9.01
- 2005-03-04 0001193125-05-042778 — 1.01
- 2005-02-08 0001193125-05-022181 — 2.02
- 2005-01-20 0001193125-05-008843 — 5.02
- 2004-12-23 0001193125-04-219331 — 8.01
- 2004-11-09 0001193125-04-191303 — 2.02
- 2004-08-23 0001193125-04-145198 — 1.01, 7.01
- 2004-08-19 0001193125-04-143859 — 5
- 2004-08-10 0001193125-04-136865 — 12
- 2004-05-11 0001193125-04-084721 — 12
- 2004-02-03 0001193125-04-013750 — 12
- 2003-11-05 0001193125-03-073418 — 12
- 2003-09-02 0001193125-03-044521 — 9
- 2003-08-05 0001193125-03-029223 — 12, 7
- 2003-07-18 0001193125-03-021155 — 5, 7
- 2003-06-05 0001012870-03-002949 — 5
- 2003-05-06 0000891618-03-002315 — 7, 9
- 2003-04-17 0000891618-03-001894 — 5, 7
- 2003-04-11 0000891618-03-001791 — 9
- 2003-03-20 0000891618-03-001326 — 5, 7
- 2003-02-04 0000891618-03-000518 — 7, 9
- 2003-01-28 0000891618-03-000271 — 5, 7
- 2002-12-27 0000891618-02-005686 — 5, 7
- 2002-10-23 0000891618-02-004715 — 5, 7
- 2002-10-11 0000891618-02-004620 — 5, 7
- 2002-09-18 0000891618-02-004352 — 5, 7
- 2002-08-20 0000891618-02-004001 — 5, 7
- 2002-08-05 0000891618-02-003498 — 5, 7
- 2002-07-03 0000891618-02-003099 — 5, 7
- 2002-05-14 0000891618-02-002407 — 5, 7
- 2002-02-05 0000891618-02-000412 — 5, 7
- 2001-09-28 0001095811-01-505261 — 5, 7
- 2001-09-14 0001095811-01-504917 — 5, 7
- 2001-08-24 0001095811-01-504581 — 5, 7
- 2001-07-30 0001095811-01-503468 — 5, 7
- 2001-07-12 0000891618-01-501567 — 5, 7
- 2001-05-11 0000891618-01-500638 — 5, 7
- 2001-02-27 0000891618-01-500076 — 5, 7
- 2001-02-20 0001095811-01-001530 — 5, 7
- 2001-02-08 0001095811-01-000848 — 5, 7
- 2001-02-07 0001095811-01-000768 — 5
- 2000-12-27 0001095811-00-005511 — 5
- 2000-12-21 0001095811-00-005427 — 5
- 2000-12-19 0001095811-00-005368 — 5
- 2000-11-15 0001095811-00-004830 — 5
- 2000-11-15 0001095811-00-004824 — 5
- 2000-11-13 0000891618-00-005023 — 5
- 2000-11-07 0001095811-00-004387 — 5, 7
- 2000-11-06 0001095811-00-004318 — 5
- 2000-09-29 0000891618-00-004739 — 5, 7
- 2000-09-28 0000891618-00-004722 — 5
- 2000-09-26 0001095811-00-003573 — 5
- 2000-09-15 0001095811-00-003413 — 5
- 2000-09-07 0001095811-00-003229 — 5
- 2000-08-15 0000891618-00-004430 — 5
- 2000-08-04 0001095811-00-002304 — 5, 7 — amendment, the index does not say of what
- 2000-07-28 0000891618-00-004132 — 5, 7
- 2000-06-29 0000891618-00-003637 — 5
- 2000-06-07 0000891618-00-003209 — 5
- 2000-05-26 0000891618-00-003054 — 5
- 2000-05-18 0000891618-00-002975 — 5, 7
- 2000-05-15 0000891618-00-002808 — 5, 7
- 2000-05-03 0000891618-00-002473 — 5
- 2000-04-03 0000891618-00-001936 — 5
- 2000-03-28 0000891618-00-001763 — 5
- 2000-03-27 0000891618-00-001722 — 5, 7
- 2000-03-16 0000891618-00-001512 — 5
- 2000-02-17 0000891618-00-001024 — 5, 7
- 2000-02-03 0000891618-00-000468 — 7 — amendment of 0000891618-99-005685
- 1999-12-22 0000891618-99-005792 — 5, 7
- 1999-12-15 0000891618-99-005685 — 5, 7
- 1999-11-17 0000891618-99-005313 — 5, 7
- 1999-11-04 0000891618-99-004862 — 5, 7
- 1999-10-20 0000891618-99-004625 — 5, 7
- 1999-09-27 0000891618-99-004333 — 5, 7
- 1999-08-26 0000891618-99-003978 — 5, 7
- 1999-08-13 0000891618-99-003764 — 5, 7 — amendment of 0000891618-99-003749
- 1999-08-13 0000891618-99-003749 — 5, 7
- 1999-07-02 0000891618-99-002980 — 5, 7
- 1999-05-14 0000891618-99-002221 — 5
- 1998-11-20 0000891618-98-005074 — 5, 7
- 1998-11-20 0000891618-98-005073 — 5, 7
- 1998-10-13 0000891618-98-004462 — 5, 7
- 1998-07-09 0000891618-98-003245 — 5, 7
- 1998-06-11 0000891618-98-002832 — 5, 7
- 1998-05-15 0000891618-98-002457 — 5, 7
- 1998-04-29 0000891618-98-001996 — 5
- 1998-02-11 0000891618-98-000584 — 5, 7
- 1997-09-09 0000891618-97-003723 — 5, 7
- 1997-08-22 0000891618-97-003559 — 5, 7
- 1997-07-01 0000891618-97-002807 — 5, 7
- 1997-01-22 0000891618-97-000120 — 5, 7
- 1996-10-15 0000891618-96-002283 — 5, 7 — amendment of 0000891618-96-002217
- 1996-10-01 0000891618-96-002217 — 5, 7
- 1996-07-23 0000891618-96-001305 — 2, 7
- 1996-04-26 0000891618-96-000253 — 2
- 1996-04-02 0000898430-96-001187 — 2, 7
- 1995-12-06 0000891618-95-000728 — 2, 7
- 1995-12-06 0000891618-95-000727 — 2, 7

## late-filing notifications on or before 2017-02-21

- none on or before 2017-02-21

## item 2.02 — earnings release, exhibit 99.1

[0001193125-17-045265:8k_2_02:1]
EX-99.1
2
d268939dex991.htm
EX-99.1

[0001193125-17-045265:8k_2_02:2]
EX-99.1

[0001193125-17-045265:8k_2_02:3]
Exhibit 99.1

[0001193125-17-045265:8k_2_02:4]
| Press Contact: |  |  |  | Investor Relations Contact: |
| Andrea Duffy |  |  |  | Marilyn Mora |
| Cisco |  |  |  | Cisco |
| 1 (646) 295-5241 |  |  |  | 1 (408) 527-7452 |
| anduffy@cisco.com |  |  |  | marilmor@cisco.com |

[0001193125-17-045265:8k_2_02:5]
CISCO REPORTS SECOND QUARTER EARNINGS

[0001193125-17-045265:8k_2_02:6]
Increases Quarterly Cash Dividend 12% to $0.29

[0001193125-17-045265:8k_2_02:7]
|  | • |  | Q2 Revenue: $11.6 billion |

[0001193125-17-045265:8k_2_02:8]
|  | • |  | Decrease of (2)% year over year — Q2 guidance was (2)% to (4)% decline year over year (normalized to exclude the SP Video CPE Business for Q2 FY2016) |

[0001193125-17-045265:8k_2_02:9]
|  | • |  | Q2 Earnings per Share: $0.47 GAAP; $0.57 non-GAAP |

[0001193125-17-045265:8k_2_02:10]
|  | • |  | Q3 FY2017 Outlook: |

[0001193125-17-045265:8k_2_02:11]
|  | • |  | Revenue: (2)% to 0% year over year |

[0001193125-17-045265:8k_2_02:12]
|  | • |  | Earnings per Share: GAAP $0.44 to $0.49; Non-GAAP: $0.57 to $0.59 |

[0001193125-17-045265:8k_2_02:13]
SAN JOSE, Calif. — February 15, 2017 — Cisco today reported second quarter results for the period ended January 28, 2017. Cisco reported
second quarter revenue of $11.6 billion, net income on a generally accepted accounting principles (GAAP) basis of $2.3 billion or $0.47 per share, and non-GAAP net income of $2.9 billion or
$0.57 per share.

[0001193125-17-045265:8k_2_02:14]
“We are pleased with the quarter and the continued customer momentum as we help them drive security, automation and intelligence
across the network and into the cloud,” said Chuck Robbins, Cisco CEO. “This quarter we announced our intent to acquire AppDynamics which, combined with Cisco’s networking analytics, will provide customers with unprecedented insights
into business performance. We will remain focused on accelerating innovation across our portfolio as we continue to deliver value to customers and shareholders.”

[0001193125-17-045265:8k_2_02:15]
GAAP Results

[0001193125-17-045265:8k_2_02:16]
|  |  | Q2 FY2017 |  |  | Q2 FY2016 |  |  | Vs. Q2 FY2016 |  |
| Revenue (excluding SP Video CPE Business for all periods) |  | $ | 11.6 billion |  |  | $ | 11.8 billion |  |  |  | (2 | )% |
| Revenue (including SP Video CPE Business for all periods) |  | $ | 11.6 billion |  |  | $ | 11.9 billion |  |  |  | (3 | )% |
| Net Income |  | $ | 2.3 billion |  |  | $ | 3.1 billion |  |  |  | (25 | )% |
| Diluted Earnings per Share (EPS) |  | $ | 0.47 |  |  | $ | 0.62 |  |  |  | (24 | )% |

[0001193125-17-045265:8k_2_02:17]
Non-GAAP Results

[0001193125-17-045265:8k_2_02:18]
|  |  | Q2 FY2017 |  |  | Q2 FY2016 |  |  | Vs. Q2 FY2016 |  |
| Net Income (excluding SP Video CPE Business for all periods) |  | $ | 2.9 billion |  |  | $ | 2.9 billion |  |  |  | (2 | )% |
| EPS (excluding SP Video CPE Business for all periods) |  | $ | 0.57 |  |  | $ | 0.57 |  |  |  | — | % |

[0001193125-17-045265:8k_2_02:19]
Reconciliations between net income, EPS and other measures on a GAAP and non-GAAP
basis are provided in the tables located in the section entitled “Reconciliations of GAAP to non-GAAP Measures.”

[0001193125-17-045265:8k_2_02:20]
1

[0001193125-17-045265:8k_2_02:21]
Cisco Increases Quarterly Cash Dividend

[0001193125-17-045265:8k_2_02:22]
Cisco has also declared a quarterly dividend of $0.29 per common share, a three-cent increase over the previous quarter’s dividend, to be paid on
April 26, 2017 to all shareholders of record as of the close of business on April 6, 2017. Future dividends will be subject to Board approval.

[0001193125-17-045265:8k_2_02:23]
“We delivered a solid Q2 with $11.6 billion in revenues and further growth in key business areas of collaboration, security and
services,” said Kelly Kramer, Cisco CFO. “I am pleased with our progress on business transformation to software and recurring revenues. We expect to continue to execute well and return value to our shareholders including our
board approved an increase of three-cents to the quarterly dividend to $0.29 per share.”

[0001193125-17-045265:8k_2_02:24]
Financial Summary

[0001193125-17-045265:8k_2_02:25]
All comparative percentages are on a year-over-year basis unless otherwise noted.

[0001193125-17-045265:8k_2_02:26]
All revenue, non-GAAP, and geographic financial information in the “Q2 FY 2017 Highlights” section
is presented excluding the SP Video CPE Business for prior periods as it was divested during the second quarter of fiscal 2016 on November 20, 2015.

[0001193125-17-045265:8k_2_02:27]
Q2 FY 2017 Highlights

[0001193125-17-045265:8k_2_02:28]
Revenue — Total
revenue was $11.6 billion, down 2%, with product revenue down 4% and service revenue up 5%. Revenue by geographic segment was: Americas down 3%, EMEA flat, and APJC down 3%. Product revenue performance was led by Security which increased 14%.
Collaboration and Wireless product revenue increased by 4% and 3%, respectively. NGN Routing, Switching and Data Center product revenue decreased by 10%, 5% and 4%, respectively. Service Provider Video product revenue decreased by 41%.

[0001193125-17-045265:8k_2_02:29]
Gross Margin — On a GAAP basis, total gross margin and product gross margin were 62.8% and 61.1%, respectively. The decrease in the
product gross margin compared with 61.3% in the second quarter of fiscal 2016 was primarily due to pricing and to a lesser extent product mix, partially offset by continued productivity improvements and the divestiture of the SP Video CPE Business.

[0001193125-17-045265:8k_2_02:30]
Non-GAAP total gross margin and product gross margin were 64.1% and 62.4%, respectively. The decrease in non-GAAP product gross margin compared with 63.3% in the second quarter of fiscal 2016 was primarily due to pricing and to a lesser extent product mix, partially offset by continued productivity improvements.

[0001193125-17-045265:8k_2_02:31]
GAAP service gross margin was 67.7% and non-GAAP service gross margin was 68.8%.

[0001193125-17-045265:8k_2_02:32]
Total gross margins by geographic segment were: 64.4% for the Americas, 65.6% for EMEA and 60.4% for APJC.

[0001193125-17-045265:8k_2_02:33]
Operating Expenses — On a GAAP basis, operating expenses were $4.4 billion, up 6%, primarily due to the gain recorded in the
second quarter of fiscal 2016 from the sale of the SP Video CPE Business. Non-GAAP operating expenses were $3.8 billion, down 2%, and were 33.0% of revenue. Headcount compared with the end of the first
quarter of fiscal 2017 decreased by 426 to 71,959, driven by our fiscal 2017 restructuring actions that began in the first quarter, offset by additional headcount primarily in our investments in key growth areas.

[0001193125-17-045265:8k_2_02:34]
Operating Income — GAAP operating income was $2.9 billion, down 12%, with GAAP operating margin of 25.0%. Non-GAAP operating income was $3.6 billion, down 3%, with non-GAAP operating margin at 31.0%.

[0001193125-17-045265:8k_2_02:35]
Provision for Income Taxes — The GAAP tax provision rate was 20.8%. The non-GAAP tax provision rate
was 22.0%.

[0001193125-17-045265:8k_2_02:36]
Net Income and EPS — On a GAAP basis, net income was $2.3 billion and EPS was $0.47. On a non-GAAP basis, net income was $2.9 billion, a decrease of 2%, and EPS was flat at $0.57.

[0001193125-17-045265:8k_2_02:37]
Cash Flow from
Operating Activities — was $3.8 billion, a decrease of 4% compared with $3.9 billion for the second quarter of fiscal 2016.

[0001193125-17-045265:8k_2_02:38]
Balance Sheet and Other Financial Highlights

[0001193125-17-045265:8k_2_02:39]
Cash
and Cash Equivalents and Investments — were $71.8 billion at the end of the second quarter of fiscal 2017, compared with $71.0 billion at the end of the first quarter of fiscal 2017, and compared with $65.8 billion at the
end of fiscal 2016. The total cash and cash equivalents and investments available in the United States at the end of the second quarter of fiscal 2017 were $9.6 billion.

[0001193125-17-045265:8k_2_02:40]
Deferred Revenue — was $17.1 billion, up 13% in total, with deferred product revenue up
19%, driven largely by subscription-based and software offerings. Deferred service revenue was up 9%. The portion of product deferred revenue related to recurring software and subscription businesses grew 51%.

[0001193125-17-045265:8k_2_02:41]
Capital Allocation — In the second quarter of fiscal 2017, Cisco declared and paid a cash dividend of $0.26 per common share, or
$1.3 billion. For the second quarter of fiscal 2017, Cisco repurchased approximately 33 million shares of common stock under its stock repurchase program at an average price of $30.33 per share for an aggregate purchase price of
$1.0 billion.

[0001193125-17-045265:8k_2_02:42]
As of January 28, 2017, Cisco had repurchased and retired 4.7 billion shares of Cisco common stock at an average price of
$21.17 per share for an aggregate purchase price of approximately $98.6 billion since the inception of the stock repurchase program. The remaining authorized amount for stock repurchases under this program is approximately $13.4 billion
with no termination date.

[0001193125-17-045265:8k_2_02:43]
Announced Acquisition of AppDynamics — On January 24, 2017, Cisco announced its intent to acquire
AppDynamics, Inc., a privately held application intelligence software company. The acquisition is expected to close in the third quarter of fiscal 2017.

[0001193125-17-045265:8k_2_02:44]
Business Outlook for Q3 FY 2017

[0001193125-17-045265:8k_2_02:45]
Cisco expects to achieve
the following results for the third quarter of fiscal 2017:

[0001193125-17-045265:8k_2_02:46]
| Q3 FY 2017 |  |  |
| Revenue |  | (2)% to 0% Y/Y |
| Non-GAAP gross margin rate |  | 63% -64% |
| Non-GAAP operating margin rate |  | 29% -30% |
| Non-GAAP tax provision rate |  | 22% |
| Non-GAAP EPS |  | $0.57 - $0.59 |

[0001193125-17-045265:8k_2_02:47]
The third quarter of fiscal 2016 included an extra week which resulted in higher revenue of $265 million and higher non-GAAP cost of sales and operating expenses of $150 million resulting in $115 million of non-GAAP operating income in that quarter.

[0001193125-17-045265:8k_2_02:48]
Cisco estimates that GAAP EPS will be $0.44 to $0.49 which is lower than non-GAAP EPS by $0.10 to $0.13 per share in
the third quarter of fiscal 2017.

[0001193125-17-045265:8k_2_02:49]
A reconciliation between the Business Outlook for Q3 FY 2017 on a GAAP and
non-GAAP basis is provided in the table entitled “GAAP to non-GAAP Business Outlook for Q3 FY 2017” located in the section entitled “Reconciliations of
GAAP to non-GAAP Measures.”

[0001193125-17-045265:8k_2_02:50]
Editor’s Notes:

[0001193125-17-045265:8k_2_02:51]
|  | • |  | Q2 fiscal year 2017 conference call to discuss Cisco’s results along with its business outlook will be held on Wednesday, February 15, 2017 at 1:30 p.m. Pacific Time. Conference call number is 1-888-848-6507 (United States) or 1-212-519-0847 (international). |

[0001193125-17-045265:8k_2_02:52]
|  | • |  | Conference call replay will be available from 4:00 p.m. Pacific Time, February 15, 2017 to 4:00 p.m. Pacific Time, February 22, 2017 at 1-866-357-1423 (United States) or 1-203-369-0115 (international). The replay will also be available via webcast on the Cisco Investor Relations website at http://investor.cisco.com. |

[0001193125-17-045265:8k_2_02:53]
|  | • |  | Additional information regarding Cisco’s financials, as well as a webcast of the conference call with visuals designed to guide participants through the call, will be available at 1:30 p.m. Pacific Time, February 15, 2017. Text of the conference call’s prepared remarks will be available within 24 hours of completion of the call. The webcast will include both the prepared remarks and the question-and-answer session. This information, along with the GAAP to non-GAAP reconciliation information, will be available on the Cisco Investor Relations website at http://investor.cisco.com. |

[0001193125-17-045265:8k_2_02:54]
CISCO SYSTEMS, INC.

[0001193125-17-045265:8k_2_02:55]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-17-045265:8k_2_02:56]
(In millions, except per-share amounts)

[0001193125-17-045265:8k_2_02:57]
(Unaudited)

[0001193125-17-045265:8k_2_02:58]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | January 28,2017 |  |  | January 23,2016 |  |  | January 28,2017 |  |  | January 23,2016 |  |
| REVENUE: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 8,491 |  |  | $ | 8,983 |  |  | $ | 17,793 |  |  | $ | 18,827 |  |
| Service |  |  | 3,089 |  |  |  | 2,944 |  |  |  | 6,139 |  |  |  | 5,782 |  |
| Total revenue |  |  | 11,580 |  |  |  | 11,927 |  |  |  | 23,932 |  |  |  | 24,609 |  |
| COST OF SALES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 3,305 |  |  |  | 3,480 |  |  |  | 6,708 |  |  |  | 7,333 |  |
| Service |  |  | 999 |  |  |  | 1,015 |  |  |  | 2,064 |  |  |  | 2,012 |  |
| Total cost of sales |  |  | 4,304 |  |  |  | 4,495 |  |  |  | 8,772 |  |  |  | 9,345 |  |
| GROSS MARGIN |  |  | 7,276 |  |  |  | 7,432 |  |  |  | 15,160 |  |  |  | 15,264 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 1,508 |  |  |  | 1,509 |  |  |  | 3,053 |  |  |  | 3,069 |  |
| Sales and marketing |  |  | 2,222 |  |  |  | 2,286 |  |  |  | 4,640 |  |  |  | 4,729 |  |
| General and administrative |  |  | 456 |  |  |  | 176 |  |  |  | 1,011 |  |  |  | 715 |  |
| Amortization of purchased intangible assets |  |  | 64 |  |  |  | 71 |  |  |  | 142 |  |  |  | 140 |  |
| Restructuring and other charges |  |  | 133 |  |  |  | 96 |  |  |  | 544 |  |  |  | 238 |  |
| Total operating expenses |  |  | 4,383 |  |  |  | 4,138 |  |  |  | 9,390 |  |  |  | 8,891 |  |
| OPERATING INCOME |  |  | 2,893 |  |  |  | 3,294 |  |  |  | 5,770 |  |  |  | 6,373 |  |
| Interest income |  |  | 329 |  |  |  | 237 |  |  |  | 624 |  |  |  | 462 |  |
| Interest expense |  |  | (222 | ) |  |  | (162 | ) |  |  | (420 | ) |  |  | (321 | ) |
| Other income (loss), net |  |  | (37 | ) |  |  | (63 | ) |  |  | (58 | ) |  |  | (71 | ) |
| Interest and other income (loss), net |  |  | 70 |  |  |  | 12 |  |  |  | 146 |  |  |  | 70 |  |
| INCOME BEFORE PROVISION FOR INCOME TAXES |  |  | 2,963 |  |  |  | 3,306 |  |  |  | 5,916 |  |  |  | 6,443 |  |
| Provision for income taxes |  |  | 615 |  |  |  | 159 |  |  |  | 1,246 |  |  |  | 866 |  |
| NET INCOME |  | $ | 2,348 |  |  | $ | 3,147 |  |  | $ | 4,670 |  |  | $ | 5,577 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.47 |  |  | $ | 0.62 |  |  | $ | 0.93 |  |  | $ | 1.10 |  |
| Diluted |  | $ | 0.47 |  |  | $ | 0.62 |  |  | $ | 0.92 |  |  | $ | 1.09 |  |
| Shares used in per-share calculation: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 5,015 |  |  |  | 5,070 |  |  |  | 5,021 |  |  |  | 5,075 |  |
| Diluted |  |  | 5,040 |  |  |  | 5,097 |  |  |  | 5,054 |  |  |  | 5,106 |  |
| Cash dividends declared per common share |  | $ | 0.26 |  |  | $ | 0.21 |  |  | $ | 0.52 |  |  | $ | 0.42 |  |

[0001193125-17-045265:8k_2_02:59]
The Consolidated Statements of Operations include the results of the SP Video CPE Business prior to its divestiture during the
second quarter of fiscal 2016 on November 20, 2015. Accordingly, the three months ended January 23, 2016 includes only one month of financial results for this business.

[0001193125-17-045265:8k_2_02:60]
4

[0001193125-17-045265:8k_2_02:61]
CISCO SYSTEMS, INC.

[0001193125-17-045265:8k_2_02:62]
REVENUE BY SEGMENT

[0001193125-17-045265:8k_2_02:63]
(In
millions, except percentages)

[0001193125-17-045265:8k_2_02:64]
|  |  | January 28, 2017 |  |
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  |  |  |  | Excluding SPVideo CPEBusiness |  |  | Including SPVideo CPEBusiness |  |  |  |  |  | Excluding SPVideo CPEBusiness |  |  | Including SPVideo CPEBusiness |  |
|  |  | Amount |  |  | Y/Y % |  |  | Y/Y % |  |  | Amount |  |  | Y/Y % |  |  | Y/Y % |  |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 6,660 |  |  |  | (3)% |  |  |  | (4)% |  |  | $ | 14,103 |  |  |  | (2)% |  |  |  | (4)% |  |
| EMEA |  |  | 3,065 |  |  |  | — % |  |  |  | (1)% |  |  |  | 6,078 |  |  |  | — % |  |  |  | (2)% |  |
| APJC |  |  | 1,855 |  |  |  | (3)% |  |  |  | (4)% |  |  |  | 3,751 |  |  |  | 1% |  |  |  | 1% |  |
| Total |  | $ | 11,580 |  |  |  | (2)% |  |  |  | (3)% |  |  | $ | 23,932 |  |  |  | (1)% |  |  |  | (3)% |  |

[0001193125-17-045265:8k_2_02:65]
During the second quarter of fiscal 2016 on November 20, 2015, Cisco completed its divestiture of the SP Video CPE
Business. SP Video CPE Business revenue for the three and six months ended January 23, 2016 was $93 million and $504 million, respectively.

[0001193125-17-045265:8k_2_02:66]
CISCO SYSTEMS, INC.

[0001193125-17-045265:8k_2_02:67]
GROSS MARGIN PERCENTAGE BY SEGMENT

[0001193125-17-045265:8k_2_02:68]
(In percentages)

[0001193125-17-045265:8k_2_02:69]
|  |  | January 28, 2017 |  |
|  |  | Three Months Ended |  |  | Six Months Ended |  |
| Gross Margin Percentage: |  |  |  |  |  |  |  |  |
| Americas |  |  | 64.4% |  |  |  | 64.7% |  |
| EMEA |  |  | 65.6% |  |  |  | 66.2% |  |
| APJC |  |  | 60.4% |  |  |  | 62.0% |  |

[0001193125-17-045265:8k_2_02:70]
5

[0001193125-17-045265:8k_2_02:71]
CISCO SYSTEMS, INC.

[0001193125-17-045265:8k_2_02:72]
REVENUE FOR GROUPS OF SIMILAR PRODUCTS AND SERVICES

[0001193125-17-045265:8k_2_02:73]
(In millions, except percentages)

[0001193125-17-045265:8k_2_02:74]
|  |  | January 28, 2017 |  |
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | Amount |  |  | Y/Y % |  |  | Amount |  |  | Y/Y % |  |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Switching |  | $ | 3,305 |  |  |  | (5)% |  |  | $ | 7,021 |  |  |  | (6)% |  |
| NGN Routing |  |  | 1,817 |  |  |  | (10)% |  |  |  | 3,906 |  |  |  | (2)% |  |
| Collaboration |  |  | 1,062 |  |  |  | 4% |  |  |  | 2,143 |  |  |  | — % |  |
| Data Center |  |  | 790 |  |  |  | (4)% |  |  |  | 1,624 |  |  |  | (3)% |  |
| Wireless |  |  | 632 |  |  |  | 3% |  |  |  | 1,264 |  |  |  | — % |  |
| Security |  |  | 528 |  |  |  | 14% |  |  |  | 1,068 |  |  |  | 13% |  |
| Service Provider Video(1) |  |  | 241 |  |  |  | (41)% |  |  |  | 512 |  |  |  | (25)% |  |
| Other |  |  | 116 |  |  |  | 53% |  |  |  | 255 |  |  |  | 70% |  |
| Product - excluding SP Video CPE Business (1) |  |  | 8,491 |  |  |  | (4)% |  |  |  | 17,793 |  |  |  | (3)% |  |
| Service |  |  | 3,089 |  |  |  | 5% |  |  |  | 6,139 |  |  |  | 6% |  |
| Total - excluding SP Video CPE Business (1) |  | $ | 11,580 |  |  |  | (2)% |  |  | $ | 23,932 |  |  |  | (1)% |  |

[0001193125-17-045265:8k_2_02:75]
(1) Excludes SP Video CPE Business revenue for all periods presented as
it was divested during the second quarter of fiscal 2016 on November 20, 2015. SP Video CPE Business revenue for the three and six months ended January 23, 2016 was $93 million and $504 million, respectively.

[0001193125-17-045265:8k_2_02:76]
6

[0001193125-17-045265:8k_2_02:77]
CISCO SYSTEMS, INC.

[0001193125-17-045265:8k_2_02:78]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001193125-17-045265:8k_2_02:79]
(In millions)

[0001193125-17-045265:8k_2_02:80]
(Unaudited)

[0001193125-17-045265:8k_2_02:81]
|  |  | January 28,2017 |  |  | July 30,2016 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 10,898 |  |  | $ | 7,631 |  |
| Investments |  |  | 60,947 |  |  |  | 58,125 |  |
| Accounts receivable, net of allowance for doubtful accounts of $225 at January 28, 2017 and $249 at July 30, 2016 |  |  | 4,458 |  |  |  | 5,847 |  |
| Inventories |  |  | 1,264 |  |  |  | 1,217 |  |
| Financing receivables, net |  |  | 4,496 |  |  |  | 4,272 |  |
| Other current assets |  |  | 1,329 |  |  |  | 1,627 |  |
| Total current assets |  |  | 83,392 |  |  |  | 78,719 |  |
| Property and equipment, net |  |  | 3,422 |  |  |  | 3,506 |  |
| Financing receivables, net |  |  | 4,664 |  |  |  | 4,158 |  |
| Goodwill |  |  | 26,822 |  |  |  | 26,625 |  |
| Purchased intangible assets, net |  |  | 2,117 |  |  |  | 2,501 |  |
| Deferred tax assets |  |  | 4,293 |  |  |  | 4,299 |  |
| Other assets |  |  | 1,538 |  |  |  | 1,844 |  |
| TOTAL ASSETS |  | $ | 126,248 |  |  | $ | 121,652 |  |
| LIABILITIES AND EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 4,451 |  |  | $ | 4,160 |  |
| Accounts payable |  |  | 957 |  |  |  | 1,056 |  |
| Income taxes payable |  |  | 57 |  |  |  | 517 |  |
| Accrued compensation |  |  | 2,522 |  |  |  | 2,951 |  |
| Deferred revenue |  |  | 10,243 |  |  |  | 10,155 |  |
| Other current liabilities |  |  | 4,478 |  |  |  | 6,072 |  |
| Total current liabilities |  |  | 22,708 |  |  |  | 24,911 |  |
| Long-term debt |  |  | 30,471 |  |  |  | 24,483 |  |
| Income taxes payable |  |  | 1,025 |  |  |  | 925 |  |
| Deferred revenue |  |  | 6,843 |  |  |  | 6,317 |  |
| Other long-term liabilities |  |  | 1,383 |  |  |  | 1,431 |  |
| Total liabilities |  |  | 62,430 |  |  |  | 58,067 |  |
| Total equity |  |  | 63,818 |  |  |  | 63,585 |  |
| TOTAL LIABILITIES AND EQUITY |  | $ | 126,248 |  |  | $ | 121,652 |  |

[0001193125-17-045265:8k_2_02:82]
CISCO SYSTEMS, INC.

[0001193125-17-045265:8k_2_02:83]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-17-045265:8k_2_02:84]
(In millions)

[0001193125-17-045265:8k_2_02:85]
(Unaudited)

[0001193125-17-045265:8k_2_02:86]
|  |  | Six Months Ended |  |
|  |  | January 28,2017 |  |  | January 23,2016 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 4,670 |  |  | $ | 5,577 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation, amortization, and other |  |  | 1,148 |  |  |  | 1,005 |  |
| Share-based compensation expense |  |  | 724 |  |  |  | 706 |  |
| Provision for receivables |  |  | 4 |  |  |  | 31 |  |
| Deferred income taxes |  |  | (26 | ) |  |  | 274 |  |
| Excess tax benefits from share-based compensation |  |  | (101 | ) |  |  | (82 | ) |
| (Gains) losses on divestitures, investments and other, net |  |  | 79 |  |  |  | (260 | ) |
| Change in operating assets and liabilities, net of effects of acquisitions and divestitures: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 1,396 |  |  |  | 988 |  |
| Inventories |  |  | (51 | ) |  |  | 153 |  |
| Financing receivables |  |  | (764 | ) |  |  | (171 | ) |
| Other assets |  |  | 155 |  |  |  | (181 | ) |
| Accounts payable |  |  | (98 | ) |  |  | (147 | ) |
| Income taxes, net |  |  | (257 | ) |  |  | (764 | ) |
| Accrued compensation |  |  | (417 | ) |  |  | (348 | ) |
| Deferred revenue |  |  | 611 |  |  |  | 69 |  |
| Other liabilities |  |  | (571 | ) |  |  | (162 | ) |
| Net cash provided by operating activities |  |  | 6,502 |  |  |  | 6,688 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of investments |  |  | (27,847 | ) |  |  | (19,089 | ) |
| Proceeds from sales of investments |  |  | 18,420 |  |  |  | 10,247 |  |
| Proceeds from maturities of investments |  |  | 5,245 |  |  |  | 7,955 |  |
| Acquisition of businesses, net of cash and cash equivalents acquired |  |  | (251 | ) |  |  | (1,089 | ) |
| Proceeds from business divestiture |  |  | — |  |  |  | 372 |  |
| Purchases of investments in privately held companies |  |  | (142 | ) |  |  | (166 | ) |
| Return of investments in privately held companies |  |  | 108 |  |  |  | 35 |  |
| Acquisition of property and equipment |  |  | (526 | ) |  |  | (576 | ) |
| Proceeds from sales of property and equipment |  |  | 5 |  |  |  | 11 |  |
| Other |  |  | 10 |  |  |  | (87 | ) |
| Net cash used in investing activities |  |  | (4,978 | ) |  |  | (2,387 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Issuances of common stock |  |  | 386 |  |  |  | 701 |  |
| Repurchases of common stock—repurchase program |  |  | (1,991 | ) |  |  | (2,344 | ) |
| Shares repurchased for tax withholdings on vesting of restricted stock units |  |  | (432 | ) |  |  | (412 | ) |
| Short-term borrowings, original maturities less than 90 days, net |  |  | 300 |  |  |  | (4 | ) |
| Issuances of debt |  |  | 6,232 |  |  |  | — |  |
| Repayments of debt |  |  | (1 | ) |  |  | (862 | ) |
| Excess tax benefits from share-based compensation |  |  | 101 |  |  |  | 82 |  |
| Dividends paid |  |  | (2,612 | ) |  |  | (2,133 | ) |
| Other |  |  | (240 | ) |  |  | 108 |  |
| Net cash provided by (used in) financing activities |  |  | 1,743 |  |  |  | (4,864 | ) |
| Net increase (decrease) in cash and cash equivalents |  |  | 3,267 |  |  |  | (563 | ) |
| Cash and cash equivalents, beginning of period |  |  | 7,631 |  |  |  | 6,877 |  |
| Cash and cash equivalents, end of period |  | $ | 10,898 |  |  | $ | 6,314 |  |
| Supplemental cash flow information: |  |  |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 419 |  |  | $ | 426 |  |
| Cash paid for income taxes, net |  | $ | 1,529 |  |  | $ | 1,355 |  |

[0001193125-17-045265:8k_2_02:87]
8

[0001193125-17-045265:8k_2_02:88]
CISCO SYSTEMS, INC.

[0001193125-17-045265:8k_2_02:89]
DEFERRED REVENUE

[0001193125-17-045265:8k_2_02:90]
(In
millions)

[0001193125-17-045265:8k_2_02:91]
|  |  | January 28,2017 |  |  | October 29,2016 |  |  | January 23,2016 |  |
| Deferred revenue: |  |  |  |  |  |  |  |  |  |  |  |  |
| Service |  | $ | 10,525 |  |  | $ | 10,424 |  |  | $ | 9,657 |  |
| Product: |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred revenue related to recurring software and subscription businesses |  |  | 3,997 |  |  |  | 3,801 |  |  |  | 2,654 |  |
| Deferred revenue related to two-tier distributors |  |  | 401 |  |  |  | 439 |  |  |  | 554 |  |
| Other product deferred revenue |  |  | 2,163 |  |  |  | 2,287 |  |  |  | 2,320 |  |
| Total product deferred revenue |  |  | 6,561 |  |  |  | 6,527 |  |  |  | 5,528 |  |
| Total |  | $ | 17,086 |  |  | $ | 16,951 |  |  | $ | 15,185 |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |  |
| Current |  | $ | 10,243 |  |  | $ | 10,215 |  |  | $ | 9,796 |  |
| Noncurrent |  |  | 6,843 |  |  |  | 6,736 |  |  |  | 5,389 |  |
| Total |  | $ | 17,086 |  |  | $ | 16,951 |  |  | $ | 15,185 |  |

[0001193125-17-045265:8k_2_02:92]
CISCO SYSTEMS, INC.

[0001193125-17-045265:8k_2_02:93]
DIVIDENDS PAID AND REPURCHASES OF COMMON STOCK

[0001193125-17-045265:8k_2_02:94]
(In millions, except per-share amounts)

[0001193125-17-045265:8k_2_02:95]
|  |  | DIVIDENDS |  |  | STOCK REPURCHASE PROGRAM |  |  | TOTAL |  |
| Quarter Ended |  | Per Share |  |  | Amount |  |  | Shares |  |  | Weighted-Average Priceper Share |  |  | Amount |  |  | Amount |  |
| Fiscal 2017 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| January 28, 2017 |  | $ | 0.26 |  |  | $ | 1,304 |  |  |  | 33 |  |  | $ | 30.33 |  |  | $ | 1,001 |  |  | $ | 2,305 |  |
| October 29, 2016 |  |  | 0.26 |  |  |  | 1,308 |  |  |  | 32 |  |  |  | 31.12 |  |  |  | 1,001 |  |  |  | 2,309 |  |
| Total |  | $ | 0.52 |  |  | $ | 2,612 |  |  |  | 65 |  |  | $ | 30.72 |  |  | $ | 2,002 |  |  | $ | 4,614 |  |
| Fiscal 2016 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| July 30, 2016 |  | $ | 0.26 |  |  | $ | 1,309 |  |  |  | 28 |  |  | $ | 28.70 |  |  | $ | 800 |  |  | $ | 2,109 |  |
| April 30, 2016 |  |  | 0.26 |  |  |  | 1,308 |  |  |  | 27 |  |  |  | 24.08 |  |  |  | 649 |  |  |  | 1,957 |  |
| January 23, 2016 |  |  | 0.21 |  |  |  | 1,065 |  |  |  | 48 |  |  |  | 26.12 |  |  |  | 1,262 |  |  |  | 2,327 |  |
| October 24, 2015 |  |  | 0.21 |  |  |  | 1,068 |  |  |  | 45 |  |  |  | 26.83 |  |  |  | 1,207 |  |  |  | 2,275 |  |
| Total |  | $ | 0.94 |  |  | $ | 4,750 |  |  |  | 148 |  |  | $ | 26.45 |  |  | $ | 3,918 |  |  | $ | 8,668 |  |

[0001193125-17-045265:8k_2_02:96]
CISCO SYSTEMS, INC.

[0001193125-17-045265:8k_2_02:97]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-17-045265:8k_2_02:98]
GAAP TO NON-GAAP NET INCOME

[0001193125-17-045265:8k_2_02:99]
(In millions, except per-share amounts)

[0001193125-17-045265:8k_2_02:100]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | January 28,2017 |  |  | January 23,2016 |  |  | January 28,2017 |  |  | January 23,2016 |  |
| GAAP net income |  | $ | 2,348 |  |  | $ | 3,147 |  |  | $ | 4,670 |  |  | $ | 5,577 |  |
| Adjustments to cost of sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 53 |  |  |  | 51 |  |  |  | 107 |  |  |  | 102 |  |
| Amortization of acquisition-related intangible assets |  |  | 107 |  |  |  | 123 |  |  |  | 219 |  |  |  | 251 |  |
| Supplier component remediation charge (adjustment), net (1) |  |  | (16 | ) |  |  | — |  |  |  | (16 | ) |  |  | — |  |
| Acquisition-related/divestiture costs |  |  | 1 |  |  |  | 1 |  |  |  | 1 |  |  |  | 1 |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | (1 | ) |  |  | — |  |  |  | (2 | ) |
| Total adjustments to GAAP cost of sales |  |  | 145 |  |  |  | 174 |  |  |  | 311 |  |  |  | 352 |  |
| Adjustments to operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 299 |  |  |  | 280 |  |  |  | 614 |  |  |  | 590 |  |
| Amortization of acquisition-related intangible assets |  |  | 64 |  |  |  | 71 |  |  |  | 142 |  |  |  | 140 |  |
| Acquisition-related/divestiture costs (2) |  |  | 61 |  |  |  | (222 | ) |  |  | 114 |  |  |  | (131 | ) |
| Significant asset impairments and restructurings |  |  | 133 |  |  |  | 96 |  |  |  | 544 |  |  |  | 238 |  |
| Total adjustments to GAAP operating expenses |  |  | 557 |  |  |  | 225 |  |  |  | 1,414 |  |  |  | 837 |  |
| Total adjustments to GAAP income before provision for income taxes |  |  | 702 |  |  |  | 399 |  |  |  | 1,725 |  |  |  | 1,189 |  |
| Income tax effect of non-GAAP adjustments |  |  | (191 | ) |  |  | (98 | ) |  |  | (435 | ) |  |  | (294 | ) |
| Significant tax matters (3) |  |  | — |  |  |  | (519 | ) |  |  | — |  |  |  | (519 | ) |
| Total adjustments to GAAP provision for income taxes |  |  | (191 | ) |  |  | (617 | ) |  |  | (435 | ) |  |  | (813 | ) |
| Non-GAAP net income |  | $ | 2,859 |  |  | $ | 2,929 |  |  | $ | 5,960 |  |  | $ | 5,953 |  |
| Diluted net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | $ | 0.47 |  |  | $ | 0.62 |  |  | $ | 0.92 |  |  | $ | 1.09 |  |
| Non-GAAP |  | $ | 0.57 |  |  | $ | 0.57 |  |  | $ | 1.18 |  |  | $ | 1.17 |  |

[0001193125-17-045265:8k_2_02:101]
(1) GAAP net income for the second quarter of fiscal 2017 included two
supplier component related items as follows: 1) a pre-tax charge to product cost of sales of $125 million related to the expected remediation costs for anticipated failures in future periods of a
widely-used clock-signal component sourced from a third party which is included in several of the Company’s products, and 2) a pre-tax adjustment (reduction to product cost of sales) of $141 million
to a liability originally recorded in the second quarter of fiscal 2014, related to lower than expected defects and future costs of remediation of issues with products sold in prior fiscal years containing memory components manufactured by a single
supplier.

[0001193125-17-045265:8k_2_02:102]
(2) The sale of the SP Video CPE Business resulted in a
pre-tax gain of $286 million during the second quarter of fiscal 2016. The gain on this transaction was excluded from non-GAAP net income for the second quarter and
first six months of fiscal 2016.

[0001193125-17-045265:8k_2_02:103]
(3) During the second quarter of fiscal 2016, Cisco recorded certain
net tax benefits totaling $519 million related to prior-year periods that were excluded from non-GAAP net income for the second quarter and first six months of fiscal 2016. These net tax benefits are
primarily comprised of settlement of all outstanding items related to Cisco’s U.S. federal income tax returns for the fiscal years ended July 26, 2008 through July 31, 2010 of $367 million, the retroactive reinstatement of the
U.S. federal R&D tax credit of $84 million related to fiscal 2015, and a net tax benefit of $68 million related to other significant tax matters.

[0001193125-17-045265:8k_2_02:104]
10

[0001193125-17-045265:8k_2_02:105]
CISCO SYSTEMS, INC.

[0001193125-17-045265:8k_2_02:106]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-17-045265:8k_2_02:107]
GROSS MARGINS, OPERATING EXPENSES, OPERATING MARGINS, AND NET INCOME

[0001193125-17-045265:8k_2_02:108]
(In millions, except percentages)

[0001193125-17-045265:8k_2_02:109]
|  |  | Three Months EndedJanuary 28, 2017 |  |
|  |  |  | ProductGross Margin |  |  |  | ServiceGross Margin |  |  |  | TotalGross Margin |  |  |  | Operating Expenses |  |  |  | Y/Y |  |  |  | Operating Income |  |  |  | Y/Y |  |  |  | Net Income |  |  |  | Y/Y |  |
| GAAP amount |  | $ | 5,186 |  |  | $ | 2,090 |  |  | $ | 7,276 |  |  | $ | 4,383 |  |  |  | 6% |  |  | $ | 2,893 |  |  |  | (12)% |  |  | $ | 2,348 |  |  |  | (25)% |  |
| % of revenue |  |  | 61.1% |  |  |  | 67.7% |  |  |  | 62.8% |  |  |  | 37.8% |  |  |  |  |  |  |  | 25.0% |  |  |  |  |  |  |  | 20.3% |  |  |  |  |  |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 19 |  |  |  | 34 |  |  |  | 53 |  |  |  | 299 |  |  |  |  |  |  |  | 352 |  |  |  |  |  |  |  | 352 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  |  | 107 |  |  |  | — |  |  |  | 107 |  |  |  | 64 |  |  |  |  |  |  |  | 171 |  |  |  |  |  |  |  | 171 |  |  |  |  |  |
| Supplier component remediation charge (adjustment), net |  |  | (16) |  |  |  | — |  |  |  | (16) |  |  |  | — |  |  |  |  |  |  |  | (16) |  |  |  |  |  |  |  | (16) |  |  |  |  |  |
| Acquisition-related/divestiture costs |  |  | — |  |  |  | 1 |  |  |  | 1 |  |  |  | 61 |  |  |  |  |  |  |  | 62 |  |  |  |  |  |  |  | 62 |  |  |  |  |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 133 |  |  |  |  |  |  |  | 133 |  |  |  |  |  |  |  | 133 |  |  |  |  |  |
| Income tax effect |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | (191) |  |  |  |  |  |
| Non-GAAP amount |  | $ | 5,296 |  |  | $ | 2,125 |  |  | $ | 7,421 |  |  | $ | 3,826 |  |  |  | (2)% |  |  | $ | 3,595 |  |  |  | (3)% |  |  | $ | 2,859 |  |  |  | (2)% |  |
| % of revenue |  |  | 62.4% |  |  |  | 68.8% |  |  |  | 64.1% |  |  |  | 33.0% |  |  |  |  |  |  |  | 31.0% |  |  |  |  |  |  |  | 24.7% |  |  |  |  |  |

[0001193125-17-045265:8k_2_02:110]
During the second quarter of fiscal 2016 on November 20, 2015, Cisco completed its divestiture of the SP Video CPE
Business. Accordingly, the non-GAAP growth rates above are normalized to exclude the SP Video CPE Business for the second quarter of fiscal 2016 as detailed in the table below.

[0001193125-17-045265:8k_2_02:111]
|  |  | Three Months EndedJanuary 23, 2016 |  |
|  |  | ProductGross Margin |  |  | ServiceGross Margin |  |  | Total Gross Margin |  |  | Operating Expenses |  |  | Y/Y |  |  | Operating Income |  |  | Y/Y |  |  | Net Income |  |  | Y/Y |  |
| GAAP amount |  | $ | 5,503 |  |  | $ | 1,929 |  |  | $ | 7,432 |  |  | $ | 4,138 |  |  |  | (7)% |  |  | $ | 3,294 |  |  |  | 26% |  |  | $ | 3,147 |  |  |  | 31% |  |
| % of revenue |  |  | 61.3% |  |  |  | 65.5% |  |  |  | 62.3% |  |  |  | 34.7% |  |  |  |  |  |  |  | 27.6% |  |  |  |  |  |  |  | 26.4% |  |  |  |  |  |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 16 |  |  |  | 35 |  |  |  | 51 |  |  |  | 280 |  |  |  |  |  |  |  | 331 |  |  |  |  |  |  |  | 331 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  |  | 123 |  |  |  | — |  |  |  | 123 |  |  |  | 71 |  |  |  |  |  |  |  | 194 |  |  |  |  |  |  |  | 194 |  |  |  |  |  |
| Acquisition-related/divestiture costs |  |  | — |  |  |  | 1 |  |  |  | 1 |  |  |  | (222) |  |  |  |  |  |  |  | (221) |  |  |  |  |  |  |  | (221) |  |  |  |  |  |
| Significant asset impairments and restructurings |  |  | (1) |  |  |  | — |  |  |  | (1) |  |  |  | 96 |  |  |  |  |  |  |  | 95 |  |  |  |  |  |  |  | 95 |  |  |  |  |  |
| Income tax/significant tax matters |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | (617) |  |  |  |  |  |
| Non-GAAP amount |  | $ | 5,641 |  |  | $ | 1,965 |  |  | $ | 7,606 |  |  | $ | 3,913 |  |  |  | (2)% |  |  | $ | 3,693 |  |  |  | 9% |  |  | $ | 2,929 |  |  |  | 7% |  |
| % of revenue |  |  | 62.8% |  |  |  | 66.7% |  |  |  | 63.8% |  |  |  | 32.8% |  |  |  |  |  |  |  | 31.0% |  |  |  |  |  |  |  | 24.6% |  |  |  |  |  |
| Less: SP Video CPE Business* |  |  | (13) |  |  |  | — |  |  |  | (13) |  |  |  | (11) |  |  |  |  |  |  |  | (2) |  |  |  |  |  |  |  | (2) |  |  |  |  |  |
| Non-GAAP amount (excluding SP Video CPE Business) |  | $ | 5,628 |  |  | $ | 1,965 |  |  | $ | 7,593 |  |  | $ | 3,902 |  |  |  | (1)% |  |  | $ | 3,691 |  |  |  | 10% |  |  | $ | 2,927 |  |  |  | 8% |  |
| % of revenue |  |  | 63.3% |  |  |  | 66.7% |  |  |  | 64.2% |  |  |  | 33.0% |  |  |  |  |  |  |  | 31.2% |  |  |  |  |  |  |  | 24.7% |  |  |  |  |  |

[0001193125-17-045265:8k_2_02:112]
* Reflects one month of operations for the SP Video CPE Business, which was divested during the second quarter of fiscal 2016
on November 20, 2015.

[0001193125-17-045265:8k_2_02:113]
11

[0001193125-17-045265:8k_2_02:114]
CISCO SYSTEMS, INC.

[0001193125-17-045265:8k_2_02:115]
RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-17-045265:8k_2_02:116]
EFFECTIVE TAX RATE

[0001193125-17-045265:8k_2_02:117]
(In
percentages)

[0001193125-17-045265:8k_2_02:118]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | January 28,2017 |  |  | January 23,2016 |  |  | January 28,2017 |  |  | January 23,2016 |  |
| GAAP effective tax rate |  |  | 20.8 | % |  |  | 4.8 | % |  |  | 21.1 | % |  |  | 13.4 | % |
| Total adjustments to GAAP provision for income taxes |  |  | 1.2 | % |  |  | 16.1 | % |  |  | 0.9 | % |  |  | 8.6 | % |
| Non-GAAP effective tax rate |  |  | 22.0 | % |  |  | 20.9 | % |  |  | 22.0 | % |  |  | 22.0 | % |

[0001193125-17-045265:8k_2_02:119]
FREE CASH FLOW

[0001193125-17-045265:8k_2_02:120]
(In millions)

[0001193125-17-045265:8k_2_02:121]
|  |  | Three Months Ended |  |
|  |  | January 28, 2017 |  |  | October 24, 2016 |  |  | January 23, 2016 |  |
| Net cash provided by operating activities |  | $ | 3,772 |  |  | $ | 2,730 |  |  | $ | 3,922 |  |
| Acquisition of property and equipment |  |  | (251 | ) |  |  | (275 | ) |  |  | (314 | ) |
| Free cash flow |  | $ | 3,521 |  |  | $ | 2,455 |  |  | $ | 3,608 |  |

[0001193125-17-045265:8k_2_02:122]
GAAP TO NON-GAAP BUSINESS OUTLOOK FOR Q3 FY 2017

[0001193125-17-045265:8k_2_02:123]
| Q3 FY 2017 |  | Gross MarginRate |  | Operating MarginRate |  | Tax ProvisionRate |  | Earnings perShare (2) |
| GAAP |  | 61.5% - 62.5% |  | 23% - 24% |  | 21% |  | $0.44 to $0.49 |
| Estimated adjustments for: |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  | 0.5% |  | 3% |  | — |  | $0.05 - $0.06 |
| Amortization of purchased intangible assets and other acquisition-related/divestiture costs |  | 1.0% |  | 2% |  | — |  | $0.03 - $0.04 |
| Restructuring and other charges (1) |  | — |  | 1% |  | — |  | $0.02 - $0.03 |
| Income tax effect of non-GAAP adjustments |  | — |  | — |  | 1% |  |  |
| Non-GAAP |  | 63% - 64% |  | 29% - 30% |  | 22% |  | $0.57 - $0.59 |

[0001193125-17-045265:8k_2_02:124]
(1) During the first six months of fiscal 2017, Cisco recognized pretax
charges of $544 million to the GAAP financial results in relation to the restructuring plan. Cisco currently estimates that it will recognize pretax charges to its GAAP financial results of approximately $700 million consisting of severance and
other one-time termination benefits, and other associated costs. These charges are primarily cash-based. Cisco expects that approximately $100 million to $150 million of these charges will be recognized during
the third quarter of fiscal 2017 with the remaining amount to be recognized during the rest of the fiscal year.

[0001193125-17-045265:8k_2_02:125]
(2) Estimated adjustments to GAAP earnings per share are shown after income tax effects.

[0001193125-17-045265:8k_2_02:126]
Except as noted
above, this business outlook does not include the effects of any future acquisitions/divestitures, asset impairments, restructurings and significant tax matters or other events, which may or may not be significant unless specifically stated.

[0001193125-17-045265:8k_2_02:127]
12

[0001193125-17-045265:8k_2_02:128]
Forward Looking Statements, Non-GAAP Information and Additional
Information

[0001193125-17-045265:8k_2_02:129]
This release includes non-GAAP net income, non-GAAP gross margins, non-GAAP operating expenses, non-GAAP operating income and margin, non-GAAP effective tax rates,
non-GAAP net income per share data, and free cash flow for the periods presented. It also includes future estimated ranges for gross margin, operating margin, tax provision rate and EPS on a non-GAAP basis.

[0001193125-17-045265:8k_2_02:130]
These non-GAAP measures are not in accordance with, or an
alternative for, measures prepared in accordance with generally accepted accounting principles and may be different from non-GAAP measures used by other companies. In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles. Cisco believes that non-GAAP measures have limitations in that they do not reflect
all of the amounts associated with Cisco’s results of operations as determined in accordance with GAAP and that these measures should only be used to evaluate Cisco’s results of operations in conjunction with the corresponding GAAP
measures.

[0001193125-17-045265:8k_2_02:131]
Cisco believes that the presentation of non-GAAP measures when shown in conjunction with the
corresponding GAAP measures, provides useful information to investors and management regarding financial and business trends relating to its financial condition and its historical and projected results of operations. Cisco believes that the
presentation of free cash flow, which it defines as the net cash provided by operating activities less cash used to acquire property and equipment, to be a liquidity measure that provides useful information to management and investors because of its
intent to return a stated

[0001193125-17-045265:8k_2_02:132]
13

[0001193125-17-045265:8k_2_02:133]
percentage of free cash flow to shareholders in the form of dividends and stock repurchases. Cisco further regards free cash flow as a useful measure because it reflects cash that can be used to,
among other things, invest in its business, make strategic acquisitions, repurchase common stock and pay dividends on its common stock, after deducting capital investments.

[0001193125-17-045265:8k_2_02:134]
For its internal budgeting process, Cisco’s management uses financial statements that do not include, when applicable, share-based compensation expense,
amortization of acquisition-related intangible assets, acquisition-related/divestiture costs, significant asset impairments and restructurings, significant litigation and other contingencies, significant gains and losses on investments, the income
tax effects of the foregoing and significant tax matters. Cisco’s management also uses the foregoing non-GAAP measures, in addition to the corresponding GAAP measures, in reviewing the financial results
of Cisco. In prior periods, Cisco has excluded other items that it no longer excludes for purposes of its non-GAAP financial measures. From time to time in the future there may be other items that Cisco may
exclude for purposes of its internal budgeting process and in reviewing its financial results. For additional information on the items excluded by Cisco from one or more of its non-GAAP financial measures,
refer to the Form 8-K regarding this release furnished today to the Securities and Exchange Commission.

[0001193125-17-045265:8k_2_02:135]
Cisco
divested the Customer Premises Equipment portion of the Service Provider Video Connected Devices business (“SP Video CPE Business”) during the second quarter of fiscal 2016 on November 20, 2015. This release includes, where indicated,
financial measures that exclude the SP Video CPE Business. Cisco believes that the presentation of these measures provides useful information to investors and management regarding financial and business trends relating to its financial condition and
its historical and projected results of operations because the SP Video CPE Business is no longer part of Cisco and will not be part of Cisco on a go forward basis. Cisco’s management also uses the financial measures excluding the SP Video CPE
Business in reviewing the financial results of Cisco.

[0001193125-17-045265:8k_2_02:136]
About Cisco

[0001193125-17-045265:8k_2_02:137]
Cisco (NASDAQ: CSCO) is the worldwide technology leader that has been making the Internet work since 1984. Our people, products and partners help society
securely connect and seize tomorrow’s digital opportunity today. Discover more at thenetwork.cisco.com and follow us on Twitter at @Cisco.

[0001193125-17-045265:8k_2_02:138]
Copyright
© 2017 Cisco and/or its affiliates. All rights reserved. Cisco and the Cisco logo are trademarks or registered trademarks of Cisco and/or its affiliates in the U.S. and other countries. To
view a list of Cisco trademarks, go to: www.cisco.com/go/trademarks. Third-party trademarks mentioned in this document are the property of their respective owners. The use of the word partner does not imply a partnership relationship between Cisco
and any other company. This document is Cisco Public Information.
