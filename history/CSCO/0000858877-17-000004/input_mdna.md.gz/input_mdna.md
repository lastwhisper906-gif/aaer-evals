# CSCO MD&A — 0000858877-17-000004


## mdna

[0000858877-17-000004:mdna:1]
[same as prior period, unchanged from 0000858877-16-000123:mdna:1]

[0000858877-17-000004:mdna:2]
[same as prior period, unchanged from 0000858877-16-000123:mdna:2]

[0000858877-17-000004:mdna:3]
[same as prior period, unchanged from 0000858877-16-000123:mdna:3]

[0000858877-17-000004:mdna:4]
[same as prior period, unchanged from 0000858877-16-000123:mdna:4]

[0000858877-17-000004:mdna:5]
[same as prior period, unchanged from 0000858877-16-000123:mdna:5]

[0000858877-17-000004:mdna:6]
|  | Three Months Ended |  | Six Months Ended |  |
|  | January 28, 2017 |  | January 23, 2016 |  | Variance |  | January 28, 2017 |  | January 23, 2016 |  | Variance |  |
| Revenue (1) | $ | 11,580 |  |  | $ | 11,927 |  |  | (2.9 | )% |  | $ | 23,932 |  |  | $ | 24,609 |  |  | (2.8 | )% |  |
| Gross margin percentage | 62.8 | % |  | 62.3 | % |  | 0.5 |  | pts | 63.3 | % |  | 62.0 | % |  | 1.3 |  | pts |
| Research and development | $ | 1,508 |  |  | $ | 1,509 |  |  | (0.1 | )% |  | $ | 3,053 |  |  | $ | 3,069 |  |  | (0.5 | )% |  |
| Sales and marketing | $ | 2,222 |  |  | $ | 2,286 |  |  | (2.8 | )% |  | $ | 4,640 |  |  | $ | 4,729 |  |  | (1.9 | )% |  |
| General and administrative | $ | 456 |  |  | $ | 176 |  |  | 159.1 | % |  | $ | 1,011 |  |  | $ | 715 |  |  | 41.4 | % |  |
| Total research and development, sales and marketing, general and administrative | $ | 4,186 |  |  | $ | 3,971 |  |  | 5.4 | % |  | $ | 8,704 |  |  | $ | 8,513 |  |  | 2.2 | % |  |
| Total as a percentage of revenue | 36.1 | % |  | 33.3 | % |  | 2.8 |  | pts | 36.4 | % |  | 34.6 | % |  | 1.8 |  | pts |
| Amortization of purchased intangible assets included in operating expenses | $ | 64 |  |  | $ | 71 |  |  | (9.9 | )% |  | $ | 142 |  |  | $ | 140 |  |  | 1.4 | % |  |
| Restructuring and other charges included in operating expenses | $ | 133 |  |  | $ | 96 |  |  | 38.5 | % |  | $ | 544 |  |  | $ | 238 |  |  | 128.6 | % |  |
| Operating income as a percentage of revenue | 25.0 | % |  | 27.6 | % |  | (2.6 | ) | pts | 24.1 | % |  | 25.9 | % |  | (1.8 | ) | pts |
| Income tax percentage | 20.8 | % |  | 4.8 | % |  | 16.0 |  | pts | 21.1 | % |  | 13.4 | % |  | 7.7 |  | pts |
| Net income | $ | 2,348 |  |  | $ | 3,147 |  |  | (25.4 | )% |  | $ | 4,670 |  |  | $ | 5,577 |  |  | (16.3 | )% |  |
| Net income as a percentage of revenue | 20.3 | % |  | 26.4 | % |  | (6.1 | ) | pts | 19.5 | % |  | 22.7 | % |  | (3.2 | ) | pts |
| Earnings per share—diluted | $ | 0.47 |  |  | $ | 0.62 |  |  | (24.2 | )% |  | $ | 0.92 |  |  | $ | 1.09 |  |  | (15.6 | )% |  |

[0000858877-17-000004:mdna:7]
(1) During the second quarter of fiscal 2016, we completed the sale of the Customer Premises Equipment portion of our Service Provider Video Connected Devices business (“SP Video CPE Business”). As a result, revenue from this portion of the Service Provider Video product category will not recur in future periods. Includes SP Video CPE Business revenue of $93 million for the second quarter of fiscal 2016 and $504 million for the first six months of fiscal 2016.

[0000858877-17-000004:mdna:8]
[same as prior period, unchanged from 0000858877-16-000123:mdna:52]

[0000858877-17-000004:mdna:9]
[same as prior period, unchanged from 0000858877-16-000123:mdna:8]

[0000858877-17-000004:mdna:10]
[same as prior period, unchanged from 0000858877-16-000123:mdna:9]

[0000858877-17-000004:mdna:11]
Three Months Ended January 28, 2017 Compared with Three Months Ended January 23, 2016

[0000858877-17-000004:mdna:12]
In the second quarter of fiscal 2017, we continued to deliver solid profitability and cash flows. We remain focused on accelerating innovation across our portfolio, and we believe that we have made progress over the past year in our strategic priority areas.  We continue to operate in a challenging and highly competitive environment, which has impacted, in particular, our NGN Routing and Switching areas. We saw some improvements in the service provider customer market compared to the first quarter of fiscal 2017, although we expect ongoing uncertainty in that area. We continued to see weakness in emerging countries in the aggregate.  We experienced solid revenue growth in Security, Collaboration, Services, and Wireless and we continued to make progress in the transition of our business model to increased software and subscriptions.  While the overall environment remains uncertain, we continue to aggressively invest in priority areas to drive profitable growth over the long term.

[0000858877-17-000004:mdna:13]
In the second quarter of fiscal 2017, our revenue decreased by 3% (decreased 2% not including revenue from the divested SP Video CPE products which had been included in the prior year period) as compared with the second quarter of fiscal 2016.  Within total revenue, product revenue decreased 5% while service revenue increased 5%.  Total gross margin increased by 0.5 percentage points, driven by higher service gross margin.  As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses, collectively, increased by 2.8 percentage points driven by a $286 million pre-tax gain from the sale of our SP Video CPE Business recorded in the second quarter of fiscal 2016. Operating income as a percentage of revenue decreased by 2.6 percentage points.  Diluted earnings per share decreased by 24%, driven by a 25% decrease in net income. A significant portion of the decrease in net income in the second quarter of fiscal 2017, as compared to the second quarter of fiscal 2016 was attributable to $519 million in tax benefits and the gain from the sale of our SP Video CPE Business as discussed above, both recorded in the second quarter of fiscal 2016. These tax benefits primarily related to our settlement with the IRS of all outstanding items related to the audit of our federal income tax returns covering the period from fiscal 2008 through fiscal 2010 and the permanent reinstatement of the U.S. federal R&D tax credit.

[0000858877-17-000004:mdna:14]
In terms of our geographic segments, revenue from the Americas decreased by $0.3 billion, driven in large part by lower product revenue in the United States. EMEA revenue decreased slightly led by a product revenue decline in the United Kingdom. Revenue in our APJC segment decreased $0.1 billion, led by a product revenue decrease in China. We experienced revenue declines from many emerging countries. The “BRICM” countries experienced a product revenue decline of 16% in the aggregate, driven by  declines in the emerging countries of China and Mexico of 30% and 36%, respectively, partially offset by increased product revenue in India, Russia and Brazil of 16%, 4% and 2%, respectively.

[0000858877-17-000004:mdna:15]
From a customer market standpoint, we experienced product revenue declines in the service provider, public sector and enterprise markets, while the commercial market experienced growth. The decline in the service provider market was driven in part by the sale of the SP Video CPE Business in the second quarter of fiscal 2016.

[0000858877-17-000004:mdna:16]
From a product category perspective, total company product revenue, not including SP Video CPE products in the prior year period, decreased 4% year over year. This decrease was led by product revenue decreases in NGN Routing and Switching of 10% and 5%, respectively. The decrease in NGN Routing was driven by a 17% decline in revenue from our high-end router products. The decline in sales of our Switching products was primarily due to lower sales of switches used in campus environments, which comprise the majority of our Switching portfolio. We believe the decline in sales of Switching products used in campus environments was driven by uncertainty in the macro environment, which led to a slowdown in customer spending, as well as by a highly competitive landscape.  Product revenue from Data Center and Service Provider Video decreased by 4% and 41%, respectively.  Partially offsetting these decreases was product revenue growth in Security, Collaboration and Wireless, which grew by 14%, 4% and 3%, respectively.

[0000858877-17-000004:mdna:17]
[same as prior period, unchanged from 0000858877-16-000123:mdna:16]

[0000858877-17-000004:mdna:18]
[same as prior period, unchanged from 0000858877-16-000123:mdna:17]

[0000858877-17-000004:mdna:19]
Six Months Ended January 28, 2017 Compared with Six Months Ended January 23, 2016

[0000858877-17-000004:mdna:20]
Diluted earnings per share decreased by 16% from the prior year, as a result of a 16% decrease in net income. Revenue decreased 3%, with product revenue decreasing 5% and service revenue increasing 6%. Total gross margin increased by 1.3 percentage points driven in part by the sale of the lower margin SP Video CPE Business. As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses collectively increased by 1.8 percentage points. Operating income as a percentage of revenue decreased by 1.8 percentage points. Net income for the first six months of fiscal 2017 was negatively impacted by a higher effective tax rate.

[0000858877-17-000004:mdna:21]
[same as prior period, unchanged from 0000858877-16-000123:mdna:18]

[0000858877-17-000004:mdna:22]
[same as prior period, unchanged from 0000858877-16-000123:mdna:19]

[0000858877-17-000004:mdna:23]
[same as prior period, unchanged from 0000858877-16-000123:mdna:20]

[0000858877-17-000004:mdna:24]
[same as prior period, unchanged from 0000858877-16-000123:mdna:21]

[0000858877-17-000004:mdna:25]
[same as prior period, unchanged from 0000858877-16-000123:mdna:22]

[0000858877-17-000004:mdna:26]
The following is a summary of our other key financial measures for the second quarter and first six months of fiscal 2017 (in millions, except annualized inventory turns):

[0000858877-17-000004:mdna:27]
|  |  | January 28, 2017 |  | July 30, 2016 |
| Cash and cash equivalents and investments |  | $ | 71,845 |  |  | $ | 65,756 |  |
| Deferred revenue |  | $ | 17,086 |  |  | $ | 16,472 |  |
| Inventories |  | $ | 1,264 |  |  | $ | 1,217 |  |
| Annualized inventory turns |  | 14.1 |  |  | 14.6 |  |

[0000858877-17-000004:mdna:28]
|  |  | Six Months Ended |
|  |  | January 28, 2017 |  | January 23, 2016 |
| Cash provided by operating activities |  | $ | 6,502 |  |  | $ | 6,688 |  |
| Repurchases of common stock—stock repurchase program |  | $ | 2,002 |  |  | $ | 2,469 |  |
| Dividends |  | $ | 2,612 |  |  | $ | 2,133 |  |

[0000858877-17-000004:mdna:29]
47

[0000858877-17-000004:mdna:30]
[same as prior period, unchanged from 0000858877-16-000123:mdna:26]

[0000858877-17-000004:mdna:31]
[same as prior period, unchanged from 0000858877-16-000123:mdna:27]

[0000858877-17-000004:mdna:32]
[same as prior period, unchanged from 0000858877-16-000123:mdna:28]

[0000858877-17-000004:mdna:33]
[same as prior period, unchanged from 0000858877-16-000123:mdna:29]

[0000858877-17-000004:mdna:34]
[same as prior period, unchanged from 0000858877-16-000123:mdna:30]

[0000858877-17-000004:mdna:35]
[same as prior period, unchanged from 0000858877-16-000123:mdna:31]

[0000858877-17-000004:mdna:36]
[same as prior period, unchanged from 0000858877-16-000123:mdna:32]

[0000858877-17-000004:mdna:37]
[same as prior period, unchanged from 0000858877-16-000123:mdna:33]

[0000858877-17-000004:mdna:38]
[same as prior period, unchanged from 0000858877-16-000123:mdna:34]

[0000858877-17-000004:mdna:39]
[same as prior period, unchanged from 0000858877-16-000123:mdna:35]

[0000858877-17-000004:mdna:40]
[same as prior period, unchanged from 0000858877-16-000123:mdna:36]

[0000858877-17-000004:mdna:41]
[same as prior period, unchanged from 0000858877-16-000123:mdna:37]

[0000858877-17-000004:mdna:42]
As our business and offerings evolve over time, our pricing practices may be required to be modified accordingly, which could result in changes in selling prices, including both VSOE and ESP, in subsequent periods. There were no material impacts during the first six months of fiscal 2017, nor do we currently expect a material impact in the next 12 months on our revenue recognition due to any changes in our VSOE, TPE, or ESP.

[0000858877-17-000004:mdna:43]
[same as prior period, unchanged from 0000858877-16-000123:mdna:86]

[0000858877-17-000004:mdna:44]
[same as prior period, unchanged from 0000858877-16-000123:mdna:39]

[0000858877-17-000004:mdna:45]
[same as prior period, unchanged from 0000858877-16-000123:mdna:40]

[0000858877-17-000004:mdna:46]
[same as prior period, unchanged from 0000858877-16-000123:mdna:41]

[0000858877-17-000004:mdna:47]
[same as prior period, unchanged from 0000858877-16-000123:mdna:42]

[0000858877-17-000004:mdna:48]
[same as prior period, unchanged from 0000858877-16-000123:mdna:43]

[0000858877-17-000004:mdna:49]
|  |  | January 28, 2017 |  | July 30, 2016 |
| Allowance for doubtful accounts |  | $ | 225 |  |  | $ | 249 |  |
| Percentage of gross accounts receivable |  | 4.8 | % |  | 4.1 | % |
| Allowance for credit loss—lease receivables |  | $ | 225 |  |  | $ | 230 |  |
| Percentage of gross lease receivables(1) |  | 7.1 | % |  | 6.6 | % |
| Allowance for credit loss—loan receivables |  | $ | 106 |  |  | $ | 97 |  |
| Percentage of gross loan receivables |  | 4.5 | % |  | 4.5 | % |

[0000858877-17-000004:mdna:50]
[same as prior period, unchanged from 0000858877-16-000123:mdna:45]

[0000858877-17-000004:mdna:51]
[same as prior period, unchanged from 0000858877-16-000123:mdna:46]

[0000858877-17-000004:mdna:52]
[same as prior period, unchanged from 0000858877-16-000123:mdna:47]

[0000858877-17-000004:mdna:53]
A reserve for future sales returns is established based on historical trends in product return rates. The reserve for future sales returns as of January 28, 2017 and July 30, 2016 was $123 million and $126 million, respectively, and was recorded as a reduction of our accounts receivable and revenue. If the actual future returns were to deviate from the historical data on which the reserve had been established, our revenue could be adversely affected.

[0000858877-17-000004:mdna:54]
[same as prior period, unchanged from 0000858877-16-000123:mdna:49]

[0000858877-17-000004:mdna:55]
[same as prior period, unchanged from 0000858877-16-000123:mdna:50]

[0000858877-17-000004:mdna:56]
We record a liability for firm, noncancelable, and unconditional purchase commitments with contract manufacturers and suppliers for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of January 28, 2017, the liability for these purchase commitments was $172 million, compared with $159 million as of July 30, 2016, and was included in other current liabilities.

[0000858877-17-000004:mdna:57]
[same as prior period, unchanged from 0000858877-16-000123:mdna:53]

[0000858877-17-000004:mdna:58]
[same as prior period, unchanged from 0000858877-16-000123:mdna:54]

[0000858877-17-000004:mdna:59]
Our provision for inventory was $35 million and $41 million for the first six months of fiscal 2017 and 2016, respectively. The provision for the liability related to purchase commitments with contract manufacturers and suppliers was $74 million and $94 million for the first six months of fiscal 2017 and 2016, respectively. If there were to be a sudden and significant decrease in demand for our products, or if there were a higher incidence of inventory obsolescence because of rapidly changing technology and customer requirements, we could be required to increase our inventory write-downs, and our liability for purchase commitments with contract manufacturers and suppliers, and accordingly our profitability, could be adversely affected. We regularly evaluate our exposure for inventory write-downs and the adequacy of our liability for purchase commitments. Inventory and supply chain management remain areas of focus as we balance the need to maintain supply chain flexibility to help ensure competitive lead times with the risk of inventory obsolescence, particularly in light of current macroeconomic uncertainties and conditions and the resulting potential for changes in future demand forecast.

[0000858877-17-000004:mdna:60]
Loss Contingencies and Product Warranties

[0000858877-17-000004:mdna:61]
We are subject to the possibility of various losses arising in the ordinary course of business. We consider the likelihood of impairment of an asset or the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated. We regularly evaluate information available to us to determine whether such accruals should be made or adjusted and whether new accruals are required.

[0000858877-17-000004:mdna:62]
Third parties, including customers, have in the past and may in the future assert claims or initiate litigation related to exclusive patent, copyright, trademark, and other intellectual property rights to technologies and related standards that are relevant to us. These assertions have increased over time as a result of our growth and the general increase in the pace of patent claims assertions, particularly in the United States. If any infringement or other intellectual property claim made against us by any third party is successful, or if we fail to develop non-infringing technology or license the proprietary rights on commercially reasonable terms and conditions, our business, operating results, and financial condition could be materially and adversely affected.

[0000858877-17-000004:mdna:63]
In the second quarter of fiscal 2014, we recorded a charge to product cost of sales of $655 million resulting from failures related to products containing memory components manufactured by a single supplier between 2005 and 2010. We perform regular assessments of the sufficiency of this liability and reduced the amount by a total of $238 million in fiscal 2016 and fiscal 2015 based on updated analyses.  During the second quarter of fiscal 2017, we further reduced the liability by $141 million to reflect lower than expected defects, actual usage history, and estimated lower future remediation costs as more of the impacted products age and near the end of the support period covered by the remediation program. The liability related to this matter as of January 28, 2017 and July 30, 2016 was $105 million and $276 million, respectively.

[0000858877-17-000004:mdna:64]
In addition, during the second quarter of fiscal 2017, we recorded a $125 million charge to product cost of sales related to the expected remediation costs for anticipated failures in future periods of a widely-used clock-signal component sourced from a third party which is included in several of our products.

[0000858877-17-000004:mdna:65]
Estimating these liabilities is complex and subjective, and if we experience changes in a number of underlying assumptions and estimates such as a change in claims compared with our expectations, or if the cost of servicing these claims is different than expected, our estimated liabilities for these matters may be impacted.

[0000858877-17-000004:mdna:66]
[same as prior period, unchanged from 0000858877-16-000123:mdna:60]

[0000858877-17-000004:mdna:67]
[same as prior period, unchanged from 0000858877-16-000123:mdna:61]

[0000858877-17-000004:mdna:68]
[same as prior period, unchanged from 0000858877-16-000123:mdna:65]

[0000858877-17-000004:mdna:69]
[same as prior period, unchanged from 0000858877-16-000123:mdna:66]

[0000858877-17-000004:mdna:70]
[same as prior period, unchanged from 0000858877-16-000123:mdna:62]

[0000858877-17-000004:mdna:71]
Our fixed income and publicly traded equity securities, collectively, are reflected in the Consolidated Balance Sheets at a fair value of $60.9 billion as of January 28, 2017, compared with $58.1 billion as of July 30, 2016. Our fixed income investment portfolio as of January 28, 2017 consisted primarily of high quality investment-grade securities. See Note 8 to the Consolidated Financial Statements.

[0000858877-17-000004:mdna:72]
[same as prior period, unchanged from 0000858877-16-000123:mdna:64]

[0000858877-17-000004:mdna:73]
[same as prior period, unchanged from 0000858877-16-000123:mdna:67]

[0000858877-17-000004:mdna:74]
The inputs and fair value are reviewed for reasonableness, may be further validated by comparison to publicly available information, and could be adjusted based on market indices or other information that management deems material to its estimate of fair value. The assessment of fair value can be difficult and subjective. However, given the relative reliability of the inputs we use to value our investment portfolio, and because substantially all of our valuation inputs are obtained using quoted market prices for similar or identical assets, we do not believe that the nature of estimates and assumptions affected by levels of subjectivity and judgment was material to the valuation of the investment portfolio as of January 28, 2017. Level 3 assets do not represent a significant portion of our total assets measured at fair value on a recurring basis as of January 28, 2017 and July 30, 2016.

[0000858877-17-000004:mdna:75]
[same as prior period, unchanged from 0000858877-16-000123:mdna:69]

[0000858877-17-000004:mdna:76]
[same as prior period, unchanged from 0000858877-16-000123:mdna:70]

[0000858877-17-000004:mdna:77]
[same as prior period, unchanged from 0000858877-16-000123:mdna:71]

[0000858877-17-000004:mdna:78]
[same as prior period, unchanged from 0000858877-16-000123:mdna:72]

[0000858877-17-000004:mdna:79]
We also have investments in privately held companies, some of which are in the startup or development stages. As of January 28, 2017, our investments in privately held companies were $1,007 million, compared with $1,003 million as of July 30, 2016, and were included in other assets. We monitor these investments for events or circumstances indicative of potential impairment, and we make appropriate reductions in carrying values if we determine that an impairment charge is required, based primarily on the financial condition and near-term prospects of these companies. These investments are inherently risky because the markets for the technologies or products these companies are developing are typically in the early stages and may never materialize. Our impairment charges on investments in privately held companies were $111 million and $56 million for the first six months of fiscal 2017 and 2016, respectively.

[0000858877-17-000004:mdna:80]
[same as prior period, unchanged from 0000858877-16-000123:mdna:125]

[0000858877-17-000004:mdna:81]
[same as prior period, unchanged from 0000858877-16-000123:mdna:77]

[0000858877-17-000004:mdna:82]
[same as prior period, unchanged from 0000858877-16-000123:mdna:78]

[0000858877-17-000004:mdna:83]
[same as prior period, unchanged from 0000858877-16-000123:mdna:74]

[0000858877-17-000004:mdna:84]
[same as prior period, unchanged from 0000858877-16-000123:mdna:75]

[0000858877-17-000004:mdna:85]
The goodwill recorded in the Consolidated Balance Sheets as of January 28, 2017 and July 30, 2016 was $26.8 billion and $26.6 billion, respectively. In response to changes in industry and market conditions, we could be required to strategically realign our resources and consider restructuring, disposing of, or otherwise exiting businesses, which could result in an impairment of goodwill. There was no impairment of goodwill in each of the first six months of fiscal 2017 and 2016.

[0000858877-17-000004:mdna:86]
[same as prior period, unchanged from 0000858877-16-000123:mdna:79]

[0000858877-17-000004:mdna:87]
We make judgments about the recoverability of purchased intangible assets with finite lives whenever events or changes in circumstances indicate that an impairment may exist. Recoverability of purchased intangible assets with finite lives is measured by comparing the carrying amount of the asset to the future undiscounted cash flows the asset is expected to generate. We review indefinite-lived intangible assets for impairment annually or whenever events or changes in circumstances indicate that the asset might be impaired. If the asset is considered to be impaired, the amount of any impairment is measured as the difference between the carrying value and the fair value of the impaired asset. Assumptions and estimates about future values and remaining useful lives of our purchased intangible assets are complex and subjective. They can be affected by a variety of factors, including external factors such as industry and economic trends, and internal factors such as changes in our business strategy and our internal forecasts.  Our impairment charges related to purchased intangible assets were $42 million and $37 million for the first six months of fiscal 2017 and 2016, respectively. Our ongoing consideration of all the factors described previously could result in additional impairment charges in the future, which could adversely affect our net income.

[0000858877-17-000004:mdna:88]
[same as prior period, unchanged from 0000858877-16-000123:mdna:81]

[0000858877-17-000004:mdna:89]
We are subject to income taxes in the United States and numerous foreign jurisdictions. Our effective tax rates differ from the statutory rate, primarily due to the tax impact of state taxes, foreign operations, R&D tax credits, domestic manufacturing deductions, tax audit settlements, nondeductible compensation, international realignments, and transfer pricing adjustments. Our effective tax rate was 20.8% and 4.8% in the second quarter of fiscal 2017 and 2016, respectively. Our effective tax rate was 21.1% and 13.4% in the first six months of fiscal 2017 and 2016, respectively.

[0000858877-17-000004:mdna:90]
[same as prior period, unchanged from 0000858877-16-000123:mdna:83]

[0000858877-17-000004:mdna:91]
[same as prior period, unchanged from 0000858877-16-000123:mdna:84]

[0000858877-17-000004:mdna:92]
[same as prior period, unchanged from 0000858877-16-000123:mdna:87]

[0000858877-17-000004:mdna:93]
[same as prior period, unchanged from 0000858877-16-000123:mdna:88]

[0000858877-17-000004:mdna:94]
[same as prior period, unchanged from 0000858877-16-000123:mdna:85]

[0000858877-17-000004:mdna:95]
53

[0000858877-17-000004:mdna:96]
[same as prior period, unchanged from 0000858877-16-000123:mdna:100]

[0000858877-17-000004:mdna:97]
[same as prior period, unchanged from 0000858877-16-000123:mdna:101]

[0000858877-17-000004:mdna:98]
[same as prior period, unchanged from 0000858877-16-000123:mdna:89]

[0000858877-17-000004:mdna:99]
[same as prior period, unchanged from 0000858877-16-000123:mdna:90]

[0000858877-17-000004:mdna:100]
[same as prior period, unchanged from 0000858877-16-000123:mdna:91]

[0000858877-17-000004:mdna:101]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 28, 2017 |  | January 23, 2016 |  | Variancein Dollars |  | Variance in Percent |  | January 28, 2017 |  | January 23, 2016 |  | Variancein Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 8,491 |  |  | $ | 8,983 |  |  | $ | (492 | ) |  | (5.5 | )% |  | $ | 17,793 |  |  | $ | 18,827 |  |  | $ | (1,034 | ) |  | (5.5 | )% |
| Percentage of revenue |  | 73.3 | % |  | 75.3 | % |  |  |  |  |  |  |  | 74.3 | % |  | 76.5 | % |  |  |  |  |  |  |
| Service |  | 3,089 |  |  | 2,944 |  |  | 145 |  |  | 4.9 | % |  | 6,139 |  |  | 5,782 |  |  | 357 |  |  | 6.2 | % |
| Percentage of revenue |  | 26.7 | % |  | 24.7 | % |  |  |  |  |  |  |  | 25.7 | % |  | 23.5 | % |  |  |  |  |  |  |
| Total |  | $ | 11,580 |  |  | $ | 11,927 |  |  | $ | (347 | ) |  | (2.9 | )% |  | $ | 23,932 |  |  | $ | 24,609 |  |  | $ | (677 | ) |  | (2.8 | )% |

[0000858877-17-000004:mdna:102]
[same as prior period, unchanged from 0000858877-16-000123:mdna:93]

[0000858877-17-000004:mdna:103]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 28, 2017 |  | January 23, 2016 |  | Variancein Dollars |  | Variance in Percent |  | January 28, 2017 |  | January 23, 2016 |  | Variancein Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 6,660 |  |  | $ | 6,911 |  |  | $ | (251 | ) |  | (3.6 | )% |  | $ | 14,103 |  |  | $ | 14,703 |  |  | $ | (600 | ) |  | (4.1 | )% |
| Percentage of revenue |  | 57.5 | % |  | 58.0 | % |  |  |  |  |  | 58.9 | % |  | 59.8 | % |  |  |  |  |
| EMEA |  | 3,065 |  |  | 3,093 |  |  | (28 | ) |  | (0.9 | )% |  | 6,078 |  |  | 6,187 |  |  | (109 | ) |  | (1.8 | )% |
| Percentage of revenue |  | 26.5 | % |  | 25.9 | % |  |  |  |  |  | 25.4 | % |  | 25.1 | % |  |  |  |  |
| APJC |  | 1,855 |  |  | 1,923 |  |  | (68 | ) |  | (3.5 | )% |  | 3,751 |  |  | 3,719 |  |  | 32 |  |  | 0.9 | % |
| Percentage of revenue |  | 16.0 | % |  | 16.1 | % |  |  |  |  |  | 15.7 | % |  | 15.1 | % |  |  |  |  |
| Total |  | $ | 11,580 |  |  | $ | 11,927 |  |  | $ | (347 | ) |  | (2.9 | )% |  | $ | 23,932 |  |  | $ | 24,609 |  |  | $ | (677 | ) |  | (2.8 | )% |

[0000858877-17-000004:mdna:104]
Three Months Ended January 28, 2017 Compared with Three Months Ended January 23, 2016

[0000858877-17-000004:mdna:105]
For the second quarter of fiscal 2017, as compared with the second quarter of fiscal 2016, total revenue decreased by 3%. Total company revenue not including SP Video CPE products decreased 2%. Product revenue decreased by 5% in total, and decreased by 4% not including revenue from SP Video CPE products in the prior year period. Service revenue increased by 5%.  Our total revenue decreased across all geographic segments.  The emerging countries of BRICM, in the aggregate, experienced a 16% product revenue decline, with declines in China and Mexico partially offset by increases in the other three BRICM countries.

[0000858877-17-000004:mdna:106]
We conduct business globally in numerous currencies. The direct effect of foreign currency fluctuations on revenue has not been material because our revenue is primarily denominated in U.S. dollars. However, if the U.S. dollar strengthens relative to other currencies, such strengthening could have an indirect effect on our revenue to the extent it raises the cost of our products to non-U.S. customers and thereby reduces demand. A weaker U.S. dollar could have the opposite effect. However, the precise indirect effect of currency fluctuations is difficult to measure or predict because our revenue is influenced by many factors in addition to the impact of such currency fluctuations. Our revenue in the second quarter of fiscal 2017 was adversely affected by the depreciation of certain currencies relative to the U.S. dollar and especially currencies in certain emerging countries, although the indirect effects are difficult to measure.

[0000858877-17-000004:mdna:107]
[same as prior period, unchanged from 0000858877-16-000123:mdna:98]

[0000858877-17-000004:mdna:108]
[same as prior period, unchanged from 0000858877-16-000123:mdna:113]

[0000858877-17-000004:mdna:109]
[same as prior period, unchanged from 0000858877-16-000123:mdna:114]

[0000858877-17-000004:mdna:110]
Six Months Ended January 28, 2017 Compared with Six Months Ended January 23, 2016

[0000858877-17-000004:mdna:111]
For the first six months of fiscal 2017, as compared with the first six months of fiscal 2016, total revenue decreased by 3%.  Total company revenue not including SP Video CPE products decreased 1%. Product revenue decreased by 5% while service revenue increased by 6%. Our total revenue declined in the Americas and EMEA segments and grew in the APJC segment. The emerging countries of BRICM, in the aggregate, experienced a 12% product revenue decline, with revenue declines in China, Mexico and Brazil partially offset by increases in the other two BRICM countries.

[0000858877-17-000004:mdna:112]
[same as prior period, unchanged from 0000858877-16-000123:mdna:102]

[0000858877-17-000004:mdna:113]
[same as prior period, unchanged from 0000858877-16-000123:mdna:103]

[0000858877-17-000004:mdna:114]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 28, 2017 |  | January 23, 2016 |  | Variancein Dollars |  | Variance in Percent |  | January 28, 2017 |  | January 23, 2016 |  | Variancein Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 4,695 |  |  | $ | 4,989 |  |  | $ | (294 | ) |  | (5.9 | )% |  | $ | 10,175 |  |  | $ | 10,937 |  |  | $ | (762 | ) |  | (7.0 | )% |
| Percentage of product revenue |  | 55.3 | % |  | 55.5 | % |  |  |  |  |  | 57.2 | % |  | 58.0 | % |  |  |  |  |
| EMEA |  | 2,392 |  |  | 2,460 |  |  | (68 | ) |  | (2.8 | )% |  | 4,756 |  |  | 4,943 |  |  | (187 | ) |  | (3.8 | )% |
| Percentage of product revenue |  | 28.2 | % |  | 27.4 | % |  |  |  |  |  | 26.7 | % |  | 26.3 | % |  |  |  |  |
| APJC |  | 1,404 |  |  | 1,534 |  |  | (130 | ) |  | (8.5 | )% |  | 2,862 |  |  | 2,947 |  |  | (85 | ) |  | (2.9 | )% |
| Percentage of product revenue |  | 16.5 | % |  | 17.1 | % |  |  |  |  |  | 16.1 | % |  | 15.7 | % |  |  |  |  |
| Total |  | $ | 8,491 |  |  | $ | 8,983 |  |  | $ | (492 | ) |  | (5.5 | )% |  | $ | 17,793 |  |  | $ | 18,827 |  |  | $ | (1,034 | ) |  | (5.5 | )% |

[0000858877-17-000004:mdna:115]
During the second quarter of fiscal 2016, we completed the sale of our SP Video CPE Business.  As a result, revenue from this portion of the Service Provider Video product category will not recur in future periods.  SP Video CPE Business revenue was $93 million for the second quarter of fiscal 2016 and $504 million for the first six months of fiscal 2016.

[0000858877-17-000004:mdna:116]
[same as prior period, unchanged from 0000858877-16-000123:mdna:107]

[0000858877-17-000004:mdna:117]
Three Months Ended January 28, 2017 Compared with Three Months Ended January 23, 2016

[0000858877-17-000004:mdna:118]
The 6% decrease in product revenue for the Americas segment was led by a significant decline in the service provider market and, to a lesser extent, declines in the public sector and enterprise markets. These product revenue declines were partially offset by the growth in the commercial market in this segment. The product revenue decrease in the service provider market was due in part to the sale of the SP Video CPE Business. The product revenue decrease in the public sector market was due primarily to lower sales to the U.S. federal government and to state and local governments. From a country perspective, product revenue decreased by 5% in the United States, 36% in Mexico and 16% in Canada, partially offset by an increase of 2% in Brazil.

[0000858877-17-000004:mdna:119]
Six Months Ended January 28, 2017 Compared with Six Months Ended January 23, 2016

[0000858877-17-000004:mdna:120]
The decrease in product revenue in the Americas segment reflected declines across all customer markets. The product revenue decrease in the service provider market was driven primarily by the absence of product sales related to our SP Video CPE Business in the first six months of fiscal 2017. We had $378 million in product sales related to our SP Video CPE Business in the first six months of fiscal 2016 in this segment. From a country perspective, product revenue decreased by 6% in the United States, 33% in Mexico, 9% in Canada and 4% in Brazil.

[0000858877-17-000004:mdna:121]
[same as prior period, unchanged from 0000858877-16-000123:mdna:126]

[0000858877-17-000004:mdna:122]
[same as prior period, unchanged from 0000858877-16-000123:mdna:127]

[0000858877-17-000004:mdna:123]
[same as prior period, unchanged from 0000858877-16-000123:mdna:109]

[0000858877-17-000004:mdna:124]
Three Months Ended January 28, 2017 Compared with Three Months Ended January 23, 2016

[0000858877-17-000004:mdna:125]
Product revenue in the EMEA segment decreased by 3%, driven by declines in the service provider, public sector and enterprise markets. Product revenue in the commercial market was flat. The decline in sales to the service provider market was due primarily to the sale of the SP Video CPE Business. Product revenue from emerging countries within EMEA decreased by 5% and product revenue for the remainder of the EMEA segment, which primarily consists of countries in Western Europe, decreased by 2%.

[0000858877-17-000004:mdna:126]
Six Months Ended January 28, 2017 Compared with Six Months Ended January 23, 2016

[0000858877-17-000004:mdna:127]
The decrease in product revenue in the EMEA segment of 4% was driven by declines in the service provider market and, to a lesser extent, declines in the public sector and commercial markets. We experienced product revenue growth in the enterprise market in this segment. The product revenue decrease in the service provider market was driven primarily by the absence of product sales related to our SP Video CPE Business in the first six months of fiscal 2017. We had $108 million in product sales related to our SP Video CPE Business in the first six months of fiscal 2016 in this segment. Product revenue from emerging countries within EMEA decreased by 6% and product revenue for the remainder of the EMEA segment decreased by 3%.

[0000858877-17-000004:mdna:128]
[same as prior period, unchanged from 0000858877-16-000123:mdna:111]

[0000858877-17-000004:mdna:129]
Three Months Ended January 28, 2017 Compared with Three Months Ended January 23, 2016

[0000858877-17-000004:mdna:130]
Product revenue in the APJC segment decreased by 8%, with declines across all customer markets in this segment. From a country perspective, product revenue decreased by 30% in China driven in large part by lower sales of Service Provider Video products and 21% in Australia, partially offset by product revenue increases of 16% in India and 14% in Japan.

[0000858877-17-000004:mdna:131]
Six Months Ended January 28, 2017 Compared with Six Months Ended January 23, 2016

[0000858877-17-000004:mdna:132]
Product revenue in the APJC segment decreased by 3%. The product revenue decline was led by declines in the public sector and service provider markets. These decreases were partially offset by product revenue growth in the commercial and enterprise markets. From a country perspective, product revenue decreased by 18% in China and 3% in Australia while increasing 13% in Japan and 9% in India. Product sales for this geographic segment were adversely impacted by an $18 million decrease in product sales related to the absence of our SP Video CPE Business.

[0000858877-17-000004:mdna:133]
[same as prior period, unchanged from 0000858877-16-000123:mdna:142]

[0000858877-17-000004:mdna:134]
[same as prior period, unchanged from 0000858877-16-000123:mdna:143]

[0000858877-17-000004:mdna:135]
[same as prior period, unchanged from 0000858877-16-000123:mdna:115]

[0000858877-17-000004:mdna:136]
[same as prior period, unchanged from 0000858877-16-000123:mdna:116]

[0000858877-17-000004:mdna:137]
[same as prior period, unchanged from 0000858877-16-000123:mdna:117]

[0000858877-17-000004:mdna:138]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 28, 2017 |  | January 23, 2016 |  | Variancein Dollars |  | Variance in Percent |  | January 28, 2017 |  | January 23, 2016 |  | Variancein Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Switching |  | $ | 3,305 |  |  | $ | 3,475 |  |  | $ | (170 | ) |  | (4.9 | )% |  | $ | 7,021 |  |  | $ | 7,484 |  |  | $ | (463 | ) |  | (6.2 | )% |
| Percentage of product revenue |  | 38.9 | % |  | 38.7 | % |  |  |  |  |  |  |  | 39.5 | % |  | 39.8 | % |  |  |  |  |  |  |
| NGN Routing |  | 1,817 |  |  | 2,014 |  |  | (197 | ) |  | (9.8 | )% |  | 3,906 |  |  | 3,983 |  |  | (77 | ) |  | (1.9 | )% |
| Percentage of product revenue |  | 21.4 | % |  | 22.4 | % |  |  |  |  |  |  |  | 22.0 | % |  | 21.2 | % |  |  |  |  |  |  |
| Collaboration |  | 1,062 |  |  | 1,019 |  |  | 43 |  |  | 4.2 | % |  | 2,143 |  |  | 2,134 |  |  | 9 |  |  | 0.4 | % |
| Percentage of product revenue |  | 12.5 | % |  | 11.3 | % |  |  |  |  |  |  |  | 12.0 | % |  | 11.3 | % |  |  |  |  |  |  |
| Data Center |  | 790 |  |  | 822 |  |  | (32 | ) |  | (3.9 | )% |  | 1,624 |  |  | 1,681 |  |  | (57 | ) |  | (3.4 | )% |
| Percentage of product revenue |  | 9.3 | % |  | 9.2 | % |  |  |  |  |  |  |  | 9.1 | % |  | 8.9 | % |  |  |  |  |  |  |
| Wireless |  | 632 |  |  | 616 |  |  | 16 |  |  | 2.6 | % |  | 1,264 |  |  | 1,262 |  |  | 2 |  |  | 0.2 | % |
| Percentage of product revenue |  | 7.5 | % |  | 6.9 | % |  |  |  |  |  | 7.1 | % |  | 6.7 | % |  |  |  |  |
| Security |  | 528 |  |  | 462 |  |  | 66 |  |  | 14.3 | % |  | 1,068 |  |  | 947 |  |  | 121 |  |  | 12.8 | % |
| Percentage of product revenue |  | 6.2 | % |  | 5.1 | % |  |  |  |  |  |  |  | 6.0 | % |  | 5.0 | % |  |  |  |  |  |  |
| Service Provider Video (1) |  | 241 |  |  | 499 |  |  | (258 | ) |  | (51.7 | )% |  | 512 |  |  | 1,186 |  |  | (674 | ) |  | (56.8 | )% |
| Percentage of product revenue |  | 2.8 | % |  | 5.6 | % |  |  |  |  |  | 2.9 | % |  | 6.3 | % |  |  |  |  |
| Other |  | 116 |  |  | 76 |  |  | 40 |  |  | 52.6 | % |  | 255 |  |  | 150 |  |  | 105 |  |  | 70.0 | % |
| Percentage of product revenue |  | 1.4 | % |  | 0.8 | % |  |  |  |  |  |  |  | 1.4 | % |  | 0.8 | % |  |  |  |  |  |  |
| Total |  | $ | 8,491 |  |  | $ | 8,983 |  |  | $ | (492 | ) |  | (5.5 | )% |  | $ | 17,793 |  |  | $ | 18,827 |  |  | $ | (1,034 | ) |  | (5.5 | )% |

[0000858877-17-000004:mdna:139]
(1) Includes SP Video CPE Business revenue of $93 million for the second quarter of fiscal 2016 and $504 million for the first six months of fiscal 2016.

[0000858877-17-000004:mdna:140]
[same as prior period, unchanged from 0000858877-16-000123:mdna:120]

[0000858877-17-000004:mdna:141]
[same as prior period, unchanged from 0000858877-16-000123:mdna:122]

[0000858877-17-000004:mdna:142]
Three Months Ended January 28, 2017 Compared with Three Months Ended January 23, 2016

[0000858877-17-000004:mdna:143]
The decrease in revenue in our Switching product category of 5%, or $170 million, was driven primarily by a decrease in sales of Switching products used in campus environments, which comprise the majority of our Switching portfolio.  We believe this was driven by the uncertainty in the macro environment which led to a slowdown in customer spending, as well as by a highly competitive landscape.

[0000858877-17-000004:mdna:144]
[same as prior period, unchanged from 0000858877-16-000123:mdna:152]

[0000858877-17-000004:mdna:145]
[same as prior period, unchanged from 0000858877-16-000123:mdna:153]

[0000858877-17-000004:mdna:146]
In terms of subcategories, the decrease was driven by a 17%, or $170 million, decrease in revenue from our modular switches and, to a lesser extent, a 24%, or $30 million, decrease in sales of storage products. Revenue from our modular switches decreased due primarily to lower sales of most of the Cisco Catalyst Series Switches and Cisco Nexus 7000 Series Switches. We experienced an increase in revenue from LAN fixed-configuration switches of 1%, or $30 million, driven primarily by higher sales of our Cisco Nexus 9300 Series Switches, Cisco Catalyst 3850 Series Switches and Cisco Catalyst 3650 Series Switches partially offset by a decrease in sales of certain other products in this portfolio.

[0000858877-17-000004:mdna:147]
Six Months Ended January 28, 2017 Compared with Six Months Ended January 23, 2016

[0000858877-17-000004:mdna:148]
Revenue in our Switching product category decreased by 6%, or $463 million, driven by a 19%, or $426 million, decrease in revenue from our modular switches and a 19%, or $40 million, decrease in sales of storage products partially offset by a slight increase in revenue from our LAN fixed-configuration switches.  Revenue from our modular switches decreased driven by lower sales of most of the Cisco Catalyst Series Switches and Cisco Nexus 7000 Series Switches, partially offset by growth in Cisco Nexus 9500 Series Switches within this product category. Revenue from LAN fixed-configuration switches increased slightly due to higher sales of our Cisco Nexus 9300 Series Switches, Cisco Catalyst 3850 Series Switches and Cisco Catalyst 3650 Series Switches partially offset by a decrease in sales of certain other products in this portfolio.

[0000858877-17-000004:mdna:149]
[same as prior period, unchanged from 0000858877-16-000123:mdna:128]

[0000858877-17-000004:mdna:150]
Three Months Ended January 28, 2017 Compared with Three Months Ended January 23, 2016

[0000858877-17-000004:mdna:151]
Revenue in our NGN Routing product category decreased by 10%, or $197 million, driven by a 17%, or $196 million, decrease in revenue from our high-end router products and an 11%, or $70 million, decrease in revenue from our midrange and low-end router products. These decreases were partially offset by a 27%, or $69 million, increase in revenue from what we categorize as other NGN Routing products. The decrease in revenue from our high-end router products was driven by a decrease in revenue from most of our products within our Cisco Aggregation Services Router (ASR) products and our Cisco Carrier Routing System (CRS) products. Revenue from our midrange and low-end router products decreased, driven by lower sales of our Cisco Integrated Services Router (ISR) products. Revenue from other NGN Routing products increased due to higher sales of certain optical networking products and cable access products.

[0000858877-17-000004:mdna:152]
Six Months Ended January 28, 2017 Compared with Six Months Ended January 23, 2016

[0000858877-17-000004:mdna:153]
The decrease in revenue in our NGN Routing product category of 2%, or $77 million, was driven by a 5%, or $108 million, decrease in revenue from our high-end router products and, a 5%, or $62 million, decrease in revenue from our midrange and low-end router products, partially offset by a 16%, or $93 million, increase in revenue from other NGN Routing products. Revenue from high-end router products decreased due to a decrease in revenue from most of our products within our ASR products and our CRS products. The decrease in revenue from our midrange and low-end router products was due to lower sales of our Cisco ISR products and certain of our access router products.  Revenue from other NGN Routing products increased due to higher sales of certain optical networking products and cable access products.

[0000858877-17-000004:mdna:154]
[same as prior period, unchanged from 0000858877-16-000123:mdna:130]

[0000858877-17-000004:mdna:155]
Three Months Ended January 28, 2017 Compared with Three Months Ended January 23, 2016

[0000858877-17-000004:mdna:156]
Revenue from our Collaboration product category increased by 4%, or $43 million, driven by growth across the various subcategories within this product category. The growth in Conferencing revenue resulted from higher usage and recurring revenue from WebEx, which we include as product revenue in this category.  The increase in Unified Communications revenue was driven by higher software revenue. Revenue from Cisco TelePresence products increased due to higher revenue in infrastructure and endpoint products as momentum continued as a result of new product introductions. We continue to increase the amount of deferred revenue and the proportion of recurring revenue related to our Collaboration product category.

[0000858877-17-000004:mdna:157]
Six Months Ended January 28, 2017 Compared with Six Months Ended January 23, 2016

[0000858877-17-000004:mdna:158]
Revenue in our Collaboration product category was flat as the growth in Conferencing revenue offset the decreases in sales from Cisco TelePresence and Unified Communications products. The growth in Conferencing revenue resulted from higher usage and recurring revenue from WebEx. The decrease in Unified Communications revenue was driven by decreased revenue from phones, partially offset by higher software revenue. Revenue from Cisco TelePresence products declined due to lower revenue from endpoint products.

[0000858877-17-000004:mdna:159]
[same as prior period, unchanged from 0000858877-16-000123:mdna:165]

[0000858877-17-000004:mdna:160]
[same as prior period, unchanged from 0000858877-16-000123:mdna:166]

[0000858877-17-000004:mdna:161]
[same as prior period, unchanged from 0000858877-16-000123:mdna:132]

[0000858877-17-000004:mdna:162]
Three Months Ended January 28, 2017 Compared with Three Months Ended January 23, 2016

[0000858877-17-000004:mdna:163]
The decrease in revenue in our Data Center product category of 4%, or $32 million, was primarily driven by a decrease in sales of our Cisco Unified Computing System products, with declines in the commercial and public sector markets partially offset by growth in the service provider market. We believe two key factors are adversely impacting the sales of this product category. We believe the uncertainty in the macro environment led to a slowdown of customer spending.  Additionally, we are seeing a market transition with computing workloads shifting from blade server systems to rack-based systems.

[0000858877-17-000004:mdna:164]
Six Months Ended January 28, 2017 Compared with Six Months Ended January 23, 2016

[0000858877-17-000004:mdna:165]
Revenue in our Data Center product category decreased by 3%, or $57 million, driven by a decrease in sales of our  Cisco Unified Computing System products, with declines in the commercial, public sector and service provider markets, partially offset by growth in the enterprise market.

[0000858877-17-000004:mdna:166]
[same as prior period, unchanged from 0000858877-16-000123:mdna:134]

[0000858877-17-000004:mdna:167]
Three Months Ended January 28, 2017 Compared with Three Months Ended January 23, 2016

[0000858877-17-000004:mdna:168]
Revenue in our Wireless product category increased by 3%, or $16 million, due primarily to continued growth in sales of Meraki products within this product category, partially offset by a decrease in sales of our controller products and, to a lesser extent, a decrease in sales of our access point products. We continue to increase the amount of deferred revenue and the proportion of recurring revenue related to our Wireless product category.

[0000858877-17-000004:mdna:169]
Six Months Ended January 28, 2017 Compared with Six Months Ended January 23, 2016

[0000858877-17-000004:mdna:170]
Revenue in our Wireless product category was flat as increases in sales from Meraki products and certain of our access point products were offset by a decrease in sales of our controller products.

[0000858877-17-000004:mdna:171]
[same as prior period, unchanged from 0000858877-16-000123:mdna:136]

[0000858877-17-000004:mdna:172]
Three Months Ended January 28, 2017 Compared with Three Months Ended January 23, 2016

[0000858877-17-000004:mdna:173]
Revenue in our Security product category increased 14%, or $66 million, driven by higher sales of advanced threat security, unified threat management and web security products. We continue to increase the amount of deferred revenue and the proportion of recurring revenue related to our Security product category.

[0000858877-17-000004:mdna:174]
Six Months Ended January 28, 2017 Compared with Six Months Ended January 23, 2016

[0000858877-17-000004:mdna:175]
Revenue in our Security product category increased 13%, or $121 million, driven by similar factors as discussed in the three-month period immediately above.

[0000858877-17-000004:mdna:176]
[same as prior period, unchanged from 0000858877-16-000123:mdna:138]

[0000858877-17-000004:mdna:177]
Three Months Ended January 28, 2017 Compared with Three Months Ended January 23, 2016

[0000858877-17-000004:mdna:178]
The decrease in revenue from our Service Provider Video product category of 52%, or $258 million, was driven by a decrease in revenue from Service Provider Video software and solutions driven by a decline in China and a decrease in product sales of $93 million related to our SP Video CPE Business which we sold during the second quarter of fiscal 2016.

[0000858877-17-000004:mdna:179]
Six Months Ended January 28, 2017 Compared with Six Months Ended January 23, 2016

[0000858877-17-000004:mdna:180]
Revenue from our Service Provider Video product category decreased by 57%, or $674 million, due to a $504 million decrease in sales related to the SP Video CPE Business and a decrease in revenue from Service Provider Video software and solutions.

[0000858877-17-000004:mdna:181]
[same as prior period, unchanged from 0000858877-16-000123:mdna:140]

[0000858877-17-000004:mdna:182]
The increase in revenue in our Other Products category was due to increased revenue from our Internet of Things (“IoT”) products, driven by our fiscal 2016 Jasper acquisition.

[0000858877-17-000004:mdna:183]
[same as prior period, unchanged from 0000858877-16-000123:mdna:177]

[0000858877-17-000004:mdna:184]
[same as prior period, unchanged from 0000858877-16-000123:mdna:178]

[0000858877-17-000004:mdna:185]
[same as prior period, unchanged from 0000858877-16-000123:mdna:144]

[0000858877-17-000004:mdna:186]
[same as prior period, unchanged from 0000858877-16-000123:mdna:145]

[0000858877-17-000004:mdna:187]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 28, 2017 |  | January 23, 2016 |  | Variancein Dollars |  | Variance in Percent |  | January 28, 2017 |  | January 23, 2016 |  | Variancein Dollars |  | Variance in Percent |
| Service revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 1,965 |  |  | $ | 1,922 |  |  | $ | 43 |  |  | 2.2 | % |  | $ | 3,928 |  |  | $ | 3,766 |  |  | $ | 162 |  |  | 4.3 | % |
| Percentage of service revenue |  | 63.6 | % |  | 65.3 | % |  |  |  |  |  | 64.0 | % |  | 65.1 | % |  |  |  |  |
| EMEA |  | 673 |  |  | 633 |  |  | 40 |  |  | 6.3 | % |  | 1,322 |  |  | 1,244 |  |  | 78 |  |  | 6.3 | % |
| Percentage of service revenue |  | 21.8 | % |  | 21.5 | % |  |  |  |  |  | 21.5 | % |  | 21.5 | % |  |  |  |  |
| APJC |  | 451 |  |  | 389 |  |  | 62 |  |  | 15.9 | % |  | 889 |  |  | 772 |  |  | 117 |  |  | 15.2 | % |
| Percentage of service revenue |  | 14.6 | % |  | 13.2 | % |  |  |  |  |  | 14.5 | % |  | 13.4 | % |  |  |  |  |
| Total |  | $ | 3,089 |  |  | $ | 2,944 |  |  | $ | 145 |  |  | 4.9 | % |  | $ | 6,139 |  |  | $ | 5,782 |  |  | $ | 357 |  |  | 6.2 | % |

[0000858877-17-000004:mdna:188]
Three Months Ended January 28, 2017 Compared with Three Months Ended January 23, 2016

[0000858877-17-000004:mdna:189]
Service revenue increased 5%, with growth across all of our geographic segments. Worldwide technical support services revenue and worldwide advanced services revenue each increased by 5%. Technical support services revenue experienced growth across all geographic segments. Renewals and technical support service contract initiations associated with product sales provided an installed base of equipment being serviced which, in concert with new service offerings, were the primary factors driving the revenue increases.  Advanced services revenue, which relates to professional services for specific customer network needs, increased in the APJC and EMEA geographic segments and was flat in the Americas segment.

[0000858877-17-000004:mdna:190]
Six Months Ended January 28, 2017 Compared with Six Months Ended January 23, 2016

[0000858877-17-000004:mdna:191]
Service revenue increased across all geographic segments. Worldwide technical support services revenue increased by 7% and worldwide advanced services increased by 3%. Technical support services revenue had solid growth across all geographic segments.  Advanced services revenue grew in the APJC and EMEA segments and was flat in the Americas segment.

[0000858877-17-000004:mdna:192]
[same as prior period, unchanged from 0000858877-16-000123:mdna:193]

[0000858877-17-000004:mdna:193]
[same as prior period, unchanged from 0000858877-16-000123:mdna:194]

[0000858877-17-000004:mdna:194]
[same as prior period, unchanged from 0000858877-16-000123:mdna:149]

[0000858877-17-000004:mdna:195]
[same as prior period, unchanged from 0000858877-16-000123:mdna:150]

[0000858877-17-000004:mdna:196]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | AMOUNT |  | PERCENTAGE |  | AMOUNT |  | PERCENTAGE |
|  |  | January 28, 2017 |  | January 23, 2016 |  | January 28, 2017 |  | January 23, 2016 |  | January 28, 2017 |  | January 23, 2016 |  | January 28, 2017 |  | January 23, 2016 |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 5,186 |  |  | $ | 5,503 |  |  | 61.1 | % |  | 61.3 | % |  | $ | 11,085 |  |  | $ | 11,494 |  |  | 62.3 | % |  | 61.1 | % |
| Service |  | 2,090 |  |  | 1,929 |  |  | 67.7 | % |  | 65.5 | % |  | 4,075 |  |  | 3,770 |  |  | 66.4 | % |  | 65.2 | % |
| Total |  | $ | 7,276 |  |  | $ | 7,432 |  |  | 62.8 | % |  | 62.3 | % |  | $ | 15,160 |  |  | $ | 15,264 |  |  | 63.3 | % |  | 62.0 | % |

[0000858877-17-000004:mdna:197]
[same as prior period, unchanged from 0000858877-16-000123:mdna:154]

[0000858877-17-000004:mdna:198]
The following table summarizes the key factors that contributed to the change in product gross margin percentage for the second quarter and first six months of fiscal 2017 as compared with the corresponding prior year periods:

[0000858877-17-000004:mdna:199]
|  |  | Product Gross Margin Percentage |
|  |  | Three Months Ended |  | Six Months Ended |
| Fiscal 2016 |  | 61.3 | % |  | 61.1 | % |
| Productivity (1) |  | 2.3 | % |  | 2.5 | % |
| SP Video CPE Business impact |  | 0.5 | % |  | 1.4 | % |
| Supplier component remediation charge/adjustment, net |  | 0.2 | % |  | 0.1 | % |
| Amortization of purchased intangible assets |  | 0.1 | % |  | 0.1 | % |
| Product pricing |  | (2.5 | )% |  | (1.8 | )% |
| Mix of products sold |  | (0.7 | )% |  | (1.1 | )% |
| Other |  | (0.1 | )% |  | — | % |
| Fiscal 2017 |  | 61.1 | % |  | 62.3 | % |

[0000858877-17-000004:mdna:200]
[same as prior period, unchanged from 0000858877-16-000123:mdna:157]

[0000858877-17-000004:mdna:201]
Three Months Ended January 28, 2017 Compared with Three Months Ended January 23, 2016

[0000858877-17-000004:mdna:202]
Product gross margin decreased by 0.2 percentage points as compared with the second quarter of fiscal 2016. The decrease in product gross margin was largely due to unfavorable impacts from product pricing, which were driven by typical market factors and impacted each of our geographic segments and customer markets. The decrease was also due to the impact of the unfavorable mix of products sold primarily from our NGN Routing and Service Provider Video products.

[0000858877-17-000004:mdna:203]
The various factors contributing to the product gross margin decrease were partially offset by productivity improvements and the sale during the second quarter of fiscal 2016 of our lower margin SP Video CPE Business. Productivity improvements were driven by value engineering efforts; favorable component pricing; and continued operational efficiency in manufacturing operations. Productivity improvements were adversely impacted by an increase in the cost of certain memory components which are currently constrained.  Value engineering is the process by which production costs are reduced through component redesign, board configuration, test processes, and transformation processes. Product gross margin was also impacted by the supplier component remediation adjustment and charge which consisted of a $141 million adjustment, partially offset by a $125 million charge. See Note 12 to the Consolidated Financial Statements.

[0000858877-17-000004:mdna:204]
[same as prior period, unchanged from 0000858877-16-000123:mdna:207]

[0000858877-17-000004:mdna:205]
[same as prior period, unchanged from 0000858877-16-000123:mdna:208]

[0000858877-17-000004:mdna:206]
Six Months Ended January 28, 2017 Compared with Six Months Ended January 23, 2016

[0000858877-17-000004:mdna:207]
Product gross margin increased by 1.2 percentage points as compared with the first six months of fiscal 2016. The increase was due to productivity improvements driven by similar factors as discussed in the three-month period immediately above.  Additionally, gross margin increased due to the sale during the second quarter of fiscal 2016 of our lower margin SP Video CPE Business. These factors were partially offset by unfavorable impacts from product pricing and unfavorable mix of products sold. The unfavorable product mix impact was driven by negative mix impacts from NGN Routing products, Service Provider Video products and Cisco Unified Computing System products.

[0000858877-17-000004:mdna:208]
[same as prior period, unchanged from 0000858877-16-000123:mdna:160]

[0000858877-17-000004:mdna:209]
Three Months Ended January 28, 2017 Compared with Three Months Ended January 23, 2016

[0000858877-17-000004:mdna:210]
Our service gross margin percentage increased by 2.2 percentage points as compared with the second quarter of fiscal 2016, due to higher sales volume and decreased delivery costs, partially offset by increased headcount-related costs.

[0000858877-17-000004:mdna:211]
[same as prior period, unchanged from 0000858877-16-000123:mdna:163]

[0000858877-17-000004:mdna:212]
Six Months Ended January 28, 2017 Compared with Six Months Ended January 23, 2016

[0000858877-17-000004:mdna:213]
Service gross margin percentage increased by 1.2 percentage points as compared with the first six months of fiscal 2016, due to higher sales volume, favorable mix and, to a lesser extent, lower share-based compensation expense. These benefits to service gross margin were partially offset by higher headcount-related costs.

[0000858877-17-000004:mdna:214]
[same as prior period, unchanged from 0000858877-16-000123:mdna:167]

[0000858877-17-000004:mdna:215]
[same as prior period, unchanged from 0000858877-16-000123:mdna:168]

[0000858877-17-000004:mdna:216]
|  | Three Months Ended |  | Six Months Ended |
|  | AMOUNT |  | PERCENTAGE |  | AMOUNT |  | PERCENTAGE |
|  | January 28, 2017 |  | January 23, 2016 |  | January 28, 2017 |  | January 23, 2016 |  | January 28, 2017 |  | January 23, 2016 |  | January 28, 2017 |  | January 23, 2016 |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 4,288 |  |  | $ | 4,411 |  |  | 64.4 | % |  | 63.8 | % |  | $ | 9,121 |  |  | $ | 9,354 |  |  | 64.7 | % |  | 63.6 | % |
| EMEA | 2,012 |  |  | 2,011 |  |  | 65.6 | % |  | 65.0 | % |  | 4,025 |  |  | 4,000 |  |  | 66.2 | % |  | 64.7 | % |
| APJC | 1,121 |  |  | 1,184 |  |  | 60.4 | % |  | 61.6 | % |  | 2,325 |  |  | 2,262 |  |  | 62.0 | % |  | 60.8 | % |
| Segment total | 7,421 |  |  | 7,606 |  |  | 64.1 | % |  | 63.8 | % |  | 15,471 |  |  | 15,616 |  |  | 64.6 | % |  | 63.5 | % |
| Unallocated corporate items (1) | (145 | ) |  | (174 | ) |  |  |  |  |  | (311 | ) |  | (352 | ) |  |  |  |  |
| Total | $ | 7,276 |  |  | $ | 7,432 |  |  | 62.8 | % |  | 62.3 | % |  | $ | 15,160 |  |  | $ | 15,264 |  |  | 63.3 | % |  | 62.0 | % |

[0000858877-17-000004:mdna:217]
(1) The unallocated corporate items include the effects of amortization and impairments of acquisition-related intangible assets, share-based compensation expense, significant litigation and other contingencies, charges related to asset impairments and restructurings, and certain other charges. We do not allocate these items to the gross margin for each segment because management does not include such information in measuring the performance of the operating segments.

[0000858877-17-000004:mdna:218]
[same as prior period, unchanged from 0000858877-16-000123:mdna:267]

[0000858877-17-000004:mdna:219]
[same as prior period, unchanged from 0000858877-16-000123:mdna:222]

[0000858877-17-000004:mdna:220]
[same as prior period, unchanged from 0000858877-16-000123:mdna:223]

[0000858877-17-000004:mdna:221]
Three Months Ended January 28, 2017 Compared with Three Months Ended January 23, 2016

[0000858877-17-000004:mdna:222]
The Americas segment experienced a gross margin percentage increase due to productivity improvements and, to a lesser extent, the sale of the lower margin SP Video CPE Business.  Partially offsetting these favorable impacts to gross margin were negative impacts from pricing and an unfavorable product mix. The unfavorable mix of products sold was driven by an unfavorable mix within our NGN Routing products.

[0000858877-17-000004:mdna:223]
The gross margin percentage increase in our EMEA segment was due primarily to higher service gross margin. Product gross margin in this segment declined due to negative impacts from pricing partially offset by the impact of productivity improvements and the sale of the lower margin SP Video CPE Business.

[0000858877-17-000004:mdna:224]
Our APJC segment gross margin percentage decreased primarily due to unfavorable impacts from pricing and unfavorable product mix, partially offset by productivity improvements. The mix impact was driven  by an unfavorable mix of products sold primarily from our Service Provider Video products and Cisco Unified Computing System products. We experienced a higher service gross margin in this segment.

[0000858877-17-000004:mdna:225]
[same as prior period, unchanged from 0000858877-16-000123:mdna:175]

[0000858877-17-000004:mdna:226]
Six Months Ended January 28, 2017 Compared with Six Months Ended January 23, 2016

[0000858877-17-000004:mdna:227]
We experienced a gross margin percentage increase in our Americas segment due to productivity improvements and the sale of the lower margin SP Video CPE Business, partially offset by unfavorable impacts from pricing and mix. The unfavorable mix impact in this geographic segment was driven by unfavorable mix from our NGN Routing, Switching and Service Provider Video products.

[0000858877-17-000004:mdna:228]
The gross margin percentage increase in our EMEA segment was due primarily to the impact of productivity improvements in this geographic segment and the sale of the lower margin SP Video CPE Business. Partially offsetting these favorable impacts to gross margin were negative impacts from pricing and, to a lesser extent, an unfavorable product mix. Higher service gross margin also contributed to the increase in the overall gross margin in this segment.

[0000858877-17-000004:mdna:229]
The APJC segment gross margin percentage increased due primarily to higher service gross margin. Product gross margin in this segment also increased due to productivity improvements partially offset by unfavorable impacts from mix and pricing. The unfavorable mix impact was driven by our Service Provider Video products and our Cisco Unified Computing System products.

[0000858877-17-000004:mdna:230]
[same as prior period, unchanged from 0000858877-16-000123:mdna:179]

[0000858877-17-000004:mdna:231]
[same as prior period, unchanged from 0000858877-16-000123:mdna:180]

[0000858877-17-000004:mdna:232]
|  | Three Months Ended |  | Six Months Ended |
|  | January 28, 2017 |  | January 23, 2016 |  | Variancein Dollars |  | Variance in Percent |  | January 28, 2017 |  | January 23, 2016 |  | Variancein Dollars |  | Variance in Percent |
| Research and development | $ | 1,508 |  |  | $ | 1,509 |  |  | $ | (1 | ) |  | (0.1 | )% |  | $ | 3,053 |  |  | $ | 3,069 |  |  | $ | (16 | ) |  | (0.5 | )% |
| Percentage of revenue | 13.0 | % |  | 12.7 | % |  |  |  |  |  | 12.8 | % |  | 12.5 | % |  |  |  |  |
| Sales and marketing | 2,222 |  |  | 2,286 |  |  | (64 | ) |  | (2.8 | )% |  | 4,640 |  |  | 4,729 |  |  | (89 | ) |  | (1.9 | )% |
| Percentage of revenue | 19.2 | % |  | 19.2 | % |  |  |  |  |  | 19.4 | % |  | 19.2 | % |  |  |  |  |
| General and administrative | 456 |  |  | 176 |  |  | 280 |  |  | 159.1 | % |  | 1,011 |  |  | 715 |  |  | 296 |  |  | 41.4 | % |
| Percentage of revenue | 3.9 | % |  | 1.5 | % |  |  |  |  |  | 4.2 | % |  | 2.9 | % |  |  |  |  |
| Total | $ | 4,186 |  |  | $ | 3,971 |  |  | $ | 215 |  |  | 5.4 | % |  | $ | 8,704 |  |  | $ | 8,513 |  |  | $ | 191 |  |  | 2.2 | % |
| Percentage of revenue | 36.1 | % |  | 33.3 | % |  |  |  |  |  | 36.4 | % |  | 34.6 | % |  |  |  |  |

[0000858877-17-000004:mdna:233]
[same as prior period, unchanged from 0000858877-16-000123:mdna:182]

[0000858877-17-000004:mdna:234]
R&D expenses decreased for the second quarter and first six months of fiscal 2017, as compared with the corresponding periods of fiscal 2016, primarily due to lower contracted services, lower discretionary spending and lower acquisition-related costs, partially offset by higher headcount-related expenses and higher share-based compensation expense.

[0000858877-17-000004:mdna:235]
63

[0000858877-17-000004:mdna:236]
[same as prior period, unchanged from 0000858877-16-000123:mdna:228]

[0000858877-17-000004:mdna:237]
[same as prior period, unchanged from 0000858877-16-000123:mdna:229]

[0000858877-17-000004:mdna:238]
[same as prior period, unchanged from 0000858877-16-000123:mdna:184]

[0000858877-17-000004:mdna:239]
[same as prior period, unchanged from 0000858877-16-000123:mdna:185]

[0000858877-17-000004:mdna:240]
Sales and marketing expenses decreased for the second quarter and first six months of fiscal 2017, compared with the corresponding periods of fiscal 2016, due to lower headcount-related expenses, lower contracted services, lower discretionary spending and lower acquisition-related costs. Lower headcount related expenses were due to efficiencies related to our restructuring actions.

[0000858877-17-000004:mdna:241]
[same as prior period, unchanged from 0000858877-16-000123:mdna:187]

[0000858877-17-000004:mdna:242]
G&A expenses increased in the second quarter and first six months of fiscal 2017, as compared with the corresponding periods of fiscal 2016, primarily due to the $286 million pre-tax gain from the sale of our SP Video CPE Business recorded in the second quarter of fiscal 2016.

[0000858877-17-000004:mdna:243]
[same as prior period, unchanged from 0000858877-16-000123:mdna:189]

[0000858877-17-000004:mdna:244]
In the second quarter of fiscal 2017, foreign currency fluctuations, net of hedging, decreased the combined R&D, sales and marketing, and G&A expenses by approximately $27 million, or approximately 0.7%, compared with the second quarter of fiscal 2016.

[0000858877-17-000004:mdna:245]
In the first six months of fiscal 2017, foreign currency fluctuations, net of hedging, decreased the combined R&D, sales and marketing, and G&A expenses by approximately $60 million, or approximately 0.7%, compared with the first six months of fiscal 2016.

[0000858877-17-000004:mdna:246]
[same as prior period, unchanged from 0000858877-16-000123:mdna:191]

[0000858877-17-000004:mdna:247]
Our headcount as of January 28, 2017 was 71,959, which represents a decrease of 426 employees in the second quarter of fiscal 2017  and a decrease of 1,752 employees in the first six months of fiscal 2017, each as compared with the total headcount at the end of fiscal 2016. The decrease was driven by our fiscal 2017 restructuring actions that began in the first quarter, partially offset by additional headcount primarily from our investments in key growth areas.

[0000858877-17-000004:mdna:248]
[same as prior period, unchanged from 0000858877-16-000123:mdna:195]

[0000858877-17-000004:mdna:249]
[same as prior period, unchanged from 0000858877-16-000123:mdna:196]

[0000858877-17-000004:mdna:250]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 28, 2017 |  | January 23, 2016 |  | January 28, 2017 |  | January 23, 2016 |
| Cost of sales—product |  | $ | 19 |  |  | $ | 16 |  |  | $ | 40 |  |  | $ | 29 |  |
| Cost of sales—service |  | 34 |  |  | 35 |  |  | 67 |  |  | 73 |  |
| Share-based compensation expense in cost of sales |  | 53 |  |  | 51 |  |  | 107 |  |  | 102 |  |
| Research and development |  | 129 |  |  | 107 |  |  | 255 |  |  | 221 |  |
| Sales and marketing |  | 125 |  |  | 126 |  |  | 265 |  |  | 265 |  |
| General and administrative |  | 45 |  |  | 47 |  |  | 94 |  |  | 104 |  |
| Restructuring and other charges |  | — |  |  | (1 | ) |  | 3 |  |  | 14 |  |
| Share-based compensation expense in operating expenses |  | 299 |  |  | 279 |  |  | 617 |  |  | 604 |  |
| Total share-based compensation expense |  | $ | 352 |  |  | $ | 330 |  |  | $ | 724 |  |  | $ | 706 |  |

[0000858877-17-000004:mdna:251]
The increase in share-based compensation expense in the second quarter and first six months of fiscal 2017, as compared with the corresponding periods of fiscal 2016, was due primarily to higher expense related to equity awards assumed with respect to our recent acquisitions.

[0000858877-17-000004:mdna:252]
64

[0000858877-17-000004:mdna:253]
[same as prior period, unchanged from 0000858877-16-000123:mdna:243]

[0000858877-17-000004:mdna:254]
[same as prior period, unchanged from 0000858877-16-000123:mdna:244]

[0000858877-17-000004:mdna:255]
[same as prior period, unchanged from 0000858877-16-000123:mdna:199]

[0000858877-17-000004:mdna:256]
[same as prior period, unchanged from 0000858877-16-000123:mdna:200]

[0000858877-17-000004:mdna:257]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 28, 2017 |  | January 23, 2016 |  | January 28, 2017 |  | January 23, 2016 |
| Amortization of purchased intangible assets: |  |  |  |  |  |  |  |  |
| Cost of sales |  | $ | 124 |  |  | $ | 139 |  |  | $ | 253 |  |  | $ | 285 |  |
| Operating expenses: |  |  |  |  |  |  |  |  |
| Amortization of purchased intangible assets |  | 64 |  |  | 71 |  |  | 142 |  |  | 140 |  |
| Restructuring and other charges |  | — |  |  | — |  |  | 38 |  |  | — |  |
| Total |  | $ | 188 |  |  | $ | 210 |  |  | $ | 433 |  |  | $ | 425 |  |

[0000858877-17-000004:mdna:258]
Amortization of purchased intangible assets decreased for the second quarter of fiscal 2017, as compared with the second quarter of fiscal 2016, due to certain purchased intangible assets having become fully amortized or impaired, partially offset by amortization of purchased intangible assets from our recent acquisitions.

[0000858877-17-000004:mdna:259]
Amortization of purchased intangible assets increased for the first six months of fiscal 2017, as compared with the first six months of fiscal 2016, due to higher impairment charges and amortization of purchased intangible assets from our recent acquisitions, partially offset by certain purchased intangible assets having become fully amortized or impaired.

[0000858877-17-000004:mdna:260]
[same as prior period, unchanged from 0000858877-16-000123:mdna:203]

[0000858877-17-000004:mdna:261]
In the second quarter and first six months of fiscal 2017, we incurred restructuring and other charges of approximately $133 million and $544 million, respectively, which were related primarily to employee severance charges for employees impacted by the restructuring action announced in August 2016. Our aggregate pretax estimated charges pursuant to the restructuring action are expected to be approximately $700 million, and we expect the restructuring action to be substantially completed by the end of fiscal 2017. We expect to reinvest substantially all of the cost savings from the restructuring action in our key priority areas such as security, IoT, collaboration, next generation data center and cloud.  As a result, the overall cost savings from the restructuring action are not expected to be material for future periods.

[0000858877-17-000004:mdna:262]
In the second quarter and first six months of fiscal 2016, we incurred restructuring and other charges of approximately $95 million net of a $1 million credit to cost of sales and $236 million net of a $2 million credit to cost of sales, respectively.  These charges were related primarily to employee severance charges for employees impacted by the restructuring action announced in August 2014. We completed this restructuring action in fiscal 2016.

[0000858877-17-000004:mdna:263]
[same as prior period, unchanged from 0000858877-16-000123:mdna:209]

[0000858877-17-000004:mdna:264]
[same as prior period, unchanged from 0000858877-16-000123:mdna:210]

[0000858877-17-000004:mdna:265]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 28, 2017 |  | January 23, 2016 |  | January 28, 2017 |  | January 23, 2016 |
| Operating income |  | $ | 2,893 |  |  | $ | 3,294 |  |  | $ | 5,770 |  |  | $ | 6,373 |  |
| Operating income as a percentage of revenue |  | 25.0 | % |  | 27.6 | % |  | 24.1 | % |  | 25.9 | % |

[0000858877-17-000004:mdna:266]
For the second quarter and first six months of fiscal 2017, as compared with the corresponding periods of fiscal 2016, operating income decreased by 12% and 9%, respectively, and as a percentage of revenue operating income decreased by 2.6 percentage points and 1.8 percentage points, respectively. These decreases resulted from the $286 million pre-tax gain from the sale of our SP Video CPE Business recorded in the second quarter of fiscal 2016 and an increase in restructuring and other charges related to the restructuring action announced in August 2016.

[0000858877-17-000004:mdna:267]
[same as prior period, unchanged from 0000858877-16-000123:mdna:257]

[0000858877-17-000004:mdna:268]
[same as prior period, unchanged from 0000858877-16-000123:mdna:258]

[0000858877-17-000004:mdna:269]
[same as prior period, unchanged from 0000858877-16-000123:mdna:213]

[0000858877-17-000004:mdna:270]
[same as prior period, unchanged from 0000858877-16-000123:mdna:214]

[0000858877-17-000004:mdna:271]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 28, 2017 |  | January 23, 2016 |  | Variancein Dollars |  | January 28, 2017 |  | January 23, 2016 |  | Variancein Dollars |
| Interest income |  | $ | 329 |  |  | $ | 237 |  |  | $ | 92 |  |  | $ | 624 |  |  | $ | 462 |  |  | $ | 162 |  |
| Interest expense |  | (222 | ) |  | (162 | ) |  | (60 | ) |  | (420 | ) |  | (321 | ) |  | (99 | ) |
| Interest income (expense), net |  | $ | 107 |  |  | $ | 75 |  |  | $ | 32 |  |  | $ | 204 |  |  | $ | 141 |  |  | $ | 63 |  |

[0000858877-17-000004:mdna:272]
For the second quarter and first six months of fiscal 2017, interest income increased compared with the corresponding periods of fiscal 2016, driven by an increase in our portfolio of cash, cash equivalents, and fixed income investments as well as higher yields on our portfolio.  Interest expense in the second quarter and first six months of fiscal 2017, as compared with the corresponding periods of fiscal 2016, was higher driven by higher average debt balances and the impact of higher effective interest rates on both floating-rate senior notes and interest rate swaps associated with fixed-rate senior notes.

[0000858877-17-000004:mdna:273]
[same as prior period, unchanged from 0000858877-16-000123:mdna:217]

[0000858877-17-000004:mdna:274]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 28, 2017 |  | January 23, 2016 |  | Variancein Dollars |  | January 28, 2017 |  | January 23, 2016 |  | Variancein Dollars |
| Gains (losses) on investments, net: |  |  |  |  |  |  |  |  |  |  |  |  |
| Publicly traded equity securities |  | $ | 4 |  |  | $ | 2 |  |  | $ | 2 |  |  | $ | 9 |  |  | $ | (7 | ) |  | $ | 16 |  |
| Fixed income securities |  | (34 | ) |  | (21 | ) |  | (13 | ) |  | (24 | ) |  | (13 | ) |  | (11 | ) |
| Total available-for-sale investments |  | (30 | ) |  | (19 | ) |  | (11 | ) |  | (15 | ) |  | (20 | ) |  | 5 |  |
| Privately held companies |  | (3 | ) |  | (36 | ) |  | 33 |  |  | (53 | ) |  | (47 | ) |  | (6 | ) |
| Net gains (losses) on investments |  | (33 | ) |  | (55 | ) |  | 22 |  |  | (68 | ) |  | (67 | ) |  | (1 | ) |
| Other gains (losses), net |  | (4 | ) |  | (8 | ) |  | 4 |  |  | 10 |  |  | (4 | ) |  | 14 |  |
| Other income (loss), net |  | $ | (37 | ) |  | $ | (63 | ) |  | $ | 26 |  |  | $ | (58 | ) |  | $ | (71 | ) |  | $ | 13 |  |

[0000858877-17-000004:mdna:275]
Three Months Ended January 28, 2017 Compared with Three Months Ended January 23, 2016

[0000858877-17-000004:mdna:276]
The change in total net gains (losses) on available-for-sale investments in the second quarter of fiscal 2017, as compared with the second quarter of fiscal 2016, was primarily attributable to higher realized losses on fixed income securities in the current period as a result of market conditions and the timing of sales of these securities.

[0000858877-17-000004:mdna:277]
The change in net gains (losses) on investments in privately held companies for the second quarter of fiscal 2017, as compared with the second quarter of fiscal 2016, was primarily due to higher realized gains on investments in privately held companies partially offset by higher impairment charges on investments in privately held companies.

[0000858877-17-000004:mdna:278]
The change in other gains (losses), net in the second quarter of fiscal 2017, as compared with the second quarter of fiscal 2016, was driven by impacts from equity derivatives and lower donation expenses.

[0000858877-17-000004:mdna:279]
Six Months Ended January 28, 2017 Compared with Six Months Ended January 23, 2016

[0000858877-17-000004:mdna:280]
The change in total net gains (losses) on available-for-sale investments in the first six months of fiscal 2017, as compared with the first six months of fiscal 2016, was primarily attributable to higher realized gains on publicly traded equity securities, partially offset by higher realized losses on fixed income securities in the current period as a result of market conditions and the timing of sales of these securities.

[0000858877-17-000004:mdna:281]
The change in net gains (losses) on investments in privately held companies for the first six months of fiscal 2017, as compared with the first six months of fiscal 2016, was primarily due to higher impairment charges on investments in privately held companies, partially offset by higher realized gains on investments in privately held companies.

[0000858877-17-000004:mdna:282]
The change in other gains (losses), net in the first six months of fiscal 2017, as compared with the first six months of fiscal 2016, was driven by net favorable foreign exchange impacts and lower donation expenses partially offset by impacts from equity derivatives.

[0000858877-17-000004:mdna:283]
66

[0000858877-17-000004:mdna:284]
[same as prior period, unchanged from 0000858877-16-000123:mdna:268]

[0000858877-17-000004:mdna:285]
[same as prior period, unchanged from 0000858877-16-000123:mdna:269]

[0000858877-17-000004:mdna:286]
[same as prior period, unchanged from 0000858877-16-000123:mdna:224]

[0000858877-17-000004:mdna:287]
[same as prior period, unchanged from 0000858877-16-000123:mdna:225]

[0000858877-17-000004:mdna:288]
The provision for income taxes resulted in an effective tax rate of 20.8% for the second quarter of fiscal 2017 compared with 4.8% for the second quarter of fiscal 2016, a net 16.0 percentage point increase in the effective tax rate for the second quarter of fiscal 2017 as compared with the second quarter of fiscal 2016. The provision for income taxes resulted in an effective tax rate of 21.1% for the first six months of fiscal 2017 as compared with 13.4% for the first six months of fiscal 2016, a net 7.7 percentage point increase in the effective tax rate for the first six months of fiscal 2017 as compared with the first six months of fiscal 2016. The increase in the effective tax rates for both the second quarter and first six months of fiscal 2017 as compared with the second quarter and first six months of fiscal 2016 was primarily due to the recognition of a net benefit to the provision for income taxes in the second quarter of fiscal 2016 related to our settlement with the IRS of all outstanding items covering fiscal 2008 through fiscal 2010 and reinstatement of the U.S. federal research and development (“R&D”) tax credit on December 18, 2015.

[0000858877-17-000004:mdna:289]
67

[0000858877-17-000004:mdna:290]
[same as prior period, unchanged from 0000858877-16-000123:mdna:277]

[0000858877-17-000004:mdna:291]
[same as prior period, unchanged from 0000858877-16-000123:mdna:278]

[0000858877-17-000004:mdna:292]
[same as prior period, unchanged from 0000858877-16-000123:mdna:230]

[0000858877-17-000004:mdna:293]
[same as prior period, unchanged from 0000858877-16-000123:mdna:231]

[0000858877-17-000004:mdna:294]
[same as prior period, unchanged from 0000858877-16-000123:mdna:232]

[0000858877-17-000004:mdna:295]
[same as prior period, unchanged from 0000858877-16-000123:mdna:233]

[0000858877-17-000004:mdna:296]
|  | January 28, 2017 |  | July 30, 2016 |  | Increase (Decrease) |
| Cash and cash equivalents | $ | 10,898 |  |  | $ | 7,631 |  |  | $ | 3,267 |  |
| Fixed income securities | 59,333 |  |  | 56,621 |  |  | 2,712 |  |
| Publicly traded equity securities | 1,614 |  |  | 1,504 |  |  | 110 |  |
| Total | $ | 71,845 |  |  | $ | 65,756 |  |  | $ | 6,089 |  |

[0000858877-17-000004:mdna:297]
The net increase in cash and cash equivalents and investments in the first six months of fiscal 2017 was primarily driven by the cash provided by operating activities of $6.5 billion and an increase in debt of $6.5 billion. These sources of cash were partially offset by cash returned to shareholders in the form of cash dividends of $2.6 billion and repurchases of common stock of $2.0 billion under the stock repurchase program; the timing of settlements and change in fair value of investments of $1.4 billion; capital expenditures of $0.5 billion; and net cash paid for acquisitions of $0.3 billion.

[0000858877-17-000004:mdna:298]
Our total in cash and cash equivalents and investments held by various foreign subsidiaries was $62.3 billion and $59.8 billion as of January 28, 2017 and July 30, 2016, respectively. Under current tax laws and regulations, if these assets were to be distributed from the foreign subsidiaries to the United States in the form of dividends or otherwise, we would be subject to additional U.S. income taxes (subject to an adjustment for foreign tax credits) and foreign withholding taxes. The balance of cash and cash equivalents and investments available in the United States as of January 28, 2017 and July 30, 2016 was $9.6 billion and $5.9 billion, respectively.

[0000858877-17-000004:mdna:299]
In addition to cash requirements in the normal course of business, we expect to close the acquisition of AppDynamics for a purchase price of $3.7 billion and repay the $4.2 billion of senior notes maturing in the third quarter of fiscal 2017. See further discussion of liquidity under “Liquidity and Capital Resource Requirements” below.

[0000858877-17-000004:mdna:300]
[same as prior period, unchanged from 0000858877-16-000123:mdna:237]

[0000858877-17-000004:mdna:301]
[same as prior period, unchanged from 0000858877-16-000123:mdna:238]

[0000858877-17-000004:mdna:302]
[same as prior period, unchanged from 0000858877-16-000123:mdna:239]

[0000858877-17-000004:mdna:303]
|  | Six Months Ended |
|  | January 28, 2017 |  | January 23, 2016 |
| Net cash provided by operating activities | $ | 6,502 |  |  | $ | 6,688 |  |
| Acquisition of property and equipment | (526 | ) |  | (576 | ) |
| Free cash flow | $ | 5,976 |  |  | $ | 6,112 |  |

[0000858877-17-000004:mdna:304]
[same as prior period, unchanged from 0000858877-16-000123:mdna:241]

[0000858877-17-000004:mdna:305]
[same as prior period, unchanged from 0000858877-16-000123:mdna:290]

[0000858877-17-000004:mdna:306]
[same as prior period, unchanged from 0000858877-16-000123:mdna:291]

[0000858877-17-000004:mdna:307]
[same as prior period, unchanged from 0000858877-16-000123:mdna:245]

[0000858877-17-000004:mdna:308]
[same as prior period, unchanged from 0000858877-16-000123:mdna:246]

[0000858877-17-000004:mdna:309]
|  |  | DIVIDENDS |  | STOCK REPURCHASE PROGRAM |  |  |
| Quarter Ended |  | Per Share |  | Amount |  | Shares |  | Weighted-Average Price per Share |  | Amount |  | TOTAL |
| Fiscal 2017 |  |  |  |  |  |  |  |  |  |  |  |  |
| January 28, 2017 |  | $ | 0.26 |  |  | $ | 1,304 |  |  | 33 |  |  | $ | 30.33 |  |  | $ | 1,001 |  |  | $ | 2,305 |  |
| October 29, 2016 |  | $ | 0.26 |  |  | $ | 1,308 |  |  | 32 |  |  | $ | 31.12 |  |  | $ | 1,001 |  |  | $ | 2,309 |  |
| Fiscal 2016 |  |  |  |  |  |  |  |  |  |  |  |  |  |
| July 30, 2016 |  | $ | 0.26 |  |  | $ | 1,309 |  |  | 28 |  |  | $ | 28.70 |  |  | $ | 800 |  |  | $ | 2,109 |  |
| April 30, 2016 |  | $ | 0.26 |  |  | $ | 1,308 |  |  | 27 |  |  | $ | 24.08 |  |  | $ | 649 |  |  | $ | 1,957 |  |
| January 23, 2016 |  | $ | 0.21 |  |  | $ | 1,065 |  |  | 48 |  |  | $ | 26.12 |  |  | $ | 1,262 |  |  | $ | 2,327 |  |
| October 24, 2015 |  | $ | 0.21 |  |  | $ | 1,068 |  |  | 45 |  |  | $ | 26.83 |  |  | $ | 1,207 |  |  | $ | 2,275 |  |

[0000858877-17-000004:mdna:310]
On February 15, 2017, our Board of Directors declared a quarterly dividend of $0.29 per common share to be paid on April 26, 2017 to all shareholders of record as of the close of business on April 6, 2017.  Any future dividends are subject to the approval of our Board of Directors.

[0000858877-17-000004:mdna:311]
[same as prior period, unchanged from 0000858877-16-000123:mdna:249]

[0000858877-17-000004:mdna:312]
|  | January 28, 2017 |  | July 30, 2016 |  | Increase (Decrease) |
| Accounts receivable, net | $ | 4,458 |  |  | $ | 5,847 |  |  | $ | (1,389 | ) |

[0000858877-17-000004:mdna:313]
Our accounts receivable net, as of January 28, 2017 decreased by approximately 24%, as compared with the end of fiscal 2016, primarily due to product and service billings being more linear in the second quarter of fiscal 2017 compared with the fourth quarter of fiscal 2016.

[0000858877-17-000004:mdna:314]
[same as prior period, unchanged from 0000858877-16-000123:mdna:252]

[0000858877-17-000004:mdna:315]
|  | January 28, 2017 |  | July 30, 2016 |  | Increase (Decrease) |
| Inventories | $ | 1,264 |  |  | $ | 1,217 |  |  | $ | 47 |  |
| Annualized inventory turns | 14.1 |  |  | 14.6 |  |  | (0.5 | ) |
| Purchase commitments with contract manufacturers and suppliers | $ | 4,402 |  |  | $ | 3,896 |  |  | $ | 506 |  |

[0000858877-17-000004:mdna:316]
Inventory as of January 28, 2017 increased by 4% from our inventory balance at the end of fiscal 2016, and for the same period purchase commitments with contract manufacturers and suppliers increased by approximately 13%.  On a combined basis, inventories and purchase commitments with contract manufacturers and suppliers increased by 11% compared with the end of fiscal 2016. The increase in purchase commitments with contract manufacturers and suppliers was due to two factors.  Approximately half of the increase was to secure memory supply which is currently constrained.  The remainder of the increase relates to procuring key components for specific product areas.

[0000858877-17-000004:mdna:317]
We believe our inventory and purchase commitments levels are in line with our current demand forecasts.

[0000858877-17-000004:mdna:318]
CISCO SYSTEMS, INC.

[0000858877-17-000004:mdna:319]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-17-000004:mdna:320]
[same as prior period, unchanged from 0000858877-16-000123:mdna:255]

[0000858877-17-000004:mdna:321]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that allow them to procure inventory based upon criteria as defined by us or that establish the parameters defining our requirements and our commitment to securing manufacturing capacity. A significant portion of our reported purchase commitments arising from these agreements are firm, noncancelable, and unconditional commitments. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed. Our purchase commitments are for short-term product manufacturing requirements as well as for commitments to suppliers to secure manufacturing capacity.

[0000858877-17-000004:mdna:322]
[same as prior period, unchanged from 0000858877-16-000123:mdna:260]

[0000858877-17-000004:mdna:323]
[same as prior period, unchanged from 0000858877-16-000123:mdna:261]

[0000858877-17-000004:mdna:324]
Financing Receivables and Guarantees We measure our net balance sheet exposure position related to our financing receivables and financing guarantees by reducing the total of gross financing receivables and financing guarantees by the associated allowances for credit loss and deferred revenue. As of January 28, 2017, our net balance sheet exposure position related to financing receivables and financing guarantees was as follows (in millions):

[0000858877-17-000004:mdna:325]
|  | FINANCING RECEIVABLES |  | FINANCING GUARANTEES |  |  |
| January 28, 2017 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts and Other |  | Total |  | Channel Partner |  | End-User Customers |  | Total |  | TOTAL |
| Financing receivables and guarantees | $ | 3,158 |  |  | $ | 2,369 |  |  | $ | 4,165 |  |  | $ | 9,692 |  |  | $ | 318 |  |  | $ | 94 |  |  | $ | 412 |  |  | $ | 10,104 |  |
| Unearned income | (154 | ) |  | — |  |  | — |  |  | (154 | ) |  | — |  |  | — |  |  | — |  |  | (154 | ) |
| Allowance for credit loss | (225 | ) |  | (106 | ) |  | (47 | ) |  | (378 | ) |  | — |  |  | — |  |  | — |  |  | (378 | ) |
| Deferred revenue | (12 | ) |  | (15 | ) |  | (1,922 | ) |  | (1,949 | ) |  | (99 | ) |  | (63 | ) |  | (162 | ) |  | (2,111 | ) |
| Net balance sheet exposure | $ | 2,767 |  |  | $ | 2,248 |  |  | $ | 2,196 |  |  | $ | 7,211 |  |  | $ | 219 |  |  | $ | 31 |  |  | $ | 250 |  |  | $ | 7,461 |  |

[0000858877-17-000004:mdna:326]
Financing Receivables  Financing receivables less unearned income increased by 8% compared with the end of fiscal 2016. The change was due to a 24% increase in financed service contracts and other and an 11% increase in loan receivables partially offset by a 9% decrease in lease receivables. We provide financing to certain end-user customers and channel partners to enable sales of our products, services, and networking solutions. These financing arrangements include leases, financed service contracts, and loans. Arrangements related to leases are generally collateralized by a security interest in the underlying assets. Lease receivables include sales-type and direct-financing leases. We also provide certain qualified customers financing for long-term service contracts, which primarily relate to technical support services. Our loan financing arrangements may include not only financing the acquisition of our products and services but also providing additional funds for other costs associated with network installation and integration of our products and services. We expect to continue to expand the use of our financing programs in the near term.

[0000858877-17-000004:mdna:327]
[same as prior period, unchanged from 0000858877-16-000123:mdna:265]

[0000858877-17-000004:mdna:328]
The volume of channel partner financing was $13.2 billion and $13.4 billion for the first six months of fiscal 2017 and 2016, respectively. These financing arrangements facilitate the working capital requirements of the channel partners, and in some cases, we guarantee a portion of these arrangements. The balance of the channel partner financing subject to guarantees was $1.2 billion and $1.1 billion as of January 28, 2017 and July 30, 2016, respectively. We could be called upon to make payments under these

[0000858877-17-000004:mdna:329]
CISCO SYSTEMS, INC.

[0000858877-17-000004:mdna:330]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-17-000004:mdna:331]
guarantees in the event of nonpayment by the channel partners or end-user customers. Historically, our payments under these arrangements have been immaterial. Where we provide a guarantee, we defer the revenue associated with the channel partner and end-user financing arrangement in accordance with revenue recognition policies, or we record a liability for the fair value of the guarantees. In either case, the deferred revenue is recognized as revenue when the guarantee is removed.

[0000858877-17-000004:mdna:332]
[same as prior period, unchanged from 0000858877-16-000123:mdna:270]

[0000858877-17-000004:mdna:333]
[same as prior period, unchanged from 0000858877-16-000123:mdna:271]

[0000858877-17-000004:mdna:334]
[same as prior period, unchanged from 0000858877-16-000123:mdna:272]

[0000858877-17-000004:mdna:335]
|  | Maturity Date |  | January 28, 2017 |  | July 30, 2016 |
| Senior notes: |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |
| Three-month LIBOR plus 0.28% | March 3, 2017 |  | $ | 1,000 |  |  | $ | 1,000 |  |
| Three-month LIBOR plus 0.60% | February 21, 2018 |  | 1,000 |  |  | 1,000 |  |
| Three-month LIBOR plus 0.31% | June 15, 2018 |  | 900 |  |  | 900 |  |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | 500 |  |  | 500 |  |
| Three-month LIBOR plus 0.34% | September 20, 2019 | (1) | 500 |  |  | — |  |
| Fixed-rate notes: |  |  |  |  |  |
| 1.10% | March 3, 2017 |  | 2,400 |  |  | 2,400 |  |
| 3.15% | March 14, 2017 |  | 750 |  |  | 750 |  |
| 1.40% | February 28, 2018 |  | 1,250 |  |  | 1,250 |  |
| 1.65% | June 15, 2018 |  | 1,600 |  |  | 1,600 |  |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 2,000 |  |
| 1.60% | February 28, 2019 |  | 1,000 |  |  | 1,000 |  |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 1,750 |  |
| 1.40% | September 20, 2019 | (1) | 1,500 |  |  | — |  |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 2,500 |  |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 1,500 |  |
| 2.20% | February 28, 2021 |  | 2,500 |  |  | 2,500 |  |
| 2.90% | March 4, 2021 |  | 500 |  |  | 500 |  |
| 1.85% | September 20, 2021 | (1) | 2,000 |  |  | — |  |
| 3.00% | June 15, 2022 |  | 500 |  |  | 500 |  |
| 2.60% | February 28, 2023 |  | 500 |  |  | 500 |  |
| 2.20% | September 20, 2023 | (1) | 750 |  |  | — |  |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1,000 |  |
| 3.50% | June 15, 2025 |  | 500 |  |  | 500 |  |
| 2.95% | February 28, 2026 |  | 750 |  |  | 750 |  |
| 2.50% | September 20, 2026 | (1) | 1,500 |  |  | — |  |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 2,000 |  |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 2,000 |  |
| Total |  |  | $ | 34,650 |  |  | $ | 28,400 |  |

[0000858877-17-000004:mdna:336]
(1) In September 2016, we issued senior notes with an aggregate principal amount of $6.25 billion.

[0000858877-17-000004:mdna:337]
Interest is payable semiannually on each class of the senior fixed-rate notes, each of which is redeemable by us at any time, subject to a make-whole premium. Interest is payable quarterly on the floating-rate notes. We were in compliance with all debt covenants as of January 28, 2017.

[0000858877-17-000004:mdna:338]
71

[0000858877-17-000004:mdna:339]
CISCO SYSTEMS, INC.

[0000858877-17-000004:mdna:340]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-17-000004:mdna:341]
Other Debt  Other debt as of July 30, 2016 included secured borrowings associated with customer financing arrangements. The amount of borrowings outstanding under these arrangements was $1 million as of July 30, 2016.

[0000858877-17-000004:mdna:342]
Commercial Paper  We established a short-term debt financing program of up to $3.0 billion through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes.  We had $300 million and no commercial paper notes outstanding as of January 28, 2017 and July 30, 2016, respectively.

[0000858877-17-000004:mdna:343]
Credit Facility On May 15, 2015, we entered into a credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 15, 2020. Any advances under the credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (i) the highest of (a) the Federal Funds rate plus 0.50%, (b) Bank of America’s “prime rate” as announced from time to time, or (c) LIBOR, or a comparable or successor rate that is approved by the Administrative Agent (“Eurocurrency Rate”), for an interest period of one month plus 1.00%, or (ii) the Eurocurrency Rate, plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the Eurocurrency Rate be less than zero. The credit agreement requires that we comply with certain covenants, including that it maintains an interest coverage ratio as defined in the agreement.

[0000858877-17-000004:mdna:344]
We may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and/or extend the expiration date of the credit facility up to May 15, 2022. We were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under the credit facility.

[0000858877-17-000004:mdna:345]
[same as prior period, unchanged from 0000858877-16-000123:mdna:282]

[0000858877-17-000004:mdna:346]
|  | January 28, 2017 |  | July 30, 2016 |  | Increase (Decrease) |
| Service | $ | 10,525 |  |  | $ | 10,621 |  |  | $ | (96 | ) |
| Product: |  |  |  |  |  |  |
| Deferred revenue related to recurring software and subscription businesses | 3,997 |  |  | 3,308 |  |  | 689 |  |
| Deferred revenue related to two-tier distributors | 401 |  |  | 377 |  |  | 24 |  |
| Other product deferred revenue | 2,163 |  |  | 2,166 |  |  | (3 | ) |
| Total product deferred revenue | 6,561 |  |  | 5,851 |  |  | 710 |  |
| Total | $ | 17,086 |  |  | $ | 16,472 |  |  | $ | 614 |  |
| Reported as: |  |  |  |  |  |
| Current | $ | 10,243 |  |  | $ | 10,155 |  |  | $ | 88 |  |
| Noncurrent | 6,843 |  |  | 6,317 |  |  | 526 |  |
| Total | $ | 17,086 |  |  | $ | 16,472 |  |  | $ | 614 |  |

[0000858877-17-000004:mdna:347]
Deferred product revenue increased 12% primarily due to increased deferrals related to recurring software and subscription businesses and, to a lesser extent, higher deferred revenue related to two-tier distributors. The portion of product deferred revenue related to recurring software and subscription businesses grew 51% on a year-over-year basis to $4.0 billion as of January 28, 2017. Collaboration, Security, and Wireless were the key product category contributors of this product deferred revenue growth during the period. The 1% decrease in deferred service revenue was driven by the timing of multiyear arrangements and the impact of ongoing amortization of deferred service revenue.

[0000858877-17-000004:mdna:348]
CISCO SYSTEMS, INC.

[0000858877-17-000004:mdna:349]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-17-000004:mdna:350]
[same as prior period, unchanged from 0000858877-16-000123:mdna:285]

[0000858877-17-000004:mdna:351]
[same as prior period, unchanged from 0000858877-16-000123:mdna:286]

[0000858877-17-000004:mdna:352]
We lease office space in many U.S. locations. Outside the United States, larger leased sites include sites in Belgium, Canada, China, France, Germany, India, Israel, Japan, Poland and the United Kingdom. We also lease equipment and vehicles. The future minimum lease payments under all of our noncancelable operating leases with an initial term in excess of one year as of January 28, 2017 were $1.2 billion.

[0000858877-17-000004:mdna:353]
[same as prior period, unchanged from 0000858877-16-000123:mdna:288]

[0000858877-17-000004:mdna:354]
[same as prior period, unchanged from 0000858877-16-000123:mdna:289]

[0000858877-17-000004:mdna:355]
[same as prior period, unchanged from 0000858877-16-000123:mdna:292]

[0000858877-17-000004:mdna:356]
During the first quarter of fiscal 2014, we exercised our call option and entered into an agreement to purchase the remaining interests in Insieme. The acquisition closed in the second quarter of fiscal 2014, at which time the former noncontrolling interest holders became eligible to receive up to two milestone payments, which will be determined using agreed-upon formulas based primarily on revenue for certain of Insieme’s products. During the six months ended January 28, 2017 and January 23, 2016, we recorded compensation expense of $32 million and $101 million, respectively, related to the fair value of the vested portion of amounts that were earned or are expected to be earned by the former noncontrolling interest holders. Continued vesting will result in additional compensation expense in future periods. Based on the terms of the agreement, we have determined that the maximum amount that could be recorded as compensation expense by us is approximately $831 million (which includes the $815 million that has been expensed to date), net of forfeitures. The former noncontrolling interest holders earned the maximum amount related to these two milestone payments and were paid approximately $422 million and $354 million during the first six months of fiscal 2017 and fiscal 2016, respectively.  As of January 28, 2017, we paid a total of approximately $811 million pursuant to these two milestone payments.

[0000858877-17-000004:mdna:357]
[same as prior period, unchanged from 0000858877-16-000123:mdna:294]

[0000858877-17-000004:mdna:358]
[same as prior period, unchanged from 0000858877-16-000123:mdna:295]

[0000858877-17-000004:mdna:359]
We also have certain funding commitments primarily related to these variable interest entities, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $182 million as of January 28, 2017.

[0000858877-17-000004:mdna:360]
[same as prior period, unchanged from 0000858877-16-000123:mdna:297]

[0000858877-17-000004:mdna:361]
[same as prior period, unchanged from 0000858877-16-000123:mdna:298]

[0000858877-17-000004:mdna:362]
73

[0000858877-17-000004:mdna:363]
CISCO SYSTEMS, INC.

[0000858877-17-000004:mdna:364]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-17-000004:mdna:365]
[same as prior period, unchanged from 0000858877-16-000123:mdna:299]

[0000858877-17-000004:mdna:366]
We periodically engage in securities lending activities with certain of our available for sale investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. The average daily balance of securities lending for the six months ended January 28, 2017 and January 23, 2016 was $1.5 billion and $0.6 billion, respectively. We require collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. We engage in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify us against collateral losses. As of January 28, 2017 and July 30, 2016, we had no outstanding securities lending transactions. We believe these arrangements do not present a material risk or impact to our liquidity requirements.

[0000858877-17-000004:mdna:367]
[same as prior period, unchanged from 0000858877-16-000123:mdna:301]

[0000858877-17-000004:mdna:368]
Based on past performance and current expectations, we believe our cash and cash equivalents, investments, cash generated from operations, and ability to access capital markets and committed credit lines will satisfy, through at least the next 12 months, our liquidity requirements, both in total and domestically, including the following: working capital needs, capital expenditures, investment requirements, stock repurchases, cash dividends, contractual obligations, commitments, principal and interest payments on debt, pending acquisitions, future customer financings, and other liquidity requirements associated with our operations. There are no other transactions, arrangements, or relationships with unconsolidated entities or other persons that are reasonably likely to materially affect the liquidity and the availability of, as well as our requirements for, capital resources.
