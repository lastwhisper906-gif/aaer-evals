# CSCO 8-K — 0001193125-16-457586 filed 2016-02-10

## item codes, every 8-K on or before 2016-02-18

- 2016-02-10 0001193125-16-457586 — 2.02
- 2016-01-28 0001193125-16-441933 — 5.02
- 2015-12-08 0001193125-15-397797 — 8.01
- 2015-11-20 0001193125-15-383743 — 5.07
- 2015-11-12 0001193125-15-375655 — 2.02
- 2015-09-21 0001193125-15-324465 — 8.01
- 2015-09-17 0001193125-15-322456 — 8.01
- 2015-09-14 0001193125-15-319489 — 8.01
- 2015-08-28 0001193125-15-306843 — 8.01
- 2015-08-12 0001193125-15-288099 — 2.02
- 2015-07-29 0001193125-15-268359 — 5.02 — amendment of 0001193125-15-169227
- 2015-06-18 0001193125-15-227387 — 8.01, 9.01
- 2015-06-12 0001193125-15-221863 — 1.01, 9.01
- 2015-06-10 0001193125-15-218734 — 8.01, 9.01
- 2015-06-01 0001193125-15-209142 — 5.02, 9.01
- 2015-05-13 0001193125-15-185905 — 2.02
- 2015-05-04 0001193125-15-169227 — 5.02
- 2015-03-24 0001193125-15-103369 — 8.01
- 2015-03-19 0001193125-15-098638 — 8.01
- 2015-02-11 0001193125-15-044175 — 2.02
- 2014-12-19 0001193125-14-448754 — 8.01
- 2014-12-18 0001193125-14-447039 — 8.01
- 2014-11-24 0001193125-14-423591 — 5.02, 5.07, 9.01
- 2014-11-14 0001193125-14-413384 — 5.02
- 2014-11-12 0001193125-14-409258 — 2.02
- 2014-09-25 0001193125-14-353210 — 8.01
- 2014-09-12 0001193125-14-340480 — 5.02
- 2014-08-14 0001193125-14-308733 — 2.05
- 2014-08-13 0001193125-14-308403 — 2.02
- 2014-07-31 0001193125-14-289683 — 5.02
- 2014-06-25 0001193125-14-249157 — 8.01
- 2014-05-14 0001193125-14-199056 — 2.02
- 2014-03-26 0001193125-14-116588 — 8.01
- 2014-03-11 0001193125-14-093805 — 8.01
- 2014-03-03 0001193125-14-079163 — 1.01, 8.01, 9.01
- 2014-02-26 0001193125-14-069912 — 1.01, 9.01
- 2014-02-12 0001193125-14-048150 — 2.02
- 2013-12-23 0001193125-13-483099 — 8.01
- 2013-12-04 0001193125-13-462216 — 8.01
- 2013-11-20 0001193125-13-448477 — 5.02, 5.07, 9.01
- 2013-11-13 0001193125-13-440194 — 2.02
- 2013-08-15 0001193125-13-335218 — 2.05
- 2013-08-14 0001193125-13-334648 — 2.02
- 2013-07-23 0001193125-13-298129 — 8.01, 9.01
- 2013-06-24 0001193125-13-269064 — 8.01
- 2013-06-12 0001193125-13-256194 — 8.01
- 2013-06-07 0001193125-13-250920 — 8.01
- 2013-05-15 0001193125-13-222377 — 2.02
- 2013-03-26 0001193125-13-127015 — 8.01
- 2013-02-13 0001193125-13-055377 — 2.02
- 2013-02-01 0001193125-13-034682 — 5.02
- 2013-01-08 0001193125-13-006886 — 5.02, 9.01
- 2012-12-21 0001193125-12-513130 — 8.01
- 2012-12-19 0001193125-12-508424 — 8.01
- 2012-11-16 0001193125-12-474089 — 5.02, 5.07, 9.01
- 2012-11-13 0001193125-12-467422 — 2.02
- 2012-10-04 0001193125-12-415386 — 5.02, 5.03, 9.01
- 2012-09-19 0001193125-12-396875 — 5.02, 8.01
- 2012-08-15 0001193125-12-357479 — 2.02
- 2012-08-02 0001193125-12-332045 — 5.02
- 2012-06-27 0001193125-12-285742 — 8.01
- 2012-06-13 0001193125-12-269642 — 8.01
- 2012-05-09 0001193125-12-222045 — 2.02
- 2012-03-27 0001193125-12-134384 — 8.01
- 2012-03-15 0001193125-12-117538 — 8.01, 9.01
- 2012-02-17 0001193125-12-067542 — 1.01, 1.02, 2.03, 9.01
- 2012-02-08 0001193125-12-046545 — 2.02
- 2011-12-16 0001193125-11-343995 — 8.01
- 2011-12-08 0001193125-11-335127 — 5.02, 5.07, 9.01
- 2011-11-09 0001193125-11-304587 — 2.02
- 2011-09-29 0001193125-11-260065 — 8.01
- 2011-09-20 0001193125-11-252379 — 5.02, 9.01
- 2011-08-24 0001193125-11-231015 — 8.01
- 2011-08-10 0001193125-11-218133 — 2.02
- 2011-07-18 0001193125-11-190246 — 2.05
- 2011-06-22 0001193125-11-170849 — 8.01
- 2011-05-11 0001193125-11-135913 — 2.02
- 2011-03-28 0001193125-11-079927 — 8.01
- 2011-03-22 0001193125-11-073802 — 5.02 — amendment of 0001193125-11-043592
- 2011-03-18 0001193125-11-071279 — 8.01, 9.01
- 2011-03-16 0001193125-11-067985 — 1.01, 5.02, 8.01, 9.01
- 2011-03-15 0001193125-11-067331 — 1.01, 9.01
- 2011-03-09 0001193125-11-060123 — 8.01, 9.01
- 2011-02-23 0001193125-11-043592 — 5.02
- 2011-02-09 0001193125-11-028987 — 2.02
- 2011-01-31 0001193125-11-019101 — 1.01, 2.03
- 2010-12-17 0001193125-10-283392 — 8.01
- 2010-11-19 0001193125-10-265377 — 5.07
- 2010-11-10 0001193125-10-256001 — 2.02
- 2010-09-22 0001193125-10-214707 — 8.01
- 2010-09-16 0001193125-10-211456 — 7.01
- 2010-08-11 0001193125-10-186042 — 2.02
- 2010-06-29 0001193125-10-149956 — 8.01
- 2010-05-12 0001193125-10-117509 — 2.02
- 2010-02-17 0001193125-10-033290 — 5.02, 8.01, 9.01
- 2010-02-03 0001193125-10-020775 — 2.02
- 2009-11-25 0001193125-09-242589 — 8.01
- 2009-11-17 0001193125-09-236335 — 1.01, 8.01, 9.01
- 2009-11-13 0001193125-09-234405 — 1.01, 2.03, 9.01
- 2009-11-13 0001193125-09-234397 — 5.02 — amendment of 0001193125-09-189511
- 2009-11-12 0001193125-09-232971 — 5.02, 7.01, 9.01
- 2009-11-09 0001193125-09-228541 — 8.01, 9.01
- 2009-11-04 0001193125-09-223763 — 2.02
- 2009-10-14 0001193125-09-207912 — 8.01, 9.01
- 2009-10-05 0001193125-09-203556 — 8.01
- 2009-09-10 0001193125-09-189511 — 5.02
- 2009-09-04 0001193125-09-187835 — 5.02
- 2009-08-05 0001193125-09-165404 — 2.02
- 2009-07-27 0001193125-09-155861 — 5.02
- 2009-05-29 0001193125-09-121672 — 8.01
- 2009-05-06 0001193125-09-101570 — 2.02
- 2009-02-26 0001193125-09-038162 — 5.02
- 2009-02-17 0001193125-09-030546 — 1.01, 8.01, 9.01
- 2009-02-13 0001193125-09-029295 — 1.01, 2.03, 9.01
- 2009-02-04 0001193125-09-018793 — 2.02
- 2008-11-05 0001193125-08-225857 — 2.02
- 2008-09-11 0001193125-08-194695 — 7.01
- 2008-08-05 0001193125-08-166496 — 2.02
- 2008-06-20 0001193125-08-137504 — 8.01
- 2008-05-06 0001193125-08-104089 — 2.02
- 2008-03-21 0001193125-08-062838 — 8.01
- 2008-02-06 0001193125-08-021681 — 2.02
- 2008-01-23 0001193125-08-010589 — 5.02
- 2008-01-04 0001193125-08-001680 — 5.02, 9.01
- 2007-12-21 0001193125-07-269613 — 5.02
- 2007-11-19 0001193125-07-250345 — 5.02 — amendment of 0001193125-07-009285
- 2007-11-19 0001193125-07-250343 — 5.02, 9.01
- 2007-11-07 0001193125-07-238464 — 2.02
- 2007-09-24 0001193125-07-206279 — 8.01
- 2007-09-20 0001193125-07-204616 — 5.02, 7.01
- 2007-09-07 0001193125-07-197514 — 8.01
- 2007-08-17 0001193125-07-185320 — 1.01, 2.03, 9.01
- 2007-08-08 0001193125-07-174077 — 5.02
- 2007-08-07 0001193125-07-173689 — 2.02
- 2007-08-01 0001193125-07-168143 — 5.02
- 2007-05-15 0001193125-07-115800 — 8.01
- 2007-05-08 0001193125-07-106059 — 2.02
- 2007-03-23 0001193125-07-063033 — 5.02, 5.03, 8.01, 9.01
- 2007-03-21 0001193125-07-060631 — 1.01, 9.01
- 2007-02-06 0001193125-07-021349 — 2.02
- 2007-01-19 0001193125-07-009285 — 5.02
- 2006-12-22 0001193125-06-259241 — 8.01
- 2006-11-16 0001193125-06-237260 — 5.03, 8.01, 9.01
- 2006-11-08 0001193125-06-228341 — 2.02
- 2006-09-21 0001193125-06-194890 — 1.01, 7.01
- 2006-09-20 0001193125-06-194063 — 1.01
- 2006-09-15 0001193125-06-191845 — 5.02
- 2006-08-18 0001193125-06-176193 — 5.02
- 2006-08-08 0001193125-06-165719 — 2.02
- 2006-07-31 0001193125-06-157106 — 1.01, 9.01
- 2006-07-31 0001193125-06-157102 — 5.02 — amendment of 0001193125-06-017426
- 2006-06-08 0001193125-06-126879 — 5.02
- 2006-05-18 0001193125-06-115516 — 8.01
- 2006-05-12 0001193125-06-110924 — 9.01 — amendment of 0001193125-06-044013
- 2006-05-09 0001193125-06-105419 — 2.02
- 2006-03-29 0001193125-06-066990 — 1.01
- 2006-03-02 0001193125-06-044013 — 1.01, 2.01, 9.01
- 2006-02-28 0001193125-06-041452 — 1.01
- 2006-02-22 0001193125-06-036759 — 8.01
- 2006-02-22 0001193125-06-036433 — 1.01, 8.01, 9.01
- 2006-02-21 0001193125-06-035865 — 1.01, 2.03, 9.01
- 2006-02-10 0001193125-06-026218 — 8.01, 9.01
- 2006-02-07 0001193125-06-022234 — 2.02
- 2006-02-01 0001193125-06-017426 — 5.02
- 2005-11-18 0001193125-05-229535 — 1.01, 9.01
- 2005-11-16 0001193125-05-227987 — 1.01, 9.01
- 2005-11-16 0001193125-05-227983 — 5.02 — amendment of 0001193125-05-008843
- 2005-11-09 0001193125-05-221610 — 2.02
- 2005-09-29 0001193125-05-194217 — 7.01
- 2005-09-27 0001193125-05-192353 — 8.01
- 2005-09-21 0001193125-05-189234 — 1.01, 9.01
- 2005-09-19 0001193125-05-187646 — 8.01
- 2005-09-09 0001193125-05-183273 — 8.01
- 2005-09-08 0001193125-05-182307 — 1.01
- 2005-08-09 0001193125-05-162626 — 2.02
- 2005-07-15 0001193125-05-142738 — 8.01
- 2005-05-10 0001193125-05-102797 — 2.02
- 2005-03-30 0001193125-05-065123 — 1.01, 3.03, 9.01
- 2005-03-04 0001193125-05-042778 — 1.01
- 2005-02-08 0001193125-05-022181 — 2.02
- 2005-01-20 0001193125-05-008843 — 5.02
- 2004-12-23 0001193125-04-219331 — 8.01
- 2004-11-09 0001193125-04-191303 — 2.02
- 2004-08-23 0001193125-04-145198 — 1.01, 7.01
- 2004-08-19 0001193125-04-143859 — 5
- 2004-08-10 0001193125-04-136865 — 12
- 2004-05-11 0001193125-04-084721 — 12
- 2004-02-03 0001193125-04-013750 — 12
- 2003-11-05 0001193125-03-073418 — 12
- 2003-09-02 0001193125-03-044521 — 9
- 2003-08-05 0001193125-03-029223 — 12, 7
- 2003-07-18 0001193125-03-021155 — 5, 7
- 2003-06-05 0001012870-03-002949 — 5
- 2003-05-06 0000891618-03-002315 — 7, 9
- 2003-04-17 0000891618-03-001894 — 5, 7
- 2003-04-11 0000891618-03-001791 — 9
- 2003-03-20 0000891618-03-001326 — 5, 7
- 2003-02-04 0000891618-03-000518 — 7, 9
- 2003-01-28 0000891618-03-000271 — 5, 7
- 2002-12-27 0000891618-02-005686 — 5, 7
- 2002-10-23 0000891618-02-004715 — 5, 7
- 2002-10-11 0000891618-02-004620 — 5, 7
- 2002-09-18 0000891618-02-004352 — 5, 7
- 2002-08-20 0000891618-02-004001 — 5, 7
- 2002-08-05 0000891618-02-003498 — 5, 7
- 2002-07-03 0000891618-02-003099 — 5, 7
- 2002-05-14 0000891618-02-002407 — 5, 7
- 2002-02-05 0000891618-02-000412 — 5, 7
- 2001-09-28 0001095811-01-505261 — 5, 7
- 2001-09-14 0001095811-01-504917 — 5, 7
- 2001-08-24 0001095811-01-504581 — 5, 7
- 2001-07-30 0001095811-01-503468 — 5, 7
- 2001-07-12 0000891618-01-501567 — 5, 7
- 2001-05-11 0000891618-01-500638 — 5, 7
- 2001-02-27 0000891618-01-500076 — 5, 7
- 2001-02-20 0001095811-01-001530 — 5, 7
- 2001-02-08 0001095811-01-000848 — 5, 7
- 2001-02-07 0001095811-01-000768 — 5
- 2000-12-27 0001095811-00-005511 — 5
- 2000-12-21 0001095811-00-005427 — 5
- 2000-12-19 0001095811-00-005368 — 5
- 2000-11-15 0001095811-00-004830 — 5
- 2000-11-15 0001095811-00-004824 — 5
- 2000-11-13 0000891618-00-005023 — 5
- 2000-11-07 0001095811-00-004387 — 5, 7
- 2000-11-06 0001095811-00-004318 — 5
- 2000-09-29 0000891618-00-004739 — 5, 7
- 2000-09-28 0000891618-00-004722 — 5
- 2000-09-26 0001095811-00-003573 — 5
- 2000-09-15 0001095811-00-003413 — 5
- 2000-09-07 0001095811-00-003229 — 5
- 2000-08-15 0000891618-00-004430 — 5
- 2000-08-04 0001095811-00-002304 — 5, 7 — amendment, the index does not say of what
- 2000-07-28 0000891618-00-004132 — 5, 7
- 2000-06-29 0000891618-00-003637 — 5
- 2000-06-07 0000891618-00-003209 — 5
- 2000-05-26 0000891618-00-003054 — 5
- 2000-05-18 0000891618-00-002975 — 5, 7
- 2000-05-15 0000891618-00-002808 — 5, 7
- 2000-05-03 0000891618-00-002473 — 5
- 2000-04-03 0000891618-00-001936 — 5
- 2000-03-28 0000891618-00-001763 — 5
- 2000-03-27 0000891618-00-001722 — 5, 7
- 2000-03-16 0000891618-00-001512 — 5
- 2000-02-17 0000891618-00-001024 — 5, 7
- 2000-02-03 0000891618-00-000468 — 7 — amendment of 0000891618-99-005685
- 1999-12-22 0000891618-99-005792 — 5, 7
- 1999-12-15 0000891618-99-005685 — 5, 7
- 1999-11-17 0000891618-99-005313 — 5, 7
- 1999-11-04 0000891618-99-004862 — 5, 7
- 1999-10-20 0000891618-99-004625 — 5, 7
- 1999-09-27 0000891618-99-004333 — 5, 7
- 1999-08-26 0000891618-99-003978 — 5, 7
- 1999-08-13 0000891618-99-003764 — 5, 7 — amendment of 0000891618-99-003749
- 1999-08-13 0000891618-99-003749 — 5, 7
- 1999-07-02 0000891618-99-002980 — 5, 7
- 1999-05-14 0000891618-99-002221 — 5
- 1998-11-20 0000891618-98-005074 — 5, 7
- 1998-11-20 0000891618-98-005073 — 5, 7
- 1998-10-13 0000891618-98-004462 — 5, 7
- 1998-07-09 0000891618-98-003245 — 5, 7
- 1998-06-11 0000891618-98-002832 — 5, 7
- 1998-05-15 0000891618-98-002457 — 5, 7
- 1998-04-29 0000891618-98-001996 — 5
- 1998-02-11 0000891618-98-000584 — 5, 7
- 1997-09-09 0000891618-97-003723 — 5, 7
- 1997-08-22 0000891618-97-003559 — 5, 7
- 1997-07-01 0000891618-97-002807 — 5, 7
- 1997-01-22 0000891618-97-000120 — 5, 7
- 1996-10-15 0000891618-96-002283 — 5, 7 — amendment of 0000891618-96-002217
- 1996-10-01 0000891618-96-002217 — 5, 7
- 1996-07-23 0000891618-96-001305 — 2, 7
- 1996-04-26 0000891618-96-000253 — 2
- 1996-04-02 0000898430-96-001187 — 2, 7
- 1995-12-06 0000891618-95-000728 — 2, 7
- 1995-12-06 0000891618-95-000727 — 2, 7

## late-filing notifications on or before 2016-02-18

- none on or before 2016-02-18

## item 2.02 — earnings release, exhibit 99.1

[0001193125-16-457586:8k_2_02:1]
EX-99.1
2
d134423dex991.htm
EX-99.1

[0001193125-16-457586:8k_2_02:2]
EX-99.1

[0001193125-16-457586:8k_2_02:3]
Exhibit 99.1

[0001193125-16-457586:8k_2_02:4]
| Press Contact: |  |  |  | Investor Relations Contact: |
| Andrea Duffy |  |  |  | Marilyn Mora |
| Cisco |  |  |  | Cisco |
| 1 (646) 295-5241 |  |  |  | 1 (408) 527-7452 |
| anduffy@cisco.com |  |  |  | marilmor@cisco.com |

[0001193125-16-457586:8k_2_02:5]
CISCO REPORTS SECOND QUARTER EARNINGS

[0001193125-16-457586:8k_2_02:6]
Strong Execution and Cash Flows in Q2; Dividend Increased 24 Percent, Additional $15 Billion Authorized for Stock Repurchase

[0001193125-16-457586:8k_2_02:7]
|  | • |  | Q2 Revenue (excluding SP Video CPE Business): $11.8 billion |

[0001193125-16-457586:8k_2_02:8]
|  | • |  | Increase of 2% year over year — (Q2 guidance was 0% - 2% growth year over year) |

[0001193125-16-457586:8k_2_02:9]
|  | • |  | Q2 Earnings per Share: $0.62 GAAP; $0.57 non-GAAP |

[0001193125-16-457586:8k_2_02:10]
|  | • |  | Q3 Guidance: |

[0001193125-16-457586:8k_2_02:11]
|  | • |  | Revenue: 1% - 4% growth year over year (normalized to exclude SP Video CPE Business for Q3 2015) |

[0001193125-16-457586:8k_2_02:12]
|  | • |  | Non-GAAP Earnings per Share: $0.54 - $0.56 |

[0001193125-16-457586:8k_2_02:13]
SAN JOSE, Calif. — February 10, 2016 —
Cisco, the worldwide leader in networking that transforms how people connect, communicate and collaborate, today reported second quarter results for the period ended January 23, 2016. Cisco reported second quarter revenue of $11.9 billion, net
income on a generally accepted accounting principles (GAAP) basis of $3.1 billion or $0.62 per share, and non-GAAP net income of $2.9 billion or $0.57 per share. Second quarter revenue was $11.8 billion excluding $93 million of revenue from the
Customer Premises Equipment portion of the Service Provider Video Connected Devices business (SP Video CPE Business) that was divested during the second quarter on November 20, 2015.

[0001193125-16-457586:8k_2_02:14]
“We delivered a strong Q2, and are managing the business extremely well in a challenging macro environment,” said Chuck Robbins, Cisco chief
executive officer. “We’re managing the company on two fronts. We’re focused on continued strong execution in the near term while investing in the innovation to lead our customers into the future.”

[0001193125-16-457586:8k_2_02:15]
GAAP Results

[0001193125-16-457586:8k_2_02:16]
|  |  | Q2 2016 |  |  | Q2 2015 |  |  | Vs. Q2 2015 |  |
| Revenue (including SP Video CPE Business for all periods) |  | $ | 11.9 billion |  |  | $ | 11.9 billion |  |  |  | — | % |
| Revenue (excluding SP Video CPE Business for all periods) |  | $ | 11.8 billion |  |  | $ | 11.6 billion |  |  |  | 2 | % |
| Net Income |  | $ | 3.1 billion |  |  | $ | 2.4 billion |  |  |  | 31 | % |
| Diluted Earnings per Share (EPS) |  | $ | 0.62 |  |  | $ | 0.46 |  |  |  | 35 | % |

[0001193125-16-457586:8k_2_02:17]
Non-GAAP Results

[0001193125-16-457586:8k_2_02:18]
|  |  | Q2 2016 |  |  | Q2 2015 |  |  | Vs. Q2 2015 |  |
| Net Income |  | $ | 2.9 billion |  |  | $ | 2.7 billion |  |  |  | 7 | % |
| EPS |  | $ | 0.57 |  |  | $ | 0.53 |  |  |  | 8 | % |

[0001193125-16-457586:8k_2_02:19]
A reconciliation between net income and EPS on a GAAP and non-GAAP basis is provided in the table following the Consolidated
Statements of Operations. Supplementary information related to other GAAP and non-GAAP measures is also provided in the tables below.

[0001193125-16-457586:8k_2_02:20]
1

[0001193125-16-457586:8k_2_02:21]
Cisco Increases Quarterly Cash Dividend; Stock Repurchase Program Authorization Increased

[0001193125-16-457586:8k_2_02:22]
Cisco has also declared a quarterly dividend of $0.26 per common share, a 24% or five-cent increase over the previous quarter’s dividend, to be paid
on April 27, 2016 to all shareholders of record as of the close of business on April 6, 2016. Future dividends will be subject to Board approval.

[0001193125-16-457586:8k_2_02:23]
Cisco’s board of directors has also approved a $15 billion increase to the authorization of the stock repurchase program. Cisco’s board had
previously authorized up to $97 billion in stock repurchases. There is no fixed termination date for the repurchase program. The remaining authorized amount for stock repurchases under this program, including the additional authorization, is
approximately $16.9 billion.

[0001193125-16-457586:8k_2_02:24]
“We had another strong quarter, delivering both the top line and bottom line growth,” said Kelly Kramer, Cisco
executive vice president and chief financial officer. “I’m happy with the progress we are making as we continue to shift our business model to more software, and recurring revenue. We are very confident in the strength of our business and
future cash flows allowing the substantial increase of our dividend this quarter to $0.26. We remain committed to our shareholders in delivering profitable growth and returning a minimum of 50 percent of our free cash flow back
annually.”

[0001193125-16-457586:8k_2_02:25]
Financial Highlights for Q2 FY16

[0001193125-16-457586:8k_2_02:26]
(All comparative percentages are on a year-over-year basis unless otherwise noted)

[0001193125-16-457586:8k_2_02:27]
All revenue, non-GAAP, and geographic financial information in this “Financial Highlights for Q2 FY16” section are presented excluding the SP
Video CPE Business for all periods as it was divested during the second quarter on November 20, 2015.

[0001193125-16-457586:8k_2_02:28]
Revenue — Revenue was $11.8 billion, up 2% with product revenue up 2%. Service revenue growth was 3%.
Revenue by geographic segment was: Americas and EMEA each up 1%, and APJC up 11%. Product revenue growth was led by Security which increased 11%, and NGN Routing and Collaboration which increased 5% and 3%, respectively. Wireless was flat while
Switching and Data Center declined 4% and 3%, respectively.

[0001193125-16-457586:8k_2_02:29]
Gross Margin — On a GAAP basis, total gross margin and product
gross margin were at 62.3% and 61.3%, respectively. Non-GAAP total gross margin and product gross margin were 64.2% and 63.3%, respectively. This increase in the non-GAAP product gross margin as compared with 62.5% in the second quarter of fiscal
2015 was driven by continued productivity improvements, partially offset by pricing and to a lesser extent product mix. GAAP service margin was 65.5% and non-GAAP service gross margin was 66.7%. Total gross margins by geographic segment were:
64.3% for the Americas, 65.4% for EMEA, and 61.8% for APJC.

[0001193125-16-457586:8k_2_02:30]
Operating Expenses — On a GAAP basis, operating expenses were $4.1
billion, down 7%. Non-GAAP operating expenses were $3.9 billion, down 1%, and at 33.0% of revenue. Headcount compared with the end of the first quarter of fiscal 2016 decreased by 406 to 71,657, which included the impact from the divestiture of the
SP Video CPE Business and our workforce realignment, partially offset by additional headcount from acquisitions and investments in key growth areas such as security, cloud and software.

[0001193125-16-457586:8k_2_02:31]
Operating Income — GAAP operating income was $3.3 billion, up 26%, with GAAP operating margin of 27.6%. Non-GAAP operating income was $3.7
billion, up 10%, with non-GAAP operating margin at 31.2%.

[0001193125-16-457586:8k_2_02:32]
Provision for Income Taxes — The GAAP tax provision rate was 4.8%. Tax
benefits of $519 million related to prior-year periods were included in the GAAP tax provision rate but were excluded in the non-GAAP tax provision rate. The non-GAAP tax provision rate was 20.9%, reflecting the reinstatement of the U.S.
federal R&D tax credit.

[0001193125-16-457586:8k_2_02:33]
Net Income and EPS — On a GAAP basis, net income was $3.1 billion and EPS was $0.62. On a non-GAAP basis,
net income was $2.9 billion, an increase of 8%, and EPS was $0.57, an increase of 8%.

[0001193125-16-457586:8k_2_02:34]
Cash Flow from Operating Activities — was $3.9
billion an increase of 36% compared with $2.9 billion for the second quarter of fiscal 2015.

[0001193125-16-457586:8k_2_02:35]
Cash and Cash Equivalents and Investments —
were $60.4 billion at the end of the second quarter of fiscal 2016, compared with $59.1 billion at the end of the first quarter of fiscal 2016, and compared with $60.4 billion at the end of fiscal 2015. The total cash and cash equivalents
and investments available in the United States at the end of the second quarter of fiscal 2016 were $3.9 billion.

[0001193125-16-457586:8k_2_02:36]
Deferred Revenue —
was $15.2 billion, up 8% in total, with deferred product revenue up 11%, driven largely by subscription based and software offerings, and deferred service revenue up 7%. Cisco continued to build a greater mix of recurring revenue as
reflected in deferred revenue.

[0001193125-16-457586:8k_2_02:37]
Days Sales Outstanding in Accounts Receivable (DSO) — was 33 days at the end of the second quarter of
fiscal 2016, compared with 34 days at the end of the first quarter of fiscal 2016.

[0001193125-16-457586:8k_2_02:38]
2

[0001193125-16-457586:8k_2_02:39]
Other Financial Highlights

[0001193125-16-457586:8k_2_02:40]
In the second quarter of fiscal 2016, Cisco declared and paid a cash dividend of $0.21 per common share, or $1.1 billion. For the second quarter of fiscal
2016, Cisco repurchased approximately 48 million shares of common stock under its stock repurchase program at an average price of $26.12 per share for an aggregate purchase price of $1.3 billion.

[0001193125-16-457586:8k_2_02:41]
As of January 23, 2016, Cisco had repurchased and retired 4.5 billion shares of Cisco common stock at an average price of $20.97 per share for an
aggregate purchase price of approximately $95.1 billion since the inception of the stock repurchase program.

[0001193125-16-457586:8k_2_02:42]
Acquisitions

[0001193125-16-457586:8k_2_02:43]
During the second quarter of fiscal 2016, Cisco completed the acquisitions of Portcullis, ParStream, Lancope and 1 Mainstream in the security, data analytics
and video markets. These moves are consistent with Cisco’s strategy to increase innovation and R&D investment in growth areas. Cisco recently completed the acquisition of Acano to help accelerate Cisco’s collaboration strategy to
deliver video more broadly. In addition, on February 3, 2016, Cisco announced its intent to acquire Jasper Technologies, a company that provides a cloud-based Internet of Things (IoT) software-as-a-service platform, which is expected to close in the
third quarter of fiscal year 2016.

[0001193125-16-457586:8k_2_02:44]
Business Outlook for the Third Quarter of Fiscal Year 2016

[0001193125-16-457586:8k_2_02:45]
On November 20, 2015, during the second quarter of fiscal 2016, Cisco completed its divestiture of the SP Video CPE Business. In order to provide a clear
view of Cisco’s continuing expected financial performance, the revenue guidance for the third quarter of fiscal 2016 is normalized to exclude the SP Video CPE Business for the third quarter of fiscal 2015. The corresponding revenue in the
third quarter of fiscal 2015 for the SP Video CPE Business was $519 million.

[0001193125-16-457586:8k_2_02:46]
Cisco expects to achieve the following results for the third quarter of
fiscal year 2016:

[0001193125-16-457586:8k_2_02:47]
| Q3 FY16 |  |  |
| Revenue (normalized to exclude SP Video CPE Business for Q3 FY15) |  | 1% - 4% growth Y/Y |
| Non-GAAP gross margin rate |  | 62.5% - 63.5% |
| Non-GAAP operating margin rate |  | 28.5% - 29.5% |
| Non-GAAP tax provision rate |  | 22% |
| Non-GAAP EPS |  | $0.54 - $0.56 |

[0001193125-16-457586:8k_2_02:48]
Cisco’s third quarter of fiscal 2016 will have 14 weeks compared to 13 weeks for the third quarter of fiscal 2015 which
is reflected in the guidance.

[0001193125-16-457586:8k_2_02:49]
Cisco estimates that GAAP EPS will be lower than non-GAAP EPS by $0.08 to $0.12 per share in the third quarter of fiscal
2016 as follows:

[0001193125-16-457586:8k_2_02:50]
| Q3 FY16 |  |  |  |
| Share-based compensation expense |  | $ | 0.05 - $0.06 |  |
| Amortization of purchased intangible assets and other acquisition-related/divestiture costs |  |  | 0.03 - 0.05 |  |
| Subtotal |  |  | 0.08 - 0.11 |  |
| Restructuring and other charges |  |  | 0.00 - 0.01 |  |
| Total |  | $ | 0.08 - $0.12 |  |

[0001193125-16-457586:8k_2_02:51]
Share-based compensation expense is expected to impact Cisco’s results of operations in similar proportions as the second
quarter of fiscal 2016. Amortization of purchased intangible assets and other acquisition-related/divestiture costs will be reported as GAAP operating expenses, cost of sales, or other income/(loss) as applicable.

[0001193125-16-457586:8k_2_02:52]
Except as noted above, this guidance does not include the effects of any future acquisitions/divestitures, asset impairments, restructurings and tax or other
events, which may or may not be significant unless specifically stated.

[0001193125-16-457586:8k_2_02:53]
Editor’s Notes:

[0001193125-16-457586:8k_2_02:54]
|  | • |  | Q2 fiscal year 2016 conference call to discuss Cisco’s results along with its business outlook will be held on Wednesday, February 10, 2016 at 1:30 p.m. Pacific Time. Conference call number is 1-888-848-6507 (United States) or 1-212-519-0847 (international). |

[0001193125-16-457586:8k_2_02:55]
|  | • |  | Conference call replay will be available from 4:00 p.m. Pacific Time, February 10, 2016 to 4:00 p.m. Pacific Time, February 19, 2016 at 1-888-562-6191(United States) or 1-402-280-9986 (international). The replay will also be available via webcast from February 10, 2016 through April 22, 2016 on the Cisco Investor Relations website at http://investor.cisco.com. |

[0001193125-16-457586:8k_2_02:56]
|  | • |  | Additional information regarding Cisco’s financials, as well as a webcast of the conference call with visuals designed to guide participants through the call, will be available at 1:30 p.m. Pacific Time, February 10, 2016. Text of the conference call’s prepared remarks will be available within 24 hours of completion of the call. The webcast will include both the prepared remarks and the question-and-answer session. This information, along with the GAAP to non-GAAP reconciliation information, will be available on the Cisco Investor Relations website at http://investor.cisco.com. |

[0001193125-16-457586:8k_2_02:57]
4

[0001193125-16-457586:8k_2_02:58]
CISCO SYSTEMS, INC.

[0001193125-16-457586:8k_2_02:59]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-16-457586:8k_2_02:60]
(In millions, except per-share amounts)

[0001193125-16-457586:8k_2_02:61]
(Unaudited)

[0001193125-16-457586:8k_2_02:62]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | January 23,2016 |  |  | January 24,2015 |  |  | January 23,2016 |  |  | January 24,2015 |  |
| REVENUE: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 8,983 |  |  | $ | 9,078 |  |  | $ | 18,827 |  |  | $ | 18,513 |  |
| Service |  |  | 2,944 |  |  |  | 2,858 |  |  |  | 5,782 |  |  |  | 5,668 |  |
| Total revenue |  |  | 11,927 |  |  |  | 11,936 |  |  |  | 24,609 |  |  |  | 24,181 |  |
| COST OF SALES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 3,480 |  |  |  | 3,806 |  |  |  | 7,333 |  |  |  | 7,725 |  |
| Service |  |  | 1,015 |  |  |  | 1,040 |  |  |  | 2,012 |  |  |  | 2,033 |  |
| Total cost of sales |  |  | 4,495 |  |  |  | 4,846 |  |  |  | 9,345 |  |  |  | 9,758 |  |
| GROSS MARGIN |  |  | 7,432 |  |  |  | 7,090 |  |  |  | 15,264 |  |  |  | 14,423 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 1,509 |  |  |  | 1,529 |  |  |  | 3,069 |  |  |  | 3,112 |  |
| Sales and marketing |  |  | 2,286 |  |  |  | 2,308 |  |  |  | 4,729 |  |  |  | 4,823 |  |
| General and administrative |  |  | 176 |  |  |  | 490 |  |  |  | 715 |  |  |  | 994 |  |
| Amortization of purchased intangible assets |  |  | 71 |  |  |  | 72 |  |  |  | 140 |  |  |  | 143 |  |
| Restructuring and other charges |  |  | 96 |  |  |  | 69 |  |  |  | 238 |  |  |  | 387 |  |
| Total operating expenses |  |  | 4,138 |  |  |  | 4,468 |  |  |  | 8,891 |  |  |  | 9,459 |  |
| OPERATING INCOME |  |  | 3,294 |  |  |  | 2,622 |  |  |  | 6,373 |  |  |  | 4,964 |  |
| Interest income |  |  | 237 |  |  |  | 189 |  |  |  | 462 |  |  |  | 368 |  |
| Interest expense |  |  | (162 | ) |  |  | (139 | ) |  |  | (321 | ) |  |  | (278 | ) |
| Other income (loss), net |  |  | (63 | ) |  |  | 201 |  |  |  | (71 | ) |  |  | 179 |  |
| Interest and other income (loss), net |  |  | 12 |  |  |  | 251 |  |  |  | 70 |  |  |  | 269 |  |
| INCOME BEFORE PROVISION FOR INCOME TAXES |  |  | 3,306 |  |  |  | 2,873 |  |  |  | 6,443 |  |  |  | 5,233 |  |
| Provision for income taxes |  |  | 159 |  |  |  | 476 |  |  |  | 866 |  |  |  | 1,008 |  |
| NET INCOME |  | $ | 3,147 |  |  | $ | 2,397 |  |  | $ | 5,577 |  |  | $ | 4,225 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.62 |  |  | $ | 0.47 |  |  | $ | 1.10 |  |  | $ | 0.83 |  |
| Diluted |  | $ | 0.62 |  |  | $ | 0.46 |  |  | $ | 1.09 |  |  | $ | 0.82 |  |
| Shares used in per-share calculation: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 5,070 |  |  |  | 5,117 |  |  |  | 5,075 |  |  |  | 5,115 |  |
| Diluted |  |  | 5,097 |  |  |  | 5,160 |  |  |  | 5,106 |  |  |  | 5,159 |  |
| Cash dividends declared per common share |  | $ | 0.21 |  |  | $ | 0.19 |  |  | $ | 0.42 |  |  | $ | 0.38 |  |

[0001193125-16-457586:8k_2_02:63]
The Consolidated Statements of Operations include the results of the SP Video CPE Business prior to its divestiture on
November 20, 2015. Accordingly, the three months ended January 23, 2016 includes only one month of financial results for this business.

[0001193125-16-457586:8k_2_02:64]
5

[0001193125-16-457586:8k_2_02:65]
CISCO SYSTEMS, INC.

[0001193125-16-457586:8k_2_02:66]
RECONCILIATION OF GAAP TO NON-GAAP NET INCOME

[0001193125-16-457586:8k_2_02:67]
(In millions, except per-share amounts)

[0001193125-16-457586:8k_2_02:68]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | January 23,2016 |  |  | January 24,2015 |  |  | January 23,2016 |  |  | January 24,2015 |  |
| GAAP net income |  | $ | 3,147 |  |  | $ | 2,397 |  |  | $ | 5,577 |  |  | $ | 4,225 |  |
| Adjustments to cost of sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 51 |  |  |  | 45 |  |  |  | 102 |  |  |  | 93 |  |
| Amortization of acquisition-related intangible assets |  |  | 123 |  |  |  | 233 |  |  |  | 251 |  |  |  | 414 |  |
| Rockstar patent portfolio charge |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 188 |  |
| Acquisition-related/divestiture costs |  |  | 1 |  |  |  | — |  |  |  | 1 |  |  |  | — |  |
| Significant asset impairments and restructurings |  |  | (1 | ) |  |  | — |  |  |  | (2 | ) |  |  | — |  |
| Total adjustments to GAAP cost of sales |  |  | 174 |  |  |  | 278 |  |  |  | 352 |  |  |  | 695 |  |
| Adjustments to operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 280 |  |  |  | 261 |  |  |  | 590 |  |  |  | 586 |  |
| Amortization of acquisition-related intangible assets |  |  | 71 |  |  |  | 72 |  |  |  | 140 |  |  |  | 143 |  |
| Acquisition-related/divestiture costs (1) |  |  | (222 | ) |  |  | 92 |  |  |  | (131 | ) |  |  | 193 |  |
| Significant asset impairments and restructurings |  |  | 96 |  |  |  | 69 |  |  |  | 238 |  |  |  | 387 |  |
| Total adjustments to GAAP operating expenses |  |  | 225 |  |  |  | 494 |  |  |  | 837 |  |  |  | 1,309 |  |
| Adjustments to other income (loss), net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Gain on VCE reorganization |  |  | — |  |  |  | (126 | ) |  |  | — |  |  |  | (126 | ) |
| Total adjustments to GAAP income before provision for income taxes |  |  | 399 |  |  |  | 646 |  |  |  | 1,189 |  |  |  | 1,878 |  |
| Income tax effect of non-GAAP adjustments |  |  | (98 | ) |  |  | (164 | ) |  |  | (294 | ) |  |  | (422 | ) |
| Significant tax matters (2) |  |  | (519 | ) |  |  | (134 | ) |  |  | (519 | ) |  |  | (134 | ) |
| Total adjustments to GAAP provision for income taxes |  |  | (617 | ) |  |  | (298 | ) |  |  | (813 | ) |  |  | (556 | ) |
| Non-GAAP net income |  | $ | 2,929 |  |  | $ | 2,745 |  |  | $ | 5,953 |  |  | $ | 5,547 |  |
| Diluted net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | $ | 0.62 |  |  | $ | 0.46 |  |  | $ | 1.09 |  |  | $ | 0.82 |  |
| Non-GAAP |  | $ | 0.57 |  |  | $ | 0.53 |  |  | $ | 1.17 |  |  | $ | 1.08 |  |

[0001193125-16-457586:8k_2_02:69]
(1) The sale of the SP Video CPE Business resulted in a pre-tax gain
of $286 million, net of certain transaction costs incurred in prior periods. The gain on this transaction was excluded from non-GAAP net income for the second quarter and first six months of fiscal 2016.

[0001193125-16-457586:8k_2_02:70]
(2) During the second quarter of fiscal 2016, Cisco recorded certain net tax benefits totaling $519
million related to prior-year periods that were excluded from non-GAAP net income for the second quarter and first six months of fiscal 2016. These net tax benefits are primarily comprised of settlement of all outstanding items related to
Cisco’s U.S. federal income tax returns for the fiscal years ended July 26, 2008 through July 31, 2010 of $367 million, the retroactive reinstatement of the U.S. federal R&D tax credit of $84 million related to fiscal 2015, and a net tax
benefit of $68 million related to other significant tax matters.

[0001193125-16-457586:8k_2_02:71]
6

[0001193125-16-457586:8k_2_02:72]
CISCO SYSTEMS, INC.

[0001193125-16-457586:8k_2_02:73]
REVENUE BY SEGMENT

[0001193125-16-457586:8k_2_02:74]
(In
millions, except percentages)

[0001193125-16-457586:8k_2_02:75]
|  |  | January 23, 2016 |
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | Amount |  |  | Y/Y % |  | Amount |  |  | Y/Y % |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |
| Including SP Video CPE Business for all periods: |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 6,912 |  |  | (3)% |  | $ | 14,711 |  |  | 1% |
| EMEA |  |  | 3,088 |  |  | — % |  |  | 6,175 |  |  | 1% |
| APJC |  |  | 1,927 |  |  | 10% |  |  | 3,723 |  |  | 7% |
| Total |  | $ | 11,927 |  |  | — % |  | $ | 24,609 |  |  | 2% |
| Excluding SP Video CPE Business for all periods: |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 6,846 |  |  | 1% |  | $ | 14,333 |  |  | 3% |
| EMEA |  |  | 3,065 |  |  | 1% |  |  | 6,067 |  |  | 2% |
| APJC |  |  | 1,923 |  |  | 11% |  |  | 3,705 |  |  | 7% |
| Total |  | $ | 11,834 |  |  | 2% |  | $ | 24,105 |  |  | 3% |

[0001193125-16-457586:8k_2_02:76]
CISCO SYSTEMS, INC.

[0001193125-16-457586:8k_2_02:77]
GROSS MARGIN PERCENTAGE BY SEGMENT

[0001193125-16-457586:8k_2_02:78]
(In percentages)

[0001193125-16-457586:8k_2_02:79]
|  |  | January 23, 2016 |
|  |  | Three Months Ended |  | Six Months Ended |
| Gross Margin Percentage: |  |  |  |  |
| Including SP Video CPE Business for all periods: |  |  |  |  |
| Americas |  | 63.8% |  | 63.6% |
| EMEA |  | 64.9% |  | 64.6% |
| APJC |  | 61.7% |  | 60.9% |
| Excluding SP Video CPE Business for all periods (1): |  |  |  |  |
| Americas |  | 64.3% |  | 65.0% |
| EMEA |  | 65.4% |  | 65.5% |
| APJC |  | 61.8% |  | 61.2% |

[0001193125-16-457586:8k_2_02:80]
(1) For the three months ended January 23, 2016 the calculation of gross
margin percentages excludes gross profit for the SP Video CPE Business of $13 million for the Americas. For the six months ended January 23, 2016, the calculation of gross margin percentages excludes gross profit for the SP Video CPE Business of $41
million and $15 million for the Americas and EMEA, respectively.

[0001193125-16-457586:8k_2_02:81]
7

[0001193125-16-457586:8k_2_02:82]
CISCO SYSTEMS, INC.

[0001193125-16-457586:8k_2_02:83]
REVENUE FOR GROUPS OF SIMILAR PRODUCTS AND SERVICES

[0001193125-16-457586:8k_2_02:84]
(In millions, except percentages)

[0001193125-16-457586:8k_2_02:85]
|  |  | January 23, 2016 |  |
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | Amount |  |  | Y/Y % |  |  | Amount |  |  | Y/Y % |  |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Switching |  | $ | 3,483 |  |  |  | (4)% |  |  | $ | 7,505 |  |  |  | 1% |  |
| NGN Routing |  |  | 1,845 |  |  |  | 5% |  |  |  | 3,638 |  |  |  | (2)% |  |
| Collaboration |  |  | 1,019 |  |  |  | 3% |  |  |  | 2,134 |  |  |  | 10% |  |
| Data Center |  |  | 822 |  |  |  | (3)% |  |  |  | 1,681 |  |  |  | 9% |  |
| Wireless |  |  | 613 |  |  |  | — % |  |  |  | 1,258 |  |  |  | 3% |  |
| Service Provider Video* |  |  | 569 |  |  |  | 37% |  |  |  | 1,008 |  |  |  | 25% |  |
| Security |  |  | 462 |  |  |  | 11% |  |  |  | 947 |  |  |  | 9% |  |
| Other |  |  | 77 |  |  |  | 31% |  |  |  | 152 |  |  |  | 21% |  |
| Product - excluding SP Video CPE Business |  |  | 8,890 |  |  |  | 2% |  |  |  | 18,323 |  |  |  | 4% |  |
| Service |  |  | 2,944 |  |  |  | 3% |  |  |  | 5,782 |  |  |  | 2% |  |
| Total - excluding SP Video CPE Business |  |  | 11,834 |  |  |  | 2% |  |  |  | 24,105 |  |  |  | 3% |  |
| SP Video CPE Business (1) |  |  | 93 |  |  |  |  |  |  |  | 504 |  |  |  |  |  |
| Total |  | $ | 11,927 |  |  |  | — % |  |  | $ | 24,609 |  |  |  | 2% |  |

[0001193125-16-457586:8k_2_02:86]
* Excludes SP Video CPE Business revenue for all periods presented.

[0001193125-16-457586:8k_2_02:87]
(1) The three months ended January 23, 2016 included one month of revenue for the SP Video CPE Business,
which was divested during the second quarter on November 20, 2015.

[0001193125-16-457586:8k_2_02:88]
8

[0001193125-16-457586:8k_2_02:89]
CISCO SYSTEMS, INC.

[0001193125-16-457586:8k_2_02:90]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001193125-16-457586:8k_2_02:91]
(In millions)

[0001193125-16-457586:8k_2_02:92]
(Unaudited)

[0001193125-16-457586:8k_2_02:93]
|  |  | January 23,2016 |  |  | July 25,2015 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 6,314 |  |  | $ | 6,877 |  |
| Investments |  |  | 54,061 |  |  |  | 53,539 |  |
| Accounts receivable, net of allowance for doubtful accounts of $325 at January 23, 2016 and $302 at July 25, 2015 |  |  | 4,302 |  |  |  | 5,344 |  |
| Inventories |  |  | 1,362 |  |  |  | 1,627 |  |
| Financing receivables, net |  |  | 4,514 |  |  |  | 4,491 |  |
| Deferred tax assets |  |  | 2,834 |  |  |  | 2,915 |  |
| Other current assets |  |  | 1,618 |  |  |  | 1,490 |  |
| Total current assets |  |  | 75,005 |  |  |  | 76,283 |  |
| Property and equipment, net |  |  | 3,386 |  |  |  | 3,332 |  |
| Financing receivables, net |  |  | 3,903 |  |  |  | 3,858 |  |
| Goodwill |  |  | 24,958 |  |  |  | 24,469 |  |
| Purchased intangible assets, net |  |  | 2,322 |  |  |  | 2,376 |  |
| Other assets |  |  | 3,068 |  |  |  | 3,163 |  |
| TOTAL ASSETS |  | $ | 112,642 |  |  | $ | 113,481 |  |
| LIABILITIES AND EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 3,008 |  |  | $ | 3,897 |  |
| Accounts payable |  |  | 962 |  |  |  | 1,104 |  |
| Income taxes payable |  |  | 370 |  |  |  | 62 |  |
| Accrued compensation |  |  | 2,667 |  |  |  | 3,049 |  |
| Deferred revenue |  |  | 9,796 |  |  |  | 9,824 |  |
| Other current liabilities |  |  | 5,996 |  |  |  | 5,687 |  |
| Total current liabilities |  |  | 22,799 |  |  |  | 23,623 |  |
| Long-term debt |  |  | 21,591 |  |  |  | 21,457 |  |
| Income taxes payable |  |  | 706 |  |  |  | 1,876 |  |
| Deferred revenue |  |  | 5,389 |  |  |  | 5,359 |  |
| Other long-term liabilities |  |  | 1,279 |  |  |  | 1,459 |  |
| Total liabilities |  |  | 51,764 |  |  |  | 53,774 |  |
| Total equity |  |  | 60,878 |  |  |  | 59,707 |  |
| TOTAL LIABILITIES AND EQUITY |  | $ | 112,642 |  |  | $ | 113,481 |  |

[0001193125-16-457586:8k_2_02:94]
CISCO SYSTEMS, INC.

[0001193125-16-457586:8k_2_02:95]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-16-457586:8k_2_02:96]
(In millions)

[0001193125-16-457586:8k_2_02:97]
(Unaudited)

[0001193125-16-457586:8k_2_02:98]
|  |  | Six Months Ended |  |
|  |  | January 23,2016 |  |  | January 24,2015 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 5,577 |  |  | $ | 4,225 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation, amortization, and other |  |  | 1,005 |  |  |  | 1,229 |  |
| Share-based compensation expense |  |  | 706 |  |  |  | 677 |  |
| Provision for receivables |  |  | 31 |  |  |  | 62 |  |
| Deferred income taxes |  |  | 274 |  |  |  | 385 |  |
| Excess tax benefits from share-based compensation |  |  | (82 | ) |  |  | (83 | ) |
| (Gains) losses on divestitures, investments and other, net |  |  | (260 | ) |  |  | (182 | ) |
| Change in operating assets and liabilities, net of effects of acquisitions and divestitures: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 988 |  |  |  | 501 |  |
| Inventories |  |  | 153 |  |  |  | (340 | ) |
| Financing receivables |  |  | (171 | ) |  |  | 74 |  |
| Other assets |  |  | (181 | ) |  |  | (223 | ) |
| Accounts payable |  |  | (147 | ) |  |  | (32 | ) |
| Income taxes, net |  |  | (764 | ) |  |  | (528 | ) |
| Accrued compensation |  |  | (348 | ) |  |  | (390 | ) |
| Deferred revenue |  |  | 69 |  |  |  | 26 |  |
| Other liabilities |  |  | (162 | ) |  |  | (27 | ) |
| Net cash provided by operating activities |  |  | 6,688 |  |  |  | 5,374 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of investments |  |  | (19,089 | ) |  |  | (20,061 | ) |
| Proceeds from sales of investments |  |  | 10,247 |  |  |  | 9,948 |  |
| Proceeds from maturities of investments |  |  | 7,955 |  |  |  | 7,212 |  |
| Acquisition of businesses, net of cash and cash equivalents acquired |  |  | (1,089 | ) |  |  | (217 | ) |
| Proceeds from business divestiture |  |  | 372 |  |  |  | — |  |
| Purchases of investments in privately held companies |  |  | (166 | ) |  |  | (91 | ) |
| Return of investments in privately held companies |  |  | 35 |  |  |  | 227 |  |
| Acquisition of property and equipment |  |  | (576 | ) |  |  | (550 | ) |
| Proceeds from sales of property and equipment |  |  | 11 |  |  |  | 5 |  |
| Other |  |  | (87 | ) |  |  | (109 | ) |
| Net cash used in investing activities |  |  | (2,387 | ) |  |  | (3,636 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Issuances of common stock |  |  | 701 |  |  |  | 1,162 |  |
| Repurchases of common stock—repurchase program |  |  | (2,344 | ) |  |  | (2,196 | ) |
| Shares repurchased for tax withholdings on vesting of restricted stock units |  |  | (412 | ) |  |  | (369 | ) |
| Short-term borrowings, original maturities less than 90 days, net |  |  | (4 | ) |  |  | (4 | ) |
| Repayments of debt |  |  | (862 | ) |  |  | (506 | ) |
| Excess tax benefits from share-based compensation |  |  | 82 |  |  |  | 83 |  |
| Dividends paid |  |  | (2,133 | ) |  |  | (1,947 | ) |
| Other |  |  | 108 |  |  |  | 110 |  |
| Net cash used in financing activities |  |  | (4,864 | ) |  |  | (3,667 | ) |
| Net decrease in cash and cash equivalents |  |  | (563 | ) |  |  | (1,929 | ) |
| Cash and cash equivalents, beginning of period |  |  | 6,877 |  |  |  | 6,726 |  |
| Cash and cash equivalents, end of period |  | $ | 6,314 |  |  | $ | 4,797 |  |
| Supplemental cash flow information: |  |  |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 426 |  |  | $ | 383 |  |
| Cash paid for income taxes, net |  | $ | 1,355 |  |  | $ | 1,152 |  |

[0001193125-16-457586:8k_2_02:99]
Certain reclassifications have been made to prior year amounts to conform to the current year’s
presentation.

[0001193125-16-457586:8k_2_02:100]
10

[0001193125-16-457586:8k_2_02:101]
CISCO SYSTEMS, INC.

[0001193125-16-457586:8k_2_02:102]
DEFERRED REVENUE

[0001193125-16-457586:8k_2_02:103]
(In
millions)

[0001193125-16-457586:8k_2_02:104]
|  |  | January 23,2016 |  |  | October 24,2015 |  |  | January 24,2015 |  |
| Deferred revenue: |  |  |  |  |  |  |  |  |  |  |  |  |
| Service |  | $ | 9,657 |  |  | $ | 9,689 |  |  | $ | 9,020 |  |
| Product: |  |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized revenue on product shipments and other deferred revenue |  |  | 4,974 |  |  |  | 4,888 |  |  |  | 4,276 |  |
| Cash receipts related to unrecognized revenue from two-tier distributors |  |  | 554 |  |  |  | 585 |  |  |  | 725 |  |
| Total product deferred revenue |  |  | 5,528 |  |  |  | 5,473 |  |  |  | 5,001 |  |
| Total |  | $ | 15,185 |  |  | $ | 15,162 |  |  | $ | 14,021 |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |  |
| Current |  | $ | 9,796 |  |  | $ | 9,821 |  |  | $ | 9,369 |  |
| Noncurrent |  |  | 5,389 |  |  |  | 5,341 |  |  |  | 4,652 |  |
| Total |  | $ | 15,185 |  |  | $ | 15,162 |  |  | $ | 14,021 |  |

[0001193125-16-457586:8k_2_02:105]
CISCO SYSTEMS, INC.

[0001193125-16-457586:8k_2_02:106]
INVENTORIES AND INVENTORY TURNS

[0001193125-16-457586:8k_2_02:107]
(In millions, except annualized inventory turns)

[0001193125-16-457586:8k_2_02:108]
|  |  | January 23,2016 |  |  | October 24,2015 |  |  | January 24,2015 |  |
| Inventories: |  |  |  |  |  |  |  |  |  |  |  |  |
| Raw materials |  | $ | 99 |  |  | $ | 107 |  |  | $ | 265 |  |
| Work in process |  |  | 1 |  |  |  | 1 |  |  |  | 2 |  |
| Finished goods: |  |  |  |  |  |  |  |  |  |  |  |  |
| Distributor inventory and deferred cost of sales |  |  | 564 |  |  |  | 631 |  |  |  | 733 |  |
| Manufactured finished goods |  |  | 446 |  |  |  | 464 |  |  |  | 577 |  |
| Total finished goods |  |  | 1,010 |  |  |  | 1,095 |  |  |  | 1,310 |  |
| Service-related spares |  |  | 224 |  |  |  | 240 |  |  |  | 274 |  |
| Demonstration systems |  |  | 28 |  |  |  | 39 |  |  |  | 39 |  |
| Total |  | $ | 1,362 |  |  | $ | 1,482 |  |  | $ | 1,890 |  |
| Annualized inventory turns - GAAP |  |  | 12.6 |  |  |  | 12.5 |  |  |  | 10.9 |  |
| Cost of sales adjustments |  |  | (0.4 | ) |  |  | (0.5 | ) |  |  | (0.7 | ) |
| Annualized inventory turns - non-GAAP |  |  | 12.2 |  |  |  | 12.0 |  |  |  | 10.2 |  |

[0001193125-16-457586:8k_2_02:109]
11

[0001193125-16-457586:8k_2_02:110]
CISCO SYSTEMS, INC.

[0001193125-16-457586:8k_2_02:111]
DIVIDENDS PAID AND REPURCHASES OF COMMON STOCK

[0001193125-16-457586:8k_2_02:112]
(In millions, except per-share amounts)

[0001193125-16-457586:8k_2_02:113]
|  |  | DIVIDENDS |  |  | STOCK REPURCHASE PROGRAM |  |  | TOTAL |  |
| Quarter Ended |  | Per Share |  |  | Amount |  |  | Shares |  |  | Weighted-Average Priceper Share |  |  | Amount |  |  | Amount |  |
| Fiscal 2016 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| January 23, 2016 |  | $ | 0.21 |  |  | $ | 1,065 |  |  |  | 48 |  |  | $ | 26.12 |  |  | $ | 1,262 |  |  | $ | 2,327 |  |
| October 24, 2015 |  | $ | 0.21 |  |  | $ | 1,068 |  |  |  | 45 |  |  | $ | 26.83 |  |  | $ | 1,207 |  |  | $ | 2,275 |  |
| Fiscal 2015 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| July 25, 2015 |  | $ | 0.21 |  |  | $ | 1,069 |  |  |  | 35 |  |  | $ | 28.62 |  |  | $ | 1,005 |  |  | $ | 2,074 |  |
| April 25, 2015 |  |  | 0.21 |  |  |  | 1,070 |  |  |  | 35 |  |  |  | 28.39 |  |  |  | 1,008 |  |  |  | 2,078 |  |
| January 24, 2015 |  |  | 0.19 |  |  |  | 974 |  |  |  | 44 |  |  |  | 27.63 |  |  |  | 1,208 |  |  |  | 2,182 |  |
| October 25, 2014 |  |  | 0.19 |  |  |  | 973 |  |  |  | 41 |  |  |  | 24.58 |  |  |  | 1,013 |  |  |  | 1,986 |  |
| Total |  | $ | 0.80 |  |  | $ | 4,086 |  |  |  | 155 |  |  | $ | 27.22 |  |  | $ | 4,234 |  |  | $ | 8,320 |  |

[0001193125-16-457586:8k_2_02:114]
CISCO SYSTEMS, INC.

[0001193125-16-457586:8k_2_02:115]
FREE CASH FLOW

[0001193125-16-457586:8k_2_02:116]
(In
millions)

[0001193125-16-457586:8k_2_02:117]
|  |  | Three Months Ended |  |
|  |  | January 23, 2016 |  |  | October 24, 2015 |  |  | January 24, 2015 |  |
| Net cash provided by operating activities |  | $ | 3,922 |  |  | $ | 2,766 |  |  | $ | 2,883 |  |
| Acquisition of property and equipment |  |  | (314 | ) |  |  | (262 | ) |  |  | (265 | ) |
| Free cash flow |  | $ | 3,608 |  |  | $ | 2,504 |  |  | $ | 2,618 |  |

[0001193125-16-457586:8k_2_02:118]
12

[0001193125-16-457586:8k_2_02:119]
CISCO SYSTEMS, INC.

[0001193125-16-457586:8k_2_02:120]
SUPPLEMENTARY INFORMATION - RECONCILIATIONS OF GAAP TO NON-GAAP MEASURES

[0001193125-16-457586:8k_2_02:121]
GROSS MARGINS, OPERATING EXPENSES, OPERATING MARGINS, AND NET INCOME

[0001193125-16-457586:8k_2_02:122]
(In millions, except percentages)

[0001193125-16-457586:8k_2_02:123]
|  |  | Three Months Ended January 23, 2016 |  |
|  |  |  | ProductGross Margin |  |  |  | Service Gross Margin |  |  |  | Total Gross Margin |  |  |  | Operating Expenses |  |  |  | Y/Y |  |  |  | Operating Income |  |  |  | Y/Y |  |  |  | Net Income |  |  |  | Y/Y |  |
| GAAP amount |  | $ | 5,503 |  |  | $ | 1,929 |  |  | $ | 7,432 |  |  | $ | 4,138 |  |  |  | (7)% |  |  | $ | 3,294 |  |  |  | 26% |  |  | $ | 3,147 |  |  |  | 31% |  |
| % of revenue |  |  | 61.3% |  |  |  | 65.5% |  |  |  | 62.3% |  |  |  | 34.7% |  |  |  |  |  |  |  | 27.6% |  |  |  |  |  |  |  | 26.4% |  |  |  |  |  |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 16 |  |  |  | 35 |  |  |  | 51 |  |  |  | 280 |  |  |  |  |  |  |  | 331 |  |  |  |  |  |  |  | 331 |  |  |  |  |  |
| Amortization of acquisition-related intangible assets |  |  | 123 |  |  |  | — |  |  |  | 123 |  |  |  | 71 |  |  |  |  |  |  |  | 194 |  |  |  |  |  |  |  | 194 |  |  |  |  |  |
| Acquisition-related/divestiture costs |  |  | — |  |  |  | 1 |  |  |  | 1 |  |  |  | (222) |  |  |  |  |  |  |  | (221) |  |  |  |  |  |  |  | (221) |  |  |  |  |  |
| Significant asset impairments and restructurings |  |  | (1) |  |  |  | — |  |  |  | (1) |  |  |  | 96 |  |  |  |  |  |  |  | 95 |  |  |  |  |  |  |  | 95 |  |  |  |  |  |
| Income tax/significant tax matters |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  |  |  |  | — |  |  |  |  |  |  |  | (617) |  |  |  |  |  |
| Non-GAAP amount |  | $ | 5,641 |  |  | $ | 1,965 |  |  | $ | 7,606 |  |  | $ | 3,913 |  |  |  | (2)% |  |  | $ | 3,693 |  |  |  | 9% |  |  | $ | 2,929 |  |  |  | 7% |  |
| % of revenue |  |  | 62.8% |  |  |  | 66.7% |  |  |  | 63.8% |  |  |  | 32.8% |  |  |  |  |  |  |  | 31.0% |  |  |  |  |  |  |  | 24.6% |  |  |  |  |  |
| Less: SP Video CPE Business* |  |  | (13) |  |  |  | — |  |  |  | (13) |  |  |  | (11) |  |  |  |  |  |  |  | (2) |  |  |  |  |  |  |  | (2) |  |  |  |  |  |
| Non-GAAP amount (excluding SP Video CPE Business) |  | $ | 5,628 |  |  | $ | 1,965 |  |  | $ | 7,593 |  |  | $ | 3,902 |  |  |  | (1)% |  |  | $ | 3,691 |  |  |  | 10% |  |  | $ | 2,927 |  |  |  | 8% |  |
| % of revenue |  |  | 63.3% |  |  |  | 66.7% |  |  |  | 64.2% |  |  |  | 33.0% |  |  |  |  |  |  |  | 31.2% |  |  |  |  |  |  |  | 24.7% |  |  |  |  |  |

[0001193125-16-457586:8k_2_02:124]
*Reflects one month of operations for the SP Video CPE Business, which was divested during the second quarter on November 20,
2015.

[0001193125-16-457586:8k_2_02:125]
|  |  | Three Months EndedJanuary 24, 2015 |  |
|  |  | ProductGross Margin |  |  | ServiceGross Margin |  |  | TotalGross Margin |  |  | Operating Expenses |  |  | Operating Income |  |  | Net Income |  |
| GAAP amount |  | $ | 5,272 |  |  | $ | 1,818 |  |  | $ | 7,090 |  |  | $ | 4,468 |  |  | $ | 2,622 |  |  | $ | 2,397 |  |
| Adjustments to GAAP amounts: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 11 |  |  |  | 34 |  |  |  | 45 |  |  |  | 261 |  |  |  | 306 |  |  |  | 306 |  |
| Amortization of acquisition-related intangible assets |  |  | 233 |  |  |  | — |  |  |  | 233 |  |  |  | 72 |  |  |  | 305 |  |  |  | 305 |  |
| Acquisition-related/divestiture costs |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 92 |  |  |  | 92 |  |  |  | 92 |  |
| Significant asset impairments and restructurings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 69 |  |  |  | 69 |  |  |  | 69 |  |
| Gain on VCE reorganization |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (126) |  |
| Income tax/significant tax matters |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (298) |  |
| Non-GAAP amount |  | $ | 5,516 |  |  | $ | 1,852 |  |  | $ | 7,368 |  |  | $ | 3,974 |  |  | $ | 3,394 |  |  | $ | 2,745 |  |
| Less: SP Video CPE Business* |  |  | (66) |  |  |  | — |  |  |  | (66) |  |  |  | (35) |  |  |  | (31) |  |  |  | (24) |  |
| Non-GAAP amount (excluding SP Video CPE Business) |  | $ | 5,450 |  |  | $ | 1,852 |  |  | $ | 7,302 |  |  | $ | 3,939 |  |  | $ | 3,363 |  |  | $ | 2,721 |  |

[0001193125-16-457586:8k_2_02:126]
*Reflects three months of operations for the SP Video CPE Business.

[0001193125-16-457586:8k_2_02:127]
EFFECTIVE TAX RATE

[0001193125-16-457586:8k_2_02:128]
(In percentages)

[0001193125-16-457586:8k_2_02:129]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | January 23,2016 |  |  | January 24,2015 |  |  | January 23,2016 |  |  | January 24,2015 |  |
| GAAP effective tax rate |  |  | 4.8 | % |  |  | 16.6 | % |  |  | 13.4 | % |  |  | 19.3 | % |
| Tax effect of non-GAAP adjustments to net income |  |  | 16.1 | % |  |  | 5.4 | % |  |  | 8.6 | % |  |  | 2.7 | % |
| Non-GAAP effective tax rate |  |  | 20.9 | % |  |  | 22.0 | % |  |  | 22.0 | % |  |  | 22.0 | % |

[0001193125-16-457586:8k_2_02:130]
COST OF SALES USED IN INVENTORY TURNS

[0001193125-16-457586:8k_2_02:131]
(In millions)

[0001193125-16-457586:8k_2_02:132]
|  |  | Three Months Ended |  |
|  |  | January 23,2016 |  |  | October 24,2015 |  |  | January 24,2015 |  |
| GAAP cost of sales |  | $ | 4,495 |  |  | $ | 4,850 |  |  | $ | 4,846 |  |
| Cost of sales adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | (51 | ) |  |  | (51 | ) |  |  | (45 | ) |
| Amortization of acquisition-related intangible assets |  |  | (123 | ) |  |  | (128 | ) |  |  | (233 | ) |
| Acquisition-related/divestiture costs |  |  | (1 | ) |  |  | — |  |  |  | — |  |
| Significant asset impairments and restructurings |  |  | 1 |  |  |  | 1 |  |  |  | — |  |
| Non-GAAP cost of sales |  | $ | 4,321 |  |  | $ | 4,672 |  |  | $ | 4,568 |  |

[0001193125-16-457586:8k_2_02:133]
14

[0001193125-16-457586:8k_2_02:134]
Forward Looking Statements, Non-GAAP Information and Additional Information

[0001193125-16-457586:8k_2_02:135]
This release includes non-GAAP net income, non-GAAP gross margins, non-GAAP operating expenses, non-GAAP operating income and margin, non-GAAP effective tax
rates, non-GAAP net income per share data, non-GAAP inventory turns and free cash flow for the periods presented. It also includes future estimated ranges for gross margin, operating margin, tax provision rate and EPS on a non-GAAP basis.

[0001193125-16-457586:8k_2_02:136]
These non-GAAP measures are not in accordance with, or an alternative for, measures prepared in accordance with generally accepted accounting principles and
may be different from non-GAAP measures used by other companies. In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules or principles. Cisco believes that non-GAAP measures have limitations in that they do
not reflect all of the amounts associated with Cisco’s results of operations as determined in accordance with GAAP and that these measures should only be used to evaluate Cisco’s results of operations in conjunction with the corresponding
GAAP measures.

[0001193125-16-457586:8k_2_02:137]
Cisco believes that the presentation of non-GAAP measures when shown in conjunction with the corresponding GAAP measures, provides useful
information to investors and management regarding financial and business trends relating to its financial condition and its historical and projected results of operations. In addition, Cisco believes that the presentation of non-GAAP inventory turns
provides useful information to investors and management regarding financial and business trends relating to inventory management based on the operating activities of the periods presented. Cisco believes that the presentation of free cash flow,
which it defines as the net cash provided by operating activities less cash used to acquire property and equipment, to be a liquidity measure that provides useful information to management and investors because of its intent to return a stated
percentage of free cash flow to shareholders in the form of dividends and stock repurchases. Cisco further regards free cash flow as a useful measure because it reflects cash that can be used to, among other things, invest in its business, make
strategic acquisitions, repurchase common stock and pay dividends on its common stock, after deducting capital investments.

[0001193125-16-457586:8k_2_02:138]
For its internal budgeting
process, Cisco’s management uses financial statements that do not include, when applicable, share-based compensation expense, amortization of acquisition-related intangible assets, impact to cost of sales from purchase accounting adjustments to
inventory, acquisition-related/divestiture costs, significant asset impairments and restructurings, significant litigation and other contingencies, the income tax effects of the foregoing and significant tax matters. Cisco’s

[0001193125-16-457586:8k_2_02:139]
management also uses the foregoing non-GAAP measures, in addition to the corresponding GAAP measures, in reviewing the financial results of Cisco. In prior periods, Cisco has excluded other items
that it no longer excludes for purposes of its non-GAAP financial measures. From time to time in the future there may be other items that Cisco may exclude for purposes of its internal budgeting process and in reviewing its financial results. For
additional information on the items excluded by Cisco from one or more of its non-GAAP financial measures, refer to the Form 8-K regarding this release furnished today to the Securities and Exchange Commission.

[0001193125-16-457586:8k_2_02:140]
Cisco divested the Customer Premises Equipment portion of the Service Provider Video Connected Devices business (“SP Video CPE Business”) during the
second quarter of fiscal 2016 on November 20, 2015. This release includes, where indicated, financial measures that exclude the SP Video CPE Business. Cisco believes that the presentation of these measures provides useful information to investors
and management regarding financial and business trends relating to its financial condition and its historical and projected results of operations because the SP Video CPE Business will not be part of Cisco on a go forward basis. Cisco’s
management also uses the financial measures excluding the SP Video CPE Business in reviewing the financial results of Cisco.

[0001193125-16-457586:8k_2_02:141]
About Cisco

[0001193125-16-457586:8k_2_02:142]
Cisco (NASDAQ: CSCO) is the worldwide technology leader that has been making the Internet work since 1984. Our people, products, and partners help society
securely connect and seize tomorrow’s digital opportunity today. Discover more at thenetwork.cisco.com and follow us on Twitter at @Cisco.

[0001193125-16-457586:8k_2_02:143]
Copyright © 2016 Cisco and/or its affiliates. All rights reserved. Cisco and the Cisco logo are
trademarks or registered trademarks of Cisco and/or its affiliates in the U.S. and other countries. To view a list of Cisco trademarks, go to: www.cisco.com/go/trademarks. Third-party trademarks mentioned in this document are the property of their
respective owners. The use of the word partner does not imply a partnership relationship between Cisco and any other company. This document is Cisco Public Information.

[0001193125-16-457586:8k_2_02:144]
16
