# CSCO MD&A — 0000858877-16-000090


## mdna

[0000858877-16-000090:mdna:1]
[same as prior period, unchanged from 0000858877-15-000073:mdna:1]

[0000858877-16-000090:mdna:2]
[same as prior period, unchanged from 0000858877-15-000073:mdna:2]

[0000858877-16-000090:mdna:3]
[same as prior period, unchanged from 0000858877-15-000073:mdna:3]

[0000858877-16-000090:mdna:4]
Cisco designs and sells broad lines of products, provides services and delivers integrated solutions to develop and connect networks around the world, building the Internet. Over the last 30-plus years, we have been the world’s leader in connecting people, things and technologies - to each other and to the Internet - realizing our vision of changing the way the world works, lives, plays and learns.

[0000858877-16-000090:mdna:5]
Today, we have over 70,000 employees in over 400 offices worldwide who design, produce, sell, and deliver integrated products, services, and solutions. Over time, we have expanded to new markets that are a natural extension of our core networking business, as the network has become the platform for automating, orchestrating, integrating, and delivering an ever-increasing array of information technology (IT)–based products and services. A summary of our results is as follows (in millions, except percentages and per-share amounts):

[0000858877-16-000090:mdna:6]
|  | Three Months Ended |  | Six Months Ended |  |
|  | January 23, 2016 |  | January 24, 2015 |  | Variance |  | January 23, 2016 |  | January 24, 2015 |  | Variance |  |
| Revenue (1) | $ | 11,927 |  |  | $ | 11,936 |  |  | (0.1 | )% |  | $ | 24,609 |  |  | $ | 24,181 |  |  | 1.8 | % |  |
| Gross margin percentage | 62.3 | % |  | 59.4 | % |  | 2.9 |  | pts | 62.0 | % |  | 59.6 | % |  | 2.4 |  | pts |
| Research and development | $ | 1,509 |  |  | $ | 1,529 |  |  | (1.3 | )% |  | $ | 3,069 |  |  | $ | 3,112 |  |  | (1.4 | )% |  |
| Sales and marketing | $ | 2,286 |  |  | $ | 2,308 |  |  | (1.0 | )% |  | $ | 4,729 |  |  | $ | 4,823 |  |  | (1.9 | )% |  |
| General and administrative | $ | 176 |  |  | $ | 490 |  |  | (64.1 | )% |  | $ | 715 |  |  | $ | 994 |  |  | (28.1 | )% |  |
| Total research and development, sales and marketing, general and administrative | $ | 3,971 |  |  | $ | 4,327 |  |  | (8.2 | )% |  | $ | 8,513 |  |  | $ | 8,929 |  |  | (4.7 | )% |  |
| Total as a percentage of revenue | 33.3 | % |  | 36.3 | % |  | (3.0 | ) | pts | 34.6 | % |  | 36.9 | % |  | (2.3 | ) | pts |
| Amortization of purchased intangible assets included in operating expenses | $ | 71 |  |  | $ | 72 |  |  | (1.4 | )% |  | $ | 140 |  |  | $ | 143 |  |  | (2.1 | )% |  |
| Restructuring and other charges included in operating expenses | $ | 96 |  |  | $ | 69 |  |  | 39.1 | % |  | $ | 238 |  |  | $ | 387 |  |  | (38.5 | )% |  |
| Operating income as a percentage of revenue | 27.6 | % |  | 22.0 | % |  | 5.6 |  | pts | 25.9 | % |  | 20.5 | % |  | 5.4 |  | pts |
| Income tax percentage | 4.8 | % |  | 16.6 | % |  | (11.8 | ) | pts | 13.4 | % |  | 19.3 | % |  | (5.9 | ) | pts |
| Net income | $ | 3,147 |  |  | $ | 2,397 |  |  | 31.3 | % |  | $ | 5,577 |  |  | $ | 4,225 |  |  | 32.0 | % |  |
| Net income as a percentage of revenue | 26.4 | % |  | 20.1 | % |  | 6.3 |  | pts | 22.7 | % |  | 17.5 | % |  | 5.2 |  | pts |
| Earnings per share—diluted | $ | 0.62 |  |  | $ | 0.46 |  |  | 34.8 | % |  | $ | 1.09 |  |  | $ | 0.82 |  |  | 32.9 | % |  |

[0000858877-16-000090:mdna:7]
(1) During the second quarter of fiscal 2016, we completed the sale of the Customer Premises Equipment portion of our Service Provider Video Connected Devices business ("SP Video CPE Business"). As a result, revenue from this portion of the Service Provider Video product category will not recur in future periods. Includes SP Video CPE Business revenue of $93 million (one month of operations) and $361 million for the second quarter of fiscal 2016 and 2015, respectively and $504 million and $840 million for the first six months of fiscal 2016 and 2015, respectively.

[0000858877-16-000090:mdna:8]
[same as prior period, unchanged from 0000858877-15-000073:mdna:8]

[0000858877-16-000090:mdna:9]
[same as prior period, unchanged from 0000858877-15-000073:mdna:9]

[0000858877-16-000090:mdna:10]
Three Months Ended January 23, 2016 Compared with Three Months Ended January 24, 2015

[0000858877-16-000090:mdna:11]
In the second quarter of fiscal 2016, revenue was flat as compared with the second quarter of fiscal 2015. Within total revenue, product revenue decreased 1% while service revenue increased 3%. On November 20, 2015, we completed the sale of our SP Video CPE Business. Total company revenue, not including revenue from SP Video CPE products, for the second quarter of fiscal 2016 increased 2%. Total gross margin increased by 2.9 percentage points, driven by the sale of the lower margin SP Video CPE Business, lower amortization of purchased intangible assets, and productivity improvements. As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses, collectively, decreased by 3.0 percentage points, reflecting the recognition of an approximate $0.3 billion pre-tax gain from the sale of our SP Video CPE Business and benefits from foreign exchange. Operating income as a percentage of revenue increased by 5.6 percentage points, driven by the factors discussed above. Diluted earnings per share increased by 35% from the prior year, driven by a 31% increase in net income. In addition to the preceding items, a significant portion of the increase in net income was attributable to certain tax benefits of approximately $0.5 billion. These tax benefits relate to our settlement with the IRS of all outstanding items related to the audit of our federal income tax returns covering the period from fiscal 2008 through fiscal 2010 and the permanent reinstatement of the U.S. federal R&D tax credit.

[0000858877-16-000090:mdna:12]
In the second quarter of fiscal 2016, revenue from the Americas decreased by $0.2 billion compared with the second quarter of fiscal 2015, driven in large part by the sale of the SP Video CPE Business which also led to lower product revenue in the United States. Revenue in our APJC segment increased $0.2 billion, led by product revenue growth in China. EMEA revenue was flat. We saw improvements in our revenue from many emerging countries, and in particular we experienced increased product revenue in the emerging countries of China, India and Mexico of 51%, 33% and 25%, respectively. Overall, the “BRICM” countries experienced, in the aggregate, product revenue growth of 15%, despite decreased product revenue in Brazil and Russia of 49% and 27%, respectively.

[0000858877-16-000090:mdna:13]
From a customer market standpoint, in the second quarter of fiscal 2016 we experienced product revenue declines in the public sector and enterprise markets. We believe our sales in the enterprise market were impacted by uncertainty in the macro environment, which led to a slowdown in customer spending, and by currency impacts. Our product revenue in the commercial market increased, which we believe was also impacted, to a lesser degree, by the uncertainty in the macro environment and currency impacts. Our product revenue in the service provider market was flat, as the impact of the sale of the SP Video CPE Business was offset by increased sales of our other products to this customer market.

[0000858877-16-000090:mdna:14]
During the prior two fiscal years we have encountered business challenges in the service provider market and certain emerging countries.  Although we saw positive business momentum in these areas during the first half of fiscal 2016, we continue to monitor and assess the sustainability of improvements in these areas.

[0000858877-16-000090:mdna:15]
From a product category perspective, total company product revenue, not including SP Video CPE products, increased 2% year over year. This increase was led by product revenue growth in Security, NGN Routing and Collaboration products which grew 11%, 5% and 3%, respectively. Offsetting these increases, we experienced a 4% decrease in sales of Switching products and a 3% decrease in our Data Center products. We believe the decline in sales of our Switching products used in campus environments (which comprises the majority of this product category) and Data Center products were largely driven by the uncertainty in the macro environment, which led to a slowdown in customer spending.

[0000858877-16-000090:mdna:16]
Six Months Ended January 23, 2016 Compared with Six Months Ended January 24, 2015

[0000858877-16-000090:mdna:17]
Diluted earnings per share increased by 33% from the prior year, a result of a 32% increase in net income. Revenue increased 2%, with product and service revenue each increasing 2%. Total gross margin increased by 2.4 percentage points driven in part by the Rockstar patent portfolio charge of $188 million (or 0.8 percentage points of the prior period revenue) recorded in the first quarter of fiscal 2015. As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses collectively decreased by 2.3 percentage points. Operating income as a percentage of revenue increased by 5.4 percentage points. Net income for the first six months of fiscal 2016 benefited from a lower effective tax rate, from the tax benefits discussed above.

[0000858877-16-000090:mdna:18]
[same as prior period, unchanged from 0000858877-15-000073:mdna:65]

[0000858877-16-000090:mdna:19]
[same as prior period, unchanged from 0000858877-15-000073:mdna:17]

[0000858877-16-000090:mdna:20]
[same as prior period, unchanged from 0000858877-15-000073:mdna:18]

[0000858877-16-000090:mdna:21]
[same as prior period, unchanged from 0000858877-15-000073:mdna:19]

[0000858877-16-000090:mdna:22]
We see our customers, in every industry, increasingly using technology—and, specifically, the network—to grow their business, drive efficiencies, and try to gain a competitive advantage. In this increasingly digital world, data is the most strategic asset and is increasingly distributed across every organization and ecosystem—on customer premises, at the edge of the network, and in the cloud. The network also plays an increasingly important role enabling our customers to aggregate, automate, and draw insights from this highly distributed data where there is a premium on security and speed. This is driving them to adopt entirely new IT architectures and organizational structures. We understand how technology can deliver the outcomes our customers want to achieve, and our strategy is to lead our customers in their digital transition with solutions, including pervasive, industry-leading security and analytics, that intelligently connect nearly everything that can be connected.

[0000858877-16-000090:mdna:23]
To deliver on our strategy, we are focused on providing highly secure, automated and intelligent solutions built on infrastructure that connects data that is highly distributed (globally dispersed across organizations). Together with our ecosystem of partners and developers, we aim to provide the technology, services, and solutions that we believe will enable our customers to gain insight and advantage from this distributed data with scale, security and agility.

[0000858877-16-000090:mdna:24]
[same as prior period, unchanged from 0000858877-15-000073:mdna:22]

[0000858877-16-000090:mdna:25]
[same as prior period, unchanged from 0000858877-15-000073:mdna:23]

[0000858877-16-000090:mdna:26]
The following is a summary of our other key financial measures for the second quarter and first six months of fiscal 2016 (in millions, except days sales outstanding in accounts receivable (DSO) and annualized inventory turns):

[0000858877-16-000090:mdna:27]
|  |  | January 23, 2016 |  | July 25, 2015 |
| Cash and cash equivalents and investments |  | $ | 60,375 |  |  | $ | 60,416 |  |
| Deferred revenue |  | $ | 15,185 |  |  | $ | 15,183 |  |
| DSO |  | 33 days |  |  | 38 days |  |
| Inventories |  | $ | 1,362 |  |  | $ | 1,627 |  |
| Annualized inventory turns |  | 12.6 |  |  | 12.1 |  |

[0000858877-16-000090:mdna:28]
|  |  | Six Months Ended |
|  |  | January 23, 2016 |  | January 24, 2015 |
| Cash provided by operating activities |  | $ | 6,688 |  |  | $ | 5,374 |  |
| Repurchases of common stock—stock repurchase program |  | $ | 2,469 |  |  | $ | 2,221 |  |
| Dividends |  | $ | 2,133 |  |  | $ | 1,947 |  |

[0000858877-16-000090:mdna:29]
[same as prior period, unchanged from 0000858877-15-000073:mdna:78]

[0000858877-16-000090:mdna:30]
[same as prior period, unchanged from 0000858877-15-000073:mdna:28]

[0000858877-16-000090:mdna:31]
[same as prior period, unchanged from 0000858877-15-000073:mdna:29]

[0000858877-16-000090:mdna:32]
[same as prior period, unchanged from 0000858877-15-000073:mdna:30]

[0000858877-16-000090:mdna:33]
The preparation of financial statements and related disclosures in conformity with accounting principles generally accepted in the United States requires us to make judgments, assumptions, and estimates that affect the amounts reported in the Consolidated Financial Statements and accompanying notes. Note 2 to the Consolidated Financial Statements in our Annual Report on Form 10-K for the year ended July 25, 2015, as updated as applicable in Note 2 to the Consolidated Financial Statements herein, describes the significant accounting policies and methods used in the preparation of the Consolidated Financial Statements. The accounting policies described below are significantly affected by critical accounting estimates. Such accounting policies require significant judgments, assumptions, and estimates used in the preparation of the Consolidated Financial Statements, and actual results could differ materially from the amounts reported based on these policies.

[0000858877-16-000090:mdna:34]
[same as prior period, unchanged from 0000858877-15-000073:mdna:32]

[0000858877-16-000090:mdna:35]
[same as prior period, unchanged from 0000858877-15-000073:mdna:33]

[0000858877-16-000090:mdna:36]
[same as prior period, unchanged from 0000858877-15-000073:mdna:34]

[0000858877-16-000090:mdna:37]
[same as prior period, unchanged from 0000858877-15-000073:mdna:35]

[0000858877-16-000090:mdna:38]
[same as prior period, unchanged from 0000858877-15-000073:mdna:36]

[0000858877-16-000090:mdna:39]
[same as prior period, unchanged from 0000858877-15-000073:mdna:37]

[0000858877-16-000090:mdna:40]
In instances where final acceptance of the product, system, or solution is specified by the customer, revenue is deferred until all acceptance criteria have been met. When a sale involves multiple deliverables, such as sales of products that include services, the multiple deliverables are evaluated to determine the unit of accounting, and the entire fee from the arrangement is allocated to each unit of accounting based on the relative selling price. Revenue is recognized when the revenue recognition criteria for each unit of accounting are met.  For hosting arrangements, we recognize subscription revenue ratably over the subscription period, while usage revenue is recognized based on utilization. Software subscription revenue is deferred and recognized ratably over the subscription term upon delivery of the first product and commencement of the term.

[0000858877-16-000090:mdna:41]
The amount of product and service revenue recognized in a given period is affected by our judgment as to whether an arrangement includes multiple deliverables and, if so, our valuation of the units of accounting for multiple deliverables. According to the accounting guidance prescribed in Accounting Standards Codification (ASC) 605, Revenue Recognition, we use vendor-specific objective evidence of selling price (VSOE) for each of those units, when available. We determine VSOE based on our normal pricing and discounting practices for the specific product or service when sold separately. In determining VSOE, we require that a substantial majority of the historical standalone transactions have the selling prices for a product or service fall within a reasonably narrow pricing range, generally evidenced by approximately 80% of such historical standalone transactions falling within plus or minus 15% of the median rates. When VSOE does not exist, we apply the selling price hierarchy to applicable multiple-deliverable arrangements. Under the selling price hierarchy, third-party evidence of selling price (TPE) will be considered if VSOE does not exist, and estimated selling price (ESP) will be used if neither VSOE nor TPE is available. Generally, we are not able to determine TPE because our go-to-market strategy differs from that of others in our markets, and the extent of our proprietary technology varies among comparable products or services from those of our peers. In determining ESP, we apply significant judgment as we weigh a variety of factors, based on the facts and circumstances of the arrangement. We typically arrive at an ESP for a product or service that is not sold separately by considering company-specific factors such as geographies, competitive landscape, internal costs, profitability objectives, pricing practices used to establish bundled pricing, and existing portfolio pricing and discounting.

[0000858877-16-000090:mdna:42]
[same as prior period, unchanged from 0000858877-15-000073:mdna:40]

[0000858877-16-000090:mdna:43]
As our business and offerings evolve over time, our pricing practices may be required to be modified accordingly, which could result in changes in selling prices, including both VSOE and ESP, in subsequent periods. There were no material impacts during the first six months of fiscal 2016, nor do we currently expect a material impact in the next 12 months on our revenue recognition due to any changes in our VSOE, TPE, or ESP.

[0000858877-16-000090:mdna:44]
[same as prior period, unchanged from 0000858877-15-000073:mdna:90]

[0000858877-16-000090:mdna:45]
[same as prior period, unchanged from 0000858877-15-000073:mdna:42]

[0000858877-16-000090:mdna:46]
[same as prior period, unchanged from 0000858877-15-000073:mdna:43]

[0000858877-16-000090:mdna:47]
Revenue deferrals relate to the timing of revenue recognition for specific transactions based on financing arrangements, service, support, and other factors. Financing arrangements may include sales-type, direct-financing, and operating leases, loans, and guarantees of third-party financing. Our deferred revenue for products was $5.5 billion and $5.4 billion as of January 23, 2016 and July 25, 2015, respectively. Technical support services revenue is deferred and recognized ratably over the period during which the services are to be performed, which typically is from one to three years. Advanced services revenue is recognized upon delivery or completion of performance milestones. Our deferred revenue for services was $9.7 billion and $9.8 billion as of January 23, 2016 and July 25, 2015, respectively.

[0000858877-16-000090:mdna:48]
We make sales to distributors which we refer to as two-tier systems of sales to the end customer. Revenue from distributors is recognized based on a sell-through method using information provided by them. Our distributors participate in various cooperative marketing and other programs, and we maintain estimated accruals and allowances for these programs. If actual credits received by our distributors under these programs were to deviate significantly from our estimates, which are based on historical experience, our revenue could be adversely affected.

[0000858877-16-000090:mdna:49]
[same as prior period, unchanged from 0000858877-15-000073:mdna:46]

[0000858877-16-000090:mdna:50]
[same as prior period, unchanged from 0000858877-15-000073:mdna:47]

[0000858877-16-000090:mdna:51]
|  |  | January 23, 2016 |  | July 25, 2015 |
| Allowance for doubtful accounts |  | $ | 325 |  |  | $ | 302 |  |
| Percentage of gross accounts receivable |  | 7.0 | % |  | 5.4 | % |
| Allowance for credit loss—lease receivables |  | $ | 248 |  |  | $ | 259 |  |
| Percentage of gross lease receivables(1) |  | 7.3 | % |  | 7.2 | % |
| Allowance for credit loss—loan receivables |  | $ | 80 |  |  | $ | 87 |  |
| Percentage of gross loan receivables |  | 3.7 | % |  | 4.9 | % |

[0000858877-16-000090:mdna:52]
[same as prior period, unchanged from 0000858877-15-000073:mdna:49]

[0000858877-16-000090:mdna:53]
[same as prior period, unchanged from 0000858877-15-000073:mdna:50]

[0000858877-16-000090:mdna:54]
The allowance for credit loss on financing receivables is also based on the assessment of collectibility of customer accounts. We regularly review the adequacy of the credit allowances determined either on an individual or a collective basis. When evaluating the financing receivables on an individual basis, we consider historical experience, credit quality and age of receivable balances, and economic conditions that may affect a customer’s ability to pay. When evaluating financing receivables on a collective basis, we use expected default frequency rates published by a major third-party credit-rating agency as well as our own historical loss rate in the event of default, while also systematically giving effect to economic conditions, concentration of risk and correlation.  Determining expected default frequency rates and loss factors associated with internal credit risk ratings, as well as assessing factors such as economic conditions, concentration of risk, and correlation, are complex and subjective. Our ongoing consideration of all these factors could result in an increase in our allowance for credit loss in the future, which could adversely affect our operating results. Both accounts receivable and financing receivables are charged off at the point when they are considered uncollectible.

[0000858877-16-000090:mdna:55]
A reserve for future sales returns is established based on historical trends in product return rates. The reserve for future sales returns as of January 23, 2016 and July 25, 2015 was $118 million and $129 million, respectively, and was recorded as a reduction of our accounts receivable. If the actual future returns were to deviate from the historical data on which the reserve had been established, our revenue could be adversely affected.

[0000858877-16-000090:mdna:56]
[same as prior period, unchanged from 0000858877-15-000073:mdna:94]

[0000858877-16-000090:mdna:57]
[same as prior period, unchanged from 0000858877-15-000073:mdna:53]

[0000858877-16-000090:mdna:58]
[same as prior period, unchanged from 0000858877-15-000073:mdna:54]

[0000858877-16-000090:mdna:59]
[same as prior period, unchanged from 0000858877-15-000073:mdna:55]

[0000858877-16-000090:mdna:60]
Our inventory balance was $1.4 billion and $1.6 billion as of January 23, 2016 and July 25, 2015, respectively. Inventory is written down based on excess and obsolete inventories, determined primarily by future demand forecasts. Inventory write-downs are measured as the difference between the cost of the inventory and market, based upon assumptions about future demand, and are charged to the provision for inventory, which is a component of our cost of sales. At the point of the loss recognition, a new, lower cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis.

[0000858877-16-000090:mdna:61]
We record a liability for firm, noncancelable, and unconditional purchase commitments with contract manufacturers and suppliers for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of January 23, 2016, the liability for these purchase commitments was $180 million, compared with $156 million as of July 25, 2015, and was included in other current liabilities.

[0000858877-16-000090:mdna:62]
Our provision for inventory was $41 million and $21 million for the first six months of fiscal 2016 and 2015, respectively. The provision for the liability related to purchase commitments with contract manufacturers and suppliers was $94 million and $59 million for the first six months of fiscal 2016 and 2015, respectively. If there were to be a sudden and significant decrease in demand for our products, or if there were a higher incidence of inventory obsolescence because of rapidly changing technology and customer requirements, we could be required to increase our inventory write-downs, and our liability for purchase commitments with contract manufacturers and suppliers, and accordingly our profitability, could be adversely affected. We regularly evaluate our exposure for inventory write-downs and the adequacy of our liability for purchase commitments. Inventory and supply chain management remain areas of focus as we balance the need to maintain supply chain flexibility to help ensure competitive lead times with the risk of inventory obsolescence, particularly in light of current macroeconomic uncertainties and conditions and the resulting potential for changes in future demand forecast.

[0000858877-16-000090:mdna:63]
Loss Contingencies and Product Warranties

[0000858877-16-000090:mdna:64]
We are subject to the possibility of various losses arising in the ordinary course of business. We consider the likelihood of impairment of an asset or the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated. We regularly evaluate information available to us to determine whether such accruals should be made or adjusted and whether new accruals are required.

[0000858877-16-000090:mdna:65]
Third parties, including customers, have in the past and may in the future assert claims or initiate litigation related to exclusive patent, copyright, trademark, and other intellectual property rights to technologies and related standards that are relevant to us. These assertions have increased over time as a result of our growth and the general increase in the pace of patent claims assertions, particularly in the United States. If any infringement or other intellectual property claim made against us by any third party is successful, or if we fail to develop non-infringing technology or license the proprietary rights on commercially reasonable terms and conditions, our business, operating results, and financial condition could be materially and adversely affected.

[0000858877-16-000090:mdna:66]
We have recorded a liability for the expected remediation cost for certain products sold in prior fiscal years containing memory components manufactured by a single supplier between 2005 and 2010. In February 2014, on the basis of the growing number of failures as described in Note 12 (f) to the Consolidated Financial Statements, we decided to expand our approach, which resulted in a charge to product cost of sales of $655 million being recorded for the second quarter of fiscal 2014. During the third quarter of fiscal 2015, we recorded an adjustment to product cost of sales of $164 million to reduce the liability, reflecting net lower than previously estimated future costs to remediate the impacted customer products. Estimating this liability is complex and subjective, and if we experience changes in a number of underlying assumptions and estimates such as a change in claims compared with our expectations, or if the cost of servicing these claims is different than expected, our estimated liability may be impacted.

[0000858877-16-000090:mdna:67]
Our liability for product warranties, included in other current liabilities, was $403 million as of January 23, 2016, compared with $449 million as of July 25, 2015. Our products are generally covered by a warranty for periods ranging from 90 days to five years, and for some products we provide a limited lifetime warranty. We accrue for warranty costs as part of our cost of sales based on associated material costs, technical support labor costs, and associated overhead. Material cost is estimated based primarily upon historical trends in the volume of product returns within the warranty period and the cost to repair or replace the equipment. Technical support labor cost is estimated based primarily upon historical trends in the rate of customer cases and the cost to support the customer cases within the warranty period. Overhead cost is applied based on estimated time to support warranty activities.

[0000858877-16-000090:mdna:68]
The provision for product warranties during the first six months of fiscal 2016 and 2015 was $322 million and $355 million, respectively. If we experience an increase in warranty claims compared with our historical experience, or if the cost of servicing warranty claims is greater than expected, our profitability could be adversely affected.

[0000858877-16-000090:mdna:69]
[same as prior period, unchanged from 0000858877-15-000073:mdna:107]

[0000858877-16-000090:mdna:70]
[same as prior period, unchanged from 0000858877-15-000073:mdna:66]

[0000858877-16-000090:mdna:71]
[same as prior period, unchanged from 0000858877-15-000073:mdna:67]

[0000858877-16-000090:mdna:72]
[same as prior period, unchanged from 0000858877-15-000073:mdna:68]

[0000858877-16-000090:mdna:73]
Our fixed income and publicly traded equity securities, collectively, are reflected in the Consolidated Balance Sheets at a fair value of $54.1 billion as of January 23, 2016, compared with $53.5 billion as of July 25, 2015. Our fixed income investment portfolio as of January 23, 2016 consisted primarily of high quality investment-grade securities. See Note 8 to the Consolidated Financial Statements.

[0000858877-16-000090:mdna:74]
[same as prior period, unchanged from 0000858877-15-000073:mdna:70]

[0000858877-16-000090:mdna:75]
[same as prior period, unchanged from 0000858877-15-000073:mdna:71]

[0000858877-16-000090:mdna:76]
The inputs and fair value are reviewed for reasonableness, may be further validated by comparison to publicly available information, and could be adjusted based on market indices or other information that management deems material to its estimate of fair value. The assessment of fair value can be difficult and subjective. However, given the relative reliability of the inputs we use to value our investment portfolio, and because substantially all of our valuation inputs are obtained using quoted market prices for similar or identical assets, we do not believe that the nature of estimates and assumptions affected by levels of subjectivity and judgment was material to the valuation of the investment portfolio as of January 23, 2016. Level 3 assets do not represent a significant portion of our total assets measured at fair value on a recurring basis as of January 23, 2016 and July 25, 2015.

[0000858877-16-000090:mdna:77]
[same as prior period, unchanged from 0000858877-15-000073:mdna:73]

[0000858877-16-000090:mdna:78]
[same as prior period, unchanged from 0000858877-15-000073:mdna:74]

[0000858877-16-000090:mdna:79]
[same as prior period, unchanged from 0000858877-15-000073:mdna:75]

[0000858877-16-000090:mdna:80]
[same as prior period, unchanged from 0000858877-15-000073:mdna:76]

[0000858877-16-000090:mdna:81]
There were no impairment charges on our investments in publicly traded equity securities in the first six months of fiscal 2016 and 2015. For the first six months of fiscal 2016, we recognized impairment charges of $3 million on our investments in fixed income securities, while there were no such impairment charges recognized in the first six months of fiscal 2015. Our ongoing consideration of all the factors described previously could result in additional impairment charges in the future, which could adversely affect our net income.

[0000858877-16-000090:mdna:82]
[same as prior period, unchanged from 0000858877-15-000073:mdna:79]

[0000858877-16-000090:mdna:83]
[same as prior period, unchanged from 0000858877-15-000073:mdna:80]

[0000858877-16-000090:mdna:84]
We also have investments in privately held companies, some of which are in the startup or development stages. Our investments in privately held companies as of January 23, 2016 were $964 million, compared with $897 million as of July 25, 2015, and were included in other assets. We monitor these investments for events or circumstances indicative of potential impairment, and we make appropriate reductions in carrying values if we determine that an impairment charge is required, based primarily on the financial condition and near-term prospects of these companies. These investments are inherently risky because the markets for the technologies or products these companies are developing are typically in the early stages and may never materialize. Our impairment charges on investments in privately held companies were $56 million and $3 million for the first six months of fiscal 2016 and 2015, respectively.

[0000858877-16-000090:mdna:85]
[same as prior period, unchanged from 0000858877-15-000073:mdna:82]

[0000858877-16-000090:mdna:86]
[same as prior period, unchanged from 0000858877-15-000073:mdna:83]

[0000858877-16-000090:mdna:87]
The goodwill recorded in the Consolidated Balance Sheets as of January 23, 2016 and July 25, 2015 was $25.0 billion and $24.5 billion, respectively. In response to changes in industry and market conditions, we could be required to strategically realign our resources and consider restructuring, disposing of, or otherwise exiting businesses, which could result in an impairment of goodwill. There was no impairment of goodwill in the first six months of fiscal 2016 and 2015.

[0000858877-16-000090:mdna:88]
We make judgments about the recoverability of purchased intangible assets with finite lives whenever events or changes in circumstances indicate that an impairment may exist. Recoverability of purchased intangible assets with finite lives is measured by comparing the carrying amount of the asset to the future undiscounted cash flows the asset is expected to generate. We review indefinite-lived intangible assets for impairment annually or whenever events or changes in circumstances indicate that the asset might be impaired. If the asset is considered to be impaired, the amount of any impairment is measured as the difference between the carrying value and the fair value of the impaired asset. Assumptions and estimates about future values and remaining useful lives of our purchased intangible assets are complex and subjective. They can be affected by a variety of factors, including external factors such as industry and economic trends, and internal factors such as changes in our business strategy and our internal forecasts.  Our impairment charges on purchased intangible assets were $37 million and $56 million for the first six months of fiscal 2016 and 2015, respectively. Our ongoing consideration of all the factors described previously could result in additional impairment charges in the future, which could adversely affect our net income.

[0000858877-16-000090:mdna:89]
[same as prior period, unchanged from 0000858877-15-000073:mdna:86]

[0000858877-16-000090:mdna:90]
We are subject to income taxes in the United States and numerous foreign jurisdictions. Our effective tax rates differ from the statutory rate, primarily due to the tax impact of state taxes, foreign operations, R&D tax credits, domestic manufacturing deductions, tax audit settlements, nondeductible compensation, international realignments, and transfer pricing adjustments. Our effective tax rate was 4.8% and 16.6% in the second quarter of fiscal 2016 and 2015, respectively. Our effective tax rate was 13.4% and 19.3% in the first six months of fiscal 2016 and 2015, respectively.

[0000858877-16-000090:mdna:91]
[same as prior period, unchanged from 0000858877-15-000073:mdna:88]

[0000858877-16-000090:mdna:92]
[same as prior period, unchanged from 0000858877-15-000073:mdna:89]

[0000858877-16-000090:mdna:93]
50

[0000858877-16-000090:mdna:94]
[same as prior period, unchanged from 0000858877-15-000073:mdna:91]

[0000858877-16-000090:mdna:95]
[same as prior period, unchanged from 0000858877-15-000073:mdna:92]

[0000858877-16-000090:mdna:96]
Our provision for income taxes is subject to volatility and could be adversely impacted by earnings being lower than anticipated in countries that have lower tax rates and higher than anticipated in countries that have higher tax rates; by changes in the valuation of our deferred tax assets and liabilities; by changes to domestic manufacturing deduction laws, regulations, or interpretations thereof; by expiration of or lapses in tax incentives; by transfer pricing adjustments, including the effect of acquisitions on our intercompany R&D cost-sharing arrangement and legal structure; by tax effects of nondeductible compensation; by tax costs related to intercompany realignments; by changes in accounting principles; or by changes in tax laws and regulations, treaties, or interpretations thereof, including possible changes to the taxation of earnings of our foreign subsidiaries, the deductibility of expenses attributable to foreign income, or the foreign tax credit rules. Significant judgment is required to determine the recognition and measurement attributes prescribed in the accounting guidance for uncertainty in income taxes. The Organisation for Economic Co-operation and Development (OECD), an international association comprised of 34 countries, including the United States, has recently made changes to numerous long-standing tax principles. There can be no assurance that these changes, once adopted by countries, will not have an adverse impact on our provision for income taxes. As a result of certain of our ongoing employment and capital investment actions and commitments, our income in certain countries is subject to reduced tax rates. Our failure to meet these commitments could adversely impact our provision for income taxes. In addition, we are subject to the continuous examination of our income tax returns by the Internal Revenue Service (IRS) and other tax authorities. We regularly assess the likelihood of adverse outcomes resulting from these examinations to determine the adequacy of our provision for income taxes. There can be no assurance that the outcomes from these continuous examinations will not have an adverse impact on our operating results and financial condition.

[0000858877-16-000090:mdna:97]
[same as prior period, unchanged from 0000858877-15-000073:mdna:147]

[0000858877-16-000090:mdna:98]
[same as prior period, unchanged from 0000858877-15-000073:mdna:95]

[0000858877-16-000090:mdna:99]
[same as prior period, unchanged from 0000858877-15-000073:mdna:96]

[0000858877-16-000090:mdna:100]
[same as prior period, unchanged from 0000858877-15-000073:mdna:97]

[0000858877-16-000090:mdna:101]
[same as prior period, unchanged from 0000858877-15-000073:mdna:98]

[0000858877-16-000090:mdna:102]
[same as prior period, unchanged from 0000858877-15-000073:mdna:99]

[0000858877-16-000090:mdna:103]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 23, 2016 |  | January 24, 2015 |  | Variancein Dollars |  | Variance in Percent |  | January 23, 2016 |  | January 24, 2015 |  | Variancein Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 8,983 |  |  | $ | 9,078 |  |  | $ | (95 | ) |  | (1.0 | )% |  | $ | 18,827 |  |  | $ | 18,513 |  |  | $ | 314 |  |  | 1.7 | % |
| Percentage of revenue |  | 75.3 | % |  | 76.1 | % |  |  |  |  |  | 76.5 | % |  | 76.6 | % |  |  |  |  |  |  |
| Service |  | 2,944 |  |  | 2,858 |  |  | 86 |  |  | 3.0 | % |  | 5,782 |  |  | 5,668 |  |  | 114 |  |  | 2.0 | % |
| Percentage of revenue |  | 24.7 | % |  | 23.9 | % |  |  |  |  |  | 23.5 | % |  | 23.4 | % |  |  |  |  |  |  |
| Total |  | $ | 11,927 |  |  | $ | 11,936 |  |  | $ | (9 | ) |  | (0.1 | )% |  | $ | 24,609 |  |  | $ | 24,181 |  |  | $ | 428 |  |  | 1.8 | % |

[0000858877-16-000090:mdna:104]
[same as prior period, unchanged from 0000858877-15-000073:mdna:101]

[0000858877-16-000090:mdna:105]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 23, 2016 |  | January 24, 2015 |  | Variancein Dollars |  | Variance in Percent |  | January 23, 2016 |  | January 24, 2015 |  | Variancein Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 6,912 |  |  | $ | 7,101 |  |  | $ | (189 | ) |  | (2.7 | )% |  | $ | 14,711 |  |  | $ | 14,602 |  |  | $ | 109 |  |  | 0.7 | % |
| Percentage of revenue |  | 57.9 | % |  | 59.5 | % |  |  |  |  |  | 59.8 | % |  | 60.4 | % |  |  |  |  |
| EMEA |  | 3,088 |  |  | 3,091 |  |  | (3 | ) |  | (0.1 | )% |  | 6,175 |  |  | 6,093 |  |  | 82 |  |  | 1.3 | % |
| Percentage of revenue |  | 25.9 | % |  | 25.9 | % |  |  |  |  |  | 25.1 | % |  | 25.2 | % |  |  |  |  |
| APJC |  | 1,927 |  |  | 1,744 |  |  | 183 |  |  | 10.5 | % |  | 3,723 |  |  | 3,486 |  |  | 237 |  |  | 6.8 | % |
| Percentage of revenue |  | 16.2 | % |  | 14.6 | % |  |  |  |  |  | 15.1 | % |  | 14.4 | % |  |  |  |  |
| Total |  | $ | 11,927 |  |  | $ | 11,936 |  |  | $ | (9 | ) |  | (0.1 | )% |  | $ | 24,609 |  |  | $ | 24,181 |  |  | $ | 428 |  |  | 1.8 | % |

[0000858877-16-000090:mdna:106]
Three Months Ended January 23, 2016 Compared with Three Months Ended January 24, 2015

[0000858877-16-000090:mdna:107]
For the second quarter of fiscal 2016, as compared with the second quarter of fiscal 2015, total revenue was flat. Total company revenue not including SP Video CPE products increased 2%. Product revenue decreased by 1% in total, but increased by 2% for total company product revenue not including SP Video CPE products. Service revenue increased by 3%. Our total revenue grew in our APJC geographic segment, while revenue declined in the Americas segment. The total revenue in our EMEA geographic segment was flat. The emerging countries of BRICM, in the aggregate, experienced a 15% product revenue growth, with growth in China, India and Mexico, partially offset by decreases in the other two BRICM countries.

[0000858877-16-000090:mdna:108]
We conduct business globally in numerous currencies. The direct effect of foreign currency fluctuations on revenue has not been material because our revenue is primarily denominated in U.S. dollars. However, if the U.S. dollar strengthens relative to other currencies, as was the case during the second quarter of fiscal 2016, such strengthening could have an indirect effect on our revenue to the extent it raises the cost of our products to non-U.S. customers and thereby reduces demand. A weaker U.S. dollar could have the opposite effect. However, the precise indirect effect of currency fluctuations is difficult to measure or predict because our revenue is influenced by many factors in addition to the impact of such currency fluctuations. Our revenue in the second quarter of fiscal 2016 was adversely affected by the depreciation of certain currencies relative to the U.S. dollar and especially currencies in certain emerging countries, although the indirect effects are difficult to measure.

[0000858877-16-000090:mdna:109]
[same as prior period, unchanged from 0000858877-15-000073:mdna:106]

[0000858877-16-000090:mdna:110]
[same as prior period, unchanged from 0000858877-15-000073:mdna:108]

[0000858877-16-000090:mdna:111]
[same as prior period, unchanged from 0000858877-15-000073:mdna:109]

[0000858877-16-000090:mdna:112]
Six Months Ended January 23, 2016 Compared with Six Months Ended January 24, 2015

[0000858877-16-000090:mdna:113]
For the first six months of fiscal 2016, as compared with the first six months of fiscal 2015, total revenue increased by 2%.  Product and service revenue each increased by 2%. Our total revenue reflected growth across each of our geographic segments. The emerging countries of BRICM, in the aggregate, experienced 9% product revenue growth, with revenue growth in China, Mexico and India partially offset by decreases in the other two BRICM countries.

[0000858877-16-000090:mdna:114]
[same as prior period, unchanged from 0000858877-15-000073:mdna:110]

[0000858877-16-000090:mdna:115]
[same as prior period, unchanged from 0000858877-15-000073:mdna:111]

[0000858877-16-000090:mdna:116]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 23, 2016 |  | January 24, 2015 |  | Variancein Dollars |  | Variance in Percent |  | January 23, 2016 |  | January 24, 2015 |  | Variancein Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 4,991 |  |  | $ | 5,243 |  |  | $ | (252 | ) |  | (4.8 | )% |  | $ | 10,945 |  |  | $ | 10,927 |  |  | $ | 18 |  |  | 0.2 | % |
| Percentage of product revenue |  | 55.6 | % |  | 57.8 | % |  |  |  |  |  | 58.1 | % |  | 59.1 | % |  |  |  |  |
| EMEA |  | 2,454 |  |  | 2,480 |  |  | (26 | ) |  | (1.0 | )% |  | 4,930 |  |  | 4,876 |  |  | 54 |  |  | 1.1 | % |
| Percentage of product revenue |  | 27.3 | % |  | 27.3 | % |  |  |  |  |  | 26.2 | % |  | 26.3 | % |  |  |  |  |
| APJC |  | 1,538 |  |  | 1,355 |  |  | 183 |  |  | 13.5 | % |  | 2,952 |  |  | 2,710 |  |  | 242 |  |  | 8.9 | % |
| Percentage of product revenue |  | 17.1 | % |  | 14.9 | % |  |  |  |  |  | 15.7 | % |  | 14.6 | % |  |  |  |  |
| Total |  | $ | 8,983 |  |  | $ | 9,078 |  |  | $ | (95 | ) |  | (1.0 | )% |  | $ | 18,827 |  |  | $ | 18,513 |  |  | $ | 314 |  |  | 1.7 | % |

[0000858877-16-000090:mdna:117]
[same as prior period, unchanged from 0000858877-15-000073:mdna:114]

[0000858877-16-000090:mdna:118]
Three Months Ended January 23, 2016 Compared with Three Months Ended January 24, 2015

[0000858877-16-000090:mdna:119]
The decrease in product revenue for the Americas segment was driven in large part by a decline of $227 million in product sales related to our SP Video CPE Business, which we sold during the second quarter of fiscal year 2016. As a result, the second quarter of fiscal 2016 includes only one month of product revenue from our SP Video CPE Business. From a customer markets perspective, the decrease in product revenue in the Americas segment of 5% was led by declines in the public sector, service provider and enterprise markets. The product revenue decline in the public sector market was due primarily to lower sales to the U.S. federal government, partially offset by higher sales to state and local governments. The decline in sales to the service provider market was due to the sale of the SP Video CPE Business. We experienced product revenue growth in the commercial market in this geographic segment. From a country perspective, product revenue decreased by 1% in the United States, 49% in Brazil and 23% in Canada, partially offset by an increase of 25% in Mexico.

[0000858877-16-000090:mdna:120]
Six Months Ended January 23, 2016 Compared with Six Months Ended January 24, 2015

[0000858877-16-000090:mdna:121]
The slight increase in product revenue in the Americas segment was led by growth in the commercial and enterprise markets and to a lesser extent, in the public sector market. These product revenue increases were partially offset by the decline in the service provider market in this segment. The decline in sales to the service provider market was due to lower revenue from SP Video CPE products, due to the sale of this business. From a country perspective, product revenue increased by 3% in the United States and 34% in Mexico, partially offset by decreases of 42% in Brazil and 26% in Canada.

[0000858877-16-000090:mdna:122]
[same as prior period, unchanged from 0000858877-15-000073:mdna:120]

[0000858877-16-000090:mdna:123]
[same as prior period, unchanged from 0000858877-15-000073:mdna:121]

[0000858877-16-000090:mdna:124]
[same as prior period, unchanged from 0000858877-15-000073:mdna:116]

[0000858877-16-000090:mdna:125]
Three Months Ended January 23, 2016 Compared with Three Months Ended January 24, 2015

[0000858877-16-000090:mdna:126]
The decrease in product revenue for the EMEA segment was driven by a decline of $28 million in sales related to our SP Video CPE Business.  From a customer markets perspective, product revenue in the EMEA segment decreased by 1%, driven by declines in the service provider, enterprise and public sector markets, partially offset by product revenue growth in the commercial market. The decline in sales to the service provider market was due primarily to the sale of the SP Video CPE Business. Product revenue from the emerging countries within EMEA decreased by 4%, led by a decline in Russia of 27%. Product revenue for the remainder of the EMEA, which primarily consists of countries in Western Europe, was flat.

[0000858877-16-000090:mdna:127]
Six Months Ended January 23, 2016 Compared with Six Months Ended January 24, 2015

[0000858877-16-000090:mdna:128]
The increase in product revenue in the EMEA segment of 1% was led by growth in the commercial market and, to a lesser extent, in the public sector market. We experienced product revenue declines in the service provider and enterprise markets in this segment. Product revenue from outside the group of emerging countries within EMEA grew by 2%, while product revenue from the emerging countries within EMEA declined by 3%, led by a 33% decrease in Russia.

[0000858877-16-000090:mdna:129]
[same as prior period, unchanged from 0000858877-15-000073:mdna:118]

[0000858877-16-000090:mdna:130]
Three Months Ended January 23, 2016 Compared with Three Months Ended January 24, 2015

[0000858877-16-000090:mdna:131]
The increase in product revenue in the APJC segment of 14% was led by strong growth in the service provider market and, to a lesser extent, in the public sector and commercial markets. These increases were partially offset by a decline in the enterprise market. From a country perspective, product revenue increased by 51% in China (driven by higher sales of Service Provider Video products), 33% in India and 20% in Australia partially offset by a product revenue decrease of 12% in Japan.  Product sales for this geographic segment were adversely impacted by a $13 million decrease in sales related to our SP Video CPE Business.

[0000858877-16-000090:mdna:132]
Six Months Ended January 23, 2016 Compared with Six Months Ended January 24, 2015

[0000858877-16-000090:mdna:133]
Product revenue in the APJC segment increased by 9%. The product revenue growth was led by solid growth in the service provider market and, to a lesser extent, in the commercial and public sector markets. These increases were partially offset by a decline in the enterprise market. From a country perspective, product revenue increased by 34% in China, 22% in India and 6% in Australia. We experienced product revenue decline of 10% in Japan.

[0000858877-16-000090:mdna:134]
[same as prior period, unchanged from 0000858877-15-000073:mdna:184]

[0000858877-16-000090:mdna:135]
[same as prior period, unchanged from 0000858877-15-000073:mdna:132]

[0000858877-16-000090:mdna:136]
[same as prior period, unchanged from 0000858877-15-000073:mdna:133]

[0000858877-16-000090:mdna:137]
[same as prior period, unchanged from 0000858877-15-000073:mdna:122]

[0000858877-16-000090:mdna:138]
In addition to the primary view on a geographic basis, we also prepare financial information related to groups of similar products and customer markets for various purposes. Our product categories consist of the following categories (with subcategories in parentheses): Switching (fixed switching, modular switching, and storage); NGN Routing (high-end routers, mid-range and low-end routers, and other NGN Routing products); Collaboration (unified communications, Cisco TelePresence, and conferencing); Data Center; Wireless; Service Provider Video (video software and solutions, and cable access); Security; and Other Products. The Other Products category consists primarily of emerging technology products and other networking products.

[0000858877-16-000090:mdna:139]
[same as prior period, unchanged from 0000858877-15-000073:mdna:124]

[0000858877-16-000090:mdna:140]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 23, 2016 |  | January 24, 2015 |  | Variancein Dollars |  | Variance in Percent |  | January 23, 2016 |  | January 24, 2015 |  | Variancein Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Switching |  | $ | 3,483 |  |  | $ | 3,615 |  |  | $ | (132 | ) |  | (3.7 | )% |  | $ | 7,505 |  |  | $ | 7,461 |  |  | $ | 44 |  |  | 0.6 | % |
| Percentage of product revenue |  | 38.8 | % |  | 39.8 | % |  |  |  |  |  |  |  | 39.9 | % |  | 40.3 | % |  |  |  |  |  |  |
| NGN Routing |  | 1,845 |  |  | 1,764 |  |  | 81 |  |  | 4.6 | % |  | 3,638 |  |  | 3,713 |  |  | (75 | ) |  | (2.0 | )% |
| Percentage of product revenue |  | 20.5 | % |  | 19.4 | % |  |  |  |  |  |  |  | 19.3 | % |  | 20.1 | % |  |  |  |  |  |  |
| Collaboration |  | 1,019 |  |  | 991 |  |  | 28 |  |  | 2.8 | % |  | 2,134 |  |  | 1,941 |  |  | 193 |  |  | 9.9 | % |
| Percentage of product revenue |  | 11.3 | % |  | 10.9 | % |  |  |  |  |  |  |  | 11.3 | % |  | 10.5 | % |  |  |  |  |  |  |
| Data Center |  | 822 |  |  | 846 |  |  | (24 | ) |  | (2.8 | )% |  | 1,681 |  |  | 1,538 |  |  | 143 |  |  | 9.3 | % |
| Percentage of product revenue |  | 9.2 | % |  | 9.3 | % |  |  |  |  |  |  |  | 8.9 | % |  | 8.3 | % |  |  |  |  |  |  |
| Wireless |  | 613 |  |  | 611 |  |  | 2 |  |  | 0.3 | % |  | 1,258 |  |  | 1,216 |  |  | 42 |  |  | 3.5 | % |
| Percentage of product revenue |  | 6.8 | % |  | 6.7 | % |  |  |  |  |  | 6.7 | % |  | 6.6 | % |  |  |  |  |
| Service ProviderVideo (1) |  | 662 |  |  | 776 |  |  | (114 | ) |  | (14.7 | )% |  | 1,512 |  |  | 1,647 |  |  | (135 | ) |  | (8.2 | )% |
| Percentage of product revenue |  | 7.4 | % |  | 8.6 | % |  |  |  |  |  |  |  | 8.0 | % |  | 8.9 | % |  |  |  |  |  |  |
| Security |  | 462 |  |  | 416 |  |  | 46 |  |  | 11.1 | % |  | 947 |  |  | 871 |  |  | 76 |  |  | 8.7 | % |
| Percentage of product revenue |  | 5.1 | % |  | 4.6 | % |  |  |  |  |  |  |  | 5.0 | % |  | 4.7 | % |  |  |  |  |  |  |
| Other |  | 77 |  |  | 59 |  |  | 18 |  |  | 30.5 | % |  | 152 |  |  | 126 |  |  | 26 |  |  | 20.6 | % |
| Percentage of product revenue |  | 0.9 | % |  | 0.7 | % |  |  |  |  |  |  |  | 0.9 | % |  | 0.6 | % |  |  |  |  |  |  |
| Total |  | $ | 8,983 |  |  | $ | 9,078 |  |  | $ | (95 | ) |  | (1.0 | )% |  | $ | 18,827 |  |  | $ | 18,513 |  |  | $ | 314 |  |  | 1.7 | % |

[0000858877-16-000090:mdna:141]
(1) Includes SP Video CPE Business revenue of $93 million (one month of operations) and $361 million for the second quarter of fiscal 2016 and 2015, respectively and $504 million and $840 million for the first six months of fiscal 2016 and 2015, respectively.

[0000858877-16-000090:mdna:142]
[same as prior period, unchanged from 0000858877-15-000073:mdna:126]

[0000858877-16-000090:mdna:143]
[same as prior period, unchanged from 0000858877-15-000073:mdna:148]

[0000858877-16-000090:mdna:144]
[same as prior period, unchanged from 0000858877-15-000073:mdna:149]

[0000858877-16-000090:mdna:145]
[same as prior period, unchanged from 0000858877-15-000073:mdna:128]

[0000858877-16-000090:mdna:146]
Three Months Ended January 23, 2016 Compared with Three Months Ended January 24, 2015

[0000858877-16-000090:mdna:147]
We believe, the decrease in revenue in our Switching product category of 4%, or $132 million was driven in large part by the uncertainty in the macro environment which led to a slowdown of customer spending, impacting sales for our Switching products used in campus environments which comprise the majority of this portfolio. This impact was partially offset by strength in our Application Centric Infrastructure portfolio.

[0000858877-16-000090:mdna:148]
In terms of subcategories, the decrease was driven by a 13%, or $147 million, decrease in revenue from our modular switches and, to a lesser extent, a 19%, or $29 million, decrease in sales of storage products. Revenue from our modular switches decreased due primarily to lower sales of most of the Cisco Catalyst Series Switches and Cisco Nexus 7000 Series Switches, partially offset by growth in Cisco Nexus 9500 Series Switches within this product category. We experienced an increase in revenue from LAN fixed-configuration switches of 2%, or $44 million, driven primarily by higher sales of our Cisco Catalyst 3850 Series Switches, Cisco Catalyst 3650 Series Switches, Cisco Nexus 9300 Series Switches, and Cisco Nexus 3000 Series Switches, partially offset by a decrease in sales of certain other products in this portfolio.

[0000858877-16-000090:mdna:149]
Six Months Ended January 23, 2016 Compared with Six Months Ended January 24, 2015

[0000858877-16-000090:mdna:150]
Revenue in our Switching product category increased by 1%, or $44 million, driven by a 6%, or $287 million, increase in revenue from our LAN fixed-configuration switches partially offset by a 6%, or $148 million, decrease in revenue from our modular switches and a 31%, or $95 million, decrease in sales of storage products. Revenue from LAN fixed-configuration switches increased due to higher sales of our Cisco Catalyst 3850 Series Switches, Cisco Catalyst 3650 Series Switches, Cisco Nexus 9300 Series Switches, and Cisco Nexus 3000 Series Switches. Revenue from our modular switches decreased driven by lower sales of Cisco Catalyst 6500-E Series Switches and Cisco Nexus 7000 Series Switches.

[0000858877-16-000090:mdna:151]
[same as prior period, unchanged from 0000858877-15-000073:mdna:130]

[0000858877-16-000090:mdna:152]
Three Months Ended January 23, 2016 Compared with Three Months Ended January 24, 2015

[0000858877-16-000090:mdna:153]
Revenue in our NGN Routing product category increased by 5%, or $81 million, driven by a 5%, or $56 million, increase in revenue from our high-end router products and a 6%, or $33 million, increase in revenue from our midrange and low-end router products.  These increases were partially offset by a 9%, or $8 million, decrease in revenue from what we categorize as other NGN Routing products. The increase in revenue from our high-end router product was driven by increased in sales of our Cisco Carrier Routing Systems platform and, to a lesser extent, increased in sales within our Cisco Aggregation Services Router category.  Revenue from our midrange and low-end router products increased due to higher sales of our Cisco Integrated Services Routers products and certain of our access products. The decrease in revenue from other NGN Routing products was due in large part to lower sales of certain optical networking products.

[0000858877-16-000090:mdna:154]
Six Months Ended January 23, 2016 Compared with Six Months Ended January 24, 2015

[0000858877-16-000090:mdna:155]
The decrease in revenue in our NGN Routing product category of 2%, or $75 million, was driven by a 7%, or $156 million, decrease in revenue from our high-end router products partially offset by a 21%, or $44 million, increase in revenue from other NGN Routing products and a 3%, or $37 million, increase in revenue from our midrange and low-end router products. Revenue from high-end router products decreased due to a decrease in revenue from most of our products within our Cisco Aggregation Services Routers category and our Cisco Network Convergence System platform, partially offset by higher sales of our CRS-X products. Revenue from other NGN Routing products increased due to higher sales of certain optical networking products. The increase in revenue from our midrange and low-end router products was due to higher sales of our Cisco Integrated Services Routers products and certain of our access products.

[0000858877-16-000090:mdna:156]
[same as prior period, unchanged from 0000858877-15-000073:mdna:134]

[0000858877-16-000090:mdna:157]
Three Months Ended January 23, 2016 Compared with Three Months Ended January 24, 2015

[0000858877-16-000090:mdna:158]
Revenue from our Collaboration product category increased by 3%, or $28 million, due primarily to increased revenue from our Conferencing products and, to a lesser extent, a slight increase in revenue from our Cisco TelePresence products, partially offset by decreased revenue from our Unified Communications products. The growth in Conferencing revenue was a result of higher usage and recurring revenue from WebEx. Revenue from our Telepresence products increased slightly due to higher revenue from our infrastructure products as a result of new offerings. The revenue decline in Unified Communications was due to lower sales of phones. We continue to increase the amount of deferred revenue and the proportion of recurring revenue related to our Collaboration product category.

[0000858877-16-000090:mdna:159]
56

[0000858877-16-000090:mdna:160]
[same as prior period, unchanged from 0000858877-15-000073:mdna:155]

[0000858877-16-000090:mdna:161]
[same as prior period, unchanged from 0000858877-15-000073:mdna:156]

[0000858877-16-000090:mdna:162]
Six Months Ended January 23, 2016 Compared with Six Months Ended January 24, 2015

[0000858877-16-000090:mdna:163]
Revenue in our Collaboration product category increased by 10%, or $193 million, driven by growth across the entire portfolio within this product category. The growth in Conferencing revenue was a result of higher usage and recurring revenue. Revenue from Cisco TelePresence products grew due to higher revenue in endpoint products as momentum continued as a result of new product introductions. The increase in Unified Communications revenue was driven by higher software revenue and increased revenue from phones due to customer migration to our newer endpoints.

[0000858877-16-000090:mdna:164]
[same as prior period, unchanged from 0000858877-15-000073:mdna:136]

[0000858877-16-000090:mdna:165]
Three Months Ended January 23, 2016 Compared with Three Months Ended January 24, 2015

[0000858877-16-000090:mdna:166]
The decrease in revenue in our Data Center product category of 3%, or $24 million, was primarily driven by a decrease in sales of our Cisco Unified Computing System products, with declines in the public sector, service provider and enterprise markets.  We believe the uncertainty in the macro environment which led to a slowdown of customer spending adversely impacted sales of this product category.

[0000858877-16-000090:mdna:167]
Six Months Ended January 23, 2016 Compared with Six Months Ended January 24, 2015

[0000858877-16-000090:mdna:168]
Revenue in our Data Center product category grew by 9%, or $143 million, with sales growth of our Cisco Unified Computing System products occurring across all geographic segments and customer markets.

[0000858877-16-000090:mdna:169]
[same as prior period, unchanged from 0000858877-15-000073:mdna:141]

[0000858877-16-000090:mdna:170]
Three Months Ended January 23, 2016 Compared with Three Months Ended January 24, 2015

[0000858877-16-000090:mdna:171]
Revenue in our Wireless product category was flat as continued growth in sales of Meraki products within this product category was offset by the decrease in sales of our controllers and access point products. We continue to increase the amount of deferred revenue and the proportion of recurring revenue related to our Wireless product category.

[0000858877-16-000090:mdna:172]
Six Months Ended January 23, 2016 Compared with Six Months Ended January 24, 2015

[0000858877-16-000090:mdna:173]
Revenue in our Wireless product category increased by 3%, or $42 million, due primarily to higher sales of Meraki products within this product category and, to a lesser extent, growth in sales of certain of our access point products.

[0000858877-16-000090:mdna:174]
[same as prior period, unchanged from 0000858877-15-000073:mdna:138]

[0000858877-16-000090:mdna:175]
Three Months Ended January 23, 2016 Compared with Three Months Ended January 24, 2015

[0000858877-16-000090:mdna:176]
The decrease in revenue from our Service Provider Video product category of 15%, or $114 million, was driven by a decrease in sales of $268 million related to our SP Video CPE Business which we sold during the second quarter of fiscal 2016. This decrease was partially offset by an increase in revenue from our video software and solutions and cable access products, driven largely by strength in APJC, particularly in China.

[0000858877-16-000090:mdna:177]
Six Months Ended January 23, 2016 Compared with Six Months Ended January 24, 2015

[0000858877-16-000090:mdna:178]
Revenue from our Service Provider Video product category decreased by 8%, or $135 million, due to a decrease in sales related to the SP Video CPE Business, partially offset by an increase in revenue from Service Provider Video software and solutions and cable access products.

[0000858877-16-000090:mdna:179]
[same as prior period, unchanged from 0000858877-15-000073:mdna:143]

[0000858877-16-000090:mdna:180]
Three Months Ended January 23, 2016 Compared with Three Months Ended January 24, 2015

[0000858877-16-000090:mdna:181]
Revenue in our Security product category was up 11%, or $46 million, driven by higher sales of advanced threat security, unified threat management and web security products, partially offset by a decrease in revenue from our traditional firewall products. We continue to increase the amount of deferred revenue and the proportion of recurring revenue related to our Security product category.

[0000858877-16-000090:mdna:182]
Six Months Ended January 23, 2016 Compared with Six Months Ended January 24, 2015

[0000858877-16-000090:mdna:183]
Revenue from our Security product category grew 9%, or $76 million, driven by similar factors as discussed in the three-month period immediately above.

[0000858877-16-000090:mdna:184]
[same as prior period, unchanged from 0000858877-15-000073:mdna:169]

[0000858877-16-000090:mdna:185]
[same as prior period, unchanged from 0000858877-15-000073:mdna:170]

[0000858877-16-000090:mdna:186]
[same as prior period, unchanged from 0000858877-15-000073:mdna:150]

[0000858877-16-000090:mdna:187]
[same as prior period, unchanged from 0000858877-15-000073:mdna:151]

[0000858877-16-000090:mdna:188]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 23, 2016 |  | January 24, 2015 |  | Variancein Dollars |  | Variance in Percent |  | January 23, 2016 |  | January 24, 2015 |  | Variancein Dollars |  | Variance in Percent |
| Service revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 1,921 |  |  | $ | 1,858 |  |  | $ | 63 |  |  | 3.4 | % |  | $ | 3,766 |  |  | $ | 3,675 |  |  | $ | 91 |  |  | 2.5 | % |
| Percentage of service revenue |  | 65.3 | % |  | 65.0 | % |  |  |  |  |  | 65.2 | % |  | 64.8 | % |  |  |  |  |
| EMEA |  | 634 |  |  | 611 |  |  | 23 |  |  | 3.8 | % |  | 1,245 |  |  | 1,217 |  |  | 28 |  |  | 2.3 | % |
| Percentage of service revenue |  | 21.5 | % |  | 21.4 | % |  |  |  |  |  | 21.5 | % |  | 21.5 | % |  |  |  |  |
| APJC |  | 389 |  |  | 389 |  |  | — |  |  | — | % |  | 771 |  |  | 776 |  |  | (5 | ) |  | (0.6 | )% |
| Percentage of service revenue |  | 13.2 | % |  | 13.6 | % |  |  |  |  |  | 13.3 | % |  | 13.7 | % |  |  |  |  |
| Total |  | $ | 2,944 |  |  | $ | 2,858 |  |  | $ | 86 |  |  | 3.0 | % |  | $ | 5,782 |  |  | $ | 5,668 |  |  | $ | 114 |  |  | 2.0 | % |

[0000858877-16-000090:mdna:189]
Three Months Ended January 23, 2016 Compared with Three Months Ended January 24, 2015

[0000858877-16-000090:mdna:190]
Service revenue grew 3%, with revenue increasing in the EMEA and Americas geographic segments, while in the APJC segment service revenue was flat. Worldwide technical support services revenue increased by 2% and worldwide advanced services revenue increased by 5%, driven by growth in transaction revenues. Technical support services revenue experienced growth across all geographic segments. Renewals and technical support service contract initiations associated with product sales provided an installed base of equipment being serviced which, in concert with new service offerings, were the primary factors driving the revenue increases. Advanced services revenue, which relates to professional services for specific customer network needs, grew in the Americas and EMEA segments.

[0000858877-16-000090:mdna:191]
Six Months Ended January 23, 2016 Compared with Six Months Ended January 24, 2015

[0000858877-16-000090:mdna:192]
Service revenue increased in the Americas and EMEA geographic segments, while service revenue declined in the APJC segment. Worldwide technical support services revenue increased slightly and worldwide advanced services experienced 7% revenue growth. Technical support services revenue grew slightly in our EMEA segment and was flat in the Americas and APJC segments.  Advanced services revenue grew in the Americas and EMEA segments but declined in the APJC segment.

[0000858877-16-000090:mdna:193]
[same as prior period, unchanged from 0000858877-15-000073:mdna:185]

[0000858877-16-000090:mdna:194]
[same as prior period, unchanged from 0000858877-15-000073:mdna:186]

[0000858877-16-000090:mdna:195]
[same as prior period, unchanged from 0000858877-15-000073:mdna:157]

[0000858877-16-000090:mdna:196]
[same as prior period, unchanged from 0000858877-15-000073:mdna:158]

[0000858877-16-000090:mdna:197]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | AMOUNT |  | PERCENTAGE |  | AMOUNT |  | PERCENTAGE |
|  |  | January 23, 2016 |  | January 24, 2015 |  | January 23, 2016 |  | January 24, 2015 |  | January 23, 2016 |  | January 24, 2015 |  | January 23, 2016 |  | January 24, 2015 |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 5,503 |  |  | $ | 5,272 |  |  | 61.3 | % |  | 58.1 | % |  | $ | 11,494 |  |  | $ | 10,788 |  |  | 61.1 | % |  | 58.3 | % |
| Service |  | 1,929 |  |  | 1,818 |  |  | 65.5 | % |  | 63.6 | % |  | 3,770 |  |  | 3,635 |  |  | 65.2 | % |  | 64.1 | % |
| Total |  | $ | 7,432 |  |  | $ | 7,090 |  |  | 62.3 | % |  | 59.4 | % |  | $ | 15,264 |  |  | $ | 14,423 |  |  | 62.0 | % |  | 59.6 | % |

[0000858877-16-000090:mdna:198]
[same as prior period, unchanged from 0000858877-15-000073:mdna:160]

[0000858877-16-000090:mdna:199]
The following table summarizes the key factors that contributed to the change in product gross margin percentage for the second quarter and first six months of fiscal 2016 as compared with the corresponding prior year period:

[0000858877-16-000090:mdna:200]
|  |  | Product Gross Margin Percentage |
|  |  | Three Months Ended |  | Six Months Ended |
| Fiscal 2015 |  | 58.1 | % |  | 58.3 | % |
| Productivity (1) |  | 3.7 | % |  | 3.7 | % |
| Rockstar patent portfolio charge |  | — | % |  | 1.0 | % |
| Amortization of purchased intangible assets |  | 1.2 | % |  | 0.9 | % |
| SP Video CPE Business impact |  | 1.2 | % |  | 0.7 | % |
| Product pricing |  | (2.1 | )% |  | (2.1 | )% |
| Mix of products sold |  | (0.8 | )% |  | (1.4 | )% |
| Fiscal 2016 |  | 61.3 | % |  | 61.1 | % |

[0000858877-16-000090:mdna:201]
[same as prior period, unchanged from 0000858877-15-000073:mdna:163]

[0000858877-16-000090:mdna:202]
Three Months Ended January 23, 2016 Compared with Three Months Ended January 24, 2015

[0000858877-16-000090:mdna:203]
Product gross margin increased by 3.2 percentage points as compared with the second quarter of fiscal 2015. The increase in product gross margin was due to productivity improvements, which were driven by value engineering efforts; favorable component pricing; continued operational efficiency in manufacturing operations and lower warranty expense. Value engineering is the process by which production costs are reduced through component redesign, board configuration, test processes, and transformation processes. Our product gross margin also benefited from lower amortization expense/impairment charges related to acquisition-related intangible assets, and the sale during the second quarter of fiscal 2016 of our lower margin SP Video CPE Business. The various factors contributing to the product gross margin increase were partially offset by unfavorable impacts from product pricing, which were driven by typical market factors and impacted each of our geographic segments and customer markets and unfavorable mix of products sold. The unfavorable mix of products sold was primarily driven by higher sales of Service Provider Video products (not including the CPE Business) and lower sales of Switching products.

[0000858877-16-000090:mdna:204]
Our future gross margins could be impacted by our product mix and could be adversely affected by further growth in sales of products that have lower gross margins, such as Cisco Unified Computing System products. Our gross margins may also be impacted by the geographic mix of our revenue and, as was the case in the first six months of fiscal 2016 and in fiscal 2015, may be adversely affected by product pricing attributable to competitive factors. Additionally, our manufacturing-related costs may be negatively impacted by constraints in our supply chain, which in turn could negatively affect gross margin. If any of the preceding factors that in the past have negatively impacted our gross margins arise in future periods, our gross margins could continue to decline.

[0000858877-16-000090:mdna:205]
[same as prior period, unchanged from 0000858877-15-000073:mdna:243]

[0000858877-16-000090:mdna:206]
[same as prior period, unchanged from 0000858877-15-000073:mdna:192]

[0000858877-16-000090:mdna:207]
[same as prior period, unchanged from 0000858877-15-000073:mdna:193]

[0000858877-16-000090:mdna:208]
Six Months Ended January 23, 2016 Compared with Six Months Ended January 24, 2015

[0000858877-16-000090:mdna:209]
Product gross margin increased by 2.8 percentage points as compared with the first six months of fiscal 2015. The increase was due to productivity improvements driven by similar factors as discussed in the three-month period immediately above. Additionally, gross margin increased due to the impact of a $188 million charge to product cost of sales recorded in the first quarter of fiscal 2015 related to the Rockstar patent portfolio, the impact of impairment charges recorded in second quarter of fiscal 2015, lower amortization expense related to acquisition-related intangible assets, and the sale during the second quarter of fiscal 2016 of our lower margin SP Video CPE Business. These factors were partially offset by unfavorable impacts from product pricing and unfavorable mix of products sold. The unfavorable product mix impact was due to increased revenue from our relatively lower margin Cisco Unified Computing System products, an unfavorable mix impact from our core products, and higher sales from our Service Provider Video products (not including the CPE Business).

[0000858877-16-000090:mdna:210]
[same as prior period, unchanged from 0000858877-15-000073:mdna:171]

[0000858877-16-000090:mdna:211]
Three Months Ended January 23, 2016 Compared with Three Months Ended January 24, 2015

[0000858877-16-000090:mdna:212]
Our service gross margin percentage increased by 1.9 percentage points as compared with the second quarter of fiscal 2015 due to lower headcount-related costs, higher sales volume and, to a lesser extent, lower outside services costs. These benefits to gross margin were partially offset by increased partner delivery costs and unfavorable mix. The mix impacts were due to our lower gross margin advanced services business contributing a higher proportion of service revenue for the second quarter of fiscal 2016, as compared with second quarter of fiscal 2015.

[0000858877-16-000090:mdna:213]
[same as prior period, unchanged from 0000858877-15-000073:mdna:174]

[0000858877-16-000090:mdna:214]
Six Months Ended January 23, 2016 Compared with Six Months Ended January 24, 2015

[0000858877-16-000090:mdna:215]
Service gross margin percentage increased by 1.1 percentage points as compared with the first six months of fiscal 2015, due to decreased headcount-related costs and higher sales volume. These benefits to gross margin were partially offset by increased partner delivery costs and unfavorable mix. The mix impacts were driven by similar factors as discussed in the three month period immediately above.

[0000858877-16-000090:mdna:216]
[same as prior period, unchanged from 0000858877-15-000073:mdna:175]

[0000858877-16-000090:mdna:217]
[same as prior period, unchanged from 0000858877-15-000073:mdna:176]

[0000858877-16-000090:mdna:218]
|  | Three Months Ended |  | Six Months Ended |
|  | AMOUNT |  | PERCENTAGE |  | AMOUNT |  | PERCENTAGE |
|  | January 23, 2016 |  | January 24, 2015 |  | January 23, 2016 |  | January 24, 2015 |  | January 23, 2016 |  | January 24, 2015 |  | January 23, 2016 |  | January 24, 2015 |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 4,412 |  |  | $ | 4,406 |  |  | 63.8 | % |  | 62.0 | % |  | $ | 9,362 |  |  | $ | 9,216 |  |  | 63.6 | % |  | 63.1 | % |
| EMEA | 2,005 |  |  | 1,910 |  |  | 64.9 | % |  | 61.8 | % |  | 3,987 |  |  | 3,825 |  |  | 64.6 | % |  | 62.8 | % |
| APJC | 1,189 |  |  | 1,052 |  |  | 61.7 | % |  | 60.3 | % |  | 2,267 |  |  | 2,077 |  |  | 60.9 | % |  | 59.6 | % |
| Segment total | 7,606 |  |  | 7,368 |  |  | 63.8 | % |  | 61.7 | % |  | 15,616 |  |  | 15,118 |  |  | 63.5 | % |  | 62.5 | % |
| Unallocated corporate items (1) | (174 | ) |  | (278 | ) |  |  |  |  |  | (352 | ) |  | (695 | ) |  |  |  |  |
| Total | $ | 7,432 |  |  | $ | 7,090 |  |  | 62.3 | % |  | 59.4 | % |  | $ | 15,264 |  |  | $ | 14,423 |  |  | 62.0 | % |  | 59.6 | % |

[0000858877-16-000090:mdna:219]
(1) The unallocated corporate items for the periods presented include the effects of amortization and impairments of acquisition-related intangible assets, share-based compensation expense, significant litigation and other contingencies, charges related to asset impairments and restructurings, and certain other charges. We do not allocate these items to the gross margin for each segment because management does not include such information in measuring the performance of the operating segments.

[0000858877-16-000090:mdna:220]
60

[0000858877-16-000090:mdna:221]
[same as prior period, unchanged from 0000858877-15-000073:mdna:208]

[0000858877-16-000090:mdna:222]
[same as prior period, unchanged from 0000858877-15-000073:mdna:209]

[0000858877-16-000090:mdna:223]
Three Months Ended January 23, 2016 Compared with Three Months Ended January 24, 2015

[0000858877-16-000090:mdna:224]
The Americas segment experienced a gross margin percentage increase due primarily to the sale of the lower margin SP Video CPE Business. In this geographic segment, productivity improvements were substantially offset by unfavorable impacts from pricing and product mix.

[0000858877-16-000090:mdna:225]
The gross margin percentage increase in our EMEA segment was due primarily to the impact of productivity improvements in this geographic segment and the sale of the SP Video CPE Business. Partially offsetting these favorable impacts to gross margin were negative impacts from pricing and an unfavorable product mix. Higher service gross margin also contributed to the increase in the overall gross margin in this segment.

[0000858877-16-000090:mdna:226]
Our APJC segment gross margin percentage increased primarily due to the impact of productivity improvements partially offset by unfavorable impacts from pricing and mix. The unfavorable mix impact was driven primarily by an increase in revenue from Service Provider Video products (not including the CPE Business).

[0000858877-16-000090:mdna:227]
[same as prior period, unchanged from 0000858877-15-000073:mdna:183]

[0000858877-16-000090:mdna:228]
Six Months Ended January 23, 2016 Compared with Six Months Ended January 24, 2015

[0000858877-16-000090:mdna:229]
We experienced a gross margin percentage increase in our Americas segment due to productivity improvements and the sale of the SP Video CPE Business, partially offset by unfavorable impacts from pricing and mix. The unfavorable mix impact in this geographic segment was driven by an increase in revenue from our relatively lower margin Cisco Unified Computing System products and an unfavorable mix from our NGN Routing products.

[0000858877-16-000090:mdna:230]
The gross margin percentage increase in our EMEA segment was due primarily to the impact of productivity improvements in this geographic segment and the sale of the lower margin SP Video CPE Business. Partially offsetting these favorable impacts to gross margin were negative impacts from pricing and an unfavorable product mix. Higher service gross margin also contributed to the increase in the overall gross margin in this segment.

[0000858877-16-000090:mdna:231]
The APJC segment gross margin percentage increased due to productivity improvements partially offset by unfavorable impacts from pricing and mix. The unfavorable mix impact was driven by an increase in revenue from our Service Provider Video products (not including the CPE Business) and an unfavorable mix within our NGN routing products.

[0000858877-16-000090:mdna:232]
[same as prior period, unchanged from 0000858877-15-000073:mdna:223]

[0000858877-16-000090:mdna:233]
[same as prior period, unchanged from 0000858877-15-000073:mdna:224]

[0000858877-16-000090:mdna:234]
[same as prior period, unchanged from 0000858877-15-000073:mdna:187]

[0000858877-16-000090:mdna:235]
[same as prior period, unchanged from 0000858877-15-000073:mdna:188]

[0000858877-16-000090:mdna:236]
[same as prior period, unchanged from 0000858877-15-000073:mdna:189]

[0000858877-16-000090:mdna:237]
[same as prior period, unchanged from 0000858877-15-000073:mdna:190]

[0000858877-16-000090:mdna:238]
[same as prior period, unchanged from 0000858877-15-000073:mdna:191]

[0000858877-16-000090:mdna:239]
[same as prior period, unchanged from 0000858877-15-000073:mdna:237]

[0000858877-16-000090:mdna:240]
[same as prior period, unchanged from 0000858877-15-000073:mdna:238]

[0000858877-16-000090:mdna:241]
[same as prior period, unchanged from 0000858877-15-000073:mdna:194]

[0000858877-16-000090:mdna:242]
[same as prior period, unchanged from 0000858877-15-000073:mdna:195]

[0000858877-16-000090:mdna:243]
|  | Three Months Ended |  | Six Months Ended |
|  | January 23, 2016 |  | January 24, 2015 |  | Variancein Dollars |  | Variance in Percent |  | January 23, 2016 |  | January 24, 2015 |  | Variancein Dollars |  | Variance in Percent |
| Research and development | $ | 1,509 |  |  | $ | 1,529 |  |  | $ | (20 | ) |  | (1.3 | )% |  | $ | 3,069 |  |  | $ | 3,112 |  |  | $ | (43 | ) |  | (1.4 | )% |
| Percentage of revenue | 12.7 | % |  | 12.8 | % |  |  |  |  |  | 12.5 | % |  | 12.9 | % |  |  |  |  |
| Sales and marketing | 2,286 |  |  | 2,308 |  |  | (22 | ) |  | (1.0 | )% |  | 4,729 |  |  | 4,823 |  |  | (94 | ) |  | (1.9 | )% |
| Percentage of revenue | 19.2 | % |  | 19.3 | % |  |  |  |  |  | 19.2 | % |  | 19.9 | % |  |  |  |  |
| General and administrative | 176 |  |  | 490 |  |  | (314 | ) |  | (64.1 | )% |  | 715 |  |  | 994 |  |  | (279 | ) |  | (28.1 | )% |
| Percentage of revenue | 1.5 | % |  | 4.1 | % |  |  |  |  |  | 2.9 | % |  | 4.1 | % |  |  |  |  |
| Total | $ | 3,971 |  |  | $ | 4,327 |  |  | $ | (356 | ) |  | (8.2 | )% |  | $ | 8,513 |  |  | $ | 8,929 |  |  | $ | (416 | ) |  | (4.7 | )% |
| Percentage of revenue | 33.3 | % |  | 36.3 | % |  |  |  |  |  | 34.6 | % |  | 36.9 | % |  |  |  |  |

[0000858877-16-000090:mdna:244]
[same as prior period, unchanged from 0000858877-15-000073:mdna:197]

[0000858877-16-000090:mdna:245]
R&D expenses decreased for the second quarter and first six months of fiscal 2016, as compared with the corresponding periods of fiscal 2015, primarily due to lower acquisition-related costs and, to a lesser extent, lower discretionary spending.

[0000858877-16-000090:mdna:246]
[same as prior period, unchanged from 0000858877-15-000073:mdna:199]

[0000858877-16-000090:mdna:247]
[same as prior period, unchanged from 0000858877-15-000073:mdna:200]

[0000858877-16-000090:mdna:248]
Sales and marketing expenses decreased for the second quarter of fiscal 2016, as compared with the second quarter of fiscal 2015, due to lower contracted services. For the first six months of fiscal 2016, as compared with the first six months of fiscal 2015, sales and marketing expenses decreased due to lower discretionary spending, lower contracted services and lower headcount-related expenses.

[0000858877-16-000090:mdna:249]
[same as prior period, unchanged from 0000858877-15-000073:mdna:202]

[0000858877-16-000090:mdna:250]
G&A expenses decreased in the second quarter and first six months of fiscal 2016, as compared with the corresponding periods of fiscal 2015, primarily due to the $286 million pre-tax gain from the sale of our SP Video CPE Business. Lower contracted services and timing of corporate-level expenses, which tend to vary from period to period, also contributed to the decrease. Corporate-level expenses included operational infrastructure activities such as IT project implementations, which included investments in our global data center infrastructure, and investments related to operational and financial systems.

[0000858877-16-000090:mdna:251]
[same as prior period, unchanged from 0000858877-15-000073:mdna:204]

[0000858877-16-000090:mdna:252]
In the second quarter of fiscal 2016, foreign currency fluctuations, net of hedging, decreased the combined R&D, sales and marketing, and G&A expenses by approximately $149 million, or approximately 3.4%, compared with the second quarter of fiscal 2015.

[0000858877-16-000090:mdna:253]
In the first six months of fiscal 2016, foreign currency fluctuations, net of hedging, decreased the combined R&D, sales and marketing, and G&A expenses by approximately $356 million, or approximately 4.0%, compared with the first six months of fiscal 2015.

[0000858877-16-000090:mdna:254]
63

[0000858877-16-000090:mdna:255]
[same as prior period, unchanged from 0000858877-15-000073:mdna:244]

[0000858877-16-000090:mdna:256]
[same as prior period, unchanged from 0000858877-15-000073:mdna:245]

[0000858877-16-000090:mdna:257]
[same as prior period, unchanged from 0000858877-15-000073:mdna:206]

[0000858877-16-000090:mdna:258]
Our headcount as of January 23, 2016 was 71,657, which represents a decrease of 406 employees in the second quarter of fiscal 2016 and a decrease of 176 employees in the first six months of fiscal 2016, as compared with the total headcount at the end of fiscal 2015. The decrease for both periods was due to headcount reductions from the sale of the SP Video CPE Business, from attrition and from our restructuring plan announced in August 2014. These headcount reductions were partially offset by headcount additions from targeted hiring in key growth areas in engineering, services and sales, and headcount additions from our recent acquisitions.

[0000858877-16-000090:mdna:259]
[same as prior period, unchanged from 0000858877-15-000073:mdna:210]

[0000858877-16-000090:mdna:260]
[same as prior period, unchanged from 0000858877-15-000073:mdna:211]

[0000858877-16-000090:mdna:261]
|  | Three Months Ended |  | Six Months Ended |
|  | January 23, 2016 |  | January 24, 2015 |  | January 23, 2016 |  | January 24, 2015 |
| Cost of sales—product | $ | 16 |  |  | $ | 11 |  |  | $ | 29 |  |  | $ | 22 |  |
| Cost of sales—service | 35 |  |  | 34 |  |  | 73 |  |  | 71 |  |
| Share-based compensation expense in cost of sales | 51 |  |  | 45 |  |  | 102 |  |  | 93 |  |
| Research and development | 107 |  |  | 105 |  |  | 221 |  |  | 224 |  |
| Sales and marketing | 126 |  |  | 114 |  |  | 265 |  |  | 261 |  |
| General and administrative | 47 |  |  | 42 |  |  | 104 |  |  | 101 |  |
| Restructuring and other charges | (1 | ) |  | 2 |  |  | 14 |  |  | (2 | ) |
| Share-based compensation expense in operating expenses | 279 |  |  | 263 |  |  | 604 |  |  | 584 |  |
| Total share-based compensation expense | $ | 330 |  |  | $ | 308 |  |  | $ | 706 |  |  | $ | 677 |  |

[0000858877-16-000090:mdna:262]
The increase in share-based compensation expense in the second quarter of fiscal 2016, as compared with the second quarter of   fiscal 2015, was due primarily to the timing of the RSU grants. The increase in share-based compensation expense in the first six months of fiscal 2016, as compared with the first six months of fiscal 2015, was due primarily to the timing of the RSU grants and higher expense associated with accelerated and modified awards, partially offset by lower expense related to equity awards assumed with respect to our recent acquisitions.

[0000858877-16-000090:mdna:263]
[same as prior period, unchanged from 0000858877-15-000073:mdna:214]

[0000858877-16-000090:mdna:264]
[same as prior period, unchanged from 0000858877-15-000073:mdna:215]

[0000858877-16-000090:mdna:265]
|  | Three Months Ended |  | Six Months Ended |
|  | January 23, 2016 |  | January 24, 2015 |  | January 23, 2016 |  | January 24, 2015 |
| Amortization of purchased intangible assets: |  |  |  |  |  |  |  |
| Cost of sales | $ | 139 |  |  | $ | 242 |  |  | $ | 285 |  |  | $ | 431 |  |
| Operating expenses | 71 |  |  | 72 |  |  | 140 |  |  | 143 |  |
| Total | $ | 210 |  |  | $ | 314 |  |  | $ | 425 |  |  | $ | 574 |  |

[0000858877-16-000090:mdna:266]
Amortization of purchased intangible assets decreased for the second quarter and first six months of fiscal 2016, as compared with the corresponding periods of fiscal 2015, due to certain purchased intangible assets having become fully amortized or impaired and impairment charges recorded in the second quarter of fiscal 2015, partially offset by amortization of purchased intangible assets from our recent acquisitions.

[0000858877-16-000090:mdna:267]
[same as prior period, unchanged from 0000858877-15-000073:mdna:218]

[0000858877-16-000090:mdna:268]
[same as prior period, unchanged from 0000858877-15-000073:mdna:258]

[0000858877-16-000090:mdna:269]
[same as prior period, unchanged from 0000858877-15-000073:mdna:259]

[0000858877-16-000090:mdna:270]
[same as prior period, unchanged from 0000858877-15-000073:mdna:219]

[0000858877-16-000090:mdna:271]
In the second quarter and first six months of fiscal 2016, we incurred restructuring and other charges of approximately $95 million net of a $1 million credit to cost of sales and $236 million net of a $2 million credit to cost of sales, respectively. These charges were related primarily to employee severance charges for employees impacted by the restructuring action announced in August 2014, which is substantially complete. We plan to reinvest substantially all of the cost savings from the restructuring actions in key growth areas of our business such as data center, software, security, and cloud. The overall cost savings from these restructuring actions were not material for the periods presented and are not expected to be material for future periods.

[0000858877-16-000090:mdna:272]
In the second quarter and first six months of fiscal 2015, we incurred restructuring and other charges of approximately $69 million and $387 million, respectively, which were related primarily to employee severance charges for employees impacted by the restructuring action announced in August 2014. See Note 5 to the Consolidated Financial Statements.

[0000858877-16-000090:mdna:273]
[same as prior period, unchanged from 0000858877-15-000073:mdna:225]

[0000858877-16-000090:mdna:274]
[same as prior period, unchanged from 0000858877-15-000073:mdna:226]

[0000858877-16-000090:mdna:275]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 23, 2016 |  | January 24, 2015 |  | January 23, 2016 |  | January 24, 2015 |
| Operating income |  | $ | 3,294 |  |  | $ | 2,622 |  |  | $ | 6,373 |  |  | $ | 4,964 |  |
| Operating income as a percentage of revenue |  | 27.6 | % |  | 22.0 | % |  | 25.9 | % |  | 20.5 | % |

[0000858877-16-000090:mdna:276]
For the second quarter of fiscal 2016, as compared with the second quarter of fiscal 2015, operating income increased by 26%, and as a percentage of revenue operating income increased by 5.6 percentage points. The increase in absolute dollars and as a percentage of revenue resulted primarily from a gross margin increase driven by impairment charges recorded in the second quarter of fiscal 2015, lower amortization expense related to acquisition-related intangible assets, and the $286 million pre-tax gain from the sale of our SP Video CPE Business. The increase as a percentage of revenue was also driven by the sale of the lower margin SP Video CPE Business during the second quarter of fiscal 2016.

[0000858877-16-000090:mdna:277]
For the first six months of fiscal 2016, as compared with the first six months of fiscal 2015, operating income increased by 28%, and as a percentage of revenue operating income increased by 5.4 percentage points. The increase resulted from the following: an increase in revenue; a gross margin percentage increase, driven in part by the Rockstar patent portfolio charge of $188 million (or 0.8 percentage points of the prior period revenue), impairment charges recorded in the second quarter of fiscal 2015, and lower amortization expense related to acquisition-related intangible assets; the $286 million pre-tax gain from the sale of our SP Video CPE Business and a decrease in restructuring and other charges related to the restructuring action announced in August 2014.

[0000858877-16-000090:mdna:278]
[same as prior period, unchanged from 0000858877-15-000073:mdna:229]

[0000858877-16-000090:mdna:279]
[same as prior period, unchanged from 0000858877-15-000073:mdna:230]

[0000858877-16-000090:mdna:280]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 23, 2016 |  | January 24, 2015 |  | Variancein Dollars |  | January 23, 2016 |  | January 24, 2015 |  | Variancein Dollars |
| Interest income |  | $ | 237 |  |  | $ | 189 |  |  | $ | 48 |  |  | $ | 462 |  |  | $ | 368 |  |  | $ | 94 |  |
| Interest expense |  | (162 | ) |  | (139 | ) |  | (23 | ) |  | (321 | ) |  | (278 | ) |  | (43 | ) |
| Interest income (expense), net |  | $ | 75 |  |  | $ | 50 |  |  | $ | 25 |  |  | $ | 141 |  |  | $ | 90 |  |  | $ | 51 |  |

[0000858877-16-000090:mdna:281]
For the second quarter and first six months of fiscal 2016, interest income increased by 25% and 26%, respectively, compared with the corresponding periods in fiscal 2015, driven by an increase in our portfolio of cash, cash equivalents, and fixed income investments as well as higher yields on our portfolio of cash and investments. Interest expense in the second quarter and first six months of fiscal 2016, compared with the corresponding periods in fiscal 2015, was higher driven by higher average debt balances.

[0000858877-16-000090:mdna:282]
[same as prior period, unchanged from 0000858877-15-000073:mdna:271]

[0000858877-16-000090:mdna:283]
[same as prior period, unchanged from 0000858877-15-000073:mdna:272]

[0000858877-16-000090:mdna:284]
[same as prior period, unchanged from 0000858877-15-000073:mdna:233]

[0000858877-16-000090:mdna:285]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 23, 2016 |  | January 24, 2015 |  | Variancein Dollars |  | January 23, 2016 |  | January 24, 2015 |  | Variancein Dollars |
| Gains (losses) on investments, net: |  |  |  |  |  |  |  |  |  |  |  |  |
| Publicly traded equity securities |  | $ | 2 |  |  | $ | 60 |  |  | $ | (58 | ) |  | $ | (7 | ) |  | $ | 56 |  |  | $ | (63 | ) |
| Fixed income securities |  | (21 | ) |  | 9 |  |  | (30 | ) |  | (13 | ) |  | 20 |  |  | (33 | ) |
| Total available-for-sale investments |  | (19 | ) |  | 69 |  |  | (88 | ) |  | (20 | ) |  | 76 |  |  | (96 | ) |
| Privately held companies |  | (36 | ) |  | 134 |  |  | (170 | ) |  | (47 | ) |  | 101 |  |  | (148 | ) |
| Net gains (losses) on investments |  | (55 | ) |  | 203 |  |  | (258 | ) |  | (67 | ) |  | 177 |  |  | (244 | ) |
| Other gains (losses), net |  | (8 | ) |  | (2 | ) |  | (6 | ) |  | (4 | ) |  | 2 |  |  | (6 | ) |
| Other income (loss), net |  | $ | (63 | ) |  | $ | 201 |  |  | $ | (264 | ) |  | $ | (71 | ) |  | $ | 179 |  |  | $ | (250 | ) |

[0000858877-16-000090:mdna:286]
The change in total net gains (losses) on available-for-sale investments in the second quarter and first six months of fiscal 2016, as compared with the corresponding periods in fiscal 2015, was primarily attributable to lower realized gains on publicly traded equity securities in the current periods as a result of market conditions and the timing of sales of these securities.

[0000858877-16-000090:mdna:287]
The change in net gains (losses) on investments in privately held companies for the second quarter and first six months of fiscal 2016, as compared with the corresponding periods in fiscal 2015, was primarily due to a gain of $126 million related to the reorganization of our investment in VCE Company, LLC, which was recorded in the second quarter of fiscal 2015, higher impairment charges on certain investments in privately held companies, and lower realized gains from various investments in privately held companies.

[0000858877-16-000090:mdna:288]
The change in other gains (losses), net in the second quarter and first six months of fiscal 2016, as compared with the corresponding periods in fiscal 2015, was driven by net unfavorable foreign exchange impacts, higher donation expenses and impacts from equity derivatives.

[0000858877-16-000090:mdna:289]
[same as prior period, unchanged from 0000858877-15-000073:mdna:240]

[0000858877-16-000090:mdna:290]
[same as prior period, unchanged from 0000858877-15-000073:mdna:241]

[0000858877-16-000090:mdna:291]
The provision for income taxes resulted in an effective tax rate of 4.8% for the second quarter of fiscal 2016 compared with 16.6% for the second quarter of fiscal 2015, which resulted in a net 11.8 percentage point decrease in the effective tax rate for the second quarter of fiscal 2016 as compared with the second quarter of fiscal 2015. The provision for income taxes resulted in an effective tax rate of 13.4% for the first six months of fiscal 2016, as compared with an effective tax rate of 19.3% for the first six months of fiscal 2015, which resulted in a net 5.9 percentage point decrease in the effective tax rate for the first six months of fiscal 2016 as compared with the first six months of fiscal 2015. The decrease in the effective tax rates for both the second quarter and first six months of fiscal 2016, as compared with the second quarter and first six months of fiscal 2015, was primarily due to the recognition of a net benefit to the provision for income taxes of approximately $367 million related to our settlement with the IRS of all outstanding items covering fiscal 2008 through fiscal 2010 and a tax benefit of $156 million related to permanent reinstatement of the U.S. federal R&D tax credit, of which $84 million related to fiscal 2015 R&D expenses. See Note 16 to the Consolidated Financial Statements.

[0000858877-16-000090:mdna:292]
[same as prior period, unchanged from 0000858877-15-000073:mdna:280]

[0000858877-16-000090:mdna:293]
[same as prior period, unchanged from 0000858877-15-000073:mdna:281]

[0000858877-16-000090:mdna:294]
[same as prior period, unchanged from 0000858877-15-000073:mdna:246]

[0000858877-16-000090:mdna:295]
[same as prior period, unchanged from 0000858877-15-000073:mdna:247]

[0000858877-16-000090:mdna:296]
[same as prior period, unchanged from 0000858877-15-000073:mdna:248]

[0000858877-16-000090:mdna:297]
[same as prior period, unchanged from 0000858877-15-000073:mdna:249]

[0000858877-16-000090:mdna:298]
|  | January 23, 2016 |  | July 25, 2015 |  | Increase (Decrease) |
| Cash and cash equivalents | $ | 6,314 |  |  | $ | 6,877 |  |  | $ | (563 | ) |
| Fixed income securities | 52,630 |  |  | 51,974 |  |  | 656 |  |
| Publicly traded equity securities | 1,431 |  |  | 1,565 |  |  | (134 | ) |
| Total | $ | 60,375 |  |  | $ | 60,416 |  |  | $ | (41 | ) |

[0000858877-16-000090:mdna:299]
The slight net decrease in cash and cash equivalents and investments in the first six months of fiscal 2016 was driven by cash returned to shareholders in the form of repurchase of common stock of $2.3 billion under the stock repurchase program and cash dividends of $2.1 billion. Other significant uses of cash in the first six months of fiscal 2016 included net cash paid for acquisitions and investments in privately-held companies of $1.2 billion, repayment of debt of $0.9 billion, and capital expenditures of $0.6 billion. Partially offsetting these cash outflows were cash provided by operating activities of $6.7 billion and proceeds from the sale of our SP Video CPE Business of $0.4 billion.

[0000858877-16-000090:mdna:300]
Our total in cash and cash equivalents and investments held by various foreign subsidiaries was $56.5 billion and $53.4 billion as of January 23, 2016 and July 25, 2015, respectively. Under current tax laws and regulations, if these assets were to be distributed from the foreign subsidiaries to the United States in the form of dividends or otherwise, we would be subject to additional U.S. income taxes (subject to an adjustment for foreign tax credits) and foreign withholding taxes. The balance of cash and cash equivalents and investments available in the United States as of January 23, 2016 and July 25, 2015 was $3.9 billion and $7.0 billion, respectively. In the third quarter of fiscal 2016, we announced that we entered into a definitive agreement to acquire Jasper. This acquisition will reduce our current balance of cash and cash equivalents and investments available in the United States by approximately $1.4 billion upon completion. See Note 3 to the Consolidated Financial Statements.

[0000858877-16-000090:mdna:301]
[same as prior period, unchanged from 0000858877-15-000073:mdna:253]

[0000858877-16-000090:mdna:302]
[same as prior period, unchanged from 0000858877-15-000073:mdna:254]

[0000858877-16-000090:mdna:303]
[same as prior period, unchanged from 0000858877-15-000073:mdna:255]

[0000858877-16-000090:mdna:304]
|  | Six Months Ended |
|  | January 23, 2016 |  | January 24, 2015 |
| Net cash provided by operating activities | $ | 6,688 |  |  | $ | 5,374 |  |
| Acquisition of property and equipment | (576 | ) |  | (550 | ) |
| Free cash flow | $ | 6,112 |  |  | $ | 4,824 |  |

[0000858877-16-000090:mdna:305]
[same as prior period, unchanged from 0000858877-15-000073:mdna:257]

[0000858877-16-000090:mdna:306]
[same as prior period, unchanged from 0000858877-15-000073:mdna:290]

[0000858877-16-000090:mdna:307]
[same as prior period, unchanged from 0000858877-15-000073:mdna:291]

[0000858877-16-000090:mdna:308]
We consider free cash flow to be a liquidity measure that provides useful information to management and investors because of our intent to return a stated percentage of free cash flow to shareholders in the form of dividends and stock repurchases. We further regard free cash flow as a useful measure because it reflects cash that can be used to, among other things, invest in our business, make strategic acquisitions, repurchase common stock, and pay dividends on our common stock, after deducting capital investments. A limitation of the utility of free cash flow as a measure of financial performance and liquidity is that the free cash flow does not represent the total increase or decrease in our cash balance for the period. In addition, we have other required uses of cash, including repaying the principal of our outstanding indebtedness. Free cash flow is not a measure calculated in accordance with U.S. generally accepted accounting principles and should not be regarded in isolation or as an alternative for net income provided by operating activities or any other measure calculated in accordance with such principles, and other companies may calculate free cash flow in a different manner than we do.

[0000858877-16-000090:mdna:309]
[same as prior period, unchanged from 0000858877-15-000073:mdna:261]

[0000858877-16-000090:mdna:310]
|  |  | DIVIDENDS |  | STOCK REPURCHASE PROGRAM |  |  |
| Quarter Ended |  | Per Share |  | Amount |  | Shares |  | Weighted-Average Price per Share |  | Amount |  | TOTAL |
| Fiscal 2016 |  |  |  |  |  |  |  |  |  |  |  |  |
| January 23, 2016 |  | $ | 0.21 |  |  | $ | 1,065 |  |  | 48 |  |  | $ | 26.12 |  |  | $ | 1,262 |  |  | $ | 2,327 |  |
| October 24, 2015 |  | $ | 0.21 |  |  | $ | 1,068 |  |  | 45 |  |  | $ | 26.83 |  |  | $ | 1,207 |  |  | $ | 2,275 |  |
| Fiscal 2015 |  |  |  |  |  |  |  |  |  |  |  |  |
| July 25, 2015 |  | $ | 0.21 |  |  | $ | 1,069 |  |  | 35 |  |  | $ | 28.62 |  |  | $ | 1,005 |  |  | $ | 2,074 |  |
| April 25, 2015 |  | $ | 0.21 |  |  | $ | 1,070 |  |  | 35 |  |  | $ | 28.39 |  |  | $ | 1,008 |  |  | $ | 2,078 |  |
| January 24, 2015 |  | $ | 0.19 |  |  | $ | 974 |  |  | 44 |  |  | $ | 27.63 |  |  | $ | 1,208 |  |  | $ | 2,182 |  |
| October 25, 2014 |  | $ | 0.19 |  |  | $ | 973 |  |  | 41 |  |  | $ | 24.58 |  |  | $ | 1,013 |  |  | $ | 1,986 |  |

[0000858877-16-000090:mdna:311]
On February 10, 2016, our Board of Directors declared a quarterly dividend of $0.26 per common share to be paid on April 27, 2016 to all shareholders of record as of the close of business on April 6, 2016. Any future dividends will be subject to the approval of our Board of Directors.

[0000858877-16-000090:mdna:312]
On February 10, 2016, our Board of Directors authorized a $15 billion increase to the stock repurchase program. The remaining authorized amount for stock repurchases under this program, including the additional authorization, is approximately $16.9 billion, with no termination date.

[0000858877-16-000090:mdna:313]
[same as prior period, unchanged from 0000858877-15-000073:mdna:264]

[0000858877-16-000090:mdna:314]
|  | January 23, 2016 |  | July 25, 2015 |  | Increase (Decrease) |
| Accounts receivable, net | $ | 4,302 |  |  | $ | 5,344 |  |  | $ | (1,042 | ) |
| DSO | 33 |  |  | 38 |  |  | (5 | ) |

[0000858877-16-000090:mdna:315]
Our accounts receivable net, as of January 23, 2016 decreased by approximately 19% compared with the end of fiscal 2015. Our DSO as of January 23, 2016 was lower by five days as compared with the end of fiscal 2015, primarily due to product and service billings being more linear in the second quarter of fiscal 2016 compared with the fourth quarter of fiscal 2015.

[0000858877-16-000090:mdna:316]
[same as prior period, unchanged from 0000858877-15-000073:mdna:267]

[0000858877-16-000090:mdna:317]
|  | January 23, 2016 |  | July 25, 2015 |  | Increase (Decrease) |
| Inventories | $ | 1,362 |  |  | $ | 1,627 |  |  | $ | (265 | ) |
| Annualized inventory turns | 12.6 |  |  | 12.1 |  |  | 0.5 |  |
| Purchase commitments with contract manufacturers and suppliers | $ | 3,435 |  |  | $ | 4,078 |  |  | $ | (643 | ) |

[0000858877-16-000090:mdna:318]
[same as prior period, unchanged from 0000858877-15-000073:mdna:304]

[0000858877-16-000090:mdna:319]
[same as prior period, unchanged from 0000858877-15-000073:mdna:305]

[0000858877-16-000090:mdna:320]
Inventory and purchase commitments with contract manufacturers and suppliers as of January 23, 2016 each decreased by approximately 16% compared with the end of fiscal 2015. The decrease in inventory and purchase commitments with contract manufacturers and suppliers was in part due to the sale of the SP Video CPE Business. We believe our inventory and purchase commitments levels are in line with our current demand forecasts.

[0000858877-16-000090:mdna:321]
[same as prior period, unchanged from 0000858877-15-000073:mdna:270]

[0000858877-16-000090:mdna:322]
[same as prior period, unchanged from 0000858877-15-000073:mdna:273]

[0000858877-16-000090:mdna:323]
[same as prior period, unchanged from 0000858877-15-000073:mdna:274]

[0000858877-16-000090:mdna:324]
[same as prior period, unchanged from 0000858877-15-000073:mdna:275]

[0000858877-16-000090:mdna:325]
Financing Receivables and Guarantees We measure our net balance sheet exposure position related to our financing receivables and financing guarantees by reducing the total of gross financing receivables and financing guarantees by the associated allowances for credit loss and deferred revenue. As of January 23, 2016, our net balance sheet exposure position related to financing receivables and financing guarantees was as follows (in millions):

[0000858877-16-000090:mdna:326]
|  | FINANCING RECEIVABLES |  | FINANCING GUARANTEES |  |  |
| January 23, 2016 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts and Other |  | Total |  | Channel Partner |  | End-User Customers |  | Total |  | TOTAL |
| Financing receivables and guarantees | $ | 3,377 |  |  | $ | 2,177 |  |  | $ | 3,405 |  |  | $ | 8,959 |  |  | $ | 244 |  |  | $ | 113 |  |  | $ | 357 |  |  | $ | 9,316 |  |
| Unearned income | (177 | ) |  | — |  |  | — |  |  | (177 | ) |  | — |  |  | — |  |  | — |  |  | (177 | ) |
| Allowance for credit loss | (248 | ) |  | (80 | ) |  | (37 | ) |  | (365 | ) |  | — |  |  | — |  |  | — |  |  | (365 | ) |
| Deferred revenue | (5 | ) |  | (13 | ) |  | (1,714 | ) |  | (1,732 | ) |  | (100 | ) |  | (90 | ) |  | (190 | ) |  | (1,922 | ) |
| Net balance sheet exposure | $ | 2,947 |  |  | $ | 2,084 |  |  | $ | 1,654 |  |  | $ | 6,685 |  |  | $ | 144 |  |  | $ | 23 |  |  | $ | 167 |  |  | $ | 6,852 |  |

[0000858877-16-000090:mdna:327]
Financing Receivables  Financing receivables less unearned income increased by 1% compared with the end of fiscal 2015. The change was due to a 23% increase in loan receivables partially offset by a 6% decrease in lease receivables and a 5% decrease in financed service contracts and other. We provide financing to certain end-user customers and channel partners to enable sales of our products, services, and networking solutions. These financing arrangements include leases, financed service contracts, and loans. Arrangements related to leases are generally collateralized by a security interest in the underlying assets. Lease receivables include sales-type and direct-financing leases. We also provide certain qualified customers financing for long-term service contracts, which primarily relate to technical support services. Our loan financing arrangements may include not only financing the acquisition of our products and services but also providing additional funds for other costs associated with network installation and integration of our products and services. We expect to continue to expand the use of our financing programs in the near term.

[0000858877-16-000090:mdna:328]
Financing Guarantees  In the normal course of business, third parties may provide financing arrangements to our customers and channel partners under financing programs. The financing arrangements to customers provided by third parties are related to leases and loans and typically have terms of up to three years. In some cases, we provide guarantees to third parties for these lease and loan arrangements. The financing arrangements to channel partners consist of revolving short-term financing provided by third parties, generally with payment terms ranging from 60 to 90 days. In certain instances, these financing arrangements result in a transfer of our receivables to the third party. The receivables are derecognized upon transfer, as these transfers qualify as true sales, and we receive payments for the receivables from the third party based on our standard payment terms.

[0000858877-16-000090:mdna:329]
69

[0000858877-16-000090:mdna:330]
CISCO SYSTEMS, INC.

[0000858877-16-000090:mdna:331]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-16-000090:mdna:332]
The volume of channel partner financing was $6.5 billion and $6.2 billion for the three months ended January 23, 2016 and January 24, 2015, respectively. These financing arrangements facilitate the working capital requirements of the channel partners, and in some cases, we guarantee a portion of these arrangements. The balance of the channel partner financing subject to guarantees was $1.2 billion  as of each of January 23, 2016 and July 25, 2015, respectively. We could be called upon to make payments under these guarantees in the event of nonpayment by the channel partners or end-user customers. Historically, our payments under these arrangements have been immaterial. Where we provide a guarantee, we defer the revenue associated with the channel partner and end-user financing arrangement in accordance with revenue recognition policies, or we record a liability for the fair value of the guarantees. In either case, the deferred revenue is recognized as revenue when the guarantee is removed.

[0000858877-16-000090:mdna:333]
[same as prior period, unchanged from 0000858877-15-000073:mdna:282]

[0000858877-16-000090:mdna:334]
[same as prior period, unchanged from 0000858877-15-000073:mdna:283]

[0000858877-16-000090:mdna:335]
[same as prior period, unchanged from 0000858877-15-000073:mdna:284]

[0000858877-16-000090:mdna:336]
|  | Maturity Date |  | January 23, 2016 |  | July 25, 2015 |
| Senior notes: |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |
| Three-month LIBOR plus 0.05% | September 3, 2015 |  | $ | — |  |  | $ | 850 |  |
| Three-month LIBOR plus 0.28% | March 3, 2017 |  | 1,000 |  |  | 1,000 |  |
| Three-month LIBOR plus 0.31% | June 15, 2018 |  | 900 |  |  | 900 |  |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | 500 |  |  | 500 |  |
| Fixed-rate notes: |  |  |  |  |  |
| 5.50% | February 22, 2016 |  | 3,000 |  |  | 3,000 |  |
| 1.10% | March 3, 2017 |  | 2,400 |  |  | 2,400 |  |
| 3.15% | March 14, 2017 |  | 750 |  |  | 750 |  |
| 1.65% | June 15, 2018 |  | 1,600 |  |  | 1,600 |  |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 2,000 |  |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 1,750 |  |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 2,500 |  |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 1,500 |  |
| 2.90% | March 4, 2021 |  | 500 |  |  | 500 |  |
| 3.00% | June 15, 2022 |  | 500 |  |  | 500 |  |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1,000 |  |
| 3.50% | June 15, 2025 |  | 500 |  |  | 500 |  |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 2,000 |  |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 2,000 |  |
| Total |  |  | $ | 24,400 |  |  | $ | 25,250 |  |

[0000858877-16-000090:mdna:337]
Interest is payable semiannually on each class of the senior fixed-rate notes, each of which is redeemable by us at any time, subject to a make-whole premium. Interest is payable quarterly on the floating-rate notes. We were in compliance with all debt covenants as of January 23, 2016.

[0000858877-16-000090:mdna:338]
[same as prior period, unchanged from 0000858877-15-000073:mdna:287]

[0000858877-16-000090:mdna:339]
Other Debt  Other debt as of January 23, 2016 and July 25, 2015 includes secured borrowings associated with customer financing arrangements. The amount of borrowings outstanding under these arrangements was $2 million and $4 million as of January 23, 2016 and July 25, 2015, respectively.

[0000858877-16-000090:mdna:340]
CISCO SYSTEMS, INC.

[0000858877-16-000090:mdna:341]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-16-000090:mdna:342]
Commercial Paper  In fiscal 2011, we established a short-term debt financing program of up to $3.0 billion through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes. We had no commercial paper notes outstanding as of each of January 23, 2016 and July 25, 2015.

[0000858877-16-000090:mdna:343]
Credit Facility On May 15, 2015, we entered into a credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 15, 2020. Any advances under the credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (i) the highest of (a) the Federal Funds rate plus 0.50%, (b) Bank of America’s “prime rate” as announced from time to time, or (c) LIBOR, or a comparable or successor rate that is approved by the Administrative Agent (“Eurocurrency Rate”), for an interest period of one month plus 1.00%, or (ii) the Eurocurrency Rate, plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the Eurocurrency Rate be less than zero. The credit agreement requires that we comply with certain covenants, including that it maintains an interest coverage ratio as defined in the agreement.

[0000858877-16-000090:mdna:344]
We may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and/or extend the expiration date of the credit facility up to May 15, 2022. We were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under the credit facility.

[0000858877-16-000090:mdna:345]
[same as prior period, unchanged from 0000858877-15-000073:mdna:294]

[0000858877-16-000090:mdna:346]
|  | January 23, 2016 |  | July 25, 2015 |  | Increase (Decrease) |
| Service | $ | 9,657 |  |  | $ | 9,757 |  |  | $ | (100 | ) |
| Product | 5,528 |  |  | 5,426 |  |  | 102 |  |
| Total | $ | 15,185 |  |  | $ | 15,183 |  |  | $ | 2 |  |
| Reported as: |  |  |  |  |  |
| Current | $ | 9,796 |  |  | $ | 9,824 |  |  | $ | (28 | ) |
| Noncurrent | 5,389 |  |  | 5,359 |  |  | 30 |  |
| Total | $ | 15,185 |  |  | $ | 15,183 |  |  | $ | 2 |  |

[0000858877-16-000090:mdna:347]
The 1% decrease in deferred service revenue was driven by the timing of multiyear arrangements, the impact of ongoing amortization of deferred service revenue, and currency impacts. The 2% increase in deferred product revenue was primarily due to increased deferrals related to subscription revenue arrangements and also was due, to a lesser extent, to an increase in shipments not having met revenue recognition criteria as of January 23, 2016, partially offset by lower deferred revenue related to two-tier distributors.

[0000858877-16-000090:mdna:348]
[same as prior period, unchanged from 0000858877-15-000073:mdna:297]

[0000858877-16-000090:mdna:349]
[same as prior period, unchanged from 0000858877-15-000073:mdna:298]

[0000858877-16-000090:mdna:350]
We lease office space in many U.S. locations. Outside the United States, larger leased sites include sites in Belgium, Canada, China, France, Germany, India, Israel, Japan, Poland and the United Kingdom. We also lease equipment and vehicles. The future minimum lease payments under all of our noncancelable operating leases with an initial term in excess of one year as of January 23, 2016 were $1.1 billion.

[0000858877-16-000090:mdna:351]
[same as prior period, unchanged from 0000858877-15-000073:mdna:300]

[0000858877-16-000090:mdna:352]
[same as prior period, unchanged from 0000858877-15-000073:mdna:301]

[0000858877-16-000090:mdna:353]
Insieme Networks, Inc.  In the third quarter of fiscal 2012, we made an investment in Insieme, an early stage company focused on research and development in the data center market. As set forth in the agreement between Cisco and Insieme, this investment included $100 million of funding and a license to certain of our technology. Immediately prior to the call option exercise and acquisition described below, we owned approximately 83% of Insieme as a result of these investments and have consolidated the results of Insieme in our Consolidated Financial Statements. In connection with this investment, we entered into a put/call option agreement that provided us with the right to purchase the remaining interests in Insieme. In addition, the noncontrolling interest holders could require us to purchase their shares upon the occurrence of certain events.

[0000858877-16-000090:mdna:354]
71

[0000858877-16-000090:mdna:355]
CISCO SYSTEMS, INC.

[0000858877-16-000090:mdna:356]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-16-000090:mdna:357]
During the first quarter of fiscal 2014, we exercised our call option and entered into an agreement to purchase the remaining interests in Insieme. The acquisition closed in the second quarter of fiscal 2014, at which time the former noncontrolling interest holders became eligible to receive up to two milestone payments, which will be determined using agreed-upon formulas based primarily on revenue for certain of Insieme’s products. During the six months ended January 23, 2016 and January 24, 2015, we recorded compensation expense of $101 million and $104 million, respectively, related to the fair value of the vested portion of amounts that were earned or are expected to be earned by the former noncontrolling interest holders. Continued vesting and changes to the fair value of the amounts probable of being earned will result in adjustments to the recorded compensation expense in future periods. Based on the terms of the agreement, we have determined that the maximum amount that could be recorded as compensation expense by us is approximately $839 million (which includes the $724 million that has been expensed to date), net of forfeitures.

[0000858877-16-000090:mdna:358]
The former noncontrolling interest holders earned the maximum amount related to the first milestone payment and were paid   approximately $354 million for a portion of this amount during the first six months of fiscal 2016. The balance of the first milestone payment is expected to be paid primarily through the end of fiscal 2016. The second milestone payment, to the extent earned, is expected to be paid primarily during the first half of fiscal 2017.

[0000858877-16-000090:mdna:359]
Other Funding Commitments  We also have certain funding commitments primarily related to our investments in privately held companies and venture funds, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $188 million as of January 23, 2016, compared with $205 million as of July 25, 2015.

[0000858877-16-000090:mdna:360]
[same as prior period, unchanged from 0000858877-15-000073:mdna:309]

[0000858877-16-000090:mdna:361]
We consider our investments in unconsolidated variable interest entities to be off-balance sheet arrangements. In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers may be considered to be variable interest entities. We evaluate on an ongoing basis our investments in these privately held companies and customer financings, and we have determined that as of January 23, 2016 there were no material unconsolidated variable interest entities.

[0000858877-16-000090:mdna:362]
[same as prior period, unchanged from 0000858877-15-000073:mdna:311]

[0000858877-16-000090:mdna:363]
[same as prior period, unchanged from 0000858877-15-000073:mdna:312]

[0000858877-16-000090:mdna:364]
[same as prior period, unchanged from 0000858877-15-000073:mdna:313]

[0000858877-16-000090:mdna:365]
We periodically engage in securities lending activities with certain of our available for sale investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. The average daily balance of securities lending for each of the six months ended January 23, 2016 and January 24, 2015 was $0.6 billion. We require collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. We engage in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify us against collateral losses. As of January 23, 2016 and July 25, 2015, we had no outstanding securities lending transactions. We believe these arrangements do not present a material risk or impact to our liquidity requirements.

[0000858877-16-000090:mdna:366]
[same as prior period, unchanged from 0000858877-15-000073:mdna:315]

[0000858877-16-000090:mdna:367]
[same as prior period, unchanged from 0000858877-15-000073:mdna:316]

[0000858877-16-000090:mdna:368]
72
