# CSCO note change history — 0000858877-15-000073 → 0000858877-16-000090


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2016-02-18):
[0000858877-16-000090:note_history:1]
The Company leases office space in many U.S. locations. Outside the United States, larger leased sites include sites in Belgium, Canada, China, France, Germany, India, Israel, Japan, Poland and the United Kingdom. The Company also leases equipment and vehicles. Future minimum lease payments under all noncancelable operating leases with an initial term in excess of one year as of January 23, 2016 are as follows (in millions):
  (was, 2015-11-19, similarity 0.9823):
[0000858877-15-000073:note_history:1]
The Company leases office space in many U.S. locations.  Outside the United States, larger leased sites include sites in Belgium, Canada, China, France, Germany, India, Israel, Japan, Poland, and the United Kingdom.  The Company also leases equipment and vehicles.  Future minimum lease payments under all noncancelable operating leases with an initial term in excess of one year as of October 24, 2015 are as follows (in millions):

- changed (2016-02-18):
[0000858877-16-000090:note_history:2]
| Fiscal Year | Amount |
| 2016 (remaining six months) | $ | 184 |  |
| 2017 | 268 |  |
| 2018 | 204 |  |
| 2019 | 117 |  |
| 2020 | 96 |  |
| Thereafter | 222 |  |
| Total | $ | 1,091 |  |
  (was, 2015-11-19, similarity 0.9836):
[0000858877-15-000073:note_history:2]
| Fiscal Year | Amount |
| 2016 (remaining nine months) | $ | 266 |  |
| 2017 | 263 |  |
| 2018 | 189 |  |
| 2019 | 105 |  |
| 2020 | 83 |  |
| Thereafter | 189 |  |
| Total | $ | 1,095 |  |

- changed (2016-02-18):
[0000858877-16-000090:note_history:3]
The Company purchases components from a variety of suppliers and uses several contract manufacturers to provide manufacturing services for its products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, the Company enters into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by the Company or establish the parameters defining the Company’s requirements.  A significant portion of the Company’s reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. In certain instances, these agreements allow the Company the option to cancel, reschedule, and adjust the Company’s requirements based on its business needs prior to firm orders being placed.  As of January 23, 2016 and July 25, 2015, the Company had total purchase commitments for inventory of $3,435 million and $4,078 million, respectively.
  (was, 2015-11-19, similarity 0.993):
[0000858877-15-000073:note_history:3]
The Company purchases components from a variety of suppliers and uses several contract manufacturers to provide manufacturing services for its products.  During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, the Company enters into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by the Company or establish the parameters defining the Company’s requirements.  A significant portion of the Company’s reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments.  In certain instances, these agreements allow the Company the option to cancel, reschedule, and adjust the Company’s requirements based on its business needs prior to firm orders being placed.  As of October 24, 2015 and July 25, 2015, the Company had total purchase commitments for inventory of $4,028 million and $4,078 million, respectively.

- changed (2016-02-18):
[0000858877-16-000090:note_history:4]
The Company records a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of its future demand forecasts consistent with the valuation of the Company’s excess and obsolete inventory. As of January 23, 2016 and July 25, 2015, the liability for these purchase commitments was $180 million and $156 million, respectively, and was included in other current liabilities.
  (was, 2015-11-19, similarity 0.9597):
[0000858877-15-000073:note_history:4]
The Company records a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of its future demand forecasts consistent with the valuation of the Company’s excess and obsolete inventory.  As of October 24, 2015 and July 25, 2015, the liability for these purchase commitments was $178 million and $156 million, respectively, and was included in other current liabilities.

- changed (2016-02-18):
[0000858877-16-000090:note_history:5]
|  | Three Months Ended |  | Six Months Ended |
|  | January 23, 2016 |  | January 24, 2015 |  | January 23, 2016 |  | January 24, 2015 |
| Compensation expense related to acquisitions | $ | 71 |  |  | $ | 94 |  |  | $ | 144 |  |  | $ | 192 |  |
  (was, 2015-11-19, similarity 0.6985):
[0000858877-15-000073:note_history:5]
|  | Three Months Ended |
|  | October 24, 2015 |  | October 25, 2014 |
| Compensation expense related to acquisitions | $ | 73 |  |  | $ | 98 |  |

- changed (2016-02-18):
[0000858877-16-000090:note_history:6]
As of January 23, 2016, the Company estimated that future cash compensation expense of up to $230 million may be required to be recognized pursuant to the applicable business combination agreements, which included the remaining potential compensation expense related to Insieme Networks, Inc. ("Insieme"), as more fully discussed immediately below.
  (was, 2015-11-19, similarity 0.9794):
[0000858877-15-000073:note_history:6]
As of October 24, 2015, the Company estimated that future cash compensation expense of up to $253 million may be required to be recognized pursuant to the applicable business combination agreements, which included the remaining potential compensation expense related to Insieme Networks, Inc. ("Insieme"), as more fully discussed immediately below.

- added (2016-02-18):
[0000858877-16-000090:note_history:7]
During the first quarter of fiscal 2014, the Company exercised its call option and entered into an agreement to purchase the remaining interests in Insieme. The acquisition closed in the second quarter of fiscal 2014, at which time the former noncontrolling interest holders became eligible to receive up to two milestone payments, which will be determined using agreed-upon formulas based primarily on revenue for certain of Insieme’s products. The Company recorded compensation expense of $50 million and $51 million during the three months ended January 23, 2016 and January 24, 2015, respectively, and $101 million and $104 million during the six months ended January 23, 2016 and January 24, 2015, respectively, related to the fair value of the vested portion of amounts that were earned or are expected to be earned by the former noncontrolling interest holders. Continued vesting and changes to the fair value of the amounts probable of being earned will result in adjustments to the recorded compensation expense in future periods.  Based on the terms of the agreement, the Company has determined that the maximum amount that could be recorded as compensation expense by the Company is approximately $839 million (which includes the $724 million that has been expensed to date), net of forfeitures.

- added (2016-02-18):
[0000858877-16-000090:note_history:8]
The former noncontrolling interest holders earned the maximum amount related to the first milestone payment and were paid   approximately $354 million for a portion of this amount during the six months ended January 23, 2016. The balance of the first milestone payment is expected to be paid primarily through the end of fiscal 2016. The second milestone payment, to the extent earned, is expected to be paid primarily during the first half of fiscal 2017.

- changed (2016-02-18):
[0000858877-16-000090:note_history:9]
The Company also has certain funding commitments, primarily related to its investments in privately held companies and venture funds, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $188 million and $205 million as of January 23, 2016 and July 25, 2015, respectively.
  (was, 2015-11-19, similarity 0.9563):
[0000858877-15-000073:note_history:9]
The Company also has certain funding commitments, primarily related to its investments in privately held companies and venture funds, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand.  The funding commitments were $192 million and $205 million as of October 24, 2015 and July 25, 2015, respectively.

- changed (2016-02-18):
[0000858877-16-000090:note_history:10]
|  | Six Months Ended |
|  | January 23, 2016 |  | January 24, 2015 |
| Balance at beginning of period | $ | 449 |  |  | $ | 446 |  |
| Provision for warranties issued | 322 |  |  | 355 |  |
| Payments | (340 | ) |  | (327 | ) |
| Acquisition/divestitures | (28 | ) |  | — |  |
| Balance at end of period | $ | 403 |  |  | $ | 474 |  |
  (was, 2015-11-19, similarity 0.8155):
[0000858877-15-000073:note_history:10]
|  | Three Months Ended |
|  | October 24, 2015 |  | October 25, 2014 |
| Balance at beginning of period | $ | 449 |  |  | $ | 446 |  |
| Provision for warranties issued | 150 |  |  | 143 |  |
| Payments | (166 | ) |  | (153 | ) |
| Balance at end of period | $ | 433 |  |  | $ | 436 |  |

- changed (2016-02-18):
[0000858877-16-000090:note_history:11]
Channel Partner Financing Guarantees   The Company facilitates arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, generally with payment terms ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, the Company guarantees a portion of these arrangements. The volume of channel partner financing was $6.5 billion and $6.2 billion for the three months ended January 23, 2016 and January 24, 2015, respectively and was $13.4 billion and $12.5 billion for the six months ended January 23, 2016 and January 24, 2015, respectively. The balance of the channel partner financing subject to guarantees was $1.2 billion as of each of January 23, 2016 and July 25, 2015, respectively.
  (was, 2015-11-19, similarity 0.7505):
[0000858877-15-000073:note_history:11]
Channel Partner Financing Guarantees   The Company facilitates arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, generally with payment terms ranging from 60 to 90 days.  These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, the Company guarantees a portion of these arrangements.  The volume of channel partner financing was $6.9 billion and $6.3 billion for the three months ended October 24, 2015 and October 25, 2014, respectively.  The balance of the channel partner financing subject to guarantees was $1.2 billion as of each October 24, 2015 and July 25, 2015.

- changed (2016-02-18):
[0000858877-16-000090:note_history:12]
End-User Financing Guarantees   The Company also provides financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. The volume of financing provided by third parties for leases and loans as to which the Company had provided guarantees was $16 million and $39 million for the three months ended January 23, 2016 and January 24, 2015, respectively, and was $39 million and $65 million for the six months ended January 23, 2016 and January 24, 2015, respectively.
  (was, 2015-11-19, similarity 0.8508):
[0000858877-15-000073:note_history:12]
End-User Financing Guarantees   The Company also provides financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years.  The volume of financing provided by third parties for leases and loans as to which the Company had provided guarantees was $23 million and $26 million for the three months ended October 24, 2015 and October 25, 2014, respectively.

- changed (2016-02-18):
[0000858877-16-000090:note_history:13]
Financing Guarantee Summary   The aggregate amounts of financing guarantees outstanding at January 23, 2016 and July 25, 2015, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):
  (was, 2015-11-19, similarity 0.9776):
[0000858877-15-000073:note_history:13]
Financing Guarantee Summary   The aggregate amounts of financing guarantees outstanding at October 24, 2015 and July 25, 2015, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

- added (2016-02-18):
[0000858877-16-000090:note_history:14]
|  | January 23, 2016 |  | July 25, 2015 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 244 |  |  | $ | 288 |  |
| End user | 113 |  |  | 129 |  |
| Total | $ | 357 |  |  | $ | 417 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (100 | ) |  | $ | (127 | ) |
| End user | (90 | ) |  | (107 | ) |
| Total | $ | (190 | ) |  | $ | (234 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue | $ | 167 |  |  | $ | 183 |  |

- changed (2016-02-18):
[0000858877-16-000090:note_history:15]
Other Guarantees   The Company’s other guarantee arrangements as of January 23, 2016 and July 25, 2015 that were subject to recognition and disclosure requirements were not material.
  (was, 2015-11-19, similarity 0.9647):
[0000858877-15-000073:note_history:15]
Other Guarantees   The Company’s other guarantee arrangements as of October 24, 2015 and July 25, 2015 that were subject to recognition and disclosure requirements were not material.

- changed (2016-02-18):
[0000858877-16-000090:note_history:16]
The Company has recorded in other current liabilities a liability for the expected remediation cost for certain products sold in prior fiscal years containing memory components manufactured by a single supplier between 2005 and 2010. These components were widely used across the industry and are included in a number of the Company's products. Defects in some of these components have caused products to fail after a power cycle event. Defect rates due to this issue have been and are expected to be low. However, the Company has seen a small number of its customers experience a growing number of failures in their networks as a result of this component problem. Although the majority of these products was beyond the Company's warranty terms, the Company has been proactively working with customers on mitigation. Prior to the second quarter of fiscal 2014, the Company had a liability of $63 million related to this issue for expected remediation costs based on the intended approach at that time. In February 2014, on the basis of the growing number of failures described above, the Company decided to expand its approach, which resulted in a charge to product cost of sales of $655 million being recorded for the second quarter of fiscal 2014. During the third quarter of fiscal 2015, an adjustment to product cost of sales of $164 million was recorded to reduce the liability, reflecting net lower than previously estimated future costs to remediate the impacted customer products. The supplier component remediation liability as of January 23, 2016 and July 25, 2015 was $375 million and $408 million, respectively.
  (was, 2015-11-19, similarity 0.9956):
[0000858877-15-000073:note_history:16]
The Company has recorded in other current liabilities a liability for the expected remediation cost for certain products sold in prior fiscal years containing memory components manufactured by a single supplier between 2005 and 2010.  These components were widely used across the industry and are included in a number of the Company's products.  Defects in some of these components have caused products to fail after a power cycle event.  Defect rates due to this issue have been and are expected to be low.  However, the Company has seen a small number of its customers experience a growing number of failures in their networks as a result of this component problem.  Although the majority of these products was beyond the Company's warranty terms, the Company has been proactively working with customers on mitigation.  Prior to the second quarter of fiscal 2014, the Company had a liability of $63 million related to this issue for expected remediation costs based on the intended approach at that time. In February 2014, on the basis of the growing number of failures described above, the Company decided to expand its approach, which resulted in a charge to product cost of sales of $655 million being recorded for the second quarter of fiscal 2014.  During the third quarter of fiscal 2015, an adjustment to product cost of sales of $164 million was recorded to reduce the liability, reflecting net lower than previously estimated future costs to remediate the impacted customer products.  The supplier component remediation liability as of October 24, 2015 and July 25, 2015 was $391 million and $408 million, respectively.

- changed (2016-02-18):
[0000858877-16-000090:note_history:17]
The Company is providing such indemnifications, among other cases, in matters involving certain of the Company’s service provider customers that are subject to patent infringement claims asserted by Sprint Communications Company, L.P. (“Sprint”) now pending in Kansas and Delaware. Sprint alleges that the service provider customers infringe Sprint’s patents by offering Voice over Internet Protocol-based telephone services utilizing products provided by the Company and other manufacturers. Sprint seeks monetary damages. Sprint’s cases in Kansas include claims against Comcast and Time Warner Cable, and the case in Delaware for which the Company is providing indemnification involves Cox Communications. At the request of Sprint and Comcast, on August 5, 2015, the judge in Sprint’s Kansas action ordered a six-month stay of the patent litigation between those parties for them to pursue a resolution of their dispute. In addition, on May 15, 2015, the judge in Sprint's Delaware action against Cox ruled invalid six of the patents that Sprint asserted Cox had infringed and a final judgment was entered on August 27, 2015, of invalidity, which Sprint appealed on October 1, 2015. In May 2015 the Company filed two declaratory judgment actions against Sprint seeking declarations that the patents Sprint asserted against the Company’s customers are invalid and/or not infringed. Cox has filed a motion for summary judgment of non-infringement for the five remaining Sprint patents that are actively being litigated against Cox in Delaware, and Comcast has also won a judgment of non-infringement, now being appealed by Sprint, in a separate case brought against it by Sprint in Delaware. In light of the invalidity rulings against Sprint in Delaware, on October 8, 2015, the judge in Sprint’s Kansas actions ordered an additional stay of Sprint’s Kansas actions including the case against Time Warner Cable, pending resolution of Sprint’s appeal of the Delaware Judge’s judgment of invalidity in the Cox case.
  (was, 2015-11-19, similarity 0.999):
[0000858877-15-000073:note_history:17]
The Company is providing such indemnifications, among other cases, in matters involving certain of the Company’s service provider customers that are subject to patent infringement claims asserted by Sprint Communications Company, L.P. (“Sprint”) now pending in Kansas and Delaware.  Sprint alleges that the service provider customers infringe Sprint’s patents by offering Voice over Internet Protocol-based telephone services utilizing products provided by the Company and other manufacturers.  Sprint seeks monetary damages.  Sprint’s cases in Kansas include claims against Comcast and Time Warner Cable, and the case in Delaware for which the Company is providing indemnification involves Cox Communications.  At the request of Sprint and Comcast, on August 5, 2015, the judge in Sprint’s Kansas action ordered a six-month stay of the patent litigation between those parties for them to pursue a resolution of their dispute. In addition, on May 15, 2015, the judge in Sprint's Delaware action against Cox ruled invalid six of the patents that Sprint asserted Cox had infringed and a final judgment was entered on August 27, 2015, of invalidity, which Sprint appealed on October 1, 2015.  In May 2015 the Company filed two declaratory judgment actions against Sprint seeking declarations that the patents Sprint asserted against the Company’s customers are invalid and/or not infringed.  Cox has filed a motion for summary judgment of non-infringement for the five remaining Sprint patents that are actively being litigated against Cox in Delaware, Comcast has also won a judgment of non-infringement, now being appealed by Sprint, in a separate case brought against it by Sprint in Delaware.  In light of the invalidity rulings against Sprint in Delaware, on October 8, 2015, the judge in Sprint’s Kansas actions ordered an additional stay of Sprint’s Kansas actions including the case against Time Warner Cable, pending resolution of Sprint’s appeal of the Delaware Judge’s judgment of invalidity in the Cox case.

- added (2016-02-18):
[0000858877-16-000090:note_history:18]
The asserted claims by Brazilian federal tax authorities are for calendar years 2003 through 2008, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $209 million for the alleged evasion of import and other taxes, $942 million for interest, and $929 million for various penalties, all determined using an exchange rate as of January 23, 2016. The Company has completed a thorough review of the matters and believes the asserted claims against the Company’s Brazilian subsidiary are without merit, and the Company is defending the claims vigorously. While the Company believes there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, the Company is unable to determine the likelihood of an unfavorable outcome against its Brazilian subsidiary and is unable to reasonably estimate a range of loss, if any. The Company does not expect a final judicial determination for several years.

- removed (2016-02-18):
[0000858877-15-000073:note_history:19]
During the first quarter of fiscal 2014, the Company exercised its call option and entered into an agreement to purchase the remaining interests in Insieme.  The acquisition closed in the second quarter of fiscal 2014, at which time the former noncontrolling interest holders became eligible to receive up to two milestone payments, which will be determined using agreed-upon formulas based primarily on revenue for certain of Insieme’s products.  The Company recorded compensation expense of $51 million and $53 million during the three months ended October 24, 2015 and October 25, 2014, respectively, related to the fair value of the vested portion of amounts that were earned or are expected to be earned by the former noncontrolling interest holders.  Continued vesting and changes to the fair value of the amounts probable of being earned will result in adjustments to the recorded compensation expense in future periods.  Based on the terms of the agreement, the Company has determined that the maximum amount that could be recorded as compensation expense by the Company is approximately $841 million (which includes the $674 million that has been expensed to date), net of forfeitures.

- removed (2016-02-18):
[0000858877-15-000073:note_history:20]
The former noncontrolling interest holders earned the maximum amount related to the first milestone payment and were paid   approximately $291 million for a portion of this amount during the first quarter of fiscal 2016.  The balance of the first milestone payment is expected to be paid primarily through the end of fiscal 2016.  The second milestone payment, to the extent earned, is expected to be paid primarily during the first half of fiscal 2017.

- removed (2016-02-18):
[0000858877-15-000073:note_history:21]
|  | October 24, 2015 |  | July 25, 2015 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 250 |  |  | $ | 288 |  |
| End user | 124 |  |  | 129 |  |
| Total | $ | 374 |  |  | $ | 417 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (96 | ) |  | $ | (127 | ) |
| End user | (100 | ) |  | (107 | ) |
| Total | $ | (196 | ) |  | $ | (234 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue | $ | 178 |  |  | $ | 183 |  |

- removed (2016-02-18):
[0000858877-15-000073:note_history:22]
The asserted claims by Brazilian federal tax authorities are for calendar years 2003 through 2008, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007.  The total asserted claims by Brazilian state and federal tax authorities aggregate to approximately $222 million for the alleged evasion of import and other taxes, approximately $1.0 billion for interest, and approximately $1.0 billion for various penalties, all determined using an exchange rate as of October 24, 2015.  The Company has completed a thorough review of the matters and believes the asserted claims against the Company’s Brazilian subsidiary are without merit, and the Company is defending the claims vigorously.  While the Company believes there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, the Company is unable to determine the likelihood of an unfavorable outcome against its Brazilian subsidiary and is unable to reasonably estimate a range of loss, if any.  The Company does not expect a final judicial determination for several years.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2016-02-18):
[0000858877-16-000090:note_history:23]
The accompanying financial data as of January 23, 2016 and for the three and six months ended January 23, 2016 and January 24, 2015 has been prepared by the Company, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (SEC).  Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (GAAP) have been condensed or omitted pursuant to such rules and regulations.  The July 25, 2015 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, the Company believes that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended July 25, 2015.
  (was, 2015-11-19, similarity 0.9636):
[0000858877-15-000073:note_history:23]
The accompanying financial data as of October 24, 2015 and for the three months ended October 24, 2015 and October 25, 2014 has been prepared by the Company, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (SEC).  Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (GAAP) have been condensed or omitted pursuant to such rules and regulations.  The July 25, 2015 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States.  However, the Company believes that the disclosures are adequate to make the information presented not misleading.  These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended July 25, 2015.

- changed (2016-02-18):
[0000858877-16-000090:note_history:24]
In the opinion of management, all normal recurring adjustments necessary to present fairly the consolidated balance sheet as of January 23, 2016; the results of operations and the statements of comprehensive income for the three and six months ended January 23, 2016 and January 24, 2015; and the statements of cash flows and equity for the six months ended January 23, 2016 and January 24, 2015, as applicable, have been made. The results of operations for the three and six months ended January 23, 2016 are not necessarily indicative of the operating results for the full fiscal year or any future periods.
  (was, 2015-11-19, similarity 0.7732):
[0000858877-15-000073:note_history:24]
In the opinion of management, all normal recurring adjustments necessary to present fairly the consolidated balance sheet as of October 24, 2015; the results of operations, statements of comprehensive income, cash flows and equity for the three months ended October 24, 2015 and October 25, 2014, as applicable, have been made.  The results of operations for the three months ended October 24, 2015 are not necessarily indicative of the operating results for the full fiscal year or any future periods.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2016-02-18):
[0000858877-16-000090:note_history:25]
Recent Accounting Standards or Updates Not Yet Effective  In May 2014, the Financial Accounting Standards Board (FASB) issued an accounting standard update related to revenue from contracts with customers, which will supersede nearly all current U.S. GAAP guidance on this topic and eliminate industry-specific guidance. The underlying principle is to recognize revenue when promised goods or services are transferred to customers in an amount that reflects the consideration that is expected to be received for those goods or services. This accounting standard update, as amended, will be effective for the Company beginning in the first quarter of fiscal 2019. The new revenue standard may be applied retrospectively to each prior period presented or retrospectively with the cumulative effect recognized as of the date of adoption. Early adoption is permitted, but no earlier than fiscal 2018. The Company is currently evaluating the timing of its adoption and impact of this accounting standard update on its Consolidated Financial Statements.

- added (2016-02-18):
[0000858877-16-000090:note_history:26]
In November 2015, the FASB issued an accounting standard update that requires that all deferred tax assets and liabilities, along with any related valuation allowance, be classified as noncurrent on the balance sheet. The accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2018, and early adoption is permitted. The accounting standard update is a change in balance sheet presentation only.

- added (2016-02-18):
[0000858877-16-000090:note_history:27]
In January 2016, the FASB issued an accounting standard update that changes the accounting for equity investments, financial liabilities under the fair value option, and the presentation and disclosure requirements for financial instruments.  The accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2019, and early adoption is permitted. The Company is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.

- removed (2016-02-18):
[0000858877-15-000073:note_history:28]
Recent Accounting Standards or Updates Not Yet Effective  In May 2014, the FASB issued an accounting standard update related to revenue from contracts with customers, which will supersede nearly all current U.S. GAAP guidance on this topic and eliminate industry-specific guidance.  The underlying principle is to recognize revenue when promised goods or services are transferred to customers in an amount that reflects the consideration that is expected to be received for those goods or services.  This accounting standard update, as amended, will be effective for the Company beginning in the first quarter of fiscal 2019.  The new revenue standard may be applied retrospectively to each prior period presented or retrospectively with the cumulative effect recognized as of the date of adoption.  Early adoption is permitted, but no earlier than fiscal 2018.  The Company is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-02-18):
[0000858877-16-000090:note_history:29]
|  | January 23, 2016 |  | July 25, 2015 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 3,006 |  |  | 3.12 | % |  | $ | 3,894 |  |  | 2.48 | % |
| Other short-term debt | 2 |  |  | 2.08 | % |  | 3 |  |  | 2.44 | % |
| Total | $ | 3,008 |  |  |  |  | $ | 3,897 |  |  |  |
  (was, 2015-11-19, similarity 0.9743):
[0000858877-15-000073:note_history:29]
|  | October 24, 2015 |  | July 25, 2015 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 3,025 |  |  | 3.09 | % |  | $ | 3,894 |  |  | 2.48 | % |
| Other short-term debt | 2 |  |  | 2.08 | % |  | 3 |  |  | 2.44 | % |
| Total | $ | 3,027 |  |  |  |  | $ | 3,897 |  |  |  |

- changed (2016-02-18):
[0000858877-16-000090:note_history:30]
In fiscal 2011, the Company established a short-term debt financing program of up to $3.0 billion through the issuance of commercial paper notes. The Company uses the proceeds from the issuance of commercial paper notes for general corporate purposes. The Company had no commercial paper notes outstanding as of each of January 23, 2016 and July 25, 2015.
  (was, 2015-11-19, similarity 0.9467):
[0000858877-15-000073:note_history:30]
In fiscal 2011, the Company established a short-term debt financing program of up to $3.0 billion through the issuance of commercial paper notes.  The Company uses the proceeds from the issuance of commercial paper notes for general corporate purposes.  The Company had no commercial paper notes outstanding as of each of October 24, 2015 and July 25, 2015.

- changed (2016-02-18):
[0000858877-16-000090:note_history:31]
|  |  |  | January 23, 2016 |  | July 25, 2015 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.05% | September 3, 2015 |  | $ | — |  |  | — |  | $ | 850 |  |  | 0.43% |
| Three-month LIBOR plus 0.28% | March 3, 2017 |  | 1,000 |  |  | 0.77% |  | 1,000 |  |  | 0.63% |
| Three-month LIBOR plus 0.31% | June 15, 2018 |  | 900 |  |  | 0.89% |  | 900 |  |  | 0.65% |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | 500 |  |  | 0.97% |  | 500 |  |  | 0.84% |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 5.50% | February 22, 2016 |  | 3,000 |  |  | 3.12% |  | 3,000 |  |  | 3.07% |
| 1.10% | March 3, 2017 |  | 2,400 |  |  | 0.83% |  | 2,400 |  |  | 0.59% |
| 3.15% | March 14, 2017 |  | 750 |  |  | 1.07% |  | 750 |  |  | 0.85% |
| 1.65% | June 15, 2018 |  | 1,600 |  |  | 1.72% |  | 1,600 |  |  | 1.72% |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 4.76% |  | 2,000 |  |  | 4.70% |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 1.04% |  | 1,750 |  |  | 0.80% |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 3.20% |  | 2,500 |  |  | 3.01% |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 2.54% |  | 1,500 |  |  | 2.54% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 1.20% |  | 500 |  |  | 0.96% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 1.45% |  | 500 |  |  | 1.21% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1.32% |  | 1,000 |  |  | 1.08% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 1.61% |  | 500 |  |  | 1.37% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Other long-term debt |  |  | — |  |  |  |  | 1 |  |  | 2.08% |
| Total |  |  | 24,400 |  |  |  |  | 25,251 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (123 | ) |  |  |  | (131 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 320 |  |  |  |  | 231 |  |  |  |
| Total |  |  | $ | 24,597 |  |  |  |  | $ | 25,351 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 3,006 |  |  |  |  | $ | 3,894 |  |  |  |
| Long-term debt |  |  | 21,591 |  |  |  |  | 21,457 |  |  |  |
| Total |  |  | $ | 24,597 |  |  |  |  | $ | 25,351 |  |  |  |
  (was, 2015-11-19, similarity 0.9959):
[0000858877-15-000073:note_history:31]
|  |  |  | October 24, 2015 |  | July 25, 2015 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.05% | September 3, 2015 |  | $ | — |  |  | — |  | $ | 850 |  |  | 0.43% |
| Three-month LIBOR plus 0.28% | March 3, 2017 |  | 1,000 |  |  | 0.68% |  | 1,000 |  |  | 0.63% |
| Three-month LIBOR plus 0.31% | June 15, 2018 |  | 900 |  |  | 0.71% |  | 900 |  |  | 0.65% |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | 500 |  |  | 0.88% |  | 500 |  |  | 0.84% |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 5.50% | February 22, 2016 |  | 3,000 |  |  | 3.09% |  | 3,000 |  |  | 3.07% |
| 1.10% | March 3, 2017 |  | 2,400 |  |  | 0.60% |  | 2,400 |  |  | 0.59% |
| 3.15% | March 14, 2017 |  | 750 |  |  | 0.90% |  | 750 |  |  | 0.85% |
| 1.65% | June 15, 2018 |  | 1,600 |  |  | 1.72% |  | 1,600 |  |  | 1.72% |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 4.70% |  | 2,000 |  |  | 4.70% |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 0.81% |  | 1,750 |  |  | 0.80% |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 3.02% |  | 2,500 |  |  | 3.01% |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 2.54% |  | 1,500 |  |  | 2.54% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 0.97% |  | 500 |  |  | 0.96% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 1.22% |  | 500 |  |  | 1.21% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1.09% |  | 1,000 |  |  | 1.08% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 1.38% |  | 500 |  |  | 1.37% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Other long-term debt |  |  | — |  |  |  |  | 1 |  |  | 2.08% |
| Total |  |  | 24,400 |  |  |  |  | 25,251 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (128 | ) |  |  |  | (131 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 347 |  |  |  |  | 231 |  |  |  |
| Total |  |  | $ | 24,619 |  |  |  |  | $ | 25,351 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 3,025 |  |  |  |  | $ | 3,894 |  |  |  |
| Long-term debt |  |  | 21,594 |  |  |  |  | 21,457 |  |  |  |
| Total |  |  | $ | 24,619 |  |  |  |  | $ | 25,351 |  |  |  |

- changed (2016-02-18):
[0000858877-16-000090:note_history:32]
The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to the Company’s short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of January 23, 2016, the Company was in compliance with all debt covenants.
  (was, 2015-11-19, similarity 0.92):
[0000858877-15-000073:note_history:32]
The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to the Company’s short-term debt financing program, as discussed above under “(a) Short-Term Debt.”  As of October 24, 2015, the Company was in compliance with all debt covenants.

- changed (2016-02-18):
[0000858877-16-000090:note_history:33]
As of January 23, 2016, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):
  (was, 2015-11-19, similarity 0.9556):
[0000858877-15-000073:note_history:33]
As of October 24, 2015, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

- changed (2016-02-18):
[0000858877-16-000090:note_history:34]
| Fiscal Year | Amount |
| 2016 (remaining six months) | $ | 3,000 |  |
| 2017 | 4,150 |  |
| 2018 | 2,500 |  |
| 2019 | 4,250 |  |
| 2020 | 4,000 |  |
| Thereafter | 6,500 |  |
| Total | $ | 24,400 |  |
  (was, 2015-11-19, similarity 0.9836):
[0000858877-15-000073:note_history:34]
| Fiscal Year | Amount |
| 2016 (remaining nine months) | $ | 3,000 |  |
| 2017 | 4,150 |  |
| 2018 | 2,500 |  |
| 2019 | 4,250 |  |
| 2020 | 4,000 |  |
| Thereafter | 6,500 |  |
| Total | $ | 24,400 |  |

- changed (2016-02-18):
[0000858877-16-000090:note_history:35]
The Company may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and/or extend the expiration date of the credit facility up to May 15, 2022.  The Company was in compliance with the required interest coverage ratio and the other covenants, and the Company had not borrowed any funds under the credit facility.
  (was, 2015-11-19, similarity 0.9809):
[0000858877-15-000073:note_history:35]
The Company may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and/or extend the expiration date of the credit facility up to May 15, 2022.  As of October 24, 2015, the Company was in compliance with the required interest coverage ratio and the other covenants, and the Company had not borrowed any funds under the credit facility.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2016-02-18):
[0000858877-16-000090:note_history:36]
| January 23, 2016 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| Fixed income securities: |  |  |  |  |  |  |  |
| U.S. government securities | $ | 28,242 |  |  | $ | 18 |  |  | $ | (16 | ) |  | $ | 28,244 |  |
| U.S. government agency securities | 3,492 |  |  | 3 |  |  | (2 | ) |  | 3,493 |  |
| Non-U.S. government and agency securities | 1,152 |  |  | 1 |  |  | (1 | ) |  | 1,152 |  |
| Corporate debt securities | 18,410 |  |  | 29 |  |  | (158 | ) |  | 18,281 |  |
| U.S. agency mortgage-backed securities | 1,452 |  |  | 9 |  |  | (1 | ) |  | 1,460 |  |
| Total fixed income securities | 52,748 |  |  | 60 |  |  | (178 | ) |  | 52,630 |  |
| Publicly traded equity securities | 1,318 |  |  | 176 |  |  | (63 | ) |  | 1,431 |  |
| Total | $ | 54,066 |  |  | $ | 236 |  |  | $ | (241 | ) |  | $ | 54,061 |  |

- changed (2016-02-18):
[0000858877-16-000090:note_history:37]
|  | Three Months Ended |  | Six Months Ended |
|  | January 23, 2016 |  | January 24, 2015 |  | January 23, 2016 |  | January 24, 2015 |
| Gross realized gains | $ | 16 |  |  | $ | 92 |  |  | $ | 51 |  |  | $ | 113 |  |
| Gross realized losses | (35 | ) |  | (23 | ) |  | (71 | ) |  | (37 | ) |
| Total | $ | (19 | ) |  | $ | 69 |  |  | $ | (20 | ) |  | $ | 76 |  |
  (was, 2015-11-19, similarity 0.6988):
[0000858877-15-000073:note_history:37]
|  | Three Months Ended |
|  | October 24, 2015 |  | October 25, 2014 |
| Gross realized gains | $ | 35 |  |  | $ | 21 |  |
| Gross realized losses | (36 | ) |  | (14 | ) |
| Total | $ | (1 | ) |  | $ | 7 |  |

- added (2016-02-18):
[0000858877-16-000090:note_history:38]
|  | Three Months Ended |  | Six Months Ended |
|  | January 23, 2016 |  | January 24, 2015 |  | January 23, 2016 |  | January 24, 2015 |
| Net gains/(losses) on investments in publicly traded equity securities | $ | 2 |  |  | $ | 60 |  |  | $ | (7 | ) |  | $ | 56 |  |
| Net gains/(losses) on investments in fixed income securities | (21 | ) |  | 9 |  |  | (13 | ) |  | 20 |  |
| Total | $ | (19 | ) |  | $ | 69 |  |  | $ | (20 | ) |  | $ | 76 |  |

- added (2016-02-18):
[0000858877-16-000090:note_history:39]
For the three and six months ended January 23, 2016, the realized net losses related to the Company's available-for-sale investments included impairment charges of $3 million for fixed income securities, due to a decline in the fair value of those securities below their cost basis that were determined to be other than temporary. There were no impairment charges on available-for-sale investments for the corresponding periods in fiscal 2015.

- changed (2016-02-18):
[0000858877-16-000090:note_history:40]
The following tables present the breakdown of the available-for-sale investments with gross unrealized losses and the duration that those losses had been unrealized at January 23, 2016 and July 25, 2015 (in millions):
  (was, 2015-11-19, similarity 0.9662):
[0000858877-15-000073:note_history:40]
The following tables present the breakdown of the available-for-sale investments with gross unrealized losses and the duration that those losses had been unrealized at October 24, 2015 and July 25, 2015 (in millions):

- added (2016-02-18):
[0000858877-16-000090:note_history:41]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| January 23, 2016 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| Fixed income securities: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | $ | 15,432 |  |  | $ | (16 | ) |  | $ | 3 |  |  | $ | — |  |  | $ | 15,435 |  |  | $ | (16 | ) |
| U.S. government agency securities | 1,793 |  |  | (2 | ) |  | — |  |  | — |  |  | 1,793 |  |  | (2 | ) |
| Non-U.S. government and agency securities | 645 |  |  | (1 | ) |  | 17 |  |  | — |  |  | 662 |  |  | (1 | ) |
| Corporate debt securities | 11,565 |  |  | (136 | ) |  | 1,252 |  |  | (22 | ) |  | 12,817 |  |  | (158 | ) |
| U.S. agency mortgage-backed securities | 387 |  |  | (1 | ) |  | — |  |  | — |  |  | 387 |  |  | (1 | ) |
| Total fixed income securities | 29,822 |  |  | (156 | ) |  | 1,272 |  |  | (22 | ) |  | 31,094 |  |  | (178 | ) |
| Publicly traded equity securities | 694 |  |  | (62 | ) |  | 2 |  |  | (1 | ) |  | 696 |  |  | (63 | ) |
| Total | $ | 30,516 |  |  | $ | (218 | ) |  | $ | 1,274 |  |  | $ | (23 | ) |  | $ | 31,790 |  |  | $ | (241 | ) |

- changed (2016-02-18):
[0000858877-16-000090:note_history:42]
As of January 23, 2016, for fixed income securities that were in unrealized loss positions, the Company has determined that (i) it does not have the intent to sell any of these investments and (ii) it is not more likely than not that it will be required to sell any of these investments before recovery of the entire amortized cost basis. In addition, as of January 23, 2016, the Company anticipates that it will recover the entire amortized cost basis of such fixed income securities and has determined that no other-than-temporary impairments associated with credit losses were required to be recognized during the six months ended January 23, 2016.
  (was, 2015-11-19, similarity 0.9385):
[0000858877-15-000073:note_history:42]
As of October 24, 2015, for fixed income securities that were in unrealized loss positions, the Company has determined that (i) it does not have the intent to sell any of these investments and (ii) it is not more likely than not that it will be required to sell any of these investments before recovery of the entire amortized cost basis.  In addition, as of October 24, 2015, the Company anticipates that it will recover the entire amortized cost basis of such fixed income securities and has determined that no other-than-temporary impairments associated with credit losses were required to be recognized during the three months ended October 24, 2015.

- changed (2016-02-18):
[0000858877-16-000090:note_history:43]
The Company has evaluated its publicly traded equity securities as of January 23, 2016 and has determined that there was no indication of other-than-temporary impairments in the respective categories of unrealized losses. This determination was based on several factors, which include the length of time and extent to which fair value has been less than the cost basis, the financial condition and near-term prospects of the issuer, and the Company’s intent and ability to hold the publicly traded equity securities for a period of time sufficient to allow for any anticipated recovery in market value.
  (was, 2015-11-19, similarity 0.9883):
[0000858877-15-000073:note_history:43]
The Company has evaluated its publicly traded equity securities as of October 24, 2015 and has determined that there was no indication of other-than-temporary impairments in the respective categories of unrealized losses.  This determination was based on several factors, which include the length of time and extent to which fair value has been less than the cost basis, the financial condition and near-term prospects of the issuer, and the Company’s intent and ability to hold the publicly traded equity securities for a period of time sufficient to allow for any anticipated recovery in market value.

- changed (2016-02-18):
[0000858877-16-000090:note_history:44]
The following table summarizes the maturities of the Company’s fixed income securities at January 23, 2016 (in millions):
  (was, 2015-11-19, similarity 0.9483):
[0000858877-15-000073:note_history:44]
The following table summarizes the maturities of the Company’s fixed income securities at October 24, 2015 (in millions):

- changed (2016-02-18):
[0000858877-16-000090:note_history:45]
The Company periodically engages in securities lending activities with certain of its available for sale investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. The average daily balance of securities lending for each of the six months ended January 23, 2016 and January 24, 2015 was $0.6 billion. The Company requires collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. The Company engages in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify the Company against collateral losses. The Company did not experience any losses in connection with the secured lending of securities during the periods presented. As of January 23, 2016 and July 25, 2015, the Company had no outstanding securities lending transactions.
  (was, 2015-11-19, similarity 0.9418):
[0000858877-15-000073:note_history:45]
The Company periodically engages in securities lending activities with certain of its available for sale investments.  These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis.  The average daily balance of securities lending for the three months ended October 24, 2015 and October 25, 2014 was $0.5 billion and $1.0 billion, respectively.  The Company requires collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets.  The Company engages in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify the Company against collateral losses.  The Company did not experience any losses in connection with the secured lending of securities during the periods presented.  As of October 24, 2015 and July 25, 2015, the Company had no outstanding securities lending transactions.

- changed (2016-02-18):
[0000858877-16-000090:note_history:46]
The carrying value of the Company’s investments in privately held companies was included in other assets.  For such investments that were accounted for under the equity and cost method as of January 23, 2016 and July 25, 2015, the amounts are summarized in the following table (in millions):
  (was, 2015-11-19, similarity 0.9749):
[0000858877-15-000073:note_history:46]
The carrying value of the Company’s investments in privately held companies was included in other assets.  For such investments that were accounted for under the equity and cost method as of October 24, 2015 and July 25, 2015, the amounts are summarized in the following table (in millions):

- changed (2016-02-18):
[0000858877-16-000090:note_history:47]
|  | January 23, 2016 |  | July 25, 2015 |
| Equity method investments | $ | 605 |  |  | $ | 578 |  |
| Cost method investments | 359 |  |  | 319 |  |
| Total | $ | 964 |  |  | $ | 897 |  |
  (was, 2015-11-19, similarity 0.9615):
[0000858877-15-000073:note_history:47]
|  | October 24, 2015 |  | July 25, 2015 |
| Equity method investments | $ | 619 |  |  | $ | 578 |  |
| Cost method investments | 309 |  |  | 319 |  |
| Total | $ | 928 |  |  | $ | 897 |  |

- changed (2016-02-18):
[0000858877-16-000090:note_history:48]
Variable Interest Entities  In the ordinary course of business, the Company has investments in privately held companies and provides financing to certain customers. These privately held companies and customers may be considered to be variable interest entities. The Company evaluates on an ongoing basis its investments in these privately held companies and its customer financings and has determined that as of January 23, 2016, except as disclosed herein, there were no variable interest entities required to be consolidated in the Company’s Consolidated Financial Statements.
  (was, 2015-11-19, similarity 0.9623):
[0000858877-15-000073:note_history:48]
Variable Interest Entities  In the ordinary course of business, the Company has investments in privately held companies and provides financing to certain customers.  These privately held companies and customers may be considered to be variable interest entities.  The Company evaluates on an ongoing basis its investments in these privately held companies and its customer financings and has determined that as of October 24, 2015 there were no variable interest entities required to be consolidated in the Company’s Consolidated Financial Statements.

- removed (2016-02-18):
[0000858877-15-000073:note_history:49]
| October 24, 2015 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| Fixed income securities: |  |  |  |  |  |  |  |
| U.S. government securities | $ | 27,409 |  |  | $ | 63 |  |  | $ | (1 | ) |  | $ | 27,471 |  |
| U.S. government agency securities | 3,606 |  |  | 11 |  |  | — |  |  | 3,617 |  |
| Non-U.S. government and agency securities | 1,133 |  |  | 3 |  |  | — |  |  | 1,136 |  |
| Corporate debt securities | 18,314 |  |  | 70 |  |  | (78 | ) |  | 18,306 |  |
| U.S. agency mortgage-backed securities | 1,454 |  |  | 15 |  |  | — |  |  | 1,469 |  |
| Total fixed income securities | 51,916 |  |  | 162 |  |  | (79 | ) |  | 51,999 |  |
| Publicly traded equity securities | 1,094 |  |  | 268 |  |  | (12 | ) |  | 1,350 |  |
| Total | $ | 53,010 |  |  | $ | 430 |  |  | $ | (91 | ) |  | $ | 53,349 |  |

- removed (2016-02-18):
[0000858877-15-000073:note_history:50]
|  | Three Months Ended |
|  | October 24, 2015 |  | October 25, 2014 |
| Net losses on investments in publicly traded equity securities | $ | (9 | ) |  | $ | (4 | ) |
| Net gains on investments in fixed income securities | 8 |  |  | 11 |  |
| Total | $ | (1 | ) |  | $ | 7 |  |

- removed (2016-02-18):
[0000858877-15-000073:note_history:51]
There were no impairment charges on available-for-sale investments for the periods presented.

- removed (2016-02-18):
[0000858877-15-000073:note_history:52]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| October 24, 2015 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| Fixed income securities: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | $ | 2,566 |  |  | $ | (1 | ) |  | $ | — |  |  | $ | — |  |  | $ | 2,566 |  |  | $ | (1 | ) |
| U.S. government agency securities | 80 |  |  | — |  |  | — |  |  | — |  |  | 80 |  |  | — |  |
| Non-U.S. government and agency securities | 57 |  |  | — |  |  | 10 |  |  | — |  |  | 67 |  |  | — |  |
| Corporate debt securities | 7,421 |  |  | (66 | ) |  | 1,048 |  |  | (12 | ) |  | 8,469 |  |  | (78 | ) |
| U.S. agency mortgage-backed securities | 77 |  |  | — |  |  | — |  |  | — |  |  | 77 |  |  | — |  |
| Total fixed income securities | 10,201 |  |  | (67 | ) |  | 1,058 |  |  | (12 | ) |  | 11,259 |  |  | (79 | ) |
| Publicly traded equity securities | 103 |  |  | (11 | ) |  | 2 |  |  | (1 | ) |  | 105 |  |  | (12 | ) |
| Total | $ | 10,304 |  |  | $ | (78 | ) |  | $ | 1,060 |  |  | $ | (13 | ) |  | $ | 11,364 |  |  | $ | (91 | ) |


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-02-18):
[0000858877-16-000090:note_history:53]
|  |  |  | January 23, 2016 |  | July 25, 2015 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.05% | September 3, 2015 |  | $ | — |  |  | — |  | $ | 850 |  |  | 0.43% |
| Three-month LIBOR plus 0.28% | March 3, 2017 |  | 1,000 |  |  | 0.77% |  | 1,000 |  |  | 0.63% |
| Three-month LIBOR plus 0.31% | June 15, 2018 |  | 900 |  |  | 0.89% |  | 900 |  |  | 0.65% |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | 500 |  |  | 0.97% |  | 500 |  |  | 0.84% |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 5.50% | February 22, 2016 |  | 3,000 |  |  | 3.12% |  | 3,000 |  |  | 3.07% |
| 1.10% | March 3, 2017 |  | 2,400 |  |  | 0.83% |  | 2,400 |  |  | 0.59% |
| 3.15% | March 14, 2017 |  | 750 |  |  | 1.07% |  | 750 |  |  | 0.85% |
| 1.65% | June 15, 2018 |  | 1,600 |  |  | 1.72% |  | 1,600 |  |  | 1.72% |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 4.76% |  | 2,000 |  |  | 4.70% |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 1.04% |  | 1,750 |  |  | 0.80% |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 3.20% |  | 2,500 |  |  | 3.01% |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 2.54% |  | 1,500 |  |  | 2.54% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 1.20% |  | 500 |  |  | 0.96% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 1.45% |  | 500 |  |  | 1.21% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1.32% |  | 1,000 |  |  | 1.08% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 1.61% |  | 500 |  |  | 1.37% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Other long-term debt |  |  | — |  |  |  |  | 1 |  |  | 2.08% |
| Total |  |  | 24,400 |  |  |  |  | 25,251 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (123 | ) |  |  |  | (131 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 320 |  |  |  |  | 231 |  |  |  |
| Total |  |  | $ | 24,597 |  |  |  |  | $ | 25,351 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 3,006 |  |  |  |  | $ | 3,894 |  |  |  |
| Long-term debt |  |  | 21,591 |  |  |  |  | 21,457 |  |  |  |
| Total |  |  | $ | 24,597 |  |  |  |  | $ | 25,351 |  |  |  |
  (was, 2015-11-19, similarity 0.9959):
[0000858877-15-000073:note_history:53]
|  |  |  | October 24, 2015 |  | July 25, 2015 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.05% | September 3, 2015 |  | $ | — |  |  | — |  | $ | 850 |  |  | 0.43% |
| Three-month LIBOR plus 0.28% | March 3, 2017 |  | 1,000 |  |  | 0.68% |  | 1,000 |  |  | 0.63% |
| Three-month LIBOR plus 0.31% | June 15, 2018 |  | 900 |  |  | 0.71% |  | 900 |  |  | 0.65% |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | 500 |  |  | 0.88% |  | 500 |  |  | 0.84% |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 5.50% | February 22, 2016 |  | 3,000 |  |  | 3.09% |  | 3,000 |  |  | 3.07% |
| 1.10% | March 3, 2017 |  | 2,400 |  |  | 0.60% |  | 2,400 |  |  | 0.59% |
| 3.15% | March 14, 2017 |  | 750 |  |  | 0.90% |  | 750 |  |  | 0.85% |
| 1.65% | June 15, 2018 |  | 1,600 |  |  | 1.72% |  | 1,600 |  |  | 1.72% |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 4.70% |  | 2,000 |  |  | 4.70% |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 0.81% |  | 1,750 |  |  | 0.80% |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 3.02% |  | 2,500 |  |  | 3.01% |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 2.54% |  | 1,500 |  |  | 2.54% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 0.97% |  | 500 |  |  | 0.96% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 1.22% |  | 500 |  |  | 1.21% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1.09% |  | 1,000 |  |  | 1.08% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 1.38% |  | 500 |  |  | 1.37% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Other long-term debt |  |  | — |  |  |  |  | 1 |  |  | 2.08% |
| Total |  |  | 24,400 |  |  |  |  | 25,251 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (128 | ) |  |  |  | (131 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 347 |  |  |  |  | 231 |  |  |  |
| Total |  |  | $ | 24,619 |  |  |  |  | $ | 25,351 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 3,025 |  |  |  |  | $ | 3,894 |  |  |  |
| Long-term debt |  |  | 21,594 |  |  |  |  | 21,457 |  |  |  |
| Total |  |  | $ | 24,619 |  |  |  |  | $ | 25,351 |  |  |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-02-18):
[0000858877-16-000090:note_history:54]
As of January 23, 2016, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):
  (was, 2015-11-19, similarity 0.9556):
[0000858877-15-000073:note_history:54]
As of October 24, 2015, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

- changed (2016-02-18):
[0000858877-16-000090:note_history:55]
| Fiscal Year | Amount |
| 2016 (remaining six months) | $ | 3,000 |  |
| 2017 | 4,150 |  |
| 2018 | 2,500 |  |
| 2019 | 4,250 |  |
| 2020 | 4,000 |  |
| Thereafter | 6,500 |  |
| Total | $ | 24,400 |  |
  (was, 2015-11-19, similarity 0.9836):
[0000858877-15-000073:note_history:55]
| Fiscal Year | Amount |
| 2016 (remaining nine months) | $ | 3,000 |  |
| 2017 | 4,150 |  |
| 2018 | 2,500 |  |
| 2019 | 4,250 |  |
| 2020 | 4,000 |  |
| Thereafter | 6,500 |  |
| Total | $ | 24,400 |  |


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2016-02-18):
[0000858877-16-000090:note_history:56]
|  | January 23, 2016 |  | July 25, 2015 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 3,006 |  |  | 3.12 | % |  | $ | 3,894 |  |  | 2.48 | % |
| Other short-term debt | 2 |  |  | 2.08 | % |  | 3 |  |  | 2.44 | % |
| Total | $ | 3,008 |  |  |  |  | $ | 3,897 |  |  |  |
  (was, 2015-11-19, similarity 0.9743):
[0000858877-15-000073:note_history:56]
|  | October 24, 2015 |  | July 25, 2015 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 3,025 |  |  | 3.09 | % |  | $ | 3,894 |  |  | 2.48 | % |
| Other short-term debt | 2 |  |  | 2.08 | % |  | 3 |  |  | 2.44 | % |
| Total | $ | 3,027 |  |  |  |  | $ | 3,897 |  |  |  |
