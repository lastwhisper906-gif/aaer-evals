# CSCO notes — 0000858877-16-000090


## csco:CompensationexpensesrelatedtobusinesscombinationsTableTextBlock

[0000858877-16-000090:notes:1]
[same as prior period, unchanged from 0000858877-15-000073:notes:1]

[0000858877-16-000090:notes:2]
|  | Three Months Ended |  | Six Months Ended |
|  | January 23, 2016 |  | January 24, 2015 |  | January 23, 2016 |  | January 24, 2015 |
| Compensation expense related to acquisitions | $ | 71 |  |  | $ | 94 |  |  | $ | 144 |  |  | $ | 192 |  |


## csco:DescriptionOfNewAccountingPronouncementsNotYetAdoptedPolicyTextBlock

[0000858877-16-000090:notes:3]
Recent Accounting Standards or Updates Not Yet Effective  In May 2014, the Financial Accounting Standards Board (FASB) issued an accounting standard update related to revenue from contracts with customers, which will supersede nearly all current U.S. GAAP guidance on this topic and eliminate industry-specific guidance. The underlying principle is to recognize revenue when promised goods or services are transferred to customers in an amount that reflects the consideration that is expected to be received for those goods or services. This accounting standard update, as amended, will be effective for the Company beginning in the first quarter of fiscal 2019. The new revenue standard may be applied retrospectively to each prior period presented or retrospectively with the cumulative effect recognized as of the date of adoption. Early adoption is permitted, but no earlier than fiscal 2018. The Company is currently evaluating the timing of its adoption and impact of this accounting standard update on its Consolidated Financial Statements.

[0000858877-16-000090:notes:4]
In February 2015, the FASB issued an accounting standard update that changes the analysis that a reporting entity must perform to determine whether it should consolidate certain types of legal entities. The accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2017, and early adoption is permitted. The Company is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.

[0000858877-16-000090:notes:5]
In November 2015, the FASB issued an accounting standard update that requires that all deferred tax assets and liabilities, along with any related valuation allowance, be classified as noncurrent on the balance sheet. The accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2018, and early adoption is permitted. The accounting standard update is a change in balance sheet presentation only.

[0000858877-16-000090:notes:6]
In January 2016, the FASB issued an accounting standard update that changes the accounting for equity investments, financial liabilities under the fair value option, and the presentation and disclosure requirements for financial instruments.  The accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2019, and early adoption is permitted. The Company is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.


## csco:EntityWideDisclosureOnGeographicAreasLongLivedAssetsTableTextBlock

[0000858877-16-000090:notes:7]
[same as prior period, unchanged from 0000858877-15-000073:notes:5]

[0000858877-16-000090:notes:8]
|  | January 23, 2016 |  | July 25, 2015 |
| Property and equipment, net: |  |  |  |
| United States | $ | 2,779 |  |  | $ | 2,733 |  |
| International | 607 |  |  | 599 |  |
| Total | $ | 3,386 |  |  | $ | 3,332 |  |


## csco:IncometaxprovisionTableTextBlock

[0000858877-16-000090:notes:9]
[same as prior period, unchanged from 0000858877-15-000073:notes:7]

[0000858877-16-000090:notes:10]
|  | Three Months Ended |  | Six Months Ended |
|  | January 23, 2016 |  | January 24, 2015 |  | January 23, 2016 |  | January 24, 2015 |
| Income before provision for income taxes | $ | 3,306 |  |  | $ | 2,873 |  |  | $ | 6,443 |  |  | $ | 5,233 |  |
| Provision for income taxes | $ | 159 |  |  | $ | 476 |  |  | $ | 866 |  |  | $ | 1,008 |  |
| Effective tax rate | 4.8 | % |  | 16.6 | % |  | 13.4 | % |  | 19.3 | % |


## csco:NetSalesForGroupsOfSimilarProductsAndServicesTableTextBlock

[0000858877-16-000090:notes:11]
[same as prior period, unchanged from 0000858877-15-000073:notes:9]

[0000858877-16-000090:notes:12]
|  | Three Months Ended |  | Six Months Ended |
|  | January 23, 2016 |  | January 24, 2015 |  | January 23, 2016 |  | January 24, 2015 |
| Revenue: |  |  |  |  |  |  |  |
| Switching | $ | 3,483 |  |  | $ | 3,615 |  |  | $ | 7,505 |  |  | $ | 7,461 |  |
| NGN Routing | 1,845 |  |  | 1,764 |  |  | 3,638 |  |  | 3,713 |  |
| Collaboration | 1,019 |  |  | 991 |  |  | 2,134 |  |  | 1,941 |  |
| Data Center | 822 |  |  | 846 |  |  | 1,681 |  |  | 1,538 |  |
| Service Provider Video (1) | 662 |  |  | 776 |  |  | 1,512 |  |  | 1,647 |  |
| Wireless | 613 |  |  | 611 |  |  | 1,258 |  |  | 1,216 |  |
| Security | 462 |  |  | 416 |  |  | 947 |  |  | 871 |  |
| Other | 77 |  |  | 59 |  |  | 152 |  |  | 126 |  |
| Product | 8,983 |  |  | 9,078 |  |  | 18,827 |  |  | 18,513 |  |
| Service | 2,944 |  |  | 2,858 |  |  | 5,782 |  |  | 5,668 |  |
| Total | $ | 11,927 |  |  | $ | 11,936 |  |  | $ | 24,609 |  |  | $ | 24,181 |  |


## csco:ScheduleOfCommonStockRepurchasedTextBlock

[0000858877-16-000090:notes:13]
[same as prior period, unchanged from 0000858877-15-000073:notes:11]

[0000858877-16-000090:notes:14]
|  | SharesRepurchased |  | Weighted-Average Priceper Share |  | AmountRepurchased |
| Cumulative balance at July 25, 2015 | 4,443 |  |  | $ | 20.86 |  |  | $ | 92,679 |  |
| Repurchase of common stock under the stock repurchase program (1) | 93 |  |  | 26.46 |  |  | 2,469 |  |
| Cumulative balance at January 23, 2016 | 4,536 |  |  | $ | 20.97 |  |  | $ | 95,148 |  |

[0000858877-16-000090:notes:15]
(1) Includes stock repurchases of $161 million, which were pending settlement as of January 23, 2016. There were $36 million of stock repurchases that were pending settlement as of July 25, 2015.


## csco:ScheduleOfDerivativeFairValueHedgeInstrumentsGainLossInStatementOfFinancialPerformanceTableTextBlock

[0000858877-16-000090:notes:16]
[same as prior period, unchanged from 0000858877-15-000073:notes:14]

[0000858877-16-000090:notes:17]
|  |  |  |  | GAINS (LOSSES) ONDERIVATIVEINSTRUMENTS FOR THETHREE MONTHS ENDED |  | GAINS (LOSSES)RELATED TO HEDGEDITEMS FOR THE THREE MONTHS ENDED |
| Derivatives Designated as Fair Value Hedging Instruments |  | Line Item in Statements of Operations |  | January 23, 2016 |  | January 24, 2015 |  | January 23, 2016 |  | January 24, 2015 |
| Equity derivatives |  | Other income (loss), net |  | $ | — |  |  | $ | (18 | ) |  | $ | — |  |  | $ | 18 |  |
| Interest rate derivatives |  | Interest expense |  | (16 | ) |  | 61 |  |  | 18 |  |  | (61 | ) |
| Total |  |  |  | $ | (16 | ) |  | $ | 43 |  |  | $ | 18 |  |  | $ | (43 | ) |

[0000858877-16-000090:notes:18]
|  |  |  |  | GAINS (LOSSES) ONDERIVATIVEINSTRUMENTS FOR THESIX MONTHS ENDED |  | GAINS (LOSSES)RELATED TO HEDGEDITEMS FOR THE SIX MONTHS ENDED |
| Derivatives Designated as Fair Value Hedging Instruments |  | Line Item in Statements of Operations |  | January 23, 2016 |  | January 24, 2015 |  | January 23, 2016 |  | January 24, 2015 |
| Equity derivatives |  | Other income (loss), net |  | $ | — |  |  | $ | (12 | ) |  | $ | — |  |  | $ | 12 |  |
| Interest rate derivatives |  | Interest expense |  | 111 |  |  | 131 |  |  | (107 | ) |  | (134 | ) |
| Total |  |  |  | $ | 111 |  |  | $ | 119 |  |  | $ | (107 | ) |  | $ | (122 | ) |


## csco:ScheduleOfFiniteLivedIntangibleAssetsAmortizationExpenseTableTextBlock

[0000858877-16-000090:notes:19]
[same as prior period, unchanged from 0000858877-15-000073:notes:16]

[0000858877-16-000090:notes:20]
|  | Three Months Ended |  | Six Months Ended |
|  | January 23, 2016 |  | January 24, 2015 |  | January 23, 2016 |  | January 24, 2015 |
| Amortization of purchased intangible assets: |  |  |  |  |  |  |  |
| Cost of sales | $ | 139 |  |  | $ | 242 |  |  | $ | 285 |  |  | $ | 431 |  |
| Operating expenses | 71 |  |  | 72 |  |  | 140 |  |  | 143 |  |
| Total | $ | 210 |  |  | $ | 314 |  |  | $ | 425 |  |  | $ | 574 |  |


## csco:ScheduleOfIntangibleAssetsAcquiredAsPartOfBusinessCombinationTextBlock

[0000858877-16-000090:notes:21]
[same as prior period, unchanged from 0000858877-15-000073:notes:18]

[0000858877-16-000090:notes:22]
The following table presents details of the Company’s intangible assets acquired through acquisitions completed during the six months ended January 23, 2016 (in millions, except years):

[0000858877-16-000090:notes:23]
|  | FINITE LIVES |  | INDEFINITELIVES |  | TOTAL |
|  | TECHNOLOGY |  | CUSTOMERRELATIONSHIPS |  | OTHER |  | IPR&D |  |
|  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Amount |  | Amount |
| MaintenanceNet | 5.0 |  | $ | 50 |  |  | 5.0 |  | $ | 2 |  |  | 2.0 |  | $ | 2 |  |  | $ | 11 |  |  | $ | 65 |  |
| OpenDNS | 5.0 |  | 43 |  |  | 7.0 |  | 15 |  |  | 1.0 |  | 2 |  |  | 1 |  |  | 61 |  |
| Lancope | 5.0 |  | 79 |  |  | 6.0 |  | 29 |  |  | 3.0 |  | 3 |  |  | 10 |  |  | 121 |  |
| Others (four in total) | 4.2 |  | 56 |  |  | 6.3 |  | 6 |  |  | 0.0 |  | — |  |  | — |  |  | 62 |  |
| Total |  |  | $ | 228 |  |  |  |  | $ | 52 |  |  |  |  | $ | 7 |  |  | $ | 22 |  |  | $ | 309 |  |


## csco:ScheduleOfIntangibleAssetsByMajorClassTextBlock

[0000858877-16-000090:notes:24]
[same as prior period, unchanged from 0000858877-15-000073:notes:21]

[0000858877-16-000090:notes:25]
| January 23, 2016 |  | Gross |  | Accumulated Amortization |  | Net |
| Purchased intangible assets with finite lives: |  |  |  |  |  |  |
| Technology |  | $ | 2,842 |  |  | $ | (1,232 | ) |  | $ | 1,610 |  |
| Customer relationships |  | 1,740 |  |  | (1,093 | ) |  | 647 |  |
| Other |  | 61 |  |  | (31 | ) |  | 30 |  |
| Total purchased intangible assets with finite lives |  | 4,643 |  |  | (2,356 | ) |  | 2,287 |  |
| In-process research and development, with indefinite lives |  | 35 |  |  | — |  |  | 35 |  |
| Total |  | $ | 4,678 |  |  | $ | (2,356 | ) |  | $ | 2,322 |  |

[0000858877-16-000090:notes:26]
[same as prior period, unchanged from 0000858877-15-000073:notes:23]


## csco:SegmentReportingProductAndServicesNetSalesTextBlock

[0000858877-16-000090:notes:27]
[same as prior period, unchanged from 0000858877-15-000073:notes:24]

[0000858877-16-000090:notes:28]
[same as prior period, unchanged from 0000858877-15-000073:notes:25]

[0000858877-16-000090:notes:29]
The Company conducts business globally and is primarily managed on a geographic basis consisting of three segments: the Americas, EMEA, and APJC. The Company’s management makes financial decisions and allocates resources based on the information it receives from its internal management system. Sales are attributed to a segment based on the ordering location of the customer. The Company does not allocate research and development, sales and marketing, or general and administrative expenses to its segments in this internal management system because management does not include the information in its measurement of the performance of the operating segments. In addition, the Company does not allocate amortization and impairment of acquisition-related intangible assets, share-based compensation expense, significant litigation and other contingencies, impacts to cost of sales from purchase accounting adjustments to inventory, charges related to asset impairments and restructurings, and certain other charges to the gross margin for each segment because management does not include this information in its measurement of the performance of the operating segments.

[0000858877-16-000090:notes:30]
Summarized financial information by segment for the three and six months ended January 23, 2016 and January 24, 2015, based on the Company’s internal management system and as utilized by the Company’s Chief Operating Decision Maker ("CODM"), is as follows (in millions):

[0000858877-16-000090:notes:31]
|  | Three Months Ended |  | Six Months Ended |
|  | January 23, 2016 |  | January 24, 2015 |  | January 23, 2016 |  | January 24, 2015 |
| Revenue: |  |  |  |  |  |  |  |
| Americas | $ | 6,912 |  |  | $ | 7,101 |  |  | $ | 14,711 |  |  | $ | 14,602 |  |
| EMEA | 3,088 |  |  | 3,091 |  |  | 6,175 |  |  | 6,093 |  |
| APJC | 1,927 |  |  | 1,744 |  |  | 3,723 |  |  | 3,486 |  |
| Total | $ | 11,927 |  |  | $ | 11,936 |  |  | $ | 24,609 |  |  | $ | 24,181 |  |
| Gross margin: |  |  |  |  |  |  |  |
| Americas | $ | 4,412 |  |  | $ | 4,406 |  |  | $ | 9,362 |  |  | $ | 9,216 |  |
| EMEA | 2,005 |  |  | 1,910 |  |  | 3,987 |  |  | 3,825 |  |
| APJC | 1,189 |  |  | 1,052 |  |  | 2,267 |  |  | 2,077 |  |
| Segment total | 7,606 |  |  | 7,368 |  |  | 15,616 |  |  | 15,118 |  |
| Unallocated corporate items | (174 | ) |  | (278 | ) |  | (352 | ) |  | (695 | ) |
| Total | $ | 7,432 |  |  | $ | 7,090 |  |  | $ | 15,264 |  |  | $ | 14,423 |  |

[0000858877-16-000090:notes:32]
Revenue in the United States was $6.1 billion and $6.0 billion for the three months ended January 23, 2016 and January 24, 2015, respectively, and was $13.0 billion and $12.6 billion for the six months ended January 23, 2016 and January 24, 2015, respectively.

[0000858877-16-000090:notes:33]
[same as prior period, unchanged from 0000858877-15-000073:notes:30]

[0000858877-16-000090:notes:34]
The Company designs and sells broad lines of products, provides services and delivers integrated solutions to develop and connect networks around the world, building the Internet. The Company groups its products and technologies into the following categories: Switching, NGN Routing, Collaboration, Data Center, Service Provider Video, Wireless, Security, and Other Products. These products, primarily integrated by Cisco IOS Software, link geographically dispersed local-area networks (LANs), metropolitan-area networks (MANs), and wide-area networks (WANs).

[0000858877-16-000090:notes:35]
(1) Includes SP Video CPE Business revenue of $93 million (one month of operations) and $361 million for the second quarter of fiscal 2016 and 2015, respectively and $504 million and $840 million for the first six months of fiscal 2016 and 2015, respectively.

[0000858877-16-000090:notes:36]
[same as prior period, unchanged from 0000858877-15-000073:notes:32]

[0000858877-16-000090:notes:37]
[same as prior period, unchanged from 0000858877-15-000073:notes:33]

[0000858877-16-000090:notes:38]
The majority of the Company’s assets, excluding cash and cash equivalents and investments, were attributable to its U.S. operations as of each of January 23, 2016 and July 25, 2015.  The Company’s total cash and cash equivalents and investments held by various foreign subsidiaries were $56.5 billion and $53.4 billion as of January 23, 2016 and July 25, 2015, respectively, and the remaining $3.9 billion and $7.0 billion at the respective period ends were available in the United States.


## csco:StockRepurchasesSinceInceptionOfProgramTableTextBlock

[0000858877-16-000090:notes:39]
[same as prior period, unchanged from 0000858877-15-000073:notes:35]

[0000858877-16-000090:notes:40]
|  | Shares ofCommonStock |  | Common Stockand AdditionalPaid-In Capital |  | RetainedEarnings |  | Total CiscoShareholders’Equity |
| Repurchases of common stock under the repurchase program | 4,536 |  |  | $ | 23,416 |  |  | $ | 71,732 |  |  | $ | 95,148 |  |


## us-gaap:AllowanceForCreditLossesOnFinancingReceivablesTableTextBlock

[0000858877-16-000090:notes:41]
[same as prior period, unchanged from 0000858877-15-000073:notes:37]

[0000858877-16-000090:notes:42]
|  | CREDIT LOSS ALLOWANCES |
| Three months ended January 23, 2016 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts and Other |  | Total |
| Allowance for credit loss as of October 24, 2015 | $ | 255 |  |  | $ | 90 |  |  | $ | 33 |  |  | $ | 378 |  |
| Provisions | (4 | ) |  | (10 | ) |  | 5 |  |  | (9 | ) |
| Recoveries (write-offs), net | — |  |  | — |  |  | (1 | ) |  | (1 | ) |
| Foreign exchange and other | (3 | ) |  | — |  |  | — |  |  | (3 | ) |
| Allowance for credit loss as of January 23, 2016 | $ | 248 |  |  | $ | 80 |  |  | $ | 37 |  |  | $ | 365 |  |

[0000858877-16-000090:notes:43]
|  | CREDIT LOSS ALLOWANCES |
| Six months ended January 23, 2016 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts and Other |  | Total |
| Allowance for credit loss as of July 25, 2015 | $ | 259 |  |  | $ | 87 |  |  | $ | 36 |  |  | $ | 382 |  |
| Provisions | (4 | ) |  | (6 | ) |  | 5 |  |  | (5 | ) |
| Recoveries (write-offs), net | (4 | ) |  | — |  |  | (4 | ) |  | (8 | ) |
| Foreign exchange and other | (3 | ) |  | (1 | ) |  | — |  |  | (4 | ) |
| Allowance for credit loss as of January 23, 2016 | $ | 248 |  |  | $ | 80 |  |  | $ | 37 |  |  | $ | 365 |  |

[0000858877-16-000090:notes:44]
|  | CREDIT LOSS ALLOWANCES |
| Three months ended January 24, 2015 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts and Other |  | Total |
| Allowance for credit loss as of October 25, 2014 | $ | 248 |  |  | $ | 84 |  |  | $ | 36 |  |  | $ | 368 |  |
| Provisions | 7 |  |  | 3 |  |  | 4 |  |  | 14 |  |
| Recoveries (write-offs), net | (1 | ) |  | — |  |  | — |  |  | (1 | ) |
| Foreign exchange and other | (4 | ) |  | (2 | ) |  | — |  |  | (6 | ) |
| Allowance for credit loss as of January 24, 2015 | $ | 250 |  |  | $ | 85 |  |  | $ | 40 |  |  | $ | 375 |  |

[0000858877-16-000090:notes:45]
|  | CREDIT LOSS ALLOWANCES |
| Six months ended January 24, 2015 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts and Other |  | Total |
| Allowance for credit loss as of July 26, 2014 | $ | 233 |  |  | $ | 98 |  |  | $ | 18 |  |  | $ | 349 |  |
| Provisions | 29 |  |  | (10 | ) |  | 23 |  |  | 42 |  |
| Recoveries (write-offs), net | (5 | ) |  | 1 |  |  | — |  |  | (4 | ) |
| Foreign exchange and other | (7 | ) |  | (4 | ) |  | (1 | ) |  | (12 | ) |
| Allowance for credit loss as of January 24, 2015 | $ | 250 |  |  | $ | 85 |  |  | $ | 40 |  |  | $ | 375 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000858877-16-000090:notes:46]
[same as prior period, unchanged from 0000858877-15-000073:notes:41]

[0000858877-16-000090:notes:47]
The Company completed seven acquisitions during the six months ended January 23, 2016. A summary of the allocation of the total purchase consideration is presented as follows (in millions):

[0000858877-16-000090:notes:48]
|  | Purchase Consideration |  | Net Liabilities Assumed |  | Purchased Intangible Assets |  | Goodwill |
| MaintenanceNet | $ | 105 |  |  | $ | (21 | ) |  | $ | 65 |  |  | $ | 61 |  |
| OpenDNS | 545 |  |  | (9 | ) |  | 61 |  |  | 493 |  |
| Lancope | 410 |  |  | (34 | ) |  | 121 |  |  | 323 |  |
| Others (four in total) | 108 |  |  | (17 | ) |  | 62 |  |  | 63 |  |
| Total | $ | 1,168 |  |  | $ | (81 | ) |  | $ | 309 |  |  | $ | 940 |  |

[0000858877-16-000090:notes:49]
On August 6, 2015, the Company completed its acquisition of privately held MaintenanceNet, Inc. ("MaintenanceNet"), a provider  of a cloud-based software platform that uses data analytics and automation to manage renewals of recurring customer contracts.  This acquisition is a component of the Company's strategy for its Services organization to simplify and digitize its business processes.

[0000858877-16-000090:notes:50]
On August 26, 2015, the Company completed its acquisition of privately held OpenDNS, Inc. ("OpenDNS"), a provider of advanced threat protection for endpoint devices. With the OpenDNS acquisition, the Company aims to strengthen its security offerings by adding broad visibility and threat intelligence delivered through a software-as-a-service platform. Revenue from the OpenDNS acquisition has been included in the Company's Security product category.

[0000858877-16-000090:notes:51]
On December 21, 2015, the Company completed its acquisition of privately held Lancope, Inc. ("Lancope"), a provider of network behavior analytics, threat visibility and security intelligence. With the Lancope acquisition, the Company aims to advance its "security everywhere" strategy with an additional capability of network behavior analytics that extend protection further into the network.  Revenue from the Lancope acquisition has been included in the Company's Security product category.

[0000858877-16-000090:notes:52]
The total purchase consideration related to the Company’s acquisitions completed during the six months ended January 23, 2016 consisted of cash consideration and the assumption of vested share-based awards. The total cash and cash equivalents acquired from these business combinations was approximately $10 million. Total transaction costs related to the Company’s acquisition activities were $14 million and $5 million for the six months ended January 23, 2016 and January 24, 2015, respectively. These transaction costs were expensed as incurred in general and administrative expenses ("G&A") in the Consolidated Statements of Operations.

[0000858877-16-000090:notes:53]
The Company’s purchase price allocation for acquisitions completed during recent periods is preliminary and subject to revision as additional information about fair value of assets and liabilities becomes available. Additional information that existed as of the acquisition date but at that time was unknown to the Company may become known to the Company during the remainder of the measurement period, a period not to exceed 12 months from the acquisition date. Adjustments in the purchase price allocation may require a recasting of the amounts allocated to goodwill retroactive to the period in which the acquisition occurred.

[0000858877-16-000090:notes:54]
The goodwill generated from the Company’s acquisitions completed during the six months ended January 23, 2016 is primarily related to expected synergies. The goodwill is generally not deductible for income tax purposes.

[0000858877-16-000090:notes:55]
The Consolidated Financial Statements include the operating results of each acquisition from the date of acquisition. Pro forma results of operations for the acquisitions completed during the six months ended January 23, 2016 have not been presented because the effects of the acquisitions, individually and in the aggregate, were not material to the Company’s financial results.

[0000858877-16-000090:notes:56]
Acquisition of Acano  On January 29, 2016, the Company completed its acquisition of privately held Acano Limited ("Acano"), a collaboration infrastructure and conferencing software provider. Under the terms of the agreement, the Company paid approximately $550 million in cash and share-based awards assumed to acquire Acano. With the Acano acquisition, the Company aims to enhance its collaboration strategy to deliver video across both cloud and hybrid environments. Revenue from the Acano acquisition will be included in the Company's Collaboration product category. The Company expects that most of the purchase price will be allocated to goodwill and purchased intangible assets.

[0000858877-16-000090:notes:57]
Pending Acquisition of Jasper  On February 3, 2016, the Company announced its intent to acquire privately held Jasper Technologies, Inc. ("Jasper"), a provider of a cloud-based Internet of Things (IoT) software-as-a-service platform to help enterprises and service providers launch, manage and monetize IoT services on a global scale. Under the terms of the agreement, the Company will pay approximately $1.4 billion in cash and share-based awards assumed to acquire Jasper. With the Jasper acquisition, the Company aims to offer a complete IoT solution that is interoperable across devices and works with IoT service providers, application developers and an ecosystem of partners.

[0000858877-16-000090:notes:58]
Divestiture of SP Video CPE Business  On November 20, 2015, the Company completed the sale of the assets comprising the customer premises equipment portion of its Service Provider Video connected devices business ("SP Video CPE Business") to Technicolor SA. As a result of the transaction, the Company received aggregate consideration of $542 million consisting of $372 million in cash and $170 million in Technicolor stock (as of the divestiture date) and the transaction resulted in a gain of $286 million, net of certain transaction costs incurred in prior periods.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000858877-16-000090:notes:59]
| 12. | Commitments and Contingencies |

[0000858877-16-000090:notes:60]
| (a) | Operating Leases |

[0000858877-16-000090:notes:61]
The Company leases office space in many U.S. locations. Outside the United States, larger leased sites include sites in Belgium, Canada, China, France, Germany, India, Israel, Japan, Poland and the United Kingdom. The Company also leases equipment and vehicles. Future minimum lease payments under all noncancelable operating leases with an initial term in excess of one year as of January 23, 2016 are as follows (in millions):

[0000858877-16-000090:notes:62]
| Fiscal Year | Amount |
| 2016 (remaining six months) | $ | 184 |  |
| 2017 | 268 |  |
| 2018 | 204 |  |
| 2019 | 117 |  |
| 2020 | 96 |  |
| Thereafter | 222 |  |
| Total | $ | 1,091 |  |

[0000858877-16-000090:notes:63]
| (b) | Purchase Commitments with Contract Manufacturers and Suppliers |

[0000858877-16-000090:notes:64]
The Company purchases components from a variety of suppliers and uses several contract manufacturers to provide manufacturing services for its products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, the Company enters into agreements with contract manufacturers and suppliers that either allow them to procure inventory based upon criteria as defined by the Company or establish the parameters defining the Company’s requirements.  A significant portion of the Company’s reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. In certain instances, these agreements allow the Company the option to cancel, reschedule, and adjust the Company’s requirements based on its business needs prior to firm orders being placed.  As of January 23, 2016 and July 25, 2015, the Company had total purchase commitments for inventory of $3,435 million and $4,078 million, respectively.

[0000858877-16-000090:notes:65]
The Company records a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of its future demand forecasts consistent with the valuation of the Company’s excess and obsolete inventory. As of January 23, 2016 and July 25, 2015, the liability for these purchase commitments was $180 million and $156 million, respectively, and was included in other current liabilities.

[0000858877-16-000090:notes:66]
| (c) | Other Commitments |

[0000858877-16-000090:notes:67]
In connection with the Company’s acquisitions, the Company has agreed to pay certain additional amounts contingent upon the achievement of certain agreed-upon technology, development, product, or other milestones or upon the continued employment with the Company of certain employees of the acquired entities.

[0000858877-16-000090:notes:68]
As of January 23, 2016, the Company estimated that future cash compensation expense of up to $230 million may be required to be recognized pursuant to the applicable business combination agreements, which included the remaining potential compensation expense related to Insieme Networks, Inc. ("Insieme"), as more fully discussed immediately below.

[0000858877-16-000090:notes:69]
Insieme Networks, Inc.    In the third quarter of fiscal 2012, the Company made an investment in Insieme, an early stage company focused on research and development in the data center market. As set forth in the agreement between the Company and Insieme, this investment included $100 million of funding and a license to certain of the Company’s technology. Immediately prior to the call option exercise and acquisition described below, the Company owned approximately 83% of Insieme as a result of these investments and consolidated the results of Insieme in its Consolidated Financial Statements. In connection with this investment, the Company and Insieme entered into a put/call option agreement that provided the Company with the right to purchase the remaining interests in Insieme.  In addition, the noncontrolling interest holders could require the Company to purchase their shares upon the occurrence of certain events.

[0000858877-16-000090:notes:70]
During the first quarter of fiscal 2014, the Company exercised its call option and entered into an agreement to purchase the remaining interests in Insieme. The acquisition closed in the second quarter of fiscal 2014, at which time the former noncontrolling interest holders became eligible to receive up to two milestone payments, which will be determined using agreed-upon formulas based primarily on revenue for certain of Insieme’s products. The Company recorded compensation expense of $50 million and $51 million during the three months ended January 23, 2016 and January 24, 2015, respectively, and $101 million and $104 million during the six months ended January 23, 2016 and January 24, 2015, respectively, related to the fair value of the vested portion of amounts that were earned or are expected to be earned by the former noncontrolling interest holders. Continued vesting and changes to the fair value of the amounts probable of being earned will result in adjustments to the recorded compensation expense in future periods.  Based on the terms of the agreement, the Company has determined that the maximum amount that could be recorded as compensation expense by the Company is approximately $839 million (which includes the $724 million that has been expensed to date), net of forfeitures.

[0000858877-16-000090:notes:71]
The former noncontrolling interest holders earned the maximum amount related to the first milestone payment and were paid   approximately $354 million for a portion of this amount during the six months ended January 23, 2016. The balance of the first milestone payment is expected to be paid primarily through the end of fiscal 2016. The second milestone payment, to the extent earned, is expected to be paid primarily during the first half of fiscal 2017.

[0000858877-16-000090:notes:72]
The Company also has certain funding commitments, primarily related to its investments in privately held companies and venture funds, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $188 million and $205 million as of January 23, 2016 and July 25, 2015, respectively.

[0000858877-16-000090:notes:73]
| (d) | Product Warranties |

[0000858877-16-000090:notes:74]
The following table summarizes the activity related to the product warranty liability (in millions):

[0000858877-16-000090:notes:75]
|  | Six Months Ended |
|  | January 23, 2016 |  | January 24, 2015 |
| Balance at beginning of period | $ | 449 |  |  | $ | 446 |  |
| Provision for warranties issued | 322 |  |  | 355 |  |
| Payments | (340 | ) |  | (327 | ) |
| Acquisition/divestitures | (28 | ) |  | — |  |
| Balance at end of period | $ | 403 |  |  | $ | 474 |  |

[0000858877-16-000090:notes:76]
The Company accrues for warranty costs as part of its cost of sales based on associated material product costs, labor costs for technical support staff, and associated overhead. The Company’s products are generally covered by a warranty for periods ranging from 90 days to five years, and for some products the Company provides a limited lifetime warranty.

[0000858877-16-000090:notes:77]
| (e) | Financing and Other Guarantees |

[0000858877-16-000090:notes:78]
In the ordinary course of business, the Company provides financing guarantees for various third-party financing arrangements extended to channel partners and end-user customers. Payments under these financing guarantee arrangements were not material for the periods presented.

[0000858877-16-000090:notes:79]
Channel Partner Financing Guarantees   The Company facilitates arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, generally with payment terms ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, the Company guarantees a portion of these arrangements. The volume of channel partner financing was $6.5 billion and $6.2 billion for the three months ended January 23, 2016 and January 24, 2015, respectively and was $13.4 billion and $12.5 billion for the six months ended January 23, 2016 and January 24, 2015, respectively. The balance of the channel partner financing subject to guarantees was $1.2 billion as of each of January 23, 2016 and July 25, 2015, respectively.

[0000858877-16-000090:notes:80]
End-User Financing Guarantees   The Company also provides financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. The volume of financing provided by third parties for leases and loans as to which the Company had provided guarantees was $16 million and $39 million for the three months ended January 23, 2016 and January 24, 2015, respectively, and was $39 million and $65 million for the six months ended January 23, 2016 and January 24, 2015, respectively.

[0000858877-16-000090:notes:81]
Financing Guarantee Summary   The aggregate amounts of financing guarantees outstanding at January 23, 2016 and July 25, 2015, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

[0000858877-16-000090:notes:82]
|  | January 23, 2016 |  | July 25, 2015 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 244 |  |  | $ | 288 |  |
| End user | 113 |  |  | 129 |  |
| Total | $ | 357 |  |  | $ | 417 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (100 | ) |  | $ | (127 | ) |
| End user | (90 | ) |  | (107 | ) |
| Total | $ | (190 | ) |  | $ | (234 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue | $ | 167 |  |  | $ | 183 |  |

[0000858877-16-000090:notes:83]
Other Guarantees   The Company’s other guarantee arrangements as of January 23, 2016 and July 25, 2015 that were subject to recognition and disclosure requirements were not material.

[0000858877-16-000090:notes:84]
| (f) | Supplier Component Remediation Liability |

[0000858877-16-000090:notes:85]
The Company has recorded in other current liabilities a liability for the expected remediation cost for certain products sold in prior fiscal years containing memory components manufactured by a single supplier between 2005 and 2010. These components were widely used across the industry and are included in a number of the Company's products. Defects in some of these components have caused products to fail after a power cycle event. Defect rates due to this issue have been and are expected to be low. However, the Company has seen a small number of its customers experience a growing number of failures in their networks as a result of this component problem. Although the majority of these products was beyond the Company's warranty terms, the Company has been proactively working with customers on mitigation. Prior to the second quarter of fiscal 2014, the Company had a liability of $63 million related to this issue for expected remediation costs based on the intended approach at that time. In February 2014, on the basis of the growing number of failures described above, the Company decided to expand its approach, which resulted in a charge to product cost of sales of $655 million being recorded for the second quarter of fiscal 2014. During the third quarter of fiscal 2015, an adjustment to product cost of sales of $164 million was recorded to reduce the liability, reflecting net lower than previously estimated future costs to remediate the impacted customer products. The supplier component remediation liability as of January 23, 2016 and July 25, 2015 was $375 million and $408 million, respectively.

[0000858877-16-000090:notes:86]
| (g) | Indemnifications |

[0000858877-16-000090:notes:87]
In the normal course of business, the Company indemnifies other parties, including customers, lessors, and parties to other transactions with the Company, with respect to certain matters. The Company has agreed to hold such parties harmless against losses arising from a breach of representations or covenants or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim.

[0000858877-16-000090:notes:88]
The Company is providing such indemnifications, among other cases, in matters involving certain of the Company’s service provider customers that are subject to patent infringement claims asserted by Sprint Communications Company, L.P. (“Sprint”) now pending in Kansas and Delaware. Sprint alleges that the service provider customers infringe Sprint’s patents by offering Voice over Internet Protocol-based telephone services utilizing products provided by the Company and other manufacturers. Sprint seeks monetary damages. Sprint’s cases in Kansas include claims against Comcast and Time Warner Cable, and the case in Delaware for which the Company is providing indemnification involves Cox Communications. At the request of Sprint and Comcast, on August 5, 2015, the judge in Sprint’s Kansas action ordered a six-month stay of the patent litigation between those parties for them to pursue a resolution of their dispute. In addition, on May 15, 2015, the judge in Sprint's Delaware action against Cox ruled invalid six of the patents that Sprint asserted Cox had infringed and a final judgment was entered on August 27, 2015, of invalidity, which Sprint appealed on October 1, 2015. In May 2015 the Company filed two declaratory judgment actions against Sprint seeking declarations that the patents Sprint asserted against the Company’s customers are invalid and/or not infringed. Cox has filed a motion for summary judgment of non-infringement for the five remaining Sprint patents that are actively being litigated against Cox in Delaware, and Comcast has also won a judgment of non-infringement, now being appealed by Sprint, in a separate case brought against it by Sprint in Delaware. In light of the invalidity rulings against Sprint in Delaware, on October 8, 2015, the judge in Sprint’s Kansas actions ordered an additional stay of Sprint’s Kansas actions including the case against Time Warner Cable, pending resolution of Sprint’s appeal of the Delaware Judge’s judgment of invalidity in the Cox case.

[0000858877-16-000090:notes:89]
The Company believes that the service providers have strong defenses and that its products do not infringe the patents subject to the claims and/or that Sprint's patents are invalid. Due to the uncertainty surrounding the litigation process, which involves numerous defendants, the Company is unable to reasonably estimate the ultimate outcome of this litigation at this time. Should the plaintiff prevail in litigation, mediation, or settlement, the Company, in accordance with its agreement, may have an obligation to indemnify its service provider customers for damages, mediation awards, or settlement amounts arising from their use of Cisco products.

[0000858877-16-000090:notes:90]
In addition, the Company has entered into indemnification agreements with its officers and directors, and the Company’s Amended and Restated Bylaws contain similar indemnification obligations to the Company’s agents.

[0000858877-16-000090:notes:91]
It is not possible to determine the maximum potential amount under these indemnification agreements due to the Company’s limited history with prior indemnification claims and the unique facts and circumstances involved in each particular agreement.  Historically, payments made by the Company under these agreements have not had a material effect on the Company’s operating results, financial position, or cash flows.

[0000858877-16-000090:notes:92]
| (h) | Legal Proceedings |

[0000858877-16-000090:notes:93]
Brazil    Brazilian authorities have investigated the Company’s Brazilian subsidiary and certain of its current and former employees, as well as a Brazilian importer of the Company’s products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against the Company’s Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years. In the first quarter of fiscal 2013, the Brazilian federal tax authorities asserted an additional claim against the Company’s Brazilian subsidiary based on a theory of joint liability with respect to an alleged underpayment of income taxes, social taxes, interest, and penalties by a Brazilian distributor.

[0000858877-16-000090:notes:94]
The asserted claims by Brazilian federal tax authorities are for calendar years 2003 through 2008, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to $209 million for the alleged evasion of import and other taxes, $942 million for interest, and $929 million for various penalties, all determined using an exchange rate as of January 23, 2016. The Company has completed a thorough review of the matters and believes the asserted claims against the Company’s Brazilian subsidiary are without merit, and the Company is defending the claims vigorously. While the Company believes there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, the Company is unable to determine the likelihood of an unfavorable outcome against its Brazilian subsidiary and is unable to reasonably estimate a range of loss, if any. The Company does not expect a final judicial determination for several years.

[0000858877-16-000090:notes:95]
Russia and the Commonwealth of Independent States    At the request of the U.S. Securities and Exchange Commission (SEC) and the U.S. Department of Justice, the Company is conducting an investigation into allegations that the Company and those agencies received regarding possible violations of the U.S. Foreign Corrupt Practices Act involving business activities of the Company's operations in Russia and certain of the Commonwealth of Independent States, and by certain resellers of the Company’s products in those countries. The Company takes any such allegations very seriously and is fully cooperating with and sharing the results of its investigation with the SEC and the Department of Justice. While the outcome of the Company's investigation is currently not determinable, the Company does not expect that it will have a material adverse effect on its consolidated financial position, results of operations, or cash flows. The countries that are the subject of the investigation collectively comprise less than 2% of the Company’s revenues.

[0000858877-16-000090:notes:96]
In addition, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, the Company does not expect that the ultimate costs to resolve these matters will have a material adverse effect on its consolidated financial position, results of operations, or cash flows.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000858877-16-000090:notes:97]
[same as prior period, unchanged from 0000858877-15-000073:notes:89]

[0000858877-16-000090:notes:98]
The components of AOCI, net of tax, and the other comprehensive income (loss), excluding noncontrolling interest, for the six months ended January 23, 2016 and January 24, 2015 are summarized as follows (in millions):

[0000858877-16-000090:notes:99]
|  | Net Unrealized Gains on Available-for-Sale Investments |  | Net Unrealized Losses Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Actuarial Gains and Losses |  | Accumulated Other Comprehensive Income (Loss) |
| BALANCE AT JULY 25, 2015 | $ | 310 |  |  | $ | (16 | ) |  | $ | (233 | ) |  | $ | 61 |  |
| Other comprehensive income (loss) before reclassifications attributable to Cisco Systems, Inc. | (515 | ) |  | (24 | ) |  | (524 | ) |  | (1,063 | ) |
| (Gains) losses reclassified out of AOCI | 20 |  |  | 8 |  |  | 1 |  |  | 29 |  |
| Tax benefit (expense) | 198 |  |  | 2 |  |  | (34 | ) |  | 166 |  |
| BALANCE AT JANUARY 23, 2016 | $ | 13 |  |  | $ | (30 | ) |  | $ | (790 | ) |  | $ | (807 | ) |

[0000858877-16-000090:notes:100]
|  | Net Unrealized Gains on Available-for-Sale Investments |  | Net Unrealized Losses Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Actuarial Gains and Losses |  | Accumulated Other Comprehensive Income (Loss) |
| BALANCE AT JULY 26, 2014 | $ | 424 |  |  | $ | (12 | ) |  | $ | 265 |  |  | $ | 677 |  |
| Other comprehensive income (loss) before reclassifications attributable to Cisco Systems, Inc. | (23 | ) |  | (131 | ) |  | (379 | ) |  | (533 | ) |
| (Gains) losses reclassified out of AOCI | (76 | ) |  | 30 |  |  | — |  |  | (46 | ) |
| Tax benefit (expense) | 49 |  |  | 3 |  |  | 36 |  |  | 88 |  |
| BALANCE AT JANUARY 24, 2015 | $ | 374 |  |  | $ | (110 | ) |  | $ | (78 | ) |  | $ | 186 |  |

[0000858877-16-000090:notes:101]
[same as prior period, unchanged from 0000858877-15-000073:notes:93]

[0000858877-16-000090:notes:102]
|  |  | Three Months Ended |  | Six Months Ended |  |  |
|  |  | January 23, 2016 |  | January 24, 2015 |  | January 23, 2016 |  | January 24, 2015 |  |  |
| Comprehensive Income Components |  | Income Before Taxes |  | Income Before Taxes |  | Line Item in Statements of Operations |
| Net unrealized gains on available-for-sale investments |  |  |  |  |  |  |  |  |  |  |
|  |  | $ | (19 | ) |  | $ | 69 |  |  | $ | (20 | ) |  | $ | 76 |  |  | Other income (loss), net |
| Net unrealized losses on cash flow hedging instruments |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | (4 | ) |  | (21 | ) |  | (6 | ) |  | (24 | ) |  | Operating expenses |
| Foreign currency derivatives |  | (1 | ) |  | (5 | ) |  | (2 | ) |  | (6 | ) |  | Cost of sales—service |
|  |  | (5 | ) |  | (26 | ) |  | (8 | ) |  | (30 | ) |  |  |
| Cumulative translation adjustment and actuarial gains and losses |  |  |  |  |  |  |  |  |  |  |
|  |  | — |  |  | — |  |  | (1 | ) |  | — |  |  | Operating expenses |
| Total amounts reclassified out of AOCI |  | $ | (24 | ) |  | $ | 43 |  |  | $ | (29 | ) |  | $ | 46 |  |  |  |


## us-gaap:DebtDisclosureTextBlock

[0000858877-16-000090:notes:103]
| 10. | Borrowings |

[0000858877-16-000090:notes:104]
| (a) | Short-Term Debt |

[0000858877-16-000090:notes:105]
The following table summarizes the Company’s short-term debt (in millions, except percentages):

[0000858877-16-000090:notes:106]
|  | January 23, 2016 |  | July 25, 2015 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 3,006 |  |  | 3.12 | % |  | $ | 3,894 |  |  | 2.48 | % |
| Other short-term debt | 2 |  |  | 2.08 | % |  | 3 |  |  | 2.44 | % |
| Total | $ | 3,008 |  |  |  |  | $ | 3,897 |  |  |  |

[0000858877-16-000090:notes:107]
The effective interest rate on the current portion of long-term debt includes the impact of interest rate swaps, as discussed further in "

[0000858877-16-000090:notes:108]
| (b) | Long-Term Debt |

[0000858877-16-000090:notes:109]
." Other notes and borrowings consist of the short-term portion of secured borrowings associated with customer financing arrangements. These notes and credit facilities were subject to various terms and foreign currency market interest rates pursuant to individual financial arrangements between the financing institution and the applicable foreign subsidiary.

[0000858877-16-000090:notes:110]
On September 3, 2015, the Company repaid an aggregate principal amount of $850 million upon the maturity of its 2015 Floating-Rate Notes.

[0000858877-16-000090:notes:111]
In fiscal 2011, the Company established a short-term debt financing program of up to $3.0 billion through the issuance of commercial paper notes. The Company uses the proceeds from the issuance of commercial paper notes for general corporate purposes. The Company had no commercial paper notes outstanding as of each of January 23, 2016 and July 25, 2015.

[0000858877-16-000090:notes:112]
(b)

[0000858877-16-000090:notes:113]
Long-Term Debt

[0000858877-16-000090:notes:114]
The following table summarizes the Company’s long-term debt (in millions, except percentages):

[0000858877-16-000090:notes:115]
|  |  |  | January 23, 2016 |  | July 25, 2015 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.05% | September 3, 2015 |  | $ | — |  |  | — |  | $ | 850 |  |  | 0.43% |
| Three-month LIBOR plus 0.28% | March 3, 2017 |  | 1,000 |  |  | 0.77% |  | 1,000 |  |  | 0.63% |
| Three-month LIBOR plus 0.31% | June 15, 2018 |  | 900 |  |  | 0.89% |  | 900 |  |  | 0.65% |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | 500 |  |  | 0.97% |  | 500 |  |  | 0.84% |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 5.50% | February 22, 2016 |  | 3,000 |  |  | 3.12% |  | 3,000 |  |  | 3.07% |
| 1.10% | March 3, 2017 |  | 2,400 |  |  | 0.83% |  | 2,400 |  |  | 0.59% |
| 3.15% | March 14, 2017 |  | 750 |  |  | 1.07% |  | 750 |  |  | 0.85% |
| 1.65% | June 15, 2018 |  | 1,600 |  |  | 1.72% |  | 1,600 |  |  | 1.72% |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 4.76% |  | 2,000 |  |  | 4.70% |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 1.04% |  | 1,750 |  |  | 0.80% |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 3.20% |  | 2,500 |  |  | 3.01% |
| 2.45% | June 15, 2020 |  | 1,500 |  |  | 2.54% |  | 1,500 |  |  | 2.54% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 1.20% |  | 500 |  |  | 0.96% |
| 3.00% | June 15, 2022 |  | 500 |  |  | 1.45% |  | 500 |  |  | 1.21% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1.32% |  | 1,000 |  |  | 1.08% |
| 3.50% | June 15, 2025 |  | 500 |  |  | 1.61% |  | 500 |  |  | 1.37% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Other long-term debt |  |  | — |  |  |  |  | 1 |  |  | 2.08% |
| Total |  |  | 24,400 |  |  |  |  | 25,251 |  |  |  |
| Unaccreted discount/issuance costs |  |  | (123 | ) |  |  |  | (131 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 320 |  |  |  |  | 231 |  |  |  |
| Total |  |  | $ | 24,597 |  |  |  |  | $ | 25,351 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 3,006 |  |  |  |  | $ | 3,894 |  |  |  |
| Long-term debt |  |  | 21,591 |  |  |  |  | 21,457 |  |  |  |
| Total |  |  | $ | 24,597 |  |  |  |  | $ | 25,351 |  |  |  |

[0000858877-16-000090:notes:116]
To achieve its interest rate risk management objectives, the Company entered into interest rate swaps in prior periods with an aggregate notional amount of $11.4 billion designated as fair value hedges of certain of its fixed-rate senior notes.  In effect, these swaps convert the fixed interest rates of the fixed-rate notes to floating interest rates based on the London InterBank Offered Rate (LIBOR). The gains and losses related to changes in the fair value of the interest rate swaps substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates.  For additional information, see Note 11.

[0000858877-16-000090:notes:117]
The effective rates for the fixed-rate debt include the interest on the notes, the accretion of the discount and issuance costs, and, if applicable, adjustments related to hedging. Interest is payable semiannually on each class of the senior fixed-rate notes and payable quarterly on the floating-rate notes. Each of the senior fixed-rate notes is redeemable by the Company at any time, subject to a make-whole premium.

[0000858877-16-000090:notes:118]
The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to the Company’s short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of January 23, 2016, the Company was in compliance with all debt covenants.

[0000858877-16-000090:notes:119]
As of January 23, 2016, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

[0000858877-16-000090:notes:120]
| Fiscal Year | Amount |
| 2016 (remaining six months) | $ | 3,000 |  |
| 2017 | 4,150 |  |
| 2018 | 2,500 |  |
| 2019 | 4,250 |  |
| 2020 | 4,000 |  |
| Thereafter | 6,500 |  |
| Total | $ | 24,400 |  |

[0000858877-16-000090:notes:121]
| (c) | Credit Facility |

[0000858877-16-000090:notes:122]
On May 15, 2015, the Company entered into a credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on May 15, 2020. Any advances under the credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (i) the highest of (a) the Federal Funds rate plus 0.50%, (b) Bank of America’s “prime rate” as announced from time to time, or (c) LIBOR, or a comparable or successor rate that is approved by the Administrative Agent (“Eurocurrency Rate”), for an interest period of one-month plus 1.00%, or (ii) the Eurocurrency Rate, plus a margin that is based on the Company’s senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc., provided that in no event will the Eurocurrency Rate be less than zero.  The credit agreement requires the Company to comply with certain covenants, including that it maintain an interest coverage ratio as defined in the agreement.

[0000858877-16-000090:notes:123]
The Company may also, upon the agreement of either the then-existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and/or extend the expiration date of the credit facility up to May 15, 2022.  The Company was in compliance with the required interest coverage ratio and the other covenants, and the Company had not borrowed any funds under the credit facility.


## us-gaap:DeferredRevenueByArrangementDisclosureTextBlock

[0000858877-16-000090:notes:124]
| Deferred revenue: |  |  |  |  |
| Service |  | $ | 9,657 |  |  | $ | 9,757 |  |
| Product: |  |  |  |  |
| Unrecognized revenue on product shipments and other deferred revenue |  | 4,974 |  |  | 4,766 |  |
| Cash receipts related to unrecognized revenue from two-tier distributors |  | 554 |  |  | 660 |  |
| Total product deferred revenue |  | 5,528 |  |  | 5,426 |  |
| Total |  | $ | 15,185 |  |  | $ | 15,183 |  |
| Reported as: |  |  |  |  |
| Current |  | $ | 9,796 |  |  | $ | 9,824 |  |
| Noncurrent |  | 5,389 |  |  | 5,359 |  |
| Total |  | $ | 15,185 |  |  | $ | 15,183 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000858877-16-000090:notes:125]
[same as prior period, unchanged from 0000858877-15-000073:notes:117]

[0000858877-16-000090:notes:126]
[same as prior period, unchanged from 0000858877-15-000073:notes:118]

[0000858877-16-000090:notes:127]
The Company uses derivative instruments primarily to manage exposures to foreign currency exchange rate, interest rate, and equity price risks. The Company’s primary objective in holding derivatives is to reduce the volatility of earnings and cash flows associated with changes in foreign currency exchange rates, interest rates, and equity prices. The Company’s derivatives expose it to credit risk to the extent that the counterparties may be unable to meet the terms of the agreement. The Company does, however, seek to mitigate such risks by limiting its counterparties to major financial institutions. In addition, the potential risk of loss with any one counterparty resulting from this type of credit risk is monitored. Management does not expect material losses as a result of defaults by counterparties.

[0000858877-16-000090:notes:128]
[same as prior period, unchanged from 0000858877-15-000073:notes:120]

[0000858877-16-000090:notes:129]
|  | DERIVATIVE ASSETS |  | DERIVATIVE LIABILITIES |
|  | Balance Sheet Line Item |  | January 23, 2016 |  | July 25, 2015 |  | Balance Sheet Line Item |  | January 23, 2016 |  | July 25, 2015 |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | $ | 1 |  |  | $ | 10 |  |  | Other current liabilities |  | $ | 16 |  |  | $ | 11 |  |
| Interest rate derivatives | Other assets |  | 313 |  |  | 202 |  |  | Other long-term liabilities |  | — |  |  | — |  |
| Total |  |  | 314 |  |  | 212 |  |  |  |  | 16 |  |  | 11 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | 4 |  |  | 2 |  |  | Other current liabilities |  | 3 |  |  | 1 |  |
| Equity derivatives | Other assets |  | 3 |  |  | 4 |  |  | Other long-term liabilities |  | — |  |  | — |  |
| Total |  |  | 7 |  |  | 6 |  |  |  |  | 3 |  |  | 1 |  |
| Total |  |  | $ | 321 |  |  | $ | 218 |  |  |  |  | $ | 19 |  |  | $ | 12 |  |

[0000858877-16-000090:notes:130]
[same as prior period, unchanged from 0000858877-15-000073:notes:122]

[0000858877-16-000090:notes:131]
| GAINS (LOSSES) RECOGNIZEDIN OCI ON DERIVATIVES FOR THE THREE MONTHS ENDED (EFFECTIVE PORTION) |  | GAINS (LOSSES) RECLASSIFIED FROMAOCI INTO INCOME FOR THETHREE MONTHS ENDED (EFFECTIVE PORTION) |
|  |  | January 23, 2016 |  | January 24, 2015 |  | Line Item in Statements of Operations |  | January 23, 2016 |  | January 24, 2015 |
| Derivatives designated as cash flow hedging instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | (20 | ) |  | $ | (75 | ) |  | Operating expenses |  | $ | (4 | ) |  | $ | (21 | ) |
|  |  |  |  |  |  | Cost of sales—service |  | (1 | ) |  | (5 | ) |
| Total |  | $ | (20 | ) |  | $ | (75 | ) |  |  |  | $ | (5 | ) |  | $ | (26 | ) |
| Derivatives designated as net investment hedging instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | 11 |  |  | $ | 24 |  |  | Other income (loss), net |  | $ | — |  |  | $ | — |  |

[0000858877-16-000090:notes:132]
| GAINS (LOSSES) RECOGNIZEDIN OCI ON DERIVATIVES FOR THE SIX MONTHS ENDED (EFFECTIVE PORTION) |  | GAINS (LOSSES) RECLASSIFIED FROMAOCI INTO INCOME FOR THESIX MONTHS ENDED (EFFECTIVE PORTION) |
|  |  | January 23, 2016 |  | January 24, 2015 |  | Line Item in Statements of Operations |  | January 23, 2016 |  | January 24, 2015 |
| Derivatives designated as cash flow hedging instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | (24 | ) |  | $ | (131 | ) |  | Operating expenses |  | $ | (6 | ) |  | $ | (24 | ) |
|  |  |  |  |  |  | Cost of sales—service |  | (2 | ) |  | (6 | ) |
| Total |  | $ | (24 | ) |  | $ | (131 | ) |  |  |  | $ | (8 | ) |  | $ | (30 | ) |
| Derivatives designated as net investment hedging instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | 11 |  |  | $ | 44 |  |  | Other income (loss), net |  | $ | — |  |  | $ | — |  |

[0000858877-16-000090:notes:133]
As of January 23, 2016, the Company estimates that approximately $21 million of net derivative losses related to its cash flow hedges included in accumulated other comprehensive income/loss (AOCI) will be reclassified into earnings within the next 12 months when the underlying hedged item impacts earnings.

[0000858877-16-000090:notes:134]
[same as prior period, unchanged from 0000858877-15-000073:notes:125]

[0000858877-16-000090:notes:135]
|  |  |  |  | GAINS (LOSSES) FOR THETHREE MONTHS ENDED |  | GAINS (LOSSES) FOR THESIX MONTHS ENDED |
| Derivatives Not Designated as Hedging Instruments |  | Line Item in Statements of Operations |  | January 23, 2016 |  | January 24, 2015 |  | January 23, 2016 |  | January 24, 2015 |
| Foreign currency derivatives |  | Other income (loss), net |  | $ | (58 | ) |  | $ | (51 | ) |  | $ | (54 | ) |  | $ | (109 | ) |
| Total return swaps—deferred compensation |  | Operating expenses |  | (38 | ) |  | 13 |  |  | (54 | ) |  | — |  |
| Equity derivatives |  | Other income (loss), net |  | 3 |  |  | 8 |  |  | 13 |  |  | 4 |  |
| Total |  |  |  | $ | (93 | ) |  | $ | (30 | ) |  | $ | (95 | ) |  | $ | (105 | ) |

[0000858877-16-000090:notes:136]
[same as prior period, unchanged from 0000858877-15-000073:notes:127]

[0000858877-16-000090:notes:137]
|  | January 23, 2016 |  | July 25, 2015 |
| Derivatives designated as hedging instruments: |  |  |  |
| Foreign currency derivatives—cash flow hedges | $ | 684 |  |  | $ | 1,201 |  |
| Interest rate derivatives | 11,400 |  |  | 11,400 |  |
| Net investment hedging instruments | 283 |  |  | 192 |  |
| Derivatives not designated as hedging instruments: |  |  |  |
| Foreign currency derivatives | 2,469 |  |  | 2,023 |  |
| Total return swaps—deferred compensation | 432 |  |  | 462 |  |
| Total | $ | 15,268 |  |  | $ | 15,278 |  |

[0000858877-16-000090:notes:138]
[same as prior period, unchanged from 0000858877-15-000073:notes:129]

[0000858877-16-000090:notes:139]
The Company presents its derivative instruments at gross fair values in the Consolidated Balance Sheets. However, the Company’s master netting and other similar arrangements with the respective counterparties allow for net settlement under certain conditions, which are designed to reduce credit risk by permitting net settlement with the same counterparty. To further limit credit risk, the Company also enters into collateral security arrangements related to certain derivative instruments whereby cash is posted as collateral between the counterparties based on the fair market value of the derivative instrument. Information related to these offsetting arrangements is summarized as follows (in millions):

[0000858877-16-000090:notes:140]
|  | January 23, 2016 |
|  | Gross Amounts Offset in the Consolidated Balance Sheets |  | Gross Amounts Not Offset in the Consolidated Balance Sheets, but with Legal Rights to Offset |
|  | Gross Amounts Recognized |  | Gross Amounts Offset |  | Net Amounts Presented |  | Gross Derivative Amounts |  | Cash Collateral |  | Net Amount |
| Derivatives assets | $ | 321 |  |  | $ | — |  |  | $ | 321 |  |  | $ | (15 | ) |  | $ | (255 | ) |  | $ | 51 |  |
| Derivatives liabilities | $ | 19 |  |  | $ | — |  |  | $ | 19 |  |  | $ | (15 | ) |  | $ | — |  |  | $ | 4 |  |

[0000858877-16-000090:notes:141]
[same as prior period, unchanged from 0000858877-15-000073:notes:132]

[0000858877-16-000090:notes:142]
[same as prior period, unchanged from 0000858877-15-000073:notes:133]

[0000858877-16-000090:notes:143]
The Company conducts business globally in numerous currencies. Therefore, it is exposed to adverse movements in foreign currency exchange rates. To limit the exposure related to foreign currency changes, the Company enters into foreign currency contracts. The Company does not enter into such contracts for trading purposes.

[0000858877-16-000090:notes:144]
The Company hedges forecasted foreign currency transactions related to certain operating expenses and service cost of sales with currency options and forward contracts. These currency options and forward contracts, designated as cash flow hedges, generally have maturities of less than 18 months. The Company assesses effectiveness based on changes in total fair value of the derivatives.  The effective portion of the derivative instrument’s gain or loss is initially reported as a component of AOCI and subsequently reclassified into earnings when the hedged exposure affects earnings. The ineffective portion, if any, of the gain or loss is reported in earnings immediately. During the periods presented, the Company did not discontinue any cash flow hedges for which it was probable that a forecasted transaction would not occur.

[0000858877-16-000090:notes:145]
The Company enters into foreign exchange forward and option contracts to reduce the short-term effects of foreign currency fluctuations on assets and liabilities such as foreign currency receivables, including long-term customer financings, investments, and payables. These derivatives are not designated as hedging instruments. Gains and losses on the contracts are included in other income (loss), net, and substantially offset foreign exchange gains and losses from the remeasurement of intercompany balances or other current assets, investments, or liabilities denominated in currencies other than the functional currency of the reporting entity.

[0000858877-16-000090:notes:146]
The Company hedges certain net investments in its foreign operations with forward contracts to reduce the effects of foreign currency fluctuations on the Company’s net investment in those foreign subsidiaries. These derivative instruments generally have maturities of up to six months.

[0000858877-16-000090:notes:147]
[same as prior period, unchanged from 0000858877-15-000073:notes:138]

[0000858877-16-000090:notes:148]
Interest Rate Derivatives, Investments   The Company’s primary objective for holding fixed income securities is to achieve an appropriate investment return consistent with preserving principal and managing risk. To realize these objectives, the Company may utilize interest rate swaps or other derivatives designated as fair value or cash flow hedges. As of January 23, 2016 and July 25, 2015, the Company did not have any outstanding interest rate derivatives related to its fixed income securities.

[0000858877-16-000090:notes:149]
Interest Rate Derivatives Designated as Fair Value Hedges, Long-Term Debt   In fiscal 2016, the Company did not enter into any interest rate swaps. In prior fiscal years, the Company entered into interest rate swaps designated as fair value hedges related to fixed-rate senior notes that are due in fiscal years 2016 through 2025. Under these interest rate swaps, the Company receives fixed-rate interest payments and makes interest payments based on LIBOR plus a fixed number of basis points. The effect of such swaps is to convert the fixed interest rates of the senior fixed-rate notes to floating interest rates based on LIBOR. The gains and losses related to changes in the fair value of the interest rate swaps are included in interest expense and substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates. The fair value of the interest rate swaps was reflected in other assets and other long-term liabilities.

[0000858877-16-000090:notes:150]
[same as prior period, unchanged from 0000858877-15-000073:notes:141]

[0000858877-16-000090:notes:151]
The Company may hold equity securities for strategic purposes or to diversify its overall investment portfolio. The publicly traded equity securities in the Company’s portfolio are subject to price risk. To manage its exposure to changes in the fair value of certain equity securities, the Company has entered into equity derivatives that are designated as fair value hedges. The changes in the value of the hedging instruments are included in other income (loss), net, and offset the change in the fair value of the underlying hedged investment. In addition, the Company periodically enters into equity derivatives that are not designated as accounting hedges. The changes in the fair value of these derivatives are also included in other income (loss), net.

[0000858877-16-000090:notes:152]
The Company is also exposed to variability in compensation charges related to certain deferred compensation obligations to employees. Although not designated as accounting hedges, the Company utilizes derivatives such as total return swaps to economically hedge this exposure.

[0000858877-16-000090:notes:153]
[same as prior period, unchanged from 0000858877-15-000073:notes:144]

[0000858877-16-000090:notes:154]
For the periods presented, amounts excluded from the assessment of hedge effectiveness were not material for fair value, cash flow, and net investment hedges. In addition, hedge ineffectiveness for fair value, cash flow, and net investment hedges was not material for any of the periods presented.

[0000858877-16-000090:notes:155]
[same as prior period, unchanged from 0000858877-15-000073:notes:146]

[0000858877-16-000090:notes:156]
For certain derivative instruments, the Company and its counterparties have entered into arrangements requiring the party that is in a liability position from a mark-to-market standpoint to post cash collateral to the other party. See further discussion under “(b) Offsetting of Derivative Instruments” above.

[0000858877-16-000090:notes:157]
In addition, certain derivative instruments are executed under agreements that have provisions requiring the Company and the counterparty to maintain a specified credit rating from certain credit-rating agencies. Under such agreements, if the Company’s or the counterparty’s credit rating falls below a specified credit rating, either party has the right to request collateral on the derivatives’ net liability position. No such derivatives were in a net liability position as of January 23, 2016 or July 25, 2015.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000858877-16-000090:notes:158]
[same as prior period, unchanged from 0000858877-15-000073:notes:149]

[0000858877-16-000090:notes:159]
[same as prior period, unchanged from 0000858877-15-000073:notes:150]

[0000858877-16-000090:notes:160]
Stock Incentive Plan Program Description    As of January 23, 2016, the Company had three stock incentive plans: the 2005 Stock Incentive Plan (the “2005 Plan”); the Cisco Systems, Inc. SA Acquisition Long-Term Incentive Plan (the “SA Acquisition Plan”); and the Cisco Systems, Inc. WebEx Acquisition Long-Term Incentive Plan (the “WebEx Acquisition Plan”). In addition, the Company has, in connection with the acquisitions of various companies, assumed the share-based awards granted under stock incentive plans of the acquired companies or issued share-based awards in replacement thereof. Share-based awards are designed to reward employees for their long-term contributions to the Company and provide incentives for them to remain with the Company.  The number and frequency of share-based awards are based on competitive practices, operating results of the Company, government regulations, and other factors. Since the inception of the stock incentive plans, the Company has granted share-based awards to a significant percentage of its employees, and the majority has been granted to employees below the vice president level. The Company’s primary stock incentive plans are summarized as follows:

[0000858877-16-000090:notes:161]
2005 Plan    As of January 23, 2016, the maximum number of shares issuable under the 2005 Plan over its term was 694 million shares, plus the 1996 Stock Incentive Plan, the SA Acquisition Plan, and the WebEx Acquisition Plan that are forfeited or are terminated for any other reason before being exercised or settled. If any awards granted under the 2005 Plan are forfeited or are terminated for any other reason before being exercised or settled, the unexercised or unsettled shares underlying the awards will again be available under the 2005 Plan. Starting November 19, 2013, shares withheld by the Company from an award other than a stock option or stock appreciation right to satisfy withholding tax liabilities resulting from such award will again be available for issuance, based on the fungible share ratio in effect on the date of grant.

[0000858877-16-000090:notes:162]
Pursuant to an amendment approved by the Company’s shareholders on November 12, 2009, the number of shares available for issuance under the 2005 Plan is reduced by 1.5 shares for each share awarded as a stock grant or a stock unit, and any shares underlying awards outstanding under the 1996 Stock Incentive Plan, the SA Acquisition Plan, and the WebEx Acquisition Plan that expire unexercised at the end of their maximum terms become available for reissuance under the 2005 Plan. The 2005 Plan permits the granting of stock options, restricted stock, and restricted stock units ("RSUs"), the vesting of which may be performance-based or market-based along with the requisite service requirement, and stock appreciation rights to employees (including employee directors and officers), consultants of the Company and its subsidiaries and affiliates, and non-employee directors of the Company. Stock options and stock appreciation rights granted under the 2005 Plan have an exercise price of at least 100% of the fair market value of the underlying stock on the grant date and prior to November 12, 2009 have an expiration date no later than nine years from the grant date. The expiration date for stock options and stock appreciation rights granted subsequent to the amendment approved on November 12, 2009 shall be no later than 10 years from the grant date.

[0000858877-16-000090:notes:163]
The stock options will generally become exercisable for 20% or 25% of the option shares one year from the date of grant and then ratably over the following 48 months or 36 months, respectively. Time-based stock grants and time-based RSUs will generally vest with respect to 20% or 25% of the shares or share units covered by the grant annually over the vesting period. The majority of the performance-based and market-based RSUs vests at the end of the three-year requisite service period or earlier if the award recipient meets certain retirement eligibility conditions. Certain performance-based RSUs, that are based on the achievement of financial and/or non-financial operating goals, typically vest upon the achievement of milestones (and may require subsequent service periods), with overall vesting of the shares underlying the award ranging from six months to three years. The Compensation and Management Development Committee of the Board of Directors has the discretion to use different vesting schedules. Stock appreciation rights may be awarded in combination with stock options or stock grants, and such awards shall provide that the stock appreciation rights will not be exercisable unless the related stock options or stock grants are forfeited. Stock grants may be awarded in combination with non-statutory stock options, and such awards may provide that the stock grants will be forfeited in the event that the related non-statutory stock options are exercised.

[0000858877-16-000090:notes:164]
Acquisition Plans In connection with the Company’s acquisitions of Scientific-Atlanta, Inc. (“Scientific-Atlanta”) and WebEx Communications, Inc. (“WebEx”), the Company adopted the SA Acquisition Plan and the WebEx Acquisition Plan, respectively, each effective upon completion of the applicable acquisition. These plans constitute assumptions, amendments, restatements, and renamings of the 2003 Long-Term Incentive Plan of Scientific-Atlanta and the WebEx Communications, Inc. Amended and Restated 2000 Stock Incentive Plan, respectively. The plans permit the grant of stock options, stock, stock units, and stock appreciation rights to certain employees of the Company and its subsidiaries and affiliates who had been employed by Scientific-Atlanta or its subsidiaries or WebEx or its subsidiaries, as applicable. As a result of the shareholder approval of the amendment and extension of the 2005 Plan, as of November 15, 2007, the Company will no longer make stock option grants or direct share issuances under either the SA Acquisition Plan or the WebEx Acquisition Plan.

[0000858877-16-000090:notes:165]
[same as prior period, unchanged from 0000858877-15-000073:notes:157]

[0000858877-16-000090:notes:166]
The Company has an Employee Stock Purchase Plan, which includes its subplan named the International Employee Stock Purchase Plan (together, the “Purchase Plan”), under which 621 million shares of the Company’s common stock have been reserved for issuance as of January 23, 2016. Eligible employees are offered shares through a 24-month offering period, which consists of four consecutive 6-month purchase periods. Employees may purchase a limited number of shares of the Company’s stock at a discount of up to 15% of the lesser of the market value at the beginning of the offering period or the end of each 6-month purchase period.  The Purchase Plan is scheduled to terminate on January 3, 2020. The Company issued 14 million shares under the Purchase Plan during each of the six months ended January 23, 2016 and January 24, 2015. As of January 23, 2016, 134 million shares were available for issuance under the Purchase Plan.

[0000858877-16-000090:notes:167]
[same as prior period, unchanged from 0000858877-15-000073:notes:159]

[0000858877-16-000090:notes:168]
[same as prior period, unchanged from 0000858877-15-000073:notes:160]

[0000858877-16-000090:notes:169]
|  | Three Months Ended |  | Six Months Ended |
|  | January 23, 2016 |  | January 24, 2015 |  | January 23, 2016 |  | January 24, 2015 |
| Cost of sales—product | $ | 16 |  |  | $ | 11 |  |  | $ | 29 |  |  | $ | 22 |  |
| Cost of sales—service | 35 |  |  | 34 |  |  | 73 |  |  | 71 |  |
| Share-based compensation expense in cost of sales | 51 |  |  | 45 |  |  | 102 |  |  | 93 |  |
| Research and development | 107 |  |  | 105 |  |  | 221 |  |  | 224 |  |
| Sales and marketing | 126 |  |  | 114 |  |  | 265 |  |  | 261 |  |
| General and administrative | 47 |  |  | 42 |  |  | 104 |  |  | 101 |  |
| Restructuring and other charges | (1 | ) |  | 2 |  |  | 14 |  |  | (2 | ) |
| Share-based compensation expense in operating expenses | 279 |  |  | 263 |  |  | 604 |  |  | 584 |  |
| Total share-based compensation expense | $ | 330 |  |  | $ | 308 |  |  | $ | 706 |  |  | $ | 677 |  |
| Income tax benefit for share-based compensation | $ | 103 |  |  | $ | 85 |  |  | $ | 198 |  |  | $ | 179 |  |

[0000858877-16-000090:notes:170]
As of January 23, 2016, the total compensation cost related to unvested share-based awards not yet recognized was $2.9 billion, which is expected to be recognized over approximately 2.6 years on a weighted-average basis.

[0000858877-16-000090:notes:171]
[same as prior period, unchanged from 0000858877-15-000073:notes:163]

[0000858877-16-000090:notes:172]
[same as prior period, unchanged from 0000858877-15-000073:notes:164]

[0000858877-16-000090:notes:173]
|  | Share-Based Awards Available for Grant |
| BALANCE AT JULY 26, 2014 | 310 |  |
| Restricted stock, stock units, and other share-based awards granted | (101 | ) |
| Share-based awards canceled/forfeited/expired | 40 |  |
| Shares withheld for taxes and not issued | 27 |  |
| BALANCE AT JULY 25, 2015 | 276 |  |
| Restricted stock, stock units, and other share-based awards granted | (64 | ) |
| Share-based awards canceled/forfeited/expired | 18 |  |
| Shares withheld for taxes and not issued | 23 |  |
| Other | 2 |  |
| BALANCE AT JANUARY 23, 2016 | 255 |  |

[0000858877-16-000090:notes:174]
As reflected in the preceding table, for each share awarded as restricted stock or subject to a restricted stock unit award under the 2005 Plan, an equivalent of 1.5 shares was deducted from the available share-based award balance. For restricted stock units that were awarded with vesting contingent upon the achievement of future financial performance or market-based metrics, the maximum awards that can be achieved upon full vesting of such awards were reflected in the preceding table.

[0000858877-16-000090:notes:175]
[same as prior period, unchanged from 0000858877-15-000073:notes:167]

[0000858877-16-000090:notes:176]
[same as prior period, unchanged from 0000858877-15-000073:notes:168]

[0000858877-16-000090:notes:177]
|  | Restricted Stock/Stock Units |  | Weighted-AverageGrant Date FairValue per Share |  | Aggregate Fair Value |
| UNVESTED BALANCE AT JULY 26, 2014 | 149 |  |  | $ | 19.54 |  |  |  |
| Granted and assumed | 67 |  |  | 25.29 |  |  |  |
| Vested | (57 | ) |  | 19.82 |  |  | $ | 1,517 |  |
| Canceled/forfeited | (16 | ) |  | 20.17 |  |  |  |
| UNVESTED BALANCE AT JULY 25, 2015 | 143 |  |  | 22.08 |  |  |  |
| Granted and assumed | 43 |  |  | 24.80 |  |  |  |
| Vested | (40 | ) |  | 20.24 |  |  | $ | 1,050 |  |
| Canceled/forfeited | (9 | ) |  | 22.57 |  |  |  |
| UNVESTED BALANCE AT JANUARY 23, 2016 | 137 |  |  | $ | 23.45 |  |  |  |

[0000858877-16-000090:notes:178]
[same as prior period, unchanged from 0000858877-15-000073:notes:170]

[0000858877-16-000090:notes:179]
[same as prior period, unchanged from 0000858877-15-000073:notes:171]

[0000858877-16-000090:notes:180]
|  | STOCK OPTIONS OUTSTANDING |
|  | NumberOutstanding |  | Weighted-AverageExercise Price per Share |
| BALANCE AT JULY 26, 2014 | 187 |  |  | $ | 26.03 |  |
| Assumed from acquisitions | 1 |  |  | 2.60 |  |
| Exercised | (71 | ) |  | 21.15 |  |
| Canceled/forfeited/expired | (14 | ) |  | 29.68 |  |
| BALANCE AT JULY 25, 2015 | 103 |  |  | 28.68 |  |
| Assumed from acquisitions | 5 |  |  | 2.07 |  |
| Exercised | (20 | ) |  | 21.63 |  |
| Canceled/forfeited/expired | (10 | ) |  | 29.00 |  |
| BALANCE AT JANUARY 23, 2016 | 78 |  |  | $ | 28.75 |  |

[0000858877-16-000090:notes:181]
The following table summarizes significant ranges of outstanding and exercisable stock options as of January 23, 2016 (in millions, except years and share prices):

[0000858877-16-000090:notes:182]
|  |  | STOCK OPTIONS OUTSTANDING |  | STOCK OPTIONS EXERCISABLE |
| Range of Exercise Prices |  | NumberOutstanding |  | Weighted-AverageRemainingContractualLife(in Years) |  | Weighted-AverageExercisePrice perShare |  | AggregateIntrinsicValue |  | NumberExercisable |  | Weighted-AverageExercisePrice perShare |  | AggregateIntrinsicValue |
| $ 0.01 – 20.00 |  | 7 |  |  | 6.2 |  | $ | 3.32 |  |  | $ | 135 |  |  | 4 |  |  | $ | 4.01 |  |  | $ | 70 |  |
| $ 20.01 – 25.00 |  | 2 |  |  | 0.9 |  | 23.02 |  |  | 1 |  |  | 2 |  |  | 23.02 |  |  | 1 |  |
| $ 25.01 – 30.00 |  | 10 |  |  | 0.7 |  | 26.82 |  |  | — |  |  | 10 |  |  | 26.82 |  |  | — |  |
| $ 30.01 – 35.00 |  | 59 |  |  | 0.6 |  | 32.16 |  |  | — |  |  | 59 |  |  | 32.16 |  |  | — |  |
| Total |  | 78 |  |  | 1.1 |  | $ | 28.75 |  |  | $ | 136 |  |  | 75 |  |  | $ | 29.83 |  |  | $ | 71 |  |

[0000858877-16-000090:notes:183]
The aggregate intrinsic value in the preceding table represents the total pretax intrinsic value, based on the Company’s closing stock price of $23.37 as of January 22, 2016, that would have been received by the option holders had those option holders exercised their stock options as of that date. The total number of in-the-money stock options exercisable as of January 23, 2016 was 4 million.  As of July 25, 2015, 102 million outstanding stock options were exercisable and the weighted-average exercise price was $29.02.

[0000858877-16-000090:notes:184]
[same as prior period, unchanged from 0000858877-15-000073:notes:176]

[0000858877-16-000090:notes:185]
Time-based restricted stock units and performance-based restricted stock units ("PRSUs") that are based on the Company’s financial performance metrics or non-financial operating goals are valued using the market value of the Company’s common stock on the date of grant, discounted for the present value of expected dividends. On the date of grant, the Company estimated the fair value of the total shareholder return (TSR) component of the PRSUs using a Monte Carlo simulation model. The assumptions for the valuation of time-based RSUs and PRSUs are summarized as follows:

[0000858877-16-000090:notes:186]
|  | RESTRICTED STOCK UNITS |  | PERFORMANCE RESTRICTED STOCK UNITS |
| Three Months Ended | January 23, 2016 |  | January 24, 2015 |  | January 23, 2016 |  | January 24, 2015 |
| Number of shares granted (in millions) | 27 |  |  | 1 |  |  | 1 |  |  | 1 |  |
| Grant date fair value per share | $ | 25.25 |  |  | $ | 25.07 |  |  | $ | 25.32 |  |  | $ | 25.39 |  |
| Weighted-average assumptions/inputs: |  |  |  |  |  |  |  |
| Expected dividend yield | 3.1 | % |  | 2.8 | % |  | 3.1 | % |  | 2.8 | % |
| Range of risk-free interest rates | 0.1% – 1.2% |  |  | 0.0% – 1.6% |  |  | 0.0% – 1.2% |  |  | 0.0% – 1.6% |  |
| Range of expected volatilities for index | N/A |  |  | N/A |  |  | 15.3% – 54.3% |  |  | 14.4% – 63.7% |  |

[0000858877-16-000090:notes:187]
|  | RESTRICTED STOCK UNITS |  | PERFORMANCE RESTRICTED STOCK UNITS |
| Six Months Ended | January 23, 2016 |  | January 24, 2015 |  | January 23, 2016 |  | January 24, 2015 |
| Number of shares granted (in millions) | 36 |  |  | 11 |  |  | 5 |  |  | 7 |  |
| Grant date fair value per share | $ | 24.93 |  |  | $ | 23.34 |  |  | $ | 24.71 |  |  | $ | 23.70 |  |
| Weighted-average assumptions/inputs: |  |  |  |  |  |  |  |
| Expected dividend yield | 3.1 | % |  | 3.0 | % |  | 3.2 | % |  | 3.0 | % |
| Range of risk-free interest rates | 0.0% – 1.2% |  |  | 0.0% – 1.8% |  |  | 0.0% – 1.2% |  |  | 0.0% – 1.8% |  |
| Range of expected volatilities for index | N/A |  |  | N/A |  |  | 15.3% – 54.3% |  |  | 14.4% – 70.0% |  |

[0000858877-16-000090:notes:188]
The PRSUs granted during the periods presented are contingent on the achievement of the Company’s financial performance metrics, its comparative market-based returns, or the achievement of financial and non-financial operating goals. For the awards based on financial performance metrics or comparative market-based returns, generally 50% of the PRSUs are earned based on the average of annual operating cash flow and earnings per share goals established at the beginning of each fiscal year over a three-year performance period. Generally, the remaining 50% of the PRSUs are earned based on the Company’s TSR measured against the benchmark TSR of a peer group over the same period. Each PRSU recipient could vest in 0% to 150% of the target shares granted contingent on the achievement of the Company's financial performance metrics or its comparative market-based returns and 0% to 100% of the target shares granted contingent on the achievement of non-financial operating goals.


## us-gaap:EarningsPerShareTextBlock

[0000858877-16-000090:notes:189]
[same as prior period, unchanged from 0000858877-15-000073:notes:180]

[0000858877-16-000090:notes:190]
[same as prior period, unchanged from 0000858877-15-000073:notes:181]

[0000858877-16-000090:notes:191]
|  | Three Months Ended |  | Six Months Ended |
|  | January 23, 2016 |  | January 24, 2015 |  | January 23, 2016 |  | January 24, 2015 |
| Net income | $ | 3,147 |  |  | $ | 2,397 |  |  | $ | 5,577 |  |  | $ | 4,225 |  |
| Weighted-average shares—basic | 5,070 |  |  | 5,117 |  |  | 5,075 |  |  | 5,115 |  |
| Effect of dilutive potential common shares | 27 |  |  | 43 |  |  | 31 |  |  | 44 |  |
| Weighted-average shares—diluted | 5,097 |  |  | 5,160 |  |  | 5,106 |  |  | 5,159 |  |
| Net income per share—basic | $ | 0.62 |  |  | $ | 0.47 |  |  | $ | 1.10 |  |  | $ | 0.83 |  |
| Net income per share—diluted | $ | 0.62 |  |  | $ | 0.46 |  |  | $ | 1.09 |  |  | $ | 0.82 |  |
| Antidilutive employee share-based awards, excluded | 98 |  |  | 83 |  |  | 133 |  |  | 156 |  |

[0000858877-16-000090:notes:192]
Employee equity share options, unvested shares, and similar equity instruments granted by the Company are treated as potential common shares outstanding in computing diluted earnings per share. Diluted shares outstanding include the dilutive effect of in-the-money options, unvested restricted stock, and restricted stock units. The dilutive effect of such equity awards is calculated based on the average share price for each fiscal period using the treasury stock method. Under the treasury stock method, the amount the employee must pay for exercising stock options, the amount of compensation cost for future service that the Company has not yet recognized, and the amount of tax benefits that would be recorded in additional paid-in capital when the award becomes deductible are collectively assumed to be used to repurchase shares.


## us-gaap:EquityMethodInvestmentsTextBlock

[0000858877-16-000090:notes:193]
For such investments that were accounted for under the equity and cost method as of January 23, 2016 and July 25, 2015, the amounts are summarized in the following table (in millions):

[0000858877-16-000090:notes:194]
|  | January 23, 2016 |  | July 25, 2015 |
| Equity method investments | $ | 605 |  |  | $ | 578 |  |
| Cost method investments | 359 |  |  | 319 |  |
| Total | $ | 964 |  |  | $ | 897 |  |


## us-gaap:FairValueAssetsMeasuredOnNonrecurringBasisTextBlock

[0000858877-16-000090:notes:195]
The following table presents the Company's recognized losses for the indicated periods, for assets that were measured at fair value on a nonrecurring basis (in millions):

[0000858877-16-000090:notes:196]
|  | LOSSES FOR THETHREE MONTHS ENDED |  | LOSSES FOR THESIX MONTHS ENDED |
|  | January 23, 2016 |  | January 24, 2015 |  | January 23, 2016 |  | January 24, 2015 |
| Investments in privately held companies (impaired) | $ | (39 | ) |  | $ | (2 | ) |  | $ | (56 | ) |  | $ | (3 | ) |
| Purchased intangible assets (impaired) | (37 | ) |  | (56 | ) |  | (37 | ) |  | (56 | ) |
| Total | $ | (76 | ) |  | $ | (58 | ) |  | $ | (93 | ) |  | $ | (59 | ) |


## us-gaap:FairValueDisclosuresTextBlock

[0000858877-16-000090:notes:197]
[same as prior period, unchanged from 0000858877-15-000073:notes:188]

[0000858877-16-000090:notes:198]
Fair value is defined as the price that would be received from selling an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. When determining the fair value measurements for assets and liabilities required or permitted to be either recorded or disclosed at fair value, the Company considers the principal or most advantageous market in which it would transact, and it also considers assumptions that market participants would use when pricing the asset or liability.

[0000858877-16-000090:notes:199]
[same as prior period, unchanged from 0000858877-15-000073:notes:190]

[0000858877-16-000090:notes:200]
The accounting guidance for fair value measurement requires an entity to maximize the use of observable inputs and minimize the use of unobservable inputs when measuring fair value. The standard establishes a fair value hierarchy based on the level of independent, objective evidence surrounding the inputs used to measure fair value. A financial instrument’s categorization within the fair value hierarchy is based upon the lowest level of input that is significant to the fair value measurement. The fair value hierarchy is as follows:

[0000858877-16-000090:notes:201]
[same as prior period, unchanged from 0000858877-15-000073:notes:192]

[0000858877-16-000090:notes:202]
[same as prior period, unchanged from 0000858877-15-000073:notes:193]

[0000858877-16-000090:notes:203]
[same as prior period, unchanged from 0000858877-15-000073:notes:194]

[0000858877-16-000090:notes:204]
[same as prior period, unchanged from 0000858877-15-000073:notes:195]

[0000858877-16-000090:notes:205]
Assets and liabilities measured at fair value on a recurring basis as of January 23, 2016 and July 25, 2015 were as follows (in millions):

[0000858877-16-000090:notes:206]
|  | JANUARY 23, 2016FAIR VALUE MEASUREMENTS |  | JULY 25, 2015FAIR VALUE MEASUREMENTS |
|  | Level 1 |  | Level 2 |  | Level 3 |  | TotalBalance |  | Level 1 |  | Level 2 |  | Level 3 |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 4,731 |  |  | $ | — |  |  | $ | — |  |  | $ | 4,731 |  |  | $ | 5,336 |  |  | $ | — |  |  | $ | — |  |  | $ | 5,336 |  |
| Corporate debt securities | — |  |  | 9 |  |  | — |  |  | 9 |  |  | — |  |  | 14 |  |  | — |  |  | 14 |  |
| U.S. government securities | — |  |  | 31 |  |  | — |  |  | 31 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Available-for-sale investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | — |  |  | 28,244 |  |  | — |  |  | 28,244 |  |  | — |  |  | 29,939 |  |  | — |  |  | 29,939 |  |
| U.S. government agency securities | — |  |  | 3,493 |  |  | — |  |  | 3,493 |  |  | — |  |  | 3,663 |  |  | — |  |  | 3,663 |  |
| Non-U.S. government and agency securities | — |  |  | 1,152 |  |  | — |  |  | 1,152 |  |  | — |  |  | 1,128 |  |  | — |  |  | 1,128 |  |
| Corporate debt securities | — |  |  | 18,281 |  |  | — |  |  | 18,281 |  |  | — |  |  | 15,783 |  |  | — |  |  | 15,783 |  |
| U.S. agency mortgage-backed securities | — |  |  | 1,460 |  |  | — |  |  | 1,460 |  |  | — |  |  | 1,461 |  |  | — |  |  | 1,461 |  |
| Publicly traded equity securities | 1,431 |  |  | — |  |  | — |  |  | 1,431 |  |  | 1,565 |  |  | — |  |  | — |  |  | 1,565 |  |
| Derivative assets | — |  |  | 318 |  |  | 3 |  |  | 321 |  |  | — |  |  | 214 |  |  | 4 |  |  | 218 |  |
| Total | $ | 6,162 |  |  | $ | 52,988 |  |  | $ | 3 |  |  | $ | 59,153 |  |  | $ | 6,901 |  |  | $ | 52,202 |  |  | $ | 4 |  |  | $ | 59,107 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities | $ | — |  |  | $ | 19 |  |  | $ | — |  |  | $ | 19 |  |  | $ | — |  |  | $ | 12 |  |  | $ | — |  |  | $ | 12 |  |
| Total | $ | — |  |  | $ | 19 |  |  | $ | — |  |  | $ | 19 |  |  | $ | — |  |  | $ | 12 |  |  | $ | — |  |  | $ | 12 |  |

[0000858877-16-000090:notes:207]
Level 1 publicly traded equity securities are determined by using quoted prices in active markets for identical assets. Level 2 fixed income securities are priced using quoted market prices for similar instruments or nonbinding market prices that are corroborated by observable market data. The Company uses inputs such as actual trade data, benchmark yields, broker/dealer quotes, and other similar data, which are obtained from quoted market prices, independent pricing vendors, or other sources, to determine the ultimate fair value of these assets and liabilities. The Company uses such pricing data as the primary input to make its assessments and determinations as to the ultimate valuation of its investment portfolio and has not made, during the periods presented, any material adjustments to such inputs. The Company is ultimately responsible for the financial statements and underlying estimates. The Company’s derivative instruments are primarily classified as Level 2, as they are not actively traded and are valued using pricing models that use observable market inputs. The Company did not have any transfers between Level 1 and Level 2 fair value measurements during the periods presented.

[0000858877-16-000090:notes:208]
[same as prior period, unchanged from 0000858877-15-000073:notes:199]

[0000858877-16-000090:notes:209]
[same as prior period, unchanged from 0000858877-15-000073:notes:200]

[0000858877-16-000090:notes:210]
These assets were measured at fair value due to events or circumstances the Company identified as having significant impact on their fair value during the respective periods. To arrive at the valuation of these assets, the Company considers any significant changes in the financial metrics and economic variables and also uses third-party valuation reports to assist in the valuation as necessary.

[0000858877-16-000090:notes:211]
The fair value measurement of the impaired investments was classified as Level 3 because significant unobservable inputs were used in the valuation due to the absence of quoted market prices and inherent lack of liquidity. Significant unobservable inputs, which included financial metrics of comparable private and public companies, financial condition and near-term prospects of the investees, recent financing activities of the investees, and the investees’ capital structure as well as other economic variables, reflected the assumptions market participants would use in pricing these assets. The impairment charges, representing the difference between the net book value and the fair value as a result of the evaluation, were recorded to other income (loss), net. The remaining carrying value of the investments that were impaired was $11 million and $1 million as of January 23, 2016 and January 24, 2015, respectively.

[0000858877-16-000090:notes:212]
The fair value for purchased intangibles for which the carrying amount was not deemed to be recoverable was determined using the future discounted cash flows that the assets are expected to generate. The difference between the estimated fair value and the carrying value of the assets was recorded as an impairment charge, which was included in product cost of sales and operating expenses as applicable. See Note 4. The remaining carrying value of the specific purchased intangible assets that were impaired was zero and $5 million as of January 23, 2016 and January 24, 2015, respectively.

[0000858877-16-000090:notes:213]
[same as prior period, unchanged from 0000858877-15-000073:notes:203]

[0000858877-16-000090:notes:214]
The carrying value of the Company’s investments in privately held companies that were accounted for under the cost method was $359 million and $319 million as of January 23, 2016 and July 25, 2015, respectively. It was not practicable to estimate the fair value of this portfolio.

[0000858877-16-000090:notes:215]
The fair value of the Company’s short-term loan receivables and financed service contracts approximates their carrying value due to their short duration. The aggregate carrying value of the Company’s long-term loan receivables and financed service contracts and other as of January 23, 2016 and July 25, 2015 was $2.4 billion and $2.2 billion, respectively. The estimated fair value of the Company’s long-term loan receivables and financed service contracts and other approximates their carrying value. The Company uses significant unobservable inputs in determining discounted cash flows to estimate the fair value of its long-term loan receivables and financed service contracts, and therefore they are categorized as Level 3.

[0000858877-16-000090:notes:216]
As of January 23, 2016, the estimated fair value of the short-term debt approximates its carrying value due to the short maturities.  As of January 23, 2016, the fair value of the Company’s senior notes and other long-term debt was $25.8 billion with a carrying amount of $24.6 billion. This compares to a fair value of $26.6 billion and a carrying amount of $25.4 billion as of July 25, 2015.  The fair value of the senior notes and other long-term debt was determined based on observable market prices in a less active market and was categorized as Level 2 in the fair value hierarchy.


## us-gaap:FinancingReceivableCreditQualityIndicatorsTableTextBlock

[0000858877-16-000090:notes:217]
Gross receivables, excluding residual value, less unearned income categorized by the Company’s internal credit risk rating as of January 23, 2016 and July 25, 2015 are summarized as follows (in millions):

[0000858877-16-000090:notes:218]
|  | INTERNAL CREDIT RISK RATING |
| January 23, 2016 | 1 to 4 |  | 5 to 6 |  | 7 and Higher |  | Total |
| Lease receivables | $ | 1,640 |  |  | $ | 1,245 |  |  | $ | 114 |  |  | $ | 2,999 |  |
| Loan receivables | 1,224 |  |  | 811 |  |  | 142 |  |  | 2,177 |  |
| Financed service contracts and other | 2,156 |  |  | 1,204 |  |  | 45 |  |  | 3,405 |  |
| Total | $ | 5,020 |  |  | $ | 3,260 |  |  | $ | 301 |  |  | $ | 8,581 |  |

[0000858877-16-000090:notes:219]
[same as prior period, unchanged from 0000858877-15-000073:notes:209]


## us-gaap:FinancingReceivablesTextBlock

[0000858877-16-000090:notes:220]
[same as prior period, unchanged from 0000858877-15-000073:notes:210]

[0000858877-16-000090:notes:221]
[same as prior period, unchanged from 0000858877-15-000073:notes:211]

[0000858877-16-000090:notes:222]
Financing receivables primarily consist of lease receivables, loan receivables, and financed service contracts and other. Lease receivables represent sales-type and direct-financing leases resulting from the sale of the Company’s and complementary third-party products and are typically collateralized by a security interest in the underlying assets. Loan receivables represent financing arrangements related to the sale of the Company’s products and services, which may include additional funding for other costs associated with network installation and integration of the Company’s products and services. Lease receivables consist of arrangements with terms of four years on average, while loan receivables generally have terms of up to three years. The financed service contracts and other category includes financing receivables related to technical support and advanced services, as well as receivables related to financing of certain indirect costs associated with leases. Revenue related to the technical support services is typically deferred and included in deferred service revenue and is recognized ratably over the period during which the related services are to be performed, which typically ranges from one to three years.

[0000858877-16-000090:notes:223]
[same as prior period, unchanged from 0000858877-15-000073:notes:213]

[0000858877-16-000090:notes:224]
| January 23, 2016 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts and Other |  | Total |
| Gross | $ | 3,176 |  |  | $ | 2,177 |  |  | $ | 3,405 |  |  | $ | 8,758 |  |
| Residual value | 201 |  |  | — |  |  | — |  |  | 201 |  |
| Unearned income | (177 | ) |  | — |  |  | — |  |  | (177 | ) |
| Allowance for credit loss | (248 | ) |  | (80 | ) |  | (37 | ) |  | (365 | ) |
| Total, net | $ | 2,952 |  |  | $ | 2,097 |  |  | $ | 3,368 |  |  | $ | 8,417 |  |
| Reported as: |  |  |  |  |  |  |  |
| Current | $ | 1,460 |  |  | $ | 978 |  |  | $ | 2,076 |  |  | $ | 4,514 |  |
| Noncurrent | 1,492 |  |  | 1,119 |  |  | 1,292 |  |  | 3,903 |  |
| Total, net | $ | 2,952 |  |  | $ | 2,097 |  |  | $ | 3,368 |  |  | $ | 8,417 |  |

[0000858877-16-000090:notes:225]
[same as prior period, unchanged from 0000858877-15-000073:notes:215]

[0000858877-16-000090:notes:226]
As of January 23, 2016 and July 25, 2015, the deferred service revenue related to "Financed Service Contracts and Other" was $1,714 million and $1,853 million, respectively.

[0000858877-16-000090:notes:227]
Future minimum lease payments at January 23, 2016 are summarized as follows (in millions):

[0000858877-16-000090:notes:228]
| Fiscal Year | Amount |
| 2016 (remaining six months) | $ | 822 |  |
| 2017 | 1,234 |  |
| 2018 | 693 |  |
| 2019 | 316 |  |
| 2020 | 104 |  |
| Thereafter | 7 |  |
| Total | $ | 3,176 |  |

[0000858877-16-000090:notes:229]
[same as prior period, unchanged from 0000858877-15-000073:notes:219]

[0000858877-16-000090:notes:230]
[same as prior period, unchanged from 0000858877-15-000073:notes:220]

[0000858877-16-000090:notes:231]
The Company determines the adequacy of its allowance for credit loss by assessing the risks and losses inherent in its financing receivables by portfolio segment. The portfolio segment is based on the types of financing offered by the Company to its customers, which consist of the following: lease receivables, loan receivables, and financed service contracts and other.

[0000858877-16-000090:notes:232]
The Company’s internal credit risk ratings of 1 through 4 correspond to investment-grade ratings, while credit risk ratings of 5 and 6 correspond to non-investment grade ratings. Credit risk ratings of 7 and higher correspond to substandard ratings.

[0000858877-16-000090:notes:233]
In circumstances when collectibility is not deemed reasonably assured, the associated revenue is deferred in accordance with the Company’s revenue recognition policies, and the related allowance for credit loss, if any, is included in deferred revenue. The Company also records deferred revenue associated with financing receivables when there are remaining performance obligations, as it does for financed service contracts. Total allowances for credit loss and deferred revenue as of January 23, 2016 and July 25, 2015 were $2,097 million and $2,253 million, respectively, and they were associated with total financing receivables before allowance for credit loss of $8,782 million and $8,731 million as of their respective period ends.

[0000858877-16-000090:notes:234]
The following tables present the aging analysis of gross receivables, excluding residual value and less unearned income as of January 23, 2016 and July 25, 2015 (in millions):

[0000858877-16-000090:notes:235]
|  | DAYS PAST DUE (INCLUDES BILLED AND UNBILLED) |  |  |  |  |  |  |  |  |
| January 23, 2016 | 31-60 |  | 61-90 |  | 91+ |  | TotalPast Due |  | Current |  | Total |  | NonaccrualFinancingReceivables |  | ImpairedFinancingReceivables |
| Lease receivables | $ | 93 |  |  | $ | 41 |  |  | $ | 176 |  |  | $ | 310 |  |  | $ | 2,689 |  |  | $ | 2,999 |  |  | $ | 71 |  |  | $ | 64 |  |
| Loan receivables | 91 |  |  | 40 |  |  | 48 |  |  | 179 |  |  | 1,998 |  |  | 2,177 |  |  | 43 |  |  | 43 |  |
| Financed service contracts and other | 245 |  |  | 45 |  |  | 171 |  |  | 461 |  |  | 2,944 |  |  | 3,405 |  |  | 29 |  |  | 9 |  |
| Total | $ | 429 |  |  | $ | 126 |  |  | $ | 395 |  |  | $ | 950 |  |  | $ | 7,631 |  |  | $ | 8,581 |  |  | $ | 143 |  |  | $ | 116 |  |

[0000858877-16-000090:notes:236]
[same as prior period, unchanged from 0000858877-15-000073:notes:226]

[0000858877-16-000090:notes:237]
Past due financing receivables are those that are 31 days or more past due according to their contractual payment terms.  The data in the preceding tables is presented by contract, and the aging classification of each contract is based on the oldest outstanding receivable, and therefore past due amounts also include unbilled and current receivables within the same contract.  The balances of either unbilled or current financing receivables included in the category of 91 days plus past due for financing receivables were $177 million and $496 million as of January 23, 2016 and July 25, 2015, respectively.

[0000858877-16-000090:notes:238]
As of January 23, 2016, the Company had financing receivables of $187 million, net of unbilled or current receivables from the same contract, that were in the category of 91 days plus past due but remained on accrual status as they are well-secured and in the process of collection. Such balance was $70 million as of July 25, 2015.

[0000858877-16-000090:notes:239]
[same as prior period, unchanged from 0000858877-15-000073:notes:229]

[0000858877-16-000090:notes:240]
The Company assesses the allowance for credit loss related to financing receivables on either an individual or a collective basis.  The Company considers various factors in evaluating lease and loan receivables and the earned portion of financed service contracts for possible impairment on an individual basis. These factors include the Company’s historical experience, credit quality and age of the receivable balances, and economic conditions that may affect a customer’s ability to pay. When the evaluation indicates that it is probable that all amounts due pursuant to the contractual terms of the financing agreement, including scheduled interest payments, are unable to be collected, the financing receivable is considered impaired. All such outstanding amounts, including any accrued interest, will be assessed and fully reserved at the customer level. The Company’s internal credit risk ratings are categorized as 1 through 10, with the lowest credit risk rating representing the highest quality financing receivables.

[0000858877-16-000090:notes:241]
Typically, the Company also considers receivables with a risk rating of 8 or higher to be impaired and will include them in the individual assessment for allowance. These balances, as of January 23, 2016 and July 25, 2015, are presented under “(b) Credit Quality of Financing Receivables” above.

[0000858877-16-000090:notes:242]
The Company evaluates the remainder of its financing receivables portfolio for impairment on a collective basis and records an allowance for credit loss at the portfolio segment level. When evaluating the financing receivables on a collective basis, the Company uses expected default frequency rates published by a major third-party credit-rating agency as well as its own historical loss rate in the event of default, while also systematically giving effect to economic conditions, concentration of risk, and correlation.

[0000858877-16-000090:notes:243]
[same as prior period, unchanged from 0000858877-15-000073:notes:233]

[0000858877-16-000090:notes:244]
The Company provides financing of certain equipment through operating leases, and the amounts are included in property and equipment in the Consolidated Balance Sheets. Amounts relating to equipment on operating lease assets and the associated accumulated depreciation are summarized as follows (in millions):

[0000858877-16-000090:notes:245]
|  | January 23, 2016 |  | July 25, 2015 |
| Operating lease assets | $ | 324 |  |  | $ | 372 |  |
| Accumulated depreciation | (181 | ) |  | (205 | ) |
| Operating lease assets, net | $ | 143 |  |  | $ | 167 |  |

[0000858877-16-000090:notes:246]
Minimum future rentals on noncancelable operating leases at January 23, 2016 were approximately $0.1 billion for the remaining six months of fiscal 2016, $0.1 billion for fiscal 2017, and less than $0.1 billion per year for each of fiscal 2018 through fiscal 2020.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000858877-16-000090:notes:247]
[same as prior period, unchanged from 0000858877-15-000073:notes:237]

[0000858877-16-000090:notes:248]
[same as prior period, unchanged from 0000858877-15-000073:notes:238]

[0000858877-16-000090:notes:249]
The following table presents the goodwill allocated to the Company’s reportable segments as of and during the six months ended January 23, 2016 (in millions):

[0000858877-16-000090:notes:250]
|  | Balance at |  |  |  |  |  |  |  | Balance at |
|  | July 25, 2015 |  | Acquisitions |  | Divestiture |  | Other |  | January 23, 2016 |
| Americas | $ | 15,212 |  |  | $ | 672 |  |  | $ | (126 | ) |  | $ | (194 | ) |  | $ | 15,564 |  |
| EMEA | 5,791 |  |  | 195 |  |  | (12 | ) |  | (73 | ) |  | 5,901 |  |
| APJC | 3,466 |  |  | 73 |  |  | (3 | ) |  | (43 | ) |  | 3,493 |  |
| Total | $ | 24,469 |  |  | $ | 940 |  |  | $ | (141 | ) |  | $ | (310 | ) |  | $ | 24,958 |  |

[0000858877-16-000090:notes:251]
[same as prior period, unchanged from 0000858877-15-000073:notes:241]

[0000858877-16-000090:notes:252]
[same as prior period, unchanged from 0000858877-15-000073:notes:242]

[0000858877-16-000090:notes:253]
[same as prior period, unchanged from 0000858877-15-000073:notes:243]

[0000858877-16-000090:notes:254]
Impairment charges related to purchased intangible assets for the three and six months ended January 23, 2016 and January 24, 2015 were approximately $37 million and $56 million, respectively.

[0000858877-16-000090:notes:255]
The estimated future amortization expense of purchased intangible assets with finite lives as of January 23, 2016 is as follows (in millions):

[0000858877-16-000090:notes:256]
| Fiscal Year | Amount |
| 2016 (remaining six months) | $ | 386 |  |
| 2017 | 663 |  |
| 2018 | 519 |  |
| 2019 | 435 |  |
| 2020 | 209 |  |
| Thereafter | 75 |  |
| Total | $ | 2,287 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000858877-16-000090:notes:257]
[same as prior period, unchanged from 0000858877-15-000073:notes:247]

[0000858877-16-000090:notes:258]
As discussed further below, the effective tax rate for the three and six months ended January 23, 2016 reflected the Company's recognition of total benefits of approximately $523 million related to a tax settlement with the Internal Revenue Service ("IRS") and the reinstatement of the U.S. federal research and development ("R&D") tax credit on December 18, 2015.

[0000858877-16-000090:notes:259]
In the second quarter of fiscal 2016, the Protecting Americans from Tax Hikes Act of 2015 reinstated the U.S. federal R&D tax credit permanently.  As a result, the effective tax rate for the three and six months ended January 23, 2016 reflected a tax benefit of $72 million related to fiscal 2016 R&D expenses and a tax benefit of $84 million related to fiscal 2015 R&D expenses.

[0000858877-16-000090:notes:260]
In the second quarter of fiscal 2016, the IRS and the Company settled all outstanding items related to the audit of the Company's federal income tax returns for the fiscal years ended July 26, 2008 through July 31, 2010.  As a result of the settlement, the Company recognized a net benefit to the provision for income taxes of $367 million, which included a reduction in interest expense of $21 million.  The Company is no longer subject to U.S. federal income tax audit through fiscal 2010.

[0000858877-16-000090:notes:261]
As a result of the IRS tax settlement, the amount of gross unrecognized tax benefits was reduced in the second quarter of fiscal 2016 by approximately $563 million, of which $188 million became certain as a result of completing the audit. As of January 23, 2016, the Company had $1.6 billion of unrecognized tax benefits, of which $1.3 billion, if recognized, would favorably impact the effective tax rate. The Company regularly engages in discussions and negotiations with tax authorities regarding tax matters in various jurisdictions. The Company believes it is reasonably possible that certain foreign and state tax matters may be concluded in the next 12 months. Specific positions that may be resolved include issues involving transfer pricing and various other matters.  The Company estimates that the unrecognized tax benefits at January 23, 2016 could be reduced by approximately $200 million in the next 12 months.


## us-gaap:InventoryDisclosureTextBlock

[0000858877-16-000090:notes:262]
[same as prior period, unchanged from 0000858877-15-000073:notes:249]

[0000858877-16-000090:notes:263]
|  |  | January 23, 2016 |  | July 25, 2015 |
| Inventories: |  |  |  |  |
| Raw materials |  | $ | 99 |  |  | $ | 114 |  |
| Work in process |  | 1 |  |  | 2 |  |
| Finished goods: |  |  |  |  |
| Distributor inventory and deferred cost of sales |  | 564 |  |  | 610 |  |
| Manufactured finished goods |  | 446 |  |  | 593 |  |
| Total finished goods |  | 1,010 |  |  | 1,203 |  |
| Service-related spares |  | 224 |  |  | 258 |  |
| Demonstration systems |  | 28 |  |  | 50 |  |
| Total |  | $ | 1,362 |  |  | $ | 1,627 |  |


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0000858877-16-000090:notes:264]
The following table summarizes the maturities of the Company’s fixed income securities at January 23, 2016 (in millions):

[0000858877-16-000090:notes:265]
|  | Amortized Cost |  | Fair Value |
| Less than 1 year | $ | 17,569 |  |  | $ | 17,555 |  |
| Due in 1 to 2 years | 16,105 |  |  | 16,081 |  |
| Due in 2 to 5 years | 17,423 |  |  | 17,345 |  |
| Due after 5 years | 1,651 |  |  | 1,649 |  |
| Total | $ | 52,748 |  |  | $ | 52,630 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000858877-16-000090:notes:266]
| 8. | Investments |

[0000858877-16-000090:notes:267]
| (a) | Summary of Available-for-Sale Investments |

[0000858877-16-000090:notes:268]
The following tables summarize the Company’s available-for-sale investments (in millions):

[0000858877-16-000090:notes:269]
| January 23, 2016 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| Fixed income securities: |  |  |  |  |  |  |  |
| U.S. government securities | $ | 28,242 |  |  | $ | 18 |  |  | $ | (16 | ) |  | $ | 28,244 |  |
| U.S. government agency securities | 3,492 |  |  | 3 |  |  | (2 | ) |  | 3,493 |  |
| Non-U.S. government and agency securities | 1,152 |  |  | 1 |  |  | (1 | ) |  | 1,152 |  |
| Corporate debt securities | 18,410 |  |  | 29 |  |  | (158 | ) |  | 18,281 |  |
| U.S. agency mortgage-backed securities | 1,452 |  |  | 9 |  |  | (1 | ) |  | 1,460 |  |
| Total fixed income securities | 52,748 |  |  | 60 |  |  | (178 | ) |  | 52,630 |  |
| Publicly traded equity securities | 1,318 |  |  | 176 |  |  | (63 | ) |  | 1,431 |  |
| Total | $ | 54,066 |  |  | $ | 236 |  |  | $ | (241 | ) |  | $ | 54,061 |  |

[0000858877-16-000090:notes:270]
| July 25, 2015 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| Fixed income securities: |  |  |  |  |  |  |  |
| U.S. government securities | $ | 29,904 |  |  | $ | 41 |  |  | $ | (6 | ) |  | $ | 29,939 |  |
| U.S. government agency securities | 3,662 |  |  | 2 |  |  | (1 | ) |  | 3,663 |  |
| Non-U.S. government and agency securities | 1,128 |  |  | 1 |  |  | (1 | ) |  | 1,128 |  |
| Corporate debt securities | 15,802 |  |  | 34 |  |  | (53 | ) |  | 15,783 |  |
| U.S. agency mortgage-backed securities | 1,456 |  |  | 8 |  |  | (3 | ) |  | 1,461 |  |
| Total fixed income securities | 51,952 |  |  | 86 |  |  | (64 | ) |  | 51,974 |  |
| Publicly traded equity securities | 1,092 |  |  | 480 |  |  | (7 | ) |  | 1,565 |  |
| Total | $ | 53,044 |  |  | $ | 566 |  |  | $ | (71 | ) |  | $ | 53,539 |  |

[0000858877-16-000090:notes:271]
Non-U.S. government and agency securities include agency and corporate debt securities that are guaranteed by non-U.S. governments.

[0000858877-16-000090:notes:272]
| (b) | Gains and Losses on Available-for-Sale Investments |

[0000858877-16-000090:notes:273]
The following table presents the gross realized gains and gross realized losses related to the Company’s available-for-sale investments (in millions):

[0000858877-16-000090:notes:274]
|  | Three Months Ended |  | Six Months Ended |
|  | January 23, 2016 |  | January 24, 2015 |  | January 23, 2016 |  | January 24, 2015 |
| Gross realized gains | $ | 16 |  |  | $ | 92 |  |  | $ | 51 |  |  | $ | 113 |  |
| Gross realized losses | (35 | ) |  | (23 | ) |  | (71 | ) |  | (37 | ) |
| Total | $ | (19 | ) |  | $ | 69 |  |  | $ | (20 | ) |  | $ | 76 |  |

[0000858877-16-000090:notes:275]
The following table presents the realized net gains (losses) related to the Company’s available-for-sale investments by security type (in millions):

[0000858877-16-000090:notes:276]
|  | Three Months Ended |  | Six Months Ended |
|  | January 23, 2016 |  | January 24, 2015 |  | January 23, 2016 |  | January 24, 2015 |
| Net gains/(losses) on investments in publicly traded equity securities | $ | 2 |  |  | $ | 60 |  |  | $ | (7 | ) |  | $ | 56 |  |
| Net gains/(losses) on investments in fixed income securities | (21 | ) |  | 9 |  |  | (13 | ) |  | 20 |  |
| Total | $ | (19 | ) |  | $ | 69 |  |  | $ | (20 | ) |  | $ | 76 |  |

[0000858877-16-000090:notes:277]
For the three and six months ended January 23, 2016, the realized net losses related to the Company's available-for-sale investments included impairment charges of $3 million for fixed income securities, due to a decline in the fair value of those securities below their cost basis that were determined to be other than temporary. There were no impairment charges on available-for-sale investments for the corresponding periods in fiscal 2015.

[0000858877-16-000090:notes:278]
The following tables present the breakdown of the available-for-sale investments with gross unrealized losses and the duration that those losses had been unrealized at January 23, 2016 and July 25, 2015 (in millions):

[0000858877-16-000090:notes:279]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| January 23, 2016 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| Fixed income securities: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | $ | 15,432 |  |  | $ | (16 | ) |  | $ | 3 |  |  | $ | — |  |  | $ | 15,435 |  |  | $ | (16 | ) |
| U.S. government agency securities | 1,793 |  |  | (2 | ) |  | — |  |  | — |  |  | 1,793 |  |  | (2 | ) |
| Non-U.S. government and agency securities | 645 |  |  | (1 | ) |  | 17 |  |  | — |  |  | 662 |  |  | (1 | ) |
| Corporate debt securities | 11,565 |  |  | (136 | ) |  | 1,252 |  |  | (22 | ) |  | 12,817 |  |  | (158 | ) |
| U.S. agency mortgage-backed securities | 387 |  |  | (1 | ) |  | — |  |  | — |  |  | 387 |  |  | (1 | ) |
| Total fixed income securities | 29,822 |  |  | (156 | ) |  | 1,272 |  |  | (22 | ) |  | 31,094 |  |  | (178 | ) |
| Publicly traded equity securities | 694 |  |  | (62 | ) |  | 2 |  |  | (1 | ) |  | 696 |  |  | (63 | ) |
| Total | $ | 30,516 |  |  | $ | (218 | ) |  | $ | 1,274 |  |  | $ | (23 | ) |  | $ | 31,790 |  |  | $ | (241 | ) |

[0000858877-16-000090:notes:280]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 25, 2015 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| Fixed income securities: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | $ | 6,412 |  |  | $ | (6 | ) |  | $ | — |  |  | $ | — |  |  | $ | 6,412 |  |  | $ | (6 | ) |
| U.S. government agency securities | 1,433 |  |  | (1 | ) |  | — |  |  | — |  |  | 1,433 |  |  | (1 | ) |
| Non-U.S. government and agency securities | 515 |  |  | (1 | ) |  | 4 |  |  | — |  |  | 519 |  |  | (1 | ) |
| Corporate debt securities | 9,552 |  |  | (49 | ) |  | 312 |  |  | (4 | ) |  | 9,864 |  |  | (53 | ) |
| U.S. agency mortgage-backed securities | 579 |  |  | (3 | ) |  | — |  |  | — |  |  | 579 |  |  | (3 | ) |
| Total fixed income securities | 18,491 |  |  | (60 | ) |  | 316 |  |  | (4 | ) |  | 18,807 |  |  | (64 | ) |
| Publicly traded equity securities | 108 |  |  | (7 | ) |  | 2 |  |  | — |  |  | 110 |  |  | (7 | ) |
| Total | $ | 18,599 |  |  | $ | (67 | ) |  | $ | 318 |  |  | $ | (4 | ) |  | $ | 18,917 |  |  | $ | (71 | ) |

[0000858877-16-000090:notes:281]
As of January 23, 2016, for fixed income securities that were in unrealized loss positions, the Company has determined that (i) it does not have the intent to sell any of these investments and (ii) it is not more likely than not that it will be required to sell any of these investments before recovery of the entire amortized cost basis. In addition, as of January 23, 2016, the Company anticipates that it will recover the entire amortized cost basis of such fixed income securities and has determined that no other-than-temporary impairments associated with credit losses were required to be recognized during the six months ended January 23, 2016.

[0000858877-16-000090:notes:282]
The Company has evaluated its publicly traded equity securities as of January 23, 2016 and has determined that there was no indication of other-than-temporary impairments in the respective categories of unrealized losses. This determination was based on several factors, which include the length of time and extent to which fair value has been less than the cost basis, the financial condition and near-term prospects of the issuer, and the Company’s intent and ability to hold the publicly traded equity securities for a period of time sufficient to allow for any anticipated recovery in market value.

[0000858877-16-000090:notes:283]
| (c) | Maturities of Fixed Income Securities |

[0000858877-16-000090:notes:284]
Actual maturities may differ from the contractual maturities because borrowers may have the right to call or prepay certain obligations.  The remaining contractual principal maturities for mortgage-backed securities were allocated assuming no prepayments.

[0000858877-16-000090:notes:285]
| (d) | Securities Lending |

[0000858877-16-000090:notes:286]
The Company periodically engages in securities lending activities with certain of its available for sale investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. The average daily balance of securities lending for each of the six months ended January 23, 2016 and January 24, 2015 was $0.6 billion. The Company requires collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. The Company engages in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify the Company against collateral losses. The Company did not experience any losses in connection with the secured lending of securities during the periods presented. As of January 23, 2016 and July 25, 2015, the Company had no outstanding securities lending transactions.

[0000858877-16-000090:notes:287]
| (e) | Investments in Privately Held Companies |

[0000858877-16-000090:notes:288]
The carrying value of the Company’s investments in privately held companies was included in other assets.  For such investments that were accounted for under the equity and cost method as of January 23, 2016 and July 25, 2015, the amounts are summarized in the following table (in millions):

[0000858877-16-000090:notes:289]
For additional information on impairment charges related to investments in privately held companies, see Note 9.

[0000858877-16-000090:notes:290]
Variable Interest Entities  In the ordinary course of business, the Company has investments in privately held companies and provides financing to certain customers. These privately held companies and customers may be considered to be variable interest entities. The Company evaluates on an ongoing basis its investments in these privately held companies and its customer financings and has determined that as of January 23, 2016, except as disclosed herein, there were no variable interest entities required to be consolidated in the Company’s Consolidated Financial Statements.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000858877-16-000090:notes:291]
[same as prior period, unchanged from 0000858877-15-000073:notes:278]

[0000858877-16-000090:notes:292]
The fiscal year for Cisco Systems, Inc. (the “Company” or “Cisco”) is the 52 or 53 weeks ending on the last Saturday in July. Fiscal 2016 is a 53-week fiscal year and fiscal 2015 was a 52-week fiscal year. The Consolidated Financial Statements include the accounts of Cisco and its subsidiaries. All intercompany accounts and transactions have been eliminated. The Company conducts business globally and is primarily managed on a geographic basis in the following three geographic segments: the Americas; Europe, Middle East, and Africa (EMEA); and Asia Pacific, Japan, and China (APJC).

[0000858877-16-000090:notes:293]
The accompanying financial data as of January 23, 2016 and for the three and six months ended January 23, 2016 and January 24, 2015 has been prepared by the Company, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (SEC).  Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (GAAP) have been condensed or omitted pursuant to such rules and regulations.  The July 25, 2015 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, the Company believes that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended July 25, 2015.

[0000858877-16-000090:notes:294]
The Company consolidates its investments in a venture fund managed by SOFTBANK Corp. and its affiliates (“SOFTBANK”) as this is a variable interest entity and the Company is the primary beneficiary. The noncontrolling interests attributed to SOFTBANK are presented as a separate component from the Company’s equity in the equity section of the Consolidated Balance Sheets. SOFTBANK’s share of the earnings in the venture fund are not presented separately in the Consolidated Statements of Operations as these amounts are not material for any of the fiscal periods presented.

[0000858877-16-000090:notes:295]
In the opinion of management, all normal recurring adjustments necessary to present fairly the consolidated balance sheet as of January 23, 2016; the results of operations and the statements of comprehensive income for the three and six months ended January 23, 2016 and January 24, 2015; and the statements of cash flows and equity for the six months ended January 23, 2016 and January 24, 2015, as applicable, have been made. The results of operations for the three and six months ended January 23, 2016 are not necessarily indicative of the operating results for the full fiscal year or any future periods.

[0000858877-16-000090:notes:296]
Certain reclassifications have been made to the amounts in prior periods in order to conform to the current period’s presentation.  The Company has evaluated subsequent events through the date that the financial statements were issued.


## us-gaap:OtherAssetsDisclosureTextBlock

[0000858877-16-000090:notes:297]
| Other assets: |  |  |  |  |
| Deferred tax assets |  | $ | 1,371 |  |  | $ | 1,648 |  |
| Investments in privately held companies |  | 964 |  |  | 897 |  |
| Other |  | 733 |  |  | 618 |  |
| Total |  | $ | 3,068 |  |  | $ | 3,163 |  |


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0000858877-16-000090:notes:298]
| Property and equipment, net: |  |  |  |  |
| Gross property and equipment: |  |  |  |  |
| Land, buildings, and building and leasehold improvements |  | $ | 4,573 |  |  | $ | 4,495 |  |
| Computer equipment and related software |  | 1,344 |  |  | 1,310 |  |
| Production, engineering, and other equipment |  | 5,640 |  |  | 5,753 |  |
| Operating lease assets |  | 324 |  |  | 372 |  |
| Furniture and fixtures |  | 501 |  |  | 497 |  |
| Total gross property and equipment |  | 12,382 |  |  | 12,427 |  |
| Less: accumulated depreciation and amortization |  | (8,996 | ) |  | (9,095 | ) |
| Total |  | $ | 3,386 |  |  | $ | 3,332 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000858877-16-000090:notes:299]
[same as prior period, unchanged from 0000858877-15-000073:notes:286]

[0000858877-16-000090:notes:300]
Fiscal 2015 Plan  The Company announced a restructuring action in August 2014 (the "Fiscal 2015 Plan"), in order to realign its workforce towards key growth areas of its business such as data center, software, security, and cloud. The Company's aggregate pre-tax estimated charges pursuant to the restructuring plan are expected to be approximately $750 million, consisting of severance and other one-time termination benefits and other associated costs, and the Company has incurred cumulative charges of approximately $725 million in connection with this plan, which is substantially complete. The Company incurred charges of $95 million, net of a $1 million credit to cost of sales, and $69 million for the three months ended January 23, 2016 and January 24, 2015, respectively, and $236 million, net of a $2 million credit to cost of sales, and $387 million for the six months ended January 23, 2016 and January 24, 2015, respectively.

[0000858877-16-000090:notes:301]
Fiscal 2014 Plan  In connection with a restructuring action announced in August 2013 (the "Fiscal 2014 Plan"), the Company incurred cumulative charges of approximately $418 million. The Company completed the Fiscal 2014 Plan at the end of fiscal 2014.

[0000858877-16-000090:notes:302]
[same as prior period, unchanged from 0000858877-15-000073:notes:289]

[0000858877-16-000090:notes:303]
|  |  | FISCAL 2014 PLAN |  | FISCAL 2015 PLAN |  |  |
|  |  | EmployeeSeverance |  | Other |  | EmployeeSeverance |  | Other |  | Total |
| Liability as of July 25, 2015 |  | $ | 11 |  |  | $ | 14 |  |  | $ | 49 |  |  | $ | 15 |  |  | $ | 89 |  |
| Charges |  | — |  |  | — |  |  | 206 |  |  | 32 |  |  | 238 |  |
| Cash payments |  | (10 | ) |  | (2 | ) |  | (177 | ) |  | (8 | ) |  | (197 | ) |
| Non-cash items |  | — |  |  | — |  |  | — |  |  | (21 | ) |  | (21 | ) |
| Liability as of January 23, 2016 |  | $ | 1 |  |  | $ | 12 |  |  | $ | 78 |  |  | $ | 18 |  |  | $ | 109 |  |


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000858877-16-000090:notes:304]
[same as prior period, unchanged from 0000858877-15-000073:notes:291]


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000858877-16-000090:notes:305]
[same as prior period, unchanged from 0000858877-15-000073:notes:292]

[0000858877-16-000090:notes:306]
[same as prior period, unchanged from 0000858877-15-000073:notes:293]

[0000858877-16-000090:notes:307]
During the six months ended January 23, 2016, the Company declared and paid cash dividends of $0.42 per common share, or $2.1 billion, on the Company’s outstanding common stock. During the six months ended January 24, 2015, the Company declared and paid cash dividends of $0.38 per common share, or $1.9 billion, on the Company’s outstanding common stock.

[0000858877-16-000090:notes:308]
On February 10, 2016, the Company's Board of Directors declared a quarterly dividend of $0.26 per common share to be paid on April 27, 2016 to all shareholders of record as of the close of business on April 6, 2016. Any future dividends will be subject to the approval of the Company's Board of Directors.

[0000858877-16-000090:notes:309]
[same as prior period, unchanged from 0000858877-15-000073:notes:296]

[0000858877-16-000090:notes:310]
In September 2001, the Company’s Board of Directors authorized a stock repurchase program. As of January 23, 2016, the Company’s Board of Directors had authorized an aggregate repurchase of up to $97 billion of common stock under this program.

[0000858877-16-000090:notes:311]
On February 10, 2016, the Company’s Board of Directors authorized a $15 billion increase to the stock repurchase program. The remaining authorized amount for stock repurchases under this program, including the additional authorization, is approximately $16.9 billion, with no termination date. A summary of the stock repurchase activity under the stock repurchase program, reported based on the trade date, is summarized as follows (in millions, except per-share amounts):

[0000858877-16-000090:notes:312]
The purchase price for the shares of the Company’s stock repurchased is reflected as a reduction to shareholders’ equity. The Company is required to allocate the purchase price of the repurchased shares as (i) a reduction to retained earnings and (ii) a reduction of common stock and additional paid-in capital. Issuance of common stock and the tax benefit related to employee stock incentive plans are recorded as an increase to common stock and additional paid-in capital.

[0000858877-16-000090:notes:313]
[same as prior period, unchanged from 0000858877-15-000073:notes:299]

[0000858877-16-000090:notes:314]
For the six months ended January 23, 2016 and January 24, 2015, the Company repurchased approximately 16 million and 15 million shares, or $412 million and $369 million, of common stock, respectively, in settlement of employee tax withholding obligations due upon the vesting of restricted stock or stock units.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000858877-16-000090:notes:315]
[same as prior period, unchanged from 0000858877-15-000073:notes:301]


## us-gaap:TreasuryStockTextBlock

[0000858877-16-000090:notes:316]
[same as prior period, unchanged from 0000858877-15-000073:notes:302]

[0000858877-16-000090:notes:317]
In September 2001, the Company’s Board of Directors authorized a stock repurchase program. As of January 23, 2016, the Company’s Board of Directors had authorized an aggregate repurchase of up to $97 billion of common stock under this program with no termination date. On February 10, 2016, the Company's Board of Directors authorized a $15 billion increase to the stock repurchase program with no termination date. The stock repurchases since the inception of this program and the related impacts on Cisco shareholders’ equity are summarized in the following table (in millions):
