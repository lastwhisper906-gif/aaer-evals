# CSCO note change history — 0000858877-14-000043 → 0000858877-15-000013


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2015-02-18):
[0000858877-15-000013:note_history:1]
The Company leases office space in many U.S. locations. Outside the United States, larger leased sites include sites in Belgium, Canada, China, France, Germany, India, Israel, Japan, Norway, and the United Kingdom.  The Company also leases equipment and vehicles. Future minimum lease payments under all noncancelable operating leases with an initial term in excess of one year as of January 24, 2015 are as follows (in millions):
  (was, 2014-11-20, similarity 0.9835):
[0000858877-14-000043:note_history:1]
The Company leases office space in many U.S. locations. Outside the United States, larger leased sites include sites in Belgium, Canada, China, France, Germany, India, Israel, Japan, Norway, and the United Kingdom.  The Company also leases equipment and vehicles. Future minimum lease payments under all noncancelable operating leases with an initial term in excess of one year as of October 25, 2014 are as follows (in millions):

- changed (2015-02-18):
[0000858877-15-000013:note_history:2]
| Fiscal Year | Amount |
| 2015 (remaining six months) | $ | 195 |  |
| 2016 | 287 |  |
| 2017 | 196 |  |
| 2018 | 139 |  |
| 2019 | 72 |  |
| Thereafter | 209 |  |
| Total | $ | 1,098 |  |
  (was, 2014-11-20, similarity 0.9836):
[0000858877-14-000043:note_history:2]
| Fiscal Year | Amount |
| 2015 (remaining nine months) | $ | 292 |  |
| 2016 | 282 |  |
| 2017 | 185 |  |
| 2018 | 132 |  |
| 2019 | 65 |  |
| Thereafter | 183 |  |
| Total | $ | 1,139 |  |

- changed (2015-02-18):
[0000858877-15-000013:note_history:3]
The Company purchases components from a variety of suppliers and uses several contract manufacturers to provide manufacturing services for its products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, the Company enters into agreements with contract manufacturers and suppliers that allow them to either procure inventory based upon criteria as defined by the Company or establish the parameters defining the Company’s requirements. A significant portion of the Company’s reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. In certain instances, these agreements allow the Company the option to cancel, reschedule, and adjust the Company’s requirements based on its business needs prior to firm orders being placed. As of January 24, 2015 and July 26, 2014, the Company had total purchase commitments for inventory of $4,257 million and $4,169 million, respectively.
  (was, 2014-11-20, similarity 0.993):
[0000858877-14-000043:note_history:3]
The Company purchases components from a variety of suppliers and uses several contract manufacturers to provide manufacturing services for its products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, the Company enters into agreements with contract manufacturers and suppliers that allow them to either procure inventory based upon criteria as defined by the Company or establish the parameters defining the Company’s requirements. A significant portion of the Company’s reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. In certain instances, these agreements allow the Company the option to cancel, reschedule, and adjust the Company’s requirements based on its business needs prior to firm orders being placed. As of October 25, 2014 and July 26, 2014, the Company had total purchase commitments for inventory of $4,299 million and $4,169 million, respectively.

- changed (2015-02-18):
[0000858877-15-000013:note_history:4]
The Company records a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of its future demand forecasts consistent with the valuation of the Company’s excess and obsolete inventory. As of January 24, 2015 and July 26, 2014, the liability for these purchase commitments was $165 million and $162 million, respectively, and was included in other current liabilities.
  (was, 2014-11-20, similarity 0.9597):
[0000858877-14-000043:note_history:4]
The Company records a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of its future demand forecasts consistent with the valuation of the Company’s excess and obsolete inventory. As of October 25, 2014 and July 26, 2014, the liability for these purchase commitments was $169 million and $162 million, respectively, and was included in other current liabilities.

- changed (2015-02-18):
[0000858877-15-000013:note_history:5]
|  | Three Months Ended |  | Six Months Ended |
|  | January 24, 2015 |  | January 25, 2014 |  | January 24, 2015 |  | January 25, 2014 |
| Compensation expense related to acquisitions | $ | 94 |  |  | $ | 106 |  |  | $ | 192 |  |  | $ | 410 |  |
  (was, 2014-11-20, similarity 0.6985):
[0000858877-14-000043:note_history:5]
|  | Three Months Ended |
|  | October 25, 2014 |  | October 26, 2013 |
| Compensation expense related to acquisitions | $ | 98 |  |  | $ | 304 |  |

- changed (2015-02-18):
[0000858877-15-000013:note_history:6]
As of January 24, 2015, the Company estimated that future cash compensation expense of up to $428 million may be required to be recognized pursuant to the applicable business combination agreements, which included the remaining potential compensation expense related to Insieme Networks, Inc., as more fully discussed immediately below.
  (was, 2014-11-20, similarity 0.9787):
[0000858877-14-000043:note_history:6]
As of October 25, 2014, the Company estimated that future cash compensation expense of up to $528 million may be required to be recognized pursuant to the applicable business combination agreements, which included the remaining potential compensation expense related to Insieme Networks, Inc., as more fully discussed immediately below.

- added (2015-02-18):
[0000858877-15-000013:note_history:7]
During the first quarter of fiscal 2014, the Company exercised its call option and entered into an agreement to purchase the remaining interests in Insieme.  The acquisition closed in the second quarter of fiscal 2014, at which time the former noncontrolling interest holders became eligible to receive up to two milestone payments, which will be determined using agreed-upon formulas based primarily on revenue for certain of Insieme’s products.  The Company recorded compensation expense of $51 million and $54 million during the three months ended January 24, 2015 and January 25, 2014, respectively, and $104 million and $311 million during the six months ended January 24, 2015 and January 25, 2014, respectively, related to the fair value of the vested portion of amounts that are expected to be earned by the former noncontrolling interest holders.  Continued vesting and changes to the fair value of the amounts probable of being earned will result in adjustments to the recorded compensation expense in future periods.  Based on the terms of the agreement, the Company has determined that the maximum amount that could be recorded as compensation expense by the Company is approximately $845 million (which includes the $520 million that has been expensed to date), net of forfeitures.  The milestone payments, if earned, are expected to be paid primarily during fiscal 2016 and fiscal 2017.

- changed (2015-02-18):
[0000858877-15-000013:note_history:8]
The Company also has certain funding commitments, primarily related to its investments in privately held companies and venture funds, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $230 million and $255 million as of January 24, 2015 and July 26, 2014, respectively.
  (was, 2014-11-20, similarity 0.9563):
[0000858877-14-000043:note_history:8]
The Company also has certain funding commitments, primarily related to its investments in privately held companies and venture funds, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $252 million and $255 million as of October 25, 2014 and July 26, 2014, respectively.

- changed (2015-02-18):
[0000858877-15-000013:note_history:9]
|  | Six Months Ended |
|  | January 24, 2015 |  | January 25, 2014 |
| Balance at beginning of period | $ | 446 |  |  | $ | 402 |  |
| Provision for warranties issued | 355 |  |  | 356 |  |
| Payments | (327 | ) |  | (333 | ) |
| Balance at end of period | $ | 474 |  |  | $ | 425 |  |
  (was, 2014-11-20, similarity 0.8911):
[0000858877-14-000043:note_history:9]
|  | Three Months Ended |
|  | October 25, 2014 |  | October 26, 2013 |
| Balance at beginning of period | $ | 446 |  |  | $ | 402 |  |
| Provision for warranties issued | 143 |  |  | 196 |  |
| Payments | (153 | ) |  | (169 | ) |
| Balance at end of period | $ | 436 |  |  | $ | 429 |  |

- changed (2015-02-18):
[0000858877-15-000013:note_history:10]
Channel Partner Financing Guarantees   The Company facilitates arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, generally with payment terms ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, the Company guarantees a portion of these arrangements. The volume of channel partner financing was $6.2 billion and $5.9 billion for the three months ended January 24, 2015 and January 25, 2014, respectively. The volume of channel partner financing was $12.5 billion and $12.2 billion for the six months ended January 24, 2015 and January 25, 2014, respectively.  The balance of the channel partner financing subject to guarantees was $1.3 billion and $1.2 billion as of January 24, 2015 and July 26, 2014, respectively.
  (was, 2014-11-20, similarity 0.6945):
[0000858877-14-000043:note_history:10]
Channel Partner Financing Guarantees   The Company facilitates arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, generally with payment terms ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, the Company guarantees a portion of these arrangements. The volume of channel partner financing was $6.3 billion for each of the three months ended October 25, 2014 and October 26, 2013. The balance of the channel partner financing subject to guarantees was $1.3 billion and $1.2 billion as of October 25, 2014 and July 26, 2014, respectively.

- changed (2015-02-18):
[0000858877-15-000013:note_history:11]
End-User Financing Guarantees   The Company also provides financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. The volume of financing provided by third parties for leases and loans as to which the Company had provided guarantees was $39 million and $20 million for the three months ended January 24, 2015 and January 25, 2014, respectively, and was $65 million and $45 million for the six months ended January 24, 2015 and January 25, 2014, respectively.
  (was, 2014-11-20, similarity 0.826):
[0000858877-14-000043:note_history:11]
End-User Financing Guarantees   The Company also provides financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. The volume of financing provided by third parties for leases and loans as to which the Company had provided guarantees was $26 million and $25 million for the three months ended October 25, 2014 and October 26, 2013.

- changed (2015-02-18):
[0000858877-15-000013:note_history:12]
Financing Guarantee Summary   The aggregate amounts of financing guarantees outstanding at January 24, 2015 and July 26, 2014, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):
  (was, 2014-11-20, similarity 0.9776):
[0000858877-14-000043:note_history:12]
Financing Guarantee Summary   The aggregate amounts of financing guarantees outstanding at October 25, 2014 and July 26, 2014, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

- added (2015-02-18):
[0000858877-15-000013:note_history:13]
|  | January 24, 2015 |  | July 26, 2014 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 316 |  |  | $ | 263 |  |
| End user | 155 |  |  | 202 |  |
| Total | $ | 471 |  |  | $ | 465 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (148 | ) |  | $ | (127 | ) |
| End user | (121 | ) |  | (166 | ) |
| Total | $ | (269 | ) |  | $ | (293 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue | $ | 202 |  |  | $ | 172 |  |

- changed (2015-02-18):
[0000858877-15-000013:note_history:14]
Other Guarantees   The Company’s other guarantee arrangements as of January 24, 2015 and July 26, 2014 that were subject to recognition and disclosure requirements were not material.
  (was, 2014-11-20, similarity 0.9647):
[0000858877-14-000043:note_history:14]
Other Guarantees   The Company’s other guarantee arrangements as of October 25, 2014 and July 26, 2014 that were subject to recognition and disclosure requirements were not material.

- changed (2015-02-18):
[0000858877-15-000013:note_history:15]
The Company has recorded in other current liabilities a liability for the expected remediation cost for certain products sold in prior fiscal years containing memory components manufactured by a single supplier between 2005 and 2010. These components are widely used across the industry and are included in a number of the Company's products. Defects in some of these components have caused products to fail after a power cycle event.  Defect rates due to this issue have been and are expected to be low. However, the Company has seen a small number of its customers experience a growing number of failures in their networks as a result of this component problem. Although the majority of these products are beyond the Company's warranty terms, the Company is proactively working with customers on mitigation.  Prior to the second quarter of fiscal 2014, the Company had a liability of $63 million related to this issue for expected remediation costs based on the intended approach at that time. In February 2014, on the basis of the growing number of failures described above, the Company decided to expand its approach, which resulted in an additional charge to product cost of sales of $655 million being recorded for the second quarter of fiscal 2014.  The remaining supplier component remediation liability as of January 24, 2015 and July 26, 2014 was $613 million and $670 million, respectively.
  (was, 2014-11-20, similarity 0.9949):
[0000858877-14-000043:note_history:15]
The Company has recorded in other current liabilities a liability for the expected remediation cost for certain products sold in prior fiscal years containing memory components manufactured by a single supplier between 2005 and 2010. These components are widely used across the industry and are included in a number of the Company's products. Defects in some of these components have caused products to fail after a power cycle event.  Defect rates due to this issue have been and are expected to be low. However, the Company has seen a small number of its customers experience a growing number of failures in their networks as a result of this component problem. Although the majority of these products are beyond the Company's warranty terms, the Company is proactively working with customers on mitigation.  Prior to the second quarter of fiscal 2014, the Company had a liability of $63 million related to this issue for expected remediation costs based on the intended approach at that time. In February 2014, on the basis of the growing number of failures described above, the Company decided to expand its approach, which resulted in an additional charge to product cost of sales of $655 million being recorded for the second quarter of fiscal 2014.  The remaining supplier component remediation liability as of October 25, 2014 and July 26, 2014 was $639 million and $670 million, respectively.

- changed (2015-02-18):
[0000858877-15-000013:note_history:16]
The Company has an obligation to indemnify certain expenses pursuant to such an agreement in, among other cases, a case involving certain of the Company’s service provider customers that are subject to patent infringement claims asserted by Sprint Communications Company, L.P. (“Sprint”) in the U.S. District Court for the District of Kansas filed on December 19, 2011 (including one case that was later transferred to the District of Delaware).  Sprint alleges that the service providers infringe Sprint’s patents by offering Voice over Internet Protocol-based telephone services utilizing products provided by the Company and other manufacturers.  Sprint is seeking monetary damages. Trial dates have been set for the first half of calendar year 2016 in the case proceeding in the District of Kansas. Trial in Delaware is scheduled for February 2017. The parties conducted mediations, and the Company participated through a mediation involving a service provider customer. Those particular mediations did not resolve the parties’ disputes, but the parties plan to engage in additional dispute resolution efforts, including participation by the Company.  The Company believes that the service providers have strong defenses and that its products do not infringe the patents subject to the claims and/or that the patents are invalid.  Due to the uncertainty surrounding the litigation process, which involves numerous defendants, the Company is unable to reasonably estimate the ultimate outcome of this litigation at this time.  Should the plaintiff prevail in litigation, mediation, or settlement, the Company, in accordance with its agreement, may have an obligation to indemnify its service provider customers for damages, mediation awards, or settlement amounts arising from their use of Cisco products.
  (was, 2014-11-20, similarity 0.7174):
[0000858877-14-000043:note_history:16]
The Company has an obligation to indemnify certain expenses pursuant to such agreements in a case involving certain of the Company’s service provider customers that are subject to patent infringement claims asserted by Sprint Communications Company, L.P. (“Sprint”) in the United States District Court for the District of Kansas filed on December 19, 2011 (including one case that was later transferred to the District of Delaware).  Sprint alleges that the service providers infringe Sprint’s patents by offering Voice over Internet Protocol-based telephone services utilizing products provided by the Company and other manufacturers.  Sprint is seeking monetary damages.  Trial dates have been set for the first half of calendar year 2015.  The parties intend to conduct a mediation process later this calendar year, and the Company may be asked to participate.  The mediation could result in a resolution of the case for some or all of the Company's service provider customers.  The Company believes that the service providers have strong defenses and that its products do not infringe the patents subject to the claims.  Due to the uncertainty surrounding the litigation process, which involves numerous defendants, the Company is unable to reasonably estimate the ultimate outcome of this litigation at this time.  Should the plaintiff prevail in litigation, mediation, or settlement, the Company may have an obligation to indemnify its service provider customers for damages, mediation awards, or settlement amounts arising from their use of Cisco products.

- added (2015-02-18):
[0000858877-15-000013:note_history:17]
The asserted claims by Brazilian federal tax authorities are for calendar years 2003 through 2008, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to approximately $335 million for the alleged evasion of import and other taxes, approximately $1.3 billion for interest, and approximately $1.5 billion for various penalties, all determined using an exchange rate as of January 24, 2015. The Company has completed a thorough review of the matters and believes the asserted claims against the Company’s Brazilian subsidiary are without merit, and the Company is defending the claims vigorously. While the Company believes there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, the Company is unable to determine the likelihood of an unfavorable outcome against its Brazilian subsidiary and is unable to reasonably estimate a range of loss, if any. The Company does not expect a final judicial determination for several years.

- added (2015-02-18):
[0000858877-15-000013:note_history:18]
Rockstar    The Company and some of its service provider customers were subject to patent claims asserted in December 2013 in the Eastern District of Texas and the District of Delaware by subsidiaries of the Rockstar Consortium (“Rockstar”).  Rockstar, whose members include Apple, Microsoft, LM Ericsson, Sony, and Blackberry, had purchased a portfolio of patents out of the Nortel Networks’ bankruptcy proceedings (the “Nortel Portfolio”).  In connection with this matter, during the first quarter of fiscal 2015 the Company recorded a charge to product cost of sales of $188 million.

- added (2015-02-18):
[0000858877-15-000013:note_history:19]
In December 2014, RPX Corporation (“RPX”) and Rockstar entered into an agreement, which closed on January 28, 2015, resulting in over 30 technology companies, including the Company and the various service provider customers described above, obtaining a license to the patents owned by Rockstar. The Company paid approximately $300 million in connection with this transaction, with the payment recorded against the amount previously reserved and as an intangible asset to be amortized over its estimated useful life.  In connection with the closing of the transaction, Rockstar dismissed all litigation it had brought against the participating companies.

- removed (2015-02-18):
[0000858877-14-000043:note_history:20]
During the first quarter of fiscal 2014, the Company exercised its call option and entered into an agreement to purchase the remaining interests in Insieme.  The acquisition closed in the second quarter of fiscal 2014, at which time the former noncontrolling interest holders became eligible to receive up to two milestone payments, which will be determined using agreed-upon formulas based primarily on revenue for certain of Insieme’s products.  During the three months ended October 25, 2014 and October 26, 2013, the Company recorded compensation expense of $53 million and $257 million, respectively, related to the fair value of the vested portion of amounts that are expected to be earned by the former noncontrolling interest holders.  Continued vesting and changes to the fair value of the amounts probable of being earned will result in adjustments to the recorded compensation expense in future periods.  Based on the terms of the agreement, the Company has determined that the maximum amount that could be recorded as compensation expense by the Company is approximately $853 million, net of forfeitures and including the $469 million that has been expensed to date.  The milestone payments, if earned, are expected to be paid primarily during fiscal 2016 and fiscal 2017.

- removed (2015-02-18):
[0000858877-14-000043:note_history:21]
|  | October 25, 2014 |  | July 26, 2014 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 285 |  |  | $ | 263 |  |
| End user | 161 |  |  | 202 |  |
| Total | $ | 446 |  |  | $ | 465 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (126 | ) |  | $ | (127 | ) |
| End user | (130 | ) |  | (166 | ) |
| Total | $ | (256 | ) |  | $ | (293 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue | $ | 190 |  |  | $ | 172 |  |

- removed (2015-02-18):
[0000858877-14-000043:note_history:22]
The asserted claims by Brazilian federal tax authorities are for calendar years 2003 through 2008, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to approximately $348 million for the alleged evasion of import and other taxes, approximately $1.3 billion for interest, and approximately $1.5 billion for various penalties, all determined using an exchange rate as of October 25, 2014. The Company has completed a thorough review of the matters and believes the asserted claims against the Company’s Brazilian subsidiary are without merit, and the Company is defending the claims vigorously. While the Company believes there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, the Company is unable to determine the likelihood of an unfavorable outcome against its Brazilian subsidiary and is unable to reasonably estimate a range of loss, if any. The Company does not expect a final judicial determination for several years.

- removed (2015-02-18):
[0000858877-14-000043:note_history:23]
Rockstar    The Company and some of its service provider customers are subject to patent claims asserted in December 2013 in the Eastern District of Texas and the District of Delaware by subsidiaries of the Rockstar Consortium ("Rockstar").  Rockstar, whose members include Apple, Microsoft, LM Ericsson, Sony, and Blackberry, purchased a portfolio of patents out of the Nortel Networks’ bankruptcy proceedings (the “Nortel Portfolio”). Rockstar’s subsidiaries allege that some of the Company’s NGN Routing, Switching and Collaboration products, as well as video solutions deployed by its service provider customers, infringe some of the patents in the Nortel Portfolio.  A binding letter of intent has been executed with Rockstar regarding the Nortel Portfolio.  The transaction, which is subject to various closing conditions, will result in various technology companies, including but not limited to the Company and the various service provider customers described above, obtaining a license to that portfolio. The parties agreed to stay the litigation pending negotiation of agreements, and when the transaction closes, Rockstar will dismiss all litigation brought against the participating companies.  In connection with this matter, during the first quarter of fiscal 2015 the Company recorded a charge to product cost of sales of $188 million.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2015-02-18):
[0000858877-15-000013:note_history:24]
The accompanying financial data as of January 24, 2015 and for the three and six months ended January 24, 2015 and January 25, 2014 has been prepared by the Company, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (SEC). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (GAAP) have been condensed or omitted pursuant to such rules and regulations. The July 26, 2014 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, the Company believes that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended July 26, 2014.
  (was, 2014-11-20, similarity 0.9636):
[0000858877-14-000043:note_history:24]
The accompanying financial data as of October 25, 2014 and for the three months ended October 25, 2014 and October 26, 2013 has been prepared by the Company, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (SEC). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (GAAP) have been condensed or omitted pursuant to such rules and regulations. The July 26, 2014 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, the Company believes that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended July 26, 2014.

- added (2015-02-18):
[0000858877-15-000013:note_history:25]
In the opinion of management, all adjustments (which include normal recurring adjustments, except as disclosed herein) necessary to present fairly the consolidated balance sheet as of January 24, 2015; the results of operations and statements of comprehensive income for the three and six months ended January 24, 2015 and January 25, 2014; and the statements of cash flows and equity for the six months ended January 24, 2015 and January 25, 2014, as applicable, have been made. The results of operations for the three and six months ended January 24, 2015 are not necessarily indicative of the operating results for the full fiscal year or any future periods.

- removed (2015-02-18):
[0000858877-14-000043:note_history:26]
In the opinion of management, all adjustments (which include normal recurring adjustments, except as disclosed herein) necessary to present fairly the consolidated balance sheet as of October 25, 2014; the results of operations; statements of comprehensive income, cash flows, and equity for the three months ended October 25, 2014 and October 26, 2013, as applicable, have been made. The results of operations for the three months ended October 25, 2014 are not necessarily indicative of the operating results for the full fiscal year or any future periods.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2015-02-18):
[0000858877-15-000013:note_history:27]
In April 2014, the FASB issued an accounting standard update that changes the criteria for reporting discontinued operations.  This accounting standard update raises the threshold for a disposal transaction to qualify as a discontinued operation and requires additional disclosures about discontinued operations and disposals of individually significant components that do not qualify as discontinued operations.  The Company adopted this accounting standard update in the second quarter of fiscal 2015, and it did not have any impact upon adoption.
  (was, 2014-11-20, similarity 0.6912):
[0000858877-14-000043:note_history:27]
In April 2014, the FASB issued an accounting standard update that changes the criteria for reporting discontinued operations.  This accounting standard update raises the threshold for a disposal transaction to qualify as a discontinued operation and requires additional disclosures about discontinued operations and disposals of individually significant components that do not qualify as discontinued operations.  This accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2016.  Early adoption is permitted, but only for disposals that have not been reported in financial statements previously issued.  The Company is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-02-18):
[0000858877-15-000013:note_history:28]
|  | January 24, 2015 |  | July 26, 2014 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 850 |  |  | 0.36 | % |  | $ | 500 |  |  | 3.11 | % |
| Other short-term debt | 5 |  |  | 2.73 | % |  | 8 |  |  | 2.67 | % |
| Total short-term debt | $ | 855 |  |  |  |  | $ | 508 |  |  |  |
  (was, 2014-11-20, similarity 0.9757):
[0000858877-14-000043:note_history:28]
|  | October 25, 2014 |  | July 26, 2014 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 1,350 |  |  | 1.38 | % |  | $ | 500 |  |  | 3.11 | % |
| Other short-term debt | 7 |  |  | 2.76 | % |  | 8 |  |  | 2.67 | % |
| Total short-term debt | $ | 1,357 |  |  |  |  | $ | 508 |  |  |  |

- changed (2015-02-18):
[0000858877-15-000013:note_history:29]
In fiscal 2011, the Company established a short-term debt financing program of up to $3.0 billion through the issuance of commercial paper notes. The Company uses the proceeds from the issuance of commercial paper notes for general corporate purposes. The Company had no commercial paper notes outstanding as of each of January 24, 2015 and July 26, 2014.
  (was, 2014-11-20, similarity 0.9467):
[0000858877-14-000043:note_history:29]
In fiscal 2011, the Company established a short-term debt financing program of up to $3.0 billion through the issuance of commercial paper notes. The Company uses the proceeds from the issuance of commercial paper notes for general corporate purposes. The Company had no commercial paper notes outstanding as of each of October 25, 2014 and July 26, 2014.

- changed (2015-02-18):
[0000858877-15-000013:note_history:30]
|  |  |  | January 24, 2015 |  | July 26, 2014 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.05% | September 3, 2015 |  | $ | 850 |  |  | 0.36% |  | $ | 850 |  |  | 0.35% |
| Three-month LIBOR plus 0.28% | March 3, 2017 |  | 1,000 |  |  | 0.57% |  | 1,000 |  |  | 0.56% |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | 500 |  |  | 0.79% |  | 500 |  |  | 0.78% |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 2.90% | November 17, 2014 |  | — |  |  | — |  | 500 |  |  | 3.11% |
| 5.50% | February 22, 2016 |  | 3,000 |  |  | 3.05% |  | 3,000 |  |  | 3.04% |
| 1.10% | March 3, 2017 |  | 2,400 |  |  | 0.57% |  | 2,400 |  |  | 0.56% |
| 3.15% | March 14, 2017 |  | 750 |  |  | 0.80% |  | 750 |  |  | 0.79% |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 4.69% |  | 2,000 |  |  | 4.69% |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 0.78% |  | 1,750 |  |  | 0.77% |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 2.99% |  | 2,500 |  |  | 2.98% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 0.94% |  | 500 |  |  | 0.93% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1.06% |  | 1,000 |  |  | 1.05% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Other long-term debt |  |  | 2 |  |  | 2.08% |  | 4 |  |  | 2.39% |
| Total |  |  | 20,252 |  |  |  |  | 20,754 |  |  |  |
| Unaccreted discount |  |  | (61 | ) |  |  |  | (63 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 326 |  |  |  |  | 210 |  |  |  |
| Total |  |  | $ | 20,517 |  |  |  |  | $ | 20,901 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 850 |  |  |  |  | $ | 500 |  |  |  |
| Long-term debt |  |  | 19,667 |  |  |  |  | 20,401 |  |  |  |
| Total |  |  | $ | 20,517 |  |  |  |  | $ | 20,901 |  |  |  |
  (was, 2014-11-20, similarity 0.9888):
[0000858877-14-000043:note_history:30]
|  |  |  | October 25, 2014 |  | July 26, 2014 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.05% | September 3, 2015 |  | $ | 850 |  |  | 0.36% |  | $ | 850 |  |  | 0.35% |
| Three-month LIBOR plus 0.28% | March 3, 2017 |  | 1,000 |  |  | 0.57% |  | 1,000 |  |  | 0.56% |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | 500 |  |  | 0.79% |  | 500 |  |  | 0.78% |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 2.90% | November 17, 2014 |  | 500 |  |  | 3.11% |  | 500 |  |  | 3.11% |
| 5.50% | February 22, 2016 |  | 3,000 |  |  | 3.05% |  | 3,000 |  |  | 3.04% |
| 1.10% | March 3, 2017 |  | 2,400 |  |  | 0.55% |  | 2,400 |  |  | 0.56% |
| 3.15% | March 14, 2017 |  | 750 |  |  | 0.80% |  | 750 |  |  | 0.79% |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 4.69% |  | 2,000 |  |  | 4.69% |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 0.77% |  | 1,750 |  |  | 0.77% |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 2.98% |  | 2,500 |  |  | 2.98% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 0.93% |  | 500 |  |  | 0.93% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1.04% |  | 1,000 |  |  | 1.05% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Other long-term debt |  |  | 2 |  |  | 2.08% |  | 4 |  |  | 2.39% |
| Total |  |  | 20,752 |  |  |  |  | 20,754 |  |  |  |
| Unaccreted discount |  |  | (62 | ) |  |  |  | (63 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 275 |  |  |  |  | 210 |  |  |  |
| Total |  |  | $ | 20,965 |  |  |  |  | $ | 20,901 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 1,350 |  |  |  |  | $ | 500 |  |  |  |
| Long-term debt |  |  | 19,615 |  |  |  |  | 20,401 |  |  |  |
| Total |  |  | $ | 20,965 |  |  |  |  | $ | 20,901 |  |  |  |

- changed (2015-02-18):
[0000858877-15-000013:note_history:31]
The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to the Company’s short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of January 24, 2015, the Company was in compliance with all debt covenants.
  (was, 2014-11-20, similarity 0.92):
[0000858877-14-000043:note_history:31]
The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to the Company’s short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of October 25, 2014, the Company was in compliance with all debt covenants.

- changed (2015-02-18):
[0000858877-15-000013:note_history:32]
As of January 24, 2015, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):
  (was, 2014-11-20, similarity 0.9556):
[0000858877-14-000043:note_history:32]
As of October 25, 2014, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

- changed (2015-02-18):
[0000858877-15-000013:note_history:33]
| Fiscal Year | Amount |
| 2015 (remaining six months) | $ | — |  |
| 2016 | 3,851 |  |
| 2017 | 4,151 |  |
| 2018 | — |  |
| 2019 | 4,250 |  |
| Thereafter | 8,000 |  |
| Total | $ | 20,252 |  |
  (was, 2014-11-20, similarity 0.977):
[0000858877-14-000043:note_history:33]
| Fiscal Year | Amount |
| 2015 (remaining nine months) | $ | 500 |  |
| 2016 | 3,851 |  |
| 2017 | 4,151 |  |
| 2018 | — |  |
| 2019 | 4,250 |  |
| Thereafter | 8,000 |  |
| Total | $ | 20,752 |  |

- changed (2015-02-18):
[0000858877-15-000013:note_history:34]
On February 17, 2012, the Company entered into a credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on February 17, 2017. Any advances under the credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (i) the higher of the Federal Funds rate plus 0.50%, Bank of America’s “prime rate” as announced from time to time, or one-month LIBOR plus 1.00% or (ii) LIBOR plus a margin that is based on the Company’s senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc. The credit agreement requires the Company to comply with certain covenants, including that it maintain an interest coverage ratio as defined in the agreement. As of January 24, 2015, the Company was in compliance with the required interest coverage ratio and the other covenants, and the Company had not borrowed any funds under the credit facility.
  (was, 2014-11-20, similarity 0.993):
[0000858877-14-000043:note_history:34]
On February 17, 2012, the Company entered into a credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on February 17, 2017. Any advances under the credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (i) the higher of the Federal Funds rate plus 0.50%, Bank of America’s “prime rate” as announced from time to time, or one-month LIBOR plus 1.00% or (ii) LIBOR plus a margin that is based on the Company’s senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc. The credit agreement requires the Company to comply with certain covenants, including that it maintain an interest coverage ratio as defined in the agreement. As of October 25, 2014, the Company was in compliance with the required interest coverage ratio and the other covenants, and the Company had not borrowed any funds under the credit facility.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2015-02-18):
[0000858877-15-000013:note_history:35]
| January 24, 2015 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| Fixed income securities: |  |  |  |  |  |  |  |
| U.S. government securities | $ | 30,302 |  |  | $ | 53 |  |  | $ | (1 | ) |  | $ | 30,354 |  |
| U.S. government agency securities | 2,324 |  |  | 3 |  |  | (1 | ) |  | 2,326 |  |
| Non-U.S. government and agency securities | 1,108 |  |  | 1 |  |  | — |  |  | 1,109 |  |
| Corporate debt securities | 11,180 |  |  | 61 |  |  | (28 | ) |  | 11,213 |  |
| U.S. agency mortgage-backed securities | 1,360 |  |  | 15 |  |  | — |  |  | 1,375 |  |
| Total fixed income securities | 46,274 |  |  | 133 |  |  | (30 | ) |  | 46,377 |  |
| Publicly traded equity securities | 1,296 |  |  | 562 |  |  | (10 | ) |  | 1,848 |  |
| Total | $ | 47,570 |  |  | $ | 695 |  |  | $ | (40 | ) |  | $ | 48,225 |  |

- added (2015-02-18):
[0000858877-15-000013:note_history:36]
| July 26, 2014 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| Fixed income securities: |  |  |  |  |  |  |  |
| U.S. government securities | $ | 31,717 |  |  | $ | 29 |  |  | $ | (12 | ) |  | $ | 31,734 |  |
| U.S. government agency securities | 1,062 |  |  | 1 |  |  | — |  |  | 1,063 |  |
| Non-U.S. government and agency securities | 860 |  |  | 2 |  |  | (1 | ) |  | 861 |  |
| Corporate debt securities | 9,092 |  |  | 74 |  |  | (7 | ) |  | 9,159 |  |
| U.S. agency mortgage-backed securities | 574 |  |  | 5 |  |  | — |  |  | 579 |  |
| Total fixed income securities | 43,305 |  |  | 111 |  |  | (20 | ) |  | 43,396 |  |
| Publicly traded equity securities | 1,314 |  |  | 648 |  |  | (10 | ) |  | 1,952 |  |
| Total | $ | 44,619 |  |  | $ | 759 |  |  | $ | (30 | ) |  | $ | 45,348 |  |

- changed (2015-02-18):
[0000858877-15-000013:note_history:37]
|  | Three Months Ended |  | Six Months Ended |
|  | January 24, 2015 |  | January 25, 2014 |  | January 24, 2015 |  | January 25, 2014 |
| Gross realized gains | $ | 92 |  |  | $ | 97 |  |  | $ | 113 |  |  | $ | 192 |  |
| Gross realized losses | (23 | ) |  | (15 | ) |  | (37 | ) |  | (27 | ) |
| Total | $ | 69 |  |  | $ | 82 |  |  | $ | 76 |  |  | $ | 165 |  |
  (was, 2014-11-20, similarity 0.6994):
[0000858877-14-000043:note_history:37]
|  | Three Months Ended |
|  | October 25, 2014 |  | October 26, 2013 |
| Gross realized gains | $ | 21 |  |  | $ | 95 |  |
| Gross realized losses | (14 | ) |  | (12 | ) |
| Total | $ | 7 |  |  | $ | 83 |  |

- added (2015-02-18):
[0000858877-15-000013:note_history:38]
|  | Three Months Ended |  | Six Months Ended |
|  | January 24, 2015 |  | January 25, 2014 |  | January 24, 2015 |  | January 25, 2014 |
| Net gains (losses) on investments in publicly traded equity securities | $ | 60 |  |  | $ | 69 |  |  | $ | 56 |  |  | $ | 144 |  |
| Net gains on investments in fixed income securities | 9 |  |  | 13 |  |  | 20 |  |  | 21 |  |
| Total | $ | 69 |  |  | $ | 82 |  |  | $ | 76 |  |  | $ | 165 |  |

- added (2015-02-18):
[0000858877-15-000013:note_history:39]
There were no impairment charges on available-for-sale investments for the three and six months ended January 24, 2015.  For the three and six months ended January 25, 2014, the realized gains related to the Company's available-for-sale investments included impairment charges of $11 million for publicly traded equity securities, which were due to a decline in the fair value of those securities below their cost basis that were determined to be other than temporary.

- changed (2015-02-18):
[0000858877-15-000013:note_history:40]
The following tables present the breakdown of the available-for-sale investments with gross unrealized losses and the duration that those losses had been unrealized at January 24, 2015 and July 26, 2014 (in millions):
  (was, 2014-11-20, similarity 0.9662):
[0000858877-14-000043:note_history:40]
The following tables present the breakdown of the available-for-sale investments with gross unrealized losses and the duration that those losses had been unrealized at October 25, 2014 and July 26, 2014 (in millions):

- added (2015-02-18):
[0000858877-15-000013:note_history:41]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| January 24, 2015 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| Fixed income securities: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | $ | 4,558 |  |  | $ | (1 | ) |  | $ | — |  |  | $ | — |  |  | $ | 4,558 |  |  | $ | (1 | ) |
| U.S. government agency securities | 854 |  |  | (1 | ) |  | — |  |  | — |  |  | 854 |  |  | (1 | ) |
| Corporate debt securities | 3,952 |  |  | (25 | ) |  | 363 |  |  | (3 | ) |  | 4,315 |  |  | (28 | ) |
| Total fixed income securities | 9,364 |  |  | (27 | ) |  | 363 |  |  | (3 | ) |  | 9,727 |  |  | (30 | ) |
| Publicly traded equity securities | 119 |  |  | (10 | ) |  | 1 |  |  | — |  |  | 120 |  |  | (10 | ) |
| Total | $ | 9,483 |  |  | $ | (37 | ) |  | $ | 364 |  |  | $ | (3 | ) |  | $ | 9,847 |  |  | $ | (40 | ) |

- changed (2015-02-18):
[0000858877-15-000013:note_history:42]
As of January 24, 2015, for fixed income securities that were in unrealized loss positions, the Company has determined that (i) it does not have the intent to sell any of these investments and (ii) it is not more likely than not that it will be required to sell any of these investments before recovery of the entire amortized cost basis. In addition, as of January 24, 2015, the Company anticipates that it will recover the entire amortized cost basis of such fixed income securities and has determined that no other-than-temporary impairments associated with credit losses were required to be recognized during the six months ended January 24, 2015.
  (was, 2014-11-20, similarity 0.6793):
[0000858877-14-000043:note_history:42]
As of October 25, 2014, for fixed income securities that were in unrealized loss positions, the Company has determined that (i) it does not have the intent to sell any of these investments, and (ii) it is not more likely than not that it will be required to sell any of these investments before recovery of the entire amortized cost basis. In addition, as of October 25, 2014, the Company anticipates that it will recover the entire amortized cost basis of such fixed income securities and has determined that no other-than-temporary impairments associated with credit losses were required to be recognized during the three months ended October 25, 2014.

- changed (2015-02-18):
[0000858877-15-000013:note_history:43]
The Company has evaluated its publicly traded equity securities as of January 24, 2015 and has determined that there was no indication of other-than-temporary impairments in the respective categories of unrealized losses. This determination was based on several factors, which include the length of time and extent to which fair value has been less than the cost basis, the financial condition and near-term prospects of the issuer, and the Company’s intent and ability to hold the publicly traded equity securities for a period of time sufficient to allow for any anticipated recovery in market value.
  (was, 2014-11-20, similarity 0.9883):
[0000858877-14-000043:note_history:43]
The Company has evaluated its publicly traded equity securities as of October 25, 2014 and has determined that there was no indication of other-than-temporary impairments in the respective categories of unrealized losses. This determination was based on several factors, which include the length of time and extent to which fair value has been less than the cost basis, the financial condition and near-term prospects of the issuer, and the Company’s intent and ability to hold the publicly traded equity securities for a period of time sufficient to allow for any anticipated recovery in market value.

- changed (2015-02-18):
[0000858877-15-000013:note_history:44]
The following table summarizes the maturities of the Company’s fixed income securities at January 24, 2015 (in millions):
  (was, 2014-11-20, similarity 0.9483):
[0000858877-14-000043:note_history:44]
The following table summarizes the maturities of the Company’s fixed income securities at October 25, 2014 (in millions):

- changed (2015-02-18):
[0000858877-15-000013:note_history:45]
The Company periodically engages in securities lending activities with certain of its available-for-sale investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. The average daily balance of securities lending for the six months ended January 24, 2015 and January 25, 2014 was $0.6 billion and $0.9 billion, respectively. The Company requires collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. The Company engages in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify the Company against collateral losses. The Company did not experience any losses in connection with the secured lending of securities during the periods presented. As of January 24, 2015 and July 26, 2014, the Company had no outstanding securities lending transactions.
  (was, 2014-11-20, similarity 0.9645):
[0000858877-14-000043:note_history:45]
The Company periodically engages in securities lending activities with certain of its available-for-sale investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. The average daily balance of securities lending for the three months ended October 25, 2014 and October 26, 2013 was $1.0 billion and $0.6 billion, respectively. The Company requires collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. The Company engages in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify the Company against collateral losses. The Company did not experience any losses in connection with the secured lending of securities during the periods presented. As of October 25, 2014 and July 26, 2014, the Company had no outstanding securities lending transactions.

- changed (2015-02-18):
[0000858877-15-000013:note_history:46]
The carrying value of the Company’s investments in privately held companies was included in other assets. For such investments that were accounted for under the equity and cost method as of January 24, 2015 and July 26, 2014, the amounts are summarized in the following table (in millions):
  (was, 2014-11-20, similarity 0.9749):
[0000858877-14-000043:note_history:46]
The carrying value of the Company’s investments in privately held companies was included in other assets. For such investments that were accounted for under the equity and cost method as of October 25, 2014 and July 26, 2014, the amounts are summarized in the following table (in millions):

- changed (2015-02-18):
[0000858877-15-000013:note_history:47]
|  | January 24, 2015 |  | July 26, 2014 |
| Equity method investments | $ | 541 |  |  | $ | 630 |  |
| Cost method investments | 316 |  |  | 269 |  |
| Total | $ | 857 |  |  | $ | 899 |  |
  (was, 2014-11-20, similarity 0.9615):
[0000858877-14-000043:note_history:47]
|  | October 25, 2014 |  | July 26, 2014 |
| Equity method investments | $ | 559 |  |  | $ | 630 |  |
| Cost method investments | 327 |  |  | 269 |  |
| Total | $ | 886 |  |  | $ | 899 |  |

- added (2015-02-18):
[0000858877-15-000013:note_history:48]
VCE Joint Venture   VCE is a joint venture formed in fiscal 2010 between the Company and EMC Corporation (“EMC”), with investments from VMware, Inc. (“VMware”) and Intel Capital Corporation ("Intel"). In October 2014, the Company, EMC, VMware, and Intel agreed to restructure VCE, and this transaction was completed in the second quarter of fiscal 2015.  Prior to the restructuring, the Company’s cumulative gross investment in VCE was approximately $716 million inclusive of convertible notes and accrued interest on convertible notes.  The Company recorded cumulative losses from VCE under the equity method of $691 million since inception. The Company ceased accounting for the VCE investment under the equity method in October 2014 and recorded no losses during the three months ended January 24, 2015, compared with losses of $58 million recorded for the three months ended January 25, 2014, and losses of $47 million and $111 million were recorded for the six months ended January 24, 2015 and January 25, 2014, respectively.  Under the terms of the restructuring, VCE paid $152 million to the Company for a portion of the outstanding principal balance of the convertible notes held by it and accrued interest on such notes, and the remaining principal balance of other such notes, and the accrued interest thereon, was cancelled.  Pursuant to the restructuring, VCE also redeemed a portion of the Company’s equity interest in VCE, reducing the Company’s ownership interest in VCE from 35% prior to the restructuring to 10%.  In connection with this transaction, the Company has written this investment down to a book value of zero and has recognized a gain of $126 million for the three and six months ended January 24, 2015.

- changed (2015-02-18):
[0000858877-15-000013:note_history:49]
Other Variable Interest Entities    In the ordinary course of business, the Company has investments in other privately held companies and provides financing to certain customers. These other privately held companies and customers may be considered to be variable interest entities. The Company evaluates on an ongoing basis its investments in these other privately held companies and its customer financings and has determined that as of January 24, 2015 there were no other variable interest entities required to be consolidated in the Company’s Consolidated Financial Statements.
  (was, 2014-11-20, similarity 0.9869):
[0000858877-14-000043:note_history:49]
Other Variable Interest Entities    In the ordinary course of business, the Company has investments in other privately held companies and provides financing to certain customers. These other privately held companies and customers may be considered to be variable interest entities. The Company evaluates on an ongoing basis its investments in these other privately held companies and its customer financings, and has determined that as of October 25, 2014 there were no other variable interest entities required to be consolidated in the Company’s Consolidated Financial Statements.

- removed (2015-02-18):
[0000858877-14-000043:note_history:50]
| October 25, 2014 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| Fixed income securities: |  |  |  |  |  |  |  |
| U.S. government securities | $ | 32,343 |  |  | $ | 71 |  |  | $ | — |  |  | $ | 32,414 |  |
| U.S. government agency securities | 1,338 |  |  | 3 |  |  | — |  |  | 1,341 |  |
| Non-U.S. government and agency securities | 1,049 |  |  | 2 |  |  | — |  |  | 1,051 |  |
| Corporate debt securities | 10,170 |  |  | 73 |  |  | (10 | ) |  | 10,233 |  |
| U.S. agency mortgage-backed securities | 875 |  |  | 9 |  |  | — |  |  | 884 |  |
| Total fixed income securities | 45,775 |  |  | 158 |  |  | (10 | ) |  | 45,923 |  |
| Publicly traded equity securities | 1,263 |  |  | 545 |  |  | (11 | ) |  | 1,797 |  |
| Total | $ | 47,038 |  |  | $ | 703 |  |  | $ | (21 | ) |  | $ | 47,720 |  |
| July 26, 2014 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| Fixed income securities: |  |  |  |  |  |  |  |
| U.S. government securities | $ | 31,717 |  |  | $ | 29 |  |  | $ | (12 | ) |  | $ | 31,734 |  |
| U.S. government agency securities | 1,062 |  |  | 1 |  |  | — |  |  | 1,063 |  |
| Non-U.S. government and agency securities | 860 |  |  | 2 |  |  | (1 | ) |  | 861 |  |
| Corporate debt securities | 9,092 |  |  | 74 |  |  | (7 | ) |  | 9,159 |  |
| U.S. agency mortgage-backed securities | 574 |  |  | 5 |  |  | — |  |  | 579 |  |
| Total fixed income securities | 43,305 |  |  | 111 |  |  | (20 | ) |  | 43,396 |  |
| Publicly traded equity securities | 1,314 |  |  | 648 |  |  | (10 | ) |  | 1,952 |  |
| Total | $ | 44,619 |  |  | $ | 759 |  |  | $ | (30 | ) |  | $ | 45,348 |  |

- removed (2015-02-18):
[0000858877-14-000043:note_history:51]
|  | Three Months Ended |
|  | October 25, 2014 |  | October 26, 2013 |
| Net gains (losses) on investments in publicly traded equity securities | $ | (4 | ) |  | $ | 75 |  |
| Net gains on investments in fixed income securities | 11 |  |  | 8 |  |
| Total | $ | 7 |  |  | $ | 83 |  |

- removed (2015-02-18):
[0000858877-14-000043:note_history:52]
There were no impairment charges on available-for-sale investments for the periods presented.

- removed (2015-02-18):
[0000858877-14-000043:note_history:53]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| October 25, 2014 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| Fixed income securities: |  |  |  |  |  |  |  |  |  |  |  |
| Corporate debt securities | $ | 2,491 |  |  | $ | (8 | ) |  | $ | 383 |  |  | $ | (2 | ) |  | $ | 2,874 |  |  | $ | (10 | ) |
| Total fixed income securities | 2,491 |  |  | (8 | ) |  | 383 |  |  | (2 | ) |  | 2,874 |  |  | (10 | ) |
| Publicly traded equity securities | 131 |  |  | (11 | ) |  | 1 |  |  | — |  |  | 132 |  |  | (11 | ) |
| Total | $ | 2,622 |  |  | $ | (19 | ) |  | $ | 384 |  |  | $ | (2 | ) |  | $ | 3,006 |  |  | $ | (21 | ) |

- removed (2015-02-18):
[0000858877-14-000043:note_history:54]
VCE Joint Venture   VCE is a joint venture that the Company formed in fiscal 2010 with EMC Corporation (“EMC”), with investments from VMware, Inc. (“VMware”) and Intel Capital Corporation ("Intel"). VCE helps organizations leverage best-in-class technologies and disciplines from Cisco, EMC, and VMware to enable the transformation to cloud computing.

- removed (2015-02-18):
[0000858877-14-000043:note_history:55]
As of October 25, 2014, the Company’s cumulative gross investment in VCE was approximately $716 million, inclusive of accrued interest on convertible notes, and its ownership percentage was approximately 35%.  The Company did not make any investments in VCE during the three months ended October 25, 2014.  As of October 25, 2014, the Company had recorded cumulative losses from VCE under the equity method of $691 million since inception, of which losses of $47 million and $53 million were recorded for the three months ended October 25, 2014 and October 26, 2013, respectively.  The Company’s carrying value in VCE as of October 25, 2014 was $25 million.

- removed (2015-02-18):
[0000858877-14-000043:note_history:56]
EMC and the Company have entered into guarantee agreements on behalf of VCE to indemnify certain customers (the "Guarantees") for monetary damages. Such Guarantees were not material as of October 25, 2014.

- removed (2015-02-18):
[0000858877-14-000043:note_history:57]
In October 2014, the Company, EMC, VMware, and Intel agreed to restructure the VCE joint venture.  Under the terms of the agreement, VCE will undergo a reorganization and recapitalization whereby VCE will pay approximately $150 million to the Company for a portion of the outstanding principal balance of the convertible notes and accrued interest on such notes.  The Company also agreed to cancel the remaining principal balance of the convertible notes held by it and the accrued interest on such notes, and to have VCE redeem a portion of the Company’s equity interest in VCE.   EMC also agreed to indemnify the Company for any liabilities incurred by the Company under the Guarantees.  Following this reorganization and recapitalization, the Company’s ownership interest in VCE will be approximately 10%.  The transaction is expected to close in the second quarter of the Company's fiscal year 2015, subject to customary regulatory approvals.


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-02-18):
[0000858877-15-000013:note_history:58]
|  |  |  | January 24, 2015 |  | July 26, 2014 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.05% | September 3, 2015 |  | $ | 850 |  |  | 0.36% |  | $ | 850 |  |  | 0.35% |
| Three-month LIBOR plus 0.28% | March 3, 2017 |  | 1,000 |  |  | 0.57% |  | 1,000 |  |  | 0.56% |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | 500 |  |  | 0.79% |  | 500 |  |  | 0.78% |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 2.90% | November 17, 2014 |  | — |  |  | — |  | 500 |  |  | 3.11% |
| 5.50% | February 22, 2016 |  | 3,000 |  |  | 3.05% |  | 3,000 |  |  | 3.04% |
| 1.10% | March 3, 2017 |  | 2,400 |  |  | 0.57% |  | 2,400 |  |  | 0.56% |
| 3.15% | March 14, 2017 |  | 750 |  |  | 0.80% |  | 750 |  |  | 0.79% |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 4.69% |  | 2,000 |  |  | 4.69% |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 0.78% |  | 1,750 |  |  | 0.77% |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 2.99% |  | 2,500 |  |  | 2.98% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 0.94% |  | 500 |  |  | 0.93% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1.06% |  | 1,000 |  |  | 1.05% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Other long-term debt |  |  | 2 |  |  | 2.08% |  | 4 |  |  | 2.39% |
| Total |  |  | 20,252 |  |  |  |  | 20,754 |  |  |  |
| Unaccreted discount |  |  | (61 | ) |  |  |  | (63 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 326 |  |  |  |  | 210 |  |  |  |
| Total |  |  | $ | 20,517 |  |  |  |  | $ | 20,901 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 850 |  |  |  |  | $ | 500 |  |  |  |
| Long-term debt |  |  | 19,667 |  |  |  |  | 20,401 |  |  |  |
| Total |  |  | $ | 20,517 |  |  |  |  | $ | 20,901 |  |  |  |
  (was, 2014-11-20, similarity 0.9888):
[0000858877-14-000043:note_history:58]
|  |  |  | October 25, 2014 |  | July 26, 2014 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.05% | September 3, 2015 |  | $ | 850 |  |  | 0.36% |  | $ | 850 |  |  | 0.35% |
| Three-month LIBOR plus 0.28% | March 3, 2017 |  | 1,000 |  |  | 0.57% |  | 1,000 |  |  | 0.56% |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | 500 |  |  | 0.79% |  | 500 |  |  | 0.78% |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 2.90% | November 17, 2014 |  | 500 |  |  | 3.11% |  | 500 |  |  | 3.11% |
| 5.50% | February 22, 2016 |  | 3,000 |  |  | 3.05% |  | 3,000 |  |  | 3.04% |
| 1.10% | March 3, 2017 |  | 2,400 |  |  | 0.55% |  | 2,400 |  |  | 0.56% |
| 3.15% | March 14, 2017 |  | 750 |  |  | 0.80% |  | 750 |  |  | 0.79% |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 4.69% |  | 2,000 |  |  | 4.69% |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 0.77% |  | 1,750 |  |  | 0.77% |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 2.98% |  | 2,500 |  |  | 2.98% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 0.93% |  | 500 |  |  | 0.93% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1.04% |  | 1,000 |  |  | 1.05% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Other long-term debt |  |  | 2 |  |  | 2.08% |  | 4 |  |  | 2.39% |
| Total |  |  | 20,752 |  |  |  |  | 20,754 |  |  |  |
| Unaccreted discount |  |  | (62 | ) |  |  |  | (63 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 275 |  |  |  |  | 210 |  |  |  |
| Total |  |  | $ | 20,965 |  |  |  |  | $ | 20,901 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 1,350 |  |  |  |  | $ | 500 |  |  |  |
| Long-term debt |  |  | 19,615 |  |  |  |  | 20,401 |  |  |  |
| Total |  |  | $ | 20,965 |  |  |  |  | $ | 20,901 |  |  |  |


## us-gaap:ScheduleOfMaturitiesOfLongTermDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-02-18):
[0000858877-15-000013:note_history:59]
As of January 24, 2015, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):
  (was, 2014-11-20, similarity 0.9556):
[0000858877-14-000043:note_history:59]
As of October 25, 2014, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

- changed (2015-02-18):
[0000858877-15-000013:note_history:60]
| Fiscal Year | Amount |
| 2015 (remaining six months) | $ | — |  |
| 2016 | 3,851 |  |
| 2017 | 4,151 |  |
| 2018 | — |  |
| 2019 | 4,250 |  |
| Thereafter | 8,000 |  |
| Total | $ | 20,252 |  |
  (was, 2014-11-20, similarity 0.977):
[0000858877-14-000043:note_history:60]
| Fiscal Year | Amount |
| 2015 (remaining nine months) | $ | 500 |  |
| 2016 | 3,851 |  |
| 2017 | 4,151 |  |
| 2018 | — |  |
| 2019 | 4,250 |  |
| Thereafter | 8,000 |  |
| Total | $ | 20,752 |  |


## us-gaap:ScheduleOfShortTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-02-18):
[0000858877-15-000013:note_history:61]
|  | January 24, 2015 |  | July 26, 2014 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 850 |  |  | 0.36 | % |  | $ | 500 |  |  | 3.11 | % |
| Other short-term debt | 5 |  |  | 2.73 | % |  | 8 |  |  | 2.67 | % |
| Total short-term debt | $ | 855 |  |  |  |  | $ | 508 |  |  |  |
  (was, 2014-11-20, similarity 0.9757):
[0000858877-14-000043:note_history:61]
|  | October 25, 2014 |  | July 26, 2014 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 1,350 |  |  | 1.38 | % |  | $ | 500 |  |  | 3.11 | % |
| Other short-term debt | 7 |  |  | 2.76 | % |  | 8 |  |  | 2.67 | % |
| Total short-term debt | $ | 1,357 |  |  |  |  | $ | 508 |  |  |  |
