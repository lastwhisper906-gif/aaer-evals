# CSCO MD&A — 0000858877-15-000013


## mdna

[0000858877-15-000013:mdna:1]
[same as prior period, unchanged from 0000858877-14-000043:mdna:1]

[0000858877-15-000013:mdna:2]
[same as prior period, unchanged from 0000858877-14-000043:mdna:2]

[0000858877-15-000013:mdna:3]
[same as prior period, unchanged from 0000858877-14-000043:mdna:3]

[0000858877-15-000013:mdna:4]
[same as prior period, unchanged from 0000858877-14-000043:mdna:4]

[0000858877-15-000013:mdna:5]
[same as prior period, unchanged from 0000858877-14-000043:mdna:5]

[0000858877-15-000013:mdna:6]
|  | Three Months Ended |  |  | Six Months Ended |  |
|  | January 24, 2015 |  | January 25, 2014 |  | Variance |  |  | January 24, 2015 |  | January 25, 2014 |  | Variance |  |
| Revenue | $ | 11,936 |  |  | $ | 11,155 |  |  | 7.0 | % |  |  | $ | 24,181 |  |  | $ | 23,240 |  |  | 4.0 | % |  |
| Gross margin percentage | 59.4 | % |  | 53.3 | % |  | 6.1 |  | pts |  | 59.6 | % |  | 57.5 | % |  | 2.1 |  | pts |
| Research and development | $ | 1,529 |  |  | $ | 1,412 |  |  | 8.3 | % |  |  | $ | 3,112 |  |  | $ | 3,136 |  |  | (0.8 | )% |  |
| Sales and marketing | $ | 2,308 |  |  | $ | 2,277 |  |  | 1.4 | % |  |  | $ | 4,823 |  |  | $ | 4,688 |  |  | 2.9 | % |  |
| General and administrative | $ | 490 |  |  | $ | 451 |  |  | 8.6 | % |  |  | $ | 994 |  |  | $ | 966 |  |  | 2.9 | % |  |
| Total R&D, sales and marketing, general and administrative | $ | 4,327 |  |  | $ | 4,140 |  |  | 4.5 | % |  |  | $ | 8,929 |  |  | $ | 8,790 |  |  | 1.6 | % |  |
| Total as a percentage of revenue | 36.3 | % |  | 37.1 | % |  | (0.8 | ) | pts |  | 36.9 | % |  | 37.8 | % |  | (0.9 | ) | pts |
| Amortization of purchased intangible assets included in operating expenses | $ | 72 |  |  | $ | 71 |  |  | 1.4 | % |  |  | $ | 143 |  |  | $ | 136 |  |  | 5.1 | % |  |
| Restructuring and other charges | $ | 69 |  |  | $ | 73 |  |  | (5.5 | )% |  |  | $ | 387 |  |  | $ | 310 |  |  | 24.8 | % |  |
| Operating income as a percentage of revenue | 22.0 | % |  | 14.9 | % |  | 7.1 |  | pts |  | 20.5 | % |  | 17.7 | % |  | 2.8 |  | pts |
| Income tax percentage | 16.6 | % |  | 18.6 | % |  | (2.0 | ) | pts |  | 19.3 | % |  | 20.3 | % |  | (1.0 | ) | pts |
| Net income | $ | 2,397 |  |  | $ | 1,429 |  |  | 67.7 | % |  |  | $ | 4,225 |  |  | $ | 3,425 |  |  | 23.4 | % |  |
| Net income as a percentage of revenue | 20.1 | % |  | 12.8 | % |  | 7.3 |  | pts |  | 17.5 | % |  | 14.7 | % |  | 2.8 |  | pts |
| Earnings per share—diluted | $ | 0.46 |  |  | $ | 0.27 |  |  | 70.4 | % |  |  | $ | 0.82 |  |  | $ | 0.64 |  |  | 28.1 | % |  |

[0000858877-15-000013:mdna:7]
42

[0000858877-15-000013:mdna:8]
[same as prior period, unchanged from 0000858877-14-000043:mdna:8]

[0000858877-15-000013:mdna:9]
[same as prior period, unchanged from 0000858877-14-000043:mdna:9]

[0000858877-15-000013:mdna:10]
Three Months Ended January 24, 2015 Compared with Three Months Ended January 25, 2014

[0000858877-15-000013:mdna:11]
In the second quarter of fiscal 2015, revenue increased by 7% as compared with the second quarter of fiscal 2014. Within the total revenue change, product revenue increased 8% while service revenue increased 5%. Total gross margin increased by 6.1 percentage points, primarily as a result of the $655 million charge to product cost of sales recorded in the second quarter of fiscal 2014 for which there was no corresponding charge in fiscal 2015.  As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses, collectively, decreased by 0.8 percentage points. Operating income as a percentage of revenue increased by 7.1 percentage points. Diluted earnings per share increased by 70% from the prior year, driven by a 68% increase in net income, with the net income increase driven by the factors discussed above, as well as higher other income driven by higher net gains on investments, and a lower effective tax rate driven by the retroactive reinstatement of the U.S. federal R&D tax credit for calendar year 2014.

[0000858877-15-000013:mdna:12]
In the second quarter of fiscal 2015, total revenue increased by $0.8 billion as compared with the second quarter of fiscal 2014. Revenue for the Americas increased by $0.6 billion, driven in large part by higher product revenue in the United States. EMEA revenue increased by $0.2 billion, led by higher product revenue in the United Kingdom. Revenue in our APJC segment decreased by $0.1 billion, led by a product revenue decline in China. The challenges we encountered in certain emerging countries in the previous quarters continued in the second quarter of fiscal 2015. We experienced increased product revenue in the emerging countries of Brazil, India, and Mexico and decreased revenue in China and Russia, as the “BRICM” countries experienced, in the aggregate, product revenue growth of 2%.  We believe that the limited growth we experienced in various emerging countries reflected the impact of economic and geopolitical challenges in these countries.

[0000858877-15-000013:mdna:13]
From a customer market standpoint, in the second quarter of fiscal 2015, while the service provider market continued to experience a decline in product revenue, we had solid product revenue growth in the public sector, enterprise and commercial markets. The product revenue increase in the public sector market was led by higher spending from the U.S. federal government.

[0000858877-15-000013:mdna:14]
From a product category perspective, the product revenue increase of 8% year-over-year was driven by product revenue growth in our core Switching and NGN Routing products which grew 11% and 2%, respectively. We also experienced 40% revenue growth from Data Center products due to continued strong customer demand. Our other major product categories experienced revenue changes ranging from an 18% increase in Wireless products to a 19% decrease in Service Provider Video. Service revenue increased by 5% year over year.

[0000858877-15-000013:mdna:15]
In summary, during the second quarter of fiscal 2015, we achieved solid and profitable growth despite encountering several of the challenges we have experienced in recent quarters, including reduced spending by our service provider customers and challenges  in certain emerging countries. While we believe we are well positioned for an upturn in these areas, we are not expecting the challenges in service provider and certain emerging countries to improve for at least a few quarters.

[0000858877-15-000013:mdna:16]
Six Months Ended January 24, 2015 Compared with Six Months Ended January 25, 2014

[0000858877-15-000013:mdna:17]
Diluted earnings per share increased by 28% from the prior year, a result of both a 23% increase in net income and a decrease in diluted share count by 224 million shares.  Revenue increased 4%, with product revenue increasing 4% and service revenue increasing 5%. Total gross margin increased by 2.1 percentage points driven in part by the $655 million supplier component remediation charge recorded in the second quarter of fiscal 2014 partially offset by the unfavorable impact of the Rockstar patent portfolio charge of $188 million (or 0.8 percentage points). As a percentage of revenue, research and development, sales and marketing, and general and administrative expenses collectively decreased by 0.9 percentage points. Operating income as a percentage of revenue increased by 2.8 percentage points.

[0000858877-15-000013:mdna:18]
[same as prior period, unchanged from 0000858877-14-000043:mdna:43]

[0000858877-15-000013:mdna:19]
[same as prior period, unchanged from 0000858877-14-000043:mdna:17]

[0000858877-15-000013:mdna:20]
[same as prior period, unchanged from 0000858877-14-000043:mdna:18]

[0000858877-15-000013:mdna:21]
[same as prior period, unchanged from 0000858877-14-000043:mdna:19]

[0000858877-15-000013:mdna:22]
[same as prior period, unchanged from 0000858877-14-000043:mdna:20]

[0000858877-15-000013:mdna:23]
[same as prior period, unchanged from 0000858877-14-000043:mdna:21]

[0000858877-15-000013:mdna:24]
[same as prior period, unchanged from 0000858877-14-000043:mdna:22]

[0000858877-15-000013:mdna:25]
[same as prior period, unchanged from 0000858877-14-000043:mdna:23]

[0000858877-15-000013:mdna:26]
[same as prior period, unchanged from 0000858877-14-000043:mdna:24]

[0000858877-15-000013:mdna:27]
The following is a summary of our other key financial measures for the second quarter and first six months of fiscal 2015 (in millions, except days sales outstanding in accounts receivable (DSO) and annualized inventory turns):

[0000858877-15-000013:mdna:28]
|  |  | January 24, 2015 |  | July 26, 2014 |
| Cash and cash equivalents and investments |  | $ | 53,022 |  |  | $ | 52,074 |  |
| Deferred revenue |  | $ | 14,021 |  |  | $ | 14,142 |  |
| DSO |  | 35 days |  |  | 38 days |  |
| Inventories |  | $ | 1,890 |  |  | $ | 1,591 |  |
| Annualized inventory turns |  | 10.9 |  |  | 12.7 |  |

[0000858877-15-000013:mdna:29]
|  |  | Six Months Ended |
|  |  | January 24, 2015 |  | January 25, 2014 |
| Cash provided by operating activities |  | $ | 5,374 |  |  | $ | 5,522 |  |
| Repurchases of common stock—stock repurchase program |  | $ | 2,221 |  |  | $ | 6,020 |  |
| Dividends |  | $ | 1,947 |  |  | $ | 1,810 |  |

[0000858877-15-000013:mdna:30]
44

[0000858877-15-000013:mdna:31]
[same as prior period, unchanged from 0000858877-14-000043:mdna:28]

[0000858877-15-000013:mdna:32]
[same as prior period, unchanged from 0000858877-14-000043:mdna:29]

[0000858877-15-000013:mdna:33]
[same as prior period, unchanged from 0000858877-14-000043:mdna:30]

[0000858877-15-000013:mdna:34]
[same as prior period, unchanged from 0000858877-14-000043:mdna:31]

[0000858877-15-000013:mdna:35]
[same as prior period, unchanged from 0000858877-14-000043:mdna:32]

[0000858877-15-000013:mdna:36]
[same as prior period, unchanged from 0000858877-14-000043:mdna:33]

[0000858877-15-000013:mdna:37]
[same as prior period, unchanged from 0000858877-14-000043:mdna:34]

[0000858877-15-000013:mdna:38]
[same as prior period, unchanged from 0000858877-14-000043:mdna:35]

[0000858877-15-000013:mdna:39]
[same as prior period, unchanged from 0000858877-14-000043:mdna:36]

[0000858877-15-000013:mdna:40]
[same as prior period, unchanged from 0000858877-14-000043:mdna:37]

[0000858877-15-000013:mdna:41]
[same as prior period, unchanged from 0000858877-14-000043:mdna:38]

[0000858877-15-000013:mdna:42]
[same as prior period, unchanged from 0000858877-14-000043:mdna:39]

[0000858877-15-000013:mdna:43]
[same as prior period, unchanged from 0000858877-14-000043:mdna:40]

[0000858877-15-000013:mdna:44]
As our business and offerings evolve over time, our pricing practices may be required to be modified accordingly, which could result in changes in selling prices, including both VSOE and ESP, in subsequent periods. There were no material impacts during the first six months of fiscal 2015, nor do we currently expect a material impact in the next 12 months on our revenue recognition due to any changes in our VSOE, TPE, or ESP.

[0000858877-15-000013:mdna:45]
45

[0000858877-15-000013:mdna:46]
[same as prior period, unchanged from 0000858877-14-000043:mdna:44]

[0000858877-15-000013:mdna:47]
[same as prior period, unchanged from 0000858877-14-000043:mdna:45]

[0000858877-15-000013:mdna:48]
Revenue deferrals relate to the timing of revenue recognition for specific transactions based on financing arrangements, service, support, and other factors. Financing arrangements may include sales-type, direct-financing, and operating leases, loans, and guarantees of third-party financing. Our deferred revenue for products was $5.0 billion and $4.5 billion as of January 24, 2015 and July 26, 2014, respectively. Technical support services revenue is deferred and recognized ratably over the period during which the services are to be performed, which typically is from one to three years. Advanced services revenue is recognized upon delivery or completion of performance. Our deferred revenue for services was $9.0 billion and $9.6 billion as of January 24, 2015 and July 26, 2014, respectively.

[0000858877-15-000013:mdna:49]
[same as prior period, unchanged from 0000858877-14-000043:mdna:47]

[0000858877-15-000013:mdna:50]
[same as prior period, unchanged from 0000858877-14-000043:mdna:48]

[0000858877-15-000013:mdna:51]
[same as prior period, unchanged from 0000858877-14-000043:mdna:49]

[0000858877-15-000013:mdna:52]
|  |  | January 24, 2015 |  | July 26, 2014 |
| Allowance for doubtful accounts |  | $ | 270 |  |  | $ | 265 |  |
| Percentage of gross accounts receivable |  | 5.6 | % |  | 4.9 | % |
| Allowance for credit loss—lease receivables |  | $ | 250 |  |  | $ | 233 |  |
| Percentage of gross lease receivables(1) |  | 7.0 | % |  | 6.2 | % |
| Allowance for credit loss—loan receivables |  | $ | 85 |  |  | $ | 98 |  |
| Percentage of gross loan receivables |  | 5.1 | % |  | 5.8 | % |

[0000858877-15-000013:mdna:53]
[same as prior period, unchanged from 0000858877-14-000043:mdna:51]

[0000858877-15-000013:mdna:54]
[same as prior period, unchanged from 0000858877-14-000043:mdna:52]

[0000858877-15-000013:mdna:55]
[same as prior period, unchanged from 0000858877-14-000043:mdna:53]

[0000858877-15-000013:mdna:56]
A reserve for future sales returns is established based on historical trends in product return rates. The reserve for future sales returns as of January 24, 2015 and July 26, 2014 was $90 million and $135 million, respectively, and was recorded as a reduction of our accounts receivable.  If the actual future returns were to deviate from the historical data on which the reserve had been established, our revenue could be adversely affected.

[0000858877-15-000013:mdna:57]
[same as prior period, unchanged from 0000858877-14-000043:mdna:58]

[0000858877-15-000013:mdna:58]
[same as prior period, unchanged from 0000858877-14-000043:mdna:59]

[0000858877-15-000013:mdna:59]
[same as prior period, unchanged from 0000858877-14-000043:mdna:55]

[0000858877-15-000013:mdna:60]
Our inventory balance was $1.9 billion and $1.6 billion as of January 24, 2015 and July 26, 2014, respectively. Inventory is written down based on excess and obsolete inventories, determined primarily by future demand forecasts. Inventory write-downs are measured as the difference between the cost of the inventory and market, based upon assumptions about future demand, and are charged to the provision for inventory, which is a component of our cost of sales. At the point of the loss recognition, a new, lower cost basis for that inventory is established, and subsequent changes in facts and circumstances do not result in the restoration or increase in that newly established cost basis.

[0000858877-15-000013:mdna:61]
We record a liability for firm, noncancelable, and unconditional purchase commitments with contract manufacturers and suppliers for quantities in excess of our future demand forecasts consistent with the valuation of our excess and obsolete inventory. As of January 24, 2015, the liability for these purchase commitments was $165 million, compared with $162 million as of July 26, 2014, and was included in other current liabilities.

[0000858877-15-000013:mdna:62]
Our provision for inventory was $21 million and $35 million for the first six months of fiscal 2015 and 2014, respectively. The provision for the liability related to purchase commitments with contract manufacturers and suppliers was $59 million and $78 million for the first six months of fiscal 2015 and 2014, respectively. If there were to be a sudden and significant decrease in demand for our products, or if there were a higher incidence of inventory obsolescence because of rapidly changing technology and customer requirements, we could be required to increase our inventory write-downs, and our liability for purchase commitments with contract manufacturers and suppliers, and accordingly our profitability, could be adversely affected. We regularly evaluate our exposure for inventory write-downs and the adequacy of our liability for purchase commitments. Inventory and supply chain management remain areas of focus as we balance the need to maintain supply chain flexibility to help ensure competitive lead times with the risk of inventory obsolescence, particularly in light of current macroeconomic uncertainties and conditions and the resulting potential for changes in future demand forecast.

[0000858877-15-000013:mdna:63]
Loss Contingencies and Product Warranties

[0000858877-15-000013:mdna:64]
We are subject to the possibility of various losses arising in the ordinary course of business. We consider the likelihood of impairment of an asset or the incurrence of a liability, as well as our ability to reasonably estimate the amount of loss, in determining loss contingencies. An estimated loss contingency is accrued when it is probable that an asset has been impaired or a liability has been incurred and the amount of loss can be reasonably estimated. We regularly evaluate information available to us to determine whether such accruals should be made or adjusted and whether new accruals are required.

[0000858877-15-000013:mdna:65]
Third parties, including customers, have in the past and may in the future assert claims or initiate litigation related to exclusive patent, copyright, trademark, and other intellectual property rights to technologies and related standards that are relevant to us. These assertions have increased over time as a result of our growth and the general increase in the pace of patent claims assertions, particularly in the United States. If any infringement or other intellectual property claim made against us by any third party is successful, or if we fail to develop non-infringing technology or license the proprietary rights on commercially reasonable terms and conditions, our business, operating results, and financial condition could be materially and adversely affected.

[0000858877-15-000013:mdna:66]
[same as prior period, unchanged from 0000858877-14-000043:mdna:65]

[0000858877-15-000013:mdna:67]
Our liability for product warranties, included in other current liabilities, was $474 million as of January 24, 2015, compared with $446 million as of July 26, 2014. Our products are generally covered by a warranty for periods ranging from 90 days to five years, and for some products we provide a limited lifetime warranty. We accrue for warranty costs as part of our cost of sales based on associated material costs, technical support labor costs, and associated overhead. Material cost is estimated based primarily upon historical trends in the volume of product returns within the warranty period and the cost to repair or replace the equipment. Technical support labor cost is estimated based primarily upon historical trends in the rate of customer cases and the cost to support the customer cases within the warranty period. Overhead cost is applied based on estimated time to support warranty activities.

[0000858877-15-000013:mdna:68]
The provision for product warranties during the first six months of fiscal 2015 and 2014 was $355 million and $356 million, respectively. If we experience an increase in warranty claims compared with our historical experience, or if the cost of servicing warranty claims is greater than expected, our profitability could be adversely affected.

[0000858877-15-000013:mdna:69]
47

[0000858877-15-000013:mdna:70]
[same as prior period, unchanged from 0000858877-14-000043:mdna:71]

[0000858877-15-000013:mdna:71]
[same as prior period, unchanged from 0000858877-14-000043:mdna:72]

[0000858877-15-000013:mdna:72]
[same as prior period, unchanged from 0000858877-14-000043:mdna:68]

[0000858877-15-000013:mdna:73]
Our fixed income and publicly traded equity securities, collectively, are reflected in the Consolidated Balance Sheets at a fair value of $48.2 billion as of January 24, 2015, compared with $45.3 billion as of July 26, 2014. Our fixed income investment portfolio as of January 24, 2015 consisted primarily of high quality investment-grade securities. See Note 8 to the Consolidated Financial Statements.

[0000858877-15-000013:mdna:74]
As described more fully in Note 9 to the Consolidated Financial Statements, a valuation hierarchy is based on the level of independent, objective evidence available regarding the value of the investments. It encompasses three classes of investments: Level 1 consists of securities for which there are quoted prices in active markets for identical securities; Level 2 consists of securities for which observable inputs other than Level 1 inputs are used, such as quoted prices for similar securities in active markets or quoted prices for identical securities in less active markets and model-derived valuations for which the variables are derived from, or corroborated by, observable market data; and Level 3 consists of securities for which there are unobservable inputs to the valuation methodology that are significant to the measurement of the fair value.

[0000858877-15-000013:mdna:75]
[same as prior period, unchanged from 0000858877-14-000043:mdna:74]

[0000858877-15-000013:mdna:76]
The inputs and fair value are reviewed for reasonableness, may be further validated by comparison to publicly available information, and could be adjusted based on market indices or other information that management deems material to its estimate of fair value. The assessment of fair value can be difficult and subjective. However, given the relative reliability of the inputs we use to value our investment portfolio, and because substantially all of our valuation inputs are obtained using quoted market prices for similar or identical assets, we do not believe that the nature of estimates and assumptions affected by levels of subjectivity and judgment was material to the valuation of the investment portfolio as of January 24, 2015. We had no Level 3 assets measured at fair value on a recurring basis as of January 24, 2015.

[0000858877-15-000013:mdna:77]
[same as prior period, unchanged from 0000858877-14-000043:mdna:76]

[0000858877-15-000013:mdna:78]
[same as prior period, unchanged from 0000858877-14-000043:mdna:77]

[0000858877-15-000013:mdna:79]
[same as prior period, unchanged from 0000858877-14-000043:mdna:78]

[0000858877-15-000013:mdna:80]
[same as prior period, unchanged from 0000858877-14-000043:mdna:79]

[0000858877-15-000013:mdna:81]
There were no impairment charges on our investments in publicly traded equity securities in the first six months of fiscal 2015, while $11 million of such impairment charges were recognized in earnings for the first six months of fiscal 2014.  There were no impairment charges on our investments in fixed income securities in the first six months of fiscal 2015 and 2014. Our ongoing consideration of all the factors described previously could result in additional impairment charges in the future, which could adversely affect our net income.

[0000858877-15-000013:mdna:82]
[same as prior period, unchanged from 0000858877-14-000043:mdna:84]

[0000858877-15-000013:mdna:83]
[same as prior period, unchanged from 0000858877-14-000043:mdna:85]

[0000858877-15-000013:mdna:84]
We also have investments in privately held companies, some of which are in the startup or development stages. Our investments in privately held companies as of January 24, 2015 were $857 million, compared with $899 million as of July 26, 2014, and were included in other assets. We monitor these investments for events or circumstances indicative of potential impairment, and we make appropriate reductions in carrying values if we determine that an impairment charge is required, based primarily on the financial condition and near-term prospects of these companies. These investments are inherently risky because the markets for the technologies or products these companies are developing are typically in the early stages and may never materialize. Our impairment charges on investments in privately held companies were $3 million and $10 million for the first six months of fiscal 2015 and 2014, respectively.

[0000858877-15-000013:mdna:85]
[same as prior period, unchanged from 0000858877-14-000043:mdna:82]

[0000858877-15-000013:mdna:86]
[same as prior period, unchanged from 0000858877-14-000043:mdna:83]

[0000858877-15-000013:mdna:87]
The goodwill recorded in the Consolidated Balance Sheets as of January 24, 2015 and July 26, 2014 was $24.4 billion and $24.2 billion, respectively.  In response to changes in industry and market conditions, we could be required to strategically realign our resources and consider restructuring, disposing of, or otherwise exiting businesses, which could result in an impairment of goodwill. There was no impairment of goodwill in the first six months of fiscal 2015 and 2014.

[0000858877-15-000013:mdna:88]
We make judgments about the recoverability of purchased intangible assets with finite lives whenever events or changes in circumstances indicate that an impairment may exist. Recoverability of purchased intangible assets with finite lives is measured by comparing the carrying amount of the asset to the future undiscounted cash flows the asset is expected to generate. We review indefinite-lived intangible assets for impairment annually or whenever events or changes in circumstances indicate that the asset might be impaired. If the asset is considered to be impaired, the amount of any impairment is measured as the difference between the carrying value and the fair value of the impaired asset. Assumptions and estimates about future values and remaining useful lives of our purchased intangible assets are complex and subjective. They can be affected by a variety of factors, including external factors such as industry and economic trends, and internal factors such as changes in our business strategy and our internal forecasts. For the first six months of fiscal 2015, impairment charges of $56 million on purchased intangible assets were recognized in earnings, while there were no such impairment charges in the first six months of fiscal 2014. Our ongoing consideration of all the factors described previously could result in additional impairment charges in the future, which could adversely affect our net income.

[0000858877-15-000013:mdna:89]
[same as prior period, unchanged from 0000858877-14-000043:mdna:88]

[0000858877-15-000013:mdna:90]
We are subject to income taxes in the United States and numerous foreign jurisdictions. Our effective tax rates differ from the statutory rate, primarily due to the tax impact of state taxes, foreign operations, R&D tax credits, domestic manufacturing deductions, tax audit settlements, nondeductible compensation, international realignments, and transfer pricing adjustments. Our effective tax rate was 16.6% and 18.6% in the second quarter of fiscal 2015 and 2014, respectively.  Our effective tax rate was 19.3% and 20.3% in the first six months of fiscal 2015 and 2014, respectively.

[0000858877-15-000013:mdna:91]
[same as prior period, unchanged from 0000858877-14-000043:mdna:90]

[0000858877-15-000013:mdna:92]
[same as prior period, unchanged from 0000858877-14-000043:mdna:91]

[0000858877-15-000013:mdna:93]
[same as prior period, unchanged from 0000858877-14-000043:mdna:93]

[0000858877-15-000013:mdna:94]
[same as prior period, unchanged from 0000858877-14-000043:mdna:94]

[0000858877-15-000013:mdna:95]
[same as prior period, unchanged from 0000858877-14-000043:mdna:92]

[0000858877-15-000013:mdna:96]
50

[0000858877-15-000013:mdna:97]
[same as prior period, unchanged from 0000858877-14-000043:mdna:106]

[0000858877-15-000013:mdna:98]
[same as prior period, unchanged from 0000858877-14-000043:mdna:107]

[0000858877-15-000013:mdna:99]
[same as prior period, unchanged from 0000858877-14-000043:mdna:95]

[0000858877-15-000013:mdna:100]
[same as prior period, unchanged from 0000858877-14-000043:mdna:96]

[0000858877-15-000013:mdna:101]
[same as prior period, unchanged from 0000858877-14-000043:mdna:97]

[0000858877-15-000013:mdna:102]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 24, 2015 |  | January 25, 2014 |  | Variancein Dollars |  | Variance in Percent |  | January 24, 2015 |  | January 25, 2014 |  | Variancein Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 9,078 |  |  | $ | 8,423 |  |  | $ | 655 |  |  | 7.8 | % |  | $ | 18,513 |  |  | $ | 17,820 |  |  | $ | 693 |  |  | 3.9 | % |
| Percentage of revenue |  | 76.1 | % |  | 75.5 | % |  |  |  |  |  |  |  | 76.6 | % |  | 76.7 | % |  |  |  |  |  |  |
| Service |  | 2,858 |  |  | 2,732 |  |  | 126 |  |  | 4.6 | % |  | 5,668 |  |  | 5,420 |  |  | 248 |  |  | 4.6 | % |
| Percentage of revenue |  | 23.9 | % |  | 24.5 | % |  |  |  |  |  |  |  | 23.4 | % |  | 23.3 | % |  |  |  |  |  |  |
| Total |  | $ | 11,936 |  |  | $ | 11,155 |  |  | $ | 781 |  |  | 7.0 | % |  | $ | 24,181 |  |  | $ | 23,240 |  |  | $ | 941 |  |  | 4.0 | % |

[0000858877-15-000013:mdna:103]
[same as prior period, unchanged from 0000858877-14-000043:mdna:99]

[0000858877-15-000013:mdna:104]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 24, 2015 |  | January 25, 2014 |  | Variancein Dollars |  | Variance in Percent |  | January 24, 2015 |  | January 25, 2014 |  | Variancein Dollars |  | Variance in Percent |
| Revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 7,101 |  |  | $ | 6,460 |  |  | $ | 641 |  |  | 9.9 | % |  | $ | 14,602 |  |  | $ | 13,776 |  |  | $ | 826 |  |  | 6.0 | % |
| Percentage of revenue |  | 59.5 | % |  | 57.9 | % |  |  |  |  |  | 60.4 | % |  | 59.3 | % |  |  |  |  |
| EMEA |  | 3,091 |  |  | 2,896 |  |  | 195 |  |  | 6.7 | % |  | 6,093 |  |  | 5,829 |  |  | 264 |  |  | 4.5 | % |
| Percentage of revenue |  | 25.9 | % |  | 26.0 | % |  |  |  |  |  | 25.2 | % |  | 25.1 | % |  |  |  |  |
| APJC |  | 1,744 |  |  | 1,799 |  |  | (55 | ) |  | (3.1 | )% |  | 3,486 |  |  | 3,635 |  |  | (149 | ) |  | (4.1 | )% |
| Percentage of revenue |  | 14.6 | % |  | 16.1 | % |  |  |  |  |  | 14.4 | % |  | 15.6 | % |  |  |  |  |
| Total |  | $ | 11,936 |  |  | $ | 11,155 |  |  | $ | 781 |  |  | 7.0 | % |  | $ | 24,181 |  |  | $ | 23,240 |  |  | $ | 941 |  |  | 4.0 | % |

[0000858877-15-000013:mdna:105]
Three Months Ended January 24, 2015 Compared with Three Months Ended January 25, 2014

[0000858877-15-000013:mdna:106]
For the second quarter of fiscal 2015, as compared with the second quarter of fiscal 2014, total revenue increased by 7%.  Product revenue increased by 8%, while service revenue increased by 5%.  Our total revenue reflected growth in our Americas and EMEA geographic segments, while revenue declined in the APJC segment. The emerging countries of BRICM, in the aggregate, experienced a slower product revenue growth of 2%, with growth in Brazil, India, and Mexico, partially offset by decreases in the other two countries.

[0000858877-15-000013:mdna:107]
We conduct business globally in numerous currencies. The direct effect of foreign currency fluctuations on revenue has not been material because our revenue is primarily denominated in U.S. dollars. However, if the U.S. dollar strengthens relative to other currencies, such strengthening could have an indirect effect on our revenue to the extent it raises the cost of our products to non-U.S. customers and thereby reduces demand. A weaker U.S. dollar could have the opposite effect. However, the precise indirect effect of currency fluctuations is difficult to measure or predict because our revenue is influenced by many factors in addition to the impact of such currency fluctuations. It is possible that our revenue in the second quarter of fiscal 2015 may have been adversely affected by the depreciation of the local currency relative to the U.S. dollar, although as noted above, such indirect effects are difficult to measure.

[0000858877-15-000013:mdna:108]
In addition to the impact of macroeconomic factors, revenue by segment in a particular period may be significantly impacted by several factors related to revenue recognition, including the complexity of transactions such as multiple-element arrangements; the mix of financing arrangements provided to our channel partners and customers; and final acceptance of the product, system, or solution, among other factors. In addition, certain customers tend to make large and sporadic purchases, and the revenue related to these transactions may also be affected by the timing of revenue recognition, which in turn would impact the revenue of the relevant segment. As has been the case in certain of our emerging countries from time to time, customers require greater levels of financing arrangements, service, and support, and these activities may occur in future periods, which may also impact the timing of the recognition of revenue.

[0000858877-15-000013:mdna:109]
[same as prior period, unchanged from 0000858877-14-000043:mdna:118]

[0000858877-15-000013:mdna:110]
[same as prior period, unchanged from 0000858877-14-000043:mdna:119]

[0000858877-15-000013:mdna:111]
Six Months Ended January 24, 2015 Compared with Six Months Ended January 25, 2014

[0000858877-15-000013:mdna:112]
For the first six months of fiscal 2015, as compared with the first six months of fiscal 2014, total revenue increased by 4%.  Product revenue increased 4%, while service revenue increased by 5%.  Our total revenue reflected growth in our Americas and EMEA geographic segments, while revenue declined in the APJC segment. The emerging countries of BRICM, in the aggregate, experienced a 3% product revenue decline, with declines in China and Russia, partially offset by increases in the other three countries.

[0000858877-15-000013:mdna:113]
[same as prior period, unchanged from 0000858877-14-000043:mdna:108]

[0000858877-15-000013:mdna:114]
[same as prior period, unchanged from 0000858877-14-000043:mdna:109]

[0000858877-15-000013:mdna:115]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 24, 2015 |  | January 25, 2014 |  | Variancein Dollars |  | Variance in Percent |  | January 24, 2015 |  | January 25, 2014 |  | Variancein Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 5,243 |  |  | $ | 4,676 |  |  | $ | 567 |  |  | 12.1 | % |  | $ | 10,927 |  |  | $ | 10,209 |  |  | $ | 718 |  |  | 7.0 | % |
| Percentage of product revenue |  | 57.8 | % |  | 55.6 | % |  |  |  |  |  | 59.1 | % |  | 57.3 | % |  |  |  |  |
| EMEA |  | 2,480 |  |  | 2,328 |  |  | 152 |  |  | 6.5 | % |  | 4,876 |  |  | 4,709 |  |  | 167 |  |  | 3.5 | % |
| Percentage of product revenue |  | 27.3 | % |  | 27.6 | % |  |  |  |  |  | 26.3 | % |  | 26.4 | % |  |  |  |  |
| APJC |  | 1,355 |  |  | 1,419 |  |  | (64 | ) |  | (4.5 | )% |  | 2,710 |  |  | 2,902 |  |  | (192 | ) |  | (6.6 | )% |
| Percentage of product revenue |  | 14.9 | % |  | 16.8 | % |  |  |  |  |  | 14.6 | % |  | 16.3 | % |  |  |  |  |
| Total |  | $ | 9,078 |  |  | $ | 8,423 |  |  | $ | 655 |  |  | 7.8 | % |  | $ | 18,513 |  |  | $ | 17,820 |  |  | $ | 693 |  |  | 3.9 | % |

[0000858877-15-000013:mdna:116]
[same as prior period, unchanged from 0000858877-14-000043:mdna:112]

[0000858877-15-000013:mdna:117]
Three Months Ended January 24, 2015 Compared with Three Months Ended January 25, 2014

[0000858877-15-000013:mdna:118]
Product revenue in the Americas segment increased by 12%, led by strong growth in the public sector market and solid growth in the enterprise and commercial markets. Product revenue increased in the U.S. public sector market, led by higher sales to the U.S. federal government and, to a lesser extent, higher sales to state and local governments. Within the Americas segment, we continued to experience a product revenue decline in the service provider market.  From a country perspective, product revenue increased by 12% in the United States, 44% in Brazil, 26% in Mexico and 1% in Canada.

[0000858877-15-000013:mdna:119]
Six Months Ended January 24, 2015 Compared with Six Months Ended January 25, 2014

[0000858877-15-000013:mdna:120]
The increase in product revenue in the Americas segment of 7% was led by solid growth in the public sector, enterprise and commercial markets. The product revenue growth in the public sector market was due primarily to higher sales to the U.S. federal government and, to a lesser extent, higher sales to state and local governments.  Product revenue decreased in the service provider market. From a country perspective, product revenue increased by 7% in the United States, 24% in Brazil, 19% in Mexico and 1% in Canada.

[0000858877-15-000013:mdna:121]
[same as prior period, unchanged from 0000858877-14-000043:mdna:114]

[0000858877-15-000013:mdna:122]
Three Months Ended January 24, 2015 Compared with Three Months Ended January 25, 2014

[0000858877-15-000013:mdna:123]
Product revenue in the EMEA segment increased by 7%, led by growth in the enterprise and commercial markets, and to a lesser extent, growth in the service provider market.  We experienced a slight product revenue decline in the public sector market.  Product revenue from emerging countries within EMEA increased by 2% and product revenue for the remainder of EMEA, which primarily consists of countries in Western Europe, grew by 8%.

[0000858877-15-000013:mdna:124]
Six Months Ended January 24, 2015 Compared with Six Months Ended January 25, 2014

[0000858877-15-000013:mdna:125]
Product revenue in the EMEA segment increased by 4%, driven by growth in the commercial market and, to a lesser degree, in the enterprise and service provider markets. We experienced a slight product revenue decline in the public sector market. Product revenue from emerging countries within EMEA decreased by 2%, led by a 20% decrease in Russia. Product revenue for the remainder of EMEA grew by 6%.

[0000858877-15-000013:mdna:126]
[same as prior period, unchanged from 0000858877-14-000043:mdna:151]

[0000858877-15-000013:mdna:127]
[same as prior period, unchanged from 0000858877-14-000043:mdna:130]

[0000858877-15-000013:mdna:128]
[same as prior period, unchanged from 0000858877-14-000043:mdna:131]

[0000858877-15-000013:mdna:129]
[same as prior period, unchanged from 0000858877-14-000043:mdna:116]

[0000858877-15-000013:mdna:130]
Three Months Ended January 24, 2015 Compared with Three Months Ended January 25, 2014

[0000858877-15-000013:mdna:131]
The decrease in product revenue in the APJC segment of 5% was led by a significant decline in the service provider market and, to a lesser extent, in the public sector market.  These decreases were partially offset by solid growth in the commercial and enterprise markets. From a country perspective, we experienced year-over-year product revenue declines of 20% in China and 10% in Japan. These decreases were partially offset by product revenue growth of 21% in India and 3% in Australia.

[0000858877-15-000013:mdna:132]
Six Months Ended January 24, 2015 Compared with Six Months Ended January 25, 2014

[0000858877-15-000013:mdna:133]
Product revenue in the APJC segment decreased by 7%.  The product revenue decline was led by a significant decline in the service provider market and, to a lesser degree, in the public sector market.  These decreases were partially offset by slow growth in the commercial and enterprise markets. From a country perspective, product revenue decreased by 22% in China, 7% in Japan and 5% in Australia. We experienced product revenue growth of 25% in India.

[0000858877-15-000013:mdna:134]
[same as prior period, unchanged from 0000858877-14-000043:mdna:144]

[0000858877-15-000013:mdna:135]
[same as prior period, unchanged from 0000858877-14-000043:mdna:145]

[0000858877-15-000013:mdna:136]
[same as prior period, unchanged from 0000858877-14-000043:mdna:120]

[0000858877-15-000013:mdna:137]
In addition to the primary view on a geographic basis, we also prepare financial information related to groups of similar products and customer markets for various purposes. Our product categories consist of the following categories (with subcategories in parentheses): Switching (fixed switching, modular switching, and storage); NGN Routing (high-end routers, mid-range and low-end routers, and other NGN Routing products); Collaboration (unified communications, Cisco TelePresence, and conferencing); Service Provider Video (infrastructure, video software, and solutions and cable access); Data Center; Wireless; Security; and Other Products. The Other Products category consists primarily of emerging technology products and other networking products.

[0000858877-15-000013:mdna:138]
[same as prior period, unchanged from 0000858877-14-000043:mdna:122]

[0000858877-15-000013:mdna:139]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 24, 2015 |  | January 25, 2014 |  | Variancein Dollars |  | Variance in Percent |  | January 24, 2015 |  | January 25, 2014 |  | Variancein Dollars |  | Variance in Percent |
| Product revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Switching |  | $ | 3,616 |  |  | $ | 3,258 |  |  | $ | 358 |  |  | 11.0 | % |  | $ | 7,462 |  |  | $ | 6,998 |  |  | $ | 464 |  |  | 6.6 | % |
| Percentage of product revenue |  | 39.8 | % |  | 38.7 | % |  |  |  |  |  |  |  | 40.3 | % |  | 39.3 | % |  |  |  |  |  |  |
| NGN Routing |  | 1,764 |  |  | 1,730 |  |  | 34 |  |  | 2.0 | % |  | 3,713 |  |  | 3,756 |  |  | (43 | ) |  | (1.1 | )% |
| Percentage of product revenue |  | 19.4 | % |  | 20.5 | % |  |  |  |  |  |  |  | 20.1 | % |  | 21.1 | % |  |  |  |  |  |  |
| Collaboration |  | 990 |  |  | 899 |  |  | 91 |  |  | 10.1 | % |  | 1,939 |  |  | 1,950 |  |  | (11 | ) |  | (0.6 | )% |
| Percentage of product revenue |  | 10.9 | % |  | 10.7 | % |  |  |  |  |  |  |  | 10.5 | % |  | 10.9 | % |  |  |  |  |  |  |
| Service Provider Video |  | 776 |  |  | 957 |  |  | (181 | ) |  | (18.9 | )% |  | 1,647 |  |  | 1,944 |  |  | (297 | ) |  | (15.3 | )% |
| Percentage of product revenue |  | 8.5 | % |  | 11.4 | % |  |  |  |  |  |  |  | 8.9 | % |  | 10.9 | % |  |  |  |  |  |  |
| Data Center |  | 846 |  |  | 605 |  |  | 241 |  |  | 39.8 | % |  | 1,539 |  |  | 1,206 |  |  | 333 |  |  | 27.6 | % |
| Percentage of product revenue |  | 9.3 | % |  | 7.2 | % |  |  |  |  |  | 8.3 | % |  | 6.8 | % |  |  |  |  |
| Wireless |  | 611 |  |  | 517 |  |  | 94 |  |  | 18.2 | % |  | 1,216 |  |  | 1,064 |  |  | 152 |  |  | 14.3 | % |
| Percentage of product revenue |  | 6.7 | % |  | 6.1 | % |  |  |  |  |  |  |  | 6.6 | % |  | 6.0 | % |  |  |  |  |  |  |
| Security |  | 416 |  |  | 393 |  |  | 23 |  |  | 5.9 | % |  | 871 |  |  | 758 |  |  | 113 |  |  | 14.9 | % |
| Percentage of product revenue |  | 4.6 | % |  | 4.7 | % |  |  |  |  |  |  |  | 4.7 | % |  | 4.3 | % |  |  |  |  |  |  |
| Other |  | 59 |  |  | 64 |  |  | (5 | ) |  | (7.8 | )% |  | 126 |  |  | 144 |  |  | (18 | ) |  | (12.5 | )% |
| Percentage of product revenue |  | 0.8 | % |  | 0.7 | % |  |  |  |  |  |  |  | 0.6 | % |  | 0.7 | % |  |  |  |  |  |  |
| Total |  | $ | 9,078 |  |  | $ | 8,423 |  |  | $ | 655 |  |  | 7.8 | % |  | $ | 18,513 |  |  | $ | 17,820 |  |  | $ | 693 |  |  | 3.9 | % |

[0000858877-15-000013:mdna:140]
[same as prior period, unchanged from 0000858877-14-000043:mdna:124]

[0000858877-15-000013:mdna:141]
[same as prior period, unchanged from 0000858877-14-000043:mdna:126]

[0000858877-15-000013:mdna:142]
Three Months Ended January 24, 2015 Compared with Three Months Ended January 25, 2014

[0000858877-15-000013:mdna:143]
Revenue in our Switching product category increased by 11%, or $358 million, driven by a 17%, or $337 million, increase in revenue from our LAN fixed-configuration switches. Revenue from our LAN fixed-configuration switches increased due to the continued adoption of Cisco Catalyst 3650 Series Switches and Cisco Catalyst 3850 Series Switches. Higher revenue from fixed-configuration Cisco Nexus Series Switches also contributed to the increase. We also experienced a 31%, or $36 million, increase in sales of storage products within this category. Partially offsetting these increases was a decrease in revenue from our modular switches of 1%, or $15 million, driven by lower sales of Cisco Nexus 7000 Series Switches and Cisco Catalyst 6500-E Series Switches.

[0000858877-15-000013:mdna:144]
[same as prior period, unchanged from 0000858877-14-000043:mdna:152]

[0000858877-15-000013:mdna:145]
[same as prior period, unchanged from 0000858877-14-000043:mdna:153]

[0000858877-15-000013:mdna:146]
Six Months Ended January 24, 2015 Compared with Six Months Ended January 25, 2014

[0000858877-15-000013:mdna:147]
The increase in revenue in our Switching product category of 7%, or $464 million, was driven by a 12%, or $507 million, increase in revenue from our LAN fixed-configuration switches and, to a lesser extent, a 45%, or $96 million, increase in sales of storage products. Revenue from LAN fixed-configuration switches increased due to higher sales of most of our Cisco Nexus Series Switches and Cisco Catalyst Series Switches within this category. We experienced a decrease in revenue from our modular switches of 6%, or $139 million, driven by lower sales of Cisco Catalyst 6500-E Series Switches and Cisco Nexus 7000 Series Switches.

[0000858877-15-000013:mdna:148]
[same as prior period, unchanged from 0000858877-14-000043:mdna:128]

[0000858877-15-000013:mdna:149]
Three Months Ended January 24, 2015 Compared with Three Months Ended January 25, 2014

[0000858877-15-000013:mdna:150]
The increase in revenue in our NGN Routing product category of 2%, or $34 million, was driven by a 5%, or $53 million, increase in revenue from our high-end router products and a 3%, or $19 million, increase in revenue from our midrange and low-end router products. These increases were partially offset by a 28%, or $38 million, decrease in revenue from what we categorize as other NGN Routing products. Within the high-end router product category, we experienced increased sales of most of our products within our Cisco Aggregation Services Routers category and the adoption of our Cisco Network Convergence System platform partially offset by lower sales of Cisco Carrier Routing System products and our legacy high-end router products. The increase in revenue from our midrange and low-end router products was due to higher sales of our Cisco Integrated Services Routers products.   Revenue from other NGN Routing products decreased due to lower sales of certain optical networking products.

[0000858877-15-000013:mdna:151]
Six Months Ended January 24, 2015 Compared with Six Months Ended January 25, 2014

[0000858877-15-000013:mdna:152]
Revenue in our NGN Routing product category decreased by 1%, or $43 million, driven by a 34%, or $108 million, decrease in revenue from other NGN Routing products and a 2%, or $31 million, decrease in revenue from our midrange and low-end router products. These decreases were partially offset by a 4%, or $96 million, increase in revenue from our high-end router products.  Revenue from other NGN Routing products decreased due to lower sales of certain optical networking products. The decrease in revenue from our midrange and low-end router products was due to lower sales of certain of our access products, partially offset by higher sales of our Cisco Integrated Services Routers products. Revenue from high-end router product increased due to an increase in revenue from most of our products within our Cisco Aggregation Services Routers category and the adoption of our Cisco Network Convergence System platform, partially offset by lower sales of Cisco Carrier Routing System products and our legacy high-end router products.

[0000858877-15-000013:mdna:153]
[same as prior period, unchanged from 0000858877-14-000043:mdna:132]

[0000858877-15-000013:mdna:154]
Three Months Ended January 24, 2015 Compared with Three Months Ended January 25, 2014

[0000858877-15-000013:mdna:155]
Overall, revenue in our Collaboration product category increased by 10%, or $91 million, primarily due to increased revenue from our Unified Communications and Cisco TelePresence products, driven by higher revenue in endpoint products as a result of new product introductions. These increases were partially offset by decreased revenue from our conferencing products. We continue to increase the amount of deferred revenue related to our Collaboration product category.

[0000858877-15-000013:mdna:156]
Six Months Ended January 24, 2015 Compared with Six Months Ended January 25, 2014

[0000858877-15-000013:mdna:157]
Revenue in our Collaboration product category decreased by 1%, or $11 million, primarily due to decreased revenue from our Cisco TelePresence products and, to a lesser extent, a slight decrease in revenue from our conferencing products, partially offset by increased revenue from our Unified Communications products.

[0000858877-15-000013:mdna:158]
[same as prior period, unchanged from 0000858877-14-000043:mdna:134]

[0000858877-15-000013:mdna:159]
Three Months Ended January 24, 2015 Compared with Three Months Ended January 25, 2014

[0000858877-15-000013:mdna:160]
Revenue in our Service Provider Video product category decreased by 19%, or $181 million,  driven by a decrease in sales of our Service Provider Video infrastructure products. The revenue decline in Service Provider Video infrastructure products was due primarily to lower sales of set-top boxes.

[0000858877-15-000013:mdna:161]
Six Months Ended January 24, 2015 Compared with Six Months Ended January 25, 2014

[0000858877-15-000013:mdna:162]
The decrease in revenue from our Service Provider Video product category of 15%, or $297 million, was driven by a 25%, or $269 million, decrease in sales of our Service Provider Video infrastructure products, due primarily to lower sales of set-top boxes. We also experienced a decrease in revenue from cable access products within this product category.

[0000858877-15-000013:mdna:163]
55

[0000858877-15-000013:mdna:164]
[same as prior period, unchanged from 0000858877-14-000043:mdna:166]

[0000858877-15-000013:mdna:165]
[same as prior period, unchanged from 0000858877-14-000043:mdna:167]

[0000858877-15-000013:mdna:166]
[same as prior period, unchanged from 0000858877-14-000043:mdna:136]

[0000858877-15-000013:mdna:167]
Three Months Ended January 24, 2015 Compared with Three Months Ended January 25, 2014

[0000858877-15-000013:mdna:168]
We continued to experience solid growth in our Data Center product category, which grew by 40%, or $241 million, with sales growth of our Cisco Unified Computing System products occurring across all geographic segments and customer markets. The increase was due in large part to the continued momentum we are experiencing in both data center and cloud environments, as current customers increase their data center build-outs and as new customers deploy these offerings.

[0000858877-15-000013:mdna:169]
Six Months Ended January 24, 2015 Compared with Six Months Ended January 25, 2014

[0000858877-15-000013:mdna:170]
We experienced solid growth in our Data Center product category, which grew by 28%, or $333 million, with sales growth of our Cisco Unified Computing System products occurring across all geographic segments and customer markets. The increase in this product category was driven by similar factors as discussed in the three month period immediately above.

[0000858877-15-000013:mdna:171]
[same as prior period, unchanged from 0000858877-14-000043:mdna:138]

[0000858877-15-000013:mdna:172]
Three Months Ended January 24, 2015 Compared with Three Months Ended January 25, 2014

[0000858877-15-000013:mdna:173]
Revenue in our Wireless product category increased by 18%, or $94 million, driven by continued growth in Meraki combined with continued strength in our 802.11ac portfolio. We continue to increase the proportion of recurring revenue in our Wireless product category.

[0000858877-15-000013:mdna:174]
Six Months Ended January 24, 2015 Compared with Six Months Ended January 25, 2014

[0000858877-15-000013:mdna:175]
Revenue in our Wireless product category increased by 14%, or $152 million, due primarily to higher sales of Meraki products and 802.11ac products.

[0000858877-15-000013:mdna:176]
[same as prior period, unchanged from 0000858877-14-000043:mdna:140]

[0000858877-15-000013:mdna:177]
Three Months Ended January 24, 2015 Compared with Three Months Ended January 25, 2014

[0000858877-15-000013:mdna:178]
Revenue in our Security product category experienced growth of 6%, or $23 million, driven by higher Network Security sales as a result of product integration with Sourcefire, which we acquired in the first quarter of fiscal 2014.  This increase was partially offset by decrease in revenue from our Content Security products due to lower sales of Web and E-mail security products. Our software and subscription sales continue to drive an increase in the proportion of recurring revenue in our Security product category.

[0000858877-15-000013:mdna:179]
Six Months Ended January 24, 2015 Compared with Six Months Ended January 25, 2014

[0000858877-15-000013:mdna:180]
Revenue in our Security product category was up 15%, or $113 million, driven primarily by sales of Sourcefire products and, to a lesser extent, by higher sales of our high-end Firewall products within our Network Security product portfolio.

[0000858877-15-000013:mdna:181]
[same as prior period, unchanged from 0000858877-14-000043:mdna:142]

[0000858877-15-000013:mdna:182]
We experienced a year-over-year decrease in revenue in our Other Products category for the second quarter and first six months of fiscal 2015 due in large part to the decrease in sales of our other networking products.

[0000858877-15-000013:mdna:183]
[same as prior period, unchanged from 0000858877-14-000043:mdna:205]

[0000858877-15-000013:mdna:184]
[same as prior period, unchanged from 0000858877-14-000043:mdna:182]

[0000858877-15-000013:mdna:185]
[same as prior period, unchanged from 0000858877-14-000043:mdna:183]

[0000858877-15-000013:mdna:186]
[same as prior period, unchanged from 0000858877-14-000043:mdna:146]

[0000858877-15-000013:mdna:187]
[same as prior period, unchanged from 0000858877-14-000043:mdna:147]

[0000858877-15-000013:mdna:188]
|  | Three Months Ended |  | Six Months Ended |
|  | January 24, 2015 |  | January 25, 2014 |  | Variancein Dollars |  | Variance in Percent |  | January 24, 2015 |  | January 25, 2014 |  | Variancein Dollars |  | Variance in Percent |
| Service revenue: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas | $ | 1,858 |  |  | $ | 1,784 |  |  | $ | 74 |  |  | 4.1 | % |  | $ | 3,675 |  |  | $ | 3,567 |  |  | $ | 108 |  |  | 3.0 | % |
| Percentage of service revenue | 65.0 | % |  | 65.3 | % |  |  |  |  |  | 64.8 | % |  | 65.8 | % |  |  |  |  |
| EMEA | 611 |  |  | 568 |  |  | 43 |  |  | 7.6 | % |  | 1,217 |  |  | 1,120 |  |  | 97 |  |  | 8.7 | % |
| Percentage of service revenue | 21.4 | % |  | 20.8 | % |  |  |  |  |  | 21.5 | % |  | 20.7 | % |  |  |  |  |
| APJC | 389 |  |  | 380 |  |  | 9 |  |  | 2.4 | % |  | 776 |  |  | 733 |  |  | 43 |  |  | 5.9 | % |
| Percentage of service revenue | 13.6 | % |  | 13.9 | % |  |  |  |  |  | 13.7 | % |  | 13.5 | % |  |  |  |  |
| Total | $ | 2,858 |  |  | $ | 2,732 |  |  | $ | 126 |  |  | 4.6 | % |  | $ | 5,668 |  |  | $ | 5,420 |  |  | $ | 248 |  |  | 4.6 | % |

[0000858877-15-000013:mdna:189]
Three Months Ended January 24, 2015 Compared with Three Months Ended January 25, 2014

[0000858877-15-000013:mdna:190]
Service revenue increased across all of our geographic segments. Worldwide technical support services revenue increased by 4% and worldwide advanced services revenue increased by 6%, driven by growth in subscription revenues. Technical support service revenue experienced growth across all geographic segments, led by growth in our EMEA segment. Renewals and technical support service contract initiations associated with product sales provided an installed base of equipment being serviced which, in concert with new service offerings, were the primary factors driving the revenue increases. Advanced services revenue, which relates to consulting support services for specific customer network needs, grew across all geographic segments, led by solid growth in our EMEA segment.

[0000858877-15-000013:mdna:191]
Six Months Ended January 24, 2015 Compared with Six Months Ended January 25, 2014

[0000858877-15-000013:mdna:192]
Service revenue grew by 5%, with growth across all of our geographic segments. Worldwide technical support services revenue increased by 5% and worldwide advanced services experienced 4% revenue growth. Technical support services revenue grew across all geographic segments, led by growth in our EMEA segment. Advanced services revenue also grew across all geographic segments, led by solid growth in our EMEA segment.

[0000858877-15-000013:mdna:193]
[same as prior period, unchanged from 0000858877-14-000043:mdna:189]

[0000858877-15-000013:mdna:194]
[same as prior period, unchanged from 0000858877-14-000043:mdna:190]

[0000858877-15-000013:mdna:195]
[same as prior period, unchanged from 0000858877-14-000043:mdna:154]

[0000858877-15-000013:mdna:196]
[same as prior period, unchanged from 0000858877-14-000043:mdna:155]

[0000858877-15-000013:mdna:197]
|  | Three Months Ended |  | Six Months Ended |
|  | AMOUNT |  | PERCENTAGE |  | AMOUNT |  | PERCENTAGE |
|  | January 24, 2015 |  | January 25, 2014 |  | January 24, 2015 |  | January 25, 2014 |  | January 24, 2015 |  | January 25, 2014 |  | January 24, 2015 |  | January 25, 2014 |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product | $ | 5,272 |  |  | $ | 4,100 |  |  | 58.1 | % |  | 48.7 | % |  | $ | 10,788 |  |  | $ | 9,750 |  |  | 58.3 | % |  | 54.7 | % |
| Service | 1,818 |  |  | 1,851 |  |  | 63.6 | % |  | 67.8 | % |  | 3,635 |  |  | 3,608 |  |  | 64.1 | % |  | 66.6 | % |
| Total | $ | 7,090 |  |  | $ | 5,951 |  |  | 59.4 | % |  | 53.3 | % |  | $ | 14,423 |  |  | $ | 13,358 |  |  | 59.6 | % |  | 57.5 | % |

[0000858877-15-000013:mdna:198]
[same as prior period, unchanged from 0000858877-14-000043:mdna:157]

[0000858877-15-000013:mdna:199]
The following table summarizes the key factors that contributed to the change in product gross margin percentage for the second quarter and first six months of fiscal 2015 as compared with the corresponding prior year periods:

[0000858877-15-000013:mdna:200]
|  |  | Product Gross Margin Percentage |
|  |  | Three Months Ended |  | Six Months Ended |
| Fiscal 2014 |  | 48.7 | % |  | 54.7 | % |
| Supplier component remediation charge |  | 7.8 | % |  | 3.7 | % |
| Productivity (1) |  | 3.6 | % |  | 2.8 | % |
| Mix of products sold |  | 1.4 | % |  | 1.1 | % |
| Product pricing |  | (3.0 | )% |  | (2.7 | )% |
| Amortization of purchased intangible assets |  | (0.4 | )% |  | (0.3 | )% |
| Rockstar patent portfolio charge |  | — | % |  | (1.0 | )% |
| Fiscal 2015 |  | 58.1 | % |  | 58.3 | % |

[0000858877-15-000013:mdna:201]
(1) Productivity includes overall manufacturing-related costs, such as component costs, warranty expense, provisions for inventory, freight, logistics, shipment volume, and other items not categorized elsewhere.

[0000858877-15-000013:mdna:202]
Three Months Ended January 24, 2015 Compared with Three Months Ended January 25, 2014

[0000858877-15-000013:mdna:203]
Product gross margin increased by 9.4 percentage points as compared with the second quarter of fiscal 2014.

[0000858877-15-000013:mdna:204]
The increase in product gross margin was primarily a result of the $655 million charge to product cost of sales recorded in the second quarter fiscal 2014 related to the expected cost of remediation of issues with memory components in certain products sold in prior fiscal years, for which there was no corresponding charge in fiscal 2015. Benefits from productivity and the mix of products sold also contributed to the increase. The productivity benefits we experienced in the second quarter of fiscal 2015 were driven by value engineering efforts; favorable component pricing; and continued operational efficiency in manufacturing operations. Value engineering is the process by which production costs are reduced through component redesign, board configuration, test processes, and transformation processes. The mix of products sold was favorable primarily as a result of a revenue decrease from our relatively lower margin Service Provider Video products, partially offset by a revenue increase in our relatively lower margin Cisco Unified Computing System products.

[0000858877-15-000013:mdna:205]
The various factors contributing to the product gross margin increase were partially offset by unfavorable impacts from product pricing, which were driven by typical market factors and impacted each of our geographic segments and customer markets. Our product gross margin for the second quarter of fiscal 2015 was also negatively impacted by impairment charges related to acquisition-related intangible assets.

[0000858877-15-000013:mdna:206]
[same as prior period, unchanged from 0000858877-14-000043:mdna:165]

[0000858877-15-000013:mdna:207]
[same as prior period, unchanged from 0000858877-14-000043:mdna:206]

[0000858877-15-000013:mdna:208]
[same as prior period, unchanged from 0000858877-14-000043:mdna:207]

[0000858877-15-000013:mdna:209]
Six Months Ended January 24, 2015 Compared with Six Months Ended January 25, 2014

[0000858877-15-000013:mdna:210]
Product gross margin increased by 3.6 percentage points as compared with the first six months of fiscal 2014. The increase was driven by the $655 million charge to product cost of sales for the second quarter of fiscal 2014 related to the expected cost of remediation of issues with memory components in certain products sold in prior fiscal years.  Additionally, gross margin increased due to benefits from productivity improvements driven by similar factors as discussed in the three-month period immediately above and the mix of products sold. The shift in the mix of products sold was primarily a result of revenue decreases from our relatively lower margin Service Provider Video products, partially offset by increased in revenue from our relatively lower margin Cisco Unified Computing System products.  These factors were partially offset by unfavorable impacts from product pricing, the unfavorable impact of the $188 million charge to product cost of sales recorded in the first quarter fiscal 2015 related to the Rockstar patent portfolio, and  impairment charges related to acquisition-related intangible assets.

[0000858877-15-000013:mdna:211]
[same as prior period, unchanged from 0000858877-14-000043:mdna:168]

[0000858877-15-000013:mdna:212]
Three Months Ended January 24, 2015 Compared with Three Months Ended January 25, 2014

[0000858877-15-000013:mdna:213]
Our service gross margin percentage decreased by 4.2 percentage points compared with the second quarter of fiscal 2014 due to increased costs such as headcount-related costs associated with higher investments in security and cloud managed services and higher variable compensation expense. Higher partner delivery costs also contributed to increased costs. These cost impacts were partially offset by the resulting benefit to gross margin of higher sales volume in both advanced services and technical support services.

[0000858877-15-000013:mdna:214]
Our service gross margin normally experiences some fluctuations due to various factors such as the timing of contract initiations and our renewals, our strategic investments in headcount, and the resources we deploy to support the overall service business. Other factors include the mix of service offerings, as the gross margin from our advanced services is typically lower than the gross margin from technical support services.

[0000858877-15-000013:mdna:215]
Six Months Ended January 24, 2015 Compared with Six Months Ended January 25, 2014

[0000858877-15-000013:mdna:216]
Service gross margin percentage decreased by 2.5 percentage points as compared with the first six months of fiscal 2014, driven by increased cost impacts such as headcount-related costs and partner delivery costs. These cost impacts were partially offset by the resulting benefit to gross margin of higher sales volume in both advanced services and technical support services.

[0000858877-15-000013:mdna:217]
[same as prior period, unchanged from 0000858877-14-000043:mdna:240]

[0000858877-15-000013:mdna:218]
[same as prior period, unchanged from 0000858877-14-000043:mdna:220]

[0000858877-15-000013:mdna:219]
[same as prior period, unchanged from 0000858877-14-000043:mdna:221]

[0000858877-15-000013:mdna:220]
[same as prior period, unchanged from 0000858877-14-000043:mdna:172]

[0000858877-15-000013:mdna:221]
[same as prior period, unchanged from 0000858877-14-000043:mdna:173]

[0000858877-15-000013:mdna:222]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | AMOUNT |  | PERCENTAGE |  | AMOUNT |  | PERCENTAGE |
|  |  | January 24, 2015 |  | January 25, 2014 |  | January 24, 2015 |  | January 25, 2014 |  | January 24, 2015 |  | January 25, 2014 |  | January 24, 2015 |  | January 25, 2014 |
| Gross margin: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Americas |  | $ | 4,406 |  |  | $ | 3,977 |  |  | 62.0 | % |  | 61.6 | % |  | $ | 9,216 |  |  | $ | 8,627 |  |  | 63.1 | % |  | 62.6 | % |
| EMEA |  | 1,910 |  |  | 1,870 |  |  | 61.8 | % |  | 64.6 | % |  | 3,825 |  |  | 3,758 |  |  | 62.8 | % |  | 64.5 | % |
| APJC |  | 1,052 |  |  | 993 |  |  | 60.3 | % |  | 55.2 | % |  | 2,077 |  |  | 2,072 |  |  | 59.6 | % |  | 57.0 | % |
| Segment total |  | 7,368 |  |  | 6,840 |  |  | 61.7 | % |  | 61.3 | % |  | 15,118 |  |  | 14,457 |  |  | 62.5 | % |  | 62.2 | % |
| Unallocated corporate items (1) |  | (278 | ) |  | (889 | ) |  |  |  |  |  | (695 | ) |  | (1,099 | ) |  |  |  |  |
| Total |  | $ | 7,090 |  |  | $ | 5,951 |  |  | 59.4 | % |  | 53.3 | % |  | $ | 14,423 |  |  | $ | 13,358 |  |  | 59.6 | % |  | 57.5 | % |

[0000858877-15-000013:mdna:223]
(1) The unallocated corporate items for the periods presented include the effects of amortization and impairments of acquisition-related intangible assets, share-based compensation expense, significant litigation and other contingencies, and certain other charges. We do not allocate these items to the gross margin for each segment because management does not include such information in measuring the performance of the operating segments.

[0000858877-15-000013:mdna:224]
Three Months Ended January 24, 2015 Compared with Three Months Ended January 25, 2014

[0000858877-15-000013:mdna:225]
The Americas segment experienced a gross margin percentage increase due to productivity improvements from lower overall manufacturing costs and, to a lesser extent, a favorable mix impact. The favorable mix impact in this geographic segment was driven by lower sales of our relatively lower margin Service Provider Video products, partially offset by an increase in revenue from our relatively lower margin Cisco Unified Computing System products. Partially offsetting these favorable impacts to gross margin were negative impacts from pricing.

[0000858877-15-000013:mdna:226]
The gross margin percentage decrease in our EMEA segment was due primarily to lower productivity and unfavorable impacts from pricing, partially offset by a favorable mix impact. The favorable mix impact was driven by an increase in revenue from certain of our higher margin core products. Lower service gross margin also contributed to the decrease in gross margin in this segment.

[0000858877-15-000013:mdna:227]
Our APJC segment gross margin percentage increased due to productivity improvements and a favorable mix impact, partially offset by unfavorable impacts from pricing and lower service gross margin. The favorable mix impact was driven by a decrease in revenue from our relatively lower margin Service Provider Video products and an increase in revenue from certain of our higher margin core products.

[0000858877-15-000013:mdna:228]
[same as prior period, unchanged from 0000858877-14-000043:mdna:180]

[0000858877-15-000013:mdna:229]
Six Months Ended January 24, 2015 Compared with Six Months Ended January 25, 2014

[0000858877-15-000013:mdna:230]
We experienced a gross margin percentage increase in our Americas segment due to productivity improvements and a favorable mix impact, partially offset by unfavorable impacts from pricing. The favorable mix impact in this geographic segment was driven by lower sales of our relatively lower margin Service Provider Video products, partially offset by an increase in revenue from our relatively lower margin Cisco Unified Computing System products.

[0000858877-15-000013:mdna:231]
The gross margin percentage decrease in our EMEA segment was primarily due to negative impacts from pricing within this segment and, to a lesser extent, lower productivity. These factors were partially offset by a slightly favorable mix impact. The favorable mix impact was driven by an increase in revenue from certain of our higher margin core products.

[0000858877-15-000013:mdna:232]
The APJC segment gross margin percentage increased due to productivity improvements and a favorable mix impact, partially offset by unfavorable impacts from pricing. The favorable mix impact was driven by a decrease in revenue from our relatively lower margin Service Provider Video products and an increase in revenue from certain of our higher margin core products.

[0000858877-15-000013:mdna:233]
60

[0000858877-15-000013:mdna:234]
[same as prior period, unchanged from 0000858877-14-000043:mdna:236]

[0000858877-15-000013:mdna:235]
[same as prior period, unchanged from 0000858877-14-000043:mdna:237]

[0000858877-15-000013:mdna:236]
[same as prior period, unchanged from 0000858877-14-000043:mdna:184]

[0000858877-15-000013:mdna:237]
[same as prior period, unchanged from 0000858877-14-000043:mdna:185]

[0000858877-15-000013:mdna:238]
[same as prior period, unchanged from 0000858877-14-000043:mdna:186]

[0000858877-15-000013:mdna:239]
[same as prior period, unchanged from 0000858877-14-000043:mdna:187]

[0000858877-15-000013:mdna:240]
[same as prior period, unchanged from 0000858877-14-000043:mdna:188]

[0000858877-15-000013:mdna:241]
[same as prior period, unchanged from 0000858877-14-000043:mdna:270]

[0000858877-15-000013:mdna:242]
[same as prior period, unchanged from 0000858877-14-000043:mdna:241]

[0000858877-15-000013:mdna:243]
[same as prior period, unchanged from 0000858877-14-000043:mdna:242]

[0000858877-15-000013:mdna:244]
[same as prior period, unchanged from 0000858877-14-000043:mdna:191]

[0000858877-15-000013:mdna:245]
[same as prior period, unchanged from 0000858877-14-000043:mdna:192]

[0000858877-15-000013:mdna:246]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 24, 2015 |  | January 25, 2014 |  | Variancein Dollars |  | Variance in Percent |  | January 24, 2015 |  | January 25, 2014 |  | Variancein Dollars |  | Variance in Percent |
| Research and development |  | $ | 1,529 |  |  | $ | 1,412 |  |  | $ | 117 |  |  | 8.3 | % |  | $ | 3,112 |  |  | $ | 3,136 |  |  | $ | (24 | ) |  | (0.8 | )% |
| Percentage of revenue |  | 12.8 | % |  | 12.7 | % |  |  |  |  |  | 12.9 | % |  | 13.5 | % |  |  |  |  |
| Sales and marketing |  | 2,308 |  |  | 2,277 |  |  | 31 |  |  | 1.4 | % |  | 4,823 |  |  | 4,688 |  |  | 135 |  |  | 2.9 | % |
| Percentage of revenue |  | 19.3 | % |  | 20.4 | % |  |  |  |  |  | 19.9 | % |  | 20.2 | % |  |  |  |  |
| General and administrative |  | 490 |  |  | 451 |  |  | 39 |  |  | 8.6 | % |  | 994 |  |  | 966 |  |  | 28 |  |  | 2.9 | % |
| Percentage of revenue |  | 4.1 | % |  | 4.0 | % |  |  |  |  |  | 4.1 | % |  | 4.2 | % |  |  |  |  |
| Total |  | $ | 4,327 |  |  | $ | 4,140 |  |  | $ | 187 |  |  | 4.5 | % |  | $ | 8,929 |  |  | $ | 8,790 |  |  | $ | 139 |  |  | 1.6 | % |
| Percentage of revenue |  | 36.3 | % |  | 37.1 | % |  |  |  |  |  | 36.9 | % |  | 37.8 | % |  |  |  |  |

[0000858877-15-000013:mdna:247]
[same as prior period, unchanged from 0000858877-14-000043:mdna:194]

[0000858877-15-000013:mdna:248]
R&D expenses increased for the second quarter of fiscal 2015, as compared with the second quarter of fiscal 2014, primarily due to higher headcount-related expenses driven by increased variable compensation expense as a result of our financial performance. Higher discretionary spending and higher contracted services, to a lesser extent, also contributed to the increase.

[0000858877-15-000013:mdna:249]
The decrease in R&D expenses for the first six months of fiscal 2015, as compared with the first six months of fiscal 2014, was primarily due to higher compensation expense recorded in the first six months of fiscal 2014 in connection with our acquisition of the remaining interest in Insieme partially offset by higher headcount-related expenses and higher contracted services. The higher headcount-related expenses were due to increased variable compensation expense partially offset by efficiencies related to our restructuring actions.

[0000858877-15-000013:mdna:250]
[same as prior period, unchanged from 0000858877-14-000043:mdna:196]

[0000858877-15-000013:mdna:251]
[same as prior period, unchanged from 0000858877-14-000043:mdna:197]

[0000858877-15-000013:mdna:252]
Sales and marketing expenses increased for the second quarter of fiscal 2015, as compared with the second quarter of fiscal 2014, due to higher headcount-related expenses and, to a lesser extent, higher contracted services, partially offset by lower share-based compensation expense. Higher headcount-related expenses were due to increased variable compensation expense as a result of our financial performance.

[0000858877-15-000013:mdna:253]
Sales and marketing expenses increased for the first six months of fiscal 2015, as compared with the first six months of fiscal 2014, due to higher headcount-related expenses, driven by increased variable compensation expense, and higher discretionary spending.

[0000858877-15-000013:mdna:254]
[same as prior period, unchanged from 0000858877-14-000043:mdna:199]

[0000858877-15-000013:mdna:255]
G&A expenses increased in the second quarter of fiscal 2015, as compared with the second quarter of fiscal 2014, primarily due to increased variable compensation expense as a result of our financial performance and timing of corporate-level expenses, which tend to vary from period to period.

[0000858877-15-000013:mdna:256]
G&A expenses increased in the first six months of fiscal 2015, as compared with the corresponding period in fiscal 2014, primarily due to increased variable compensation expense as a result of our financial performance and timing of corporate-level expenses, which tend to vary from period to period, partially offset by higher compensation expense recorded in the first six months of fiscal 2014 in connection with our acquisition of the remaining interest in Insieme.

[0000858877-15-000013:mdna:257]
[same as prior period, unchanged from 0000858877-14-000043:mdna:201]

[0000858877-15-000013:mdna:258]
In the second quarter of fiscal 2015, foreign currency fluctuations, net of hedging, decreased the combined R&D, sales and marketing, and G&A expenses by $60 million, or approximately 1.5%, compared with the second quarter of fiscal 2014.

[0000858877-15-000013:mdna:259]
In the first six months of fiscal 2015, foreign currency fluctuations, net of hedging, decreased the combined R&D, sales and marketing, and G&A expenses by $56 million, or approximately 0.6%, compared with the first six months of fiscal 2014.

[0000858877-15-000013:mdna:260]
62

[0000858877-15-000013:mdna:261]
[same as prior period, unchanged from 0000858877-14-000043:mdna:256]

[0000858877-15-000013:mdna:262]
[same as prior period, unchanged from 0000858877-14-000043:mdna:257]

[0000858877-15-000013:mdna:263]
[same as prior period, unchanged from 0000858877-14-000043:mdna:203]

[0000858877-15-000013:mdna:264]
Our headcount decreased by approximately 2,135 employees in the second quarter of fiscal 2015 and decreased by approximately 3,930 in the first six months of fiscal 2015, as compared with the total headcount at the end of fiscal 2014.  The decrease was due to headcount reductions from our workforce reduction under the Fiscal 2015 Plan. These headcount reductions were partially offset by headcount additions from targeted hiring in engineering, services and sales, and also by headcount additions from our recent acquisitions.

[0000858877-15-000013:mdna:265]
[same as prior period, unchanged from 0000858877-14-000043:mdna:208]

[0000858877-15-000013:mdna:266]
[same as prior period, unchanged from 0000858877-14-000043:mdna:209]

[0000858877-15-000013:mdna:267]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 24, 2015 |  | January 25, 2014 |  | January 24, 2015 |  | January 25, 2014 |
| Cost of sales—product |  | $ | 11 |  |  | $ | 12 |  |  | $ | 22 |  |  | $ | 22 |  |
| Cost of sales—service |  | 34 |  |  | 40 |  |  | 71 |  |  | 73 |  |
| Share-based compensation expense in cost of sales |  | 45 |  |  | 52 |  |  | 93 |  |  | 95 |  |
| Research and development |  | 105 |  |  | 108 |  |  | 224 |  |  | 200 |  |
| Sales and marketing |  | 114 |  |  | 141 |  |  | 261 |  |  | 264 |  |
| General and administrative |  | 42 |  |  | 47 |  |  | 101 |  |  | 101 |  |
| Restructuring and other charges |  | 2 |  |  | (1 | ) |  | (2 | ) |  | (4 | ) |
| Share-based compensation expense in operating expenses |  | 263 |  |  | 295 |  |  | 584 |  |  | 561 |  |
| Total share-based compensation expense |  | $ | 308 |  |  | $ | 347 |  |  | $ | 677 |  |  | $ | 656 |  |

[0000858877-15-000013:mdna:268]
The decrease in share-based compensation expense for the second quarter of fiscal 2015, as compared with the second quarter of fiscal 2014, was due primarily to the timing of annual RSU grants partially offset by higher expense associated with PRSUs.

[0000858877-15-000013:mdna:269]
The increase in share-based compensation expense for the first six months of fiscal 2015, as compared with the corresponding period in fiscal 2014, was due primarily to higher expense associated with the PRSUs and equity awards assumed with respect to our recent acquisitions, partially offset by the timing of annual RSU grants.

[0000858877-15-000013:mdna:270]
[same as prior period, unchanged from 0000858877-14-000043:mdna:212]

[0000858877-15-000013:mdna:271]
[same as prior period, unchanged from 0000858877-14-000043:mdna:213]

[0000858877-15-000013:mdna:272]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 24, 2015 |  | January 25, 2014 |  | January 24, 2015 |  | January 25, 2014 |
| Amortization of purchased intangible assets: |  |  |  |  |  |  |  |  |
| Cost of sales |  | $ | 242 |  |  | $ | 189 |  |  | $ | 431 |  |  | $ | 363 |  |
| Operating expenses |  | 72 |  |  | 71 |  |  | 143 |  |  | 136 |  |
| Total |  | $ | 314 |  |  | $ | 260 |  |  | $ | 574 |  |  | $ | 499 |  |

[0000858877-15-000013:mdna:273]
Amortization of purchased intangible assets increased for the second quarter and first six months of fiscal 2015, as compared with the corresponding periods of fiscal 2014, due to the impairment charges of approximately $56 million recorded in the second quarter of fiscal 2015. The impairment charges were primarily due to reductions in expected future cash flows related to certain of our technology intangible assets.

[0000858877-15-000013:mdna:274]
[same as prior period, unchanged from 0000858877-14-000043:mdna:216]

[0000858877-15-000013:mdna:275]
[same as prior period, unchanged from 0000858877-14-000043:mdna:271]

[0000858877-15-000013:mdna:276]
[same as prior period, unchanged from 0000858877-14-000043:mdna:272]

[0000858877-15-000013:mdna:277]
[same as prior period, unchanged from 0000858877-14-000043:mdna:217]

[0000858877-15-000013:mdna:278]
In the second quarter and first six months of fiscal 2015, we incurred within operating expenses restructuring and other charges of approximately $69 million and $387 million, respectively, which were related primarily to employee severance charges for employees impacted by our workforce reduction under the Fiscal 2015 Plan.  We expect the remaining charges under this plan to be incurred within the remainder of fiscal 2015. We plan to reinvest substantially all of the cost savings from the restructuring actions in key growth areas of our business such as data center, software, security, and cloud. The overall cost savings from these restructuring actions were not material for the periods presented and are not expected to be material for future periods.

[0000858877-15-000013:mdna:279]
In the second quarter and first six months of fiscal 2014, we incurred within operating expenses net restructuring and other charges of $73 million and $310 million, respectively, which were related primarily to employee severance charges for employees impacted by our workforce reduction under the Fiscal 2014 Plan. See Note 5 to the Consolidated Financial Statements.

[0000858877-15-000013:mdna:280]
[same as prior period, unchanged from 0000858877-14-000043:mdna:222]

[0000858877-15-000013:mdna:281]
[same as prior period, unchanged from 0000858877-14-000043:mdna:223]

[0000858877-15-000013:mdna:282]
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | January 24, 2015 |  | January 25, 2014 |  | January 24, 2015 |  | January 25, 2014 |
| Operating income |  | $ | 2,622 |  |  | $ | 1,667 |  |  | $ | 4,964 |  |  | $ | 4,122 |  |
| Operating income as a percentage of revenue |  | 22.0 | % |  | 14.9 | % |  | 20.5 | % |  | 17.7 | % |

[0000858877-15-000013:mdna:283]
For the second quarter of fiscal 2015, as compared with the second quarter of fiscal 2014, operating income increased by 57%, and as a percentage of revenue operating income increased by 7.1 percentage points. The increase resulted from an increase in revenue and a gross margin percentage increase, with the gross margin  increase driven in large part by the $655 million supplier component remediation charge (or 5.9 percentage points) recorded in the second quarter of fiscal 2014 for which there was no corresponding charge in fiscal 2015.

[0000858877-15-000013:mdna:284]
In the first six months of fiscal 2015, as compared with the first six months of fiscal 2014, operating income increased by 20%, and as a percentage of revenue operating income increased by 2.8 percentage points. The increase resulted from the following: an increase in revenue; a gross margin percentage increase, driven in part by the $655 million supplier component remediation charge (or 2.8 percentage points) recorded in the second quarter of fiscal 2014  partially offset by the unfavorable impact of the Rockstar patent portfolio charge of $188 million (or 0.8 percentage points); and higher compensation expense recorded in the first six months of fiscal 2014 in connection with our acquisition of the remaining interest in Insieme.

[0000858877-15-000013:mdna:285]
[same as prior period, unchanged from 0000858877-14-000043:mdna:226]

[0000858877-15-000013:mdna:286]
[same as prior period, unchanged from 0000858877-14-000043:mdna:227]

[0000858877-15-000013:mdna:287]
|  | Three Months Ended |  | Six Months Ended |
|  | January 24, 2015 |  | January 25, 2014 |  | Variancein Dollars |  | January 24, 2015 |  | January 25, 2014 |  | Variancein Dollars |
| Interest income | $ | 189 |  |  | $ | 169 |  |  | $ | 20 |  |  | $ | 368 |  |  | $ | 338 |  |  | $ | 30 |  |
| Interest expense | (139 | ) |  | (136 | ) |  | (3 | ) |  | (278 | ) |  | (276 | ) |  | (2 | ) |
| Interest income (expense), net | $ | 50 |  |  | $ | 33 |  |  | $ | 17 |  |  | $ | 90 |  |  | $ | 62 |  |  | $ | 28 |  |

[0000858877-15-000013:mdna:288]
For the second quarter and first six months of fiscal 2015, interest income increased by 12% and 9%, respectively, compared with the corresponding periods in fiscal 2014, driven by an increase in our portfolio of cash, cash equivalents, and fixed income investments. Interest expense in the second quarter and first six months of fiscal 2015, compared with the corresponding periods in fiscal 2014, was higher driven by higher average debt balance.

[0000858877-15-000013:mdna:289]
64

[0000858877-15-000013:mdna:290]
[same as prior period, unchanged from 0000858877-14-000043:mdna:281]

[0000858877-15-000013:mdna:291]
[same as prior period, unchanged from 0000858877-14-000043:mdna:282]

[0000858877-15-000013:mdna:292]
[same as prior period, unchanged from 0000858877-14-000043:mdna:230]

[0000858877-15-000013:mdna:293]
|  | Three Months Ended |  | Six Months Ended |
|  | January 24, 2015 |  | January 25, 2014 |  | Variancein Dollars |  | January 24, 2015 |  | January 25, 2014 |  | Variancein Dollars |
| Gains (losses) on investments, net: |  |  |  |  |  |  |  |  |  |  |  |
| Publicly traded equity securities | $ | 60 |  |  | $ | 69 |  |  | $ | (9 | ) |  | $ | 56 |  |  | $ | 144 |  |  | $ | (88 | ) |
| Fixed income securities | 9 |  |  | 13 |  |  | (4 | ) |  | 20 |  |  | 21 |  |  | (1 | ) |
| Total available-for-sale investments | 69 |  |  | 82 |  |  | (13 | ) |  | 76 |  |  | 165 |  |  | (89 | ) |
| Privately held companies | 134 |  |  | (35 | ) |  | 169 |  |  | 101 |  |  | (66 | ) |  | 167 |  |
| Net gains (losses) on investments | 203 |  |  | 47 |  |  | 156 |  |  | 177 |  |  | 99 |  |  | 78 |  |
| Other gains (losses), net | (2 | ) |  | 8 |  |  | (10 | ) |  | 2 |  |  | 12 |  |  | (10 | ) |
| Other income (loss), net | $ | 201 |  |  | $ | 55 |  |  | $ | 146 |  |  | $ | 179 |  |  | $ | 111 |  |  | $ | 68 |  |

[0000858877-15-000013:mdna:294]
The decrease in total net gains on available-for-sale investments in the second quarter and first six months of fiscal 2015, as compared with the corresponding periods in fiscal 2014, was primarily attributable to lower gains on publicly traded equity securities in the current periods as a result of market conditions and the timing of sales of these securities.

[0000858877-15-000013:mdna:295]
The change in net gains (losses) on investments in privately held companies for the second quarter and first six months of fiscal 2015, as compared with the corresponding periods in fiscal 2014, was primarily due to a gain of $126 million related to the reorganization of our investment in VCE and the absence of losses from VCE for the second quarter of fiscal 2015 and lower losses for the first six months of fiscal 2015 related to this investment under the equity method. We ceased accounting for VCE under the equity method in October 2014.

[0000858877-15-000013:mdna:296]
The change in other gains (losses), net in the second quarter and first six months of fiscal 2015, as compared with the corresponding periods in fiscal 2014, was driven by lower gains from equity derivative instruments, and for the six month period this impact was partially offset by net favorable foreign exchange impacts.

[0000858877-15-000013:mdna:297]
[same as prior period, unchanged from 0000858877-14-000043:mdna:238]

[0000858877-15-000013:mdna:298]
Our provision for income taxes is subject to volatility and could be adversely impacted by earnings being lower than anticipated in countries that have lower tax rates, higher than anticipated in countries that have higher tax rates, and expiration of or lapses in tax incentives. Our provision for income taxes does not include provisions for U.S. income taxes and foreign withholding taxes associated with the repatriation of undistributed earnings of certain foreign subsidiaries that we intend to reinvest indefinitely in our foreign subsidiaries. If these earnings were distributed from the foreign subsidiaries to the United States in the form of dividends or otherwise, or if the shares of the relevant foreign subsidiaries were sold or otherwise transferred, we would be subject to additional U.S. income taxes (subject to an adjustment for foreign tax credits) and foreign withholding taxes. Further, as a result of certain of our ongoing employment and capital investment actions and commitments, our income in certain countries is subject to reduced tax rates and in some cases is wholly exempt from tax. Our failure to meet these commitments could adversely impact our provision for income taxes.

[0000858877-15-000013:mdna:299]
The provision for income taxes resulted in an effective tax rate of 16.6% for the second quarter of fiscal 2015, compared with 18.6% for the second quarter of fiscal 2014, which resulted in a net 2.0 percentage point decrease in the effective tax rate for the second quarter of fiscal 2015 as compared with the second quarter of fiscal 2014. The provision for income taxes resulted in an effective tax rate of 19.3% for the first six months of fiscal 2015, as compared with an effective tax rate of 20.3% for the first six months of fiscal 2014, which resulted in a net 1.0 percentage point decrease in the effective tax rate for the first six months of fiscal 2015 as compared with the first six months of fiscal 2014. The decrease in the effective tax rates for both the second quarter and first six months of fiscal 2015, as compared with the second quarter and first six months of fiscal 2014, was primarily due to the retroactive reinstatement of the U.S. federal R&D tax credit for calendar year 2014 in the second quarter of fiscal 2015.

[0000858877-15-000013:mdna:300]
[same as prior period, unchanged from 0000858877-14-000043:mdna:292]

[0000858877-15-000013:mdna:301]
[same as prior period, unchanged from 0000858877-14-000043:mdna:293]

[0000858877-15-000013:mdna:302]
[same as prior period, unchanged from 0000858877-14-000043:mdna:243]

[0000858877-15-000013:mdna:303]
[same as prior period, unchanged from 0000858877-14-000043:mdna:244]

[0000858877-15-000013:mdna:304]
[same as prior period, unchanged from 0000858877-14-000043:mdna:245]

[0000858877-15-000013:mdna:305]
[same as prior period, unchanged from 0000858877-14-000043:mdna:246]

[0000858877-15-000013:mdna:306]
|  | January 24, 2015 |  | July 26, 2014 |  | Increase (Decrease) |
| Cash and cash equivalents | $ | 4,797 |  |  | $ | 6,726 |  |  | $ | (1,929 | ) |
| Fixed income securities | 46,377 |  |  | 43,396 |  |  | 2,981 |  |
| Publicly traded equity securities | 1,848 |  |  | 1,952 |  |  | (104 | ) |
| Total | $ | 53,022 |  |  | $ | 52,074 |  |  | $ | 948 |  |

[0000858877-15-000013:mdna:307]
The net increase in cash and cash equivalents and investments in the first six months of fiscal 2015 was primarily the result of cash provided by operating activities of $5.4 billion and proceeds from the issuance of common stock of $1.2 billion pursuant to employee stock incentive plans. These sources of cash were partially offset by the repurchase of common stock of $2.2 billion under the stock repurchase program, cash dividends paid of $1.9 billion, capital expenditures of $0.6 billion, repayment of debt of $0.5 billion and net cash paid for acquisitions of $0.2 billion.

[0000858877-15-000013:mdna:308]
Our total in cash and cash equivalents and investments held by various foreign subsidiaries was $49.8 billion and $47.4 billion as of January 24, 2015 and July 26, 2014, respectively. Under current tax laws and regulations, if these assets were to be distributed from the foreign subsidiaries to the United States in the form of dividends or otherwise, we would be subject to additional U.S. income taxes (subject to an adjustment for foreign tax credits) and foreign withholding taxes. The balance of cash and cash equivalents and investments available in the United States as of January 24, 2015 and July 26, 2014 was $3.2 billion and $4.7 billion, respectively.

[0000858877-15-000013:mdna:309]
[same as prior period, unchanged from 0000858877-14-000043:mdna:250]

[0000858877-15-000013:mdna:310]
[same as prior period, unchanged from 0000858877-14-000043:mdna:251]

[0000858877-15-000013:mdna:311]
[same as prior period, unchanged from 0000858877-14-000043:mdna:252]

[0000858877-15-000013:mdna:312]
|  | Six Months Ended |
|  | January 24, 2015 |  | January 25, 2014 |
| Net cash provided by operating activities | $ | 5,374 |  |  | $ | 5,522 |  |
| Acquisition of property and equipment | (550 | ) |  | (577 | ) |
| Free cash flow | $ | 4,824 |  |  | $ | 4,945 |  |

[0000858877-15-000013:mdna:313]
[same as prior period, unchanged from 0000858877-14-000043:mdna:254]

[0000858877-15-000013:mdna:314]
We consider free cash flow to be a liquidity measure that provides useful information to management and investors because of our intent to return a stated percentage of free cash flow to shareholders in the form of dividends and stock repurchases.  We further

[0000858877-15-000013:mdna:315]
[same as prior period, unchanged from 0000858877-14-000043:mdna:305]

[0000858877-15-000013:mdna:316]
[same as prior period, unchanged from 0000858877-14-000043:mdna:306]

[0000858877-15-000013:mdna:317]
regard free cash flow as a useful measure because it reflects cash that can be used to, among other things, invest in our business, make strategic acquisitions, repurchase common stock, and pay dividends on our common stock, after deducting capital investments. A limitation of the utility of free cash flow as a measure of financial performance and liquidity is that the free cash flow does not represent the total increase or decrease in our cash balance for the period.  In addition, we have other required uses of cash, including repaying the principal of our outstanding indebtedness.  Free cash flow is not a measure calculated in accordance with U.S. generally accepted accounting principles and should not be regarded in isolation or as an alternative for net income provided by operating activities or any other measure calculated in accordance with such principles, and other companies may calculate free cash flow in a different manner than we do.

[0000858877-15-000013:mdna:318]
[same as prior period, unchanged from 0000858877-14-000043:mdna:259]

[0000858877-15-000013:mdna:319]
|  |  | DIVIDENDS |  | STOCK REPURCHASE PROGRAM |  |  |
| Quarter Ended |  | Per Share |  | Amount |  | Shares |  | Weighted-Average Price per Share |  | Amount |  | TOTAL |
| Fiscal 2015 |  |  |  |  |  |  |  |  |  |  |  |  |
| January 24, 2015 |  | $ | 0.19 |  |  | $ | 974 |  |  | 44 |  |  | $ | 27.63 |  |  | $ | 1,208 |  |  | $ | 2,182 |  |
| October 25, 2014 |  | $ | 0.19 |  |  | $ | 973 |  |  | 41 |  |  | $ | 24.58 |  |  | $ | 1,013 |  |  | $ | 1,986 |  |
| Fiscal 2014 |  |  |  |  |  |  |  |  |  |  |  |  |
| July 26, 2014 |  | $ | 0.19 |  |  | $ | 974 |  |  | 61 |  |  | $ | 25.11 |  |  | $ | 1,514 |  |  | $ | 2,488 |  |
| April 26, 2014 |  | $ | 0.19 |  |  | $ | 974 |  |  | 90 |  |  | $ | 22.24 |  |  | $ | 2,005 |  |  | $ | 2,979 |  |
| January 25, 2014 |  | $ | 0.17 |  |  | $ | 896 |  |  | 185 |  |  | $ | 21.73 |  |  | $ | 4,020 |  |  | $ | 4,916 |  |
| October 26, 2013 |  | $ | 0.17 |  |  | $ | 914 |  |  | 84 |  |  | $ | 23.65 |  |  | $ | 2,000 |  |  | $ | 2,914 |  |

[0000858877-15-000013:mdna:320]
On February 11, 2015, our Board of Directors declared a quarterly dividend of $0.21 per common share to be paid on April 22, 2015 to all shareholders of record as of the close of business on April 2, 2015.  Any future dividends will be subject to the approval of our Board of Directors.

[0000858877-15-000013:mdna:321]
[same as prior period, unchanged from 0000858877-14-000043:mdna:262]

[0000858877-15-000013:mdna:322]
|  | January 24, 2015 |  | July 26, 2014 |  | Increase (Decrease) |
| Accounts receivable, net | $ | 4,541 |  |  | $ | 5,157 |  |  | $ | (616 | ) |
| DSO | 35 |  |  | 38 |  |  | (3 | ) |

[0000858877-15-000013:mdna:323]
Our accounts receivable net, as of January 24, 2015 decreased by approximately 12% compared with the end of fiscal 2014. Our DSO as of January 24, 2015 was lower by 3 days compared with the end of fiscal 2014, primarily due to product billings being more linear in the second quarter of fiscal 2015 compared with the fourth quarter of fiscal 2014.

[0000858877-15-000013:mdna:324]
[same as prior period, unchanged from 0000858877-14-000043:mdna:265]

[0000858877-15-000013:mdna:325]
|  | January 24, 2015 |  | July 26, 2014 |  | Increase (Decrease) |
| Inventories | $ | 1,890 |  |  | $ | 1,591 |  |  | $ | 299 |  |
| Annualized inventory turns | 10.9 |  |  | 12.7 |  |  | (1.8 | ) |
| Purchase commitments with contract manufacturers and suppliers | $ | 4,257 |  |  | $ | 4,169 |  |  | $ | 88 |  |

[0000858877-15-000013:mdna:326]
Inventory as of January 24, 2015 increased by 19% from our inventory balance at the end of fiscal 2014, and for the same period purchase commitments with contract manufacturers and suppliers increased by approximately 2%. On a combined basis, inventories and purchase commitments with contract manufacturers and suppliers increased by 7% compared with the end of fiscal 2014.

[0000858877-15-000013:mdna:327]
The inventory increase was primarily due to higher levels of raw materials primarily from insourcing of certain memory components.  We believe our inventory and purchase commitments levels are in line with our current demand forecasts.

[0000858877-15-000013:mdna:328]
[same as prior period, unchanged from 0000858877-14-000043:mdna:268]

[0000858877-15-000013:mdna:329]
CISCO SYSTEMS, INC.

[0000858877-15-000013:mdna:330]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-15-000013:mdna:331]
We purchase components from a variety of suppliers and use several contract manufacturers to provide manufacturing services for our products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, we enter into agreements with contract manufacturers and suppliers that allow them to procure inventory based upon criteria as defined by us or that establish the parameters defining our requirements and our commitment to securing manufacturing capacity. A significant portion of our reported purchase commitments arising from these agreements are firm, noncancelable, and unconditional commitments. In certain instances, these agreements allow us the option to cancel, reschedule, and adjust our requirements based on our business needs prior to firm orders being placed. Our purchase commitments are for short-term product manufacturing requirements as well as for commitments to suppliers to secure manufacturing capacity.

[0000858877-15-000013:mdna:332]
[same as prior period, unchanged from 0000858877-14-000043:mdna:274]

[0000858877-15-000013:mdna:333]
[same as prior period, unchanged from 0000858877-14-000043:mdna:275]

[0000858877-15-000013:mdna:334]
Financing Receivables and Guarantees We measure our net balance sheet exposure position related to our financing receivables and financing guarantees by reducing the total of gross financing receivables and financing guarantees by the associated allowances for credit loss and deferred revenue. As of January 24, 2015, our net balance sheet exposure position related to financing receivables and financing guarantees was as follows (in millions):

[0000858877-15-000013:mdna:335]
|  | FINANCING RECEIVABLES |  | FINANCING GUARANTEES |  |  |
| January 24, 2015 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts and Other |  | Total |  | Channel Partner |  | End-User Customers |  | Total |  | TOTAL |
| Financing receivables less unearned income | $ | 3,391 |  |  | $ | 1,674 |  |  | $ | 3,069 |  |  | $ | 8,134 |  |  | $ | 316 |  |  | $ | 155 |  |  | $ | 471 |  |  | $ | 8,605 |  |
| Allowance for credit loss | (250 | ) |  | (85 | ) |  | (40 | ) |  | (375 | ) |  | — |  |  | — |  |  | — |  |  | (375 | ) |
| Deferred revenue | (10 | ) |  | (13 | ) |  | (1,530 | ) |  | (1,553 | ) |  | (148 | ) |  | (121 | ) |  | (269 | ) |  | (1,822 | ) |
| Net balance sheet exposure | $ | 3,131 |  |  | $ | 1,576 |  |  | $ | 1,499 |  |  | $ | 6,206 |  |  | $ | 168 |  |  | $ | 34 |  |  | $ | 202 |  |  | $ | 6,408 |  |

[0000858877-15-000013:mdna:336]
Financing Receivables  Financing receivables less unearned income decreased by 3% compared with the end of fiscal 2014. The change was primarily due to a 4% decrease in both lease receivables and financed service contracts and other, as well as a 1% decrease in loan receivables. We provide financing to certain end-user customers and channel partners to enable sales of our products, services, and networking solutions. These financing arrangements include leases, financed service contracts, and loans. Arrangements related to leases are generally collateralized by a security interest in the underlying assets. Lease receivables include sales-type and direct-financing leases. We also provide certain qualified customers financing for long-term service contracts, which primarily relate to technical support services and advanced services. Our loan financing arrangements may include not only financing the acquisition of our products and services but also providing additional funds for other costs associated with network installation and integration of our products and services. We expect to continue to expand the use of our financing programs in the near term.

[0000858877-15-000013:mdna:337]
[same as prior period, unchanged from 0000858877-14-000043:mdna:279]

[0000858877-15-000013:mdna:338]
68

[0000858877-15-000013:mdna:339]
CISCO SYSTEMS, INC.

[0000858877-15-000013:mdna:340]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-15-000013:mdna:341]
[same as prior period, unchanged from 0000858877-14-000043:mdna:280]

[0000858877-15-000013:mdna:342]
[same as prior period, unchanged from 0000858877-14-000043:mdna:283]

[0000858877-15-000013:mdna:343]
[same as prior period, unchanged from 0000858877-14-000043:mdna:284]

[0000858877-15-000013:mdna:344]
|  | Maturity Date |  | January 24, 2015 |  | July 26, 2014 |
| Senior notes: |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |
| Three-month LIBOR plus 0.05% | September 3, 2015 |  | $ | 850 |  |  | $ | 850 |  |
| Three-month LIBOR plus 0.28% | March 3, 2017 |  | 1,000 |  |  | 1,000 |  |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | 500 |  |  | 500 |  |
| Fixed-rate notes: |  |  |  |  |  |
| 2.90% | November 17, 2014 |  | — |  |  | 500 |  |
| 5.50% | February 22, 2016 |  | 3,000 |  |  | 3,000 |  |
| 1.10% | March 3, 2017 |  | 2,400 |  |  | 2,400 |  |
| 3.15% | March 14, 2017 |  | 750 |  |  | 750 |  |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 2,000 |  |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 1,750 |  |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 2,500 |  |
| 2.90% | March 4, 2021 |  | 500 |  |  | 500 |  |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1,000 |  |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 2,000 |  |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 2,000 |  |
| Total |  |  | $ | 20,250 |  |  | $ | 20,750 |  |

[0000858877-15-000013:mdna:345]
Interest is payable semiannually on each class of the senior fixed-rate notes, each of which is redeemable by us at any time, subject to a make-whole premium. Interest is payable quarterly on the floating-rate notes. We were in compliance with all debt covenants as of January 24, 2015.

[0000858877-15-000013:mdna:346]
[same as prior period, unchanged from 0000858877-14-000043:mdna:287]

[0000858877-15-000013:mdna:347]
Other Debt  Other debt as of January 24, 2015 and July 26, 2014 included secured borrowings associated with customer financing arrangements.  The amount of borrowings outstanding under these arrangements was $7 million and $12 million as of January 24, 2015 and July 26, 2014, respectively.

[0000858877-15-000013:mdna:348]
Commercial Paper  In fiscal 2011, we established a short-term debt financing program of up to $3.0 billion through the issuance of commercial paper notes. We use the proceeds from the issuance of commercial paper notes for general corporate purposes. We had no commercial paper notes outstanding as of each of January 24, 2015 and July 26, 2014.

[0000858877-15-000013:mdna:349]
Credit Facility  On February 17, 2012, we entered into a credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on February 17, 2017. Any advances under the credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (i) the higher of the Federal Funds rate plus 0.50%, Bank of America’s “prime rate” as announced from time to time, or one-month LIBOR plus 1.00% or (ii) LIBOR plus a margin that is based on our senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc. The credit agreement requires that we comply with certain covenants, including that we maintain an interest coverage ratio as defined in the agreement. As of January 24, 2015, we were in compliance with the required interest coverage ratio and the other covenants, and we had not borrowed any funds under the credit facility.

[0000858877-15-000013:mdna:350]
69

[0000858877-15-000013:mdna:351]
CISCO SYSTEMS, INC.

[0000858877-15-000013:mdna:352]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-15-000013:mdna:353]
We may also, upon the agreement of either the existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and/or extend the expiration date of the credit facility by up to two additional years, or up to February 17, 2019.

[0000858877-15-000013:mdna:354]
[same as prior period, unchanged from 0000858877-14-000043:mdna:294]

[0000858877-15-000013:mdna:355]
|  | January 24, 2015 |  | July 26, 2014 |  | Increase (Decrease) |
| Service | $ | 9,020 |  |  | $ | 9,640 |  |  | $ | (620 | ) |
| Product | 5,001 |  |  | 4,502 |  |  | 499 |  |
| Total | $ | 14,021 |  |  | $ | 14,142 |  |  | $ | (121 | ) |
| Reported as: |  |  |  |  |  |
| Current | $ | 9,369 |  |  | $ | 9,478 |  |  | $ | (109 | ) |
| Noncurrent | 4,652 |  |  | 4,664 |  |  | (12 | ) |
| Total | $ | 14,021 |  |  | $ | 14,142 |  |  | $ | (121 | ) |

[0000858877-15-000013:mdna:356]
The 6% decrease in deferred service revenue was driven by the timing of multiyear arrangements, an increase in customers paying technical support service contracts over time and the impact of ongoing amortization of deferred service revenue. The 11% increase in deferred product revenue was primarily due to increased deferrals related to subscription revenue arrangements and also was due, to a lesser extent, to an increase in shipments not having met revenue recognition criteria as of January 24, 2015.

[0000858877-15-000013:mdna:357]
[same as prior period, unchanged from 0000858877-14-000043:mdna:297]

[0000858877-15-000013:mdna:358]
[same as prior period, unchanged from 0000858877-14-000043:mdna:298]

[0000858877-15-000013:mdna:359]
We lease office space in many U.S. locations. Outside the United States, larger leased sites include sites in Belgium, Canada, China, France, Germany, India, Israel, Japan, Norway, and the United Kingdom. We also lease equipment and vehicles. The future minimum lease payments under all of our noncancelable operating leases with an initial term in excess of one year as of January 24, 2015 were $1.1 billion.

[0000858877-15-000013:mdna:360]
[same as prior period, unchanged from 0000858877-14-000043:mdna:300]

[0000858877-15-000013:mdna:361]
[same as prior period, unchanged from 0000858877-14-000043:mdna:301]

[0000858877-15-000013:mdna:362]
[same as prior period, unchanged from 0000858877-14-000043:mdna:302]

[0000858877-15-000013:mdna:363]
During the first quarter of fiscal 2014, we exercised our call option and entered into an agreement to purchase the remaining interests in Insieme. The acquisition closed in the second quarter of fiscal 2014, at which time the former noncontrolling interest holders became eligible to receive up to two milestone payments, which will be determined using agreed-upon formulas based primarily on revenue for certain of Insieme’s products.  During the six months ended January 24, 2015 and January 25, 2014, we recorded compensation expense of $104 million and $311 million, respectively, related to the fair value of the vested portion of amounts that are expected to be earned by the former noncontrolling interest holders. Continued vesting and changes to the fair value of the amounts probable of being earned will result in adjustments to the recorded compensation expense in future periods. Based on the terms of the agreement, we have determined that the maximum amount that could be recorded as compensation expense by us is approximately $845 million (which includes the $520 million that has been expensed to date), net of forfeitures.  The milestone payments, if earned, are expected to be paid primarily during fiscal 2016 and fiscal 2017.

[0000858877-15-000013:mdna:364]
Other Funding Commitments  We also have certain funding commitments primarily related to our investments in privately held companies and venture funds, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $230 million as of January 24, 2015, compared with $255 million as of July 26, 2014.

[0000858877-15-000013:mdna:365]
CISCO SYSTEMS, INC.

[0000858877-15-000013:mdna:366]
MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS (Continued)

[0000858877-15-000013:mdna:367]
[same as prior period, unchanged from 0000858877-14-000043:mdna:307]

[0000858877-15-000013:mdna:368]
We consider our investments in unconsolidated variable interest entities to be off-balance sheet arrangements. In the ordinary course of business, we have investments in privately held companies and provide financing to certain customers. These privately held companies and customers may be considered to be variable interest entities. We evaluate on an ongoing basis our investments in these privately held companies and customer financings, and we have determined that as of January 24, 2015 there were no material unconsolidated variable interest entities.

[0000858877-15-000013:mdna:369]
[same as prior period, unchanged from 0000858877-14-000043:mdna:312]

[0000858877-15-000013:mdna:370]
[same as prior period, unchanged from 0000858877-14-000043:mdna:313]

[0000858877-15-000013:mdna:371]
[same as prior period, unchanged from 0000858877-14-000043:mdna:314]

[0000858877-15-000013:mdna:372]
We periodically engage in securities lending activities with certain of our available-for-sale investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. The average daily balance of securities lending for the six months ended January 24, 2015 and January 25, 2014 was $0.6 billion and $0.9 billion, respectively. We require collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. We engage in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify us against collateral losses. As of January 24, 2015 and July 26, 2014, we had no outstanding securities lending transactions. We believe these arrangements do not present a material risk or impact to our liquidity requirements.

[0000858877-15-000013:mdna:373]
[same as prior period, unchanged from 0000858877-14-000043:mdna:316]

[0000858877-15-000013:mdna:374]
[same as prior period, unchanged from 0000858877-14-000043:mdna:317]

[0000858877-15-000013:mdna:375]
71
