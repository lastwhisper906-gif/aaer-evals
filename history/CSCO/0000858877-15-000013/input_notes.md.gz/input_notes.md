# CSCO notes — 0000858877-15-000013


## csco:CompensationexpensesrelatedtobusinesscombinationsTableTextBlock

[0000858877-15-000013:notes:1]
The following table summarizes the compensation expense related to acquisitions (in millions):

[0000858877-15-000013:notes:2]
|  | Three Months Ended |  | Six Months Ended |
|  | January 24, 2015 |  | January 25, 2014 |  | January 24, 2015 |  | January 25, 2014 |
| Compensation expense related to acquisitions | $ | 94 |  |  | $ | 106 |  |  | $ | 192 |  |  | $ | 410 |  |


## csco:DescriptionOfNewAccountingPronouncementsNotYetAdoptedPolicyTextBlock

[0000858877-15-000013:notes:3]
Recent Accounting Standards or Updates Not Yet Effective

[0000858877-15-000013:notes:4]
In May 2014, the FASB issued an accounting standard update related to revenue from contracts with customers, which will supersede nearly all current U.S. GAAP guidance on this topic and eliminate industry-specific guidance.  The underlying principle is to recognize revenue when promised goods or services are transferred to customers in an amount that reflects the consideration that is expected to be received for those goods or services. This accounting standard update will be effective for the Company beginning in the first quarter of fiscal 2018. The new revenue standard may be applied retrospectively to each prior period presented or retrospectively with the cumulative effect recognized as of the date of adoption.  Early adoption is not permitted.  The Company is currently evaluating the impact of this accounting standard update on its Consolidated Financial Statements.


## csco:EntityWideDisclosureOnGeographicAreasLongLivedAssetsTableTextBlock

[0000858877-15-000013:notes:5]
[same as prior period, unchanged from 0000858877-14-000043:notes:294]

[0000858877-15-000013:notes:6]
|  | January 24, 2015 |  | July 26, 2014 |
| Property and equipment, net: |  |  |  |
| United States | $ | 2,668 |  |  | $ | 2,697 |  |
| International | 544 |  |  | 555 |  |
| Total | $ | 3,212 |  |  | $ | 3,252 |  |


## csco:IncometaxprovisionTableTextBlock

[0000858877-15-000013:notes:7]
The following table provides details of income taxes (in millions, except percentages):

[0000858877-15-000013:notes:8]
|  | Three Months Ended |  | Six Months Ended |
|  | January 24, 2015 |  | January 25, 2014 |  | January 24, 2015 |  | January 25, 2014 |
| Income before provision for income taxes | $ | 2,873 |  |  | $ | 1,755 |  |  | $ | 5,233 |  |  | $ | 4,295 |  |
| Provision for income taxes | $ | 476 |  |  | $ | 326 |  |  | $ | 1,008 |  |  | $ | 870 |  |
| Effective tax rate | 16.6 | % |  | 18.6 | % |  | 19.3 | % |  | 20.3 | % |


## csco:NetSalesForGroupsOfSimilarProductsAndServicesTableTextBlock

[0000858877-15-000013:notes:9]
[same as prior period, unchanged from 0000858877-14-000043:notes:296]

[0000858877-15-000013:notes:10]
|  | Three Months Ended |  | Six Months Ended |
|  | January 24, 2015 |  | January 25, 2014 |  | January 24, 2015 |  | January 25, 2014 |
| Revenue: |  |  |  |  |  |  |  |
| Switching | $ | 3,616 |  |  | $ | 3,258 |  |  | $ | 7,462 |  |  | $ | 6,998 |  |
| NGN Routing | 1,764 |  |  | 1,730 |  |  | 3,713 |  |  | 3,756 |  |
| Collaboration | 990 |  |  | 899 |  |  | 1,939 |  |  | 1,950 |  |
| Service Provider Video | 776 |  |  | 957 |  |  | 1,647 |  |  | 1,944 |  |
| Data Center | 846 |  |  | 605 |  |  | 1,539 |  |  | 1,206 |  |
| Wireless | 611 |  |  | 517 |  |  | 1,216 |  |  | 1,064 |  |
| Security | 416 |  |  | 393 |  |  | 871 |  |  | 758 |  |
| Other | 59 |  |  | 64 |  |  | 126 |  |  | 144 |  |
| Product | 9,078 |  |  | 8,423 |  |  | 18,513 |  |  | 17,820 |  |
| Service | 2,858 |  |  | 2,732 |  |  | 5,668 |  |  | 5,420 |  |
| Total | $ | 11,936 |  |  | $ | 11,155 |  |  | $ | 24,181 |  |  | $ | 23,240 |  |


## csco:ScheduleOfCommonStockRepurchasedTextBlock

[0000858877-15-000013:notes:11]
A summary of the stock repurchase activity under the stock repurchase program, reported based on the trade date, is summarized as follows (in millions, except per-share amounts):

[0000858877-15-000013:notes:12]
|  | SharesRepurchased |  | Weighted-Average Priceper Share |  | AmountRepurchased |
| Cumulative balance at July 26, 2014 | 4,288 |  |  | $ | 20.63 |  |  | $ | 88,445 |  |
| Repurchase of common stock under the stock repurchase program (1) | 85 |  |  | 26.15 |  |  | 2,221 |  |
| Cumulative balance at January 24, 2015 | 4,373 |  |  | $ | 20.73 |  |  | $ | 90,666 |  |

[0000858877-15-000013:notes:13]
(1) Includes stock repurchases of $150 million, which were pending settlement as of January 24, 2015. There were $126 million of stock repurchases that were pending settlement as of July 26, 2014.


## csco:ScheduleOfDerivativeFairValueHedgeInstrumentsGainLossInStatementOfFinancialPerformanceTableTextBlock

[0000858877-15-000013:notes:14]
The effect on the Consolidated Statements of Operations of derivative instruments designated as fair value hedges and the underlying hedged items is summarized as follows (in millions):

[0000858877-15-000013:notes:15]
|  |  |  |  | GAINS (LOSSES) ONDERIVATIVEINSTRUMENTS FOR THETHREE MONTHS ENDED |  | GAINS (LOSSES)RELATED TO HEDGEDITEMS FOR THE THREEMONTHS ENDED |
| Derivatives Designated as Fair Value Hedging Instruments |  | Line Item in Statements of Operations |  | January 24, 2015 |  | January 25, 2014 |  | January 24, 2015 |  | January 25, 2014 |
| Equity derivatives |  | Other income (loss), net |  | $ | (18 | ) |  | $ | (12 | ) |  | $ | 18 |  |  | $ | 12 |  |
| Interest rate derivatives |  | Interest expense |  | 61 |  |  | (53 | ) |  | (61 | ) |  | 54 |  |
| Total |  |  |  | $ | 43 |  |  | $ | (65 | ) |  | $ | (43 | ) |  | $ | 66 |  |

[0000858877-15-000013:notes:16]
|  |  |  |  | GAINS (LOSSES) ONDERIVATIVEINSTRUMENTS FOR THESIX MONTHS ENDED |  | GAINS (LOSSES)RELATED TO HEDGEDITEMS FOR THE SIXMONTHS ENDED |
| Derivatives Designated as Fair Value Hedging Instruments |  | Line Item in Statements of Operations |  | January 24, 2015 |  | January 25, 2014 |  | January 24, 2015 |  | January 25, 2014 |
| Equity derivatives |  | Other income (loss), net |  | $ | (12 | ) |  | $ | (47 | ) |  | $ | 12 |  |  | $ | 47 |  |
| Interest rate derivatives |  | Interest expense |  | 131 |  |  | (35 | ) |  | (134 | ) |  | 34 |  |
| Total |  |  |  | $ | 119 |  |  | $ | (82 | ) |  | $ | (122 | ) |  | $ | 81 |  |


## csco:ScheduleOfFiniteLivedIntangibleAssetsAmortizationExpenseTableTextBlock

[0000858877-15-000013:notes:17]
The following table presents the amortization of purchased intangible assets (in millions):

[0000858877-15-000013:notes:18]
|  | Three Months Ended |  | Six Months Ended |
|  | January 24, 2015 |  | January 25, 2014 |  | January 24, 2015 |  | January 25, 2014 |
| Amortization of purchased intangible assets: |  |  |  |  |  |  |  |
| Cost of sales | $ | 242 |  |  | $ | 189 |  |  | $ | 431 |  |  | $ | 363 |  |
| Operating expenses | 72 |  |  | 71 |  |  | 143 |  |  | 136 |  |
| Total | $ | 314 |  |  | $ | 260 |  |  | $ | 574 |  |  | $ | 499 |  |


## csco:ScheduleOfIntangibleAssetsAcquiredAsPartOfBusinessCombinationTextBlock

[0000858877-15-000013:notes:19]
The following table presents details of the Company’s intangible assets acquired through business combinations completed during the six months ended January 24, 2015 (in millions, except years):

[0000858877-15-000013:notes:20]
|  | FINITE LIVES |  | INDEFINITELIVES |  | TOTAL |
|  | TECHNOLOGY |  | CUSTOMERRELATIONSHIPS |  | IPR&D |  |
|  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Weighted-Average UsefulLife (in Years) |  | Amount |  | Amount |  | Amount |
| Metacloud, Inc. | 3.0 |  | $ | 24 |  |  | 5.0 |  | $ | 3 |  |  | $ | 2 |  |  | $ | 29 |  |
| All others (two in total) | 5.0 |  | 25 |  |  | 8.1 |  | 11 |  |  | 4 |  |  | 40 |  |
| Total |  |  | $ | 49 |  |  |  |  | $ | 14 |  |  | $ | 6 |  |  | $ | 69 |  |


## csco:ScheduleOfIntangibleAssetsByMajorClassTextBlock

[0000858877-15-000013:notes:21]
The following tables present details of the Company’s purchased intangible assets (in millions):

[0000858877-15-000013:notes:22]
| January 24, 2015 |  | Gross |  | Accumulated Amortization |  | Net |
| Purchased intangible assets with finite lives: |  |  |  |  |  |  |
| Technology |  | $ | 4,020 |  |  | $ | (2,270 | ) |  | $ | 1,750 |  |
| Customer relationships |  | 1,709 |  |  | (847 | ) |  | 862 |  |
| Other |  | 51 |  |  | (19 | ) |  | 32 |  |
| Total purchased intangible assets with finite lives |  | 5,780 |  |  | (3,136 | ) |  | 2,644 |  |
| In-process research and development, with indefinite lives |  | 111 |  |  | — |  |  | 111 |  |
| Total |  | $ | 5,891 |  |  | $ | (3,136 | ) |  | $ | 2,755 |  |

[0000858877-15-000013:notes:23]
| July 26, 2014 |  | Gross |  | AccumulatedAmortization |  | Net |
| Purchased intangible assets with finite lives: |  |  |  |  |  |  |
| Technology |  | $ | 4,100 |  |  | $ | (1,976 | ) |  | $ | 2,124 |  |
| Customer relationships |  | 1,706 |  |  | (720 | ) |  | 986 |  |
| Other |  | 51 |  |  | (13 | ) |  | 38 |  |
| Total purchased intangible assets with finite lives |  | 5,857 |  |  | (2,709 | ) |  | 3,148 |  |
| In-process research and development, with indefinite lives |  | 132 |  |  | — |  |  | 132 |  |
| Total |  | $ | 5,989 |  |  | $ | (2,709 | ) |  | $ | 3,280 |  |


## csco:SegmentReportingProductAndServicesNetSalesTextBlock

[0000858877-15-000013:notes:24]
[same as prior period, unchanged from 0000858877-14-000043:notes:298]

[0000858877-15-000013:notes:25]
[same as prior period, unchanged from 0000858877-14-000043:notes:299]

[0000858877-15-000013:notes:26]
The Company conducts business globally and is primarily managed on a geographic basis consisting of three segments: the Americas, EMEA, and APJC. The Company’s management makes financial decisions and allocates resources based on the information it receives from its internal management system. Sales are attributed to a segment based on the ordering location of the customer. The Company does not allocate research and development, sales and marketing, or general and administrative expenses to its segments in this internal management system because management does not include the information in its measurement of the performance of the operating segments. In addition, the Company does not allocate amortization and impairment of acquisition-related intangible assets, share-based compensation expense, significant litigation and other contingencies, impacts to cost of sales from purchase accounting adjustments to inventory, charges related to asset impairments and restructurings, and certain other charges to the gross margin for each segment because management does not include this information in its measurement of the performance of the operating segments.

[0000858877-15-000013:notes:27]
Summarized financial information by segment for the three and six months ended January 24, 2015 and January 25, 2014, based on the Company’s internal management system and as utilized by the Company’s Chief Operating Decision Maker ("CODM"), is as follows (in millions):

[0000858877-15-000013:notes:28]
|  | Three Months Ended |  | Six Months Ended |
|  | January 24, 2015 |  | January 25, 2014 |  | January 24, 2015 |  | January 25, 2014 |
| Revenue: |  |  |  |  |  |  |  |
| Americas | $ | 7,101 |  |  | $ | 6,460 |  |  | $ | 14,602 |  |  | $ | 13,776 |  |
| EMEA | 3,091 |  |  | 2,896 |  |  | 6,093 |  |  | 5,829 |  |
| APJC | 1,744 |  |  | 1,799 |  |  | 3,486 |  |  | 3,635 |  |
| Total | $ | 11,936 |  |  | $ | 11,155 |  |  | $ | 24,181 |  |  | $ | 23,240 |  |
| Gross margin: |  |  |  |  |  |  |  |
| Americas | $ | 4,406 |  |  | $ | 3,977 |  |  | $ | 9,216 |  |  | $ | 8,627 |  |
| EMEA | 1,910 |  |  | 1,870 |  |  | 3,825 |  |  | 3,758 |  |
| APJC | 1,052 |  |  | 993 |  |  | 2,077 |  |  | 2,072 |  |
| Segment total | 7,368 |  |  | 6,840 |  |  | 15,118 |  |  | 14,457 |  |
| Unallocated corporate items | (278 | ) |  | (889 | ) |  | (695 | ) |  | (1,099 | ) |
| Total | $ | 7,090 |  |  | $ | 5,951 |  |  | $ | 14,423 |  |  | $ | 13,358 |  |

[0000858877-15-000013:notes:29]
Revenue in the United States was $6.1 billion and $5.6 billion for the three months ended January 24, 2015 and January 25, 2014, respectively, and was $12.7 billion and $12.0 billion for the six months ended January 24, 2015 and January 25, 2014, respectively.

[0000858877-15-000013:notes:30]
[same as prior period, unchanged from 0000858877-14-000043:notes:302]

[0000858877-15-000013:notes:31]
[same as prior period, unchanged from 0000858877-14-000043:notes:303]

[0000858877-15-000013:notes:32]
[same as prior period, unchanged from 0000858877-14-000043:notes:304]

[0000858877-15-000013:notes:33]
[same as prior period, unchanged from 0000858877-14-000043:notes:305]

[0000858877-15-000013:notes:34]
The majority of the Company’s assets, excluding cash and cash equivalents and investments, as of January 24, 2015 and July 26, 2014 were attributable to its U.S. operations. The Company’s total cash and cash equivalents and investments held by various foreign subsidiaries were $49.8 billion and $47.4 billion as of January 24, 2015 and July 26, 2014, respectively, and the remaining $3.2 billion and $4.7 billion at the respective period ends were available in the United States.


## csco:StockRepurchasesSinceInceptionOfProgramTableTextBlock

[0000858877-15-000013:notes:35]
The stock repurchases since the inception of this program and the related impacts on Cisco shareholders’ equity are summarized in the following table (in millions):

[0000858877-15-000013:notes:36]
|  | Shares ofCommonStock |  | Common Stockand AdditionalPaid-In Capital |  | RetainedEarnings |  | Total CiscoShareholders’Equity |
| Repurchases of common stock under the repurchase program | 4,373 |  |  | $ | 22,021 |  |  | $ | 68,645 |  |  | $ | 90,666 |  |


## us-gaap:AllowanceForCreditLossesOnFinancingReceivablesTableTextBlock

[0000858877-15-000013:notes:37]
[same as prior period, unchanged from 0000858877-14-000043:notes:1]

[0000858877-15-000013:notes:38]
|  | CREDIT LOSS ALLOWANCES |
| Three Months Ended January 24, 2015 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts and Other |  | Total |
| Allowance for credit loss as of October 25, 2014 | $ | 248 |  |  | $ | 84 |  |  | $ | 36 |  |  | $ | 368 |  |
| Provisions | 7 |  |  | 3 |  |  | 4 |  |  | 14 |  |
| Recoveries (write-offs), net | (1 | ) |  | — |  |  | — |  |  | (1 | ) |
| Foreign exchange and other | (4 | ) |  | (2 | ) |  | — |  |  | (6 | ) |
| Allowance for credit loss as of January 24, 2015 | $ | 250 |  |  | $ | 85 |  |  | $ | 40 |  |  | $ | 375 |  |
| Financing receivables as of January 24, 2015 (1) | $ | 3,391 |  |  | $ | 1,674 |  |  | $ | 3,069 |  |  | $ | 8,134 |  |

[0000858877-15-000013:notes:39]
|  | CREDIT LOSS ALLOWANCES |
| Six Months Ended January 24, 2015 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts and Other |  | Total |
| Allowance for credit loss as of July 26, 2014 | $ | 233 |  |  | $ | 98 |  |  | $ | 18 |  |  | $ | 349 |  |
| Provisions | 29 |  |  | (10 | ) |  | 23 |  |  | 42 |  |
| Recoveries (write-offs), net | (5 | ) |  | 1 |  |  | — |  |  | (4 | ) |
| Foreign exchange and other | (7 | ) |  | (4 | ) |  | (1 | ) |  | (12 | ) |
| Allowance for credit loss as of January 24, 2015 | $ | 250 |  |  | $ | 85 |  |  | $ | 40 |  |  | $ | 375 |  |

[0000858877-15-000013:notes:40]
|  | CREDIT LOSS ALLOWANCES |
| Three Months Ended January 25, 2014 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts and Other |  | Total |
| Allowance for credit loss as of October 26, 2013 | $ | 237 |  |  | $ | 93 |  |  | $ | 20 |  |  | $ | 350 |  |
| Provisions | 18 |  |  | 9 |  |  | 2 |  |  | 29 |  |
| Recoveries (write-offs), net | 1 |  |  | — |  |  | — |  |  | 1 |  |
| Foreign exchange and other | (2 | ) |  | (4 | ) |  | — |  |  | (6 | ) |
| Allowance for credit loss as of January 25, 2014 | $ | 254 |  |  | $ | 98 |  |  | $ | 22 |  |  | $ | 374 |  |
| Financing receivables as of January 25, 2014 (1) | $ | 3,551 |  |  | $ | 1,660 |  |  | $ | 2,807 |  |  | $ | 8,018 |  |

[0000858877-15-000013:notes:41]
|  | CREDIT LOSS ALLOWANCES |
| Six Months Ended January 25, 2014 | LeaseReceivables |  | LoanReceivables |  | Financed ServiceContracts and Other |  | Total |
| Allowance for credit loss as of July 27, 2013 | $ | 238 |  |  | $ | 86 |  |  | $ | 20 |  |  | $ | 344 |  |
| Provisions | 15 |  |  | 15 |  |  | 2 |  |  | 32 |  |
| Recoveries (write-offs), net | 1 |  |  | — |  |  | — |  |  | 1 |  |
| Foreign exchange and other | — |  |  | (3 | ) |  | — |  |  | (3 | ) |
| Allowance for credit loss as of January 25, 2014 | $ | 254 |  |  | $ | 98 |  |  | $ | 22 |  |  | $ | 374 |  |

[0000858877-15-000013:notes:42]
[same as prior period, unchanged from 0000858877-14-000043:notes:4]


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000858877-15-000013:notes:43]
[same as prior period, unchanged from 0000858877-14-000043:notes:5]

[0000858877-15-000013:notes:44]
The Company completed three business combinations during the six months ended January 24, 2015.  A summary of the allocation of the total purchase consideration is presented as follows (in millions):

[0000858877-15-000013:notes:45]
|  | Purchase Consideration |  | Net Liabilities Assumed |  | Purchased Intangible Assets |  | Goodwill |
| Metacloud, Inc. | $ | 149 |  |  | $ | (7 | ) |  | $ | 29 |  |  | $ | 127 |  |
| All others (two in total) | 71 |  |  | (10 | ) |  | 40 |  |  | 41 |  |
| Total acquisitions | $ | 220 |  |  | $ | (17 | ) |  | $ | 69 |  |  | $ | 168 |  |

[0000858877-15-000013:notes:46]
On September 29, 2014, the Company completed its acquisition of Metacloud, Inc. ("Metacloud"), a provider of private clouds for global organizations.  With its acquisition of Metacloud, the Company aims to advance its Intercloud strategy to deliver a globally distributed, highly secure cloud platform capable of meeting customer demands. Revenue from the Metacloud acquisition has been included in the Company's Service category.

[0000858877-15-000013:notes:47]
The total purchase consideration related to the Company’s business combinations completed during the six months ended January 24, 2015 consisted of cash consideration and vested share-based awards assumed. The total cash and cash equivalents acquired from these business combinations was approximately $4 million. Total transaction costs related to the Company’s business combination activities were $5 million and $6 million for the six months ended January 24, 2015 and January 25, 2014, respectively. These transaction costs were expensed as incurred in general and administrative (G&A) expenses in the Consolidated Statements of Operations.

[0000858877-15-000013:notes:48]
The Company’s purchase price allocation for business combinations completed during recent periods is preliminary and subject to revision as additional information about fair value of assets and liabilities becomes available. Additional information, that existed as of the acquisition date but at that time was unknown to the Company may become known to the Company during the remainder of the measurement period, a period not to exceed 12 months from the acquisition date. Adjustments in the purchase price allocation may require a recasting of the amounts allocated to goodwill retroactive to the period in which the acquisition occurred.

[0000858877-15-000013:notes:49]
The goodwill generated from the Company’s business combinations completed during the six months ended January 24, 2015 is primarily related to expected synergies. The goodwill is generally not deductible for income tax purposes.

[0000858877-15-000013:notes:50]
The Consolidated Financial Statements include the operating results of each business combination from the date of acquisition. Pro forma results of operations for the acquisitions completed during the six months ended January 24, 2015 have not been presented because the effects of the acquisitions, individually and in the aggregate, were not material to the Company’s financial results.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000858877-15-000013:notes:51]
| 12. | Commitments and Contingencies |

[0000858877-15-000013:notes:52]
| (a) | Operating Leases |

[0000858877-15-000013:notes:53]
The Company leases office space in many U.S. locations. Outside the United States, larger leased sites include sites in Belgium, Canada, China, France, Germany, India, Israel, Japan, Norway, and the United Kingdom.  The Company also leases equipment and vehicles. Future minimum lease payments under all noncancelable operating leases with an initial term in excess of one year as of January 24, 2015 are as follows (in millions):

[0000858877-15-000013:notes:54]
| Fiscal Year | Amount |
| 2015 (remaining six months) | $ | 195 |  |
| 2016 | 287 |  |
| 2017 | 196 |  |
| 2018 | 139 |  |
| 2019 | 72 |  |
| Thereafter | 209 |  |
| Total | $ | 1,098 |  |

[0000858877-15-000013:notes:55]
| (b) | Purchase Commitments with Contract Manufacturers and Suppliers |

[0000858877-15-000013:notes:56]
The Company purchases components from a variety of suppliers and uses several contract manufacturers to provide manufacturing services for its products. During the normal course of business, in order to manage manufacturing lead times and help ensure adequate component supply, the Company enters into agreements with contract manufacturers and suppliers that allow them to either procure inventory based upon criteria as defined by the Company or establish the parameters defining the Company’s requirements. A significant portion of the Company’s reported purchase commitments arising from these agreements consists of firm, noncancelable, and unconditional commitments. In certain instances, these agreements allow the Company the option to cancel, reschedule, and adjust the Company’s requirements based on its business needs prior to firm orders being placed. As of January 24, 2015 and July 26, 2014, the Company had total purchase commitments for inventory of $4,257 million and $4,169 million, respectively.

[0000858877-15-000013:notes:57]
The Company records a liability for firm, noncancelable, and unconditional purchase commitments for quantities in excess of its future demand forecasts consistent with the valuation of the Company’s excess and obsolete inventory. As of January 24, 2015 and July 26, 2014, the liability for these purchase commitments was $165 million and $162 million, respectively, and was included in other current liabilities.

[0000858877-15-000013:notes:58]
| (c) | Other Commitments |

[0000858877-15-000013:notes:59]
In connection with the Company’s business combinations, the Company has agreed to pay certain additional amounts contingent upon the achievement of certain agreed-upon technology, development, product, or other milestones or upon the continued employment with the Company of certain employees of the acquired entities.

[0000858877-15-000013:notes:60]
As of January 24, 2015, the Company estimated that future cash compensation expense of up to $428 million may be required to be recognized pursuant to the applicable business combination agreements, which included the remaining potential compensation expense related to Insieme Networks, Inc., as more fully discussed immediately below.

[0000858877-15-000013:notes:61]
Insieme Networks, Inc.    In the third quarter of fiscal 2012, the Company made an investment in Insieme Networks, Inc. ("Insieme"), an early stage company focused on research and development in the data center market.  As set forth in the agreement between the Company and Insieme, this investment included $100 million of funding and a license to certain of the Company’s technology.  Immediately prior to the call option exercise and acquisition described below, the Company owned approximately 83% of Insieme as a result of these investments and consolidated the results of Insieme in its Consolidated Financial Statements.  In connection with this investment, the Company and Insieme entered into a put/call option agreement that provided the Company with the right to purchase the remaining interests in Insieme.  In addition, the noncontrolling interest holders could require the Company to purchase their shares upon the occurrence of certain events.

[0000858877-15-000013:notes:62]
During the first quarter of fiscal 2014, the Company exercised its call option and entered into an agreement to purchase the remaining interests in Insieme.  The acquisition closed in the second quarter of fiscal 2014, at which time the former noncontrolling interest holders became eligible to receive up to two milestone payments, which will be determined using agreed-upon formulas based primarily on revenue for certain of Insieme’s products.  The Company recorded compensation expense of $51 million and $54 million during the three months ended January 24, 2015 and January 25, 2014, respectively, and $104 million and $311 million during the six months ended January 24, 2015 and January 25, 2014, respectively, related to the fair value of the vested portion of amounts that are expected to be earned by the former noncontrolling interest holders.  Continued vesting and changes to the fair value of the amounts probable of being earned will result in adjustments to the recorded compensation expense in future periods.  Based on the terms of the agreement, the Company has determined that the maximum amount that could be recorded as compensation expense by the Company is approximately $845 million (which includes the $520 million that has been expensed to date), net of forfeitures.  The milestone payments, if earned, are expected to be paid primarily during fiscal 2016 and fiscal 2017.

[0000858877-15-000013:notes:63]
The Company also has certain funding commitments, primarily related to its investments in privately held companies and venture funds, some of which are based on the achievement of certain agreed-upon milestones, and some of which are required to be funded on demand. The funding commitments were $230 million and $255 million as of January 24, 2015 and July 26, 2014, respectively.

[0000858877-15-000013:notes:64]
| (d) | Product Warranties |

[0000858877-15-000013:notes:65]
The following table summarizes the activity related to the product warranty liability (in millions):

[0000858877-15-000013:notes:66]
|  | Six Months Ended |
|  | January 24, 2015 |  | January 25, 2014 |
| Balance at beginning of period | $ | 446 |  |  | $ | 402 |  |
| Provision for warranties issued | 355 |  |  | 356 |  |
| Payments | (327 | ) |  | (333 | ) |
| Balance at end of period | $ | 474 |  |  | $ | 425 |  |

[0000858877-15-000013:notes:67]
The Company accrues for warranty costs as part of its cost of sales based on associated material product costs, labor costs for technical support staff, and associated overhead. The Company’s products are generally covered by a warranty for periods ranging from 90 days to five years, and for some products the Company provides a limited lifetime warranty.

[0000858877-15-000013:notes:68]
| (e) | Financing and Other Guarantees |

[0000858877-15-000013:notes:69]
In the ordinary course of business, the Company provides financing guarantees for various third-party financing arrangements extended to channel partners and end-user customers. Payments under these financing guarantee arrangements were not material for the periods presented.

[0000858877-15-000013:notes:70]
Channel Partner Financing Guarantees   The Company facilitates arrangements for third-party financing extended to channel partners, consisting of revolving short-term financing, generally with payment terms ranging from 60 to 90 days. These financing arrangements facilitate the working capital requirements of the channel partners, and, in some cases, the Company guarantees a portion of these arrangements. The volume of channel partner financing was $6.2 billion and $5.9 billion for the three months ended January 24, 2015 and January 25, 2014, respectively. The volume of channel partner financing was $12.5 billion and $12.2 billion for the six months ended January 24, 2015 and January 25, 2014, respectively.  The balance of the channel partner financing subject to guarantees was $1.3 billion and $1.2 billion as of January 24, 2015 and July 26, 2014, respectively.

[0000858877-15-000013:notes:71]
End-User Financing Guarantees   The Company also provides financing guarantees for third-party financing arrangements extended to end-user customers related to leases and loans, which typically have terms of up to three years. The volume of financing provided by third parties for leases and loans as to which the Company had provided guarantees was $39 million and $20 million for the three months ended January 24, 2015 and January 25, 2014, respectively, and was $65 million and $45 million for the six months ended January 24, 2015 and January 25, 2014, respectively.

[0000858877-15-000013:notes:72]
Financing Guarantee Summary   The aggregate amounts of financing guarantees outstanding at January 24, 2015 and July 26, 2014, representing the total maximum potential future payments under financing arrangements with third parties along with the related deferred revenue, are summarized in the following table (in millions):

[0000858877-15-000013:notes:73]
|  | January 24, 2015 |  | July 26, 2014 |
| Maximum potential future payments relating to financing guarantees: |  |  |  |
| Channel partner | $ | 316 |  |  | $ | 263 |  |
| End user | 155 |  |  | 202 |  |
| Total | $ | 471 |  |  | $ | 465 |  |
| Deferred revenue associated with financing guarantees: |  |  |  |
| Channel partner | $ | (148 | ) |  | $ | (127 | ) |
| End user | (121 | ) |  | (166 | ) |
| Total | $ | (269 | ) |  | $ | (293 | ) |
| Maximum potential future payments relating to financing guarantees, net of associated deferred revenue | $ | 202 |  |  | $ | 172 |  |

[0000858877-15-000013:notes:74]
Other Guarantees   The Company’s other guarantee arrangements as of January 24, 2015 and July 26, 2014 that were subject to recognition and disclosure requirements were not material.

[0000858877-15-000013:notes:75]
| (f) | Supplier Component Remediation Liability |

[0000858877-15-000013:notes:76]
The Company has recorded in other current liabilities a liability for the expected remediation cost for certain products sold in prior fiscal years containing memory components manufactured by a single supplier between 2005 and 2010. These components are widely used across the industry and are included in a number of the Company's products. Defects in some of these components have caused products to fail after a power cycle event.  Defect rates due to this issue have been and are expected to be low. However, the Company has seen a small number of its customers experience a growing number of failures in their networks as a result of this component problem. Although the majority of these products are beyond the Company's warranty terms, the Company is proactively working with customers on mitigation.  Prior to the second quarter of fiscal 2014, the Company had a liability of $63 million related to this issue for expected remediation costs based on the intended approach at that time. In February 2014, on the basis of the growing number of failures described above, the Company decided to expand its approach, which resulted in an additional charge to product cost of sales of $655 million being recorded for the second quarter of fiscal 2014.  The remaining supplier component remediation liability as of January 24, 2015 and July 26, 2014 was $613 million and $670 million, respectively.

[0000858877-15-000013:notes:77]
| (g) | Indemnifications |

[0000858877-15-000013:notes:78]
In the normal course of business, the Company indemnifies other parties, including customers, lessors, and parties to other transactions with the Company, with respect to certain matters. The Company has agreed to hold such parties harmless against losses arising from a breach of representations or covenants or out of intellectual property infringement or other claims made against certain parties. These agreements may limit the time within which an indemnification claim can be made and the amount of the claim.

[0000858877-15-000013:notes:79]
The Company has an obligation to indemnify certain expenses pursuant to such an agreement in, among other cases, a case involving certain of the Company’s service provider customers that are subject to patent infringement claims asserted by Sprint Communications Company, L.P. (“Sprint”) in the U.S. District Court for the District of Kansas filed on December 19, 2011 (including one case that was later transferred to the District of Delaware).  Sprint alleges that the service providers infringe Sprint’s patents by offering Voice over Internet Protocol-based telephone services utilizing products provided by the Company and other manufacturers.  Sprint is seeking monetary damages. Trial dates have been set for the first half of calendar year 2016 in the case proceeding in the District of Kansas. Trial in Delaware is scheduled for February 2017. The parties conducted mediations, and the Company participated through a mediation involving a service provider customer. Those particular mediations did not resolve the parties’ disputes, but the parties plan to engage in additional dispute resolution efforts, including participation by the Company.  The Company believes that the service providers have strong defenses and that its products do not infringe the patents subject to the claims and/or that the patents are invalid.  Due to the uncertainty surrounding the litigation process, which involves numerous defendants, the Company is unable to reasonably estimate the ultimate outcome of this litigation at this time.  Should the plaintiff prevail in litigation, mediation, or settlement, the Company, in accordance with its agreement, may have an obligation to indemnify its service provider customers for damages, mediation awards, or settlement amounts arising from their use of Cisco products.

[0000858877-15-000013:notes:80]
In addition, the Company has entered into indemnification agreements with its officers and directors, and the Company’s Amended and Restated Bylaws contain similar indemnification obligations to the Company’s agents.

[0000858877-15-000013:notes:81]
It is not possible to determine the maximum potential amount under these indemnification agreements due to the Company’s limited history with prior indemnification claims and the unique facts and circumstances involved in each particular agreement. Historically, payments made by the Company under these agreements have not had a material effect on the Company’s operating results, financial position, or cash flows.

[0000858877-15-000013:notes:82]
| (h) | Legal Proceedings |

[0000858877-15-000013:notes:83]
Brazil    Brazilian authorities have investigated the Company’s Brazilian subsidiary and certain of its current and former employees, as well as a Brazilian importer of the Company’s products, and its affiliates and employees, relating to alleged evasion of import taxes and alleged improper transactions involving the subsidiary and the importer. Brazilian tax authorities have assessed claims against the Company’s Brazilian subsidiary based on a theory of joint liability with the Brazilian importer for import taxes, interest, and penalties. In addition to claims asserted by the Brazilian federal tax authorities in prior fiscal years, tax authorities from the Brazilian state of Sao Paulo have asserted similar claims on the same legal basis in prior fiscal years. In the first quarter of fiscal 2013, the Brazilian federal tax authorities asserted an additional claim against the Company’s Brazilian subsidiary based on a theory of joint liability with respect to an alleged underpayment of income taxes, social taxes, interest, and penalties by a Brazilian distributor.

[0000858877-15-000013:notes:84]
The asserted claims by Brazilian federal tax authorities are for calendar years 2003 through 2008, and the asserted claims by the tax authorities from the state of Sao Paulo are for calendar years 2005 through 2007. The total asserted claims by Brazilian state and federal tax authorities aggregate to approximately $335 million for the alleged evasion of import and other taxes, approximately $1.3 billion for interest, and approximately $1.5 billion for various penalties, all determined using an exchange rate as of January 24, 2015. The Company has completed a thorough review of the matters and believes the asserted claims against the Company’s Brazilian subsidiary are without merit, and the Company is defending the claims vigorously. While the Company believes there is no legal basis for the alleged liability, due to the complexities and uncertainty surrounding the judicial process in Brazil and the nature of the claims asserting joint liability with the importer, the Company is unable to determine the likelihood of an unfavorable outcome against its Brazilian subsidiary and is unable to reasonably estimate a range of loss, if any. The Company does not expect a final judicial determination for several years.

[0000858877-15-000013:notes:85]
Russia and the Commonwealth of Independent States    At the request of the U.S. Securities and Exchange Commission (SEC) and the U.S. Department of Justice, the Company is conducting an investigation into allegations which the Company and those agencies received regarding possible violations of the U.S. Foreign Corrupt Practices Act involving business activities of the Company's operations in Russia and certain of the Commonwealth of Independent States, and by certain resellers of the Company’s products in those countries.  The Company takes any such allegations very seriously and is fully cooperating with and sharing the results of its investigation with the SEC and the Department of Justice.  While the outcome of the Company's investigation is currently not determinable, the Company does not expect that it will have a material adverse effect on its consolidated financial position, results of operations, or cash flows. The countries that are the subject of the investigation collectively comprise less than 2% of the Company’s revenues.

[0000858877-15-000013:notes:86]
Rockstar    The Company and some of its service provider customers were subject to patent claims asserted in December 2013 in the Eastern District of Texas and the District of Delaware by subsidiaries of the Rockstar Consortium (“Rockstar”).  Rockstar, whose members include Apple, Microsoft, LM Ericsson, Sony, and Blackberry, had purchased a portfolio of patents out of the Nortel Networks’ bankruptcy proceedings (the “Nortel Portfolio”).  In connection with this matter, during the first quarter of fiscal 2015 the Company recorded a charge to product cost of sales of $188 million.

[0000858877-15-000013:notes:87]
In December 2014, RPX Corporation (“RPX”) and Rockstar entered into an agreement, which closed on January 28, 2015, resulting in over 30 technology companies, including the Company and the various service provider customers described above, obtaining a license to the patents owned by Rockstar. The Company paid approximately $300 million in connection with this transaction, with the payment recorded against the amount previously reserved and as an intangible asset to be amortized over its estimated useful life.  In connection with the closing of the transaction, Rockstar dismissed all litigation it had brought against the participating companies.

[0000858877-15-000013:notes:88]
In addition, the Company is subject to legal proceedings, claims, and litigation arising in the ordinary course of business, including intellectual property litigation. While the outcome of these matters is currently not determinable, the Company does not expect that the ultimate costs to resolve these matters will have a material adverse effect on its consolidated financial position, results of operations, or cash flows.


## us-gaap:ComprehensiveIncomeNoteTextBlock

[0000858877-15-000013:notes:89]
[same as prior period, unchanged from 0000858877-14-000043:notes:52]

[0000858877-15-000013:notes:90]
The components of AOCI, net of tax, and the other comprehensive income (loss), excluding noncontrolling interest, for the six months ended January 24, 2015 and January 25, 2014 are summarized as follows (in millions):

[0000858877-15-000013:notes:91]
| January 24, 2015 | Net Unrealized Gains on Investments |  | Net Unrealized Gains (Losses) Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Actuarial Gains (Losses) |  | Accumulated Other Comprehensive Income |
| BALANCE AT JULY 26, 2014 | $ | 424 |  |  | $ | (12 | ) |  | $ | 265 |  |  | $ | 677 |  |
| Other comprehensive income (loss) before reclassifications attributable to Cisco Systems, Inc. | (23 | ) |  | (131 | ) |  | (379 | ) |  | (533 | ) |
| (Gains) losses reclassified out of other comprehensive income | (76 | ) |  | 30 |  |  | — |  |  | (46 | ) |
| Tax benefit (expense) | 49 |  |  | 3 |  |  | 36 |  |  | 88 |  |
| BALANCE AT JANUARY 24, 2015 | $ | 374 |  |  | $ | (110 | ) |  | $ | (78 | ) |  | $ | 186 |  |

[0000858877-15-000013:notes:92]
| January 25, 2014 | Net Unrealized Gains on Investments |  | Net Unrealized Gains (Losses) Cash Flow Hedging Instruments |  | Cumulative Translation Adjustment and Actuarial Gains (Losses) |  | Accumulated Other Comprehensive Income |
| BALANCE AT JULY 27, 2013 | $ | 379 |  |  | $ | 8 |  |  | $ | 221 |  |  | $ | 608 |  |
| Other comprehensive income (loss) before reclassifications attributable to Cisco Systems, Inc. | 332 |  |  | 33 |  |  | (14 | ) |  | 351 |  |
| (Gains) losses reclassified out of other comprehensive income | (165 | ) |  | (28 | ) |  | — |  |  | (193 | ) |
| Tax benefit (expense) | (60 | ) |  | (2 | ) |  | (1 | ) |  | (63 | ) |
| BALANCE AT JANUARY 25, 2014 | $ | 486 |  |  | $ | 11 |  |  | $ | 206 |  |  | $ | 703 |  |

[0000858877-15-000013:notes:93]
[same as prior period, unchanged from 0000858877-14-000043:notes:56]

[0000858877-15-000013:notes:94]
|  |  | Three Months Ended |  | Six Months Ended |  |  |
|  |  | January 24, 2015 |  | January 25, 2014 |  | January 24, 2015 |  | January 25, 2014 |  |  |
| Comprehensive Income Components |  | Income Before Taxes |  | Income Before Taxes |  | Line Item in Statements of Operations |
| Net unrealized gains on available-for-sale investments |  |  |  |  |  |  |  |  |  |  |
|  |  | $ | 69 |  |  | $ | 82 |  |  | $ | 76 |  |  | $ | 165 |  |  | Other income (loss), net |
| Net unrealized gains and (losses) on cash flow hedging instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | (21 | ) |  | 16 |  |  | (24 | ) |  | 23 |  |  | Operating expenses |
| Foreign currency derivatives |  | (5 | ) |  | 3 |  |  | (6 | ) |  | 5 |  |  | Cost of sales—service |
|  |  | (26 | ) |  | 19 |  |  | (30 | ) |  | 28 |  |  |  |
| Total amounts reclassified out of other comprehensive income |  | $ | 43 |  |  | $ | 101 |  |  | $ | 46 |  |  | $ | 193 |  |  |  |


## us-gaap:DebtDisclosureTextBlock

[0000858877-15-000013:notes:95]
| 10. | Borrowings |

[0000858877-15-000013:notes:96]
| (a) | Short-Term Debt |

[0000858877-15-000013:notes:97]
The following table summarizes the Company’s short-term debt (in millions, except percentages):

[0000858877-15-000013:notes:98]
|  | January 24, 2015 |  | July 26, 2014 |
|  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Current portion of long-term debt | $ | 850 |  |  | 0.36 | % |  | $ | 500 |  |  | 3.11 | % |
| Other short-term debt | 5 |  |  | 2.73 | % |  | 8 |  |  | 2.67 | % |
| Total short-term debt | $ | 855 |  |  |  |  | $ | 508 |  |  |  |

[0000858877-15-000013:notes:99]
In fiscal 2011, the Company established a short-term debt financing program of up to $3.0 billion through the issuance of commercial paper notes. The Company uses the proceeds from the issuance of commercial paper notes for general corporate purposes. The Company had no commercial paper notes outstanding as of each of January 24, 2015 and July 26, 2014.

[0000858877-15-000013:notes:100]
The effective interest rate on the current portion of long-term debt includes the impact of interest rate swaps, as discussed further in "

[0000858877-15-000013:notes:101]
| (b) | Long-Term Debt |

[0000858877-15-000013:notes:102]
."  Other notes and borrowings consist of the short-term portion of secured borrowings associated with customer financing arrangements.  These notes and credit facilities were subject to various terms and foreign currency market interest rates pursuant to individual financial arrangements between the financing institution and the applicable foreign subsidiary.

[0000858877-15-000013:notes:103]
On November 17, 2014, upon the maturity of the Company’s 2014 Fixed-Rate Notes (2.90%), the Company repaid an aggregate principal amount of $500 million.

[0000858877-15-000013:notes:104]
(b)

[0000858877-15-000013:notes:105]
Long-Term Debt

[0000858877-15-000013:notes:106]
The following table summarizes the Company’s long-term debt (in millions, except percentages):

[0000858877-15-000013:notes:107]
|  |  |  | January 24, 2015 |  | July 26, 2014 |
|  | Maturity Date |  | Amount |  | Effective Rate |  | Amount |  | Effective Rate |
| Senior notes: |  |  |  |  |  |  |  |  |  |
| Floating-rate notes: |  |  |  |  |  |  |  |  |  |
| Three-month LIBOR plus 0.05% | September 3, 2015 |  | $ | 850 |  |  | 0.36% |  | $ | 850 |  |  | 0.35% |
| Three-month LIBOR plus 0.28% | March 3, 2017 |  | 1,000 |  |  | 0.57% |  | 1,000 |  |  | 0.56% |
| Three-month LIBOR plus 0.50% | March 1, 2019 |  | 500 |  |  | 0.79% |  | 500 |  |  | 0.78% |
| Fixed-rate notes: |  |  |  |  |  |  |  |  |  |
| 2.90% | November 17, 2014 |  | — |  |  | — |  | 500 |  |  | 3.11% |
| 5.50% | February 22, 2016 |  | 3,000 |  |  | 3.05% |  | 3,000 |  |  | 3.04% |
| 1.10% | March 3, 2017 |  | 2,400 |  |  | 0.57% |  | 2,400 |  |  | 0.56% |
| 3.15% | March 14, 2017 |  | 750 |  |  | 0.80% |  | 750 |  |  | 0.79% |
| 4.95% | February 15, 2019 |  | 2,000 |  |  | 4.69% |  | 2,000 |  |  | 4.69% |
| 2.125% | March 1, 2019 |  | 1,750 |  |  | 0.78% |  | 1,750 |  |  | 0.77% |
| 4.45% | January 15, 2020 |  | 2,500 |  |  | 2.99% |  | 2,500 |  |  | 2.98% |
| 2.90% | March 4, 2021 |  | 500 |  |  | 0.94% |  | 500 |  |  | 0.93% |
| 3.625% | March 4, 2024 |  | 1,000 |  |  | 1.06% |  | 1,000 |  |  | 1.05% |
| 5.90% | February 15, 2039 |  | 2,000 |  |  | 6.11% |  | 2,000 |  |  | 6.11% |
| 5.50% | January 15, 2040 |  | 2,000 |  |  | 5.67% |  | 2,000 |  |  | 5.67% |
| Other long-term debt |  |  | 2 |  |  | 2.08% |  | 4 |  |  | 2.39% |
| Total |  |  | 20,252 |  |  |  |  | 20,754 |  |  |  |
| Unaccreted discount |  |  | (61 | ) |  |  |  | (63 | ) |  |  |
| Hedge accounting fair value adjustments |  |  | 326 |  |  |  |  | 210 |  |  |  |
| Total |  |  | $ | 20,517 |  |  |  |  | $ | 20,901 |  |  |  |
| Reported as: |  |  |  |  |  |  |  |  |  |
| Current portion of long-term debt |  |  | $ | 850 |  |  |  |  | $ | 500 |  |  |  |
| Long-term debt |  |  | 19,667 |  |  |  |  | 20,401 |  |  |  |
| Total |  |  | $ | 20,517 |  |  |  |  | $ | 20,901 |  |  |  |

[0000858877-15-000013:notes:108]
To achieve its interest rate risk management objectives, the Company entered into interest rate swaps in prior periods with an aggregate notional amount of $10.4 billion designated as fair value hedges of certain of its fixed-rate senior notes. In effect, these swaps convert the fixed interest rates of the fixed-rate notes to floating interest rates based on the London InterBank Offered Rate (LIBOR). The gains and losses related to changes in the fair value of the interest rate swaps substantially offset changes in the fair value of the hedged portion of the underlying debt that are attributable to the changes in market interest rates. For additional information, see Note 11.

[0000858877-15-000013:notes:109]
The effective rates for the fixed-rate debt include the interest on the notes, the accretion of the discount, and, if applicable, adjustments related to hedging. Interest is payable semiannually on each class of the senior fixed-rate notes and payable quarterly on the floating-rate notes. Each of the senior fixed-rate notes is redeemable by the Company at any time, subject to a make-whole premium.

[0000858877-15-000013:notes:110]
The senior notes rank at par with the commercial paper notes that may be issued in the future pursuant to the Company’s short-term debt financing program, as discussed above under “(a) Short-Term Debt.” As of January 24, 2015, the Company was in compliance with all debt covenants.

[0000858877-15-000013:notes:111]
As of January 24, 2015, future principal payments for long-term debt, including the current portion, are summarized as follows (in millions):

[0000858877-15-000013:notes:112]
| Fiscal Year | Amount |
| 2015 (remaining six months) | $ | — |  |
| 2016 | 3,851 |  |
| 2017 | 4,151 |  |
| 2018 | — |  |
| 2019 | 4,250 |  |
| Thereafter | 8,000 |  |
| Total | $ | 20,252 |  |

[0000858877-15-000013:notes:113]
| (c) | Credit Facility |

[0000858877-15-000013:notes:114]
On February 17, 2012, the Company entered into a credit agreement with certain institutional lenders that provides for a $3.0 billion unsecured revolving credit facility that is scheduled to expire on February 17, 2017. Any advances under the credit agreement will accrue interest at rates that are equal to, based on certain conditions, either (i) the higher of the Federal Funds rate plus 0.50%, Bank of America’s “prime rate” as announced from time to time, or one-month LIBOR plus 1.00% or (ii) LIBOR plus a margin that is based on the Company’s senior debt credit ratings as published by Standard & Poor’s Financial Services, LLC and Moody’s Investors Service, Inc. The credit agreement requires the Company to comply with certain covenants, including that it maintain an interest coverage ratio as defined in the agreement. As of January 24, 2015, the Company was in compliance with the required interest coverage ratio and the other covenants, and the Company had not borrowed any funds under the credit facility.

[0000858877-15-000013:notes:115]
The Company may also, upon the agreement of either the existing lenders or additional lenders not currently parties to the agreement, increase the commitments under the credit facility by up to an additional $2.0 billion and/or extend the expiration date of the credit facility by up to two additional years, or up to February 17, 2019.


## us-gaap:DeferredRevenueByArrangementDisclosureTextBlock

[0000858877-15-000013:notes:116]
| Deferred revenue: |  |  |  |  |
| Service |  | $ | 9,020 |  |  | $ | 9,640 |  |
| Product: |  |  |  |  |
| Unrecognized revenue on product shipments and other deferred revenue |  | 4,276 |  |  | 3,924 |  |
| Cash receipts related to unrecognized revenue from two-tier distributors |  | 725 |  |  | 578 |  |
| Total product deferred revenue |  | 5,001 |  |  | 4,502 |  |
| Total |  | $ | 14,021 |  |  | $ | 14,142 |  |
| Reported as: |  |  |  |  |
| Current |  | $ | 9,369 |  |  | $ | 9,478 |  |
| Noncurrent |  | 4,652 |  |  | 4,664 |  |
| Total |  | $ | 14,021 |  |  | $ | 14,142 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000858877-15-000013:notes:117]
[same as prior period, unchanged from 0000858877-14-000043:notes:80]

[0000858877-15-000013:notes:118]
[same as prior period, unchanged from 0000858877-14-000043:notes:81]

[0000858877-15-000013:notes:119]
[same as prior period, unchanged from 0000858877-14-000043:notes:82]

[0000858877-15-000013:notes:120]
[same as prior period, unchanged from 0000858877-14-000043:notes:83]

[0000858877-15-000013:notes:121]
|  | DERIVATIVE ASSETS |  | DERIVATIVE LIABILITIES |
|  | Balance Sheet Line Item |  | January 24, 2015 |  | July 26, 2014 |  | Balance Sheet Line Item |  | January 24, 2015 |  | July 26, 2014 |
| Derivatives designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | $ | 4 |  |  | $ | 7 |  |  | Other current liabilities |  | $ | 88 |  |  | $ | 6 |  |
| Interest rate derivatives | Other assets |  | 279 |  |  | 148 |  |  | Other long-term liabilities |  | — |  |  | 3 |  |
| Equity derivatives | Other current assets |  | — |  |  | — |  |  | Other current liabilities |  | 68 |  |  | 56 |  |
| Total |  |  | 283 |  |  | 155 |  |  |  |  | 156 |  |  | 65 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives | Other current assets |  | 5 |  |  | 3 |  |  | Other current liabilities |  | 6 |  |  | 2 |  |
| Equity derivatives | Other assets |  | — |  |  | 2 |  |  | Other long-term liabilities |  | — |  |  | — |  |
| Total |  |  | 5 |  |  | 5 |  |  |  |  | 6 |  |  | 2 |  |
| Total |  |  | $ | 288 |  |  | $ | 160 |  |  |  |  | $ | 162 |  |  | $ | 67 |  |

[0000858877-15-000013:notes:122]
[same as prior period, unchanged from 0000858877-14-000043:notes:85]

[0000858877-15-000013:notes:123]
| GAINS (LOSSES) RECOGNIZEDIN OCI ON DERIVATIVES FOR THE THREE MONTHS ENDED (EFFECTIVE PORTION) |  | GAINS (LOSSES) RECLASSIFIED FROMAOCI INTO INCOME FOR THETHREE MONTHS ENDED (EFFECTIVE PORTION) |
|  |  | January 24, 2015 |  | January 25, 2014 |  | Line Item in Statements of Operations |  | January 24, 2015 |  | January 25, 2014 |
| Derivatives designated as cash flow hedging instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | (75 | ) |  | $ | (4 | ) |  | Operating expenses |  | $ | (21 | ) |  | $ | 16 |  |
|  |  |  |  |  |  | Cost of sales—service |  | (5 | ) |  | 3 |  |
| Total |  | $ | (75 | ) |  | $ | (4 | ) |  |  |  | $ | (26 | ) |  | $ | 19 |  |
| Derivatives designated as net investment hedging instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | 24 |  |  | $ | 16 |  |  | Other income (loss), net |  | $ | — |  |  | $ | — |  |

[0000858877-15-000013:notes:124]
| GAINS (LOSSES) RECOGNIZEDIN OCI ON DERIVATIVES FOR THE SIX MONTHS ENDED (EFFECTIVE PORTION) |  | GAINS (LOSSES) RECLASSIFIED FROMAOCI INTO INCOME FOR THESIX MONTHS ENDED (EFFECTIVE PORTION) |
|  |  | January 24, 2015 |  | January 25, 2014 |  | Line Item in Statements of Operations |  | January 24, 2015 |  | January 25, 2014 |
| Derivatives designated as cash flow hedging instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | (131 | ) |  | $ | 34 |  |  | Operating expenses |  | $ | (24 | ) |  | $ | 23 |  |
|  |  |  |  |  |  | Cost of sales—service |  | (6 | ) |  | 5 |  |
| Total |  | $ | (131 | ) |  | $ | 34 |  |  |  |  | $ | (30 | ) |  | $ | 28 |  |
| Derivatives designated as net investment hedging instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign currency derivatives |  | $ | 44 |  |  | $ | (3 | ) |  | Other income (loss), net |  | $ | — |  |  | $ | — |  |

[0000858877-15-000013:notes:125]
As of January 24, 2015, the Company estimates that approximately $102 million of net derivative losses related to its cash flow hedges included in accumulated other comprehensive income (AOCI) will be reclassified into earnings within the next 12 months when the underlying hedged item impacts earnings.

[0000858877-15-000013:notes:126]
[same as prior period, unchanged from 0000858877-14-000043:notes:90]

[0000858877-15-000013:notes:127]
|  |  |  |  | GAINS (LOSSES) FOR THETHREE MONTHS ENDED |  | GAINS (LOSSES) FOR THESIX MONTHS ENDED |
| Derivatives Not Designated as Hedging Instruments |  | Line Item in Statements of Operations |  | January 24, 2015 |  | January 25, 2014 |  | January 24, 2015 |  | January 25, 2014 |
| Foreign currency derivatives |  | Other income (loss), net |  | $ | (51 | ) |  | $ | (63 | ) |  | $ | (109 | ) |  | $ | (20 | ) |
| Total return swaps—deferred compensation |  | Operating expenses |  | 13 |  |  | 12 |  |  | — |  |  | 29 |  |
| Equity derivatives |  | Other income (loss), net |  | 8 |  |  | 13 |  |  | 4 |  |  | 24 |  |
| Total |  |  |  | $ | (30 | ) |  | $ | (38 | ) |  | $ | (105 | ) |  | $ | 33 |  |

[0000858877-15-000013:notes:128]
[same as prior period, unchanged from 0000858877-14-000043:notes:92]

[0000858877-15-000013:notes:129]
|  | January 24, 2015 |  | July 26, 2014 |
| Derivatives designated as hedging instruments: |  |  |  |
| Foreign currency derivatives—cash flow hedges | $ | 1,641 |  |  | $ | 1,618 |  |
| Interest rate derivatives | 10,400 |  |  | 10,400 |  |
| Net investment hedging instruments | 216 |  |  | 345 |  |
| Equity derivatives | 238 |  |  | 238 |  |
| Derivatives not designated as hedging instruments: |  |  |  |
| Foreign currency derivatives | 1,969 |  |  | 2,528 |  |
| Total return swaps—deferred compensation | 449 |  |  | 428 |  |
| Total | $ | 14,913 |  |  | $ | 15,557 |  |

[0000858877-15-000013:notes:130]
[same as prior period, unchanged from 0000858877-14-000043:notes:94]

[0000858877-15-000013:notes:131]
[same as prior period, unchanged from 0000858877-14-000043:notes:95]

[0000858877-15-000013:notes:132]
|  | OFFSETTING OF DERIVATIVE ASSETS |
|  | Gross Amounts Offset in Consolidated Balance Sheets |  | Gross Amounts Not Offset in the Consolidated Balance Sheets, but with Legal Rights to Offset |
| January 24, 2015 | Gross Amount of Recognized Assets |  | Gross Amounts Offset in Consolidated Balance Sheets |  | Net Amount Presented on Consolidated Balance Sheets |  | Gross Derivative Amounts with Legal Rights to Offset |  | Cash Collateral Received |  | Net Amount |
| Derivatives | $ | 288 |  |  | $ | — |  |  | $ | 288 |  |  | $ | (58 | ) |  | $ | (186 | ) |  | $ | 44 |  |

[0000858877-15-000013:notes:133]
|  | OFFSETTING OF DERIVATIVE LIABILITIES |
|  | Gross Amounts Offset in Consolidated Balance Sheets |  | Gross Amounts Not Offset in the Consolidated Balance Sheets, but with Legal Rights to Offset |
| January 24, 2015 | Gross Amount of Recognized Liabilities |  | Gross Amounts Offset in Consolidated Balance Sheets |  | Net Amount Presented on Consolidated Balance Sheets |  | Gross Derivative Amounts with Legal Rights to Offset |  | Cash Collateral Pledged |  | Net Amount |
| Derivatives | $ | 162 |  |  | $ | — |  |  | $ | 162 |  |  | $ | (58 | ) |  | $ | — |  |  | $ | 104 |  |

[0000858877-15-000013:notes:134]
[same as prior period, unchanged from 0000858877-14-000043:notes:98]

[0000858877-15-000013:notes:135]
[same as prior period, unchanged from 0000858877-14-000043:notes:99]

[0000858877-15-000013:notes:136]
[same as prior period, unchanged from 0000858877-14-000043:notes:100]

[0000858877-15-000013:notes:137]
[same as prior period, unchanged from 0000858877-14-000043:notes:101]

[0000858877-15-000013:notes:138]
[same as prior period, unchanged from 0000858877-14-000043:notes:102]

[0000858877-15-000013:notes:139]
[same as prior period, unchanged from 0000858877-14-000043:notes:103]

[0000858877-15-000013:notes:140]
[same as prior period, unchanged from 0000858877-14-000043:notes:104]

[0000858877-15-000013:notes:141]
[same as prior period, unchanged from 0000858877-14-000043:notes:105]

[0000858877-15-000013:notes:142]
Interest Rate Derivatives, Investments   The Company’s primary objective for holding fixed income securities is to achieve an appropriate investment return consistent with preserving principal and managing risk. To realize these objectives, the Company may utilize interest rate swaps or other derivatives designated as fair value or cash flow hedges. As of January 24, 2015 and July 26, 2014, the Company did not have any outstanding interest rate derivatives related to its fixed income securities.

[0000858877-15-000013:notes:143]
[same as prior period, unchanged from 0000858877-14-000043:notes:107]

[0000858877-15-000013:notes:144]
[same as prior period, unchanged from 0000858877-14-000043:notes:108]

[0000858877-15-000013:notes:145]
[same as prior period, unchanged from 0000858877-14-000043:notes:109]

[0000858877-15-000013:notes:146]
[same as prior period, unchanged from 0000858877-14-000043:notes:110]

[0000858877-15-000013:notes:147]
[same as prior period, unchanged from 0000858877-14-000043:notes:111]

[0000858877-15-000013:notes:148]
[same as prior period, unchanged from 0000858877-14-000043:notes:112]

[0000858877-15-000013:notes:149]
[same as prior period, unchanged from 0000858877-14-000043:notes:113]

[0000858877-15-000013:notes:150]
[same as prior period, unchanged from 0000858877-14-000043:notes:114]

[0000858877-15-000013:notes:151]
In addition, certain derivative instruments are executed under agreements that have provisions requiring the Company and the counterparty to maintain a specified credit rating from certain credit-rating agencies. Under such agreements, if the Company’s or the counterparty’s credit rating falls below a specified credit rating, either party has the right to request collateral on the derivatives’ net liability position. No such derivatives were in a net liability position as of January 24, 2015.  The fair market value of such derivatives was $3 million as of July 26, 2014.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000858877-15-000013:notes:152]
[same as prior period, unchanged from 0000858877-14-000043:notes:116]

[0000858877-15-000013:notes:153]
[same as prior period, unchanged from 0000858877-14-000043:notes:117]

[0000858877-15-000013:notes:154]
Stock Incentive Plan Program Description    As of January 24, 2015, the Company had four stock incentive plans: the 2005 Stock Incentive Plan (the “2005 Plan”); the 1996 Stock Incentive Plan (the “1996 Plan”); the Cisco Systems, Inc. SA Acquisition Long-Term Incentive Plan (the “SA Acquisition Plan”); and the Cisco Systems, Inc. WebEx Acquisition Long-Term Incentive Plan (the “WebEx Acquisition Plan”). In addition, the Company has, in connection with the acquisitions of various companies, assumed the share-based awards granted under stock incentive plans of the acquired companies or issued share-based awards in replacement thereof. Share-based awards are designed to reward employees for their long-term contributions to the Company and provide incentives for them to remain with the Company. The number and frequency of share-based awards are based on competitive practices, operating results of the Company, government regulations, and other factors. Since the inception of the stock incentive plans, the Company has granted share-based awards to a significant percentage of its employees, and the majority has been granted to employees below the vice president level. The Company’s primary stock incentive plans are summarized as follows:

[0000858877-15-000013:notes:155]
2005 Plan    As of January 24, 2015, the maximum number of shares issuable under the 2005 Plan over its term was 694 million shares, plus the number of any shares underlying awards outstanding on November 15, 2007 under the 1996 Plan, the SA Acquisition Plan, and the WebEx Acquisition Plan that are forfeited or are terminated for any other reason before being exercised or settled. If any awards granted under the 2005 Plan are forfeited or are terminated for any other reason before being exercised or settled, the unexercised or unsettled shares underlying the awards will again be available under the 2005 Plan.  Starting November 19, 2013, shares withheld by the Company from an award other than a stock option or stock appreciation right to satisfy withholding tax liabilities resulting from such award will again be available for issuance, based on the fungible share ratio in effect on the date of grant.

[0000858877-15-000013:notes:156]
[same as prior period, unchanged from 0000858877-14-000043:notes:120]

[0000858877-15-000013:notes:157]
The stock options will generally become exercisable for 20% or 25% of the option shares one year from the date of grant and then ratably over the following 48 months or 36 months, respectively. Time-based stock grants and time-based RSUs will generally vest with respect to 20% or 25% of the shares or share units covered by the grant on each of the first through fifth or fourth anniversaries of the date of the grant, respectively. The majority of the performance-based and market-based RSUs vest at the end of the three-year requisite service period or earlier if the award recipient meets certain retirement eligibility conditions.  Other  performance-based RSUs, that are based on the achievement of financial and/or non-financial operating goals, typically vest upon the achievement of milestones (and may require subsequent service periods), with overall vesting ranging from six months to three years. The Compensation and Management Development Committee of the Board of Directors has the discretion to use different vesting schedules. Stock appreciation rights may be awarded in combination with stock options or stock grants, and such awards shall provide that the stock appreciation rights will not be exercisable unless the related stock options or stock grants are forfeited. Stock grants may be awarded in combination with non-statutory stock options, and such awards may provide that the stock grants will be forfeited in the event that the related non-statutory stock options are exercised.

[0000858877-15-000013:notes:158]
[same as prior period, unchanged from 0000858877-14-000043:notes:122]

[0000858877-15-000013:notes:159]
[same as prior period, unchanged from 0000858877-14-000043:notes:123]

[0000858877-15-000013:notes:160]
[same as prior period, unchanged from 0000858877-14-000043:notes:124]

[0000858877-15-000013:notes:161]
The Company has an Employee Stock Purchase Plan, which includes its subplan named the International Employee Stock Purchase Plan (together, the “Purchase Plan”), under which 621.4 million shares of the Company’s common stock have been reserved for issuance as of January 24, 2015. Eligible employees are offered shares through a 24-month offering period, which consists of four consecutive 6-month purchase periods. Employees may purchase a limited number of shares of the Company’s stock at a discount of up to 15% of the lesser of the market value at the beginning of the offering period or the end of each 6-month purchase period. The Purchase Plan is scheduled to terminate on January 3, 2020. The Company issued 14 million shares under the Purchase Plan during each of the six months ended January 24, 2015 and January 25, 2014.  As of January 24, 2015, 161 million shares were available for issuance under the Purchase Plan.

[0000858877-15-000013:notes:162]
[same as prior period, unchanged from 0000858877-14-000043:notes:126]

[0000858877-15-000013:notes:163]
[same as prior period, unchanged from 0000858877-14-000043:notes:127]

[0000858877-15-000013:notes:164]
|  | Three Months Ended |  | Six Months Ended |
|  | January 24, 2015 |  | January 25, 2014 |  | January 24, 2015 |  | January 25, 2014 |
| Cost of sales—product | $ | 11 |  |  | $ | 12 |  |  | $ | 22 |  |  | $ | 22 |  |
| Cost of sales—service | 34 |  |  | 40 |  |  | 71 |  |  | 73 |  |
| Share-based compensation expense in cost of sales | 45 |  |  | 52 |  |  | 93 |  |  | 95 |  |
| Research and development | 105 |  |  | 108 |  |  | 224 |  |  | 200 |  |
| Sales and marketing | 114 |  |  | 141 |  |  | 261 |  |  | 264 |  |
| General and administrative | 42 |  |  | 47 |  |  | 101 |  |  | 101 |  |
| Restructuring and other charges | 2 |  |  | (1 | ) |  | (2 | ) |  | (4 | ) |
| Share-based compensation expense in operating expenses | 263 |  |  | 295 |  |  | 584 |  |  | 561 |  |
| Total share-based compensation expense | $ | 308 |  |  | $ | 347 |  |  | $ | 677 |  |  | $ | 656 |  |
| Income tax benefit for share-based compensation | $ | 85 |  |  | $ | 82 |  |  | $ | 179 |  |  | $ | 160 |  |

[0000858877-15-000013:notes:165]
As of January 24, 2015, the total compensation cost related to unvested share-based awards not yet recognized was $2.0 billion, which is expected to be recognized over approximately 2.3 years on a weighted-average basis.

[0000858877-15-000013:notes:166]
[same as prior period, unchanged from 0000858877-14-000043:notes:130]

[0000858877-15-000013:notes:167]
[same as prior period, unchanged from 0000858877-14-000043:notes:131]

[0000858877-15-000013:notes:168]
|  | Share-BasedAwards Availablefor Grant |
| BALANCE AT JULY 27, 2013 | 228 |  |
| Restricted stock, stock units, and other share-based awards granted | (98 | ) |
| Share-based awards canceled/forfeited/expired | 36 |  |
| Additional shares reserved | 135 |  |
| Shares withheld for taxes and not issued | 6 |  |
| Other | 3 |  |
| BALANCE AT JULY 26, 2014 | 310 |  |
| Restricted stock, stock units, and other share-based awards granted | (28 | ) |
| Share-based awards canceled/forfeited/expired | 27 |  |
| Shares withheld for taxes and not issued | 21 |  |
| Other | (2 | ) |
| BALANCE AT JANUARY 24, 2015 | 328 |  |

[0000858877-15-000013:notes:169]
[same as prior period, unchanged from 0000858877-14-000043:notes:133]

[0000858877-15-000013:notes:170]
[same as prior period, unchanged from 0000858877-14-000043:notes:134]

[0000858877-15-000013:notes:171]
[same as prior period, unchanged from 0000858877-14-000043:notes:135]

[0000858877-15-000013:notes:172]
|  | Restricted Stock/Stock Units |  | Weighted-AverageGrant Date FairValue per Share |  | Aggregated FairMarket Value |
| UNVESTED BALANCE AT JULY 27, 2013 | 143 |  |  | $ | 18.80 |  |  |  |
| Granted and assumed | 72 |  |  | 20.85 |  |  |  |
| Vested | (53 | ) |  | 19.55 |  |  | $ | 1,229 |  |
| Canceled/forfeited | (13 | ) |  | 18.61 |  |  |  |
| UNVESTED BALANCE AT JULY 26, 2014 | 149 |  |  | 19.54 |  |  |  |
| Granted and assumed | 18 |  |  | 23.47 |  |  |  |
| Vested | (41 | ) |  | 19.47 |  |  | $ | 1,053 |  |
| Canceled/forfeited | (11 | ) |  | 19.70 |  |  |  |
| UNVESTED BALANCE AT JANUARY 24, 2015 | 115 |  |  | $ | 20.18 |  |  |  |

[0000858877-15-000013:notes:173]
[same as prior period, unchanged from 0000858877-14-000043:notes:137]

[0000858877-15-000013:notes:174]
[same as prior period, unchanged from 0000858877-14-000043:notes:138]

[0000858877-15-000013:notes:175]
|  | STOCK OPTIONS OUTSTANDING |
|  | NumberOutstanding |  | Weighted-AverageExercise Price per Share |
| BALANCE AT JULY 27, 2013 | 276 |  |  | $ | 24.44 |  |
| Assumed from acquisitions | 6 |  |  | 3.60 |  |
| Exercised | (78 | ) |  | 18.30 |  |
| Canceled/forfeited/expired | (17 | ) |  | 27.53 |  |
| BALANCE AT JULY 26, 2014 | 187 |  |  | 26.03 |  |
| Assumed from acquisitions | 1 |  |  | 2.72 |  |
| Exercised | (45 | ) |  | 20.49 |  |
| Canceled/forfeited/expired | (10 | ) |  | 29.48 |  |
| BALANCE AT JANUARY 24, 2015 | 133 |  |  | $ | 27.45 |  |

[0000858877-15-000013:notes:176]
The following table summarizes significant ranges of outstanding and exercisable stock options as of January 24, 2015 (in millions, except years and share prices):

[0000858877-15-000013:notes:177]
|  |  | STOCK OPTIONS OUTSTANDING |  | STOCK OPTIONS EXERCISABLE |
| Range of Exercise Prices |  | NumberOutstanding |  | Weighted-AverageRemainingContractualLife(in Years) |  | Weighted-AverageExercisePrice perShare |  | AggregateIntrinsicValue |  | NumberExercisable |  | Weighted-AverageExercisePrice perShare |  | AggregateIntrinsicValue |
| $ 0.01 – 15.00 |  | 5 |  |  | 5.4 |  | $ | 4.17 |  |  | $ | 135 |  |  | 3 |  |  | $ | 5.66 |  |  | $ | 69 |  |
| 15.01 – 18.00 |  | 1 |  |  | 2.0 |  | 16.91 |  |  | 3 |  |  | 1 |  |  | 16.91 |  |  | 3 |  |
| 18.01 – 20.00 |  | 1 |  |  | 0.3 |  | 19.69 |  |  | 9 |  |  | 1 |  |  | 19.69 |  |  | 9 |  |
| 20.01 – 25.00 |  | 37 |  |  | 0.8 |  | 22.90 |  |  | 198 |  |  | 37 |  |  | 22.90 |  |  | 198 |  |
| 25.01 – 30.00 |  | 20 |  |  | 1.5 |  | 26.72 |  |  | 32 |  |  | 20 |  |  | 26.72 |  |  | 32 |  |
| 30.01 – 35.00 |  | 69 |  |  | 1.5 |  | 32.16 |  |  | — |  |  | 69 |  |  | 32.16 |  |  | — |  |
| Total |  | 133 |  |  | 1.5 |  | $ | 27.45 |  |  | $ | 377 |  |  | 131 |  |  | $ | 27.94 |  |  | $ | 311 |  |

[0000858877-15-000013:notes:178]
The aggregate intrinsic value in the preceding table represents the total pretax intrinsic value, based on the Company’s closing stock price of $28.21 as of January 23, 2015, that would have been received by the option holders had those option holders exercised their stock options as of that date. The total number of in-the-money stock options exercisable as of January 24, 2015 was 59 million. As of July 26, 2014, 183 million outstanding stock options were exercisable, and the weighted-average exercise price was $26.50.

[0000858877-15-000013:notes:179]
[same as prior period, unchanged from 0000858877-14-000043:notes:143]

[0000858877-15-000013:notes:180]
[same as prior period, unchanged from 0000858877-14-000043:notes:144]

[0000858877-15-000013:notes:181]
|  | RESTRICTED STOCK UNITS |  | PERFORMANCE RESTRICTED STOCK UNITS |
| Three Months Ended | January 24, 2015 |  | January 25, 2014 |  | January 24, 2015 |  | January 25, 2014 |
| Number of shares granted (in millions) | 1 |  |  | 37 |  |  | 1 |  |  | — |  |
| Grant date fair value per share | $ | 25.07 |  |  | $ | 19.90 |  |  | $ | 25.39 |  |  | N/A |  |
| Weighted-average assumptions/inputs: |  |  |  |  |  |  |  |
| Expected dividend yield | 2.8 | % |  | 3.2 | % |  | 2.8 | % |  | N/A |  |
| Range of risk-free interest rates | 0.0% – 1.6% |  |  | 0.1% – 1.4% |  |  | 0.0% – 1.6% |  |  | N/A |  |
| Range of expected volatilities for index | N/A |  |  | N/A |  |  | 14.4% – 63.7% |  |  | N/A |  |

[0000858877-15-000013:notes:182]
|  | RESTRICTED STOCK UNITS |  | PERFORMANCE RESTRICTED STOCK UNITS |
| Six Months Ended | January 24, 2015 |  | January 25, 2014 |  | January 24, 2015 |  | January 25, 2014 |
| Number of shares granted (in millions) | 11 |  |  | 47 |  |  | 7 |  |  | 4 |  |
| Grant date fair value per share | $ | 23.34 |  |  | $ | 20.57 |  |  | $ | 23.70 |  |  | $ | 22.70 |  |
| Weighted-average assumptions/inputs: |  |  |  |  |  |  |  |
| Expected dividend yield | 3.0 | % |  | 3.1 | % |  | 3.0 | % |  | 2.3 | % |
| Range of risk-free interest rates | 0.0% – 1.8% |  |  | 0.0% – 1.4% |  |  | 0.0% – 1.8% |  |  | 0.0% – 1.4% |  |
| Range of expected volatilities for index | N/A |  |  | N/A |  |  | 14.4% – 70.0% |  |  | 17.4% – 70.5% |  |

[0000858877-15-000013:notes:183]
The PRSUs granted during the first two quarters of fiscal 2015 and the first quarter of fiscal 2014 are contingent on the achievement of the Company’s financial performance metrics, its comparative market-based returns, or the achievement of financial and non-financial operating goals.  For the awards based on financial performance metrics or comparative market-based returns, generally 50% of the PRSUs are earned based on the average of annual operating cash flow and earnings per share goals established at the beginning of each fiscal year over a three-year performance period. Generally, the remaining 50% of the PRSUs are earned based on the Company’s TSR measured against the benchmark TSR of a peer group over the same period. Each PRSU recipient could vest in 0% to 150% of the target shares granted contingent on the achievement of the Company's financial performance metrics or its comparative market-based returns and 0% to 100% of the target shares granted contingent on the achievement of non-financial operating goals.


## us-gaap:EarningsPerShareTextBlock

[0000858877-15-000013:notes:184]
[same as prior period, unchanged from 0000858877-14-000043:notes:147]

[0000858877-15-000013:notes:185]
[same as prior period, unchanged from 0000858877-14-000043:notes:148]

[0000858877-15-000013:notes:186]
|  | Three Months Ended |  | Six Months Ended |
|  | January 24, 2015 |  | January 25, 2014 |  | January 24, 2015 |  | January 25, 2014 |
| Net income | $ | 2,397 |  |  | $ | 1,429 |  |  | $ | 4,225 |  |  | $ | 3,425 |  |
| Weighted-average shares—basic | 5,117 |  |  | 5,294 |  |  | 5,115 |  |  | 5,336 |  |
| Effect of dilutive potential common shares | 43 |  |  | 33 |  |  | 44 |  |  | 47 |  |
| Weighted-average shares—diluted | 5,160 |  |  | 5,327 |  |  | 5,159 |  |  | 5,383 |  |
| Net income per share—basic | $ | 0.47 |  |  | $ | 0.27 |  |  | $ | 0.83 |  |  | $ | 0.64 |  |
| Net income per share—diluted | $ | 0.46 |  |  | $ | 0.27 |  |  | $ | 0.82 |  |  | $ | 0.64 |  |
| Antidilutive employee share-based awards, excluded | 83 |  |  | 278 |  |  | 156 |  |  | 252 |  |

[0000858877-15-000013:notes:187]
[same as prior period, unchanged from 0000858877-14-000043:notes:150]


## us-gaap:EquityMethodInvestmentsTextBlock

[0000858877-15-000013:notes:188]
For such investments that were accounted for under the equity and cost method as of January 24, 2015 and July 26, 2014, the amounts are summarized in the following table (in millions):

[0000858877-15-000013:notes:189]
|  | January 24, 2015 |  | July 26, 2014 |
| Equity method investments | $ | 541 |  |  | $ | 630 |  |
| Cost method investments | 316 |  |  | 269 |  |
| Total | $ | 857 |  |  | $ | 899 |  |


## us-gaap:FairValueDisclosuresTextBlock

[0000858877-15-000013:notes:190]
| 9. | Fair Value |

[0000858877-15-000013:notes:191]
[same as prior period, unchanged from 0000858877-14-000043:notes:153]

[0000858877-15-000013:notes:192]
[same as prior period, unchanged from 0000858877-14-000043:notes:154]

[0000858877-15-000013:notes:193]
[same as prior period, unchanged from 0000858877-14-000043:notes:155]

[0000858877-15-000013:notes:194]
[same as prior period, unchanged from 0000858877-14-000043:notes:156]

[0000858877-15-000013:notes:195]
[same as prior period, unchanged from 0000858877-14-000043:notes:157]

[0000858877-15-000013:notes:196]
[same as prior period, unchanged from 0000858877-14-000043:notes:158]

[0000858877-15-000013:notes:197]
[same as prior period, unchanged from 0000858877-14-000043:notes:159]

[0000858877-15-000013:notes:198]
Assets and liabilities measured at fair value on a recurring basis as of January 24, 2015 and July 26, 2014 were as follows (in millions):

[0000858877-15-000013:notes:199]
|  | JANUARY 24, 2015FAIR VALUE MEASUREMENTS |  | JULY 26, 2014FAIR VALUE MEASUREMENTS |
|  | Level 1 |  | Level 2 |  | Level 3 |  | TotalBalance |  | Level 1 |  | Level 2 |  | Level 3 |  | TotalBalance |
| Assets: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash equivalents: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | $ | 2,977 |  |  | $ | — |  |  | $ | — |  |  | $ | 2,977 |  |  | $ | 4,935 |  |  | $ | — |  |  | $ | — |  |  | $ | 4,935 |  |
| Corporate debt securities | — |  |  | 67 |  |  | — |  |  | 67 |  |  | — |  |  | — |  |  | — |  |  | — |  |
| Available-for-sale investments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | — |  |  | 30,354 |  |  | — |  |  | 30,354 |  |  | — |  |  | 31,734 |  |  | — |  |  | 31,734 |  |
| U.S. government agency securities | — |  |  | 2,326 |  |  | — |  |  | 2,326 |  |  | — |  |  | 1,063 |  |  | — |  |  | 1,063 |  |
| Non-U.S. government and agency securities | — |  |  | 1,109 |  |  | — |  |  | 1,109 |  |  | — |  |  | 861 |  |  | — |  |  | 861 |  |
| Corporate debt securities | — |  |  | 11,213 |  |  | — |  |  | 11,213 |  |  | — |  |  | 9,159 |  |  | — |  |  | 9,159 |  |
| U.S. agency mortgage-backed securities | — |  |  | 1,375 |  |  | — |  |  | 1,375 |  |  | — |  |  | 579 |  |  | — |  |  | 579 |  |
| Publicly traded equity securities | 1,848 |  |  | — |  |  | — |  |  | 1,848 |  |  | 1,952 |  |  | — |  |  | — |  |  | 1,952 |  |
| Derivative assets | — |  |  | 288 |  |  | — |  |  | 288 |  |  | — |  |  | 158 |  |  | 2 |  |  | 160 |  |
| Total | $ | 4,825 |  |  | $ | 46,732 |  |  | $ | — |  |  | $ | 51,557 |  |  | $ | 6,887 |  |  | $ | 43,554 |  |  | $ | 2 |  |  | $ | 50,443 |  |
| Liabilities: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Derivative liabilities | $ | — |  |  | $ | 162 |  |  | $ | — |  |  | $ | 162 |  |  | $ | — |  |  | $ | 67 |  |  | $ | — |  |  | $ | 67 |  |
| Total | $ | — |  |  | $ | 162 |  |  | $ | — |  |  | $ | 162 |  |  | $ | — |  |  | $ | 67 |  |  | $ | — |  |  | $ | 67 |  |

[0000858877-15-000013:notes:200]
[same as prior period, unchanged from 0000858877-14-000043:notes:162]

[0000858877-15-000013:notes:201]
[same as prior period, unchanged from 0000858877-14-000043:notes:163]

[0000858877-15-000013:notes:202]
[same as prior period, unchanged from 0000858877-14-000043:notes:164]

[0000858877-15-000013:notes:203]
The Company recognized $2 million and $3 million of losses related to the impairment of privately held investments for the three and six months ended January 24, 2015, respectively, and $9 million and $10 million for the three and six months ended January 25, 2014, respectively. The Company recognized $56 million of losses related to the impairment of purchased intangible assets for the three and six months ended January 24, 2015.  There were no impairment charges of purchased intangible assets for the corresponding periods in fiscal 2014.  These assets were measured at fair value due to events or circumstances the Company identified as having significant impact on their fair value during the respective periods.  To arrive at the valuation of these assets, the Company considers any significant changes in the financial metrics and economic variables and also uses third-party valuation reports to assist in the valuation as necessary.

[0000858877-15-000013:notes:204]
[same as prior period, unchanged from 0000858877-14-000043:notes:166]

[0000858877-15-000013:notes:205]
The fair value for purchased intangibles for which the carrying amount was not deemed to be recoverable was determined using the future discounted cash flows that the assets are expected to generate.  The difference between the estimated fair value and the carrying value of the assets was recorded as an impairment charge, which was included in product cost of sales and operating expenses as applicable.  See Note 4.

[0000858877-15-000013:notes:206]
[same as prior period, unchanged from 0000858877-14-000043:notes:167]

[0000858877-15-000013:notes:207]
The carrying value of the Company’s investments in privately held companies that were accounted for under the cost method was $316 million and $269 million as of January 24, 2015 and July 26, 2014, respectively. It was not practicable to estimate the fair value of this portfolio.

[0000858877-15-000013:notes:208]
The fair value of the Company’s short-term loan receivables and financed service contracts approximates their carrying value due to their short duration.  The aggregate carrying value of the Company’s long-term loan receivables and financed service contracts and other as of January 24, 2015 and July 26, 2014 was $1.9 billion and $2.1 billion, respectively.  The estimated fair value of the Company’s long-term loan receivables and financed service contracts and other approximates their carrying value. The Company uses significant unobservable inputs in determining discounted cash flows to estimate the fair value of its long-term loan receivables and financed service contracts, and therefore they are categorized as Level 3.

[0000858877-15-000013:notes:209]
As of January 24, 2015, the estimated fair value of the short-term debt approximates its carrying value due to the short maturities.  As of January 24, 2015, the fair value of the Company’s senior notes and other long-term debt was $22.3 billion with a carrying amount of $20.5 billion.  This compares to a fair value of $22.4 billion and a carrying amount of $20.9 billion as of July 26, 2014.  The fair value of the senior notes and other long-term debt was determined based on observable market prices in a less active market and was categorized as Level 2 in the fair value hierarchy.


## us-gaap:FinancingReceivableCreditQualityIndicatorsTableTextBlock

[0000858877-15-000013:notes:210]
Gross receivables less unearned income categorized by the Company’s internal credit risk rating as of January 24, 2015 and July 26, 2014 are summarized as follows (in millions):

[0000858877-15-000013:notes:211]
|  | INTERNAL CREDIT RISK RATING |
| January 24, 2015 | 1 to 4 |  | 5 to 6 |  | 7 and Higher |  | Total |
| Lease receivables | $ | 1,632 |  |  | $ | 1,386 |  |  | $ | 145 |  |  | $ | 3,163 |  |
| Loan receivables | 717 |  |  | 803 |  |  | 154 |  |  | 1,674 |  |
| Financed service contracts and other | 1,647 |  |  | 1,342 |  |  | 80 |  |  | 3,069 |  |
| Total | $ | 3,996 |  |  | $ | 3,531 |  |  | $ | 379 |  |  | $ | 7,906 |  |

[0000858877-15-000013:notes:212]
[same as prior period, unchanged from 0000858877-14-000043:notes:173]


## us-gaap:FinancingReceivablesTextBlock

[0000858877-15-000013:notes:213]
[same as prior period, unchanged from 0000858877-14-000043:notes:174]

[0000858877-15-000013:notes:214]
[same as prior period, unchanged from 0000858877-14-000043:notes:175]

[0000858877-15-000013:notes:215]
[same as prior period, unchanged from 0000858877-14-000043:notes:176]

[0000858877-15-000013:notes:216]
[same as prior period, unchanged from 0000858877-14-000043:notes:177]

[0000858877-15-000013:notes:217]
| January 24, 2015 | LeaseReceivables |  | LoanReceivables |  | FinancedServiceContracts and Other |  | Total |
| Gross | $ | 3,369 |  |  | $ | 1,674 |  |  | $ | 3,069 |  |  | $ | 8,112 |  |
| Residual value | 228 |  |  | — |  |  | — |  |  | 228 |  |
| Unearned income | (206 | ) |  | — |  |  | — |  |  | (206 | ) |
| Allowance for credit loss | (250 | ) |  | (85 | ) |  | (40 | ) |  | (375 | ) |
| Total, net | $ | 3,141 |  |  | $ | 1,589 |  |  | $ | 3,029 |  |  | $ | 7,759 |  |
| Reported as: |  |  |  |  |  |  |  |
| Current | $ | 1,462 |  |  | $ | 782 |  |  | $ | 1,966 |  |  | $ | 4,210 |  |
| Noncurrent | 1,679 |  |  | 807 |  |  | 1,063 |  |  | 3,549 |  |
| Total, net | $ | 3,141 |  |  | $ | 1,589 |  |  | $ | 3,029 |  |  | $ | 7,759 |  |

[0000858877-15-000013:notes:218]
[same as prior period, unchanged from 0000858877-14-000043:notes:179]

[0000858877-15-000013:notes:219]
As of January 24, 2015 and July 26, 2014, the deferred service revenue related to "Financed Service Contracts and Other" was $1,530 million and $1,843 million, respectively.

[0000858877-15-000013:notes:220]
Future minimum lease payments at January 24, 2015 are summarized as follows (in millions):

[0000858877-15-000013:notes:221]
| Fiscal Year | Amount |
| 2015 (remaining six months) | $ | 883 |  |
| 2016 | 1,281 |  |
| 2017 | 753 |  |
| 2018 | 327 |  |
| 2019 | 115 |  |
| Thereafter | 10 |  |
| Total | $ | 3,369 |  |

[0000858877-15-000013:notes:222]
[same as prior period, unchanged from 0000858877-14-000043:notes:183]

[0000858877-15-000013:notes:223]
[same as prior period, unchanged from 0000858877-14-000043:notes:184]

[0000858877-15-000013:notes:224]
[same as prior period, unchanged from 0000858877-14-000043:notes:185]

[0000858877-15-000013:notes:225]
[same as prior period, unchanged from 0000858877-14-000043:notes:186]

[0000858877-15-000013:notes:226]
In circumstances when collectibility is not deemed reasonably assured, the associated revenue is deferred in accordance with the Company’s revenue recognition policies, and the related allowance for credit loss, if any, is included in deferred revenue. The Company also records deferred revenue associated with financing receivables when there are remaining performance obligations, as it does for financed service contracts. Total allowances for credit loss and deferred revenue as of January 24, 2015 and July 26, 2014 were $1,928 million and $2,220 million, respectively, and they were associated with total financing receivables before allowance for credit loss of $8,134 million and $8,420 million as of their respective period ends.

[0000858877-15-000013:notes:227]
The following tables present the aging analysis of gross receivables less unearned income as of January 24, 2015 and July 26, 2014 (in millions):

[0000858877-15-000013:notes:228]
|  | DAYS PAST DUE (INCLUDES BILLED AND UNBILLED) |  |  |  |  |  |  |  |  |
| January 24, 2015 | 31-60 |  | 61-90 |  | 91+ |  | TotalPast Due |  | Current |  | Total |  | NonaccrualFinancingReceivables |  | ImpairedFinancingReceivables |
| Lease receivables | $ | 171 |  |  | $ | 63 |  |  | $ | 224 |  |  | $ | 458 |  |  | $ | 2,705 |  |  | $ | 3,163 |  |  | $ | 53 |  |  | $ | 48 |  |
| Loan receivables | 30 |  |  | 42 |  |  | 177 |  |  | 249 |  |  | 1,425 |  |  | 1,674 |  |  | 33 |  |  | 33 |  |
| Financed service contracts and other | 144 |  |  | 135 |  |  | 385 |  |  | 664 |  |  | 2,405 |  |  | 3,069 |  |  | 30 |  |  | 8 |  |
| Total | $ | 345 |  |  | $ | 240 |  |  | $ | 786 |  |  | $ | 1,371 |  |  | $ | 6,535 |  |  | $ | 7,906 |  |  | $ | 116 |  |  | $ | 89 |  |

[0000858877-15-000013:notes:229]
|  | DAYS PAST DUE (INCLUDES BILLED AND UNBILLED) |  |  |  |  |  |  |  |  |
| July 26, 2014 | 31-60 |  | 61-90 |  | 91+ |  | TotalPast Due |  | Current |  | Total |  | NonaccrualFinancingReceivables |  | ImpairedFinancingReceivables |
| Lease receivables | $ | 63 |  |  | $ | 48 |  |  | $ | 203 |  |  | $ | 314 |  |  | $ | 2,980 |  |  | $ | 3,294 |  |  | $ | 48 |  |  | $ | 41 |  |
| Loan receivables | 7 |  |  | 21 |  |  | 28 |  |  | 56 |  |  | 1,627 |  |  | 1,683 |  |  | 19 |  |  | 19 |  |
| Financed service contracts and other | 268 |  |  | 238 |  |  | 221 |  |  | 727 |  |  | 2,483 |  |  | 3,210 |  |  | 12 |  |  | 9 |  |
| Total | $ | 338 |  |  | $ | 307 |  |  | $ | 452 |  |  | $ | 1,097 |  |  | $ | 7,090 |  |  | $ | 8,187 |  |  | $ | 79 |  |  | $ | 69 |  |

[0000858877-15-000013:notes:230]
Past due financing receivables are those that are 31 days or more past due according to their contractual payment terms. The data in the preceding tables is presented by contract, and the aging classification of each contract is based on the oldest outstanding receivable, and therefore past due amounts also include unbilled and current receivables within the same contract. The balances of either unbilled or current financing receivables included in the category of 91 days plus past due for financing receivables were $542 million and $334 million as of January 24, 2015 and July 26, 2014, respectively.

[0000858877-15-000013:notes:231]
As of January 24, 2015, the Company had financing receivables of $217 million, net of unbilled or current receivables from the same contract, that were in the category of 91 days plus past due but remained on accrual status. Such balance was $78 million as of July 26, 2014. A financing receivable may be placed on nonaccrual status earlier if, in management’s opinion, a timely collection of the full principal and interest becomes uncertain.

[0000858877-15-000013:notes:232]
[same as prior period, unchanged from 0000858877-14-000043:notes:193]

[0000858877-15-000013:notes:233]
[same as prior period, unchanged from 0000858877-14-000043:notes:194]

[0000858877-15-000013:notes:234]
Typically, the Company also considers receivables with a risk rating of 8 or higher to be impaired and will include them in the individual assessment for allowance. These balances, as of January 24, 2015 and July 26, 2014, are presented under “(b) Credit Quality of Financing Receivables” above.

[0000858877-15-000013:notes:235]
[same as prior period, unchanged from 0000858877-14-000043:notes:196]

[0000858877-15-000013:notes:236]
[same as prior period, unchanged from 0000858877-14-000043:notes:197]

[0000858877-15-000013:notes:237]
[same as prior period, unchanged from 0000858877-14-000043:notes:198]

[0000858877-15-000013:notes:238]
|  | January 24, 2015 |  | July 26, 2014 |
| Operating lease assets | $ | 343 |  |  | $ | 362 |  |
| Accumulated depreciation | (195 | ) |  | (202 | ) |
| Operating lease assets, net | $ | 148 |  |  | $ | 160 |  |

[0000858877-15-000013:notes:239]
Minimum future rentals on noncancelable operating leases at January 24, 2015 were approximately $0.1 billion for the remaining six months of fiscal 2015, $0.2 billion for fiscal 2016, and less than $0.1 billion per year for each of fiscal 2017 through fiscal 2019.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0000858877-15-000013:notes:240]
[same as prior period, unchanged from 0000858877-14-000043:notes:201]

[0000858877-15-000013:notes:241]
[same as prior period, unchanged from 0000858877-14-000043:notes:202]

[0000858877-15-000013:notes:242]
The following table presents the goodwill allocated to the Company’s reportable segments as of and during the six months ended January 24, 2015 (in millions):

[0000858877-15-000013:notes:243]
|  | Balance at July 26, 2014 |  | Acquisitions |  | Other |  | Balance at January 24, 2015 |
| Americas | $ | 15,080 |  |  | $ | 89 |  |  | $ | (13 | ) |  | $ | 15,156 |  |
| EMEA | 5,715 |  |  | 63 |  |  | (7 | ) |  | 5,771 |  |
| APJC | 3,444 |  |  | 16 |  |  | (5 | ) |  | 3,455 |  |
| Total | $ | 24,239 |  |  | $ | 168 |  |  | $ | (25 | ) |  | $ | 24,382 |  |

[0000858877-15-000013:notes:244]
[same as prior period, unchanged from 0000858877-14-000043:notes:205]

[0000858877-15-000013:notes:245]
[same as prior period, unchanged from 0000858877-14-000043:notes:206]

[0000858877-15-000013:notes:246]
[same as prior period, unchanged from 0000858877-14-000043:notes:212]

[0000858877-15-000013:notes:247]
Amortization of purchased intangible assets for the three and six months ended January 24, 2015 included impairment charges of approximately $56 million. The impairment was primarily due to reductions in expected future cash flows related to certain of the Company's technology intangible assets and was recorded as amortization of purchased intangible assets. There were no impairment charges related to purchased intangible assets during the three and six months ended January 25, 2014.

[0000858877-15-000013:notes:248]
The estimated future amortization expense of purchased intangible assets with finite lives as of January 24, 2015 is as follows (in millions):

[0000858877-15-000013:notes:249]
| Fiscal Year | Amount |
| 2015 (remaining six months) | $ | 462 |  |
| 2016 | 734 |  |
| 2017 | 561 |  |
| 2018 | 420 |  |
| 2019 | 317 |  |
| Thereafter | 150 |  |
| Total | $ | 2,644 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000858877-15-000013:notes:250]
[same as prior period, unchanged from 0000858877-14-000043:notes:218]

[0000858877-15-000013:notes:251]
During the three months ended January 24, 2015, the Tax Increase Prevention Act of 2014 reinstated the U.S. federal R&D tax credit for calendar year 2014 R&D expenses.  As a result, the effective tax rate for the three and six months ended January 24, 2015 reflected tax benefits related to fiscal 2015 R&D expenses and a tax benefit of $91 million related to fiscal 2014 R&D expenses.

[0000858877-15-000013:notes:252]
As of January 24, 2015, the Company had $2.0 billion of unrecognized tax benefits, of which $1.8 billion, if recognized, would favorably impact the effective tax rate. The Company regularly engages in discussions and negotiations with tax authorities regarding tax matters in various jurisdictions. The Company believes it is reasonably possible that certain federal, foreign, and state tax matters may be concluded in the next 12 months. Specific positions that may be resolved include issues involving transfer pricing and various other matters. Accordingly, the Company estimates that it is reasonably possible that the unrecognized tax benefits at January 24, 2015 could be reduced by $300 million in the next 12 months.


## us-gaap:InventoryDisclosureTextBlock

[0000858877-15-000013:notes:253]
[same as prior period, unchanged from 0000858877-14-000043:notes:222]

[0000858877-15-000013:notes:254]
|  |  | January 24, 2015 |  | July 26, 2014 |
| Inventories: |  |  |  |  |
| Raw materials |  | $ | 265 |  |  | $ | 77 |  |
| Work in process |  | 2 |  |  | 5 |  |
| Finished goods: |  |  |  |  |
| Distributor inventory and deferred cost of sales |  | 733 |  |  | 595 |  |
| Manufactured finished goods |  | 577 |  |  | 606 |  |
| Total finished goods |  | 1,310 |  |  | 1,201 |  |
| Service-related spares |  | 274 |  |  | 273 |  |
| Demonstration systems |  | 39 |  |  | 35 |  |
| Total |  | $ | 1,890 |  |  | $ | 1,591 |  |


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0000858877-15-000013:notes:255]
The following table summarizes the maturities of the Company’s fixed income securities at January 24, 2015 (in millions):

[0000858877-15-000013:notes:256]
|  | Amortized Cost |  | Fair Value |
| Less than 1 year | $ | 15,355 |  |  | $ | 15,362 |  |
| Due in 1 to 2 years | 14,963 |  |  | 14,995 |  |
| Due in 2 to 5 years | 14,383 |  |  | 14,431 |  |
| Due after 5 years | 1,573 |  |  | 1,589 |  |
| Total | $ | 46,274 |  |  | $ | 46,377 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000858877-15-000013:notes:257]
| 8. | Investments |

[0000858877-15-000013:notes:258]
| (a) | Summary of Available-for-Sale Investments |

[0000858877-15-000013:notes:259]
The following tables summarize the Company’s available-for-sale investments (in millions):

[0000858877-15-000013:notes:260]
| January 24, 2015 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| Fixed income securities: |  |  |  |  |  |  |  |
| U.S. government securities | $ | 30,302 |  |  | $ | 53 |  |  | $ | (1 | ) |  | $ | 30,354 |  |
| U.S. government agency securities | 2,324 |  |  | 3 |  |  | (1 | ) |  | 2,326 |  |
| Non-U.S. government and agency securities | 1,108 |  |  | 1 |  |  | — |  |  | 1,109 |  |
| Corporate debt securities | 11,180 |  |  | 61 |  |  | (28 | ) |  | 11,213 |  |
| U.S. agency mortgage-backed securities | 1,360 |  |  | 15 |  |  | — |  |  | 1,375 |  |
| Total fixed income securities | 46,274 |  |  | 133 |  |  | (30 | ) |  | 46,377 |  |
| Publicly traded equity securities | 1,296 |  |  | 562 |  |  | (10 | ) |  | 1,848 |  |
| Total | $ | 47,570 |  |  | $ | 695 |  |  | $ | (40 | ) |  | $ | 48,225 |  |

[0000858877-15-000013:notes:261]
| July 26, 2014 | AmortizedCost |  | GrossUnrealizedGains |  | GrossUnrealizedLosses |  | FairValue |
| Fixed income securities: |  |  |  |  |  |  |  |
| U.S. government securities | $ | 31,717 |  |  | $ | 29 |  |  | $ | (12 | ) |  | $ | 31,734 |  |
| U.S. government agency securities | 1,062 |  |  | 1 |  |  | — |  |  | 1,063 |  |
| Non-U.S. government and agency securities | 860 |  |  | 2 |  |  | (1 | ) |  | 861 |  |
| Corporate debt securities | 9,092 |  |  | 74 |  |  | (7 | ) |  | 9,159 |  |
| U.S. agency mortgage-backed securities | 574 |  |  | 5 |  |  | — |  |  | 579 |  |
| Total fixed income securities | 43,305 |  |  | 111 |  |  | (20 | ) |  | 43,396 |  |
| Publicly traded equity securities | 1,314 |  |  | 648 |  |  | (10 | ) |  | 1,952 |  |
| Total | $ | 44,619 |  |  | $ | 759 |  |  | $ | (30 | ) |  | $ | 45,348 |  |

[0000858877-15-000013:notes:262]
Non-U.S. government and agency securities include agency and corporate debt securities that are guaranteed by non-U.S. governments.

[0000858877-15-000013:notes:263]
| (b) | Gains and Losses on Available-for-Sale Investments |

[0000858877-15-000013:notes:264]
The following table presents the gross realized gains and gross realized losses related to the Company’s available-for-sale investments (in millions):

[0000858877-15-000013:notes:265]
|  | Three Months Ended |  | Six Months Ended |
|  | January 24, 2015 |  | January 25, 2014 |  | January 24, 2015 |  | January 25, 2014 |
| Gross realized gains | $ | 92 |  |  | $ | 97 |  |  | $ | 113 |  |  | $ | 192 |  |
| Gross realized losses | (23 | ) |  | (15 | ) |  | (37 | ) |  | (27 | ) |
| Total | $ | 69 |  |  | $ | 82 |  |  | $ | 76 |  |  | $ | 165 |  |

[0000858877-15-000013:notes:266]
The following table presents the realized net gains (losses) related to the Company’s available-for-sale investments by security type (in millions):

[0000858877-15-000013:notes:267]
|  | Three Months Ended |  | Six Months Ended |
|  | January 24, 2015 |  | January 25, 2014 |  | January 24, 2015 |  | January 25, 2014 |
| Net gains (losses) on investments in publicly traded equity securities | $ | 60 |  |  | $ | 69 |  |  | $ | 56 |  |  | $ | 144 |  |
| Net gains on investments in fixed income securities | 9 |  |  | 13 |  |  | 20 |  |  | 21 |  |
| Total | $ | 69 |  |  | $ | 82 |  |  | $ | 76 |  |  | $ | 165 |  |

[0000858877-15-000013:notes:268]
There were no impairment charges on available-for-sale investments for the three and six months ended January 24, 2015.  For the three and six months ended January 25, 2014, the realized gains related to the Company's available-for-sale investments included impairment charges of $11 million for publicly traded equity securities, which were due to a decline in the fair value of those securities below their cost basis that were determined to be other than temporary.

[0000858877-15-000013:notes:269]
The following tables present the breakdown of the available-for-sale investments with gross unrealized losses and the duration that those losses had been unrealized at January 24, 2015 and July 26, 2014 (in millions):

[0000858877-15-000013:notes:270]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| January 24, 2015 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| Fixed income securities: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | $ | 4,558 |  |  | $ | (1 | ) |  | $ | — |  |  | $ | — |  |  | $ | 4,558 |  |  | $ | (1 | ) |
| U.S. government agency securities | 854 |  |  | (1 | ) |  | — |  |  | — |  |  | 854 |  |  | (1 | ) |
| Corporate debt securities | 3,952 |  |  | (25 | ) |  | 363 |  |  | (3 | ) |  | 4,315 |  |  | (28 | ) |
| Total fixed income securities | 9,364 |  |  | (27 | ) |  | 363 |  |  | (3 | ) |  | 9,727 |  |  | (30 | ) |
| Publicly traded equity securities | 119 |  |  | (10 | ) |  | 1 |  |  | — |  |  | 120 |  |  | (10 | ) |
| Total | $ | 9,483 |  |  | $ | (37 | ) |  | $ | 364 |  |  | $ | (3 | ) |  | $ | 9,847 |  |  | $ | (40 | ) |

[0000858877-15-000013:notes:271]
|  | UNREALIZED LOSSESLESS THAN 12 MONTHS |  | UNREALIZED LOSSES12 MONTHS OR GREATER |  | TOTAL |
| July 26, 2014 | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | GrossUnrealizedLosses |  | Fair Value |  | Gross Unrealized Losses |
| Fixed income securities: |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities | $ | 7,676 |  |  | $ | (12 | ) |  | $ | 45 |  |  | $ | — |  |  | $ | 7,721 |  |  | $ | (12 | ) |
| Non-U.S. government and agency securities | 361 |  |  | (1 | ) |  | 22 |  |  | — |  |  | 383 |  |  | (1 | ) |
| Corporate debt securities | 1,875 |  |  | (3 | ) |  | 491 |  |  | (4 | ) |  | 2,366 |  |  | (7 | ) |
| Total fixed income securities | 9,912 |  |  | (16 | ) |  | 558 |  |  | (4 | ) |  | 10,470 |  |  | (20 | ) |
| Publicly traded equity securities | 132 |  |  | (10 | ) |  | — |  |  | — |  |  | 132 |  |  | (10 | ) |
| Total | $ | 10,044 |  |  | $ | (26 | ) |  | $ | 558 |  |  | $ | (4 | ) |  | $ | 10,602 |  |  | $ | (30 | ) |

[0000858877-15-000013:notes:272]
As of January 24, 2015, for fixed income securities that were in unrealized loss positions, the Company has determined that (i) it does not have the intent to sell any of these investments and (ii) it is not more likely than not that it will be required to sell any of these investments before recovery of the entire amortized cost basis. In addition, as of January 24, 2015, the Company anticipates that it will recover the entire amortized cost basis of such fixed income securities and has determined that no other-than-temporary impairments associated with credit losses were required to be recognized during the six months ended January 24, 2015.

[0000858877-15-000013:notes:273]
The Company has evaluated its publicly traded equity securities as of January 24, 2015 and has determined that there was no indication of other-than-temporary impairments in the respective categories of unrealized losses. This determination was based on several factors, which include the length of time and extent to which fair value has been less than the cost basis, the financial condition and near-term prospects of the issuer, and the Company’s intent and ability to hold the publicly traded equity securities for a period of time sufficient to allow for any anticipated recovery in market value.

[0000858877-15-000013:notes:274]
| (c) | Maturities of Fixed Income Securities |

[0000858877-15-000013:notes:275]
Actual maturities may differ from the contractual maturities because borrowers may have the right to call or prepay certain obligations.  The remaining contractual principal maturities for mortgage-backed securities were allocated assuming no prepayments.

[0000858877-15-000013:notes:276]
| (d) | Securities Lending |

[0000858877-15-000013:notes:277]
The Company periodically engages in securities lending activities with certain of its available-for-sale investments. These transactions are accounted for as a secured lending of the securities, and the securities are typically loaned only on an overnight basis. The average daily balance of securities lending for the six months ended January 24, 2015 and January 25, 2014 was $0.6 billion and $0.9 billion, respectively. The Company requires collateral equal to at least 102% of the fair market value of the loaned security and that the collateral be in the form of cash or liquid, high-quality assets. The Company engages in these secured lending transactions only with highly creditworthy counterparties, and the associated portfolio custodian has agreed to indemnify the Company against collateral losses. The Company did not experience any losses in connection with the secured lending of securities during the periods presented. As of January 24, 2015 and July 26, 2014, the Company had no outstanding securities lending transactions.

[0000858877-15-000013:notes:278]
| (e) | Investments in Privately Held Companies |

[0000858877-15-000013:notes:279]
The carrying value of the Company’s investments in privately held companies was included in other assets. For such investments that were accounted for under the equity and cost method as of January 24, 2015 and July 26, 2014, the amounts are summarized in the following table (in millions):

[0000858877-15-000013:notes:280]
Variable Interest Entities

[0000858877-15-000013:notes:281]
VCE Joint Venture   VCE is a joint venture formed in fiscal 2010 between the Company and EMC Corporation (“EMC”), with investments from VMware, Inc. (“VMware”) and Intel Capital Corporation ("Intel"). In October 2014, the Company, EMC, VMware, and Intel agreed to restructure VCE, and this transaction was completed in the second quarter of fiscal 2015.  Prior to the restructuring, the Company’s cumulative gross investment in VCE was approximately $716 million inclusive of convertible notes and accrued interest on convertible notes.  The Company recorded cumulative losses from VCE under the equity method of $691 million since inception. The Company ceased accounting for the VCE investment under the equity method in October 2014 and recorded no losses during the three months ended January 24, 2015, compared with losses of $58 million recorded for the three months ended January 25, 2014, and losses of $47 million and $111 million were recorded for the six months ended January 24, 2015 and January 25, 2014, respectively.  Under the terms of the restructuring, VCE paid $152 million to the Company for a portion of the outstanding principal balance of the convertible notes held by it and accrued interest on such notes, and the remaining principal balance of other such notes, and the accrued interest thereon, was cancelled.  Pursuant to the restructuring, VCE also redeemed a portion of the Company’s equity interest in VCE, reducing the Company’s ownership interest in VCE from 35% prior to the restructuring to 10%.  In connection with this transaction, the Company has written this investment down to a book value of zero and has recognized a gain of $126 million for the three and six months ended January 24, 2015.

[0000858877-15-000013:notes:282]
Other Variable Interest Entities    In the ordinary course of business, the Company has investments in other privately held companies and provides financing to certain customers. These other privately held companies and customers may be considered to be variable interest entities. The Company evaluates on an ongoing basis its investments in these other privately held companies and its customer financings and has determined that as of January 24, 2015 there were no other variable interest entities required to be consolidated in the Company’s Consolidated Financial Statements.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0000858877-15-000013:notes:283]
[same as prior period, unchanged from 0000858877-14-000043:notes:254]

[0000858877-15-000013:notes:284]
[same as prior period, unchanged from 0000858877-14-000043:notes:255]

[0000858877-15-000013:notes:285]
The accompanying financial data as of January 24, 2015 and for the three and six months ended January 24, 2015 and January 25, 2014 has been prepared by the Company, without audit, pursuant to the rules and regulations of the U.S. Securities and Exchange Commission (SEC). Certain information and footnote disclosures normally included in financial statements prepared in accordance with generally accepted accounting principles in the United States (GAAP) have been condensed or omitted pursuant to such rules and regulations. The July 26, 2014 Consolidated Balance Sheet was derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States. However, the Company believes that the disclosures are adequate to make the information presented not misleading. These Consolidated Financial Statements should be read in conjunction with the Consolidated Financial Statements and the notes thereto included in the Company’s Annual Report on Form 10-K for the fiscal year ended July 26, 2014.

[0000858877-15-000013:notes:286]
[same as prior period, unchanged from 0000858877-14-000043:notes:257]

[0000858877-15-000013:notes:287]
In the opinion of management, all adjustments (which include normal recurring adjustments, except as disclosed herein) necessary to present fairly the consolidated balance sheet as of January 24, 2015; the results of operations and statements of comprehensive income for the three and six months ended January 24, 2015 and January 25, 2014; and the statements of cash flows and equity for the six months ended January 24, 2015 and January 25, 2014, as applicable, have been made. The results of operations for the three and six months ended January 24, 2015 are not necessarily indicative of the operating results for the full fiscal year or any future periods.

[0000858877-15-000013:notes:288]
Certain reclassifications have been made to the amounts in prior periods in order to conform to the current period’s presentation.  The Company has evaluated subsequent events through the date that the financial statements were issued.


## us-gaap:OtherAssetsDisclosureTextBlock

[0000858877-15-000013:notes:289]
| Other assets: |  |  |  |  |
| Deferred tax assets |  | $ | 1,448 |  |  | $ | 1,700 |  |
| Investments in privately held companies |  | 857 |  |  | 899 |  |
| Other |  | 837 |  |  | 732 |  |
| Total |  | $ | 3,142 |  |  | $ | 3,331 |  |


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0000858877-15-000013:notes:290]
| Property and equipment, net: |  |  |  |  |
| Land, buildings, and building and leasehold improvements |  | $ | 4,457 |  |  | $ | 4,468 |  |
| Computer equipment and related software |  | 1,417 |  |  | 1,425 |  |
| Production, engineering, and other equipment |  | 5,745 |  |  | 5,756 |  |
| Operating lease assets |  | 343 |  |  | 362 |  |
| Furniture and fixtures |  | 498 |  |  | 509 |  |
|  |  | 12,460 |  |  | 12,520 |  |
| Less accumulated depreciation and amortization |  | (9,248 | ) |  | (9,268 | ) |
| Total |  | $ | 3,212 |  |  | $ | 3,252 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000858877-15-000013:notes:291]
[same as prior period, unchanged from 0000858877-14-000043:notes:262]

[0000858877-15-000013:notes:292]
[same as prior period, unchanged from 0000858877-14-000043:notes:263]

[0000858877-15-000013:notes:293]
In connection with a restructuring action announced in August 2014 ("Fiscal 2015 Plan"), the Company incurred cumulative charges of $69 million and $387 million for the three and six months ended January 24, 2015, respectively.  The Company estimates that it will recognize aggregate pre-tax charges pursuant to the restructuring action in an amount not expected to exceed $600 million, consisting of severance and other one-time termination benefits and other associated costs.  These charges are primarily cash-based and the Company expects the remaining amount to be recognized during the remainder of fiscal 2015.

[0000858877-15-000013:notes:294]
[same as prior period, unchanged from 0000858877-14-000043:notes:265]

[0000858877-15-000013:notes:295]
In connection with a restructuring action announced in August 2013 ("Fiscal 2014 Plan"), the Company incurred cumulative charges of approximately $418 million, of which $73 million and $310 million were incurred during the three and six months ended January 25, 2014, respectively.  The Company completed the Fiscal 2014 Plan at the end of fiscal 2014.

[0000858877-15-000013:notes:296]
[same as prior period, unchanged from 0000858877-14-000043:notes:267]

[0000858877-15-000013:notes:297]
|  |  | Fiscal 2014 and Prior Plans |  | Fiscal 2015 Plan |  |  |
|  |  | EmployeeSeverance |  | Other |  | EmployeeSeverance |  | Other |  | Total |
| Liability as of July 26, 2014 |  | $ | 40 |  |  | $ | 29 |  |  | $ | — |  |  | $ | — |  |  | $ | 69 |  |
| Gross charges in fiscal 2015 |  | — |  |  | — |  |  | 386 |  |  | 1 |  |  | 387 |  |
| Cash payments |  | (18 | ) |  | — |  |  | (347 | ) |  | (3 | ) |  | (368 | ) |
| Non-cash items |  | — |  |  | (8 | ) |  | — |  |  | 2 |  |  | (6 | ) |
| Liability as of January 24, 2015 |  | $ | 22 |  |  | $ | 21 |  |  | $ | 39 |  |  | $ | — |  |  | $ | 82 |  |


## us-gaap:ScheduleOfNewAccountingPronouncementsAndChangesInAccountingPrinciplesTextBlock

[0000858877-15-000013:notes:298]
New Accounting Updates Recently Adopted

[0000858877-15-000013:notes:299]
In March 2013, the FASB issued an accounting standard update requiring an entity to release into net income the entire amount of a cumulative translation adjustment related to its investment in a foreign entity when as a parent it sells either a part or all of its investment in the foreign entity or no longer holds a controlling financial interest in a subsidiary or group of assets within the foreign entity.  This accounting standard update became effective for the Company beginning in the first quarter of fiscal 2015. The application of this accounting standard update did not have any impact to the Company's Consolidated Financial Statements.

[0000858877-15-000013:notes:300]
In July 2013, the FASB issued an accounting standard update that provides explicit guidance on the financial statement presentation of an unrecognized tax benefit when a net operating loss carryforward or a tax credit carryforward exists. Under the new standard update, an unrecognized tax benefit, or a portion of an unrecognized tax benefit, is to be presented in the financial statements as a reduction to a deferred tax asset for a net operating loss carryforward or a tax credit carryforward.  This accounting standard update became effective for the Company beginning in the first quarter of fiscal 2015 and applied prospectively. The application of this accounting standard update did not have a material impact to the Company's Consolidated Financial Statements.

[0000858877-15-000013:notes:301]
In April 2014, the FASB issued an accounting standard update that changes the criteria for reporting discontinued operations.  This accounting standard update raises the threshold for a disposal transaction to qualify as a discontinued operation and requires additional disclosures about discontinued operations and disposals of individually significant components that do not qualify as discontinued operations.  The Company adopted this accounting standard update in the second quarter of fiscal 2015, and it did not have any impact upon adoption.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000858877-15-000013:notes:302]
[same as prior period, unchanged from 0000858877-14-000043:notes:274]

[0000858877-15-000013:notes:303]
[same as prior period, unchanged from 0000858877-14-000043:notes:275]

[0000858877-15-000013:notes:304]
[same as prior period, unchanged from 0000858877-14-000043:notes:276]


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000858877-15-000013:notes:305]
[same as prior period, unchanged from 0000858877-14-000043:notes:279]

[0000858877-15-000013:notes:306]
[same as prior period, unchanged from 0000858877-14-000043:notes:280]

[0000858877-15-000013:notes:307]
During the six months ended January 24, 2015, the Company declared and paid cash dividends of $0.38 per common share, or $1.9 billion, on the Company’s outstanding common stock.  During the six months ended January 25, 2014, the Company declared and paid cash dividends of $0.34 per common share, or $1.8 billion, on the Company’s outstanding common stock.

[0000858877-15-000013:notes:308]
On February 11, 2015, the Company’s Board of Directors declared a quarterly dividend of $0.21 per common share to be paid on April 22, 2015 to all shareholders of record as of the close of business on April 2, 2015.  Any future dividends will be subject to the approval of the Company’s Board of Directors.

[0000858877-15-000013:notes:309]
[same as prior period, unchanged from 0000858877-14-000043:notes:283]

[0000858877-15-000013:notes:310]
In September 2001, the Company’s Board of Directors authorized a stock repurchase program. As of January 24, 2015, the Company’s Board of Directors had authorized an aggregate repurchase of up to $97 billion of common stock under this program, and the remaining authorized repurchase amount was $6.3 billion, with no termination date. A summary of the stock repurchase activity under the stock repurchase program, reported based on the trade date, is summarized as follows (in millions, except per-share amounts):

[0000858877-15-000013:notes:311]
[same as prior period, unchanged from 0000858877-14-000043:notes:287]

[0000858877-15-000013:notes:312]
[same as prior period, unchanged from 0000858877-14-000043:notes:288]

[0000858877-15-000013:notes:313]
For the six months ended January 24, 2015 and January 25, 2014, the Company repurchased approximately 15 million and 13 million shares, or $369 million and $309 million, of common stock, respectively, in settlement of employee tax withholding obligations due upon the vesting of restricted stock or stock units.


## us-gaap:SupplementalBalanceSheetDisclosuresTextBlock

[0000858877-15-000013:notes:314]
[same as prior period, unchanged from 0000858877-14-000043:notes:290]


## us-gaap:TreasuryStockTextBlock

[0000858877-15-000013:notes:315]
[same as prior period, unchanged from 0000858877-14-000043:notes:291]

[0000858877-15-000013:notes:316]
In September 2001, the Company’s Board of Directors authorized a stock repurchase program. As of January 24, 2015, the Company’s Board of Directors had authorized an aggregate repurchase of up to $97 billion of common stock under this program with no termination date. The stock repurchases since the inception of this program and the related impacts on Cisco shareholders’ equity are summarized in the following table (in millions):
