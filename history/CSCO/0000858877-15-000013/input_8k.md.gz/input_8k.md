# CSCO 8-K — 0001193125-15-044175 filed 2015-02-11

## item codes, every 8-K on or before 2015-02-18

- 2015-02-11 0001193125-15-044175 — 2.02
- 2014-12-19 0001193125-14-448754 — 8.01
- 2014-12-18 0001193125-14-447039 — 8.01
- 2014-11-24 0001193125-14-423591 — 5.02, 5.07, 9.01
- 2014-11-14 0001193125-14-413384 — 5.02
- 2014-11-12 0001193125-14-409258 — 2.02
- 2014-09-25 0001193125-14-353210 — 8.01
- 2014-09-12 0001193125-14-340480 — 5.02
- 2014-08-14 0001193125-14-308733 — 2.05
- 2014-08-13 0001193125-14-308403 — 2.02
- 2014-07-31 0001193125-14-289683 — 5.02
- 2014-06-25 0001193125-14-249157 — 8.01
- 2014-05-14 0001193125-14-199056 — 2.02
- 2014-03-26 0001193125-14-116588 — 8.01
- 2014-03-11 0001193125-14-093805 — 8.01
- 2014-03-03 0001193125-14-079163 — 1.01, 8.01, 9.01
- 2014-02-26 0001193125-14-069912 — 1.01, 9.01
- 2014-02-12 0001193125-14-048150 — 2.02
- 2013-12-23 0001193125-13-483099 — 8.01
- 2013-12-04 0001193125-13-462216 — 8.01
- 2013-11-20 0001193125-13-448477 — 5.02, 5.07, 9.01
- 2013-11-13 0001193125-13-440194 — 2.02
- 2013-08-15 0001193125-13-335218 — 2.05
- 2013-08-14 0001193125-13-334648 — 2.02
- 2013-07-23 0001193125-13-298129 — 8.01, 9.01
- 2013-06-24 0001193125-13-269064 — 8.01
- 2013-06-12 0001193125-13-256194 — 8.01
- 2013-06-07 0001193125-13-250920 — 8.01
- 2013-05-15 0001193125-13-222377 — 2.02
- 2013-03-26 0001193125-13-127015 — 8.01
- 2013-02-13 0001193125-13-055377 — 2.02
- 2013-02-01 0001193125-13-034682 — 5.02
- 2013-01-08 0001193125-13-006886 — 5.02, 9.01
- 2012-12-21 0001193125-12-513130 — 8.01
- 2012-12-19 0001193125-12-508424 — 8.01
- 2012-11-16 0001193125-12-474089 — 5.02, 5.07, 9.01
- 2012-11-13 0001193125-12-467422 — 2.02
- 2012-10-04 0001193125-12-415386 — 5.02, 5.03, 9.01
- 2012-09-19 0001193125-12-396875 — 5.02, 8.01
- 2012-08-15 0001193125-12-357479 — 2.02
- 2012-08-02 0001193125-12-332045 — 5.02
- 2012-06-27 0001193125-12-285742 — 8.01
- 2012-06-13 0001193125-12-269642 — 8.01
- 2012-05-09 0001193125-12-222045 — 2.02
- 2012-03-27 0001193125-12-134384 — 8.01
- 2012-03-15 0001193125-12-117538 — 8.01, 9.01
- 2012-02-17 0001193125-12-067542 — 1.01, 1.02, 2.03, 9.01
- 2012-02-08 0001193125-12-046545 — 2.02
- 2011-12-16 0001193125-11-343995 — 8.01
- 2011-12-08 0001193125-11-335127 — 5.02, 5.07, 9.01
- 2011-11-09 0001193125-11-304587 — 2.02
- 2011-09-29 0001193125-11-260065 — 8.01
- 2011-09-20 0001193125-11-252379 — 5.02, 9.01
- 2011-08-24 0001193125-11-231015 — 8.01
- 2011-08-10 0001193125-11-218133 — 2.02
- 2011-07-18 0001193125-11-190246 — 2.05
- 2011-06-22 0001193125-11-170849 — 8.01
- 2011-05-11 0001193125-11-135913 — 2.02
- 2011-03-28 0001193125-11-079927 — 8.01
- 2011-03-22 0001193125-11-073802 — 5.02 — amendment of 0001193125-11-043592
- 2011-03-18 0001193125-11-071279 — 8.01, 9.01
- 2011-03-16 0001193125-11-067985 — 1.01, 5.02, 8.01, 9.01
- 2011-03-15 0001193125-11-067331 — 1.01, 9.01
- 2011-03-09 0001193125-11-060123 — 8.01, 9.01
- 2011-02-23 0001193125-11-043592 — 5.02
- 2011-02-09 0001193125-11-028987 — 2.02
- 2011-01-31 0001193125-11-019101 — 1.01, 2.03
- 2010-12-17 0001193125-10-283392 — 8.01
- 2010-11-19 0001193125-10-265377 — 5.07
- 2010-11-10 0001193125-10-256001 — 2.02
- 2010-09-22 0001193125-10-214707 — 8.01
- 2010-09-16 0001193125-10-211456 — 7.01
- 2010-08-11 0001193125-10-186042 — 2.02
- 2010-06-29 0001193125-10-149956 — 8.01
- 2010-05-12 0001193125-10-117509 — 2.02
- 2010-02-17 0001193125-10-033290 — 5.02, 8.01, 9.01
- 2010-02-03 0001193125-10-020775 — 2.02
- 2009-11-25 0001193125-09-242589 — 8.01
- 2009-11-17 0001193125-09-236335 — 1.01, 8.01, 9.01
- 2009-11-13 0001193125-09-234405 — 1.01, 2.03, 9.01
- 2009-11-13 0001193125-09-234397 — 5.02 — amendment of 0001193125-09-189511
- 2009-11-12 0001193125-09-232971 — 5.02, 7.01, 9.01
- 2009-11-09 0001193125-09-228541 — 8.01, 9.01
- 2009-11-04 0001193125-09-223763 — 2.02
- 2009-10-14 0001193125-09-207912 — 8.01, 9.01
- 2009-10-05 0001193125-09-203556 — 8.01
- 2009-09-10 0001193125-09-189511 — 5.02
- 2009-09-04 0001193125-09-187835 — 5.02
- 2009-08-05 0001193125-09-165404 — 2.02
- 2009-07-27 0001193125-09-155861 — 5.02
- 2009-05-29 0001193125-09-121672 — 8.01
- 2009-05-06 0001193125-09-101570 — 2.02
- 2009-02-26 0001193125-09-038162 — 5.02
- 2009-02-17 0001193125-09-030546 — 1.01, 8.01, 9.01
- 2009-02-13 0001193125-09-029295 — 1.01, 2.03, 9.01
- 2009-02-04 0001193125-09-018793 — 2.02
- 2008-11-05 0001193125-08-225857 — 2.02
- 2008-09-11 0001193125-08-194695 — 7.01
- 2008-08-05 0001193125-08-166496 — 2.02
- 2008-06-20 0001193125-08-137504 — 8.01
- 2008-05-06 0001193125-08-104089 — 2.02
- 2008-03-21 0001193125-08-062838 — 8.01
- 2008-02-06 0001193125-08-021681 — 2.02
- 2008-01-23 0001193125-08-010589 — 5.02
- 2008-01-04 0001193125-08-001680 — 5.02, 9.01
- 2007-12-21 0001193125-07-269613 — 5.02
- 2007-11-19 0001193125-07-250345 — 5.02 — amendment of 0001193125-07-009285
- 2007-11-19 0001193125-07-250343 — 5.02, 9.01
- 2007-11-07 0001193125-07-238464 — 2.02
- 2007-09-24 0001193125-07-206279 — 8.01
- 2007-09-20 0001193125-07-204616 — 5.02, 7.01
- 2007-09-07 0001193125-07-197514 — 8.01
- 2007-08-17 0001193125-07-185320 — 1.01, 2.03, 9.01
- 2007-08-08 0001193125-07-174077 — 5.02
- 2007-08-07 0001193125-07-173689 — 2.02
- 2007-08-01 0001193125-07-168143 — 5.02
- 2007-05-15 0001193125-07-115800 — 8.01
- 2007-05-08 0001193125-07-106059 — 2.02
- 2007-03-23 0001193125-07-063033 — 5.02, 5.03, 8.01, 9.01
- 2007-03-21 0001193125-07-060631 — 1.01, 9.01
- 2007-02-06 0001193125-07-021349 — 2.02
- 2007-01-19 0001193125-07-009285 — 5.02
- 2006-12-22 0001193125-06-259241 — 8.01
- 2006-11-16 0001193125-06-237260 — 5.03, 8.01, 9.01
- 2006-11-08 0001193125-06-228341 — 2.02
- 2006-09-21 0001193125-06-194890 — 1.01, 7.01
- 2006-09-20 0001193125-06-194063 — 1.01
- 2006-09-15 0001193125-06-191845 — 5.02
- 2006-08-18 0001193125-06-176193 — 5.02
- 2006-08-08 0001193125-06-165719 — 2.02
- 2006-07-31 0001193125-06-157106 — 1.01, 9.01
- 2006-07-31 0001193125-06-157102 — 5.02 — amendment of 0001193125-06-017426
- 2006-06-08 0001193125-06-126879 — 5.02
- 2006-05-18 0001193125-06-115516 — 8.01
- 2006-05-12 0001193125-06-110924 — 9.01 — amendment of 0001193125-06-044013
- 2006-05-09 0001193125-06-105419 — 2.02
- 2006-03-29 0001193125-06-066990 — 1.01
- 2006-03-02 0001193125-06-044013 — 1.01, 2.01, 9.01
- 2006-02-28 0001193125-06-041452 — 1.01
- 2006-02-22 0001193125-06-036759 — 8.01
- 2006-02-22 0001193125-06-036433 — 1.01, 8.01, 9.01
- 2006-02-21 0001193125-06-035865 — 1.01, 2.03, 9.01
- 2006-02-10 0001193125-06-026218 — 8.01, 9.01
- 2006-02-07 0001193125-06-022234 — 2.02
- 2006-02-01 0001193125-06-017426 — 5.02
- 2005-11-18 0001193125-05-229535 — 1.01, 9.01
- 2005-11-16 0001193125-05-227987 — 1.01, 9.01
- 2005-11-16 0001193125-05-227983 — 5.02 — amendment of 0001193125-05-008843
- 2005-11-09 0001193125-05-221610 — 2.02
- 2005-09-29 0001193125-05-194217 — 7.01
- 2005-09-27 0001193125-05-192353 — 8.01
- 2005-09-21 0001193125-05-189234 — 1.01, 9.01
- 2005-09-19 0001193125-05-187646 — 8.01
- 2005-09-09 0001193125-05-183273 — 8.01
- 2005-09-08 0001193125-05-182307 — 1.01
- 2005-08-09 0001193125-05-162626 — 2.02
- 2005-07-15 0001193125-05-142738 — 8.01
- 2005-05-10 0001193125-05-102797 — 2.02
- 2005-03-30 0001193125-05-065123 — 1.01, 3.03, 9.01
- 2005-03-04 0001193125-05-042778 — 1.01
- 2005-02-08 0001193125-05-022181 — 2.02
- 2005-01-20 0001193125-05-008843 — 5.02
- 2004-12-23 0001193125-04-219331 — 8.01
- 2004-11-09 0001193125-04-191303 — 2.02
- 2004-08-23 0001193125-04-145198 — 1.01, 7.01
- 2004-08-19 0001193125-04-143859 — 5
- 2004-08-10 0001193125-04-136865 — 12
- 2004-05-11 0001193125-04-084721 — 12
- 2004-02-03 0001193125-04-013750 — 12
- 2003-11-05 0001193125-03-073418 — 12
- 2003-09-02 0001193125-03-044521 — 9
- 2003-08-05 0001193125-03-029223 — 12, 7
- 2003-07-18 0001193125-03-021155 — 5, 7
- 2003-06-05 0001012870-03-002949 — 5
- 2003-05-06 0000891618-03-002315 — 7, 9
- 2003-04-17 0000891618-03-001894 — 5, 7
- 2003-04-11 0000891618-03-001791 — 9
- 2003-03-20 0000891618-03-001326 — 5, 7
- 2003-02-04 0000891618-03-000518 — 7, 9
- 2003-01-28 0000891618-03-000271 — 5, 7
- 2002-12-27 0000891618-02-005686 — 5, 7
- 2002-10-23 0000891618-02-004715 — 5, 7
- 2002-10-11 0000891618-02-004620 — 5, 7
- 2002-09-18 0000891618-02-004352 — 5, 7
- 2002-08-20 0000891618-02-004001 — 5, 7
- 2002-08-05 0000891618-02-003498 — 5, 7
- 2002-07-03 0000891618-02-003099 — 5, 7
- 2002-05-14 0000891618-02-002407 — 5, 7
- 2002-02-05 0000891618-02-000412 — 5, 7
- 2001-09-28 0001095811-01-505261 — 5, 7
- 2001-09-14 0001095811-01-504917 — 5, 7
- 2001-08-24 0001095811-01-504581 — 5, 7
- 2001-07-30 0001095811-01-503468 — 5, 7
- 2001-07-12 0000891618-01-501567 — 5, 7
- 2001-05-11 0000891618-01-500638 — 5, 7
- 2001-02-27 0000891618-01-500076 — 5, 7
- 2001-02-20 0001095811-01-001530 — 5, 7
- 2001-02-08 0001095811-01-000848 — 5, 7
- 2001-02-07 0001095811-01-000768 — 5
- 2000-12-27 0001095811-00-005511 — 5
- 2000-12-21 0001095811-00-005427 — 5
- 2000-12-19 0001095811-00-005368 — 5
- 2000-11-15 0001095811-00-004830 — 5
- 2000-11-15 0001095811-00-004824 — 5
- 2000-11-13 0000891618-00-005023 — 5
- 2000-11-07 0001095811-00-004387 — 5, 7
- 2000-11-06 0001095811-00-004318 — 5
- 2000-09-29 0000891618-00-004739 — 5, 7
- 2000-09-28 0000891618-00-004722 — 5
- 2000-09-26 0001095811-00-003573 — 5
- 2000-09-15 0001095811-00-003413 — 5
- 2000-09-07 0001095811-00-003229 — 5
- 2000-08-15 0000891618-00-004430 — 5
- 2000-08-04 0001095811-00-002304 — 5, 7 — amendment, the index does not say of what
- 2000-07-28 0000891618-00-004132 — 5, 7
- 2000-06-29 0000891618-00-003637 — 5
- 2000-06-07 0000891618-00-003209 — 5
- 2000-05-26 0000891618-00-003054 — 5
- 2000-05-18 0000891618-00-002975 — 5, 7
- 2000-05-15 0000891618-00-002808 — 5, 7
- 2000-05-03 0000891618-00-002473 — 5
- 2000-04-03 0000891618-00-001936 — 5
- 2000-03-28 0000891618-00-001763 — 5
- 2000-03-27 0000891618-00-001722 — 5, 7
- 2000-03-16 0000891618-00-001512 — 5
- 2000-02-17 0000891618-00-001024 — 5, 7
- 2000-02-03 0000891618-00-000468 — 7 — amendment of 0000891618-99-005685
- 1999-12-22 0000891618-99-005792 — 5, 7
- 1999-12-15 0000891618-99-005685 — 5, 7
- 1999-11-17 0000891618-99-005313 — 5, 7
- 1999-11-04 0000891618-99-004862 — 5, 7
- 1999-10-20 0000891618-99-004625 — 5, 7
- 1999-09-27 0000891618-99-004333 — 5, 7
- 1999-08-26 0000891618-99-003978 — 5, 7
- 1999-08-13 0000891618-99-003764 — 5, 7 — amendment of 0000891618-99-003749
- 1999-08-13 0000891618-99-003749 — 5, 7
- 1999-07-02 0000891618-99-002980 — 5, 7
- 1999-05-14 0000891618-99-002221 — 5
- 1998-11-20 0000891618-98-005074 — 5, 7
- 1998-11-20 0000891618-98-005073 — 5, 7
- 1998-10-13 0000891618-98-004462 — 5, 7
- 1998-07-09 0000891618-98-003245 — 5, 7
- 1998-06-11 0000891618-98-002832 — 5, 7
- 1998-05-15 0000891618-98-002457 — 5, 7
- 1998-04-29 0000891618-98-001996 — 5
- 1998-02-11 0000891618-98-000584 — 5, 7
- 1997-09-09 0000891618-97-003723 — 5, 7
- 1997-08-22 0000891618-97-003559 — 5, 7
- 1997-07-01 0000891618-97-002807 — 5, 7
- 1997-01-22 0000891618-97-000120 — 5, 7
- 1996-10-15 0000891618-96-002283 — 5, 7 — amendment of 0000891618-96-002217
- 1996-10-01 0000891618-96-002217 — 5, 7
- 1996-07-23 0000891618-96-001305 — 2, 7
- 1996-04-26 0000891618-96-000253 — 2
- 1996-04-02 0000898430-96-001187 — 2, 7
- 1995-12-06 0000891618-95-000728 — 2, 7
- 1995-12-06 0000891618-95-000727 — 2, 7

## late-filing notifications on or before 2015-02-18

- none on or before 2015-02-18

## item 2.02 — earnings release, exhibit 99.1

[0001193125-15-044175:8k_2_02:1]
EX-99.1
2
d870540dex991.htm
EX-99.1

[0001193125-15-044175:8k_2_02:2]
EX-99.1

[0001193125-15-044175:8k_2_02:3]
Exhibit 99.1

[0001193125-15-044175:8k_2_02:4]
| Press Contact: |  |  |  |  |  | Investor Relations Contact: |
| Robyn Jenkins-Blum |  |  |  |  |  | Marilyn Mora |
| Cisco |  |  |  |  |  | Cisco |
| 1 (408) 853-9848 |  |  |  |  |  | 1 (408) 527-7452 |
| rojenkin@cisco.com |  |  |  |  |  | marilmor@cisco.com |

[0001193125-15-044175:8k_2_02:5]
CISCO REPORTS SECOND QUARTER EARNINGS

[0001193125-15-044175:8k_2_02:6]
Strong Momentum and Results; Dividend Increase to $0.21

[0001193125-15-044175:8k_2_02:7]
|  | • |  | Q2 Revenue: $11.9 billion (increase of 7% year over year) |

[0001193125-15-044175:8k_2_02:8]
|  | • |  | Q2 Earnings per Share: $0.46 GAAP; $0.53 non-GAAP |

[0001193125-15-044175:8k_2_02:9]
SAN JOSE, Calif. — February 11,
2015 — Cisco, the worldwide leader in networking that transforms how people connect, communicate and collaborate, today reported its second quarter results for the period ended January 24, 2015. Cisco reported second quarter revenue of
$11.9 billion, net income on a generally accepted accounting principles (GAAP) basis of $2.4 billion or $0.46 per share, and non-GAAP net income of $2.7 billion or $0.53 per share.

[0001193125-15-044175:8k_2_02:10]
“Our Q2 results reflect continued progress as we transform Cisco to become the #1 IT company. In the quarter we grew revenues by 7%, with strong EPS
growth, and saw the best balance of growth across all our geographies, products, and segments. We delivered this strong performance despite a volatile economic environment,” stated Cisco chairman and CEO John Chambers.

[0001193125-15-044175:8k_2_02:11]
“Our strong momentum is the direct result of how well we have managed our company transformation over the last three plus years and our leadership
position in the key technology transitions of cloud, mobility, big data, security, collaboration, and the Internet of Everything. Every nation, every company, everything is becoming digitized and the network is at the center of this
transformation.”

[0001193125-15-044175:8k_2_02:12]
GAAP Results

[0001193125-15-044175:8k_2_02:13]
|  |  | Q2 2015 |  |  | Q2 2014 |  |  | Vs. Q2 2014 |  |
| Revenue |  | $ | 11.9 billion |  |  | $ | 11.2 billion |  |  |  | 7.0 | % |
| Net Income |  | $ | 2.4 billion |  |  | $ | 1.4 billion |  |  |  | 67.7 | % |
| Earnings per Share |  | $ | 0.46 |  |  | $ | 0.27 |  |  |  | 70.4 | % |

[0001193125-15-044175:8k_2_02:14]
Non-GAAP Results

[0001193125-15-044175:8k_2_02:15]
|  |  | Q2 2015 |  |  | Q2 2014 |  |  | Vs. Q2 2014 |  |
| Net Income |  | $ | 2.7 billion |  |  | $ | 2.5 billion |  |  |  | 8.9 | % |
| Earnings per Share |  | $ | 0.53 |  |  | $ | 0.47 |  |  |  | 12.8 | % |

[0001193125-15-044175:8k_2_02:16]
Revenue for the first six months of fiscal 2015 was $24.2 billion, compared with $23.2 billion for the first six months of
fiscal 2014. Net income for the first six months of fiscal 2015, on a GAAP basis, was $4.2 billion or $0.82 per share, compared with $3.4 billion or $0.64 per share for the first six months of fiscal 2014. Non-GAAP net income for the first six
months of fiscal 2015 was $5.5 billion or $1.08 per share, compared with $5.4 billion or $1.00 per share for the first six months of fiscal 2014.

[0001193125-15-044175:8k_2_02:17]
A
reconciliation between net income on a GAAP basis and non-GAAP net income is provided in the table following the Consolidated Statements of Operations.

[0001193125-15-044175:8k_2_02:18]
Cisco will discuss second quarter results and business outlook on a conference call and webcast at 1:30 p.m. Pacific Time today. Call information and related
charts are available at http://investor.cisco.com.

[0001193125-15-044175:8k_2_02:19]
Cisco Increases Quarterly Cash Dividend

[0001193125-15-044175:8k_2_02:20]
Cisco is also announcing that earlier today its Board of Directors declared a quarterly dividend of $0.21 per common share, a two-cent increase over the
previous quarter’s dividend, to be paid on April 22, 2015 to all shareholders of record as of the close of business on April 2, 2015. Future dividends will be subject to Board approval.

[0001193125-15-044175:8k_2_02:21]
“This was a good quarter to start as CFO,” stated Kelly Kramer, EVP and CFO. “The momentum in the business feels good and we are excited about
the opportunities ahead. Our revenue growth and increased EPS allows us to continue to give back to shareholders as we returned $2.2 billion to shareholders in Q2 and remain committed to returning at least 50% of our free cash flow annually. We are
also pleased to increase our dividend to $0.21 this quarter, an 11% increase.”

[0001193125-15-044175:8k_2_02:22]
Other Financial Highlights

[0001193125-15-044175:8k_2_02:23]
|  | • |  | Cash flows from operations were $2.9 billion for the second quarter of fiscal 2015, compared with $2.5 billion for the first quarter of fiscal 2015, and compared with $2.9 billion for the second quarter of fiscal 2014. |

[0001193125-15-044175:8k_2_02:24]
|  | • |  | Cash and cash equivalents and investments were $53.0 billion at the end of the second quarter of fiscal 2015, compared with $52.1 billion at the end of the first quarter of fiscal 2015, and compared with $52.1 billion at the end of the fourth quarter of fiscal 2014. |

[0001193125-15-044175:8k_2_02:25]
|  | • |  | During the second quarter of fiscal 2015, Cisco paid a cash dividend of $0.19 per common share, or $974 million. |

[0001193125-15-044175:8k_2_02:26]
|  | • |  | Cisco repurchased approximately 44 million shares of common stock under the stock repurchase program at an average price of $27.63 per share for an aggregate purchase price of $1.2 billion during the second quarter of fiscal 2015. As of January 24, 2015, Cisco had repurchased and retired 4.4 billion shares of Cisco common stock at an average price of $20.73 per share for an aggregate purchase price of approximately $90.7 billion since the inception of the stock repurchase program. The remaining authorized amount for stock repurchases under this program is approximately $6.3 billion with no termination date. |

[0001193125-15-044175:8k_2_02:27]
Internet of Everything

[0001193125-15-044175:8k_2_02:28]
|  | • |  | The Metropolitan Regional Government of Santiago signed a collaboration agreement with Cisco Chile with the aim to turn Santiago into a “Smart City.” |

[0001193125-15-044175:8k_2_02:29]
|  | • |  | Cisco announced the opening of a new Internet of Everything (IoE) Innovation Center in Tokyo. |

[0001193125-15-044175:8k_2_02:30]
Fast IT

[0001193125-15-044175:8k_2_02:31]
|  | • |  | Cisco released the Cisco 2015 Annual Security Report that revealed a widening gap between perception and reality of cybersecurity readiness. |

[0001193125-15-044175:8k_2_02:32]
|  | • |  | The Cisco® Connected Analytics for the IoE was unveiled to help customers access, analyze and act on data — from the cloud to the data center to the network’s edge. |

[0001193125-15-044175:8k_2_02:33]
|  | • |  | Cisco and IBM announced the VersaStack solution that combines the innovation of the Cisco UCS® Integrated Infrastructure with the efficiency of the IBM Storwize storage system. |

[0001193125-15-044175:8k_2_02:34]
|  | • |  | The fourth annual Cisco Global Cloud Index (2013-2018) projected that over the next five years data center traffic will nearly triple, with cloud representing 76 percent of total data center traffic. |

[0001193125-15-044175:8k_2_02:35]
|  | • |  | Cisco Meraki® solutions will be used to offer Internet connectivity under Mexico Conectado, a program developed by the Mexican federal government that offers broadband connectivity to the population in public areas. |

[0001193125-15-044175:8k_2_02:36]
|  | • |  | Cisco announced that four new cloud providers from across Latin America have joined the Intercloud partner ecosystem. |

[0001193125-15-044175:8k_2_02:37]
|  | • |  | Cisco announced that beIN SPORTS selected the Cisco VideoscapeTM TV platform to deliver advanced sports video experiences across more than 20 countries in the Middle East and North Africa. |

[0001193125-15-044175:8k_2_02:38]
Innovation

[0001193125-15-044175:8k_2_02:39]
|  | • |  | Cisco completed the acquisition of Neohapsis to help deliver comprehensive services to help customers build the security capabilities required to remain secure and competitive in today’s markets. |

[0001193125-15-044175:8k_2_02:40]
|  | • |  | Cisco and Charter Communications entered a strategic agreement to supply key Cisco products in support of Charter’s next-generation video solution. |

[0001193125-15-044175:8k_2_02:41]
|  | • |  | In December 2014, Cisco celebrated 30 years of innovation. |

[0001193125-15-044175:8k_2_02:42]
|  | • |  | Cisco unveiled Project Squared, a business collaboration app that combines chat, audio, video, multi-party meetings and content sharing in a single experience that supports the demanding collaboration needs of modern teams. |

[0001193125-15-044175:8k_2_02:43]
|  | • |  | Cisco introduced the TelePresenceTM IX5000 series, a world-class quality video collaboration experience for 6-to-18 people. |

[0001193125-15-044175:8k_2_02:44]
|  | • |  | Cisco was named one of the 50 most innovative companies by Boston Consulting Group and jumped to 14th from 46th last year. |

[0001193125-15-044175:8k_2_02:45]
Editor’s Notes:

[0001193125-15-044175:8k_2_02:46]
|  | • |  | Q2 fiscal year 2015 conference call to discuss Cisco’s results along with its business outlook will be held on Wednesday, February 11, 2015 at 1:30 p.m. Pacific Time. Conference call number is 1-888-848-6507 (United States) or 1-212-519-0847 (international). |

[0001193125-15-044175:8k_2_02:47]
2

[0001193125-15-044175:8k_2_02:48]
|  | • |  | Conference call replay will be available from 4:00 p.m. Pacific Time, February 11, 2015 to 4:00 p.m. Pacific Time, on February 18, 2015 at 1-866-410-5841 (United States) or 1-203-369-0643 (international). The replay will also be available via webcast from February 11, 2015 through April 17, 2015 on the Cisco Investor Relations website at http://investor.cisco.com. |

[0001193125-15-044175:8k_2_02:49]
|  | • |  | Additional information regarding Cisco’s financials, as well as a webcast of the conference call with visuals designed to guide participants through the call, will be available at 1:30 p.m. Pacific Time, February 11, 2015. Text of the conference call’s prepared remarks will be available within 24 hours of completion of the call. The webcast will include both the prepared remarks and the question-and-answer session. This information, along with the GAAP to non-GAAP reconciliation information, will be available on the Cisco Investor Relations website at http://investor.cisco.com. |

[0001193125-15-044175:8k_2_02:50]
About Cisco

[0001193125-15-044175:8k_2_02:51]
Cisco (NASDAQ: CSCO) is the worldwide leader
in IT that helps companies seize the opportunities of tomorrow by proving that amazing things can happen when you connect the previously unconnected. For ongoing news, please go to http://thenetwork.cisco.com.

[0001193125-15-044175:8k_2_02:52]
###

[0001193125-15-044175:8k_2_02:53]
This release includes non-GAAP net income, non-GAAP effective tax rates,
non-GAAP net income per share data, non-GAAP inventory turns and free cash flow.

[0001193125-15-044175:8k_2_02:54]
These non-GAAP measures are not in accordance with, or an alternative
for, measures prepared in accordance with generally accepted accounting principles and may be different from non-GAAP measures used by other companies. In addition, these non-GAAP measures are not based on any comprehensive set of accounting rules
or principles. Cisco believes that non-GAAP measures have limitations in that they do not reflect all of the amounts associated with Cisco’s results of operations as determined in accordance with GAAP and that these measures should only be used
to evaluate Cisco’s results of operations in conjunction with the corresponding GAAP measures.

[0001193125-15-044175:8k_2_02:55]
Cisco believes that the presentation of non-GAAP net
income, non-GAAP effective tax rates, and non-GAAP net income per share data, when shown in conjunction with the corresponding GAAP measures, provides useful information to investors and management regarding financial and business trends relating to
its financial condition and results of operations. In addition, Cisco believes that the presentation of non-GAAP inventory turns provides useful information to investors and management regarding financial and business trends relating to inventory
management based on the operating activities of the periods presented. Cisco believes that the presentation of free cash flow, which it defines as the net cash provided by operating activities less cash used to

[0001193125-15-044175:8k_2_02:56]
3

[0001193125-15-044175:8k_2_02:57]
acquire property and equipment, to be a liquidity measure that provides useful information to management and investors because of its intent to return a stated percentage of free cash flow to
shareholders in the form of dividends and stock repurchases. Cisco further regards free cash flow as a useful measure because it reflects cash that can be used to, among other things, invest in its business, make strategic acquisitions, repurchase
common stock, and pay dividends on its common stock, after deducting capital investments.

[0001193125-15-044175:8k_2_02:58]
For its internal budgeting process, Cisco’s management
uses financial statements that do not include, when applicable, share-based compensation expense, amortization of acquisition-related intangible assets, impact to cost of sales from purchase accounting adjustments to inventory,
acquisition-related/divestiture costs (which includes a gain recognized in the second quarter of fiscal 2015 with respect to the reorganization and divestiture of a portion of Cisco’s investment in VCE), significant asset impairments and
restructurings, significant litigation and other contingencies, the income tax effects of the foregoing, and significant tax matters. Cisco’s management also uses the foregoing non-GAAP measures, in addition to the corresponding GAAP measures,
in reviewing the financial results of Cisco. In prior periods, Cisco has excluded other items that it no longer excludes for purposes of its non-GAAP financial measures. From time to time in the future there may be other items that Cisco may exclude
for purposes of its internal budgeting process and in reviewing its financial results. For additional information on the items excluded by Cisco from one or more of its non-GAAP financial measures, refer to the Form 8-K regarding this release
furnished today to the Securities and Exchange Commission.

[0001193125-15-044175:8k_2_02:59]
Copyright © 2015 Cisco and/or its
affiliates. All rights reserved. Cisco, the Cisco logo, Cisco UCS, Meraki, TelePresence, and Videoscape are trademarks or registered trademarks of Cisco and/or its affiliates in the U.S. and other countries. To view a list of Cisco trademarks, go
to: www.cisco.com/go/trademarks. Third-party trademarks mentioned in this document are the property of their respective owners. The use of the word partner does not imply a partnership relationship between Cisco and any other company. This document
is Cisco Public Information.

[0001193125-15-044175:8k_2_02:60]
4

[0001193125-15-044175:8k_2_02:61]
CONSOLIDATED STATEMENTS OF OPERATIONS

[0001193125-15-044175:8k_2_02:62]
(In millions, except per-share amounts)

[0001193125-15-044175:8k_2_02:63]
(Unaudited)

[0001193125-15-044175:8k_2_02:64]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | January 24,2015 |  |  | January 25,2014 |  |  | January 24,2015 |  |  | January 25,2014 |  |
| REVENUE: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  | $ | 9,078 |  |  | $ | 8,423 |  |  | $ | 18,513 |  |  | $ | 17,820 |  |
| Service |  |  | 2,858 |  |  |  | 2,732 |  |  |  | 5,668 |  |  |  | 5,420 |  |
| Total revenue |  |  | 11,936 |  |  |  | 11,155 |  |  |  | 24,181 |  |  |  | 23,240 |  |
| COST OF SALES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Product |  |  | 3,806 |  |  |  | 4,323 |  |  |  | 7,725 |  |  |  | 8,070 |  |
| Service |  |  | 1,040 |  |  |  | 881 |  |  |  | 2,033 |  |  |  | 1,812 |  |
| Total cost of sales |  |  | 4,846 |  |  |  | 5,204 |  |  |  | 9,758 |  |  |  | 9,882 |  |
| GROSS MARGIN |  |  | 7,090 |  |  |  | 5,951 |  |  |  | 14,423 |  |  |  | 13,358 |  |
| OPERATING EXPENSES: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Research and development |  |  | 1,529 |  |  |  | 1,412 |  |  |  | 3,112 |  |  |  | 3,136 |  |
| Sales and marketing |  |  | 2,308 |  |  |  | 2,277 |  |  |  | 4,823 |  |  |  | 4,688 |  |
| General and administrative |  |  | 490 |  |  |  | 451 |  |  |  | 994 |  |  |  | 966 |  |
| Amortization of purchased intangible assets |  |  | 72 |  |  |  | 71 |  |  |  | 143 |  |  |  | 136 |  |
| Restructuring and other charges |  |  | 69 |  |  |  | 73 |  |  |  | 387 |  |  |  | 310 |  |
| Total operating expenses |  |  | 4,468 |  |  |  | 4,284 |  |  |  | 9,459 |  |  |  | 9,236 |  |
| OPERATING INCOME |  |  | 2,622 |  |  |  | 1,667 |  |  |  | 4,964 |  |  |  | 4,122 |  |
| Interest income |  |  | 189 |  |  |  | 169 |  |  |  | 368 |  |  |  | 338 |  |
| Interest expense |  |  | (139 | ) |  |  | (136 | ) |  |  | (278 | ) |  |  | (276 | ) |
| Other income (loss), net |  |  | 201 |  |  |  | 55 |  |  |  | 179 |  |  |  | 111 |  |
| Interest and other income (loss), net |  |  | 251 |  |  |  | 88 |  |  |  | 269 |  |  |  | 173 |  |
| INCOME BEFORE PROVISION FOR INCOME TAXES |  |  | 2,873 |  |  |  | 1,755 |  |  |  | 5,233 |  |  |  | 4,295 |  |
| Provision for income taxes |  |  | 476 |  |  |  | 326 |  |  |  | 1,008 |  |  |  | 870 |  |
| NET INCOME |  | $ | 2,397 |  |  | $ | 1,429 |  |  | $ | 4,225 |  |  | $ | 3,425 |  |
| Net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  | $ | 0.47 |  |  | $ | 0.27 |  |  | $ | 0.83 |  |  | $ | 0.64 |  |
| Diluted |  | $ | 0.46 |  |  | $ | 0.27 |  |  | $ | 0.82 |  |  | $ | 0.64 |  |
| Shares used in per-share calculation: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Basic |  |  | 5,117 |  |  |  | 5,294 |  |  |  | 5,115 |  |  |  | 5,336 |  |
| Diluted |  |  | 5,160 |  |  |  | 5,327 |  |  |  | 5,159 |  |  |  | 5,383 |  |
| Cash dividends declared per common share |  | $ | 0.19 |  |  | $ | 0.17 |  |  | $ | 0.38 |  |  | $ | 0.34 |  |

[0001193125-15-044175:8k_2_02:65]
5

[0001193125-15-044175:8k_2_02:66]
RECONCILIATION OF GAAP TO NON-GAAP NET INCOME

[0001193125-15-044175:8k_2_02:67]
(In millions, except per-share amounts)

[0001193125-15-044175:8k_2_02:68]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | January 24,2015 |  |  | January 25,2014 |  |  | January 24,2015 |  |  | January 25,2014 |  |
| GAAP net income |  | $ | 2,397 |  |  | $ | 1,429 |  |  | $ | 4,225 |  |  | $ | 3,425 |  |
| Adjustments to cost of sales: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 45 |  |  |  | 52 |  |  |  | 93 |  |  |  | 95 |  |
| Amortization of acquisition-related intangible assets |  |  | 233 |  |  |  | 182 |  |  |  | 414 |  |  |  | 349 |  |
| Supplier component remediation charge |  |  | — |  |  |  | 655 |  |  |  | — |  |  |  | 655 |  |
| Patent portfolio charge |  |  | — |  |  |  | — |  |  |  | 188 |  |  |  | — |  |
| Total adjustments to GAAP cost of sales |  |  | 278 |  |  |  | 889 |  |  |  | 695 |  |  |  | 1,099 |  |
| Adjustments to operating expenses: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | 261 |  |  |  | 296 |  |  |  | 586 |  |  |  | 565 |  |
| Amortization of acquisition-related intangible assets |  |  | 72 |  |  |  | 71 |  |  |  | 143 |  |  |  | 136 |  |
| Acquisition-related/divestiture costs |  |  | 92 |  |  |  | 107 |  |  |  | 193 |  |  |  | 415 |  |
| Significant asset impairments and restructurings |  |  | 69 |  |  |  | 73 |  |  |  | 387 |  |  |  | 310 |  |
| Total adjustments to GAAP operating expenses |  |  | 494 |  |  |  | 547 |  |  |  | 1,309 |  |  |  | 1,426 |  |
| Adjustments to other income (loss), net: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Gain on VCE reorganization |  |  | (126 | ) |  |  | — |  |  |  | (126 | ) |  |  | — |  |
| Total adjustments to GAAP income before provision for income taxes |  |  | 646 |  |  |  | 1,436 |  |  |  | 1,878 |  |  |  | 2,525 |  |
| Income tax effect of non-GAAP adjustments |  |  | (164 | ) |  |  | (275 | ) |  |  | (422 | ) |  |  | (493 | ) |
| Significant tax matters (1) |  |  | (134 | ) |  |  | (69 | ) |  |  | (134 | ) |  |  | (69 | ) |
| Total adjustments to GAAP provision for income taxes |  |  | (298 | ) |  |  | (344 | ) |  |  | (556 | ) |  |  | (562 | ) |
| Non-GAAP net income |  | $ | 2,745 |  |  | $ | 2,521 |  |  | $ | 5,547 |  |  | $ | 5,388 |  |
| Diluted net income per share: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| GAAP |  | $ | 0.46 |  |  | $ | 0.27 |  |  | $ | 0.82 |  |  | $ | 0.64 |  |
| Non-GAAP |  | $ | 0.53 |  |  | $ | 0.47 |  |  | $ | 1.08 |  |  | $ | 1.00 |  |

[0001193125-15-044175:8k_2_02:69]
| (1) | During the second quarter of fiscal 2015, Cisco recorded certain net tax benefits totaling $134 million related to prior year periods that were excluded from non-GAAP net income for the second quarter and first six months of fiscal 2015. These net tax benefits are comprised of the retroactive reinstatement of the U.S. federal R&D tax credit of $91 million related to fiscal 2014 and a net tax benefit of $43 million related to prior fiscal years. |

[0001193125-15-044175:8k_2_02:70]
RECONCILIATION OF GAAP TO NON-GAAP EFFECTIVE TAX RATE

[0001193125-15-044175:8k_2_02:71]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | January 24,2015 |  |  | January 25,2014 |  |  | January 24,2015 |  |  | January 25,2014 |  |
| GAAP effective tax rate |  |  | 16.6 | % |  |  | 18.6 | % |  |  | 19.3 | % |  |  | 20.3 | % |
| Tax effect of non-GAAP adjustments to net income |  |  | 5.4 | % |  |  | 2.4 | % |  |  | 2.7 | % |  |  | 0.7 | % |
| Non-GAAP effective tax rate |  |  | 22.0 | % |  |  | 21.0 | % |  |  | 22.0 | % |  |  | 21.0 | % |

[0001193125-15-044175:8k_2_02:72]
6

[0001193125-15-044175:8k_2_02:73]
CONDENSED CONSOLIDATED BALANCE SHEETS

[0001193125-15-044175:8k_2_02:74]
(In millions)

[0001193125-15-044175:8k_2_02:75]
(Unaudited)

[0001193125-15-044175:8k_2_02:76]
|  |  | January 24,2015 |  |  | July 26,2014 |  |
| ASSETS |  |  |  |  |  |  |  |  |
| Current assets: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 4,797 |  |  | $ | 6,726 |  |
| Investments |  |  | 48,225 |  |  |  | 45,348 |  |
| Accounts receivable, net of allowance for doubtful accounts of $270 at January 24, 2015 and $265 at July 26, 2014 |  |  | 4,541 |  |  |  | 5,157 |  |
| Inventories |  |  | 1,890 |  |  |  | 1,591 |  |
| Financing receivables, net |  |  | 4,210 |  |  |  | 4,153 |  |
| Deferred tax assets |  |  | 2,654 |  |  |  | 2,808 |  |
| Other current assets |  |  | 1,565 |  |  |  | 1,331 |  |
| Total current assets |  |  | 67,882 |  |  |  | 67,114 |  |
| Property and equipment, net |  |  | 3,212 |  |  |  | 3,252 |  |
| Financing receivables, net |  |  | 3,549 |  |  |  | 3,918 |  |
| Goodwill |  |  | 24,382 |  |  |  | 24,239 |  |
| Purchased intangible assets, net |  |  | 2,755 |  |  |  | 3,280 |  |
| Other assets |  |  | 3,142 |  |  |  | 3,331 |  |
| TOTAL ASSETS |  | $ | 104,922 |  |  | $ | 105,134 |  |
| LIABILITIES AND EQUITY |  |  |  |  |  |  |  |  |
| Current liabilities: |  |  |  |  |  |  |  |  |
| Short-term debt |  | $ | 855 |  |  | $ | 508 |  |
| Accounts payable |  |  | 988 |  |  |  | 1,032 |  |
| Income taxes payable |  |  | — |  |  |  | 159 |  |
| Accrued compensation |  |  | 2,694 |  |  |  | 3,181 |  |
| Deferred revenue |  |  | 9,369 |  |  |  | 9,478 |  |
| Other current liabilities |  |  | 6,128 |  |  |  | 5,451 |  |
| Total current liabilities |  |  | 20,034 |  |  |  | 19,809 |  |
| Long-term debt |  |  | 19,667 |  |  |  | 20,401 |  |
| Income taxes payable |  |  | 1,433 |  |  |  | 1,851 |  |
| Deferred revenue |  |  | 4,652 |  |  |  | 4,664 |  |
| Other long-term liabilities |  |  | 1,403 |  |  |  | 1,748 |  |
| Total liabilities |  |  | 47,189 |  |  |  | 48,473 |  |
| Total equity |  |  | 57,733 |  |  |  | 56,661 |  |
| TOTAL LIABILITIES AND EQUITY |  | $ | 104,922 |  |  | $ | 105,134 |  |

[0001193125-15-044175:8k_2_02:77]
CONSOLIDATED STATEMENTS OF CASH FLOWS

[0001193125-15-044175:8k_2_02:78]
(In millions)

[0001193125-15-044175:8k_2_02:79]
(Unaudited)

[0001193125-15-044175:8k_2_02:80]
|  |  | Six Months Ended |  |
|  |  | January 24,2015 |  |  | January 25,2014 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 4,225 |  |  | $ | 3,425 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation, amortization, and other |  |  | 1,224 |  |  |  | 1,203 |  |
| Share-based compensation expense |  |  | 677 |  |  |  | 656 |  |
| Provision for receivables |  |  | 62 |  |  |  | 56 |  |
| Deferred income taxes |  |  | 385 |  |  |  | (26 | ) |
| Excess tax benefits from share-based compensation |  |  | (83 | ) |  |  | (73 | ) |
| (Gains) losses on investments and other, net |  |  | (182 | ) |  |  | (163 | ) |
| Change in operating assets and liabilities, net of effects of acquisitions and divestitures: |  |  |  |  |  |  |  |  |
| Accounts receivable |  |  | 501 |  |  |  | 1,134 |  |
| Inventories |  |  | (340 | ) |  |  | (77 | ) |
| Financing receivables |  |  | 74 |  |  |  | 245 |  |
| Other assets |  |  | (218 | ) |  |  | 179 |  |
| Accounts payable |  |  | (32 | ) |  |  | (161 | ) |
| Income taxes, net |  |  | (528 | ) |  |  | (444 | ) |
| Accrued compensation |  |  | (390 | ) |  |  | (804 | ) |
| Deferred revenue |  |  | 26 |  |  |  | (205 | ) |
| Other liabilities |  |  | (27 | ) |  |  | 577 |  |
| Net cash provided by operating activities |  |  | 5,374 |  |  |  | 5,522 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of investments |  |  | (20,061 | ) |  |  | (15,874 | ) |
| Proceeds from sales of investments |  |  | 9,948 |  |  |  | 9,081 |  |
| Proceeds from maturities of investments |  |  | 7,212 |  |  |  | 7,988 |  |
| Acquisition of businesses, net of cash and cash equivalents acquired |  |  | (217 | ) |  |  | (2,784 | ) |
| Purchases of investments in privately held companies |  |  | (91 | ) |  |  | (263 | ) |
| Return of investments in privately held companies |  |  | 227 |  |  |  | 81 |  |
| Acquisition of property and equipment |  |  | (550 | ) |  |  | (577 | ) |
| Proceeds from sales of property and equipment |  |  | 5 |  |  |  | 164 |  |
| Other |  |  | (109 | ) |  |  | (6 | ) |
| Net cash used in investing activities |  |  | (3,636 | ) |  |  | (2,190 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Issuances of common stock |  |  | 1,162 |  |  |  | 837 |  |
| Repurchases of common stock - repurchase program |  |  | (2,196 | ) |  |  | (5,680 | ) |
| Shares repurchased for tax withholdings on vesting of restricted stock units |  |  | (369 | ) |  |  | (309 | ) |
| Short-term borrowings, original maturities less than 90 days, net |  |  | (4 | ) |  |  | 998 |  |
| Issuances of debt |  |  | — |  |  |  | 4 |  |
| Repayments of debt |  |  | (506 | ) |  |  | (22 | ) |
| Excess tax benefits from share-based compensation |  |  | 83 |  |  |  | 73 |  |
| Dividends paid |  |  | (1,947 | ) |  |  | (1,810 | ) |
| Other |  |  | 110 |  |  |  | (9 | ) |
| Net cash used in financing activities |  |  | (3,667 | ) |  |  | (5,918 | ) |
| Net decrease in cash and cash equivalents |  |  | (1,929 | ) |  |  | (2,586 | ) |
| Cash and cash equivalents, beginning of period |  |  | 6,726 |  |  |  | 7,925 |  |
| Cash and cash equivalents, end of period |  | $ | 4,797 |  |  | $ | 5,339 |  |
| Supplemental cash flow information: |  |  |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 383 |  |  | $ | 340 |  |
| Cash paid for income taxes, net |  | $ | 1,152 |  |  | $ | 1,340 |  |

[0001193125-15-044175:8k_2_02:81]
8

[0001193125-15-044175:8k_2_02:82]
CASH AND CASH EQUIVALENTS AND INVESTMENTS

[0001193125-15-044175:8k_2_02:83]
(In millions)

[0001193125-15-044175:8k_2_02:84]
|  |  | January 24,2015 |  |  | July 26,2014 |  |
| Cash and cash equivalents and investments: |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 4,797 |  |  | $ | 6,726 |  |
| Fixed income securities |  |  | 46,377 |  |  |  | 43,396 |  |
| Publicly traded equity securities |  |  | 1,848 |  |  |  | 1,952 |  |
| Total |  | $ | 53,022 |  |  | $ | 52,074 |  |

[0001193125-15-044175:8k_2_02:85]
RECONCILIATION OF NET CASH PROVIDED BY OPERATING ACTIVITIES

[0001193125-15-044175:8k_2_02:86]
TO FREE CASH FLOW (NON-GAAP)

[0001193125-15-044175:8k_2_02:87]
(In millions)

[0001193125-15-044175:8k_2_02:88]
|  |  | Three Months Ended |  |
|  |  | January 24,2015 |  |  | October 25,2014 |  |  | January 25,2014 |  |
| Net cash provided by operating activities |  | $ | 2,883 |  |  | $ | 2,491 |  |  | $ | 2,873 |  |
| Acquisition of property and equipment |  |  | (265 | ) |  |  | (285 | ) |  |  | (262 | ) |
| Free cash flow |  | $ | 2,618 |  |  | $ | 2,206 |  |  | $ | 2,611 |  |

[0001193125-15-044175:8k_2_02:89]
DIVIDENDS PAID AND REPURCHASES OF COMMON STOCK

[0001193125-15-044175:8k_2_02:90]
(In millions, except per-share amounts)

[0001193125-15-044175:8k_2_02:91]
|  |  | DIVIDENDS |  |  | STOCK REPURCHASE PROGRAM |  |  | TOTAL |  |
| Quarter Ended |  | Per Share |  |  | Amount |  |  | Shares |  |  | Weighted-Average Priceper Share |  |  | Amount |  |  | Amount |  |
| Fiscal 2015 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| January 24, 2015 |  | $ | 0.19 |  |  | $ | 974 |  |  |  | 44 |  |  | $ | 27.63 |  |  | $ | 1,208 |  |  | $ | 2,182 |  |
| October 25, 2014 |  | $ | 0.19 |  |  | $ | 973 |  |  |  | 41 |  |  | $ | 24.58 |  |  | $ | 1,013 |  |  | $ | 1,986 |  |
| Fiscal 2014 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| July 26, 2014 |  | $ | 0.19 |  |  | $ | 974 |  |  |  | 61 |  |  | $ | 25.11 |  |  | $ | 1,514 |  |  | $ | 2,488 |  |
| April 26, 2014 |  |  | 0.19 |  |  |  | 974 |  |  |  | 90 |  |  | $ | 22.24 |  |  |  | 2,005 |  |  |  | 2,979 |  |
| January 25, 2014 |  |  | 0.17 |  |  |  | 896 |  |  |  | 185 |  |  | $ | 21.73 |  |  |  | 4,020 |  |  |  | 4,916 |  |
| October 26, 2013 |  |  | 0.17 |  |  |  | 914 |  |  |  | 84 |  |  | $ | 23.65 |  |  |  | 2,000 |  |  |  | 2,914 |  |
| Total |  | $ | 0.72 |  |  | $ | 3,758 |  |  |  | 420 |  |  | $ | 22.71 |  |  | $ | 9,539 |  |  | $ | 13,297 |  |

[0001193125-15-044175:8k_2_02:92]
ACCOUNTS RECEIVABLE AND DSO

[0001193125-15-044175:8k_2_02:93]
(In millions, except DSO)

[0001193125-15-044175:8k_2_02:94]
|  |  | January 24,2015 |  |  | October 25,2014 |  |  | January 25,2014 |  |
| Accounts receivable, net |  | $ | 4,541 |  |  | $ | 4,375 |  |  | $ | 4,378 |  |
| Days sales outstanding in accounts receivable (DSO) |  |  | 35 |  |  |  | 33 |  |  |  | 36 |  |

[0001193125-15-044175:8k_2_02:95]
INVENTORIES

[0001193125-15-044175:8k_2_02:96]
(In millions)

[0001193125-15-044175:8k_2_02:97]
|  |  | January 24,2015 |  |  | October 25,2014 |  |  | January 25,2014 |  |
| Inventories: |  |  |  |  |  |  |  |  |  |  |  |  |
| Raw materials |  | $ | 265 |  |  | $ | 173 |  |  | $ | 81 |  |
| Work in process |  |  | 2 |  |  |  | 3 |  |  |  | 6 |  |
| Finished goods: |  |  |  |  |  |  |  |  |  |  |  |  |
| Distributor inventory and deferred cost of sales |  |  | 733 |  |  |  | 654 |  |  |  | 598 |  |
| Manufactured finished goods |  |  | 577 |  |  |  | 535 |  |  |  | 579 |  |
| Total finished goods |  |  | 1,310 |  |  |  | 1,189 |  |  |  | 1,177 |  |
| Service-related spares |  |  | 274 |  |  |  | 275 |  |  |  | 244 |  |
| Demonstration systems |  |  | 39 |  |  |  | 36 |  |  |  | 40 |  |
| Total |  | $ | 1,890 |  |  | $ | 1,676 |  |  | $ | 1,548 |  |

[0001193125-15-044175:8k_2_02:98]
INVENTORY TURNS AND RECONCILIATION OF GAAP TO NON-GAAP

[0001193125-15-044175:8k_2_02:99]
COST OF SALES USED IN INVENTORY TURNS

[0001193125-15-044175:8k_2_02:100]
(In millions, except annualized inventory turns)

[0001193125-15-044175:8k_2_02:101]
|  |  | Three Months Ended |  |
|  |  | January 24,2015 |  |  | October 25,2014 |  |  | January 25,2014 |  |
| Annualized inventory turns - GAAP |  |  | 10.9 |  |  |  | 12.0 |  |  |  | 13.8 |  |
| Cost of sales adjustments |  |  | (0.7 | ) |  |  | (1.0 | ) |  |  | (2.3 | ) |
| Annualized inventory turns - non-GAAP |  |  | 10.2 |  |  |  | 11.0 |  |  |  | 11.5 |  |
| GAAP cost of sales |  | $ | 4,846 |  |  | $ | 4,912 |  |  | $ | 5,204 |  |
| Cost of sales adjustments: |  |  |  |  |  |  |  |  |  |  |  |  |
| Share-based compensation expense |  |  | (45 | ) |  |  | (48 | ) |  |  | (52 | ) |
| Amortization of acquisition-related intangible assets |  |  | (233 | ) |  |  | (181 | ) |  |  | (182 | ) |
| Supplier component remediation charge |  |  | — |  |  |  | — |  |  |  | (655 | ) |
| Patent portfolio charge |  |  | — |  |  |  | (188 | ) |  |  | — |  |
| Non-GAAP cost of sales |  | $ | 4,568 |  |  | $ | 4,495 |  |  | $ | 4,315 |  |

[0001193125-15-044175:8k_2_02:102]
DEFERRED REVENUE

[0001193125-15-044175:8k_2_02:103]
(In millions)

[0001193125-15-044175:8k_2_02:104]
|  |  | January 24,2015 |  |  | October 25,2014 |  |  | January 25,2014 |  |
| Deferred revenue: |  |  |  |  |  |  |  |  |  |  |  |  |
| Service |  | $ | 9,020 |  |  | $ | 9,029 |  |  | $ | 8,843 |  |
| Product: |  |  |  |  |  |  |  |  |  |  |  |  |
| Unrecognized revenue on product shipments and other deferred revenue |  |  | 4,276 |  |  |  | 4,056 |  |  |  | 3,549 |  |
| Cash receipts related to unrecognized revenue from two-tier distributors |  |  | 725 |  |  |  | 659 |  |  |  | 852 |  |
| Total product deferred revenue |  |  | 5,001 |  |  |  | 4,715 |  |  |  | 4,401 |  |
| Total |  | $ | 14,021 |  |  | $ | 13,744 |  |  | $ | 13,244 |  |
| Reported as: |  |  |  |  |  |  |  |  |  |  |  |  |
| Current |  | $ | 9,369 |  |  | $ | 9,449 |  |  | $ | 9,350 |  |
| Noncurrent |  |  | 4,652 |  |  |  | 4,295 |  |  |  | 3,894 |  |
| Total |  | $ | 14,021 |  |  | $ | 13,744 |  |  | $ | 13,244 |  |

[0001193125-15-044175:8k_2_02:105]
SUMMARY OF SHARE-BASED COMPENSATION EXPENSE

[0001193125-15-044175:8k_2_02:106]
(In millions)

[0001193125-15-044175:8k_2_02:107]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | January 24,2015 |  |  | January 25,2014 |  |  | January 24,2015 |  |  | January 25,2014 |  |
| Cost of sales - product |  | $ | 11 |  |  | $ | 12 |  |  | $ | 22 |  |  | $ | 22 |  |
| Cost of sales - service |  |  | 34 |  |  |  | 40 |  |  |  | 71 |  |  |  | 73 |  |
| Share-based compensation expense in cost of sales |  |  | 45 |  |  |  | 52 |  |  |  | 93 |  |  |  | 95 |  |
| Research and development |  |  | 105 |  |  |  | 108 |  |  |  | 224 |  |  |  | 200 |  |
| Sales and marketing |  |  | 114 |  |  |  | 141 |  |  |  | 261 |  |  |  | 264 |  |
| General and administrative |  |  | 42 |  |  |  | 47 |  |  |  | 101 |  |  |  | 101 |  |
| Restructuring and other charges |  |  | 2 |  |  |  | (1 | ) |  |  | (2 | ) |  |  | (4 | ) |
| Share-based compensation expense in operating expenses |  |  | 263 |  |  |  | 295 |  |  |  | 584 |  |  |  | 561 |  |
| Total share-based compensation expense |  | $ | 308 |  |  | $ | 347 |  |  | $ | 677 |  |  | $ | 656 |  |
| Income tax benefit for share-based compensation |  | $ | 85 |  |  | $ | 82 |  |  | $ | 179 |  |  | $ | 160 |  |

[0001193125-15-044175:8k_2_02:108]
11
