# ADTN MD&A — 0001564590-21-025123


## mdna

[0001564590-21-025123:mdna:1]
[same as prior period, unchanged from 0001564590-20-052017:mdna:1]

[0001564590-21-025123:mdna:2]
The following discussion should be read in conjunction with the consolidated financial statements and the related notes that appear in Part I, Item 1 of this document.  In addition, the following discussion should be read in conjunction with our audited consolidated financial statements for the year ended December 31, 2020, Part II, Item 7, Management’s Discussion and Analysis of Financial Condition and Results of Operations, Part I, Item 1, Business, and Item 1A, Risk Factors, included in our Annual Report on Form 10-K for the year ended December 31, 2020, filed with the SEC on February 26, 2021 (the “2020 Form 10-K”).

[0001564590-21-025123:mdna:3]
This discussion is designed to provide the reader with information that will assist in understanding our condensed consolidated financial statements, the changes in certain key items in those financial statements from period to period, and the primary factors that accounted for those changes, as well as how certain accounting principles affect our condensed consolidated financial statements. See “Cautionary Note Regarding Forward-Looking Statements” on page 3 of this report for a description of important factors that could cause actual results to differ from expected results.  See also Part 1, Item 1A, Risk Factors, of the 2020 Form 10‑K.

[0001564590-21-025123:mdna:4]
[same as prior period, unchanged from 0001564590-20-052017:mdna:4]

[0001564590-21-025123:mdna:5]
ADTRAN is a leading global provider of networking and communications platforms, systems and services focused on the broadband access market, serving a diverse domestic and international customer base in multiple countries that includes Tier-1, -2 and -3 service providers, alternative service providers, such as utilities, municipalities and fiber overbuilders, cable/MSOs, SMBs and distributed enterprises. Our innovative solutions and services enable voice, data, video and internet-communications across a variety of network infrastructures and are currently in use by millions worldwide. We support our customers through our direct global sales organization and our distribution networks. Our success depends upon our ability to increase unit volume and market share through the introduction of new products and succeeding generations of products having lower selling prices and increased functionality as compared to both the prior generation of a product and to the products of competitors. In order to service our customers and grow revenue, we are continually conducting research and development of new products addressing customer needs and testing those products for the specific requirements of the particular customers. We are focused on being a top global supplier of access infrastructure and related value-added solutions from the cloud edge to the subscriber edge. We offer a broad portfolio of flexible software and hardware network solutions and services that enable service providers to meet today’s service demands, while enabling them to transition to the fully-converged, scalable, highly-automated, cloud-controlled voice, data, internet and video network of the future. In addition to our corporate headquarters in Huntsville, Alabama, we have sales and research and development facilities in strategic global locations.

[0001564590-21-025123:mdna:6]
[same as prior period, unchanged from 0001564590-20-052017:mdna:6]

[0001564590-21-025123:mdna:7]
We ended the first quarter of 2021 with a year-over-year revenue increase of 11.4%, driven by increased shipments to regional service providers in the U.S., alternative network operators in Europe and initial sales to a European Tier-1 operator. During the first quarter of 2021, we had two 10% revenue customers, both of which were domestic distributors. Our year-over-year domestic revenue growth of 9.5% was driven by growth in both Tier-2 and Tier-3 carrier categories due to additional fiber access deployments in both access equipment and CPE as well as a certain U.S.-based MSO. Internationally, our revenue increased by 15.5% compared to the prior year period, primarily driven by access network builds in the Asia Pacific region, with a focus on Australia, increased shipments to alternative network operators in Europe and initial sales to a European Tier-1 operator. Additionally, fiber access continued to experience revenue growth, and, during the first quarter of 2021, we announced multiple long-term Tier-1 next-generation fiber access deals in Europe and the U.S., positioning us well for the next access network upgrade investment cycle.

[0001564590-21-025123:mdna:8]
In March 2020, the World Health Organization declared the outbreak of COVID-19 a pandemic. During the twelve months ended December 31, 2020, there was a downturn in the global financial markets followed by a gradual rebound and a slowdown in the global economy due to the COVID-19 pandemic. COVID-19 continues to spread throughout the U.S. and the world and has resulted in authorities implementing numerous measures to contain the virus, including travel bans and restrictions, quarantines, shelter-in-place orders, and business limitations and shutdowns. While we are unable to accurately predict the full impact that COVID-19 will have on our results of operations, financial condition, liquidity and cash flows due to numerous uncertainties, including the duration and severity of the pandemic and containment measures, our compliance with these measures has impacted our day-to-day operations and could disrupt our business and operations, as well as that of our key customers, suppliers and other counterparties, for an indefinite period of time. We have experienced some impact to our supply chain, including a slowdown in supply chain deliveries, extended lead times on some key components and some raw material cost increases. We have also had to increase our volume of inventory to ensure supply continuity during the pandemic. In addition, we have experienced significant increases in freight-related costs. While throughout the pandemic, we have seen increased demand in networking requirements and utilization due to social distancing guidelines issued by governments, as well as COVID-19 related reductions in travel and infrastructure expenses, it is possible that we could experience some slowdown in demand and further supply chain issues as the pandemic continues. Even after the COVID-19 pandemic has subsided, we may continue to experience adverse impacts to our business as a result of any economic recession that has occurred or may occur in the future.

[0001564590-21-025123:mdna:9]
Among our customers, we made progress with our fiber, fiber-extension, in-home service delivery platforms and cloud services while also continuing to engage in value-added service opportunities that we expect will contribute to sales over the remainder of 2021 and beyond. In addition, we believe that we are at the beginning of a significant investment cycle for fiber deployment and in-home Wi-Fi connectivity driven by technology advancements and regulatory influences. The transition to next-generation network architectures is beginning, and we are seeing demand for our next-generation fiber access and connected home solutions. In 2021, we anticipate that payments to service providers under government funding programs such as the FCC RDOF will begin.

[0001564590-21-025123:mdna:10]
[same as prior period, unchanged from 0001564590-20-052017:mdna:10]

[0001564590-21-025123:mdna:11]
Our Access & Aggregation platforms are used by CSPs to connect their network infrastructure to subscribers. This revenue category includes hardware- and software-based products and services that aggregate and/or originate access technologies. ADTRAN solutions within this category include a wide array of modular or fixed platforms designed to deliver the best technology and economy based on subscriber density and environmental conditions.

[0001564590-21-025123:mdna:12]
[same as prior period, unchanged from 0001564590-20-052017:mdna:12]

[0001564590-21-025123:mdna:13]
[same as prior period, unchanged from 0001564590-20-052017:mdna:13]

[0001564590-21-025123:mdna:14]
Our operating results have fluctuated, and may continue to fluctuate, on a quarterly basis due to a number of factors, including customer order activity and backlog. A substantial portion of our shipments in any fiscal period relates to orders received and shipped within that fiscal period for customers under agreements containing non-binding purchase commitments. Further, a significant percentage of orders require delivery within a few days. These factors normally result in a varying order backlog and limited order flow visibility. Additionally, backlog levels may vary because of seasonal trends, the timing of customer projects and other factors that affect customer order lead times. Because many of our customers require prompt delivery of products, we are required to maintain sufficient inventory levels to satisfy anticipated customer demand. If near-term demand for our products declines, or if potential sales in any quarter do not occur as anticipated, our financial results could be adversely affected. Operating expenses are relatively fixed in the short term; therefore, a shortfall in quarterly revenues could significantly impact our financial results in a given quarter.

[0001564590-21-025123:mdna:15]
Our operating results may also fluctuate as a result of a number of other factors, including a decline in general economic and market conditions, specifically the decline that has resulted from the COVID-19 pandemic, foreign currency exchange rate movements, increased competition, customer order patterns, changes in product and services mix, timing differences between price decreases and product cost reductions, product warranty returns, expediting costs, tariffs and announcements of new products by us or our competitors. Additionally, maintaining sufficient inventory levels to assure prompt delivery of our products increases the amount of inventory that may become obsolete and increases the risk that the obsolescence of this inventory may have an adverse effect on our business and operating results. Also, not maintaining sufficient inventory levels to assure prompt delivery of our products may cause us to incur expediting costs to meet customer delivery requirements, which may negatively impact our operating results in a given quarter. In recent years, the Company initiated restructuring plans to realign its expense structure with the reduction in revenue experienced and with overall Company objectives. Management assessed the efficiency of our operations and consolidated locations and personnel, among other things, and implemented certain cost savings initiatives, where possible. See Note 20 of the Notes to Condensed Consolidated Financial Statements included in Part 1, Item 1 of this report for additional information on this restructuring.

[0001564590-21-025123:mdna:16]
Our historical financial performance is not necessarily a meaningful indicator of future results, and in general, management expects that our financial results may vary from period to period. Factors that could materially affect our business, financial condition or operating results are included in Part I, Item 1A of the 2020 Form 10-K.

[0001564590-21-025123:mdna:17]
[same as prior period, unchanged from 0001564590-20-052017:mdna:17]

[0001564590-21-025123:mdna:18]
There have been no material changes to our critical accounting policies and estimates from those disclosed in our 2020 Form 10-K.

[0001564590-21-025123:mdna:19]
[same as prior period, unchanged from 0001564590-20-052017:mdna:19]

[0001564590-21-025123:mdna:20]
See Note 1 of the Notes to Condensed Consolidated Financial Statements included in Part 1, Item 1 of this report for a full description of recent accounting pronouncements, including the expected dates of adoption and estimated effects on results of operations and financial condition, which is incorporated herein by reference.

[0001564590-21-025123:mdna:21]
30

[0001564590-21-025123:mdna:22]
RESULTS OF OPERATIONS – THREE MONTHS ENDED MARCH 31, 2021 COMPARED TO THREE MONTHS ENDED MARCH 31, 2020

[0001564590-21-025123:mdna:23]
The following table presents selected financial information derived from our Condensed Consolidated Statements of Income (Loss) expressed as a percentage of revenue for the periods indicated. Amounts may not foot due to rounding.

[0001564590-21-025123:mdna:24]
|  |  | Three Months Ended |  |  |
|  |  | March 31, |  |  |
|  |  | 2021 |  |  | 2020 |  |  |
| Revenue |  |  |  |  |  |  |  |  |  |
| Network Solutions |  |  | 89.2 |  | % |  | 85.0 |  | % |
| Services & Support |  |  | 10.8 |  |  |  | 15.0 |  |  |
| Total Revenue |  |  | 100.0 |  |  |  | 100.0 |  |  |
| Cost of Revenue |  |  |  |  |  |  |  |  |  |
| Network Solutions |  |  | 51.0 |  |  |  | 45.1 |  |  |
| Services & Support |  |  | 7.0 |  |  |  | 9.9 |  |  |
| Total Cost of Revenue |  |  | 58.0 |  |  |  | 54.9 |  |  |
| Gross Profit |  |  | 42.0 |  |  |  | 45.1 |  |  |
| Selling, general and administrative expenses |  |  | 21.5 |  |  |  | 23.2 |  |  |
| Research and development expenses |  |  | 21.6 |  |  |  | 26.1 |  |  |
| Asset impairments |  |  | — |  |  |  | — |  |  |
| Operating Loss |  |  | (1.0 | ) |  |  | (4.3 | ) |  |
| Interest and dividend income |  |  | 0.2 |  |  |  | 0.3 |  |  |
| Interest expense |  |  | — |  |  |  | — |  |  |
| Net investment gain (loss) |  |  | 0.8 |  |  |  | (9.5 | ) |  |
| Other income, net |  |  | 1.6 |  |  |  | 1.0 |  |  |
| Income (Loss) Before Income Taxes |  |  | 1.5 |  |  |  | (12.5 | ) |  |
| Income tax (expense) benefit |  |  | (0.8 | ) |  |  | 3.8 |  |  |
| Net Income (Loss) |  |  | 0.7 |  | % |  | (8.7 | ) | % |

[0001564590-21-025123:mdna:25]
REVENUE

[0001564590-21-025123:mdna:26]
Our revenue increased 11.4% from $114.5 million for the three months ended March 31, 2020 to $127.5 million for the three months ended March 31, 2021. The increase in revenue for the three months ended March 31, 2021 was primarily attributable to a $12.4 million increase in Subscriber Solutions & Experience revenue and a $3.1 million increase in Access & Aggregation revenue partially offset by a $2.5 million decrease in revenue of our Traditional & Other Products.

[0001564590-21-025123:mdna:27]
Network Solutions segment revenue increased 16.9% from $97.4 million for the three months ended March 31, 2020 to $113.8 million for the three months ended March 31, 2021. The increase in revenue for the three months ended March 31, 2021 was due primarily to sales of Subscriber Solutions & Experience and Access & Aggregation products. The increase in Subscriber Solutions & Experience revenue for the three months ended March 31, 2021 was primarily attributable to increased volume of network termination and Fiber CPE. The increase in the Access & Aggregation category for the three months ended March 31, 2021 was due to increased volume of fiber access and residential gateways. While we expect that revenue from Traditional & Other Products will decline over time, this revenue may fluctuate and continue for years because of the time required for our customers to transition to newer technologies.

[0001564590-21-025123:mdna:28]
Services & Support segment revenue decreased 20.0% from $17.2 million for the three months ended March 31, 2020 to $13.7 million for the three months ended March 31, 2021. The decrease in revenue for the three months ended March 31, 2021 was primarily attributable to a decrease in network planning and implementation services for Access & Aggregation products.

[0001564590-21-025123:mdna:29]
International revenue, which are included in the amounts for both the Network Solutions and Services & Support segments discussed above, increased 15.5% from $35.5 million for the three months ended March 31, 2020 to $41.0 million for the three months ended March 31, 2021. International revenue, as a percentage of total revenue, increased from 31.0% for the three months ended March 31, 2020 to 32.2% for the three months ended March 31, 2021. The increase in revenue for the three months ended March 31, 2021, was primarily driven by access network builds in the Asia Pacific region, with a focus on Australia, increased shipments to alternative network operators in Europe and initial sales to a European Tier-1 operator.

[0001564590-21-025123:mdna:30]
Our international revenue is largely focused on broadband infrastructure and is affected by the decisions of our customers as to timing for installation of new technologies, expansion of their networks and/or network upgrades. Our international customers must make these decisions in the regulatory and political environment in which they operate – both nationally and in some instances, regionally – whether of a multi-country region or a more local region within a country. The competitive landscape in certain international markets is also affected by the increased presence of Asian manufacturers that seek to compete aggressively on price. Our revenue and operating income in some international markets can be negatively impacted by a strengthening U.S. dollar. Consequently, while we expect the global trend towards deployment of more robust broadband speeds and access to continue creating additional market opportunities for us, the factors described above may result in negative pressure on revenue and operating income.

[0001564590-21-025123:mdna:31]
COST OF REVENUE

[0001564590-21-025123:mdna:32]
As a percentage of revenue, cost of revenue increased from 54.9% for the three months ended March 31, 2020 to 58.0% for the three months ended March 31, 2021. The increase was primarily attributable to changes in customer and product mix, a regional revenue shift and the negative impact of supply constraints.

[0001564590-21-025123:mdna:33]
Network Solutions cost of revenue, as a percentage of that segment’s revenue, increased from 53.0% for the three months ended March 31, 2020 to 57.1% for the three months ended March 31, 2021. The increase in cost of revenue as a percentage of revenue for the three months ended March 31, 2021 was primarily attributable to changes in customer and product mix, a regional revenue shift and the negative impact of supply constraints.

[0001564590-21-025123:mdna:34]
[same as prior period, unchanged from 0001564590-20-052017:mdna:34]

[0001564590-21-025123:mdna:35]
Services & Support cost of revenue, as a percentage of that segment’s revenue, decreased slightly from 65.9% for the three months ended March 31, 2020 to 65.1% for the three months ended March 31, 2021. The decrease in cost of revenue as a percentage of revenue for the three months ended March 31, 2021 was primarily attributable to customer mix and changes in services and support mix.

[0001564590-21-025123:mdna:36]
[same as prior period, unchanged from 0001564590-20-052017:mdna:36]

[0001564590-21-025123:mdna:37]
As our network planning and implementation revenue grew to become a larger component of our Services & Support segment business, our Services & Support segment gross margins decreased versus those reported when maintenance and support comprised the majority of the business. Further, because the growth in our network planning and implementation services has resulted in our Services & Support segment revenue comprising a larger percentage of our overall revenue, and because our Services & Support segment gross margins are generally below those of the Network Solutions segment, our overall corporate gross margins have declined as that business has continued to grow. Within the Services & Support segment, we do expect variability in gross margins from quarter-to-quarter based on the mix of the services recognized.

[0001564590-21-025123:mdna:38]
[same as prior period, unchanged from 0001564590-20-052017:mdna:38]

[0001564590-21-025123:mdna:39]
As a percentage of revenue, selling, general and administrative expenses decreased from 23.2% for the three months ended March 31, 2020 to 21.5% for the three months ended March 31, 2021. Selling, general and administrative expenses as a percentage of revenue will generally fluctuate whenever there is a significant fluctuation in revenue for the periods being compared.

[0001564590-21-025123:mdna:40]
Selling, general and administrative expenses increased 3.1% from $26.6 million for the three months ended March 31, 2020 to $27.4 million for the three months ended March 31, 2021. The increase in selling, general and administrative expenses for the three months ended March 31, 2021 was primarily attributable to increased deferred compensation related costs, partially offset by decreases in travel related expense and the capitalization of certain costs related to our ongoing enterprise resource planning implementation project.

[0001564590-21-025123:mdna:41]
[same as prior period, unchanged from 0001564590-20-052017:mdna:41]

[0001564590-21-025123:mdna:42]
As a percentage of revenue, research and development expenses decreased from 26.1% for the three months ended March 31, 2020 to 21.6% for the three months ended March 31, 2021. Research and development expenses as a percentage of revenue will fluctuate whenever there are incremental product development activities or significant fluctuations in revenue for the periods being compared as these costs are relatively fixed in the short term.

[0001564590-21-025123:mdna:43]
Research and development expenses decreased 7.9% from $29.9 million for the three months ended March 31, 2020 to $27.5 million for the three months ended March 31, 2021. The decrease in research and development expenses for the three months ended March 31, 2021 was primarily attributable to lower personnel costs which were mainly the result of our restructuring programs, lower travel related costs and lower project related expenses, partially offset by increased contract services.

[0001564590-21-025123:mdna:44]
We expect to continue to incur research and development expenses in connection with our new and existing products and our continued expansion into international markets. We continually evaluate new product opportunities and engage in significant research and product development efforts, which provides for new product development, enhancement of existing products and product cost reductions. We may incur significant research and development expenses prior to the receipt of revenue from a major new product group.

[0001564590-21-025123:mdna:45]
[same as prior period, unchanged from 0001564590-20-052017:mdna:45]

[0001564590-21-025123:mdna:46]
Asset impairments, which were $0.1 million for the three months ended March 31, 2020, related to the abandonment of certain information technology projects in which we had previously capitalized costs. There were no asset impairments recognized during the three months ended March 31, 2021.

[0001564590-21-025123:mdna:47]
[same as prior period, unchanged from 0001564590-20-052017:mdna:49]

[0001564590-21-025123:mdna:48]
Interest and dividend income decreased 18.5% from $0.4 million for the three months ended March 31, 2020 to $0.3 million for the three months ended March 31, 2021. The decrease in interest and dividend income was primarily attributable to a decrease in the rate of return on our investments due to lower interest rates.

[0001564590-21-025123:mdna:49]
[same as prior period, unchanged from 0001564590-20-052017:mdna:51]

[0001564590-21-025123:mdna:50]
Interest expense was less than $0.1 million for each of the three months ended March 31, 2021 and 2020. Interest expense during the first quarter of 2021 was primarily related to our Revolving Credit Agreement that we entered into during the fourth quarter of 2020.  Interest expect during the first quarter of 2020 was primarily related to certain taxable revenue bonds.

[0001564590-21-025123:mdna:51]
[same as prior period, unchanged from 0001564590-20-052017:mdna:53]

[0001564590-21-025123:mdna:52]
We recognized a net investment loss of $10.9 million for the three months ended March 31, 2020 and a net investment gain of $1.0 million for the three months ended March 31, 2021. The fluctuations in our net investments were primarily attributable to changes in the fair value of our securities recognized during the period. We expect that any future market volatility, whether from COVID-19 or other factors, will result in continued volatility in our investment portfolio. See Note 7 of the Notes to Condensed Consolidated Financial Statements, included in Part I, Item 1 of this report, and “Investing Activities” in “Liquidity and Capital Resources” below for additional information.

[0001564590-21-025123:mdna:53]
OTHER INCOME, NET

[0001564590-21-025123:mdna:54]
Other income, net which consisted mainly of gains and losses on foreign currency transactions, increased from income of $1.1 million for the three months ended March 31, 2020 to income of $2.0 million for the three months ended March 31, 2021.

[0001564590-21-025123:mdna:55]
[same as prior period, unchanged from 0001564590-20-052017:mdna:57]

[0001564590-21-025123:mdna:56]
Our effective tax rate increased from a benefit of 30.5% for the three months ended March 31, 2020 to an expense of 53.9% for the three months ended March 31, 2021. The increase in the effective tax rate was primarily driven by a tax benefit of $7.4 million recognized during the three months March 31, 2020 as a result of the enactment of the CARES Act in March 2020. See Note 4 of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this report for additional information.

[0001564590-21-025123:mdna:57]
[same as prior period, unchanged from 0001564590-20-052017:mdna:59]

[0001564590-21-025123:mdna:58]
As a result of the above factors, net income (loss) increased from a net loss of $10.0 million for the three months ended March 31, 2020 to net income of $0.9 million for the three months ended March 31, 2021.

[0001564590-21-025123:mdna:59]
[same as prior period, unchanged from 0001564590-20-052017:mdna:61]

[0001564590-21-025123:mdna:60]
[same as prior period, unchanged from 0001564590-20-052017:mdna:62]

[0001564590-21-025123:mdna:61]
We have historically financed, and we currently expect to continue to finance, our ongoing business with existing cash, investments and cash flow from operations. We have used, and expect to continue to use, existing cash, investments and cash generated from operations for working capital, business acquisitions, purchases of treasury stock, shareholder dividends and other general corporate purposes, including product development activities to enhance our existing products and develop new products, expansion of our sales and marketing activities, and capital expenditures. We believe our cash and cash equivalents, investments and cash generated from operations to be adequate to meet our operating and capital needs for at least the next 12 months.

[0001564590-21-025123:mdna:62]
As of March 31, 2021, cash on hand was $63.8 million and short-term investments were $4.1 million, which resulted in available short-term liquidity of $67.9 million, of which $51.0 million was held by our foreign subsidiaries. As of December 31, 2020, cash on hand was $60.2 million and short-term investments were $3.1 million, which resulted in available short-term liquidity of $63.3 million, of which $49.7 million was held by our foreign subsidiaries.

[0001564590-21-025123:mdna:63]
During the fourth quarter of 2020, the Company entered into a Revolving Credit and Security Agreement and related Promissory Note (together, the “Revolving Credit Agreement”) with Cadence Bank, N.A., as lender (the “Lender”). The Revolving Credit Agreement provides the Company with a new $10.0 million secured revolving credit facility. Loans under the Revolving Credit Agreement will bear interest at a rate equal to 1.50% over the screen rate as obtained by Reuter’s, Bloomberg or another commercially available source as may be designated by the Lender from time to time; provided, however, that in no event shall the applicable rate of interest under the Revolving Credit Agreement be less than 1.50% per annum. Such loans are secured by all of the cash, securities, securities entitlements and investment property in a certain bank account, as outlined in the Revolving Credit Agreement, at a maximum loan-to-value ratio of 75% determined by dividing the full commitment amount under the Revolving Credit Agreement on the date of testing, determined by the Lender each fiscal quarter, by the market value of the collateral. Based on the market value of the collateral at March 31, 2021, the Company had approximately $10.0 million of loan availability under the revolving credit facility as of such date. The Revolving Credit Agreement matures on November 4, 2021, subject to earlier termination upon the occurrence of certain events of default. The Company entered into the Revolving Credit Agreement in order to increase the flexibility and management of its short-term liquidity. To date, the Company has not made any draws under the Revolving Credit Agreement. The Company agreed to certain negative covenants that are customary for credit arrangements of this type, including, among other things, restrictions on the Company’s ability to enter into mergers, acquisitions or other business combination transactions, grant liens or suffer a material adverse change in the condition or affairs (financial or otherwise) of the Company, which negative covenants are subject to certain exceptions. The Company must be in compliance with all covenants to be able to draw on the line of credit. As of March 31, 2021, the Company was in compliance with all covenants.

[0001564590-21-025123:mdna:64]
[same as prior period, unchanged from 0001564590-20-052017:mdna:66]

[0001564590-21-025123:mdna:65]
Our working capital, defined as current assets less current liabilities, decreased 0.5% from $223.2 million as of December 31, 2020 to $222.2 million as of March 31, 2021, and our current ratio, defined as current assets divided by current liabilities, decreased from 3.37 as of December 31, 2020 to 3.18 as of March 31, 2021. The decrease in our working capital and current ratio were primarily attributable to an increase in accounts payable and decrease in inventory, partially offset by increases in accounts receivable, cash and cash equivalents and other receivables. The quick ratio, defined as cash, cash equivalents, short-term investments, and net accounts receivable, divided by current liabilities, decreased from 1.72 as of December 31, 2020 to 1.67 as of March 31, 2021. The decrease in the quick ratio was primarily attributable to an increase in accounts payable, partially offset by increases in accounts receivable, cash and cash equivalents and other receivables.

[0001564590-21-025123:mdna:66]
Net accounts receivable increased 4.4% from $98.8 million as of December 31, 2020 to $103.2 million as of March 31, 2021. The increase in net accounts receivable was due to an increase in sales volume and timing of shipments within the quarter. Quarterly accounts receivable DSO increased from 70 days as of December 31, 2020 to 73 days as of March 31, 2021. The increase in DSO was due to the timing of product shipments and customer mix.

[0001564590-21-025123:mdna:67]
Other receivables increased 5.3% from $21.5 million as of December 31, 2020 to $22.7 million as of March 31, 2021. The increase in other receivables was primarily attributable to an increase in contract manufacturer purchases and contract assets partially offset by a decrease in tax receivables.

[0001564590-21-025123:mdna:68]
Quarterly inventory turnover decreased from 2.5 turns as of December 31, 2020 to 2.4 turns as of March 31, 2021. Inventory decreased 2.1% from $125.5 million as of December 31, 2020 to $122.9 million as of March 31, 2021. Barring COVID-19 uncertainties related to supply chain and demand, we expect inventory levels to fluctuate as we attempt to maintain sufficient inventory in response to seasonal cycles of our business and ensuring competitive lead times while managing the risk of inventory.

[0001564590-21-025123:mdna:69]
Accounts payable increased 11.1% from $49.9 million as of December 31, 2020 to $55.5 million as of March 31, 2021. Accounts payable will fluctuate due to variations in the timing of the receipt of supplies, inventory and services and our subsequent payments for these purchases.

[0001564590-21-025123:mdna:70]
[same as prior period, unchanged from 0001564590-20-052017:mdna:72]

[0001564590-21-025123:mdna:71]
Capital expenditures totaled approximately $0.7 million and $1.4 million for the three months ended March 31, 2021 and 2020, respectively. These expenditures were primarily used to purchase manufacturing and test equipment, software, computer hardware and to finance building improvements.

[0001564590-21-025123:mdna:72]
Our combined short-term and long-term investments increased $2.1 million from $83.3 million as of December 31, 2020 to $85.4 million as of March 31, 2021. This increase reflects the impact of net realized and unrealized gains and losses on our investments.

[0001564590-21-025123:mdna:73]
We typically invest all available cash not required for immediate use in operations, primarily in securities that we believe bear minimal risk of loss. See Note 7 of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this report for additional information. As of March 31, 2021, investments were classified as available-for-sale and had a combined duration of 1.70 years with an average Standard & Poor’s credit rating of AA-. Because our investment portfolio has a high-quality rating and contractual maturities of short duration, we are able to obtain prices for these bonds derived from observable market inputs, or for similar securities traded in an active market, on a daily basis.

[0001564590-21-025123:mdna:74]
Our long-term investments increased 1.4% from $80.1 million as of December 31, 2020 to $81.3 million as of March 31, 2021.  Our investments include various marketable equity securities classified as long-term investments with a fair market value of $11.5 million and $11.0 million, as of March 31, 2021 and December 31, 2020, respectively. Long-term investments as of March 31, 2021 and December 31, 2020 also included $24.4 million and $23.9 million, respectively, related to our deferred compensation plans, and $0.2 million for both years, of other investments, consisting of interests in a private equity fund.

[0001564590-21-025123:mdna:75]
[same as prior period, unchanged from 0001564590-20-052017:mdna:77]

[0001564590-21-025123:mdna:76]
[same as prior period, unchanged from 0001564590-20-052017:mdna:78]

[0001564590-21-025123:mdna:77]
In July 2003, our Board of Directors elected to begin declaring quarterly dividends on our common stock considering the tax treatment of dividends and adequate levels of Company liquidity. During the three months ended March 31, 2021 and 2020, we paid dividends totaling $4.4 million and $4.3 million, respectively. The continued payment of dividends is at the discretion of the Company’s Board of Directors and is subject to general business conditions and ongoing financial results of the Company.

[0001564590-21-025123:mdna:78]
Stock Option Exercises

[0001564590-21-025123:mdna:79]
To accommodate employee stock option exercises, the Company issued 0.1 million shares of treasury stock which resulted in proceeds of $1.2 million during the three months ended March 31, 2021. No stock options were exercised during the three months ended March 31, 2020.

[0001564590-21-025123:mdna:80]
[same as prior period, unchanged from 0001564590-20-052017:mdna:84]

[0001564590-21-025123:mdna:81]
We do not have off-balance sheet financing arrangements and have not engaged in any related party transactions or arrangements with unconsolidated entities or other persons that are reasonably likely to materially affect liquidity or the availability of or requirements for capital resources.

[0001564590-21-025123:mdna:82]
[same as prior period, unchanged from 0001564590-20-052017:mdna:86]

[0001564590-21-025123:mdna:83]
Certain contracts, customers and jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of March 31, 2021 and December 31, 2020, we had commitments related to these bonds totaling $21.2 million and $15.2 million, respectively, which expire at various dates through August 2024. Although the triggering events vary from contract to contract, in general we would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which we believe is remote.

[0001564590-21-025123:mdna:84]
In June 2020, the Company entered into a letter of credit with a bank to guarantee performance obligations under a contract with a certain customer. The obligations under this customer contract will be performed over multiple years. We reached the maximum value of our minimum collateral requirement of $15.0 million during the three months ended March 31, 2021, as the Company reached certain milestones through the first quarter of 2021 as outlined in the customer contract. The letter of credit was secured by a pledge of a portion of the Company’s fixed-income securities, which totaled $18.2 million as of March 31, 2021, of which $0.1 million is included in restricted cash and $18.1 million is included in long-term investments on the Condensed Consolidated Balance Sheet. This pledged collateral value will fluctuate as the Company changes the mix of the pledged collateral between restricted cash and investments. Any shortfalls in the minimum collateral value are required to be restored by the Company from available cash and cash equivalents, short-term investments and/or long-term investments. The collateral under the letter of credit will be released when all obligations under the customer contract have been met. As of March 31, 2021, the Company was in compliance with all contractual requirements under the letter of credit.

[0001564590-21-025123:mdna:85]
We have committed to invest up to an aggregate of $5.0 million in a private equity fund, of which $4.9 million has been applied as of March 31, 2021.

[0001564590-21-025123:mdna:86]
Other than as described above, during the three months ended March 31, 2021, there have been no material changes in contractual obligations and commercial commitments from those discussed in the 2020 Form 10-K.
