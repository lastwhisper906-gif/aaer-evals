# ADTN notes — 0001564590-21-025123


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001564590-21-025123:notes:1]
[same as prior period, unchanged from 0001564590-20-052017:notes:1]

[0001564590-21-025123:notes:2]
[same as prior period, unchanged from 0001564590-20-052017:notes:2]

[0001564590-21-025123:notes:3]
The accompanying unaudited condensed consolidated financial statements of ADTRAN®, Inc. and its subsidiaries (“ADTRAN”, the “Company”, “we”, “our” or “us”) have been prepared pursuant to the rules and regulations of the Securities and Exchange Commission (the “SEC”) applicable to interim financial information presented in Quarterly Reports on Form 10-Q. Accordingly, certain information and notes required by generally accepted accounting principles in the United States of America (“U.S. GAAP”) for complete financial statements are not included herein. The December 31, 2020 Condensed Consolidated Balance Sheet is derived from audited financial statements but does not include all disclosures required by U.S. GAAP.

[0001564590-21-025123:notes:4]
In the opinion of management, all adjustments necessary to fairly state these interim statements have been recorded and are of a normal and recurring nature. The results of operations for an interim period are not necessarily indicative of the results for the full year. The interim financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in ADTRAN’s Annual Report on Form 10-K for the year ended December 31, 2020, filed with the SEC on February 26, 2021.

[0001564590-21-025123:notes:5]
[same as prior period, unchanged from 0001564590-20-052017:notes:5]

[0001564590-21-025123:notes:6]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenue and expense during the reporting period. The more significant estimates include excess and obsolete inventory reserves, warranty reserves, customer rebates, determination and accrual of deferred revenue components of multiple element sales agreements, estimated costs to complete obligations associated with deferred and accrued revenues and network installations, estimated income tax provision and income tax contingencies, fair value of stock-based compensation, assessment of goodwill and other intangibles for impairment, estimated lives of intangible assets, estimated pension, and liability and fair value of investments, evaluation of other-than-temporary declines in the value of investments and the allowance for current expected credit losses. Actual amounts could differ significantly from these estimates.

[0001564590-21-025123:notes:7]
We assessed certain accounting matters that generally require consideration of forecasted financial information in context with the information reasonably available to us and the unknown future impacts of the novel coronavirus (“COVID-19”) as of March 31, 2021 and through the date of this report. The accounting matters assessed included, but were not limited to, the allowance for doubtful accounts, stock-based compensation, carrying value of goodwill, intangibles and other long-lived assets, financial assets, valuation allowances for tax assets and revenue recognition. While there was not a material impact to our consolidated financial statements as of and for the quarter ended March 31, 2021 resulting from these assessments, future assessments related to the COVID-19 pandemic, as well as other factors, could result in material impacts to our consolidated financial statements in future reporting periods.

[0001564590-21-025123:notes:8]
Correction of an Immaterial Misstatement

[0001564590-21-025123:notes:9]
During the three months ended March 31, 2020, it was determined that certain investments held in the Company’s stock for a deferred compensation plan accounted for as a Rabbi trust were incorrectly classified as Long-term investments with the fair value of such investments incorrectly marked to market at each period end rather than classified as Treasury stock held at historical cost. This plan has been in existence since 2011. The Company corrected this misstatement as an out-of-period adjustment in the three months ended March 31, 2020 by remeasuring the investment assets to their historical cost basis through the recording of a Net investment gain of $1.5 million in the unaudited Condensed Consolidated Statement of Income (Loss) and then correcting the classification by decreasing the Long-term investment balance at its remeasured cost basis of $2.8 million to Treasury stock in the unaudited Condensed Consolidated Balance Sheet as of March 31, 2020. Management has determined that this misstatement was not material to any of its previously issued financial statements and that the correction of the misstatement was not material to the Company’s 2020 annual financial results on either a quantitative or qualitative basis.

[0001564590-21-025123:notes:10]
Recently Adopted Accounting Pronouncements

[0001564590-21-025123:notes:11]
We recently adopted the following accounting standards, which had the following impacts on our consolidated financial statements:

[0001564590-21-025123:notes:12]
In August 2018, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2018-14, Compensation – Retirement Benefits – Defined Benefit Plans – General (Subtopic 715-20): Disclosure Framework – Changes to the Disclosure Requirements for Defined Benefit Plans, which makes changes to and clarifies the disclosure requirements related to defined benefit pension and other postretirement plans. ASU 2018-14 requires additional disclosures related to the reasons for significant gains and losses affecting the benefit obligation and an explanation of any other significant changes in the benefit obligation or plan assets that are not otherwise apparent in other disclosures required by Accounting Standards Codification (“ASC”) 715. ASU 2018-14 also clarifies the guidance in ASC 715 to require disclosure of the projected benefit obligation (“PBO”) and fair value of plan assets for pension plans with PBOs in excess of plan assets and the accumulated benefit obligation (“ABO”) and fair value of plan assets for pension plans with ABOs in excess of plan assets. ASU 2018-14 became effective for public business entities for fiscal years ending after December 15, 2020. The adoption of this standard did not have a material effect on the disclosures in the condensed consolidation financial statements.

[0001564590-21-025123:notes:13]
In December 2019, the FASB issued ASU 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes, which simplifies the accounting for income taxes by removing various exceptions, such as the exception to the incremental approach for intra-period tax allocation when there is a loss from continuing operations and income or a gain from other items. The amendments in this update also simplify the accounting for income taxes related to income-based franchise taxes and require that an entity reflect enacted tax laws or rates in the annual effective tax rate computation in the interim period that includes the enactment date. The Company early adopted ASU 2019-12 on April 1, 2020, which was applied on a prospective basis as if the Company adopted the standard on January 1, 2020. The Company early adopted the standard to take advantage of the simplification of rules for income taxes on intra-period tax allocations. Specifically, the adoption of this standard resulted in the recognition of approximately $0.1 million of tax benefit in other comprehensive income (loss) for the three months ended March 31, 2020, that otherwise would have been recognized in continuing operations had the intra-period tax allocation been completed. There were no other impacts from this standard on the Condensed Consolidated Balance Sheets, Condensed Consolidated Statements of Income (Loss) or Condensed Consolidated Statements of Cash Flows.

[0001564590-21-025123:notes:14]
[same as prior period, unchanged from 0001564590-20-052017:notes:25]

[0001564590-21-025123:notes:15]
There are currently no recent accounting pronouncements that have not yet been adopted and that would have a material effect, once adopted, on the Condensed Consolidated Balance Sheets, Condensed Consolidated Statements of Income (Loss) or Condensed Consolidated Statements of Cash Flows.


## us-gaap:CashAndCashEquivalentsDisclosureTextBlock

[0001564590-21-025123:notes:16]
[same as prior period, unchanged from 0001564590-20-052017:notes:27]

[0001564590-21-025123:notes:17]
The following table provides a reconciliation of cash, cash equivalents and restricted cash reported within the Condensed Consolidated Balance Sheets that sum to the total of the same such amounts shown in the Condensed Consolidated Statements of Cash Flows:

[0001564590-21-025123:notes:18]
| (In thousands) |  | As of March 31, 2021 |  |  | As of December 31, 2020 |  |
| Cash and cash equivalents |  | $ | 63,777 |  |  | $ | 60,161 |  |
| Restricted cash |  |  | 119 |  |  |  | 18 |  |
| Cash, cash equivalents and restricted cash |  | $ | 63,896 |  |  | $ | 60,179 |  |

[0001564590-21-025123:notes:19]
See Note 19 for additional information regarding restricted cash.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001564590-21-025123:notes:20]
[same as prior period, unchanged from 0001564590-20-052017:notes:32]

[0001564590-21-025123:notes:21]
[same as prior period, unchanged from 0001564590-20-052017:notes:33]

[0001564590-21-025123:notes:22]
Network Solutions Segment - Includes hardware products and software-defined next-generation virtualized solutions used in service provider or business networks, as well as prior generation products.

[0001564590-21-025123:notes:23]
Services & Support Segment - Includes maintenance, network implementation, solutions integration and managed services, which include hosted cloud services and subscription services.

[0001564590-21-025123:notes:24]
See Note 17 for additional information on reportable segments.

[0001564590-21-025123:notes:25]
Revenue by Category

[0001564590-21-025123:notes:26]
In addition to our reporting segments, revenue is also reported for the following three categories – Access & Aggregation, Subscriber Solutions & Experience and Traditional & Other Products.

[0001564590-21-025123:notes:27]
The following table disaggregates revenue by reportable segment and revenue category:

[0001564590-21-025123:notes:28]
|  |  | For the Three Months Ended |  |
|  |  | March 31, 2021 |  |  | March 31, 2020 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 60,053 |  |  | $ | 9,021 |  |  | $ | 69,074 |  |  | $ | 53,055 |  |  | $ | 12,911 |  |  | $ | 65,966 |  |
| Subscriber Solutions & Experience |  |  | 52,269 |  |  |  | 2,300 |  |  |  | 54,569 |  |  |  | 39,983 |  |  |  | 2,196 |  |  |  | 42,179 |  |
| Traditional & Other Products |  |  | 1,487 |  |  |  | 2,403 |  |  |  | 3,890 |  |  |  | 4,334 |  |  |  | 2,044 |  |  |  | 6,378 |  |
| Total |  | $ | 113,809 |  |  | $ | 13,724 |  |  | $ | 127,533 |  |  | $ | 97,372 |  |  | $ | 17,151 |  |  | $ | 114,523 |  |

[0001564590-21-025123:notes:29]
Revenue allocated to remaining performance obligations represents contract revenue that have not yet been recognized for contracts with a duration greater than one year. As of March 31, 2021, we did not have any significant performance obligations related to customer contracts that had an original expected duration of one year or more, other than maintenance services, which are satisfied over time. As a practical expedient, for certain contracts we recognize revenue equal to the amounts we are entitled to invoice which correspond to the value of completed performance obligations to date. The amount related to these performance obligations was $19.0 million and $17.7 million as of March 31, 2021 and December 31, 2020, respectively. The Company expects to recognize 63% of the $19.0 million as of March 31, 2021 over the next 12 months with the remainder to be recognized thereafter.

[0001564590-21-025123:notes:30]
[same as prior period, unchanged from 0001564590-20-052017:notes:42]

[0001564590-21-025123:notes:31]
| (In thousands) |  | As of March 31, 2021 |  |  | As of December 31, 2020 |  |
| Accounts receivable, net |  | $ | 103,201 |  |  | $ | 98,827 |  |
| Contract assets(1) |  | $ | 906 |  |  | $ | 63 |  |
| Unearned revenue |  | $ | 14,457 |  |  | $ | 14,092 |  |
| Non-current unearned revenue |  | $ | 7,040 |  |  | $ | 6,888 |  |

[0001564590-21-025123:notes:32]
[same as prior period, unchanged from 0001564590-20-052017:notes:44]

[0001564590-21-025123:notes:33]
Of the outstanding unearned revenue balances as of December 31, 2020, $5.0 million was recognized as revenue during the three months ended March 31, 2021.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0001564590-21-025123:notes:34]
The table below presents revenue information by category:

[0001564590-21-025123:notes:35]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2021 |  |  | 2020 |  |
| Access & Aggregation |  | $ | 69,074 |  |  | $ | 65,966 |  |
| Subscriber Solutions & Experience |  |  | 54,569 |  |  |  | 42,179 |  |
| Traditional & Other Products |  |  | 3,890 |  |  |  | 6,378 |  |
| Total Revenue |  | $ | 127,533 |  |  | $ | 114,523 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-21-025123:notes:36]
[same as prior period, unchanged from 0001564590-20-052017:notes:48]

[0001564590-21-025123:notes:37]
Our effective tax rate increased from a benefit of 30.5% for the three months ended March 31, 2020, to an expense of 53.9% for the three months ended March 31, 2021. The increase in the effective tax rate between the two periods was primarily driven by a tax benefit of $7.4 million recognized during the three months ended March 31, 2020 as a result of the passing of the Coronavirus Aid, Relief, and Economic Security Act (the “CARES Act”) on March 27, 2020, which allowed for the carryback of federal net operating losses, partially offset with tax expense in our international operations in the current quarter. Additionally, on February 12, 2021, the Alabama Business Tax Competitiveness Act was signed into law. As a result of the Act, we recognized an expense of $1.6 million related to the revaluation of our deferred tax assets, which was offset by changes in our valuation allowance previously recorded against our domestic deferred tax assets. The total increase in the valuation allowance against our domestic deferred tax assets was recorded in the amount of $2.7 million during the three months ended March 31, 2021.

[0001564590-21-025123:notes:38]
The Company continually reviews the adequacy of its valuation allowance and recognizes the benefits of deferred tax assets only as the reassessment indicates that it is more likely than not that the deferred tax assets will be recognized in accordance with ASC 740, Income Taxes. As of March 31, 2021, the Company had deferred tax assets totaling $58.0 million, and a valuation allowance totaling $48.5 million had been established against those deferred tax assets. The remaining $9.4 million in deferred tax assets not offset by a valuation allowance are located in various foreign jurisdictions where the Company believes it is more likely than not we will realize these deferred tax assets. Our assessment of the realizability of our deferred tax assets includes the evaluation of historical operating results as well as the evaluation of evidence which requires significant judgement, including the evaluation of our three-year cumulative income position, future taxable income projections and tax planning strategies. Should management’s conclusion change in the future and an additional valuation allowance or a partial or full release of the valuation allowance becomes necessary, it could have a material effect on our consolidated financial statements.

[0001564590-21-025123:notes:39]
Supplemental balance sheet information related to deferred tax assets is as follows:

[0001564590-21-025123:notes:40]
|  |  | As of March 31,2021 |  |
| (In thousands) |  | Deferred Tax Assets |  |  | Valuation Allowance |  |  | Deferred Tax Assets, net |  |
| Domestic |  | $ | 46,479 |  |  | $ | (46,479 | ) |  | $ | — |  |
| International |  |  | 11,473 |  |  |  | (2,025 | ) |  |  | 9,448 |  |
| Total |  | $ | 57,952 |  |  | $ | (48,504 | ) |  | $ | 9,448 |  |

[0001564590-21-025123:notes:41]
|  |  | As of December 31, 2020 |  |
| (In thousands) |  | Deferred Tax Assets |  |  | Valuation Allowance |  |  | Deferred Tax Assets, net |  |
| Domestic |  | $ | 43,791 |  |  | $ | (43,791 | ) |  | $ | — |  |
| International |  |  | 11,896 |  |  |  | (2,027 | ) |  |  | 9,869 |  |
| Total |  | $ | 55,687 |  |  | $ | (45,818 | ) |  | $ | 9,869 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001564590-21-025123:notes:42]
[same as prior period, unchanged from 0001564590-20-052017:notes:54]

[0001564590-21-025123:notes:43]
The following table summarizes the components of net periodic pension cost related to a defined benefit pension plan covering employees in certain foreign countries:

[0001564590-21-025123:notes:44]
|  |  | For the Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2021 |  |  | 2020 |  |
| Service cost |  | $ | 314 |  |  | $ | 310 |  |
| Interest cost |  |  | 87 |  |  |  | 108 |  |
| Expected return on plan assets |  |  | (471 | ) |  |  | (410 | ) |
| Amortization of actuarial losses |  |  | 278 |  |  |  | 237 |  |
| Net periodic pension cost |  | $ | 208 |  |  | $ | 245 |  |

[0001564590-21-025123:notes:45]
The components of net periodic pension cost, other than the service cost component, are included in other income (expense), net in the Condensed Consolidated Statements of Income (Loss). Service cost is included in cost of revenue, selling, general and administrative expenses and research and development expenses in the Condensed Consolidated Statements of Income (Loss).


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-21-025123:notes:46]
[same as prior period, unchanged from 0001564590-20-052017:notes:58]

[0001564590-21-025123:notes:47]
The following table summarizes stock-based compensation expense related to stock options, performance stock units (“PSUs”), restricted stock units (“RSUs”) and restricted stock:

[0001564590-21-025123:notes:48]
|  |  | For the Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2021 |  |  | 2020 |  |
| Stock-based compensation expense included in cost of revenue |  | $ | 131 |  |  | $ | 115 |  |
| Selling, general and administrative expense |  |  | 1,098 |  |  |  | 1,075 |  |
| Research and development expense |  |  | 578 |  |  |  | 601 |  |
| Stock-based compensation expense included in operating expenses |  |  | 1,676 |  |  |  | 1,676 |  |
| Total stock-based compensation expense |  |  | 1,807 |  |  |  | 1,791 |  |
| Tax benefit for expense associated with stock options, PSUs, RSUs and restricted stock |  |  | (431 | ) |  |  | (427 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 1,376 |  |  | $ | 1,364 |  |

[0001564590-21-025123:notes:49]
[same as prior period, unchanged from 0001564590-20-052017:notes:61]

[0001564590-21-025123:notes:50]
The following table summarizes PSUs, RSUs and restricted stock outstanding as of December 31, 2020 and March 31, 2021 and the changes that occurred during the three months ended March 31, 2021:

[0001564590-21-025123:notes:51]
|  |  | Number of Shares (in thousands) |  |  | Weighted Avg. Grant Date Fair Value (per share) |  |
| Unvested PSUs, RSUs and restricted stock outstanding, December 31, 2020 |  |  | 1,846 |  |  | $ | 11.49 |  |
| PSUs, RSUs and restricted stock granted |  |  | 354 |  |  | $ | 16.72 |  |
| PSUs, RSUs and restricted stock vested |  |  | (11 | ) |  | $ | 11.88 |  |
| PSUs, RSUs and restricted stock forfeited |  |  | (34 | ) |  | $ | 11.48 |  |
| Unvested PSUs, RSUs and restricted stock outstanding, March 31, 2021 |  |  | 2,155 |  |  | $ | 12.40 |  |

[0001564590-21-025123:notes:52]
During the three months ended March 31, 2021 and 2020, the Company granted 0.3 million performance-based PSUs to its executive officers and certain employees. The grant-date fair value of these performance-based awards was based on the closing price of the Company’s stock on the date of grant. These awards vest over a two-year and three-year period, respectively, subject to the grantee’s continued employment, with the ability to earn shares in a range of 0% to 142.8% of the awarded number of PSUs based on the achievement of defined performance targets. Equity-based compensation expense with respect to these awards will be adjusted over the vesting period to reflect the probability of achievement of performance targets defined in the award agreements.

[0001564590-21-025123:notes:53]
The fair value of RSUs and restricted stock is equal to the closing price of our stock on the grant date. The fair value of PSUs with market conditions is calculated using a Monte Carlo simulation valuation method.

[0001564590-21-025123:notes:54]
As of March 31, 2021, total unrecognized compensation expense related to non-vested market-based PSUs, RSUs and restricted stock was approximately $15.2 million, which will be recognized over the remaining weighted-average period of 2.6 years. In addition, there was $5.3 million of unrecognized compensation expense related to unvested 2020 and 2021 performance-based PSUs, which will be recognized over the remaining requisite service period of 1.7 years if achievement of the performance obligation becomes probable. Unrecognized compensation expense will be adjusted for actual forfeitures.

[0001564590-21-025123:notes:55]
As of March 31, 2021, 3.4 million shares were available for issuance under shareholder-approved equity plans.

[0001564590-21-025123:notes:56]
[same as prior period, unchanged from 0001564590-20-052017:notes:71]

[0001564590-21-025123:notes:57]
The following table summarizes stock options outstanding as of December 31, 2020 and March 31, 2021 and the changes that occurred during the three months ended March 31, 2021:

[0001564590-21-025123:notes:58]
|  |  | Number of Stock Options (in thousands) |  |  | Weighted Avg. Exercise Price (per share) |  |  | Weighted Avg. Remaining Contractual Life (in years) |  |  | Aggregate Intrinsic Value (in thousands) |  |
| Stock options outstanding, December 31, 2020 |  |  | 2,718 |  |  | $ | 21.17 |  |  |  | 2.9 |  |  | $ | — |  |
| Stock options exercised |  |  | (80 | ) |  | $ | 15.64 |  |  |  |  |  |  | $ | 167 |  |
| Stock options forfeited / expired |  |  | (92 | ) |  | $ | 21.55 |  |  |  |  |  |  | $ | — |  |
| Stock options outstanding, March 31, 2021 |  |  | 2,546 |  |  | $ | 21.32 |  |  |  | 2.6 |  |  | $ | 779 |  |
| Stock options exercisable, March 31, 2021 |  |  | 2,546 |  |  | $ | 21.32 |  |  |  | 2.6 |  |  | $ | 779 |  |

[0001564590-21-025123:notes:59]
As of March 31, 2021, there was no unrecognized compensation expense related to non-vested stock options.

[0001564590-21-025123:notes:60]
There were no stock options granted during the three months ended March 31, 2021 and 2020. All of the options were previously issued at exercise prices that approximated fair market value at the date of grant.

[0001564590-21-025123:notes:61]
The aggregate intrinsic value of stock options represents the total pre-tax intrinsic value (the difference between the Company’s closing stock price on the last trading day of the quarter and the exercise price, multiplied by the number of in-the-money options) that would have been received by the option holders had all option holders exercised their options on March 31, 2021. The amount of aggregate intrinsic value will change based on the fair market value of the Company’s stock and was $0.8 million as of March 31, 2021. The total pre-tax intrinsic value of options exercised during the three months ended March 31, 2021 was $0.2 million.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001564590-21-025123:notes:62]
7. INVESTMENTS

[0001564590-21-025123:notes:63]
Debt Securities and Other Investments

[0001564590-21-025123:notes:64]
The following debt securities and other investments were included on the Condensed Consolidated Balance Sheets and recorded at fair value:

[0001564590-21-025123:notes:65]
|  |  | As of March 31,2021 |  |
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 14,176 |  |  | $ | 68 |  |  | $ | (13 | ) |  | $ | 14,231 |  |
| Municipal fixed-rate bonds |  |  | 2,600 |  |  |  | 25 |  |  |  | — |  |  |  | 2,625 |  |
| Asset-backed bonds |  |  | 5,772 |  |  |  | 42 |  |  |  | (2 | ) |  |  | 5,812 |  |
| Mortgage/Agency-backed bonds |  |  | 11,775 |  |  |  | 92 |  |  |  | (22 | ) |  |  | 11,845 |  |
| U.S. government bonds |  |  | 9,704 |  |  |  | 66 |  |  |  | (1 | ) |  |  | 9,769 |  |
| Foreign government bonds |  |  | 1,331 |  |  |  | 3 |  |  |  | (2 | ) |  |  | 1,332 |  |
| Other |  |  | 533 |  |  |  | — |  |  |  | — |  |  |  | 533 |  |
| Available-for-sale debt securities held at fair value |  | $ | 45,891 |  |  | $ | 296 |  |  | $ | (40 | ) |  | $ | 46,147 |  |

[0001564590-21-025123:notes:66]
|  |  | As of December 31, 2020 |  |
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 11,762 |  |  | $ | 123 |  |  | $ | — |  |  | $ | 11,885 |  |
| Municipal fixed-rate bonds |  |  | 2,854 |  |  |  | 30 |  |  |  | — |  |  |  | 2,884 |  |
| Asset-backed bonds |  |  | 6,634 |  |  |  | 74 |  |  |  | — |  |  |  | 6,708 |  |
| Mortgage/Agency-backed bonds |  |  | 11,536 |  |  |  | 114 |  |  |  | (6 | ) |  |  | 11,644 |  |
| U.S. government bonds |  |  | 9,763 |  |  |  | 112 |  |  |  | — |  |  |  | 9,875 |  |
| Foreign government bonds |  |  | 1,334 |  |  |  | 4 |  |  |  | (1 | ) |  |  | 1,337 |  |
| Commercial Paper |  |  | 250 |  |  |  | — |  |  |  | — |  |  |  | 250 |  |
| Other |  |  | 533 |  |  |  | — |  |  |  | — |  |  |  | 533 |  |
| Available-for-sale debt securities held at fair value |  | $ | 44,666 |  |  | $ | 457 |  |  | $ | (7 | ) |  | $ | 45,116 |  |

[0001564590-21-025123:notes:67]
The contractual maturities related to debt securities and other investments were as follows:

[0001564590-21-025123:notes:68]
|  |  | As of March 31,2021 |  |
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset- backed bonds |  |  | Mortgage / Agency- backed bonds |  |  | U.S. government bonds |  | Foreign government bonds |  |  | Other |  |
| Less than one year |  | $ | 1,323 |  |  | $ | 357 |  |  | $ | 16 |  |  | $ | 296 |  |  | $ | 1,282 |  | $ | 75 |  |  | $ | 533 |  |
| One to two years |  |  | 3,758 |  |  |  | 1,130 |  |  |  | 13 |  |  |  | 2,090 |  |  |  | 6,831 |  |  | 460 |  |  |  | — |  |
| Two to three years |  |  | 7,509 |  |  |  | 1,138 |  |  |  | 272 |  |  |  | 1,740 |  |  |  | 1,656 |  |  | 497 |  |  |  | — |  |
| Three to five years |  |  | 1,641 |  |  |  | — |  |  |  | 3,445 |  |  |  | 175 |  |  |  | — |  |  | 300 |  |  |  | — |  |
| Five to ten years |  |  | — |  |  |  | — |  |  |  | 1,143 |  |  |  | 2,457 |  |  |  | — |  |  | — |  |  |  | — |  |
| More than ten years |  |  | — |  |  |  | — |  |  |  | 923 |  |  |  | 5,087 |  |  |  | — |  |  | — |  |  |  | — |  |
| Total |  | $ | 14,231 |  |  | $ | 2,625 |  |  | $ | 5,812 |  |  | $ | 11,845 |  |  | $ | 9,769 |  | $ | 1,332 |  |  | $ | 533 |  |

[0001564590-21-025123:notes:69]
Actual maturities may differ from contractual maturities as some borrowers have the right to call or prepay obligations with or without call or prepayment penalties.

[0001564590-21-025123:notes:70]
Realized gains and losses on sales of debt securities are computed under the specific identification method. The following table presents gross realized gains and losses related to debt securities:

[0001564590-21-025123:notes:71]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2021 |  |  | 2020 |  |
| Gross realized gains on debt securities |  | $ | 87 |  |  | $ | 43 |  |
| Gross realized losses on debt securities |  |  | (16 | ) |  |  | (20 | ) |
| Total gain recognized, net |  | $ | 71 |  |  | $ | 23 |  |

[0001564590-21-025123:notes:72]
The Company’s investment policy provides limitations for issuer concentration, which limits, at the time of purchase, the concentration in any one issuer to 5% of the market value of the total investment portfolio. The Company did not purchase any available-for-sale debt security with credit deterioration during the three months ended March 31, 2021.

[0001564590-21-025123:notes:73]
Marketable Equity Securities

[0001564590-21-025123:notes:74]
Our marketable equity securities consist of publicly traded stock, funds and certain other investments measured at fair value or cost (where appropriate).

[0001564590-21-025123:notes:75]
In March 2019, an outstanding note receivable of $4.3 million was repaid and reissued to the Company in the form of debt and equity. Of the outstanding $4.3 million, $3.4 million was issued as an equity investment. The Company elected to record this equity investment that does not have a readily determinable fair value using the measurement alternative. Under the measurement alternative, equity investments that do not have a readily determinable fair value can be recorded at cost less impairment, if any, adjusted for observable price changes for an identical or similar investment. During the year ended December 31, 2020, impairment charges totaling $2.6 million were recorded related to this equity investment, which was included in net investment gain (loss) on the Condensed Consolidated Statement of Income (Loss). As a result, the carrying value of this investment was $0.8 million as of March 31, 2021 and December 31, 2020. The remaining amount, $0.9 million of the original $4.3 million note receivable, was reissued as a new note receivable, which is included in long-term investments on the Condensed Consolidated Balance Sheets as of March 31, 2021 and December 31, 2020. No impairment charge was recognized related to the note receivable, as it is a secured loan.

[0001564590-21-025123:notes:76]
Realized and unrealized gains and losses related to marketable equity securities were as follows:

[0001564590-21-025123:notes:77]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2021 |  |  | 2020 |  |
| Realized gains (losses) on equity securities sold |  | $ | 24 |  |  | $ | (2,436 | ) |
| Unrealized gains (losses) on equity securities held |  |  | 901 |  |  |  | (8,464 | ) |
| Total gain (loss) recognized, net |  | $ | 925 |  |  | $ | (10,900 | ) |

[0001564590-21-025123:notes:78]
U.S. GAAP establishes a three-level valuation hierarchy based upon observable and unobservable inputs for fair value measurement of financial instruments:

[0001564590-21-025123:notes:79]
• Level 1 – Observable outputs; values based on unadjusted quoted prices for identical assets or liabilities in an active market;

[0001564590-21-025123:notes:80]
• Level 2 – Significant inputs that are observable; values based on quoted prices in markets that are not active or model inputs that are observable either directly or indirectly;

[0001564590-21-025123:notes:81]
• Level 3 – Significant unobservable inputs; values based on prices or valuation techniques that require inputs that are both unobservable and significant to the overall fair value measurement; inputs could include information supplied by investees.

[0001564590-21-025123:notes:82]
The Company’s cash equivalents and investments held at fair value are categorized into this hierarchy as follows:

[0001564590-21-025123:notes:83]
|  |  |  |  |  |  | Fair Value Measurements as of March 31, 2021 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 889 |  |  | $ | 889 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 14,231 |  |  |  | — |  |  |  | 14,231 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 2,625 |  |  |  | — |  |  |  | 2,625 |  |  |  | — |  |
| Asset-backed bonds |  |  | 5,812 |  |  |  | — |  |  |  | 5,812 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 11,845 |  |  |  | — |  |  |  | 11,845 |  |  |  | — |  |
| U.S. government bonds |  |  | 9,769 |  |  |  | 9,769 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 1,332 |  |  |  | — |  |  |  | 1,332 |  |  |  | — |  |
| Other |  |  | 533 |  |  |  | — |  |  |  | — |  |  |  | 533 |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 11,544 |  |  |  | 11,544 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 24,364 |  |  |  | 24,364 |  |  |  | — |  |  |  | — |  |
| Other investments |  |  | 1,400 |  |  |  | 1,400 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 84,344 |  |  | $ | 47,966 |  |  | $ | 35,845 |  |  | $ | 533 |  |

[0001564590-21-025123:notes:84]
|  |  |  |  |  |  | Fair Value Measurements as of December 31, 2020 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 497 |  |  | $ | 497 |  |  | $ | — |  |  | $ | — |  |
| U.S. government bonds |  |  | 350 |  |  |  | 350 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 11,885 |  |  |  | — |  |  |  | 11,885 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 2,884 |  |  |  | — |  |  |  | 2,884 |  |  |  | — |  |
| Asset-backed bonds |  |  | 6,708 |  |  |  | — |  |  |  | 6,708 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 11,644 |  |  |  | — |  |  |  | 11,644 |  |  |  | — |  |
| U.S. government bonds |  |  | 9,875 |  |  |  | 9,875 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 1,337 |  |  |  | — |  |  |  | 1,337 |  |  |  | — |  |
| Commercial paper |  |  | 250 |  |  |  | — |  |  |  | 250 |  |  |  | — |  |
| Other |  |  | 533 |  |  |  | — |  |  |  | — |  |  |  | 533 |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 10,963 |  |  |  | 10,963 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 23,891 |  |  |  | 23,891 |  |  |  | — |  |  |  | — |  |
| Other investments |  |  | 1,400 |  |  |  | 1,400 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 82,217 |  |  | $ | 46,976 |  |  | $ | 34,708 |  |  | $ | 533 |  |

[0001564590-21-025123:notes:85]
The fair value of our Level 2 securities is calculated using a weighted average market price for each security. Market prices are obtained from a variety of industry standard data providers, large financial institutions and other third-party sources. These multiple market prices are used as inputs into a distribution-curve-based algorithm to determine the daily market value of each security.

[0001564590-21-025123:notes:86]
The fair value of Level 3 securities is calculated based on unobservable inputs. Quantitative information with respect to unobservable inputs consists of third-party valuations performed in accordance with ASC 820 – Fair Value Measurement. Inputs used in preparing the third-party valuation included the following assumptions, among others: estimated discount rates and fair market yields.


## us-gaap:InventoryDisclosureTextBlock

[0001564590-21-025123:notes:87]
[same as prior period, unchanged from 0001564590-20-052017:notes:103]

[0001564590-21-025123:notes:88]
Inventory consisted of the following:

[0001564590-21-025123:notes:89]
|  |  | As of March 31, |  |  | As of December 31, |  |
| (In thousands) |  | 2021 |  |  | 2020 |  |
| Raw materials |  | $ | 47,980 |  |  | $ | 47,026 |  |
| Work in process |  |  | 1,820 |  |  |  | 776 |  |
| Finished goods |  |  | 73,062 |  |  |  | 77,655 |  |
| Total inventory, net |  | $ | 122,862 |  |  | $ | 125,457 |  |

[0001564590-21-025123:notes:90]
Inventory reserves are established for estimated excess and obsolete inventory equal to the difference between the cost of the inventory and the estimated net realizable value of the inventory based on estimated reserve percentages, which consider historical usage, known trends, inventory age and market conditions. As of March 31, 2021 and December 31, 2020, inventory reserves were $41.7 million and $39.6 million, respectively.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001564590-21-025123:notes:91]
[same as prior period, unchanged from 0001564590-20-052017:notes:107]

[0001564590-21-025123:notes:92]
Property, plant and equipment consisted of the following:

[0001564590-21-025123:notes:93]
|  |  | As of March 31, |  |  | As of December 31, |  |
| (In thousands) |  | 2021 |  |  | 2020 |  |
| Land |  | $ | 4,575 |  |  | $ | 4,575 |  |
| Building and land improvements |  |  | 35,154 |  |  |  | 35,142 |  |
| Building |  |  | 68,167 |  |  |  | 68,169 |  |
| Furniture and fixtures |  |  | 19,946 |  |  |  | 19,965 |  |
| Computer hardware and software |  |  | 70,889 |  |  |  | 70,942 |  |
| Engineering and other equipment |  |  | 133,065 |  |  |  | 132,920 |  |
| Total property, plant and equipment |  |  | 331,796 |  |  |  | 331,713 |  |
| Less: accumulated depreciation |  |  | (271,639 | ) |  |  | (269,314 | ) |
| Total property, plant and equipment, net |  | $ | 60,157 |  |  | $ | 62,399 |  |

[0001564590-21-025123:notes:94]
Long-lived assets used in operations are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable and the undiscounted cash flows estimated to be generated by the asset are less than the asset’s carrying value. Due to the current economic environment, particularly related to COVID-19, the Company assessed impairment triggers related to long-lived assets during the first quarter of 2021. Based on this assessment, no triggers occurred to require the performance of an impairment test, and no impairment losses of long-lived assets were recorded.

[0001564590-21-025123:notes:95]
Depreciation expense was $3.1 million and $3.0 million for the three months ended March 31, 2021 and 2020, respectively, which is recorded in cost of revenue, selling, general and administrative expenses and research and development expenses in the Condensed Consolidated Statements of Income (Loss).


## us-gaap:GoodwillDisclosureTextBlock

[0001564590-21-025123:notes:96]
[same as prior period, unchanged from 0001564590-20-052017:notes:112]

[0001564590-21-025123:notes:97]
Goodwill was $7.0 million as of March 31, 2021 and December 31, 2020, of which $6.6 million and $0.4 million was allocated to our Network Solutions and Services & Support reportable segments, respectively.

[0001564590-21-025123:notes:98]
The Company evaluates the carrying value of goodwill during the fourth quarter of each year and between annual evaluations if events occur or circumstances change that could more likely than not reduce the fair value of the reporting unit below its carrying amount. Qualitative factors are assessed to determine whether the fair value of the reporting unit to which the goodwill is assigned is less than its carrying amount and an impairment charge is recognized for the amount by which the carrying value exceeds the fair value of the reporting unit. Due to the current economic environment, particularly related to COVID-19, the Company performed a triggering event assessment during the first quarters of 2021 and 2020, in which no triggers were identified. Therefore, no interim impairment test of goodwill was performed as of March 31, 2021 and 2020 and no impairment of goodwill was recorded during the three months ended March 31, 2021 or 2020.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001564590-21-025123:notes:99]
[same as prior period, unchanged from 0001564590-20-052017:notes:115]

[0001564590-21-025123:notes:100]
Intangible assets consisted of the following:

[0001564590-21-025123:notes:101]
|  |  | As of March 31, 2021 |  |  | As of December 31, 2020 |  |
| (In thousands) |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Net Book Value |  |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Net Book Value |  |
| Customer relationships |  | $ | 20,934 |  |  | $ | (8,451 | ) |  | $ | 12,483 |  |  | $ | 21,123 |  |  | $ | (8,055 | ) |  | $ | 13,068 |  |
| Developed technology |  |  | 8,200 |  |  |  | (2,830 | ) |  |  | 5,370 |  |  |  | 8,200 |  |  |  | (2,546 | ) |  |  | 5,654 |  |
| Licensed technology |  |  | 5,900 |  |  |  | (1,994 | ) |  |  | 3,906 |  |  |  | 5,900 |  |  |  | (1,830 | ) |  |  | 4,070 |  |
| Supplier relationships |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 2,800 |  |  |  | (2,800 | ) |  |  | — |  |
| Licensing agreements |  |  | 560 |  |  |  | (170 | ) |  |  | 390 |  |  |  | 560 |  |  |  | (152 | ) |  |  | 408 |  |
| Patents |  |  | 500 |  |  |  | (312 | ) |  |  | 188 |  |  |  | 500 |  |  |  | (294 | ) |  |  | 206 |  |
| Trade names |  |  | 210 |  |  |  | (163 | ) |  |  | 47 |  |  |  | 210 |  |  |  | (146 | ) |  |  | 64 |  |
| Total |  | $ | 36,304 |  |  | $ | (13,920 | ) |  | $ | 22,384 |  |  | $ | 39,293 |  |  | $ | (15,823 | ) |  | $ | 23,470 |  |

[0001564590-21-025123:notes:102]
The Company evaluates the carrying value of intangible assets whenever events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable and the undiscounted cash flows estimated to be generated by the asset are less than the asset’s carrying value. Due to the current economic environment, particularly related to COVID-19, the Company assessed impairment triggers related to intangible assets during the first quarter of 2021 and 2020. Based on this assessment, no triggers occurred to require the performance of an impairment test, and no impairment losses of intangible assets were recorded for the three months ended March 31, 2021 or 2020.

[0001564590-21-025123:notes:103]
Amortization expense was $1.0 million and $1.3 million for the three months ended March 31, 2021 and 2020, respectively, and was included in cost of revenue, selling, general and administrative expenses and research and development expenses in the Condensed Consolidated Statements of Income (Loss).

[0001564590-21-025123:notes:104]
Estimated future amortization expense of intangible assets was as follows:

[0001564590-21-025123:notes:105]
| (In thousands) |  | As of March 31, 2021 |  |
| 2021 |  | $ | 3,067 |  |
| 2022 |  |  | 3,482 |  |
| 2023 |  |  | 3,330 |  |
| 2024 |  |  | 3,236 |  |
| 2025 |  |  | 3,028 |  |
| Thereafter |  |  | 6,241 |  |
| Total |  | $ | 22,384 |  |


## adtn:LeasesDisclosureTextBlock

[0001564590-21-025123:notes:106]
[same as prior period, unchanged from 0001564590-20-052017:notes:122]

[0001564590-21-025123:notes:107]
[same as prior period, unchanged from 0001564590-20-052017:notes:136]

[0001564590-21-025123:notes:108]
We are the lessor in sales-type lease arrangements for network equipment, which consisted of the following:

[0001564590-21-025123:notes:109]
| (In thousands) |  | As of March 31, 2021 |  |  | As of December 31, 2020 |  |  |
| Current minimum lease payments receivable(1) |  | $ | 560 |  |  | $ | 702 |  |
| Non-current minimum lease payments receivable(2) |  |  | 262 |  |  |  | 347 |  |
| Total minimum lease payments receivable |  |  | 822 |  |  |  | 1,049 |  |
| Less: Current unearned revenue |  |  | 164 |  |  |  | 218 |  |
| Less: Non-current unearned revenue |  |  | 33 |  |  |  | 50 |  |
| Net investment in sales-type leases |  | $ | 625 |  |  | $ | 781 |  |

[0001564590-21-025123:notes:110]
(1)Included in other receivables on the Condensed Consolidated Balance Sheets.
     (2)Included in other assets on the Condensed Consolidated Balance Sheets.


## us-gaap:DebtDisclosureTextBlock

[0001564590-21-025123:notes:111]
13. REVOLVING CREDIT AGREEMENT

[0001564590-21-025123:notes:112]
On November 4, 2020, the Company, as borrower, entered into a Revolving Credit and Security Agreement and related Promissory Note (together, the “Revolving Credit Agreement”) with Cadence Bank, N.A., as lender (the “Lender”). The Revolving Credit Agreement provides the Company with a new $10.0 million secured revolving credit facility. Loans under the Revolving Credit Agreement will bear interest at a rate equal to 1.50% over the screen rate as obtained by Reuter’s, Bloomberg  or  another  commercially  available  source  as  may  be  designated  by  the  Lender  from  time  to  time;  provided,  however,  that  in  no  event  shall  the applicable rate of interest under the Revolving Credit Agreement be less than 1.50% per annum. Such loans are secured by all of the cash, securities, securities entitlements  and  investment  property  in  a  certain  bank  account,  as  outlined  in  the  Revolving  Credit  Agreement,  at  a  maximum  loan-to-value  ratio  of  75% determined by dividing the full commitment amount under the Revolving Credit Agreement on the date of testing, determined by the Lender each fiscal quarter, by the market value of the collateral. The Revolving Credit Agreement matures on November 4, 2021, subject to earlier termination upon the occurrence of certain events of default. The Company had not made any draws under the Revolving Credit Agreement as of March 31, 2021.


## adtn:IndustrialDevelopmentAuthorityFinancingAndEconomicIncentivesTextBlock

[0001564590-21-025123:notes:113]
14. ALABAMA STATE INDUSTRIAL DEVELOPMENT AUTHORITY FINANCING AND ECONOMIC INCENTIVES

[0001564590-21-025123:notes:114]
In conjunction with the 1995 expansion of our Huntsville, Alabama facility, we were approved for participation in an incentive program offered by the State of Alabama Industrial Development Authority (the “Authority”). Pursuant to the program, in January 1995, the Authority issued $20.0 million of its taxable revenue bonds (the “Taxable Revenue Bonds”) and loaned the proceeds from the sale of the Taxable Revenue Bonds to the Company. Further advances on the Taxable Revenue Bonds were made by the Authority, bringing the total amount to $50.0 million. The Taxable Revenue Bonds bore interest, payable monthly with an interest rate of 2% per annum. The Taxable Revenue Bonds aggregate principal amount of $24.6 million matured on January 1, 2020 and was repaid in full on January 2, 2020, using the funds held in a certificate of deposit by the Company.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001564590-21-025123:notes:115]
15. STOCKHOLDERS’ EQUITY

[0001564590-21-025123:notes:116]
[same as prior period, unchanged from 0001564590-20-052017:notes:145]

[0001564590-21-025123:notes:117]
Since 1997, the Company’s Board of Directors has approved multiple share repurchase programs that have authorized repurchases of its common stock, which are implemented through open market or private purchases from time to time as conditions warrant. During the three months ended March 31, 2021 and 2020, we did not repurchase any shares of our common stock. As of March 31, 2021, we had the authority to purchase an additional 2.5 million shares of our common stock under the current authorization of up to 5.0 million shares.

[0001564590-21-025123:notes:118]
Other Comprehensive Loss

[0001564590-21-025123:notes:119]
The following tables present the changes in accumulated other comprehensive loss, net of tax, by component:

[0001564590-21-025123:notes:120]
|  |  | Three Months Ended March 31, 2021 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | ASU 2018-02 Adoption |  |  | Total |  |
| As of December 31, 2020 |  | $ | 32 |  |  | $ | (9,621 | ) |  | $ | (2,435 | ) |  | $ | 385 |  |  | $ | (11,639 | ) |
| Other comprehensive loss before reclassifications |  |  | (57 | ) |  |  | — |  |  |  | (1,863 | ) |  |  | — |  |  |  | (1,920 | ) |
| Amounts reclassified from accumulated other comprehensive income (loss) |  |  | (135 | ) |  |  | 99 |  |  |  | — |  |  |  | — |  |  |  | (36 | ) |
| Net current period other comprehensive income (loss) |  |  | (192 | ) |  |  | 99 |  |  |  | (1,863 | ) |  |  | — |  |  |  | (1,956 | ) |
| As of March 31, 2021 |  | $ | (160 | ) |  | $ | (9,522 | ) |  | $ | (4,298 | ) |  | $ | 385 |  |  | $ | (13,595 | ) |

[0001564590-21-025123:notes:121]
|  |  | Three Months Ended March 31, 2020 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | ASU 2018-02 Adoption |  |  | Total |  |
| As of December 31, 2019 |  | $ | (284 | ) |  | $ | (9,226 | ) |  | $ | (7,292 | ) |  | $ | 385 |  |  | $ | (16,417 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | (931 | ) |  |  | — |  |  |  | (1,650 | ) |  |  | — |  |  |  | (2,581 | ) |
| Amounts reclassified from accumulated other comprehensive income (loss) |  |  | 1,048 |  |  |  | 141 |  |  |  | — |  |  |  | — |  |  |  | 1,189 |  |
| Net current period other comprehensive income (loss) |  |  | 117 |  |  |  | 141 |  |  |  | (1,650 | ) |  |  | — |  |  |  | (1,392 | ) |
| As of March 31, 2020 |  | $ | (167 | ) |  | $ | (9,085 | ) |  | $ | (8,942 | ) |  | $ | 385 |  |  | $ | (17,809 | ) |

[0001564590-21-025123:notes:122]
The following tables present the details of reclassifications out of accumulated other comprehensive loss:

[0001564590-21-025123:notes:123]
|  |  | Three Months Ended March 31, 2021 |
| (In thousands) |  | Amount Reclassified from Accumulated Other Comprehensive Loss |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for-sale securities: |  |  |  |  |  |  |
| Net realized gains on sales of securities |  | $ | 178 |  |  | Net investment gain (loss) |
| Defined benefit plan adjustments – actuarial losses |  |  | (143 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | 35 |  |  |  |
| Tax benefit |  |  | 1 |  |  |  |
| Total reclassifications for the period, net of tax |  | $ | 36 |  |  |  |

[0001564590-21-025123:notes:124]
[same as prior period, unchanged from 0001564590-20-052017:notes:157]

[0001564590-21-025123:notes:125]
|  |  | Three Months Ended March 31, 2020 |
| (In thousands) |  | Amount Reclassified from Accumulated Other Comprehensive Loss |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for-sale securities: |  |  |  |  |  |  |
| Net realized losses on sales of securities |  | $ | (1,416 | ) |  | Net investment gain (loss) |
| Defined benefit plan adjustments – actuarial losses |  |  | (204 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | (1,620 | ) |  |  |
| Tax benefit |  |  | 431 |  |  |  |
| Total reclassifications for the period, net of tax |  | $ | (1,189 | ) |  |  |

[0001564590-21-025123:notes:126]
The following table presents the tax effects related to the change in each component of other comprehensive loss:

[0001564590-21-025123:notes:127]
|  |  | Three Months Ended |  |  | Three Months Ended |  |
|  |  | March 31, 2021 |  |  | March 31, 2020 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |
| Unrealized loss on available-for-sale securities |  | $ | (75 | ) |  | $ | 18 |  |  | $ | (57 | ) |  | $ | (1,258 | ) |  | $ | 327 |  |  | $ | (931 | ) |
| Reclassification adjustment for amounts related to available-for-sale investments included in net income (loss) |  |  | (178 | ) |  |  | 43 |  |  |  | (135 | ) |  |  | 1,416 |  |  |  | (368 | ) |  |  | 1,048 |  |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net income (loss) |  |  | 143 |  |  |  | (44 | ) |  |  | 99 |  |  |  | 204 |  |  |  | (63 | ) |  |  | 141 |  |
| Foreign currency translation adjustment |  |  | (1,863 | ) |  |  | — |  |  |  | (1,863 | ) |  |  | (1,650 | ) |  |  | — |  |  |  | (1,650 | ) |
| Total Other Comprehensive Loss |  | $ | (1,973 | ) |  | $ | 17 |  |  | $ | (1,956 | ) |  | $ | (1,288 | ) |  | $ | (104 | ) |  | $ | (1,392 | ) |


## us-gaap:EarningsPerShareTextBlock

[0001564590-21-025123:notes:128]
16. EARNINGS (LOSS) PER SHARE

[0001564590-21-025123:notes:129]
A summary of the calculation of basic and diluted earnings (loss) per share is as follows:

[0001564590-21-025123:notes:130]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands, except per share amounts) |  | 2021 |  |  | 2020 |  |
| Numerator |  |  |  |  |  |  |  |  |
| Net income (loss) |  | $ | 896 |  |  | $ | (9,969 | ) |
| Denominator |  |  |  |  |  |  |  |  |
| Weighted average number of shares – basic |  |  | 48,336 |  |  |  | 47,957 |  |
| Effect of dilutive securities |  |  |  |  |  |  |  |  |
| Stock options |  |  | 56 |  |  |  | — |  |
| PSUs, RSUs and restricted stock |  |  | 612 |  |  |  | — |  |
| Weighted average number of shares – diluted |  |  | 49,004 |  |  |  | 47,957 |  |
| Earnings (loss) per share – basic |  | $ | 0.02 |  |  | $ | (0.21 | ) |
| Earnings (loss) per share – diluted |  | $ | 0.02 |  |  | $ | (0.21 | ) |

[0001564590-21-025123:notes:131]
For the three months ended March 31, 2021 and 2020, 0.7 million and 5.9 million stock options, respectively, were outstanding but were not included in the computation of diluted earnings per share. These stock options were excluded because their exercise prices were greater than the average market price of the common shares during the quarter, therefore making them anti-dilutive under the treasury stock method.

[0001564590-21-025123:notes:132]
For the three months ended March 31, 2021 and 2020, one thousand and 0.4 million shares, respectively, of unvested PSUs, RSUs and restricted stock were excluded from the calculation of diluted earnings per share due to their anti-dilutive effect.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-21-025123:notes:133]
17. SEGMENT INFORMATION

[0001564590-21-025123:notes:134]
The Company’s chief operating decision maker regularly reviews the Company’s financial performance based on two reportable segments: (1) Network Solutions and (2) Services & Support. Network Solutions includes hardware and software products and next-generation virtualized solutions used in service provider or business networks, as well as prior-generation products. Services & Support includes a portfolio of maintenance, network installation and solution integration services, which include hosted cloud services and subscription services.

[0001564590-21-025123:notes:135]
The performance of these segments is evaluated based on gross profit; therefore, selling, general and administrative expenses, research and development expenses, interest and dividend income, interest expense, net investment gain (loss), other income (expense) and income tax (expense) benefit are reported on a company-wide basis only. There is no inter-segment revenue. Asset information by reportable segment is not produced and, therefore, is not reported.

[0001564590-21-025123:notes:136]
The following table presents information about the revenue and gross profit of our reportable segments:

[0001564590-21-025123:notes:137]
|  |  | Three Months Ended March 31, |  |
|  |  | 2021 |  |  | 2020 |  |
| (In thousands) |  | Revenue |  |  | Gross Profit |  |  | Revenue |  |  | Gross Profit |  |
| Network Solutions |  | $ | 113,809 |  |  | $ | 48,808 |  |  | $ | 97,372 |  |  | $ | 45,746 |  |
| Services & Support |  |  | 13,724 |  |  |  | 4,793 |  |  |  | 17,151 |  |  |  | 5,854 |  |
| Total Revenue |  | $ | 127,533 |  |  | $ | 53,601 |  |  | $ | 114,523 |  |  | $ | 51,600 |  |

[0001564590-21-025123:notes:138]
In addition to our reporting segments, revenue is also reported for the following three categories – (1) Access & Aggregation, (2) Subscriber Solutions & Experience and (3) Traditional & Other Products.

[0001564590-21-025123:notes:139]
Revenue by Geographic Area

[0001564590-21-025123:notes:140]
The following table presents revenue information by geographic area:

[0001564590-21-025123:notes:141]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2021 |  |  | 2020 |  |
| United States |  | $ | 86,485 |  |  | $ | 78,991 |  |
| International |  |  | 41,048 |  |  |  | 35,532 |  |
| Total Revenue |  | $ | 127,533 |  |  | $ | 114,523 |  |


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001564590-21-025123:notes:142]
18. LIABILITY FOR WARRANTY RETURNS

[0001564590-21-025123:notes:143]
Our products generally include warranties of 90 days to five years for product defects. We accrue for warranty returns at the time of product shipment based on our historical return rate and estimate of the cost to repair or replace the defective products. We engage in extensive product quality programs and processes, including actively monitoring and evaluating the quality of our component suppliers. The increasing complexity of our products may cause warranty incidences, when they arise, to be more costly. Estimates regarding future warranty obligations may change due to product failure rates, material usage and other rework costs incurred in correcting a product failure. In addition, from time to time, specific warranty accruals may be recorded if unforeseen problems arise. Should our actual experience relative to these factors be worse than our estimates, we will be required to record additional warranty expense. The liability for warranty obligations totaled $6.5 million and $7.1 million as of March 31, 2021 and December 31, 2020, respectively, and is included in accrued expenses and other liabilities in the Condensed Consolidated Balance Sheets. During the three months ended March 31, 2021, we had a reversal of prior provisions related to warranty expirations, the impact of which is reflected in the table below.

[0001564590-21-025123:notes:144]
A reconciliation of warranty expense and related write-off activity is as follows:

[0001564590-21-025123:notes:145]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2021 |  |  | 2020 |  |
| Balance at beginning of period |  | $ | 7,146 |  |  | $ | 8,394 |  |
| Plus: Amounts charged to cost and expenses |  |  | (231 | ) |  |  | (55 | ) |
| Less: Deductions |  |  | (443 | ) |  |  | (704 | ) |
| Balance at end of period |  | $ | 6,472 |  |  | $ | 7,635 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-21-025123:notes:146]
19. COMMITMENTS AND CONTINGENCIES

[0001564590-21-025123:notes:147]
Securities Class Action Lawsuit

[0001564590-21-025123:notes:148]
On March 31, 2021, the U.S. District for the Northern District of Alabama dismissed without prejudice a purported stockholder class action lawsuit, captioned Burbridge v. ADTRAN, Inc. et al, Docket No. 19-cv-09619 originally filed on October 17, 2019. This matter has been fully resolved by agreement among the parties, with no further action to be taken by the plaintiffs and each party bearing its own costs.

[0001564590-21-025123:notes:149]
Shareholder Derivative Lawsuit

[0001564590-21-025123:notes:150]
On March 31, 2020, a shareholder derivative suit, captioned Johnson (Derivatively on behalf of ADTRAN) v. T. Stanton, M. Foliano, R. Shannon, and Board of Directors, case no. 5:20-cv-00447, was filed in the U.S. District Court of Northern Alabama against two of the Company’s current executive officers, one of its former executive officers and its Board of Directors. The derivative suit, which is purportedly brought on behalf of ADTRAN, claims that the defendants made materially false and misleading statements regarding, and/or failed to disclose  material  adverse  facts  about,  the  Company’s  business,  operations  and  prospects,  specifically  relating  to  the  Company’s  internal  control  over  financial reporting, excess and obsolete inventory reserves, financial results and demand from certain customers. These are similar allegations as the shareholder class action that was dismissed without prejudice by the Court on March 31, 2021, and fully resolved by mutual agreement of the parties on May 3, 2021. The parties to the shareholder derivative suit agreed to a joint stipulation requesting a stay in the proceedings due to the resolution of the shareholder class action that remains in effect at least until May 19, 2021. The Company and its defendants disagree with the claims made in the complaint, and the defendants intend to vigorously defend against this lawsuit. At this time, we are unable to predict the outcome of or estimate the possible loss or range of loss, if any, associated with this lawsuit.

[0001564590-21-025123:notes:151]
Other Legal Matters

[0001564590-21-025123:notes:152]
In addition to the litigation described above, from time to time we are subject to or otherwise involved in various lawsuits, claims, investigations and legal proceedings that arise out of or are incidental to the conduct of our business (collectively, “Legal Matters”), including those relating to patent rights, employment matters, regulatory compliance matters, stockholder claims, and contractual and other commercial disputes. Such Legal Matters, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Additionally, an unfavorable outcome in any legal matter, including in a patent dispute, could require the Company to pay damages, entitle claimants to other relief, such as royalties, or could prevent the Company from selling some of its products in certain jurisdictions. While the Company cannot predict with certainty the results of the Legal Matters in which it is currently involved, the Company does not expect that the ultimate outcome of such Legal Matters will individually or in the aggregate have a material adverse effect on its business, results of operations, financial condition or cash flows.

[0001564590-21-025123:notes:153]
Performance Bonds

[0001564590-21-025123:notes:154]
Certain contracts, customers and jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of March 31, 2021 and December 31, 2020, we had commitments related to these bonds totaling $21.2 million and $15.2 million, respectively, which expire at various dates through August 2024. Although the triggering events vary from contract to contract, in general we would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which we believe is remote.

[0001564590-21-025123:notes:155]
In June 2020, the Company entered into a letter of credit with a bank to guarantee performance obligations under a contract with a certain customer. The obligations under this customer contract will be performed over multiple years. We reached the maximum value of our minimum collateral requirement of $15.0 million during the three months ended March 31, 2021 as the Company reached certain milestones through the first quarter of 2021 as outlined in the customer contract. The letter of credit was secured by a pledge of a portion of the Company’s fixed-income securities, which totaled $18.2 million as of March 31, 2021, of which $0.1 million is included in restricted cash and $18.1 million is included in long-term investments on the Condensed Consolidated Balance Sheet. This pledged collateral value will fluctuate as the Company changes the mix of the pledged collateral between restricted cash and investments. Any shortfalls in the minimum collateral value are required to be restored by the Company from available cash and cash equivalents, short-term investments and/or long-term investments. The collateral under the letter of credit will be released when all obligations under the customer contract have been met. As of March 31, 2021, the Company was in compliance with all contractual requirements under the letter of credit.

[0001564590-21-025123:notes:156]
Investment Commitment

[0001564590-21-025123:notes:157]
We have committed to invest up to an aggregate of $5.0 million in a private equity fund, of which $4.9 million has been applied as of March 31, 2021.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-21-025123:notes:158]
[same as prior period, unchanged from 0001564590-20-052017:notes:223]

[0001564590-21-025123:notes:159]
During the second half of 2019, the Company initiated a restructuring plan to realign its expense structure with the reduction in revenue experienced in recent years and overall Company objectives. As part of this restructuring plan, the Company announced plans to reduce its overall operating expenses, both in the U.S. and internationally. Management continued to assess the efficiency of operations during 2020 and 2021 and, in turn, consolidated locations and personnel, among other things, where possible.

[0001564590-21-025123:notes:160]
[same as prior period, unchanged from 0001564590-20-052017:notes:225]

[0001564590-21-025123:notes:161]
The cumulative amount of restructuring expenses incurred as of March 31, 2021 for the restructuring plans was $12.5 million.

[0001564590-21-025123:notes:162]
A reconciliation of the beginning and ending restructuring liability, which is included in accrued wages and benefits in the Consolidated Balance Sheets is as follows:

[0001564590-21-025123:notes:163]
| (In thousands) |  | As of March 31, 2021 |  |
| Balance as of December 31, 2020 |  | $ | 4,186 |  |
| Plus: Amounts charged to cost and expense |  |  | 301 |  |
| Less: Amounts paid |  |  | (2,410 | ) |
| Balance as of March 31, 2021 |  | $ | 2,077 |  |

[0001564590-21-025123:notes:164]
[same as prior period, unchanged from 0001564590-20-052017:notes:229]

[0001564590-21-025123:notes:165]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2021 |  |  | 2020 |  |
| Cost of revenue |  |  | 15 |  |  |  | 34 |  |
| Selling, general and administrative expenses |  | $ | 142 |  |  | $ | 83 |  |
| Research and development expenses |  |  | 144 |  |  |  | 436 |  |
| Total restructuring expenses |  | $ | 301 |  |  | $ | 553 |  |

[0001564590-21-025123:notes:166]
The following table represents the components of restructuring expense by geographic area were as follows:

[0001564590-21-025123:notes:167]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2021 |  |  | 2020 |  |
| Domestic |  | $ | 209 |  |  | $ | 551 |  |
| International |  |  | 92 |  |  |  | 2 |  |
| Total restructuring expenses |  | $ | 301 |  |  | $ | 553 |  |


## us-gaap:SubsequentEventsTextBlock

[0001564590-21-025123:notes:168]
21. SUBSEQUENT EVENTS

[0001564590-21-025123:notes:169]
On May 5, 2021, we announced that our Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to the Company’s stockholders of record as of the close of business on May 20, 2021. The payment date will be June 3, 2021 in the aggregate amount of approximately $4.4 million.
