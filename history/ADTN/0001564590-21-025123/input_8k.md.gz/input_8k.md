# ADTN 8-K — 0001564590-21-024430 filed 2021-05-06

## item codes, every 8-K on or before 2021-05-06

- 2021-05-06 0001564590-21-024430 — 2.02, 9.01
- 2021-02-26 0001564590-21-009408 — 2.02, 9.01 — amendment of 0001564590-21-004167
- 2021-02-04 0001564590-21-004167 — 2.02, 9.01
- 2020-11-03 0001564590-20-049784 — 2.02, 9.01
- 2020-08-06 0001564590-20-037168 — 2.02, 9.01
- 2020-07-23 0001564590-20-033184 — 5.03, 9.01
- 2020-05-15 0001564590-20-025794 — 5.07
- 2020-05-11 0001564590-20-024328 — 5.02, 9.01
- 2020-05-07 0001564590-20-022297 — 2.02, 9.01
- 2020-02-25 0001564590-20-006448 — 2.02, 9.01
- 2020-02-06 0001564590-20-003580 — 2.02, 9.01
- 2019-10-31 0001564590-19-038936 — 2.02, 9.01
- 2019-10-10 0001564590-19-036732 — 2.02, 9.01
- 2019-09-20 0001564590-19-035144 — 2.02, 9.01
- 2019-08-21 0001564590-19-032757 — 3.01, 9.01
- 2019-07-18 0001564590-19-025186 — 2.02, 9.01
- 2019-05-09 0001564590-19-017956 — 5.07
- 2019-04-18 0001564590-19-011897 — 2.02, 9.01
- 2019-03-07 0001564590-19-006575 — 5.02, 9.01
- 2019-01-24 0001564590-19-001024 — 2.02, 9.01
- 2018-12-06 0001564590-18-030615 — 8.01, 9.01
- 2018-10-17 0001564590-18-024365 — 2.02, 9.01
- 2018-07-18 0001564590-18-016946 — 2.02, 9.01
- 2018-05-10 0001564590-18-012968 — 5.07
- 2018-04-18 0001564590-18-008361 — 2.02, 9.01
- 2018-03-21 0001564590-18-006409 — 8.01, 9.01
- 2018-01-17 0001564590-18-000519 — 2.02, 9.01
- 2017-12-29 0001564590-17-025375 — 2.02, 9.01
- 2017-11-16 0001193125-17-345232 — 5.02
- 2017-10-18 0001564590-17-019582 — 2.02, 9.01
- 2017-07-19 0001564590-17-013609 — 2.02, 9.01
- 2017-05-11 0001564590-17-010459 — 5.02, 9.01
- 2017-05-11 0001564590-17-010452 — 5.07
- 2017-04-19 0001193125-17-127926 — 2.02, 9.01
- 2017-02-07 0001193125-17-032714 — 8.01
- 2017-01-18 0001193125-17-011669 — 2.02, 9.01
- 2016-11-16 0001193125-16-769505 — 5.02, 9.01
- 2016-10-19 0001193125-16-741087 — 2.02, 9.01
- 2016-09-14 0001193125-16-709148 — 8.01, 9.01
- 2016-08-17 0001193125-16-683980 — 5.02, 9.01
- 2016-07-13 0001193125-16-646816 — 2.02, 9.01
- 2016-05-13 0001193125-16-590263 — 5.07
- 2016-04-13 0001193125-16-539019 — 2.02, 9.01
- 2016-04-08 0001193125-16-535035 — 7.01
- 2016-02-11 0001193125-16-459453 — 5.02, 9.01
- 2016-01-20 0001193125-16-432934 — 2.02, 9.01
- 2015-11-16 0001193125-15-378019 — 5.02, 9.01
- 2015-10-14 0001193125-15-343083 — 2.02, 9.01
- 2015-07-16 0001193125-15-254729 — 8.01, 9.01
- 2015-07-15 0001193125-15-253068 — 2.02, 9.01
- 2015-05-15 0001193125-15-189160 — 5.07, 9.01
- 2015-04-22 0001193125-15-140997 — 2.02, 9.01
- 2015-02-23 0001193125-15-056741 — 5.02, 9.01
- 2015-01-21 0001193125-15-015465 — 2.02, 9.01
- 2014-10-15 0001193125-14-372076 — 2.02, 9.01
- 2014-10-03 0001193125-14-363152 — 2.02, 9.01
- 2014-07-16 0001193125-14-269660 — 2.02, 9.01
- 2014-05-20 0001193125-14-205916 — 8.01, 9.01
- 2014-05-20 0001193125-14-205906 — 5.02, 9.01
- 2014-05-15 0001193125-14-201144 — 5.07
- 2014-04-16 0001193125-14-144665 — 2.02, 9.01
- 2014-04-03 0001193125-14-129578 — 2.02, 9.01
- 2014-01-22 0001157523-14-000154 — 2.02, 9.01
- 2013-10-15 0001193125-13-399540 — 5.02
- 2013-10-09 0001157523-13-004657 — 2.02, 9.01
- 2013-07-10 0001157523-13-003290 — 2.02, 9.01
- 2013-05-10 0001193125-13-213728 — 5.07
- 2013-05-03 0001193125-13-198816 — 8.01, 9.01
- 2013-04-10 0001157523-13-001730 — 2.02, 9.01
- 2013-01-16 0001157523-13-000139 — 2.02, 9.01
- 2012-10-10 0001157523-12-005081 — 2.02, 9.01
- 2012-10-03 0001193125-12-413609 — 7.01
- 2012-09-28 0001193125-12-408878 — 2.02, 9.01
- 2012-07-11 0001157523-12-003592 — 2.02, 9.01
- 2012-05-10 0001193125-12-225669 — 5.07
- 2012-05-10 0001193125-12-225639 — 8.01, 9.01
- 2012-04-11 0001157523-12-001772 — 2.02, 9.01
- 2012-03-15 0001193125-12-116494 — 2.02, 9.01
- 2012-01-18 0001157523-12-000174 — 2.02, 9.01
- 2011-12-12 0001193125-11-337271 — 7.01, 9.01
- 2011-10-13 0000950123-11-089785 — 5.03, 9.01
- 2011-10-12 0001157523-11-005682 — 2.02, 9.01
- 2011-07-13 0001157523-11-003986 — 2.02, 9.01
- 2011-05-09 0000950123-11-047191 — 5.02, 5.07, 9.01
- 2011-04-13 0001157523-11-002001 — 2.02, 9.01
- 2011-01-19 0001157523-11-000232 — 2.02, 9.01
- 2010-11-09 0000950123-10-103195 — 5.02, 9.01
- 2010-10-13 0001157523-10-005798 — 2.02, 9.01
- 2010-07-14 0001157523-10-004011 — 2.02, 9.01
- 2010-05-28 0000950123-10-053947 — 5.07
- 2010-04-14 0001157523-10-002022 — 2.02, 9.01
- 2010-01-20 0001157523-10-000200 — 2.02, 9.01
- 2009-10-28 0000950123-09-053984 — 8.01
- 2009-10-14 0001157523-09-006877 — 2.02, 9.01
- 2009-07-15 0001157523-09-004878 — 2.02, 9.01
- 2009-04-15 0001157523-09-002687 — 2.02, 9.01
- 2009-01-21 0001157523-09-000340 — 2.02, 9.01
- 2008-11-12 0001193125-08-233181 — 5.02, 9.01
- 2008-10-14 0001157523-08-007999 — 2.02, 9.01
- 2008-07-15 0001157523-08-005504 — 2.02, 9.01
- 2008-04-15 0001157523-08-002896 — 2.02, 9.01
- 2008-01-22 0001157523-08-000408 — 2.02, 9.01
- 2007-10-16 0001193125-07-219356 — 5.03, 9.01
- 2007-10-16 0001157523-07-009850 — 2.02, 9.01
- 2007-07-17 0001157523-07-006912 — 2.02, 9.01
- 2007-04-17 0001157523-07-003630 — 2.02, 9.01
- 2007-04-03 0001179022-07-000068 — 5.02
- 2007-03-28 0001179022-07-000064 — 5.02
- 2007-02-23 0001193125-07-038337 — 5.02
- 2007-02-23 0001193125-07-038335 — 5.02
- 2007-01-30 0001193125-07-015912 — 5.02, 9.01
- 2007-01-26 0001193125-07-014234 — 5.02
- 2007-01-23 0001157523-07-000494 — 2.02, 9.01 — amendment of 0001157523-07-000481
- 2007-01-23 0001157523-07-000481 — 2.02, 9.01
- 2006-10-17 0001157523-06-009945 — 2.02, 9.01
- 2006-07-18 0001157523-06-006929 — 2.02, 9.01
- 2006-06-08 0001193125-06-126486 — 1.01, 9.01
- 2006-05-10 0001193125-06-107316 — 1.01, 9.01
- 2006-04-18 0001157523-06-003699 — 2.02, 9.01
- 2006-02-03 0001179022-06-000014 — 1.01
- 2006-01-27 0001157523-06-000754 — 5.02, 9.01
- 2006-01-24 0001157523-06-000551 — 2.02, 9.01
- 2005-10-18 0001157523-05-008826 — 2.02, 9.01
- 2005-07-19 0001193125-05-143958 — 1.01, 5.02, 9.01
- 2005-07-19 0001193125-05-143957 — 2.02, 9.01
- 2005-05-20 0001193125-05-112019 — 1.01, 9.01
- 2005-04-19 0001157523-05-003418 — 2.02, 9.01
- 2005-01-25 0001193125-05-010721 — 2.02, 9.01
- 2004-10-12 0001193125-04-169652 — 2.02, 9.01
- 2004-07-13 0001193125-04-116820 — 12, 7
- 2004-04-14 0001193125-04-061547 — 12, 7
- 2004-01-21 0001193125-04-006366 — 12, 7
- 2003-10-14 0001193125-03-061018 — 12, 5, 7
- 2003-07-15 0001193125-03-019292 — 7, 9
- 2003-04-15 0000931763-03-000968 — 7, 9
- 1996-09-12 0000931763-96-000667 — 5, 7

## late-filing notifications on or before 2021-05-06

- 2019-08-12 0001564590-19-031524 — NT 10-Q, for the period ended 2019-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001564590-21-024430:8k_2_02:1]
EX-99.1
2
adtn-ex991_6.htm
EX-99.1

[0001564590-21-024430:8k_2_02:2]
adtn-ex991_6.htm

[0001564590-21-024430:8k_2_02:3]
EXHIBIT 99.1

[0001564590-21-024430:8k_2_02:4]
ADTRAN, Inc. Reports Earnings for the First Quarter of 2021 and Declares Quarterly Cash Dividend

[0001564590-21-024430:8k_2_02:5]
HUNTSVILLE, Ala.--(May 5, 2021)—ADTRAN, Inc., (NASDAQ:ADTN), today announced financial results for the first quarter of 2021. For the quarter, revenue was $127.5 million. Net income for the first quarter of 2021 was $0.9 million and earnings per share, assuming dilution, was $0.02 per share. Non-GAAP net income was $6.3 million and non-GAAP earnings per share, assuming dilution, was $0.13 per share. Non-GAAP net income and non-GAAP earnings per share exclude stock-based compensation expense, acquisition-related expenses and amortizations, restructuring expenses, amortization of pension actuarial losses, change in valuation allowance related to our deferred tax assets, non-cash deferred compensation, asset impairments and other one-time adjustments. The reconciliations between GAAP net income (loss) and earnings (loss) per share to non-GAAP net income (loss) and non-GAAP earnings (loss) per share are set forth in the table provided below.

[0001564590-21-024430:8k_2_02:6]
ADTRAN Chairman and Chief Executive Officer Tom Stanton stated, “Our business continues to be driven by strong demand for our fiber access platforms, in-home service delivery platforms and software platforms with regional service providers across the U.S. and Europe. These service providers increasingly turn to ADTRAN for end-to-end solutions that simplify the deployment of fiber-based broadband services while providing an enhanced subscriber experience. The increased demand for ADTRAN’s solutions was highlighted by record product order bookings in the quarter.”

[0001564590-21-024430:8k_2_02:7]
The Company also announced that its Board of Directors declared a cash dividend for the first quarter of 2021. The quarterly cash dividend of $0.09 per common share is to be paid to the Company’s stockholders of record as of the close of business on May 20, 2021. The payment date will be June 3, 2021.

[0001564590-21-024430:8k_2_02:8]
The Company confirmed that it will hold a conference call to discuss its first quarter results on Thursday, May 6, 2021, at 9:30 a.m. Central Time. ADTRAN will webcast this conference call. To listen, simply visit ADTRAN’s Investor Relations site at www.adtran.com/investor approximately 10 minutes prior to the start of the call, click on the event “ADTRAN releases 1st Quarter Financial Results and Conference Call”, and click on the Webcast link.

[0001564590-21-024430:8k_2_02:9]
An online replay of the Company’s conference call, as well as the text of the Company's conference call, will be available on the Investor Relations site approximately 24 hours following the call and will remain available for at least 12 months. For more information, visit www.investors.adtran.com or email at investor.relations@adtran.com.

[0001564590-21-024430:8k_2_02:10]
About ADTRAN

[0001564590-21-024430:8k_2_02:11]
At ADTRAN, we believe amazing things happen when people connect. From the cloud edge to the subscriber edge, we help communications service providers around the world manage and scale services that connect people, places and things to advance human progress. Whether rural or urban, domestic or international, telco or cable, enterprise or residential—ADTRAN solutions optimize existing technology infrastructures and create new, multi-gigabit platforms that leverage cloud economics, data analytics, machine learning and open ecosystems—the future of global networking. Find more at ADTRAN.com, LinkedIn and Twitter.

[0001564590-21-024430:8k_2_02:12]
This press release contains forward-looking statements, generally identified by the use of words such as “believe,” “expect,” “intend,” “estimate,” “anticipate,” “will,” “may,” “could” and similar expressions, which forward-looking statements reflect management’s best judgment based on factors currently known. However, these statements involve risks and uncertainties, including: (i) risks and uncertainties related to the continued impact of the COVID-19 global pandemic, including the severity, geographic reach and duration of the pandemic and the speed of distribution and effectiveness of vaccines, which could lead to a decrease in demand for the Company’s products and services, and which has disrupted, and could lead to further disruptions in, the Company’s supply chain, adversely impacting the operations and financial condition of the Company and its customers; actions that have been taken and that may be taken by the Company, its customers, suppliers and counterparties in response to the pandemic, including the implementation of alternative work arrangements for employees, which may delay the timing of some orders and expected deliveries and which may impact the Company’s ability to mitigate inefficiencies, delays and additional costs in the Company’s product development, sales, marketing and customer service efforts; the legal, regulatory and administrative developments that occur at the federal, state and local levels and in foreign jurisdictions in response to the pandemic, including travel bans and restrictions, quarantines, shelter-in-place orders, and business limitations and shutdowns; potential disruptions, breaches, or other incidents affecting the proper operation, availability or security of the Company’s or its partners’ information systems; declines in revenues due to declining customer demand and deteriorating macroeconomic conditions; potential increased expenses related to labor, raw materials, freight or other expenditures; the impact of the COVID-19 pandemic on the Company’s liquidity, as well as risks associated with disruptions in the financial markets and the business of financial institutions as a result of the COVID-19 pandemic which could impact the Company from a financial perspective; (ii) those risks and uncertainties related to evolving U.S. and foreign laws and regulations regarding privacy, data protection and other matters, including uncertainty and potential additional compliance obligations arising from the Court of Justice of the European Union’s recent issuance of a decision that invalidated the EU-U.S. Privacy Shield framework as a basis for transfers of personal data from the EU to the U.S.; and (iii) the other risks detailed in the Company’s Annual Report on Form 10-K for the year ended December 31, 2020. These risks and uncertainties could cause actual results to differ materially from those in the forward-looking statements included in this press release.

[0001564590-21-024430:8k_2_02:13]
To provide additional transparency, we have disclosed in the table below non-GAAP operating income (loss), which has been reconciled to operating loss, and non-GAAP net income (loss) and non-GAAP earnings (loss) per share - basic and diluted, which have been reconciled to net income (loss) and earnings (loss) per share - basic and diluted, in each case as reported based on Generally Accepted Accounting Principles in the United States (“U.S. GAAP”). These non-GAAP financial measures exclude certain items which management believes are not reflective of the ongoing operating performance of the business. We believe this information is useful in providing period-to-period comparisons of the results of our ongoing operations. Additionally, these measures are used by management in our ongoing planning and annual budgeting processes. The presentation of non-GAAP operating income (loss), non-GAAP net income (loss) and non-GAAP earnings (loss) per share - basic and diluted, when combined with the U.S. GAAP presentation of operating loss, net income (loss) and earnings (loss) per share - basic and diluted, is beneficial to the overall understanding of ongoing operating performance of the Company.

[0001564590-21-024430:8k_2_02:14]
These non-GAAP financial measures are not prepared in accordance with, or an alternative for, U.S. GAAP and therefore should not be considered in isolation or as a substitution for analysis of our results as reported under U.S. GAAP. Additionally, our calculation of non-GAAP operating loss, non-GAAP net income (loss) and non-GAAP earnings (loss) per share - basic and diluted, may not be comparable to similar measures calculated by other companies.

[0001564590-21-024430:8k_2_02:15]
Condensed Consolidated Balance Sheets

[0001564590-21-024430:8k_2_02:16]
(Unaudited)

[0001564590-21-024430:8k_2_02:17]
(In thousands)

[0001564590-21-024430:8k_2_02:18]
|  | March 31, |  |  | December 31, |  |
|  | 2021 |  |  | 2020 |  |
| ASSETS |  |  |  |  |  |  |  |
| Current Assets |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 63,777 |  |  | $ | 60,161 |  |
| Restricted cash |  | 119 |  |  |  | 18 |  |
| Short-term investments |  | 4,092 |  |  |  | 3,131 |  |
| Accounts receivable, net |  | 103,201 |  |  |  | 98,827 |  |
| Other receivables |  | 22,669 |  |  |  | 21,531 |  |
| Inventory, net |  | 122,862 |  |  |  | 125,457 |  |
| Prepaid expenses and other current assets |  | 7,625 |  |  |  | 8,293 |  |
| Total Current Assets |  | 324,345 |  |  |  | 317,418 |  |
| Property, plant and equipment, net |  | 60,157 |  |  |  | 62,399 |  |
| Deferred tax assets, net |  | 9,448 |  |  |  | 9,869 |  |
| Goodwill |  | 6,968 |  |  |  | 6,968 |  |
| Intangibles, net |  | 22,384 |  |  |  | 23,470 |  |
| Other non-current assets |  | 26,195 |  |  |  | 25,425 |  |
| Long-term investments |  | 81,266 |  |  |  | 80,130 |  |
| Total Assets | $ | 530,763 |  |  | $ | 525,679 |  |
| LIABILITIES AND STOCKHOLDERS’ EQUITY |  |  |  |  |  |  |  |
| Current Liabilities |  |  |  |  |  |  |  |
| Accounts payable | $ | 55,476 |  |  | $ | 49,929 |  |
| Unearned revenue |  | 14,457 |  |  |  | 14,092 |  |
| Accrued expenses and other liabilities |  | 14,601 |  |  |  | 13,609 |  |
| Accrued wages and benefits |  | 15,856 |  |  |  | 15,262 |  |
| Income tax payable, net |  | 1,765 |  |  |  | 1,301 |  |
| Total Current Liabilities |  | 102,155 |  |  |  | 94,193 |  |
| Non-current unearned revenue |  | 7,040 |  |  |  | 6,888 |  |
| Pension liability |  | 17,579 |  |  |  | 18,664 |  |
| Deferred compensation liability |  | 26,658 |  |  |  | 25,866 |  |
| Other non-current liabilities |  | 6,956 |  |  |  | 7,124 |  |
| Total Liabilities |  | 160,388 |  |  |  | 152,735 |  |
| Stockholders' Equity |  | 370,375 |  |  |  | 372,944 |  |
| Total Liabilities and Stockholders' Equity | $ | 530,763 |  |  | $ | 525,679 |  |

[0001564590-21-024430:8k_2_02:19]
Condensed Consolidated Statements of Income (Loss)

[0001564590-21-024430:8k_2_02:20]
(Unaudited)

[0001564590-21-024430:8k_2_02:21]
(In thousands, except per share amounts)

[0001564590-21-024430:8k_2_02:22]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
|  |  | 2021 |  |  | 2020 |  |
| Revenue |  |  |  |  |  |  |  |  |
| Network Solutions |  | $ | 113,809 |  |  | $ | 97,372 |  |
| Services & Support |  |  | 13,724 |  |  |  | 17,151 |  |
| Total Revenue |  |  | 127,533 |  |  |  | 114,523 |  |
| Cost of Revenue |  |  |  |  |  |  |  |  |
| Network Solutions |  |  | 65,001 |  |  |  | 51,626 |  |
| Services & Support |  |  | 8,931 |  |  |  | 11,297 |  |
| Total Cost of Revenue |  |  | 73,932 |  |  |  | 62,923 |  |
| Gross Profit |  |  | 53,601 |  |  |  | 51,600 |  |
| Selling, general and administrative expenses |  |  | 27,435 |  |  |  | 26,620 |  |
| Research and development expenses |  |  | 27,501 |  |  |  | 29,859 |  |
| Asset impairments |  |  | — |  |  |  | 65 |  |
| Operating Loss |  |  | (1,335 | ) |  |  | (4,944 | ) |
| Interest and dividend income |  |  | 290 |  |  |  | 356 |  |
| Interest expense |  |  | (6 | ) |  |  | (1 | ) |
| Net investment gain (loss) |  |  | 996 |  |  |  | (10,877 | ) |
| Other income, net |  |  | 1,999 |  |  |  | 1,129 |  |
| Income (Loss) Before Income Taxes |  |  | 1,944 |  |  |  | (14,337 | ) |
| Income tax (expense) benefit |  |  | (1,048 | ) |  |  | 4,368 |  |
| Net Income (Loss) |  | $ | 896 |  |  | $ | (9,969 | ) |
| Weighted average shares outstanding – basic |  |  | 48,336 |  |  |  | 47,957 |  |
| Weighted average shares outstanding – diluted |  |  | 49,004 |  | (1) |  | 47,957 |  |
| Earnings (loss) per common share – basic |  | $ | 0.02 |  |  | $ | (0.21 | ) |
| Earnings (loss) per common share – diluted |  | $ | 0.02 |  | (1) | $ | (0.21 | ) |

[0001564590-21-024430:8k_2_02:23]
(1) Assumes exercise of dilutive stock awards calculated under the treasury stock method.

[0001564590-21-024430:8k_2_02:24]
Condensed Consolidated Statements of Cash Flows

[0001564590-21-024430:8k_2_02:25]
(Unaudited)

[0001564590-21-024430:8k_2_02:26]
(In thousands)

[0001564590-21-024430:8k_2_02:27]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
|  |  | 2021 |  |  | 2020 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income (loss) |  | $ | 896 |  |  | $ | (9,969 | ) |
| Adjustments to reconcile net income (loss) to net cash provided by (used in) operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 4,122 |  |  |  | 4,365 |  |
| (Gain) loss on investments |  |  | (1,161 | ) |  |  | 10,877 |  |
| Stock-based compensation expense |  |  | 1,807 |  |  |  | 1,791 |  |
| Other |  |  | 84 |  |  |  | 115 |  |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  |  | (4,762 | ) |  |  | 3,052 |  |
| Other receivables |  |  | (1,220 | ) |  |  | (6,707 | ) |
| Inventory, net |  |  | 1,893 |  |  |  | (1,598 | ) |
| Prepaid expenses and other assets |  |  | (417 | ) |  |  | 2,206 |  |
| Accounts payable, net |  |  | 5,629 |  |  |  | 2,712 |  |
| Accrued expenses and other liabilities |  |  | 3,317 |  |  |  | (6,680 | ) |
| Income taxes payable |  |  | 497 |  |  |  | (188 | ) |
| Net cash provided by (used in) operating activities |  |  | 10,685 |  |  |  | (24 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (741 | ) |  |  | (1,406 | ) |
| Proceeds from sales and maturities of available-for-sale investments |  |  | 10,087 |  |  |  | 46,440 |  |
| Purchases of available-for-sale investments |  |  | (11,350 | ) |  |  | (16,879 | ) |
| Acquisition of note receivable |  |  | — |  |  |  | (523 | ) |
| Net cash provided by (used in) investing activities |  |  | (2,004 | ) |  |  | 27,632 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Dividend payments |  |  | (4,361 | ) |  |  | (4,328 | ) |
| Proceeds from stock option exercises |  |  | 1,244 |  |  |  | — |  |
| Tax withholdings related to stock-based compensation settlements |  |  | (113 | ) |  |  | — |  |
| Repayment of bonds payable |  |  | — |  |  |  | (24,600 | ) |
| Net cash used in financing activities |  |  | (3,230 | ) |  |  | (28,928 | ) |
| Net increase (decrease) in cash, cash equivalents and restricted cash |  |  | 5,451 |  |  |  | (1,320 | ) |
| Effect of exchange rate changes |  |  | (1,734 | ) |  |  | (1,168 | ) |
| Cash, cash equivalents and restricted cash, beginning of period |  |  | 60,179 |  |  |  | 73,773 |  |
| Cash, cash equivalents and restricted cash, end of period |  | $ | 63,896 |  |  | $ | 71,285 |  |
| Supplemental Cash Flow Information: |  |  |  |  |  |  |  |  |
| Right-of-use assets obtained in exchange for lease obligations |  | $ | 248 |  |  | $ | 85 |  |
| Non-cash Investing Activities: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment included in accounts payable |  | $ | 199 |  |  | $ | 302 |  |

[0001564590-21-024430:8k_2_02:28]
Supplemental Information

[0001564590-21-024430:8k_2_02:29]
Reconciliation of Operating Loss to Non-GAAP Operating Income (Loss)

[0001564590-21-024430:8k_2_02:30]
(Unaudited)

[0001564590-21-024430:8k_2_02:31]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2021 |  |  | 2020 |  |  |
| Operating Loss |  | $ | (1,335 | ) |  | $ | (4,944 | ) |  |
| Acquisition related expenses, amortizations and adjustments |  |  | 1,045 |  | (1) |  | 1,358 |  | (5) |
| Stock-based compensation expense |  |  | 1,807 |  | (2) |  | 1,791 |  | (6) |
| Restructuring expenses |  |  | 301 |  | (3) |  | 553 |  | (7) |
| Deferred compensation adjustments |  |  | 556 |  | (4) |  | (3,460 | ) | (4) |
| Asset impairments |  |  | — |  |  |  | 65 |  | (8) |
| Non-GAAP Operating Income (Loss) |  | $ | 2,374 |  |  | $ | (4,637 | ) |  |

[0001564590-21-024430:8k_2_02:32]
(1) $0.6 million is included in selling, general and administrative expenses and $0.5 million is included in research and development expenses on the condensed consolidated statements of income (loss).

[0001564590-21-024430:8k_2_02:33]
(2) $0.1 million is included in total cost of revenue, $1.1 million is included in selling, general and administrative expenses and $0.6 million is included in research and development expenses on the condensed consolidated statements of income (loss).

[0001564590-21-024430:8k_2_02:34]
(3)  $0.1 million is included in selling, general and administrative expenses and $0.2 million is included in research and development expenses on the condensed consolidated statements of income (loss).

[0001564590-21-024430:8k_2_02:35]
(4) Includes non-cash change in fair value of equity investments held in the ADTRAN, Inc. Deferred Compensation Program for Employees, all of which is included in selling, general and administrative expenses on the condensed consolidated statements of income (loss).

[0001564590-21-024430:8k_2_02:36]
(5) $0.3 million is included in total cost of revenue, $0.6 million is included in selling, general and administrative expenses and $0.5 million is included in research and development expenses on the condensed consolidated statements of income (loss).

[0001564590-21-024430:8k_2_02:37]
(6) $0.1 million is included in total cost of revenue, $1.1 million is included in selling, general and administrative expenses and $0.6 million is included in research and development expenses on the condensed consolidated statements of income (loss).

[0001564590-21-024430:8k_2_02:38]
(7) $0.1 million is included in selling, general and administrative expenses and $0.5 million is included in research and development expenses on the condensed consolidated statements of income (loss).

[0001564590-21-024430:8k_2_02:39]
(8) Includes abandonment of certain information technology projects.

[0001564590-21-024430:8k_2_02:40]
Supplemental Information

[0001564590-21-024430:8k_2_02:41]
Reconciliation of Net Income (Loss) and Earnings (Loss) per Common Share – Basic and Diluted

[0001564590-21-024430:8k_2_02:42]
to Non-GAAP Net Income (Loss) and Non-GAAP Earnings (Loss) per Common Share – Basic and Diluted

[0001564590-21-024430:8k_2_02:43]
(Unaudited)

[0001564590-21-024430:8k_2_02:44]
|  |  | Three Months Ended March 31, |  |  |  |
|  |  | 2021 |  |  | 2020 |  |  |  |
| Net Income (Loss) |  | $ | 896 |  |  | $ | (9,969 | ) |  |  |
| Acquisition related expenses, amortizations and adjustments |  |  | 1,045 |  |  |  | 1,358 |  |  |  |
| Stock-based compensation expense |  |  | 1,807 |  |  |  | 1,791 |  |  |  |
| Restructuring expenses |  |  | 301 |  |  |  | 553 |  |  |  |
| Deferred compensation adjustments (1) |  |  | 268 |  |  |  | (1,787 | ) | (3) |  |
| Pension expense (2) |  |  | 278 |  |  |  | 237 |  |  |  |
| Valuation allowance |  |  | 2,685 |  |  |  | 6,090 |  |  |  |
| Asset impairments |  |  | — |  |  |  | 65 |  |  |  |
| Tax effect of adjustments to net income (loss) |  |  | (952 | ) |  |  | (578 | ) |  |  |
| Non-GAAP Net Income (Loss) |  | $ | 6,328 |  |  | $ | (2,240 | ) |  |  |
| Weighted average shares outstanding – basic |  |  | 48,336 |  |  |  | 47,957 |  |  |  |
| Weighted average shares outstanding – diluted |  |  | 49,004 |  |  |  | 47,957 |  |  |  |
| Earnings (loss) per common share - basic |  | $ | 0.02 |  |  | $ | (0.21 | ) |  |  |
| Earnings (loss) per common share - diluted |  | $ | 0.02 |  |  | $ | (0.21 | ) |  |  |
| Non-GAAP earnings (loss) per common share - basic |  | $ | 0.13 |  |  | $ | (0.05 | ) |  |  |
| Non-GAAP earnings (loss) per common share - diluted |  | $ | 0.13 |  |  | $ | (0.05 | ) |  |  |

[0001564590-21-024430:8k_2_02:45]
(1) Includes non-cash change in fair value of equity investments held in deferred compensation plans offered to certain employees.

[0001564590-21-024430:8k_2_02:46]
(2) Includes amortization of actuarial losses related to the Company's pension plan for employees in certain foreign countries.

[0001564590-21-024430:8k_2_02:47]
(3) Includes net investment gain of $1.5 million related to the out-of-period remeasurement to historical cost basis of certain long-term investments held in the Company's stock as part of one of the Company’s deferred compensation plans.
