# ADTN note change history — 0001564590-20-052017 → 0001564590-21-025123


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2021-05-06):
[0001564590-21-025123:note_history:1]
On March 31, 2021, the U.S. District for the Northern District of Alabama dismissed without prejudice a purported stockholder class action lawsuit, captioned Burbridge v. ADTRAN, Inc. et al, Docket No. 19-cv-09619 originally filed on October 17, 2019. This matter has been fully resolved by agreement among the parties, with no further action to be taken by the plaintiffs and each party bearing its own costs.

- added (2021-05-06):
[0001564590-21-025123:note_history:2]
On March 31, 2020, a shareholder derivative suit, captioned Johnson (Derivatively on behalf of ADTRAN) v. T. Stanton, M. Foliano, R. Shannon, and Board of Directors, case no. 5:20-cv-00447, was filed in the U.S. District Court of Northern Alabama against two of the Company’s current executive officers, one of its former executive officers and its Board of Directors. The derivative suit, which is purportedly brought on behalf of ADTRAN, claims that the defendants made materially false and misleading statements regarding, and/or failed to disclose  material  adverse  facts  about,  the  Company’s  business,  operations  and  prospects,  specifically  relating  to  the  Company’s  internal  control  over  financial reporting, excess and obsolete inventory reserves, financial results and demand from certain customers. These are similar allegations as the shareholder class action that was dismissed without prejudice by the Court on March 31, 2021, and fully resolved by mutual agreement of the parties on May 3, 2021. The parties to the shareholder derivative suit agreed to a joint stipulation requesting a stay in the proceedings due to the resolution of the shareholder class action that remains in effect at least until May 19, 2021. The Company and its defendants disagree with the claims made in the complaint, and the defendants intend to vigorously defend against this lawsuit. At this time, we are unable to predict the outcome of or estimate the possible loss or range of loss, if any, associated with this lawsuit.

- changed (2021-05-06):
[0001564590-21-025123:note_history:3]
In addition to the litigation described above, from time to time we are subject to or otherwise involved in various lawsuits, claims, investigations and legal proceedings that arise out of or are incidental to the conduct of our business (collectively, “Legal Matters”), including those relating to patent rights, employment matters, regulatory compliance matters, stockholder claims, and contractual and other commercial disputes. Such Legal Matters, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Additionally, an unfavorable outcome in any legal matter, including in a patent dispute, could require the Company to pay damages, entitle claimants to other relief, such as royalties, or could prevent the Company from selling some of its products in certain jurisdictions. While the Company cannot predict with certainty the results of the Legal Matters in which it is currently involved, the Company does not expect that the ultimate outcome of such Legal Matters will individually or in the aggregate have a material adverse effect on its business, results of operations, financial condition or cash flows.
  (was, 2020-11-06, similarity 0.9726):
[0001564590-20-052017:note_history:3]
In addition to the litigation described above, from time to time we are subject to or otherwise involved in various lawsuits, claims, investigations and legal proceedings that arise out of or are incidental to the conduct of our business (collectively, “Legal Matters”), including those relating to employment matters, patent rights, regulatory compliance matters, stockholder claims, and contractual and other commercial disputes. Such Legal Matters, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Additionally, an unfavorable outcome in any legal matter, including in a patent dispute, could require the Company to pay damages, entitle claimants to other relief, such as royalties, or could prevent the Company from selling some of its products in certain jurisdictions. While the Company cannot predict with certainty the results of the Legal Matters in which it is currently involved, the Company does not expect that the ultimate outcome of such Legal Matters will individually or in the aggregate have a material adverse effect on its business, results of operations, financial condition or cash flows.

- changed (2021-05-06):
[0001564590-21-025123:note_history:4]
Certain contracts, customers and jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of March 31, 2021 and December 31, 2020, we had commitments related to these bonds totaling $21.2 million and $15.2 million, respectively, which expire at various dates through August 2024. Although the triggering events vary from contract to contract, in general we would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which we believe is remote.
  (was, 2020-11-06, similarity 0.988):
[0001564590-20-052017:note_history:4]
Certain contracts, customers and jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of September 30, 2020 and December 31, 2019, we had commitments related to these bonds totaling $12.0 million and $9.3 million, respectively, which expire at various dates through August 2024. Although the triggering events vary from contract to contract, in general we would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which we believe is remote.

- changed (2021-05-06):
[0001564590-21-025123:note_history:5]
In June 2020, the Company entered into a letter of credit with a bank to guarantee performance obligations under a contract with a certain customer. The obligations under this customer contract will be performed over multiple years. We reached the maximum value of our minimum collateral requirement of $15.0 million during the three months ended March 31, 2021 as the Company reached certain milestones through the first quarter of 2021 as outlined in the customer contract. The letter of credit was secured by a pledge of a portion of the Company’s fixed-income securities, which totaled $18.2 million as of March 31, 2021, of which $0.1 million is included in restricted cash and $18.1 million is included in long-term investments on the Condensed Consolidated Balance Sheet. This pledged collateral value will fluctuate as the Company changes the mix of the pledged collateral between restricted cash and investments. Any shortfalls in the minimum collateral value are required to be restored by the Company from available cash and cash equivalents, short-term investments and/or long-term investments. The collateral under the letter of credit will be released when all obligations under the customer contract have been met. As of March 31, 2021, the Company was in compliance with all contractual requirements under the letter of credit.
  (was, 2020-11-06, similarity 0.7575):
[0001564590-20-052017:note_history:5]
In June 2020, the Company entered into a letter of credit with a bank to guarantee performance obligations under a contract with a certain customer. The obligations under the customer contract will be performed over multiple years. As of September 30, 2020, the Company was required to maintain a minimum collateral value of $4.5 million. The letter of credit was secured by a pledge of a portion of the Company’s fixed-income securities, which totaled $5.9 million as of September 30, 2020, of which $0.3 million is included in restricted cash and $5.6 million is included in long-term investments on the Condensed Consolidated Balance Sheet. This pledged collateral value will fluctuate as the Company changes the mix of the pledged collateral between restricted cash and investments, with an expected maximum value between $13.0 million and $15.0 million. On October 8, 2020, the Company entered into an amendment to the letter of credit, which increased the minimum collateral value to $9.0 million. The minimum collateral value is expected to continue to increase as the Company reaches certain milestones through the first quarter of 2021 as outlined in the customer contract. Any shortfalls in the minimum collateral value are required to be restored by the Company from available cash and cash equivalents, short-term investments and/or long-term investments. The collateral under the letter of credit will be released when all obligations under the customer contract have been met. As of September 30, 2020, the Company was in compliance with all contractual requirements under the letter of credit.

- changed (2021-05-06):
[0001564590-21-025123:note_history:6]
We have committed to invest up to an aggregate of $5.0 million in a private equity fund, of which $4.9 million has been applied as of March 31, 2021.
  (was, 2020-11-06, similarity 0.9231):
[0001564590-20-052017:note_history:6]
We have committed to invest up to an aggregate of $5.0 million in a private equity fund, of which $4.9 million has been contributed as of September 30, 2020.

- removed (2021-05-06):
[0001564590-20-052017:note_history:7]
On October 17, 2019, a purported stockholder class action lawsuit, captioned Burbridge v. ADTRAN, Inc. et al., Docket No. 19-cv-09619, was filed in the United States District Court for the Southern District of New York against the Company, two of its current executive officers and one of its former executive officers. The complaint alleges violations of federal securities laws and seeks unspecified compensatory damages on behalf of purported purchasers of ADTRAN securities between February 28, 2019 and October 9, 2019. The lawsuit claims that the defendants made materially false and misleading statements regarding, and/or failed to disclose material adverse facts about, the Company’s business, operations and prospects, specifically relating to the Company’s internal control over financial reporting, excess and obsolete inventory reserves, financial results and demand from certain customers. The lawsuit was transferred to the U.S. District Court for the Northern District of Alabama on January 7, 2020, and co-lead plaintiffs have been appointed to represent the putative class. The plaintiffs filed an amended complaint on April 30, 2020. The defendants filed a motion to dismiss the amended complaint on June 17, 2020. The plaintiffs filed an opposition brief to the defendants’ motion to dismiss on July 17, 2020. The defendants filed a reply to the plaintiffs’ brief on August 17, 2020. The motion to dismiss remains under review by the Court. We deny the allegations in the complaint, as amended, and intend to vigorously defend against this lawsuit. At this time, we are unable to predict the outcome of or estimate the possible loss or range of loss, if any, associated with this lawsuit.

- removed (2021-05-06):
[0001564590-20-052017:note_history:8]
On March 31, 2020, a shareholder derivative suit, captioned Johnson (Derivatively on behalf of ADTRAN) v. T. Stanton, M. Foliano, R. Shannon, and Board of Directors, case no. 5:20-cv-00447, was filed in the U.S. District Court of Northern Alabama against two of the Company’s current executive officers, one of its former executive officers and its Board of Directors. The derivative suit, which is purportedly brought on behalf of ADTRAN, makes similar allegations as the shareholder class action and accuses the directors and officers of breaches of fiduciary duty in connection with those allegations. On June 7, 2020, the Court entered an order staying the derivative litigation pending resolution of the motion to dismiss in the securities class action. The Company and its defendants disagree with the claims made in the complaint, and the defendants intend to vigorously defend against this lawsuit. At this time, we are unable to predict the outcome of or estimate the possible loss or range of loss, if any, associated with this lawsuit.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-05-06):
[0001564590-21-025123:note_history:9]
The accompanying unaudited condensed consolidated financial statements of ADTRAN®, Inc. and its subsidiaries (“ADTRAN”, the “Company”, “we”, “our” or “us”) have been prepared pursuant to the rules and regulations of the Securities and Exchange Commission (the “SEC”) applicable to interim financial information presented in Quarterly Reports on Form 10-Q. Accordingly, certain information and notes required by generally accepted accounting principles in the United States of America (“U.S. GAAP”) for complete financial statements are not included herein. The December 31, 2020 Condensed Consolidated Balance Sheet is derived from audited financial statements but does not include all disclosures required by U.S. GAAP.
  (was, 2020-11-06, similarity 0.9372):
[0001564590-20-052017:note_history:9]
The accompanying unaudited condensed consolidated financial statements of ADTRAN®, Inc. and its subsidiaries (“ADTRAN”, the “Company”, “we”, “our” or “us”) have been prepared pursuant to the rules and regulations of the Securities and Exchange Commission (the “SEC”) applicable to interim financial information presented in Quarterly Reports on Form 10-Q. Accordingly, certain information and notes required by generally accepted accounting principles in the United States of America (“U.S. GAAP”) for complete financial statements are not included herein. The Condensed Consolidated Balance Sheet as of December 31, 2019 is derived from audited financial statements but does not include all disclosures required by U.S. GAAP.

- changed (2021-05-06):
[0001564590-21-025123:note_history:10]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenue and expense during the reporting period. The more significant estimates include excess and obsolete inventory reserves, warranty reserves, customer rebates, determination and accrual of deferred revenue components of multiple element sales agreements, estimated costs to complete obligations associated with deferred and accrued revenues and network installations, estimated income tax provision and income tax contingencies, fair value of stock-based compensation, assessment of goodwill and other intangibles for impairment, estimated lives of intangible assets, estimated pension, and liability and fair value of investments, evaluation of other-than-temporary declines in the value of investments and the allowance for current expected credit losses. Actual amounts could differ significantly from these estimates.
  (was, 2020-11-06, similarity 0.8796):
[0001564590-20-052017:note_history:10]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenue and expense during the reporting period. The more significant estimates include excess and obsolete inventory reserves, warranty reserves, customer rebates, determination and accrual of deferred revenue components of multi-element sales agreements, estimated costs to complete obligations associated with deferred and accrued revenues and network installations, estimated income tax provision and income tax contingencies, fair value of stock-based compensation, assessment of goodwill and other intangibles for impairment, estimated lives of intangible assets, estimated pension liability and fair value of investments. Actual amounts could differ significantly from these estimates.

- changed (2021-05-06):
[0001564590-21-025123:note_history:11]
We assessed certain accounting matters that generally require consideration of forecasted financial information in context with the information reasonably available to us and the unknown future impacts of the novel coronavirus (“COVID-19”) as of March 31, 2021 and through the date of this report. The accounting matters assessed included, but were not limited to, the allowance for doubtful accounts, stock-based compensation, carrying value of goodwill, intangibles and other long-lived assets, financial assets, valuation allowances for tax assets and revenue recognition. While there was not a material impact to our consolidated financial statements as of and for the quarter ended March 31, 2021 resulting from these assessments, future assessments related to the COVID-19 pandemic, as well as other factors, could result in material impacts to our consolidated financial statements in future reporting periods.
  (was, 2020-11-06, similarity 0.8232):
[0001564590-20-052017:note_history:11]
We assessed certain accounting matters that generally require consideration of forecasted financial information in context with the information reasonably available to us and the unknown future impacts of the novel coronavirus (“COVID-19”) as of September 30, 2020 and through the date of this report. The accounting matters assessed included, but were not limited to, the allowance for doubtful accounts, current estimated credit losses, stock-based compensation, excess and obsolete inventory reserves, carrying value of goodwill, intangibles and other long-lived assets, financial assets, valuation allowances for tax assets and revenue recognition. While there was not a material impact to our condensed consolidated financial statements as of and for the three and nine month periods ended September 30, 2020 resulting from these assessments, future conditions related to the magnitude and duration of the COVID-19 pandemic, as well as other factors, could result in material impacts to our consolidated financial statements in future reporting periods.

- changed (2021-05-06):
[0001564590-21-025123:note_history:12]
Correction of an Immaterial Misstatement
  (was, 2020-11-06, similarity 0.9487):
[0001564590-20-052017:note_history:12]
Correction of Immaterial Misstatements

- changed (2021-05-06):
[0001564590-21-025123:note_history:13]
During the three months ended March 31, 2020, it was determined that certain investments held in the Company’s stock for a deferred compensation plan accounted for as a Rabbi trust were incorrectly classified as Long-term investments with the fair value of such investments incorrectly marked to market at each period end rather than classified as Treasury stock held at historical cost. This plan has been in existence since 2011. The Company corrected this misstatement as an out-of-period adjustment in the three months ended March 31, 2020 by remeasuring the investment assets to their historical cost basis through the recording of a Net investment gain of $1.5 million in the unaudited Condensed Consolidated Statement of Income (Loss) and then correcting the classification by decreasing the Long-term investment balance at its remeasured cost basis of $2.8 million to Treasury stock in the unaudited Condensed Consolidated Balance Sheet as of March 31, 2020. Management has determined that this misstatement was not material to any of its previously issued financial statements and that the correction of the misstatement was not material to the Company’s 2020 annual financial results on either a quantitative or qualitative basis.
  (was, 2020-11-06, similarity 0.9252):
[0001564590-20-052017:note_history:13]
During the first quarter of 2020, it was determined that certain investments held in the Company’s stock for a deferred compensation plan accounted for as a Rabbi trust were incorrectly classified as long-term investments with the fair value of such investments incorrectly marked to market at each period end rather than classified as treasury stock held at historical cost. This plan has been in existence since 2011. The Company corrected this misstatement as an out-of-period adjustment in the three months ended March 31, 2020 by remeasuring the investment assets to their historical cost basis through the recording of a net investment gain of $1.5 million in the unaudited Condensed Consolidated Statement of Income (Loss) and then correcting the classification by decreasing the long-term investment balance at its remeasured cost basis of $2.8 million to treasury stock in the unaudited Condensed Consolidated Balance Sheet as of March 31, 2020. Management has determined that this misstatement was not material to any of its previously issued financial statements and that correction of the misstatement is also not expected to be material to the 2020 annual financial results on either a quantitative or qualitative basis.

- changed (2021-05-06):
[0001564590-21-025123:note_history:14]
We recently adopted the following accounting standards, which had the following impacts on our consolidated financial statements:
  (was, 2020-11-06, similarity 0.9302):
[0001564590-20-052017:note_history:14]
During 2020, we adopted the following accounting standards, which had the following impacts on our consolidated financial statements:

- added (2021-05-06):
[0001564590-21-025123:note_history:15]
In August 2018, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2018-14, Compensation – Retirement Benefits – Defined Benefit Plans – General (Subtopic 715-20): Disclosure Framework – Changes to the Disclosure Requirements for Defined Benefit Plans, which makes changes to and clarifies the disclosure requirements related to defined benefit pension and other postretirement plans. ASU 2018-14 requires additional disclosures related to the reasons for significant gains and losses affecting the benefit obligation and an explanation of any other significant changes in the benefit obligation or plan assets that are not otherwise apparent in other disclosures required by Accounting Standards Codification (“ASC”) 715. ASU 2018-14 also clarifies the guidance in ASC 715 to require disclosure of the projected benefit obligation (“PBO”) and fair value of plan assets for pension plans with PBOs in excess of plan assets and the accumulated benefit obligation (“ABO”) and fair value of plan assets for pension plans with ABOs in excess of plan assets. ASU 2018-14 became effective for public business entities for fiscal years ending after December 15, 2020. The adoption of this standard did not have a material effect on the disclosures in the condensed consolidation financial statements.

- changed (2021-05-06):
[0001564590-21-025123:note_history:16]
In December 2019, the FASB issued ASU 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes, which simplifies the accounting for income taxes by removing various exceptions, such as the exception to the incremental approach for intra-period tax allocation when there is a loss from continuing operations and income or a gain from other items. The amendments in this update also simplify the accounting for income taxes related to income-based franchise taxes and require that an entity reflect enacted tax laws or rates in the annual effective tax rate computation in the interim period that includes the enactment date. The Company early adopted ASU 2019-12 on April 1, 2020, which was applied on a prospective basis as if the Company adopted the standard on January 1, 2020. The Company early adopted the standard to take advantage of the simplification of rules for income taxes on intra-period tax allocations. Specifically, the adoption of this standard resulted in the recognition of approximately $0.1 million of tax benefit in other comprehensive income (loss) for the three months ended March 31, 2020, that otherwise would have been recognized in continuing operations had the intra-period tax allocation been completed. There were no other impacts from this standard on the Condensed Consolidated Balance Sheets, Condensed Consolidated Statements of Income (Loss) or Condensed Consolidated Statements of Cash Flows.
  (was, 2020-11-06, similarity 0.9864):
[0001564590-20-052017:note_history:16]
In December 2019, the FASB issued ASU 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes, which simplifies the accounting for income taxes by removing various exceptions, such as the exception to the incremental approach for intra-period tax allocation when there is a loss from continuing operations and income or a gain from other items. The amendments in this update also simplify the accounting for income taxes related to income-based franchise taxes and require that an entity reflect enacted tax laws or rates in the annual effective tax rate computation in the interim period that includes the enactment date. The Company early adopted ASU 2019-12 on April 1, 2020, which was applied on a prospective basis as if the Company adopted the standard on January 1, 2020. The Company early adopted the standard to take advantage of the simplification of rules for income taxes on intra-period tax allocations. Specifically, the adoption of this standard resulted in the recognition of approximately $0.1 million of tax benefit in other comprehensive income (loss), that otherwise would have been recognized in continuing operations had the intra-period tax allocation been completed. There were no other impacts from this standard on the Condensed Consolidated Balance Sheets, Condensed Consolidated Statements of Income (Loss) or Condensed Consolidated Statements of Cash Flows.

- added (2021-05-06):
[0001564590-21-025123:note_history:17]
There are currently no recent accounting pronouncements that have not yet been adopted and that would have a material effect, once adopted, on the Condensed Consolidated Balance Sheets, Condensed Consolidated Statements of Income (Loss) or Condensed Consolidated Statements of Cash Flows.

- removed (2021-05-06):
[0001564590-20-052017:note_history:18]
During the three months ended June 30, 2019, the Company determined that there was an immaterial misstatement of its excess and obsolete inventory reserves in its previously issued annual and interim financial statements. The Company corrected this misstatement by recognizing a $0.8 million out-of-period adjustment during the three months ended June 30, 2019, which increased its excess and obsolete inventory reserve and cost of goods sold for the period. For the six months ended June 30, 2019, the out-of-period adjustment was a cumulative $0.2 million reduction in its excess and obsolete inventory reserve and cost of goods sold. In addition, the Company determined that a $1.0 million cash inflow related to an insurance recovery was incorrectly classified as a cash flow from operations instead of a cash flow from investing activities within the unaudited Condensed Consolidated Statement of Cash Flows for the three months ended March 31, 2019. The Company corrected this misstatement in the Unaudited Condensed Consolidated Statement of Cash Flows for the nine months ended September 30, 2019 to correctly reflect the $1.0 million insurance recovery as a cash inflow from investing activities. Management determined that these misstatements were not material to any of its previously issued financial statements on both a quantitative and qualitative basis.

- removed (2021-05-06):
[0001564590-20-052017:note_history:19]
In June 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. ASU 2016-13 requires the measurement and recognition of expected credit losses for financial instruments held at amortized cost. In November 2018, the FASB issued ASU 2018-19, Codification Improvements to Topic 326 Financial Instruments – Credit Losses, which clarifies that receivables arising from operating leases are not within the scope of the credit losses standard, but rather should be accounted for in accordance with the standard for leases. In April 2019, the FASB issued ASU 2019-04, Codification Improvements to Topic 326, Financial Instruments–Credit Losses, Topic 815, Derivatives and Hedging, and Topic 825, Financial Instruments, which clarifies the accounting for transfers between classifications of debt securities and clarifies that entities should include expected recoveries on financial assets in the calculation of the current expected credit loss allowance. In addition, renewal options that are not unconditionally cancelable should be considered in the determination of expected credit losses. In May 2019, the FASB issued ASU 2019-05, Financial Instruments – Credit Losses (Topic 326): Targeted Transition Relief, which amends ASU 2016-13 to allow companies, upon adoption, to elect the fair value option on financial instruments that were previously recorded at amortized cost if they meet certain criteria. In November 2019, the FASB issued ASU 2019-11, Codification Improvements to Topic 326, Financial Instruments – Credit Losses, which makes various narrow-scope amendments to the new credit losses standard, such as providing disclosure relief for accrued interest receivables. All of these ASUs were codified as part of Accounting Standards Codifications (“ASC”) Topic 326 and were effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. The Company adopted this standard on January 1, 2020, using a modified-retrospective approach and, therefore, elected to carry forward legacy disclosures for comparative periods and did not adjust the comparative period financial information. Additionally, the Company made an accounting policy election, at the class of financing receivable, not to measure the allowance for credit losses for accrued interest receivables, as the Company writes off the uncollectable accrued interest receivable by reversing any previously recorded interest income in a timely manner (as soon as these amounts are determined to be uncollectable). The adoption of this standard did not have a material effect on our consolidated financial statements. See Note 19 for additional information.

- removed (2021-05-06):
[0001564590-20-052017:note_history:20]
In January 2017, the FASB issued ASU 2017-04, Intangibles – Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment. ASU 2017-04 simplifies the measurement of goodwill by eliminating step 2 of the goodwill impairment test. Under ASU 2017-04, entities are required to compare the fair value of a reporting unit to its carrying amount and recognize an impairment charge for the amount by which the carrying amount exceeds the reporting unit’s fair value. ASU 2017-04 was effective for annual or interim impairment tests performed in fiscal years beginning after December 15, 2019. The Company adopted ASU 2017-04 on January 1, 2020, and the amendments were applied prospectively. The adoption of this standard did not have a material effect on our consolidated financial statements.

- removed (2021-05-06):
[0001564590-20-052017:note_history:21]
In August 2018, the FASB issued ASU 2018-13, Fair Value Measurement (Topic 820): Disclosure Framework – Changes to the Disclosure Requirements for Fair Value Measurement, which changes the fair value measurement disclosure requirements of ASC 820, Fair Value Measurement. The amendments in this ASU are the result of a broader disclosure project, Concepts Statement No. 8 — Conceptual Framework for Financial Reporting — Chapter 8 — Notes to Financial Statements, which the FASB finalized on August 28, 2018. The FASB used the guidance in the Concepts Statement to improve the effectiveness of ASC 820’s disclosure requirements. ASU 2018-13 provides users of financial statements with information about assets and liabilities measured at fair value in the statement of financial position or disclosed in the notes to the financial statements. More specifically, ASU 2018-13 requires disclosures about the valuation techniques and inputs that are used to arrive at measures of fair value, including judgments and assumptions that are made in determining fair value. In addition, ASU 2018-13 requires disclosures regarding the uncertainty in the fair value measurements as of the reporting date and how changes in fair value measurements affect performance and cash flows. The Company adopted ASU 2018-13 on January 1, 2020, and the adoption of this standard did not have a material effect on our consolidated financial statements.

- removed (2021-05-06):
[0001564590-20-052017:note_history:22]
In August 2018, the FASB issued ASU 2018-15, Intangibles – Goodwill and Other – Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract.  ASU 2018-15 clarifies certain aspects of ASU 2015-05, Customer’s Accounting for Fees Paid in a Cloud Computing Arrangement. Specifically, ASU 2018-15 aligns the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementations costs incurred to develop or obtain internal use software. The Company adopted ASU 2018-15 on January 1, 2020, retrospectively. The adoption of this standard resulted in a reclassification of $5.6 million from property, plant and equipment to other assets for certain previously capitalized costs related to information technology implementation projects that had not yet been placed in service on the Condensed Consolidated Balance Sheets as of September 30, 2020 and December 31, 2019. There was no impact to previously reported net cash provided by (used in) operations on the statement of cash flows and no impact to the statements of income (loss) as no portion of the capitalized asset was depreciated in prior periods.

- removed (2021-05-06):
[0001564590-20-052017:note_history:23]
The following table illustrates the impact of adoption of ASU 2018-15 on the Condensed Consolidated Balance Sheet as of December 31, 2019:

- removed (2021-05-06):
[0001564590-20-052017:note_history:24]
|  |  | As of December 31, 2019 |  |
| (In thousands) |  | Pre-Adoption |  |  | Effect of Adoption |  |  | As Presented Now |  |
| Condensed Consolidated Balance Sheet |  |  |  |  |  |  |  |  |  |  |  |  |
| Property, plant and equipment, net |  | $ | 73,708 |  |  | $ | (5,622 | ) |  | $ | 68,086 |  |
| Other assets |  | $ | 14,261 |  |  | $ | 5,622 |  |  | $ | 19,883 |  |

- removed (2021-05-06):
[0001564590-20-052017:note_history:25]
There was no impact upon adoption of ASU 2018-15 on the Condensed Consolidated Statement of Loss for the three and nine months ended September 30, 2019 and the Condensed Consolidated Statement of Cash Flows for nine months ended September 30, 2019 as outlined in the following tables:

- removed (2021-05-06):
[0001564590-20-052017:note_history:26]
|  |  | Three months ended September 30, 2019 |  |
| (In thousands) |  | Pre-Adoption |  |  | Effect of Adoption |  |  | As Presented Now |  |
| Condensed Consolidated Statement of Loss |  |  |  |  |  |  |  |  |  |  |  |  |
| Net loss |  | $ | (46,123 | ) |  | $ | — |  |  | $ | (46,123 | ) |

- removed (2021-05-06):
[0001564590-20-052017:note_history:27]
|  |  | Nine months ended September 30, 2019 |  |
| (In thousands) |  | Pre-Adoption |  |  | Effect of Adoption |  |  | As Presented Now |  |
| Condensed Consolidated Statement of Loss |  |  |  |  |  |  |  |  |  |  |  |  |
| Net loss |  | $ | (41,358 | ) |  | $ | — |  |  | $ | (41,358 | ) |
| Condensed Consolidated Statement of Cash Flows |  |  |  |  |  |  |  |  |  |  |  |  |
| Net cash provided by operating activities |  | $ | 10,082 |  |  | $ | — |  |  | $ | 10,082 |  |

- removed (2021-05-06):
[0001564590-20-052017:note_history:28]
The following table presents the capitalized implementation costs incurred with hosting arrangements, included in other assets on the Condensed Consolidated Balance Sheet, as of September 30, 2020:

- removed (2021-05-06):
[0001564590-20-052017:note_history:29]
| (In thousands) |  | September 30, 2020 |  |
| Implementation costs - hosting arrangements |  | $ | 10,455 |  |
| Less: accumulated amortization |  |  | — |  |
| Implementation costs - hosting arrangements, net |  | $ | 10,455 |  |

- removed (2021-05-06):
[0001564590-20-052017:note_history:30]
In August 2018, the FASB issued ASU 2018-14, Compensation – Retirement Benefits – Defined Benefit Plans – General (Subtopic 715-20): Disclosure Framework – Changes to the Disclosure Requirements for Defined Benefit Plans, which makes changes to and clarifies the disclosure requirements related to defined benefit pension and other postretirement plans. ASU 2018-14 requires additional disclosures related to the reasons for significant gains and losses affecting the benefit obligation and an explanation of any other significant changes in the benefit obligation or plan assets that are not otherwise apparent in other disclosures required by ASC 715. ASU 2018-14 also clarifies the guidance in ASC 715 to require disclosure of the projected benefit obligation (“PBO”) and fair value of plan assets for pension plans with PBOs in excess of plan assets and the accumulated benefit obligation (“ABO”) and fair value of plan assets for pension plans with ABOs in excess of plan assets. ASU 2018-14 is effective for public business entities for fiscal years ending after December 15, 2020. The Company is currently evaluating the impact this guidance will have on its related disclosures.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2021-05-06):
[0001564590-21-025123:note_history:31]
13. REVOLVING CREDIT AGREEMENT

- added (2021-05-06):
[0001564590-21-025123:note_history:32]
On November 4, 2020, the Company, as borrower, entered into a Revolving Credit and Security Agreement and related Promissory Note (together, the “Revolving Credit Agreement”) with Cadence Bank, N.A., as lender (the “Lender”). The Revolving Credit Agreement provides the Company with a new $10.0 million secured revolving credit facility. Loans under the Revolving Credit Agreement will bear interest at a rate equal to 1.50% over the screen rate as obtained by Reuter’s, Bloomberg  or  another  commercially  available  source  as  may  be  designated  by  the  Lender  from  time  to  time;  provided,  however,  that  in  no  event  shall  the applicable rate of interest under the Revolving Credit Agreement be less than 1.50% per annum. Such loans are secured by all of the cash, securities, securities entitlements  and  investment  property  in  a  certain  bank  account,  as  outlined  in  the  Revolving  Credit  Agreement,  at  a  maximum  loan-to-value  ratio  of  75% determined by dividing the full commitment amount under the Revolving Credit Agreement on the date of testing, determined by the Lender each fiscal quarter, by the market value of the collateral. The Revolving Credit Agreement matures on November 4, 2021, subject to earlier termination upon the occurrence of certain events of default. The Company had not made any draws under the Revolving Credit Agreement as of March 31, 2021.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-05-06):
[0001564590-21-025123:note_history:33]
The following debt securities and other investments were included on the Condensed Consolidated Balance Sheets and recorded at fair value:
  (was, 2020-11-06, similarity 0.932):
[0001564590-20-052017:note_history:33]
As of December 31, 2019, the following debt securities and other investments were included on the Condensed Consolidated Balance Sheet and recorded at fair value:

- changed (2021-05-06):
[0001564590-21-025123:note_history:34]
|  |  | As of March 31,2021 |  |
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 14,176 |  |  | $ | 68 |  |  | $ | (13 | ) |  | $ | 14,231 |  |
| Municipal fixed-rate bonds |  |  | 2,600 |  |  |  | 25 |  |  |  | — |  |  |  | 2,625 |  |
| Asset-backed bonds |  |  | 5,772 |  |  |  | 42 |  |  |  | (2 | ) |  |  | 5,812 |  |
| Mortgage/Agency-backed bonds |  |  | 11,775 |  |  |  | 92 |  |  |  | (22 | ) |  |  | 11,845 |  |
| U.S. government bonds |  |  | 9,704 |  |  |  | 66 |  |  |  | (1 | ) |  |  | 9,769 |  |
| Foreign government bonds |  |  | 1,331 |  |  |  | 3 |  |  |  | (2 | ) |  |  | 1,332 |  |
| Other |  |  | 533 |  |  |  | — |  |  |  | — |  |  |  | 533 |  |
| Available-for-sale debt securities held at fair value |  | $ | 45,891 |  |  | $ | 296 |  |  | $ | (40 | ) |  | $ | 46,147 |  |
  (was, 2020-11-06, similarity 0.8152):
[0001564590-20-052017:note_history:34]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 9,304 |  |  | $ | 80 |  |  | $ | — |  |  | $ | 9,384 |  |
| Municipal fixed-rate bonds |  |  | 930 |  |  |  | — |  |  |  | — |  |  |  | 930 |  |
| Asset-backed bonds |  |  | 6,867 |  |  |  | 26 |  |  |  | (3 | ) |  |  | 6,890 |  |
| Mortgage/Agency-backed bonds |  |  | 6,944 |  |  |  | 26 |  |  |  | (8 | ) |  |  | 6,962 |  |
| U.S. government bonds |  |  | 12,311 |  |  |  | 21 |  |  |  | (9 | ) |  |  | 12,323 |  |
| Foreign government bonds |  |  | 372 |  |  |  | — |  |  |  | (1 | ) |  |  | 371 |  |
| Variable-rate demand notes |  |  | 800 |  |  |  | — |  |  |  | — |  |  |  | 800 |  |
| Available-for-sale debt securities held at fair value |  | $ | 37,528 |  |  | $ | 153 |  |  | $ | (21 | ) |  | $ | 37,660 |  |

- changed (2021-05-06):
[0001564590-21-025123:note_history:35]
|  |  | As of December 31, 2020 |  |
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 11,762 |  |  | $ | 123 |  |  | $ | — |  |  | $ | 11,885 |  |
| Municipal fixed-rate bonds |  |  | 2,854 |  |  |  | 30 |  |  |  | — |  |  |  | 2,884 |  |
| Asset-backed bonds |  |  | 6,634 |  |  |  | 74 |  |  |  | — |  |  |  | 6,708 |  |
| Mortgage/Agency-backed bonds |  |  | 11,536 |  |  |  | 114 |  |  |  | (6 | ) |  |  | 11,644 |  |
| U.S. government bonds |  |  | 9,763 |  |  |  | 112 |  |  |  | — |  |  |  | 9,875 |  |
| Foreign government bonds |  |  | 1,334 |  |  |  | 4 |  |  |  | (1 | ) |  |  | 1,337 |  |
| Commercial Paper |  |  | 250 |  |  |  | — |  |  |  | — |  |  |  | 250 |  |
| Other |  |  | 533 |  |  |  | — |  |  |  | — |  |  |  | 533 |  |
| Available-for-sale debt securities held at fair value |  | $ | 44,666 |  |  | $ | 457 |  |  | $ | (7 | ) |  | $ | 45,116 |  |
  (was, 2020-11-06, similarity 0.9007):
[0001564590-20-052017:note_history:35]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 12,861 |  |  | $ | 149 |  |  | $ | — |  |  | $ | 13,010 |  |
| Municipal fixed-rate bonds |  |  | 3,093 |  |  |  | 32 |  |  |  | (1 | ) |  |  | 3,124 |  |
| Asset-backed bonds |  |  | 8,472 |  |  |  | 115 |  |  |  | — |  |  |  | 8,587 |  |
| Mortgage/Agency-backed bonds |  |  | 10,964 |  |  |  | 127 |  |  |  | (11 | ) |  |  | 11,080 |  |
| U.S. government bonds |  |  | 7,096 |  |  |  | 174 |  |  |  | — |  |  |  | 7,270 |  |
| Foreign government bonds |  |  | 1,032 |  |  |  | 3 |  |  |  | — |  |  |  | 1,035 |  |
| Commercial paper |  |  | 324 |  |  |  | 1 |  |  |  | — |  |  |  | 325 |  |
| Variable-rate demand notes |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Other |  |  | 442 |  |  |  | — |  |  |  | — |  |  |  | 442 |  |
| Available-for-sale debt securities held at fair value |  | $ | 44,284 |  |  | $ | 601 |  |  | $ | (12 | ) |  | $ | 44,873 |  |

- changed (2021-05-06):
[0001564590-21-025123:note_history:36]
The contractual maturities related to debt securities and other investments were as follows:
  (was, 2020-11-06, similarity 0.91):
[0001564590-20-052017:note_history:36]
As of September 30, 2020, contractual maturities related to debt securities and other investments were as follows:

- changed (2021-05-06):
[0001564590-21-025123:note_history:37]
|  |  | As of March 31,2021 |  |
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset- backed bonds |  |  | Mortgage / Agency- backed bonds |  |  | U.S. government bonds |  | Foreign government bonds |  |  | Other |  |
| Less than one year |  | $ | 1,323 |  |  | $ | 357 |  |  | $ | 16 |  |  | $ | 296 |  |  | $ | 1,282 |  | $ | 75 |  |  | $ | 533 |  |
| One to two years |  |  | 3,758 |  |  |  | 1,130 |  |  |  | 13 |  |  |  | 2,090 |  |  |  | 6,831 |  |  | 460 |  |  |  | — |  |
| Two to three years |  |  | 7,509 |  |  |  | 1,138 |  |  |  | 272 |  |  |  | 1,740 |  |  |  | 1,656 |  |  | 497 |  |  |  | — |  |
| Three to five years |  |  | 1,641 |  |  |  | — |  |  |  | 3,445 |  |  |  | 175 |  |  |  | — |  |  | 300 |  |  |  | — |  |
| Five to ten years |  |  | — |  |  |  | — |  |  |  | 1,143 |  |  |  | 2,457 |  |  |  | — |  |  | — |  |  |  | — |  |
| More than ten years |  |  | — |  |  |  | — |  |  |  | 923 |  |  |  | 5,087 |  |  |  | — |  |  | — |  |  |  | — |  |
| Total |  | $ | 14,231 |  |  | $ | 2,625 |  |  | $ | 5,812 |  |  | $ | 11,845 |  |  | $ | 9,769 |  | $ | 1,332 |  |  | $ | 533 |  |
  (was, 2020-11-06, similarity 0.8584):
[0001564590-20-052017:note_history:37]
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset- backed bonds |  |  | Mortgage/ Agency- backed bonds |  |  | U.S. government bonds |  |  | Foreign government bonds |  |  | Commercial paper |  |  | Other |  |
| Less than one year |  | $ | 2,900 |  |  | $ | 737 |  |  | $ | 696 |  |  | $ | 208 |  |  | $ | 500 |  |  | $ | 75 |  |  | $ | 325 |  |  | $ | 442 |  |
| One to two years |  |  | 3,752 |  |  |  | 1,183 |  |  |  | 956 |  |  |  | 1,256 |  |  |  | 826 |  |  |  | 463 |  |  |  | — |  |  |  | — |  |
| Two to three years |  |  | 6,122 |  |  |  | 908 |  |  |  | 615 |  |  |  | 2,775 |  |  |  | 5,492 |  |  |  | 497 |  |  |  | — |  |  |  | — |  |
| Three to five years |  |  | 236 |  |  |  | 296 |  |  |  | 4,817 |  |  |  | 1,079 |  |  |  | 452 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Five to ten years |  |  | — |  |  |  | — |  |  |  | 946 |  |  |  | 1,507 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| More than ten years |  |  | — |  |  |  | — |  |  |  | 557 |  |  |  | 4,255 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 13,010 |  |  | $ | 3,124 |  |  | $ | 8,587 |  |  | $ | 11,080 |  |  | $ | 7,270 |  |  | $ | 1,035 |  |  | $ | 325 |  |  | $ | 442 |  |

- changed (2021-05-06):
[0001564590-21-025123:note_history:38]
Realized gains and losses on sales of debt securities are computed under the specific identification method. The following table presents gross realized gains and losses related to debt securities:
  (was, 2020-11-06, similarity 0.9899):
[0001564590-20-052017:note_history:38]
Realized gains and losses on sales of debt securities are computed under the specific identification method. The following table presents gross realized gains and losses related to our debt securities:

- changed (2021-05-06):
[0001564590-21-025123:note_history:39]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2021 |  |  | 2020 |  |
| Gross realized gains on debt securities |  | $ | 87 |  |  | $ | 43 |  |
| Gross realized losses on debt securities |  |  | (16 | ) |  |  | (20 | ) |
| Total gain recognized, net |  | $ | 71 |  |  | $ | 23 |  |
  (was, 2020-11-06, similarity 0.7843):
[0001564590-20-052017:note_history:39]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Gross realized gains on debt securities |  | $ | 70 |  |  | $ | 36 |  |  | $ | 303 |  |  | $ | 85 |  |
| Gross realized losses on debt securities |  |  | (6 | ) |  |  | (7 | ) |  |  | (45 | ) |  |  | (40 | ) |
| Total gain recognized, net |  | $ | 64 |  |  | $ | 29 |  |  | $ | 258 |  |  | $ | 45 |  |

- changed (2021-05-06):
[0001564590-21-025123:note_history:40]
The Company’s investment policy provides limitations for issuer concentration, which limits, at the time of purchase, the concentration in any one issuer to 5% of the market value of the total investment portfolio. The Company did not purchase any available-for-sale debt security with credit deterioration during the three months ended March 31, 2021.
  (was, 2020-11-06, similarity 0.9305):
[0001564590-20-052017:note_history:40]
The Company’s investment policy provides limitations for issuer concentration, which limits, at the time of purchase, the concentration in any one issuer to 5% of the market value of the total investment portfolio. The Company did not purchase any available-for-sale debt security with credit deterioration during the three and nine months ended September 30, 2020.

- changed (2021-05-06):
[0001564590-21-025123:note_history:41]
Our marketable equity securities consist of publicly traded stock, funds and certain other investments measured at fair value or cost (where appropriate).
  (was, 2020-11-06, similarity 0.9902):
[0001564590-20-052017:note_history:41]
Our marketable equity securities consist of publicly traded stock, funds and certain other investments measured at fair value or cost, where appropriate.

- changed (2021-05-06):
[0001564590-21-025123:note_history:42]
In March 2019, an outstanding note receivable of $4.3 million was repaid and reissued to the Company in the form of debt and equity. Of the outstanding $4.3 million, $3.4 million was issued as an equity investment. The Company elected to record this equity investment that does not have a readily determinable fair value using the measurement alternative. Under the measurement alternative, equity investments that do not have a readily determinable fair value can be recorded at cost less impairment, if any, adjusted for observable price changes for an identical or similar investment. During the year ended December 31, 2020, impairment charges totaling $2.6 million were recorded related to this equity investment, which was included in net investment gain (loss) on the Condensed Consolidated Statement of Income (Loss). As a result, the carrying value of this investment was $0.8 million as of March 31, 2021 and December 31, 2020. The remaining amount, $0.9 million of the original $4.3 million note receivable, was reissued as a new note receivable, which is included in long-term investments on the Condensed Consolidated Balance Sheets as of March 31, 2021 and December 31, 2020. No impairment charge was recognized related to the note receivable, as it is a secured loan.
  (was, 2020-11-06, similarity 0.8013):
[0001564590-20-052017:note_history:42]
During the three months ended March 31, 2019, an outstanding note receivable of $4.3 million was repaid and reissued in the form of debt and equity. Of the outstanding $4.3 million, $3.4 million was issued as an equity investment, which represented a non-cash investing activity. We elected to record this equity investment that does not have a readily determinable fair value using the measurement alternative. Under the measurement alternative, equity investments that do not have a readily determinable fair value can be recorded at cost less impairment, if any, adjusted for observable price changes for an identical or similar investment. The carrying value of this investment under the measurement alternative was $3.4 million as of December 31, 2019. During the nine months ended September 30, 2020, an impairment charge of $1.6 million was recorded related to this equity investment, which is included in net investment gain (loss) on the Condensed Consolidated Statement of Income (Loss). As a result, the carrying value of this investment was $1.8 million as of September 30, 2020. The remaining amount, $0.9 million of the original $4.3 million note receivable, was reissued as a new note receivable, which is included in long-term investments on the Condensed Consolidated Balance Sheets as of September 30, 2020 and December 31, 2019, and represented a non-cash investing activity during the nine months ended September 30, 2019. No impairment charge was recognized related to the note receivable as it is a secured loan.

- changed (2021-05-06):
[0001564590-21-025123:note_history:43]
Realized and unrealized gains and losses related to marketable equity securities were as follows:
  (was, 2020-11-06, similarity 0.776):
[0001564590-20-052017:note_history:43]
Realized and unrealized gains and losses related to marketable equity securities for the three and nine months ended September 30, 2020 and 2019 were as follows:

- added (2021-05-06):
[0001564590-21-025123:note_history:44]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2021 |  |  | 2020 |  |
| Realized gains (losses) on equity securities sold |  | $ | 24 |  |  | $ | (2,436 | ) |
| Unrealized gains (losses) on equity securities held |  |  | 901 |  |  |  | (8,464 | ) |
| Total gain (loss) recognized, net |  | $ | 925 |  |  | $ | (10,900 | ) |

- changed (2021-05-06):
[0001564590-21-025123:note_history:45]
|  |  |  |  |  |  | Fair Value Measurements as of March 31, 2021 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 889 |  |  | $ | 889 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 14,231 |  |  |  | — |  |  |  | 14,231 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 2,625 |  |  |  | — |  |  |  | 2,625 |  |  |  | — |  |
| Asset-backed bonds |  |  | 5,812 |  |  |  | — |  |  |  | 5,812 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 11,845 |  |  |  | — |  |  |  | 11,845 |  |  |  | — |  |
| U.S. government bonds |  |  | 9,769 |  |  |  | 9,769 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 1,332 |  |  |  | — |  |  |  | 1,332 |  |  |  | — |  |
| Other |  |  | 533 |  |  |  | — |  |  |  | — |  |  |  | 533 |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 11,544 |  |  |  | 11,544 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 24,364 |  |  |  | 24,364 |  |  |  | — |  |  |  | — |  |
| Other investments |  |  | 1,400 |  |  |  | 1,400 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 84,344 |  |  | $ | 47,966 |  |  | $ | 35,845 |  |  | $ | 533 |  |
  (was, 2020-11-06, similarity 0.7415):
[0001564590-20-052017:note_history:45]
|  |  |  |  |  |  | Fair Value Measurements as of December 31, 2019 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,309 |  |  | $ | 1,309 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 9,384 |  |  |  | — |  |  |  | 9,384 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 930 |  |  |  | — |  |  |  | 930 |  |  |  | — |  |
| Asset-backed bonds |  |  | 6,890 |  |  |  | — |  |  |  | 6,890 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 6,962 |  |  |  | — |  |  |  | 6,962 |  |  |  | — |  |
| U.S. government bonds |  |  | 12,323 |  |  |  | 12,323 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 371 |  |  |  | — |  |  |  | 371 |  |  |  | — |  |
| Variable-rate demand notes |  |  | 800 |  |  |  | — |  |  |  | 800 |  |  |  | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 35,501 |  |  |  | 35,501 |  |  |  | — |  |  |  | — |  |
| Equity in escrow |  |  | 298 |  |  |  | 298 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 21,698 |  |  |  | 21,698 |  |  |  | — |  |  |  | — |  |
| Other investments |  |  | 2,442 |  |  |  | 2,442 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 98,908 |  |  | $ | 73,571 |  |  | $ | 25,337 |  |  | $ | — |  |

- changed (2021-05-06):
[0001564590-21-025123:note_history:46]
|  |  |  |  |  |  | Fair Value Measurements as of December 31, 2020 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 497 |  |  | $ | 497 |  |  | $ | — |  |  | $ | — |  |
| U.S. government bonds |  |  | 350 |  |  |  | 350 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 11,885 |  |  |  | — |  |  |  | 11,885 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 2,884 |  |  |  | — |  |  |  | 2,884 |  |  |  | — |  |
| Asset-backed bonds |  |  | 6,708 |  |  |  | — |  |  |  | 6,708 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 11,644 |  |  |  | — |  |  |  | 11,644 |  |  |  | — |  |
| U.S. government bonds |  |  | 9,875 |  |  |  | 9,875 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 1,337 |  |  |  | — |  |  |  | 1,337 |  |  |  | — |  |
| Commercial paper |  |  | 250 |  |  |  | — |  |  |  | 250 |  |  |  | — |  |
| Other |  |  | 533 |  |  |  | — |  |  |  | — |  |  |  | 533 |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 10,963 |  |  |  | 10,963 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 23,891 |  |  |  | 23,891 |  |  |  | — |  |  |  | — |  |
| Other investments |  |  | 1,400 |  |  |  | 1,400 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 82,217 |  |  | $ | 46,976 |  |  | $ | 34,708 |  |  | $ | 533 |  |
  (was, 2020-11-06, similarity 0.9419):
[0001564590-20-052017:note_history:46]
|  |  |  |  |  |  | Fair Value Measurements as of September 30, 2020 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 636 |  |  | $ | 636 |  |  | $ | — |  |  | $ | — |  |
| U.S. government securities |  |  | 300 |  |  |  | 300 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 13,010 |  |  | — |  |  |  | 13,010 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 3,124 |  |  | — |  |  |  | 3,124 |  |  |  | — |  |
| Asset-backed bonds |  |  | 8,587 |  |  | — |  |  |  | 8,587 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 11,080 |  |  | — |  |  |  | 11,080 |  |  |  | — |  |
| U.S. government bonds |  |  | 7,270 |  |  |  | 7,270 |  |  | — |  |  |  | — |  |
| Foreign government securities |  |  | 1,035 |  |  | — |  |  |  | 1,035 |  |  |  | — |  |
| Commercial paper |  |  | 325 |  |  | — |  |  |  | 325 |  |  |  | — |  |
| Variable-rate demand notes |  |  | — |  |  | — |  |  |  |  |  |  |  | — |  |
| Other |  |  | 442 |  |  | — |  |  | — |  |  |  | 442 |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 13,590 |  |  |  | 13,590 |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 21,595 |  |  |  | 21,595 |  |  | — |  |  |  | — |  |
| Other investments |  |  | 1,276 |  |  |  | 1,276 |  |  | — |  |  |  | — |  |
| Total |  | $ | 82,270 |  |  | $ | 44,667 |  |  | $ | 37,161 |  |  | $ | 442 |  |

- removed (2021-05-06):
[0001564590-20-052017:note_history:47]
As of September 30, 2020, the following debt securities and other investments were included on the Condensed Consolidated Balance Sheet and recorded at fair value:

- removed (2021-05-06):
[0001564590-20-052017:note_history:48]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Realized gains (losses) on equity securities sold |  | $ | 623 |  |  | $ | (20 | ) |  | $ | (1,485 | ) |  | $ | (83 | ) |
| Unrealized gains (losses) on equity securities held |  |  | 2,157 |  |  |  | (225 | ) |  |  | 3,046 |  |  |  | 8,233 |  |
| Total gain (loss) recognized, net |  | $ | 2,780 |  |  | $ | (245 | ) |  | $ | 1,561 |  |  | $ | 8,150 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-05-06):
[0001564590-21-025123:note_history:49]
The following table disaggregates revenue by reportable segment and revenue category:
  (was, 2020-11-06, similarity 0.7434):
[0001564590-20-052017:note_history:49]
The following tables disaggregate revenue by reportable segment and revenue category for the three and nine months ended September 30, 2020 and 2019:

- changed (2021-05-06):
[0001564590-21-025123:note_history:50]
|  |  | For the Three Months Ended |  |
|  |  | March 31, 2021 |  |  | March 31, 2020 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 60,053 |  |  | $ | 9,021 |  |  | $ | 69,074 |  |  | $ | 53,055 |  |  | $ | 12,911 |  |  | $ | 65,966 |  |
| Subscriber Solutions & Experience |  |  | 52,269 |  |  |  | 2,300 |  |  |  | 54,569 |  |  |  | 39,983 |  |  |  | 2,196 |  |  |  | 42,179 |  |
| Traditional & Other Products |  |  | 1,487 |  |  |  | 2,403 |  |  |  | 3,890 |  |  |  | 4,334 |  |  |  | 2,044 |  |  |  | 6,378 |  |
| Total |  | $ | 113,809 |  |  | $ | 13,724 |  |  | $ | 127,533 |  |  | $ | 97,372 |  |  | $ | 17,151 |  |  | $ | 114,523 |  |
  (was, 2020-11-06, similarity 0.9108):
[0001564590-20-052017:note_history:50]
|  |  | Three Months Ended |  |
|  |  | September 30, 2020 |  |  | September 30, 2019 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 71,919 |  |  | $ | 13,504 |  |  | $ | 85,423 |  |  | $ | 48,902 |  |  | $ | 16,212 |  |  | $ | 65,114 |  |
| Subscriber Solutions & Experience |  |  | 40,843 |  |  |  | 2,282 |  |  |  | 43,125 |  |  |  | 40,382 |  |  |  | 2,094 |  |  |  | 42,476 |  |
| Traditional & Other Products |  |  | 2,467 |  |  |  | 2,128 |  |  |  | 4,595 |  |  |  | 4,734 |  |  |  | 1,768 |  |  |  | 6,502 |  |
| Total |  | $ | 115,229 |  |  | $ | 17,914 |  |  | $ | 133,143 |  |  | $ | 94,018 |  |  | $ | 20,074 |  |  | $ | 114,092 |  |

- changed (2021-05-06):
[0001564590-21-025123:note_history:51]
The table below presents revenue information by category:
  (was, 2020-11-06, similarity 0.6071):
[0001564590-20-052017:note_history:51]
The table below presents sales information by category for the three and nine months ended September 30, 2020 and 2019:

- changed (2021-05-06):
[0001564590-21-025123:note_history:52]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2021 |  |  | 2020 |  |
| Access & Aggregation |  | $ | 69,074 |  |  | $ | 65,966 |  |
| Subscriber Solutions & Experience |  |  | 54,569 |  |  |  | 42,179 |  |
| Traditional & Other Products |  |  | 3,890 |  |  |  | 6,378 |  |
| Total Revenue |  | $ | 127,533 |  |  | $ | 114,523 |  |
  (was, 2020-11-06, similarity 0.6893):
[0001564590-20-052017:note_history:52]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Access & Aggregation |  | $ | 85,423 |  |  | $ | 65,114 |  |  | $ | 234,165 |  |  | $ | 274,313 |  |
| Subscriber Solutions & Experience |  |  | 43,125 |  |  |  | 42,476 |  |  |  | 125,697 |  |  |  | 119,731 |  |
| Traditional & Other Products |  |  | 4,595 |  |  |  | 6,502 |  |  |  | 16,519 |  |  |  | 20,230 |  |
| Total |  | $ | 133,143 |  |  | $ | 114,092 |  |  | $ | 376,381 |  |  | $ | 414,274 |  |

- removed (2021-05-06):
[0001564590-20-052017:note_history:53]
|  |  | Nine Months Ended |  |
|  |  | September 30, 2020 |  |  | September 30, 2019 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 194,695 |  |  | $ | 39,470 |  |  | $ | 234,165 |  |  | $ | 230,837 |  |  | $ | 43,476 |  |  | $ | 274,313 |  |
| Subscriber Solutions & Experience |  |  | 118,907 |  |  |  | 6,790 |  |  |  | 125,697 |  |  |  | 113,545 |  |  |  | 6,186 |  |  |  | 119,731 |  |
| Traditional & Other Products |  |  | 10,322 |  |  |  | 6,197 |  |  |  | 16,519 |  |  |  | 14,625 |  |  |  | 5,605 |  |  |  | 20,230 |  |
| Total |  | $ | 323,924 |  |  | $ | 52,457 |  |  | $ | 376,381 |  |  | $ | 359,007 |  |  | $ | 55,267 |  |  | $ | 414,274 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-05-06):
[0001564590-21-025123:note_history:54]
Network Solutions Segment - Includes hardware products and software-defined next-generation virtualized solutions used in service provider or business networks, as well as prior generation products.
  (was, 2020-11-06, similarity 0.9794):
[0001564590-20-052017:note_history:54]
Network Solutions - Includes hardware products and software-defined next-generation virtualized solutions used in service provider or business networks, as well as prior generation products.

- changed (2021-05-06):
[0001564590-21-025123:note_history:55]
Services & Support Segment - Includes maintenance, network implementation, solutions integration and managed services, which include hosted cloud services and subscription services.
  (was, 2020-11-06, similarity 0.9774):
[0001564590-20-052017:note_history:55]
Services & Support - Includes maintenance, network implementation, solutions integration and managed services, which include hosted cloud services and subscription services.

- added (2021-05-06):
[0001564590-21-025123:note_history:56]
See Note 17 for additional information on reportable segments.

- changed (2021-05-06):
[0001564590-21-025123:note_history:57]
Revenue by Category
  (was, 2020-11-06, similarity 0.7222):
[0001564590-20-052017:note_history:57]
Sales by Category

- changed (2021-05-06):
[0001564590-21-025123:note_history:58]
In addition to our reporting segments, revenue is also reported for the following three categories – Access & Aggregation, Subscriber Solutions & Experience and Traditional & Other Products.
  (was, 2020-11-06, similarity 0.9816):
[0001564590-20-052017:note_history:58]
In addition to our reportable segments, revenue is also reported for the following three categories – Access & Aggregation, Subscriber Solutions & Experience and Traditional & Other Products.

- changed (2021-05-06):
[0001564590-21-025123:note_history:59]
The following table disaggregates revenue by reportable segment and revenue category:
  (was, 2020-11-06, similarity 0.7434):
[0001564590-20-052017:note_history:59]
The following tables disaggregate revenue by reportable segment and revenue category for the three and nine months ended September 30, 2020 and 2019:

- changed (2021-05-06):
[0001564590-21-025123:note_history:60]
|  |  | For the Three Months Ended |  |
|  |  | March 31, 2021 |  |  | March 31, 2020 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 60,053 |  |  | $ | 9,021 |  |  | $ | 69,074 |  |  | $ | 53,055 |  |  | $ | 12,911 |  |  | $ | 65,966 |  |
| Subscriber Solutions & Experience |  |  | 52,269 |  |  |  | 2,300 |  |  |  | 54,569 |  |  |  | 39,983 |  |  |  | 2,196 |  |  |  | 42,179 |  |
| Traditional & Other Products |  |  | 1,487 |  |  |  | 2,403 |  |  |  | 3,890 |  |  |  | 4,334 |  |  |  | 2,044 |  |  |  | 6,378 |  |
| Total |  | $ | 113,809 |  |  | $ | 13,724 |  |  | $ | 127,533 |  |  | $ | 97,372 |  |  | $ | 17,151 |  |  | $ | 114,523 |  |
  (was, 2020-11-06, similarity 0.9108):
[0001564590-20-052017:note_history:60]
|  |  | Three Months Ended |  |
|  |  | September 30, 2020 |  |  | September 30, 2019 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 71,919 |  |  | $ | 13,504 |  |  | $ | 85,423 |  |  | $ | 48,902 |  |  | $ | 16,212 |  |  | $ | 65,114 |  |
| Subscriber Solutions & Experience |  |  | 40,843 |  |  |  | 2,282 |  |  |  | 43,125 |  |  |  | 40,382 |  |  |  | 2,094 |  |  |  | 42,476 |  |
| Traditional & Other Products |  |  | 2,467 |  |  |  | 2,128 |  |  |  | 4,595 |  |  |  | 4,734 |  |  |  | 1,768 |  |  |  | 6,502 |  |
| Total |  | $ | 115,229 |  |  | $ | 17,914 |  |  | $ | 133,143 |  |  | $ | 94,018 |  |  | $ | 20,074 |  |  | $ | 114,092 |  |

- changed (2021-05-06):
[0001564590-21-025123:note_history:61]
Revenue allocated to remaining performance obligations represents contract revenue that have not yet been recognized for contracts with a duration greater than one year. As of March 31, 2021, we did not have any significant performance obligations related to customer contracts that had an original expected duration of one year or more, other than maintenance services, which are satisfied over time. As a practical expedient, for certain contracts we recognize revenue equal to the amounts we are entitled to invoice which correspond to the value of completed performance obligations to date. The amount related to these performance obligations was $19.0 million and $17.7 million as of March 31, 2021 and December 31, 2020, respectively. The Company expects to recognize 63% of the $19.0 million as of March 31, 2021 over the next 12 months with the remainder to be recognized thereafter.
  (was, 2020-11-06, similarity 0.9701):
[0001564590-20-052017:note_history:61]
Revenue allocated to remaining performance obligations represents contract revenue that have not yet been recognized for contracts with a duration of greater than one year. As of September 30, 2020, we did not have any significant performance obligations related to customer contracts that had an original expected duration of one year or more, other than maintenance services, which are satisfied over time. As a practical expedient, for certain contracts we recognize revenue equal to the amounts that we are entitled to invoice, which correspond to the value of completed performance obligations to date. The amount related to these performance obligations was $16.5 million and $13.6 million as of September 30, 2020 and December 31, 2019, respectively. The Company expects to recognize 59% of the $16.5 million as of September 30, 2020 over the next 12 months, with the remainder to be recognized thereafter.

- changed (2021-05-06):
[0001564590-21-025123:note_history:62]
| (In thousands) |  | As of March 31, 2021 |  |  | As of December 31, 2020 |  |
| Accounts receivable, net |  | $ | 103,201 |  |  | $ | 98,827 |  |
| Contract assets(1) |  | $ | 906 |  |  | $ | 63 |  |
| Unearned revenue |  | $ | 14,457 |  |  | $ | 14,092 |  |
| Non-current unearned revenue |  | $ | 7,040 |  |  | $ | 6,888 |  |
  (was, 2020-11-06, similarity 0.8973):
[0001564590-20-052017:note_history:62]
| (In thousands) |  | September 30, 2020 |  |  | December 31, 2019 |  |
| Accounts receivable, net |  | $ | 100,223 |  |  | $ | 90,531 |  |
| Contract assets(1) |  | $ | 1,015 |  |  | $ | 2,812 |  |
| Unearned revenue |  | $ | 13,379 |  |  | $ | 11,963 |  |
| Non-current unearned revenue |  | $ | 6,694 |  |  | $ | 6,012 |  |

- added (2021-05-06):
[0001564590-21-025123:note_history:63]
Of the outstanding unearned revenue balances as of December 31, 2020, $5.0 million was recognized as revenue during the three months ended March 31, 2021.

- removed (2021-05-06):
[0001564590-20-052017:note_history:64]
|  |  | Nine Months Ended |  |
|  |  | September 30, 2020 |  |  | September 30, 2019 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 194,695 |  |  | $ | 39,470 |  |  | $ | 234,165 |  |  | $ | 230,837 |  |  | $ | 43,476 |  |  | $ | 274,313 |  |
| Subscriber Solutions & Experience |  |  | 118,907 |  |  |  | 6,790 |  |  |  | 125,697 |  |  |  | 113,545 |  |  |  | 6,186 |  |  |  | 119,731 |  |
| Traditional & Other Products |  |  | 10,322 |  |  |  | 6,197 |  |  |  | 16,519 |  |  |  | 14,625 |  |  |  | 5,605 |  |  |  | 20,230 |  |
| Total |  | $ | 323,924 |  |  | $ | 52,457 |  |  | $ | 376,381 |  |  | $ | 359,007 |  |  | $ | 55,267 |  |  | $ | 414,274 |  |

- removed (2021-05-06):
[0001564590-20-052017:note_history:65]
Of the outstanding unearned revenue balances as of December 31, 2019 and December 31, 2018, $1.5 million and $1.2 million were recognized as revenue during the three months ended September 30, 2020 and 2019 and $9.6 million and $11.7 million were recognized as revenue during the nine months ended September 30, 2020 and 2019, respectively.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2021-05-06):
[0001564590-21-025123:note_history:66]
On May 5, 2021, we announced that our Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to the Company’s stockholders of record as of the close of business on May 20, 2021. The payment date will be June 3, 2021 in the aggregate amount of approximately $4.4 million.
  (was, 2020-11-06, similarity 0.8941):
[0001564590-20-052017:note_history:66]
On November 2, 2020, the Company announced that its Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to the Company’s stockholders of record as of the close of business on November 17, 2020. The payment date will be December 1, 2020 in the aggregate amount of approximately $4.3 million.

- removed (2021-05-06):
[0001564590-20-052017:note_history:67]
On November 4, 2020, the Company, as borrower, entered into a Revolving Credit and Security Agreement and related Promissory Note (together, the “Revolving Credit Agreement”) with Cadence Bank, N.A., as lender (the “Lender”). The Revolving Credit Agreement provides the Company with a new $10 million secured revolving credit facility. Loans under the Revolving Credit Agreement will bear interest at a rate equal to 1.50% over the screen rate as obtained by Reuter’s, Bloomberg or another commercially available source as may be designated by the Lender from time to time; provided, however, that in no event shall the applicable rate of interest under the Revolving Credit Agreement be less than 1.50% per annum. Such loans are secured by all of the cash, securities, securities entitlements and investment property in a certain bank account, as outlined in the Revolving Credit Agreement, at a maximum loan-to-value ratio of 75% determined by dividing the full commitment amount under the Revolving Credit Agreement on the date of testing, determined by the Lender each fiscal quarter, by the market value of the collateral. The Revolving Credit Agreement matures on November 4, 2021, subject to earlier termination upon the occurrence of certain events of default. The Company has not made any draws under the Revolving Credit Agreement to date.
