# ADTN notes — 0001193125-12-089158


## adtn:DividendsPolicyTextBlock

[0001193125-12-089158:notes:1]
Dividends

[0001193125-12-089158:notes:2]
The Board of Directors presently anticipates that it will declare a regular quarterly dividend as long as the current tax treatment of dividends exists and adequate levels of liquidity are maintained. During the years ended December 31, 2011, 2010 and 2009, we paid $23.1 million, $22.5 million and $22.5 million, respectively, in dividend payments. On January 17, 2012, the Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to holders of record at the close of business on February 2, 2012. The ex-dividend date was January 31, 2012 and the payment date was February 16, 2012. The quarterly dividend payment was $5.7 million.


## adtn:IndustrialDevelopmentAuthorityFinancingAndEconomicIncentivesTextBlock

[0001193125-12-089158:notes:3]
Note 8 – Alabama State Industrial Development Authority Financing and Economic Incentives

[0001193125-12-089158:notes:4]
In conjunction with an expansion of our Huntsville, Alabama, facility, we were approved for participation in an incentive program offered by the State of Alabama Industrial Development Authority (the "Authority"). Pursuant to the program, on January 13, 1995, the Authority issued $20.0 million of its taxable revenue bonds and loaned the proceeds from the sale of the bonds to ADTRAN. The bonds were originally purchased by AmSouth Bank of Alabama, Birmingham, Alabama (the "Bank"). Wachovia Bank, N.A., Nashville, Tennessee (formerly First Union National Bank of Tennessee) (the "Bondholder"), which was acquired by Wells Fargo & Company on December 31, 2008, purchased the original bonds from the Bank and made further advances to the Authority, bringing the total amount outstanding to $50.0 million. An Amended and Restated Taxable Revenue Bond ("Amended and Restated Bond") was issued and the original financing agreement was amended. The Amended and Restated Bond bears interest, payable monthly. The interest rate is 5% per annum. The Amended and Restated Bond matures on January 1, 2020. The estimated fair value of the bond at December 31, 2011 was approximately $46.9 million, based on a debt security with a comparable interest rate and maturity and a Standard & Poor's credit rating of A+. We are required to make payments to the Authority in amounts necessary to pay the principal of and interest on the Amended and Restated Bond. Included in long-term investments at December 31, 2011 is $48.3 million which is invested in a restricted certificate of deposit. These funds serve as a collateral deposit against the principal of this bond, and we have the right to set-off the balance of the Bond with the collateral deposit in order to reduce the balance of the indebtedness. In conjunction with this program, we are eligible to receive certain economic incentives from the state of Alabama that reduce the amount of payroll withholdings that we are required to remit to the state for those employment positions that qualify under the program. For the years ended December 31, 2011, 2010 and 2009, we realized economic incentives related to payroll withholdings totaling $1.9 million, $1.5 million and $1.5 million, respectively.

[0001193125-12-089158:notes:5]
Due to continued positive cash flow from operating activities, we made a business decision in 2006 to begin an early partial redemption of the Bond. We made principal payments of $1.0 million and $0.3 million for the years ended December 31, 2011 and 2010, respectively. It is our intent to make annual principal payments in addition to the interest amounts that are due. In connection with this decision, $0.5 million of the bond debt has been reclassified to a current liability in accounts payable in the Consolidated Balance Sheets at December 31, 2011 and 2010.


## adtn:OtherIncomePolicyTextBlock

[0001193125-12-089158:notes:6]
Other Income (Expense), Net

[0001193125-12-089158:notes:7]
Other income (expense), net, is comprised primarily of miscellaneous income and expense, gains and losses on foreign currency transactions, investment account management fees, and gains or losses on the disposal of property, plant and equipment occurring in the normal course of business.


## adtn:OtherReceivablesPolicyTextBlock

[0001193125-12-089158:notes:8]
Other Receivables

[0001193125-12-089158:notes:9]
Other receivables are comprised primarily of amounts due from subcontract manufacturers for product component transfers, accrued interest on investments and on a restricted certificate of deposit and amounts due from employee stock option exercises.


## adtn:RecentlyIssuedAccountingStandardsPolicyTextBlock

[0001193125-12-089158:notes:10]
Recently Issued Accounting Standards

[0001193125-12-089158:notes:11]
In June 2011, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update No. 2011-05, Presentation of Comprehensive Income (ASU 2011-05). ASU 2011-05 requires companies to present the components of net income and other comprehensive income either as one continuous statement or as two consecutive statements. ASU 2011-05 eliminates the option to present the components of other comprehensive income as part of the statement of changes in stockholders' equity. While ASU 2011-05 changes the presentation of comprehensive income, it does not change the components that are recognized in net income or comprehensive income under current accounting guidance. This update is effective for fiscal years, and interim periods within those years, ending after December 15, 2011, with early adoption permitted. We plan to adopt this amendment during the first quarter of 2012. Since ASU 2011-05 affects presentation only, it will have no effect on our consolidated results of operations or financial condition.

[0001193125-12-089158:notes:12]
In December 2011, the FASB issued Accounting Standards Update No. 2011-12, Deferral of the Effective Date for Amendments to the Presentation of Reclassifications of Items Out of Accumulated Other Comprehensive Income in Accounting Standards Update No. 2011-05 (ASU 2011-12). ASU 2011-12 defers the effective date for certain presentation requirements that relate to reclassification adjustments and the effect of those reclassification adjustments on the financial statements. This update is effective for fiscal years, and interim periods within those years, ending after December 15, 2011, with early adoption permitted. We plan to adopt this amendment during the first quarter of 2012. Since ASU 2011-12 affects presentation only, it will have no effect on our consolidated results of operations or financial condition.

[0001193125-12-089158:notes:13]
In May 2011, the FASB issued Accounting Standards Update No. 2011-04, Amendments to Achieve Common Fair Value Measurement and Disclosure Requirements in U.S. GAAP and IFRSs (ASU 2011-04). ASU 2011-04 is intended to improve the comparability of fair value measurements presented and disclosed in financial statements prepared in accordance with U.S. GAAP and IFRS. The amendments are of two types: (i) those that clarify the Board's intent about the application of existing fair value measurement and disclosure requirements and (ii) those that change a particular principle or requirement for measuring fair value or for disclosing information about fair value measurements. This update is effective for annual periods beginning after December 15, 2011. We do not expect the adoption of this amendment will have a material impact on our consolidated results of operations or financial condition.

[0001193125-12-089158:notes:14]
During 2011, we adopted the following accounting standards, which had no material effect on our consolidated results of operations or financial condition:

[0001193125-12-089158:notes:15]
In October 2009, the FASB issued Accounting Standards Update No. 2009-13, Multiple-Deliverable Revenue Arrangements (ASU 2009-13). ASU 2009-13 provides amendments to the criteria in Subtopic 605-25 of the ASC for separating consideration in multiple-deliverable arrangements. As a result of those amendments, multiple-deliverable arrangements are separated in more circumstances than under previously existing U.S. GAAP. ASU 2009-13 established a selling price hierarchy for determining the selling price of a deliverable and replaced the term fair value in the revenue allocation guidance with selling price to clarify that the allocation of revenue is based on entity-specific assumptions rather than assumptions of a marketplace participant. ASU 2009 -13 also eliminated the residual method of allocation and required that arrangement consideration be allocated at the inception of the arrangement to all deliverables using the relative selling price method and required that a vendor determine its best estimate of selling price in a manner that is consistent with that used to determine the price to sell the deliverable on a standalone basis.

[0001193125-12-089158:notes:16]
We generally sell our products and services separately, but in some circumstances products and services may be sold in bundles that contain multiple deliverables. A sale that includes multiple deliverables is evaluated to determine the units of accounting, and the revenue from the arrangement is allocated to each item requiring separate revenue recognition based on the relative selling price and corresponding terms of the contract. We strive to use vendor-specific objective evidence of selling price. When this evidence is not available, we are generally not able to determine third-party evidence of selling price because of the extent of customization among competing products or services from other companies. In these cases, estimated selling price is determined based on the particular circumstances of the arrangement and is used to allocate revenues to each unit of accounting. Revenue is recognized incrementally as the necessary criteria for each item are met.

[0001193125-12-089158:notes:17]
We adopted this amendment during the first quarter of 2011. The adoption of this amendment had no effect on our consolidated results of operations and financial condition for the year ended December 31, 2011.

[0001193125-12-089158:notes:18]
In October 2009, the FASB issued Accounting Standards Update No. 2009-14, Certain Revenue Arrangements that Include Software Arrangements. ASU 2009-14 changed the accounting model for revenue arrangements that include both tangible products and software elements. Tangible products containing software components and non-software components that function together to deliver the tangible product's essential functionality are no longer within the scope of the software revenue guidance in Subtopic 985-605 of the ASC. In addition, ASU 2009-14 requires that hardware components of a tangible product containing software components always be excluded from the software revenue guidance. In that regard, ASU 2009-14 provides additional guidance on how to determine which software, if any, relating to the tangible product also would be excluded from the scope of the software revenue guidance. ASU 2009-14 also provides guidance on how a vendor should allocate arrangement consideration to deliverables in an arrangement that includes both tangible products and software. ASU 2009-14 also provides further guidance on how to allocate arrangement consideration when an arrangement includes deliverables both included and excluded from the scope of the software revenue guidance. We adopted this amendment during the first quarter of 2011. The adoption of this amendment had no effect on our consolidated results of operations and financial condition for the year ended December 31, 2011.

[0001193125-12-089158:notes:19]
In September 2011, the FASB issued Accounting Standards Update No. 2011-08, Testing Goodwill for Impairment (ASU 2011-08). Existing accounting guidance requires that an entity perform a test for goodwill impairment, on at least an annual basis, by first comparing the fair value of a reporting unit with its carrying amount, including goodwill. If the fair value of a reporting unit is less than its carrying amount, then the second step of the test is to be performed to measure the amount of impairment loss, if any. ASU 2011-08 will allow an entity to first assess qualitative factors to determine whether it is necessary to perform the two-step quantitative goodwill impairment test. An entity will no longer be required to calculate the fair value of a reporting unit unless the entity determines, based on a qualitative assessment, that it is more likely than not that its fair value is less than its carrying amount. This update is effective for annual and interim goodwill impairment tests performed for fiscal years beginning after December 15, 2011, with early adoption permitted. We adopted this amendment during the fourth quarter of 2011. The adoption of this amendment had no effect on our consolidated results of operations and financial condition for the year ended December 31, 2011.


## adtn:ScheduleOfEntityWideInformationRevenueFromExternalCustomersBySubcategoryProductsAndServicesTableTextBlock

[0001193125-12-089158:notes:20]
|  |  |  | September 30, |  |  |  | September 30, |  |  |  | September 30, |  |
| (In thousands) |  | 2011 |  |  | 2010 |  |  | 2009 |  |
| Core Products |  |  |  |  |  |  |  |  |  |  |  |  |
| Broadband Access (included in Carrier Systems) |  | $ | 289,776 |  |  | $ | 176,116 |  |  | $ | 111,470 |  |
| Optical Access (included in Carrier Systems) |  |  | 82,535 |  |  |  | 66,206 |  |  |  | 60,596 |  |
| Internetworking (NetVanta® & Multi-service Access Gateways) (included in Business Networking) |  |  | 151,536 |  |  |  | 111,123 |  |  |  | 79,979 |  |
| Total |  | $ | 523,847 |  |  | $ | 353,445 |  |  | $ | 252,045 |  |
| Legacy Products |  |  |  |  |  |  |  |  |  |  |  |  |
| HDSL (does not include T1) (included in Loop Access) |  |  | 126,976 |  |  |  | 177,249 |  |  |  | 150,276 |  |
| Other products (excluding HDSL) |  |  | 66,406 |  |  |  | 74,980 |  |  |  | 81,864 |  |
| Total |  | $ | 193,382 |  |  | $ | 252,229 |  |  | $ | 232,140 |  |
| Total |  | $ | 717,229 |  |  | $ | 605,674 |  |  | $ | 484,185 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001193125-12-089158:notes:21]
Note 2 – Business Combinations

[0001193125-12-089158:notes:22]
On August 4, 2011, we acquired all of the outstanding stock of Bluesocket, Inc., a provider of wireless network solutions with virtual control, for $23.7 million in cash. The acquisition provides us with IEEE802.11N enterprise class wireless LAN expertise, technology, and products to address the growing transition within small-medium enterprises and large enterprises to wireless networks and mobile devices. We have included the financial results of Bluesocket in our consolidated financial statements since the date of acquisition. Pro forma results of operations prior to the closing date for the acquisition have not been presented because the effect of the acquisition was not material to our financial results. The allocation of the purchase price to the estimated fair value of the assets acquired and liabilities assumed at the acquisition date is as follows:

[0001193125-12-089158:notes:23]
|  |  |  | September 30, |  |
| (In Thousands) |  |  |  |
| Cash |  | $ | 1,027 |  |
| Accounts receivable |  |  | 298 |  |
| Inventory |  |  | 792 |  |
| Prepaid expenses |  |  | 357 |  |
| Property, plant and equipment |  |  | 173 |  |
| Deferred tax assets, net |  |  | 12,962 |  |
| Accounts payable |  |  | (441 | ) |
| Unearned revenue |  |  | (600 | ) |
| Accrued expenses |  |  | (332 | ) |
| Net assets acquired |  |  | 14,236 |  |
| Customer relationships |  |  | 1,530 |  |
| Developed technology |  |  | 3,230 |  |
| Intellectual property |  |  | 930 |  |
| Trade names |  |  | 270 |  |
| Goodwill |  |  | 3,492 |  |
| Total purchase price |  | $ | 23,688 |  |

[0001193125-12-089158:notes:24]
During the fourth quarter of 2011, the purchase price and purchase price allocation were adjusted for our final valuations. The adjustments resulted in a decrease to the goodwill recognized in the transaction.

[0001193125-12-089158:notes:25]
The net deferred tax assets acquired are primarily related to net operating losses and previously capitalized and unamortized research and development expense for tax deduction purposes.

[0001193125-12-089158:notes:26]
The fair value of the customer relationships, developed technology and intellectual property acquired was calculated using an income approach (excess earnings method) and is being amortized using the straight-line method. The customer relationships and intellectual property are being amortized over an estimated useful life of 7 years and the developed technology is being amortized over an average estimated useful life of 4.5 years.

[0001193125-12-089158:notes:27]
The fair value of the trade names acquired was calculated using an income approach (relief from royalty method) and is being amortized using the straight-line method over the estimate useful life of 4.5 years.

[0001193125-12-089158:notes:28]
The goodwill of $3.5 million generated from this acquisition is primarily related to expected synergies and was assigned to our Enterprise Networks division. The goodwill will not be deductible for U.S. federal income tax purposes.

[0001193125-12-089158:notes:29]
For the year ended December 31, 2011, we incurred acquisition related expenses and amortization of acquired intangibles of $1.7 million related to this acquisition.


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0001193125-12-089158:notes:30]
Cash and Cash Equivalents

[0001193125-12-089158:notes:31]
Cash and cash equivalents represent demand deposits, money market funds, and short-term investments classified as available-for-sale with original maturities of three months or less. We maintain depository investments with certain financial institutions. Although these depository investments may exceed government insured depository limits, we have evaluated the credit worthiness of these applicable financial institutions, and determined the risk of material financial loss due to the exposure of such credit risk to be minimal. As of December 31, 2011, $23.4 million of our cash and cash equivalents, primarily certain domestic money market funds and foreign depository accounts, were in excess of government provided insured depository limits.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-12-089158:notes:32]
Note 12 – Commitments and Contingencies

[0001193125-12-089158:notes:33]
In the ordinary course of business, we may be subject to various legal proceedings and claims, including employment disputes, patent claims, disputes over contract agreements and other commercial disputes. In some cases, claimants seek damages or other relief, such as royalty payments related to patents, which, if granted, could require significant expenditures. Although the outcome of any claim or litigation can never be certain, it is our opinion that the outcome of all contingencies of which we are currently aware will not materially affect our business, operations, financial condition or cash flows.

[0001193125-12-089158:notes:34]
We lease office space and equipment under operating leases which expire at various dates through 2016. As of December 31, 2011, future minimum rental payments under non-cancelable operating leases with original maturities of greater than 12 months are approximately as follows:

[0001193125-12-089158:notes:35]
|  |  |  | September 30, |  |
| (In thousands) |  |
| 2012 |  | $ | 2,007 |  |
| 2013 |  |  | 1,207 |  |
| 2014 |  |  | 967 |  |
| 2015 |  |  | 710 |  |
| 2016 |  |  | 89 |  |
| Total |  | $ | 4,980 |  |

[0001193125-12-089158:notes:36]
Rental expense was approximately $2.4 million, $1.8 million and $1.5 million for the years ended December 31, 2011, 2010 and 2009, respectively


## us-gaap:CompensationRelatedCostsPolicyTextBlock

[0001193125-12-089158:notes:37]
Stock-Based Compensation

[0001193125-12-089158:notes:38]
We have two Board and stockholder approved stock option plans from which stock options and other awards are available for grant to employees and directors. All employee and director stock options granted under our stock option plans have an exercise price equal to the fair market value of the award, as defined in the plan, of the underlying common stock on the grant date. There are currently no vesting provisions tied to performance or market conditions for any option awards; vesting for all outstanding option grants is based only on continued service as an employee or director of ADTRAN. All of our outstanding stock option awards are classified as equity awards.

[0001193125-12-089158:notes:39]
Under the provisions of our approved plans, we made grants of performance-based restricted stock units to five of our executive officers in 2011, 2010 and 2009. The restricted stock units are subject to a market condition based on the relative total shareholder return of ADTRAN against a peer group of companies (2009 grant) or against all the companies in the NASDAQ Telecommunications Index (2010 and 2011 grant) and vest at the end of a three-year performance period. The restricted stock units are converted into shares of common stock upon vesting. Depending on the relative total shareholder return over the performance period, the executive officers may earn from 0% to 150% of the number of restricted stock units granted. The fair value of the award is based on the market price of our common stock on the date of grant, adjusted for the expected outcome of the impact of market conditions using a Monte Carlo Simulation valuation method. The recipients of the restricted stock units also earn dividend credits during the performance period, which will be paid in cash upon the issuance of common stock for the restricted stock units.

[0001193125-12-089158:notes:40]
Stock-based compensation expense recognized under the Stock Compensation Topic of the Financial Accounting Standards Board Accounting Standards Codification (FASB ASC) in 2011, 2010 and 2009 was approximately $9.2 million, $7.7 million and $7.0 million, respectively. As of December 31, 2011, total compensation cost related to non-vested stock options, restricted stock units and restricted stock not yet recognized was approximately $21.9 million, which is expected to be recognized over an average remaining recognition period of 2.9 years. See Note 3 of Notes to Consolidated Financial Statements for additional information.


## us-gaap:ConsolidationPolicyTextBlock

[0001193125-12-089158:notes:41]
Principles of Consolidation

[0001193125-12-089158:notes:42]
Our consolidated financial statements include ADTRAN and its wholly owned subsidiaries. All significant inter-company accounts and transactions have been eliminated in consolidation.


## us-gaap:DeferredRevenueByArrangementDisclosureTextBlock

[0001193125-12-089158:notes:43]
|  |  |  | September 30, |  |  |  | September 30, |  |
| (In thousands) |  | 2011 |  |  | 2010 |  |
| Current unearned revenue |  | $ | 9,965 |  |  | $ | 10,138 |  |
| Non-current unearned revenue |  |  | 4,874 |  |  |  | 3,801 |  |
| Total |  | $ | 14,839 |  |  | $ | 13,939 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-12-089158:notes:44]
Note 3 – Stock Incentive Plans

[0001193125-12-089158:notes:45]
Stock Incentive Program Descriptions

[0001193125-12-089158:notes:46]
Our Board of Directors adopted the 1996 Employee Incentive Stock Option Plan (1996 Plan) effective February 14, 1996, as amended, under which 17.0 million shares of common stock were authorized for issuance to certain employees and officers through incentive stock options and non-qualified stock options. Options granted under the 1996 Plan typically become exercisable beginning after one year of continued employment, normally pursuant to a four or five-year vesting schedule beginning on the first anniversary of the grant date, and have a ten-year contractual term. The 1996 Plan expired February 14, 2006, and expiration dates of options outstanding at December 31, 2011 under the 1996 Plan range from 2012 to 2015.

[0001193125-12-089158:notes:47]
On January 23, 2006, the Board of Directors adopted the 2006 Employee Stock Incentive Plan (2006 Plan), which authorizes 13.0 million shares of common stock for issuance to certain employees and officers through incentive stock options and non-qualified stock options, stock appreciation rights, restricted stock and restricted stock units. The 2006 Plan was adopted by stockholder approval at our annual meeting of stockholders held on May 9, 2006. Options granted under the 2006 Plan typically become exercisable beginning after one year of continued employment, normally pursuant to a four-year vesting schedule beginning on the first anniversary of the grant date, and have a ten-year contractual term. Expiration dates of options outstanding at December 31, 2011 under the 2006 Plan range from 2016 to 2021.

[0001193125-12-089158:notes:48]
Our stockholders approved the 2010 Directors Stock Plan (2010 Directors Plan) on May 5, 2010, under which 0.5 million shares of common stock have been reserved. This plan replaces the 2005 Directors Stock Option Plan. The 2010 Directors Plan provides that the Company may issue stock options, restricted stock and restricted stock units to our non-employee directors. Stock awards issued under the 2010 Directors Plan normally become vested in full on the first anniversary of the grant date. Options issued under the 2010 Directors Plan have a ten-year contractual term. We currently also have options outstanding under the 1995 Directors Plan, as amended, and the 2005 Directors Plan. Expiration dates of options outstanding under both plans at December 31, 2011 range from 2012 to 2020.

[0001193125-12-089158:notes:49]
The following table is a summary of our stock options outstanding as of December 31, 2010 and 2011 and the changes that occurred during 2011:

[0001193125-12-089158:notes:50]
|  |  |  | September 30, |  |  |  | September 30, |  |  |  | September 30, |  |  |  | September 30, |  |
| (In thousands, except per share amounts) |  | Number ofOptions |  |  | WeightedAverageExercise Price |  |  | Weighted Avg.RemainingContractual Lifein Years |  |  | AggregateIntrinsic Value |  |
| Options outstanding, December 31, 2010 |  |  | 6,234 |  |  | $ | 23.09 |  |  |  | 6.21 |  |  | $ | 81,561 |  |
| Options granted |  |  | 1,031 |  |  | $ | 30.42 |  |  |  |  |  |  |  |  |  |
| Options cancelled/forfeited |  |  | (87 | ) |  | $ | 26.32 |  |  |  |  |  |  |  |  |  |
| Options exercised |  |  | (1,778 | ) |  | $ | 19.36 |  |  |  |  |  |  |  |  |  |
| Options outstanding, December 31, 2011 |  |  | 5,400 |  |  | $ | 25.66 |  |  |  | 6.78 |  |  | $ | 27,270 |  |
| Options exercisable, December 31, 2011 |  |  | 3,054 |  |  | $ | 23.49 |  |  |  | 5.20 |  |  | $ | 21,042 |  |

[0001193125-12-089158:notes:51]
The following table further describes our stock options outstanding as of December 31, 2011:

[0001193125-12-089158:notes:52]
|  |  |  | September 30, |  |  |  | September 30, |  |  |  | September 30, |  |  |  | September 30, |  |  |  | September 30, |  |
|  |  | Options Outstanding |  |  | Options Exercisable |  |
| Range of Exercise Prices |  | OptionsOutstanding at12/31/11(In thousands) |  |  | Weighted Avg.RemainingContractual Lifein Years |  |  | WeightedAverageExercisePrice |  |  | OptionsExercisable at12/31/10(In thousands) |  |  | WeightedAverageExercisePrice |  |
| $ 8.70 - $23.46 |  |  | 2,806 |  |  |  | 5.98 |  |  | $ | 20.30 |  |  |  | 2,135 |  |  | $ | 20.16 |  |
| $23.47 - $30.04 |  |  | 473 |  |  |  | 4.66 |  |  | $ | 29.13 |  |  |  | 421 |  |  | $ | 29.29 |  |
| $30.05- $33.33 |  |  | 1,262 |  |  |  | 7.96 |  |  | $ | 30.77 |  |  |  | 279 |  |  | $ | 32.18 |  |
| $33.34 - $41.92 |  |  | 859 |  |  |  | 8.81 |  |  | $ | 33.79 |  |  |  | 219 |  |  | $ | 33.80 |  |
|  |  |  | 5,400 |  |  |  |  |  |  |  |  |  |  |  | 3,054 |  |  |  |  |  |

[0001193125-12-089158:notes:53]
All of the options above were issued at exercise prices that approximate fair market value at the date of grant. At December 31, 2011, 8.0 million options were available for grant under the shareholder approved plans.

[0001193125-12-089158:notes:54]
The aggregate intrinsic values in the table above represent the total pre-tax intrinsic value (the difference between ADTRAN's closing stock price on the last trading day of 2011 and the exercise price, multiplied by the number of in-the-money options) that would have been received by the option holders had all option holders exercised their options on December 31, 2011. The amount of aggregate intrinsic value will change based on the fair market value of ADTRAN's stock.

[0001193125-12-089158:notes:55]
The total pre-tax intrinsic value of options exercised during 2011, 2010 and 2009 was $39.8 million, $20.3 million and $5.3 million, respectively. The fair value of options fully vesting during 2011, 2010 and 2009 was $7.3 million, $6.9 million and $7.1 million, respectively.

[0001193125-12-089158:notes:56]
Restricted Stock Program Description

[0001193125-12-089158:notes:57]
On November 6, 2008, the Compensation Committee of the Board of Directors approved the Performance Shares Agreement under the 2006 Plan which sets forth the terms and conditions of awards of performance-based restricted stock units (RSUs). Of the 13.0 million shares of common stock authorized for issuance under the 2006 Plan, we may grant up to 5.0 million shares of common stock for issuance to certain employees and officers for awards other than stock options, which would include RSUs. Under a proposal that was approved by the Board of Directors and shareholders at the 2010 annual meeting, the number of shares available for awards other than stock options under all stock plans was reduced to 3.3 million. The number of shares of common stock earned by a recipient pursuant to the RSUs is subject to a market condition based on ADTRAN's relative total shareholder return against a peer group (2009 grant) or against all companies in the NASDAQ Telecommunications Index (2010 and 2011 grant) at the end of a three-year performance period. Depending on the relative total shareholder return over the performance period, the recipient may earn from 0% to 150% of the shares underlying the RSUs, with the shares earned distributed upon the vesting of the RSUs at the end of the three-year performance period. The fair value of the award is based on the market price of our common stock on the date of grant, adjusted for the expected outcome of the impact of market conditions using a Monte Carlo Simulation valuation method. A portion of the granted RSUs also vest and the underlying shares become deliverable upon the death or disability of the recipient or upon a change of control of ADTRAN, as defined by the 2006 Plan. The recipients of the RSUs receive dividend credits based on the shares of common stock underlying the RSUs. The dividend credits are vested and earned in the same manner as the RSUs and will be paid in cash upon the issuance of common stock for the RSUs.

[0001193125-12-089158:notes:58]
The following table is a summary of our RSUs and restricted stock outstanding as of December 31, 2010 and 2011 and the changes that occurred during 2011:

[0001193125-12-089158:notes:59]
|  |  |  | September 30, |  |  |  | September 30, |  |
| (In thousands, except per share amounts) |  | Number ofshares |  |  | WeightedAverage GrantDate Fair Value |  |
| Unvested RSUs and restricted stock outstanding, December 31, 2010 |  |  | 87 |  |  | $ | 28.46 |  |
| RSUs and restricted stock granted |  |  | 39 |  |  | $ | 36.09 |  |
| RSUs and restricted stock vested |  |  | (49 | ) |  | $ | 22.36 |  |
| RSUs and restricted stock cancelled/forfeited |  |  | — |  |  | $ | — |  |
| Adjustments to shares granted due to shares earned at vesting |  |  | 13 |  |  | $ | 17.05 |  |
| Unvested RSUs and restricted stock outstanding, December 31, 2011 |  |  | 90 |  |  | $ | 34.21 |  |

[0001193125-12-089158:notes:60]
As of December 31, 2011, there was approximately $2.2 million of total unamortized compensation cost related to the non-vested portion of RSUs and restricted stock granted, which will be recognized on a straight-line basis over the remainder of the three-year performance period for RSUs and over the remainder of the one-year vesting period for restricted stock.

[0001193125-12-089158:notes:61]
Valuation and Expense Information

[0001193125-12-089158:notes:62]
We use the Black-Scholes option pricing model (Black-Scholes Model) for the purpose of determining the estimated fair value of stock option awards on the date of grant. The Black-Scholes Model requires the input of certain assumptions that involve judgment. Because our stock options have characteristics significantly different from those of traded options, and because changes in the input assumptions can materially affect the fair value estimate, existing models may not provide reliable measures of fair value of our stock options. We use a Monte Carlo Simulation valuation method to value our performance-based RSUs. The fair value of restricted stock issued is equal to the closing price of our stock on the date of grant. We will continue to assess the assumptions and methodologies used to calculate the estimated fair value of stock-based compensation. If circumstances change, and additional data becomes available over time, we may change our assumptions and methodologies, which may materially impact our fair value determination.

[0001193125-12-089158:notes:63]
The following table summarizes stock-based compensation expense related to stock options, RSUs and restricted stock under the Stock Compensation Topic of the FASB ASC for the years ended December 31, 2011, 2010 and 2009, which was recognized as follows:

[0001193125-12-089158:notes:64]
|  |  |  | September 30, |  |  |  | September 30, |  |  |  | September 30, |  |
| (In thousands) |  | 2011 |  |  | 2010 |  |  | 2009 |  |
| Stock-based compensation expense included in cost of sales |  | $ | 412 |  |  | $ | 317 |  |  | $ | 268 |  |
| Selling, general and administrative expense |  |  | 4,316 |  |  |  | 3,575 |  |  |  | 3,039 |  |
| Research and development expense |  |  | 4,441 |  |  |  | 3,825 |  |  |  | 3,680 |  |
| Stock-based compensation expense included in operating expenses |  |  | 8,757 |  |  |  | 7,400 |  |  |  | 6,719 |  |
| Total stock-based compensation expense |  |  | 9,169 |  |  |  | 7,717 |  |  |  | 6,987 |  |
| Tax benefit for expense associated with non-qualified options |  |  | (1,321 | ) |  |  | (650 | ) |  |  | (634 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 7,848 |  |  | $ | 7,067 |  |  | $ | 6,353 |  |

[0001193125-12-089158:notes:65]
At December 31, 2011, total compensation cost related to non-vested stock options, RSUs and restricted stock not yet recognized was approximately $21.9 million, which is expected to be recognized over an average remaining recognition period of 2.9 years.

[0001193125-12-089158:notes:66]
The stock option pricing model requires the use of several significant assumptions that impact the fair value estimate. These variables include, but are not limited to, the volatility of our stock price and employee exercise behaviors. The assumptions and variables used for the current period grants were developed based on guidance in the Stock Compensation Topic of the FASB ASC. There were no material changes made during 2011 to the methodology used to determine our assumptions.

[0001193125-12-089158:notes:67]
The weighted-average estimated fair value of stock options granted to employees and directors during the twelve months ended December 31, 2011, 2010 and 2009 was $9.53 per share, $11.69 per share and $8.11 per share, respectively, with the following weighted-average assumptions:

[0001193125-12-089158:notes:68]
|  |  |  | September 30, |  |  |  | September 30, |  |  |  | September 30, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2009 |  |
| Expected volatility |  |  | 38.32 | % |  |  | 39.57 | % |  |  | 41.86 | % |
| Risk-free interest rate |  |  | 1.01 | % |  |  | 1.35 | % |  |  | 2.29 | % |
| Expected dividend yield |  |  | 1.19 | % |  |  | 1.08 | % |  |  | 1.55 | % |
| Expected life (in years) |  |  | 5.15 |  |  |  | 5.78 |  |  |  | 5.10 |  |

[0001193125-12-089158:notes:69]
We based our estimate of expected volatility for the 12 months ended December 31, 2011, 2010 and 2009 on the sequential historical daily trading data of our common stock for a period equal to the expected life of the options granted. The selection of the historical volatility method was based on available data indicating our historical volatility is as equally representative of our future stock price trends as is our implied volatility. We have no reason to believe the future volatility of our stock price is likely to differ from its past volatility.

[0001193125-12-089158:notes:70]
The risk-free interest rate assumption is based upon implied yields of U.S. Treasury zero-coupon bonds on the date of grant having a remaining term equal to the expected life of the options granted. The dividend yield is based on our historical and expected dividend payouts.

[0001193125-12-089158:notes:71]
The expected life of our stock options is based upon historical exercise and cancellation activity of our previous stock-based grants with a ten-year contractual term.

[0001193125-12-089158:notes:72]
The RSU pricing model also requires the use of several significant assumptions that impact the fair value estimate. The estimated fair value of the RSUs granted to employees in 2011, 2010 and 2009 was $38.73 per share, $39.21 per share and $26.65 per share, respectively, with the following assumptions:

[0001193125-12-089158:notes:73]
|  |  |  | September 30, |  |  |  | September 30, |  |  |  | September 30, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2009 |  |
| Expected volatility |  |  | 39.32 | % |  |  | 40.82 | % |  |  | 41.41 | % |
| Risk-free interest rate |  |  | 0.37 | % |  |  | 0.51 | % |  |  | 1.40 | % |
| Expected dividend yield |  |  | 1.08 | % |  |  | 1.07 | % |  |  | 1.53 | % |

[0001193125-12-089158:notes:74]
Stock-based compensation expense recognized in our Consolidated Statements of Income for the 12 months ended December 31, 2011, 2010 and 2009 is based on RSUs and options ultimately expected to vest, and has been reduced for estimated forfeitures. Estimates for forfeiture rates are based upon historical experience and are evaluated quarterly. We expect our forfeiture rate for stock option awards to be approximately 1.6% annually. We estimated a 0% forfeiture rate for our RSUs and restricted stock due to the limited number of recipients and historical experience for these awards.


## us-gaap:EarningsPerSharePolicyTextBlock

[0001193125-12-089158:notes:75]
Earnings per Share

[0001193125-12-089158:notes:76]
Earnings per common share, and earnings per common share assuming dilution, are based on the weighted average number of common shares and, when dilutive, common equivalent shares outstanding during the year (see Note 13).


## us-gaap:EarningsPerShareTextBlock

[0001193125-12-089158:notes:77]
Note 13 – Earnings per Share

[0001193125-12-089158:notes:78]
A summary of the calculation of basic and diluted earnings per share (EPS) for the years ended December 31, 2011, 2010 and 2009 is as follows:

[0001193125-12-089158:notes:79]
|  |  |  | September 30, |  |  |  | September 30, |  |  |  | September 30, |  |
|  |  | Year Ended |  |
| (In thousands, except for per share amounts) |  | 2011 |  |  | 2010 |  |  | 2009 |  |
| Numerator |  |  |  |  |  |  |  |  |  |  |  |  |
| Net Income |  | $ | 138,577 |  |  | $ | 113,989 |  |  | $ | 74,221 |  |
| Denominator |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average number of shares – basic |  |  | 64,145 |  |  |  | 62,490 |  |  |  | 62,459 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock options |  |  | 1,236 |  |  |  | 1,355 |  |  |  | 887 |  |
| Restricted stock and restricted stock units |  |  | 35 |  |  |  | 34 |  |  |  | 10 |  |
| Weighted average number of shares – diluted |  |  | 65,416 |  |  |  | 63,879 |  |  |  | 63,356 |  |
| Net income per share – basic |  | $ | 2.16 |  |  | $ | 1.82 |  |  | $ | 1.19 |  |
| Net income per share – diluted |  | $ | 2.12 |  |  | $ | 1.78 |  |  | $ | 1.17 |  |

[0001193125-12-089158:notes:80]
For each of the years ended December 31, 2011, 2010 and 2009, 1.2 million, 2.0 million and 3.5 million stock options were outstanding but were not included in the computation of that year's diluted EPS because the options' exercise prices were greater than the average market price of the common shares, therefore making them anti-dilutive under the treasury stock method.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001193125-12-089158:notes:81]
| Fair Value Measurements at December 31, 2011 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarkets forIdentical Assets(Level 1) |  |  | SignificantOtherObservableInputs(Level 2) |  |  | SignificantUnobservableInputs(Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 13,696 |  |  | $ | 13,696 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 7,712 |  |  |  | 7,712 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 156,753 |  |  |  | — |  |  |  | 156,753 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 174,826 |  |  |  | — |  |  |  | 174,826 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 69,660 |  |  |  | — |  |  |  | 69,660 |  |  |  | — |  |
| Fixed income bond fund |  |  | 721 |  |  |  | 721 |  |  |  | — |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – technology industry |  |  | 18,743 |  |  |  | 18,743 |  |  |  | — |  |  |  | — |  |
| Marketable equity securities – other |  |  | 12,567 |  |  |  | 12,567 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 440,982 |  |  |  | 39,743 |  |  |  | 401,239 |  |  |  | — |  |
| Total |  | $ | 454,678 |  |  | $ | 53,439 |  |  | $ | 401,239 |  |  | $ | — |  |

[0001193125-12-089158:notes:82]
|  |  |  | September 30, |  |  |  | September 30, |  |  |  | September 30, |  |  |  | September 30, |  |
|  |  | Fair Value Measurements at December 31, 2010 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarkets forIdentical Assets(Level 1) |  |  | SignificantOtherObservableInputs(Level 2) |  |  | SignificantUnobservableInputs(Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 14,532 |  |  | $ | 14,532 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 4,246 |  |  |  | 4,246 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 127,072 |  |  |  | — |  |  |  | 127,072 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 71,467 |  |  |  | — |  |  |  | 71,467 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 116,745 |  |  |  | — |  |  |  | 116,745 |  |  |  | — |  |
| Fixed income bond fund |  |  | 746 |  |  |  | 746 |  |  |  | — |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – technology industry |  |  | 35,596 |  |  |  | 35,596 |  |  |  | — |  |  |  | — |  |
| Marketable equity securities – other |  |  | 12,414 |  |  |  | 12,414 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 368,286 |  |  |  | 53,002 |  |  |  | 315,284 |  |  |  | — |  |
| Total |  | $ | 382,818 |  |  | $ | 67,534 |  |  | $ | 315,284 |  |  | $ | — |  |


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001193125-12-089158:notes:83]
Foreign Currency

[0001193125-12-089158:notes:84]
We record transactions denominated in foreign currencies on a monthly basis using exchange rates from throughout the year. Assets and liabilities denominated in foreign currencies are translated at the balance sheet dates using the closing rates of exchange between those foreign currencies and the U.S. dollar with any transaction gains or losses reported in income. Adjustments from translating financial statements of international subsidiaries are recorded as a component of accumulated other comprehensive income (loss).


## us-gaap:GoodwillDisclosureTextBlock

[0001193125-12-089158:notes:85]
Note 7 – Goodwill and Intangible Assets

[0001193125-12-089158:notes:86]
The changes in the carrying value of goodwill, all of which is included in our Enterprise Networks division, for the year ended December 31, 2011 are as follows:

[0001193125-12-089158:notes:87]
|  |  |  | September 30, |  |
| (In thousands) |  |  |  |
| Balance, December 31, 2010 |  | $ | — |  |
| Acquisitions |  |  | 3,492 |  |
| Impairment losses |  |  | — |  |
| Balance, December 31, 2011 |  | $ | 3,492 |  |
| Balance as of December 31, 2011: |  |  |  |  |
| Goodwill |  | $ | 3,492 |  |
| Accumulated impairment losses |  |  | — |  |
| Total goodwill |  | $ | 3,492 |  |

[0001193125-12-089158:notes:88]
We evaluate the carrying value of goodwill during the fourth quarter of each year and between annual evaluations if events occur or circumstances change that would more likely than not reduce the fair value of the reporting unit below its carrying amount. When evaluating whether goodwill is impaired, we compare the fair value of the reporting unit to which the goodwill is assigned to the reporting unit's carrying amount, including goodwill. If the carrying amount of the reporting unit exceeds its fair value, then the amount of the impairment loss is measured. There were no impairment losses during 2011.

[0001193125-12-089158:notes:89]
The following table presents our intangible assets as of December 31, 2011 and 2010. Intangible assets are included in other assets in the accompanying Consolidated Balance Sheets and include intangible assets acquired with our acquisitions of Objectworld Communications Corporation on September 15, 2009 and Bluesocket, Inc. on August 4, 2011.

[0001193125-12-089158:notes:90]
|  |  |  | September 30, |  |  |  | September 30, |  |  |  | September 30, |  |  |  | September 30, |  |  |  | September 30, |  |  |  | September 30, |  |
|  |  | December 31, 2011 |  |  | December 31, 2010 |  |
| (In thousands) |  | Gross Value |  |  | AccumulatedAmortization |  |  | Net Value |  |  | Gross Value |  |  | AccumulatedAmortization |  |  | Net Value |  |
| Customer relationships |  | $ | 1,623 |  |  | $ | (194 | ) |  | $ | 1,429 |  |  | $ | 93 |  |  | $ | (60 | ) |  | $ | 33 |  |
| Developed technology |  |  | 3,230 |  |  |  | (303 | ) |  |  | 2,927 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Intellectual property |  |  | 2,340 |  |  |  | (525 | ) |  |  | 1,815 |  |  |  | 1,410 |  |  |  | (260 | ) |  |  | 1,150 |  |
| Trade names |  |  | 270 |  |  |  | (28 | ) |  |  | 242 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 7,463 |  |  | $ | (1,050 | ) |  | $ | 6,413 |  |  | $ | 1,503 |  |  | $ | (320 | ) |  | $ | 1,183 |  |

[0001193125-12-089158:notes:91]
Amortization expense was $0.7 million, $0.4 million and $0.1 million in 2011, 2010 and 2009, respectively.

[0001193125-12-089158:notes:92]
As of December 31, 2011, the estimated future amortization expense of intangible assets is as follows:

[0001193125-12-089158:notes:93]
|  |  |  | September 30, |  |
| (In thousands) |  | Amount |  |
| 2012 |  | $ | 1,221 |  |
| 2013 |  |  | 1,271 |  |
| 2014 |  |  | 1,120 |  |
| 2015 |  |  | 1,018 |  |
| 2016 |  |  | 781 |  |
| Thereafter |  |  | 1,002 |  |
| Total |  | $ | 6,413 |  |


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsPolicyTextBlock

[0001193125-12-089158:notes:94]
Impairment of Long-Lived Assets

[0001193125-12-089158:notes:95]
We review long-lived assets used in operations for impairment whenever events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable and the undiscounted cash flows estimated to be generated by the asset are less than the asset's carrying value. An impairment loss would be recognized in the amount by which the recorded value of the asset exceeds the fair value of the asset, measured by the quoted market price of an asset or an estimate based on the best information available in the circumstances. There were no such impairment losses recognized during 2011, 2010 or 2009.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-12-089158:notes:96]
Note 9 – Income Taxes

[0001193125-12-089158:notes:97]
A summary of the components of the provision for income taxes as of December 31, 2011, 2010 and 2009 is as follows:

[0001193125-12-089158:notes:98]
|  |  |  | September 30, |  |  |  | September 30, |  |  |  | September 30, |  |
| (In thousands) |  | 2011 |  |  | 2010 |  |  | 2009 |  |
| Current |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  | $ | 59,813 |  |  | $ | 49,144 |  |  | $ | 30,756 |  |
| State |  |  | 7,177 |  |  |  | 6,380 |  |  |  | 3,615 |  |
| Total Current |  |  | 66,990 |  |  |  | 55,524 |  |  |  | 34,371 |  |
| Deferred tax expense (benefit) |  |  | 575 |  |  |  | (1,324 | ) |  |  | (1,024 | ) |
| Total Provision for Income Taxes |  | $ | 67,565 |  |  | $ | 54,200 |  |  | $ | 33,347 |  |

[0001193125-12-089158:notes:99]
The effective income tax rate differs from the federal statutory rate due to the following:

[0001193125-12-089158:notes:100]
|  |  |  | September 30, |  |  |  | September 30, |  |  |  | September 30, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2009 |  |
| Tax provision computed at the federal statutory rate |  |  | 35.00 | % |  |  | 35.00 | % |  |  | 35.00 | % |
| State income tax provision, net of federal benefit |  |  | 3.19 |  |  |  | 3.33 |  |  |  | 3.68 |  |
| Federal research credits |  |  | (2.50 | ) |  |  | (2.90 | ) |  |  | (3.37 | ) |
| Tax-exempt income |  |  | (0.27 | ) |  |  | (0.46 | ) |  |  | (1.05 | ) |
| State tax incentives |  |  | (0.90 | ) |  |  | (0.86 | ) |  |  | (1.36 | ) |
| Stock-based compensation |  |  | 0.03 |  |  |  | 0.34 |  |  |  | 1.64 |  |
| Domestic production activity deduction |  |  | (1.84 | ) |  |  | (2.37 | ) |  |  | (3.33 | ) |
| Other, net |  |  | 0.07 |  |  |  | 0.15 |  |  |  | (0.21 | ) |
| Effective Tax Rate |  |  | 32.78 | % |  |  | 32.23 | % |  |  | 31.00 | % |

[0001193125-12-089158:notes:101]
Deferred income taxes on the balance sheet result from temporary differences between the amount of assets and liabilities recognized for financial reporting and tax purposes. The principal components of our current and non-current deferred taxes are as follows:

[0001193125-12-089158:notes:102]
|  |  |  | September 30, |  |  |  | September 30, |  |
| (In thousands) |  | 2011 |  |  | 2010 |  |
| Current deferred tax assets |  |  |  |  |  |  |  |  |
| Accounts receivable |  | $ | 4 |  |  | $ | 61 |  |
| Inventory |  |  | 6,709 |  |  |  | 6,032 |  |
| Accrued expenses |  |  | 5,412 |  |  |  | 4,524 |  |
| Total Current Deferred Tax Assets |  |  | 12,125 |  |  |  | 10,617 |  |
| Non-current deferred tax assets |  |  |  |  |  |  |  |  |
| Accrued expenses |  |  | 113 |  |  |  | 102 |  |
| Deferred compensation |  |  | 3,177 |  |  |  | 1,539 |  |
| Stock-based compensation |  |  | 3,808 |  |  |  | 3,542 |  |
| State tax and interest expense |  |  | 947 |  |  |  | 861 |  |
| Foreign loss and state credit carry-forwards |  |  | 7,891 |  |  |  | 5,988 |  |
| Federal loss and research carry-forwards |  |  | 14,778 |  |  |  | — |  |
| Valuation allowance |  |  | (7,585 | ) |  |  | (5,627 | ) |
| Total Non-current Deferred Tax Assets |  |  | 23,129 |  |  |  | 6,405 |  |
| Total Deferred Tax Assets |  | $ | 35,254 |  |  | $ | 17,022 |  |
| Non-current deferred tax liabilities |  |  |  |  |  |  |  |  |
| Accumulated depreciation |  | $ | (7,081 | ) |  | $ | (4,782 | ) |
| Intellectual property |  |  | (2,594 | ) |  |  | — |  |
| Investments |  |  | (5,109 | ) |  |  | (11,973 | ) |
| Total Non-current Deferred Tax Liabilities |  | $ | (14,784 | ) |  | $ | (16,755 | ) |
| Net Deferred Tax Assets |  | $ | 20,470 |  |  | $ | 267 |  |

[0001193125-12-089158:notes:103]
At December 31, 2011 and 2010, non-current deferred tax liabilities and non-current deferred tax assets, respectively, related to investments reflect deferred taxes on unrealized gains and losses on available-for-sale investments. The net change in non-current deferred taxes associated with these investments, a deferred tax benefit of $7.8 million in 2011 and a deferred tax provision of $4.6 million in 2010, is recorded as an adjustment to other comprehensive income, presented in the Consolidated Statements of Changes in Stockholders' Equity and Comprehensive Income.

[0001193125-12-089158:notes:104]
We have deferred tax assets for both foreign and domestic loss, unamortized research and development cost and state credit carry-forwards of $22.7 million which will expire between 2012 and 2030. These carry-forwards were caused by tax credits in excess of our annual tax liabilities to an individual state where we no longer generate sufficient state income, net operating loss carry-forwards acquired through the acquisition of a foreign entity and net operating losses and research and development cost acquired through the acquisition of a domestic entity. In accordance with the Income Taxes Topic of the FASB ASC, we believe it is more likely than not that we will not realize the full benefits of the deferred tax asset arising from these losses and credits, and accordingly, have provided a valuation allowance against these assets. We do not provide for U.S. income tax on undistributed earnings of our foreign operations, whose earnings are intended to be permanently reinvested. For years ended December 31, 2011, 2010 and 2009, foreign profits before income taxes were not material.

[0001193125-12-089158:notes:105]
During 2011, 2010 and 2009, we recorded an income tax benefit of $10.5 million, $4.9 million and $1.5 million, respectively, as an adjustment to equity in accordance with the Stock Compensation Topic of the FASB ASC. This deduction is calculated on the difference between the exercise price of stock option exercises and the market price of the underlying common stock upon exercise.

[0001193125-12-089158:notes:106]
The change in the unrecognized income tax benefits for 2011, 2010 and 2009 is reconciled below:

[0001193125-12-089158:notes:107]
|  |  |  | September 30, |  |  |  | September 30, |  |  |  | September 30, |  |
| (In thousands) |  | 2011 |  |  | 2010 |  |  | 2009 |  |
| Balance at beginning of period |  | $ | 2,593 |  |  | $ | 2,919 |  |  | $ | 2,775 |  |
| Increases for tax position related to: |  |  |  |  |  |  |  |  |  |  |  |  |
| Prior years |  |  | — |  |  |  | 197 |  |  |  | 390 |  |
| Current year |  |  | 840 |  |  |  | 818 |  |  |  | 610 |  |
| Decreases for tax positions related to: |  |  |  |  |  |  |  |  |  |  |  |  |
| Prior years |  |  | (92 | ) |  |  | (16 | ) |  |  | (1 | ) |
| Settlements with taxing authorities |  |  | (354 | ) |  |  | (630 | ) |  |  | (413 | ) |
| Expiration of applicable statute of limitations |  |  | (17 | ) |  |  | (695 | ) |  |  | (442 | ) |
| Balance at end of period |  | $ | 2,970 |  |  | $ | 2,593 |  |  | $ | 2,919 |  |

[0001193125-12-089158:notes:108]
As of December 31, 2011, 2010, and 2009, our total liability for unrecognized tax benefits was $3.0 million, $2.6 million, and $2.9 million, respectively, of which $2.4 million, $2.0 million, and $2.3 million, respectively, would reduce our effective tax rate if we were successful in upholding all of the uncertain positions and recognized the amounts recorded. We classify interest and penalties recognized on the liability for unrecognized tax benefits as income tax expense. As of December 31, 2011, 2010 and 2009, the balances of accrued interest and penalties were $1.2 million, $1.0 million and $1.2 million, respectively.

[0001193125-12-089158:notes:109]
We do not anticipate a single tax position generating a significant increase or decrease in our liability for unrecognized tax benefits within 12 months of this reporting date. We file income tax returns in the U.S. federal and various state jurisdictions and several foreign jurisdictions. We have been audited by the Internal Revenue Service and the state of Alabama through the 2007 tax year. Generally, we are not subject to changes in income taxes by any taxing jurisdiction for the years prior to 2008.


## us-gaap:IncomeTaxPolicyTextBlock

[0001193125-12-089158:notes:110]
Income Taxes

[0001193125-12-089158:notes:111]
The provision for income taxes has been determined using the asset and liability approach of accounting for income taxes. Under this approach, deferred taxes represent the future tax consequences expected to occur when the reported amounts of assets and liabilities are recovered or paid. The provision for income taxes represents income taxes paid or payable for the current year plus the change in deferred taxes during the year. Deferred taxes result from the difference between financial and tax bases of our assets and liabilities and are adjusted for changes in tax rates and tax laws when such changes are enacted. Valuation allowances are recorded to reduce deferred tax assets when it is more likely than not that a tax benefit will not be realized.


## us-gaap:InventoryDisclosureTextBlock

[0001193125-12-089158:notes:112]
Note 5 – Inventory

[0001193125-12-089158:notes:113]
At December 31, 2011 and 2010, inventory was comprised of the following:

[0001193125-12-089158:notes:114]
|  |  |  | September 30, |  |  |  | September 30, |  |
| (In thousands) |  | 2011 |  |  | 2010 |  |
| Raw materials |  | $ | 44,588 |  |  | $ | 43,897 |  |
| Work in process |  |  | 3,954 |  |  |  | 2,871 |  |
| Finished goods |  |  | 39,258 |  |  |  | 27,506 |  |
| Total |  | $ | 87,800 |  |  | $ | 74,274 |  |

[0001193125-12-089158:notes:115]
We establish reserves for estimated excess, obsolete, or unmarketable inventory equal to the difference between the cost of the inventory and the estimated fair value of the inventory based upon assumptions about future demand and market conditions. At December 31, 2011 and 2010, raw materials reserves totaled $7.9 million and $7.3 million, respectively, and finished goods inventory reserves totaled $1.5 million and $1.6 million, respectively.


## us-gaap:InventoryPolicyTextBlock

[0001193125-12-089158:notes:116]
Inventory

[0001193125-12-089158:notes:117]
Inventory is carried at the lower of cost or market, with cost being determined using the first-in, first-out method. Standard costs for material, labor and manufacturing overhead are used to value inventory. Standard costs are updated at least quarterly; therefore, inventory costs approximate actual costs at the end of each reporting period. We establish reserves for estimated excess, obsolete or unmarketable inventory equal to the difference between the cost of the inventory and the estimated fair value of the inventory based upon assumptions about future demand and market conditions. When we dispose of excess and obsolete inventories, the related write-downs are charged against the inventory reserve. See Note 5 of Notes to Consolidated Financial Statements for additional information.


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001193125-12-089158:notes:118]
|  |  |  | September 30, |  |  |  | September 30, |  |
| (In thousands) |  | Corporatebonds |  |  | Municipalfixed-rate bonds |  |
| Less than one year |  | $ | 10,093 |  |  | $ | 79,592 |  |
| One to two years |  |  | 54,245 |  |  |  | 64,001 |  |
| Two to three years |  |  | 92,415 |  |  |  | 18,990 |  |
| Three to five years |  |  | — |  |  |  | 12,243 |  |
| Total |  | $ | 156,753 |  |  | $ | 174,826 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001193125-12-089158:notes:119]
Note 4 – Investments

[0001193125-12-089158:notes:120]
We classify our investments as available-for-sale. At December 31, 2011, we held the following securities and investments, recorded at either fair value or cost.

[0001193125-12-089158:notes:121]
|  |  |  | September 30, |  |  |  | September 30, |  |  |  | September 30, |  |  |  | September 30, |  |
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair Value /Carrying |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Deferred compensation plan assets |  | $ | 7,994 |  |  | $ | 119 |  |  | $ | (401 | ) |  | $ | 7,712 |  |
| Corporate bonds |  |  | 159,077 |  |  |  | 181 |  |  |  | (2,505 | ) |  |  | 156,753 |  |
| Municipal fixed-rate bonds |  |  | 174,300 |  |  |  | 579 |  |  |  | (53 | ) |  |  | 174,826 |  |
| Municipal variable rate demand notes |  |  | 69,660 |  |  |  | — |  |  |  | — |  |  |  | 69,660 |  |
| Fixed income bond fund |  |  | 527 |  |  |  | 194 |  |  |  | — |  |  |  | 721 |  |
| Marketable equity securities |  |  | 12,771 |  |  |  | 19,098 |  |  |  | (559 | ) |  |  | 31,310 |  |
| Available-for-sale securities held at fair value |  | $ | 424,329 |  |  | $ | 20,171 |  |  | $ | (3,518 | ) |  | $ | 440,982 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 48,250 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 2,123 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 491,355 |  |

[0001193125-12-089158:notes:122]
At December 31, 2010, we held the following securities and investments, recorded at either fair value or cost.

[0001193125-12-089158:notes:123]
|  |  |  | September 30, |  |  |  | September 30, |  |  |  | September 30, |  |  |  | September 30, |  |
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair Value /Carrying |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Deferred compensation plan assets |  | $ | 3,483 |  |  | $ | 770 |  |  | $ | (7 | ) |  | $ | 4,246 |  |
| Corporate bonds |  |  | 126,671 |  |  |  | 630 |  |  |  | (229 | ) |  |  | 127,072 |  |
| Municipal fixed-rate bonds |  |  | 71,212 |  |  |  | 268 |  |  |  | (13 | ) |  |  | 71,467 |  |
| Municipal variable rate demand notes |  |  | 116,745 |  |  |  | — |  |  |  | — |  |  |  | 116,745 |  |
| Fixed income bond fund |  |  | 526 |  |  |  | 220 |  |  |  | — |  |  |  | 746 |  |
| Marketable equity securities |  |  | 11,486 |  |  |  | 36,657 |  |  |  | (133 | ) |  |  | 48,010 |  |
| Available-for-sale securities held at fair value |  | $ | 330,123 |  |  | $ | 38,545 |  |  | $ | (382 | ) |  | $ | 368,286 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 48,250 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 2,103 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 418,639 |  |

[0001193125-12-089158:notes:124]
At December 31, 2011 and 2010, we held $7.7 million and $4.2 million, respectively, of deferred compensation plan assets, carried at fair value.

[0001193125-12-089158:notes:125]
At December 31, 2011 and 2010, we held $156.8 million and $127.1 million, respectively, of corporate bonds. These bonds are classified as available-for-sale and had an average duration of 0.8 years at December 31, 2011. At December 31, 2011, approximately 1% of our corporate bond portfolio had a credit rating of AAA, 11% had a credit rating of AA, 50% had a credit rating of A, and 38% had a credit rating of BBB.

[0001193125-12-089158:notes:126]
At December 31, 2011 and 2010, we held $174.8 million and $71.5 million, respectively, of municipal fixed-rate bonds. These bonds are classified as available-for-sale investments and had an average duration of 1.3 years at December 31, 2011. At December 31, 2011, approximately 19% of our municipal fixed-rate bond portfolio had a credit rating of AAA, 64% had a credit rating of AA, 15% had a credit rating of A, and 2% had a credit rating of BBB. Because our bond portfolio has a high quality rating and contractual maturities of a short duration, we are able to obtain prices for these bonds derived from observable market inputs, or for similar securities traded in an active market, on a daily basis.

[0001193125-12-089158:notes:127]
As of December 31, 2011, corporate and municipal fixed-rate bonds had the following contractual maturities:

[0001193125-12-089158:notes:128]
At December 31, 2011 and 2010, we held $69.7 million and $116.7 million, respectively, of municipal variable rate demand notes, all of which were classified as available-for-sale short-term investments. At December 31, 2011, 18% of our municipal variable rate demand notes had a credit rating of AAA, 58% had a credit rating of AA, 24% had a credit rating of A, and all contained put options of seven days. Despite the long-term nature of their stated contractual maturities, we routinely buy and sell these securities and we believe that we have the ability to quickly liquidate them. Our investments in these securities are recorded at fair value, and the interest rates reset every seven days. We believe we have the ability to sell our variable rate demand notes to the remarketing agent, tender agent or issuer at par value plus accrued interest in the event we decide to liquidate our investment in a particular variable rate demand note. At December 31, 2011, approximately 34% of our variable rate demand notes were supported by letters of credit from banks that we believe to be in good financial condition. The remaining 66% of our variable rate demand notes were supported by standby purchase agreements. As a result of these factors, we had no cumulative gross unrealized holding gains (losses) or gross realized gains (losses) from these investments. All income generated from these investments was recorded as interest income. We have not been required to record any losses relating to municipal variable rate demand notes.

[0001193125-12-089158:notes:129]
At December 31, 2011 and 2010, we held $0.7 million of a fixed income bond fund. This bond fund had unrealized gains of $0.2 million at December 31, 2011 and 2010.

[0001193125-12-089158:notes:130]
At December 31, 2011, we held $31.3 million of marketable equity securities, including a single security, of which we held 1.1 million shares, carried at a fair value of $17.3 million. We sold 0.5 million shares of this security during the 12 months ended December 31, 2011. The sales resulted in proceeds of $9.2 million and a realized gain of $9.1 million. This single security traded approximately 0.8 million shares per day in 2011, in an active market on a European stock exchange. This single security comprises $16.9 million of the gross unrealized gains included in the fair value of our marketable equity securities at December 31, 2011. The remaining $2.2 million of gross unrealized gains and $0.6 million of gross unrealized losses at December 31, 2011 were spread amongst more than 400 equity securities. At December 31, 2010, we held $48.0 million of marketable equity securities, including the single security mentioned above, of which we held 1.5 million shares, carried at a fair value of $34.2 million. This single security comprised $33.7 million of the gross unrealized gains included in the fair value of our marketable equity securities at December 31, 2010. The remaining $3.0 million of unrealized gains and $0.1 million of gross unrealized losses at December 31, 2010 were spread amongst more than 415 equity securities.

[0001193125-12-089158:notes:131]
At December 31, 2011 and 2010, we held a $48.3 million restricted certificate of deposit, which is carried at cost. This investment serves as a collateral deposit against the principal amount outstanding under loans made to ADTRAN pursuant to an Alabama State Industrial Development Authority revenue bond (the Bond). At December 31, 2011, the estimated fair value of the Bond was approximately $46.9 million, based on a debt security with a comparable interest rate and maturity and a Standard & Poor's credit rating of A+. We have the right to set-off the balance of the Bond with the collateral deposit in order to reduce the balance of the indebtedness. For more information on the Bond, see Note 8 of Notes to Consolidated Financial Statements.

[0001193125-12-089158:notes:132]
At December 31, 2011 and 2010, we held $2.1 million of other investments carried at cost, consisting of interests in two private equity funds and an investment in a privately held telecommunications equipment manufacturer. The fair value of these investments was estimated to be approximately $10.0 million at December 31, 2011, based on unobservable inputs including information supplied by the company and the fund managers. We have committed to invest up to an aggregate of $7.9 million in the two private equity funds, and we have contributed $8.4 million as of December 31, 2011, of which $7.7 million has been applied toward these commitments. As of December 31, 2011 we have received distributions related to these two private equity funds of $8.8 million, of which $2.2 million was recorded as investment income. These investments are carried at cost, net of distributions, with distributions in excess of our investment recorded as investment income. The duration of each of these commitments is ten years with $0.1 million expiring in 2013 and $0.1 million expiring in 2012. We have not been required to record any impairment losses related to these investments during the years ended December 31, 2011, 2010 or 2009.

[0001193125-12-089158:notes:133]
Our investment policy provides limitations for issuer concentration, which limits, at the time of purchase, the concentration in any one issuer to 5% of the market value of our total investment portfolio.

[0001193125-12-089158:notes:134]
We review our investment portfolio for potential "other-than-temporary" declines in value on an individual investment basis. We assess, on a quarterly basis, significant declines in value which may be considered other-than-temporary and, if necessary, recognize and record the appropriate charge to write-down the carrying value of such investments. In making this assessment, we take into consideration qualitative and quantitative information, including but not limited to the following: the magnitude and duration of historical declines in market prices, credit rating activity, assessments of liquidity, public filings, and statements made by the issuer. We generally begin our identification of potential other-than-temporary impairments by reviewing any security with a fair value that has declined from its original or adjusted cost basis by 25% or more for six or more consecutive months. We then evaluate the individual security based on the previously identified factors to determine the amount of the write-down, if any. As a result of our review, we recorded an other-than-temporary impairment charge of $36 thousand during the fourth quarter of 2011. For each of the years ended December 31, 2011, 2010 and 2009 we recorded a charge of $68 thousand, $43 thousand and $2.9 million, respectively, related to the other-than-temporary impairment of certain marketable equity securities, a fixed income bond fund and deferred compensation plan assets.

[0001193125-12-089158:notes:135]
Realized gains and losses on sales of securities are computed under the specific identification method. The following table presents gross realized gains and losses related to our investments.

[0001193125-12-089158:notes:136]
|  |  |  | September 30, |  |  |  | September 30, |  |  |  | September 30, |  |
| Year Ended December 31, (In thousands) |  | 2011 |  |  | 2010 |  |  | 2009 |  |
| Gross realized gains |  | $ | 13,641 |  |  | $ | 12,191 |  |  | $ | 1,978 |  |
| Gross realized losses |  | $ | (1,187 | ) |  | $ | (1,183 | ) |  | $ | (3,275 | ) |

[0001193125-12-089158:notes:137]
The following table presents the breakdown of investments with unrealized losses at December 31, 2011.

[0001193125-12-089158:notes:138]
|  |  |  | September 30, |  |  |  | September 30, |  |  |  | September 30, |  |  |  | September 30, |  |  |  | September 30, |  |  |  | September 30, |  |
|  |  | Continuous UnrealizedLoss Position for Lessthan 12 Months |  |  | Continuous UnrealizedLoss Position for 12Months or Greater |  |  | Total |  |
| (In thousands) |  | Fair Value |  |  | UnrealizedLosses |  |  | Fair Value |  |  | UnrealizedLosses |  |  | Fair Value |  |  | UnrealizedLosses |  |
| Deferred compensation plan assets |  | $ | 5,655 |  |  | $ | (401 | ) |  | $ | — |  |  | $ | — |  |  | $ | 5,655 |  |  | $ | (401 | ) |
| Corporate bonds |  |  | 112,345 |  |  |  | (2,505 | ) |  |  | — |  |  |  | — |  |  |  | 112,345 |  |  |  | (2,505 | ) |
| Municipal fixed-rate bonds |  |  | 20,076 |  |  |  | (53 | ) |  |  | — |  |  |  | — |  |  |  | 20,076 |  |  |  | (53 | ) |
| Marketable equity securities |  |  | 4,418 |  |  |  | (543 | ) |  |  | 48 |  |  |  | (16 | ) |  |  | 4,466 |  |  |  | (559 | ) |
| Total |  | $ | 142,494 |  |  | $ | (3,502 | ) |  | $ | 48 |  |  | $ | (16 | ) |  | $ | 142,542 |  |  | $ | (3,518 | ) |

[0001193125-12-089158:notes:139]
The following table presents the breakdown of investments with unrealized losses at December 31, 2010.

[0001193125-12-089158:notes:140]
|  |  |  | September 30, |  |  |  | September 30, |  |  |  | September 30, |  |  |  | September 30, |  |  |  | September 30, |  |  |  | September 30, |  |
|  |  | Continuous UnrealizedLoss Position for Less than12 Months |  |  | Continuous UnrealizedLoss Position for 12Months or Greater |  |  | Total |  |
| (In thousands) |  | Fair Value |  |  | UnrealizedLosses |  |  | Fair Value |  |  | UnrealizedLosses |  |  | Fair Value |  |  | UnrealizedLosses |  |
| Deferred compensation plan assets |  | $ | 338 |  |  | $ | (7 | ) |  | $ | — |  |  | $ | — |  |  | $ | 338 |  |  | $ | (7 | ) |
| Corporate bonds |  |  | 32,326 |  |  |  | (229 | ) |  |  | — |  |  |  | — |  |  |  | 32,326 |  |  |  | (229 | ) |
| Municipal fixed-rate bonds |  |  | 5,869 |  |  |  | (13 | ) |  |  | — |  |  |  | — |  |  |  | 5,869 |  |  |  | (13 | ) |
| Marketable equity securities |  |  | 2,021 |  |  |  | (107 | ) |  |  | 176 |  |  |  | (26 | ) |  |  | 2,197 |  |  |  | (133 | ) |
| Total |  | $ | 40,554 |  |  | $ | (356 | ) |  | $ | 176 |  |  | $ | (26 | ) |  | $ | 40,730 |  |  | $ | (382 | ) |

[0001193125-12-089158:notes:141]
The increase in unrealized losses during 2011, as reflected in the table above, is primarily due to credit yield spreads widening during the second half of 2011 primarily impacting our corporate bonds. At December 31, 2011, a total of 128 of our marketable equity securities were in an unrealized loss position.

[0001193125-12-089158:notes:142]
In accordance with the Fair Value Measurements and Disclosures Topic of the FASB ASC, we have categorized our cash equivalents held in money market funds and our investments held at fair value into a three-level fair value hierarchy based on the priority of the inputs to the valuation technique for the cash equivalents and investments as follows: Level 1—Values based on unadjusted quoted prices for identical assets or liabilities in an active market; Level 2—Values based on quoted prices in markets that are not active or model inputs that are observable either directly or indirectly; Level 3—Values based on prices or valuation techniques that require inputs that are both unobservable and significant to the overall fair value measurement. These inputs include information supplied by investees.

[0001193125-12-089158:notes:143]
|  |  |  | September 30, |  |  |  | September 30, |  |  |  | September 30, |  |  |  | September 30, |  |
|  |  | Fair Value Measurements at December 31, 2011 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarkets forIdentical Assets(Level 1) |  |  | SignificantOtherObservableInputs(Level 2) |  |  | SignificantUnobservableInputs(Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 13,696 |  |  | $ | 13,696 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 7,712 |  |  |  | 7,712 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 156,753 |  |  |  | — |  |  |  | 156,753 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 174,826 |  |  |  | — |  |  |  | 174,826 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 69,660 |  |  |  | — |  |  |  | 69,660 |  |  |  | — |  |
| Fixed income bond fund |  |  | 721 |  |  |  | 721 |  |  |  | — |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – technology industry |  |  | 18,743 |  |  |  | 18,743 |  |  |  | — |  |  |  | — |  |
| Marketable equity securities – other |  |  | 12,567 |  |  |  | 12,567 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 440,982 |  |  |  | 39,743 |  |  |  | 401,239 |  |  |  | — |  |
| Total |  | $ | 454,678 |  |  | $ | 53,439 |  |  | $ | 401,239 |  |  | $ | — |  |

[0001193125-12-089158:notes:144]
As of December 31, 2011 and 2010, the fair value of the investments in available-for-sale Level 2 corporate bonds and municipal fixed-rate bonds was $331.6 million and $198.5 million, respectively. The fair value of these securities is calculated using a weighted average market price for each security. Market prices are obtained from a variety of industry standard data providers, security master files from large financial institutions, and other third-party sources. These multiple market prices are used as inputs into a distribution-curve-based algorithm to determine the daily market value of each security.

[0001193125-12-089158:notes:145]
As of December 31, 2011 and 2010, the fair value of the investments in available-for-sale Level 2 municipal variable rate demand notes was $69.7 million and $116.7 million, respectively. These securities have a structure that implies a standard expected market price. The frequent interest rate resets make it reasonable to expect the price to stay at par. These securities are priced at the expected market price.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001193125-12-089158:notes:146]
Note 1 – Nature of Business and Summary of Significant Accounting Policies

[0001193125-12-089158:notes:147]
ADTRAN, Inc. designs, manufactures and markets solutions and provides services and support for communications networks. Our solutions are widely deployed by providers of communications services (serviced by our Carrier Networks Division), and small and mid-sized enterprises (SMEs) (serviced by our Enterprise Networks Division), and enable voice, data, video and Internet communications across wireline and wireless networks. Many of these solutions are currently in use by every major United States and many global service providers, as well as by many public, private and governmental organizations worldwide.

[0001193125-12-089158:notes:148]
Cash and Cash Equivalents

[0001193125-12-089158:notes:149]
Financial Instruments

[0001193125-12-089158:notes:150]
The carrying amounts reported in the consolidated balance sheets for cash and cash equivalents, accounts receivable, and accounts payable approximate fair value due to the immediate or short-term maturity of these financial instruments. The carrying amount reported for bonds payable was $47.0 million compared to an estimated fair value of $46.9 million, based on a debt security with a comparable interest rate and maturity and a Standard & Poor's credit rating of A+.

[0001193125-12-089158:notes:151]
Investments with maturities beyond one year, such as our municipal variable rate demand notes, may be classified as short-term based on their highly liquid nature and because such marketable securities represent the investment of cash that is available for current operations. At December 31, 2011, 18% of our municipal variable rate demand notes had a credit rating of AAA, 58% had a credit rating of AA, 24% had a credit rating of A, and all contained put options of seven days. Despite the long-term nature of their stated contractual maturities, we routinely buy and sell these securities and we believe that we have the ability to quickly liquidate them. Our investments in these securities are recorded at fair value, and the interest rates reset every seven days. We believe we have the ability to sell our variable rate demand notes to the remarketing agent, tender agent, or issuer at par value plus accrued interest in the event we decide to liquidate our investment in a particular variable rate demand note. At December 31, 2011, approximately 34% of our variable rate demand notes were supported by letters of credit from banks that we believe to be in good financial condition. The remaining 66% of our variable rate demand notes were supported by standby purchase agreements. As a result of these factors, we had no cumulative gross unrealized holding gains (losses) or gross realized gains (losses) from these investments at December 31, 2011. All income generated from these investments was recorded as interest income. We have not been required to record any losses relating to municipal variable rate demand notes.

[0001193125-12-089158:notes:152]
Long-term investments represent a restricted certificate of deposit, municipal fixed-rate bonds, corporate bonds, a fixed income bond fund, marketable equity securities, and other equity investments. Marketable equity securities are reported at fair value as determined by the most recently traded price of the securities at the balance sheet date, although the securities may not be readily marketable due to the size of the available market. Unrealized gains and losses, net of tax, are reported as a separate component of stockholders' equity. Realized gains and losses on sales of securities are computed under the specific identification method and are included in current income. We periodically review our investment portfolio for investments considered to have sustained an other-than-temporary decline in value. Impairment charges for other-than-temporary declines in value are recorded as realized losses in the accompanying consolidated statements of income. All of our investments at December 31, 2011 and 2010 are classified as available-for-sale securities (see Note 4).

[0001193125-12-089158:notes:153]
Accounts Receivable

[0001193125-12-089158:notes:154]
We record accounts receivable at net realizable value. Prior to issuing payment terms to a new customer, we perform a detailed credit review of the customer. Credit limits are established for each new customer based on the results of this credit review. Payment terms are established for each new customer, and collection experience is reviewed periodically in order to determine if the customer's payment terms and credit limits need to be revised. At December 31, 2011, three customers, each of which accounted for more than 10% of our accounts receivable, accounted for 57.3% of our total accounts receivable in the aggregate. At December 31, 2010, three customers, each of which accounted for more than 10% of our accounts receivable, accounted for 54.7% of our total accounts receivable in the aggregate.

[0001193125-12-089158:notes:155]
We maintain an allowance for doubtful accounts for losses resulting from the inability of our customers to make required payments. We regularly review the allowance for doubtful accounts and consider factors such as the age of accounts receivable balances, the current economic conditions that may affect a customer's ability to pay, significant one-time events and our historical experience. If the financial condition of a customer deteriorates, resulting in an impairment of their ability to make payments, we may be required to make additional allowances. If circumstances change with regard to individual receivable balances that have previously been determined to be uncollectible (and for which a specific reserve has been established), a reduction in our allowance for doubtful accounts may be required. Our allowance for doubtful accounts was $8 thousand at December 31, 2011 and $162 thousand at December 31, 2010.

[0001193125-12-089158:notes:156]
Inventory is carried at the lower of cost or market, with cost being determined using the first-in, first-out method. Standard costs for material, labor and manufacturing overhead are used to value inventory. Standard costs are updated at least quarterly; therefore, inventory costs approximate actual costs at the end of each reporting period. We establish reserves for estimated excess, obsolete or unmarketable inventory equal to the difference between the cost of the inventory and the estimated fair value of the inventory based upon assumptions about future demand and market conditions. When we dispose of excess and obsolete inventories, the related write-downs are charged against the inventory reserve.  See Note 5 of Notes to Consolidated Financial Statements for additional information.

[0001193125-12-089158:notes:157]
Property, Plant and Equipment

[0001193125-12-089158:notes:158]
Property, plant and equipment, which is stated at cost, is depreciated using the straight-line method over the estimated useful lives of the assets. We depreciate building and land improvements from five to 39 years, office machinery and equipment from three to seven years, engineering machinery and equipment from three to seven years and computer software from three to five years. Expenditures for repairs and maintenance are charged to expense as incurred. Betterments that materially prolong the lives of the assets are capitalized. The cost of assets retired or otherwise disposed of and the related accumulated depreciation are removed from the accounts, and the gain or loss on such disposition is included in other income (expense), net in the accompanying consolidated statements of income. See Note 6 of Notes to Consolidated Financial Statements for additional information.

[0001193125-12-089158:notes:159]
Liability for Warranty

[0001193125-12-089158:notes:160]
Our products generally include warranties of one to ten years for product defects. We accrue for warranty returns at the time revenue is recognized based on our estimate of the cost to repair or replace the defective products. We engage in extensive product quality programs and processes, including actively monitoring and evaluating the quality of our component suppliers. Our products continue to become more complex in both size and functionality as many of our product offerings migrate from line card applications to systems products. The increasing complexity of our products will cause warranty incidences, when they arise, to be more costly. Our estimates regarding future warranty obligations may change due to product failure rates, material usage, and other rework costs incurred in correcting a product failure. In addition, from time to time, specific warranty accruals may be recorded if unforeseen problems arise. Should our actual experience relative to these factors be worse than our estimates, we will be required to record additional warranty expense. Alternatively, if we provide for more reserves than we require, we will reverse a portion of such provisions in future periods. The liability for warranty obligations totaled $4.1 million and $3.3 million at December 31, 2011 and 2010, respectively. These liabilities are included in accrued expenses in the accompanying consolidated balance sheets.

[0001193125-12-089158:notes:161]
A summary of warranty expense and write-off activity for the years ended December 31, 2011 and 2010 is as follows:

[0001193125-12-089158:notes:162]
|  |  |  | September 30, |  |  |  | September 30, |  |
| Year Ended December 31, |  | 2011 |  |  | 2010 |  |
| (In thousands) |  |  |  |  |  |  |
| Balance at beginning of period |  | $ | 3,304 |  |  | $ | 2,833 |  |
| Plus: amounts acquired or charged to cost and expenses |  |  | 2,893 |  |  |  | 5,309 |  |
| Less: deductions |  |  | (2,079 | ) |  |  | (4,838 | ) |
| Balance at end of period |  | $ | 4,118 |  |  | $ | 3,304 |  |

[0001193125-12-089158:notes:163]
We have two Board and stockholder approved stock option plans from which stock options and other awards are available for grant to employees and directors. All employee and director stock options granted under our stock option plans have an exercise price equal to the fair market value of the award, as defined in the plan, of the underlying common stock on the grant date. There are currently no vesting provisions tied to performance or market conditions for any option awards; vesting for all outstanding option grants is based only on continued service as an employee or director of ADTRAN. All of our outstanding stock option awards are classified as equity awards.

[0001193125-12-089158:notes:164]
Stock-based compensation expense recognized under the Stock Compensation Topic of the Financial Accounting Standards Board Accounting Standards Codification (FASB ASC) in 2011, 2010 and 2009 was approximately $9.2 million, $7.7 million and $7.0 million, respectively. As of December 31, 2011, total compensation cost related to non-vested stock options, restricted stock units and restricted stock not yet recognized was approximately $21.9 million, which is expected to be recognized over an average remaining recognition period of 2.9 years. See Note 3 of Notes to Consolidated Financial Statements for additional information .

[0001193125-12-089158:notes:165]
Goodwill and Purchased Intangible Assets

[0001193125-12-089158:notes:166]
We evaluate the carrying value of goodwill during the fourth quarter of each year and between annual evaluations if events occur or circumstances change that would more likely than not reduce the fair value of the reporting unit below its carrying amount. When evaluating whether goodwill is impaired, we first assess qualitative factors to determine whether it is necessary to perform the two-step quantitative goodwill impairment test. If we determine that the two-step quantitative test is necessary, then we compare the fair value of the reporting unit to which the goodwill is assigned to the reporting unit's carrying amount, including goodwill. If the carrying amount of the reporting unit exceeds its fair value, then the amount of the impairment loss is measured. There were no impairment losses during 2011. Purchased intangible assets with finite lives are carried at cost, less accumulated amortization. Amortization is computed over the estimated useful lives of the respective assets, which is 2.5 to seven years.

[0001193125-12-089158:notes:167]
Research and Development Costs

[0001193125-12-089158:notes:168]
Research and development costs include compensation for engineers and support personnel, outside contracted services, depreciation and material costs associated with new product development, the enhancement of current products, and product cost reductions. We continually evaluate new product opportunities and engage in intensive research and product development efforts. Research and development costs totaled $100.3 million, $90.3 million and $83.3 million for the years ended December 31, 2011, 2010 and 2009, respectively.

[0001193125-12-089158:notes:169]
Comprehensive Income

[0001193125-12-089158:notes:170]
Comprehensive income consists of all changes in equity (net assets) during a period from non-owner sources. Items included in comprehensive income include net income, changes in unrealized gains and losses on marketable securities, and foreign currency translation adjustments. Comprehensive income is presented in the Consolidated Statements of Changes in Stockholders' Equity and Comprehensive Income. The components of accumulated comprehensive income (loss) are as follows:

[0001193125-12-089158:notes:171]
|  |  |  | September 30, |  |  |  | September 30, |  |  |  | September 30, |  |
| (In thousands) |  | Change inUnrealized Gainsand (Losses) onMarketableSecurities, Net ofTax |  |  | Foreign CurrencyTranslationAdjustment |  |  | AccumulatedOtherComprehensiveIncome (Loss) |  |
| Balance at December 31, 2008 |  | $ | (243 | ) |  | $ | (766 | ) |  | $ | (1,009 | ) |
| Activity in 2009 |  |  | 15,384 |  |  |  | 2,468 |  |  |  | 17,852 |  |
| Reclassification adjustment for amounts included in net income |  |  | 1,010 |  |  |  | — |  |  |  | 1,010 |  |
| Balance at December 31, 2009 |  |  | 16,151 |  |  |  | 1,702 |  |  |  | 17,853 |  |
| Activity in 2010 |  |  | 8,700 |  |  |  | 1,394 |  |  |  | 10,094 |  |
| Reclassification adjustment for amounts included in net income |  |  | (999 | ) |  |  | — |  |  |  | (999 | ) |
| Balance at December 31, 2010 |  |  | 23,852 |  |  |  | 3,096 |  |  |  | 26,948 |  |
| Activity in 2011 |  |  | (13,004 | ) |  |  | (154 | ) |  |  | (13,158 | ) |
| Reclassification adjustment for amounts included in net income |  |  | (688 | ) |  |  | — |  |  |  | (688 | ) |
| Balance at December 31, 2011 |  | $ | 10,160 |  |  | $ | 2,942 |  |  | $ | 13,102 |  |

[0001193125-12-089158:notes:172]
The provision for income taxes has been determined using the asset and liability approach of accounting for income taxes. Under this approach, deferred taxes represent the future tax consequences expected to occur when the reported amounts of assets and liabilities are recovered or paid. The provision for income taxes represents income taxes paid or payable for the current year plus the change in deferred taxes during the year. Deferred taxes result from the difference between financial and tax bases of our assets and liabilities and are adjusted for changes in tax rates and tax laws when such changes are enacted. Valuation allowances are recorded to reduce deferred tax assets when it is more likely than not that a tax benefit will not be realized .

[0001193125-12-089158:notes:173]
Revenue Recognition

[0001193125-12-089158:notes:174]
Revenue is generally recognized upon shipment of the product to our customer in accordance with the title transfer terms of the sales agreement, generally FOB shipping point. In the case of consigned inventory, revenue is recognized when the end customer assumes ownership of the product. Contracts that contain multiple deliverables are evaluated to determine the units of accounting, and the revenue from the arrangement is allocated to each item requiring separate revenue recognition based on the relative selling price and corresponding terms of the contract. We strive to use vendor-specific objective evidence of selling price. When this evidence is not available, we are generally not able to determine third-party evidence of selling price because of the extent of customization among competing products or services from other companies. We record revenue associated with installation services when all contractual obligations are complete. Contracts that include both installation services and product sales are evaluated for revenue recognition in accordance with contract terms. As a result, depending on contract terms, installation services may be considered as a separate deliverable item or may be considered an element of the delivered product. Either the purchaser, ADTRAN, or a third party can perform the installation of our products. Shipping fees are recorded as revenue and the related cost is included in cost of sales. Revenue is recorded net of discounts. Also, revenue is recorded when the product price is fixed or determinable, collection of the resulting receivable is probable, and product returns are reasonably estimable. Sales returns are accrued based on historical sales return experience, which we believe provides a reasonable estimate of future returns.

[0001193125-12-089158:notes:175]
A portion of Enterprise Networks products are sold to a non-exclusive distribution network of major technology distributors in the United States. These large organizations then distribute to an extensive network of value-added resellers and system integrators. Value-added resellers and system integrators may be affiliated with us as a channel partner, or they may purchase from the distributor in an unaffiliated fashion. Additionally, with certain limitations our distributors may return unused and unopened product for stock-balancing purposes when such returns are accompanied by offsetting orders for products of equal or greater value.

[0001193125-12-089158:notes:176]
We participate in cooperative advertising and market development programs with certain customers. We use these programs to reimburse customers for certain forms of advertising, and in general, to allow our customers credits up to a specified percentage of their net purchases. Our costs associated with these programs are estimated and included in marketing expenses in our consolidated statements of income. We also participate in rebate programs to provide sales incentives for certain products. Our costs associated with these programs are estimated and accrued at the time of sale, and are recorded as a reduction of sales in our consolidated statements of income.

[0001193125-12-089158:notes:177]
Unearned Revenue

[0001193125-12-089158:notes:178]
Unearned revenue primarily represents customer billings on our maintenance service programs and deferred revenues relating to multiple element contracts where we still have contractual obligations to our customers. We currently offer maintenance contracts ranging from one to five years, primarily on Enterprise Networks Division products sold through distribution channels. Revenue attributable to maintenance contracts is recognized on a straight-line basis over the related contract term. In addition, we provide software maintenance and a variety of hardware maintenance services to Carrier Network Division customers under contracts with terms up to ten years. Non-current unearned revenue is included in other non-current liabilities in the accompanying consolidated balance sheets. At December 31, 2011 and 2010, unearned revenue was as follows:

[0001193125-12-089158:notes:179]
Other income (expense), net, is comprised primarily of miscellaneous income and expense, gains and losses on foreign currency transactions, investment account management fees, and gains or losses on the disposal of property, plant and equipment occurring in the normal course of business .

[0001193125-12-089158:notes:180]
Business Combinations

[0001193125-12-089158:notes:181]
We use the acquisition method to account for business combinations. Under the acquisition method of accounting, we recognize the assets acquired and liabilities assumed at their fair value on the acquisition date. Goodwill is measured as the excess of the consideration transferred over the net assets acquired. Costs incurred to complete the business combination, such as legal, accounting or other professional fees, are charged to general and administrative expenses as they are incurred.

[0001193125-12-089158:notes:182]
Use of Estimates

[0001193125-12-089158:notes:183]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States of America requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenue and expense during the reporting period. Our more significant estimates include the allowance for doubtful accounts, obsolete and excess inventory reserves, warranty reserves, customer rebates, allowance for sales returns, determination of the deferred revenue components of multiple element sales agreements, estimated income tax contingencies, the fair value of stock-based compensation, impairment of goodwill, and the evaluation of other-than-temporary declines in the value of investments. Actual amounts could differ significantly from these estimates.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001193125-12-089158:notes:184]
Note 10 – Employee Benefit Plans

[0001193125-12-089158:notes:185]
401(k) Savings Plan

[0001193125-12-089158:notes:186]
We maintain the ADTRAN, Inc. 401(k) Retirement Plan (Savings Plan) for the benefit of our eligible employees. The Savings Plan is intended to qualify under Sections 401(a) and 401(k) of the Internal Revenue Code of 1986, as amended (Code), and is intended to be a "safe harbor" 401(k) plan under Code Section 401(k)(12). The Savings Plan allows employees to save for retirement by contributing part of their compensation to the plan on a tax-deferred basis. The Savings Plan also requires us to contribute a "safe harbor" amount each year. We match up to 4% of employee contributions (100% of an employee's first 3% of contributions and 50% of their next 2% of contributions), beginning on the employee's one year anniversary date. In calculating our matching contribution, we only use compensation up to the statutory maximum under the Code ($245 thousand for 2011). All contributions under the Savings Plan are 100% vested. Expenses recorded for employer contributions and plan administration costs for the Savings Plan amounted to approximately $4.3 million, $4.6 million and $4.2 million in 2011, 2010 and 2009, respectively.

[0001193125-12-089158:notes:187]
Deferred Compensation Plans

[0001193125-12-089158:notes:188]
We maintain the ADTRAN, Inc. Deferred Compensation Plan (Deferred Compensation Plan). This plan is offered as a supplement to our tax-qualified 401(k) plan and is available to certain executive management employees who have been designated by our Board of Directors. The deferred compensation plan allows participants to defer all or a portion of certain specified bonuses and up to 25% of remaining cash compensation, and permits us to make matching contributions on a discretionary basis, without the limitations that apply to the 401(k) plan. To date, we have not made any matching contributions under this plan.

[0001193125-12-089158:notes:189]
We also maintain the ADTRAN, Inc. Equity Deferral Program for Employees for the purpose of providing deferred compensation for certain executive management employees. Participants may elect to defer all or a portion of their vested Performance Share awards to the Plan. Such deferrals shall continue to be held and deemed to be invested in shares of ADTRAN stock unless and until the amounts are distributed or such deferrals are moved to another deemed investment pursuant to an election made by the Participant.

[0001193125-12-089158:notes:190]
We have set aside the plan assets for both plans in a rabbi trust (Trust) and all contributions are credited to bookkeeping accounts for the participants. The Trust assets are subject to the claims of our creditors in the event of bankruptcy or insolvency. The assets of the Trust are deemed to be invested in pre-approved mutual funds as directed by each participant, and the participant's bookkeeping account is credited with the earnings and losses attributable to those investments. Benefits are scheduled to be distributed six months after termination of employment in a single lump sum payment or annual installments paid over a three or ten year term. Distributions will be made on a pro rata basis from each of the hypothetical investments of the Participant's account in cash. Any whole shares of ADTRAN, Inc. common stock that are distributed will be distributed in-kind.

[0001193125-12-089158:notes:191]
Assets of the Trust are deemed invested in mutual funds that cover an investment spectrum ranging from equities to money market instruments. These mutual funds are publicly quoted and reported at fair value. The fair value of the assets held by the Trust and the amounts payable to the plan participants are as follows:

[0001193125-12-089158:notes:192]
|  |  |  | September 30, |  |  |  | September 30, |  |
| (In thousands) |  | 2011 |  |  | 2010 |  |
| Fair Value of Plan Assets |  |  |  |  |  |  |  |  |
| Long-term Investments |  | $ | 7,710 |  |  | $ | 4,246 |  |
| Total Fair Value of Plan Assets |  | $ | 7,710 |  |  | $ | 4,246 |  |
| Amounts Payable to Plan Participants |  |  |  |  |  |  |  |  |
| Non-current Liabilities |  | $ | 7,710 |  |  | $ | 4,246 |  |
| Total Amounts Payable to Plan Participants |  | $ | 7,710 |  |  | $ | 4,246 |  |

[0001193125-12-089158:notes:193]
Interest and dividend income of the Trust have been included in interest and dividend income in the accompanying 2011, 2010 and 2009 Consolidated Statements of Income. Changes in the fair value of the plan assets held by the Trust have been included in accumulated other comprehensive income in the accompanying 2011 and 2010 Consolidated Balance Sheets. Changes in the fair value of the deferred compensation liability are included as selling, general and administrative expense in the accompanying 2011, 2010 and 2009 Consolidated Statements of Income. Based on the changes in the total fair value of the Trust's assets, we recorded deferred compensation adjustments in 2011, 2010 and 2009 of $(0.2) million, $0.4 million and $0.6 million, respectively.

[0001193125-12-089158:notes:194]
Retiree Medical Coverage

[0001193125-12-089158:notes:195]
We provide medical, dental and prescription drug coverage to one retired former officer and his spouse, for his life, on the same terms as provided to our active officers, and to the spouse of a former deceased officer for up to 30 years. At December 31, 2011 and 2010, this liability totaled $0.2 million.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001193125-12-089158:notes:196]
Note 6 – Property, Plant and Equipment

[0001193125-12-089158:notes:197]
At December 31, 2011 and 2010, property, plant and equipment were comprised of the following:

[0001193125-12-089158:notes:198]
|  |  |  | September 30, |  |  |  | September 30, |  |
| (In thousands) |  | 2011 |  |  | 2010 |  |
| Land |  | $ | 4,263 |  |  | $ | 4,263 |  |
| Building and land improvements |  |  | 16,857 |  |  |  | 15,507 |  |
| Building |  |  | 68,479 |  |  |  | 68,479 |  |
| Furniture and fixtures |  |  | 16,433 |  |  |  | 16,130 |  |
| Computer hardware and software |  |  | 64,053 |  |  |  | 61,898 |  |
| Engineering and other equipment |  |  | 91,232 |  |  |  | 83,946 |  |
| Total Property, Plant and Equipment |  |  | 261,317 |  |  |  | 250,223 |  |
| Less accumulated depreciation |  |  | (186,022 | ) |  |  | (176,237 | ) |
| Total Property, Plant and Equipment (net) |  | $ | 75,295 |  |  | $ | 73,986 |  |

[0001193125-12-089158:notes:199]
Depreciation expense was $10.8 million, $10.2 million and $10.0 million in 2011, 2010 and 2009, respectively.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001193125-12-089158:notes:200]
Note 14 – Summarized Quarterly Financial Data (Unaudited)

[0001193125-12-089158:notes:201]
The following table presents unaudited quarterly operating results for each of our last eight fiscal quarters. This information has been prepared on a basis consistent with our audited financial statements and includes all adjustments, consisting only of normal recurring adjustments, considered necessary for a fair presentation of the data.

[0001193125-12-089158:notes:202]
Unaudited Quarterly Operating Results

[0001193125-12-089158:notes:203]
(In thousands, except for per share amounts)

[0001193125-12-089158:notes:204]
|  |  |  | September 30, |  |  |  | September 30, |  |  |  | September 30, |  |  |  | September 30, |  |
| Three Months Ended |  | March 31, 2011 |  |  | June 30, 2011 |  |  | September 30, 2011 |  |  | December 31, 2011 |  |
| Net sales |  | $ | 165,522 |  |  | $ | 184,227 |  |  | $ | 192,194 |  |  | $ | 175,286 |  |
| Gross profit |  | $ | 98,795 |  |  | $ | 106,827 |  |  | $ | 109,476 |  |  | $ | 99,220 |  |
| Operating income |  | $ | 45,606 |  |  | $ | 51,310 |  |  | $ | 51,107 |  |  | $ | 41,115 |  |
| Net income |  | $ | 34,258 |  |  | $ | 36,943 |  |  | $ | 36,213 |  |  | $ | 31,163 |  |
| Earnings per common share |  | $ | 0.53 |  |  | $ | 0.57 |  |  | $ | 0.57 |  |  | $ | 0.49 |  |
| Earnings per common share assuming dilution (1) |  | $ | 0.52 |  |  | $ | 0.56 |  |  | $ | 0.56 |  |  | $ | 0.48 |  |

[0001193125-12-089158:notes:205]
|  |  |  | September 30, |  |  |  | September 30, |  |  |  | September 30, |  |  |  | September 30, |  |
| Three Months Ended |  | March 31, 2010 |  |  | June 30, 2010 |  |  | September 30, 2010 |  |  | December 31, 2010 |  |
| Net sales |  | $ | 127,027 |  |  | $ | 150,361 |  |  | $ | 162,957 |  |  | $ | 165,329 |  |
| Gross profit |  | $ | 75,328 |  |  | $ | 89,329 |  |  | $ | 97,299 |  |  | $ | 96,907 |  |
| Operating income |  | $ | 25,345 |  |  | $ | 38,617 |  |  | $ | 45,045 |  |  | $ | 44,857 |  |
| Net income |  | $ | 18,194 |  |  | $ | 27,751 |  |  | $ | 32,084 |  |  | $ | 35,960 |  |
| Earnings per common share |  | $ | 0.29 |  |  | $ | 0.45 |  |  | $ | 0.51 |  |  | $ | 0.57 |  |
| Earnings per common share assuming dilution (1) |  | $ | 0.29 |  |  | $ | 0.44 |  |  | $ | 0.50 |  |  | $ | 0.56 |  |

[0001193125-12-089158:notes:206]
| (1) | Assumes exercise of dilutive stock options calculated under the treasury stock method. |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001193125-12-089158:notes:207]
Note 15 – Related Party Transactions

[0001193125-12-089158:notes:208]
We employ the law firm of our director emeritus for legal services. All bills for services rendered by this firm are reviewed and approved by our Chief Financial Officer. We believe that the fees for such services are comparable to those charged by other firms for services rendered to us. For the years ended 2011, 2010 and 2009, we incurred fees of $10 thousand per month for these legal services.


## us-gaap:ScheduleOfDeferredTaxAssetsAndLiabilitiesTableTextBlock

[0001193125-12-089158:notes:209]
| (In thousands) |  | 2011 |  |  | 2010 |  |
| Current deferred tax assets |  |  |  |  |  |  |  |  |
| Accounts receivable |  | $ | 4 |  |  | $ | 61 |  |
| Inventory |  |  | 6,709 |  |  |  | 6,032 |  |
| Accrued expenses |  |  | 5,412 |  |  |  | 4,524 |  |
| Total Current Deferred Tax Assets |  |  | 12,125 |  |  |  | 10,617 |  |
| Non-current deferred tax assets |  |  |  |  |  |  |  |  |
| Accrued expenses |  |  | 113 |  |  |  | 102 |  |
| Deferred compensation |  |  | 3,177 |  |  |  | 1,539 |  |
| Stock-based compensation |  |  | 3,808 |  |  |  | 3,542 |  |
| State tax and interest expense |  |  | 947 |  |  |  | 861 |  |
| Foreign loss and state credit carry-forwards |  |  | 7,891 |  |  |  | 5,988 |  |
| Federal loss and research carry-forwards |  |  | 14,778 |  |  |  |  |  |
| Valuation allowance |  |  | (7,585 | ) |  |  | (5,627 | ) |
| Total Non-current Deferred Tax Assets |  |  | 23,129 |  |  |  | 6,405 |  |
| Total Deferred Tax Assets |  | $ | 35,254 |  |  | $ | 17,022 |  |
| Non-current deferred tax liabilities |  |  |  |  |  |  |  |  |
| Accumulated depreciation |  | $ | (7,081 | ) |  | $ | (4,782 | ) |
| Intellectual property |  |  | (2,594 | ) |  |  |  |  |
| Investments |  |  | (5,109 | ) |  |  | (11,973 | ) |
| Total Non-current Deferred Tax Liabilities |  | $ | (14,784 | ) |  | $ | (16,755 | ) |
| Net Deferred Tax Assets |  | $ | 20,470 |  |  | $ | 267 |  |


## us-gaap:ScheduleOfEntityWideInformationRevenueFromExternalCustomersByProductsAndServicesTextBlock

[0001193125-12-089158:notes:210]
|  |  |  | September 30, |  |  |  | September 30, |  |  |  | September 30, |  |
| (In thousands) |  | 2011 |  |  | 2010 |  |  | 2009 |  |
| Carrier Systems |  | $ | 420,289 |  |  | $ | 289,314 |  |  | $ | 215,715 |  |
| Business Networking |  |  | 162,186 |  |  |  | 127,233 |  |  |  | 100,451 |  |
| Loop Access |  |  | 134,754 |  |  |  | 189,127 |  |  |  | 168,019 |  |
| Total |  | $ | 717,229 |  |  | $ | 605,674 |  |  | $ | 484,185 |  |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0001193125-12-089158:notes:211]
|  |  |  | September 30, |  |  |  | September 30, |  |  |  | September 30, |  |
| (In thousands) |  | 2011 |  |  | 2010 |  |  | 2009 |  |
| United States |  | $ | 632,795 |  |  | $ | 573,845 |  |  | $ | 456,402 |  |
| International |  |  | 84,434 |  |  |  | 31,829 |  |  |  | 27,783 |  |
| Total |  | $ | 717,229 |  |  | $ | 605,674 |  |  | $ | 484,185 |  |


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001193125-12-089158:notes:212]
|  |  |  | September 30, |  |  |  | September 30, |  |  |  | September 30, |  |  |  | September 30, |  |  |  | September 30, |  |  |  | September 30, |  |
| Sales and Gross Profit by Market Segment |  | 2011 |  |  | 2010 |  |  | 2009 |  |
| (In thousands) |  | Sales |  |  | Gross Profit |  |  | Sales |  |  | Gross Profit |  |  | Sales |  |  | Gross Profit |  |
| Carrier Networks |  | $ | 569,579 |  |  | $ | 327,813 |  |  | $ | 476,030 |  |  | $ | 283,310 |  |  | $ | 371,349 |  |  | $ | 219,681 |  |
| Enterprise Networks |  |  | 147,650 |  |  |  | 86,505 |  |  |  | 129,644 |  |  |  | 75,553 |  |  |  | 112,836 |  |  |  | 67,281 |  |
|  |  | $ | 717,229 |  |  | $ | 414,318 |  |  | $ | 605,674 |  |  | $ | 358,863 |  |  | $ | 484,185 |  |  | $ | 286,962 |  |


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001193125-12-089158:notes:213]
ADTRAN, INC.

[0001193125-12-089158:notes:214]
SCHEDULE II

[0001193125-12-089158:notes:215]
VALUATION AND QUALIFYING ACCOUNTS

[0001193125-12-089158:notes:216]
|  |  |  | September 30, |  |  |  | September 30, |  |  |  | September 30, |  |  |  | September 30, |  |  |  | September 30, |  |
| Column A |  | Column B |  |  | Column C |  |  | Column D |  |  | Column E |  |  | Column F |  |
| (In thousands) |  | Balance atBeginningof Period |  |  | AssumedonAcquisition |  |  | Charged toCosts &Expenses |  |  | Deductions |  |  | Balance atEnd ofPeriod |  |
| Year ended December 31, 2011 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for Doubtful Accounts |  | $ | 162 |  |  |  | — |  |  |  | 117 |  |  |  | 271 |  |  | $ | 8 |  |
| Inventory Reserve |  | $ | 8,932 |  |  |  | — |  |  |  | 1,137 |  |  |  | 650 |  |  | $ | 9,419 |  |
| Warranty Liability |  | $ | 3,304 |  |  |  | 33 |  |  |  | 2,860 |  |  |  | 2,079 |  |  | $ | 4,118 |  |
| Deferred Tax Asset Valuation Allowance |  | $ | 5,627 |  |  |  | 1,462 |  |  |  | 496 |  |  |  | — |  |  | $ | 7,585 |  |
| Year ended December 31, 2010 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for Doubtful Accounts |  | $ | 138 |  |  |  | — |  |  |  | 72 |  |  |  | 48 |  |  | $ | 162 |  |
| Inventory Reserve |  | $ | 7,750 |  |  |  | — |  |  |  | 1,992 |  |  |  | 810 |  |  | $ | 8,932 |  |
| Warranty Liability |  | $ | 2,833 |  |  |  | — |  |  |  | 5,309 |  |  |  | 4,838 |  |  | $ | 3,304 |  |
| Deferred Tax Asset Valuation Allowance |  | $ | 5,340 |  |  |  | — |  |  |  | 391 |  |  |  | 104 |  |  | $ | 5,627 |  |
| Year ended December 31, 2009 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for Doubtful Accounts |  | $ | 38 |  |  |  | 3 |  |  |  | 102 |  |  |  | 5 |  |  | $ | 138 |  |
| Inventory Reserve |  | $ | 7,728 |  |  |  | — |  |  |  | 1,681 |  |  |  | 1,659 |  |  | $ | 7,750 |  |
| Warranty Liability |  | $ | 2,812 |  |  |  | — |  |  |  | 2,665 |  |  |  | 2,644 |  |  | $ | 2,833 |  |
| Deferred Tax Asset Valuation Allowance |  | $ | 1,581 |  |  |  | 3,549 |  |  |  | 251 |  |  |  | 41 |  |  | $ | 5,340 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-12-089158:notes:217]
Note 11 – Segment Information and Major Customers

[0001193125-12-089158:notes:218]
We operate in two reportable segments: (1) the Carrier Networks Division and (2) the Enterprise Networks Division. The accounting policies of the segments are the same as those described in the "Nature of Business and Summary of Significant Accounting Policies" (see Note 1) to the extent that such policies affect the reported segment information. We evaluate the performance of our segments based on gross profit; therefore, selling, general and administrative expense, research and development expenses, interest income and dividend income, interest expense, net realized investment gain/loss, other income/expense and provision for taxes are reported on an entity-wide basis only. There are no inter-segment revenues.

[0001193125-12-089158:notes:219]
The following table presents information about the reported sales and gross profit of our reportable segments for each of the years ended December 31, 2011, 2010 and 2009. Asset information by reportable segment is not reported, since we do not produce such information internally.

[0001193125-12-089158:notes:220]
Sales by Product

[0001193125-12-089158:notes:221]
Our three major product categories are Carrier Systems, Business Networking and Loop Access.

[0001193125-12-089158:notes:222]
Carrier Systems products are used by communications service providers to provide data, voice and video services to consumers and enterprises. The Carrier Systems category includes our broadband access products comprised of Total Access® 5000 multi-service access and aggregation platform products, Total Access 1100/1200 Series Fiber-To-The-Node (FTTN) products, Ultra Broadband Ethernet (UBE) and Digital Subscriber Line Access Multiplexer (DSLAM) products. Our broadband access products are used by service providers to deliver high-speed Internet access, Voice over Internet Protocol (VoIP), IP Television (IPTV), and/or Ethernet services from the central office or remote terminal locations to customer premises. The Carrier Systems category also includes our optical access products. These products consist of optical access multiplexers and transceivers including those used in our Optical Networking Edge (ONE) products, NetVanta 8000 series products, and our family of OPTI products. Optical access products are used to deliver higher bandwidth services, aggregate large numbers of low bandwidth services, or transport wavelength services across a fiber optic infrastructure. Total Access 1500 products, 303 concentrator products, M13 multiplexer products, and a number of mobile backhaul products are also included in the Carrier Systems product category.

[0001193125-12-089158:notes:223]
Business Networking products provide access to telecommunication services, facilitating the delivery of converged services and Unified Communications to the small and mid-sized enterprises (SME) market. The Business Networking category includes Internetworking products and Integrated Access Devices (IADs). Internetworking products consist of our Total Access IP Business Gateways, Optical Network Terminals (ONTs), Virtual Wireless LAN products and NetVanta product lines. NetVanta products include multi-service routers, managed Ethernet switches, IP Private Branch Exchange (PBX) products, IP phone products, Unified Communications solutions, Unified Threat Management (UTM) solutions, and Carrier Ethernet Network Terminating Equipment (NTE). IAD products consist of our Total Access 600 Series and the Total Access 850.

[0001193125-12-089158:notes:224]
Loop Access products are used by carrier and enterprise customers for access to copper-based telecommunications networks. The Loop Access category includes products such as: Digital Data Service (DDS) and Integrated Services Digital Network (Total Reach) products, High bit-rate Digital Subscriber Line (HDSL) products including Total Access 3000 HDSL and Time Division Multiplexed-Symmetrical HDSL (TDM-SHDSL) products, T1/E1/T3, Channel Service Units/Data Service Units, and TRACER fixed wireless products.

[0001193125-12-089158:notes:225]
The table below presents sales information by product category for the years ended December 31, 2011, 2010 and 2009:

[0001193125-12-089158:notes:226]
In addition, we identify subcategories of product revenues, which we divide into our core products and legacy products. Our core products consist of Broadband Access and Optical Access products (included in Carrier Systems) and Internetworking products (included in Business Networking) and our legacy products include HDSL products (included in Loop Access) and other products not included in the aforementioned core products.

[0001193125-12-089158:notes:227]
The table below presents subcategory revenues for the years ended December 31, 2011, 2010 and 2009:

[0001193125-12-089158:notes:228]
Sales by Geographic Region

[0001193125-12-089158:notes:229]
The following table presents sales information by geographic area for the years ended December 31, 2011, 2010 and 2009. International sales correlate to shipments with a non-U.S. destination.

[0001193125-12-089158:notes:230]
Single customers comprising more than 10% of our revenue in 2011 included two customers at 25% and 10%, respectively. Single customers comprising more than 10% of our revenue in 2010 included three customers at 20%, 18%, and 11%, respectively. Single customers comprising more than 10% of our revenue in 2009 included three customers at 22%, 19%, and 11%, respectively. No other customer accounted for 10% or more of our sales in 2011, 2010 or 2009.

[0001193125-12-089158:notes:231]
Sales to Major Service Providers amounted to approximately 72%, 72% and 69% of total sales during the years ended December 31, 2011, 2010 and 2009, respectively. In addition, a significant portion of our products are sold directly to distributors and certain value-added resellers, which accounted for approximately 26%, 26% and 28% of our revenue for each of the years ended December 31, 2011, 2010 and 2009, respectively.

[0001193125-12-089158:notes:232]
As of December 31, 2011, long-lived assets, net totaled $75.3 million, which includes $73.9 million held in the United States and $1.4 million held outside the United States. As of December 31, 2010, long-lived assets, net totaled $74.0 million, which includes $73.0 million held in the United States and $1.0 million held outside the United States.


## us-gaap:SubsequentEventsTextBlock

[0001193125-12-089158:notes:233]
Note 16 – Subsequent Events

[0001193125-12-089158:notes:234]
On January 17, 2012, the Board declared a quarterly cash dividend of $0.09 per common share to be paid to stockholders of record at the close of business on February 2, 2012. The quarterly dividend payment was $5.7 million and was paid on February 16, 2012. In July 2003, our Board of Directors elected to begin declaring quarterly dividends on our common stock considering the tax treatment of dividends and adequate levels of Company liquidity.
