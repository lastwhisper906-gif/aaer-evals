# ADTN MD&A — 0001193125-12-089158


## mdna

[0001193125-12-089158:mdna:1]
| ITEM 7. | MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS |

[0001193125-12-089158:mdna:2]
Overview

[0001193125-12-089158:mdna:3]
ADTRAN, Inc.
designs, manufactures and markets solutions and provides services and support for communications networks. Our solutions are widely deployed by providers of communications services (serviced by our Carrier Networks Division), and small and mid-sized
enterprises (SMEs) (serviced by our Enterprise Networks Division), and enable voice, data, video and Internet communications across wireline and wireless networks. Many of these solutions are currently in use by every major United States and many
global service providers, as well as by many public, private and governmental organizations worldwide.

[0001193125-12-089158:mdna:4]
Our success depends
upon our ability to increase unit volume and market share through the introduction of new products and succeeding generations of products having lower selling prices and increased functionality as compared to both the prior generation of a product
and to the products of competitors. An important part of our strategy is to reduce the cost of each succeeding product generation and then lower the product’s selling price based on the cost savings achieved in order to gain market share and/or
improve gross margins. As a part of this strategy, we seek in most instances to be a high-quality, low-cost provider of products in our markets. Our success to date is attributable in large measure to our ability to design our products initially
with a view to their subsequent redesign, allowing both increased functionality and reduced manufacturing costs in each succeeding product generation. This strategy enables us to sell succeeding generations of products to existing customers, while
increasing our market share by selling these enhanced products to new customers.

[0001193125-12-089158:mdna:5]
Our three major product categories are Carrier Systems,
Business Networking and Loop Access.

[0001193125-12-089158:mdna:6]
Carrier Systems products are used by communications service
providers to provide data, voice and video services to consumers and enterprises. The Carrier Systems category includes our broadband access products comprised of Total Access® 5000 multi-service access and aggregation platform products, Total Access 1100/1200 Series Fiber-To-The-Node (FTTN) products, Ultra Broadband Ethernet (UBE) and
Digital Subscriber Line Access Multiplexer (DSLAM) products. Our broadband access products are used by service providers to deliver high-speed Internet access, Voice over Internet Protocol (VoIP), IP Television (IPTV), and/or Ethernet services from
the central office or remote terminal locations to customer premises. The Carrier Systems category also includes our optical access products. These products consist of optical access multiplexers and transceivers including those used in our Optical
Networking Edge (ONE) products, NetVanta 8000 series products, and our family of OPTI products. Optical access products are used to deliver higher bandwidth services, aggregate large numbers of low bandwidth services, or transport wavelength
services across a fiber optic infrastructure. Total Access 1500 products, 303 concentrator products, M13 multiplexer products, and a number of mobile backhaul products are also included in the Carrier Systems product category.

[0001193125-12-089158:mdna:7]
Business Networking products provide access to telecommunication services, facilitating the delivery of converged services and
Unified Communications to the small and mid-sized enterprises (SME) market. The Business Networking category includes Internetworking products and Integrated Access Devices (IADs). Internetworking products consist of our Total Access IP Business
Gateways, Optical Network Terminals (ONTs), Virtual Wireless LAN products and NetVanta product lines. NetVanta products include multi-service routers, managed Ethernet switches, IP Private Branch Exchange (PBX) products, IP phone products, Unified
Communications solutions, Unified Threat Management (UTM) solutions, and Carrier Ethernet Network Terminating Equipment (NTE). IAD products consist of our Total Access 600 Series and the Total Access 850.

[0001193125-12-089158:mdna:8]
Loop Access products are used by carrier and enterprise customers for access to copper-based telecommunications networks. The Loop
Access category includes products such as: Digital Data Service (DDS) and Integrated Services Digital Network (Total Reach) products, High bit-rate Digital Subscriber Line (HDSL) products including Total Access 3000 HDSL and Time Division
Multiplexed-Symmetrical HDSL (TDM-SHDSL) products, T1/E1/T3, Channel Service Units/Data Service Units, and TRACER fixed wireless products.

[0001193125-12-089158:mdna:9]
In addition, we identify subcategories of product revenues, which we divide into our core products and legacy products. Our core products consist of Broadband Access and Optical Access products (included
in Carrier Systems) and Internetworking products (included in Business Networking) and our legacy products include HDSL products (included in Loop Access) and other products not included in the aforementioned core products. Many of our customers are
migrating their networks to deliver higher bandwidth services by utilizing newer technologies. We believe that products and services offered in our core product areas position us well for this migration. Despite occasional increases, we anticipate
that revenues of many of our legacy products, including HDSL, will decline over time; however, revenues from these products may continue for years because of the time required for our customers to transition to newer technologies.

[0001193125-12-089158:mdna:10]
Sales were $717.2 million in 2011 compared to $605.7 million in 2010 and $484.2 million in
2009. Sales increased in each of our core areas, Broadband Access, Optical Access and Internetworking. Total sales of products in these three core areas increased 48.2% in 2011 compared to 2010 and 40.2% in 2010 compared to 2009. Our gross profit
margin for the Company decreased to 57.8% in 2011 from 59.3% in 2010 and 2009. Our operating income margin increased to 26.4% in 2011 compared to 25.4% in 2010 and 21.5% in 2009. Net income was $138.6 million in 2011 compared to $114.0 million in
2010 and $74.2 million in 2009. Earnings per share, assuming dilution, were $2.12 in 2011 compared to $1.78 in 2010 and $1.17 in 2009. Earnings per share in 2011, 2010 and 2009 include the effect of the repurchase of 1.1 million,
0.7 million and 0.8 million shares of our stock in those years, respectively.

[0001193125-12-089158:mdna:11]
Our operating results have fluctuated
on a quarterly basis in the past, and may vary significantly in future periods due to a number of factors, including customer order activity and backlog. Backlog levels vary because of seasonal trends, the timing of customer projects and other
factors that affect customer order lead times. Many of our customers require prompt delivery of products. This requires us to maintain sufficient inventory levels to satisfy anticipated customer demand. If near-term demand for our products declines,
or if potential sales in any quarter do not occur as anticipated, our financial results could be adversely affected. Operating expenses are relatively fixed in the short term; therefore, a shortfall in quarterly revenues could significantly impact
our financial results in a given quarter.

[0001193125-12-089158:mdna:12]
Our operating results may also fluctuate as a result of a number of other factors,
including a decline in general economic and market conditions, increased competition, customer order patterns, changes in product and services mix, timing differences between price decreases and product cost reductions, product warranty returns,
expediting costs and announcements of new products by us or our competitors. Additionally, maintaining sufficient inventory levels to assure prompt delivery of our products increases the amount of inventory that may become obsolete and increases the
risk that the obsolescence of this inventory may have an adverse effect on our business and operating results. Also, not maintaining sufficient inventory levels to assure prompt delivery of our products may cause us to incur expediting costs to meet
customer delivery requirements, which may negatively impact our operating results in a given quarter.

[0001193125-12-089158:mdna:13]
Accordingly, our
historical financial performance is not necessarily a meaningful indicator of future results, and, in general, management expects that our financial results may vary from period to period. See Note 14 of Notes to Consolidated Financial Statements
for additional information. For a discussion of risks associated with our operating results, see Item 1A of this report.

[0001193125-12-089158:mdna:14]
Critical Accounting Policies and Estimates

[0001193125-12-089158:mdna:15]
An accounting policy is deemed to be critical if it requires an accounting estimate to be made based on assumptions about matters that are highly uncertain at the time the estimate is made, if different
estimates reasonably could have been used, or if changes in the accounting estimate that are reasonably likely to occur could materially impact the results of financial operations. We believe the following critical accounting policies affect our
more significant judgments and estimates used in the preparation of our consolidated financial statements. These policies have been consistently applied across our two reportable segments: (1) Carrier Networks Division and (2) Enterprise
Networks Division.

[0001193125-12-089158:mdna:16]
|  | • |  | We review customer contracts to determine if all of the requirements for revenue recognition have been met prior to recording revenues from sales transactions. We generally record sales revenue upon shipment of our products, net of any rebates or discounts, since: (i) we generally do not have significant post-delivery obligations, (ii) the product price is fixed or determinable, (iii) collection of the resulting receivable is probable, and (iv) product returns are reasonably estimable. We generally ship products upon receipt of a purchase order from a customer. We evaluate shipping terms and we record revenue on products shipped in accordance with the terms of each respective contract where applicable, or under our standard shipping terms for purchase orders accepted without a contract, generally FOB shipping point. In the case of consigned inventory, revenue is recognized when the customer assumes ownership of the product. Contracts that contain multiple deliverables are evaluated to determine the units of accounting, and the revenue from the arrangement is allocated to each item requiring separate revenue recognition based on the relative selling price and corresponding terms of the contract. We strive to use vendor-specific objective evidence of selling price. When this evidence is not available, we are generally not able to determine third-party evidence of selling price because of the extent of customization among competing products or services from other companies. We record revenue associated with installation services when all contractual obligations are complete. Contracts that include both installation services and product sales are evaluated for revenue recognition in accordance with contract terms. As a result, depending on contract terms, installation services may be considered as a separate deliverable item or may be considered an element of the delivered product. Either the purchaser, ADTRAN, or a third party can perform installation of our products. Revenues related to maintenance services are recognized on a straight line basis over the contract term. |

[0001193125-12-089158:mdna:17]
|  | • |  | Sales returns are accrued based on historical sales return experience, which we believe provides a reasonable estimate of future returns. A significant portion of Enterprise Networks products are sold in the United States through a non-exclusive distribution network of major technology distributors. These organizations then distribute to an extensive network of value- |

[0001193125-12-089158:mdna:18]
|  | added resellers and system integrators. Value-added resellers and system integrators may be affiliated with us as a channel partner, or they may purchase from the distributor on an unaffiliated basis. Additionally, with certain limitations, our distributors may return unused and unopened product for stock-balancing purposes when these returns are accompanied by offsetting orders for products of equal or greater value. |

[0001193125-12-089158:mdna:19]
We participate in cooperative advertising and market development programs with certain
customers. We use these programs to reimburse customers for certain forms of advertising, and in general, to allow our customers credits up to a specified percentage of their net purchases. Our costs associated with these programs are estimated and
accrued at the time of sale and are included in selling, general and administrative expenses in our consolidated statements of income. We also participate in rebate programs to provide sales incentives for certain products. Our costs associated with
these programs are estimated and accrued at the time of sale and are recorded as a reduction of sales in our consolidated statements of income.

[0001193125-12-089158:mdna:20]
Prior to issuing payment terms to a new customer, we perform a detailed credit review of the customer. Credit limits and payment terms are established for each new customer based on the results of this
credit review. Collection experience is reviewed periodically in order to determine if the customer’s payment terms and credit limits need to be revised. We maintain allowances for doubtful accounts for losses resulting from the inability of
our customers to make required payments. If the financial condition of our customers deteriorates, resulting in an impairment of their ability to make payments, we may be required to make additional allowances. If circumstances change with regard to
individual receivable balances that have previously been determined to be uncollectible (and for which a specific reserve has been established), a reduction in our allowance for doubtful accounts may be required. Our allowance for doubtful accounts
was $8 thousand at December 31, 2011 and $0.2 million at December 31, 2010.

[0001193125-12-089158:mdna:21]
|  | • |  | We carry our inventory at the lower of cost or market, with cost being determined using the first-in, first-out method. We use standard costs for material, labor, and manufacturing overhead to value our inventory. Our standard costs are updated on at least a quarterly basis and any variances are expensed in the current period; therefore, our inventory costs approximate actual costs at the end of each reporting period. We write down our inventory for estimated obsolescence or unmarketable inventory by an amount equal to the difference between the cost of inventory and the estimated fair value based upon assumptions about future demand and market conditions. If actual future demand or market conditions are less favorable than those projected by management, we may be required to make additional inventory write-downs. Our reserve for excess and obsolete inventory was $9.4 million and $8.9 million at December 31, 2011 and 2010, respectively. Inventory write-downs charged to the reserve were $0.7 million, $0.8 million and $1.7 million for the years ended December 31, 2011, 2010 and 2009, respectively. |

[0001193125-12-089158:mdna:22]
|  | • |  | The objective of our short-term investment policy is to preserve principal and maintain adequate liquidity with appropriate diversification, while achieving market returns. The objective of our long-term investment policy is principal preservation and total return; that is, the aggregate return from capital appreciation, dividend income, and interest income. These objectives are achieved through investments with appropriate diversification in fixed and variable rate income securities, public equity, and private equity portfolios. Our investment policy provides limitations for issuer concentration, which limits, at the time of purchase, the concentration in any one issuer to 5% of the market value of our total investment portfolio. We have experienced significant volatility in the market prices of our publicly traded equity investments. These investments are recorded on the consolidated balance sheets at fair value with unrealized gains and losses reported as a component of accumulated other comprehensive income, net of tax. The ultimate realized value on these equity investments is subject to market price volatility. |

[0001193125-12-089158:mdna:23]
In accordance with the Fair Value Measurements and Disclosures Topic of the
FASB ASC, we have categorized our cash equivalents held in money market funds and our investments held at fair value into a three-level fair value hierarchy based on the priority of the inputs to the valuation technique for the cash equivalents and
investments as follows: Level 1 – Values based on unadjusted quoted prices for identical assets or liabilities in an active market; Level 2 – Values based on quoted prices in markets that are not active or model inputs that are observable
either directly or indirectly for substantially the full term of the asset or liability; Level 3 – Values based on prices or valuation techniques that require inputs that are both unobservable and significant to the overall fair value
measurement. These inputs include information supplied by investees. At December 31, 2011, we categorized $39.7 million and $401.2 million of our available-for-sale investments as Level 1 and Level 2, respectively, and $13.7 million of our cash
equivalents as Level 1. At December 31, 2010, we categorized $53.0 million and $315.3 million of our available-for-sale investments as Level 1 and Level 2, respectively, and $14.5 million of our cash equivalents as Level 1.

[0001193125-12-089158:mdna:24]
29

[0001193125-12-089158:mdna:25]
We review our investment portfolio for potential
“other-than-temporary” declines in value on an individual investment basis. We assess, on a quarterly basis, significant declines in value which may be considered other-than-temporary and, if necessary, recognize and record the appropriate
charge to write-down the carrying value of such investments. In making this assessment, we take into consideration qualitative and quantitative information, including but not limited to the following: the magnitude and duration of historical
declines in market prices, credit rating activity, assessments of liquidity, public filings, and statements made by the issuer. We generally begin our identification of potential other-than-temporary impairments by reviewing any security with a fair
value that has declined from its original or adjusted cost basis by 25% or more for six or more consecutive months. We then evaluate the individual security based on the previously identified factors to determine the amount of the write-down, if
any. As a result of our review, we recorded an other-than-temporary impairment charge of $36 thousand during the fourth quarter of 2011. For the years ended December 31, 2011, 2010 and 2009, we recorded charges of $68 thousand, $43 thousand and
$2.9 million, respectively, related to the other-than-temporary impairment of certain publicly traded equity securities, a fixed income bond fund, and deferred compensation plan assets. Actual losses, if any, could ultimately differ from these
estimates. Future adverse changes in market conditions or poor operating results of underlying investments could result in additional losses that may not be reflected in an investment’s current carrying value, thereby possibly requiring an
impairment charge in the future. See Note 4 of Notes to the Consolidated Financial Statements in this report for more information about our investments.

[0001193125-12-089158:mdna:26]
We also invest in privately held entities and private equity funds and record these investments at cost. We review these investments periodically in order to determine if circumstances (both financial and
non-financial) exist that indicate that we will not recover our initial investment. Impairment charges are recorded on investments having a cost basis that is greater than the value that we would reasonably expect to receive in an arm’s length
sale of the investment. We have not been required to record any impairment losses relating to these investments in 2011, 2010 or 2009.

[0001193125-12-089158:mdna:27]
|  | • |  | For purposes of determining the estimated fair value of our stock option awards on the date of grant under the Stock Compensation Topic of the FASB ASC, we use the Black-Scholes Model. This model requires the input of certain assumptions that require subjective judgment. These assumptions include, but are not limited to, expected stock price volatility over the term of the awards and actual and projected employee stock option exercise behaviors. Because our stock option awards have characteristics significantly different from those of traded options, and because changes in the input assumptions can materially affect the fair value estimate, the existing model may not provide a reliable single measure of the fair value of our stock option awards. For purposes of determining the estimated fair value of our performance-based restricted stock unit awards on the date of grant, we use a Monte Carlo Simulation valuation method. The restricted stock units are subject to a market condition based on the relative total shareholder return of ADTRAN against a peer group of companies (2009 grant) or against all companies in the NASDAQ Telecommunications Index (2010 and 2011 grants) and vest at the end of a three-year performance period. The fair value of restricted stock issued to our Directors in 2011 is equal to the closing price of our stock on the date of grant. Management will continue to assess the assumptions and methodologies used to calculate the estimated fair value of stock-based compensation. Circumstances may change and additional data may become available over time, which could result in changes to these assumptions and methodologies and thereby materially impact our fair value determination. If factors change and we use different assumptions in the application of the Stock Compensation Topic of the FASB ASC in future periods, the compensation expense that we record may differ significantly from what we have recorded in the current period. |

[0001193125-12-089158:mdna:28]
|  | • |  | We estimate our income tax provision or benefit in each of the jurisdictions in which we operate, including estimating exposures related to examinations by taxing authorities. We also make judgments regarding the realization of deferred tax assets, and establish reserves where we believe it is more likely than not that future taxable income in certain jurisdictions will be insufficient to realize these deferred tax assets in accordance with the Income Taxes Topic of the FASB ASC. Our estimates regarding future taxable income and income tax provision or benefit may vary due to changes in market conditions, changes in tax laws, or other factors. If our assumptions, and consequently our estimates, change in the future, the valuation allowances we have established may be increased or decreased, impacting future income tax expense. At December 31, 2011 and 2010 respectively, the valuation allowance was $7.6 million and $5.6 million. As of December 31, 2011, we have state research tax credit carry-forwards of $2.7 million, which will expire between 2015 and 2026. These carry-forwards were caused by tax credits in excess of our annual tax liabilities to an individual state where we no longer generate sufficient state income. In addition, as of December 31, 2011, we have a deferred tax asset of $5.2 million relating to net operating loss carry-forwards which will expire between 2012 and 2030. These carry-forwards are the result of an acquisition in 2009 and another in 2011. The acquired net operating losses are in excess of the amount of estimated earnings. In accordance with the Income Taxes Topic of the FASB ASC, we believe it is more likely than not that we will not realize the full benefits of our deferred tax asset arising from these credits and net operating losses, and accordingly, have provided a valuation allowance against them. This valuation allowance is included in non-current deferred tax liabilities in the accompanying balance sheets. |

[0001193125-12-089158:mdna:29]
|  | • |  | Our products generally include warranties of one to ten years for product defects. We accrue for warranty returns at the time revenue is recognized based on our estimate of the cost to repair or replace the defective products. We engage in extensive product quality programs and processes, including actively monitoring and evaluating the quality of our component suppliers. Our products continue to become more complex in both size and functionality as many of our product offerings migrate from line card applications to systems products. The increasing complexity of our products will cause warranty incidences, when they arise, to be more costly. Our estimates regarding future warranty obligations may change due to product failure rates, material usage, and other rework costs incurred in correcting a product failure. In addition, from time to time, specific warranty accruals may be recorded if unforeseen problems arise. Should our actual experience relative to these factors be worse than our estimates, we will be required to record additional warranty expense. Alternatively, if we provide for more reserves than we require, we will reverse a portion of such provisions in future periods. The liability for warranty returns totaled $4.1 million and $3.3 million at December 31, 2011 and 2010, respectively. These liabilities are included in accrued expenses in the accompanying consolidated balance sheets. |

[0001193125-12-089158:mdna:30]
|  | • |  | We use the acquisition method to account for business combinations. Under the acquisition method of accounting, we recognize the assets acquired and liabilities assumed at their fair value on the acquisition date. Goodwill is measured as the excess of the consideration transferred over the net assets acquired. The acquisition method of accounting requires us to exercise judgment and make significant estimates and assumptions regarding the fair value of the assets acquired and liabilities assumed, including the fair values of inventory, deferred revenue, identifiable intangible assets and deferred tax asset valuation allowances. This method also requires us to refine these estimates over a one-year measurement period to reflect information obtained about facts and circumstances that existed as of the acquisition date that, if known, would have affected the measurement of the asset and liabilities recorded on that date, which could affect our net income. |

[0001193125-12-089158:mdna:31]
|  | • |  | We evaluate the carrying value of goodwill during the fourth quarter of each year and between annual evaluations if events occur or circumstances change that would more likely than not reduce the fair value of the reporting unit below its carrying amount. When evaluating whether goodwill is impaired, we first assess qualitative factors to determine whether it is necessary to perform the two-step quantitative goodwill impairment test. If we determine that the two-step quantitative test is necessary, then we compare the fair value of the reporting unit to which the goodwill is assigned to the reporting unit’s carrying amount, including goodwill. If the carrying amount of the reporting unit exceeds its fair value, then the amount of the impairment loss is measured. There were no impairment losses during 2011. |

[0001193125-12-089158:mdna:32]
Results of Operations

[0001193125-12-089158:mdna:33]
The following table presents selected financial information derived from our consolidated statements of income expressed as a percentage
of sales for the years indicated.

[0001193125-12-089158:mdna:34]
|  |  |  | September 30, |  |  |  | September 30, |  |  |  | September 30, |  |
| Year Ended December 31, |  | 2011 |  |  | 2010 |  |  | 2009 |  |
| Sales |  |  |  |  |  |  |  |  |  |  |  |  |
| Carrier Networks Division |  |  | 79.4 | % |  |  | 78.6 | % |  |  | 76.7 | % |
| Enterprise Networks Division |  |  | 20.6 |  |  |  | 21.4 |  |  |  | 23.3 |  |
| Total sales |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |
| Cost of sales |  |  | 42.2 |  |  |  | 40.7 |  |  |  | 40.7 |  |
| Gross profit |  |  | 57.8 |  |  |  | 59.3 |  |  |  | 59.3 |  |
| Selling, general and administrative expenses |  |  | 17.4 |  |  |  | 19.0 |  |  |  | 20.5 |  |
| Research and development expenses |  |  | 14.0 |  |  |  | 14.9 |  |  |  | 17.2 |  |
| Operating income |  |  | 26.4 |  |  |  | 25.4 |  |  |  | 21.6 |  |
| Interest and dividend income |  |  | 1.1 |  |  |  | 1.1 |  |  |  | 1.4 |  |
| Interest expense |  |  | (0.3 | ) |  |  | (0.4 | ) |  |  | (0.5 | ) |
| Net realized investment gain (loss) |  |  | 1.7 |  |  |  | 1.8 |  |  |  | (0.3 | ) |
| Other income (expense), net |  |  | (0.1 | ) |  |  | (0.1 | ) |  |  | — |  |
| Income before provision for income taxes |  |  | 28.7 |  |  |  | 27.8 |  |  |  | 22.2 |  |
| Provision for income taxes |  |  | (9.4 | ) |  |  | (9.0 | ) |  |  | (6.9 | ) |
| Net income |  |  | 19.3 | % |  |  | 18.8 | % |  |  | 15.3 | % |

[0001193125-12-089158:mdna:35]
31

[0001193125-12-089158:mdna:36]
Acquisition Expenses

[0001193125-12-089158:mdna:37]
On August 4, 2011, we closed on the acquisition of Bluesocket, Inc. and on December 12, 2011, we announced the planned acquisition of the Nokia Siemens Networks Broadband Access business.
Acquisition related expenses, amortizations and adjustments for the twelve months ended December 31, 2011 for both transactions are as follows:

[0001193125-12-089158:mdna:38]
|  |  |  | September 30, |  |
| (In Thousands) |  | 2011 |  |
| Bluesocket, Inc. acquisition |  |  |  |  |
| Acquisition related professional fees and travel expenses |  | $ | 730 |  |
| Amortization of acquired intangible assets |  |  | 495 |  |
| Amortization and adjustments of other acquisition related non-cash items |  |  | 521 |  |
| Subtotal |  | $ | 1,746 |  |
| Planned NSN BBA acquisition |  |  |  |  |
| Acquisition related professional fees, travel and other expenses |  |  | 2,027 |  |
| Total acquisition related expenses, amortizations and adjustments |  | $ | 3,773 |  |
| Tax effect |  |  | (1,434 | ) |
| Total acquisition related expenses, amortizations and adjustments, net of tax |  | $ | 2,339 |  |

[0001193125-12-089158:mdna:39]
The acquisition related expenses, amortizations and adjustments above were recorded in the following
Consolidated Statements of Income categories for the twelve months ended December 31, 2011:

[0001193125-12-089158:mdna:40]
|  |  |  | September 30, |  |
| (In Thousands) |  | 2011 |  |
| Revenue (adjustments to deferred revenue recognized in the period) |  | $ | 362 |  |
| Cost of goods sold |  |  | 165 |  |
| Subtotal |  | $ | 527 |  |
| Selling, general and administrative expenses |  |  | 2,557 |  |
| Research and development expenses |  |  | 689 |  |
| Subtotal |  | $ | 3,246 |  |
| Total acquisition related expenses, amortizations and adjustments |  | $ | 3,773 |  |
| Tax effect |  |  | (1,434 | ) |
| Total acquisition related expenses, amortizations and adjustments, net of tax |  | $ | 2,339 |  |

[0001193125-12-089158:mdna:41]
2011 Compared to 2010

[0001193125-12-089158:mdna:42]
Sales

[0001193125-12-089158:mdna:43]
ADTRAN’s sales increased 18.4% from $605.7 million in 2010 to
$717.2 million in 2011. This increase in sales is primarily attributable to a $113.7 million increase in sales of our Broadband Access products, a $40.4 million increase in sales of our Internetworking products, a $16.3 million increase in sales of
our Optical Access products, partially offset by a $58.8 million decrease in sales of our HDSL and other legacy products.

[0001193125-12-089158:mdna:44]
Carrier Networks sales increased 19.7% from $476.0 million in 2010 to $569.6 million in 2011. The increase is primarily attributable to
increases in Broadband Access, Optical Access and Internetworking NTE product sales, partially offset by a decrease in HDSL and other legacy product sales.

[0001193125-12-089158:mdna:45]
Enterprise Networks sales increased 13.9% from $129.6 million in 2010 to $147.7 million in
2011. The increase is primarily attributable to an increase in sales of Internetworking products, partially offset by decreases in sales of legacy products. Internetworking product sales attributable to Enterprise Networks were 87.4% of the
division’s sales in 2011 compared with 77.3% in 2010. Legacy products primarily comprise the remainder of Enterprise Networks sales. Enterprise Networks sales as a percentage of total sales decreased from 21.4% in 2010 to 20.6% in 2011.

[0001193125-12-089158:mdna:46]
International sales, which are included in the Carrier Networks and Enterprise Networks amounts discussed above, increased
165.3% from $31.8 million in 2010 to $84.4 million in 2011. International sales, as a percentage of total sales, increased from 5.3% in 2010 to 11.8% in 2011. The increase in international sales in 2011 was primarily due to an increase in sales to
Latin America, Asia-Pacific and Europe regions.

[0001193125-12-089158:mdna:47]
Carrier Systems product sales increased $131.0 million in 2011 compared to
2010 primarily due to a $113.7 million increase in Broadband Access product sales and a $16.3 million increase in Optical Access product sales. The increase in Broadband Access product sales was primarily attributable to continued growth in
deployments of our Total Access 5000 and Fiber-to-the-Node platforms.

[0001193125-12-089158:mdna:48]
Business Networking product sales increased $35.0
million in 2011 compared to 2010 primarily due to a $40.4 million increase in Internetworking product sales across both divisions, partially offset by a $5.8 million decrease in legacy product sales. The decrease in sales of legacy products is a
result of customers shifting to newer technologies. Many of these newer technologies are integral to our Internetworking product area.

[0001193125-12-089158:mdna:49]
Loop Access product sales decreased $54.4 million in 2011 compared to 2010 primarily due to a $50.3 million decrease in HDSL product sales.

[0001193125-12-089158:mdna:50]
Cost of Sales

[0001193125-12-089158:mdna:51]
As a percentage of sales, cost of sales increased from
40.7% in 2010 to 42.2% in 2011. The increase was primarily the result of higher services related revenue including cabinet shipments, and specific customer price movements related to market share expansion. These effects were partially offset
by cost absorption and manufacturing efficiencies achieved at the higher production volumes.

[0001193125-12-089158:mdna:52]
Carrier Networks cost of sales
increased from 40.5% of sales in 2010 to 42.4% of sales in 2011. The increase in Carrier Networks cost of sales as a percentage of sales was primarily attributable to higher services related revenue including cabinet shipments, and specific customer
price movements related to market share expansion.

[0001193125-12-089158:mdna:53]
Enterprise Networks cost of sales decreased from 41.7% of sales in 2010 to
41.4% of sales in 2011. The decrease in Enterprise Networks cost of sales as a percentage of sales was primarily attributable to cost absorption and manufacturing efficiencies achieved at higher production volumes.

[0001193125-12-089158:mdna:54]
An important part of our strategy is to reduce the product cost of each succeeding product generation and then to lower the
product’s price based on the cost savings achieved. This may cause variations in our gross profit percentage due to timing differences between the recognition of cost reductions and the lowering of product selling prices.

[0001193125-12-089158:mdna:55]
Selling, General and Administrative Expenses

[0001193125-12-089158:mdna:56]
Selling, general and administrative expenses increased 8.9% from $114.7 million in 2010 to $124.9 million in 2011. Selling, general and administrative expenses include personnel costs for administration,
finance, information systems, human resources, sales and marketing, and general management, as well as rent, utilities, legal and accounting expenses, bad debt expense, advertising, promotional material, trade show expenses, and related travel
costs. The increase in selling, general and administrative expenses is primarily related to increases in staffing and fringe benefit costs due to increased headcount, contract services, professional services, recruiting expenses and travel expenses.
These increases included expenses related to Bluesocket, Inc., which was acquired on August 4, 2011, and the announced planned acquisition of Nokia Siemens Networks Broadband Access business.

[0001193125-12-089158:mdna:57]
Selling, general and administrative expenses as a percentage of sales decreased from 18.9% for the year ended December 31, 2010 to
17.4% for the year ended December 31, 2011. Selling, general and administrative expenses as a percent of sales will generally fluctuate whenever there is a significant fluctuation in revenues for the periods being compared.

[0001193125-12-089158:mdna:58]
Research and Development Expenses

[0001193125-12-089158:mdna:59]
Research and development expenses increased 11.1% from $90.3 million in 2010 to $100.3 million in 2011. The increase in research and development expense is primarily related to increases in staffing and
fringe benefit costs due to increased headcount. These increases included research and development expenses related to Bluesocket, Inc., and amortization of intangible assets related to the acquisition of Bluesocket, Inc.

[0001193125-12-089158:mdna:60]
Research and development expenses as a percentage of sales decreased from 14.9% for the year
ended December 31, 2010 to 14.0% for the year ended December 31, 2011. Research and development expenses as a percentage of sales will fluctuate whenever there are incremental product development activities or a significant fluctuation in
revenues for the periods being compared.

[0001193125-12-089158:mdna:61]
We expect to continue to incur research and development expenses in connection with
our new and existing products and our expansion into international markets. We continually evaluate new product opportunities and engage in intensive research and product development efforts which provide for new product development, enhancement of
existing products and product cost reductions. We may incur significant research and development expenses prior to the receipt of revenues from a major new product group.

[0001193125-12-089158:mdna:62]
Interest and Dividend Income

[0001193125-12-089158:mdna:63]
Interest and dividend income increased 16.5%
from $6.6 million in 2010 to $7.6 million in 2011. This increase was primarily attributable to a 19.9% increase in our average investment balances, partially offset by a 22.6% reduction in the average rate of return on our investments as a result of
lower interest rates.

[0001193125-12-089158:mdna:64]
Interest Expense

[0001193125-12-089158:mdna:65]
Interest expense remained consistent at $2.4 million in 2011 and 2010, as we had no substantial change in our fixed rate borrowing. See “Liquidity and Capital Resources” below for additional
information.

[0001193125-12-089158:mdna:66]
Net Realized Investment Gain (Loss)

[0001193125-12-089158:mdna:67]
Net realized investment gain (loss) increased from an $11.0 million gain in 2010 to a $12.5 million gain in 2011. This change is related to a $0.7 million increase related to sales of marketable equity
securities and an increase of $0.8 million related to distributions from two private equity funds. See “Investing Activities” in “Liquidity and Capital Resources” below for additional information.

[0001193125-12-089158:mdna:68]
Other Income (Expense), net

[0001193125-12-089158:mdna:69]
Other income (expense), net, comprised primarily of miscellaneous income, gains and losses on foreign currency transactions, investment account management fees, and gains or losses on the disposal of
property, plant and equipment occurring in the normal course of business, decreased from $0.8 million of expense in 2010 to $0.7 million of expense in 2011.

[0001193125-12-089158:mdna:70]
Income Taxes

[0001193125-12-089158:mdna:71]
Our effective tax rate increased from 32.2% in 2010 to 32.8%
in 2011. This increase is primarily due to the reduced impact of available statutory tax benefits applied to the increased level of pretax income in 2011. The statutory benefits include the research tax credit, deduction for domestic
manufacturing under Internal Revenue Code Section 199 and stock option related tax benefits.

[0001193125-12-089158:mdna:72]
Net Income

[0001193125-12-089158:mdna:73]
As a result of the above factors, net income increased from $114.0 million in 2010 to $138.6 million in 2011. As a percentage of sales,
net income increased from 18.8% in 2010 to 19.3% in 2011.

[0001193125-12-089158:mdna:74]
2010 Compared to 2009

[0001193125-12-089158:mdna:75]
Sales

[0001193125-12-089158:mdna:76]
ADTRAN’s
sales increased 25.1% from $484.2 million in 2009 to $605.7 million in 2010. This increase in sales is primarily attributable to a $64.6 million increase in sales of our Broadband Access products, a $31.1 million increase in sales of our
Internetworking products, a $27.0 million increase in sales of our HDSL products, and a $5.6 million increase in our Optical Access products, partially offset by a $4.2 million decrease in traditional IAD products and a $2.6 million decrease in
enterprise T1 products.

[0001193125-12-089158:mdna:77]
Carrier Networks sales increased 28.2% from $371.3 million in 2009 to $476.0 million in 2010. The
increase is primarily attributable to increases in Broadband Access, Optical Access, TDM, HDSL and Internetworking NTE product sales, partially offset by a decrease in other traditional products.

[0001193125-12-089158:mdna:78]
Enterprise Networks sales increased 14.9% from $112.8 million in 2009 to $129.6 million in
2010. The increase is primarily attributable to an increase in Enterprise Networks related Internetworking product sales, partially offset by decreases in IAD and enterprise T1 product sales. Internetworking product sales were 77.3% of Enterprise
Network sales in 2010 compared with 67.4% in 2009. Traditional products primarily comprise the remainder of Enterprise Networks sales. Enterprise Networks sales as a percentage of total sales decreased from 23.3% in 2009 to 21.4% in 2010.

[0001193125-12-089158:mdna:79]
International sales, which are included in the Carrier Networks and Enterprise Networks amounts discussed above, increased
14.6% from $27.8 million in 2009 to $31.8 million in 2010. International sales, as a percentage of total sales, decreased from 5.7% in 2009 to 5.3% in 2010. The increase in international sales in 2010 was primarily attributable to an increase in
sales in Australia, Mexico and Europe, partially offset by a decrease in sales in Canada.

[0001193125-12-089158:mdna:80]
Carrier Systems product sales
increased $73.6 million in 2010 compared to 2009 primarily due to a $64.6 million increase in Broadband Access product sales and a $5.6 million increase in Optical Access product sales. The increase in Broadband Access product sales was primarily
attributable to continued growth in deployments of our TA 5000 platform and Fiber to the Node products resulting from market share gains across all major market segments.

[0001193125-12-089158:mdna:81]
Business Networking product sales increased $26.8 million in 2010 compared to 2009 primarily due to an increase in Internetworking product sales. Growth in Internetworking product sales occurred across
all areas, including routers, Ethernet switches, IP gateways, access termination products and our IP PBX segment as a result of market share gains in SME and distributed enterprise applications. This increase was partially offset by a decrease in
traditional IAD product sales as customers shifted emphasis to newer technologies. Many of these newer technologies are integral to our Internetworking product area.

[0001193125-12-089158:mdna:82]
Loop Access product sales increased $21.1 million in 2010 compared to 2009 primarily due to a $27.0 million increase in HDSL product sales, partially offset by decreases in other traditional product
sales. The increase in HDSL product sales is primarily attributable to carriers increasing investment to cost effectively and quickly add capacity to mobility networks.

[0001193125-12-089158:mdna:83]
Cost of Sales

[0001193125-12-089158:mdna:84]
Cost of sales remained consistent in 2010 and 2009 at 40.7%
of sales. Gross margins benefited from improved product mix, cost absorption and manufacturing efficiencies achieved at the higher production volumes, offset by higher warranty expense and an increase in lower gross margin installation services
related revenue. However, installation services related revenue was accretive to operating income margins in 2010.

[0001193125-12-089158:mdna:85]
Carrier
Networks cost of sales decreased from 40.8% of sales in 2009 to 40.5% of sales in 2010. The decrease was primarily related to improved cost absorption and manufacturing efficiencies achieved at the higher production volumes, which was partially
offset by an increase in lower margin installation services revenue.

[0001193125-12-089158:mdna:86]
Enterprise Networks cost of sales increased from 40.4%
of sales in 2009 to 41.7% of sales in 2010. The increase was primarily related to a higher cost product mix and the impact of cost allocations between divisions.

[0001193125-12-089158:mdna:87]
An important part of our strategy is to reduce the product cost of each succeeding product generation and then to lower the product’s price based on the cost savings achieved. This may cause
variations in our gross profit percentage due to timing differences between the recognition of cost reductions and the lowering of product selling prices.

[0001193125-12-089158:mdna:88]
Selling, General and Administrative Expenses

[0001193125-12-089158:mdna:89]
Selling, general and
administrative expenses increased 15.3% from $99.4 million in 2009 to $114.7 million in 2010. Selling, general and administrative expenses include personnel costs for administration, finance, information systems, human resources, sales and
marketing, and general management, as well as rent, utilities, legal and accounting expenses, bad debt expense, advertising, promotional material, trade show expenses, and related travel costs. The increase in selling, general and administrative
expenses was primarily related to an increase in staffing costs and fringe benefits due to increased headcount, and increases in incentive compensation, contract services and travel expenses.

[0001193125-12-089158:mdna:90]
Selling, general and administrative expenses as a percentage of sales decreased from 20.5% for the year ended December 31, 2009 to
18.9% for the year ended December 31, 2010. Selling, general and administrative expenses as a percent of sales will generally fluctuate whenever there is a significant fluctuation in revenues for the periods being compared.

[0001193125-12-089158:mdna:91]
Research and Development Expenses

[0001193125-12-089158:mdna:92]
Research and development expenses increased 8.4% from $83.3 million in 2009 to $90.3 million in 2010. The increase in research and
development expenses was a result of increased staffing costs and fringe benefits, engineering and testing expense primarily related to customer specific product development activities as well as costs related to product approvals, primarily for one
or more of the top three U.S. carriers.

[0001193125-12-089158:mdna:93]
Research and development expenses as a percentage of sales decreased from 17.2% for
the year ended December 31, 2009 to 14.9% for the year ended December 31, 2010. Research and development expenses as a percentage of sales will fluctuate whenever there are incremental product development activities or a significant
fluctuation in revenues for the periods being compared.

[0001193125-12-089158:mdna:94]
We expect to continue to incur research and development expenses in
connection with our new and existing products and our expansion into international markets. We continually evaluate new product opportunities and engage in intensive research and product development efforts which provides for new product
development, enhancement of existing products and product cost reductions. We may incur significant research and development expenses prior to the receipt of revenues from a major new product group.

[0001193125-12-089158:mdna:95]
Interest and Dividend Income

[0001193125-12-089158:mdna:96]
Interest and dividend income decreased 5.4% from $6.9 million in 2009 to $6.6 million in 2010. This decrease was primarily attributable to a 22.2% reduction in the average rate of return on our
investments as a result of lower interest rates, partially offset by a 23.7% increase in our average investment balances.

[0001193125-12-089158:mdna:97]
Interest Expense

[0001193125-12-089158:mdna:98]
Interest expense remained consistent at $2.4 million in 2010 and 2009, as we had no substantial change in our fixed rate
borrowing. See “Liquidity and Capital Resources” below for additional information.

[0001193125-12-089158:mdna:99]
Net Realized Investment Gain (Loss)

[0001193125-12-089158:mdna:100]
Net realized investment gain (loss) changed from a $1.3 million loss in 2009 to an $11.0 million gain in 2010. This
change is primarily a result of the other-than-temporary impairments of $2.0 million related to our marketable equity securities, $0.4 million related to our investment in a fixed income bond fund, and $0.5 million related to our deferred
compensation plan assets in 2009 and the realized gains of $8.1 million on the sale of one security and $1.6 million from the sale of previously impaired marketable equity securities in 2010. See “Investing Activities” in “Liquidity
and Capital Resources” below for additional information.

[0001193125-12-089158:mdna:101]
Other Income (Expense), net

[0001193125-12-089158:mdna:102]
Other income (expense), net, comprised primarily of miscellaneous income, gains and losses on foreign currency transactions, investment
account management fees, and gains or losses on the disposal of property, plant and equipment occurring in the normal course of business, changed from $0.1 million of income in 2009 to $0.8 million of expense in 2010.

[0001193125-12-089158:mdna:103]
Income Taxes

[0001193125-12-089158:mdna:104]
Our
effective tax rate increased from 31.0% in 2009 to 32.2% in 2010. This increase is primarily due to the reduced impact of available statutory tax benefits applied to the increased level of pretax income in 2010. The statutory benefits include
the research and development tax credit, deduction for domestic manufacturing under Internal Revenue Code Section 199 and stock option related tax benefits.

[0001193125-12-089158:mdna:105]
Net Income

[0001193125-12-089158:mdna:106]
As a result of the above factors, net income increased from
$74.2 million in 2009 to $114.0 million in 2010. As a percentage of sales, net income increased from 15.3% in 2009 to 18.8% in 2010.

[0001193125-12-089158:mdna:107]
Liquidity and Capital Resources

[0001193125-12-089158:mdna:108]
Liquidity

[0001193125-12-089158:mdna:109]
We intend to finance our operations with cash flow from
operations. We have used, and expect to continue to use, the cash generated from operations for working capital, purchases of treasury stock, dividend payments, and other general corporate purposes, including (i) product development activities
to enhance our existing products and develop new products and (ii) expansion of sales and marketing activities. We believe our cash and cash equivalents, investments and cash generated from operations to be adequate to meet our operating and
capital needs for the foreseeable future.

[0001193125-12-089158:mdna:110]
At December 31, 2011, cash on hand was $43.0 million and short-term
investments were $159.3 million, which placed our short-term liquidity at $202.3 million. At December 31, 2010, our cash on hand of $31.7 million and short-term investments of $157.5 million placed our short-term liquidity at $189.2 million.
The increase in liquidity from 2010 to 2011 relates to additional funds provided by our operating activities and proceeds from stock option exercises by our employees, reduced by our cash needs for equipment acquisitions, business acquisition, stock
repurchases and dividends.

[0001193125-12-089158:mdna:111]
Operating Activities

[0001193125-12-089158:mdna:112]
Our working capital, which consists of current assets less current liabilities, increased 8.0% from $305.0 million as of December 31, 2010 to $329.3 million as of December 31, 2011, primarily
due to an increase in cash of $11.3 million, an increase in inventory of $13.5 million, an increase in accounts receivable of $5.2 million, and an increase in other receivables of $5.8 million, partially offset by an increase in accounts payable of
$6.6 million. Generally, the change in net accounts receivable is due to the timing of sales and collections during the quarter. Inventory increased during 2011 to support increasing customer demand, increases in inventories related to an increase
in installation services activities, and to mitigate component supply constraints broadly affecting the industry. Generally, the change in other receivables is due to the timing of shipments and collections for materials supplied to our contract
manufacturers during the quarter. Generally, the change in accounts payable is due to variations in the timing of the receipt of supplies, inventory and services and our subsequent payments for these purchases. The quick ratio, defined as cash, cash
equivalents, short-term investments, and net accounts receivable, divided by current liabilities, decreased from 5.21 as of December 31, 2010 to 4.50 as of December 31, 2011. The current ratio, defined as current assets divided by current
liabilities, decreased from 7.10 as of December 31, 2010 to 6.32 as of December 31, 2011. The quick ratio and the current ratio decreases were primarily due to the working capital changes described above.

[0001193125-12-089158:mdna:113]
Net accounts receivable increased 7.4% from $70.9 million at December 31, 2010 to $76.1 million at December 31, 2011. Our
allowance for doubtful accounts decreased from $0.2 million at December 31, 2010 to $8 thousand at December 31, 2011. Quarterly accounts receivable days sales outstanding (DSO) increased from 39 days as of December 31, 2010 to 40 days
as of December 31, 2011. Generally, the change in net accounts receivable and DSO is due to the timing of sales and collections during the quarter. Other receivables increased from $4.0 million at December 31, 2010 to $9.7 million at
December 31, 2011. Other receivables may fluctuate due to the timing of shipments and collections for materials supplied to our contract manufacturers during the quarter.

[0001193125-12-089158:mdna:114]
Quarterly inventory turnover decreased from 3.8 turns as of December 31, 2010 to 3.5 turns as of December 31, 2011. Inventory increased 18.2% from December 31, 2010 to December 31,
2011. Our investment in inventory increased during 2011 to support increasing customer demand, increases in inventories related to an increase in installation services activities, and to mitigate component supply constraints broadly affecting the
industry. We expect inventory levels to fluctuate as we attempt to maintain sufficient inventory in response to seasonal cycles of our business; ensuring competitive lead times while managing the risk of inventory obsolescence that may occur due to
rapidly changing technology and customer demand.

[0001193125-12-089158:mdna:115]
Accounts payable increased 29.0% from $22.8 million at December 31,
2010 to $29.4 million at December 31, 2011. Generally, the change in accounts payable is due to variations in the timing of the receipt of supplies, inventory and services and our subsequent payments for these purchases.

[0001193125-12-089158:mdna:116]
Investing Activities

[0001193125-12-089158:mdna:117]
Capital expenditures totaled approximately $11.9 million, $9.9 million and $8.7 million for the years ended December 31, 2011, 2010
and 2009, respectively. These expenditures were primarily used to purchase computer hardware, software and manufacturing and test equipment.

[0001193125-12-089158:mdna:118]
Our combined short-term and long-term investments increased $72.7 million from $418.6 million at December 31, 2010 to $491.4 million at December 31, 2011. This increase reflects the impact of
additional funds available for investment provided by our operating activities and proceeds from stock option exercises by our employees, reduced by our cash needs for equipment acquisitions, business acquisition, stock repurchases and dividends, as
well as net realized and unrealized losses and amortization of net premiums on our combined investments.

[0001193125-12-089158:mdna:119]
We invest all available cash not required for immediate use in operations primarily in
securities that we believe bear minimal risk of loss. At December 31, 2011, these investments included municipal variable rate demand notes of $69.7 million, municipal fixed-rate bonds of $174.8 million and corporate bonds of $156.8 million. At
December 31, 2010, these investments included municipal variable rate demand notes of $116.7 million, municipal fixed-rate bonds of $71.5 million and corporate bonds of $127.1 million.

[0001193125-12-089158:mdna:120]
At December 31, 2011, we held $69.7 million of municipal variable rate demand notes, all of which were classified as
available-for-sale. At December 31, 2011, 18% of our municipal variable rate demand notes had a credit rating of AAA, 58% had a credit rating of AA, 24% had a credit rating of A, and all contained put options of seven days. Despite the
long-term nature of their stated contractual maturities, we routinely buy and sell these securities and we believe that we have the ability to quickly liquidate them. Our investments in these securities are recorded at fair value, and the interest
rates reset every seven days. We believe we have the ability to sell our variable rate demand notes to the remarketing agent, tender agent or issuer at par value plus accrued interest in the event we decide to liquidate our investment in a
particular variable rate demand note. At December 31, 2011, approximately 34% of our variable rate demand notes were supported by letters of credit from banks that we believe to be in good financial condition. The remaining 66% of our variable
rate demand notes were supported by standby purchase agreements. As a result of these factors, we had no cumulative gross unrealized holding gains (losses) or gross realized gains (losses) from these investments. All income generated from these
investments was recorded as interest income. We have not recorded any losses relating to municipal variable rate demand notes.

[0001193125-12-089158:mdna:121]
At December 31, 2011, we held $174.8 million of municipal fixed-rate bonds. These bonds are classified as available-for-sale and had
an average duration of 1.3 years at December 31, 2011. At December 31, 2011, approximately 19% of our municipal fixed-rate bond portfolio had a credit rating of AAA, 64% had a credit rating of AA, 15% had a credit rating of A, and 2% had a
credit rating of BBB. Because our bond portfolio has a high quality rating and contractual maturities of a short duration, we are able to obtain prices for these bonds derived from observable market inputs, or for similar securities traded in an
active market, on a daily basis.

[0001193125-12-089158:mdna:122]
At December 31, 2011, we held $156.8 million of corporate bonds. These bonds are
classified as available-for-sale and had an average duration of 0.8 years. At December 31, 2011, approximately 1% of our corporate bond portfolio had a credit rating of AAA, 11% had a credit rating of AA, 50% had a credit rating of A, and 38%
had a credit rating of BBB. Because our bond portfolio has a high quality rating and contractual maturities of a short duration, we are able to obtain prices for these bonds derived from observable market inputs, or for similar securities traded in
an active market, on a daily basis.

[0001193125-12-089158:mdna:123]
Our long-term investments increased 27.1% from $261.2 million at December 31, 2010
to $332.0 million at December 31, 2011. The primary reasons for the increase in our long-term investments were cash generated from operations and proceeds from stock option exercises by our employees. Long-term investments at December 31,
2011 and December 31, 2010 included an investment in a certificate of deposit of $48.3 million, which serves as collateral for our revenue bonds, as discussed below. We have various equity investments included in long-term investments at a cost
of $12.8 million and $11.5 million, and with a fair value of $31.3 million and $48.0 million, at December 31, 2011 and December 31, 2010, respectively, including a single equity security, of which we held 1.1 million shares and
1.5 million shares, carried at $17.3 million and $34.2 million of fair value at December 31, 2011 and December 31, 2010, respectively. The single security traded approximately 0.8 million shares per day in 2011 in an active
market on a European stock exchange. Of the gross unrealized gains included in the fair value of our marketable securities at December 31, 2011 and 2010, this single security comprised $16.9 million and $33.7 million, respectively, of the
unrealized gain. The remaining $2.2 million of gross unrealized gains and $0.6 million in gross unrealized losses at December 31, 2011 were spread amongst more than 400 marketable equity securities. Long-term investments at December 31,
2011 and 2010 also included $7.7 million and $4.2 million, respectively, related to our deferred compensation plan; $2.1 million of other investments carried at cost, consisting of interests in two private equity funds and an investment in a
privately held telecommunications equipment manufacturer; and $0.7 million of a fixed income bond fund. This bond fund had unrealized gains of $0.2 million at December 31, 2011 and 2010.

[0001193125-12-089158:mdna:124]
We review our investment portfolio for potential “other-than-temporary” declines in value on an individual investment basis. We
assess, on a quarterly basis, significant declines in value which may be considered other-than-temporary and, if necessary, recognize and record the appropriate charge to write-down the carrying value of such investments. In making this assessment,
we take into consideration qualitative and quantitative information, including but not limited to the following: the magnitude and duration of historical declines in market prices, credit rating activity, assessments of liquidity, public filings,
and statements made by the issuer. We generally begin our identification of potential other-than-temporary impairments by reviewing any security with a fair value that has declined from its original or adjusted cost basis by 25% or more for six or
more consecutive months. We then evaluate the individual security based on the previously identified factors to determine the amount of the write-down, if any. As a result of our review, we recorded an other-than-temporary impairment charge of $36
thousand during the fourth quarter of 2011. For the years ended December 31, 2011, 2010 and 2009 we recorded charges of $68 thousand, $43 thousand and $2.9 million, respectively, related to the other-than-temporary impairment of certain
publicly traded equity securities, a fixed income bond fund, and deferred compensation plan assets.

[0001193125-12-089158:mdna:125]
On August 4, 2011, we acquired all of the outstanding stock of Bluesocket, Inc., a
provider of wireless network solutions with virtual control, for $23.7 million in cash. The acquisition provides us with IEEE802.11N enterprise class wireless LAN expertise, technology, and products to address the growing transition within
small-medium enterprises and large enterprises to wireless networks and mobile devices. We have included the financial results of Bluesocket in our consolidated financial statements since the date of acquisition.

[0001193125-12-089158:mdna:126]
Financing Activities

[0001193125-12-089158:mdna:127]
In conjunction with an expansion of our Huntsville, Alabama, facility, we were approved for participation in an incentive program offered
by the State of Alabama Industrial Development Authority (the “Authority”). Pursuant to the program, on January 13, 1995, the Authority issued $20.0 million of its taxable revenue bonds and loaned the proceeds from the sale of the
bonds to ADTRAN. The bonds were originally purchased by AmSouth Bank of Alabama, Birmingham, Alabama (the “Bank”). Wachovia Bank, N.A., Nashville, Tennessee (formerly First Union National Bank of Tennessee) (the “Bondholder”),
which was acquired by Wells Fargo & Company on December 31, 2008, purchased the original bonds from the Bank and made further advances to the Authority, bringing the total amount outstanding to $50.0 million. An Amended and Restated
Taxable Revenue Bond (“Amended and Restated Bond”) was issued and the original financing agreement was amended. The Amended and Restated Bond bears interest, payable monthly. The interest rate is 5% per annum. The Amended and Restated
Bond matures on January 1, 2020. The estimated fair value of the bond at December 31, 2011 was approximately $46.9 million, based on a debt security with a comparable interest rate and maturity and a Standard & Poor’s credit
rating of A+. We are required to make payments to the Authority in amounts necessary to pay the principal of and interest on the Amended and Restated Bond. Included in long-term investments at December 31, 2011 is $48.3 million which is
invested in a restricted certificate of deposit. These funds serve as a collateral deposit against the principal of this bond, and we have the right to set-off the balance of the Bond with the collateral deposit in order to reduce the balance of the
indebtedness. In conjunction with this program, we are eligible to receive certain economic incentives from the state of Alabama that reduce the amount of payroll withholdings that we are required to remit to the state for those employment positions
that qualify under the program. For the years ended December 31, 2011, 2010 and 2009, we realized economic incentives related to payroll withholdings totaling $1.9 million, $1.5 million and $1.5 million, respectively.

[0001193125-12-089158:mdna:128]
Due to continued positive cash flow from operating activities, we made a business decision in 2006 to begin an early partial redemption
of the Bond. We made principal payments of $1.0 million and $0.3 million for the years ended December 31, 2011 and 2010, respectively. It is our intent to make annual principal payments in addition to the interest amounts that are due. In
connection with this decision, $0.5 million of the bond debt has been reclassified to a current liability in accounts payable in the Consolidated Balance Sheets at December 31, 2011 and 2010.

[0001193125-12-089158:mdna:129]
The following table shows dividends paid in each quarter of 2011, 2010 and 2009. During 2011, 2010 and 2009, we paid dividends totaling
$23.1 million, $22.5 million and $22.5 million, respectively. The Board of Directors presently anticipates that it will declare a regular quarterly dividend so long as the present tax treatment of dividends exists and adequate levels of liquidity
are maintained.

[0001193125-12-089158:mdna:130]
Dividends per Common Share

[0001193125-12-089158:mdna:131]
|  |  |  | September 30, |  |  |  | September 30, |  |  |  | September 30, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2009 |  |
| First Quarter |  | $ | 0.09 |  |  | $ | 0.09 |  |  | $ | 0.09 |  |
| Second Quarter |  | $ | 0.09 |  |  | $ | 0.09 |  |  | $ | 0.09 |  |
| Third Quarter |  | $ | 0.09 |  |  | $ | 0.09 |  |  | $ | 0.09 |  |
| Fourth Quarter |  | $ | 0.09 |  |  | $ | 0.09 |  |  | $ | 0.09 |  |

[0001193125-12-089158:mdna:132]
Stock Repurchase Program

[0001193125-12-089158:mdna:133]
Since 1997, our Board of Directors has approved multiple share repurchase programs that have authorized open market repurchase transactions of up to 35 million shares of our common stock. We
currently have the authority to purchase an additional 5.9 million shares of our common stock under the plans approved by the Board of Directors on April 14, 2008 and October 11, 2011. For the years 2011, 2010 and 2009, we repurchased
1.1 million shares, 0.7 million shares and 0.8 million shares, respectively, for a cost of $35.6 million, $18.3 million and $15.9 million, respectively, at an average price of $31.97, $25.12 and $21.05 per share, respectively.

[0001193125-12-089158:mdna:134]
To accommodate employee stock option exercises, we issued 1.8 million shares of treasury stock for $34.1 million during
the year ended December 31, 2011, 1.5 million shares of treasury stock for $24.9 million during the year ended December 31, 2010, and 0.9 million shares of treasury stock for $13.5 million during the year ended December 31,
2009.

[0001193125-12-089158:mdna:135]
Off-Balance Sheet Arrangements and Contractual Obligations

[0001193125-12-089158:mdna:136]
We have various contractual obligations and commercial commitments. The following table sets forth, in millions, the annual payments we
are required to make under contractual cash obligations and other commercial commitments at December 31, 2011.

[0001193125-12-089158:mdna:137]
Contractual
Obligations

[0001193125-12-089158:mdna:138]
|  |  |  | September 30, |  |  |  | September 30, |  |  |  | September 30, |  |  |  | September 30, |  |  |  | September 30, |  |  |  | September 30, |  |
| (In millions) |  | Total |  |  | 2012 |  |  | 2013 |  |  | 2014 |  |  | 2015 |  |  | After 2015 |  |
| Long-term debt |  | $ | 47.0 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 47.0 |  |
| Interest on long-term debt |  |  | 18.8 |  |  |  | 2.4 |  |  |  | 2.4 |  |  |  | 2.4 |  |  |  | 2.4 |  |  |  | 9.2 |  |
| Purchase obligations |  |  | 69.6 |  |  |  | 67.5 |  |  |  | 1.5 |  |  |  | 0.6 |  |  |  | — |  |  |  | — |  |
| Operating lease obligations |  |  | 5.0 |  |  |  | 2.0 |  |  |  | 1.2 |  |  |  | 1.0 |  |  |  | 0.7 |  |  |  | 0.1 |  |
| Investment commitments |  |  | 0.2 |  |  |  | 0.1 |  |  |  | 0.1 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Totals |  | $ | 140.6 |  |  | $ | 72.0 |  |  | $ | 5.2 |  |  | $ | 4.0 |  |  | $ | 3.1 |  |  | $ | 56.3 |  |

[0001193125-12-089158:mdna:139]
We are required to make payments necessary to pay the interest on the Taxable Revenue Bond, Series 1995,
as amended, currently outstanding in the aggregate principal amount of $47.0 million. The bond matures on January 1, 2020, and bears interest at the rate of 5% per annum. Included in long-term investments are $48.3 million of restricted
funds, which is a collateral deposit against the principal amount of this bond.

[0001193125-12-089158:mdna:140]
We have committed to invest up to an
aggregate of $7.9 million in two private equity funds, and we have contributed $8.4 million as of December 31, 2011, of which $7.7 million has been applied to these commitments. See Note 4 of Notes to Consolidated Financial Statements for
additional information.

[0001193125-12-089158:mdna:141]
We also have obligations related to uncertain income tax positions that have not been included in the
table above due to the uncertainty of when the related expense will be recognized. See Note 9 of Notes to Consolidated Financial Statements for additional information.

[0001193125-12-089158:mdna:142]
We do not have off-balance sheet financing arrangements and have not engaged in any related party transactions or arrangements with unconsolidated entities or other persons that are reasonably likely to
materially affect liquidity or the availability of or requirements for capital resources. See Notes 8 and 12 of Notes to Consolidated Financial Statements for additional information on our revenue bond and operating lease obligations, respectively.

[0001193125-12-089158:mdna:143]
Effect of Recent Accounting Pronouncements

[0001193125-12-089158:mdna:144]
In June 2011, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update No. 2011-05, Presentation of Comprehensive Income (ASU 2011-05). ASU 2011-05 requires companies to
present the components of net income and other comprehensive income either as one continuous statement or as two consecutive statements. ASU 2011-05 eliminates the option to present the components of other comprehensive income as part of the
statement of changes in stockholders’ equity. While ASU 2011-05 changes the presentation of comprehensive income, it does not change the components that are recognized in net income or comprehensive income under current accounting guidance.
This update is effective for fiscal years, and interim periods within those years, ending after December 15, 2011, with early adoption permitted. We plan to adopt this amendment during the first quarter of 2012. Since ASU 2011-05 affects
presentation only, it will have no effect on our consolidated results of operations or financial condition.

[0001193125-12-089158:mdna:145]
In December 2011,
the FASB issued Accounting Standards Update No. 2011-12, Deferral of the Effective Date for Amendments to the Presentation of Reclassifications of Items Out of Accumulated Other Comprehensive Income in Accounting Standards Update
No. 2011-05 (ASU 2011-12). ASU 2011-12 defers the effective date for certain presentation requirements that relate to reclassification adjustments and the effect of those reclassification adjustments on the financial statements. This update is
effective for fiscal years, and interim periods within those years, ending after December 15, 2011, with early adoption permitted. We plan to adopt this amendment during the first quarter of 2012. Since ASU 2011-12 affects presentation only, it
will have no effect on our consolidated results of operations or financial condition.

[0001193125-12-089158:mdna:146]
In May 2011, the FASB issued Accounting
Standards Update No. 2011-04, Amendments to Achieve Common Fair Value Measurement and Disclosure Requirements in U.S. GAAP and IFRSs (ASU 2011-04). ASU 2011-04 is intended to improve the comparability of fair value measurements presented and
disclosed in financial statements prepared in accordance with U.S. GAAP and IFRS. The amendments are of two types: (i) those that clarify the Board’s intent about the application of existing fair value measurement and disclosure
requirements and (ii) those that change a particular principle or requirement for measuring fair value or for disclosing information about fair value measurements. This update is effective for annual periods beginning after December 15,
2011. We do not expect the adoption of this amendment will have a material impact on our consolidated results of operations or financial condition.

[0001193125-12-089158:mdna:147]
During 2011, we adopted the following accounting standards, which had no material effect on
our consolidated results of operations or financial condition:

[0001193125-12-089158:mdna:148]
In October 2009, the FASB issued Accounting Standards Update
No. 2009-13, Multiple-Deliverable Revenue Arrangements (ASU 2009-13). ASU 2009-13 provides amendments to the criteria in Subtopic 605-25 of the ASC for separating consideration in multiple-deliverable arrangements. As a result of those
amendments, multiple-deliverable arrangements are separated in more circumstances than under previously existing U.S. GAAP. ASU 2009-13 established a selling price hierarchy for determining the selling price of a deliverable and replaced the term
fair value in the revenue allocation guidance with selling price to clarify that the allocation of revenue is based on entity-specific assumptions rather than assumptions of a marketplace participant. ASU 2009 -13 also eliminated the residual method
of allocation and required that arrangement consideration be allocated at the inception of the arrangement to all deliverables using the relative selling price method and required that a vendor determine its best estimate of selling price in a
manner that is consistent with that used to determine the price to sell the deliverable on a standalone basis.

[0001193125-12-089158:mdna:149]
We generally sell our products and services separately, but in some circumstances products and services may be sold in bundles that
contain multiple deliverables. A sale that includes multiple deliverables is evaluated to determine the units of accounting, and the revenue from the arrangement is allocated to each item requiring separate revenue recognition based on the relative
selling price and corresponding terms of the contract. We strive to use vendor-specific objective evidence of selling price. When this evidence is not available, we are generally not able to determine third-party evidence of selling price because of
the extent of customization among competing products or services from other companies. In these cases, estimated selling price is determined based on the particular circumstances of the arrangement and is used to allocate revenues to each unit of
accounting. Revenue is recognized incrementally as the necessary criteria for each item are met.

[0001193125-12-089158:mdna:150]
We adopted this amendment
during the first quarter of 2011. The adoption of this amendment had no effect on our consolidated results of operations and financial condition for the year ended December 31, 2011.

[0001193125-12-089158:mdna:151]
In October 2009, the FASB issued Accounting Standards Update No. 2009-14, Certain Revenue Arrangements that Include Software
Arrangements. ASU 2009-14 changed the accounting model for revenue arrangements that include both tangible products and software elements. Tangible products containing software components and non-software components that function together to deliver
the tangible product’s essential functionality are no longer within the scope of the software revenue guidance in Subtopic 985-605 of the ASC. In addition, ASU 2009-14 requires that hardware components of a tangible product containing software
components always be excluded from the software revenue guidance. In that regard, ASU 2009-14 provides additional guidance on how to determine which software, if any, relating to the tangible product also would be excluded from the scope of the
software revenue guidance. ASU 2009-14 also provides guidance on how a vendor should allocate arrangement consideration to deliverables in an arrangement that includes both tangible products and software. ASU 2009-14 also provides further guidance
on how to allocate arrangement consideration when an arrangement includes deliverables both included and excluded from the scope of the software revenue guidance. We adopted this amendment during the first quarter of 2011. The adoption of this
amendment had no effect on our consolidated results of operations and financial condition for the year ended December 31, 2011.

[0001193125-12-089158:mdna:152]
In September 2011, the FASB issued Accounting Standards Update No. 2011-08, Testing Goodwill for Impairment (ASU 2011-08). Existing accounting guidance requires that an entity perform a test for
goodwill impairment, on at least an annual basis, by first comparing the fair value of a reporting unit with its carrying amount, including goodwill. If the fair value of a reporting unit is less than its carrying amount, then the second step of the
test is to be performed to measure the amount of impairment loss, if any. ASU 2011-08 will allow an entity to first assess qualitative factors to determine whether it is necessary to perform the two-step quantitative goodwill impairment test. An
entity will no longer be required to calculate the fair value of a reporting unit unless the entity determines, based on a qualitative assessment, that it is more likely than not that its fair value is less than its carrying amount. This update is
effective for annual and interim goodwill impairment tests performed for fiscal years beginning after December 15, 2011, with early adoption permitted. We adopted this amendment during the fourth quarter of 2011. The adoption of this amendment
had no effect on our consolidated results of operations and financial condition for the year ended December 31, 2011.

[0001193125-12-089158:mdna:153]
Subsequent
Events

[0001193125-12-089158:mdna:154]
On January 17, 2012, the Board declared a quarterly cash dividend of $0.09 per common share to be paid to
stockholders of record at the close of business on February 2, 2012. The quarterly dividend payment was $5.7 million and was paid on February 16, 2012.
