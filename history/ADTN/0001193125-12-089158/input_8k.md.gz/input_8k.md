# ADTN 8-K — 0001157523-12-000174 filed 2012-01-18

## item codes, every 8-K on or before 2012-02-29

- 2012-01-18 0001157523-12-000174 — 2.02, 9.01
- 2011-12-12 0001193125-11-337271 — 7.01, 9.01
- 2011-10-13 0000950123-11-089785 — 5.03, 9.01
- 2011-10-12 0001157523-11-005682 — 2.02, 9.01
- 2011-07-13 0001157523-11-003986 — 2.02, 9.01
- 2011-05-09 0000950123-11-047191 — 5.02, 5.07, 9.01
- 2011-04-13 0001157523-11-002001 — 2.02, 9.01
- 2011-01-19 0001157523-11-000232 — 2.02, 9.01
- 2010-11-09 0000950123-10-103195 — 5.02, 9.01
- 2010-10-13 0001157523-10-005798 — 2.02, 9.01
- 2010-07-14 0001157523-10-004011 — 2.02, 9.01
- 2010-05-28 0000950123-10-053947 — 5.07
- 2010-04-14 0001157523-10-002022 — 2.02, 9.01
- 2010-01-20 0001157523-10-000200 — 2.02, 9.01
- 2009-10-28 0000950123-09-053984 — 8.01
- 2009-10-14 0001157523-09-006877 — 2.02, 9.01
- 2009-07-15 0001157523-09-004878 — 2.02, 9.01
- 2009-04-15 0001157523-09-002687 — 2.02, 9.01
- 2009-01-21 0001157523-09-000340 — 2.02, 9.01
- 2008-11-12 0001193125-08-233181 — 5.02, 9.01
- 2008-10-14 0001157523-08-007999 — 2.02, 9.01
- 2008-07-15 0001157523-08-005504 — 2.02, 9.01
- 2008-04-15 0001157523-08-002896 — 2.02, 9.01
- 2008-01-22 0001157523-08-000408 — 2.02, 9.01
- 2007-10-16 0001193125-07-219356 — 5.03, 9.01
- 2007-10-16 0001157523-07-009850 — 2.02, 9.01
- 2007-07-17 0001157523-07-006912 — 2.02, 9.01
- 2007-04-17 0001157523-07-003630 — 2.02, 9.01
- 2007-04-03 0001179022-07-000068 — 5.02
- 2007-03-28 0001179022-07-000064 — 5.02
- 2007-02-23 0001193125-07-038337 — 5.02
- 2007-02-23 0001193125-07-038335 — 5.02
- 2007-01-30 0001193125-07-015912 — 5.02, 9.01
- 2007-01-26 0001193125-07-014234 — 5.02
- 2007-01-23 0001157523-07-000494 — 2.02, 9.01 — amendment of 0001157523-07-000481
- 2007-01-23 0001157523-07-000481 — 2.02, 9.01
- 2006-10-17 0001157523-06-009945 — 2.02, 9.01
- 2006-07-18 0001157523-06-006929 — 2.02, 9.01
- 2006-06-08 0001193125-06-126486 — 1.01, 9.01
- 2006-05-10 0001193125-06-107316 — 1.01, 9.01
- 2006-04-18 0001157523-06-003699 — 2.02, 9.01
- 2006-02-03 0001179022-06-000014 — 1.01
- 2006-01-27 0001157523-06-000754 — 5.02, 9.01
- 2006-01-24 0001157523-06-000551 — 2.02, 9.01
- 2005-10-18 0001157523-05-008826 — 2.02, 9.01
- 2005-07-19 0001193125-05-143958 — 1.01, 5.02, 9.01
- 2005-07-19 0001193125-05-143957 — 2.02, 9.01
- 2005-05-20 0001193125-05-112019 — 1.01, 9.01
- 2005-04-19 0001157523-05-003418 — 2.02, 9.01
- 2005-01-25 0001193125-05-010721 — 2.02, 9.01
- 2004-10-12 0001193125-04-169652 — 2.02, 9.01
- 2004-07-13 0001193125-04-116820 — 12, 7
- 2004-04-14 0001193125-04-061547 — 12, 7
- 2004-01-21 0001193125-04-006366 — 12, 7
- 2003-10-14 0001193125-03-061018 — 12, 5, 7
- 2003-07-15 0001193125-03-019292 — 7, 9
- 2003-04-15 0000931763-03-000968 — 7, 9
- 1996-09-12 0000931763-96-000667 — 5, 7

## late-filing notifications on or before 2012-02-29

- none on or before 2012-02-29

## item 2.02 — earnings release, exhibit 99.1

[0001157523-12-000174:8k_2_02:1]
EX-99.1
2
a50136330ex99-1.htm
EXHIBIT 99.1

[0001157523-12-000174:8k_2_02:2]
Exhibit 99.1

[0001157523-12-000174:8k_2_02:3]
ADTRAN,
      Inc. Reports Results for the Fourth Quarter and Full Year 2011 and
      Declares Quarterly Cash Dividend

[0001157523-12-000174:8k_2_02:4]
HUNTSVILLE, Ala.--(BUSINESS WIRE)--January 17, 2012--ADTRAN, Inc.
      (NASDAQ:ADTN) reported results for the fourth quarter and full year of
      2011. For the quarter, sales increased to $175,286,000 compared to
      $165,329,000 for the fourth quarter of 2010. Net income was $31,163,000
      for the quarter compared to $35,960,000 for the fourth quarter of 2010.
      Earnings per share, assuming dilution, were $0.48 for the quarter
      compared to $0.56 for the fourth quarter of 2010. For the year, sales
      increased to a record $717,229,000 compared to $605,674,000 for the year
      2010. Net income increased to $138,577,000 for the year compared to
      $113,989,000 for the year 2010. Earnings per share, assuming dilution,
      increased to $2.12 for the year compared to $1.78 for the year 2010.

[0001157523-12-000174:8k_2_02:5]
ADTRAN Chief Executive Officer Tom Stanton stated, “Our Company had a
      solid fourth quarter which contributed to a record year in 2011. Our
      performance continued to be driven by our core product areas which
      include Broadband Access, Internetworking and Optical Access. Combined
      these areas grew 32% for the quarter compared to the same period in
      2010. Growth was led by Broadband Access which grew 49% and
      Internetworking which grew 37% for the quarter. We believe that our
      strategic areas of focus are well aligned with global market trends and
      will provide our company long term growth.”

[0001157523-12-000174:8k_2_02:6]
The Company reported that acquisition related expenses, amortizations
      and adjustments related to the acquisition of Bluesocket, Inc. and the
      planned acquisition of the NSN Broadband Access business reduced diluted
      earnings per share by $0.02 for the fourth quarter 2011 and $0.04 for
      the year 2011.

[0001157523-12-000174:8k_2_02:7]
The Company also reported that stock-based compensation expense reduced
      diluted earnings per share by $0.04 for the fourth quarter of 2011
      compared to a reduction of $0.03 for the fourth quarter of 2010 and
      reduced diluted earnings per share by $0.12 for the year 2011 compared
      to $0.11 for the year 2010.

[0001157523-12-000174:8k_2_02:8]
The Company also announced that its Board of Directors declared a cash
      dividend for the fourth quarter of 2011. The quarterly cash dividend is
      $0.09 per common share to be paid to holders of record at the close of
      business on February 2, 2012. The ex-dividend date is January 31, 2012
      and the payment date is February 16, 2012.

[0001157523-12-000174:8k_2_02:9]
The Company confirmed that its fourth quarter conference call will be
      held Wednesday, January 18, 2012 at 9:30 a.m. Central Time. This
      conference call will be web cast live through StreetEvents.com. To
      listen, simply visit the Investor Relations site at http://www.adtran.com
      or http://streetevents.com approximately 10 minutes prior to the
      start of the call and click on the conference call link provided.

[0001157523-12-000174:8k_2_02:10]
An online replay of the conference call will be available for seven days
      at http://streetevents.com. In addition, an online replay of the
      conference call, as well as the text of the Company's earnings release,
      will be available on the Investor Relations site at http://www.adtran.com
      for at least 12 months following the call.

[0001157523-12-000174:8k_2_02:11]
ADTRAN, Inc. is a leading global provider of networking and
      communications equipment, with a portfolio of more than 1,700 solutions.
      ADTRAN’s products enable voice, data, video, and Internet communications
      across a variety of network infrastructures. ADTRAN solutions are
      currently in use by service providers, private enterprises, government
      organizations, and millions of individual users worldwide.

[0001157523-12-000174:8k_2_02:12]
For more information, contact the company at 800 9ADTRAN (800 923-8726)
      or via email at info@adtran.com. On the Web, visit www.adtran.com.

[0001157523-12-000174:8k_2_02:13]
This press release contains forward-looking statements which reflect
      management’s best judgment based on factors currently known. However,
      these statements involve risks and uncertainties, including the
      successful development and market acceptance of new products, the degree
      of competition in the market for such products, the product and channel
      mix, component costs, manufacturing efficiencies, and other risks
      detailed in our annual report on Form 10-K for the year ended December
      31, 2010 and our quarterly report on Form 10Q for the quarter ended
      September 30, 2011. These risks and uncertainties could cause actual
      results to differ materially from those in the forward-looking
      statements included in this press release.

[0001157523-12-000174:8k_2_02:14]
| Condensed Consolidated Balance Sheet Unaudited (In thousands) |
|  |  | December 31,2011 |  | December 31,2010 |
| Assets |  |  |  |  |
| Cash and cash equivalents |  | $ | 42,979 |  | $ | 31,677 |
| Short-term investments |  |  | 159,347 |  |  | 157,479 |
| Accounts receivable, net |  |  | 76,130 |  |  | 70,893 |
| Other receivables |  |  | 9,743 |  |  | 3,962 |
| Income tax receivable, net |  |  | - |  |  | 2,741 |
| Inventory |  |  | 87,800 |  |  | 74,274 |
| Prepaid expenses |  |  | 3,119 |  |  | 3,270 |
| Deferred tax assets, net |  |  | 12,125 |  |  | 10,617 |
| Total Current Assets |  |  | 391,243 |  |  | 354,913 |
| Property, plant and equipment, net |  |  | 75,295 |  |  | 73,986 |
| Deferred tax assets, net |  |  | 7,494 |  |  | - |
| Goodwill |  |  | 4,770 |  |  | - |
| Other assets |  |  | 7,131 |  |  | 1,915 |
| Long-term investments |  |  | 332,008 |  |  | 261,160 |
| Total Assets |  | $ | 817,941 |  | $ | 691,974 |
| Liabilities and Stockholders' Equity |  |  |  |  |
| Accounts payable |  | $ | 29,404 |  | $ | 22,785 |
| Unearned revenue |  |  | 9,965 |  |  | 10,138 |
| Accrued expenses |  |  | 5,876 |  |  | 4,913 |
| Accrued wages and benefits |  |  | 13,518 |  |  | 12,125 |
| Income tax payable, net |  |  | 3,596 |  |  | - |
| Total Current Liabilities |  |  | 62,359 |  |  | 49,961 |
| Deferred tax liabilities, net |  |  | - |  |  | 10,350 |
| Other non-current liabilities |  |  | 16,951 |  |  | 11,841 |
| Bonds payable |  |  | 46,500 |  |  | 47,500 |
| Total Liabilities |  |  | 125,810 |  |  | 119,652 |
| Stockholders' Equity |  |  | 692,131 |  |  | 572,322 |
| Total Liabilities and Stockholders' Equity |  | $ | 817,941 |  | $ | 691,974 |

[0001157523-12-000174:8k_2_02:15]
| Consolidated Statements of Income Unaudited (In thousands, except per share data) |
|  |  |  | Three Months Ended |  | Twelve Months Ended |
|  |  |  | December 31, |  | December 31, |
|  |  |  | 2011 |  | 2010 |  | 2011 |  | 2010 |
| Sales |  | $ | 175,286 |  |  | $ | 165,329 |  |  | $ | 717,229 |  |  | $ | 605,674 |  |
| Cost of sales |  |  | 76,066 |  |  |  | 68,422 |  |  |  | 302,911 |  |  |  | 246,811 |  |
| Gross Profit |  |  | 99,220 |  |  |  | 96,907 |  |  |  | 414,318 |  |  |  | 358,863 |  |
| Selling, general and administrative expenses |  |  | 32,954 |  |  |  | 29,588 |  |  |  | 124,879 |  |  |  | 114,699 |  |
| Research and development expenses |  |  | 25,151 |  |  |  | 22,462 |  |  |  | 100,301 |  |  |  | 90,300 |  |
| Operating Income |  |  | 41,115 |  |  |  | 44,857 |  |  |  | 189,138 |  |  |  | 153,864 |  |
| Interest and dividend income |  |  | 1,813 |  |  |  | 1,754 |  |  |  | 7,642 |  |  |  | 6,557 |  |
| Interest expense |  |  | (603 | ) |  |  | (608 | ) |  |  | (2,398 | ) |  |  | (2,436 | ) |
| Net realized investment gain |  |  | 3,333 |  |  |  | 2,953 |  |  |  | 12,454 |  |  |  | 11,008 |  |
| Other expense, net |  |  | (297 | ) |  |  | (163 | ) |  |  | (694 | ) |  |  | (804 | ) |
| Income before provision for income taxes |  |  | 45,361 |  |  |  | 48,793 |  |  |  | 206,142 |  |  |  | 168,189 |  |
| Provision for income taxes |  |  | (14,198 | ) |  |  | (12,833 | ) |  |  | (67,565 | ) |  |  | (54,200 | ) |
| Net Income |  | $ | 31,163 |  |  | $ | 35,960 |  |  | $ | 138,577 |  |  | $ | 113,989 |  |
| Weighted average shares outstanding - basic |  |  | 63,685 |  |  |  | 63,007 |  |  |  | 64,145 |  |  |  | 62,490 |  |
| Weighted average shares outstanding - diluted (1) |  |  | 64,586 |  |  |  | 64,660 |  |  |  | 65,416 |  |  |  | 63,879 |  |
| Earnings per common share - basic |  | $ | 0.49 |  |  | $ | 0.57 |  |  | $ | 2.16 |  |  | $ | 1.82 |  |
| Earnings per common share - diluted (1) |  | $ | 0.48 |  |  | $ | 0.56 |  |  | $ | 2.12 |  |  | $ | 1.78 |  |
| (1) Assumes exercise of dilutive stock options calculated under the treasury stock method. |

[0001157523-12-000174:8k_2_02:16]
| Supplemental Information Acquisition Related Expenses, Amortizations and Adjustments Unaudited (In thousands) |
| On August 4, 2011, we closed on the acquisition of Bluesocket, Inc. and on December 12, 2011, we announced the planned acquisition of the Nokia Siemens Networks Broadband Access business (NSN BBA). Acquisition related expenses, amortizations and adjustments for the three and twelve months ended December 31, 2011 for both transactions are as follows: |
|  |  | Three Months EndedDecember 31,2011 |  | TwelveMonths EndedDecember 31,2011 |
| Bluesocket, Inc. acquisition |  |  |  |  |
| Acquisition related professional fees and travel expenses |  | $ | 100 |  |  | $ | 730 |  |
| Amortization of acquired intangible assets |  |  | 297 |  |  |  | 495 |  |
| Amortization and adjustments of other acquisition related non-cash items |  |  | 304 |  |  |  | 521 |  |
| Subtotal |  | $ | 701 |  |  | $ | 1,746 |  |
| Planned NSN BBA acquisition |  |  |  |  |
| Acquisition related professional fees, travel and other expenses |  |  | 1,035 |  |  |  | 2,027 |  |
| Total acquisition related expenses, amortizations and adjustments |  | $ | 1,736 |  |  | $ | 3,773 |  |
| Tax effect |  |  | (658 | ) |  |  | (1,434 | ) |
| Total acquisition related expenses, amortizations and adjustments, net of tax |  | $ | 1,078 |  |  | $ | 2,339 |  |

[0001157523-12-000174:8k_2_02:17]
| The acquisition related expenses, amortizations and adjustments above were recorded in the following Consolidated Statements of Income categories for the three and twelve months ended December 31, 2011: |
| Revenue (adjustments to deferred revenue recognized in the period) |  | $ | 207 |  |  | $ | 362 |  |
| Cost of goods sold |  |  | 99 |  |  |  | 165 |  |
| Subtotal |  | $ | 306 |  |  | $ | 527 |  |
| Selling, general and administrative expenses |  |  | 1,133 |  |  |  | 2,557 |  |
| Research and development expenses |  |  | 297 |  |  |  | 689 |  |
| Subtotal |  | $ | 1,430 |  |  | $ | 3,246 |  |
| Total acquisition related expenses, amortizations and adjustments |  | $ | 1,736 |  |  | $ | 3,773 |  |
| Tax effect |  |  | (658 | ) |  |  | (1,434 | ) |
| Total acquisition related expenses, amortizations and adjustments, net of tax |  | $ | 1,078 |  |  | $ | 2,339 |  |

[0001157523-12-000174:8k_2_02:18]
| Supplemental Information Stock-based Compensation Expense Unaudited (In thousands) |
|  |  | Three Months Ended |  | Twelve Months Ended |
|  |  | December 31, |  | December 31, |
|  |  | 2011 |  | 2010 |  | 2011 |  | 2010 |
| Stock-based compensation expense included in cost of sales |  | $ | 132 |  |  | $ | 107 |  |  | $ | 412 |  |  | $ | 317 |  |
| Selling, general and administrative expense |  |  | 1,220 |  |  |  | 1,215 |  |  |  | 4,316 |  |  |  | 3,575 |  |
| Research and development expense |  |  | 1,362 |  |  |  | 1,168 |  |  |  | 4,441 |  |  |  | 3,825 |  |
| Stock-based compensation expense included in operating expenses |  |  | 2,582 |  |  |  | 2,383 |  |  |  | 8,757 |  |  |  | 7,400 |  |
| Total stock-based compensation expense |  |  | 2,714 |  |  |  | 2,490 |  |  |  | 9,169 |  |  |  | 7,717 |  |
| Tax benefit for expense associated with non-qualified options |  |  | (303 | ) |  |  | (235 | ) |  |  | (1,321 | ) |  |  | (650 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 2,411 |  |  | $ | 2,255 |  |  | $ | 7,848 |  |  | $ | 7,067 |  |

[0001157523-12-000174:8k_2_02:19]
| Consolidated Statements of Cash Flows Unaudited (In thousands) |
|  |  | Twelve Months Ended |
|  |  | December 31, |
|  |  | 2011 |  | 2010 |
| Cash flows from operating activities: |  |  |  |  |
| Net income |  | $ | 138,577 |  |  | $ | 113,989 |  |
| Adjustments to reconcile net income to net cash provided by operatingactivities: |  |  |  |  |
| Depreciation and amortization |  |  | 11,499 |  |  |  | 10,545 |  |
| Amortization of net premium on available-for-sale investments |  |  | 6,617 |  |  |  | 4,380 |  |
| Net realized gain on long-term investments |  |  | (12,454 | ) |  |  | (11,008 | ) |
| Net loss on disposal of property, plant and equipment |  |  | 6 |  |  |  | 2 |  |
| Stock-based compensation expense |  |  | 9,169 |  |  |  | 7,717 |  |
| Deferred income taxes |  |  | 148 |  |  |  | (1,324 | ) |
| Tax benefit from stock option exercises |  |  | 10,525 |  |  |  | 4,909 |  |
| Excess tax benefits from stock-based compensation arrangements |  |  | (9,373 | ) |  |  | (4,404 | ) |
| Change in operating assets and liabilities: |  |  |  |  |
| Accounts receivable, net |  |  | (4,939 | ) |  |  | (2,849 | ) |
| Other receivables |  |  | (5,781 | ) |  |  | 135 |  |
| Income tax receivable, net |  |  | 2,741 |  |  |  | (2,741 | ) |
| Inventory |  |  | (12,734 | ) |  |  | (28,600 | ) |
| Prepaid expenses and other assets |  |  | 522 |  |  |  | (574 | ) |
| Accounts payable |  |  | 6,178 |  |  |  | (2,997 | ) |
| Accrued expenses and other liabilities |  |  | 6,309 |  |  |  | 8,626 |  |
| Income tax payable, net |  |  | 3,596 |  |  |  | (3,017 | ) |
| Net cash provided by operating activities |  |  | 150,606 |  |  |  | 92,789 |  |
| Cash flows from investing activities: |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (11,912 | ) |  |  | (9,872 | ) |
| Proceeds from sales and maturities of available-for-sale investments |  |  | 466,243 |  |  |  | 275,442 |  |
| Purchases of available-for-sale investments |  |  | (554,629 | ) |  |  | (340,489 | ) |
| Acquisition of business, net of cash acquired |  |  | (22,661 | ) |  |  | - |  |
| Net cash used in investing activities |  |  | (122,959 | ) |  |  | (74,919 | ) |
| Cash flows from financing activities: |  |  |  |  |
| Proceeds from stock option exercises |  |  | 34,125 |  |  |  | 24,942 |  |
| Purchases of treasury stock |  |  | (35,565 | ) |  |  | (18,316 | ) |
| Dividend payments |  |  | (23,124 | ) |  |  | (22,502 | ) |
| Payments on long-term debt |  |  | (1,000 | ) |  |  | (250 | ) |
| Excess tax benefits from stock-based compensation arrangements |  |  | 9,373 |  |  |  | 4,404 |  |
| Net cash used in financing activities |  |  | (16,191 | ) |  |  | (11,722 | ) |
| Net increase in cash and cash equivalents |  |  | 11,456 |  |  |  | 6,148 |  |
| Effect of exchange rate changes |  |  | (154 | ) |  |  | 1,394 |  |
| Cash and cash equivalents, beginning of period |  |  | 31,677 |  |  |  | 24,135 |  |
| Cash and cash equivalents, end of period |  | $ | 42,979 |  |  | $ | 31,677 |  |

[0001157523-12-000174:8k_2_02:20]
CONTACT:
ADTRAN, Inc.
Jim Matthews, 256-963-8775
Senior Vice
      President/CFO
or
Investor Services/Assistance:
Gayle Ellis,
      256-963-8220
