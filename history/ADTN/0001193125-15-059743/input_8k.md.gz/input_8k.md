# ADTN 8-K — 0001193125-15-015465 filed 2015-01-21

## item codes, every 8-K on or before 2015-02-24

- 2015-02-23 0001193125-15-056741 — 5.02, 9.01
- 2015-01-21 0001193125-15-015465 — 2.02, 9.01
- 2014-10-15 0001193125-14-372076 — 2.02, 9.01
- 2014-10-03 0001193125-14-363152 — 2.02, 9.01
- 2014-07-16 0001193125-14-269660 — 2.02, 9.01
- 2014-05-20 0001193125-14-205916 — 8.01, 9.01
- 2014-05-20 0001193125-14-205906 — 5.02, 9.01
- 2014-05-15 0001193125-14-201144 — 5.07
- 2014-04-16 0001193125-14-144665 — 2.02, 9.01
- 2014-04-03 0001193125-14-129578 — 2.02, 9.01
- 2014-01-22 0001157523-14-000154 — 2.02, 9.01
- 2013-10-15 0001193125-13-399540 — 5.02
- 2013-10-09 0001157523-13-004657 — 2.02, 9.01
- 2013-07-10 0001157523-13-003290 — 2.02, 9.01
- 2013-05-10 0001193125-13-213728 — 5.07
- 2013-05-03 0001193125-13-198816 — 8.01, 9.01
- 2013-04-10 0001157523-13-001730 — 2.02, 9.01
- 2013-01-16 0001157523-13-000139 — 2.02, 9.01
- 2012-10-10 0001157523-12-005081 — 2.02, 9.01
- 2012-10-03 0001193125-12-413609 — 7.01
- 2012-09-28 0001193125-12-408878 — 2.02, 9.01
- 2012-07-11 0001157523-12-003592 — 2.02, 9.01
- 2012-05-10 0001193125-12-225669 — 5.07
- 2012-05-10 0001193125-12-225639 — 8.01, 9.01
- 2012-04-11 0001157523-12-001772 — 2.02, 9.01
- 2012-03-15 0001193125-12-116494 — 2.02, 9.01
- 2012-01-18 0001157523-12-000174 — 2.02, 9.01
- 2011-12-12 0001193125-11-337271 — 7.01, 9.01
- 2011-10-13 0000950123-11-089785 — 5.03, 9.01
- 2011-10-12 0001157523-11-005682 — 2.02, 9.01
- 2011-07-13 0001157523-11-003986 — 2.02, 9.01
- 2011-05-09 0000950123-11-047191 — 5.02, 5.07, 9.01
- 2011-04-13 0001157523-11-002001 — 2.02, 9.01
- 2011-01-19 0001157523-11-000232 — 2.02, 9.01
- 2010-11-09 0000950123-10-103195 — 5.02, 9.01
- 2010-10-13 0001157523-10-005798 — 2.02, 9.01
- 2010-07-14 0001157523-10-004011 — 2.02, 9.01
- 2010-05-28 0000950123-10-053947 — 5.07
- 2010-04-14 0001157523-10-002022 — 2.02, 9.01
- 2010-01-20 0001157523-10-000200 — 2.02, 9.01
- 2009-10-28 0000950123-09-053984 — 8.01
- 2009-10-14 0001157523-09-006877 — 2.02, 9.01
- 2009-07-15 0001157523-09-004878 — 2.02, 9.01
- 2009-04-15 0001157523-09-002687 — 2.02, 9.01
- 2009-01-21 0001157523-09-000340 — 2.02, 9.01
- 2008-11-12 0001193125-08-233181 — 5.02, 9.01
- 2008-10-14 0001157523-08-007999 — 2.02, 9.01
- 2008-07-15 0001157523-08-005504 — 2.02, 9.01
- 2008-04-15 0001157523-08-002896 — 2.02, 9.01
- 2008-01-22 0001157523-08-000408 — 2.02, 9.01
- 2007-10-16 0001193125-07-219356 — 5.03, 9.01
- 2007-10-16 0001157523-07-009850 — 2.02, 9.01
- 2007-07-17 0001157523-07-006912 — 2.02, 9.01
- 2007-04-17 0001157523-07-003630 — 2.02, 9.01
- 2007-04-03 0001179022-07-000068 — 5.02
- 2007-03-28 0001179022-07-000064 — 5.02
- 2007-02-23 0001193125-07-038337 — 5.02
- 2007-02-23 0001193125-07-038335 — 5.02
- 2007-01-30 0001193125-07-015912 — 5.02, 9.01
- 2007-01-26 0001193125-07-014234 — 5.02
- 2007-01-23 0001157523-07-000494 — 2.02, 9.01 — amendment of 0001157523-07-000481
- 2007-01-23 0001157523-07-000481 — 2.02, 9.01
- 2006-10-17 0001157523-06-009945 — 2.02, 9.01
- 2006-07-18 0001157523-06-006929 — 2.02, 9.01
- 2006-06-08 0001193125-06-126486 — 1.01, 9.01
- 2006-05-10 0001193125-06-107316 — 1.01, 9.01
- 2006-04-18 0001157523-06-003699 — 2.02, 9.01
- 2006-02-03 0001179022-06-000014 — 1.01
- 2006-01-27 0001157523-06-000754 — 5.02, 9.01
- 2006-01-24 0001157523-06-000551 — 2.02, 9.01
- 2005-10-18 0001157523-05-008826 — 2.02, 9.01
- 2005-07-19 0001193125-05-143958 — 1.01, 5.02, 9.01
- 2005-07-19 0001193125-05-143957 — 2.02, 9.01
- 2005-05-20 0001193125-05-112019 — 1.01, 9.01
- 2005-04-19 0001157523-05-003418 — 2.02, 9.01
- 2005-01-25 0001193125-05-010721 — 2.02, 9.01
- 2004-10-12 0001193125-04-169652 — 2.02, 9.01
- 2004-07-13 0001193125-04-116820 — 12, 7
- 2004-04-14 0001193125-04-061547 — 12, 7
- 2004-01-21 0001193125-04-006366 — 12, 7
- 2003-10-14 0001193125-03-061018 — 12, 5, 7
- 2003-07-15 0001193125-03-019292 — 7, 9
- 2003-04-15 0000931763-03-000968 — 7, 9
- 1996-09-12 0000931763-96-000667 — 5, 7

## late-filing notifications on or before 2015-02-24

- none on or before 2015-02-24

## item 2.02 — earnings release, exhibit 99.1

[0001193125-15-015465:8k_2_02:1]
EX-99.1
2
d854255dex991.htm
EX-99.1

[0001193125-15-015465:8k_2_02:2]
EX-99.1

[0001193125-15-015465:8k_2_02:3]
EXHIBIT 99.1

[0001193125-15-015465:8k_2_02:4]
ADTRAN, INC.

[0001193125-15-015465:8k_2_02:5]
REPORTS
RESULTS FOR THE FOURTH QUARTER 2014 AND DECLARES QUARTERLY CASH DIVIDEND

[0001193125-15-015465:8k_2_02:6]
HUNTSVILLE, Ala. – (BUSINESS WIRE) – January 20, 2015 –
ADTRAN, Inc. (NASDAQ:ADTN) reported results for the fourth quarter 2014. For the quarter, sales were $143,982,000 compared to $159,094,000 for the fourth quarter of 2013. Net income was $9,292,000 compared to $11,840,000 for the fourth
quarter of 2013. Earnings per share, assuming dilution, were $0.17 compared to $0.20 for the fourth quarter of 2013. Non-GAAP earnings per share were $0.19 compared to $0.25 for the fourth quarter of 2013. The reconciliation between GAAP earnings
per share, diluted, and non-GAAP earnings per share, diluted, is in the table provided.

[0001193125-15-015465:8k_2_02:7]
ADTRAN Chief Executive Officer Tom Stanton stated, “Our
Company had a solid performance this quarter with most segments meeting or slightly exceeding our expectations. We continue to see positive trends as we enter 2015 and believe our geographic presence, market share gains and new product introductions
position us well for the future.”

[0001193125-15-015465:8k_2_02:8]
The Company also announced that its Board of Directors declared a cash dividend for the fourth quarter of 2014.
The quarterly cash dividend is $0.09 per common share to be paid to holders of record at the close of business on February 5, 2015. The ex-dividend date is February 3, 2015 and the payment date is February 19, 2015.

[0001193125-15-015465:8k_2_02:9]
The Company confirmed that its fourth quarter conference call will be held Wednesday, January 21, 2015 at 9:30 a.m. Central Time. This conference call will be
web cast live through StreetEvents.com. To listen, simply visit the Investor Relations site at www.adtran.com or www.streetevents.com approximately 10 minutes prior to the start of the call and click on the conference call link
provided.

[0001193125-15-015465:8k_2_02:10]
An online replay of the conference call will be available for seven days at www.streetevents.com. In addition, an online replay of the
conference call, as well as the text of the Company’s earnings release, will be available on the Investor Relations site at www.adtran.com for at least 12 months following the call.

[0001193125-15-015465:8k_2_02:11]
ADTRAN, Inc. is a leading global provider of networking and communications equipment. ADTRAN’s products enable voice, data, video and Internet
communications across a variety of network infrastructures. ADTRAN solutions are currently in use by service providers, private enterprises, government organizations, and millions of individual users worldwide. For more information, please visit
www.adtran.com.

[0001193125-15-015465:8k_2_02:12]
For more information, contact the company at 800 9ADTRAN (800 923-8726) or via email at info@adtran.com. On the Web, visit
www.adtran.com.

[0001193125-15-015465:8k_2_02:13]
This press release contains forward-looking statements which reflect management’s best judgment based on factors currently
known. However, these statements involve risks and uncertainties, including the successful development and market acceptance of new products, the degree of competition in the market for such products, the product and channel mix, component costs,
manufacturing efficiencies, and other risks detailed in our annual report on Form 10-K for the year ended December 31, 2013 and on Form 10-Q for the quarter ended September 30, 2014. These risks and uncertainties could cause actual results to differ
materially from those in the forward-looking statements included in this press release.

[0001193125-15-015465:8k_2_02:14]
| CONTACT: Jim Matthews Senior Vice President/CFO 256-963-8775 |  | INVESTOR SERVICES/ASSISTANCE: Gayle Ellis 256-963-8220 |

[0001193125-15-015465:8k_2_02:15]
Condensed Consolidated Balance Sheet

[0001193125-15-015465:8k_2_02:16]
(Unaudited)

[0001193125-15-015465:8k_2_02:17]
(In
thousands)

[0001193125-15-015465:8k_2_02:18]
|  |  | December 31,2014 |  |  | December 31,2013 |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 73,439 |  |  | $ | 58,298 |  |
| Short-term investments |  |  | 46,919 |  |  |  | 105,760 |  |
| Accounts receivable, net |  |  | 86,158 |  |  |  | 85,814 |  |
| Other receivables |  |  | 35,639 |  |  |  | 18,249 |  |
| Inventory |  |  | 86,710 |  |  |  | 90,111 |  |
| Prepaid expenses |  |  | 5,129 |  |  |  | 4,325 |  |
| Deferred tax assets, net |  |  | 17,095 |  |  |  | 17,083 |  |
| Total Current Assets |  |  | 351,089 |  |  |  | 379,640 |  |
| Property, plant and equipment, net |  |  | 74,828 |  |  |  | 76,739 |  |
| Deferred tax assets, net |  |  | 17,694 |  |  |  | 9,622 |  |
| Goodwill |  |  | 3,492 |  |  |  | 3,492 |  |
| Other assets |  |  | 10,942 |  |  |  | 11,180 |  |
| Long-term investments |  |  | 280,649 |  |  |  | 309,225 |  |
| Total Assets |  | $ | 738,694 |  |  | $ | 789,898 |  |
| Liabilities and Stockholders’ Equity |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 56,414 |  |  | $ | 48,282 |  |
| Unearned revenue |  |  | 22,762 |  |  |  | 22,205 |  |
| Accrued expenses |  |  | 11,077 |  |  |  | 12,776 |  |
| Accrued wages and benefits |  |  | 13,855 |  |  |  | 14,040 |  |
| Income tax payable, net |  |  | 14,901 |  |  |  | 5,002 |  |
| Total Current Liabilities |  |  | 119,009 |  |  |  | 102,305 |  |
| Non-current unearned revenue |  |  | 10,948 |  |  |  | 14,643 |  |
| Other non-current liabilities |  |  | 30,924 |  |  |  | 22,144 |  |
| Bonds payable |  |  | 28,800 |  |  |  | 46,200 |  |
| Total Liabilities |  |  | 189,681 |  |  |  | 185,292 |  |
| Stockholders’ Equity |  |  | 549,013 |  |  |  | 604,606 |  |
| Total Liabilities and Stockholders’ Equity |  | $ | 738,694 |  |  | $ | 789,898 |  |

[0001193125-15-015465:8k_2_02:19]
Consolidated Statements of Income

[0001193125-15-015465:8k_2_02:20]
(Unaudited)

[0001193125-15-015465:8k_2_02:21]
(In
thousands, except per share data)

[0001193125-15-015465:8k_2_02:22]
|  |  | Three Months Ended |  |  | Twelve Months Ended |  |
|  |  | December 31, |  |  | December 31, |  |
|  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Sales |  | $ | 143,982 |  |  | $ | 159,094 |  |  | $ | 630,007 |  |  | $ | 641,744 |  |
| Cost of sales |  |  | 75,499 |  |  |  | 82,230 |  |  |  | 318,680 |  |  |  | 332,858 |  |
| Gross Profit |  |  | 68,483 |  |  |  | 76,864 |  |  |  | 311,327 |  |  |  | 308,886 |  |
| Selling, general and administrative expenses |  |  | 31,793 |  |  |  | 33,284 |  |  |  | 131,958 |  |  |  | 129,366 |  |
| Research and development expenses |  |  | 32,711 |  |  |  | 32,941 |  |  |  | 132,258 |  |  |  | 131,055 |  |
| Operating Income |  |  | 3,979 |  |  |  | 10,639 |  |  |  | 47,111 |  |  |  | 48,465 |  |
| Interest and dividend income |  |  | 1,679 |  |  |  | 1,991 |  |  |  | 5,019 |  |  |  | 7,012 |  |
| Interest expense |  |  | (152 | ) |  |  | (588 | ) |  |  | (677 | ) |  |  | (2,325 | ) |
| Net realized investment gain |  |  | 59 |  |  |  | 1,665 |  |  |  | 7,278 |  |  |  | 8,614 |  |
| Other income (expense), net (1) |  |  | 2,790 |  |  |  | 610 |  |  |  | 1,175 |  |  |  | (911 | ) |
| Income before provision for income taxes |  |  | 8,355 |  |  |  | 14,317 |  |  |  | 59,906 |  |  |  | 60,855 |  |
| Provision for income taxes |  |  | 937 |  |  |  | (2,477 | ) |  |  | (15,286 | ) |  |  | (15,061 | ) |
| Net Income |  | $ | 9,292 |  |  | $ | 11,840 |  |  | $ | 44,620 |  |  | $ | 45,794 |  |
| Weighted average shares outstanding - basic |  |  | 53,835 |  |  |  | 57,178 |  |  |  | 55,120 |  |  |  | 59,001 |  |
| Weighted average shares outstanding - diluted (2) |  |  | 54,085 |  |  |  | 57,777 |  |  |  | 55,482 |  |  |  | 59,424 |  |
| Earnings per common share - basic |  | $ | 0.17 |  |  | $ | 0.21 |  |  | $ | 0.81 |  |  | $ | 0.78 |  |
| Earnings per common share - diluted (2) |  | $ | 0.17 |  |  | $ | 0.20 |  |  | $ | 0.80 |  |  | $ | 0.77 |  |

[0001193125-15-015465:8k_2_02:23]
| (1) | Results for the three and twelve months ended December 31, 2014 include a $2.4 million gain related to the settlement of working capital items from an acquisition transaction that closed in 2012. |

[0001193125-15-015465:8k_2_02:24]
| (2) | Assumes exercise of dilutive stock options calculated under the treasury stock method. |

[0001193125-15-015465:8k_2_02:25]
Consolidated Statements of Comprehensive Income

[0001193125-15-015465:8k_2_02:26]
(Unaudited)

[0001193125-15-015465:8k_2_02:27]
(In
thousands)

[0001193125-15-015465:8k_2_02:28]
|  |  | Three Months Ended |  |  | Twelve Months Ended |  |
|  |  | December 31, |  |  | December 31, |  |
|  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Net Income |  | $ | 9,292 |  |  | $ | 11,840 |  |  | $ | 44,620 |  |  | $ | 45,794 |  |
| Other Comprehensive Income (Loss), net of tax: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Unrealized gains (losses) on available-for-sale securities |  |  | 1,077 |  |  |  | 1,409 |  |  |  | (1,773 | ) |  |  | 629 |  |
| Defined benefit plan adjustments |  |  | (4,866 | ) |  |  | 1,061 |  |  |  | (4,866 | ) |  |  | 1,061 |  |
| Foreign currency translation |  |  | (2,007 | ) |  |  | (707 | ) |  |  | (4,189 | ) |  |  | (2,205 | ) |
| Other Comprehensive Income (Loss), net of tax |  |  | (5,796 | ) |  |  | 1,763 |  |  |  | (10,828 | ) |  |  | (515 | ) |
| Comprehensive Income, net of tax |  | $ | 3,496 |  |  | $ | 13,603 |  |  | $ | 33,792 |  |  | $ | 45,279 |  |

[0001193125-15-015465:8k_2_02:29]
Consolidated Statements of Cash Flows

[0001193125-15-015465:8k_2_02:30]
(Unaudited)

[0001193125-15-015465:8k_2_02:31]
(In
thousands)

[0001193125-15-015465:8k_2_02:32]
|  |  | Twelve Months Ended |  |
|  |  | December 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 44,620 |  |  | $ | 45,794 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 14,845 |  |  |  | 14,628 |  |
| Amortization of net premium on available-for-sale investments |  |  | 4,360 |  |  |  | 5,956 |  |
| Net realized gain on long-term investments |  |  | (7,278 | ) |  |  | (8,614 | ) |
| Net loss on disposal of property, plant and equipment |  |  | 142 |  |  |  | 3 |  |
| Stock-based compensation expense |  |  | 8,563 |  |  |  | 9,073 |  |
| Deferred income taxes |  |  | (5,526 | ) |  |  | (4,058 | ) |
| Tax benefit from stock option exercises |  |  | 81 |  |  |  | 169 |  |
| Excess tax benefits from stock-based compensation arrangements |  |  | (63 | ) |  |  | (158 | ) |
| Change in operating assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  |  | (2,769 | ) |  |  | (5,541 | ) |
| Other receivables |  |  | (20,439 | ) |  |  | (1,549 | ) |
| Inventory |  |  | 1,953 |  |  |  | 10,265 |  |
| Prepaid expenses and other assets |  |  | (3,627 | ) |  |  | (11 | ) |
| Accounts payable |  |  | 9,973 |  |  |  | 5,206 |  |
| Accrued expenses and other liabilities |  |  | (166 | ) |  |  | (15,146 | ) |
| Income tax payable, net |  |  | 11,168 |  |  |  | 3,747 |  |
| Net cash provided by operating activities |  |  | 55,837 |  |  |  | 59,764 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (11,256 | ) |  |  | (8,173 | ) |
| Proceeds from disposals of property, plant and equipment |  |  | 1 |  |  |  | — |  |
| Proceeds from sales and maturities of available-for-sale investments |  |  | 230,019 |  |  |  | 343,567 |  |
| Purchases of available-for-sale investments |  |  | (142,695 | ) |  |  | (261,625 | ) |
| Net cash provided by investing activities |  |  | 76,069 |  |  |  | 73,769 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Proceeds from stock option exercises |  |  | 2,839 |  |  |  | 3,629 |  |
| Purchases of treasury stock |  |  | (80,576 | ) |  |  | (124,267 | ) |
| Dividend payments |  |  | (19,947 | ) |  |  | (21,412 | ) |
| Payments on long-term debt |  |  | (16,500 | ) |  |  | — |  |
| Excess tax benefits from stock-based compensation arrangements |  |  | 63 |  |  |  | 158 |  |
| Net cash used in financing activities |  |  | (114,121 | ) |  |  | (141,892 | ) |
| Net increase (decrease) in cash and cash equivalents |  |  | 17,785 |  |  |  | (8,359 | ) |
| Effect of exchange rate changes |  |  | (2,644 | ) |  |  | (1,800 | ) |
| Cash and cash equivalents, beginning of period |  |  | 58,298 |  |  |  | 68,457 |  |
| Cash and cash equivalents, end of period |  | $ | 73,439 |  |  | $ | 58,298 |  |
| Supplemental disclosure of non-cash investing activities |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment included in accounts payable |  | $ | 467 |  |  | $ | 444 |  |

[0001193125-15-015465:8k_2_02:33]
Supplemental Information

[0001193125-15-015465:8k_2_02:34]
Acquisition Related Expenses, Amortizations and Adjustments

[0001193125-15-015465:8k_2_02:35]
(Unaudited)

[0001193125-15-015465:8k_2_02:36]
(In
thousands)

[0001193125-15-015465:8k_2_02:37]
On August 4, 2011, we closed on the acquisition of Bluesocket, Inc. and on May 4, 2012, we closed on the acquisition of the
Nokia Siemens Networks Broadband Access business (NSN BBA). Acquisition related expenses, amortizations and adjustments for the three and twelve months ended December 31, 2014 and 2013 for both transactions are as follows:

[0001193125-15-015465:8k_2_02:38]
|  |  | Three Months Ended |  |  | Twelve Months Ended |  |
|  |  | December 31, |  |  | December 31, |  |
|  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Bluesocket, Inc. acquisition |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets and other purchase accounting adjustments |  | $ | 226 |  |  | $ | 279 |  |  | $ | 925 |  |  | $ | 1,142 |  |
| NSN BBA acquisition |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets |  |  | 269 |  |  |  | 301 |  |  |  | 1,153 |  |  |  | 1,174 |  |
| Amortization of other purchase accounting adjustments |  |  | 222 |  |  |  | 391 |  |  |  | 1,117 |  |  |  | 1,378 |  |
| Acquisition related professional fees, travel and other expenses |  |  | 193 |  |  |  | 16 |  |  |  | 282 |  |  |  | 345 |  |
| Subtotal |  |  | 684 |  |  |  | 708 |  |  |  | 2,552 |  |  |  | 2,897 |  |
| Total acquisition related expenses, amortizations and adjustments |  |  | 910 |  |  |  | 987 |  |  |  | 3,477 |  |  |  | 4,039 |  |
| Provision for income taxes |  |  | (300 | ) |  |  | (328 | ) |  |  | (1,151 | ) |  |  | (1,343 | ) |
| Total acquisition related expenses, amortizations and adjustments, net of tax |  | $ | 610 |  |  | $ | 659 |  |  | $ | 2,326 |  |  | $ | 2,696 |  |

[0001193125-15-015465:8k_2_02:39]
The acquisition related expenses, amortizations and adjustments above were recorded in the following Consolidated Statements
of Income categories for the three and twelve months ended December 31, 2014 and 2013:

[0001193125-15-015465:8k_2_02:40]
|  |  | Three Months Ended |  |  | Twelve Months Ended |  |
|  |  | December 31, |  |  | December 31, |  |
|  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Revenue (adjustments to deferred revenue recognized in the period) |  | $ | 73 |  |  | $ | 211 |  |  | $ | 601 |  |  | $ | 929 |  |
| Cost of goods sold |  |  | 67 |  |  |  | 102 |  |  |  | 171 |  |  |  | 196 |  |
| Subtotal |  |  | 140 |  |  |  | 313 |  |  |  | 772 |  |  |  | 1,125 |  |
| Selling, general and administrative expenses |  |  | 200 |  |  |  | 24 |  |  |  | 310 |  |  |  | 399 |  |
| Research and development expenses |  |  | 570 |  |  |  | 650 |  |  |  | 2,395 |  |  |  | 2,515 |  |
| Subtotal |  |  | 770 |  |  |  | 674 |  |  |  | 2,705 |  |  |  | 2,914 |  |
| Total acquisition related expenses, amortizations and adjustments |  |  | 910 |  |  |  | 987 |  |  |  | 3,477 |  |  |  | 4,039 |  |
| Provision for income taxes |  |  | (300 | ) |  |  | (328 | ) |  |  | (1,151 | ) |  |  | (1,343 | ) |
| Total acquisition related expenses, amortizations and adjustments, net of tax |  | $ | 610 |  |  | $ | 659 |  |  | $ | 2,326 |  |  | $ | 2,696 |  |

[0001193125-15-015465:8k_2_02:41]
Supplemental Information

[0001193125-15-015465:8k_2_02:42]
Stock-based Compensation Expense

[0001193125-15-015465:8k_2_02:43]
(Unaudited)

[0001193125-15-015465:8k_2_02:44]
(In
thousands)

[0001193125-15-015465:8k_2_02:45]
|  |  | Three Months Ended |  |  | Twelve Months Ended |  |
|  |  | December 31, |  |  | December 31, |  |
|  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Stock-based compensation expense included in cost of sales |  | $ | 120 |  |  | $ | 131 |  |  | $ | 479 |  |  | $ | 465 |  |
| Selling, general and administrative expense |  |  | 1,096 |  |  |  | 1,314 |  |  |  | 4,185 |  |  |  | 4,443 |  |
| Research and development expense |  |  | 1,051 |  |  |  | 1,112 |  |  |  | 3,899 |  |  |  | 4,165 |  |
| Stock-based compensation expense included in operating expenses |  |  | 2,147 |  |  |  | 2,426 |  |  |  | 8,084 |  |  |  | 8,608 |  |
| Total stock-based compensation expense |  |  | 2,267 |  |  |  | 2,557 |  |  |  | 8,563 |  |  |  | 9,073 |  |
| Tax benefit for expense associated with non-qualified options |  |  | (279 | ) |  |  | (374 | ) |  |  | (1,157 | ) |  |  | (1,298 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 1,988 |  |  | $ | 2,183 |  |  | $ | 7,406 |  |  | $ | 7,775 |  |

[0001193125-15-015465:8k_2_02:46]
Reconciliation of GAAP net income per share, diluted, to

[0001193125-15-015465:8k_2_02:47]
Non-GAAP net income per share, diluted

[0001193125-15-015465:8k_2_02:48]
(Unaudited)

[0001193125-15-015465:8k_2_02:49]
|  |  | Three Months Ended |  |  | Twelve Months Ended |  |
|  |  | December 31, |  |  | December 31, |  |
|  |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| GAAP earnings per common share – diluted |  | $ | 0.17 |  |  | $ | 0.20 |  |  | $ | 0.80 |  |  | $ | 0.77 |  |
| Acquisition related expenses, amortizations and adjustments |  |  | 0.01 |  |  |  | 0.01 |  |  |  | 0.04 |  |  |  | 0.05 |  |
| Settlement of acquisition related working capital items |  |  | (0.03 | ) |  |  | — |  |  |  | (0.03 | ) |  |  | — |  |
| Stock-based compensation expense |  |  | 0.04 |  |  |  | 0.04 |  |  |  | 0.13 |  |  |  | 0.13 |  |
| Non-GAAP earnings per common share – diluted |  | $ | 0.19 |  |  | $ | 0.25 |  |  | $ | 0.94 |  |  | $ | 0.95 |  |
