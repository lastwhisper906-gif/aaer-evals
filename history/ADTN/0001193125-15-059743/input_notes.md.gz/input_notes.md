# ADTN notes — 0001193125-15-059743


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-15-059743:notes:1]
Note 13 – Commitments and Contingencies

[0001193125-15-059743:notes:2]
In the ordinary course of business, we may be subject to various
 legal proceedings and claims, including employment disputes, patent
 claims, disputes over contract agreements and other commercial
 disputes. In some cases, claimants seek damages or other relief,
 such as royalty payments related to patents, which, if granted,
 could require significant expenditures. Although the outcome of any
 claim or litigation can never be certain, it is our opinion that
 the outcome of all contingencies of which we are currently aware
 will not materially affect our business, operations, financial
 condition or cash flows.

[0001193125-15-059743:notes:3]
We lease office space and equipment under operating leases which
 expire at various dates through 2025. As of December 31, 2014,
 future minimum rental payments under non-cancelable operating
 leases with original maturities of greater than 12 months are as
 follows:

[0001193125-15-059743:notes:4]
| (In thousands) |  |
| 2015 |  | $ | 4,894 |  |
| 2016 |  |  | 3,701 |  |
| 2017 |  |  | 3,190 |  |
| 2018 |  |  | 1,563 |  |
| Thereafter |  |  | 5,340 |  |
| Total |  | $ | 18,688 |  |

[0001193125-15-059743:notes:5]
Rental expense was $4.7 million, $4.8 million and $3.9 million for
 the years ended December 31, 2014, 2013 and 2012,
 respectively.


## us-gaap:EarningsPerSharePolicyTextBlock

[0001193125-15-059743:notes:6]
Earnings per Share

[0001193125-15-059743:notes:7]
Earnings per common share, and earnings per common share assuming
 dilution, are based on the weighted average number of common shares
 and, when dilutive, common equivalent shares outstanding during the
 year. See Note 14 of Notes to Consolidated Financial Statements for
 additional information.


## us-gaap:EarningsPerShareTextBlock

[0001193125-15-059743:notes:8]
Note 14 – Earnings per Share

[0001193125-15-059743:notes:9]
A summary of the calculation of basic and diluted earnings per
 share (EPS) for the years ended December 31, 2014, 2013 and
 2012 is as follows:

[0001193125-15-059743:notes:10]
| (In thousands, except for per share amounts) |  | 2014 |  |  | 2013 |  |  | 2012 |  |
| Numerator |  |  |  |  |  |  |  |  |  |  |  |  |
| Net Income |  | $ | 44,620 |  |  | $ | 45,794 |  |  | $ | 47,263 |  |
| Denominator |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average number of shares – basic |  |  | 55,120 |  |  |  | 59,001 |  |  |  | 63,259 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock options |  |  | 304 |  |  |  | 390 |  |  |  | 488 |  |
| Restricted stock and restricted stock units |  |  | 58 |  |  |  | 33 |  |  |  | 27 |  |
| Weighted average number of shares – diluted |  |  | 55,482 |  |  |  | 59,424 |  |  |  | 63,774 |  |
| Net income per share – basic |  | $ | 0.81 |  |  | $ | 0.78 |  |  | $ | 0.75 |  |
| Net income per share – diluted |  | $ | 0.80 |  |  | $ | 0.77 |  |  | $ | 0.74 |  |

[0001193125-15-059743:notes:11]
For each of the years ended December 31, 2014, 2013 and 2012,
 4.4 million, 3.2 million and 3.2 million stock
 options were outstanding but were not included in the computation
 of that year’s diluted EPS because the options’
 exercise prices were greater than the average market price of the
 common shares, therefore making them anti-dilutive under the
 treasury stock method.


## us-gaap:InventoryPolicyTextBlock

[0001193125-15-059743:notes:12]
Inventory

[0001193125-15-059743:notes:13]
Inventory is carried at the lower of cost or market, with cost
 being determined using the first-in, first-out method. Standard
 costs for material, labor and manufacturing overhead are used to
 value inventory. Standard costs are updated at least quarterly;
 therefore, inventory costs approximate actual costs at the end of
 each reporting period. We establish reserves for estimated excess,
 obsolete or unmarketable inventory equal to the difference between
 the cost of the inventory and the estimated fair value of the
 inventory based upon assumptions about future demand and market
 conditions. When we dispose of excess and obsolete inventories, the
 related disposals are charged against the inventory reserve. See
 Note 6 of Notes to Consolidated Financial Statements for additional
 information.


## us-gaap:ScheduleOfEffectiveIncomeTaxRateReconciliationTableTextBlock

[0001193125-15-059743:notes:14]
Our effective income tax rate differs from the federal statutory
 rate due to the following:

[0001193125-15-059743:notes:15]
|  |  | 2014 |  |  | 2013 |  |  | 2012 |  |
| Tax provision computed at the federal statutory rate |  |  | 35.00 | % |  |  | 35.00 | % |  |  | 35.00 | % |
| State income tax provision, net of federal benefit |  |  | 2.69 |  |  |  | 3.98 |  |  |  | 3.78 |  |
| Federal research credits |  |  | (4.05 | ) |  |  | (9.24 | ) |  |  | — |  |
| Foreign taxes |  |  | (7.26 | ) |  |  | (2.93 | ) |  |  | 3.80 |  |
| Tax-exempt income |  |  | (1.25 | ) |  |  | (1.11 | ) |  |  | (1.01 | ) |
| State tax incentives |  |  | (2.21 | ) |  |  | (2.19 | ) |  |  | (4.46 | ) |
| Stock-based compensation |  |  | 3.06 |  |  |  | 2.97 |  |  |  | 2.36 |  |
| Domestic production activity deduction |  |  | (1.15 | ) |  |  | (1.80 | ) |  |  | (3.21 | ) |
| Other, net |  |  | 0.69 |  |  |  | 0.07 |  |  |  | (1.03 | ) |
| Effective Tax Rate |  |  | 25.52 | % |  |  | 24.75 | % |  |  | 35.23 | % |


## us-gaap:ScheduleOfFairValueAssetsAndLiabilitiesMeasuredOnRecurringBasisTableTextBlock

[0001193125-15-059743:notes:16]
We have categorized our cash equivalents and our investments held
 at fair value into a three-level fair value hierarchy based on the
 priority of the inputs to the valuation technique for the cash
 equivalents and investments as follows: Level 1 – Values
 based on unadjusted quoted prices for identical assets or
 liabilities in an active market; Level 2 – Values based on
 quoted prices in markets that are not active or model inputs that
 are observable either directly or indirectly; Level 3 –
 Values based on prices or valuation techniques that require inputs
 that are both unobservable and significant to the overall fair
 value measurement. These inputs include information supplied by
 investees.

[0001193125-15-059743:notes:17]
|  |  | Fair Value Measurements at December 31, 2014 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  | $ | 4 |  |  | $ | 4 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Bond funds: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 12,587 |  |  |  | 12,587 |  |  |  | — |  |  |  | — |  |
| Government bonds |  |  | 2,172 |  |  |  | 2,172 |  |  |  | — |  |  |  | — |  |
| Equity funds: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Large cap blend |  |  | 4,488 |  |  |  | 4,488 |  |  |  | — |  |  |  | — |  |
| Large cap value |  |  | 268 |  |  |  | 268 |  |  |  | — |  |  |  | — |  |
| Balanced fund |  |  | 819 |  |  |  | 819 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 20,334 |  |  |  | 20,334 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 20,338 |  |  | $ | 20,338 |  |  | $ | — |  |  | $ | — |  |

[0001193125-15-059743:notes:18]
|  |  | Fair Value Measurements at December 31, 2013 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  | $ | 4 |  |  | $ | 4 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Bond funds: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 12,976 |  |  |  | 12,976 |  |  |  | — |  |  |  | — |  |
| Government bonds |  |  | 1,915 |  |  |  | 1,915 |  |  |  | — |  |  |  | — |  |
| Equity funds: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Large cap blend |  |  | 4,720 |  |  |  | 4,720 |  |  |  | — |  |  |  | — |  |
| Large cap value |  |  | 287 |  |  |  | 287 |  |  |  | — |  |  |  | — |  |
| Balanced fund |  |  | 871 |  |  |  | 871 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 20,769 |  |  |  | 20,769 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 20,773 |  |  | $ | 20,773 |  |  | $ | — |  |  | $ | — |  |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0001193125-15-059743:notes:19]
The following table presents sales information by geographic area
 for the years ended December 31, 2014, 2013 and 2012.
 International sales correlate to shipments with a non-U.S.
 destination.

[0001193125-15-059743:notes:20]
| (In thousands) |  | 2014 |  |  | 2013 |  |  | 2012 |  |
| United States |  | $ | 381,382 |  |  | $ | 455,996 |  |  | $ | 470,369 |  |
| Germany |  |  | 150,987 |  |  |  | 97,151 |  |  |  | 26,918 |  |
| Other international |  |  | 97,638 |  |  |  | 88,597 |  |  |  | 123,327 |  |
| Total |  | $ | 630,007 |  |  | $ | 641,744 |  |  | $ | 620,614 |  |


## us-gaap:CompensationRelatedCostsPolicyTextBlock

[0001193125-15-059743:notes:21]
Stock-Based Compensation

[0001193125-15-059743:notes:22]
We have two Board and stockholder approved stock option plans from
 which stock options and other awards are available for grant to
 employees and directors. All employee and director stock options
 granted under our stock option plans have an exercise price equal
 to the fair market value of the award, as defined in the plan, of
 the underlying common stock on the grant date. There are currently
 no vesting provisions tied to performance or market conditions for
 any option awards; vesting for all outstanding option grants is
 based only on continued service as an employee or director of
 ADTRAN. All of our outstanding stock option awards are classified
 as equity awards.

[0001193125-15-059743:notes:23]
Under the provisions of our approved plans, we made grants of
 performance-based restricted stock units to certain of our
 executive officers in 2014, 2013, and 2012. The restricted stock
 units are subject to a market condition based on the relative total
 shareholder return of ADTRAN against all the companies in the
 NASDAQ Telecommunications Index and vest at the end of a three-year
 performance period. The restricted stock units are converted into
 shares of common stock upon vesting. Depending on the relative
 total shareholder return over the performance period, the executive
 officers may earn from 0% to 150% of the number of restricted stock
 units granted. The fair value of the award is based on the market
 price of our common stock on the date of grant, adjusted for the
 expected outcome of the impact of market conditions using a Monte
 Carlo Simulation valuation method. The recipients of the restricted
 stock units also earn dividend credits during the performance
 period, which will be paid in cash upon the issuance of common
 stock for the restricted stock units.

[0001193125-15-059743:notes:24]
Stock-based compensation expense recognized in 2014, 2013 and 2012
 was approximately $8.6 million, $9.1 million and $9.3 million,
 respectively. As of December 31, 2014, total compensation cost
 related to non-vested stock options, restricted stock units and
 restricted stock not yet recognized was approximately $17.7
 million, which is expected to be recognized over an average
 remaining recognition period of 2.8 years. See Note 3 of Notes to
 Consolidated Financial Statements for additional information.


## us-gaap:ComprehensiveIncomePolicyPolicyTextBlock

[0001193125-15-059743:notes:25]
Other Comprehensive Income

[0001193125-15-059743:notes:26]
Other comprehensive income consists of unrealized gains (losses) on
 available-for-sale securities, reclassification adjustments for
 amounts included in net income related to impairments of
 available-for-sale securities and realized gains (losses) on
 available-for-sale securities, defined benefit plan adjustments and
 foreign currency translation adjustments.

[0001193125-15-059743:notes:27]
The following table presents changes in accumulated other
 comprehensive income, net of tax, by component for the years ended
 December 31, 2012, 2013 and 2014:

[0001193125-15-059743:notes:28]
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | Total |  |
| Balance at December 31, 2011 |  | $ | 10,160 |  |  | $ | — |  |  | $ | 2,942 |  |  | $ | 13,102 |  |
| Other comprehensive income (loss) before reclassifications |  |  | 5,426 |  |  |  | (1,952 | ) |  |  | 170 |  |  |  | 3,644 |  |
| Amounts reclassified from accumulated other comprehensive income |  |  | (5,478 | ) |  |  | — |  |  |  | — |  |  |  | (5,478 | ) |
| Balance at December 31, 2012 |  | $ | 10,108 |  |  | $ | (1,952 | ) |  | $ | 3,112 |  |  | $ | 11,268 |  |
| Other comprehensive income (loss) before reclassifications |  |  | 5,508 |  |  |  | 1,061 |  |  |  | (2,205 | ) |  |  | 4,364 |  |
| Amounts reclassified from accumulated other comprehensive income |  |  | (4,879 | ) |  |  | — |  |  |  | — |  |  |  | (4,879 | ) |
| Balance at December 31, 2013 |  | $ | 10,737 |  |  | $ | (891 | ) |  | $ | 907 |  |  | $ | 10,753 |  |
| Other comprehensive income (loss) before reclassifications |  |  | 2,363 |  |  |  | (4,866 | ) |  |  | (4,189 | ) |  |  | (6,692 | ) |
| Amounts reclassified from accumulated other comprehensive income |  |  | (4,136 | ) |  |  | — |  |  |  | — |  |  |  | (4,136 | ) |
| Balance at December 31, 2014 |  | $ | 8,964 |  |  | $ | (5,757 | ) |  | $ | (3,282 | ) |  | $ | (75 | ) |

[0001193125-15-059743:notes:29]
The following tables present the details of reclassifications out
 of accumulated other comprehensive income for the years ended
 December 31, 2014, 2013 and 2012:

[0001193125-15-059743:notes:30]
| (In thousands) |  | 2014 |
| Details about Accumulated Other Comprehensive Income Components |  | Amount Reclassified from Accumulated Other Comprehensive Income |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for-sale securities: |  |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 6,895 |  |  | Net realized investment gain |
| Impairment expense |  |  | (115 | ) |  | Net realized investment gain |
| Total reclassifications for the period, before tax |  |  | 6,780 |  |  |  |
| Tax (expense) benefit |  |  | (2,644 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 4,136 |  |  |  |

[0001193125-15-059743:notes:31]
| (In thousands) |  | 2013 |
| Details about Accumulated Other Comprehensive Income Components |  | Amount Reclassified from Accumulated Other Comprehensive Income |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for-sale securities: |  |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 8,023 |  |  | Net realized investment gain |
| Impairment expense |  |  | (25 | ) |  | Net realized investment gain |
| Total reclassifications for the period, before tax |  |  | 7,998 |  |  |  |
| Tax (expense) benefit |  |  | (3,119 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 4,879 |  |  |  |

[0001193125-15-059743:notes:32]
| (In thousands) |  | 2012 |
| Details about Accumulated Other Comprehensive Income Components |  | Amount Reclassified from Accumulated Other Comprehensive Income |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for-sale securities: |  |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 9,662 |  |  | Net realized investment gain |
| Impairment expense |  |  | (682 | ) |  | Net realized investment gain |
| Total reclassifications for the period, before tax |  |  | 8,980 |  |  |  |
| Tax (expense) benefit |  |  | (3,502 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 5,478 |  |  |  |

[0001193125-15-059743:notes:33]
The following tables present the tax effects related to the change
 in each component of other comprehensive income for the years ended
 December 31, 2014, 2013 and 2012:

[0001193125-15-059743:notes:34]
|  |  | 2014 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |
| Unrealized gains (losses) on available-for-sale securities |  | $ | 3,874 |  |  | $ | (1,511 | ) |  | $ | 2,363 |  |
| Reclassification adjustment for amounts included in net income |  |  | (6,780 | ) |  |  | 2,644 |  |  |  | (4,136 | ) |
| Defined benefit plan adjustments |  |  | (7,052 | ) |  |  | 2,186 |  |  |  | (4,866 | ) |
| Foreign currency translation adjustment |  |  | (4,189 | ) |  |  | — |  |  |  | (4,189 | ) |
| Total Other Comprehensive Income (Loss) |  | $ | (14,147 | ) |  | $ | 3,319 |  |  | $ | (10,828 | ) |

[0001193125-15-059743:notes:35]
|  |  | 2013 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |
| Unrealized gains (losses) on available-for-sale securities |  | $ | 9,030 |  |  | $ | (3,522 | ) |  | $ | 5,508 |  |
| Reclassification adjustment for amounts included in net income |  |  | (7,998 | ) |  |  | 3,119 |  |  |  | (4,879 | ) |
| Defined benefit plan adjustments |  |  | 1,061 |  |  |  | — |  |  |  | 1,061 |  |
| Foreign currency translation adjustment |  |  | (2,205 | ) |  |  | — |  |  |  | (2,205 | ) |
| Total Other Comprehensive Income (Loss) |  | $ | (112 | ) |  | $ | (403 | ) |  | $ | (515 | ) |

[0001193125-15-059743:notes:36]
|  |  | 2012 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |
| Unrealized gains (losses) on available-for-sale securities |  | $ | 8,895 |  |  | $ | (3,469 | ) |  | $ | 5,426 |  |
| Reclassification adjustment for amounts included in net income |  |  | (8,980 | ) |  |  | 3,502 |  |  |  | (5,478 | ) |
| Defined benefit plan adjustments |  |  | (1,952 | ) |  |  | — |  |  |  | (1,952 | ) |
| Foreign currency translation adjustment |  |  | 170 |  |  |  | — |  |  |  | 170 |  |
| Total Other Comprehensive Income (Loss) |  | $ | (1,867 | ) |  | $ | 33 |  |  | $ | (1,834 | ) |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001193125-15-059743:notes:37]
We have categorized our cash equivalents held in money market funds
 and our investments held at fair value into a three-level fair
 value hierarchy based on the priority of the inputs to the
 valuation technique for the cash equivalents and investments as
 follows: Level 1 – Values based on unadjusted quoted prices
 for identical assets or liabilities in an active market; Level 2
 – Values based on quoted prices in markets that are not
 active or model inputs that are observable either directly or
 indirectly; Level 3 – Values based on prices or valuation
 techniques that require inputs that are both unobservable and
 significant to the overall fair value measurement. These inputs
 include information supplied by investees.

[0001193125-15-059743:notes:38]
|  |  |  |  |  | Fair Value Measurements at December 31, 2014 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,163 |  |  | $ | 1,163 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 16,294 |  |  |  | 16,294 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 111,261 |  |  |  | — |  |  |  | 111,261 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 127,787 |  |  |  | — |  |  |  | 127,787 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 2,465 |  |  |  | — |  |  |  | 2,465 |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – technology industry |  |  | 9,661 |  |  |  | 9,661 |  |  |  | — |  |  |  | — |  |
| Marketable equity securities – other |  |  | 28,594 |  |  |  | 28,594 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 296,062 |  |  |  | 54,549 |  |  |  | 241,513 |  |  |  | — |  |
| Total |  | $ | 297,225 |  |  | $ | 55,712 |  |  | $ | 241,513 |  |  | $ | — |  |

[0001193125-15-059743:notes:39]
|  |  |  |  |  | Fair Value Measurements at December 31, 2013 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 3,949 |  |  | $ | 3,949 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 15,123 |  |  |  | 15,123 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 166,859 |  |  |  | — |  |  |  | 166,859 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 136,302 |  |  |  | — |  |  |  | 136,302 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 8,310 |  |  |  | — |  |  |  | 8,310 |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – technology industry |  |  | 11,398 |  |  |  | 11,398 |  |  |  | — |  |  |  | — |  |
| Marketable equity securities – other |  |  | 27,054 |  |  |  | 27,054 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 365,046 |  |  |  | 53,575 |  |  |  | 311,471 |  |  |  | — |  |
| Total |  | $ | 368,995 |  |  | $ | 57,524 |  |  | $ | 311,471 |  |  | $ | — |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001193125-15-059743:notes:40]
Note 8 – Goodwill and Intangible Assets

[0001193125-15-059743:notes:41]
Goodwill, all of which relates to our acquisition of Bluesocket,
 Inc. and is included in our Enterprise Networks division, was $3.5
 million at December 31, 2014 and 2013. We evaluate the
 carrying value of goodwill during the fourth quarter of each year
 and between annual evaluations if events occur or circumstances
 change that would more likely than not reduce the fair value of the
 reporting unit below its carrying amount. We have elected to first
 assess the qualitative factors to determine whether it is more
 likely than not that the fair value of the reporting unit to which
 the goodwill is assigned is less than its carrying amount as a
 basis for determining whether it is necessary to perform the
 two-step impairment test. If we determine that it is more likely
 than not that its fair value is less than its carrying amount, then
 the two-step impairment test will be performed. Based on the
 results of our qualitative assessment in 2014, we concluded that it
 was not necessary to perform the two-step impairment test. There
 were no impairment losses recognized during 2014, 2013, or
 2012.

[0001193125-15-059743:notes:42]
Intangible assets are included in other assets in the accompanying
 Consolidated Balance Sheets and include intangible assets acquired
 in conjunction with our acquisition of Objectworld Communications
 Corporation on September 15, 2009, Bluesocket, Inc. on
 August 4, 2011, and the NSN BBA business on May 4,
 2012.

[0001193125-15-059743:notes:43]
The following table presents our intangible assets as of
 December 31, 2014 and 2013:

[0001193125-15-059743:notes:44]
| (In thousands) |  | 2014 |  |  | 2013 |  |
|  |  | Gross Value |  |  | Accumulated Amortization |  |  | Net Value |  |  | Gross Value |  |  | Accumulated Amortization |  |  | Net Value |  |
| Customer relationships |  | $ | 6,310 |  |  | $ | (2,136 | ) |  | $ | 4,174 |  |  | $ | 6,996 |  |  | $ | (1,555 | ) |  | $ | 5,441 |  |
| Developed technology |  |  | 6,005 |  |  |  | (3,577 | ) |  |  | 2,428 |  |  |  | 6,537 |  |  |  | (2,692 | ) |  |  | 3,845 |  |
| Intellectual property |  |  | 2,340 |  |  |  | (1,520 | ) |  |  | 820 |  |  |  | 2,340 |  |  |  | (1,185 | ) |  |  | 1,155 |  |
| Trade names |  |  | 270 |  |  |  | (205 | ) |  |  | 65 |  |  |  | 270 |  |  |  | (145 | ) |  |  | 125 |  |
| Other |  |  | 12 |  |  |  | (11 | ) |  |  | 1 |  |  |  | 14 |  |  |  | (8 | ) |  |  | 6 |  |
| Total |  | $ | 14,937 |  |  | $ | (7,449 | ) |  | $ | 7,488 |  |  | $ | 16,157 |  |  | $ | (5,585 | ) |  | $ | 10,572 |  |

[0001193125-15-059743:notes:45]
Amortization expense was $2.3 million, $2.4 million and $2.0
 million for the years ended December 31, 2014, 2013 and 2012,
 respectively.

[0001193125-15-059743:notes:46]
As of December 31, 2014, the estimated future amortization
 expense of intangible assets is as follows:

[0001193125-15-059743:notes:47]
| (In thousands) |  | Amount |  |
| 2015 |  | $ | 2,027 |  |
| 2016 |  |  | 1,757 |  |
| 2017 |  |  | 1,209 |  |
| 2018 |  |  | 732 |  |
| 2019 |  |  | 336 |  |
| Thereafter |  |  | 1,427 |  |
| Total |  | $ | 7,488 |  |


## us-gaap:IncomeTaxPolicyTextBlock

[0001193125-15-059743:notes:48]
Income Taxes

[0001193125-15-059743:notes:49]
The provision for income taxes has been determined using the asset
 and liability approach of accounting for income taxes. Under this
 approach, deferred taxes represent the future tax consequences
 expected to occur when the reported amounts of assets and
 liabilities are recovered or paid. The provision for income taxes
 represents income taxes paid or payable for the current year plus
 the change in deferred taxes during the year. Deferred taxes result
 from the difference between financial and tax bases of our assets
 and liabilities and are adjusted for changes in tax rates and tax
 laws when such changes are enacted. Valuation allowances are
 recorded to reduce deferred tax assets when it is more likely than
 not that a tax benefit will not be realized.

[0001193125-15-059743:notes:50]
We establish reserves to remove some or all of the tax benefit of
 any of our tax positions at the time we determine that the
 positions become uncertain. We adjust these reserves, including any
 impact on the related interest and penalties, as facts and
 circumstances change.


## us-gaap:ReceivablesPolicyTextBlock

[0001193125-15-059743:notes:51]
Accounts Receivable

[0001193125-15-059743:notes:52]
We record accounts receivable at net realizable value. Prior to
 issuing payment terms to a new customer, we perform a detailed
 credit review of the customer. Credit limits are established for
 each new customer based on the results of this credit review.
 Payment terms are established for each new customer, and collection
 experience is reviewed periodically in order to determine if the
 customer’s payment terms and credit limits need to be
 revised. At December 31, 2014, two customers accounted for
 24.5% of our total accounts receivable. At December 31, 2013,
 one customer accounted for 13.1% of our total accounts
 receivable.

[0001193125-15-059743:notes:53]
We maintain an allowance for doubtful accounts for losses resulting
 from the inability of our customers to make required payments. We
 regularly review the allowance for doubtful accounts and consider
 factors such as the age of accounts receivable balances, the
 current economic conditions that may affect a customer’s
 ability to pay, significant one-time events and our historical
 experience. If the financial condition of a customer deteriorates,
 resulting in an impairment of their ability to make payments, we
 may be required to record an allowance for doubtful accounts. If
 circumstances change with regard to individual receivable balances
 that have previously been determined to be uncollectible (and for
 which a specific reserve has been established), a reduction in our
 allowance for doubtful accounts may be required. Our allowance for
 doubtful accounts was $0.1 million at December 31, 2014 and
 December 31, 2013.


## us-gaap:ScheduleOfAvailableForSaleSecuritiesReconciliationTableTextBlock

[0001193125-15-059743:notes:54]
At December 31, 2014, we held the following securities and
 investments, recorded at either fair value or cost:

[0001193125-15-059743:notes:55]
|  |  | Amortized Cost |  |  | Gross Unrealized |  |  | Fair Value / Carrying Value |  |
| (In thousands) |  |  | Gains |  |  | Losses |  |  |
| Deferred compensation plan assets |  | $ | 13,897 |  |  | $ | 2,409 |  |  | $ | (12 | ) |  | $ | 16,294 |  |
| Corporate bonds |  |  | 111,261 |  |  |  | 186 |  |  |  | (186 | ) |  |  | 111,261 |  |
| Municipal fixed-rate bonds |  |  | 127,341 |  |  |  | 480 |  |  |  | (34 | ) |  |  | 127,787 |  |
| Municipal variable rate demand notes |  |  | 2,465 |  |  |  | — |  |  |  | — |  |  |  | 2,465 |  |
| Marketable equity securities |  |  | 26,399 |  |  |  | 12,395 |  |  |  | (539 | ) |  |  | 38,255 |  |
| Available-for-sale securities held at fair value |  | $ | 281,363 |  |  | $ | 15,470 |  |  | $ | (771 | ) |  | $ | 296,062 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 30,000 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1,506 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 327,568 |  |

[0001193125-15-059743:notes:56]
At December 31, 2013, we held the following securities and
 investments, recorded at either fair value or cost:

[0001193125-15-059743:notes:57]
|  |  | Amortized Cost |  |  | Gross Unrealized |  |  | Fair Value / Carrying Value |  |
| (In thousands) |  |  | Gains |  |  | Losses |  |  |
| Deferred compensation plan assets |  | $ | 12,300 |  |  | $ | 2,847 |  |  | $ | (24 | ) |  | $ | 15,123 |  |
| Corporate bonds |  |  | 166,370 |  |  |  | 534 |  |  |  | (45 | ) |  |  | 166,859 |  |
| Municipal fixed-rate bonds |  |  | 135,773 |  |  |  | 583 |  |  |  | (54 | ) |  |  | 136,302 |  |
| Municipal variable rate demand notes |  |  | 8,310 |  |  |  | — |  |  |  | — |  |  |  | 8,310 |  |
| Marketable equity securities |  |  | 24,654 |  |  |  | 13,975 |  |  |  | (177 | ) |  |  | 38,452 |  |
| Available-for-sale securities held at fair value |  | $ | 347,407 |  |  | $ | 17,939 |  |  | $ | (300 | ) |  | $ | 365,046 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 48,250 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1,689 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 414,985 |  |


## us-gaap:ScheduleOfDeferredCompensationArrangementWithIndividualExcludingShareBasedPaymentsAndPostretirementBenefitsByTitleOfIndividualAndByTypeOfDeferredCompensationTextBlock

[0001193125-15-059743:notes:58]
The fair value of the assets held by the Trust and the amounts
 payable to the plan participants are as follows:

[0001193125-15-059743:notes:59]
| (In thousands) |  | 2014 |  |  | 2013 |  |
| Fair Value of Plan Assets |  |  |  |  |  |  |  |  |
| Long-term Investments |  | $ | 16,294 |  |  | $ | 15,123 |  |
| Total Fair Value of Plan Assets |  | $ | 16,294 |  |  | $ | 15,123 |  |
| Amounts Payable to Plan Participants |  |  |  |  |  |  |  |  |
| Non-current Liabilities |  | $ | 16,294 |  |  | $ | 15,123 |  |
| Total Amounts Payable to Plan Participants |  | $ | 16,294 |  |  | $ | 15,123 |  |


## us-gaap:ScheduleOfDerivativeInstrumentsInStatementOfFinancialPositionFairValueTextBlock

[0001193125-15-059743:notes:60]
The fair values of our derivative instruments recorded in the
 Consolidated Balance Sheet as of December 31, 2014 and 2013
 were as follows:

[0001193125-15-059743:notes:61]
| (In thousands) |  | Balance Sheet Location |  | 2014 |  |  | 2013 |  |
| Derivatives Not Designated as Hedging Instruments (Level 2): |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts – asset derivatives |  | Other receivables |  | $ | 249 |  |  | $ | 18 |  |
| Foreign exchange contracts – liability derivatives |  | Accounts payable |  | $ | (10 | ) |  | $ | (15 | ) |


## us-gaap:ScheduleOfIncomeBeforeIncomeTaxDomesticAndForeignTableTextBlock

[0001193125-15-059743:notes:62]
Income before provision for income taxes for the years ended
 December 31, 2014, 2013 and 2012 is as follows:

[0001193125-15-059743:notes:63]
| (In thousands) |  | 2014 |  |  | 2013 |  |  | 2012 |  |
| U.S. entities |  | $ | 23,812 |  |  | $ | 51,752 |  |  | $ | 80,926 |  |
| International entities |  |  | 36,094 |  |  |  | 9,103 |  |  |  | (7,961 | ) |
| Total |  | $ | 59,906 |  |  | $ | 60,855 |  |  | $ | 72,965 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001193125-15-059743:notes:64]
At December 31, 2014 and 2013, inventory was comprised of the
 following:

[0001193125-15-059743:notes:65]
| (In thousands) |  | 2014 |  |  | 2013 |  |
| Raw materials |  | $ | 34,831 |  |  | $ | 44,093 |  |
| Work in process |  |  | 3,750 |  |  |  | 3,484 |  |
| Finished goods |  |  | 48,129 |  |  |  | 42,534 |  |
| Total Inventory, net |  | $ | 86,710 |  |  | $ | 90,111 |  |


## us-gaap:ScheduleOfNetBenefitCostsTableTextBlock

[0001193125-15-059743:notes:66]
The weighted-average assumptions that were used to determine the
 net periodic benefit cost for the years ended December 31,
 2014 and 2013 and the period May 4, 2012 to December 31,
 2012 are as follows:

[0001193125-15-059743:notes:67]
|  |  | Year Ended December 31, 2014 |  |  | Year Ended December 31, 2013 |  |  | May 4, 2012 to December 31, 2012 |  |
| Discount rates |  |  | 3.70 | % |  |  | 3.50 | % |  |  | 3.96 | % |
| Rate of compensation increase |  |  | 2.25 | % |  |  | 2.25 | % |  |  | 2.25 | % |
| Expected long-term rates of return |  |  | 5.40 | % |  |  | 5.40 | % |  |  | 5.40 | % |


## us-gaap:ScheduleOfRealizedGainLossTableTextBlock

[0001193125-15-059743:notes:68]
The following table presents gross realized gains and losses
 related to our investments for the years ended December 31,
 2014, 2013 and 2012:

[0001193125-15-059743:notes:69]
| Year Ended December 31, |  |  |  |  |  |  |  |  |  |
| (In thousands) |  | 2014 |  |  | 2013 |  |  | 2012 |  |
| Gross realized gains |  | $ | 7,586 |  |  | $ | 8,932 |  |  | $ | 11,006 |  |
| Gross realized losses |  | $ | (308 | ) |  | $ | (318 | ) |  | $ | (1,456 | ) |


## us-gaap:ScheduleOfShareBasedCompensationStockOptionsActivityTableTextBlock

[0001193125-15-059743:notes:70]
The following table is a summary of our stock options outstanding
 as of December 31, 2013 and 2014 and the changes that occurred
 during 2014:

[0001193125-15-059743:notes:71]
| (In thousands, except per share amounts) |  | Number of Options |  |  | Weighted Average Exercise Price |  |  | Weighted Avg. Remaining Contractual Life in Years |  |  | Aggregate Intrinsic Value |  |
| Options outstanding, December 31, 2013 |  |  | 6,358 |  |  | $ | 24.43 |  |  |  | 6.60 |  |  | $ | 25,878 |  |
| Options granted |  |  | 1,181 |  |  | $ | 18.98 |  |  |  |  |  |  |  |  |  |
| Options forfeited |  |  | (150 | ) |  | $ | 23.28 |  |  |  |  |  |  |  |  |  |
| Options cancelled |  |  | (261 | ) |  | $ | 24.87 |  |  |  |  |  |  |  |  |  |
| Options exercised |  |  | (147 | ) |  | $ | 19.27 |  |  |  |  |  |  |  |  |  |
| Options outstanding, December 31, 2014 |  |  | 6,981 |  |  | $ | 23.62 |  |  |  | 6.45 |  |  | $ | 10,625 |  |
| Options vested and expected to vest, December 31, 2014 |  |  | 6,787 |  |  | $ | 23.69 |  |  |  | 6.38 |  |  | $ | 9,381 |  |
| Options exercisable, December 31, 2014 |  |  | 4,397 |  |  | $ | 25.15 |  |  |  | 4.99 |  |  | $ | 5,153 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-15-059743:notes:72]
Note 12 – Segment Information and Major Customers

[0001193125-15-059743:notes:73]
We operate in two reportable segments: (1) the Carrier
 Networks Division and (2) the Enterprise Networks Division.
 The accounting policies of the segments are the same as those
 described in the “Nature of Business and Summary of
 Significant Accounting Policies” (see Note 1) to the extent
 that such policies affect the reported segment information. We
 evaluate the performance of our segments based on gross profit;
 therefore, selling, general and administrative expense, research
 and development expenses, interest income and dividend income,
 interest expense, net realized investment gain/loss, other
 income/expense and provision for taxes are reported on an
 entity-wide basis only. There are no inter-segment revenues.

[0001193125-15-059743:notes:74]
The following table presents information about the reported sales
 and gross profit of our reportable segments for each of the years
 ended December 31, 2014, 2013 and 2012. Asset information by
 reportable segment is not reported, since we do not produce such
 information internally.

[0001193125-15-059743:notes:75]
Sales and Gross Profit by Market Segment

[0001193125-15-059743:notes:76]
| (In thousands) |  | 2014 |  |  | 2013 |  |  | 2012 |  |
|  |  | Sales |  |  | Gross Profit |  |  | Sales |  |  | Gross Profit |  |  | Sales |  |  | Gross Profit |  |
| Carrier Networks |  | $ | 510,373 |  |  | $ | 243,211 |  |  | $ | 500,733 |  |  | $ | 233,206 |  |  | $ | 492,096 |  |  | $ | 247,380 |  |
| Enterprise Networks |  |  | 119,634 |  |  |  | 68,116 |  |  |  | 141,011 |  |  |  | 75,680 |  |  |  | 128,518 |  |  |  | 69,263 |  |
| Total |  | $ | 630,007 |  |  | $ | 311,327 |  |  | $ | 641,744 |  |  | $ | 308,886 |  |  | $ | 620,614 |  |  | $ | 316,643 |  |

[0001193125-15-059743:notes:77]
Sales by Product

[0001193125-15-059743:notes:78]
Our three major product categories are Carrier Systems, Business
 Networking and Loop Access.

[0001193125-15-059743:notes:79]
Carrier Systems products are used by communications service
 providers to provide data, voice, and video services to consumers
 and enterprises. This category includes the following product areas
 and related services:

[0001193125-15-059743:notes:80]
|  | • |  | Broadband Access |

[0001193125-15-059743:notes:81]
|  | • |  | Total Access® 5000 Series of Multi-Service Access Node (MSAN) |

[0001193125-15-059743:notes:82]
|  | • |  | hiX 5600 Series of MSANs |

[0001193125-15-059743:notes:83]
|  | • |  | Total Access 1100/1200 Series of Fiber to the Node (FTTN) products |

[0001193125-15-059743:notes:84]
|  | • |  | hiX 1100 Series of Fiber to the Node (FTTN) products |

[0001193125-15-059743:notes:85]
|  | • |  | VDSL2 Vectoring based Digital Subscriber Line Access Multiplexer (DSLAM) products |

[0001193125-15-059743:notes:86]
|  | • |  | ADTRAN 500 Series of FTTdp G.fast Distribution Point Units (DPU) |

[0001193125-15-059743:notes:87]
|  | • |  | Optical |

[0001193125-15-059743:notes:88]
|  | • |  | Optical Networking Edge (ONE) |

[0001193125-15-059743:notes:89]
|  | • |  | NetVanta 8000 Series of Fiber Ethernet Access Devices (EAD) |

[0001193125-15-059743:notes:90]
|  | • |  | NetVanta 8400 Series of 10Gig Multi-service Edge Switches |

[0001193125-15-059743:notes:91]
|  | • |  | OPTI-6100 and Total Access 3000 optical Multi-Service Provisioning Platforms (MSPP) |

[0001193125-15-059743:notes:92]
|  | • |  | Pluggable Optical Products, including SFP, XFP, and SFP+ |

[0001193125-15-059743:notes:93]
|  | • |  | Time Division Multiplexed (TDM) systems |

[0001193125-15-059743:notes:94]
Business Networking products provide access to communication
 services and facilitate the delivery of cloud connectivity and
 enterprise communications to the small and mid-sized enterprise
 (SME) market. This category includes the following product areas
 and related services:

[0001193125-15-059743:notes:95]
|  | • |  | Internetworking products |

[0001193125-15-059743:notes:96]
|  | • |  | Total Access IP Business Gateways |

[0001193125-15-059743:notes:97]
|  | • |  | Optical Network Terminals (ONTs) |

[0001193125-15-059743:notes:98]
|  | • |  | Bluesocket® virtual Wireless LAN (vWLAN®) |

[0001193125-15-059743:notes:99]
|  | • |  | NetVanta® |

[0001193125-15-059743:notes:100]
|  | • |  | Access Routers |

[0001193125-15-059743:notes:101]
|  | • |  | Enterprise Session Border Controllers (eSBC) |

[0001193125-15-059743:notes:102]
|  | • |  | Managed Ethernet Switches |

[0001193125-15-059743:notes:103]
|  | • |  | IP Business Gateways |

[0001193125-15-059743:notes:104]
|  | • |  | Unified Communications (UC) solutions |

[0001193125-15-059743:notes:105]
|  | • |  | Carrier Ethernet Network Terminating Equipment (NTE) |

[0001193125-15-059743:notes:106]
|  | • |  | Carrier Ethernet Routers and Gateways |

[0001193125-15-059743:notes:107]
|  | • |  | Network Management Solutions |

[0001193125-15-059743:notes:108]
Loop Access products are used by carrier and enterprise
 customers for access to copper-based communications networks. This
 category includes the following product areas and related
 services:

[0001193125-15-059743:notes:109]
|  | • |  | High bit-rate Digital Subscriber Line (HDSL) products |

[0001193125-15-059743:notes:110]
|  | • |  | Digital Data Service (DDS) |

[0001193125-15-059743:notes:111]
|  | • |  | Integrated Services Digital Network (ISDN) products |

[0001193125-15-059743:notes:112]
|  | • |  | T1/E1/T3 Channel Service Units/Data Service Units (CSUs/DSUs) |

[0001193125-15-059743:notes:113]
|  | • |  | TRACER fixed-wireless products |

[0001193125-15-059743:notes:114]
The table below presents sales information by product category for
 the years ended December 31, 2014, 2013 and 2012:

[0001193125-15-059743:notes:115]
| (In thousands) |  | 2014 |  |  | 2013 |  |  | 2012 |  |
| Carrier Systems |  | $ | 442,664 |  |  | $ | 427,850 |  |  | $ | 399,646 |  |
| Business Networking |  |  | 156,980 |  |  |  | 168,871 |  |  |  | 149,304 |  |
| Loop Access |  |  | 30,363 |  |  |  | 45,023 |  |  |  | 71,664 |  |
| Total |  | $ | 630,007 |  |  | $ | 641,744 |  |  | $ | 620,614 |  |

[0001193125-15-059743:notes:116]
In addition, we identify subcategories of product revenues, which
 we divide into core products and legacy products. Our core products
 consist of Broadband Access and Optical products (included in
 Carrier Systems), and Internetworking products (included in
 Business Networking). Our legacy products include HDSL products
 (included in Loop Access) and other products not included in the
 aforementioned core products.

[0001193125-15-059743:notes:117]
The table below presents subcategory revenues for the years ended
 December 31, 2014, 2013 and 2012:

[0001193125-15-059743:notes:118]
| (In thousands) |  | 2014 |  |  | 2013 |  |  | 2012 |  |
| Core Products |  |  |  |  |  |  |  |  |  |  |  |  |
| Broadband Access (included in Carrier Systems) |  | $ | 368,464 |  |  | $ | 340,560 |  |  | $ | 320,076 |  |
| Optical (included in Carrier Systems) |  |  | 55,374 |  |  |  | 55,615 |  |  |  | 51,755 |  |
| Internetworking (NetVanta® & Multi-service Access Gateways) (included in Business Networking) |  |  | 152,223 |  |  |  | 164,422 |  |  |  | 142,958 |  |
| Subtotal |  | $ | 576,061 |  |  | $ | 560,597 |  |  | $ | 514,789 |  |
| Legacy Products |  |  |  |  |  |  |  |  |  |  |  |  |
| HDSL (does not include T1) (included in Loop Access) |  |  | 27,829 |  |  |  | 41,666 |  |  |  | 66,974 |  |
| Other products (excluding HDSL) |  |  | 26,117 |  |  |  | 39,481 |  |  |  | 38,851 |  |
| Subtotal |  | $ | 53,946 |  |  | $ | 81,147 |  |  | $ | 105,825 |  |
| Total |  | $ | 630,007 |  |  | $ | 641,744 |  |  | $ | 620,614 |  |

[0001193125-15-059743:notes:119]
Customers comprising more than 10% of revenue can change from year
 to year. Single customers comprising more than 10% of our revenue
 in 2014 included two customers at 21% and 14%. Single customers
 comprising more than 10% of our revenue in 2013 included two
 customers at 17% and 14%. Only a single customer comprised more
 than 10% of our revenue in 2012 at 23%. No other customer accounted
 for 10% or more of our sales in 2014, 2013 or 2012. Our five
 largest customers, other than those with more than 10 percent of
 revenues disclosed above, can change from year to year. These
 customers represented 22%, 22%, and 34% of total revenue in 2014,
 2013 and 2012, respectively. Revenues in this disclosure do not
 include distributor agents who predominately provide fulfillment
 services to end users. In such cases where known, that revenue is
 associated with the end user.

[0001193125-15-059743:notes:120]
As of December 31, 2014, long-lived assets, net totaled $74.8
 million, which includes $70.0 million held in the United States and
 $4.8 million held outside the United States. As of
 December 31, 2013, long-lived assets, net totaled $76.7
 million, which includes $71.2 million held in the United States and
 $5.5 million held outside the United States.


## us-gaap:UnrealizedGainLossOnInvestmentsTableTextBlock

[0001193125-15-059743:notes:121]
The following table presents the breakdown of investments with
 unrealized losses at December 31, 2014:

[0001193125-15-059743:notes:122]
| (In thousands) |  | Continuous Unrealized Loss Position for Less than 12 Months |  |  | Continuous Unrealized Loss Position for 12 Months or Greater |  |  | Total |  |
|  |  | Fair Value |  |  | Unrealized Losses |  |  | Fair Value |  |  | Unrealized Losses |  |  | Fair Value |  |  | Unrealized Losses |  |
| Deferred compensation plan assets |  | $ | 49 |  |  | $ | (3 | ) |  | $ | 278 |  |  | $ | (9 | ) |  | $ | 327 |  |  | $ | (12 | ) |
| Corporate bonds |  |  | 31,021 |  |  |  | (186 | ) |  |  | — |  |  |  | — |  |  |  | 31,021 |  |  |  | (186 | ) |
| Municipal fixed-rate bonds |  |  | 30,339 |  |  |  | (34 | ) |  |  | — |  |  |  | — |  |  |  | 30,339 |  |  |  | (34 | ) |
| Marketable equity securities |  |  | 4,824 |  |  |  | (478 | ) |  |  | 208 |  |  |  | (61 | ) |  |  | 5,032 |  |  |  | (539 | ) |
| Total |  | $ | 66,233 |  |  | $ | (701 | ) |  | $ | 486 |  |  | $ | (70 | ) |  | $ | 66,719 |  |  | $ | (771 | ) |

[0001193125-15-059743:notes:123]
The following table presents the breakdown of investments with
 unrealized losses at December 31, 2013:

[0001193125-15-059743:notes:124]
| (In thousands) |  | Continuous Unrealized Loss Position for Less than 12 Months |  |  | Continuous Unrealized Loss Position for 12 Months or Greater |  |  | Total |  |
|  |  | Fair Value |  |  | Unrealized Losses |  |  | Fair Value |  |  | Unrealized Losses |  |  | Fair Value |  |  | Unrealized Losses |  |
| Deferred compensation plan assets |  | $ | 48 |  |  | $ | (6 | ) |  | $ | 409 |  |  | $ | (18 | ) |  | $ | 457 |  |  | $ | (24 | ) |
| Corporate bonds |  |  | 20,697 |  |  |  | (45 | ) |  |  | — |  |  |  | — |  |  |  | 20,697 |  |  |  | (45 | ) |
| Municipal fixed-rate bonds |  |  | 13,733 |  |  |  | (54 | ) |  |  | — |  |  |  | — |  |  |  | 13,733 |  |  |  | (54 | ) |
| Marketable equity securities |  |  | 2,758 |  |  |  | (173 | ) |  |  | 31 |  |  |  | (4 | ) |  |  | 2,789 |  |  |  | (177 | ) |
| Total |  | $ | 37,236 |  |  | $ | (278 | ) |  | $ | 440 |  |  | $ | (22 | ) |  | $ | 37,676 |  |  | $ | (300 | ) |


## us-gaap:InventoryDisclosureTextBlock

[0001193125-15-059743:notes:125]
Note 6 – Inventory

[0001193125-15-059743:notes:126]
We establish reserves for estimated excess, obsolete, or
 unmarketable inventory equal to the difference between the cost of
 the inventory and the estimated fair value of the inventory based
 upon assumptions about future demand and market conditions. At
 December 31, 2014 and 2013, raw materials reserves totaled
 $16.9 million, and finished goods inventory reserves totaled $7.8
 million and $6.1 million, respectively.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001193125-15-059743:notes:127]
Note 16 – Related Party Transactions

[0001193125-15-059743:notes:128]
We employed the law firm of our director emeritus for legal
 services. All bills for services rendered by this firm were
 reviewed and approved by our Chief Financial Officer. We believe
 that the fees for such services are comparable to those charged by
 other firms for services rendered to us. The services of our
 director emeritus ended with his death on September 7, 2014.
 For the years ended 2014, 2013 and 2012, we incurred fees of $0.1
 million for these legal services.


## us-gaap:ScheduleOfEmployeeServiceShareBasedCompensationAllocationOfRecognizedPeriodCostsTextBlock

[0001193125-15-059743:notes:129]
The following table summarizes stock-based compensation expense
 related to stock options, RSUs and restricted stock for the years
 ended December 31, 2014, 2013 and 2012, which was recognized
 as follows:

[0001193125-15-059743:notes:130]
| (In thousands) |  | 2014 |  |  | 2013 |  |  | 2012 |  |
| Stock-based compensation expense included in cost of sales |  | $ | 479 |  |  | $ | 465 |  |  | $ | 422 |  |
| Selling, general and administrative expense |  |  | 4,185 |  |  |  | 4,443 |  |  |  | 4,351 |  |
| Research and development expense |  |  | 3,899 |  |  |  | 4,165 |  |  |  | 4,491 |  |
| Stock-based compensation expense included in operating expenses |  |  | 8,084 |  |  |  | 8,608 |  |  |  | 8,842 |  |
| Total stock-based compensation expense |  |  | 8,563 |  |  |  | 9,073 |  |  |  | 9,264 |  |
| Tax benefit for expense associated with non-qualified options |  |  | (1,157 | ) |  |  | (1,298 | ) |  |  | (1,234 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 7,406 |  |  | $ | 7,775 |  |  | $ | 8,030 |  |


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001193125-15-059743:notes:131]
Revenue Recognition

[0001193125-15-059743:notes:132]
Revenue is generally recognized when persuasive evidence of an
 arrangement exists, delivery has occurred, the product price is
 fixed or determinable, collection of the resulting receivable is
 reasonably assured, and product returns are reasonably estimable.
 For product sales, revenue is generally recognized upon shipment of
 the product to our customer in accordance with the title transfer
 terms of the sales agreement, generally FOB shipping point. In the
 case of consigned inventory, revenue is recognized when the end
 customer assumes ownership of the product. Contracts that contain
 multiple deliverables are evaluated to determine the units of
 accounting, and the consideration from the arrangement is allocated
 to each unit of accounting based on the relative selling price and
 corresponding terms of the contract. We use vendor-specific
 objective evidence of selling price. When this evidence is not
 available, we are generally not able to determine third-party
 evidence of selling price because of the extent of customization
 among competing products or services from other companies. In these
 instances, we use best estimates to allocate consideration to each
 respective unit of accounting. These estimates include analysis of
 respective bills of material and review and analysis of similar
 product and service offerings. We record revenue associated with
 installation services when respective contractual obligations are
 complete. In instances where customer acceptance is required,
 revenue is deferred until respective acceptance criteria have been
 met. Contracts that include both installation services and product
 sales are evaluated for revenue recognition in accordance with
 contract terms. As a result, installation services may be
 considered a separate deliverable or may be considered a combined
 single unit of accounting with the delivered product. Generally,
 either the purchaser, ADTRAN, or a third party can perform the
 installation of our products. Shipping fees are recorded as revenue
 and the related cost is included in cost of sales. Sales taxes
 invoiced to customers are included in revenues, and represent less
 than one percent of total revenues. The corresponding sales taxes
 paid are included in cost of goods sold. Value added taxes
 collected from customers in international jurisdictions are
 recorded in accrued expenses as a liability. Revenue is recorded
 net of discounts. Sales returns are accrued based on historical
 sales return experience, which we believe provides a reasonable
 estimate of future returns.

[0001193125-15-059743:notes:133]
A portion of Enterprise Networks products are sold to a
 non-exclusive distribution network of major technology distributors
 in the United States. These large organizations then distribute or
 provide fulfillment services to an extensive network of value-added
 resellers (VARs) and system integrators. VARs and system
 integrators may be affiliated with us as a channel partner, or they
 may purchase from the distributor in an unaffiliated fashion.
 Additionally, with certain limitations our distributors may return
 unused and unopened product for stock-balancing purposes when such
 returns are accompanied by offsetting orders for products of equal
 or greater value.

[0001193125-15-059743:notes:134]
We participate in cooperative advertising and market development
 programs with certain customers. We use these programs to reimburse
 customers for certain forms of advertising, and in general, to
 allow our customers credits up to a specified percentage of their
 net purchases. Our costs associated with these programs are
 estimated and included in marketing expenses in our consolidated
 statements of income. We also participate in rebate programs to
 provide sales incentives for certain products. Our costs associated
 with these programs are estimated and accrued at the time of sale,
 and are recorded as a reduction of sales in our consolidated
 statements of income.


## us-gaap:ScheduleOfNetFundedStatusTableTextBlock

[0001193125-15-059743:notes:135]
The pension benefit plan obligations and funded status at
 December 31, 2014 and 2013, are as follows:

[0001193125-15-059743:notes:136]
| (In thousands) |  | 2014 |  |  | 2013 |  |
| Change in projected benefit obligation: |  |  |  |  |  |  |  |  |
| Projected benefit obligation at beginning of period |  | $ | (23,354 | ) |  | $ | (21,181 | ) |
| Service cost |  |  | (1,189 | ) |  |  | (1,198 | ) |
| Interest cost |  |  | (836 | ) |  |  | (745 | ) |
| Actuarial gain (loss) |  |  | (8,166 | ) |  |  | 779 |  |
| Benefit payments |  |  | 2 |  |  |  | 1 |  |
| Effects of foreign currency exchange rate changes |  |  | 3,036 |  |  |  | (1,010 | ) |
| Projected benefit obligation at end of period |  | $ | (30,507 | ) |  | $ | (23,354 | ) |
| Change in plan assets: |  |  |  |  |  |  |  |  |
| Fair value of plan assets at beginning of period |  | $ | 20,773 |  |  | $ | 18,620 |  |
| Actual return on plan assets |  |  | 2,315 |  |  |  | 1,281 |  |
| Effects of foreign currency exchange rate changes |  |  | (2,750 | ) |  |  | 872 |  |
| Fair value of plan assets at end of period |  | $ | 20,338 |  |  | $ | 20,773 |  |
| Funded status at end of period |  | $ | (10,169 | ) |  | $ | (2,581 | ) |


## us-gaap:ScheduleOfShareBasedCompensationSharesAuthorizedUnderStockOptionPlansByExercisePriceRangeTextBlock

[0001193125-15-059743:notes:137]
The following table further describes our stock options outstanding
 as of December 31, 2014:

[0001193125-15-059743:notes:138]
|  |  | Options Outstanding |  |  | Options Exercisable |  |
| Range of Exercise Prices |  | Options Outstanding at 12/31/14 (In thousands) |  |  | Weighted Avg. Remaining Contractual Life in Years |  |  | Weighted Average Exercise Price |  |  | Options Exercisable at 12/31/14 (In thousands) |  |  | Weighted Average Exercise Price |  |
| $14.88 – 18.07 |  |  | 1,340 |  |  |  | 6.40 |  |  | $ | 16.36 |  |  |  | 895 |  |  | $ | 16.06 |  |
| $18.08 – 22.40 |  |  | 1,201 |  |  |  | 9.71 |  |  | $ | 19.02 |  |  |  | 28 |  |  | $ | 21.35 |  |
| $22.41 – 23.46 |  |  | 1,415 |  |  |  | 3.65 |  |  | $ | 23.12 |  |  |  | 1,415 |  |  | $ | 23.12 |  |
| $23.47 – 30.04 |  |  | 1,421 |  |  |  | 6.71 |  |  | $ | 25.47 |  |  |  | 671 |  |  | $ | 27.20 |  |
| $30.05 – 41.92 |  |  | 1,604 |  |  |  | 6.30 |  |  | $ | 31.94 |  |  |  | 1,388 |  |  | $ | 32.17 |  |
|  |  |  | 6,981 |  |  |  |  |  |  |  |  |  |  |  | 4,397 |  |  |  |  |  |


## us-gaap:ScheduleOfChangesInAccumulatedPostemploymentBenefitObligationsTableTextBlock

[0001193125-15-059743:notes:139]
The amounts recognized in accumulated other comprehensive income as
 of December 31, 2014 and 2013 are as follows:

[0001193125-15-059743:notes:140]
| (In thousands) |  | 2014 |  |  | 2013 |  |
| Net actuarial (gain) loss |  | $ | 7,943 |  |  | $ | 891 |  |


## us-gaap:ScheduleOfComponentsOfIncomeTaxExpenseBenefitTableTextBlock

[0001193125-15-059743:notes:141]
A summary of the components of the provision for income taxes for
 the years ended December 31, 2014, 2013 and 2012 is as
 follows:

[0001193125-15-059743:notes:142]
| (In thousands) |  | 2014 |  |  | 2013 |  |  | 2012 |  |
| Current |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  | $ | 7,626 |  |  | $ | 15,641 |  |  | $ | 26,225 |  |
| State |  |  | 599 |  |  |  | 2,041 |  |  |  | 3,766 |  |
| International |  |  | 12,587 |  |  |  | 1,437 |  |  |  | (504 | ) |
| Total Current |  |  | 20,812 |  |  |  | 19,119 |  |  |  | 29,487 |  |
| Deferred |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  |  | (1,083 | ) |  |  | (3,606 | ) |  |  | (3,395 | ) |
| State |  |  | (123 | ) |  |  | (412 | ) |  |  | (388 | ) |
| International |  |  | (4,320 | ) |  |  | (40 | ) |  |  | (2 | ) |
| Total Deferred |  |  | (5,526 | ) |  |  | (4,058 | ) |  |  | (3,785 | ) |
| Total Provision for Income Taxes |  | $ | 15,286 |  |  | $ | 15,061 |  |  | $ | 25,702 |  |


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001193125-15-059743:notes:143]
SCHEDULE II

[0001193125-15-059743:notes:144]
VALUATION AND QUALIFYING ACCOUNTS

[0001193125-15-059743:notes:145]
| Column A |  | Column B |  |  | Column C |  |  | Column D |  |  | Column E |  |  | Column F |  |
| (In thousands) |  | Balance at Beginning of Period |  |  | Assumed on Acquisition |  |  | Charged to Costs & Expenses |  |  | Deductions |  |  | Balance at End of Period |  |
| Year ended December 31, 2014 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for Doubtful Accounts |  | $ | 130 |  |  |  | — |  |  |  | 23 |  |  |  | 17 |  |  | $ | 136 |  |
| Inventory Reserve |  | $ | 22,993 |  |  |  | — |  |  |  | 2,549 |  |  |  | 860 |  |  | $ | 24,682 |  |
| Warranty Liability |  | $ | 8,977 |  |  |  | — |  |  |  | 3,103 |  |  |  | 3,665 |  |  | $ | 8,415 |  |
| Deferred Tax Asset Valuation Allowance |  | $ | 8,842 |  |  |  | — |  |  |  | 283 |  |  |  | 1,662 |  |  | $ | 7,463 |  |
| Year ended December 31, 2013 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for Doubtful Accounts |  | $ | 6 |  |  |  | — |  |  |  | 136 |  |  |  | 12 |  |  | $ | 130 |  |
| Inventory Reserve |  | $ | 11,957 |  |  |  | — |  |  |  | 11,457 |  |  |  | 421 |  |  | $ | 22,993 |  |
| Warranty Liability |  | $ | 9,653 |  |  |  | — |  |  |  | 4,051 |  |  |  | 4,727 |  |  | $ | 8,977 |  |
| Deferred Tax Asset Valuation Allowance |  | $ | 10,939 |  |  |  | — |  |  |  | (1,056 | ) |  |  | 1,041 |  |  | $ | 8,842 |  |
| Year ended December 31, 2012 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for Doubtful Accounts |  | $ | 8 |  |  |  | — |  |  |  | 38 |  |  |  | 40 |  |  | $ | 6 |  |
| Inventory Reserve |  | $ | 9,419 |  |  |  | — |  |  |  | 3,042 |  |  |  | 504 |  |  | $ | 11,957 |  |
| Warranty Liability |  | $ | 4,118 |  |  |  | 3,781 |  |  |  | 5,363 |  |  |  | 3,609 |  |  | $ | 9,653 |  |
| Deferred Tax Asset Valuation Allowance |  | $ | 7,585 |  |  |  | — |  |  |  | 3,594 |  |  |  | 240 |  |  | $ | 10,939 |  |


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0001193125-15-059743:notes:146]
This supplemental pro forma information does not purport to be
 indicative of what would have occurred had the acquisition of the
 NSN BBA business been completed on January 1, 2011, nor are
 they indicative of any future results.

[0001193125-15-059743:notes:147]
| (In thousands) (Unaudited) |  | 2012 |  |  | 2011 |  |
| Pro forma revenue |  | $ | 672,044 |  |  | $ | 913,485 |  |
| Pro forma pre-tax income |  | $ | 57,906 |  |  | $ | 169,162 |  |
| Weighted average exchange rate during the period (EURO/USD) |  | € | 1.00/$1.29 |  |  | € | 1.00/$1.38 |  |


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0001193125-15-059743:notes:148]
Cash and Cash Equivalents

[0001193125-15-059743:notes:149]
Cash and cash equivalents represent demand deposits, money market
 funds, and short-term investments classified as available-for-sale
 with original maturities of three months or less. We maintain
 depository investments with certain financial institutions.
 Although these depository investments may exceed government insured
 depository limits, we have evaluated the credit worthiness of these
 applicable financial institutions, and determined the risk of
 material financial loss due to the exposure of such credit risk to
 be minimal. As of December 31, 2014, $69.6 million of our cash and
 cash equivalents, primarily certain domestic money market funds and
 foreign depository accounts, were in excess of government provided
 insured depository limits.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001193125-15-059743:notes:150]
Note 5 – Derivative Instruments and Hedging
 Activities

[0001193125-15-059743:notes:151]
We have certain international customers who are billed in their
 local currency. Changes in the monetary exchange rates may
 adversely affect our results of operations and financial condition.
 When appropriate, we enter into various derivative transactions to
 enhance our ability to manage the volatility relating to these
 typical business exposures. We do not hold or issue derivative
 instruments for trading or other speculative purposes. Our
 derivative instruments are recorded in the Consolidated Balance
 Sheets at their fair values. Our derivative instruments do not
 qualify for hedge accounting, and accordingly, all changes in the
 fair value of the instruments are recognized as other income
 (expense) in the Consolidated Statements of Income. The maximum
 contractual period for our derivatives is currently less than
 twelve months. Our derivative instruments are not subject to master
 netting arrangements and are not offset in the Consolidated Balance
 Sheets.

[0001193125-15-059743:notes:152]
As of December 31, 2014, we had forward contracts outstanding
 with notional amounts totaling €12.5 million ($15.1
 million), which mature at various times throughout early 2015.

[0001193125-15-059743:notes:153]
The change in the fair values of our derivative instruments
 recorded in the Consolidated Statements of Income during the years
 ended December 31, 2014 and 2013 were as follows:

[0001193125-15-059743:notes:154]
| (In thousands) |  | Income Statement Location |  | 2014 |  |  | 2013 |  |
| Derivatives Not Designated as Hedging Instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Other income (expense) |  | $ | 1,852 |  |  | $ | 750 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001193125-15-059743:notes:155]
Note 4 – Investments

[0001193125-15-059743:notes:156]
As of December 31, 2014, corporate and municipal fixed-rate
 bonds had the following contractual maturities:

[0001193125-15-059743:notes:157]
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |
| Less than one year |  | $ | 20,413 |  |  | $ | 22,730 |  |
| One to two years |  |  | 67,732 |  |  |  | 69,680 |  |
| Two to three years |  |  | 23,116 |  |  |  | 34,160 |  |
| Three to five years |  |  | — |  |  |  | 1,217 |  |
| Total |  | $ | 111,261 |  |  | $ | 127,787 |  |

[0001193125-15-059743:notes:158]
Our investment policy provides limitations for issuer
 concentration, which limits, at the time of purchase, the
 concentration in any one issuer to 5% of the market value of our
 total investment portfolio.

[0001193125-15-059743:notes:159]
We review our investment portfolio for potential
 “other-than-temporary” declines in value on an
 individual investment basis. We assess, on a quarterly basis,
 significant declines in value which may be considered
 other-than-temporary and, if necessary, recognize and record the
 appropriate charge to write-down the carrying value of such
 investments. In making this assessment, we take into consideration
 qualitative and quantitative information, including but not limited
 to the following: the magnitude and duration of historical declines
 in market prices, credit rating activity, assessments of liquidity,
 public filings, and statements made by the issuer. We generally
 begin our identification of potential other-than-temporary
 impairments by reviewing any security with a fair value that has
 declined from its original or adjusted cost basis by 25% or more
 for six or more consecutive months. We then evaluate the individual
 security based on the previously identified factors to determine
 the amount of the write-down, if any. For each of the years ended
 December 31, 2014, 2013 and 2012, we recorded a charge of $0.1
 million, $25 thousand and $0.7 million, respectively, related to
 the other-than-temporary impairment of certain marketable equity
 securities and our deferred compensation plan assets.

[0001193125-15-059743:notes:160]
Realized gains and losses on sales of securities are computed under
 the specific identification method. The following table presents
 gross realized gains and losses related to our investments for the
 years ended December 31, 2014, 2013 and 2012:

[0001193125-15-059743:notes:161]
| Year Ended December 31, (In thousands) |  | 2014 |  |  | 2013 |  |  | 2012 |  |
| Gross realized gains |  | $ | 7,586 |  |  | $ | 8,932 |  |  | $ | 11,006 |  |
| Gross realized losses |  | $ | (308 | ) |  | $ | (318 | ) |  | $ | (1,456 | ) |

[0001193125-15-059743:notes:162]
The increase in unrealized losses during 2014, as reflected in the
 table above result from changes in market positions associated with
 our equity investment portfolio. At December 31, 2014, a total
 of 265 of our marketable equity securities were in an unrealized
 loss position.

[0001193125-15-059743:notes:163]
The fair value of our Level 2 securities is calculated using a
 weighted average market price for each security. Market prices are
 obtained from a variety of industry standard data providers,
 security master files from large financial institutions, and other
 third-party sources. These multiple market prices are used as
 inputs into a distribution-curve-based algorithm to determine the
 daily market value of each security.

[0001193125-15-059743:notes:164]
Our municipal variable rate demand notes have a structure that
 implies a standard expected market price. The frequent interest
 rate resets make it reasonable to expect the price to stay at par.
 These securities are priced at the expected market price.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0001193125-15-059743:notes:165]
Property, Plant and Equipment

[0001193125-15-059743:notes:166]
Property, plant and equipment, which is stated at cost, is
 depreciated using the straight-line method over the estimated
 useful lives of the assets. We depreciate building and land
 improvements from five to 39 years, office machinery and equipment
 from three to seven years, engineering machinery and equipment from
 three to seven years, and computer software from three to five
 years. Expenditures for repairs and maintenance are charged to
 expense as incurred. Betterments that materially prolong the lives
 of the assets are capitalized. See Note 7 of Notes to Consolidated
 Financial Statements for additional information.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001193125-15-059743:notes:167]
Note 15 – Summarized Quarterly Financial Data
 (Unaudited)

[0001193125-15-059743:notes:168]
The following table presents unaudited quarterly operating results
 for each of our last eight fiscal quarters. This information has
 been prepared on a basis consistent with our audited financial
 statements and includes all adjustments, consisting only of normal
 recurring adjustments, considered necessary for a fair presentation
 of the data.

[0001193125-15-059743:notes:169]
Unaudited Quarterly Operating Results

[0001193125-15-059743:notes:170]
(In thousands, except for per share amounts)

[0001193125-15-059743:notes:171]
| Three Months Ended |  | March 31, 2014 |  |  | June 30, 2014 |  |  | September 30, 2014 |  |  | December 31, 2014 |  |
| Net sales |  | $ | 147,004 |  |  | $ | 176,129 |  |  | $ | 162,892 |  |  | $ | 143,982 |  |
| Gross profit |  | $ | 77,790 |  |  | $ | 86,797 |  |  | $ | 78,257 |  |  | $ | 68,483 |  |
| Operating income |  | $ | 11,298 |  |  | $ | 19,339 |  |  | $ | 12,495 |  |  | $ | 3,979 |  |
| Net income |  | $ | 9,607 |  |  | $ | 14,395 |  |  | $ | 11,326 |  |  | $ | 9,292 |  |
| Earnings per common share |  | $ | 0.17 |  |  | $ | 0.26 |  |  | $ | 0.21 |  |  | $ | 0.17 |  |
| Earnings per common share assuming dilution (1) |  | $ | 0.17 |  |  | $ | 0.26 |  |  | $ | 0.21 |  |  | $ | 0.17 |  |

[0001193125-15-059743:notes:172]
| Three Months Ended |  | March 31, 2013 |  |  | June 30, 2013 |  |  | September 30, 2013 |  |  | December 31, 2013 |  |
| Net sales |  | $ | 143,013 |  |  | $ | 162,233 |  |  | $ | 177,404 |  |  | $ | 159,094 |  |
| Gross profit |  | $ | 69,677 |  |  | $ | 79,798 |  |  | $ | 82,547 |  |  | $ | 76,864 |  |
| Operating income |  | $ | 6,563 |  |  | $ | 14,053 |  |  | $ | 17,210 |  |  | $ | 10,639 |  |
| Net income |  | $ | 7,890 |  |  | $ | 9,859 |  |  | $ | 16,205 |  |  | $ | 11,840 |  |
| Earnings per common share |  | $ | 0.13 |  |  | $ | 0.17 |  |  | $ | 0.28 |  |  | $ | 0.21 |  |
| Earnings per common share assuming dilution (1) |  | $ | 0.13 |  |  | $ | 0.17 |  |  | $ | 0.28 |  |  | $ | 0.20 |  |

[0001193125-15-059743:notes:173]
| (1) | Assumes exercise of dilutive stock options calculated under the treasury stock method. |


## us-gaap:ScheduleOfDefinedBenefitPlanAmountsRecognizedInOtherComprehensiveIncomeLossTableTextBlock

[0001193125-15-059743:notes:174]
The components of net periodic pension cost and amounts recognized
 in other comprehensive income for the years ended December 31,
 2014 and 2013 and the period May 4, 2012 to December 31, 2012 are
 as follows:

[0001193125-15-059743:notes:175]
| (In thousands) |  | Year Ended December 31, 2014 |  |  | Year Ended December 31, 2013 |  |  | May 4, 2012 to December 31, 2012 |  |
| Net periodic benefit cost: |  |  |  |  |  |  |  |  |  |  |  |  |
| Service cost |  | $ | 1,189 |  |  | $ | 1,198 |  |  | $ | 766 |  |
| Interest cost |  |  | 836 |  |  |  | 745 |  |  |  | 494 |  |
| Expected return on plan assets |  |  | (1,086 | ) |  |  | (1,010 | ) |  |  | (674 | ) |
| Net periodic benefit cost |  |  | 939 |  |  |  | 933 |  |  |  | 586 |  |
| Other changes in plan assets and benefit obligations recognized in other comprehensive income: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net actuarial (gain) loss |  |  | 7,052 |  |  |  | (1,061 | ) |  |  | 1,952 |  |
| Total recognized in net periodic benefit cost and other comprehensive income |  | $ | 7,991 |  |  | $ | (128 | ) |  | $ | 2,538 |  |


## us-gaap:SummaryOfIncomeTaxContingenciesTextBlock

[0001193125-15-059743:notes:176]
The change in the unrecognized income tax benefits for the years
 ended December 31, 2014, 2013 and 2012 is reconciled
 below:

[0001193125-15-059743:notes:177]
| (In thousands) |  | 2014 |  |  | 2013 |  |  | 2012 |  |
| Balance at beginning of period |  | $ | 3,240 |  |  | $ | 2,926 |  |  | $ | 2,970 |  |
| Increases for tax position related to: |  |  |  |  |  |  |  |  |  |  |  |  |
| Prior years |  |  | — |  |  |  | 89 |  |  |  | 965 |  |
| Current year |  |  | 522 |  |  |  | 549 |  |  |  | 302 |  |
| Decreases for tax positions related to: |  |  |  |  |  |  |  |  |  |  |  |  |
| Prior years |  |  | — |  |  |  | — |  |  |  | (49 | ) |
| Settlements with taxing authorities |  |  | — |  |  |  | (141 | ) |  |  | (507 | ) |
| Expiration of applicable statute of limitations |  |  | (428 | ) |  |  | (183 | ) |  |  | (755 | ) |
| Balance at end of period |  | $ | 3,334 |  |  | $ | 3,240 |  |  | $ | 2,926 |  |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001193125-15-059743:notes:178]
Note 2 – Business Combinations

[0001193125-15-059743:notes:179]
On May 4, 2012, we acquired the NSN BBA business. This
 acquisition provides us with an established customer base in key
 markets and complementary, market-focused products and was
 accounted for as a business combination. We have included the
 financial results of the NSN BBA business in our consolidated
 financial statements since the date of acquisition. These revenues
 are included in the Carrier Networks division in the Broadband
 Access subcategory.

[0001193125-15-059743:notes:180]
Upon acquisition, we received a cash payment of $7.5 million from
 NSN and recorded a bargain purchase gain of $1.8 million, net of
 income taxes, subject to customary working capital adjustments
 between the parties as defined in the purchase agreement. During
 the fourth quarter of 2014, the parties settled final working
 capital items, and as a result, we recorded a $2.4 million gain in
 other income (expense), net. Additionally, $3.5 million is included
 in other receivables at December 31, 2014 for additional
 consideration due from NSN for settlement of the working capital
 items. The bargain purchase gain of $1.8 million represents the
 excess of the consideration exchanged over the fair value of the
 assets acquired and liabilities assumed. We have assessed the
 recognition and measurements of the assets acquired and liabilities
 assumed based on historical and pro forma data for future periods
 and have concluded that our valuation procedures and resulting
 measures were appropriate. The gain is included in the line item
 “Gain on bargain purchase of a business” in the 2012
 Consolidated Statements of Income.

[0001193125-15-059743:notes:181]
The allocation of the purchase price to the estimated fair value of
 the assets acquired and liabilities assumed at the acquisition date
 is as follows:

[0001193125-15-059743:notes:182]
| (In Thousands) |  |  |  |
| Other receivables |  | $ | 9,486 |  |
| Inventory |  |  | 21,068 |  |
| Property, plant and equipment |  |  | 5,035 |  |
| Accounts payable |  |  | (5,194 | ) |
| Unearned revenue |  |  | (18,203 | ) |
| Accrued expenses |  |  | (3,361 | ) |
| Accrued wages and benefits |  |  | (2,251 | ) |
| Deferred tax liability |  |  | (788 | ) |
| Non-current unearned revenue |  |  | (19,886 | ) |
| Net liabilities assumed |  |  | (14,094 | ) |
| Customer relationships |  |  | 5,162 |  |
| Developed technology |  |  | 3,176 |  |
| Other |  |  | 13 |  |
| Gain on bargain purchase of a business, net of tax |  |  | (1,753 | ) |
| Net consideration received from seller |  | $ | (7,496 | ) |

[0001193125-15-059743:notes:183]
The fair value of the customer relationships acquired was
 calculated using a discounted cash flow method (excess earnings)
 and is being amortized using a declining balance method derived
 from projected customer revenue over an average estimated useful
 life of 13 years. The fair value of the developed technology
 acquired was calculated using a discounted cash flow method (relief
 from royalty) and is being amortized using the straight-line method
 over an estimated useful life of five years.

[0001193125-15-059743:notes:184]
For the years ended December 31, 2014, 2013 and 2012, we
 incurred acquisition and integration related expenses and
 amortization of acquired intangibles of $2.5 million, $2.9 million,
 and $7.9 million, respectively, related to this acquisition.

[0001193125-15-059743:notes:185]
The following supplemental pro forma information presents the
 financial results of the combined entity for the years ended
 December 31, 2012 and 2011. The pro forma results of the
 acquired NSN BBA business for the period January 1, 2012 to
 May 4, 2012 and January 1, 2011 to December 31, 2011
 were not included in our consolidated financial results for the
 years ended December 31, 2012 or 2011. There were no material,
 non-recurring pro forma adjustments to the historical data.


## us-gaap:ConsolidationPolicyTextBlock

[0001193125-15-059743:notes:186]
Principles of Consolidation

[0001193125-15-059743:notes:187]
Our consolidated financial statements include ADTRAN and its wholly
 owned subsidiaries. All inter-company accounts and transactions
 have been eliminated in consolidation.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001193125-15-059743:notes:188]
Foreign Currency

[0001193125-15-059743:notes:189]
We record transactions denominated in foreign currencies on a
 monthly basis using exchange rates from throughout the year. Assets
 and liabilities denominated in foreign currencies are translated at
 the balance sheet dates using the closing rates of exchange between
 those foreign currencies and the functional currency with any
 transaction gains or losses reported in other income (expense). Our
 primary exposure to foreign currency exchange rate movements is
 with our German subsidiary, whose functional currency is the Euro,
 and our Australian subsidiary, whose functional currency is the
 Australian dollar. Adjustments resulting from translating financial
 statements of international subsidiaries are recorded as a
 component of accumulated other comprehensive income (loss).


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-15-059743:notes:190]
Note 10 – Income Taxes

[0001193125-15-059743:notes:191]
Income before provision for income taxes for international entities
 reflects income based on statutory transfer pricing agreements.
 This amount does not correlate to consolidated international
 revenues, many of which occur from our U.S. entity.

[0001193125-15-059743:notes:192]
Deferred income taxes on the balance sheet result from temporary
 differences between the amount of assets and liabilities recognized
 for financial reporting and tax purposes. The principal components
 of our current and non-current deferred taxes are as follows:

[0001193125-15-059743:notes:193]
| (In thousands) |  | 2014 |  |  | 2013 |  |
| Current deferred tax assets |  |  |  |  |  |  |  |  |
| Accounts receivable |  | $ | 53 |  |  | $ | 51 |  |
| Inventory |  |  | 10,405 |  |  |  | 9,877 |  |
| Accrued expenses |  |  | 6,637 |  |  |  | 7,155 |  |
| Total Current Deferred Tax Assets |  |  | 17,095 |  |  |  | 17,083 |  |
| Non-current deferred tax assets |  |  |  |  |  |  |  |  |
| Accrued expenses |  |  | 1,232 |  |  |  | 140 |  |
| Deferred compensation |  |  | 6,424 |  |  |  | 5,972 |  |
| Stock-based compensation |  |  | 5,832 |  |  |  | 5,331 |  |
| Uncertain tax positions related to state taxes and related interest |  |  | 1,176 |  |  |  | 1,107 |  |
| Pensions |  |  | 4,844 |  |  |  | 301 |  |
| Foreign losses |  |  | 3,547 |  |  |  | 5,702 |  |
| State losses and credit carry-forwards |  |  | 4,023 |  |  |  | 3,737 |  |
| Federal loss and research carry-forwards |  |  | 6,998 |  |  |  | 8,322 |  |
| Valuation allowance |  |  | (7,463 | ) |  |  | (8,842 | ) |
| Total Non-current Deferred Tax Assets |  |  | 26,613 |  |  |  | 21,770 |  |
| Total Deferred Tax Assets |  | $ | 43,708 |  |  | $ | 38,853 |  |
| Non-current deferred tax liabilities |  |  |  |  |  |  |  |  |
| Property, plant and equipment |  | $ | (3,632 | ) |  | $ | (5,499 | ) |
| Intellectual property |  |  | (711 | ) |  |  | (1,006 | ) |
| Investments |  |  | (4,576 | ) |  |  | (5,643 | ) |
| Total Non-current Deferred Tax Liabilities |  | $ | (8,919 | ) |  | $ | (12,148 | ) |
| Net Deferred Tax Assets |  | $ | 34,789 |  |  | $ | 26,705 |  |

[0001193125-15-059743:notes:194]
At December 31, 2014 and 2013, non-current deferred taxes
 related to our investments and our defined benefit pension plan,
 reflect deferred taxes on the net unrealized gains on
 available-for-sale investments and deferred taxes on unrealized
 losses in our pension plan. The net change in non-current deferred
 taxes associated with these items, a deferred tax benefit of $3.3
 million in 2014 and a deferred tax expense of $0.4 million in 2013,
 is recorded as an adjustment to other comprehensive income,
 presented in the Consolidated Statements of Comprehensive
 Income.

[0001193125-15-059743:notes:195]
Based upon our results of operations in 2014 and expected
 profitability in future years in a certain international
 jurisdiction, we concluded that it is more likely than not certain
 foreign deferred tax assets will be realized. A reversal of the
 valuation allowance on these deferred tax assets, which includes a
 change in estimate of the years beginning balance, resulted in a
 deferred income tax benefit totaling $4.6 million in 2014. As of
 December 31, 2014, the remaining valuation allowance primarily
 relates to deferred tax assets related to state credit
 carry-forwards from tax credits in excess of our annual tax
 liability to an individual state where we do not generate
 sufficient state income to offset the credit and net operating
 losses in foreign jurisdictions. We believe it is more likely than
 not that we will not realize the full benefits of the deferred tax
 assets arising from these losses and credits, and accordingly, we
 have provided a valuation allowance against these deferred tax
 assets. The deferred tax assets for foreign and domestic
 carry-forwards, unamortized research and development costs, and
 state credit carry-forwards of $15.5 million will expire between
 2015 and 2030. The loss carry-forwards were acquired through
 acquisitions in 2009 and 2011. We will continue to assess the
 realization of our deferred tax assets and related valuations
 allowances. We do not provide for U.S. income tax on undistributed
 earnings of our foreign operations, whose earnings are intended to
 be permanently reinvested. These earnings are not required to
 service debt or fund our U.S. operations. It is impracticable to
 determine the amount of any unrecognized deferred tax liability for
 temporary differences related to investments in foreign
 subsidiaries.

[0001193125-15-059743:notes:196]
During 2014, 2013 and 2012, we recorded an income tax benefit of
 $0.1 million, $0.2 million and $1.9 million, respectively, as an
 adjustment to equity. This deduction is calculated on the
 difference between the exercise price of stock option exercises and
 the market price of the underlying common stock upon exercise.

[0001193125-15-059743:notes:197]
As of December 31, 2014, 2013, and 2012, our total liability
 for unrecognized tax benefits was $3.3 million, $3.2 million, and
 $2.9 million, respectively, of which $2.6 million, $2.5 million,
 and $2.2 million, respectively, would reduce our effective tax rate
 if we were successful in upholding all of the uncertain positions
 and recognized the amounts recorded. We classify interest and
 penalties recognized on the liability for unrecognized tax benefits
 as income tax expense. As of December 31, 2014, 2013 and 2012,
 the balances of accrued interest and penalties were $1.0 million,
 $1.0 million and $0.8 million, respectively.

[0001193125-15-059743:notes:198]
We do not anticipate a single tax position generating a significant
 increase or decrease in our liability for unrecognized tax benefits
 within 12 months of this reporting date. We file income tax returns
 in the U.S. federal and various state jurisdictions and several
 foreign jurisdictions. We are currently under audit by the Internal
 Revenue Service. Generally, we are not subject to changes in income
 taxes by any taxing jurisdiction for the years prior to 2011.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001193125-15-059743:notes:199]
Note 1 – Nature of Business and Summary of Significant
 Accounting Policies

[0001193125-15-059743:notes:200]
ADTRAN, Inc. is a leading global provider of networking and
 communications equipment. Our solutions enable voice, data, video
 and Internet communications across a variety of network
 infrastructures. These solutions are deployed by some of the
 world’s largest service providers, distributed enterprises
 and small and medium-sized businesses, public and private
 enterprises, and millions of individual users worldwide.

[0001193125-15-059743:notes:201]
Changes in Classifications

[0001193125-15-059743:notes:202]
We corrected immaterial misclassifications between the operating
 and investing sections of our consolidated statements of cash flows
 and adjusted our 2012 cash flows in these categories by $0.2
 million, in order to be consistent with the 2014 and 2013
 presentation.

[0001193125-15-059743:notes:203]
Additionally, changes in classifications have been made to the
 prior period balances in other comprehensive income to conform to
 the current period’s presentation as a result of our adoption
 of Accounting Standards Update No. 2013-02, Reporting of
 Amounts Reclassified Out of Accumulated Comprehensive Income.

[0001193125-15-059743:notes:204]
Out of Period Adjustment

[0001193125-15-059743:notes:205]
During the year ended December 31, 2013, we identified two
 adjustments in the acquired NSN (formerly Nokia Siemens Networks)
 Broadband Access business (NSN BBA business) relating to customer
 payment discounts for one customer, and recoverable VAT taxes on
 certain vendor freight invoices that should have been recorded in
 prior periods. These adjustments resulted from a $0.4 million
 understatement of net income in 2012. We evaluated the impact of
 the adjustments on the results of our previously issued financial
 statements for the prior period affected and concluded that the
 impact was not material. We also evaluated the impact of the
 cumulative effect of the adjustments in the current year and
 concluded that the impact was not material to our results for the
 year 2013. Accordingly, during the year ended December 31,
 2013 we recorded an out of period adjustment to correct these
 issues.

[0001193125-15-059743:notes:206]
Use of Estimates

[0001193125-15-059743:notes:207]
The preparation of financial statements in conformity with
 accounting principles generally accepted in the United States of
 America requires management to make estimates and assumptions that
 affect the reported amounts of assets and liabilities, the
 disclosure of contingent assets and liabilities at the date of the
 financial statements, and the reported amounts of revenue and
 expense during the reporting period. Our more significant estimates
 include the obsolete and excess inventory reserves, warranty
 reserves, customer rebates, determination of the deferred revenue
 components of multiple element sales agreements, estimated costs to
 complete obligations associated with deferred revenues, estimated
 income tax provision and income tax contingencies, the fair value
 of stock-based compensation, impairment of goodwill, valuation and
 estimated lives of intangible assets, estimated pension liability,
 fair value of investments, and the evaluation of
 other-than-temporary declines in the value of investments. Actual
 amounts could differ significantly from these estimates.

[0001193125-15-059743:notes:208]
Cash and cash equivalents represent demand deposits, money market
 funds, and short-term investments classified as available-for-sale
 with original maturities of three months or less. We maintain
 depository investments with certain financial institutions.
 Although these depository investments may exceed government insured
 depository limits, we have evaluated the credit worthiness of these
 applicable financial institutions, and determined the risk of
 material financial loss due to the exposure of such credit risk to
 be minimal. As of December 31, 2014, $69.6 million of our cash
 and cash equivalents, primarily certain domestic money market funds
 and foreign depository accounts, were in excess of government
 provided insured depository limits.

[0001193125-15-059743:notes:209]
Financial Instruments

[0001193125-15-059743:notes:210]
The carrying amounts reported in the consolidated balance sheets
 for cash and cash equivalents, accounts receivable, and accounts
 payable approximate fair value due to the immediate or short-term
 maturity of these financial instruments. The carrying amount
 reported for bonds payable was $30.0 million, compared to an
 estimated fair value of $29.7 million, based on a debt security
 with a comparable interest rate and maturity and a
 Standard & Poor’s credit rating of AAA.

[0001193125-15-059743:notes:211]
Investments with contractual maturities beyond one year, such as
 our municipal variable rate demand notes, may be classified as
 short-term based on their highly liquid nature and because such
 marketable securities represent the investment of cash that is
 available for current operations. Despite the long-term nature of
 their stated contractual maturities, we routinely buy and sell
 these securities and we believe we have the ability to quickly sell
 them to the remarketing agent, tender agent, or issuer at par value
 plus accrued interest in the event we decide to liquidate our
 investment in a particular variable rate demand note. All income
 generated from these investments was recorded as interest income.
 We have not been required to record any losses relating to
 municipal variable rate demand notes.

[0001193125-15-059743:notes:212]
Long-term investments represent a restricted certificate of deposit
 held at cost, municipal fixed-rate bonds, corporate bonds, deferred
 compensation plan assets, marketable equity securities, and other
 equity investments. Marketable equity securities are reported at
 fair value as determined by the most recently traded price of the
 securities at the balance sheet date, although the securities may
 not be readily marketable due to the size of the available market.
 Unrealized gains and losses, net of tax, are reported as a separate
 component of stockholders’ equity. Realized gains and losses
 on sales of securities are computed under the specific
 identification method and are included in current income. We
 periodically review our investment portfolio for investments
 considered to have sustained an other-than-temporary decline in
 value. Impairment charges for other-than-temporary declines in
 value are recorded as realized losses in the accompanying
 consolidated statements of income. All of our investments at
 December 31, 2014 and 2013 are classified as
 available-for-sale securities. See Note 4 of Notes to Consolidated
 Financial Statements for additional information.

[0001193125-15-059743:notes:213]
Other Receivables

[0001193125-15-059743:notes:214]
Other receivables are comprised primarily of amounts due from
 subcontract manufacturers for product component transfers, accrued
 interest on investments and on a restricted certificate of deposit,
 amounts due from various jurisdictions for value-added tax, and
 amounts due from employee stock option exercises. At
 December 31, 2014 and 2013, other receivables also included a
 receivable due from NSN related to working capital items settled
 during the fourth quarter of 2014 and collected in January
 2015.

[0001193125-15-059743:notes:215]
Liability for Warranty

[0001193125-15-059743:notes:216]
Our products generally include warranties of 90 days to ten years
 for product defects. We accrue for warranty returns at the time
 revenue is recognized based on our estimate of the cost to repair
 or replace the defective products. We engage in extensive product
 quality programs and processes, including actively monitoring and
 evaluating the quality of our component suppliers. Our products
 continue to become more complex in both size and functionality as
 many of our product offerings migrate from line card applications
 to systems products. The increasing complexity of our products will
 cause warranty incidences, when they arise, to be more costly. Our
 estimates regarding future warranty obligations may change due to
 product failure rates, material usage, and other rework costs
 incurred in correcting a product failure. In addition, from time to
 time, specific warranty accruals may be recorded if unforeseen
 problems arise. Should our actual experience relative to these
 factors be worse than our estimates, we will be required to record
 additional warranty expense. Alternatively, if we provide for more
 reserves than we require, we will reverse a portion of such
 provisions in future periods. The liability for warranty
 obligations totaled $8.4 million and $9.0 million at
 December 31, 2014 and 2013, respectively. These liabilities
 are included in accrued expenses in the accompanying consolidated
 balance sheets.

[0001193125-15-059743:notes:217]
A summary of warranty expense and write-off activity for the years
 ended December 31, 2014, 2013 and 2012 is as follows:

[0001193125-15-059743:notes:218]
| Year Ended December 31, |  | 2014 |  |  | 2013 |  |  | 2012 |  |
| (In thousands) |  |  |  |  |  |  |  |  |  |
| Balance at beginning of period |  | $ | 8,977 |  |  | $ | 9,653 |  |  | $ | 4,118 |  |
| Plus: Amounts charged to cost and expenses |  |  | 3,103 |  |  |  | 4,051 |  |  |  | 5,363 |  |
| Amounts assumed on acquisition |  |  | — |  |  |  | — |  |  |  | 3,781 |  |
| Less: Deductions |  |  | (3,665 | ) |  |  | (4,727 | ) |  |  | (3,609 | ) |
| Balance at end of period |  | $ | 8,415 |  |  | $ | 8,977 |  |  | $ | 9,653 |  |

[0001193125-15-059743:notes:219]
Pension Benefit Plan Obligations

[0001193125-15-059743:notes:220]
We maintain a defined benefit pension plan covering employees in
 certain foreign countries. Pension benefit plan obligations are
 based on various assumptions used by our actuaries in calculating
 these amounts. These assumptions include discount rates,
 compensation rate increases, expected return on plan assets,
 retirement rates and mortality rates. Actual results that differ
 from the assumptions and changes in assumptions could affect future
 expenses and obligations.

[0001193125-15-059743:notes:221]
Impairment of Long-Lived Assets

[0001193125-15-059743:notes:222]
We review long-lived assets used in operations for impairment
 whenever events or changes in circumstances indicate that the
 carrying amount of an asset may not be recoverable and the
 undiscounted cash flows estimated to be generated by the asset are
 less than the asset’s carrying value. An impairment loss
 would be recognized in the amount by which the recorded value of
 the asset exceeds the fair value of the asset, measured by the
 quoted market price of an asset or an estimate based on the best
 information available in the circumstances. There were no
 impairment losses recognized during 2014, 2013 or 2012.

[0001193125-15-059743:notes:223]
Goodwill and Purchased Intangible Assets

[0001193125-15-059743:notes:224]
We evaluate the carrying value of goodwill during the fourth
 quarter of each year and between annual evaluations if events occur
 or circumstances change that would more likely than not reduce the
 fair value of the reporting unit below its carrying amount. When
 evaluating whether goodwill is impaired, we first assess
 qualitative factors to determine whether it is necessary to perform
 the two-step quantitative goodwill impairment test. If we determine
 that the two-step quantitative test is necessary, then we compare
 the fair value of the reporting unit to which the goodwill is
 assigned to the reporting unit’s carrying amount, including
 goodwill. If the carrying amount of the reporting unit exceeds its
 fair value, then the amount of the impairment loss is measured.
 There were no impairment losses recognized during 2014, 2013 or
 2012. Purchased intangible assets with finite lives are carried at
 cost, less accumulated amortization. Amortization is recorded over
 the estimated useful lives of the respective assets, which is 2.5
 to 14 years.

[0001193125-15-059743:notes:225]
Research and Development Costs

[0001193125-15-059743:notes:226]
Research and development costs include compensation for engineers
 and support personnel, outside contracted services, depreciation
 and material costs associated with new product development, the
 enhancement of current products, and product cost reductions. We
 continually evaluate new product opportunities and engage in
 intensive research and product development efforts. Research and
 development costs totaled $132.3 million, $131.1 million and $126.0
 million for the years ended December 31, 2014, 2013 and 2012,
 respectively.

[0001193125-15-059743:notes:227]
Unearned Revenue

[0001193125-15-059743:notes:228]
Unearned revenue primarily represents customer billings on our
 maintenance service programs and unearned revenues relating to
 multiple element contracts where we still have contractual
 obligations to our customers. We currently offer maintenance
 contracts ranging from one to five years, primarily on Enterprise
 Networks Division products sold through distribution channels.
 Revenue attributable to maintenance contracts is recognized on a
 straight-line basis over the related contract term. In addition, we
 provide software maintenance and a variety of hardware maintenance
 services to Carrier Networks Division customers under contracts
 with terms up to ten years.

[0001193125-15-059743:notes:229]
Other Income (Expense), Net

[0001193125-15-059743:notes:230]
Other income (expense), net, is comprised primarily of
 miscellaneous income and expense, gains and losses on foreign
 currency transactions, and investment account management fees. For
 the year ended December 31, 2014, other income (expense), net
 included a $2.4 million gain related to the settlement of working
 capital items from an acquisition transaction that closed in
 2012.

[0001193125-15-059743:notes:231]
Dividends

[0001193125-15-059743:notes:232]
The Board of Directors presently anticipates that it will declare a
 regular quarterly dividend as long as the current tax treatment of
 dividends exists and adequate levels of liquidity are maintained.
 During the years ended December 31, 2014, 2013 and 2012, we
 paid $19.9 million, $21.4 million and $22.8 million, respectively,
 in shareholder dividends. On January 20, 2015, the Board of
 Directors declared a quarterly cash dividend of $0.09 per common
 share to be paid to shareholders of record at the close of business
 on February 5, 2015. The ex-dividend date was February 3,
 2015 and the payment date was February 19, 2015. The quarterly
 dividend payment was $4.8 million.

[0001193125-15-059743:notes:233]
Business Combinations

[0001193125-15-059743:notes:234]
We use the acquisition method to account for business combinations.
 Under the acquisition method of accounting, we recognize the assets
 acquired and liabilities assumed at their fair value on the
 acquisition date. Goodwill is measured as the excess of the
 consideration transferred over the net assets acquired. Costs
 incurred to complete the business combination, such as legal,
 accounting or other professional fees, are charged to general and
 administrative expenses as they are incurred.

[0001193125-15-059743:notes:235]
Recently Issued Accounting Standards

[0001193125-15-059743:notes:236]
In May 2014, the Financial Accounting Standards Board issued
 Accounting Standards Update No. 2014-09, Revenue from Contracts with
 Customers (ASU
 2014-09), which supersedes the revenue recognition requirements in
 Topic 605, Revenue Recognition,
 including most industry-specific revenue recognition guidance
 throughout the Industry Topics of the Codification. The core
 principle of ASU 2014-09 is to recognize revenues when promised
 goods or services are transferred to customers in an amount that
 reflects the consideration that is expected to be received for
 those goods or services. ASU 2014-09 is effective for annual
 reporting periods beginning after December 15, 2016, including
 interim periods within that reporting period, and early application
 is not permitted. ASU 2014-09 allows for either full retrospective
 or modified retrospective adoption. We are currently evaluating the
 transition method that will be elected and the impact that the
 adoption of ASU 2014-09 will have on our financial position,
 results of operations and cash flows.


## us-gaap:ScheduleOfFutureMinimumRentalPaymentsForOperatingLeasesTableTextBlock

[0001193125-15-059743:notes:237]
As of December 31, 2014, future minimum rental payments under
 non-cancelable operating leases with original maturities of greater
 than 12 months are approximately as follows:

[0001193125-15-059743:notes:238]
| (In thousands) |  |
| 2015 |  | $ | 4,648 |  |
| 2016 |  |  | 3,897 |  |
| 2017 |  |  | 3,239 |  |
| 2018 |  |  | 1,564 |  |
| Thereafter |  |  | 5,340 |  |
| Total |  | $ | 18,688 |  |


## us-gaap:ScheduleOfQuarterlyFinancialInformationTableTextBlock

[0001193125-15-059743:notes:239]
The following table presents unaudited quarterly operating results
 for each of our last eight fiscal quarters.


## us-gaap:SubsequentEventsTextBlock

[0001193125-15-059743:notes:240]
Note 17 – Subsequent Events

[0001193125-15-059743:notes:241]
On January 20, 2015, the Board declared a quarterly cash
 dividend of $0.09 per common share to be paid to shareholders of
 record at the close of business on February 5, 2015. The
 quarterly dividend payment was $4.8 million and was paid on
 February 19, 2015. In July 2003, our Board of Directors
 elected to begin declaring quarterly dividends on our common stock
 considering the tax treatment of dividends and adequate levels of
 Company liquidity.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-15-059743:notes:242]
Note 3 – Stock Incentive Plans

[0001193125-15-059743:notes:243]
Stock Incentive Program Descriptions

[0001193125-15-059743:notes:244]
Our Board of Directors adopted the 1996 Employee Incentive Stock
 Option Plan (1996 Plan) effective February 14, 1996, as
 amended, under which 17.0 million shares of common stock were
 authorized for issuance to certain employees and officers through
 incentive stock options and non-qualified stock options. Options
 granted under the 1996 Plan typically become exercisable beginning
 after one year of continued employment, normally pursuant to a four
 or five-year vesting schedule beginning on the first anniversary of
 the grant date, and have a ten-year contractual term. The 1996 Plan
 expired February 14, 2006, and all options outstanding under
 the 1996 Plan at December 31, 2014 expire during 2015.

[0001193125-15-059743:notes:245]
On January 23, 2006, the Board of Directors adopted the 2006
 Employee Stock Incentive Plan (2006 Plan), which authorizes
 13.0 million shares of common stock for issuance to certain
 employees and officers through incentive stock options and
 non-qualified stock options, stock appreciation rights, restricted
 stock and restricted stock units. The 2006 Plan was adopted by
 stockholder approval at our annual meeting of stockholders held on
 May 9, 2006. Options granted under the 2006 Plan typically
 become exercisable beginning after one year of continued
 employment, normally pursuant to a four-year vesting schedule
 beginning on the first anniversary of the grant date, and have a
 ten-year contractual term. Expiration dates of options outstanding
 at December 31, 2014 under the 2006 Plan range from 2016 to
 2024.

[0001193125-15-059743:notes:246]
Our stockholders approved the 2010 Directors Stock Plan (2010
 Directors Plan) on May 5, 2010, under which 0.5 million
 shares of common stock have been reserved. This plan replaces the
 2005 Directors Stock Option Plan. The 2010 Directors Plan provides
 that the Company may issue stock options, restricted stock and
 restricted stock units to our non-employee directors. Stock awards
 issued under the 2010 Directors Plan normally become vested in full
 on the first anniversary of the grant date. Options issued under
 the 2010 Directors Plan have a ten-year contractual term. We also
 currently have options outstanding under the 2005 Directors Stock
 Option Plan. Expiration dates of options outstanding under both
 plans at December 31, 2014 range from 2015 to 2019.

[0001193125-15-059743:notes:247]
All of the options above were issued at exercise prices that
 approximate fair market value at the date of grant. At
 December 31, 2014, 5.2 million options were available for
 grant under the shareholder approved plans.

[0001193125-15-059743:notes:248]
The aggregate intrinsic values in the table above represent the
 total pre-tax intrinsic value (the difference between
 ADTRAN’s closing stock price on the last trading day of 2014
 and the exercise price, multiplied by the number of in-the-money
 options) that would have been received by the option holders had
 all option holders exercised their options on December 31,
 2014. The amount of aggregate intrinsic value will change based on
 the fair market value of ADTRAN’s stock.

[0001193125-15-059743:notes:249]
The total pre-tax intrinsic value of options exercised during 2014,
 2013 and 2012 was $0.7 million, $1.1 million and $4.5 million,
 respectively. The fair value of options fully vesting during 2014,
 2013 and 2012 was $7.7 million.

[0001193125-15-059743:notes:250]
Restricted Stock Program

[0001193125-15-059743:notes:251]
On November 6, 2008, the Compensation Committee of the Board
 of Directors approved the Performance Shares Agreement under the
 2006 Plan which sets forth the terms and conditions of awards of
 performance-based restricted stock units (RSUs). Of the
 13.0 million shares of common stock authorized for issuance
 under the 2006 Plan, up to 3.0 million shares of common stock
 may be granted to certain employees and officers for awards other
 than stock options, including RSUs. The number of shares of common
 stock earned by a recipient pursuant to the RSUs is subject to a
 market condition based on ADTRAN’s relative total shareholder
 return against all companies in the NASDAQ Telecommunications Index
 at the end of a three-year performance period. Depending on the
 relative total shareholder return over the performance period, the
 recipient may earn from 0% to 150% of the shares underlying the
 RSUs, with the shares earned distributed upon the vesting of the
 RSUs at the end of the three-year performance period. The fair
 value of the award is based on the market price of our common stock
 on the date of grant, adjusted for the expected outcome of the
 impact of market conditions using a Monte Carlo Simulation
 valuation method. A portion of the granted RSUs also vest and the
 underlying shares become deliverable upon the death or disability
 of the recipient or upon a change of control of ADTRAN, as defined
 by the 2006 Plan. The recipients of the RSUs receive dividend
 credits based on the shares of common stock underlying the RSUs.
 The dividend credits are vested and earned in the same manner as
 the RSUs and are paid in cash upon the issuance of common stock for
 the RSUs.

[0001193125-15-059743:notes:252]
The following table is a summary of our RSUs and restricted stock
 outstanding as of December 31, 2013 and 2014 and the changes
 that occurred during 2014:

[0001193125-15-059743:notes:253]
| (In thousands, except per share amounts) |  | Number of shares |  |  | Weighted Average Grant Date Fair Value |  |
| Unvested RSUs and restricted stock outstanding, December 31, 2013 |  |  | 95 |  |  | $ | 28.38 |  |
| RSUs and restricted stock granted |  |  | 50 |  |  | $ | 21.97 |  |
| RSUs and restricted stock vested |  |  | (24 | ) |  | $ | 34.56 |  |
| Adjustments to shares granted due to shares earned at vesting |  |  | (17 | ) |  | $ | 38.73 |  |
| Unvested RSUs and restricted stock outstanding, December 31, 2014 |  |  | 104 |  |  | $ | 22.81 |  |

[0001193125-15-059743:notes:254]
At December 31, 2014, total compensation cost related to the
 non-vested portion of RSUs and restricted stock not yet recognized
 was approximately $1.6 million, which is expected to be recognized
 over an average remaining recognition period of 1.9 years.

[0001193125-15-059743:notes:255]
Valuation and Expense Information

[0001193125-15-059743:notes:256]
We use the Black-Scholes option pricing model (Black-Scholes Model)
 for the purpose of determining the estimated fair value of stock
 option awards on the date of grant. The Black-Scholes Model
 requires the input of certain assumptions that involve judgment.
 Because our stock options have characteristics significantly
 different from those of traded options, and because changes in the
 input assumptions can materially affect the fair value estimate,
 existing models may not provide reliable measures of fair value of
 our stock options. We use a Monte Carlo Simulation valuation method
 to value our performance-based RSUs. The fair value of restricted
 stock issued is equal to the closing price of our stock on the date
 of grant. We will continue to assess the assumptions and
 methodologies used to calculate the estimated fair value of
 stock-based compensation. If circumstances change, and additional
 data becomes available over time, we may change our assumptions and
 methodologies, which may materially impact our fair value
 determination.

[0001193125-15-059743:notes:257]
At December 31, 2014, total compensation cost related to
 non-vested stock options not yet recognized was approximately $16.0
 million, which is expected to be recognized over an average
 remaining recognition period of 2.9 years.

[0001193125-15-059743:notes:258]
The stock option pricing model requires the use of several
 assumptions that impact the fair value estimate. These variables
 include, but are not limited to, the volatility of our stock price
 and employee exercise behaviors. There were no material changes
 made during 2014 to the methodology used to determine our
 assumptions.

[0001193125-15-059743:notes:259]
The weighted-average estimated fair value of stock options granted
 to employees during the years ended December 31, 2014, 2013
 and 2012 was $6.31 per share, $8.35 per share and $5.60 per share,
 respectively, with the following weighted-average assumptions:

[0001193125-15-059743:notes:260]
|  |  | 2014 |  |  | 2013 |  |  | 2012 |  |
| Expected volatility |  |  | 39.05 | % |  |  | 39.92 | % |  |  | 39.46 | % |
| Risk-free interest rate |  |  | 1.79 | % |  |  | 1.71 | % |  |  | 0.96 | % |
| Expected dividend yield |  |  | 1.90 | % |  |  | 1.52 | % |  |  | 2.05 | % |
| Expected life (in years) |  |  | 6.33 |  |  |  | 6.36 |  |  |  | 6.18 |  |

[0001193125-15-059743:notes:261]
We based our estimate of expected volatility for the years ended
 December 31, 2014, 2013 and 2012 on the sequential historical
 daily trading data of our common stock for a period equal to the
 expected life of the options granted. The selection of the
 historical volatility method was based on available data indicating
 our historical volatility is as equally representative of our
 future stock price trends as is our implied volatility. We have no
 reason to believe the future volatility of our stock price is
 likely to differ from its past volatility.

[0001193125-15-059743:notes:262]
The risk-free interest rate assumption is based upon implied yields
 of U.S. Treasury zero-coupon bonds on the date of grant having a
 remaining term equal to the expected life of the options granted.
 The dividend yield is based on our historical and expected dividend
 payouts.

[0001193125-15-059743:notes:263]
The expected life of our stock options is based upon historical
 exercise and cancellation activity of our previous stock-based
 grants with a ten-year contractual term.

[0001193125-15-059743:notes:264]
The RSU pricing model also requires the use of several significant
 assumptions that impact the fair value estimate. The estimated fair
 value of the RSUs granted to employees during the years ended
 December 31, 2014, 2013 and 2012 was $22.11 per share, $27.72
 per share and $19.46 per share, respectively, with the following
 assumptions:

[0001193125-15-059743:notes:265]
|  |  | 2014 |  |  | 2013 |  |  | 2012 |  |
| Expected volatility |  |  | 36.40 | % |  |  | 38.83 | % |  |  | 37.75 | % |
| Risk-free interest rate |  |  | 0.96 | % |  |  | 0.61 | % |  |  | 0.38 | % |
| Expected dividend yield |  |  | 1.89 | % |  |  | 1.52 | % |  |  | 2.12 | % |

[0001193125-15-059743:notes:266]
Stock-based compensation expense recognized in our Consolidated
 Statements of Income for the years ended December 31, 2014,
 2013 and 2012 is based on RSUs and options ultimately expected to
 vest, and has been reduced for estimated forfeitures. Estimates for
 forfeiture rates are based upon historical experience and are
 evaluated quarterly. We expect our forfeiture rate for stock option
 awards to be approximately 3.1% annually. We estimated a 0%
 forfeiture rate for our RSUs and restricted stock due to the
 limited number of recipients and historical experience for these
 awards.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001193125-15-059743:notes:267]
Note 11 – Employee Benefit Plans

[0001193125-15-059743:notes:268]
Pension Benefit Plan

[0001193125-15-059743:notes:269]
We maintain a defined benefit pension plan covering employees in
 certain foreign countries.

[0001193125-15-059743:notes:270]
The accumulated benefit obligation was $29.2 million and $22.9
 million at December 31, 2014 and 2013, respectively. The
 increase in the accumulated benefit obligation and actuarial loss
 is primarily attributable to a decrease in the discount rate used
 in 2014 to determine the accumulated benefit obligation.

[0001193125-15-059743:notes:271]
The net amounts recognized in the balance sheet for the unfunded
 pension liability as of December 31, 2014 and 2013 are as
 follows:

[0001193125-15-059743:notes:272]
| (In thousands) |  | 2014 |  |  | 2013 |  |
| Current liability |  | $ | — |  |  | $ | — |  |
| Non-current liability |  |  | (10,169 | ) |  |  | (2,581 | ) |
| Total |  | $ | (10,169 | ) |  | $ | (2,581 | ) |

[0001193125-15-059743:notes:273]
The components of net periodic pension cost and amounts recognized
 in other comprehensive income for the years ended December 31,
 2014 and 2013 and the period May 4, 2012 to December 31, 2012
 are as follows:

[0001193125-15-059743:notes:274]
The defined benefit pension plan is accounted for on an actuarial
 basis, which requires the selection of various assumptions,
 including an expected rate of return on plan assets and a discount
 rate. The expected return on our German plan assets that is
 utilized in determining the benefit obligation and net periodic
 benefit cost is derived from periodic studies, which include a
 review of asset allocation strategies, anticipated future long-term
 performance of individual asset classes, risks using standard
 deviations and correlations of returns among the asset classes that
 comprise the plans’ asset mix. While the studies give
 appropriate consideration to recent plan performance and historical
 returns, the assumptions are primarily long-term, prospective rates
 of return.

[0001193125-15-059743:notes:275]
Another key assumption in determining net pension expense is the
 assumed discount rate to be used to discount plan obligations. The
 discount rate has been derived from the returns of high-quality,
 corporate bonds denominated in Euro currency with durations close
 to the duration of our pension obligations.

[0001193125-15-059743:notes:276]
The weighted-average assumptions that were used to determine the
 benefit obligation at December 31, 2014 and 2013:

[0001193125-15-059743:notes:277]
|  |  | 2014 |  |  | 2013 |  |
| Discount rates |  |  | 2.20 | % |  |  | 3.70 | % |
| Rate of compensation increase |  |  | 2.25 | % |  |  | 2.25 | % |

[0001193125-15-059743:notes:278]
Actuarial gains and losses are recorded in accumulated other
 comprehensive income. To the extent unamortized gains and losses
 exceed 10% of the higher of the market-related value of assets or
 the projected benefit obligation, the excess is amortized as a
 component of net periodic pension cost over the remaining service
 period of active participants. We estimate that $0.4 million will
 be amortized from accumulated other comprehensive income into net
 periodic pension cost in 2015 for the net actuarial loss.

[0001193125-15-059743:notes:279]
We do not anticipate making a contribution to our pension plan in
 2015. The following pension benefit payments, which reflect
 expected future service, as appropriate, are expected to be paid to
 participants:

[0001193125-15-059743:notes:280]
| (In thousands) |  |
| 2015 |  | $ | 249 |  |
| 2016 |  |  | 284 |  |
| 2017 |  |  | 459 |  |
| 2018 |  |  | 628 |  |
| 2019 |  |  | 812 |  |
| 2020 – 2023 |  |  | 5,444 |  |
| Total |  | $ | 7,876 |  |

[0001193125-15-059743:notes:281]
Our investment policy includes various guidelines and procedures
 designed to ensure assets are invested in a manner necessary to
 meet expected future benefits earned by participants. The
 investments guidelines consider a broad range of economic
 conditions. Central to the policy are target allocation ranges by
 asset class, which is currently 75% for bond funds and 25% for
 equity funds.

[0001193125-15-059743:notes:282]
The objectives of the target allocations are to maintain investment
 portfolios that diversify risk through prudent asset allocation
 parameters, achieve asset returns that meet or exceed the
 plans’ actuarial assumptions, and achieve asset returns that
 are competitive with like institutions employing similar investment
 strategies.

[0001193125-15-059743:notes:283]
The investment policy is periodically reviewed by us and a
 designated third-party fiduciary for investment matters. The policy
 is established and administered in a manner that is compliant at
 all times with applicable government regulations.

[0001193125-15-059743:notes:284]
401(k) Savings Plan

[0001193125-15-059743:notes:285]
We maintain the ADTRAN, Inc. 401(k) Retirement Plan (Savings Plan)
 for the benefit of our eligible employees. The Savings Plan is
 intended to qualify under Sections 401(a) and 401(k) of the
 Internal Revenue Code of 1986, as amended (Code), and is intended
 to be a “safe harbor” 401(k) plan under Code
 Section 401(k)(12). The Savings Plan allows employees to save
 for retirement by contributing part of their compensation to the
 plan on a tax-deferred basis. The Savings Plan also requires us to
 contribute a “safe harbor” amount each year. We match
 up to 4% of employee contributions (100% of an employee’s
 first 3% of contributions and 50% of their next 2% of
 contributions), beginning on the employee’s one year
 anniversary date. In calculating our matching contribution, we only
 use compensation up to the statutory maximum under the Code ($260
 thousand for 2014). All contributions under the Savings Plan are
 100% vested. Expenses recorded for employer contributions and plan
 administration costs for the Savings Plan amounted to approximately
 $4.5 million, $4.5 million and $4.6 million in 2014, 2013 and 2012,
 respectively.

[0001193125-15-059743:notes:286]
Deferred Compensation Plans

[0001193125-15-059743:notes:287]
We maintain the ADTRAN, Inc. Deferred Compensation Plan (Deferred
 Compensation Plan). This plan is offered as a supplement to our
 tax-qualified 401(k) plan and is available to certain executive
 management employees who have been designated by our Board of
 Directors. The deferred compensation plan allows participants to
 defer all or a portion of certain specified bonuses and up to 25%
 of remaining cash compensation, and permits us to make matching
 contributions on a discretionary basis, without the limitations
 that apply to the 401(k) plan. To date, we have not made any
 matching contributions under this plan.

[0001193125-15-059743:notes:288]
We also maintain the ADTRAN, Inc. Equity Deferral Program for
 Employees for the purpose of providing deferred compensation for
 certain executive management employees. Participants may elect to
 defer all or a portion of their vested Performance Share awards to
 the Plan. Such deferrals shall continue to be held and deemed to be
 invested in shares of ADTRAN stock unless and until the amounts are
 distributed or such deferrals are moved to another deemed
 investment pursuant to an election made by the Participant.

[0001193125-15-059743:notes:289]
We have set aside the plan assets for both plans in a rabbi trust
 (Trust) and all contributions are credited to bookkeeping accounts
 for the participants. The Trust assets are subject to the claims of
 our creditors in the event of bankruptcy or insolvency. The assets
 of the Trust are deemed to be invested in pre-approved mutual funds
 as directed by each participant, and the participant’s
 bookkeeping account is credited with the earnings and losses
 attributable to those investments. Benefits are scheduled to be
 distributed six months after termination of employment in a single
 lump sum payment or annual installments paid over a three or ten
 year term. Distributions will be made on a pro rata basis from each
 of the hypothetical investments of the Participant’s account
 in cash. Any whole shares of ADTRAN, Inc. common stock that are
 distributed will be distributed in-kind.

[0001193125-15-059743:notes:290]
Assets of the Trust are deemed invested in mutual funds that cover
 an investment spectrum ranging from equities to money market
 instruments. These mutual funds are publicly quoted and reported at
 fair value. The fair value of the assets held by the Trust and the
 amounts payable to the plan participants are as follows:

[0001193125-15-059743:notes:291]
Interest and dividend income of the Trust have been included in
 interest and dividend income in the accompanying 2014, 2013 and
 2012 Consolidated Statements of Income. Changes in the fair value
 of the plan assets held by the Trust have been included in
 accumulated other comprehensive income in the accompanying 2014 and
 2013 Consolidated Balance Sheets. Changes in the fair value of the
 deferred compensation liability are included as selling, general
 and administrative expense in the accompanying 2014, 2013 and 2012
 Consolidated Statements of Income. Based on the changes in the
 total fair value of the Trust’s assets, we recorded deferred
 compensation expense in 2014, 2013 and 2012 of $0.7 million, $2.8
 million and $0.9 million, respectively.

[0001193125-15-059743:notes:292]
Retiree Medical Coverage

[0001193125-15-059743:notes:293]
We provide medical, dental and prescription drug coverage to one
 retired former officer and his spouse, for his life, on the same
 terms as provided to our active officers, and to the spouse of a
 former deceased officer for up to 30 years. At December 31,
 2014 and 2013, this liability totaled $0.2 million.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001193125-15-059743:notes:294]
Note 7 – Property, Plant and Equipment

[0001193125-15-059743:notes:295]
At December 31, 2014 and 2013, property, plant and equipment
 were comprised of the following:

[0001193125-15-059743:notes:296]
| (In thousands) |  | 2014 |  |  | 2013 |  |
| Land |  | $ | 4,575 |  |  | $ | 4,263 |  |
| Building and land improvements |  |  | 22,374 |  |  |  | 21,776 |  |
| Building |  |  | 68,301 |  |  |  | 68,479 |  |
| Furniture and fixtures |  |  | 16,468 |  |  |  | 16,465 |  |
| Computer hardware and software |  |  | 74,603 |  |  |  | 70,468 |  |
| Engineering and other equipment |  |  | 109,501 |  |  |  | 104,584 |  |
| Total Property, Plant and Equipment |  |  | 295,822 |  |  |  | 286,035 |  |
| Less accumulated depreciation |  |  | (220,994 | ) |  |  | (209,296 | ) |
| Total Property, Plant and Equipment, net |  | $ | 74,828 |  |  | $ | 76,739 |  |

[0001193125-15-059743:notes:297]
Depreciation expense was $12.5 million, $12.2 million and $12.1
 million in 2014, 2013 and 2012, respectively.


## adtn:IndustrialDevelopmentAuthorityFinancingAndEconomicIncentivesTextBlock

[0001193125-15-059743:notes:298]
Note 9 – Alabama State Industrial Development Authority
 Financing and Economic Incentives

[0001193125-15-059743:notes:299]
In conjunction with an expansion of our Huntsville, Alabama,
 facility, we were approved for participation in an incentive
 program offered by the State of Alabama Industrial Development
 Authority (the “Authority”). Pursuant to the program,
 on January 13, 1995, the Authority issued $20.0 million of its
 taxable revenue bonds and loaned the proceeds from the sale of the
 bonds to ADTRAN. The bonds were originally purchased by AmSouth
 Bank of Alabama, Birmingham, Alabama (the “Bank”).
 Wachovia Bank, N.A., Nashville, Tennessee (formerly First Union
 National Bank of Tennessee) (the “Bondholder”), which
 was acquired by Wells Fargo & Company on December 31,
 2008, purchased the original bonds from the Bank and made further
 advances to the Authority, bringing the total amount outstanding to
 $50.0 million. An Amended and Restated Taxable Revenue Bond
 (“Amended and Restated Bond”) was issued and the
 original financing agreement was amended. The Amended and Restated
 Bond bears interest, payable monthly. The interest rate is
 2% per annum. The Amended and Restated Bond matures on
 January 1, 2020. The estimated fair value of the bond using a
 level 2 valuation technique at December 31, 2014 was
 approximately $29.7 million, based on a debt security with a
 comparable interest rate and maturity and a Standard &
 Poor’s credit rating of AAA. We are required to make payments
 to the Authority in amounts necessary to pay the interest on the
 Amended and Restated Bond. Included in long-term investments at
 December 31, 2014 is $30.0 million which is invested in a
 restricted certificate of deposit. These funds serve as a
 collateral deposit against the principal of this bond, and we have
 the right to set-off the balance of the Bond with the collateral
 deposit in order to reduce the balance of the indebtedness.

[0001193125-15-059743:notes:300]
In conjunction with this program, we are eligible to receive
 certain economic incentives from the state of Alabama that reduce
 the amount of payroll withholdings that we are required to remit to
 the state for those employment positions that qualify under the
 program. For the years ended December 31, 2014, 2013 and 2012,
 we realized economic incentives related to payroll withholdings
 totaling $1.3 million, $1.3 million and $1.4 million,
 respectively.

[0001193125-15-059743:notes:301]
We made a principal payment of $16.5 million for the year ended
 December 31, 2014. We did not make a principal payment for the
 year-ended December 31, 2013. At December 31, 2014, $1.2
 million of the bond debt was classified as a current liability in
 accounts payable in the Consolidated Balance Sheets.
