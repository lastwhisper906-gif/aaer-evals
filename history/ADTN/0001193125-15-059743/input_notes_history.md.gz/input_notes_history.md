# ADTN note change history — 0001193125-14-297927 → 0001193125-14-398391


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2014-11-05):
[0001193125-14-398391:note_history:1]
We have committed to invest up to an aggregate of $7.9 million in
 two private equity funds, and we have contributed $8.4 million as
 of September 30, 2014, of which $7.7 million has been applied
 to these commitments.
  (was, 2014-08-06, similarity 0.9726):
[0001193125-14-297927:note_history:1]
We have committed to invest up to an aggregate of $7.9 million in
 two private equity funds, and we have contributed $8.4 million as
 of June 30, 2014, of which $7.7 million has been applied to
 these commitments.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: title_similarity, score: 1.0

- changed (2014-11-05):
[0001193125-14-398391:note_history:2]
We corrected immaterial misclassifications between the operating
 and investing sections of our consolidated statements of cash flows
 and adjusted our cash flows for the nine months ended
 September 30, 2013 in these categories by $0.4 million in
 order to be consistent with the 2014 presentation.
  (was, 2014-08-06, similarity 0.9149):
[0001193125-14-297927:note_history:2]
We corrected immaterial misclassifications between the operating
 and investing sections of our consolidated statements of cash flows
 and adjusted our cash flows for the six months ended June 30,
 2013 in these categories by $0.5 million in order to be consistent
 with the 2014 presentation.

- changed (2014-11-05):
[0001193125-14-398391:note_history:3]
During the year ended December 31, 2013, we identified two
 adjustments in the acquired NSN (formerly Nokia Siemens Networks)
 Broadband Access business (NSN BBA business) relating to customer
 payment discounts for one customer, and recoverable VAT taxes on
 certain vendor freight invoices that should have been recorded in
 prior periods. These adjustments resulted from a $0.5 million
 understatement of net income in the first two quarters of 2013. We
 evaluated the impact of the adjustments on the results of our
 previously issued financial statements for each of the prior
 periods affected and concluded that the impact was not material. We
 also evaluated the impact of the cumulative effect of the
 adjustments in 2013 and concluded that the impact is not material
 to our results for the year 2013. Accordingly, during the three
 months ended September 30, 2013 we recorded an out of period
 adjustment to correct these issues.
  (was, 2014-08-06, similarity 0.9682):
[0001193125-14-297927:note_history:3]
During the year ended December 31, 2013, we identified two
 adjustments in the acquired NSN (formerly Nokia Siemens Networks)
 Broadband Access business (NSN BBA business) relating to customer
 payment discounts for one customer, and recoverable VAT taxes on
 certain vendor freight invoices that should have been recorded in
 prior periods. These adjustments resulted from a $0.5 million
 understatement of net income in the first two quarters of 2013. We
 evaluated the impact of the adjustments on the results of our
 previously issued financial statements for the second quarter of
 2013 and concluded that the impact was not material. We also
 evaluated the impact of the cumulative effect of the adjustments in
 2013 and concluded that the impact is not material to our results
 for the year 2013. Accordingly, during the three months ended
 September 30, 2013 we recorded an out of period adjustment to
 correct these issues.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-11-05):
[0001193125-14-398391:note_history:4]
At September 30, 2014, we held the following securities and
 investments, recorded at either fair value or cost.
  (was, 2014-08-06, similarity 0.9463):
[0001193125-14-297927:note_history:4]
At June 30, 2014, we held the following securities and
 investments, recorded at either fair value or cost.

- changed (2014-11-05):
[0001193125-14-398391:note_history:5]
As of September 30, 2014, our corporate bonds and municipal
 fixed-rate bonds had the following contractual maturities:
  (was, 2014-08-06, similarity 0.9498):
[0001193125-14-297927:note_history:5]
As of June 30, 2014, our corporate bonds and municipal
 fixed-rate bonds had the following contractual maturities:

- added (2014-11-05):
[0001193125-14-398391:note_history:6]
Actual maturities may differ from contractual maturities because
 some borrowers have the right to call or prepay obligations with or
 without call or prepayment penalties.

- changed (2014-11-05):
[0001193125-14-398391:note_history:7]
At September 30, 2014, we held a $30.0 million restricted
 certificate of deposit, which is carried at cost. This investment
 serves as a collateral deposit against the principal amount
 outstanding under loans made to ADTRAN pursuant to an Alabama State
 Industrial Development Authority revenue bond (the Bond). During
 the first quarter of 2014, we made a principal payment on the Bond
 of $16.5 million. At September 30, 2014, the estimated fair
 value of the Bond using a level 2 valuation technique was
 approximately $29.8 million, based on a debt security with a
 comparable interest rate and maturity and a Standard and
 Poor’s credit rating of AAA. For more information on the
 Bond, see “Debt” under “Liquidity and Capital
 Resources” in the “Management’s Discussion and
 Analysis of Financial Condition and Results of Operations”
 contained in Item 2 of Part I of this report.
  (was, 2014-08-06, similarity 0.9846):
[0001193125-14-297927:note_history:7]
At June 30, 2014, we held a $30.0 million restricted
 certificate of deposit, which is carried at cost. This investment
 serves as a collateral deposit against the principal amount
 outstanding under loans made to ADTRAN pursuant to an Alabama State
 Industrial Development Authority revenue bond (the Bond). During
 the first quarter of 2014, we made a principal payment on the Bond
 of $16.5 million. At June 30, 2014, the estimated fair value
 of the Bond using a level 2 valuation technique was approximately
 $29.7 million, based on a debt security with a comparable interest
 rate and maturity and a Standard and Poor’s credit rating of
 AAA. For more information on the Bond, see “Debt” under
 “Liquidity and Capital Resources” in the
 “Management’s Discussion and Analysis of Financial
 Condition and Results of Operations” contained in Item 2
 of Part I of this report.

- changed (2014-11-05):
[0001193125-14-398391:note_history:8]
We review our investment portfolio for potential
 “other-than-temporary” declines in value on an
 individual investment basis. We assess, on a quarterly basis,
 significant declines in value which may be considered
 other-than-temporary and, if necessary, recognize and record the
 appropriate charge to write-down the carrying value of such
 investments. In making this assessment, we take into consideration
 qualitative and quantitative information, including but not limited
 to the following: the magnitude and duration of historical declines
 in market prices, credit rating activity, assessments of liquidity,
 public filings, and statements made by the issuer. We generally
 begin our identification of potential other-than-temporary
 impairments by reviewing any security with a fair value that has
 declined from its original or adjusted cost basis by 25% or more
 for six or more consecutive months. We then evaluate the individual
 security based on the previously identified factors to determine
 the amount of the write-down, if any. For the three and nine months
 ended September 30, 2014 and 2013, other-than-temporary
 impairment charges were not significant.
  (was, 2014-08-06, similarity 0.979):
[0001193125-14-297927:note_history:8]
We review our investment portfolio for potential
 “other-than-temporary” declines in value on an
 individual investment basis. We assess, on a quarterly basis,
 significant declines in value which may be considered
 other-than-temporary and, if necessary, recognize and record the
 appropriate charge to write-down the carrying value of such
 investments. In making this assessment, we take into consideration
 qualitative and quantitative information, including but not limited
 to the following: the magnitude and duration of historical declines
 in market prices, credit rating activity, assessments of liquidity,
 public filings, and statements made by the issuer. We generally
 begin our identification of potential other-than-temporary
 impairments by reviewing any security with a fair value that has
 declined from its original or adjusted cost basis by 25% or more
 for six or more consecutive months. We then evaluate the individual
 security based on the previously identified factors to determine
 the amount of the write-down, if any. For the three and six months
 ended June 30, 2014 and 2013, other-than-temporary impairment
 charges were not significant.

- changed (2014-11-05):
[0001193125-14-398391:note_history:9]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Gross realized gains |  | $ | 2,728 |  |  | $ | 1,797 |  |  | $ | 7,363 |  |  | $ | 7,252 |  |
| Gross realized losses |  | $ | (41 | ) |  | $ | (46 | ) |  | $ | (144 | ) |  | $ | (303 | ) |
  (was, 2014-08-06, similarity 0.8284):
[0001193125-14-297927:note_history:9]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
| (In thousands) |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Gross realized gains |  | $ | 2,407 |  |  | $ | 1,728 |  |  | $ | 4,635 |  |  | $ | 5,455 |  |
| Gross realized losses |  | $ | (67 | ) |  | $ | (175 | ) |  | $ | (103 | ) |  | $ | (257 | ) |

- changed (2014-11-05):
[0001193125-14-398391:note_history:10]
As of September 30, 2014 and 2013, gross unrealized losses
 related to individual securities in a continuous loss position for
 12 months or longer were not significant.
  (was, 2014-08-06, similarity 0.9644):
[0001193125-14-297927:note_history:10]
As of June 30, 2014 and 2013, gross unrealized losses related
 to individual securities in a continuous loss position for 12
 months or longer were not significant.

- changed (2014-11-05):
[0001193125-14-398391:note_history:11]
We have categorized our cash equivalents held in money market funds
 and our investments held at fair value into a three-level fair
 value hierarchy based on the priority of the inputs to the
 valuation technique for the cash equivalents and investments as
 follows: Level 1 - Values based on unadjusted quoted prices for
 identical assets or liabilities in an active market; Level 2 -
 Values based on quoted prices in markets that are not active or
 model inputs that are observable either directly or indirectly;
 Level 3 - Values based on prices or valuation techniques that
 require inputs that are both unobservable and significant to the
 overall fair value measurement. These inputs include information
 supplied by investees.
  (was, 2014-08-06, similarity 0.9917):
[0001193125-14-297927:note_history:11]
We have categorized our cash equivalents held in money market funds
 and our investments held at fair value into a three-level fair
 value hierarchy based on the priority of the inputs to the
 valuation technique for the cash equivalents and investments as
 follows: Level 1—Values based on unadjusted quoted prices for
 identical assets or liabilities in an active market; Level
 2—Values based on quoted prices in markets that are not
 active or model inputs that are observable either directly or
 indirectly; Level 3—Values based on prices or valuation
 techniques that require inputs that are both unobservable and
 significant to the overall fair value measurement. These inputs
 include information supplied by investees.

- changed (2014-11-05):
[0001193125-14-398391:note_history:12]
|  |  | Fair Value Measurements at September 30, 2014 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 9,861 |  |  | $ | 9,861 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 15,498 |  |  |  | 15,498 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 102,520 |  |  |  | — |  |  |  | 102,520 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 150,773 |  |  |  | — |  |  |  | 150,773 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 18,000 |  |  |  | — |  |  |  | 18,000 |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – technology industry |  |  | 8,879 |  |  |  | 8,879 |  |  |  | — |  |  |  | — |  |
| Marketable equity securities – other |  |  | 26,902 |  |  |  | 26,902 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 322,572 |  |  |  | 51,279 |  |  |  | 271,293 |  |  |  | — |  |
| Total |  | $ | 332,433 |  |  | $ | 61,140 |  |  | $ | 271,293 |  |  | $ | — |  |
  (was, 2014-08-06, similarity 0.9946):
[0001193125-14-297927:note_history:12]
|  |  | Fair Value Measurements at June 30, 2014 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 11,737 |  |  | $ | 11,737 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 15,755 |  |  |  | 15,755 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 99,391 |  |  |  | — |  |  |  | 99,391 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 155,982 |  |  |  | — |  |  |  | 155,982 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 15,120 |  |  |  | — |  |  |  | 15,120 |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – technology industry |  |  | 12,085 |  |  |  | 12,085 |  |  |  | — |  |  |  | — |  |
| Marketable equity securities – other |  |  | 27,642 |  |  |  | 27,642 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 325,975 |  |  |  | 55,482 |  |  |  | 270,493 |  |  |  | — |  |
| Total |  | $ | 337,712 |  |  | $ | 67,219 |  |  | $ | 270,493 |  |  | $ | — |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2014-11-05):
[0001193125-14-398391:note_history:13]
We employ the law firm of our director emeritus for legal services.
 All bills for services rendered by this firm are reviewed and
 approved by our Chief Financial Officer. We believe that the fees
 for such services are comparable to those charged by other firms
 for services rendered to us. The services of our director emeritus
 ended with his death on September 7, 2014. We incurred fees of
 $10 thousand and $30 thousand for the three months ended
 September 30, 2014 and 2013, respectively, and $70 thousand
 and $90 thousand for the nine months ended September 30, 2014
 and 2013, respectively, for these legal services.
  (was, 2014-08-06, similarity 0.7087):
[0001193125-14-297927:note_history:13]
We employ the law firm of our director emeritus for legal services.
 All bills for services rendered by this firm are reviewed and
 approved by our Chief Financial Officer. We believe that the fees
 for such services are comparable to those charged by other firms
 for services rendered to us. For the three and six months ended
 June 30, 2014 and 2013, we incurred fees of $10 thousand per
 month for these legal services.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2014-11-05):
[0001193125-14-398391:note_history:14]
On October 14, 2014, we announced that our Board of Directors
 declared a quarterly cash dividend of $0.09 per common share to be
 paid to stockholders of record at the close of business on
 October 30, 2014. The payment date will be November 13,
 2014. The quarterly dividend payment will be approximately $4.9
 million. In July 2003, our Board of Directors elected to begin
 declaring quarterly dividends on our common stock considering the
 tax treatment of dividends and adequate levels of Company
 liquidity.

- changed (2014-11-05):
[0001193125-14-398391:note_history:15]
During the fourth quarter and as of November 5, 2014, we have
 repurchased 0.2 million shares of our common stock
 through open market purchases at an average cost of $20.47 per
 share. We currently have the authority to purchase an additional
 5.5 million shares of our common stock under the current plan
 approved by the Board of Directors.
  (was, 2014-08-06, similarity 0.8611):
[0001193125-14-297927:note_history:15]
During the third quarter and as of August 6, 2014, we have
 repurchased 45 thousand shares of our common stock through
 open market purchases at an average cost of $21.93 per share. We
 currently have the authority to purchase an additional 6.1 million
 shares of our common stock under the current plan approved by the
 Board of Directors.

- removed (2014-11-05):
[0001193125-14-297927:note_history:16]
On July 15, 2014, we announced that our Board of Directors
 declared a quarterly cash dividend of $0.09 per common share to be
 paid to stockholders of record at the close of business on
 July 31, 2014. The payment date will be August 14, 2014.
 The quarterly dividend payment will be approximately $4.9 million.
 In July 2003, our Board of Directors elected to begin declaring
 quarterly dividends on our common stock considering the tax
 treatment of dividends and adequate levels of Company
 liquidity.
