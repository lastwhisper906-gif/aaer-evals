# ADTN MD&A — 0001193125-15-059743


## mdna

[0001193125-15-059743:mdna:1]
| ITEM 7. | MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS |

[0001193125-15-059743:mdna:2]
Overview

[0001193125-15-059743:mdna:3]
ADTRAN, Inc. is a leading global provider of networking and communications equipment. Our solutions enable voice, data, video and Internet communications
across a variety of network infrastructures. These solutions are deployed by some of the world’s largest service providers, distributed enterprises and small and medium-sized businesses, public and private enterprises, and millions of
individual users worldwide.

[0001193125-15-059743:mdna:4]
Our success depends upon our ability to increase unit volume and market share through the introduction of new products and
succeeding generations of products having lower selling prices and increased functionality as compared to both the prior generation of a product and to the products of competitors. An important part of our strategy is to reduce the cost of each
succeeding product generation and then lower the product’s selling price based on the cost savings achieved in order to gain market share and/or improve gross margins. As a part of this strategy, we seek in most instances to be a high-quality,
low-cost provider of products in our markets. Our success to date is attributable in large measure to our ability to design our products initially with a view to their subsequent redesign, allowing both increased functionality and reduced
manufacturing costs in each succeeding product generation. This strategy enables us to sell succeeding generations of products to existing customers, while increasing our market share by selling these enhanced products to new customers.

[0001193125-15-059743:mdna:5]
Our three major product categories are Carrier Systems, Business Networking and Loop Access.

[0001193125-15-059743:mdna:6]
Carrier Systems products are used by communications service providers to provide data, voice, and video services to consumers and enterprises. This
category includes the following product areas and related services:

[0001193125-15-059743:mdna:7]
|  | • |  | Broadband Access |

[0001193125-15-059743:mdna:8]
|  | • |  | Total Access® 5000 Series of Multi-Service Access Node (MSAN) |

[0001193125-15-059743:mdna:9]
|  | • |  | hiX 5600 Series of MSANs |

[0001193125-15-059743:mdna:10]
|  | • |  | Total Access 1100/1200 Series of Fiber to the Node (FTTN) products |

[0001193125-15-059743:mdna:11]
|  | • |  | hiX 1100 Series of Fiber to the Node (FTTN) products |

[0001193125-15-059743:mdna:12]
|  | • |  | VDSL2 Vectoring based Digital Subscriber Line Access Multiplexer (DSLAM) products |

[0001193125-15-059743:mdna:13]
|  | • |  | ADTRAN 500 Series of FTTdp G.fast Distribution Point Units (DPU) |

[0001193125-15-059743:mdna:14]
|  | • |  | Optical |

[0001193125-15-059743:mdna:15]
|  | • |  | Optical Networking Edge (ONE) |

[0001193125-15-059743:mdna:16]
|  | • |  | NetVanta 8000 Series of Fiber Ethernet Access Devices (EAD) |

[0001193125-15-059743:mdna:17]
|  | • |  | NetVanta 8400 Series of 10Gig Multi-service Edge Switches |

[0001193125-15-059743:mdna:18]
|  | • |  | OPTI-6100 and Total Access 3000 optical Multi-Service Provisioning Platforms (MSPP) |

[0001193125-15-059743:mdna:19]
|  | • |  | Pluggable Optical Products, including SFP, XFP, and SFP+ |

[0001193125-15-059743:mdna:20]
|  | • |  | Time Division Multiplexed (TDM) systems |

[0001193125-15-059743:mdna:21]
Business Networking products provide access to communication
services and facilitate the delivery of cloud connectivity and enterprise communications to the small and mid-sized enterprise (SME) market. This category includes the following product areas and related services:

[0001193125-15-059743:mdna:22]
|  | • |  | Internetworking products |

[0001193125-15-059743:mdna:23]
|  | • |  | Total Access IP Business Gateways |

[0001193125-15-059743:mdna:24]
|  | • |  | Optical Network Terminals (ONTs) |

[0001193125-15-059743:mdna:25]
|  | • |  | Bluesocket® virtual Wireless LAN (vWLAN®) |

[0001193125-15-059743:mdna:26]
|  | • |  | NetVanta® |

[0001193125-15-059743:mdna:27]
|  | • |  | Access Routers |

[0001193125-15-059743:mdna:28]
|  | • |  | Enterprise Session Border Controllers (eSBC) |

[0001193125-15-059743:mdna:29]
|  | • |  | Managed Ethernet Switches |

[0001193125-15-059743:mdna:30]
|  | • |  | IP Business Gateways |

[0001193125-15-059743:mdna:31]
|  | • |  | Unified Communications (UC) solutions |

[0001193125-15-059743:mdna:32]
|  | • |  | Carrier Ethernet Network Terminating Equipment (NTE) |

[0001193125-15-059743:mdna:33]
|  | • |  | Carrier Ethernet Routers and Gateways |

[0001193125-15-059743:mdna:34]
|  | • |  | Network Management Solutions |

[0001193125-15-059743:mdna:35]
Loop Access products are used by carrier and enterprise customers for access to copper-based
communications networks. This category includes the following product areas and related services:

[0001193125-15-059743:mdna:36]
|  | • |  | High bit-rate Digital Subscriber Line (HDSL) products |

[0001193125-15-059743:mdna:37]
|  | • |  | Digital Data Service (DDS) |

[0001193125-15-059743:mdna:38]
|  | • |  | Integrated Services Digital Network (ISDN) products |

[0001193125-15-059743:mdna:39]
|  | • |  | T1/E1/T3 Channel Service Units/Data Service Units (CSUs/DSUs) |

[0001193125-15-059743:mdna:40]
|  | • |  | TRACER fixed-wireless products |

[0001193125-15-059743:mdna:41]
In addition, we identify subcategories of product revenues, which we divide
into core products and legacy products. Our core products consist of Broadband Access and Optical products (included in Carrier Systems) and Internetworking products (included in Business Networking). Our legacy products include HDSL products
(included in Loop Access) and other products not included in the aforementioned core products. Many of our customers are migrating their networks to deliver higher bandwidth services by utilizing newer technologies. We believe that products and
services offered in our core product areas position us well for this migration. Despite occasional increases, we anticipate that revenues of many of our legacy products, including HDSL, will decline over time; however, revenues from these products
may continue for years because of the time required for our customers to transition to newer technologies.

[0001193125-15-059743:mdna:42]
Sales were $630.0 million in 2014 compared to
$641.7 million in 2013 and $620.6 million in 2012. Total sales of products in our three core areas, Broadband Access, Optical and Internetworking, increased 2.8% in 2014 compared to 2013 and increased 8.9% in 2013 compared to 2012. Our gross profit
margin was 49.4% in 2014 compared to 48.1% in 2013 and 51.0% in 2012. Net income was $44.6 million in 2014 compared to $45.8 million in 2013 and $47.3 million in 2012. Earnings per share, assuming dilution, were $0.80 in 2014 compared to $0.77 in
2013 and $0.74 in 2012. Earnings per share in 2014, 2013 and 2012 include the effect of the repurchase of 3.7 million, 5.6 million and 1.8 million shares of our stock in those years, respectively.

[0001193125-15-059743:mdna:43]
Our operating results have fluctuated on a quarterly basis in the past, and may vary significantly in future periods due to a number of factors, including
customer order activity and backlog. Backlog levels vary because of seasonal trends, the timing of customer projects and other factors that affect customer order lead times. Many of our customers require prompt delivery of products. This requires us
to maintain sufficient inventory levels to satisfy anticipated customer demand. If near-term demand for our products declines, or if potential sales in any quarter do not occur as anticipated, our financial results could be adversely affected.
Operating expenses are relatively fixed in the short term; therefore, a shortfall in quarterly revenues could significantly impact our financial results in a given quarter.

[0001193125-15-059743:mdna:44]
Our operating results may also fluctuate as a result of a number of other factors, including a decline in general economic and market conditions, increased
competition, customer order patterns, changes in product and services mix, foreign currency exchange rate movements, timing differences between price decreases and product cost reductions, product warranty returns, expediting costs, and
announcements of new products by us or our competitors. Additionally, maintaining sufficient inventory levels to assure prompt delivery of our products increases the amount of inventory that may become obsolete and increases the risk that the
obsolescence of this inventory may have an adverse effect on our business and operating results. Also, not maintaining sufficient inventory levels to assure prompt delivery of our products may cause us to incur expediting costs to meet customer
delivery requirements, which may negatively impact our operating results in a given quarter.

[0001193125-15-059743:mdna:45]
Accordingly, our historical financial performance is
not necessarily a meaningful indicator of future results, and, in general, management expects that our financial results may vary from period to period. See Note 15 of Notes to Consolidated Financial Statements for additional information. For a
discussion of risks associated with our operating results, see Item 1A of this report.

[0001193125-15-059743:mdna:46]
Critical Accounting Policies and Estimates

[0001193125-15-059743:mdna:47]
An accounting policy is deemed to be critical if it requires an accounting estimate to be made based on assumptions about matters that are highly uncertain at
the time the estimate is made, if different estimates reasonably could have been used, or if changes in the accounting estimate that are reasonably likely to occur could materially impact the results of financial operations. We believe the following
critical accounting policies affect our more significant judgments and estimates used in the preparation of our consolidated financial statements. These policies have been consistently applied across our two reportable segments: (1) Carrier
Networks Division and (2) Enterprise Networks Division.

[0001193125-15-059743:mdna:48]
|  | • |  | Revenue is generally recognized when persuasive evidence of an arrangement exists, delivery has occurred, the product price is fixed or determinable, collection of the resulting receivable is reasonably assured, and product returns are reasonably estimable. For product sales, revenue is generally recognized upon shipment of the product to our customer in accordance with the title transfer terms of the sales agreement, generally FOB shipping point. In the case of consigned inventory, revenue is recognized when the end customer assumes ownership of the product. Contracts that contain multiple deliverables are evaluated to determine the units of accounting, and the consideration from the arrangement is allocated to each unit of accounting based on the relative selling price and corresponding terms of the contract. We use vendor-specific objective evidence of selling price. When this evidence is not available, we are generally not able to determine third-party evidence of selling price because of the extent of customization among competing products or services from other companies. In these instances, we use best estimates to allocate consideration to each respective unit of accounting. These estimates include analysis of respective bills of material and review and analysis of similar product and service offerings. We record revenue associated with installation services when respective contractual obligations are complete. In instances where customer acceptance is required, revenue is deferred until respective acceptance criteria have been met. Contracts that include both installation services and product sales are evaluated for revenue recognition in accordance with contract terms. As a result, installation services may be considered a separate deliverable or may be considered a combined single unit of accounting with the delivered product. Generally, either the purchaser, ADTRAN, or a third party can perform the installation of our products. Shipping fees are recorded as revenue and the related cost is included in cost of sales. Revenue is recorded net of discounts. |

[0001193125-15-059743:mdna:49]
|  | • |  | A significant portion of Enterprise Networks products are sold in the United States through a non-exclusive distribution network of major technology distributors. These organizations then distribute or provide fulfillment services to an extensive network of VARs and system integrators. VARs and system integrators may be affiliated with us as a channel partner, or they may purchase from the distributor on an unaffiliated basis. Additionally, with certain limitations, our distributors may return unused and unopened product for stock-balancing purposes when these returns are accompanied by offsetting orders for products of equal or greater value. |

[0001193125-15-059743:mdna:50]
|  | • |  | We carry our inventory at the lower of cost or market, with cost being determined using the first-in, first-out method. We use standard costs for material, labor, and manufacturing overhead to value our inventory. Our standard costs are updated on at least a quarterly basis and any variances are expensed in the current period; therefore, our inventory costs approximate actual costs at the end of each reporting period. We write down our inventory for estimated obsolescence or unmarketable inventory by an amount equal to the difference between the cost of inventory and the estimated fair value based upon assumptions about future demand and market conditions. If actual future demand or market conditions are less favorable than those projected by management, we may be required to make additional inventory write-downs. Our reserve for excess and obsolete inventory was $24.7 million and $23.0 million at December 31, 2014 and 2013, respectively. Inventory disposals charged against the reserve were $2.1 million, $0.4 million and $0.5 million for the years ended December 31, 2014, 2013 and 2012, respectively. |

[0001193125-15-059743:mdna:51]
|  | • |  | The objective of our short-term investment policy is to preserve principal and maintain adequate liquidity with appropriate diversification, while achieving market returns. The objective of our long-term investment policy is principal preservation and total return; that is, the aggregate return from capital appreciation, dividend income, and interest income. These objectives are achieved through investments with appropriate diversification in fixed and variable rate income securities, public equity, and private equity portfolios. Our investment policy provides limitations for issuer concentration, which limits, at the time of purchase, the concentration in any one issuer to 5% of the market value of our total investment portfolio. We have experienced significant volatility in the market prices of our publicly traded marketable equity securities. These investments are recorded on the consolidated balance sheets at fair value with unrealized gains and losses reported as a component of accumulated other comprehensive income, net of tax. The ultimate realized value on these marketable equity securities is subject to market price volatility. |

[0001193125-15-059743:mdna:52]
30

[0001193125-15-059743:mdna:53]
We have categorized our cash equivalents held in money market funds and our investments held at
fair value into a three-level fair value hierarchy based on the priority of the inputs to the valuation technique for the cash equivalents and investments as follows: Level 1 – Values based on unadjusted, quoted prices in active markets for
identical assets or liabilities; Level 2 – Values based on inputs other than quoted prices included within Level 1 that are directly or indirectly observable for the asset or liability; Level 3 – Values based on unobservable inputs for the
asset or liability. These inputs include information supplied by investees. At December 31, 2014, we categorized $54.5 million and $241.5 million of our available-for-sale investments as Level 1 and Level 2, respectively, and $1.2 million of
our cash equivalents as Level 1. At December 31, 2013, we categorized $53.6 million and $311.5 million of our available-for-sale investments as Level 1 and Level 2, respectively, and $3.9 million of our cash equivalents as Level 1.

[0001193125-15-059743:mdna:54]
We review our investment portfolio for potential “other-than-temporary” declines in value on an individual investment basis. We
assess, on a quarterly basis, significant declines in value which may be considered other-than-temporary and, if necessary, recognize and record the appropriate charge to write-down the carrying value of such investments. In making this assessment,
we take into consideration qualitative and quantitative information, including but not limited to the following: the magnitude and duration of historical declines in market prices, credit rating activity, assessments of liquidity, public filings,
and statements made by the issuer. We generally begin our identification of potential other-than-temporary impairments by reviewing any security with a fair value that has declined from its original or adjusted cost basis by 25% or more for six or
more consecutive months. We then evaluate the individual security based on the previously identified factors to determine the amount of the write-down, if any. For the years ended December 31, 2014, 2013 and 2012, we recorded charges of $0.1
million, $25 thousand and $0.7 million, respectively, related to the other-than-temporary impairment of certain publicly traded equity securities and our deferred compensation plan assets. Actual losses, if any, could ultimately differ from these
estimates. Future adverse changes in market conditions or poor operating results of underlying investments could result in additional losses that may not be reflected in an investment’s current carrying value, thereby possibly requiring an
impairment charge in the future. See Note 4 of Notes to the Consolidated Financial Statements in this report for more information about our investments.

[0001193125-15-059743:mdna:55]
We also invest in privately held entities and private equity funds and record these investments at cost. We review these investments
periodically in order to determine if circumstances (both financial and non-financial) exist that indicate that we will not recover our initial investment. Impairment charges are recorded on investments having a cost basis that is greater than the
value that we would reasonably expect to receive in an arm’s length sale of the investment. We have not been required to record any impairment losses relating to these investments in 2014, 2013 or 2012.

[0001193125-15-059743:mdna:56]
|  | • |  | For purposes of determining the estimated fair value of our stock option awards on the date of grant, we use the Black-Scholes Model. This model requires the input of certain assumptions that require subjective judgment. These assumptions include, but are not limited to, expected stock price volatility over the term of the awards and actual and projected employee stock option exercise behaviors. Because our stock option awards have characteristics significantly different from those of traded options, and because changes in the input assumptions can materially affect the fair value estimate, the existing model may not provide a reliable single measure of the fair value of our stock option awards. For purposes of determining the estimated fair value of our performance-based restricted stock unit awards on the date of grant, we use a Monte Carlo Simulation valuation method. The restricted stock units are subject to a market condition based on the relative total shareholder return of ADTRAN against all of the companies in the NASDAQ Telecommunications Index and vest at the end of a three-year performance period. The fair value of restricted stock issued to our Directors is equal to the closing price of our stock on the date of grant. Management will continue to assess the assumptions and methodologies used to calculate the estimated fair value of stock-based compensation. Circumstances may change and additional data may become available over time, which could result in changes to these assumptions and methodologies and thereby materially impact our fair value determination. If factors change in future periods, the compensation expense that we record may differ significantly from what we have recorded in the current period. |

[0001193125-15-059743:mdna:57]
|  | • |  | We estimate our income tax provision or benefit in each of the jurisdictions in which we operate, including estimating exposures related to examinations by taxing authorities. We also make judgments regarding the realization of deferred tax assets, and establish valuation allowances where we believe it is more likely than not that future taxable income in certain jurisdictions will be insufficient to realize these deferred tax assets. Our estimates regarding future taxable income and income tax provision or benefit may vary due to changes in market conditions, changes in tax laws, or other factors. If our assumptions, and consequently our estimates, change in the future, the valuation allowances we have established may be increased or decreased, impacting future income tax expense. At December 31, 2014 and 2013 respectively, the valuation allowance was $7.5 million and $8.8 million. As of December 31, 2014, we have state research tax credit carry-forwards of $3.9 million, which will expire between 2015 and 2029. These carry-forwards were caused by tax credits in excess of our annual tax liabilities to an individual state where we no longer generate sufficient state income. In addition, as of December 31, 2014, we have a deferred tax asset of $9.2 million relating to net operating loss carry-forwards which will expire between 2015 and 2030. These carry-forwards are the result of acquisitions in 2009 and in 2011. The acquired net operating losses are in excess of the amount of estimated earnings. We believe it is more likely than not that we will not realize the full benefits of our deferred tax asset arising from these credits and net operating losses, and accordingly, have provided a valuation allowance against them. This valuation allowance is included in non-current deferred tax liabilities in the accompanying balance sheets. |

[0001193125-15-059743:mdna:58]
We establish reserves to remove some or all of the tax benefit of any of our tax positions at the time we determine that the positions become
uncertain. We adjust these reserves, including any impact on the related interest and penalties, as facts and circumstances change.

[0001193125-15-059743:mdna:59]
|  | • |  | Our products generally include warranties of 90 days to ten years for product defects. We accrue for warranty returns at the time revenue is recognized based on our estimate of the cost to repair or replace the defective products. We engage in extensive product quality programs and processes, including actively monitoring and evaluating the quality of our component suppliers. Our products continue to become more complex in both size and functionality as many of our product offerings migrate from line card applications to systems products. The increasing complexity of our products will cause warranty incidences, when they arise, to be more costly. Our estimates regarding future warranty obligations may change due to product failure rates, material usage, and other rework costs incurred in correcting a product failure. In addition, from time to time, specific warranty accruals may be recorded if unforeseen problems arise. Should our actual experience relative to these factors be worse than our estimates, we will be required to record additional warranty expense. Alternatively, if we provide for more reserves than we require, we will reverse a portion of such provisions in future periods. The liability for warranty obligations totaled $8.4 million and $9.0 million at December 31, 2014 and 2013, respectively. These liabilities are included in accrued expenses in the accompanying Consolidated Balance Sheets. |

[0001193125-15-059743:mdna:60]
|  | • |  | Pension benefit plan obligations are based on various assumptions used by our actuaries in calculating these amounts. These assumptions include discount rates, compensation rate increases, expected return on plan assets, retirement rates, and mortality rates. Actual results that differ from the assumptions and changes in assumptions could affect future expenses and obligations. Our net pension liability totaled $10.2 million and $2.6 million at December 31, 2014 and 2013, respectively. This liability is included in other non-current liabilities in the accompanying Consolidated Balance Sheets. |

[0001193125-15-059743:mdna:61]
|  | • |  | We use the acquisition method to account for business combinations. Under the acquisition method of accounting, we recognize the assets acquired and liabilities assumed at their fair value on the acquisition date. Goodwill is measured as the excess of the consideration transferred over the net assets acquired. The acquisition method of accounting requires us to exercise judgment and make significant estimates and assumptions regarding the fair value of the assets acquired and liabilities assumed, including the fair values of inventory, unearned revenue, warranty liabilities, identifiable intangible assets and deferred tax asset valuation allowances. This method also requires us to refine these estimates over a one-year measurement period to reflect information obtained about facts and circumstances that existed as of the acquisition date that, if known, would have affected the measurement of the asset and liabilities recorded on that date, which could affect our net income. |

[0001193125-15-059743:mdna:62]
|  | • |  | We evaluate the carrying value of goodwill during the fourth quarter of each year and between annual evaluations if events occur or circumstances change that would more likely than not reduce the fair value of the reporting unit below its carrying amount. When evaluating whether goodwill is impaired, we first assess qualitative factors to determine whether it is necessary to perform the two-step quantitative goodwill impairment test. If we determine that the two-step quantitative test is necessary, then we compare the fair value of the reporting unit to which the goodwill is assigned to the reporting unit’s carrying amount, including goodwill. If the carrying amount of the reporting unit exceeds its fair value, then the amount of the impairment loss is measured. We passed the qualitative assessment in 2014; therefore, we did not complete a quantitative assessment. As a result, there were no impairment losses recognized during 2014, 2013 or 2012. |

[0001193125-15-059743:mdna:63]
32

[0001193125-15-059743:mdna:64]
Results of Operations

[0001193125-15-059743:mdna:65]
The following table presents selected financial information derived from our consolidated statements of income expressed as a percentage of sales for the years
indicated.

[0001193125-15-059743:mdna:66]
| Year Ended December 31, |  | 2014 |  |  | 2013 |  |  | 2012 |  |
| Sales |  |  |  |  |  |  |  |  |  |  |  |  |
| Carrier Networks Division |  |  | 81.0 | % |  |  | 78.0 | % |  |  | 79.3 | % |
| Enterprise Networks Division |  |  | 19.0 |  |  |  | 22.0 |  |  |  | 20.7 |  |
| Total sales |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |
| Cost of sales |  |  | 50.6 |  |  |  | 51.9 |  |  |  | 49.0 |  |
| Gross profit |  |  | 49.4 |  |  |  | 48.1 |  |  |  | 51.0 |  |
| Selling, general and administrative expenses |  |  | 20.9 |  |  |  | 20.2 |  |  |  | 21.7 |  |
| Research and development expenses |  |  | 21.0 |  |  |  | 20.4 |  |  |  | 20.3 |  |
| Operating income |  |  | 7.5 |  |  |  | 7.6 |  |  |  | 9.1 |  |
| Interest and dividend income |  |  | 0.8 |  |  |  | 1.1 |  |  |  | 1.2 |  |
| Interest expense |  |  | (0.1 | ) |  |  | (0.4 | ) |  |  | (0.4 | ) |
| Net realized investment gain |  |  | 1.2 |  |  |  | 1.3 |  |  |  | 1.5 |  |
| Other income (expense), net |  |  | 0.2 |  |  |  | (0.1 | ) |  |  | — |  |
| Gain on bargain purchase of a business |  |  | — |  |  |  | — |  |  |  | 0.3 |  |
| Income before provision for income taxes |  |  | 9.5 |  |  |  | 9.5 |  |  |  | 11.8 |  |
| Provision for income taxes |  |  | (2.4 | ) |  |  | (2.3 | ) |  |  | (4.1 | ) |
| Net income |  |  | 7.1 | % |  |  | 7.1 | % |  |  | 7.6 | % |

[0001193125-15-059743:mdna:67]
33

[0001193125-15-059743:mdna:68]
Acquisition Expenses

[0001193125-15-059743:mdna:69]
On May 4, 2012, we closed on the acquisition of the NSN BBA business. Acquisition related expenses, amortizations and adjustments for the years ended
December 31, 2014, 2013 and 2012 for this transaction is as follows:

[0001193125-15-059743:mdna:70]
| (In Thousands) |  | 2014 |  |  | 2013 |  |  | 2012 |  |
| Amortization of acquired intangible assets |  | $ | 1,153 |  |  | $ | 1,174 |  |  | $ | 762 |  |
| Amortization of other purchase accounting adjustments |  |  | 1,117 |  |  |  | 1,378 |  |  |  | 2,305 |  |
| Acquisition related professional fees, travel and other expenses |  |  | 282 |  |  |  | 345 |  |  |  | 4,860 |  |
| Total acquisition related expenses, amortizations and adjustments |  |  | 2,552 |  |  |  | 2,897 |  |  |  | 7,927 |  |
| Tax effect |  |  | (791 | ) |  |  | (898 | ) |  |  | (2,589 | ) |
| Total acquisition related expenses, amortizations and adjustments, net of tax |  | $ | 1,761 |  |  | $ | 1,999 |  |  | $ | 5,338 |  |

[0001193125-15-059743:mdna:71]
The acquisition related expenses, amortizations and adjustments above were recorded in the following Consolidated Statements
of Income categories for the years ended December 31, 2014, 2013 and 2012:

[0001193125-15-059743:mdna:72]
| (In Thousands) |  | 2014 |  |  | 2013 |  |  | 2012 |  |
| Revenue (adjustments to unearned revenue recognized in the period) |  | $ | 595 |  |  | $ | 856 |  |  | $ | 1,225 |  |
| Cost of goods sold |  |  | 171 |  |  |  | 196 |  |  |  | 946 |  |
| Subtotal |  |  | 766 |  |  |  | 1,052 |  |  |  | 2,171 |  |
| Selling, general and administrative expenses |  |  | 311 |  |  |  | 399 |  |  |  | 4,510 |  |
| Research and development expenses |  |  | 1,475 |  |  |  | 1,446 |  |  |  | 1,246 |  |
| Subtotal |  |  | 1,786 |  |  |  | 1,845 |  |  |  | 5,756 |  |
| Total acquisition related expenses, amortizations and adjustments |  |  | 2,552 |  |  |  | 2,897 |  |  |  | 7,927 |  |
| Tax effect |  |  | (791 | ) |  |  | (898 | ) |  |  | (2,589 | ) |
| Total acquisition related expenses, amortizations and adjustments, net of tax |  | $ | 1,761 |  |  | $ | 1,999 |  |  | $ | 5,338 |  |

[0001193125-15-059743:mdna:73]
2014 Compared to 2013

[0001193125-15-059743:mdna:74]
Sales

[0001193125-15-059743:mdna:75]
Our sales decreased 1.8% from $641.7 million in
2013 to $630.0 million in 2014. The decrease in sales is primarily attributable to a $27.2 million decrease in sales of our HDSL and other legacy products and a $12.2 million decrease in sales of our Internetworking products, partially offset by a
$27.9 million increase in sales of our Broadband Access products.

[0001193125-15-059743:mdna:76]
Carrier Networks sales increased 1.9% from $500.7 million in 2013 to $510.4 million in
2014. The increase in sales is primarily attributable to increases in sales of Broadband Access products, Internetworking products, and Optical products, partially offset by a decrease in sales of our HDSL and other legacy products. The increase in
sales of our Broadband Access products is primarily attributable to an increase in hiX product sales in the EMEA region. The increase in sales of our Internetworking products is primarily attributable to increases in Carrier Ethernet sales and FTTP
ONT sales to carriers in North America. The increase in sales of our Optical products is primarily attributable to increased sales of Optical products for broadband access globally and increased sales of our OPTI-6100 products to a domestic tier 1
carrier for Ethernet services to enterprises for wireless backhaul. The decreases in sales of HDSL and other legacy products in North America have been expected as customers continue to upgrade their networks to deliver higher bandwidth services by
migrating to newer technologies, including to our core products from our Broadband Access, Internetworking and Optical product lines. While we expect that revenues from HDSL and our other legacy products will continue to decline over time, these
revenues may continue for years because of the time required for our customers to transition to newer technologies.

[0001193125-15-059743:mdna:77]
Enterprise Networks sales decreased
15.2% from $141.0 million in 2013 to $119.6 million in 2014. The decrease is attributable to a decrease in sales of our Internetworking products. The decrease in sales of our Internetworking products for this division is primarily attributable to
softer demand in North America and an inventory reduction, primarily at two distribution partners. Internetworking product sales attributable to Enterprise Networks were 93.6% of the division’s sales in 2014 and 2013. Legacy products primarily
comprise the remainder of Enterprise Networks sales. Enterprise Networks sales as a percentage of total sales decreased from 22.0% in 2013 to 19.0% in 2014.

[0001193125-15-059743:mdna:78]
International sales, which are included in the Carrier Networks and Enterprise Networks amounts discussed above, increased 33.9% from $185.7 million in 2013
to $248.6 million in 2014. International sales, as a percentage of total sales, increased from 28.9% in 2013 to 39.5% in 2014. The increase in international sales is primarily attributable to increases in sales in the EMEA region and Latin America,
partially offset by a decrease in sales in the Asia-Pacific region.

[0001193125-15-059743:mdna:79]
Carrier Systems product sales increased $14.8 million in 2014 compared to 2013
primarily due to a $27.9 million increase in Broadband Access product sales, partially offset by a $12.8 million decrease in legacy product sales. The increase in Carrier Systems product sales is primarily attributable to the factors discussed
above.

[0001193125-15-059743:mdna:80]
Business Networking product sales decreased $11.9 million in 2014 compared to 2013 primarily due to a $19.9 million decrease in Internetworking
product sales in the EN division, partially offset by a $7.7 million increase in Internetworking product sales in the CN division. The changes in sales of our Internetworking products in both of our divisions are primarily attributable to the
factors discussed above.

[0001193125-15-059743:mdna:81]
Loop Access product sales decreased $14.7 million in 2014 compared to 2013 primarily due to a $13.8 million decrease in HDSL
product sales, which is further discussed above.

[0001193125-15-059743:mdna:82]
Cost of Sales

[0001193125-15-059743:mdna:83]
As a percentage of sales, cost of sales decreased from 51.9% in 2013 to 50.6% in 2014. The decrease is primarily attributable to improving gross margins in our
international business, primarily related to lower product costs, partially offset by shifts in domestic customer mix and a higher services mix.

[0001193125-15-059743:mdna:84]
Carrier
Networks cost of sales decreased from 53.4% of sales in 2013 to 52.3% of sales in 2014. The decrease in Carrier Networks cost of sales as a percentage of sales is primarily attributable to improving gross margins in our international business,
partially offset by shifts in domestic customer mix and a higher services mix.

[0001193125-15-059743:mdna:85]
Enterprise Networks cost of sales decreased from 46.3% of sales in 2013 to
43.1% of sales in 2014. The decrease in Enterprise Networks cost of sales as a percentage of sales is primarily attributable to shifts in customer mix and lower product costs.

[0001193125-15-059743:mdna:86]
An important part of our strategy is to reduce the product cost of each succeeding product generation and then to
lower the product’s price based on the cost savings achieved. This may cause variations in our gross profit percentage due to timing differences between the recognition of cost reductions and the lowering of product selling prices.

[0001193125-15-059743:mdna:87]
Selling, General and Administrative Expenses

[0001193125-15-059743:mdna:88]
Selling,
general and administrative expenses increased 2.0% from $129.4 million in 2013 to $132.0 million in 2014. Selling, general and administrative expenses include personnel costs for administration, finance, information systems, human resources, sales
and marketing, and general management, as well as rent, utilities, legal and accounting expenses, bad debt expense, advertising, promotional material, trade show expenses, and related travel costs. The increase in selling, general and administrative
expenses is primarily attributable to increases in travel expenses, marketing expenses, contract services, and legal expenses, partially offset by a decrease in compensation expense. The increase in travel and marketing expenses is primarily
attributable to our increased participation in trade shows in the U.S. and the EMEA region.

[0001193125-15-059743:mdna:89]
Selling, general and administrative expenses as a percentage
of sales increased from 20.2% for the year ended December 31, 2013 to 20.9% for the year ended December 31, 2014. Selling, general and administrative expenses as a percentage of sales will generally fluctuate whenever there is a
significant fluctuation in revenues for the periods being compared.

[0001193125-15-059743:mdna:90]
Research and Development Expenses

[0001193125-15-059743:mdna:91]
Research and development expenses increased 0.9% from $131.1 million in 2013 to $132.3 million in 2014. The increase in research and development expenses is
primarily attributable to increases in compensation costs and travel expenses, partially offset by a decrease in independent contractor expense.

[0001193125-15-059743:mdna:92]
Research
and development expenses as a percentage of sales increased from 20.4% for the year ended December 31, 2013 to 21.0% for the year ended December 31, 2014. Research and development expenses as a percentage of sales will fluctuate whenever
there are incremental product development activities or a significant fluctuation in revenues for the periods being compared.

[0001193125-15-059743:mdna:93]
We expect to continue to
incur research and development expenses in connection with our new and existing products and our expansion into international markets. We continually evaluate new product opportunities and engage in intensive research and product development efforts
which provide for new product development, enhancement of existing products and product cost reductions. We may incur significant research and development expenses prior to the receipt of revenues from a major new product group.

[0001193125-15-059743:mdna:94]
Interest and Dividend Income

[0001193125-15-059743:mdna:95]
Interest and dividend
income decreased from $7.0 million in 2013 to $5.0 million in 2014. The decrease in interest and dividend income is primarily attributable to an $18.3 million reduction of restricted funds that serves as a collateral deposit against our taxable
revenue bond during the first quarter of 2014 and a reduction in the interest rate of that investment from 4.8% to 1.6% (see “Interest Expense” below for corresponding decrease in the interest rate of our taxable revenue bond). See
“Liquidity and Capital Resources” below for additional information on our taxable revenue bond.

[0001193125-15-059743:mdna:96]
Interest Expense

[0001193125-15-059743:mdna:97]
Interest expense, which is primarily related to our taxable revenue bond, decreased from $2.3 million in 2013 to $0.7 million in 2014. The decrease is
primarily attributable to a $16.5 million principal payment made on our taxable revenue bond during the first quarter of 2014. In connection with this payment, we negotiated a reduction in the interest rate of that bond from 5.0% to 2.0%, and, as
noted above, a reduction in the interest rate on the collateral supporting the bond. See “Liquidity and Capital Resources” below for additional information on our taxable revenue bond.

[0001193125-15-059743:mdna:98]
Net Realized Investment Gain

[0001193125-15-059743:mdna:99]
Net realized investment
gain decreased from $8.6 million in 2013 to $7.3 million in 2014. The decrease in realized investment gains is primarily attributable to lower gains from the sale of equity securities in 2014. See “Investing Activities” in “Liquidity
and Capital Resources” below for additional information.

[0001193125-15-059743:mdna:100]
Other Income (Expense), net

[0001193125-15-059743:mdna:101]
Other income (expense), net, comprised primarily of miscellaneous income, gains and losses resulting from foreign currency exchange rate movements, and
investment account management fees, changed from $0.9 million of expense in 2013 to $1.2 million of income in 2014. The change is primarily attributable to a $2.4 million gain recorded in the fourth quarter of 2014 related to the settlement of
working capital items from an acquisition transaction that closed in 2012, partially offset by investment account management fees.

[0001193125-15-059743:mdna:102]
Income Taxes

[0001193125-15-059743:mdna:103]
Our effective tax rate increased from 24.7% in 2013 to 25.5% in 2014. The increase in the effective tax rate between the two periods is primarily
attributable to two years of research tax credits being recognized in 2013, partially offset by an additional foreign tax benefit from the elimination of a valuation allowance recorded in 2014. Based upon our results of operations in 2014 and
expected profitability in future years in a certain international jurisdiction, we concluded that it is more likely than not certain foreign deferred tax assets will be realized.

[0001193125-15-059743:mdna:104]
Net Income

[0001193125-15-059743:mdna:105]
As a result of the above factors, net income
decreased from $45.8 million in 2013 to $44.6 million in 2014. As a percentage of sales, net income was 7.1% in 2013 and 2014.

[0001193125-15-059743:mdna:106]
2013 Compared to 2012

[0001193125-15-059743:mdna:107]
Sales

[0001193125-15-059743:mdna:108]
Our sales increased 3.4% from $620.6
million in 2012 to $641.7 million in 2013. The increase in sales is primarily attributable to a $21.5 million increase in sales of our Internetworking products, a $20.5 million increase in sales of our Broadband Access products, a $3.9 million
increase in sales of our Optical products, partially offset by a $24.7 million decrease in sales of our HDSL and other legacy products.

[0001193125-15-059743:mdna:109]
Carrier Networks
sales increased 1.8% from $492.1 million in 2012 to $500.7 million in 2013. The increase in sales is primarily attributable to increases in sales of Broadband Access products, Internetworking products, and Optical products, partially offset by a
decrease in sales of our HDSL products. The increase in sales of our Broadband Access products is primarily attributable to initial VDSL2 vectoring technology shipments to Europe, partially offset by fluctuations in project installation activities
at a Latin American carrier. The increase in sales of our Internetworking products is primarily attributable to an improved spending environment and increases in EFM NTE sales and FTTP ONT sales to carriers. The increase in sales of our Optical
products is primarily attributable to a technology shift from TDM and SONET/SDH architectures to Ethernet-based packet networks. We offer Ethernet-based solutions within our Optical products that address this technology change, and we expect sales
of our Optical products will increase over time due to this transition. The decrease in sales of HDSL and other legacy products has been expected as customers continue to upgrade their networks to deliver higher bandwidth services by migrating to
newer technologies, including to our core products from our Broadband Access, Internetworking and Optical product lines. While we expect that revenues from HDSL and our other legacy products will continue to decline over time, these revenues may
continue for years because of the time required for our customers to transition to newer technologies.

[0001193125-15-059743:mdna:110]
Enterprise Networks sales increased 9.7% from
$128.5 million in 2012 to $141.0 million in 2013. The increase is attributable to an increase in sales of our Internetworking products, partially offset by decreases in sales of our legacy products. The increase in sales of our Internetworking
products is primarily attributable to an improved spending environment and reflected an increase in sales of Ethernet switches and IP business gateways to both carriers and value added resellers. The decrease in legacy products was expected and is
discussed further above. Internetworking product sales attributable to Enterprise Networks were 93.6% of the division’s sales in 2013 compared with 91.5% in 2012. Legacy products primarily comprise the remainder of Enterprise Networks sales.
Enterprise Networks sales as a percentage of total sales increased from 20.7% in 2012 to 22.0% in 2013.

[0001193125-15-059743:mdna:111]
International sales, which are included in the
Carrier Networks and Enterprise Networks amounts discussed above, increased 23.6% from $150.2 million in 2012 to $185.7 million in 2013. International sales, as a percentage of total sales, increased from 24.2% in 2012 to 28.9% in 2013. The increase
in international sales is primarily attributable to an increase in sales in the EMEA region, partially offset by a decrease in sales in Latin America and the Asia-Pacific region.

[0001193125-15-059743:mdna:112]
Carrier Systems product sales increased $28.2 million in 2013 compared to 2012 primarily due to a $20.5 million increase in Broadband Access product sales, a
$3.9 million increase in Optical product sales, and a $3.9 million increase in legacy product sales. The increase in Carrier Systems product sales is primarily attributable to the factors discussed above.

[0001193125-15-059743:mdna:113]
Business Networking product sales increased $19.6 million in 2013 compared to 2012 primarily due to a $21.5
million increase in Internetworking product sales across both divisions, partially offset by a $1.9 million decrease in legacy product sales. The increase in sales of our Internetworking products was primarily attributable to an improved spending
environment and reflected an increase in sales to both carriers and value added resellers. The decrease in legacy products was expected and is further discussed above.

[0001193125-15-059743:mdna:114]
Loop Access product sales decreased $26.6 million in 2013 compared to 2012 primarily due to a $25.3 million decrease in HDSL product sales, which is further
discussed above.

[0001193125-15-059743:mdna:115]
Cost of Sales

[0001193125-15-059743:mdna:116]
As a percentage of
sales, cost of sales increased from 49.0% in 2012 to 51.9% in 2013. The increase was primarily attributable to a higher volume of the lower gross margin products related to the broadband access business we acquired in 2012, customer price movements
to achieve market share position and shifts in customer mix.

[0001193125-15-059743:mdna:117]
Carrier Networks cost of sales increased from 49.7% of sales in 2012 to 53.4% of sales in
2013. The increase in Carrier Networks cost of sales as a percentage of sales was primarily attributable to a higher volume of the lower gross margin products related to the acquired broadband access business, customer price movements to achieve
market share position and shifts in customer mix.

[0001193125-15-059743:mdna:118]
Enterprise Networks cost of sales increased from 46.1% of sales in 2012 to 46.3% of sales in 2013. The
increase in Enterprise Networks cost of sales as a percentage of sales was primarily attributable to customer price movements to achieve market share position and the impact of cost allocations between divisions, partially offset by higher cost
absorption due to the higher production volumes.

[0001193125-15-059743:mdna:119]
An important part of our strategy is to reduce the product cost of each succeeding product generation
and then to lower the product’s price based on the cost savings achieved. This may cause variations in our gross profit percentage due to timing differences between the recognition of cost reductions and the lowering of product selling prices.

[0001193125-15-059743:mdna:120]
Selling, General and Administrative Expenses

[0001193125-15-059743:mdna:121]
Selling, general and administrative expenses decreased 3.8% from $134.5 million in 2012 to $129.4 million in 2013. Selling, general and administrative expenses
include personnel costs for administration, finance, information systems, human resources, sales and marketing, and general management, as well as rent, utilities, legal and accounting expenses, bad debt expense, advertising, promotional material,
trade show expenses, and related travel costs. The decrease in selling, general and administrative expenses is primarily related to decreases in professional services, legal services and travel expenses, which were higher in 2012 due to
pre-acquisition activities related to the acquired broadband access business, and decreased independent contractor expense.

[0001193125-15-059743:mdna:122]
Selling, general and
administrative expenses as a percentage of sales decreased from 21.7% for the year ended December 31, 2012 to 20.2% for the year ended December 31, 2013. Selling, general and administrative expenses as a percentage of sales will generally
fluctuate whenever there is a significant fluctuation in revenues for the periods being compared.

[0001193125-15-059743:mdna:123]
Research and Development Expenses

[0001193125-15-059743:mdna:124]
Research and development expenses increased 4.1% from $126.0 million in 2012 to $131.1 million in 2013. The increase in research and development expenses is
primarily attributable to increases in staffing and fringe benefit costs due to increased headcount related to the broadband access business acquired on May 4, 2012, increases in amortization of acquired intangible assets and depreciation of
acquired fixed assets, partially offset by a decrease in independent contractor expenses.

[0001193125-15-059743:mdna:125]
Research and development expenses as a percentage of sales
increased from 20.3% for the year ended December 31, 2012 to 20.4% for the year ended December 31, 2013. Research and development expenses as a percentage of sales will fluctuate whenever there are incremental product development
activities or a significant fluctuation in revenues for the periods being compared.

[0001193125-15-059743:mdna:126]
We expect to continue to incur research and development expenses in
connection with our new and existing products and our expansion into international markets. We continually evaluate new product opportunities and engage in intensive research and product development efforts which provide for new product development,
enhancement of existing products and product cost reductions. We may incur significant research and development expenses prior to the receipt of revenues from a major new product group.

[0001193125-15-059743:mdna:127]
Interest and Dividend Income

[0001193125-15-059743:mdna:128]
Interest and dividend income decreased from $7.7 million in 2012 to $7.0 million in 2013. The decrease in interest and dividend income is primarily
attributable to a reduction in the average rate of return on our investments as well as a decrease in our average investment balances.

[0001193125-15-059743:mdna:129]
Interest
Expense

[0001193125-15-059743:mdna:130]
Interest expense remained consistent at $2.3 million in 2012 and 2013, as we had no substantial change in our fixed rate borrowings. See
“Liquidity and Capital Resources” below for additional information.

[0001193125-15-059743:mdna:131]
Net Realized Investment Gain

[0001193125-15-059743:mdna:132]
Net realized investment gain decreased from $9.6 million in 2012 to $8.6 million in 2013. The decrease in realized investment gains is primarily attributable
to lower gains from the sale of equity securities in 2013. See “Investing Activities” in “Liquidity and Capital Resources” below for additional information.

[0001193125-15-059743:mdna:133]
Other Income (Expense), net

[0001193125-15-059743:mdna:134]
Other income (expense), net,
comprised primarily of miscellaneous income, gains and losses on foreign currency transactions, investment account management fees, and gains or losses on the disposal of property, plant and equipment occurring in the normal course of business,
changed from $0.2 million of income in 2012 to $0.9 million of expense in 2013.

[0001193125-15-059743:mdna:135]
Income Taxes

[0001193125-15-059743:mdna:136]
Our effective tax rate decreased from 35.2% in 2012 to 24.7% in 2013. The decrease in the effective tax rate between the two periods is primarily attributable
to an acquired business that incurred losses in the prior year for which no tax benefit was recognized and the improved profitability of that business in the current year, the net effect of recording the benefit for the research tax credit for the
2012 tax year in January 2013 pursuant to the American Taxpayer Relief Act of 2012, and the inclusion of the benefit of the estimated 2013 research tax credit in the estimated annual effective rate for 2013.

[0001193125-15-059743:mdna:137]
Net Income

[0001193125-15-059743:mdna:138]
As a result of the above factors, net income
decreased from $47.3 million in 2012 to $45.8 million in 2013. As a percentage of sales, net income decreased from 7.6% in 2012 to 7.1% in 2013.

[0001193125-15-059743:mdna:139]
Liquidity and Capital Resources

[0001193125-15-059743:mdna:140]
Liquidity

[0001193125-15-059743:mdna:141]
We intend to finance our operations with cash flow from operations. We have used, and expect to continue to use, the cash generated from operations for working
capital, purchases of treasury stock, shareholder dividends, and other general corporate purposes, including (i) product development activities to enhance our existing products and develop new products and (ii) expansion of sales and
marketing activities. We believe our cash and cash equivalents, investments and cash generated from operations to be adequate to meet our operating and capital needs for at least the next 12 months.

[0001193125-15-059743:mdna:142]
At December 31, 2014, cash on hand was $73.4 million and short-term investments were $46.9 million, which placed our short-term liquidity at $120.4
million. At December 31, 2013, our cash on hand of $58.3 million and short-term investments of $105.8 million placed our short-term liquidity at $164.1 million. The decrease in short-term liquidity from 2013 to 2014 primarily reflects funds
used for share repurchases, shareholder dividends, and equipment acquisitions, partially offset by funds provided by our operating activities and proceeds from stock option exercises.

[0001193125-15-059743:mdna:143]
Operating Activities

[0001193125-15-059743:mdna:144]
Our working capital, which consists of current assets less current liabilities, decreased 16.3% from $277.3 million as of December 31, 2013 to $232.1
million as of December 31, 2014. The quick ratio, defined as cash and cash equivalents, short-term investments, and net accounts receivable, divided by current liabilities, decreased from 2.44 as of December 31, 2013 to 1.74 as of
December 31, 2014. The current ratio, defined as current assets divided by current liabilities, decreased from 3.71 as of December 31, 2013 to 2.95 as of December 31, 2014. The changes in our working capital, quick ratio and current
ratio are primarily attributable to a decrease in short-term investments and an increase in accounts payable and income tax payable, partially offset by an increase in other receivables. Short-term investments were used to fund share repurchases
during 2014.

[0001193125-15-059743:mdna:145]
Net accounts receivable increased 0.4% from $85.8 million at December 31, 2013 to $86.2 million at December 31, 2014. Our
allowance for doubtful accounts was $0.1 million at December 31, 2013 and 2014. Quarterly accounts receivable days sales outstanding (DSO) increased from 50 days as of December 31, 2013 to 55 days as of December 31, 2014. The change
in net accounts receivable and DSO is due to changes in customer mix and the timing of sales and collections during the quarter. Certain international customers can have longer payment terms than U.S. customers. Other receivables increased from
$18.2 million at December 31, 2013 to $35.6 million at December 31, 2014. The increase in other receivables is primarily attributable to the timing of filing returns and collections of value-added tax receivables in our international
subsidiaries. At December 31, 2014 and 2013, other receivables also included a receivable for additional consideration due from NSN for settlement of the working capital items. Other receivables will also fluctuate due to the timing of
shipments and collections for materials supplied to our contract manufacturers during the quarter.

[0001193125-15-059743:mdna:146]
Quarterly inventory turnover decreased from 3.6 turns
as of December 31, 2013 to 3.5 turns as of December 31, 2014. Inventory decreased 3.8% from $90.1 million at December 31, 2013 to $86.7 million at December 31, 2014. We expect inventory levels to fluctuate as we attempt to
maintain sufficient inventory in response to seasonal cycles of our business ensuring competitive lead times while managing the risk of inventory obsolescence that may occur due to rapidly changing technology and customer demand.

[0001193125-15-059743:mdna:147]
Accounts payable increased 16.8% from $48.3 million at December 31, 2013 to $56.4 million at December 31, 2014. Accounts payable will fluctuate due
to variations in the timing of the receipt of supplies, inventory and services and our subsequent payments for these purchases.

[0001193125-15-059743:mdna:148]
Investing Activities

[0001193125-15-059743:mdna:149]
Capital expenditures totaled approximately $11.3 million, $8.2 million and $12.3 million for the years ended December 31, 2014, 2013 and 2012,
respectively. These expenditures were primarily used to purchase computer hardware, software and manufacturing and test equipment.

[0001193125-15-059743:mdna:150]
On May 4, 2012,
we acquired the NSN BBA business. This acquisition provides us with an established customer base in key markets and complementary, market-focused products and was accounted for as a business combination. Upon acquisition, we received a cash payment
of $7.5 million from NSN and recorded a bargain purchase gain of $1.8 million, net of income taxes, subject to customary working capital adjustments between the parties as defined in the purchase agreement. During the fourth quarter of 2014, the
parties settled final working capital items, and as a result, we recorded a $2.4 million gain in other income (expense), net. Additionally, $3.5 million is included in other receivables at December 31, 2014 for additional consideration due from
NSN related to the settlement of the working capital items. This receivable was subsequently collected in January 2015.

[0001193125-15-059743:mdna:151]
Our combined short-term and
long-term investments decreased $87.4 million from $415.0 million at December 31, 2013 to $327.6 million at December 31, 2014. This decrease reflects the impact of our cash needs for share repurchases, shareholder dividends, equipment
acquisitions, as well as net realized and unrealized losses and amortization of net premiums on our combined investments, partially offset by additional funds available for investment provided by our operating activities and stock option exercises
by our employees.

[0001193125-15-059743:mdna:152]
We invest all available cash not required for immediate use in operations primarily in securities that we believe bear minimal risk of
loss. At December 31, 2014 these investments included corporate bonds of $111.3 million, municipal fixed-rate bonds of $127.8 million and municipal variable rate demand notes of $2.5 million. At December 31, 2013, these investments
included corporate bonds of $166.9 million, municipal fixed-rate bonds of $136.3 million and municipal variable rate demand notes of $8.3 million. As of December 31, 2014, our corporate bonds, municipal fixed-rate bonds, and municipal variable
rate demand notes were classified as available-for-sale and had a combined duration of 0.9 years with an average credit rating of AA-. Because our bond portfolio has a high quality rating and contractual maturities of a short duration, we are able
to obtain prices for these bonds derived from observable market inputs, or for similar securities traded in an active market, on a daily basis.

[0001193125-15-059743:mdna:153]
Our long-term investments decreased 9.2% from $309.2 million at December 31, 2013 to $280.6 million at
December 31, 2014. Long-term investments at December 31, 2014 and December 31, 2013 included an investment in a certificate of deposit of $30.0 million and $48.3 million, respectively, which serves as collateral for our revenue bonds,
as discussed below. We have investments in various marketable equity securities classified as long-term investments at a cost of $26.4 million and $24.7 million, and with a fair value of $38.3 million and $38.5 million, at December 31, 2014 and
December 31, 2013, respectively.

[0001193125-15-059743:mdna:154]
Long-term investments at December 31, 2014 and 2013 also included $16.3 million and $15.1 million,
respectively, related to our deferred compensation plan, and $1.5 million and $1.7 million, respectively, of other investments carried at cost, consisting of interests in two private equity funds and an investment in a privately held
telecommunications equipment manufacturer.

[0001193125-15-059743:mdna:155]
We review our investment portfolio for potential “other-than-temporary” declines in value on an
individual investment basis. We assess, on a quarterly basis, significant declines in value which may be considered other-than-temporary and, if necessary, recognize and record the appropriate charge to write-down the carrying value of such
investments. In making this assessment, we take into consideration qualitative and quantitative information, including but not limited to the following: the magnitude and duration of historical declines in market prices, credit rating activity,
assessments of liquidity, public filings, and statements made by the issuer. We generally begin our identification of potential other-than-temporary impairments by reviewing any security with a fair value that has declined from its original or
adjusted cost basis by 25% or more for six or more consecutive months. We then evaluate the individual security based on the previously identified factors to determine the amount of the write-down, if any. For the years ended December 31, 2014,
2013, and 2012, we recorded charges of $0.1 million, $25 thousand and $0.7 million, respectively, related to the other-than-temporary impairment of certain publicly traded equity securities and our deferred compensation plan assets.

[0001193125-15-059743:mdna:156]
Financing Activities

[0001193125-15-059743:mdna:157]
In conjunction with an expansion of
our Huntsville, Alabama, facility, we were approved for participation in an incentive program offered by the State of Alabama Industrial Development Authority (the “Authority”). Pursuant to the program, on January 13, 1995, the
Authority issued $20.0 million of its taxable revenue bonds and loaned the proceeds from the sale of the bonds to ADTRAN. The bonds were originally purchased by AmSouth Bank of Alabama, Birmingham, Alabama (the “Bank”). Wachovia Bank,
N.A., Nashville, Tennessee (formerly First Union National Bank of Tennessee) (the “Bondholder”), which was acquired by Wells Fargo & Company on December 31, 2008, purchased the original bonds from the Bank and made further
advances to the Authority, bringing the total amount outstanding to $50.0 million. An Amended and Restated Taxable Revenue Bond (“Amended and Restated Bond”) was issued and the original financing agreement was amended. The Amended and
Restated Bond bears interest, payable monthly. The interest rate is 2% per annum. The Amended and Restated Bond matures on January 1, 2020. The estimated fair value of the bond using a level 2 valuation technique at December 31, 2014
was approximately $29.7 million, based on a debt security with a comparable interest rate and maturity and a Standard & Poor’s credit rating of AAA. We are required to make payments to the Authority in amounts necessary to pay the
interest on the Amended and Restated Bond. Included in long-term investments at December 31, 2014 is $30.0 million which is invested in a restricted certificate of deposit. These funds serve as a collateral deposit against the principal of this
bond, and we have the right to set-off the balance of the Bond with the collateral deposit in order to reduce the balance of the indebtedness.

[0001193125-15-059743:mdna:158]
In
conjunction with this program, we are eligible to receive certain economic incentives from the state of Alabama that reduce the amount of payroll withholdings that we are required to remit to the state for those employment positions that qualify
under the program. For the years ended December 31, 2014, 2013 and 2012, we realized economic incentives related to payroll withholdings totaling $1.3 million, $1.3 million and $1.4 million, respectively.

[0001193125-15-059743:mdna:159]
We made a principal payment of $16.5 million for the year ended December 31, 2014. We did not make a principal payment for the year-ended
December 31, 2013. We anticipate making a principal payment in 2015. At December 31, 2014, $1.2 million of the bond debt was classified as a current liability in accounts payable in the Consolidated Balance Sheets.

[0001193125-15-059743:mdna:160]
The following table shows dividends paid to our shareholders in each quarter of 2014, 2013 and 2012. During 2014, 2013 and 2012, we paid shareholder dividends
totaling $19.9 million, $21.4 million and $22.8 million, respectively. The Board of Directors presently anticipates that it will declare a regular quarterly dividend so long as the present tax treatment of dividends exists and adequate levels of
liquidity are maintained.

[0001193125-15-059743:mdna:161]
| Dividends per Common Share |  |
|  |  | 2014 |  |  | 2013 |  |  | 2012 |  |
| First Quarter |  | $ | 0.09 |  |  | $ | 0.09 |  |  | $ | 0.09 |  |
| Second Quarter |  | $ | 0.09 |  |  | $ | 0.09 |  |  | $ | 0.09 |  |
| Third Quarter |  | $ | 0.09 |  |  | $ | 0.09 |  |  | $ | 0.09 |  |
| Fourth Quarter |  | $ | 0.09 |  |  | $ | 0.09 |  |  | $ | 0.09 |  |

[0001193125-15-059743:mdna:162]
Stock Repurchase Program

[0001193125-15-059743:mdna:163]
Since 1997, our Board of Directors has approved multiple share repurchase programs that have authorized open market repurchase transactions of up to
40.0 million shares of our common stock. On May 14, 2014, our Board of Directors authorized the repurchase of an additional 5.0 million shares of our common stock (bringing the total shares authorized for repurchase to 45.0 million),
which commenced upon completion of the repurchase plan announced on May 1, 2013. This new authorization is being implemented through open market or private purchases from time to time as conditions warrant. For the years 2014, 2013 and 2012, we
repurchased 3.7 million shares, 5.6 million shares and 1.8 million shares, respectively, for a cost of $80.6 million, $124.3 million and $39.4 million, respectively, at an average price of $21.96, $22.16 and $22.03 per share,
respectively. We currently have the authority to purchase an additional 4.8 million shares of our common stock under the current plan approved by the Board of Directors.

[0001193125-15-059743:mdna:164]
Stock Option Exercises

[0001193125-15-059743:mdna:165]
To accommodate employee stock
option exercises, we issued 0.1 million shares of treasury stock for $2.8 million during the year ended December 31, 2014, 0.2 million shares of treasury stock for $3.6 million during the year ended December 31, 2013, and
0.4 million shares of treasury stock for $6.0 million during the year ended December 31, 2012.

[0001193125-15-059743:mdna:166]
Off-Balance Sheet Arrangements and
Contractual Obligations

[0001193125-15-059743:mdna:167]
We do not have off-balance sheet financing arrangements and have not engaged in any related party transactions or arrangements
with unconsolidated entities or other persons that are reasonably likely to materially affect liquidity or the availability of or requirements for capital resources.

[0001193125-15-059743:mdna:168]
We have various contractual obligations and commercial commitments. The following table sets forth, in millions, the annual payments we are required to make
under contractual cash obligations and other commercial commitments at December 31, 2014.

[0001193125-15-059743:mdna:169]
Contractual Obligations

[0001193125-15-059743:mdna:170]
| (In millions) |  | Total |  |  | 2015 |  |  | 2016 |  |  | 2017 |  |  | 2018 |  |  | After 2018 |  |
| Long-term debt |  | $ | 30.0 |  |  | $ | 1.2 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 28.8 |  |
| Interest on long-term debt |  |  | 3.0 |  |  |  | 0.6 |  |  |  | 0.6 |  |  |  | 0.6 |  |  |  | 0.6 |  |  |  | 0.6 |  |
| Purchase obligations |  |  | 81.8 |  |  |  | 78.0 |  |  |  | 2.7 |  |  |  | 0.5 |  |  |  | 0.5 |  |  |  | 0.1 |  |
| Operating lease obligations |  |  | 18.7 |  |  |  | 4.9 |  |  |  | 3.7 |  |  |  | 3.2 |  |  |  | 1.6 |  |  |  | 5.3 |  |
| Totals |  | $ | 133.5 |  |  | $ | 84.7 |  |  | $ | 7.0 |  |  | $ | 4.3 |  |  | $ | 2.7 |  |  | $ | 34.8 |  |

[0001193125-15-059743:mdna:171]
We are required to make payments necessary to pay the interest on the Amended and Restated Bond, currently outstanding in the
aggregate principal amount of $30.0 million. The bond matures on January 1, 2020, and bears interest at the rate of 2% per annum. Included in long-term investments are $30.0 million of restricted funds, which is a collateral deposit
against the principal amount of this bond. We made a principal payment of $16.5 million for the year ended December 31, 2014. We did not make a principal payment for the year-ended December 31, 2013. We anticipate making a principal
payment in 2015. At December 31, 2014 and 2013, $1.2 million and $0.3 million, respectively, of the bond debt were classified as a current liability in accounts payable in the Consolidated Balance Sheets. See Note 9 of Notes to Consolidated
Financial Statements for additional information.

[0001193125-15-059743:mdna:172]
Purchase obligations primarily relate to open purchase orders to our contract manufacturers, component
suppliers, and other vendors.

[0001193125-15-059743:mdna:173]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, and we have contributed $8.4
million as of December 31, 2014, of which $7.7 million has been applied to these commitments. The additional $0.2 million commitment has been excluded from the table above due to uncertainty of when it will be applied.

[0001193125-15-059743:mdna:174]
We also have obligations related to uncertain income tax positions that have been excluded from the table above due to the uncertainty of when the related
expense will be recognized. See Note 10 of Notes to Consolidated Financial Statements for additional information.

[0001193125-15-059743:mdna:175]
Effect of Recent Accounting Pronouncements

[0001193125-15-059743:mdna:176]
In May 2014, the Financial Accounting Standards Board issued Accounting Standards Update No. 2014-09, Revenue from Contracts with Customers (ASU
2014-09), which supersedes the revenue recognition requirements in Topic 605, Revenue Recognition, including most industry-specific revenue recognition guidance throughout the Industry Topics of the Codification. The core principle of ASU
2014-09 is to recognize revenues when promised goods or services are transferred to customers in an amount that reflects the consideration that is expected to be received for those goods or services. ASU 2014-09 is effective for annual reporting
periods beginning after December 15, 2016, including interim periods within that reporting period, and early application is not permitted. ASU 2014-09 allows for either full retrospective or modified retrospective adoption. We are currently
evaluating the transition method that will be elected and the impact that the adoption of ASU 2014-09 will have on our financial position, results of operations and cash flows.

[0001193125-15-059743:mdna:177]
Subsequent Events

[0001193125-15-059743:mdna:178]
On January 20, 2015, the Board
declared a quarterly cash dividend of $0.09 per common share to be paid to shareholders of record at the close of business on February 5, 2015. The quarterly dividend payment was $4.8 million and was paid on February 19, 2015.
