# ADTN 8-K — 0001193125-15-140997 filed 2015-04-22

## item codes, every 8-K on or before 2015-05-06

- 2015-04-22 0001193125-15-140997 — 2.02, 9.01
- 2015-02-23 0001193125-15-056741 — 5.02, 9.01
- 2015-01-21 0001193125-15-015465 — 2.02, 9.01
- 2014-10-15 0001193125-14-372076 — 2.02, 9.01
- 2014-10-03 0001193125-14-363152 — 2.02, 9.01
- 2014-07-16 0001193125-14-269660 — 2.02, 9.01
- 2014-05-20 0001193125-14-205916 — 8.01, 9.01
- 2014-05-20 0001193125-14-205906 — 5.02, 9.01
- 2014-05-15 0001193125-14-201144 — 5.07
- 2014-04-16 0001193125-14-144665 — 2.02, 9.01
- 2014-04-03 0001193125-14-129578 — 2.02, 9.01
- 2014-01-22 0001157523-14-000154 — 2.02, 9.01
- 2013-10-15 0001193125-13-399540 — 5.02
- 2013-10-09 0001157523-13-004657 — 2.02, 9.01
- 2013-07-10 0001157523-13-003290 — 2.02, 9.01
- 2013-05-10 0001193125-13-213728 — 5.07
- 2013-05-03 0001193125-13-198816 — 8.01, 9.01
- 2013-04-10 0001157523-13-001730 — 2.02, 9.01
- 2013-01-16 0001157523-13-000139 — 2.02, 9.01
- 2012-10-10 0001157523-12-005081 — 2.02, 9.01
- 2012-10-03 0001193125-12-413609 — 7.01
- 2012-09-28 0001193125-12-408878 — 2.02, 9.01
- 2012-07-11 0001157523-12-003592 — 2.02, 9.01
- 2012-05-10 0001193125-12-225669 — 5.07
- 2012-05-10 0001193125-12-225639 — 8.01, 9.01
- 2012-04-11 0001157523-12-001772 — 2.02, 9.01
- 2012-03-15 0001193125-12-116494 — 2.02, 9.01
- 2012-01-18 0001157523-12-000174 — 2.02, 9.01
- 2011-12-12 0001193125-11-337271 — 7.01, 9.01
- 2011-10-13 0000950123-11-089785 — 5.03, 9.01
- 2011-10-12 0001157523-11-005682 — 2.02, 9.01
- 2011-07-13 0001157523-11-003986 — 2.02, 9.01
- 2011-05-09 0000950123-11-047191 — 5.02, 5.07, 9.01
- 2011-04-13 0001157523-11-002001 — 2.02, 9.01
- 2011-01-19 0001157523-11-000232 — 2.02, 9.01
- 2010-11-09 0000950123-10-103195 — 5.02, 9.01
- 2010-10-13 0001157523-10-005798 — 2.02, 9.01
- 2010-07-14 0001157523-10-004011 — 2.02, 9.01
- 2010-05-28 0000950123-10-053947 — 5.07
- 2010-04-14 0001157523-10-002022 — 2.02, 9.01
- 2010-01-20 0001157523-10-000200 — 2.02, 9.01
- 2009-10-28 0000950123-09-053984 — 8.01
- 2009-10-14 0001157523-09-006877 — 2.02, 9.01
- 2009-07-15 0001157523-09-004878 — 2.02, 9.01
- 2009-04-15 0001157523-09-002687 — 2.02, 9.01
- 2009-01-21 0001157523-09-000340 — 2.02, 9.01
- 2008-11-12 0001193125-08-233181 — 5.02, 9.01
- 2008-10-14 0001157523-08-007999 — 2.02, 9.01
- 2008-07-15 0001157523-08-005504 — 2.02, 9.01
- 2008-04-15 0001157523-08-002896 — 2.02, 9.01
- 2008-01-22 0001157523-08-000408 — 2.02, 9.01
- 2007-10-16 0001193125-07-219356 — 5.03, 9.01
- 2007-10-16 0001157523-07-009850 — 2.02, 9.01
- 2007-07-17 0001157523-07-006912 — 2.02, 9.01
- 2007-04-17 0001157523-07-003630 — 2.02, 9.01
- 2007-04-03 0001179022-07-000068 — 5.02
- 2007-03-28 0001179022-07-000064 — 5.02
- 2007-02-23 0001193125-07-038337 — 5.02
- 2007-02-23 0001193125-07-038335 — 5.02
- 2007-01-30 0001193125-07-015912 — 5.02, 9.01
- 2007-01-26 0001193125-07-014234 — 5.02
- 2007-01-23 0001157523-07-000494 — 2.02, 9.01 — amendment of 0001157523-07-000481
- 2007-01-23 0001157523-07-000481 — 2.02, 9.01
- 2006-10-17 0001157523-06-009945 — 2.02, 9.01
- 2006-07-18 0001157523-06-006929 — 2.02, 9.01
- 2006-06-08 0001193125-06-126486 — 1.01, 9.01
- 2006-05-10 0001193125-06-107316 — 1.01, 9.01
- 2006-04-18 0001157523-06-003699 — 2.02, 9.01
- 2006-02-03 0001179022-06-000014 — 1.01
- 2006-01-27 0001157523-06-000754 — 5.02, 9.01
- 2006-01-24 0001157523-06-000551 — 2.02, 9.01
- 2005-10-18 0001157523-05-008826 — 2.02, 9.01
- 2005-07-19 0001193125-05-143958 — 1.01, 5.02, 9.01
- 2005-07-19 0001193125-05-143957 — 2.02, 9.01
- 2005-05-20 0001193125-05-112019 — 1.01, 9.01
- 2005-04-19 0001157523-05-003418 — 2.02, 9.01
- 2005-01-25 0001193125-05-010721 — 2.02, 9.01
- 2004-10-12 0001193125-04-169652 — 2.02, 9.01
- 2004-07-13 0001193125-04-116820 — 12, 7
- 2004-04-14 0001193125-04-061547 — 12, 7
- 2004-01-21 0001193125-04-006366 — 12, 7
- 2003-10-14 0001193125-03-061018 — 12, 5, 7
- 2003-07-15 0001193125-03-019292 — 7, 9
- 2003-04-15 0000931763-03-000968 — 7, 9
- 1996-09-12 0000931763-96-000667 — 5, 7

## late-filing notifications on or before 2015-05-06

- none on or before 2015-05-06

## item 2.02 — earnings release, exhibit 99.1

[0001193125-15-140997:8k_2_02:1]
EX-99.1
2
d911247dex991.htm
EX-99.1

[0001193125-15-140997:8k_2_02:2]
EX-99.1

[0001193125-15-140997:8k_2_02:3]
EXHIBIT 99.1

[0001193125-15-140997:8k_2_02:4]
ADTRAN, INC.

[0001193125-15-140997:8k_2_02:5]
REPORTS RESULTS for the FIRST QUARTER 2015 and DECLARES QUARTERLY CASH DIVIDEND

[0001193125-15-140997:8k_2_02:6]
HUNTSVILLE, Ala.—(BUSINESS WIRE)—April 21, 2015—ADTRAN, Inc. (NASDAQ:ADTN) reported results for the first quarter 2015. For the quarter, sales
were $142,835,000 compared to $147,004,000 for the first quarter of 2014. Net income was $3,317,000 compared to $9,607,000 for the first quarter of 2014. Earnings per share, assuming dilution, were $0.06 compared to $0.17 for the first quarter of
2014. Non-GAAP earnings per share were $0.10 compared to $0.21 for the first quarter of 2014. The reconciliation between GAAP earnings per share, diluted, and non-GAAP earnings per share, diluted, is in the table provided.

[0001193125-15-140997:8k_2_02:7]
ADTRAN Chief Executive Officer Tom Stanton stated, “Revenue for the quarter came in lower than expected, driven by currency fluctuations in our European
business, and the cancellation of a planned domestic Tier 1 program that was expected to commence late in the quarter. We did continue to see positive momentum in our European business, as well as the expected improvement in our Tier 2 carriers in
the U.S. as CAF funding started to take hold.”

[0001193125-15-140997:8k_2_02:8]
The Company also announced that its Board of Directors declared a cash dividend for the first quarter
of 2015. The quarterly cash dividend is $0.09 per common share to be paid to holders of record at the close of business on May 7, 2015. The ex-dividend date is May 5, 2015 and the payment date is May 21, 2015.

[0001193125-15-140997:8k_2_02:9]
The Company confirmed that its first quarter conference call will be held Wednesday, April 22, 2015 at 9:30 a.m. Central Time. This conference call will
be web cast live through StreetEvents.com. To listen, simply visit the Investor Relations site at www.adtran.com or www.streetevents.com approximately 10 minutes prior to the start of the call and click on the conference call link
provided.

[0001193125-15-140997:8k_2_02:10]
An online replay of the conference call will be available for seven days at www.streetevents.com. In addition, an online replay of the
conference call, as well as the text of the Company’s earnings release, will be available on the Investor Relations site at www.adtran.com for at least 12 months following the call.

[0001193125-15-140997:8k_2_02:11]
ADTRAN, Inc. is a leading global provider of networking and communications equipment. ADTRAN’s products enable voice, data, video and Internet
communications across a variety of network infrastructures. ADTRAN solutions are currently in use by service providers, private enterprises, government organizations, and millions of individual users worldwide. For more information, please visit
www.adtran.com.

[0001193125-15-140997:8k_2_02:12]
For more information, contact the company at 800 9ADTRAN (800 923-8726) or via email at info@adtran.com. On the Web, visit
www.adtran.com.

[0001193125-15-140997:8k_2_02:13]
This press release contains forward-looking statements which reflect management’s best judgment based on factors currently
known. However, these statements involve risks and uncertainties, including the successful development and market acceptance of new products, the degree of competition in the market for such products, the product and channel mix, component costs,
manufacturing efficiencies, and other risks detailed in our annual report on Form 10-K for the year ended December 31, 2014. These risks and uncertainties could cause actual results to differ materially from those in the forward-looking
statements included in this press release.

[0001193125-15-140997:8k_2_02:14]
| CONTACT: Michael Foliano Senior Vice President & Interim CFO 256-963-8885 |  | INVESTOR SERVICES/ASSISTANCE: Gayle Ellis Investor Services 256-963-8220 |

[0001193125-15-140997:8k_2_02:15]
Condensed Consolidated Balance Sheet

[0001193125-15-140997:8k_2_02:16]
(Unaudited)

[0001193125-15-140997:8k_2_02:17]
(In
thousands)

[0001193125-15-140997:8k_2_02:18]
|  |  | March 31,2015 |  |  | December 31,2014 |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 87,009 |  |  | $ | 73,439 |  |
| Short-term investments |  |  | 78,760 |  |  |  | 46,919 |  |
| Accounts receivable, net |  |  | 90,869 |  |  |  | 88,502 |  |
| Other receivables |  |  | 29,962 |  |  |  | 33,295 |  |
| Inventory |  |  | 93,123 |  |  |  | 86,710 |  |
| Prepaid expenses |  |  | 5,092 |  |  |  | 5,129 |  |
| Deferred tax assets, net |  |  | 16,297 |  |  |  | 17,095 |  |
| Total Current Assets |  |  | 401,112 |  |  |  | 351,089 |  |
| Property, plant and equipment, net |  |  | 73,987 |  |  |  | 74,828 |  |
| Deferred tax assets, net |  |  | 18,831 |  |  |  | 17,694 |  |
| Goodwill |  |  | 3,492 |  |  |  | 3,492 |  |
| Other assets |  |  | 10,080 |  |  |  | 10,942 |  |
| Long-term investments |  |  | 236,678 |  |  |  | 280,649 |  |
| Total Assets |  | $ | 744,180 |  |  | $ | 738,694 |  |
| Liabilities and Stockholders’ Equity |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 73,696 |  |  | $ | 56,414 |  |
| Unearned revenue |  |  | 16,815 |  |  |  | 22,762 |  |
| Accrued expenses |  |  | 12,773 |  |  |  | 11,077 |  |
| Accrued wages and benefits |  |  | 15,605 |  |  |  | 13,855 |  |
| Income tax payable, net |  |  | 13,088 |  |  |  | 14,901 |  |
| Total Current Liabilities |  |  | 131,977 |  |  |  | 119,009 |  |
| Non-current unearned revenue |  |  | 10,088 |  |  |  | 10,948 |  |
| Other non-current liabilities |  |  | 30,646 |  |  |  | 30,924 |  |
| Bonds payable |  |  | 28,800 |  |  |  | 28,800 |  |
| Total Liabilities |  |  | 201,511 |  |  |  | 189,681 |  |
| Stockholders’ Equity |  |  | 542,669 |  |  |  | 549,013 |  |
| Total Liabilities and Stockholders’ Equity |  | $ | 744,180 |  |  | $ | 738,694 |  |

[0001193125-15-140997:8k_2_02:19]
Consolidated Statements of Income

[0001193125-15-140997:8k_2_02:20]
(Unaudited)

[0001193125-15-140997:8k_2_02:21]
(In
thousands, except per share data)

[0001193125-15-140997:8k_2_02:22]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
|  |  | 2015 |  |  | 2014 |  |
| Sales |  | $ | 142,835 |  |  | $ | 147,004 |  |
| Cost of sales |  |  | 77,272 |  |  |  | 69,214 |  |
| Gross Profit |  |  | 65,563 |  |  |  | 77,790 |  |
| Selling, general and administrative expenses |  |  | 31,064 |  |  |  | 33,939 |  |
| Research and development expenses |  |  | 32,536 |  |  |  | 32,553 |  |
| Operating Income |  |  | 1,963 |  |  |  | 11,298 |  |
| Interest and dividend income |  |  | 933 |  |  |  | 1,294 |  |
| Interest expense |  |  | (148 | ) |  |  | (227 | ) |
| Net realized investment gain |  |  | 3,115 |  |  |  | 2,192 |  |
| Other income (expense), net |  |  | (353 | ) |  |  | 122 |  |
| Income before provision for income taxes |  |  | 5,510 |  |  |  | 14,679 |  |
| Provision for income taxes |  |  | (2,193 | ) |  |  | (5,072 | ) |
| Net Income |  | $ | 3,317 |  |  | $ | 9,607 |  |
| Weighted average shares outstanding - basic |  |  | 53,399 |  |  |  | 56,751 |  |
| Weighted average shares outstanding - diluted (1) |  |  | 53,634 |  |  |  | 57,368 |  |
| Earnings per common share - basic |  | $ | 0.06 |  |  | $ | 0.17 |  |
| Earnings per common share - diluted (1) |  | $ | 0.06 |  |  | $ | 0.17 |  |

[0001193125-15-140997:8k_2_02:23]
| (1) | Assumes exercise of dilutive stock options calculated under the treasury stock method. |

[0001193125-15-140997:8k_2_02:24]
Consolidated Statements of Comprehensive Income

[0001193125-15-140997:8k_2_02:25]
(Unaudited)

[0001193125-15-140997:8k_2_02:26]
(In
thousands)

[0001193125-15-140997:8k_2_02:27]
|  |  | Three Months EndedMarch 31, |  |
|  |  | 2015 |  |  | 2014 |  |
| Net Income |  | $ | 3,317 |  |  | $ | 9,607 |  |
| Other Comprehensive Loss, net of tax: |  |  |  |  |  |  |  |  |
| Unrealized losses on available-for-sale securities |  |  | (503 | ) |  |  | (921 | ) |
| Defined benefit plan adjustments |  |  | 68 |  |  |  | — |  |
| Foreign currency translation |  |  | (3,318 | ) |  |  | 252 |  |
| Other Comprehensive Loss, net of tax |  |  | (3,753 | ) |  |  | (669 | ) |
| Comprehensive Income (Loss), net of tax |  | $ | (436 | ) |  | $ | 8,938 |  |

[0001193125-15-140997:8k_2_02:28]
Consolidated Statements of Cash Flows

[0001193125-15-140997:8k_2_02:29]
(Unaudited)

[0001193125-15-140997:8k_2_02:30]
(In
thousands)

[0001193125-15-140997:8k_2_02:31]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
|  |  | 2015 |  |  | 2014 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 3,317 |  |  | $ | 9,607 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 3,728 |  |  |  | 3,580 |  |
| Amortization of net premium on available-for-sale investments |  |  | 910 |  |  |  | 1,135 |  |
| Net realized gain on long-term investments |  |  | (3,115 | ) |  |  | (2,192 | ) |
| Net (gain)/loss on disposal of property, plant and equipment |  |  | 8 |  |  |  | (3 | ) |
| Stock-based compensation expense |  |  | 1,639 |  |  |  | 2,057 |  |
| Deferred income taxes |  |  | (692 | ) |  |  | 627 |  |
| Tax benefit from stock option exercises |  |  | 8 |  |  |  | 57 |  |
| Excess tax benefits from stock-based compensation arrangements |  |  | (9 | ) |  |  | (55 | ) |
| Change in operating assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  |  | (4,571 | ) |  |  | (15,971 | ) |
| Other receivables |  |  | 511 |  |  |  | (9,407 | ) |
| Inventory |  |  | (7,784 | ) |  |  | 2,739 |  |
| Prepaid expenses and other assets |  |  | (213 | ) |  |  | (2,024 | ) |
| Accounts payable |  |  | 20,084 |  |  |  | 11,043 |  |
| Accrued expenses and other liabilities |  |  | (282 | ) |  |  | 8,431 |  |
| Income tax payable, net |  |  | (524 | ) |  |  | 275 |  |
| Net cash provided by operating activities |  |  | 13,015 |  |  |  | 9,899 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (2,442 | ) |  |  | (2,042 | ) |
| Proceeds from disposals of property, plant and equipment |  |  | — |  |  |  | 1 |  |
| Proceeds from sales and maturities of available-for-sale investments |  |  | 58,075 |  |  |  | 85,072 |  |
| Purchases of available-for-sale investments |  |  | (44,584 | ) |  |  | (69,182 | ) |
| Net cash provided by investing activities |  |  | 11,049 |  |  |  | 13,849 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Proceeds from stock option exercises |  |  | 280 |  |  |  | 1,541 |  |
| Purchases of treasury stock |  |  | (3,035 | ) |  |  | (9,427 | ) |
| Dividend payments |  |  | (4,811 | ) |  |  | (5,102 | ) |
| Payments on long-term debt |  |  | — |  |  |  | (16,500 | ) |
| Excess tax benefits from stock-based compensation arrangements |  |  | 9 |  |  |  | 55 |  |
| Net cash used in financing activities |  |  | (7,557 | ) |  |  | (29,433 | ) |
| Net increase (decrease) in cash and cash equivalents |  |  | 16,507 |  |  |  | (5,685 | ) |
| Effect of exchange rate changes |  |  | (2,937 | ) |  |  | 202 |  |
| Cash and cash equivalents, beginning of period |  |  | 73,439 |  |  |  | 58,298 |  |
| Cash and cash equivalents, end of period |  | $ | 87,009 |  |  | $ | 52,815 |  |
| Supplemental disclosure of non-cash investing activities |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment included in accounts payable |  | $ | 784 |  |  | $ | 85 |  |

[0001193125-15-140997:8k_2_02:32]
Supplemental Information

[0001193125-15-140997:8k_2_02:33]
Acquisition Related Expenses, Amortizations and Adjustments

[0001193125-15-140997:8k_2_02:34]
(Unaudited)

[0001193125-15-140997:8k_2_02:35]
(In
thousands)

[0001193125-15-140997:8k_2_02:36]
On August 4, 2011, we closed on the acquisition of Bluesocket, Inc. and on May 4, 2012, we closed on the acquisition of the
Nokia Siemens Networks Broadband Access business (NSN BBA). Acquisition related expenses, amortizations and adjustments for the three months ended March 31, 2015 and 2014 for both transactions are as follows:

[0001193125-15-140997:8k_2_02:37]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
|  |  | 2015 |  |  | 2014 |  |
| Bluesocket, Inc. acquisition |  |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets and other purchase accounting adjustments |  | $ | 226 |  |  | $ | 246 |  |
| NSN BBA acquisition |  |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets |  |  | 241 |  |  |  | 302 |  |
| Amortization of other purchase accounting adjustments |  |  | 154 |  |  |  | 361 |  |
| Acquisition related professional fees, travel and other expenses |  |  | 6 |  |  |  | 48 |  |
| Subtotal |  |  | 401 |  |  |  | 711 |  |
| Total acquisition related expenses, amortizations and adjustments |  |  | 627 |  |  |  | 957 |  |
| Provision for income taxes |  |  | (213 | ) |  |  | (316 | ) |
| Total acquisition related expenses, amortizations and adjustments, net of tax |  | $ | 414 |  |  | $ | 641 |  |

[0001193125-15-140997:8k_2_02:38]
The acquisition related expenses, amortizations and adjustments above were recorded in the following Consolidated Statements
of Income categories for the three months ended March 31, 2015 and 2014:

[0001193125-15-140997:8k_2_02:39]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
|  |  | 2015 |  |  | 2014 |  |
| Revenue (adjustments to deferred revenue recognized in the period) |  | $ | 67 |  |  | $ | 243 |  |
| Cost of goods sold |  |  | 12 |  |  |  | 34 |  |
| Subtotal |  |  | 79 |  |  |  | 277 |  |
| Selling, general and administrative expenses |  |  | 12 |  |  |  | 55 |  |
| Research and development expenses |  |  | 536 |  |  |  | 625 |  |
| Subtotal |  |  | 548 |  |  |  | 680 |  |
| Total acquisition related expenses, amortizations and adjustments |  |  | 627 |  |  |  | 957 |  |
| Provision for income taxes |  |  | (213 | ) |  |  | (316 | ) |
| Total acquisition related expenses, amortizations and adjustments, net of tax |  | $ | 414 |  |  | $ | 641 |  |

[0001193125-15-140997:8k_2_02:40]
Supplemental Information

[0001193125-15-140997:8k_2_02:41]
Stock-based Compensation Expense

[0001193125-15-140997:8k_2_02:42]
(Unaudited)

[0001193125-15-140997:8k_2_02:43]
(In
thousands)

[0001193125-15-140997:8k_2_02:44]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
|  |  | 2015 |  |  | 2014 |  |
| Stock-based compensation expense included in cost of sales |  | $ | 90 |  |  | $ | 116 |  |
| Selling, general and administrative expense |  |  | 691 |  |  |  | 1,026 |  |
| Research and development expense |  |  | 858 |  |  |  | 915 |  |
| Stock-based compensation expense included in operating expenses |  |  | 1,549 |  |  |  | 1,941 |  |
| Total stock-based compensation expense |  |  | 1,639 |  |  |  | 2,057 |  |
| Tax benefit for expense associated with non-qualified options |  |  | (180 | ) |  |  | (284 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 1,459 |  |  | $ | 1,773 |  |

[0001193125-15-140997:8k_2_02:45]
Reconciliation of GAAP net income per share, diluted, to

[0001193125-15-140997:8k_2_02:46]
Non-GAAP net income per share, diluted

[0001193125-15-140997:8k_2_02:47]
(Unaudited)

[0001193125-15-140997:8k_2_02:48]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
|  |  | 2015 |  |  | 2014 |  |
| GAAP earnings per common share – diluted |  | $ | 0.06 |  |  | $ | 0.17 |  |
| Acquisition related expenses, amortizations and adjustments |  |  | 0.01 |  |  |  | 0.01 |  |
| Stock-based compensation expense |  |  | 0.03 |  |  |  | 0.03 |  |
| Non-GAAP earnings per common share – diluted |  | $ | 0.10 |  |  | $ | 0.21 |  |
