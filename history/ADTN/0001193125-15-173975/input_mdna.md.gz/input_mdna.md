# ADTN MD&A — 0001193125-15-173975


## mdna

[0001193125-15-173975:mdna:1]
[same as prior period, unchanged from 0001193125-14-398391:mdna:1]

[0001193125-15-173975:mdna:2]
[same as prior period, unchanged from 0001193125-14-398391:mdna:2]

[0001193125-15-173975:mdna:3]
[same as prior period, unchanged from 0001193125-14-398391:mdna:3]

[0001193125-15-173975:mdna:4]
[same as prior period, unchanged from 0001193125-14-398391:mdna:4]

[0001193125-15-173975:mdna:5]
[same as prior period, unchanged from 0001193125-14-398391:mdna:5]

[0001193125-15-173975:mdna:6]
[same as prior period, unchanged from 0001193125-14-398391:mdna:6]

[0001193125-15-173975:mdna:7]
Carrier Systems products are used by communications service providers to provide data, voice, and video services to consumers and enterprises. This
category includes the following product areas and related services:

[0001193125-15-173975:mdna:8]
[same as prior period, unchanged from 0001193125-14-398391:mdna:8]

[0001193125-15-173975:mdna:9]
|  | • |  | Total Access® 5000 Series of Multi-Service Access Node (MSAN) |

[0001193125-15-173975:mdna:10]
|  | • |  | hiX 5600 Series of MSANs |

[0001193125-15-173975:mdna:11]
[same as prior period, unchanged from 0001193125-14-398391:mdna:11]

[0001193125-15-173975:mdna:12]
|  | • |  | hiX 1100 Series of Fiber to the Node (FTTN) products |

[0001193125-15-173975:mdna:13]
|  | • |  | VDSL2 Vectoring based Digital Subscriber Line Access Multiplexer (DSLAM) products |

[0001193125-15-173975:mdna:14]
|  | • |  | ADTRAN 500 Series of FTTdp G.fast Distribution Point Units (DPU) |

[0001193125-15-173975:mdna:15]
[same as prior period, unchanged from 0001193125-14-398391:mdna:14]

[0001193125-15-173975:mdna:16]
[same as prior period, unchanged from 0001193125-14-398391:mdna:15]

[0001193125-15-173975:mdna:17]
[same as prior period, unchanged from 0001193125-14-398391:mdna:16]

[0001193125-15-173975:mdna:18]
|  | • |  | NetVanta 8400 Series of 10Gig Multi-service Edge Switches |

[0001193125-15-173975:mdna:19]
[same as prior period, unchanged from 0001193125-14-398391:mdna:17]

[0001193125-15-173975:mdna:20]
[same as prior period, unchanged from 0001193125-14-398391:mdna:18]

[0001193125-15-173975:mdna:21]
|  | • |  | Time Division Multiplexed (TDM) systems |

[0001193125-15-173975:mdna:22]
Business Networking products provide access to communication services and facilitate the delivery of cloud
connectivity and enterprise communications to the small and mid-sized enterprise (SME) market. This category includes the following product areas and related services:

[0001193125-15-173975:mdna:23]
[same as prior period, unchanged from 0001193125-14-398391:mdna:21]

[0001193125-15-173975:mdna:24]
[same as prior period, unchanged from 0001193125-14-398391:mdna:22]

[0001193125-15-173975:mdna:25]
[same as prior period, unchanged from 0001193125-14-398391:mdna:23]

[0001193125-15-173975:mdna:26]
[same as prior period, unchanged from 0001193125-14-398391:mdna:24]

[0001193125-15-173975:mdna:27]
[same as prior period, unchanged from 0001193125-14-398391:mdna:25]

[0001193125-15-173975:mdna:28]
|  | • |  | Access Routers |

[0001193125-15-173975:mdna:29]
|  | • |  | Enterprise Session Border Controllers (eSBC) |

[0001193125-15-173975:mdna:30]
|  | • |  | Managed Ethernet Switches |

[0001193125-15-173975:mdna:31]
|  | • |  | IP Business Gateways |

[0001193125-15-173975:mdna:32]
|  | • |  | Unified Communications (UC) solutions |

[0001193125-15-173975:mdna:33]
|  | • |  | Carrier Ethernet Network Terminating Equipment (NTE) |

[0001193125-15-173975:mdna:34]
|  | • |  | Carrier Ethernet Routers and Gateways |

[0001193125-15-173975:mdna:35]
[same as prior period, unchanged from 0001193125-14-398391:mdna:31]

[0001193125-15-173975:mdna:36]
[same as prior period, unchanged from 0001193125-14-398391:mdna:33]

[0001193125-15-173975:mdna:37]
[same as prior period, unchanged from 0001193125-14-398391:mdna:34]

[0001193125-15-173975:mdna:38]
[same as prior period, unchanged from 0001193125-14-398391:mdna:35]

[0001193125-15-173975:mdna:39]
[same as prior period, unchanged from 0001193125-14-398391:mdna:36]

[0001193125-15-173975:mdna:40]
[same as prior period, unchanged from 0001193125-14-398391:mdna:37]

[0001193125-15-173975:mdna:41]
[same as prior period, unchanged from 0001193125-14-398391:mdna:38]

[0001193125-15-173975:mdna:42]
[same as prior period, unchanged from 0001193125-14-398391:mdna:39]

[0001193125-15-173975:mdna:43]
[same as prior period, unchanged from 0001193125-14-398391:mdna:40]

[0001193125-15-173975:mdna:44]
Sales were $142.8 million for the three months ended March 31, 2015 compared to $147.0 million for
the three months ended March 31, 2014. Product revenues for our three core areas, Broadband Access, Optical and Internetworking, were $131.5 million for the three months ended March 31, 2015 compared to $131.3 million for the three months
ended March 31, 2014. Our gross margin decreased to 45.9% for the three months ended March 31, 2015 from 52.9% for the three months ended March 31, 2014. Our operating income margin decreased to 1.4% for the three months ended
March 31, 2015 from 7.7% for the three months ended March 31, 2014. Net income was $3.3 million for the three months ended March 31, 2015 compared to $9.6 million for the three months ended March 31, 2014. Our effective tax rate
increased to 39.8% for the three months ended March 31, 2015 from 34.6% for the three months ended March 31, 2014. Earnings per share, assuming dilution, were $0.06 for the three months ended March 31, 2015 compared to $0.17 for the
three months ended March 31, 2014.

[0001193125-15-173975:mdna:45]
23

[0001193125-15-173975:mdna:46]
[same as prior period, unchanged from 0001193125-14-398391:mdna:43]

[0001193125-15-173975:mdna:47]
[same as prior period, unchanged from 0001193125-14-398391:mdna:44]

[0001193125-15-173975:mdna:48]
Accordingly, our historical financial performance is not necessarily a meaningful indicator of future results, and, in
general, management expects that our financial results may vary from period to period. A list of factors that could materially affect our business, financial condition or operating results is included under “Factors That Could Affect Our Future
Results” in “Management’s Discussion and Analysis of Financial Condition and Results of Operations” contained in Item 2 of Part I of this report. These factors have also been discussed in more detail in Item 1A of Part
I in our most recent Annual Report on Form 10-K for the year ended December 31, 2014, filed on February 24, 2015 with the SEC.

[0001193125-15-173975:mdna:49]
[same as prior period, unchanged from 0001193125-14-398391:mdna:46]

[0001193125-15-173975:mdna:50]
Our critical accounting policies and estimates have not changed significantly from those detailed in our most recent
Annual Report on Form 10-K for the year ended December 31, 2014, filed on February 24, 2015 with the SEC.

[0001193125-15-173975:mdna:51]
[same as prior period, unchanged from 0001193125-14-398391:mdna:48]

[0001193125-15-173975:mdna:52]
[same as prior period, unchanged from 0001193125-14-398391:mdna:49]

[0001193125-15-173975:mdna:53]
RESULTS OF OPERATIONS – THREE MONTHS ENDED MARCH 31, 2015 COMPARED TO THREE MONTHS ENDED MARCH 31, 2014

[0001193125-15-173975:mdna:54]
[same as prior period, unchanged from 0001193125-14-398391:mdna:51]

[0001193125-15-173975:mdna:55]
ADTRAN’s sales decreased 2.8% from
$147.0 million in the three months ended March 31, 2014 to $142.8 million in the three months ended March 31, 2015. The decrease in sales for the three months ended March 31, 2015 is primarily attributable to a $4.4 million decrease
in sales of our HDSL and other legacy products and a $2.8 million decrease in sales of our Internetworking products, partially offset by a $3.3 million increase in sales of our Broadband Access products. Sales during the three months ended
March 31, 2015 were also negatively impacted by the strengthening of the U.S. dollar against the Euro.

[0001193125-15-173975:mdna:56]
Carrier Networks sales decreased 1.8% from $118.2 million in the three months ended March 31, 2014 to $116.0
million in the three months ended March 31, 2015. The decrease in sales for the three months ended March 31, 2015 is primarily attributable to decreases in sales of our HDSL and other legacy products and Internetworking products, partially
offset by an increase in sales of our Broadband Access products. The decrease in sales of HDSL and other legacy products for the three months ended March 31, 2015 has been expected as customers continue to upgrade their networks to deliver
higher bandwidth services by migrating to newer technologies, including to our core products from our Broadband Access, Internetworking and Optical product lines. While we expect that revenues from HDSL and our other legacy products will continue to
decline over time, these revenues may continue for years because of the time required for our customers to transition to newer technologies. The decrease in sales of our Internetworking products for the Carrier Networks division is primarily
attributable to a decrease in sales of our EFM products, partially offset by an increase in sales of our FTTP ONT products. The increase in sales of our Broadband Access products is primarily attributable to increases in hiX 5600 and Total Access
5000 MSAN product sales, partially offset by the impact of the strengthening of the U.S. dollar against the Euro.

[0001193125-15-173975:mdna:57]
Enterprise Networks sales decreased
7.0% from $28.8 million in the three months ended March 31, 2014 to $26.8 million in the three months ended March 31, 2015. The decrease in sales for the three months ended March 31, 2015 is primarily attributable to decreases in
sales of our Internetworking products. The decrease in sales of our Internetworking products for the Enterprise Networks division was primarily attributable to soft demand in our regional carrier distribution channels and VAR channels, partially
offset by improvements in large carrier channel sales. Internetworking product sales attributable to Enterprise Networks were 93.8% of the division’s sales in the three months ended March 31, 2015, compared to 94.3% in the three months
ended March 31, 2014. Legacy products primarily comprise the remainder of Enterprise Networks sales. Enterprise Networks sales as a percentage of total sales decreased from 19.6% for the three months ended March 31, 2014 to 18.8% for the
three months ended March 31, 2015.

[0001193125-15-173975:mdna:58]
International sales, which are included in the Carrier Networks and Enterprise Networks amounts discussed above,
increased 9.4% from $54.3 million in the three months ended March 31, 2014 to $59.4 million in the three months ended March 31, 2015. International sales, as a percentage of total sales, increased from 36.9% for the three months ended
March 31, 2014 to 41.6% for the three months ended March 31, 2015. The increase in international sales in the three months ended March 31, 2015 compared to the three months ended March 31, 2014 is primarily attributable to an
increase in sales in the EMEA region, partially offset by decreases in sales in Latin America and the Asia-Pacific region.

[0001193125-15-173975:mdna:59]
Carrier System product sales
increased $0.9 million in the three months ended March 31, 2015 compared to the three months ended March 31, 2014. The increase for the three months ended March 31, 2015 is primarily attributable to a $3.3 million increase in
Broadband Access product sales, partially offset by a $2.1 million decrease in legacy product sales. The changes for the three months ended March 31, 2015 are primarily attributable to the factors discussed above.

[0001193125-15-173975:mdna:60]
Business Networking product sales decreased $2.5 million in the three months ended March 31, 2015 compared to the three months ended March 31, 2014.
The decrease for the three months ended March 31, 2015 is primarily attributable to a $2.8 million decrease in Internetworking product sales. The decrease for the three ended March 31, 2015 is primarily attributable to the factors
discussed above.

[0001193125-15-173975:mdna:61]
Loop Access product sales decreased $2.5 million in the three months ended March 31, 2015 compared to the three months ended
March 31, 2014. The decrease for the three months ended March 31, 2015 is primarily attributable to a $2.2 million decrease in HDSL product sales, which is discussed further above.

[0001193125-15-173975:mdna:62]
[same as prior period, unchanged from 0001193125-14-398391:mdna:61]

[0001193125-15-173975:mdna:63]
As a percentage of sales, cost of
sales increased from 47.1% in the three months ended March 31, 2014 to 54.1% in the three months ended March 31, 2015. The increase for the three months ended March 31, 2015 is primarily attributable to the strengthening of the U.S.
dollar against the Euro, an increase in international sales at lower gross margins, shifts in customer mix, higher services mix, and customer price movements to achieve market share position.

[0001193125-15-173975:mdna:64]
Carrier Networks cost of sales, as a percent of division sales, increased from 48.1% in the three months ended
March 31, 2014 to 57.0% in the three months ended March 31, 2015. The increase for the three months ended March 31, 2015 is primarily attributable to the strengthening of the U.S. dollar against the Euro, an increase in international
sales at lower gross margins, higher services mix, and customer price movements to achieve market share position.

[0001193125-15-173975:mdna:65]
Enterprise Networks cost of sales, as a
percent of division sales, decreased from 43.0% in the three months ended March 31, 2014 to 41.4% in the three months ended March 31, 2015. The decrease for the three months ended March 31, 2015 is primarily attributable to customer
and product mix.

[0001193125-15-173975:mdna:66]
An important part of our strategy is to reduce the product cost of each succeeding product generation and then to lower the
product’s price based on the cost savings achieved. This may cause variations in our gross profit percentage due to timing differences between the recognition of cost reductions and the lowering of product selling prices.

[0001193125-15-173975:mdna:67]
[same as prior period, unchanged from 0001193125-14-398391:mdna:66]

[0001193125-15-173975:mdna:68]
Selling, general and administrative expenses decreased 8.5% from $33.9 million in the three months ended March 31, 2014 to $31.1 million in the three
months ended March 31, 2015. The decrease in selling, general and administrative expenses for the three months ended March 31, 2015 is primarily attributable to a decrease in compensation expense and legal expense.

[0001193125-15-173975:mdna:69]
Selling, general and administrative expenses as a percentage of sales decreased from 23.1% in the three months ended March 31, 2014 to 21.7% in the three
months ended March 31, 2015. Selling, general and administrative expenses as a percentage of sales may fluctuate whenever there is a significant fluctuation in revenues for the periods being compared.

[0001193125-15-173975:mdna:70]
[same as prior period, unchanged from 0001193125-14-398391:mdna:69]

[0001193125-15-173975:mdna:71]
Research and
development expenses remained constant at $32.6 million in the three months ended March 31, 2014 and $32.5 million in the three months ended March 31, 2015.

[0001193125-15-173975:mdna:72]
As a percentage of sales, research and development expenses increased from 22.1% in the three months ended March 31, 2014 to 22.8% in the three months
ended March 31, 2015. Research and development expenses as a percentage of sales will fluctuate whenever there are incremental product development activities or a significant fluctuation in revenues for the periods being compared.

[0001193125-15-173975:mdna:73]
[same as prior period, unchanged from 0001193125-14-398391:mdna:72]

[0001193125-15-173975:mdna:74]
[same as prior period, unchanged from 0001193125-14-398391:mdna:73]

[0001193125-15-173975:mdna:75]
Interest and dividend income decreased 27.9% from $1.3 million in the three months ended March 31, 2014 to $0.9 million in the three months
ended March 31, 2015. The decrease in interest and dividend income is primarily attributable to a reduction in investment principal partially offset by a slightly higher rate of return. See “Liquidity and Capital Resources” below for
additional information on our taxable revenue bond.

[0001193125-15-173975:mdna:76]
[same as prior period, unchanged from 0001193125-14-398391:mdna:75]

[0001193125-15-173975:mdna:77]
Interest expense, which is primarily related to our taxable revenue bond, remained constant at $0.2 million in the three months ended March 31, 2014 and
$0.1 million in the three months ended March 31, 2015, as we had no substantial change in our fixed-rate borrowing. See “Liquidity and Capital Resources” below for additional information on our revenue bond.

[0001193125-15-173975:mdna:78]
[same as prior period, unchanged from 0001193125-14-398391:mdna:77]

[0001193125-15-173975:mdna:79]
Net realized investment gain increased 42.1% from $2.2 million in the three months ended March 31, 2014 to $3.1 million in the three months ended
March 31, 2015. The increase in realized investment gains for the three months ended March 31, 2015 is primarily attributable to increased gains from the sale of equity securities and the rebalancing of our investment portfolio. See
“Investing Activities” in “Liquidity and Capital Resources” below for additional information.

[0001193125-15-173975:mdna:80]
[same as prior period, unchanged from 0001193125-14-398391:mdna:79]

[0001193125-15-173975:mdna:81]
Other income (expense), net, comprised primarily of miscellaneous income, gains and losses on foreign currency transactions, investment account
management fees, and scrap raw material sales, changed from $0.1 million of income in the three months ended March 31, 2014 to $0.4 million of expense in the three months ended March 31, 2015. The change in the three months ended
March 31, 2015 is primarily attributable to losses on foreign currency transactions during the first quarter of 2015.

[0001193125-15-173975:mdna:82]
[same as prior period, unchanged from 0001193125-14-398391:mdna:81]

[0001193125-15-173975:mdna:83]
Our effective tax rate increased from 34.6% in the three months ended March 31, 2014 to 39.8% in the three months ended March 31, 2015.
The increase in the effective tax rate between the two periods is primarily attributable to the release of a valuation allowance attributable to a foreign subsidiary in 2014.

[0001193125-15-173975:mdna:84]
[same as prior period, unchanged from 0001193125-14-398391:mdna:83]

[0001193125-15-173975:mdna:85]
As a result of the above factors, net
income decreased $6.3 million from $9.6 million in the three months ended March 31, 2014 to $3.3 million in the three months ended March 31, 2015.

[0001193125-15-173975:mdna:86]
As a percentage of sales, net income decreased from 6.5% in the three months ended March 31, 2014 to 2.3% in the three months ended March 31, 2015.

[0001193125-15-173975:mdna:87]
[same as prior period, unchanged from 0001193125-14-398391:mdna:86]

[0001193125-15-173975:mdna:88]
[same as prior period, unchanged from 0001193125-14-398391:mdna:87]

[0001193125-15-173975:mdna:89]
We intend to finance our operations with cash flow from operations. We have used, and expect to continue to use, the cash generated from operations
for working capital, purchases of treasury stock, shareholder dividends, and other general corporate purposes, including (i) product development activities to enhance our existing products and develop new products and (ii) expansion of
sales and marketing activities. We believe our cash and cash equivalents, investments and cash generated from operations to be adequate to meet our operating and capital needs for at least the next 12 months.

[0001193125-15-173975:mdna:90]
At March 31, 2015, cash on hand was $87.0 million and short-term investments were $78.8 million, which resulted in available short-term liquidity of
$165.8 million. At December 31, 2014, our cash on hand of $73.4 million and short-term investments of $46.9 million resulted in available short-term liquidity of $120.4 million. The increase in short-term liquidity from December 31, 2014
to March 31, 2015 is primarily attributable to a reallocation of our investments to provide additional funds for our short-term cash needs, which includes operating activities, capital expenditures, purchase of treasury stock, and shareholder
dividends.

[0001193125-15-173975:mdna:91]
[same as prior period, unchanged from 0001193125-14-398391:mdna:90]

[0001193125-15-173975:mdna:92]
Our working
capital, which consists of current assets less current liabilities, increased 16.0% from $232.1 million as of December 31, 2014 to $269.1 million as of March 31, 2015. The quick ratio, defined as cash, cash equivalents, short-term
investments, and net accounts receivable, divided by current liabilities, increased from 1.75 as of December 31, 2014 to 1.94 as of March 31, 2015. The current ratio, defined as current assets divided by current liabilities, increased from
2.95 as of December 31, 2014 to 3.04 as of March 31, 2015. The increases in our working capital, quick ratio and current ratio are primarily attributable to an increase in cash and short-term investments, partially offset by an increase in
accounts payable.

[0001193125-15-173975:mdna:93]
Net accounts receivable increased 2.7% from $88.5 million at December 31, 2014 to $90.9 million at
March 31, 2015. Our allowance for doubtful accounts was $0.1 million at December 31, 2014 and $20 thousand at March 31, 2015. Quarterly accounts receivable days sales outstanding (DSO) remained constant at 57 days as of
December 31, 2014 and March 31, 2015. The change in net accounts receivable is due to changes in customer mix and the timing of sales and collections during the quarter. Certain international customers can have longer payment terms than
U.S. customers. Other receivables decreased from $33.3 million at December 31, 2014 to $30.0 million at March 31, 2015. The decrease in other receivables is primarily attributable to the timing of shipments and collections for materials
supplied to our contract manufacturers during the quarter.

[0001193125-15-173975:mdna:94]
Quarterly inventory turnover decreased from 3.5 turns as of December 31, 2014 to 3.4
turns as of March 31, 2015. Inventory increased 7.4% from December 31, 2014 to March 31, 2015. We expect inventory levels to fluctuate as we attempt to maintain sufficient inventory in response to seasonal cycles of our business
ensuring competitive lead times while managing the risk of inventory obsolescence that may occur due to rapidly changing technology and customer demand.

[0001193125-15-173975:mdna:95]
Accounts payable increased 30.6% from $56.4 million at December 31, 2014 to $73.7 million at March 31, 2015. Accounts payable will fluctuate due to
variations in the timing of the receipt of supplies, inventory and services and our subsequent payments for these purchases.

[0001193125-15-173975:mdna:96]
[same as prior period, unchanged from 0001193125-14-398391:mdna:95]

[0001193125-15-173975:mdna:97]
Capital expenditures totaled approximately $2.4 million and $2.0 million for the three months ended March 31, 2015 and 2014, respectively. These
expenditures were primarily used to purchase manufacturing and test equipment and computer software and hardware.

[0001193125-15-173975:mdna:98]
Our combined short-term and long-term
investments decreased $12.1 million from $327.6 million at December 31, 2014 to $315.4 million at March 31, 2015. This decrease reflects the impact of our cash needs for capital expenditures, share repurchases, dividends, as well as net
realized and unrealized losses and amortization of net premiums on our combined investments, partially offset by additional funds available for investment provided by our operating activities and stock option exercises by our employees.

[0001193125-15-173975:mdna:99]
We invest all available cash not required for immediate use in operations primarily in securities that we believe bear minimal risk of loss. At March 31,
2015 these investments included corporate bonds of $132.4 million, municipal fixed-rate bonds of $93.1 million, and municipal variable rate demand notes of $4.2 million. At December 31, 2014, these investments included corporate bonds of $111.3
million, municipal fixed-rate bonds of $127.8 million, and municipal variable rate demand notes of $2.5 million. As of March 31, 2015, our corporate bonds, municipal fixed-rate bonds, and municipal variable rate demand notes were classified as
available-for-sale and had a combined duration of 1.0 years with an average credit rating of A+. Because our bond portfolio has a high quality rating and contractual maturities of a short duration, we are able to obtain prices for these bonds
derived from observable market inputs, or for similar securities traded in an active market, on a daily basis.

[0001193125-15-173975:mdna:100]
Our long-term investments decreased 15.7%
from $280.6 million at December 31, 2014 to $236.7 million at March 31, 2015. Long-term investments at March 31, 2015 and December 31, 2014 included an investment in a certificate of deposit of $30.0 million, which serves as
collateral for our revenue bond, as discussed below. We have various equity investments included in long-term investments at a cost of $26.6 million and $26.4 million, and with a fair value of $37.6 million and $38.3 million, at March 31, 2015
and December 31, 2014, respectively.

[0001193125-15-173975:mdna:101]
Long-term investments at March 31, 2015 and December 31, 2014 also included $16.6 million and $16.3
million, respectively, related to our deferred compensation plans, and $1.5 million, respectively, of other investments carried at cost, consisting of interests in two private equity funds and an investment in a privately held telecommunications
equipment manufacturer.

[0001193125-15-173975:mdna:102]
We review our investment portfolio for potential “other-than-temporary” declines in value on an
individual investment basis. We assess, on a quarterly basis, significant declines in value which may be considered other-than-temporary and, if necessary, recognize and record the appropriate charge to write-down the carrying value of such
investments. In making this assessment, we take into consideration qualitative and quantitative information, including but not limited to the following: the magnitude and duration of historical declines in market prices, credit rating activity,
assessments of liquidity, public filings, and statements made by the issuer. We generally begin our identification of potential other-than-temporary impairments by reviewing any security with a fair value that has declined from its original or
adjusted cost basis by 25% or more for six or more consecutive months. We then evaluate the individual security based on the previously identified factors to determine the amount of the write-down, if any. For the three months ended March 31,
2015 and 2014, other-than-temporary impairment charges were not significant.

[0001193125-15-173975:mdna:103]
[same as prior period, unchanged from 0001193125-14-398391:mdna:102]

[0001193125-15-173975:mdna:104]
[same as prior period, unchanged from 0001193125-14-398391:mdna:103]

[0001193125-15-173975:mdna:105]
In July 2003, our Board of Directors elected to
begin declaring quarterly dividends on our common stock considering the tax treatment of dividends and adequate levels of Company liquidity. During the three months ended March 31, 2015, we paid dividends totaling $4.8 million.

[0001193125-15-173975:mdna:106]
[same as prior period, unchanged from 0001193125-14-398391:mdna:105]

[0001193125-15-173975:mdna:107]
We have amounts outstanding under loans made
pursuant to an Alabama State Industrial Development Authority revenue bond (the Bond) which totaled $30.0 million at March 31, 2015 and December 31, 2014. At March 31, 2015, the estimated fair value of the Bond was approximately
$29.7 million, based on a debt security with a comparable interest rate and maturity and a Standard & Poor’s credit rating of AAA. Included in long-term investments are restricted funds in the amount of $30.0 million
at March 31, 2015 and December 31, 2014, which is a collateral deposit against the principal amount of the Bond. We have the right to set-off the balance of the Bond with the collateral deposit in order to reduce the balance of the
indebtedness. The Bond matures on January 1, 2020, and bears interest at the rate of 2% per annum. In conjunction with this program, we are eligible to receive certain economic incentives from the state of Alabama that reduce the amount of
payroll withholdings we are required to remit to the state for those employment positions that qualify under this program. We are required to make payments in the amounts necessary to pay the interest on the amounts currently outstanding. It is our
intent to make annual principal payments in addition to the interest amounts that are due. In connection with this decision, $1.2 million of the Bond has been classified as a current liability in accounts payable in the Consolidated Balance Sheet at
March 31, 2015.

[0001193125-15-173975:mdna:108]
[same as prior period, unchanged from 0001193125-14-398391:mdna:107]

[0001193125-15-173975:mdna:109]
Since
1997, our Board of Directors has approved multiple share repurchase programs that have authorized open market repurchase transactions of up to 45.0 million shares of our common stock. This authorization will be implemented through open market
or private purchases from time to time as conditions warrant. During the three months ended March 31, 2015, we repurchased 0.1 million shares of our common stock at an average price of $21.52 per share. We currently have the authority to
purchase an additional 4.7 million shares of our common stock under the current plans approved by the Board of Directors.

[0001193125-15-173975:mdna:110]
[same as prior period, unchanged from 0001193125-14-398391:mdna:110]

[0001193125-15-173975:mdna:111]
To accommodate employee stock option exercises, we issued 17 thousand shares of treasury stock for $0.3 million during the three months ended
March 31, 2015.

[0001193125-15-173975:mdna:112]
[same as prior period, unchanged from 0001193125-14-398391:mdna:112]

[0001193125-15-173975:mdna:113]
We do not have off-balance sheet financing arrangements and have not engaged in any related party transactions or arrangements with unconsolidated entities or
other persons that are reasonably likely to materially affect liquidity or the availability of or requirements for capital resources. During the three months ended March 31, 2015, there have been no material changes in contractual obligations
and commercial commitments from those discussed in our most recent Annual Report on Form 10-K for the year ended December 31, 2014 filed on February 24, 2015 with the SEC.

[0001193125-15-173975:mdna:114]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, and we have contributed $8.4 million as of March 31, 2015, of
which $7.7 million has been applied to these commitments.

[0001193125-15-173975:mdna:115]
[same as prior period, unchanged from 0001193125-14-398391:mdna:115]

[0001193125-15-173975:mdna:116]
[same as prior period, unchanged from 0001193125-14-398391:mdna:116]

[0001193125-15-173975:mdna:117]
[same as prior period, unchanged from 0001193125-14-398391:mdna:117]

[0001193125-15-173975:mdna:118]
[same as prior period, unchanged from 0001193125-14-398391:mdna:118]

[0001193125-15-173975:mdna:119]
[same as prior period, unchanged from 0001193125-14-398391:mdna:119]

[0001193125-15-173975:mdna:120]
[same as prior period, unchanged from 0001193125-14-398391:mdna:120]

[0001193125-15-173975:mdna:121]
[same as prior period, unchanged from 0001193125-14-398391:mdna:121]

[0001193125-15-173975:mdna:122]
[same as prior period, unchanged from 0001193125-14-398391:mdna:122]

[0001193125-15-173975:mdna:123]
[same as prior period, unchanged from 0001193125-14-398391:mdna:123]

[0001193125-15-173975:mdna:124]
[same as prior period, unchanged from 0001193125-14-398391:mdna:124]

[0001193125-15-173975:mdna:125]
[same as prior period, unchanged from 0001193125-14-398391:mdna:125]

[0001193125-15-173975:mdna:126]
[same as prior period, unchanged from 0001193125-14-398391:mdna:126]

[0001193125-15-173975:mdna:127]
[same as prior period, unchanged from 0001193125-14-398391:mdna:127]

[0001193125-15-173975:mdna:128]
[same as prior period, unchanged from 0001193125-14-398391:mdna:128]

[0001193125-15-173975:mdna:129]
|  | • |  | Our strategy of outsourcing a portion of our manufacturing requirements to subcontractors located in various international regions may result in us not meeting our cost, quality or performance standards. |

[0001193125-15-173975:mdna:130]
|  | • |  | Our dependence on a limited number of suppliers for certain raw materials and key components may prevent us from delivering our products on a timely basis, which could have a material adverse effect on customer relations and operating results. |

[0001193125-15-173975:mdna:131]
[same as prior period, unchanged from 0001193125-14-398391:mdna:131]

[0001193125-15-173975:mdna:132]
[same as prior period, unchanged from 0001193125-14-398391:mdna:132]

[0001193125-15-173975:mdna:133]
[same as prior period, unchanged from 0001193125-14-398391:mdna:133]

[0001193125-15-173975:mdna:134]
[same as prior period, unchanged from 0001193125-14-398391:mdna:134]

[0001193125-15-173975:mdna:135]
[same as prior period, unchanged from 0001193125-14-398391:mdna:135]

[0001193125-15-173975:mdna:136]
[same as prior period, unchanged from 0001193125-14-398391:mdna:136]

[0001193125-15-173975:mdna:137]
[same as prior period, unchanged from 0001193125-14-398391:mdna:137]

[0001193125-15-173975:mdna:138]
[same as prior period, unchanged from 0001193125-14-398391:mdna:139]

[0001193125-15-173975:mdna:139]
[same as prior period, unchanged from 0001193125-14-398391:mdna:140]

[0001193125-15-173975:mdna:140]
|  | • |  | We may incur liabilities or become subject to litigation that would have a material effect on our business. |

[0001193125-15-173975:mdna:141]
[same as prior period, unchanged from 0001193125-14-398391:mdna:142]

[0001193125-15-173975:mdna:142]
[same as prior period, unchanged from 0001193125-14-398391:mdna:143]

[0001193125-15-173975:mdna:143]
30

[0001193125-15-173975:mdna:144]
[same as prior period, unchanged from 0001193125-14-398391:mdna:144]

[0001193125-15-173975:mdna:145]
[same as prior period, unchanged from 0001193125-14-398391:mdna:145]

[0001193125-15-173975:mdna:146]
[same as prior period, unchanged from 0001193125-14-398391:mdna:146]

[0001193125-15-173975:mdna:147]
[same as prior period, unchanged from 0001193125-14-398391:mdna:147]

[0001193125-15-173975:mdna:148]
[same as prior period, unchanged from 0001193125-14-398391:mdna:148]

[0001193125-15-173975:mdna:149]
[same as prior period, unchanged from 0001193125-14-398391:mdna:149]

[0001193125-15-173975:mdna:150]
[same as prior period, unchanged from 0001193125-14-398391:mdna:150]

[0001193125-15-173975:mdna:151]
[same as prior period, unchanged from 0001193125-14-398391:mdna:151]

[0001193125-15-173975:mdna:152]
The foregoing
list of risks is not exclusive. For a more detailed description of the risk factors associated with our business, see Item 1A of our Annual Report on Form 10-K for the year ended December 31, 2014, filed on February 24, 2015 with the
SEC.
