# ADTN notes — 0001193125-15-173975


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-15-173975:notes:1]
14. COMMITMENTS AND CONTINGENCIES

[0001193125-15-173975:notes:2]
In the ordinary course of business, we may be subject to various
 legal proceedings and claims, including employment disputes, patent
 claims, disputes over contract agreements and other commercial
 disputes. In some cases, claimants seek damages or other relief,
 such as royalty payments related to patents, which, if granted,
 could require significant expenditures. Although the outcome of any
 claim or litigation can never be certain, it is our opinion that
 the outcome of all contingencies of which we are currently aware
 will not materially affect our business, operations, financial
 condition or cash flows.

[0001193125-15-173975:notes:3]
We have committed to invest up to an aggregate of $7.9 million in
 two private equity funds, and we have contributed $8.4 million as
 of March 31, 2015, of which $7.7 million has been applied to
 these commitments.


## us-gaap:EarningsPerShareTextBlock

[0001193125-15-173975:notes:4]
[same as prior period, unchanged from 0001193125-14-398391:notes:4]

[0001193125-15-173975:notes:5]
A summary of the calculation of basic and diluted earnings per
 share for the three months ended March 31, 2015 and 2014 is as
 follows:

[0001193125-15-173975:notes:6]
|  |  | Three Months Ended March 31, |  |
| (In thousands, except per share amounts) |  | 2015 |  |  | 2014 |  |
| Numerator |  |  |  |  |  |  |  |  |
| Net income |  | $ | 3,317 |  |  | $ | 9,607 |  |
| Denominator |  |  |  |  |  |  |  |  |
| Weighted average number of shares – basic |  |  | 53,399 |  |  |  | 56,751 |  |
| Effect of dilutive securities |  |  |  |  |  |  |  |  |
| Stock options |  |  | 220 |  |  |  | 602 |  |
| Restricted stock and restricted stock units |  |  | 15 |  |  |  | 15 |  |
| Weighted average number of shares – diluted |  |  | 53,634 |  |  |  | 57,368 |  |
| Net income per share – basic |  | $ | 0.06 |  |  | $ | 0.17 |  |
| Net income per share – diluted |  | $ | 0.06 |  |  | $ | 0.17 |  |

[0001193125-15-173975:notes:7]
Anti-dilutive options to purchase common stock outstanding were
 excluded from the above calculations. Anti-dilutive options totaled
 5.6 million and 3.1 million for the three months ended
 March 31, 2015 and 2014, respectively.


## us-gaap:ScheduleOfShareBasedPaymentAwardStockOptionsValuationAssumptionsTableTextBlock

[0001193125-15-173975:notes:8]
The weighted-average assumptions and value of options granted for
 the three months ended March 31, 2015 and 2014 are summarized
 as follows:

[0001193125-15-173975:notes:9]
|  |  | Three Months Ended |  |
|  |  | March 31, 2015 |  |  | March 31, 2014 |  |
| Expected volatility |  |  | 38.75 | % |  |  | 39.57 | % |
| Risk-free interest rate |  |  | 1.46 | % |  |  | 1.86 | % |
| Expected dividend yield |  |  | 1.60 | % |  |  | 1.38 | % |
| Expected life (in years) |  |  | 6.47 |  |  |  | 6.25 |  |
| Weighted-average estimated value |  | $ | 7.63 |  |  | $ | 9.28 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001193125-15-173975:notes:10]
[same as prior period, unchanged from 0001193125-14-398391:notes:13]

[0001193125-15-173975:notes:11]
|  |  | Fair Value Measurements at March 31, 2015 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial paper |  | $ | 11,997 |  |  | $ | — |  |  | $ | 11,997 |  |  | $ | — |  |
| Money market funds |  |  | 3,228 |  |  |  | 3,228 |  |  |  | — |  |  |  | — |  |
| Cash equivalents |  |  | 15,225 |  |  |  | 3,228 |  |  |  | 11,997 |  |  |  | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 16,572 |  |  |  | 16,572 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 132,388 |  |  |  | — |  |  |  | 132,388 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 93,117 |  |  |  | — |  |  |  | 93,117 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 4,245 |  |  |  | — |  |  |  | 4,245 |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – technology industry |  |  | 9,034 |  |  |  | 9,034 |  |  |  | — |  |  |  | — |  |
| Marketable equity securities – other |  |  | 28,589 |  |  |  | 28,589 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 283,945 |  |  |  | 54,195 |  |  |  | 229,750 |  |  |  | — |  |
| Total |  | $ | 299,170 |  |  | $ | 57,423 |  |  | $ | 241,747 |  |  | $ | — |  |

[0001193125-15-173975:notes:12]
|  |  | Fair Value Measurements at December 31, 2014 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,163 |  |  | $ | 1,163 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 16,294 |  |  |  | 16,294 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 111,261 |  |  |  | — |  |  |  | 111,261 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 127,787 |  |  |  | — |  |  |  | 127,787 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 2,465 |  |  |  | — |  |  |  | 2,465 |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – technology industry |  |  | 9,661 |  |  |  | 9,661 |  |  |  | — |  |  |  | — |  |
| Marketable equity securities – other |  |  | 28,594 |  |  |  | 28,594 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 296,062 |  |  |  | 54,549 |  |  |  | 241,513 |  |  |  | — |  |
| Total |  | $ | 297,225 |  |  | $ | 55,712 |  |  | $ | 241,513 |  |  | $ | — |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001193125-15-173975:notes:13]
8. GOODWILL AND INTANGIBLE ASSETS

[0001193125-15-173975:notes:14]
Goodwill, all of which relates to our acquisition of Bluesocket,
 Inc. and is included in our Enterprise Networks division, was $3.5
 million at March 31, 2015 and December 31, 2014. We
 evaluate the carrying value of goodwill during the fourth quarter
 of each year and between annual evaluations if events occur or
 circumstances change that would more likely than not reduce the
 fair value of the reporting unit below its carrying amount. We have
 elected to first assess the qualitative factors to determine
 whether it is more likely than not that the fair value of the
 reporting unit to which the goodwill is assigned is less than its
 carrying amount as a basis for determining whether it is necessary
 to perform the two-step impairment test. If we determine that it is
 more likely than not that its fair value is less than its carrying
 amount, then the two-step impairment test will be performed. There
 have been no impairment losses recorded since acquisition.

[0001193125-15-173975:notes:15]
Intangible assets are included in other assets in the accompanying
 Consolidated Balance Sheets and include intangibles acquired in
 conjunction with our acquisitions of Objectworld Communications
 Corporation on September 15, 2009, Bluesocket, Inc. on
 August 4, 2011, and the NSN BBA business on May 4,
 2012.

[0001193125-15-173975:notes:16]
The following table presents our intangible assets as of
 March 31, 2015 and December 31, 2014:

[0001193125-15-173975:notes:17]
| (In thousands) |  | March 31, 2015 |  |  | December 31, 2014 |  |
|  |  | Gross Value |  |  | Accumulated Amortization |  |  | Net Value |  |  | Gross Value |  |  | Accumulated Amortization |  |  | Net Value |  |
| Customer relationships |  | $ | 5,787 |  |  | $ | (2,146 | ) |  | $ | 3,641 |  |  | $ | 6,310 |  |  | $ | (2,136 | ) |  | $ | 4,174 |  |
| Developed technology |  |  | 5,696 |  |  |  | (3,660 | ) |  |  | 2,036 |  |  |  | 6,005 |  |  |  | (3,577 | ) |  |  | 2,428 |  |
| Intellectual property |  |  | 2,340 |  |  |  | (1,603 | ) |  |  | 737 |  |  |  | 2,340 |  |  |  | (1,520 | ) |  |  | 820 |  |
| Trade names |  |  | 270 |  |  |  | (220 | ) |  |  | 50 |  |  |  | 270 |  |  |  | (205 | ) |  |  | 65 |  |
| Other |  |  | 11 |  |  |  | (11 | ) |  |  | — |  |  |  | 12 |  |  |  | (11 | ) |  |  | 1 |  |
| Total |  | $ | 14,104 |  |  | $ | (7,640 | ) |  | $ | 6,464 |  |  | $ | 14,937 |  |  | $ | (7,449 | ) |  | $ | 7,488 |  |

[0001193125-15-173975:notes:18]
Amortization expense, all of which relates to business
 acquisitions, was $0.5 million and $0.6 million for the three
 months ended March 31, 2015 and 2014, respectively.

[0001193125-15-173975:notes:19]
As of March 31, 2015, the estimated future amortization
 expense of our intangible assets is as follows:

[0001193125-15-173975:notes:20]
| (In thousands) |  | Amount |  |
| Remainder of 2015 |  | $ | 1,413 |  |
| 2016 |  |  | 1,648 |  |
| 2017 |  |  | 1,145 |  |
| 2018 |  |  | 691 |  |
| 2019 |  |  | 298 |  |
| Thereafter |  |  | 1,269 |  |
| Total |  | $ | 6,464 |  |


## us-gaap:ScheduleOfAvailableForSaleSecuritiesReconciliationTableTextBlock

[0001193125-15-173975:notes:21]
At March 31, 2015, we held the following securities and
 investments, recorded at either fair value or cost.

[0001193125-15-173975:notes:22]
| (In thousands) |  | Amortized Cost |  |  | Gross Unrealized |  |  | Carrying Value |  |
|  |  | Gains |  |  | Losses |  |  |
| Deferred compensation plan assets |  | $ | 14,071 |  |  | $ | 2,555 |  |  | $ | (54 | ) |  | $ | 16,572 |  |
| Corporate bonds |  |  | 132,343 |  |  |  | 250 |  |  |  | (205 | ) |  |  | 132,388 |  |
| Municipal fixed-rate bonds |  |  | 92,810 |  |  |  | 318 |  |  |  | (11 | ) |  |  | 93,117 |  |
| Municipal variable rate demand notes |  |  | 4,245 |  |  |  | — |  |  |  | — |  |  |  | 4,245 |  |
| Marketable equity securities |  |  | 26,608 |  |  |  | 11,496 |  |  |  | (481 | ) |  |  | 37,623 |  |
| Available-for-sale securities held at fair value |  | $ | 270,077 |  |  | $ | 14,619 |  |  | $ | (751 | ) |  | $ | 283,945 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 30,000 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1,493 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 315,438 |  |

[0001193125-15-173975:notes:23]
At December 31, 2014, we held the following securities and
 investments, recorded at either fair value or cost.

[0001193125-15-173975:notes:24]
| (In thousands) |  | Amortized Cost |  |  | Gross Unrealized |  |  | Carrying Value |  |
|  |  | Gains |  |  | Losses |  |  |
| Deferred compensation plan assets |  | $ | 13,897 |  |  | $ | 2,409 |  |  | $ | (12 | ) |  | $ | 16,294 |  |
| Corporate bonds |  |  | 111,261 |  |  |  | 186 |  |  |  | (186 | ) |  |  | 111,261 |  |
| Municipal fixed-rate bonds |  |  | 127,341 |  |  |  | 480 |  |  |  | (34 | ) |  |  | 127,787 |  |
| Municipal variable rate demand notes |  |  | 2,465 |  |  |  | — |  |  |  | — |  |  |  | 2,465 |  |
| Marketable equity securities |  |  | 26,399 |  |  |  | 12,395 |  |  |  | (539 | ) |  |  | 38,255 |  |
| Available-for-sale securities held at fair value |  | $ | 281,363 |  |  | $ | 15,470 |  |  | $ | (771 | ) |  | $ | 296,062 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 30,000 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1,506 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 327,568 |  |


## us-gaap:ScheduleOfDerivativeInstrumentsInStatementOfFinancialPositionFairValueTextBlock

[0001193125-15-173975:notes:25]
The fair values of our derivative instruments recorded in the
 Consolidated Balance Sheet as of March 31, 2015 and
 December 31, 2014 were as follows:

[0001193125-15-173975:notes:26]
| (In thousands) |  | Balance Sheet Location |  | March 31, 2015 |  |  | December 31, 2014 |  |
| Derivatives Not Designated as Hedging Instruments (Level 2): |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts – asset derivatives |  | Other receivables |  | $ | 1,692 |  |  | $ | 249 |  |
| Foreign exchange contracts – liability derivatives |  | Accounts payable |  | $ | (607 | ) |  | $ | (10 | ) |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001193125-15-173975:notes:27]
At March 31, 2015 and December 31, 2014, inventory
 consisted of the following:

[0001193125-15-173975:notes:28]
| (In thousands) |  | March 31, 2015 |  |  | December 31, 2014 |  |
| Raw materials |  | $ | 35,891 |  |  | $ | 34,831 |  |
| Work in process |  |  | 2,613 |  |  |  | 3,750 |  |
| Finished goods |  |  | 54,619 |  |  |  | 48,129 |  |
| Total |  | $ | 93,123 |  |  | $ | 86,710 |  |


## us-gaap:ScheduleOfRealizedGainLossTableTextBlock

[0001193125-15-173975:notes:29]
[same as prior period, unchanged from 0001193125-14-398391:notes:24]

[0001193125-15-173975:notes:30]
|  |  | Three Months Ended March 31, |  |
| (In thousands) |  | 2015 |  |  | 2014 |  |
| Gross realized gains |  | $ | 3,145 |  |  | $ | 2,228 |  |
| Gross realized losses |  | $ | (30 | ) |  | $ | (36 | ) |


## us-gaap:ScheduleOfShareBasedCompensationStockOptionsActivityTableTextBlock

[0001193125-15-173975:notes:31]
The following table is a summary of our stock options outstanding
 as of December 31, 2014 and March 31, 2015 and the
 changes that occurred during the three months ended March 31,
 2015:

[0001193125-15-173975:notes:32]
| (In thousands, except per share amounts) |  | Number of Options |  |  | Weighted Avg. Exercise Price |  |  | Weighted Avg. Remaining Contractual Life In Years |  |  | Aggregate Intrinsic Value |  |
| Options outstanding, December 31, 2014 |  |  | 6,981 |  |  | $ | 23.62 |  |  |  | 6.45 |  |  | $ | 10,625 |  |
| Options granted |  |  | 2 |  |  | $ | 22.56 |  |  |  |  |  |  |  |  |  |
| Options forfeited |  |  | (79 | ) |  | $ | 20.87 |  |  |  |  |  |  |  |  |  |
| Options expired |  |  | (19 | ) |  | $ | 27.19 |  |  |  |  |  |  |  |  |  |
| Options exercised |  |  | (17 | ) |  | $ | 16.58 |  |  |  |  |  |  |  |  |  |
| Options outstanding, March 31, 2015 |  |  | 6,868 |  |  | $ | 23.66 |  |  |  | 6.18 |  |  | $ | 3,037 |  |
| Options vested and expected to vest, March 31, 2015 |  |  | 6,678 |  |  | $ | 23.73 |  |  |  | 6.11 |  |  | $ | 2,553 |  |
| Options exercisable, March 31, 2015 |  |  | 4,362 |  |  | $ | 25.17 |  |  |  | 4.74 |  |  | $ | 2,303 |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-15-173975:notes:33]
[same as prior period, unchanged from 0001193125-14-398391:notes:28]

[0001193125-15-173975:notes:34]
[same as prior period, unchanged from 0001193125-14-398391:notes:29]

[0001193125-15-173975:notes:35]
The following table presents information about the reported sales
 and gross profit of our reportable segments for the three months
 ended March 31, 2015 and 2014. Asset information by reportable
 segment is not reported, since we do not produce such information
 internally.

[0001193125-15-173975:notes:36]
|  |  | Three Months Ended |  |
|  |  | March 31, 2015 |  |  | March 31, 2014 |  |
| (In thousands) |  | Sales |  |  | Gross Profit |  |  | Sales |  |  | Gross Profit |  |
| Carrier Networks |  | $ | 116,014 |  |  | $ | 49,859 |  |  | $ | 118,162 |  |  | $ | 61,353 |  |
| Enterprise Networks |  |  | 26,821 |  |  |  | 15,704 |  |  |  | 28,842 |  |  |  | 16,437 |  |
| Total |  | $ | 142,835 |  |  | $ | 65,563 |  |  | $ | 147,004 |  |  | $ | 77,790 |  |

[0001193125-15-173975:notes:37]
[same as prior period, unchanged from 0001193125-14-398391:notes:33]

[0001193125-15-173975:notes:38]
[same as prior period, unchanged from 0001193125-14-398391:notes:34]

[0001193125-15-173975:notes:39]
Carrier Systems products are used by
 communications service providers to provide data, voice, and video
 services to consumers and enterprises. This category includes the
 following product areas and related services:

[0001193125-15-173975:notes:40]
[same as prior period, unchanged from 0001193125-14-398391:notes:36]

[0001193125-15-173975:notes:41]
|  | • |  | Total Access® 5000 Series of Multi-Service Access Node (MSAN) |

[0001193125-15-173975:notes:42]
|  | • |  | hiX 5600 Series of MSANs |

[0001193125-15-173975:notes:43]
[same as prior period, unchanged from 0001193125-14-398391:notes:39]

[0001193125-15-173975:notes:44]
|  | • |  | hiX 1100 Series of Fiber to the Node (FTTN) products |

[0001193125-15-173975:notes:45]
|  | • |  | VDSL2 Vectoring based Digital Subscriber Line Access Multiplexer (DSLAM) products |

[0001193125-15-173975:notes:46]
|  | • |  | ADTRAN 500 Series of FTTdp G.fast Distribution Point Units (DPU) |

[0001193125-15-173975:notes:47]
[same as prior period, unchanged from 0001193125-14-398391:notes:42]

[0001193125-15-173975:notes:48]
[same as prior period, unchanged from 0001193125-14-398391:notes:43]

[0001193125-15-173975:notes:49]
[same as prior period, unchanged from 0001193125-14-398391:notes:44]

[0001193125-15-173975:notes:50]
|  | • |  | NetVanta 8400 Series of 10Gig Multi-service Edge Switches |

[0001193125-15-173975:notes:51]
[same as prior period, unchanged from 0001193125-14-398391:notes:45]

[0001193125-15-173975:notes:52]
[same as prior period, unchanged from 0001193125-14-398391:notes:46]

[0001193125-15-173975:notes:53]
|  | • |  | Time Division Multiplexed (TDM) systems |

[0001193125-15-173975:notes:54]
Business Networking products provide access to
 communication services and facilitate the delivery of cloud
 connectivity and enterprise communications to the small and
 mid-sized enterprise (SME) market. This category includes the
 following product areas and related services:

[0001193125-15-173975:notes:55]
[same as prior period, unchanged from 0001193125-14-398391:notes:49]

[0001193125-15-173975:notes:56]
[same as prior period, unchanged from 0001193125-14-398391:notes:50]

[0001193125-15-173975:notes:57]
[same as prior period, unchanged from 0001193125-14-398391:notes:51]

[0001193125-15-173975:notes:58]
[same as prior period, unchanged from 0001193125-14-398391:notes:52]

[0001193125-15-173975:notes:59]
[same as prior period, unchanged from 0001193125-14-398391:notes:53]

[0001193125-15-173975:notes:60]
|  | • |  | Access Routers |

[0001193125-15-173975:notes:61]
|  | • |  | Enterprise Session Border Controllers (eSBC) |

[0001193125-15-173975:notes:62]
|  | • |  | Managed Ethernet Switches |

[0001193125-15-173975:notes:63]
|  | • |  | IP Business Gateways |

[0001193125-15-173975:notes:64]
|  | • |  | Unified Communications (UC) solutions |

[0001193125-15-173975:notes:65]
|  | • |  | Carrier Ethernet Network Terminating Equipment (NTE) |

[0001193125-15-173975:notes:66]
|  | • |  | Carrier Ethernet Routers and Gateways |

[0001193125-15-173975:notes:67]
[same as prior period, unchanged from 0001193125-14-398391:notes:59]

[0001193125-15-173975:notes:68]
Loop Access products are used by carrier
 and enterprise customers for access to copper-based communications
 networks. This category includes the following product areas and
 related services:

[0001193125-15-173975:notes:69]
[same as prior period, unchanged from 0001193125-14-398391:notes:62]

[0001193125-15-173975:notes:70]
[same as prior period, unchanged from 0001193125-14-398391:notes:63]

[0001193125-15-173975:notes:71]
[same as prior period, unchanged from 0001193125-14-398391:notes:64]

[0001193125-15-173975:notes:72]
[same as prior period, unchanged from 0001193125-14-398391:notes:65]

[0001193125-15-173975:notes:73]
[same as prior period, unchanged from 0001193125-14-398391:notes:66]

[0001193125-15-173975:notes:74]
The table below presents sales information by product category for
 the three months ended March 31, 2015 and 2014:

[0001193125-15-173975:notes:75]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2015 |  |  | 2014 |  |
| Carrier Systems |  | $ | 100,439 |  |  | $ | 99,553 |  |
| Business Networking |  |  | 35,381 |  |  |  | 37,919 |  |
| Loop Access |  |  | 7,015 |  |  |  | 9,532 |  |
| Total |  | $ | 142,835 |  |  | $ | 147,004 |  |

[0001193125-15-173975:notes:76]
[same as prior period, unchanged from 0001193125-14-398391:notes:69]

[0001193125-15-173975:notes:77]
The table below presents subcategory revenues for the three months
 ended March 31, 2015 and 2014:

[0001193125-15-173975:notes:78]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2015 |  |  | 2014 |  |
| Core Products |  |  |  |  |  |  |  |  |
| Broadband Access (included in Carrier Systems) |  | $ | 84,794 |  |  | $ | 81,527 |  |
| Optical (included in Carrier Systems) |  |  | 12,504 |  |  |  | 12,789 |  |
| Internetworking (included in Business Networking) |  |  | 34,159 |  |  |  | 36,946 |  |
| Subtotal |  |  | 131,457 |  |  |  | 131,262 |  |
| Legacy Products |  |  |  |  |  |  |  |  |
| HDSL (does not include T1) (included in Loop Access) |  |  | 6,703 |  |  |  | 8,877 |  |
| Other products (excluding HDSL) |  |  | 4,675 |  |  |  | 6,865 |  |
| Subtotal |  |  | 11,378 |  |  |  | 15,742 |  |
| Total |  | $ | 142,835 |  |  | $ | 147,004 |  |


## us-gaap:InventoryDisclosureTextBlock

[0001193125-15-173975:notes:79]
[same as prior period, unchanged from 0001193125-14-398391:notes:72]

[0001193125-15-173975:notes:80]
We establish reserves for estimated excess, obsolete, or
 unmarketable inventory equal to the difference between the cost of
 the inventory and the estimated fair value of the inventory based
 upon assumptions about future demand and market conditions. At
 March 31, 2015 and December 31, 2014, raw materials
 reserves totaled $16.9 million, and finished goods inventory
 reserves totaled $7.6 million and $7.8 million, respectively.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001193125-15-173975:notes:81]
13. RELATED PARTY TRANSACTIONS

[0001193125-15-173975:notes:82]
During 2014, we employed the law firm of our director emeritus for
 legal services. All bills for services rendered by this firm were
 reviewed and approved by our Chief Financial Officer. We believe
 that the fees for such services were comparable to those charged by
 other firms for services rendered to us. The services of our
 director emeritus ended with his death on September 7, 2014.
 For the three months ended March 31, 2014, we incurred fees of
 $10 thousand per month for these legal services.


## us-gaap:ScheduleOfEmployeeServiceShareBasedCompensationAllocationOfRecognizedPeriodCostsTextBlock

[0001193125-15-173975:notes:83]
The following table summarizes the stock-based compensation expense
 related to stock options, restricted stock units (RSUs) and
 restricted stock for the three months ended March 31, 2015 and
 2014, which was recognized as follows:

[0001193125-15-173975:notes:84]
|  |  | Three Months Ended March 31, |  |
| (In thousands) |  | 2015 |  |  | 2014 |  |
| Stock-based compensation expense included in cost of sales |  | $ | 90 |  |  | $ | 116 |  |
| Selling, general and administrative expense |  |  | 691 |  |  |  | 1,026 |  |
| Research and development expense |  |  | 858 |  |  |  | 915 |  |
| Stock-based compensation expense included in operating expenses |  |  | 1,549 |  |  |  | 1,941 |  |
| Total stock-based compensation expense |  |  | 1,639 |  |  |  | 2,057 |  |
| Tax benefit for expense associated with non-qualified options |  |  | (180 | ) |  |  | (284 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 1,459 |  |  | $ | 1,773 |  |


## us-gaap:ScheduleOfStockholdersEquityTableTextBlock

[0001193125-15-173975:notes:85]
A summary of the changes in stockholders’ equity for the
 three months ended March 31, 2015 is as follows:

[0001193125-15-173975:notes:86]
| (In thousands) |  | Stockholders’ Equity |  |
| Balance, December 31, 2014 |  | $ | 549,013 |  |
| Net income |  |  | 3,317 |  |
| Dividend payments |  |  | (4,811 | ) |
| Dividends accrued for unvested restricted stock units |  |  | 11 |  |
| Net unrealized losses on available-for-sale securities (net of tax) |  |  | (503 | ) |
| Defined benefit plan adjustments |  |  | 68 |  |
| Foreign currency translation adjustment |  |  | (3,318 | ) |
| Proceeds from stock option exercises |  |  | 280 |  |
| Purchase of treasury stock |  |  | (3,035 | ) |
| Income tax benefit from exercise of stock options |  |  | 8 |  |
| Stock-based compensation expense |  |  | 1,639 |  |
| Balance, March 31, 2015 |  | $ | 542,669 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001193125-15-173975:notes:87]
[same as prior period, unchanged from 0001193125-14-398391:notes:87]

[0001193125-15-173975:notes:88]
[same as prior period, unchanged from 0001193125-14-398391:notes:88]

[0001193125-15-173975:notes:89]
As of March 31, 2015, we had forward contracts outstanding
 with notional amounts totaling €63.0 million ($67.7
 million), which mature at various times throughout 2015.

[0001193125-15-173975:notes:90]
The change in the fair values of our derivative instruments
 recorded in the Consolidated Statements of Income during the three
 months ended March 31, 2015 and 2014 were as follows:

[0001193125-15-173975:notes:91]
|  |  |  |  | Three Months Ended |  |
|  |  | Income Statement Location |  | March 31, |  |
| (In thousands) |  |  | 2015 |  |  | 2014 |  |
| Derivatives Not Designated as Hedging Instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Other income (expense) |  | $ | 1,476 |  |  | $ | (110 | ) |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001193125-15-173975:notes:92]
5. INVESTMENTS

[0001193125-15-173975:notes:93]
As of March 31, 2015, our corporate bonds and municipal
 fixed-rate bonds had the following contractual maturities:

[0001193125-15-173975:notes:94]
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |
| Less than one year |  | $ | 44,108 |  |  | $ | 30,407 |  |
| One to two years |  |  | 39,163 |  |  |  | 39,660 |  |
| Two to three years |  |  | 49,117 |  |  |  | 21,826 |  |
| Three to five years |  |  | — |  |  |  | 1,224 |  |
| Total |  | $ | 132,388 |  |  | $ | 93,117 |  |

[0001193125-15-173975:notes:95]
Actual maturities may differ from contractual maturities because
 some borrowers have the right to call or prepay obligations with or
 without call or prepayment penalties.

[0001193125-15-173975:notes:96]
Our investment policy provides limitations for issuer
 concentration, which limits, at the time of purchase, the
 concentration in any one issuer to 5% of the market value of our
 total investment portfolio.

[0001193125-15-173975:notes:97]
At March 31, 2015, we held a $30.0 million restricted
 certificate of deposit, which is carried at cost. This investment
 serves as a collateral deposit against the principal amount
 outstanding under loans made to ADTRAN pursuant to an Alabama State
 Industrial Development Authority revenue bond (the Bond). At
 March 31, 2015, the estimated fair value of the Bond using a
 level 2 valuation technique was approximately $29.7 million, based
 on a debt security with a comparable interest rate and maturity and
 a Standard and Poor’s credit rating of AAA. For more
 information on the Bond, see “Debt” under
 “Liquidity and Capital Resources” in the
 “Management’s Discussion and Analysis of Financial
 Condition and Results of Operations” contained in Item 2
 of Part I of this report.

[0001193125-15-173975:notes:98]
We review our investment portfolio for potential
 “other-than-temporary” declines in value on an
 individual investment basis. We assess, on a quarterly basis,
 significant declines in value which may be considered
 other-than-temporary and, if necessary, recognize and record the
 appropriate charge to write-down the carrying value of such
 investments. In making this assessment, we take into consideration
 qualitative and quantitative information, including but not limited
 to the following: the magnitude and duration of historical declines
 in market prices, credit rating activity, assessments of liquidity,
 public filings, and statements made by the issuer. We generally
 begin our identification of potential other-than-temporary
 impairments by reviewing any security with a fair value that has
 declined from its original or adjusted cost basis by 25% or more
 for six or more consecutive months. We then evaluate the individual
 security based on the previously identified factors to determine
 the amount of the write-down, if any. For the three months ended
 March 31, 2015 and 2014, other-than-temporary impairment
 charges were not significant.

[0001193125-15-173975:notes:99]
Realized gains and losses on sales of securities are computed under
 the specific identification method. The following table presents
 gross realized gains and losses related to our investments.

[0001193125-15-173975:notes:100]
As of March 31, 2015 and 2014, gross unrealized losses related
 to individual securities in a continuous loss position for 12
 months or longer were not significant.

[0001193125-15-173975:notes:101]
The fair value of our Level 2 securities is calculated using a
 weighted average market price for each security. Market prices are
 obtained from a variety of industry standard data providers,
 security master files from large financial institutions, and other
 third-party sources. These multiple market prices are used as
 inputs into a distribution-curve-based algorithm to determine the
 daily market value of each security.

[0001193125-15-173975:notes:102]
Our municipal variable rate demand notes have a structure that
 implies a standard expected market price. The frequent interest
 rate resets make it reasonable to expect the price to stay at par.
 These securities are priced at the expected market price.


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001193125-15-173975:notes:103]
The following tables present changes in accumulated other
 comprehensive income, net of tax, by component for the three months
 ended March 31, 2015 and 2014:

[0001193125-15-173975:notes:104]
|  |  | Three Months Ended March 31, 2015 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | Total |  |
| Beginning balance |  | $ | 8,964 |  |  | $ | (5,757 | ) |  | $ | (3,282 | ) |  | $ | (75 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | 1,360 |  |  |  | — |  |  |  | (3,318 | ) |  |  | (1,958 | ) |
| Amounts reclassified from accumulated other comprehensive income |  |  | (1,863 | ) |  |  | 68 |  |  |  | — |  |  |  | (1,795 | ) |
| Net current period other comprehensive income(loss) |  |  | (503 | ) |  |  | 68 |  |  |  | (3,318 | ) |  |  | (3,753 | ) |
| Ending balance |  | $ | 8,461 |  |  | $ | (5,689 | ) |  | $ | (6,600 | ) |  | $ | (3,828 | ) |
|  |  | Three Months Ended March 31, 2014 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | Total |  |
| Beginning balance |  | $ | 10,737 |  |  | $ | (891 | ) |  | $ | 907 |  |  | $ | 10,753 |  |
| Other comprehensive income (loss) before reclassifications |  |  | 402 |  |  |  | — |  |  |  | 252 |  |  |  | 654 |  |
| Amounts reclassified from accumulated other comprehensive income |  |  | (1,323 | ) |  |  | — |  |  |  | — |  |  |  | (1,323 | ) |
| Net current period other comprehensive income(loss) |  |  | (921 | ) |  |  | — |  |  |  | 252 |  |  |  | (669 | ) |
| Ending balance |  | $ | 9,816 |  |  | $ | (891 | ) |  | $ | 1,159 |  |  | $ | 10,084 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001193125-15-173975:notes:105]
[same as prior period, unchanged from 0001193125-14-398391:notes:108]

[0001193125-15-173975:notes:106]
[same as prior period, unchanged from 0001193125-14-398391:notes:109]

[0001193125-15-173975:notes:107]
Since 1997, our Board of Directors has approved multiple share
 repurchase programs that have authorized open market repurchase
 transactions of up to 45.0 million shares of our common stock.
 During the three months ended March 31, 2015, we repurchased
 0.1 million shares of our common stock at an average price of
 $21.52 per share. We currently have the authority to purchase an
 additional 4.7 million shares of our common stock under the
 current plans approved by the Board of Directors.

[0001193125-15-173975:notes:108]
[same as prior period, unchanged from 0001193125-14-398391:notes:112]

[0001193125-15-173975:notes:109]
We issued 17 thousand shares of treasury stock during the
 three months ended March 31, 2015 to accommodate employee
 stock option exercises. The stock options had exercise prices
 ranging from $15.29 to $22.53. We received proceeds totaling $0.3
 million from the exercise of these stock options during the three
 months ended March 31, 2015.

[0001193125-15-173975:notes:110]
[same as prior period, unchanged from 0001193125-14-398391:notes:114]

[0001193125-15-173975:notes:111]
During the three months ended March 31, 2015, we paid cash
 dividends as follows (in thousands except per share amounts):

[0001193125-15-173975:notes:112]
| Record Date |  | Payment Date |  |  | Per Share Amount |  |  | Total Dividend Paid |  |
| February 5, 2015 |  |  | February 19, 2015 |  |  | $ | 0.09 |  |  | $ | 4,811 |  |

[0001193125-15-173975:notes:113]
Other Comprehensive Income

[0001193125-15-173975:notes:114]
Other comprehensive income consists of unrealized gains (losses) on
 available-for-sale securities, reclassification adjustments for
 amounts included in net income related to impairments of
 available-for-sale securities, realized gains (losses) on
 available-for-sale securities, and amortization of actuarial gains
 (losses) related to our defined benefit plan, defined benefit plan
 adjustments and foreign currency translation adjustments.

[0001193125-15-173975:notes:115]
The following tables present the details of reclassifications out
 of accumulated other comprehensive income for the three months
 ended March 31, 2015 and 2014:

[0001193125-15-173975:notes:116]
| (In thousands) |  | Three Months Ended March 31, 2015 |
| Details about Accumulated Other Comprehensive Income Components |  | Amount Reclassified from Accumulated Other Comprehensive Income |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for-sale securities: |  |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 3,076 |  |  | Net realized investment gain |
| Impairment expense |  |  | (22 | ) |  | Net realized investment gain |
| Defined benefit plan adjustments – actuarial losses |  |  | (98 | ) |  | 1 |
| Total reclassifications for the period, before tax |  |  | 2,956 |  |  |  |
| Tax (expense) benefit |  |  | (1,161 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 1,795 |  |  |  |

[0001193125-15-173975:notes:117]
| 1 | Included in the computation of net periodic pension cost. See Note 3 of Notes to Consolidated Financial Statements. |

[0001193125-15-173975:notes:118]
| (In thousands) |  | Three Months Ended March 31, 2014 |  |
| Details about Accumulated Other Comprehensive Income Components |  | Amount Reclassified from Accumulated Other Comprehensive Income |  |  | Affected Line Item in the Statement Where Net Income Is Presented |  |
| Unrealized gains (losses) on available-for-sale securities: |  |  |  |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 2,170 |  |  |  | Net realized investment gain |  |
| Impairment expense |  |  | — |  |  |  | Net realized investment gain |  |
| Total reclassifications for the period, before tax |  |  | 2,170 |  |  |  |  |  |
| Tax (expense) benefit |  |  | (847 | ) |  |  |  |  |
| Total reclassifications for the period, net of tax |  | $ | 1,323 |  |  |  |  |  |

[0001193125-15-173975:notes:119]
The following table presents the tax effects related to the change
 in each component of other comprehensive income for the three
 months ended March 31, 2015 and 2014:

[0001193125-15-173975:notes:120]
|  |  | Three Months Ended March 31, 2015 |  |  | Three Months Ended March 31, 2014 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |  | Before-Tax Amount |  |  | Tax Benefit |  |  | Net-of-Tax Amount |  |
| Unrealized gains (losses) on available-for-sale securities |  | $ | 2,230 |  |  | $ | (870 | ) |  | $ | 1,360 |  |  | $ | 659 |  |  | $ | (257 | ) |  | $ | 402 |  |
| Reclassification adjustment for amounts included in net income |  |  | (2,956 | ) |  |  | 1,161 |  |  |  | (1,795 | ) |  |  | (2,170 | ) |  |  | 847 |  |  |  | (1,323 | ) |
| Foreign currency translation adjustment |  |  | (3,318 | ) |  |  | — |  |  |  | (3,318 | ) |  |  | 252 |  |  |  | — |  |  |  | 252 |  |
| Total Other Comprehensive Income (Loss) |  | $ | (4,044 | ) |  | $ | 291 |  |  | $ | (3,753 | ) |  | $ | (1,259 | ) |  | $ | 590 |  |  | $ | (669 | ) |


## us-gaap:ConsolidationPolicyTextBlock

[0001193125-15-173975:notes:121]
[same as prior period, unchanged from 0001193125-14-398391:notes:127]

[0001193125-15-173975:notes:122]
The accompanying unaudited consolidated financial statements of
 ADTRAN®, Inc. and its
 subsidiaries (ADTRAN) have been prepared pursuant to the rules and
 regulations for reporting on Quarterly Reports on Form 10-Q.
 Accordingly, certain information and notes required by generally
 accepted accounting principles for complete financial statements
 are not included herein. The December 31, 2014 Consolidated
 Balance Sheet is derived from audited financial statements, but
 does not include all disclosures required by accounting principles
 generally accepted in the United States.

[0001193125-15-173975:notes:123]
In the opinion of management, all adjustments necessary to fairly
 state these interim statements have been recorded and are of a
 normal and recurring nature. The results of operations for an
 interim period are not necessarily indicative of the results for
 the full year. The interim statements should be read in conjunction
 with the financial statements and notes thereto included in
 ADTRAN’s Annual Report on Form 10-K for the year ended
 December 31, 2014, filed on February 24, 2015 with the
 SEC.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-15-173975:notes:124]
[same as prior period, unchanged from 0001193125-14-398391:notes:130]

[0001193125-15-173975:notes:125]
Our effective tax rate increased from 34.6% in the three months
 ended March 31, 2014 to 39.8% in the three months ended
 March 31, 2015. The increase in the effective tax rate between
 the two periods is primarily attributable to the release of a
 valuation allowance attributable to a foreign subsidiary in
 2014.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001193125-15-173975:notes:126]
[same as prior period, unchanged from 0001193125-14-398391:notes:132]

[0001193125-15-173975:notes:127]
Our products generally include warranties of 90 days to ten years
 for product defects. We accrue for warranty returns at the time
 revenue is recognized based on our estimate of the cost to repair
 or replace the defective products. We engage in extensive product
 quality programs and processes, including actively monitoring and
 evaluating the quality of our component suppliers. Our products
 continue to become more complex in both size and functionality as
 many of our product offerings migrate from line card applications
 to systems products. The increasing complexity of our products will
 cause warranty incidences, when they arise, to be more costly. Our
 estimates regarding future warranty obligations may change due to
 product failure rates, material usage, and other rework costs
 incurred in correcting a product failure. In addition, from time to
 time, specific warranty accruals may be recorded if unforeseen
 problems arise. Should our actual experience relative to these
 factors be worse than our estimates, we will be required to record
 additional warranty expense. Alternatively, if we provide for more
 reserves than we require, we will reverse a portion of such
 provisions in future periods. The liability for warranty
 obligations totaled $8.7 million at March 31, 2015 and $8.4
 million at December 31, 2014. These liabilities are included
 in accrued expenses in the accompanying Consolidated Balance
 Sheets.

[0001193125-15-173975:notes:128]
A summary of warranty expense and write-off activity for the three
 months ended March 31, 2015 and 2014 is as follows:

[0001193125-15-173975:notes:129]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
|  |  | 2015 |  |  | 2014 |  |
| (In thousands) |  |  |  |  |  |  |
| Balance at beginning of period |  | $ | 8,415 |  |  | $ | 8,977 |  |
| Plus: Amounts charged to cost and expenses |  |  | 461 |  |  |  | 434 |  |
| Less: Deductions |  |  | (192 | ) |  |  | (2,019 | ) |
| Balance at end of period |  | $ | 8,684 |  |  | $ | 7,392 |  |


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001193125-15-173975:notes:130]
[same as prior period, unchanged from 0001193125-14-398391:notes:137]

[0001193125-15-173975:notes:131]
[same as prior period, unchanged from 0001193125-14-398391:notes:138]

[0001193125-15-173975:notes:132]
We reclassified $2.3 million from other receivables to accounts
 receivable at December 31, 2014 to conform to the current
 period presentation.

[0001193125-15-173975:notes:133]
[same as prior period, unchanged from 0001193125-14-398391:notes:140]

[0001193125-15-173975:notes:134]
In connection with the preparation of our Condensed Consolidated
 Financial Statements, we recorded corrections of certain out of
 period, immaterial misstatements that occurred in prior periods,
 the most significant of which resulted in an increase in Other
 Expense of $1.3 million in the first quarter. The aggregate impact
 of the corrections was a $0.8 million reduction to pre-tax income
 for the three months ended March 31, 2015 and is not expected
 to be material to the current year annual results.

[0001193125-15-173975:notes:135]
[same as prior period, unchanged from 0001193125-14-398391:notes:142]

[0001193125-15-173975:notes:136]
The preparation of financial statements in conformity with
 accounting principles generally accepted in the United States of
 America requires management to make estimates and assumptions that
 affect the reported amounts of assets and liabilities, the
 disclosure of contingent assets and liabilities at the date of the
 financial statements, and the reported amounts of revenue and
 expense during the reporting period. Our more significant estimates
 include the obsolete and excess inventory reserves, warranty
 reserves, customer rebates, determination of the deferred revenue
 components of multiple element sales agreements, estimated costs to
 complete obligations associated with deferred revenues, estimated
 income tax provision and income tax contingencies, the fair value
 of stock-based compensation, impairment of goodwill, valuation and
 estimated lives of intangible assets, estimated pension liability,
 fair value of investments, and the evaluation of
 other-than-temporary declines in the value of investments. Actual
 amounts could differ significantly from these estimates.

[0001193125-15-173975:notes:137]
[same as prior period, unchanged from 0001193125-14-398391:notes:144]

[0001193125-15-173975:notes:138]
In May 2014, the Financial Accounting Standards Board issued
 Accounting Standards Update No. 2014-09, Revenue from Contracts with
 Customers (ASU
 2014-09), which supersedes the revenue recognition requirements in
 Topic 605, Revenue Recognition,
 including most industry-specific revenue recognition guidance
 throughout the Industry Topics of the Codification. The core
 principle of ASU 2014-09 is to recognize revenues when promised
 goods or services are transferred to customers in an amount that
 reflects the consideration that is expected to be received for
 those goods or services. ASU 2014-09 is effective for annual
 reporting periods beginning after December 15, 2016, including
 interim periods within that reporting period, and early application
 is not permitted. ASU 2014-09 allows for either full retrospective
 or modified retrospective adoption. We are currently evaluating the
 transition method that will be elected and the impact that the
 adoption of ASU 2014-09 will have on our financial position,
 results of operations and cash flows.


## us-gaap:SubsequentEventsTextBlock

[0001193125-15-173975:notes:139]
15. SUBSEQUENT EVENTS

[0001193125-15-173975:notes:140]
On April 21, 2015, we announced that our Board of Directors
 declared a quarterly cash dividend of $0.09 per common share to be
 paid to stockholders of record at the close of business on
 May 7, 2015. The payment date will be May 21, 2015. The
 quarterly dividend payment will be approximately $4.7 million. In
 July 2003, our Board of Directors elected to begin declaring
 quarterly dividends on our common stock considering the tax
 treatment of dividends and adequate levels of Company
 liquidity.

[0001193125-15-173975:notes:141]
During the second quarter and as of May 6, 2015, we have
 repurchased 1.2 million shares of our common stock through open
 market purchases at an average cost of $16.33 per share. We
 currently have the authority to purchase an additional 3.4 million
 shares of our common stock under the current plan approved by the
 Board of Directors.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-15-173975:notes:142]
[same as prior period, unchanged from 0001193125-14-398391:notes:149]

[0001193125-15-173975:notes:143]
[same as prior period, unchanged from 0001193125-14-398391:notes:150]

[0001193125-15-173975:notes:144]
The fair value of our RSUs is calculated using a Monte Carlo
 Simulation valuation method. No RSUs were granted or vested during
 the three months ended March 31, 2015 or 2014. Twelve thousand
 RSUs were forfeited during the three months ended March 31,
 2015.

[0001193125-15-173975:notes:145]
The fair value of restricted stock is equal to the closing price of
 our stock on the date of grant. No restricted stock was granted,
 forfeited, or vested during the three months ended March 31,
 2015 or 2014.

[0001193125-15-173975:notes:146]
Stock-based compensation expense recognized in our Consolidated
 Statements of Income for the three months ended March 31, 2015
 and 2014 is based on options, RSUs and restricted stock ultimately
 expected to vest, and has been reduced for estimated forfeitures.
 Estimated forfeitures for stock options are based upon historical
 experience and approximate 3.1% annually. We estimated a 0%
 forfeiture rate for our RSUs and restricted stock due to the
 limited number of recipients and historical experience for these
 awards.

[0001193125-15-173975:notes:147]
As of March 31, 2015, total compensation expense related to
 non-vested stock options, RSUs and restricted stock not yet
 recognized was approximately $15.2 million, which is expected to be
 recognized over an average remaining recognition period of 2.7
 years.

[0001193125-15-173975:notes:148]
The aggregate intrinsic values in the table above represent the
 total pre-tax intrinsic value (the difference between the closing
 price of our stock on the last trading day of the quarter and the
 exercise price, multiplied by the number of in-the-money options)
 that would have been received by the option holders had all option
 holders exercised their options on March 31, 2015. The
 aggregate intrinsic value will change based on the fair market
 value of our stock.

[0001193125-15-173975:notes:149]
The total pre-tax intrinsic value of options exercised during the
 three months ended March 31, 2015 was $0.1 million.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001193125-15-173975:notes:150]
[same as prior period, unchanged from 0001193125-14-398391:notes:158]

[0001193125-15-173975:notes:151]
[same as prior period, unchanged from 0001193125-14-398391:notes:159]

[0001193125-15-173975:notes:152]
The following table summarizes the components of net periodic
 pension cost for the three months ended March 31, 2015 and
 2014:

[0001193125-15-173975:notes:153]
|  |  | Three Months Ended March 31, |  |
| (In thousands) |  | 2015 |  |  | 2014 |  |
| Service cost |  | $ | 340 |  |  | $ | 305 |  |
| Interest cost |  |  | 159 |  |  |  | 215 |  |
| Expected return on plan assets |  |  | (261 | ) |  |  | (279 | ) |
| Amortization of actuarial losses |  |  | 105 |  |  |  | — |  |
| Net periodic pension cost |  | $ | 343 |  |  | $ | 241 |  |
