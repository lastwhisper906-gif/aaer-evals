# ADTN note change history — 0001193125-14-398391 → 0001193125-15-173975


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2015-05-06):
[0001193125-15-173975:note_history:1]
We have committed to invest up to an aggregate of $7.9 million in
 two private equity funds, and we have contributed $8.4 million as
 of March 31, 2015, of which $7.7 million has been applied to
 these commitments.
  (was, 2014-11-05, similarity 0.9652):
[0001193125-14-398391:note_history:1]
We have committed to invest up to an aggregate of $7.9 million in
 two private equity funds, and we have contributed $8.4 million as
 of September 30, 2014, of which $7.7 million has been applied
 to these commitments.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2015-05-06):
[0001193125-15-173975:note_history:2]
In the opinion of management, all adjustments necessary to fairly
 state these interim statements have been recorded and are of a
 normal and recurring nature. The results of operations for an
 interim period are not necessarily indicative of the results for
 the full year. The interim statements should be read in conjunction
 with the financial statements and notes thereto included in
 ADTRAN’s Annual Report on Form 10-K for the year ended
 December 31, 2014, filed on February 24, 2015 with the
 SEC.
  (was, 2014-11-05, similarity 0.9583):
[0001193125-14-398391:note_history:2]
In the opinion of management, all adjustments necessary for a fair
 presentation of these interim statements have been recorded and are
 of a normal and recurring nature. The results of operations for an
 interim period are not necessarily indicative of the results for
 the full year. The interim statements should be read in conjunction
 with the financial statements and notes thereto included in
 ADTRAN’s Annual Report on Form 10-K for the year ended
 December 31, 2013, filed on February 27, 2014 with the
 SEC.

- added (2015-05-06):
[0001193125-15-173975:note_history:3]
We reclassified $2.3 million from other receivables to accounts
 receivable at December 31, 2014 to conform to the current
 period presentation.

- added (2015-05-06):
[0001193125-15-173975:note_history:4]
In connection with the preparation of our Condensed Consolidated
 Financial Statements, we recorded corrections of certain out of
 period, immaterial misstatements that occurred in prior periods,
 the most significant of which resulted in an increase in Other
 Expense of $1.3 million in the first quarter. The aggregate impact
 of the corrections was a $0.8 million reduction to pre-tax income
 for the three months ended March 31, 2015 and is not expected
 to be material to the current year annual results.

- changed (2015-05-06):
[0001193125-15-173975:note_history:5]
The preparation of financial statements in conformity with
 accounting principles generally accepted in the United States of
 America requires management to make estimates and assumptions that
 affect the reported amounts of assets and liabilities, the
 disclosure of contingent assets and liabilities at the date of the
 financial statements, and the reported amounts of revenue and
 expense during the reporting period. Our more significant estimates
 include the obsolete and excess inventory reserves, warranty
 reserves, customer rebates, determination of the deferred revenue
 components of multiple element sales agreements, estimated costs to
 complete obligations associated with deferred revenues, estimated
 income tax provision and income tax contingencies, the fair value
 of stock-based compensation, impairment of goodwill, valuation and
 estimated lives of intangible assets, estimated pension liability,
 fair value of investments, and the evaluation of
 other-than-temporary declines in the value of investments. Actual
 amounts could differ significantly from these estimates.
  (was, 2014-11-05, similarity 0.9456):
[0001193125-14-398391:note_history:5]
The preparation of financial statements in conformity with
 accounting principles generally accepted in the United States of
 America requires management to make estimates and assumptions that
 affect the reported amounts of assets and liabilities, the
 disclosure of contingent assets and liabilities at the date of the
 financial statements, and the reported amounts of revenue and
 expense during the reporting period. Our more significant estimates
 include the obsolete and excess inventory reserves, warranty
 reserves, customer rebates, determination of the deferred revenue
 components of multiple element sales agreements, estimated costs to
 complete obligations associated with deferred revenues, estimated
 income tax provision and income tax contingencies, the fair value
 of stock-based compensation, impairment of goodwill, valuation and
 estimated lives of intangible assets, estimated working capital
 adjustments under negotiation related to the NSN BBA business
 acquisition, estimated pension liability, fair value of
 investments, and the evaluation of other-than-temporary declines in
 the value of investments. Actual amounts could differ significantly
 from these estimates.

- removed (2015-05-06):
[0001193125-14-398391:note_history:6]
We corrected immaterial misclassifications between the operating
 and investing sections of our consolidated statements of cash flows
 and adjusted our cash flows for the nine months ended
 September 30, 2013 in these categories by $0.4 million in
 order to be consistent with the 2014 presentation.

- removed (2015-05-06):
[0001193125-14-398391:note_history:7]
During the year ended December 31, 2013, we identified two
 adjustments in the acquired NSN (formerly Nokia Siemens Networks)
 Broadband Access business (NSN BBA business) relating to customer
 payment discounts for one customer, and recoverable VAT taxes on
 certain vendor freight invoices that should have been recorded in
 prior periods. These adjustments resulted from a $0.5 million
 understatement of net income in the first two quarters of 2013. We
 evaluated the impact of the adjustments on the results of our
 previously issued financial statements for each of the prior
 periods affected and concluded that the impact was not material. We
 also evaluated the impact of the cumulative effect of the
 adjustments in 2013 and concluded that the impact is not material
 to our results for the year 2013. Accordingly, during the three
 months ended September 30, 2013 we recorded an out of period
 adjustment to correct these issues.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-05-06):
[0001193125-15-173975:note_history:8]
At March 31, 2015, we held the following securities and
 investments, recorded at either fair value or cost.
  (was, 2014-11-05, similarity 0.9515):
[0001193125-14-398391:note_history:8]
At September 30, 2014, we held the following securities and
 investments, recorded at either fair value or cost.

- changed (2015-05-06):
[0001193125-15-173975:note_history:9]
As of March 31, 2015, our corporate bonds and municipal
 fixed-rate bonds had the following contractual maturities:
  (was, 2014-11-05, similarity 0.9545):
[0001193125-14-398391:note_history:9]
As of September 30, 2014, our corporate bonds and municipal
 fixed-rate bonds had the following contractual maturities:

- changed (2015-05-06):
[0001193125-15-173975:note_history:10]
At March 31, 2015, we held a $30.0 million restricted
 certificate of deposit, which is carried at cost. This investment
 serves as a collateral deposit against the principal amount
 outstanding under loans made to ADTRAN pursuant to an Alabama State
 Industrial Development Authority revenue bond (the Bond). At
 March 31, 2015, the estimated fair value of the Bond using a
 level 2 valuation technique was approximately $29.7 million, based
 on a debt security with a comparable interest rate and maturity and
 a Standard and Poor’s credit rating of AAA. For more
 information on the Bond, see “Debt” under
 “Liquidity and Capital Resources” in the
 “Management’s Discussion and Analysis of Financial
 Condition and Results of Operations” contained in Item 2
 of Part I of this report.
  (was, 2014-11-05, similarity 0.9259):
[0001193125-14-398391:note_history:10]
At September 30, 2014, we held a $30.0 million restricted
 certificate of deposit, which is carried at cost. This investment
 serves as a collateral deposit against the principal amount
 outstanding under loans made to ADTRAN pursuant to an Alabama State
 Industrial Development Authority revenue bond (the Bond). During
 the first quarter of 2014, we made a principal payment on the Bond
 of $16.5 million. At September 30, 2014, the estimated fair
 value of the Bond using a level 2 valuation technique was
 approximately $29.8 million, based on a debt security with a
 comparable interest rate and maturity and a Standard and
 Poor’s credit rating of AAA. For more information on the
 Bond, see “Debt” under “Liquidity and Capital
 Resources” in the “Management’s Discussion and
 Analysis of Financial Condition and Results of Operations”
 contained in Item 2 of Part I of this report.

- changed (2015-05-06):
[0001193125-15-173975:note_history:11]
We review our investment portfolio for potential
 “other-than-temporary” declines in value on an
 individual investment basis. We assess, on a quarterly basis,
 significant declines in value which may be considered
 other-than-temporary and, if necessary, recognize and record the
 appropriate charge to write-down the carrying value of such
 investments. In making this assessment, we take into consideration
 qualitative and quantitative information, including but not limited
 to the following: the magnitude and duration of historical declines
 in market prices, credit rating activity, assessments of liquidity,
 public filings, and statements made by the issuer. We generally
 begin our identification of potential other-than-temporary
 impairments by reviewing any security with a fair value that has
 declined from its original or adjusted cost basis by 25% or more
 for six or more consecutive months. We then evaluate the individual
 security based on the previously identified factors to determine
 the amount of the write-down, if any. For the three months ended
 March 31, 2015 and 2014, other-than-temporary impairment
 charges were not significant.
  (was, 2014-11-05, similarity 0.9785):
[0001193125-14-398391:note_history:11]
We review our investment portfolio for potential
 “other-than-temporary” declines in value on an
 individual investment basis. We assess, on a quarterly basis,
 significant declines in value which may be considered
 other-than-temporary and, if necessary, recognize and record the
 appropriate charge to write-down the carrying value of such
 investments. In making this assessment, we take into consideration
 qualitative and quantitative information, including but not limited
 to the following: the magnitude and duration of historical declines
 in market prices, credit rating activity, assessments of liquidity,
 public filings, and statements made by the issuer. We generally
 begin our identification of potential other-than-temporary
 impairments by reviewing any security with a fair value that has
 declined from its original or adjusted cost basis by 25% or more
 for six or more consecutive months. We then evaluate the individual
 security based on the previously identified factors to determine
 the amount of the write-down, if any. For the three and nine months
 ended September 30, 2014 and 2013, other-than-temporary
 impairment charges were not significant.

- changed (2015-05-06):
[0001193125-15-173975:note_history:12]
|  |  | Three Months Ended March 31, |  |
| (In thousands) |  | 2015 |  |  | 2014 |  |
| Gross realized gains |  | $ | 3,145 |  |  | $ | 2,228 |  |
| Gross realized losses |  | $ | (30 | ) |  | $ | (36 | ) |
  (was, 2014-11-05, similarity 0.6276):
[0001193125-14-398391:note_history:12]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2014 |  |  | 2013 |  |  | 2014 |  |  | 2013 |  |
| Gross realized gains |  | $ | 2,728 |  |  | $ | 1,797 |  |  | $ | 7,363 |  |  | $ | 7,252 |  |
| Gross realized losses |  | $ | (41 | ) |  | $ | (46 | ) |  | $ | (144 | ) |  | $ | (303 | ) |

- changed (2015-05-06):
[0001193125-15-173975:note_history:13]
As of March 31, 2015 and 2014, gross unrealized losses related
 to individual securities in a continuous loss position for 12
 months or longer were not significant.
  (was, 2014-11-05, similarity 0.9677):
[0001193125-14-398391:note_history:13]
As of September 30, 2014 and 2013, gross unrealized losses
 related to individual securities in a continuous loss position for
 12 months or longer were not significant.

- changed (2015-05-06):
[0001193125-15-173975:note_history:14]
|  |  | Fair Value Measurements at March 31, 2015 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Commercial paper |  | $ | 11,997 |  |  | $ | — |  |  | $ | 11,997 |  |  | $ | — |  |
| Money market funds |  |  | 3,228 |  |  |  | 3,228 |  |  |  | — |  |  |  | — |  |
| Cash equivalents |  |  | 15,225 |  |  |  | 3,228 |  |  |  | 11,997 |  |  |  | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 16,572 |  |  |  | 16,572 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 132,388 |  |  |  | — |  |  |  | 132,388 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 93,117 |  |  |  | — |  |  |  | 93,117 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 4,245 |  |  |  | — |  |  |  | 4,245 |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – technology industry |  |  | 9,034 |  |  |  | 9,034 |  |  |  | — |  |  |  | — |  |
| Marketable equity securities – other |  |  | 28,589 |  |  |  | 28,589 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 283,945 |  |  |  | 54,195 |  |  |  | 229,750 |  |  |  | — |  |
| Total |  | $ | 299,170 |  |  | $ | 57,423 |  |  | $ | 241,747 |  |  | $ | — |  |
  (was, 2014-11-05, similarity 0.7203):
[0001193125-14-398391:note_history:14]
|  |  | Fair Value Measurements at September 30, 2014 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 9,861 |  |  | $ | 9,861 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 15,498 |  |  |  | 15,498 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 102,520 |  |  |  | — |  |  |  | 102,520 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 150,773 |  |  |  | — |  |  |  | 150,773 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 18,000 |  |  |  | — |  |  |  | 18,000 |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – technology industry |  |  | 8,879 |  |  |  | 8,879 |  |  |  | — |  |  |  | — |  |
| Marketable equity securities – other |  |  | 26,902 |  |  |  | 26,902 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 322,572 |  |  |  | 51,279 |  |  |  | 271,293 |  |  |  | — |  |
| Total |  | $ | 332,433 |  |  | $ | 61,140 |  |  | $ | 271,293 |  |  | $ | — |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- added (2015-05-06):
[0001193125-15-173975:note_history:15]
During 2014, we employed the law firm of our director emeritus for
 legal services. All bills for services rendered by this firm were
 reviewed and approved by our Chief Financial Officer. We believe
 that the fees for such services were comparable to those charged by
 other firms for services rendered to us. The services of our
 director emeritus ended with his death on September 7, 2014.
 For the three months ended March 31, 2014, we incurred fees of
 $10 thousand per month for these legal services.

- removed (2015-05-06):
[0001193125-14-398391:note_history:16]
We employ the law firm of our director emeritus for legal services.
 All bills for services rendered by this firm are reviewed and
 approved by our Chief Financial Officer. We believe that the fees
 for such services are comparable to those charged by other firms
 for services rendered to us. The services of our director emeritus
 ended with his death on September 7, 2014. We incurred fees of
 $10 thousand and $30 thousand for the three months ended
 September 30, 2014 and 2013, respectively, and $70 thousand
 and $90 thousand for the nine months ended September 30, 2014
 and 2013, respectively, for these legal services.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2015-05-06):
[0001193125-15-173975:note_history:17]
On April 21, 2015, we announced that our Board of Directors
 declared a quarterly cash dividend of $0.09 per common share to be
 paid to stockholders of record at the close of business on
 May 7, 2015. The payment date will be May 21, 2015. The
 quarterly dividend payment will be approximately $4.7 million. In
 July 2003, our Board of Directors elected to begin declaring
 quarterly dividends on our common stock considering the tax
 treatment of dividends and adequate levels of Company
 liquidity.
  (was, 2014-11-05, similarity 0.9651):
[0001193125-14-398391:note_history:17]
On October 14, 2014, we announced that our Board of Directors
 declared a quarterly cash dividend of $0.09 per common share to be
 paid to stockholders of record at the close of business on
 October 30, 2014. The payment date will be November 13,
 2014. The quarterly dividend payment will be approximately $4.9
 million. In July 2003, our Board of Directors elected to begin
 declaring quarterly dividends on our common stock considering the
 tax treatment of dividends and adequate levels of Company
 liquidity.

- changed (2015-05-06):
[0001193125-15-173975:note_history:18]
During the second quarter and as of May 6, 2015, we have
 repurchased 1.2 million shares of our common stock through open
 market purchases at an average cost of $16.33 per share. We
 currently have the authority to purchase an additional 3.4 million
 shares of our common stock under the current plan approved by the
 Board of Directors.
  (was, 2014-11-05, similarity 0.9643):
[0001193125-14-398391:note_history:18]
During the fourth quarter and as of November 5, 2014, we have
 repurchased 0.2 million shares of our common stock
 through open market purchases at an average cost of $20.47 per
 share. We currently have the authority to purchase an additional
 5.5 million shares of our common stock under the current plan
 approved by the Board of Directors.
