# ADTN notes — 0000950123-11-094914


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000950123-11-094914:notes:1]
[same as prior period, unchanged from 0000950123-11-071519:notes:1]

[0000950123-11-094914:notes:2]
[same as prior period, unchanged from 0000950123-11-071519:notes:2]

[0000950123-11-094914:notes:3]
[same as prior period, unchanged from 0000950123-11-071519:notes:3]

[0000950123-11-094914:notes:4]
[same as prior period, unchanged from 0000950123-11-071519:notes:4]

[0000950123-11-094914:notes:5]
[same as prior period, unchanged from 0000950123-11-071519:notes:5]

[0000950123-11-094914:notes:6]
The preparation of financial statements in conformity with accounting principles generally accepted
   in the United States of America requires management to make estimates and assumptions that affect
   the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities
   at the date of the financial statements, and the reported amounts of revenue and expense during the
   reporting period. Our more significant estimates include the allowance for doubtful accounts,
   obsolete and excess inventory reserves, warranty reserves, customer rebates, allowance for sales
   returns, estimated income tax contingencies, the fair value of stock-based compensation, and the
   evaluation of other-than-temporary declines in the value of investments. Actual amounts could
   differ significantly from these estimates.

[0000950123-11-094914:notes:7]
[same as prior period, unchanged from 0000950123-11-071519:notes:7]

[0000950123-11-094914:notes:8]
In September 2011, the Financial Accounting Standards Board (FASB) issued Accounting Standards
   Update No. 2011-08, Testing Goodwill for Impairment (ASU 2011-08). Existing accounting guidance
   requires that an entity perform a test for goodwill impairment, on at least an annual basis, by
   first comparing the fair value of a reporting unit with its carrying amount, including goodwill.
   If the fair value of a reporting unit is less than its carrying amount, then the second step of the
   test is to be performed to measure the amount of impairment loss, if any. ASU 2011-08 will allow
   an entity to first assess qualitative factors to determine whether it is necessary to perform the
   two-step quantitative goodwill impairment test. An entity will no longer be required to calculate
   the fair value of a reporting unit unless the entity determines, based on a qualitative assessment,
   that it is more likely than not that its fair value is less than its carrying amount. This update
   is effective for annual and interim goodwill impairment tests performed for fiscal years beginning
   after December 15, 2011, with early adoption permitted. We plan to adopt this amendment during the
   fourth quarter. We do not expect the adoption of this amendment will have a material impact on our
   consolidated results of operations or financial condition.

[0000950123-11-094914:notes:9]
In June 2011, the FASB issued Accounting Standards Update No. 2011-05, Presentation of
   Comprehensive Income (ASU 2011-05). ASU 2011-05 requires companies to present the components of
   net income and other comprehensive income either as one continuous statement or as two consecutive
   statements. ASU 2011-05 eliminates the option to present the components of other comprehensive
   income as part of the statement of changes in stockholders’ equity. While ASU 2011-05 changes the
   presentation of comprehensive income, it does not change the components that are recognized in net
   income or comprehensive income under current accounting guidance. This update is effective for
   fiscal years, and interim periods within those years, ending after December 15, 2011, with early
   adoption permitted. We plan to adopt this amendment during the first quarter of 2012. Since ASU
   2011-05 affects presentation only, it will have no effect on our consolidated results of operations
   or financial condition.

[0000950123-11-094914:notes:10]
In May 2011, the FASB issued Accounting Standards Update No. 2011-04, Amendments to Achieve Common
   Fair Value Measurement and Disclosure Requirements in U.S. GAAP and IFRSs (ASU 2011-04). ASU
   2011-04 is intended to improve the comparability of fair value measurements presented and disclosed
   in financial statements prepared in
   accordance with U.S. GAAP and IFRS. The amendments are of two types: (i) those that clarify the
   Board’s intent about the application of existing fair value measurement and disclosure requirements
   and (ii) those that change a particular principle or requirement for measuring fair value or for
   disclosing information about fair value measurements. This update is effective for annual periods
   beginning after December 15, 2011. We do not expect the adoption of this amendment will have a
   material impact on our consolidated results of operations or financial condition.

[0000950123-11-094914:notes:11]
During the nine months ended September 30, 2011, we adopted the following accounting standards,
   which had no material effect on our consolidated results of operations or financial condition:

[0000950123-11-094914:notes:12]
In October 2009, the FASB issued Accounting Standards Update No. 2009-13, Multiple-Deliverable
   Revenue Arrangements (ASU 2009-13). ASU 2009-13 provides amendments to the criteria in Subtopic
   605-25 of the ASC for separating consideration in multiple-deliverable arrangements. As a result
   of those amendments, multiple-deliverable arrangements are separated in more circumstances than
   under previously existing U.S. GAAP. ASU 2009-13 established a selling price hierarchy for
   determining the selling price of a deliverable and replaced the term fair value in the revenue
   allocation guidance with selling price to clarify that the allocation of revenue is based on
   entity-specific assumptions rather than assumptions of a marketplace participant. ASU 2009 -13
   also eliminated the residual method of allocation and required that arrangement consideration be
   allocated at the inception of the arrangement to all deliverables using the relative selling price
   method and required that a vendor determine its best estimate of selling price in a manner that is
   consistent with that used to determine the price to sell the deliverable on a standalone basis.

[0000950123-11-094914:notes:13]
[same as prior period, unchanged from 0000950123-11-071519:notes:12]

[0000950123-11-094914:notes:14]
We adopted this amendment during the first quarter of 2011. The adoption of this amendment had no
   effect on our consolidated results of operations and financial condition for the three or nine
   months ended September 30, 2011.

[0000950123-11-094914:notes:15]
In October 2009, the FASB issued Accounting Standards Update No. 2009-14, Certain Revenue
   Arrangements that Include Software Arrangements. ASU 2009-14 changed the accounting model for
   revenue arrangements that include both tangible products and software elements. Tangible products
   containing software components and non-software components that function together to deliver the
   tangible product’s essential functionality are no longer within the scope of the software revenue
   guidance in Subtopic 985-605 of the ASC. In addition, ASU 2009-14 requires that hardware
   components of a tangible product containing software components always be excluded from the
   software revenue guidance. In that regard, ASU 2009-14 provides additional guidance on how to
   determine which software, if any, relating to the tangible product also would be excluded from the
   scope of the software revenue guidance. ASU 2009-14 also provides guidance on how a vendor should
   allocate arrangement consideration to deliverables in an arrangement that includes both tangible
   products and software. ASU 2009-14 also provides further guidance on how to allocate arrangement
   consideration when an arrangement includes deliverables both included and excluded from the scope
   of the software revenue guidance. We adopted this amendment during the first quarter of 2011. The
   adoption of this amendment had no effect on our consolidated results of operations and financial
   condition for the three or nine months ended September 30, 2011.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000950123-11-094914:notes:16]
2. BUSINESS COMBINATIONS

[0000950123-11-094914:notes:17]
On August 4, 2011, we acquired all of the outstanding stock of Bluesocket, Inc., a provider of
   wireless network solutions with virtual control, for $23.8 million in cash. The acquisition
   provides us with IEEE802.11N enterprise class wireless LAN expertise, technology, and products to
   address the growing transition within small-medium enterprises and large enterprises to wireless
   networks and mobile devices. We have included the financial results of Bluesocket in our
   consolidated financial statements since the date of acquisition. Pro forma results of operations
   for the acquisition have not been presented because the effect of the acquisition was not material to
   our financial results. The preliminary allocation of the purchase price to the estimated fair
   value of the assets acquired and liabilities assumed at the acquisition date is as follows:

[0000950123-11-094914:notes:18]
| (In Thousands) |  |  |  |  |
| Cash |  | $ | 1,027 |  |
| Accounts receivable |  |  | 297 |  |
| Inventory |  |  | 792 |  |
| Prepaid expenses |  |  | 357 |  |
| Property, plant and equipment |  |  | 173 |  |
| Deferred tax assets, net |  |  | 11,411 |  |
| Accounts payable |  |  | (441 | ) |
| Unearned revenue |  |  | (600 | ) |
| Accrued expenses |  |  | (332 | ) |
| Net assets acquired |  |  | 12,684 |  |
| Customer relationships |  |  | 1,700 |  |
| Developed technology |  |  | 3,590 |  |
| Intellectual property |  |  | 1,070 |  |
| Trade names |  |  | 300 |  |
| Goodwill |  |  | 4,445 |  |
| Total purchase price |  | $ | 23,789 |  |

[0000950123-11-094914:notes:19]
The net deferred tax assets acquired are primarily related to net operating losses and previously
   capitalized and unamortized research and development expense for tax deduction purposes.

[0000950123-11-094914:notes:20]
The fair value of the customer relationships, developed technology and intellectual property
   acquired was calculated using an income approach (excess earnings method) and is being amortized
   using the straight-line method. The customer relationships and intellectual property are being
   amortized over an estimated useful life of 7 years and the developed technology is being amortized
   over an average estimated useful life of 4.5 years.

[0000950123-11-094914:notes:21]
The fair value of the trade names acquired was calculated using an income approach (relief from
   royalty method) and is being amortized using the straight-line method over the estimate useful life
   of 4.5 years.

[0000950123-11-094914:notes:22]
The goodwill of $4.4 million generated from this acquisition is primarily related to expected
   synergies and was assigned to our Enterprise Networks division. We are evaluating the tax
   treatment options associated with this transaction. Currently, we do not believe any of the
   goodwill will be deductible for U.S. federal income tax purposes.

[0000950123-11-094914:notes:23]
During the three months ended September 30, 2011, we incurred acquisition related expenses and
   amortization of acquired intangibles of $1.0 million related to this acquisition.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000950123-11-094914:notes:24]
3. INCOME TAXES

[0000950123-11-094914:notes:25]
Our effective tax rate for the nine months ended September 30, 2011 was 33.2%. The difference
   between our effective tax rate and the federal statutory rate for the nine months ended September
   30, 2011 is primarily attributable to a benefit for the research tax credit of 2.2 percentage
   points and a benefit for the manufacturer’s domestic production activities deduction of 2.0
   percentage points, partially offset by state income tax provisions of 2.3 percentage points.

[0000950123-11-094914:notes:26]
Our effective tax rate for the nine months ended September 30, 2010 was 34.6%. The difference
   between our effective tax rate and the federal statutory rate for the nine months ended September
   30, 2010 is primarily attributable to a benefit for the manufacturer’s domestic production
   activities deduction of 2.5 percentage points, partially offset by state income tax provisions of
   2.4 percentage points. The tax provision for the nine months ended September 30, 2010 did not
   include the benefit of the research tax credit, which expired on December 31, 2009. The credit was
   reinstated during the fourth quarter of 2010.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000950123-11-094914:notes:27]
4. STOCK-BASED COMPENSATION

[0000950123-11-094914:notes:28]
The following table summarizes the stock-based compensation expense related to stock options,
   restricted stock units (RSUs) and restricted stock under the Stock Compensation Topic of the FASB
   Accounting Standards Codification (ASC) for the three and nine months ended September 30, 2011 and
   2010, which was recognized as follows:

[0000950123-11-094914:notes:29]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
| Stock-based compensation expense included in cost of sales |  | $ | 100 |  |  | $ | 69 |  |  | $ | 280 |  |  | $ | 210 |  |
| Selling, general and administrative expense |  |  | 1,090 |  |  |  | 775 |  |  |  | 3,096 |  |  |  | 2,360 |  |
| Research and development expense |  |  | 1,100 |  |  |  | 886 |  |  |  | 3,079 |  |  |  | 2,657 |  |
| Stock-based compensation expense included in operating expenses |  |  | 2,190 |  |  |  | 1,661 |  |  |  | 6,175 |  |  |  | 5,017 |  |
| Total stock-based compensation expense |  |  | 2,290 |  |  |  | 1,730 |  |  |  | 6,455 |  |  |  | 5,227 |  |
| Tax benefit for expense associated with non-qualified options |  |  | (302 | ) |  |  | (43 | ) |  |  | (1,018 | ) |  |  | (415 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 1,988 |  |  | $ | 1,687 |  |  | $ | 5,437 |  |  | $ | 4,812 |  |

[0000950123-11-094914:notes:30]
[same as prior period, unchanged from 0000950123-11-071519:notes:21]

[0000950123-11-094914:notes:31]
The weighted-average assumptions and value of options granted for the three and nine months ended
   September 30, 2011 and 2010 are summarized as follows:

[0000950123-11-094914:notes:32]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
| Expected volatility |  |  | 38.31 | % |  |  | 39.75 | % |  |  | 38.31 | % |  |  | 40.92 | % |
| Risk-free interest rate |  |  | 1.00 | % |  |  | 1.98 | % |  |  | 1.00 | % |  |  | 2.47 | % |
| Expected dividend yield |  |  | 1.19 | % |  |  | 1.27 | % |  |  | 1.19 | % |  |  | 1.51 | % |
| Expected life (in years) |  |  | 5.14 |  |  |  | 5.38 |  |  |  | 5.14 |  |  |  | 5.19 |  |
| Weighted-average estimated value |  | $ | 9.52 |  |  | $ | 9.72 |  |  | $ | 9.54 |  |  | $ | 8.29 |  |

[0000950123-11-094914:notes:33]
The fair value of our RSUs is calculated using a Monte Carlo Simulation valuation method. There
   were no RSU grants during the nine months ended September 30, 2011 or 2010.

[0000950123-11-094914:notes:34]
The fair value of restricted stock is equal to the closing price of our stock on the date of grant.
   There were no restricted stock grants during the nine months ended September 30, 2011 or 2010.

[0000950123-11-094914:notes:35]
Stock-based compensation expense recognized in our Consolidated Statements of Income for the three
   and nine months ended September 30, 2011 and 2010 is based on options, RSUs and restricted stock
   ultimately expected to vest, and has been reduced for estimated forfeitures. Estimated forfeitures
   for stock options were based upon historical experience and approximate 2.0% annually. We
   estimated a 0% forfeiture rate for our RSUs and restricted stock due to the limited number of
   recipients and historical experience for these awards.

[0000950123-11-094914:notes:36]
As of September 30, 2011, total compensation expense related to non-vested stock options, RSUs and
   restricted stock not yet recognized was approximately $23.0 million, which is expected to be
   recognized over an average remaining recognition period of 3.1 years.

[0000950123-11-094914:notes:37]
The following table is a summary of our stock options outstanding as of December 31, 2010 and
   September 30, 2011 and the changes that occurred during the nine months ended September 30, 2011:

[0000950123-11-094914:notes:38]
|  |  |  |  |  |  |  |  |  |  | Weighted Avg. |  |  |  |  |
|  |  |  |  |  |  |  |  |  |  | Remaining |  |  | Aggregate |  |
|  |  | Number of |  |  | Weighted Avg. |  |  | Contractual |  |  | Intrinsic |  |
| (In thousands, except per share amounts) |  | Options |  |  | Exercise Price |  |  | Life In Years |  |  | Value |  |
| Options outstanding, December 31, 2010 |  |  | 6,234 |  |  | $ | 23.09 |  |  |  | 6.21 |  |  | $ | 81,561 |  |
| Options granted |  |  | 992 |  |  | $ | 30.47 |  |  |  |  |  |  |  |  |  |
| Options cancelled/forfeited |  |  | (58 | ) |  | $ | 26.61 |  |  |  |  |  |  |  |  |  |
| Options exercised |  |  | (1,752 | ) |  | $ | 19.36 |  |  |  |  |  |  |  |  |  |
| Options outstanding, September 30, 2011 |  |  | 5,416 |  |  | $ | 25.61 |  |  |  | 7.01 |  |  | $ | 24,647 |  |
| Options exercisable, September 30, 2011 |  |  | 2,221 |  |  | $ | 23.30 |  |  |  | 4.63 |  |  | $ | 13,700 |  |

[0000950123-11-094914:notes:39]
The aggregate intrinsic values in the table above represent the total pre-tax intrinsic value (the
   difference between ADTRAN’s closing stock price on the last trading day of the quarter and the
   exercise price, multiplied by the number of in-the-money options) that would have been received by
   the option holders had all option holders exercised their options on September 30, 2011. The
   aggregate intrinsic value will change based on the fair market value of ADTRAN’s stock.

[0000950123-11-094914:notes:40]
The total pre-tax intrinsic value of options exercised during the three and nine month periods
   ended September 30, 2011 was $0.5 million and $39.5 million, respectively.

[0000950123-11-094914:notes:41]
The following table is a summary of our RSUs and restricted stock outstanding as of December 31,
   2010 and September 30, 2011 and the changes that occurred during the nine months ended September
   30, 2011:

[0000950123-11-094914:notes:42]
|  |  |  |  |  |  | Weighted |  |
|  |  |  |  |  |  | Average |  |
|  |  | Number of |  |  | Grant Date |  |
| (In thousands, except per share amounts) |  | Shares |  |  | Fair Value |  |
| RSUs and restricted stock outstanding, December 31, 2010 |  |  | 87 |  |  | $ | 28.46 |  |
| RSUs and restricted stock granted |  |  | — |  |  | $ | — |  |
| RSUs and restricted stock vested |  |  | — |  |  | $ | — |  |
| RSUs and restricted stock cancelled/forfeited |  |  | — |  |  | $ | — |  |
| Unvested RSUs and restricted stock, September 30, 2011 |  |  | 87 |  |  | $ | 28.46 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000950123-11-094914:notes:43]
5. INVESTMENTS

[0000950123-11-094914:notes:44]
At September 30, 2011, we held the following securities and investments, recorded at either fair
   value or cost:

[0000950123-11-094914:notes:45]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Carrying |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Deferred compensation plan assets |  | $ | 6,636 |  |  | $ | 113 |  |  | $ | (635 | ) |  | $ | 6,114 |  |
| Corporate bonds |  |  | 178,560 |  |  |  | 316 |  |  |  | (2,219 | ) |  |  | 176,657 |  |
| Municipal fixed-rate bonds |  |  | 140,405 |  |  |  | 578 |  |  |  | (37 | ) |  |  | 140,946 |  |
| Municipal variable rate demand notes |  |  | 60,705 |  |  |  | — |  |  |  | — |  |  |  | 60,705 |  |
| Fixed income bond fund |  |  | 526 |  |  |  | 165 |  |  |  | — |  |  |  | 691 |  |
| Marketable equity securities |  |  | 12,662 |  |  |  | 22,391 |  |  |  | (1,076 | ) |  |  | 33,977 |  |
| Available-for-sale securities held at fair value |  | $ | 399,494 |  |  | $ | 23,563 |  |  | $ | (3,967 | ) |  | $ | 419,090 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 48,250 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 2,152 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 469,492 |  |

[0000950123-11-094914:notes:46]
At December 31, 2010, we held the following securities and investments, recorded at either fair
   value or cost:

[0000950123-11-094914:notes:47]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Carrying |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Deferred compensation plan assets |  | $ | 3,483 |  |  | $ | 770 |  |  | $ | (7 | ) |  | $ | 4,246 |  |
| Corporate bonds |  |  | 126,671 |  |  |  | 630 |  |  |  | (229 | ) |  |  | 127,072 |  |
| Municipal fixed-rate bonds |  |  | 71,212 |  |  |  | 268 |  |  |  | (13 | ) |  |  | 71,467 |  |
| Municipal variable rate demand notes |  |  | 116,745 |  |  |  | — |  |  |  | — |  |  |  | 116,745 |  |
| Fixed income bond fund |  |  | 526 |  |  |  | 220 |  |  |  | — |  |  |  | 746 |  |
| Marketable equity securities |  |  | 11,486 |  |  |  | 36,657 |  |  |  | (133 | ) |  |  | 48,010 |  |
| Available-for-sale securities held at fair value |  | $ | 330,123 |  |  | $ | 38,545 |  |  | $ | (382 | ) |  | $ | 368,286 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 48,250 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 2,103 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 418,639 |  |

[0000950123-11-094914:notes:48]
At September 30, 2011, we held $6.1 million of deferred compensation plan assets, carried at fair
   value.

[0000950123-11-094914:notes:49]
At September 30, 2011, we held $176.7 million of corporate bonds. These bonds are classified as
   available-for-sale and had an average duration of 0.9 years at September 30, 2011. At September
   30, 2011, approximately 1% of our corporate bond portfolio had a credit rating of AAA, 13% had a
   credit rating of AA, 48% had a credit rating of A, and 38% had a credit rating of BBB. Because our
   bond portfolio has a high quality rating and contractual maturities of a short duration, we are
   able to obtain prices for these bonds derived from observable market inputs, or for similar
   securities traded in an active market, on a daily basis.

[0000950123-11-094914:notes:50]
At September 30, 2011, we held $140.9 million of municipal fixed-rate bonds. These bonds are
   classified as available-for-sale and had an average duration of 1.1 years at September 30, 2011.
   At September 30, 2011, approximately 16% of our municipal fixed-rate bond portfolio had a credit
   rating of AAA, 66% had a credit rating of AA, and 18% had a credit rating of A. Because our bond
   portfolio has a high quality rating and contractual maturities of a short duration, we are able to
   obtain prices for these bonds derived from observable market inputs, or for similar securities
   traded in an active market, on a daily basis.

[0000950123-11-094914:notes:51]
At September 30, 2011, we held $60.7 million of municipal variable rate demand notes, all of which
   were classified as available-for-sale. At September 30, 2011, 14% of our municipal variable rate
   demand notes had a credit rating of AAA,
   72% had a credit rating of AA, 14% had a credit rating of A, and all contained put options of seven
   days. Despite the long-term nature of their stated contractual maturities, we routinely buy and
   sell these securities and we believe that we have the ability to quickly liquidate them. Our
   investments in these securities are recorded at fair value, and the interest rates reset every
   seven days. We believe we have the ability to sell our variable rate demand notes to the
   remarketing agent, tender agent or issuer at par value plus accrued interest in the event we decide
   to liquidate our investment in a particular variable rate demand note. At September 30, 2011,
   approximately 40% of our variable rate demand notes were supported by letters of credit from banks
   that we believe to be in good financial condition. The remaining 60% of our variable rate demand
   notes were supported by standby purchase agreements. As a result of these factors, we had no
   cumulative gross unrealized holding gains (losses) or gross realized gains (losses) from these
   investments. All income generated from these investments was recorded as interest income. We have
   not recorded any losses relating to municipal variable rate demand notes.

[0000950123-11-094914:notes:52]
At September 30, 2011, we held $0.7 million of a fixed income bond fund.

[0000950123-11-094914:notes:53]
At September 30, 2011, we held $34.0 million of marketable equity securities, including a single
   security, of which we held 1.2 million shares, carried at a fair value of $21.3 million. We sold
   0.3 million shares of this security during the nine months ended September 30, 2011. The sale of
   this security resulted in proceeds of $6.1 million and a realized gain of $6.0 million. This
   single security traded an average of approximately 0.9 million shares per day in the first nine
   months of 2011 in an active market on a European stock exchange. This single security comprises
   $20.9 million of the gross unrealized gains included in the fair value of our marketable equity
   securities at September 30, 2011. The remaining $1.5 million of gross unrealized gains and $1.1
   million of gross unrealized losses at September 30, 2011 were spread amongst more than 400 equity
   securities.

[0000950123-11-094914:notes:54]
At September 30, 2011, we held a $48.3 million restricted certificate of deposit, which is carried
   at cost. This investment serves as a collateral deposit against the principal amount outstanding
   under loans made to ADTRAN pursuant to an Alabama State Industrial Development Authority revenue
   bond (the Bond). At September 30, 2011, the estimated fair value of the Bond was approximately
   $48.3 million, based on a debt security with a comparable interest rate and maturity and a Standard
   and Poor’s credit rating of A+. We have the right to set-off the balance of the Bond with the
   collateral deposit in order to reduce the balance of the indebtedness. For more information on the
   Bond, see “Debt” under “Liquidity and Capital Resources” in the “Management’s Discussion and
   Analysis of Financial Condition and Results of Operations” contained in Item 2 of Part I of this
   report.

[0000950123-11-094914:notes:55]
At September 30, 2011, we held $2.2 million of other investments carried at cost, consisting of
   interests in two private equity funds and an investment in a privately held telecommunications
   equipment manufacturer. The fair value of these investments was estimated to be approximately
   $10.4 million at September 30, 2011, based on unobservable inputs including information supplied by
   the company and the fund managers. We have committed to invest up to an aggregate of $7.9 million
   in the two private equity funds, and we have contributed $8.4 million as of September 30, 2011, of
   which $7.7 million has been applied toward these commitments. As of September 30, 2011, we have
   received distributions related to these two private equity funds of $8.5 million, of which $2.0
   million was recorded as investment income. These investments are carried at cost, net of
   distributions, with distributions in excess of our investment recorded as investment income. The
   remaining commitment under the funds is $0.2 million, which expires in 2013. We have not been
   required to record any impairment losses related to these investments during the nine months ended
   September 30, 2011.

[0000950123-11-094914:notes:56]
We review our investment portfolio for potential “other-than-temporary” declines in value on an
   individual investment basis. We assess, on a quarterly basis, significant declines in value which
   may be considered other-than-temporary and, if necessary, recognize and record the appropriate
   charge to write-down the carrying value of such investments. In making this assessment, we take
   into consideration qualitative and quantitative information, including but not limited to the
   following: the magnitude and duration of historical declines in market prices, credit rating
   activity, assessments of liquidity, public filings, and statements made by the issuer. We
   generally begin our identification of potential other-than-temporary impairments by reviewing any
   security with a fair value that has declined from its original or adjusted cost basis by 25% or
   more for six or more consecutive months. We then evaluate the individual security based on the
   previously identified factors to determine the amount of the write-down, if any. As a result of
   our review, we recorded an other-than-temporary impairment charge of $32 thousand during the nine
   months ended September 30, 2011 related to
   seven marketable equity securities. For the nine months ended September 30, 2010, we recorded an
   other-than-temporary impairment charge of $43 thousand related to five marketable equity
   securities.

[0000950123-11-094914:notes:57]
In accordance with the Fair Value Measurements and Disclosures Topic of the FASB ASC, we have
   categorized our cash equivalents held in money market funds and our investments held at fair value
   into a three-level fair value hierarchy based on the priority of the inputs to the valuation
   technique for the cash equivalents and investments as follows: Level 1 — Values based on
   unadjusted quoted prices for identical assets or liabilities in an active market; Level 2 — Values
   based on quoted prices in markets that are not active or model inputs that are observable either
   directly or indirectly; Level 3 — Values based on prices or valuation techniques that require
   inputs that are both unobservable and significant to the overall fair value measurement. These
   inputs include information supplied by investees.

[0000950123-11-094914:notes:58]
|  |  | Fair Value Measurements at September 30, 2011 Using |  |
|  |  |  |  |  |  | Quoted Prices |  |  |  |  |  |  |  |
|  |  |  |  |  |  | in Active |  |  | Significant |  |  |  |  |
|  |  |  |  |  |  | Market for |  |  | Other |  |  | Significant |  |
|  |  |  |  |  |  | Identical |  |  | Observable |  |  | Unobservable |  |
|  |  |  |  |  |  | Assets |  |  | Inputs |  |  | Inputs |  |
| (In thousands) |  | Fair Value |  |  | (Level 1) |  |  | (Level 2) |  |  | (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 7,898 |  |  | $ | 7,898 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 6,114 |  |  |  | 6,114 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 176,657 |  |  |  | — |  |  |  | 176,657 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 140,946 |  |  |  | — |  |  |  | 140,946 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 60,705 |  |  |  | — |  |  |  | 60,705 |  |  |  | — |  |
| Fixed income bond fund |  |  | 691 |  |  |  | 691 |  |  |  | — |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity securities — technology industry |  |  | 22,701 |  |  |  | 22,701 |  |  |  | — |  |  |  | — |  |
| Equity securities — other |  |  | 11,276 |  |  |  | 11,276 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 419,090 |  |  |  | 40,782 |  |  |  | 378,308 |  |  |  | — |  |
| Total |  | $ | 426,988 |  |  | $ | 48,680 |  |  | $ | 378,308 |  |  | $ | — |  |

[0000950123-11-094914:notes:59]
|  |  | Fair Value Measurements at December 31, 2010 Using |  |
|  |  |  |  |  |  | Quoted Prices |  |  |  |  |  |  |  |
|  |  |  |  |  |  | in Active |  |  | Significant |  |  |  |  |
|  |  |  |  |  |  | Market for |  |  | Other |  |  | Significant |  |
|  |  |  |  |  |  | Identical |  |  | Observable |  |  | Unobservable |  |
|  |  |  |  |  |  | Assets |  |  | Inputs |  |  | Inputs |  |
| (In thousands) |  | Fair Value |  |  | (Level 1) |  |  | (Level 2) |  |  | (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 14,532 |  |  | $ | 14,532 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 4,246 |  |  |  | 4,246 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 127,072 |  |  |  | — |  |  |  | 127,072 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 71,467 |  |  |  | — |  |  |  | 71,467 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 116,745 |  |  |  | — |  |  |  | 116,745 |  |  |  | — |  |
| Fixed income bond fund |  |  | 746 |  |  |  | 746 |  |  |  | — |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity securities — technology industry |  |  | 35,596 |  |  |  | 35,596 |  |  |  | — |  |  |  | — |  |
| Equity securities — other |  |  | 12,414 |  |  |  | 12,414 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 368,286 |  |  |  | 53,002 |  |  |  | 315,284 |  |  |  | — |  |
| Total |  | $ | 382,818 |  |  | $ | 67,534 |  |  | $ | 315,284 |  |  | $ | — |  |

[0000950123-11-094914:notes:60]
As of September 30, 2011 and December 31, 2010, the fair value of the investments in
   available-for-sale Level 2 corporate bonds and municipal fixed-rate bonds was $317.6 million and
   $198.5 million, respectively. The fair value of these securities is calculated using a weighted
   average market price for each security. Market prices are obtained from a variety of industry
   standard data providers, security master files from large financial institutions, and other
   third-party sources. These multiple market prices are used as inputs into a
   distribution-curve-based algorithm to determine the daily market value of each security.

[0000950123-11-094914:notes:61]
As of September 30, 2011 and December 31, 2010, the fair value of the investments in
   available-for-sale Level 2 municipal variable rate demand notes was $60.7 million and $116.7
   million, respectively. These securities have a structure that implies a standard expected market
   price. The frequent interest rate resets make it reasonable to expect the price to stay at par.
   These securities are priced at the expected market price.


## us-gaap:InventoryDisclosureTextBlock

[0000950123-11-094914:notes:62]
6. INVENTORY

[0000950123-11-094914:notes:63]
At September 30, 2011 and December 31, 2010, inventory consisted of the following:

[0000950123-11-094914:notes:64]
|  |  | September 30, |  |  | December 31, |  |
| (In thousands) |  | 2011 |  |  | 2010 |  |
| Raw materials |  | $ | 43,938 |  |  | $ | 43,897 |  |
| Work in process |  |  | 4,806 |  |  |  | 2,871 |  |
| Finished goods |  |  | 38,569 |  |  |  | 27,506 |  |
| Total |  | $ | 87,313 |  |  | $ | 74,274 |  |

[0000950123-11-094914:notes:65]
We establish reserves for estimated excess, obsolete, or unmarketable inventory equal to the
   difference between the cost of the inventory and the estimated fair value of the inventory based
   upon assumptions about future demand and market conditions. At September 30, 2011 and December 31,
   2010, raw materials reserves totaled $8.1 million and $7.3 million, respectively, and finished
   goods inventory reserves totaled $2.1 million and $1.6 million, respectively.


## us-gaap:GoodwillDisclosureTextBlock

[0000950123-11-094914:notes:66]
7. GOODWILL AND INTANGIBLE ASSETS

[0000950123-11-094914:notes:67]
The changes in the carrying value of goodwill included in our Enterprise Networks division for the
   nine months ended September 30, 2011 are as follows:

[0000950123-11-094914:notes:68]
| (In thousands) |  |  |  |  |
| Balance, December 31, 2010 |  | $ | — |  |
| Acquisitions |  |  | 4,445 |  |
| Impairment losses |  |  | — |  |
| Balance, September 30, 2011 |  | $ | 4,445 |  |
| Balance as of September 30, 2011: |  |  |  |  |
| Goodwill |  | $ | 4,445 |  |
| Accumulated impairment losses |  |  | — |  |
| Total goodwill |  | $ | 4,445 |  |

[0000950123-11-094914:notes:69]
We evaluate the carrying value of goodwill during the fourth quarter of each year and between
   annual evaluations if events occur or circumstances change that would more likely than not reduce
   the fair value of the reporting unit below its carrying amount. When evaluating whether goodwill
   is impaired, we compare the fair value of the reporting unit to which the goodwill is assigned to
   the reporting unit’s carrying amount, including goodwill. If the carrying amount of the reporting
   unit exceeds its fair value, then the amount of the impairment loss is measured.

[0000950123-11-094914:notes:70]
The following table presents our intangible assets as of September 30, 2011 and December 31, 2010.
   Intangible assets are included in other assets in the accompanying Consolidated Balance Sheets and
   include intangibles acquired with our acquisition of Objectworld Communications Corporation on
   September 15, 2009 and Bluesocket, Inc. on August 4, 2011.

[0000950123-11-094914:notes:71]
|  |  | September 30, 2011 |  |  | December 31, 2010 |  |
|  |  | Gross |  |  | Accumulated |  |  |  |  |  |  | Gross |  |  | Accumulated |  |  |  |  |
| (In thousands) |  | Value |  |  | Amortization |  |  | Net Value |  |  | Value |  |  | Amortization |  |  | Net Value |  |
| Customer relationships |  | $ | 1,793 |  |  | $ | 133 |  |  | $ | 1,660 |  |  | $ | 93 |  |  | $ | 60 |  |  | $ | 33 |  |
| Developed technology |  |  | 3,590 |  |  |  | 121 |  |  |  | 3,469 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Intellectual property |  |  | 2,480 |  |  |  | 437 |  |  |  | 2,043 |  |  |  | 1,410 |  |  |  | 260 |  |  |  | 1,150 |  |
| Trade names |  |  | 300 |  |  |  | 11 |  |  |  | 289 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 8,163 |  |  | $ | 702 |  |  | $ | 7,461 |  |  | $ | 1,503 |  |  | $ | 320 |  |  | $ | 1,183 |  |

[0000950123-11-094914:notes:72]
Amortization expense was $0.3 million and $0.4 million for the three and nine months ended
   September 30, 2011, respectively, and $0.1 million and $0.2 million for the three and nine months
   ended September 30, 2010, respectively.

[0000950123-11-094914:notes:73]
As of September 30, 2011, the estimated future amortization expense of intangible assets is as
   follows:

[0000950123-11-094914:notes:74]
| (In thousands) |  | Amount |  |
| Remainder of 2011 |  | $ | 347 |  |
| 2012 |  |  | 1,389 |  |
| 2013 |  |  | 1,389 |  |
| 2014 |  |  | 1,228 |  |
| 2015 |  |  | 1,117 |  |
| 2016 and thereafter |  |  | 1,991 |  |
| Total |  | $ | 7,461 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000950123-11-094914:notes:75]
8. STOCKHOLDERS’ EQUITY

[0000950123-11-094914:notes:76]
A summary of the changes in stockholders’ equity for the nine months ended September 30, 2011 is as
   follows:

[0000950123-11-094914:notes:77]
|  |  | Stockholders’ |  |
| (In thousands) |  | Equity |  |
| Balance, December 31, 2010 |  | $ | 572,322 |  |
| Net income |  |  | 107,414 |  |
| Dividend payments |  |  | (17,395 | ) |
| Dividends accrued for unvested restricted stock units |  |  | (22 | ) |
| Net change in unrealized gains (losses) on marketable securities (net of deferred taxes) |  |  | (11,259 | ) |
| Reclassification adjustment for amounts included in net income (net of deferred taxes) |  |  | (682 | ) |
| Foreign currency translation adjustment |  |  | (1,031 | ) |
| Proceeds from stock option exercises |  |  | 33,631 |  |
| Tax benefits from stock option exercises |  |  | 10,457 |  |
| Stock-based compensation expense |  |  | 6,455 |  |
| Purchases of treasury stock |  |  | (35,178 | ) |
| Balance, September 30, 2011 |  | $ | 664,712 |  |

[0000950123-11-094914:notes:78]
[same as prior period, unchanged from 0000950123-11-071519:notes:60]

[0000950123-11-094914:notes:79]
Since 1997, our Board of Directors has approved multiple share repurchase programs that have
   authorized open market repurchase transactions of up to 30 million shares of our common stock.
   During the nine months ended September 30, 2011, we repurchased 1.1 million shares of our common
   stock at an average price of $31.98 per share. We have the authority to purchase an additional 0.9
   million shares of our common stock under the plan approved by the Board of Directors on April 14,
   2008.

[0000950123-11-094914:notes:80]
On October 11, 2011, we announced that our Board of Directors had authorized the repurchase of an
   additional 5.0 million shares of our common stock to commence upon completion of the repurchase
   plan announced on April 14, 2008. Upon completion of the current plan, under which we have the
   remaining authority to purchase 0.9 million shares, the new plan to repurchase 5.0 million shares
   will be implemented through open market or private purchases from time to time as conditions
   warrant.

[0000950123-11-094914:notes:81]
[same as prior period, unchanged from 0000950123-11-071519:notes:62]

[0000950123-11-094914:notes:82]
We issued 1.8 million shares of treasury stock during the nine months ended September 30, 2011 to
   accommodate employee stock option exercises. The stock options had exercise prices ranging from
   $10.50 to $36.64. We received proceeds totaling $33.6 million from the exercise of these stock
   options during the nine months ended September 30, 2011.

[0000950123-11-094914:notes:83]
[same as prior period, unchanged from 0000950123-11-071519:notes:64]

[0000950123-11-094914:notes:84]
During the nine months ended September 30, 2011, we paid cash dividends as follows (in thousands
   except per share amount):

[0000950123-11-094914:notes:85]
| Record Date |  | Payment Date |  |  | Per Share Amount |  |  | Total Dividend Paid |  |
| February 3, 2011 |  | February 17, 2011 |  |  | $ | 0.09 |  |  | $ | 5,775 |  |
| April 28, 2011 |  | May 12, 2011 |  | $ | 0.09 |  |  | $ | 5,821 |  |
| July 28, 2011 |  | August 11, 2011 |  | $ | 0.09 |  |  | $ | 5,799 |  |

[0000950123-11-094914:notes:86]
[same as prior period, unchanged from 0000950123-11-071519:notes:67]

[0000950123-11-094914:notes:87]
[same as prior period, unchanged from 0000950123-11-071519:notes:68]

[0000950123-11-094914:notes:88]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
| Net income |  | $ | 36,213 |  |  | $ | 32,084 |  |  | $ | 107,414 |  |  | $ | 78,029 |  |
| Net change in unrealized gains (losses) related to marketable securities, net of deferred tax benefit (expense) of $3,533 and $(2,538) for the three months ended September 30, 2011 and 2010, respectively, and $6,235 and $(1,907) for the nine months ended September 30, 2011 and 2010, respectively |  |  | (5,468 | ) |  |  | 4,230 |  |  |  | (11,259 | ) |  |  | 3,174 |  |
| Reclassification adjustment for amounts included in net income, net of deferred tax benefit of $195 and $47 for the three months ended September 30, 2011 and 2010, respectively, and $381 and $174 for the nine months ended September 30, 2011 and 2010, respectively |  |  | (287 | ) |  |  | (80 | ) |  |  | (682 | ) |  |  | (292 | ) |
| Foreign currency translation adjustment |  |  | (1,487 | ) |  |  | 1,465 |  |  |  | (1,031 | ) |  |  | 863 |  |
| Total comprehensive income |  | $ | 28,971 |  |  | $ | 37,699 |  |  | $ | 94,442 |  |  | $ | 81,774 |  |


## us-gaap:EarningsPerShareTextBlock

[0000950123-11-094914:notes:89]
9. EARNINGS PER SHARE

[0000950123-11-094914:notes:90]
A summary of the calculation of basic and diluted earnings per share for the three and nine months
   ended September 30, 2011 and 2010 is as follows:

[0000950123-11-094914:notes:91]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands, except per share amounts) |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
| Numerator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 36,213 |  |  | $ | 32,084 |  |  | $ | 107,414 |  |  | $ | 78,029 |  |
| Denominator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average number of shares — basic |  |  | 64,023 |  |  |  | 62,771 |  |  |  | 64,300 |  |  |  | 62,316 |  |
| Effect of dilutive securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock options |  |  | 882 |  |  |  | 1,491 |  |  |  | 1,346 |  |  |  | 1,286 |  |
| Restricted stock and restricted stock units |  |  | 56 |  |  |  | 38 |  |  |  | 51 |  |  |  | 36 |  |
| Weighted average number of shares — diluted |  |  | 64,961 |  |  |  | 64,300 |  |  |  | 65,697 |  |  |  | 63,638 |  |
| Net income per share — basic |  | $ | 0.57 |  |  | $ | 0.51 |  |  | $ | 1.67 |  |  | $ | 1.25 |  |
| Net income per share — diluted |  | $ | 0.56 |  |  | $ | 0.50 |  |  | $ | 1.63 |  |  | $ | 1.23 |  |

[0000950123-11-094914:notes:92]
Anti-dilutive options to purchase common stock outstanding were excluded from the above
   calculations. Anti-dilutive options totaled 1.5 million and 0.5 million for the three months ended
   September 30, 2011 and 2010, respectively, and 1.0 million and 2.0 million for the nine months
   ended September 30, 2011 and 2010, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000950123-11-094914:notes:93]
10. SEGMENT INFORMATION

[0000950123-11-094914:notes:94]
[same as prior period, unchanged from 0000950123-11-071519:notes:75]

[0000950123-11-094914:notes:95]
The following table presents information about the reported sales and gross profit of our
   reportable segments for the three and nine months ended September 30, 2011 and 2010. Asset
   information by reportable segment is not reported, since we do not produce such information
   internally.

[0000950123-11-094914:notes:96]
|  |  | Three Months Ended |  |
|  |  | September 30, 2011 |  |  | September 30, 2010 |  |
| (In thousands) |  | Sales |  |  | Gross Profit |  |  | Sales |  |  | Gross Profit |  |
| Carrier Networks |  | $ | 152,492 |  |  | $ | 85,944 |  |  | $ | 128,581 |  |  | $ | 77,372 |  |
| Enterprise Networks |  |  | 39,702 |  |  |  | 23,532 |  |  |  | 34,376 |  |  |  | 19,927 |  |
| Total |  | $ | 192,194 |  |  | $ | 109,476 |  |  | $ | 162,957 |  |  | $ | 97,299 |  |

[0000950123-11-094914:notes:97]
|  |  | Nine Months Ended |  |
|  |  | September 30, 2011 |  |  | September 30, 2010 |  |
| (In thousands) |  | Sales |  |  | Gross Profit |  |  | Sales |  |  | Gross Profit |  |
| Carrier Networks |  | $ | 435,344 |  |  | $ | 252,908 |  |  | $ | 345,684 |  |  | $ | 206,910 |  |
| Enterprise Networks |  |  | 106,599 |  |  |  | 62,190 |  |  |  | 94,661 |  |  |  | 55,046 |  |
| Total |  | $ | 541,943 |  |  | $ | 315,098 |  |  | $ | 440,345 |  |  | $ | 261,956 |  |

[0000950123-11-094914:notes:98]
[same as prior period, unchanged from 0000950123-11-071519:notes:79]

[0000950123-11-094914:notes:99]
[same as prior period, unchanged from 0000950123-11-071519:notes:80]

[0000950123-11-094914:notes:100]
Carrier Systems products are used by communications service providers to provide data, voice and
   video services to consumers and enterprises. The Carrier Systems category includes our broadband
   access products comprised of Total Access® 5000 multi-service access and aggregation platform
   products, Total Access 1100/1200 Series Fiber-To-The-Node (FTTN) products, and Digital Subscriber
   Line Access Multiplexer (DSLAM) products. Our broadband access products are used by service
   providers to deliver high-speed Internet access, Voice over Internet Protocol (VoIP), IP Television
   (IPTV), and/or Ethernet services from the central office or remote terminal locations to customer
   premises. The Carrier Systems category also includes our optical access products. These products
   consist of optical access multiplexers including our family of OPTI products, our family of 8000
   series products and our Optical Networking Edge (ONE) products. Optical access products are used
   to deliver higher bandwidth services, or to aggregate large numbers of low bandwidth services for
   transportation across fiber optic infrastructure. Total Access 1500 products, 303 concentrator
   products, M13 multiplexer products, and a number of mobile backhaul products are also included in
   the Carrier Systems product category.

[0000950123-11-094914:notes:101]
Business Networking products provide access to telecommunication services, facilitating the
   delivery of converged services and Unified Communications to the small and mid-sized enterprises
   (SME) market. The Business Networking category includes Internetworking products and Integrated
   Access Devices (IADs). Internetworking products consist of our Total Access IP Business Gateways,
   Optical Network Terminals (ONTs), Virtual Wireless LAN products and NetVanta product lines.
   NetVanta products include multi-service routers, managed Ethernet switches, IP Private Branch
   Exchange (PBX) products, IP phone products, Unified Communications solutions, Unified Threat
   Management (UTM) solutions, and Carrier Ethernet Network Terminating Equipment (NTE). IAD products
   consist of our Total Access 600 Series and the Total Access 850.

[0000950123-11-094914:notes:102]
[same as prior period, unchanged from 0000950123-11-071519:notes:83]

[0000950123-11-094914:notes:103]
The table below presents sales information by product category for the three and nine months ended
   September 30, 2011 and 2010.

[0000950123-11-094914:notes:104]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
| Carrier Systems |  | $ | 119,979 |  |  | $ | 76,349 |  |  | $ | 319,018 |  |  | $ | 207,590 |  |
| Business Networking |  |  | 44,919 |  |  |  | 33,830 |  |  |  | 116,981 |  |  |  | 92,452 |  |
| Loop Access |  |  | 27,296 |  |  |  | 52,778 |  |  |  | 105,944 |  |  |  | 140,303 |  |
| Total |  | $ | 192,194 |  |  | $ | 162,957 |  |  | $ | 541,943 |  |  | $ | 440,345 |  |

[0000950123-11-094914:notes:105]
[same as prior period, unchanged from 0000950123-11-071519:notes:86]

[0000950123-11-094914:notes:106]
[same as prior period, unchanged from 0000950123-11-071519:notes:87]

[0000950123-11-094914:notes:107]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
| Growth Products |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Broadband Access (included in Carrier Systems) |  | $ | 86,954 |  |  | $ | 45,099 |  |  | $ | 215,798 |  |  | $ | 126,432 |  |
| Optical Access (included in Carrier Systems) |  |  | 22,298 |  |  |  | 18,619 |  |  |  | 65,222 |  |  |  | 46,006 |  |
| Internetworking (NetVanta & Multi-service Access Gateways) (included in Business Networking) |  |  | 42,506 |  |  |  | 29,475 |  |  |  | 108,418 |  |  |  | 79,560 |  |
| Total |  |  | 151,758 |  |  |  | 93,193 |  |  |  | 389,438 |  |  |  | 251,998 |  |
| Traditional Products |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| HDSL (does not include T1) (included in Loop Access) |  |  | 25,297 |  |  |  | 49,383 |  |  |  | 100,291 |  |  |  | 131,487 |  |
| Other products (excluding HDSL) |  |  | 15,139 |  |  |  | 20,381 |  |  |  | 52,214 |  |  |  | 56,860 |  |
| Total |  |  | 40,436 |  |  |  | 69,764 |  |  |  | 152,505 |  |  |  | 188,347 |  |
| Total |  | $ | 192,194 |  |  | $ | 162,957 |  |  | $ | 541,943 |  |  | $ | 440,345 |  |

[0000950123-11-094914:notes:108]
[same as prior period, unchanged from 0000950123-11-071519:notes:89]

[0000950123-11-094914:notes:109]
The table below presents sales information by geographic area for the three and nine months ended
   September 30, 2011 and 2010. International sales correlate to shipments with a non-U.S.
   destination.

[0000950123-11-094914:notes:110]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
| United States |  | $ | 170,343 |  |  | $ | 154,648 |  |  | $ | 484,260 |  |  | $ | 416,994 |  |
| International |  |  | 21,851 |  |  |  | 8,309 |  |  |  | 57,683 |  |  |  | 23,351 |  |
| Total |  | $ | 192,194 |  |  | $ | 162,957 |  |  | $ | 541,943 |  |  | $ | 440,345 |  |


## us-gaap:ProductWarrantyDisclosureTextBlock

[0000950123-11-094914:notes:111]
11. LIABILITY FOR WARRANTY RETURNS

[0000950123-11-094914:notes:112]
Our products generally include warranties of one to ten years for product defects. We accrue for
   warranty returns at the time revenue is recognized based on our estimate of the cost to repair or
   replace the defective products. We engage in extensive product quality programs and processes,
   including actively monitoring and evaluating the quality of our component suppliers. Our products
   continue to become more complex in both size and functionality as many of our
   product offerings migrate from line card applications to systems products. The increasing
   complexity of our products will cause warranty incidences, when they arise, to be more costly. Our
   estimates regarding future warranty obligations may change due to product failure rates, material
   usage, and other rework costs incurred in correcting a product failure. In addition, from time to
   time, specific warranty accruals may be recorded if unforeseen problems arise. Should our actual
   experience relative to these factors be worse than our estimates, we will be required to record
   additional warranty expense. Alternatively, if we provide for more reserves than we require, we
   will reverse a portion of such provisions in future periods. The liability for warranty
   obligations totaled $3.9 million at September 30, 2011 and $3.3 million at December 31, 2010.
   These liabilities are included in accrued expenses in the accompanying Consolidated Balance Sheets.

[0000950123-11-094914:notes:113]
A summary of warranty expense and write-off activity for the nine months ended September 30, 2011
   and 2010 is as follows:

[0000950123-11-094914:notes:114]
| Nine Months Ended September 30, |  |  |  |  |  |  |
| (In thousands) |  | 2011 |  |  | 2010 |  |
| Balance at beginning of period |  | $ | 3,304 |  |  | $ | 2,833 |  |
| Plus: Amounts charged to cost and expenses |  |  | 2,306 |  |  |  | 2,544 |  |
| Less: Deductions |  |  | (1,743 | ) |  |  | (2,137 | ) |
| Balance at end of period |  | $ | 3,867 |  |  | $ | 3,240 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0000950123-11-094914:notes:115]
12. RELATED PARTY TRANSACTIONS

[0000950123-11-094914:notes:116]
We employ the law firm of our director emeritus for legal services. All bills for services
   rendered by this firm are reviewed and approved by our Chief Financial Officer. We believe that
   the fees for such services are comparable to those charged by other firms for services rendered to
   us. For the three and nine month periods ended September 30, 2011 and 2010, we incurred fees of
   $10 thousand per month for these legal services.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000950123-11-094914:notes:117]
13. COMMITMENTS AND CONTINGENCIES

[0000950123-11-094914:notes:118]
In the ordinary course of business, we may be subject to various legal proceedings and claims,
   including employment disputes, patent claims, disputes over contract agreements and other
   commercial disputes. In some cases, claimants seek damages or other relief, such as royalty
   payments related to patents, which, if granted, could require significant expenditures. Although
   the outcome of any claim or litigation can never be certain, it is our opinion that the outcome of
   all contingencies of which we are currently aware will not materially affect our business,
   operations, financial condition or cash flows.

[0000950123-11-094914:notes:119]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, and we
   have contributed $8.4 million as of September 30, 2011, of which $7.7 million has been applied to
   these commitments. See Note 5 of Notes to Consolidated Financial Statements for additional
   information.


## us-gaap:SubsequentEventsTextBlock

[0000950123-11-094914:notes:120]
14. SUBSEQUENT EVENTS

[0000950123-11-094914:notes:121]
On October 11, 2011, we announced that our Board of Directors declared a quarterly cash dividend of
   $0.09 per common share to be paid to stockholders of record at the close of business on October 27,
   2011. The payment date will be November 10, 2011. The quarterly dividend payment will be
   approximately $5.7 million. In July 2003, our Board of Directors elected to begin declaring
   quarterly dividends on our common stock considering the tax treatment of dividends and adequate
   levels of Company liquidity.
