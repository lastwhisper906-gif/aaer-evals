# ADTN 8-K — 0001157523-11-005682 filed 2011-10-12

## item codes, every 8-K on or before 2011-11-03

- 2011-10-13 0000950123-11-089785 — 5.03, 9.01
- 2011-10-12 0001157523-11-005682 — 2.02, 9.01
- 2011-07-13 0001157523-11-003986 — 2.02, 9.01
- 2011-05-09 0000950123-11-047191 — 5.02, 5.07, 9.01
- 2011-04-13 0001157523-11-002001 — 2.02, 9.01
- 2011-01-19 0001157523-11-000232 — 2.02, 9.01
- 2010-11-09 0000950123-10-103195 — 5.02, 9.01
- 2010-10-13 0001157523-10-005798 — 2.02, 9.01
- 2010-07-14 0001157523-10-004011 — 2.02, 9.01
- 2010-05-28 0000950123-10-053947 — 5.07
- 2010-04-14 0001157523-10-002022 — 2.02, 9.01
- 2010-01-20 0001157523-10-000200 — 2.02, 9.01
- 2009-10-28 0000950123-09-053984 — 8.01
- 2009-10-14 0001157523-09-006877 — 2.02, 9.01
- 2009-07-15 0001157523-09-004878 — 2.02, 9.01
- 2009-04-15 0001157523-09-002687 — 2.02, 9.01
- 2009-01-21 0001157523-09-000340 — 2.02, 9.01
- 2008-11-12 0001193125-08-233181 — 5.02, 9.01
- 2008-10-14 0001157523-08-007999 — 2.02, 9.01
- 2008-07-15 0001157523-08-005504 — 2.02, 9.01
- 2008-04-15 0001157523-08-002896 — 2.02, 9.01
- 2008-01-22 0001157523-08-000408 — 2.02, 9.01
- 2007-10-16 0001193125-07-219356 — 5.03, 9.01
- 2007-10-16 0001157523-07-009850 — 2.02, 9.01
- 2007-07-17 0001157523-07-006912 — 2.02, 9.01
- 2007-04-17 0001157523-07-003630 — 2.02, 9.01
- 2007-04-03 0001179022-07-000068 — 5.02
- 2007-03-28 0001179022-07-000064 — 5.02
- 2007-02-23 0001193125-07-038337 — 5.02
- 2007-02-23 0001193125-07-038335 — 5.02
- 2007-01-30 0001193125-07-015912 — 5.02, 9.01
- 2007-01-26 0001193125-07-014234 — 5.02
- 2007-01-23 0001157523-07-000494 — 2.02, 9.01 — amendment of 0001157523-07-000481
- 2007-01-23 0001157523-07-000481 — 2.02, 9.01
- 2006-10-17 0001157523-06-009945 — 2.02, 9.01
- 2006-07-18 0001157523-06-006929 — 2.02, 9.01
- 2006-06-08 0001193125-06-126486 — 1.01, 9.01
- 2006-05-10 0001193125-06-107316 — 1.01, 9.01
- 2006-04-18 0001157523-06-003699 — 2.02, 9.01
- 2006-02-03 0001179022-06-000014 — 1.01
- 2006-01-27 0001157523-06-000754 — 5.02, 9.01
- 2006-01-24 0001157523-06-000551 — 2.02, 9.01
- 2005-10-18 0001157523-05-008826 — 2.02, 9.01
- 2005-07-19 0001193125-05-143958 — 1.01, 5.02, 9.01
- 2005-07-19 0001193125-05-143957 — 2.02, 9.01
- 2005-05-20 0001193125-05-112019 — 1.01, 9.01
- 2005-04-19 0001157523-05-003418 — 2.02, 9.01
- 2005-01-25 0001193125-05-010721 — 2.02, 9.01
- 2004-10-12 0001193125-04-169652 — 2.02, 9.01
- 2004-07-13 0001193125-04-116820 — 12, 7
- 2004-04-14 0001193125-04-061547 — 12, 7
- 2004-01-21 0001193125-04-006366 — 12, 7
- 2003-10-14 0001193125-03-061018 — 12, 5, 7
- 2003-07-15 0001193125-03-019292 — 7, 9
- 2003-04-15 0000931763-03-000968 — 7, 9
- 1996-09-12 0000931763-96-000667 — 5, 7

## late-filing notifications on or before 2011-11-03

- none on or before 2011-11-03

## item 2.02 — earnings release, exhibit 99.1

[0001157523-11-005682:8k_2_02:1]
EX-99.1
2
a50026049ex99_1.htm
EXHIBIT 99.1

[0001157523-11-005682:8k_2_02:2]
Exhibit 99.1

[0001157523-11-005682:8k_2_02:3]
ADTRAN,
      Inc. Reports Record Results for Third Quarter 2011, Announces Additional
      Five Million Share Repurchase Plan and Declares Quarterly Cash Dividend

[0001157523-11-005682:8k_2_02:4]
HUNTSVILLE, Ala.--(BUSINESS WIRE)--October 11, 2011--ADTRAN, Inc.
      (NASDAQ:ADTN) reported results for the third quarter of 2011. Sales
      increased 18% to an all-time record level of $192,194,000 for the
      quarter, compared to $162,957,000 for the third quarter of 2010. Net
      income increased to $36,213,000 for the quarter, compared to $32,084,000
      for the third quarter of 2010. Earnings per share, assuming dilution,
      increased to $0.56 for the quarter, compared to $0.50 for the third
      quarter of 2010.

[0001157523-11-005682:8k_2_02:5]
ADTRAN Chief Executive Officer Tom Stanton stated, “Our Company’s strong
      performance in the quarter included record revenue performances by our
      three main product areas, Broadband Access, Internetworking and Optical
      Access. Our Broadband Access category grew a stellar 93% over the third
      quarter of 2010. Our Internetworking category also showed a strong
      performance by growing 44%, and our Optical Access category grew 20%.
      These results allowed the company to achieve its sixth consecutive
      all-time record revenue quarter. With nearly 80% of our revenues coming
      from these high growth areas, we feel the Company is well positioned for
      the future.”

[0001157523-11-005682:8k_2_02:6]
The Company reported that stock-based compensation expense for the third
      quarter of 2011 reduced diluted earnings per share by $0.03 compared to
      a reduction of $0.03 for the third quarter of 2010.

[0001157523-11-005682:8k_2_02:7]
The Company announced that its Board of Directors has authorized the
      repurchase of an additional 5,000,000 shares of the Company’s common
      stock to commence upon completion of the repurchase plan announced April
      14, 2008. There are 869,425 shares remaining to be repurchased under the
      April 2008 plan. Upon completion of the current plan, the new plan will
      be implemented through open market or private purchases from time to
      time as conditions warrant.

[0001157523-11-005682:8k_2_02:8]
The Company also announced that its Board of Directors declared a cash
      dividend for the third quarter of 2011. The quarterly cash dividend is
      $0.09 per common share to be paid to holders of record at the close of
      business on October 27, 2011. The ex-dividend date is October 25, 2011
      and the payment date is November 10, 2011.

[0001157523-11-005682:8k_2_02:9]
The Company confirmed that its third quarter conference call will be
      held Wednesday, October 12, 2011 at 9:30 a.m. Central Time. This
      conference call will be web cast live through StreetEvents.com. To
      listen, simply visit the Investor Relations site at http://www.adtran.com
      or http://streetevents.com approximately 10 minutes prior to the
      start of the call and click on the conference call link provided.

[0001157523-11-005682:8k_2_02:10]
An online replay of the conference call will be available for seven days
      at http://streetevents.com. In addition, an online replay of the
      conference call, as well as the text of the Company's earnings release,
      will be available on the Investor Relations site at http://www.adtran.com
      for at least 12 months following the call.

[0001157523-11-005682:8k_2_02:11]
ADTRAN, Inc. is a leading global provider of networking and
      communications equipment, with a portfolio of more than 1,700 solutions.
      ADTRAN’s products enable voice, data, video, and Internet communications
      across a variety of network infrastructures. ADTRAN solutions are
      currently in use by service providers, private enterprises, government
      organizations, and millions of individual users worldwide.

[0001157523-11-005682:8k_2_02:12]
For more information, contact the company at 800 9ADTRAN (800 923-8726)
      or via email at info@adtran.com. On the Web, visit www.adtran.com.

[0001157523-11-005682:8k_2_02:13]
This press release contains forward-looking statements which reflect
      management’s best judgment based on factors currently known. However,
      these statements involve risks and uncertainties, including the
      successful development and market acceptance of new products, the degree
      of competition in the market for such products, the product and channel
      mix, component costs, manufacturing efficiencies, and other risks
      detailed in our annual report on Form 10-K for the year ended December
      31, 2010 and our quarterly report on Form 10Q for the quarter ended June
      30, 2011. These risks and uncertainties could cause actual results to
      differ materially from those in the forward-looking statements included
      in this press release.

[0001157523-11-005682:8k_2_02:14]
| Condensed Consolidated Balance Sheet |
| Unaudited |
| (In thousands) |
|  |  |  | September 30, 2011 |  | December 31, 2010 |
| Assets |  |  |  |  |  |
| Cash and cash equivalents |  |  | $ | 32,526 |  | $ | 31,677 |
| Short-term investments |  |  |  | 121,389 |  |  | 157,479 |
| Accounts receivable, net |  |  |  | 89,631 |  |  | 70,893 |
| Other receivables |  |  |  | 12,487 |  |  | 3,962 |
| Income tax receivable, net |  |  |  | - |  |  | 2,741 |
| Inventory |  |  |  | 87,313 |  |  | 74,274 |
| Prepaid expenses |  |  |  | 3,337 |  |  | 3,270 |
| Deferred tax assets, net |  |  |  | 12,247 |  |  | 10,617 |
| Total Current Assets |  |  |  | 358,930 |  |  | 354,913 |
| Property, plant and equipment, net |  |  |  | 75,698 |  |  | 73,986 |
| Deferred tax assets, net |  |  |  | 5,918 |  |  | - |
| Goodwill |  |  |  | 4,445 |  |  | - |
| Other assets |  |  |  | 8,201 |  |  | 1,915 |
| Long-term investments |  |  |  | 348,103 |  |  | 261,160 |
| Total Assets |  |  | $ | 801,295 |  | $ | 691,974 |
| Liabilities and Stockholders' Equity |  |  |  |  |  |
| Accounts payable |  |  | $ | 33,150 |  | $ | 22,785 |
| Unearned revenue |  |  |  | 18,708 |  |  | 10,138 |
| Accrued expenses |  |  |  | 6,703 |  |  | 4,913 |
| Accrued wages and benefits |  |  |  | 14,753 |  |  | 12,125 |
| Income tax payable, net |  |  |  | 1,916 |  |  | - |
| Total Current Liabilities |  |  |  | 75,230 |  |  | 49,961 |
| Deferred tax liabilities, net |  |  |  | - |  |  | 10,350 |
| Other non-current liabilities |  |  |  | 14,853 |  |  | 11,841 |
| Bonds payable |  |  |  | 46,500 |  |  | 47,500 |
| Total Liabilities |  |  |  | 136,583 |  |  | 119,652 |
| Stockholders' Equity |  |  |  | 664,712 |  |  | 572,322 |
| Total Liabilities and Stockholders' Equity |  |  | $ | 801,295 |  | $ | 691,974 |

[0001157523-11-005682:8k_2_02:15]
| Consolidated Statements of Income |
| Unaudited |
| (In thousands, except per share data) |
|  |  |  |  | Three Months Ended |  | Nine Months Ended |
|  |  |  |  | September 30, |  | September 30, |
|  |  |  |  | 2011 |  | 2010 |  | 2011 |  | 2010 |
| Sales |  |  | $ | 192,194 |  |  | $ | 162,957 |  |  | $ | 541,943 |  |  | $ | 440,345 |  |
| Cost of sales |  |  |  | 82,718 |  |  |  | 65,658 |  |  |  | 226,845 |  |  |  | 178,389 |  |
| Gross Profit |  |  |  | 109,476 |  |  |  | 97,299 |  |  |  | 315,098 |  |  |  | 261,956 |  |
| Selling, general and administrative expenses |  |  |  | 31,475 |  |  |  | 29,452 |  |  |  | 91,925 |  |  |  | 85,111 |  |
| Research and development expenses |  |  |  | 26,894 |  |  |  | 22,802 |  |  |  | 75,150 |  |  |  | 67,838 |  |
| Operating Income |  |  |  | 51,107 |  |  |  | 45,045 |  |  |  | 148,023 |  |  |  | 109,007 |  |
| Interest and dividend income |  |  |  | 2,037 |  |  |  | 1,622 |  |  |  | 5,829 |  |  |  | 4,803 |  |
| Interest expense |  |  |  | (599 | ) |  |  | (630 | ) |  |  | (1,795 | ) |  |  | (1,828 | ) |
| Net realized investment gain |  |  |  | 2,982 |  |  |  | 3,399 |  |  |  | 9,121 |  |  |  | 8,055 |  |
| Other expense, net |  |  |  | (155 | ) |  |  | (266 | ) |  |  | (397 | ) |  |  | (641 | ) |
| Income before provision for income taxes |  |  |  | 55,372 |  |  |  | 49,170 |  |  |  | 160,781 |  |  |  | 119,396 |  |
| Provision for income taxes |  |  |  | (19,159 | ) |  |  | (17,086 | ) |  |  | (53,367 | ) |  |  | (41,367 | ) |
| Net Income |  |  | $ | 36,213 |  |  | $ | 32,084 |  |  | $ | 107,414 |  |  | $ | 78,029 |  |
| Weighted average shares outstanding - basic |  |  |  | 64,023 |  |  |  | 62,771 |  |  |  | 64,300 |  |  |  | 62,316 |  |
| Weighted average shares outstanding - diluted(1) |  |  |  | 64,961 |  |  |  | 64,300 |  |  |  | 65,697 |  |  |  | 63,638 |  |
| Earnings per common share - basic |  |  | $ | 0.57 |  |  | $ | 0.51 |  |  | $ | 1.67 |  |  | $ | 1.25 |  |
| Earnings per common share - diluted(1) |  |  | $ | 0.56 |  |  | $ | 0.50 |  |  | $ | 1.63 |  |  | $ | 1.23 |  |
| (1) Assumes exercise of dilutive stock options calculated under the treasury stock method. |  |  |  |

[0001157523-11-005682:8k_2_02:16]
| Supplemental Information |
| Acquisition Related Expenses |
| Unaudited |
| (In thousands) |
| On August 4, 2011, we closed on the acquisition of Bluesocket, Inc., a provider of virtual wireless network solutions. For the three months ended September 30, 2011, acquisition related expenses were as follows: |
| Acquisition related professional fees and travel expenses | $ | 630 |
| Amortization of acquired intangible assets |  | 198 |
| Other non-cash items |  | 217 |
| Total | $ | 1,045 |

[0001157523-11-005682:8k_2_02:17]
| Supplemental Information |
| Stock-based Compensation Expense |
| Unaudited |
| (In thousands) |
|  |  |  | Three Months Ended |  | Nine Months Ended |
|  |  |  | September 30, |  | September 30, |
|  |  |  | 2011 |  | 2010 |  | 2011 |  | 2010 |
| Stock-based compensation expense included in cost of sales |  |  | $ | 100 |  |  | $ | 69 |  |  | $ | 280 |  |  | $ | 210 |  |
| Selling, general and administrative expense |  |  |  | 1,090 |  |  |  | 775 |  |  |  | 3,096 |  |  |  | 2,360 |  |
| Research and development expense |  |  |  | 1,100 |  |  |  | 886 |  |  |  | 3,079 |  |  |  | 2,657 |  |
| Stock-based compensation expense included in operating expenses |  |  |  | 2,190 |  |  |  | 1,661 |  |  |  | 6,175 |  |  |  | 5,017 |  |
| Total stock-based compensation expense |  |  |  | 2,290 |  |  |  | 1,730 |  |  |  | 6,455 |  |  |  | 5,227 |  |
| Tax benefit for expense associated with non-qualified options |  |  |  | (302 | ) |  |  | (43 | ) |  |  | (1,018 | ) |  |  | (415 | ) |
| Total stock-based compensation expense, net of tax |  |  | $ | 1,988 |  |  | $ | 1,687 |  |  | $ | 5,437 |  |  | $ | 4,812 |  |

[0001157523-11-005682:8k_2_02:18]
| Consolidated Statements of Cash Flows |
| Unaudited |
| (In thousands) |
|  |  |  | Nine Months Ended |
|  |  |  | September 30, |
|  |  |  | 2011 |  | 2010 |
| Cash flows from operating activities: |  |  |  |  |  |
| Net income |  |  | $ | 107,414 |  |  | $ | 78,029 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |
| Depreciation and amortization |  |  |  | 8,435 |  |  |  | 7,842 |  |
| Amortization of net premium on available-for-sale investments |  |  |  | 4,697 |  |  |  | 3,267 |  |
| Net realized gain on long-term investments |  |  |  | (9,121 | ) |  |  | (8,055 | ) |
| Net loss on disposal of property, plant and equipment |  |  |  | 14 |  |  |  | 9 |  |
| Stock-based compensation expense |  |  |  | 6,455 |  |  |  | 5,227 |  |
| Deferred income taxes |  |  |  | 128 |  |  |  | (1,624 | ) |
| Tax benefit from stock option exercises |  |  |  | 10,457 |  |  |  | 4,459 |  |
| Excess tax benefits from stock-based compensation arrangements |  |  |  | (9,311 | ) |  |  | (3,986 | ) |
| Change in operating assets and liabilities: |  |  |  |  |  |
| Accounts receivable, net |  |  |  | (18,440 | ) |  |  | (1,351 | ) |
| Other receivables |  |  |  | (8,525 | ) |  |  | (3,256 | ) |
| Income tax receivable, net |  |  |  | 2,741 |  |  |  | - |  |
| Inventory |  |  |  | (12,247 | ) |  |  | (24,278 | ) |
| Prepaid expenses and other assets |  |  |  | 207 |  |  |  | (829 | ) |
| Accounts payable |  |  |  | 8,924 |  |  |  | 1,188 |  |
| Accrued expenses and other liabilities |  |  |  | 15,047 |  |  |  | 7,525 |  |
| Income tax payable, net |  |  |  | 1,916 |  |  |  | (1,121 | ) |
| Net cash provided by operating activities |  |  |  | 108,791 |  |  |  | 63,046 |  |
| Cash flows from investing activities: |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  |  | (9,531 | ) |  |  | (7,375 | ) |
| Proceeds from sales and maturities of available-for-sale investments |  |  |  | 378,288 |  |  |  | 221,173 |  |
| Purchases of available-for-sale investments |  |  |  | (443,275 | ) |  |  | (272,383 | ) |
| Acquisition of business, net of cash acquired |  |  |  | (22,762 | ) |  |  | - |  |
| Net cash used in investing activities |  |  |  | (97,280 | ) |  |  | (58,585 | ) |
| Cash flows from financing activities: |  |  |  |  |  |
| Proceeds from stock option exercises |  |  |  | 33,631 |  |  |  | 19,769 |  |
| Purchases of treasury stock |  |  |  | (35,178 | ) |  |  | (10,330 | ) |
| Dividend payments |  |  |  | (17,395 | ) |  |  | (16,822 | ) |
| Excess tax benefits from stock-based compensation arrangements |  |  |  | 9,311 |  |  |  | 3,986 |  |
| Net cash used in financing activities |  |  |  | (9,631 | ) |  |  | (3,397 | ) |
| Net increase in cash and cash equivalents |  |  |  | 1,880 |  |  |  | 1,064 |  |
| Effect of exchange rate changes |  |  |  | (1,031 | ) |  |  | 863 |  |
| Cash and cash equivalents, beginning of period |  |  |  | 31,677 |  |  |  | 24,135 |  |
| Cash and cash equivalents, end of period |  |  | $ | 32,526 |  |  | $ | 26,062 |  |

[0001157523-11-005682:8k_2_02:19]
CONTACT:
ADTRAN, Inc.
Jim Matthews, Senior Vice President/CFO,
      256-963-8775
or
Investor Services/Assistance:
Gayle Ellis,
      256-963-8220
