# ADTN 10-Q controls and the auditor's report


## item_4_controls

[0000950123-11-094914:item_4_controls:1]
| ITEM 4. |  | CONTROLS AND PROCEDURES |

[0000950123-11-094914:item_4_controls:2]
(a) Evaluation of disclosure controls and procedures. Our Chief Executive Officer and Chief
Financial Officer are responsible for establishing and maintaining “disclosure controls and
procedures” (as defined in the Securities Exchange Act of 1934 Rules 13a-15(e) and 15d-15(e)) for
ADTRAN. Our Chief Executive Officer and Chief Financial Officer, after evaluating the
effectiveness of our disclosure controls and procedures as of the end of the period covered by this
quarterly report, have concluded that our disclosure controls and procedures are effective.

[0000950123-11-094914:item_4_controls:3]
(b) Changes in internal control over financial reporting. There were no changes in our internal
control over financial reporting that occurred during our most recent fiscal quarter that have
materially affected, or are reasonably likely to materially affect, our internal control over
financial reporting.

[0000950123-11-094914:item_4_controls:4]
31
