# ADTN MD&A — 0000950123-11-094914


## mdna

[0000950123-11-094914:mdna:1]
[same as prior period, unchanged from 0000950123-11-071519:mdna:1]

[0000950123-11-094914:mdna:2]
[same as prior period, unchanged from 0000950123-11-071519:mdna:2]

[0000950123-11-094914:mdna:3]
[same as prior period, unchanged from 0000950123-11-071519:mdna:3]

[0000950123-11-094914:mdna:4]
[same as prior period, unchanged from 0000950123-11-071519:mdna:4]

[0000950123-11-094914:mdna:5]
[same as prior period, unchanged from 0000950123-11-071519:mdna:5]

[0000950123-11-094914:mdna:6]
[same as prior period, unchanged from 0000950123-11-071519:mdna:6]

[0000950123-11-094914:mdna:7]
[same as prior period, unchanged from 0000950123-11-071519:mdna:7]

[0000950123-11-094914:mdna:8]
See Note 10 of Notes to Consolidated Financial Statements in this report for further information
regarding these product categories.

[0000950123-11-094914:mdna:9]
Sales were $192.2 million and $541.9 million for the three and nine months ended September 30, 2011
compared to $163.0 million and $440.3 million for the three and nine months ended September 30,
2010. Product revenues for our three primary growth areas, Broadband Access, Optical Access and
Internetworking, were $151.8 million and $389.4 million for the three and nine months ended
September 30, 2011 compared to $93.2 million and $252.0 million for the three and nine months ended
September 30, 2010. Our gross margin decreased to 57.0% and 58.1% for the three and nine months
ended September 30, 2011 from 59.7% and 59.5% for the three and nine months ended September 30,
2010. Our operating income margin decreased to 26.6% for the three months ended September 30, 2011
from 27.6% for the three months ended September 30, 2010, and increased to 27.3% for the nine
months ended September 30, 2011 from 24.8% for the nine months ended September 30, 2010. Net
income was $36.2 million and $107.4 million for the three and nine months ended September 30, 2011
compared to $32.1 million and $78.0 million for the three and nine months ended September 30, 2010.
Our effective tax rate decreased to 34.6% for the three months ended September 30, 2011
from 34.7% for the three months ended September 30, 2010 and decreased to 33.2% for the nine months
ended September 30, 2011 from 34.6% for the nine months ended September 30, 2010. Earnings per
share, assuming dilution, were $0.56 and $1.63 for the three and nine months ended September 30,
2011 compared to $0.50 and $1.23 for the three and nine months ended September 30, 2010.

[0000950123-11-094914:mdna:10]
[same as prior period, unchanged from 0000950123-11-071519:mdna:10]

[0000950123-11-094914:mdna:11]
[same as prior period, unchanged from 0000950123-11-071519:mdna:11]

[0000950123-11-094914:mdna:12]
[same as prior period, unchanged from 0000950123-11-071519:mdna:12]

[0000950123-11-094914:mdna:13]
[same as prior period, unchanged from 0000950123-11-071519:mdna:13]

[0000950123-11-094914:mdna:14]
[same as prior period, unchanged from 0000950123-11-071519:mdna:14]

[0000950123-11-094914:mdna:15]
[same as prior period, unchanged from 0000950123-11-071519:mdna:15]

[0000950123-11-094914:mdna:16]
[same as prior period, unchanged from 0000950123-11-071519:mdna:16]

[0000950123-11-094914:mdna:17]
RESULTS OF OPERATIONS — THREE AND NINE MONTHS ENDED SEPTEMBER 30, 2011 COMPARED TO THREE AND NINE
MONTHS ENDED SEPTEMBER 30, 2010

[0000950123-11-094914:mdna:18]
[same as prior period, unchanged from 0000950123-11-071519:mdna:18]

[0000950123-11-094914:mdna:19]
ADTRAN’s sales increased 17.9% from $163.0 million in the three months ended September 30, 2010 to
$192.2 million in the three months ended September 30, 2011, and increased 23.1% from $440.3
million in the nine months ended September 30, 2010 to $541.9 million in the nine months ended
September 30, 2011. The increase in sales for the three months ended September 30, 2011 is
primarily attributable to a $41.9 million increase in sales of our Broadband Access products, a
$13.0 million increase in sales of our Internetworking products, and a $3.7 million increase in
sales of our Optical Access products, partially offset by a $29.3 million decrease in sales of our
HDSL and other traditional products. The increase in sales for the nine months ended September 30,
2011 is primarily attributable to an $89.4 million increase in sales of our Broadband Access
products, a $28.9 million increase in sales of our Internetworking products, and a $19.2 million
increase in sales of our Optical Access products, partially offset by a $35.8 million decrease in
sales of our HDSL and other traditional products.

[0000950123-11-094914:mdna:20]
Carrier Networks sales increased 18.6% from $128.6 million in the three months ended September 30,
2010 to $152.5 million in the three months ended September 30, 2011, and increased 25.9% from
$345.7 million in the nine months ended September 30, 2010 to $435.3 in the nine months ended
September 30, 2011. The increase in sales for the three and nine months ended September 30, 2011
is primarily attributable to increases in Broadband Access, Optical Access and Internetworking NTE
product sales, partially offset by a decrease in HDSL and other traditional product sales.

[0000950123-11-094914:mdna:21]
Enterprise Networks sales increased 15.5% from $34.4 million in the three months ended September
30, 2010 to $39.7 million in the three months ended September 30, 2011, and increased 12.6% from
$94.7 million in the nine months ended September 30, 2010 to $106.6 million in the nine months
ended September 30, 2011. The increase for the three and nine months ended September 30, 2011 is
primarily attributable to an increase in sales of Internetworking products, partially offset by a
decrease in sales of traditional products. Internetworking product sales attributable to
Enterprise Networks were 88.6% and 86.6% of the division’s sales in the three and nine months ended
September 30, 2011, compared to 77.4% and 75.7% in the three and nine months ended September 30,
2010. Traditional products primarily comprise the remainder of Enterprise Networks sales.
Enterprise Networks sales as a percentage of total sales decreased from 21.1% for the three months
ended September 30, 2010 to 20.7% for the three months ended September 30, 2011 and decreased from
21.5% for the nine months ended September 30, 2010 to 19.7% for the nine months ended September 30,
2011.

[0000950123-11-094914:mdna:22]
International sales, which are included in the Carrier Networks and Enterprise Networks amounts
discussed above, increased 163.0% from $8.3 million in the three months ended September 30, 2010 to
$21.9 million in the three months ended September 30, 2011, and increased 147.0% from $23.4 million
in the nine months ended September 30, 2010 to $57.7 million in the nine months ended September 30,
2011. International sales, as a percentage of total sales, increased from 5.1% for the three
months ended September 30, 2010 to 11.4% for the three months ended September 30, 2011, and
increased from 5.3% for the nine months ended September 30, 2010 to 10.6% for the nine months ended
September 30, 2011. International sales increased in the three and nine months ended September 30,
2011 compared to the three and nine months ended September 30, 2010 primarily due to an increase in
sales to Latin America, Asia/Pacific and Europe.

[0000950123-11-094914:mdna:23]
Carrier System product sales increased $43.6 million and $111.4 million in the three and nine
months ended September 30, 2011 compared to the three and nine months ended September 30, 2010.
The increase for the three months ended September 30, 2011 is primarily due to a $41.9 million
increase in Broadband Access product sales and a $3.7 million increase in Optical Access product
sales. The increase for the nine months ended September 30, 2011 is primarily due to an $89.4
million increase in Broadband Access product sales and a $19.2 million increase in Optical Access
product sales. The increase in Broadband Access product sales is primarily attributable to
continued growth in deployments of our Total Access 5000 and Fiber-to-the-Node platforms.

[0000950123-11-094914:mdna:24]
Business Networking product sales increased $11.1 million and $24.5 million in the three and nine
months ended September 30, 2011 compared to the three and nine months ended September 30, 2010.
The increase for the three months ended September 30, 2011 is primarily due to a $13.0 million
increase in Internetworking product sales across both divisions, partially offset by a $2.0 million
decrease in other traditional product sales. The increase for the nine months ended September 30,
2011 is primarily due to a $28.9 million increase in Internetworking product sales across both
divisions, partially offset by a $4.7 million decrease in other traditional product sales. The
decrease in sales of traditional products is a result of customers shifting to newer technologies.
Many of these newer technologies are integral to our Internetworking product area.

[0000950123-11-094914:mdna:25]
Loop Access product sales decreased $25.5 million and $34.4 million in the three and nine months
ended September 30, 2011 compared to the three and nine months ended September 30, 2010. The
decrease for the three months ended September 30, 2011 is primarily due to a $24.1 million decrease
in HDSL product sales. The decrease for the nine months ended September 30, 2011 is primarily due
to a $31.2 million decrease in HDSL product sales.

[0000950123-11-094914:mdna:26]
[same as prior period, unchanged from 0000950123-11-071519:mdna:26]

[0000950123-11-094914:mdna:27]
As a percentage of sales, cost of sales increased from 40.3% in the three months ended September
30, 2010 to 43.0% in the three months ended September 30, 2011 and increased from 40.5% in the nine
months ended September 30, 2010 to 41.9% in the nine months ended September 30, 2011. This
increase is primarily the result of higher services related revenue, expediting costs related to
specific customer opportunities, and specific customer pricing related to market share expansion.
These effects were partially offset by cost absorption and manufacturing efficiencies achieved at
the higher production volumes.

[0000950123-11-094914:mdna:28]
Carrier Networks cost of sales, as a percent of division sales, increased from 39.8% in the three
months ended September 30, 2010 to 43.6% in the three months ended September 30, 2011 and increased
from 40.1% in the nine months ended September 30, 2010 to 41.9% in the nine months ended September
30, 2011. The increase in Carrier Networks cost of sales as a percentage of sales is primarily
attributable to higher services related revenues, expediting costs related to specific customer
opportunities and specific customer pricing related to market share expansion, partially offset by
manufacturing efficiencies achieved at the higher production volumes.

[0000950123-11-094914:mdna:29]
Enterprise Networks cost of sales, as a percent of division sales, decreased from 42.0% in the
three months ended September 30, 2010 to 40.7% in the three months ended September 30, 2011 and
decreased from 41.8% in the nine months ended September 30, 2010 to 41.7% in the nine months ended
September 30, 2011. The decrease in Enterprise Networks cost of sales as a percentage of sales is
primarily attributable to cost absorption and manufacturing efficiencies achieved at the higher
production volumes.

[0000950123-11-094914:mdna:30]
[same as prior period, unchanged from 0000950123-11-071519:mdna:30]

[0000950123-11-094914:mdna:31]
[same as prior period, unchanged from 0000950123-11-071519:mdna:31]

[0000950123-11-094914:mdna:32]
Selling, general and administrative expenses increased 6.9% from $29.5 million in the three months
ended September 30, 2010 to $31.5 million in the three months ended September 30, 2011 and
increased 8.0% from $85.1 million in the nine months ended September 30, 2010 to $91.9 million in
the nine months ended September 30, 2011. The increase in selling, general and administrative
expenses for the three month period ended September 30, 2011 is primarily related to increased
staffing and fringe benefit costs due to increased headcount, including Bluesocket, acquired on
August 4, 2011, selling expenses related to Bluesocket, and increases in professional fees and
travel related to the Bluesocket acquisition. The increase in selling, general and administrative
expenses for the nine month period ended September 30, 2011 is primarily related to increased
staffing and fringe benefit costs due to increased headcount, including Bluesocket, selling
expenses related to Bluesocket, and increases in contract services, recruiting expenses, and travel
expenses.

[0000950123-11-094914:mdna:33]
Selling, general and administrative expenses as a percentage of sales decreased from 18.1% in the
three months ended September 30, 2010 to 16.4% in the three months ended September 30, 2011 and
decreased from 19.3% in the nine months ended September 30, 2010 to 17.0% in the nine months ended
September 30, 2011. Selling, general and administrative expenses as a percentage of sales
decreased due to increased revenue, partially offset by increased selling expenses related to
Bluesocket.

[0000950123-11-094914:mdna:34]
[same as prior period, unchanged from 0000950123-11-071519:mdna:34]

[0000950123-11-094914:mdna:35]
Research and development expenses increased 17.9% from $22.8 million in the three months ended
September 30, 2010 to $26.9 million in the three months ended September 30, 2011 and increased
10.8% from $67.8 million in the nine months ended September 30, 2010 to $75.2 million in the nine
months ended September 30, 2011. The increase in research and development expenses for the three
months ended September 30, 2011 reflects increased staffing and fringe benefit costs due to
increased headcount, including Bluesocket, increased customer specific testing expense, research
and development expenses related to Bluesocket, and amortization of intangibles related to the
Bluesocket acquisition. The increase in research and development expenses for the nine months
ended September 30, 2011 reflects increased staffing and fringe benefit costs due to increased
headcount, including Bluesocket, increased customer specific testing expense, research and
development expenses related to Bluesocket, and amortization of intangibles related to the
Bluesocket acquisition.

[0000950123-11-094914:mdna:36]
Research and development expenses as a percentage of sales remained consistent at 14.0% in the
three months ended September 30, 2010 and 2011, and decreased from 15.4% in the nine months ended
September 30, 2010 to 13.9% in the nine months ended September 30, 2011. Research and development
expenses as a percentage of sales decreased due to increased revenue, partially offset by increased
research and development expenses related to Bluesocket.

[0000950123-11-094914:mdna:37]
We expect to continue to incur research and development expenses in connection with our new and
existing products and our expansion into international markets. We continually evaluate new
product opportunities and engage in intensive research and product development efforts which
provide for new product development, enhancement of existing products
and product cost reductions. We may incur significant research and development expenses prior to
the receipt of revenues from a major new product group.

[0000950123-11-094914:mdna:38]
[same as prior period, unchanged from 0000950123-11-071519:mdna:37]

[0000950123-11-094914:mdna:39]
Interest and dividend income increased 25.6% from $1.6 million in the three months ended September
30, 2010 to $2.0 million in the three months ended September 30, 2011 and increased 21.4% from $4.8
million in the nine months ended September 30, 2010 to $5.8 million in the nine months ended
September 30, 2011. The increase for the three months ended September 30, 2011 is primarily driven
by a 14.1% increase in our average investment balances, partially offset by a 26.0% reduction in
the average rate of return on our investments as a result of lower interest rates. The increase
for the nine months ended September 30, 2011 is primarily driven by a 20.0% increase in our average
investment balances, partially offset by a 22.0% reduction in the average rate of return on our
investments as a result of lower interest rates.

[0000950123-11-094914:mdna:40]
[same as prior period, unchanged from 0000950123-11-071519:mdna:39]

[0000950123-11-094914:mdna:41]
Interest expense, which is primarily related to our taxable revenue bond, remained constant at $0.6
million in each of the three months ended September 30, 2011 and 2010 and $1.8 million in each of
the nine months ended September 30, 2011 and 2010, respectively. See “Liquidity and Capital
Resources” below for additional information on our revenue bond.

[0000950123-11-094914:mdna:42]
[same as prior period, unchanged from 0000950123-11-071519:mdna:41]

[0000950123-11-094914:mdna:43]
Net realized investment gain decreased 12.3% from $3.4 million in the three months ended September
30, 2010 to $3.0 million in the three months ended September 30, 2011 and increased 13.2% from $8.1
million in the nine months ended September 30, 2010 to $9.1 million in the nine months ended
September 30, 2011. The decrease for the three months ended September 30, 2011 is the result of
realized gains from the realignment of our fixed income portfolio during 2010. The increase for
the nine months ended September 30, 2011 is the result of realized gains from the sale of
previously impaired holdings and increased distributions from two private equity funds. See
“Investing Activities” in “Liquidity and Capital Resources” below for additional information.

[0000950123-11-094914:mdna:44]
[same as prior period, unchanged from 0000950123-11-071519:mdna:43]

[0000950123-11-094914:mdna:45]
Other expense, net, comprised primarily of miscellaneous income, gains and losses on foreign
currency transactions, investment account management fees, scrap raw material sales, and gains and
losses on the disposal of property, plant and equipment occurring in the normal course of business,
decreased from $0.3 million in the three months ended September 30, 2010 to $0.2 million in the
three months ended September 30, 2011 and decreased from $0.7 million in the nine months ended
September 30, 2010 to $0.4 million in the nine months ended September 30, 2011.

[0000950123-11-094914:mdna:46]
[same as prior period, unchanged from 0000950123-11-071519:mdna:45]

[0000950123-11-094914:mdna:47]
Our effective tax rate for the nine months ended September 30, 2011 was 33.2%. The difference
between our effective tax rate and the federal statutory rate for the nine months ended September
30, 2011 is primarily attributable to a benefit for the research tax credit of 2.2 percentage
points and a benefit for the manufacturer’s domestic production activities deduction of 2.0
percentage points, partially offset by state income tax provisions of 2.3 percentage points.

[0000950123-11-094914:mdna:48]
Our effective tax rate for the nine months ended September 30, 2010 was 34.6%. The difference
between our effective tax rate and the federal statutory rate for the nine months ended September
30, 2010 is primarily attributable to a benefit for the manufacturer’s domestic production
activities deduction of 2.5 percentage points, partially offset by state income tax provisions of
2.4 percentage points. The tax provision for the nine months ended September 30, 2010 did not
include the benefit of the research tax credit, which expired on December 31, 2009. The credit was
reinstated during the fourth quarter of 2010.

[0000950123-11-094914:mdna:49]
[same as prior period, unchanged from 0000950123-11-071519:mdna:48]

[0000950123-11-094914:mdna:50]
As a result of the above factors, net income increased $4.1 million from $32.1 million in the three
months ended September 30, 2010 to $36.2 million in the three months ended September 30, 2011 and
increased $29.4 million from $78.0 million in the nine months ended September 30, 2010 to $107.4
million in the nine months ended September 30, 2011.

[0000950123-11-094914:mdna:51]
As a percentage of sales, net income decreased from 19.7% in the three months ended September 30,
2010 to 18.8% in the three months ended September 30, 2011 and increased from 17.7% in the nine
months ended September 30, 2010 to 19.8% in the nine months ended September 30, 2011.

[0000950123-11-094914:mdna:52]
[same as prior period, unchanged from 0000950123-11-071519:mdna:51]

[0000950123-11-094914:mdna:53]
[same as prior period, unchanged from 0000950123-11-071519:mdna:52]

[0000950123-11-094914:mdna:54]
[same as prior period, unchanged from 0000950123-11-071519:mdna:53]

[0000950123-11-094914:mdna:55]
At September 30, 2011, cash on hand was $32.5 million and short-term investments were $121.4
million, which resulted in available short-term liquidity of $153.9 million. At December 31, 2010,
our cash on hand of $31.7 million and short-term investments of $157.5 million resulted in
available short-term liquidity of $189.2 million. The decrease in short-term liquidity from
December 31, 2010 to September 30, 2011 primarily reflects a realignment of our fixed income
portfolio from short-term to long-term, which increased long-term investments $86.9 million during
the nine months ended September 30, 2011.

[0000950123-11-094914:mdna:56]
[same as prior period, unchanged from 0000950123-11-071519:mdna:55]

[0000950123-11-094914:mdna:57]
Our working capital, which consists of current assets less current liabilities, decreased 7.0% from
$305.0 million as of December 31, 2010 to $283.7 million as of September 30, 2011. The quick
ratio, defined as cash, cash equivalents, short-term investments, and net accounts receivable,
divided by current liabilities, decreased from 5.21 as of December 31, 2010 to 3.24 as of September
30, 2011. The current ratio, defined as current assets divided by current liabilities, decreased
from 7.10 as of December 31, 2010 to 4.77 as of September 30, 2011. Our working capital, the quick
ratio, and the current ratio decreased due to a decrease in short-term investments of $36.1
million, which was a result of the realignment of our fixed income portfolio from short-term to
long-term, and an increase in accounts payable $10.4 million and an increase in unearned revenue of
$8.6 million. Generally, the change in accounts payable is due to variations in the timing of the
receipt of supplies, inventory and services and our subsequent payments for these purchases.
Generally, fluctuations in unearned revenue result from variations in the timing of customer
payments and our revenue recognition under contract terms for hardware acceptance, installation
services and post-sale support and maintenance services.

[0000950123-11-094914:mdna:58]
Net accounts receivable increased 26.4% from $70.9 million at December 31, 2010 to $89.6 million at
September 30, 2011. Our allowance for doubtful accounts was $0.2 million at December 31, 2010 and
$4 thousand at September 30, 2011. Quarterly accounts receivable days sales outstanding (DSO)
increased from 39 days as of December 31, 2010 to 43 days as of September 30, 2011. Net accounts
receivable and DSO increased for the quarter ended September 30, 2011 due to the timing of sales
and collections during the quarter. Other receivables increased from $4.0 million at December 31,
2010 to $12.5 million at September 30, 2011. Generally, the change in other receivables is due to
the timing of shipments and payments received for materials supplied to our contract manufacturers.

[0000950123-11-094914:mdna:59]
Quarterly inventory turnover remained consistent at 3.8 turns as of December 31, 2010 and September
30, 2011. Inventory increased 17.6% from December 31, 2010 to September 30, 2011. Our investment
in inventory increased during the nine months ended September 30, 2011 to support increasing
customer demand, increases in inventories related to an increase in installation services
activities, and to mitigate component supply constraints broadly affecting the industry. We expect
inventory levels to fluctuate as we attempt to maintain sufficient inventory in response to
seasonal cycles of our business; ensuring competitive lead times while managing the risk of
inventory obsolescence that may occur due to rapidly changing technology and customer demand.

[0000950123-11-094914:mdna:60]
Accounts payable increased 45.5% from $22.8 million at December 31, 2010 to $33.2 million at
September 30, 2011. Generally, the change in accounts payable is due to variations in the timing
of the receipt of supplies, inventory and services and our subsequent payments for these purchases.

[0000950123-11-094914:mdna:61]
[same as prior period, unchanged from 0000950123-11-071519:mdna:60]

[0000950123-11-094914:mdna:62]
Capital expenditures totaled approximately $7.4 million and $9.5 million for the nine months ended
September 30, 2010 and 2011, respectively. These expenditures were primarily used to purchase
manufacturing and test equipment and computer software and hardware.

[0000950123-11-094914:mdna:63]
On August 4, 2011, we acquired all of the outstanding stock of Bluesocket, Inc., a provider of
wireless network solutions with virtual control, for $23.8 million in cash.

[0000950123-11-094914:mdna:64]
Our combined short-term and long-term investments increased $50.9 million from $418.6 million at
December 31, 2010 to $469.5 million at September 30, 2011. This increase reflects the impact of
additional funds available for investment provided by our operating activities and proceeds from
stock option exercises by our employees, reduced by our cash needs for equipment acquisitions,
business acquisition, stock repurchases and dividends, as well as net realized and unrealized
losses and amortization of net premiums on our combined investments.

[0000950123-11-094914:mdna:65]
We invest all available cash not required for immediate use in operations primarily in securities
that we believe bear minimal risk of loss. At September 30, 2011 these investments included
municipal variable rate demand notes of $60.7 million, municipal fixed-rate bonds of $140.9 million
and corporate bonds of $176.7 million. At December 31, 2010, these investments included municipal
variable rate demand notes of $116.7 million, municipal fixed-rate bonds of $71.5 million and
corporate bonds of $127.1 million.

[0000950123-11-094914:mdna:66]
At September 30, 2011, we held $60.7 million of municipal variable rate demand notes, all of which
were classified as available-for-sale. At September 30, 2011, 14% of our municipal variable rate
demand notes had a credit rating of AAA, 72% had a credit rating of AA, 14% had a credit rating of
A, and all contained put options of seven days. Despite the long-term nature of their stated
contractual maturities, we routinely buy and sell these securities and we believe that we have the
ability to quickly liquidate them. Our investments in these securities are recorded at fair value,
and the interest rates reset every seven days. We believe we have the ability to sell our variable
rate demand notes to the remarketing agent, tender agent or issuer at par value plus accrued
interest in the event we decide to liquidate our investment in a particular variable rate demand
note. At September 30, 2011, approximately 40% of our variable rate demand notes were supported by
letters of credit from banks that we believe to be in good financial condition. The remaining 60%
of our variable rate demand notes were supported by standby purchase agreements. As a result of
these factors, we had no cumulative gross unrealized holding gains (losses) or gross realized gains
(losses) from these investments. All income generated from these investments was recorded as
interest income. We have not recorded any losses relating to municipal variable rate demand notes.

[0000950123-11-094914:mdna:67]
At September 30, 2011, we held $140.9 million of municipal fixed-rate bonds. These bonds are
classified as available-for-sale and had an average duration of 1.1 years at September 30, 2011.
At September 30, 2011, approximately 16% of our municipal fixed-rate bond portfolio had a credit
rating of AAA, 66% had a credit rating of AA, and 18% had a credit rating of A. Because our bond
portfolio has a high quality rating and contractual maturities of a short duration, we are able to
obtain prices for these bonds derived from observable market inputs, or for similar securities
traded in an active market, on a daily basis.

[0000950123-11-094914:mdna:68]
At September 30, 2011, we held $176.7 million of corporate bonds. These bonds are classified as
available-for-sale and had an average duration of 0.9 years. At September 30, 2011, approximately
1% of our corporate bond portfolio had a credit rating of AAA, 13% had a credit rating of AA, 48%
had a credit rating of A, and 38% had a credit rating of BBB. Because our bond portfolio has a
high quality rating and contractual maturities of a short duration, we are able to obtain prices
for these bonds derived from observable market inputs, or for similar securities traded in an
active market, on a daily basis.

[0000950123-11-094914:mdna:69]
Our long-term investments increased 33.3% from $261.2 million at December 31, 2010 to $348.1
million at September 30, 2011. The primary reasons for the increase in our long-term investments
were cash generated from operations and proceeds from stock option exercises by our employees.
Long-term investments at September 30, 2011 and December 31, 2010 included an investment in a
certificate of deposit of $48.3 million, which serves as collateral for our revenue bonds, as
discussed below. We have various equity investments included in long-term investments at a cost of
$12.7 million and $11.5 million, and with a fair value of $34.0 million and $48.0 million, at
September 30, 2011 and December 31, 2010, respectively, including a single equity security, of
which we held

[0000950123-11-094914:mdna:70]
1.2 million shares and 1.5 million shares, carried at $21.3 million and $34.2 million of fair value at September 30, 2011 and December 31,
2010, respectively. The single security traded approximately 0.9 million shares per day in the
nine months ended September 30, 2011 in an active market on a European stock exchange. Of the
gross unrealized gains included in the fair value of our marketable securities at September 30,
2011, this single security comprised $20.9 million of this unrealized gain. Long-term investments
at September 30, 2011 also include $6.1 million related to our deferred compensation plan; $2.2
million of other investments carried at cost, consisting of interests in two private equity funds
and an investment in a privately held telecommunications equipment manufacturer; and $0.7 million
of a fixed income bond fund.

[0000950123-11-094914:mdna:71]
We review our investment portfolio for potential “other-than-temporary” declines in value on an
individual investment basis. We assess, on a quarterly basis, significant declines in value which
may be considered other-than-temporary and, if necessary, recognize and record the appropriate
charge to write-down the carrying value of such investments. In making this assessment, we take
into consideration qualitative and quantitative information, including but not limited to the
following: the magnitude and duration of historical declines in market prices, credit rating
activity, assessments of liquidity, public filings, and statements made by the issuer. We
generally begin our identification of potential other-than-temporary impairments by reviewing any
security with a fair value that has declined from its original or adjusted cost basis by 25% or
more for six or more consecutive months. We then evaluate the individual security based on the
previously identified factors to determine the amount of the write-down, if any. As a result of
our review, we recorded an other-than-temporary impairment charge of $32 thousand during the nine
months ended September 30, 2011 related to seven marketable equity securities. For the nine months
ended September 30, 2010, we recorded an other-than-temporary impairment charge of $43 thousand
related to five marketable equity securities.

[0000950123-11-094914:mdna:72]
[same as prior period, unchanged from 0000950123-11-071519:mdna:69]

[0000950123-11-094914:mdna:73]
[same as prior period, unchanged from 0000950123-11-071519:mdna:70]

[0000950123-11-094914:mdna:74]
In July 2003, our Board of Directors elected to begin declaring quarterly dividends on our common
stock considering the tax treatment of dividends and adequate levels of Company liquidity. During
the nine months ended September 30, 2011, we paid dividends totaling $17.4 million.

[0000950123-11-094914:mdna:75]
[same as prior period, unchanged from 0000950123-11-071519:mdna:72]

[0000950123-11-094914:mdna:76]
We have amounts outstanding under loans made pursuant to an Alabama State Industrial Development
Authority revenue bond (the Bond) which totaled $48.0 million at September 30, 2011 and December
31, 2010. At September 30, 2011, the estimated fair value of the Bond was approximately $48.3
million, based on a debt security with a comparable interest rate and maturity and a Standard &
Poor’s credit rating of A+. Included in long-term investments are restricted funds in the amount
of $48.3 million at September 30, 2011 and December 31, 2010, which is a collateral deposit against
the principal amount of the Bond. We have the right to set-off the balance of the Bond with the
collateral deposit in order to reduce the balance of the indebtedness. The Bond matures on January
1, 2020, and bears interest at the rate of 5% per annum. In conjunction with this program, we are
eligible to receive certain economic incentives from the state of Alabama that reduce the amount of
payroll withholdings we are required to remit to the state for those employment positions that
qualify under this program.

[0000950123-11-094914:mdna:77]
We are required to make payments in the amounts necessary to pay the principal and interest on the
amounts currently outstanding. Based on positive cash flow from operating activities, we have
decided to continue early partial redemptions of the Bond. It is our intent to make annual
principal payments in addition to the interest amounts that are due. In connection with this
decision, $1.5 million of the Bond debt has been classified in accounts payable in the Consolidated
Balance Sheet.

[0000950123-11-094914:mdna:78]
[same as prior period, unchanged from 0000950123-11-071519:mdna:75]

[0000950123-11-094914:mdna:79]
Since 1997, our Board of Directors has approved multiple share repurchase programs that have
authorized open market repurchase transactions of up to 30 million shares of our common stock.
During the nine months ended September 30, 2011, we repurchased 1.1 million shares of our common
stock at an average price of $31.98 per share. We have the authority to purchase an additional 0.9
million shares of our common stock under the plan approved by the Board of Directors on April 14,
2008.

[0000950123-11-094914:mdna:80]
On October 11, 2011, we announced that our Board of Directors had authorized the repurchase of an
additional 5.0 million shares of our common stock to commence upon completion of the repurchase
plan announced on April 14, 2008.
Upon completion of the current plan, the new plan to repurchase 5.0 million shares will be
implemented through open market or private purchases from time to time as conditions warrant.

[0000950123-11-094914:mdna:81]
To accommodate employee stock option exercises, we issued 1.8 million shares of treasury stock for
$33.6 million during the nine months ended September 30, 2011. During the nine months ended
September 30, 2010, we issued 1.2 million shares of treasury stock for $19.8 million.

[0000950123-11-094914:mdna:82]
[same as prior period, unchanged from 0000950123-11-071519:mdna:78]

[0000950123-11-094914:mdna:83]
We do not have off-balance sheet financing arrangements and have not engaged in any related party
transactions or arrangements with unconsolidated entities or other persons that are reasonably
likely to materially affect liquidity or the availability of or requirements for capital resources.
During the nine months ended September 30, 2011, there have been no material changes in
contractual obligations and commercial commitments from those discussed in our most recent Annual
Report on Form 10-K for the year ended December 31, 2010 filed on February 25, 2011 with the SEC.

[0000950123-11-094914:mdna:84]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, and we
have contributed $8.4 million as of September 30, 2011, of which $7.7 million has been applied to
these commitments. See Note 5 of Notes to Consolidated Financial Statements for additional
information.

[0000950123-11-094914:mdna:85]
[same as prior period, unchanged from 0000950123-11-071519:mdna:81]

[0000950123-11-094914:mdna:86]
[same as prior period, unchanged from 0000950123-11-071519:mdna:82]

[0000950123-11-094914:mdna:87]
|  | • |  | Our operating results may fluctuate in future periods, which may adversely affect our stock price. |
|  | • |  | Our revenue for a particular period can be difficult to predict, and a shortfall in revenue may harm our operating results. |
|  | • |  | General economic conditions may reduce our revenues and harm our operating results. |
|  | • |  | Our exposure to the credit risks of our customers and distributors may make it difficult to collect accounts receivable and could adversely affect our operating results and financial condition. |
|  | • |  | We expect gross margin to vary over time, and our level of product gross margin may not be sustainable. |
|  | • |  | We must continue to update and improve our products and develop new products in order to compete and to keep pace with improvements in telecommunications technology. |
|  | • |  | Our products may not continue to comply with the regulations governing their sale, which may harm our business. |
|  | • |  | Our failure or the failure of our contract manufacturers to comply with applicable environmental regulations could adversely impact our results of operations. |
|  | • |  | If our products do not interoperate with our customers’ networks, installations may be delayed or cancelled, which could harm our business. |
|  | • |  | The lengthy approval process required by major and other service providers for new products could result in fluctuations in our revenue. |
|  | • |  | We engage in research and development activities to improve the application of developed technologies, and as a consequence may miss certain market opportunities enjoyed by larger companies with substantially greater research and development efforts who may focus on more leading edge development. |
|  | • |  | We depend heavily on sales to certain customers; the loss of any of these customers would significantly reduce our revenues and net income. |
|  | • |  | Our strategy of outsourcing a portion of our manufacturing requirements to subcontractors located in Asia may result in us not meeting our cost, quality or performance standards. |
|  | • |  | Our dependence on a limited number of suppliers may prevent us from delivering our products on a timely basis, which could have a material adverse effect on customer relations and operating results. |
|  | • |  | We compete in markets that have become increasingly competitive, which may result in reduced gross profit margins and market share. |

[0000950123-11-094914:mdna:88]
|  | • |  | Our estimates regarding future warranty obligations may change due to product failure rates, shipment volumes, field service obligations and other rework costs incurred in correcting product failures. If our estimates change, the liability for warranty obligations may be increased or decreased, impacting future cost of goods sold. |
|  | • |  | Managing our inventory is complex and may include write-downs of excess or obsolete inventory. |
|  | • |  | We may pursue acquisitions, which may expose us to a number of risks. If we are unable to mitigate these risks, our business may be negatively impacted. |
|  | • |  | Increased sales volume in international markets could result in increased costs or loss of revenue due to factors inherent in these markets. |
|  | • |  | We may be adversely affected by fluctuations in currency exchange rates. |
|  | • |  | Our success depends on our ability to reduce the selling prices of succeeding generations of our products. |
|  | • |  | Our failure to maintain rights to intellectual property used in our business could adversely affect the development, functionality, and commercial value of our products. |
|  | • |  | Software under license from third parties for use in certain of our products may not continue to be available to us on commercially reasonable terms. |
|  | • |  | We may incur liabilities or become subject to litigation that would have a material effect on our business. |
|  | • |  | Consolidation and deterioration in the competitive service provider market could result in a significant decrease in our revenue. |
|  | • |  | We depend on distributors who maintain inventories of our products. If the distributors reduce their inventories of these products, our sales could be adversely affected. |
|  | • |  | If we are unable to successfully develop relationships with system integrators, service providers, and enterprise value added resellers, our sales may be negatively affected. |
|  | • |  | If we fail to manage our exposure to worldwide financial and securities markets successfully, our operating results and financial statements could be materially impacted. |
|  | • |  | Changes in our effective tax rate or assessments arising from tax audits may have an adverse impact on our results. |
|  | • |  | Our success depends on attracting and retaining key personnel. |
|  | • |  | Regulatory and potential physical impacts of climate change may affect our customers and our production operations, resulting in adverse effects on our operating results. |
|  | • |  | While we believe our internal control over financial reporting is adequate, a failure to maintain effective internal control over financial reporting as our business expands could result in a loss of investor confidence in our financial reports and have an adverse effect on our stock price. |
|  | • |  | The price of our common stock has been volatile and may continue to fluctuate significantly. |

[0000950123-11-094914:mdna:89]
[same as prior period, unchanged from 0000950123-11-071519:mdna:116]
