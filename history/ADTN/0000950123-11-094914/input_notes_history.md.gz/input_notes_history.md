# ADTN note change history — 0000950123-11-071519 → 0000950123-11-094914


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2011-11-03):
[0000950123-11-094914:note_history:1]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, and we
   have contributed $8.4 million as of September 30, 2011, of which $7.7 million has been applied to
   these commitments. See Note 5 of Notes to Consolidated Financial Statements for additional
   information.
  (was, 2011-08-02, similarity 0.8757):
[0000950123-11-071519:note_history:1]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, and we
   have contributed $8.4 million as of June 30, 2011, of which $7.7 million has been applied to these
   commitments. See Note 4 of Notes to Consolidated Financial Statements for additional information.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2011-11-03):
[0000950123-11-094914:note_history:2]
In September 2011, the Financial Accounting Standards Board (FASB) issued Accounting Standards
   Update No. 2011-08, Testing Goodwill for Impairment (ASU 2011-08). Existing accounting guidance
   requires that an entity perform a test for goodwill impairment, on at least an annual basis, by
   first comparing the fair value of a reporting unit with its carrying amount, including goodwill.
   If the fair value of a reporting unit is less than its carrying amount, then the second step of the
   test is to be performed to measure the amount of impairment loss, if any. ASU 2011-08 will allow
   an entity to first assess qualitative factors to determine whether it is necessary to perform the
   two-step quantitative goodwill impairment test. An entity will no longer be required to calculate
   the fair value of a reporting unit unless the entity determines, based on a qualitative assessment,
   that it is more likely than not that its fair value is less than its carrying amount. This update
   is effective for annual and interim goodwill impairment tests performed for fiscal years beginning
   after December 15, 2011, with early adoption permitted. We plan to adopt this amendment during the
   fourth quarter. We do not expect the adoption of this amendment will have a material impact on our
   consolidated results of operations or financial condition.

- changed (2011-11-03):
[0000950123-11-094914:note_history:3]
In June 2011, the FASB issued Accounting Standards Update No. 2011-05, Presentation of
   Comprehensive Income (ASU 2011-05). ASU 2011-05 requires companies to present the components of
   net income and other comprehensive income either as one continuous statement or as two consecutive
   statements. ASU 2011-05 eliminates the option to present the components of other comprehensive
   income as part of the statement of changes in stockholders’ equity. While ASU 2011-05 changes the
   presentation of comprehensive income, it does not change the components that are recognized in net
   income or comprehensive income under current accounting guidance. This update is effective for
   fiscal years, and interim periods within those years, ending after December 15, 2011, with early
   adoption permitted. We plan to adopt this amendment during the first quarter of 2012. Since ASU
   2011-05 affects presentation only, it will have no effect on our consolidated results of operations
   or financial condition.
  (was, 2011-08-02, similarity 0.9438):
[0000950123-11-071519:note_history:3]
In June 2011, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update
   No. 2011-05, Presentation of Comprehensive Income (ASU 2011-05). ASU 2011-05 requires companies to
   present the components of net income and other comprehensive income either as one continuous
   statement or as two consecutive statements. ASU 2011-05 eliminates the option to present the
   components of other comprehensive income as part of the statement of changes in stockholders’
   equity. While ASU 2011-05 changes the presentation of comprehensive income, it does not change the
   components that are recognized in net income or comprehensive income under current accounting
   guidance. This update is effective for fiscal years, and interim periods within those years,
   ending after December 15, 2011, with early adoption permitted. Since ASU 2011-05 affects
   presentation only, it will have no effect on our consolidated results of operations or financial
   condition.

- changed (2011-11-03):
[0000950123-11-094914:note_history:4]
In May 2011, the FASB issued Accounting Standards Update No. 2011-04, Amendments to Achieve Common
   Fair Value Measurement and Disclosure Requirements in U.S. GAAP and IFRSs (ASU 2011-04). ASU
   2011-04 is intended to improve the comparability of fair value measurements presented and disclosed
   in financial statements prepared in
   accordance with U.S. GAAP and IFRS. The amendments are of two types: (i) those that clarify the
   Board’s intent about the application of existing fair value measurement and disclosure requirements
   and (ii) those that change a particular principle or requirement for measuring fair value or for
   disclosing information about fair value measurements. This update is effective for annual periods
   beginning after December 15, 2011. We do not expect the adoption of this amendment will have a
   material impact on our consolidated results of operations or financial condition.
  (was, 2011-08-02, similarity 0.9994):
[0000950123-11-071519:note_history:4]
In May 2011, the FASB issued Accounting Standards Update No. 2011-04, Amendments to Achieve Common
   Fair Value Measurement and Disclosure Requirements in U.S. GAAP and IFRSs(ASU 2011-04). ASU
   2011-04 is intended to improve the comparability of fair value measurements presented and disclosed
   in financial statements prepared in accordance with U.S. GAAP and IFRS. The amendments are of two
   types: (i) those that clarify the Board’s intent about the application of existing fair value
   measurement and disclosure requirements and (ii) those that change a particular principle or
   requirement for measuring fair value or for disclosing information about fair value measurements.
   This update is effective for annual periods beginning after December 15, 2011. We do not expect
   the adoption of this amendment will have a material impact on our consolidated results of
   operations or financial condition.

- changed (2011-11-03):
[0000950123-11-094914:note_history:5]
During the nine months ended September 30, 2011, we adopted the following accounting standards,
   which had no material effect on our consolidated results of operations or financial condition:
  (was, 2011-08-02, similarity 0.9558):
[0000950123-11-071519:note_history:5]
During the six months ended June 30, 2011, we adopted the following accounting standards, which had no material effect on our
   consolidated results of operations or financial condition:

- changed (2011-11-03):
[0000950123-11-094914:note_history:6]
In October 2009, the FASB issued Accounting Standards Update No. 2009-13, Multiple-Deliverable
   Revenue Arrangements (ASU 2009-13). ASU 2009-13 provides amendments to the criteria in Subtopic
   605-25 of the ASC for separating consideration in multiple-deliverable arrangements. As a result
   of those amendments, multiple-deliverable arrangements are separated in more circumstances than
   under previously existing U.S. GAAP. ASU 2009-13 established a selling price hierarchy for
   determining the selling price of a deliverable and replaced the term fair value in the revenue
   allocation guidance with selling price to clarify that the allocation of revenue is based on
   entity-specific assumptions rather than assumptions of a marketplace participant. ASU 2009 -13
   also eliminated the residual method of allocation and required that arrangement consideration be
   allocated at the inception of the arrangement to all deliverables using the relative selling price
   method and required that a vendor determine its best estimate of selling price in a manner that is
   consistent with that used to determine the price to sell the deliverable on a standalone basis.
  (was, 2011-08-02, similarity 0.6898):
[0000950123-11-071519:note_history:6]
In October 2009, the FASB issued Accounting Standards Update No. 2009-13, Multiple-Deliverable
   Revenue Arrangements (ASU 2009-13). ASU 2009-13 provides amendments to the criteria in Subtopic
   605-25 of the ASC for separating consideration in multiple-deliverable arrangements. As a result
   of those amendments, multiple-deliverable
   arrangements will be separated in more circumstances than under existing U.S. GAAP. ASU 2009-13
   establishes a selling price hierarchy for determining the selling price of a deliverable and will
   replace the term fair value in the revenue allocation guidance with selling price to clarify that
   the allocation of revenue is based on entity-specific assumptions rather than assumptions of a
   marketplace participant. ASU 2009 -13 will also eliminate the residual method of allocation and
   require that arrangement consideration be allocated at the inception of the arrangement to all
   deliverables using the relative selling price method and will require that a vendor determine its
   best estimate of selling price in a manner that is consistent with that used to determine the price
   to sell the deliverable on a standalone basis.

- changed (2011-11-03):
[0000950123-11-094914:note_history:7]
We adopted this amendment during the first quarter of 2011. The adoption of this amendment had no
   effect on our consolidated results of operations and financial condition for the three or nine
   months ended September 30, 2011.
  (was, 2011-08-02, similarity 0.8868):
[0000950123-11-071519:note_history:7]
We adopted this amendment during the first quarter of 2011. The adoption of this amendment had no
   effect on our consolidated results of operations and financial condition for the three or six
   months ended June 30, 2011.

- changed (2011-11-03):
[0000950123-11-094914:note_history:8]
In October 2009, the FASB issued Accounting Standards Update No. 2009-14, Certain Revenue
   Arrangements that Include Software Arrangements. ASU 2009-14 changed the accounting model for
   revenue arrangements that include both tangible products and software elements. Tangible products
   containing software components and non-software components that function together to deliver the
   tangible product’s essential functionality are no longer within the scope of the software revenue
   guidance in Subtopic 985-605 of the ASC. In addition, ASU 2009-14 requires that hardware
   components of a tangible product containing software components always be excluded from the
   software revenue guidance. In that regard, ASU 2009-14 provides additional guidance on how to
   determine which software, if any, relating to the tangible product also would be excluded from the
   scope of the software revenue guidance. ASU 2009-14 also provides guidance on how a vendor should
   allocate arrangement consideration to deliverables in an arrangement that includes both tangible
   products and software. ASU 2009-14 also provides further guidance on how to allocate arrangement
   consideration when an arrangement includes deliverables both included and excluded from the scope
   of the software revenue guidance. We adopted this amendment during the first quarter of 2011. The
   adoption of this amendment had no effect on our consolidated results of operations and financial
   condition for the three or nine months ended September 30, 2011.
  (was, 2011-08-02, similarity 0.9801):
[0000950123-11-071519:note_history:8]
In October 2009, the FASB issued Accounting Standards Update No. 2009-14, Certain Revenue
   Arrangements that Include Software Arrangements. ASU 2009-14 changes the accounting model for
   revenue arrangements that include both tangible products and software elements. Tangible products
   containing software components and non-software components that function together to deliver the
   tangible product’s essential functionality are no longer within the scope of the software revenue
   guidance in Subtopic 985-605 of the ASC. In addition, ASU 2009-14 requires that hardware
   components of a tangible product containing software components always be excluded from the
   software revenue guidance. In that regard, ASU 2009-14 provides additional guidance on how to
   determine which software, if any, relating to the tangible product also would be excluded from the
   scope of the software revenue guidance. ASU 2009-14 also provides guidance on how a vendor should
   allocate arrangement consideration to deliverables in an arrangement that includes both tangible
   products and software. ASU 2009-14 also provides further guidance on how to allocate arrangement
   consideration when an arrangement includes deliverables both included and excluded from the scope
   of the software revenue guidance. We adopted this amendment during the first quarter of 2011. The
   adoption of this amendment had no effect on our consolidated results of operations and financial
   condition for the three or six months ended June 30, 2011.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2011-11-03):
[0000950123-11-094914:note_history:9]
At September 30, 2011, we held the following securities and investments, recorded at either fair
   value or cost:
  (was, 2011-08-02, similarity 0.9665):
[0000950123-11-071519:note_history:9]
At December 31, 2010, we held the following securities and investments, recorded at either fair
   value or cost.

- changed (2011-11-03):
[0000950123-11-094914:note_history:10]
At December 31, 2010, we held the following securities and investments, recorded at either fair
   value or cost:
  (was, 2011-08-02, similarity 0.9412):
[0000950123-11-071519:note_history:10]
At June 30, 2011, we held the following securities and investments, recorded at either fair
   value or cost.

- changed (2011-11-03):
[0000950123-11-094914:note_history:11]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Carrying |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Deferred compensation plan assets |  | $ | 3,483 |  |  | $ | 770 |  |  | $ | (7 | ) |  | $ | 4,246 |  |
| Corporate bonds |  |  | 126,671 |  |  |  | 630 |  |  |  | (229 | ) |  |  | 127,072 |  |
| Municipal fixed-rate bonds |  |  | 71,212 |  |  |  | 268 |  |  |  | (13 | ) |  |  | 71,467 |  |
| Municipal variable rate demand notes |  |  | 116,745 |  |  |  | — |  |  |  | — |  |  |  | 116,745 |  |
| Fixed income bond fund |  |  | 526 |  |  |  | 220 |  |  |  | — |  |  |  | 746 |  |
| Marketable equity securities |  |  | 11,486 |  |  |  | 36,657 |  |  |  | (133 | ) |  |  | 48,010 |  |
| Available-for-sale securities held at fair value |  | $ | 330,123 |  |  | $ | 38,545 |  |  | $ | (382 | ) |  | $ | 368,286 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 48,250 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 2,103 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 418,639 |  |
  (was, 2011-08-02, similarity 0.9951):
[0000950123-11-071519:note_history:11]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Carrying |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Deferred compensation plan assets |  | $ | 6,438 |  |  | $ | 351 |  |  | $ | — |  |  | $ | 6,789 |  |
| Corporate bonds |  |  | 200,280 |  |  |  | 971 |  |  |  | (362 | ) |  |  | 200,889 |  |
| Municipal fixed-rate bonds |  |  | 117,262 |  |  |  | 597 |  |  |  | (5 | ) |  |  | 117,854 |  |
| Municipal variable rate demand notes |  |  | 94,870 |  |  |  | — |  |  |  | — |  |  |  | 94,870 |  |
| Fixed income bond fund |  |  | 526 |  |  |  | 225 |  |  |  | — |  |  |  | 751 |  |
| Marketable equity securities |  |  | 12,119 |  |  |  | 27,516 |  |  |  | (212 | ) |  |  | 39,423 |  |
| Available-for-sale securities held at fair value |  | $ | 431,495 |  |  | $ | 29,660 |  |  | $ | (579 | ) |  | $ | 460,576 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 48,250 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 2,296 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 511,122 |  |

- changed (2011-11-03):
[0000950123-11-094914:note_history:12]
At September 30, 2011, we held $6.1 million of deferred compensation plan assets, carried at fair
   value.
  (was, 2011-08-02, similarity 0.9412):
[0000950123-11-071519:note_history:12]
At June 30, 2011, we held $6.8 million of deferred compensation plan assets, carried at fair value.

- changed (2011-11-03):
[0000950123-11-094914:note_history:13]
At September 30, 2011, we held $176.7 million of corporate bonds. These bonds are classified as
   available-for-sale and had an average duration of 0.9 years at September 30, 2011. At September
   30, 2011, approximately 1% of our corporate bond portfolio had a credit rating of AAA, 13% had a
   credit rating of AA, 48% had a credit rating of A, and 38% had a credit rating of BBB. Because our
   bond portfolio has a high quality rating and contractual maturities of a short duration, we are
   able to obtain prices for these bonds derived from observable market inputs, or for similar
   securities traded in an active market, on a daily basis.
  (was, 2011-08-02, similarity 0.954):
[0000950123-11-071519:note_history:13]
At June 30, 2011, we held $200.9 million of corporate bonds. These bonds are classified as
   available-for-sale and had an average duration of 2.2 years at June 30, 2011. At June 30, 2011,
   approximately 1% of our corporate bond portfolio had a credit rating of AAA, 14% had a credit
   rating of AA, 55% had a credit rating of A, and 30% had a credit rating of BBB. Because our bond
   portfolio has a high quality rating and contractual maturities of a short duration, we are able to
   obtain prices for these bonds derived from observable market inputs, or for similar securities
   traded in an active market, on a daily basis.

- changed (2011-11-03):
[0000950123-11-094914:note_history:14]
At September 30, 2011, we held $140.9 million of municipal fixed-rate bonds. These bonds are
   classified as available-for-sale and had an average duration of 1.1 years at September 30, 2011.
   At September 30, 2011, approximately 16% of our municipal fixed-rate bond portfolio had a credit
   rating of AAA, 66% had a credit rating of AA, and 18% had a credit rating of A. Because our bond
   portfolio has a high quality rating and contractual maturities of a short duration, we are able to
   obtain prices for these bonds derived from observable market inputs, or for similar securities
   traded in an active market, on a daily basis.
  (was, 2011-08-02, similarity 0.9533):
[0000950123-11-071519:note_history:14]
At June 30, 2011, we held $117.9 million of municipal fixed-rate bonds. These bonds are classified
   as available-for-sale and had an average duration of 1.3 years at June 30, 2011. At June 30, 2011,
   approximately 24% of our municipal fixed-rate bond portfolio had a credit rating of AAA, 58% had a
   credit rating of AA, and 18% had a credit rating of A. Because
   our bond portfolio has a high quality rating and contractual maturities of a short duration, we are
   able to obtain prices for these bonds derived from observable market inputs, or for similar
   securities traded in an active market, on a daily basis.

- changed (2011-11-03):
[0000950123-11-094914:note_history:15]
At September 30, 2011, we held $60.7 million of municipal variable rate demand notes, all of which
   were classified as available-for-sale. At September 30, 2011, 14% of our municipal variable rate
   demand notes had a credit rating of AAA,
   72% had a credit rating of AA, 14% had a credit rating of A, and all contained put options of seven
   days. Despite the long-term nature of their stated contractual maturities, we routinely buy and
   sell these securities and we believe that we have the ability to quickly liquidate them. Our
   investments in these securities are recorded at fair value, and the interest rates reset every
   seven days. We believe we have the ability to sell our variable rate demand notes to the
   remarketing agent, tender agent or issuer at par value plus accrued interest in the event we decide
   to liquidate our investment in a particular variable rate demand note. At September 30, 2011,
   approximately 40% of our variable rate demand notes were supported by letters of credit from banks
   that we believe to be in good financial condition. The remaining 60% of our variable rate demand
   notes were supported by standby purchase agreements. As a result of these factors, we had no
   cumulative gross unrealized holding gains (losses) or gross realized gains (losses) from these
   investments. All income generated from these investments was recorded as interest income. We have
   not recorded any losses relating to municipal variable rate demand notes.
  (was, 2011-08-02, similarity 0.9863):
[0000950123-11-071519:note_history:15]
At June 30, 2011, we held $94.9 million of municipal variable rate demand notes, all of which were
   classified as available-for-sale. At June 30, 2011, 27% of our municipal variable rate demand
   notes had a credit rating of AAA, 63% had a credit rating of AA, 10% had a credit rating of A, and
   all contained put options of seven days. Despite the long-term nature of their stated contractual
   maturities, we routinely buy and sell these securities and we believe that we have the ability to
   quickly liquidate them. Our investments in these securities are recorded at fair value, and the
   interest rates reset every seven days. We believe we have the ability to sell our variable rate
   demand notes to the remarketing agent, tender agent or issuer at par value plus accrued interest in
   the event we decide to liquidate our investment in a particular variable rate demand note. At June
   30, 2011, approximately 24% of our variable rate demand notes were supported by letters of credit
   from banks that we believe to be in good financial condition. The remaining 76% of our variable
   rate demand notes were supported by standby purchase agreements. As a result of these factors, we
   had no cumulative gross unrealized holding gains (losses) or gross realized gains (losses) from
   these investments. All income generated from these investments was recorded as interest income.
   We have not recorded any losses relating to municipal variable rate demand notes.

- changed (2011-11-03):
[0000950123-11-094914:note_history:16]
At September 30, 2011, we held $0.7 million of a fixed income bond fund.
  (was, 2011-08-02, similarity 0.9106):
[0000950123-11-071519:note_history:16]
At June 30, 2011, we held $0.8 million of a fixed income bond fund.

- added (2011-11-03):
[0000950123-11-094914:note_history:17]
At September 30, 2011, we held $34.0 million of marketable equity securities, including a single
   security, of which we held 1.2 million shares, carried at a fair value of $21.3 million. We sold
   0.3 million shares of this security during the nine months ended September 30, 2011. The sale of
   this security resulted in proceeds of $6.1 million and a realized gain of $6.0 million. This
   single security traded an average of approximately 0.9 million shares per day in the first nine
   months of 2011 in an active market on a European stock exchange. This single security comprises
   $20.9 million of the gross unrealized gains included in the fair value of our marketable equity
   securities at September 30, 2011. The remaining $1.5 million of gross unrealized gains and $1.1
   million of gross unrealized losses at September 30, 2011 were spread amongst more than 400 equity
   securities.

- changed (2011-11-03):
[0000950123-11-094914:note_history:18]
At September 30, 2011, we held a $48.3 million restricted certificate of deposit, which is carried
   at cost. This investment serves as a collateral deposit against the principal amount outstanding
   under loans made to ADTRAN pursuant to an Alabama State Industrial Development Authority revenue
   bond (the Bond). At September 30, 2011, the estimated fair value of the Bond was approximately
   $48.3 million, based on a debt security with a comparable interest rate and maturity and a Standard
   and Poor’s credit rating of A+. We have the right to set-off the balance of the Bond with the
   collateral deposit in order to reduce the balance of the indebtedness. For more information on the
   Bond, see “Debt” under “Liquidity and Capital Resources” in the “Management’s Discussion and
   Analysis of Financial Condition and Results of Operations” contained in Item 2 of Part I of this
   report.
  (was, 2011-08-02, similarity 0.9848):
[0000950123-11-071519:note_history:18]
At June 30, 2011, we held a $48.3 million restricted certificate of deposit, which is carried at
   cost. This investment serves as a collateral deposit against the principal amount outstanding
   under loans made to ADTRAN pursuant to an Alabama State Industrial Development Authority revenue
   bond (the Bond). At June 30, 2011, the estimated fair value of the Bond was approximately $46.0
   million, based on a debt security with a comparable interest rate and maturity and a Standard and
   Poor’s credit rating of A+. We have the right to set-off the balance of the Bond with the
   collateral deposit in order to reduce the balance of the indebtedness. For more information on the
   Bond, see “Debt” under “Liquidity and Capital Resources” in the “Management’s Discussion and
   Analysis of Financial Condition and Results of Operations” contained in Item 2 of Part I of this
   report.

- added (2011-11-03):
[0000950123-11-094914:note_history:19]
At September 30, 2011, we held $2.2 million of other investments carried at cost, consisting of
   interests in two private equity funds and an investment in a privately held telecommunications
   equipment manufacturer. The fair value of these investments was estimated to be approximately
   $10.4 million at September 30, 2011, based on unobservable inputs including information supplied by
   the company and the fund managers. We have committed to invest up to an aggregate of $7.9 million
   in the two private equity funds, and we have contributed $8.4 million as of September 30, 2011, of
   which $7.7 million has been applied toward these commitments. As of September 30, 2011, we have
   received distributions related to these two private equity funds of $8.5 million, of which $2.0
   million was recorded as investment income. These investments are carried at cost, net of
   distributions, with distributions in excess of our investment recorded as investment income. The
   remaining commitment under the funds is $0.2 million, which expires in 2013. We have not been
   required to record any impairment losses related to these investments during the nine months ended
   September 30, 2011.

- changed (2011-11-03):
[0000950123-11-094914:note_history:20]
We review our investment portfolio for potential “other-than-temporary” declines in value on an
   individual investment basis. We assess, on a quarterly basis, significant declines in value which
   may be considered other-than-temporary and, if necessary, recognize and record the appropriate
   charge to write-down the carrying value of such investments. In making this assessment, we take
   into consideration qualitative and quantitative information, including but not limited to the
   following: the magnitude and duration of historical declines in market prices, credit rating
   activity, assessments of liquidity, public filings, and statements made by the issuer. We
   generally begin our identification of potential other-than-temporary impairments by reviewing any
   security with a fair value that has declined from its original or adjusted cost basis by 25% or
   more for six or more consecutive months. We then evaluate the individual security based on the
   previously identified factors to determine the amount of the write-down, if any. As a result of
   our review, we recorded an other-than-temporary impairment charge of $32 thousand during the nine
   months ended September 30, 2011 related to
   seven marketable equity securities. For the nine months ended September 30, 2010, we recorded an
   other-than-temporary impairment charge of $43 thousand related to five marketable equity
   securities.
  (was, 2011-08-02, similarity 0.941):
[0000950123-11-071519:note_history:20]
We review our investment portfolio for potential “other-than-temporary” declines in value on an
   individual investment basis. We assess, on a quarterly basis, significant declines in value which
   may be considered other-than-temporary and, if necessary, recognize and record the appropriate
   charge to write-down the carrying value of such investments. In making this assessment, we take
   into consideration qualitative and quantitative information, including but not limited to the
   following: the magnitude and duration of historical declines in market prices, credit rating
   activity, assessments of liquidity, public filings, and statements made by the issuer. We
   generally begin our identification of potential other-than-temporary impairments by reviewing any
   security with a fair value that has declined from its original or adjusted cost basis by 25% or
   more for six or more consecutive months. We then evaluate the individual security based on the
   previously identified factors to determine the amount of the write-down, if any. As a result of
   our review, we recorded an other-than-temporary impairment charge of $12 thousand during the six
   months ended June 30, 2011 related to three marketable equity securities. For the six months ended
   June 30, 2010, we recorded an other-than-temporary impairment charge of $42 thousand related to
   three marketable equity securities.

- changed (2011-11-03):
[0000950123-11-094914:note_history:21]
|  |  | Fair Value Measurements at September 30, 2011 Using |  |
|  |  |  |  |  |  | Quoted Prices |  |  |  |  |  |  |  |
|  |  |  |  |  |  | in Active |  |  | Significant |  |  |  |  |
|  |  |  |  |  |  | Market for |  |  | Other |  |  | Significant |  |
|  |  |  |  |  |  | Identical |  |  | Observable |  |  | Unobservable |  |
|  |  |  |  |  |  | Assets |  |  | Inputs |  |  | Inputs |  |
| (In thousands) |  | Fair Value |  |  | (Level 1) |  |  | (Level 2) |  |  | (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 7,898 |  |  | $ | 7,898 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 6,114 |  |  |  | 6,114 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 176,657 |  |  |  | — |  |  |  | 176,657 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 140,946 |  |  |  | — |  |  |  | 140,946 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 60,705 |  |  |  | — |  |  |  | 60,705 |  |  |  | — |  |
| Fixed income bond fund |  |  | 691 |  |  |  | 691 |  |  |  | — |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity securities — technology industry |  |  | 22,701 |  |  |  | 22,701 |  |  |  | — |  |  |  | — |  |
| Equity securities — other |  |  | 11,276 |  |  |  | 11,276 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 419,090 |  |  |  | 40,782 |  |  |  | 378,308 |  |  |  | — |  |
| Total |  | $ | 426,988 |  |  | $ | 48,680 |  |  | $ | 378,308 |  |  | $ | — |  |
  (was, 2011-08-02, similarity 0.9953):
[0000950123-11-071519:note_history:21]
|  |  | Fair Value Measurements at June 30, 2011 Using |  |
|  |  |  |  |  |  | Quoted Prices |  |  |  |  |  |  |  |
|  |  |  |  |  |  | in Active |  |  | Significant |  |  |  |  |
|  |  |  |  |  |  | Market for |  |  | Other |  |  | Significant |  |
|  |  |  |  |  |  | Identical |  |  | Observable |  |  | Unobservable |  |
|  |  |  |  |  |  | Assets |  |  | Inputs |  |  | Inputs |  |
| (In thousands) |  | Fair Value |  |  | (Level 1) |  |  | (Level 2) |  |  | (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 10,737 |  |  | $ | 10,737 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 6,789 |  |  |  | 6,789 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 200,889 |  |  |  | — |  |  |  | 200,889 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 117,854 |  |  |  | — |  |  |  | 117,854 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 94,870 |  |  |  | — |  |  |  | 94,870 |  |  |  | — |  |
| Fixed income bond fund |  |  | 751 |  |  |  | 751 |  |  |  | — |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity securities — technology industry |  |  | 25,591 |  |  |  | 25,591 |  |  |  | — |  |  |  | — |  |
| Equity securities — other |  |  | 13,832 |  |  |  | 13,832 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 460,576 |  |  |  | 46,963 |  |  |  | 413,613 |  |  |  | — |  |
| Total |  | $ | 471,313 |  |  | $ | 57,700 |  |  | $ | 413,613 |  |  | $ | — |  |

- changed (2011-11-03):
[0000950123-11-094914:note_history:22]
As of September 30, 2011 and December 31, 2010, the fair value of the investments in
   available-for-sale Level 2 corporate bonds and municipal fixed-rate bonds was $317.6 million and
   $198.5 million, respectively. The fair value of these securities is calculated using a weighted
   average market price for each security. Market prices are obtained from a variety of industry
   standard data providers, security master files from large financial institutions, and other
   third-party sources. These multiple market prices are used as inputs into a
   distribution-curve-based algorithm to determine the daily market value of each security.
  (was, 2011-08-02, similarity 0.9893):
[0000950123-11-071519:note_history:22]
As of June 30, 2011 and December 31, 2010, the fair value of the investments in available-for-sale
   Level 2 corporate bonds and municipal fixed-rate bonds was $318.7 million and $198.5 million,
   respectively. The fair value of these securities is calculated using a weighted average market
   price for each security. Market prices are obtained from a variety of industry standard data
   providers, security master files from large financial institutions, and other third-party sources.
   These multiple market prices are used as inputs into a distribution-curve-based algorithm to
   determine the daily market value of each security.

- changed (2011-11-03):
[0000950123-11-094914:note_history:23]
As of September 30, 2011 and December 31, 2010, the fair value of the investments in
   available-for-sale Level 2 municipal variable rate demand notes was $60.7 million and $116.7
   million, respectively. These securities have a structure that implies a standard expected market
   price. The frequent interest rate resets make it reasonable to expect the price to stay at par.
   These securities are priced at the expected market price.
  (was, 2011-08-02, similarity 0.984):
[0000950123-11-071519:note_history:23]
As of June 30, 2011 and December 31, 2010, the fair value of the investments in available-for-sale
   Level 2 municipal variable rate demand notes was $94.9 million and $116.7 million, respectively.
   These securities have a structure that implies a standard expected market price. The frequent
   interest rate resets make it reasonable to expect the price to stay at par. These securities are
   priced at the expected market price.

- removed (2011-11-03):
[0000950123-11-071519:note_history:24]
At June 30, 2011, we held $39.4 million of marketable equity securities, including a single
   security, of which we held 1.3 million shares, carried at a fair value of $24.3 million. We sold
   0.2 million shares of this security during the six months ended June 30, 2011. The sale of this
   security resulted in proceeds of $4.2 million and a realized gain of $4.1 million. This single
   security traded approximately 0.9 million shares per day in the first six months of 2011 in an
   active market on a European stock exchange. This single security comprises $23.8 million of the
   gross unrealized gains included in the fair value of our marketable equity securities at June 30,
   2011. The remaining $3.7 million of gross unrealized gains and $0.2 million of gross unrealized
   losses at June 30, 2011 were spread amongst more than 400 equity securities.

- removed (2011-11-03):
[0000950123-11-071519:note_history:25]
At June 30, 2011, we held $2.3 million of other investments carried at cost, consisting of
   interests in two private equity funds and an investment in a privately held telecommunications
   equipment manufacturer. The fair value of these investments was estimated to be approximately
   $10.5 million at June 30, 2011, based on unobservable inputs including information supplied by the
   company and the fund managers. We have committed to invest up to an aggregate of $7.9 million in
   the two private equity funds, and we have contributed $8.4 million as of June 30, 2011, of which
   $7.7 million has been applied toward these commitments. As of June 30, 2011, we have received
   distributions related to these two private equity funds of $7.9 million, of which $1.4 million was
   recorded as investment income. These investments are carried at cost, net of distributions, with
   distributions in excess of our investment recorded as investment income. The remaining commitment
   under the funds is $0.2 million, which expires in 2013. We have not been required to record any
   impairment losses related to these investments during the six months ended June 30, 2011.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2011-11-03):
[0000950123-11-094914:note_history:26]
We employ the law firm of our director emeritus for legal services. All bills for services
   rendered by this firm are reviewed and approved by our Chief Financial Officer. We believe that
   the fees for such services are comparable to those charged by other firms for services rendered to
   us. For the three and nine month periods ended September 30, 2011 and 2010, we incurred fees of
   $10 thousand per month for these legal services.
  (was, 2011-08-02, similarity 0.9257):
[0000950123-11-071519:note_history:26]
We employ the law firm of our director emeritus for legal services. All bills for services
   rendered by this firm are reviewed and approved by our Chief Financial Officer. We believe that
   the fees for such services are comparable to those charged by other firms for services rendered to
   us. For the three and six month periods ended June 30, 2011 and 2010, we incurred fees of $10
   thousand per month for these legal services.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2011-11-03):
[0000950123-11-094914:note_history:27]
On October 11, 2011, we announced that our Board of Directors declared a quarterly cash dividend of
   $0.09 per common share to be paid to stockholders of record at the close of business on October 27,
   2011. The payment date will be November 10, 2011. The quarterly dividend payment will be
   approximately $5.7 million. In July 2003, our Board of Directors elected to begin declaring
   quarterly dividends on our common stock considering the tax treatment of dividends and adequate
   levels of Company liquidity.

- added (2011-11-03):
[0000950123-11-094914:note_history:28]
On October 11, 2011, we announced that our Board of Directors had authorized the repurchase of an
   additional 5.0 million shares of our common stock to commence upon completion of the repurchase
   plan announced on April 14, 2008. Upon completion of the current plan, under which we have the
   remaining authority to purchase 0.9 million shares, the new plan to repurchase 5.0 million shares
   will be implemented through open market or private purchases from time to time as conditions
   warrant.

- removed (2011-11-03):
[0000950123-11-071519:note_history:29]
On July 12, 2011, we announced that our Board of Directors declared a quarterly cash dividend of
   $0.09 per common share to be paid to stockholders of record at the close of business on July 28,
   2011. The payment date will be August 11, 2011. The quarterly dividend payment will be
   approximately $5.8 million. In July 2003, our Board of Directors elected to begin declaring
   quarterly dividends on our common stock considering the tax treatment of dividends and adequate
   levels of Company liquidity.

- removed (2011-11-03):
[0000950123-11-071519:note_history:30]
During the third quarter of 2011 and as of August 2, 2011, we repurchased 0.6 million shares of our
   common stock through open market purchases at an average cost of $34.25 per share. We have the
   authority to purchase an additional 1.4 million shares of our common stock under the plan approved
   by the Board of Directors on April 14, 2008.
