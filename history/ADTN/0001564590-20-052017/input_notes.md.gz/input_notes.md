# ADTN notes — 0001564590-20-052017


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001564590-20-052017:notes:1]
[same as prior period, unchanged from 0001564590-20-038237:notes:1]

[0001564590-20-052017:notes:2]
[same as prior period, unchanged from 0001564590-20-038237:notes:2]

[0001564590-20-052017:notes:3]
The accompanying unaudited condensed consolidated financial statements of ADTRAN®, Inc. and its subsidiaries (“ADTRAN”, the “Company”, “we”, “our” or “us”) have been prepared pursuant to the rules and regulations of the Securities and Exchange Commission (the “SEC”) applicable to interim financial information presented in Quarterly Reports on Form 10-Q. Accordingly, certain information and notes required by generally accepted accounting principles in the United States of America (“U.S. GAAP”) for complete financial statements are not included herein. The Condensed Consolidated Balance Sheet as of December 31, 2019 is derived from audited financial statements but does not include all disclosures required by U.S. GAAP.

[0001564590-20-052017:notes:4]
[same as prior period, unchanged from 0001564590-20-038237:notes:4]

[0001564590-20-052017:notes:5]
[same as prior period, unchanged from 0001564590-20-038237:notes:5]

[0001564590-20-052017:notes:6]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenue and expense during the reporting period. The more significant estimates include excess and obsolete inventory reserves, warranty reserves, customer rebates, determination and accrual of deferred revenue components of multi-element sales agreements, estimated costs to complete obligations associated with deferred and accrued revenues and network installations, estimated income tax provision and income tax contingencies, fair value of stock-based compensation, assessment of goodwill and other intangibles for impairment, estimated lives of intangible assets, estimated pension liability and fair value of investments. Actual amounts could differ significantly from these estimates.

[0001564590-20-052017:notes:7]
We assessed certain accounting matters that generally require consideration of forecasted financial information in context with the information reasonably available to us and the unknown future impacts of the novel coronavirus (“COVID-19”) as of September 30, 2020 and through the date of this report. The accounting matters assessed included, but were not limited to, the allowance for doubtful accounts, current estimated credit losses, stock-based compensation, excess and obsolete inventory reserves, carrying value of goodwill, intangibles and other long-lived assets, financial assets, valuation allowances for tax assets and revenue recognition. While there was not a material impact to our condensed consolidated financial statements as of and for the three and nine month periods ended September 30, 2020 resulting from these assessments, future conditions related to the magnitude and duration of the COVID-19 pandemic, as well as other factors, could result in material impacts to our consolidated financial statements in future reporting periods.

[0001564590-20-052017:notes:8]
[same as prior period, unchanged from 0001564590-20-038237:notes:8]

[0001564590-20-052017:notes:9]
During the three months ended June 30, 2019, the Company determined that there was an immaterial misstatement of its excess and obsolete inventory reserves in its previously issued annual and interim financial statements. The Company corrected this misstatement by recognizing a $0.8 million out-of-period adjustment during the three months ended June 30, 2019, which increased its excess and obsolete inventory reserve and cost of goods sold for the period. For the six months ended June 30, 2019, the out-of-period adjustment was a cumulative $0.2 million reduction in its excess and obsolete inventory reserve and cost of goods sold. In addition, the Company determined that a $1.0 million cash inflow related to an insurance recovery was incorrectly classified as a cash flow from operations instead of a cash flow from investing activities within the unaudited Condensed Consolidated Statement of Cash Flows for the three months ended March 31, 2019. The Company corrected this misstatement in the Unaudited Condensed Consolidated Statement of Cash Flows for the nine months ended September 30, 2019 to correctly reflect the $1.0 million insurance recovery as a cash inflow from investing activities. Management determined that these misstatements were not material to any of its previously issued financial statements on both a quantitative and qualitative basis.

[0001564590-20-052017:notes:10]
[same as prior period, unchanged from 0001564590-20-038237:notes:10]

[0001564590-20-052017:notes:11]
Recently Adopted Accounting Pronouncements

[0001564590-20-052017:notes:12]
[same as prior period, unchanged from 0001564590-20-038237:notes:12]

[0001564590-20-052017:notes:13]
In June 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. ASU 2016-13 requires the measurement and recognition of expected credit losses for financial instruments held at amortized cost. In November 2018, the FASB issued ASU 2018-19, Codification Improvements to Topic 326 Financial Instruments – Credit Losses, which clarifies that receivables arising from operating leases are not within the scope of the credit losses standard, but rather should be accounted for in accordance with the standard for leases. In April 2019, the FASB issued ASU 2019-04, Codification Improvements to Topic 326, Financial Instruments–Credit Losses, Topic 815, Derivatives and Hedging, and Topic 825, Financial Instruments, which clarifies the accounting for transfers between classifications of debt securities and clarifies that entities should include expected recoveries on financial assets in the calculation of the current expected credit loss allowance. In addition, renewal options that are not unconditionally cancelable should be considered in the determination of expected credit losses. In May 2019, the FASB issued ASU 2019-05, Financial Instruments – Credit Losses (Topic 326): Targeted Transition Relief, which amends ASU 2016-13 to allow companies, upon adoption, to elect the fair value option on financial instruments that were previously recorded at amortized cost if they meet certain criteria. In November 2019, the FASB issued ASU 2019-11, Codification Improvements to Topic 326, Financial Instruments – Credit Losses, which makes various narrow-scope amendments to the new credit losses standard, such as providing disclosure relief for accrued interest receivables. All of these ASUs were codified as part of Accounting Standards Codifications (“ASC”) Topic 326 and were effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. The Company adopted this standard on January 1, 2020, using a modified-retrospective approach and, therefore, elected to carry forward legacy disclosures for comparative periods and did not adjust the comparative period financial information. Additionally, the Company made an accounting policy election, at the class of financing receivable, not to measure the allowance for credit losses for accrued interest receivables, as the Company writes off the uncollectable accrued interest receivable by reversing any previously recorded interest income in a timely manner (as soon as these amounts are determined to be uncollectable). The adoption of this standard did not have a material effect on our consolidated financial statements. See Note 19 for additional information.

[0001564590-20-052017:notes:14]
In January 2017, the FASB issued ASU 2017-04, Intangibles – Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment. ASU 2017-04 simplifies the measurement of goodwill by eliminating step 2 of the goodwill impairment test. Under ASU 2017-04, entities are required to compare the fair value of a reporting unit to its carrying amount and recognize an impairment charge for the amount by which the carrying amount exceeds the reporting unit’s fair value. ASU 2017-04 was effective for annual or interim impairment tests performed in fiscal years beginning after December 15, 2019. The Company adopted ASU 2017-04 on January 1, 2020, and the amendments were applied prospectively. The adoption of this standard did not have a material effect on our consolidated financial statements.

[0001564590-20-052017:notes:15]
In August 2018, the FASB issued ASU 2018-13, Fair Value Measurement (Topic 820): Disclosure Framework – Changes to the Disclosure Requirements for Fair Value Measurement, which changes the fair value measurement disclosure requirements of ASC 820, Fair Value Measurement. The amendments in this ASU are the result of a broader disclosure project, Concepts Statement No. 8 — Conceptual Framework for Financial Reporting — Chapter 8 — Notes to Financial Statements, which the FASB finalized on August 28, 2018. The FASB used the guidance in the Concepts Statement to improve the effectiveness of ASC 820’s disclosure requirements. ASU 2018-13 provides users of financial statements with information about assets and liabilities measured at fair value in the statement of financial position or disclosed in the notes to the financial statements. More specifically, ASU 2018-13 requires disclosures about the valuation techniques and inputs that are used to arrive at measures of fair value, including judgments and assumptions that are made in determining fair value. In addition, ASU 2018-13 requires disclosures regarding the uncertainty in the fair value measurements as of the reporting date and how changes in fair value measurements affect performance and cash flows. The Company adopted ASU 2018-13 on January 1, 2020, and the adoption of this standard did not have a material effect on our consolidated financial statements.

[0001564590-20-052017:notes:16]
In August 2018, the FASB issued ASU 2018-15, Intangibles – Goodwill and Other – Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract.  ASU 2018-15 clarifies certain aspects of ASU 2015-05, Customer’s Accounting for Fees Paid in a Cloud Computing Arrangement. Specifically, ASU 2018-15 aligns the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementations costs incurred to develop or obtain internal use software. The Company adopted ASU 2018-15 on January 1, 2020, retrospectively. The adoption of this standard resulted in a reclassification of $5.6 million from property, plant and equipment to other assets for certain previously capitalized costs related to information technology implementation projects that had not yet been placed in service on the Condensed Consolidated Balance Sheets as of September 30, 2020 and December 31, 2019. There was no impact to previously reported net cash provided by (used in) operations on the statement of cash flows and no impact to the statements of income (loss) as no portion of the capitalized asset was depreciated in prior periods.

[0001564590-20-052017:notes:17]
The following table illustrates the impact of adoption of ASU 2018-15 on the Condensed Consolidated Balance Sheet as of December 31, 2019:

[0001564590-20-052017:notes:18]
[same as prior period, unchanged from 0001564590-20-038237:notes:18]

[0001564590-20-052017:notes:19]
There was no impact upon adoption of ASU 2018-15 on the Condensed Consolidated Statement of Loss for the three and nine months ended September 30, 2019 and the Condensed Consolidated Statement of Cash Flows for nine months ended September 30, 2019 as outlined in the following tables:

[0001564590-20-052017:notes:20]
|  |  | Three months ended September 30, 2019 |  |
| (In thousands) |  | Pre-Adoption |  |  | Effect of Adoption |  |  | As Presented Now |  |
| Condensed Consolidated Statement of Loss |  |  |  |  |  |  |  |  |  |  |  |  |
| Net loss |  | $ | (46,123 | ) |  | $ | — |  |  | $ | (46,123 | ) |

[0001564590-20-052017:notes:21]
|  |  | Nine months ended September 30, 2019 |  |
| (In thousands) |  | Pre-Adoption |  |  | Effect of Adoption |  |  | As Presented Now |  |
| Condensed Consolidated Statement of Loss |  |  |  |  |  |  |  |  |  |  |  |  |
| Net loss |  | $ | (41,358 | ) |  | $ | — |  |  | $ | (41,358 | ) |
| Condensed Consolidated Statement of Cash Flows |  |  |  |  |  |  |  |  |  |  |  |  |
| Net cash provided by operating activities |  | $ | 10,082 |  |  | $ | — |  |  | $ | 10,082 |  |

[0001564590-20-052017:notes:22]
The following table presents the capitalized implementation costs incurred with hosting arrangements, included in other assets on the Condensed Consolidated Balance Sheet, as of September 30, 2020:

[0001564590-20-052017:notes:23]
| (In thousands) |  | September 30, 2020 |  |
| Implementation costs - hosting arrangements |  | $ | 10,455 |  |
| Less: accumulated amortization |  |  | — |  |
| Implementation costs - hosting arrangements, net |  | $ | 10,455 |  |

[0001564590-20-052017:notes:24]
In December 2019, the FASB issued ASU 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes, which simplifies the accounting for income taxes by removing various exceptions, such as the exception to the incremental approach for intra-period tax allocation when there is a loss from continuing operations and income or a gain from other items. The amendments in this update also simplify the accounting for income taxes related to income-based franchise taxes and require that an entity reflect enacted tax laws or rates in the annual effective tax rate computation in the interim period that includes the enactment date. The Company early adopted ASU 2019-12 on April 1, 2020, which was applied on a prospective basis as if the Company adopted the standard on January 1, 2020. The Company early adopted the standard to take advantage of the simplification of rules for income taxes on intra-period tax allocations. Specifically, the adoption of this standard resulted in the recognition of approximately $0.1 million of tax benefit in other comprehensive income (loss), that otherwise would have been recognized in continuing operations had the intra-period tax allocation been completed. There were no other impacts from this standard on the Condensed Consolidated Balance Sheets, Condensed Consolidated Statements of Income (Loss) or Condensed Consolidated Statements of Cash Flows.

[0001564590-20-052017:notes:25]
[same as prior period, unchanged from 0001564590-20-038237:notes:23]

[0001564590-20-052017:notes:26]
In August 2018, the FASB issued ASU 2018-14, Compensation – Retirement Benefits – Defined Benefit Plans – General (Subtopic 715-20): Disclosure Framework – Changes to the Disclosure Requirements for Defined Benefit Plans, which makes changes to and clarifies the disclosure requirements related to defined benefit pension and other postretirement plans. ASU 2018-14 requires additional disclosures related to the reasons for significant gains and losses affecting the benefit obligation and an explanation of any other significant changes in the benefit obligation or plan assets that are not otherwise apparent in other disclosures required by ASC 715. ASU 2018-14 also clarifies the guidance in ASC 715 to require disclosure of the projected benefit obligation (“PBO”) and fair value of plan assets for pension plans with PBOs in excess of plan assets and the accumulated benefit obligation (“ABO”) and fair value of plan assets for pension plans with ABOs in excess of plan assets. ASU 2018-14 is effective for public business entities for fiscal years ending after December 15, 2020. The Company is currently evaluating the impact this guidance will have on its related disclosures.


## us-gaap:CashAndCashEquivalentsDisclosureTextBlock

[0001564590-20-052017:notes:27]
[same as prior period, unchanged from 0001564590-20-038237:notes:25]

[0001564590-20-052017:notes:28]
The following table provides a reconciliation of cash, cash equivalents and restricted cash reported within the Condensed Consolidated Balance Sheet that sum to the total of the same such amounts shown in the Condensed Consolidated Statement of Cash Flows:

[0001564590-20-052017:notes:29]
| (In thousands) |  | September 30, 2020 |  |
| Cash and cash equivalents |  | $ | 71,081 |  |
| Restricted cash |  |  | 322 |  |
| Cash, cash equivalents and restricted cash |  | $ | 71,403 |  |

[0001564590-20-052017:notes:30]
The Company did not have any restricted cash as of December 31, 2019.

[0001564590-20-052017:notes:31]
[same as prior period, unchanged from 0001564590-20-038237:notes:29]


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001564590-20-052017:notes:32]
[same as prior period, unchanged from 0001564590-20-038237:notes:30]

[0001564590-20-052017:notes:33]
[same as prior period, unchanged from 0001564590-20-038237:notes:31]

[0001564590-20-052017:notes:34]
Network Solutions - Includes hardware products and software-defined next-generation virtualized solutions used in service provider or business networks, as well as prior generation products.

[0001564590-20-052017:notes:35]
Services & Support - Includes maintenance, network implementation, solutions integration and managed services, which include hosted cloud services and subscription services.

[0001564590-20-052017:notes:36]
[same as prior period, unchanged from 0001564590-20-038237:notes:34]

[0001564590-20-052017:notes:37]
[same as prior period, unchanged from 0001564590-20-038237:notes:35]

[0001564590-20-052017:notes:38]
The following tables disaggregate revenue by reportable segment and revenue category for the three and nine months ended September 30, 2020 and 2019:

[0001564590-20-052017:notes:39]
|  |  | Three Months Ended |  |
|  |  | September 30, 2020 |  |  | September 30, 2019 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 71,919 |  |  | $ | 13,504 |  |  | $ | 85,423 |  |  | $ | 48,902 |  |  | $ | 16,212 |  |  | $ | 65,114 |  |
| Subscriber Solutions & Experience |  |  | 40,843 |  |  |  | 2,282 |  |  |  | 43,125 |  |  |  | 40,382 |  |  |  | 2,094 |  |  |  | 42,476 |  |
| Traditional & Other Products |  |  | 2,467 |  |  |  | 2,128 |  |  |  | 4,595 |  |  |  | 4,734 |  |  |  | 1,768 |  |  |  | 6,502 |  |
| Total |  | $ | 115,229 |  |  | $ | 17,914 |  |  | $ | 133,143 |  |  | $ | 94,018 |  |  | $ | 20,074 |  |  | $ | 114,092 |  |

[0001564590-20-052017:notes:40]
|  |  | Nine Months Ended |  |
|  |  | September 30, 2020 |  |  | September 30, 2019 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 194,695 |  |  | $ | 39,470 |  |  | $ | 234,165 |  |  | $ | 230,837 |  |  | $ | 43,476 |  |  | $ | 274,313 |  |
| Subscriber Solutions & Experience |  |  | 118,907 |  |  |  | 6,790 |  |  |  | 125,697 |  |  |  | 113,545 |  |  |  | 6,186 |  |  |  | 119,731 |  |
| Traditional & Other Products |  |  | 10,322 |  |  |  | 6,197 |  |  |  | 16,519 |  |  |  | 14,625 |  |  |  | 5,605 |  |  |  | 20,230 |  |
| Total |  | $ | 323,924 |  |  | $ | 52,457 |  |  | $ | 376,381 |  |  | $ | 359,007 |  |  | $ | 55,267 |  |  | $ | 414,274 |  |

[0001564590-20-052017:notes:41]
Revenue allocated to remaining performance obligations represents contract revenue that have not yet been recognized for contracts with a duration of greater than one year. As of September 30, 2020, we did not have any significant performance obligations related to customer contracts that had an original expected duration of one year or more, other than maintenance services, which are satisfied over time. As a practical expedient, for certain contracts we recognize revenue equal to the amounts that we are entitled to invoice, which correspond to the value of completed performance obligations to date. The amount related to these performance obligations was $16.5 million and $13.6 million as of September 30, 2020 and December 31, 2019, respectively. The Company expects to recognize 59% of the $16.5 million as of September 30, 2020 over the next 12 months, with the remainder to be recognized thereafter.

[0001564590-20-052017:notes:42]
[same as prior period, unchanged from 0001564590-20-038237:notes:40]

[0001564590-20-052017:notes:43]
| (In thousands) |  | September 30, 2020 |  |  | December 31, 2019 |  |
| Accounts receivable, net |  | $ | 100,223 |  |  | $ | 90,531 |  |
| Contract assets(1) |  | $ | 1,015 |  |  | $ | 2,812 |  |
| Unearned revenue |  | $ | 13,379 |  |  | $ | 11,963 |  |
| Non-current unearned revenue |  | $ | 6,694 |  |  | $ | 6,012 |  |

[0001564590-20-052017:notes:44]
[same as prior period, unchanged from 0001564590-20-038237:notes:42]

[0001564590-20-052017:notes:45]
Of the outstanding unearned revenue balances as of December 31, 2019 and December 31, 2018, $1.5 million and $1.2 million were recognized as revenue during the three months ended September 30, 2020 and 2019 and $9.6 million and $11.7 million were recognized as revenue during the nine months ended September 30, 2020 and 2019, respectively.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0001564590-20-052017:notes:46]
The table below presents sales information by category for the three and nine months ended September 30, 2020 and 2019:

[0001564590-20-052017:notes:47]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Access & Aggregation |  | $ | 85,423 |  |  | $ | 65,114 |  |  | $ | 234,165 |  |  | $ | 274,313 |  |
| Subscriber Solutions & Experience |  |  | 43,125 |  |  |  | 42,476 |  |  |  | 125,697 |  |  |  | 119,731 |  |
| Traditional & Other Products |  |  | 4,595 |  |  |  | 6,502 |  |  |  | 16,519 |  |  |  | 20,230 |  |
| Total |  | $ | 133,143 |  |  | $ | 114,092 |  |  | $ | 376,381 |  |  | $ | 414,274 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-20-052017:notes:48]
[same as prior period, unchanged from 0001564590-20-038237:notes:46]

[0001564590-20-052017:notes:49]
Our effective tax rate decreased from an expense of 150.6% of pre-tax loss for the three months ended September 30, 2019 to an expense of 9.3% of pre-tax income for the three months ended September 30, 2020 and decreased from an expense of 197.1% of pre-tax loss for the nine months ended September 30, 2019 to a benefit of 36.8% of pre-tax loss for the nine months ended September 30, 2020. The change in the effective tax rate for the three months ended September 30, 2020 was impacted by tax expense in our international operations, offset by additional changes in the valuation allowance related to our domestic operations of $1.0 million and by additional benefits recognized during the quarter of $0.4 million as a result of the Coronavirus Aid, Relief, and Economic Security (“CARES”) Act signed into law on March 27, 2020 in conjunction with the Internal Revenue Service’s release of its final Global Intangible Low Tax Income (“GILTI”) regulations on July 9th, 2020. The change in the effective tax rate for the three and nine months ended September 30, 2019 was primarily driven by the establishment of the valuation allowance against our domestic deferred tax assets in the amount of $37.1 million, with tax expense being offset by a 7.1% rate reduction related to a transfer pricing study completed during the second quarter of 2019 that resulted in the assignment of operating expenditures to specific company locations, and the effective income tax rates among the respective jurisdictions. The decrease in the effective tax rate for the nine months ended September 30, 2020 was primarily driven by a tax benefit of $7.8 million recognized during the nine months ended September 30, 2020 as a result of the CARES Act, which allowed for the carryback of federal net operating losses, partially offset with tax expense in our international operations and changes in our valuation allowance related to our domestic operations. An increase in the valuation allowance against our domestic deferred tax assets was recorded in the amount of $2.6 million during the nine months ended September 30, 2020.

[0001564590-20-052017:notes:50]
The Company continually reviews the adequacy of its valuation allowance and recognizes the benefits of deferred tax assets only as the reassessment indicates that it is more likely than not that the deferred tax assets will be recognized in accordance with ASC 740, Income Taxes. As of September 30, 2020, the Company had deferred tax assets totaling $59.1 million, and a valuation allowance totaling $51.2 million had been established against those deferred tax assets. The remaining $7.9 million in deferred tax assets not offset by a valuation allowance is located in various foreign jurisdictions where the Company believes it is more likely than not we will realize these deferred tax assets. Our assessment of the realizability of our deferred tax assets includes the evaluation of evidence, some of which requires significant judgement, including historical operating results, the evaluation of our three-year cumulative income position, future taxable income projections and tax planning strategies. Should management’s conclusion change in the future and additional valuation allowance or a partial or full release of the valuation allowance is necessary, it could have a material effect on our consolidated financial statements.

[0001564590-20-052017:notes:51]
Supplemental balance sheet information related to deferred tax assets as of September 30, 2020 and December 31, 2019 is as follows:

[0001564590-20-052017:notes:52]
|  |  | September 30, 2020 |  |
| (In thousands) |  | Deferred Tax Assets |  |  | Valuation Allowance |  |  | Deferred Tax Assets, net |  |
| Domestic |  | $ | 49,212 |  |  | $ | (49,212 | ) |  | $ | — |  |
| International |  |  | 9,892 |  |  |  | (2,027 | ) |  |  | 7,865 |  |
| Total |  | $ | 59,104 |  |  | $ | (51,239 | ) |  | $ | 7,865 |  |

[0001564590-20-052017:notes:53]
[same as prior period, unchanged from 0001564590-20-038237:notes:51]


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001564590-20-052017:notes:54]
[same as prior period, unchanged from 0001564590-20-038237:notes:52]

[0001564590-20-052017:notes:55]
The following table summarizes the components of net periodic pension cost related to a defined benefit pension plan covering employees in certain foreign countries for the three and nine months ended September 30, 2020 and 2019:

[0001564590-20-052017:notes:56]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Service cost |  | $ | 325 |  |  | $ | 366 |  |  | $ | 942 |  |  | $ | 1,109 |  |
| Interest cost |  |  | 113 |  |  |  | 158 |  |  |  | 329 |  |  |  | 479 |  |
| Expected return on plan assets |  |  | (429 | ) |  |  | (346 | ) |  |  | (1,246 | ) |  |  | (1,049 | ) |
| Amortization of actuarial losses |  |  | 248 |  |  |  | 198 |  |  |  | 720 |  |  |  | 600 |  |
| Net periodic pension cost |  | $ | 257 |  |  | $ | 376 |  |  | $ | 745 |  |  | $ | 1,139 |  |

[0001564590-20-052017:notes:57]
[same as prior period, unchanged from 0001564590-20-038237:notes:55]


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-20-052017:notes:58]
[same as prior period, unchanged from 0001564590-20-038237:notes:56]

[0001564590-20-052017:notes:59]
The following table summarizes stock-based compensation expense related to stock options, performance stock units (“PSUs”), restricted stock units (“RSUs”) and restricted stock for the three and nine months ended September 30, 2020 and 2019:

[0001564590-20-052017:notes:60]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Stock-based compensation expense included in cost of sales |  | $ | 101 |  |  | $ | 83 |  |  | $ | 303 |  |  | $ | 272 |  |
| Selling, general and administrative expense |  |  | 953 |  |  |  | 1,142 |  |  |  | 2,999 |  |  |  | 2,867 |  |
| Research and development expense |  |  | 556 |  |  |  | 646 |  |  |  | 1,754 |  |  |  | 2,045 |  |
| Stock-based compensation expense included in operating expenses |  |  | 1,509 |  |  |  | 1,788 |  |  |  | 4,753 |  |  |  | 4,912 |  |
| Total stock-based compensation expense |  |  | 1,610 |  |  |  | 1,871 |  |  |  | 5,056 |  |  |  | 5,184 |  |
| Tax benefit for expense associated with stock options, PSUs, RSUs and restricted stock |  |  | (384 | ) |  |  | (446 | ) |  |  | (1,205 | ) |  |  | (1,235 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 1,226 |  |  | $ | 1,425 |  |  | $ | 3,851 |  |  | $ | 3,949 |  |

[0001564590-20-052017:notes:61]
[same as prior period, unchanged from 0001564590-20-038237:notes:59]

[0001564590-20-052017:notes:62]
The following table summarizes PSUs, RSUs and restricted stock outstanding as of December 31, 2019 and September 30, 2020 and the changes that occurred during the nine months ended September 30, 2020.

[0001564590-20-052017:notes:63]
|  |  | Number of Shares (in thousands) |  |  | Weighted Avg. Grant Date Fair Value (per share) |  |
| Unvested PSUs, RSUs and restricted stock outstanding, December 31, 2019 |  |  | 1,891 |  |  | $ | 14.58 |  |
| PSUs, RSUs and restricted stock granted |  |  | 399 |  |  | $ | 8.21 |  |
| PSUs, RSUs and restricted stock vested |  |  | (15 | ) |  | $ | 12.76 |  |
| PSUs, RSUs and restricted stock forfeited |  |  | (586 | ) |  | $ | 18.24 |  |
| Unvested PSUs, RSUs and restricted stock outstanding, September 30, 2020 |  |  | 1,689 |  |  | $ | 11.83 |  |

[0001564590-20-052017:notes:64]
During the nine months ended September 30, 2020, the Company issued 0.3 million performance-based PSUs under the ADTRAN, Inc. 2015 Employee Stock Incentive Plan (the “2015 Employee Plan”) to its executive officers and certain employees. The grant-date fair value of these performance-based awards is based on the closing price of the Company’s stock on the date of grant. Subject to the grantee’s continued employment, the grantee has the ability to earn shares in a range of 0% to 142.8% of the awarded number of PSUs based on the achievement of a defined performance target at the end of a three-year period. If the Company achieves the performance target at the end of the first or second year during the vesting period, the grantee will be entitled to the target number of performance shares, which will not be issued until the end of the three-year period. Equity-based compensation expense with respect to these awards will be adjusted over the vesting period to reflect the probability of achievement of the performance target defined in the award agreements.

[0001564590-20-052017:notes:65]
[same as prior period, unchanged from 0001564590-20-038237:notes:63]

[0001564590-20-052017:notes:66]
As of September 30, 2020, total unrecognized compensation expense related to unvested market-based PSUs, RSUs and restricted stock was approximately $10.6 million, which will be recognized over the remaining weighted-average period of 2.3 years. In addition, there was $2.3 million of unrecognized compensation expense related to unvested 2020 performance-based PSUs, which will be recognized over the remaining requisite service period of 2.3 years if achievement of the performance obligation becomes probable. Unrecognized compensation expense will be adjusted for actual forfeitures.

[0001564590-20-052017:notes:67]
[same as prior period, unchanged from 0001564590-20-038237:notes:65]

[0001564590-20-052017:notes:68]
Under the 2020 Employee Plan, the Company is authorized to issue 2.8 million shares of common stock to certain employees, key service providers and advisors through incentive stock options and non-qualified stock options, stock appreciation rights, RSUs and restricted stock, any of which may be subject to performance-based conditions. Stock options, RSUs and restricted stock granted under the 2020 Employee Plan reduce the shares authorized for issuance under the 2020 Employee Plan by one share of common stock for each share underlying the award. Forfeitures, cancellations or expirations of awards granted under the 2015 Employee Plan increase the shares authorized for issuance under the 2020 Employee Plan, with forfeitures, cancellations or expirations of RSUs and restricted stock increasing the shares authorized for issuance by 2.5 shares of common stock for each share underlying the award. Forfeitures, cancellations or expirations of stock options from the 2015 Employee Plan increase the shares authorized for issuance under the 2020 Employee Plan by one share of common stock for each share underlying the award. RSUs and restricted stock granted under the 2020 Employee Plan will typically vest pursuant to a four-year vesting schedule beginning on the first anniversary of the grant date. Stock options granted under the 2020 Employee Plan will typically become exercisable beginning after one year of continued employment, normally pursuant to a four-year vesting schedule beginning on the first anniversary of the grant date and have a ten-year contractual term.

[0001564590-20-052017:notes:69]
Under the 2020 Directors Plan, the Company is authorized to issue 0.4 million shares of common stock through stock options, restricted stock and RSUs to non-employee directors. Stock awards issued under the 2020 Directors Plan typically will become vested in full on the first anniversary of the grant date. Stock options issued under the 2020 Directors Plan will have a ten-year contractual term. Stock options, restricted stock and RSUs granted under the 2020 Directors Plan reduce the shares authorized for issuance under the 2020 Directors Plan by one share of common stock for each share underlying the award. Forfeitures, cancellations and expirations of awards granted under the 2010 Directors Stock Plan increase the shares authorized for issuance under the 2020 Directors Plan by one share of common stock for each share underlying the award.

[0001564590-20-052017:notes:70]
As of September 30, 2020, 3.6 million shares, including forfeitures to date under the 2015 Employee Plan and the 2010 Directors Stock Plan, were available for issuance under stockholder-approved equity plans.

[0001564590-20-052017:notes:71]
[same as prior period, unchanged from 0001564590-20-038237:notes:69]

[0001564590-20-052017:notes:72]
The following table summarizes stock options outstanding as of December 31, 2019 and September 30, 2020 and the changes that occurred during the nine months ended September 30, 2020:

[0001564590-20-052017:notes:73]
|  |  | Number of Stock Options (in thousands) |  |  | Weighted Avg. Exercise Price (per share) |  |  | Weighted Avg. Remaining Contractual Life (in years) |  |  | Aggregate Intrinsic Value (in thousands) |  |
| Stock options outstanding, December 31, 2019 |  |  | 3,572 |  |  | $ | 22.88 |  |  |  | 3.4 |  |  | $ | — |  |
| Stock options exercised |  |  | — |  |  | $ | — |  |  |  |  |  |  |  |  |  |
| Stock options forfeited |  |  | — |  |  | $ | — |  |  |  |  |  |  |  |  |  |
| Stock options expired |  |  | (352 | ) |  | $ | 21.48 |  |  |  |  |  |  |  |  |  |
| Stock options outstanding, September 30, 2020 |  |  | 3,220 |  |  | $ | 22.94 |  |  |  | 2.7 |  |  | $ | — |  |
| Stock options exercisable, September 30, 2020 |  |  | 3,217 |  |  | $ | 22.95 |  |  |  | 2.7 |  |  | $ | — |  |

[0001564590-20-052017:notes:74]
As of September 30, 2020, total unrecognized compensation expense related to unvested stock options was approximately $1 thousand, which will be recognized over the remaining weighted-average period of 0.1 years. Unrecognized compensation expense will be adjusted for actual forfeitures.

[0001564590-20-052017:notes:75]
There were no stock options granted during the three and nine months ended September 30, 2020 and 2019. All of the options were previously issued at exercise prices that approximated fair market value at the date of grant.

[0001564590-20-052017:notes:76]
The aggregate intrinsic value of stock options represents the total pre-tax intrinsic value (the difference between ADTRAN’s closing stock price on the last trading day of the quarter and the exercise price, multiplied by the number of in-the-money options) that would have been received by the option holders had all option holders exercised their options on September 30, 2020. The amount of aggregate intrinsic value will change based on the fair market value of the Company’s stock and was zero as of September 30, 2020. The total pre-tax intrinsic value of options exercised during the nine months ended September 30, 2020 was zero.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001564590-20-052017:notes:77]
7. INVESTMENTS

[0001564590-20-052017:notes:78]
Debt Securities and Other Investments

[0001564590-20-052017:notes:79]
As of September 30, 2020, the following debt securities and other investments were included on the Condensed Consolidated Balance Sheet and recorded at fair value:

[0001564590-20-052017:notes:80]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 12,861 |  |  | $ | 149 |  |  | $ | — |  |  | $ | 13,010 |  |
| Municipal fixed-rate bonds |  |  | 3,093 |  |  |  | 32 |  |  |  | (1 | ) |  |  | 3,124 |  |
| Asset-backed bonds |  |  | 8,472 |  |  |  | 115 |  |  |  | — |  |  |  | 8,587 |  |
| Mortgage/Agency-backed bonds |  |  | 10,964 |  |  |  | 127 |  |  |  | (11 | ) |  |  | 11,080 |  |
| U.S. government bonds |  |  | 7,096 |  |  |  | 174 |  |  |  | — |  |  |  | 7,270 |  |
| Foreign government bonds |  |  | 1,032 |  |  |  | 3 |  |  |  | — |  |  |  | 1,035 |  |
| Commercial paper |  |  | 324 |  |  |  | 1 |  |  |  | — |  |  |  | 325 |  |
| Variable-rate demand notes |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Other |  |  | 442 |  |  |  | — |  |  |  | — |  |  |  | 442 |  |
| Available-for-sale debt securities held at fair value |  | $ | 44,284 |  |  | $ | 601 |  |  | $ | (12 | ) |  | $ | 44,873 |  |

[0001564590-20-052017:notes:81]
As of December 31, 2019, the following debt securities and other investments were included on the Condensed Consolidated Balance Sheet and recorded at fair value:

[0001564590-20-052017:notes:82]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 9,304 |  |  | $ | 80 |  |  | $ | — |  |  | $ | 9,384 |  |
| Municipal fixed-rate bonds |  |  | 930 |  |  |  | — |  |  |  | — |  |  |  | 930 |  |
| Asset-backed bonds |  |  | 6,867 |  |  |  | 26 |  |  |  | (3 | ) |  |  | 6,890 |  |
| Mortgage/Agency-backed bonds |  |  | 6,944 |  |  |  | 26 |  |  |  | (8 | ) |  |  | 6,962 |  |
| U.S. government bonds |  |  | 12,311 |  |  |  | 21 |  |  |  | (9 | ) |  |  | 12,323 |  |
| Foreign government bonds |  |  | 372 |  |  |  | — |  |  |  | (1 | ) |  |  | 371 |  |
| Variable-rate demand notes |  |  | 800 |  |  |  | — |  |  |  | — |  |  |  | 800 |  |
| Available-for-sale debt securities held at fair value |  | $ | 37,528 |  |  | $ | 153 |  |  | $ | (21 | ) |  | $ | 37,660 |  |

[0001564590-20-052017:notes:83]
As of September 30, 2020, contractual maturities related to debt securities and other investments were as follows:

[0001564590-20-052017:notes:84]
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset- backed bonds |  |  | Mortgage/ Agency- backed bonds |  |  | U.S. government bonds |  |  | Foreign government bonds |  |  | Commercial paper |  |  | Other |  |
| Less than one year |  | $ | 2,900 |  |  | $ | 737 |  |  | $ | 696 |  |  | $ | 208 |  |  | $ | 500 |  |  | $ | 75 |  |  | $ | 325 |  |  | $ | 442 |  |
| One to two years |  |  | 3,752 |  |  |  | 1,183 |  |  |  | 956 |  |  |  | 1,256 |  |  |  | 826 |  |  |  | 463 |  |  |  | — |  |  |  | — |  |
| Two to three years |  |  | 6,122 |  |  |  | 908 |  |  |  | 615 |  |  |  | 2,775 |  |  |  | 5,492 |  |  |  | 497 |  |  |  | — |  |  |  | — |  |
| Three to five years |  |  | 236 |  |  |  | 296 |  |  |  | 4,817 |  |  |  | 1,079 |  |  |  | 452 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Five to ten years |  |  | — |  |  |  | — |  |  |  | 946 |  |  |  | 1,507 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| More than ten years |  |  | — |  |  |  | — |  |  |  | 557 |  |  |  | 4,255 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 13,010 |  |  | $ | 3,124 |  |  | $ | 8,587 |  |  | $ | 11,080 |  |  | $ | 7,270 |  |  | $ | 1,035 |  |  | $ | 325 |  |  | $ | 442 |  |

[0001564590-20-052017:notes:85]
Actual maturities may differ from contractual maturities as some borrowers have the right to call or prepay obligations with or without call or prepayment penalties.

[0001564590-20-052017:notes:86]
Realized gains and losses on sales of debt securities are computed under the specific identification method. The following table presents gross realized gains and losses related to our debt securities:

[0001564590-20-052017:notes:87]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Gross realized gains on debt securities |  | $ | 70 |  |  | $ | 36 |  |  | $ | 303 |  |  | $ | 85 |  |
| Gross realized losses on debt securities |  |  | (6 | ) |  |  | (7 | ) |  |  | (45 | ) |  |  | (40 | ) |
| Total gain recognized, net |  | $ | 64 |  |  | $ | 29 |  |  | $ | 258 |  |  | $ | 45 |  |

[0001564590-20-052017:notes:88]
The Company’s investment policy provides limitations for issuer concentration, which limits, at the time of purchase, the concentration in any one issuer to 5% of the market value of the total investment portfolio. The Company did not purchase any available-for-sale debt security with credit deterioration during the three and nine months ended September 30, 2020.

[0001564590-20-052017:notes:89]
Marketable Equity Securities

[0001564590-20-052017:notes:90]
Our marketable equity securities consist of publicly traded stock, funds and certain other investments measured at fair value or cost, where appropriate.

[0001564590-20-052017:notes:91]
During the three months ended March 31, 2019, an outstanding note receivable of $4.3 million was repaid and reissued in the form of debt and equity. Of the outstanding $4.3 million, $3.4 million was issued as an equity investment, which represented a non-cash investing activity. We elected to record this equity investment that does not have a readily determinable fair value using the measurement alternative. Under the measurement alternative, equity investments that do not have a readily determinable fair value can be recorded at cost less impairment, if any, adjusted for observable price changes for an identical or similar investment. The carrying value of this investment under the measurement alternative was $3.4 million as of December 31, 2019. During the nine months ended September 30, 2020, an impairment charge of $1.6 million was recorded related to this equity investment, which is included in net investment gain (loss) on the Condensed Consolidated Statement of Income (Loss). As a result, the carrying value of this investment was $1.8 million as of September 30, 2020. The remaining amount, $0.9 million of the original $4.3 million note receivable, was reissued as a new note receivable, which is included in long-term investments on the Condensed Consolidated Balance Sheets as of September 30, 2020 and December 31, 2019, and represented a non-cash investing activity during the nine months ended September 30, 2019. No impairment charge was recognized related to the note receivable as it is a secured loan.

[0001564590-20-052017:notes:92]
Realized and unrealized gains and losses related to marketable equity securities for the three and nine months ended September 30, 2020 and 2019 were as follows:

[0001564590-20-052017:notes:93]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Realized gains (losses) on equity securities sold |  | $ | 623 |  |  | $ | (20 | ) |  | $ | (1,485 | ) |  | $ | (83 | ) |
| Unrealized gains (losses) on equity securities held |  |  | 2,157 |  |  |  | (225 | ) |  |  | 3,046 |  |  |  | 8,233 |  |
| Total gain (loss) recognized, net |  | $ | 2,780 |  |  | $ | (245 | ) |  | $ | 1,561 |  |  | $ | 8,150 |  |

[0001564590-20-052017:notes:94]
U.S. GAAP establishes a three-level valuation hierarchy based upon observable and unobservable inputs for fair value measurement of financial instruments:

[0001564590-20-052017:notes:95]
• Level 1 – Observable outputs; values based on unadjusted quoted prices for identical assets or liabilities in an active market;

[0001564590-20-052017:notes:96]
• Level 2 – Significant inputs that are observable; values based on quoted prices in markets that are not active or model inputs that are observable either directly or indirectly;

[0001564590-20-052017:notes:97]
• Level 3 – Significant unobservable inputs; values based on prices or valuation techniques that require inputs that are both unobservable and significant to the overall fair value measurement; inputs could include information supplied by investees.

[0001564590-20-052017:notes:98]
The Company’s cash equivalents and investments held at fair value are categorized into this hierarchy as follows:

[0001564590-20-052017:notes:99]
|  |  |  |  |  |  | Fair Value Measurements as of September 30, 2020 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 636 |  |  | $ | 636 |  |  | $ | — |  |  | $ | — |  |
| U.S. government securities |  |  | 300 |  |  |  | 300 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 13,010 |  |  | — |  |  |  | 13,010 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 3,124 |  |  | — |  |  |  | 3,124 |  |  |  | — |  |
| Asset-backed bonds |  |  | 8,587 |  |  | — |  |  |  | 8,587 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 11,080 |  |  | — |  |  |  | 11,080 |  |  |  | — |  |
| U.S. government bonds |  |  | 7,270 |  |  |  | 7,270 |  |  | — |  |  |  | — |  |
| Foreign government securities |  |  | 1,035 |  |  | — |  |  |  | 1,035 |  |  |  | — |  |
| Commercial paper |  |  | 325 |  |  | — |  |  |  | 325 |  |  |  | — |  |
| Variable-rate demand notes |  |  | — |  |  | — |  |  |  |  |  |  |  | — |  |
| Other |  |  | 442 |  |  | — |  |  | — |  |  |  | 442 |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 13,590 |  |  |  | 13,590 |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 21,595 |  |  |  | 21,595 |  |  | — |  |  |  | — |  |
| Other investments |  |  | 1,276 |  |  |  | 1,276 |  |  | — |  |  |  | — |  |
| Total |  | $ | 82,270 |  |  | $ | 44,667 |  |  | $ | 37,161 |  |  | $ | 442 |  |

[0001564590-20-052017:notes:100]
|  |  |  |  |  |  | Fair Value Measurements as of December 31, 2019 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,309 |  |  | $ | 1,309 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 9,384 |  |  |  | — |  |  |  | 9,384 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 930 |  |  |  | — |  |  |  | 930 |  |  |  | — |  |
| Asset-backed bonds |  |  | 6,890 |  |  |  | — |  |  |  | 6,890 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 6,962 |  |  |  | — |  |  |  | 6,962 |  |  |  | — |  |
| U.S. government bonds |  |  | 12,323 |  |  |  | 12,323 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 371 |  |  |  | — |  |  |  | 371 |  |  |  | — |  |
| Variable-rate demand notes |  |  | 800 |  |  |  | — |  |  |  | 800 |  |  |  | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 35,501 |  |  |  | 35,501 |  |  |  | — |  |  |  | — |  |
| Equity in escrow |  |  | 298 |  |  |  | 298 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 21,698 |  |  |  | 21,698 |  |  |  | — |  |  |  | — |  |
| Other investments |  |  | 2,442 |  |  |  | 2,442 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 98,908 |  |  | $ | 73,571 |  |  | $ | 25,337 |  |  | $ | — |  |

[0001564590-20-052017:notes:101]
The fair value of our Level 2 securities is calculated using a weighted average market price for each security. Market prices are obtained from a variety of industry standard data providers, large financial institutions and other third-party sources. These multiple market prices are used as inputs into a distribution-curve-based algorithm to determine the daily market value of each security.

[0001564590-20-052017:notes:102]
The fair value of Level 3 securities is calculated based on unobservable inputs. Quantitative information with respect to unobservable inputs consists of third-party valuations performed in accordance with ASC 820 – Fair Value Measurement. Inputs used in preparing the third-party valuation included the following assumptions, among others: estimated discount rates and fair market yields.


## us-gaap:InventoryDisclosureTextBlock

[0001564590-20-052017:notes:103]
[same as prior period, unchanged from 0001564590-20-038237:notes:101]

[0001564590-20-052017:notes:104]
As of September 30, 2020 and December 31, 2019, inventory consisted of the following:

[0001564590-20-052017:notes:105]
|  |  | September 30, |  |  | December 31, |  |
| (In thousands) |  | 2020 |  |  | 2019 |  |
| Raw materials |  | $ | 43,418 |  |  | $ | 36,987 |  |
| Work in process |  |  | 1,787 |  |  |  | 1,085 |  |
| Finished goods |  |  | 75,055 |  |  |  | 60,233 |  |
| Total inventory |  | $ | 120,260 |  |  | $ | 98,305 |  |

[0001564590-20-052017:notes:106]
Inventory reserves are established for estimated excess and obsolete inventory equal to the difference between the cost of the inventory and the estimated net realizable value of the inventory based on estimated reserve percentages, which consider historical usage, known trends, inventory age and market conditions. As of September 30, 2020 and December 31, 2019, inventory reserves were $38.0 million and $34.1 million, respectively.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001564590-20-052017:notes:107]
[same as prior period, unchanged from 0001564590-20-038237:notes:105]

[0001564590-20-052017:notes:108]
At September 30, 2020 and December 31, 2019, property, plant and equipment consisted of the following:

[0001564590-20-052017:notes:109]
|  |  | September 30, |  |  | December 31, |  |
| (In thousands) |  | 2020 |  |  | 2019 |  |
| Land |  | $ | 4,575 |  |  | $ | 4,575 |  |
| Building and land improvements |  |  | 35,105 |  |  |  | 34,797 |  |
| Building |  |  | 68,160 |  |  |  | 68,157 |  |
| Furniture and fixtures |  |  | 19,981 |  |  |  | 19,959 |  |
| Computer hardware and software |  |  | 70,766 |  |  |  | 68,777 |  |
| Engineering and other equipment |  |  | 132,672 |  |  |  | 130,430 |  |
| Total property, plant and equipment |  |  | 331,259 |  |  |  | 326,695 |  |
| Less: accumulated depreciation |  |  | (266,906 | ) |  |  | (258,609 | ) |
| Total property, plant and equipment, net |  | $ | 64,353 |  |  | $ | 68,086 |  |

[0001564590-20-052017:notes:110]
Long-lived assets used in operations are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable and the undiscounted cash flows estimated to be generated by the asset are less than the asset’s carrying value. Due to the current economic environment, particularly related to COVID-19, the Company assessed impairment triggers related to long-lived assets during the third quarter of 2020. Based on this assessment, no triggers occurred to perform an impairment test, and no impairment losses of long-lived assets were recorded.

[0001564590-20-052017:notes:111]
Depreciation expense was $3.1 million for both the three months ended September 30, 2020 and 2019, and $9.1 million and $9.3 million for the nine months ended September 30, 2020 and 2019 respectively, which is recorded in cost of sales, selling, general and administrative expenses and research and development expenses in the Condensed Consolidated Statements of Income (Loss).


## us-gaap:GoodwillDisclosureTextBlock

[0001564590-20-052017:notes:112]
[same as prior period, unchanged from 0001564590-20-038237:notes:110]

[0001564590-20-052017:notes:113]
Goodwill was $7.0 million as of September 30, 2020 and December 31, 2019, of which $6.6 million and $0.4 million was allocated to our Network Solutions and Services & Support reportable segments, respectively.

[0001564590-20-052017:notes:114]
The Company evaluates the carrying value of goodwill during the fourth quarter of each year and between annual evaluations if events occur or circumstances change that could more likely than not reduce the fair value of the reporting unit below its carrying amount. Qualitative factors are assessed to determine whether the fair value of the reporting unit to which the goodwill is assigned is less than its carrying amount and recognize an impairment charge for the amount by which the carrying value exceeds the fair value of the reporting unit, if applicable. Due to the current economic environment, particularly related to COVID-19, the Company performed a triggering event assessment, in which no triggers were identified. Therefore, no interim impairment test of goodwill was performed as of September 30, 2020, and no impairment of goodwill was recorded during the three and nine months ended September 30, 2020.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001564590-20-052017:notes:115]
[same as prior period, unchanged from 0001564590-20-038237:notes:113]

[0001564590-20-052017:notes:116]
Intangible assets as of September 30, 2020 and December 31, 2019 consisted of the following:

[0001564590-20-052017:notes:117]
|  |  | September 30, 2020 |  |  | December 31, 2019 |  |
| (In thousands) |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Net Book Value |  |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Net Book Value |  |
| Customer relationships |  | $ | 20,931 |  |  | $ | (7,369 | ) |  | $ | 13,562 |  |  | $ | 22,356 |  |  | $ | (7,233 | ) |  | $ | 15,123 |  |
| Developed technology |  |  | 8,200 |  |  |  | (2,262 | ) |  |  | 5,938 |  |  |  | 10,170 |  |  |  | (3,379 | ) |  |  | 6,791 |  |
| Licensed technology |  |  | 5,900 |  |  |  | (1,666 | ) |  |  | 4,234 |  |  |  | 5,900 |  |  |  | (1,174 | ) |  |  | 4,726 |  |
| Supplier relationships |  |  | 2,800 |  |  |  | (2,800 | ) |  |  | — |  |  |  | 2,800 |  |  |  | (2,508 | ) |  |  | 292 |  |
| Licensing agreements |  |  | 560 |  |  |  | (134 | ) |  |  | 426 |  |  |  | 560 |  |  |  | (79 | ) |  |  | 481 |  |
| Patents |  |  | 500 |  |  |  | (277 | ) |  |  | 223 |  |  |  | 500 |  |  |  | (226 | ) |  |  | 274 |  |
| Trade names |  |  | 210 |  |  |  | (128 | ) |  |  | 82 |  |  |  | 310 |  |  |  | (176 | ) |  |  | 134 |  |
| Total |  | $ | 39,101 |  |  | $ | (14,636 | ) |  | $ | 24,465 |  |  | $ | 42,596 |  |  | $ | (14,775 | ) |  | $ | 27,821 |  |

[0001564590-20-052017:notes:118]
The Company evaluates the carrying value of intangible assets whenever events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable and the undiscounted cash flows estimated to be generated by the asset are less than the asset’s carrying value. Due to the current economic environment, particularly related to COVID-19, the Company assessed impairment triggers related to intangible assets during the third quarter of 2020. Based on this assessment, no triggers occurred to perform an impairment test, and no impairment losses of intangible assets were recorded during the three and nine months ended September 30, 2020.

[0001564590-20-052017:notes:119]
Amortization expense was $1.0 million and $1.3 million for the three months ended September 30, 2020 and 2019, respectively, and $3.4 million and $4.0 million for the nine months ended September 30, 2020 and 2019, respectively, and was included in cost of sales, selling, general and administrative expenses and research and development expenses in the Condensed Consolidated Statements of Income (Loss).

[0001564590-20-052017:notes:120]
As of September 30, 2020, estimated future amortization expense of intangible assets was as follows:

[0001564590-20-052017:notes:121]
| (In thousands) |  |  |  |  |
| 2020 |  | $ | 1,041 |  |
| 2021 |  |  | 4,107 |  |
| 2022 |  |  | 3,482 |  |
| 2023 |  |  | 3,330 |  |
| 2024 |  |  | 3,236 |  |
| Thereafter |  |  | 9,269 |  |
| Total |  | $ | 24,465 |  |


## adtn:LeasesDisclosureTextBlock

[0001564590-20-052017:notes:122]
[same as prior period, unchanged from 0001564590-20-038237:notes:120]

[0001564590-20-052017:notes:123]
[same as prior period, unchanged from 0001564590-20-038237:notes:121]

[0001564590-20-052017:notes:124]
The Company’s operating leases consist of office space, automobiles and various other equipment in the U.S. and in certain international locations in which we do business. Other contracts, such as manufacturing agreements and service agreements, are reviewed to determine if they contain any embedded leases. As of September 30, 2020, the Company’s operating leases had remaining lease terms of one month to five years, some of which include options to extend the leases for up to nine years, and some of which include options to terminate the leases within three months. As of September 30, 2020 and December 31, 2019, the Company’s operating lease assets and operating lease liabilities were as follows:

[0001564590-20-052017:notes:125]
| (In thousands) |  | Classification |  | September 30, 2020 |  |  | December 31, 2019 |  |
| Assets |  |  |  |  |  |  |  |  |  |  |
| Operating lease asset |  | Other assets |  | $ | 5,503 |  |  | $ | 8,452 |  |
| Total lease asset |  |  |  | $ | 5,503 |  |  | $ | 8,452 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |
| Current operating lease liability |  | Accrued expenses |  | $ | 1,731 |  |  | $ | 2,676 |  |
| Non-current operating lease liability |  | Other non-current liabilities |  |  | 3,788 |  |  |  | 5,818 |  |
| Total lease liability |  |  |  | $ | 5,519 |  |  | $ | 8,494 |  |

[0001564590-20-052017:notes:126]
Lease expense related to short-term leases (initial term of less than 12 months) was $6 thousand and $0.1 million for the three months ended September 30, 2020 and 2019, respectively, and was $20 thousand and $0.3 million for the nine months ended September 30, 2020 and 2019, respectively, and was included in cost of sales, selling, general and administrative expenses and research and development expenses in the Condensed Consolidated Statements of Income (Loss). Lease expense related to variable lease payments that do not depend on an index or rate, such as real estate taxes and insurance reimbursements, was $0.1 million and $0.3 million for the three months ended September 30, 2020 and 2019, respectively and was $0.4 million and $0.7 million for the nine months ended September 30, 2020 and 2019, respectively.

[0001564590-20-052017:notes:127]
Components of lease expense included in the Condensed Consolidated Statements of Income (Loss) for the three and nine months ended September 30, 2020 and 2019 were as follows:

[0001564590-20-052017:notes:128]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Cost of sales |  | $ | 21 |  |  | $ | 16 |  |  | $ | 68 |  |  | $ | 49 |  |
| Selling, general and administrative expenses |  |  | 265 |  |  |  | 352 |  |  |  | 863 |  |  |  | 1,050 |  |
| Research and development expenses |  |  | 368 |  |  |  | 847 |  |  |  | 1,044 |  |  |  | 1,731 |  |
| Total operating lease expense |  | $ | 654 |  |  | $ | 1,215 |  |  | $ | 1,975 |  |  | $ | 2,830 |  |

[0001564590-20-052017:notes:129]
As of September 30, 2020 and December 31, 2019, operating lease liabilities included on the Condensed Consolidated Balance Sheets by future maturity were as follows:

[0001564590-20-052017:notes:130]
| (In thousands) |  | September 30, 2020 |  |  | December 31, 2019 |  |
| 2020 |  | $ | 518 |  |  | $ | 2,856 |  |
| 2021 |  |  | 1,744 |  |  |  | 2,412 |  |
| 2022 |  |  | 1,514 |  |  |  | 1,705 |  |
| 2023 |  |  | 1,180 |  |  |  | 1,160 |  |
| 2024 |  |  | 499 |  |  |  | 482 |  |
| Thereafter |  |  | 276 |  |  |  | 264 |  |
| Total lease payments |  |  | 5,731 |  |  |  | 8,879 |  |
| Less: Interest |  |  | (212 | ) |  |  | (385 | ) |
| Present value of lease liabilities |  | $ | 5,519 |  |  | $ | 8,494 |  |

[0001564590-20-052017:notes:131]
Future operating lease payments include $0.3 million related to options to extend lease terms that are reasonably certain of being exercised. There are no legally binding leases that have not yet commenced.

[0001564590-20-052017:notes:132]
An incremental borrowing rate is used based on information available at the commencement date in determining the present value of lease payments. The incremental borrowing rate was determined on a portfolio basis by grouping leases with similar terms as well as grouping leases based on a U.S. dollar or Euro functional currency. The actual rate is then determined based on a credit spread over LIBOR as well as the Bloomberg Curve Matrix for the U.S. Communications section. The following table provides information about the weighted average lease terms and weighted average discount rates as of September 30, 2020 and December 31, 2019:

[0001564590-20-052017:notes:133]
|  |  | As of September 30, 2020 |  |  | As of December 31, 2019 |  |
| Weighted average remaining lease term (in years) |  |  |  |  |  |  |  |  |
| Operating leases with USD functional currency |  |  | 2.6 |  |  |  | 2.6 |  |
| Operating leases with Euro functional currency |  |  | 3.8 |  |  |  | 4.4 |  |
| Weighted average discount rate |  |  |  |  |  |  |  |  |
| Operating leases with USD functional currency |  |  | 4.50 | % |  |  | 4.02 | % |
| Operating leases with Euro functional currency |  |  | 1.81 | % |  |  | 1.84 | % |

[0001564590-20-052017:notes:134]
[same as prior period, unchanged from 0001564590-20-038237:notes:132]

[0001564590-20-052017:notes:135]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Cash paid for amounts included in the measurement of operating lease assets / liabilities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Cash used in operating activities related to operating leases |  | $ | 582 |  |  | $ | 775 |  |  | $ | 2,059 |  |  | $ | 2,383 |  |
| Right-of-use assets obtained in exchange for lease obligations |  | $ | 138 |  |  | $ | 11,022 |  |  | $ | 231 |  |  | $ | 21,418 |  |

[0001564590-20-052017:notes:136]
[same as prior period, unchanged from 0001564590-20-038237:notes:134]

[0001564590-20-052017:notes:137]
We are the lessor in sales-type lease arrangements for network equipment, which have initial terms of up to five years, and consisted of the following as of September 30, 2020 and December 31, 2019:

[0001564590-20-052017:notes:138]
| (In thousands) |  | September 30, 2020 |  |  | December 31, 2019 |  |
| Current minimum lease payments receivable(1) |  | $ | 811 |  |  | $ | 1,201 |  |
| Non-current minimum lease payments receivable(2) |  |  | 450 |  |  |  | 889 |  |
| Total minimum lease payments receivable |  |  | 1,261 |  |  |  | 2,090 |  |
| Less: Current unearned revenue |  |  | 235 |  |  |  | 365 |  |
| Less: Non-current unearned revenue |  |  | 70 |  |  |  | 163 |  |
| Net investment in sales-type leases |  | $ | 956 |  |  | $ | 1,562 |  |

[0001564590-20-052017:notes:139]
[same as prior period, unchanged from 0001564590-20-038237:notes:137]

[0001564590-20-052017:notes:140]
Components of gross profit related to sales-type leases recognized at the lease commencement date and interest and dividend income included in the Condensed Consolidated Statements of Income (Loss) for the three and nine months ended September 30, 2020 and 2019 were as follows:

[0001564590-20-052017:notes:141]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Sales - Network Solutions |  | $ | 22 |  |  | $ | 47 |  |  | $ | 72 |  |  | $ | 1,668 |  |
| Less: Cost of sales - Network Solutions |  |  | 9 |  |  |  | 25 |  |  |  | 29 |  |  |  | 660 |  |
| Gross profit |  | $ | 13 |  |  | $ | 22 |  |  | $ | 43 |  |  | $ | 1,008 |  |
| Interest and dividend income |  | $ | 10 |  |  | $ | 92 |  |  | $ | 34 |  |  | $ | 278 |  |


## adtn:IndustrialDevelopmentAuthorityFinancingAndEconomicIncentivesTextBlock

[0001564590-20-052017:notes:142]
[same as prior period, unchanged from 0001564590-20-038237:notes:140]

[0001564590-20-052017:notes:143]
[same as prior period, unchanged from 0001564590-20-038237:notes:141]


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001564590-20-052017:notes:144]
[same as prior period, unchanged from 0001564590-20-038237:notes:142]

[0001564590-20-052017:notes:145]
[same as prior period, unchanged from 0001564590-20-038237:notes:143]

[0001564590-20-052017:notes:146]
Since 1997, the Company’s Board of Directors has approved multiple share repurchase programs that have authorized repurchases of its common stock, which are implemented through open market or private purchases from time to time as conditions warrant. During the nine months ended September 30, 2020, we did not repurchase shares of our common stock. As of September 30, 2020, we had the authority to purchase an additional 2.5 million shares of our common stock under the current authorization of up to 5.0 million shares.

[0001564590-20-052017:notes:147]
[same as prior period, unchanged from 0001564590-20-038237:notes:145]

[0001564590-20-052017:notes:148]
The following tables present the changes in accumulated other comprehensive income (loss), net of tax, by component for the three months ended September 30, 2020 and 2019:

[0001564590-20-052017:notes:149]
|  |  | Three Months Ended September 30, 2020 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | ASU 2018-02 Adoption (1) |  |  | Total |  |
| As of June 30, 2020 |  | $ | 206 |  |  | $ | (8,894 | ) |  | $ | (7,043 | ) |  | $ | 385 |  |  | $ | (15,346 | ) |
| Other comprehensive income before reclassifications |  |  | 494 |  |  |  | — |  |  |  | 2,469 |  |  |  | — |  |  |  | 2,963 |  |
| Amounts reclassified from accumulated other comprehensive income (loss) |  |  | (539 | ) |  |  | 244 |  |  |  | — |  |  |  | — |  |  |  | (295 | ) |
| Net current period other comprehensive income |  |  | (45 | ) |  |  | 244 |  |  |  | 2,469 |  |  |  | — |  |  |  | 2,668 |  |
| As of September 30, 2020 |  | $ | 161 |  |  | $ | (8,650 | ) |  | $ | (4,574 | ) |  | $ | 385 |  |  | $ | (12,678 | ) |

[0001564590-20-052017:notes:150]
|  |  | Three Months Ended September 30, 2019 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | ASU 2018-02 Adoption (1) |  |  | Total |  |
| As of June 30, 2019 |  | $ | (271 | ) |  | $ | (7,770 | ) |  | $ | (6,439 | ) |  | $ | 385 |  |  | $ | (14,095 | ) |
| Other comprehensive income before reclassifications |  |  | (39 | ) |  |  | — |  |  |  | (2,486 | ) |  |  | — |  |  |  | (2,525 | ) |
| Amounts reclassified from accumulated other comprehensive income (loss) |  |  | 24 |  |  |  | 90 |  |  |  | — |  |  |  | — |  |  |  | 114 |  |
| Net current period other comprehensive income |  |  | (15 | ) |  |  | 90 |  |  |  | (2,486 | ) |  |  | — |  |  |  | (2,411 | ) |
| As of September 30, 2019 |  | $ | (286 | ) |  | $ | (7,680 | ) |  | $ | (8,925 | ) |  | $ | 385 |  |  | $ | (16,506 | ) |

[0001564590-20-052017:notes:151]
|  | (1) | With the adoption of ASU 2018-02 on January 1, 2019, stranded tax effects related to the Tax Cuts and Jobs Act of 2017 were reclassified to retained earnings. |

[0001564590-20-052017:notes:152]
The following tables present the changes in accumulated other comprehensive income (loss), net of tax, by component for the nine months ended September 30, 2020 and 2019:

[0001564590-20-052017:notes:153]
|  |  | Nine Months Ended September 30, 2020 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | ASU 2018-02 Adoption(1) |  |  | Total |  |
| As of December 31, 2019 |  | $ | (284 | ) |  | $ | (9,226 | ) |  | $ | (7,292 | ) |  | $ | 385 |  |  | $ | (16,417 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | 444 |  |  |  | — |  |  |  | 2,718 |  |  |  | — |  |  |  | 3,162 |  |
| Amounts reclassified from accumulated other comprehensive income |  |  | 1 |  |  |  | 576 |  |  |  | — |  |  |  | — |  |  |  | 577 |  |
| Net current period other comprehensive income |  |  | 445 |  |  |  | 576 |  |  |  | 2,718 |  |  |  | — |  |  |  | 3,739 |  |
| As of September 30, 2020 |  | $ | 161 |  |  | $ | (8,650 | ) |  | $ | (4,574 | ) |  | $ | 385 |  |  | $ | (12,678 | ) |

[0001564590-20-052017:notes:154]
|  |  | Nine Months Ended September 30, 2019 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | ASU 2018-02 Adoption (1) |  |  | Total |  |
| As of December 31, 2018 |  | $ | (563 | ) |  | $ | (8,041 | ) |  | $ | (5,812 | ) |  | $ | — |  |  | $ | (14,416 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | 372 |  |  |  | — |  |  |  | (3,113 | ) |  |  | — |  |  |  | (2,741 | ) |
| Amounts reclassified from accumulated other comprehensive income (loss) |  |  | (95 | ) |  |  | 361 |  |  |  | — |  |  |  | — |  |  |  | 266 |  |
| Amounts reclassified to retained earnings (1) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 385 |  |  |  | 385 |  |
| Net current period other comprehensive income (loss) |  |  | 277 |  |  |  | 361 |  |  |  | (3,113 | ) |  |  | 385 |  |  |  | (2,090 | ) |
| As of September 30, 2019 |  | $ | (286 | ) |  | $ | (7,680 | ) |  | $ | (8,925 | ) |  | $ | 385 |  |  | $ | (16,506 | ) |

[0001564590-20-052017:notes:155]
The following tables present the details of reclassifications out of accumulated other comprehensive income (loss) for the three months ended September 30, 2020 and 2019:

[0001564590-20-052017:notes:156]
|  |  | Three Months Ended September 30, 2020 |
| (In thousands) |  | Amount Reclassified from Accumulated Other Comprehensive Income (Loss) |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for-sale securities: |  |  |  |  |  |  |
| Net realized gains on sales of securities |  | $ | 728 |  |  | Net investment gain (loss) |
| Defined benefit plan adjustments – actuarial losses |  |  | (354 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | 374 |  |  |  |
| Tax expense |  |  | (79 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 295 |  |  |  |

[0001564590-20-052017:notes:157]
[same as prior period, unchanged from 0001564590-20-038237:notes:155]

[0001564590-20-052017:notes:158]
|  |  | Three Months Ended September 30, 2019 |
| (In thousands) |  | Amount Reclassified from Accumulated Other Comprehensive Income (Loss) |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for-sale securities: |  |  |  |  |  |  |
| Net realized losses on sales of securities |  | $ | (32 | ) |  | Net investment gain (loss) |
| Defined benefit plan adjustments – actuarial losses |  |  | (130 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | (162 | ) |  |  |
| Tax benefit |  |  | 48 |  |  |  |
| Total reclassifications for the period, net of tax |  | $ | (114 | ) |  |  |

[0001564590-20-052017:notes:159]
The following tables present the details of reclassifications out of accumulated other comprehensive loss for the nine months ended September 30, 2020 and 2019:

[0001564590-20-052017:notes:160]
|  |  | Nine Months Ended September 30, 2020 |
| (In thousands) |  | Amount Reclassified from Accumulated Other Comprehensive Income (Loss) |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for-sale securities: |  |  |  |  |  |  |
| Net realized losses on sales of securities |  | $ | (1 | ) |  | Net investment gain (loss) |
| Defined benefit plan adjustments – actuarial losses |  |  | (835 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | (836 | ) |  |  |
| Tax benefit |  |  | 259 |  |  |  |
| Total reclassifications for the period, net of tax |  | $ | (577 | ) |  |  |

[0001564590-20-052017:notes:161]
|  |  | Nine Months Ended September 30, 2019 |
| (In thousands) |  | Amount Reclassified from Accumulated Other Comprehensive Income (Loss) |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains on available-for-sale securities: |  |  |  |  |  |  |
| Net realized gains on sales of securities |  | $ | 128 |  |  | Net investment gain (loss) |
| Defined benefit plan adjustments – actuarial losses |  |  | (523 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | (395 | ) |  |  |
| Tax benefit |  |  | 129 |  |  |  |
| Total reclassifications for the period, net of tax |  | $ | (266 | ) |  |  |

[0001564590-20-052017:notes:162]
The following table presents the tax effects related to the change in each component of other comprehensive loss for the three months ended September 30, 2020 and 2019:

[0001564590-20-052017:notes:163]
|  |  | Three Months Ended |  |  | Three Months Ended |  |
|  |  | September 30, 2020 |  |  | September 30, 2019 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |
| Unrealized gain on available-for-sale securities |  | $ | 668 |  |  | $ | (174 | ) |  | $ | 494 |  |  | $ | (53 | ) |  | $ | 14 |  |  | $ | (39 | ) |
| Reclassification adjustment for amounts related to available-for-sale investments included in net income (loss) |  |  | (728 | ) |  |  | 189 |  |  |  | (539 | ) |  |  | 32 |  |  |  | (8 | ) |  |  | 24 |  |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net income (loss) |  |  | 354 |  |  |  | (110 | ) |  |  | 244 |  |  |  | 130 |  |  |  | (40 | ) |  |  | 90 |  |
| Foreign currency translation adjustment |  |  | 2,469 |  |  |  | — |  |  |  | 2,469 |  |  |  | (2,486 | ) |  |  | — |  |  |  | (2,486 | ) |
| Total Other Comprehensive Income (Loss) |  | $ | 2,763 |  |  | $ | (95 | ) |  | $ | 2,668 |  |  | $ | (2,377 | ) |  | $ | (34 | ) |  | $ | (2,411 | ) |

[0001564590-20-052017:notes:164]
The following table presents the tax effects related to the change in each component of other comprehensive income (loss) for the nine months ended September 30, 2020 and 2019:

[0001564590-20-052017:notes:165]
|  |  | Nine Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, 2020 |  |  | September 30, 2019 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |
| Unrealized gain (loss) on available-for-sale securities |  | $ | 600 |  |  | $ | (156 | ) |  | $ | 444 |  |  | $ | 503 |  |  | $ | (131 | ) |  | $ | 372 |  |
| Reclassification adjustment for amounts related to available-for-sale investments included in net income (loss) |  |  | 1 |  |  |  | — |  |  |  | 1 |  |  |  | (128 | ) |  |  | 33 |  |  |  | (95 | ) |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net income (loss) |  |  | 835 |  |  |  | (259 | ) |  |  | 576 |  |  |  | 523 |  |  |  | (162 | ) |  |  | 361 |  |
| Foreign currency translation adjustment |  |  | 2,718 |  |  |  | — |  |  |  | 2,718 |  |  |  | (3,113 | ) |  |  | — |  |  |  | (3,113 | ) |
| Total Other Comprehensive Income (Loss) |  | $ | 4,154 |  |  | $ | (415 | ) |  | $ | 3,739 |  |  | $ | (2,215 | ) |  | $ | (260 | ) |  | $ | (2,475 | ) |


## us-gaap:EarningsPerShareTextBlock

[0001564590-20-052017:notes:166]
[same as prior period, unchanged from 0001564590-20-038237:notes:164]

[0001564590-20-052017:notes:167]
A summary of the calculation of basic and diluted earnings (loss) per share for the three and nine months ended September 30, 2020 and 2019 is as follows:

[0001564590-20-052017:notes:168]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands, except per share amounts) |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Numerator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) |  | $ | 5,481 |  |  | $ | (46,123 | ) |  | $ | (3,736 | ) |  | $ | (41,358 | ) |
| Denominator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average number of shares – basic |  |  | 47,957 |  |  |  | 47,824 |  |  |  | 47,957 |  |  |  | 47,803 |  |
| Effect of dilutive securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PSUs, RSUs and restricted stock |  |  | 467 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Weighted average number of shares – diluted |  |  | 48,424 |  |  |  | 47,824 |  |  |  | 47,957 |  |  |  | 47,803 |  |
| Earnings (loss) per share – basic |  | $ | 0.11 |  |  | $ | (0.96 | ) |  | $ | (0.08 | ) |  | $ | (0.87 | ) |
| Earnings (loss) per share – diluted |  | $ | 0.11 |  |  | $ | (0.96 | ) |  | $ | (0.08 | ) |  | $ | (0.87 | ) |

[0001564590-20-052017:notes:169]
For the three months ended September 30, 2020 and 2019, 18 thousand and 0.1 million shares, respectively, and for the nine months ended September 30, 2020 and 2019, 0.1 million shares, of unvested or unearned, as applicable, PSUs, RSUs and restricted stock were excluded from the calculation of diluted earnings per share due to their anti-dilutive effect.

[0001564590-20-052017:notes:170]
For the three months ended September 30, 2020 and 2019, 3.4 million and 3.9 million stock options, respectively, and for the nine months ended September 30, 2020 and 2019, 4.3 million and 2.8 million stock options, respectively, were outstanding but were not included in the computation of diluted earnings per share. These stock options were excluded because their exercise prices were greater than the average market price of the common shares during the quarter, making them anti-dilutive under the treasury stock method.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-20-052017:notes:171]
[same as prior period, unchanged from 0001564590-20-038237:notes:169]

[0001564590-20-052017:notes:172]
The chief operating decision maker regularly reviews the Company’s financial performance based on two reportable segments: (1) Network Solutions and (2) Services & Support. Network Solutions includes hardware products and software defined next-generation virtualized solutions used in service provider or business networks, as well as prior-generation products. Services & Support includes a portfolio of maintenance, network implementation and solutions integration and managed services, which include hosted cloud services and subscription services.

[0001564590-20-052017:notes:173]
The performance of our segments is evaluated based on gross profit; therefore, selling, general and administrative expenses, research and development expenses, interest and dividend income, interest expense, net investment gain (loss), other income (expense) and income tax (expense) benefit are reported on a Company-wide basis only. There is no inter-segment revenue. Asset information by reportable segment is not produced and, therefore, is not reported.

[0001564590-20-052017:notes:174]
The following tables present information about the sales and gross profit of our reportable segments for the three and nine months ended September 30, 2020 and 2019.

[0001564590-20-052017:notes:175]
|  |  | Three Months Ended |  |
|  |  | September 30, 2020 |  |  | September 30, 2019 |  |
| (In thousands) |  | Sales |  |  | Gross Profit |  |  | Sales |  |  | Gross Profit |  |
| Network Solutions |  | $ | 115,229 |  |  | $ | 52,434 |  |  | $ | 94,018 |  |  | $ | 37,574 |  |
| Services & Support |  |  | 17,914 |  |  |  | 6,528 |  |  |  | 20,074 |  |  |  | 8,757 |  |
| Total |  | $ | 133,143 |  |  | $ | 58,962 |  |  | $ | 114,092 |  |  | $ | 46,331 |  |

[0001564590-20-052017:notes:176]
|  |  | Nine Months Ended |  |
|  |  | September 30, 2020 |  |  | September 30, 2019 |  |
| (In thousands) |  | Sales |  |  | Gross Profit |  |  | Sales |  |  | Gross Profit |  |
| Network Solutions |  | $ | 323,924 |  |  | $ | 145,432 |  |  | $ | 359,007 |  |  | $ | 151,654 |  |
| Services & Support |  |  | 52,457 |  |  |  | 18,602 |  |  |  | 55,267 |  |  |  | 20,304 |  |
| Total |  | $ | 376,381 |  |  | $ | 164,034 |  |  | $ | 414,274 |  |  | $ | 171,958 |  |

[0001564590-20-052017:notes:177]
[same as prior period, unchanged from 0001564590-20-038237:notes:176]

[0001564590-20-052017:notes:178]
The following table presents sales information by geographic area for the three and nine months ended September 30, 2020 and 2019:

[0001564590-20-052017:notes:179]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| United States |  | $ | 92,838 |  |  | $ | 83,144 |  |  | $ | 256,287 |  |  | $ | 230,960 |  |
| International |  |  | 40,305 |  |  |  | 30,948 |  |  |  | 120,094 |  |  |  | 183,314 |  |
| Total |  | $ | 133,143 |  |  | $ | 114,092 |  |  | $ | 376,381 |  |  | $ | 414,274 |  |


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001564590-20-052017:notes:180]
[same as prior period, unchanged from 0001564590-20-038237:notes:179]

[0001564590-20-052017:notes:181]
Our products generally include warranties of 90 days to five years for product defects. Warranty returns are accrued at the time revenue is recognized based on an estimate of the cost to repair or replace the defective products. We engage in extensive product quality programs and processes, including actively monitoring and evaluating the quality of our component suppliers. Products continue to become more complex in both size and functionality as many of our product offerings migrate from line card applications to total systems. The increasing complexity of products will cause warranty incidences, when they arise, to be more costly. Estimates regarding future warranty obligations may change due to product failure rates, material usage and other rework costs incurred in correcting a product failure. In addition, from time to time, specific warranty accruals may be recorded if unforeseen problems arise. Should actual experience relative to these factors be worse than estimated, additional warranty expense will be incurred. Alternatively, if actual costs incurred are less than estimated, a portion of the warranty reserves will be reversed in future periods. The liability for warranty obligations totaled $7.2 million and $8.4 million as of September 30, 2020 and December 31, 2019, respectively, and are included in accrued expenses and other liabilities in the accompanying Condensed Consolidated Balance Sheets.

[0001564590-20-052017:notes:182]
A reconciliation of warranty expense and related write-off activity for the three and nine months ended September 30, 2020 and 2019 is as follows:

[0001564590-20-052017:notes:183]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Balance at beginning of period |  | $ | 7,294 |  |  | $ | 8,972 |  |  | $ | 8,394 |  |  | $ | 8,623 |  |
| Plus: Amounts charged to cost and expenses |  |  | 632 |  |  |  | 816 |  |  |  | 970 |  |  |  | 3,796 |  |
| Less: Deductions |  |  | (734 | ) |  |  | (1,131 | ) |  |  | (2,172 | ) |  |  | (3,762 | ) |
| Balance at end of period |  | $ | 7,192 |  |  | $ | 8,657 |  |  | $ | 7,192 |  |  | $ | 8,657 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-20-052017:notes:184]
18. COMMITMENTS AND CONTINGENCIES

[0001564590-20-052017:notes:185]
Securities Class Action Lawsuit

[0001564590-20-052017:notes:186]
On October 17, 2019, a purported stockholder class action lawsuit, captioned Burbridge v. ADTRAN, Inc. et al., Docket No. 19-cv-09619, was filed in the United States District Court for the Southern District of New York against the Company, two of its current executive officers and one of its former executive officers. The complaint alleges violations of federal securities laws and seeks unspecified compensatory damages on behalf of purported purchasers of ADTRAN securities between February 28, 2019 and October 9, 2019. The lawsuit claims that the defendants made materially false and misleading statements regarding, and/or failed to disclose material adverse facts about, the Company’s business, operations and prospects, specifically relating to the Company’s internal control over financial reporting, excess and obsolete inventory reserves, financial results and demand from certain customers. The lawsuit was transferred to the U.S. District Court for the Northern District of Alabama on January 7, 2020, and co-lead plaintiffs have been appointed to represent the putative class. The plaintiffs filed an amended complaint on April 30, 2020. The defendants filed a motion to dismiss the amended complaint on June 17, 2020. The plaintiffs filed an opposition brief to the defendants’ motion to dismiss on July 17, 2020. The defendants filed a reply to the plaintiffs’ brief on August 17, 2020. The motion to dismiss remains under review by the Court. We deny the allegations in the complaint, as amended, and intend to vigorously defend against this lawsuit. At this time, we are unable to predict the outcome of or estimate the possible loss or range of loss, if any, associated with this lawsuit.

[0001564590-20-052017:notes:187]
Shareholder Derivative Lawsuit

[0001564590-20-052017:notes:188]
On March 31, 2020, a shareholder derivative suit, captioned Johnson (Derivatively on behalf of ADTRAN) v. T. Stanton, M. Foliano, R. Shannon, and Board of Directors, case no. 5:20-cv-00447, was filed in the U.S. District Court of Northern Alabama against two of the Company’s current executive officers, one of its former executive officers and its Board of Directors. The derivative suit, which is purportedly brought on behalf of ADTRAN, makes similar allegations as the shareholder class action and accuses the directors and officers of breaches of fiduciary duty in connection with those allegations. On June 7, 2020, the Court entered an order staying the derivative litigation pending resolution of the motion to dismiss in the securities class action. The Company and its defendants disagree with the claims made in the complaint, and the defendants intend to vigorously defend against this lawsuit. At this time, we are unable to predict the outcome of or estimate the possible loss or range of loss, if any, associated with this lawsuit.

[0001564590-20-052017:notes:189]
Other Legal Matters

[0001564590-20-052017:notes:190]
In addition to the litigation described above, from time to time we are subject to or otherwise involved in various lawsuits, claims, investigations and legal proceedings that arise out of or are incidental to the conduct of our business (collectively, “Legal Matters”), including those relating to employment matters, patent rights, regulatory compliance matters, stockholder claims, and contractual and other commercial disputes. Such Legal Matters, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Additionally, an unfavorable outcome in any legal matter, including in a patent dispute, could require the Company to pay damages, entitle claimants to other relief, such as royalties, or could prevent the Company from selling some of its products in certain jurisdictions. While the Company cannot predict with certainty the results of the Legal Matters in which it is currently involved, the Company does not expect that the ultimate outcome of such Legal Matters will individually or in the aggregate have a material adverse effect on its business, results of operations, financial condition or cash flows.

[0001564590-20-052017:notes:191]
Performance Bonds

[0001564590-20-052017:notes:192]
Certain contracts, customers and jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of September 30, 2020 and December 31, 2019, we had commitments related to these bonds totaling $12.0 million and $9.3 million, respectively, which expire at various dates through August 2024. Although the triggering events vary from contract to contract, in general we would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which we believe is remote.

[0001564590-20-052017:notes:193]
In June 2020, the Company entered into a letter of credit with a bank to guarantee performance obligations under a contract with a certain customer. The obligations under the customer contract will be performed over multiple years. As of September 30, 2020, the Company was required to maintain a minimum collateral value of $4.5 million. The letter of credit was secured by a pledge of a portion of the Company’s fixed-income securities, which totaled $5.9 million as of September 30, 2020, of which $0.3 million is included in restricted cash and $5.6 million is included in long-term investments on the Condensed Consolidated Balance Sheet. This pledged collateral value will fluctuate as the Company changes the mix of the pledged collateral between restricted cash and investments, with an expected maximum value between $13.0 million and $15.0 million. On October 8, 2020, the Company entered into an amendment to the letter of credit, which increased the minimum collateral value to $9.0 million. The minimum collateral value is expected to continue to increase as the Company reaches certain milestones through the first quarter of 2021 as outlined in the customer contract. Any shortfalls in the minimum collateral value are required to be restored by the Company from available cash and cash equivalents, short-term investments and/or long-term investments. The collateral under the letter of credit will be released when all obligations under the customer contract have been met. As of September 30, 2020, the Company was in compliance with all contractual requirements under the letter of credit.

[0001564590-20-052017:notes:194]
Investment Commitment

[0001564590-20-052017:notes:195]
We have committed to invest up to an aggregate of $5.0 million in a private equity fund, of which $4.9 million has been contributed as of September 30, 2020.


## us-gaap:CreditLossFinancialInstrumentTextBlock

[0001564590-20-052017:notes:196]
[same as prior period, unchanged from 0001564590-20-038237:notes:195]

[0001564590-20-052017:notes:197]
[same as prior period, unchanged from 0001564590-20-038237:notes:196]

[0001564590-20-052017:notes:198]
[same as prior period, unchanged from 0001564590-20-038237:notes:197]

[0001564590-20-052017:notes:199]
[same as prior period, unchanged from 0001564590-20-038237:notes:198]

[0001564590-20-052017:notes:200]
The Company records accounts receivable in the normal course of business as products are shipped or services are performed and invoiced, but payment has not yet been remitted by the customer. As of January 1, 2020 and September 30, 2020, the Company’s outstanding accounts receivable balance was $90.5 million and $100.2 million, respectively. The Company assessed the need for an allowance for credit losses related to its outstanding accounts receivable as of September 30, 2020 and January 1, 2020 using the historical loss-rate method as well as assessing asset-specific risks. The Company’s historical losses related to accounts receivable have been immaterial as evidenced by its historical allowance and write-offs due to uncollectability. The assessment of asset-specific risks included the evaluation of relevant available information, from internal and external sources, relating to current conditions that may affect a customer’s ability to pay, such as the customer’s current financial condition, credit rating by geographic location, as provided by a third party and/or by customer, if needed, and overall macro-economic conditions in which the customer operates. The Company pooled assets by geographic location to determine if an allowance should be applied to its accounts receivable balance, assessing the specific country risk rating and overall economics of that particular country. If elevated risk existed, or customer specific risk indicated the accounts receivable balance was at risk, the Company further analyzed the need for an allowance related to specific accounts receivable balances. Additionally, the Company determined that significant changes to customer country risk rating from period-to-period and from the end of the prior year to the end of the current quarter would require further review and analysis by the Company.

[0001564590-20-052017:notes:201]
[same as prior period, unchanged from 0001564590-20-038237:notes:200]

[0001564590-20-052017:notes:202]
No allowance for credit loss was recorded on January 1, 2020 (the “implementation date”) or during the three and nine months ended September 30, 2020 related to accounts receivable. The Company’s allowance for credit losses related to accounts receivable was $38 thousand as of September 30, 2020 and December 31, 2019, all of which was expensed prior to January 1, 2020.

[0001564590-20-052017:notes:203]
[same as prior period, unchanged from 0001564590-20-038237:notes:202]

[0001564590-20-052017:notes:204]
The Company records contract assets when it has recognized revenue but has not yet billed the customer. As of January 1, 2020 and September 30, 2020, the Company’s outstanding contract asset balance was $2.8 million and $1.0 million, respectively, which is included in other receivables on the Condensed Consolidated Balance Sheets as of December 31, 2019 and September 30, 2020. The Company assessed the need for an allowance for credit losses related to its outstanding contract assets as of September 30, 2020 and January 1, 2020 using the historical loss-rate method as well as asset-specific risks. The Company’s historical losses related to contract assets receivable have been immaterial as evidenced by historical write-offs due to uncollectability. Asset-specific risk included the evaluation of relevant available information, from internal and external sources, relating to current conditions that may affect a customer’s ability to pay once invoiced, such as the customer’s financial condition, credit rating by geographic location as provided by a third party and/or by customer, if needed, and overall macro-economic conditions in which the customer operates. The Company pooled assets by geographic location to determine if an allowance should be applied to its contract asset balance, assessing the specific country risk rating and overall economics of that particular country. If elevated risk existed, or customer specific risk indicated the contract balance was at risk, the Company further analyzed the need for an allowance related to specific customer balances. Additionally, the Company determined that significant changes to customer country risk rating from period-to-period and from the end of the prior year to the end of the current quarter would be subject to further review and analysis by the Company.

[0001564590-20-052017:notes:205]
No allowance for credit loss was recorded on the implementation date or during the three and nine months ended September 30, 2020 related to contract assets.

[0001564590-20-052017:notes:206]
The Company is the lessor in sales-type lease arrangements for network equipment. As of January 1, 2020 and September 30, 2020, the Company’s outstanding net investment in sales-type leases was $1.6 million and $1.0 million, respectively, which is included in other receivables and other assets on the Condensed Consolidated Balance Sheets as of December 31, 2019 and September 30, 2020. The Company assessed the need for an allowance for credit losses related to future receivables under its outstanding sales-type leases as of September 30, 2020 and January 1, 2020 using the historical loss-rate method as well as asset-specific risks. The Company’s historical losses related to contract assets receivable have been immaterial as evidenced by historical write-offs due to uncollectability. Asset-specific risk included the evaluation of relevant available information, from internal and external sources, relating to current conditions that may affect a customer’s ability to pay once invoiced, such as the customer’s financial condition, credit rating by geographic location as provided by a third party and/or by customer, if needed, and overall macro-economic conditions in which the customer operates.

[0001564590-20-052017:notes:207]
[same as prior period, unchanged from 0001564590-20-038237:notes:206]

[0001564590-20-052017:notes:208]
|  |  | Sales-Type Leases Amortized Cost Basis by Origination Year |  |
| (In thousands) |  | 2020 |  |  | 2019 |  |  | 2018 |  |  | 2017 |  |  | 2016 |  |  | Prior |  |  | Total |  |
| Payment performance |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Performing |  | $ | 58 |  |  | $ | 227 |  |  | $ | 426 |  |  | $ | 153 |  |  | $ | 89 |  |  | $ | 3 |  |  | $ | 956 |  |
| Non-performing |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 58 |  |  | $ | 227 |  |  | $ | 426 |  |  | $ | 153 |  |  | $ | 89 |  |  | $ | 3 |  |  | $ | 956 |  |

[0001564590-20-052017:notes:209]
Sales-type lease receivables are considered past due when payment has not been received based on agreed upon terms between the customer and the Company. No allowance for credit loss was recorded on the implementation date or during the three and nine months ended September 30, 2020 related to sales-type leases.

[0001564590-20-052017:notes:210]
[same as prior period, unchanged from 0001564590-20-038237:notes:209]

[0001564590-20-052017:notes:211]
The Company has a secured loan receivable totaling $0.9 million as of January 1, 2020 and September 30, 2020, which originated in February 2019, and is included in long-term investments on the Condensed Consolidated Balance Sheets as of September 30, 2020 and December 31, 2019. The Company assessed the need for an allowance for credit loss related to its secured loan receivable as of September 30, 2020 and January 1, 2020 using the historical loss-rate method as well as asset-specific risks. There have been no historical losses related to this receivable. Asset-specific risks included the evaluation of relevant available information, from internal and external sources, relating to current conditions that may affect the customer’s ability to repay the loan upon maturity, such as the customer’s current financial condition, credit rating specific to the customer as determined by a third party and current overall economic conditions, as well as a Company valuation prepared by a third party which was based on reasonable and supportable forecasts as provided by management. Accrued interest receivable on the secured loan receivable, which is included in other receivables on the Condensed Consolidated Balance Sheets as of September 30, 2020 and December 31, 2019, totaled $24 thousand and $0 as of January 1, 2020 and September 30, 2020, respectively, and was excluded from the estimate of credit losses for both periods based on the Company’s accounting policy election.

[0001564590-20-052017:notes:212]
No allowance for credit loss was recorded on the implementation date or during the three and nine months ended September 30, 2020 related to the secured loan receivable.

[0001564590-20-052017:notes:213]
[same as prior period, unchanged from 0001564590-20-038237:notes:212]

[0001564590-20-052017:notes:214]
The Company did not have any off-balance sheet arrangements as of January 1, 2020 or September 30, 2020.

[0001564590-20-052017:notes:215]
[same as prior period, unchanged from 0001564590-20-038237:notes:214]

[0001564590-20-052017:notes:216]
As of January 1, 2020 and September 30, 2020, the Company’s available-for-sale debt securities totaled $37.7 million and $44.9 million, respectively. These securities were analyzed at the individual investment level, by CUSIP, to limit credit losses, if applicable, to reflect only the amount by which the fair value of the security was less than its amortized cost. The Company noted that, as of January 1, 2020 and September 30, 2020, there was no intent to sell any of its available-for-sale debt securities before maturity, and, therefore, the Company assessed the need for an allowance for each of its available-for-sale debt securities in which the fair value was less than its amortized cost as of January 1, 2020 and September 30, 2020. Accrued interest receivable on available-for-sale debt securities, which is included in other receivables on the Condensed Consolidated Balance Sheets as of September 30, 2020 and December 31, 2019, totaled $0.1 million as of January 1, 2020 and September 30, 2020, and was excluded from the estimate of credit losses for both periods based on the Company’s accounting policy election. Income generated from available-for-sale debt securities was recorded as interest and dividend income in the Condensed Consolidated Statements of Income (Loss).

[0001564590-20-052017:notes:217]
The Company had 45 positions in available-for-sale debt securities that were in an unrealized loss position as of September 30, 2020, which are presented in the table below:

[0001564590-20-052017:notes:218]
| (In thousands) |  | Continuous Unrealized Loss Position for Less than 12 Months |  |  | Continuous Unrealized Loss Position for 12 Months or Greater |  |  | Total |  |
|  |  | Fair Value |  |  | Unrealized Losses |  |  | Fair Value |  |  | Unrealized Losses |  |  | Fair Value |  |  | Unrealized Losses |  |
| Corporate bonds |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 394 |  |  |  | (1 | ) |  |  | — |  |  |  | — |  |  |  | 394 |  |  |  | (1 | ) |
| Asset-backed bonds |  |  | 396 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 396 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 3,199 |  |  |  | (11 | ) |  |  | — |  |  |  | — |  |  |  | 3,199 |  |  |  | (11 | ) |
| U.S. government bonds |  |  | 800 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 800 |  |  |  | — |  |
| Foreign government bonds |  |  | 75 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 75 |  |  |  | — |  |
| Total |  | $ | 4,864 |  |  | $ | (12 | ) |  | $ | — |  |  | $ | — |  |  | $ | 4,864 |  |  | $ | (12 | ) |

[0001564590-20-052017:notes:219]
[same as prior period, unchanged from 0001564590-20-038237:notes:218]

[0001564590-20-052017:notes:220]
| (In thousands) |  | Continuous Unrealized Loss Position for Less than 12 Months |  |  | Continuous Unrealized Loss Position for 12 Months or Greater |  |  | Total |  |
|  |  | Fair Value |  |  | Unrealized Losses |  |  | Fair Value |  |  | Unrealized Losses |  |  | Fair Value |  |  | Unrealized Losses |  |
| Corporate bonds |  |  | 203 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 203 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 930 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 930 |  |  |  | — |  |
| Asset-backed bonds |  |  | 797 |  |  |  | (3 | ) |  |  | — |  |  |  | — |  |  |  | 797 |  |  |  | (3 | ) |
| Mortgage/Agency-backed bonds |  |  | 2,594 |  |  |  | (6 | ) |  |  | 136 |  |  |  | (2 | ) |  |  | 2,730 |  |  |  | (8 | ) |
| U.S. government bonds |  |  | 4,070 |  |  |  | (9 | ) |  |  | — |  |  |  | — |  |  |  | 4,070 |  |  |  | (9 | ) |
| Foreign government bonds |  |  | 371 |  |  |  | (1 | ) |  |  | — |  |  |  | — |  |  |  | 371 |  |  |  | (1 | ) |
| Total |  | $ | 8,965 |  |  | $ | (19 | ) |  | $ | 136 |  |  | $ | (2 | ) |  | $ | 9,101 |  |  | $ | (21 | ) |

[0001564590-20-052017:notes:221]
[same as prior period, unchanged from 0001564590-20-038237:notes:220]

[0001564590-20-052017:notes:222]
No allowance for credit loss was recorded on the implementation date or during the three and nine months ended September 30, 2020 related to the Company’s available-for-sale debt securities.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-20-052017:notes:223]
[same as prior period, unchanged from 0001564590-20-038237:notes:222]

[0001564590-20-052017:notes:224]
[same as prior period, unchanged from 0001564590-20-038237:notes:223]

[0001564590-20-052017:notes:225]
In February 2019, the Company announced the restructuring of a certain portion of its workforce predominantly in Germany, which included the closure of the Company’s office location in Munich, Germany accompanied by relocation or severance benefits for the affected employees. Voluntary early retirement was offered to certain other employees and was announced in March 2019 and again in August 2020.

[0001564590-20-052017:notes:226]
A reconciliation of the beginning and ending restructuring liability, which is included in accrued wages and benefits on the Condensed Consolidated Balance Sheets as of September 30, 2020 and December 31, 2019, is as follows:

[0001564590-20-052017:notes:227]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
| (In thousands) |  | September 30, 2020 |  |  | September 30, 2020 |  |
| Balance at beginning of period |  | $ | 358 |  |  | $ | 1,568 |  |
| Plus: Amounts charged to expense |  |  | 1,903 |  |  |  | 3,648 |  |
| Less: Amounts paid |  |  | (542 | ) |  |  | (3,497 | ) |
| Balance as of September 30, 2020 |  | $ | 1,719 |  |  | $ | 1,719 |  |

[0001564590-20-052017:notes:228]
| (In thousands) |  | December 31, 2019 |  |
| Balance as of December 31, 2018 |  | $ | 185 |  |
| Plus: Amounts charged to expense |  |  | 6,014 |  |
| Less: Amounts paid |  |  | (4,631 | ) |
| Balance as of December 31, 2019 |  | $ | 1,568 |  |

[0001564590-20-052017:notes:229]
[same as prior period, unchanged from 0001564590-20-038237:notes:228]

[0001564590-20-052017:notes:230]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Cost of sales |  |  | 232 |  |  |  | 62 |  |  |  | 288 |  |  |  | 747 |  |
| Selling, general and administrative expenses |  | $ | 1,050 |  |  | $ | 531 |  |  | $ | 1,622 |  |  | $ | 2,078 |  |
| Research and development expenses |  |  | 621 |  |  |  | 602 |  |  |  | 1,738 |  |  |  | 1,833 |  |
| Total restructuring expenses |  | $ | 1,903 |  |  | $ | 1,195 |  |  | $ | 3,648 |  |  | $ | 4,658 |  |

[0001564590-20-052017:notes:231]
The following table represents the components of restructuring expenses by geographic area:

[0001564590-20-052017:notes:232]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |
| Domestic |  | $ | 448 |  |  | $ | 1,116 |  |  | $ | 2,191 |  |  | $ | 1,941 |  |
| International |  |  | 1,455 |  |  |  | 79 |  |  |  | 1,457 |  |  |  | 2,717 |  |
| Total restructuring expenses |  | $ | 1,903 |  |  | $ | 1,195 |  |  | $ | 3,648 |  |  | $ | 4,658 |  |

[0001564590-20-052017:notes:233]
The cumulative amount of restructuring expenses incurred as of September 30, 2020 for the restructuring plans announced in 2019 and 2020 was $9.7 million.


## us-gaap:SubsequentEventsTextBlock

[0001564590-20-052017:notes:234]
21. SUBSEQUENT EVENTS

[0001564590-20-052017:notes:235]
On November 2, 2020, the Company announced that its Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to the Company’s stockholders of record as of the close of business on November 17, 2020. The payment date will be December 1, 2020 in the aggregate amount of approximately $4.3 million.

[0001564590-20-052017:notes:236]
On November 4, 2020, the Company, as borrower, entered into a Revolving Credit and Security Agreement and related Promissory Note (together, the “Revolving Credit Agreement”) with Cadence Bank, N.A., as lender (the “Lender”). The Revolving Credit Agreement provides the Company with a new $10 million secured revolving credit facility. Loans under the Revolving Credit Agreement will bear interest at a rate equal to 1.50% over the screen rate as obtained by Reuter’s, Bloomberg or another commercially available source as may be designated by the Lender from time to time; provided, however, that in no event shall the applicable rate of interest under the Revolving Credit Agreement be less than 1.50% per annum. Such loans are secured by all of the cash, securities, securities entitlements and investment property in a certain bank account, as outlined in the Revolving Credit Agreement, at a maximum loan-to-value ratio of 75% determined by dividing the full commitment amount under the Revolving Credit Agreement on the date of testing, determined by the Lender each fiscal quarter, by the market value of the collateral. The Revolving Credit Agreement matures on November 4, 2021, subject to earlier termination upon the occurrence of certain events of default. The Company has not made any draws under the Revolving Credit Agreement to date.
