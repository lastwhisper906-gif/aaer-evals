# ADTN MD&A — 0001564590-20-052017


## mdna

[0001564590-20-052017:mdna:1]
[same as prior period, unchanged from 0001564590-20-038237:mdna:1]

[0001564590-20-052017:mdna:2]
The following discussion should be read in conjunction with the consolidated financial statements and the related notes that appear in Part I, Item 1 of this document. In addition, the following discussion should be read in conjunction with our audited consolidated financial statements for the year ended December 31, 2019, Part II, Item 7, Management’s Discussion and Analysis of Financial Condition and Results of Operations, Part I, Item 1, Business, and Item 1A, Risk Factors, included in our Annual Report on Form 10-K for the year ended December 31, 2019, filed with the SEC on February 25, 2020 (the “2019 Form 10-K”).

[0001564590-20-052017:mdna:3]
This discussion is designed to provide the reader with information that will assist in understanding our condensed consolidated financial statements, the changes in certain key items in those financial statements from period to period, and the primary factors that accounted for those changes, as well as how certain accounting principles affect our condensed consolidated financial statements. See “Cautionary Note Regarding Forward-Looking Statements” on page 3 of this report for a description of important factors that could cause actual results to differ from expected results. See also Part I, Item 1A, Risk Factors, of the 2019 Form 10‑K and Part II, Item 1A, Risk Factors, of this Form 10-Q.

[0001564590-20-052017:mdna:4]
[same as prior period, unchanged from 0001564590-20-038237:mdna:4]

[0001564590-20-052017:mdna:5]
ADTRAN is a leading global provider of networking and communications solutions focused on the access market, serving a diverse domestic and international customer base in multiple countries that includes Tier-1, -2 and -3 service providers, cable/MSOs and distributed enterprises. Our innovative solutions and services enable voice, data, video and internet communications across a variety of network infrastructures and are currently in use by millions worldwide. We support our customers through our direct global sales organization and our distribution networks. Our success depends upon our ability to increase unit volume and market share through the introduction of new products and succeeding generations of products having lower selling prices and increased functionality as compared to both the prior generation of a product and to the products of competitors. In order to service our customers and grow revenue, we are continually conducting research and development of new products addressing customer needs and testing those products for the specific requirements of the particular customers. We are focused on being a top global supplier of access infrastructure and related value-added solutions from the cloud edge to the subscriber edge. We offer a broad portfolio of flexible software and hardware network solutions and services that enable service providers to meet today’s service demands, while enabling them to transition to the fully-converged, scalable, highly-automated, cloud-controlled voice, data, internet and video network of the future. In addition to our corporate headquarters in Huntsville, Alabama, we have research and development facilities in strategic global locations.

[0001564590-20-052017:mdna:6]
[same as prior period, unchanged from 0001564590-20-038237:mdna:6]

[0001564590-20-052017:mdna:7]
We ended the third quarter of 2020 with an increase in revenue of 16.7% for the three months ended September 30, 2020 as compared to the three months ended September 30, 2019, mainly driven by the increase in shipments to regional service providers in the U.S., alternative network operators in Europe and initial sales to a European Tier-1 operator. Additionally, in the third quarter of 2020, we had two 10% revenue domestic customers. Our domestic revenue grew 11.7% during the three months ended September 30, 2020 compared to the same quarter in the prior year, which was driven by growth in both Tier-3 and Tier-2 carrier categories due to additional fiber access deployments in both access equipment and CPE. Internationally, our revenue grew 30.2% compared to the same quarter in the prior year, primarily driven by an increase in spending from a Tier-1 customer. In the Asia Pacific region, we experienced growth driven by the acceleration of access network builds. Additionally, fiber access continues to experience revenue growth, and, during the first three quarters of 2020, we announced multiple long-term Tier-1 next-generation fiber access deals in Europe and the U.S., positioning us well for the next access network upgrade investment cycle.

[0001564590-20-052017:mdna:8]
In March 2020, the World Health Organization declared the outbreak of COVID-19 a pandemic. During the nine months ended September 30, 2020, there was a downturn in the global financial markets followed by a gradual rebound and a slowdown in the global economy due to the COVID-19 pandemic. COVID-19 continues to spread throughout the U.S. and the world and has resulted in authorities implementing numerous measures to contain the virus, including travel bans and restrictions, quarantines, shelter-in-place orders, and business limitations and shutdowns. While we are unable to accurately predict the full impact that COVID-19 will have on our results of operations, financial condition, liquidity and cash flows due to numerous uncertainties, including the duration and severity of the pandemic and containment measures, our compliance with these measures has impacted our day-to-day operations and could disrupt our business and operations, as well as that of our key customers, suppliers and other counterparties, for an indefinite period of time. We have experienced some impact to our supply chain, including a slowdown in supply chain deliveries, extended lead times on some key components and some raw material cost increases. We have also had to increase our volume of inventory to ensure supply continuity during the pandemic. In addition, we have experienced significant increases in freight-related costs. While throughout the pandemic, we have seen increased demand in networking requirements and utilization due to social distancing guidelines issued by governments, as well as COVID-19 related reductions in travel and infrastructure expenses, it is possible that we could experience some slowdown in demand and further supply chain issues as the pandemic continues. Even after the COVID-19 pandemic has subsided, we may continue to experience adverse impacts to our business as a result of any economic recession that has occurred or may occur in the future.

[0001564590-20-052017:mdna:9]
Among our customers, we made progress with our fiber and fiber-extension solutions, including PON and Gfast, while also continuing to engage various Services & Support opportunities that we expect will contribute to sales in 2020 and beyond. In addition, we believe that we are at the beginning of a significant investment cycle for fiber deployment driven by technology advancements and regulatory influences. The transition to next-generation network architectures is beginning, and we are seeing demand for our next-generation SD-Access solutions. In 2021, we anticipate that payments to service providers under government funding programs such as the FCC RDOF will begin.

[0001564590-20-052017:mdna:10]
[same as prior period, unchanged from 0001564590-20-038237:mdna:10]

[0001564590-20-052017:mdna:11]
[same as prior period, unchanged from 0001564590-20-038237:mdna:11]

[0001564590-20-052017:mdna:12]
[same as prior period, unchanged from 0001564590-20-038237:mdna:12]

[0001564590-20-052017:mdna:13]
[same as prior period, unchanged from 0001564590-20-038237:mdna:13]

[0001564590-20-052017:mdna:14]
[same as prior period, unchanged from 0001564590-20-038237:mdna:14]

[0001564590-20-052017:mdna:15]
Our operating results may also fluctuate as a result of a number of other factors, including a decline in general economic and market conditions, specifically the decline that has resulted from the COVID-19 pandemic, foreign currency exchange rate movements, increased competition, customer order patterns, changes in product and services mix, timing differences between price decreases and product cost reductions, product warranty returns, expediting costs, tariffs and announcements of new products by us or our competitors. Additionally, maintaining sufficient inventory levels to assure prompt delivery of our products increases the amount of inventory that may become obsolete and increases the risk that the obsolescence of this inventory may have an adverse effect on our business and operating results. Also, not maintaining sufficient inventory levels to assure prompt delivery of our products may cause us to incur expediting costs to meet customer delivery requirements, which may negatively impact our operating results in a given quarter. During 2019 and 2020, the Company implemented restructuring plans to realign its expense structure with the reduction in revenue experienced in recent years and with overall Company objectives. Management assessed the efficiency of our operations and consolidated locations and personnel, among other things, and has implemented certain cost savings initiatives, where possible. We expect to continue to see a reduction in our operating expenses and cost of sales, both in the U.S. and internationally, as a result of our implementation of these restructuring plans.

[0001564590-20-052017:mdna:16]
[same as prior period, unchanged from 0001564590-20-038237:mdna:16]

[0001564590-20-052017:mdna:17]
[same as prior period, unchanged from 0001564590-20-038237:mdna:17]

[0001564590-20-052017:mdna:18]
[same as prior period, unchanged from 0001564590-20-038237:mdna:18]

[0001564590-20-052017:mdna:19]
[same as prior period, unchanged from 0001564590-20-038237:mdna:19]

[0001564590-20-052017:mdna:20]
[same as prior period, unchanged from 0001564590-20-038237:mdna:20]

[0001564590-20-052017:mdna:21]
40

[0001564590-20-052017:mdna:22]
RESULTS OF OPERATIONS – THREE AND NINE MONTHS ENDED SEPTEMBER 30, 2020 COMPARED TO THREE AND NINE MONTHS ENDED SEPTEMBER 30, 2019

[0001564590-20-052017:mdna:23]
[same as prior period, unchanged from 0001564590-20-038237:mdna:23]

[0001564590-20-052017:mdna:24]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |  |
|  |  | September 30, |  |  | September 30, |  |  |
|  |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |  |
| Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Network Solutions |  |  | 86.5 |  | % |  | 82.4 |  | % |  | 86.1 |  | % |  | 86.7 |  | % |
| Services & Support |  |  | 13.5 |  |  |  | 17.6 |  |  |  | 13.9 |  |  |  | 13.3 |  |  |
| Total Sales |  |  | 100.0 |  |  |  | 100.0 |  |  |  | 100.0 |  |  |  | 100.0 |  |  |
| Cost of Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Network Solutions |  |  | 47.2 |  |  |  | 49.5 |  |  |  | 47.4 |  |  |  | 50.1 |  |  |
| Services & Support |  |  | 8.6 |  |  |  | 9.9 |  |  |  | 9.0 |  |  |  | 8.4 |  |  |
| Total Cost of Sales |  |  | 55.7 |  |  |  | 59.4 |  |  |  | 56.4 |  |  |  | 58.5 |  |  |
| Gross Profit |  |  | 44.3 |  |  |  | 40.6 |  |  |  | 43.6 |  |  |  | 41.5 |  |  |
| Selling, general and administrative expenses |  |  | 20.4 |  |  |  | 27.1 |  |  |  | 22.5 |  |  |  | 24.1 |  |  |
| Research and development expenses |  |  | 20.4 |  |  |  | 27.9 |  |  |  | 22.8 |  |  |  | 23.1 |  |  |
| Asset impairments |  |  | — |  |  |  | 3.4 |  |  |  | — |  |  |  | 0.9 |  |  |
| Gain on contingency |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (0.3 | ) |  |
| Operating Income (Loss) |  |  | 3.4 |  |  |  | (17.8 | ) |  |  | (1.7 | ) |  |  | (6.3 | ) |  |
| Interest and dividend income |  |  | 0.3 |  |  |  | 0.5 |  |  |  | 0.3 |  |  |  | 0.5 |  |  |
| Interest expense |  |  | — |  |  |  | (0.1 | ) |  |  | — |  |  |  | (0.1 | ) |  |
| Net investment gain (loss) |  |  | 2.1 |  |  |  | (0.2 | ) |  |  | 0.5 |  |  |  | 2.0 |  |  |
| Other income (expense), net |  |  | (1.3 | ) |  |  | 1.4 |  |  |  | (0.6 | ) |  |  | 0.5 |  |  |
| Income (Loss) Before Income Taxes |  |  | 4.5 |  |  |  | (16.1 | ) |  |  | (1.6 | ) |  |  | (3.4 | ) |  |
| Income tax (expense) benefit |  |  | (0.4 | ) |  |  | (24.3 | ) |  |  | 0.6 |  |  |  | (6.6 | ) |  |
| Net Income (Loss) |  |  | 4.1 |  | % |  | (40.4 | ) | % |  | (1.0 | ) | % |  | (10.0 | ) | % |

[0001564590-20-052017:mdna:25]
[same as prior period, unchanged from 0001564590-20-038237:mdna:25]

[0001564590-20-052017:mdna:26]
Our sales increased 16.7% from $114.1 million for the three months ended September 30, 2019 to $133.1 million for the three months ended September 30, 2020 and decreased 9.1% from $414.3 million for the nine months ended September 30, 2019 to $376.4 million for the nine months ended September 30, 2020. The increase in sales for the three months ended September 30, 2020 was primarily attributable to a $20.3 million increase in Access & Aggregation sales and a $0.6 million increase in Subscriber Solutions & Experience sales, partially offset by a decrease of $1.9 million in Traditional & Other Products. The decrease in sales for the nine months ended September 30, 2020 was primarily attributable to a $40.1 million decrease in Access & Aggregation sales and a $3.7 million decrease in Traditional & Other Products sales, partially offset by a $6.0 million increase in Subscriber Solutions & Experience sales.

[0001564590-20-052017:mdna:27]
Network Solutions segment sales increased 22.6% from $94.0 million for the three months ended September 30, 2019 to $115.2 million for the three months ended September 30, 2020 and decreased 9.8% from $359.0 million for the nine months ended September 30, 2019 to $323.9 million for the nine months ended September 30, 2020. The increase in sales for the three months ended September 30, 2020 was primarily attributable to an increase in shipments to regional service providers in the U.S., alternative network operators in Europe and initial sales to a European Tier-1 operator. For the three months ended September 30, 2020, sales in the Access & Aggregation and Subscriber Solutions & Experience categories increased, while sales in the Traditional & Other Products categories decreased. The increase in Access & Aggregation sales for the three months ended September 30, 2020 was primarily attributable to increased volume in sales of FTTP solutions and our Mosaic software. The increase in Subscriber Solutions & Experience sales for the three months ended September 30, 2020 was primarily attributable to increased volume in residential gateways partially offset by decreased volume of SP Business CPE sales. The decrease in sales for the nine months ended September 30, 2020 was primarily attributable to the slowdown in shipments to two Tier-1 customers. For the nine months ended September 30, 2020, sales in the Access & Aggregation and Traditional & Other Products categories decreased, while sales in the Subscriber Solutions & Experience categories increased. The decrease in Access & Aggregation sales for the nine months ended September 30, 2020 was primarily attributable to decreased volume in sales of FTTN products. The increase in Subscriber Solutions & Experience sales for the nine months ended September 30, 2020 was primarily attributable to an increased volume of network termination and Fiber CPE. While we expect that revenue from Traditional & Other Products will continue to decline over time, this revenue may fluctuate and continue for years because of the time required for our customers to transition to newer technologies.

[0001564590-20-052017:mdna:28]
Services & Support segment sales decreased 10.8% from $20.1 million for the three months ended September 30, 2019 to $17.9 million for the three months ended September 30, 2020 and decreased 5.1% from $55.3 million for the nine months ended September 30, 2019 to $52.5 million for the nine months ended September 30, 2020. The decrease in sales for the three and nine months ended September 30, 2020 was primarily attributable to decreased volume of FTTN products.

[0001564590-20-052017:mdna:29]
International sales, which are included in the amounts for both the Network Solutions and Services & Support segments discussed above, increased 30.2% from $30.9 million for the three months ended September 30, 2019 to $40.3 million for the three months ended September 30, 2020 and decreased 34.5% from $183.3 million for the nine months ended September 30, 2019 to $120.1 million for the nine months ended September 30, 2020. International sales, as a percentage of total sales, increased from 27.1% for the three months ended September 30, 2019 to 30.3% for the three months ended September 30, 2020 and decreased from 44.2% for the nine months ended September 30, 2019 to 31.9% for the nine months ended September 30, 2020. The increase in sales for the three months ended September 30, 2020 was primarily attributable to increased shipments to European Tier-1 operators as well as alternative network operators in Europe. The decrease in sales for the nine months ended September 30, 2020, was primarily attributable to the reduction in shipments to two international Tier-1 customers.

[0001564590-20-052017:mdna:30]
[same as prior period, unchanged from 0001564590-20-038237:mdna:30]

[0001564590-20-052017:mdna:31]
[same as prior period, unchanged from 0001564590-20-038237:mdna:31]

[0001564590-20-052017:mdna:32]
As a percentage of sales, cost of sales decreased from 59.4% for the three months ended September 30, 2019 to 55.7% for the three months ended September 30, 2020 and decreased from 58.5% for the nine months ended September 30, 2019 to 56.4% for the nine months ended September 30, 2020. For the three months ended September 30, 2020, the decrease was primarily attributable to changes in customer and product mix as well as a decrease in fixed personnel costs as a result of our restructuring program initiated in 2019, partially offset by higher freight-related charges and expedite premiums. For the nine months ended September 30, 2020, the decrease was primarily attributable to changes in customer and product mix, a regional revenue shift, changes in services and support mix and a decrease in fixed personnel costs as a result of our restructuring program initiated in 2019.

[0001564590-20-052017:mdna:33]
Network Solutions cost of sales, as a percentage of that segment’s sales, decreased from 60.0% for the three months ended September 30, 2019 to 54.5% for the three months ended September 30, 2020 and decreased from 57.8% for the nine months ended September 30, 2019 to 55.1% for the nine months ended September 30, 2020. The decrease in cost of sales as a percentage of sales for the three and nine months ended September 30, 2020 was primarily attributable to changes in customer and product mix, a regional revenue shift and a decrease in fixed personnel costs as a result of our restructuring program initiated in 2019.

[0001564590-20-052017:mdna:34]
[same as prior period, unchanged from 0001564590-20-038237:mdna:34]

[0001564590-20-052017:mdna:35]
Services & Support cost of sales, as a percentage of that segment’s sales, increased from 56.4% for the three months ended September 30, 2019 to 63.6% for the three months ended September 30, 2020 and increased from 63.3% for the nine months ended September 30, 2019 to 64.5% for the nine months ended September 30, 2020. The increase in cost of sales as a percentage of sales for the three and nine months ended September 30, 2020 was primarily attributable to changes in services and support mix and volume.

[0001564590-20-052017:mdna:36]
[same as prior period, unchanged from 0001564590-20-038237:mdna:36]

[0001564590-20-052017:mdna:37]
As our network planning and implementation revenue grew to become the largest component of our Services & Support segment business, our Services & Support segment gross margins decreased versus those reported when maintenance and support comprised the majority of the business. Further, because the growth in our network planning and implementation services has resulted in our Services & Support segment revenue comprising a large percentage of our overall revenue, and because our Services & Support segment gross margins are generally below those of the Network Solutions segment, our overall corporate gross margins have declined as that business has continued to grow. Within the Services & Support segment, we do expect variability in gross margins from quarter to quarter based on the mix of the services recognized.

[0001564590-20-052017:mdna:38]
[same as prior period, unchanged from 0001564590-20-038237:mdna:38]

[0001564590-20-052017:mdna:39]
As a percentage of sales, selling, general and administrative expenses decreased from 27.1% for the three months ended September 30, 2019 to 20.4% for the three months ended September 30, 2020 and decreased from 24.1% for the nine months ended September 30, 2019 to 22.5% for the nine months ended September 30, 2020. Selling, general and administrative expenses as a percentage of sales will generally fluctuate whenever there is a significant fluctuation in revenue for the periods being compared.

[0001564590-20-052017:mdna:40]
Selling, general and administrative expenses decreased 12.0% from $30.9 million for the three months ended September 30, 2019 to $27.2 million for the three months ended September 30, 2020 and decreased 15.1% from $99.7 million for the nine months ended September 30, 2019 to $84.6 million for the nine months ended September 30, 2020. The decrease in selling, general and administrative expenses for the three months ended September 30, 2020 was primarily attributable to lower travel-related expenses and lower labor expense mainly due to our restructuring program initiated in 2019 and the capitalization of certain costs related to an enterprise resource planning implementation project, partially offset by market driven increases in our deferred compensation investment portfolios. The decrease in selling, general and administrative expenses for the nine months ended September 30, 2020 was primarily attributable to lower labor expense partially due to our restructuring program initiated in 2019 and the capitalization of certain costs related to an enterprise resource planning implementation project, market driven decreases in our deferred compensation investment portfolio and reduced travel-related expenses, partially offset by increased contract services related to an enterprise resource planning implementation project.

[0001564590-20-052017:mdna:41]
[same as prior period, unchanged from 0001564590-20-038237:mdna:41]

[0001564590-20-052017:mdna:42]
As a percentage of sales, research and development expenses decreased from 27.9% for the three months ended September 30, 2019 to 20.4% for the three months ended September 30, 2020 and decreased from 23.1% for the nine months ended September 30, 2019 to 22.8% for the nine months ended September 30, 2020. Research and development expenses as a percentage of sales will fluctuate whenever there are incremental product development activities or significant fluctuations in revenue for the periods being compared.

[0001564590-20-052017:mdna:43]
Research and development expenses decreased 14.5% from $31.8 million for the three months ended September 30, 2019 to $27.2 million for the three months ended September 30, 2020 and decreased 10.2% from $95.5 million for the nine months ended September 30, 2019 to $85.8 million for the nine months ended September 30, 2020. The decrease in research and development expenses for the three and nine months ended September 30, 2020 was primarily attributable to lower labor expense and other expenses which were mainly the result of our restructuring program initiated in 2019, partially offset by increased contract services costs.

[0001564590-20-052017:mdna:44]
[same as prior period, unchanged from 0001564590-20-038237:mdna:44]

[0001564590-20-052017:mdna:45]
[same as prior period, unchanged from 0001564590-20-038237:mdna:47]

[0001564590-20-052017:mdna:46]
Asset impairments, which were $0 and $3.9 million for the three months ended September 30, 2020 and 2019, respectively, and $0.1 million and $3.9 million for the nine months ended September 30, 2020 and 2019, respectively, relate to the abandonment of certain information technology projects in which we had previously capitalized costs.

[0001564590-20-052017:mdna:47]
GAIN ON CONTINGENCY

[0001564590-20-052017:mdna:48]
Gain on contingency, which was $1.2 million for the nine months ended September 30, 2019, relates to the reversal of unearned contingent liabilities which were initially recognized upon the acquisition of SmartRG in the fourth quarter of 2018. There was no gain on contingency recognized during the three and nine months ended September 30, 2020, or during the three months ended September 30, 2019.

[0001564590-20-052017:mdna:49]
[same as prior period, unchanged from 0001564590-20-038237:mdna:49]

[0001564590-20-052017:mdna:50]
Interest and dividend income decreased 43.6% from $0.6 million for the three months ended September 30, 2019 to $0.3 million for the three months ended September 30, 2020 and decreased 45.5% from $1.9 million for the nine months ended September 30, 2019 to $1.0 million for the nine months ended September 30, 2020. The decrease in interest and dividend income was primarily attributable to a decrease in interest income as a result of a decline in our investment balances mainly due to the maturity of our certificate of deposit which served as collateral for our taxable revenue bonds. Our total investments decreased from $119.4 million as of September 30, 2019 to $84.2 million as of September 30, 2020.

[0001564590-20-052017:mdna:51]
[same as prior period, unchanged from 0001564590-20-038237:mdna:51]

[0001564590-20-052017:mdna:52]
Interest expense, which related to our taxable revenue bonds, decreased by $0.1 million for the three months ended September 30, 2020 compared to the three months ended September 30, 2019 and decreased by $0.4 million for the nine months ended September 30, 2020 compared to the nine months ended September 30, 2019. The decrease was due to the fact that the outstanding principal balance of the taxable revenue bonds was paid off upon maturity in January 2020. See “Liquidity and Capital Resources” below for additional information on our revenue bond.

[0001564590-20-052017:mdna:53]
[same as prior period, unchanged from 0001564590-20-038237:mdna:53]

[0001564590-20-052017:mdna:54]
We recognized a net investment loss of $0.2 million and a net investment gain of $2.8 million for the three months ended September 30, 2019 and September 30, 2020, respectively, and a net investment gain of $8.2 million and $1.8 million for the nine months ended September 30, 2019 and September 30, 2020, respectively. The fluctuations in our net investments were primarily attributable to the sale of equity securities as well as changes in the fair value of our securities recognized during the period. During the nine months ended September 30, 2020, our investments were impacted by varying market conditions, including the COVID-19 pandemic, which resulted in a sharp downturn in the markets during the first quarter of 2020 followed by market improvements and more positive results from a favorable portfolio mix in the second and third quarters of 2020. We expect that any future market volatility, whether from COVID-19 or other factors, will result in continued volatility in our investment portfolio. See Note 7 of the Notes to Condensed Consolidated Financial Statements, included in Part I, Item 1 of this report, and “Investing Activities” in “Liquidity and Capital Resources” below for additional information.

[0001564590-20-052017:mdna:55]
[same as prior period, unchanged from 0001564590-20-038237:mdna:55]

[0001564590-20-052017:mdna:56]
Other income (expense), net decreased from income of $1.6 million for the three months ended September 30, 2019 to expense of $1.7 million for the three months ended September 30, 2020 and decreased from income of $2.3 million for the nine months ended September 30, 2019 to expense of $2.3 million for the nine months ended September 30, 2020. For the three and nine months ended September 30, 2020, other expense, net consisted mainly of gains and losses on foreign currency transactions. For the three and nine months ended September 30, 2019, other income, net consisted mainly of the receipt of one-time insurance proceeds from a life insurance policy and gains and losses on foreign currency transactions.

[0001564590-20-052017:mdna:57]
[same as prior period, unchanged from 0001564590-20-038237:mdna:57]

[0001564590-20-052017:mdna:58]
Our effective tax rate decreased from an expense of 150.6% of pre-tax loss for the three months ended September 30, 2019 to an expense of 9.3% of pre-tax income for the three months ended September 30, 2020 and decreased from an expense of 197.1% of pre-tax loss for the nine months ended September 30, 2019 to an benefit of 36.8% of pre-tax loss for the nine months ended September 30, 2020. The change in the effective tax rate for the three months ended September 30, 2020 was impacted by tax expense in our international operations, offset by additional changes in the valuation allowance related to our domestic operations of $1.0 million and by additional benefits recognized during the quarter of $0.4 million as a result of the Coronavirus Aid, Relief, and Economic Security Act (“CARES”) signed into law on March 27, 2020 in conjunction with the Internal Revenue Service’s release of its final Global Intangible Low Tax Income (“GILTI”) regulations on July 9th, 2020. The change in the effective tax rate for the three and nine months ended September 30, 2019 was primarily driven by the establishment of the valuation allowance against our domestic deferred tax assets in the amount of $37.1 million, with tax expense being offset by a 7.1% rate reduction related to a transfer pricing study completed during the second quarter of 2019 that resulted in the assignment of operating expenditures to specific company locations, and the effective income tax rates among the respective jurisdictions. The decrease in the effective tax rate for the nine months ended September 30, 2020 was primarily driven by a tax benefit of $7.8 million recognized during the nine months ended September 30, 2020 as a result of the CARES Act, which allowed for the carryback of federal net operating losses, partially offset with tax expense in our international operations and changes in our valuation allowance related to our domestic operations. An increase in the valuation allowance against our domestic deferred tax assets was recorded in the amount of $2.6 million during the nine months ended September 30, 2020. See Note 4 of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this report for additional information.

[0001564590-20-052017:mdna:59]
[same as prior period, unchanged from 0001564590-20-038237:mdna:59]

[0001564590-20-052017:mdna:60]
As a result of the above factors, net income (loss) increased from a net loss of $46.1 million for the three months ended September 30, 2019 to net income of $5.5 million for the three months ended September 30, 2020, and net loss decreased from a net loss of $41.4 million for the nine months ended September 30, 2019 to a net loss of $3.7 million for the nine months ended September 30, 2020.

[0001564590-20-052017:mdna:61]
[same as prior period, unchanged from 0001564590-20-038237:mdna:61]

[0001564590-20-052017:mdna:62]
[same as prior period, unchanged from 0001564590-20-038237:mdna:62]

[0001564590-20-052017:mdna:63]
We have historically financed, and we currently expect to continue to finance, our ongoing business with existing cash, investments and cash flow from operations. We have used, and expect to continue to use, existing cash, investments and cash generated from operations for working capital, business acquisitions, purchases of treasury stock, shareholder dividends and other general corporate purposes, including product development activities to enhance our existing products and develop new products, expansion of our sales and marketing activities and capital expenditures. We believe that our cash and cash equivalents, investments and cash generated from operations will be adequate to meet our operating and capital needs for at least the next 12 months.

[0001564590-20-052017:mdna:64]
As of September 30, 2020, cash on hand was $71.1 million and short-term investments were $6.2 million, which resulted in available short-term liquidity of $77.3 million, of which $55.7 million was held by our foreign subsidiaries. As of December 31, 2019, cash on hand was $73.8 million and short-term investments were $33.2 million, which resulted in available short-term liquidity of $107.0 million, of which $52.3 million was held by our foreign subsidiaries. Generally, we intend to permanently reinvest funds held outside the U.S., except to the extent that any of these funds can be repatriated without withholding tax. The decrease in short-term liquidity from December 31, 2019 to September 30, 2020 was primarily attributable to the maturity of a certificate of deposit of $25.6 million that served as collateral for our revenue bond, which matured in January 2020.

[0001564590-20-052017:mdna:65]
On November 4, 2020, the Company entered into a Revolving Credit and Security Agreement and related Promissory Note (together, the “Revolving Credit Agreement”) with Cadence Bank, N.A., as lender (the “Lender”). The Revolving Credit Agreement provides the Company with a new $10 million secured revolving credit facility. Loans under the Revolving Credit Agreement will bear interest at a rate equal to 1.50% over the screen rate as obtained by Reuter’s, Bloomberg or another commercially available source as may be designated by the Lender from time to time; provided, however, that in no event shall the applicable rate of interest under the Revolving Credit Agreement be less than 1.50% per annum. Such loans are secured by all of the cash, securities, securities entitlements and investment property in a certain bank account, as outlined in the Revolving Credit Agreement, at a maximum loan-to-value ratio of 75% determined by dividing the full commitment amount under the Revolving Credit Agreement on the date of testing, determined by the Lender each fiscal quarter, by the market value of the collateral. The Revolving Credit Agreement matures on November 4, 2021, subject to earlier termination upon the occurrence of certain events of default. The Company entered into the Revolving Credit Agreement in order to increase the flexibility and management of its short-term liquidity. To date, the Company has not made any draws under the Revolving Credit Agreement. See Part II, Item 5 of this Form 10-Q for additional information on the Revolving Credit Agreement.

[0001564590-20-052017:mdna:66]
[same as prior period, unchanged from 0001564590-20-038237:mdna:65]

[0001564590-20-052017:mdna:67]
Our working capital, defined as current assets less current liabilities, increased 7.1% from $207.6 million as of December 31, 2019 to $222.3 million as of September 30, 2020, and our current ratio, defined as current assets divided by current liabilities, increased from 2.84 as of December 31, 2019 to 3.08 as of September 30, 2020. The increase in our current ratio was primarily attributable to increases in inventory, accounts receivable and other receivables, partially offset by a decrease in short-term investments, which consisted of a certificate of deposit related to our taxable revenue bond and the related bonds payable. The quick ratio, defined as cash, cash equivalents, short-term investments and net accounts receivable, divided by current liabilities, decreased from 1.75 as of December 31, 2019 to 1.66 as of September 30, 2020. The decrease in the quick ratio was primarily attributable to the payment of our bond payable upon maturity in January 2020, partially offset by a decrease in cash and cash equivalents along with an increase in accounts payable.

[0001564590-20-052017:mdna:68]
Net accounts receivable increased 10.7% from $90.5 million as of December 31, 2019 to $100.2 million as of September 30, 2020. Our allowance for doubtful accounts was $38 thousand as of December 31, 2019 and September 30, 2020. The increase in net accounts receivable was due to an increase in sales volume in the third quarter of 2020 as compared to the fourth quarter of 2019. Quarterly accounts receivable DSO decreased from 72 days as of December 31, 2019 to 69 days as of September 30, 2020. The decrease in DSO was due to the timing of product shipments and customer mix.

[0001564590-20-052017:mdna:69]
Other receivables increased 38.2% from $16.6 million as of December 31, 2019 to $22.9 million as of September 30, 2020. The increase in other receivables was primarily attributable to increases in income tax receivables related to the CARES Act partially offset by a decrease in contract assets.

[0001564590-20-052017:mdna:70]
Quarterly inventory turnover decreased from 2.7 turns as of December 31, 2019 to 2.6 turns as of September 30, 2020. Inventory increased 22.3% from $98.3 million as of December 31, 2019 to $120.3 million as of September 30, 2020. The increase in inventory was due to increased purchases in preparation for new product ramp ups as well as strategic inventory buffer purchases to ensure supply continuity during the COVID-19 pandemic. We expect inventory levels to fluctuate as we attempt to maintain sufficient inventory in response to COVID-19 uncertainties related to supply chain and supply, seasonal cycles of our business and ensuring competitive lead times while managing the risk of inventory.

[0001564590-20-052017:mdna:71]
Accounts payable increased 33.5% from $44.9 million as of December 31, 2019 to $59.9 million as of September 30, 2020. Accounts payable will fluctuate due to variations in the timing of the receipt of supplies, inventory and services and our subsequent payments for these purchases.

[0001564590-20-052017:mdna:72]
[same as prior period, unchanged from 0001564590-20-038237:mdna:71]

[0001564590-20-052017:mdna:73]
Capital expenditures totaled approximately $5.1 million and $6.0 million for the nine months ended September 30, 2020 and 2019, respectively. These expenditures were primarily used to purchase manufacturing and test equipment, software, computer hardware and building improvements.

[0001564590-20-052017:mdna:74]
Our combined short-term and long-term investments decreased $43.5 million from $127.7 million as of December 31, 2019 to $84.2 million as of September 30, 2020. This decrease reflects the maturity of a certificate of deposit which served as collateral for our revenue bond and the sale of certain equity investments for working capital and other purposes.

[0001564590-20-052017:mdna:75]
We typically invest all available cash not required for immediate use in operations, primarily in securities that we believe bear minimal risk of loss. See Note 7 of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this report for additional information. As of September 30, 2020, our corporate bonds, municipal bonds, asset-backed bonds, mortgage/agency bonds, U.S. government bonds, other government bonds and variable-rate demand notes were classified as available-for-sale and had a combined duration of 1.6 years with an average Standard & Poor’s credit rating of AA. Because our investment portfolio has a high-quality rating and contractual maturities of short duration, we are able to obtain prices for these bonds derived from observable market inputs, or for similar securities traded in an active market, on a daily basis.

[0001564590-20-052017:mdna:76]
Our long-term investments decreased 17.4% from $94.5 million as of December 31, 2019 to $78.0 million as of September 30, 2020.  Our investments include various marketable equity securities classified as long-term investments with a fair market value of $13.6 million and $35.8 million as of September 30, 2020 and December 31, 2019, respectively. Long-term investments as of September 30, 2020 and December 31, 2019 also included $21.6 million and $21.7 million, respectively, related to our deferred compensation plans, and $0.2 million and $0.3 million as of September 30, 2020 and December 31, 2019, respectively, of other investments, consisting of interests in a private equity fund.

[0001564590-20-052017:mdna:77]
[same as prior period, unchanged from 0001564590-20-038237:mdna:76]

[0001564590-20-052017:mdna:78]
[same as prior period, unchanged from 0001564590-20-038237:mdna:77]

[0001564590-20-052017:mdna:79]
In July 2003, our Board of Directors elected to begin declaring quarterly dividends on our common stock considering the tax treatment of dividends and adequate levels of Company liquidity. During the nine months ended September 30, 2020 and 2019, we paid dividends totaling $13.0 million and $12.9 million, respectively. The continued payment of dividends is at the discretion of the Company’s Board of Directors and is subject to general business conditions and ongoing financial results of the Company.

[0001564590-20-052017:mdna:80]
[same as prior period, unchanged from 0001564590-20-038237:mdna:79]

[0001564590-20-052017:mdna:81]
In conjunction with the 1995 expansion of our Huntsville, Alabama, facility, we were approved for participation in an incentive program offered by the State of Alabama Industrial Development Authority (the “Authority”). Pursuant to the program, in January 1995, the Authority issued $20.0 million of its taxable revenue bonds and loaned the proceeds from the sale of these taxable revenue bonds to the Company. Further advances on the taxable revenue bonds were made by the Authority, bringing the total amount outstanding to $50.0 million. The bonds matured on January 1, 2020, and the outstanding balance of $24.6 million was repaid in full on January 2, 2020. The Company had no outstanding debt as of September 30, 2020.

[0001564590-20-052017:mdna:82]
[same as prior period, unchanged from 0001564590-20-038237:mdna:81]

[0001564590-20-052017:mdna:83]
Since 1997, our Board of Directors has approved multiple share repurchase programs that have authorized repurchases of our common stock, which are implemented through open market or private purchases from time to time as conditions warrant. We currently have authorization to repurchase an additional 2.5 million shares of our common stock under the current authorization of up to 5.0 million shares. During the nine months ended September 30, 2020, there were no common stock repurchases. During the nine months ended September 30, 2019, we repurchased 13,000 shares of our common stock for $0.2 million at an average price of $14.06 per share.

[0001564590-20-052017:mdna:84]
Off-Balance Sheet Arrangements

[0001564590-20-052017:mdna:85]
We do not have off-balance sheet financing arrangements and have not engaged in any related party transactions or arrangements with unconsolidated entities or other persons that are reasonably likely to materially affect liquidity or the availability of or requirements for capital resources.

[0001564590-20-052017:mdna:86]
Contractual Obligations

[0001564590-20-052017:mdna:87]
Certain contracts, customers and jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of September 30, 2020 and December 31, 2019, we had commitments related to these bonds totaling $12.0 million and $9.3 million, respectively, which expire at various dates through August 2024. Although the triggering events vary from contract to contract, in general we would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which we believe is remote.

[0001564590-20-052017:mdna:88]
In June 2020, the Company entered into a letter of credit with a bank to guarantee performance obligations under a contract with a certain customer. The obligations under the customer contract will be performed over multiple years. As of September 30, 2020, the Company was required to maintain a minimum collateral value of $4.5 million. The letter of credit was secured by a pledge of a portion of the Company’s fixed-income securities, which totaled $5.9 million as of September 30, 2020, of which $0.3 million is included in restricted cash and $5.6 million is included in long-term investments on the Condensed Consolidated Balance Sheet. This pledged collateral value will fluctuate as the Company changes the mix of the pledged collateral between restricted cash and investments, with an expected maximum value between $13.0 million and $15.0 million. On October 8, 2020, the Company entered into an amendment to the letter of credit, which increased the minimum collateral value to $9.0 million. The minimum collateral value is expected to continue to increase as the Company reaches certain milestones through the first quarter of 2021 as outlined in the customer contract. Any shortfalls in the minimum collateral value are required to be restored by the Company from available cash and cash equivalents, short-term investments and/or long-term investments. The collateral under the letter of credit will be released when all obligations under the customer contract have been met. As of September 30, 2020, the Company was in compliance with all contractual requirements under the letter of credit.

[0001564590-20-052017:mdna:89]
We have committed to invest up to an aggregate of $5.0 million in a private equity fund of which $4.9 million has been contributed as of September 30, 2020.

[0001564590-20-052017:mdna:90]
During the nine months ended September 30, 2020, there have been no other material changes in contractual obligations and commercial commitments out of the normal course of business from those discussed in the 2019 Form 10-K.
