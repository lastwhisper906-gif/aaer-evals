# ADTN 8-K — 0001564590-20-049784 filed 2020-11-03

## item codes, every 8-K on or before 2020-11-06

- 2020-11-03 0001564590-20-049784 — 2.02, 9.01
- 2020-08-06 0001564590-20-037168 — 2.02, 9.01
- 2020-07-23 0001564590-20-033184 — 5.03, 9.01
- 2020-05-15 0001564590-20-025794 — 5.07
- 2020-05-11 0001564590-20-024328 — 5.02, 9.01
- 2020-05-07 0001564590-20-022297 — 2.02, 9.01
- 2020-02-25 0001564590-20-006448 — 2.02, 9.01
- 2020-02-06 0001564590-20-003580 — 2.02, 9.01
- 2019-10-31 0001564590-19-038936 — 2.02, 9.01
- 2019-10-10 0001564590-19-036732 — 2.02, 9.01
- 2019-09-20 0001564590-19-035144 — 2.02, 9.01
- 2019-08-21 0001564590-19-032757 — 3.01, 9.01
- 2019-07-18 0001564590-19-025186 — 2.02, 9.01
- 2019-05-09 0001564590-19-017956 — 5.07
- 2019-04-18 0001564590-19-011897 — 2.02, 9.01
- 2019-03-07 0001564590-19-006575 — 5.02, 9.01
- 2019-01-24 0001564590-19-001024 — 2.02, 9.01
- 2018-12-06 0001564590-18-030615 — 8.01, 9.01
- 2018-10-17 0001564590-18-024365 — 2.02, 9.01
- 2018-07-18 0001564590-18-016946 — 2.02, 9.01
- 2018-05-10 0001564590-18-012968 — 5.07
- 2018-04-18 0001564590-18-008361 — 2.02, 9.01
- 2018-03-21 0001564590-18-006409 — 8.01, 9.01
- 2018-01-17 0001564590-18-000519 — 2.02, 9.01
- 2017-12-29 0001564590-17-025375 — 2.02, 9.01
- 2017-11-16 0001193125-17-345232 — 5.02
- 2017-10-18 0001564590-17-019582 — 2.02, 9.01
- 2017-07-19 0001564590-17-013609 — 2.02, 9.01
- 2017-05-11 0001564590-17-010459 — 5.02, 9.01
- 2017-05-11 0001564590-17-010452 — 5.07
- 2017-04-19 0001193125-17-127926 — 2.02, 9.01
- 2017-02-07 0001193125-17-032714 — 8.01
- 2017-01-18 0001193125-17-011669 — 2.02, 9.01
- 2016-11-16 0001193125-16-769505 — 5.02, 9.01
- 2016-10-19 0001193125-16-741087 — 2.02, 9.01
- 2016-09-14 0001193125-16-709148 — 8.01, 9.01
- 2016-08-17 0001193125-16-683980 — 5.02, 9.01
- 2016-07-13 0001193125-16-646816 — 2.02, 9.01
- 2016-05-13 0001193125-16-590263 — 5.07
- 2016-04-13 0001193125-16-539019 — 2.02, 9.01
- 2016-04-08 0001193125-16-535035 — 7.01
- 2016-02-11 0001193125-16-459453 — 5.02, 9.01
- 2016-01-20 0001193125-16-432934 — 2.02, 9.01
- 2015-11-16 0001193125-15-378019 — 5.02, 9.01
- 2015-10-14 0001193125-15-343083 — 2.02, 9.01
- 2015-07-16 0001193125-15-254729 — 8.01, 9.01
- 2015-07-15 0001193125-15-253068 — 2.02, 9.01
- 2015-05-15 0001193125-15-189160 — 5.07, 9.01
- 2015-04-22 0001193125-15-140997 — 2.02, 9.01
- 2015-02-23 0001193125-15-056741 — 5.02, 9.01
- 2015-01-21 0001193125-15-015465 — 2.02, 9.01
- 2014-10-15 0001193125-14-372076 — 2.02, 9.01
- 2014-10-03 0001193125-14-363152 — 2.02, 9.01
- 2014-07-16 0001193125-14-269660 — 2.02, 9.01
- 2014-05-20 0001193125-14-205916 — 8.01, 9.01
- 2014-05-20 0001193125-14-205906 — 5.02, 9.01
- 2014-05-15 0001193125-14-201144 — 5.07
- 2014-04-16 0001193125-14-144665 — 2.02, 9.01
- 2014-04-03 0001193125-14-129578 — 2.02, 9.01
- 2014-01-22 0001157523-14-000154 — 2.02, 9.01
- 2013-10-15 0001193125-13-399540 — 5.02
- 2013-10-09 0001157523-13-004657 — 2.02, 9.01
- 2013-07-10 0001157523-13-003290 — 2.02, 9.01
- 2013-05-10 0001193125-13-213728 — 5.07
- 2013-05-03 0001193125-13-198816 — 8.01, 9.01
- 2013-04-10 0001157523-13-001730 — 2.02, 9.01
- 2013-01-16 0001157523-13-000139 — 2.02, 9.01
- 2012-10-10 0001157523-12-005081 — 2.02, 9.01
- 2012-10-03 0001193125-12-413609 — 7.01
- 2012-09-28 0001193125-12-408878 — 2.02, 9.01
- 2012-07-11 0001157523-12-003592 — 2.02, 9.01
- 2012-05-10 0001193125-12-225669 — 5.07
- 2012-05-10 0001193125-12-225639 — 8.01, 9.01
- 2012-04-11 0001157523-12-001772 — 2.02, 9.01
- 2012-03-15 0001193125-12-116494 — 2.02, 9.01
- 2012-01-18 0001157523-12-000174 — 2.02, 9.01
- 2011-12-12 0001193125-11-337271 — 7.01, 9.01
- 2011-10-13 0000950123-11-089785 — 5.03, 9.01
- 2011-10-12 0001157523-11-005682 — 2.02, 9.01
- 2011-07-13 0001157523-11-003986 — 2.02, 9.01
- 2011-05-09 0000950123-11-047191 — 5.02, 5.07, 9.01
- 2011-04-13 0001157523-11-002001 — 2.02, 9.01
- 2011-01-19 0001157523-11-000232 — 2.02, 9.01
- 2010-11-09 0000950123-10-103195 — 5.02, 9.01
- 2010-10-13 0001157523-10-005798 — 2.02, 9.01
- 2010-07-14 0001157523-10-004011 — 2.02, 9.01
- 2010-05-28 0000950123-10-053947 — 5.07
- 2010-04-14 0001157523-10-002022 — 2.02, 9.01
- 2010-01-20 0001157523-10-000200 — 2.02, 9.01
- 2009-10-28 0000950123-09-053984 — 8.01
- 2009-10-14 0001157523-09-006877 — 2.02, 9.01
- 2009-07-15 0001157523-09-004878 — 2.02, 9.01
- 2009-04-15 0001157523-09-002687 — 2.02, 9.01
- 2009-01-21 0001157523-09-000340 — 2.02, 9.01
- 2008-11-12 0001193125-08-233181 — 5.02, 9.01
- 2008-10-14 0001157523-08-007999 — 2.02, 9.01
- 2008-07-15 0001157523-08-005504 — 2.02, 9.01
- 2008-04-15 0001157523-08-002896 — 2.02, 9.01
- 2008-01-22 0001157523-08-000408 — 2.02, 9.01
- 2007-10-16 0001193125-07-219356 — 5.03, 9.01
- 2007-10-16 0001157523-07-009850 — 2.02, 9.01
- 2007-07-17 0001157523-07-006912 — 2.02, 9.01
- 2007-04-17 0001157523-07-003630 — 2.02, 9.01
- 2007-04-03 0001179022-07-000068 — 5.02
- 2007-03-28 0001179022-07-000064 — 5.02
- 2007-02-23 0001193125-07-038337 — 5.02
- 2007-02-23 0001193125-07-038335 — 5.02
- 2007-01-30 0001193125-07-015912 — 5.02, 9.01
- 2007-01-26 0001193125-07-014234 — 5.02
- 2007-01-23 0001157523-07-000494 — 2.02, 9.01 — amendment of 0001157523-07-000481
- 2007-01-23 0001157523-07-000481 — 2.02, 9.01
- 2006-10-17 0001157523-06-009945 — 2.02, 9.01
- 2006-07-18 0001157523-06-006929 — 2.02, 9.01
- 2006-06-08 0001193125-06-126486 — 1.01, 9.01
- 2006-05-10 0001193125-06-107316 — 1.01, 9.01
- 2006-04-18 0001157523-06-003699 — 2.02, 9.01
- 2006-02-03 0001179022-06-000014 — 1.01
- 2006-01-27 0001157523-06-000754 — 5.02, 9.01
- 2006-01-24 0001157523-06-000551 — 2.02, 9.01
- 2005-10-18 0001157523-05-008826 — 2.02, 9.01
- 2005-07-19 0001193125-05-143958 — 1.01, 5.02, 9.01
- 2005-07-19 0001193125-05-143957 — 2.02, 9.01
- 2005-05-20 0001193125-05-112019 — 1.01, 9.01
- 2005-04-19 0001157523-05-003418 — 2.02, 9.01
- 2005-01-25 0001193125-05-010721 — 2.02, 9.01
- 2004-10-12 0001193125-04-169652 — 2.02, 9.01
- 2004-07-13 0001193125-04-116820 — 12, 7
- 2004-04-14 0001193125-04-061547 — 12, 7
- 2004-01-21 0001193125-04-006366 — 12, 7
- 2003-10-14 0001193125-03-061018 — 12, 5, 7
- 2003-07-15 0001193125-03-019292 — 7, 9
- 2003-04-15 0000931763-03-000968 — 7, 9
- 1996-09-12 0000931763-96-000667 — 5, 7

## late-filing notifications on or before 2020-11-06

- 2019-08-12 0001564590-19-031524 — NT 10-Q, for the period ended 2019-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001564590-20-049784:8k_2_02:1]
EX-99.1
2
adtn-ex991_6.htm
EX-99.1

[0001564590-20-049784:8k_2_02:2]
adtn-ex991_6.htm

[0001564590-20-049784:8k_2_02:3]
EXHIBIT 99.1

[0001564590-20-049784:8k_2_02:4]
ADTRAN, Inc. Reports Earnings for the Third Quarter of 2020 and Declares Quarterly Cash Dividend

[0001564590-20-049784:8k_2_02:5]
November 2, 2020

[0001564590-20-049784:8k_2_02:6]
HUNTSVILLE, Ala.--(BUSINESS WIRE)—November 2, 2020 -- ADTRAN, Inc. (NASDAQ:ADTN) (“ADTRAN” or the “Company”) today announced financial results for the third quarter of 2020. For the quarter, revenue was $133.1 million. Net income for the third quarter of 2020 was $5.5 million and earnings per share, assuming dilution, was $0.11 per share. Non-GAAP net income was $7.9 million and non-GAAP earnings per share, assuming dilution, was $0.16 per share. Non-GAAP net income and non-GAAP earnings per share exclude stock-based compensation expense, acquisition-related expenses, amortizations and adjustments, restructuring expenses, amortization of pension actuarial losses, valuation allowance related to our deferred tax assets, non-cash deferred compensation, and other one-time adjustments. The reconciliations between GAAP net income and earnings per share to non-GAAP net income and non-GAAP earnings per share are set forth in the table provided below.

[0001564590-20-049784:8k_2_02:7]
ADTRAN Chairman and Chief Executive Officer Tom Stanton stated, “We had a solid quarter with outstanding customer traction, securing 38 new service provider customers, ranging from global Tier-1 operators to electric co-operatives and utilities, municipalities, cable MSOs and regional broadband providers. We are also making great progress with the Tier 1 fiber access projects we announced earlier this year and we continue to have very strong momentum on new customer acquisition across a broad base of market segments.  We continue to introduce new fiber access and software innovations that have been well timed as we enter the early stages of a generational communications infrastructure network upgrade cycle driven by confluence of favorable government, regulatory, technology and competitive factors.”

[0001564590-20-049784:8k_2_02:8]
The Company also announced that its Board of Directors declared a cash dividend for the third quarter of 2020. The quarterly cash dividend of $0.09 per common share is to be paid to the Company’s stockholders of record as of the close of business on November 17, 2020. The payment date will be December 1, 2020.

[0001564590-20-049784:8k_2_02:9]
The Company confirmed that it will hold a conference call to discuss its third quarter results on Tuesday, November 3, 2020, at 9:30 a.m. Central Time. ADTRAN will webcast this conference call. To listen, simply visit ADTRAN’s Investor Relations site at www.adtran.com/investor approximately 10 minutes prior to the start of the call, click on the event “ADTRAN releases 3rd Quarter Financial Results and Conference Call”, and click on the Webcast link.

[0001564590-20-049784:8k_2_02:10]
An online replay of the Company’s conference call, as well as the text of the Company's conference call, will be available on the Investor Relations site approximately 24 hours following the call and will remain available for at least 12 months. For more information, visit www.investors.adtran.com or email at investor.relations@adtran.com.

[0001564590-20-049784:8k_2_02:11]
At ADTRAN, we believe amazing things happen when people connect. From the cloud edge to the subscriber edge, we help communications service providers around the world manage and scale services that connect people, places and things to advance human progress. Whether rural or urban, domestic or international, telco or cable, enterprise or residential—ADTRAN solutions optimize existing technology infrastructures and create new, multi-gigabit platforms that leverage cloud economics, data analytics, machine learning and open ecosystems—the future of global networking. Find more at ADTRAN.com, LinkedIn and Twitter.

[0001564590-20-049784:8k_2_02:12]
This press release contains forward-looking statements, generally identified by the use of words such as “believe,” “expect,” “intend,” “estimate,” “anticipate,” “will,” “may,” “could” and similar expressions, which forward-looking statements reflect management’s best judgment based on factors currently known. However, these statements involve risks and uncertainties, including: (i) those risks and uncertainties related to the continued spread and extent of the impact of the COVID-19 global pandemic, including the speed, depth, geographic reach and duration of the spread, which could lead to a decrease in demand for the Company’s products and services, and which has disrupted, and could lead to further disruptions in, the Company’s supply chain, adversely impacting the operations and financial condition of the Company and its customers; actions that have been taken and that may be taken by the Company, its customers, suppliers and counterparties in response to the pandemic, including the implementation of alternative work arrangements for employees, which may delay the timing of some orders and expected deliveries and which may impact the Company’s ability to mitigate inefficiencies, delays and additional costs in the Company’s product development, sales, marketing and customer service efforts; the legal, regulatory and administrative developments that occur at the federal, state and local levels and in foreign jurisdictions in response to the pandemic, including travel bans and restrictions, quarantines, shelter-in-place orders, and business limitations and shutdowns; potential disruptions, breaches, or other incidents affecting the proper operation, availability or security of the Company’s or its partners’ information systems; declines in revenues due to declining customer demand and deteriorating macroeconomic conditions; potential increased expenses related to labor, raw materials, freight or other expenditures; the impact of the COVID-19 pandemic on the

[0001564590-20-049784:8k_2_02:13]
Company’s liquidity, as well as risks associated with disruptions in the financial markets and the business of financial institutions as a result of the COVID-19 pandemic which could impact the Company from a financial perspective; (ii) those risks and uncertainties related to evolving U.S. and foreign laws and regulations regarding privacy, data protection and other matters, including uncertainty and potential additional compliance obligations arising from the Court of Justice of the European Union’s recent issuance of a decision that invalidated the EU-U.S. Privacy Shield framework as a basis for transfers of personal data from the EU to the U.S.; and (iii) the other risks detailed in the Company’s Annual Report on Form 10-K for the year ended December 31, 2019 and in the Company’s Quarterly Report on Form 10-Q for the quarter ended June 30, 2020. These risks and uncertainties could cause actual results to differ materially from those in the forward-looking statements included in this press release.

[0001564590-20-049784:8k_2_02:14]
To provide additional transparency, we have disclosed in the table below non-GAAP operating income (loss), which has been reconciled to operating income (loss), and non-GAAP net income (loss) and non-GAAP earnings (loss) per share - basic and diluted, which have been reconciled to net income (loss) and earnings (loss) per share - basic and diluted, in each case as reported based on Generally Accepted Accounting Principles in the United States (“U.S. GAAP”). These non-GAAP financial measures exclude certain items which management believes are not reflective of the ongoing operating performance of the business. We believe this information is useful in providing period-to-period comparisons of the results of our ongoing operations. Additionally, these measures are used by management in our ongoing planning and annual budgeting processes. The presentation of non-GAAP operating income (loss), non-GAAP net income (loss) and non-GAAP earnings (loss) per share - basic and diluted, when combined with the U.S. GAAP presentation of operating income (loss), net income (loss) and earnings (loss) per share - basic and diluted, is beneficial to the overall understanding of ongoing operating performance of the Company.

[0001564590-20-049784:8k_2_02:15]
These non-GAAP financial measures are not prepared in accordance with, or an alternative for, U.S. GAAP and therefore should not be considered in isolation or as a substitution for analysis of our results as reported under U.S. GAAP. Additionally, our calculation of non-GAAP operating income (loss), non-GAAP net income (loss) and non-GAAP earnings (loss) per share - basic and diluted, may not be comparable to similar measures calculated by other companies.

[0001564590-20-049784:8k_2_02:16]
Condensed Consolidated Balance Sheets

[0001564590-20-049784:8k_2_02:17]
(Unaudited)

[0001564590-20-049784:8k_2_02:18]
(In thousands)

[0001564590-20-049784:8k_2_02:19]
|  | September 30, |  |  | December 31, |  |
|  | 2020 |  |  | 2019 |  |
| Assets |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 71,081 |  |  | $ | 73,773 |  |
| Restricted cash |  | 322 |  |  |  | — |  |
| Short-term investments |  | 6,180 |  |  |  | 33,243 |  |
| Accounts receivable, net |  | 100,223 |  |  |  | 90,531 |  |
| Other receivables |  | 22,899 |  |  |  | 16,566 |  |
| Inventory |  | 120,260 |  |  |  | 98,305 |  |
| Prepaid expenses and other current assets |  | 8,374 |  |  |  | 7,892 |  |
| Total Current Assets |  | 329,339 |  |  |  | 320,310 |  |
| Property, plant and equipment, net |  | 64,353 |  |  |  | 68,086 |  |
| Deferred tax assets, net |  | 7,865 |  |  |  | 7,561 |  |
| Goodwill |  | 6,968 |  |  |  | 6,968 |  |
| Intangibles, net |  | 24,465 |  |  |  | 27,821 |  |
| Other assets |  | 20,409 |  |  |  | 19,883 |  |
| Long-term investments |  | 78,016 |  |  |  | 94,489 |  |
| Total Assets | $ | 531,415 |  |  | $ | 545,118 |  |
| Liabilities and Stockholders' Equity |  |  |  |  |  |  |  |
| Accounts payable | $ | 59,886 |  |  | $ | 44,870 |  |
| Bonds payable |  | — |  |  |  | 24,600 |  |
| Unearned revenue |  | 13,379 |  |  |  | 11,963 |  |
| Accrued expenses and other liabilities |  | 13,173 |  |  |  | 13,876 |  |
| Accrued wages and benefits |  | 17,228 |  |  |  | 13,890 |  |
| Income tax payable, net |  | 3,346 |  |  |  | 3,512 |  |
| Total Current Liabilities |  | 107,012 |  |  |  | 112,711 |  |
| Non-current unearned revenue |  | 6,694 |  |  |  | 6,012 |  |
| Pension liability |  | 16,282 |  |  |  | 15,886 |  |
| Deferred compensation liability |  | 22,957 |  |  |  | 21,698 |  |
| Other non-current liabilities |  | 8,877 |  |  |  | 8,385 |  |
| Total Liabilities |  | 161,822 |  |  |  | 164,692 |  |
| Stockholders' Equity |  | 369,593 |  |  |  | 380,426 |  |
| Total Liabilities and Stockholders' Equity | $ | 531,415 |  |  | $ | 545,118 |  |

[0001564590-20-049784:8k_2_02:20]
Condensed Consolidated Statements of Income (Loss)

[0001564590-20-049784:8k_2_02:21]
(Unaudited)

[0001564590-20-049784:8k_2_02:22]
(In thousands, except per share amounts)

[0001564590-20-049784:8k_2_02:23]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |  |
|  |  | September 30, |  |  | September 30, |  |  |
|  |  | 2020 |  |  | 2019 |  |  | 2020 |  |  | 2019 |  |  |
| Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Network Solutions |  | $ | 115,229 |  |  | $ | 94,018 |  |  | $ | 323,924 |  |  | $ | 359,007 |  |  |
| Services & Support |  |  | 17,914 |  |  |  | 20,074 |  |  |  | 52,457 |  |  |  | 55,267 |  |  |
| Total Sales |  |  | 133,143 |  |  |  | 114,092 |  |  |  | 376,381 |  |  |  | 414,274 |  |  |
| Cost of Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Network Solutions |  |  | 62,795 |  |  |  | 56,444 |  |  |  | 178,492 |  |  |  | 207,353 |  |  |
| Services & Support |  |  | 11,386 |  |  |  | 11,317 |  |  |  | 33,855 |  |  |  | 34,963 |  |  |
| Total Cost of Sales |  |  | 74,181 |  |  |  | 67,761 |  |  |  | 212,347 |  |  |  | 242,316 |  |  |
| Gross Profit |  |  | 58,962 |  |  |  | 46,331 |  |  |  | 164,034 |  |  |  | 171,958 |  |  |
| Selling, general and administrative expenses |  |  | 27,205 |  |  |  | 30,912 |  |  |  | 84,624 |  |  |  | 99,663 |  |  |
| Research and development expenses |  |  | 27,223 |  |  |  | 31,835 |  |  |  | 85,794 |  |  |  | 95,546 |  |  |
| Asset impairments |  |  | — |  |  |  | 3,872 |  |  |  | 65 |  |  |  | 3,872 |  |  |
| Gain on contingency |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (1,230 | ) |  |
| Operating Income (Loss) |  |  | 4,534 |  |  |  | (20,288 | ) |  |  | (6,449 | ) |  |  | (25,893 | ) |  |
| Interest and dividend income |  |  | 344 |  |  |  | 610 |  |  |  | 1,031 |  |  |  | 1,893 |  |  |
| Interest expense |  |  | — |  |  |  | (128 | ) |  |  | (1 | ) |  |  | (382 | ) |  |
| Net investment gain (loss) |  |  | 2,844 |  |  |  | (216 | ) |  |  | 1,819 |  |  |  | 8,195 |  |  |
| Other income (expense), net |  |  | (1,679 | ) |  |  | 1,616 |  |  |  | (2,307 | ) |  |  | 2,266 |  |  |
| Income (Loss) Before Income Taxes |  |  | 6,043 |  |  |  | (18,406 | ) |  |  | (5,907 | ) |  |  | (13,921 | ) |  |
| Income tax (expense) benefit |  |  | (562 | ) |  |  | (27,717 | ) |  |  | 2,171 |  |  |  | (27,437 | ) |  |
| Net Income (Loss) |  | $ | 5,481 |  |  | $ | (46,123 | ) |  | $ | (3,736 | ) |  | $ | (41,358 | ) |  |
| Weighted average shares outstanding – basic |  |  | 47,957 |  |  |  | 47,824 |  |  |  | 47,957 |  |  |  | 47,803 |  |  |
| Weighted average shares outstanding – diluted |  |  | 48,424 |  | (1) |  | 47,824 |  |  |  | 47,957 |  |  |  | 47,803 |  |  |
| Earnings (loss) per common share – basic |  | $ | 0.11 |  |  | $ | (0.96 | ) |  | $ | (0.08 | ) |  | $ | (0.87 | ) |  |
| Earnings (loss) per common share – diluted |  | $ | 0.11 |  | (1) | $ | (0.96 | ) |  | $ | (0.08 | ) |  | $ | (0.87 | ) |  |

[0001564590-20-049784:8k_2_02:24]
(1) Assumes exercise of dilutive stock options calculated under the treasury stock method.

[0001564590-20-049784:8k_2_02:25]
Condensed Consolidated Statements of Cash Flows

[0001564590-20-049784:8k_2_02:26]
(Unaudited)

[0001564590-20-049784:8k_2_02:27]
(In thousands)

[0001564590-20-049784:8k_2_02:28]
|  |  | Nine Months Ended |  |
|  |  | September 30, |  |
|  |  | 2020 |  |  | 2019 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net loss |  | $ | (3,736 | ) |  | $ | (41,358 | ) |
| Adjustments to reconcile net loss to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 12,525 |  |  |  | 13,315 |  |
| Asset impairments |  |  | 65 |  |  |  | 3,872 |  |
| Amortization of net premium on available-for-sale investments |  |  | 90 |  |  |  | (86 | ) |
| Net gain on long-term investments |  |  | (1,819 | ) |  |  | (8,195 | ) |
| Net loss on disposal of property, plant and equipment |  |  | 105 |  |  |  | 58 |  |
| Gain on contingency |  |  | — |  |  |  | (1,230 | ) |
| Gain on life insurance proceeds |  |  | — |  |  |  | (1,000 | ) |
| Stock-based compensation expense |  |  | 5,056 |  |  |  | 5,184 |  |
| Deferred income taxes |  |  | (1 | ) |  |  | 30,421 |  |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  |  | (9,131 | ) |  |  | 7,603 |  |
| Other receivables |  |  | (6,224 | ) |  |  | 17,645 |  |
| Inventory |  |  | (21,170 | ) |  |  | (5,998 | ) |
| Prepaid expenses and other assets |  |  | (672 | ) |  |  | (10,071 | ) |
| Accounts payable, net |  |  | 14,204 |  |  |  | (5,569 | ) |
| Accrued expenses and other liabilities |  |  | 5,618 |  |  |  | 10,564 |  |
| Income taxes payable |  |  | (227 | ) |  |  | (5,073 | ) |
| Net cash provided by (used in) operating activities |  |  | (5,317 | ) |  |  | 10,082 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (5,082 | ) |  |  | (6,008 | ) |
| Proceeds from sales and maturities of available-for-sale investments |  |  | 86,145 |  |  |  | 38,561 |  |
| Purchases of available-for-sale investments |  |  | (42,641 | ) |  |  | (37,223 | ) |
| Acquisition of note receivable |  |  | (523 | ) |  |  | — |  |
| Life insurance proceeds received |  |  | — |  |  |  | 1,000 |  |
| Acquisition of business |  |  | — |  |  |  | 13 |  |
| Net cash provided by (used in) investing activities |  |  | 37,899 |  |  |  | (3,657 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Dividend payments |  |  | (12,993 | ) |  |  | (12,908 | ) |
| Repayment of bonds payable |  |  | (24,600 | ) |  |  | — |  |
| Proceeds from stock option exercises |  |  | — |  |  |  | 526 |  |
| Purchases of treasury stock |  |  | — |  |  |  | (184 | ) |
| Net cash used in financing activities |  |  | (37,593 | ) |  |  | (12,566 | ) |
| Net decrease in cash, cash equivalents and restricted cash |  |  | (5,011 | ) |  |  | (6,141 | ) |
| Effect of exchange rate changes |  |  | 2,641 |  |  |  | (2,956 | ) |
| Cash, cash equivalents and restricted cash, beginning of period |  |  | 73,773 |  |  |  | 105,504 |  |
| Cash, cash equivalents and restricted cash, end of period |  | $ | 71,403 |  |  | $ | 96,407 |  |
| Supplemental disclosure of non-cash investing activities: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment included in accounts payable |  | $ | 442 |  |  | $ | 135 |  |

[0001564590-20-049784:8k_2_02:29]
Supplemental Information

[0001564590-20-049784:8k_2_02:30]
Reconciliation of Operating Income (Loss) to Non-GAAP Operating Income (Loss)

[0001564590-20-049784:8k_2_02:31]
(Unaudited)

[0001564590-20-049784:8k_2_02:32]
|  |  | Three Months Ended September 30, |  |  |  | Nine Months ended September 30, |  |  |
|  |  | 2020 |  |  | 2019 |  |  |  | 2020 |  |  | 2019 |  |  |
| Operating Income (Loss) |  | $ | 4,534 |  |  | $ | (20,288 | ) |  |  | $ | (6,449 | ) |  | $ | (25,893 | ) |  |
| Acquisition related expenses, amortizations and adjustments |  |  | 1,042 |  | (1) |  | 1,343 |  | (6) |  |  | 3,499 |  | (10) |  | 4,346 |  | (13) |
| Stock-based compensation expense |  |  | 1,610 |  | (2) |  | 1,871 |  | (7) |  |  | 5,056 |  | (11) |  | 5,184 |  | (14) |
| Restructuring expenses |  |  | 1,903 |  | (3) |  | 1,195 |  | (8) |  |  | 3,648 |  | (12) |  | 4,658 |  | (15) |
| Deferred compensation adjustments |  |  | 791 |  | (4) |  | (576 | ) | (4) |  |  | 765 |  | (4) |  | 2,231 |  | (4) |
| Asset impairments |  |  | — |  |  |  | 3,872 |  | (9) |  |  | 65 |  | (9) |  | 3,872 |  | (9) |
| Gain on contingency |  |  | — |  |  |  | — |  |  |  |  | — |  |  |  | (1,230 | ) | (16) |
| Settlement income |  |  | (28 | ) | (5) |  | — |  |  |  |  | (28 | ) | (5) |  | (746 | ) | (5) |
| Non-GAAP Operating Income (Loss) |  | $ | 9,852 |  |  | $ | (12,583 | ) |  |  | $ | 6,556 |  |  | $ | (7,578 | ) |  |

[0001564590-20-049784:8k_2_02:33]
(1) $0.6 million is included in selling, general and administrative expenses and $0.5 million is included in research and development expenses on the condensed consolidated statements of income.

[0001564590-20-049784:8k_2_02:34]
(2) $0.1 million is included in total cost of sales, $0.9 million is included in selling, general and administrative expenses and $0.6 million is included in research and development expenses on the condensed consolidated statements of income.

[0001564590-20-049784:8k_2_02:35]
(3) $0.2 million is included in total cost of sales, $1.1 million is included in selling, general and administrative expenses and $0.6 million is included in research and development expenses on the condensed consolidated statements of income.

[0001564590-20-049784:8k_2_02:36]
(4) Includes non-cash change in fair value of equity investments held in the ADTRAN, Inc. Deferred Compensation Program for Employees per ASU 2016-01, all of which is included in selling, general and administrative expenses on the condensed consolidated statement of income.

[0001564590-20-049784:8k_2_02:37]
(5)  Includes income related to certain freight forwarder claim settlements, all of which is included in total cost of sales on the condensed consolidated statements of income.

[0001564590-20-049784:8k_2_02:38]
(6) $0.3 million is included in total cost of sales, $0.5 million is included in selling, general and administrative expenses and $0.5 million is included in research and development expenses on the condensed consolidated statements of income.

[0001564590-20-049784:8k_2_02:39]
(7) $0.1 million is included in total cost of sales, $1.1 million is included in selling, general and administrative expenses and $0.7 million is included in research and development expenses on the condensed consolidated statements of income.

[0001564590-20-049784:8k_2_02:40]
(8) $0.1 million is included in total cost of sales, $0.5 million is included in selling, general and administrative expenses and $0.6 million is included in research and development expenses on the condensed consolidated statements of income.

[0001564590-20-049784:8k_2_02:41]
(9) Includes abandonment of certain information technology projects.

[0001564590-20-049784:8k_2_02:42]
(10) $0.3 million is included in total cost of sales, $1.7 million is included in selling, general and administrative expenses and $1.5 million is included in research and development expenses on the condensed consolidated statements of income.

[0001564590-20-049784:8k_2_02:43]
(11) $0.3 million is included in total cost of sales, $3.0 million is included in selling, general and administrative expenses and $1.8 million is included in research and development expenses on the condensed consolidated statements of income.

[0001564590-20-049784:8k_2_02:44]
(12) $0.3 million is included in total cost of sales, $1.6 million is included in selling, general and administrative expenses and $1.7 million is included in research and development expenses on the condensed consolidated statements of income.

[0001564590-20-049784:8k_2_02:45]
(13) $1.3 million is included in total cost of sales, $1.6 million is included in selling, general and administrative expenses and $1.4 million is included in research and development expenses on the condensed consolidated statements of income.

[0001564590-20-049784:8k_2_02:46]
(14) $0.3 million is included in total cost of sales, $2.9 million is included in selling, general and administrative expenses and $2.0 million is included in research and development expenses on the condensed consolidated statements of income.

[0001564590-20-049784:8k_2_02:47]
(15) $0.8 million is included in total cost of sales, $2.1 million is included in selling, general and administrative expenses and $1.8 million is included in research and development expenses on the condensed consolidated statements of income.

[0001564590-20-049784:8k_2_02:48]
(16) Includes gain related to unearned contingent liabilities recognized upon the acquisition of a business in November 2018.

[0001564590-20-049784:8k_2_02:49]
Supplemental Information

[0001564590-20-049784:8k_2_02:50]
Reconciliation of Net Income (Loss) and Earnings (Loss) per Common Share – Basic and Diluted to Non-GAAP

[0001564590-20-049784:8k_2_02:51]
Net Income (Loss) and Non-GAAP Earnings (Loss) per Common Share – Basic and Diluted

[0001564590-20-049784:8k_2_02:52]
(Unaudited)

[0001564590-20-049784:8k_2_02:53]
|  |  | Three Months Ended September 30, |  |  |  | Nine Months ended September 30, |  |
|  |  | 2020 |  |  | 2019 |  |  |  | 2020 |  |  |  |  | 2019 |  |
| Net Income (Loss) |  | $ | 5,481 |  |  | $ | (46,123 | ) |  |  | $ | (3,736 | ) |  |  |  | $ | (41,358 | ) |
| Acquisition related expenses, amortizations and adjustments |  |  | 1,042 |  |  |  | 1,343 |  |  |  |  | 3,499 |  |  |  |  |  | 4,346 |  |
| Stock-based compensation expense |  |  | 1,610 |  |  |  | 1,871 |  |  |  |  | 5,056 |  |  |  |  |  | 5,184 |  |
| Restructuring expenses |  |  | 1,903 |  |  |  | 1,195 |  |  |  |  | 3,648 |  |  |  |  |  | 4,658 |  |
| Pension expense(1) |  |  | 248 |  |  |  | 198 |  |  |  |  | 720 |  |  |  |  |  | 600 |  |
| Deferred compensation adjustments(2) |  |  | (90 | ) |  |  | — |  |  |  |  | (1,432 | ) |  | (3 | ) |  | — |  |
| Valuation allowance |  |  | (956 | ) |  |  | 37,055 |  |  |  |  | 2,622 |  |  |  |  |  | 37,055 |  |
| Asset impairments |  |  | — |  |  |  | 3,872 |  |  |  |  | 65 |  |  |  |  |  | 3,872 |  |
| Gain on contingency |  |  | — |  |  |  | — |  |  |  |  | — |  |  |  |  |  | (1,230 | ) |
| Settlement income |  |  | (28 | ) |  |  | — |  |  |  |  | (28 | ) |  |  |  |  | (746 | ) |
| Tax effect of adjustments to net income (loss) |  |  | (1,279 | ) |  |  | (2,186 | ) |  |  |  | (3,089 | ) |  |  |  |  | (4,424 | ) |
| Non-GAAP Net Income (Loss) |  | $ | 7,931 |  |  | $ | (2,775 | ) |  |  | $ | 7,325 |  |  |  |  | $ | 7,957 |  |
| Weighted average shares outstanding – basic |  |  | 47,957 |  |  |  | 47,824 |  |  |  |  | 47,957 |  |  |  |  |  | 47,803 |  |
| Weighted average shares outstanding – diluted |  |  | 48,424 |  |  |  | 47,824 |  |  |  |  | 47,957 |  |  |  |  |  | 47,803 |  |
| Earnings (loss) per common share - basic |  | $ | 0.11 |  |  | $ | (0.96 | ) |  |  | $ | (0.08 | ) |  |  |  | $ | (0.87 | ) |
| Earnings (loss) per common share - diluted |  | $ | 0.11 |  |  | $ | (0.96 | ) |  |  | $ | (0.08 | ) |  |  |  | $ | (0.87 | ) |
| Non-GAAP earnings (loss) per common share - basic |  | $ | 0.17 |  |  | $ | (0.06 | ) |  |  | $ | 0.15 |  |  |  |  | $ | 0.17 |  |
| Non-GAAP earnings (loss) per common share - diluted |  | $ | 0.16 |  |  | $ | (0.06 | ) |  |  | $ | 0.15 |  |  |  |  | $ | 0.17 |  |

[0001564590-20-049784:8k_2_02:54]
(1) Includes amortization of actuarial losses related to the Company's pension plan for employees in certain foreign countries.

[0001564590-20-049784:8k_2_02:55]
(2) Includes non-cash change in fair value of equity investments held in deferred compensation plans offered to certain employees.

[0001564590-20-049784:8k_2_02:56]
(3) Includes net investment gain of $1.5 million related to the out of period remeasurement to historical cost basis of certain long-term investments held in the Company's stock as part of one of these deferred compensation plans.
