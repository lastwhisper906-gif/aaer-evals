# ADTN MD&A — 0000950170-25-075374


## mdna

[0000950170-25-075374:mdna:1]
[same as prior period, unchanged from 0000950170-24-125685:mdna:1]

[0000950170-25-075374:mdna:2]
The following discussion should be read in conjunction with the Condensed Consolidated Financial Statements and the related notes that appear in Part I, Item 1 of this document. In addition, the following discussion should be read in conjunction with our audited consolidated financial statements for the year ended December 31, 2024, Part II, Item 7, Management’s Discussion and Analysis of Financial Condition and Results of Operations, Part I, Item 1A, Risk Factors, and Part I, Item 1, Business, included in Amendment No. 1 to our Annual Report on Form 10-K for the year ended December 31, 2024, filed with the SEC on May 20, 2025 (the "2024 Form 10-K/A").

[0000950170-25-075374:mdna:3]
As discussed in the financial statements as of and for the year ended December 31, 2024 included in our 2024 Form 10-K/A, we identified errors in our previously issued financial statements. The identified errors impacted the Condensed Consolidated Financial Statements as of and for the three months ended March 31, 2024, among other periods as previously disclosed. See Note 1 and 18 to Condensed Consolidated Financial Statements included in Part I, Item, 1 for additional information.

[0000950170-25-075374:mdna:4]
This discussion is designed to provide the reader with information that will assist in understanding our Condensed Consolidated Financial Statements, the changes in certain key items in those financial statements from period to period, and the primary factors that accounted for those changes, as well as how certain accounting principles affect our Condensed Consolidated Financial Statements. See “Cautionary Note Regarding Forward-Looking Statements” on page 5 of this report for a description of important factors that could cause actual results to differ from expected results. See also Part 1, Item 1A, Risk Factors, of the 2024 Form 10‑K/A and Part II, Item 1A, Risk Factors of this Form 10-Q.

[0000950170-25-075374:mdna:5]
Unless the context otherwise indicates or requires, references in this Quarterly Report on Form 10-Q to "Adtran", the “Company,” “we”, “us” and “our” refer to ADTRAN Holdings, Inc. and its consolidated subsidiaries. Furthermore, unless the context otherwise indicates or requires, references in this Quarterly Report on Form 10-Q to “Adtran Networks” refer to Adtran Networks SE (formerly ADVA Optical Networking SE).

[0000950170-25-075374:mdna:6]
[same as prior period, unchanged from 0000950170-24-125685:mdna:5]

[0000950170-25-075374:mdna:7]
The Company is a leading global provider of networking and communications platforms, software, systems and services focused on carrier networks, private enterprise networks and mission critical infrastructure. It is serving a diverse domestic and international customer base in multiple countries that includes Large, Medium and Small Service Providers, alternative Service Providers, such as utilities, municipalities and fiber overbuilders; cable/MSOs; SMBs; distributed enterprises, including Fortune 500 companies with sophisticated business continuity applications; and federal, state and local government agencies.

[0000950170-25-075374:mdna:8]
Our innovative solutions and services enable voice, data, video and internet-communications across a variety of network infrastructures and are currently in use by millions worldwide. We support our customers through our direct global sales organization and our distribution networks. Our success depends upon our ability to have customers adopt our technology, increase unit volume and market share through the introduction of new products and succeeding generations of products having optimal selling prices and increased functionality as compared to both the prior generation of a product and the products of competitors in order to gain market share. To service our customers and grow revenue, we are continually conducting research and developing new products addressing customer needs and testing those products for the specific requirements of the particular customers. We offer a broad portfolio of flexible software and hardware network solutions and services that enable Service Providers to meet today’s service demands while enabling them to transition to the fully converged, scalable, highly-automated, cloud-controlled voice, data, internet and video network of the future. In addition to our global headquarters in Huntsville, Alabama, and our European headquarters in Munich, Germany, we have sales and research and development facilities in multiple strategic global locations.

[0000950170-25-075374:mdna:9]
The Company solely owns ADTRAN, Inc. and is the majority shareholder of Adtran Networks (formerly ADVA Optical Networking SE). Adtran is a leading global provider of open, disaggregated networking and communications solutions. Adtran Networks is a global provider of network solutions for wholesale mobile and data center interconnect services. We believe that the combined technology portfolio can best address current and future customer needs for high-speed connectivity from the network core to the end consumer, especially upon the convergence of solutions at the network edge.

[0000950170-25-075374:mdna:10]
[same as prior period, unchanged from 0000950170-24-125685:mdna:9]

[0000950170-25-075374:mdna:11]
[same as prior period, unchanged from 0000950170-24-125685:mdna:10]

[0000950170-25-075374:mdna:12]
[same as prior period, unchanged from 0000950170-24-125685:mdna:11]

[0000950170-25-075374:mdna:13]
[same as prior period, unchanged from 0000950170-24-125685:mdna:12]

[0000950170-25-075374:mdna:14]
[same as prior period, unchanged from 0000950170-24-125685:mdna:13]

[0000950170-25-075374:mdna:15]
[same as prior period, unchanged from 0000950170-24-125685:mdna:14]

[0000950170-25-075374:mdna:16]
Under the DPLTA, subject to certain limitations pursuant to applicable law and the specific terms of the DPLTA, (i) the Company is
entitled to issue binding instructions to the management board of Adtran Networks, (ii) Adtran Networks will transfer its annual profit to the Company, subject to, among other things, the creation or dissolution of certain reserves, and (iii) the Company will absorb the annual net loss incurred by Adtran Networks. The Company’s payment obligation in satisfaction of the requirement that it absorb Adtran Networks’ annual net loss applied to the net loss generated by Adtran Networks in 2024, and it will apply to any net loss generated by Adtran Networks in 2025.

[0000950170-25-075374:mdna:17]
Additionally, and subject to certain limitations pursuant to applicable law and the specific terms of the DPLTA, the DPLTA provides that Adtran Networks shareholders (other than us) be offered, at their election, (i) to put their Adtran Networks shares to the Company in exchange for compensation in cash of €17.21 per share plus guaranteed interest ("Exit Compensation"), or (ii) to remain Adtran Networks shareholders and receive a recurring compensation in cash of €0.52 per share for each full fiscal year of Adtran Networks (“Annual Recurring Compensation”). The guaranteed interest component under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid. The guaranteed interest rate is 5.0% plus a variable component that was 2.27% as of March 31, 2025. The Annual Recurring Compensation is due on the third banking day following the ordinary general shareholders’ meeting of Adtran Networks for the respective preceding fiscal year (but in any event within eight months following expiration of the fiscal year). With respect to the 2024 fiscal year, Adtran Networks’ ordinary general shareholder meeting is scheduled for June 27, 2025, and therefore, the Annual Recurring Compensation will be due on July 2, 2025. The adequacy of both forms of compensation has been challenged by minority shareholders of Adtran Networks via court-led appraisal proceedings under German law, and it is possible that the courts in such appraisal proceedings may adjudicate a higher Exit Compensation or Annual Recurring Compensation (in each case, including interest thereon) than agreed upon in the DPLTA.

[0000950170-25-075374:mdna:18]
The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that were initiated in 2023 in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger). The Company expects to receive a ruling on a procedural matter in the DPLTA appraisal proceedings during the latter half of 2025 or 2026, which ruling, depending on outcome, will likely be appealed and may take 6-12 months to be decided on appeal. The Company does not expect that a trial on the merits of the DPLTA appraisal proceedings will commence until the procedural matter has been resolved. The proceeding for the trial on the merits of the DPLTA will likely take a minimum of 12 months for a ruling and such ruling may likewise be appealed, which would be expected to take an additional 12-24 months to be resolved. Accordingly, the Company does not expect a final decision on the DPLTA appraisal proceedings to be rendered and published prior to 2027, and most likely not until 2028 or beyond. For the three months ended March 31, 2025 and 2024, less than one thousand shares of Adtran Networks stock were tendered to the Company and Exit Compensation payments of approximately €12 thousand and €4 thousand, respectively, or approximately $13 thousand and $5 thousand based on the applicable exchange rates at the time of the transaction, were paid to Adtran Networks shareholders. Between March 31, 2025 and the date of this report, 0.4 million shares of Adtran Networks stock were tendered to the Company and Exit Compensation payments of approximately €7.0 million, or approximately $7.5 million based on the applicable exchange rate at the time of the transactions, will be paid to Adtran Networks shareholders.

[0000950170-25-075374:mdna:19]
In addition to our cash and cash equivalents and the credit facility, we may fund a portion or all of the Exit Compensation through the sale of securities or additional alternative funding sources, if available. There can be no assurances that we would be successful in effecting these actions on commercially reasonable terms or at all. If we cannot raise additional funds as needed, it could have a material adverse impact on our financial results and financial condition.

[0000950170-25-075374:mdna:20]
We currently hold 34,856,611 no-par value bearer shares of Adtran Networks, representing 67.0% of Adtran Networks outstanding shares as of March 31, 2025.

[0000950170-25-075374:mdna:21]
The foregoing description of the DPLTA does not purport to be complete and is qualified in its entirety by reference to the DPLTA, a non-binding English translation of which is incorporated by reference to Exhibit 10.11 included in our 2024 Form 10-K/A.

[0000950170-25-075374:mdna:22]
[same as prior period, unchanged from 0000950170-24-125685:mdna:27]

[0000950170-25-075374:mdna:23]
We ended the first quarter of 2025 with a year-over-year revenue increase of 9.5% as compared to the three months ended March 31, 2024, driven by increased volume of sales activity due to a return of normalized customer spending, increased growth due to fiber expansion brought about by higher service provider spending, vendor consolidation due to a continuing shift away from high-risk vendors, increased demand for modernizing and upgrading critical infrastructure within governments, utilities, large enterprises, and applications, including AI. During the first quarter of 2025, we had one customer with revenues greater than 10.0%, which was an international Service Provider customer and our five largest customers comprised 38.9% of our revenue. Our year-over-year domestic revenue increased by 23.9% due to a return to normalized customer spending and fiber expansion. Internationally, our year-over-year revenue increased by 1.2%, primarily driven by fiber expansion. Our Access & Aggregation, Subscriber Solutions and Optical Networking revenue categories all experienced increased volume of sales activity due to growth across geographies, most product lines, and the continued expansion of our customer base.

[0000950170-25-075374:mdna:24]
Our revenues have fluctuated in recent years and they may continue to fluctuate going forward. However, during the first quarter of 2025, our operating results improved due to slowly stabilizing revenues, improving margins and tight operational cost controls. Additionally, we have taken steps to transform our business into a leaner, more efficient and more profitable company, including the completion of our Business Efficiency Program (other than our aim of selling our headquarters in Huntsville, which we expect to occur within the next 12 months). Nevertheless, our operating expenses are relatively fixed in the short term, and a shortfall in quarterly revenues consequently has previously impacted and may again in the future significantly impact our financial results in a given quarter.

[0000950170-25-075374:mdna:25]
Our operating results have significantly fluctuated and may do so in the future as a result of a number of other factors, including a decline in general economic and market conditions, foreign currency exchange rate movements, inflation, increased competition, customer order patterns, changes in product and services mix, trade policies, timing differences between price decreases and product cost reductions, product warranty returns, expediting costs, tariffs and announcements of new products by us or our competitors. Nevertheless, as stated above, our operating results improved due to slowly stabilizing revenues, improving margins and tight operational cost controls. In addition, we continue to support our customer demand for our products by working with our suppliers, contract manufacturers, distributors, and customers to address and to limit potential disruptions to our operations and order fulfillment. Moreover, maintaining sufficient inventory levels to assure prompt delivery of our products increases the amount of inventory that may become obsolete and increases the risk that the obsolescence of this inventory may have an additional adverse effect on our business and operating results beyond the effects of the most recent inventory write-downs. On the other hand, not maintaining sufficient inventory levels to ensure prompt delivery of our products may cause us to incur expediting costs to meet customer delivery requirements, which may negatively impact our operating results.

[0000950170-25-075374:mdna:26]
The anticipated near-term impact of the Broadband Equity, Access, and Deployment (“BEAD”) Program has decreased following the announcement of a comprehensive federal agency review of BEAD Program priorities, including those related to project technology preferences, and associated delays in state BEAD Program grant awards.

[0000950170-25-075374:mdna:27]
Trade Policy/Tariffs

[0000950170-25-075374:mdna:28]
During the first quarter of 2025 and into May 2025, the U.S. introduced trade policy actions that have increased import tariffs across a wide range of countries at various rates, with certain exemptions. At this time, it remains unclear what additional actions, if any, will be taken by the U.S. or other governments with respect to international trade agreements, the imposition of tariffs on goods imported into the U.S. or exported to other countries, tax policy related to international commerce, increased export control, sanctions and investment restrictions, import or use of foreign communications equipment, or other trade matters. These changes in U.S. trade policy and subsequent retaliatory actions have the potential to materially increase various input costs for the Company. Moreover, related costs and the uncertainty arising from such changes in trade policy may result in shifts in customer behavior, such as decreased demand. These impacts could have a negative effect on our financial results, including our revenue and profitability. To help mitigate this, we have taken steps to diversify our supply chain, manufacturing locations and relationships with suppliers to give us added flexibility. See “Changes in trade policy in the U.S. and other countries, including the imposition of additional tariffs and the resulting consequences, may adversely impact our gross profits, gross margins, results of operations and financial condition,” in Part II, Item 1A “Risk Factors” of this report for further discussion of the risks associated with the changes to U.S. and foreign trade policies.

[0000950170-25-075374:mdna:29]
Foreign Currency

[0000950170-25-075374:mdna:30]
[same as prior period, unchanged from 0000950170-24-125685:mdna:33]

[0000950170-25-075374:mdna:31]
Goodwill Impairment

[0000950170-25-075374:mdna:32]
The Company’s policy is to assess the realizability of assets (long-lived assets, intangibles and goodwill) held within our reporting units and to evaluate such assets for impairment whenever events or changes in circumstances indicate that the carrying amount of such assets may not be recoverable.

[0000950170-25-075374:mdna:33]
No impairment of goodwill was recognized during the three months ended March 31, 2025. During the first quarter of 2024, qualitative factors such as a decrease in the Company’s market capitalization, lower service provider spending and delayed holding patterns of inventory with respect to customers caused us to reduce our forecasts, triggering a quantitative impairment assessment for our reporting units. The Company determined the fair value of the Network Solutions reporting unit using a combination of an income approach and a market-based peer group analysis. The Company determined upon its quantitative impairment assessment to recognize a $297.4 million non-cash goodwill impairment charge for the Network Solutions reporting unit during the three months ended March 31, 2024. The quantitative impairment analysis indicated there was no impairment of the Services & Support goodwill during the three months ended March 31, 2024. There have been no triggering events identified affecting the valuation of goodwill in our Services & Support reporting unit since the first quarter of 2024.

[0000950170-25-075374:mdna:34]
Our historical financial performance is not necessarily a meaningful indicator of future results, and in general, management expects that our financial results may vary from period to period. Factors that could materially affect our business, financial condition or operating results are included in Part I, Item 1A of the 2024 Form 10-K/A and Part II, Item 1A of this Form 10-Q.

[0000950170-25-075374:mdna:35]
BUSINESS EFFICIENCY PROGRAM

[0000950170-25-075374:mdna:36]
On November 6, 2023, due to the uncertainty around the then current macroeconomic environment and its impact on customer spending levels, the Company’s management decided to implement a Business Efficiency Program targeting the reduction of ongoing operating expenses and focusing on capital efficiency. This included certain salary reductions, an early retirement program, a site consolidation plan to include lease impairments and the sale of owned real estate (including the sale of our headquarters in Huntsville), inventory write downs from product discontinuances, and the suspension of the quarterly dividend. Other than the Company's aim of selling its headquarters, the Business Efficiency Program was completed as of December 31, 2024.

[0000950170-25-075374:mdna:37]
During the three months ended March 31, 2024, we recognized $17.1 million of costs related to the Business Efficiency Program. We did not incur any Business Efficiency Program costs during the three months ended March 31, 2025. Future cash payments include previously accrued severance and outplacement fees as well as site consolidation costs that are anticipated to be approximately $3.1 million.

[0000950170-25-075374:mdna:38]
[same as prior period, unchanged from 0000950170-24-125685:mdna:37]

[0000950170-25-075374:mdna:39]
[same as prior period, unchanged from 0000950170-24-125685:mdna:38]

[0000950170-25-075374:mdna:40]
RESULTS OF OPERATIONS – THREE MONTHS ENDED MARCH 31, 2025, COMPARED TO THE THREE MONTHS ENDED MARCH 31, 2024

[0000950170-25-075374:mdna:41]
As discussed in the financial statements as of and for the year ended December 31, 2024 included in our amended 2024 Annual Report on Form 10-K/A, we identified errors in our previously issued financial statements. The identified errors impacted the Condensed Consolidated Financial Statements as of and for the three months ended March 31, 2024, among other periods as previously disclosed. See Note 1 and 18 to Condensed Consolidated Financial Statements included in Part I, Item, 1 for additional information.

[0000950170-25-075374:mdna:42]
[same as prior period, unchanged from 0000950170-24-125685:mdna:40]

[0000950170-25-075374:mdna:43]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
|  |  | 2025 |  |  | 2024 |  |
|  |  |  |  |  | (Restated) |  |
| Revenue |  |  |  |  |  |  |
| Network Solutions |  |  | 81.6 |  | % |  | 80.1 |  |
| Services & Support |  |  | 18.4 |  |  |  | 19.9 |  |
| Total Revenue |  |  | 100.0 |  |  |  | 100.0 |  |
| Cost of Revenue |  |  |  |  |  |  |
| Network Solutions |  |  | 54.2 |  |  |  | 56.7 |  |
| Network Solutions - charges and inventory write-down |  |  | — |  |  |  | 3.9 |  |
| Services & Support |  |  | 7.4 |  |  |  | 8.3 |  |
| Total Cost of Revenue |  |  | 61.6 |  |  |  | 68.9 |  |
| Gross Profit |  |  | 38.4 |  |  |  | 31.1 |  |
| Selling, general and administrative expenses |  |  | 20.3 |  |  |  | 26.1 |  |
| Research and development expenses |  |  | 19.7 |  |  |  | 26.6 |  |
| Goodwill impairment |  |  | — |  |  |  | 131.5 |  |
| Operating Loss |  |  | (1.6 | ) |  |  | (153.1 | ) |
| Interest and dividend income |  |  | 0.1 |  |  |  | 0.2 |  |
| Interest expense |  |  | (1.9 | ) |  |  | (2.0 | ) |
| Net investment (loss) gain |  |  | (0.7 | ) |  |  | 1.0 |  |
| Other income, net |  |  | 0.4 |  |  |  | 0.6 |  |
| Loss Before Income Taxes |  |  | (3.8 | ) |  |  | (153.4 | ) |
| Income tax benefit |  |  | 0.2 |  |  |  | 8.2 |  |
| Net Loss |  |  | (3.6 | ) | % |  | (145.1 | ) |
| Less: Net Income attributable to non-controlling interest |  |  | 0.9 |  |  |  | 1.1 |  |
| Net Loss attributable to ADTRAN Holdings, Inc. |  |  | (4.5 | ) | % |  | (146.2 | ) |

[0000950170-25-075374:mdna:44]
Revenue

[0000950170-25-075374:mdna:45]
Our revenue increased 9.5% from $226.2 million for the three months ended March 31, 2024, to $247.7 million for the three months ended March 31, 2025, the increase was driven by increased volume of sales activity due to a return of normalized customer spending, increased growth due to fiber expansion brought about by higher service provider spending, vendor consolidation due to a continuing shift away from high-risk vendors, increased demand for modernizing and upgrading critical infrastructure within governments, utilities, large enterprises, and applications, including AI. The increase in revenue by category for the three months ended March 31, 2025, was primarily attributable to a $10.6 million increase in Subscriber Solutions products, and a $7.8 million increase in Access & Aggregation revenue and a $3.1 million increase in Optical Networking Solutions products. All revenue categories experienced increased volume of sales activity due to growth across geographies, most product lines, and the continued expansion of our customer base.

[0000950170-25-075374:mdna:46]
Network Solutions segment revenue increased 11.6% from $181.3 million for the three months ended March 31, 2024, to $202.2 million for the three months ended March 31, 2025. The increase in Network Solutions revenue for the three months ended March 31, 2025, was due to an increase of $11.4 million in volume of sales activity in Subscriber Solutions products, and an increase of $8.1 million in volume of sales activity in Access & Aggregation products and an increase of $1.5 million in volume of sales activity in Optical Networking Solutions products.

[0000950170-25-075374:mdna:47]
Services & Support segment revenue increased 1.4% from $44.9 million for the three months ended March 31, 2024, to $45.5 million for the three months ended March 31, 2025. The increase in revenue for the three months ended March 31, 2025, was primarily attributable a $1.6 million increase in Optical Networking services, partially offset by a $0.7 million decrease for Subscriber Solutions and a $0.2 million decrease in Access & Aggregation.

[0000950170-25-075374:mdna:48]
Domestic revenue increased by 23.9% from $83.3 million for the three months ended March 31, 2024, to $103.2 million for the three months ended March 31, 2025. The increase in domestic revenue for the three months ended March 31, 2025, due to a return to normalized customer spending and fiber expansion.

[0000950170-25-075374:mdna:49]
International revenue, which is defined as revenue generated from the Network Solutions and Services & Support segments provided to a customer outside of the U.S., increased by 1.2% from $142.9 million for the three months ended March 31, 2024 to $144.6 million for the three months ended March 31, 2025. International revenue, as a percentage of total revenue, decreased from 63.2% for the three months ended March 31, 2024, to 58.3% for the three months ended March 31, 2025. The increase in international revenue for the three months ended March 31, 2025, was primarily due to fiber expansion. While international revenue has decreased to approximately 58.3% and 63.2% of total revenues for the three months ended March 31, 2025 and 2024, respectively, the mix of our Network Solutions and Services & Support segments as a percentage of total international revenue remains relatively linear. For the three months ended March 31, 2025, as compared to the three months ended March 31, 2024, changes in foreign currencies relative to the U.S. dollar decreased our net revenue by approximately $1.5 million.

[0000950170-25-075374:mdna:50]
Our ADTRAN, Inc. international revenue is largely focused on broadband infrastructure and is consequently affected by the decisions of our customers as to timing for installation of new technologies, expansion of their networks and/or network upgrades. Our international customers must make these decisions in the regulatory and political environment in which they operate – both nationally and, in some instances, regionally – whether of a multi-country region or a more local region within a country. Our Adtran Networks international revenue is largely focused on the manufacture and selling of networking solutions that are based on three core areas of expertise: fiber-optic transmission technology (cloud interconnect), cloud access technology for rapid creation of innovative services around the network edge and solutions for precise timing and synchronization of networks. In addition, Adtran Networks international operations offers a comprehensive portfolio of network design, implementation and maintenance services to assist operators in the deployment of market-leading networks while reducing costs to maintain these networks.

[0000950170-25-075374:mdna:51]
Cost of Revenue

[0000950170-25-075374:mdna:52]
As a percentage of revenue, cost of revenue decreased from 68.9% for the three months ended March 31, 2024, to 61.6% for the three months ended March 31, 2025. The decrease for the three months ended March 31, 2025 was attributable to a 6.2% decrease in restructuring expense and labor cost efficiencies as a percentage of revenue in connection with our Business Efficiency Program which was completed as of December 31, 2024 (other than our aim of selling our headquarters in Huntsville, which we expect to occur within the next 12 months) a 0.5% decrease in expense as a percentage of revenue attributable to changes in foreign currencies relative to the U.S. dollar and a 0.6% decrease in expense as a percentage of revenue attributable to changes in customer and product mix. For the three months ended March 31, 2025, as compared to the three months ended March 31, 2024, changes in foreign currencies relative to the U.S. dollar decreased our cost of revenue by approximately $0.8 million.

[0000950170-25-075374:mdna:53]
Network Solutions cost of revenue, as a percentage of that segment’s revenue, decreased from 75.6% for the three months ended March 31, 2024, to 66.4% for the three months ended March 31, 2025. The decrease in cost of revenue as a percentage of revenue for the three months ended March 31, 2025 was attributable to a 7.5% decrease in restructuring expense and labor cost efficiencies as a percentage of revenue in connection with our Business Efficiency Program which was completed as of December 31, 2024 (other than our aim of selling our headquarters in Huntsville, which we expect to occur within the next 12 months) a 0.5% decrease in expense as a percentage of revenue attributable to changes in foreign currencies relative to the U.S. dollar, and a 1.2% decrease in expense as a percentage of revenue attributable to changes in customer and product mix.

[0000950170-25-075374:mdna:54]
Services & Support cost of revenue, as a percentage of that segment’s revenue, decreased from 41.9% for the three months ended March 31, 2024, to 40.3% for the three months ended March 31, 2025. The decrease in cost of revenue as a percentage of revenue for the three months ended March 31, 2025, was primarily attributable to a 1.0% decrease in restructuring expense and labor cost efficiencies as a percentage of revenue in connection with our Business Efficiency Program which was completed as of December 31, 2024 (other than our aim of selling our headquarters in Huntsville, which we expect to occur within the next 12 months) and a 0.3% decrease in expense as a percentage of revenue attributable to changes in foreign currencies relative to the U.S. dollar, and a 0.3% decrease in expense as a percentage of revenue attributable to changes in customer and product mix.

[0000950170-25-075374:mdna:55]
[same as prior period, unchanged from 0000950170-24-125685:mdna:56]

[0000950170-25-075374:mdna:56]
Gross Profit

[0000950170-25-075374:mdna:57]
As a percentage of revenue, gross profit increased from 31.1% for the three months ended March 31, 2024, to 38.4% for the three months ended March 31, 2025. The increase for the three months ended March 31, 2025 was primarily attributable to a 6.2% decrease in restructuring expense and labor cost efficiencies as a percentage of revenue in connection with our Business Efficiency Program which

[0000950170-25-075374:mdna:58]
was completed as of December 31, 2024 (other than our aim of selling our headquarters in Huntsville, which we expect to occur within the next 12 months), a 1.1% decrease in expense as a percentage of revenue attributable to changes in foreign currencies relative to the U.S. dollar and a 14.6% increase in gross profit as a percentage of revenue attributable to changes in customer and product mix.

[0000950170-25-075374:mdna:59]
As a percentage of that segment's revenue, Network Solutions gross profit increased from 24.4% for the three months ended March 31, 2024, to 33.6% for the three months ended March 31, 2025. The increase for the three months ended March 31, 2025 was primarily attributable to a 7.5% decrease in restructuring expense and labor cost efficiencies as a percentage of revenue in connection with our Business Efficiency Program which was completed as of December 31, 2024 (other than our aim of selling our headquarters in Huntsville, which we expect to occur within the next 12 months), a 1.2% decrease in expense as a percentage of revenue attributable to changes in foreign currencies relative to the U.S. dollar and a 17.9% increase in gross profit as a percentage of revenue attributable to changes in customer and product mix.

[0000950170-25-075374:mdna:60]
As a percentage of that segment's revenue, Services & Support gross profit increased from 58.1% for the three months ended March 31, 2024, to 59.7% for the three months ended March 31, 2025. The increase was primarily attributable to to a 1.0% decrease in restructuring expense and labor cost efficiencies as a percentage of revenue in connection with our Business Efficiency Program which was completed as of December 31, 2024 (other than our aim of selling our headquarters in Huntsville, which we expect to occur within the next 12 months) and a 0.7% decrease in expense as a percentage of revenue attributable to changes in foreign currencies relative to the U.S. dollar, and a 3.3% increase in expense as a percentage of revenue attributable to changes in customer and product mix.

[0000950170-25-075374:mdna:61]
Selling, General and Administrative Expenses

[0000950170-25-075374:mdna:62]
As a percentage of revenue, selling, general and administrative expenses decreased from 26.1% for the three months ended March 31, 2024, to 20.3% for the three months ended March 31, 2025. Selling, general and administrative expenses as a percentage of revenue will generally fluctuate whenever there is a significant fluctuation in revenue for the periods being compared.

[0000950170-25-075374:mdna:63]
Selling, general and administrative expenses decreased 14.7% from $59.0 million for the three months ended March 31, 2024, to $50.3 million for the three months ended March 31, 2025. Selling, general and administrative expenses include personnel costs for management, accounting, information technology, human resources, sales and marketing, as well as independent auditor, tax and other professional fees, contract services and legal and litigation related costs. The decrease in selling, general and administrative expenses for the three months ended March 31, 2025, compared to the three months ended March 31, 2024, was primarily attributable to the impact of the Company's Business Efficiency Program which was completed as of December 31, 2024 (other than our aim of selling our headquarters in Huntsville, which we expect to occur within the next 12 months) resulting in reduced employee-related costs of $6.7 million. Additionally, the decrease in selling, general and administrative expenses is attributable to a decrease of $2.2 million in the amortization of intangible assets related to the Business Combination with Adtran Networks. For the three months ended March 31, 2025, as compared to the three months ended March 31, 2024, changes in foreign currencies relative to the U.S dollar decreased our selling, general and administrative expenses by approximately $0.7 million.

[0000950170-25-075374:mdna:64]
Research and Development Expenses

[0000950170-25-075374:mdna:65]
As a percentage of revenue, research and development expenses decreased from 26.6% for the three months ended March 31, 2024, to 19.7% for the three months ended March 31, 2025. Research and development expenses as a percentage of revenue will generally fluctuate whenever there are incremental product development activities or significant fluctuations in revenue for the periods being compared.

[0000950170-25-075374:mdna:66]
Research and development expenses decreased 18.9% from $60.2 million for the three months ended March 31, 2024, to $48.9 million for the three months ended March 31, 2025. The decrease in research and development expenses for the three months ended March 31, 2025, was primarily attributable to the impact of the Company's Business Efficiency Program which was completed as of December 31, 2024 (other than our aim of selling our headquarters in Huntsville, which we expect to occur within the next 12 months) resulting in reduced its employee-related costs of $8.5 million, reduced contract services of $0.7 million and reduced lease costs of $0.6 million. For the three months ended March 31, 2025, as compared to the three months ended March 31, 2024, changes in foreign currencies relative to the U.S. dollar decreased our research and development expenses by approximately $0.4 million.

[0000950170-25-075374:mdna:67]
Adtran Networks has arrangements with governmental entities for the purpose of obtaining funding for research and development activities. The Company classifies government grants received under these arrangements as a reduction to research and development expenses incurred. For the three months ended March 31, 2025 and 2024, the Company recognized $2.2 million and 1.9 million as a reduction of research and development expense, respectively.

[0000950170-25-075374:mdna:68]
[same as prior period, unchanged from 0000950170-24-125685:mdna:70]

[0000950170-25-075374:mdna:69]
Goodwill Impairment

[0000950170-25-075374:mdna:70]
No goodwill impairment was recognized during the first quarter ended March 31, 2025. During the first quarter of 2024, qualitative factors such as a decrease in the Company’s market capitalization, cautious service provider spending due to economic uncertainty and continued customer focus on inventory adjustments, triggered a quantitative impairment assessment for our reporting units for goodwill and long-lived assets. The Company determined upon its quantitative impairment assessment to recognize a $297.4 million non-cash goodwill impairment charge for the Network Solutions reporting unit. For additional information, see Note 8 of Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this report.

[0000950170-25-075374:mdna:71]
Interest and Dividend Income

[0000950170-25-075374:mdna:72]
Interest and dividend income decreased from $0.4 million for the three months ended March 31, 2024 to $0.1 million for the three months ended March 31, 2025. The decrease in interest and dividend income is primarily attributable to fluctuations in investment balances and an increase in the rate of return on those investments due to interest rate movements.

[0000950170-25-075374:mdna:73]
Interest Expense

[0000950170-25-075374:mdna:74]
Interest expense increased from $4.6 million for the three months ended March 31, 2024, to $4.8 million for the three months ended March 31, 2025. The increase in interest expense during the three months ended March 31, 2025, was primarily driven by higher interest costs incurred related to the sale of accounts receivable related to our receivables purchase agreement. See Note 2 of the Notes to Condensed Consolidated Financial Statements, included in Part I, Item 1 of this report for additional information.

[0000950170-25-075374:mdna:75]
Net Investment (Loss) Gain

[0000950170-25-075374:mdna:76]
We recognized a net investment gain of $2.3 million for the three months ended March 31, 2024 and a net investment loss of $1.7 million for the three months ended March 31, 2025. The fluctuations in our net investments were primarily attributable to changes in the fair value of our securities recognized during the period. We expect that any future market volatility could result in continued fluctuations in our investment portfolio. See Note 5 of the Notes to Condensed Consolidated Financial Statements, included in Part I, Item 1 of this report, and “Investing Activities” in “Liquidity and Capital Resources” below for additional information.

[0000950170-25-075374:mdna:77]
Other Income, net

[0000950170-25-075374:mdna:78]
Other income, net, which primarily consisted of gains and losses on foreign currency transactions and income from excess material sales, decreased from income of $1.3 million for the three months ended March 31, 2024 to income of $0.9 million for the three months ended March 31, 2025.

[0000950170-25-075374:mdna:79]
Income Tax Benefit

[0000950170-25-075374:mdna:80]
The Company's effective tax rate changed from a benefit of 5.4% of pre-tax loss for the three months ended March 31, 2024, to a benefit of 4.2% of pre-tax loss for the three months ended March 31, 2025 The change in the effective tax rate for the three months ended March 31, 2025, was driven primarily by loss jurisdictions for which the recognition of tax benefits on pre-tax losses incurred during the first quarter of 2025 were limited due to valuation allowance.

[0000950170-25-075374:mdna:81]
Net Loss Attributable To ADTRAN HOLDINGS, INC.

[0000950170-25-075374:mdna:82]
As a result of the above factors, net loss attributable to ADTRAN Holdings, Inc. decreased from net loss of $330.8 million for the three months ended March 31, 2024, to a net loss of $11.3 million for the three months ended March 31, 2025.

[0000950170-25-075374:mdna:83]
[same as prior period, unchanged from 0000950170-24-125685:mdna:86]

[0000950170-25-075374:mdna:84]
Liquidity

[0000950170-25-075374:mdna:85]
We have historically financed our ongoing business with existing cash, investments and cash flow from operations; however, we have increasingly relied upon our credit arrangements to manage our working capital needs. We had a positive cash flow from operating activities of $43.2 million in the three months ended March 31, 2025. We have used, and expect to continue to use, existing cash, credit arrangements and cash generated from operations for working capital and other general corporate purposes, including product development activities to enhance our existing products and develop new products, expand our sales and marketing activities and fund capital expenditures.

[0000950170-25-075374:mdna:86]
As of March 31, 2025, our cash on hand was $101.3 million of which $83.0 million was held by our foreign subsidiaries. As of March 31, 2025 and the date of this filing the Company had access to $25.8 million on its Credit Facility for future borrowings based on debt covenant compliance metrics. Generally, we intend to permanently reinvest funds held outside the U.S., except to the extent that any of these funds can be repatriated without withholding tax. As of December 31, 2024, our cash on hand was $76.0 million, of which $52.6 million was held by our foreign subsidiaries.

[0000950170-25-075374:mdna:87]
Under the DPLTA, subject to certain limitations pursuant to applicable law and the specific terms of the DPLTA, (i) the Company is entitled to issue binding instructions to the management board of Adtran Networks, (ii) Adtran Networks will transfer its annual profit to the Company, subject to, among other things, the creation or dissolution of certain reserves, and (iii) the Company will absorb the annual net loss incurred by Adtran Networks. The Company’s payment obligation in satisfaction of the requirement that it absorb Adtran Networks’ annual net loss applies to the net loss generated by Adtran Networks in 2024, and it will apply to any net loss generated by Adtran Networks in 2025.

[0000950170-25-075374:mdna:88]
Pursuant to the terms of the DPLTA, each Adtran Networks shareholder (other than the Company) has received an offer to elect either (1) to remain an Adtran Networks shareholder and receive from us an Annual Recurring Compensation payment, or (2) to receive Exit Compensation plus guaranteed interest. The guaranteed interest under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid. The guaranteed interest rate is 5.0% plus a variable component (according to the German Civil Code) that was 2.27% as of March 31, 2025. Assuming all the minority holders of currently outstanding Adtran Networks shares were to elect the second option, we would be obligated to make aggregate Exit Compensation payments, including guaranteed interest, of approximately €338.5 million or approximately $366.1 million, based on an exchange rate as of March 31, 2025, and reflecting interest accrued through March 31, 2025, during the pendency of the appraisal proceedings discussed below. Shareholders electing the first option of Annual Recurring Compensation may later elect the second option. The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that were initiated in 2023 in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger). The Company expects to receive a ruling on a procedural matter in the DPLTA appraisal proceedings during the latter half of 2025 or 2026, which ruling, depending on outcome, will likely be appealed and may take 6-12 months to be decided on appeal. The Company does not expect that a trial on the merits of the DPLTA appraisal proceedings will commence until the procedural matter has been resolved. The proceeding for the trial on the merits of the DPLTA will likely take a minimum of 12 months for a ruling and such ruling may likewise be appealed, which would be expected to take an additional 12-24 months to be resolved. Accordingly, the Company does not expect a final decision on the DPLTA appraisal proceedings to be rendered and published prior to 2027, and most likely not until 2028 or beyond.

[0000950170-25-075374:mdna:89]
Additionally, our obligation to pay Annual Recurring Compensation under the DPLTA is a continuing payment obligation, which will amount to approximately €8.9 million or $9.7 million (based on the current exchange rate) per year assuming none of the minority Adtran Networks shareholders were to elect Exit Compensation. The foregoing amounts do not reflect any potential increase in payment obligations that we may have depending on the outcome of ongoing appraisal proceedings in Germany. The Annual Recurring Compensation is due on the third banking day following the ordinary general shareholders’ meeting of Adtran Networks for the respective preceding fiscal year (but in any event within eight months following expiration of the fiscal year). With respect to the 2023 fiscal year, Adtran Networks’ ordinary general shareholders’ meeting occurred on June 28, 2024; therefore, the Annual Recurring Compensation was paid on July 3, 2024. With respect to the 2024 fiscal year, Adtran Networks’ ordinary general shareholder meeting is scheduled for June 27, 2025, and therefore, the Annual Recurring Compensation will be due on July 2, 2025. During the three months ended March 31, 2025 and 2024, we accrued $2.4 million and $2.5 million, respectively, in Annual Recurring Compensation which is reflected as an increase to retained deficit.

[0000950170-25-075374:mdna:90]
On July 18, 2022, ADTRAN, Inc., as the borrower, and ADTRAN Holdings, Inc. entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (“Credit Agreement”), which has since been amended four times. As of the date of this filing the Company had access to $25.8 million on its Credit Facility for future borrowings based on debt covenant compliance metrics. The financial covenants under the Credit Agreement, as amended, require the Company to maintain a Consolidated Total Net Leverage Ratio of 5.00x, a Consolidated Senior Secured Net Leverage Ratio of 3.25x (or 4.0x to 3.5x during a Springing Covenant Period), and a Consolidated Fixed Charge Coverage Ratio of 1.25x. See Note 10, Revolving Credit Agreements for additional information regarding the terms of the Wells Fargo Credit Agreement.

[0000950170-25-075374:mdna:91]
As of March 31, 2025, and as of the date of issuance of the condensed consolidated financial statements included in Part I, Item 1 of this Form 10-Q, the Company does not have sufficient liquidity to meet the substantial majority of its payment obligations under the DPLTA pertaining to Exit Compensation. For the three months ended March 31, 2025 and 2024, less than one thousand shares of Adtran Networks stock were tendered to the Company and Exit Compensation payments of approximately €12 thousand and €4 thousand, respectively, or approximately $13 thousand and $5 thousand based on the applicable exchange rates at the time of the transactions, were paid to Adtran Networks shareholders. In addition, between March 31, 2025 and the date of this report, 0.4 million shares of Adtran Networks stock were tendered to the Company and Exit Compensation payments of approximately €7.0 million, or $7.5 million, based on the applicable exchange rate at the time of the transaction, will be paid to Adtran Networks shareholders.  We believe the probability that more than a small minority of Adtran Networks shareholders elect to receive Exit Compensation in the next twelve months is remote based on the following factors: (i) the shareholders can exercise their right to receive the Exit Compensation until two months after publication of the final decision in the appraisal proceedings and we do not expect the final decision to be published within the next 12 months; (ii) the diverse base of shareholders that must make this election on an individual shareholder basis; (iii) the fact that the Company expects to receive a procedural decision during 2025 or 2026 that will likely be appealed and, while the date of a decision by

[0000950170-25-075374:mdna:92]
45

[0000950170-25-075374:mdna:93]
the court on the merits of the case is uncertain, it will likely take a minimum of 12 months for a ruling and thereafter, an expected appeal process will take a further 12-24 months to resolve; (iv) the current guaranteed Annual Recurring Compensation payment; and (v) the current trading value of Adtran Networks shares.

[0000950170-25-075374:mdna:94]
The Company experienced revenue declines in the year ended December 31, 2024. However, customers have started to replenish their inventories to meet increasing demand and we expect orders and billings to increase during the remainder of 2025. The Company continues to implement plans to preserve cash liquidity to maintain compliance with the Company’s covenants in case of further we are impacted by customer inventory reduction initiatives and uncertain macroeconomic conditions. Additionally, the Company suspended dividend payments and effectuated a Business Efficiency Program, which targeted the reduction of ongoing operating expenses and focused on enhancing capital efficiency. The Business Efficiency Program was completed as of December 31, 2024, other than the Company's aim of selling its headquarters. The Company has determined that it is probable that the sale of its headquarters in Huntsville will occur within the next twelve months after December 31, 2024. The Company expects to use the proceeds of the sale to repay indebtedness. The Company may need to further reduce capital expenditures and/or take other steps to preserve working capital in order to ensure that it can meet its needs and obligations and maintain compliance with its debt covenants.

[0000950170-25-075374:mdna:95]
In summary, the Company believes that its cash and cash equivalents, working capital management initiatives and availability to access cash under the Wells Fargo Credit Facility (described below), will be adequate to meet our business operating requirements, our capital expenditures and our expected obligations under the DPLTA, including anticipated levels of Exit Compensation and ability to continue to comply with our debt covenants under the Credit Facility for at least the next twelve months, from the issuance of these condensed consolidated financial statements included in Part I, Item 1 of this Form 10-Q. See Note 10, Revolving Credit Agreements, for additional information regarding the terms of the Wells Fargo Credit agreement and Notes to Condensed Consolidated Financial Statements included in Part I, Item, 1 for additional information regarding the terms of the Wells Fargo Credit Agreement.

[0000950170-25-075374:mdna:96]
Wells Fargo Credit Facility

[0000950170-25-075374:mdna:97]
On July 18, 2022, ADTRAN, Inc., as the borrower ("U.S. Borrower"), and the Company entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (the “Original Credit Agreement”), as amended by the First Amendment to the Credit Agreement, dated August 9, 2023, 2021 (“Amendment No. 1”), the Second Amendment to the Credit Agreement, dated January 16, 2024 (“Amendment No. 2”), the Third Amendment to the Credit Agreement, dated March 12, 2024 (“Amendment No. 3”), the Fourth Amendment to the Credit Amendment, dated June 4, 2024 (“Amendment No. 4”), and the Fifth Amendment to the Credit Agreement, dated May 6, 2025 (“Amendment No. 5” and, collectively with Amendment No. 1, Amendment No. 2, and Amendment No. 3, and Amendment No. 4, the “Credit Agreement Amendments”; and the Original Credit Agreement, as amended by the Credit Agreement Amendments, the “Amended Credit Agreement”). As of the date of this filing, the Amended Credit Agreement provided for a secured revolving credit facility of up to $350.0 million of borrowings, $50.0 million of which is solely available to Adtran Networks as borrower pursuant to the Subline (as defined and further described below).

[0000950170-25-075374:mdna:98]
As of March 31, 2025, the Company’s borrowings under the revolving line of credit were $190.1 million, of which approximately $141.0 million were borrowed by the U.S. Borrower and $49.1 million were borrowed under the Subline by Adtran Networks, who became a party to the Amended Credit Agreement in June 2024. As of the date of this filing, the Company’s borrowings under the revolving line of credit were $190.0 million, of which approximately $165.0 million were borrowed by the U.S. Borrower and $25.0 million were borrowed under the Subline by Adtran Networks. The credit facilities provided under the Amended Credit Agreement mature in July 2027, but the U.S. Borrower may request extensions subject to customary conditions. In addition, the U.S. Borrower may utilize up to $50.0 million of the $350.0 million total revolving facility for the issuance of letters of credit. As of March 31, 2025 and the date of this filing the Company was limited to additional borrowings of $25.8 million based on debt covenant compliance metrics. Any future credit extensions under the Amended Credit Agreement are subject to customary conditions precedent. The proceeds of any loans are expected to be used for general corporate purposes and to pay a portion of the Exchange Offer consideration.

[0000950170-25-075374:mdna:99]
Moreover, the Amended Credit Agreement provides for a sublimit under the existing $350.0 million revolving commitments in an aggregate amount of $50.0 million (“Subline”), which Subline is available for borrowings by Adtran Networks. Prepayments of outstanding loans under the Subline that result in the remaining outstanding loans under the Subline being less than the German Commitment Reduction Threshold (as defined below) will result in a permanent partial reduction of the commitments in respect of the Subline. The German Commitment Reduction Threshold was initially $75.0 million, but was reduced to $25.0 million as of the date of this filing and may be lowered from time to time pursuant to the terms of the Amended Credit Agreement. The existing swing line sublimit and letter of credit sublimit under the Amended Credit Agreement remain available to the U.S. Borrower (and not to Adtran Networks). Otherwise, the loans under the Subline are subject to substantially the same terms and conditions under the Amended Credit Agreement (including with respect to the interest rate and maturity date) as the other existing revolving commitments.

[0000950170-25-075374:mdna:100]
All U.S. borrowings under the Amended Credit Agreement bear interest at a rate tied to the Base Rate (as defined in the Amended Credit Agreement) or SOFR, at the Company’s option, and all E.U. borrowings bear interest at a rate tied to the Euro Interbank Offered Rate as administered by the European Money Markets Institute (or a comparable or successor administrator approved by the Administrative Agent), in each case plus applicable margins which vary based on the consolidated net leverage ratio of the Company and its subsidiaries

[0000950170-25-075374:mdna:101]
as determined pursuant to the terms of the Amended Credit Agreement. Default interest is 2.00% per annum in excess of the rate otherwise applicable. As of March 31, 2025, the weighted average interest rate on our revolving credit agreements was 8.55%.

[0000950170-25-075374:mdna:102]
The Company made certain representations and warranties to the lenders in the Amended Credit Agreement that are customary for credit arrangements of this type. The Company also agreed to maintain a Consolidated Total Net Leverage Ratio of 5.00x, a Consolidated Senior Secured Net Leverage Ratio of 3.25x (4.0x to 3.5x during a “Springing Covenant Period,” as defined below) and a Consolidated Fixed Charge Coverage Ratio of 1.25x (as such ratios are defined in the Amended Credit Agreement). A “Springing Covenant Event” occurs when at least sixty percent (60.0%) of the outstanding shares of Adtran Networks that were not owned by the Company and its subsidiaries as of August 9, 2023 have been tendered and purchased by the Company. Upon the occurrence of a Springing Covenant Event, the Company will enter a “Springing Covenant Period”, defined as the fiscal quarter in which a Springing Covenant Event occurs and the three (3) consecutive fiscal quarters thereafter. During a Springing Covenant Period, the Company’s leverage ratios are increased. In addition, the cash and cash equivalents of the credit parties must be at least $50.0 million and the cash and cash equivalents of the Company and its subsidiaries must be at least $70.0 million. In connection with Amendment No. 5, the Company informed the Administrative Agent that the financial statements and the compliance certificates previously delivered by the Company with respect to the fiscal quarters ended June 30, 2024 and September 30, 2024 contained errors and the Consolidated Fixed Charge Coverage Ratio for each of those quarters, after giving effect to the correction of such errors, was less than 1.25 to 1.00. Upon the execution of Amendment No. 5, the Lenders waived the existing events of default with respect to the fiscal quarters ended June 30, 2024 and September 30, 2024. As of March 31, 2025, the Company was in compliance with all covenants.

[0000950170-25-075374:mdna:103]
The Amended Credit Agreement also contains customary events of default, such as misrepresentation and a default in the performance or observance of any covenant (subject to customary cure periods and materiality thresholds). Upon the occurrence and during the continuance of an event of default, the Administrative Agent is entitled to take various actions, including the acceleration of all amounts due under the Amended Credit Agreement.

[0000950170-25-075374:mdna:104]
All obligations under the Amended Credit Agreement (including under the Subline) are guaranteed by the U.S. Borrower and certain subsidiaries of the U.S. Borrower (“Full Facility Guarantors”). To secure such guarantees, the U.S. Borrower and the Full Facility Guarantors have granted security interests in favor of the Administrative Agent over substantially all of their tangible and intangible assets, and the U.S. Borrower has granted mortgages in favor of the Administrative Agent over certain owned real estate assets. Certain of Adtran Networks' subsidiaries (the “Subline Guarantors”) have also provided a guarantee solely of the obligations in respect of the Subline. Furthermore, to secure such guarantees, Adtran Networks and the Subline Guarantors have granted security interests in favor of the Administrative Agent over substantially all of their tangible and intangible assets. Upon repayment in full and termination of the Subline, the guarantees by the Subline Guarantors and the liens granted by Adtran Networks and the Subline Guarantors to secure obligations under the Subline will be released.

[0000950170-25-075374:mdna:105]
[same as prior period, unchanged from 0000950170-24-125685:mdna:130]

[0000950170-25-075374:mdna:106]
Net cash provided by operating activities of $43.2 million during the three months ended March 31, 2025, improved by $5.3 million compared to net cash provided by operating activities of $37.9 million during the three months ended March 31, 2024. The increase was primarily due to the declining net loss for the three months ended March 31, 2025 and 2024, excluding the goodwill impairment charge of $297.4 million, as adjusted primarily for decreased deferred taxes partially offset by decreased net cash inflows from working capital. Additional details related to our working capital and its drivers are discussed below.

[0000950170-25-075374:mdna:107]
Net accounts receivable decreased 6.5% from $178.0 million as of December 31, 2024, to $166.5 million as of March 31, 2025. There was an allowance for credit losses of $1.2 million as of March 31, 2025, and $1.3 million as of December 31, 2024. The decrease in net accounts receivable was due primarily to a reduction in DSO. Quarterly accounts receivable DSO decreased from 67 days as of December 31, 2024, to 60 days as of March 31, 2025 and was primarily driven by customer and geographical mix of commercial terms.

[0000950170-25-075374:mdna:108]
Other receivables decreased 1.7% from $9.8 million as of December 31, 2024, to $9.6 million as of March 31, 2025. The decrease in other receivables was primarily attributable to a decrease in our receivables for sales of raw materials and contract assets partially offset by an increase in subscription service receivables and duty drawbacks.

[0000950170-25-075374:mdna:109]
Quarterly inventory turnover increased from 2.2 turns as of December 31, 2024, and 2.4 turns as of March 31, 2025. The increase in inventory turnover was primarily attributable to increased volume of sales activity due to a return of normalized customer spending and utilization of buffer stock. Inventory decreased 3.0% from $261.6 million as of December 31, 2024, to $253.6 million as of March 31, 2025. The decrease in inventory was primarily due to a reduction in component purchases due to improved lead time and utilization of buffer stock. We expect inventory levels to fluctuate as we attempt to maintain sufficient inventory for customer demand and improve working capital.

[0000950170-25-075374:mdna:110]
Accounts payable as of December 31, 2024 and March 31, 2025 remained flat at $171.8 million and $171.9 million, respectively. Accounts payable will fluctuate due to variations in the timing of the receipt of inventory, supplies and services and our subsequent payments for these purchases.

[0000950170-25-075374:mdna:111]
[same as prior period, unchanged from 0000950170-24-125685:mdna:136]

[0000950170-25-075374:mdna:112]
Capital expenditures, including intangibles totaled approximately $18.7 million and $14.7 million for the three months ended March 31, 2025 and 2024 respectively. These expenditures were primarily used to purchase computer hardware, internal use software, manufacturing and test equipment, and building improvements. The increase in capital expenditures for the three months ended March 31, 2025, is primarily attributable to increases in expenditures related to software and building renovation projects.

[0000950170-25-075374:mdna:113]
Our long-term investments decreased 6.5% from $32.1 million as of December 31, 2024, to $30.0 million as of March 31, 2025. Our investments include various marketable equity securities classified as long-term investments with a fair market value of $1.0 million and $1.1 million as of March 31, 2025, and December 31, 2024. Long-term investments as of March 31, 2025, and December 31, 2024, also included $29.0 million and $31.0 million, respectively, related to our deferred compensation plans. See Note 5 of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this report for additional information.

[0000950170-25-075374:mdna:114]
[same as prior period, unchanged from 0000950170-24-125685:mdna:141]

[0000950170-25-075374:mdna:115]
There were no stock repurchases during the periods ended March 31, 2025, and 2024, and there currently is no authorized stock repurchase program.

[0000950170-25-075374:mdna:116]
[same as prior period, unchanged from 0000950170-24-125685:mdna:143]

[0000950170-25-075374:mdna:117]
To accommodate employee stock option exercises, the Company issued 113 thousand and 36 thousand shares of common stock which resulted in proceeds of $0.8 million and $0.2 million during the three months ended March 31, 2025 and 2024, respectively.

[0000950170-25-075374:mdna:118]
[same as prior period, unchanged from 0000950170-24-125685:mdna:145]

[0000950170-25-075374:mdna:119]
We maintain defined benefit pension plans covering employees in certain foreign countries. The net amounts recognized in the Condensed Consolidated Balance Sheets for the unfunded pension liability as of  March 31, 2025 and December 31, 2024 were as follows:

[0000950170-25-075374:mdna:120]
|  |  |  |  | As of |  |  | As of |  |
| (In thousands) |  | Balance Sheet Location |  | March 31, 2025 |  |  | December 31, 2024 |  |
| Non-current pension asset |  | Other non-current assets |  | $ | 540 |  |  | $ | 517 |  |
| Current pension liability |  | Accrued wages and benefits |  |  | (317 | ) |  |  | (303 | ) |
| Non-current pension liability |  | Non-current pension liability |  |  | (8,886 | ) |  |  | (8,983 | ) |
| Total |  |  |  | $ | (8,663 | ) |  | $ | (8,769 | ) |

[0000950170-25-075374:mdna:121]
For additional information, see Note 11 of Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this report.

[0000950170-25-075374:mdna:122]
[same as prior period, unchanged from 0000950170-24-125685:mdna:147]

[0000950170-25-075374:mdna:123]
We maintain two deferred compensation programs for certain executive management employees and our Board of Directors. The fair value of the assets held by the deferred compensation programs totaled $29.0 million and $31.0 million as of March 31, 2025, and  December 31, 2024, respectively, and is included in long-term investments on the Condensed Consolidated Balance Sheets. The amounts payable to the deferred compensation program participants totaled $31.3 million and $33.2 million as of March 31, 2025, and December 31, 2024, respectively. For additional information, see Note 5 of Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this report.

[0000950170-25-075374:mdna:124]
[same as prior period, unchanged from 0000950170-24-125685:mdna:149]

[0000950170-25-075374:mdna:125]
We have exposure to credit losses from off-balance sheet exposures, to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds, where we believe the risk of loss is immaterial to our financial statements as of March 31, 2025. Otherwise, we do not have off-balance sheet financing arrangements and have not engaged in any related party transactions or arrangements with unconsolidated entities or other persons that are reasonably likely to materially affect liquidity or the availability of or requirements for capital resources. See Note 16 of the Notes to Condensed Consolidated Financial Statements, included in Part I, Item 1 of this report for additional information.

[0000950170-25-075374:mdna:126]
[same as prior period, unchanged from 0000950170-24-125685:mdna:151]

[0000950170-25-075374:mdna:127]
The following table summarizes the Company’s material short- and long-term cash requirements from known obligations pursuant to certain contracts and commitments as of March 31, 2025, as well as an estimate of the timing in which such obligations and payments are expected to be satisfied (but excluding payments that may be made pursuant to the DPLTA, which is discussed below). Other than operating lease obligations, the cash requirements table excludes interest payments.

[0000950170-25-075374:mdna:128]
| (In thousands) |  | Total |  |  | 2025 |  |  | 2026 |  |  | 2027 |  |  | 2028 |  |  | 2029 |  |  | Thereafter |  |
| Wells Fargo credit agreement(1) |  | $ | 190,085 |  |  | $ | — |  |  | $ | — |  |  | $ | 190,085 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Purchase obligations(2) |  |  | 203,898 |  |  |  | 190,777 |  |  |  | 12,121 |  |  |  | 875 |  |  |  | 125 |  |  |  | — |  |  |  | — |  |
| Operating lease obligations(3) |  |  | 42,325 |  |  |  | 7,157 |  |  |  | 8,004 |  |  |  | 7,070 |  |  |  | 5,769 |  |  |  | 3,300 |  |  |  | 11,025 |  |
| Totals |  | $ | 436,308 |  |  | $ | 197,934 |  |  | $ | 20,125 |  |  | $ | 198,030 |  |  | $ | 5,894 |  |  | $ | 3,300 |  |  | $ | 11,025 |  |

[0000950170-25-075374:mdna:129]
[same as prior period, unchanged from 0000950170-24-125685:mdna:154]

[0000950170-25-075374:mdna:130]
[same as prior period, unchanged from 0000950170-24-125685:mdna:155]

[0000950170-25-075374:mdna:131]
partners and other vendors. The settlement of our purchase obligations will occur at various dates beginning in 2025 and going

[0000950170-25-075374:mdna:132]
through 2028. See Note 16 of the Notes to Condensed Consolidated Financial Statements, included in Part I, Item 1 of this report

[0000950170-25-075374:mdna:133]
[same as prior period, unchanged from 0000950170-24-125685:mdna:158]

[0000950170-25-075374:mdna:134]
[same as prior period, unchanged from 0000950170-24-125685:mdna:159]

[0000950170-25-075374:mdna:135]
locations. Our operating leases had remaining lease terms ranging from 1 month to 164 months as of  March 31, 2025.

[0000950170-25-075374:mdna:136]
[same as prior period, unchanged from 0000950170-24-125685:mdna:161]

[0000950170-25-075374:mdna:137]
On July 18, 2022, ADTRAN Holdings, Inc. and ADTRAN, Inc., as the borrower, entered into the Credit Agreement with the Administrative Agent and the other lenders named therein. The Credit Agreement was subsequently amended five times. As of March 31, 2025, the Company's borrowings under the revolving line of credit were $190.1 million, of which approximately $141.0 million were borrowed by ADTRAN, Inc. and $49.1 million were borrowed under the Subline by Adtran Networks. As of the date of this filing, the Company’s borrowings under the revolving line of credit were $190.0 million, of which approximately $165.0 million were borrowed by the U.S. Borrower and $25.0 million were borrowed under the Subline by Adtran Networks. The Credit Facility matures in July 2027; however, the Company may request extensions subject to customary conditions. See Note 10 and 18 of the Notes to Condensed Consolidated Financial Statements, included in Part I, Item 1 of this report and “Liquidity and Capital Resources - Wells Fargo Credit Facility” in Part I, Item 2 of this report for additional information.

[0000950170-25-075374:mdna:138]
[same as prior period, unchanged from 0000950170-24-125685:mdna:166]

[0000950170-25-075374:mdna:139]
On July 1, 2024, the Company entered into a Factoring Agreement with the Factor, which accelerates receivable collection and helps to better manage cash flow.  The Factoring Agreement provides for up to $40.0 million in factoring capacity, subject to eligible receivables and reserve requirements, secured by the receivables.  Total accounts receivables factored as of the end of March 31, 2025, totaled $11.2 million of which $3.7 million was retained pursuant to the Factoring Agreement in the reserve account. See Note 2 of the Notes to Condensed Consolidated Financial Statements, included in Part I, Item 1 of this report for additional information.

[0000950170-25-075374:mdna:140]
On December 19, 2023, the Company entered into the Prior Factoring Agreement with a third-party financial institution which qualified for treatment as a secured borrowing with a pledge of collateral under Accounting Standards Codification ("ASC") Topic 810, Consolidation. The Prior Factoring Agreement was terminated on July 1, 2024.

[0000950170-25-075374:mdna:141]
[same as prior period, unchanged from 0000950170-24-125685:mdna:169]

[0000950170-25-075374:mdna:142]
[same as prior period, unchanged from 0000950170-24-125685:mdna:170]

[0000950170-25-075374:mdna:143]
Under the DPLTA, subject to certain limitations pursuant to applicable law and the specific terms of the DPLTA, (i) the Company is entitled to issue binding instructions to the management board of Adtran Networks, (ii) Adtran Networks will transfer its annual profit to the Company, subject to, among other things, the creation or dissolution of certain reserves, and (iii) the Company will absorb the annual net loss incurred by Adtran Networks. The Company’s payment obligation in satisfaction of the requirement that it absorb Adtran Networks’ annual net loss will apply to any net loss generated by Adtran Networks in 2025.

[0000950170-25-075374:mdna:144]
Pursuant to the terms of the DPLTA, each Adtran Networks shareholder (other than the Company) has received an offer to elect either (1) to remain an Adtran Networks shareholder and receive from us an Annual Recurring Compensation payment, or (2) to receive Exit Compensation plus guaranteed interest. The guaranteed interest under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid. The guaranteed interest rate is 5.0% plus a variable component (according to the German Civil Code) that was 2.27% as of March 31, 2025. Assuming all the minority holders of currently outstanding Adtran Networks shares were to elect the second option, we would be obligated to make aggregate Exit Compensation payments, including guaranteed interest, of approximately €338.5 million or approximately $366.1 million, based on an

[0000950170-25-075374:mdna:145]
exchange rate as of March 31, 2025, and reflecting interest accrued through March 31, 2025, during the pendency of the appraisal proceedings discussed below. Shareholders electing the first option of Annual Recurring Compensation may later elect the second option. The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that were initiated in 2023 in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger). The Company expects to receive a ruling on a procedural matter in the DPLTA appraisal proceedings during the latter half of 2025 or 2026, which ruling, depending on outcome, will likely be appealed and may take 6-12 months to be decided on appeal. The Company does not expect that a trial on the merits of the DPLTA appraisal proceedings will commence until the procedural matter has been resolved. The proceeding for the trial on the merits of the DPLTA will likely take a minimum of 12 months for a ruling and such ruling may likewise be appealed, which would be expected to take an additional 12-24 months to be resolved. Accordingly, the Company does not expect a final decision on the DPLTA appraisal proceedings to be rendered and published prior to 2027, and most likely not until 2028 or beyond.

[0000950170-25-075374:mdna:146]
Additionally, our obligation to pay Annual Recurring Compensation under the DPLTA is a continuing payment obligation, which will amount to approximately €8.9 million or $9.7 million (based on the current exchange rate) per year assuming none of the minority Adtran Networks shareholders were to elect Exit Compensation. The foregoing amounts do not reflect any potential increase in payment obligations that we may have depending on the outcome of ongoing appraisal proceedings in Germany. The Annual Recurring Compensation is due on the third banking day following the ordinary general shareholders’ meeting of Adtran Networks for the respective preceding fiscal year (but in any event within eight months following expiration of the fiscal year). With respect to the 2023 fiscal year, Adtran Networks’ ordinary general shareholders’ meeting occurred on June 28, 2024 and, therefore, the Annual Recurring Compensation was paid on July 3, 2024. With respect to the 2024 fiscal year, Adtran Networks’ ordinary general shareholder meeting is scheduled for June 27, 2025, and therefore, the Annual Recurring Compensation will be due on July 2, 2025. During the three months ended March 31, 2025 and 2024, we accrued $2.4 million and $2.5 million, respectively, in Annual Recurring Compensation. The Annual Recurring Compensation is reflected as an increase to retained deficit in the Condensed Consolidated Balance Sheets.

[0000950170-25-075374:mdna:147]
On October 18, 2022, the Company's Board of Directors authorized the Company to purchase additional shares of Adtran Networks through open market purchases not to exceed 15,346,544 shares. For the three months ended March 31, 2025 and 2024, less than one thousand shares, respectively, of Adtran Networks stock was tendered to the Company and Exit Compensation payments of approximately €12 thousand and €4 thousand, respectively, or approximately $13 thousand and $5 thousand based on an exchange rates at the time of the transactions, were paid to Adtran Networks shareholders.

[0000950170-25-075374:mdna:148]
We currently hold 34,856,611 no-par value bearer shares of Adtran Networks, representing 67.0% of Adtran Networks outstanding shares as of March 31, 2025.

[0000950170-25-075374:mdna:149]
The foregoing description of the DPLTA does not purport to be complete and is qualified in its entirety by reference to the DPLTA, a non-binding English translation of which incorporated by reference to Exhibit 10.5 included in our Form 10-K.

[0000950170-25-075374:mdna:150]
[same as prior period, unchanged from 0000950170-24-125685:mdna:21]

[0000950170-25-075374:mdna:151]
On November 6, 2023, due to the uncertainty around the then current macroeconomic environment and its impact on customer spending levels, the Company’s management decided to implement a Business Efficiency Program targeting the reduction of ongoing operating expenses and focusing on capital efficiency. This included certain salary reductions, an early retirement program, a site consolidation plan to include lease impairments and the sale of owned real estate (including the sale of our headquarters in Huntsville), inventory write downs from product discontinuances, and the suspension of the quarterly dividend. Other than the Company's aim of selling its headquarters, the Business Efficiency Program was completed as of December 31, 2024.

[0000950170-25-075374:mdna:152]
During the three months ended March 31, 2024, we recognized $17.1 million of costs related to the Business Efficiency Program. We did not incur any Business Efficiency Program costs during the three months ended March 31, 2025. Future cash payments include previously accrued severance and outplacement fees, as well as site consolidation costs that are anticipated to be approximately $3.1 million.

[0000950170-25-075374:mdna:153]
[same as prior period, unchanged from 0000950170-24-125685:mdna:182]

[0000950170-25-075374:mdna:154]
During the three months ended March 31, 2025, other than the Exit Compensation payments, Annual Recurring Compensation under the DPLTA, and receivables purchase arrangements there have been no other material changes in cash requirements from those discussed in the 2024 Form 10-K/A and our cash requirements table shown in Liquidity and Capital Resources above.

[0000950170-25-075374:mdna:155]
[same as prior period, unchanged from 0000950170-24-125685:mdna:184]

[0000950170-25-075374:mdna:156]
Certain contracts, customers and jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of March 31, 2025, and December 31, 2024, we had commitments related to these bonds totaling $15.2 million and $15.7 million, respectively, which expire at various dates through April 2029. In general, we would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which we believe is remote.

[0000950170-25-075374:mdna:157]
[same as prior period, unchanged from 0000950170-24-125685:mdna:186]

[0000950170-25-075374:mdna:158]
[same as prior period, unchanged from 0000950170-24-125685:mdna:187]

[0000950170-25-075374:mdna:159]
An accounting policy is deemed to be critical if it requires an accounting estimate to be made based on assumptions about matters that are highly uncertain at the time the estimate is made, if different estimates reasonably could have been used or if changes in the accounting estimate that are reasonably likely to occur could materially impact the results of financial operations. Several accounting policies, as described in Note 1 of Notes to the Condensed Consolidated Financial Statements included in Part I, Item 1 of this report, require material subjective or complex judgment and have a significant impact on our financial condition and results of operations, as applicable. We believe the critical accounting policies affect our more significant judgments and estimates used in the preparation of our Condensed Consolidated Financial Statements. During the three months ended March 31, 2025, there were no significant changes to our critical accounting policies and estimates as described in the financial statements contained in the 2024 Form 10-K/A.

[0000950170-25-075374:mdna:160]
[same as prior period, unchanged from 0000950170-24-125685:mdna:60]
