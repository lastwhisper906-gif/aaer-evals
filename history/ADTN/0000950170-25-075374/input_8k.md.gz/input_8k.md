# ADTN 8-K — 0000950170-25-066343 filed 2025-05-08

## item codes, every 8-K on or before 2025-05-20

- 2025-05-13 0000950170-25-070473 — 4.02, 8.01, 9.01
- 2025-05-12 0000950170-25-069478 — 1.01, 9.01
- 2025-05-08 0000950170-25-066343 — 2.02, 7.01, 9.01
- 2025-04-16 0001193125-25-081800 — 7.01, 9.01
- 2025-03-07 0001193125-25-048727 — 5.02, 7.01, 9.01
- 2025-02-27 0000950170-25-028352 — 2.02, 7.01, 9.01
- 2024-11-07 0000950170-24-122762 — 2.02, 7.01, 9.01
- 2024-08-30 0000950170-24-102309 — 5.02, 9.01
- 2024-08-06 0000950170-24-091207 — 2.02, 7.01, 9.01
- 2024-08-02 0000950170-24-089974 — 5.02
- 2024-06-10 0001193125-24-158388 — 1.01, 2.03, 9.01
- 2024-05-09 0000950170-24-056830 — 5.02, 5.07, 9.01
- 2024-05-07 0000950170-24-053920 — 2.02, 7.01, 9.01
- 2024-05-03 0001193125-24-130896 — 2.02, 7.01, 9.01
- 2024-04-17 0000950170-24-045151 — 2.05, 9.01
- 2024-03-15 0000950170-24-031864 — 2.02, 9.01
- 2024-02-27 0000950170-24-020613 — 2.02, 7.01, 9.01
- 2024-02-20 0001193125-24-040068 — 4.02
- 2024-01-22 0001193125-24-011697 — 1.01, 2.03, 9.01
- 2023-12-06 0001193125-23-289895 — 5.02, 9.01
- 2023-12-05 0001193125-23-289150 — 5.02, 9.01
- 2023-11-07 0001193125-23-271842 — 2.02, 7.01, 9.01
- 2023-10-24 0001193125-23-261665 — 5.02, 5.03, 9.01
- 2023-10-17 0001193125-23-257289 — 2.02, 7.01, 9.01
- 2023-09-29 0001193125-23-246498 — 5.02
- 2023-08-14 0001193125-23-212439 — 2.02, 9.01 — amendment of 0001193125-23-204377
- 2023-08-10 0001193125-23-209039 — 4.02, 9.01
- 2023-08-10 0001193125-23-209024 — 2.02, 9.01 — amendment of 0001193125-23-204377
- 2023-08-07 0001193125-23-204377 — 2.02, 7.01, 9.01
- 2023-06-28 0001193125-23-177593 — 5.02, 9.01
- 2023-06-01 0001193125-23-158986 — 5.02, 9.01
- 2023-05-30 0001193125-23-156741 — 5.02
- 2023-05-15 0000950170-23-021860 — 5.07, 9.01
- 2023-05-09 0000950170-23-019145 — 2.02, 9.01
- 2023-04-11 0001193125-23-097240 — 2.02, 9.01
- 2023-04-03 0001193125-23-089517 — 5.02, 9.01
- 2023-03-30 0001193125-23-085151 — 5.02, 9.01
- 2023-02-21 0000950170-23-003277 — 2.02, 9.01
- 2023-02-08 0001193125-23-028386 — 1.02, 9.01
- 2023-01-26 0001193125-23-016354 — 5.02, 9.01
- 2023-01-19 0001193125-23-010702 — 8.01, 9.01
- 2022-12-05 0001193125-22-298171 — 1.01, 9.01
- 2022-11-09 0000950170-22-023662 — 2.02 — amendment of 0000950170-22-022906
- 2022-11-08 0000950170-22-022906 — 2.02, 9.01
- 2022-10-26 0001193125-22-269383 — 8.01
- 2022-10-25 0001193125-22-268261 — 2.02, 9.01 — amendment, the index does not say of what
- 2022-10-25 0001193125-22-267712 — 2.02, 9.01
- 2022-10-18 0001193125-22-264344 — 8.01, 9.01
- 2022-09-30 0000950170-22-019126 — 5.02, 9.01 — amendment of 0001193125-22-195093
- 2022-08-04 0000950170-22-014476 — 2.02, 9.01
- 2022-07-22 0001193125-22-200018 — 1.01, 1.02, 2.03, 9.01
- 2022-07-15 0001193125-22-195093 — 2.01, 5.02, 9.01
- 2022-07-08 0001193125-22-190213 — 2.01, 3.01, 3.03, 5.01, 5.02, 5.03, 7.01, 9.01
- 2022-07-07 0001193125-22-188934 — 7.01, 9.01
- 2022-06-30 0001193125-22-186294 — 5.04, 9.01
- 2022-05-23 0000950170-22-010455 — 1.01, 2.03, 9.01
- 2022-05-13 0000950170-22-009818 — 5.07
- 2022-05-05 0000950170-22-007563 — 2.02, 9.01
- 2022-04-06 0000950170-22-005405 — 1.01, 2.03, 9.01
- 2022-02-03 0000950170-22-000705 — 2.02, 9.01
- 2022-01-06 0001193125-22-003467 — 5.07, 7.01, 9.01
- 2021-12-28 0001193125-21-368041 — 8.01
- 2021-11-29 0000950170-21-004926 — 5.02, 9.01
- 2021-11-02 0000950170-21-002595 — 7.01, 9.01
- 2021-11-02 0000950170-21-002593 — 2.02, 9.01
- 2021-10-15 0000950170-21-002127 — 2.02, 9.01
- 2021-10-07 0000950170-21-002053 — 5.02
- 2021-09-01 0000950170-21-001615 — 5.02
- 2021-08-30 0001193125-21-260059 — 1.01, 7.01, 9.01
- 2021-08-05 0001564590-21-041127 — 2.02, 9.01
- 2021-05-18 0001564590-21-028541 — 5.07
- 2021-05-06 0001564590-21-024430 — 2.02, 9.01
- 2021-02-26 0001564590-21-009408 — 2.02, 9.01 — amendment of 0001564590-21-004167
- 2021-02-04 0001564590-21-004167 — 2.02, 9.01
- 2020-11-03 0001564590-20-049784 — 2.02, 9.01
- 2020-08-06 0001564590-20-037168 — 2.02, 9.01
- 2020-07-23 0001564590-20-033184 — 5.03, 9.01
- 2020-05-15 0001564590-20-025794 — 5.07
- 2020-05-11 0001564590-20-024328 — 5.02, 9.01
- 2020-05-07 0001564590-20-022297 — 2.02, 9.01
- 2020-02-25 0001564590-20-006448 — 2.02, 9.01
- 2020-02-06 0001564590-20-003580 — 2.02, 9.01
- 2019-10-31 0001564590-19-038936 — 2.02, 9.01
- 2019-10-10 0001564590-19-036732 — 2.02, 9.01
- 2019-09-20 0001564590-19-035144 — 2.02, 9.01
- 2019-08-21 0001564590-19-032757 — 3.01, 9.01
- 2019-07-18 0001564590-19-025186 — 2.02, 9.01
- 2019-05-09 0001564590-19-017956 — 5.07
- 2019-04-18 0001564590-19-011897 — 2.02, 9.01
- 2019-03-07 0001564590-19-006575 — 5.02, 9.01
- 2019-01-24 0001564590-19-001024 — 2.02, 9.01
- 2018-12-06 0001564590-18-030615 — 8.01, 9.01
- 2018-10-17 0001564590-18-024365 — 2.02, 9.01
- 2018-07-18 0001564590-18-016946 — 2.02, 9.01
- 2018-05-10 0001564590-18-012968 — 5.07
- 2018-04-18 0001564590-18-008361 — 2.02, 9.01
- 2018-03-21 0001564590-18-006409 — 8.01, 9.01
- 2018-01-17 0001564590-18-000519 — 2.02, 9.01
- 2017-12-29 0001564590-17-025375 — 2.02, 9.01
- 2017-11-16 0001193125-17-345232 — 5.02
- 2017-10-18 0001564590-17-019582 — 2.02, 9.01
- 2017-07-19 0001564590-17-013609 — 2.02, 9.01
- 2017-05-11 0001564590-17-010459 — 5.02, 9.01
- 2017-05-11 0001564590-17-010452 — 5.07
- 2017-04-19 0001193125-17-127926 — 2.02, 9.01
- 2017-02-07 0001193125-17-032714 — 8.01
- 2017-01-18 0001193125-17-011669 — 2.02, 9.01
- 2016-11-16 0001193125-16-769505 — 5.02, 9.01
- 2016-10-19 0001193125-16-741087 — 2.02, 9.01
- 2016-09-14 0001193125-16-709148 — 8.01, 9.01
- 2016-08-17 0001193125-16-683980 — 5.02, 9.01
- 2016-07-13 0001193125-16-646816 — 2.02, 9.01
- 2016-05-13 0001193125-16-590263 — 5.07
- 2016-04-13 0001193125-16-539019 — 2.02, 9.01
- 2016-04-08 0001193125-16-535035 — 7.01
- 2016-02-11 0001193125-16-459453 — 5.02, 9.01
- 2016-01-20 0001193125-16-432934 — 2.02, 9.01
- 2015-11-16 0001193125-15-378019 — 5.02, 9.01
- 2015-10-14 0001193125-15-343083 — 2.02, 9.01
- 2015-07-16 0001193125-15-254729 — 8.01, 9.01
- 2015-07-15 0001193125-15-253068 — 2.02, 9.01
- 2015-05-15 0001193125-15-189160 — 5.07, 9.01
- 2015-04-22 0001193125-15-140997 — 2.02, 9.01
- 2015-02-23 0001193125-15-056741 — 5.02, 9.01
- 2015-01-21 0001193125-15-015465 — 2.02, 9.01
- 2014-10-15 0001193125-14-372076 — 2.02, 9.01
- 2014-10-03 0001193125-14-363152 — 2.02, 9.01
- 2014-07-16 0001193125-14-269660 — 2.02, 9.01
- 2014-05-20 0001193125-14-205916 — 8.01, 9.01
- 2014-05-20 0001193125-14-205906 — 5.02, 9.01
- 2014-05-15 0001193125-14-201144 — 5.07
- 2014-04-16 0001193125-14-144665 — 2.02, 9.01
- 2014-04-03 0001193125-14-129578 — 2.02, 9.01
- 2014-01-22 0001157523-14-000154 — 2.02, 9.01
- 2013-10-15 0001193125-13-399540 — 5.02
- 2013-10-09 0001157523-13-004657 — 2.02, 9.01
- 2013-07-10 0001157523-13-003290 — 2.02, 9.01
- 2013-05-10 0001193125-13-213728 — 5.07
- 2013-05-03 0001193125-13-198816 — 8.01, 9.01
- 2013-04-10 0001157523-13-001730 — 2.02, 9.01
- 2013-01-16 0001157523-13-000139 — 2.02, 9.01
- 2012-10-10 0001157523-12-005081 — 2.02, 9.01
- 2012-10-03 0001193125-12-413609 — 7.01
- 2012-09-28 0001193125-12-408878 — 2.02, 9.01
- 2012-07-11 0001157523-12-003592 — 2.02, 9.01
- 2012-05-10 0001193125-12-225669 — 5.07
- 2012-05-10 0001193125-12-225639 — 8.01, 9.01
- 2012-04-11 0001157523-12-001772 — 2.02, 9.01
- 2012-03-15 0001193125-12-116494 — 2.02, 9.01
- 2012-01-18 0001157523-12-000174 — 2.02, 9.01
- 2011-12-12 0001193125-11-337271 — 7.01, 9.01
- 2011-10-13 0000950123-11-089785 — 5.03, 9.01
- 2011-10-12 0001157523-11-005682 — 2.02, 9.01
- 2011-07-13 0001157523-11-003986 — 2.02, 9.01
- 2011-05-09 0000950123-11-047191 — 5.02, 5.07, 9.01
- 2011-04-13 0001157523-11-002001 — 2.02, 9.01
- 2011-01-19 0001157523-11-000232 — 2.02, 9.01
- 2010-11-09 0000950123-10-103195 — 5.02, 9.01
- 2010-10-13 0001157523-10-005798 — 2.02, 9.01
- 2010-07-14 0001157523-10-004011 — 2.02, 9.01
- 2010-05-28 0000950123-10-053947 — 5.07
- 2010-04-14 0001157523-10-002022 — 2.02, 9.01
- 2010-01-20 0001157523-10-000200 — 2.02, 9.01
- 2009-10-28 0000950123-09-053984 — 8.01
- 2009-10-14 0001157523-09-006877 — 2.02, 9.01
- 2009-07-15 0001157523-09-004878 — 2.02, 9.01
- 2009-04-15 0001157523-09-002687 — 2.02, 9.01
- 2009-01-21 0001157523-09-000340 — 2.02, 9.01
- 2008-11-12 0001193125-08-233181 — 5.02, 9.01
- 2008-10-14 0001157523-08-007999 — 2.02, 9.01
- 2008-07-15 0001157523-08-005504 — 2.02, 9.01
- 2008-04-15 0001157523-08-002896 — 2.02, 9.01
- 2008-01-22 0001157523-08-000408 — 2.02, 9.01
- 2007-10-16 0001193125-07-219356 — 5.03, 9.01
- 2007-10-16 0001157523-07-009850 — 2.02, 9.01
- 2007-07-17 0001157523-07-006912 — 2.02, 9.01
- 2007-04-17 0001157523-07-003630 — 2.02, 9.01
- 2007-04-03 0001179022-07-000068 — 5.02
- 2007-03-28 0001179022-07-000064 — 5.02
- 2007-02-23 0001193125-07-038337 — 5.02
- 2007-02-23 0001193125-07-038335 — 5.02
- 2007-01-30 0001193125-07-015912 — 5.02, 9.01
- 2007-01-26 0001193125-07-014234 — 5.02
- 2007-01-23 0001157523-07-000494 — 2.02, 9.01 — amendment of 0001157523-07-000481
- 2007-01-23 0001157523-07-000481 — 2.02, 9.01
- 2006-10-17 0001157523-06-009945 — 2.02, 9.01
- 2006-07-18 0001157523-06-006929 — 2.02, 9.01
- 2006-06-08 0001193125-06-126486 — 1.01, 9.01
- 2006-05-10 0001193125-06-107316 — 1.01, 9.01
- 2006-04-18 0001157523-06-003699 — 2.02, 9.01
- 2006-02-03 0001179022-06-000014 — 1.01
- 2006-01-27 0001157523-06-000754 — 5.02, 9.01
- 2006-01-24 0001157523-06-000551 — 2.02, 9.01
- 2005-10-18 0001157523-05-008826 — 2.02, 9.01
- 2005-07-19 0001193125-05-143958 — 1.01, 5.02, 9.01
- 2005-07-19 0001193125-05-143957 — 2.02, 9.01
- 2005-05-20 0001193125-05-112019 — 1.01, 9.01
- 2005-04-19 0001157523-05-003418 — 2.02, 9.01
- 2005-01-25 0001193125-05-010721 — 2.02, 9.01
- 2004-10-12 0001193125-04-169652 — 2.02, 9.01
- 2004-07-13 0001193125-04-116820 — 12, 7
- 2004-04-14 0001193125-04-061547 — 12, 7
- 2004-01-21 0001193125-04-006366 — 12, 7
- 2003-10-14 0001193125-03-061018 — 12, 5, 7
- 2003-07-15 0001193125-03-019292 — 7, 9
- 2003-04-15 0000931763-03-000968 — 7, 9
- 1996-09-12 0000931763-96-000667 — 5, 7

## late-filing notifications on or before 2025-05-20

- 2025-05-13 0000950170-25-070493 — NT 10-Q, for the period ended 2025-05-13
- 2024-02-29 0000950170-24-023141 — NT 10-K, for the period ended 2023-12-31
- 2023-08-10 0001193125-23-209042 — NT 10-Q, for the period ended 2023-06-30
- 2019-08-12 0001564590-19-031524 — NT 10-Q, for the period ended 2019-06-30

## item 2.02 — earnings release, exhibit 99.1

[0000950170-25-066343:8k_2_02:1]
EX-99.1
2
adtn-ex99_1.htm
EX-99.1

[0000950170-25-066343:8k_2_02:2]
EX-99.1

[0000950170-25-066343:8k_2_02:3]
ADTRAN Holdings, Inc. reports preliminary first quarter 2025 financial results

[0000950170-25-066343:8k_2_02:4]
Huntsville, Alabama, USA. — May 7, 2025 — ADTRAN Holdings, Inc. (NASDAQ: ADTN and FSE: QH9) (“ADTRAN Holdings” or the “Company”) today announced its preliminary unaudited financial results for the first quarter ended March 31, 2025.

[0000950170-25-066343:8k_2_02:5]
•
Revenue: $247.7 million, higher by 10% year-over-year, and above the mid-point of outlook.

[0000950170-25-066343:8k_2_02:6]
•
Gross margin: GAAP gross margin: 38.5%; non-GAAP gross margin: 42.6%.

[0000950170-25-066343:8k_2_02:7]
•
Operating margin: at the high end of outlook.

[0000950170-25-066343:8k_2_02:8]
•
GAAP diluted loss per share of $0.13; non-GAAP diluted earnings per share $0.03.

[0000950170-25-066343:8k_2_02:9]
•
Net cash provided by operating activities of $41.6 million

[0000950170-25-066343:8k_2_02:10]
•
Cash and cash equivalents of $101.3 million, an increase of $23.8 million sequentially

[0000950170-25-066343:8k_2_02:11]
Adtran Holdings’ Chairman and Chief Executive Officer Tom Stanton stated, “We executed on all fronts during the first quarter. Our strong performance reinforces Adtran’s improved operating efficiency and the strength of our business model. We delivered solid results, improving several key operating metrics, including higher revenue, strong gross and operating margins, and robust cash from operations.

[0000950170-25-066343:8k_2_02:12]
Mr. Stanton added, “We are well-positioned to navigate and capitalize on shifts in trade policy due to our globally diverse supply chain, operational flexibility, and strong customer relationships. Based on the current visibility and booking trends, we expect this positive momentum to continue into the second quarter.”

[0000950170-25-066343:8k_2_02:13]
The information contained in this press release is preliminary. Investors should refer to our Quarterly Report on Form 10-Q for the period ended March 31, 2025 once it is filed with the Securities and Exchange Commission (“SEC”).

[0000950170-25-066343:8k_2_02:14]
Business outlook1

[0000950170-25-066343:8k_2_02:15]
For the second quarter of 2025, the Company expects revenue to be within a range of $247.5 million to $262.5 million. Non-GAAP operating margin is expected to be within a range of 0% to 4%.

[0000950170-25-066343:8k_2_02:16]
1 Non-GAAP operating margin (which is calculated as non-GAAP operating income (loss) divided by revenue) is a non-GAAP financial measure. The Company has provided second quarter 2025 guidance with regard to non-GAAP operating margin. This measure excludes from the corresponding GAAP financial measure the effect of adjustments as described below. The Company has not provided a reconciliation of such non-GAAP guidance to guidance presented on a GAAP basis because it cannot predict and quantify without unreasonable effort all of the adjustments that may occur during the period due to the difficulty of predicting the timing and amounts of various items within a reasonable range. In particular, non-GAAP operating margin excludes certain items, such as acquisition related expenses, amortizations and adjustments, stock-based compensation expense, restructuring expenses, integration expenses, deferred compensation adjustments, and goodwill impairment that the Company is unable to quantitatively predict. Depending on the materiality of these items, they could have a significant impact on the Company's GAAP financial results.

[0000950170-25-066343:8k_2_02:17]
Conference call

[0000950170-25-066343:8k_2_02:18]
The Company will hold a conference call to discuss its preliminary first quarter 2025 results on Thursday, May 8, 2025, at 9:30 a.m. Central Time, or 4:30 p.m. Central European Time. The Company will webcast this conference call at the events and presentations section of ADTRAN Holdings, Inc. Investor Relations website at https://events.q4inc.com/attendee/184900731 approximately 10 minutes before the start of the call, or you may dial 1-888-330-2391 (Toll-Free US) or 1-240-789-2702, and use Conference ID 8936454.

[0000950170-25-066343:8k_2_02:19]
An online replay of the Company’s conference call, as well as the transcript of the call, will be available on the Investor Relations site https://investors.adtran.com/shortly following the call and will remain available for at least 12 months. For more information, visit investors.adtran.com or email investor.relations@adtran.com.

[0000950170-25-066343:8k_2_02:20]
Upcoming conference schedule

[0000950170-25-066343:8k_2_02:21]
May 12, 2025: Needham Technology Virtual One-on-One Conference

[0000950170-25-066343:8k_2_02:22]
May 28, 2025: 22nd Annual Craig Hallum Institutional Investor Conference

[0000950170-25-066343:8k_2_02:23]
June 25, 2025: Northland Capital Virtual One-on-One Growth Conference

[0000950170-25-066343:8k_2_02:24]
About Adtran

[0000950170-25-066343:8k_2_02:25]
ADTRAN Holdings, Inc. (NASDAQ: ADTN and FSE: QH9) is the parent company of Adtran, Inc., a leading global provider of open, disaggregated networking and communications solutions that enable voice, data, video and internet communications across any network infrastructure. From the cloud edge to the subscriber edge, Adtran empowers communications service providers around the world to manage and scale services that connect people, places and things. Adtran solutions are used by service providers, private enterprises,

[0000950170-25-066343:8k_2_02:26]
government organizations and millions of individual users worldwide. ADTRAN Holdings, Inc. is also the majority shareholder of Adtran Networks SE, formerly ADVA Optical Networking SE (“Adtran Networks”). Find more at Adtran, LinkedIn and Twitter.

[0000950170-25-066343:8k_2_02:27]
Cautionary note regarding forward-looking statements

[0000950170-25-066343:8k_2_02:28]
Additionally, the financial measures presented herein are preliminary estimates, remain subject to our internal controls and procedures, and are subject to risks and uncertainties, including, among others, changes in connection with quarter-end adjustments. Any variation between the Company’s actual results and the preliminary financial information set forth herein may be material.

[0000950170-25-066343:8k_2_02:29]
Explanation of use of non-GAAP financial measures

[0000950170-25-066343:8k_2_02:30]
Set forth in the tables below are reconciliations of gross profit, gross margin, operating expenses, operating loss, other expense, net loss inclusive of the non-controlling interest, net income attributable to the non-controlling interest, net loss attributable to the Company, and loss per share - basic and diluted, attributable to the Company, and net cash provided by operating activities, in each case as reported based on generally accepted accounting principles in the United States (“GAAP”), to non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income (loss), non-GAAP other expense, non-GAAP net income (loss) inclusive of the non-controlling interest, non-GAAP net income attributable to the non-controlling interest, non-GAAP net income (loss) attributable to the Company, non-GAAP net earnings (loss) per share - basic and diluted, attributable to the Company, and free cash flow, respectively. Such non-GAAP measures exclude acquisition-related expenses, amortization and adjustments (consisting of intangible amortization of backlog, inventory fair value adjustments, developed technology, customer relationships, and trade names acquired in connection with business combinations, as well as legal and advisory fees related to a previously contemplated significant transaction, stock-based compensation expense, restructuring expenses, integration expenses, deferred compensation adjustments, goodwill impairments, amortization of pension actuarial losses, the tax effect of these adjustments to net loss and purchases of property, plant and equipment. These measures are used by management in our ongoing planning and annual budgeting processes. Additionally, we believe the presentation of these non-GAAP measures, when combined with the presentation of the most directly comparable GAAP financial measure, is beneficial to the overall understanding of ongoing operating performance of the Company. These non-GAAP financial measures are not prepared in accordance with, or an alternative for, GAAP and therefore should not be considered in isolation or as a substitution for analysis of our results as reported under GAAP. Additionally, our calculation of non-GAAP measures may not be comparable to similar measures calculated by other companies.

[0000950170-25-066343:8k_2_02:31]
Published by

[0000950170-25-066343:8k_2_02:32]
ADTRAN Holdings, Inc.

[0000950170-25-066343:8k_2_02:33]
www.adtran.com

[0000950170-25-066343:8k_2_02:34]
For media

[0000950170-25-066343:8k_2_02:35]
Gareth Spence

[0000950170-25-066343:8k_2_02:36]
+44 1904 699 358

[0000950170-25-066343:8k_2_02:37]
public.relations@adtran.com

[0000950170-25-066343:8k_2_02:38]
For investors

[0000950170-25-066343:8k_2_02:39]
Peter Schuman, IRC

[0000950170-25-066343:8k_2_02:40]
+1 256 963 6305

[0000950170-25-066343:8k_2_02:41]
investor.relations@adtran.com

[0000950170-25-066343:8k_2_02:42]
Revision of Previously Issued Consolidated Financial Statements

[0000950170-25-066343:8k_2_02:43]
Following the first quarter of 2025, the Company identified errors in its previously issued consolidated financial statements primarily impacting inventory and cost of revenue. The Company has evaluated the errors and determined that the related impacts were not material to the previously issued consolidated financial statements for any prior period. A summary description of the errors in the Company's Preliminary Condensed Consolidated Financial Statements for the periods ended December 31, 2023, March 31, 2024, June 30, 2024, September 30, 2024 and December 31, 2024, are as follows:

[0000950170-25-066343:8k_2_02:44]
(a) For the year ended December 31, 2023 through the year ended December 31, 2024, the Company understated cost of revenue and overstated inventory in the Company's Adtran Networks subsidiary due to a system error. In addition, there were adjustments in the Company's U.S and Australian subsidiaries related to inventory reserves that were understated.

[0000950170-25-066343:8k_2_02:45]
As previously disclosed in the Company’s Annual Report on Form 10-K for the year ended December 31, 2024, following the third quarter of 2024, the Company identified errors primarily impacting the carrying values of the redeemable non-controlling interest, retained deficit, the net income attributable to the non-controlling interest and the net loss attributable to the Company and, as a consequence, of the loss per common share attributable to the Company. As previously disclosed, the Company evaluated the errors and determined that the related impacts were not material to the previously issued consolidated financial statements for any prior period. A summary description of the errors in the Company's Condensed Consolidated Financial Statements for the period ended March 31, 2024 is as follows:

[0000950170-25-066343:8k_2_02:46]
(b) Pursuant to the terms of the DPLTA, each Adtran Networks shareholder (other than the Company) is entitled to receive from us an Annual Recurring Compensation payment of €0.52 per share. The Company erroneously accrued this liability every quarter at €0.59 per share, overstating the associated accrual, the net income attributable to non-controlling interest and the net loss attributable to ADTRAN Holdings, Inc. for the period ended March 31, 2024.

[0000950170-25-066343:8k_2_02:47]
(c) For the period ended March 31, 2024 the Company remeasured the redeemable non-controlling interest each quarter-end at the current exchange rate of euros to U.S. Dollar. The Company treated the redeemable non-controlling interest as a monetary mezzanine equity instrument but should have treated it as a non-monetary mezzanine equity instrument not subject to remeasurement.

[0000950170-25-066343:8k_2_02:48]
The Company will be revising its previously issued 2024 interim financial statements and 2024 annual financial statements in connection with its future filings on Form 10-Q for the periods ended March 31, 2025, June 30, 2025 and September 30, 2025 and Form 10-K for the year ended December 31, 2025.

[0000950170-25-066343:8k_2_02:49]
The following tables reflect the expected impact of the revisions to the specific line items presented in the Company's previously reported (i) balance sheets as of March 31, 2024 and as of December 31, 2024, (ii) statements of loss and comprehensive loss for the quarter ended March 31, 2024 and the quarter and year ended December 31, 2024, (iii) the statements of changes in stockholders equity as of March 31, 2024 and December 31, 2024, (iv) statements of cash flows for the quarter ended March 31, 2024 and the year ended December 31, 2024 and (v) the net cash provided by operating activities for the quarter ended December 31, 2024. The preliminary financial information in this press release reflects these revisions.

[0000950170-25-066343:8k_2_02:50]
Revised Line Items in the Condensed Consolidated Balance Sheet as of March 31, 2024 (unaudited):

[0000950170-25-066343:8k_2_02:51]
|  |  |  | March 31, 2024 |  |
| (In thousands) |  |  | As Previously Reported |  |  | Revision |  |  | As Revised |  |
| Inventory, net |  |  | $ | 322,147 |  |  | $ | (3,460 | ) | (a) | $ | 318,687 |  |
| Total Current Assets |  |  | $ | 696,958 |  |  | $ | (3,460 | ) |  | $ | 693,498 |  |
| Total Assets |  |  | $ | 1,327,906 |  |  | $ | (3,460 | ) |  | $ | 1,324,446 |  |
| Accrued Expenses and Other Liabilities |  |  | $ | 36,404 |  |  | $ | (1,403 | ) | (b) | $ | 35,001 |  |
| Total Current Liabilities |  |  | $ | 282,746 |  |  | $ | (1,403 | ) |  | $ | 281,343 |  |
| Other non-current liabilities |  |  | $ | 35,375 |  |  | $ | (350 | ) | (b) | $ | 35,025 |  |
| Total Liabilities |  |  | $ | 620,488 |  |  | $ | (1,753 | ) |  | $ | 618,735 |  |
| Redeemable Non-Controlling Interest |  |  | $ | 441,635 |  |  | $ | 511 |  | (c) | $ | 442,146 |  |
| Accumulated Other Comprehensive Income |  |  | $ | 29,656 |  |  | $ | 19 |  | (a)(b) | $ | 29,675 |  |
| Retained Deficit |  |  | $ | (558,363 | ) |  | $ | (2,237 | ) | (a)(b)(c) | $ | (560,600 | ) |
| Total Equity |  |  | $ | 265,783 |  |  | $ | (2,218 | ) |  | $ | 263,565 |  |
| Total Liabilities, Redeemable Non-Controlling Interest and Equity |  |  | $ | 1,327,906 |  |  | $ | (3,460 | ) |  | $ | 1,324,446 |  |

[0000950170-25-066343:8k_2_02:52]
Revised Line Items in the Condensed Consolidated Statement of Loss and Condensed Consolidated Statement of Comprehensive Loss for the fiscal quarter ended March 31, 2024 (unaudited):

[0000950170-25-066343:8k_2_02:53]
|  |  |  | For the Three Months Ended March 31, 2024 |  |
| (In thousands) |  |  | As Previously Reported |  |  | Revision |  |  | As Revised |  |
| Cost of Revenue - Network Solutions |  |  | $ | 126,326 |  |  | $ | 1,952 |  | (a) | $ | 128,278 |  |
| Total Cost of Revenue |  |  | $ | 153,918 |  |  | $ | 1,952 |  |  | $ | 155,870 |  |
| Gross Profit |  |  | $ | 72,255 |  |  | $ | (1,952 | ) |  | $ | 70,303 |  |
| Operating Loss |  |  | $ | (339,679 | ) |  | $ | (1,952 | ) |  | $ | (341,631 | ) |
| Loss before Income Taxes |  |  | $ | (340,317 | ) |  | $ | (1,952 | ) |  | $ | (342,269 | ) |
| Net Loss |  |  | $ | (321,670 | ) |  | $ | (1,952 | ) |  | $ | (323,622 | ) |
| Less: Net Income attributable to non-controlling interest |  |  | $ | 2,880 |  |  | $ | (349 | ) | (b) | $ | 2,531 |  |
| Net Loss attributable to ADTRAN Holdings, Inc. |  |  | $ | (324,550 | ) |  | $ | (1,603 | ) |  | $ | (326,153 | ) |
| Loss per common share attributable to ADTRAN Holdings, Inc. – basic |  |  | $ | (4.12 | ) |  | $ | (0.02 | ) |  | $ | (4.14 | ) |
| Loss per common share attributable to ADTRAN Holdings, Inc. – diluted |  |  | $ | (4.12 | ) |  | $ | (0.02 | ) |  | $ | (4.14 | ) |
| Net Loss |  |  | $ | (321,670 | ) |  | $ | (1,952 | ) |  | $ | (323,622 | ) |
| Foreign currency translation loss |  |  | $ | (17,745 | ) |  | $ | 15 |  | (a)(b) | $ | (17,730 | ) |
| Other Comprehensive Loss, net of tax |  |  | $ | (17,805 | ) |  | $ | 15 |  |  | $ | (17,790 | ) |
| Comprehensive Loss, net of tax |  |  | $ | (339,475 | ) |  | $ | (1,937 | ) |  | $ | (341,412 | ) |
| Less: Comprehensive Income attributable to non-controlling interest, net of tax |  |  | $ | 2,880 |  |  | $ | (349 | ) | (b) | $ | 2,531 |  |
| Comprehensive Loss attributable to ADTRAN Holdings, Inc., net of tax |  |  | $ | (342,355 | ) |  | $ | (1,588 | ) |  | $ | (343,943 | ) |

[0000950170-25-066343:8k_2_02:54]
Revised Line Items in the Condensed Consolidated Statement of Loss for the fiscal quarter ended December 31, 2024 (unaudited):

[0000950170-25-066343:8k_2_02:55]
|  |  |  | For the Three Months Ended December 31, 2024 |  |
| (In thousands) |  |  | As Previously Reported |  |  | Revision |  |  | As Revised |  |
| Cost of Revenue - Network Solutions |  |  | $ | 134,184 |  |  | $ | 1,974 |  | (a) | $ | 136,158 |  |
| Total Cost of Revenue |  |  | $ | 151,619 |  |  | $ | 1,974 |  |  | $ | 153,593 |  |
| Gross Profit |  |  | $ | 91,233 |  |  | $ | (1,974 | ) |  | $ | 89,259 |  |
| Operating Loss |  |  | $ | (15,132 | ) |  | $ | (1,974 | ) |  | $ | (17,106 | ) |
| Loss before Income Taxes |  |  | $ | (18,604 | ) |  | $ | (1,974 | ) |  | $ | (20,578 | ) |
| Net Loss |  |  | $ | (43,509 | ) |  | $ | (1,974 | ) |  | $ | (45,483 | ) |
| Net Loss attributable to ADTRAN Holdings, Inc. |  |  | $ | (45,916 | ) |  | $ | (1,974 | ) |  | $ | (47,890 | ) |
| Loss per common share attributable to ADTRAN Holdings, Inc. – basic |  |  | $ | (0.58 | ) |  | $ | (0.02 | ) |  | $ | (0.61 | ) |
| Loss per common share attributable to ADTRAN Holdings, Inc. – diluted |  |  | $ | (0.58 | ) |  | $ | (0.02 | ) |  | $ | (0.61 | ) |

[0000950170-25-066343:8k_2_02:56]
Revised Line Items in the Consolidated Balance Sheet as of December 31, 2024 (unaudited):

[0000950170-25-066343:8k_2_02:57]
|  |  |  | December 31, 2024 |  |
| (In thousands) |  |  | As Previously Reported |  |  | Revision |  |  | As Revised |  |
| Inventory, net |  |  | $ | 269,337 |  |  | $ | (7,683 | ) | (a) | $ | 261,654 |  |
| Total Current Assets |  |  | $ | 610,605 |  |  | $ | (7,683 | ) |  | $ | 602,922 |  |
| Total Assets |  |  | $ | 1,179,372 |  |  | $ | (7,683 | ) |  | $ | 1,171,689 |  |
| Accumulated Other Comprehensive Income |  |  | $ | 10,897 |  |  | $ | 322 |  | (a) | $ | 11,219 |  |
| Retained Deficit |  |  | $ | (680,993 | ) |  | $ | (8,005 | ) | (a) | $ | (688,998 | ) |
| Total Equity |  |  | $ | 134,414 |  |  | $ | (7,683 | ) |  | $ | 126,731 |  |
| Total Liabilities, Redeemable Non-Controlling Interest and Equity |  |  | $ | 1,179,372 |  |  | $ | (7,683 | ) |  | $ | 1,171,689 |  |

[0000950170-25-066343:8k_2_02:58]
Revised Line Items in the Consolidated Statement of Loss and Consolidated Statement of Comprehensive Loss for the fiscal year ended December 31, 2024 (unaudited):

[0000950170-25-066343:8k_2_02:59]
|  |  |  | For the Year Ended December 31, 2024 |  |
| (In thousands) |  |  | As Previously Reported |  |  | Revision |  |  | As Revised |  |
| Cost of Revenue - Network Solutions |  |  | $ | 511,070 |  |  | $ | 6,483 |  | (a) | $ | 517,553 |  |
| Total Cost of Revenue |  |  | $ | 592,406 |  |  | $ | 6,483 |  |  | $ | 598,889 |  |
| Gross Profit |  |  | $ | 330,314 |  |  | $ | (6,483 | ) |  | $ | 323,831 |  |
| Operating Loss |  |  | $ | (417,101 | ) |  | $ | (6,483 | ) |  | $ | (423,584 | ) |
| Loss before Income Taxes |  |  | $ | (432,263 | ) |  | $ | (6,483 | ) |  | $ | (438,746 | ) |
| Net Loss |  |  | $ | (441,048 | ) |  | $ | (6,483 | ) |  | $ | (447,531 | ) |
| Net Loss attributable to ADTRAN Holdings, Inc. |  |  | $ | (450,872 | ) |  | $ | (6,483 | ) |  | $ | (457,355 | ) |
| Loss per common share attributable to ADTRAN Holdings, Inc. – basic |  |  | $ | (5.67 | ) |  | $ | (0.08 | ) |  | $ | (5.75 | ) |
| Loss per common share attributable to ADTRAN Holdings, Inc. – diluted |  |  | $ | (5.67 | ) |  | $ | (0.08 | ) |  | $ | (5.75 | ) |
| Net Loss |  |  | $ | (441,048 | ) |  | $ | (6,483 | ) |  | $ | (447,531 | ) |
| Foreign currency translation loss |  |  | $ | (38,047 | ) |  | $ | 322 |  | (a) | $ | (37,725 | ) |
| Other Comprehensive Loss, net of tax |  |  | $ | (36,568 | ) |  | $ | 322 |  |  | $ | (36,246 | ) |
| Comprehensive Loss, net of tax |  |  | $ | (477,616 | ) |  | $ | (6,161 | ) |  | $ | (483,777 | ) |
| Comprehensive Loss attributable to ADTRAN Holdings, Inc., net of tax |  |  | $ | (487,440 | ) |  | $ | (8,015 | ) |  | $ | (495,455 | ) |

[0000950170-25-066343:8k_2_02:60]
Revised Line Items in the Condensed Consolidated Statement of Changes in Stockholders Equity as of March 31, 2024 (unaudited):

[0000950170-25-066343:8k_2_02:61]
|  |  |  | Retained Deficit |  |  | Accumulated Other Comprehensive Income |  |
| (In thousands) |  |  | As Previously Reported |  |  | Revision |  |  | As Revised |  |  | As Previously Reported |  |  | Revision |  |  | As Revised |  |
| Balance as of December 31, 2023 |  |  | $ | (243,908 | ) |  | $ | 9,481 |  | (b) | $ | (234,427 | ) |  | $ | 47,461 |  |  | $ | 4 |  | (b) | $ | 47,465 |  |
| Net loss |  |  | $ | (321,670 | ) |  | $ | (1,952 | ) | (a) | $ | (323,622 | ) |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Annual recurring compensation earned |  |  | $ | (2,880 | ) |  | $ | 349 |  | (b) | $ | (2,531 | ) |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Other comprehensive loss, net of tax |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | (17,805 | ) |  | $ | 15 |  | (a)(b) | $ | (17,790 | ) |
| Foreign currency remeasurement of redeemable non-controlling interest |  |  | $ | 10,115 |  |  | $ | (10,115 | ) | (c) | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Balance as of March 31, 2024 |  |  | $ | (558,363 | ) |  | $ | (2,237 | ) |  | $ | (560,600 | ) |  | $ | 29,656 |  |  | $ | 19 |  |  | $ | 29,675 |  |

[0000950170-25-066343:8k_2_02:62]
Revised Line Items in the Consolidated Statement of Changes in Stockholders Equity as of December 31, 2024 (unaudited):

[0000950170-25-066343:8k_2_02:63]
|  |  |  | Retained Deficit |  |  | Accumulated Other Comprehensive Income |  |
| (In thousands) |  |  | As Previously Reported |  |  | Revision |  |  | As Revised |  |  | As Previously Reported |  |  | Revision |  |  | As Revised |  |
| Balance as of December 31, 2023 |  |  | $ | (232,905 | ) |  | $ | (1,522 | ) | (a) | $ | (234,427 | ) |  | $ | 47,465 |  |  | $ | — |  |  | $ | 47,465 |  |
| Net loss |  |  | $ | (441,048 | ) |  | $ | (6,483 | ) | (a) | $ | (447,531 | ) |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Other comprehensive income, net of tax |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | (36,568 | ) |  | $ | 322 |  | (a) | $ | (36,246 | ) |
| Balance as of December 31, 2024 |  |  | $ | (680,993 | ) |  | $ | (8,005 | ) |  | $ | (688,998 | ) |  | $ | 10,897 |  |  | $ | 322 |  |  | $ | 11,219 |  |

[0000950170-25-066343:8k_2_02:64]
Revised Line Items in the Condensed Consolidated Statement of Cash Flows for the quarter ended March 31, 2024 (unaudited):

[0000950170-25-066343:8k_2_02:65]
|  |  |  | Three months ended March 31, 2024 |  |
| (In thousands) |  |  | As Previously Reported |  |  | Revision |  |  | As Revised |  |
| Net Loss |  |  | $ | (321,670 | ) |  | $ | (1,952 | ) | (a) | $ | (323,622 | ) |
| Adjustments to reconcile net loss to net cash provided by operating activities |  |  |  |  |  |  |  |  |  |  |
| Inventory reserves |  |  | $ | 1,837 |  |  | $ | 157 |  | (a) | $ | 1,994 |  |
| Change in operating assets and liabilities: |  |  |  |  |  |  |  |  |  |  |
| Inventory |  |  | $ | 30,426 |  |  | $ | 1,795 |  | (a) | $ | 32,221 |  |
| Net Cash Provided by operating activities |  |  | $ | 36,598 |  |  | $ | — |  |  | $ | 36,598 |  |

[0000950170-25-066343:8k_2_02:66]
Revised Line Items in the Consolidated Statement of Cash Flows for the year ended December 31, 2024 (unaudited):

[0000950170-25-066343:8k_2_02:67]
|  |  |  | Year ended December 31, 2024 |  |
| (In thousands) |  |  | As Previously Reported |  |  | Revision |  |  | As Revised |  |
| Net Loss |  |  | $ | (441,048 | ) |  | $ | (6,483 | ) | (a) | $ | (447,531 | ) |
| Adjustments to reconcile net loss to net cash provided by operating activities |  |  |  |  |  |  |  |  |  |  |
| Inventory reserves |  |  | $ | 3,980 |  |  | $ | 352 |  | (a) | $ | 4,332 |  |
| Change in operating assets and liabilities: |  |  |  |  |  |  |  |  |  |  |
| Inventory |  |  | $ | 75,171 |  |  | $ | 6,100 |  | (a) | $ | 81,271 |  |
| Net Cash Provided by operating activities |  |  | $ | 103,070 |  |  | $ | (31 | ) |  | $ | 103,039 |  |
| Effect of exchange rate changes |  |  | $ | (451 | ) |  | $ | 31 |  |  | $ | (420 | ) |

[0000950170-25-066343:8k_2_02:68]
Revised Net Cash Provided by Operating Activities for the quarter ended December 31, 2024 (unaudited):

[0000950170-25-066343:8k_2_02:69]
|  |  |  | Three months ended December 31, 2024 |  |
| (In thousands) |  |  | As Previously Reported |  |  | Revision |  |  | As Revised |  |
| Net Cash Provided by operating activities |  |  | $ | 4,544 |  |  | $ | 12 |  | (a) | $ | 4,556 |  |

[0000950170-25-066343:8k_2_02:70]
For additional information, please refer to our Note 1 to the Condensed Consolidated Financial Statements set forth in the Form 10-Q for the quarterly period ended March 31, 2025 to be filed with the SEC.

[0000950170-25-066343:8k_2_02:71]
Condensed Consolidated Balance Sheets

[0000950170-25-066343:8k_2_02:72]
(Preliminary, Unaudited)

[0000950170-25-066343:8k_2_02:73]
(In thousands)

[0000950170-25-066343:8k_2_02:74]
|  | March 31, |  |  | December 31, |  |
|  | 2025 |  |  | 2024 |  |
| Assets |  |  |  |  |  |
| Current Assets |  |  |  |  |  |
| Cash and cash equivalents | $ | 101,321 |  |  | $ | 77,567 |  |
| Accounts receivable, net |  | 166,519 |  |  |  | 178,030 |  |
| Other receivables |  | 9,613 |  |  |  | 9,775 |  |
| Income tax receivable |  | 6,632 |  |  |  | 5,461 |  |
| Inventory, net |  | 254,055 |  |  |  | 261,654 |  |
| Assets held for sale |  | 11,901 |  |  |  | 11,901 |  |
| Prepaid expenses and other current assets |  | 64,456 |  |  |  | 58,534 |  |
| Total Current Assets |  | 614,497 |  |  |  | 602,922 |  |
| Property, plant and equipment, net |  | 105,940 |  |  |  | 102,942 |  |
| Deferred tax assets |  | 17,826 |  |  |  | 17,826 |  |
| Goodwill |  | 55,261 |  |  |  | 52,918 |  |
| Intangibles, net |  | 293,064 |  |  |  | 284,893 |  |
| Other non-current assets |  | 75,659 |  |  |  | 78,128 |  |
| Long-term investments |  | 29,973 |  |  |  | 32,060 |  |
| Total Assets | $ | 1,192,220 |  |  | $ | 1,171,689 |  |
| Liabilities, Redeemable Non-Controlling Interest and Equity |  |  |  |  |  |
| Current Liabilities |  |  |  |  |  |
| Accounts payable | $ | 170,477 |  |  | $ | 170,451 |  |
| Unearned revenue |  | 66,459 |  |  |  | 52,701 |  |
| Accrued expenses and other liabilities |  | 38,161 |  |  |  | 35,704 |  |
| Accrued wages and benefits |  | 25,910 |  |  |  | 32,853 |  |
| Income tax payable, net |  | 999 |  |  |  | 1,936 |  |
| Total Current Liabilities |  | 302,006 |  |  |  | 293,645 |  |
| Non-current revolving credit agreement outstanding |  | 190,085 |  |  |  | 189,576 |  |
| Deferred tax liabilities |  | 30,768 |  |  |  | 30,690 |  |
| Non-current unearned revenue |  | 24,082 |  |  |  | 22,065 |  |
| Non-current pension liability |  | 8,886 |  |  |  | 8,983 |  |
| Deferred compensation liability |  | 31,283 |  |  |  | 33,203 |  |
| Non-current lease obligations |  | 26,369 |  |  |  | 25,925 |  |
| Other non-current liabilities |  | 16,531 |  |  |  | 17,928 |  |
| Total Liabilities |  | 630,010 |  |  |  | 622,015 |  |
| Redeemable Non-Controlling Interest |  | 422,934 |  |  |  | 422,943 |  |
| Equity |  |  |  |  |  |
| Common stock |  | 800 |  |  |  | 795 |  |
| Additional paid-in capital |  | 812,071 |  |  |  | 808,913 |  |
| Accumulated other comprehensive income |  | 31,601 |  |  |  | 11,219 |  |
| Retained deficit |  | (700,088 | ) |  |  | (688,998 | ) |
| Treasury stock |  | (5,108 | ) |  |  | (5,198 | ) |
| Total Equity |  | 139,276 |  |  |  | 126,731 |  |
| Total Liabilities, Redeemable Non-Controlling Interest and Equity | $ | 1,192,220 |  |  | $ | 1,171,689 |  |

[0000950170-25-066343:8k_2_02:75]
Condensed Consolidated Statements of Loss

[0000950170-25-066343:8k_2_02:76]
(Preliminary, Unaudited)

[0000950170-25-066343:8k_2_02:77]
(In thousands, except per share amounts)

[0000950170-25-066343:8k_2_02:78]
|  |  | Three Months Ended |  |  |
|  |  | March 31, |  |  |
|  |  | 2025 |  |  | 2024 |  |  |
| Revenue |  |  |  |  |  |  |  |
| Network Solutions |  | $ | 202,217 |  |  | $ | 181,273 |  |  |
| Services & Support |  |  | 45,527 |  |  |  | 44,900 |  |  |
| Total Revenue |  |  | 247,744 |  |  |  | 226,173 |  |  |
| Cost of Revenue |  |  |  |  |  |  |  |
| Network Solutions |  |  | 133,925 |  |  |  | 128,278 |  |  |
| Network Solutions - charges and inventory write-down |  |  | — |  |  |  | 8,782 |  |  |
| Services & Support |  |  | 18,327 |  |  |  | 18,810 |  |  |
| Total Cost of Revenue |  |  | 152,252 |  |  |  | 155,870 |  |  |
| Gross Profit |  |  | 95,492 |  |  |  | 70,303 |  |  |
| Selling, general and administrative expenses |  |  | 50,285 |  |  |  | 59,100 |  |  |
| Research and development expenses |  |  | 48,859 |  |  |  | 60,251 |  |  |
| Goodwill impairment |  |  | — |  |  |  | 292,583 |  |  |
| Operating Loss |  |  | (3,652 | ) |  |  | (341,631 | ) |  |
| Interest and dividend income |  |  | 126 |  |  |  | 397 |  |  |
| Interest expense |  |  | (4,761 | ) |  |  | (4,598 | ) |  |
| Net investment (loss) gain |  |  | (1,686 | ) |  |  | 2,253 |  |  |
| Other income, net |  |  | 944 |  |  |  | 1,310 |  |  |
| Loss Before Income Taxes |  |  | (9,029 | ) |  |  | (342,269 | ) |  |
| Income tax benefit |  |  | 715 |  |  |  | 18,647 |  |  |
| Net Loss |  | $ | (8,314 | ) |  | $ | (323,622 | ) |  |
| Less: Net Income attributable to non-controlling interest (1) |  |  | 2,319 |  |  |  | 2,531 |  |  |
| Net Loss attributable to ADTRAN Holdings, Inc. |  | $ | (10,633 | ) |  | $ | (326,153 | ) |  |
| Weighted average shares outstanding – basic |  |  | 79,534 |  |  |  | 78,814 |  |  |
| Weighted average shares outstanding – diluted |  |  | 79,534 |  |  |  | 78,814 |  |  |
| Loss per common share attributable to ADTRAN Holdings, Inc. – basic |  | $ | (0.13 | ) | (2) | $ | (4.14 | ) |  |
| Loss per common share attributable to ADTRAN Holdings, Inc. – diluted |  | $ | (0.13 | ) | (2) | $ | (4.14 | ) |  |

[0000950170-25-066343:8k_2_02:79]
(1) For the three months ended March 31, 2025, we accrued $2.4 million net income attributable to non-controlling interest, representing the recurring cash compensation earned by non-controlling interest shareholders post-DPLTA. For the three months ended March 31, 2024, we recognized $2.5 million of net gain attributable to non-controlling interest, representing the recurring cash compensation earned by non-controlling interest shareholders post DPTLA.

[0000950170-25-066343:8k_2_02:80]
(2) Loss per common share attributable to ADTRAN Holdings, Inc. - basic and diluted - reflects a $(3) thousand effect of redemption of RNCI for the three months ended March 31, 2025.

[0000950170-25-066343:8k_2_02:81]
Condensed Consolidated Statements of Cash Flows

[0000950170-25-066343:8k_2_02:82]
(Preliminary, Unaudited)

[0000950170-25-066343:8k_2_02:83]
(In thousands)

[0000950170-25-066343:8k_2_02:84]
|  |  | March 31, |  |
|  |  | 2025 |  |  | 2024 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |
| Net loss |  | $ | (8,314 | ) |  | $ | (323,622 | ) |
| Adjustments to reconcile net loss to net cash provided by operating activities: |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 21,596 |  |  |  | 22,528 |  |
| Goodwill impairment |  |  | — |  |  |  | 292,583 |  |
| Amortization of debt issuance cost |  |  | 320 |  |  |  | 1,013 |  |
| Loss (Gain) on investments, net |  |  | 1,631 |  |  |  | (2,621 | ) |
| Net loss on disposal of property, plant and equipment |  |  | 13 |  |  |  | 150 |  |
| Stock-based compensation expense |  |  | 3,210 |  |  |  | 3,957 |  |
| Deferred income taxes |  |  | (475 | ) |  |  | (19,738 | ) |
| Other, net |  |  | — |  |  |  | 545 |  |
| Inventory write down - business efficiency program |  |  | — |  |  |  | 3,992 |  |
| Inventory reserves |  |  | 3,339 |  |  |  | 1,994 |  |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |
| Accounts receivable, net |  |  | 16,019 |  |  |  | 26,002 |  |
| Other receivables |  |  | (1,731 | ) |  |  | 5,605 |  |
| Income taxes receivable, net |  |  | (100 | ) |  |  | (1,296 | ) |
| Inventory |  |  | 10,030 |  |  |  | 32,221 |  |
| Prepaid expenses, other current assets and other assets |  |  | 1,504 |  |  |  | (15,882 | ) |
| Accounts payable |  |  | (4,222 | ) |  |  | 553 |  |
| Accrued expenses and other liabilities |  |  | (1,196 | ) |  |  | 7,459 |  |
| Income taxes payable, net |  |  | 18 |  |  |  | 1,155 |  |
| Net cash provided by operating activities |  |  | 41,642 |  |  |  | 36,598 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (7,399 | ) |  |  | (12,180 | ) |
| Purchases of intangibles - developed technology |  |  | (11,296 | ) |  |  | (1,194 | ) |
| Proceeds from sales and maturities of available-for-sale investments |  |  | 660 |  |  |  | 873 |  |
| Purchases of available-for-sale investments |  |  | (170 | ) |  |  | (44 | ) |
| Payments for beneficial interests in securitized accounts receivable |  |  | (133 | ) |  |  | — |  |
| Net cash used in investing activities |  |  | (18,338 | ) |  |  | (12,545 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |
| Tax withholdings related to stock-based compensation settlements |  |  | (420 | ) |  |  | (176 | ) |
| Proceeds from stock option exercises |  |  | 756 |  |  |  | 219 |  |
| Proceeds from receivables purchase agreement |  |  | — |  |  |  | 30,231 |  |
| Repayments on receivables purchase agreement |  |  | — |  |  |  | (32,437 | ) |
| Payment for redemption of redeemable non-controlling interest |  |  | (12 | ) |  |  | (5 | ) |
| Payment of debt issuance cost |  |  | — |  |  |  | (1,994 | ) |
| Net cash provided by (used in) financing activities |  |  | 324 |  |  |  | (4,162 | ) |
| Net increase in cash and cash equivalents |  |  | 23,628 |  |  |  | 19,891 |  |
| Effect of exchange rate changes |  |  | 126 |  |  |  | (301 | ) |
| Cash and cash equivalents, beginning of period |  |  | 77,567 |  |  |  | 87,167 |  |
| Cash and cash equivalents, end of period |  | $ | 101,321 |  |  | $ | 106,757 |  |
| Supplemental disclosure of cash financing activities: |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 4,129 |  |  | $ | 5,243 |  |
| Cash paid for income taxes |  | $ | 1,849 |  |  | $ | 2,315 |  |
| Cash used in operating activities related to operating leases |  | $ | 2,696 |  |  | $ | 2,384 |  |
| Supplemental disclosure of non-cash investing activities: |  |  |  |  |  |  |
| Redemption of redeemable non-controlling interest |  | $ | (3 | ) |  | $ | — |  |
| Right-of-use assets obtained in exchange for lease obligations |  | $ | 1,893 |  |  | $ | 842 |  |
| Purchases of property, plant and equipment included in accounts payable |  | $ | 1,162 |  |  | $ | 1,689 |  |

[0000950170-25-066343:8k_2_02:85]
Supplemental Information

[0000950170-25-066343:8k_2_02:86]
Reconciliation of Preliminary Gross Profit and Preliminary Gross Margin to

[0000950170-25-066343:8k_2_02:87]
Preliminary Non-GAAP Gross Profit and Preliminary Non-GAAP Gross Margin

[0000950170-25-066343:8k_2_02:88]
(Unaudited)

[0000950170-25-066343:8k_2_02:89]
(In thousands)

[0000950170-25-066343:8k_2_02:90]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |  | December 31, |  |  | March 31, |  |
|  |  | 2025 |  |  | 2024 |  |  | 2024 |  |
| Total Revenue |  | $ | 247,744 |  |  | $ | 242,852 |  |  | $ | 226,173 |  |
| Cost of Revenue |  |  | 152,252 |  |  |  | 153,593 |  |  |  | 155,870 |  |
| Acquisition-related expenses, amortizations and adjustments (1) |  |  | (9,831 | ) |  |  | (9,980 | ) |  |  | (10,177 | ) |
| Stock-based compensation expense |  |  | (267 | ) |  |  | (317 | ) |  |  | (275 | ) |
| Restructuring expenses (2) |  |  | — |  |  |  | (538 | ) |  |  | (11,247 | ) |
| Integration expenses (3) |  |  | — |  |  |  | 123 |  |  |  | (35 | ) |
| Non-GAAP Cost of Revenue |  | $ | 142,154 |  |  | $ | 142,881 |  |  | $ | 134,136 |  |
| Gross Profit |  | $ | 95,492 |  |  | $ | 89,259 |  |  | $ | 70,303 |  |
| Non-GAAP Gross Profit |  | $ | 105,590 |  |  | $ | 99,971 |  |  | $ | 92,037 |  |
| Gross Margin |  |  | 38.5 | % |  |  | 36.8 | % |  |  | 31.1 | % |
| Non-GAAP Gross Margin |  |  | 42.6 | % |  |  | 41.2 | % |  |  | 40.7 | % |

[0000950170-25-066343:8k_2_02:91]
(1) Includes intangible amortization of backlog, inventory fair value adjustments, developed technology, customer relationships, and trade names acquired in connection with business combinations. We incur charges relating to the amortization of intangible assets and exclude these charges for purposes of calculating our non-GAAP measures. Such charges are significantly impacted by the timing and magnitude of our acquisitions. We exclude these charges for the purpose of calculating our non-GAAP measures, primarily because they are noncash expenses and our internal benchmarking analyses evidence that many industry participants and peers present non-GAAP financial measures excluding intangible asset amortization. Although this does not directly affect our cash position, the loss in value of intangible assets overtime can have a material impact on the equivalent GAAP earnings measure.

[0000950170-25-066343:8k_2_02:92]
(2) Includes expenses for a Business Efficiency Program designed to optimize the assets and business processes following the business combination with Adtran Networks. Other than the Company's aim of selling its headquarters, the Business Efficiency Program was completed as of December 31, 2024.

[0000950170-25-066343:8k_2_02:93]
(3) Includes expenses related to the Company's one-time integration bonus program in connection with synergy targets as a result of the business combination with Adtran Networks which was completed as of December 31, 2024.

[0000950170-25-066343:8k_2_02:94]
Supplemental Information

[0000950170-25-066343:8k_2_02:95]
Reconciliation of Preliminary Operating Expenses to Preliminary Non-GAAP Operating Expenses

[0000950170-25-066343:8k_2_02:96]
(Unaudited)

[0000950170-25-066343:8k_2_02:97]
(In thousands)

[0000950170-25-066343:8k_2_02:98]
|  |  | Three Months Ended |  |  |
|  |  | March 31, |  |  | December 31, |  |  | March 31, |  |  |
|  |  | 2025 |  |  | 2024 |  |  | 2024 |  |  |
| Operating Expenses |  | $ | 99,144 |  |  | $ | 106,365 |  |  | $ | 411,934 |  |  |
| Acquisition-related expenses, amortizations and adjustments (1) |  |  | (2,249 | ) | (2) |  | (5,294 | ) | (7) |  | (4,881 | ) | (11) |
| Stock-based compensation expense |  |  | (2,943 | ) | (3) |  | (3,351 | ) | (8) |  | (3,447 | ) | (12) |
| Restructuring expenses |  |  | — |  | (4) |  | (3,567 | ) | (9) |  | (5,862 | ) | (13) |
| Integration expenses |  |  | — |  | (5) |  | (586 | ) | (10) |  | (480 | ) | (14) |
| Deferred compensation adjustments (6) |  |  | 1,547 |  |  |  | 451 |  |  |  | (1,940 | ) |  |
| Goodwill impairment |  |  | — |  |  |  | — |  |  |  | (292,583 | ) | (15) |
| Non-GAAP Operating Expenses |  | $ | 95,499 |  |  | $ | 94,018 |  |  | $ | 102,741 |  |  |

[0000950170-25-066343:8k_2_02:99]
(1) We incur charges relating to the amortization of intangible assets and exclude these charges for purposes of calculating our non-GAAP measures. Such charges are significantly impacted by the timing and magnitude of our acquisitions. We exclude these charges for the purpose of calculating our non-GAAP measures, primarily because they are non-cash expenses and our internal benchmarking analyses evidence that many industry participants and peers present non-GAAP financial measures excluding intangible asset amortization. Although this does not directly affect our cash position, the loss in value of intangible assets over time can have a material impact on the equivalent GAAP earnings measure.

[0000950170-25-066343:8k_2_02:100]
(2) Includes $2.2M of intangible amortization of developed technology, customer relationships, and trade names acquired in connection with business combinations.

[0000950170-25-066343:8k_2_02:101]
(3) $2.0 million is included in selling, general and administrative expenses and $0.9 million is included in research and development expenses on the condensed consolidated statements of loss.

[0000950170-25-066343:8k_2_02:102]
(4) Other than the Company's aim of selling its headquarters, the Business Efficiency Program was completed as of December 31, 2024.

[0000950170-25-066343:8k_2_02:103]
(5) Includes expenses related to the Company's one-time integration bonus program in connection with synergy targets as a result of the business combination with Adtran Networks and which was completed as of December 31, 2024.

[0000950170-25-066343:8k_2_02:104]
(6) Includes non-cash change in fair value of equity investments held in the ADTRAN Holdings, Inc. Deferred Compensation Program for certain employees, all of which is included in selling, general and administrative expenses on the condensed consolidated statement of loss.

[0000950170-25-066343:8k_2_02:105]
(7) Includes $4.3M of intangible amortization of developed technology, customer relationships, and trade names acquired in connection with business combinations and $1.0 million of legal and advisory fees related to a previously contemplated significant transaction which are included in selling, general and administrative expenses on the condensed consolidated statements of loss.

[0000950170-25-066343:8k_2_02:106]
(8) $2.4 million is included in selling, general and administrative expenses and $1.0 million is included in research and development expenses on the condensed consolidated statements of loss.

[0000950170-25-066343:8k_2_02:107]
(9) $1.2 million is included in selling, general and administrative expenses and $2.4 million is included in research and development expenses on the condensed consolidated statements of loss. Includes expenses for a Business Efficiency Program designed to optimize the assets and business processes following the business combination with Adtran Networks. Other than the Company's aim of selling its headquarters, the Business Efficiency Program was completed as of December 31, 2024.

[0000950170-25-066343:8k_2_02:108]
(10) $0.6 million is included in selling, general and administrative expenses and less than $0.1 million is included in research and development expenses on the condensed consolidated statements of loss, and is primarily related to the Company's one-time integration bonus program in connection with synergy targets as a result of the business combination with Adtran Networks.

[0000950170-25-066343:8k_2_02:109]
(11) Includes intangible amortization of developed technology, customer relationships, and trade names acquired in connection with business combinations, of which $4.4 million is included in selling, general and administrative expenses and $0.5 million is included in research and development expenses on the condensed consolidated statements of loss.

[0000950170-25-066343:8k_2_02:110]
(12) $2.5 million is included in selling, general and administrative expenses and $1.0 million is included in research and development expenses on the condensed consolidated statements of loss.

[0000950170-25-066343:8k_2_02:111]
(13) $1.8 million is included in selling, general and administrative expenses and $4.1 million is included in research and development expenses on the condensed consolidated statements of loss. Includes expenses for a Business Efficiency Program designed to optimize the assets and business processes following the business combination with Adtran Networks. Other than the Company's aim of selling its headquarters, the Business Efficiency Program was completed as of December 31, 2024.

[0000950170-25-066343:8k_2_02:112]
(14) $0.5 million is included in selling, general and administrative expenses and $0.02 million is included in research and development expenses on the condensed consolidated statements of loss. Includes legal and advisory fees totaling $0.1 million related primarily to the DPLTA proceedings that are recorded in selling, general and administrative expenses. Includes expenses totaling $0.4 million related to the Company's one-time integration bonus program in connection with synergy targets as a result of the business combination with Adtran Networks of which $0.4 million are included in selling, general and administrative expenses and $0.02 million are included in research and development expenses. The transformation bonus expense of $0.4 million includes $0.2 million of stock compensation expense.

[0000950170-25-066343:8k_2_02:113]
(15) Non-cash impairment of goodwill in our Network Solutions reporting unit, necessitated by factors such as a decrease in the Company's market capitalization, cautious service provider spending due to economic uncertainty and continued elevated customer inventory adjustments.

[0000950170-25-066343:8k_2_02:114]
Supplemental Information

[0000950170-25-066343:8k_2_02:115]
Reconciliation of Preliminary Operating Loss to Preliminary Non-GAAP Operating Income (Loss)

[0000950170-25-066343:8k_2_02:116]
(Unaudited)

[0000950170-25-066343:8k_2_02:117]
(In thousands)

[0000950170-25-066343:8k_2_02:118]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |  | December 31, |  |  | March 31, |  |
|  |  | 2025 |  |  | 2024 |  |  | 2024 |  |
| Operating Loss |  | $ | (3,652 | ) |  | $ | (17,106 | ) |  | $ | (341,631 | ) |
| Acquisition related expenses, amortizations and adjustments (1) |  |  | 12,080 |  |  |  | 15,274 |  |  |  | 15,058 |  |
| Stock-based compensation expense |  |  | 3,210 |  |  |  | 3,668 |  |  |  | 3,722 |  |
| Restructuring expenses (2) |  |  | — |  |  |  | 4,105 |  |  |  | 17,110 |  |
| Integration expenses (3) |  |  | — |  |  |  | 464 |  |  |  | 514 |  |
| Deferred compensation adjustments (4) |  |  | (1,547 | ) |  |  | (451 | ) |  |  | 1,940 |  |
| Goodwill impairment (5) |  |  | — |  |  |  | — |  |  |  | 292,583 |  |
| Non-GAAP Operating Income (Loss) |  | $ | 10,091 |  |  | $ | 5,954 |  |  | $ | (10,704 | ) |

[0000950170-25-066343:8k_2_02:119]
(1) Includes intangible amortization of backlog, inventory fair value adjustments, developed technology, customer relationships, and trade names acquired in connection with business combinations. We incur charges relating to the amortization of intangible assets and exclude these charges for purposes of calculating our non-GAAP measures. Such charges are significantly impacted by the timing and magnitude of our acquisitions. We exclude these charges for the purpose of calculating our non-GAAP measures, primarily because they are non-cash expenses and our internal benchmarking analyses evidence that many industry participants and peers present non-GAAP financial measures excluding intangible asset amortization. Although this does not directly affect our cash position, the loss in value of intangible assets overtime can have a material impact on the equivalent GAAP earnings measure.

[0000950170-25-066343:8k_2_02:120]
(2) Includes expenses for a Business Efficiency Program designed to optimize the assets and business processes following the business combination with Adtran Networks. Other than the Company's aim of selling its headquarters, the Business Efficiency Program was completed as of December 31, 2024.

[0000950170-25-066343:8k_2_02:121]
(3) Includes expenses related to the Company's one-time integration bonus program in connection with synergy targets as a results of the business combination with Adtran Networks.

[0000950170-25-066343:8k_2_02:122]
(4) Includes non-cash change in fair value of equity investments held in the ADTRAN Holdings, Inc. Deferred Compensation Program for certain employees, all of which is included in selling, general and administrative expenses on the condensed consolidated statement of loss.

[0000950170-25-066343:8k_2_02:123]
(5) Non-cash impairment of goodwill in our Network Solutions reporting unit, necessitated by factors such as a decrease in the Company's market capitalization, cautious service provider spending due to economic uncertainty and continued elevated customer inventory adjustments.

[0000950170-25-066343:8k_2_02:124]
Supplemental Information

[0000950170-25-066343:8k_2_02:125]
Reconciliation of Preliminary Other Expense to Preliminary Non-GAAP Other Expense

[0000950170-25-066343:8k_2_02:126]
(Unaudited)

[0000950170-25-066343:8k_2_02:127]
(In thousands)

[0000950170-25-066343:8k_2_02:128]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |  | December 31, |  |  | March 31, |  |
|  |  | 2025 |  |  | 2024 |  |  | 2024 |  |
| Interest and dividend income |  | $ | 126 |  |  | $ | 1,631 |  |  | $ | 397 |  |
| Interest expense |  |  | (4,761 | ) |  |  | (4,870 | ) |  |  | (4,598 | ) |
| Net investment (loss) gain |  |  | (1,686 | ) |  |  | (920 | ) |  |  | 2,253 |  |
| Other income, net |  |  | 944 |  |  |  | 687 |  |  |  | 1,310 |  |
| Total Other Expense |  | $ | (5,377 | ) |  | $ | (3,472 | ) |  | $ | (638 | ) |
| Deferred compensation adjustments (1) |  |  | 1,649 |  |  |  | 1,090 |  |  |  | (2,439 | ) |
| Pension expense (2) |  |  | 11 |  |  |  | 7 |  |  |  | 7 |  |
| Non-GAAP Other Expense |  | $ | (3,717 | ) |  | $ | (2,375 | ) |  | $ | (3,070 | ) |

[0000950170-25-066343:8k_2_02:129]
(1) Includes non-cash change in fair value of equity investments held in the ADTRAN Holdings, Inc. Deferred Compensation Program for Employees.

[0000950170-25-066343:8k_2_02:130]
(2) Includes amortization of actuarial losses related to the Company's pension plan for employees in certain foreign countries.

[0000950170-25-066343:8k_2_02:131]
Supplemental Information

[0000950170-25-066343:8k_2_02:132]
Reconciliation of Preliminary Net Loss inclusive of Non-Controlling Interest to

[0000950170-25-066343:8k_2_02:133]
Preliminary Non-GAAP Net Income (Loss) inclusive of Non-Controlling Interest

[0000950170-25-066343:8k_2_02:134]
(Unaudited)

[0000950170-25-066343:8k_2_02:135]
and

[0000950170-25-066343:8k_2_02:136]
Reconciliation of Preliminary Net Loss attributable to ADTRAN Holdings, Inc. and

[0000950170-25-066343:8k_2_02:137]
Preliminary Loss per Common Share attributable to ADTRAN Holdings, Inc. – Basic and Diluted to

[0000950170-25-066343:8k_2_02:138]
Preliminary Non-GAAP Net Income (Loss) attributable to ADTRAN Holdings, Inc. and

[0000950170-25-066343:8k_2_02:139]
Preliminary Non-GAAP Earnings (Loss) per Common Share attributable to ADTRAN Holdings, Inc. – Basic and Diluted

[0000950170-25-066343:8k_2_02:140]
(Unaudited)

[0000950170-25-066343:8k_2_02:141]
(In thousands, except per share amounts)

[0000950170-25-066343:8k_2_02:142]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |  | December 31, |  |  | March 31, |  |
|  |  | 2025 |  |  | 2024 |  |  | 2024 |  |
| Net Loss attributable to ADTRAN Holdings, Inc. common shareholders |  | $ | (10,636 | ) |  | $ | (47,885 | ) |  | $ | (326,153 | ) |
| Effect of redemption of RNCI (1) |  |  | 3 |  |  |  | (5 | ) |  |  | — |  |
| Net Loss attributable to ADTRAN Holdings, Inc. |  | $ | (10,633 | ) |  | $ | (47,890 | ) |  | $ | (326,153 | ) |
| Net Income attributable to non-controlling interest (2) |  |  | 2,319 |  |  |  | 2,407 |  |  |  | 2,531 |  |
| Net Loss inclusive of non-controlling interest |  | $ | (8,314 | ) |  | $ | (45,483 | ) |  | $ | (323,622 | ) |
| Acquisition related expenses, amortizations and adjustments (3) |  |  | 12,080 |  |  |  | 15,274 |  |  |  | 15,058 |  |
| Stock-based compensation expense |  |  | 3,210 |  |  |  | 3,668 |  |  |  | 3,722 |  |
| Deferred compensation adjustments (4) |  |  | 102 |  |  |  | 639 |  |  |  | (499 | ) |
| Pension adjustments (5) |  |  | 11 |  |  |  | 7 |  |  |  | 7 |  |
| Restructuring expenses (6) |  |  | — |  |  |  | 4,105 |  |  |  | 17,110 |  |
| Integration expenses (7) |  |  | — |  |  |  | 464 |  |  |  | 514 |  |
| Goodwill impairment |  |  | — |  |  |  | — |  |  |  | 292,583 |  |
| Tax effect of adjustments to net loss (8) |  |  | (2,393 | ) |  |  | 22,071 |  |  |  | (18,481 | ) |
| Non-GAAP Net Income (Loss) inclusive of non-controlling interest |  | $ | 4,696 |  |  | $ | 745 |  |  | $ | (13,608 | ) |
| Net Income attributable to non-controlling interest (2) |  |  | 2,319 |  |  |  | 2,407 |  |  |  | 2,531 |  |
| Non-GAAP Net Income (Loss) attributable to ADTRAN Holdings, Inc. |  | $ | 2,377 |  |  | $ | (1,662 | ) |  | $ | (16,139 | ) |
| Effect of redemption of RNCI (1) |  |  | (3 | ) |  |  | 5 |  |  |  | - |  |
| Non-GAAP Net Income (Loss) attributable to ADTRAN Holdings, Inc. common shareholders |  | $ | 2,374 |  |  | $ | (1,657 | ) |  | $ | (16,139 | ) |
| Weighted average shares outstanding – basic |  |  | 79,534 |  |  |  | 79,091 |  |  |  | 78,814 |  |
| Weighted average shares outstanding – diluted |  |  | 79,534 |  |  |  | 79,091 |  |  |  | 78,814 |  |
| Loss per common share attributable to ADTRAN Holdings, Inc. – basic |  | $ | (0.13 | ) |  | $ | (0.61 | ) |  | $ | (4.14 | ) |
| Loss per common share attributable to ADTRAN Holdings, Inc. – diluted |  | $ | (0.13 | ) |  | $ | (0.61 | ) |  | $ | (4.14 | ) |
| Non-GAAP Earnings (Loss) per common share attributable to ADTRAN – basic |  | $ | 0.03 |  |  | $ | (0.02 | ) |  | $ | (0.20 | ) |
| Non-GAAP Earnings (Loss) per common share attributable to ADTRAN – diluted |  | $ | 0.03 |  |  | $ | (0.02 | ) |  | $ | (0.20 | ) |

[0000950170-25-066343:8k_2_02:143]
(1) Loss per common share attributable to ADTRAN Holdings, Inc. - basic and diluted - reflects a $3 thousand and $5 thousand effect of redemption for the three months ended March 31, 2025 and December 31, 2024 respectively.

[0000950170-25-066343:8k_2_02:144]
(2) Represents the non-controlling interest portion of the Company's ownership of Adtran Networks pre-DPLTA and the annual recurring compensation earned by redeemable non-controlling interests and accrued by the Company post-DPLTA.

[0000950170-25-066343:8k_2_02:145]
(3) We incur charges relating to the amortization of intangible assets and exclude these charges for purposes of calculating our non-GAAP measures. Such charges are significantly impacted by the timing and magnitude of our acquisitions. We exclude these charges for the purpose of calculating our non-GAAP measures, primarily because they are non-cash expenses and our internal benchmarking analyses evidence that many industry participants and peers present non-GAAP financial measures excluding intangible asset amortization. Although this does not directly affect our cash position, the loss in value of intangible assets over time can have a material impact on the equivalent GAAP earnings measure.

[0000950170-25-066343:8k_2_02:146]
(4) Includes non-cash change in fair value of equity investments held in deferred compensation plans offered to certain employees.

[0000950170-25-066343:8k_2_02:147]
(5) Includes amortization of actuarial losses related to the Company's pension plan for employees in certain foreign countries.

[0000950170-25-066343:8k_2_02:148]
(6) Includes expenses for a Business Efficiency Program designed to optimize the assets and business processes following the business combination with Adtran Networks. Other than the Company's aim of selling its headquarters, the Business Efficiency Program was completed as of December 31, 2024.

[0000950170-25-066343:8k_2_02:149]
(7) Includes expenses related to the Company's one-time integration bonus program in connection with synergy targets as a results of the business combination with Adtran Networks. Includes fees incurred for the expansion of internal controls at Adtran Networks and the implementation of the DPTLA which was completed as of December 31, 2024.

[0000950170-25-066343:8k_2_02:150]
(8) Represents the tax effect of non-GAAP adjustments. Beginning in the period ended September 30, 2024, the Company changed its method of calculating non-GAAP income taxes by applying blended statutory tax rates to non-GAAP losses before income taxes in order to include current and deferred income tax expenses that are commensurate with the non-GAAP measure of profitability. The blended statutory tax rate is calculated using 0%, resulting in no tax benefits net of impact of valuation allowance, for the loss jurisdiction’s non-GAAP losses before income taxes and 30% for all remaining jurisdictions’ non-GAAP income before income taxes. Prior periods have been adjusted to reflect the application of blended statutory tax rates, net of impact of valuation allowance, to non-GAAP losses before income taxes as opposed to the previous application of blended statutory and effective tax rates to separate non-GAAP adjustments. We previously reported the tax effect of the adjustment to non-GAAP net loss under the prior method of $5.6 million for the three months ended March 31, 2024.

[0000950170-25-066343:8k_2_02:151]
Supplemental Information

[0000950170-25-066343:8k_2_02:152]
Reconciliation of Preliminary Net Cash Provided By Operating Activities to Preliminary Free Cash Flow

[0000950170-25-066343:8k_2_02:153]
(Unaudited)

[0000950170-25-066343:8k_2_02:154]
(In thousands)

[0000950170-25-066343:8k_2_02:155]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |  | December 31, |  |  | March 31, |  |
|  |  | 2025 |  |  | 2024 |  |  | 2024 |  |
| Net Cash provided by operating activities |  | $ | 41,642 |  |  | $ | 4,556 |  |  | $ | 36,598 |  |
| Purchases of property, plant and equipment and developed technologies (1) |  |  | (18,695 | ) |  |  | (14,942 | ) |  |  | (13,374 | ) |
| Free cash flow (Non-GAAP) |  | $ | 22,947 |  |  | $ | (10,386 | ) |  | $ | 23,224 |  |

[0000950170-25-066343:8k_2_02:156]
(1) Purchases related to capital expenditures and developed technologies.
