# ADTN note change history — 0000950170-24-125685 → 0000950170-25-075374


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2025-05-20):
[0000950170-25-075374:note_history:1]
DPLTA Appraisal Proceedings

- added (2025-05-20):
[0000950170-25-075374:note_history:2]
In addition to such Legal Matters, the Company is a party to appraisal proceedings relating to the DPLTA which were originally filed with the Landgericht Meiningen (Meiningen District Court) on February 3, 2023. The DPLTA provides that Adtran Networks shareholders (other than the Company) be offered, at their election, (i) to put their Adtran Networks shares to the Company in exchange for compensation in cash of €17.21 per share, plus guaranteed interest or (ii) to remain Adtran Networks shareholders and receive recurring cash compensation of €0.52 per share for each full fiscal year of Adtran Networks. The appraisal proceedings, which were initiated by certain minority shareholders of Adtran Networks, challenge the adequacy of both forms of compensation. While the Company believes that the compensation offered in connection with the DPLTA is fair, it notes that German courts often adjudicate increases of the cash compensation to plaintiffs in varying amounts in connection with German appraisal proceedings. Therefore, the Company cannot rule out that the first instance court or an appellate court may increase the cash compensation owed to the minority Adtran Networks shareholders. Given the stage of the appraisal proceedings, the Company is currently unable to predict the likely outcome or estimate the potential financial impact, if any, of the appraisal proceedings. If a ruling were to occur and be upheld upon appeal that required the Company to pay significant additional cash compensation to the Adtran Networks minority shareholders, there exists the possibility of a material adverse effect on our financial position and results of operations for the period in which the ruling occurs or future periods.

- changed (2025-05-20):
[0000950170-25-075374:note_history:3]
DPLTA Exit and Recurring Compensation Costs and the Absorption of Adtran Network's Annual Net Loss
  (was, 2024-11-12, similarity 0.6099):
[0000950170-24-125685:note_history:3]
DPLTA Exit and Recurring Compensation Costs

- changed (2025-05-20):
[0000950170-25-075374:note_history:4]
Pursuant to the terms of the DPLTA, each Adtran Networks shareholder (other than the Company) has received an offer to elect either (1) to remain an Adtran Networks shareholder and receive from us an Annual Recurring Compensation payment, or (2) to receive Exit Compensation plus guaranteed interest. The guaranteed interest under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid. The guaranteed interest rate is 5.0% plus a variable component (according to the German Civil Code) that was 2.27% as of March 31, 2025. Assuming all the minority holders of currently outstanding Adtran Networks shares were to elect the second option, the Company would be obligated to make aggregate Exit Compensation payments, including guaranteed interest, of approximately €338.5 million or approximately $366.1 million, based on an exchange rate as of March 31, 2025, and reflecting interest accrued through March 31, 2025, during the pendency of the appraisal proceedings discussed below. Shareholders electing the first option of Annual Recurring Compensation may later elect the second option. The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that were initiated in 2023 in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger). The Company expects to receive a ruling on a procedural matter in the DPLTA appraisal proceedings during the latter half of 2025 or 2026, which ruling, depending on outcome, will likely be appealed and may take 6-12 months to be decided on appeal. The Company does not expect that a trial on the merits of the DPLTA appraisal proceedings will commence until the procedural matter has been resolved. The proceeding for the trial on the merits of the DPLTA will likely take a minimum of 12 months for a ruling and such ruling may likewise be appealed, which would be expected to take an additional 12-24 months to be resolved. Accordingly, the Company does not expect a final decision on the DPLTA appraisal proceedings to be rendered and published prior to 2027, and most likely not until 2028 or beyond.
  (was, 2024-11-12, similarity 0.7904):
[0000950170-24-125685:note_history:4]
Pursuant to the terms of the DPLTA, each Adtran Networks shareholder (other than the Company) has received an offer to elect either (1) to remain an Adtran Networks shareholder and receive from us an Annual Recurring Compensation payment, or (2) to receive Exit Compensation plus guaranteed interest. The guaranteed interest under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid. The guaranteed interest rate is 5.0% plus a variable component (according to the German Civil Code) that was 3.37% as of September 30, 2024. Assuming all the minority holders of currently outstanding Adtran Networks shares were to elect the second option, we would be obligated to make aggregate Exit Compensation payments, including guaranteed interest, of approximately €326.9 million or approximately $364.1 million, based on an exchange rate as of September 30, 2024, and reflecting interest accrued through September 30, 2024, during the pendency of the appraisal proceedings discussed below. Shareholders electing the first option of Annual Recurring Compensation may later elect the second option. The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that have been initiated in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger).

- changed (2025-05-20):
[0000950170-25-075374:note_history:5]
Our obligation to pay Annual Recurring Compensation under the DPLTA is a continuing payment obligation, which will amount to approximately €8.9 million (or $9.7 million based on the current exchange rate) per year assuming none of the minority Adtran Networks shareholders were to elect Exit Compensation. The foregoing amounts do not reflect any potential increase in payment obligations that we may have depending on the outcome of ongoing appraisal proceedings in Germany. The Annual Recurring Compensation is due on the third banking day following the ordinary general shareholders’ meeting of Adtran Networks for the respective preceding fiscal year (but in any event within eight months following expiration of the fiscal year). With respect to the 2024 fiscal year, Adtran Networks’ ordinary general shareholders meeting is scheduled for June 27, 2025 and, therefore, the Annual Recurring Compensation will be due on July 2, 2025. During the three months ended March 31, 2025 and 2024, we accrued $2.4 million and $2.5 million, respectively, in Annual Recurring Compensation, which was reflected as an increase to retained deficit.
  (was, 2024-11-12, similarity 0.8748):
[0000950170-24-125685:note_history:5]
Our obligation to pay Annual Recurring Compensation under the DPLTA is a continuing payment obligation, which will amount to approximately €8.9 million (or $10.0 million based on the current exchange rate) per year assuming none of the minority Adtran Networks shareholders were to elect Exit Compensation. The foregoing amounts do not reflect any potential increase in payment obligations that we may have depending on the outcome of ongoing appraisal proceedings in Germany. The Annual Recurring Compensation is due on the third banking day following the ordinary general shareholders’ meeting of Adtran Networks for the respective preceding fiscal year (but in any event within eight months following expiration of the fiscal year). With respect to the 2023 fiscal year, Adtran Networks’ ordinary general shareholders’ meeting occurred on June 28, 2024 and, therefore, the Annual Recurring Compensation was paid on July 3, 2024. During the three months ended September 30, 2024 and 2023, we accrued $2.4 million and $2.6 million, respectively, in Annual Recurring Compensation. During the nine months ended September 30, 2024 and 2023, we accrued $7.4 million and $7.6 million, respectively, in Annual Recurring Compensation, which was reflected as an increase to retained deficit.

- added (2025-05-20):
[0000950170-25-075374:note_history:6]
For the three months ended March 31, 2025 and 2024, less than one thousand shares of Adtran Networks stock were tendered to the Company and Exit Compensation payments of approximately €12 thousand and €4 thousand, respectively, or approximately $13 thousand and $5 thousand based on the applicable exchange rates at the time of the transactions, were paid to Adtran Networks shareholders.

- added (2025-05-20):
[0000950170-25-075374:note_history:7]
In addition, under the DPLTA, subject to certain limitations pursuant to applicable law and the specific terms of the DPLTA, (i) the Company is entitled to issue binding instructions to the management board of Adtran Networks, (ii) Adtran Networks will transfer its annual profit to the Company, subject to, among other things, the creation or dissolution of certain reserves, and (iii) the Company will absorb the annual net loss incurred by Adtran Networks. The Company’s payment obligation in satisfaction of the requirement that it absorb Adtran Networks’ annual net loss applies to the net loss generated by Adtran Networks in 2024 and it will apply to any net loss generated by Adtran Networks in 2025.

- changed (2025-05-20):
[0000950170-25-075374:note_history:8]
Certain contracts, customers and jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of March 31, 2025 and December 31, 2024, we had commitments related to these bonds totaling $15.2 million and $15.7 million, respectively, which expire at various dates through April 2029. In general, we would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which we believe is remote.
  (was, 2024-11-12, similarity 0.9865):
[0000950170-24-125685:note_history:8]
Certain contracts, customers and jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of September 30, 2024, and December 31, 2023, we had commitments related to these bonds totaling $14.6 million and $10.8 million, respectively, which expire at various dates through April 2031. In general, we would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which we believe is remote.

- changed (2025-05-20):
[0000950170-25-075374:note_history:9]
The Company purchases components from a variety of suppliers and uses contract manufacturers to provide manufacturing services for our products. Our inventory purchase obligations are for product manufacturing requirements, as well as for commitments to suppliers to secure manufacturing capacity. Certain of our inventory purchase obligations with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. As of March 31, 2025, purchase obligations totaled $203.9 million.
  (was, 2024-11-12, similarity 0.9873):
[0000950170-24-125685:note_history:9]
The Company purchases components from a variety of suppliers and uses contract manufacturers to provide manufacturing services for our products. Our inventory purchase obligations are for product manufacturing requirements, as well as for commitments to suppliers to secure manufacturing capacity. Certain of our inventory purchase obligations with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. As of September 30, 2024, purchase obligations totaled $261.8 million.

- removed (2025-05-20):
[0000950170-24-125685:note_history:10]
For the three and nine months ended September 30, 2024, approximately 830 thousand shares and 831 thousand shares, respectively, of Adtran Networks stock were tendered to the Company. This resulted in total Exit Compensation payments of approximately €15.7 million, or approximately $17.4 million, based on an exchange rate as of September 30, 2024, being paid to Adtran Networks shareholders. For the three and nine months ended September 30, 2023, less than 1 thousand shares and 64 thousand shares, respectively, of Adtran Networks stock were tendered to the Company. This resulted in Exit Compensation payments of approximately €8 thousand and €1.1 million, respectively, or approximately $9 thousand and $1.2 million, respectively, based on an exchange rate as of September 30, 2023, being paid to Adtran Networks shareholders.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-05-20):
[0000950170-25-075374:note_history:11]
ADTRAN Holdings, Inc. (“Adtran” or the “Company”) is a leading global provider of networking and communications platforms, software, systems and services focused on the broadband access market, serving a diverse domestic and international customer base in multiple countries that includes large, medium and small Service Providers, alternative Service Providers, such as utilities, municipalities and fiber overbuilders, cable/MSOs, SMBs and distributed enterprises, including Fortune 500 companies with sophisticated business continuity applications; and federal, state and local government agencies. Our innovative solutions and services enable voice, data, video and internet-communications across a variety of network infrastructures and are currently in use by millions worldwide. We support our customers through our direct global sales organization and distribution networks. Our success depends upon our ability to increase unit volume and market share through the introduction of new products and succeeding generations of products having optimal selling prices and increased functionality as compared to both the prior generation of a product and to the products of competitors in order to gain market share. To service our customers and grow revenue, we are continually conducting research and developing new products addressing customer needs and testing those products for the specific requirements of the particular customers. We offer a broad portfolio of flexible software and hardware network solutions and services that enable Service Providers to meet today’s service demands, while enabling them to transition to the fully converged, scalable, highly-automated, cloud-controlled voice, data, internet and video network of the future. In addition to our global headquarters in Huntsville, Alabama, and our European headquarters in Munich, Germany, we have sales and research and development facilities in strategic global locations.
  (was, 2024-11-12, similarity 0.999):
[0000950170-24-125685:note_history:11]
ADTRAN Holdings, Inc. (“ADTRAN” or the “Company”) is a leading global provider of networking and communications platforms, software, systems and services focused on the broadband access market, serving a diverse domestic and international customer base in multiple countries that includes large, medium and small Service Providers, alternative Service Providers, such as utilities, municipalities and fiber overbuilders, cable/MSOs, SMBs and distributed enterprises, including Fortune 500 companies with sophisticated business continuity applications; and federal, state and local government agencies. Our innovative solutions and services enable voice, data, video and internet-communications across a variety of network infrastructures and are currently in use by millions worldwide. We support our customers through our direct global sales organization and our distribution networks. Our success depends upon our ability to increase unit volume and market share through the introduction of new products and succeeding generations of products having optimal selling prices and increased functionality as compared to both the prior generation of a product and to the products of competitors in order to gain market share. To service our customers and grow revenue, we are continually conducting research and developing new products addressing customer needs and testing those products for the specific requirements of the particular customers. We offer a broad portfolio of flexible software and hardware network solutions and services that enable Service Providers to meet today’s service demands, while enabling them to transition to the fully converged, scalable, highly-automated, cloud-controlled voice, data, internet and video network of the future. In addition to our global headquarters in Huntsville, Alabama, and our European headquarters in Munich, Germany, we have sales and research and development facilities in strategic global locations.

- changed (2025-05-20):
[0000950170-25-075374:note_history:12]
Under the DPLTA, subject to certain limitations pursuant to applicable law and the specific terms of the DPLTA, (i) the Company is entitled to issue binding instructions to the management board of Adtran Networks, (ii) Adtran Networks will transfer its annual profit to the Company, subject to, among other things, the creation or dissolution of certain reserves, and (iii) the Company will absorb the annual net loss incurred by Adtran Networks. The Company’s payment obligation in satisfaction of the requirement that it absorb Adtran Networks’ annual net loss applies to the net loss generated by Adtran Networks in 2024 and it will apply to any net loss generated by Adtran Networks in 2025.
  (was, 2024-11-12, similarity 0.6884):
[0000950170-24-125685:note_history:12]
Under the DPLTA, subject to certain limitations pursuant to applicable law and the specific terms of the DPLTA, (i) the Company is entitled to issue binding instructions to the management board of Adtran Networks, (ii) Adtran Networks will transfer its annual profit to the Company, subject to, among other things, the creation or dissolution of certain reserves, and (iii) the Company will generally absorb the annual net loss incurred by Adtran Networks. The obligation of the Company to absorb Adtran Networks’ annual net loss applied for the first time to the loss generated by Adtran Networks in 2023.

- changed (2025-05-20):
[0000950170-25-075374:note_history:13]
Pursuant to the terms of the DPLTA, each Adtran Networks shareholder (other than the Company) has received an offer to elect either (1) to remain an Adtran Networks shareholder and receive from us an Annual Recurring Compensation payment, or (2) to receive Exit Compensation plus guaranteed interest. The guaranteed interest under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid. The guaranteed interest rate is 5.0% plus a variable component (according to the German Civil Code) that was 2.27% as of March 31, 2025. Assuming all the minority holders of currently outstanding Adtran Networks shares were to elect the second option, we would be obligated to make aggregate Exit Compensation payments, including guaranteed interest, of approximately €338.5 million or approximately $366.1 million, based on an exchange rate as of March 31, 2025, and reflecting interest accrued through March 31, 2025 during the pendency of the appraisal proceedings discussed below. Shareholders electing the first option of Annual Recurring Compensation may later elect the second option. The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that were initiated in 2023 in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger). The Company expects to receive a ruling on a procedural matter in the DPLTA appraisal proceedings during the latter half of 2025 or 2026, which ruling, depending on outcome, will likely be appealed and may take 6-12 months to be decided on appeal. The Company does not expect that a trial on the merits of the DPLTA appraisal proceedings will commence until the procedural matter has been resolved. The proceeding for the trial on the merits of the DPLTA will likely take a minimum of 12 months for a ruling and such ruling may likewise be appealed, which would be expected to take an additional 12-24 months to be resolved. Accordingly, the Company does not expect a final decision on the DPLTA appraisal proceedings to be rendered and published prior to 2027, and most likely not until 2028 or beyond.
  (was, 2024-11-12, similarity 0.793):
[0000950170-24-125685:note_history:13]
Pursuant to the terms of the DPLTA, each Adtran Networks shareholder (other than the Company) has received an offer to elect either (1) to remain an Adtran Networks shareholder and receive from us an Annual Recurring Compensation payment, or (2) to receive Exit Compensation plus guaranteed interest. The guaranteed interest under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid. The guaranteed interest rate is 5.0% plus a variable component (according to the German Civil Code) that was 3.37% as of September 30, 2024. Assuming all the minority holders of currently outstanding Adtran Networks shares were to elect the second option, we would be obligated to make aggregate Exit Compensation payments, including guaranteed interest, of approximately €326.9 million or approximately $364.1 million, based on an exchange rate as of September 30, 2024, and reflecting interest accrued through September 30, 2024 during the pendency of the appraisal proceedings discussed below. Shareholders electing the first option of Annual Recurring Compensation may later elect the second option. The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that have been initiated in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger).

- changed (2025-05-20):
[0000950170-25-075374:note_history:14]
Additionally, our obligation to pay Annual Recurring Compensation under the DPLTA is a continuing payment obligation, which will amount to approximately €8.9 million (or $9.7 million based on the current exchange rate) per year assuming none of the minority Adtran Networks shareholders as of March 31, 2025 were to elect Exit Compensation. The foregoing amounts do not reflect any potential increase in payment obligations that we may have depending on the outcome of ongoing appraisal proceedings in Germany. The Annual Recurring Compensation is due on the third banking day following the ordinary general shareholders’ meeting of Adtran Networks for the respective preceding fiscal year (but in any event within eight months following expiration of the fiscal year). With respect to the 2023 fiscal year, Adtran Networks’ ordinary general shareholders’ meeting occurred on June 28, 2024 and, therefore, the Annual Recurring Compensation was paid on July 3, 2024. With respect to the 2024 fiscal year, Adtran Networks’ ordinary general shareholder meeting is scheduled for June 27, 2025 and, therefore, the Annual Recurring Compensation will be due on July 2, 2025. During the three months ended March 31, 2025 and 2024, we accrued $2.4 million and $2.5 million, respectively, in Annual Recurring Compensation. The Annual Recurring Compensation is reflected as an increase to retained deficit in the Condensed Consolidated Balance Sheets.
  (was, 2024-11-12, similarity 0.6709):
[0000950170-24-125685:note_history:14]
We are also obligated to absorb any annual net loss of Adtran Networks under the DPLTA. Additionally, our obligation to pay Annual Recurring Compensation under the DPLTA is a continuing payment obligation, which will amount to approximately €8.9 million (or $10.0 million based on the current exchange rate) per year assuming none of the minority Adtran Networks shareholders as of September 30, 2024 were to elect Exit Compensation. The foregoing amounts do not reflect any potential increase in payment obligations that we may have depending on the outcome of ongoing appraisal proceedings in Germany. The Annual Recurring Compensation is due on the third banking day following the ordinary general shareholders’ meeting of Adtran Networks for the respective preceding fiscal year (but in any event within eight months following expiration of the fiscal year). With respect to the 2023 fiscal year, Adtran Networks’ ordinary general shareholders’ meeting occurred on June 28, 2024 and, therefore, the Annual Recurring Compensation was paid on July 3, 2024. During the three months ended September 30, 2024 and 2023, we accrued $2.4 million and $2.6 million, respectively, in Annual Recurring Compensation. During the nine months ended September 30, 2024 and 2023, we accrued $7.4 million and $7.6 million, respectively, in Annual Recurring Compensation. The Annual Recurring Compensation is reflected as an increase to retained deficit in the Condensed Consolidated Balance Sheets.

- added (2025-05-20):
[0000950170-25-075374:note_history:15]
On October 18, 2022, the Company's Board of Directors authorized the Company to purchase additional shares of Adtran Networks through open market purchases not to exceed 15,346,544 shares.

- changed (2025-05-20):
[0000950170-25-075374:note_history:16]
On July 18, 2022, ADTRAN, Inc., as the borrower, and ADTRAN Holdings, Inc. entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (“Credit Agreement”), which has since been amended four times. The Company had access to $180.7 million on its Credit Facility for future borrowings; however, as of March 31, 2025 and the date of this filing the Company was limited to additional borrowings of $25.8 million based on debt covenant compliance metrics. The financial covenants under the Credit Agreement, as amended, require the Company to maintain a Consolidated Total Net Leverage Ratio of 5.00x, a Consolidated Senior Secured Net Leverage Ratio of 3.25x (4.0x to 3.5x during a Springing Covenant Period) and a Consolidated Fixed Charge Coverage Ratio of 1.25x. See Note 10, Revolving Credit Agreements for additional information regarding the terms of the Wells Fargo Credit Agreement.
  (was, 2024-11-12, similarity 0.965):
[0000950170-24-125685:note_history:16]
On July 18, 2022, ADTRAN, Inc., as the borrower, and ADTRAN Holdings, Inc. entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (“Credit Agreement”), which has since been amended four times. The Company had access to $205.6 million on its Credit Facility for future borrowings; however, as of September 30, 2024, the Company was limited to additional borrowings of $24.1 million based on debt covenant compliance metrics. The financial covenants under the Credit Agreement, as amended, require the Company to maintain a Consolidated Total Net Leverage Ratio of 5.00x, a Consolidated Senior Secured Net Leverage Ratio of 3.25x (4.0x to 3.5x during a Springing Covenant Period) and a Consolidated Fixed Charge Coverage Ratio of 1.25x.  See Note 11, Revolving Credit Agreements for additional information regarding the terms of the Wells Fargo Credit Agreement and its amendments.

- added (2025-05-20):
[0000950170-25-075374:note_history:17]
As of March 31, 2025, and as of the date of issuance of these financial statements, the Company does not have sufficient liquidity to meet the substantial majority of its payment obligations under the DPLTA pertaining to Exit Compensation. For the three months ended March 31, 2025 and 2024, less than one thousand shares of Adtran Networks stock were tendered to the Company and Exit Compensation payments of approximately €12 thousand and €4 thousand, respectively, or approximately $13 thousand and $5 thousand based on the applicable exchange rates at the time of the transaction, were paid to Adtran Networks shareholders. On April 14, 2025, 0.4 million shares of Adtran Networks stock were tendered to the Company and Exit Compensation payments of approximately €7.0 million or approximately $7.5 million, based on the applicable exchange rate at the time of the transaction, will be paid to Adtran Networks shareholders. We believe the probability that more than a small minority of Adtran Networks shareholders elect to receive Exit Compensation in the next twelve months is remote based on the following factors: (i) the shareholders can exercise their right to receive the Exit Compensation until two months after publication of the final decision in the appraisal proceedings and we do not expect the final decision to be published within the next 12 months; (ii) the diverse base of shareholders that must make this election on an individual shareholder basis; (iii) the fact that the Company expects to receive a procedural decision during 2025 or 2026 that will likely be appealed and, while the date of a decision by the court on the merits of the case is uncertain, it will likely take a minimum of 12 months for a ruling and, thereafter, an expected appeal process will take a further 12-24 months to resolve; (iv) the current guaranteed Annual Recurring Compensation payment; and (v) the current trading value of Adtran Networks shares.

- added (2025-05-20):
[0000950170-25-075374:note_history:18]
The Company experienced revenue declines in the year ended December 31, 2024. However, customers have started to replenish their inventories to meet increasing demand and management expects orders and billings to increase during the remainder of 2025. The Company continues to implement plans to preserve cash liquidity to maintain compliance with the Company’s covenants in case of further impacts related to customer inventory reduction initiatives and uncertain macroeconomic conditions. Additionally, the Company suspended dividend payments and effectuated a business efficiency program (the "Business Efficiency Program"), which targeted the reduction of ongoing operating expenses and focused on enhancing capital efficiency. The Business Efficiency Program was completed as of December 31, 2024, other than the Company's aim of selling its headquarters. The Company has determined that it is probable that the sale of its headquarters in Huntsville will occur within the next twelve months after December 31, 2024. The Company may need to further reduce capital expenditures and/or take other steps to preserve working capital in order to ensure that it can meet its needs and obligations and maintain compliance with its debt covenants.

- changed (2025-05-20):
[0000950170-25-075374:note_history:19]
In summary, the Company believes that its cash and cash equivalents, investments, working capital management initiatives and availability to access cash under the Wells Fargo credit facility will be adequate to meet our business operating requirements, our capital expenditures and our expected obligations under the DPLTA, including anticipated levels of Exit Compensation and to support our ability to continue to comply with our debt covenants under the Credit Facility and continue as a going concern, for at least the next twelve months, from the issuance of these financial statements. See Note 10, Revolving Credit Agreements, for additional information regarding the terms of the Wells Fargo Credit agreement.
  (was, 2024-11-12, similarity 0.9647):
[0000950170-24-125685:note_history:19]
In summary, the Company believes that its cash and cash equivalents, investments, working capital management initiatives and availability to access cash under the Wells Fargo credit facility will be adequate to meet our business operating requirements, our capital expenditures and our expected obligations under the DPLTA, including anticipated levels of Exit Compensation and to support our ability to continue to comply with our debt covenants under the Credit Facility, for at least the next twelve months, from the issuance of these financial statements. See Note 11, Revolving Credit Agreements, for additional information regarding the terms of the Amendments of the Wells Fargo Credit agreement.

- changed (2025-05-20):
[0000950170-25-075374:note_history:20]
In the opinion of management, all adjustments necessary to fairly state these interim statements have been recorded and are of a normal and recurring nature. The results of operations for an interim period are not necessarily indicative of the results for the full year. The interim financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in ADTRAN Holdings, Inc. Amendment No. 1 to the Annual Report on Form 10-K for the year ended December 31, 2024, filed with the SEC on May 20, 2025 (the "2024 Form 10-K/A").
  (was, 2024-11-12, similarity 0.9546):
[0000950170-24-125685:note_history:20]
In the opinion of management, all adjustments necessary to fairly state these interim statements have been recorded and are of a normal and recurring nature. The results of operations for an interim period are not necessarily indicative of the results for the full year. The interim financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in ADTRAN Holdings, Inc. Annual Report on Form 10-K for the year ended December 31, 2023, filed with the SEC on March 15, 2024.

- changed (2025-05-20):
[0000950170-25-075374:note_history:21]
Restatement of Previously Issued Financial Statements
  (was, 2024-11-12, similarity 0.7302):
[0000950170-24-125685:note_history:21]
Revision of Previously Issued Condensed Consolidated Financial Statements

- added (2025-05-20):
[0000950170-25-075374:note_history:22]
As discussed in the financial statements as of and for the year ended December 31, 2024 included in our amended 2024 Annual Report on Form 10-K/A, we identified errors in our previously issued financial statements. In addition, on May 13, 2025, the Company announced that it needed additional time to complete its quarterly reporting process as a result of the restatements to the annual periods ended December 31, 2023 and 2024 and for the interim periods ended March 31, 2024, June 30, 2024 and September 30, 2024, as well as to complete its evaluation of internal control over financial reporting as of December 31, 2024 as a result of errors related to the historical accounting for certain inventory and cost of goods sold transactions in its Adtran Networks SE subsidiary (the “Adjustment”). As a result, the Company filed a Form 12b-25 with the SEC and delayed the filing of this report.

- added (2025-05-20):
[0000950170-25-075374:note_history:23]
In connection with the identification of the Adjustment, the Audit Committee has overseen an internal investigation into the circumstances surrounding the Adjustment and its impact on the Company’s historical financial statements. Based on the findings of the internal investigation, which is substantially complete, it has been determined that the underlying errors giving rise to the Adjustment were not properly addressed in the Company’s previously filed financial statements as of and for the years ended December 31, 2024 and 2023 and was not communicated to the Audit Committee or the independent auditors prior to the filing of the initial 2024 Annual Report on Form 10-K. As described in Part I, Item 4 of this report, the Company is taking certain remedial actions to address the material weaknesses in its internal controls associated with these findings.

- added (2025-05-20):
[0000950170-25-075374:note_history:24]
The identified errors impacted the Condensed Consolidated Financial Statements as of and for the three months ended March 31, 2024, among other periods as previously disclosed. Below is a summary description of the significant errors in the Company's Condensed Consolidated Financial Statements as of and for the quarter ended March 31, 2024:

- changed (2025-05-20):
[0000950170-25-075374:note_history:25]
ADJ 1 - Pursuant to the terms of the DPLTA, each Adtran Networks shareholder (other than the Company) is entitled to receive from us an Annual Recurring Compensation payment of €0.52 per share. The Company erroneously accrued this liability every quarter at €0.59 per share, overstating the associated accrual, the net income attributable to non-controlling interest and the net loss attributable to ADTRAN Holdings, Inc. for fiscal periods beginning with the quarter ended March 31, 2023 through the quarter ended June 30, 2024.
  (was, 2024-11-12, similarity 0.9902):
[0000950170-24-125685:note_history:25]
(a)
Pursuant to the terms of the DPLTA, each Adtran Networks shareholder (other than the Company) is entitled to receive from us an Annual Recurring Compensation payment of €0.52 per share. The Company erroneously accrued this liability every quarter at €0.59 per share, overstating the associated accrual, the net income attributable to non-controlling interest and the net loss attributable to ADTRAN Holdings, Inc. for fiscal periods beginning with the quarter ended March 31, 2023 through the quarter ended June 30, 2024.

- changed (2025-05-20):
[0000950170-25-075374:note_history:26]
ADJ 2 - For the periods beginning with the quarter ended March 31, 2023 through the quarter ended June 30, 2024 the Company remeasured the redeemable non-controlling interest each quarter-end at the current exchange rate of euros to U.S. Dollar. The Company treated the redeemable non-controlling interest as a monetary mezzanine equity instrument but should have treated it as a non-monetary mezzanine equity instrument not subject to remeasurement.
  (was, 2024-11-12, similarity 0.9886):
[0000950170-24-125685:note_history:26]
(b)
For the periods beginning with the quarter ended March 31, 2023 through the quarter ended June 30, 2024 the Company remeasured the redeemable non-controlling interest each quarter-end at the current exchange rate of Euros to U.S. Dollar. The Company treated the redeemable non-controlling interest as a monetary mezzanine equity instrument but should have treated it as a non-monetary mezzanine equity instrument not subject to remeasurement.

- added (2025-05-20):
[0000950170-25-075374:note_history:27]
ADJ 3 - For the year ended December 31, 2023 through the year ended December 31, 2024, the Company understated cost of revenue and overstated inventory in the Company's Adtran Networks subsidiary due to a system error. In addition, there were adjustments in the Company's U.S and Australian subsidiaries related to inventory reserves that were understated.

- added (2025-05-20):
[0000950170-25-075374:note_history:28]
ADJ 4 - For the year ended December 31, 2023 through the year ended December 31, 2024, the Company understated goodwill and overstated income tax receivable. The understatement was attributable to corrections to goodwill and deferred income tax associated with goodwill for an internal divestiture of a wholly owned subsidiary required by statutory laws in Europe.

- added (2025-05-20):
[0000950170-25-075374:note_history:29]
In addition to the misstatements identified above, the Company has corrected other immaterial errors. These other errors are quantitatively and qualitatively immaterial, individually and in the aggregate. However, the Company has corrected these other errors as part of the correction for the significant errors described above.

- added (2025-05-20):
[0000950170-25-075374:note_history:30]
We assessed the materiality of the errors on prior period consolidated financial statements in accordance with SEC Staff Accounting Bulletin No. 99, “Materiality,” codified in ASC Topic 250, Accounting Changes and Error Corrections. Based on this assessment, we concluded that the errors, in the aggregate, are material to the March 31, 2024 financial statements and therefore, we are restating those financial statements herein. Furthermore, we made adjustments to correct for other previously identified immaterial errors. The

- added (2025-05-20):
[0000950170-25-075374:note_history:31]
Company has also restated impacted amounts within the accompanying footnotes to the Condensed Consolidated Financial Statements. See Note 18 for further information about the restatement.

- changed (2025-05-20):
[0000950170-25-075374:note_history:32]
We assessed certain accounting matters that generally require consideration of forecasted financial information in context with the information reasonably available to us and the unknown future impacts of ongoing inflationary pressures, continued elevated interest rates, currency fluctuations and political tensions as of March 31, 2025, and through the date of this report. These conditions could result in further impacts to the Company's consolidated financial statements in future reporting periods. The accounting matters assessed included, but were not limited to, the allowance for credit losses, stock-based compensation, carrying value of goodwill, intangibles and other long-lived assets, financial assets, valuation allowances for tax assets, revenue recognition and costs of revenue.
  (was, 2024-11-12, similarity 0.902):
[0000950170-24-125685:note_history:32]
We assessed certain accounting matters that generally require consideration of forecasted financial information in context with the information reasonably available to us and the unknown future impacts of ongoing inflationary pressures, continued elevated interest rates, instability in the financial services industry, currency fluctuations and political tensions as of September 30, 2024, and through the date of this report. These conditions could result in further impacts to the Company's consolidated financial statements in future reporting periods. The accounting matters assessed included, but were not limited to, the allowance for credit losses, stock-based compensation, carrying value of goodwill, intangibles and other long-lived assets, financial assets, valuation allowances for tax assets, revenue recognition and costs of revenue.

- added (2025-05-20):
[0000950170-25-075374:note_history:33]
Reclassification of Prior Year Presentation

- added (2025-05-20):
[0000950170-25-075374:note_history:34]
Certain prior year amounts have been reclassified for consistency with current year presentation. These reclassifications had no effect on reported results of operations. An adjustment has been made to the Consolidated Statement of Cash Flows for the quarter ended March 31, 2024, to reclassify between Property, Plant and Equipment and Intangible Assets.

- removed (2025-05-20):
[0000950170-24-125685:note_history:35]
On October 18, 2022, the Company's Board of Directors authorized the Company to purchase additional shares of Adtran Networks through open market purchases not to exceed 15,346,544 shares. For the three and nine months ended September 30, 2024, approximately 830 thousand shares and 831 thousand shares, respectively, of Adtran Networks stock were tendered to the Company. This resulted in total Exit Compensation payments of approximately €15.7 million, or approximately $17.4 million, based on an exchange rate as of September 30, 2024, being paid to Adtran Networks shareholders. For the three and nine months ended September 30, 2023, less than 1 thousand shares and 64 thousand shares, respectively, of Adtran Networks stock were tendered to the Company. This resulted in Exit Compensation payments of approximately €8 thousand and €1.1 million, respectively, or approximately $9 thousand and $1.2 million, respectively, based on an exchange rate as of September 30, 2023, being paid to Adtran Networks shareholders.

- removed (2025-05-20):
[0000950170-24-125685:note_history:36]
As of September 30, 2024, and as of the date of issuance of these financial statements, the Company does not have sufficient liquidity to meet payment obligations under the DPLTA pertaining to Exit Compensation. While the Company did experience $17.4 million of redemptions in Q3 2024, we believe the probability that more than a small minority of Adtran Networks shareholders elect to receive Exit Compensation in the next twelve months is remote based on the following factors: (i) the diverse base of shareholders that must make this election on an individual shareholder basis, (ii) the fact that the Company expects to receive a procedural decision on a matter of law related to the current ongoing appraisal proceedings involving a dispute over the value of the Exit Compensation in 2024 or early 2025, after which the appeal process should take an additional 24-32 months to resolve, (iii) the current guaranteed Annual Recurring Compensation payment plus the interest earned on such shares during the ongoing appraisal proceedings, and (iv) the current trading value of Adtran Networks shares.

- removed (2025-05-20):
[0000950170-24-125685:note_history:37]
The Company experienced revenue declines in the year ended December 31, 2023, and during the three and nine months ended September 30, 2024. To the extent the Company does not experience anticipated revenue growth, the Company will implement plans to preserve cash liquidity and maintain compliance with the Company’s net leverage covenants. The Company has suspended dividend payments and has implemented a business efficiency program, which includes, but is not limited to ongoing reductions in operating expenses and a site consolidation plan. In connection with the site consolidation plan, the Company is also exploring a potential sale of portions of our headquarters in Huntsville. There can be no assurance that the Company will be successful in effecting this action on commercially reasonable terms or at all. We may need to further reduce capital expenditure and/or take other steps to preserve working capital in order to ensure that we can meet our needs and obligations and maintain compliance with our net leverage debt covenants.

- removed (2025-05-20):
[0000950170-24-125685:note_history:38]
Following the third quarter of 2024, the Company identified errors primarily impacting the carrying values of the redeemable non-controlling interest, retained deficit, the net income attributable to the non-controlling interest and the net loss attributable to the Company and, as a consequence, of the loss per common share attributable to the Company. The Company has evaluated the errors and determined that the related impacts were not material to the previously issued consolidated financial statements for any prior period. A summary of the corrections to the Company's Condensed Consolidated Financial Statements for the periods ended March 31, 2023, June 30, 2023, September 30, 2023, December 31, 2023, March 31, 2024 and June 30, 2024, are as follows:

- removed (2025-05-20):
[0000950170-24-125685:note_history:39]
We have revised our previously issued Condensed Consolidated Financial Statements for the periods ended March 31, 2023, June 30, 2023, September 30, 2023, December 31, 2023, March 31, 2024 and June 30, 2024. Additionally, the Company will revise its previously issued 2023 interim financial statements and 2023 annual financial statements in connection with the future filings of the Form 10-K for the year ended December 31, 2024, and interim reporting on Form 10-Q for the periods ended March 31, 2025 and June 30, 2025.

- removed (2025-05-20):
[0000950170-24-125685:note_history:40]
The following tables reflect the impact of the revision to the specific line items presented in the Company's previously reported Condensed Consolidated Balance Sheets, Condensed Consolidated Statements of Loss, and Condensed Consolidated Statements of Comprehensive Loss for the for fiscal periods beginning with the quarter ended March 31, 2023 through the quarter ended June 30, 2024.

- removed (2025-05-20):
[0000950170-24-125685:note_history:41]
|  |  |  | March 31, 2023 |  |
| (In thousands) |  |  | As Previously Reported |  |  | Revision |  |  | As Revised |  |
| Other non-current liabilities |  |  | $ | 15,986 |  |  | $ | (346 | ) | (a) | $ | 15,640 |  |
| Total Liabilities |  |  | $ | 675,765 |  |  | $ | (346 | ) |  | $ | 675,419 |  |
| Redeemable Non-Controlling Interest |  |  | $ | 442,668 |  |  | $ | (430 | ) | (b) | $ | 442,238 |  |
| Accumulated Other Comprehensive Income |  |  | $ | 34,526 |  |  | $ | 1 |  | (a) | $ | 34,527 |  |
| Retained Earnings |  |  | $ | 8,006 |  |  | $ | 775 |  | (a)(b) | $ | 8,781 |  |
| Total Equity |  |  | $ | 820,162 |  |  | $ | 776 |  |  | $ | 820,938 |  |
| Total Liabilities, Redeemable Non-Controlling Interest and Equity |  |  | $ | 1,938,595 |  |  | $ | — |  |  | $ | 1,938,595 |  |

- removed (2025-05-20):
[0000950170-24-125685:note_history:42]
|  |  |  | For the Three Months Ended March 31, 2023 |  |
| (In thousands) |  |  | As Previously Reported |  |  | Revision |  |  | As Revised |  |
| Less: Net Loss attributable to non-controlling interest |  |  | $ | (370 | ) |  | $ | (345 | ) | (a) | $ | (715 | ) |
| Net Loss attributable to ADTRAN Holdings, Inc. |  |  | $ | (40,083 | ) |  | $ | 345 |  | (a) | $ | (39,738 | ) |
| Loss per common share attributable to ADTRAN Holdings, Inc. – basic |  |  | $ | (0.51 | ) |  | $ | — |  |  | $ | (0.51 | ) |
| Loss per common share attributable to ADTRAN Holdings, Inc. – diluted |  |  | $ | (0.51 | ) |  | $ | — |  |  | $ | (0.51 | ) |
| Foreign currency translation gain |  |  | $ | 8,678 |  |  | $ | 1 |  | (a) | $ | 8,679 |  |
| Other Comprehensive Income, net of tax |  |  | $ | 8,782 |  |  | $ | 1 |  |  | $ | 8,783 |  |
| Comprehensive Loss, net of tax |  |  | $ | (31,671 | ) |  | $ | 1 |  |  | $ | (31,670 | ) |
| Less: Comprehensive Income (Loss) attributable to non-controlling interest, net of tax |  |  | $ | 12 |  |  | $ | (345 | ) | (a) | $ | (333 | ) |
| Comprehensive Loss attributable to ADTRAN Holdings, Inc., net of tax |  |  | $ | (31,683 | ) |  | $ | 346 |  | (a) | $ | (31,337 | ) |

- removed (2025-05-20):
[0000950170-24-125685:note_history:43]
|  |  |  | June 30, 2023 |  |
| (In thousands) |  |  | As Previously Reported |  |  | Revision |  |  | As Revised |  |
| Other non-current liabilities |  |  | $ | 16,401 |  |  | $ | (695 | ) | (a) | $ | 15,706 |  |
| Total Liabilities |  |  | $ | 665,006 |  |  | $ | (695 | ) |  | $ | 664,311 |  |
| Redeemable Non-Controlling Interest |  |  | $ | 445,462 |  |  | $ | (3,244 | ) | (b) | $ | 442,218 |  |
| Accumulated Other Comprehensive Income |  |  | $ | 41,483 |  |  | $ | 2 |  | (a) | $ | 41,485 |  |
| Retained Deficit |  |  | $ | (41,010 | ) |  | $ | 3,937 |  | (a)(b) | $ | (37,073 | ) |
| Total Equity |  |  | $ | 782,470 |  |  | $ | 3,939 |  |  | $ | 786,409 |  |
| Total Liabilities, Redeemable Non-Controlling Interest and Equity |  |  | $ | 1,882,938 |  |  | $ | — |  |  | $ | 1,882,938 |  |

- removed (2025-05-20):
[0000950170-24-125685:note_history:44]
|  |  |  | For the Three Months Ended June 30, 2023 |  |  | For the Six Months Ended June 30, 2023 |  |
| (In thousands) |  |  | As Previously Reported |  |  | Revision |  |  | As Revised |  |  | As Previously Reported |  |  | Revision |  |  | As Revised |  |
| Less: Net Income attributable to non-controlling interest |  |  | $ | 2,882 |  |  | $ | (348 | ) | (a) | $ | 2,534 |  |  | $ | 2,512 |  |  | $ | (693 | ) | (a) | $ | 1,819 |  |
| Net Loss attributable to ADTRAN Holdings, Inc. |  |  | $ | (39,097 | ) |  | $ | 348 |  | (a) | $ | (38,749 | ) |  | $ | (79,180 | ) |  | $ | 693 |  | (a) | $ | (78,487 | ) |
| Loss per common share attributable to ADTRAN Holdings, Inc. – basic |  |  | $ | (0.50 | ) |  | $ | — |  |  | $ | (0.50 | ) |  | $ | (1.01 | ) |  | $ | 0.01 |  | (a) | $ | (1.00 | ) |
| Loss per common share attributable to ADTRAN Holdings, Inc. – diluted |  |  | $ | (0.50 | ) |  | $ | — |  |  | $ | (0.50 | ) |  | $ | (1.01 | ) |  | $ | 0.01 |  | (a) | $ | (1.00 | ) |
| Foreign currency translation gain |  |  | $ | 6,940 |  |  | $ | 1 |  | (a) | $ | 6,941 |  |  | $ | 15,618 |  |  | $ | 2 |  | (a) | $ | 15,620 |  |
| Other Comprehensive Income, net of tax |  |  | $ | 6,957 |  |  | $ | 1 |  |  | $ | 6,958 |  |  | $ | 15,739 |  |  | $ | 2 |  |  | $ | 15,741 |  |
| Comprehensive Loss, net of tax |  |  | $ | (29,258 | ) |  | $ | 1 |  |  | $ | (29,257 | ) |  | $ | (60,929 | ) |  | $ | 2 |  |  | $ | (60,927 | ) |
| Less: Comprehensive Income attributable to non-controlling interest, net of tax |  |  | $ | 2,882 |  |  | $ | (348 | ) | (a) | $ | 2,534 |  |  | $ | 2,894 |  |  | $ | (693 | ) | (a) | $ | 2,201 |  |
| Comprehensive Loss attributable to ADTRAN Holdings, Inc., net of tax |  |  | $ | (32,140 | ) |  | $ | 349 |  | (a) | $ | (31,791 | ) |  | $ | (63,823 | ) |  | $ | 695 |  | (a) | $ | (63,128 | ) |

- removed (2025-05-20):
[0000950170-24-125685:note_history:45]
|  |  |  | September 30, 2023 |  |
| (In thousands) |  |  | As Previously Reported |  |  | Revision |  |  | As Revised |  |
| Other non-current liabilities |  |  | $ | 17,408 |  |  | $ | (1,049 | ) | (a) | $ | 16,359 |  |
| Total Liabilities |  |  | $ | 625,355 |  |  | $ | (1,049 | ) |  | $ | 624,306 |  |
| Redeemable Non-Controlling Interest |  |  | $ | 431,921 |  |  | $ | 10,291 |  | (b) | $ | 442,212 |  |
| Accumulated Other Comprehensive Income |  |  | $ | 12,075 |  |  | $ | 3 |  | (a) | $ | 12,078 |  |
| Retained Deficit |  |  | $ | (113,289 | ) |  | $ | (9,245 | ) | (a)(b) | $ | (122,534 | ) |
| Total Equity |  |  | $ | 684,893 |  |  | $ | (9,242 | ) |  | $ | 675,651 |  |
| Total Liabilities, Redeemable Non-Controlling Interest and Equity |  |  | $ | 1,742,169 |  |  | $ | — |  |  | $ | 1,742,169 |  |

- removed (2025-05-20):
[0000950170-24-125685:note_history:46]
|  |  |  | For the Three Months Ended September 30, 2023 |  |  | For the Nine Months Ended September 30, 2023 |  |
| (In thousands) |  |  | As Previously Reported |  |  | Revision |  |  | As Revised |  |  | As Previously Reported |  |  | Revision |  |  | As Revised |  |
| Less: Net Income attributable to non-controlling interest |  |  | $ | 2,914 |  |  | $ | (353 | ) | (a) | $ | 2,561 |  |  | $ | 5,426 |  |  | $ | (1,046 | ) | (a) | $ | 4,380 |  |
| Net Loss attributable to ADTRAN Holdings, Inc. |  |  | $ | (78,563 | ) |  | $ | 353 |  | (a) | $ | (78,210 | ) |  | $ | (157,743 | ) |  | $ | 1,046 |  | (a) | $ | (156,697 | ) |
| Loss per common share attributable to ADTRAN Holdings, Inc. – basic |  |  | $ | (1.00 | ) |  | $ | — |  |  | $ | (1.00 | ) |  | $ | (2.01 | ) |  | $ | 0.01 |  | (a) | $ | (2.00 | ) |
| Loss per common share attributable to ADTRAN Holdings, Inc. – diluted |  |  | $ | (1.00 | ) |  | $ | — |  |  | $ | (1.00 | ) |  | $ | (2.01 | ) |  | $ | 0.01 |  | (a) | $ | (2.00 | ) |
| Foreign currency translation loss |  |  | $ | (29,716 | ) |  | $ | 1 |  | (a) | $ | (29,715 | ) |  | $ | (14,098 | ) |  | $ | 3 |  | (a) | $ | (14,095 | ) |
| Other Comprehensive Loss, net of tax |  |  | $ | (29,408 | ) |  | $ | 1 |  |  | $ | (29,407 | ) |  | $ | (13,669 | ) |  | $ | 3 |  |  | $ | (13,666 | ) |
| Comprehensive Loss, net of tax |  |  | $ | (105,057 | ) |  | $ | 1 |  |  | $ | (105,056 | ) |  | $ | (165,986 | ) |  | $ | 3 |  |  | $ | (165,983 | ) |
| Less: Comprehensive Income attributable to non-controlling interest, net of tax |  |  | $ | 2,914 |  |  | $ | (353 | ) | (a) | $ | 2,561 |  |  | $ | 5,808 |  |  | $ | (1,046 | ) | (a) | $ | 4,762 |  |
| Comprehensive Loss attributable to ADTRAN Holdings, Inc., net of tax |  |  | $ | (107,971 | ) |  | $ | 354 |  | (a) | $ | (107,617 | ) |  | $ | (171,794 | ) |  | $ | 1,049 |  | (a) | $ | (170,745 | ) |

- removed (2025-05-20):
[0000950170-24-125685:note_history:47]
|  |  |  | March 31, 2024 |  |
| (In thousands) |  |  | As Previously Reported |  |  | Revision |  |  | As Revised |  |
| Accrued Expenses and Other Liabilities |  |  | $ | 36,404 |  |  | $ | (1,403 | ) | (a) | $ | 35,001 |  |
| Total Current Liabilities |  |  | $ | 282,746 |  |  | $ | (1,403 | ) |  | $ | 281,343 |  |
| Other non-current liabilities |  |  | $ | 35,375 |  |  | $ | (350 | ) | (a) | $ | 35,025 |  |
| Total Liabilities |  |  | $ | 620,488 |  |  | $ | (1,753 | ) |  | $ | 618,735 |  |
| Redeemable Non-Controlling Interest |  |  | $ | 441,635 |  |  | $ | 511 |  | (b) | $ | 442,146 |  |
| Accumulated Other Comprehensive Income |  |  | $ | 29,656 |  |  | $ | 5 |  | (a) | $ | 29,661 |  |
| Retained Deficit |  |  | $ | (558,363 | ) |  | $ | 1,237 |  | (a)(b) | $ | (557,126 | ) |
| Total Equity |  |  | $ | 265,783 |  |  | $ | 1,242 |  |  | $ | 267,025 |  |
| Total Liabilities, Redeemable Non-Controlling Interest and Equity |  |  | $ | 1,327,906 |  |  | $ | — |  |  | $ | 1,327,906 |  |

- removed (2025-05-20):
[0000950170-24-125685:note_history:48]
|  |  |  | For the Three Months Ended March 31, 2024 |  |
| (In thousands) |  |  | As Previously Reported |  |  | Revision |  |  | As Revised |  |
| Less: Net Income attributable to non-controlling interest |  |  | $ | 2,880 |  |  | $ | (349 | ) | (a) | $ | 2,531 |  |
| Net Loss attributable to ADTRAN Holdings, Inc. |  |  | $ | (324,550 | ) |  | $ | 349 |  | (a) | $ | (324,201 | ) |
| Loss per common share attributable to ADTRAN Holdings, Inc. – basic |  |  | $ | (4.12 | ) |  | $ | — |  |  | $ | (4.12 | ) |
| Loss per common share attributable to ADTRAN Holdings, Inc. – diluted |  |  | $ | (4.12 | ) |  | $ | — |  |  | $ | (4.12 | ) |
| Foreign currency translation loss |  |  | $ | (17,745 | ) |  | $ | 1 |  | (a) | $ | (17,744 | ) |
| Other Comprehensive Loss, net of tax |  |  | $ | (17,805 | ) |  | $ | 1 |  |  | $ | (17,804 | ) |
| Comprehensive Loss, net of tax |  |  | $ | (339,475 | ) |  | $ | 1 |  |  | $ | (339,474 | ) |
| Less: Comprehensive Income attributable to non-controlling interest, net of tax |  |  | $ | 2,880 |  |  | $ | (349 | ) | (a) | $ | 2,531 |  |
| Comprehensive Loss attributable to ADTRAN Holdings, Inc., net of tax |  |  | $ | (342,355 | ) |  | $ | 350 |  | (a) | $ | (342,005 | ) |

- removed (2025-05-20):
[0000950170-24-125685:note_history:49]
|  |  |  | June 30, 2024 |  |
| (In thousands) |  |  | As Previously Reported |  |  | Revision |  |  | As Revised |  |
| Accrued Expenses and Other Liabilities |  |  | $ | 36,307 |  |  | $ | (1,403 | ) | (a) | $ | 34,904 |  |
| Total Current Liabilities |  |  | $ | 289,712 |  |  | $ | (1,403 | ) |  | $ | 288,309 |  |
| Other non-current liabilities |  |  | $ | 34,445 |  |  | $ | (701 | ) | (a) | $ | 33,744 |  |
| Total Liabilities |  |  | $ | 630,810 |  |  | $ | (2,104 | ) |  | $ | 628,706 |  |
| Redeemable Non-Controlling Interest |  |  | $ | 439,743 |  |  | $ | 2,379 |  | (b) | $ | 442,122 |  |
| Accumulated Other Comprehensive Income |  |  | $ | 28,274 |  |  | $ | 6 |  | (a) | $ | 28,280 |  |
| Retained Deficit |  |  | $ | (606,375 | ) |  | $ | (281 | ) | (a)(b) | $ | (606,656 | ) |
| Total Equity |  |  | $ | 220,229 |  |  | $ | (275 | ) |  | $ | 219,954 |  |
| Total Liabilities, Redeemable Non-Controlling Interest and Equity |  |  | $ | 1,290,782 |  |  | $ | — |  |  | $ | 1,290,782 |  |

- removed (2025-05-20):
[0000950170-24-125685:note_history:50]
|  |  |  | For the Three Months Ended June 30, 2024 |  |  | For the Six Months Ended June 30, 2024 |  |
| (In thousands) |  |  | As Previously Reported |  |  | Revision |  |  | As Revised |  |  | As Previously Reported |  |  | Revision |  |  | As Revised |  |
| Less: Net Income attributable to non-controlling interest |  |  | $ | 2,854 |  |  | $ | (350 | ) | (a) | $ | 2,504 |  |  | $ | 5,734 |  |  | $ | (699 | ) | (a) | $ | 5,035 |  |
| Net Loss attributable to ADTRAN Holdings, Inc. |  |  | $ | (49,865 | ) |  | $ | 350 |  | (a) | $ | (49,515 | ) |  | $ | (374,415 | ) |  | $ | 699 |  | (a) | $ | (373,716 | ) |
| Loss per common share attributable to ADTRAN Holdings, Inc. – basic |  |  | $ | (0.63 | ) |  | $ | — |  |  | $ | (0.63 | ) |  | $ | (4.75 | ) |  | $ | 0.01 |  | (a) | $ | (4.74 | ) |
| Loss per common share attributable to ADTRAN Holdings, Inc. – diluted |  |  | $ | (0.63 | ) |  | $ | — |  |  | $ | (0.63 | ) |  | $ | (4.75 | ) |  | $ | 0.01 |  | (a) | $ | (4.74 | ) |
| Foreign currency translation loss |  |  | $ | (1,375 | ) |  | $ | 1 |  | (a) | $ | (1,374 | ) |  | $ | (19,120 | ) |  | $ | 2 |  | (a) | $ | (19,118 | ) |
| Other Comprehensive Loss, net of tax |  |  | $ | (1,382 | ) |  | $ | 1 |  |  | $ | (1,381 | ) |  | $ | (19,187 | ) |  | $ | 2 |  |  | $ | (19,185 | ) |
| Comprehensive Loss, net of tax |  |  | $ | (48,393 | ) |  | $ | 1 |  |  | $ | (48,392 | ) |  | $ | (387,868 | ) |  | $ | 2 |  |  | $ | (387,866 | ) |
| Less: Comprehensive Income attributable to non-controlling interest, net of tax |  |  | $ | 2,854 |  |  | $ | (350 | ) | (a) | $ | 2,504 |  |  | $ | 5,734 |  |  | $ | (699 | ) | (a) | $ | 5,035 |  |
| Comprehensive Loss attributable to ADTRAN Holdings, Inc., net of tax |  |  | $ | (51,247 | ) |  | $ | 351 |  | (a) | $ | (50,896 | ) |  | $ | (393,602 | ) |  | $ | 701 |  | (a) | $ | (392,901 | ) |

- removed (2025-05-20):
[0000950170-24-125685:note_history:51]
The following tables reflect the impact of the revisions to the specific line items presented in the Company’s previously reported Consolidated Balance Sheet as of December 31, 2023, the Consolidated Statement of Loss and the Consolidated Statement of Comprehensive Loss for the year ended December 31, 2023.

- removed (2025-05-20):
[0000950170-24-125685:note_history:52]
|  |  |  | December 31, 2023 |  |
| (In thousands) |  |  | As Previously Reported |  |  | Revision |  |  | As Revised |  |
| Accrued Expenses and Other Liabilities |  |  | $ | 37,607 |  |  | $ | (1,403 | ) | (a) | $ | 36,204 |  |
| Total Current Liabilities |  |  | $ | 279,511 |  |  | $ | (1,403 | ) |  | $ | 278,108 |  |
| Total Liabilities |  |  | $ | 636,934 |  |  | $ | (1,403 | ) |  | $ | 635,531 |  |
| Redeemable Non-Controlling Interest |  |  | $ | 451,756 |  |  | $ | (9,604 | ) | (b) | $ | 442,152 |  |
| Accumulated Other Comprehensive Income |  |  | $ | 47,461 |  |  | $ | 4 |  | (a) | $ | 47,465 |  |
| Retained Deficit |  |  | $ | (243,908 | ) |  | $ | 11,003 |  | (a)(b) | $ | (232,905 | ) |
| Total Equity |  |  | $ | 593,822 |  |  | $ | 11,007 |  |  | $ | 604,829 |  |
| Total Liabilities, Redeemable Non-Controlling Interest and Equity |  |  | $ | 1,682,512 |  |  | $ | — |  |  | $ | 1,682,512 |  |

- removed (2025-05-20):
[0000950170-24-125685:note_history:53]
|  |  |  | For the Year Ended December 31, 2023 |  |
| (In thousands) |  |  | As Previously Reported |  |  | Revision |  |  | As Revised |  |
| Less: Net Income attributable to non-controlling interest |  |  | $ | 8,345 |  |  | $ | (1,399 | ) | (a) | $ | 6,946 |  |
| Net Loss attributable to ADTRAN Holdings, Inc. |  |  | $ | (267,688 | ) |  | $ | 1,399 |  | (a) | $ | (266,289 | ) |
| Loss per common share attributable to ADTRAN Holdings, Inc. – basic |  |  | $ | (3.41 | ) |  | $ | 0.02 |  | (a) | $ | (3.39 | ) |
| Loss per common share attributable to ADTRAN Holdings, Inc. – diluted |  |  | $ | (3.41 | ) |  | $ | 0.02 |  | (a) | $ | (3.39 | ) |
| Foreign currency translation gain |  |  | $ | 22,753 |  |  | $ | 4 |  | (a) | $ | 22,757 |  |
| Other Comprehensive Income, net of tax |  |  | $ | 21,717 |  |  | $ | 4 |  |  | $ | 21,721 |  |
| Comprehensive Loss, net of tax |  |  | $ | (237,626 | ) |  | $ | 4 |  |  | $ | (237,622 | ) |
| Less: Comprehensive Income attributable to non-controlling interest, net of tax |  |  | $ | 8,727 |  |  | $ | (1,399 | ) | (a) | $ | 7,328 |  |
| Comprehensive Loss attributable to ADTRAN Holdings, Inc., net of tax |  |  | $ | (246,353 | ) |  | $ | 1,403 |  | (a) | $ | (244,950 | ) |

- removed (2025-05-20):
[0000950170-24-125685:note_history:54]
The following tables reflect the impact of the revision to the specific line items presented in the Company's previously reported Condensed Consolidated Statements of Changes in Stockholders Equity as of September 30, 2023 and 2024:

- removed (2025-05-20):
[0000950170-24-125685:note_history:55]
|  |  |  | Retained Earnings (Deficit) |  |  | Accumulated Other Comprehensive Income |  |
| (In thousands) |  |  | As Previously Reported |  |  | Revision |  |  | As Revised |  |  | As Previously Reported |  |  | Revision |  |  | As Revised |  |
| Annual recurring compensation earned |  |  | $ | (2,809 | ) |  | $ | 345 |  | (a) | $ | (2,464 | ) |  | $ | - |  |  | $ | - |  |  | $ | - |  |
| Other comprehensive income, net of tax |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | 8,400 |  |  | $ | 1 |  | (a) | $ | 8,401 |  |
| Foreign currency remeasurement of redeemable non-controlling interest |  |  | $ | (430 | ) |  | $ | 430 |  | (b) | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |
| Balance as of March 31, 2023 |  |  | $ | 8,006 |  |  | $ | 775 |  |  | $ | 8,781 |  |  | $ | 34,526 |  |  | $ | 1 |  |  | $ | 34,527 |  |
| Annual recurring compensation earned |  |  | $ | (2,882 | ) |  | $ | 348 |  | (a) | $ | (2,534 | ) |  | $ | - |  |  | $ | - |  |  | $ | - |  |
| Other comprehensive income, net of tax |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | 6,957 |  |  | $ | 1 |  | (a) | $ | 6,958 |  |
| Foreign currency remeasurement of redeemable non-controlling interest |  |  | $ | (2,814 | ) |  | $ | 2,814 |  | (b) | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |
| Balance as of June 30, 2023 |  |  | $ | (41,010 | ) |  | $ | 3,937 |  |  | $ | (37,073 | ) |  | $ | 41,483 |  |  | $ | 2 |  |  | $ | 41,485 |  |
| Annual recurring compensation earned |  |  | $ | (2,914 | ) |  | $ | 353 |  | (a) | $ | (2,561 | ) |  | $ | - |  |  | $ | - |  |  | $ | - |  |
| Other comprehensive loss, net of tax |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | (29,408 | ) |  | $ | 1 |  | (a) | $ | (29,407 | ) |
| Foreign currency remeasurement of redeemable non-controlling interest |  |  | $ | 13,535 |  |  | $ | (13,535 | ) | (b) | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |
| Balance as of September 30, 2023 |  |  | $ | (113,289 | ) |  | $ | (9,245 | ) |  | $ | (122,534 | ) |  | $ | 12,075 |  |  | $ | 3 |  |  | $ | 12,078 |  |

- removed (2025-05-20):
[0000950170-24-125685:note_history:56]
|  |  |  | Retained Deficit |  |  | Accumulated Other Comprehensive Income |  |
| (In thousands) |  |  | As Previously Reported |  |  | Revision |  |  | As Revised |  |  | As Previously Reported |  |  | Revision |  |  | As Revised |  |
| Balance as of December 31, 2023 |  |  | $ | (243,908 | ) |  | $ | 11,003 |  | (a) | $ | (232,905 | ) |  | $ | 47,461 |  |  | $ | 4 |  | (a) | $ | 47,465 |  |
| Annual recurring compensation earned |  |  | $ | (2,880 | ) |  | $ | 349 |  | (a) | $ | (2,531 | ) |  | $ | - |  |  | $ | - |  |  | $ | - |  |
| Other comprehensive loss, net of tax |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | (17,805 | ) |  | $ | 1 |  | (a) | $ | (17,804 | ) |
| Foreign currency remeasurement of redeemable non-controlling interest |  |  | $ | 10,115 |  |  | $ | (10,115 | ) | (b) | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |
| Balance as of March 31, 2024 |  |  | $ | (558,363 | ) |  | $ | 1,237 |  |  | $ | (557,126 | ) |  | $ | 29,656 |  |  | $ | 5 |  |  | $ | 29,661 |  |
| Annual recurring compensation earned |  |  | $ | (2,854 | ) |  | $ | 350 |  | (a) | $ | (2,504 | ) |  | $ | - |  |  |  |  |  | $ | - |  |
| Other comprehensive loss, net of tax |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | (1,382 | ) |  | $ | 1 |  | (a) | $ | (1,381 | ) |
| Foreign currency remeasurement of redeemable non-controlling interest |  |  | $ | 1,868 |  |  | $ | (1,868 | ) | (b) | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |
| Balance as of June 30, 2024 |  |  | $ | (606,375 | ) |  | $ | (281 | ) |  | $ | (606,656 | ) |  | $ | 28,274 |  |  | $ | 6 |  |  | $ | 28,280 |  |

- removed (2025-05-20):
[0000950170-24-125685:note_history:57]
The following tables reflect the impact of the revision to the specific line items presented in the Company's previously reported Consolidated Statement of Changes in Stockholders as of December 31, 2023:

- removed (2025-05-20):
[0000950170-24-125685:note_history:58]
|  |  |  | Retained Earnings (Deficit) |  |  | Accumulated Other Comprehensive Income |  |
| (In thousands) |  |  | As Previously Reported |  |  | Revision |  |  | As Revised |  |  | As Previously Reported |  |  | Revision |  |  | As Revised |  |
| Annual recurring compensation earned |  |  | $ | (11,524 | ) |  | $ | 1,399 |  | (a) | $ | (10,125 | ) |  | $ | - |  |  | $ | - |  |  | $ | - |  |
| Other comprehensive income, net of tax |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | 21,335 |  |  | $ | 4 |  | (a) | $ | 21,339 |  |
| Foreign currency remeasurement of redeemable non-controlling interest |  |  | $ | (9,604 | ) |  | $ | 9,604 |  | (b) | $ | - |  |  | $ | - |  |  | $ | - |  |  | $ | - |  |
| Balance as of December 31, 2023 |  |  | $ | (243,908 | ) |  | $ | 11,003 |  |  | $ | (232,905 | ) |  | $ | 47,461 |  |  | $ | 4 |  |  | $ | 47,465 |  |

- removed (2025-05-20):
[0000950170-24-125685:note_history:59]
Accounts Receivable Factoring

- removed (2025-05-20):
[0000950170-24-125685:note_history:60]
Receivables Purchase Agreement

- removed (2025-05-20):
[0000950170-24-125685:note_history:61]
On July 1, 2024, the Company entered into a receivables purchase agreement (the “Factoring Agreement”) with a third-party financial institution (the “Factor”), which accelerates receivable collection and helps to better manage cash flow. These transactions are accounted for in accordance with ASC Topic 860 and result in a reduction in accounts receivable because the Factoring Agreement transfers effective control over, and risk related to the receivables to the buyers. Trade accounts receivables balances sold are removed from the Condensed Consolidated Balance Sheets and cash received is reflected as cash flows provided by (used in) operating activities in the Condensed Consolidated Statements of Cash Flow. Factoring related interest expense is recorded to interest expense on the Condensed Consolidated Statements of Loss. On each sale date, the Factor retains from the sale price a default reserve, up to a required balance, which is held by the Factor in a reserve account and pledged to the Company. The Factor is entitled to withdraw from the reserve account the sale price of a defaulted receivable. The balance in the reserve account is included in other assets on the Condensed Consolidated Balance Sheets.

- removed (2025-05-20):
[0000950170-24-125685:note_history:62]
Previous Receivables Purchase Agreement

- removed (2025-05-20):
[0000950170-24-125685:note_history:63]
On December 19, 2023, the Company entered into a receivables purchase agreement (the “Prior Factoring Agreement”) with a third-party financial institution and was terminated on July 1, 2024. The Prior Factoring Agreement qualified for treatment as a secured borrowing with a pledge of collateral under Accounting Standards Codification ("ASC") Topic 810, Consolidations, as the Company was considered the primary beneficiary in a variable interest entity created to hold the factored receivables and the Company retained a residual claim on reserves related to the factored receivables. Within the Condensed Consolidated Balance Sheets, the receivables factored were carried in accounts receivable, less allowance for credit losses, and the secured borrowings were carried as a current liability within accounts payable. The proceeds and repayments of secured borrowings were reflected as cash flows (used in) provided by financing activities within the Condensed Consolidated Statements of Cash Flows, and program fees were recorded as interest expense in the Consolidated Statements of Loss. The short-term liability classification of the secured borrowings was based on the estimated timing of the collection of the accounts receivable which were expected to be received within 12 months. See Note 2 for additional information.

- removed (2025-05-20):
[0000950170-24-125685:note_history:64]
Redeemable Non-Controlling Interest

- removed (2025-05-20):
[0000950170-24-125685:note_history:65]
As of September 30, 2024 and December 31, 2023, the non-controlling Adtran Networks stockholders’ equity ownership percentage in Adtran Networks was approximately 33.0% and 34.6%, respectively.

- removed (2025-05-20):
[0000950170-24-125685:note_history:66]
As a result of the effectiveness of the DPLTA on January 16, 2023, the Adtran Networks shares, representing the equity interest in Adtran Networks held by holders other than the Company, can be tendered at any time and are, therefore, redeemable and must be classified outside stockholders’ equity. Therefore, the permanent equity noncontrolling interest balance was reclassified to redeemable non-controlling interest on January 16, 2023, and was remeasured to fair value based on the trading market price of the Adtran Networks shares.

- removed (2025-05-20):
[0000950170-24-125685:note_history:67]
Subsequently, the carrying value of the RNCI is adjusted to its maximum redemption value at each reporting date when the maximum redemption value is greater than the initial carrying amount of the RNCI. For the period of time that the DPLTA is in effect, the RNCI will continue to be presented as RNCI outside of stockholders’ equity in the Condensed Consolidated Balance Sheets. See Note 14 for additional information on RNCI.

- removed (2025-05-20):
[0000950170-24-125685:note_history:68]
In November 2023, the FASB issued ASU 2023-7, "Segment Reporting (Topic 280): Improvements to Reportable Segment Disclosures", which is intended to improve reportable segment disclosure requirements, primarily through enhanced disclosures about significant segment expenses, allowing financial statement users to better understand the components of a segment's profit or loss to assess potential future cash flows for each reportable segment and the entity as a whole. The amendments expand a public entity's segment disclosures by requiring disclosure of significant segment expenses that are regularly provided to the chief operating decision maker ("CODM"), clarifying when an entity may report one or more additional measures to assess segment performance, requiring enhanced interim disclosures, providing new disclosure requirements for entities with a single reportable segment, and requiring other new disclosures. The amendments are effective for fiscal years beginning after December 15, 2023, and interim periods within fiscal years beginning after December 15, 2024, and early adoption is permitted. The Company expects to adopt the new disclosures as required for the year ended December 31, 2024. The Company is currently evaluating the impact on the related disclosures.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-05-20):
[0000950170-25-075374:note_history:69]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | March 31, 2025 |  |  | December 31, 2024 |  |
| Wells Fargo credit agreement |  | $ | 190,085 |  |  | $ | 189,576 |  |
| Total non-current revolving credit facility |  | $ | 190,085 |  |  | $ | 189,576 |  |
  (was, 2024-11-12, similarity 0.9009):
[0000950170-24-125685:note_history:69]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | September 30, 2024 |  |  | December 31, 2023 |  |
| Wells Fargo credit agreement |  | $ | 189,849 |  |  | $ | 195,000 |  |
| Total non-current revolving credit facility |  | $ | 189,849 |  |  | $ | 195,000 |  |

- changed (2025-05-20):
[0000950170-25-075374:note_history:70]
Wells Fargo Credit Facility
  (was, 2024-11-12, similarity 0.7636):
[0000950170-24-125685:note_history:70]
Wells Fargo Credit Agreement

- added (2025-05-20):
[0000950170-25-075374:note_history:71]
On July 18, 2022, ADTRAN, Inc., as the borrower ("U.S. Borrower"), and the Company entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (the “Original Credit Agreement”), as amended by the First Amendment to the Credit Agreement, dated August 9, 2023, 2021 (“Amendment No. 1”), the Second Amendment to the Credit Agreement, dated January 16, 2024 (“Amendment No. 2”), the Third Amendment to the Credit Agreement, dated March 12, 2024 (“Amendment No. 3”), and the Fourth Amendment to the Credit Amendment, dated June 4, 2024 (“Amendment No. 4” and, collectively with Amendment No. 1, Amendment No. 2, and Amendment No. 3, the “Credit Agreement Amendments”; and the Original Credit Agreement, as amended by the Credit Agreement Amendments, the “Amended Credit Agreement”). As of the date of this filing, the Amended Credit Agreement provided for a secured revolving credit facility of up to $374.0 million of borrowings, $74.0 million of which is solely available to Adtran Networks as borrower pursuant to the Subline (as defined and further described below.

- added (2025-05-20):
[0000950170-25-075374:note_history:72]
As of March 31, 2025, the Company’s borrowings under the revolving line of credit were $190.1 million, of which approximately $141.0 million were borrowed by the U.S. Borrower and $49.1 million were borrowed under the Subline by Adtran Networks (as defined below), who became a party to the Amended Credit Agreement in June 2024. The credit facilities provided under the Amended Credit Agreement mature in July 2027, but the U.S. Borrower may request extensions subject to customary conditions. In addition, the U.S. Borrower may utilize up to $50.0 million of the $374.0 million total revolving facility for the issuance of letters of credit. As of March 31, 2025, the U.S. Borrower had a total of $3.2 million in letters of credit under the Amended Credit Agreement, leaving a net amount (after giving effect to the $190.1 million of outstanding borrowings described above) of $180.7 million available for future borrowings;

- added (2025-05-20):
[0000950170-25-075374:note_history:73]
however, as of March 31, 2025 and the date of this filing the Company was limited to additional borrowings of $25.8 million based on debt covenant compliance metrics. Any future credit extensions under the Amended Credit Agreement are subject to customary conditions precedent. The proceeds of any loans are expected to be used for general corporate purposes and to pay a portion of the Exchange Offer consideration.

- added (2025-05-20):
[0000950170-25-075374:note_history:74]
Moreover, the Amended Credit Agreement provides for a sublimit under the existing $374.0 million revolving commitments in an aggregate amount of $100.0 million (“Subline”), which Subline is available for borrowings by Adtran Networks. Prepayments of outstanding loans under the Subline that result in the remaining outstanding loans under the Subline being less than the German Commitment Reduction Threshold (as defined below) will result in a permanent partial reduction of the commitments in respect of the Subline. The German Commitment Reduction Threshold was initially $75.0 million and may be lowered from time to time pursuant to the terms of the Amended Credit Agreement. The existing swing line sublimit and letter of credit sublimit under the Amended Credit Agreement remain available to the U.S. Borrower (and not to Adtran Networks). Otherwise, the loans under the Subline are subject to substantially the same terms and conditions under the Amended Credit Agreement (including with respect to the interest rate and maturity date) as the other existing revolving commitments.

- added (2025-05-20):
[0000950170-25-075374:note_history:75]
All U.S. borrowings under the Amended Credit Agreement bear interest at a rate tied to the Base Rate (as defined in the Amended Credit Agreement) or SOFR, at the Company’s option, and all E.U. borrowings bear interest at a rate tied to the Euro Interbank Offered Rate as administered by the European Money Markets Institute (or a comparable or successor administrator approved by the Administrative Agent), in each case plus applicable margins which vary based on the consolidated net leverage ratio of the Company and its subsidiaries as determined pursuant to the terms of the Amended Credit Agreement. Default interest is 2.00% per annum in excess of the rate otherwise applicable. As of March 31, 2025, the weighted average interest rate on our revolving credit agreements was 8.55%.

- added (2025-05-20):
[0000950170-25-075374:note_history:76]
The Company made certain representations and warranties to the lenders in the Amended Credit Agreement that are customary for credit arrangements of this type. The Company also agreed to maintain a Consolidated Total Net Leverage Ratio of 5.00x, a Consolidated Senior Secured Net Leverage Ratio of 3.25x (4.0x to 3.5x during a “Springing Covenant Period,” as defined below) and a Consolidated Fixed Charge Coverage Ratio of 1.25x (as such ratios are defined in the Amended Credit Agreement). A “Springing Covenant Event” occurs when at least sixty percent (60.0%) of the outstanding shares of Adtran Networks that were not owned by the Company and its subsidiaries as of August 9, 2023 have been tendered and purchased by the Company. Upon the occurrence of a Springing Covenant Event, the Company will enter a “Springing Covenant Period”, defined as the fiscal quarter in which a Springing Covenant Event occurs and the three (3) consecutive fiscal quarters thereafter. During a Springing Covenant Period, the Company’s leverage ratios are increased. In addition, the cash and cash equivalents of the credit parties must be at least $50.0 million and the cash and cash equivalents of the Company and its subsidiaries must be at least $70.0 million. As of March 31, 2025, the Company was in compliance with all covenants.

- added (2025-05-20):
[0000950170-25-075374:note_history:77]
The Amended Credit Agreement also contains customary events of default, such as misrepresentation and a default in the performance or observance of any covenant (subject to customary cure periods and materiality thresholds). Upon the occurrence and during the continuance of an event of default, the Administrative Agent is entitled to take various actions, including the acceleration of all amounts due under the Amended Credit Agreement.

- added (2025-05-20):
[0000950170-25-075374:note_history:78]
All obligations under the Amended Credit Agreement (including under the Subline) are guaranteed by the U.S. Borrower and certain subsidiaries of the U.S. Borrower (“Full Facility Guarantors”). To secure such guarantees, the U.S. Borrower and the Full Facility Guarantors have granted security interests in favor of the Administrative Agent over substantially all of their tangible and intangible assets, and the U.S. Borrower has granted mortgages in favor of the Administrative Agent over certain owned real estate assets. Certain of Adtran Networks' subsidiaries (the “Subline Guarantors”) have also provided a guarantee solely of the obligations in respect of the Subline. Furthermore, to secure such guarantees, Adtran Networks and the Subline Guarantors have granted security interests in favor of the Administrative Agent over substantially all of their tangible and intangible assets. Upon repayment in full and termination of the Subline, the guarantees by the Subline Guarantors and the liens granted by Adtran Networks and the Subline Guarantors to secure obligations under the Subline will be released.

- removed (2025-05-20):
[0000950170-24-125685:note_history:79]
As of September 30, 2024, the weighted average interest rate on our revolving credit agreements was 8.45%.

- removed (2025-05-20):
[0000950170-24-125685:note_history:80]
On July 18, 2022, ADTRAN, Inc., as the borrower ("U.S. Borrower"), and the Company entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (as amended from time to time, the “Credit Agreement”). As of the date of this filing, the Credit Agreement allows for revolving credit borrowings of up to $400.0 million in aggregate principal amount ($100.0 million of which is available to Adtran Networks as borrower pursuant to the Subline (as defined and further described below).

- removed (2025-05-20):
[0000950170-24-125685:note_history:81]
On August 9, 2023, ("First Amendment Effective Date") the Company and ADTRAN, Inc. entered into a First Amendment to Credit Agreement (“First Amendment”).

- removed (2025-05-20):
[0000950170-24-125685:note_history:82]
The First Amendment, among other things, increased the available funding from $100.0 million to $400.0 million. In addition, a new $50.0 million delayed draw term loan facility (“DDTL”) was introduced, which (subject to certain conditions) was available for borrowing in the event that at least sixty percent (60.0%) of the outstanding shares of Adtran Networks that were not owned by the Company and its subsidiaries as of the First Amendment Effective Date was tendered (such event, a “Springing Covenant Event”). Upon the occurrence of a Springing Covenant Event, the Company will enter a “Springing Covenant Period”, defined as the fiscal quarter in which a Springing Covenant Event occurs and the three (3) consecutive fiscal quarters thereafter. During the Springing Covenant Period, the Company’s leverage ratios are increased. Although the ability to borrow under the DDTL expired on August 9, 2024, the Springing Covenant Event and Springing Covenant Period remain in effect.

- removed (2025-05-20):
[0000950170-24-125685:note_history:83]
The First Amendment further added additional financial flexibility by permitting, subject to certain requirements, the incurrence of convertible indebtedness by the Company in an aggregate principal amount of up to $172.5 million. Any such convertible indebtedness must, among other things, be incurred in pro forma compliance with the financial covenants in the Credit Agreement, be unsecured, and otherwise rank junior to borrowings under the Credit Agreement and have a stated maturity date of at least 91 days after the latest scheduled maturity date of loans and commitments under the Credit Agreement. Net cash proceeds from any incurrence of convertible indebtedness must be used to repurchase shares of Adtran Networks or repay revolver borrowings under the Credit Agreement.

- removed (2025-05-20):
[0000950170-24-125685:note_history:84]
On January 16, 2024 ("Second Amendment Effective Date"), the Company and ADTRAN, Inc. entered into a Second Amendment to Credit Agreement and First Amendment to Collateral Agreement ("Second Amendment"). The Second Amendment, among other things, introduced the Covenant Relief Period, which provided the Company with additional covenant headroom while imposing a minimum liquidity financial covenant from the end of the fourth quarter of 2023 to the end of the third quarter of 2024. The Covenant Relief Period ended on November 7, 2024.

- removed (2025-05-20):
[0000950170-24-125685:note_history:85]
On March 12, 2024, the Company and ADTRAN, Inc. entered into a Third Amendment to Credit Agreement ("Third Amendment"). The Third Amendment, among other things, amended the definition of “Consolidated Funded Indebtedness” (which is used in the calculation of the Consolidated Total Net Leverage Ratio and the Consolidated Senior Secured Net Leverage Ratio) to exclude obligations of the Company and its subsidiaries under certain factoring arrangements when calculated for the fiscal quarters ending March 31, 2024, and June 30, 2024.

- removed (2025-05-20):
[0000950170-24-125685:note_history:86]
On June 4, 2024, the Company, ADTRAN, Inc., and Adtran Networks entered into a Fourth Amendment to Credit Agreement ("Fourth Amendment"). The Fourth Amendment, among other things, created a new sublimit under the existing $400.0 million revolving commitments, in an aggregate amount of $100.0 million (“Subline”), which Subline is available for borrowings by Adtran Networks. Prepayments of outstanding loans under the Subline that result in the remaining outstanding loans under the Subline being less than the German Commitment Reduction Threshold will result in a permanent partial reduction of the commitments in respect of the Subline. The German Commitment Reduction Threshold is initially $75.0 million and may be lowered from time to time pursuant to the terms of the Fourth Amendment. The existing swing line sublimit and letter of credit sublimit under the Credit Agreement remained available to the US Borrower (and not to Adtran Networks) after giving effect to the Fourth Amendment. Otherwise, the loans under the Subline are subject to substantially the same terms and conditions under the Credit Agreement (including with respect to the interest rate and maturity date) as the other existing revolving commitments.

- removed (2025-05-20):
[0000950170-24-125685:note_history:87]
As of September 30, 2024, ADTRAN, Inc.’s borrowings under the revolving line of credit were $189.8 million, of which approximately $115.0 million were borrowed by ADTRAN, Inc. and $75.0 million were borrowed under the Subline by Adtran Networks. The credit facilities provided under the Credit Agreement mature in July 2027, but the U.S. Borrower may request extensions subject to customary conditions. In addition, the U.S. Borrower may utilize up to $50.0 million of the $400.0 million total revolving facility for the issuance of letters of credit. As of September 30, 2024, we had a total of $4.4 million in letters of credit under ADTRAN, Inc. outstanding under the Credit Agreement, leaving a net amount (after giving effect to the $189.8 million of outstanding borrowings described above) of $205.6 million available for future borrowings; however, as of September 30, 2024, the Company was limited to additional borrowings of $24.1 million based on debt covenant compliance metrics. Any future credit extensions under the Credit Agreement are subject to customary conditions precedent. The proceeds of any loans are expected to be used for general corporate purposes and to pay a portion of the Exchange Offer consideration. As of September 30, 2024, the Company was in compliance with all covenants.

- removed (2025-05-20):
[0000950170-24-125685:note_history:88]
Revolving Line of Credit Interest Rate

- removed (2025-05-20):
[0000950170-24-125685:note_history:89]
All U.S. dollar borrowings under the revolving line of credit other than swingline loans, which bear interest at the Base Rate (as defined below plus the applicable margin), bear interest, at the Company’s option, at a rate per annum equal to either (A) the Base Rate plus an applicable margin ranging from 0.65% to 1.65% per annum based on the Company’s Consolidated Total Net Leverage Ratio (or, during the Applicable Margin Increase Period (as defined below), an applicable margin of 2.15% per annum), or (B) Adjusted Term SOFR (as defined below) plus an applicable margin ranging from 1.65% to 2.65% per annum based on the Company’s Consolidated Total Net Leverage Ratio (or, during the Applicable Margin Increase Period, an applicable margin of 3.15% per annum).

- removed (2025-05-20):
[0000950170-24-125685:note_history:90]
“Base Rate” means the highest of (a) the federal funds rate (i.e., for any day, the rate per annum equal to the weighted average of the rates on overnight federal funds transactions with members of the Federal Reserve System, as published by the Federal Reserve Bank of New York on the business day next succeeding such day) plus ½ of 1.0%, (b) the prime commercial lending rate of the Administrative Agent, as established from time to time at its principal U.S. office (which such rate is an index or base rate and will not necessarily be its lowest or best rate charged to its customers or other banks), or (c) the daily Adjusted Term SOFR (as defined in the Credit Agreement) for a one-month tenor plus 1.0%. The Base Rate is subject to a floor of 1.00% per annum.

- removed (2025-05-20):
[0000950170-24-125685:note_history:91]
“Adjusted Term SOFR” means Term SOFR for the applicable interest period plus 0.10% per annum. Adjusted Term SOFR is subject to a floor of 0.00% per annum.

- removed (2025-05-20):
[0000950170-24-125685:note_history:92]
All euro borrowings under the revolving line of credit bear interest at a rate per annum equal to EURIBOR (as defined in the Credit Agreement and subject to a 0.00% per annum floor) plus an applicable margin ranging from 1.75% to 2.75% per annum based on the Company’s Consolidated Total Net Leverage Ratio (or, during the Applicable Margin Increase Period, an applicable margin of 3.25% per annum).

- removed (2025-05-20):
[0000950170-24-125685:note_history:93]
In addition, if on or prior to December 31, 2024, we have not reduced the aggregate revolving credit commitment to $340.0 million or less, the applicable margin for all loans shall be increased by 1.00% per annum, and (y) if on or prior to June 30, 2025 we have not reduced the aggregate revolving credit commitment to $300.0 million or less, the applicable margin for all loans shall be increased by 1.00% per annum.

- removed (2025-05-20):
[0000950170-24-125685:note_history:94]
In addition to paying interest on outstanding principal under the Credit Agreement, the Company is required to pay a quarterly commitment fee to the lenders under the Credit Agreement in respect of unutilized revolving loan commitments on the average daily unused portion of the revolving credit commitment of each lender, which commitment fee ranges from 0.20% to 0.25% per annum based on the Company’s Consolidated Total Net Leverage Ratio (or, during the Applicable Margin Increase Period, is equal to 0.25% per annum). The Company is also required to pay a participation fee to the Administrative Agent for the account of each lender with respect to the Company’s participation in letters of credit at the then applicable rate for Adjusted Term SOFR Loans or EURIBOR Loans, and other customary fronting, issuance and administration fees with respect to letters of credit.

- removed (2025-05-20):
[0000950170-24-125685:note_history:95]
The “Applicable Margin Interest Period” means the period commencing on the Second Amendment Effective Date and ending on the first date when each of the following conditions have been met: (a) the Covenant Relief Period has ended, (b) since the Second Amendment Effective Date, the borrowers have repaid the revolving credit outstanding borrowings by a principal amount of at least $75.0 million, (c) the borrowers have reduced the aggregate revolving credit commitment to an amount no greater than $300.0 million, and (d) the borrowers are in compliance with all financial covenants based on the financial statements for the most recently completed reference period.

- removed (2025-05-20):
[0000950170-24-125685:note_history:96]
Default interest is 2.0% per annum in excess of the rate otherwise applicable.

- removed (2025-05-20):
[0000950170-24-125685:note_history:97]
Covenants Under the Credit Agreement

- removed (2025-05-20):
[0000950170-24-125685:note_history:98]
The financial covenants under the Credit Agreement, as amended, include the following (capitalized terms used in this subsection and not otherwise defined herein have the meanings assigned to them in the Credit Agreement or its amendments, as applicable):

- removed (2025-05-20):
[0000950170-24-125685:note_history:99]
•
As of the last day of any fiscal quarter, commencing with the fiscal quarter ended December 31, 2023, the Consolidated Total Net Leverage Ratio may not exceed 5.00x.

- removed (2025-05-20):
[0000950170-24-125685:note_history:100]
•
As of the last day of any fiscal quarter, commencing with the fiscal quarter ended December 31, 2023, the Consolidated Senior Secured Net Leverage Ratio may not exceed:

- removed (2025-05-20):
[0000950170-24-125685:note_history:101]
•
In the fiscal quarter in which a Springing Covenant Event occurs and the three consecutive quarterly test periods thereafter, (“Springing Covenant Period”), the following covenant levels:

- removed (2025-05-20):
[0000950170-24-125685:note_history:102]
•
First fiscal quarter ending after a Springing Covenant Event: 4.00x

- removed (2025-05-20):
[0000950170-24-125685:note_history:103]
•
Second fiscal quarter ending after a Springing Covenant Event: 3.75x

- removed (2025-05-20):
[0000950170-24-125685:note_history:104]
•
Third and fourth fiscal quarters ending after a Springing Covenant Event: 3.50x

- removed (2025-05-20):
[0000950170-24-125685:note_history:105]
•
If the Company or any of its subsidiaries incurs certain unsecured indebtedness in excess of $50.0 million in connection with a transaction that is a Springing Covenant Event or during a Springing Covenant Period, the Consolidated Senor Secured Net Leverage Ratio covenant will step down to 3.50x at the time of such incurrence.

- removed (2025-05-20):
[0000950170-24-125685:note_history:106]
•
If a Springing Covenant Period is not in effect, the Consolidated Senior Secured Net Leverage Ratio may not exceed 3.25x.

- removed (2025-05-20):
[0000950170-24-125685:note_history:107]
•
As of the last day of any fiscal quarter, commencing with the fiscal quarter ended December 31, 2023, the Consolidated Fixed Charge Coverage Ratio may not be less than 1.25x.

- removed (2025-05-20):
[0000950170-24-125685:note_history:108]
•
During a Springing Covenant Period, as of the last day of any fiscal quarter (i) cash and cash equivalents of the Credit Parties must be at least $50.0 million and (ii) cash and cash equivalents of the Company and its subsidiaries must be at least $70.0 million.

- removed (2025-05-20):
[0000950170-24-125685:note_history:109]
All obligations under the Credit Agreement (including under the Subline) are guaranteed by ADTRAN, Inc., and certain subsidiaries of ADTRAN, Inc. (“Full Facility Guarantors”). To secure such guarantees, ADTRAN, Inc. and the Full Facility Guarantors have granted security interests in favor of the Administrative Agent over substantially all of their tangible and intangible assets, and ADTRAN, Inc. has granted mortgages in favor of the Administrative Agent over certain owned real estate assets. Certain of Adtran Networks' subsidiaries ("Subline Guarantors") have provided a guarantee solely of the obligations in respect of the Subline. Furthermore, to secure such guarantees, the Subline Guarantors have granted security interests in favor of the Administrative Agent over substantially all of their tangible and intangible assets. Adtran Networks has also granted security interests in favor of the Administrative Agent over substantially all of its tangible and intangible assets, to secure solely its obligations under the Subline. Upon repayment in full and termination of the Subline, the guarantees by the Subline Guarantors and the liens granted by Adtran Networks and the Subline Guarantors to secure obligations under the Subline will be released.

- removed (2025-05-20):
[0000950170-24-125685:note_history:110]
The Credit Agreement, as amended, contains customary affirmative and negative covenants, including incurrence covenants and certain other limitations on the ability of the Company and the Company’s subsidiaries to incur additional debt, guarantee other obligations, grant liens on assets, make investments, dispose of assets, make restricted payments, engage in mergers or consolidations, engage in transactions with affiliates, modify its organizational documents, and enter into certain restrictive agreements. The negative covenants are subject to various exceptions and carveouts. It also contains customary events of default, such as misrepresentation and a default in the performance or observance of any covenant (subject to customary cure periods and materiality thresholds). Upon the occurrence and during the continuance of an event of default, the Administrative Agent is entitled to take various actions, including the acceleration of all amounts due under the Credit Agreement.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-05-20):
[0000950170-25-075374:note_history:111]
The Company has cash equivalents and investments which are held at fair value as follows:
  (was, 2024-11-12, similarity 0.7525):
[0000950170-24-125685:note_history:111]
The Company’s cash equivalents and investments held at fair value are categorized into this hierarchy as follows:

- added (2025-05-20):
[0000950170-25-075374:note_history:112]
|  |  |  |  |  | Fair Value Measurements as of March 31, 2025 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket for IdenticalAssets (Level 1) |  |  | SignificantOtherObservableInputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 5,539 |  |  | $ | 5,539 |  |  | $ | — |  |  | $ | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 970 |  |  |  | 970 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 29,003 |  |  |  | 29,003 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 35,512 |  |  | $ | 35,512 |  |  | $ | — |  |  | $ | — |  |

- changed (2025-05-20):
[0000950170-25-075374:note_history:113]
U.S. GAAP establishes a three-level valuation hierarchy based upon observable and unobservable inputs for fair value measurement of financial instruments:
  (was, 2024-11-12, similarity 0.6696):
[0000950170-24-125685:note_history:113]
Income generated from marketable equity securities was recorded as interest and dividend income in the Condensed Consolidated Statements of Loss. U.S. GAAP establishes a three-level valuation hierarchy based upon observable and unobservable inputs for fair value measurement of financial instruments:

- removed (2025-05-20):
[0000950170-24-125685:note_history:114]
Debt Securities and Other Investments

- removed (2025-05-20):
[0000950170-24-125685:note_history:115]
The Company did not have any debt securities and other investments as of September 30, 2024.

- removed (2025-05-20):
[0000950170-24-125685:note_history:116]
Realized gains and losses on sales of debt securities are computed under the specific identification method. The following table presents the gross realized gains and losses related to its debt securities:

- removed (2025-05-20):
[0000950170-24-125685:note_history:117]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Gross realized gain on debt securities |  | $ | — |  |  | $ | 5 |  |  | $ | — |  |  | $ | 9 |  |
| Gross realized loss on debt securities |  |  | — |  |  |  | (317 | ) |  |  | — |  |  |  | (355 | ) |
| Total loss recognized, net |  | $ | — |  |  | $ | (312 | ) |  | $ | — |  |  | $ | (346 | ) |

- removed (2025-05-20):
[0000950170-24-125685:note_history:118]
Realized and unrealized gains and losses related to marketable equity securities were as follows:

- removed (2025-05-20):
[0000950170-24-125685:note_history:119]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2024 |  |  | 2023 |  |  | 2024 |  |  | 2023 |  |
| Unrealized gain (loss) on equity securities held |  | $ | 1,372 |  |  | $ | (1,130 | ) |  | $ | 4,371 |  |  | $ | 1,404 |  |
| Realized (loss) gain on equity securities sold |  |  | 10 |  |  |  | (1 | ) |  |  | 136 |  |  |  | 13 |  |
| Total gain (loss) recognized, net |  | $ | 1,382 |  |  | $ | (1,131 | ) |  | $ | 4,507 |  |  | $ | 1,417 |  |

- removed (2025-05-20):
[0000950170-24-125685:note_history:120]
|  |  |  |  |  | Fair Value Measurements as of September 30, 2024 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket for IdenticalAssets (Level 1) |  |  | SignificantOtherObservableInputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 5,500 |  |  | $ | 5,500 |  |  | $ | — |  |  | $ | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 1,035 |  |  |  | 1,035 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 30,471 |  |  |  | 30,471 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 37,006 |  |  | $ | 37,006 |  |  | $ | — |  |  | $ | — |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2025-05-20):
[0000950170-25-075374:note_history:121]
|  |  | Three Months Ended |  |
|  |  | March 31, 2025 |  |  | March 31, 2024 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Subscriber Solutions |  | $ | 71,748 |  |  | $ | 8,662 |  |  | $ | 80,410 |  |  | $ | 60,369 |  |  | $ | 9,399 |  |  | $ | 69,767 |  |
| Access & Aggregation Solutions |  |  | 75,847 |  |  |  | 13,289 |  |  |  | 89,136 |  |  |  | 67,777 |  |  |  | 13,535 |  |  |  | 81,312 |  |
| Optical Networking Solutions |  |  | 54,622 |  |  |  | 23,576 |  |  |  | 78,198 |  |  |  | 53,127 |  |  |  | 21,966 |  |  |  | 75,094 |  |
| Total |  | $ | 202,217 |  |  | $ | 45,527 |  |  | $ | 247,744 |  |  | $ | 181,273 |  |  | $ | 44,900 |  |  | $ | 226,173 |  |

- removed (2025-05-20):
[0000950170-24-125685:note_history:122]
|  |  | Three Months Ended |  |
|  |  | September 30, 2024 |  |  | September 30, 2023 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Subscriber Solutions |  | $ | 81,060 |  |  | $ | 9,036 |  |  | $ | 90,096 |  |  | $ | 52,921 |  |  | $ | 8,564 |  |  | $ | 61,485 |  |
| Optical Networking Solutions |  |  | 47,474 |  |  |  | 23,061 |  |  |  | 70,535 |  |  |  | 94,592 |  |  |  | 21,608 |  |  |  | 116,200 |  |
| Access & Aggregation Solutions |  |  | 52,954 |  |  |  | 14,119 |  |  |  | 67,073 |  |  |  | 81,051 |  |  |  | 13,595 |  |  |  | 94,646 |  |
| Total |  | $ | 181,488 |  |  | $ | 46,216 |  |  | $ | 227,704 |  |  | $ | 228,564 |  |  | $ | 43,767 |  |  | $ | 272,331 |  |

- removed (2025-05-20):
[0000950170-24-125685:note_history:123]
|  |  | Nine Months Ended |  |
|  |  | September 30, 2024 |  |  | September 30, 2023 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Subscriber Solutions |  | $ | 215,044 |  |  | $ | 27,218 |  |  | $ | 242,262 |  |  | $ | 196,726 |  |  | $ | 25,760 |  |  | $ | 222,486 |  |
| Optical Networking Solutions |  |  | 152,068 |  |  |  | 67,246 |  |  |  | 219,314 |  |  |  | 342,390 |  |  |  | 64,562 |  |  |  | 406,952 |  |
| Access & Aggregation Solutions |  |  | 174,843 |  |  |  | 43,449 |  |  |  | 218,292 |  |  |  | 254,868 |  |  |  | 39,315 |  |  |  | 294,183 |  |
| Total |  | $ | 541,955 |  |  | $ | 137,913 |  |  | $ | 679,868 |  |  | $ | 793,984 |  |  | $ | 129,637 |  |  | $ | 923,621 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2025-05-20):
[0000950170-25-075374:note_history:124]
|  |  | Three Months Ended |  |
|  |  | March 31, 2025 |  |  | March 31, 2024 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Subscriber Solutions |  | $ | 71,748 |  |  | $ | 8,662 |  |  | $ | 80,410 |  |  | $ | 60,369 |  |  | $ | 9,399 |  |  | $ | 69,767 |  |
| Access & Aggregation Solutions |  |  | 75,847 |  |  |  | 13,289 |  |  |  | 89,136 |  |  |  | 67,777 |  |  |  | 13,535 |  |  |  | 81,312 |  |
| Optical Networking Solutions |  |  | 54,622 |  |  |  | 23,576 |  |  |  | 78,198 |  |  |  | 53,127 |  |  |  | 21,966 |  |  |  | 75,094 |  |
| Total |  | $ | 202,217 |  |  | $ | 45,527 |  |  | $ | 247,744 |  |  | $ | 181,273 |  |  | $ | 44,900 |  |  | $ | 226,173 |  |

- changed (2025-05-20):
[0000950170-25-075374:note_history:125]
The aggregate amount of transaction price allocated to remaining performance obligations that have not been satisfied as of March 31, 2025 and December 31, 2024 related to contractual maintenance agreements, contractual SaaS and subscription services, and hardware contracts that exceed one year in duration amounted to $274.3 million and $325.7 million, respectively. As of March 31, 2025, approximately 69% is expected to be recognized over the next 12 months and the remainder recognized thereafter. The majority of the Company's remaining performance obligations as of March 31, 2025, are related to contracts or orders that have an original expected duration of one year or less and are excluded from the transaction price related to these future obligations. The Company will generally satisfy the remaining performance obligations as we transfer control of the products ordered or services to our customers, excluding maintenance services, which are satisfied over time.
  (was, 2024-11-12, similarity 0.958):
[0000950170-24-125685:note_history:125]
The aggregate amount of transaction price allocated to remaining performance obligations that have not been satisfied as of September 30, 2024, related to contractual maintenance agreements, contractual SaaS and subscription services, and hardware contracts that exceed one year in duration amounted to $280.8 million. As of September 30, 2024, approximately 66.0% is expected to be recognized over the next 12 months and the remainder recognized thereafter. The majority of the Company's remaining performance obligations as of September 30, 2024, are related to contracts or orders that have an original expected duration of one year or less and are excluded from the transaction price related to these future obligations. The Company will generally satisfy the remaining performance obligations as we transfer control of the products ordered or services to our customers, excluding maintenance services, which are satisfied over time.

- changed (2025-05-20):
[0000950170-25-075374:note_history:126]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | March 31, 2025 |  |  | December 31, 2024 |  |
| Accounts receivable, net |  | $ | 166,519 |  |  | $ | 178,030 |  |
| Contract assets(1) |  | $ | 431 |  |  | $ | 631 |  |
| Unearned revenue |  | $ | 66,459 |  |  | $ | 52,701 |  |
| Non-current unearned revenue |  | $ | 24,082 |  |  | $ | 22,065 |  |
  (was, 2024-11-12, similarity 0.9263):
[0000950170-24-125685:note_history:126]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | September 30, 2024 |  |  | December 31, 2023 |  |
| Accounts receivable, net |  | $ | 172,025 |  |  | $ | 216,445 |  |
| Contract assets(1) |  | $ | 668 |  |  | $ | 691 |  |
| Unearned revenue |  | $ | 54,615 |  |  | $ | 46,731 |  |
| Non-current unearned revenue |  | $ | 24,901 |  |  | $ | 25,109 |  |

- changed (2025-05-20):
[0000950170-25-075374:note_history:127]
The allowance for credit losses was $1.2 million and $1.3 million as of March 31, 2025, and December 31, 2024, respectively, related to accounts receivable.
  (was, 2024-11-12, similarity 0.9071):
[0000950170-24-125685:note_history:127]
The allowance for credit losses was $0.4 million as of September 30, 2024, and December 31, 2023, respectively, related to accounts receivable.

- changed (2025-05-20):
[0000950170-25-075374:note_history:128]
Receivables Purchase Agreements
  (was, 2024-11-12, similarity 0.9836):
[0000950170-24-125685:note_history:128]
Receivables Purchase Agreement

- changed (2025-05-20):
[0000950170-25-075374:note_history:129]
On July 1, 2024, the Company entered into a receivables purchase agreement (the “Factoring Agreement”) with a third-party financial institution (the “Factor”), which accelerates receivable collection and helps to better manage cash flow. Total accounts receivables factored as of the end of March 31, 2025, totaled $11.2 million of which $3.7 million was retained pursuant to the Factoring Agreement in the reserve account. The Factoring Agreement provides for up to $40.0 million in factoring capacity, subject to eligible receivables and reserve requirements, secured by the receivables. The balance in the reserve account is included in other assets on the Condensed Consolidated Balance Sheets. The cost of the Factoring Agreement is included in interest expense in the Condensed Consolidated Statements of Loss and totaled $0.3 million for the three months ended March 31, 2025.
  (was, 2024-11-12, similarity 0.8535):
[0000950170-24-125685:note_history:129]
On July 1, 2024, the Company entered into a receivables purchase agreement (the “Factoring Agreement”) with a third-party financial institution (the “Factor”), which accelerates receivable collection and helps to better manage cash flow. Total accounts receivables factored as of the end of September 30, 2024, totaled $16.7 million of which $3.7 million was retained pursuant to the Factoring Agreement in the reserve account. The Factoring Agreement provides for up to $40.0 million in factoring capacity, subject to eligible receivables and reserve requirements, secured by the receivables. The balance in the reserve account is included in other assets on the Condensed Consolidated Balance Sheets. The cost of the Factoring Agreement is included in interest expense in the Condensed Consolidated Statements of Loss and totaled $0.3 million for the three months and nine months ended September 30, 2024. Costs of a previous receivables purchase agreement which are included in interest expense in the Condensed Consolidated Statements of Loss totaled $0.3 million and $0.9 million for the three and nine months ended September 30, 2023.

- added (2025-05-20):
[0000950170-25-075374:note_history:130]
On December 19, 2023, the Company entered into a receivables purchase agreement (the "Prior Factoring Agreement") with a third-party financial institution which qualified for treatment as a secured borrowing with a pledge of collateral under Accounting Standards Codification ("ASC") Topic 810, Consolidation. The Prior Factoring Agreement was terminated on July 1, 2024. For the three months ended March 31, 2024, the Company incurred program fee expenses of $0.3 million.

- changed (2025-05-20):
[0000950170-25-075374:note_history:131]
No allowance for credit losses was recorded for the three months ended March 31, 2025 and 2024, respectively, related to contract assets.
  (was, 2024-11-12, similarity 0.9294):
[0000950170-24-125685:note_history:131]
No allowance for credit losses was recorded for the three and nine months ended September 30, 2024 and 2023, respectively, related to contract assets.

- added (2025-05-20):
[0000950170-25-075374:note_history:132]
Of the outstanding unearned revenue balances as of December 31, 2024, $21.9 million were recognized as revenue during the three months ended March 31, 2025. Of the $65.1 million of outstanding unearned revenue balances as of December 31, 2023, $19.7 million were recognized as revenue during the three months ended March 31, 2024.

- removed (2025-05-20):
[0000950170-24-125685:note_history:133]
|  |  | Three Months Ended |  |
|  |  | September 30, 2024 |  |  | September 30, 2023 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Subscriber Solutions |  | $ | 81,060 |  |  | $ | 9,036 |  |  | $ | 90,096 |  |  | $ | 52,921 |  |  | $ | 8,564 |  |  | $ | 61,485 |  |
| Optical Networking Solutions |  |  | 47,474 |  |  |  | 23,061 |  |  |  | 70,535 |  |  |  | 94,592 |  |  |  | 21,608 |  |  |  | 116,200 |  |
| Access & Aggregation Solutions |  |  | 52,954 |  |  |  | 14,119 |  |  |  | 67,073 |  |  |  | 81,051 |  |  |  | 13,595 |  |  |  | 94,646 |  |
| Total |  | $ | 181,488 |  |  | $ | 46,216 |  |  | $ | 227,704 |  |  | $ | 228,564 |  |  | $ | 43,767 |  |  | $ | 272,331 |  |

- removed (2025-05-20):
[0000950170-24-125685:note_history:134]
|  |  | Nine Months Ended |  |
|  |  | September 30, 2024 |  |  | September 30, 2023 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Subscriber Solutions |  | $ | 215,044 |  |  | $ | 27,218 |  |  | $ | 242,262 |  |  | $ | 196,726 |  |  | $ | 25,760 |  |  | $ | 222,486 |  |
| Optical Networking Solutions |  |  | 152,068 |  |  |  | 67,246 |  |  |  | 219,314 |  |  |  | 342,390 |  |  |  | 64,562 |  |  |  | 406,952 |  |
| Access & Aggregation Solutions |  |  | 174,843 |  |  |  | 43,449 |  |  |  | 218,292 |  |  |  | 254,868 |  |  |  | 39,315 |  |  |  | 294,183 |  |
| Total |  | $ | 541,955 |  |  | $ | 137,913 |  |  | $ | 679,868 |  |  | $ | 793,984 |  |  | $ | 129,637 |  |  | $ | 923,621 |  |

- removed (2025-05-20):
[0000950170-24-125685:note_history:135]
Previous Receivable Purchase Agreement

- removed (2025-05-20):
[0000950170-24-125685:note_history:136]
On December 19, 2023, the Company entered into a receivables purchase agreement (the “Prior Factoring Agreement”) with a third-party financial institution (the "Factor")  to replace a prior accounts receivable purchase agreement and to sell, on a revolving basis, undivided interests in the Company’s accounts receivable. The prior factoring agreement provided for up to $40.0 million in borrowing capacity, subject to eligible receivables and reserve requirements, secured by the receivables. The prior factoring agreement qualified for treatment as a secured borrowing with a pledge of collateral under Accounting Standards Codification ("ASC") Topic 810, Consolidations. The receivables purchase agreement was terminated on July 1, 2024 and there were no secured borrowings under this agreement as of September 30, 2024. Total secured borrowings under the agreement were $14.3 million as of December 31, 2023, which left $25.4 million available for future borrowings as of December 31, 2023. Accounts receivable pledged as collateral related to the secured borrowings were $16.8 million as of December 31, 2023. For the nine months ended September 30, 2024, the Company incurred program fee expenses of $0.6 million.

- removed (2025-05-20):
[0000950170-24-125685:note_history:137]
Of the outstanding unearned revenue balances as of December 31, 2023, $10.03 million and $43.1 million were recognized as revenue during the three and nine months ended September 30, 2024, respectively. Of the $60.4 million of outstanding unearned revenue balances as of December 31, 2022, $6.1 million and $31.3 million were recognized as revenue during the three and nine months ended September 30, 2023, respectively.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_prior_note, score: 0.0

- added (2025-05-20):
[0000950170-25-075374:note_history:138]
19. SUBSEQUENT EVENTS

- added (2025-05-20):
[0000950170-25-075374:note_history:139]
Exit Compensation Payments

- added (2025-05-20):
[0000950170-25-075374:note_history:140]
On April 14, 2025, 0.4 million shares of Adtran Networks stock were tendered to the Company and Exit Compensation payments of approximately €7.0 million or approximately $7.5 million, based on the applicable exchange rate at the time of the transaction, was paid to Adtran Networks shareholders.

- added (2025-05-20):
[0000950170-25-075374:note_history:141]
Fifth Amendment to Wells Fargo Credit Agreement

- added (2025-05-20):
[0000950170-25-075374:note_history:142]
On May 6, 2025, the Company, ADTRAN, Inc., and Adtran Networks entered into a fifth amendment to the Credit Agreement ("Amendment No. 5"). Amendment No. 5, together with a substantially concurrent prepayment by the German Borrower of outstanding revolving loans under the German Borrower Sublimit (as defined in the Amended Credit Agreement, which term includes Amendment No. 5 for the purposes of this note) in the amount of $24.0 million, among other things, resulted in (i) a permanent partial reduction in the total commitments under the Amended Credit Agreement from $374.0 million to $350.0 million, (ii) a reduction of the German Borrower Sublimit from $74.0 million to $50.0 million, and (iii) a reduction of the German Commitment Reduction Threshold (as defined in the Amended Credit Agreement) to $25.0 million. The lenders also waived certain events of default related to among others, inaccuracies in the financial statements that were previously delivered to the lenders by the Company with respect to the fiscal quarters ended June 30, 2024 and September 30, 2024, and breaches of the Consolidated Fixed Charge Coverage Ratio (as defined in the Amended Credit Agreement) financial covenant for the fiscal quarters ended June 30, 2024 and September 30, 2024.
