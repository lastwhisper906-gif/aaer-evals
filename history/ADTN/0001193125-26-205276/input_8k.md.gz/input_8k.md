# ADTN 8-K — 0001193125-26-204995 filed 2026-05-05

## item codes, every 8-K on or before 2026-05-05

- 2026-05-05 0001193125-26-204995 — 2.02, 7.01, 9.01
- 2026-04-07 0001193125-26-145496 — 5.02, 9.01
- 2026-02-26 0001193125-26-073361 — 2.02, 7.01, 9.01
- 2026-01-22 0001193125-26-018367 — 2.02, 7.01, 9.01
- 2025-12-11 0001193125-25-315910 — 5.02, 9.01
- 2025-11-04 0001193125-25-263524 — 2.02, 7.01, 9.01
- 2025-09-22 0001193125-25-211271 — 1.01, 2.03, 3.02, 9.01
- 2025-09-17 0001193125-25-205483 — 1.01, 8.01, 9.01
- 2025-08-05 0000950170-25-102401 — 2.02, 7.01, 9.01
- 2025-07-30 0000950170-25-100222 — 5.07, 8.01, 9.01
- 2025-07-17 0000950170-25-096408 — 2.02, 7.01, 9.01 — amendment of 0000950170-25-096231
- 2025-07-16 0000950170-25-096231 — 2.02, 7.01, 9.01
- 2025-05-28 0000950170-25-077995 — 2.02, 9.01
- 2025-05-27 0001193125-25-127878 — 8.01, 9.01
- 2025-05-13 0000950170-25-070473 — 4.02, 8.01, 9.01
- 2025-05-12 0000950170-25-069478 — 1.01, 9.01
- 2025-05-08 0000950170-25-066343 — 2.02, 7.01, 9.01
- 2025-04-16 0001193125-25-081800 — 7.01, 9.01
- 2025-03-07 0001193125-25-048727 — 5.02, 7.01, 9.01
- 2025-02-27 0000950170-25-028352 — 2.02, 7.01, 9.01
- 2024-11-07 0000950170-24-122762 — 2.02, 7.01, 9.01
- 2024-08-30 0000950170-24-102309 — 5.02, 9.01
- 2024-08-06 0000950170-24-091207 — 2.02, 7.01, 9.01
- 2024-08-02 0000950170-24-089974 — 5.02
- 2024-06-10 0001193125-24-158388 — 1.01, 2.03, 9.01
- 2024-05-09 0000950170-24-056830 — 5.02, 5.07, 9.01
- 2024-05-07 0000950170-24-053920 — 2.02, 7.01, 9.01
- 2024-05-03 0001193125-24-130896 — 2.02, 7.01, 9.01
- 2024-04-17 0000950170-24-045151 — 2.05, 9.01
- 2024-03-15 0000950170-24-031864 — 2.02, 9.01
- 2024-02-27 0000950170-24-020613 — 2.02, 7.01, 9.01
- 2024-02-20 0001193125-24-040068 — 4.02
- 2024-01-22 0001193125-24-011697 — 1.01, 2.03, 9.01
- 2023-12-06 0001193125-23-289895 — 5.02, 9.01
- 2023-12-05 0001193125-23-289150 — 5.02, 9.01
- 2023-11-07 0001193125-23-271842 — 2.02, 7.01, 9.01
- 2023-10-24 0001193125-23-261665 — 5.02, 5.03, 9.01
- 2023-10-17 0001193125-23-257289 — 2.02, 7.01, 9.01
- 2023-09-29 0001193125-23-246498 — 5.02
- 2023-08-14 0001193125-23-212439 — 2.02, 9.01 — amendment of 0001193125-23-204377
- 2023-08-10 0001193125-23-209039 — 4.02, 9.01
- 2023-08-10 0001193125-23-209024 — 2.02, 9.01 — amendment of 0001193125-23-204377
- 2023-08-07 0001193125-23-204377 — 2.02, 7.01, 9.01
- 2023-06-28 0001193125-23-177593 — 5.02, 9.01
- 2023-06-01 0001193125-23-158986 — 5.02, 9.01
- 2023-05-30 0001193125-23-156741 — 5.02
- 2023-05-15 0000950170-23-021860 — 5.07, 9.01
- 2023-05-09 0000950170-23-019145 — 2.02, 9.01
- 2023-04-11 0001193125-23-097240 — 2.02, 9.01
- 2023-04-03 0001193125-23-089517 — 5.02, 9.01
- 2023-03-30 0001193125-23-085151 — 5.02, 9.01
- 2023-02-21 0000950170-23-003277 — 2.02, 9.01
- 2023-02-08 0001193125-23-028386 — 1.02, 9.01
- 2023-01-26 0001193125-23-016354 — 5.02, 9.01
- 2023-01-19 0001193125-23-010702 — 8.01, 9.01
- 2022-12-05 0001193125-22-298171 — 1.01, 9.01
- 2022-11-09 0000950170-22-023662 — 2.02 — amendment of 0000950170-22-022906
- 2022-11-08 0000950170-22-022906 — 2.02, 9.01
- 2022-10-26 0001193125-22-269383 — 8.01
- 2022-10-25 0001193125-22-268261 — 2.02, 9.01 — amendment, the index does not say of what
- 2022-10-25 0001193125-22-267712 — 2.02, 9.01
- 2022-10-18 0001193125-22-264344 — 8.01, 9.01
- 2022-09-30 0000950170-22-019126 — 5.02, 9.01 — amendment of 0001193125-22-195093
- 2022-08-04 0000950170-22-014476 — 2.02, 9.01
- 2022-07-22 0001193125-22-200018 — 1.01, 1.02, 2.03, 9.01
- 2022-07-15 0001193125-22-195093 — 2.01, 5.02, 9.01
- 2022-07-08 0001193125-22-190213 — 2.01, 3.01, 3.03, 5.01, 5.02, 5.03, 7.01, 9.01
- 2022-07-07 0001193125-22-188934 — 7.01, 9.01
- 2022-06-30 0001193125-22-186294 — 5.04, 9.01
- 2022-05-23 0000950170-22-010455 — 1.01, 2.03, 9.01
- 2022-05-13 0000950170-22-009818 — 5.07
- 2022-05-05 0000950170-22-007563 — 2.02, 9.01
- 2022-04-06 0000950170-22-005405 — 1.01, 2.03, 9.01
- 2022-02-03 0000950170-22-000705 — 2.02, 9.01
- 2022-01-06 0001193125-22-003467 — 5.07, 7.01, 9.01
- 2021-12-28 0001193125-21-368041 — 8.01
- 2021-11-29 0000950170-21-004926 — 5.02, 9.01
- 2021-11-02 0000950170-21-002595 — 7.01, 9.01
- 2021-11-02 0000950170-21-002593 — 2.02, 9.01
- 2021-10-15 0000950170-21-002127 — 2.02, 9.01
- 2021-10-07 0000950170-21-002053 — 5.02
- 2021-09-01 0000950170-21-001615 — 5.02
- 2021-08-30 0001193125-21-260059 — 1.01, 7.01, 9.01
- 2021-08-05 0001564590-21-041127 — 2.02, 9.01
- 2021-05-18 0001564590-21-028541 — 5.07
- 2021-05-06 0001564590-21-024430 — 2.02, 9.01
- 2021-02-26 0001564590-21-009408 — 2.02, 9.01 — amendment of 0001564590-21-004167
- 2021-02-04 0001564590-21-004167 — 2.02, 9.01
- 2020-11-03 0001564590-20-049784 — 2.02, 9.01
- 2020-08-06 0001564590-20-037168 — 2.02, 9.01
- 2020-07-23 0001564590-20-033184 — 5.03, 9.01
- 2020-05-15 0001564590-20-025794 — 5.07
- 2020-05-11 0001564590-20-024328 — 5.02, 9.01
- 2020-05-07 0001564590-20-022297 — 2.02, 9.01
- 2020-02-25 0001564590-20-006448 — 2.02, 9.01
- 2020-02-06 0001564590-20-003580 — 2.02, 9.01
- 2019-10-31 0001564590-19-038936 — 2.02, 9.01
- 2019-10-10 0001564590-19-036732 — 2.02, 9.01
- 2019-09-20 0001564590-19-035144 — 2.02, 9.01
- 2019-08-21 0001564590-19-032757 — 3.01, 9.01
- 2019-07-18 0001564590-19-025186 — 2.02, 9.01
- 2019-05-09 0001564590-19-017956 — 5.07
- 2019-04-18 0001564590-19-011897 — 2.02, 9.01
- 2019-03-07 0001564590-19-006575 — 5.02, 9.01
- 2019-01-24 0001564590-19-001024 — 2.02, 9.01
- 2018-12-06 0001564590-18-030615 — 8.01, 9.01
- 2018-10-17 0001564590-18-024365 — 2.02, 9.01
- 2018-07-18 0001564590-18-016946 — 2.02, 9.01
- 2018-05-10 0001564590-18-012968 — 5.07
- 2018-04-18 0001564590-18-008361 — 2.02, 9.01
- 2018-03-21 0001564590-18-006409 — 8.01, 9.01
- 2018-01-17 0001564590-18-000519 — 2.02, 9.01
- 2017-12-29 0001564590-17-025375 — 2.02, 9.01
- 2017-11-16 0001193125-17-345232 — 5.02
- 2017-10-18 0001564590-17-019582 — 2.02, 9.01
- 2017-07-19 0001564590-17-013609 — 2.02, 9.01
- 2017-05-11 0001564590-17-010459 — 5.02, 9.01
- 2017-05-11 0001564590-17-010452 — 5.07
- 2017-04-19 0001193125-17-127926 — 2.02, 9.01
- 2017-02-07 0001193125-17-032714 — 8.01
- 2017-01-18 0001193125-17-011669 — 2.02, 9.01
- 2016-11-16 0001193125-16-769505 — 5.02, 9.01
- 2016-10-19 0001193125-16-741087 — 2.02, 9.01
- 2016-09-14 0001193125-16-709148 — 8.01, 9.01
- 2016-08-17 0001193125-16-683980 — 5.02, 9.01
- 2016-07-13 0001193125-16-646816 — 2.02, 9.01
- 2016-05-13 0001193125-16-590263 — 5.07
- 2016-04-13 0001193125-16-539019 — 2.02, 9.01
- 2016-04-08 0001193125-16-535035 — 7.01
- 2016-02-11 0001193125-16-459453 — 5.02, 9.01
- 2016-01-20 0001193125-16-432934 — 2.02, 9.01
- 2015-11-16 0001193125-15-378019 — 5.02, 9.01
- 2015-10-14 0001193125-15-343083 — 2.02, 9.01
- 2015-07-16 0001193125-15-254729 — 8.01, 9.01
- 2015-07-15 0001193125-15-253068 — 2.02, 9.01
- 2015-05-15 0001193125-15-189160 — 5.07, 9.01
- 2015-04-22 0001193125-15-140997 — 2.02, 9.01
- 2015-02-23 0001193125-15-056741 — 5.02, 9.01
- 2015-01-21 0001193125-15-015465 — 2.02, 9.01
- 2014-10-15 0001193125-14-372076 — 2.02, 9.01
- 2014-10-03 0001193125-14-363152 — 2.02, 9.01
- 2014-07-16 0001193125-14-269660 — 2.02, 9.01
- 2014-05-20 0001193125-14-205916 — 8.01, 9.01
- 2014-05-20 0001193125-14-205906 — 5.02, 9.01
- 2014-05-15 0001193125-14-201144 — 5.07
- 2014-04-16 0001193125-14-144665 — 2.02, 9.01
- 2014-04-03 0001193125-14-129578 — 2.02, 9.01
- 2014-01-22 0001157523-14-000154 — 2.02, 9.01
- 2013-10-15 0001193125-13-399540 — 5.02
- 2013-10-09 0001157523-13-004657 — 2.02, 9.01
- 2013-07-10 0001157523-13-003290 — 2.02, 9.01
- 2013-05-10 0001193125-13-213728 — 5.07
- 2013-05-03 0001193125-13-198816 — 8.01, 9.01
- 2013-04-10 0001157523-13-001730 — 2.02, 9.01
- 2013-01-16 0001157523-13-000139 — 2.02, 9.01
- 2012-10-10 0001157523-12-005081 — 2.02, 9.01
- 2012-10-03 0001193125-12-413609 — 7.01
- 2012-09-28 0001193125-12-408878 — 2.02, 9.01
- 2012-07-11 0001157523-12-003592 — 2.02, 9.01
- 2012-05-10 0001193125-12-225669 — 5.07
- 2012-05-10 0001193125-12-225639 — 8.01, 9.01
- 2012-04-11 0001157523-12-001772 — 2.02, 9.01
- 2012-03-15 0001193125-12-116494 — 2.02, 9.01
- 2012-01-18 0001157523-12-000174 — 2.02, 9.01
- 2011-12-12 0001193125-11-337271 — 7.01, 9.01
- 2011-10-13 0000950123-11-089785 — 5.03, 9.01
- 2011-10-12 0001157523-11-005682 — 2.02, 9.01
- 2011-07-13 0001157523-11-003986 — 2.02, 9.01
- 2011-05-09 0000950123-11-047191 — 5.02, 5.07, 9.01
- 2011-04-13 0001157523-11-002001 — 2.02, 9.01
- 2011-01-19 0001157523-11-000232 — 2.02, 9.01
- 2010-11-09 0000950123-10-103195 — 5.02, 9.01
- 2010-10-13 0001157523-10-005798 — 2.02, 9.01
- 2010-07-14 0001157523-10-004011 — 2.02, 9.01
- 2010-05-28 0000950123-10-053947 — 5.07
- 2010-04-14 0001157523-10-002022 — 2.02, 9.01
- 2010-01-20 0001157523-10-000200 — 2.02, 9.01
- 2009-10-28 0000950123-09-053984 — 8.01
- 2009-10-14 0001157523-09-006877 — 2.02, 9.01
- 2009-07-15 0001157523-09-004878 — 2.02, 9.01
- 2009-04-15 0001157523-09-002687 — 2.02, 9.01
- 2009-01-21 0001157523-09-000340 — 2.02, 9.01
- 2008-11-12 0001193125-08-233181 — 5.02, 9.01
- 2008-10-14 0001157523-08-007999 — 2.02, 9.01
- 2008-07-15 0001157523-08-005504 — 2.02, 9.01
- 2008-04-15 0001157523-08-002896 — 2.02, 9.01
- 2008-01-22 0001157523-08-000408 — 2.02, 9.01
- 2007-10-16 0001193125-07-219356 — 5.03, 9.01
- 2007-10-16 0001157523-07-009850 — 2.02, 9.01
- 2007-07-17 0001157523-07-006912 — 2.02, 9.01
- 2007-04-17 0001157523-07-003630 — 2.02, 9.01
- 2007-04-03 0001179022-07-000068 — 5.02
- 2007-03-28 0001179022-07-000064 — 5.02
- 2007-02-23 0001193125-07-038337 — 5.02
- 2007-02-23 0001193125-07-038335 — 5.02
- 2007-01-30 0001193125-07-015912 — 5.02, 9.01
- 2007-01-26 0001193125-07-014234 — 5.02
- 2007-01-23 0001157523-07-000494 — 2.02, 9.01 — amendment of 0001157523-07-000481
- 2007-01-23 0001157523-07-000481 — 2.02, 9.01
- 2006-10-17 0001157523-06-009945 — 2.02, 9.01
- 2006-07-18 0001157523-06-006929 — 2.02, 9.01
- 2006-06-08 0001193125-06-126486 — 1.01, 9.01
- 2006-05-10 0001193125-06-107316 — 1.01, 9.01
- 2006-04-18 0001157523-06-003699 — 2.02, 9.01
- 2006-02-03 0001179022-06-000014 — 1.01
- 2006-01-27 0001157523-06-000754 — 5.02, 9.01
- 2006-01-24 0001157523-06-000551 — 2.02, 9.01
- 2005-10-18 0001157523-05-008826 — 2.02, 9.01
- 2005-07-19 0001193125-05-143958 — 1.01, 5.02, 9.01
- 2005-07-19 0001193125-05-143957 — 2.02, 9.01
- 2005-05-20 0001193125-05-112019 — 1.01, 9.01
- 2005-04-19 0001157523-05-003418 — 2.02, 9.01
- 2005-01-25 0001193125-05-010721 — 2.02, 9.01
- 2004-10-12 0001193125-04-169652 — 2.02, 9.01
- 2004-07-13 0001193125-04-116820 — 12, 7
- 2004-04-14 0001193125-04-061547 — 12, 7
- 2004-01-21 0001193125-04-006366 — 12, 7
- 2003-10-14 0001193125-03-061018 — 12, 5, 7
- 2003-07-15 0001193125-03-019292 — 7, 9
- 2003-04-15 0000931763-03-000968 — 7, 9
- 1996-09-12 0000931763-96-000667 — 5, 7

## late-filing notifications on or before 2026-05-05

- 2025-05-13 0000950170-25-070493 — NT 10-Q, for the period ended 2025-05-13
- 2024-02-29 0000950170-24-023141 — NT 10-K, for the period ended 2023-12-31
- 2023-08-10 0001193125-23-209042 — NT 10-Q, for the period ended 2023-06-30
- 2019-08-12 0001564590-19-031524 — NT 10-Q, for the period ended 2019-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001193125-26-204995:8k_2_02:1]
EX-99.1
2
adtn-ex99_1.htm
EX-99.1

[0001193125-26-204995:8k_2_02:2]
EX-99.1

[0001193125-26-204995:8k_2_02:3]
ADTRAN Holdings, Inc. reports first quarter 2026 financial results

[0001193125-26-204995:8k_2_02:4]
Huntsville, Alabama, USA. — May 4, 2026 — ADTRAN Holdings, Inc. (NASDAQ: ADTN and FSE: QH9) (“ADTRAN Holdings” “ADTRAN” or the “Company”) today announced its unaudited financial results for the first quarter ended March 31, 2026.

[0001193125-26-204995:8k_2_02:5]
•
Revenue: $286.1 million, up 15.5% year-over-year.

[0001193125-26-204995:8k_2_02:6]
•
GAAP gross margin of 39.5%; Non-GAAP gross margin of 43.0%; up 108 and 55 basis points year-over-year, respectively.

[0001193125-26-204995:8k_2_02:7]
•
Operating margin: GAAP operating margin of 2.2 %; non-GAAP operating margin of 6.9%.

[0001193125-26-204995:8k_2_02:8]
•
Net cash provided by operating activities of $12.7 million.

[0001193125-26-204995:8k_2_02:9]
•
GAAP diluted loss per share of $0.01; non-GAAP diluted earnings per share of $0.14.

[0001193125-26-204995:8k_2_02:10]
•
Cash and cash equivalents of $88.3 million.

[0001193125-26-204995:8k_2_02:11]
ADTRAN Holdings Chairman and Chief Executive Officer Tom Stanton stated, “We delivered solid first quarter results, with revenue increasing 15.5% year-over-year, and GAAP and non-GAAP operating margin rising 380 and 300 basis points from a year ago, respectively. These results reflect the continued strength of our core markets and the operating leverage we have been building.”

[0001193125-26-204995:8k_2_02:12]
Mr. Stanton added, “We believe that the demand drivers underpinning our business continue to build. In the US, broadband momentum continues with BEAD deployment funds now beginning to reach operators in a growing number of states. In Europe, high-risk vendor displacement continues to progress, reinforced by the European Commission's advancing legislation such as Cybersecurity Act 2.0. Also during the quarter, we introduced LiteWave800™, our first product purpose-built for intra-data center AI infrastructure, setting a new benchmark for power efficiency at 800G.”

[0001193125-26-204995:8k_2_02:13]
Business outlook1

[0001193125-26-204995:8k_2_02:14]
For the second quarter of 2026, the Company expects revenue to be within a range of $283.0 million to $303.0 million. Non-GAAP operating margin is expected to be within a range of 5.0% to 9.0%.

[0001193125-26-204995:8k_2_02:15]
1 Non-GAAP operating margin (which is calculated as non-GAAP operating income (loss) divided by revenue) is a non-GAAP financial measure. The Company has provided guidance for its second quarter 2026 non-GAAP operating margin. This measure excludes from the corresponding GAAP financial measure the effect of adjustments as described below. The Company has not provided a reconciliation of such non-GAAP guidance to guidance presented on a GAAP basis because it cannot predict and quantify without unreasonable effort all of the adjustments that may occur during the period due to the difficulty of predicting the timing and amounts of various items within a reasonable range. In particular, non-GAAP operating margin excludes certain items, such as acquisition related expenses, amortization and adjustments, stock-based compensation expense, deferred compensation adjustments, professional fees and other expenses, amortization of pension actuarial losses, the tax effect of these adjustments to net loss and purchases of property, plant and equipment, and developed technologies, that the Company is unable to quantitatively predict. Depending on the materiality of these items, they could have a significant impact on the Company's GAAP financial results.

[0001193125-26-204995:8k_2_02:16]
Conference call

[0001193125-26-204995:8k_2_02:17]
The Company will hold a conference call to discuss its first quarter 2026 results on Tuesday , May 5, 2026, at 7:30 a.m. Central Time (2:30 p.m. Central European Time). The Company will webcast this conference call at the events and presentations section of ADTRAN Holdings, Inc. Investor Relations website at https://events.q4inc.com/attendee/656998876  approximately 10 minutes before the start of the call, or you may dial 1-888-330-2391 (Toll-Free US) or 1-240-789-2702, and use Conference ID 8936454.

[0001193125-26-204995:8k_2_02:18]
An online replay of the Company’s conference call, as well as the transcript of the call, will be available on the Investor Relations site  https://investors.adtran.com/ shortly following the call and will remain available for at least 12 months. For more information, visit investors.adtran.com or email investor.relations@adtran.com.

[0001193125-26-204995:8k_2_02:19]
Upcoming conference schedule

[0001193125-26-204995:8k_2_02:20]
May 20, 2026: B. Riley Institutional Investor Conference - Marina Del Rey, CA

[0001193125-26-204995:8k_2_02:21]
About Adtran

[0001193125-26-204995:8k_2_02:22]
ADTRAN Holdings, Inc. (NASDAQ: ADTN and FSE: QH9) is the parent company of Adtran, Inc., a leading global provider of open, disaggregated networking and communications solutions that enable voice, data, video and internet communications across any network infrastructure. From the cloud edge to the subscriber edge, Adtran empowers communications service providers around the world to manage and scale services that connect people, places and things. Adtran solutions are used by service providers, private enterprises, government organizations and millions of individual users worldwide. ADTRAN Holdings, Inc. is also the majority shareholder of Adtran Networks SE, formerly ADVA Optical Networking SE (“Adtran Networks”). Find more at Adtran.com, LinkedIn and X.

[0001193125-26-204995:8k_2_02:23]
Cautionary note regarding forward-looking statements

[0001193125-26-204995:8k_2_02:24]
Explanation of use of non-GAAP financial measures

[0001193125-26-204995:8k_2_02:25]
Set forth in the tables below under the heading “Supplemental Information” are reconciliations of cost of revenue, gross profit, gross margin, operating expenses, operating income (loss), operating margin, other expense, net income (loss) inclusive of the non-controlling interest, net loss attributable to the Company, and loss per share - basic and diluted, attributable to the Company, and net cash provided by operating activities, in each case as reported based on generally accepted accounting principles in the United States (“GAAP”), to non-GAAP cost of revenue, non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income, non-GAAP operating margin, non-GAAP other expense, non-GAAP net income inclusive of the non-controlling interest, non-GAAP net income attributable to the Company, non-GAAP net earnings per share - basic and diluted, attributable to the Company, and free cash flow, respectively. Such non-GAAP measures exclude acquisition-related expenses, amortizations and adjustments (consisting of intangible amortization of backlog, developed technology, customer relationships, and trade names acquired in connection with business combinations), stock-based compensation expense, deferred compensation adjustments, professional fees and other expenses, amortization of pension actuarial losses, the tax effect of these adjustments to net loss and purchases of property, plant and equipment, and developed technologies. These measures are used by management in our ongoing planning and annual budgeting processes. Additionally, we believe the presentation of these non-GAAP measures, when combined with the presentation of the most directly comparable GAAP financial measure, is beneficial to the overall understanding of ongoing operating performance of the Company. These non-GAAP financial measures are not prepared in accordance with, or an alternative for, GAAP and therefore should not be considered in isolation or as a substitution for analysis of our results as reported under GAAP. Furthermore, our calculation of non-GAAP measures may not be comparable to similar measures calculated by other companies.

[0001193125-26-204995:8k_2_02:26]
Published by

[0001193125-26-204995:8k_2_02:27]
ADTRAN Holdings, Inc.

[0001193125-26-204995:8k_2_02:28]
www.adtran.com

[0001193125-26-204995:8k_2_02:29]
For media

[0001193125-26-204995:8k_2_02:30]
Gareth Spence

[0001193125-26-204995:8k_2_02:31]
+44 1904 699 358

[0001193125-26-204995:8k_2_02:32]
public.relations@adtran.com

[0001193125-26-204995:8k_2_02:33]
For investors

[0001193125-26-204995:8k_2_02:34]
Rob Fink

[0001193125-26-204995:8k_2_02:35]
investor.relations@adtran.com

[0001193125-26-204995:8k_2_02:36]
Condensed Consolidated Balance Sheets

[0001193125-26-204995:8k_2_02:37]
(Unaudited)

[0001193125-26-204995:8k_2_02:38]
(In thousands)

[0001193125-26-204995:8k_2_02:39]
|  | March 31, |  |  | December 31, |  |
|  | 2026 |  |  | 2025 |  |
| Assets |  |  |  |  |  |
| Current Assets |  |  |  |  |  |
| Cash and cash equivalents | $ | 88,270 |  |  | $ | 95,696 |  |
| Accounts receivable, net |  | 215,473 |  |  |  | 210,687 |  |
| Other receivables |  | 10,292 |  |  |  | 7,046 |  |
| Inventory, net |  | 209,003 |  |  |  | 215,736 |  |
| Income tax receivable |  | 2,971 |  |  |  | 3,667 |  |
| Prepaid expenses and other current assets |  | 62,492 |  |  |  | 55,317 |  |
| Short-term investments - deferred compensation |  | 33,813 |  |  |  | 35,174 |  |
| Assets held for sale |  | 11,901 |  |  |  | 11,901 |  |
| Total Current Assets |  | 634,215 |  |  |  | 635,224 |  |
| Property, plant and equipment, net |  | 123,849 |  |  |  | 124,384 |  |
| Goodwill |  | 59,003 |  |  |  | 59,983 |  |
| Intangible assets, net |  | 281,280 |  |  |  | 294,047 |  |
| Deferred tax assets |  | 16,223 |  |  |  | 16,481 |  |
| Other non-current assets |  | 69,560 |  |  |  | 73,352 |  |
| Long-term investments |  | 937 |  |  |  | 1,022 |  |
| Total Assets | $ | 1,185,067 |  |  | $ | 1,204,493 |  |
| Liabilities, Redeemable Non-Controlling Interest and Equity |  |  |  |  |  |
| Current Liabilities |  |  |  |  |  |
| Accounts payable | $ | 170,605 |  |  | $ | 167,337 |  |
| Unearned revenue |  | 90,752 |  |  |  | 87,541 |  |
| Accrued expenses and other liabilities |  | 31,736 |  |  |  | 33,690 |  |
| Accrued wages and benefits |  | 23,449 |  |  |  | 32,203 |  |
| Deferred compensation liability |  | 37,051 |  |  |  | 37,447 |  |
| Income tax payable |  | 5,613 |  |  |  | 3,642 |  |
| Total Current Liabilities |  | 359,206 |  |  |  | 361,860 |  |
| Non-current revolving credit agreement |  | 25,000 |  |  |  | 25,000 |  |
| Non-current convertible senior notes, net of debt issuance costs |  | 193,425 |  |  |  | 193,038 |  |
| Deferred tax liabilities |  | 26,776 |  |  |  | 27,453 |  |
| Non-current unearned revenue |  | 26,227 |  |  |  | 27,143 |  |
| Non-current pension liability |  | 6,305 |  |  |  | 6,277 |  |
| Non-current lease obligations |  | 24,940 |  |  |  | 27,000 |  |
| Other non-current liabilities |  | 16,646 |  |  |  | 17,564 |  |
| Total Liabilities |  | 678,525 |  |  |  | 685,335 |  |
| Redeemable Non-Controlling Interest |  | 369,017 |  |  |  | 373,328 |  |
| Equity |  |  |  |  |  |
| Common stock |  | 808 |  |  |  | 802 |  |
| Additional paid-in capital |  | 803,031 |  |  |  | 801,269 |  |
| Accumulated other comprehensive income |  | 70,046 |  |  |  | 78,877 |  |
| Retained deficit |  | (731,345 | ) |  |  | (730,010 | ) |
| Treasury stock |  | (5,015 | ) |  |  | (5,108 | ) |
| Total Equity |  | 137,525 |  |  |  | 145,830 |  |
| Total Liabilities, Redeemable Non-Controlling Interest and Equity | $ | 1,185,067 |  |  | $ | 1,204,493 |  |

[0001193125-26-204995:8k_2_02:40]
Condensed Consolidated Statements of Loss

[0001193125-26-204995:8k_2_02:41]
(Unaudited)

[0001193125-26-204995:8k_2_02:42]
(In thousands, except per share amounts)

[0001193125-26-204995:8k_2_02:43]
|  |  | Three Months Ended |  |  |  |
|  |  | March 31, |  |  |  |
|  |  | 2026 |  |  | 2025 |  |  |  |
| Revenue |  |  |  |  |  |  |  |  |
| Network Solutions |  | $ | 237,941 |  |  | $ | 202,217 |  |  |  |
| Services & Support |  |  | 48,145 |  |  |  | 45,527 |  |  |  |
| Total Revenue |  |  | 286,086 |  |  |  | 247,744 |  |  |  |
| Cost of Revenue |  |  |  |  |  |  |  |  |
| Network Solutions |  |  | 154,648 |  |  |  | 134,241 |  |  |  |
| Services & Support |  |  | 18,450 |  |  |  | 18,327 |  |  |  |
| Total Cost of Revenue |  |  | 173,098 |  |  |  | 152,568 |  |  |  |
| Gross Profit |  |  | 112,988 |  |  |  | 95,176 |  |  |  |
| Selling, general and administrative expenses |  |  | 55,836 |  |  |  | 50,285 |  |  |  |
| Research and development expenses |  |  | 50,777 |  |  |  | 48,859 |  |  |  |
| Operating Income (Loss) |  |  | 6,375 |  |  |  | (3,968 | ) |  |  |
| Interest and dividend income |  |  | 300 |  |  |  | 126 |  |  |  |
| Interest expense |  |  | (4,241 | ) |  |  | (4,761 | ) |  |  |
| Net investment loss |  |  | (850 | ) |  |  | (1,686 | ) |  |  |
| Other income, net |  |  | 1,263 |  |  |  | 944 |  |  |  |
| Income (Loss) Before Income Taxes |  |  | 2,847 |  |  |  | (9,345 | ) |  |  |
| Income tax (expense) benefit |  |  | (1,917 | ) |  |  | 397 |  |  |  |
| Net Income (Loss) |  | $ | 930 |  |  | $ | (8,948 | ) |  |  |
| Less: Net Income attributable to non-controlling interest (1) |  |  | 2,251 |  |  |  | 2,319 |  |  |  |
| Net Loss attributable to ADTRAN Holdings, Inc. |  | $ | (1,321 | ) |  | $ | (11,267 | ) |  |  |
| Weighted average shares outstanding – basic |  |  | 80,321 |  |  |  | 79,534 |  |  |  |
| Weighted average shares outstanding – diluted |  |  | 80,321 |  |  |  | 79,534 |  |  |  |
| Loss per common share attributable to ADTRAN Holdings, Inc. – basic (2) |  | $ | (0.01 | ) |  | $ | (0.14 | ) |  |  |
| Loss per common share attributable to ADTRAN Holdings, Inc. – diluted (2) |  | $ | (0.01 | ) |  | $ | (0.14 | ) |  |  |

[0001193125-26-204995:8k_2_02:44]
(1) For the three months ended March 31, 2026 and 2025 we accrued $2.2 million and $2.4 million, respectively, of net income attributable to non-controlling interest, representing the recurring cash compensation earned by non-controlling interest shareholders post-DPLTA.

[0001193125-26-204995:8k_2_02:45]
(2) Loss per common share attributable to ADTRAN Holdings, Inc. - basic and diluted - reflects a $0.3 million and a $(3) thousand effect  of redemption of RNCI for the three months ended March 31, 2026 and 2025.

[0001193125-26-204995:8k_2_02:46]
Condensed Consolidated Statements of Cash Flows

[0001193125-26-204995:8k_2_02:47]
(Unaudited)

[0001193125-26-204995:8k_2_02:48]
(In thousands)

[0001193125-26-204995:8k_2_02:49]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
|  |  | 2026 |  |  | 2025 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |
| Net income (loss) |  | $ | 930 |  |  | $ | (8,948 | ) |
| Adjustments to reconcile net income (loss) to net cash provided by operating activities: |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 24,916 |  |  |  | 21,596 |  |
| Amortization of debt issuance cost |  |  | 374 |  |  |  | 320 |  |
| Amortization of convertible notes issuance costs |  |  | 386 |  |  |  | — |  |
| Loss on investments, net |  |  | 822 |  |  |  | 1,631 |  |
| Net loss on disposal of property, plant and equipment |  |  | 60 |  |  |  | 13 |  |
| Stock-based compensation expense |  |  | 1,819 |  |  |  | 3,210 |  |
| Deferred income taxes |  |  | (244 | ) |  |  | (157 | ) |
| Inventory reserves |  |  | 143 |  |  |  | 3,339 |  |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |
| Accounts receivable, net |  |  | (6,192 | ) |  |  | 16,011 |  |
| Other receivables |  |  | (3,312 | ) |  |  | (1,141 | ) |
| Income taxes receivable |  |  | 896 |  |  |  | (690 | ) |
| Inventory |  |  | 4,671 |  |  |  | 10,345 |  |
| Prepaid expenses, other current assets and other assets |  |  | (5,558 | ) |  |  | 1,504 |  |
| Accounts payable |  |  | 366 |  |  |  | (4,222 | ) |
| Accrued expenses and other liabilities |  |  | (9,197 | ) |  |  | 352 |  |
| Income taxes payable |  |  | 1,790 |  |  |  | 18 |  |
| Net cash provided by operating activities |  |  | 12,670 |  |  |  | 43,181 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (7,505 | ) |  |  | (7,399 | ) |
| Purchases of intangibles - developed technology |  |  | (8,435 | ) |  |  | (11,296 | ) |
| Proceeds from sales and maturities of available-for-sale investments |  |  | 736 |  |  |  | 660 |  |
| Purchases of available-for-sale investments |  |  | (75 | ) |  |  | (170 | ) |
| Payments for beneficial interests in securitized accounts receivable |  |  | (574 | ) |  |  | (133 | ) |
| Net cash used in investing activities |  |  | (15,853 | ) |  |  | (18,338 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |
| Tax withholdings related to stock-based compensation settlements |  |  | (1,645 | ) |  |  | (420 | ) |
| Proceeds from stock option exercises |  |  | 1,369 |  |  |  | 756 |  |
| Payments on financing agreement |  |  | (1,400 | ) |  |  | — |  |
| Redemption of redeemable non-controlling interest |  |  | (8 | ) |  |  | (12 | ) |
| Net cash (used in) provided by financing activities |  |  | (1,684 | ) |  |  | 324 |  |
| Net (decrease) increase in cash and cash equivalents |  |  | (4,867 | ) |  |  | 25,167 |  |
| Effect of exchange rate changes |  |  | (2,559 | ) |  |  | 133 |  |
| Cash and cash equivalents, beginning of period |  |  | 95,696 |  |  |  | 76,021 |  |
| Cash and cash equivalents, end of period |  | $ | 88,270 |  |  | $ | 101,321 |  |
| Supplemental disclosure of cash financing activities: |  |  |  |  |  |  |
| Cash paid for interest expense |  | $ | 4,451 |  |  | $ | 4,129 |  |
| Cash (refund) paid for income taxes, net |  | $ | (814 | ) |  | $ | 2,367 |  |
| Cash used in operating activities related to operating leases |  | $ | 2,425 |  |  | $ | 2,696 |  |
| Supplemental disclosure of non-cash investing and financing activities: |  |  |  |  |  |  |
| Redemption of redeemable non-controlling interest |  | $ | 301 |  |  | $ | (3 | ) |
| Right-of-use assets obtained in exchange for lease obligations |  | $ | 183 |  |  | $ | 1,893 |  |
| Purchases of property, plant and equipment included in accounts payable |  | $ | 1,296 |  |  | $ | 1,162 |  |

[0001193125-26-204995:8k_2_02:50]
Supplemental Information

[0001193125-26-204995:8k_2_02:51]
Reconciliation of Cost of Revenue, Gross Profit and Gross Margin to

[0001193125-26-204995:8k_2_02:52]
Non-GAAP Cost of Revenue, Non-GAAP Gross Profit and Non-GAAP Gross Margin

[0001193125-26-204995:8k_2_02:53]
(Unaudited)

[0001193125-26-204995:8k_2_02:54]
(In thousands)

[0001193125-26-204995:8k_2_02:55]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |  | December 31, |  |  | March 31, |  |
|  |  | 2026 |  |  | 2025 |  |  | 2025 |  |
| Total Revenue |  | $ | 286,086 |  |  | $ | 291,560 |  |  | $ | 247,744 |  |
| Cost of Revenue |  | $ | 173,098 |  |  | $ | 177,831 |  |  | $ | 152,568 |  |
| Acquisition-related expenses, amortizations and adjustments (1) |  |  | (10,021 | ) |  |  | (9,964 | ) |  |  | (9,831 | ) |
| Stock-based compensation expense |  |  | (140 | ) |  |  | (232 | ) |  |  | (267 | ) |
| Non-GAAP Cost of Revenue |  | $ | 162,937 |  |  | $ | 167,635 |  |  | $ | 142,470 |  |
| Gross Profit |  | $ | 112,988 |  |  | $ | 113,729 |  |  | $ | 95,176 |  |
| Non-GAAP Gross Profit |  | $ | 123,149 |  |  | $ | 123,925 |  |  | $ | 105,274 |  |
| Gross Margin |  |  | 39.5 | % |  |  | 39.0 | % |  |  | 38.4 | % |
| Non-GAAP Gross Margin |  |  | 43.0 | % |  |  | 42.5 | % |  |  | 42.5 | % |

[0001193125-26-204995:8k_2_02:56]
(1) Includes intangible amortization of backlog, developed technology, customer relationships, and trade names acquired in connection with business combinations. We incur charges relating to the amortization of intangible assets and exclude these charges for purposes of calculating our non-GAAP measures. Such charges are significantly impacted by the timing and magnitude of our acquisitions. We exclude these charges for the purpose of calculating our non-GAAP measures, primarily because they are noncash expenses and our internal benchmarking analyses evidence that many industry participants and peers present non-GAAP financial measures excluding intangible asset amortization. Although this does not directly affect our cash position, the loss in value of intangible assets over time can have a material impact on the equivalent GAAP earnings measure.

[0001193125-26-204995:8k_2_02:57]
Supplemental Information

[0001193125-26-204995:8k_2_02:58]
Reconciliation of Operating Expenses to Non-GAAP Operating Expenses

[0001193125-26-204995:8k_2_02:59]
(Unaudited)

[0001193125-26-204995:8k_2_02:60]
(In thousands)

[0001193125-26-204995:8k_2_02:61]
|  |  | Three Months Ended |  |  |
|  |  | March 31, |  |  | December 31, |  |  | March 31, |  |  |
|  |  | 2026 |  |  | 2025 |  |  | 2025 |  |  |
| Operating Expenses |  | $ | 106,613 |  |  | $ | 109,251 |  |  | $ | 99,144 |  |  |
| Acquisition-related expenses, amortizations and adjustments (1) |  |  | (1,641 | ) | (2) |  | (1,805 | ) | (6) |  | (2,249 | ) | (9) |
| Stock-based compensation expense |  |  | (1,679 | ) | (3) |  | (1,092 | ) | (7) |  | (2,943 | ) | (10) |
| Deferred compensation adjustments (4) |  |  | 11 |  |  |  | 781 |  |  |  | 1,547 |  |  |
| Professional fees and other expenses |  |  | (30 | ) | (5) |  | (1,988 | ) | (8) |  | — |  |  |
| Non-GAAP Operating Expenses |  | $ | 103,274 |  |  | $ | 105,147 |  |  | $ | 95,499 |  |  |

[0001193125-26-204995:8k_2_02:62]
(1) We incur charges relating to the amortization of intangible assets and exclude these charges for purposes of calculating our non-GAAP measures. Such charges are significantly impacted by the timing and magnitude of our acquisitions. We exclude these charges for the purpose of calculating our non-GAAP measures, primarily because they are noncash expenses and our internal benchmarking analyses evidence that many industry participants and peers present non-GAAP financial measures excluding intangible asset amortization. Although this does not directly affect our cash position, the loss in value of intangible assets over time can have a material impact on the equivalent GAAP earnings measure.

[0001193125-26-204995:8k_2_02:63]
(2) Includes intangible amortization of developed technology, customer relationships, and trade names acquired in connection with business combinations, of which $1.4 million is included in selling, general and administrative expenses and $0.2 million is included in research and development expenses on the condensed consolidated statements of loss.

[0001193125-26-204995:8k_2_02:64]
(3) $1.2 million is included in selling, general and administrative expenses and $0.5 million is included in research and development expenses on the condensed consolidated statements of loss.

[0001193125-26-204995:8k_2_02:65]
(4) Includes non-cash change in fair value of equity investments held in the ADTRAN Holdings, Inc. Deferred Compensation Program for Employees, all of which is included in selling, general and administrative expenses on the condensed consolidated statement of loss.

[0001193125-26-204995:8k_2_02:66]
(5) Included in selling, general and administrative expenses on the condensed consolidated statements of loss. Includes one-time professional fees and business expenses.

[0001193125-26-204995:8k_2_02:67]
(6) Includes intangible amortization of developed technology, customer relationships, and trade names acquired in connection with business combinations, of which $1.4 million is included in selling, general and administrative expenses and $0.4 million is included in research and development expenses on the condensed consolidated statements of loss.

[0001193125-26-204995:8k_2_02:68]
(7) $0.4 million is included in selling, general and administrative expenses and $0.7 million is included in research and development expenses on the condensed consolidated statements of loss.

[0001193125-26-204995:8k_2_02:69]
(8) $2.0 million is included in selling, general and administrative expenses on the condensed consolidated statements of loss. Includes professional fees related to an internal investigation and a related SEC inquiry, a provision in connection with a potential 401(k) plan corrective action, and fees relating to other one-time professional fees and business expenses.

[0001193125-26-204995:8k_2_02:70]
(9) Includes $2.2 million of intangible amortization of developed technology, customer relationships, and trade names acquired in connection with business

[0001193125-26-204995:8k_2_02:71]
combinations.

[0001193125-26-204995:8k_2_02:72]
(10) $2.0 million is included in selling, general and administrative expenses and $0.9 million is included in research and development expenses on the condensed

[0001193125-26-204995:8k_2_02:73]
consolidated statements of loss.

[0001193125-26-204995:8k_2_02:74]
Supplemental Information

[0001193125-26-204995:8k_2_02:75]
Reconciliation of Operating Income (Loss) and Operating Margin to Non-GAAP Operating Income

[0001193125-26-204995:8k_2_02:76]
and Non-GAAP Operating Margin

[0001193125-26-204995:8k_2_02:77]
(Unaudited)

[0001193125-26-204995:8k_2_02:78]
(In thousands)

[0001193125-26-204995:8k_2_02:79]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |  | December 31, |  |  | March 31, |  |
|  |  | 2026 |  |  | 2025 |  |  | 2025 |  |
| Total Revenue |  | $ | 286,086 |  |  | $ | 291,560 |  |  | $ | 247,744 |  |
| Operating Income (Loss) |  | $ | 6,375 |  |  | $ | 4,478 |  |  | $ | (3,968 | ) |
| Acquisition related expenses, amortizations and adjustments (1) |  |  | 11,662 |  |  |  | 11,769 |  |  |  | 12,080 |  |
| Stock-based compensation expense |  |  | 1,819 |  |  |  | 1,324 |  |  |  | 3,210 |  |
| Deferred compensation adjustments (2) |  |  | (11 | ) |  |  | (781 | ) |  |  | (1,547 | ) |
| Professional fees and other expenses (3) |  |  | 30 |  |  |  | 1,988 |  |  |  | — |  |
| Non-GAAP Operating Income |  | $ | 19,875 |  |  | $ | 18,778 |  |  | $ | 9,775 |  |
| Operating Margin |  |  | 2.2 | % |  |  | 1.5 | % |  |  | -1.6 | % |
| Non-GAAP Operating Margin |  |  | 6.9 | % |  |  | 6.4 | % |  |  | 3.9 | % |

[0001193125-26-204995:8k_2_02:80]
(1) Includes intangible amortization of backlog, developed technology, customer relationships, and trade names acquired in connection with business combinations. We incur charges relating to the amortization of intangible assets and exclude these charges for purposes of calculating our non-GAAP measures. Such charges are significantly impacted by the timing and magnitude of our acquisitions. We exclude these charges for the purpose of calculating our non-GAAP measures, primarily because they are noncash expenses and our internal benchmarking analyses evidence that many industry participants and peers present non-GAAP financial measures excluding intangible asset amortization. Although this does not directly affect our cash position, the loss in value of intangible assets over time can have a material impact on the equivalent GAAP earnings measure.

[0001193125-26-204995:8k_2_02:81]
(2) Includes non-cash change in fair value of equity investments held in the ADTRAN Holdings, Inc. Deferred Compensation Program for certain employees, all of which is included in selling, general and administrative expenses on the condensed consolidated statement of loss.

[0001193125-26-204995:8k_2_02:82]
(3) Includes professional fees related to an internal investigation and a related SEC inquiry, a provision in connection with a potential 401(k) plan corrective action,  employee exit costs and fees relating to other one-time professional fees and business expenses.

[0001193125-26-204995:8k_2_02:83]
Supplemental Information

[0001193125-26-204995:8k_2_02:84]
Reconciliation of Other Expense to Non-GAAP Other Expense

[0001193125-26-204995:8k_2_02:85]
(Unaudited)

[0001193125-26-204995:8k_2_02:86]
(In thousands)

[0001193125-26-204995:8k_2_02:87]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |  | December 31, |  |  | March 31, |  |
|  |  | 2026 |  |  | 2025 |  |  | 2025 |  |
| Interest and dividend income |  | $ | 300 |  |  | $ | 1,703 |  |  | $ | 126 |  |
| Interest expense |  |  | (4,241 | ) |  |  | (4,520 | ) |  |  | (4,761 | ) |
| Net investment loss |  |  | (850 | ) |  |  | (574 | ) |  |  | (1,686 | ) |
| Other income, net |  |  | 1,263 |  |  |  | 805 |  |  |  | 944 |  |
| Total Other Expense |  | $ | (3,528 | ) |  | $ | (2,586 | ) |  | $ | (5,377 | ) |
| Deferred compensation adjustments (1) |  |  | 1,012 |  |  |  | 601 |  |  |  | 1,649 |  |
| Pension expense (2) |  |  | (20 | ) |  |  | 12 |  |  |  | 11 |  |
| Non-GAAP Other Expense |  | $ | (2,536 | ) |  | $ | (1,973 | ) |  | $ | (3,717 | ) |

[0001193125-26-204995:8k_2_02:88]
(1) Includes non-cash change in fair value of equity investments held in the ADTRAN Holdings, Inc. Deferred Compensation Program for Employees.

[0001193125-26-204995:8k_2_02:89]
(2) Includes amortization of actuarial losses related to the Company's pension plan for employees in certain foreign countries.

[0001193125-26-204995:8k_2_02:90]
Supplemental Information

[0001193125-26-204995:8k_2_02:91]
Reconciliation of Net Income (Loss) inclusive of Non-Controlling Interest to

[0001193125-26-204995:8k_2_02:92]
Non-GAAP Net Income inclusive of Non-Controlling Interest

[0001193125-26-204995:8k_2_02:93]
(Unaudited)

[0001193125-26-204995:8k_2_02:94]
and

[0001193125-26-204995:8k_2_02:95]
Reconciliation of Net Loss attributable to ADTRAN Holdings, Inc. and

[0001193125-26-204995:8k_2_02:96]
Loss per Common Share attributable to ADTRAN Holdings, Inc. – Basic and Diluted to

[0001193125-26-204995:8k_2_02:97]
Non-GAAP Net Income attributable to ADTRAN Holdings, Inc. and

[0001193125-26-204995:8k_2_02:98]
Non-GAAP Earnings per Common Share attributable to ADTRAN Holdings, Inc. – Basic and Diluted

[0001193125-26-204995:8k_2_02:99]
(Unaudited)

[0001193125-26-204995:8k_2_02:100]
(In thousands, except per share amounts)

[0001193125-26-204995:8k_2_02:101]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |  | December 31, |  |  | March 31, |  |
|  |  | 2026 |  |  | 2025 |  |  | 2025 |  |
| Net Loss attributable to ADTRAN Holdings, Inc. common stockholders |  | $ | (1,020 | ) |  | $ | (1,521 | ) |  | $ | (11,270 | ) |
| Effect of redemption of RNCI (1) |  |  | (301 | ) |  |  | (2,075 | ) |  |  | 3 |  |
| Net Loss attributable to ADTRAN Holdings, Inc. |  | $ | (1,321 | ) |  | $ | (3,596 | ) |  | $ | (11,267 | ) |
| Net Income attributable to non-controlling interest (2) |  |  | 2,251 |  |  |  | 2,316 |  |  |  | 2,319 |  |
| Net Income (Loss) inclusive of non-controlling interest |  | $ | 930 |  |  | $ | (1,280 | ) |  | $ | (8,948 | ) |
| Acquisition related expenses, amortizations and adjustments (3) |  |  | 11,662 |  |  |  | 11,769 |  |  |  | 12,080 |  |
| Stock-based compensation expense |  |  | 1,819 |  |  |  | 1,324 |  |  |  | 3,210 |  |
| Deferred compensation adjustments (4) |  |  | 1,001 |  |  |  | (180 | ) |  |  | 102 |  |
| Pension adjustments (5) |  |  | (20 | ) |  |  | 12 |  |  |  | 11 |  |
| Professional fees and other expenses (6) |  |  | 30 |  |  |  | 1,988 |  |  |  | — |  |
| Tax effect of adjustments to net loss |  |  | (2,509 | ) |  |  | (628 | ) |  |  | (1,980 | ) |
| Non-GAAP Net Income inclusive of non-controlling interest |  | $ | 12,913 |  |  | $ | 13,005 |  |  | $ | 4,475 |  |
| Net Income attributable to non-controlling interest (2) |  |  | 2,251 |  |  |  | 2,316 |  |  |  | 2,319 |  |
| Non-GAAP Net Income attributable to ADTRAN Holdings, Inc. |  | $ | 10,662 |  |  | $ | 10,689 |  |  | $ | 2,156 |  |
| Effect of redemption of RNCI (1) |  |  | 301 |  |  |  | 2,075 |  |  |  | (3 | ) |
| Non-GAAP Net Income attributable to ADTRAN Holdings, Inc. common stockholders |  | $ | 10,963 |  |  | $ | 12,764 |  |  | $ | 2,153 |  |
| Weighted average shares outstanding – basic |  |  | 80,321 |  |  |  | 79,877 |  |  |  | 79,534 |  |
| Weighted average shares outstanding – diluted |  |  | 80,321 |  |  |  | 79,877 |  |  |  | 79,534 |  |
| Loss per common share attributable to ADTRAN Holdings, Inc. – basic |  | $ | (0.01 | ) |  | $ | (0.02 | ) |  | $ | (0.14 | ) |
| Loss per common share attributable to ADTRAN Holdings, Inc. – diluted |  | $ | (0.01 | ) |  | $ | (0.02 | ) |  | $ | (0.14 | ) |
| Non-GAAP Earnings per common share attributable to ADTRAN – basic |  | $ | 0.14 |  |  | $ | 0.16 |  |  | $ | 0.03 |  |
| Non-GAAP Earnings per common share attributable to ADTRAN – diluted |  | $ | 0.14 |  |  | $ | 0.16 |  |  | $ | 0.03 |  |

[0001193125-26-204995:8k_2_02:102]
(1) Loss per common share attributable to ADTRAN Holdings, Inc. - basic and diluted - reflects a $0.3 million and a $(3) thousand effect  of redemption of RNCI for the three months ended March 31, 2026 and 2025.

[0001193125-26-204995:8k_2_02:103]
(2) Represents the non-controlling interest portion of the Company's ownership of Adtran Networks pre-DPLTA and the annual recurring compensation earned by redeemable non-controlling interests and accrued by the Company post-DPLTA.

[0001193125-26-204995:8k_2_02:104]
(3) We incur charges relating to the amortization of intangible assets and exclude these charges for purposes of calculating our non-GAAP measures. Such charges are significantly impacted by the timing and magnitude of our acquisitions. We exclude these charges for the purpose of calculating our non-GAAP measures, primarily because they are noncash expenses and our internal benchmarking analyses evidence that many industry participants and peers present non-GAAP financial measures excluding intangible asset amortization. Although this does not directly affect our cash position, the loss in value of intangible assets over time can have a material impact on the equivalent GAAP earnings measure.

[0001193125-26-204995:8k_2_02:105]
(4) Includes non-cash change in fair value of equity investments held in deferred compensation plans offered to certain employees.

[0001193125-26-204995:8k_2_02:106]
(5) Includes amortization of actuarial losses related to the Company's pension plan for employees in certain foreign countries.

[0001193125-26-204995:8k_2_02:107]
(6) Includes professional fees related to an internal investigation and a related SEC inquiry, a provision in connection with a potential 401(k) plan corrective action and fees relating to other one-time professional fees and business expenses.

[0001193125-26-204995:8k_2_02:108]
Supplemental Information

[0001193125-26-204995:8k_2_02:109]
Reconciliation of Net Cash Provided By Operating Activities to Free Cash Flow

[0001193125-26-204995:8k_2_02:110]
(Unaudited)

[0001193125-26-204995:8k_2_02:111]
(In thousands)

[0001193125-26-204995:8k_2_02:112]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |  | December 31, |  |  | March 31, |  |
|  |  | 2026 |  |  | 2025 |  |  | 2025 |  |
| Net cash provided by operating activities |  | $ | 12,670 |  |  | $ | 42,238 |  |  | $ | 43,181 |  |
| Purchases of property, plant and equipment and developed technologies (1) |  |  | (15,940 | ) |  |  | (19,708 | ) |  |  | (18,695 | ) |
| Free cash flow (Non-GAAP) |  | $ | (3,270 | ) |  | $ | 22,530 |  |  | $ | 24,486 |  |

[0001193125-26-204995:8k_2_02:113]
(1) Purchases related to capital expenditures and developed technologies.
