# ADTN note change history — 0001193125-25-264157 → 0001193125-26-205276


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2026-05-05):
[0001193125-26-205276:note_history:1]
As disclosed in Amendment No. 1 to our Annual Report on Form 10-K for the fiscal year ended December 31, 2024, filed with the SEC on May 20, 2025, we identified errors in our previously issued financial statements related to the historical accounting for certain inventory and cost of goods sold transactions (“Adjustment”). The affected periods included the annual periods ended December 31, 2023 and 2024 and the interim periods ended March 31, 2024, June 30, 2024 and September 30, 2024. In connection with the identification of the Adjustment, the Audit Committee oversaw an internal investigation into the circumstances surrounding the Adjustment and its impact on the Company’s historical financial statements. Based on the findings of the internal investigation, it was determined that the underlying errors giving rise to the Adjustment were not properly addressed in the Company’s previously filed financial statements as of and for the years ended December 31, 2024 and 2023 and were not communicated to the Audit Committee or the independent auditors prior to the filing of the initial Annual Report on Form 10-K for the year ended December 31, 2024. The Company has taken certain remedial actions to address the material weaknesses in its internal controls associated with these findings. On August 4, 2025, the Company received a letter from the Atlanta regional office of the SEC in connection with a non-public, fact-finding inquiry, requesting that we voluntarily provide information regarding the internal investigation. The Company is cooperating in response to the SEC’s inquiry and cannot predict the timing or outcome of the inquiry.

- changed (2026-05-05):
[0001193125-26-205276:note_history:2]
In addition to such Legal Matters, the Company is a party to appraisal proceedings relating to the DPLTA which were originally filed with the Landgericht Meiningen (Meiningen District Court) on February 3, 2023. The DPLTA provides that Adtran Networks shareholders (other than the Company) be offered, at their election, (i) to put their Adtran Networks shares to the Company in exchange for compensation in cash of €17.21 per share, plus guaranteed interest or (ii) to remain Adtran Networks shareholders and receive recurring cash compensation of €0.52 per share for each full fiscal year of Adtran Networks. The appraisal proceedings, which were initiated by certain minority shareholders of Adtran Networks, challenge the adequacy of both forms of compensation. While the Company believes that the compensation offered in connection with the DPLTA is fair, it notes that German courts often adjudicate increases of the cash compensation to plaintiffs in varying amounts in connection with German appraisal proceedings. Therefore, the Company cannot rule out that the first instance court or an appellate court may increase the cash compensation owed to the minority Adtran Networks shareholders. Given the stage of the appraisal proceedings, the Company is currently unable to predict the likely outcome or estimate the potential financial impact, if any, of the appraisal proceedings. If a ruling were to occur and be upheld upon appeal that required the Company to pay significant additional cash compensation to the Adtran Networks minority shareholders, there exists the possibility of a material adverse effect on our financial position and results of operations for the period in which the ruling occurs or future periods.
  (was, 2025-11-04, similarity 0.9909):
[0001193125-25-264157:note_history:2]
In addition to such Legal Matters, the Company is a party to appraisal proceedings relating to the DPLTA which were originally filed with the Landgericht Meiningen (Meiningen Regional Court) on February 3, 2023. The DPLTA provides that Adtran Networks shareholders (other than the Company) be offered, at their election, (i) to put their Adtran Networks shares to the Company in exchange for compensation in cash of €17.21 per share, plus guaranteed interest or (ii) to remain Adtran Networks shareholders and receive recurring cash compensation of €0.52 per share for each full fiscal year of Adtran Networks. The appraisal proceedings, which were initiated by certain minority shareholders of Adtran Networks, challenge the adequacy of both forms of compensation. While the Company believes that the compensation offered in connection with the DPLTA is fair, it notes that German courts often adjudicate increases of the cash compensation to plaintiffs in varying amounts in connection with German appraisal proceedings. Therefore, the Company cannot rule out that the court or an appellate court may increase the cash compensation owed to the minority Adtran Networks shareholders. Given the stage of the appraisal proceedings, the Company is currently unable to predict the likely outcome or estimate the potential financial impact, if any, of the appraisal proceedings. If a ruling were to occur and be upheld upon appeal that required the Company to pay significant additional cash compensation to the Adtran Networks minority shareholders, there exists the possibility of a material adverse effect on our financial position and results of operations for the period in which the ruling occurs or future periods.

- changed (2026-05-05):
[0001193125-26-205276:note_history:3]
Pursuant to the terms of the DPLTA, each Adtran Networks shareholder (other than the Company) has received an offer to elect either (1) to remain an Adtran Networks shareholder and receive from us an Annual Recurring Compensation payment, or (2) to receive Exit Compensation plus guaranteed interest. The guaranteed interest under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid. The guaranteed interest rate is 5.0% plus a variable component (according to the German Civil Code) that was 1.27% as of March 31, 2026. Assuming all the minority holders of currently outstanding Adtran Networks shares were to elect the second option, the Company would be obligated to make aggregate Exit Compensation payments, including guaranteed interest, of approximately €304.4 million or approximately $351.7 million, based on an exchange rate as of March 31, 2026, and reflecting interest accrued through March 31, 2026, during the pendency of the appraisal proceedings discussed below. Shareholders electing the first option of Annual Recurring Compensation may later elect the second option. The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that were initiated in 2023 in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger). Following the court's decision on a procedural matter in the DPLTA appraisal proceedings on July 14, 2025, the proceeding for the trial on the merits of the DPLTA has recommenced. It is expected to take a minimum of 12 months for
  (was, 2025-11-04, similarity 0.9128):
[0001193125-25-264157:note_history:3]
Pursuant to the terms of the DPLTA, each Adtran Networks shareholder (other than the Company) has received an offer to elect either (1) to remain an Adtran Networks shareholder and receive from us an Annual Recurring Compensation payment, or (2) to receive Exit Compensation plus guaranteed interest. The guaranteed interest under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid. The guaranteed interest rate is 5.0% plus a variable component (according to the German Civil Code) that was 1.27% as of September 30, 2025. Assuming all the minority holders of currently outstanding Adtran Networks shares were to elect the second option, the Company would be obligated to make aggregate Exit Compensation payments, including guaranteed interest, of approximately €322.7 million or $378.7 million, based on an exchange rate as of September 30, 2025, and reflecting interest accrued through September 30, 2025, during the pendency of the appraisal proceedings discussed below. Shareholders electing the first option of Annual Recurring Compensation may later elect the second option. The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that were initiated in 2023 in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the

- changed (2026-05-05):
[0001193125-26-205276:note_history:4]
a ruling of the court on the merits and such ruling will most likely be appealed, which would be expected to take an additional 12-24 months to be resolved. Accordingly, the Company does not expect a final decision on the DPLTA appraisal proceedings to be rendered and published prior to 2027, and most likely not until 2028 or beyond.
  (was, 2025-11-04, similarity 0.7173):
[0001193125-25-264157:note_history:4]
Federal Gazette (Bundesanzeiger). Following the court's decision on a procedural matter in the DPLTA appraisal proceedings on July 14, 2025, the proceeding for the trial on the merits of the DPLTA has recommenced. It is expected to take a minimum of 12 months for a ruling of the court on the merits and such ruling will most likely be appealed, which would be expected to take an additional 12-24 months to be resolved. Accordingly, the Company does not expect a final decision on the DPLTA appraisal proceedings to be rendered and published prior to 2027, and most likely not until 2028 or beyond.

- changed (2026-05-05):
[0001193125-26-205276:note_history:5]
Our obligation to pay Annual Recurring Compensation under the DPLTA is a continuing payment obligation, which will amount to approximately €7.8 million (or $9.0 million based on the current exchange rate) per year assuming none of the minority Adtran Networks shareholders were to elect Exit Compensation. The foregoing amounts do not reflect any potential increase in payment obligations that we may have depending on the outcome of ongoing appraisal proceedings in Germany. The Annual Recurring Compensation is due on the third banking day following the ordinary general shareholders’ meeting of Adtran Networks for the respective preceding fiscal year (but in any event within eight months following expiration of the fiscal year). With respect to the 2025 fiscal year, Adtran Networks’ ordinary general shareholders meeting is scheduled for the second quarter of 2026, and the Annual Recurring Compensation will be due on the third banking day following the meeting. During the three months ended March 31, 2026 and 2025, we accrued $2.2 million and $2.4 million, respectively, in Annual Recurring Compensation, which was reflected as an increase to retained deficit.
  (was, 2025-11-04, similarity 0.6736):
[0001193125-25-264157:note_history:5]
Our obligation to pay Annual Recurring Compensation under the DPLTA is a continuing payment obligation, which will amount to approximately €8.5 million (or $10.0 million based on the exchange rate as of September 30, 2025) per year assuming none of the minority Adtran Networks shareholders were to elect Exit Compensation. The foregoing amounts do not reflect any potential increase in payment obligations that we may have depending on the outcome of ongoing appraisal proceedings in Germany. The Annual Recurring Compensation is due on the third banking day following the ordinary general shareholders’ meeting of Adtran Networks for the respective preceding fiscal year (but in any event within eight months following expiration of the fiscal year). With respect to the 2024 fiscal year, Adtran Networks’ ordinary general shareholders' meeting occurred on June 27, 2025 and, therefore, the Annual Recurring Compensation was paid on July 1, 2025. During the three months ended September 30, 2025 and 2024, we accrued $2.5 million and $2.4 million, respectively, in Annual Recurring Compensation. During the nine months ended September 30, 2025 and 2024, we accrued $7.5 million and $7.4 million, respectively, in Annual Recurring Compensation, which was reflected as an increase to retained deficit.

- added (2026-05-05):
[0001193125-26-205276:note_history:6]
For the three months ended March 31, 2026, approximately 0.2 million shares of Adtran Networks stock were tendered to the Company and Exit Compensation of  €3.6 million or approximately $4.1 million are to be settled in cash in April 2026. For the three months ended March 31, 2025, less than one thousand shares of Adtran Networks stock were tendered to the Company and exit compensation payments of €12 thousand or $13 thousand based on the applicable exchange rates at the time of the transaction were paid to Adtran Networks shareholders.

- changed (2026-05-05):
[0001193125-26-205276:note_history:7]
Certain contracts, customers and jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of March 31, 2026 and December 31, 2025, we had commitments related to these bonds totaling $22.2 million and $22.4 million, respectively, which expire at various dates through April 2029. In general, we would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which we believe is remote.
  (was, 2025-11-04, similarity 0.9865):
[0001193125-25-264157:note_history:7]
Certain contracts, customers and jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of September 30, 2025 and December 31, 2024, we had commitments related to these bonds totaling $18.0 million and $15.7 million, respectively, which expire at various dates through April 2029. In general, we would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which we believe is remote.

- changed (2026-05-05):
[0001193125-26-205276:note_history:8]
The Company purchases components from a variety of suppliers and uses contract manufacturers to provide manufacturing services for our products. Our inventory purchase obligations are for product manufacturing requirements, as well as for commitments to suppliers to secure manufacturing capacity. Certain of our inventory purchase obligations with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. As of March 31, 2026, purchase obligations totaled $223.7 million.
  (was, 2025-11-04, similarity 0.9873):
[0001193125-25-264157:note_history:8]
The Company purchases components from a variety of suppliers and uses contract manufacturers to provide manufacturing services for our products. Our inventory purchase obligations are for product manufacturing requirements, as well as for commitments to suppliers to secure manufacturing capacity. Certain of our inventory purchase obligations with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. As of September 30, 2025, purchase obligations totaled $211.2 million.

- added (2026-05-05):
[0001193125-26-205276:note_history:9]
Tariff Refund

- added (2026-05-05):
[0001193125-26-205276:note_history:10]
On February 20, 2026, the U.S. Supreme Court issued a ruling striking down certain tariffs previously imposed under the International Emergency Economic Powers Act ("IEEPA"). The ultimate availability, timing, and amount of any potential refunds of such tariffs remain highly uncertain and are subject to further legal, regulatory, and administrative developments. Following the Supreme Court’s decision, the U.S. presidential administration announced its intention to invoke other laws to collect tariffs and announced new tariffs on imports from all countries, in addition to any existing non-IEEPA tariffs (including tariffs on semiconductors, which are expected to increase in June 2027).

- added (2026-05-05):
[0001193125-26-205276:note_history:11]
The Company has concluded that the potential refund of IEEPA tariffs should be evaluated under a loss recovery model pursuant to Accounting Standards Codification ("ASC") 410‑30. The tariffs at issue were previously capitalized to inventory and subsequently expensed through cost of goods sold. Accordingly, any refund represents a recovery of previously recognized costs, and recognition is limited to amounts previously recorded.

- added (2026-05-05):
[0001193125-26-205276:note_history:12]
Under the loss recovery model, an asset for recovery may be recognized only when receipt is considered probable, as defined under ASC 450‑20. While the Supreme Court ruling establishes a legal basis for recovery, material uncertainty remains regarding the administrative process required to obtain refunds. The U.S. Customs and Border Protection ("CBP") system became operational on April 20, 2026.

- added (2026-05-05):
[0001193125-26-205276:note_history:13]
Given the lack of clarity surrounding refund execution to determine expected recovery amount, the Company has concluded that recovery of the IEEPA tariffs is not probable as of the reporting date. Accordingly, no refund receivable has been recognized. Management will continue to monitor developments, including CBP implementation milestones, formal guidance on claim submission, and claim acceptance processes.

- added (2026-05-05):
[0001193125-26-205276:note_history:14]
Additionally, Adtran may owe money to customers depending on final assessments of contractual or implicit passthrough obligations. The Company will continue to monitor developments related to both refund recoverability and customer refund considerations and will update its accounting conclusions in future periods as facts and circumstances evolve.

- added (2026-05-05):
[0001193125-26-205276:note_history:15]
401(k) Plan Corrective Action

- added (2026-05-05):
[0001193125-26-205276:note_history:16]
In June 2024, the Company identified that within our Adtran, Inc. 401(k) plan for the year ended 2023, that deferrals and matching contributions should have been applied to vested equity award amounts in accordance with the plan documents. As such, we filed a voluntary correction program (“VCP”) application with the IRS and the Company is still in negotiations with the IRS regarding the appropriate corrective actions for this failure. Nonetheless, based on the current facts and circumstances surrounding the VCP negotiations, the Company accrued $1.4 million during the year ended December 31, 2025.

- removed (2026-05-05):
[0001193125-25-264157:note_history:17]
On August 4, 2025, we received a letter from the Atlanta regional office of the SEC in connection with a non-public, fact-finding inquiry, requesting that we voluntarily provide information regarding the internal investigation referenced in Note 1, “Summary of Significant Accounting Policies”. We intend to cooperate in response to the SEC’s inquiry. We cannot predict the timing or outcome of the inquiry.

- removed (2026-05-05):
[0001193125-25-264157:note_history:18]
For the three and nine months ended September 30, 2025, less than one thousand shares and approximately 0.9 million shares, respectively, of Adtran Networks stock were tendered to the Company. This resulted in total Exit Compensation payments of approximately €16.9 million, or $19.9 million based on the applicable exchange rates at the time of the transactions, being paid to Adtran Networks shareholders. For the three and nine months ended September 30, 2024, 0.8 million shares of Adtran Networks stock were tendered to the Company. This resulted in total Exit Compensation payments of approximately €15.7 million, or approximately $17.4 million, respectively, based on the applicable exchange rates at the time of the transactions, being paid to Adtran Networks shareholders.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2026-05-05):
[0001193125-26-205276:note_history:19]
ADTRAN Holdings, Inc. (“Adtran” or the “Company”) is a leading global provider of networking and communications platforms, software, systems and services focused on the broadband access market, serving a diverse domestic and international customer base in multiple countries that includes large, medium and small Service Providers, alternative Service Providers, such as utilities, municipalities and fiber overbuilders, cable/MSOs, SMBs and distributed enterprises, including Fortune 500 companies with sophisticated business continuity applications; and federal, state and local government agencies. Our innovative solutions and services enable voice, data, video and internet-communications across a variety of network infrastructures and are currently in use by millions worldwide. We support our customers through our direct global sales organization and distribution networks. Our success depends upon our ability to increase unit volume and market share through the introduction of new products and succeeding generations of products having optimal selling prices and increased functionality as compared to both the prior generation of a product and to the products of competitors in order to gain market share. To service our customers and grow revenue, we are continually conducting research and developing new products addressing customer needs and testing those products for the specific requirements of the particular customers. We offer a broad portfolio of flexible software and hardware network solutions and services that enable Service Providers to meet today’s service demands, while enabling them to transition to the fully converged, scalable, highly-automated, cloud-controlled voice, data, internet and video network of the future. In addition to our global headquarters in Huntsville, Alabama, and our European headquarters in Munich, Germany, we have sales and research and development facilities in strategic global locations.
  (was, 2025-11-04, similarity 0.9985):
[0001193125-25-264157:note_history:19]
ADTRAN Holdings, Inc. (“ADTRAN” or the “Company”) is a leading global provider of networking and communications platforms, software, systems and services focused on the broadband access market, serving a diverse domestic and international customer base in multiple countries that includes large, medium and small Service Providers, alternative Service Providers, such as utilities, municipalities and fiber overbuilders, cable/MSOs, SMBs and distributed enterprises, including Fortune 500 companies with sophisticated business continuity applications, and federal, state and local government agencies. Our innovative solutions and services enable voice, data, video and internet-communications across a variety of network infrastructures and are currently in use by millions worldwide. We support our customers through our direct global sales organization and our distribution networks. Our success depends upon our ability to increase unit volume and market share through the introduction of new products and succeeding generations of products having optimal selling prices and increased functionality as compared to both the prior generation of a product and to the products of competitors in order to gain market share. To service our customers and grow revenue, we are continually conducting research and developing new products addressing customer needs and testing those products for the specific requirements of the particular customers. We offer a broad portfolio of flexible software and hardware network solutions and services that enable Service Providers to meet today’s service demands, while enabling them to transition to the fully converged, scalable, highly-automated, cloud-controlled voice, data, internet and video network of the future. In addition to our global headquarters in Huntsville, Alabama, and our European headquarters in Munich, Germany, we have sales and research and development facilities in strategic global locations.

- changed (2026-05-05):
[0001193125-26-205276:note_history:20]
The Company solely owns ADTRAN, Inc. and is the majority shareholder of Adtran Networks. ADTRAN, Inc. is a leading global provider of open, disaggregated networking and communications solutions. Adtran Networks is a global provider of network solutions for data, storage, voice and video services. We believe that the combined technology portfolio can best address current and future customer needs for high-speed connectivity from the network core to the end consumer, especially upon the convergence of solutions at the network edge.
  (was, 2025-11-04, similarity 0.979):
[0001193125-25-264157:note_history:20]
The Company solely owns ADTRAN, Inc. and is the majority shareholder of Adtran Networks SE (“Adtran Networks”). ADTRAN, Inc. is a leading global provider of open, disaggregated networking and communications solutions. Adtran Networks is a global provider of network solutions for data, storage, voice and video services. We believe that the combined technology portfolio can best address current and future customer needs for high-speed connectivity from the network core to the end consumer, especially upon the convergence of solutions at the network edge.

- changed (2026-05-05):
[0001193125-26-205276:note_history:21]
Domination and Profit and Loss Transfer Agreement, Liquidity, Credit Facility and Notes Offering
  (was, 2025-11-04, similarity 0.7188):
[0001193125-25-264157:note_history:21]
Liquidity, Domination and Profit and Loss Transfer Agreement, Notes Offering and Credit Facility

- changed (2026-05-05):
[0001193125-26-205276:note_history:22]
Under the DPLTA, subject to certain limitations pursuant to applicable law and the specific terms of the DPLTA, (i) the Company is entitled to issue binding instructions to the management board of Adtran Networks, (ii) Adtran Networks will transfer its annual profit to the Company, subject to, among other things, the creation or dissolution of certain reserves, and (iii) the Company will absorb the annual net loss incurred by Adtran Networks. The Company’s payment obligation in satisfaction of the requirement that it absorb Adtran Networks’ annual net loss applied to the net loss generated by Adtran Networks in 2025 and it will apply to any net loss generated by Adtran Networks in 2026.
  (was, 2025-11-04, similarity 0.9985):
[0001193125-25-264157:note_history:22]
Under the DPLTA, subject to certain limitations pursuant to applicable law and the specific terms of the DPLTA, (i) the Company is entitled to issue binding instructions to the management board of Adtran Networks, (ii) Adtran Networks will transfer its annual profit to the Company, subject to, among other things, the creation or dissolution of certain reserves, and (iii) the Company will absorb the annual net loss incurred by Adtran Networks. The Company’s payment obligation in satisfaction of the requirement that it absorb Adtran Networks’ annual net loss applies to the net loss generated by Adtran Networks in 2024 and it will apply to any net loss generated by Adtran Networks in 2025.

- changed (2026-05-05):
[0001193125-26-205276:note_history:23]
Pursuant to the terms of the DPLTA, each Adtran Networks shareholder (other than the Company) has received an offer to elect either (1) to remain an Adtran Networks shareholder and receive from us an Annual Recurring Compensation payment, or (2) to receive Exit Compensation plus guaranteed interest. The guaranteed interest under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid. The guaranteed interest rate is 5.0% plus a variable component (according to the German Civil Code) that was 1.27% as of March 31, 2026. Assuming all the minority holders of currently outstanding Adtran Networks shares were to elect the second option, we would be obligated to make aggregate Exit Compensation payments, including guaranteed interest, of approximately €304.4 million or approximately $351.7 million, based on an exchange rate as of March 31, 2026, and reflecting interest accrued through March 31, 2026 during the pendency of the appraisal proceedings discussed below. Shareholders electing the first option of Annual Recurring Compensation may later elect the second option. The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that were initiated in 2023 in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger). Following the court's decision on a procedural matter in the DPLTA appraisal proceedings on July 14, 2025, the trial on the merits of the DPLTA has recommenced. It is expected to take a minimum of 12 months for a ruling of the court on the merits and such ruling will most likely be appealed, which would be expected to take an additional 12-24 months to be resolved. Accordingly, the Company does not expect a final decision on the DPLTA appraisal proceedings to be rendered and published prior to 2027, and most likely not until 2028 or beyond.
  (was, 2025-11-04, similarity 0.9096):
[0001193125-25-264157:note_history:23]
Pursuant to the terms of the DPLTA, each Adtran Networks shareholder (other than the Company) has received an offer to elect either (1) to remain an Adtran Networks shareholder and receive from us recurring compensation in cash of €0.52 per share for each full fiscal year of Adtran Networks (the "Annual Recurring Compensation"), or (2) to put their Adtran Networks shares to the Company in exchange for compensation in cash of €17.21 per share, plus guaranteed interest (the "Exit Compensation"). The guaranteed interest under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid. The guaranteed interest rate is 5.0% plus a variable component (according to the German Civil Code) that was 1.27% as of September 30, 2025. Assuming all the minority holders of currently outstanding Adtran Networks shares were to elect the second option, we would be obligated to make aggregate Exit Compensation payments, including guaranteed interest, of approximately €322.7 million or $378.7 million, based on an exchange rate as of September 30, 2025, and reflecting interest accrued through September 30, 2025 during the pendency of the appraisal proceedings discussed below. Shareholders electing the first option of Annual Recurring Compensation may later elect the second option. The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that were initiated in 2023 in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger). Following the court's decision on a procedural matter in the DPLTA appraisal proceedings on July 14, 2025, the trial on the merits of the DPLTA has recommenced. It is expected to take a minimum of 12 months for a ruling of the court on the merits and such ruling will most likely be appealed, which would be expected to take an additional 12-24 months to be resolved. Accordingly, the Company does not expect a final decision on the DPLTA appraisal proceedings to be rendered and published prior to 2027, and most likely not until 2028 or beyond.

- changed (2026-05-05):
[0001193125-26-205276:note_history:24]
Additionally, our obligation to pay Annual Recurring Compensation under the DPLTA is a continuing payment obligation, which will amount to approximately €7.8 million (or $9.0 million based on the current exchange rate) per year assuming none of the minority Adtran Networks shareholders as of March 31, 2026 were to elect Exit Compensation. The foregoing amounts do not reflect any potential increase in payment obligations that we may have depending on the outcome of ongoing appraisal proceedings in Germany. The Annual Recurring Compensation is due on the third banking day following the ordinary general shareholders’ meeting of Adtran Networks for the respective preceding fiscal year (but in any event within eight months following expiration of the fiscal year). With respect to the 2025 fiscal year, Adtran Networks’ ordinary general shareholder meeting is scheduled for the second quarter of 2026, and the Annual Recurring Compensation will be due on the third banking day following the meeting. During the three months ended March 31, 2026 and 2025, we accrued $2.2 million and $2.4 million, respectively, in Annual Recurring Compensation. The Annual Recurring Compensation is reflected as an increase to retained deficit in the Condensed Consolidated Balance Sheets.
  (was, 2025-11-04, similarity 0.6012):
[0001193125-25-264157:note_history:24]
Additionally, our obligation to pay Annual Recurring Compensation under the DPLTA is a continuing payment obligation, which will amount to approximately €8.5 million (or $10.0 million based on the exchange rate as of September 30, 2025) per year assuming none of the minority Adtran Networks shareholders as of September 30, 2025 were to elect Exit Compensation. The foregoing amounts do not reflect any potential increase in payment obligations that we may have depending on the outcome of ongoing appraisal proceedings in the German court. The Annual Recurring Compensation is due on the third banking day following the ordinary general shareholders’ meeting of Adtran Networks for the respective preceding fiscal year (but in any event within eight months following expiration of the fiscal year). With respect to the 2023 fiscal year, Adtran Networks’ ordinary general shareholders’ meeting occurred on June 28, 2024 and, therefore, the Annual Recurring Compensation was paid on July 3, 2024. With respect to the 2024 fiscal year, Adtran Networks’ ordinary general shareholder meeting occurred on June 27, 2025 and, therefore, the Annual Recurring Compensation was paid on July 1, 2025. During the three months ended September 30, 2025 and 2024, we accrued $2.5 million and $2.4 million, respectively, in Annual Recurring Compensation. During the nine months ended September 30, 2025 and 2024, we accrued $7.5 million and $7.4 million, respectively, in Annual Recurring Compensation. The Annual Recurring Compensation is reflected as an increase to retained deficit.

- changed (2026-05-05):
[0001193125-26-205276:note_history:25]
On July 18, 2022, ADTRAN, Inc., as the borrower, and ADTRAN Holdings, Inc. entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (“Credit Agreement”), which has since been amended six times. The Company had access to $319.2 million on its Credit Facility for future borrowings based on debt covenant compliance metrics. The financial covenants under the Credit Agreement, as amended, require the Company to maintain a Consolidated Total Net Leverage Ratio of 5.00x, a Consolidated Senior Secured Net Leverage Ratio of 3.25x (4.0x to 3.5x during a Springing Covenant Period) and a Consolidated Fixed Charge Coverage Ratio of 1.25x (as such terms are defined in the Credit Agreement). In addition, during a Springing Covenant Period the cash and cash equivalents of the credit parties must be at least $50.0 million and the cash and cash equivalents of the Company and its subsidiaries must be at least $70.0 million. The Credit Agreement matures in July 2027. The Company intends to refinance or replace the existing Credit Agreement with a new credit facility during the second quarter of 2026. There can be no assurances that this renewal will occur on terms acceptable to the Company, or at all.
  (was, 2025-11-04, similarity 0.8141):
[0001193125-25-264157:note_history:25]
On July 18, 2022, ADTRAN, Inc., as the borrower, and ADTRAN Holdings, Inc. entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (“Credit Agreement”), which has since been amended six times. The Company had access to $319.2 million on its Credit Facility for future borrowings; however, as of September 30, 2025, the Company was limited to additional borrowings of $232.0 million based on debt covenant compliance metrics. The financial covenants under the Credit Agreement, as amended, require the Company to maintain a Consolidated Total Net Leverage Ratio of 5.00x, a Consolidated Senior Secured Net Leverage Ratio of 3.25x (4.0x to 3.5x during a Springing Covenant Period) and a Consolidated Fixed Charge Coverage Ratio of 1.25x (as such terms are defined in the Credit Agreement). In addition, during a Springing Covenant Period the cash and cash equivalents of the credit parties must be at least $50.0 million and the cash and cash equivalents of the Company and its subsidiaries must be at least $70.0 million. See Note 11, Credit Agreement for additional information regarding the terms of the Wells Fargo Credit Agreement.

- changed (2026-05-05):
[0001193125-26-205276:note_history:26]
As of March 31, 2026, and as of the date of issuance of these financial statements, the Company has sufficient liquidity to meet the majority of its payment obligations under the DPLTA pertaining to Exit Compensation. For the three months ended March 31, 2026,  approximately 0.2 million shares of Adtran Networks stock were tendered to the Company and Exit Compensation of  €3.6 million or approximately $4.1 million are to be settled in cash in April 2026. For the three months ended March 31, 2025, less than one thousand shares of Adtran Networks stock were tendered to the Company and exit compensation payments of €12 thousand or $13 thousand based on the applicable exchange rates at the time of the transaction were paid to Adtran Networks shareholders. We believe the probability that more than a small minority of Adtran Networks shareholders elect to receive Exit Compensation in the next twelve months is remote based on the following factors: (i) the shareholders can exercise their right to receive the Exit Compensation until two months after publication of the final decision in the appraisal proceedings and we do not expect the final decision to be published within the next 12 months; (ii) the diverse base of shareholders that must make this election on an individual shareholder basis; (iii) the fact the date of a decision by the court on the merits of the case is uncertain, it will most likely take a minimum of 12 months for a ruling and, thereafter, an expected appeal process will take a further 12-24 months to resolve; (iv) the current guaranteed Annual Recurring Compensation payment; and (v) the current trading value of Adtran Networks shares.
  (was, 2025-11-04, similarity 0.8466):
[0001193125-25-264157:note_history:26]
As of September 30, 2025, and as of the date of issuance of these financial statements, the Company has sufficient liquidity to meet a majority of its payment obligations under the DPLTA pertaining to Exit Compensation. For the three and nine months ended September 30, 2025, less than one thousand shares and approximately 0.9 million shares, respectively, of Adtran Networks stock were tendered to the Company. This resulted in total Exit Compensation payments of approximately €16.9 million or $19.9 million based on the applicable exchange rates at the time of the transactions being paid to Adtran Networks shareholders. For the three and nine months ended September 30, 2024, approximately 0.8 million shares of Adtran Networks stock were tendered to the Company. This resulted in Exit Compensation payments of approximately €15.7 million, or $17.4 million, based on the applicable exchange rates at the time of the transactions, being paid to Adtran Networks shareholders. We believe the probability that more than a small minority of Adtran Networks shareholders elect to receive Exit Compensation in the next twelve months is remote based on the following factors: (i) the shareholders can exercise their right to receive the Exit Compensation until two months after publication of the final decision in the appraisal proceedings and we do not expect the final decision to be published within the next 12 months; (ii) the diverse base of shareholders that must make this election on an individual shareholder basis; (iii) the fact the date of a decision by the court on the merits of the case is uncertain, it will most likely take a minimum of 12 months for a ruling and, thereafter, an expected appeal process will take a further 12-24 months to resolve; (iv) the current guaranteed Annual Recurring Compensation payment; and (v) the current trading value of Adtran Networks shares.

- changed (2026-05-05):
[0001193125-26-205276:note_history:27]
Moreover, on September 19, 2025, the Company issued $201.3 million aggregate principal amount of convertible senior notes due 2030 (the “Notes”). The Notes accrue interest at a rate of 3.75% per annum, payable semi-annually in arrears on March 15 and September 15 of each year, beginning March 15, 2026. Unless repurchased earlier, redeemed, or converted, the Notes will mature on September 15, 2030. After deducting the initial purchasers’ discounts, commissions, and estimated offering expenses, the Company received net proceeds of $192.6 million.
  (was, 2025-11-04, similarity 0.786):
[0001193125-25-264157:note_history:27]
Moreover, on September 19, 2025, the Company issued $201.3 million aggregate principal amount of convertible senior notes due 2030 (the “Notes”). The Notes accrue interest at a rate of 3.75% per annum, payable semi-annually in arrears on March 15 and September 15 of each year, beginning March 15, 2026. Unless repurchased earlier, redeemed, or converted, the Notes will mature on September 15, 2030. After deducting the initial purchasers’ discounts, commissions, and estimated offering expenses, the Company received net proceeds of $192.8 million. As of September 30, 2025, and as of the date of issuance of these financial statements, management believes that the Company has sufficient liquidity to meet its payment obligations under the Notes through its operating cash flow and the borrowings available under the Credit Agreement.

- added (2026-05-05):
[0001193125-26-205276:note_history:28]
The Company believes that its cash and cash equivalents, working capital management initiatives and availability to access cash under the Wells Fargo credit facility or other future sources of capital will be adequate to meet our business operating requirements, our capital expenditures and our expected obligations under both the Notes and the DPLTA, including anticipated levels of Exit Compensation, as well as to support our ability to continue to comply with our debt covenants under the Credit Facility for at least the next twelve months, from the issuance of these financial statements. See Note 10, Credit Agreements, for additional information regarding the terms of the Amendments of the Wells Fargo Credit Agreement.

- changed (2026-05-05):
[0001193125-26-205276:note_history:29]
In the opinion of management, all adjustments necessary to fairly state these interim statements have been recorded and are of a normal and recurring nature. The results of operations for an interim period are not necessarily indicative of the results for the full year. The interim financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in ADTRAN Holdings, Inc. Annual Report on Form 10-K for the year ended December 31, 2025, filed with the SEC on February 26, 2026.
  (was, 2025-11-04, similarity 0.9536):
[0001193125-25-264157:note_history:29]
In the opinion of management, all adjustments necessary to fairly state these interim statements have been recorded and are of a normal and recurring nature. The results of operations for an interim period are not necessarily indicative of the results for the full year. The interim financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in ADTRAN Holdings, Inc. Amendment No. 1 to the Annual Report on Form 10-K for the year ended December 31, 2024, filed with the SEC on May 20, 2025 ("2024 Form 10-K/A").

- changed (2026-05-05):
[0001193125-26-205276:note_history:30]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenue and expense during the reporting period. Significant estimates include allowance for credit losses on accounts receivable and contract assets, excess and obsolete inventory reserves, determination and accrual of the deferred revenue related to performance obligations under contracts with customers, estimated costs to complete obligations associated with deferred and accrued revenue and network installations, estimated income tax provision and income tax contingencies, fair value of stock-based compensation, assessment of goodwill and other intangibles for impairment, estimated lives of intangible assets, estimates of intangible assets upon measurement, estimated pension liability and fair value of investments and estimated contingent liabilities. Actual amounts could differ significantly from these estimates.
  (was, 2025-11-04, similarity 0.9839):
[0001193125-25-264157:note_history:30]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenue and expense during the reporting period. Significant estimates include allowance for credit losses on accounts receivable and contract assets, excess and obsolete inventory reserves, warranty reserves, customer rebates, determination and accrual of the deferred revenue related to performance obligations under contracts with customers, estimated costs to complete obligations associated with deferred and accrued revenue and network installations, estimated income tax provision and income tax contingencies, fair value of stock-based compensation, assessment of goodwill and other intangibles for impairment, estimated lives of intangible assets, estimates of intangible assets upon measurement, estimated pension liability and fair value of investments and estimated contingent liabilities. Actual amounts could differ significantly from these estimates.

- changed (2026-05-05):
[0001193125-26-205276:note_history:31]
We assessed certain accounting matters that generally require consideration of forecasted financial information in context with the information reasonably available to us and the unknown future impacts of ongoing inflationary pressures, continued elevated interest rates, instability in the financial services industry, currency fluctuations and political tensions as of March 31, 2026, and through the date of this report. These conditions could result in further impacts to the Company's consolidated financial statements in future reporting periods. The accounting matters assessed included, but were not limited to, the allowance for credit losses, stock-based compensation, carrying value of goodwill, intangibles and other long-lived assets, financial assets, valuation allowances for tax assets, revenue recognition and costs of revenue.
  (was, 2025-11-04, similarity 0.9007):
[0001193125-25-264157:note_history:31]
We assessed certain accounting matters that generally require consideration of forecasted financial information in context with the information reasonably available to us and the unknown future impacts of ongoing inflationary pressures, continued elevated interest rates, currency fluctuations and political tensions as of September 30, 2025, and through the date of this report. These conditions could result in further impacts to the Company's consolidated financial statements in future reporting periods. The accounting matters assessed included, but were not limited to, the allowance for credit losses, stock-based compensation, carrying value of goodwill, intangibles and other long-lived assets, financial assets, valuation allowances for tax assets, revenue recognition and costs of revenue.

- changed (2026-05-05):
[0001193125-26-205276:note_history:32]
During the three months ended March 31, 2026, there were no other significant changes to our critical accounting policies or estimates from those described in the financial statements contained in the 2025 Form 10-K.
  (was, 2025-11-04, similarity 0.8939):
[0001193125-25-264157:note_history:32]
During the nine months ended September 30, 2025, there were no other significant changes to our critical accounting policies as described in the financial statements contained in the 2024 Form 10-K/A.

- changed (2026-05-05):
[0001193125-26-205276:note_history:33]
In September 2025, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update ("ASU") 2025-06, "Intangibles-Goodwill and Other-Internal-Use Software (Subtopic 350-40): Targeted Improvements to the Accounting for Internal-Use Software," which is intended to modernize the accounting for the costs of internal-use software given the evolution of software development to the incremental and iterative development method. The amendments remove all references to prescriptive and sequential development stages and, instead, require an entity to start capitalizing software costs when management has authorized and committed to funding the software project, and it is probable that the project will be completed and the software will be used to perform the function intended. The amendments are effective for annual reporting periods beginning after December 15, 2027, and interim reporting periods within those annual reporting periods. Early adoption is permitted as of the beginning of an annual reporting period with the amendments to be applied using a prospective, modified or retrospective transition approach. The Company is currently evaluating the impact of adopting this guidance on the consolidated financial statements.
  (was, 2025-11-04, similarity 0.9852):
[0001193125-25-264157:note_history:33]
In September 2025, the Financial Accounting Standards Board (“FASB”) issued ASU 2025-06, "Intangibles-Goodwill and Other-Internal-Use Software (Subtopic 350-40): Targeted Improvements to the Accounting for Internal-Use Software," which is intended to modernize the accounting for the costs of internal-use software given the evolution of software development to the incremental and iterative development method. The amendments remove all references to prescriptive and sequential development stages and, instead, require an entity to start capitalizing software costs when management has authorized and committed to funding the software project, and it is probable that the project will be completed and the software will be used to perform the function intended. The amendments are effective for annual reporting periods beginning after December 15, 2027, and interim reporting periods within those annual reporting periods. Early adoption is permitted as of the beginning of an annual reporting period with the amendments to be applied using a prospective, modified or retrospective transition approach. The Company is currently evaluating the impact of adopting this guidance on the consolidated financial statements.

- added (2026-05-05):
[0001193125-26-205276:note_history:34]
In November 2024, the FASB issued ASU 2024-03, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses, as amended by ASU 2025-01, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40): Clarifying the Effective Date", which applies to all public business entities (PBEs) and is intended to enhance disclosures about specific types of expenses included in the expense captions presented on the face of the income statement as well as disclosures about selling expenses. The amendments are effective prospectively for annual periods beginning after December 15, 2026, and interim reporting periods within annual reporting periods beginning after December 15, 2027. Early adoption and retrospective application are permitted. The Company is currently evaluating the effect that adoption of ASU 2024-03 will have on our disclosures.

- removed (2026-05-05):
[0001193125-25-264157:note_history:35]
The Company experienced revenue declines in the year ended December 31, 2024. However, customers began replenishing their inventories to meet increasing demand, and revenue increased throughout the first three quarters of 2025. In 2023, the Company suspended dividend payments and effectuated a business efficiency program (the "Business Efficiency Program"), which targeted the reduction of ongoing operating expenses and focused on enhancing capital efficiency. The Business Efficiency Program was completed as of December 31, 2024. In addition, the Company continues to assess the probability that the sale of its headquarters in Huntsville will occur and has determined it is probable of occurring in the next twelve months.

- removed (2026-05-05):
[0001193125-25-264157:note_history:36]
In summary, the Company believes that its cash, cash equivalents and restricted cash, working capital management initiatives and availability to access cash under the Wells Fargo credit facility will be adequate to meet our business operating requirements, our capital expenditures and our expected obligations under both the Notes and the DPLTA, including anticipated levels of Exit Compensation, as well as to support our ability to continue to comply with our debt covenants under the Credit Facility for at least the next twelve months,

- removed (2026-05-05):
[0001193125-25-264157:note_history:37]
from the issuance of these financial statements. See Note 11, Credit Agreements, for additional information regarding the terms of the Amendments of the Credit Agreement.

- removed (2026-05-05):
[0001193125-25-264157:note_history:38]
Restatement of Previously Issued Financial Statements

- removed (2026-05-05):
[0001193125-25-264157:note_history:39]
As discussed in the financial statements as of and for the year ended December 31, 2024 included in our 2024 Form 10-K/A, we identified errors in our previously issued financial statements related to the historical accounting for certain inventory and cost of goods sold transactions (“Adjustment”). The affected periods included the annual periods ended December 31, 2023 and 2024 and the interim periods ended March 31, 2024, June 30, 2024 and September 30, 2024.

- removed (2026-05-05):
[0001193125-25-264157:note_history:40]
In connection with the identification of the Adjustment, the Audit Committee oversaw an internal investigation into the circumstances surrounding the Adjustment and its impact on the Company’s historical financial statements. Based on the findings of the internal investigation, it was determined that the underlying errors giving rise to the Adjustment were not properly addressed in the Company’s previously filed financial statements as of and for the years ended December 31, 2024 and 2023 and were not communicated to the Audit Committee or the independent auditors prior to the filing of the initial 2024 Annual Report on Form 10-K. As described in Part I, Item 4 of this report, the Company is taking certain remedial actions to address the material weaknesses in its internal controls associated with these findings. On August 4, 2025, we received a letter from the Atlanta regional office of the SEC in connection with a non-public, fact-finding inquiry, requesting that we voluntarily provide information regarding the internal investigation.

- removed (2026-05-05):
[0001193125-25-264157:note_history:41]
The identified errors referenced above impacted the Condensed Consolidated Financial Statements as of and for the three and nine months ended September 30, 2024, among other periods as previously disclosed. Below is a summary description of the significant errors in the Company's Condensed Consolidated Financial Statements as of and for the three and nine months ended September 30, 2024:

- removed (2026-05-05):
[0001193125-25-264157:note_history:42]
ADJ 1 - Pursuant to the terms of the DPLTA, each Adtran Networks shareholder (other than the Company) is entitled to receive from us an Annual Recurring Compensation payment of €0.52 per share. The Company erroneously accrued this liability every quarter at €0.59 per share, overstating the associated accrual, the net income attributable to non-controlling interest and the net loss attributable to ADTRAN Holdings, Inc. for fiscal periods beginning with the quarter ended March 31, 2023 through the quarter ended June 30, 2024.

- removed (2026-05-05):
[0001193125-25-264157:note_history:43]
ADJ 2 - For the periods beginning with the quarter ended March 31, 2023 through the quarter ended June 30, 2024, the Company remeasured the RNCI each quarter-end at the current exchange rate of euros to U.S. Dollar. The Company treated the RNCI as a monetary mezzanine equity instrument but should have treated it as a non-monetary mezzanine equity instrument not subject to remeasurement.

- removed (2026-05-05):
[0001193125-25-264157:note_history:44]
ADJ 3 - For the year ended December 31, 2023 through the year ended December 31, 2024, the Company understated cost of revenue and overstated inventory in the Company's Adtran Networks subsidiary due to a system error. In addition, there were adjustments in the Company's U.S and Australian subsidiaries related to inventory reserves that were understated.

- removed (2026-05-05):
[0001193125-25-264157:note_history:45]
ADJ 4 - For the year ended December 31, 2023 through the year ended December 31, 2024, the Company understated goodwill and overstated income tax receivable. The understatement was attributable to corrections to goodwill and deferred income tax associated with goodwill for an internal divestiture of a wholly owned subsidiary required by statutory laws in Europe.

- removed (2026-05-05):
[0001193125-25-264157:note_history:46]
In addition to the misstatements identified above, the Company has corrected other immaterial errors. These other errors are quantitatively and qualitatively immaterial, individually and in the aggregate. However, the Company has corrected these other errors as part of the correction for the significant errors described above.

- removed (2026-05-05):
[0001193125-25-264157:note_history:47]
We assessed the materiality of the errors on prior period consolidated financial statements in accordance with SEC Staff Accounting Bulletin No. 99, “Materiality,” codified in ASC Topic 250, Accounting Changes and Error Corrections. Based on this assessment, we concluded that the errors, in the aggregate, are material to the September 30, 2024 financial statements and therefore, we have restated

- removed (2026-05-05):
[0001193125-25-264157:note_history:48]
those financial statements herein. Furthermore, we made adjustments to correct for other previously identified immaterial errors. The Company has also restated impacted amounts within the accompanying footnotes to the Condensed Consolidated Financial Statements. See Note 20 for further information about the restatement.

- removed (2026-05-05):
[0001193125-25-264157:note_history:49]
Restricted Cash

- removed (2026-05-05):
[0001193125-25-264157:note_history:50]
Restricted cash consists of cash pledged as collateral, which is permitted to be withdrawn for the purpose of financing the purchase of additional outstanding shares of Equity Interests (as defined in the Credit Agreement) of Adtran Networks. See Note 11 for additional information.

- removed (2026-05-05):
[0001193125-25-264157:note_history:51]
Convertible Senior Notes

- removed (2026-05-05):
[0001193125-25-264157:note_history:52]
We account for our convertible senior notes with embedded conversion features in accordance with ASC 470-20, under which convertible debt instruments would only be separated into multiple components if they were issued at a substantial premium or if embedded derivatives requiring bifurcation were identified. The convertible senior notes (the "2030 Notes" or the “Notes”) were not issued at a substantial premium, and we analyzed the provisions of the 2030 Notes and did not identify any material embedded features which would require bifurcation from the host debt. As such, the 2030 Notes are accounted for entirely as a liability, net of unamortized issuance costs. The carrying amount of the liability is classified as long-term as the instrument does not mature within one year of the balance sheet date and the holder is not permitted to demand repayment of the principal within one year of the balance sheet date. However, if conditions to convertibility are met and holders are expected to convert within one year as described further in Note 12, we may be required to reclassify the carrying amount of the liability to current. Issuance costs are amortized to interest expense using the effective interest rate method.

- removed (2026-05-05):
[0001193125-25-264157:note_history:53]
In November 2024, the FASB issued ASU 2024-03, "Disaggregation of Income Statement Expenses (DISE) (Topic 220): Improvements to Income Statement Disclosures", which applies to all public business entities and is intended to enhance disclosures about specific types of expenses included in the expense captions presented on the face of the income statement as well as disclosures about selling expenses. The amendments are effective prospectively for annual periods beginning after December 15, 2026, and early adoption and retrospective application are permitted. The Company is currently evaluating the effect that adoption of ASU 2024-03 will have on our disclosures.

- removed (2026-05-05):
[0001193125-25-264157:note_history:54]
In December 2023, the FASB issued ASU 2023-09, "Income Taxes (Topic 740): Improvements to Income Tax Disclosures", which is intended to enhance the transparency, decision usefulness and effectiveness of income tax disclosures. The amendments in this ASU require a public entity to disclose a tabular tax rate reconciliation, using both percentages and currency, with specific categories. A public entity is also required to provide a qualitative description of the states and local jurisdictions that make up the majority of the effect of the state and local income tax category and the net amount of income taxes paid, disaggregated by federal, state and foreign taxes and also disaggregated by individual jurisdictions. The amendments also remove certain disclosures that are no longer considered cost beneficial. The amendments are effective prospectively for annual periods beginning after December 15, 2024, and early adoption and retrospective application are permitted. The resulting new annual disclosure requirements will be reflected in our 2025 report on Form 10-K. The adoption of this guidance is not expected to have a material impact on our consolidated financial statements.


## adtn:ConvertibleSeniorNotesPolicyTextBlock (debt) — matched_by: no_current_note, score: 0.0

- removed (2026-05-05):
[0001193125-25-264157:note_history:55]
Convertible Senior Notes

- removed (2026-05-05):
[0001193125-25-264157:note_history:56]
We account for our convertible senior notes with embedded conversion features in accordance with ASC 470-20, under which convertible debt instruments would only be separated into multiple components if they were issued at a substantial premium or if embedded derivatives requiring bifurcation were identified. The convertible senior notes (the "2030 Notes" or the “Notes”) were not issued at a substantial premium, and we analyzed the provisions of the 2030 Notes and did not identify any material embedded features which would require bifurcation from the host debt. As such, the 2030 Notes are accounted for entirely as a liability, net of unamortized issuance costs. The carrying amount of the liability is classified as long-term as the instrument does not mature within one year of the balance sheet date and the holder is not permitted to demand repayment of the principal within one year of the balance sheet date. However, if conditions to convertibility are met and holders are expected to convert within one year as described further in Note 12, we may be required to reclassify the carrying amount of the liability to current. Issuance costs are amortized to interest expense using the effective interest rate method.

- removed (2026-05-05):
[0001193125-25-264157:note_history:57]
During the nine months ended September 30, 2025, there were no other significant changes to our critical accounting policies as described in the financial statements contained in the 2024 Form 10-K/A.


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2026-05-05):
[0001193125-26-205276:note_history:58]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | March 31, 2026 |  |  | December 31, 2025 |  |
| Convertible senior notes |  | $ | 201,250 |  |  | $ | 201,250 |  |
| Less: unamortized debt issuance costs |  |  | (7,825 | ) |  |  | (8,212 | ) |
| Non-current convertible senior notes |  | $ | 193,425 |  |  | $ | 193,038 |  |

- removed (2026-05-05):
[0001193125-25-264157:note_history:59]
|  |  | As of |  |
| (In thousands) |  | September 30, 2025 |  |
| Convertible senior notes |  | $ | 201,250 |  |
| Less: unamortized debt issuance costs |  |  | (8,391 | ) |
| Non-current convertible senior notes |  | $ | 192,859 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2026-05-05):
[0001193125-26-205276:note_history:60]
10. CREDIT AGREEMENTS
  (was, 2025-11-04, similarity 0.973):
[0001193125-25-264157:note_history:60]
11. CREDIT AGREEMENT

- changed (2026-05-05):
[0001193125-26-205276:note_history:61]
The carrying amounts of the Company's non-current revolving credit facility in its Condensed Consolidated Balance Sheets were as follows:
  (was, 2025-11-04, similarity 0.7434):
[0001193125-25-264157:note_history:61]
The carrying value of the Company's non-current revolving credit facility was as follows:

- changed (2026-05-05):
[0001193125-26-205276:note_history:62]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | March 31, 2026 |  |  | December 31, 2025 |  |
| Wells Fargo credit agreement |  | $ | 25,000 |  |  | $ | 25,000 |  |
| Total non-current revolving credit facility |  | $ | 25,000 |  |  | $ | 25,000 |  |
  (was, 2025-11-04, similarity 0.9009):
[0001193125-25-264157:note_history:62]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | September 30, 2025 |  |  | December 31, 2024 |  |
| Wells Fargo credit agreement |  | $ | 25,023 |  |  | $ | 189,576 |  |
| Total non-current revolving credit facility |  | $ | 25,023 |  |  | $ | 189,576 |  |

- added (2026-05-05):
[0001193125-26-205276:note_history:63]
As of March 31, 2026 and December 31, 2025, the estimated fair value of our revolving credit agreement approximates the carrying value. As of March 31, 2026, the weighted average interest rate on our revolving credit agreement was 8.92%.

- changed (2026-05-05):
[0001193125-26-205276:note_history:64]
On July 18, 2022, ADTRAN, Inc., as the borrower ("U.S. Borrower"), and the Company entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (the “Original Credit Agreement”), as amended by the First Amendment to Credit Agreement, dated August 9, 2023 (“Amendment No. 1”), the Second Amendment to Credit Agreement, dated January 16, 2024 (“Amendment No. 2”), the Third Amendment to Credit Agreement, dated March 12, 2024 (“Amendment No. 3”), the Fourth Amendment to Credit Amendment, dated June 4, 2024 among Adtran Networks (the "German Borrower") and the parties set forth above ("Amendment No. 4"), the Fifth Amendment to Credit Agreement and Waiver, dated May 6, 2025, among the German Borrower and the parties set forth above (“Amendment No. 5”), and the Sixth Amendment and Consent Credit Agreement, dated September 16, 2025, among the U.S. Borrower,
  (was, 2025-11-04, similarity 0.8652):
[0001193125-25-264157:note_history:64]
On July 18, 2022, ADTRAN, Inc., as the borrower ("U.S. Borrower"), and the Company entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (the “Original Credit Agreement”), as amended by the First Amendment to Credit Agreement, dated August 9, 2023 (“Amendment No. 1”), the Second Amendment to Credit Agreement, dated January 16, 2024 (“Amendment No. 2”), the Third Amendment to Credit Agreement, dated March 12, 2024 (“Amendment No. 3”), the Fourth Amendment to Credit Amendment, dated June 4, 2024 among Adtran Networks (the "German Borrower") and the parties set forth above ("Amendment No. 4") and the Fifth Amendment to Credit Agreement and Waiver, dated May 6, 2025, among the German Borrower and the parties set forth above (“Amendment No. 5”; the Original Credit Agreement as amended by Amendment No. 1, Amendment No. 2. Amendment No. 3, Amendment No. 4 and Amendment No. 5, the “Existing Credit Agreement”).

- added (2026-05-05):
[0001193125-26-205276:note_history:65]
the German Borrower and the lenders party thereto ("Amendment No. 6"); (the Original Credit Agreement as amended by Amendment No. 1, Amendment No. 2. Amendment No. 3, Amendment No. 4 and Amendment No. 5, the “Existing Credit Agreement”).

- changed (2026-05-05):
[0001193125-26-205276:note_history:66]
As of March 31, 2026, the Amended Credit Agreement provided for a secured revolving credit facility of up to $350.0 million of borrowings, $50.0 million of which is solely available to the German Borrower.
  (was, 2025-11-04, similarity 0.9742):
[0001193125-25-264157:note_history:66]
As of September 30, 2025, the Amended Credit Agreement provided for a secured revolving credit facility of up to $350.0 million of borrowings, $50.0 million of which is solely available to the German Borrower.

- added (2026-05-05):
[0001193125-26-205276:note_history:67]
As of March 31, 2026, the Company’s borrowings under the revolving line of credit were $25.0 million. The credit facilities provided under the Amended Credit Agreement mature in July 2027, but the U.S. Borrower may request extensions subject to customary conditions. In addition, the U.S. Borrower may utilize up to $50.0 million of the $350.0 million total revolving facility for the issuance of letters of credit. As of March 31, 2026, the U.S. Borrower had a total of $5.8 million in letters of credit under the Amended Credit Agreement, leaving a net amount (after giving effect to the $25.0 million of outstanding borrowings described above) of $319.2 million available for future borrowings, based on debt covenant compliance metrics. Any future credit extensions under the Amended Credit Agreement are subject to customary conditions precedent. The proceeds of any loans may be used as described above, as well as for working capital and other general corporate purposes.

- changed (2026-05-05):
[0001193125-26-205276:note_history:68]
Moreover, the Amended Credit Agreement provides for a sublimit under the existing $350.0 million revolving commitments in an aggregate amount of $50.0 million (“Subline”), which Subline is available for borrowings by the German Borrower. The Company had no borrowings under the Subline as of March 31, 2026. The existing swing line sublimit and letter of credit sublimit under the Amended Credit Agreement remain available to the U.S. Borrower (and not to the German Borrower). Otherwise, the loans under the Subline are subject to substantially the same terms and conditions under the Amended Credit Agreement (including with respect to the interest rate and maturity date) as the other existing revolving commitments.
  (was, 2025-11-04, similarity 0.9525):
[0001193125-25-264157:note_history:68]
Moreover, the Amended Credit Agreement provides for a sublimit under the existing $350.0 million revolving commitments in an aggregate amount of $50.0 million (“Subline”), which Subline is available for borrowings by the German Borrower. The existing swing line sublimit and letter of credit sublimit under the Amended Credit Agreement remain available to the U.S. Borrower (and not to the German Borrower). Otherwise, the loans under the Subline are subject to substantially the same terms and conditions under the Amended Credit Agreement (including with respect to the interest rate and maturity date) as the other existing revolving commitments.

- removed (2026-05-05):
[0001193125-25-264157:note_history:69]
On September 16, 2025, the U.S. Borrower, the German Borrower, and the lenders party thereto, including the Administrative Agent, entered into the Sixth Amendment and Consent to Credit Agreement, dated September 16, 2025 (“Amendment No. 6”; the Existing Credit Agreement as amended by Amendment No. 6, the “Amended Credit Agreement”). Amendment No. 6, among other things, (i) provides for a consent from the lenders to the issuance by the Company of new unsecured convertible indebtedness in an amount not to exceed $230.0 million, notwithstanding the cap on the amount of Permitted Convertible Indebtedness (as defined in the Amended Credit Agreement) the Company is permitted to incur, (ii) requires that the net cash proceeds of the new unsecured convertible indebtedness be used to (a) repay outstanding revolving credit loans under the Amended Credit Agreement, (b) pay fees, costs, and expenses related to Amendment No. 6 and the issuance of the new unsecured convertible indebtedness and (c) cash collateralize the obligations of the Company and its subsidiaries under the Amended Credit Agreement (with such cash only being permitted to be withdrawn for the purpose of financing the purchase of additional outstanding shares of Equity Interests (as defined in the Amended Credit Agreement) of the German Borrower that were not owned by the Company and its subsidiaries as of August 9, 2023 pursuant to Section 5, paragraph 1 of the DPLTA), and (iii) after the prepayment contemplated in the foregoing clause (ii)(a) and the provision of cash collateral contemplated in the foregoing clause (ii)(c), amends provisions governing the Subline (as defined below) to provide that future prepayments in respect of borrowings under the Subline will no longer permanently reduce the commitments in respect of the Subline. As of September 30, 2025, the Company had $7.5 million of cash collateral which is permitted to be withdrawn for the purpose of financing the purchase of additional outstanding shares of Adtran Networks stock as defined in the Amended Credit Agreement.

- removed (2026-05-05):
[0001193125-25-264157:note_history:70]
As of September 30, 2025, the Company’s borrowings under the revolving line of credit were $25.0 million, of which all was borrowed under the Subline by the German Borrower. The credit facilities provided under the Amended Credit Agreement mature in July 2027,

- removed (2026-05-05):
[0001193125-25-264157:note_history:71]
but the U.S. Borrower may request extensions subject to customary conditions. In addition, the U.S. Borrower may utilize up to $50.0 million of the $350.0 million total revolving facility for the issuance of letters of credit. As of September 30, 2025, the U.S. Borrower had a total of $5.8 million in letters of credit under the Amended Credit Agreement, leaving a net amount (after giving effect to the $25.0 million of outstanding borrowings described above) of $319.2 million available for future borrowings; however, as of September 30, 2025, the Company was limited to additional borrowings of $232.0 million based on debt covenant compliance metrics. Any future credit extensions under the Amended Credit Agreement are subject to customary conditions precedent. The proceeds of any loans may be used as described above, as well as for working capital and other general corporate purposes.

- removed (2026-05-05):
[0001193125-25-264157:note_history:72]
All U.S. borrowings under the Amended Credit Agreement bear interest at a rate tied to the Base Rate (as defined in the Amended Credit Agreement) or SOFR, at the Company’s option, and all E.U. borrowings bear interest at a rate tied to the Euro Interbank Offered Rate as administered by the European Money Markets Institute (or a comparable or successor administrator approved by the Administrative Agent), in each case plus applicable margins which vary based on the consolidated net leverage ratio of the Company and its subsidiaries as determined pursuant to the terms of the Amended Credit Agreement. Default interest is 2.00% per annum in excess of the rate otherwise applicable. As of September 30, 2025, the weighted average interest rate on our revolving credit agreements was 9.50%.

- removed (2026-05-05):
[0001193125-25-264157:note_history:73]
The Company made certain representations and warranties to the lenders in the Amended Credit Agreement that are customary for credit arrangements of this type. The Company also agreed to maintain a Consolidated Total Net Leverage Ratio of 5.00x, a Consolidated Senior Secured Net Leverage Ratio of 3.25x (4.0x to 3.5x during a “Springing Covenant Period,” as defined below) and a Consolidated Fixed Charge Coverage Ratio of 1.25x (as such ratios are defined in the Amended Credit Agreement). A “Springing Covenant Event” occurs when at least sixty percent (60.0%) of the outstanding shares of Adtran Networks that were not owned by the Company and its subsidiaries as of August 9, 2023 have been tendered and purchased by the Company. Upon the occurrence of a Springing Covenant Event, the Company will enter a “Springing Covenant Period”, defined as the fiscal quarter in which a Springing Covenant Event occurs and the three (3) consecutive fiscal quarters thereafter. During a Springing Covenant Period, the Company’s leverage ratios are increased. In addition, the cash and cash equivalents of the credit parties must be at least $50.0 million and the cash and cash equivalents of the Company and its subsidiaries must be at least $70.0 million. As of September 30, 2025, the Company was in compliance with all covenants.

- removed (2026-05-05):
[0001193125-25-264157:note_history:74]
The Amended Credit Agreement also contains customary events of default, such as misrepresentation and a default in the performance or observance of any covenant (subject to customary cure periods and materiality thresholds). Upon the occurrence and during the continuance of an event of default, the Administrative Agent is entitled to take various actions, including the acceleration of all amounts due under the Amended Credit Agreement.

- removed (2026-05-05):
[0001193125-25-264157:note_history:75]
All obligations under the Amended Credit Agreement (including under the Subline) are guaranteed by the U.S. Borrower and certain subsidiaries of the U.S. Borrower (“Full Facility Guarantors”). To secure such guarantees, the U.S. Borrower and the Full Facility Guarantors have granted security interests in favor of the Administrative Agent over substantially all of their tangible and intangible assets, and the U.S. Borrower has granted mortgages in favor of the Administrative Agent over certain owned real estate assets. Certain of the German Borrower's subsidiaries (the “Subline Guarantors”) have also provided a guarantee solely of the obligations in respect of the Subline. Furthermore, to secure such guarantees, the German Borrower and the Subline Guarantors have granted security interests in favor of the Administrative Agent over substantially all of their tangible and intangible assets. Upon repayment in full and termination of the Subline, the guarantees by the Subline Guarantors and the liens granted by the German Borrower and the Subline Guarantors to secure obligations under the Subline will be released.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2026-05-05):
[0001193125-26-205276:note_history:76]
5. INVESTMENTS
  (was, 2025-11-04, similarity 0.7222):
[0001193125-25-264157:note_history:76]
6. LONG TERM INVESTMENTS

- added (2026-05-05):
[0001193125-26-205276:note_history:77]
|  |  |  |  |  | Fair Value Measurements as of March 31, 2026 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket for IdenticalAssets (Level 1) |  |  | SignificantOtherObservableInputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds (1) |  | $ | 246 |  |  | $ | 246 |  |  | $ | — |  |  | $ | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities |  |  | 937 |  |  |  | 937 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 33,813 |  |  |  | 33,813 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 34,996 |  |  | $ | 34,996 |  |  | $ | — |  |  | $ | — |  |

- changed (2026-05-05):
[0001193125-26-205276:note_history:78]
|  |  |  |  | Fair Value Measurements as of December 31, 2025 Using |  |
| (In thousands) | Fair Value |  |  | Quoted Pricesin ActiveMarket for IdenticalAssets (Level 1) |  |  | SignificantOtherObservableInputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds (1) | $ | 245 |  |  | $ | 245 |  |  | $ | — |  |  | $ | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities |  | 1,022 |  |  |  | 1,022 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  | 35,174 |  |  |  | 35,174 |  |  |  | — |  |  |  | — |  |
| Total | $ | 36,441 |  |  | $ | 36,441 |  |  | $ | — |  |  | $ | — |  |
  (was, 2025-11-04, similarity 0.8453):
[0001193125-25-264157:note_history:78]
|  |  |  |  |  | Fair Value Measurements as of December 31, 2024 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket for IdenticalAssets (Level 1) |  |  | SignificantOtherObservableInputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds (1) |  | $ | 5,538 |  |  | $ | 5,538 |  |  | $ | — |  |  | $ | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities |  |  | 1,068 |  |  |  | 1,068 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 30,991 |  |  |  | 30,991 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 37,597 |  |  | $ | 37,597 |  |  | $ | — |  |  | $ | — |  |

- changed (2026-05-05):
[0001193125-26-205276:note_history:79]
(1) The money market fund balances of $0.2 million as of March 31, 2026 and December 31, 2025, are included in cash and cash equivalents on the balance sheet.
  (was, 2025-11-04, similarity 0.8793):
[0001193125-25-264157:note_history:79]
(1)
The money market fund balances of $0.2 million and $5.5 million as of September 30, 2025 and December 31, 2024, respectively, are included in cash and cash equivalents on the balance sheet.

- changed (2026-05-05):
[0001193125-26-205276:note_history:80]
 Level 2 – Significant inputs that are observable; values based on quoted prices in markets that are not active or model inputs that are observable either directly or indirectly and
  (was, 2025-11-04, similarity 0.9973):
[0001193125-25-264157:note_history:80]
 Level 2 – Significant inputs that are observable; values based on quoted prices in markets that are not active or model inputs that are observable either directly or indirectly; and

- removed (2026-05-05):
[0001193125-25-264157:note_history:81]
|  |  |  |  |  | Fair Value Measurements as of September 30, 2025 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket for IdenticalAssets (Level 1) |  |  | SignificantOtherObservableInputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds (1) |  | $ | 238 |  |  | $ | 238 |  |  | $ | — |  |  | $ | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities |  |  | 1,049 |  |  |  | 1,049 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 34,230 |  |  |  | 34,230 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 35,517 |  |  | $ | 35,517 |  |  | $ | — |  |  | $ | — |  |


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2026-05-05):
[0001193125-26-205276:note_history:82]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | March 31, 2026 |  |  | December 31, 2025 |  |
| Convertible senior notes |  | $ | 201,250 |  |  | $ | 201,250 |  |
| Less: unamortized debt issuance costs |  |  | (7,825 | ) |  |  | (8,212 | ) |
| Non-current convertible senior notes |  | $ | 193,425 |  |  | $ | 193,038 |  |

- changed (2026-05-05):
[0001193125-26-205276:note_history:83]
The estimated fair value of the 2030 Notes was $273.9 million and $217.5 million as of March 31, 2026 and December 31, 2025, respectively. The estimated fair value of the 2030 Notes, based on Level 2 inputs of the valuation hierarchy, were determined based on the quoted bid prices of the 2030 Notes in an over-the-counter market on the last trading day of the reporting period.
  (was, 2025-11-04, similarity 0.8937):
[0001193125-25-264157:note_history:83]
The estimated fair value of the 2030 Notes was $226.3 million as of September 30, 2025. The estimated fair value of the 2030 Notes, Level 2 inputs of the valuation hierarchy, were determined based on the quoted bid prices of the 2030 Notes in an over-the-counter market on the last trading day of the reporting period.

- changed (2026-05-05):
[0001193125-26-205276:note_history:84]
|  |  | Three Months Ended |  |
| (In thousands) |  | March 31, 2026 |  |
| Contractual interest |  | $ | 1,854 |  |
| Amortization of issuance costs |  |  | 387 |  |
| Total interest expense |  | $ | 2,241 |  |
  (was, 2025-11-04, similarity 0.9501):
[0001193125-25-264157:note_history:84]
|  |  | Three and Nine Months Ended |  |
| (In thousands) |  | September 30, 2025 |  |
| Contractual interest |  | $ | 227 |  |
| Amortization of issuance costs |  |  | 45 |  |
| Total interest expense |  | $ | 272 |  |

- changed (2026-05-05):
[0001193125-26-205276:note_history:85]
The 2030 Notes are convertible at the option of the holders of the 2030 Notes before June 15, 2030, only under the following circumstances: (1) during any calendar quarter (and only during such calendar quarter) commencing after the calendar quarter ending on December 31, 2025, if the last reported sale price per share of the Company’s common stock exceeds 130% of the conversion price for each of at least 20 trading days, whether or not consecutive, during the last 30 consecutive trading days ending on, and including, the last trading day of the immediately preceding calendar quarter; (2) during the five consecutive business days immediately after any 10 consecutive trading day period (such 10 consecutive trading day period, the “measurement period”) if the trading price per $1,000 principal amount of the 2030 Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price per share of our common stock on such trading day and the conversion rate on such trading day; (3) upon the occurrence of certain corporate events or distributions on the Company’s common stock; or (4) if the Company calls (or is deemed to have called) the 2030 Notes for redemption. From and after June 15, 2030, noteholders may convert their 2030 Notes at any time at their election until
  (was, 2025-11-04, similarity 0.8209):
[0001193125-25-264157:note_history:85]
The 2030 Notes are convertible at the option of the holders of the 2030 Notes before June 15, 2030, only under the following circumstances: (1) during any calendar quarter (and only during such calendar quarter) commencing after the calendar quarter ending on December 31, 2025, if the last reported sale price per share of the Company’s common stock exceeds 130% of the conversion price for each of at least 20 trading days, whether or not consecutive, during the 30 consecutive trading days ending on, and including, the last trading day of the immediately preceding calendar quarter; (2) during the five consecutive business days immediately after any 10 consecutive trading day period (such 10 consecutive trading day period, the “measurement period”) if the trading price per $1,000 principal amount of the 2030 Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price per share of our common stock on such trading day and the conversion rate on such trading day; (3) upon the occurrence of certain corporate events or distributions on the Company’s common stock; or (4) if the Company calls (or is deemed to have called) the 2030 Notes for redemption. From and after June 15, 2030, noteholders may convert their 2030 Notes at any time at their election until the close of business on the second scheduled trading day immediately before the maturity date. The Company will settle conversions by paying cash up to the aggregate principal amount of the 2030 Notes to be converted and paying or delivering, as applicable, cash, shares of its common stock or a combination of cash and shares of its common stock, at the Company’s election, in respect of the remainder, if any, of its conversion obligation in excess of the aggregate principal amount of the Notes being converted, based on the applicable conversion rate.

- added (2026-05-05):
[0001193125-26-205276:note_history:86]
the close of business on the second scheduled trading day immediately before the maturity date. The Company will settle conversions by paying cash up to the aggregate principal amount of the 2030 Notes to be converted and paying or delivering, as applicable, cash, shares of its common stock or a combination of cash and shares of its common stock, at the Company’s election, in respect of the remainder, if any, of its conversion obligation in excess of the aggregate principal amount of the Notes being converted, based on the applicable conversion rate.

- changed (2026-05-05):
[0001193125-26-205276:note_history:87]
The 2030 Notes will be redeemable, in whole or in part (subject to certain limitations described below), at the Company’s option at any time, and from time to time, on or after September 20, 2028 and on or before the 46th scheduled trading day immediately before the maturity date, but only if (i) the Notes are “Freely Tradable” (as defined in the Indenture) as of the date the Company sends the related redemption notice, and all accrued and unpaid additional interest, if any, has been paid in full as of the most recent interest payment date occurring on or before the date the Company sends the related redemption notice; and (ii) the last reported sale price per share of the Company’s common stock exceeds 130% of the conversion price on (1) each of at least 20 trading days, whether or not consecutive, during the last 30 consecutive trading days ending on, and including, the trading day immediately before the date the Company sends the related redemption notice; and (2) the trading day immediately before the date the Company sends such redemption notice. However, the Company may not redeem less than all of the outstanding Notes unless at least $70.0 million aggregate principal amount of Notes are outstanding and not called for redemption as of the time the Company sends, and after giving effect to, the related redemption notice. The redemption price will be a cash amount equal to the principal amount of the Notes to be redeemed, plus accrued and unpaid interest, if any, to, but excluding, the redemption date. In addition, calling (or the deemed calling of) any Note for redemption will constitute a “make-whole fundamental change” with respect to that Note, in which case the conversion rate applicable to the conversion of that Note will be increased in certain circumstances if it is converted during the related redemption conversion period. No sinking fund is provided for the 2030 Notes, which means the Company is not required to redeem or retire the 2030 Notes periodically.
  (was, 2025-11-04, similarity 0.9987):
[0001193125-25-264157:note_history:87]
The 2030 Notes will be redeemable, in whole or in part (subject to certain limitations described below), at the Company’s option at any time, and from time to time, on or after September 20, 2028 and on or before the 46th scheduled trading day immediately before the maturity date, but only if (i) the Notes are “Freely Tradable” (as defined in the Indenture) as of the date the Company sends the related redemption notice, and all accrued and unpaid additional interest, if any, has been paid in full as of the most recent interest payment date occurring on or before the date the Company sends the related redemption notice; and (ii) the last reported sale price per share of the Company’s common stock exceeds 130% of the conversion price on (1) each of at least 20 trading days, whether or not consecutive, during the 30 consecutive trading days ending on, and including, the trading day immediately before the date the Company sends the related redemption notice; and (2) the trading day immediately before the date the Company sends such redemption notice. However, the Company may not redeem less than all of the outstanding Notes unless at least $70.0 million aggregate principal amount of Notes are outstanding and not called for redemption as of the time the Company sends, and after giving effect to, the related redemption notice. The redemption price will be a cash amount equal to the principal amount of the Notes to be redeemed, plus accrued and unpaid interest, if any, to, but excluding, the redemption date. In addition, calling (or the deemed calling of) any Note for redemption will constitute a “make-whole fundamental change” with respect to that Note, in which case the conversion rate applicable to the conversion of that Note will be increased in certain circumstances if it is converted during the related redemption conversion period. No sinking fund is provided for the 2030 Notes, which means the Company is not required to redeem or retire the 2030 Notes periodically.

- changed (2026-05-05):
[0001193125-26-205276:note_history:88]
In connection with the pricing of the 2030 Notes and the exercise of the initial purchasers’ option to purchase additional 2030 Notes, the Company entered into privately negotiated capped call transactions with one of the initial purchasers of the 2030 Notes or its affiliate and certain other financial institutions pursuant to capped call confirmations (collectively, the “Capped Calls”). The premiums paid for the purchases of the Capped Calls were approximately $17.6 million. The Capped Calls have an initial strike price of approximately $11.52 per share, subject to certain adjustments substantially similar to those applicable to the corresponding 2030 Notes. The Capped Calls have an initial cap price of approximately $15.51 per share, subject to certain adjustments. The Capped Calls cover, subject to anti-dilution adjustments, approximately 17.5 million shares of the Company’s common stock.
  (was, 2025-11-04, similarity 0.8575):
[0001193125-25-264157:note_history:88]
In connection with the pricing of the 2030 Notes and the exercise of the initial purchasers’ option to purchase additional 2030 Notes, the Company entered into privately negotiated capped call transactions with one of the initial purchasers of the 2030 Notes or its affiliate and certain other financial institutions pursuant to capped call confirmations (collectively, the “Capped Calls”). The premiums paid for the purchases of the Capped Calls were approximately $17.6 million. The Capped Calls have an initial strike price of approximately $11.52 per share, subject to certain adjustments substantially similar to those applicable to the corresponding 2030 Notes. The Capped

- changed (2026-05-05):
[0001193125-26-205276:note_history:89]
The Capped Calls are separate transactions and are not part of the terms of the 2030 Notes. The Capped Calls do not meet the criteria for separate accounting as a derivative as they are indexed to the Company's stock and meet the requirements to be classified in equity and, as such, are not remeasured each reporting period.
  (was, 2025-11-04, similarity 0.7921):
[0001193125-25-264157:note_history:89]
The Capped Calls are separate transactions and are not part of the terms of the 2030 Notes. The Capped Calls do not meet the criteria for separate accounting as a derivative as they are indexed to the Company's stock and meet the requirements to be classified in equity and, as such, are not remeasured each reporting period. The premiums paid for the Capped Calls were included as a net reduction to additional paid-in capital within stockholders’ equity during the quarter ended September 30, 2025.

- removed (2026-05-05):
[0001193125-25-264157:note_history:90]
|  |  | As of |  |
| (In thousands) |  | September 30, 2025 |  |
| Convertible senior notes |  | $ | 201,250 |  |
| Less: unamortized debt issuance costs |  |  | (8,391 | ) |
| Non-current convertible senior notes |  | $ | 192,859 |  |

- removed (2026-05-05):
[0001193125-25-264157:note_history:91]
Calls have an initial cap price of approximately $15.51 per share, subject to certain adjustments. The Capped Calls cover, subject to anti-dilution adjustments, approximately 17.5 million shares of the Company’s common stock.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2026-05-05):
[0001193125-26-205276:note_history:92]
|  |  | Three Months Ended |  |
|  |  | March 31, 2026 |  |  | March 31, 2025 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Subscriber Solutions |  | $ | 90,193 |  |  | $ | 8,047 |  |  | $ | 98,240 |  |  | $ | 71,748 |  |  | $ | 8,662 |  |  | $ | 80,410 |  |
| Optical Networking Solutions |  |  | 70,952 |  |  |  | 26,374 |  |  |  | 97,326 |  |  |  | 54,622 |  |  |  | 23,576 |  |  |  | 78,198 |  |
| Access & Aggregation Solutions |  |  | 76,796 |  |  |  | 13,724 |  |  |  | 90,520 |  |  |  | 75,847 |  |  |  | 13,289 |  |  |  | 89,136 |  |
| Total |  | $ | 237,941 |  |  | $ | 48,145 |  |  | $ | 286,086 |  |  | $ | 202,217 |  |  | $ | 45,527 |  |  | $ | 247,744 |  |

- removed (2026-05-05):
[0001193125-25-264157:note_history:93]
|  |  | Three Months Ended |  |
|  |  | September 30, 2025 |  |  | September 30, 2024 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Subscriber Solutions |  | $ | 92,770 |  |  | $ | 8,368 |  |  | $ | 101,138 |  |  | $ | 81,060 |  |  | $ | 9,036 |  |  | $ | 90,096 |  |
| Access & Aggregation Solutions |  |  | 61,051 |  |  |  | 13,757 |  |  |  | 74,808 |  |  |  | 52,954 |  |  |  | 14,119 |  |  |  | 67,073 |  |
| Optical Networking Solutions |  |  | 78,722 |  |  |  | 24,767 |  |  |  | 103,489 |  |  |  | 47,474 |  |  |  | 23,061 |  |  |  | 70,535 |  |
| Total |  | $ | 232,543 |  |  | $ | 46,892 |  |  | $ | 279,435 |  |  | $ | 181,488 |  |  | $ | 46,216 |  |  | $ | 227,704 |  |

- removed (2026-05-05):
[0001193125-25-264157:note_history:94]
|  |  | Nine Months Ended |  |
|  |  | September 30, 2025 |  |  | September 30, 2024 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Subscriber Solutions |  | $ | 240,055 |  |  | $ | 25,252 |  |  | $ | 265,307 |  |  | $ | 215,044 |  |  | $ | 27,218 |  |  | $ | 242,262 |  |
| Access & Aggregation Solutions |  |  | 214,251 |  |  |  | 40,905 |  |  |  | 255,156 |  |  |  | 174,843 |  |  |  | 43,449 |  |  |  | 218,292 |  |
| Optical Networking Solutions |  |  | 199,952 |  |  |  | 71,832 |  |  |  | 271,784 |  |  |  | 152,068 |  |  |  | 67,246 |  |  |  | 219,314 |  |
| Total |  | $ | 654,258 |  |  | $ | 137,989 |  |  | $ | 792,247 |  |  | $ | 541,955 |  |  | $ | 137,913 |  |  | $ | 679,868 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2026-05-05):
[0001193125-26-205276:note_history:95]
2. REVENUE AND RECEIVABLES

- added (2026-05-05):
[0001193125-26-205276:note_history:96]
|  |  | Three Months Ended |  |
|  |  | March 31, 2026 |  |  | March 31, 2025 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Subscriber Solutions |  | $ | 90,193 |  |  | $ | 8,047 |  |  | $ | 98,240 |  |  | $ | 71,748 |  |  | $ | 8,662 |  |  | $ | 80,410 |  |
| Optical Networking Solutions |  |  | 70,952 |  |  |  | 26,374 |  |  |  | 97,326 |  |  |  | 54,622 |  |  |  | 23,576 |  |  |  | 78,198 |  |
| Access & Aggregation Solutions |  |  | 76,796 |  |  |  | 13,724 |  |  |  | 90,520 |  |  |  | 75,847 |  |  |  | 13,289 |  |  |  | 89,136 |  |
| Total |  | $ | 237,941 |  |  | $ | 48,145 |  |  | $ | 286,086 |  |  | $ | 202,217 |  |  | $ | 45,527 |  |  | $ | 247,744 |  |

- added (2026-05-05):
[0001193125-26-205276:note_history:97]
The aggregate amount of transaction price allocated to remaining performance obligations ("RPO") that have not been satisfied as of March 31, 2026 related to non-cancellable contractual maintenance agreements, non-cancellable contractual SaaS and subscription services, and non-cancellable hardware contracts amounted to $159.2 million. The majority of the Company's performance obligations will generally be satisfied within a year and any remaining performance obligations are typically recognized over one to three years.

- changed (2026-05-05):
[0001193125-26-205276:note_history:98]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | March 31, 2026 |  |  | December 31, 2025 |  |
| Accounts receivable, net |  | $ | 215,473 |  |  | $ | 210,687 |  |
| Contract assets(1) |  | $ | 533 |  |  | $ | 432 |  |
| Unearned revenue |  | $ | 90,752 |  |  | $ | 87,541 |  |
| Non-current unearned revenue |  | $ | 26,227 |  |  | $ | 27,143 |  |
  (was, 2025-11-04, similarity 0.9263):
[0001193125-25-264157:note_history:98]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | September 30, 2025 |  |  | December 31, 2024 |  |
| Accounts receivable, net |  | $ | 178,621 |  |  | $ | 178,030 |  |
| Contract assets(1) |  | $ | 360 |  |  | $ | 631 |  |
| Unearned revenue |  | $ | 57,563 |  |  | $ | 52,701 |  |
| Non-current unearned revenue |  | $ | 23,196 |  |  | $ | 22,065 |  |

- changed (2026-05-05):
[0001193125-26-205276:note_history:99]
(1)	Included in other receivables on the Condensed Consolidated Balance Sheets.
  (was, 2025-11-04, similarity 0.6018):
[0001193125-25-264157:note_history:99]
(1)	Included in other receivables.

- changed (2026-05-05):
[0001193125-26-205276:note_history:100]
The allowance for credit losses was $1.7 million and $1.3 million as of March 31, 2026, and December 31, 2025, respectively, related to accounts receivable.
  (was, 2025-11-04, similarity 0.8333):
[0001193125-25-264157:note_history:100]
The allowance for credit losses was $1.2 million and $1.3 million as of September 30, 2025 and December 31, 2024, respectively.

- changed (2026-05-05):
[0001193125-26-205276:note_history:101]
Receivables Purchase Agreements
  (was, 2025-11-04, similarity 0.9836):
[0001193125-25-264157:note_history:101]
Receivables Purchase Agreement

- changed (2026-05-05):
[0001193125-26-205276:note_history:102]
On July 1, 2024, the Company entered into a receivables purchase agreement (the “Factoring Agreement”) with a third-party financial institution (the “Factor”), which accelerates receivable collection and helps to better manage cash flow. Total accounts receivables factored as of the end of March 31, 2026, totaled $26.1 million of which $3.9 million was retained pursuant to the Factoring Agreement in the reserve account. Total accounts receivables factored as of the end of March 31, 2025, totaled $11.2 million of which $3.7 million was retained pursuant to the Factoring Agreement in the reserve account. The Factoring Agreement provides for up to $40.0 million in factoring capacity, subject to eligible receivables and reserve requirements, secured by the receivables.
  (was, 2025-11-04, similarity 0.7468):
[0001193125-25-264157:note_history:102]
On July 1, 2024, the Company entered into a receivables purchase agreement (the “Factoring Agreement”) with a third-party financial institution, which accelerates receivable collection and helps to better manage cash flow. Total accounts receivables factored as of the end of September 30, 2025, totaled $23.6 million net of $3.7 million retained pursuant to the Factoring Agreement in the reserve account. Total accounts receivables factored as of the end of September 30, 2024, totaled $16.7 million net of  $3.7 million retained pursuant to the Factoring Agreement in the reserve account. The Factoring Agreement provides for up to $40.0 million in factoring capacity, subject to eligible receivables and reserve requirements, secured by the receivables. The balance in the reserve account is included in other assets. The Company at its own expense does have collection and administrative responsibilities for the sold receivables and that is its only continuing involvement with the factoring party. The Company is not compensated for the servicing of the factoring program and deems the costs of servicing the receivables sold to be immaterial.

- added (2026-05-05):
[0001193125-26-205276:note_history:103]
During the three months ended March 31, 2026 and 2025, the Company received $51.8 million and $31.8 million, in cash proceeds from the Factoring Agreement, respectively. The cost of the Factoring Agreement is included in interest expense in the Condensed Consolidated Statements of Loss and totaled $0.5 million and $0.3 million for the three months ended March 31, 2026 and 2025, respectively.

- changed (2026-05-05):
[0001193125-26-205276:note_history:104]
No allowance for credit losses was recorded for the three months ended March 31, 2026 and 2025, respectively, related to contract assets.
  (was, 2025-11-04, similarity 0.9294):
[0001193125-25-264157:note_history:104]
No allowance for credit losses was recorded for the three and nine months ended September 30, 2025 and 2024, respectively, related to contract assets.

- added (2026-05-05):
[0001193125-26-205276:note_history:105]
Of the outstanding unearned revenue balances as of December 31, 2025, $23.1 million were recognized as revenue during the three months ended March 31, 2026. Of the $52.7 outstanding unearned revenue balances as of December 31, 2024, $21.9 million were recognized as revenue during the three months ended March 31, 2025.

- removed (2026-05-05):
[0001193125-25-264157:note_history:106]
3. REVENUE

- removed (2026-05-05):
[0001193125-25-264157:note_history:107]
|  |  | Three Months Ended |  |
|  |  | September 30, 2025 |  |  | September 30, 2024 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Subscriber Solutions |  | $ | 92,770 |  |  | $ | 8,368 |  |  | $ | 101,138 |  |  | $ | 81,060 |  |  | $ | 9,036 |  |  | $ | 90,096 |  |
| Access & Aggregation Solutions |  |  | 61,051 |  |  |  | 13,757 |  |  |  | 74,808 |  |  |  | 52,954 |  |  |  | 14,119 |  |  |  | 67,073 |  |
| Optical Networking Solutions |  |  | 78,722 |  |  |  | 24,767 |  |  |  | 103,489 |  |  |  | 47,474 |  |  |  | 23,061 |  |  |  | 70,535 |  |
| Total |  | $ | 232,543 |  |  | $ | 46,892 |  |  | $ | 279,435 |  |  | $ | 181,488 |  |  | $ | 46,216 |  |  | $ | 227,704 |  |

- removed (2026-05-05):
[0001193125-25-264157:note_history:108]
|  |  | Nine Months Ended |  |
|  |  | September 30, 2025 |  |  | September 30, 2024 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Subscriber Solutions |  | $ | 240,055 |  |  | $ | 25,252 |  |  | $ | 265,307 |  |  | $ | 215,044 |  |  | $ | 27,218 |  |  | $ | 242,262 |  |
| Access & Aggregation Solutions |  |  | 214,251 |  |  |  | 40,905 |  |  |  | 255,156 |  |  |  | 174,843 |  |  |  | 43,449 |  |  |  | 218,292 |  |
| Optical Networking Solutions |  |  | 199,952 |  |  |  | 71,832 |  |  |  | 271,784 |  |  |  | 152,068 |  |  |  | 67,246 |  |  |  | 219,314 |  |
| Total |  | $ | 654,258 |  |  | $ | 137,989 |  |  | $ | 792,247 |  |  | $ | 541,955 |  |  | $ | 137,913 |  |  | $ | 679,868 |  |

- removed (2026-05-05):
[0001193125-25-264157:note_history:109]
The aggregate amount of transaction price allocated to remaining performance obligations (“RPO”) that have not been satisfied as of September 30, 2025 related to non-cancellable contractual maintenance agreements, non-cancellable contractual SaaS and subscription services, and non-cancellable hardware contracts amounted to $174.0 million. The Company identified an immaterial error in its 2024 RPO disclosure of $325.7 million where it incorrectly included cancellable contracts and inappropriately applied the practical expedient under ASC 606. The Company has corrected the disclosure to remove the cancellable portion of RPO amounts and to reflect the impact of discontinuing the use of the practical expedient to exclude contracts with an original expected duration of one year or less. The corrected amount of the RPO is $185.4 million as of December 31, 2024. The Company will generally satisfy the remaining performance obligations as we transfer control of the products ordered or services to our customers, excluding maintenance services, which are satisfied over time.

- removed (2026-05-05):
[0001193125-25-264157:note_history:110]
During the three and nine months ended September 30, 2025, the Company received $49.2 million and $119.4 million, in cash proceeds from the Factoring Agreement, respectively, and during the three and nine months ended September 30, 2024, the Company received $39.9 million, in cash proceeds from the Factoring Agreement, which are recorded as a component of accounts receivable in operating cash flows on the Condensed Consolidated Statement of Cash Flows. The cost of the Factoring Agreement is included in interest expense in the Condensed Consolidated Statements of Loss and totaled $0.5 million and $0.3 million for the three months ended September, 30, 2025 and 2024, respectively, and $1.0 million and $0.3 million for the nine months ended September 30, 2025 and 2024, respectively.

- removed (2026-05-05):
[0001193125-25-264157:note_history:111]
On December 19, 2023, the Company entered into a receivables purchase agreement (the "Prior Factoring Agreement") with a third-party financial institution which qualified for treatment as a secured borrowing with a pledge of collateral under Accounting Standards Codification ("ASC") Topic 810, Consolidation. The Prior Factoring Agreement was terminated on July 1, 2024. For the nine months ended September 30, 2024, the Company incurred program fee expenses of $0.6 million.

- removed (2026-05-05):
[0001193125-25-264157:note_history:112]
Of the outstanding unearned revenue balances as of December 31, 2024, $9.3 million and $44.1 million were recognized as revenue during the three and nine months ended September 30, 2025, respectively. Of the $65.1 million of outstanding unearned revenue balances as of December 31, 2023, $10.03 million and $43.1 million were recognized as revenue during the three and nine months ended September 30, 2024, respectively.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: no_current_note, score: 0.0

- removed (2026-05-05):
[0001193125-25-264157:note_history:113]
21. SUBSEQUENT EVENTS

- removed (2026-05-05):
[0001193125-25-264157:note_history:114]
Termination of Deferred Compensation Plans

- removed (2026-05-05):
[0001193125-25-264157:note_history:115]
On November 3, 2025, in an effort to streamline the benefits offered to members of management and other key employees, the Company terminated its Deferred Compensation Program for Employees (the "Deferred Compensation Plan") and its Equity Deferral Program for Employees (together with the Deferred Compensation Plan, the "Plans"). The Plans are deferred compensation plans that have provided certain members of management or highly compensated employees, including certain of our named executive officers, with an opportunity to defer the receipt of a portion of their cash compensation, bonus, or other specified compensation. Each of the Plans has been maintained as an unfunded, nonqualified plan providing benefits based on the participant’s notional account balance at the time of retirement or separation, death or (with respect to the Deferred Compensation Plan) a change in control. The Company has also terminated its deferred compensation plans for its non-employee directors. See Part II, Item 5(a) of this report for additional information regarding the terminated deferred compensation plans.
