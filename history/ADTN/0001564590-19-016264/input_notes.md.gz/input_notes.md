# ADTN notes — 0001564590-19-016264


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001564590-19-016264:notes:1]
[same as prior period, unchanged from 0001564590-18-027351:notes:1]

[0001564590-19-016264:notes:2]
[same as prior period, unchanged from 0001564590-18-027351:notes:2]

[0001564590-19-016264:notes:3]
The accompanying unaudited consolidated financial statements of ADTRAN®, Inc. and its subsidiaries (“ADTRAN” or the “Company”) have been prepared pursuant to the rules and regulations for reporting on Quarterly Reports on Form 10-Q. Accordingly, certain information and notes required by generally accepted accounting principles for complete financial statements are not included herein. The December 31, 2018 Consolidated Balance Sheet is derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States.

[0001564590-19-016264:notes:4]
In the opinion of management, all adjustments necessary to fairly state these interim statements have been recorded and are of a normal and recurring nature. The results of operations for an interim period are not necessarily indicative of the results for the full year. The interim statements should be read in conjunction with the financial statements and notes thereto included in ADTRAN’s Annual Report on Form 10-K for the year ended December 31, 2018, filed on February 28, 2019 with the SEC.

[0001564590-19-016264:notes:5]
[same as prior period, unchanged from 0001564590-18-027351:notes:5]

[0001564590-19-016264:notes:6]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States of America requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenue and expense during the reporting period. Our more significant estimates include the obsolete and excess inventory reserves, warranty reserves, customer rebates, determination of the deferred and accrued revenue components of multiple element sales agreements, estimated costs to complete obligations associated with deferred and accrued revenue, estimated income tax provision and income tax contingencies, the fair value of stock-based compensation, impairment of goodwill, valuation and estimated lives of intangible assets, estimated pension liability, fair value of investments and the evaluation of other-than-temporary declines in the value of investments. Actual amounts could differ significantly from these estimates.

[0001564590-19-016264:notes:7]
[same as prior period, unchanged from 0001564590-18-027351:notes:7]

[0001564590-19-016264:notes:8]
In June 2016, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. ASU 2016-13 requires the measurement and recognition of expected credit losses for financial instruments held at amortized cost. In November 2018, the FASB issued ASU 2018-19, Codification Improvements to Topic 326 Financial Instruments – Credit Losses, that clarifies receivables arising from operating leases are not within the scope of the credit losses standard, but rather, should be accounted for in accordance with the leases standard. ASU 2016-13 and ASU 2018-19 are effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019, with early adoption permitted. We are currently evaluating the effect ASU 2016-13 and ASU 2018-19 will have on our consolidated financial statements.

[0001564590-19-016264:notes:9]
In January 2017, the FASB issued ASU 2017-04, Intangibles – Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment. ASU 2017-04 simplifies the measurement of goodwill by eliminating step 2 of the goodwill impairment test. Under ASU 2017-04, entities will be required to compare the fair value of a reporting unit to its carrying amount and recognize an impairment charge for the amount by which the carrying amount exceeds the reporting unit’s fair value. ASU 2017-04 is effective for annual or interim impairment tests performed in fiscal years beginning after December 15, 2019, with early adoption permitted for annual or interim impairment tests performed on testing dates after January 1, 2017. The amendments should be applied prospectively. We are currently evaluating whether to early adopt ASU 2017-04, but do not expect it will have a material effect on our consolidated financial statements.

[0001564590-19-016264:notes:10]
In August 2018, the FASB issued ASU 2018-13, Fair Value Measurement (Topic 820) Disclosure Framework-Changes to the Disclosure Requirements for Fair Value Measurement, which changes the fair value measurement disclosure requirements of ASC 820, Fair Value Measurement. The amendments in this ASU are the result of a broader disclosure project called, Concepts Statement No. 8 - Conceptual Framework for Financial Reporting — Chapter 8, Notes to Financial Statements, which the FASB finalized on August 28, 2018. The FASB used the guidance in the Concepts Statement to improve the effectiveness of ASC 820’s disclosure requirements. ASU 2018-13 provides users of financial statements with information about assets and liabilities measured at fair value in the statement of financial position or disclosed in the notes to the financial statements. More specifically ASU 2018-13 requires disclosures about the valuation techniques and inputs that are used to arrive at measures of fair value, including judgments and assumptions that are made in determining fair value. In addition, ASU 2018-13 requires disclosures regarding the uncertainty in the fair value measurements as of the reporting date and how changes in fair value measurements affect performance and cash flows. ASU 2018-13 is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. We are currently evaluating the effect of ASU 2018-13, but do not expect it will have a material effect on our financial statement disclosures.

[0001564590-19-016264:notes:11]
In August 2018, the FASB issued ASU 2018-14, Compensation-Retirement Benefits-Defined Benefit Plans-General (Subtopic 715-20): Disclosure Framework-Changes to the Disclosure Requirements for Defined Benefit Plans, which makes changes to and clarifies the disclosure requirements related to defined benefit pension and other postretirement plans. ASU 2018-14 requires additional disclosures related to the reasons for significant gains and losses affecting the benefit obligation and an explanation of any other significant changes in the benefit obligation or plan assets that are not otherwise apparent in other disclosures required by ASC 715. ASU 2018-14 also clarifies the guidance in ASC 715 to require disclosure of the projected benefit obligation (PBO) and fair value of plan assets for pension plans with PBOs in excess of plan assets and the accumulated benefit obligation (ABO) and fair value of plan assets for pension plans with ABOs in excess of plan assets. ASU 2018-14 is effective for public business entities for fiscal years ending after December 15, 2020. We are currently evaluating the effect of ASU 2018-14, but do not expect it will have a material effect on our financial statement disclosures.

[0001564590-19-016264:notes:12]
In August 2018, the FASB issued ASU 2018-15, Intangibles-Goodwill and Other-Internal-Use Software (Subtopic 350-40), Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract.  ASU 2018-15 clarifies certain aspects of ASU 2015-05, Customer’s Accounting for Fees Paid in a Cloud Computing Arrangement. Specifically, ASU 2018-15 aligns the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementations costs incurred to develop or obtain internal use software. ASU 2018-15 is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019, with early adoption permitted. We are currently evaluating the effect of ASU 2018-15, but do not expect it will have a material effect on our consolidated financial statements.

[0001564590-19-016264:notes:13]
During 2019, we adopted the following accounting standards, which had the following effects on our consolidated financial statements:

[0001564590-19-016264:notes:14]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842). ASU 2016-02 requires an entity to recognize right-of-use assets and lease liabilities on the balance sheet and to disclose key information about the entity’s leasing arrangements. In July 2018, the FASB issued ASU 2018-10, Codification Improvements to Topic 842, Leases, which clarified certain aspects of ASU 2016-02, as well as, ASU 2018-11, Leases (Topic 842), Targeted Improvements, which provided for an optional transition method which allowed for the application of the legacy lease guidance, including its disclosure requirements, for the comparative periods presented in the year of adoption, with the cumulative effect of initially applying the new lease standard recognized as an adjustment to retained earnings as of the date of adoption. In March 2019, the FASB issued ASU 2019-01, Leases (Topic 824) Codification Improvements, which removed the requirement for an entity to disclose in the interim periods after adoption, the effect of the change on income from continuing operations, net income, any other affected financial statement line item, and any affected per share amount. For lessors, the new leasing standard requires leases to be classified as a sales-type, direct financing or operating leases. These criteria focus on the transfer of control of the underlying lease asset. This standard and related updates were effective for fiscal years beginning after December 15, 2018, and interim periods within those fiscal years.

[0001564590-19-016264:notes:15]
The Company adopted the new standard on January 1, 2019, the effective date of our initial application, using the optional transition method. The Company has elected to carry forward the legacy (ASC 840) disclosures for comparative periods and therefore, did not adjust the comparative period financial information prior to January 1, 2019. In addition, the Company elected the package of practical expedients which allows for companies to not reassess whether any expired or existing contracts are or contain leases, not reassess historical lease classifications for expired or existing contracts and not reassess initial direct costs for existing leases. Additionally, the Company elected the practical expedients which allow the use of hindsight when determining the lease term, the short-term lease recognition exemption and the option to not separate lease and non-lease components. The adoption of this standard resulted in the recognition of a right-of-use asset and corresponding right-of-use liability on our Consolidated Balance Sheet of $10.3 million, mainly related to our operating leases for office space, automobiles and other equipment.

[0001564590-19-016264:notes:16]
As a lessee, the adoption of this standard did not have a material impact on our Consolidated Statement of Income or Statement of Cash Flow. See Note 12 for additional information.

[0001564590-19-016264:notes:17]
As a lessor, the adoption of this standard did not have a material impact on the Company’s Consolidated Balance Sheet, Consolidated Statement of Income or Statement of Cash Flow. Prior to and after adoption, all of our leases in which we are the lessor were classified as sales-types leases.

[0001564590-19-016264:notes:18]
In March 2017, the FASB issued ASU 2017-08, Receivables – Nonrefundable Fees and Other Costs (Subtopic 310-20): Premium Amortization on Purchased Callable Debt Securities, which shortened the amortization period for the premium on certain purchased callable debt securities to the earliest call date. ASU 2017-08 was effective for fiscal years and interim periods within those fiscal years, beginning after December 15, 2018. The amendments were required to be applied through a modified-retrospective transition approach that required a cumulative-effect adjustment directly to retained earnings as of the beginning of the period of adoption. The Company adopted ASU 2017-08 on January 1, 2019, and the adoption of this standard did not have a material effect on our consolidated financial statements.

[0001564590-19-016264:notes:19]
In August 2017, the FASB issued ASU 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities. ASU 2017-12 expanded and refined hedge accounting for both financial and non-financial risk components, aligned the recognition and presentation of the effects of hedging instruments and hedge items in the financial statements, and included certain targeted improvements to ease the application of current guidance related to the assessment of hedge effectiveness.  In October 2018, the FASB issued ASU 2018-16, Derivatives and Hedging (Topic 815): Inclusion of the Secured Overnight Financing Rate (SOFR) Overnight Index Swap (OIS) Rate as a Benchmark Interest Rate for Hedge Accounting, which permits the OIS rate based on SOFR as a U.S. benchmark interest rate. Both ASU 2017-12 and ASU 2018-16 were effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2018. The Company adopted ASU 2017-12 on January 1, 2019, and the adoption of this standard did not have a material effect on our consolidated financial statements as we currently do not have any hedging instruments.

[0001564590-19-016264:notes:20]
In February 2018, the FASB issued ASU 2018-02, Income Statement – Reporting Comprehensive Income (Topic 220): Reclassification of Certain Tax Effects from Accumulated Comprehensive Income. ASU 2018-02 allowed for an optional reclassification from accumulated other comprehensive income to retained earnings for stranded tax effects resulting from the Tax Cuts and Jobs Act of 2017. ASU 2018-02 was effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2018. The Company adopted ASU 2018-02 on January 1, 2019, and upon adoption reclassified $0.4 million of stranded tax effects created by rate changes related to the Tax Cuts and Jobs Act of 2017 to retained earnings. See Note 13 for additional information.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001564590-19-016264:notes:21]
[same as prior period, unchanged from 0001564590-18-027351:notes:29]

[0001564590-19-016264:notes:22]
On November 30, 2018, we acquired SmartRG, Inc., a provider of carrier-class, open-source connected home platforms and cloud services for broadband service providers in exchange for cash consideration. This transaction was accounted for as a business combination. We have included the financial results of this acquisition in our consolidated financial statements since the date of acquisition. This revenue is included in the Subscriber Solutions & Experience category within the Network Solutions and Services & Support reportable segments.

[0001564590-19-016264:notes:23]
Contingent liabilities with a fair value totaling $1.2 million were recognized at the acquisition date, the payments of which are dependent upon SmartRG achieving future revenue, EBIT or customer purchase order milestones during the first half of 2019. The contingent payments are subject to arbitration and the final payouts, if applicable, are expected to occur during the third quarter of 2019. The minimum and maximum potential payment under the total of the contingent liabilities ranges from no payment to $1.5 million. As of March 31, 2019, the fair value of the contingent liability was re-assessed and was determined to be $1.2 million, based on the expected probable outcomes. No change in fair value was recognized during the three months ended March 31, 2019.

[0001564590-19-016264:notes:24]
An escrow in the amount of $2.8 million was set up at the acquisition date, to fund post-closing working capital settlements and to indemnify the Company from any inaccuracy or breach of representations, warranties, covenants, agreements or obligations of the sellers. The escrow is subject to arbitration with final settlement expected during the fourth quarter of 2020. The minimum and maximum potential release of funds to the seller ranges from no payment to $2.8 million.

[0001564590-19-016264:notes:25]
We recorded goodwill of $3.5 million as a result of this acquisition, which represents the excess of the purchase price over the fair value of net assets acquired. We assessed the recognition and measurement of the assets acquired and liabilities assumed based on historical and forecasted data for future periods and concluded that our valuation procedures and resulting measures were appropriate.

[0001564590-19-016264:notes:26]
On March 19, 2018, we acquired Sumitomo Electric Lightwave Corp.’s (SEL) North American EPON business and entered into a technology license and OEM supply agreement with Sumitomo Electric Industries, Ltd. (SEI). This transaction was accounted for as a business combination. We have included the financial results of this acquisition in our consolidated financial statements since the date of acquisition. This revenue is included in the Access & Aggregation and Subscriber Solutions & Experience categories within the Network Solutions reportable segment.

[0001564590-19-016264:notes:27]
We recorded a bargain purchase gain, net of income taxes, of $11.3 million during the first quarter of 2018, which represents the difference between the fair value of the net assets acquired over the cash paid. We assessed the recognition and measurement of the assets acquired and liabilities assumed based on historical and forecasted data for future periods and concluded that our valuation procedures and resulting measures were appropriate.

[0001564590-19-016264:notes:28]
The final allocation of the purchase price to the estimated fair value of the assets acquired and liabilities assumed at the acquisition date for SmartRG and Sumitomo are as follows:

[0001564590-19-016264:notes:29]
| (In thousands) |  | SmartRG |  |  | Sumitomo |  |
| Assets |  |  |  |  |  |  |  |  |
| Tangible assets acquired |  | $ | 8,594 |  |  | $ | 1,006 |  |
| Intangible assets |  |  | 9,960 |  |  |  | 22,100 |  |
| Goodwill |  |  | 3,489 |  |  |  | — |  |
| Total assets acquired |  |  | 22,043 |  |  |  | 23,106 |  |
| Liabilities |  |  |  |  |  |  |  |  |
| Liabilities assumed |  |  | (6,001 | ) |  |  | (3,978 | ) |
| Total liabilities assumed |  |  | (6,001 | ) |  |  | (3,978 | ) |
| Total net assets |  |  | 16,042 |  |  |  | 19,128 |  |
| Gain on bargain purchase of a business, net of tax |  |  | — |  |  |  | (11,322 | ) |
| Total purchase price |  | $ | 16,042 |  |  | $ | 7,806 |  |

[0001564590-19-016264:notes:30]
The actual revenue and net loss included in the Consolidated Statements of Income for SmartRG and Sumitomo for the three months ended March 31, 2019 and from March 19, 2018 to March 31, 2018 are as follows:

[0001564590-19-016264:notes:31]
|  |  | Three Months Ended |  |  | March 19 to |  |
| (In thousands) |  | March 31, 2019 |  |  | March 31, 2018 |  |
| Revenue |  | $ | 7,348 |  |  | $ | — |  |
| Net loss |  | $ | (1,684 | ) |  | $ | (77 | ) |

[0001564590-19-016264:notes:32]
The details of the acquired intangible assets from these acquisitions are as follows:

[0001564590-19-016264:notes:33]
| (In thousands) | Value |  |  | Life (years) |
| Customer relationships | $ | 15,190 |  |  | 3 – 12 |
| Developed technology |  | 7,400 |  |  | 7 |
| Licensed technology |  | 5,900 |  |  | 9 |
| Supplier relationship |  | 2,800 |  |  | 2 |
| Licensing agreements |  | 560 |  |  | 5 – 10 |
| Trade name |  | 210 |  |  | 3 |
| Total | $ | 32,060 |  |  |  |

[0001564590-19-016264:notes:34]
The following unaudited supplemental pro forma information presents the financial results of the Company as if the acquisition of SmartRG and Sumitomo had occurred on January 1, 2018. This unaudited supplemental pro forma information does not purport to be indicative of what would have occurred had the acquisition been completed on January 1, 2018, nor is it indicative of any future results. Aside from revising the 2018 net income for the effect of the bargain purchase gain, there were no material, non-recurring adjustments to this unaudited pro forma information.

[0001564590-19-016264:notes:35]
| (In thousands) |  | For the Three Months Ended March 31, 2018 |  |
| Pro forma revenue |  | $ | 129,584 |  |
| Pro forma net loss |  | $ | (23,400 | ) |
| Pro forma loss per share - basic |  | $ | (0.49 | ) |
| Pro forma loss per share - diluted |  | $ | (0.49 | ) |

[0001564590-19-016264:notes:36]
For the three months ended March 31, 2019 and 2018, we incurred acquisition and integration related expenses and amortization of acquired intangibles of $1.3 million and $0.2 million respectively, related to these acquisitions.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001564590-19-016264:notes:37]
[same as prior period, unchanged from 0001564590-18-027351:notes:41]

[0001564590-19-016264:notes:38]
[same as prior period, unchanged from 0001564590-18-027351:notes:43]

[0001564590-19-016264:notes:39]
[same as prior period, unchanged from 0001564590-18-027351:notes:44]

[0001564590-19-016264:notes:40]
Network Solutions includes hardware products and software-defined next-generation virtualized solutions used in service provider or business networks, as well as prior generation products. The majority of the revenue from this segment is from hardware sales. In certain transactions, we are also the lessor in sales-type lease arrangements for network equipment. These arrangements typically include network equipment, network implementation services and maintenance services. See Note 12 for additional information.

[0001564590-19-016264:notes:41]
[same as prior period, unchanged from 0001564590-18-027351:notes:49]

[0001564590-19-016264:notes:42]
To complement our Network Solutions segment, we offer a complete portfolio of maintenance, network implementation and solutions integration and managed services, which include hosted cloud services and subscription services.

[0001564590-19-016264:notes:43]
In addition to our reporting segments, we also report revenue in the following three categories – Access & Aggregation, Subscriber Solutions & Experience, and Traditional & Other Products.

[0001564590-19-016264:notes:44]
The following table disaggregates our revenue by major source for the three months ended March 31, 2019:

[0001564590-19-016264:notes:45]
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 85,673 |  |  | $ | 14,105 |  |  | $ | 99,778 |  |
| Subscriber Solutions & Experience(1) |  |  | 34,719 |  |  |  | 2,034 |  |  |  | 36,753 |  |
| Traditional & Other Products |  |  | 5,430 |  |  |  | 1,830 |  |  |  | 7,260 |  |
| Total |  | $ | 125,822 |  |  | $ | 17,969 |  |  | $ | 143,791 |  |

[0001564590-19-016264:notes:46]
|  | (1) | Subscriber Solutions & Experience was formerly reported as Customer Devices. With the increasing focus on enhancing the customer experience for both our business and consumer broadband customers and the addition of SmartRG during the fourth quarter of 2018, Subscriber Solutions & Experience more accurately represents this revenue category. |

[0001564590-19-016264:notes:47]
The following table disaggregates our revenue by major source for the three months ended March 31, 2018:

[0001564590-19-016264:notes:48]
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 69,385 |  |  | $ | 12,295 |  |  | $ | 81,680 |  |
| Subscriber Solutions & Experience(1) |  |  | 28,777 |  |  |  | 1,324 |  |  |  | 30,101 |  |
| Traditional & Other Products |  |  | 7,091 |  |  |  | 1,934 |  |  |  | 9,025 |  |
| Total |  | $ | 105,253 |  |  | $ | 15,553 |  |  | $ | 120,806 |  |

[0001564590-19-016264:notes:49]
As of March 31, 2019, we did not have any significant performance obligations related to customer contracts that had an original expected duration of one year or more, other than maintenance services, which are satisfied over time.

[0001564590-19-016264:notes:50]
The following table provides information about receivables, contract assets and unearned revenue from contracts with customers:

[0001564590-19-016264:notes:51]
| (In thousands) |  | March 31, 2019 |  |  | December 31, 2018 |  |
| Accounts receivable, net |  | $ | 99,032 |  |  | $ | 99,385 |  |
| Contract assets |  | $ | 2,333 |  |  | $ | 3,766 |  |
| Unearned revenue |  | $ | 15,230 |  |  | $ | 17,940 |  |
| Non-current unearned revenue |  | $ | 4,514 |  |  | $ | 5,296 |  |

[0001564590-19-016264:notes:52]
$6.9 million of the outstanding unearned revenue balance at December 31, 2018 was recognized as revenue during the three months ended March 31, 2019.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0001564590-19-016264:notes:53]
The table below presents sales information by category for the three months ended March 31, 2019 and 2018:

[0001564590-19-016264:notes:54]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2019 |  |  | 2018 |  |
| Access & Aggregation |  | $ | 99,778 |  |  | $ | 81,680 |  |
| Subscriber Solutions & Experience |  |  | 36,753 |  |  |  | 30,101 |  |
| Traditional & Other Products |  |  | 7,260 |  |  |  | 9,025 |  |
| Total |  | $ | 143,791 |  |  | $ | 120,806 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-19-016264:notes:55]
[same as prior period, unchanged from 0001564590-18-027351:notes:63]

[0001564590-19-016264:notes:56]
Our effective tax rate increased from an expense of 15.1%, excluding the tax effect of the bargain purchase gain, in the three months ended March 31, 2018, to an expense of 28.6% in the three months ended March 31, 2019. The increase in the effective tax rate between the two periods is primarily driven by the shift to profitability in the current quarter.

[0001564590-19-016264:notes:57]
The Company continually reviews the adequacy of the valuation allowance and recognizes the benefits of deferred tax assets only as the reassessment indicates that it is more likely than not that the deferred tax assets will be recognized in accordance with ASC 740, Income Taxes (ASC 740). As of March 31, 2019, we had net deferred tax assets of $36.9 million. Since management continues to assess the realization of these deferred tax assets and related valuation allowance(s), as such, we may release a portion of the valuation allowance or establish a new valuation allowance based on operations in the jurisdictions in which these assets arose. Our assessment includes the evaluation of evidence, some of which requires significant judgment, including historical operating results, the evaluation of three-year cumulative income, future taxable income and tax planning strategies. Should management determine a valuation allowance is needed in the future due to not being able to absorb loss carryforwards, it could have a material effect on our consolidated financial statements.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001564590-19-016264:notes:58]
[same as prior period, unchanged from 0001564590-18-027351:notes:65]

[0001564590-19-016264:notes:59]
[same as prior period, unchanged from 0001564590-18-027351:notes:66]

[0001564590-19-016264:notes:60]
The following table summarizes the components of net periodic pension cost for the three months ended March 31, 2019 and 2018:

[0001564590-19-016264:notes:61]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2019 |  |  | 2018 |  |
| Service cost |  | $ | 375 |  |  | $ | 308 |  |
| Interest cost |  |  | 162 |  |  |  | 187 |  |
| Expected return on plan assets |  |  | (355 | ) |  |  | (399 | ) |
| Amortization of actuarial losses |  |  | 203 |  |  |  | 64 |  |
| Net periodic pension cost |  | $ | 385 |  |  | $ | 160 |  |

[0001564590-19-016264:notes:62]
The components of net periodic pension cost other than the service cost component are included in other income (expense), net in the Consolidated Statements of Income. Service cost are included in cost of sales, selling, general and administrative expenses and research and development expenses in the Consolidated Statements of Income.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-19-016264:notes:63]
[same as prior period, unchanged from 0001564590-18-027351:notes:70]

[0001564590-19-016264:notes:64]
The following table summarizes stock-based compensation expense related to stock options, performance stock units (PSUs), restricted stock units (RSUs) and restricted stock for the three months ended March 31, 2019 and 2018, which was recognized as follows:

[0001564590-19-016264:notes:65]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2019 |  |  | 2018 |  |
| Stock-based compensation expense included in cost of sales |  | $ | 104 |  |  | $ | 95 |  |
| Selling, general and administrative expense |  |  | 1,063 |  |  |  | 1,035 |  |
| Research and development expense |  |  | 692 |  |  |  | 689 |  |
| Stock-based compensation expense included in operating expenses |  |  | 1,755 |  |  |  | 1,724 |  |
| Total stock-based compensation expense |  |  | 1,859 |  |  |  | 1,819 |  |
| Tax benefit for expense associated with non-qualified options, PSUs, RSUs and restricted stock |  |  | (443 | ) |  |  | (384 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 1,416 |  |  | $ | 1,435 |  |

[0001564590-19-016264:notes:66]
[same as prior period, unchanged from 0001564590-18-027351:notes:73]

[0001564590-19-016264:notes:67]
The following table is a summary of our stock options outstanding as of December 31, 2018 and March 31, 2019, and the changes that occurred during the three months ended March 31, 2019:

[0001564590-19-016264:notes:68]
|  |  | Number of Stock Options (in thousands) |  |  | Weighted Avg. Exercise Price (per share) |  |  | Weighted Avg. Remaining Contractual Life (in years) |  |  | Aggregate Intrinsic Value (in thousands) |  |
| Stock options outstanding, December 31, 2018 |  |  | 4,382 |  |  | $ | 22.91 |  |  |  | 4.10 |  |  | $ | — |  |
| Stock options granted |  |  | — |  |  | $ | — |  |  |  |  |  |  |  |  |  |
| Stock options exercised |  |  | — |  |  | $ | — |  |  |  |  |  |  |  |  |  |
| Stock options forfeited |  |  | (8 | ) |  | $ | 15.33 |  |  |  |  |  |  |  |  |  |
| Stock options expired |  |  | (33 | ) |  | $ | 23.13 |  |  |  |  |  |  |  |  |  |
| Stock options outstanding, March 31, 2019 |  |  | 4,341 |  |  | $ | 22.93 |  |  |  | 3.80 |  |  | $ | — |  |
| Stock options exercisable, March 31, 2019 |  |  | 4,098 |  |  | $ | 23.37 |  |  |  | 3.63 |  |  | $ | — |  |

[0001564590-19-016264:notes:69]
At March 31, 2019, total unrecognized compensation expense related to non-vested stock options was approximately $0.6 million, which is expected to be recognized over an average remaining recognition period of 0.7 years.

[0001564590-19-016264:notes:70]
All of the options above were issued at exercise prices that approximated fair market value at the date of grant. At March 31, 2019, 2.4 million options were available for grant under the shareholder-approved plans.

[0001564590-19-016264:notes:71]
The aggregate intrinsic values in the table above represent the total pre-tax intrinsic value (the difference between ADTRAN’s closing stock price on the last trading day of the quarter and the exercise price, multiplied by the number of in-the-money options) that would have been received by the option holders had all option holders exercised their options on March 31, 2019. The amount of aggregate intrinsic value will change based on the fair market value of ADTRAN’s stock. The total pre-tax intrinsic value of options exercised during the three months ended March 31, 2019 was zero.

[0001564590-19-016264:notes:72]
The fair value of our stock options is estimated using the Black-Scholes model. The determination of the fair value of stock options on the date of grant using the Black-Scholes model is affected by our stock price, as well as assumptions regarding a number of complex and subjective variables that may have a significant impact on the fair value estimate. The stock option pricing model requires the use of several assumptions that impact the fair value estimate. These variables include, but are not limited to, the volatility of our stock price and employee exercise behaviors.

[0001564590-19-016264:notes:73]
There were no stock options granted during the three months ended March 31, 2019 or 2018.

[0001564590-19-016264:notes:74]
[same as prior period, unchanged from 0001564590-18-027351:notes:81]

[0001564590-19-016264:notes:75]
The following table is a summary of our PSUs, RSUs and restricted stock outstanding as of December 31, 2018 and the changes that occurred during the three months ended March 31, 2019:

[0001564590-19-016264:notes:76]
|  |  | Number of Shares (in thousands) |  |  | Weighted Avg. Grant Date Fair Value (per share) |  |
| Unvested PSUs, RSUs and restricted stock outstanding, December 31, 2018 |  |  | 1,570 |  |  | $ | 18.52 |  |
| PSUs, RSUs and restricted stock granted |  |  | 59 |  |  | $ | 12.54 |  |
| PSUs, RSUs and restricted stock vested |  |  | (1 | ) |  | $ | 18.86 |  |
| PSUs, RSUs and restricted stock forfeited |  |  | (44 | ) |  | $ | 17.88 |  |
| Unvested PSUs, RSUs and restricted stock outstanding, March 31, 2019 |  |  | 1,584 |  |  | $ | 18.32 |  |

[0001564590-19-016264:notes:77]
The fair value of our PSUs with market conditions is calculated using a Monte Carlo simulation valuation method. The fair value of RSUs and restricted stock is equal to the closing price of our stock on the business day immediately preceding the grant date.

[0001564590-19-016264:notes:78]
At March 31, 2019, total unrecognized compensation expense related to the non-vested portion of market-based PSUs, RSUs and restricted stock was approximately $16.1 million, which is expected to be recognized over an average remaining recognition period of 2.8 years. In addition, there was $9.0 million of unrecognized compensation expense related to the unvested 2017 performance-based PSUs, which will be recognized over the remaining requisite service period of 0.8 years if achievement of the performance obligation becomes probable. For the three months ending March 31, 2019 and 2018, no compensation expense was recognized related to these performance-based PSUs.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001564590-19-016264:notes:79]
7. INVESTMENTS

[0001564590-19-016264:notes:80]
Debt Securities and Other Investments

[0001564590-19-016264:notes:81]
At March 31, 2019, we held the following debt securities and other investments, recorded at either fair value or cost:

[0001564590-19-016264:notes:82]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Carrying |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 15,964 |  |  | $ | 69 |  |  | $ | (24 | ) |  | $ | 16,009 |  |
| Municipal fixed-rate bonds |  |  | 951 |  |  |  | — |  |  |  | (13 | ) |  |  | 938 |  |
| Asset-backed bonds |  |  | 7,171 |  |  |  | 13 |  |  |  | (9 | ) |  |  | 7,175 |  |
| Mortgage/Agency-backed bonds |  |  | 4,561 |  |  |  | 6 |  |  |  | (26 | ) |  |  | 4,541 |  |
| U.S. government bonds |  |  | 4,238 |  |  |  | — |  |  |  | (11 | ) |  |  | 4,227 |  |
| Foreign government bonds |  |  | 2,159 |  |  |  | — |  |  |  | (2 | ) |  |  | 2,157 |  |
| Available-for-sale debt securities held at fair value |  | $ | 35,044 |  |  | $ | 88 |  |  | $ | (85 | ) |  | $ | 35,047 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 25,600 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1,180 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 61,827 |  |

[0001564590-19-016264:notes:83]
At December 31, 2018, we held the following debt securities and other investments, recorded at either fair value or cost:

[0001564590-19-016264:notes:84]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Carrying |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 20,777 |  |  | $ | 19 |  |  | $ | (112 | ) |  | $ | 20,684 |  |
| Municipal fixed-rate bonds |  |  | 1,339 |  |  |  | — |  |  |  | (26 | ) |  |  | 1,313 |  |
| Asset-backed bonds |  |  | 5,230 |  |  |  | 5 |  |  |  | (14 | ) |  |  | 5,221 |  |
| Mortgage/Agency-backed bonds |  |  | 3,833 |  |  |  | 2 |  |  |  | (44 | ) |  |  | 3,791 |  |
| U.S. government bonds |  |  | 9,271 |  |  |  | 1 |  |  |  | (66 | ) |  |  | 9,206 |  |
| Foreign government bonds |  |  | 592 |  |  |  | — |  |  |  | (8 | ) |  |  | 584 |  |
| Available-for-sale debt securities held at fair value |  | $ | 41,042 |  |  | $ | 27 |  |  | $ | (270 | ) |  | $ | 40,799 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 25,600 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 397 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 66,796 |  |

[0001564590-19-016264:notes:85]
As of March 31, 2019, our debt securities had the following contractual maturities:

[0001564590-19-016264:notes:86]
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset- backed bonds |  |  | Mortgage / Agency- backed bonds |  |  | U.S. government bonds |  |  | Foreign government bonds |  |
| Less than one year |  | $ | 3,127 |  |  | $ | — |  |  | $ | 872 |  |  | $ | — |  |  | $ | 1,691 |  |  | $ | — |  |
| One to two years |  |  | 8,389 |  |  |  | — |  |  |  | 387 |  |  |  | 289 |  |  |  | — |  |  |  | 1,196 |  |
| Two to three years |  |  | 4,493 |  |  |  | 938 |  |  |  | 976 |  |  |  | — |  |  |  | 1,324 |  |  |  | 961 |  |
| Three to five years |  |  | — |  |  |  | — |  |  |  | 3,105 |  |  |  | 827 |  |  |  | 1,212 |  |  |  | — |  |
| Five to ten years |  |  | — |  |  |  | — |  |  |  | 1,038 |  |  |  | 303 |  |  |  | — |  |  |  | — |  |
| More than ten years |  |  | — |  |  |  | — |  |  |  | 797 |  |  |  | 3,122 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 16,009 |  |  | $ | 938 |  |  | $ | 7,175 |  |  | $ | 4,541 |  |  | $ | 4,227 |  |  | $ | 2,157 |  |

[0001564590-19-016264:notes:87]
Actual maturities may differ from contractual maturities because some borrowers have the right to call or prepay obligations with or without call or prepayment penalties.

[0001564590-19-016264:notes:88]
Realized gains and losses on sales of debt securities are computed under the specific identification method. The following table presents gross realized gains and losses related to our debt securities:

[0001564590-19-016264:notes:89]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2019 |  |  | 2018 |  |
| Gross realized gains on debt securities |  | $ | 41 |  |  | $ | — |  |
| Gross realized losses on debt securities |  |  | (19 | ) |  |  | (73 | ) |
| Total gain (loss) recognized, net |  | $ | 22 |  |  | $ | (73 | ) |

[0001564590-19-016264:notes:90]
Our investment policy provides limitations for issuer concentration, which limits, at the time of purchase, the concentration in any one issuer to 5% of the market value of our total investment portfolio.

[0001564590-19-016264:notes:91]
At March 31, 2019, we held a $25.6 million restricted certificate of deposit that is carried at cost. This investment serves as a collateral deposit against the principal amount outstanding under loans made to ADTRAN pursuant to an Alabama State Industrial Development Authority revenue bond (the Bond), which totaled $25.6 million at March 31, 2019 and December 31, 2018. At March 31, 2019 and December 31, 2018, the estimated fair value of the Bond using a level 2 valuation technique was approximately $25.5 million and $25.4 million, respectively, based on a debt security with a comparable interest rate and maturity and a Standard and Poor’s credit rating of AAA. We have the right to set-off the balance of the Bond with the collateral deposit in order to reduce the balance of the indebtedness. The Bond matures on January 1, 2020, and bears interest at the rate of 2% per annum. In conjunction with this program, we are eligible to receive certain economic incentives from the state of Alabama that reduce the amount of payroll withholdings we are required to remit to the state for those employment positions that qualify under this program. We are required to make payments in the amounts necessary to pay the interest on the amounts currently outstanding. It is our intent to make annual principal payments in addition to the interest amounts that are due. The restricted funds held as collateral against the principal amount of the Bond will be used to pay the outstanding principal and interest upon the Bond’s maturity on January 1, 2020.

[0001564590-19-016264:notes:92]
Marketable Equity Securities

[0001564590-19-016264:notes:93]
Our marketable equity securities consist of publicly traded stock, funds and certain other investments measured at fair value or cost (where appropriate).

[0001564590-19-016264:notes:94]
On January 1, 2018, we adopted ASU 2016-01, which requires us to measure all equity investments that do not result in consolidation and are not accounted for under the equity method at fair value, with any changes in fair value recognized in net investment gain (loss). Upon adoption, we reclassified $3.2 million of net unrealized gains related to marketable equity securities from accumulated other comprehensive income (loss) to retained earnings.

[0001564590-19-016264:notes:95]
ASU 2016-01 also provides a measurement alternative for equity investments that do not have a readily determinable fair value in which investments can be recorded at cost less impairment, if any, adjusted for observable price changes for an identical or similar investment. We elected to record our equity investment that does not have a readily determinable fair value using the measurement alternative method. The carrying value of this investment was $3.4 million and $0 as of March 31, 2019 and December 31, 2018, respectively.

[0001564590-19-016264:notes:96]
Realized and unrealized gains and losses for our marketable equity securities for the three months ended March 31, 2019 and 2018 were as follows:

[0001564590-19-016264:notes:97]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2019 |  |  | 2018 |  |
| Realized gains (losses) on equity securities sold |  | $ | (14 | ) |  | $ | 398 |  |
| Unrealized gains (losses) on equity securities held |  |  | 5,918 |  |  |  | (422 | ) |
| Total gain (loss) recognized, net |  | $ | 5,904 |  |  | $ | (24 | ) |

[0001564590-19-016264:notes:98]
As of March 31, 2019 and 2018, gross unrealized losses related to individual investments in a continuous loss position for twelve months or longer were not significant.

[0001564590-19-016264:notes:99]
We have categorized our cash equivalents and our investments held at fair value into a three-level fair value hierarchy based on the priority of the inputs to the valuation technique for the cash equivalents and investments as follows: Level 1 - Values based on unadjusted quoted prices for identical assets or liabilities in an active market; Level 2 - Values based on quoted prices in markets that are not active or model inputs that are observable either directly or indirectly; Level 3 - Values based on prices or valuation techniques that require inputs that are both unobservable and significant to the overall fair value measurement. These inputs include information supplied by investees.

[0001564590-19-016264:notes:100]
|  |  |  |  |  |  | Fair Value Measurements at March 31, 2019 Using |  |
| (In thousands) |  | Cost or Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,279 |  |  | $ | 1,279 |  |  | $ | — |  |  | $ | — |  |
| Commercial paper |  |  | 6,547 |  |  |  | — |  |  |  | 6,547 |  |  |  | — |  |
| Cash equivalents |  |  | 7,826 |  |  |  | 1,279 |  |  |  | 6,547 |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 16,009 |  |  |  | — |  |  |  | 16,009 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 938 |  |  |  | — |  |  |  | 938 |  |  |  | — |  |
| Asset-backed bonds |  |  | 7,175 |  |  |  | — |  |  |  | 7,175 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 4,541 |  |  |  | — |  |  |  | 4,541 |  |  |  | — |  |
| U.S. government bonds |  |  | 4,227 |  |  |  | 4,227 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 2,157 |  |  |  | — |  |  |  | 2,157 |  |  |  | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  | — |  |
| Marketable equity securities – various industries |  |  | 30,725 |  |  |  | 30,725 |  |  |  | — |  |  |  | — |  |
| Equity in escrow |  |  | 174 |  |  |  | 174 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 20,416 |  |  |  | 20,416 |  |  |  | — |  |  |  | — |  |
| Total debt and equity securities at fair value |  |  | 86,362 |  |  |  | 55,542 |  |  |  | 30,820 |  |  |  | — |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other investments |  |  | 3,375 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total other investments held at cost |  |  | 3,375 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 97,563 |  |  | $ | 56,821 |  |  | $ | 37,367 |  |  | $ | — |  |

[0001564590-19-016264:notes:101]
|  |  |  |  |  |  | Fair Value Measurements at December 31, 2018 Using |  |
| (In thousands) |  | Cost or Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,554 |  |  | $ | 1,554 |  |  | $ | — |  |  | $ | — |  |
| Cash equivalents |  |  | 1,554 |  |  |  | 1,554 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 20,684 |  |  |  | — |  |  |  | 20,684 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 1,313 |  |  |  | — |  |  |  | 1,313 |  |  |  | — |  |
| Asset-backed bonds |  |  | 5,221 |  |  |  | — |  |  |  | 5,221 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 3,791 |  |  |  | — |  |  |  | 3,791 |  |  |  | — |  |
| U.S. government bonds |  |  | 9,206 |  |  |  | 9,206 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 584 |  |  |  | — |  |  |  | 584 |  |  |  | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 26,763 |  |  |  | 26,763 |  |  |  | — |  |  |  | — |  |
| Equity in escrow |  |  | 253 |  |  |  | 253 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 18,256 |  |  |  | 18,256 |  |  |  | — |  |  |  | — |  |
| Total debt and equity securities at fair value |  |  | 86,071 |  |  |  | 54,478 |  |  |  | 31,593 |  |  |  | — |  |
| Total |  | $ | 87,625 |  |  | $ | 56,032 |  |  | $ | 31,593 |  |  | $ | — |  |

[0001564590-19-016264:notes:102]
The fair value of our Level 2 securities is calculated using a weighted average market price for each security. Market prices are obtained from a variety of industry standard data providers, security master files from large financial institutions, and other third-party sources. These multiple market prices are used as inputs into a distribution-curve-based algorithm to determine the daily market value of each security.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001564590-19-016264:notes:103]
[same as prior period, unchanged from 0001564590-18-027351:notes:110]

[0001564590-19-016264:notes:104]
[same as prior period, unchanged from 0001564590-18-027351:notes:111]

[0001564590-19-016264:notes:105]
[same as prior period, unchanged from 0001564590-18-027351:notes:112]

[0001564590-19-016264:notes:106]
Our cash flow hedging activities utilize foreign exchange forward contracts to reduce the risk that movements in exchange rates will adversely affect the net cash flows resulting from the planned purchase of products from foreign suppliers. Purchases of U.S. denominated inventory by our European subsidiary represent our primary exposure. Changes in the fair value of derivatives designated as cash flow hedges are not recognized in current operating results, but are recorded in accumulated other comprehensive income. Amounts related to cash flow hedges are reclassified from accumulated other comprehensive income when the underlying hedged item impacts earnings. This reclassification is recorded in cost of sales, the same line item of the Consolidated Statements of Income at which the effects of the hedged item are recorded.

[0001564590-19-016264:notes:107]
[same as prior period, unchanged from 0001564590-18-027351:notes:114]

[0001564590-19-016264:notes:108]
We have certain customers and suppliers who are invoiced or pay in a non-functional currency. Changes in the monetary exchange rates may adversely affect our results of operations and financial condition, as outstanding non-functional balances are revalued to the functional currency through profit and loss. When appropriate, we utilize foreign exchange forward contracts to help manage the volatility relating to these valuation exposures. All changes in the fair value of our derivative instruments that do not qualify for, or are not designated for hedged accounting transactions, are recognized as other income (expense), net in the Consolidated Statements of Income.

[0001564590-19-016264:notes:109]
[same as prior period, unchanged from 0001564590-18-027351:notes:116]

[0001564590-19-016264:notes:110]
As of March 31, 2019, we had no foreign exchange forward contracts.

[0001564590-19-016264:notes:111]
The changes in the fair values of our derivative instruments recorded in the Consolidated Statements of Income during the three months ended March 31, 2019 and 2018 were as follows:

[0001564590-19-016264:notes:112]
|  |  |  |  | Three Months Ended |  |
|  |  | Income Statement |  | March 31, |  |
| (In thousands) |  | Location |  | 2019 |  |  | 2018 |  |
| Derivatives not designated as hedging instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Other income (expense), net |  | $ | — |  |  | $ | 13 |  |


## us-gaap:InventoryDisclosureTextBlock

[0001564590-19-016264:notes:113]
[same as prior period, unchanged from 0001564590-18-027351:notes:123]

[0001564590-19-016264:notes:114]
At March 31, 2019 and December 31, 2018, inventory consisted of the following:

[0001564590-19-016264:notes:115]
|  |  | March 31, |  |  | December 31, |  |
| (In thousands) |  | 2019 |  |  | 2018 |  |
| Raw materials |  | $ | 40,841 |  |  | $ | 45,333 |  |
| Work in process |  |  | 1,513 |  |  |  | 1,638 |  |
| Finished goods |  |  | 51,255 |  |  |  | 52,877 |  |
| Total |  | $ | 93,609 |  |  | $ | 99,848 |  |

[0001564590-19-016264:notes:116]
We establish reserves for estimated excess, obsolete, or unmarketable inventory equal to the difference between the cost of the inventory and the estimated fair value of the inventory based upon assumptions about future demand and market conditions. At March 31, 2019 and December 31, 2018, raw materials reserves totaled $17.1 million and $17.6 million, respectively, and finished goods inventory reserves totaled $12.8 million and $12.4 million, respectively.


## us-gaap:GoodwillDisclosureTextBlock

[0001564590-19-016264:notes:117]
10. GOODWILL

[0001564590-19-016264:notes:118]
Goodwill, all of which relates to our acquisitions of Bluesocket, Inc. and SmartRG, was $7.0 million and $7.1 million at March 31, 2019 and December 31, 2018, of which $6.6 million and $0.4 million is allocated to our Network Solutions and Services & Support reportable segments, respectively, as of March 31, 2019, and of which $6.7 million and $0.4 million was allocated to our Network Solutions and Services & Support reportable segments, respectively, as of December 31, 2018. Goodwill related to our SmartRG acquisition was adjusted during the three months ended March 31, 2019, as a result of filing the SmartRG income tax returns during the quarter.

[0001564590-19-016264:notes:119]
We evaluate the carrying value of goodwill during the fourth quarter of each year and between annual evaluations if events occur or circumstances change that would more likely than not reduce the fair value of the reporting unit below its carrying amount. We have elected to first assess the qualitative factors to determine whether it is more likely than not that the fair value of the reporting unit to which the goodwill is assigned is less than its carrying amount as a basis for determining whether it is necessary to perform the two-step impairment test. If we determine that it is more likely than not that its fair value is less than its carrying amount, then the two-step impairment test will be performed. Based on the results of our qualitative assessment in 2018, we concluded that it was not necessary to perform the two-step impairment test.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001564590-19-016264:notes:120]
11. INTANGIBLE ASSETS

[0001564590-19-016264:notes:121]
Intangible assets include intangibles acquired in conjunction with several acquisitions since 2011, with the most recent being SmartRG, Inc. in November 2018 and SEI’s North American EPON business and technology license and OEM supply agreement with SEI in March 2018.

[0001564590-19-016264:notes:122]
The following table presents our intangible assets as of March 31, 2019 and December 31, 2018:

[0001564590-19-016264:notes:123]
|  |  | March 31, 2019 |  |  | December 31, 2018 |  |
| (In thousands) |  | Gross Value |  |  | Accumulated Amortization |  |  | Net Value |  |  | Gross Value |  |  | Accumulated Amortization |  |  | Net Value |  |
| Customer relationships |  | $ | 22,363 |  |  | $ | (5,797 | ) |  | $ | 16,566 |  |  | $ | 22,455 |  |  | $ | (5,380 | ) |  | $ | 17,075 |  |
| Developed technology |  |  | 10,170 |  |  |  | (2,526 | ) |  |  | 7,644 |  |  |  | 12,801 |  |  |  | (4,867 | ) |  |  | 7,934 |  |
| Licensed technology |  |  | 5,900 |  |  |  | (683 | ) |  |  | 5,217 |  |  |  | 5,900 |  |  |  | (520 | ) |  |  | 5,380 |  |
| Supplier relationships |  |  | 2,800 |  |  |  | (1,458 | ) |  |  | 1,342 |  |  |  | 2,800 |  |  |  | (1,108 | ) |  |  | 1,692 |  |
| Licensing agreements |  |  | 560 |  |  |  | (24 | ) |  |  | 536 |  |  |  | 560 |  |  |  | (5 | ) |  |  | 555 |  |
| Patents |  |  | 500 |  |  |  | (174 | ) |  |  | 326 |  |  |  | 500 |  |  |  | (157 | ) |  |  | 343 |  |
| Trade names |  |  | 310 |  |  |  | (124 | ) |  |  | 186 |  |  |  | 310 |  |  |  | (106 | ) |  |  | 204 |  |
| Total |  | $ | 42,603 |  |  | $ | (10,786 | ) |  | $ | 31,817 |  |  | $ | 45,326 |  |  | $ | (12,143 | ) |  | $ | 33,183 |  |

[0001564590-19-016264:notes:124]
Amortization expense was $1.3 million and $0.4 million for the three months ended March 31, 2019 and 2018 respectively.

[0001564590-19-016264:notes:125]
As of March 31, 2019, the estimated future amortization expense of our intangible assets is as follows:

[0001564590-19-016264:notes:126]
| (In thousands) |  | Amount |  |
| Remainder of 2019 |  | $ | 3,994 |  |
| 2020 |  |  | 4,444 |  |
| 2021 |  |  | 4,096 |  |
| 2022 |  |  | 3,472 |  |
| 2023 |  |  | 3,320 |  |
| Thereafter |  |  | 12,491 |  |
| Total |  | $ | 31,817 |  |


## adtn:LeasesDisclosureTextBlock

[0001564590-19-016264:notes:127]
12. LEASES

[0001564590-19-016264:notes:128]
Operating Lease Arrangements

[0001564590-19-016264:notes:129]
We have operating leases for office space, automobiles, and other equipment in the United States and in various international locations in which we do business. We also have other contracts such as, manufacturing agreements and service agreements, which we review to determine if they contain an embedded lease. We specifically review these other contracts to determine whether we have the right to substantially all of the economic benefit from the use of any specified assets or the right to direct the use of any specified assets, either of which would indicate the existence of a lease.

[0001564590-19-016264:notes:130]
As of March 31, 2019, our leases have remaining lease terms of one month to six years, some of which include options to extend the leases for up to 3 years, and some of which include options to terminate the leases within 3 months. For those leases that are reasonably assured to be renewed, we have included the option to extend as part of our right of use asset and right of use liability included on the Consolidated Balance Sheet. Leases with an initial term of 12 months or less are not recorded on the balance sheet and lease expense for these leases is recognized on a straight-line basis over the lease term. Lease expense related to these short-term leases was $0.2 million for the three months ended March 31, 2019, and is included in selling, general and administrative expenses on the Consolidated Statement of Income. For lease agreements entered into or reassessed after the adoption of Topic 842, we elected the practical expedient which allows us to not separate lease and non-lease components. None of our lease agreements contain any material residual value guarantees or material restrictive covenants.

[0001564590-19-016264:notes:131]
Supplemental balance sheet information related to operating leases is as follows:

[0001564590-19-016264:notes:132]
|  |  |  |  | March 31, |  |  | January 1, |  |
| (In thousands) |  | Classification |  | 2019 |  |  | 2019 |  |
| Assets |  |  |  |  |  |  |  |  |  |  |
| Operating lease asset |  | Other assets |  | $ | 9,502 |  |  | $ | 10,322 |  |
| Total lease assets |  |  |  | $ | 9,502 |  |  | $ | 10,322 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |
| Current operating lease liability |  | Accrued expenses |  | $ | 2,718 |  |  | $ | 2,948 |  |
| Non-current operating lease liability |  | Other non-current liabilities |  |  | 6,801 |  |  |  | 7,374 |  |
| Total lease liability |  |  |  | $ | 9,519 |  |  | $ | 10,322 |  |

[0001564590-19-016264:notes:133]
The components of lease expense included in the Consolidated Statement of Income for the three months ended March 31, 2019 are as follows:

[0001564590-19-016264:notes:134]
| (In thousands) |  | Classification |  | Three Months Ended March 31, 2019 |  |
| Operating lease expense |  | Selling, general and administrative expenses |  | $ | 349 |  |
| Operating lease expense |  | Research and development expenses |  |  | 454 |  |
| Operating lease expense |  | Cost of sales |  |  | 16 |  |
| Total lease expense |  |  |  | $ | 819 |  |

[0001564590-19-016264:notes:135]
As of March 31, 2019, the maturity of lease liabilities included on the Consolidated Balance Sheet are as follows:

[0001564590-19-016264:notes:136]
| (In thousands) |  | Amount |  |
| Remainder of 2019 |  | $ | 2,363 |  |
| 2020 |  |  | 2,185 |  |
| 2021 |  |  | 2,032 |  |
| 2022 |  |  | 1,544 |  |
| 2023 |  |  | 1,163 |  |
| Thereafter |  |  | 747 |  |
| Total lease payments |  |  | 10,034 |  |
| Less: Interest |  |  | (515 | ) |
| Present value of lease liabilities |  | $ | 9,519 |  |

[0001564590-19-016264:notes:137]
Operating lease payments include $1.2 million related to options to extend lease terms that are reasonably certain of being exercised and there are no legally binding leases that have not yet commenced.

[0001564590-19-016264:notes:138]
As of December 31, 2018, future minimum rental payments under non-cancelable operating leases, including renewals determined to be reasonably assured as of December 31, 2018, with original maturities of greater than 12 months are as follows:

[0001564590-19-016264:notes:139]
| (In thousands) |  | Amount (1) |  |
| 2019 |  | $ | 3,873 |  |
| 2020 |  |  | 3,580 |  |
| 2021 |  |  | 2,771 |  |
| 2022 |  |  | 2,053 |  |
| 2023 |  |  | 1,317 |  |
| Thereafter |  |  | 762 |  |
| Total |  | $ | 14,356 |  |

[0001564590-19-016264:notes:140]
|  | (1) | Certain renewal options were subsequently determined to not be reasonably assured of renewal upon adoption of the new lease standard. |

[0001564590-19-016264:notes:141]
Our leases do not provide an implicit borrowing rate and therefore we use an incremental borrowing rate based on the information available at commencement date in determining the present value of lease payments. We used the incremental borrowing rate on January 1, 2019, for operating leases that commenced on or prior to that date. The incremental borrowing rate was determined on a portfolio basis by grouping leases with similar terms as well as grouping leases based on a U.S. dollar or Euro functional currency.  The actual rate is then determined based on a credit spread over LIBOR as well as the Bloomberg Curve Matrix for the U.S. Communications section.

[0001564590-19-016264:notes:142]
|  |  | As of March 31, 2019 |  |
| Weighted average remaining lease term (years) |  |  |  |  |
| Operating leases with USD functional currency |  |  | 3.0 |  |
| Operating leases with Euro functional currency |  |  | 5.1 |  |
| Weighted average discount rate |  |  |  |  |
| Operating leases with USD functional currency |  |  | 4.61 | % |
| Operating leases with Euro functional currency |  |  | 1.85 | % |

[0001564590-19-016264:notes:143]
Supplemental cash flow information related to leases were as follows:

[0001564590-19-016264:notes:144]
| (In thousands) |  | As of March 31, 2019 |  |
| Cash paid for amounts included in the measurement of lease liabilities / assets |  |  |  |  |
| Cash used in operating activities related to operating leases |  |  | $ (811 | ) |
| Right-of-use assets obtained in exchange for lease obligations |  |  | $ 10,387 |  |

[0001564590-19-016264:notes:145]
Sales-Type Lease Arrangements

[0001564590-19-016264:notes:146]
We are the lessor in sales-type lease arrangements for network equipment, which have initial terms of up to five years. Our sales-type lease arrangements contain either a provision whereby the network equipment reverts back to us upon the expiration of the lease or a provision that allows the lessee to purchase the network equipment at a bargain purchase amount. In addition, our sales-type lease arrangements do not contain any residual value guarantees or material restrictive covenants. The allocation of the consideration between lease and non-lease components is determined by standalone sales price by component. The net investment in sales-type leases consists of lease receivables less unearned income. Collectability of sales-type leases is evaluated periodically at an individual customer level. At March 31, 2019 and December 31, 2018, we had no allowance for credit losses for our net investment in sales-type leases. As of March 31, 2019 and December 31, 2018, the components of the net investment in sales-type leases were as follows:

[0001564590-19-016264:notes:147]
|  |  | March 31, |  |  | December 31, |  |
| (In thousands) |  | 2019 |  |  | 2018 |  |
| Current minimum lease payments receivable (included in other receivables) |  | $ | 9,349 |  |  | $ | 11,339 |  |
| Non-current minimum lease payments receivable (included in other assets) |  |  | 1,494 |  |  |  | 1,670 |  |
| Total minimum lease payments receivable |  |  | 10,843 |  |  |  | 13,009 |  |
| Less: Current unearned revenue |  |  | 573 |  |  |  | 631 |  |
| Less: Non-current unearned revenue |  |  | 343 |  |  |  | 473 |  |
| Net investment in sales-type leases |  | $ | 9,927 |  |  | $ | 11,905 |  |

[0001564590-19-016264:notes:148]
The components of sales-type lease gross profit recognized at the lease commencement date and interest income, included in the Consolidated Statement of Income for the three months ended March 31, 2019 are as follows:

[0001564590-19-016264:notes:149]
| (In thousands) |  | Classification |  | Three Months Ended March 31, 2019 |  |
| Sales type leases |  | Sales - products |  | $ | 1,512 |  |
| Sales type leases |  | Cost of sales - products |  |  | 591 |  |
| Sales type leases |  | Gross profit |  | $ | 921 |  |
| Sales type leases |  | Interest and dividend income |  | $ | 87 |  |

[0001564590-19-016264:notes:150]
Future minimum lease payments to be received from sales-type leases as of March 31, 2019 are as follows:

[0001564590-19-016264:notes:151]
| (In thousands) |  | Amount (1) |  |
| Remainder of 2019 |  | $ | 9,005 |  |
| 2020 |  |  | 1,056 |  |
| 2021 |  |  | 493 |  |
| 2022 |  |  | 209 |  |
| 2023 |  |  | 78 |  |
| Thereafter |  |  | 2 |  |
| Total |  | $ | 10,843 |  |

[0001564590-19-016264:notes:152]
|  | (1) | A significant portion of these future minimum lease payments relates to one of our customers who filed for Chapter 11 bankruptcy in February 2019. In March 2019, we reached an agreement with this customer and they continue to make payments as outlined in the lease agreements. Therefore, we believe there is no potential risk of uncollectibility related to these outstanding balances. |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001564590-19-016264:notes:153]
13. STOCKHOLDERS’ EQUITY

[0001564590-19-016264:notes:154]
[same as prior period, unchanged from 0001564590-18-027351:notes:139]

[0001564590-19-016264:notes:155]
Since 1997, our Board of Directors has approved multiple share repurchase programs that have authorized open market repurchase transactions of our common stock, which are implemented through open market or private purchases from time to time as conditions warrant. During the three months ended March 31, 2019, we repurchased 13,000 shares of our common stock at an average price of $14.06 per share. As of March 31, 2019, we have the authority to purchase an additional 2.5 million shares of our common stock under the current authorization of up to 5.0 million shares.

[0001564590-19-016264:notes:156]
[same as prior period, unchanged from 0001564590-18-027351:notes:146]

[0001564590-19-016264:notes:157]
Other comprehensive income consists of unrealized gains (losses) on available-for-sale debt securities; reclassification adjustments for amounts included in net income related to impairments of available-for-sale debt securities, realized gains (losses) on available-for-sale debt securities, realized gains (losses) on cash flow hedges, amortization of actuarial gains (losses) related to our defined benefit plan, defined benefit plan adjustments, and foreign currency translation adjustments.

[0001564590-19-016264:notes:158]
The following tables present the changes in accumulated other comprehensive income (loss), net of tax, by component for the three months ended March 31, 2019 and 2018:

[0001564590-19-016264:notes:159]
|  |  | Three Months Ended March 31, 2019 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | ASU 2018-02 Adoption |  |  | Total |  |
| Beginning balance |  | $ | (563 | ) |  | $ | (8,041 | ) |  | $ | (5,812 | ) |  | $ | — |  |  | $ | (14,416 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | 231 |  |  |  | — |  |  |  | (1,160 | ) |  |  | — |  |  |  | (929 | ) |
| Amounts reclassified from accumulated other comprehensive income (loss) |  |  | (46 | ) |  |  | 121 |  |  |  | — |  |  |  | — |  |  |  | 75 |  |
| Amounts reclassified to retained earnings (1) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 385 |  |  |  | 385 |  |
| Net current period other comprehensive income (loss) |  |  | 185 |  |  |  | 121 |  |  |  | (1,160 | ) |  |  | 385 |  |  |  | (469 | ) |
| Ending balance |  | $ | (378 | ) |  | $ | (7,920 | ) |  | $ | (6,972 | ) |  | $ | 385 |  |  | $ | (14,885 | ) |

[0001564590-19-016264:notes:160]
|  | (1) | With the adoption of ASU 2018-02, the stranded tax effects related to the Tax Cuts and Jobs Act of 2017 were reclassified to retained earnings. See Note 1. |

[0001564590-19-016264:notes:161]
|  |  | Three Months Ended March 31, 2018 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | Total |  |
| Beginning balance |  | $ | 2,567 |  |  | $ | (4,286 | ) |  | $ | (1,576 | ) |  | $ | (3,295 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | (257 | ) |  |  | — |  |  |  | 842 |  |  |  | 585 |  |
| Amounts reclassified from accumulated other comprehensive income (loss) |  |  | 65 |  |  |  | 62 |  |  |  | — |  |  |  | 127 |  |
| Amounts reclassified to retained earnings (1) |  |  | (3,220 | ) |  |  | — |  |  |  | — |  |  |  | (3,220 | ) |
| Net current period other comprehensive income (loss) |  |  | (3,412 | ) |  |  | 62 |  |  |  | 842 |  |  |  | (2,508 | ) |
| Ending balance |  | $ | (845 | ) |  | $ | (4,224 | ) |  | $ | (734 | ) |  | $ | (5,803 | ) |

[0001564590-19-016264:notes:162]
|  | (1) | With the adoption of ASU 2016-01, the unrealized gains on our equity investments were reclassified to retained earnings. See Note 7. |

[0001564590-19-016264:notes:163]
The following tables present the details of reclassifications out of accumulated other comprehensive income (loss) for the three months ended March 31, 2019 and 2018:

[0001564590-19-016264:notes:164]
|  |  | Three Months Ended March 31, 2019 |
| Details about Accumulated Other Comprehensive Income (Loss) Components |  | Amount Reclassified from Accumulated Other Comprehensive Income (Loss) |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains on available-for-sale securities: |  |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 62 |  |  | Net investment gain (loss) |
| Defined benefit plan adjustments – actuarial losses |  |  | (175 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | (113 | ) |  |  |
| Tax benefit |  |  | 38 |  |  |  |
| Total reclassifications for the period, net of tax |  | $ | (75 | ) |  |  |

[0001564590-19-016264:notes:165]
|  | (1) | Included in the computation of net periodic pension cost. See Note 5. |

[0001564590-19-016264:notes:166]
|  |  | Three Months Ended March 31, 2018 |
| Details about Accumulated Other Comprehensive Income (Loss) Components |  | Amount Reclassified from Accumulated Other Comprehensive Income (Loss) |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized losses on available-for-sale securities: |  |  |  |  |  |  |
| Net realized loss on sales of securities |  | $ | (73 | ) |  | Net investment gain (loss) |
| Defined benefit plan adjustments – actuarial losses |  |  | (90 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | (163 | ) |  |  |
| Tax benefit |  |  | 36 |  |  |  |
| Total reclassifications for the period, net of tax |  | $ | (127 | ) |  |  |

[0001564590-19-016264:notes:167]
The following table presents the tax effects related to the change in each component of other comprehensive income (loss) for the three months ended March 31, 2019 and 2018:

[0001564590-19-016264:notes:168]
|  |  | Three Months Ended |  |  | Three Months Ended |  |
|  |  | March 31, 2019 |  |  | March 31, 2018 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |
| Unrealized gains (losses) on available-for-sale securities |  | $ | 312 |  |  | $ | (81 | ) |  | $ | 231 |  |  | $ | (347 | ) |  | $ | 90 |  |  | $ | (257 | ) |
| Reclassification adjustment for amounts related to available-for-sale investments included in net income |  |  | (62 | ) |  |  | 16 |  |  |  | (46 | ) |  |  | 73 |  |  |  | (8 | ) |  |  | 65 |  |
| Reclassification adjustment for amounts related to cash flow hedges included in net income |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (3,220 | ) |  |  | — |  |  |  | (3,220 | ) |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net income |  |  | 175 |  |  |  | (54 | ) |  |  | 121 |  |  |  | 90 |  |  |  | (28 | ) |  |  | 62 |  |
| Foreign currency translation adjustment |  |  | (1,160 | ) |  |  | — |  |  |  | (1,160 | ) |  |  | 842 |  |  |  | — |  |  |  | 842 |  |
| Total Other Comprehensive Income (Loss) |  | $ | (735 | ) |  | $ | (119 | ) |  | $ | (854 | ) |  | $ | (2,562 | ) |  | $ | 54 |  |  | $ | (2,508 | ) |


## us-gaap:EarningsPerShareTextBlock

[0001564590-19-016264:notes:169]
14. EARNINGS (LOSS) PER SHARE

[0001564590-19-016264:notes:170]
A summary of the calculation of basic and diluted earnings (loss) per share for the three months ended March 31, 2019 and 2018 is as follows:

[0001564590-19-016264:notes:171]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands, except per share amounts) |  | 2019 |  |  | 2018 |  |
| Numerator |  |  |  |  |  |  |  |  |
| Net income (loss) |  | $ | 770 |  |  | $ | (10,814 | ) |
| Denominator |  |  |  |  |  |  |  |  |
| Weighted average number of shares – basic |  |  | 47,782 |  |  |  | 48,232 |  |
| Effect of dilutive securities |  |  |  |  |  |  |  |  |
| Stock options |  |  | — |  |  |  | — |  |
| PSUs, RSUs and restricted stock |  |  | 71 |  |  |  | — |  |
| Weighted average number of shares – diluted |  |  | 47,853 |  |  |  | 48,232 |  |
| Earnings (loss) per share – basic |  | $ | 0.02 |  |  | $ | (0.22 | ) |
| Earnings (loss) per share – diluted |  | $ | 0.02 |  |  | $ | (0.22 | ) |

[0001564590-19-016264:notes:172]
For the three months ended March 31, 2019 and 2018, 2.9 million and 4.8 million stock options were outstanding but were not included in the computation of diluted earnings (loss) per share because the stock options’ exercise prices were greater than the average market price of the common shares, therefore making them anti-dilutive under the treasury stock method.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-19-016264:notes:173]
15. SEGMENT INFORMATION

[0001564590-19-016264:notes:174]
We operate in two reportable segments: (1) Network Solutions and (2) Services & Support. Network Solutions includes hardware products and software defined next-generation virtualized solutions used in service provider or business networks, as well as prior-generation products. Services & Support includes our suite of ProCloud managed services, network installation, engineering and maintenance services and fee-based technical support and equipment repair/replacement plans.

[0001564590-19-016264:notes:175]
We evaluate the performance of our segments based on gross profit; therefore, selling, general and administrative expenses, research and development expenses, interest and dividend income, interest expense, net investment gain (loss), other income (expense) and (provision) benefit for income taxes are reported on a company-wide, functional basis only. There is no inter-segment revenue.

[0001564590-19-016264:notes:176]
The following table presents information about the reported sales and gross profit of our reportable segments for the three months ended March 31, 2019 and 2018. We do not produce asset information by reportable segment; therefore, it is not reported.

[0001564590-19-016264:notes:177]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
|  |  | 2019 |  |  | 2018 |  |
| (In thousands) |  | Sales |  |  | Gross Profit |  |  | Sales |  |  | Gross Profit |  |
| Network Solutions |  | $ | 125,822 |  |  | $ | 55,088 |  |  | $ | 105,253 |  |  | $ | 36,641 |  |
| Services & Support |  |  | 17,969 |  |  |  | 5,524 |  |  |  | 15,553 |  |  |  | 3,092 |  |
| Total |  | $ | 143,791 |  |  | $ | 60,612 |  |  | $ | 120,806 |  |  | $ | 39,733 |  |

[0001564590-19-016264:notes:178]
[same as prior period, unchanged from 0001564590-18-027351:notes:176]

[0001564590-19-016264:notes:179]
In addition to our reporting segments, we also report revenue for the following three categories – Access & Aggregation, Subscriber Solutions & Experience (formerly Customer Devices) and Traditional & Other Products.

[0001564590-19-016264:notes:180]
The following table represents sales information by geographic area for the three months ended March 31, 2019 and 2018:

[0001564590-19-016264:notes:181]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2019 |  |  | 2018 |  |
| United States |  | $ | 72,528 |  |  | $ | 62,086 |  |
| International |  |  | 71,263 |  |  |  | 58,720 |  |
| Total |  | $ | 143,791 |  |  | $ | 120,806 |  |


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001564590-19-016264:notes:182]
16. LIABILITY FOR WARRANTY RETURNS

[0001564590-19-016264:notes:183]
Our products generally include warranties of 90 days to five years for product defects. We accrue for warranty returns at the time revenue is recognized based on our estimate of the cost to repair or replace the defective products. We engage in extensive product quality programs and processes, including actively monitoring and evaluating the quality of our component suppliers. Our products continue to become more complex in both size and functionality as many of our product offerings migrate from line card applications to total systems. The increasing complexity of our products will cause warranty incidences, when they arise, to be more costly. Our estimates regarding future warranty obligations may change due to product failure rates, material usage and other rework costs incurred in correcting a product failure. In addition, from time to time, specific warranty accruals may be recorded if unforeseen problems arise. Should our actual experience relative to these factors be worse than our estimates, we will be required to record additional warranty expense. Alternatively, if we provide for more reserves than we require, we will reverse a portion of such provisions in future periods. The liability for warranty obligations totaled $8.8 million and $8.6 million at March 31, 2019 and December 31, 2018, which are included in accrued expenses in the accompanying Consolidated Balance Sheet.

[0001564590-19-016264:notes:184]
A summary of warranty expense and write-off activity for the three months ended March 31, 2019 and 2018 is as follows:

[0001564590-19-016264:notes:185]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2019 |  |  | 2018 |  |
| Balance at beginning of period |  | $ | 8,623 |  |  | $ | 9,724 |  |
| Plus: Amounts charged to cost and expenses |  |  | 1,131 |  |  |  | 1,822 |  |
| Less: Deductions |  |  | (952 | ) |  |  | (1,859 | ) |
| Balance at end of period |  | $ | 8,802 |  |  | $ | 9,687 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-19-016264:notes:186]
17. COMMITMENTS AND CONTINGENCIES

[0001564590-19-016264:notes:187]
In the ordinary course of business, we may be subject to various legal proceedings and claims, including employment disputes, patent claims, disputes over contract agreements and other commercial disputes. In some cases, claimants seek damages or other relief, such as royalty payments related to patents, which, if granted, could require significant expenditures. Although the outcome of any claim or litigation can never be certain, it is our opinion that the outcome of all contingencies of which we are currently aware will not materially affect our business, operations, financial condition or cash flows.

[0001564590-19-016264:notes:188]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, and we have contributed $8.4 million as of March 31, 2019, of which $7.7 million has been applied to these commitments.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-19-016264:notes:189]
18. RESTRUCTURING

[0001564590-19-016264:notes:190]
In February 2019, we announced the restructuring of our workforce predominantly in Germany, which included the closure of the office location in Munich, Germany accompanied by relocation or severance benefits for the affected employees. The restructuring is expected to be completed in the fourth quarter of 2019. The cumulative amount incurred during the three months ended March 31, 2019 related to this restructuring program is $1.8 million. We also offered a voluntary early retirement offering to certain other employees which was announced to employees in March 2019. As of March 31, 2019, we did not have sufficient information on which to estimate an additional liability associated with the voluntary early retirement program.

[0001564590-19-016264:notes:191]
In January 2018, we announced an early retirement incentive program for employees that met certain requirements. The cumulative amount incurred during the year ended December 31, 2018 related to this restructuring program was $7.3 million, of which $6.0 million was incurred during the three months ended March 31, 2018. We do not expect to incur any additional expenses related to this restructuring program.

[0001564590-19-016264:notes:192]
A reconciliation of the beginning and ending restructuring liability, which is included in accrued wages and benefits on the Consolidated Balance Sheet, is as follows:

[0001564590-19-016264:notes:193]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2019 |  |
| Balance as of December 31, 2018 |  | $ | 185 |  |
| Plus: Amounts charged to cost and expense |  |  | 2,063 |  |
| Less: Costs paid |  |  | (277 | ) |
| Balance as of March 31, 2019 |  | $ | 1,971 |  |

[0001564590-19-016264:notes:194]
The components of restructuring expense in the Consolidated Statements of Income are as follows:

[0001564590-19-016264:notes:195]
|  |  |  |  | Three Months Ended |  |
|  |  |  |  | March 31, |  |
| (In thousands) |  | Classification |  | 2019 |  |  | 2018 |  |
| Restructuring expenses |  | Selling, general and administrative expenses |  | $ | 844 |  |  | $ | 1,766 |  |
| Restructuring expenses |  | Research and development expenses |  |  | 584 |  |  |  | 1,814 |  |
| Restructuring expenses |  | Cost of sales |  |  | 635 |  |  |  | 2,370 |  |
| Total restructuring expenses |  |  |  | $ | 2,063 |  |  | $ | 5,950 |  |


## us-gaap:SubsequentEventsTextBlock

[0001564590-19-016264:notes:196]
19. SUBSEQUENT EVENTS

[0001564590-19-016264:notes:197]
On April 17, 2019, we announced that our Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to stockholders of record at the close of business on May 2, 2019. The payment date will be May 16, 2019. The quarterly dividend payment will be approximately $4.3 million. In July 2003, our Board of Directors elected to begin declaring quarterly dividends on our common stock considering the tax treatment of dividends and adequate levels of Company liquidity.

[0001564590-19-016264:notes:198]
A voluntary early retirement offering was communicated to certain of our employees in Germany in March 2019. These employees were given until April 28, 2019 to accept the early retirement offering. Therefore, as of March 31, 2019, we did not have sufficient information on which to estimate the liability associated with this program. The Company expects to incur approximately $0.8 million in restructuring expense during the second quarter of 2019 related to the early retirement program.
