# ADTN note change history — 0001564590-18-027351 → 0001564590-19-016264


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2019-05-07):
[0001564590-19-016264:note_history:1]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, and we have contributed $8.4 million as of March 31, 2019, of which $7.7 million has been applied to these commitments.
  (was, 2018-11-06, similarity 0.9652):
[0001564590-18-027351:note_history:1]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, and we have contributed $8.4 million as of September 30, 2018, of which $7.7 million has been applied to these commitments.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2019-05-07):
[0001564590-19-016264:note_history:2]
The accompanying unaudited consolidated financial statements of ADTRAN®, Inc. and its subsidiaries (“ADTRAN” or the “Company”) have been prepared pursuant to the rules and regulations for reporting on Quarterly Reports on Form 10-Q. Accordingly, certain information and notes required by generally accepted accounting principles for complete financial statements are not included herein. The December 31, 2018 Consolidated Balance Sheet is derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States.
  (was, 2018-11-06, similarity 0.9732):
[0001564590-18-027351:note_history:2]
The accompanying unaudited consolidated financial statements of ADTRAN®, Inc. and its subsidiaries (ADTRAN) have been prepared pursuant to the rules and regulations for reporting on Quarterly Reports on Form 10-Q. Accordingly, certain information and notes required by generally accepted accounting principles for complete financial statements are not included herein. The December 31, 2017 Consolidated Balance Sheet is derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States.

- changed (2019-05-07):
[0001564590-19-016264:note_history:3]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States of America requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenue and expense during the reporting period. Our more significant estimates include the obsolete and excess inventory reserves, warranty reserves, customer rebates, determination of the deferred and accrued revenue components of multiple element sales agreements, estimated costs to complete obligations associated with deferred and accrued revenue, estimated income tax provision and income tax contingencies, the fair value of stock-based compensation, impairment of goodwill, valuation and estimated lives of intangible assets, estimated pension liability, fair value of investments and the evaluation of other-than-temporary declines in the value of investments. Actual amounts could differ significantly from these estimates.
  (was, 2018-11-06, similarity 0.9817):
[0001564590-18-027351:note_history:3]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States of America requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenue and expense during the reporting period. Our more significant estimates include the obsolete and excess inventory reserves, warranty reserves, customer rebates, determination of the deferred revenue components of multiple element sales agreements, estimated costs to complete obligations associated with deferred revenues, estimated income tax provision and income tax contingencies, the fair value of stock-based compensation, impairment of goodwill, valuation and estimated lives of intangible assets, estimated pension liability, fair value of investments, and the evaluation of other-than-temporary declines in the value of investments. Actual amounts could differ significantly from these estimates.

- added (2019-05-07):
[0001564590-19-016264:note_history:4]
In June 2016, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. ASU 2016-13 requires the measurement and recognition of expected credit losses for financial instruments held at amortized cost. In November 2018, the FASB issued ASU 2018-19, Codification Improvements to Topic 326 Financial Instruments – Credit Losses, that clarifies receivables arising from operating leases are not within the scope of the credit losses standard, but rather, should be accounted for in accordance with the leases standard. ASU 2016-13 and ASU 2018-19 are effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019, with early adoption permitted. We are currently evaluating the effect ASU 2016-13 and ASU 2018-19 will have on our consolidated financial statements.

- changed (2019-05-07):
[0001564590-19-016264:note_history:5]
In January 2017, the FASB issued ASU 2017-04, Intangibles – Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment. ASU 2017-04 simplifies the measurement of goodwill by eliminating step 2 of the goodwill impairment test. Under ASU 2017-04, entities will be required to compare the fair value of a reporting unit to its carrying amount and recognize an impairment charge for the amount by which the carrying amount exceeds the reporting unit’s fair value. ASU 2017-04 is effective for annual or interim impairment tests performed in fiscal years beginning after December 15, 2019, with early adoption permitted for annual or interim impairment tests performed on testing dates after January 1, 2017. The amendments should be applied prospectively. We are currently evaluating whether to early adopt ASU 2017-04, but do not expect it will have a material effect on our consolidated financial statements.
  (was, 2018-11-06, similarity 0.9983):
[0001564590-18-027351:note_history:5]
In January 2017, the FASB issued ASU 2017-04, Intangibles – Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment. ASU 2017-04 simplifies the measurement of goodwill by eliminating step 2 of the goodwill impairment test. Under ASU 2017-04, entities will be required to compare the fair value of a reporting unit to its carrying amount and recognize an impairment charge for the amount by which the carrying amount exceeds the reporting unit’s fair value. ASU 2017-04 is effective for annual or interim impairment tests performed in fiscal years beginning after December 15, 2019, with early adoption permitted for annual or interim impairment tests performed on testing dates after January 1, 2017. The amendments should be applied prospectively. We are currently evaluating whether to early adopt ASU 2017-04, but we do not expect it will have a material effect on our consolidated financial statements.

- changed (2019-05-07):
[0001564590-19-016264:note_history:6]
In August 2018, the FASB issued ASU 2018-13, Fair Value Measurement (Topic 820) Disclosure Framework-Changes to the Disclosure Requirements for Fair Value Measurement, which changes the fair value measurement disclosure requirements of ASC 820, Fair Value Measurement. The amendments in this ASU are the result of a broader disclosure project called, Concepts Statement No. 8 - Conceptual Framework for Financial Reporting — Chapter 8, Notes to Financial Statements, which the FASB finalized on August 28, 2018. The FASB used the guidance in the Concepts Statement to improve the effectiveness of ASC 820’s disclosure requirements. ASU 2018-13 provides users of financial statements with information about assets and liabilities measured at fair value in the statement of financial position or disclosed in the notes to the financial statements. More specifically ASU 2018-13 requires disclosures about the valuation techniques and inputs that are used to arrive at measures of fair value, including judgments and assumptions that are made in determining fair value. In addition, ASU 2018-13 requires disclosures regarding the uncertainty in the fair value measurements as of the reporting date and how changes in fair value measurements affect performance and cash flows. ASU 2018-13 is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. We are currently evaluating the effect of ASU 2018-13, but do not expect it will have a material effect on our financial statement disclosures.
  (was, 2018-11-06, similarity 0.999):
[0001564590-18-027351:note_history:6]
In August 2018, the FASB issued ASU 2018-13, Fair Value Measurement (Topic 820) Disclosure Framework-Changes to the Disclosure Requirements for Fair Value Measurement, which changes the fair value measurement disclosure requirements of ASC 820, Fair Value Measurement. The amendments in this ASU are the result of a broader disclosure project called, Concepts Statement No. 8 -  Conceptual Framework for Financial Reporting — Chapter 8, Notes to Financial Statements, which the FASB finalized on August 28, 2018. The FASB used the guidance in the Concepts Statement to improve the effectiveness of ASC 820’s disclosure requirements.  ASU 2018-13 provides users of financial statements with information about assets and liabilities measured at fair value in the statement of financial position or disclosed in the notes to the financial statements.  More specifically ASU 2018-13 requires disclosures about the valuation techniques and inputs that are used to arrive at measures of fair value, including judgments and assumptions that are made in determining fair value.  In addition, ASU 2018-13 requires disclosures regarding the uncertainty in the fair value measurements as of the reporting date and how changes in fair value measurements affect performance and cash flows.  ASU 2018-13 is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. We are currently evaluating the effect of ASU 2018-13, but we do not expect it will have a material effect on our financial statement disclosures.

- changed (2019-05-07):
[0001564590-19-016264:note_history:7]
In August 2018, the FASB issued ASU 2018-14, Compensation-Retirement Benefits-Defined Benefit Plans-General (Subtopic 715-20): Disclosure Framework-Changes to the Disclosure Requirements for Defined Benefit Plans, which makes changes to and clarifies the disclosure requirements related to defined benefit pension and other postretirement plans. ASU 2018-14 requires additional disclosures related to the reasons for significant gains and losses affecting the benefit obligation and an explanation of any other significant changes in the benefit obligation or plan assets that are not otherwise apparent in other disclosures required by ASC 715. ASU 2018-14 also clarifies the guidance in ASC 715 to require disclosure of the projected benefit obligation (PBO) and fair value of plan assets for pension plans with PBOs in excess of plan assets and the accumulated benefit obligation (ABO) and fair value of plan assets for pension plans with ABOs in excess of plan assets. ASU 2018-14 is effective for public business entities for fiscal years ending after December 15, 2020. We are currently evaluating the effect of ASU 2018-14, but do not expect it will have a material effect on our financial statement disclosures.
  (was, 2018-11-06, similarity 0.9987):
[0001564590-18-027351:note_history:7]
In August 2018, the FASB issued ASU 2018-14, Compensation-Retirement Benefits-Defined Benefit Plans-General (Subtopic 715-20): Disclosure Framework-Changes to the Disclosure Requirements for Defined Benefit Plans, which makes changes to and clarifies the disclosure requirements related to defined benefit pension and other postretirement plans. ASU 2018-14 requires additional disclosures related to the reasons for significant gains and losses affecting the benefit obligation and an explanation of any other significant changes in the benefit obligation or plan assets that are not otherwise apparent in other disclosures required by ASC 715.  ASU 2018-14 also clarifies the guidance in ASC 715 to require disclosure of the projected benefit obligation (PBO) and fair value of plan assets for pension plans with PBOs in excess of plan assets and the accumulated benefit obligation (ABO) and fair value of plan assets for pension plans with ABOs in excess of plan assets. ASU 2018-14 is effective for public business entities for fiscal years ending after December 15, 2020. We are currently evaluating the effect of ASU 2018-14, but we do not expect it will have a material effect on our financial statement disclosures.

- changed (2019-05-07):
[0001564590-19-016264:note_history:8]
In August 2018, the FASB issued ASU 2018-15, Intangibles-Goodwill and Other-Internal-Use Software (Subtopic 350-40), Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract.  ASU 2018-15 clarifies certain aspects of ASU 2015-05, Customer’s Accounting for Fees Paid in a Cloud Computing Arrangement. Specifically, ASU 2018-15 aligns the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementations costs incurred to develop or obtain internal use software. ASU 2018-15 is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019, with early adoption permitted. We are currently evaluating the effect of ASU 2018-15, but do not expect it will have a material effect on our consolidated financial statements.
  (was, 2018-11-06, similarity 0.9734):
[0001564590-18-027351:note_history:8]
In August 2018, the FASB issued ASU 2018-15, Intangibles-Goodwill and Other-Internal-Use Software (Subtopic 350-40), Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract.  ASU 2018-15 clarifies certain aspects of ASU 2015-05, Customer’s Accounting for Fees Paid in a Cloud Computing Arrangement.  Specifically, ASU 2018-15 aligns the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementations costs incurred to develop or obtain internal use software.  ASU 2018-15 is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019, with early adoption permitted.  We are currently evaluating whether to early adopt, but we do not expect it will have a material effect on our consolidated financial statements.

- added (2019-05-07):
[0001564590-19-016264:note_history:9]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842). ASU 2016-02 requires an entity to recognize right-of-use assets and lease liabilities on the balance sheet and to disclose key information about the entity’s leasing arrangements. In July 2018, the FASB issued ASU 2018-10, Codification Improvements to Topic 842, Leases, which clarified certain aspects of ASU 2016-02, as well as, ASU 2018-11, Leases (Topic 842), Targeted Improvements, which provided for an optional transition method which allowed for the application of the legacy lease guidance, including its disclosure requirements, for the comparative periods presented in the year of adoption, with the cumulative effect of initially applying the new lease standard recognized as an adjustment to retained earnings as of the date of adoption. In March 2019, the FASB issued ASU 2019-01, Leases (Topic 824) Codification Improvements, which removed the requirement for an entity to disclose in the interim periods after adoption, the effect of the change on income from continuing operations, net income, any other affected financial statement line item, and any affected per share amount. For lessors, the new leasing standard requires leases to be classified as a sales-type, direct financing or operating leases. These criteria focus on the transfer of control of the underlying lease asset. This standard and related updates were effective for fiscal years beginning after December 15, 2018, and interim periods within those fiscal years.

- added (2019-05-07):
[0001564590-19-016264:note_history:10]
The Company adopted the new standard on January 1, 2019, the effective date of our initial application, using the optional transition method. The Company has elected to carry forward the legacy (ASC 840) disclosures for comparative periods and therefore, did not adjust the comparative period financial information prior to January 1, 2019. In addition, the Company elected the package of practical expedients which allows for companies to not reassess whether any expired or existing contracts are or contain leases, not reassess historical lease classifications for expired or existing contracts and not reassess initial direct costs for existing leases. Additionally, the Company elected the practical expedients which allow the use of hindsight when determining the lease term, the short-term lease recognition exemption and the option to not separate lease and non-lease components. The adoption of this standard resulted in the recognition of a right-of-use asset and corresponding right-of-use liability on our Consolidated Balance Sheet of $10.3 million, mainly related to our operating leases for office space, automobiles and other equipment.

- added (2019-05-07):
[0001564590-19-016264:note_history:11]
As a lessee, the adoption of this standard did not have a material impact on our Consolidated Statement of Income or Statement of Cash Flow. See Note 12 for additional information.

- added (2019-05-07):
[0001564590-19-016264:note_history:12]
As a lessor, the adoption of this standard did not have a material impact on the Company’s Consolidated Balance Sheet, Consolidated Statement of Income or Statement of Cash Flow. Prior to and after adoption, all of our leases in which we are the lessor were classified as sales-types leases.

- added (2019-05-07):
[0001564590-19-016264:note_history:13]
In March 2017, the FASB issued ASU 2017-08, Receivables – Nonrefundable Fees and Other Costs (Subtopic 310-20): Premium Amortization on Purchased Callable Debt Securities, which shortened the amortization period for the premium on certain purchased callable debt securities to the earliest call date. ASU 2017-08 was effective for fiscal years and interim periods within those fiscal years, beginning after December 15, 2018. The amendments were required to be applied through a modified-retrospective transition approach that required a cumulative-effect adjustment directly to retained earnings as of the beginning of the period of adoption. The Company adopted ASU 2017-08 on January 1, 2019, and the adoption of this standard did not have a material effect on our consolidated financial statements.

- added (2019-05-07):
[0001564590-19-016264:note_history:14]
In August 2017, the FASB issued ASU 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities. ASU 2017-12 expanded and refined hedge accounting for both financial and non-financial risk components, aligned the recognition and presentation of the effects of hedging instruments and hedge items in the financial statements, and included certain targeted improvements to ease the application of current guidance related to the assessment of hedge effectiveness.  In October 2018, the FASB issued ASU 2018-16, Derivatives and Hedging (Topic 815): Inclusion of the Secured Overnight Financing Rate (SOFR) Overnight Index Swap (OIS) Rate as a Benchmark Interest Rate for Hedge Accounting, which permits the OIS rate based on SOFR as a U.S. benchmark interest rate. Both ASU 2017-12 and ASU 2018-16 were effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2018. The Company adopted ASU 2017-12 on January 1, 2019, and the adoption of this standard did not have a material effect on our consolidated financial statements as we currently do not have any hedging instruments.

- added (2019-05-07):
[0001564590-19-016264:note_history:15]
In February 2018, the FASB issued ASU 2018-02, Income Statement – Reporting Comprehensive Income (Topic 220): Reclassification of Certain Tax Effects from Accumulated Comprehensive Income. ASU 2018-02 allowed for an optional reclassification from accumulated other comprehensive income to retained earnings for stranded tax effects resulting from the Tax Cuts and Jobs Act of 2017. ASU 2018-02 was effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2018. The Company adopted ASU 2018-02 on January 1, 2019, and upon adoption reclassified $0.4 million of stranded tax effects created by rate changes related to the Tax Cuts and Jobs Act of 2017 to retained earnings. See Note 13 for additional information.

- removed (2019-05-07):
[0001564590-18-027351:note_history:16]
In February 2016, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) 2016-02, Leases (Topic 842). ASU 2016-02 requires an entity to recognize lease assets and lease liabilities on the balance sheet and to disclose key information about the entity's leasing arrangements. In July 2018, the FASB issued ASU 2018-10, Codification Improvements to Topic 842, Leases, which clarified certain aspects of ASU 2016-02, as well as, ASU 2018-11, Leases (Topic 842), Targeted Improvements, which provides for an optional transition method that allows for the application of current legacy guidance, including its disclosure requirements, in the comparative periods presented in the year of adoption.  Otherwise, Topic 842 must be adopted by a modified retrospective method, with elective reliefs, which requires application of the new guidance for all periods presented.   The Company plans to use the optional transition method when adopting the new standard.  ASU 2016-02, ASU 2018-10 and ASU 2018-11 are effective for fiscal years beginning after December 15, 2018, and interim periods within those fiscal years. We anticipate the adoption of these ASUs will have a material increase in the assets and liabilities of our consolidated balance sheets; however, we do not believe adoption will have a material effect on our results of operations. We believe the most significant effect relates to our accounting for operating leases for office space.

- removed (2019-05-07):
[0001564590-18-027351:note_history:17]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. ASU 2016-13 requires the measurement and recognition of expected credit losses for financial instruments held at amortized cost. ASU 2016-13 is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019, with early adoption permitted. We are currently evaluating the effect ASU 2016-13 will have on our consolidated financial statements.

- removed (2019-05-07):
[0001564590-18-027351:note_history:18]
In March 2017, the FASB issued ASU 2017-08, Receivables – Nonrefundable Fees and Other Costs (Subtopic 310-20): Premium Amortization on Purchased Callable Debt Securities, which shortens the amortization period for the premium on certain purchased callable debt securities to the earliest call date.  ASU 2017-08 is effective for fiscal years and interim periods within those fiscal years, beginning after December 15, 2018 with early adoption permitted.  The amendments should be applied through a modified-retrospective transition approach that requires a cumulative-effect adjustment directly to retained earnings as of the beginning of the period of adoption.  We are currently evaluating the effect of ASU 2017-08, but we do not expect it will have a material effect on our consolidated financial statements.

- removed (2019-05-07):
[0001564590-18-027351:note_history:19]
In August 2017, the FASB issued ASU 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities. ASU 2017-12 expands and refines hedge accounting for both financial and non-financial risk components, aligns the recognition and presentation of the effects of hedging instruments and hedge items in the financial statements, and includes certain targeted improvements to ease the application of current guidance related to the assessment of hedge effectiveness. ASU 2017-12 is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2018, with early adoption permitted. We are currently evaluating the effect ASU 2017-12 will have on our consolidated financial statements.

- removed (2019-05-07):
[0001564590-18-027351:note_history:20]
In February 2018, the FASB issued ASU 2018-02, Income Statement – Reporting Comprehensive Income (Topic 220): Reclassification of Certain Tax Effects from Accumulated Comprehensive Income. ASU 2018-02 allows for an optional reclassification from accumulated other comprehensive income to retained earnings for stranded tax effects resulting from the Tax Cuts and Jobs Act of 2017. ASU 2018-02 is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2018, with early adoption permitted. We are currently evaluating whether to reclassify stranded tax effects related to the Tax Cuts and Jobs Act of 2017, but we do not expect ASU 2018-02 will have a material effect on our consolidated financial statements.

- removed (2019-05-07):
[0001564590-18-027351:note_history:21]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers (Topic 606), which supersedes the revenue recognition requirements in Topic 605, Revenue Recognition, including most industry-specific revenue recognition guidance throughout the Industry Topics of the Codification. The core principle of ASU 2014-09 is to recognize revenues when promised goods or services are transferred to customers in an amount that reflects the consideration that is expected to be received for those goods or services. In August 2015, the FASB issued ASU 2015-14, which deferred the effective date of ASU 2014-09 to fiscal years beginning after December 31, 2017, and interim periods within those fiscal years, with early adoption permitted for reporting periods beginning after December 15, 2016. Subsequently, the FASB issued ASUs in 2016 containing implementation guidance related to ASU 2014-09, including: ASU 2016-08, Revenue from Contracts with Customers (Topic 606): Principal versus Agent Considerations (Reporting Revenue Gross versus Net), which is intended to improve the operability and understandability of the implementation guidance on principal versus agent considerations; ASU 2016-10, Revenue from Contracts with Customers (Topic 606): Identifying Performance Obligations and Licensing, which is intended to clarify two aspects of Topic 606: identifying performance obligations and the licensing implementation guidance; ASU 2016-12, Revenue from Contracts with Customers (Topic 606): Narrow-Scope Improvements and Practical Expedients, which contains certain provisions and practical expedients in response to identified implementation issues; and ASU 2016-20, Technical Corrections and Improvements to Topic 606, Revenue from Contracts with Customers, which is intended to clarify the Codification and/or to correct unintended application of guidance. ASU 2014-09 allows for either full retrospective or modified retrospective adoption. We adopted ASU 2014-09 and the related ASUs on January 1, 2018 using the modified retrospective method, which was applied to all contracts on the date of initial adoption.

- removed (2019-05-07):
[0001564590-18-027351:note_history:22]
These ASUs primarily affected our network implementation service revenue performance obligations and contract costs. We are using the “output method” to measure network implementation services progress, which 1) accelerates revenue recognition for certain performance obligations related to service revenue arrangements that were previously deferred until customer acceptance and 2) requires capitalization and amortization of the incremental costs of obtaining a contract as described below.

- removed (2019-05-07):
[0001564590-18-027351:note_history:23]
In connection with the adoption of the new revenue standard, effective January 1, 2018, we adopted ASC 340-40, Other Assets and Deferred Costs – Contracts with Customers, with respect to capitalization and amortization of incremental costs of obtaining a contract. As a result, certain costs of obtaining a contract, including sales commissions, will be capitalized, as the guidance requires the capitalization of all incremental costs incurred to obtain a contract with a customer that it would not have incurred if the contract had not been obtained, provided the costs are recoverable. The primary effect was the capitalization of certain sales commissions for our extended maintenance and support contracts in excess of one year and amortization of those costs over the period that the related revenue is recognized.

- removed (2019-05-07):
[0001564590-18-027351:note_history:24]
The cumulative effect of the changes made to our Consolidated Balance Sheet on January 1, 2018 for the adoption of ASU 2014-09 and the related ASUs was as follows:

- removed (2019-05-07):
[0001564590-18-027351:note_history:25]
| (In thousands) |  | Balance at December 31, 2017 |  |  | Adjustments due to ASU 2014-09 |  |  | Balance at January 1, 2018 |  |
| Other receivables |  | $ | 26,578 |  |  | $ | 374 |  |  | $ | 26,952 |  |
| Deferred tax assets, net |  | $ | 23,428 |  |  | $ | (96 | ) |  | $ | 23,332 |  |
| Retained earnings |  | $ | 922,178 |  |  | $ | 278 |  |  | $ | 922,456 |  |

- removed (2019-05-07):
[0001564590-18-027351:note_history:26]
The effect of the adoption of ASU 2014-09 and the related ASUs on our financial statements was as follows:

- removed (2019-05-07):
[0001564590-18-027351:note_history:27]
|  |  | For the three months ended September 30, 2018 |  |
| (In thousands) |  | As Reported |  |  | Balances Without Adoption of ASC 606 |  |  | Effect of Adoption of ASC 606 |  |
| Sales |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  | $ | 121,043 |  |  | $ | 120,588 |  |  | $ | 455 |  |
| Services |  | $ | 19,292 |  |  | $ | 17,932 |  |  | $ | 1,360 |  |
| Cost of Sales |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  | $ | 69,943 |  |  | $ | 69,754 |  |  | $ | 189 |  |
| Services |  | $ | 11,944 |  |  | $ | 11,046 |  |  | $ | 898 |  |
| Income before benefit for income taxes |  | $ | 3,220 |  |  | $ | 2,492 |  |  | $ | 728 |  |
| Benefit for income taxes |  | $ | 4,369 |  |  | $ | 3,382 |  |  | $ | 987 |  |
| Net income |  | $ | 7,589 |  |  | $ | 5,874 |  |  | $ | 1,715 |  |

- removed (2019-05-07):
[0001564590-18-027351:note_history:28]
|  |  | For the nine months ended September 30, 2018 |  |
| (In thousands) |  | As Reported |  |  | Balances Without Adoption of ASC 606 |  |  | Effect of Adoption of ASC 606 |  |
| Sales |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  | $ | 341,359 |  |  | $ | 341,464 |  |  | $ | (105 | ) |
| Services |  | $ | 47,830 |  |  | $ | 46,062 |  |  | $ | 1,768 |  |
| Cost of Sales |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  | $ | 208,184 |  |  | $ | 208,480 |  |  | $ | (296 | ) |
| Services |  | $ | 32,828 |  |  | $ | 31,743 |  |  | $ | 1,085 |  |
| Loss before benefit for income taxes |  | $ | (22,784 | ) |  | $ | (23,658 | ) |  | $ | 874 |  |
| Benefit for income taxes |  | $ | 11,889 |  |  | $ | 10,938 |  |  | $ | 951 |  |
| Net loss |  | $ | (10,895 | ) |  | $ | (12,720 | ) |  | $ | 1,825 |  |

- removed (2019-05-07):
[0001564590-18-027351:note_history:29]
|  |  | As of September 30, 2018 |  |
| (In thousands) |  | As Reported |  |  | Balances Without Adoption of ASC 606 |  |  | Effect of Adoption of ASC 606 |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Other receivables |  | $ | 30,084 |  |  | $ | 27,917 |  |  | $ | 2,167 |  |
| Inventory |  | $ | 106,060 |  |  | $ | 106,402 |  |  | $ | (342 | ) |
| Equity |  |  |  |  |  |  |  |  |  |  |  |  |
| Retained earnings |  | $ | 900,324 |  |  | $ | 898,499 |  |  | $ | 1,825 |  |

- removed (2019-05-07):
[0001564590-18-027351:note_history:30]
In January 2016, the FASB issued ASU 2016-01, Financial Instruments — Overall: Recognition and Measurement of Financial Assets and Financial Liabilities, which addresses certain aspects of the recognition, measurement, presentation and disclosure of financial instruments. Subsequently, the FASB issued ASU 2018-03, Technical Corrections and Improvements to Financial Instruments – Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities, which issued technical corrections and improvements intended to clarify certain aspects of ASU 2016-01. ASU 2016-01 was effective beginning January 1, 2018 and we now recognize any changes in the fair value of certain equity investments in net income as prescribed by the new standard rather than in other comprehensive income. We adopted ASU 2016-01 on January 1, 2018 using the modified retrospective method, which resulted in a $3.2 million reclassification of net unrealized gains from accumulated other comprehensive income to opening retained earnings. ASU 2018-03 is effective for us with the interim period beginning after June 15, 2018. See Note 7 of Notes to Consolidated Financial Statements for additional information.

- removed (2019-05-07):
[0001564590-18-027351:note_history:31]
In March 2017, the FASB issued ASU 2017-07, Compensation – Retirement Benefits (Topic 715): Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost. ASU 2017-07 amends ASC 715, Compensation — Retirement Benefits, to require employers that present a measure of operating income in their statements of earnings to include only the service cost component of net periodic pension cost and net periodic postretirement benefit cost in operating expenses (together with other employee compensation costs). The other components of net benefit cost, including amortization of prior service cost/credit, and settlement and curtailment effects, are to be included in non-operating expenses. We adopted ASU 2017-07 on January 1, 2018. We retrospectively adopted the presentation of service cost separate from other components of net periodic pension costs. As a result, $0.1 million and $0.3 million have been reclassified from cost of sales, selling, general and administrative expenses, and research and development expense to other income (expense), net for the three and nine months ended September 30, 2017, respectively.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2019-05-07):
[0001564590-19-016264:note_history:32]
At March 31, 2019, we held the following debt securities and other investments, recorded at either fair value or cost:
  (was, 2018-11-06, similarity 0.9561):
[0001564590-18-027351:note_history:32]
At September 30, 2018, we held the following debt securities and other investments, recorded at either fair value or cost:

- changed (2019-05-07):
[0001564590-19-016264:note_history:33]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Carrying |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 15,964 |  |  | $ | 69 |  |  | $ | (24 | ) |  | $ | 16,009 |  |
| Municipal fixed-rate bonds |  |  | 951 |  |  |  | — |  |  |  | (13 | ) |  |  | 938 |  |
| Asset-backed bonds |  |  | 7,171 |  |  |  | 13 |  |  |  | (9 | ) |  |  | 7,175 |  |
| Mortgage/Agency-backed bonds |  |  | 4,561 |  |  |  | 6 |  |  |  | (26 | ) |  |  | 4,541 |  |
| U.S. government bonds |  |  | 4,238 |  |  |  | — |  |  |  | (11 | ) |  |  | 4,227 |  |
| Foreign government bonds |  |  | 2,159 |  |  |  | — |  |  |  | (2 | ) |  |  | 2,157 |  |
| Available-for-sale debt securities held at fair value |  | $ | 35,044 |  |  | $ | 88 |  |  | $ | (85 | ) |  | $ | 35,047 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 25,600 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1,180 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 61,827 |  |
  (was, 2018-11-06, similarity 0.9861):
[0001564590-18-027351:note_history:33]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Carrying |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 32,654 |  |  | $ | 44 |  |  | $ | (155 | ) |  | $ | 32,543 |  |
| Municipal fixed-rate bonds |  |  | 2,902 |  |  |  | 2 |  |  |  | (22 | ) |  |  | 2,882 |  |
| Asset-backed bonds |  |  | 6,545 |  |  |  | 1 |  |  |  | (20 | ) |  |  | 6,526 |  |
| Mortgage/Agency-backed bonds |  |  | 5,554 |  |  |  | 1 |  |  |  | (46 | ) |  |  | 5,509 |  |
| U.S. government bonds |  |  | 14,477 |  |  |  | — |  |  |  | (174 | ) |  |  | 14,303 |  |
| Foreign government bonds |  |  | 725 |  |  |  | 5 |  |  |  | — |  |  |  | 730 |  |
| Available-for-sale debt securities held at fair value |  | $ | 62,857 |  |  | $ | 53 |  |  | $ | (417 | ) |  | $ | 62,493 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 27,800 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 547 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 90,840 |  |

- changed (2019-05-07):
[0001564590-19-016264:note_history:34]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Carrying |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 20,777 |  |  | $ | 19 |  |  | $ | (112 | ) |  | $ | 20,684 |  |
| Municipal fixed-rate bonds |  |  | 1,339 |  |  |  | — |  |  |  | (26 | ) |  |  | 1,313 |  |
| Asset-backed bonds |  |  | 5,230 |  |  |  | 5 |  |  |  | (14 | ) |  |  | 5,221 |  |
| Mortgage/Agency-backed bonds |  |  | 3,833 |  |  |  | 2 |  |  |  | (44 | ) |  |  | 3,791 |  |
| U.S. government bonds |  |  | 9,271 |  |  |  | 1 |  |  |  | (66 | ) |  |  | 9,206 |  |
| Foreign government bonds |  |  | 592 |  |  |  | — |  |  |  | (8 | ) |  |  | 584 |  |
| Available-for-sale debt securities held at fair value |  | $ | 41,042 |  |  | $ | 27 |  |  | $ | (270 | ) |  | $ | 40,799 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 25,600 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 397 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 66,796 |  |
  (was, 2018-11-06, similarity 0.9838):
[0001564590-18-027351:note_history:34]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Carrying |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 25,758 |  |  | $ | 13 |  |  | $ | (209 | ) |  | $ | 25,562 |  |
| Municipal fixed-rate bonds |  |  | 1,451 |  |  |  | — |  |  |  | (36 | ) |  |  | 1,415 |  |
| Asset-backed bonds |  |  | 8,384 |  |  |  | — |  |  |  | (29 | ) |  |  | 8,355 |  |
| Mortgage/Agency-backed bonds |  |  | 5,450 |  |  |  | — |  |  |  | (87 | ) |  |  | 5,363 |  |
| U.S. government bonds |  |  | 19,957 |  |  |  | — |  |  |  | (184 | ) |  |  | 19,773 |  |
| Foreign government bonds |  |  | 593 |  |  |  | 2 |  |  |  | — |  |  |  | 595 |  |
| Available-for-sale debt securities held at fair value |  | $ | 61,593 |  |  | $ | 15 |  |  | $ | (545 | ) |  | $ | 61,063 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 26,700 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 520 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 88,283 |  |

- changed (2019-05-07):
[0001564590-19-016264:note_history:35]
As of March 31, 2019, our debt securities had the following contractual maturities:
  (was, 2018-11-06, similarity 0.9367):
[0001564590-18-027351:note_history:35]
As of September 30, 2018 our debt securities had the following contractual maturities:

- changed (2019-05-07):
[0001564590-19-016264:note_history:36]
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset- backed bonds |  |  | Mortgage / Agency- backed bonds |  |  | U.S. government bonds |  |  | Foreign government bonds |  |
| Less than one year |  | $ | 3,127 |  |  | $ | — |  |  | $ | 872 |  |  | $ | — |  |  | $ | 1,691 |  |  | $ | — |  |
| One to two years |  |  | 8,389 |  |  |  | — |  |  |  | 387 |  |  |  | 289 |  |  |  | — |  |  |  | 1,196 |  |
| Two to three years |  |  | 4,493 |  |  |  | 938 |  |  |  | 976 |  |  |  | — |  |  |  | 1,324 |  |  |  | 961 |  |
| Three to five years |  |  | — |  |  |  | — |  |  |  | 3,105 |  |  |  | 827 |  |  |  | 1,212 |  |  |  | — |  |
| Five to ten years |  |  | — |  |  |  | — |  |  |  | 1,038 |  |  |  | 303 |  |  |  | — |  |  |  | — |  |
| More than ten years |  |  | — |  |  |  | — |  |  |  | 797 |  |  |  | 3,122 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 16,009 |  |  | $ | 938 |  |  | $ | 7,175 |  |  | $ | 4,541 |  |  | $ | 4,227 |  |  | $ | 2,157 |  |
  (was, 2018-11-06, similarity 0.9568):
[0001564590-18-027351:note_history:36]
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset- backed bonds |  |  | Mortgage / Agency- backed bonds |  |  | U.S. government bonds |  |  | Foreign government bonds |  |
| Less than one year |  | $ | 2,800 |  |  | $ | — |  |  | $ | 3,112 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| One to two years |  |  | 10,122 |  |  |  | 287 |  |  |  | 657 |  |  |  | — |  |  |  | 11,716 |  |  |  | 285 |  |
| Two to three years |  |  | 9,898 |  |  |  | 1,128 |  |  |  | 714 |  |  |  | 425 |  |  |  | 5,565 |  |  |  | 310 |  |
| Three to five years |  |  | 2,742 |  |  |  | — |  |  |  | 2,244 |  |  |  | 1,561 |  |  |  | 2,492 |  |  |  | — |  |
| Five to ten years |  |  | — |  |  |  | — |  |  |  | 445 |  |  |  | 525 |  |  |  | — |  |  |  | — |  |
| More than ten years |  |  | — |  |  |  | — |  |  |  | 1,183 |  |  |  | 2,852 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 25,562 |  |  | $ | 1,415 |  |  | $ | 8,355 |  |  | $ | 5,363 |  |  | $ | 19,773 |  |  | $ | 595 |  |

- changed (2019-05-07):
[0001564590-19-016264:note_history:37]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2019 |  |  | 2018 |  |
| Gross realized gains on debt securities |  | $ | 41 |  |  | $ | — |  |
| Gross realized losses on debt securities |  |  | (19 | ) |  |  | (73 | ) |
| Total gain (loss) recognized, net |  | $ | 22 |  |  | $ | (73 | ) |
  (was, 2018-11-06, similarity 0.7247):
[0001564590-18-027351:note_history:37]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Gross realized gains on debt securities |  | $ | 24 |  |  | $ | 91 |  |  | $ | 49 |  |  | $ | 148 |  |
| Gross realized losses on debt securities |  |  | (50 | ) |  |  | (28 | ) |  |  | (365 | ) |  |  | (179 | ) |
| Total gain (loss) recognized, net |  | $ | (26 | ) |  | $ | 63 |  |  | $ | (316 | ) |  | $ | (31 | ) |

- changed (2019-05-07):
[0001564590-19-016264:note_history:38]
At March 31, 2019, we held a $25.6 million restricted certificate of deposit that is carried at cost. This investment serves as a collateral deposit against the principal amount outstanding under loans made to ADTRAN pursuant to an Alabama State Industrial Development Authority revenue bond (the Bond), which totaled $25.6 million at March 31, 2019 and December 31, 2018. At March 31, 2019 and December 31, 2018, the estimated fair value of the Bond using a level 2 valuation technique was approximately $25.5 million and $25.4 million, respectively, based on a debt security with a comparable interest rate and maturity and a Standard and Poor’s credit rating of AAA. We have the right to set-off the balance of the Bond with the collateral deposit in order to reduce the balance of the indebtedness. The Bond matures on January 1, 2020, and bears interest at the rate of 2% per annum. In conjunction with this program, we are eligible to receive certain economic incentives from the state of Alabama that reduce the amount of payroll withholdings we are required to remit to the state for those employment positions that qualify under this program. We are required to make payments in the amounts necessary to pay the interest on the amounts currently outstanding. It is our intent to make annual principal payments in addition to the interest amounts that are due. The restricted funds held as collateral against the principal amount of the Bond will be used to pay the outstanding principal and interest upon the Bond’s maturity on January 1, 2020.
  (was, 2018-11-06, similarity 0.9042):
[0001564590-18-027351:note_history:38]
At September 30, 2018, we held a $26.7 million restricted certificate of deposit that is carried at cost. This investment serves as a collateral deposit against the principal amount outstanding under loans made to ADTRAN pursuant to an Alabama State Industrial Development Authority revenue bond (the Bond), which totaled $26.7 million at September 30, 2018 and December 31, 2017. At September 30, 2018 and December 31, 2017, the estimated fair value of the Bond using a level 2 valuation technique was approximately $26.5 million and $26.7 million, respectively, based on a debt security with a comparable interest rate and maturity and a Standard and Poor’s credit rating of AAA. We have the right to set-off the balance of the Bond with the collateral deposit in order to reduce the balance of the indebtedness. The Bond matures on January 1, 2020, and bears interest at the rate of 2% per annum. In conjunction with this program, we are eligible to receive certain economic incentives from the state of Alabama that reduce the amount of payroll withholdings we are required to remit to the state for those employment positions that qualify under this program. We are required to make payments in the amounts necessary to pay the interest on the amounts currently outstanding. It is our intent to make annual principal payments in addition to the interest amounts that are due.

- changed (2019-05-07):
[0001564590-19-016264:note_history:39]
Our marketable equity securities consist of publicly traded stock, funds and certain other investments measured at fair value or cost (where appropriate).
  (was, 2018-11-06, similarity 0.751):
[0001564590-18-027351:note_history:39]
Our marketable equity securities consist of publicly traded stocks or funds measured at fair value.

- changed (2019-05-07):
[0001564590-19-016264:note_history:40]
On January 1, 2018, we adopted ASU 2016-01, which requires us to measure all equity investments that do not result in consolidation and are not accounted for under the equity method at fair value, with any changes in fair value recognized in net investment gain (loss). Upon adoption, we reclassified $3.2 million of net unrealized gains related to marketable equity securities from accumulated other comprehensive income (loss) to retained earnings.
  (was, 2018-11-06, similarity 0.991):
[0001564590-18-027351:note_history:40]
On January 1, 2018, we adopted ASU 2016-01, which requires us to measure all equity investments that do not result in consolidation and are not accounted for under the equity method at fair value, with any changes in fair value recognized in net investment gain (loss). Upon adoption, we reclassified $3.2 million of net unrealized gains related to marketable equity securities from accumulated other comprehensive income (loss) to opening retained earnings.

- added (2019-05-07):
[0001564590-19-016264:note_history:41]
ASU 2016-01 also provides a measurement alternative for equity investments that do not have a readily determinable fair value in which investments can be recorded at cost less impairment, if any, adjusted for observable price changes for an identical or similar investment. We elected to record our equity investment that does not have a readily determinable fair value using the measurement alternative method. The carrying value of this investment was $3.4 million and $0 as of March 31, 2019 and December 31, 2018, respectively.

- changed (2019-05-07):
[0001564590-19-016264:note_history:42]
Realized and unrealized gains and losses for our marketable equity securities for the three months ended March 31, 2019 and 2018 were as follows:
  (was, 2018-11-06, similarity 0.911):
[0001564590-18-027351:note_history:42]
Realized and unrealized gains and losses for our marketable equity securities for the three and nine months ended September 30, 2018 were as follows:

- added (2019-05-07):
[0001564590-19-016264:note_history:43]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2019 |  |  | 2018 |  |
| Realized gains (losses) on equity securities sold |  | $ | (14 | ) |  | $ | 398 |  |
| Unrealized gains (losses) on equity securities held |  |  | 5,918 |  |  |  | (422 | ) |
| Total gain (loss) recognized, net |  | $ | 5,904 |  |  | $ | (24 | ) |

- changed (2019-05-07):
[0001564590-19-016264:note_history:44]
As of March 31, 2019 and 2018, gross unrealized losses related to individual investments in a continuous loss position for twelve months or longer were not significant.
  (was, 2018-11-06, similarity 0.9689):
[0001564590-18-027351:note_history:44]
As of September 30, 2018 and 2017, gross unrealized losses related to individual investments in a continuous loss position for twelve months or longer were not significant.

- changed (2019-05-07):
[0001564590-19-016264:note_history:45]
|  |  |  |  |  |  | Fair Value Measurements at March 31, 2019 Using |  |
| (In thousands) |  | Cost or Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,279 |  |  | $ | 1,279 |  |  | $ | — |  |  | $ | — |  |
| Commercial paper |  |  | 6,547 |  |  |  | — |  |  |  | 6,547 |  |  |  | — |  |
| Cash equivalents |  |  | 7,826 |  |  |  | 1,279 |  |  |  | 6,547 |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 16,009 |  |  |  | — |  |  |  | 16,009 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 938 |  |  |  | — |  |  |  | 938 |  |  |  | — |  |
| Asset-backed bonds |  |  | 7,175 |  |  |  | — |  |  |  | 7,175 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 4,541 |  |  |  | — |  |  |  | 4,541 |  |  |  | — |  |
| U.S. government bonds |  |  | 4,227 |  |  |  | 4,227 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 2,157 |  |  |  | — |  |  |  | 2,157 |  |  |  | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  | — |  |
| Marketable equity securities – various industries |  |  | 30,725 |  |  |  | 30,725 |  |  |  | — |  |  |  | — |  |
| Equity in escrow |  |  | 174 |  |  |  | 174 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 20,416 |  |  |  | 20,416 |  |  |  | — |  |  |  | — |  |
| Total debt and equity securities at fair value |  |  | 86,362 |  |  |  | 55,542 |  |  |  | 30,820 |  |  |  | — |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Other investments |  |  | 3,375 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total other investments held at cost |  |  | 3,375 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 97,563 |  |  | $ | 56,821 |  |  | $ | 37,367 |  |  | $ | — |  |
  (was, 2018-11-06, similarity 0.8415):
[0001564590-18-027351:note_history:45]
|  |  | Fair Value Measurements at December 31, 2017 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 5,851 |  |  | $ | 5,851 |  |  | $ | — |  |  | $ | — |  |
| Commercial paper |  |  | 3,999 |  |  |  | — |  |  |  | 3,999 |  |  |  | — |  |
| Cash equivalents |  |  | 9,850 |  |  |  | 5,851 |  |  |  | 3,999 |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 32,543 |  |  |  | — |  |  |  | 32,543 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 2,882 |  |  |  | — |  |  |  | 2,882 |  |  |  | — |  |
| Asset-backed bonds |  |  | 6,526 |  |  |  | — |  |  |  | 6,526 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 5,509 |  |  |  | — |  |  |  | 5,509 |  |  |  | — |  |
| U.S. government bonds |  |  | 14,303 |  |  |  | 14,303 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 730 |  |  |  | — |  |  |  | 730 |  |  |  | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 35,662 |  |  |  | 35,662 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 19,883 |  |  |  | 19,883 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 118,038 |  |  |  | 69,848 |  |  |  | 48,190 |  |  |  | — |  |
| Total |  | $ | 127,888 |  |  | $ | 75,699 |  |  | $ | 52,189 |  |  | $ | — |  |

- changed (2019-05-07):
[0001564590-19-016264:note_history:46]
|  |  |  |  |  |  | Fair Value Measurements at December 31, 2018 Using |  |
| (In thousands) |  | Cost or Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,554 |  |  | $ | 1,554 |  |  | $ | — |  |  | $ | — |  |
| Cash equivalents |  |  | 1,554 |  |  |  | 1,554 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 20,684 |  |  |  | — |  |  |  | 20,684 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 1,313 |  |  |  | — |  |  |  | 1,313 |  |  |  | — |  |
| Asset-backed bonds |  |  | 5,221 |  |  |  | — |  |  |  | 5,221 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 3,791 |  |  |  | — |  |  |  | 3,791 |  |  |  | — |  |
| U.S. government bonds |  |  | 9,206 |  |  |  | 9,206 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 584 |  |  |  | — |  |  |  | 584 |  |  |  | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 26,763 |  |  |  | 26,763 |  |  |  | — |  |  |  | — |  |
| Equity in escrow |  |  | 253 |  |  |  | 253 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 18,256 |  |  |  | 18,256 |  |  |  | — |  |  |  | — |  |
| Total debt and equity securities at fair value |  |  | 86,071 |  |  |  | 54,478 |  |  |  | 31,593 |  |  |  | — |  |
| Total |  | $ | 87,625 |  |  | $ | 56,032 |  |  | $ | 31,593 |  |  | $ | — |  |
  (was, 2018-11-06, similarity 0.9379):
[0001564590-18-027351:note_history:46]
|  |  | Fair Value Measurements at September 30, 2018 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,423 |  |  | $ | 1,423 |  |  | $ | — |  |  | $ | — |  |
| Foreign government securities |  |  | 600 |  |  |  | — |  |  |  | 600 |  |  |  | — |  |
| Cash equivalents |  |  | 2,023 |  |  |  | 1,423 |  |  |  | 600 |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 25,562 |  |  |  | — |  |  |  | 25,562 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 1,415 |  |  |  | — |  |  |  | 1,415 |  |  |  | — |  |
| Asset-backed bonds |  |  | 8,355 |  |  |  | — |  |  |  | 8,355 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 5,363 |  |  |  | — |  |  |  | 5,363 |  |  |  | — |  |
| U.S. government bonds |  |  | 19,773 |  |  |  | 19,773 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 595 |  |  |  | — |  |  |  | 595 |  |  |  | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  | — |  |
| Marketable equity securities – various industries |  |  | 40,645 |  |  |  | 40,645 |  |  |  | — |  |  |  | — |  |
| Equity in escrow |  |  | 277 |  |  |  | 277 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 20,948 |  |  |  | 20,948 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 122,933 |  |  |  | 81,643 |  |  |  | 41,290 |  |  |  | — |  |
| Total |  | $ | 124,956 |  |  | $ | 83,066 |  |  | $ | 41,890 |  |  | $ | — |  |

- removed (2019-05-07):
[0001564590-18-027351:note_history:47]
Prior to January 1, 2018, our marketable equity securities were classified as available-for-sale. Realized gains and losses on marketable equity securities were included in net investment gain (loss). Unrealized gains and losses were recognized in accumulated other comprehensive income, net of deferred taxes, on the balance sheet.

- removed (2019-05-07):
[0001564590-18-027351:note_history:48]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2018 |  |  | 2018 |  |
| Realized gains (losses) on equity securities sold |  | $ | 1,240 |  |  | $ | 1,587 |  |
| Unrealized gains (losses) on equity securities held |  |  | 3,293 |  |  |  | 4,129 |  |
| Total gain (loss) recognized, net |  | $ | 4,533 |  |  | $ | 5,716 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2019-05-07):
[0001564590-19-016264:note_history:49]
The following table disaggregates our revenue by major source for the three months ended March 31, 2019:
  (was, 2018-11-06, similarity 0.9505):
[0001564590-18-027351:note_history:49]
The following table disaggregates our revenue by major source for the three months ended September 30, 2018:

- added (2019-05-07):
[0001564590-19-016264:note_history:50]
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 85,673 |  |  | $ | 14,105 |  |  | $ | 99,778 |  |
| Subscriber Solutions & Experience(1) |  |  | 34,719 |  |  |  | 2,034 |  |  |  | 36,753 |  |
| Traditional & Other Products |  |  | 5,430 |  |  |  | 1,830 |  |  |  | 7,260 |  |
| Total |  | $ | 125,822 |  |  | $ | 17,969 |  |  | $ | 143,791 |  |

- added (2019-05-07):
[0001564590-19-016264:note_history:51]
|  | (1) | Subscriber Solutions & Experience was formerly reported as Customer Devices. With the increasing focus on enhancing the customer experience for both our business and consumer broadband customers and the addition of SmartRG during the fourth quarter of 2018, Subscriber Solutions & Experience more accurately represents this revenue category. |

- changed (2019-05-07):
[0001564590-19-016264:note_history:52]
The following table disaggregates our revenue by major source for the three months ended March 31, 2018:
  (was, 2018-11-06, similarity 0.9154):
[0001564590-18-027351:note_history:52]
The following table disaggregates our revenue by major source for the nine months ended September 30, 2018:

- added (2019-05-07):
[0001564590-19-016264:note_history:53]
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 69,385 |  |  | $ | 12,295 |  |  | $ | 81,680 |  |
| Subscriber Solutions & Experience(1) |  |  | 28,777 |  |  |  | 1,324 |  |  |  | 30,101 |  |
| Traditional & Other Products |  |  | 7,091 |  |  |  | 1,934 |  |  |  | 9,025 |  |
| Total |  | $ | 105,253 |  |  | $ | 15,553 |  |  | $ | 120,806 |  |

- added (2019-05-07):
[0001564590-19-016264:note_history:54]
|  | (1) | Subscriber Solutions & Experience was formerly reported as Customer Devices. With the increasing focus on enhancing the customer experience for both our business and consumer broadband customers and the addition of SmartRG during the fourth quarter of 2018, Subscriber Solutions & Experience more accurately represents this revenue category. |

- added (2019-05-07):
[0001564590-19-016264:note_history:55]
The table below presents sales information by category for the three months ended March 31, 2019 and 2018:

- added (2019-05-07):
[0001564590-19-016264:note_history:56]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2019 |  |  | 2018 |  |
| Access & Aggregation |  | $ | 99,778 |  |  | $ | 81,680 |  |
| Subscriber Solutions & Experience |  |  | 36,753 |  |  |  | 30,101 |  |
| Traditional & Other Products |  |  | 7,260 |  |  |  | 9,025 |  |
| Total |  | $ | 143,791 |  |  | $ | 120,806 |  |

- removed (2019-05-07):
[0001564590-18-027351:note_history:57]
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 76,046 |  |  | $ | 15,855 |  |  | $ | 91,901 |  |
| Customer Devices |  |  | 37,313 |  |  |  | 1,239 |  |  |  | 38,552 |  |
| Traditional & Other Products |  |  | 7,684 |  |  |  | 2,198 |  |  |  | 9,882 |  |
| Total |  | $ | 121,043 |  |  | $ | 19,292 |  |  | $ | 140,335 |  |

- removed (2019-05-07):
[0001564590-18-027351:note_history:58]
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 220,653 |  |  | $ | 37,670 |  |  | $ | 258,323 |  |
| Customer Devices |  |  | 99,396 |  |  |  | 3,817 |  |  |  | 103,213 |  |
| Traditional & Other Products |  |  | 21,310 |  |  |  | 6,343 |  |  |  | 27,653 |  |
| Total |  | $ | 341,359 |  |  | $ | 47,830 |  |  | $ | 389,189 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2019-05-07):
[0001564590-19-016264:note_history:59]
Network Solutions includes hardware products and software-defined next-generation virtualized solutions used in service provider or business networks, as well as prior generation products. The majority of the revenue from this segment is from hardware sales. In certain transactions, we are also the lessor in sales-type lease arrangements for network equipment. These arrangements typically include network equipment, network implementation services and maintenance services. See Note 12 for additional information.

- changed (2019-05-07):
[0001564590-19-016264:note_history:60]
To complement our Network Solutions segment, we offer a complete portfolio of maintenance, network implementation and solutions integration and managed services, which include hosted cloud services and subscription services.
  (was, 2018-11-06, similarity 0.9978):
[0001564590-18-027351:note_history:60]
To complement our Network Solutions segment, we offer a complete portfolio of maintenance, network implementation, and solutions integration and managed services, which include hosted cloud services and subscription services.

- added (2019-05-07):
[0001564590-19-016264:note_history:61]
In addition to our reporting segments, we also report revenue in the following three categories – Access & Aggregation, Subscriber Solutions & Experience, and Traditional & Other Products.

- changed (2019-05-07):
[0001564590-19-016264:note_history:62]
The following table disaggregates our revenue by major source for the three months ended March 31, 2019:
  (was, 2018-11-06, similarity 0.9505):
[0001564590-18-027351:note_history:62]
The following table disaggregates our revenue by major source for the three months ended September 30, 2018:

- added (2019-05-07):
[0001564590-19-016264:note_history:63]
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 85,673 |  |  | $ | 14,105 |  |  | $ | 99,778 |  |
| Subscriber Solutions & Experience(1) |  |  | 34,719 |  |  |  | 2,034 |  |  |  | 36,753 |  |
| Traditional & Other Products |  |  | 5,430 |  |  |  | 1,830 |  |  |  | 7,260 |  |
| Total |  | $ | 125,822 |  |  | $ | 17,969 |  |  | $ | 143,791 |  |

- added (2019-05-07):
[0001564590-19-016264:note_history:64]
|  | (1) | Subscriber Solutions & Experience was formerly reported as Customer Devices. With the increasing focus on enhancing the customer experience for both our business and consumer broadband customers and the addition of SmartRG during the fourth quarter of 2018, Subscriber Solutions & Experience more accurately represents this revenue category. |

- changed (2019-05-07):
[0001564590-19-016264:note_history:65]
The following table disaggregates our revenue by major source for the three months ended March 31, 2018:
  (was, 2018-11-06, similarity 0.9154):
[0001564590-18-027351:note_history:65]
The following table disaggregates our revenue by major source for the nine months ended September 30, 2018:

- added (2019-05-07):
[0001564590-19-016264:note_history:66]
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 69,385 |  |  | $ | 12,295 |  |  | $ | 81,680 |  |
| Subscriber Solutions & Experience(1) |  |  | 28,777 |  |  |  | 1,324 |  |  |  | 30,101 |  |
| Traditional & Other Products |  |  | 7,091 |  |  |  | 1,934 |  |  |  | 9,025 |  |
| Total |  | $ | 105,253 |  |  | $ | 15,553 |  |  | $ | 120,806 |  |

- added (2019-05-07):
[0001564590-19-016264:note_history:67]
|  | (1) | Subscriber Solutions & Experience was formerly reported as Customer Devices. With the increasing focus on enhancing the customer experience for both our business and consumer broadband customers and the addition of SmartRG during the fourth quarter of 2018, Subscriber Solutions & Experience more accurately represents this revenue category. |

- changed (2019-05-07):
[0001564590-19-016264:note_history:68]
As of March 31, 2019, we did not have any significant performance obligations related to customer contracts that had an original expected duration of one year or more, other than maintenance services, which are satisfied over time.
  (was, 2018-11-06, similarity 0.9692):
[0001564590-18-027351:note_history:68]
As of September 30, 2018, we did not have any significant performance obligations related to customer contracts that had an original expected duration of one year or more, other than maintenance services, which are satisfied over time.

- changed (2019-05-07):
[0001564590-19-016264:note_history:69]
The following table provides information about receivables, contract assets and unearned revenue from contracts with customers:
  (was, 2018-11-06, similarity 0.9961):
[0001564590-18-027351:note_history:69]
The following table provides information about receivables, contract assets, and unearned revenue from contracts with customers:

- changed (2019-05-07):
[0001564590-19-016264:note_history:70]
| (In thousands) |  | March 31, 2019 |  |  | December 31, 2018 |  |
| Accounts receivable, net |  | $ | 99,032 |  |  | $ | 99,385 |  |
| Contract assets |  | $ | 2,333 |  |  | $ | 3,766 |  |
| Unearned revenue |  | $ | 15,230 |  |  | $ | 17,940 |  |
| Non-current unearned revenue |  | $ | 4,514 |  |  | $ | 5,296 |  |
  (was, 2018-11-06, similarity 0.9084):
[0001564590-18-027351:note_history:70]
| (In thousands) |  | September 30, 2018 |  |  | January 1, 2018 |  |
| Accounts receivable |  | $ | 101,865 |  |  | $ | 144,150 |  |
| Contract assets |  | $ | 4,564 |  |  | $ | 374 |  |
| Unearned revenue |  | $ | 17,004 |  |  | $ | 13,070 |  |
| Non-current unearned revenue |  | $ | 3,846 |  |  | $ | 4,556 |  |

- added (2019-05-07):
[0001564590-19-016264:note_history:71]
$6.9 million of the outstanding unearned revenue balance at December 31, 2018 was recognized as revenue during the three months ended March 31, 2019.

- removed (2019-05-07):
[0001564590-18-027351:note_history:72]
Revenue is measured based on the consideration we expect to receive in exchange for transferring goods or providing services to a customer and as performance obligations under the terms of the contract are satisfied. Generally, this occurs with the transfer of control of a product or service to the customer. For transactions where there are multiple performance obligations, we account for individual products and services separately if they are distinct (if a product or service is separately identifiable from other items and if a customer can benefit from it on its own or with other resources that are readily available to the customer). The consideration, including any discounts, is allocated between separate products and services based on their stand-alone selling prices. The stand-alone selling prices are determined based on the prices at which we sell the separate products and services and are allocated based on each item’s relative value to the total value of the products and services in the arrangement. For items that are not sold separately, we estimate stand-alone selling prices primarily using the “expected cost plus a margin” approach. Payment terms are typically 30 days. Shipping fees are recorded as revenue and the related cost is included in cost of sales. Sales, value-added, and other taxes collected concurrently with revenue-producing activities are excluded from revenue. Costs of obtaining a contract are capitalized and amortized over the period that the related revenue is recognized if greater than one year. We have elected to apply the practical expedient related to the incremental costs of obtaining contracts and recognize those costs as an expense when incurred if the amortization period of the assets is one year or less. These costs are included in selling, general and administrative expenses. Capitalized costs with an amortization period greater than one year were immaterial.

- removed (2019-05-07):
[0001564590-18-027351:note_history:73]
Network Solutions includes hardware products and next-generation virtualized solutions used in service provider or business networks, as well as prior generation products.

- removed (2019-05-07):
[0001564590-18-027351:note_history:74]
Hardware

- removed (2019-05-07):
[0001564590-18-027351:note_history:75]
The majority of the revenue from this segment is from hardware sales and is recognized when control is transferred to our customers, which is generally when we ship the products. Shipping terms are generally FOB shipping point. Revenue is recorded net of estimated discounts and rebates using historical trends. Customers are typically invoiced when control is transferred and revenue is recognized. Our products generally include assurance-based warranties of 90 days to five years for product defects, which are accrued at the time revenue is recognized.

- removed (2019-05-07):
[0001564590-18-027351:note_history:76]
In certain transactions, we are also the lessor in sales-type lease arrangements for network equipment that have terms of 18 months to five years. These arrangements typically include network equipment, network implementation services and maintenance services. Product revenue for these leases is generally recorded when we transfer control of the product to our customers. Revenue for network implementation and maintenance services is recognized as described below. Customers are typically invoiced and pay in equal installments over the lease term. In relation to these lease agreements, during the three months ended September 30, 2018 and 2017, we recognized revenue of $4.2 million and $8.4 million, respectively, and during the nine months ended September 30, 2018 and 2017 we recognized revenue of $10.5 million and $15.4 million, respectively.

- removed (2019-05-07):
[0001564590-18-027351:note_history:77]
Maintenance

- removed (2019-05-07):
[0001564590-18-027351:note_history:78]
Our maintenance service periods range from one month to five years. Customers are typically invoiced and pay for maintenance services at the beginning of the maintenance period. We recognize revenue for maintenance services on a straight-line basis over the maintenance period in services revenue as our customers benefit evenly throughout the contract term and deferred revenues are recorded in current and non-current unearned revenue.

- removed (2019-05-07):
[0001564590-18-027351:note_history:79]
Network Implementation

- removed (2019-05-07):
[0001564590-18-027351:note_history:80]
We recognize revenue for network implementation, which primarily consists of engineering, execution and enablement services, at a point in time when each performance obligation is complete. If we have recognized revenue, but have not billed the customer, the right to consideration is recognized as a contract asset that is included in other receivables in the Consolidated Balance Sheet. The contract asset is transferred to accounts receivable when the completed performance obligation is invoiced to the customer.

- removed (2019-05-07):
[0001564590-18-027351:note_history:81]
The decrease in accounts receivable is due to the collection of customer specific payment terms that became due in the first quarter of 2018. The increase in the contract asset balance for the nine months ended September 30, 2018 is primarily attributable to revenue recognized that has not yet been billed to the customer during the period. The increase in the unearned revenue balance as of nine months ended September 30, 2018 is primarily attributable to cash payments received or due in advance of satisfying our performance obligations, offset by $8.9 million of revenues recognized that were included in the unearned revenue balance as of December 31, 2017.

- removed (2019-05-07):
[0001564590-18-027351:note_history:82]
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 76,046 |  |  | $ | 15,855 |  |  | $ | 91,901 |  |
| Customer Devices |  |  | 37,313 |  |  |  | 1,239 |  |  |  | 38,552 |  |
| Traditional & Other Products |  |  | 7,684 |  |  |  | 2,198 |  |  |  | 9,882 |  |
| Total |  | $ | 121,043 |  |  | $ | 19,292 |  |  | $ | 140,335 |  |

- removed (2019-05-07):
[0001564590-18-027351:note_history:83]
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 220,653 |  |  | $ | 37,670 |  |  | $ | 258,323 |  |
| Customer Devices |  |  | 99,396 |  |  |  | 3,817 |  |  |  | 103,213 |  |
| Traditional & Other Products |  |  | 21,310 |  |  |  | 6,343 |  |  |  | 27,653 |  |
| Total |  | $ | 341,359 |  |  | $ | 47,830 |  |  | $ | 389,189 |  |


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2019-05-07):
[0001564590-19-016264:note_history:84]
On April 17, 2019, we announced that our Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to stockholders of record at the close of business on May 2, 2019. The payment date will be May 16, 2019. The quarterly dividend payment will be approximately $4.3 million. In July 2003, our Board of Directors elected to begin declaring quarterly dividends on our common stock considering the tax treatment of dividends and adequate levels of Company liquidity.
  (was, 2018-11-06, similarity 0.9651):
[0001564590-18-027351:note_history:84]
On October 16, 2018, we announced that our Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to stockholders of record at the close of business on October 31, 2018. The payment date will be November 14, 2018. The quarterly dividend payment will be approximately $4.3 million. In July 2003, our Board of Directors elected to begin declaring quarterly dividends on our common stock considering the tax treatment of dividends and adequate levels of Company liquidity.

- added (2019-05-07):
[0001564590-19-016264:note_history:85]
A voluntary early retirement offering was communicated to certain of our employees in Germany in March 2019. These employees were given until April 28, 2019 to accept the early retirement offering. Therefore, as of March 31, 2019, we did not have sufficient information on which to estimate the liability associated with this program. The Company expects to incur approximately $0.8 million in restructuring expense during the second quarter of 2019 related to the early retirement program.

- removed (2019-05-07):
[0001564590-18-027351:note_history:86]
During the 4th quarter and as of November 6, 2018, we have repurchased 0.1 million shares of our common stock through open market purchases at an average cost of $13.60 per share.  We currently have the authority to purchase an additional 2.6 million shares of our common stock under the current plan approved by the Board of Directors.
