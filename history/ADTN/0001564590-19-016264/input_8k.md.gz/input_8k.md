# ADTN 8-K — 0001564590-19-011897 filed 2019-04-18

## item codes, every 8-K on or before 2019-05-07

- 2019-04-18 0001564590-19-011897 — 2.02, 9.01
- 2019-03-07 0001564590-19-006575 — 5.02, 9.01
- 2019-01-24 0001564590-19-001024 — 2.02, 9.01
- 2018-12-06 0001564590-18-030615 — 8.01, 9.01
- 2018-10-17 0001564590-18-024365 — 2.02, 9.01
- 2018-07-18 0001564590-18-016946 — 2.02, 9.01
- 2018-05-10 0001564590-18-012968 — 5.07
- 2018-04-18 0001564590-18-008361 — 2.02, 9.01
- 2018-03-21 0001564590-18-006409 — 8.01, 9.01
- 2018-01-17 0001564590-18-000519 — 2.02, 9.01
- 2017-12-29 0001564590-17-025375 — 2.02, 9.01
- 2017-11-16 0001193125-17-345232 — 5.02
- 2017-10-18 0001564590-17-019582 — 2.02, 9.01
- 2017-07-19 0001564590-17-013609 — 2.02, 9.01
- 2017-05-11 0001564590-17-010459 — 5.02, 9.01
- 2017-05-11 0001564590-17-010452 — 5.07
- 2017-04-19 0001193125-17-127926 — 2.02, 9.01
- 2017-02-07 0001193125-17-032714 — 8.01
- 2017-01-18 0001193125-17-011669 — 2.02, 9.01
- 2016-11-16 0001193125-16-769505 — 5.02, 9.01
- 2016-10-19 0001193125-16-741087 — 2.02, 9.01
- 2016-09-14 0001193125-16-709148 — 8.01, 9.01
- 2016-08-17 0001193125-16-683980 — 5.02, 9.01
- 2016-07-13 0001193125-16-646816 — 2.02, 9.01
- 2016-05-13 0001193125-16-590263 — 5.07
- 2016-04-13 0001193125-16-539019 — 2.02, 9.01
- 2016-04-08 0001193125-16-535035 — 7.01
- 2016-02-11 0001193125-16-459453 — 5.02, 9.01
- 2016-01-20 0001193125-16-432934 — 2.02, 9.01
- 2015-11-16 0001193125-15-378019 — 5.02, 9.01
- 2015-10-14 0001193125-15-343083 — 2.02, 9.01
- 2015-07-16 0001193125-15-254729 — 8.01, 9.01
- 2015-07-15 0001193125-15-253068 — 2.02, 9.01
- 2015-05-15 0001193125-15-189160 — 5.07, 9.01
- 2015-04-22 0001193125-15-140997 — 2.02, 9.01
- 2015-02-23 0001193125-15-056741 — 5.02, 9.01
- 2015-01-21 0001193125-15-015465 — 2.02, 9.01
- 2014-10-15 0001193125-14-372076 — 2.02, 9.01
- 2014-10-03 0001193125-14-363152 — 2.02, 9.01
- 2014-07-16 0001193125-14-269660 — 2.02, 9.01
- 2014-05-20 0001193125-14-205916 — 8.01, 9.01
- 2014-05-20 0001193125-14-205906 — 5.02, 9.01
- 2014-05-15 0001193125-14-201144 — 5.07
- 2014-04-16 0001193125-14-144665 — 2.02, 9.01
- 2014-04-03 0001193125-14-129578 — 2.02, 9.01
- 2014-01-22 0001157523-14-000154 — 2.02, 9.01
- 2013-10-15 0001193125-13-399540 — 5.02
- 2013-10-09 0001157523-13-004657 — 2.02, 9.01
- 2013-07-10 0001157523-13-003290 — 2.02, 9.01
- 2013-05-10 0001193125-13-213728 — 5.07
- 2013-05-03 0001193125-13-198816 — 8.01, 9.01
- 2013-04-10 0001157523-13-001730 — 2.02, 9.01
- 2013-01-16 0001157523-13-000139 — 2.02, 9.01
- 2012-10-10 0001157523-12-005081 — 2.02, 9.01
- 2012-10-03 0001193125-12-413609 — 7.01
- 2012-09-28 0001193125-12-408878 — 2.02, 9.01
- 2012-07-11 0001157523-12-003592 — 2.02, 9.01
- 2012-05-10 0001193125-12-225669 — 5.07
- 2012-05-10 0001193125-12-225639 — 8.01, 9.01
- 2012-04-11 0001157523-12-001772 — 2.02, 9.01
- 2012-03-15 0001193125-12-116494 — 2.02, 9.01
- 2012-01-18 0001157523-12-000174 — 2.02, 9.01
- 2011-12-12 0001193125-11-337271 — 7.01, 9.01
- 2011-10-13 0000950123-11-089785 — 5.03, 9.01
- 2011-10-12 0001157523-11-005682 — 2.02, 9.01
- 2011-07-13 0001157523-11-003986 — 2.02, 9.01
- 2011-05-09 0000950123-11-047191 — 5.02, 5.07, 9.01
- 2011-04-13 0001157523-11-002001 — 2.02, 9.01
- 2011-01-19 0001157523-11-000232 — 2.02, 9.01
- 2010-11-09 0000950123-10-103195 — 5.02, 9.01
- 2010-10-13 0001157523-10-005798 — 2.02, 9.01
- 2010-07-14 0001157523-10-004011 — 2.02, 9.01
- 2010-05-28 0000950123-10-053947 — 5.07
- 2010-04-14 0001157523-10-002022 — 2.02, 9.01
- 2010-01-20 0001157523-10-000200 — 2.02, 9.01
- 2009-10-28 0000950123-09-053984 — 8.01
- 2009-10-14 0001157523-09-006877 — 2.02, 9.01
- 2009-07-15 0001157523-09-004878 — 2.02, 9.01
- 2009-04-15 0001157523-09-002687 — 2.02, 9.01
- 2009-01-21 0001157523-09-000340 — 2.02, 9.01
- 2008-11-12 0001193125-08-233181 — 5.02, 9.01
- 2008-10-14 0001157523-08-007999 — 2.02, 9.01
- 2008-07-15 0001157523-08-005504 — 2.02, 9.01
- 2008-04-15 0001157523-08-002896 — 2.02, 9.01
- 2008-01-22 0001157523-08-000408 — 2.02, 9.01
- 2007-10-16 0001193125-07-219356 — 5.03, 9.01
- 2007-10-16 0001157523-07-009850 — 2.02, 9.01
- 2007-07-17 0001157523-07-006912 — 2.02, 9.01
- 2007-04-17 0001157523-07-003630 — 2.02, 9.01
- 2007-04-03 0001179022-07-000068 — 5.02
- 2007-03-28 0001179022-07-000064 — 5.02
- 2007-02-23 0001193125-07-038337 — 5.02
- 2007-02-23 0001193125-07-038335 — 5.02
- 2007-01-30 0001193125-07-015912 — 5.02, 9.01
- 2007-01-26 0001193125-07-014234 — 5.02
- 2007-01-23 0001157523-07-000494 — 2.02, 9.01 — amendment of 0001157523-07-000481
- 2007-01-23 0001157523-07-000481 — 2.02, 9.01
- 2006-10-17 0001157523-06-009945 — 2.02, 9.01
- 2006-07-18 0001157523-06-006929 — 2.02, 9.01
- 2006-06-08 0001193125-06-126486 — 1.01, 9.01
- 2006-05-10 0001193125-06-107316 — 1.01, 9.01
- 2006-04-18 0001157523-06-003699 — 2.02, 9.01
- 2006-02-03 0001179022-06-000014 — 1.01
- 2006-01-27 0001157523-06-000754 — 5.02, 9.01
- 2006-01-24 0001157523-06-000551 — 2.02, 9.01
- 2005-10-18 0001157523-05-008826 — 2.02, 9.01
- 2005-07-19 0001193125-05-143958 — 1.01, 5.02, 9.01
- 2005-07-19 0001193125-05-143957 — 2.02, 9.01
- 2005-05-20 0001193125-05-112019 — 1.01, 9.01
- 2005-04-19 0001157523-05-003418 — 2.02, 9.01
- 2005-01-25 0001193125-05-010721 — 2.02, 9.01
- 2004-10-12 0001193125-04-169652 — 2.02, 9.01
- 2004-07-13 0001193125-04-116820 — 12, 7
- 2004-04-14 0001193125-04-061547 — 12, 7
- 2004-01-21 0001193125-04-006366 — 12, 7
- 2003-10-14 0001193125-03-061018 — 12, 5, 7
- 2003-07-15 0001193125-03-019292 — 7, 9
- 2003-04-15 0000931763-03-000968 — 7, 9
- 1996-09-12 0000931763-96-000667 — 5, 7

## late-filing notifications on or before 2019-05-07

- none on or before 2019-05-07

## item 2.02 — earnings release, exhibit 99.1

[0001564590-19-011897:8k_2_02:1]
EX-99.1
2
adtn-ex991_7.htm
EX-99.1

[0001564590-19-011897:8k_2_02:2]
adtn-ex991_7.htm

[0001564590-19-011897:8k_2_02:3]
EXHIBIT 99.1

[0001564590-19-011897:8k_2_02:4]
ADTRAN, Inc. Reports Earnings for the First Quarter 2019 and Declares Quarterly Cash Dividend

[0001564590-19-011897:8k_2_02:5]
HUNTSVILLE, Ala. -- (BUSINESS WIRE) – April 17, 2019 -- ADTRAN, Inc. (NASDAQ:ADTN) reported results for the first quarter 2019. For the quarter, sales were $143.8 million compared to $120.8 million for the first quarter of 2018. Net income was $0.8 million compared to a net loss of $10.8 million for the first quarter of 2018. Earnings per share, assuming dilution, were $0.02 compared to a loss per share of $0.22 for the first quarter of 2018. Non-GAAP net income was $4.9 million compared to a net loss of $15.8 million for the first quarter of 2018.  Non-GAAP earnings per share, assuming dilution, were $0.10 compared to a loss per share of $0.33 for the first quarter of 2018.  Non-GAAP earnings per share exclude stock-based compensation expense, acquisition related amortizations and other expenses, restructuring expenses, gain on bargain purchase of a business, and amortization of pension actuarial losses.   The reconciliation between GAAP net income (loss) and earnings (loss) per share to non-GAAP net income (loss) and non-GAAP earnings (loss) per share is in the table provided.

[0001564590-19-011897:8k_2_02:6]
ADTRAN Chairman and Chief Executive Officer Tom Stanton stated, “We are pleased with our progress in the first quarter of 2019. Our revenue was diverse and well balanced with material contributions across the LATAM, EMEA, North America, and Pacific Rim regions. Furthermore, our broad portfolio of next-generation solutions continues to gain market traction with a growing number of customers in an expanding range of market segments. This progress underscores the company’s global strategy of diversification across geographies and markets.”

[0001564590-19-011897:8k_2_02:7]
The Company also announced that its Board of Directors declared a cash dividend for the first quarter of 2019. The quarterly cash dividend is $0.09 per common share to be paid to holders of record at the close of business on May 2, 2019. The ex-dividend date is May 1, 2019, and the payment date is May 16, 2019.

[0001564590-19-011897:8k_2_02:8]
The Company confirmed that it will hold a conference call to discuss its first quarter results Thursday, April 18, 2019, at 9:30 a.m. Central Time. ADTRAN will webcast this conference call. To listen, simply visit the Investor Relations site at www.investors.adtran.com approximately 10 minutes prior to the start of the call and click on the conference call link provided.

[0001564590-19-011897:8k_2_02:9]
An online replay of the conference call, as well as the text of the Company's earnings release, will be available on the Investor Relations site approximately 24 hours following the call and will remain available for at least 12 months. For more information, visit www.investors.adtran.com or via email at investor.relations@adtran.com.

[0001564590-19-011897:8k_2_02:10]
At ADTRAN, we believe amazing things happen when people connect. From the cloud edge to the subscriber edge, we help communications service providers around the world manage and scale services that connect people, places and things to advance human progress. Whether rural or urban, domestic or international, telco or cable, enterprise or residential—ADTRAN solutions optimize existing technology infrastructures and create new, multi-gigabit platforms that leverage cloud economics, data analytics, machine learning and open ecosystems—the future of global networking. Find more at ADTRAN, LinkedIn and Twitter.

[0001564590-19-011897:8k_2_02:11]
This press release contains forward-looking statements which reflect management’s best judgment based on factors currently known. However, these statements involve risks and uncertainties, including the successful development and market acceptance of new products, the degree of competition in the market for such products, the product and channel mix, component costs, manufacturing efficiencies, and other risks detailed in our annual report on Form 10-K for the year ended December 31, 2018. These risks and uncertainties could cause actual results to differ materially from those in the forward-looking statements included in this press release.

[0001564590-19-011897:8k_2_02:12]
To provide additional transparency, we have disclosed non-GAAP operating income (loss) which has been reconciled to operating income (loss) and non-GAAP net income (loss) and non-GAAP adjusted earnings (loss) per share - basic and diluted which have been reconciled to net income (loss) and earnings (loss) per share - basic and diluted as reported based on Generally Accepted Accounting Principles in the United States (U.S. GAAP). These measures exclude certain items which management believes are not reflective of the ongoing operating performance of the business. We believe this information is useful in providing period-to-period comparisons of the results of our ongoing operations. Additionally, these measures are used by management in our ongoing planning and annual budgeting processes. The presentation of non-GAAP operating income (loss), non-GAAP net income (loss) and non-GAAP earnings (loss) per share- basic and diluted, when combined with the U.S. GAAP presentation of operating income (loss), net income (loss), and net income (loss) per share is beneficial to the overall understanding of ongoing operating performance of the company.

[0001564590-19-011897:8k_2_02:13]
These measures are not in accordance with, or an alternative for, U.S. GAAP and therefore should not be considered in isolation or as a substitution for analysis of our results as reported under U.S. GAAP. Our calculation of non-GAAP operating income (loss), non-GAAP net income (loss) and non-GAAP earnings (loss) per share - basic and diluted may not be comparable to similar measures calculated by other companies.

[0001564590-19-011897:8k_2_02:14]
Condensed Consolidated Balance Sheet

[0001564590-19-011897:8k_2_02:15]
(Unaudited)

[0001564590-19-011897:8k_2_02:16]
(In thousands)

[0001564590-19-011897:8k_2_02:17]
|  | March 31, |  |  | December 31, |  |
|  | 2019 |  |  | 2018 |  |
| Assets |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 109,119 |  |  | $ | 105,504 |  |
| Short-term investments |  | 31,290 |  |  |  | 3,246 |  |
| Accounts receivable, net |  | 99,032 |  |  |  | 99,385 |  |
| Other receivables |  | 34,583 |  |  |  | 36,699 |  |
| Inventory, net |  | 93,609 |  |  |  | 99,848 |  |
| Prepaid expenses and other current assets |  | 9,683 |  |  |  | 10,744 |  |
| Total Current Assets |  | 377,316 |  |  |  | 355,426 |  |
| Property, plant and equipment, net |  | 79,505 |  |  |  | 80,635 |  |
| Deferred tax assets, net |  | 36,891 |  |  |  | 37,187 |  |
| Goodwill |  | 6,982 |  |  |  | 7,106 |  |
| Intangibles, net |  | 31,817 |  |  |  | 33,183 |  |
| Other assets |  | 14,885 |  |  |  | 5,668 |  |
| Long-term investments |  | 85,227 |  |  |  | 108,822 |  |
| Total Assets | $ | 632,623 |  |  | $ | 628,027 |  |
| Liabilities and Stockholders' Equity |  |  |  |  |  |  |  |
| Accounts payable | $ | 60,116 |  |  | $ | 60,054 |  |
| Bonds payable |  | 25,600 |  |  |  | 1,000 |  |
| Unearned revenue |  | 15,230 |  |  |  | 17,940 |  |
| Accrued expenses |  | 14,039 |  |  |  | 11,746 |  |
| Accrued wages and benefits |  | 15,105 |  |  |  | 14,752 |  |
| Income tax payable, net |  | 11,785 |  |  |  | 12,518 |  |
| Total Current Liabilities |  | 141,875 |  |  |  | 118,010 |  |
| Non-current unearned revenue |  | 4,514 |  |  |  | 5,296 |  |
| Other non-current liabilities |  | 42,687 |  |  |  | 33,842 |  |
| Bonds payable |  | — |  |  |  | 24,600 |  |
| Total Liabilities |  | 189,076 |  |  |  | 181,748 |  |
| Stockholders' Equity |  | 443,547 |  |  |  | 446,279 |  |
| Total Liabilities and Stockholders' Equity | $ | 632,623 |  |  | $ | 628,027 |  |

[0001564590-19-011897:8k_2_02:18]
Consolidated Statements of Income

[0001564590-19-011897:8k_2_02:19]
(Unaudited)

[0001564590-19-011897:8k_2_02:20]
(In thousands, except per share data)

[0001564590-19-011897:8k_2_02:21]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
|  |  | 2019 |  |  | 2018 |  |
| Sales |  |  |  |  |  |  |  |  |
| Products |  | $ | 125,822 |  |  | $ | 105,253 |  |
| Services |  |  | 17,969 |  |  |  | 15,553 |  |
| Total Sales |  |  | 143,791 |  |  |  | 120,806 |  |
| Cost of Sales |  |  |  |  |  |  |  |  |
| Products |  |  | 70,734 |  |  |  | 68,612 |  |
| Services |  |  | 12,445 |  |  |  | 12,461 |  |
| Total Cost of Sales |  |  | 83,179 |  |  |  | 81,073 |  |
| Gross Profit |  |  | 60,612 |  |  |  | 39,733 |  |
| Selling, general and administrative expenses |  |  | 35,132 |  |  |  | 33,531 |  |
| Research and development expenses |  |  | 31,647 |  |  |  | 32,849 |  |
| Operating Loss |  |  | (6,167 | ) |  |  | (26,647 | ) |
| Interest and dividend income |  |  | 591 |  |  |  | 866 |  |
| Interest expense |  |  | (127 | ) |  |  | (132 | ) |
| Net investment gain (loss) |  |  | 5,926 |  |  |  | (97 | ) |
| Other income (expense), net |  |  | 855 |  |  |  | (57 | ) |
| Gain on bargain purchase of a business |  |  | — |  |  |  | 11,322 |  |
| Income (Loss) Before Provision for Income Taxes |  |  | 1,078 |  |  |  | (14,745 | ) |
| (Provision) benefit for income taxes |  |  | (308 | ) |  |  | 3,931 |  |
| Net Income (Loss) |  | $ | 770 |  |  | $ | (10,814 | ) |
| Weighted average shares outstanding – basic |  |  | 47,782 |  |  |  | 48,232 |  |
| Weighted average shares outstanding – diluted(1) |  |  | 47,853 |  |  |  | 48,292 |  |
| Earnings (loss) per common share – basic |  | $ | 0.02 |  |  | $ | (0.22 | ) |
| Earnings (loss) per common share – diluted(1) |  | $ | 0.02 |  |  | $ | (0.22 | ) |

[0001564590-19-011897:8k_2_02:22]
(1) Assumes exercise of dilutive stock options calculated under the treasury stock method.

[0001564590-19-011897:8k_2_02:23]
Consolidated Statements of Comprehensive Income

[0001564590-19-011897:8k_2_02:24]
(Unaudited)

[0001564590-19-011897:8k_2_02:25]
(In thousands)

[0001564590-19-011897:8k_2_02:26]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
|  |  | 2019 |  |  | 2018 |  |
| Net Income (Loss) |  | $ | 770 |  |  | $ | (10,814 | ) |
| Other Comprehensive Loss, net of tax |  |  |  |  |  |  |  |  |
| Net unrealized gains (losses) on available-for-sale securities |  |  | 185 |  |  |  | (3,412 | ) |
| Defined benefit plan adjustments |  |  | 121 |  |  |  | 62 |  |
| Foreign currency translation |  |  | (1,160 | ) |  |  | 842 |  |
| Other Comprehensive Loss, net of tax |  |  | (854 | ) |  |  | (2,508 | ) |
| Comprehensive Loss, net of tax |  | $ | (84 | ) |  | $ | (13,322 | ) |

[0001564590-19-011897:8k_2_02:27]
Consolidated Statements of Cash Flows

[0001564590-19-011897:8k_2_02:28]
(Unaudited)

[0001564590-19-011897:8k_2_02:29]
(In thousands)

[0001564590-19-011897:8k_2_02:30]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
|  |  | 2019 |  |  | 2018 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income (loss) |  | $ | 770 |  |  | $ | (10,814 | ) |
| Adjustments to reconcile net income (loss) to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 4,496 |  |  |  | 3,614 |  |
| Amortization of net premium on available-for-sale investments |  |  | 6 |  |  |  | 42 |  |
| Net (gain) loss on long-term investments |  |  | (5,926 | ) |  |  | 97 |  |
| Net (gain) loss on disposal of property, plant and equipment |  |  | (6 | ) |  |  | 67 |  |
| Gain on bargain purchase of a business |  |  | — |  |  |  | (11,322 | ) |
| Stock-based compensation expense |  |  | 1,859 |  |  |  | 1,819 |  |
| Deferred income taxes |  |  | 235 |  |  |  | (1,877 | ) |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  |  | 170 |  |  |  | 63,904 |  |
| Other receivables |  |  | 1,185 |  |  |  | (6,598 | ) |
| Inventory |  |  | 5,974 |  |  |  | 3,368 |  |
| Prepaid expenses and other assets |  |  | (566 | ) |  |  | 10,583 |  |
| Accounts payable |  |  | 166 |  |  |  | (10,233 | ) |
| Accrued expenses and other liabilities |  |  | (2,355 | ) |  |  | 826 |  |
| Income tax payable |  |  | (487 | ) |  |  | 2,753 |  |
| Net cash provided by operating activities |  |  | 5,521 |  |  |  | 46,229 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (1,872 | ) |  |  | (1,950 | ) |
| Proceeds from sales and maturities of available-for-sale investments |  |  | 17,039 |  |  |  | 49,074 |  |
| Purchases of available-for-sale investments |  |  | (11,127 | ) |  |  | (75,960 | ) |
| Acquisition of business |  |  | — |  |  |  | (7,806 | ) |
| Net cash provided by (used in) investing activities |  |  | 4,040 |  |  |  | (36,642 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Proceeds from stock option exercises |  |  | — |  |  |  | 369 |  |
| Purchases of treasury stock |  |  | (184 | ) |  |  | (10,171 | ) |
| Dividend payments |  |  | (4,301 | ) |  |  | (4,367 | ) |
| Net cash used in financing activities |  |  | (4,485 | ) |  |  | (14,169 | ) |
| Net increase (decrease) in cash and cash equivalents |  |  | 5,076 |  |  |  | (4,582 | ) |
| Effect of exchange rate changes |  |  | (1,461 | ) |  |  | 772 |  |
| Cash and cash equivalents, beginning of period |  |  | 105,504 |  |  |  | 86,433 |  |
| Cash and cash equivalents, end of period |  | $ | 109,119 |  |  | $ | 82,623 |  |
| Supplemental disclosure of non-cash investing activities: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment included in accounts payable |  | $ | 273 |  |  | $ | 95 |  |
| Right-of-use asset obtained in exchange for lease obligations |  | $ | 10,371 |  |  | $ | — |  |

[0001564590-19-011897:8k_2_02:31]
Supplemental Information

[0001564590-19-011897:8k_2_02:32]
Reconciliation of Operating Loss to Non-GAAP Operating Income (Loss)

[0001564590-19-011897:8k_2_02:33]
(Unaudited)

[0001564590-19-011897:8k_2_02:34]
|  |  | Three Months Ended March 31, |  |  |  |  |
|  |  | 2019 |  |  |  |  | 2018 |  |  |  |  |
| Operating Loss |  | $ | (6,167 | ) |  |  |  | $ | (26,647 | ) |  |  |  |
| Acquisition related expenses, amortizations and adjustments |  |  | 1,497 |  | (1) |  |  |  | 583 |  | (5) |  |  |
| Stock-based compensation expense |  |  | 1,859 |  | (2) |  |  |  | 1,819 |  | (6) |  |  |
| Restructuring expenses |  |  | 2,063 |  | (3) |  |  |  | 5,950 |  | (7) |  |  |
| Deferred compensation investment fluctuations |  |  | 2,124 |  | (4) |  |  |  | (386 | ) | (4) |  |  |
| Non-GAAP Operating Income (Loss) |  | $ | 1,376 |  |  |  |  | $ | (18,681 | ) |  |  |  |

[0001564590-19-011897:8k_2_02:35]
| (1) $0.5 million is included in total cost of sales, $0.5 million is included in selling, general and administrative expenses and $0.5 million is included in research and development expenses on the consolidated statements of income. |
| (2) $0.1 million is included in total cost of sales, $1.1 million is included in selling, general and administrative expenses and $0.7 million is included in research and development expenses on the consolidated statements of income. |
| (3) $0.6 million is included in total cost of sales, $0.8 million is included in selling, general and administrative expenses and $0.6 million is included in research and development expenses on the consolidated statements of income. |
| (4) Includes non-cash change in fair value of equity investments held in the ADTRAN, Inc. Deferred Compensation Program for Employees (as amended and restated as of June 1, 2010) per ASU 2016-01, all of which is included in selling, general and administrative expenses on the consolidated statements of income. |
| (5) $0.3 million is included in selling, general and administrative expenses and $0.3 million is included in research and development expenses on the consolidated statements of income. |
| (6) $0.1 million is included in total cost of sales, $1.0 million is included in selling, general and administrative expenses and $0.7 million is included in research and development expenses on the consolidated statements of income. |
| (7) $2.4 million is included in total cost of sales, $1.8 million is included in selling, general and administrative expenses and $1.8 million is included in research and development expenses on the consolidated statements of income. |

[0001564590-19-011897:8k_2_02:36]
Reconciliation of Net Income (Loss) and Earnings (Loss) per Share – Basic and Diluted to Non-GAAP

[0001564590-19-011897:8k_2_02:37]
Net Income (Loss) and Non-GAAP Earnings (Loss) per Share – Basic and Diluted

[0001564590-19-011897:8k_2_02:38]
(Unaudited)

[0001564590-19-011897:8k_2_02:39]
|  |  | Three Months Ended March 31, |  |  |  |  |
|  |  | 2019 |  |  |  |  | 2018 |  |  |  |  |
| Net Income (Loss) |  | $ | 770 |  |  |  |  | $ | (10,814 | ) |  |  |  |
| Restructuring expenses |  |  | 2,063 |  |  |  |  |  | 5,950 |  |  |  |  |
| Acquisition related expenses, amortizations and adjustments |  |  | 1,497 |  |  |  |  |  | 583 |  |  |  |  |
| Stock-based compensation expense |  |  | 1,859 |  |  |  |  |  | 1,819 |  |  |  |  |
| Pension expense |  |  | 203 |  |  | (1 | ) |  | 64 |  |  | (1 | ) |
| Gain on bargain purchase of a business |  |  | — |  |  |  |  |  | (11,322 | ) |  |  |  |
| Tax effect of adjustments to Net Income (Loss) |  |  | (1,524 | ) |  |  |  |  | (2,107 | ) |  |  |  |
| Non-GAAP Net Income (Loss) |  | $ | 4,868 |  |  |  |  | $ | (15,827 | ) |  |  |  |
| Weighted average shares outstanding – basic |  |  | 47,782 |  |  |  |  |  | 48,232 |  |  |  |  |
| Weighted average shares outstanding – diluted |  |  | 47,853 |  |  |  |  |  | 48,292 |  |  |  |  |
| Earnings (loss) per common share - basic |  | $ | 0.02 |  |  |  |  | $ | (0.22 | ) |  |  |  |
| Earnings (loss) per common share - diluted |  | $ | 0.02 |  |  |  |  | $ | (0.22 | ) |  |  |  |
| Non-GAAP earnings (loss) per common share - basic |  | $ | 0.10 |  |  |  |  | $ | (0.33 | ) |  |  |  |
| Non-GAAP earnings (loss) per common share - diluted |  | $ | 0.10 |  |  |  |  | $ | (0.33 | ) |  |  |  |
| (1) Includes amortization of actuarial losses related to the Company's pension plan for employees in certain foreign countries. |  |
