# ADTN MD&A — 0001564590-19-016264


## mdna

[0001564590-19-016264:mdna:1]
[same as prior period, unchanged from 0001564590-18-027351:mdna:1]

[0001564590-19-016264:mdna:2]
The following discussion should be read in conjunction with the Consolidated Financial Statements and the related notes that appear in Item 1 of this document.

[0001564590-19-016264:mdna:3]
[same as prior period, unchanged from 0001564590-18-027351:mdna:3]

[0001564590-19-016264:mdna:4]
ADTRAN is a leading global provider of networking and communications equipment, serving a diverse domestic and international customer base in 68 countries that includes Tier-1, 2 and 3 service providers, Cable/MSOs and distributed enterprises. Our innovative solutions and services enable voice, data, video and internet communications across a variety of network infrastructures and are currently in use by millions worldwide. We support our customers through our direct global sales organization and our distribution networks. Our success depends upon our ability to increase unit volume and market share through the introduction of new products and succeeding generations of products having lower selling prices and increased functionality as compared to both the prior generation of a product and to the products of competitors. In order to service our customers and build revenue, we are constantly conducting research and development (R&D) of new products addressing customer needs and testing those products for the particular specifications of the particular customers. In addition to our corporate headquarters in Huntsville, Alabama, we have R&D facilities in strategic global locations.

[0001564590-19-016264:mdna:5]
We are focused on being a top global supplier of access infrastructure and related value-added solutions from the cloud edge to the subscriber edge. We offer a broad portfolio of flexible software and hardware network solutions and services that enable service providers to meet today’s service demands, while enabling them to transition to the fully-converged, scalable, highly-automated, cloud-controlled voice, data, internet and video network of the future.

[0001564590-19-016264:mdna:6]
An important part of our strategy is to reduce the cost of each succeeding product generation and then lower the product’s selling price based on the cost savings achieved in order to gain market share and/or improve gross margins. As a part of this strategy, we seek to be a high-quality, and in most instances the low-cost provider of products in our markets. Our success to date is attributable in large measure to our ability to design our products initially with a view to their subsequent redesign, allowing both increased functionality and reduced manufacturing costs in each succeeding product generation. This strategy enables us to sell succeeding generations of products to existing customers, while increasing our market share by selling these enhanced products to new customers.

[0001564590-19-016264:mdna:7]
Our business is global. We supply different sets of products to different customers in different regions around the world. Our financial results in any period reflect the activities of our various customers in their respective regions at any given time. The lead times to revenue for new products vary.

[0001564590-19-016264:mdna:8]
The Company made two acquisitions in 2018, strengthening its position in both the Cable/MSO and connected home markets. In the first quarter of 2018, we acquired the market-leading EPON business and certain assets for North America from Sumitomo Electric Industries Ltd. These solutions, combined with our organic fiber access product portfolio and our distributed access expertise, present new opportunities in the Cable/MSO market. Also, in the fourth quarter of 2018, we acquired U.S.-based SmartRG, an industry-leading provider of carrier-class, connected–home software platforms and cloud services for broadband service providers. With this acquisition, ADTRAN now offers a complete cloud-to-consumer portfolio of virtualized management, data analytics, Wi-Fi-enabled residential gateways and software platforms. For more information, see Note 2 of the Notes to Consolidated Financial Statements included in Item 1 of this report.

[0001564590-19-016264:mdna:9]
We review our financial performance, specifically revenue and gross profit, based on two reportable segments – Network Solutions and Services & Support. Network Solutions software and hardware products provide solutions supporting fiber-, copper- and coaxial-based infrastructures and a growing number of wireless solutions, lowering the overall cost to deploy advanced services across a wide range of applications for Carrier, Cable/MSO networks and business networks, as well as for prior-generation products. Our Services & Support enables our customers to accelerate time to market, reduce costs and improve customer satisfaction through a complete portfolio of services, including maintenance, turnkey network implementation, solutions integration, and managed services. ADTRAN’s comprehensive network implementation services include engineering design and documentation (pre-construction), construction and installation (construction), and test, turn-up and provisioning (post-construction). Additionally, we partner with customers to tailor a program to each specific service-delivery need.

[0001564590-19-016264:mdna:10]
We report revenue for the following three categories – Access & Aggregation, Subscriber Solutions & Experience (formerly Customer Devices) and Traditional & Other Products.

[0001564590-19-016264:mdna:11]
Access & Aggregation solutions are used by service providers to connect their network infrastructure to their subscribers. This category includes software- and hardware-based products and services that aggregate and/or originate access technologies. The portfolio of ADTRAN solutions within this category includes a wide array of modular or fixed physical form factors designed to deliver the best technology and economic fit based on the target subscriber density and environmental conditions.

[0001564590-19-016264:mdna:12]
Subscriber Solutions & Experience (formerly Customer Devices) includes open-source connected home platforms, cloud services and any of our solutions and services that deliver residential and/or enterprise subscribers an immersive and interactive broadband experience from the service provider’s access network. These products, software and services include SmartRG solutions and applications, NetVanta Enterprise IP business gateways, access routers, Ethernet switches, ProCloud service offerings, residential and enterprise operating systems (such as SmartOS and AOS), Bluesocket Wi-Fi portfolio, service provider and Cable/MSO Optical Network Terminals (ONTs), as well as related software applications and services. In alignment with our increased focus on enhancing customer experience for both business and consumer broadband customers as well as the addition of SmartRG during 2018, Customer Devices is now known as Subscriber Solutions & Experience, as this more accurately represents this revenue category and our vision moving forward.

[0001564590-19-016264:mdna:13]
Traditional & Other Products generally includes a mix of prior generation technologies’ products and services, as well as other products and services that do not fit within the Access & Aggregation or Subscriber Solutions & Experience categories.

[0001564590-19-016264:mdna:14]
See Note 15 of Notes to Consolidated Financial Statements in Item 1 of this Form 10-Q for further information regarding these product categories.

[0001564590-19-016264:mdna:15]
Our operating results have fluctuated on a quarterly basis in the past, and may vary significantly in future periods, due to a number of factors, including customer order activity and backlog. Backlog levels vary because of seasonal trends, the timing of customer projects and other factors that affect customer order lead times. Many of our customers require prompt delivery of products. This requires us to maintain sufficient inventory levels to satisfy anticipated customer demand. If near-term demand for our products declines, or if potential sales in any quarter do not occur as anticipated, our financial results could be adversely affected. Operating expenses are relatively fixed in the short term; therefore, a shortfall in quarterly revenue could significantly impact our financial results in a given quarter.

[0001564590-19-016264:mdna:16]
[same as prior period, unchanged from 0001564590-18-027351:mdna:17]

[0001564590-19-016264:mdna:17]
Accordingly, our historical financial performance is not necessarily a meaningful indicator of future results, and in general, management expects that our financial results may vary from period to period. Factors that could materially affect our business, financial condition or operating results are included in Item 1A of Part I in our most recent Annual Report on Form 10-K for the year ended December 31, 2018, filed on February 28, 2019, with the SEC and in Part II Item 1A herein.

[0001564590-19-016264:mdna:18]
[same as prior period, unchanged from 0001564590-18-027351:mdna:19]

[0001564590-19-016264:mdna:19]
Our critical accounting policies and estimates have not changed significantly from those detailed in our most recent Annual Report on Form 10-K for the year ended December 31, 2018, filed on February 28, 2019, with the SEC.

[0001564590-19-016264:mdna:20]
[same as prior period, unchanged from 0001564590-18-027351:mdna:21]

[0001564590-19-016264:mdna:21]
[same as prior period, unchanged from 0001564590-18-027351:mdna:22]

[0001564590-19-016264:mdna:22]
RESULTS OF OPERATIONS – THREE MONTHS ENDED MARCH 31, 2019 COMPARED TO THREE MONTHS ENDED MARCH 31, 2018

[0001564590-19-016264:mdna:23]
The following table presents selected financial information derived from our Consolidated Statements of Income expressed as a percentage of sales for the quarters indicated. Amounts may not foot due to rounding.

[0001564590-19-016264:mdna:24]
|  |  | Three Months Ended |  |  |
|  |  | March 31, |  |  |
|  |  | 2019 |  |  | 2018 |  |  |
| Sales |  |  |  |  |  |  |  |  |  |
| Products |  |  | 87.5 |  | % |  | 87.1 |  | % |
| Services |  |  | 12.5 |  |  |  | 12.9 |  |  |
| Total Sales |  |  | 100.0 |  |  |  | 100.0 |  |  |
| Cost of Sales |  |  |  |  |  |  |  |  |  |
| Products |  |  | 49.2 |  |  |  | 56.8 |  |  |
| Services |  |  | 8.7 |  |  |  | 10.3 |  |  |
| Total Cost of Sales |  |  | 57.8 |  |  |  | 67.1 |  |  |
| Gross Profit |  |  | 42.2 |  |  |  | 32.9 |  |  |
| Selling, general and administrative expenses |  |  | 24.4 |  |  |  | 27.8 |  |  |
| Research and development expenses |  |  | 22.0 |  |  |  | 27.2 |  |  |
| Operating Income |  |  | (4.3 | ) |  |  | (22.1 | ) |  |
| Interest and dividend income |  |  | 0.4 |  |  |  | 0.7 |  |  |
| Interest expense |  |  | (0.1 | ) |  |  | (0.1 | ) |  |
| Net investment gain (loss) |  |  | 4.1 |  |  |  | (0.1 | ) |  |
| Other income (expense), net |  |  | 0.6 |  |  |  | — |  |  |
| Gain on bargain purchase of a business, net |  |  | — |  |  |  | 9.4 |  |  |
| Income (Loss) Before Provision for Income Taxes |  |  | 0.7 |  |  |  | (12.2 | ) |  |
| (Provision) benefit for income taxes |  |  | (0.2 | ) |  |  | 3.3 |  |  |
| Net Income (Loss) |  |  | 0.5 |  | % |  | (9.0 | ) | % |

[0001564590-19-016264:mdna:25]
[same as prior period, unchanged from 0001564590-18-027351:mdna:24]

[0001564590-19-016264:mdna:26]
Our sales increased 19.0% from $120.8 million in the three months ended March 31, 2018 to $143.8 million in the three months ended March 31, 2019. The increase in sales for the three months ended March 31, 2019 is primarily attributable to an $18.1 million increase in Access & Aggregation products, a $6.7 million increase in sales of our Subscriber Solutions & Experience products, partially offset by a $1.8 million decrease in sales of our Traditional & Other products.

[0001564590-19-016264:mdna:27]
Network Solutions sales increased 19.5% from $105.3 million in the three months ended March 31, 2018 to $125.8 million in the three months ended March 31, 2019. The increase in sales for the three months ended March 31, 2019 is primarily attributable to an increase in sales of Access & Aggregation products and Subscriber Solutions & Experience products, partially offset by a decrease in sales of our Traditional & Other products. The increase in sales of our Access & Aggregation products for the three months ended March 31, 2019 is primarily attributable to increased fiber to the premises (FTTN) products, Gfast distribution point units (DPUs) and fiber access and aggregation. The increase in sales of our Subscriber Solutions & Experience is primarily attributable to increased fiber CPE and network termination. While we expect that revenue from Traditional & Other Products will continue to decline over time, this revenue may fluctuate and continue for years because of the time required for our customers to transition to newer technologies.

[0001564590-19-016264:mdna:28]
Services & Support sales increased 15.5% from $15.6 million in the three months ended March 31, 2018 to $18.0 million in the three months ended March 31, 2019. The increase in sales for the three months ended March 31, 2019 is primarily attributable to an increase in network installation services for Access & Aggregation products.

[0001564590-19-016264:mdna:29]
31

[0001564590-19-016264:mdna:30]
International sales, which are included in the Network Solutions and Services & Support amounts discussed above, increased 21.4% from $58.7 million in the three months ended March 31, 2018 to $71.3 million in the three months ended March 31, 2019. International sales, as a percentage of total sales, increased from 48.6% for the three months ended March 31, 2018 to 49.6% for the three months ended March 31, 2019. The increase in sales for the three months ended March 31, 2019 is primarily attributable to an increase in sales in LATAM and APAC regions. The increase in sales in LATAM for the three months ended March 31, 2019 is primarily attributable to a network expansion program of a large Tier-1 customer. The increase in sales in APAC for the three months ended March 31, 2019 is primarily attributable to a network expansion program in Australia.

[0001564590-19-016264:mdna:31]
Our international revenue is largely focused on broadband infrastructure and is effected by the decisions of our customers as to timing for installation of new technologies, expansion of their networks and/or network upgrades. Our international customers must make these decisions in the regulatory and political environment in which they operate – both nationally and in some instances, regionally – whether of a multi-country region or a more local region within a country. For example, the European Commission launched a Gigabit Society initiative, and before that, the Digital Agenda, which has provided a favorable market environment for the deployment of ultra-broadband and Gigabit network solutions. Although the overall environment and market demand for broadband service deployment in the European Union have improved, some new broadband technologies are still being reviewed for regulatory and standards compliance, which may affect the timing of those technologies. The competitive landscape in certain international markets is also effected by the increased presence of Asian manufacturers that seek to compete aggressively on price. Our revenue and operating income in our international markets can be negatively impacted by a strengthening U.S. dollar. Consequently, while we expect the global trend towards deployment of more robust broadband speeds and access to continue creating additional market opportunities for us, the factors described above may result in pressure on revenue and operating income.

[0001564590-19-016264:mdna:32]
[same as prior period, unchanged from 0001564590-18-027351:mdna:31]

[0001564590-19-016264:mdna:33]
As a percentage of sales, cost of sales decreased from 67.1% in the three months ended March 31, 2018 to 57.8% in the three months ended March 31, 2019. The decrease in cost of sales as a percentage of sales for the three months ended March 31, 2019 is primarily attributable to a regional revenue shift, customer and product mix, services and support mix and a decrease in labor expense as a result of a restructuring program in the first quarter of 2018.

[0001564590-19-016264:mdna:34]
Network Solutions cost of sales, as a percent of that segment’s sales, decreased from 65.2% in the three months ended March 31, 2018 to 56.2% in the three months ended March 31, 2019. The decrease in cost of sales as a percentage of sales for the three months ended March 31, 2019 is primarily attributable to a regional revenue shift, customer and product mix and a decrease in labor expense due to a restructuring program in the first quarter of 2018.

[0001564590-19-016264:mdna:35]
An important part of our strategy is to reduce the cost of each succeeding product generation and then lower the product’s selling price based on the cost savings achieved in order to gain market share and/or improve gross margins. This may cause variations in our gross profit percentage due to timing differences between the recognition of cost reductions and the lowering of product selling prices.

[0001564590-19-016264:mdna:36]
Services & Support cost of sales, as a percent of that segment’s sales, decreased from 80.1% in the three months ended March 31, 2018 to 69.3% in the three months ended March 31, 2019. The decrease in cost of sales as a percentage of sales for the three months ended March 31, 2019 is primarily attributable to lower fixed personnel costs due to a restructuring program in the first quarter of 2081, customer mix and services and support mix.

[0001564590-19-016264:mdna:37]
Our Services & Support revenue is comprised of network planning and implementation, maintenance, support and cloud-based management services, with network planning and implementation being the largest and fastest growing component in the long-term. Compared to our other services, such as maintenance, support and cloud-based management services, our network planning and implementation services typically utilize a higher percentage of internal and subcontracted engineers, professionals and contractors to perform the work for customers. The additional costs incurred to perform these infrastructure and labor-intensive services inherently result in lower average gross margins as compared to maintenance and support services.

[0001564590-19-016264:mdna:38]
As our network planning and implementation revenue grew and is now the largest component of our Services & Support business, our Services & Support segment gross margins decreased versus those reported when maintenance and support comprised the majority of the business. Further, because the growth in our network planning and implementation services has resulted in our Services & Support revenue comprising a larger percentage of our overall revenue, and because our Services & Support gross margins are below those of the Network Solutions segment, our overall corporate gross margins have declined as that business has continued to grow. Within the Services & Support segment, we do expect variability in gross margins from quarter-to-quarter based on the mix of the services recognized.

[0001564590-19-016264:mdna:39]
[same as prior period, unchanged from 0001564590-18-027351:mdna:38]

[0001564590-19-016264:mdna:40]
Selling, general and administrative expenses increased 4.8% from $33.5 million in the three months ended March 31, 2018 to $35.1 million in the three months ended March 31, 2019. The increase in selling, general and administrative expenses for the three months ended March 31, 2019 is primarily attributable to increases in deferred compensation expense and incremental expenses as a result of the SmartRG acquisition.

[0001564590-19-016264:mdna:41]
As a percentage of sales, selling, general and administrative expenses decreased from 27.8% in the three months ended March 31, 2018 to 24.4% in the three months ended March 31, 2019. Selling, general and administrative expenses as a percentage of sales may fluctuate whenever there is a significant fluctuation in revenue for the periods being compared.

[0001564590-19-016264:mdna:42]
[same as prior period, unchanged from 0001564590-18-027351:mdna:41]

[0001564590-19-016264:mdna:43]
Research and development expenses decreased 3.7% from $32.8 million in the three months ended March 31, 2018 to $31.6 million in the three months ended March 31, 2019. The decrease in research and development expenses for the three months ended March 31, 2019 is primarily attributable to decreases in restructuring and labor expenses, partially offset by an increase in incremental expenses as a result of the SmartRG and Sumitomo acquisitions.

[0001564590-19-016264:mdna:44]
As a percentage of sales, research and development expenses decreased from 27.2% in the three months ended March 31, 2018 to 22.0% in the three months ended March 31, 2019. Research and development expenses as a percentage of sales will fluctuate whenever there are incremental product development activities or significant fluctuations in revenue for the periods being compared.

[0001564590-19-016264:mdna:45]
We expect to continue to incur research and development expenses in connection with our new and existing products and our continued expansion into international markets. We continually evaluate new product opportunities and engage in intensive research and product development efforts, which provides for new product development, enhancement of existing products and product cost reductions. We may incur significant research and development expenses prior to the receipt of revenue from a major new product group.

[0001564590-19-016264:mdna:46]
[same as prior period, unchanged from 0001564590-18-027351:mdna:45]

[0001564590-19-016264:mdna:47]
Interest and dividend income decreased 31.8% from $0.9 million in the three months ended March 31, 2018 to $0.6 million in the three months ended March 31, 2019. The decrease in interest and dividend income for the three months ended March 31, 2019 is primarily attributable to fluctuations in investment balances.

[0001564590-19-016264:mdna:48]
[same as prior period, unchanged from 0001564590-18-027351:mdna:47]

[0001564590-19-016264:mdna:49]
Interest expense, which is primarily related to our taxable revenue bond, remained constant at $0.1 million for both the three months ended March 31, 2018 and 2019, as we had no substantial change in our fixed-rate borrowing. See “Liquidity and Capital Resources” below for additional information on our revenue bond.

[0001564590-19-016264:mdna:50]
NET INVESTMENT GAIN (LOSS)

[0001564590-19-016264:mdna:51]
Net investment gain (loss) increased from a loss of $(0.1) million in the three months ended March 31, 2018 to a gain of $5.9 million in the three months ended March 31, 2019. The fluctuation in our net investment gain (loss) is primarily attributable to changes in fair value on equity securities recognized during the period. See Note 7 of Notes to Consolidated Financial Statements, included in Item 1 of this report, and “Investing Activities” in “Liquidity and Capital Resources” for additional information.

[0001564590-19-016264:mdna:52]
[same as prior period, unchanged from 0001564590-18-027351:mdna:51]

[0001564590-19-016264:mdna:53]
Other income (expense), net, is comprised primarily of miscellaneous income, gains and losses on foreign currency transactions and gains and losses on foreign exchange forward contracts. Other income (expense), net increased from $0.1 million of expense in the three months ended March 31, 2018 to $0.9 million of income in the three months ended March 31, 2019. The change in other income (expense), net for the three months ended March 31, 2019 is primarily attributable to the receipt of insurance proceeds from a life insurance policy.

[0001564590-19-016264:mdna:54]
GAIN ON BARGAIN PURCHASE OF A BUSINESS, NET

[0001564590-19-016264:mdna:55]
Gain on bargain purchase of a business was $11.3 million during the three months ended March 31, 2018 and is related to our acquisition of Sumitomo Electric Lightwave Corp.’s North American EPON business and entry into a technology license and supply agreement with Sumitomo Electric Industries, Ltd. in March 2018. No gain on bargain purchase of a business was recorded during the three months ended March 31, 2019. See Note 2 of Notes to Consolidated Financial Statements included in Item 1 of this report for additional information.

[0001564590-19-016264:mdna:56]
(PROVISION) BENEFIT FOR INCOME TAXES

[0001564590-19-016264:mdna:57]
Our effective tax rate increased from a benefit of 15.1%, excluding the tax effect of the bargain purchase gain, in the three months ended March 31, 2018 to an expense of 28.6% three months ended March 31, 2019. The increase in the effective tax rate between the two periods is primarily driven by the shift to profitability in the current quarter.

[0001564590-19-016264:mdna:58]
[same as prior period, unchanged from 0001564590-18-027351:mdna:57]

[0001564590-19-016264:mdna:59]
As a result of the above factors, net income increased $11.6 million from a net loss of $10.8 million in the three months ended March 31, 2018 to net income of $0.8 million in the three months ended March 31, 2019.

[0001564590-19-016264:mdna:60]
[same as prior period, unchanged from 0001564590-18-027351:mdna:59]

[0001564590-19-016264:mdna:61]
[same as prior period, unchanged from 0001564590-18-027351:mdna:60]

[0001564590-19-016264:mdna:62]
We intend to finance our operations with cash flow from operations. We have used, and expect to continue to use, the cash generated from operations for working capital, purchases of treasury stock, shareholder dividends, business acquisitions and other general corporate purposes, including (i) product development activities to enhance our existing products and develop new products and (ii) expansion of sales and marketing activities. We believe our cash and cash equivalents, investments and cash generated from operations to be adequate to meet our operating and capital needs for at least the next 12 months.

[0001564590-19-016264:mdna:63]
At March 31, 2019, cash on hand was $109.1 million and short-term investments were $31.3 million, which resulted in available short-term liquidity of $140.4 million, of which $70.2 million was held by our foreign subsidiaries. At December 31, 2018, cash on hand was $105.5 million and short-term investments were $3.2 million, which resulted in available short-term liquidity of $108.7 million, of which $87.1 million was held by our foreign subsidiaries. The increase in short-term liquidity from December 31, 2018 to March 31, 2019 is primarily attributable to the restricted certificate of deposit totaling $25.6 million being reclassified from a long-term investment to a short-term investment.

[0001564590-19-016264:mdna:64]
[same as prior period, unchanged from 0001564590-18-027351:mdna:63]

[0001564590-19-016264:mdna:65]
Our working capital, which consists of current assets less current liabilities, decreased 0.8% from $237.4 million as of December 31, 2018 to $235.4 million as of March 31, 2019, and our current ratio, defined as current assets divided by current liabilities, decreased from 3.01 as of December 31, 2018 to 2.66 as of March 31, 2019. The decreases in our working capital and current ratio are primarily attributable to the reclassification of our bond payable to current liabilities as it matures in January 2020 as well as a decrease in inventory. The quick ratio, defined as cash, cash equivalents, short-term investments, and net accounts receivable, divided by current liabilities, decreased from 1.76 as of December 31, 2018 to 1.69 as of March 31, 2019. The decrease in the quick ratio is primarily attributable to the reclassification of our bond payable to current liabilities as it matures in January 2020, partially offset by an increase in cash and cash equivalents and short-term investments, mainly related to the reclassification of our restricted certificate of deposit from a long-term investment to a short-term investment.

[0001564590-19-016264:mdna:66]
Net accounts receivable decreased 0.4% from $99.4 million at December 31, 2018 to $99.0 million at March 31, 2019. Our allowance for doubtful accounts was $0.1 million at December 31, 2018 and March 31, 2019. Quarterly accounts receivable day’s sales outstanding (DSO) decreased from 65 days as of December 31, 2018 to 62 days as of March 31, 2019. The decrease in net accounts receivable is due to the timing of international shipments and customer mix.

[0001564590-19-016264:mdna:67]
Other receivables decreased 5.8% from $36.7 million at December 31, 2018 to $34.6 million at March 31, 2019. The decrease in other receivables is primarily attributable to a decrease in contract assets, leased equipment receivables and income tax receivables partially offset by an increase in contract manufacturers’ receivables.

[0001564590-19-016264:mdna:68]
Quarterly inventory turnover increased from 3.29 turns as of December 31, 2018 to 3.44 turns at March 31, 2019. Inventory decreased 6.2% from $99.8 million at December 31, 2018 to $93.6 million at March 31, 2019. We expect inventory levels to fluctuate as we attempt to maintain sufficient inventory in response to services activity and seasonal cycles of our business, ensuring competitive lead times while managing the risk of inventory obsolescence that may occur due to rapidly changing technology and customer demand.

[0001564590-19-016264:mdna:69]
Accounts payable remained consistent at $60.1 million at December 31, 2018 and March 31, 2019. Accounts payable will fluctuate due to variations in the timing of the receipt of supplies, inventory and services and our subsequent payments for these purchases.

[0001564590-19-016264:mdna:70]
[same as prior period, unchanged from 0001564590-18-027351:mdna:69]

[0001564590-19-016264:mdna:71]
Capital expenditures totaled approximately $1.9 million and $2.0 million for the three months ended March 31, 2019 and 2018, respectively. These expenditures were primarily used to purchase computer hardware, software, manufacturing and test equipment and building improvements.

[0001564590-19-016264:mdna:72]
Our combined short-term and long-term investments increased $4.4 million from $112.1 million at December 31, 2018 to $116.5 million at March 31, 2019. This increase reflects the impact of net realized and unrealized gains and losses on our combined investments plus new investments, partially offset by cash used for share repurchases, shareholder dividends and property, plant and equipment purchases.

[0001564590-19-016264:mdna:73]
We typically invest all available cash not required for immediate use in operations primarily in securities that we believe bear minimal risk of loss. At March 31, 2019, these investments included corporate bonds of $16.0 million, municipal bonds of $0.9 million, asset-backed bonds of $7.2 million, mortgage/agency bonds of $4.5 million, U.S. government bonds of $4.2 million and foreign government bonds of $2.2 million. At December 31, 2018, these investments included corporate bonds of $20.7 million, municipal fixed-rate bonds of $1.3 million, asset-backed bonds of $5.2 million, mortgage/agency-backed bonds of $3.8 million, U.S. government bonds of $9.2 million and foreign government bonds of $0.6 million. As of March 31, 2019, our corporate bonds, municipal fixed-rate bonds, asset-backed bonds, mortgage/agency-backed bonds, U.S. government bonds and foreign government bonds were classified as available-for-sale and had a combined duration of 0.96 years with an average Standard & Poor’s credit rating of A+. Because our bond portfolio has a high-quality rating and contractual maturities of short duration, we are able to obtain prices for these bonds derived from observable market inputs, or for similar securities traded in an active market, on a daily basis.

[0001564590-19-016264:mdna:74]
Our long-term investments decreased 21.7% from $108.8 million at December 31, 2018 to $85.2 million at March 31, 2019. Long-term investments at December 31, 2018 included an investment in a certificate of deposit of $25.6 million, which serves as collateral for our revenue bond. This certificate of deposit is now included in short-term investments as of March 31, 2019, as this bond matures on January 1, 2020. See “Debt” below for additional information. We also have investments in various marketable equity securities classified as long-term investments with a fair market value of $30.9 million and $27.0 million, at March 31, 2019 and December 31, 2018, respectively. Long-term investments at March 31, 2019 and December 31, 2018 also included $20.4 million and $18.3 million, respectively, related to our deferred compensation plans.

[0001564590-19-016264:mdna:75]
Acquisition of businesses, net of cash acquired, totaled $7.8 million for the three months ended March 31, 2018. No businesses were acquired during the three months ended March 31, 2019. See Note 2 of Notes to Consolidated Financial Statements included in Item 1 of this report for additional information.

[0001564590-19-016264:mdna:76]
[same as prior period, unchanged from 0001564590-18-027351:mdna:75]

[0001564590-19-016264:mdna:77]
[same as prior period, unchanged from 0001564590-18-027351:mdna:76]

[0001564590-19-016264:mdna:78]
In July 2003, our Board of Directors elected to begin declaring quarterly dividends on our common stock considering the tax treatment of dividends and adequate levels of Company liquidity. During the three months ended March 31, 2019 and 2018, we paid dividends totaling $4.3 million and $4.4 million, respectively.

[0001564590-19-016264:mdna:79]
[same as prior period, unchanged from 0001564590-18-027351:mdna:78]

[0001564590-19-016264:mdna:80]
We have amounts outstanding under loans made pursuant to an Alabama State Industrial Development Authority revenue bond (the Bond) which totaled $25.6 million at March 31, 2019 and December 31, 2018. At March 31, 2019, the estimated fair value of the Bond was $25.5 million, based on a debt security with a comparable interest rate and maturity and a Standard & Poor’s credit rating of AAA. Restricted funds serving as a collateral deposit against the principal amount of the Bond in the amount of $25.6 million were included in short-term and long-term investments at March 31, 2019, and December 31, 2018, respectively. We have the right to set-off the balance of the Bond with the collateral deposit in order to reduce the balance of the indebtedness. The Bond matures on January 1, 2020, and bears interest at the rate of 2% per annum. In conjunction with this program, we are eligible to receive certain economic incentives from the state of Alabama that reduce the amount of payroll withholdings we are required to remit to the state for those employment positions that qualify under this program. We are required to make payments in the amounts necessary to pay the interest on the amounts currently outstanding. It is our intent to make annual principal payments in addition to the interest amounts that are due. The restricted funds held as collateral against the principal amount of the Bond will be used to pay the outstanding principal and interest upon the Bond’s maturity on January 1, 2020.

[0001564590-19-016264:mdna:81]
[same as prior period, unchanged from 0001564590-18-027351:mdna:80]

[0001564590-19-016264:mdna:82]
Since 1997, our Board of Directors has approved multiple share repurchase programs that have authorized open market repurchase transactions of our common stock, which are implemented through open market or private purchases from time to time as conditions warrant. During the three months ended March 31, 2019, we repurchased 13,000 shares of our common stock, for $0.2 million at an average price of $14.06 per share. We currently have authorization to repurchase an additional 2.5 million shares of our common stock under the current authorization of up to 5.0 million shares.

[0001564590-19-016264:mdna:83]
[same as prior period, unchanged from 0001564590-18-027351:mdna:82]

[0001564590-19-016264:mdna:84]
There were no stock options exercised during the three months ended March 31, 2019.

[0001564590-19-016264:mdna:85]
[same as prior period, unchanged from 0001564590-18-027351:mdna:84]

[0001564590-19-016264:mdna:86]
We do not have off-balance sheet financing arrangements and have not engaged in any related party transactions or arrangements with unconsolidated entities or other persons that are reasonably likely to materially affect liquidity or the availability of or requirements for capital resources. During the three months ended March 31, 2019, there have been no material changes in contractual obligations and commercial commitments from those discussed in our most recent Annual Report on Form 10-K for the year ended December 31, 2018 filed on February 28, 2019 with the SEC.

[0001564590-19-016264:mdna:87]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, and we have contributed $8.4 million as of March 31, 2019, of which $7.7 million has been applied to these commitments.
