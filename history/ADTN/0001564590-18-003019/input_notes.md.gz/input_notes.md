# ADTN notes — 0001564590-18-003019


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001564590-18-003019:notes:1]
Note 1 – Nature of Business and Summary of Significant Accounting Policies

[0001564590-18-003019:notes:2]
ADTRAN, Inc. (ADTRAN) is a leading global provider of networking and communications equipment. Our solutions enable voice, data, video and Internet communications across a variety of network infrastructures. These solutions are deployed by many of the United States’ and the world’s largest communications service providers (CSPs), distributed enterprises and small and medium-sized businesses, public and private enterprises, and millions of individual users worldwide.

[0001564590-18-003019:notes:3]
Principles of Consolidation

[0001564590-18-003019:notes:4]
Our consolidated financial statements include ADTRAN and its wholly owned subsidiaries. All inter-company accounts and transactions have been eliminated in consolidation.

[0001564590-18-003019:notes:5]
Use of Estimates

[0001564590-18-003019:notes:6]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States of America requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenue and expense during the reporting period. Our more significant estimates include the obsolete and excess inventory reserves, warranty reserves, customer rebates, determination of the deferred revenue components of multiple element sales agreements, estimated costs to complete obligations associated with deferred revenues and network installations, estimated income tax provision and income tax contingencies, the fair value of stock-based compensation, impairment of goodwill, valuation and estimated lives of intangible assets, estimated pension liability, fair value of investments, and the evaluation of other-than-temporary declines in the value of investments. Actual amounts could differ significantly from these estimates.

[0001564590-18-003019:notes:7]
Cash and Cash Equivalents

[0001564590-18-003019:notes:8]
Cash and cash equivalents represent demand deposits, money market funds, and short-term investments classified as available-for-sale with original maturities of three months or less. We maintain depository investments with certain financial institutions. Although these depository investments may exceed government insured depository limits, we have evaluated the credit worthiness of these applicable financial institutions, and determined the risk of material financial loss due to the exposure of such credit risk to be minimal. As of December 31, 2017, $83.7 million of our cash and cash equivalents, primarily certain domestic money market funds and foreign depository accounts, were in excess of government provided insured depository limits.

[0001564590-18-003019:notes:9]
Financial Instruments

[0001564590-18-003019:notes:10]
The carrying amounts reported in the consolidated balance sheets for cash and cash equivalents, accounts receivable, and accounts payable approximate fair value due to the immediate or short-term maturity of these financial instruments. The carrying amount reported for bonds payable was $26.7 million, compared to an estimated fair value of $26.7 million, based on a debt security with a comparable interest rate and maturity and a Standard & Poor’s credit rating of AAA.

[0001564590-18-003019:notes:11]
Investments with contractual maturities beyond one year, such as our variable rate demand notes, may be classified as short-term based on their highly liquid nature and because such marketable securities represent the investment of cash that is available for current operations. Despite the long-term nature of their stated contractual maturities, we routinely buy and sell these securities and we believe we have the ability to quickly sell them to the remarketing agent, tender agent, or issuer at par value plus accrued interest in the event we decide to liquidate our investment in a particular variable rate demand note. All income generated from these investments was recorded as interest income. We have not been required to record any losses relating to variable rate demand notes.

[0001564590-18-003019:notes:12]
Long-term investments represent a restricted certificate of deposit held at cost, deferred compensation plan assets, corporate bonds, municipal fixed-rate bonds, asset-backed bonds, mortgage/agency backed bonds, U.S. and foreign government bonds, variable rate demand notes, marketable equity securities, and other equity investments. Marketable equity securities are reported at fair value as determined by the most recently traded price of the securities at the balance sheet date, although the securities may not be readily marketable due to the size of the available market. Unrealized gains and losses, net of tax, are reported as a separate component of stockholders’ equity. Realized gains and losses on sales of securities are computed under the specific identification method and are included in current income. We review our investment portfolio quarterly for investments considered to have sustained an other-than-temporary decline in value. Impairment charges for other-than-temporary declines in value are recorded as realized losses in the accompanying consolidated statements of income. All of our investments at December 31, 2017 and 2016 are classified as available-for-sale securities. See Note 4 of Notes to Consolidated Financial Statements for additional information.

[0001564590-18-003019:notes:13]
Accounts Receivable

[0001564590-18-003019:notes:14]
We record accounts receivable at net realizable value. Prior to establishing payment terms for a new customer, we evaluate the credit risk of the customer. Credit limits and payment terms established for new customers are re-evaluated periodically based on customer collection experience and other financial factors. At December 31, 2017, single customers comprising more than 10% of our total accounts receivable balance included two customers, which accounted for 63.8% of our total accounts receivable. At December 31, 2016, single customers comprising more than 10% of our total accounts receivable balance included three customers, which accounted for 63.3% of our total accounts receivable.

[0001564590-18-003019:notes:15]
We regularly review the need to maintain an allowance for doubtful accounts and consider factors such as the age of accounts receivable balances, the current economic conditions that may affect a customer’s ability to pay, significant one-time events and our historical experience. If the financial condition of a customer deteriorates, resulting in an impairment of their ability to make payments, we may be required to record an allowance for doubtful accounts. If circumstances change with regard to individual receivable balances that have previously been determined to be uncollectible (and for which a specific reserve has been established), a reduction in our allowance for doubtful accounts may be required. We did not have an allowance for doubtful accounts at December 31, 2017 or December 31, 2016.

[0001564590-18-003019:notes:16]
Other Receivables

[0001564590-18-003019:notes:17]
Other receivables are comprised primarily of lease receivables, amounts due from subcontract manufacturers for product component transfers, unbilled receivables, amounts due from various jurisdictions for value-added tax, income tax receivable, accrued interest on investments and on a restricted certificate of deposit, and amounts due from employee stock option exercises.

[0001564590-18-003019:notes:18]
Inventory

[0001564590-18-003019:notes:19]
Inventory is carried at the lower of cost and net realizable value, with cost being determined using the first-in, first-out method. Standard costs for material, labor and manufacturing overhead are used to value inventory. Standard costs are updated at least quarterly; therefore, inventory costs approximate actual costs at the end of each reporting period. We establish reserves for estimated excess, obsolete or unmarketable inventory equal to the difference between the cost of the inventory and the estimated fair value of the inventory based upon assumptions about future demand, market conditions and age. When we dispose of excess and obsolete inventories, the related disposals are charged against the inventory reserve. See Note 6 of Notes to Consolidated Financial Statements for additional information.

[0001564590-18-003019:notes:20]
Property, Plant and Equipment

[0001564590-18-003019:notes:21]
Property, plant and equipment, which is stated at cost, is depreciated using the straight-line method over the estimated useful lives of the assets. We depreciate building and land improvements from five to 39 years, office machinery and equipment from three to seven years, engineering machinery and equipment from three to seven years, and computer software from three to five years. Expenditures for repairs and maintenance are charged to expense as incurred. Betterments that materially prolong the lives of the assets are capitalized. Gains and losses on the disposal of property, plant and equipment are recorded in operating income. See Note 7 of Notes to Consolidated Financial Statements for additional information.

[0001564590-18-003019:notes:22]
Liability for Warranty

[0001564590-18-003019:notes:23]
Our products generally include warranties of 90 days to five years for product defects. We accrue for warranty returns at the time revenue is recognized based on our historical return rate and estimate of the cost to repair or replace the defective products. We engage in extensive product quality programs and processes, including actively monitoring and evaluating the quality of our component suppliers. Our products continue to become more complex in both size and functionality as many of our product offerings migrate from line card applications to total systems. The increasing complexity of our products will cause warranty incidences, when they arise, to be more costly. Our estimates regarding future warranty obligations may change due to product failure rates, material usage, and other rework costs incurred in correcting a product failure. In addition, from time to time, specific warranty accruals may be recorded if unforeseen problems arise. Should our actual experience relative to these factors be worse than our estimates, we will be required to record additional warranty expense. Alternatively, if we provide for more reserves than we require, we will reverse a portion of such provisions in future periods. During 2017, we recorded a reduction in warranty expense related to a settlement with a third party supplier for a defective component, the impact of which is reflected in the following table. The liability for warranty obligations totaled $9.7 million and $8.5 million at December 31, 2017 and 2016, respectively. These liabilities are included in accrued expenses in the accompanying consolidated balance sheets.

[0001564590-18-003019:notes:24]
A summary of warranty expense and write-off activity for the years ended December 31, 2017, 2016 and 2015 is as follows:

[0001564590-18-003019:notes:25]
| Year Ended December 31, |  | 2017 |  |  | 2016 |  |  | 2015 |  |
| (In thousands) |  |  |  |  |  |  |  |  |  |  |  |  |
| Balance at beginning of period |  | $ | 8,548 |  |  | $ | 8,739 |  |  | $ | 8,415 |  |
| Plus: Amounts charged to cost and expenses |  |  | 6,951 |  |  |  | 8,561 |  |  |  | 2,998 |  |
| Less: Deductions |  |  | (5,775 | ) |  |  | (8,752 | ) |  |  | (2,674 | ) |
| Balance at end of period |  | $ | 9,724 |  |  | $ | 8,548 |  |  | $ | 8,739 |  |

[0001564590-18-003019:notes:26]
Pension Benefit Plan Obligations

[0001564590-18-003019:notes:27]
We maintain a defined benefit pension plan covering employees in certain foreign countries. Pension benefit plan obligations are based on various assumptions used by our actuaries in calculating these amounts. These assumptions include discount rates, compensation rate increases, expected return on plan assets, retirement rates and mortality rates. Actual results that differ from the assumptions and changes in assumptions could affect future expenses and obligations.

[0001564590-18-003019:notes:28]
Stock-Based Compensation

[0001564590-18-003019:notes:29]
We have two Board and stockholder approved stock incentive plans from which stock options, performance stock units (PSUs), restricted stock units (RSUs) and restricted stock are available for grant to employees and directors. All employee and director stock options granted under our stock option plans have an exercise price equal to the fair market value of the award, as defined in the plan, of the underlying common stock on the grant date. All of our outstanding stock option awards are classified as equity awards.

[0001564590-18-003019:notes:30]
Stock-based compensation expense recognized in 2017, 2016 and 2015 was approximately $7.4 million, $6.7 million and $6.7 million, respectively. As of December 31, 2017, total compensation cost related to non-vested stock options, market-based PSUs, RSUs and restricted stock not yet recognized was approximately $17.1 million, which is expected to be recognized over an average remaining recognition period of 2.9 years. In addition, there was $11.4 million of unrecognized compensation expense related to unvested performance-based PSUs, which will be recognized over the requisite service period of three years as achievement of the performance obligation becomes probable. See Note 3 of Notes to Consolidated Financial Statements for additional information.

[0001564590-18-003019:notes:31]
Impairment of Long-Lived Assets

[0001564590-18-003019:notes:32]
We review long-lived assets used in operations for impairment whenever events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable and the undiscounted cash flows estimated to be generated by the asset are less than the asset’s carrying value. An impairment loss would be recognized in the amount by which the recorded value of the asset exceeds the fair value of the asset, measured by the quoted market price of an asset or an estimate based on the best information available in the circumstances. There were no impairment losses recognized during 2017, 2016 or 2015.

[0001564590-18-003019:notes:33]
Goodwill and Purchased Intangible Assets

[0001564590-18-003019:notes:34]
We evaluate the carrying value of goodwill during the fourth quarter of each year and between annual evaluations if events occur or circumstances change that would more likely than not reduce the fair value of the reporting unit below its carrying amount. We have elected to first assess the qualitative factors to determine whether it is more likely than not that the fair value of the reporting unit to which the goodwill is assigned is less than its carrying amount as a basis for determining whether it is necessary to perform the two-step impairment test. If we determine that it is more likely than not that its fair value is less than its carrying amount, then the two-step impairment test will be performed. Based on the results of our qualitative assessment in 2017, we concluded that it was not necessary to perform the two-step impairment test. There have been no impairment losses recognized since the goodwill was acquired in an acquisition in 2011. Purchased intangible assets with finite lives are carried at cost, less accumulated amortization. Amortization is recorded over the estimated useful lives of the respective assets, which is 9 months to 14 years.

[0001564590-18-003019:notes:35]
Research and Development Costs

[0001564590-18-003019:notes:36]
Research and development costs include compensation for engineers and support personnel, outside contracted services, depreciation and material costs associated with new product development, the enhancement of current products, and product cost reductions. We continually evaluate new product opportunities and engage in intensive research and product development efforts. Research and development costs totaled $130.4 million, $124.8 million and $129.9 million for the years ended December 31, 2017, 2016 and 2015, respectively.

[0001564590-18-003019:notes:37]
Other Comprehensive Income

[0001564590-18-003019:notes:38]
Other comprehensive income consists of unrealized gains (losses) on available-for-sale securities; unrealized gains (losses) on cash flow hedges; reclassification adjustments for amounts included in net income related to impairments of available-for-sale securities, realized gains (losses) on available-for-sale securities, realized gains (losses) on cash flow hedges, and amortization of actuarial gains (losses) related to our defined benefit plan; defined benefit plan adjustments; and foreign currency translation adjustments.

[0001564590-18-003019:notes:39]
The following table presents changes in accumulated other comprehensive income, net of tax, by component for the years ended December 31, 2015, 2016 and 2017:

[0001564590-18-003019:notes:40]
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Unrealized Gains (Losses) on Cash Flow Hedges |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | Total |  |
| Balance, December 31, 2014 |  | $ | 8,964 |  |  | $ | — |  |  | $ | (5,757 | ) |  | $ | (3,282 | ) |  | $ | (75 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | (844 | ) |  |  | — |  |  |  | 1,589 |  |  |  | (3,724 | ) |  |  | (2,979 | ) |
| Amounts reclassified from accumulated other comprehensive income |  |  | (6,188 | ) |  |  | — |  |  |  | 273 |  |  |  | — |  |  |  | (5,915 | ) |
| Balance, December 31, 2015 |  |  | 1,932 |  |  |  | — |  |  |  | (3,895 | ) |  |  | (7,006 | ) |  |  | (8,969 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | 1,515 |  |  |  | — |  |  |  | (1,229 | ) |  |  | (569 | ) |  |  | (283 | ) |
| Amounts reclassified from accumulated other comprehensive income |  |  | (3,043 | ) |  |  | — |  |  |  | 107 |  |  |  | — |  |  |  | (2,936 | ) |
| Balance, December 31, 2016 |  |  | 404 |  |  |  | — |  |  |  | (5,017 | ) |  |  | (7,575 | ) |  |  | (12,188 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | 5,020 |  |  |  | (619 | ) |  |  | 451 |  |  |  | 5,999 |  |  |  | 10,851 |  |
| Amounts reclassified from accumulated other comprehensive income |  |  | (2,857 | ) |  |  | 619 |  |  |  | 280 |  |  |  | — |  |  |  | (1,958 | ) |
| Balance at December 31, 2017 |  | $ | 2,567 |  |  | $ | — |  |  | $ | (4,286 | ) |  | $ | (1,576 | ) |  | $ | (3,295 | ) |

[0001564590-18-003019:notes:41]
The following tables present the details of reclassifications out of accumulated other comprehensive income for the years ended December 31, 2017, 2016 and 2015:

[0001564590-18-003019:notes:42]
| (In thousands) |  | 2017 |
| Details about Accumulated Other Comprehensive Income Components |  | Amount Reclassified from Accumulated Other Comprehensive Income |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for-sale securities: |  |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 4,864 |  |  | Net realized investment gain |
| Impairment expense |  |  | (180 | ) |  | Net realized investment gain |
| Net losses on derivatives designated as hedging instruments |  |  | (897 | ) |  | Cost of sales |
| Defined benefit plan adjustments – actuarial losses |  |  | (406 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | 3,381 |  |  |  |
| Tax (expense) benefit |  |  | (1,423 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 1,958 |  |  |  |

[0001564590-18-003019:notes:43]
| (1) | Included in the computation of net periodic pension cost. See Note 12 of Notes to Consolidated Financial Statements. |

[0001564590-18-003019:notes:44]
| (In thousands) |  | 2016 |
| Details about Accumulated Other Comprehensive Income Components |  | Amount Reclassified from Accumulated Other Comprehensive Income |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for-sale securities: |  |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 5,408 |  |  | Net realized investment gain |
| Impairment expense |  |  | (419 | ) |  | Net realized investment gain |
| Defined benefit plan adjustments – actuarial losses |  |  | (156 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | 4,833 |  |  |  |
| Tax (expense) benefit |  |  | (1,897 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 2,936 |  |  |  |

[0001564590-18-003019:notes:45]
| (In thousands) |  | 2015 |
| Details about Accumulated Other Comprehensive Income Components |  | Amount Reclassified from Accumulated Other Comprehensive Income |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for-sale securities: |  |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 10,348 |  |  | Net realized investment gain |
| Impairment expense |  |  | (203 | ) |  | Net realized investment gain |
| Defined benefit plan adjustments – actuarial losses |  |  | (396 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | 9,749 |  |  |  |
| Tax (expense) benefit |  |  | (3,834 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 5,915 |  |  |  |

[0001564590-18-003019:notes:46]
The following tables present the tax effects related to the change in each component of other comprehensive income for the years ended December 31, 2017, 2016 and 2015:

[0001564590-18-003019:notes:47]
|  |  | 2017 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |
| Unrealized gains (losses) on available-for-sale securities |  | $ | 8,230 |  |  | $ | (3,210 | ) |  | $ | 5,020 |  |
| Reclassification adjustment for amounts related to available-for-sale investments included in net income |  |  | (4,684 | ) |  |  | 1,827 |  |  |  | (2,857 | ) |
| Unrealized gains (losses) on cash flow hedges |  |  | (897 | ) |  |  | 278 |  |  |  | (619 | ) |
| Reclassification adjustment for amounts related to cash flow hedges included in net income |  |  | 897 |  |  |  | (278 | ) |  |  | 619 |  |
| Defined benefit plan adjustments |  |  | 654 |  |  |  | (203 | ) |  |  | 451 |  |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net income |  |  | 406 |  |  |  | (126 | ) |  |  | 280 |  |
| Foreign currency translation adjustment |  |  | 5,999 |  |  |  | — |  |  |  | 5,999 |  |
| Total Other Comprehensive Income (Loss) |  | $ | 10,605 |  |  | $ | (1,712 | ) |  | $ | 8,893 |  |

[0001564590-18-003019:notes:48]
|  |  | 2016 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |
| Unrealized gains (losses) on available-for-sale securities |  | $ | 2,484 |  |  | $ | (969 | ) |  | $ | 1,515 |  |
| Reclassification adjustment for amounts related to available-for-sale investments included in net income |  |  | (4,989 | ) |  |  | 1,946 |  |  |  | (3,043 | ) |
| Defined benefit plan adjustments |  |  | (1,782 | ) |  |  | 553 |  |  |  | (1,229 | ) |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net income |  |  | 156 |  |  |  | (49 | ) |  |  | 107 |  |
| Foreign currency translation adjustment |  |  | (569 | ) |  |  | — |  |  |  | (569 | ) |
| Total Other Comprehensive Income (Loss) |  | $ | (4,700 | ) |  | $ | 1,481 |  |  | $ | (3,219 | ) |

[0001564590-18-003019:notes:49]
|  |  | 2015 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |
| Unrealized gains (losses) on available-for-sale securities |  | $ | (1,384 | ) |  | $ | 540 |  |  | $ | (844 | ) |
| Reclassification adjustment for amounts related to available-for-sale investments included in net income |  |  | (10,145 | ) |  |  | 3,957 |  |  |  | (6,188 | ) |
| Defined benefit plan adjustments |  |  | 2,303 |  |  |  | (714 | ) |  |  | 1,589 |  |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net income |  |  | 396 |  |  |  | (123 | ) |  |  | 273 |  |
| Foreign currency translation adjustment |  |  | (3,724 | ) |  |  | — |  |  |  | (3,724 | ) |
| Total Other Comprehensive Income (Loss) |  | $ | (12,554 | ) |  | $ | 3,660 |  |  | $ | (8,894 | ) |

[0001564590-18-003019:notes:50]
Income Taxes

[0001564590-18-003019:notes:51]
The provision for income taxes has been determined using the asset and liability approach of accounting for income taxes. Under this approach, deferred taxes represent the future tax consequences expected to occur when the reported amounts of assets and liabilities are recovered or paid. The provision for income taxes represents income taxes paid or payable for the current year plus the change in deferred taxes during the year. Deferred taxes result from the difference between financial and tax bases of our assets and liabilities and are adjusted for changes in tax rates and tax laws when such changes are enacted. Valuation allowances are recorded to reduce deferred tax assets when it is more likely than not that a tax benefit will not be realized.

[0001564590-18-003019:notes:52]
We establish reserves to remove some or all of the tax benefit of any of our tax positions at the time we determine that the positions become uncertain. We adjust these reserves, including any impact on the related interest and penalties, as facts and circumstances change.

[0001564590-18-003019:notes:53]
On December 22, 2017, the Tax Cuts and Jobs Act (the Act) was signed into law. As a result of the Act, we have recognized an estimated expense of $11.9 million in the fourth quarter of 2017, of which $9.2 million related to the write-down of deferred tax assets and $2.7 million related to tax on unrepatriated foreign earnings. We have calculated our best estimate of the impact of the Act in our year-end income tax provision, in accordance with Staff Accounting Bulletin No. 118, which was issued to address the application of U.S. GAAP in situations when a registrant does not have the necessary information available, prepared or analyzed to finalize the accounting for certain income tax effects of the Act. Additional work is necessary to do a more detailed analysis of historical foreign earnings, as well as the full impact relating to the write-down of deferred tax assets. Any subsequent adjustments to these amounts will be recorded as income tax expense in the quarter the analysis is complete.

[0001564590-18-003019:notes:54]
Foreign Currency

[0001564590-18-003019:notes:55]
We record transactions denominated in foreign currencies on a monthly basis using exchange rates from throughout the year. Assets and liabilities denominated in foreign currencies are remeasured at the balance sheet dates using the closing rates of exchange between those foreign currencies and the functional currency with any transaction gains or losses reported in other income (expense). Our primary exposures to foreign currency exchange rate movements are with our German subsidiary, whose functional currency is the Euro, our Australian subsidiary, whose functional currency is the Australian dollar, and our Mexican subsidiary, whose functional currency is the U.S. dollar. Adjustments resulting from translating financial statements of international subsidiaries are recorded as a component of accumulated other comprehensive income (loss).

[0001564590-18-003019:notes:56]
Revenue Recognition

[0001564590-18-003019:notes:57]
Revenue is generally recognized when persuasive evidence of an arrangement exists, delivery has occurred, the product price is fixed or determinable, collection of the resulting receivable is reasonably assured, and product returns are reasonably estimable. For product sales, revenue is generally recognized upon shipment of the product to our customer in accordance with the title transfer terms of the sales agreement, generally Ex Works, per International Commercial Terms. In the case of consigned inventory, revenue is recognized when the end customer assumes ownership of the product. Contracts that contain multiple deliverables are evaluated to determine the units of accounting, and the consideration from the arrangement is allocated to each unit of accounting based on the relative selling price and corresponding terms of the contract. When this is not available, we are generally not able to determine third-party evidence of selling price because of the extent of customization among competing products or services from other companies. In these instances, we use best estimates to allocate consideration to each respective unit of accounting. These estimates include analysis of respective bills of material and review and analysis of similar product and service offerings. We record revenue associated with installation services when respective contractual obligations are complete. In instances where customer acceptance is required, revenue is deferred until respective acceptance criteria have been met. Contracts that include both installation services and product sales are evaluated for revenue recognition in accordance with contract terms. As a result, installation services may be considered a separate deliverable or may be considered a combined single unit of accounting with the delivered product. Generally, either the purchaser, ADTRAN, or a third party can perform the installation of our products. Shipping fees are recorded as revenue and the related cost is included in cost of sales. Sales taxes invoiced to customers are included in revenues, and represent less than one percent of total revenues. The corresponding sales taxes paid are included in cost of goods sold. Value added taxes collected from customers in international jurisdictions are recorded in accrued expenses as a liability. Revenue is recorded net of discounts. Sales returns are recorded as a reduction of revenue and accrued based on historical sales return experience, which we believe provides a reasonable estimate of future returns.

[0001564590-18-003019:notes:58]
A portion of our products are sold to a non-exclusive distribution network of major technology distributors in the United States. These large organizations then distribute or provide fulfillment services to an extensive network of VARs and SIs. VARs and SIs may be affiliated with us as a channel partner, or they may purchase from the distributor in an unaffiliated fashion. Additionally, with certain limitations our distributors may return unused and unopened product for stock-balancing purposes when such returns are accompanied by offsetting orders for products of equal or greater value.

[0001564590-18-003019:notes:59]
We participate in cooperative advertising and market development programs with certain customers. We use these programs to reimburse customers for certain forms of advertising, and in general, to allow our customers credits up to a specified percentage of their net purchases. Our costs associated with these programs are estimated and included in marketing expenses in our consolidated statements of income. We also participate in rebate programs to provide sales incentives for certain products. Our costs associated with these programs are estimated and accrued at the time of sale, and are recorded as a reduction of sales in our consolidated statements of income.

[0001564590-18-003019:notes:60]
Unearned Revenue

[0001564590-18-003019:notes:61]
Unearned revenue primarily represents customer billings on our maintenance service programs and leases and unearned revenues relating to multiple element contracts where we still have contractual obligations to our customers. We currently offer maintenance contracts ranging from one to five years. Revenue attributable to maintenance contracts is recognized on a straight-line basis over the related contract term. In addition, we provide software maintenance and a variety of hardware maintenance services to customers under contracts with terms up to ten years. When we defer revenue related to multiple-element contracts where we still have contractual obligations, we also defer the related costs. Current deferred costs are included in prepaid expenses and other assets and totaled $11.4 million and $10.7 million at December 31, 2017 and 2016, respectively. Non-current deferred costs are included in other assets and totaled $2.8 million and $0.9 million at December 31, 2017 and 2016, respectively.

[0001564590-18-003019:notes:62]
Other Income (Expense), Net

[0001564590-18-003019:notes:63]
Other income (expense), net, is comprised primarily of miscellaneous income and expense, gains and losses on foreign currency transactions, gains and losses on foreign exchange forward contracts, investment account management fees, and scrap raw material sales.

[0001564590-18-003019:notes:64]
Earnings per Share

[0001564590-18-003019:notes:65]
Earnings per common share, and earnings per common share assuming dilution, are based on the weighted average number of common shares and, when dilutive, common equivalent shares outstanding during the year. See Note 15 of Notes to Consolidated Financial Statements for additional information.

[0001564590-18-003019:notes:66]
Dividends

[0001564590-18-003019:notes:67]
During 2017, 2016 and 2015, we paid shareholder dividends totaling $17.4 million, $17.6 million and $18.4 million, respectively. The Board of Directors presently anticipates that it will declare a regular quarterly dividend so long as the present tax treatment of dividends exists and adequate levels of liquidity are maintained. The following table shows dividends paid to our shareholders in each quarter of 2017, 2016 and 2015.

[0001564590-18-003019:notes:68]
| Dividends per Common Share |  |
|  |  | 2017 |  |  | 2016 |  |  | 2015 |  |
| First Quarter |  | $ | 0.09 |  |  | $ | 0.09 |  |  | $ | 0.09 |  |
| Second Quarter |  | $ | 0.09 |  |  | $ | 0.09 |  |  | $ | 0.09 |  |
| Third Quarter |  | $ | 0.09 |  |  | $ | 0.09 |  |  | $ | 0.09 |  |
| Fourth Quarter |  | $ | 0.09 |  |  | $ | 0.09 |  |  | $ | 0.09 |  |

[0001564590-18-003019:notes:69]
On January 16, 2018, the Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to shareholders of record at the close of business on January 31, 2018. The ex-dividend date was January 30, 2018 and the payment date was February 14, 2018. The quarterly dividend payment was $4.4 million.

[0001564590-18-003019:notes:70]
Business Combinations

[0001564590-18-003019:notes:71]
We use the acquisition method to account for business combinations. Under the acquisition method of accounting, we recognize the assets acquired and liabilities assumed at their fair value on the acquisition date. Goodwill is measured as the excess of the consideration transferred over the net assets acquired. Costs incurred to complete the business combination, such as legal, accounting or other professional fees, are charged to general and administrative expenses as they are incurred.

[0001564590-18-003019:notes:72]
Recently Issued Accounting Standards

[0001564590-18-003019:notes:73]
In May 2014, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update No. 2014-09, Revenue from Contracts with Customers (Topic 606) (ASU 2014-09), which supersedes the revenue recognition requirements in Topic 605, Revenue Recognition, including most industry-specific revenue recognition guidance throughout the Industry Topics of the Codification. The core principle of ASU 2014-09 is to recognize revenues when promised goods or services are transferred to customers in an amount that reflects the consideration that is expected to be received for those goods or services. In August 2015, the FASB issued ASU 2015-14, which deferred the effective date of ASU 2014-09 to fiscal years beginning after December 31, 2017, and interim periods within those fiscal years, with early adoption permitted for reporting periods beginning after December 15, 2016. Subsequently, the FASB issued ASUs in 2016 containing implementation guidance related to ASU 2014-09, including: ASU 2016-08, Revenue from Contracts with Customers (Topic 606): Principal versus Agent Considerations (Reporting Revenue Gross versus Net), which is intended to improve the operability and understandability of the implementation guidance on principal versus agent considerations; ASU 2016-10, Revenue from Contracts with Customers (Topic 606): Identifying Performance Obligations and Licensing, which is intended to clarify two aspects of Topic 606: identifying performance obligations and the licensing implementation guidance; ASU 2016-12, Revenue from Contracts with Customers (Topic 606): Narrow-Scope Improvements and Practical Expedients, which contains certain provisions and practical expedients in response to identified implementation issues; and ASU 2016-20, Technical Corrections and Improvements to Topic 606, Revenue from Contracts with Customers, which is intended to clarify the Codification or to correct unintended application of guidance. ASU 2014-09 allows for either full retrospective or modified retrospective adoption. We adopted ASU 2014-09 and the related ASUs on January 1, 2018 using the modified retrospective method.

[0001564590-18-003019:notes:74]
The two areas of impact of these ASUs are network installation service revenue performance obligations and contract costs. The output method will be used to measure network installation services progress. The primary impact will be the timing of revenue recognition for certain performance obligations related to service revenue arrangements that are currently deferred until customer acceptance.

[0001564590-18-003019:notes:75]
In connection with the adoption of the new revenue standard, effective January 1, 2018, we adopted ASC 340-40, Other Assets and Deferred Costs - Contracts with Customers, with respect to capitalization and amortization of incremental costs of obtaining a contract. As a result, certain costs of obtaining a contract will need to be capitalized, including sales commissions, as the guidance requires the capitalization of all incremental costs incurred to obtain a contract with a customer that it would not have incurred if the contract had not been obtained, provided the costs are recoverable. The primary impact will be capitalization of certain sales commissions for our extended maintenance and support contracts in excess of one year and costs associated with our capital lease arrangements that are billed monthly, and amortization of those costs over the period that the related revenue is recognized.

[0001564590-18-003019:notes:76]
We will recognize the cumulative adjustment for network installation service revenue performance obligations and contract costs to retained earnings during the three months ended March 31, 2018. We do not believe the cumulative adjustment will have a significant impact on our consolidated financial statements during 2018.

[0001564590-18-003019:notes:77]
In February 2016, the FASB issued Accounting Standards Update No. 2016-02, Leases (Topic 842) (ASU 2016-02). ASU 2016-02 requires an entity to recognize lease assets and lease liabilities on the balance sheet and to disclose key information about the entity's leasing arrangements. ASU 2016-02 is effective for fiscal years beginning after December 15, 2018, and interim periods within those fiscal years. A modified retrospective approach is required. We anticipate the adoption of ASU 2016-02 will have a material impact on our financial position; however, we do not believe adoption will have a material impact on our results of operations. We believe the most significant impact relates to our accounting for operating leases for office space and equipment.

[0001564590-18-003019:notes:78]
In January 2017, the FASB issued Accounting Standards Update No. 2017-04, Intangibles – Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment (ASU 2017-04). ASU 2017-04 simplifies the measurement of goodwill by eliminating step 2 of the goodwill impairment test. Under ASU 2017-04, entities will be required to compare the fair value of a reporting unit to its carrying amount and recognize an impairment charge for the amount by which the carrying amount exceeds the reporting unit’s fair value. ASU 2017-04 is effective for annual or interim impairment tests performed in fiscal years beginning after December 15, 2019, with early adoption permitted for annual or interim impairment tests performed on testing dates after January 1, 2017. The amendments should be applied prospectively. We are currently evaluating whether to early adopt ASU 2017-04, but we do not expect it will have a material impact on our financial position, results of operations or cash flows.

[0001564590-18-003019:notes:79]
In March 2017, the FASB issued Accounting Standards Update No. 2017-07, Compensation – Retirement Benefits (Topic 715): Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost (ASU 2017-07). ASU 2017-07 amends ASC 715, Compensation — Retirement Benefits, to require employers that present a measure of operating income in their statements of earnings to include only the service cost component of net periodic pension cost and net periodic postretirement benefit cost in operating expenses (together with other employee compensation costs). The other components of net benefit cost, including amortization of prior service cost/credit, and settlement and curtailment effects, are to be included in non-operating expenses. ASU 2017-07 is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017. We adopted ASU 2017-07 on January 1, 2018 and we do not expect it will have a material impact on our financial position, results of operations or cash flows.

[0001564590-18-003019:notes:80]
In August 2017, the FASB issued Accounting Standards Update No. 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities (ASU 2017-12). ASU 2017-12 expands and refines hedge accounting for both financial and non-financial risk components, aligns the recognition and presentation of the effects of hedging instruments and hedge items in the financial statements, and includes certain targeted improvements to ease the application of current guidance related to the assessment of hedge effectiveness. ASU 2017-12 is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2018, with early adoption permitted. We are currently evaluating the impact ASU 2017-12 will have on our financial position, results of operations and cash flows.

[0001564590-18-003019:notes:81]
During 2017, we adopted the following accounting standards, which had no material effect on our financial position, results of operations or cash flows:

[0001564590-18-003019:notes:82]
In July 2015, the FASB issued Accounting Standards Update No. 2015-11, Inventory (Topic 330): Simplifying the Measurement of Inventory (ASU 2015-11). Currently, Topic 330, Inventory, requires an entity to measure inventory at the lower of cost or market. Market could be replacement cost, net realizable value, or net realizable value less an approximately normal profit margin. ASU 2015-11 does not apply to inventory that is measured using last-in, first-out (LIFO) or the retail inventory method. The amendments apply to all other inventory, which includes inventory that is measured using first-in, first-out (FIFO) or average cost. ASU 2015-11 requires an entity to measure in scope inventory at the lower of cost and net realizable value. Net realizable value is the estimated selling prices in the ordinary course of business, less reasonably predictable costs of completion, disposal, and transportation. ASU 2015-11 is effective for annual reporting periods beginning after December 15, 2016, including interim periods within that reporting period. The amendments should be applied prospectively with earlier application permitted as of the beginning of an interim or annual reporting period. We adopted ASU 2015-11 in the first quarter of 2017, and there was no material impact on our financial position, results of operations or cash flows.

[0001564590-18-003019:notes:83]
In January 2017, we adopted ASU 2016-09, Compensation – Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting. As a result, beginning in the first quarter of 2017, we began recognizing all excess tax benefits and tax deficiencies as income tax expense or benefit as a discrete event. The treatment of forfeitures has changed as we have elected to discontinue our past practice of estimating forfeitures and now account for forfeitures as they occur. As a result, we recorded an increase in additional paid in capital of $0.1 million, a charge to beginning retained earnings of $0.1 million, and an increase in the deferred tax assets related to non-qualified stock options and RSUs of $10 thousand. In addition, cash flows related to excess tax benefits will no longer be separately classified as a financing activity apart from other income tax cash flows within operating activities. We elected to retrospectively apply the changes in presentation to the statements of cash flows and no longer classify excess tax benefits as a financing activity, which had an immaterial impact on our cash flows for the years ended December 31, 2017, 2016 and 2015. There was no material impact on our financial position, results of operations or cash flows as a result of these changes.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001564590-18-003019:notes:84]
Note 2 – Business Combinations

[0001564590-18-003019:notes:85]
On September 13, 2016, we acquired key fiber access products, technologies and service relationships from subsidiaries of CommScope, Inc. for $0.9 million in cash. This acquisition enhanced our solutions for the cable MSO industry and provided cable operators with the scalable solutions, services and support they required to compete in the multi-gigabit service delivery market. This transaction was accounted for as a business combination. We have included the financial results of this acquisition in our consolidated financial statements since the date of acquisition. These revenues are included in the Network Solutions reportable segment, and in the Access & Aggregation and Customer Devices categories.

[0001564590-18-003019:notes:86]
We recorded a bargain purchase gain of $3.5 million during the year ended December 31, 2016, net of income taxes, which was subject to customary working capital adjustments between the parties. The bargain purchase gain of $3.5 million represents the excess fair value of the net assets acquired over the consideration exchanged. We have assessed the recognition and measurement of the assets acquired and liabilities assumed based on historical and pro forma data for future periods and have concluded that our valuation procedures and resulting measures were appropriate. The gain is included in the line item “Gain on bargain purchase of a business” in the 2016 Consolidated Statements of Income.

[0001564590-18-003019:notes:87]
Working capital adjustments were recorded in the fourth quarter of 2016 and resulted in an immaterial reduction in the inventory acquired, accounts payable assumed, deferred income taxes and bargain purchase gain. If these adjustments had been recorded on the date of acquisition, the bargain purchase gain would have been reduced by $8 thousand for the three months ended September 30, 2016. The final allocation of the purchase price to the estimated fair value of the assets acquired and liabilities assumed at the acquisition date is as follows:

[0001564590-18-003019:notes:88]
| (In Thousands) |  |  |  |  |
| Assets |  |  |  |  |
| Inventory |  | $ | 3,131 |  |
| Property, plant and equipment |  |  | 352 |  |
| Intangible assets |  |  | 4,700 |  |
| Total assets acquired |  |  | 8,183 |  |
| Liabilities |  |  |  |  |
| Accounts payable |  |  | (1,250 | ) |
| Warranty payable |  |  | (61 | ) |
| Accrued wages and benefits |  |  | (122 | ) |
| Deferred income taxes |  |  | (2,265 | ) |
| Total liabilities assumed |  |  | (3,698 | ) |
| Total net assets |  |  | 4,485 |  |
| Gain on bargain purchase of a business, net of tax |  |  | (3,542 | ) |
| Total purchase price |  | $ | 943 |  |

[0001564590-18-003019:notes:89]
The details of the acquired intangible assets are as follows:

[0001564590-18-003019:notes:90]
| In thousands |  | Value |  |  | Life (years) |  |
| Supply agreement |  | $ | 1,400 |  |  |  | 0.8 |  |
| Customer relationships |  |  | 1,200 |  |  |  | 6.0 |  |
| Developed technology |  |  | 800 |  |  |  | 10.0 |  |
| License |  |  | 500 |  |  |  | 1.3 |  |
| Patent |  |  | 500 |  |  |  | 7.3 |  |
| Non-compete |  |  | 200 |  |  |  | 2.3 |  |
| Trade name |  |  | 100 |  |  |  | 2.0 |  |
| Total |  | $ | 4,700 |  |  |  |  |  |

[0001564590-18-003019:notes:91]
The following unaudited supplemental pro forma information presents the financial results as if the acquisition had occurred on January 1, 2015. This unaudited supplemental pro forma information does not purport to be indicative of what would have occurred had the acquisition been completed on January 1, 2015, nor is it indicative of any future results. Aside from revising the 2015 net income for the effect of the bargain purchase gain, there were no material, non-recurring adjustments to this unaudited pro forma information.

[0001564590-18-003019:notes:92]
| (In thousands) |  | 2016 |  |  | 2015 |  |
| Pro forma revenue |  | $ | 641,170 |  |  | $ | 603,923 |  |
| Pro forma net income |  | $ | 31,212 |  |  | $ | 22,945 |  |
| Pro forma earnings per share – basic |  | $ | 0.64 |  |  | $ | 0.45 |  |
| Pro forma earnings per share – diluted |  | $ | 0.64 |  |  | $ | 0.45 |  |

[0001564590-18-003019:notes:93]
For the years ended December 31, 2017 and 2016, we incurred acquisition and integration related expenses and amortization of acquired intangibles of $1.8 million and $1.0 million, respectively, related to this acquisition.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-18-003019:notes:94]
Note 3 – Stock-Based Compensation

[0001564590-18-003019:notes:95]
Stock Incentive Program Descriptions

[0001564590-18-003019:notes:96]
On January 23, 2006, the Board of Directors adopted the ADTRAN, Inc. 2006 Employee Stock Incentive Plan (2006 Plan), which authorized 13.0 million shares of common stock for issuance to certain employees and officers through incentive stock options and non-qualified stock options, stock appreciation rights, RSUs and restricted stock. The 2006 Plan was adopted by stockholder approval at our annual meeting of stockholders held on May 9, 2006. Options granted under the 2006 Plan typically become exercisable beginning after one year of continued employment, normally pursuant to a four-year vesting schedule beginning on the first anniversary of the grant date, and have a ten-year contractual term. The 2006 Plan was replaced on May 13, 2015 by the ADTRAN, Inc. 2015 Employee Stock Incentive Plan (2015 Plan). Expiration dates of options outstanding at December 31, 2017 under the 2006 Plan range from 2018 to 2024.

[0001564590-18-003019:notes:97]
Our stockholders approved the 2010 Directors Stock Plan (2010 Directors Plan) on May 5, 2010, under which 0.5 million shares of common stock have been reserved. This plan replaces the 2005 Directors Stock Option Plan. Under the 2010 Directors Plan, the Company may issue stock options, restricted stock and RSUs to our non-employee directors. Stock awards issued under the 2010 Directors Plan normally become vested in full on the first anniversary of the grant date. Options issued under the 2010 Directors Plan have a ten-year contractual term. Expiration dates of options outstanding at December 31, 2017 under the 2010 Directors Plan range from 2018 to 2019.

[0001564590-18-003019:notes:98]
On January 20, 2015, the Board of Directors adopted the ADTRAN, Inc. 2015 Employee Stock Incentive Plan (2015 Plan), which authorizes 7.7 million shares of common stock for issuance to certain employees and officers through incentive stock options and non-qualified stock options, stock appreciation rights, PSUs, RSUs and restricted stock. The 2015 Plan was adopted by stockholder approval at our annual meeting of stockholders held on May 13, 2015. PSUs, RSUs and restricted stock granted under the 2015 Plan reduce the shares authorized for issuance under the 2015 Plan by 2.5 shares of common stock for each share underlying the award. Options granted under the 2015 Plan typically become exercisable beginning after one year of continued employment, normally pursuant to a four-year vesting schedule beginning on the first anniversary of the grant date, and have a ten-year contractual term. Expiration dates of options outstanding at December 31, 2017 under the 2015 Plan range from 2025 to 2026.

[0001564590-18-003019:notes:99]
The following table summarizes stock-based compensation expense related to stock options, PSUs, RSUs and restricted stock for the years ended December 31, 2017, 2016 and 2015, which was recognized as follows:

[0001564590-18-003019:notes:100]
| (In thousands) |  | 2017 |  |  | 2016 |  |  | 2015 |  |
| Stock-based compensation expense included in cost of sales |  | $ | 379 |  |  | $ | 389 |  |  | $ | 280 |  |
| Selling, general and administrative expense |  |  | 4,063 |  |  |  | 3,341 |  |  |  | 3,261 |  |
| Research and development expense |  |  | 2,991 |  |  |  | 2,965 |  |  |  | 3,171 |  |
| Stock-based compensation expense included in operating expenses |  |  | 7,054 |  |  |  | 6,306 |  |  |  | 6,432 |  |
| Total stock-based compensation expense |  |  | 7,433 |  |  |  | 6,695 |  |  |  | 6,712 |  |
| Tax benefit for expense associated with non-qualified options, PSUs, RSUs and restricted stock |  |  | (1,699 | ) |  |  | (963 | ) |  |  | (862 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 5,734 |  |  | $ | 5,732 |  |  | $ | 5,850 |  |

[0001564590-18-003019:notes:101]
With our adoption of ASU 2016-09 Compensation – Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting in January 2017, we elected to discontinue our past practice of estimating forfeitures and now account for forfeitures as they occur.

[0001564590-18-003019:notes:102]
Stock Options

[0001564590-18-003019:notes:103]
The following table is a summary of our stock options outstanding as of December 31, 2016 and 2017 and the changes that occurred during 2017:

[0001564590-18-003019:notes:104]
| (In thousands, except per share amounts) |  | Number of Options |  |  | Weighted Average Exercise Price |  |  | Weighted Avg. Remaining Contractual Life in Years |  |  | Aggregate Intrinsic Value |  |
| Stock options outstanding, December 31, 2016 |  |  | 6,338 |  |  | $ | 22.14 |  |  |  | 5.63 |  |  | $ | 16,972 |  |
| Stock options granted |  |  | — |  |  | $ | — |  |  |  |  |  |  |  |  |  |
| Stock options exercised |  |  | (742 | ) |  | $ | 18.08 |  |  |  |  |  |  |  |  |  |
| Stock options forfeited |  |  | (70 | ) |  | $ | 17.29 |  |  |  |  |  |  |  |  |  |
| Stock options expired |  |  | (378 | ) |  | $ | 24.14 |  |  |  |  |  |  |  |  |  |
| Stock options outstanding, December 31, 2017 |  |  | 5,148 |  |  | $ | 22.65 |  |  |  | 4.87 |  |  | $ | 6,109 |  |
| Stock options vested and expected to vest, December 31, 2017 |  |  | 5,148 |  |  | $ | 22.65 |  |  |  | 4.87 |  |  | $ | 6,109 |  |
| Stock options exercisable, December 31, 2017 |  |  | 4,351 |  |  | $ | 23.78 |  |  |  | 4.37 |  |  | $ | 3,810 |  |

[0001564590-18-003019:notes:105]
At December 31, 2017, total compensation cost related to non-vested stock options not yet recognized was approximately $3.2 million, which is expected to be recognized over an average remaining recognition period of 1.5 years.

[0001564590-18-003019:notes:106]
All of the options above were issued at exercise prices that approximated fair market value at the date of grant. At December 31, 2017, 3.5 million options were available for grant under the shareholder approved plans.

[0001564590-18-003019:notes:107]
The aggregate intrinsic values in the table above represent the total pre-tax intrinsic value (the difference between ADTRAN’s closing stock price on the last trading day of 2017 and the exercise price, multiplied by the number of in-the-money options) that would have been received by the option holders had all option holders exercised their options on December 31, 2017. The amount of aggregate intrinsic value will change based on the fair market value of ADTRAN’s stock.

[0001564590-18-003019:notes:108]
The total pre-tax intrinsic value of options exercised during 2017, 2016 and 2015 was $3.4 million, $1.1 million and $0.1 million, respectively. The fair value of options fully vesting during 2017, 2016 and 2015 was $4.3 million, $5.7 million and $6.6 million, respectively.

[0001564590-18-003019:notes:109]
The following table further describes our stock options outstanding as of December 31, 2017:

[0001564590-18-003019:notes:110]
|  |  | Options Outstanding |  |  | Options Exercisable |  |
| Range of Exercise Prices |  | Options Outstanding at 12/31/17 (In thousands) |  |  | Weighted Avg. Remaining Contractual Life in Years |  |  | Weighted Average Exercise Price |  |  | Options Exercisable at 12/31/17 (In thousands) |  |  | Weighted Average Exercise Price |  |
| $14.88 – 18.96 |  |  | 1,623 |  |  |  | 6.02 |  |  | $ | 15.77 |  |  |  | 1,063 |  |  | $ | 15.96 |  |
| $18.97 – 23.45 |  |  | 801 |  |  |  | 6.68 |  |  | $ | 19.11 |  |  |  | 565 |  |  | $ | 19.17 |  |
| $23.46 – 30.35 |  |  | 1,400 |  |  |  | 4.16 |  |  | $ | 23.85 |  |  |  | 1,399 |  |  | $ | 23.85 |  |
| $30.36 – 41.92 |  |  | 1,324 |  |  |  | 3.29 |  |  | $ | 31.94 |  |  |  | 1,324 |  |  | $ | 31.94 |  |
|  |  |  | 5,148 |  |  |  |  |  |  |  |  |  |  |  | 4,351 |  |  |  |  |  |

[0001564590-18-003019:notes:111]
PSUs, RSUs and restricted stock

[0001564590-18-003019:notes:112]
Under the 2015 Plan, awards other than stock options, including PSUs, RSUs and restricted stock, may be granted to certain employees and officers.

[0001564590-18-003019:notes:113]
Under our market-based PSU program, the number of shares of common stock earned by a recipient pursuant to the PSUs is subject to a market condition based on ADTRAN’s relative total shareholder return against all companies in the NASDAQ Telecommunications Index at the end of a three-year performance period. Depending on the relative total shareholder return over the performance period, the recipient may earn from 0% to 150% of the shares underlying the PSUs, with the shares earned distributed upon the vesting of the PSUs at the end of the three-year performance period. The fair value of the award is based on the market price of our common stock on the date of grant, adjusted for the expected outcome of the impact of market conditions using a Monte Carlo Simulation valuation method. A portion of the granted PSUs also vest and the underlying shares become deliverable upon the death or disability of the recipient or upon a change of control of ADTRAN, as defined by the 2015 Plan. The recipients of the PSUs receive dividend credits based on the shares of common stock underlying the PSUs. The dividend credits are vested and earned in the same manner as the PSUs and are paid in cash upon the issuance of common stock for the PSUs.

[0001564590-18-003019:notes:114]
During the first quarter of 2017, the Compensation Committee of the Board of Directors approved a PSU grant of 0.5 million shares that contain performance conditions. The fair value of these performance-based PSU awards was equal to the closing price of our stock on the date of grant.

[0001564590-18-003019:notes:115]
The fair value of RSUs and restricted stock is equal to the closing price of our stock on the business day immediately preceding the grant date. RSUs and restricted stock vest ratably over four year and one year periods, respectively.

[0001564590-18-003019:notes:116]
The following table is a summary of our PSUs, RSUs and restricted stock outstanding as of December 31, 2016 and 2017 and the changes that occurred during 2017. The unvested awards outstanding as of December 31, 2016 have been adjusted for the actual shares vested in 2017 for our market-based PSUs.

[0001564590-18-003019:notes:117]
| (In thousands, except per share amounts) |  | Number of shares |  |  | Weighted Average Grant Date Fair Value |  |
| Unvested PSUs, RSUs and restricted stock outstanding, December 31, 2016 |  |  | 527 |  |  | $ | 20.53 |  |
| PSUs, RSUs and restricted stock granted |  |  | 950 |  |  | $ | 21.69 |  |
| PSUs, RSUs and restricted stock vested |  |  | (154 | ) |  | $ | 20.84 |  |
| PSUs, RSUs and restricted stock forfeited |  |  | (31 | ) |  | $ | 20.99 |  |
| Unvested RSUs and restricted stock outstanding, December 31, 2017 |  |  | 1,292 |  |  | $ | 21.33 |  |

[0001564590-18-003019:notes:118]
At December 31, 2017, total compensation cost related to the non-vested portion of market-based PSUs, RSUs and restricted stock not yet recognized was approximately $13.9 million, which is expected to be recognized over an average remaining recognition period of 3.2 years. In addition, there was $11.4 million of unrecognized compensation expense related to unvested performance-based PSUs, which will be recognized over the requisite service period of three years as achievement of the performance obligation becomes probable. For the year ended 2017, no compensation expense was recognized related to these performance-based PSUs.

[0001564590-18-003019:notes:119]
Valuation and Expense Information

[0001564590-18-003019:notes:120]
We use the Black-Scholes option pricing model (Black-Scholes Model) for the purpose of determining the estimated fair value of stock option awards on the date of grant. The Black-Scholes Model requires the input of certain assumptions that involve judgment. Because our stock options have characteristics significantly different from those of traded options, and because changes in the input assumptions can materially affect the fair value estimate, existing models may not provide reliable measures of fair value of our stock options. We use a Monte Carlo Simulation valuation method to value our market-based PSUs. The fair value of our performance-based PSUs, RSUs and restricted stock issued is equal to the closing price of our stock on the date of grant. We will continue to assess the assumptions and methodologies used to calculate the estimated fair value of stock-based compensation. If circumstances change, and additional data becomes available over time, we may change our assumptions and methodologies, which may materially impact our fair value determination.

[0001564590-18-003019:notes:121]
The stock option pricing model requires the use of several assumptions that impact the fair value estimate. These variables include, but are not limited to, the volatility of our stock price and employee exercise behaviors.

[0001564590-18-003019:notes:122]
There were no stock option grants in 2017. The weighted-average estimated fair value of stock options granted to employees during the years ended December 31, 2016 and 2015 was $5.22 per share and $4.28 per share, respectively, with the following weighted-average assumptions:

[0001564590-18-003019:notes:123]
|  |  | 2016 |  |  | 2015 |  |
| Expected volatility |  |  | 34.79 | % |  |  | 34.57 | % |
| Risk-free interest rate |  |  | 1.36 | % |  |  | 1.81 | % |
| Expected dividend yield |  |  | 1.98 | % |  |  | 2.35 | % |
| Expected life (in years) |  |  | 6.25 |  |  |  | 6.23 |  |

[0001564590-18-003019:notes:124]
We based our estimate of expected volatility for the years ended December 31, 2016 and 2015 on the sequential historical daily trading data of our common stock for a period equal to the expected life of the options granted. The selection of the historical volatility method was based on available data indicating our historical volatility is as equally representative of our future stock price trends as is our implied volatility. We have no reason to believe the future volatility of our stock price is likely to differ from its past volatility. The risk-free interest rate assumption is based upon implied yields of U.S. Treasury zero-coupon bonds on the date of grant having a remaining term equal to the expected life of the options granted. The dividend yield is based on our historical and expected dividend payouts. The expected life of our stock options is based upon historical exercise and forfeiture activity of our previous stock-based grants with a ten-year contractual term.

[0001564590-18-003019:notes:125]
The PSU pricing model also requires the use of several significant assumptions that impact the fair value estimate. The estimated fair value of the PSUs granted to employees during the years ended December 31, 2017, 2016 and 2015 was $24.17 per share, $23.50 per share and $17.64 per share, respectively, with the following assumptions:

[0001564590-18-003019:notes:126]
|  |  | 2017 |  |  | 2016 |  |  | 2015 |  |
| Expected volatility |  |  | 27.03 | % |  |  | 29.79 | % |  |  | 31.34 | % |
| Risk-free interest rate |  |  | 1.78 | % |  |  | 1.17 | % |  |  | 1.20 | % |
| Expected dividend yield |  |  | 1.74 | % |  |  | 1.80 | % |  |  | 2.35 | % |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001564590-18-003019:notes:127]
Note 4 – Investments

[0001564590-18-003019:notes:128]
At December 31, 2017, we held the following securities and investments, recorded at either fair value or cost:

[0001564590-18-003019:notes:129]
|  |  |  |  |  |  |  |  |  |  |  |  |  |  | Fair Value / |  |
|  |  | Amortized |  |  | Gross Unrealized |  |  | Carrying |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Deferred compensation plan assets |  | $ | 17,804 |  |  | $ | 2,175 |  |  | $ | (96 | ) |  | $ | 19,883 |  |
| Corporate bonds |  |  | 32,654 |  |  |  | 44 |  |  |  | (155 | ) |  |  | 32,543 |  |
| Municipal fixed-rate bonds |  |  | 2,902 |  |  |  | 2 |  |  |  | (22 | ) |  |  | 2,882 |  |
| Asset-backed bonds |  |  | 6,545 |  |  |  | 1 |  |  |  | (20 | ) |  |  | 6,526 |  |
| Mortgage/Agency-backed bonds |  |  | 5,554 |  |  |  | 1 |  |  |  | (46 | ) |  |  | 5,509 |  |
| U.S. government bonds |  |  | 14,477 |  |  |  | — |  |  |  | (174 | ) |  |  | 14,303 |  |
| Foreign government bonds |  |  | 725 |  |  |  | 5 |  |  |  | — |  |  |  | 730 |  |
| Marketable equity securities |  |  | 33,478 |  |  |  | 3,034 |  |  |  | (850 | ) |  |  | 35,662 |  |
| Available-for-sale securities held at fair value |  | $ | 114,139 |  |  | $ | 5,262 |  |  | $ | (1,363 | ) |  | $ | 118,038 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 27,800 |  |
| Other investments |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 547 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 146,385 |  |

[0001564590-18-003019:notes:130]
At December 31, 2016, we held the following securities and investments, recorded at either fair value or cost:

[0001564590-18-003019:notes:131]
|  |  |  |  |  |  |  |  |  |  |  |  |  |  | Fair Value / |  |
|  |  | Amortized |  |  | Gross Unrealized |  |  | Carrying |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Deferred compensation plan assets |  | $ | 12,367 |  |  | $ | 2,271 |  |  | $ | (42 | ) |  | $ | 14,596 |  |
| Corporate bonds |  |  | 66,522 |  |  |  | 64 |  |  |  | (174 | ) |  |  | 66,412 |  |
| Municipal fixed-rate bonds |  |  | 11,799 |  |  |  | 12 |  |  |  | (37 | ) |  |  | 11,774 |  |
| Asset-backed bonds |  |  | 10,201 |  |  |  | 19 |  |  |  | (14 | ) |  |  | 10,206 |  |
| Mortgage/Agency-backed bonds |  |  | 13,080 |  |  |  | 15 |  |  |  | (91 | ) |  |  | 13,004 |  |
| U.S. government bonds |  |  | 30,022 |  |  |  | 15 |  |  |  | (270 | ) |  |  | 29,767 |  |
| Foreign government bonds |  |  | 3,729 |  |  |  | 2 |  |  |  | (1 | ) |  |  | 3,730 |  |
| Variable rate demand notes |  |  | 11,855 |  |  |  | — |  |  |  | — |  |  |  | 11,855 |  |
| Marketable equity securities |  |  | 30,571 |  |  |  | 311 |  |  |  | (1,503 | ) |  |  | 29,379 |  |
| Available-for-sale securities held at fair value |  | $ | 190,146 |  |  | $ | 2,709 |  |  | $ | (2,132 | ) |  | $ | 190,723 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 27,800 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 767 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 219,290 |  |

[0001564590-18-003019:notes:132]
As of December 31, 2017, corporate bonds, municipal fixed-rate bonds, asset-backed bonds, mortgage/agency-backed bonds, U.S. government bonds, and foreign government bonds had the following contractual maturities:

[0001564590-18-003019:notes:133]
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset-backed bonds |  |  | Mortgage / Agency-backed bonds |  |  | U.S. government bonds |  |  | Foreign government bonds |  |
| Less than one year |  | $ | 12,021 |  |  | $ | 891 |  |  | $ | 143 |  |  | $ | — |  |  | $ | 3,073 |  |  | $ | — |  |
| One to two years |  |  | 9,145 |  |  |  | 826 |  |  |  | 2,367 |  |  |  | — |  |  |  | 5,960 |  |  |  | — |  |
| Two to three years |  |  | 7,345 |  |  |  | 212 |  |  |  | 2,245 |  |  |  | — |  |  |  | 3,568 |  |  |  | 730 |  |
| Three to five years |  |  | 4,032 |  |  |  | 953 |  |  |  | 810 |  |  |  | 356 |  |  |  | 1,702 |  |  |  | — |  |
| Five to ten years |  |  | — |  |  |  | — |  |  |  | 158 |  |  |  | 1,144 |  |  |  | — |  |  |  | — |  |
| More than ten years |  |  | — |  |  |  | — |  |  |  | 803 |  |  |  | 4,009 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 32,543 |  |  | $ | 2,882 |  |  | $ | 6,526 |  |  | $ | 5,509 |  |  | $ | 14,303 |  |  | $ | 730 |  |

[0001564590-18-003019:notes:134]
Our investment policy provides limitations for issuer concentration, which limits, at the time of purchase, the concentration in any one issuer to 5% of the market value of our total investment portfolio.

[0001564590-18-003019:notes:135]
We review our investment portfolio for potential “other-than-temporary” declines in value on an individual investment basis. We assess, on a quarterly basis, significant declines in value which may be considered other-than-temporary and, if necessary, recognize and record the appropriate charge to write-down the carrying value of such investments. In making this assessment, we take into consideration qualitative and quantitative information, including but not limited to the following: the magnitude and duration of historical declines in market prices, credit rating activity, assessments of liquidity, public filings, and statements made by the issuer. We generally begin our identification of potential other-than-temporary impairments by reviewing any security with a fair value that has declined from its original or adjusted cost basis by 25% or more for six or more consecutive months. We then evaluate the individual security based on the previously identified factors to determine the amount of the write-down, if any. For each of the years ended December 31, 2017, 2016 and 2015, we recorded a charge of $0.2 million, $0.8 million and $0.2 million, respectively, related to the other-than-temporary impairment of certain marketable equity securities and our deferred compensation plan assets.

[0001564590-18-003019:notes:136]
Realized gains and losses on sales of securities are computed under the specific identification method. The following table presents gross realized gains and losses related to our investments for the years ended December 31, 2017, 2016 and 2015:

[0001564590-18-003019:notes:137]
| Year Ended December 31, (In thousands) |  | 2017 |  |  | 2016 |  |  | 2015 |  |
| Gross realized gains |  | $ | 5,258 |  |  | $ | 7,530 |  |  | $ | 10,906 |  |
| Gross realized losses |  | $ | (573 | ) |  | $ | (1,607 | ) |  | $ | (569 | ) |

[0001564590-18-003019:notes:138]
The following table presents the breakdown of investments with unrealized losses at December 31, 2017:

[0001564590-18-003019:notes:139]
| (In thousands) |  | Continuous Unrealized Loss Position for Less than 12 Months |  |  | Continuous Unrealized Loss Position for 12 Months or Greater |  |  | Total |  |
|  |  | Fair Value |  |  | Unrealized Losses |  |  | Fair Value |  |  | Unrealized Losses |  |  | Fair Value |  |  | Unrealized Losses |  |
| Deferred compensation plan assets |  | $ | 1,922 |  |  | $ | (81 | ) |  | $ | 262 |  |  | $ | (15 | ) |  | $ | 2,184 |  |  | $ | (96 | ) |
| Corporate bonds |  |  | 16,015 |  |  |  | (58 | ) |  |  | 6,112 |  |  |  | (97 | ) |  |  | 22,127 |  |  |  | (155 | ) |
| Municipal fixed-rate bonds |  |  | 230 |  |  |  | — |  |  |  | 1,165 |  |  |  | (22 | ) |  |  | 1,395 |  |  |  | (22 | ) |
| Asset-backed bonds |  |  | 4,941 |  |  |  | (17 | ) |  |  | 179 |  |  |  | (3 | ) |  |  | 5,120 |  |  |  | (20 | ) |
| Mortgage/Agency-backed bonds |  |  | 3,062 |  |  |  | (8 | ) |  |  | 1,673 |  |  |  | (38 | ) |  |  | 4,735 |  |  |  | (46 | ) |
| U.S. government bonds |  |  | 2,754 |  |  |  | (26 | ) |  |  | 11,549 |  |  |  | (148 | ) |  |  | 14,303 |  |  |  | (174 | ) |
| Marketable equity securities |  |  | 10,169 |  |  |  | (712 | ) |  |  | 544 |  |  |  | (138 | ) |  |  | 10,713 |  |  |  | (850 | ) |
| Total |  | $ | 39,093 |  |  | $ | (902 | ) |  | $ | 21,484 |  |  | $ | (461 | ) |  | $ | 60,577 |  |  | $ | (1,363 | ) |

[0001564590-18-003019:notes:140]
The following table presents the breakdown of investments with unrealized losses at December 31, 2016:

[0001564590-18-003019:notes:141]
| (In thousands) |  | Continuous Unrealized Loss Position for Less than 12 Months |  |  | Continuous Unrealized Loss Position for 12 Months or Greater |  |  | Total |  |
|  |  | Fair Value |  |  | Unrealized Losses |  |  | Fair Value |  |  | Unrealized Losses |  |  | Fair Value |  |  | Unrealized Losses |  |
| Deferred compensation plan assets |  | $ | 294 |  |  | $ | (12 | ) |  | $ | 245 |  |  | $ | (30 | ) |  | $ | 539 |  |  | $ | (42 | ) |
| Corporate bonds |  |  | 32,562 |  |  |  | (166 | ) |  |  | 2,722 |  |  |  | (8 | ) |  |  | 35,284 |  |  |  | (174 | ) |
| Municipal fixed-rate bonds |  |  | 8,936 |  |  |  | (37 | ) |  |  | — |  |  |  | — |  |  |  | 8,936 |  |  |  | (37 | ) |
| Asset-backed bonds |  |  | 2,986 |  |  |  | (14 | ) |  |  | — |  |  |  | — |  |  |  | 2,986 |  |  |  | (14 | ) |
| Mortgage/Agency-backed bonds |  |  | 7,842 |  |  |  | (81 | ) |  |  | 1,239 |  |  |  | (10 | ) |  |  | 9,081 |  |  |  | (91 | ) |
| U.S. government bonds |  |  | 26,449 |  |  |  | (270 | ) |  |  | — |  |  |  | — |  |  |  | 26,449 |  |  |  | (270 | ) |
| Foreign government bonds |  |  | 924 |  |  |  | (1 | ) |  |  | — |  |  |  | — |  |  |  | 924 |  |  |  | (1 | ) |
| Marketable equity securities |  |  | 21,607 |  |  |  | (1,200 | ) |  |  | 1,495 |  |  |  | (303 | ) |  |  | 23,102 |  |  |  | (1,503 | ) |
| Total |  | $ | 101,600 |  |  | $ | (1,781 | ) |  | $ | 5,701 |  |  | $ | (351 | ) |  | $ | 107,301 |  |  | $ | (2,132 | ) |

[0001564590-18-003019:notes:142]
The decrease in unrealized losses during 2017, as reflected in the table above, results from changes in market positions associated with our fixed income and equity investment portfolio. At December 31, 2017, a total of 274 of our marketable equity securities were in an unrealized loss position.

[0001564590-18-003019:notes:143]
We have categorized our cash equivalents and our investments held at fair value into a three-level fair value hierarchy based on the priority of the inputs to the valuation technique for the cash equivalents and investments as follows: Level 1 - Values based on unadjusted quoted prices for identical assets or liabilities in an active market; Level 2 - Values based on quoted prices in markets that are not active or model inputs that are observable either directly or indirectly; Level 3 - Values based on prices or valuation techniques that require inputs that are both unobservable and significant to the overall fair value measurement. These inputs could include information supplied by investees.

[0001564590-18-003019:notes:144]
|  |  | Fair Value Measurements at December 31, 2017 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 5,851 |  |  | $ | 5,851 |  |  | $ | — |  |  | $ | — |  |
| Commercial paper |  |  | 3,999 |  |  |  | — |  |  |  | 3,999 |  |  |  | — |  |
| Cash equivalents |  |  | 9,850 |  |  |  | 5,851 |  |  |  | 3,999 |  |  |  | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 19,883 |  |  |  | 19,883 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 32,543 |  |  |  | — |  |  |  | 32,543 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 2,882 |  |  |  | — |  |  |  | 2,882 |  |  |  | — |  |
| Asset-backed bonds |  |  | 6,526 |  |  |  | — |  |  |  | 6,526 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 5,509 |  |  |  | — |  |  |  | 5,509 |  |  |  | — |  |
| U.S. government bonds |  |  | 14,303 |  |  |  | 14,303 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 730 |  |  |  | — |  |  |  | 730 |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 35,662 |  |  |  | 35,662 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 118,038 |  |  |  | 69,848 |  |  |  | 48,190 |  |  |  | — |  |
| Total |  | $ | 127,888 |  |  | $ | 75,699 |  |  | $ | 52,189 |  |  | $ | — |  |

[0001564590-18-003019:notes:145]
|  |  | Fair Value Measurements at December 31, 2016 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 6,878 |  |  | $ | 6,878 |  |  | $ | — |  |  | $ | — |  |
| Commercial paper |  |  | 17,222 |  |  |  | — |  |  |  | 17,222 |  |  |  | — |  |
| Cash equivalents |  |  | 24,100 |  |  |  | 6,878 |  |  |  | 17,222 |  |  |  | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 14,596 |  |  |  | 14,596 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 66,412 |  |  |  | — |  |  |  | 66,412 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 11,774 |  |  |  | — |  |  |  | 11,774 |  |  |  | — |  |
| Asset-backed bonds |  |  | 10,206 |  |  |  | — |  |  |  | 10,206 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 13,004 |  |  |  | — |  |  |  | 13,004 |  |  |  | — |  |
| U.S. government bonds |  |  | 29,767 |  |  |  | 29,767 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 3,730 |  |  |  | — |  |  |  | 3,730 |  |  |  | — |  |
| Variable rate demand notes |  |  | 11,855 |  |  |  | — |  |  |  | 11,855 |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 29,379 |  |  |  | 29,379 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 190,723 |  |  |  | 73,742 |  |  |  | 116,981 |  |  |  | — |  |
| Total |  | $ | 214,823 |  |  | $ | 80,620 |  |  | $ | 134,203 |  |  | $ | — |  |

[0001564590-18-003019:notes:146]
The fair value of our Level 2 securities is calculated using a weighted average market price for each security. Market prices are obtained from a variety of industry standard data providers, security master files from large financial institutions, and other third-party sources. These multiple market prices are used as inputs into a distribution-curve-based algorithm to determine the daily market value of each security.

[0001564590-18-003019:notes:147]
Our municipal variable rate demand notes have a structure that implies a standard expected market price. The frequent interest rate resets make it reasonable to expect the price to stay at par. These securities are priced at the expected market price.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001564590-18-003019:notes:148]
Note 5 – Derivative Instruments and Hedging Activities

[0001564590-18-003019:notes:149]
We participate in foreign exchange forward contracts in connection with the management of exposure to fluctuations in foreign exchange rates.

[0001564590-18-003019:notes:150]
Cash Flow Hedges

[0001564590-18-003019:notes:151]
Our cash flow hedging activities utilize foreign exchange forward contracts to reduce the risk that movements in exchange rates will adversely affect the net cash flows resulting from the planned purchase of products from foreign suppliers. Purchases of U.S. denominated inventory by our European subsidiary represent our primary exposure. Changes in the fair value of derivatives designated as cash flow hedges are not recognized in current operating results, but are recorded in accumulated other comprehensive income. Amounts related to cash flow hedges are reclassified from accumulated other comprehensive income when the underlying hedged item impacts earnings. This reclassification is recorded in the same line item of the consolidated statements of income as where the effects of the hedged item are recorded, which is cost of sales.

[0001564590-18-003019:notes:152]
Undesignated Hedges

[0001564590-18-003019:notes:153]
We have certain customers and suppliers who are invoiced or pay in a non-functional currency. Changes in the monetary exchange rates may adversely affect our results of operations and financial condition, as outstanding non-functional balances are revalued to the functional currency through profit and loss. When appropriate, we utilize foreign exchange forward contracts to help manage the volatility relating to these valuation exposures. All changes in the fair value of our derivative instruments that do not qualify for or are not designated for hedged accounting transactions are recognized as other income (expense) in the Consolidated Statements of Income.

[0001564590-18-003019:notes:154]
We do not hold or issue derivative instruments for trading or other speculative purposes. Our derivative instruments are recorded in the Consolidated Balance Sheets at their fair values. Our derivative instruments are not subject to master netting agreements and are not offset in the Consolidated Balance Sheets. As of December 31, 2017, we had no forward contracts outstanding.

[0001564590-18-003019:notes:155]
The fair values of our derivative instruments recorded in the Consolidated Balance Sheet as of December 31, 2017 and 2016 were as follows:

[0001564590-18-003019:notes:156]
| (In thousands) |  | Balance Sheet Location |  | 2017 |  |  | 2016 |  |
| Derivatives Not Designated as Hedging Instruments (Level 2): |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts – derivative assets |  | Other receivables |  | $ | — |  |  | $ | 159 |  |

[0001564590-18-003019:notes:157]
The change in the fair values of our derivative instruments recorded in the Consolidated Statements of Income during the years ended December 31, 2017, 2016 and 2015 were as follows:

[0001564590-18-003019:notes:158]
| (In thousands) |  | Income Statement Location |  | 2017 |  |  | 2016 |  |  | 2015 |  |
| Derivatives Not Designated as Hedging Instruments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Other income (expense) |  | $ | (754 | ) |  | $ | 724 |  |  | $ | 511 |  |

[0001564590-18-003019:notes:159]
The change in our derivatives designated as hedging instruments recorded in other comprehensive income (OCI) and reclassified to income, net of tax, during the twelve months ended December 31, 2017, 2016 and 2015 were as follows:

[0001564590-18-003019:notes:160]
|  |  | Amount of Gains (Losses) Recognized in |  |  | Location of Gains |  | Amount of Gains (Losses) Reclassified |  |
|  |  | OCI on Derivatives |  |  | (Losses) Reclassified |  | from AOCI into Income |  |
| (In thousands) |  | 2017 |  |  | 2016 |  |  | 2015 |  |  | from AOCI into Income |  | 2017 |  |  | 2016 |  |  | 2015 |  |
| Derivatives Designated as Hedging Instruments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | Cost of Sales |  | $ | (897 | ) |  | $ | — |  |  | $ | — |  |


## us-gaap:InventoryDisclosureTextBlock

[0001564590-18-003019:notes:161]
Note 6 – Inventory

[0001564590-18-003019:notes:162]
At December 31, 2017 and 2016, inventory was comprised of the following:

[0001564590-18-003019:notes:163]
| (In thousands) |  | 2017 |  |  | 2016 |  |
| Raw materials |  | $ | 44,185 |  |  | $ | 40,461 |  |
| Work in process |  |  | 1,939 |  |  |  | 4,003 |  |
| Finished goods |  |  | 76,418 |  |  |  | 60,653 |  |
| Total Inventory, net |  | $ | 122,542 |  |  | $ | 105,117 |  |

[0001564590-18-003019:notes:164]
We establish reserves for estimated excess, obsolete, or unmarketable inventory equal to the difference between the cost of the inventory and the estimated fair value of the inventory based upon assumptions about future demand and market conditions. At December 31, 2017 and 2016, raw materials reserves totaled $15.0 million and $14.6 million, respectively, and finished goods inventory reserves totaled $8.3 million and $10.6 million, respectively.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001564590-18-003019:notes:165]
Note 7 – Property, Plant and Equipment

[0001564590-18-003019:notes:166]
At December 31, 2017 and 2016, property, plant and equipment were comprised of the following:

[0001564590-18-003019:notes:167]
| (In thousands) |  | 2017 |  |  | 2016 |  |
| Land |  | $ | 4,575 |  |  | $ | 4,575 |  |
| Building and land improvements |  |  | 32,470 |  |  |  | 29,229 |  |
| Building |  |  | 68,301 |  |  |  | 68,301 |  |
| Furniture and fixtures |  |  | 19,489 |  |  |  | 18,477 |  |
| Computer hardware and software |  |  | 90,726 |  |  |  | 87,655 |  |
| Engineering and other equipment |  |  | 123,363 |  |  |  | 118,746 |  |
| Total Property, Plant and Equipment |  |  | 338,924 |  |  |  | 326,983 |  |
| Less accumulated depreciation |  |  | (253,845 | ) |  |  | (242,514 | ) |
| Total Property, Plant and Equipment, net |  | $ | 85,079 |  |  | $ | 84,469 |  |

[0001564590-18-003019:notes:168]
Depreciation expense was $12.8 million, $12.0 million and $12.3 million in 2017, 2016, and 2015, respectively.


## us-gaap:LessorSalesTypeLeasesTextBlock

[0001564590-18-003019:notes:169]
Note 8 – Lease Arrangements

[0001564590-18-003019:notes:170]
We are the lessor in sales-type lease arrangements for network equipment, which have terms of 18 months to five years. The net investment in sales-type leases consists of lease receivables less unearned income. Collectability of sales-type leases is evaluated periodically on an individual customer level. At December 31, 2017, we had no allowance for credit losses for our net investment in sales-type leases. As of December 31, 2017 and 2016, the components of the net investment in sales-type leases were as follows:

[0001564590-18-003019:notes:171]
| (In thousands) |  | 2017 |  |  | 2016 |  |
| Current minimum lease payments receivable (included in other receivables) |  | $ | 11,325 |  |  | $ | 2,141 |  |
| Non-current minimum lease payments receivable (included in other assets) |  |  | 2,913 |  |  |  | 2,912 |  |
| Total minimum lease payments receivable |  |  | 14,238 |  |  |  | 5,053 |  |
| Less: Current unearned revenue |  |  | 707 |  |  |  | 841 |  |
| Less: Non-current unearned revenue |  |  | 787 |  |  |  | 1,153 |  |
| Net investment in sales-type leases |  | $ | 12,744 |  |  | $ | 3,059 |  |

[0001564590-18-003019:notes:172]
Future minimum lease payments to be received from sales-type leases at December 31, 2017 are as follows:

[0001564590-18-003019:notes:173]
| (In thousands) |  | Amount |  |
| 2018 |  | $ | 11,211 |  |
| 2019 |  |  | 2,172 |  |
| 2020 |  |  | 592 |  |
| 2021 |  |  | 205 |  |
| 2022 |  |  | 58 |  |
| Total |  | $ | 14,238 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001564590-18-003019:notes:174]
Note 9 – Goodwill and Intangible Assets

[0001564590-18-003019:notes:175]
Goodwill, all of which relates to our acquisition of Bluesocket, Inc., was $3.5 million at December 31, 2017 and 2016,  of which $3.1 million and $0.4 million is allocated to our Network Solutions and Services & Support reportable segments, respectively.

[0001564590-18-003019:notes:176]
We evaluate the carrying value of goodwill during the fourth quarter of each year and between annual evaluations if events occur or circumstances change that would more likely than not reduce the fair value of the reporting unit below its carrying amount. We have elected to first assess the qualitative factors to determine whether it is more likely than not that the fair value of the reporting unit to which the goodwill is assigned is less than its carrying amount as a basis for determining whether it is necessary to perform the two-step impairment test. If we determine that it is more likely than not that its fair value is less than its carrying amount, then the two-step impairment test will be performed. Based on the results of our qualitative assessment in 2017, we concluded that it was not necessary to perform the two-step impairment test. There have been no impairment losses recognized since the acquisition in 2011.

[0001564590-18-003019:notes:177]
Intangible assets are included in other assets in the accompanying Consolidated Balance Sheets. The following table presents our intangible assets as of December 31, 2017 and 2016:

[0001564590-18-003019:notes:178]
| (In thousands) |  | 2017 |  |  | 2016 |  |
|  |  | Gross Value |  |  | Accumulated Amortization |  |  | Net Value |  |  | Gross Value |  |  | Accumulated Amortization |  |  | Net Value |  |
| Customer relationships |  | $ | 7,474 |  |  | $ | (4,283 | ) |  | $ | 3,191 |  |  | $ | 6,899 |  |  | $ | (3,208 | ) |  | $ | 3,691 |  |
| Developed technology |  |  | 5,524 |  |  |  | (4,663 | ) |  |  | 861 |  |  |  | 5,184 |  |  |  | (3,801 | ) |  |  | 1,383 |  |
| Intellectual property |  |  | 2,340 |  |  |  | (2,262 | ) |  |  | 78 |  |  |  | 2,340 |  |  |  | (2,129 | ) |  |  | 211 |  |
| Supply agreement |  |  | 1,400 |  |  |  | (1,400 | ) |  |  | — |  |  |  | 1,400 |  |  |  | (544 | ) |  |  | 856 |  |
| License |  |  | 500 |  |  |  | (500 | ) |  |  | — |  |  |  | 500 |  |  |  | (113 | ) |  |  | 387 |  |
| Patent |  |  | 500 |  |  |  | (89 | ) |  |  | 411 |  |  |  | 500 |  |  |  | (20 | ) |  |  | 480 |  |
| Trade names |  |  | 370 |  |  |  | (335 | ) |  |  | 35 |  |  |  | 370 |  |  |  | (285 | ) |  |  | 85 |  |
| Non-compete |  |  | 200 |  |  |  | (115 | ) |  |  | 85 |  |  |  | 200 |  |  |  | (26 | ) |  |  | 174 |  |
| Total |  | $ | 18,308 |  |  | $ | (13,647 | ) |  | $ | 4,661 |  |  | $ | 17,393 |  |  | $ | (10,126 | ) |  | $ | 7,267 |  |

[0001564590-18-003019:notes:179]
Amortization expense was $2.9 million, $2.5 million and $1.9 million for the years ended December 31, 2017, 2016 and 2015, respectively.

[0001564590-18-003019:notes:180]
As of December 31, 2017, the estimated future amortization expense of intangible assets is as follows:

[0001564590-18-003019:notes:181]
| (In thousands) |  | Amount |  |
| 2018 |  | $ | 1,212 |  |
| 2019 |  |  | 697 |  |
| 2020 |  |  | 659 |  |
| 2021 |  |  | 603 |  |
| 2022 |  |  | 567 |  |
| Thereafter |  |  | 923 |  |
| Total |  | $ | 4,661 |  |


## adtn:IndustrialDevelopmentAuthorityFinancingAndEconomicIncentivesTextBlock

[0001564590-18-003019:notes:182]
Note 10 – Alabama State Industrial Development Authority Financing and Economic Incentives

[0001564590-18-003019:notes:183]
In conjunction with an expansion of our Huntsville, Alabama, facility, we were approved for participation in an incentive program offered by the State of Alabama Industrial Development Authority (the “Authority”). Pursuant to the program, on January 13, 1995, the Authority issued $20.0 million of its taxable revenue bonds and loaned the proceeds from the sale of the bonds to ADTRAN. The bonds were originally purchased by AmSouth Bank of Alabama, Birmingham, Alabama (the “Bank”). Wachovia Bank, N.A., Nashville, Tennessee (formerly First Union National Bank of Tennessee) (the “Bondholder”), which was acquired by Wells Fargo & Company on December 31, 2008, purchased the original bonds from the Bank and made further advances to the Authority, bringing the total amount outstanding to $50.0 million. An Amended and Restated Taxable Revenue Bond (“Amended and Restated Bond”) was issued and the original financing agreement was amended. The Amended and Restated Bond bears interest, payable monthly. The interest rate is 2% per annum. The Amended and Restated Bond matures on January 1, 2020, and is currently outstanding in the aggregate principal amount of $26.7 million. The estimated fair value of the bond using a level 2 valuation technique at December 31, 2017 was approximately $26.7 million, based on a debt security with a comparable interest rate and maturity and a Standard & Poor’s credit rating of AAA. We are required to make payments to the Authority in amounts necessary to pay the interest on the Amended and Restated Bond. Included in long-term investments at December 31, 2017 is $27.8 million which is invested in a restricted certificate of deposit. These funds serve as a collateral deposit against the principal of this bond, and we have the right to set-off the balance of the Bond with the collateral deposit in order to reduce the balance of the indebtedness.

[0001564590-18-003019:notes:184]
In conjunction with this program, we are eligible to receive certain economic incentives from the state of Alabama that reduce the amount of payroll withholdings that we are required to remit to the state for those employment positions that qualify under the program. We realized economic incentives related to payroll withholdings totaling $1.5 million for the year ended December 31, 2017 and $1.3 million for each of the years ended December 31, 2016 and 2015.

[0001564590-18-003019:notes:185]
We made principal payments of $1.1 million for each of the years ended December 31, 2017 and 2016, and anticipate making a principal payment in 2018. At December 31, 2017, $1.1 million of the bond debt was classified as a current liability in accounts payable in the Consolidated Balance Sheets.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-18-003019:notes:186]
Note 11 – Income Taxes

[0001564590-18-003019:notes:187]
A summary of the components of the provision for income taxes for the years ended December 31, 2017, 2016 and 2015 is as follows:

[0001564590-18-003019:notes:188]
| (In thousands) |  | 2017 |  |  | 2016 |  |  | 2015 |  |
| Current |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  | $ | 466 |  |  | $ | 12,733 |  |  | $ | 7,504 |  |
| State |  |  | (150 | ) |  |  | 1,141 |  |  |  | 279 |  |
| International |  |  | 6,458 |  |  |  | 477 |  |  |  | (29 | ) |
| Total Current |  |  | 6,774 |  |  |  | 14,351 |  |  |  | 7,754 |  |
| Deferred |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  |  | 8,024 |  |  |  | 647 |  |  |  | (585 | ) |
| State |  |  | 1,882 |  |  |  | 73 |  |  |  | (66 | ) |
| International |  |  | 4,167 |  |  |  | (3,405 | ) |  |  | (41 | ) |
| Total Deferred |  |  | 14,073 |  |  |  | (2,685 | ) |  |  | (692 | ) |
| Total Provision for Income Taxes |  | $ | 20,847 |  |  | $ | 11,666 |  |  | $ | 7,062 |  |

[0001564590-18-003019:notes:189]
Our effective income tax rate differs from the federal statutory rate due to the following:

[0001564590-18-003019:notes:190]
|  |  | 2017 |  |  | 2016 |  |  | 2015 |  |
| Tax provision computed at the federal statutory rate |  |  | 35.00 | % |  |  | 35.00 | % |  |  | 35.00 | % |
| State income tax provision, net of federal benefit |  |  | 2.17 |  |  |  | 3.93 |  |  |  | 4.86 |  |
| Federal research credits |  |  | (11.88 | ) |  |  | (8.15 | ) |  |  | (12.55 | ) |
| Foreign taxes |  |  | (2.27 | ) |  |  | (0.34 | ) |  |  | 2.10 |  |
| Tax-exempt income |  |  | (0.75 | ) |  |  | (0.53 | ) |  |  | (1.94 | ) |
| State tax incentives |  |  | (2.71 | ) |  |  | (2.77 | ) |  |  | (5.04 | ) |
| Stock-based compensation |  |  | 1.43 |  |  |  | 2.53 |  |  |  | 6.91 |  |
| Domestic production activity deduction |  |  | (1.13 | ) |  |  | (2.23 | ) |  |  | (3.17 | ) |
| Bargain purchase |  |  | — |  |  |  | (2.64 | ) |  |  | — |  |
| Impact of U.S. tax reform |  |  | 26.70 |  |  |  | — |  |  |  | — |  |
| Other, net |  |  | 0.09 |  |  |  | 0.08 |  |  |  | 1.30 |  |
| Effective Tax Rate |  |  | 46.65 | % |  |  | 24.88 | % |  |  | 27.47 | % |

[0001564590-18-003019:notes:191]
Income before provision for income taxes for the years ended December 31, 2017, 2016 and 2015 is as follows:

[0001564590-18-003019:notes:192]
| (In thousands) |  | 2017 |  |  | 2016 |  |  | 2015 |  |
| U.S. entities |  | $ | 26,552 |  |  | $ | 54,077 |  |  | $ | 27,400 |  |
| International entities |  |  | 18,135 |  |  |  | (7,182 | ) |  |  | (1,692 | ) |
| Total |  | $ | 44,687 |  |  | $ | 46,895 |  |  | $ | 25,708 |  |

[0001564590-18-003019:notes:193]
Income before provision for income taxes for international entities reflects income based on statutory transfer pricing agreements. This amount does not correlate to consolidated international revenues, many of which occur from our U.S. entity.

[0001564590-18-003019:notes:194]
Deferred income taxes on the balance sheet result from temporary differences between the amount of assets and liabilities recognized for financial reporting and tax purposes. The principal components of our current and non-current deferred taxes are as follows:

[0001564590-18-003019:notes:195]
| (In thousands) |  | 2017 |  |  | 2016 |  |
| Deferred tax assets |  |  |  |  |  |  |  |  |
| Inventory |  | $ | 7,545 |  |  | $ | 12,020 |  |
| Accrued expenses |  |  | 3,103 |  |  |  | 5,551 |  |
| Investments |  |  | — |  |  |  | 1,062 |  |
| Deferred compensation |  |  | 5,204 |  |  |  | 5,751 |  |
| Stock-based compensation |  |  | 2,988 |  |  |  | 4,724 |  |
| Uncertain tax positions related to state taxes and related interest |  |  | 370 |  |  |  | 762 |  |
| Pensions |  |  | 4,727 |  |  |  | 4,273 |  |
| Foreign losses |  |  | 3,091 |  |  |  | 6,486 |  |
| State losses and credit carry-forwards |  |  | 3,854 |  |  |  | 4,021 |  |
| Federal loss and research carry-forwards |  |  | 3,058 |  |  |  | 5,886 |  |
| Valuation allowance |  |  | (6,006 | ) |  |  | (6,149 | ) |
| Total Deferred Tax Assets |  |  | 27,934 |  |  |  | 44,387 |  |
| Deferred tax liabilities |  |  |  |  |  |  |  |  |
| Property, plant and equipment |  |  | (3,553 | ) |  |  | (4,433 | ) |
| Intellectual property |  |  | (663 | ) |  |  | (1,918 | ) |
| Investments |  |  | (290 | ) |  |  | — |  |
| Total Deferred Tax Liabilities |  |  | (4,506 | ) |  |  | (6,351 | ) |
| Net Deferred Tax Assets |  | $ | 23,428 |  |  | $ | 38,036 |  |

[0001564590-18-003019:notes:196]
At December 31, 2017 and 2016, non-current deferred taxes related to our investments and our defined benefit pension plan reflect deferred taxes on the net unrealized gains on available-for-sale investments and deferred taxes on unrealized losses in our pension plan. The net change in non-current deferred taxes associated with these items, a deferred tax benefit of $1.7 million and $1.5 million in 2017 and 2016, respectively, is recorded as an adjustment to other comprehensive income, presented in the Consolidated Statements of Comprehensive Income.

[0001564590-18-003019:notes:197]
Based upon our results of operations in 2017 and expected profitability in future years in a certain international jurisdiction, we concluded that it is more likely than not certain foreign deferred tax assets will be realized. As of December 31, 2017, the remaining valuation allowance primarily relates to deferred tax assets related to state credit carry-forwards from tax credits in excess of our annual tax liability to an individual state where we do not generate sufficient state income to offset the credit and net operating losses in foreign jurisdictions. We believe it is more likely than not that we will not realize the full benefits of the deferred tax assets arising from these losses and credits, and accordingly, we have provided a valuation allowance against these deferred tax assets. The deferred tax assets for foreign and domestic carry-forwards, unamortized research and development costs, and state credit carry-forwards of $10.0 million will expire between 2018 and 2030. The loss carry-forwards were acquired through acquisitions in 2009 and 2011. We will continue to assess the realization of our deferred tax assets and related valuation allowances. The net change in our valuation allowance from December 31, 2016 to December 31, 2017 was $(0.1) million.

[0001564590-18-003019:notes:198]
As of December 31, 2017 and 2016, respectively, our cash and cash equivalents were $86.4 million and $79.9 million and short-term investments were $16.1 million and $43.2 million, which provided an available short-term liquidity of $102.6 million and $123.1 million. Of these amounts, our foreign subsidiaries held cash of $56.8 million and $42.1 million, respectively, representing approximately 55.4% and 34.2% of available short-term liquidity, which is used to fund on-going liquidity needs of these subsidiaries. We intend to permanently reinvest these funds outside the U.S. and our current business plans do not indicate a need to repatriate to fund domestic operations. However, if these funds were repatriated to the U.S. or used for U.S. operations, certain amounts could be subject to tax. Due to the timing and circumstances of repatriation of such earnings, if any, it is not practical to determine the amount of funds subject to unrecognized deferred tax liability.

[0001564590-18-003019:notes:199]
During 2017 and 2016, we recorded no income tax benefit or expense for stock options exercised as an adjustment to equity. In 2015, we recorded an income tax expense of  $(40) thousand as an adjustment to equity. This is calculated on the difference between the exercise price of stock option exercises and the market price of the underlying common stock upon exercise.

[0001564590-18-003019:notes:200]
The change in the unrecognized income tax benefits for the years ended December 31, 2017, 2016 and 2015 is reconciled below:

[0001564590-18-003019:notes:201]
| (In thousands) |  | 2017 |  |  | 2016 |  |  | 2015 |  |
| Balance at beginning of period |  | $ | 2,226 |  |  | $ | 2,537 |  |  | $ | 3,334 |  |
| Increases for tax position related to: |  |  |  |  |  |  |  |  |  |  |  |  |
| Prior years |  |  | 465 |  |  |  | 95 |  |  |  | — |  |
| Current year |  |  | 285 |  |  |  | 428 |  |  |  | 280 |  |
| Decreases for tax positions related to: |  |  |  |  |  |  |  |  |  |  |  |  |
| Prior years |  |  | (14 | ) |  |  | — |  |  |  | (29 | ) |
| Settlements with taxing authorities |  |  | — |  |  |  | — |  |  |  | (103 | ) |
| Expiration of applicable statute of limitations |  |  | (596 | ) |  |  | (834 | ) |  |  | (945 | ) |
| Balance at end of period |  | $ | 2,366 |  |  | $ | 2,226 |  |  | $ | 2,537 |  |

[0001564590-18-003019:notes:202]
As of December 31, 2017, 2016, and 2015, our total liability for unrecognized tax benefits was $2.4 million, $2.2 million, and $2.5 million, respectively, of which $2.2 million, $1.7 million, and $1.8 million, respectively, would reduce our effective tax rate if we were successful in upholding all of the uncertain positions and recognized the amounts recorded. We classify interest and penalties recognized on the liability for unrecognized tax benefits as income tax expense. As of December 31, 2017, 2016 and 2015, the balances of accrued interest and penalties were $0.8 million, $0.8 million and $0.9 million, respectively.

[0001564590-18-003019:notes:203]
We do not anticipate a single tax position generating a significant increase or decrease in our liability for unrecognized tax benefits within 12 months of this reporting date. We file income tax returns in the U.S. federal and various state jurisdictions and several foreign jurisdictions. We are not currently under audit by the Internal Revenue Service. Generally, we are not subject to changes in income taxes by any taxing jurisdiction for the years prior to 2013.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001564590-18-003019:notes:204]
Note 12 – Employee Benefit Plans

[0001564590-18-003019:notes:205]
Pension Benefit Plan

[0001564590-18-003019:notes:206]
We maintain a defined benefit pension plan covering employees in certain foreign countries.

[0001564590-18-003019:notes:207]
The pension benefit plan obligations and funded status at December 31, 2017 and 2016, are as follows:

[0001564590-18-003019:notes:208]
| (In thousands) |  | 2017 |  |  | 2016 |  |
| Change in projected benefit obligation: |  |  |  |  |  |  |  |  |
| Projected benefit obligation at beginning of period |  | $ | 30,011 |  |  | $ | 26,851 |  |
| Service cost |  |  | 1,260 |  |  |  | 1,211 |  |
| Interest cost |  |  | 607 |  |  |  | 720 |  |
| Actuarial (gain) loss - experience |  |  | 47 |  |  |  | (431 | ) |
| Actuarial (gain) loss - assumptions |  |  | (1,294 | ) |  |  | 2,628 |  |
| Benefit payments |  |  | (80 | ) |  |  | (52 | ) |
| Effects of foreign currency exchange rate changes |  |  | 4,342 |  |  |  | (916 | ) |
| Projected benefit obligation at end of period |  |  | 34,893 |  |  |  | 30,011 |  |
| Change in plan assets: |  |  |  |  |  |  |  |  |
| Fair value of plan assets at beginning of period |  |  | 20,045 |  |  |  | 19,213 |  |
| Actual return on plan assets |  |  | 709 |  |  |  | 1,494 |  |
| Contributions |  |  | 3,001 |  |  |  | — |  |
| Effects of foreign currency exchange rate changes |  |  | 2,869 |  |  |  | (662 | ) |
| Fair value of plan assets at end of period |  |  | 26,624 |  |  |  | 20,045 |  |
| Funded (unfunded) status at end of period |  | $ | (8,269 | ) |  | $ | (9,966 | ) |

[0001564590-18-003019:notes:209]
The accumulated benefit obligation was $32.9 million and $28.7 million at December 31, 2017 and 2016, respectively. The increase in the accumulated benefit obligation is primarily attributable to the weakening U.S. dollar to Euro exchange rate during 2017. The change in actuarial gain (loss) is primarily attributable to an increase in the discount rate used in 2017.

[0001564590-18-003019:notes:210]
The net amounts recognized in the balance sheet for the unfunded pension liability as of December 31, 2017 and 2016 are as follows:

[0001564590-18-003019:notes:211]
| (In thousands) |  | 2017 |  |  | 2016 |  |
| Current liability |  | $ | — |  |  | $ | — |  |
| Non-current liability |  |  | 8,269 |  |  |  | 9,966 |  |
| Total |  | $ | 8,269 |  |  | $ | 9,966 |  |

[0001564590-18-003019:notes:212]
The components of net periodic pension cost and amounts recognized in other comprehensive income for the years ended December 31, 2017, 2016 and 2015 are as follows:

[0001564590-18-003019:notes:213]
| (In thousands) |  | 2017 |  |  | 2016 |  |  | 2015 |  |
| Net periodic benefit cost: |  |  |  |  |  |  |  |  |  |  |  |  |
| Service cost |  | $ | 1,260 |  |  | $ | 1,211 |  |  | $ | 1,314 |  |
| Interest cost |  |  | 607 |  |  |  | 720 |  |  |  | 615 |  |
| Expected return on plan assets |  |  | (1,267 | ) |  |  | (1,057 | ) |  |  | (1,011 | ) |
| Amortization of actuarial losses |  |  | 309 |  |  |  | 175 |  |  |  | 407 |  |
| Net periodic benefit cost |  |  | 909 |  |  |  | 1,049 |  |  |  | 1,325 |  |
| Other changes in plan assets and benefit obligations recognized in other comprehensive income: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net actuarial (gain) loss |  |  | (654 | ) |  |  | 1,782 |  |  |  | (2,303 | ) |
| Amortization of actuarial losses |  |  | (406 | ) |  |  | (156 | ) |  |  | (396 | ) |
| Amount recognized in other comprehensive income |  |  | (1,060 | ) |  |  | 1,626 |  |  |  | (2,699 | ) |
| Total recognized in net periodic benefit cost and other comprehensive income |  | $ | (151 | ) |  | $ | 2,675 |  |  | $ | (1,374 | ) |

[0001564590-18-003019:notes:214]
The amounts recognized in accumulated other comprehensive income as of December 31, 2017 and 2016 are as follows:

[0001564590-18-003019:notes:215]
| (In thousands) |  | 2017 |  |  | 2016 |  |
| Net actuarial loss |  | $ | (5,812 | ) |  | $ | (6,871 | ) |

[0001564590-18-003019:notes:216]
The defined benefit pension plan is accounted for on an actuarial basis, which requires the selection of various assumptions, including an expected rate of return on plan assets and a discount rate. The expected return on our German plan assets that is utilized in determining the benefit obligation and net periodic benefit cost is derived from periodic studies, which include a review of asset allocation strategies, anticipated future long-term performance of individual asset classes, risks using standard deviations and correlations of returns among the asset classes that comprise the plans' asset mix. While the studies give appropriate consideration to recent plan performance and historical returns, the assumptions are primarily long-term, prospective rates of return.

[0001564590-18-003019:notes:217]
Another key assumption in determining net pension expense is the assumed discount rate to be used to discount plan obligations. The discount rate has been derived from the returns of high-quality, corporate bonds denominated in Euro currency with durations close to the duration of our pension obligations.

[0001564590-18-003019:notes:218]
The weighted-average assumptions that were used to determine the net periodic benefit cost for the years ended December 31, 2017, 2016 and 2015 are as follows:

[0001564590-18-003019:notes:219]
|  |  | 2017 |  |  | 2016 |  |  | 2015 |  |
| Discount rates |  |  | 1.90 | % |  |  | 2.64 | % |  |  | 2.20 | % |
| Rate of compensation increase |  |  | 2.00 | % |  |  | 2.00 | % |  |  | 2.25 | % |
| Expected long-term rates of return |  |  | 5.90 | % |  |  | 5.40 | % |  |  | 5.40 | % |

[0001564590-18-003019:notes:220]
The weighted-average assumptions that were used to determine the benefit obligation at December 31, 2017 and 2016:

[0001564590-18-003019:notes:221]
|  |  | 2017 |  |  | 2016 |  |
| Discount rates |  |  | 2.13 | % |  |  | 1.90 | % |
| Rate of compensation increase |  |  | 2.00 | % |  |  | 2.00 | % |

[0001564590-18-003019:notes:222]
Actuarial gains and losses are recorded in accumulated other comprehensive income. To the extent unamortized gains and losses exceed 10% of the higher of the market-related value of assets or the projected benefit obligation, the excess is amortized as a component of net periodic pension cost over the remaining service period of active participants. We estimate that $0.2 million will be amortized from accumulated other comprehensive income into net periodic pension cost in 2018 for the net actuarial loss.

[0001564590-18-003019:notes:223]
We do not anticipate making a contribution to this pension plan in 2018. The following pension benefit payments, which reflect expected future service, as appropriate, are expected to be paid to participants:

[0001564590-18-003019:notes:224]
| (In thousands) |  |  |  |  |
| 2018 |  | $ | 549 |  |
| 2019 |  |  | 772 |  |
| 2020 |  |  | 1,090 |  |
| 2021 |  |  | 1,225 |  |
| 2022 |  |  | 1,315 |  |
| 2023 – 2027 |  |  | 6,301 |  |
| Total |  | $ | 11,252 |  |

[0001564590-18-003019:notes:225]
We have categorized our cash equivalents and our investments held at fair value into a three-level fair value hierarchy based on the priority of the inputs to the valuation technique for the cash equivalents and investments as follows: Level 1 - Values based on unadjusted quoted prices for identical assets or liabilities in an active market; Level 2 - Values based on quoted prices in markets that are not active or model inputs that are observable either directly or indirectly; Level 3 - Values based on prices or valuation techniques that require inputs that are both unobservable and significant to the overall fair value measurement. These inputs include information supplied by investees.

[0001564590-18-003019:notes:226]
|  |  | Fair Value Measurements at December 31, 2017 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash and cash equivalents |  | $ | 3,005 |  |  | $ | 3,005 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Bond funds: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 14,349 |  |  |  | 14,349 |  |  |  | — |  |  |  | — |  |
| Government bonds |  |  | 2,305 |  |  |  | 2,305 |  |  |  | — |  |  |  | — |  |
| Equity funds: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Large cap blend |  |  | 5,758 |  |  |  | 5,758 |  |  |  | — |  |  |  | — |  |
| Large cap value |  |  | 309 |  |  |  | 309 |  |  |  | — |  |  |  | — |  |
| Balanced fund |  |  | 898 |  |  |  | 898 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 23,619 |  |  |  | 23,619 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 26,624 |  |  | $ | 26,624 |  |  | $ | — |  |  | $ | — |  |

[0001564590-18-003019:notes:227]
|  |  | Fair Value Measurements at December 31, 2016 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash and cash equivalents |  | $ | 6 |  |  | $ | 6 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Bond funds: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 12,546 |  |  |  | 12,546 |  |  |  | — |  |  |  | — |  |
| Government bonds |  |  | 2,037 |  |  |  | 2,037 |  |  |  | — |  |  |  | — |  |
| Equity funds: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Large cap blend |  |  | 4,462 |  |  |  | 4,462 |  |  |  | — |  |  |  | — |  |
| Large cap value |  |  | 249 |  |  |  | 249 |  |  |  | — |  |  |  | — |  |
| Balanced fund |  |  | 745 |  |  |  | 745 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 20,039 |  |  |  | 20,039 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 20,045 |  |  | $ | 20,045 |  |  | $ | — |  |  | $ | — |  |

[0001564590-18-003019:notes:228]
Our investment policy includes various guidelines and procedures designed to ensure assets are invested in a manner necessary to meet expected future benefits earned by participants, and consider a broad range of economic conditions. Central to the policy are target allocation ranges by asset class, which is currently 75% for bond funds and 25% for equity funds.

[0001564590-18-003019:notes:229]
The objectives of the target allocations are to maintain investment portfolios that diversify risk through prudent asset allocation parameters, achieve asset returns that meet or exceed the plans’ actuarial assumptions, and achieve asset returns that are competitive with like institutions employing similar investment strategies.

[0001564590-18-003019:notes:230]
The investment policy is periodically reviewed by us and a designated third-party fiduciary for investment matters. The policy is established and administered in a manner that is compliant at all times with applicable government regulations.

[0001564590-18-003019:notes:231]
401(k) Savings Plan

[0001564590-18-003019:notes:232]
We maintain the ADTRAN, Inc. 401(k) Retirement Plan (Savings Plan) for the benefit of our eligible employees. The Savings Plan is intended to qualify under Sections 401(a) and 401(k) of the Internal Revenue Code of 1986, as amended (Code), and is intended to be a “safe harbor” 401(k) plan under Code Section 401(k)(12). The Savings Plan allows employees to save for retirement by contributing part of their compensation to the plan on a tax-deferred basis. The Savings Plan also requires us to contribute a “safe harbor” amount each year. We match up to 4% of employee contributions (100% of an employee’s first 3% of contributions and 50% of their next 2% of contributions), beginning on the employee’s one year anniversary date. In calculating our matching contribution, we only use compensation up to the statutory maximum under the Code ($270 thousand for 2017). All contributions under the Savings Plan are 100% vested. Expenses recorded for employer contributions and plan administration costs for the Savings Plan amounted to approximately $4.6 million, $4.1 million and $4.7 million in 2017, 2016 and 2015, respectively.

[0001564590-18-003019:notes:233]
Deferred Compensation Plans

[0001564590-18-003019:notes:234]
We maintain four deferred compensation programs for certain executive management employees and our Board of Directors.

[0001564590-18-003019:notes:235]
For our executive management employees, the ADTRAN, Inc. Deferred Compensation Program for Employees is offered as a supplement to our tax-qualified 401(k) plan and is available to certain executive management employees who have been designated by our Board of Directors. This deferred compensation plan allows participants to defer all or a portion of certain specified bonuses and up to 25% of remaining cash compensation, and permits us to make matching contributions on a discretionary basis, without the limitations that apply to the 401(k) plan. To date, we have not made any matching contributions under this plan. We also maintain the ADTRAN, Inc. Equity Deferral Program for Employees. Under this plan, participants may elect to defer all or a portion of their vested PSUs to the Plan. Such deferrals shall continue to be held and deemed to be invested in shares of ADTRAN stock unless and until the amounts are distributed or such deferrals are moved to another deemed investment pursuant to an election made by the Participant.

[0001564590-18-003019:notes:236]
For our Board of Directors, we maintain the ADTRAN, Inc. Deferred Compensation Program for Directors. This program allows our Board of Directors to defer all or a portion of monetary remuneration paid to the Director, including, but not limited to, meeting fees and annual retainers. We also maintain the ADTRAN, Inc. Equity Deferral Program for Directors. Under this plan, participants may elect to defer all or a portion of their vested restricted stock awards. Such deferrals shall continue to be held and deemed to be invested in shares of ADTRAN stock unless and until the amounts are distributed or such deferrals are moved to another deemed investment pursuant to an election made by the Director.

[0001564590-18-003019:notes:237]
We have set aside the plan assets for all plans in a rabbi trust (Trust) and all contributions are credited to bookkeeping accounts for the participants. The Trust assets are subject to the claims of our creditors in the event of bankruptcy or insolvency. The assets of the Trust are deemed to be invested in pre-approved mutual funds as directed by each participant, and the participant’s bookkeeping account is credited with the earnings and losses attributable to those investments. Benefits are scheduled to be distributed six months after termination of employment in a single lump sum payment or annual installments paid over a three or ten year term. Distributions will be made on a pro rata basis from each of the hypothetical investments of the Participant’s account in cash. Any whole shares of ADTRAN, Inc. common stock that are distributed will be distributed in-kind.

[0001564590-18-003019:notes:238]
Assets of the Trust are deemed invested in mutual funds that cover an investment spectrum ranging from equities to money market instruments. These mutual funds are publicly quoted and reported at fair value. The fair value of the assets held by the Trust and the amounts payable to the plan participants at December 31, 2017 and 2016 are as follows:

[0001564590-18-003019:notes:239]
| (In thousands) |  | 2017 |  |  | 2016 |  |
| Fair Value of Plan Assets |  |  |  |  |  |  |  |  |
| Long-term Investments |  | $ | 19,883 |  |  | $ | 14,596 |  |
| Total Fair Value of Plan Assets |  | $ | 19,883 |  |  | $ | 14,596 |  |
| Amounts Payable to Plan Participants |  |  |  |  |  |  |  |  |
| Non-current Liabilities |  | $ | 19,883 |  |  | $ | 14,596 |  |
| Total Amounts Payable to Plan Participants |  | $ | 19,883 |  |  | $ | 14,596 |  |

[0001564590-18-003019:notes:240]
Interest and dividend income of the Trust have been included in interest and dividend income in the accompanying 2017, 2016 and 2015 Consolidated Statements of Income. Changes in the fair value of the plan assets held by the Trust have been included in accumulated other comprehensive income in the accompanying 2017 and 2016 Consolidated Balance Sheets. Changes in the fair value of the deferred compensation liability are included as selling, general and administrative expense in the accompanying 2017, 2016 and 2015 Consolidated Statements of Income. Based on the changes in the total fair value of the Trust’s assets, we recorded deferred compensation income (expense) in 2017, 2016 and 2015 of $(2.6) million, $(1.3) million and $0.3 million, respectively.

[0001564590-18-003019:notes:241]
Retiree Medical Coverage

[0001564590-18-003019:notes:242]
We provide medical, dental and prescription drug coverage to one retired former officer and his spouse, for his life, on the same terms as provided to our active officers, and to the spouse of a former deceased officer for up to 30 years. At December 31, 2017 and 2016, this liability totaled $0.1 million and $0.2 million, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-18-003019:notes:243]
Note 13 – Segment Information and Major Customers

[0001564590-18-003019:notes:244]
In 2015, we realigned our organizational structure to better match our market opportunities, technological development initiatives, and improve efficiencies. During the first quarter of 2016, our chief operating decision maker requested changes in the information that he regularly reviews for purposes of allocating resources and assessing performance. As a result, beginning with the quarter ended March 31, 2016, we began reporting our financial performance based on two, new reportable segments – Network Solutions and Services & Support. Network Solutions includes hardware products and next-generation virtualized solutions used in service provider or business networks, as well as prior-generation products. Services & Support includes our suite of ProCloud managed services, network installation, engineering and maintenance services, and fee-based technical support and equipment repair/replacement plans.

[0001564590-18-003019:notes:245]
We evaluate the performance of our new segments based on gross profit; therefore, selling, general and administrative expenses, research and development expenses, interest and dividend income, interest expense, net realized investment gain/loss, other income/expense and provision for taxes are reported on a company-wide, functional basis only. Historical financial information by reportable segment and category, as discussed below, has been recast to conform to our new reporting structure. There are no inter-segment revenues.

[0001564590-18-003019:notes:246]
The following table presents information about the reported sales and gross profit of our reportable segments for each of the years ended December 31, 2017, 2016 and 2015. Asset information by reportable segment is not reported, since we do not produce such information internally.

[0001564590-18-003019:notes:247]
| Sales and Gross Profit by Market Segment |  |  |  |  |  |  |  |  |  |
| (In thousands) |  | 2017 |  |  | 2016 |  |  | 2015 |  |
|  |  | Sales |  |  | Gross Profit |  |  | Sales |  |  | Gross Profit |  |  | Sales |  |  | Gross Profit |  |
| Network Solutions |  | $ | 540,396 |  |  | $ | 260,855 |  |  | $ | 525,502 |  |  | $ | 254,807 |  |  | $ | 527,422 |  |  | $ | 233,579 |  |
| Services & Support |  |  | 126,504 |  |  |  | 42,805 |  |  |  | 111,279 |  |  |  | 36,537 |  |  |  | 72,642 |  |  |  | 33,318 |  |
| Total |  | $ | 666,900 |  |  | $ | 303,660 |  |  | $ | 636,781 |  |  | $ | 291,344 |  |  | $ | 600,064 |  |  | $ | 266,897 |  |

[0001564590-18-003019:notes:248]
Sales by Category

[0001564590-18-003019:notes:249]
In addition to our new reporting segments, we will also report revenue for the following three categories – Access & Aggregation, Customer Devices, and Traditional & Other Products.

[0001564590-18-003019:notes:250]
The following table presents sales information by product category for the years ended December 31, 2017, 2016 and 2015:

[0001564590-18-003019:notes:251]
| (In thousands) |  | 2017 |  |  | 2016 |  |  | 2015 |  |
| Access & Aggregation |  | $ | 473,943 |  |  | $ | 436,372 |  |  | $ | 405,698 |  |
| Customer Devices |  |  | 138,456 |  |  |  | 137,608 |  |  |  | 125,565 |  |
| Traditional & Other Products |  |  | 54,501 |  |  |  | 62,801 |  |  |  | 68,801 |  |
| Total |  | $ | 666,900 |  |  | $ | 636,781 |  |  | $ | 600,064 |  |

[0001564590-18-003019:notes:252]
The following table presents sales information by geographic area for the years ended December 31, 2017, 2016 and 2015. International sales correlate to shipments with a non-U.S. destination.

[0001564590-18-003019:notes:253]
| (In thousands) |  | 2017 |  |  | 2016 |  |  | 2015 |  |
| United States |  | $ | 508,178 |  |  | $ | 501,337 |  |  | $ | 419,366 |  |
| Germany |  |  | 119,502 |  |  |  | 85,780 |  |  |  | 111,666 |  |
| Other international |  |  | 39,220 |  |  |  | 49,664 |  |  |  | 69,032 |  |
| Total |  | $ | 666,900 |  |  | $ | 636,781 |  |  | $ | 600,064 |  |

[0001564590-18-003019:notes:254]
Customers comprising more than 10% of revenue can change from year to year. Single customers comprising more than 10% of our revenue in 2017 included two customers at 40% and 16%. Single customers comprising more than 10% of our revenue in 2016 included three customers at 24%, 19% and 12%. Single customers comprising more than 10% of our revenue in 2015 included three customers at 20%, 17% and 14%. No other customer accounted for 10% or more of our sales in 2017, 2016 or 2015. Our five largest customers, other than those with more than 10 percent of revenues disclosed above, can change from year to year. These customers represented 15%, 13%, and 14% of total revenue in 2017, 2016 and 2015, respectively. Revenues in this disclosure do not include distributor agents, who predominantly provide fulfillment services to end users. In such cases where known, that revenue is associated with the end user.

[0001564590-18-003019:notes:255]
Additional Segment Information

[0001564590-18-003019:notes:256]
As of December 31, 2017, long-lived assets, net totaled $85.1 million, which includes $80.6 million held in the U.S. and $4.5 million held outside the U.S. As of December 31, 2016, long-lived assets, net totaled $84.5 million, which includes $79.9 million held in the U.S. and $4.6 million held outside the U.S.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-18-003019:notes:257]
Note 14 – Commitments and Contingencies

[0001564590-18-003019:notes:258]
In the ordinary course of business, we may be subject to various legal proceedings and claims, including employment disputes, patent claims, disputes over contract agreements and other commercial disputes. In some cases, claimants seek damages or other relief, such as royalty payments related to patents, which, if granted, could require significant expenditures. Although the outcome of any claim or litigation can never be certain, it is our opinion that the outcome of all contingencies of which we are currently aware will not materially affect our business, operations, financial condition or cash flows.

[0001564590-18-003019:notes:259]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, and we have contributed $8.4 million as of December 31, 2017, of which $7.7 million has been applied to these commitments.

[0001564590-18-003019:notes:260]
We lease office space and equipment under operating leases which expire at various dates through 2025. As of December 31, 2017, future minimum rental payments under non-cancelable operating leases with original maturities of greater than 12 months are as follows:

[0001564590-18-003019:notes:261]
| (In thousands) |  |  |  |  |
| 2018 |  | $ | 3,073 |  |
| 2019 |  |  | 927 |  |
| 2020 |  |  | 805 |  |
| 2021 |  |  | 793 |  |
| Thereafter |  |  | 2,907 |  |
| Total |  | $ | 8,505 |  |

[0001564590-18-003019:notes:262]
Rental expense was $4.5 million, $4.2 million and $4.9 million for the years ended December 31, 2017, 2016 and 2015, respectively.


## us-gaap:EarningsPerShareTextBlock

[0001564590-18-003019:notes:263]
Note 15 – Earnings per Share

[0001564590-18-003019:notes:264]
A summary of the calculation of basic and diluted earnings per share (EPS) for the years ended December 31, 2017, 2016 and 2015 is as follows:

[0001564590-18-003019:notes:265]
| (In thousands, except for per share amounts) |  | 2017 |  |  | 2016 |  |  | 2015 |  |
| Numerator |  |  |  |  |  |  |  |  |  |  |  |  |
| Net Income |  | $ | 23,840 |  |  | $ | 35,229 |  |  | $ | 18,646 |  |
| Denominator |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average number of shares – basic |  |  | 48,153 |  |  |  | 48,724 |  |  |  | 51,145 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock options |  |  | 406 |  |  |  | 170 |  |  |  | 81 |  |
| Restricted stock and restricted stock units |  |  | 140 |  |  |  | 55 |  |  |  | 41 |  |
| Weighted average number of shares – diluted |  | $ | 48,699 |  |  | $ | 48,949 |  |  | $ | 51,267 |  |
| Net income per share – basic |  | $ | 0.50 |  |  | $ | 0.72 |  |  | $ | 0.36 |  |
| Net income per share – diluted |  | $ | 0.49 |  |  | $ | 0.72 |  |  | $ | 0.36 |  |

[0001564590-18-003019:notes:266]
For each of the years ended December 31, 2017, 2016 and 2015, 3.2 million, 4.6 million and 6.1 million stock options were outstanding but were not included in the computation of that year’s diluted EPS because the options’ exercise prices were greater than the average market price of the common shares, therefore making them anti-dilutive under the treasury stock method.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001564590-18-003019:notes:267]
Note 16 – Summarized Quarterly Financial Data (Unaudited)

[0001564590-18-003019:notes:268]
The following table presents unaudited quarterly operating results for each of our last eight fiscal quarters. This information has been prepared on a basis consistent with our audited financial statements and includes all adjustments, consisting only of normal recurring adjustments, considered necessary for a fair presentation of the data.

[0001564590-18-003019:notes:269]
Unaudited Quarterly Operating Results

[0001564590-18-003019:notes:270]
(In thousands, except for per share amounts)

[0001564590-18-003019:notes:271]
| Three Months Ended |  | March 31, 2017 |  |  | June 30, 2017 |  |  | September 30, 2017 |  |  | December 31, 2017 |  |
| Net sales |  | $ | 170,279 |  |  | $ | 184,673 |  |  | $ | 185,112 |  |  | $ | 126,836 |  |
| Gross profit |  | $ | 73,715 |  |  | $ | 84,632 |  |  | $ | 86,498 |  |  | $ | 58,815 |  |
| Operating income |  | $ | 7,032 |  |  | $ | 16,448 |  |  | $ | 18,318 |  |  | $ | (4,061 | ) |
| Net income |  | $ | 6,651 |  |  | $ | 12,401 |  |  | $ | 15,898 |  |  | $ | (11,110 | ) |
| Earnings per common share |  | $ | 0.14 |  |  | $ | 0.26 |  |  | $ | 0.33 |  |  | $ | (0.23 | ) |
| Earnings per common share assuming dilution (1) |  | $ | 0.14 |  |  | $ | 0.26 |  |  | $ | 0.33 |  |  | $ | (0.23 | ) |

[0001564590-18-003019:notes:272]
| Three Months Ended |  | March 31, 2016 |  |  | June 30, 2016 |  |  | September 30, 2016 |  |  | December 31, 2016 |  |
| Net sales |  | $ | 142,204 |  |  | $ | 162,701 |  |  | $ | 168,890 |  |  | $ | 162,986 |  |
| Gross profit |  | $ | 65,794 |  |  | $ | 78,955 |  |  | $ | 75,808 |  |  | $ | 70,787 |  |
| Operating income |  | $ | 5,521 |  |  | $ | 14,812 |  |  | $ | 10,130 |  |  | $ | 4,272 |  |
| Net income |  | $ | 5,014 |  |  | $ | 10,228 |  |  | $ | 12,415 |  |  | $ | 7,572 |  |
| Earnings per common share |  | $ | 0.10 |  |  | $ | 0.21 |  |  | $ | 0.26 |  |  | $ | 0.16 |  |
| Earnings per common share assuming dilution (1) |  | $ | 0.10 |  |  | $ | 0.21 |  |  | $ | 0.26 |  |  | $ | 0.16 |  |

[0001564590-18-003019:notes:273]
| (1) | Assumes exercise of dilutive stock options calculated under the treasury stock method. |


## us-gaap:SubsequentEventsTextBlock

[0001564590-18-003019:notes:274]
Note 17 – Subsequent Events

[0001564590-18-003019:notes:275]
On January 16, 2018, the Board declared a quarterly cash dividend of $0.09 per common share to be paid to shareholders of record at the close of business on January 31, 2018. The quarterly dividend payment was $4.4 million and was paid on February 14, 2018. In July 2003, our Board of Directors elected to begin declaring quarterly dividends on our common stock considering the tax treatment of dividends and adequate levels of Company liquidity.

[0001564590-18-003019:notes:276]
During the first quarter and as of February 23, 2018, we have repurchased 0.6 million shares of our common stock through open market purchases at an average cost of $16.18 per share. We currently have the authority to purchase an additional 2.9 million shares of our common stock under the current plan approved by the Board of Directors.

[0001564590-18-003019:notes:277]
In January 2018, we announced an early retirement incentive program for employees that met certain requirements. The estimated liability associated with this program ranges from $3.6 to $14.3 million.


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001564590-18-003019:notes:278]
SCHEDULE II

[0001564590-18-003019:notes:279]
VALUATION AND QUALIFYING ACCOUNTS

[0001564590-18-003019:notes:280]
| Column A |  | Column B |  |  | Column C |  |  | Column D |  |  | Column E |  |
| (In thousands) |  | Balance at Beginning of Period |  |  | Charged to Costs & Expenses |  |  | Deductions |  |  | Balance at End of Period |  |
| Year ended December 31, 2017 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for Doubtful Accounts |  | $ | — |  |  |  | — |  |  |  | — |  |  | $ | — |  |
| Inventory Reserve |  | $ | 25,249 |  |  |  | 6,406 |  |  |  | 8,300 |  |  | $ | 23,355 |  |
| Warranty Liability |  | $ | 8,548 |  |  |  | 6,951 |  |  |  | 5,775 |  |  | $ | 9,724 |  |
| Deferred Tax Asset Valuation Allowance |  | $ | 6,149 |  |  |  | 18 |  |  |  | 161 |  |  | $ | 6,006 |  |
| Year ended December 31, 2016 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for Doubtful Accounts |  | $ | 19 |  |  |  | — |  |  |  | 19 |  |  | $ | — |  |
| Inventory Reserve |  | $ | 26,675 |  |  |  | 3,303 |  |  |  | 4,729 |  |  | $ | 25,249 |  |
| Warranty Liability |  | $ | 8,739 |  |  |  | 8,561 |  |  |  | 8,752 |  |  | $ | 8,548 |  |
| Deferred Tax Asset Valuation Allowance |  | $ | 7,250 |  |  |  | 69 |  |  |  | 1,170 |  |  | $ | 6,149 |  |
| Year ended December 31, 2015 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for Doubtful Accounts |  | $ | 136 |  |  |  | 19 |  |  |  | 136 |  |  | $ | 19 |  |
| Inventory Reserve |  | $ | 24,682 |  |  |  | 2,225 |  |  |  | 232 |  |  | $ | 26,675 |  |
| Warranty Liability |  | $ | 8,415 |  |  |  | 2,998 |  |  |  | 2,674 |  |  | $ | 8,739 |  |
| Deferred Tax Asset Valuation Allowance |  | $ | 7,463 |  |  |  | 81 |  |  |  | 294 |  |  | $ | 7,250 |  |


## adtn:ScheduleOfShareBasedCompensationPerformanceStockUnitsRestrictedStockUnitsAndRestrictedStockActivityTableTextBlock

[0001564590-18-003019:notes:281]
The following table is a summary of our PSUs, RSUs and restricted stock outstanding as of December 31, 2016 and 2017 and the changes that occurred during 2017.
