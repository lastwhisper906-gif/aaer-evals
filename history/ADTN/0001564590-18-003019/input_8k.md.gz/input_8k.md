# ADTN 8-K — 0001564590-18-000519 filed 2018-01-17

## item codes, every 8-K on or before 2018-02-23

- 2018-01-17 0001564590-18-000519 — 2.02, 9.01
- 2017-12-29 0001564590-17-025375 — 2.02, 9.01
- 2017-11-16 0001193125-17-345232 — 5.02
- 2017-10-18 0001564590-17-019582 — 2.02, 9.01
- 2017-07-19 0001564590-17-013609 — 2.02, 9.01
- 2017-05-11 0001564590-17-010459 — 5.02, 9.01
- 2017-05-11 0001564590-17-010452 — 5.07
- 2017-04-19 0001193125-17-127926 — 2.02, 9.01
- 2017-02-07 0001193125-17-032714 — 8.01
- 2017-01-18 0001193125-17-011669 — 2.02, 9.01
- 2016-11-16 0001193125-16-769505 — 5.02, 9.01
- 2016-10-19 0001193125-16-741087 — 2.02, 9.01
- 2016-09-14 0001193125-16-709148 — 8.01, 9.01
- 2016-08-17 0001193125-16-683980 — 5.02, 9.01
- 2016-07-13 0001193125-16-646816 — 2.02, 9.01
- 2016-05-13 0001193125-16-590263 — 5.07
- 2016-04-13 0001193125-16-539019 — 2.02, 9.01
- 2016-04-08 0001193125-16-535035 — 7.01
- 2016-02-11 0001193125-16-459453 — 5.02, 9.01
- 2016-01-20 0001193125-16-432934 — 2.02, 9.01
- 2015-11-16 0001193125-15-378019 — 5.02, 9.01
- 2015-10-14 0001193125-15-343083 — 2.02, 9.01
- 2015-07-16 0001193125-15-254729 — 8.01, 9.01
- 2015-07-15 0001193125-15-253068 — 2.02, 9.01
- 2015-05-15 0001193125-15-189160 — 5.07, 9.01
- 2015-04-22 0001193125-15-140997 — 2.02, 9.01
- 2015-02-23 0001193125-15-056741 — 5.02, 9.01
- 2015-01-21 0001193125-15-015465 — 2.02, 9.01
- 2014-10-15 0001193125-14-372076 — 2.02, 9.01
- 2014-10-03 0001193125-14-363152 — 2.02, 9.01
- 2014-07-16 0001193125-14-269660 — 2.02, 9.01
- 2014-05-20 0001193125-14-205916 — 8.01, 9.01
- 2014-05-20 0001193125-14-205906 — 5.02, 9.01
- 2014-05-15 0001193125-14-201144 — 5.07
- 2014-04-16 0001193125-14-144665 — 2.02, 9.01
- 2014-04-03 0001193125-14-129578 — 2.02, 9.01
- 2014-01-22 0001157523-14-000154 — 2.02, 9.01
- 2013-10-15 0001193125-13-399540 — 5.02
- 2013-10-09 0001157523-13-004657 — 2.02, 9.01
- 2013-07-10 0001157523-13-003290 — 2.02, 9.01
- 2013-05-10 0001193125-13-213728 — 5.07
- 2013-05-03 0001193125-13-198816 — 8.01, 9.01
- 2013-04-10 0001157523-13-001730 — 2.02, 9.01
- 2013-01-16 0001157523-13-000139 — 2.02, 9.01
- 2012-10-10 0001157523-12-005081 — 2.02, 9.01
- 2012-10-03 0001193125-12-413609 — 7.01
- 2012-09-28 0001193125-12-408878 — 2.02, 9.01
- 2012-07-11 0001157523-12-003592 — 2.02, 9.01
- 2012-05-10 0001193125-12-225669 — 5.07
- 2012-05-10 0001193125-12-225639 — 8.01, 9.01
- 2012-04-11 0001157523-12-001772 — 2.02, 9.01
- 2012-03-15 0001193125-12-116494 — 2.02, 9.01
- 2012-01-18 0001157523-12-000174 — 2.02, 9.01
- 2011-12-12 0001193125-11-337271 — 7.01, 9.01
- 2011-10-13 0000950123-11-089785 — 5.03, 9.01
- 2011-10-12 0001157523-11-005682 — 2.02, 9.01
- 2011-07-13 0001157523-11-003986 — 2.02, 9.01
- 2011-05-09 0000950123-11-047191 — 5.02, 5.07, 9.01
- 2011-04-13 0001157523-11-002001 — 2.02, 9.01
- 2011-01-19 0001157523-11-000232 — 2.02, 9.01
- 2010-11-09 0000950123-10-103195 — 5.02, 9.01
- 2010-10-13 0001157523-10-005798 — 2.02, 9.01
- 2010-07-14 0001157523-10-004011 — 2.02, 9.01
- 2010-05-28 0000950123-10-053947 — 5.07
- 2010-04-14 0001157523-10-002022 — 2.02, 9.01
- 2010-01-20 0001157523-10-000200 — 2.02, 9.01
- 2009-10-28 0000950123-09-053984 — 8.01
- 2009-10-14 0001157523-09-006877 — 2.02, 9.01
- 2009-07-15 0001157523-09-004878 — 2.02, 9.01
- 2009-04-15 0001157523-09-002687 — 2.02, 9.01
- 2009-01-21 0001157523-09-000340 — 2.02, 9.01
- 2008-11-12 0001193125-08-233181 — 5.02, 9.01
- 2008-10-14 0001157523-08-007999 — 2.02, 9.01
- 2008-07-15 0001157523-08-005504 — 2.02, 9.01
- 2008-04-15 0001157523-08-002896 — 2.02, 9.01
- 2008-01-22 0001157523-08-000408 — 2.02, 9.01
- 2007-10-16 0001193125-07-219356 — 5.03, 9.01
- 2007-10-16 0001157523-07-009850 — 2.02, 9.01
- 2007-07-17 0001157523-07-006912 — 2.02, 9.01
- 2007-04-17 0001157523-07-003630 — 2.02, 9.01
- 2007-04-03 0001179022-07-000068 — 5.02
- 2007-03-28 0001179022-07-000064 — 5.02
- 2007-02-23 0001193125-07-038337 — 5.02
- 2007-02-23 0001193125-07-038335 — 5.02
- 2007-01-30 0001193125-07-015912 — 5.02, 9.01
- 2007-01-26 0001193125-07-014234 — 5.02
- 2007-01-23 0001157523-07-000494 — 2.02, 9.01 — amendment of 0001157523-07-000481
- 2007-01-23 0001157523-07-000481 — 2.02, 9.01
- 2006-10-17 0001157523-06-009945 — 2.02, 9.01
- 2006-07-18 0001157523-06-006929 — 2.02, 9.01
- 2006-06-08 0001193125-06-126486 — 1.01, 9.01
- 2006-05-10 0001193125-06-107316 — 1.01, 9.01
- 2006-04-18 0001157523-06-003699 — 2.02, 9.01
- 2006-02-03 0001179022-06-000014 — 1.01
- 2006-01-27 0001157523-06-000754 — 5.02, 9.01
- 2006-01-24 0001157523-06-000551 — 2.02, 9.01
- 2005-10-18 0001157523-05-008826 — 2.02, 9.01
- 2005-07-19 0001193125-05-143958 — 1.01, 5.02, 9.01
- 2005-07-19 0001193125-05-143957 — 2.02, 9.01
- 2005-05-20 0001193125-05-112019 — 1.01, 9.01
- 2005-04-19 0001157523-05-003418 — 2.02, 9.01
- 2005-01-25 0001193125-05-010721 — 2.02, 9.01
- 2004-10-12 0001193125-04-169652 — 2.02, 9.01
- 2004-07-13 0001193125-04-116820 — 12, 7
- 2004-04-14 0001193125-04-061547 — 12, 7
- 2004-01-21 0001193125-04-006366 — 12, 7
- 2003-10-14 0001193125-03-061018 — 12, 5, 7
- 2003-07-15 0001193125-03-019292 — 7, 9
- 2003-04-15 0000931763-03-000968 — 7, 9
- 1996-09-12 0000931763-96-000667 — 5, 7

## late-filing notifications on or before 2018-02-23

- none on or before 2018-02-23

## item 2.02 — earnings release, exhibit 99.1

[0001564590-18-000519:8k_2_02:1]
EX-99.1
2
adtn-ex991_14.htm
EX-99.1

[0001564590-18-000519:8k_2_02:2]
adtn-ex991_14.htm

[0001564590-18-000519:8k_2_02:3]
EXHIBIT 99.1

[0001564590-18-000519:8k_2_02:4]
ADTRAN, Inc. Reports Earnings for the Fourth Quarter 2017 and Declares Quarterly Cash Dividend

[0001564590-18-000519:8k_2_02:5]
HUNTSVILLE, Ala.--(BUSINESS WIRE)—January 16, 2018-- ADTRAN, Inc. (NASDAQ:ADTN) reported results for the fourth quarter 2017. For the quarter, sales were $126.5 million compared to $163.0 million for the fourth quarter of 2016. Net income was a loss of $11.1 million compared to income of $7.6 million for the fourth quarter of 2016. Earnings per share, assuming dilution, were a loss of $0.23 compared to income of $0.16 for the fourth quarter of 2016. Non-GAAP earnings per share were $0.05 compared to $0.21 for the fourth quarter of 2016. GAAP results for the fourth quarter 2017 reflect the impact of the Tax Cuts and Jobs Act that resulted in a charge to tax expense of $11.9 million, which has been excluded from non-GAAP earnings. The reconciliation between GAAP earnings per share, diluted, and non-GAAP earnings per share, diluted, is in the table provided.

[0001564590-18-000519:8k_2_02:6]
ADTRAN Chairman and Chief Executive Officer Tom Stanton stated, “As we previously disclosed, our results for the quarter were negatively affected by a merger-related review and spending slowdown by a domestic Tier 1 customer. While this disruption continues to impact our business, our overall expectations regarding our domestic and international programs and opportunities remain positive. The company’s engagement with leading service providers across the globe is extremely strong, with high interest and acceptance of our next-generation Software Defined Access solutions. ADTRAN is well positioned to help our carrier and MSO customers successfully manage the transition to a fully realized Gigabit and beyond marketplace by providing the industry’s most innovative and complete portfolio of transformative SD-Access solutions so that any subscriber, in any market, can realize the full potential of the network.”

[0001564590-18-000519:8k_2_02:7]
The Company also announced that its Board of Directors declared a cash dividend for the fourth quarter of 2017. The quarterly cash dividend is $0.09 per common share to be paid to holders of record at the close of business on January 31, 2018. The ex-dividend date is January 30, 2018, and the payment date is February 14, 2018.

[0001564590-18-000519:8k_2_02:8]
The Company confirmed that its fourth quarter conference call will be held Wednesday, January 17, 2018, at 9:30 a.m. Central Time. ADTRAN will webcast this conference. To listen, simply visit the Investor Relations site at www.investors.adtran.com approximately 10 minutes prior to the start of the call and click on the conference call link provided.

[0001564590-18-000519:8k_2_02:9]
An online replay of the conference call, as well as the text of the Company's earnings release, will be available on the Investor Relations site approximately 24 hours following the call and will remain available for at least 12 months.

[0001564590-18-000519:8k_2_02:10]
ADTRAN, Inc. is a leading global provider of networking and communications equipment. ADTRAN’s products enable voice, data, video and Internet communications across a variety of network infrastructures. ADTRAN solutions are currently in use by service providers, private enterprises, government organizations, and millions of individual users worldwide. For more information, please visit www.adtran.com.

[0001564590-18-000519:8k_2_02:11]
For more information, contact the company at 800 9ADTRAN (800 923-8726) or via email at investor.relations@adtran.com. On the Web, visit www.adtran.com.

[0001564590-18-000519:8k_2_02:12]
This press release contains forward-looking statements which reflect management’s best judgment based on factors currently known. However, these statements involve risks and uncertainties, including the successful development and market acceptance of new products, the degree of competition in the market for such products, the product and channel mix, component costs, manufacturing efficiencies, and other risks detailed in our annual report on Form 10-K for the year ended December 31, 2016. These risks and uncertainties could cause actual results to differ materially from those in the forward-looking statements included in this press release.

[0001564590-18-000519:8k_2_02:13]
Condensed Consolidated Balance Sheet

[0001564590-18-000519:8k_2_02:14]
(Unaudited)

[0001564590-18-000519:8k_2_02:15]
(In thousands)

[0001564590-18-000519:8k_2_02:16]
|  | December 31, |  |  | December 31, |  |
|  | 2017 |  |  | 2016 |  |
| Assets |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 86,433 |  |  | $ | 79,895 |  |
| Short-term investments |  | 16,129 |  |  |  | 43,188 |  |
| Accounts receivable, net |  | 143,835 |  |  |  | 92,346 |  |
| Other receivables |  | 22,746 |  |  |  | 15,137 |  |
| Income tax receivable, net |  | — |  |  |  | 760 |  |
| Inventory, net |  | 122,542 |  |  |  | 105,117 |  |
| Prepaid expenses and other current assets |  | 17,455 |  |  |  | 16,459 |  |
| Total Current Assets |  | 409,140 |  |  |  | 352,902 |  |
| Property, plant and equipment, net |  | 85,079 |  |  |  | 84,469 |  |
| Deferred tax assets, net |  | 23,318 |  |  |  | 38,036 |  |
| Goodwill |  | 3,492 |  |  |  | 3,492 |  |
| Other assets |  | 13,725 |  |  |  | 12,234 |  |
| Long-term investments |  | 130,256 |  |  |  | 176,102 |  |
| Total Assets | $ | 665,010 |  |  | $ | 667,235 |  |
| Liabilities and Stockholders' Equity |  |  |  |  |  |  |  |
| Accounts payable | $ | 60,495 |  |  | $ | 77,342 |  |
| Unearned revenue |  | 13,070 |  |  |  | 16,326 |  |
| Accrued expenses |  | 13,232 |  |  |  | 12,434 |  |
| Accrued wages and benefits |  | 15,948 |  |  |  | 20,433 |  |
| Income tax payable, net |  | 104 |  |  |  | — |  |
| Total Current Liabilities |  | 102,849 |  |  |  | 126,535 |  |
| Non-current unearned revenue |  | 4,556 |  |  |  | 6,333 |  |
| Other non-current liabilities |  | 33,854 |  |  |  | 28,050 |  |
| Bonds payable |  | 25,600 |  |  |  | 26,800 |  |
| Total Liabilities |  | 166,859 |  |  |  | 187,718 |  |
| Stockholders' Equity |  | 498,151 |  |  |  | 479,517 |  |
| Total Liabilities and Stockholders' Equity | $ | 665,010 |  |  | $ | 667,235 |  |

[0001564590-18-000519:8k_2_02:17]
Consolidated Statements of Income

[0001564590-18-000519:8k_2_02:18]
(Unaudited)

[0001564590-18-000519:8k_2_02:19]
(In thousands, except per share data)

[0001564590-18-000519:8k_2_02:20]
|  |  | Three Months Ended |  |  | Twelve Months Ended |  |
|  |  | December 31, |  |  | December 31, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  | $ | 96,058 |  |  | $ | 126,793 |  |  | $ | 540,665 |  |  | $ | 525,502 |  |
| Services |  |  | 30,461 |  |  |  | 36,193 |  |  |  | 125,918 |  |  |  | 111,279 |  |
| Total Sales |  |  | 126,519 |  |  |  | 162,986 |  |  |  | 666,583 |  |  |  | 636,781 |  |
| Cost of sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  |  | 49,696 |  |  |  | 67,790 |  |  |  | 279,541 |  |  |  | 270,695 |  |
| Services |  |  | 18,015 |  |  |  | 24,409 |  |  |  | 83,389 |  |  |  | 74,742 |  |
| Total Cost of Sales |  |  | 67,711 |  |  |  | 92,199 |  |  |  | 362,930 |  |  |  | 345,437 |  |
| Gross Profit |  |  | 58,808 |  |  |  | 70,787 |  |  |  | 303,653 |  |  |  | 291,344 |  |
| Selling, general and administrative expenses |  |  | 31,387 |  |  |  | 34,438 |  |  |  | 135,489 |  |  |  | 131,805 |  |
| Research and development expenses |  |  | 31,489 |  |  |  | 32,077 |  |  |  | 130,434 |  |  |  | 124,804 |  |
| Operating Income (Loss) |  |  | (4,068 | ) |  |  | 4,272 |  |  |  | 37,730 |  |  |  | 34,735 |  |
| Interest and dividend income |  |  | 1,523 |  |  |  | 1,226 |  |  |  | 4,380 |  |  |  | 3,918 |  |
| Interest expense |  |  | (139 | ) |  |  | (142 | ) |  |  | (556 | ) |  |  | (572 | ) |
| Net realized investment gain |  |  | 1,816 |  |  |  | 1,769 |  |  |  | 4,685 |  |  |  | 5,923 |  |
| Other income (expense), net |  |  | 127 |  |  |  | (273 | ) |  |  | (1,559 | ) |  |  | (651 | ) |
| Gain on bargain purchase of a business |  |  | — |  |  |  | (8 | ) |  |  | — |  |  |  | 3,542 |  |
| Income (Loss) before provision for income taxes |  |  | (741 | ) |  |  | 6,844 |  |  |  | 44,680 |  |  |  | 46,895 |  |
| Provision for income taxes |  |  | (10,376 | ) |  |  | 728 |  |  |  | (20,847 | ) |  |  | (11,666 | ) |
| Net Income (Loss) |  | $ | (11,117 | ) |  | $ | 7,572 |  |  | $ | 23,833 |  |  | $ | 35,229 |  |
| Weighted average shares outstanding – basic |  |  | 48,280 |  |  |  | 48,383 |  |  |  | 48,153 |  |  |  | 48,724 |  |
| Weighted average shares outstanding – diluted |  |  | 48,912 |  |  |  | 48,757 |  |  |  | 48,699 |  |  |  | 48,949 |  |
| Earnings per common share – basic |  | $ | (0.23 | ) |  | $ | 0.16 |  |  | $ | 0.49 |  |  | $ | 0.72 |  |
| Earnings per common share – diluted |  | $ | (0.23 | ) |  | $ | 0.16 |  |  | $ | 0.49 |  |  | $ | 0.72 |  |

[0001564590-18-000519:8k_2_02:21]
(1) Assumes exercise of dilutive stock options calculated under the treasury stock method.

[0001564590-18-000519:8k_2_02:22]
Consolidated Statements of Comprehensive Income

[0001564590-18-000519:8k_2_02:23]
(Unaudited)

[0001564590-18-000519:8k_2_02:24]
(In thousands)

[0001564590-18-000519:8k_2_02:25]
|  |  | Three Months Ended |  |  | Twelve Months Ended |  |
|  |  | December 31, |  |  | December 31, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Net Income (Loss) |  | $ | (11,117 | ) |  | $ | 7,572 |  |  | $ | 23,833 |  |  | $ | 35,229 |  |
| Other Comprehensive Income (Loss), net of tax |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net unrealized gains (losses) on available-for-sale securities |  |  | (349 | ) |  |  | (1,366 | ) |  |  | 2,163 |  |  |  | (1,528 | ) |
| Net unrealized gains on cash flow hedges |  |  | 196 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Defined benefit plan adjustments |  |  | 762 |  |  |  | (1,225 | ) |  |  | 976 |  |  |  | (1,122 | ) |
| Foreign currency translation |  |  | 599 |  |  |  | (1,771 | ) |  |  | 6,001 |  |  |  | (569 | ) |
| Other Comprehensive Income (Loss), net of tax |  |  | 1,208 |  |  |  | (4,362 | ) |  |  | 9,140 |  |  |  | (3,219 | ) |
| Comprehensive Income (Loss), net of tax |  | $ | (9,909 | ) |  | $ | 3,210 |  |  | $ | 32,973 |  |  | $ | 32,010 |  |

[0001564590-18-000519:8k_2_02:26]
Consolidated Statements of Cash Flows

[0001564590-18-000519:8k_2_02:27]
(Unaudited)

[0001564590-18-000519:8k_2_02:28]
(In thousands)

[0001564590-18-000519:8k_2_02:29]
|  |  | Twelve Months Ended |  |
|  |  | December 31, |  |
|  |  | 2017 |  |  | 2016 |  |
| Cash flows from operating activities |  |  |  |  |  |  |  |  |
| Net income |  | $ | 23,833 |  |  | $ | 35,229 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 15,690 |  |  |  | 14,407 |  |
| Amortization of net premium on available-for-sale investments |  |  | 425 |  |  |  | 643 |  |
| Net realized gain on long-term investments |  |  | (4,685 | ) |  |  | (5,923 | ) |
| Net (gain) loss on disposal of property, plant and equipment |  |  | (145 | ) |  |  | 22 |  |
| Gain on bargain purchase of a business |  |  | — |  |  |  | (3,542 | ) |
| Stock-based compensation expense |  |  | 7,433 |  |  |  | 6,695 |  |
| Deferred income taxes |  |  | 14,069 |  |  |  | (2,685 | ) |
| Change in operating assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  |  | (48,773 | ) |  |  | (21,302 | ) |
| Other receivables |  |  | (6,906 | ) |  |  | 4,101 |  |
| Inventory |  |  | (15,519 | ) |  |  | (10,887 | ) |
| Prepaid expenses and other assets |  |  | (5,003 | ) |  |  | (7,108 | ) |
| Accounts payable |  |  | (17,877 | ) |  |  | 26,722 |  |
| Accrued expenses and other liabilities |  |  | (5,448 | ) |  |  | 8,792 |  |
| Income taxes payable/receivable, net |  |  | 536 |  |  |  | (3,162 | ) |
| Net cash provided by (used in) operating activities |  |  | (42,370 | ) |  |  | 42,002 |  |
| Cash flows from investing activities |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (14,719 | ) |  |  | (21,441 | ) |
| Proceeds from disposals of property, plant and equipment |  |  | 151 |  |  |  | — |  |
| Proceeds from sales and maturities of available-for-sale investments |  |  | 173,752 |  |  |  | 225,075 |  |
| Purchases of available-for-sale investments |  |  | (93,141 | ) |  |  | (209,172 | ) |
| Acquisition of business |  |  | — |  |  |  | (943 | ) |
| Net cash provided by (used in) investing activities |  |  | 66,043 |  |  |  | (6,481 | ) |
| Cash flows from financing activities |  |  |  |  |  |  |  |  |
| Proceeds from stock option exercises |  |  | 13,412 |  |  |  | 4,717 |  |
| Purchases of treasury stock |  |  | (17,348 | ) |  |  | (25,817 | ) |
| Dividend payments |  |  | (17,368 | ) |  |  | (17,583 | ) |
| Payments on long-term debt |  |  | (1,100 | ) |  |  | (1,100 | ) |
| Net cash used in financing activities |  |  | (22,404 | ) |  |  | (39,783 | ) |
| Net increase (decrease) in cash and cash equivalents |  |  | 1,269 |  |  |  | (4,262 | ) |
| Effect of exchange rate changes |  |  | 5,269 |  |  |  | (393 | ) |
| Cash and cash equivalents, beginning of year |  |  | 79,895 |  |  |  | 84,550 |  |
| Cash and cash equivalents, end of year |  | $ | 86,433 |  |  | $ | 79,895 |  |
| Supplemental disclosure of non-cash investing activities |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment included in accounts payable |  | $ | 408 |  |  | $ | 2,103 |  |

[0001564590-18-000519:8k_2_02:30]
Supplemental Information

[0001564590-18-000519:8k_2_02:31]
Restructuring Expenses

[0001564590-18-000519:8k_2_02:32]
(Unaudited)

[0001564590-18-000519:8k_2_02:33]
(In thousands)

[0001564590-18-000519:8k_2_02:34]
Restructuring expense was recorded in the following Consolidated Statements of Income categories for three and twelve months ended December 31, 2017 and 2016:

[0001564590-18-000519:8k_2_02:35]
|  |  | Three Months Ended |  |  | Twelve Months Ended |  |
|  |  | December 31, |  |  | December 31, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Restructuring expense included in cost of sales |  | $ | — |  |  | $ | 14 |  |  | $ | — |  |  | $ | 1,321 |  |
| Selling, general and administrative expense |  |  | 59 |  |  |  | — |  |  |  | 152 |  |  |  | 637 |  |
| Research and development expense |  |  | — |  |  |  | — |  |  |  | 122 |  |  |  | — |  |
| Restructuring expense included in operating expenses |  |  | 59 |  |  |  | — |  |  |  | 274 |  |  |  | 637 |  |
| Total restructuring expense |  |  | 59 |  |  |  | 14 |  |  |  | 274 |  |  |  | 1,958 |  |
| Provision for income taxes |  |  | (23 | ) |  |  | (4 | ) |  |  | (107 | ) |  |  | (607 | ) |
| Total restructuring expense, net of tax |  | $ | 36 |  |  | $ | 10 |  |  | $ | 167 |  |  | $ | 1,351 |  |

[0001564590-18-000519:8k_2_02:36]
Supplemental Information

[0001564590-18-000519:8k_2_02:37]
Acquisition Related Expenses, Amortizations and Adjustments

[0001564590-18-000519:8k_2_02:38]
(Unaudited)

[0001564590-18-000519:8k_2_02:39]
(In thousands)

[0001564590-18-000519:8k_2_02:40]
On August 4, 2011, we closed on the acquisition of Bluesocket, Inc., on May 4, 2012, we closed on the acquisition of the Nokia Siemens Networks Broadband Access business (NSN BBA), and on September 13, 2016, we closed on the acquisition of CommScope’s active fiber business (CommScope). Acquisition related expenses, amortizations and adjustments for the three and twelve months ended December 31, 2017 and 2016 for all three transactions are as follows:

[0001564590-18-000519:8k_2_02:41]
|  |  | Three Months Ended |  |  | Twelve Months Ended |  |
|  |  | December 31, |  |  | December 31, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Bluesocket, Inc. acquisition |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets |  | $ | 158 |  |  | $ | 158 |  |  | $ | 632 |  |  | $ | 662 |  |
| NSN BBA acquisition |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets |  |  | 95 |  |  |  | 221 |  |  |  | 527 |  |  |  | 901 |  |
| Amortization of other purchase accounting adjustments |  |  | — |  |  |  | 30 |  |  |  | 39 |  |  |  | 224 |  |
| Subtotal - NSN BBA acquisition |  |  | 95 |  |  |  | 251 |  |  |  | 566 |  |  |  | 1,125 |  |
| CommScope acquisition |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets |  |  | 219 |  |  |  | 673 |  |  |  | 1,732 |  |  |  | 785 |  |
| Amortization of other purchase accounting adjustments |  |  | 3 |  |  |  | 42 |  |  |  | 88 |  |  |  | 126 |  |
| Acquisition related professional fees, travel and other expenses |  |  | — |  |  |  | 29 |  |  |  | 8 |  |  |  | 74 |  |
| Subtotal - CommScope acquisition |  |  | 222 |  |  |  | 744 |  |  |  | 1,828 |  |  |  | 985 |  |
| Total acquisition related expenses, amortizations and adjustments |  |  | 475 |  |  |  | 1,153 |  |  |  | 3,026 |  |  |  | 2,772 |  |
| Provision for income taxes |  |  | (178 | ) |  |  | (429 | ) |  |  | (1,135 | ) |  |  | (991 | ) |
| Total acquisition related expenses, amortizations and adjustments, net of tax |  | $ | 297 |  |  | $ | 724 |  |  | $ | 1,891 |  |  | $ | 1,781 |  |

[0001564590-18-000519:8k_2_02:42]
The acquisition related expenses, amortizations and adjustments above were recorded in the following Consolidated Statements of Income categories for the three and twelve months ended December 31, 2017 and 2016:

[0001564590-18-000519:8k_2_02:43]
|  |  | Three Months Ended |  |  | Twelve Months Ended |  |
|  |  | December 31, |  |  | December 31, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Cost of goods sold |  | $ | 2 |  |  | $ | 43 |  |  | $ | 88 |  |  | $ | 232 |  |
| Selling, general and administrative expenses |  |  | 51 |  |  |  | 70 |  |  |  | 215 |  |  |  | 131 |  |
| Research and development expenses |  |  | 422 |  |  |  | 1,040 |  |  |  | 2,723 |  |  |  | 2,409 |  |
| Total acquisition related expenses, amortizations and adjustments included in operating expenses |  |  | 473 |  |  |  | 1,110 |  |  |  | 2,938 |  |  |  | 2,540 |  |
| Total acquisition related expenses, amortizations and adjustments |  |  | 475 |  |  |  | 1,153 |  |  |  | 3,026 |  |  |  | 2,772 |  |
| Provision for income taxes |  |  | (178 | ) |  |  | (429 | ) |  |  | (1,135 | ) |  |  | (991 | ) |
| Total acquisition related expenses, amortizations and adjustments, net of tax |  | $ | 297 |  |  | $ | 724 |  |  | $ | 1,891 |  |  | $ | 1,781 |  |

[0001564590-18-000519:8k_2_02:44]
Supplemental Information

[0001564590-18-000519:8k_2_02:45]
Stock-based Compensation Expense

[0001564590-18-000519:8k_2_02:46]
(Unaudited)

[0001564590-18-000519:8k_2_02:47]
(In thousands)

[0001564590-18-000519:8k_2_02:48]
|  |  | Three Months Ended |  |  | Twelve Months Ended |  |
|  |  | December 31, |  |  | December 31, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| Stock-based compensation expense included in cost of sales |  | $ | 98 |  |  | $ | 107 |  |  | $ | 379 |  |  | $ | 389 |  |
| Selling, general and administrative expense |  |  | 1,045 |  |  |  | 1,019 |  |  |  | 4,063 |  |  |  | 3,341 |  |
| Research and development expense |  |  | 717 |  |  |  | 968 |  |  |  | 2,991 |  |  |  | 2,965 |  |
| Stock-based compensation expense included in operating expenses |  |  | 1,762 |  |  |  | 1,987 |  |  |  | 7,054 |  |  |  | 6,306 |  |
| Total stock-based compensation expense |  |  | 1,860 |  |  |  | 2,094 |  |  |  | 7,433 |  |  |  | 6,695 |  |
| Tax benefit for expense associated with non-qualified options, PSUs, RSUs and restricted stock |  |  | (484 | ) |  |  | (320 | ) |  |  | (1,699 | ) |  |  | (963 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 1,376 |  |  | $ | 1,774 |  |  | $ | 5,734 |  |  | $ | 5,732 |  |

[0001564590-18-000519:8k_2_02:49]
Reconciliation of GAAP net income per share, diluted, to

[0001564590-18-000519:8k_2_02:50]
Non-GAAP net income per share, diluted

[0001564590-18-000519:8k_2_02:51]
(Unaudited)

[0001564590-18-000519:8k_2_02:52]
|  |  | Three Months Ended |  |  | Twelve Months Ended |  |
|  |  | December 31, |  |  | December 31, |  |
|  |  | 2017 |  |  | 2016 |  |  | 2017 |  |  | 2016 |  |
| GAAP earnings per common share - diluted |  | $ | (0.23 | ) |  | $ | 0.16 |  |  | $ | 0.49 |  |  | $ | 0.72 |  |
| Restructuring expense |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 0.03 |  |
| Acquisition related expenses, amortizations and adjustments |  |  | 0.01 |  |  |  | 0.01 |  |  |  | 0.04 |  |  |  | 0.04 |  |
| Stock-based compensation expense |  |  | 0.03 |  |  |  | 0.04 |  |  |  | 0.12 |  |  |  | 0.12 |  |
| Impact of the Tax Cuts and Jobs Act |  |  | 0.24 |  |  |  | — |  |  |  | 0.24 |  |  |  | — |  |
| Gain on bargain purchase of a business |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (0.07 | ) |
| Non-GAAP earnings per common share - diluted |  | $ | 0.05 |  |  | $ | 0.21 |  |  | $ | 0.89 |  |  | $ | 0.84 |  |
