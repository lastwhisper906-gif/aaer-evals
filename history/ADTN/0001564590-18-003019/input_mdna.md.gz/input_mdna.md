# ADTN MD&A — 0001564590-18-003019


## mdna

[0001564590-18-003019:mdna:1]
| ITEM 7. | MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS |

[0001564590-18-003019:mdna:2]
Overview

[0001564590-18-003019:mdna:3]
ADTRAN, Inc. (ADTRAN) is a leading global provider of networking and communications equipment. Our solutions enable voice, data, video and Internet communications across a variety of network infrastructures. These solutions are deployed by many of the United States’ and the world’s largest communications service providers (CSPs), distributed enterprises and small and medium-sized businesses, public and private enterprises, and millions of individual users worldwide.

[0001564590-18-003019:mdna:4]
Our success depends upon our ability to increase unit volume and market share through the introduction of new products and succeeding generations of products having lower selling prices and increased functionality as compared to both the prior generation of a product and to the products of competitors. An important part of our strategy is to reduce the cost of each succeeding product generation and then lower the product’s selling price based on the cost savings achieved in order to gain market share and/or improve gross margins. As a part of this strategy, we seek in most instances to be a high-quality, low-cost provider of products in our markets. Our success to date is attributable in large measure to our ability to design our products initially with a view to their subsequent redesign, allowing both increased functionality and reduced manufacturing costs in each succeeding product generation. This strategy enables us to sell succeeding generations of products to existing customers, while increasing our market share by selling these enhanced products to new customers.

[0001564590-18-003019:mdna:5]
In addition to reporting our Network Solutions and Services & Support segments, we report revenue across three categories – Access & Aggregation, Customer Devices, and Traditional & Other Products.

[0001564590-18-003019:mdna:6]
Access & Aggregation solutions are used by CSPs to connect their network infrastructure to their subscribers. This category includes software and hardware-based products and services that aggregate and/or originate access technologies. The portfolio of ADTRAN solutions within this category includes a wide array of modular or fixed physical form factors designed to deliver the best technology and economic fit based on the target subscriber density and environmental conditions.

[0001564590-18-003019:mdna:7]
The Access & Aggregation category includes product and service families such as:

[0001564590-18-003019:mdna:8]
|  | • | Mosaic branded network management and subscriber services control and orchestration software within a SD-Access architecture |

[0001564590-18-003019:mdna:9]
|  | • | SDX series of SDN-controlled programmable network elements that form the hardware components within a SD-Access architecture |

[0001564590-18-003019:mdna:10]
|  | • | Total Access® 5000 Series Fiber to the Premises (FTTP) and Fiber to the Node (FTTN) Multi-Service Access Nodes (MSAN) |

[0001564590-18-003019:mdna:11]
|  | • | hiX 5600 Series fiber aggregation and FTTN MSAN |

[0001564590-18-003019:mdna:12]
|  | • | Fiber to the Distribution Point (FTTdp) Gfast Optical Network Units (ONU) |

[0001564590-18-003019:mdna:13]
|  | • | GPON, EPON and 10G PON Optical Line Terminals (OLT) |

[0001564590-18-003019:mdna:14]
|  | • | Optical Networking Edge (ONE) aggregation |

[0001564590-18-003019:mdna:15]
|  | • | IP-based Digital Subscriber Line Access Multiplexers (DSLAMs) |

[0001564590-18-003019:mdna:16]
|  | • | Cabinet and Outside-Plant (OSP) enclosures and services |

[0001564590-18-003019:mdna:17]
|  | • | Pluggable optical transceivers (i.e., SFP, SFP+, XFP, QSFP), cables and other miscellaneous materials |

[0001564590-18-003019:mdna:18]
|  | • | Planning, engineering, program management, maintenance, installation and commissioning services to implement customer network solutions |

[0001564590-18-003019:mdna:19]
|  | • | Other products and services that are generally applicable to Access & Aggregation |

[0001564590-18-003019:mdna:20]
Customer Devices includes our products and services that provide end users access to CSP networks. Our Customer Devices portfolio includes a comprehensive array of service provider and enterprise hardware and software products and services.

[0001564590-18-003019:mdna:21]
The Customer Devices category includes products and services such as:

[0001564590-18-003019:mdna:22]
|  | • | Broadband customer premises solutions, including Passive Optical Network (PON) and point-to-point Ethernet Optical Network Terminals (ONTs) |

[0001564590-18-003019:mdna:23]
|  | • | Radio Frequency over Glass (RFoG) MicroNodes |

[0001564590-18-003019:mdna:24]
|  | • | Residential and business gateways |

[0001564590-18-003019:mdna:25]
|  | • | Wi-Fi access points and associated powering and switching infrastructure |

[0001564590-18-003019:mdna:26]
|  | • | Enterprise Session Border Controllers (eSBC) |

[0001564590-18-003019:mdna:27]
|  | • | Branch office and access routers |

[0001564590-18-003019:mdna:28]
|  | • | Carrier Ethernet services termination devices |

[0001564590-18-003019:mdna:29]
|  | • | Voice over Internet Protocol (VoIP) media gateways |

[0001564590-18-003019:mdna:30]
|  | • | ProServices pre-sale and post-sale technical support |

[0001564590-18-003019:mdna:31]
|  | • | Planning, engineering, program management, maintenance, installation and commissioning services to implement customer devices solutions into consumer, small business and enterprise locations |

[0001564590-18-003019:mdna:32]
|  | • | Other products and services that are generally applicable to customer devices |

[0001564590-18-003019:mdna:33]
Traditional & Other Products generally includes a mix of prior generation technologies’ products and services, as well as other products and services that do not fit within the Access & Aggregation or Customer Devices categories.

[0001564590-18-003019:mdna:34]
The Traditional & Other Products category includes products and services such as:

[0001564590-18-003019:mdna:35]
|  | • | Time Division Multiplexed (TDM) and Asynchronous Transfer Mode (ATM)-based aggregation systems and customer devices |

[0001564590-18-003019:mdna:36]
|  | • | HDSL, ADSL and other mature technologies used to deliver business and residential services over the CSP access and customer networks |

[0001564590-18-003019:mdna:37]
|  | • | Other products and services that do not fit within the Access & Aggregation and Customer Devices categories |

[0001564590-18-003019:mdna:38]
Sales were $666.9 million in 2017, compared to $636.8 million in 2016 and $600.1 million in 2015. Our gross profit margin was 45.5% in 2017, compared to 45.8% in 2016 and 44.5% in 2015. Net income was $23.8 million in 2017, compared to $35.2 million in 2016 and $18.6 million in 2015. Earnings per share, assuming dilution, were $0.49 in 2017, compared to $0.72 in 2016 and $0.36 in 2015. Earnings per share in 2017, 2016 and 2015 include the effect of the repurchase of 0.9 million, 1.4 million and 4.0 million shares of our stock in those years, respectively.

[0001564590-18-003019:mdna:39]
Our operating results have fluctuated on a quarterly basis in the past, and may vary significantly in future periods due to a number of factors, including customer order activity and backlog. Backlog levels vary because of seasonal trends, the timing of customer projects and other factors that affect customer order lead times. Many of our customers require prompt delivery of products. This requires us to maintain sufficient inventory levels to satisfy anticipated customer demand. If near-term demand for our products declines, or if potential sales in any quarter do not occur as anticipated, our financial results could be adversely affected. Operating expenses are relatively fixed in the short term; therefore, a shortfall in quarterly revenues could significantly impact our financial results in a given quarter.

[0001564590-18-003019:mdna:40]
Our operating results may also fluctuate as a result of a number of other factors, including a decline in general economic and market conditions, foreign currency exchange rate movements, increased competition, customer order patterns, changes in product and services mix, timing differences between price decreases and product cost reductions, product warranty returns, expediting costs and announcements of new products by us or our competitors. Additionally, maintaining sufficient inventory levels to assure prompt delivery of our products increases the amount of inventory that may become obsolete and increases the risk that the obsolescence of this inventory may have an adverse effect on our business and operating results. Also, not maintaining sufficient inventory levels to assure prompt delivery of our products may cause us to incur expediting costs to meet customer delivery requirements, which may negatively impact our operating results in a given quarter.

[0001564590-18-003019:mdna:41]
Accordingly, our historical financial performance is not necessarily a meaningful indicator of future results, and, in general, management expects that our financial results may vary from period to period. See Note 16 of Notes to Consolidated Financial Statements for additional information. For a discussion of risks associated with our operating results, see Item 1A of this report.

[0001564590-18-003019:mdna:42]
Critical Accounting Policies and Estimates

[0001564590-18-003019:mdna:43]
An accounting policy is deemed to be critical if it requires an accounting estimate to be made based on assumptions about matters that are highly uncertain at the time the estimate is made, if different estimates reasonably could have been used, or if changes in the accounting estimate that are reasonably likely to occur could materially impact the results of financial operations. We believe the following critical accounting policies affect our more significant judgments and estimates used in the preparation of our consolidated financial statements. These policies have been consistently applied across our two reportable segments: (1) Network Solutions and (2) Services & Support.

[0001564590-18-003019:mdna:44]
|  | • | Revenue is generally recognized when persuasive evidence of an arrangement exists, delivery has occurred, the product price is fixed or determinable, collection of the resulting receivable is reasonably assured, and product returns are reasonably estimable. For product sales, revenue is generally recognized upon shipment of the product to our customer in accordance with the title transfer terms of the sales agreement, generally Ex Works, per International Commercial Terms. In the case of consigned inventory, revenue is recognized when the end customer assumes ownership of the product. Contracts that contain multiple deliverables are evaluated to determine the units of accounting, and the consideration from the arrangement is allocated to each unit of accounting based on the relative selling price and corresponding terms of the contract. When this is not available, we are generally not able to determine third-party evidence of selling price because of the extent of customization among competing products or services from other companies. In these instances, we use best estimates to allocate consideration to each respective unit of accounting. These estimates include analysis of respective bills of material and review and analysis of similar product and service offerings. We record revenue associated with installation services when respective contractual obligations are complete. In instances where customer acceptance is required, revenue is deferred until respective acceptance criteria have been met. Contracts that include both installation services and product sales are evaluated for revenue recognition in accordance with contract terms. As a result, installation services may be considered a separate deliverable or may be considered a combined single unit of accounting with the delivered product. Generally, either the purchaser, ADTRAN, or a third party can perform the installation of our products. Sales taxes invoiced to customers are included in revenue, and represent less than one percent of total revenues. The corresponding sales taxes paid are included in cost of goods sold. Value added taxes collected from customers in international jurisdictions are recorded in accrued expenses as a liability. Revenue is recorded net of discounts. Sales returns are recorded as a reduction of revenue and accrued based on historical sales return experience, which we believe provides a reasonable estimate of future returns. |

[0001564590-18-003019:mdna:45]
A significant portion of our products are sold in the U.S. through a non-exclusive distribution network of major technology distributors. These organizations then distribute or provide fulfillment services to an extensive network of VARs and SIs. VARs and SIs may be affiliated with us as a channel partner, or they may purchase from the distributor on an unaffiliated basis. Additionally, with certain limitations, our distributors may return unused and unopened product for stock-balancing purposes when these returns are accompanied by offsetting orders for products of equal or greater value.

[0001564590-18-003019:mdna:46]
|  | • | We carry our inventory at the lower of cost and net realizable value, with cost being determined using the first-in, first-out method. We use standard costs for material, labor, and manufacturing overhead to value our inventory. Our standard costs are updated on at least a quarterly basis and any variances are expensed in the current period; therefore, our inventory costs approximate actual costs at the end of each reporting period. We write down our inventory for estimated obsolescence or unmarketable inventory by an amount equal to the difference between the cost of inventory and the estimated fair value based upon assumptions about future demand and market conditions. If actual future demand or market conditions are less favorable than those projected by management, we may be required to make additional inventory write-downs. Our reserve for excess and obsolete inventory was $23.4 million and $25.2 million at December 31, 2017 and 2016, respectively. Inventory disposals charged against the reserve were $8.3 million, $4.7 million and $0.2 million for the years ended December 31, 2017, 2016 and 2015, respectively. |

[0001564590-18-003019:mdna:47]
31

[0001564590-18-003019:mdna:48]
|  | • | For purposes of determining the estimated fair value of our stock option awards on the date of grant, we use the Black-Scholes Model. This model requires the input of certain assumptions that require subjective judgment. These assumptions include, but are not limited to, expected stock price volatility over the term of the awards and actual and projected employee stock option exercise behaviors. Because our stock option awards have characteristics significantly different from those of traded options, and because changes in the input assumptions can materially affect the fair value estimate, the existing model may not provide a reliable, single measure of the fair value of our stock option awards. For purposes of determining the estimated fair value of our market-based performance stock unit (PSU) awards on the date of grant, we use a Monte Carlo Simulation valuation method. The PSUs are subject to a market condition based on the relative total shareholder return of ADTRAN against all of the companies in the NASDAQ Telecommunications Index and vest at the end of a three-year performance period. The fair value of performance-based PSUs, restricted stock units (RSUs) and restricted stock is equal to the closing price of our stock on the business day immediately preceding the grant date. Compensation expense related to unvested performance-based PSUs will be recognized over the requisite service period of three years as achievement of the performance obligation becomes probable. Management will continue to assess the assumptions and methodologies used to calculate the estimated fair value of stock-based compensation. Circumstances may change and additional data may become available over time, which could result in changes to these assumptions and methodologies and thereby materially impact our fair value determination. If factors change in future periods, the compensation expense that we record may differ significantly from what we have recorded in the current period. |

[0001564590-18-003019:mdna:49]
|  | • | We estimate our income tax provision or benefit in each of the jurisdictions in which we operate, including estimating exposures related to examinations by taxing authorities. We also make judgments regarding the realization of deferred tax assets, and establish valuation allowances where we believe it is more likely than not that future taxable income in certain jurisdictions will be insufficient to realize these deferred tax assets. Our estimates regarding future taxable income and income tax provision or benefit may vary due to changes in market conditions, changes in tax laws, or other factors. If our assumptions, and consequently our estimates, change in the future, the valuation allowances we have established may be increased or decreased, impacting future income tax expense. At December 31, 2017 and 2016 respectively, the valuation allowance was $6.0 million and $6.1 million. As of December 31, 2017, we have state research tax credit carry-forwards of $3.8 million, which will expire between 2018 and 2030. These carry-forwards were caused by tax credits in excess of our annual tax liabilities to an individual state where we no longer generate sufficient state income. In addition, as of December 31, 2017, we have a deferred tax asset of $5.2 million relating to net operating loss carry-forwards which will expire between 2018 and 2030. These carry-forwards are the result of acquisitions in 2009 and in 2011. The acquired net operating losses are in excess of the amount of estimated earnings. We believe it is more likely than not that we will not realize the full benefits of our deferred tax asset arising from these credits and net operating losses, and accordingly, have provided a valuation allowance against that piece. |

[0001564590-18-003019:mdna:50]
We establish reserves to remove some or all of the tax benefit of any of our tax positions at the time we determine that the positions become uncertain. We adjust these reserves, including any impact on the related interest and penalties, as facts and circumstances change.

[0001564590-18-003019:mdna:51]
|  | • | Our products generally include warranties of 90 days to five years for product defects. We accrue for warranty returns at the time revenue is recognized based on our historical return rate and estimate of the cost to repair or replace the defective products. We engage in extensive product quality programs and processes, including actively monitoring and evaluating the quality of our component suppliers. Our products continue to become more complex in both size and functionality as many of our product offerings migrate from line card applications to total systems. The increasing complexity of our products will cause warranty incidences, when they arise, to be more costly. Our estimates regarding future warranty obligations may change due to product failure rates, material usage, and other rework costs incurred in correcting a product failure. In addition, from time to time, specific warranty accruals may be recorded if unforeseen problems arise. Should our actual experience relative to these factors be worse than our estimates, we will be required to record additional warranty expense. Alternatively, if we provide for more reserves than we require, we will reverse a portion of such provisions in future periods. The liability for warranty obligations totaled $9.7 million and $8.5 million at December 31, 2017 and 2016, respectively. These liabilities are included in accrued expenses in the accompanying Consolidated Balance Sheets. |

[0001564590-18-003019:mdna:52]
|  | • | Pension benefit plan obligations are based on various assumptions used by our actuaries in calculating these amounts. These assumptions include discount rates, compensation rate increases, expected return on plan assets, retirement rates, and mortality rates. Actual results that differ from the assumptions and changes in assumptions could affect future expenses and obligations. Our net pension liability totaled $8.3 million and $10.0 million at December 31, 2017 and 2016, respectively. This liability is included in other non-current liabilities in the accompanying Consolidated Balance Sheets. |

[0001564590-18-003019:mdna:53]
32

[0001564590-18-003019:mdna:54]
Results of Operations

[0001564590-18-003019:mdna:55]
The following table presents selected financial information derived from our consolidated statements of income expressed as a percentage of sales for the years indicated. Amounts may not foot due to rounding.

[0001564590-18-003019:mdna:56]
| Year Ended December 31, |  | 2017 |  |  | 2016 |  |  | 2015 |  |
| Sales |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  |  | 81.0 | % |  |  | 82.5 | % |  |  | 87.9 | % |
| Services |  |  | 19.0 |  |  |  | 17.5 |  |  |  | 12.1 |  |
| Total sales |  |  | 100.0 |  |  |  | 100.0 |  |  |  | 100.0 |  |
| Cost of sales |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  |  | 41.9 |  |  |  | 42.5 |  |  |  | 49.0 |  |
| Services |  |  | 12.6 |  |  |  | 11.7 |  |  |  | 6.6 |  |
| Gross profit |  |  | 45.5 |  |  |  | 45.8 |  |  |  | 44.5 |  |
| Selling, general and administrative expenses |  |  | 20.3 |  |  |  | 20.7 |  |  |  | 20.6 |  |
| Research and development expenses |  |  | 19.6 |  |  |  | 19.6 |  |  |  | 21.6 |  |
| Operating income |  |  | 5.7 |  |  |  | 5.5 |  |  |  | 2.2 |  |
| Interest and dividend income |  |  | 0.7 |  |  |  | 0.6 |  |  |  | 0.7 |  |
| Interest expense |  |  | (0.1 | ) |  |  | (0.1 | ) |  |  | (0.1 | ) |
| Net realized investment gain |  |  | 0.7 |  |  |  | 0.9 |  |  |  | 1.7 |  |
| Other expense, net |  |  | (0.2 | ) |  |  | (0.1 | ) |  |  | (0.2 | ) |
| Gain on bargain purchase of a business |  |  | — |  |  |  | 0.6 |  |  |  | — |  |
| Income before provision for income taxes |  |  | 6.7 |  |  |  | 7.4 |  |  |  | 4.3 |  |
| Provision for income taxes |  |  | (3.1 | ) |  |  | (1.8 | ) |  |  | (1.2 | ) |
| Net income |  |  | 3.6 | % |  |  | 5.5 | % |  |  | 3.1 | % |

[0001564590-18-003019:mdna:57]
2017 Compared to 2016

[0001564590-18-003019:mdna:58]
Sales

[0001564590-18-003019:mdna:59]
Our sales increased 4.7% from $636.8 million in 2016 to $666.9 million in 2017. The increase in sales is attributable to a $14.9 million increase in Network Solutions sales and a $15.2 million increase in Services & Support sales.

[0001564590-18-003019:mdna:60]
Network Solutions sales increased 2.8% from $525.5 million in 2016 to $540.4 million in 2017. The increase in sales in 2017 is primarily attributable to an increase in sales of our Access & Aggregation products, partially offset by a decrease in sales of our Traditional & Other products. The increase in sales of our Access & Aggregation products is primarily attributable to increased VDSL2 vectoring product sales in the U.S. and European carrier markets. While we expect that revenues from Traditional & Other products will continue to decline over time, these revenues may fluctuate and continue for years because of the time required for our customers to transition to newer technologies.

[0001564590-18-003019:mdna:61]
Services & Support sales increased 13.7% from $111.3 million in 2016 to $126.5 million in 2017. The increase in sales in 2017 is primarily attributable to an increase in network installation services for Access & Aggregation products.

[0001564590-18-003019:mdna:62]
International sales, which are included in the Network Solutions and Services & Support amounts discussed above, increased 17.2% from $135.4 million in 2016 to $158.7 million in 2017. International sales, as a percentage of total sales, increased from 21.3% in 2016 to 23.8% in 2017. The increase in international sales in 2017 is primarily attributable to an increase in sales in EMEA, partially offset by a decrease in sales in Latin America and the APAC region.

[0001564590-18-003019:mdna:63]
Our international revenues are largely focused on broadband infrastructure and are impacted by the decisions of our customers as to timing for installation of new technologies, expansion of their networks and/or network upgrades. Our international customers must make these decisions in the regulatory and political environment in which they operate – both nationally and in some instances, regionally – whether of a multi-country region or a more local region within a country. For example, the European Commission launched a Gigabit Society initiative, and before that, the Digital Agenda, which has provided a favorable market environment for the deployment of ultra-broadband and Gigabit network solutions. Although the overall environment and market demand for broadband service deployment in the European Union has improved, some new broadband technologies are still being reviewed for regulatory and standards completion, which may affect the timing of those technologies. In Mexico, regulatory changes have created uncertainty for customers, which have resulted in slowdowns in network buying patterns. The competitive landscape in certain international markets is also impacted by the increased presence of Asian manufacturers that seek to compete aggressively on price. A strengthening U.S. dollar can also negatively impact our revenues in regions such as Latin America, where our products are traditionally priced in U.S. dollars, while in regions where our products are sold in local currency, such as Europe, a stronger U.S. dollar can negatively impact operating income. Consequently, while we expect the global trend towards deployment of more robust broadband speeds and access to continue to create expanded market opportunities for us, the factors described above may result in pressure on revenues and operating income. However, we do not presently foresee a significant negative impact to our financial condition based on our strong liquidity and the generally positive environment described above.

[0001564590-18-003019:mdna:64]
We recognized a positive impact to our revenues in the first half of 2017 due to our being awarded a network expansion program by a large European tier-1 customer. We anticipate that as our European and Latin American customers resume their network upgrade projects, we may experience further enhancement to our revenues. We have recently announced receipt of a new nationwide award in the Pacific region, as well as additional awards based on new ADTRAN technologies in the EMEA region that we believe will likely result in a positive impact to our revenues. Further, we expect that a resolution of the regulatory changes in Mexico may result in business with our major customer in that region returning to a more normal level.

[0001564590-18-003019:mdna:65]
Cost of Sales

[0001564590-18-003019:mdna:66]
As a percentage of sales, cost of sales increased from 54.2% in 2016 to 54.5% in 2017. The increase is primarily attributable to a regional revenue shift, customer and product mix and services and support mix.

[0001564590-18-003019:mdna:67]
Network Solutions cost of sales, as a percent of that segment’s sales, increased from 51.5% of sales in 2016 to 51.7% of sales in 2017. The increase in Network Solutions cost of sales as a percentage of that segment’s sales is primarily attributable to customer and product mix.

[0001564590-18-003019:mdna:68]
An important part of our strategy is to reduce the product cost of each succeeding product generation and then to lower the product’s price based on the cost savings achieved. This may cause variations in our gross profit percentage due to timing differences between the recognition of cost reductions and the lowering of product selling prices.

[0001564590-18-003019:mdna:69]
Services & Support cost of sales, as a percent of that segment’s sales, decreased from 67.2% of sales in 2016 to 66.2% of sales in 2017. The decrease in Services & Support cost of sales as a percentage of that segment’s sales is primarily attributable to the mix of network installation programs and support.

[0001564590-18-003019:mdna:70]
Our Services business has experienced significant growth since 2015 as competitive pressures to expand broadband access and speeds have strained carriers’ ability to respond to customer demand. Our Services & Support revenues are comprised of network planning and implementation, maintenance, support and cloud-based management services, with network planning and implementation being the largest and fastest growing component. Compared to our other services such as maintenance, support and cloud-based management services, our network planning and implementation services typically utilize a higher percentage of internal and subcontracted engineers, professionals and contractors to perform the work for customers. The additional costs incurred to perform these infrastructure and labor intensive services inherently result in lower average gross margins as compared to maintenance and support services.

[0001564590-18-003019:mdna:71]
As our network planning and implementation revenues have grown and are now the largest component of our Services & Support business, our Services & Support segment gross margins have decreased versus those reported when maintenance and support comprised the majority of the business. Further, because the growth in our network planning and implementation services has resulted in our Services & Support revenues comprising a larger percentage of our overall revenues, and because our Services & Support gross margins are below those of the Network Solutions segment, our overall corporate gross margins have declined as that business has continued to grow. Within the Services & Support segment, we do expect variability in gross margins from quarter-to-quarter based on the mix of the services recognized.

[0001564590-18-003019:mdna:72]
Selling, General and Administrative Expenses

[0001564590-18-003019:mdna:73]
Selling, general and administrative expenses increased 2.8% from $131.8 million in 2016 to $135.5 million in 2017. Selling, general and administrative expenses include personnel costs for administration, finance, information technology, human resources, sales and marketing, and general management, as well as rent, utilities, legal and accounting expenses, bad debt expense, advertising, promotional material, trade show expenses, and related travel costs. The increase in selling, general and administrative expenses is primarily attributable to increases in ERP implementation expense, deferred compensation expense, travel expense, and equity-based compensation expense, partially offset by a decrease in performance-based compensation expense.

[0001564590-18-003019:mdna:74]
Selling, general and administrative expenses as a percentage of sales decreased from 20.7% for the year ended December 31, 2016 to 20.3% for the year ended December 31, 2017. Selling, general and administrative expenses as a percentage of sales will generally fluctuate whenever there is a significant fluctuation in revenues for the periods being compared.

[0001564590-18-003019:mdna:75]
Research and Development Expenses

[0001564590-18-003019:mdna:76]
Research and development expenses increased 4.5% from $124.8 million in 2016 to $130.4 million in 2017. The increase in research and development expenses is primarily attributable to an increase in labor and engineering materials related to customer specific projects, contract services and amortization of intangibles acquired in the third quarter of 2016.

[0001564590-18-003019:mdna:77]
Research and development expenses as a percentage of sales remained constant at 19.6% for the years ended December 31, 2016 and 2017. Research and development expenses as a percentage of sales will fluctuate whenever there are incremental product development activities or a significant fluctuation in revenues for the periods being compared.

[0001564590-18-003019:mdna:78]
We expect to continue to incur research and development expenses in connection with our new and existing products and our expansion into international markets. We continually evaluate new product opportunities and engage in intensive research and product development efforts which provide for new product development, enhancement of existing products and product cost reductions. We may incur significant research and development expenses prior to the receipt of revenues from a major new product group.

[0001564590-18-003019:mdna:79]
Interest and Dividend Income

[0001564590-18-003019:mdna:80]
Interest and dividend income increased 11.8% from $3.9 million in 2016 to $4.4 million in 2017. The increase in interest and dividend income is primarily attributable to an increase in the rate of return on investments.

[0001564590-18-003019:mdna:81]
Interest Expense

[0001564590-18-003019:mdna:82]
Interest expense, which is primarily related to our taxable revenue bond, remained consistent at $0.6 million in 2016 and 2017, as we had no substantial change in our fixed-rate borrowing. See “Financing Activities” in “Liquidity and Capital Resources” below for additional information on our taxable revenue bond.

[0001564590-18-003019:mdna:83]
Net Realized Investment Gain

[0001564590-18-003019:mdna:84]
Net realized investment gain decreased 20.9% from $5.9 million in 2016 to $4.7 million in 2017. The decrease in realized investment gains is primarily attributable to decreased gains from the sale of equity securities. See “Investing Activities” in “Liquidity and Capital Resources” below for additional information.

[0001564590-18-003019:mdna:85]
Other Income (Expense), net

[0001564590-18-003019:mdna:86]
Other income (expense), net, comprised primarily of miscellaneous income and expense, gains and losses on foreign currency transactions, gains and losses on foreign exchange forward contracts, investment account management fees, and scrap raw material sales, increased 139.5% from $0.7 million of expense in 2016 to $1.6 million of expense in 2017. The change is primarily attributable to increased losses on our foreign exchange contracts.

[0001564590-18-003019:mdna:87]
Gain on Bargain Purchase of a Business

[0001564590-18-003019:mdna:88]
Gain on bargain purchase of a business in 2016 is related to our acquisition of key fiber access products, technologies and service relationships from a third party on September 13, 2016. See Note 2 of Notes to Consolidated Financial Statements for additional information.

[0001564590-18-003019:mdna:89]
Income Taxes

[0001564590-18-003019:mdna:90]
Our effective tax rate increased from 24.9% in 2016 to 46.7% in 2017. The increase in the effective tax rate between the two periods is primarily attributable to the Tax Cuts and Jobs Act, which was signed into law on December 22, 2017. As a result of the new law, we recognized an estimated expense of $11.9 million in the fourth quarter of 2017, of which $9.2 million related to the write-down of deferred tax assets and $2.7 million related to tax on unrepatriated foreign earnings. See Note 11 of Notes to Consolidated Financial Statements for additional information.

[0001564590-18-003019:mdna:91]
Net Income

[0001564590-18-003019:mdna:92]
As a result of the above factors, net income decreased from $35.2 million in 2016 to $23.8 million in 2017. As a percentage of sales, net income decreased from 5.5% in 2016 to 3.6% in 2017.

[0001564590-18-003019:mdna:93]
2016 Compared to 2015

[0001564590-18-003019:mdna:94]
Sales

[0001564590-18-003019:mdna:95]
Our sales increased 6.1% from $600.1 million in 2015 to $636.8 million in 2016. The increase in sales is primarily attributable to a $38.6 million increase in Services & Support sales, partially offset by a $1.9 million decrease in Network Solutions sales.

[0001564590-18-003019:mdna:96]
Network Solutions sales decreased 0.4% from $527.4 million in 2015 to $525.5 million in 2016. The decrease in sales in 2016 is primarily attributable to a decrease in sales of our Access & Aggregation products and Traditional & Other products, partially offset by an increase in sales of our Customer Devices products. The decrease in sales of our Access & Aggregation products is primarily attributable to a decrease in international hiX product sales, partially offset by an increase in OSP DSLAM sales. The increase in sales of our Customer Devices products is primarily attributable to increased sales of our FTTP ONT products. While we expect that revenues from Traditional & Other products will continue to decline over time, these revenues may fluctuate and continue for years because of the time required for our customers to transition to newer technologies.

[0001564590-18-003019:mdna:97]
Services & Support sales increased 53.2% from $72.6 million in 2015 to $111.3 million in 2016. The increase in sales in 2016 is primarily attributable to an increase in network installation services for Access & Aggregation products.

[0001564590-18-003019:mdna:98]
International sales, which are included in the Network Solutions and Services & Support amounts discussed above, decreased 25.0% from $180.7 million in 2015 to $135.4 million in 2016. International sales, as a percentage of total sales, decreased from 30.1% in 2015 to 21.3% in 2016. Our international revenues are affected to a great extent by the timing of network upgrade projects at our larger European and Latin American customers and by changes in foreign exchange rates in territories in which we sell our products and services. Throughout 2016, our largest European customer focused on completing network upgrade activities in regions outside of our footprint with them. However, we expect that once current projects are completed, future network upgrades will resume in the second half of 2017 within our geographic footprint with this customer. Additionally, after reaching a cyclical high in the second quarter of 2014, the value of the Euro currency relative to the U.S. dollar declined significantly throughout the second half of 2014 and in 2015. Though the Euro-USD exchange rate appears to have stabilized since reaching a low in the fourth quarter of 2015, it remains approximately 20% below the highs of 2014. This decline in the value of the Euro throughout 2015 and into 2016 significantly reduced the U.S. dollar value of revenue from our European sales.

[0001564590-18-003019:mdna:99]
Cost of Sales

[0001564590-18-003019:mdna:100]
As a percentage of sales, cost of sales decreased from 55.5% in 2015 to 54.2% in 2016. The decrease is primarily attributable to a regional revenue shift and customer and product mix, partially offset by a change in services mix, restructuring expenses and an increase in warranty expense related to a product recall caused by a defect in a part provided by a third party supplier.

[0001564590-18-003019:mdna:101]
Network Solutions cost of sales, as a percent of that segment’s sales, decreased from 55.7% of sales in 2015 to 51.5% of sales in 2016. The decrease in Network Solutions cost of sales as a percentage of that segment’s sales is primarily attributable to a regional revenue shift and customer and product mix, partially offset by restructuring expenses and an increase in warranty expense related to a product recall caused by a defect in a part provided by a third party supplier.

[0001564590-18-003019:mdna:102]
Services & Support cost of sales, as a percent of that segment’s sales, increased from 54.1% of sales in 2015 to 67.2% of sales in 2016. The increase in Services & Support cost of sales as a percentage of that segment’s sales is primarily attributable to an increase in network installation services, which have higher costs than maintenance and support services, and in restructuring expenses.

[0001564590-18-003019:mdna:103]
An important part of our strategy is to reduce the product cost of each succeeding product generation and then to lower the product’s price based on the cost savings achieved. This may cause variations in our gross profit percentage due to timing differences between the recognition of cost reductions and the lowering of product selling prices.

[0001564590-18-003019:mdna:104]
Selling, General and Administrative Expenses

[0001564590-18-003019:mdna:105]
Selling, general and administrative expenses increased 6.7% from $123.5 million in 2015 to $131.8 million in 2016. Selling, general and administrative expenses include personnel costs for administration, finance, information systems, human resources, sales and marketing, and general management, as well as rent, utilities, legal and accounting expenses, bad debt expense, advertising, promotional material, trade show expenses, and related travel costs. The increase in selling, general and administrative expenses is primarily attributable to an increase in variable incentive compensation expense and use tax expense, partially offset by a decrease in professional services.

[0001564590-18-003019:mdna:106]
Selling, general and administrative expenses as a percentage of sales increased from 20.6% for the year ended December 31, 2015 to 20.7% for the year ended December 31, 2016. Selling, general and administrative expenses as a percentage of sales will generally fluctuate whenever there is a significant fluctuation in revenues for the periods being compared.

[0001564590-18-003019:mdna:107]
Research and Development Expenses

[0001564590-18-003019:mdna:108]
Research and development expenses decreased 3.9% from $129.9 million in 2015 to $124.8 million in 2016. The decrease in research and development expenses is primarily attributable to a decrease in compensation expense, lease expense and testing expense, partially offset by an increase in contract services. The decrease in compensation expense and lease expense in 2016 was primarily attributable to the consolidation of engineering resources that occurred during the second quarter of 2015.

[0001564590-18-003019:mdna:109]
Research and development expenses as a percentage of sales decreased from 21.6% for the year ended December 31, 2015 to 19.6% for the year ended December 31, 2016. Research and development expenses as a percentage of sales will fluctuate whenever there are incremental product development activities or a significant fluctuation in revenues for the periods being compared.

[0001564590-18-003019:mdna:110]
We expect to continue to incur research and development expenses in connection with our new and existing products and our expansion into international markets. We continually evaluate new product opportunities and engage in intensive research and product development efforts which provide for new product development, enhancement of existing products and product cost reductions. We may incur significant research and development expenses prior to the receipt of revenues from a major new product group.

[0001564590-18-003019:mdna:111]
Interest and Dividend Income

[0001564590-18-003019:mdna:112]
Interest and dividend income remained constant at $3.95 million in 2015 and $3.92 million in 2016.

[0001564590-18-003019:mdna:113]
Interest Expense

[0001564590-18-003019:mdna:114]
Interest expense, which is primarily related to our taxable revenue bond, remained consistent at $0.6 million in 2015 and 2016, as we had no substantial change in our fixed-rate borrowing. See “Financing Activities” in “Liquidity and Capital Resources” below for additional information on our taxable revenue bond.

[0001564590-18-003019:mdna:115]
Net Realized Investment Gain

[0001564590-18-003019:mdna:116]
Net realized investment gain decreased from $10.3 million in 2015 to $5.9 million in 2016. The decrease in realized investment gains is primarily attributable to fewer gains from the sale of equity securities in 2016. See “Investing Activities” in “Liquidity and Capital Resources” below for additional information.

[0001564590-18-003019:mdna:117]
Other Income (Expense), net

[0001564590-18-003019:mdna:118]
Other income (expense), net, comprised primarily of miscellaneous income, gains and losses resulting from foreign currency exchange rate movements, and investment account management fees, decreased from $1.5 million of expense in 2015 to $0.7 million of expense in 2016. The change is primarily attributable to gains on forward currency contracts during the fourth quarter of 2016.

[0001564590-18-003019:mdna:119]
Gain on Bargain Purchase of a Business

[0001564590-18-003019:mdna:120]
Gain on bargain purchase of a business is related to our acquisition of key fiber access products, technologies and service relationships from a third party on September 13, 2016. See Note 2 of Notes to Consolidated Financial Statements for additional information.

[0001564590-18-003019:mdna:121]
Income Taxes

[0001564590-18-003019:mdna:122]
Our effective tax rate decreased from 27.5% in 2015 to 24.9% in 2016. The decrease in the effective tax rate between the two periods is primarily attributable to the benefit associated with the bargain purchase gain.

[0001564590-18-003019:mdna:123]
Net Income

[0001564590-18-003019:mdna:124]
As a result of the above factors, net income increased from $18.6 million in 2015 to $35.2 million in 2016. As a percentage of sales, net income increased from 3.1% in 2015 to 5.5% in 2016.

[0001564590-18-003019:mdna:125]
Liquidity and Capital Resources

[0001564590-18-003019:mdna:126]
Liquidity

[0001564590-18-003019:mdna:127]
We intend to finance our operations with cash flow from operations. We have used, and expect to continue to use, the cash generated from operations for working capital, purchases of treasury stock, shareholder dividends, and other general corporate purposes, including (i) product development activities to enhance our existing products and develop new products and (ii) expansion of sales and marketing activities. We believe our cash and cash equivalents, investments and cash generated from operations to be adequate to meet our operating and capital needs for at least the next 12 months.

[0001564590-18-003019:mdna:128]
At December 31, 2017, cash on hand was $86.4 million and short-term investments were $16.1 million, which resulted in available short-term liquidity of $102.6 million, of which $56.8 million was held by our foreign subsidiaries. At December 31, 2016, cash on hand was $79.9 million and short-term investments were $43.2 million, which resulted in available short-term liquidity of $123.1 million, of which $42.1 million was held by our foreign subsidiaries. The decrease in short-term liquidity from December 31, 2016 to December 31, 2017 is primarily attributable to shifts among available investment option tenures to provide funds for our short-term cash needs.

[0001564590-18-003019:mdna:129]
Operating Activities

[0001564590-18-003019:mdna:130]
Our working capital, which consists of current assets less current liabilities, increased 35.3% from $226.4 million as of December 31, 2016 to $306.3 million as of December 31, 2017. The current ratio, defined as current assets divided by current liabilities, increased from 2.79 as of December 31, 2016 to 3.87 as of December 31, 2017. The increase in our working capital and current ratio is primarily attributable to an increase in accounts receivable, inventory, and other receivables, and a decrease in accounts payable and accrued wages and benefits. The quick ratio, defined as cash and cash equivalents, short-term investments, and net accounts receivable, divided by current liabilities, increased from 1.70 as of December 31, 2016 to 2.31 as of December 31, 2017. The increase in the quick ratio is primarily attributable to an increase in accounts receivable and a decrease in accounts payable and accrued wages and benefits. The decrease in accrued wages and benefits was primarily attributable to a decrease in accrued variable incentive compensation.

[0001564590-18-003019:mdna:131]
Net accounts receivable increased 56.1% from $92.3 million at December 31, 2016 to $144.2 million at December 31, 2017. We did not have an allowance for doubtful accounts at December 31, 2016 or 2017. Quarterly accounts receivable DSO increased from 52 days as of December 31, 2016 to 105 days as of December 31, 2017. The increase in net accounts receivable and DSO is attributable to customer specific payment terms that will become due early in the first quarter of 2018 and the timing of sales and collections during the quarter. Additionally, certain international customers can have longer payment terms than U.S. customers.

[0001564590-18-003019:mdna:132]
Other receivables increased 67.2% from $15.9 million at December 31, 2016 to $26.6 million at December 31, 2017. The increase in other receivables is primarily attributable to an increase in lease receivables and income tax receivables.

[0001564590-18-003019:mdna:133]
Annual inventory turnover decreased from 3.51 turns as of December 31, 2016 to 3.19 turns as of December 31, 2017. Inventory increased 16.6% from $105.1 million at December 31, 2016 to $122.5 million at December 31, 2017. We expect inventory levels to fluctuate as we attempt to maintain sufficient inventory in response to seasonal cycles of our business ensuring competitive lead times while managing the risk of inventory obsolescence that may occur due to rapidly changing technology and customer demand.

[0001564590-18-003019:mdna:134]
Accounts payable decreased 21.6% from $77.3 million at December 31, 2016 to $60.6 million at December 31, 2017. Accounts payable will fluctuate due to variations in the timing of the receipt of supplies, inventory and services and our subsequent payments for these purchases.

[0001564590-18-003019:mdna:135]
Investing Activities

[0001564590-18-003019:mdna:136]
Capital expenditures totaled approximately $14.7 million, $21.4 million and $11.8 million for the years ended December 31, 2017, 2016 and 2015, respectively. These expenditures were primarily used to purchase computer hardware, software, manufacturing and test equipment, and building improvements.

[0001564590-18-003019:mdna:137]
Our combined short-term and long-term investments decreased $72.9 million from $219.3 million at December 31, 2016 to $146.4 million at December 31, 2017. This decrease reflects the impact of our cash used by our operating activities, cash needs for share repurchases, shareholder dividends, equipment acquisitions, as well as net realized and unrealized losses, and amortization of net premiums on our combined investments, partially offset by funds provided by stock option exercises by our employees.

[0001564590-18-003019:mdna:138]
We invest all available cash not required for immediate use in operations primarily in securities that we believe bear minimal risk of loss. At December 31, 2017, these investments included corporate bonds of $32.5 million, municipal fixed-rate bonds of $2.9 million, asset-backed bonds of $6.5 million, mortgage/agency-backed bonds of $5.5 million, U.S. government bonds of $14.3 million, and foreign government bonds of $0.7 million. At December 31, 2016, these investments included corporate bonds of $66.4 million, municipal fixed-rate bonds of $11.8 million, asset-backed bonds of $10.2 million, mortgage/agency-backed bonds of $13.0 million, U.S. government bonds of $29.8 million, foreign government bonds of $3.7 million, and variable rate demand notes of $11.9 million. As of December 31, 2017, our corporate bonds, municipal fixed-rate bonds, asset-backed bonds, mortgage/agency-backed bonds, U.S. government bonds, and foreign government bonds were classified as available-for-sale and had a combined duration of 1.15 years with an average credit rating of A+. Because our bond portfolio has a high quality rating and contractual maturities of a short duration, we are able to obtain prices for these bonds derived from observable market inputs, or for similar securities traded in an active market, on a daily basis.

[0001564590-18-003019:mdna:139]
Our long-term investments decreased 26.0% from $176.1 million at December 31, 2016 to $130.3 million at December 31, 2017. Long-term investments at December 31, 2017 and December 31, 2016 included an investment in a certificate of deposit of $27.8 million, which serves as collateral for our revenue bond, as discussed below. We have investments in various marketable equity securities classified as long-term investments at a cost of $33.5 million and $30.6 million, and with a fair value of $35.7 million and $29.4 million, at December 31, 2017 and December 31, 2016, respectively.

[0001564590-18-003019:mdna:140]
Long-term investments at December 31, 2017 and 2016 also included $19.9 million and $14.6 million, respectively, related to our deferred compensation plan, and $0.5 million and $0.8 million, respectively, of other investments, consisting of interests in two private equity funds and an investment in a privately held telecommunications equipment manufacturer.

[0001564590-18-003019:mdna:141]
We review our investment portfolio for potential “other-than-temporary” declines in value on an individual investment basis. We assess, on a quarterly basis, significant declines in value which may be considered other-than-temporary and, if necessary, recognize and record the appropriate charge to write-down the carrying value of such investments. In making this assessment, we take into consideration qualitative and quantitative information, including but not limited to the following: the magnitude and duration of historical declines in market prices, credit rating activity, assessments of liquidity, public filings, and statements made by the issuer. We generally begin our identification of potential other-than-temporary impairments by reviewing any security with a fair value that has declined from its original or adjusted cost basis by 25% or more for six or more consecutive months. We then evaluate the individual security based on the previously identified factors to determine the amount of the write-down, if any. For the years ended December 31, 2017, 2016, and 2015, we recorded charges of $0.2 million, $0.8 million and $0.2 million, respectively, related to the other-than-temporary impairment of certain publicly traded equity securities, our deferred compensation plan assets, and our investments in two private equity funds.

[0001564590-18-003019:mdna:142]
Financing Activities

[0001564590-18-003019:mdna:143]
In conjunction with an expansion of our Huntsville, Alabama, facility, we were approved for participation in an incentive program offered by the State of Alabama Industrial Development Authority (the “Authority”). Pursuant to the program, on January 13, 1995, the Authority issued $20.0 million of its taxable revenue bonds and loaned the proceeds from the sale of the bonds to ADTRAN. The bonds were originally purchased by AmSouth Bank of Alabama, Birmingham, Alabama (the “Bank”). Wachovia Bank, N.A., Nashville, Tennessee (formerly First Union National Bank of Tennessee) (the “Bondholder”), which was acquired by Wells Fargo & Company on December 31, 2008, purchased the original bonds from the Bank and made further advances to the Authority, bringing the total amount outstanding to $50.0 million. An Amended and Restated Taxable Revenue Bond (“Amended and Restated Bond”) was issued and the original financing agreement was amended. The Amended and Restated Bond bears interest, payable monthly. The interest rate is 2% per annum. The Amended and Restated Bond matures on January 1, 2020, and is currently outstanding in the aggregate principal amount of $26.7 million. The estimated fair value of the bond using a level 2 valuation technique at December 31, 2017 was approximately $26.7 million, based on a debt security with a comparable interest rate and maturity and a Standard & Poor’s credit rating of AAA. We are required to make payments to the Authority in amounts necessary to pay the interest on the Amended and Restated Bond. Included in long-term investments at December 31, 2017 is $27.8 million which is invested in a restricted certificate of deposit. These funds serve as a collateral deposit against the principal of this bond, and we have the right to set-off the balance of the Bond with the collateral deposit in order to reduce the balance of the indebtedness.

[0001564590-18-003019:mdna:144]
In conjunction with this program, we are eligible to receive certain economic incentives from the state of Alabama that reduce the amount of payroll withholdings that we are required to remit to the state for those employment positions that qualify under the program. We realized economic incentives related to payroll withholdings totaling $1.5 million for the year ended December 31, 2017 and $1.3 million for each of the years ended December 31, 2016 and 2015.

[0001564590-18-003019:mdna:145]
We made principal payments of $1.1 million for each of the years ended December 31, 2017 and 2016, and we anticipate making a principal payment in 2018. At December 31, 2017, $1.1 million of the bond debt was classified as a current liability in accounts payable in the Consolidated Balance Sheets.

[0001564590-18-003019:mdna:146]
Dividends

[0001564590-18-003019:mdna:147]
During 2017, 2016 and 2015, we paid shareholder dividends totaling $17.4 million, $17.6 million and $18.4 million, respectively. The Board of Directors presently anticipates that it will declare a regular quarterly dividend so long as the present tax treatment of dividends exists and adequate levels of liquidity are maintained. The following table shows dividends per common share paid to our shareholders in each quarter of 2017, 2016 and 2015.

[0001564590-18-003019:mdna:148]
| Dividends per Common Share |  |
|  |  | 2017 |  |  | 2016 |  |  | 2015 |  |
| First Quarter |  | $ | 0.09 |  |  | $ | 0.09 |  |  | $ | 0.09 |  |
| Second Quarter |  | $ | 0.09 |  |  | $ | 0.09 |  |  | $ | 0.09 |  |
| Third Quarter |  | $ | 0.09 |  |  | $ | 0.09 |  |  | $ | 0.09 |  |
| Fourth Quarter |  | $ | 0.09 |  |  | $ | 0.09 |  |  | $ | 0.09 |  |

[0001564590-18-003019:mdna:149]
Stock Repurchase Program

[0001564590-18-003019:mdna:150]
Since 1997, our Board of Directors has approved multiple share repurchase programs that have authorized open market repurchase transactions of up to 50.0 million shares of our common stock, which will be implemented through open market or private purchases from time to time as conditions warrant. For the years 2017, 2016 and 2015, we repurchased 0.9 million shares, 1.4 million shares and 4.0 million shares, respectively, for a cost of $17.3 million, $25.8 million and $66.2 million, respectively, at an average price of $20.27, $18.29 and $16.68 per share, respectively. We currently have the authority to purchase an additional 3.6 million shares of our common stock under the current plans approved by the Board of Directors.

[0001564590-18-003019:mdna:151]
Stock Option Exercises

[0001564590-18-003019:mdna:152]
To accommodate employee stock option exercises, we issued 0.7 million shares of treasury stock for $13.4 million during the year ended December 31, 2017, 0.3 million shares of treasury stock for $4.7 million during the year ended December 31, 2016, and 0.1 million shares of treasury stock for $1.0 million during the year ended December 31, 2015.

[0001564590-18-003019:mdna:153]
Off-Balance Sheet Arrangements and Contractual Obligations

[0001564590-18-003019:mdna:154]
We do not have off-balance sheet financing arrangements and have not engaged in any related party transactions or arrangements with unconsolidated entities or other persons that are reasonably likely to materially affect liquidity or the availability of or requirements for capital resources.

[0001564590-18-003019:mdna:155]
We have various contractual obligations and commercial commitments. The following table sets forth, in millions, the annual payments we are required to make under contractual cash obligations and other commercial commitments at December 31, 2017.

[0001564590-18-003019:mdna:156]
Contractual Obligations

[0001564590-18-003019:mdna:157]
| (In millions) |  | Total |  |  | 2018 |  |  | 2019 |  |  | 2020 |  |  | 2021 |  |  | After 2021 |  |
| Long-term debt |  | $ | 26.7 |  |  | $ | 1.1 |  |  | $ | — |  |  | $ | 25.6 |  |  | $ | — |  |  | $ | — |  |
| Interest on long-term debt |  |  | 1.0 |  |  |  | 0.5 |  |  |  | 0.5 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Purchase obligations |  |  | 140.0 |  |  |  | 139.1 |  |  |  | 0.8 |  |  |  | 0.1 |  |  |  | — |  |  |  | — |  |
| Operating lease obligations |  |  | 8.5 |  |  |  | 3.1 |  |  |  | 0.9 |  |  |  | 0.8 |  |  |  | 0.8 |  |  |  | 2.9 |  |
| Tax Cuts and Jobs Act toll charge |  |  | 2.7 |  |  |  | 0.5 |  |  |  | 0.2 |  |  |  | 0.2 |  |  |  | 0.2 |  |  |  | 1.6 |  |
| Totals |  | $ | 178.9 |  |  | $ | 144.3 |  |  | $ | 2.4 |  |  | $ | 26.7 |  |  | $ | 1.0 |  |  | $ | 4.5 |  |

[0001564590-18-003019:mdna:158]
We are required to make payments necessary to pay the interest on the Amended and Restated Bond, currently outstanding in the aggregate principal amount of $26.7 million. The bond matures on January 1, 2020, and bears interest at the rate of 2% per annum. Included in long-term investments are $27.8 million of restricted funds, which is a collateral deposit against the principal amount of this bond. We made principal payments of $1.1 million for each of the years ended December 31, 2017 and 2016. We anticipate making a principal payment in 2018. At December 31, 2017, $1.1 million of the bond debt was classified as a current liability in accounts payable in the Consolidated Balance Sheets. See Note 10 of Notes to Consolidated Financial Statements for additional information.

[0001564590-18-003019:mdna:159]
Purchase obligations primarily relate to open purchase orders to our contract manufacturers, component suppliers, service partners, and other vendors.

[0001564590-18-003019:mdna:160]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, and we have contributed $8.4 million as of December 31, 2017, of which $7.7 million has been applied to these commitments. The additional $0.2 million commitment has been excluded from the table above due to uncertainty of when it will be applied.

[0001564590-18-003019:mdna:161]
We also have obligations related to uncertain income tax positions that have been excluded from the table above due to the uncertainty of when the related expense will be recognized. See Note 11 of Notes to Consolidated Financial Statements for additional information.

[0001564590-18-003019:mdna:162]
Recently Issued Accounting Pronouncements

[0001564590-18-003019:mdna:163]
In May 2014, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update No. 2014-09, Revenue from Contracts with Customers (Topic 606) (ASU 2014-09), which supersedes the revenue recognition requirements in Topic 605, Revenue Recognition, including most industry-specific revenue recognition guidance throughout the Industry Topics of the Codification. The core principle of ASU 2014-09 is to recognize revenues when promised goods or services are transferred to customers in an amount that reflects the consideration that is expected to be received for those goods or services. In August 2015, the FASB issued ASU 2015-14, which deferred the effective date of ASU 2014-09 to fiscal years beginning after December 31, 2017, and interim periods within those fiscal years, with early adoption permitted for reporting periods beginning after December 15, 2016. Subsequently, the FASB issued ASUs in 2016 containing implementation guidance related to ASU 2014-09, including: ASU 2016-08, Revenue from Contracts with Customers (Topic 606): Principal versus Agent Considerations (Reporting Revenue Gross versus Net), which is intended to improve the operability and understandability of the implementation guidance on principal versus agent considerations; ASU 2016-10, Revenue from Contracts with Customers (Topic 606): Identifying Performance Obligations and Licensing, which is intended to clarify two aspects of Topic 606: identifying performance obligations and the licensing implementation guidance; ASU 2016-12, Revenue from Contracts with Customers (Topic 606): Narrow-Scope Improvements and Practical Expedients, which contains certain provisions and practical expedients in response to identified implementation issues; and ASU 2016-20, Technical Corrections and Improvements to Topic 606, Revenue from Contracts with Customers, which is intended to clarify the Codification or to correct unintended application of guidance. ASU 2014-09 allows for either full retrospective or modified retrospective adoption. We adopted ASU 2014-09 and the related ASUs on January 1, 2018 using the modified retrospective method.

[0001564590-18-003019:mdna:164]
The two areas of impact of these ASUs are network installation service revenue performance obligations and contract costs. The output method will be used to measure network installation services progress. The primary impact will be the timing of revenue recognition for certain performance obligations related to service revenue arrangements that are currently deferred until customer acceptance.

[0001564590-18-003019:mdna:165]
In connection with the adoption of the new revenue standard, effective January 1, 2018, we adopted ASC 340-40, Other Assets and Deferred Costs - Contracts with Customers, with respect to capitalization and amortization of incremental costs of obtaining a contract. As a result, certain costs of obtaining a contract will need to be capitalized, including sales commissions, as the guidance requires the capitalization of all incremental costs incurred to obtain a contract with a customer that it would not have incurred if the contract had not been obtained, provided the costs are recoverable. The primary impact will be capitalization of certain sales commissions for our extended maintenance and support contracts in excess of one year and costs associated with our capital lease arrangements that are billed monthly, and amortization of those costs over the period that the related revenue is recognized.

[0001564590-18-003019:mdna:166]
We will recognize the cumulative adjustment for network installation service revenue performance obligations and contract costs to retained earnings during the three months ended March 31, 2018. We do not believe the cumulative adjustment will have a significant impact on our consolidated financial statements during 2018.

[0001564590-18-003019:mdna:167]
In February 2016, the FASB issued Accounting Standards Update No. 2016-02, Leases (Topic 842) (ASU 2016-02). ASU 2016-02 requires an entity to recognize lease assets and lease liabilities on the balance sheet and to disclose key information about the entity's leasing arrangements. ASU 2016-02 is effective for fiscal years beginning after December 15, 2018, and interim periods within those fiscal years. A modified retrospective approach is required. We anticipate the adoption of ASU 2016-02 will have a material impact on our financial position; however, we do not believe adoption will have a material impact on our results of operations. We believe the most significant impact relates to our accounting for operating leases for office space and equipment.

[0001564590-18-003019:mdna:168]
In January 2017, the FASB issued Accounting Standards Update No. 2017-04, Intangibles – Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment (ASU 2017-04). ASU 2017-04 simplifies the measurement of goodwill by eliminating step 2 of the goodwill impairment test. Under ASU 2017-04, entities will be required to compare the fair value of a reporting unit to its carrying amount and recognize an impairment charge for the amount by which the carrying amount exceeds the reporting unit’s fair value. ASU 2017-04 is effective for annual or interim impairment tests performed in fiscal years beginning after December 15, 2019, with early adoption permitted for annual or interim impairment tests performed on testing dates after January 1, 2017. The amendments should be applied prospectively. We are currently evaluating whether to early adopt ASU 2017-04, but we do not expect it will have a material impact on our financial position, results of operations or cash flows.

[0001564590-18-003019:mdna:169]
In March 2017, the FASB issued Accounting Standards Update No. 2017-07, Compensation – Retirement Benefits (Topic 715): Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost (ASU 2017-07). ASU 2017-07 amends ASC 715, Compensation — Retirement Benefits, to require employers that present a measure of operating income in their statements of earnings to include only the service cost component of net periodic pension cost and net periodic postretirement benefit cost in operating expenses (together with other employee compensation costs). The other components of net benefit cost, including amortization of prior service cost/credit, and settlement and curtailment effects, are to be included in non-operating expenses. ASU 2017-07 is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2017. We adopted ASU 2017-07 on January 1, 2018 and we do not expect ASU 2017-07 will have a material impact on our financial position, results of operations or cash flows.

[0001564590-18-003019:mdna:170]
In August 2017, the FASB issued Accounting Standards Update No. 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities (ASU 2017-12). ASU 2017-12 expands and refines hedge accounting for both financial and non-financial risk components, aligns the recognition and presentation of the effects of hedging instruments and hedge items in the financial statements, and includes certain targeted improvements to ease the application of current guidance related to the assessment of hedge effectiveness. ASU 2017-12 is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2018, with early adoption permitted. We are currently evaluating the impact ASU 2017-12 will have on our financial position, results of operations and cash flows.

[0001564590-18-003019:mdna:171]
During 2017, we adopted the following accounting standards, which had no material effect on our financial position, results of operations or cash flows:

[0001564590-18-003019:mdna:172]
In July 2015, the FASB issued Accounting Standards Update No. 2015-11, Inventory (Topic 330): Simplifying the Measurement of Inventory (ASU 2015-11). Currently, Topic 330, Inventory, requires an entity to measure inventory at the lower of cost or market. Market could be replacement cost, net realizable value, or net realizable value less an approximately normal profit margin. ASU 2015-11 does not apply to inventory that is measured using last-in, first-out (LIFO) or the retail inventory method. The amendments apply to all other inventory, which includes inventory that is measured using first-in, first-out (FIFO) or average cost. ASU 2015-11 requires an entity to measure in scope inventory at the lower of cost and net realizable value. Net realizable value is the estimated selling prices in the ordinary course of business, less reasonably predictable costs of completion, disposal, and transportation. ASU 2015-11 is effective for annual reporting periods beginning after December 15, 2016, including interim periods within that reporting period. The amendments should be applied prospectively with earlier application permitted as of the beginning of an interim or annual reporting period. We adopted ASU 2015-11 in the first quarter of 2017, and there was no material impact on our financial position, results of operations or cash flows.

[0001564590-18-003019:mdna:173]
In January 2017, we adopted ASU 2016-09, Compensation – Stock Compensation (Topic 718): Improvements to Employee Share-Based Payment Accounting. As a result, beginning in the first quarter of 2017, we began recognizing all excess tax benefits and tax deficiencies as income tax expense or benefit as a discrete event. The treatment of forfeitures has changed as we have elected to discontinue our past practice of estimating forfeitures and now account for forfeitures as they occur. As a result, we recorded an increase in additional paid in capital of $0.1 million, a charge to beginning retained earnings of $0.1 million, and an increase in the deferred tax assets related to non-qualified stock options and RSUs of $10 thousand. In addition, cash flows related to excess tax benefits will no longer be separately classified as a financing activity apart from other income tax cash flows within operating activities. We elected to retrospectively apply the changes in presentation to the statements of cash flows and no longer classify excess tax benefits as a financing activity, which had an immaterial impact on our cash flows for the years ended December 31, 2017, 2016 and 2015. There was no material impact on our financial position, results of operations or cash flows as a result of these changes.

[0001564590-18-003019:mdna:174]
Subsequent Events

[0001564590-18-003019:mdna:175]
On January 16, 2018, the Board declared a quarterly cash dividend of $0.09 per common share to be paid to shareholders of record at the close of business on January 31, 2018. The quarterly dividend payment was $4.4 million and was paid on February 14, 2018. In July 2003, our Board of Directors elected to begin declaring quarterly dividends on our common stock considering the tax treatment of dividends and adequate levels of Company liquidity.

[0001564590-18-003019:mdna:176]
During the first quarter and as of February 23, 2018, we have repurchased 0.6 million shares of our common stock through open market purchases at an average cost of $16.18 per share. We currently have the authority to purchase an additional 2.9 million shares of our common stock under the current plan approved by the Board of Directors.

[0001564590-18-003019:mdna:177]
In January 2018, we announced an early retirement incentive program for employees that met certain requirements. The estimated liability associated with this program ranges from $3.6 to $14.3 million.
