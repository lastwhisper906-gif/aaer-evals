# ADTN 10-K controls and the auditor's report


## auditors_report

10-K auditors_report: 2 candidate headings, none whose body matches 'critical audit matter'.


## item_9a

[0001193125-14-071988:item_9a:1]
| ITEM 9A. | CONTROLS AND PROCEDURES |

[0001193125-14-071988:item_9a:2]
| (a) | Internal control over financial reporting. Section 404 of the Sarbanes-Oxley Act of 2002 requires management to include in this Annual Report on Form 10-K a report on management’s assessment of the effectiveness of our internal control over financial reporting, as well as a report from our independent registered public accounting firm on the effectiveness of internal control over financial reporting. Management’s report on internal control over financial reporting and the related report from our independent registered public accounting firm are located in Item 8 “Financial Statements and Supplementary Data” of this report. |

[0001193125-14-071988:item_9a:3]
| (b) | Evaluation of disclosure controls and procedures. Our Chief Executive Officer and Chief Financial Officer are responsible for establishing and maintaining “disclosure controls and procedures” (as defined in the Securities Exchange Act of 1934 Rules 13a-15(e) and 15d-15(e)) for the company. Our Chief Executive Officer and Chief Financial Officer, after evaluating the effectiveness of our disclosure controls and procedures as of the end of the period covered by this annual report, have concluded that our disclosure controls and procedures are effective. |

[0001193125-14-071988:item_9a:4]
| (c) | Changes in internal control over financial reporting. There were no changes in our internal control over financial reporting that occurred during our most recent fiscal quarter that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting. |
