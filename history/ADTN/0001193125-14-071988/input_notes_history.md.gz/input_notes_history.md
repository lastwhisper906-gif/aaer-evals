# ADTN note change history — 0001193125-13-312256 → 0001193125-13-422365


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2013-11-01):
[0001193125-13-422365:note_history:1]
We have
 committed to invest up to an aggregate of $7.9 million in two
 private equity funds, and we have contributed $8.4 million as of
 September 30, 2013, of which $7.7 million has been applied to
 these commitments.
  (was, 2013-07-31, similarity 0.9726):
[0001193125-13-312256:note_history:1]
We have committed to invest
up to an aggregate of $7.9 million in two private equity funds, and
we have contributed $8.4 million as of June 30, 2013, of which
$7.7 million has been applied to these commitments.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2013-11-01):
[0001193125-13-422365:note_history:2]
In the opinion of management, all adjustments necessary for a fair
 presentation of these interim statements have been recorded,
 including the out of period adjustment discussed below. The results
 of operations for an interim period are not necessarily indicative
 of the results for the full year. The interim statements should be
 read in conjunction with the financial statements and notes thereto
 included in ADTRAN’s Annual Report on Form 10-K for the year
 ended December 31, 2012, filed on February 28, 2013 with
 the SEC.
  (was, 2013-07-31, similarity 0.8959):
[0001193125-13-312256:note_history:2]
In the
opinion of management, all adjustments necessary for a fair
presentation of these interim statements have been included and are
of a normal and recurring nature. The results of operations for an
interim period are not necessarily indicative of the results for
the full year. The interim statements should be read in conjunction
with the financial statements and notes thereto included in
ADTRAN’s Annual Report on Form 10-K for the year ended
December 31, 2012, filed on February 28, 2013 with the
SEC.

- added (2013-11-01):
[0001193125-13-422365:note_history:3]
Out of Period Adjustment

- added (2013-11-01):
[0001193125-13-422365:note_history:4]
During the three months ended September 30, 2013, we
 identified two adjustments in the acquired Nokia Siemens Networks
 Broadband Access business (NSN BBA business) relating to customer
 payment discounts for one customer, and recoverable VAT taxes on
 certain vendor freight invoices that should have been recorded in
 prior periods. These adjustments resulted from a $0.4 million
 understatement of net income in 2012 and $0.5 million
 understatement of net income in the first two quarters of 2013. We
 evaluated the impact of the adjustments on the results of our
 previously issued financial statements for each of the prior
 periods affected and concluded that the impact was not material. We
 also evaluated the impact of the cumulative effect of the
 adjustments in the current year and concluded that the impact is
 not material to our projected results for the year 2013.
 Accordingly, during the three months ended September 30, 2013
 we recorded an out of period adjustment to correct these
 issues.

- changed (2013-11-01):
[0001193125-13-422365:note_history:5]
During the nine months ended September 30, 2013, we adopted
 the following accounting standard, which had no material effect on
 our consolidated results of operations or financial condition:
  (was, 2013-07-31, similarity 0.9556):
[0001193125-13-312256:note_history:5]
During the
six months ended June 30, 2013, we adopted the following
accounting standard, which had no material effect on our
consolidated results of operations or financial
condition:

- changed (2013-11-01):
[0001193125-13-422365:note_history:6]
In February 2013, the FASB issued Accounting Standards Update
 No. 2013-02, Reporting of Amounts Reclassified Out of
 Accumulated Other Comprehensive Income (ASU 2013-02). ASU 2013-02
 requires entities to provide information about the amounts
 reclassified out of accumulated other comprehensive income by
 component either on the face of the financial statements or in the
 footnotes. ASU 2013-02 does not change the current requirements for
 reporting net income or other comprehensive income in the financial
 statements. This update is effective prospectively for reporting
 periods beginning after December 15, 2012. We adopted this
 amendment during the first quarter of 2013, and we have provided
 the disclosures required for the periods ended September 30,
 2013 and 2012 in Note 10 of Notes to Consolidated Financial
 Statements.
  (was, 2013-07-31, similarity 0.9917):
[0001193125-13-312256:note_history:6]
In February
2013, the FASB issued Accounting Standards Update No. 2013-02,
Reporting of Amounts Reclassified Out of Accumulated Other
Comprehensive Income (ASU 2013-02). ASU 2013-02 requires entities
to provide information about the amounts reclassified out of
accumulated other comprehensive income by component either on the
face of the financial statements or in the footnotes. ASU 2013-02
does not change the current requirements for reporting net income
or other comprehensive income in the financial statements. This
update is effective prospectively for reporting periods beginning
after December 15, 2012. We adopted this amendment during the
first quarter of 2013, and we have provided the disclosures
required for the periods ended June 30, 2013 and 2012 in Note
10 of Notes to Consolidated Financial Statements.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2013-11-01):
[0001193125-13-422365:note_history:7]
At September 30, 2013, we held the following securities and
 investments, recorded at either fair value or cost.
  (was, 2013-07-31, similarity 0.9463):
[0001193125-13-312256:note_history:7]
At
June 30, 2013, we held the following securities and
investments, recorded at either fair value or cost.

- changed (2013-11-01):
[0001193125-13-422365:note_history:8]
As of September 30, 2013, our corporate bonds and municipal
 fixed-rate bonds had the following contractual maturities:
  (was, 2013-07-31, similarity 0.9498):
[0001193125-13-312256:note_history:8]
As of
June 30, 2013, our corporate bonds and municipal fixed-rate
bonds had the following contractual maturities:

- changed (2013-11-01):
[0001193125-13-422365:note_history:9]
At September 30, 2013, we held a $48.3 million restricted
 certificate of deposit, which is carried at cost. This investment
 serves as a collateral deposit against the principal amount
 outstanding under loans made to ADTRAN pursuant to an Alabama State
 Industrial Development Authority revenue bond (the Bond). At
 September 30, 2013, the estimated fair value of the Bond using
 a level 2 valuation technique was approximately $44.9 million,
 based on a debt security with a comparable interest rate and
 maturity and a Standard and Poor’s credit rating of A-. For
 more information on the Bond, see “Debt” under
 “Liquidity and Capital Resources” in the
 “Management’s Discussion and Analysis of Financial
 Condition and Results of Operations” contained in Item 2
 of Part I of this report.
  (was, 2013-07-31, similarity 0.9581):
[0001193125-13-312256:note_history:9]
At
June 30, 2013, we held a $48.3 million restricted certificate
of deposit, which is carried at cost. This investment serves as a
collateral deposit against the principal amount outstanding under
loans made to ADTRAN pursuant to an Alabama State Industrial
Development Authority revenue bond (the Bond). At June 30,
2013, the estimated fair value of the Bond was approximately $46.3
million, based on a debt security with a comparable interest rate
and maturity and a Standard and Poor’s credit rating of A-.
For more information on the Bond, see “Debt” under
“Liquidity and Capital Resources” in the
“Management’s Discussion and Analysis of Financial
Condition and Results of Operations” contained in Item 2
of Part I of this report.

- changed (2013-11-01):
[0001193125-13-422365:note_history:10]
We review our investment portfolio for potential
 “other-than-temporary” declines in value on an
 individual investment basis. We assess, on a quarterly basis,
 significant declines in value which may be considered
 other-than-temporary and, if necessary, recognize and record the
 appropriate charge to write-down the carrying value of such
 investments. In making this assessment, we take into consideration
 qualitative and quantitative information, including but not limited
 to the following: the magnitude and duration of historical declines
 in market prices, credit rating activity, assessments of liquidity,
 public filings, and statements made by the issuer. We generally
 begin our identification of potential other-than-temporary
 impairments by reviewing any security with a fair value that has
 declined from its original or adjusted cost basis by 25% or more
 for six or more consecutive months. We then evaluate the individual
 security based on the previously identified factors to determine
 the amount of the write-down, if any. As a result of our review, we
 recorded an other-than-temporary impairment charge of $13 thousand
 during the nine months ended September 30, 2013 related to
 five marketable securities. For the nine months ended
 September 30, 2012, we recorded an other-than-temporary
 impairment charge of $0.1 million related to 21 marketable equity
 securities.
  (was, 2013-07-31, similarity 0.9188):
[0001193125-13-312256:note_history:10]
We review our
investment portfolio for potential
“other-than-temporary” declines in value on an
individual investment basis. We assess, on a quarterly basis,
significant declines in value which may be considered
other-than-temporary and, if necessary, recognize and record the
appropriate charge to write-down the carrying value of such
investments. In making this assessment, we take into consideration
qualitative and quantitative information, including but not limited
to the following: the magnitude and duration of historical declines
in market prices, credit rating activity, assessments of liquidity,
public filings, and statements made by the issuer. We generally
begin our identification of potential other-than-temporary
impairments by reviewing any security with a fair value that has
declined from its original or adjusted cost basis by 25% or more
for six or more consecutive months. We then evaluate the individual
security based on the previously identified factors to determine
the amount of the write-down, if any. As a result of our review, we
recorded an other-than-temporary impairment charge of $4 thousand
during the six months ended June 30, 2013 related to one
marketable security. For the six months ended June 30, 2012,
we recorded an other-than-temporary impairment charge of $33
thousand related to eight marketable equity securities.

- changed (2013-11-01):
[0001193125-13-422365:note_history:11]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
| Gross realized gains |  | $ | 1,797 |  |  | $ | 3,388 |  |  | $ | 7,252 |  |  | $ | 8,688 |  |
| Gross realized losses |  | $ | (46 | ) |  | $ | (858 | ) |  | $ | (303 | ) |  | $ | (1,335 | ) |
  (was, 2013-07-31, similarity 0.86):
[0001193125-13-312256:note_history:11]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
| Gross realized gains |  | $ | 1,728 |  |  | $ | 2,631 |  |  | $ | 5,455 |  |  | $ | 5,300 |  |
| Gross realized losses |  | $ | (175 | ) |  | $ | (275 | ) |  | $ | (257 | ) |  | $ | (477 | ) |

- changed (2013-11-01):
[0001193125-13-422365:note_history:12]
As of September 30, 2013 and 2012, gross unrealized losses
 related to individual securities in a continuous loss position for
 12 months or longer were not significant.
  (was, 2013-07-31, similarity 0.9644):
[0001193125-13-312256:note_history:12]
As of
June 30, 2013 and 2012, gross unrealized losses related to
individual securities in a continuous loss position for 12 months
or longer were not significant.

- changed (2013-11-01):
[0001193125-13-422365:note_history:13]
|  |  | Fair Value Measurements at September 30, 2013 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 6,594 |  |  | $ | 6,594 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 13,780 |  |  |  | 13,780 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 178,141 |  |  |  | — |  |  |  | 178,141 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 145,935 |  |  |  | — |  |  |  | 145,935 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 11,960 |  |  |  | — |  |  |  | 11,960 |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity securities – technology industry |  |  | 9,973 |  |  |  | 9,973 |  |  |  | — |  |  |  | — |  |
| Equity securities – other |  |  | 24,970 |  |  |  | 24,970 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 384,759 |  |  |  | 48,723 |  |  |  | 336,036 |  |  |  | — |  |
| Total |  | $ | 391,353 |  |  | $ | 55,317 |  |  | $ | 336,036 |  |  | $ | — |  |
  (was, 2013-07-31, similarity 0.9945):
[0001193125-13-312256:note_history:13]
|  |  | Fair Value Measurements at June 30, 2013 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,339 |  |  | $ | 1,339 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 12,792 |  |  |  | 12,792 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 187,930 |  |  |  | — |  |  |  | 187,930 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 155,481 |  |  |  | — |  |  |  | 155,481 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 7,120 |  |  |  | — |  |  |  | 7,120 |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity securities – technology industry |  |  | 7,818 |  |  |  | 7,818 |  |  |  | — |  |  |  | — |  |
| Equity securities – other |  |  | 24,032 |  |  |  | 24,032 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 395,173 |  |  |  | 44,642 |  |  |  | 350,531 |  |  |  | — |  |
| Total |  | $ | 396,512 |  |  | $ | 45,981 |  |  | $ | 350,531 |  |  | $ | — |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2013-11-01):
[0001193125-13-422365:note_history:14]
We employ the
 law firm of our director emeritus for legal services. All bills for
 services rendered by this firm are reviewed and approved by our
 Chief Financial Officer. We believe that the fees for such services
 are comparable to those charged by other firms for services
 rendered to us. For the three and nine month periods ended
 September 30, 2013 and 2012, we incurred fees of $10 thousand
 per month for these legal services.
  (was, 2013-07-31, similarity 0.9257):
[0001193125-13-312256:note_history:14]
We employ the law firm of
our director emeritus for legal services. All bills for services
rendered by this firm are reviewed and approved by our Chief
Financial Officer. We believe that the fees for such services are
comparable to those charged by other firms for services rendered to
us. For the three and six month periods ended June 30, 2013
and 2012, we incurred fees of $10 thousand per month for these
legal services.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2013-11-01):
[0001193125-13-422365:note_history:15]
On October 8, 2013, we announced that our Board of Directors
 declared a quarterly cash dividend of $0.09 per common share to be
 paid to stockholders of record at the close of business on
 October 24, 2013. The payment date will be November 7,
 2013. The quarterly dividend payment will be approximately $5.2
 million. In July 2003, our Board of Directors elected to begin
 declaring quarterly dividends on our common stock considering the
 tax treatment of dividends and adequate levels of Company
 liquidity.

- added (2013-11-01):
[0001193125-13-422365:note_history:16]
During the fourth quarter of 2013 and as of November 1, 2013,
 we repurchased 0.4 million shares of our common stock through
 open market purchases at an average cost of $23.85 per share. We
 currently have the authority to purchase an additional 3.9 million
 shares of our common stock under the current plan approved by the
 Board of Directors.

- removed (2013-11-01):
[0001193125-13-312256:note_history:17]
On
July 9, 2013, we announced that our Board of Directors
declared a quarterly cash dividend of $0.09 per common share to be
paid to stockholders of record at the close of business on
July 25, 2013. The payment date will be August 8, 2013.
The quarterly dividend payment will be approximately $5.2 million.
In July 2003, our Board of Directors elected to begin declaring
quarterly dividends on our common stock considering the tax
treatment of dividends and adequate levels of Company
liquidity.
