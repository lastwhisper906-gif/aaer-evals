# ADTN notes — 0001193125-14-071988


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-14-071988:notes:1]
Note 3 – Stock
 Incentive Plans

[0001193125-14-071988:notes:2]
Stock Incentive Program
 Descriptions

[0001193125-14-071988:notes:3]
Our Board of Directors
 adopted the 1996 Employee Incentive Stock Option Plan (1996 Plan)
 effective February 14, 1996, as amended, under which
 17.0 million shares of common stock were authorized for
 issuance to certain employees and officers through incentive stock
 options and non-qualified stock options. Options granted under the
 1996 Plan typically become exercisable beginning after one year of
 continued employment, normally pursuant to a four or five-year
 vesting schedule beginning on the first anniversary of the grant
 date, and have a ten-year contractual term. The 1996 Plan expired
 February 14, 2006, and expiration dates of options outstanding
 at December 31, 2013 under the 1996 Plan range from 2014 to
 2015.

[0001193125-14-071988:notes:4]
On January 23, 2006,
 the Board of Directors adopted the 2006 Employee Stock Incentive
 Plan (2006 Plan), which authorizes 13.0 million shares of
 common stock for issuance to certain employees and officers through
 incentive stock options and non-qualified stock options, stock
 appreciation rights, restricted stock and restricted stock units.
 The 2006 Plan was adopted by stockholder approval at our annual
 meeting of stockholders held on May 9, 2006. Options granted
 under the 2006 Plan typically become exercisable beginning after
 one year of continued employment, normally pursuant to a four-year
 vesting schedule beginning on the first anniversary of the grant
 date, and have a ten-year contractual term. Expiration dates of
 options outstanding at December 31, 2013 under the 2006 Plan
 range from 2016 to 2023.

[0001193125-14-071988:notes:5]
Our stockholders approved
 the 2010 Directors Stock Plan (2010 Directors Plan) on May 5,
 2010, under which 0.5 million shares of common stock have been
 reserved. This plan replaces the 2005 Directors Stock Option Plan.
 The 2010 Directors Plan provides that the Company may issue stock
 options, restricted stock and restricted stock units to our
 non-employee directors. Stock awards issued under the 2010
 Directors Plan normally become vested in full on the first
 anniversary of the grant date. Options issued under the 2010
 Directors Plan have a ten-year contractual term. We currently also
 have options outstanding under the 1995 Directors Plan, as amended,
 and the 2005 Directors Stock Option Plan. Expiration dates of
 options outstanding under both plans at December 31, 2013
 range from 2014 to 2019.

[0001193125-14-071988:notes:6]
The following table is a
 summary of our stock options outstanding as of December 31,
 2012 and 2013 and the changes that occurred during 2013:

[0001193125-14-071988:notes:7]
| (In thousands, except per share amounts) |  | Number of Options |  |  | Weighted Average Exercise Price |  |  | Weighted Avg. Remaining Contractual Life in Years |  |  | Aggregate Intrinsic Value |  |
| Options outstanding, December 31, 2012 |  |  | 6,035 |  |  | $ | 24.81 |  |  |  | 6.69 |  |  | $ | 5,154 |  |
| Options granted |  |  | 1,005 |  |  | $ | 23.64 |  |  |  |  |  |  |  |  |  |
| Options cancelled/forfeited |  |  | (491 | ) |  | $ | 29.60 |  |  |  |  |  |  |  |  |  |
| Options exercised |  |  | (191 | ) |  | $ | 19.07 |  |  |  |  |  |  |  |  |  |
| Options outstanding, December 31, 2013 |  |  | 6,358 |  |  | $ | 24.43 |  |  |  | 6.60 |  |  | $ | 25,878 |  |
| Options exercisable, December 31, 2013 |  |  | 3,911 |  |  | $ | 24.75 |  |  |  | 5.19 |  |  | $ | 15,336 |  |

[0001193125-14-071988:notes:8]
All of the options above
 were issued at exercise prices that approximate fair market value
 at the date of grant. At December 31, 2013, 6.0 million
 options were available for grant under the shareholder approved
 plans.

[0001193125-14-071988:notes:9]
The aggregate intrinsic
 values in the table above represent the total pre-tax intrinsic
 value (the difference between ADTRAN’s closing stock price on
 the last trading day of 2013 and the exercise price, multiplied by
 the number of in-the-money options) that would have been received
 by the option holders had all option holders exercised their
 options on December 31, 2013. The amount of aggregate
 intrinsic value will change based on the fair market value of
 ADTRAN’s stock.

[0001193125-14-071988:notes:10]
The total pre-tax intrinsic
 value of options exercised during 2013, 2012 and 2011 was $1.1
 million, $4.5 million and $39.8 million, respectively. The fair
 value of options fully vesting during 2013, 2012 and 2011 was $7.7
 million, $7.7 million and $7.3 million, respectively.

[0001193125-14-071988:notes:11]
The following table further
 describes our stock options outstanding as of December 31,
 2013:

[0001193125-14-071988:notes:12]
|  |  | Options Outstanding |  |  | Options Exercisable |  |
| Range of Exercise Prices |  | Options Outstanding at 12/31/13 (In thousands) |  |  | Weighted Avg. Remaining Contractual Life in Years |  |  | Weighted Average Exercise Price |  |  | Options Exercisable at 12/31/13 (In thousands) |  |  | Weighted Average Exercise Price |  |
| $14.88 – 18.07 |  |  | 1,456 |  |  |  | 7.42 |  |  | $ | 16.37 |  |  |  | 742 |  |  | $ | 15.79 |  |
| $18.08 – 23.36 |  |  | 1,002 |  |  |  | 3.04 |  |  | $ | 22.59 |  |  |  | 1,001 |  |  | $ | 22.59 |  |
| $23.37 – 26.06 |  |  | 1,745 |  |  |  | 8.10 |  |  | $ | 23.60 |  |  |  | 745 |  |  | $ | 23.54 |  |
| $26.07 – 30.04 |  |  | 466 |  |  |  | 3.59 |  |  | $ | 29.39 |  |  |  | 383 |  |  | $ | 29.71 |  |
| $30.05 – 30.36 |  |  | 905 |  |  |  | 7.67 |  |  | $ | 30.36 |  |  |  | 454 |  |  | $ | 30.36 |  |
| $30.37 – 41.92 |  |  | 784 |  |  |  | 6.84 |  |  | $ | 33.78 |  |  |  | 586 |  |  | $ | 33.76 |  |
|  |  |  | 6,358 |  |  |  |  |  |  |  |  |  |  |  | 3,911 |  |  |  |  |  |

[0001193125-14-071988:notes:13]
Restricted Stock Program
 Description

[0001193125-14-071988:notes:14]
On November 6, 2008,
 the Compensation Committee of the Board of Directors approved the
 Performance Shares Agreement under the 2006 Plan which sets forth
 the terms and conditions of awards of performance-based restricted
 stock units (RSUs). Of the 13.0 million shares of common stock
 authorized for issuance under the 2006 Plan, we may grant up to
 5.0 million shares of common stock for issuance to certain
 employees and officers for awards other than stock options, which
 would include RSUs. Under a proposal that was approved by the Board
 of Directors and shareholders at the 2010 annual meeting, the
 number of shares available for awards other than stock options
 under all stock plans was reduced to 3.3 million. The number of
 shares of common stock earned by a recipient pursuant to the RSUs
 is subject to a market condition based on ADTRAN’s relative
 total shareholder return against all companies in the NASDAQ
 Telecommunications Index at the end of a three-year performance
 period. Depending on the relative total shareholder return over the
 performance period, the recipient may earn from 0% to 150% of the
 shares underlying the RSUs, with the shares earned distributed upon
 the vesting of the RSUs at the end of the three-year performance
 period. The fair value of the award is based on the market price of
 our common stock on the date of grant, adjusted for the expected
 outcome of the impact of market conditions using a Monte Carlo
 Simulation valuation method. A portion of the granted RSUs also
 vest and the underlying shares become deliverable upon the death or
 disability of the recipient or upon a change of control of ADTRAN,
 as defined by the 2006 Plan. The recipients of the RSUs receive
 dividend credits based on the shares of common stock underlying the
 RSUs. The dividend credits are vested and earned in the same manner
 as the RSUs and will be paid in cash upon the issuance of common
 stock for the RSUs.

[0001193125-14-071988:notes:15]
The following table is a
 summary of our RSUs and restricted stock outstanding as of
 December 31, 2012 and 2013 and the changes that occurred
 during 2013:

[0001193125-14-071988:notes:16]
| (In thousands, except per share amounts) |  | Number of shares |  |  | Weighted Average Grant Date Fair Value |  |
| Unvested RSUs and restricted stock outstanding, December 31, 2012 |  |  | 103 |  |  | $ | 29.25 |  |
| RSUs and restricted stock granted |  |  | 41 |  |  | $ | 27.47 |  |
| RSUs and restricted stock vested |  |  | (39 | ) |  | $ | 29.42 |  |
| Adjustments to shares granted due to shares earned at vesting |  |  | (10 | ) |  | $ | 39.21 |  |
| Unvested RSUs and restricted stock outstanding, December 31, 2013 |  |  | 95 |  |  | $ | 28.38 |  |

[0001193125-14-071988:notes:17]
At December 31, 2013,
 total compensation cost related to the non-vested portion of RSUs
 and restricted stock not yet recognized was approximately $1.7
 million, which is expected to be recognized over an average
 remaining recognition period of 1.9 years.

[0001193125-14-071988:notes:18]
Valuation and Expense
 Information

[0001193125-14-071988:notes:19]
We use the Black-Scholes
 option pricing model (Black-Scholes Model) for the purpose of
 determining the estimated fair value of stock option awards on the
 date of grant. The Black-Scholes Model requires the input of
 certain assumptions that involve judgment. Because our stock
 options have characteristics significantly different from those of
 traded options, and because changes in the input assumptions can
 materially affect the fair value estimate, existing models may not
 provide reliable measures of fair value of our stock options. We
 use a Monte Carlo Simulation valuation method to value our
 performance-based RSUs. The fair value of restricted stock issued
 is equal to the closing price of our stock on the date of grant. We
 will continue to assess the assumptions and methodologies used to
 calculate the estimated fair value of stock-based compensation. If
 circumstances change, and additional data becomes available over
 time, we may change our assumptions and methodologies, which may
 materially impact our fair value determination.

[0001193125-14-071988:notes:20]
The following table
 summarizes stock-based compensation expense related to stock
 options, RSUs and restricted stock for the years ended
 December 31, 2013, 2012 and 2011, which was recognized as
 follows:

[0001193125-14-071988:notes:21]
| (In thousands) |  | 2013 |  |  | 2012 |  |  | 2011 |  |
| Stock-based compensation expense included in cost of sales |  | $ | 465 |  |  | $ | 422 |  |  | $ | 412 |  |
| Selling, general and administrative expense |  |  | 4,443 |  |  |  | 4,351 |  |  |  | 4,316 |  |
| Research and development expense |  |  | 4,165 |  |  |  | 4,491 |  |  |  | 4,441 |  |
| Stock-based compensation expense included in operating expenses |  |  | 8,608 |  |  |  | 8,842 |  |  |  | 8,757 |  |
| Total stock-based compensation expense |  |  | 9,073 |  |  |  | 9,264 |  |  |  | 9,169 |  |
| Tax benefit for expense associated with non-qualified options |  |  | (1,298 | ) |  |  | (1,234 | ) |  |  | (1,321 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 7,775 |  |  | $ | 8,030 |  |  | $ | 7,848 |  |

[0001193125-14-071988:notes:22]
At December 31, 2013,
 total compensation cost related to non-vested stock options not yet
 recognized was approximately $17.1 million, which is expected to be
 recognized over an average remaining recognition period of 2.8
 years.

[0001193125-14-071988:notes:23]
The stock option pricing
 model requires the use of several assumptions that impact the fair
 value estimate. These variables include, but are not limited to,
 the volatility of our stock price and employee exercise behaviors.
 There were no material changes made during 2013 to the methodology
 used to determine our assumptions.

[0001193125-14-071988:notes:24]
The weighted-average
 estimated fair value of stock options granted to employees and
 directors during the years ended December 31, 2013, 2012 and
 2011 was $8.35 per share, $5.60 per share and $9.53 per share,
 respectively, with the following weighted-average
 assumptions:

[0001193125-14-071988:notes:25]
|  |  | 2013 |  |  | 2012 |  |  | 2011 |  |
| Expected volatility |  |  | 39.92 | % |  |  | 39.46 | % |  |  | 38.32 | % |
| Risk-free interest rate |  |  | 1.71 | % |  |  | 0.96 | % |  |  | 1.01 | % |
| Expected dividend yield |  |  | 1.52 | % |  |  | 2.05 | % |  |  | 1.19 | % |
| Expected life (in years) |  |  | 6.36 |  |  |  | 6.18 |  |  |  | 5.15 |  |

[0001193125-14-071988:notes:26]
We based our estimate of
 expected volatility for the years ended December 31, 2013,
 2012 and 2011 on the sequential historical daily trading data of
 our common stock for a period equal to the expected life of the
 options granted. The selection of the historical volatility method
 was based on available data indicating our historical volatility is
 as equally representative of our future stock price trends as is
 our implied volatility. We have no reason to believe the future
 volatility of our stock price is likely to differ from its past
 volatility.

[0001193125-14-071988:notes:27]
The risk-free interest rate
 assumption is based upon implied yields of U.S. Treasury
 zero-coupon bonds on the date of grant having a remaining term
 equal to the expected life of the options granted. The dividend
 yield is based on our historical and expected dividend
 payouts.

[0001193125-14-071988:notes:28]
The expected life of our
 stock options is based upon historical exercise and cancellation
 activity of our previous stock-based grants with a ten-year
 contractual term.

[0001193125-14-071988:notes:29]
The RSU pricing model also
 requires the use of several significant assumptions that impact the
 fair value estimate. The estimated fair value of the RSUs granted
 to employees during the years ended December 31, 2013, 2012
 and 2011 was $27.72 per share, $19.46 per share and $38.73 per
 share, respectively, with the following assumptions:

[0001193125-14-071988:notes:30]
|  |  | 2013 |  |  | 2012 |  |  | 2011 |  |
| Expected volatility |  |  | 38.83 | % |  |  | 37.75 | % |  |  | 39.32 | % |
| Risk-free interest rate |  |  | 0.61 | % |  |  | 0.38 | % |  |  | 0.37 | % |
| Expected dividend yield |  |  | 1.52 | % |  |  | 2.12 | % |  |  | 1.08 | % |

[0001193125-14-071988:notes:31]
Stock-based compensation
 expense recognized in our Consolidated Statements of Income for the
 years ended December 31, 2013, 2012 and 2011 is based on RSUs
 and options ultimately expected to vest, and has been reduced for
 estimated forfeitures. Estimates for forfeiture rates are based
 upon historical experience and are evaluated quarterly. We expect
 our forfeiture rate for stock option awards to be approximately
 2.5% annually. We estimated a 0% forfeiture rate for our RSUs and
 restricted stock due to the limited number of recipients and
 historical experience for these awards.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-14-071988:notes:32]
Note 12
 – Segment Information and Major Customers

[0001193125-14-071988:notes:33]
We operate in
 two reportable segments: (1) the Carrier Networks Division and
 (2) the Enterprise Networks Division. The accounting policies
 of the segments are the same as those described in the
 “Nature of Business and Summary of Significant Accounting
 Policies” (see Note 1) to the extent that such policies
 affect the reported segment information. We evaluate the
 performance of our segments based on gross profit; therefore,
 selling, general and administrative expense, research and
 development expenses, interest income and dividend income, interest
 expense, net realized investment gain/loss, other income/expense
 and provision for taxes are reported on an entity-wide basis only.
 There are no inter-segment revenues.

[0001193125-14-071988:notes:34]
The following
 table presents information about the reported sales and gross
 profit of our reportable segments for each of the years ended
 December 31, 2013, 2012 and 2011. Asset information by
 reportable segment is not reported, since we do not produce such
 information internally.

[0001193125-14-071988:notes:35]
Sales and
 Gross Profit by Market Segment

[0001193125-14-071988:notes:36]
| (In thousands) |  | 2013 |  |  | 2012 |  |  | 2011 |  |
|  |  | Sales |  |  | Gross Profit |  |  | Sales |  |  | Gross Profit |  |  | Sales |  |  | Gross Profit |  |
| Carrier Networks |  | $ | 500,733 |  |  | $ | 233,206 |  |  | $ | 492,096 |  |  | $ | 247,380 |  |  | $ | 569,579 |  |  | $ | 327,813 |  |
| Enterprise Networks |  |  | 141,011 |  |  |  | 75,680 |  |  |  | 128,518 |  |  |  | 69,263 |  |  |  | 147,650 |  |  |  | 86,505 |  |
| Total |  | $ | 641,744 |  |  | $ | 308,886 |  |  | $ | 620,614 |  |  | $ | 316,643 |  |  | $ | 717,229 |  |  | $ | 414,318 |  |

[0001193125-14-071988:notes:37]
Sales by
 Product

[0001193125-14-071988:notes:38]
Our three
 major product categories are Carrier Systems, Business Networking
 and Loop Access.

[0001193125-14-071988:notes:39]
Carrier
 Systems products are used by
 communications service providers to provide data, voice and video
 services to consumers and enterprises. This category includes the
 following product areas and related services:

[0001193125-14-071988:notes:40]
|  | • |  | Broadband Access |

[0001193125-14-071988:notes:41]
|  | • |  | Total Access® 5000 Multi-Service Access Node (MSAN) |

[0001193125-14-071988:notes:42]
|  | • |  | hiX family of MSANs |

[0001193125-14-071988:notes:43]
|  | • |  | Total Access 1100/1200 Series of Fiber to the Node (FTTN) products |

[0001193125-14-071988:notes:44]
|  | • |  | Ultra Broadband Ethernet (UBE) |

[0001193125-14-071988:notes:45]
|  | • |  | Digital Subscriber Line Access Multiplexer (DSLAM) products |

[0001193125-14-071988:notes:46]
|  | • |  | Optical |

[0001193125-14-071988:notes:47]
|  | • |  | Optical Networking Edge (ONE) |

[0001193125-14-071988:notes:48]
|  | • |  | NetVanta 8000 Series of Fiber Ethernet Access Devices (EAD) |

[0001193125-14-071988:notes:49]
|  | • |  | OPTI-6100 and Total Access 3000 optical Multi-Service Provisioning Platforms (MSPP) |

[0001193125-14-071988:notes:50]
|  | • |  | Pluggable Optical Products, including SFP, XFP, and SFP+ |

[0001193125-14-071988:notes:51]
|  | • |  | TDM systems |

[0001193125-14-071988:notes:52]
Business
 Networking products provide access to
 communication services and facilitate the delivery of cloud
 connectivity and enterprise communications to the small and
 mid-sized enterprise (SME) market. This category includes the
 following product areas and related services:

[0001193125-14-071988:notes:53]
|  | • |  | Internetworking products |

[0001193125-14-071988:notes:54]
|  | • |  | Total Access IP Business Gateways |

[0001193125-14-071988:notes:55]
|  | • |  | Optical Network Terminals (ONTs) |

[0001193125-14-071988:notes:56]
|  | • |  | Bluesocket® virtual Wireless LAN (vWLAN®) |

[0001193125-14-071988:notes:57]
|  | • |  | NetVanta® |

[0001193125-14-071988:notes:58]
|  | • |  | Multiservice Routers |

[0001193125-14-071988:notes:59]
|  | • |  | Managed Ethernet Switches |

[0001193125-14-071988:notes:60]
|  | • |  | IP Business Gateways |

[0001193125-14-071988:notes:61]
|  | • |  | Unified Communications (UC) solutions |

[0001193125-14-071988:notes:62]
|  | • |  | Carrier Ethernet Network Terminating Equipment (NTE) |

[0001193125-14-071988:notes:63]
|  | • |  | Network Management Solutions |

[0001193125-14-071988:notes:64]
|  | • |  | Integrated Access Devices (IADs) |

[0001193125-14-071988:notes:65]
Loop
 Access products
 are used by carrier and enterprise customers for access to
 copper-based communications networks. The Loop Access category
 includes the following product areas and related
 services:

[0001193125-14-071988:notes:66]
|  | • |  | High bit-rate Digital Subscriber Line (HDSL) products |

[0001193125-14-071988:notes:67]
|  | • |  | Digital Data Service (DDS) |

[0001193125-14-071988:notes:68]
|  | • |  | Integrated Services Digital Network (ISDN) products |

[0001193125-14-071988:notes:69]
|  | • |  | T1/E1/T3 Channel Service Units/Data Service Units (CSUs/DSUs) |

[0001193125-14-071988:notes:70]
|  | • |  | TRACER fixed-wireless products |

[0001193125-14-071988:notes:71]
The table
 below presents sales information by product category for the years
 ended December 31, 2013, 2012 and 2011:

[0001193125-14-071988:notes:72]
| (In thousands) |  | 2013 |  |  | 2012 |  |  | 2011 |  |
| Carrier Systems |  | $ | 427,850 |  |  | $ | 399,646 |  |  | $ | 420,289 |  |
| Business Networking |  |  | 168,871 |  |  |  | 149,304 |  |  |  | 162,186 |  |
| Loop Access |  |  | 45,023 |  |  |  | 71,664 |  |  |  | 134,754 |  |
| Total |  | $ | 641,744 |  |  | $ | 620,614 |  |  | $ | 717,229 |  |

[0001193125-14-071988:notes:73]
In addition,
 we identify subcategories of product revenues, which we divide into
 core products and legacy products. Our core products consist of
 Broadband Access and Optical products (included in Carrier
 Systems), and Internetworking products (included in Business
 Networking). Our legacy products include HDSL products (included in
 Loop Access) and other products not included in the aforementioned
 core products.

[0001193125-14-071988:notes:74]
The table
 below presents subcategory revenues for the years ended
 December 31, 2013, 2012 and 2011:

[0001193125-14-071988:notes:75]
| (In thousands) |  | 2013 |  |  | 2012 |  |  | 2011 |  |
| Core Products |  |  |  |  |  |  |  |  |  |  |  |  |
| Broadband Access (included in Carrier Systems) |  | $ | 340,560 |  |  | $ | 320,076 |  |  | $ | 289,776 |  |
| Optical (included in Carrier Systems) |  |  | 55,615 |  |  |  | 51,755 |  |  |  | 82,535 |  |
| Internetworking (NetVanta® & Multi-service Access Gateways) (included in Business Networking) |  |  | 164,422 |  |  |  | 142,958 |  |  |  | 151,536 |  |
| Subtotal |  | $ | 560,597 |  |  | $ | 514,789 |  |  | $ | 523,847 |  |
| Legacy Products |  |  |  |  |  |  |  |  |  |  |  |  |
| HDSL (does not include T1) (included in Loop Access) |  |  | 41,666 |  |  |  | 66,974 |  |  |  | 126,976 |  |
| Other products (excluding HDSL) |  |  | 39,481 |  |  |  | 38,851 |  |  |  | 66,406 |  |
| Subtotal |  | $ | 81,147 |  |  | $ | 105,825 |  |  | $ | 193,382 |  |
| Total |  | $ | 641,744 |  |  | $ | 620,614 |  |  | $ | 717,229 |  |

[0001193125-14-071988:notes:76]
The following
 table presents sales information by geographic area for the years
 ended December 31, 2013, 2012 and 2011. International sales
 correlate to shipments with a non-U.S. destination.

[0001193125-14-071988:notes:77]
| (In thousands) |  | 2013 |  |  | 2012 |  |  | 2011 |  |
| United States |  | $ | 455,996 |  |  | $ | 470,369 |  |  | $ | 632,795 |  |
| Germany |  |  | 97,151 |  |  |  | 26,918 |  |  |  | 554 |  |
| Other international |  |  | 88,597 |  |  |  | 123,327 |  |  |  | 83,880 |  |
| Total |  | $ | 641,744 |  |  | $ | 620,614 |  |  | $ | 717,229 |  |

[0001193125-14-071988:notes:78]
Customers
 comprising more than 10% of revenue can change from year to year.
 Single customers comprising more than 10% of our revenue in 2013
 included two customers at 17% and 14%, respectively. Only a single
 customer comprised more than 10% of our revenue in 2012 at 23%.
 Single customers comprising more than 10% of our revenue in 2011
 included two customers at 25% and 10%, respectively. No other
 customer accounted for 10% or more of our sales in 2013, 2012 or
 2011. Our five largest customers, other than those with more than
 10 percent of revenues disclosed above, can change from year to
 year. These customers represented 22%, 34% and 29% of total revenue
 in 2013, 2012 and 2011, respectively. Revenues in this disclosure
 do not include distributor agents who predominately provide
 fulfillment services to end users. In such cases where known, that
 revenue is associated with the end user.

[0001193125-14-071988:notes:79]
As of
 December 31, 2013, long-lived assets, net totaled $76.7
 million, which includes $71.2 million held in the United States and
 $5.5 million held outside the United States. As of
 December 31, 2012, long-lived assets, net totaled $80.2
 million, which includes $73.9 million held in the United States and
 $6.3 million held outside the United States.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-14-071988:notes:80]
Note 13 –
 Commitments and Contingencies

[0001193125-14-071988:notes:81]
In the ordinary course of
 business, we may be subject to various legal proceedings and
 claims, including employment disputes, patent claims, disputes over
 contract agreements and other commercial disputes. In some cases,
 claimants seek damages or other relief, such as royalty payments
 related to patents, which, if granted, could require significant
 expenditures. Although the outcome of any claim or litigation can
 never be certain, it is our opinion that the outcome of all
 contingencies of which we are currently aware will not materially
 affect our business, operations, financial condition or cash
 flows.

[0001193125-14-071988:notes:82]
We lease office space and
 equipment under operating leases which expire at various dates
 through 2018. As of December 31, 2013, future minimum rental
 payments under non-cancelable operating leases with original
 maturities of greater than 12 months are approximately as
 follows:

[0001193125-14-071988:notes:83]
| (In thousands) |  |  |  |
| 2014 |  | $ | 4,523 |  |
| 2015 |  |  | 3,556 |  |
| 2016 |  |  | 2,506 |  |
| 2017 |  |  | 2,156 |  |
| Thereafter |  |  | 686 |  |
| Total |  | $ | 13,427 |  |

[0001193125-14-071988:notes:84]
Rental expense was
 approximately $4.8 million, $3.9 million and $2.4 million for the
 years ended December 31, 2013, 2012 and 2011,
 respectively.


## us-gaap:ScheduleOfAmountsRecognizedInBalanceSheetTableTextBlock

[0001193125-14-071988:notes:85]
The net amounts recognized
 in the balance sheet for the unfunded pension liability as of
 December 31, 2013 and 2012 are as follows:

[0001193125-14-071988:notes:86]
| (In thousands) |  | 2013 |  |  | 2012 |  |
| Current liability |  | $ | — |  |  | $ | (609 | ) |
| Non-current liability |  |  | (2,581 | ) |  |  | (1,952 | ) |
| Total |  | $ | (2,581 | ) |  | $ | (2,561 | ) |


## us-gaap:ScheduleOfDerivativeInstrumentsInStatementOfFinancialPositionFairValueTextBlock

[0001193125-14-071988:notes:87]
The fair values of our
 derivative instruments recorded in the Consolidated Balance Sheet
 as of December 31, 2013 were as follows:

[0001193125-14-071988:notes:88]
|  |  | December 31, 2013 |  |
| (In thousands) |  | Balance Sheet Location |  | Fair Value |  |
| Derivatives Not Designated as Hedging Instruments (Level 2): |  |  |  |  |  |  |
| Foreign exchange contracts – asset derivatives |  | Other receivables |  | $ | 18 |  |
| Foreign exchange contracts – liability derivatives |  | Accounts payable |  | $ | (15 | ) |


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001193125-14-071988:notes:89]
Revenue
 Recognition

[0001193125-14-071988:notes:90]
Revenue is generally
 recognized when persuasive evidence of an arrangement exists,
 delivery has occurred, the product price is fixed or determinable,
 collection of the resulting receivable is reasonably assured, and
 product returns are reasonably estimable. For product sales,
 revenue is generally recognized upon shipment of the product to our
 customer in accordance with the title transfer terms of the sales
 agreement, generally FOB shipping point. In the case of consigned
 inventory, revenue is recognized when the end customer assumes
 ownership of the product. Contracts that contain multiple
 deliverables are evaluated to determine the units of accounting,
 and the consideration from the arrangement is allocated to each
 unit of accounting based on the relative selling price and
 corresponding terms of the contract. We use vendor-specific
 objective evidence of selling price. When this evidence is not
 available, we are generally not able to determine third-party
 evidence of selling price because of the extent of customization
 among competing products or services from other companies. We
 record revenue associated with installation services when all
 contractual obligations are complete. In instances where customer
 acceptance is required, revenue is deferred until all acceptance
 criteria have been met. Contracts that include both installation
 services and product sales are evaluated for revenue recognition in
 accordance with contract terms. As a result, depending on contract
 terms, installation services may be considered a separate
 deliverable or may be considered a combined single unit of
 accounting with the delivered product. Generally, either the
 purchaser, ADTRAN, or a third party can perform the installation of
 our products. Shipping fees are recorded as revenue and the related
 cost is included in cost of sales. Sales taxes invoiced to
 customers are included in revenues, and represent less than one
 percent of total revenues. The corresponding sales taxes paid are
 included in cost of goods sold. Value added taxes collected from
 customers in international jurisdictions are recorded in accrued
 expenses as a liability. Revenue is recorded net of discounts.
 Sales returns are accrued based on historical sales return
 experience, which we believe provides a reasonable estimate of
 future returns.

[0001193125-14-071988:notes:91]
A portion of Enterprise
 Networks products are sold to a non-exclusive distribution network
 of major technology distributors in the United States. These large
 organizations then distribute or provide fulfillment services to an
 extensive network of value-added resellers and system integrators.
 Value-added resellers and system integrators may be affiliated with
 us as a channel partner, or they may purchase from the distributor
 in an unaffiliated fashion. Additionally, with certain limitations
 our distributors may return unused and unopened product for
 stock-balancing purposes when such returns are accompanied by
 offsetting orders for products of equal or greater
 value.

[0001193125-14-071988:notes:92]
We participate in
 cooperative advertising and market development programs with
 certain customers. We use these programs to reimburse customers for
 certain forms of advertising, and in general, to allow our
 customers credits up to a specified percentage of their net
 purchases. Our costs associated with these programs are estimated
 and included in marketing expenses in our consolidated statements
 of income. We also participate in rebate programs to provide sales
 incentives for certain products. Our costs associated with these
 programs are estimated and accrued at the time of sale, and are
 recorded as a reduction of sales in our consolidated statements of
 income.


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001193125-14-071988:notes:93]
SCHEDULE
 II

[0001193125-14-071988:notes:94]
VALUATION
 AND QUALIFYING ACCOUNTS

[0001193125-14-071988:notes:95]
| Column A |  | Column B |  |  | Column C |  |  | Column D |  |  | Column E |  |  | Column F |  |
| (In thousands) |  | Balance at Beginning of Period |  |  | Assumed on Acquisition |  |  | Charged to Costs & Expenses |  |  | Deductions |  |  | Balance at End of Period |  |
| Year ended December 31, 2013 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for Doubtful Accounts |  | $ | 6 |  |  |  | — |  |  |  | 136 |  |  |  | 12 |  |  | $ | 130 |  |
| Inventory Reserve |  | $ | 11,957 |  |  |  | — |  |  |  | 11,457 |  |  |  | 421 |  |  | $ | 22,993 |  |
| Warranty Liability |  | $ | 9,653 |  |  |  | — |  |  |  | 4,051 |  |  |  | 4,727 |  |  | $ | 8,977 |  |
| Deferred Tax Asset Valuation Allowance |  | $ | 10,939 |  |  |  | — |  |  |  | (1,056 | ) |  |  | 1,041 |  |  | $ | 8,842 |  |
| Year ended December 31, 2012 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for Doubtful Accounts |  | $ | 8 |  |  |  | — |  |  |  | 38 |  |  |  | 40 |  |  | $ | 6 |  |
| Inventory Reserve |  | $ | 9,419 |  |  |  | — |  |  |  | 3,042 |  |  |  | 504 |  |  | $ | 11,957 |  |
| Warranty Liability |  | $ | 4,118 |  |  |  | 3,781 |  |  |  | 5,363 |  |  |  | 3,609 |  |  | $ | 9,653 |  |
| Deferred Tax Asset Valuation Allowance |  | $ | 7,585 |  |  |  | — |  |  |  | 3,594 |  |  |  | 240 |  |  | $ | 10,939 |  |
| Year ended December 31, 2011 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for Doubtful Accounts |  | $ | 162 |  |  |  | — |  |  |  | 117 |  |  |  | 271 |  |  | $ | 8 |  |
| Inventory Reserve |  | $ | 8,932 |  |  |  | — |  |  |  | 1,137 |  |  |  | 650 |  |  | $ | 9,419 |  |
| Warranty Liability |  | $ | 3,304 |  |  |  | 33 |  |  |  | 2,860 |  |  |  | 2,079 |  |  | $ | 4,118 |  |
| Deferred Tax Asset Valuation Allowance |  | $ | 5,627 |  |  |  | 1,462 |  |  |  | 496 |  |  |  | — |  |  | $ | 7,585 |  |


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001193125-14-071988:notes:96]
The following tables
 present changes in accumulated other comprehensive income, net of
 tax, by component for the years ended December 31, 2011, 2012
 and 2013:

[0001193125-14-071988:notes:97]
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | Total |  |
| Balance at December 31, 2010 |  | $ | 23,852 |  |  | $ | — |  |  | $ | 3,096 |  |  | $ | 26,948 |  |
| Other comprehensive loss before reclassifications |  |  | (6,784 | ) |  |  | — |  |  |  | (154 | ) |  |  | (6,938 | ) |
| Amounts reclassified from accumulated other comprehensive income |  |  | (6,908 | ) |  |  | — |  |  |  | — |  |  |  | (6,908 | ) |
| Balance at December 31, 2011 |  | $ | 10,160 |  |  | $ | — |  |  | $ | 2,942 |  |  | $ | 13,102 |  |
| Other comprehensive income (loss) before reclassifications |  |  | 5,426 |  |  |  | (1,952 | ) |  |  | 170 |  |  |  | 3,644 |  |
| Amounts reclassified from accumulated other comprehensive income |  |  | (5,478 | ) |  |  | — |  |  |  | — |  |  |  | (5,478 | ) |
| Balance at December 31, 2012 |  | $ | 10,108 |  |  | $ | (1,952 | ) |  | $ | 3,112 |  |  | $ | 11,268 |  |
| Other comprehensive income (loss) before reclassifications |  |  | 5,508 |  |  |  | 1,061 |  |  |  | (2,205 | ) |  |  | 4,364 |  |
| Amounts reclassified from accumulated other comprehensive income |  |  | (4,879 | ) |  |  | — |  |  |  | — |  |  |  | (4,879 | ) |
| Balance at December 31, 2013 |  | $ | 10,737 |  |  | $ | (891 | ) |  | $ | 907 |  |  | $ | 10,753 |  |


## us-gaap:ScheduleOfFairValueAssetsAndLiabilitiesMeasuredOnRecurringBasisTableTextBlock

[0001193125-14-071988:notes:98]
We have categorized our
 cash equivalents and our investments held at fair value into a
 three-level fair value hierarchy based on the priority of the
 inputs to the valuation technique for the cash equivalents and
 investments as follows: Level 1—Values based on unadjusted
 quoted prices for identical assets or liabilities in an active
 market; Level 2—Values based on quoted prices in markets that
 are not active or model inputs that are observable either directly
 or indirectly; Level 3—Values based on prices or valuation
 techniques that require inputs that are both unobservable and
 significant to the overall fair value measurement. These inputs
 include information supplied by investees.

[0001193125-14-071988:notes:99]
|  |  |  |  |  | Fair Value Measurements at December 31, 2013 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  | $ | 4 |  |  | $ | 4 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Bond funds: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 12,976 |  |  |  | 12,976 |  |  |  | — |  |  |  | — |  |
| Government bonds |  |  | 1,915 |  |  |  | 1,915 |  |  |  | — |  |  |  | — |  |
| Equity funds: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Large cap blend |  |  | 4,720 |  |  |  | 4,720 |  |  |  | — |  |  |  | — |  |
| Large cap value |  |  | 287 |  |  |  | 287 |  |  |  | — |  |  |  | — |  |
| Balanced fund |  |  | 871 |  |  |  | 871 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 20,769 |  |  |  | 20,769 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 20,773 |  |  | $ | 20,773 |  |  | $ | — |  |  | $ | — |  |

[0001193125-14-071988:notes:100]
|  |  |  |  |  | Fair Value Measurements at December 31, 2012 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  | $ | 6 |  |  | $ | 6 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Bond funds: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 12,041 |  |  |  | 12,041 |  |  |  | — |  |  |  | — |  |
| Government bonds |  |  | 1,839 |  |  |  | 1,839 |  |  |  | — |  |  |  | — |  |
| Equity funds: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Large cap blend |  |  | 3,740 |  |  |  | 3,740 |  |  |  | — |  |  |  | — |  |
| Large cap value |  |  | 235 |  |  |  | 235 |  |  |  | — |  |  |  | — |  |
| Balanced fund |  |  | 759 |  |  |  | 759 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 18,614 |  |  |  | 18,614 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 18,620 |  |  | $ | 18,620 |  |  | $ | — |  |  | $ | — |  |


## us-gaap:ComprehensiveIncomePolicyPolicyTextBlock

[0001193125-14-071988:notes:101]
Other Comprehensive
 Income

[0001193125-14-071988:notes:102]
Other comprehensive income
 consists of unrealized gains (losses) on available-for-sale
 securities, reclassification adjustments for amounts included in
 net income related to impairments of available-for-sale securities
 and realized gains (losses) on available-for-sale securities,
 defined benefit plan adjustments and foreign currency translation
 adjustments.

[0001193125-14-071988:notes:103]
The following tables
 present the details of reclassifications out of accumulated other
 comprehensive income for the years ended December 31, 2013,
 2012 and 2011:

[0001193125-14-071988:notes:104]
| (In thousands) |  | 2013 |
| Details about Accumulated Other Comprehensive Income Components |  | Amount Reclassified from Accumulated Other Comprehensive Income |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for-sale securities: |  |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 8,023 |  |  | Net realized investment gain |
| Impairment expense |  |  | (25 | ) |  | Net realized investment gain |
| Total reclassifications for the period, before tax |  |  | 7,998 |  |  |  |
| Tax (expense) benefit |  |  | (3,119 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 4,879 |  |  |  |

[0001193125-14-071988:notes:105]
| (In thousands) |  | 2012 |
| Details about Accumulated Other Comprehensive Income Components |  | Amount Reclassified from Accumulated Other Comprehensive Income |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for-sale securities: |  |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 9,662 |  |  | Net realized investment gain |
| Impairment expense |  |  | (682 | ) |  | Net realized investment gain |
| Total reclassifications for the period, before tax |  |  | 8,980 |  |  |  |
| Tax (expense) benefit |  |  | (3,502 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 5,478 |  |  |  |

[0001193125-14-071988:notes:106]
| (In thousands) |  | 2011 |
| Details about Accumulated Other Comprehensive Income Components |  | Amount Reclassified from Accumulated Other Comprehensive Income |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for-sale securities: |  |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 11,393 |  |  | Net realized investment gain |
| Impairment expense |  |  | (68 | ) |  | Net realized investment gain |
| Total reclassifications for the period, before tax |  |  | 11,325 |  |  |  |
| Tax (expense) benefit |  |  | (4,417 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 6,908 |  |  |  |

[0001193125-14-071988:notes:107]
The following tables
 present the tax effects related to the change in each component of
 other comprehensive income for the years ended December 31,
 2013, 2012 and 2011:

[0001193125-14-071988:notes:108]
|  |  | 2013 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |
| Unrealized gains (losses) on available-for-sale securities |  | $ | 9,030 |  |  | $ | (3,522 | ) |  | $ | 5,508 |  |
| Reclassification adjustment for amounts included in net income |  |  | (7,998 | ) |  |  | 3,119 |  |  |  | (4,879 | ) |
| Defined benefit plan adjustments |  |  | 1,061 |  |  |  | — |  |  |  | 1,061 |  |
| Foreign currency translation adjustment |  |  | (2,205 | ) |  |  | — |  |  |  | (2,205 | ) |
| Total Other Comprehensive Income (Loss) |  | $ | (112 | ) |  | $ | (403 | ) |  | $ | (515 | ) |

[0001193125-14-071988:notes:109]
|  |  | 2012 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |
| Unrealized gains (losses) on available-for-sale securities |  | $ | 8,895 |  |  | $ | (3,469 | ) |  | $ | 5,426 |  |
| Reclassification adjustment for amounts included in net income |  |  | (8,980 | ) |  |  | 3,502 |  |  |  | (5,478 | ) |
| Defined benefit plan adjustments |  |  | (1,952 | ) |  |  | — |  |  |  | (1,952 | ) |
| Foreign currency translation adjustment |  |  | 170 |  |  |  | — |  |  |  | 170 |  |
| Total Other Comprehensive Income (Loss) |  | $ | (1,867 | ) |  | $ | 33 |  |  | $ | (1,834 | ) |

[0001193125-14-071988:notes:110]
|  |  | 2011 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |
| Unrealized gains (losses) on available-for-sale securities |  | $ | (11,121 | ) |  | $ | 4,337 |  |  | $ | (6,784 | ) |
| Reclassification adjustment for amounts included in net income |  |  | (11,325 | ) |  |  | 4,417 |  |  |  | (6,908 | ) |
| Foreign currency translation adjustment |  |  | (154 | ) |  |  | — |  |  |  | (154 | ) |
| Total Other Comprehensive Income (Loss) |  | $ | (22,600 | ) |  | $ | 8,754 |  |  | $ | (13,846 | ) |


## us-gaap:PropertyPlantAndEquipmentTextBlock

[0001193125-14-071988:notes:111]
At December 31, 2013
 and 2012, property, plant and equipment were comprised of the
 following:

[0001193125-14-071988:notes:112]
| (In thousands) |  | 2013 |  |  | 2012 |  |
| Land |  | $ | 4,263 |  |  | $ | 4,263 |  |
| Building and land improvements |  |  | 21,776 |  |  |  | 20,915 |  |
| Building |  |  | 68,479 |  |  |  | 68,479 |  |
| Furniture and fixtures |  |  | 16,465 |  |  |  | 16,631 |  |
| Computer hardware and software |  |  | 70,468 |  |  |  | 68,596 |  |
| Engineering and other equipment |  |  | 104,584 |  |  |  | 99,081 |  |
| Total Property, Plant and Equipment |  |  | 286,035 |  |  |  | 277,965 |  |
| Less accumulated depreciation |  |  | (209,296 | ) |  |  | (197,719 | ) |
| Total Property, Plant and Equipment, net |  | $ | 76,739 |  |  | $ | 80,246 |  |


## us-gaap:ScheduleofFiniteLivedIntangibleAssetsFutureAmortizationExpenseTableTextBlock

[0001193125-14-071988:notes:113]
As of December 31,
 2013, the estimated future amortization expense of intangible
 assets is as follows:

[0001193125-14-071988:notes:114]
| (In thousands) |  | Amount |  |
| 2014 |  | $ | 2,335 |  |
| 2015 |  |  | 2,199 |  |
| 2016 |  |  | 1,925 |  |
| 2017 |  |  | 1,302 |  |
| 2018 |  |  | 784 |  |
| Thereafter |  |  | 2,027 |  |
| Total |  | $ | 10,572 |  |


## us-gaap:ScheduleOfNetBenefitCostsTableTextBlock

[0001193125-14-071988:notes:115]
The weighted-average
 assumptions that were used to determine the net periodic benefit
 cost for the year ended December 31, 2013 and the period
 May 4, 2012 to December 31, 2012 are as
 follows:

[0001193125-14-071988:notes:116]
|  |  | Year Ended December 31, 2013 |  |  | May 4, 2012 to December 31, 2012 |  |
| Discount rates |  |  | 3.50 | % |  |  | 3.96 | % |
| Rate of compensation increase |  |  | 2.25 | % |  |  | 2.25 | % |
| Expected long-term rates of return |  |  | 5.40 | % |  |  | 5.40 | % |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001193125-14-071988:notes:117]
Note 7 – Property,
 Plant and Equipment

[0001193125-14-071988:notes:118]
Depreciation expense was
 $12.2 million, $12.1 million and $10.8 million in 2013, 2012 and
 2011, respectively.


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001193125-14-071988:notes:119]
We have categorized our
 cash equivalents held in money market funds and our investments
 held at fair value into a three-level fair value hierarchy based on
 the priority of the inputs to the valuation technique for the cash
 equivalents and investments as follows: Level 1—Values based
 on unadjusted quoted prices for identical assets or liabilities in
 an active market; Level 2—Values based on quoted prices in
 markets that are not active or model inputs that are observable
 either directly or indirectly; Level 3—Values based on prices
 or valuation techniques that require inputs that are both
 unobservable and significant to the overall fair value measurement.
 These inputs include information supplied by investees.

[0001193125-14-071988:notes:120]
|  |  | Fair Value Measurements at December 31, 2013 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 3,949 |  |  | $ | 3,949 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 15,123 |  |  |  | 15,123 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 166,859 |  |  |  | — |  |  |  | 166,859 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 136,302 |  |  |  | — |  |  |  | 136,302 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 8,310 |  |  |  | — |  |  |  | 8,310 |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – technology industry |  |  | 11,398 |  |  |  | 11,398 |  |  |  | — |  |  |  | — |  |
| Marketable equity securities – other |  |  | 27,054 |  |  |  | 27,054 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 365,046 |  |  |  | 53,575 |  |  |  | 311,471 |  |  |  | — |  |
| Total |  | $ | 368,995 |  |  | $ | 57,524 |  |  | $ | 311,471 |  |  | $ | — |  |
|  |  | Fair Value Measurements at December 31, 2012 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 28,071 |  |  | $ | 28,071 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 11,527 |  |  |  | 11,527 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 186,412 |  |  |  | — |  |  |  | 186,412 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 175,084 |  |  |  | — |  |  |  | 175,084 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 34,375 |  |  |  | — |  |  |  | 34,375 |  |  |  | — |  |
| Fixed income bond fund |  |  | 456 |  |  |  | 456 |  |  |  | — |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – technology industry |  |  | 14,099 |  |  |  | 14,099 |  |  |  | — |  |  |  | — |  |
| Marketable equity securities – other |  |  | 21,105 |  |  |  | 21,105 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 443,058 |  |  |  | 47,187 |  |  |  | 395,871 |  |  |  | — |  |
| Total |  | $ | 471,129 |  |  | $ | 75,258 |  |  | $ | 395,871 |  |  | $ | — |  |


## us-gaap:ReceivablesPolicyTextBlock

[0001193125-14-071988:notes:121]
Accounts
 Receivable

[0001193125-14-071988:notes:122]
We record accounts
 receivable at net realizable value. Prior to issuing payment terms
 to a new customer, we perform a detailed credit review of the
 customer. Credit limits are established for each new customer based
 on the results of this credit review. Payment terms are established
 for each new customer, and collection experience is reviewed
 periodically in order to determine if the customer’s payment
 terms and credit limits need to be revised. At December 31,
 2013, one customer accounted for 13.1% of our total accounts
 receivable. At December 31, 2012, one customer accounted for
 10.4% of our total accounts receivable.

[0001193125-14-071988:notes:123]
We maintain an allowance
 for doubtful accounts for losses resulting from the inability of
 our customers to make required payments. We regularly review the
 allowance for doubtful accounts and consider factors such as the
 age of accounts receivable balances, the current economic
 conditions that may affect a customer’s ability to pay,
 significant one-time events and our historical experience. If the
 financial condition of a customer deteriorates, resulting in an
 impairment of their ability to make payments, we may be required to
 record an allowance for doubtful accounts. If circumstances change
 with regard to individual receivable balances that have previously
 been determined to be uncollectible (and for which a specific
 reserve has been established), a reduction in our allowance for
 doubtful accounts may be required. Our allowance for doubtful
 accounts was $130 thousand at December 31, 2013 and $6
 thousand at December 31, 2012.


## us-gaap:SummaryOfIncomeTaxContingenciesTextBlock

[0001193125-14-071988:notes:124]
The change in the
 unrecognized income tax benefits for 2013, 2012 and 2011 is
 reconciled below:

[0001193125-14-071988:notes:125]
| (In thousands) |  | 2013 |  |  | 2012 |  |  | 2011 |  |
| Balance at beginning of period |  | $ | 2,926 |  |  | $ | 2,970 |  |  | $ | 2,593 |  |
| Increases for tax position related to: |  |  |  |  |  |  |  |  |  |  |  |  |
| Prior years |  |  | 89 |  |  |  | 965 |  |  |  | — |  |
| Current year |  |  | 549 |  |  |  | 302 |  |  |  | 840 |  |
| Decreases for tax positions related to: |  |  |  |  |  |  |  |  |  |  |  |  |
| Prior years |  |  | — |  |  |  | (49 | ) |  |  | (92 | ) |
| Settlements with taxing authorities |  |  | (141 | ) |  |  | (507 | ) |  |  | (354 | ) |
| Expiration of applicable statute of limitations |  |  | (183 | ) |  |  | (755 | ) |  |  | (17 | ) |
| Balance at end of period |  | $ | 3,240 |  |  | $ | 2,926 |  |  | $ | 2,970 |  |


## us-gaap:ScheduleOfNetFundedStatusTableTextBlock

[0001193125-14-071988:notes:126]
The pension benefit plan
 obligations and funded status at December 31, 2013 and 2012,
 are as follows:

[0001193125-14-071988:notes:127]
| (In thousands) |  | 2013 |  |  | 2012 |  |
| Change in projected benefit obligation: |  |  |  |  |  |  |  |  |
| Projected benefit obligation at beginning of period |  | $ | (21,181 | ) |  | $ | — |  |
| Business combination |  |  | — |  |  |  | (18,063 | ) |
| Service cost |  |  | (1,198 | ) |  |  | (766 | ) |
| Interest cost |  |  | (745 | ) |  |  | (494 | ) |
| Actuarial gain (loss) |  |  | 779 |  |  |  | (1,862 | ) |
| Benefit payments |  |  | (1 | ) |  |  | — |  |
| Foreign currency exchange rate changes |  |  | (1,008 | ) |  |  | 4 |  |
| Projected benefit obligation at end of period |  | $ | (23,354 | ) |  | $ | (21,181 | ) |
| Change in plan assets: |  |  |  |  |  |  |  |  |
| Fair value of plan assets at beginning of period |  | $ | 18,620 |  |  | $ | — |  |
| Business combination |  |  | — |  |  |  | 18,063 |  |
| Actual return on plan assets |  |  | 1,281 |  |  |  | 592 |  |
| Foreign currency exchange rate changes |  |  | 872 |  |  |  | (35 | ) |
| Fair value of plan assets at end of period |  | $ | 20,773 |  |  | $ | 18,620 |  |
| Funded status at end of period |  | $ | (2,581 | ) |  | $ | (2,561 | ) |


## us-gaap:ConsolidationPolicyTextBlock

[0001193125-14-071988:notes:128]
Principles of
 Consolidation

[0001193125-14-071988:notes:129]
Our consolidated financial
 statements include ADTRAN and its wholly owned subsidiaries. All
 inter-company accounts and transactions have been eliminated in
 consolidation.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001193125-14-071988:notes:130]
Note 15 –
 Summarized Quarterly Financial Data (Unaudited)

[0001193125-14-071988:notes:131]
The following table
 presents unaudited quarterly operating results for each of our last
 eight fiscal quarters. This information has been prepared on a
 basis consistent with our audited financial statements and includes
 all adjustments, consisting only of normal recurring adjustments,
 considered necessary for a fair presentation of the
 data.

[0001193125-14-071988:notes:132]
Unaudited Quarterly
 Operating Results

[0001193125-14-071988:notes:133]
(In thousands, except
 for per share amounts)

[0001193125-14-071988:notes:134]
| Three Months Ended |  | March 31, 2013 |  |  | June 30, 2013 |  |  | September 30, 2013 |  |  | December 31, 2013 |  |
| Net sales |  | $ | 143,013 |  |  | $ | 162,233 |  |  | $ | 177,404 |  |  | $ | 159,094 |  |
| Gross profit |  | $ | 69,677 |  |  | $ | 79,798 |  |  | $ | 82,547 |  |  | $ | 76,864 |  |
| Operating income |  | $ | 6,563 |  |  | $ | 14,053 |  |  | $ | 17,210 |  |  | $ | 10,639 |  |
| Net income |  | $ | 7,890 |  |  | $ | 9,859 |  |  | $ | 16,205 |  |  | $ | 11,840 |  |
| Earnings per common share |  | $ | 0.13 |  |  | $ | 0.17 |  |  | $ | 0.28 |  |  | $ | 0.21 |  |
| Earnings per common share assuming dilution (1) |  | $ | 0.13 |  |  | $ | 0.17 |  |  | $ | 0.28 |  |  | $ | 0.20 |  |
| Three Months Ended |  | March 31, 2012 |  |  | June 30, 2012 |  |  | September 30, 2012 |  |  | December 31, 2012 |  |
| Net sales |  | $ | 134,735 |  |  | $ | 183,998 |  |  | $ | 162,125 |  |  | $ | 139,756 |  |
| Gross profit |  | $ | 74,087 |  |  | $ | 95,201 |  |  | $ | 79,972 |  |  | $ | 67,383 |  |
| Operating income |  | $ | 16,181 |  |  | $ | 26,838 |  |  | $ | 10,276 |  |  | $ | 2,874 |  |
| Net income |  | $ | 12,960 |  |  | $ | 21,070 |  |  | $ | 9,272 |  |  | $ | 3,961 |  |
| Earnings per common share |  | $ | 0.20 |  |  | $ | 0.33 |  |  | $ | 0.15 |  |  | $ | 0.06 |  |
| Earnings per common share assuming dilution (1) |  | $ | 0.20 |  |  | $ | 0.33 |  |  | $ | 0.15 |  |  | $ | 0.06 |  |

[0001193125-14-071988:notes:135]
| (1) | Assumes exercise of dilutive stock options calculated under the treasury stock method. |


## us-gaap:DeferredRevenueByArrangementDisclosureTextBlock

[0001193125-14-071988:notes:136]
At December 31, 2013 and 2012, unearned
 revenue was as follows:

[0001193125-14-071988:notes:137]
| (In thousands) |  | 2013 |  |  | 2012 |  |
| Current unearned revenue |  | $ | 22,205 |  |  | $ | 35,326 |  |
| Non-current unearned revenue |  |  | 14,643 |  |  |  | 22,377 |  |
| Total |  | $ | 36,848 |  |  | $ | 57,703 |  |


## us-gaap:InventoryDisclosureTextBlock

[0001193125-14-071988:notes:138]
Note 6 –
 Inventory

[0001193125-14-071988:notes:139]
At December 31, 2013
 and 2012, inventory was comprised of the following:

[0001193125-14-071988:notes:140]
| (In thousands) |  | 2013 |  |  | 2012 |  |
| Raw materials |  | $ | 44,093 |  |  | $ | 47,054 |  |
| Work in process |  |  | 3,484 |  |  |  | 3,262 |  |
| Finished goods |  |  | 42,534 |  |  |  | 51,061 |  |
| Total Inventory, net |  | $ | 90,111 |  |  | $ | 101,377 |  |

[0001193125-14-071988:notes:141]
We establish reserves for
 estimated excess, obsolete, or unmarketable inventory equal to the
 difference between the cost of the inventory and the estimated fair
 value of the inventory based upon assumptions about future demand
 and market conditions. At December 31, 2013 and 2012, raw
 materials reserves totaled $16.9 million and $9.9 million,
 respectively, and finished goods inventory reserves totaled $6.1
 million and $2.1 million, respectively.


## us-gaap:ScheduleOfEarningsPerShareBasicAndDilutedTableTextBlock

[0001193125-14-071988:notes:142]
A summary of the
 calculation of basic and diluted earnings per share (EPS) for the
 years ended December 31, 2013, 2012 and 2011 is as
 follows:

[0001193125-14-071988:notes:143]
| (In thousands, except for per share amounts) |  | 2013 |  |  | 2012 |  |  | 2011 |  |
| Numerator |  |  |  |  |  |  |  |  |  |  |  |  |
| Net Income |  | $ | 45,794 |  |  | $ | 47,263 |  |  | $ | 138,577 |  |
| Denominator |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average number of shares – basic |  |  | 59,001 |  |  |  | 63,259 |  |  |  | 64,145 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock options |  |  | 390 |  |  |  | 488 |  |  |  | 1,236 |  |
| Restricted stock and restricted stock units |  |  | 33 |  |  |  | 27 |  |  |  | 35 |  |
| Weighted average number of shares – diluted |  |  | 59,424 |  |  |  | 63,774 |  |  |  | 65,416 |  |
| Net income per share – basic |  | $ | 0.78 |  |  | $ | 0.75 |  |  | $ | 2.16 |  |
| Net income per share – diluted |  | $ | 0.77 |  |  | $ | 0.74 |  |  | $ | 2.12 |  |


## us-gaap:ScheduleOfExpectedBenefitPaymentsTableTextBlock

[0001193125-14-071988:notes:144]
The following pension
 benefit payments, which reflect expected future service, as
 appropriate, are expected to be paid to participants:

[0001193125-14-071988:notes:145]
| (In thousands) |  |
| 2014 |  | $ | 357 |  |
| 2015 |  |  | 312 |  |
| 2016 |  |  | 223 |  |
| 2017 |  |  | 390 |  |
| 2018 |  |  | 650 |  |
| 2019 – 2023 |  |  | 4,427 |  |
| Total |  | $ | 6,359 |  |


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001193125-14-071988:notes:146]
As of December 31,
 2013, corporate and municipal fixed-rate bonds had the following
 contractual maturities:

[0001193125-14-071988:notes:147]
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |
| Less than one year |  | $ | 55,396 |  |  | $ | 46,606 |  |
| One to two years |  |  | 37,838 |  |  |  | 25,284 |  |
| Two to three years |  |  | 70,447 |  |  |  | 55,358 |  |
| Three to five years |  |  | 3,178 |  |  |  | 9,054 |  |
| Total |  | $ | 166,859 |  |  | $ | 136,302 |  |


## us-gaap:ScheduleOfQuarterlyFinancialInformationTableTextBlock

[0001193125-14-071988:notes:148]
The following table
 presents unaudited quarterly operating results for each of our last
 eight fiscal quarters.


## us-gaap:ScheduleOfRealizedGainLossTableTextBlock

[0001193125-14-071988:notes:149]
The following table
 presents gross realized gains and losses related to our investments
 for the years ended December 31, 2013, 2012 and
 2011:

[0001193125-14-071988:notes:150]
| Year Ended December 31, (In thousands) |  | 2013 |  |  | 2012 |  |  | 2011 |  |
| Gross realized gains |  | $ | 8,932 |  |  | $ | 11,006 |  |  | $ | 13,641 |  |
| Gross realized losses |  | $ | (318 | ) |  | $ | (1,456 | ) |  | $ | (1,187 | ) |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001193125-14-071988:notes:151]
Note 5 –
 Derivative Instruments and Hedging Activities

[0001193125-14-071988:notes:152]
We have certain
 international customers who are billed in their local currency.
 Changes in the monetary exchange rates may adversely affect our
 results of operations and financial condition. When appropriate, we
 enter into various derivative transactions to enhance our ability
 to manage the volatility relating to these typical business
 exposures. We do not hold or issue derivative instruments for
 trading or other speculative purposes. Our derivative instruments
 are recorded in the Consolidated Balance Sheets at their fair
 values. Our derivative instruments do not qualify for hedge
 accounting, and accordingly, all changes in the fair value of the
 instruments are recognized as other income (expense) in the
 Consolidated Statements of Income. The maximum contractual period
 for our derivatives is currently less than twelve months. Our
 derivative instruments are not subject to master netting
 arrangements and are not offset in the Consolidated Balance
 Sheets.

[0001193125-14-071988:notes:153]
As of December 31,
 2013, we had forward contracts outstanding with notional amounts
 totaling €18.5 million ($25.5 million), which mature
 through 2014.

[0001193125-14-071988:notes:154]
The change in the fair
 values of our derivative instruments recorded in the Consolidated
 Statements of Income during the year ended December 31, 2013
 were as follows:

[0001193125-14-071988:notes:155]
| (In thousands) |  | Income Statement Location |  | 2013 |  |
| Derivatives Not Designated as Hedging Instruments: |  |  |  |  |  |  |
| Foreign exchange contracts |  | Other income (expense) |  | $ | 750 |  |


## us-gaap:InventoryPolicyTextBlock

[0001193125-14-071988:notes:156]
Inventory

[0001193125-14-071988:notes:157]
Inventory is carried at the lower of cost or market, with cost
 being determined using the first-in, first-out method. Standard
 costs for material, labor and manufacturing overhead are used to
 value inventory. Standard costs are updated at least quarterly;
 therefore, inventory costs approximate actual costs at the end of
 each reporting period. We establish reserves for estimated excess,
 obsolete or unmarketable inventory equal to the difference between
 the cost of the inventory and the estimated fair value of the
 inventory based upon assumptions about future demand and market
 conditions. When we dispose of excess and obsolete inventories, the
 related write-downs are charged against the inventory reserve. See
 Note 6 of Notes to Consolidated Financial Statements for additional
 information.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0001193125-14-071988:notes:158]
Property, Plant and Equipment

[0001193125-14-071988:notes:159]
Property, plant and equipment, which is stated at cost, is
 depreciated using the straight-line method over the estimated
 useful lives of the assets. We depreciate building and land
 improvements from five to 39 years, office machinery and equipment
 from three to seven years, engineering machinery and equipment from
 three to seven years, and computer software from three to five
 years. Expenditures for repairs and maintenance are charged to
 expense as incurred. Betterments that materially prolong the lives
 of the assets are capitalized. The cost of assets retired or
 otherwise disposed of and the related accumulated depreciation are
 removed from the accounts, and the gain or loss on such disposition
 is included in other income (expense), net in the accompanying
 consolidated statements of income. See Note 7 of Notes to
 Consolidated Financial Statements for additional information.


## us-gaap:CashAndCashEquivalentsPolicyTextBlock

[0001193125-14-071988:notes:160]
Cash and Cash Equivalents

[0001193125-14-071988:notes:161]
Cash and cash equivalents represent demand deposits, money market
 funds, and short-term investments classified as available-for-sale
 with original maturities of three months or less. We maintain
 depository investments with certain financial institutions.
 Although these depository investments may exceed government insured
 depository limits, we have evaluated the credit worthiness of these
 applicable financial institutions, and determined the risk of
 material financial loss due to the exposure of such credit risk to
 be minimal. As of December 31, 2013, $53.5 million of our cash
 and cash equivalents, primarily certain domestic money market funds
 and foreign depository accounts, were in excess of government
 provided insured depository limits.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001193125-14-071988:notes:162]
Note 2 – Business
 Combinations

[0001193125-14-071988:notes:163]
On May 4, 2012, we
 acquired the NSN BBA business. This acquisition provides us with an
 established customer base in key markets and complementary,
 market-focused products and was accounted for as a business
 combination. We have included the financial results of the NSN BBA
 business in our consolidated financial statements since the date of
 acquisition. These revenues are included in the Carrier Networks
 division in the Broadband Access subcategory.

[0001193125-14-071988:notes:164]
Upon acquisition, we
 received a cash payment of $7.5 million from NSN and recorded a
 bargain purchase gain of $1.8 million, net of income taxes, subject
 to customary working capital adjustments between the parties as
 defined in the purchase agreement. As of December 31, 2013,
 the parties were in the process of negotiating final working
 capital adjustments. We have adjusted the purchase price allocation
 to record additional estimated liabilities and an estimated
 receivable from NSN related to working capital adjustments under
 negotiation. The bargain purchase gain of $1.8 million represents
 the excess of the consideration exchanged over the fair value of
 the assets acquired and liabilities assumed. We have assessed the
 recognition and measurements of the assets acquired and liabilities
 assumed based on historical and pro forma data for future periods
 and have concluded that our valuation procedures and resulting
 measures were appropriate. The gain is included in the line item
 “Gain on bargain purchase of a business” in the 2012
 Consolidated Statements of Income.

[0001193125-14-071988:notes:165]
The allocation of the
 purchase price to the estimated fair value of the assets acquired
 and liabilities assumed at the acquisition date is as
 follows:

[0001193125-14-071988:notes:166]
| (In Thousands) |  |  |  |
| Other receivables |  | $ | 9,486 |  |
| Inventory |  |  | 21,068 |  |
| Property, plant and equipment |  |  | 5,035 |  |
| Accounts payable |  |  | (5,194 | ) |
| Unearned revenue |  |  | (18,203 | ) |
| Accrued expenses |  |  | (3,361 | ) |
| Accrued wages and benefits |  |  | (2,251 | ) |
| Deferred tax liability |  |  | (788 | ) |
| Non-current unearned revenue |  |  | (19,886 | ) |
| Net liabilities assumed |  |  | (14,094 | ) |
| Customer relationships |  |  | 5,162 |  |
| Developed technology |  |  | 3,176 |  |
| Other |  |  | 13 |  |
| Gain on bargain purchase of a business, net of tax |  |  | (1,753 | ) |
| Net consideration received from seller |  | $ | (7,496 | ) |

[0001193125-14-071988:notes:167]
The fair value of the
 customer relationships acquired was calculated using a discounted
 cash flow method (excess earnings) and is being amortized using a
 declining balance method derived from projected customer revenue
 over an average estimated useful life of 13 years. The fair value
 of the developed technology acquired was calculated using a
 discounted cash flow method (relief from royalty) and is being
 amortized using the straight-line method over an estimated useful
 life of five years.

[0001193125-14-071988:notes:168]
For the years ended
 December 31, 2013 and 2012, we incurred acquisition and
 integration related expenses and amortization of acquired
 intangibles of $2.9 million and $7.9 million, respectively, related
 to this acquisition.

[0001193125-14-071988:notes:169]
The following supplemental
 pro forma information presents the financial results of the
 acquired NSN BBA business for the years ended December 31,
 2012 and 2011. The pro forma results for the period January 1,
 2012 to May 4, 2012 and January 1, 2011 to
 December 31, 2011 are not included in our consolidated
 financial results.

[0001193125-14-071988:notes:170]
This supplemental pro forma
 information does not purport to be indicative of what would have
 occurred had the acquisition of the NSN BBA business been completed
 on January 1, 2011, nor are they indicative of any future
 results.

[0001193125-14-071988:notes:171]
| (In thousands) (Unaudited) |  | 2012 |  |  | 2011 |  |
| Pro forma revenue |  | $ | 119,600 |  |  | $ | 196,256 |  |
| Pro forma pre-tax loss |  | $ | (23,621 | ) |  | $ | (36,980 | ) |
| Weighted average exchange rate during the period (EURO/USD) |  | € | 1.00/$1.29 |  |  | € | 1.00/$1.38 |  |

[0001193125-14-071988:notes:172]
On August 4, 2011, we
 acquired all of the outstanding stock of Bluesocket, Inc., a
 provider of wireless network solutions with virtual control, for
 $23.7 million in cash. The acquisition provides us with IEEE802.11N
 enterprise class wireless LAN expertise, technology, and products
 to address the growing transition within small-medium enterprises
 and large enterprises to wireless networks and mobile devices. We
 have included the financial results of Bluesocket in our
 consolidated financial statements since the date of acquisition.
 Pro forma results of operations prior to the closing date for the
 acquisition have not been presented because the effect of the
 acquisition was not material to our financial results. The
 allocation of the purchase price to the estimated fair value of the
 assets acquired and liabilities assumed at the acquisition date is
 as follows:

[0001193125-14-071988:notes:173]
| (In Thousands) |  |  |  |
| Cash |  | $ | 1,027 |  |
| Accounts receivable |  |  | 298 |  |
| Inventory |  |  | 792 |  |
| Prepaid expenses |  |  | 357 |  |
| Property, plant and equipment |  |  | 173 |  |
| Deferred tax assets, net |  |  | 12,962 |  |
| Accounts payable |  |  | (441 | ) |
| Unearned revenue |  |  | (600 | ) |
| Accrued expenses |  |  | (332 | ) |
| Net assets acquired |  |  | 14,236 |  |
| Customer relationships |  |  | 1,530 |  |
| Developed technology |  |  | 3,230 |  |
| Intellectual property |  |  | 930 |  |
| Trade names |  |  | 270 |  |
| Goodwill |  |  | 3,492 |  |
| Total purchase price |  | $ | 23,688 |  |

[0001193125-14-071988:notes:174]
During the fourth quarter
 of 2011, the purchase price and purchase price allocation were
 adjusted for our final valuations. The adjustments resulted in a
 decrease to the goodwill recognized in the transaction.

[0001193125-14-071988:notes:175]
The net deferred tax assets
 acquired are primarily related to net operating losses and
 previously capitalized and unamortized research and development
 expense for tax deduction purposes.

[0001193125-14-071988:notes:176]
The fair value of the
 customer relationships, developed technology and intellectual
 property acquired was calculated using an income approach (excess
 earnings method) and is being amortized using the straight-line
 method. The customer relationships and intellectual property are
 being amortized over an estimated useful life of 7 years and the
 developed technology is being amortized over an average estimated
 useful life of 4.5 years.

[0001193125-14-071988:notes:177]
The fair value of the trade
 names acquired was calculated using an income approach (relief from
 royalty method) and is being amortized using the straight-line
 method over the estimated useful life of 4.5 years.

[0001193125-14-071988:notes:178]
The goodwill of $3.5
 million generated from this acquisition is primarily related to
 expected synergies and was assigned to our Enterprise Networks
 division. The goodwill will not be deductible for U.S. federal
 income tax purposes.

[0001193125-14-071988:notes:179]
For the years ended
 December 31, 2013, 2012 and 2011, we incurred integration
 related expenses and amortization of acquired intangibles of $1.1
 million, $1.5 million and $1.7 million, respectively, related to
 this acquisition.


## us-gaap:ScheduleOfGoodwillTextBlock

[0001193125-14-071988:notes:180]
The changes in the carrying
 value of goodwill, all of which is included in our Enterprise
 Networks division, for the year ended December 31, 2013 are as
 follows:

[0001193125-14-071988:notes:181]
| (In thousands) |  |  |  |
| Balance, December 31, 2012 |  | $ | 3,492 |  |
| Acquisitions |  |  | — |  |
| Impairment losses |  |  | — |  |
| Balance, December 31, 2013 |  | $ | 3,492 |  |
| Balance as of December 31, 2013: |  |  |  |  |
| Goodwill |  | $ | 3,492 |  |
| Accumulated impairment losses |  |  | — |  |
| Total goodwill |  | $ | 3,492 |  |


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0001193125-14-071988:notes:182]
A summary of warranty
 expense and write-off activity for the years ended
 December 31, 2013 and 2012 is as follows:

[0001193125-14-071988:notes:183]
| Year Ended December 31, |  | 2013 |  |  | 2012 |  |
| (In thousands) |  |  |  |  |  |  |
| Balance at beginning of period |  | $ | 9,653 |  |  | $ | 4,118 |  |
| Plus: Amounts charged to cost and expenses |  |  | 4,051 |  |  |  | 5,363 |  |
| Amounts assumed on acquisition |  |  | — |  |  |  | 3,781 |  |
| Less: Deductions |  |  | (4,727 | ) |  |  | (3,609 | ) |
| Balance at end of period |  | $ | 8,977 |  |  | $ | 9,653 |  |


## us-gaap:SubsequentEventsTextBlock

[0001193125-14-071988:notes:184]
Note 17
 – Subsequent Events

[0001193125-14-071988:notes:185]
On
 January 21, 2014, the Board declared a quarterly cash dividend
 of $0.09 per common share to be paid to shareholders of record at
 the close of business on February 6, 2014. The quarterly
 dividend payment was $5.1 million and was paid on February 20,
 2014. In July 2003, our Board of Directors elected to begin
 declaring quarterly dividends on our common stock considering the
 tax treatment of dividends and adequate levels of Company
 liquidity.

[0001193125-14-071988:notes:186]
In February
 2014, we made a decision to make a $16.5 million principal payment
 on the Amended and Restated Bond. The restricted certificate of
 deposit included in our long-term investments will be reduced by
 the amount of the payment. We anticipate this payment will be made
 during the first quarter of 2014.

[0001193125-14-071988:notes:187]
As of
 February 27, 2014, we have repurchased 0.4 million shares
 of our common stock through open market purchases at an average
 cost of $25.13 per share. We currently have the authority to
 purchase an additional 3.1 million shares of our common stock
 under the current plan approved by the Board of
 Directors.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-14-071988:notes:188]
Note 10 – Income
 Taxes

[0001193125-14-071988:notes:189]
A summary of the components
 of the provision for income taxes for the years ended
 December 31, 2013, 2012 and 2011 is as follows:

[0001193125-14-071988:notes:190]
| (In thousands) |  | 2013 |  |  | 2012 |  |  | 2011 |  |
| Current |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  | $ | 15,641 |  |  | $ | 26,225 |  |  | $ | 59,382 |  |
| State |  |  | 2,041 |  |  |  | 3,766 |  |  |  | 7,177 |  |
| International |  |  | 1,437 |  |  |  | (504 | ) |  |  | 431 |  |
| Total Current |  |  | 19,119 |  |  |  | 29,487 |  |  |  | 66,990 |  |
| Deferred |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  |  | (3,606 | ) |  |  | (3,395 | ) |  |  | 527 |  |
| State |  |  | (412 | ) |  |  | (388 | ) |  |  | 60 |  |
| International |  |  | (40 | ) |  |  | (2 | ) |  |  | (12 | ) |
| Total Deferred |  |  | (4,058 | ) |  |  | (3,785 | ) |  |  | 575 |  |
| Total Provision for Income Taxes |  | $ | 15,061 |  |  | $ | 25,702 |  |  | $ | 67,565 |  |

[0001193125-14-071988:notes:191]
Our effective income tax
 rate differs from the federal statutory rate due to the
 following:

[0001193125-14-071988:notes:192]
|  |  | 2013 |  |  | 2012 |  |  | 2011 |  |
| Tax provision computed at the federal statutory rate |  |  | 35.00 | % |  |  | 35.00 | % |  |  | 35.00 | % |
| State income tax provision, net of federal benefit |  |  | 3.98 |  |  |  | 3.78 |  |  |  | 3.19 |  |
| Federal research credits |  |  | (9.24 | ) |  |  | — |  |  |  | (2.50 | ) |
| International |  |  | (2.93 | ) |  |  | 3.80 |  |  |  | — |  |
| Tax-exempt income |  |  | (1.11 | ) |  |  | (1.01 | ) |  |  | (0.27 | ) |
| State tax incentives |  |  | (2.19 | ) |  |  | (4.46 | ) |  |  | (0.90 | ) |
| Stock-based compensation |  |  | 2.97 |  |  |  | 2.36 |  |  |  | 0.03 |  |
| Domestic production activity deduction |  |  | (1.80 | ) |  |  | (3.21 | ) |  |  | (1.84 | ) |
| Other, net |  |  | 0.07 |  |  |  | (1.03 | ) |  |  | 0.07 |  |
| Effective Tax Rate |  |  | 24.75 | % |  |  | 35.23 | % |  |  | 32.78 | % |

[0001193125-14-071988:notes:193]
Income before provision for
 income taxes for the years ended December 31, 2013, 2012 and
 2011 is as follows:

[0001193125-14-071988:notes:194]
| (In thousands) |  | 2013 |  |  | 2012 |  |  | 2011 |  |
| U.S. entities |  | $ | 51,752 |  |  | $ | 80,926 |  |  | $ | 204,652 |  |
| International entities |  |  | 9,103 |  |  |  | (7,961 | ) |  |  | 1,490 |  |
| Total |  | $ | 60,855 |  |  | $ | 72,965 |  |  | $ | 206,142 |  |

[0001193125-14-071988:notes:195]
Income before provision for
 income taxes for international entities reflects income based on
 statutory transfer pricing agreements. This amount does not
 correlate to consolidated international revenues, many of which
 occur from our U.S. entity.

[0001193125-14-071988:notes:196]
Deferred income taxes on
 the balance sheet result from temporary differences between the
 amount of assets and liabilities recognized for financial reporting
 and tax purposes. The principal components of our current and
 non-current deferred taxes are as follows:

[0001193125-14-071988:notes:197]
| (In thousands) |  | 2013 |  |  | 2012 |  |
| Current deferred tax assets |  |  |  |  |  |  |  |  |
| Accounts receivable |  | $ | 51 |  |  | $ | 2 |  |
| Inventory |  |  | 9,877 |  |  |  | 7,507 |  |
| Accrued expenses |  |  | 7,155 |  |  |  | 5,546 |  |
| Total Current Deferred Tax Assets |  |  | 17,083 |  |  |  | 13,055 |  |
| Non-current deferred tax assets |  |  |  |  |  |  |  |  |
| Accrued expenses |  |  | 140 |  |  |  | 116 |  |
| Deferred compensation |  |  | 5,972 |  |  |  | 4,456 |  |
| Stock-based compensation |  |  | 5,331 |  |  |  | 4,569 |  |
| Uncertain tax positions related to state taxes and related interest |  |  | 1,107 |  |  |  | 1,005 |  |
| Pensions |  |  | 301 |  |  |  | 605 |  |
| Foreign losses |  |  | 5,702 |  |  |  | 6,978 |  |
| State losses and credit carry-forwards |  |  | 3,737 |  |  |  | 4,349 |  |
| Federal loss and research carry-forwards |  |  | 8,322 |  |  |  | 12,210 |  |
| Valuation allowance |  |  | (8,842 | ) |  |  | (10,939 | ) |
| Total Non-current Deferred Tax Assets |  |  | 21,770 |  |  |  | 23,349 |  |
| Total Deferred Tax Assets |  | $ | 38,853 |  |  | $ | 36,404 |  |
| Non-current deferred tax liabilities |  |  |  |  |  |  |  |  |
| Property, plant and equipment |  | $ | (5,499 | ) |  | $ | (6,405 | ) |
| Intellectual property |  |  | (1,006 | ) |  |  | (1,839 | ) |
| Investments |  |  | (5,643 | ) |  |  | (4,844 | ) |
| Total Non-current Deferred Tax Liabilities |  | $ | (12,148 | ) |  | $ | (13,088 | ) |
| Net Deferred Tax Assets |  | $ | 26,705 |  |  | $ | 23,316 |  |

[0001193125-14-071988:notes:198]
At December 31, 2013
 and 2012, non-current deferred tax liabilities and non-current
 deferred tax assets, respectively, related to our investments,
 reflect deferred taxes on unrealized gains and losses on
 available-for-sale investments. The net change in non-current
 deferred taxes associated with these investments, a deferred tax
 expense of $0.4 million in 2013 and a deferred tax benefit of $33
 thousand in 2012, is recorded as an adjustment to other
 comprehensive income, presented in the Consolidated Statements of
 Comprehensive Income.

[0001193125-14-071988:notes:199]
We have deferred tax assets
 for foreign and domestic loss carry-forwards, unamortized research
 and development costs and state credit carry-forwards of $19.0
 million which will expire between 2014 and 2030. The foreign loss
 carry-forwards were generated through the acquisition of a foreign
 entity in 2009 and through current losses at a foreign subsidiary.
 The unamortized research and development costs are related to our
 acquisition of Bluesocket in 2011. The state credit carry-forwards
 result from tax credits in excess of our annual tax liability to an
 individual state where we do not generate sufficient state income
 to offset the credit. We believe it is more likely than not that we
 will not realize the full benefits of the deferred tax asset
 arising from these losses and credits in various states and foreign
 countries, and accordingly, we have provided a valuation allowance
 against these deferred tax assets. We do not provide for U.S.
 income tax on undistributed earnings of our foreign operations,
 whose earnings are intended to be permanently reinvested. These
 earnings are not required to service debt or fund our U.S.
 operations.

[0001193125-14-071988:notes:200]
During 2013, 2012 and 2011,
 we recorded an income tax benefit of $0.2 million, $1.9 million and
 $10.5 million, respectively, as an adjustment to equity. This
 deduction is calculated on the difference between the exercise
 price of stock option exercises and the market price of the
 underlying common stock upon exercise.

[0001193125-14-071988:notes:201]
As of December 31,
 2013, 2012, and 2011, our total liability for unrecognized tax
 benefits was $3.2 million, $2.9 million, and $3.0 million,
 respectively, of which $2.5 million, $2.2 million, and $2.4
 million, respectively, would reduce our effective tax rate if we
 were successful in upholding all of the uncertain positions and
 recognized the amounts recorded. We classify interest and penalties
 recognized on the liability for unrecognized tax benefits as income
 tax expense. As of December 31, 2013, 2012 and 2011, the
 balances of accrued interest and penalties were $1.0 million, $0.8
 million and $1.2 million, respectively.

[0001193125-14-071988:notes:202]
We do not anticipate a
 single tax position generating a significant increase or decrease
 in our liability for unrecognized tax benefits within 12 months of
 this reporting date. We file income tax returns in the U.S. federal
 and various state jurisdictions and several foreign jurisdictions.
 We have been audited by the Internal Revenue Service and the state
 of Alabama through the 2009 tax year. Generally, we are not subject
 to changes in income taxes by any taxing jurisdiction for the years
 prior to 2010.


## us-gaap:ScheduleOfAvailableForSaleSecuritiesReconciliationTableTextBlock

[0001193125-14-071988:notes:203]
At December 31, 2013,
 we held the following securities and investments, recorded at
 either fair value or cost:

[0001193125-14-071988:notes:204]
|  |  | Amortized Cost |  |  | Gross Unrealized |  |  | Fair Value / Carrying Value |  |
| (In thousands) |  |  | Gains |  |  | Losses |  |  |
| Deferred compensation plan assets |  | $ | 12,300 |  |  | $ | 2,847 |  |  | $ | (24 | ) |  | $ | 15,123 |  |
| Corporate bonds |  |  | 166,370 |  |  |  | 534 |  |  |  | (45 | ) |  |  | 166,859 |  |
| Municipal fixed-rate bonds |  |  | 135,773 |  |  |  | 583 |  |  |  | (54 | ) |  |  | 136,302 |  |
| Municipal variable rate demand notes |  |  | 8,310 |  |  |  | — |  |  |  | — |  |  |  | 8,310 |  |
| Marketable equity securities |  |  | 24,654 |  |  |  | 13,975 |  |  |  | (177 | ) |  |  | 38,452 |  |
| Available-for-sale securities held at fair value |  | $ | 347,407 |  |  | $ | 17,939 |  |  | $ | (300 | ) |  | $ | 365,046 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 48,250 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1,689 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 414,985 |  |

[0001193125-14-071988:notes:205]
At December 31, 2012,
 we held the following securities and investments, recorded at
 either fair value or cost:

[0001193125-14-071988:notes:206]
|  |  | Amortized Cost |  |  | Gross Unrealized |  |  | Fair Value / Carrying Value |  |
| (In thousands) |  |  | Gains |  |  | Losses |  |  |
| Deferred compensation plan assets |  | $ | 10,688 |  |  | $ | 846 |  |  | $ | (7 | ) |  | $ | 11,527 |  |
| Corporate bonds |  |  | 185,464 |  |  |  | 966 |  |  |  | (18 | ) |  |  | 186,412 |  |
| Municipal fixed-rate bonds |  |  | 174,530 |  |  |  | 627 |  |  |  | (73 | ) |  |  | 175,084 |  |
| Municipal variable rate demand notes |  |  | 34,375 |  |  |  | — |  |  |  | — |  |  |  | 34,375 |  |
| Fixed income bond fund |  |  | 444 |  |  |  | 12 |  |  |  | — |  |  |  | 456 |  |
| Marketable equity securities |  |  | 20,966 |  |  |  | 14,630 |  |  |  | (392 | ) |  |  | 35,204 |  |
| Available-for-sale securities held at fair value |  | $ | 426,467 |  |  | $ | 17,081 |  |  | $ | (490 | ) |  | $ | 443,058 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 48,250 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1,902 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 493,210 |  |


## us-gaap:ScheduleOfDefinedBenefitPlanAmountsRecognizedInOtherComprehensiveIncomeLossTableTextBlock

[0001193125-14-071988:notes:207]
The components of net
 periodic pension cost and amounts recognized in other comprehensive
 income for the year ended December 31, 2013 and the period
 May 4, 2012 to December 31, 2012 are as
 follows:

[0001193125-14-071988:notes:208]
| (In thousands) |  | Year Ended December 31, 2013 |  |  | May 4, 2012 to December 31, 2012 |  |
| Net periodic benefit cost: |  |  |  |  |  |  |  |  |
| Service cost |  | $ | 1,198 |  |  | $ | 766 |  |
| Interest cost |  |  | 745 |  |  |  | 494 |  |
| Expected return on plan assets |  |  | (1,010 | ) |  |  | (674 | ) |
| Net periodic benefit cost |  |  | 933 |  |  |  | 586 |  |
| Other changes in plan assets and benefit obligations recognized in other comprehensive income: |  |  |  |  |  |  |  |  |
| Net actuarial (gain) loss |  |  | (779 | ) |  |  | 1,862 |  |
| Net unrealized (gain) loss on plan assets |  |  | (282 | ) |  |  | 90 |  |
| Other comprehensive (income) loss |  |  | (1,061 | ) |  |  | 1,952 |  |
| Total recognized in net periodic benefit cost and other comprehensive income |  | $ | (128 | ) |  | $ | 2,538 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001193125-14-071988:notes:209]
Note 11 – Employee
 Benefit Plans

[0001193125-14-071988:notes:210]
Pension Benefit
 Plan

[0001193125-14-071988:notes:211]
As a result of our
 acquisition of the NSN BBA business, we assumed a defined benefit
 pension plan covering employees in certain foreign countries. We
 established a Contribution Trust Arrangement (CTA) to hold the
 pension assets, and NSN transferred assets to us equal to the
 defined benefit obligation as of the May 4, 2012 acquisition
 date.

[0001193125-14-071988:notes:212]
The accumulated benefit
 obligation was $22.9 million and $20.8 million at December 31,
 2013 and 2012, respectively.

[0001193125-14-071988:notes:213]
The components of net
 periodic pension cost and amounts recognized in other comprehensive
 income for the year ended December 31, 2013 and the period
 May 4, 2012 to December 31, 2012 are as
 follows:

[0001193125-14-071988:notes:214]
The amounts recognized in
 accumulated other comprehensive income as of December 31, 2013
 and 2012 are as follows:

[0001193125-14-071988:notes:215]
| (In thousands) |  | 2013 |  |  | 2012 |  |
| Net actuarial (gain) loss |  | $ | 1,083 |  |  | $ | 1,862 |  |
| Net unrealized (gain) loss on plan assets |  |  | (192 | ) |  |  | 90 |  |
| Total |  | $ | 891 |  |  | $ | 1,952 |  |

[0001193125-14-071988:notes:216]
The defined benefit pension
 plan is accounted for on an actuarial basis, which requires the
 selection of various assumptions, including an expected rate of
 return on plan assets and a discount rate. The expected return on
 our German plan assets that is utilized in determining the benefit
 obligation and net periodic benefit cost is derived from periodic
 studies, which include a review of asset allocation strategies,
 anticipated future long-term performance of individual asset
 classes, risks using standard deviations and correlations of
 returns among the asset classes that comprise the plans’
 asset mix. While the studies give appropriate consideration to
 recent plan performance and historical returns, the assumptions are
 primarily long-term, prospective rates of return.

[0001193125-14-071988:notes:217]
Another key assumption in
 determining net pension expense is the assumed discount rate to be
 used to discount plan obligations. The discount rate has been
 derived from the returns of high-quality, corporate bonds
 denominated in Euro currency with durations close to the duration
 of our pension obligations.

[0001193125-14-071988:notes:218]
The weighted-average
 assumptions that were used to determine the net periodic benefit
 cost for the year ended December 31, 2013 and the period
 May 4, 2012 to December 31, 2012 are as
 follows:

[0001193125-14-071988:notes:219]
The weighted-average
 assumptions that were used to determine the benefit obligation at
 December 31, 2013 and 2012:

[0001193125-14-071988:notes:220]
|  |  | 2013 |  |  | 2012 |  |
| Discount rates |  |  | 3.70 | % |  |  | 3.50 | % |
| Rate of compensation increase |  |  | 2.25 | % |  |  | 2.25 | % |

[0001193125-14-071988:notes:221]
No amounts will be
 amortized from accumulated other comprehensive income into net
 periodic benefit cost during 2014.

[0001193125-14-071988:notes:222]
We do not anticipate making
 a contribution to our pension plan in 2014. The following pension
 benefit payments, which reflect expected future service, as
 appropriate, are expected to be paid to participants:

[0001193125-14-071988:notes:223]
Our investment policy
 includes various guidelines and procedures designed to ensure
 assets are invested in a manner necessary to meet expected future
 benefits earned by participants. The investments guidelines
 consider a broad range of economic conditions. Central to the
 policy are target allocation ranges by asset class, which is
 currently 75% for bond funds and 25% for equity funds.

[0001193125-14-071988:notes:224]
The objectives of the
 target allocations are to maintain investment portfolios that
 diversify risk through prudent asset allocation parameters, achieve
 asset returns that meet or exceed the plans’ actuarial
 assumptions, and achieve asset returns that are competitive with
 like institutions employing similar investment
 strategies.

[0001193125-14-071988:notes:225]
The investment policy is
 periodically reviewed by us and a designated third-party fiduciary
 for investment matters. The policy is established and administered
 in a manner that is compliant at all times with applicable
 government regulations.

[0001193125-14-071988:notes:226]
401(k) Savings
 Plan

[0001193125-14-071988:notes:227]
We maintain the ADTRAN,
 Inc. 401(k) Retirement Plan (Savings Plan) for the benefit of our
 eligible employees. The Savings Plan is intended to qualify under
 Sections 401(a) and 401(k) of the Internal Revenue Code of 1986, as
 amended (Code), and is intended to be a “safe harbor”
 401(k) plan under Code Section 401(k)(12). The Savings Plan
 allows employees to save for retirement by contributing part of
 their compensation to the plan on a tax-deferred basis. The Savings
 Plan also requires us to contribute a “safe harbor”
 amount each year. We match up to 4% of employee contributions (100%
 of an employee’s first 3% of contributions and 50% of their
 next 2% of contributions), beginning on the employee’s one
 year anniversary date. In calculating our matching contribution, we
 only use compensation up to the statutory maximum under the Code
 ($255 thousand for 2013). All contributions under the Savings Plan
 are 100% vested. Expenses recorded for employer contributions and
 plan administration costs for the Savings Plan amounted to
 approximately $4.5 million, $4.6 million and $4.3 million in 2013,
 2012 and 2011, respectively.

[0001193125-14-071988:notes:228]
Deferred Compensation
 Plans

[0001193125-14-071988:notes:229]
We maintain the ADTRAN,
 Inc. Deferred Compensation Plan (Deferred Compensation Plan). This
 plan is offered as a supplement to our tax-qualified 401(k) plan
 and is available to certain executive management employees who have
 been designated by our Board of Directors. The deferred
 compensation plan allows participants to defer all or a portion of
 certain specified bonuses and up to 25% of remaining cash
 compensation, and permits us to make matching contributions on a
 discretionary basis, without the limitations that apply to the
 401(k) plan. To date, we have not made any matching contributions
 under this plan.

[0001193125-14-071988:notes:230]
We also maintain the
 ADTRAN, Inc. Equity Deferral Program for Employees for the purpose
 of providing deferred compensation for certain executive management
 employees. Participants may elect to defer all or a portion of
 their vested Performance Share awards to the Plan. Such deferrals
 shall continue to be held and deemed to be invested in shares of
 ADTRAN stock unless and until the amounts are distributed or such
 deferrals are moved to another deemed investment pursuant to an
 election made by the Participant.

[0001193125-14-071988:notes:231]
We have set aside the plan
 assets for both plans in a rabbi trust (Trust) and all
 contributions are credited to bookkeeping accounts for the
 participants. The Trust assets are subject to the claims of our
 creditors in the event of bankruptcy or insolvency. The assets of
 the Trust are deemed to be invested in pre-approved mutual funds as
 directed by each participant, and the participant’s
 bookkeeping account is credited with the earnings and losses
 attributable to those investments. Benefits are scheduled to be
 distributed six months after termination of employment in a single
 lump sum payment or annual installments paid over a three or ten
 year term. Distributions will be made on a pro rata basis from each
 of the hypothetical investments of the Participant’s account
 in cash. Any whole shares of ADTRAN, Inc. common stock that are
 distributed will be distributed in-kind.

[0001193125-14-071988:notes:232]
Assets of the Trust are
 deemed invested in mutual funds that cover an investment spectrum
 ranging from equities to money market instruments. These mutual
 funds are publicly quoted and reported at fair value. The fair
 value of the assets held by the Trust and the amounts payable to
 the plan participants are as follows:

[0001193125-14-071988:notes:233]
| (In thousands) |  | 2013 |  |  | 2012 |  |
| Fair Value of Plan Assets |  |  |  |  |  |  |  |  |
| Long-term Investments |  | $ | 15,123 |  |  | $ | 11,527 |  |
| Total Fair Value of Plan Assets |  | $ | 15,123 |  |  | $ | 11,527 |  |
| Amounts Payable to Plan Participants |  |  |  |  |  |  |  |  |
| Non-current Liabilities |  | $ | 15,123 |  |  | $ | 11,527 |  |
| Total Amounts Payable to Plan Participants |  | $ | 15,123 |  |  | $ | 11,527 |  |

[0001193125-14-071988:notes:234]
Interest and dividend
 income of the Trust have been included in interest and dividend
 income in the accompanying 2013, 2012 and 2011 Consolidated
 Statements of Income. Changes in the fair value of the plan assets
 held by the Trust have been included in accumulated other
 comprehensive income in the accompanying 2013 and 2012 Consolidated
 Balance Sheets. Changes in the fair value of the deferred
 compensation liability are included as selling, general and
 administrative expense in the accompanying 2013, 2012 and 2011
 Consolidated Statements of Income. Based on the changes in the
 total fair value of the Trust’s assets, we recorded deferred
 compensation adjustments in 2013, 2012 and 2011 of $2.8 million,
 $0.9 million and $(0.2) million, respectively.

[0001193125-14-071988:notes:235]
Retiree Medical
 Coverage

[0001193125-14-071988:notes:236]
We provide medical, dental
 and prescription drug coverage to one retired former officer and
 his spouse, for his life, on the same terms as provided to our
 active officers, and to the spouse of a former deceased officer for
 up to 30 years. At December 31, 2013 and 2012, this liability
 totaled $0.2 million.


## us-gaap:EarningsPerShareTextBlock

[0001193125-14-071988:notes:237]
Note 14 – Earnings
 per Share

[0001193125-14-071988:notes:238]
For each of the years ended
 December 31, 2013, 2012 and 2011, 3.2 million,
 3.2 million and 1.2 million stock options were
 outstanding but were not included in the computation of that
 year’s diluted EPS because the options’ exercise prices
 were greater than the average market price of the common shares,
 therefore making them anti-dilutive under the treasury stock
 method.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001193125-14-071988:notes:239]
Note 16 – Related
 Party Transactions

[0001193125-14-071988:notes:240]
We employ the law firm of
 our director emeritus for legal services. All bills for services
 rendered by this firm are reviewed and approved by our Chief
 Financial Officer. We believe that the fees for such services are
 comparable to those charged by other firms for services rendered to
 us. For the years ended 2013, 2012 and 2011, we incurred fees of
 $10 thousand per month for these legal services.


## us-gaap:CompensationRelatedCostsPolicyTextBlock

[0001193125-14-071988:notes:241]
Stock-Based Compensation

[0001193125-14-071988:notes:242]
We have two Board and stockholder approved stock option plans from
 which stock options and other awards are available for grant to
 employees and directors. All employee and director stock options
 granted under our stock option plans have an exercise price equal
 to the fair market value of the award, as defined in the plan, of
 the underlying common stock on the grant date. There are currently
 no vesting provisions tied to performance or market conditions for
 any option awards; vesting for all outstanding option grants is
 based only on continued service as an employee or director of
 ADTRAN. All of our outstanding stock option awards are classified
 as equity awards.

[0001193125-14-071988:notes:243]
Under the provisions of our approved plans, we made grants of
 performance-based restricted stock units to five of our executive
 officers in 2013, 2012 and 2011. The restricted stock units are
 subject to a market condition based on the relative total
 shareholder return of ADTRAN against all the companies in the
 NASDAQ Telecommunications Index and vest at the end of a three-year
 performance period. The restricted stock units are converted into
 shares of common stock upon vesting. Depending on the relative
 total shareholder return over the performance period, the executive
 officers may earn from 0% to 150% of the number of restricted stock
 units granted. The fair value of the award is based on the market
 price of our common stock on the date of grant, adjusted for the
 expected outcome of the impact of market conditions using a Monte
 Carlo Simulation valuation method. The recipients of the restricted
 stock units also earn dividend credits during the performance
 period, which will be paid in cash upon the issuance of common
 stock for the restricted stock units.

[0001193125-14-071988:notes:244]
Stock-based compensation expense recognized in 2013, 2012 and 2011
 was approximately $9.1 million, $9.3 million
 and $9.2 million, respectively. As of December 31,
 2013, total compensation cost related to non-vested stock options,
 restricted stock units and restricted stock not yet recognized was
 approximately $18.8 million, which is expected to be recognized
 over an average remaining recognition period of 2.7 years. See Note
 3 of Notes to Consolidated Financial Statements for additional
 information.


## us-gaap:ScheduleOfFiniteLivedIntangibleAssetsTableTextBlock

[0001193125-14-071988:notes:245]
The following table
 presents our intangible assets as of December 31, 2013 and
 2012:

[0001193125-14-071988:notes:246]
| (In thousands) |  | 2013 |  |  | 2012 |  |
|  |  | Gross Value |  |  | Accumulated Amortization |  |  | Net Value |  |  | Gross Value |  |  | Accumulated Amortization |  |  | Net Value |  |
| Customer relationships |  | $ | 6,996 |  |  | $ | (1,555 | ) |  | $ | 5,441 |  |  | $ | 6,769 |  |  | $ | (766 | ) |  | $ | 6,003 |  |
| Developed technology |  |  | 6,537 |  |  |  | (2,692 | ) |  |  | 3,845 |  |  |  | 6,397 |  |  |  | (1,354 | ) |  |  | 5,043 |  |
| Intellectual property |  |  | 2,340 |  |  |  | (1,185 | ) |  |  | 1,155 |  |  |  | 2,340 |  |  |  | (851 | ) |  |  | 1,489 |  |
| Trade names |  |  | 270 |  |  |  | (145 | ) |  |  | 125 |  |  |  | 270 |  |  |  | (85 | ) |  |  | 185 |  |
| Other |  |  | 14 |  |  |  | (8 | ) |  |  | 6 |  |  |  | 13 |  |  |  | (3 | ) |  |  | 10 |  |
| Total |  | $ | 16,157 |  |  | $ | (5,585 | ) |  | $ | 10,572 |  |  | $ | 15,789 |  |  | $ | (3,059 | ) |  | $ | 12,730 |  |


## us-gaap:ImpairmentOrDisposalOfLongLivedAssetsPolicyTextBlock

[0001193125-14-071988:notes:247]
Impairment of Long-Lived Assets

[0001193125-14-071988:notes:248]
We review long-lived assets used in operations for impairment
 whenever events or changes in circumstances indicate that the
 carrying amount of an asset may not be recoverable and the
 undiscounted cash flows estimated to be generated by the asset are
 less than the asset’s carrying value. An impairment loss
 would be recognized in the amount by which the recorded value of
 the asset exceeds the fair value of the asset, measured by the
 quoted market price of an asset or an estimate based on the best
 information available in the circumstances. There were no
 impairment losses recognized during 2013, 2012 or 2011.


## us-gaap:ForeignCurrencyTransactionsAndTranslationsPolicyTextBlock

[0001193125-14-071988:notes:249]
Foreign Currency

[0001193125-14-071988:notes:250]
We record transactions denominated in foreign currencies on a
 monthly basis using exchange rates from throughout the year. Assets
 and liabilities denominated in foreign currencies are translated at
 the balance sheet dates using the closing rates of exchange between
 those foreign currencies and the U.S. dollar with any transaction
 gains or losses reported in other income (expense). Adjustments
 resulting from translating financial statements of international
 subsidiaries are recorded as a component of accumulated other
 comprehensive income (loss).


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001193125-14-071988:notes:251]
Note 1 – Nature of
 Business and Summary of Significant Accounting
 Policies

[0001193125-14-071988:notes:252]
ADTRAN, Inc. is a leading
 global provider of networking and communications equipment. Our
 solutions enable voice, data, video and Internet communications
 across a variety of network infrastructures. These solutions are
 deployed by some of the world’s largest service providers,
 distributed enterprises and small and medium-sized businesses,
 public and private enterprises, and millions of individual users
 worldwide.

[0001193125-14-071988:notes:253]
Changes in
 Classifications

[0001193125-14-071988:notes:254]
Certain balance sheet
 amounts (including inventory, accounts receivable, unearned revenue
 and accrued expenses) and related disclosures have been revised to
 correct immaterial misclassifications in 2012 that were corrected
 in 2013. The revisions decreased both total assets and total
 liabilities each by $2.7 million at December 31, 2012. The
 revisions had no impact on our previously reported
 stockholders’ equity, income statement, comprehensive income,
 or earnings per share. Additionally, we corrected immaterial
 misclassifications between the operating and investing sections of
 our consolidated statements of cash flows and adjusted our 2012 and
 2011 cash flows in these categories by $0.2 million and $0.1
 million, respectively, in order to be consistent with the 2013
 presentation.

[0001193125-14-071988:notes:255]
Additionally, changes in
 classifications have been made to the prior period balances in
 other comprehensive income to conform to the current period’s
 presentation as a result of our adoption of Accounting Standards
 Update No. 2013-02, Reporting of Amounts Reclassified Out of
 Accumulated Comprehensive Income.

[0001193125-14-071988:notes:256]
Out of Period
 Adjustment

[0001193125-14-071988:notes:257]
During the year ended
 December 31, 2013, we identified two adjustments in the
 acquired NSN (formerly Nokia Siemens Networks) Broadband Access
 business (NSN BBA business) relating to customer payment discounts
 for one customer, and recoverable VAT taxes on certain vendor
 freight invoices that should have been recorded in prior periods.
 These adjustments resulted from a $0.4 million understatement of
 net income in 2012. We evaluated the impact of the adjustments on
 the results of our previously issued financial statements for the
 prior period affected and concluded that the impact was not
 material. We also evaluated the impact of the cumulative effect of
 the adjustments in the current year and concluded that the impact
 was not material to our results for the year 2013. Accordingly,
 during the year ended December 31, 2013 we recorded an out of
 period adjustment to correct these issues.

[0001193125-14-071988:notes:258]
Use of
 Estimates

[0001193125-14-071988:notes:259]
The preparation of
 financial statements in conformity with accounting principles
 generally accepted in the United States of America requires
 management to make estimates and assumptions that affect the
 reported amounts of assets and liabilities, the disclosure of
 contingent assets and liabilities at the date of the financial
 statements, and the reported amounts of revenue and expense during
 the reporting period. Our more significant estimates include the
 obsolete and excess inventory reserves, warranty reserves, customer
 rebates, determination of the deferred revenue components of
 multiple element sales agreements, estimated costs to complete
 obligations associated with deferred revenues, estimated income tax
 provision and income tax contingencies, the fair value of
 stock-based compensation, impairment of goodwill, valuation and
 estimated lives of intangible assets, estimated working capital
 adjustments under negotiation related to the NSN BBA business
 acquisition, estimated pension liability, fair value of
 investments, and the evaluation of other-than-temporary declines in
 the value of investments. Actual amounts could differ significantly
 from these estimates.

[0001193125-14-071988:notes:260]
Cash and Cash
 Equivalents

[0001193125-14-071988:notes:261]
Cash and cash equivalents
 represent demand deposits, money market funds, and short-term
 investments classified as available-for-sale with original
 maturities of three months or less. We maintain depository
 investments with certain financial institutions. Although these
 depository investments may exceed government insured depository
 limits, we have evaluated the credit worthiness of these applicable
 financial institutions, and determined the risk of material
 financial loss due to the exposure of such credit risk to be
 minimal. As of December 31, 2013, $53.5 million of our cash
 and cash equivalents, primarily certain domestic money market funds
 and foreign depository accounts, were in excess of government
 provided insured depository limits.

[0001193125-14-071988:notes:262]
Financial
 Instruments

[0001193125-14-071988:notes:263]
The carrying amounts
 reported in the consolidated balance sheets for cash and cash
 equivalents, accounts receivable, and accounts payable approximate
 fair value due to the immediate or short-term maturity of these
 financial instruments. The carrying amount reported for bonds
 payable was $46.5 million, compared to an estimated fair value of
 $45.4 million, based on a debt security with a comparable interest
 rate and maturity and a Standard & Poor’s credit
 rating of A-.

[0001193125-14-071988:notes:264]
Investments with
 contractual maturities beyond one year, such as our municipal
 variable rate demand notes, may be classified as short-term based
 on their highly liquid nature and because such marketable
 securities represent the investment of cash that is available for
 current operations. Despite the long-term nature of their stated
 contractual maturities, we routinely buy and sell these securities
 and we believe we have the ability to quickly sell them to the
 remarketing agent, tender agent, or issuer at par value plus
 accrued interest in the event we decide to liquidate our investment
 in a particular variable rate demand note. All income generated
 from these investments was recorded as interest income. We have not
 been required to record any losses relating to municipal variable
 rate demand notes.

[0001193125-14-071988:notes:265]
Long-term investments
 represent a restricted certificate of deposit held at cost,
 municipal fixed-rate bonds, corporate bonds, a fixed income bond
 fund, marketable equity securities, and other equity investments.
 Marketable equity securities are reported at fair value as
 determined by the most recently traded price of the securities at
 the balance sheet date, although the securities may not be readily
 marketable due to the size of the available market. Unrealized
 gains and losses, net of tax, are reported as a separate component
 of stockholders’ equity. Realized gains and losses on sales
 of securities are computed under the specific identification method
 and are included in current income. We periodically review our
 investment portfolio for investments considered to have sustained
 an other-than-temporary decline in value. Impairment charges for
 other-than-temporary declines in value are recorded as realized
 losses in the accompanying consolidated statements of income. All
 of our investments at December 31, 2013 and 2012 are
 classified as available-for-sale securities. See Note 4 of Notes to
 Consolidated Financial Statements for additional
 information.

[0001193125-14-071988:notes:266]
Other
 Receivables

[0001193125-14-071988:notes:267]
Other receivables are
 comprised primarily of amounts due from subcontract manufacturers
 for product component transfers, accrued interest on investments
 and on a restricted certificate of deposit, and amounts due from
 employee stock option exercises. At December 31, 2013 and
 2012, other receivables also included an estimated receivable due
 from NSN related to working capital adjustments that are currently
 under negotiation.

[0001193125-14-071988:notes:268]
Inventory is carried at the
 lower of cost or market, with cost being determined using the
 first-in, first-out method. Standard costs for material, labor and
 manufacturing overhead are used to value inventory. Standard costs
 are updated at least quarterly; therefore, inventory costs
 approximate actual costs at the end of each reporting period. We
 establish reserves for estimated excess, obsolete or unmarketable
 inventory equal to the difference between the cost of the inventory
 and the estimated fair value of the inventory based upon
 assumptions about future demand and market conditions. When we
 dispose of excess and obsolete inventories, the related write-downs
 are charged against the inventory reserve. See Note 6 of Notes to
 Consolidated Financial Statements for additional
 information.

[0001193125-14-071988:notes:269]
Property, Plant and
 Equipment

[0001193125-14-071988:notes:270]
Property, plant and
 equipment, which is stated at cost, is depreciated using the
 straight-line method over the estimated useful lives of the assets.
 We depreciate building and land improvements from five to 39 years,
 office machinery and equipment from three to seven years,
 engineering machinery and equipment from three to seven years, and
 computer software from three to five years. Expenditures for
 repairs and maintenance are charged to expense as incurred.
 Betterments that materially prolong the lives of the assets are
 capitalized. The cost of assets retired or otherwise disposed of
 and the related accumulated depreciation are removed from the
 accounts, and the gain or loss on such disposition is included in
 other income (expense), net in the accompanying consolidated
 statements of income. See Note 7 of Notes to Consolidated Financial
 Statements for additional information.

[0001193125-14-071988:notes:271]
Liability for
 Warranty

[0001193125-14-071988:notes:272]
Our products generally
 include warranties of 90 days to ten years for product defects. We
 accrue for warranty returns at the time revenue is recognized based
 on our estimate of the cost to repair or replace the defective
 products. We engage in extensive product quality programs and
 processes, including actively monitoring and evaluating the quality
 of our component suppliers. Our products continue to become more
 complex in both size and functionality as many of our product
 offerings migrate from line card applications to systems products.
 The increasing complexity of our products will cause warranty
 incidences, when they arise, to be more costly. Our estimates
 regarding future warranty obligations may change due to product
 failure rates, material usage, and other rework costs incurred in
 correcting a product failure. In addition, from time to time,
 specific warranty accruals may be recorded if unforeseen problems
 arise. Should our actual experience relative to these factors be
 worse than our estimates, we will be required to record additional
 warranty expense. Alternatively, if we provide for more reserves
 than we require, we will reverse a portion of such provisions in
 future periods. The liability for warranty obligations totaled $9.0
 million and $9.7 million at December 31, 2013 and 2012,
 respectively. These liabilities are included in accrued expenses in
 the accompanying consolidated balance sheets.

[0001193125-14-071988:notes:273]
Pension Benefit Plan
 Obligations

[0001193125-14-071988:notes:274]
As a result of our
 acquisition of the NSN BBA business, we assumed a defined benefit
 pension plan covering employees in certain foreign countries.
 Pension benefit plan obligations are based on various assumptions
 used by our actuaries in calculating these amounts. These
 assumptions include discount rates, compensation rate increases,
 expected return on plan assets, retirement rates and mortality
 rates. Actual results that differ from the assumptions and changes
 in assumptions could affect future expenses and
 obligations.

[0001193125-14-071988:notes:275]
Stock-Based
 Compensation

[0001193125-14-071988:notes:276]
We have two Board and
 stockholder approved stock option plans from which stock options
 and other awards are available for grant to employees and
 directors. All employee and director stock options granted under
 our stock option plans have an exercise price equal to the fair
 market value of the award, as defined in the plan, of the
 underlying common stock on the grant date. There are currently no
 vesting provisions tied to performance or market conditions for any
 option awards; vesting for all outstanding option grants is based
 only on continued service as an employee or director of ADTRAN. All
 of our outstanding stock option awards are classified as equity
 awards.

[0001193125-14-071988:notes:277]
Under the provisions of our
 approved plans, we made grants of performance-based restricted
 stock units to five of our executive officers in 2013, 2012 and
 2011. The restricted stock units are subject to a market condition
 based on the relative total shareholder return of ADTRAN against
 all the companies in the NASDAQ Telecommunications Index and vest
 at the end of a three-year performance period. The restricted stock
 units are converted into shares of common stock upon vesting.
 Depending on the relative total shareholder return over the
 performance period, the executive officers may earn from 0% to 150%
 of the number of restricted stock units granted. The fair value of
 the award is based on the market price of our common stock on the
 date of grant, adjusted for the expected outcome of the impact of
 market conditions using a Monte Carlo Simulation valuation method.
 The recipients of the restricted stock units also earn dividend
 credits during the performance period, which will be paid in cash
 upon the issuance of common stock for the restricted stock
 units.

[0001193125-14-071988:notes:278]
Stock-based compensation
 expense recognized in 2013, 2012 and 2011 was approximately $9.1
 million, $9.3 million and $9.2 million, respectively. As of
 December 31, 2013, total compensation cost related to
 non-vested stock options, restricted stock units and restricted
 stock not yet recognized was approximately $18.8 million, which is
 expected to be recognized over an average remaining recognition
 period of 2.7 years. See Note 3 of Notes to Consolidated Financial
 Statements for additional information.

[0001193125-14-071988:notes:279]
Impairment of Long-Lived
 Assets

[0001193125-14-071988:notes:280]
We review long-lived assets
 used in operations for impairment whenever events or changes in
 circumstances indicate that the carrying amount of an asset may not
 be recoverable and the undiscounted cash flows estimated to be
 generated by the asset are less than the asset’s carrying
 value. An impairment loss would be recognized in the amount by
 which the recorded value of the asset exceeds the fair value of the
 asset, measured by the quoted market price of an asset or an
 estimate based on the best information available in the
 circumstances. There were no impairment losses recognized during
 2013, 2012 or 2011.

[0001193125-14-071988:notes:281]
Goodwill and Purchased
 Intangible Assets

[0001193125-14-071988:notes:282]
We evaluate the carrying
 value of goodwill during the fourth quarter of each year and
 between annual evaluations if events occur or circumstances change
 that would more likely than not reduce the fair value of the
 reporting unit below its carrying amount. When evaluating whether
 goodwill is impaired, we first assess qualitative factors to
 determine whether it is necessary to perform the two-step
 quantitative goodwill impairment test. If we determine that the
 two-step quantitative test is necessary, then we compare the fair
 value of the reporting unit to which the goodwill is assigned to
 the reporting unit’s carrying amount, including goodwill. If
 the carrying amount of the reporting unit exceeds its fair value,
 then the amount of the impairment loss is measured. There were no
 impairment losses recognized during 2013, 2012 or 2011. Purchased
 intangible assets with finite lives are carried at cost, less
 accumulated amortization. Amortization is recorded over the
 estimated useful lives of the respective assets, which is 2.5 to 14
 years.

[0001193125-14-071988:notes:283]
Research and Development
 Costs

[0001193125-14-071988:notes:284]
Research and development
 costs include compensation for engineers and support personnel,
 outside contracted services, depreciation and material costs
 associated with new product development, the enhancement of current
 products, and product cost reductions. We continually evaluate new
 product opportunities and engage in intensive research and product
 development efforts. Research and development costs totaled $131.1
 million, $126.0 million and $100.3 million for the years ended
 December 31, 2013, 2012 and 2011, respectively.

[0001193125-14-071988:notes:285]
Income
 Taxes

[0001193125-14-071988:notes:286]
The provision for income
 taxes has been determined using the asset and liability approach of
 accounting for income taxes. Under this approach, deferred taxes
 represent the future tax consequences expected to occur when the
 reported amounts of assets and liabilities are recovered or paid.
 The provision for income taxes represents income taxes paid or
 payable for the current year plus the change in deferred taxes
 during the year. Deferred taxes result from the difference between
 financial and tax bases of our assets and liabilities and are
 adjusted for changes in tax rates and tax laws when such changes
 are enacted. Valuation allowances are recorded to reduce deferred
 tax assets when it is more likely than not that a tax benefit will
 not be realized.

[0001193125-14-071988:notes:287]
We establish reserves to
 remove some or all of the tax benefit of any of our tax positions
 at the time we determine that the positions become uncertain. We
 adjust these reserves, including any impact on the related interest
 and penalties, as facts and circumstances change.

[0001193125-14-071988:notes:288]
Foreign
 Currency

[0001193125-14-071988:notes:289]
We record transactions
 denominated in foreign currencies on a monthly basis using exchange
 rates from throughout the year. Assets and liabilities denominated
 in foreign currencies are translated at the balance sheet dates
 using the closing rates of exchange between those foreign
 currencies and the U.S. dollar with any transaction gains or losses
 reported in other income (expense). Adjustments resulting from
 translating financial statements of international subsidiaries are
 recorded as a component of accumulated other comprehensive income
 (loss).

[0001193125-14-071988:notes:290]
Unearned
 Revenue

[0001193125-14-071988:notes:291]
Unearned revenue primarily
 represents customer billings on our maintenance service programs
 and unearned revenues relating to multiple element contracts where
 we still have contractual obligations to our customers. We
 currently offer maintenance contracts ranging from one to five
 years, primarily on Enterprise Networks Division products sold
 through distribution channels. Revenue attributable to maintenance
 contracts is recognized on a straight-line basis over the related
 contract term. In addition, we provide software maintenance and a
 variety of hardware maintenance services to Carrier Networks
 Division customers, which include customers of the acquired NSN BBA
 business, under contracts with terms up to ten years. At
 December 31, 2013 and 2012, unearned revenue was as
 follows:

[0001193125-14-071988:notes:292]
Other Income (Expense),
 Net

[0001193125-14-071988:notes:293]
Other income (expense),
 net, is comprised primarily of miscellaneous income and expense,
 gains and losses on foreign currency transactions, investment
 account management fees, and gains or losses on the disposal of
 property, plant and equipment occurring in the normal course of
 business.

[0001193125-14-071988:notes:294]
Earnings per
 Share

[0001193125-14-071988:notes:295]
Earnings per common share,
 and earnings per common share assuming dilution, are based on the
 weighted average number of common shares and, when dilutive, common
 equivalent shares outstanding during the year. See Note 14 of Notes
 to Consolidated Financial Statements for additional
 information.

[0001193125-14-071988:notes:296]
Dividends

[0001193125-14-071988:notes:297]
The Board of Directors
 presently anticipates that it will declare a regular quarterly
 dividend as long as the current tax treatment of dividends exists
 and adequate levels of liquidity are maintained. During the years
 ended December 31, 2013, 2012 and 2011, we paid $21.4 million,
 $22.8 million and $23.1 million, respectively, in shareholder
 dividends. On January 21, 2014, the Board of Directors
 declared a quarterly cash dividend of $0.09 per common share to be
 paid to shareholders of record at the close of business on
 February 6, 2014. The ex-dividend date was February 4,
 2014 and the payment date was February 20, 2014. The quarterly
 dividend payment was $5.1 million.

[0001193125-14-071988:notes:298]
Business
 Combinations

[0001193125-14-071988:notes:299]
We use the acquisition
 method to account for business combinations. Under the acquisition
 method of accounting, we recognize the assets acquired and
 liabilities assumed at their fair value on the acquisition date.
 Goodwill is measured as the excess of the consideration transferred
 over the net assets acquired. Costs incurred to complete the
 business combination, such as legal, accounting or other
 professional fees, are charged to general and administrative
 expenses as they are incurred.

[0001193125-14-071988:notes:300]
Recently Issued
 Accounting Standards

[0001193125-14-071988:notes:301]
During 2013, we adopted the
 following accounting standards, which had no material effect on our
 consolidated results of operations or financial
 condition:

[0001193125-14-071988:notes:302]
In February 2013, the FASB
 issued Accounting Standards Update No. 2013-02, Reporting of
 Amounts Reclassified Out of Accumulated Other Comprehensive Income
 (ASU 2013-02). ASU 2013-02 requires entities to provide information
 about the amounts reclassified out of accumulated other
 comprehensive income by component either on the face of the
 financial statements or in the footnotes. ASU 2013-02 does not
 change the current requirements for reporting net income or other
 comprehensive income in the financial statements. This update is
 effective prospectively for reporting periods beginning after
 December 15, 2012. We adopted this amendment during the first
 quarter of 2013, and we have provided the disclosures required for
 the years ended December 31, 2013, 2012 and 2011 in Note 1 of
 Notes to Consolidated Financial Statements.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001193125-14-071988:notes:303]
Note 4 –
 Investments

[0001193125-14-071988:notes:304]
Our investment policy
 provides limitations for issuer concentration, which limits, at the
 time of purchase, the concentration in any one issuer to 5% of the
 market value of our total investment portfolio.

[0001193125-14-071988:notes:305]
We review our investment
 portfolio for potential “other-than-temporary” declines
 in value on an individual investment basis. We assess, on a
 quarterly basis, significant declines in value which may be
 considered other-than-temporary and, if necessary, recognize and
 record the appropriate charge to write-down the carrying value of
 such investments. In making this assessment, we take into
 consideration qualitative and quantitative information, including
 but not limited to the following: the magnitude and duration of
 historical declines in market prices, credit rating activity,
 assessments of liquidity, public filings, and statements made by
 the issuer. We generally begin our identification of potential
 other-than-temporary impairments by reviewing any security with a
 fair value that has declined from its original or adjusted cost
 basis by 25% or more for six or more consecutive months. We then
 evaluate the individual security based on the previously identified
 factors to determine the amount of the write-down, if any. As a
 result of our review, we recorded an other-than-temporary
 impairment charge of $11 thousand during the fourth quarter of
 2013. For each of the years ended December 31, 2013, 2012 and
 2011 we recorded a charge of $25 thousand, $0.7 million and $68
 thousand, respectively, related to the other-than-temporary
 impairment of certain marketable equity securities and our deferred
 compensation plan assets.

[0001193125-14-071988:notes:306]
Realized gains and losses
 on sales of securities are computed under the specific
 identification method. The following table presents gross realized
 gains and losses related to our investments for the years ended
 December 31, 2013, 2012 and 2011:

[0001193125-14-071988:notes:307]
The following table
 presents the breakdown of investments with unrealized losses at
 December 31, 2013:

[0001193125-14-071988:notes:308]
| (In thousands) |  | Continuous Unrealized Loss Position for Less than 12 Months |  |  | Continuous Unrealized Loss Position for 12 Months or Greater |  |  | Total |  |
|  |  | Fair Value |  |  | Unrealized Losses |  |  | Fair Value |  |  | Unrealized Losses |  |  | Fair Value |  |  | Unrealized Losses |  |
| Deferred compensation plan assets |  | $ | 48 |  |  | $ | (6 | ) |  | $ | 409 |  |  | $ | (18 | ) |  | $ | 457 |  |  | $ | (24 | ) |
| Corporate bonds |  |  | 20,697 |  |  |  | (45 | ) |  |  | — |  |  |  | — |  |  |  | 20,697 |  |  |  | (45 | ) |
| Municipal fixed-rate bonds |  |  | 13,733 |  |  |  | (54 | ) |  |  | — |  |  |  | — |  |  |  | 13,733 |  |  |  | (54 | ) |
| Marketable equity securities |  |  | 2,758 |  |  |  | (173 | ) |  |  | 31 |  |  |  | (4 | ) |  |  | 2,789 |  |  |  | (177 | ) |
| Total |  | $ | 37,236 |  |  | $ | (278 | ) |  | $ | 440 |  |  | $ | (22 | ) |  | $ | 37,676 |  |  | $ | (300 | ) |

[0001193125-14-071988:notes:309]
The following table
 presents the breakdown of investments with unrealized losses at
 December 31, 2012.

[0001193125-14-071988:notes:310]
| (In thousands) |  | Continuous Unrealized Loss Position for Less than 12 Months |  |  | Continuous Unrealized Loss Position for 12 Months or Greater |  |  | Total |  |
|  |  | Fair Value |  |  | Unrealized Losses |  |  | Fair Value |  |  | Unrealized Losses |  |  | Fair Value |  |  | Unrealized Losses |  |
| Deferred compensation plan assets |  | $ | 915 |  |  | $ | (7 | ) |  | $ | — |  |  | $ | — |  |  | $ | 915 |  |  | $ | (7 | ) |
| Corporate bonds |  |  | 20,204 |  |  |  | (17 | ) |  |  | 1,600 |  |  |  | (1 | ) |  |  | 21,804 |  |  |  | (18 | ) |
| Municipal fixed-rate bonds |  |  | 34,297 |  |  |  | (73 | ) |  |  | — |  |  |  | — |  |  |  | 34,297 |  |  |  | (73 | ) |
| Marketable equity securities |  |  | 6,171 |  |  |  | (355 | ) |  |  | 230 |  |  |  | (37 | ) |  |  | 6,401 |  |  |  | (392 | ) |
| Total |  | $ | 61,587 |  |  | $ | (452 | ) |  | $ | 1,830 |  |  | $ | (38 | ) |  | $ | 63,417 |  |  | $ | (490 | ) |

[0001193125-14-071988:notes:311]
The decrease in unrealized
 losses during 2013, as reflected in the table above, is primarily
 due to the restructuring of our investment portfolio relating to
 marketable equity securities in December 2013 resulting in the sale
 of several securities in an unrealized loss position. At
 December 31, 2013, a total of 168 of our marketable equity
 securities were in an unrealized loss position.

[0001193125-14-071988:notes:312]
The fair value of our Level
 2 securities is calculated using a weighted average market price
 for each security. Market prices are obtained from a variety of
 industry standard data providers, security master files from large
 financial institutions, and other third-party sources. These
 multiple market prices are used as inputs into a
 distribution-curve-based algorithm to determine the daily market
 value of each security.

[0001193125-14-071988:notes:313]
Our municipal variable rate
 demand notes have a structure that implies a standard expected
 market price. The frequent interest rate resets make it reasonable
 to expect the price to stay at par. These securities are priced at
 the expected market price.


## us-gaap:GoodwillDisclosureTextBlock

[0001193125-14-071988:notes:314]
Note 8 – Goodwill
 and Intangible Assets

[0001193125-14-071988:notes:315]
We evaluate the carrying
 value of goodwill during the fourth quarter of each year and
 between annual evaluations if events occur or circumstances change
 that would more likely than not reduce the fair value of the
 reporting unit below its carrying amount. When evaluating whether
 goodwill is impaired, we compare the fair value of the reporting
 unit to which the goodwill is assigned to the reporting
 unit’s carrying amount, including goodwill. If the carrying
 amount of the reporting unit exceeds its fair value, then the
 amount of the impairment loss is measured. There were no impairment
 losses recognized during 2013 or 2012.

[0001193125-14-071988:notes:316]
Intangible assets are
 included in other assets in the accompanying Consolidated Balance
 Sheets and include intangible assets acquired in conjunction with
 our acquisition of Objectworld Communications Corporation on
 September 15, 2009, Bluesocket, Inc. on August 4, 2011,
 and the NSN BBA business on May 4, 2012.

[0001193125-14-071988:notes:317]
Amortization expense was
 $2.4 million, $2.0 million and $0.7 million in 2013, 2012 and 2011,
 respectively.


## adtn:IndustrialDevelopmentAuthorityFinancingAndEconomicIncentivesTextBlock

[0001193125-14-071988:notes:318]
Note 9 – Alabama
 State Industrial Development Authority Financing and Economic
 Incentives

[0001193125-14-071988:notes:319]
In conjunction with an
 expansion of our Huntsville, Alabama, facility, we were approved
 for participation in an incentive program offered by the State of
 Alabama Industrial Development Authority (the
 “Authority”). Pursuant to the program, on
 January 13, 1995, the Authority issued $20.0 million of its
 taxable revenue bonds and loaned the proceeds from the sale of the
 bonds to ADTRAN. The bonds were originally purchased by AmSouth
 Bank of Alabama, Birmingham, Alabama (the “Bank”).
 Wachovia Bank, N.A., Nashville, Tennessee (formerly First Union
 National Bank of Tennessee) (the “Bondholder”), which
 was acquired by Wells Fargo & Company on December 31,
 2008, purchased the original bonds from the Bank and made further
 advances to the Authority, bringing the total amount outstanding to
 $50.0 million. An Amended and Restated Taxable Revenue Bond
 (“Amended and Restated Bond”) was issued and the
 original financing agreement was amended. The Amended and Restated
 Bond bears interest, payable monthly. The interest rate is
 5% per annum. The Amended and Restated Bond matures on
 January 1, 2020. The estimated fair value of the bond using a
 level 2 valuation technique at December 31, 2013 was
 approximately $45.4 million, based on a debt security with a
 comparable interest rate and maturity and a Standard &
 Poor’s credit rating of A-. We are required to make payments
 to the Authority in amounts necessary to pay the interest on the
 Amended and Restated Bond. Included in long-term investments at
 December 31, 2013 is $48.3 million which is invested in a
 restricted certificate of deposit. These funds serve as a
 collateral deposit against the principal of this bond, and we have
 the right to set-off the balance of the Bond with the collateral
 deposit in order to reduce the balance of the
 indebtedness.

[0001193125-14-071988:notes:320]
In conjunction with this
 program, we are eligible to receive certain economic incentives
 from the state of Alabama that reduce the amount of payroll
 withholdings that we are required to remit to the state for those
 employment positions that qualify under the program. For the years
 ended December 31, 2013, 2012 and 2011, we realized economic
 incentives related to payroll withholdings totaling $1.3 million,
 $1.4 million and $1.9 million, respectively.

[0001193125-14-071988:notes:321]
We did not make a principal
 payment for the year-ended December 31, 2013. We made a
 principal payment of $0.5 million for the year ended
 December 31, 2012. We anticipate making a principal payment in
 2014. At December 31, 2013 and 2012, $0.3 million and $0.5
 million, respectively, of the bond debt were classified as a
 current liability in accounts payable in the Consolidated Balance
 Sheets at December 31, 2013.
