# ADTN 8-K — 0001157523-14-000154 filed 2014-01-22

## item codes, every 8-K on or before 2014-02-27

- 2014-01-22 0001157523-14-000154 — 2.02, 9.01
- 2013-10-15 0001193125-13-399540 — 5.02
- 2013-10-09 0001157523-13-004657 — 2.02, 9.01
- 2013-07-10 0001157523-13-003290 — 2.02, 9.01
- 2013-05-10 0001193125-13-213728 — 5.07
- 2013-05-03 0001193125-13-198816 — 8.01, 9.01
- 2013-04-10 0001157523-13-001730 — 2.02, 9.01
- 2013-01-16 0001157523-13-000139 — 2.02, 9.01
- 2012-10-10 0001157523-12-005081 — 2.02, 9.01
- 2012-10-03 0001193125-12-413609 — 7.01
- 2012-09-28 0001193125-12-408878 — 2.02, 9.01
- 2012-07-11 0001157523-12-003592 — 2.02, 9.01
- 2012-05-10 0001193125-12-225669 — 5.07
- 2012-05-10 0001193125-12-225639 — 8.01, 9.01
- 2012-04-11 0001157523-12-001772 — 2.02, 9.01
- 2012-03-15 0001193125-12-116494 — 2.02, 9.01
- 2012-01-18 0001157523-12-000174 — 2.02, 9.01
- 2011-12-12 0001193125-11-337271 — 7.01, 9.01
- 2011-10-13 0000950123-11-089785 — 5.03, 9.01
- 2011-10-12 0001157523-11-005682 — 2.02, 9.01
- 2011-07-13 0001157523-11-003986 — 2.02, 9.01
- 2011-05-09 0000950123-11-047191 — 5.02, 5.07, 9.01
- 2011-04-13 0001157523-11-002001 — 2.02, 9.01
- 2011-01-19 0001157523-11-000232 — 2.02, 9.01
- 2010-11-09 0000950123-10-103195 — 5.02, 9.01
- 2010-10-13 0001157523-10-005798 — 2.02, 9.01
- 2010-07-14 0001157523-10-004011 — 2.02, 9.01
- 2010-05-28 0000950123-10-053947 — 5.07
- 2010-04-14 0001157523-10-002022 — 2.02, 9.01
- 2010-01-20 0001157523-10-000200 — 2.02, 9.01
- 2009-10-28 0000950123-09-053984 — 8.01
- 2009-10-14 0001157523-09-006877 — 2.02, 9.01
- 2009-07-15 0001157523-09-004878 — 2.02, 9.01
- 2009-04-15 0001157523-09-002687 — 2.02, 9.01
- 2009-01-21 0001157523-09-000340 — 2.02, 9.01
- 2008-11-12 0001193125-08-233181 — 5.02, 9.01
- 2008-10-14 0001157523-08-007999 — 2.02, 9.01
- 2008-07-15 0001157523-08-005504 — 2.02, 9.01
- 2008-04-15 0001157523-08-002896 — 2.02, 9.01
- 2008-01-22 0001157523-08-000408 — 2.02, 9.01
- 2007-10-16 0001193125-07-219356 — 5.03, 9.01
- 2007-10-16 0001157523-07-009850 — 2.02, 9.01
- 2007-07-17 0001157523-07-006912 — 2.02, 9.01
- 2007-04-17 0001157523-07-003630 — 2.02, 9.01
- 2007-04-03 0001179022-07-000068 — 5.02
- 2007-03-28 0001179022-07-000064 — 5.02
- 2007-02-23 0001193125-07-038337 — 5.02
- 2007-02-23 0001193125-07-038335 — 5.02
- 2007-01-30 0001193125-07-015912 — 5.02, 9.01
- 2007-01-26 0001193125-07-014234 — 5.02
- 2007-01-23 0001157523-07-000494 — 2.02, 9.01 — amendment of 0001157523-07-000481
- 2007-01-23 0001157523-07-000481 — 2.02, 9.01
- 2006-10-17 0001157523-06-009945 — 2.02, 9.01
- 2006-07-18 0001157523-06-006929 — 2.02, 9.01
- 2006-06-08 0001193125-06-126486 — 1.01, 9.01
- 2006-05-10 0001193125-06-107316 — 1.01, 9.01
- 2006-04-18 0001157523-06-003699 — 2.02, 9.01
- 2006-02-03 0001179022-06-000014 — 1.01
- 2006-01-27 0001157523-06-000754 — 5.02, 9.01
- 2006-01-24 0001157523-06-000551 — 2.02, 9.01
- 2005-10-18 0001157523-05-008826 — 2.02, 9.01
- 2005-07-19 0001193125-05-143958 — 1.01, 5.02, 9.01
- 2005-07-19 0001193125-05-143957 — 2.02, 9.01
- 2005-05-20 0001193125-05-112019 — 1.01, 9.01
- 2005-04-19 0001157523-05-003418 — 2.02, 9.01
- 2005-01-25 0001193125-05-010721 — 2.02, 9.01
- 2004-10-12 0001193125-04-169652 — 2.02, 9.01
- 2004-07-13 0001193125-04-116820 — 12, 7
- 2004-04-14 0001193125-04-061547 — 12, 7
- 2004-01-21 0001193125-04-006366 — 12, 7
- 2003-10-14 0001193125-03-061018 — 12, 5, 7
- 2003-07-15 0001193125-03-019292 — 7, 9
- 2003-04-15 0000931763-03-000968 — 7, 9
- 1996-09-12 0000931763-96-000667 — 5, 7

## late-filing notifications on or before 2014-02-27

- none on or before 2014-02-27

## item 2.02 — earnings release, exhibit 99.1

[0001157523-14-000154:8k_2_02:1]
EX-99.1
2
a50788047_ex99-1.htm
EXHIBIT 99.1

[0001157523-14-000154:8k_2_02:2]
Exhibit 99.1

[0001157523-14-000154:8k_2_02:3]
ADTRAN,
      Inc. Reports Results for the Fourth Quarter 2013 and Declares Quarterly
      Cash Dividend

[0001157523-14-000154:8k_2_02:4]
HUNTSVILLE, Ala.--(BUSINESS WIRE)--January 21, 2014--ADTRAN, Inc.
      (NASDAQ:ADTN) reported results for the fourth quarter 2013. For the
      quarter, sales were $159,094,000 compared to $139,756,000 for the fourth
      quarter of 2012. Operating income was $10,639,000 compared to $2,874,000
      for the fourth quarter of 2012. Net Income was $11,840,000 compared to
      $3,961,000 for the fourth quarter of 2012. Earnings per share, assuming
      dilution, were $0.20 compared to $0.06 for the fourth quarter of 2012.
      Non-GAAP earnings per share were $0.25 compared to $0.11 for the fourth
      quarter of 2012. The reconciliation between GAAP earnings per share,
      diluted, and non-GAAP earnings per share, diluted, is in the table
      provided.

[0001157523-14-000154:8k_2_02:5]
ADTRAN Chief Executive Officer Tom Stanton stated, “We had a solid
      quarter with revenue coming in at 14% over the same period last year.
      Growth was driven by our core product areas, Broadband Access,
      Internetworking and Optical, which were up 25%. Strong performances in
      EMEA and Latin America helped drive our international revenue up 78%.
      Our strategy towards geographic diversification continued to pay
      benefits during the quarter and we believe we are well positioned for
      the future as our customers leverage technology advancements to improve
      their competitive position.”

[0001157523-14-000154:8k_2_02:6]
The Company also announced that its Board of Directors declared a cash
      dividend for the fourth quarter of 2013. The quarterly cash dividend is
      $0.09 per common share to be paid to holders of record at the close of
      business on February 6, 2014. The ex-dividend date is February 4, 2014
      and the payment date is February 20, 2014.

[0001157523-14-000154:8k_2_02:7]
The Company confirmed that its fourth quarter conference call will be
      held Wednesday, January 22, 2014 at 9:30 a.m. Central Time. This
      conference call will be web cast live through StreetEvents.com. To
      listen, simply visit the Investor Relations site at www.adtran.com
      or www.streetevents.com approximately 10 minutes prior to the
      start of the call and click on the conference call link provided.

[0001157523-14-000154:8k_2_02:8]
An online replay of the conference call will be available for seven days
      at www.streetevents.com. In addition, an online replay of the
      conference call, as well as the text of the Company’s earnings release,
      will be available on the Investor Relations site at www.adtran.com
      for at least 12 months following the call.

[0001157523-14-000154:8k_2_02:9]
ADTRAN, Inc. is a leading global provider of networking and
      communications equipment. ADTRAN’s products enable voice, data, video
      and Internet communications across a variety of network infrastructures.
      ADTRAN solutions are currently in use by service providers, private
      enterprises, government organizations, and millions of individual users
      worldwide. For more information, please visit www.adtran.com.

[0001157523-14-000154:8k_2_02:10]
For more information, contact the company at 800 9ADTRAN (800 923-8726)
      or via email at info@adtran.com. On the Web, visit www.adtran.com.

[0001157523-14-000154:8k_2_02:11]
This press release contains forward-looking statements which reflect
      management’s best judgment based on factors currently known. However,
      these statements involve risks and uncertainties, including the
      successful development and market acceptance of new products, the degree
      of competition in the market for such products, the product and channel
      mix, component costs, manufacturing efficiencies, and other risks
      detailed in our annual report on Form 10-K for the year ended December
      31, 2012 and on Form 10-Q for the quarter ended September 30, 2013.
      These risks and uncertainties could cause actual results to differ
      materially from those in the forward-looking statements included in this
      press release.

[0001157523-14-000154:8k_2_02:12]
| Condensed Consolidated Balance Sheet(Unaudited)(In thousands) |
|  |  | December 31, 2013 |  | December 31,2012 |
| Assets |  |  |  |  |
| Cash and cash equivalents |  | $ | 58,298 |  | $ | 68,457 |
| Short-term investments |  |  | 105,760 |  |  | 160,481 |
| Accounts receivable, net |  |  | 85,814 |  |  | 81,194 |
| Other receivables |  |  | 18,249 |  |  | 16,253 |
| Inventory |  |  | 90,111 |  |  | 102,583 |
| Prepaid expenses |  |  | 4,325 |  |  | 4,148 |
| Deferred tax assets, net |  |  | 17,083 |  |  | 13,055 |
| Total Current Assets |  |  | 379,640 |  |  | 446,171 |
| Property, plant and equipment, net |  |  | 76,739 |  |  | 80,246 |
| Deferred tax assets, net |  |  | 9,622 |  |  | 10,261 |
| Goodwill |  |  | 3,492 |  |  | 3,492 |
| Other assets |  |  | 11,180 |  |  | 13,482 |
| Long-term investments |  |  | 309,225 |  |  | 332,729 |
| Total Assets |  | $ | 789,898 |  | $ | 886,381 |
| Liabilities and Stockholders' Equity |  |  |  |  |
| Accounts payable |  | $ | 48,282 |  | $ | 42,173 |
| Unearned revenue |  |  | 22,205 |  |  | 38,051 |
| Accrued expenses |  |  | 12,776 |  |  | 10,309 |
| Accrued wages and benefits |  |  | 14,040 |  |  | 15,022 |
| Income tax payable, net |  |  | 5,002 |  |  | 1,211 |
| Total Current Liabilities |  |  | 102,305 |  |  | 106,766 |
| Non-current unearned revenue |  |  | 14,643 |  |  | 23,803 |
| Other non-current liabilities |  |  | 22,144 |  |  | 17,406 |
| Bonds payable |  |  | 46,200 |  |  | 46,000 |
| Total Liabilities |  |  | 185,292 |  |  | 193,975 |
| Stockholders' Equity |  |  | 604,606 |  |  | 692,406 |
| Total Liabilities and Stockholders' Equity |  | $ | 789,898 |  | $ | 886,381 |

[0001157523-14-000154:8k_2_02:13]
| Consolidated Statements of Income(Unaudited)(In thousands, except per share data) |
|  |  |  | Three Months Ended |  | Twelve Months Ended |
|  |  |  | December 31, |  | December 31, |
|  |  |  | 2013 |  | 2012 |  | 2013 |  | 2012 |
| Sales |  | $ | 159,094 |  |  | $ | 139,756 |  |  | $ | 641,744 |  |  | $ | 620,614 |  |
| Cost of sales |  |  | 82,230 |  |  |  | 72,373 |  |  |  | 332,858 |  |  |  | 303,971 |  |
| Gross Profit |  |  | 76,864 |  |  |  | 67,383 |  |  |  | 308,886 |  |  |  | 316,643 |  |
| Selling, general and administrative expenses |  |  | 33,284 |  |  |  | 31,393 |  |  |  | 129,366 |  |  |  | 134,523 |  |
| Research and development expenses |  |  | 32,941 |  |  |  | 33,116 |  |  |  | 131,055 |  |  |  | 125,951 |  |
| Operating Income |  |  | 10,639 |  |  |  | 2,874 |  |  |  | 48,465 |  |  |  | 56,169 |  |
| Interest and dividend income |  |  | 1,991 |  |  |  | 2,006 |  |  |  | 7,012 |  |  |  | 7,657 |  |
| Interest expense |  |  | (588 | ) |  |  | (591 | ) |  |  | (2,325 | ) |  |  | (2,347 | ) |
| Net realized investment gain |  |  | 1,665 |  |  |  | 2,197 |  |  |  | 8,614 |  |  |  | 9,550 |  |
| Other income (expense), net |  |  | 610 |  |  |  | (82 | ) |  |  | (911 | ) |  |  | 183 |  |
| Gain on bargain purchase of a business |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 1,753 |  |
| Income before provision for income taxes |  |  | 14,317 |  |  |  | 6,404 |  |  |  | 60,855 |  |  |  | 72,965 |  |
| Provision for income taxes |  |  | (2,477 | ) |  |  | (2,443 | ) |  |  | (15,061 | ) |  |  | (25,702 | ) |
| Net Income |  | $ | 11,840 |  |  | $ | 3,961 |  |  | $ | 45,794 |  |  | $ | 47,263 |  |
| Weighted average shares outstanding - basic |  |  | 57,178 |  |  |  | 62,542 |  |  |  | 59,001 |  |  |  | 63,259 |  |
| Weighted average shares outstanding - diluted (1) |  |  | 57,777 |  |  |  | 62,690 |  |  |  | 59,424 |  |  |  | 63,774 |  |
| Earnings per common share - basic |  | $ | 0.21 |  |  | $ | 0.06 |  |  | $ | 0.78 |  |  | $ | 0.75 |  |
| Earnings per common share - diluted (1) |  | $ | 0.20 |  |  | $ | 0.06 |  |  | $ | 0.77 |  |  | $ | 0.74 |  |
| (1) Assumes exercise of dilutive stock options calculated under the treasury stock method. |

[0001157523-14-000154:8k_2_02:14]
| Consolidated Statements of Comprehensive Income(Unaudited)(In thousands) |
|  |  | Three Months Ended |  | Twelve Months Ended |
|  |  | December 31, |  | December 31, |
|  |  | 2013 |  | 2012 |  | 2013 |  | 2012 |
| Net Income |  | $ | 11,840 |  |  | $ | 3,961 |  |  | $ | 45,794 |  |  | $ | 47,263 |  |
| Other Comprehensive Income (Loss), net of tax: |  |  |  |  |  |  |  |  |
| Unrealized gains (losses) on available-for-sale securities |  |  | 1,409 |  |  |  | (2,071 | ) |  |  | 629 |  |  |  | (52 | ) |
| Defined benefit plan adjustments |  |  | 1,061 |  |  |  | (1,952 | ) |  |  | 1,061 |  |  |  | (1,952 | ) |
| Foreign currency translation |  |  | (707 | ) |  |  | (21 | ) |  |  | (2,205 | ) |  |  | 170 |  |
| Other Comprehensive Income (Loss), net of tax |  |  | 1,763 |  |  |  | (4,044 | ) |  |  | (515 | ) |  |  | (1,834 | ) |
| Comprehensive Income (Loss), net of tax |  | $ | 13,603 |  |  | $ | (83 | ) |  | $ | 45,279 |  |  | $ | 45,429 |  |

[0001157523-14-000154:8k_2_02:15]
| Consolidated Statements of Cash Flows(Unaudited)(In thousands) |
|  |  | Twelve Months Ended |
|  |  | December 31, |
|  |  | 2013 |  | 2012 |
| Cash flows from operating activities: |  |  |  |  |
| Net income |  | $ | 45,794 |  |  | $ | 47,263 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Depreciation and amortization |  |  | 14,628 |  |  |  | 14,079 |  |
| Amortization of net premium on available-for-sale investments |  |  | 5,956 |  |  |  | 8,257 |  |
| Net realized gain on long-term investments |  |  | (8,614 | ) |  |  | (9,550 | ) |
| Net (gain) loss on disposal of property, plant and equipment |  |  | 3 |  |  |  | (214 | ) |
| Gain on bargain purchase of a business |  |  | - |  |  |  | (1,753 | ) |
| Stock-based compensation expense |  |  | 9,073 |  |  |  | 9,264 |  |
| Deferred income taxes |  |  | (4,058 | ) |  |  | (3,785 | ) |
| Tax benefit from stock option exercises |  |  | 169 |  |  |  | 1,905 |  |
| Excess tax benefits from stock-based compensation arrangements |  |  | (158 | ) |  |  | (1,456 | ) |
| Change in operating assets and liabilities: |  |  |  |  |
| Accounts receivable, net |  |  | (4,022 | ) |  |  | (4,365 | ) |
| Other receivables |  |  | (1,549 | ) |  |  | 2,977 |  |
| Inventory |  |  | 11,479 |  |  |  | 7,163 |  |
| Prepaid expenses and other assets |  |  | (11 | ) |  |  | (1,045 | ) |
| Accounts payable |  |  | 5,543 |  |  |  | 7,265 |  |
| Accrued expenses and other liabilities |  |  | (17,879 | ) |  |  | 11,583 |  |
| Income tax payable, net |  |  | 3,747 |  |  |  | (1,960 | ) |
| Net cash provided by operating activities |  |  | 60,101 |  |  |  | 85,628 |  |
| Cash flows from investing activities: |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (8,510 | ) |  |  | (12,075 | ) |
| Proceeds from disposals of property, plant and equipment |  |  | - |  |  |  | 266 |  |
| Proceeds from sales and maturities of available-for-sale investments |  |  | 343,567 |  |  |  | 282,039 |  |
| Purchases of available-for-sale investments |  |  | (261,625 | ) |  |  | (282,740 | ) |
| Acquisition of business |  |  | - |  |  |  | 7,496 |  |
| Net cash provided by (used in) investing activities |  |  | 73,432 |  |  |  | (5,014 | ) |
| Cash flows from financing activities: |  |  |  |  |
| Proceeds from stock option exercises |  |  | 3,629 |  |  |  | 6,049 |  |
| Purchases of treasury stock |  |  | (124,267 | ) |  |  | (39,362 | ) |
| Dividend payments |  |  | (21,412 | ) |  |  | (22,813 | ) |
| Payments on long-term debt |  |  | - |  |  |  | (500 | ) |
| Excess tax benefits from stock-based compensation arrangements |  |  | 158 |  |  |  | 1,456 |  |
| Net cash used in financing activities |  |  | (141,892 | ) |  |  | (55,170 | ) |
| Net increase (decrease) in cash and cash equivalents |  |  | (8,359 | ) |  |  | 25,444 |  |
| Effect of exchange rate changes |  |  | (1,800 | ) |  |  | 34 |  |
| Cash and cash equivalents, beginning of period |  |  | 68,457 |  |  |  | 42,979 |  |
| Cash and cash equivalents, end of period |  | $ | 58,298 |  |  | $ | 68,457 |  |

[0001157523-14-000154:8k_2_02:16]
| Supplemental InformationAcquisition Related Expenses, Amortizations and Adjustments(Unaudited)(In thousands) |
| On August 4, 2011, we closed on the acquisition of Bluesocket, Inc. and on May 4, 2012, we closed on the acquisition of the Nokia Siemens Networks Broadband Access business (NSN BBA). Acquisition related expenses, amortizations and adjustments for the three and twelve months ended December 31, 2013 and 2012 for both transactions are as follows: |
|  |  | Three Months Ended |  | Twelve Months Ended |
|  |  | December 31, |  | December 31, |
|  |  | 2013 |  | 2012 |  | 2013 |  | 2012 |
| Bluesocket, Inc. acquisition |  |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets and other purchase accounting adjustments |  | $ | 279 |  |  | $ | 296 |  |  | $ | 1,142 |  |  | $ | 1,463 |  |
| NSN BBA acquisition |  |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets |  |  | 301 |  |  |  | 290 |  |  |  | 1,174 |  |  |  | 762 |  |
| Amortization of other purchase accounting adjustments |  |  | 391 |  |  |  | 587 |  |  |  | 1,378 |  |  |  | 2,305 |  |
| Acquisition related professional fees, travel and other expenses |  |  | 16 |  |  |  | 323 |  |  |  | 345 |  |  |  | 4,860 |  |
| Subtotal |  |  | 708 |  |  |  | 1,200 |  |  |  | 2,897 |  |  |  | 7,927 |  |
| Total acquisition related expenses, amortizations and adjustments |  |  | 987 |  |  |  | 1,496 |  |  |  | 4,039 |  |  |  | 9,390 |  |
| Provision for income taxes |  |  | (328 | ) |  |  | (488 | ) |  |  | (1,343 | ) |  |  | (3,148 | ) |
| Total acquisition related expenses, amortizations and adjustments, net of tax |  | $ | 659 |  |  | $ | 1,008 |  |  | $ | 2,696 |  |  | $ | 6,242 |  |
| The acquisition related expenses, amortizations and adjustments above were recorded in the following Consolidated Statements of Income categories for the three and twelve months ended December 31, 2013 and 2012: |
|  |  | Three Months Ended |  | Twelve Months Ended |
|  |  | December 31, |  | December 31, |
|  |  | 2013 |  | 2012 |  | 2013 |  | 2012 |
| Revenue (adjustments to deferred revenue recognized in the period) |  | $ | 211 |  |  | $ | 377 |  |  | $ | 929 |  |  | $ | 1,528 |  |
| Cost of goods sold |  |  | 102 |  |  |  | 154 |  |  |  | 196 |  |  |  | 1,086 |  |
| Subtotal |  |  | 313 |  |  |  | 531 |  |  |  | 1,125 |  |  |  | 2,614 |  |
| Selling, general and administrative expenses |  |  | 24 |  |  |  | 330 |  |  |  | 399 |  |  |  | 4,510 |  |
| Research and development expenses |  |  | 650 |  |  |  | 635 |  |  |  | 2,515 |  |  |  | 2,266 |  |
| Subtotal |  |  | 674 |  |  |  | 965 |  |  |  | 2,914 |  |  |  | 6,776 |  |
| Total acquisition related expenses, amortizations and adjustments |  |  | 987 |  |  |  | 1,496 |  |  |  | 4,039 |  |  |  | 9,390 |  |
| Provision for income taxes |  |  | (328 | ) |  |  | (488 | ) |  |  | (1,343 | ) |  |  | (3,148 | ) |
| Total acquisition related expenses, amortizations and adjustments, net of tax |  | $ | 659 |  |  | $ | 1,008 |  |  | $ | 2,696 |  |  | $ | 6,242 |  |

[0001157523-14-000154:8k_2_02:17]
| Supplemental InformationStock-based Compensation Expense(Unaudited)(In thousands) |
|  |  | Three Months Ended |  | Twelve Months Ended |
|  |  | December 31, |  | December 31, |
|  |  | 2013 |  | 2012 |  | 2013 |  | 2012 |
| Stock-based compensation expense included in cost of sales |  | $ | 131 |  |  | $ | 118 |  |  | $ | 465 |  |  | $ | 422 |  |
| Selling, general and administrative expense |  |  | 1,314 |  |  |  | 1,146 |  |  |  | 4,443 |  |  |  | 4,351 |  |
| Research and development expense |  |  | 1,112 |  |  |  | 1,217 |  |  |  | 4,165 |  |  |  | 4,491 |  |
| Stock-based compensation expense included in operating expenses |  |  | 2,426 |  |  |  | 2,363 |  |  |  | 8,608 |  |  |  | 8,842 |  |
| Total stock-based compensation expense |  |  | 2,557 |  |  |  | 2,481 |  |  |  | 9,073 |  |  |  | 9,264 |  |
| Tax benefit for expense associated with non-qualified options |  |  | (374 | ) |  |  | (318 | ) |  |  | (1,298 | ) |  |  | (1,234 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 2,183 |  |  | $ | 2,163 |  |  | $ | 7,775 |  |  | $ | 8,030 |  |

[0001157523-14-000154:8k_2_02:18]
| Reconciliation of GAAP net income per share, diluted, toNon-GAAP net income per share, diluted(Unaudited) |
|  |  | Three Months Ended |  | Twelve Months Ended |
|  |  | December 31, |  | December 31, |
|  |  | 2013 |  | 2012 |  | 2013 |  | 2012 |
| GAAP earnings per common share – diluted |  | $ | 0.20 |  | $ | 0.06 |  | $ | 0.77 |  | $ | 0.74 |  |
| Acquisition related expenses, amortizations and adjustments |  |  | 0.01 |  |  | 0.02 |  |  | 0.05 |  |  | 0.10 |  |
| Stock-based compensation expense |  |  | 0.04 |  |  | 0.03 |  |  | 0.13 |  |  | 0.13 |  |
| Gain on bargain purchase of business |  | - |  |  | - |  | - |  |  | (0.03 | ) |
| Non-GAAP earnings per common share – diluted |  | $ | 0.25 |  | $ | 0.11 |  | $ | 0.95 |  | $ | 0.94 |  |

[0001157523-14-000154:8k_2_02:19]
CONTACT:
ADTRAN, Inc.
Jim Matthews, 256-963-8775
Senior Vice
      President/CFO
or
Investor Services/Assistance:
Gayle Ellis,
      256-963-8220
