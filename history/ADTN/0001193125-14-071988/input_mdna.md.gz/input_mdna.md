# ADTN MD&A — 0001193125-14-071988


## mdna

[0001193125-14-071988:mdna:1]
| ITEM 7. | MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS |

[0001193125-14-071988:mdna:2]
Overview

[0001193125-14-071988:mdna:3]
ADTRAN, Inc. is a leading
global provider of networking and communications equipment. Our solutions enable voice, data, video and Internet communications across a variety of network infrastructures. These solutions are deployed by some of the world’s largest service
providers, distributed enterprises and small and medium-sized businesses, public and private enterprises, and millions of individual users worldwide.

[0001193125-14-071988:mdna:4]
Our success depends upon our ability to increase unit volume and market share through the introduction of new products and succeeding generations of products having lower selling prices and increased
functionality as compared to both the prior generation of a product and to the products of competitors. An important part of our strategy is to reduce the cost of each succeeding product generation and then lower the product’s selling price
based on the cost savings achieved in order to gain market share and/or improve gross margins. As a part of this strategy, we seek in most instances to be a high-quality, low-cost provider of products in our markets. Our success to date is
attributable in large measure to our ability to design our products initially with a view to their subsequent redesign, allowing both increased functionality and reduced manufacturing costs in each succeeding product generation. This strategy
enables us to sell succeeding generations of products to existing customers, while increasing our market share by selling these enhanced products to new customers.

[0001193125-14-071988:mdna:5]
Carrier Systems products are used by communications service providers to provide data, voice and video services to consumers and enterprises. This category includes the following product areas and
related services:

[0001193125-14-071988:mdna:6]
|  | • |  | Broadband Access |

[0001193125-14-071988:mdna:7]
|  | • |  | Total Access® 5000 Multi-Service Access Node (MSAN) |

[0001193125-14-071988:mdna:8]
|  | • |  | hiX family of MSANs |

[0001193125-14-071988:mdna:9]
|  | • |  | Total Access 1100/1200 Series of Fiber to the Node (FTTN) products |

[0001193125-14-071988:mdna:10]
|  | • |  | Ultra Broadband Ethernet (UBE) |

[0001193125-14-071988:mdna:11]
|  | • |  | Digital Subscriber Line Access Multiplexer (DSLAM) products |

[0001193125-14-071988:mdna:12]
|  | • |  | Optical |

[0001193125-14-071988:mdna:13]
|  | • |  | Optical Networking Edge (ONE) |

[0001193125-14-071988:mdna:14]
|  | • |  | NetVanta 8000 Series of Fiber Ethernet Access Devices (EAD) |

[0001193125-14-071988:mdna:15]
|  | • |  | OPTI-6100 and Total Access 3000 optical Multi-Service Provisioning Platforms (MSPP) |

[0001193125-14-071988:mdna:16]
|  | • |  | Pluggable Optical Products, including SFP, XFP, and SFP+ |

[0001193125-14-071988:mdna:17]
|  | • |  | TDM systems |

[0001193125-14-071988:mdna:18]
Business
Networking products provide access to communication services and facilitate the delivery of cloud connectivity and enterprise communications to the small and mid-sized enterprise (SME) market. This category includes the following product areas
and related services:

[0001193125-14-071988:mdna:19]
|  | • |  | Internetworking products |

[0001193125-14-071988:mdna:20]
|  | • |  | Total Access IP Business Gateways |

[0001193125-14-071988:mdna:21]
|  | • |  | Optical Network Terminals (ONTs) |

[0001193125-14-071988:mdna:22]
|  | • |  | Bluesocket® virtual Wireless LAN (vWLAN®) |

[0001193125-14-071988:mdna:23]
|  | • |  | NetVanta® |

[0001193125-14-071988:mdna:24]
|  | • |  | Multiservice Routers |

[0001193125-14-071988:mdna:25]
|  | • |  | Managed Ethernet Switches |

[0001193125-14-071988:mdna:26]
|  | • |  | IP Business Gateways |

[0001193125-14-071988:mdna:27]
|  | • |  | Unified Communications (UC) solutions |

[0001193125-14-071988:mdna:28]
|  | • |  | Carrier Ethernet Network Terminating Equipment (NTE) |

[0001193125-14-071988:mdna:29]
|  | • |  | Network Management Solutions |

[0001193125-14-071988:mdna:30]
|  | • |  | Integrated Access Devices (IADs) |

[0001193125-14-071988:mdna:31]
Loop Access products are used by carrier and enterprise customers for access to copper-based
communications networks. The Loop Access category includes the following product areas and related services:

[0001193125-14-071988:mdna:32]
|  | • |  | High bit-rate Digital Subscriber Line (HDSL) products |

[0001193125-14-071988:mdna:33]
|  | • |  | Digital Data Service (DDS) |

[0001193125-14-071988:mdna:34]
|  | • |  | Integrated Services Digital Network (ISDN) products |

[0001193125-14-071988:mdna:35]
|  | • |  | T1/E1/T3 Channel Service Units/Data Service Units (CSUs/DSUs) |

[0001193125-14-071988:mdna:36]
|  | • |  | TRACER fixed-wireless products |

[0001193125-14-071988:mdna:37]
In addition, we identify subcategories of product revenues, which we divide into core products and legacy products. Our core products consist of Broadband Access and Optical products (included in Carrier
Systems) and Internetworking products (included in Business Networking). Our legacy products include HDSL products (included in Loop Access) and other products not included in the aforementioned core products. Many of our customers are migrating
their networks to deliver higher bandwidth services by utilizing newer technologies. We believe that products and services offered in our core product areas position us well for this migration. Despite occasional increases, we anticipate that
revenues of many of our legacy products, including HDSL, will decline over time; however, revenues from these products may continue for years because of the time required for our customers to transition to newer technologies.

[0001193125-14-071988:mdna:38]
Sales were $641.7 million in 2013 compared to $620.6 million in 2012 and $717.2 million in 2011. Total sales of products in our three core areas,
Broadband Access, Optical and Internetworking, increased 8.9% in 2013 compared to 2012 and decreased 1.7% in 2012 compared to 2011. Our gross profit margin decreased in 2013 to 48.1% from 51.0% in 2012 and 57.8% in 2011. Net income was $45.8 million
in 2013 compared to $47.3 million in 2012 and $138.6 million in 2011. Earnings per share, assuming dilution, were $0.77 in 2013 compared to $0.74 in 2012 and $2.12 in 2011. Earnings per share in 2013, 2012 and 2011 include the effect of the
repurchase of 5.6 million, 1.8 million and 1.1 million shares of our stock in those years, respectively.

[0001193125-14-071988:mdna:39]
Our operating results
have fluctuated on a quarterly basis in the past, and may vary significantly in future periods due to a number of factors, including customer order activity and backlog. Backlog levels vary because of seasonal trends, the timing of customer projects
and other factors that affect customer order lead times. Many of our customers require prompt delivery of products. This requires us to maintain sufficient inventory levels to satisfy anticipated customer demand. If near-term demand for our products
declines, or if potential sales in any quarter do not occur as anticipated, our financial results could be adversely affected. Operating expenses are relatively fixed in the short term; therefore, a shortfall in quarterly revenues could
significantly impact our financial results in a given quarter.

[0001193125-14-071988:mdna:40]
Our operating results may also fluctuate as a result of a number of other
factors, including a decline in general economic and market conditions, increased competition, customer order patterns, changes in product and services mix, timing differences between price decreases and product cost reductions, product warranty
returns, expediting costs and announcements of new products by us or our competitors. Additionally, maintaining sufficient inventory levels to assure prompt delivery of our products increases the amount of inventory that may become obsolete and
increases the risk that the obsolescence of this inventory may have an adverse effect on our business and operating results. Also, not maintaining sufficient inventory levels to assure prompt delivery of our products may cause us to incur expediting
costs to meet customer delivery requirements, which may negatively impact our operating results in a given quarter.

[0001193125-14-071988:mdna:41]
Accordingly, our
historical financial performance is not necessarily a meaningful indicator of future results, and, in general, management expects that our financial results may vary from period to period. See Note 15 of Notes to Consolidated Financial Statements
for additional information. For a discussion of risks associated with our operating results, see Item 1A of this report.

[0001193125-14-071988:mdna:42]
Critical Accounting Policies and Estimates

[0001193125-14-071988:mdna:43]
An accounting policy is deemed to be critical if it requires an accounting estimate to be made based on assumptions about matters that are highly uncertain at the time the estimate is made, if different
estimates reasonably could have been used, or if changes in the accounting estimate that are reasonably likely to occur could materially impact the results of financial operations. We believe the following critical accounting policies affect our
more significant judgments and estimates used in the preparation of our consolidated financial statements. These policies have been consistently applied across our two reportable segments: (1) Carrier Networks Division and (2) Enterprise
Networks Division.

[0001193125-14-071988:mdna:44]
|  | • |  | Revenue is generally recognized when persuasive evidence of an arrangement exists, delivery has occurred, the product price is fixed or determinable, collection of the resulting receivable is reasonably assured, and product returns are reasonably estimable. For product sales, revenue is generally recognized upon shipment of the product to our customer in accordance with the title transfer terms of the sales agreement, generally FOB shipping point. In the case of consigned inventory, revenue is recognized when the end customer assumes ownership of the product. Contracts that contain multiple deliverables are evaluated to determine the units of accounting, and the consideration from the arrangement is allocated to each unit of accounting based on the relative selling price and corresponding terms of the contract. We use vendor-specific objective evidence of selling price. When this evidence is not available, we are generally not able to determine third-party evidence of selling price because of the extent of customization among competing products or services from other companies. We record revenue associated with installation services when all contractual obligations are complete. In instances where customer acceptance is required, revenue is deferred until all acceptance criteria have been met. Contracts that include both installation services and product sales are evaluated for revenue recognition in accordance with contract terms. As a result, depending on contract terms, installation services may be considered a separate deliverable or may be considered a combined single unit of accounting with the delivered product. Generally, either the purchaser, ADTRAN, or a third party can perform the installation of our products. Shipping fees are recorded as revenue and the related cost is included in cost of sales. Revenue is recorded net of discounts. |

[0001193125-14-071988:mdna:45]
|  | • |  | A significant portion of Enterprise Networks products are sold in the United States through a non-exclusive distribution network of major technology distributors. These organizations then distribute or provide fulfillment services to an extensive network of value-added resellers and system integrators. Value-added resellers and system integrators may be affiliated with us as a channel partner, or they may purchase from the distributor on an unaffiliated basis. Additionally, with certain limitations, our distributors may return unused and unopened product for stock-balancing purposes when these returns are accompanied by offsetting orders for products of equal or greater value. |

[0001193125-14-071988:mdna:46]
|  | • |  | We carry our inventory at the lower of cost or market, with cost being determined using the first-in, first-out method. We use standard costs for material, labor, and manufacturing overhead to value our inventory. Our standard costs are updated on at least a quarterly basis and any variances are expensed in the current period; therefore, our inventory costs approximate actual costs at the end of each reporting period. We write down our inventory for estimated obsolescence or unmarketable inventory by an amount equal to the difference between the cost of inventory and the estimated fair value based upon assumptions about future demand and market conditions. If actual future demand or market conditions are less favorable than those projected by management, we may be required to make additional inventory write-downs. Our reserve for excess and obsolete inventory was $23.0 million and $12.0 million at December 31, 2013 and 2012, respectively. Inventory write-downs charged to the reserve were $0.4 million, $0.5 million and $0.7 million for the years ended December 31, 2013, 2012 and 2011, respectively. |

[0001193125-14-071988:mdna:47]
|  | • |  | The objective of our short-term investment policy is to preserve principal and maintain adequate liquidity with appropriate diversification, while achieving market returns. The objective of our long-term investment policy is principal preservation and total return; that is, the aggregate return from capital appreciation, dividend income, and interest income. These objectives are achieved through investments with appropriate diversification in fixed and variable rate income securities, public equity, and private equity portfolios. Our investment policy provides limitations for issuer concentration, which limits, at the time of purchase, the concentration in any one issuer to 5% of the market value of our total investment portfolio. We have experienced significant volatility in the market prices of our publicly traded equity investments. These investments are recorded on the consolidated balance sheets at fair value with unrealized gains and losses reported as a component of accumulated other comprehensive income, net of tax. The ultimate realized value on these equity investments is subject to market price volatility. |

[0001193125-14-071988:mdna:48]
30

[0001193125-14-071988:mdna:49]
We have categorized our cash equivalents held in money market funds and our investments held
at fair value into a three-level fair value hierarchy based on the priority of the inputs to the valuation technique for the cash equivalents and investments as follows: Level 1 – Values based on unadjusted, quoted prices in active markets for
identical assets or liabilities; Level 2 – Values based on inputs other than quoted prices included within Level 1 that are directly or indirectly observable for the asset or liability; Level 3 – Values based on unobservable inputs for the
asset or liability. These inputs include information supplied by investees. At December 31, 2013, we categorized $53.6 million and $311.5 million of our available-for-sale investments as Level 1 and Level 2, respectively, and $3.9 million of
our cash equivalents as Level 1. At December 31, 2012, we categorized $47.2 million and $395.9 million of our available-for-sale investments as Level 1 and Level 2, respectively, and $28.1 million of our cash equivalents as Level 1.

[0001193125-14-071988:mdna:50]
We review our investment portfolio for potential “other-than-temporary” declines in value on an individual investment basis. We
assess, on a quarterly basis, significant declines in value which may be considered other-than-temporary and, if necessary, recognize and record the appropriate charge to write-down the carrying value of such investments. In making this assessment,
we take into consideration qualitative and quantitative information, including but not limited to the following: the magnitude and duration of historical declines in market prices, credit rating activity, assessments of liquidity, public filings,
and statements made by the issuer. We generally begin our identification of potential other-than-temporary impairments by reviewing any security with a fair value that has declined from its original or adjusted cost basis by 25% or more for six or
more consecutive months. We then evaluate the individual security based on the previously identified factors to determine the amount of the write-down, if any. As a result of our review, we recorded an other-than-temporary impairment charge of $11
thousand during the fourth quarter of 2013. For the years ended December 31, 2013, 2012 and 2011, we recorded charges of $25 thousand, $0.7 million and $68 thousand, respectively, related to the other-than-temporary impairment of certain
publicly traded equity securities and our deferred compensation plan assets. Actual losses, if any, could ultimately differ from these estimates. Future adverse changes in market conditions or poor operating results of underlying investments could
result in additional losses that may not be reflected in an investment’s current carrying value, thereby possibly requiring an impairment charge in the future. See Note 4 of Notes to the Consolidated Financial Statements in this report for more
information about our investments.

[0001193125-14-071988:mdna:51]
We also invest in privately held entities and private equity funds and record these
investments at cost. We review these investments periodically in order to determine if circumstances (both financial and non-financial) exist that indicate that we will not recover our initial investment. Impairment charges are recorded on
investments having a cost basis that is greater than the value that we would reasonably expect to receive in an arm’s length sale of the investment. We have not been required to record any impairment losses relating to these investments in
2013, 2012 or 2011.

[0001193125-14-071988:mdna:52]
|  | • |  | For purposes of determining the estimated fair value of our stock option awards on the date of grant, we use the Black-Scholes Model. This model requires the input of certain assumptions that require subjective judgment. These assumptions include, but are not limited to, expected stock price volatility over the term of the awards and actual and projected employee stock option exercise behaviors. Because our stock option awards have characteristics significantly different from those of traded options, and because changes in the input assumptions can materially affect the fair value estimate, the existing model may not provide a reliable single measure of the fair value of our stock option awards. For purposes of determining the estimated fair value of our performance-based restricted stock unit awards on the date of grant, we use a Monte Carlo Simulation valuation method. The restricted stock units are subject to a market condition based on the relative total shareholder return of ADTRAN against all of the companies in the NASDAQ Telecommunications Index and vest at the end of a three-year performance period. The fair value of restricted stock issued to our Directors is equal to the closing price of our stock on the date of grant. Management will continue to assess the assumptions and methodologies used to calculate the estimated fair value of stock-based compensation. Circumstances may change and additional data may become available over time, which could result in changes to these assumptions and methodologies and thereby materially impact our fair value determination. If factors change in future periods, the compensation expense that we record may differ significantly from what we have recorded in the current period. |

[0001193125-14-071988:mdna:53]
|  | • |  | We estimate our income tax provision or benefit in each of the jurisdictions in which we operate, including estimating exposures related to examinations by taxing authorities. We also make judgments regarding the realization of deferred tax assets, and establish valuation allowances where we believe it is more likely than not that future taxable income in certain jurisdictions will be insufficient to realize these deferred tax assets. Our estimates regarding future taxable income and income tax provision or benefit may vary due to changes in market conditions, changes in tax laws, or other factors. If our assumptions, and consequently our estimates, change in the future, the valuation allowances we have established may be increased or decreased, impacting future income tax expense. At December 31, 2013 and 2012 respectively, the valuation allowance was $8.8 million and $10.9 million. As of December 31, 2013, we have state research tax credit carry-forwards of $3.6 million, which will expire between 2015 and 2028. These carry-forwards were caused by tax credits in excess of our annual tax liabilities to an individual state where we no longer generate sufficient state income. In addition, as of December 31, 2013, we have a deferred tax asset of $11.9 million relating to net operating loss carry-forwards which will expire between 2014 and 2030. These carry-forwards are the result of acquisitions in 2009 and in 2011, plus losses generated in 2012 by a foreign entity. The acquired net operating losses are in excess of the amount of estimated earnings. We believe it is more likely than not that we will not realize the full benefits of our deferred tax asset arising from these credits and net operating losses, and accordingly, have provided a full valuation allowance against them. This valuation allowance is included in non-current deferred tax liabilities in the accompanying balance sheets. |

[0001193125-14-071988:mdna:54]
We establish reserves to remove
some or all of the tax benefit of any of our tax positions at the time we determine that the positions become uncertain. We adjust these reserves, including any impact on the related interest and penalties, as facts and circumstances change.

[0001193125-14-071988:mdna:55]
|  | • |  | Our products generally include warranties of 90 days to ten years for product defects. We accrue for warranty returns at the time revenue is recognized based on our estimate of the cost to repair or replace the defective products. We engage in extensive product quality programs and processes, including actively monitoring and evaluating the quality of our component suppliers. Our products continue to become more complex in both size and functionality as many of our product offerings migrate from line card applications to systems products. The increasing complexity of our products will cause warranty incidences, when they arise, to be more costly. Our estimates regarding future warranty obligations may change due to product failure rates, material usage, and other rework costs incurred in correcting a product failure. In addition, from time to time, specific warranty accruals may be recorded if unforeseen problems arise. Should our actual experience relative to these factors be worse than our estimates, we will be required to record additional warranty expense. Alternatively, if we provide for more reserves than we require, we will reverse a portion of such provisions in future periods. The liability for warranty obligations totaled $9.0 million and $9.7 million at December 31, 2013 and 2012, respectively. These liabilities are included in accrued expenses in the accompanying Consolidated Balance Sheets. |

[0001193125-14-071988:mdna:56]
|  | • |  | Pension benefit plan obligations are based on various assumptions used by our actuaries in calculating these amounts. These assumptions include discount rates, compensation rate increases, expected return on plan assets, retirement rates, and mortality rates. Actual results that differ from the assumptions and changes in assumptions could affect future expenses and obligations. Our net pension liability totaled $2.6 million at December 31, 2013 and 2012. This liability is included in other non-current liabilities in the accompanying Consolidated Balance Sheets. |

[0001193125-14-071988:mdna:57]
|  | • |  | We use the acquisition method to account for business combinations. Under the acquisition method of accounting, we recognize the assets acquired and liabilities assumed at their fair value on the acquisition date. Goodwill is measured as the excess of the consideration transferred over the net assets acquired. The acquisition method of accounting requires us to exercise judgment and make significant estimates and assumptions regarding the fair value of the assets acquired and liabilities assumed, including the fair values of inventory, unearned revenue, warranty liabilities, identifiable intangible assets and deferred tax asset valuation allowances. This method also requires us to refine these estimates over a one-year measurement period to reflect information obtained about facts and circumstances that existed as of the acquisition date that, if known, would have affected the measurement of the asset and liabilities recorded on that date, which could affect our net income. |

[0001193125-14-071988:mdna:58]
|  | • |  | We evaluate the carrying value of goodwill during the fourth quarter of each year and between annual evaluations if events occur or circumstances change that would more likely than not reduce the fair value of the reporting unit below its carrying amount. When evaluating whether goodwill is impaired, we first assess qualitative factors to determine whether it is necessary to perform the two-step quantitative goodwill impairment test. If we determine that the two-step quantitative test is necessary, then we compare the fair value of the reporting unit to which the goodwill is assigned to the reporting unit’s carrying amount, including goodwill. If the carrying amount of the reporting unit exceeds its fair value, then the amount of the impairment loss is measured. We passed the qualitative assessment in 2013 and 2012; therefore, we did not complete a quantitative assessment. As a result, there were no impairment losses recognized during 2013 or 2012. |

[0001193125-14-071988:mdna:59]
32

[0001193125-14-071988:mdna:60]
Results of Operations

[0001193125-14-071988:mdna:61]
The following table presents selected financial information derived from our consolidated statements of income expressed as a percentage of sales for the years indicated.

[0001193125-14-071988:mdna:62]
| Year Ended December 31, |  | 2013 |  |  | 2012 |  |  | 2011 |  |
| Sales |  |  |  |  |  |  |  |  |  |  |  |  |
| Carrier Networks Division |  |  | 78.0 | % |  |  | 79.3 | % |  |  | 79.4 | % |
| Enterprise Networks Division |  |  | 22.0 |  |  |  | 20.7 |  |  |  | 20.6 |  |
| Total sales |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |
| Cost of sales |  |  | 51.9 |  |  |  | 49.0 |  |  |  | 42.2 |  |
| Gross profit |  |  | 48.1 |  |  |  | 51.0 |  |  |  | 57.8 |  |
| Selling, general and administrative expenses |  |  | 20.2 |  |  |  | 21.7 |  |  |  | 17.4 |  |
| Research and development expenses |  |  | 20.4 |  |  |  | 20.3 |  |  |  | 14.0 |  |
| Operating income |  |  | 7.6 |  |  |  | 9.1 |  |  |  | 26.4 |  |
| Interest and dividend income |  |  | 1.1 |  |  |  | 1.2 |  |  |  | 1.1 |  |
| Interest expense |  |  | (0.4 | ) |  |  | (0.4 | ) |  |  | (0.3 | ) |
| Net realized investment gain |  |  | 1.3 |  |  |  | 1.5 |  |  |  | 1.7 |  |
| Other income (expense), net |  |  | (0.1 | ) |  |  | — |  |  |  | (0.1 | ) |
| Gain on bargain purchase of a business |  |  | — |  |  |  | 0.3 |  |  |  | — |  |
| Income before provision for income taxes |  |  | 9.5 |  |  |  | 11.8 |  |  |  | 28.7 |  |
| Provision for income taxes |  |  | (2.3 | ) |  |  | (4.1 | ) |  |  | (9.4 | ) |
| Net income |  |  | 7.1 | % |  |  | 7.6 | % |  |  | 19.3 | % |

[0001193125-14-071988:mdna:63]
33

[0001193125-14-071988:mdna:64]
Acquisition Expenses

[0001193125-14-071988:mdna:65]
On August 4, 2011, we closed on the acquisition of Bluesocket, Inc. and on May 4, 2012, we closed on the acquisition of the NSN BBA business. Acquisition related expenses, amortizations and
adjustments for the years ended December 31, 2013, 2012 and 2011 for both transactions are as follows:

[0001193125-14-071988:mdna:66]
| (In Thousands) |  | 2013 |  |  | 2012 |  |  | 2011 |  |
| Bluesocket, Inc. acquisition |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets |  | $ | 1,069 |  |  | $ | 1,020 |  |  | $ | 495 |  |
| Amortization of other purchase accounting adjustments |  |  | 73 |  |  |  | 443 |  |  |  | 521 |  |
| Acquisition related professional fees, travel and other expenses |  |  | — |  |  |  | — |  |  |  | 730 |  |
| Subtotal |  |  | 1,142 |  |  |  | 1,463 |  |  |  | 1,746 |  |
| NSN BBA acquisition |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets |  |  | 1,174 |  |  |  | 762 |  |  |  | — |  |
| Amortization of other purchase accounting adjustments |  |  | 1,378 |  |  |  | 2,305 |  |  |  | — |  |
| Acquisition related professional fees, travel and other expenses |  |  | 345 |  |  |  | 4,860 |  |  |  | 2,027 |  |
| Subtotal |  |  | 2,897 |  |  |  | 7,927 |  |  |  | 2,027 |  |
| Total acquisition related expenses, amortizations and adjustments |  |  | 4,039 |  |  |  | 9,390 |  |  |  | 3,773 |  |
| Tax effect |  |  | (1,343 | ) |  |  | (3,148 | ) |  |  | (1,434 | ) |
| Total acquisition related expenses, amortizations and adjustments, net of tax |  | $ | 2,696 |  |  | $ | 6,242 |  |  | $ | 2,339 |  |

[0001193125-14-071988:mdna:67]
The acquisition related expenses, amortizations and adjustments above were recorded in the following Consolidated
Statements of Income categories for the years ended December 31, 2013, 2012 and 2011:

[0001193125-14-071988:mdna:68]
| (In Thousands) |  | 2013 |  |  | 2012 |  |  | 2011 |  |
| Revenue (adjustments to unearned revenue recognized in the period) |  | $ | 929 |  |  | $ | 1,528 |  |  | $ | 362 |  |
| Cost of goods sold |  |  | 196 |  |  |  | 1,086 |  |  |  | 165 |  |
| Subtotal |  |  | 1,125 |  |  |  | 2,614 |  |  |  | 527 |  |
| Selling, general and administrative expenses |  |  | 399 |  |  |  | 4,510 |  |  |  | 2,557 |  |
| Research and development expenses |  |  | 2,515 |  |  |  | 2,266 |  |  |  | 689 |  |
| Subtotal |  |  | 2,914 |  |  |  | 6,776 |  |  |  | 3,246 |  |
| Total acquisition related expenses, amortizations and adjustments |  |  | 4,039 |  |  |  | 9,390 |  |  |  | 3,773 |  |
| Tax effect |  |  | (1,343 | ) |  |  | (3,148 | ) |  |  | (1,434 | ) |
| Total acquisition related expenses, amortizations and adjustments, net of tax |  | $ | 2,696 |  |  | $ | 6,242 |  |  | $ | 2,339 |  |

[0001193125-14-071988:mdna:69]
2013 Compared to 2012

[0001193125-14-071988:mdna:70]
Sales

[0001193125-14-071988:mdna:71]
Our sales increased 3.4% from $620.6 million in 2012 to $641.7 million in 2013. The
increase in sales is primarily attributable to a $21.5 million increase in sales of our Internetworking products, a $20.5 million increase in sales of our Broadband Access products, a $3.9 million increase in sales of our Optical products, partially
offset by a $24.7 million decrease in sales of our HDSL and other legacy products.

[0001193125-14-071988:mdna:72]
Carrier Networks sales increased 1.8% from $492.1 million
in 2012 to $500.7 million in 2013. The increase in sales is primarily attributable to increases in sales of Broadband Access products, Internetworking products, and Optical products, partially offset by a decrease in sales of our HDSL products. The
increase in sales of our Broadband Access products is primarily attributable to initial VDSL2 vectoring technology shipments to Europe, partially offset by fluctuations in project installation activities at a Latin American carrier. The increase in
sales of our Internetworking products is primarily attributable to an improved spending environment and increases in EFM NTE sales and FTTP ONT sales to carriers. The increase in sales of our Optical products is primarily attributable to a
technology shift from Time Division Multiplexed (TDM) and SONET/SDH architectures to Ethernet-based packet networks. We offer Ethernet-based solutions within our Optical products that address this technology change, and we expect sales of our
Optical products will increase over time due to this transition. The decrease in sales of HDSL and other legacy products has been expected as customers continue to upgrade their networks to deliver higher bandwidth services by migrating to newer
technologies, including to our core products from our Broadband Access, Internetworking and Optical product lines. While we expect that revenues from HDSL and our other legacy products will continue to decline over time, these revenues may continue
for years because of the time required for our customers to transition to newer technologies.

[0001193125-14-071988:mdna:73]
Enterprise Networks sales increased 9.7% from
$128.5 million in 2012 to $141.0 million in 2013. The increase is attributable to an increase in sales of our Internetworking products, partially offset by decreases in sales of our legacy products. The increase in sales of our Internetworking
products is primarily attributable to an improved spending environment and reflected an increase in sales of Ethernet switches and IP business gateways to both carriers and value added resellers. The decrease in legacy products was expected and is
discussed further above. Internetworking product sales attributable to Enterprise Networks were 93.6% of the division’s sales in 2013 compared with 91.5% in 2012. Legacy products primarily comprise the remainder of Enterprise Networks sales.
Enterprise Networks sales as a percentage of total sales increased from 20.7% in 2012 to 22.0% in 2013.

[0001193125-14-071988:mdna:74]
International sales, which are
included in the Carrier Networks and Enterprise Networks amounts discussed above, increased 23.6% from $150.2 million in 2012 to $185.7 million in 2013. International sales, as a percentage of total sales, increased from 24.2% in 2012 to 28.9% in
2013. The increase in international sales is primarily attributable to an increase in sales in the EMEA region, partially offset by a decrease in sales in Latin America and the Asia-Pacific region.

[0001193125-14-071988:mdna:75]
Carrier Systems product sales increased $28.2 million in 2013 compared to 2012 primarily due to a $20.5 million increase in Broadband Access product
sales, a $3.9 million increase in Optical product sales, and a $3.9 million increase in legacy product sales. The increase in Carrier Systems product sales is primarily attributable to the factors discussed above.

[0001193125-14-071988:mdna:76]
Business Networking product sales increased $19.6 million in 2013 compared to 2012 primarily due to a $21.5 million increase in Internetworking product
sales across both divisions, partially offset by a $1.9 million decrease in legacy product sales. The increase in sales of our Internetworking products was primarily attributable to an improved spending environment and reflected an increase in sales
to both carriers and value added resellers. The decrease in legacy products was expected and is further discussed above.

[0001193125-14-071988:mdna:77]
Loop Access product
sales decreased $26.6 million in 2013 compared to 2012 primarily due to a $25.3 million decrease in HDSL product sales, which is further discussed above.

[0001193125-14-071988:mdna:78]
Cost of Sales

[0001193125-14-071988:mdna:79]
As a percentage of sales, cost of sales increased from 49.0% in 2012 to
51.9% in 2013. The increase was primarily attributable to a higher volume of the lower gross margin products related to the broadband access business we acquired in 2012, customer price movements to achieve market share position and shifts in
customer mix.

[0001193125-14-071988:mdna:80]
Carrier Networks cost of sales increased from 49.7% of sales in 2012 to 53.4% of sales in 2013. The increase in Carrier
Networks cost of sales as a percentage of sales was primarily attributable to a higher volume of the lower gross margin products related to the acquired broadband access business, customer price movements to achieve market share position and shifts
in customer mix.

[0001193125-14-071988:mdna:81]
Enterprise Networks cost of sales increased from 46.1% of sales in 2012 to 46.3% of sales in 2013. The
increase in Enterprise Networks cost of sales as a percentage of sales was primarily attributable to customer price movements to achieve market share position and the impact of cost allocations between divisions, partially offset by higher cost
absorption due to the higher production volumes.

[0001193125-14-071988:mdna:82]
An important part of our strategy is to reduce the product cost of each succeeding product
generation and then to lower the product’s price based on the cost savings achieved. This may cause variations in our gross profit percentage due to timing differences between the recognition of cost reductions and the lowering of product
selling prices.

[0001193125-14-071988:mdna:83]
Selling, General and Administrative Expenses

[0001193125-14-071988:mdna:84]
Selling, general and administrative expenses decreased 3.8% from $134.5 million in 2012 to $129.4 million in 2013. Selling, general and administrative expenses include personnel costs for administration,
finance, information systems, human resources, sales and marketing, and general management, as well as rent, utilities, legal and accounting expenses, bad debt expense, advertising, promotional material, trade show expenses, and related travel
costs. The decrease in selling, general and administrative expenses is primarily related to decreases in professional services, legal services and travel expenses, which were higher in 2012 due to pre-acquisition activities related to the acquired
broadband access business, and decreased independent contractor expense.

[0001193125-14-071988:mdna:85]
Selling, general and administrative expenses as a percentage of
sales decreased from 21.7% for the year ended December 31, 2012 to 20.2% for the year ended December 31, 2013. Selling, general and administrative expenses as a percentage of sales will generally fluctuate whenever there is a significant
fluctuation in revenues for the periods being compared.

[0001193125-14-071988:mdna:86]
Research and Development Expenses

[0001193125-14-071988:mdna:87]
Research and development expenses increased 4.1% from $126.0 million in 2012 to $131.1 million in 2013. The increase in research and development expenses
is primarily attributable to increases in staffing and fringe benefit costs due to increased headcount related to the broadband access business acquired on May 4, 2012, increases in amortization of acquired intangible assets and depreciation of
acquired fixed assets, partially offset by a decrease in independent contractor expenses.

[0001193125-14-071988:mdna:88]
Research and development expenses as a percentage
of sales increased from 20.3% for the year ended December 31, 2012 to 20.4% for the year ended December 31, 2013. Research and development expenses as a percentage of sales will fluctuate whenever there are incremental product development
activities or a significant fluctuation in revenues for the periods being compared.

[0001193125-14-071988:mdna:89]
We expect to continue to incur research and development
expenses in connection with our new and existing products and our expansion into international markets. We continually evaluate new product opportunities and engage in intensive research and product development efforts which provide for new product
development, enhancement of existing products and product cost reductions. We may incur significant research and development expenses prior to the receipt of revenues from a major new product group.

[0001193125-14-071988:mdna:90]
Interest and Dividend Income

[0001193125-14-071988:mdna:91]
Interest
and dividend income decreased from $7.7 million in 2012 to $7.0 million in 2013. The decrease in interest and dividend income is primarily attributable to a reduction in the average rate of return on our investments as well as a decrease in our
average investment balances.

[0001193125-14-071988:mdna:92]
Interest Expense

[0001193125-14-071988:mdna:93]
Interest expense remained consistent at $2.3 million in 2012 and 2013, as we had no substantial change in our fixed rate borrowings. See “Liquidity and Capital Resources” below for additional
information.

[0001193125-14-071988:mdna:94]
Net Realized Investment Gain

[0001193125-14-071988:mdna:95]
Net realized investment gain decreased from $9.6 million in 2012 to $8.6 million in 2013. The decrease in realized investment gains is primarily attributable to lower gains from the sale of equity
securities in 2013. See “Investing Activities” in “Liquidity and Capital Resources” below for additional information.

[0001193125-14-071988:mdna:96]
Other Income (Expense), net

[0001193125-14-071988:mdna:97]
Other income (expense), net, comprised primarily of miscellaneous income, gains and losses on foreign currency transactions, investment account management fees, and gains or losses on the disposal of
property, plant and equipment occurring in the normal course of business, changed from $0.2 million of income in 2012 to $0.9 million of expense in 2013.

[0001193125-14-071988:mdna:98]
Income Taxes

[0001193125-14-071988:mdna:99]
Our effective tax rate decreased from 35.2% in 2012 to 24.7% in 2013. The
decrease in the effective tax rate between the two periods is primarily attributable to an acquired business that incurred losses in the prior year for which no tax benefit was recognized and the improved profitability of that business in the
current year, the net effect of recording the benefit for the research tax credit for the 2012 tax year in January 2013 pursuant to the American Taxpayer Relief Act of 2012, and the inclusion of the benefit of the estimated 2013 research tax credit
in the estimated annual effective rate for 2013.

[0001193125-14-071988:mdna:100]
Net Income

[0001193125-14-071988:mdna:101]
As a result of the above factors, net income decreased from $47.3 million in 2012 to $45.8 million in 2013. As a percentage of sales, net income decreased from 7.6% in 2012 to 7.1% in 2013.

[0001193125-14-071988:mdna:102]
2012 Compared to 2011

[0001193125-14-071988:mdna:103]
Sales

[0001193125-14-071988:mdna:104]
ADTRAN’s sales decreased 13.5% from $717.2 million in 2011 to $620.6 million in 2012. The decrease in sales is primarily attributable
to an $87.6 million decrease in sales of our HDSL and other legacy products, a $30.8 million decrease in sales of our Optical products, an $8.6 million decrease in sales of our Internetworking products, partially offset by a $30.3 million increase
in sales of our Broadband Access products.

[0001193125-14-071988:mdna:105]
Carrier Networks sales decreased 13.6% from $569.6 million in 2011 to $492.1 million in 2012. The
decrease is primarily attributable to decreases in sales of Optical products, HDSL products and other legacy products. These declines were partially offset by the added sales of the NSN BBA business and an increase in sales of our Internetworking
NTE products. Our organic Broadband Access sales in 2012 were negatively impacted by decreased capital expenditures at two substantial Broadband Access customers. The decrease in sales of Optical products in 2012 is primarily attributable to the
market transitioning to Ethernet and our transition to new products to address this market. The declining trend in HDSL and other legacy products has been expected as we evolve our products towards packet-based technologies, but was larger than
anticipated due to a large carrier customer that initiated a significant acceleration of their installed inventory reuse program.

[0001193125-14-071988:mdna:106]
Enterprise
Networks sales decreased 13.0% from $147.7 million in 2011 to $128.5 million in 2012. The decrease is attributable to decreases in sales of Internetworking products and legacy products. The decrease in Internetworking product sales in 2012 is
primarily due to a decline in Carrier spending caused by the macroeconomic environment, partially offset by growth in the value-added reseller channel and by the addition of our vWLAN solutions. Internetworking product sales attributable to
Enterprise Networks were 91.5% of the division’s sales in 2012 compared with 87.4% in 2011. Legacy products primarily comprise the remainder of Enterprise Networks sales. Enterprise Networks sales as a percentage of total sales increased from
20.6% in 2011 to 20.7% in 2012.

[0001193125-14-071988:mdna:107]
International sales, which are included in the Carrier Networks and Enterprise Networks amounts discussed
above, increased 77.9% from $84.4 million in 2011 to $150.2 million in 2012. International sales, as a percentage of total sales, increased from 11.8% in 2011 to 24.2% in 2012. The increase in international sales in 2012 was primarily due to sales
attributable to the acquired NSN BBA business and an increase in organic sales in Latin America.

[0001193125-14-071988:mdna:108]
Carrier Systems product sales decreased
$20.6 million in 2012 compared to 2011 primarily due to a $30.8 million decrease in Optical product sales and a $20.2 million decrease in legacy product sales, partially offset by an increase of $30.3 million in Broadband Access product sales. The
decrease in sales of Optical products in 2012 is primarily attributable to the market transitioning to Ethernet and our transition to new products to address this market. The increase in Broadband Access product sales was due to the added sales of
the NSN BBA business, partially offset by a decline in organic Broadband Access product sales. Our organic Broadband Access sales in 2012 were negatively impacted by decreased capital expenditures at two substantial Broadband Access customers.

[0001193125-14-071988:mdna:109]
Business Networking product sales decreased $12.9 million in 2012 compared to 2011 primarily due to an $8.6
million decrease in Internetworking product sales across both divisions and a $4.3 million decrease in legacy product sales. The decrease in Internetworking product sales in 2012 is primarily due to a decline in Carrier spending caused by the
macroeconomic environment, partially offset by growth in the value-added reseller channel and by the addition of our vWLAN solutions. The decrease in sales of legacy products is a result of customers shifting to newer technologies. Many of these
newer technologies are integral to our Internetworking product area.

[0001193125-14-071988:mdna:110]
Loop Access product sales decreased $63.1 million in 2012 compared to
2011 primarily due to a $60.0 million decrease in HDSL product sales. The declining trend in HDSL and other legacy products has been expected as we evolve our products towards packet-based technologies, but was larger than anticipated due to a large
carrier customer that initiated a significant acceleration of their installed inventory reuse program.

[0001193125-14-071988:mdna:111]
Cost of Sales

[0001193125-14-071988:mdna:112]
As a percentage of sales, cost of sales increased from 42.2% in 2011 to 49.0% in 2012. The increase was primarily attributable to lower gross margins
related to the acquired NSN BBA business, lower cost absorption due to the lower production volumes, customer price movements to achieve market share position and higher warranty costs.

[0001193125-14-071988:mdna:113]
Carrier Networks cost of sales increased from 42.4% of sales in 2011 to 49.7% of sales in 2012. The increase in Carrier Networks cost of sales as a percentage of sales was primarily attributable to lower
gross margins related to the acquired NSN BBA business, lower cost absorption due to the lower production volumes, customer price movements to achieve market share position and higher warranty costs.

[0001193125-14-071988:mdna:114]
Enterprise Networks cost of sales increased from 41.4% of sales in 2011 to 46.1% of sales in 2012. The increase in Enterprise Networks cost of sales as a
percentage of sales was primarily attributable to lower cost absorption due to the lower production volumes and customer price movements to achieve market share position.

[0001193125-14-071988:mdna:115]
An important part of our strategy is to reduce the product cost of each succeeding product generation and then to lower the product’s price based on the cost savings achieved. This may cause
variations in our gross profit percentage due to timing differences between the recognition of cost reductions and the lowering of product selling prices.

[0001193125-14-071988:mdna:116]
Selling, General and Administrative Expenses

[0001193125-14-071988:mdna:117]
Selling, general and administrative expenses
increased 7.7% from $124.9 million in 2011 to $134.5 million in 2012. Selling, general and administrative expenses include personnel costs for administration, finance, information systems, human resources, sales and marketing, and general
management, as well as rent, utilities, legal and accounting expenses, bad debt expense, advertising, promotional material, trade show expenses, and related travel costs. The increase in selling, general and administrative expenses is primarily
related to increases in staffing and fringe benefit costs due to increased headcount, professional services, legal services and amortization of acquired intangible assets. These increases were primarily related to the NSN BBA business, which was
acquired on May 4, 2012, and Bluesocket Inc., which was acquired on August 4, 2011.

[0001193125-14-071988:mdna:118]
Selling, general and administrative expenses as
a percentage of sales increased from 17.4% for the year ended December 31, 2011 to 21.7% for the year ended December 31, 2012. Selling, general and administrative expenses as a percentage of sales will generally fluctuate whenever there is
a significant fluctuation in revenues for the periods being compared.

[0001193125-14-071988:mdna:119]
Research and Development Expenses

[0001193125-14-071988:mdna:120]
Research and development expenses increased 25.6% from $100.3 million in 2011 to $126.0 million in 2012. The increase in research and development expense
is primarily related to increases in staffing and fringe benefit costs due to increased headcount, including expenses and increased headcount related to the NSN BBA business acquired on May 4, 2012 and Bluesocket, Inc., which was acquired on
August 4, 2011, amortization of acquired intangible assets related to both acquisitions, and increases in independent contractor expense and office lease expense related to the NSN BBA business.

[0001193125-14-071988:mdna:121]
Research and development expenses as a percentage of sales increased from 14.0% for the year ended December 31, 2011 to 20.3% for the year ended
December 31, 2012. Research and development expenses as a percentage of sales will fluctuate whenever there are incremental product development activities or a significant fluctuation in revenues for the periods being compared.

[0001193125-14-071988:mdna:122]
We expect to continue to incur research and development expenses in connection with our new and existing
products and our expansion into international markets. We continually evaluate new product opportunities and engage in intensive research and product development efforts which provide for new product development, enhancement of existing products and
product cost reductions. We may incur significant research and development expenses prior to the receipt of revenues from a major new product group.

[0001193125-14-071988:mdna:123]
Interest and Dividend Income

[0001193125-14-071988:mdna:124]
Interest and dividend income remained consistent at $7.6
million in 2011 and $7.7 million in 2012, as we had no substantial change in interest-bearing investment balances or interest rates.

[0001193125-14-071988:mdna:125]
Interest Expense

[0001193125-14-071988:mdna:126]
Interest expense
remained consistent at $2.4 million in 2011 and $2.3 million in 2012, as we had no substantial change in our fixed rate borrowing. See “Liquidity and Capital Resources” below for additional information.

[0001193125-14-071988:mdna:127]
Net Realized Investment Gain

[0001193125-14-071988:mdna:128]
Net
realized investment gain decreased from $12.5 million in 2011 to $9.6 million in 2012. This change is primarily related to a $1.3 million decrease related to sales of marketable equity securities and impaired marketable equity securities, a $0.6
million decrease in distributions from two private equity funds, and a $0.6 million increase in impairment of deferred compensation plan assets. See “Investing Activities” in “Liquidity and Capital Resources” below for additional
information.

[0001193125-14-071988:mdna:129]
Other Income (Expense), net

[0001193125-14-071988:mdna:130]
Other income (expense), net, comprised primarily of miscellaneous income, gains and losses on foreign currency transactions, investment account management fees, and gains or losses on the disposal of
property, plant and equipment occurring in the normal course of business, changed from $0.7 million of expense in 2011 to $0.2 million of income in 2012.

[0001193125-14-071988:mdna:131]
Income Taxes

[0001193125-14-071988:mdna:132]
Our effective tax rate increased from 32.8% in 2011 to 35.2% in 2012. This
increase is primarily attributable to the exclusion of the research tax credit in 2012 and our inability to utilize losses generated by our foreign subsidiaries where a full valuation allowance was provided. These tax rate increases were partially
offset by increased state tax incentives in 2012. In 2013, we will recognize a benefit from the research tax credit related to 2012 and 2013, of which we estimate $3.1 million will be attributable to 2012.

[0001193125-14-071988:mdna:133]
Net Income

[0001193125-14-071988:mdna:134]
As a result of the above
factors, net income decreased from $138.6 million in 2011 to $47.3 million in 2012. As a percentage of sales, net income decreased from 19.3% in 2011 to 7.6% in 2012.

[0001193125-14-071988:mdna:135]
Liquidity and Capital Resources

[0001193125-14-071988:mdna:136]
Liquidity

[0001193125-14-071988:mdna:137]
We intend to finance our operations with cash flow from operations. We have used, and expect to continue to use, the cash generated from operations for
working capital, purchases of treasury stock, shareholder dividends, and other general corporate purposes, including (i) product development activities to enhance our existing products and develop new products and (ii) expansion of sales
and marketing activities. We believe our cash and cash equivalents, investments and cash generated from operations to be adequate to meet our operating and capital needs for at least the next 12 months.

[0001193125-14-071988:mdna:138]
At December 31, 2013, cash on hand was $58.3 million and short-term investments were $105.8 million, which placed our short-term liquidity at $164.1
million. At December 31, 2012, our cash on hand of $68.5 million and short-term investments of $160.5 million placed our short-term liquidity at $228.9 million. The decrease in short-term liquidity from 2012 to 2013 primarily reflects funds
used for share repurchases, shareholder dividends, and equipment acquisitions, partially offset by funds provided by our operating activities, and proceeds from stock option exercises.

[0001193125-14-071988:mdna:139]
Operating Activities

[0001193125-14-071988:mdna:140]
Our working capital, which consists of current assets less current liabilities, decreased 17.9% from $338.0 million as of December 31, 2012 to $277.3 million as of December 31, 2013. The quick
ratio, defined as cash and cash equivalents, short-term investments, and net accounts receivable, divided by current liabilities, decreased from 2.93 as of December 31, 2012 to 2.44 as of December 31, 2013. The current ratio, defined as
current assets divided by current liabilities, decreased from 4.20 as of December 31, 2012 to 3.71 as of December 31, 2013. The changes in our working capital, quick ratio and current ratio are primarily attributable to a decrease in
short-term investments, which proceeds were primarily used to fund share repurchases during the year.

[0001193125-14-071988:mdna:141]
Net accounts receivable increased 7.7%
from $79.7 million at December 31, 2012 to $85.8 million at December 31, 2013. Our allowance for doubtful accounts increased from $6 thousand at December 31, 2012 to $130 thousand at December 31, 2013. Quarterly accounts
receivable days sales outstanding (DSO) decreased from 52 days as of December 31, 2012 to 50 days as of December 31, 2013. The change in net accounts receivable and DSO is due to changes in customer mix and the timing of sales and
collections during the quarter. Certain international customers can have longer payment terms than U.S. customers. Other receivables increased from $16.3 million at December 31, 2012 to $18.2 million at December 31, 2013. At
December 31, 2013 and 2012, other receivables included an estimated receivable due from NSN related to working capital adjustments under negotiation. Other receivables will also fluctuate due to the timing of shipments and collections for
materials supplied to our contract manufacturers during the quarter.

[0001193125-14-071988:mdna:142]
Quarterly inventory turnover increased from 2.8 turns as of
December 31, 2012 to 3.6 turns as of December 31, 2013. Inventory decreased 11.1% from December 31, 2012 to December 31, 2013. We expect inventory levels to fluctuate as we attempt to maintain sufficient inventory in response to
seasonal cycles of our business ensuring competitive lead times while managing the risk of inventory obsolescence that may occur due to rapidly changing technology and customer demand.

[0001193125-14-071988:mdna:143]
Accounts payable increased 14.5% from $42.2 million at December 31, 2012 to $48.3 million at December 31, 2013. Accounts payable will fluctuate due to variations in the timing of the receipt of
supplies, inventory and services and our subsequent payments for these purchases.

[0001193125-14-071988:mdna:144]
Investing Activities

[0001193125-14-071988:mdna:145]
Capital expenditures totaled approximately $8.2 million, $12.3 million and $11.8 million for the years ended December 31, 2013, 2012 and 2011,
respectively. These expenditures were primarily used to purchase computer hardware, software and manufacturing and test equipment.

[0001193125-14-071988:mdna:146]
On
May 4, 2012, we acquired the NSN BBA business. This acquisition provides us with an established customer base in key markets and complementary, market-focused products and was accounted for as a business combination. Upon acquisition, we
received a cash payment of $7.5 million from NSN and recorded a bargain purchase gain of $1.8 million, net of income taxes, subject to customary working capital adjustments between the parties during the three months ended June 30, 2012. We are
currently negotiating the final working capital adjustments in accordance with the provisions of the underlying purchase agreement.

[0001193125-14-071988:mdna:147]
Our
combined short-term and long-term investments decreased $78.2 million from $493.2 million at December 31, 2012 to $415.0 million at December 31, 2013. This decrease reflects the impact of our cash needs for share repurchases, shareholder
dividends, equipment acquisitions, as well as net realized and unrealized losses and amortization of net premiums on our combined investments, partially offset by additional funds available for investment provided by our operating activities and
stock option exercises by our employees.

[0001193125-14-071988:mdna:148]
We invest all available cash not required for immediate use in operations primarily in securities
that we believe bear minimal risk of loss. At December 31, 2013 these investments included corporate bonds of $166.9 million, municipal fixed-rate bonds of $136.3 million and municipal variable rate demand notes of $8.3 million. At
December 31, 2012, these investments included corporate bonds of $186.4 million, municipal fixed-rate bonds of $175.1 million and municipal variable rate demand notes of $34.4 million. As of December 31, 2013, our corporate bonds,
municipal fixed-rate bonds, and municipal variable rate demand notes were classified as available-for-sale and had a combined duration of 0.95 years with an average credit rating of A+. Because our bond portfolio has a high quality rating and
contractual maturities of a short duration, we are able to obtain prices for these bonds derived from observable market inputs, or for similar securities traded in an active market, on a daily basis.

[0001193125-14-071988:mdna:149]
Our long-term investments decreased 7.1% from $332.7 million at December 31, 2012 to $309.2 million at December 31, 2013. Long-term investments
at December 31, 2013 and December 31, 2012 included an investment in a certificate of deposit of $48.3 million, which serves as collateral for our revenue bonds, as discussed below. We have various equity investments included in long-term
investments at a cost of $24.7 million and $21.0 million, and with a fair value of $38.5 million and $35.2 million, at December 31, 2013 and December 31, 2012, respectively.

[0001193125-14-071988:mdna:150]
Long-term investments at December 31, 2013 and 2012 also included $15.1 million and $11.5 million,
respectively, related to our deferred compensation plan, and $1.7 million and $1.9 million, respectively, of other investments carried at cost, consisting of interests in two private equity funds and an investment in a privately held
telecommunications equipment manufacturer. At December 31, 2012, long-term investments also included $0.5 million of a fixed income bond fund.

[0001193125-14-071988:mdna:151]
We review our investment portfolio for potential “other-than-temporary” declines in value on an individual investment basis. We assess, on a quarterly basis, significant declines in value which
may be considered other-than-temporary and, if necessary, recognize and record the appropriate charge to write-down the carrying value of such investments. In making this assessment, we take into consideration qualitative and quantitative
information, including but not limited to the following: the magnitude and duration of historical declines in market prices, credit rating activity, assessments of liquidity, public filings, and statements made by the issuer. We generally begin our
identification of potential other-than-temporary impairments by reviewing any security with a fair value that has declined from its original or adjusted cost basis by 25% or more for six or more consecutive months. We then evaluate the individual
security based on the previously identified factors to determine the amount of the write-down, if any. As a result of our review, we recorded an other-than-temporary impairment charge of $11 thousand during the fourth quarter of 2013 related to four
marketable equity securities. For the years ended December 31, 2013, 2012 and 2011 we recorded charges of $25 thousand, $0.7 million and $68 thousand, respectively, related to the other-than-temporary impairment of certain publicly traded
equity securities and our deferred compensation plan assets.

[0001193125-14-071988:mdna:152]
Financing Activities

[0001193125-14-071988:mdna:153]
In conjunction with an expansion of our Huntsville, Alabama, facility, we were approved for participation in an incentive program offered by the State of
Alabama Industrial Development Authority (the “Authority”). Pursuant to the program, on January 13, 1995, the Authority issued $20.0 million of its taxable revenue bonds and loaned the proceeds from the sale of the bonds to ADTRAN.
The bonds were originally purchased by AmSouth Bank of Alabama, Birmingham, Alabama (the “Bank”). Wachovia Bank, N.A., Nashville, Tennessee (formerly First Union National Bank of Tennessee) (the “Bondholder”), which was acquired
by Wells Fargo & Company on December 31, 2008, purchased the original bonds from the Bank and made further advances to the Authority, bringing the total amount outstanding to $50.0 million. An Amended and Restated Taxable Revenue Bond
(“Amended and Restated Bond”) was issued and the original financing agreement was amended. The Amended and Restated Bond bears interest, payable monthly. The interest rate is 5% per annum. The Amended and Restated Bond matures on
January 1, 2020. The estimated fair value of the bond at December 31, 2013 was approximately $45.4 million, based on a debt security with a comparable interest rate and maturity and a Standard & Poor’s credit rating of A-. We
are required to make payments to the Authority in amounts necessary to pay the interest on the Amended and Restated Bond. Included in long-term investments at December 31, 2013 is $48.3 million which is invested in a restricted certificate of
deposit. These funds serve as a collateral deposit against the principal of this bond, and we have the right to set-off the balance of the Bond with the collateral deposit in order to reduce the balance of the indebtedness.

[0001193125-14-071988:mdna:154]
In conjunction with this program, we are eligible to receive certain economic incentives from the state of Alabama that reduce the amount of payroll
withholdings that we are required to remit to the state for those employment positions that qualify under the program. For the years ended December 31, 2013, 2012 and 2011, we realized economic incentives related to payroll withholdings
totaling $1.3 million, $1.4 million and $1.9 million, respectively.

[0001193125-14-071988:mdna:155]
We did not make a principal payment for the year-ended December 31,
2013. We made a principal payment of $0.5 million for the year ended December 31, 2012. We anticipate making a principal payment in 2014. At December 31, 2013 and 2012, $0.3 million and $0.5 million, respectively, of the bond debt were
classified as a current liability in accounts payable in the Consolidated Balance Sheets at December 31, 2013.

[0001193125-14-071988:mdna:156]
The following table shows
dividends paid to our shareholders in each quarter of 2013, 2012 and 2011. During 2013, 2012 and 2011, we paid shareholder dividends totaling $21.4 million, $22.8 million and $23.1 million, respectively. The Board of Directors presently anticipates
that it will declare a regular quarterly dividend so long as the present tax treatment of dividends exists and adequate levels of liquidity are maintained.

[0001193125-14-071988:mdna:157]
Dividends per Common Share

[0001193125-14-071988:mdna:158]
|  |  | 2013 |  |  | 2012 |  |  | 2011 |  |
| First Quarter |  | $ | 0.09 |  |  | $ | 0.09 |  |  | $ | 0.09 |  |
| Second Quarter |  | $ | 0.09 |  |  | $ | 0.09 |  |  | $ | 0.09 |  |
| Third Quarter |  | $ | 0.09 |  |  | $ | 0.09 |  |  | $ | 0.09 |  |
| Fourth Quarter |  | $ | 0.09 |  |  | $ | 0.09 |  |  | $ | 0.09 |  |

[0001193125-14-071988:mdna:159]
Stock Repurchase Program

[0001193125-14-071988:mdna:160]
Since 1997, our Board of Directors has approved multiple share repurchase programs that have authorized open market repurchase transactions of up to 35 million shares of our common stock. On
May 1, 2013, our Board of Directors authorized the repurchase of an additional 5.0 million shares of our common stock (bringing the total shares authorized for repurchase to 40 million), which commenced upon completion of the repurchase
plan announced on October 11, 2011. This new authorization is being implemented through open market or private purchases from time to time as conditions warrant. For the years 2013, 2012 and 2011, we repurchased 5.6 million shares,
1.8 million shares and 1.1 million shares, respectively, for a cost of $124.3 million, $39.4 million and $35.6 million, respectively, at an average price of $22.16, $22.03 and $31.97 per share, respectively. We currently have the authority
to purchase an additional 3.5 million shares of our common stock under the current plan approved by the Board of Directors.

[0001193125-14-071988:mdna:161]
Stock
Option Exercises

[0001193125-14-071988:mdna:162]
To accommodate employee stock option exercises, we issued 0.2 million shares of treasury stock for $3.6 million
during the year ended December 31, 2013, 0.4 million shares of treasury stock for $6.0 million during the year ended December 31, 2012, and 1.8 million shares of treasury stock for $34.1 million during the year ended
December 31, 2011.

[0001193125-14-071988:mdna:163]
Off-Balance Sheet Arrangements and Contractual Obligations

[0001193125-14-071988:mdna:164]
We do not have off-balance sheet financing arrangements and have not engaged in any related party transactions or arrangements with unconsolidated
entities or other persons that are reasonably likely to materially affect liquidity or the availability of or requirements for capital resources.

[0001193125-14-071988:mdna:165]
We have various contractual obligations and commercial commitments. The following table sets forth, in millions, the annual payments we are required to make under contractual cash obligations and other
commercial commitments at December 31, 2013.

[0001193125-14-071988:mdna:166]
Contractual Obligations

[0001193125-14-071988:mdna:167]
| (In millions) |  | Total |  |  | 2014 |  |  | 2015 |  |  | 2016 |  |  | 2017 |  |  | After 2017 |  |
| Long-term debt |  | $ | 46.5 |  |  | $ | 0.3 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 46.2 |  |
| Interest on long-term debt |  |  | 14.0 |  |  |  | 2.3 |  |  |  | 2.3 |  |  |  | 2.3 |  |  |  | 2.3 |  |  |  | 4.8 |  |
| Purchase obligations |  |  | 75.0 |  |  |  | 74.9 |  |  |  | 0.1 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Operating lease obligations |  |  | 13.5 |  |  |  | 4.5 |  |  |  | 3.6 |  |  |  | 2.5 |  |  |  | 2.2 |  |  |  | 0.7 |  |
| Totals |  | $ | 149.0 |  |  | $ | 82.0 |  |  | $ | 6.0 |  |  | $ | 4.8 |  |  | $ | 4.5 |  |  | $ | 51.7 |  |

[0001193125-14-071988:mdna:168]
We are required to make payments necessary to pay the interest on the Taxable Revenue Bond, Series 1995, as amended,
currently outstanding in the aggregate principal amount of $46.5 million. The bond matures on January 1, 2020, and bears interest at the rate of 5% per annum. Included in long-term investments are $48.3 million of restricted funds, which
is a collateral deposit against the principal amount of this bond. We did not make a principal payment for the year-ended December 31, 2013. We made a principal payment of $0.5 million for the year ended December 31, 2012. We anticipate
making a principal payment in 2014. At December 31, 2013 and 2012, $0.3 million and $0.5 million, respectively, of the bond debt were classified as a current liability in accounts payable in the Consolidated Balance Sheets at December 31,
2013. See Note 9 of Notes to Consolidated Financial Statements for additional information.

[0001193125-14-071988:mdna:169]
We have committed to invest up to an aggregate of
$7.9 million in two private equity funds, and we have contributed $8.4 million as of December 31, 2013, of which $7.7 million has been applied to these commitments. The additional $0.2 million commitment has been excluded from the table above
due to uncertainty of when it will be applied.

[0001193125-14-071988:mdna:170]
We also have obligations related to uncertain income tax positions that have been excluded
from the table above due to the uncertainty of when the related expense will be recognized. See Note 10 of Notes to Consolidated Financial Statements for additional information.

[0001193125-14-071988:mdna:171]
Effect of Recent Accounting Pronouncements

[0001193125-14-071988:mdna:172]
During 2013, we adopted the following accounting standards, which had no material effect on our consolidated results of operations or financial condition:

[0001193125-14-071988:mdna:173]
In February 2013, the FASB issued Accounting Standards Update No. 2013-02, Reporting of Amounts Reclassified Out of Accumulated Other Comprehensive
Income (ASU 2013-02). ASU 2013-02 requires entities to provide information about the amounts reclassified out of accumulated other comprehensive income by component either on the face of the financial statements or in the footnotes. ASU 2013-02 does
not change the current requirements for reporting net income or other comprehensive income in the financial statements. This update is effective prospectively for reporting periods beginning after December 15, 2012. We adopted this amendment
during the first quarter of 2013, and we have provided the disclosures required for the years ended December 31, 2013, 2012 and 2011 in Note 1 of Notes to Consolidated Financial Statements.

[0001193125-14-071988:mdna:174]
Subsequent Events

[0001193125-14-071988:mdna:175]
On January 21,
2014, the Board declared a quarterly cash dividend of $0.09 per common share to be paid to shareholders of record at the close of business on February 6, 2014. The quarterly dividend payment was $5.1 million and was paid on February 20,
2014.

[0001193125-14-071988:mdna:176]
In February 2014, we made a decision to make a $16.5 million principal payment on the Amended and Restated Bond. The restricted
certificate of deposit included in our long-term investments will be reduced by the amount of the payment. We anticipate this payment will be made during the first quarter of 2014.

[0001193125-14-071988:mdna:177]
Since January 1, 2014 and as of February 27, 2014, we have repurchased 0.4 million shares of our common stock through open market purchases at an average cost of $25.13 per share. We
currently have the authority to purchase an additional 3.1 million shares of our common stock under the current plan approved by the Board of Directors.
