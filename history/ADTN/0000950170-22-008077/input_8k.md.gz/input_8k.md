# ADTN 8-K — 0000950170-22-007563 filed 2022-05-05

## item codes, every 8-K on or before 2022-05-06

- 2022-05-05 0000950170-22-007563 — 2.02, 9.01
- 2022-04-06 0000950170-22-005405 — 1.01, 2.03, 9.01
- 2022-02-03 0000950170-22-000705 — 2.02, 9.01
- 2022-01-06 0001193125-22-003467 — 5.07, 7.01, 9.01
- 2021-12-28 0001193125-21-368041 — 8.01
- 2021-11-29 0000950170-21-004926 — 5.02, 9.01
- 2021-11-02 0000950170-21-002595 — 7.01, 9.01
- 2021-11-02 0000950170-21-002593 — 2.02, 9.01
- 2021-10-15 0000950170-21-002127 — 2.02, 9.01
- 2021-10-07 0000950170-21-002053 — 5.02
- 2021-09-01 0000950170-21-001615 — 5.02
- 2021-08-30 0001193125-21-260059 — 1.01, 7.01, 9.01
- 2021-08-05 0001564590-21-041127 — 2.02, 9.01
- 2021-05-18 0001564590-21-028541 — 5.07
- 2021-05-06 0001564590-21-024430 — 2.02, 9.01
- 2021-02-26 0001564590-21-009408 — 2.02, 9.01 — amendment of 0001564590-21-004167
- 2021-02-04 0001564590-21-004167 — 2.02, 9.01
- 2020-11-03 0001564590-20-049784 — 2.02, 9.01
- 2020-08-06 0001564590-20-037168 — 2.02, 9.01
- 2020-07-23 0001564590-20-033184 — 5.03, 9.01
- 2020-05-15 0001564590-20-025794 — 5.07
- 2020-05-11 0001564590-20-024328 — 5.02, 9.01
- 2020-05-07 0001564590-20-022297 — 2.02, 9.01
- 2020-02-25 0001564590-20-006448 — 2.02, 9.01
- 2020-02-06 0001564590-20-003580 — 2.02, 9.01
- 2019-10-31 0001564590-19-038936 — 2.02, 9.01
- 2019-10-10 0001564590-19-036732 — 2.02, 9.01
- 2019-09-20 0001564590-19-035144 — 2.02, 9.01
- 2019-08-21 0001564590-19-032757 — 3.01, 9.01
- 2019-07-18 0001564590-19-025186 — 2.02, 9.01
- 2019-05-09 0001564590-19-017956 — 5.07
- 2019-04-18 0001564590-19-011897 — 2.02, 9.01
- 2019-03-07 0001564590-19-006575 — 5.02, 9.01
- 2019-01-24 0001564590-19-001024 — 2.02, 9.01
- 2018-12-06 0001564590-18-030615 — 8.01, 9.01
- 2018-10-17 0001564590-18-024365 — 2.02, 9.01
- 2018-07-18 0001564590-18-016946 — 2.02, 9.01
- 2018-05-10 0001564590-18-012968 — 5.07
- 2018-04-18 0001564590-18-008361 — 2.02, 9.01
- 2018-03-21 0001564590-18-006409 — 8.01, 9.01
- 2018-01-17 0001564590-18-000519 — 2.02, 9.01
- 2017-12-29 0001564590-17-025375 — 2.02, 9.01
- 2017-11-16 0001193125-17-345232 — 5.02
- 2017-10-18 0001564590-17-019582 — 2.02, 9.01
- 2017-07-19 0001564590-17-013609 — 2.02, 9.01
- 2017-05-11 0001564590-17-010459 — 5.02, 9.01
- 2017-05-11 0001564590-17-010452 — 5.07
- 2017-04-19 0001193125-17-127926 — 2.02, 9.01
- 2017-02-07 0001193125-17-032714 — 8.01
- 2017-01-18 0001193125-17-011669 — 2.02, 9.01
- 2016-11-16 0001193125-16-769505 — 5.02, 9.01
- 2016-10-19 0001193125-16-741087 — 2.02, 9.01
- 2016-09-14 0001193125-16-709148 — 8.01, 9.01
- 2016-08-17 0001193125-16-683980 — 5.02, 9.01
- 2016-07-13 0001193125-16-646816 — 2.02, 9.01
- 2016-05-13 0001193125-16-590263 — 5.07
- 2016-04-13 0001193125-16-539019 — 2.02, 9.01
- 2016-04-08 0001193125-16-535035 — 7.01
- 2016-02-11 0001193125-16-459453 — 5.02, 9.01
- 2016-01-20 0001193125-16-432934 — 2.02, 9.01
- 2015-11-16 0001193125-15-378019 — 5.02, 9.01
- 2015-10-14 0001193125-15-343083 — 2.02, 9.01
- 2015-07-16 0001193125-15-254729 — 8.01, 9.01
- 2015-07-15 0001193125-15-253068 — 2.02, 9.01
- 2015-05-15 0001193125-15-189160 — 5.07, 9.01
- 2015-04-22 0001193125-15-140997 — 2.02, 9.01
- 2015-02-23 0001193125-15-056741 — 5.02, 9.01
- 2015-01-21 0001193125-15-015465 — 2.02, 9.01
- 2014-10-15 0001193125-14-372076 — 2.02, 9.01
- 2014-10-03 0001193125-14-363152 — 2.02, 9.01
- 2014-07-16 0001193125-14-269660 — 2.02, 9.01
- 2014-05-20 0001193125-14-205916 — 8.01, 9.01
- 2014-05-20 0001193125-14-205906 — 5.02, 9.01
- 2014-05-15 0001193125-14-201144 — 5.07
- 2014-04-16 0001193125-14-144665 — 2.02, 9.01
- 2014-04-03 0001193125-14-129578 — 2.02, 9.01
- 2014-01-22 0001157523-14-000154 — 2.02, 9.01
- 2013-10-15 0001193125-13-399540 — 5.02
- 2013-10-09 0001157523-13-004657 — 2.02, 9.01
- 2013-07-10 0001157523-13-003290 — 2.02, 9.01
- 2013-05-10 0001193125-13-213728 — 5.07
- 2013-05-03 0001193125-13-198816 — 8.01, 9.01
- 2013-04-10 0001157523-13-001730 — 2.02, 9.01
- 2013-01-16 0001157523-13-000139 — 2.02, 9.01
- 2012-10-10 0001157523-12-005081 — 2.02, 9.01
- 2012-10-03 0001193125-12-413609 — 7.01
- 2012-09-28 0001193125-12-408878 — 2.02, 9.01
- 2012-07-11 0001157523-12-003592 — 2.02, 9.01
- 2012-05-10 0001193125-12-225669 — 5.07
- 2012-05-10 0001193125-12-225639 — 8.01, 9.01
- 2012-04-11 0001157523-12-001772 — 2.02, 9.01
- 2012-03-15 0001193125-12-116494 — 2.02, 9.01
- 2012-01-18 0001157523-12-000174 — 2.02, 9.01
- 2011-12-12 0001193125-11-337271 — 7.01, 9.01
- 2011-10-13 0000950123-11-089785 — 5.03, 9.01
- 2011-10-12 0001157523-11-005682 — 2.02, 9.01
- 2011-07-13 0001157523-11-003986 — 2.02, 9.01
- 2011-05-09 0000950123-11-047191 — 5.02, 5.07, 9.01
- 2011-04-13 0001157523-11-002001 — 2.02, 9.01
- 2011-01-19 0001157523-11-000232 — 2.02, 9.01
- 2010-11-09 0000950123-10-103195 — 5.02, 9.01
- 2010-10-13 0001157523-10-005798 — 2.02, 9.01
- 2010-07-14 0001157523-10-004011 — 2.02, 9.01
- 2010-05-28 0000950123-10-053947 — 5.07
- 2010-04-14 0001157523-10-002022 — 2.02, 9.01
- 2010-01-20 0001157523-10-000200 — 2.02, 9.01
- 2009-10-28 0000950123-09-053984 — 8.01
- 2009-10-14 0001157523-09-006877 — 2.02, 9.01
- 2009-07-15 0001157523-09-004878 — 2.02, 9.01
- 2009-04-15 0001157523-09-002687 — 2.02, 9.01
- 2009-01-21 0001157523-09-000340 — 2.02, 9.01
- 2008-11-12 0001193125-08-233181 — 5.02, 9.01
- 2008-10-14 0001157523-08-007999 — 2.02, 9.01
- 2008-07-15 0001157523-08-005504 — 2.02, 9.01
- 2008-04-15 0001157523-08-002896 — 2.02, 9.01
- 2008-01-22 0001157523-08-000408 — 2.02, 9.01
- 2007-10-16 0001193125-07-219356 — 5.03, 9.01
- 2007-10-16 0001157523-07-009850 — 2.02, 9.01
- 2007-07-17 0001157523-07-006912 — 2.02, 9.01
- 2007-04-17 0001157523-07-003630 — 2.02, 9.01
- 2007-04-03 0001179022-07-000068 — 5.02
- 2007-03-28 0001179022-07-000064 — 5.02
- 2007-02-23 0001193125-07-038337 — 5.02
- 2007-02-23 0001193125-07-038335 — 5.02
- 2007-01-30 0001193125-07-015912 — 5.02, 9.01
- 2007-01-26 0001193125-07-014234 — 5.02
- 2007-01-23 0001157523-07-000494 — 2.02, 9.01 — amendment of 0001157523-07-000481
- 2007-01-23 0001157523-07-000481 — 2.02, 9.01
- 2006-10-17 0001157523-06-009945 — 2.02, 9.01
- 2006-07-18 0001157523-06-006929 — 2.02, 9.01
- 2006-06-08 0001193125-06-126486 — 1.01, 9.01
- 2006-05-10 0001193125-06-107316 — 1.01, 9.01
- 2006-04-18 0001157523-06-003699 — 2.02, 9.01
- 2006-02-03 0001179022-06-000014 — 1.01
- 2006-01-27 0001157523-06-000754 — 5.02, 9.01
- 2006-01-24 0001157523-06-000551 — 2.02, 9.01
- 2005-10-18 0001157523-05-008826 — 2.02, 9.01
- 2005-07-19 0001193125-05-143958 — 1.01, 5.02, 9.01
- 2005-07-19 0001193125-05-143957 — 2.02, 9.01
- 2005-05-20 0001193125-05-112019 — 1.01, 9.01
- 2005-04-19 0001157523-05-003418 — 2.02, 9.01
- 2005-01-25 0001193125-05-010721 — 2.02, 9.01
- 2004-10-12 0001193125-04-169652 — 2.02, 9.01
- 2004-07-13 0001193125-04-116820 — 12, 7
- 2004-04-14 0001193125-04-061547 — 12, 7
- 2004-01-21 0001193125-04-006366 — 12, 7
- 2003-10-14 0001193125-03-061018 — 12, 5, 7
- 2003-07-15 0001193125-03-019292 — 7, 9
- 2003-04-15 0000931763-03-000968 — 7, 9
- 1996-09-12 0000931763-96-000667 — 5, 7

## late-filing notifications on or before 2022-05-06

- 2019-08-12 0001564590-19-031524 — NT 10-Q, for the period ended 2019-06-30

## item 2.02 — earnings release, exhibit 99.1

[0000950170-22-007563:8k_2_02:1]
EX-99.1
2
adtn-ex99_1.htm
EX-99.1

[0000950170-22-007563:8k_2_02:2]
EX-99.1

[0000950170-22-007563:8k_2_02:3]
EXHIBIT 99.1

[0000950170-22-007563:8k_2_02:4]
ADTRAN, Inc. Reports Earnings for the First Quarter of 2022 and Declares Quarterly Cash Dividend

[0000950170-22-007563:8k_2_02:5]
HUNTSVILLE, Ala. — (May 4, 2022) — ADTRAN, Inc., (NASDAQ: ADTN) (“ADTRAN” or the “Company”), today announced financial results for the first quarter of 2022. For the quarter, revenue was $154.5 million. Earnings for the first quarter of 2022 was a net loss of $1.1 million and earnings per share was a loss of $0.02. Non-GAAP net income was $9.9 million and non-GAAP earnings per share was $0.20. Non-GAAP net income and non-GAAP earnings per share exclude stock-based compensation expense, acquisition related expenses, amortizations and adjustments, restructuring expenses, amortization of pension actuarial losses, deferred compensation related adjustments, change in valuation allowance related to our deferred tax assets, and the tax effect of these adjustments to net income (loss). The reconciliations between GAAP net income (loss) and earnings (loss) per share to non-GAAP net income and non-GAAP earnings per share are set forth in the table provided below.

[0000950170-22-007563:8k_2_02:6]
ADTRAN Chairman and Chief Executive Officer Tom Stanton stated, “We continue to experience unprecedented demand for our solutions with revenue up 21% year-over-year. We had another quarter with strong order bookings, paired with high growth in our fiber access, connected home and cloud software solutions. Our fiber access platforms led the way with an impressive 61% year-over-year growth rate. Our continued success with fiber footprint capture, customer diversification, and the portfolio synergies offered by the announced ADVA combination provides an optimistic outlook for continued growth.”

[0000950170-22-007563:8k_2_02:7]
The Company also announced that its Board of Directors declared a cash dividend for the first quarter of 2022. The quarterly cash dividend of $0.09 per common share is to be paid to the Company’s stockholders of record as of the close of business on May 19, 2022. The ex-dividend date is May 18, 2022 and the payment date will be June 2, 2022.

[0000950170-22-007563:8k_2_02:8]
The Company confirmed that it will hold a conference call to discuss its first quarter results on Thursday, May 5, 2022, at 9:30 a.m. Central Time. ADTRAN will webcast this conference call. To listen, simply visit ADTRAN’s Investor Relations site at www.adtran.com/investor approximately ten minutes prior to the start of the call, click on the event “ADTRAN Releases 1st Quarter 2022 Financial Results and Earnings Call”, and click on the Webcast link.

[0000950170-22-007563:8k_2_02:9]
An online replay of the Company’s conference call, as well as the text of the Company's conference call, will be available on the Investor Relations site approximately 24 hours following the call and will remain available for at least 12 months. For more information, visit www.investors.adtran.com or email atinvestor.relations@adtran.com.

[0000950170-22-007563:8k_2_02:10]
About ADTRAN

[0000950170-22-007563:8k_2_02:11]
At ADTRAN, we believe amazing things happen when people connect. From the cloud edge to the subscriber edge, we help communications service providers around the world manage and scale services that connect people, places and things to advance human progress. Whether rural or urban, domestic or international, telco or cable, enterprise or residential—ADTRAN solutions optimize existing technology infrastructures and create new, multi-gigabit platforms that leverage cloud economics, data analytics, machine learning and open ecosystems—the future of global networking. Find more at ADTRAN.com, LinkedIn and Twitter.

[0000950170-22-007563:8k_2_02:12]
This press release contains forward-looking statements, generally identified by the use of words such as “believe,” “expect,” “intend,” “estimate,” “anticipate,” “will,” “may,” “could” and similar expressions, which forward-looking statements reflect management’s best judgment based on factors currently known. However, these statements involve risks and uncertainties, including: (i) risks and uncertainties related to the continued impact of the SARS-CoV-2 coronavirus/COVID-19 global pandemic (including variants of the SARS-CoV-2 coronavirus), including with respect to continued manufacturing and supply chain constraints; (ii) risks and uncertainties related to the anticipated business combination between the Company and ADVA Optical Networking SE (“ADVA”), including the timing, receipt and terms and conditions of any required governmental and regulatory approvals of the contemplated business combination that could reduce anticipated benefits or cause the parties to abandon the transaction; the occurrence of any event, change or other circumstances that could give rise to the termination of the business combination agreement; the ability to successfully complete the proposed business combination; regulatory or other limitations imposed as a result of the proposed business combination; the success of the business following the proposed business combination; the ability to successfully integrate the ADTRAN and ADVA businesses; the risk that the parties may not be able to satisfy the conditions to closing of the proposed business combination in a timely manner or at all; risks related to disruption of management time from ongoing business operations due to the proposed business combination; the risk that the publicity surrounding or consummation of the proposed business combination could have adverse effects on the market price of ADTRAN’s common stock or ADVA’s common shares or the ability of ADTRAN and ADVA to retain customers, retain or hire key personnel, maintain relationships with their respective suppliers and customers, and on their operating results and businesses generally; the risk that the successor issuer (“Acorn HoldCo”), may be unable to achieve expected synergies or that it may take longer

[0000950170-22-007563:8k_2_02:13]
or be more costly than expected to achieve those synergies; the risk of fluctuations in revenue due to lengthy sales and approval process required by major and other service providers for new products; the risk posed by potential breaches of information systems and cyber-attacks; the risks that ADTRAN, ADVA or the post-combination company may not be able to effectively compete, including through product improvements and development, and (iii) the other risks detailed in the Company’s filings with the Securities and Exchange Commission, including the Company's Annual Report on Form 10-K for the year ended December 31, 2021. These risks and uncertainties could cause actual results to differ materially from those in the forward-looking statements included in this press release.

[0000950170-22-007563:8k_2_02:14]
To provide additional transparency, we have disclosed in the tables below non-GAAP operating income, which has been reconciled to operating (loss), and non-GAAP net income and non-GAAP earnings per share - basic and diluted, which have been reconciled to net (loss) income and (loss) earnings per share - basic and diluted, in each case as reported based on Generally Accepted Accounting Principles in the United States (“U.S. GAAP”). These non-GAAP financial measures exclude certain items which management believes are not reflective of the ongoing operating performance of the business. We believe this information is useful in providing period-to-period comparisons of the results of our ongoing operations. Additionally, these measures are used by management in our ongoing planning and annual budgeting processes. We believe the presentation of non-GAAP operating income, non-GAAP net income and non-GAAP earnings per share - basic and diluted, when combined with the U.S. GAAP presentation of operating (loss), net (loss) income and (loss) earnings per share - basic and diluted, is beneficial to the overall understanding of ongoing operating performance of the Company.

[0000950170-22-007563:8k_2_02:15]
These non-GAAP financial measures are not prepared in accordance with, or an alternative for, U.S. GAAP and therefore should not be considered in isolation or as a substitution for analysis of our results as reported under U.S. GAAP. Additionally, our calculation of non-GAAP operating income, non-GAAP net income and non-GAAP earnings per share - basic and diluted, may not be comparable to similar measures calculated by other companies.

[0000950170-22-007563:8k_2_02:16]
Investor Services/Assistance:

[0000950170-22-007563:8k_2_02:17]
Rhonda Lambert/256-963-7450

[0000950170-22-007563:8k_2_02:18]
investor@adtran.com

[0000950170-22-007563:8k_2_02:19]
Condensed Consolidated Balance Sheets

[0000950170-22-007563:8k_2_02:20]
(Unaudited)

[0000950170-22-007563:8k_2_02:21]
(In thousands)

[0000950170-22-007563:8k_2_02:22]
|  | March 31, |  |  | December 31, |  |
|  | 2022 |  |  | 2021 |  |
| Assets |  |  |  |  |  |
| Current Assets |  |  |  |  |  |
| Cash and cash equivalents | $ | 53,979 |  |  | $ | 56,603 |  |
| Restricted cash |  | 52 |  |  |  | 215 |  |
| Short-term investments |  | 429 |  |  |  | 350 |  |
| Accounts receivable, net |  | 150,111 |  |  |  | 158,742 |  |
| Other receivables |  | 17,373 |  |  |  | 11,228 |  |
| Inventory, net |  | 171,121 |  |  |  | 139,891 |  |
| Prepaid expenses and other current assets |  | 9,076 |  |  |  | 9,296 |  |
| Total Current Assets |  | 402,141 |  |  |  | 376,325 |  |
| Property, plant and equipment, net |  | 54,384 |  |  |  | 55,766 |  |
| Deferred tax assets, net |  | 8,939 |  |  |  | 9,079 |  |
| Goodwill |  | 6,968 |  |  |  | 6,968 |  |
| Intangibles, net |  | 18,405 |  |  |  | 19,293 |  |
| Other non-current assets |  | 30,542 |  |  |  | 30,971 |  |
| Long-term investments |  | 67,713 |  |  |  | 70,615 |  |
| Total Assets | $ | 589,092 |  |  | $ | 569,017 |  |
| Liabilities and Stockholders' Equity |  |  |  |  |  |
| Current Liabilities |  |  |  |  |  |
| Accounts payable | $ | 127,111 |  |  | $ | 102,489 |  |
| Unearned revenue |  | 19,454 |  |  |  | 17,737 |  |
| Accrued expenses and other liabilities |  | 18,736 |  |  |  | 13,673 |  |
| Accrued wages and benefits |  | 13,953 |  |  |  | 14,900 |  |
| Income tax payable, net |  | 3,519 |  |  |  | 6,560 |  |
| Total Current Liabilities |  | 182,773 |  |  |  | 155,359 |  |
| Non-current unearned revenue |  | 9,381 |  |  |  | 9,271 |  |
| Pension liability |  | 10,667 |  |  |  | 11,402 |  |
| Deferred compensation liability |  | 29,691 |  |  |  | 31,383 |  |
| Other non-current liabilities |  | 4,264 |  |  |  | 4,500 |  |
| Total Liabilities |  | 236,776 |  |  |  | 211,915 |  |
| Stockholders' Equity |  | 352,316 |  |  |  | 357,102 |  |
| Total Liabilities and Stockholders' Equity | $ | 589,092 |  |  | $ | 569,017 |  |

[0000950170-22-007563:8k_2_02:23]
Condensed Consolidated Statements of (Loss) Income

[0000950170-22-007563:8k_2_02:24]
(Unaudited)

[0000950170-22-007563:8k_2_02:25]
(In thousands, except per share data)

[0000950170-22-007563:8k_2_02:26]
|  |  | Three Months Ended |  |  |
|  |  | March 31, |  |  |
|  |  | 2022 |  |  | 2021 |  |  |
| Revenue |  |  |  |  |  |  |  |
| Network Solutions |  | $ | 138,374 |  |  | $ | 113,809 |  |  |
| Services & Support |  |  | 16,144 |  |  |  | 13,724 |  |  |
| Total Revenue |  |  | 154,518 |  |  |  | 127,533 |  |  |
| Cost of Revenue |  |  |  |  |  |  |  |
| Network Solutions |  |  | 90,653 |  |  |  | 65,001 |  |  |
| Services & Support |  |  | 9,549 |  |  |  | 8,931 |  |  |
| Total Cost of Revenue |  |  | 100,202 |  |  |  | 73,932 |  |  |
| Gross Profit |  |  | 54,316 |  |  |  | 53,601 |  |  |
| Selling, general and administrative expenses |  |  | 27,893 |  |  |  | 27,435 |  |  |
| Research and development expenses |  |  | 26,491 |  |  |  | 27,501 |  |  |
| Operating Loss |  |  | (68 | ) |  |  | (1,335 | ) |  |
| Interest and dividend income |  |  | 204 |  |  |  | 290 |  |  |
| Interest expense |  |  | (30 | ) |  |  | (6 | ) |  |
| Net investment (loss) gain |  |  | (3,415 | ) |  |  | 996 |  |  |
| Other (expense) income, net |  |  | (226 | ) |  |  | 1,999 |  |  |
| (Loss) income Before Income Taxes |  |  | (3,535 | ) |  |  | 1,944 |  |  |
| Income tax benefit (expense) |  |  | 2,408 |  |  |  | (1,048 | ) |  |
| Net (Loss) Income |  | $ | (1,127 | ) |  | $ | 896 |  |  |
| Weighted average shares outstanding – basic |  |  | 49,113 |  |  |  | 48,336 |  |  |
| Weighted average shares outstanding – diluted |  |  | 49,113 |  |  |  | 49,004 |  | (1) |
| (Loss) earnings per common share – basic |  | $ | (0.02 | ) |  | $ | 0.02 |  |  |
| (Loss) earnings per common share – diluted |  | $ | (0.02 | ) |  | $ | 0.02 |  | (1) |

[0000950170-22-007563:8k_2_02:27]
(1) Assumes exercise of dilutive stock awards calculated under the treasury stock method.

[0000950170-22-007563:8k_2_02:28]
Condensed Consolidated Statements of Cash Flows

[0000950170-22-007563:8k_2_02:29]
(Unaudited)

[0000950170-22-007563:8k_2_02:30]
(In thousands)

[0000950170-22-007563:8k_2_02:31]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
|  |  | 2022 |  |  | 2021 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |
| Net (loss) income |  | $ | (1,127 | ) |  | $ | 896 |  |
| Adjustments to reconcile net loss to net cash provided by operating activities: |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 3,661 |  |  |  | 4,122 |  |
| Loss (gain) on investments |  |  | 3,304 |  |  |  | (1,161 | ) |
| Stock-based compensation expense |  |  | 1,893 |  |  |  | 1,807 |  |
| Other, net |  |  | (62 | ) |  |  | 84 |  |
| Inventory reserves |  |  | (1,754 | ) |  |  | (2,131 | ) |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |
| Accounts receivable, net |  |  | 8,697 |  |  |  | (4,762 | ) |
| Other receivables |  |  | (6,205 | ) |  |  | (1,220 | ) |
| Inventory |  |  | (29,685 | ) |  |  | 4,024 |  |
| Prepaid expenses, other current assets and other assets |  |  | (1,170 | ) |  |  | (417 | ) |
| Accounts payable |  |  | 24,818 |  |  |  | 5,629 |  |
| Accrued expenses and other liabilities |  |  | 3,803 |  |  |  | 3,317 |  |
| Income taxes payable, net |  |  | (1,304 | ) |  |  | 497 |  |
| Net cash provided by operating activities |  |  | 4,869 |  |  |  | 10,685 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (1,461 | ) |  |  | (741 | ) |
| Proceeds from sales and maturities of available-for-sale investments |  |  | 10,265 |  |  |  | 10,087 |  |
| Purchases of available-for-sale investments |  |  | (11,504 | ) |  |  | (11,350 | ) |
| Net cash used in investing activities |  |  | (2,700 | ) |  |  | (2,004 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |
| Tax withholdings related to stock-based compensation settlements |  |  | (54 | ) |  |  | (113 | ) |
| Proceeds from stock option exercises |  |  | 568 |  |  |  | 1,244 |  |
| Dividend payments |  |  | (4,438 | ) |  |  | (4,361 | ) |
| Proceeds from draw on line of credit |  |  | 8,000 |  |  |  | — |  |
| Repayment of line of credit |  |  | (8,000 | ) |  |  | — |  |
| Net cash used in financing activities |  |  | (3,924 | ) |  |  | (3,230 | ) |
| Net (decrease) increase in cash, cash equivalents and restricted cash |  |  | (1,755 | ) |  |  | 5,451 |  |
| Effect of exchange rate changes |  |  | (1,032 | ) |  |  | (1,734 | ) |
| Cash, cash equivalents and restricted cash, beginning of period |  |  | 56,818 |  |  |  | 60,179 |  |
| Cash, cash equivalents and restricted cash, end of period |  | $ | 54,031 |  |  | $ | 63,896 |  |
| Supplemental disclosure of non-cash investing activities: |  |  |  |  |  |  |
| Right-of-use assets obtained in exchange for lease obligations |  | $ | 332 |  |  | $ | 248 |  |
| Purchases of property, plant and equipment included in accounts payable |  | $ | 392 |  |  | $ | 199 |  |

[0000950170-22-007563:8k_2_02:32]
Supplemental Information

[0000950170-22-007563:8k_2_02:33]
Reconciliation of Operating Loss to Non-GAAP Operating Income

[0000950170-22-007563:8k_2_02:34]
(Unaudited)

[0000950170-22-007563:8k_2_02:35]
|  |  | Three Months Ended March 31, |  |  |
|  |  | 2022 |  |  | 2021 |  |  |
| Operating Loss |  | $ | (68 | ) |  | $ | (1,335 | ) |  |
| Acquisition-related expenses, amortizations and adjustments |  |  | 2,330 |  | (1) |  | 1,045 |  | (5) |
| Stock-based compensation expense |  |  | 1,893 |  | (2) |  | 1,807 |  | (6) |
| Restructuring expenses |  |  | 2 |  | (3) |  | 301 |  | (7) |
| Deferred compensation adjustments |  |  | (2,696 | ) | (4) |  | 556 |  | (4) |
| Non-GAAP Operating Income |  | $ | 1,461 |  |  | $ | 2,374 |  |  |

[0000950170-22-007563:8k_2_02:36]
(1) $1.8 million is included in selling, general and administrative expenses and $0.5 million is included in research and development expenses on the condensed consolidated statements of (loss) income.

[0000950170-22-007563:8k_2_02:37]
(2) $0.2 million is included in total cost of revenue, $1.1 million is included in selling, general and administrative expenses and $0.6 million is included in research and development expenses on the condensed consolidated statements of (loss) income.

[0000950170-22-007563:8k_2_02:38]
(3) Less than $0.1 million is included in selling, general and administrative expenses on the condensed consolidated statements of (loss) income.

[0000950170-22-007563:8k_2_02:39]
(4) Includes non-cash change in fair value of equity investments held in the ADTRAN, Inc. Deferred Compensation Program for Employees, all of which is included in selling, general and administrative expenses on the condensed consolidated statement of (loss) income.

[0000950170-22-007563:8k_2_02:40]
(5) $0.6 million is included in selling, general and administrative expenses and $0.5 million is included in research and development expenses on the condensed consolidated statements of (loss) income.

[0000950170-22-007563:8k_2_02:41]
(6) $0.1 million is included in total cost of revenue, $1.1 million is included in selling, general and administrative expenses and $0.6 million is included in research and development expenses on the condensed consolidated statements of (loss) income.

[0000950170-22-007563:8k_2_02:42]
(7) $0.1 million is included in selling, general and administrative expenses and $0.2 million is included in research and development expenses on the condensed consolidated statements of (loss) income.

[0000950170-22-007563:8k_2_02:43]
Supplemental Information

[0000950170-22-007563:8k_2_02:44]
Reconciliation of Net (Loss) Income and (Loss) Earnings per Common Share – Basic and Diluted to

[0000950170-22-007563:8k_2_02:45]
Non-GAAP Net Income and Non-GAAP Earnings per Common Share – Basic and Diluted

[0000950170-22-007563:8k_2_02:46]
(Unaudited)

[0000950170-22-007563:8k_2_02:47]
|  |  | Three Months Ended March 31, |  |
|  |  | 2022 |  |  | 2021 |  |
| Net (Loss) Income |  | $ | (1,127 | ) |  | $ | 896 |  |
| Acquisition-related expenses, amortizations and adjustments |  |  | 2,330 |  |  |  | 1,045 |  |
| Stock-based compensation expense |  |  | 1,893 |  |  |  | 1,807 |  |
| Restructuring expenses |  |  | 2 |  |  |  | 301 |  |
| Deferred compensation adjustments(1) |  |  | (855 | ) |  |  | 268 |  |
| Pension expense(2) |  |  | 89 |  |  |  | 278 |  |
| Valuation allowance related to deferred tax assets |  |  | 8,079 |  |  |  | 2,685 |  |
| Tax effect of adjustments to net (loss) income |  |  | (505 | ) |  |  | (952 | ) |
| Non-GAAP Net Income |  | $ | 9,906 |  |  | $ | 6,328 |  |
| Weighted average shares outstanding – basic |  |  | 49,113 |  |  |  | 48,336 |  |
| Weighted average shares outstanding – diluted |  |  | 49,113 |  |  |  | 49,004 |  |
| (Loss) earnings per common share - basic |  | $ | (0.02 | ) |  | $ | 0.02 |  |
| (Loss) earnings per common share - diluted |  | $ | (0.02 | ) |  | $ | 0.02 |  |
| Non-GAAP earnings per common share - basic |  | $ | 0.20 |  |  | $ | 0.13 |  |
| Non-GAAP earnings per common share - diluted |  | $ | 0.20 |  |  | $ | 0.13 |  |

[0000950170-22-007563:8k_2_02:48]
(1) Includes non-cash change in fair value of equity investments held in deferred compensation plans offered to certain employees.

[0000950170-22-007563:8k_2_02:49]
(2) Includes amortization of actuarial losses related to the Company's pension plan for employees in certain foreign countries.
