# ADTN notes — 0000950170-22-008077


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000950170-22-008077:notes:1]
[same as prior period, unchanged from 0000950170-21-003219:notes:1]

[0000950170-22-008077:notes:2]
[same as prior period, unchanged from 0000950170-21-003219:notes:2]

[0000950170-22-008077:notes:3]
The accompanying unaudited condensed consolidated financial statements of ADTRAN®, Inc. and its subsidiaries (“ADTRAN”, the “Company”, “we”, “our” or “us”) have been prepared pursuant to the rules and regulations of the Securities and Exchange Commission (the “SEC”) applicable to interim financial information presented in Quarterly Reports on Form 10-Q. Accordingly, certain information and notes required by generally accepted accounting principles in the United States of America (“U.S. GAAP”) for complete financial statements are not included herein. Certain prior year amounts have been reclassified to conform to the current period presentation. The December 31, 2021 Condensed Consolidated Balance Sheet is derived from audited financial statements but does not include all disclosures required by U.S. GAAP.

[0000950170-22-008077:notes:4]
In the opinion of management, all adjustments necessary to fairly state these interim statements have been recorded and are of a normal and recurring nature. The results of operations for an interim period are not necessarily indicative of the results for the full year. The interim financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in ADTRAN’s Annual Report on Form 10-K for the year ended December 31, 2021, filed with the SEC on February 25, 2022.

[0000950170-22-008077:notes:5]
[same as prior period, unchanged from 0000950170-21-003219:notes:5]

[0000950170-22-008077:notes:6]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenue and expense during the reporting period. Significant estimates include excess and obsolete inventory reserves, warranty reserves, customer rebates, determination and accrual of the deferred revenue related to performance obligations under contracts with customers, estimated costs to complete obligations associated with deferred and accrued revenues and network installations, estimated income tax provision and income tax contingencies, fair value of stock-based compensation, assessment of goodwill and other intangibles for impairment, estimated lives of intangible assets, estimated pension liability and fair value of investments. Actual amounts could differ significantly from these estimates.

[0000950170-22-008077:notes:7]
We assessed certain accounting matters that generally require consideration of forecasted financial information in context with the information reasonably available to us and the unknown future impacts of the SARS-CoV-2 coronavirus/COVID-19 global pandemic (or variants of the SARS-CoV-2 coronavirus) as well as supply chain constraints as of March 31, 2022 and through the date of this report. The accounting matters assessed included, but were not limited to, the allowance for credit losses, stock-based compensation, carrying value of goodwill, intangibles and other long-lived assets, financial assets, valuation allowances for tax assets, revenue recognition and costs of revenue. Future conditions related to the magnitude and duration of the COVID-19 pandemic, as well as other factors, including supply chain constraints, could result in further impacts to our consolidated financial statements in future reporting periods.

[0000950170-22-008077:notes:8]
Recently Adopted Accounting Pronouncements

[0000950170-22-008077:notes:9]
There are currently no recently adopted accounting pronouncements that had a material effect on the condensed consolidated financial statements.

[0000950170-22-008077:notes:10]
[same as prior period, unchanged from 0000950170-21-003219:notes:14]

[0000950170-22-008077:notes:11]
In October 2021, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update ("ASU") 2021-08, Business Combinations (Topic 805) Accounting for Contract Assets and Contract Liabilities from Contracts with Customers, which would require an acquirer to recognize and measure acquired contract assets and contract liabilities in a manner consistent with how the acquiree recognized and measured them in its pre-acquisition financial statements in accordance with Topic 606, Revenue Recognition. ASU 2021-08 is effective for annual periods beginning after December 15, 2022, including interim periods within those fiscal years. Adoption of the ASU should be applied prospectively. Early adoption is also permitted, including adoption in an interim period. If early adopted, the amendments are applied retrospectively to all business combinations for which the acquisition date occurred during the fiscal year of adoption. The Company plans to early adopt ASU 2021-08 in the event that the Business Combination Agreement with ADVA closes during 2022. However, we are unable to estimate the effect on our Condensed Consolidated Financial Statements as of the date of this report.


## us-gaap:CashAndCashEquivalentsDisclosureTextBlock

[0000950170-22-008077:notes:12]
[same as prior period, unchanged from 0000950170-21-003219:notes:15]

[0000950170-22-008077:notes:13]
[same as prior period, unchanged from 0000950170-21-003219:notes:16]

[0000950170-22-008077:notes:14]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | March 31, 2022 |  |  | December 31, 2021 |  |
| Cash and cash equivalents |  | $ | 53,979 |  |  | $ | 56,603 |  |
| Restricted cash |  |  | 52 |  |  |  | 215 |  |
| Cash, cash equivalents and restricted cash |  | $ | 54,031 |  |  | $ | 56,818 |  |

[0000950170-22-008077:notes:15]
See Note 17 for additional information regarding restricted cash.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000950170-22-008077:notes:16]
[same as prior period, unchanged from 0000950170-21-003219:notes:19]

[0000950170-22-008077:notes:17]
[same as prior period, unchanged from 0000950170-21-003219:notes:20]

[0000950170-22-008077:notes:18]
[same as prior period, unchanged from 0000950170-21-003219:notes:21]

[0000950170-22-008077:notes:19]
[same as prior period, unchanged from 0000950170-21-003219:notes:22]

[0000950170-22-008077:notes:20]
[same as prior period, unchanged from 0000950170-21-003219:notes:23]

[0000950170-22-008077:notes:21]
[same as prior period, unchanged from 0000950170-21-003219:notes:24]

[0000950170-22-008077:notes:22]
[same as prior period, unchanged from 0000950170-21-003219:notes:25]

[0000950170-22-008077:notes:23]
|  |  | Three Months Ended |  |
|  |  | March 31, 2022 |  |  | March 31, 2021 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 84,289 |  |  | $ | 11,171 |  |  | $ | 95,460 |  |  | $ | 60,053 |  |  | $ | 9,021 |  |  | $ | 69,074 |  |
| Subscriber Solutions & Experience |  |  | 51,823 |  |  |  | 2,783 |  |  |  | 54,606 |  |  |  | 52,269 |  |  |  | 2,300 |  |  |  | 54,569 |  |
| Traditional & Other Products |  |  | 2,262 |  |  |  | 2,190 |  |  |  | 4,452 |  |  |  | 1,487 |  |  |  | 2,403 |  |  |  | 3,890 |  |
| Total |  | $ | 138,374 |  |  | $ | 16,144 |  |  | $ | 154,518 |  |  | $ | 113,809 |  |  | $ | 13,724 |  |  | $ | 127,533 |  |

[0000950170-22-008077:notes:24]
The aggregate amount of transaction price allocated to remaining performance obligations that have not been satisfied as of March 31, 2022 and December 31, 2021 related to contractual maintenance agreements, contractual SaaS and subscription services, and hardware contracts that exceed one year in duration amounted to $133.1 million and $101.1 million, respectively. As of March 31, 2022, approximately 81.1% is expected to be recognized over the next 12 months and the remainder recognized thereafter. The majority of the Company's remaining performance obligations at March 31, 2022 are related to contracts or orders that have an original expected duration of one year or less, for which the Company is electing to utilize the practical expedient available within the guidance, and are excluded from the transaction price related to these future obligations. The Company will generally satisfy the remaining performance obligations as we transfer control of the products ordered or services to our customers, excluding maintenance services, which are satisfied over time.

[0000950170-22-008077:notes:25]
[same as prior period, unchanged from 0000950170-21-003219:notes:29]

[0000950170-22-008077:notes:26]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | March 31, 2022 |  |  | December 31, 2021 |  |
| Accounts receivable, net |  | $ | 150,111 |  |  | $ | 158,742 |  |
| Contract assets(1) |  | $ | 8,243 |  |  | $ | 464 |  |
| Unearned revenue |  | $ | 19,454 |  |  | $ | 17,737 |  |
| Non-current unearned revenue |  | $ | 9,381 |  |  | $ | 9,271 |  |

[0000950170-22-008077:notes:27]
[same as prior period, unchanged from 0000950170-21-003219:notes:31]

[0000950170-22-008077:notes:28]
Of the outstanding unearned revenue balances as of December 31, 2021, $5.4 million was recognized as revenue during the three months ended March 31, 2022. Of the $14.1 million of outstanding unearned revenue balances as of December 31, 2020, $5.0 million was recognized as revenue during the three months ended March 31, 2021.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000950170-22-008077:notes:29]
[same as prior period, unchanged from 0000950170-21-003219:notes:35]

[0000950170-22-008077:notes:30]
Our effective tax rate decreased from an expense of 53.9% of pre-tax income for the three months ended March 31, 2021, to a benefit of 68.1% of pre-tax loss for the three months ended March 31, 2022. The change in the effective tax rate for the three months ended March 31, 2022, was driven primarily by a change in our annual estimated tax rate as a result of the requirement to begin capitalizing research and development expenses for U.S. tax purposes beginning in 2022 as previously passed as part of the Tax Cuts and Jobs Act in December 2017 and the associated impact of those changes on our previously established valuation allowance.

[0000950170-22-008077:notes:31]
The Company continually reviews the adequacy of its valuation allowance and recognizes the benefits of deferred tax assets only as the assessment indicates that it is more likely than not that the deferred tax assets will be recognized in accordance with ASC 740, Income Taxes. As of March 31, 2022, the Company had deferred tax assets totaling $67.6 million, and a valuation allowance totaling $58.7 million against those deferred tax assets. The remaining $8.9 million in deferred tax assets not offset by a valuation allowance are located in various foreign jurisdictions where the Company believes it is more likely than not we will realize these deferred tax assets. During the three months ended March 31, 2022, the total change in the valuation allowance against our domestic and international deferred tax assets was recorded in the amount of an $8.2 million increase and a $0.1 million decrease, respectively. Our assessment of the realizability of our deferred tax assets includes the evaluation of historical operating results as well as the evaluation of evidence which requires significant judgment, including the evaluation of our three-year cumulative income position, future taxable income projections and tax planning strategies. Should management’s conclusion change in the future and an additional valuation allowance or a partial or full release of the valuation allowance becomes necessary, it may have a material effect on our consolidated financial statements.

[0000950170-22-008077:notes:32]
[same as prior period, unchanged from 0000950170-21-003219:notes:40]

[0000950170-22-008077:notes:33]
|  |  | As of March 31, 2022 |  |
| (In thousands) |  | Deferred Tax Assets |  |  | Valuation Allowance |  |  | Deferred Tax Assets, net |  |
| Domestic |  | $ | 56,460 |  |  | $ | (56,460 | ) |  | $ | — |  |
| International |  |  | 11,121 |  |  |  | (2,182 | ) |  |  | 8,939 |  |
| Total |  | $ | 67,581 |  |  | $ | (58,642 | ) |  | $ | 8,939 |  |

[0000950170-22-008077:notes:34]
|  |  | As of December 31, 2021 |  |
| (In thousands) |  | Deferred Tax Assets |  |  | Valuation Allowance |  |  | Deferred Tax Assets, net |  |
| Domestic |  | $ | 48,265 |  |  | $ | (48,265 | ) |  | $ | — |  |
| International |  |  | 11,378 |  |  |  | (2,299 | ) |  |  | 9,079 |  |
| Total |  | $ | 59,643 |  |  | $ | (50,564 | ) |  | $ | 9,079 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000950170-22-008077:notes:35]
[same as prior period, unchanged from 0000950170-21-003219:notes:47]

[0000950170-22-008077:notes:36]
[same as prior period, unchanged from 0000950170-21-003219:notes:48]

[0000950170-22-008077:notes:37]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2022 |  |  | 2021 |  |
| Stock-based compensation expense included in cost of revenue |  | $ | 159 |  |  | $ | 131 |  |
| Selling, general and administrative expense |  |  | 1,124 |  |  |  | 1,098 |  |
| Research and development expense |  |  | 610 |  |  |  | 578 |  |
| Stock-based compensation expense included in operating expenses |  |  | 1,734 |  |  |  | 1,676 |  |
| Total stock-based compensation expense |  |  | 1,893 |  |  |  | 1,807 |  |
| Tax benefit for expense associated with stock options, PSUs, RSUs and restricted stock |  |  | (473 | ) |  |  | (431 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 1,420 |  |  | $ | 1,376 |  |

[0000950170-22-008077:notes:38]
[same as prior period, unchanged from 0000950170-21-003219:notes:50]

[0000950170-22-008077:notes:39]
The following table summarizes PSUs, RSUs and restricted stock outstanding as of December 31, 2021 and March 31, 2022 and the changes that occurred during the three months ended March 31, 2022:

[0000950170-22-008077:notes:40]
|  |  | Number of Shares(in thousands) |  |  | Weighted Avg. Grant Date Fair Value(per share) |  |
| Unvested PSUs, RSUs and restricted stock outstanding, December 31, 2021 |  |  | 1,930 |  |  | $ | 14.11 |  |
| PSUs, RSUs and restricted stock granted |  |  | 328 |  |  | $ | 20.21 |  |
| PSUs, RSUs and restricted stock vested |  |  | (10 | ) |  | $ | 12.36 |  |
| PSUs, RSUs and restricted stock forfeited |  |  | (28 | ) |  | $ | 13.72 |  |
| Unvested PSUs, RSUs and restricted stock outstanding, March 31, 2022 |  |  | 2,220 |  |  | $ | 15.03 |  |

[0000950170-22-008077:notes:41]
During each of the three months ended March 31, 2022 and 2021, the Company granted 0.3 million performance-based PSUs to its executive officers and certain employees. The grant-date fair value of these performance-based awards was based on the closing price of the Company’s stock on the date of grant. These awards vest over one-year, two-year and three-year periods, respectively, subject to the grantee’s continued employment, with the ability to earn shares in a range of 0% to 142.8% of the awarded number of PSUs based on the achievement of defined performance targets. Equity-based compensation expense with respect to these awards may be adjusted over the vesting period to reflect the probability of achievement of performance targets defined in the award agreements.

[0000950170-22-008077:notes:42]
[same as prior period, unchanged from 0000950170-21-003219:notes:54]

[0000950170-22-008077:notes:43]
As of March 31, 2022, total unrecognized compensation expense related to non-vested market-based PSUs, RSUs and restricted stock was approximately $15.9 million, which will be recognized over the remaining weighted-average period of 2.7 years. In addition, there was $13.2 million of unrecognized compensation expense related to unvested 2020, 2021 and 2022 performance-based PSUs, which will be recognized over the remaining requisite service period of 0.8 years if achievement of the performance obligation becomes probable. Unrecognized compensation expense will be adjusted for actual forfeitures.

[0000950170-22-008077:notes:44]
As of March 31, 2022, 3.8 million shares were available for issuance under stockholder-approved equity plans.

[0000950170-22-008077:notes:45]
[same as prior period, unchanged from 0000950170-21-003219:notes:57]

[0000950170-22-008077:notes:46]
The following table summarizes stock options outstanding as of December 31, 2021 and March 31, 2022 and the changes that occurred during the three months ended March 31, 2022:

[0000950170-22-008077:notes:47]
|  |  | Number of Stock Options(in thousands) |  |  | Weighted Avg. Exercise Price(per share) |  |  | Weighted Avg. Remaining Contractual Life(in years) |  |  | Aggregate Intrinsic Value(in thousands) |  |
| Stock options outstanding, December 31, 2021 |  |  | 1,721 |  |  | $ | 19.37 |  |  |  | 2.4 |  |  | $ | 6,669 |  |
| Stock options exercised |  |  | (33 | ) |  | $ | 17.27 |  |  |  |  |  | $ | 101 |  |
| Stock options expired |  |  | (9 | ) |  | $ | 23.18 |  |  |  |  |  | $ | 4 |  |
| Stock options outstanding, March 31, 2022 |  |  | 1,679 |  |  | $ | 19.39 |  |  |  | 2.2 |  |  | $ | 1,758 |  |
| Stock options exercisable, March 31, 2022 |  |  | 1,679 |  |  | $ | 19.39 |  |  |  | 2.2 |  |  | $ | 1,758 |  |

[0000950170-22-008077:notes:48]
As of March 31, 2022, there was no unrecognized compensation expense related to stock options as all awards vested in prior periods.

[0000950170-22-008077:notes:49]
There were no stock options granted during the three months ended March 31, 2022 and 2021. All of the options were previously issued at exercise prices that approximated fair market value at the date of grant.

[0000950170-22-008077:notes:50]
The aggregate intrinsic value of stock options represents the total pre-tax intrinsic value (the difference between ADTRAN’s closing stock price on the last trading day of the quarter and the exercise price, multiplied by the number of in-the-money options) that would have been received by the option holders had all option holders exercised their options on March 31, 2022. The amount of aggregate intrinsic value was $1.8 million as of March 31, 2022 and will change based on the fair market value of ADTRAN’s stock. The total pre-tax intrinsic value of options exercised during the three months ended March 31, 2022 was $0.1 million.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000950170-22-008077:notes:51]
6. INVESTMENTS

[0000950170-22-008077:notes:52]
Debt Securities and Other Investments

[0000950170-22-008077:notes:53]
The following debt securities and other investments were included on the Condensed Consolidated Balance Sheet and recorded at fair value:

[0000950170-22-008077:notes:54]
|  |  | As of March 31, 2022 |  |
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 9,299 |  |  | $ | 1 |  |  | $ | (206 | ) |  | $ | 9,094 |  |
| Municipal fixed-rate bonds |  |  | 1,684 |  |  |  | — |  |  |  | (37 | ) |  |  | 1,647 |  |
| Asset-backed bonds |  |  | 318 |  |  |  | — |  |  |  | (11 | ) |  |  | 307 |  |
| Mortgage/Agency-backed bonds |  |  | 4,703 |  |  |  | 1 |  |  |  | (142 | ) |  |  | 4,562 |  |
| U.S. government bonds |  |  | 14,000 |  |  |  | — |  |  |  | (446 | ) |  |  | 13,554 |  |
| Foreign government bonds |  |  | 411 |  |  |  | — |  |  |  | (17 | ) |  |  | 394 |  |
| Available-for-sale debt securities held at fair value |  | $ | 30,415 |  |  | $ | 2 |  |  | $ | (859 | ) |  | $ | 29,558 |  |

[0000950170-22-008077:notes:55]
|  |  | As of December 31, 2021 |  |
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 10,776 |  |  | $ | 6 |  |  | $ | (35 | ) |  | $ | 10,747 |  |
| Municipal fixed-rate bonds |  |  | 1,553 |  |  |  | 2 |  |  |  | (4 | ) |  |  | 1,551 |  |
| Asset-backed bonds |  |  | 322 |  |  |  | 3 |  |  |  | (3 | ) |  |  | 322 |  |
| Mortgage/Agency-backed bonds |  |  | 4,754 |  |  |  | 15 |  |  |  | (33 | ) |  |  | 4,736 |  |
| U.S. government bonds |  |  | 12,251 |  |  |  | 12 |  |  |  | (92 | ) |  |  | 12,171 |  |
| Foreign government bonds |  |  | 543 |  |  |  | — |  |  |  | (4 | ) |  |  | 539 |  |
| Available-for-sale debt securities held at fair value |  | $ | 30,199 |  |  | $ | 38 |  |  | $ | (171 | ) |  | $ | 30,066 |  |

[0000950170-22-008077:notes:56]
The contractual maturities related to debt securities and other investments were as follows:

[0000950170-22-008077:notes:57]
|  |  | As of March 31, 2022 |
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset-backed bonds |  |  | Mortgage/ Agency-backed bonds |  |  | U.S. government bonds |  |  | Foreign government bonds |  |  |
| Less than one year |  | $ | 295 |  |  | $ | 269 |  |  | $ | — |  |  | $ | 1,050 |  |  | $ | 979 |  |  | $ | — |  |  |
| One to two years |  |  | 5,965 |  |  |  | 1,265 |  |  |  | — |  |  |  | 479 |  |  |  | 4,800 |  |  |  | — |  |  |
| Two to three years |  |  | 2,596 |  |  |  | 113 |  |  |  | — |  |  |  | 289 |  |  |  | 7,106 |  |  |  | 394 |  |  |
| Three to five years |  |  | 238 |  |  |  | — |  |  |  | 49 |  |  |  | 371 |  |  |  | 669 |  |  |  | — |  |  |
| Five to ten years |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 915 |  |  |  | — |  |  |  | — |  |  |
| More than ten years |  |  | — |  |  |  | — |  |  |  | 258 |  |  |  | 1,458 |  |  |  | — |  |  |  | — |  |  |
| Total |  | $ | 9,094 |  |  | $ | 1,647 |  |  | $ | 307 |  |  | $ | 4,562 |  |  | $ | 13,554 |  |  | $ | 394 |  |  |

[0000950170-22-008077:notes:58]
Actual maturities may differ from contractual maturities as some borrowers have the right to call or prepay obligations with or without call or prepayment penalties.

[0000950170-22-008077:notes:59]
Realized gains and losses on sales of debt securities are computed under the specific identification method. The following table presents the gross realized gains and losses related to our debt securities:

[0000950170-22-008077:notes:60]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2022 |  |  | 2021 |  |
| Gross realized gain on debt securities |  | $ | 12 |  |  | $ | 87 |  |
| Gross realized loss on debt securities |  |  | (40 | ) |  |  | (16 | ) |
| Total (loss) gain recognized, net |  | $ | (28 | ) |  | $ | 71 |  |

[0000950170-22-008077:notes:61]
Income generated from available-for-sale debt securities was recorded as interest and dividend income in the Condensed Consolidated Statements of (Loss) Income. No allowance for credit losses was recorded for the three months ended March 31, 2022 and 2021 related to available-for-sale debt securities. The Company’s investment policy provides limitations for issuer concentration, which limits, at the time of purchase, the concentration in any one issuer to 5% of the market value of our total investment portfolio. The Company did not purchase any available-for-sale debt security with credit deterioration during the three months ended March 31, 2022.

[0000950170-22-008077:notes:62]
Marketable Equity Securities

[0000950170-22-008077:notes:63]
Our marketable equity securities consist of publicly traded stock, interests in funds and certain other investments measured at fair value or cost (where appropriate).

[0000950170-22-008077:notes:64]
The Company has an equity investment which does not have a readily determinable fair value, and is recorded using the measurement alternative. Under the measurement alternative, equity investments that do not have a readily determinable fair value can be recorded at cost less impairment, if any, adjusted for observable price changes for an identical or similar investment. The carrying value of the equity investment as of March 31, 2022 and December 31, 2021 was $1.0 million. During the year ended December 31, 2021, impairment charges totaling $0.4 million, were recorded related to the equity investment. As of March 31 2022, cumulative impairment charges totaling $2.4 million were recorded related to the equity investment. There were no impairment charges during the three months ended March 31, 2022 and 2021. During the year ended December 31, 2021, an unsecured loan totaling $0.5 million was converted to equity which increased the Company's carrying value of the equity investment.

[0000950170-22-008077:notes:65]
The Company has a secured note receivable as of March 31, 2022 and December 31, 2021 which totaled $0.4 million and is included in long term investments on the Consolidated Balance Sheets. During the year ended December 31, 2021, an impairment charge of $0.5 million was recognized against the secured note receivable. There were no impairment charges during the three months ended March 31, 2022 and 2021.

[0000950170-22-008077:notes:66]
Realized and unrealized gains and losses related to marketable equity securities were as follows:

[0000950170-22-008077:notes:67]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2022 |  |  | 2021 |  |
| Realized (loss) gain on equity securities sold |  | $ | (25 | ) |  | $ | 24 |  |
| Unrealized (loss) gain on equity securities held |  |  | (3,362 | ) |  |  | 901 |  |
| Total (loss) gain recognized, net |  | $ | (3,387 | ) |  | $ | 925 |  |

[0000950170-22-008077:notes:68]
Income generated from marketable equity securities was recorded as interest and dividend income in the Condensed Consolidated Statements of (Loss) Income. U.S. GAAP establishes a three-level valuation hierarchy based upon observable and unobservable inputs for fair value measurement of financial instruments:

[0000950170-22-008077:notes:69]
 Level 1 – Observable outputs; values based on unadjusted quoted prices for identical assets or liabilities in an active market;

[0000950170-22-008077:notes:70]
 Level 2 – Significant inputs that are observable; values based on quoted prices in markets that are not active or model inputs that are observable either directly or indirectly;

[0000950170-22-008077:notes:71]
 Level 3 – Significant unobservable inputs; values based on prices or valuation techniques that require inputs that are both unobservable and significant to the overall fair value measurement. These inputs could include information supplied by investees.

[0000950170-22-008077:notes:72]
The Company’s cash equivalents and investments held at fair value are categorized into this hierarchy as follows:

[0000950170-22-008077:notes:73]
|  |  |  |  |  | Fair Value Measurements as of March 31, 2022 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket for IdenticalAssets (Level 1) |  |  | SignificantOtherObservableInputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 457 |  |  | $ | 457 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 9,094 |  |  |  | — |  |  |  | 9,094 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 1,647 |  |  |  | — |  |  |  | 1,647 |  |  |  | — |  |
| Asset-backed bonds |  |  | 307 |  |  |  | — |  |  |  | 307 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 4,562 |  |  |  | — |  |  |  | 4,562 |  |  |  | — |  |
| U.S. government bonds |  |  | 13,554 |  |  |  | 13,554 |  |  |  |  |  |  | — |  |
| Foreign government securities |  |  | 394 |  |  |  | — |  |  |  | 394 |  |  |  | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 11,143 |  |  |  | 11,143 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 26,081 |  |  |  | 26,081 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 67,239 |  |  | $ | 51,235 |  |  | $ | 16,004 |  |  | $ | — |  |

[0000950170-22-008077:notes:74]
|  |  |  |  |  | Fair Value Measurements as of December 31, 2021 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket for IdenticalAssets (Level 1) |  |  | SignificantOtherObservableInputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 652 |  |  | $ | 652 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 10,747 |  |  |  | — |  |  |  | 10,747 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 1,551 |  |  |  | — |  |  |  | 1,551 |  |  |  | — |  |
| Asset-backed bonds |  |  | 322 |  |  |  | — |  |  |  | 322 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 4,736 |  |  |  | — |  |  |  | 4,736 |  |  |  | — |  |
| U.S. government bonds |  |  | 12,171 |  |  |  | 12,171 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 539 |  |  |  | — |  |  |  | 539 |  |  |  | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 12,606 |  |  |  | 12,606 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 26,935 |  |  |  | 26,935 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 70,259 |  |  | $ | 52,364 |  |  | $ | 17,895 |  |  | $ | — |  |

[0000950170-22-008077:notes:75]
The fair value of our Level 2 securities is calculated using a weighted average market price for each security. Market prices are obtained from a variety of industry standard data providers, large financial institutions and other third-party sources. These multiple market prices are used as inputs into a distribution-curve-based algorithm to determine the daily market value of each security.

[0000950170-22-008077:notes:76]
The fair value of Level 3 securities is calculated based on unobservable inputs. Quantitative information with respect to unobservable inputs consists of third-party valuations performed in accordance with ASC 820 – Fair Value Measurement. Inputs used in preparing the third-party valuation included the following assumptions, among others: estimated discount rates and fair market yields.


## us-gaap:InventoryDisclosureTextBlock

[0000950170-22-008077:notes:77]
[same as prior period, unchanged from 0000950170-21-003219:notes:88]

[0000950170-22-008077:notes:78]
[same as prior period, unchanged from 0000950170-21-003219:notes:89]

[0000950170-22-008077:notes:79]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | March 31, 2022 |  |  | December 31, 2021 |  |
| Raw materials |  | $ | 100,644 |  |  | $ | 74,709 |  |
| Work in process |  |  | 2,232 |  |  |  | 2,143 |  |
| Finished goods |  |  | 68,245 |  |  |  | 63,039 |  |
| Total inventory, net |  | $ | 171,121 |  |  | $ | 139,891 |  |

[0000950170-22-008077:notes:80]
Inventory reserves are established for estimated excess and obsolete inventory equal to the difference between the cost of the inventory and the estimated net realizable value of the inventory based on estimated reserve percentages, which considers historical usage, known trends, inventory age and market conditions. As of March 31, 2022 and December 31, 2021, inventory reserves were $46.3 million and $44.6 million, respectively.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000950170-22-008077:notes:81]
[same as prior period, unchanged from 0000950170-21-003219:notes:92]

[0000950170-22-008077:notes:82]
[same as prior period, unchanged from 0000950170-21-003219:notes:93]

[0000950170-22-008077:notes:83]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | March 31, 2022 |  |  | December 31, 2021 |  |
| Land |  | $ | 4,575 |  |  | $ | 4,575 |  |
| Building and land improvements |  |  | 35,667 |  |  |  | 35,578 |  |
| Building |  |  | 68,161 |  |  |  | 68,157 |  |
| Furniture and fixtures |  |  | 19,956 |  |  |  | 19,917 |  |
| Computer hardware and software |  |  | 73,440 |  |  |  | 72,274 |  |
| Engineering and other equipment |  |  | 134,438 |  |  |  | 134,771 |  |
| Total property, plant and equipment |  |  | 336,237 |  |  |  | 335,272 |  |
| Less: accumulated depreciation |  |  | (281,853 | ) |  |  | (279,506 | ) |
| Total property, plant and equipment, net |  | $ | 54,384 |  |  | $ | 55,766 |  |

[0000950170-22-008077:notes:84]
Long-lived assets used in operations are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable and the undiscounted cash flows estimated to be generated by the asset are less than the asset’s carrying value. No impairment charges were recognized during the three months ended March 31, 2022 and 2021.

[0000950170-22-008077:notes:85]
Depreciation expense was $2.8 million and $3.1 million for the three months ended March 31, 2022 and 2021 respectively, which is recorded in cost of revenue, selling, general and administrative expenses and research and development expenses in the Condensed Consolidated Statements of (Loss) Income.


## us-gaap:GoodwillDisclosureTextBlock

[0000950170-22-008077:notes:86]
[same as prior period, unchanged from 0000950170-21-003219:notes:97]

[0000950170-22-008077:notes:87]
Goodwill was $7.0 million as of March 31, 2022 and December 31, 2021, of which $6.6 million and $0.4 million was allocated to our Network Solutions and Services & Support reportable segments, respectively.

[0000950170-22-008077:notes:88]
Goodwill represents the excess purchase price over the fair value of net assets acquired. We qualitatively assess the carrying value of goodwill each reporting period for events or circumstance changes that would more likely than not reduce the fair value of the reporting unit below its carrying amount. Based on our assessment of certain qualitative factors such as macro-economic conditions, industry and market considerations, costs factors and overall financial performance, management concluded that no such events or circumstance changes were identified that would suggest that the fair value of the goodwill was more likely than not greater than its carrying amount as of March 31, 2022. No impairment of goodwill was recorded during the three months ended March 31, 2022 and 2021.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0000950170-22-008077:notes:89]
[same as prior period, unchanged from 0000950170-21-003219:notes:100]

[0000950170-22-008077:notes:90]
[same as prior period, unchanged from 0000950170-21-003219:notes:101]

[0000950170-22-008077:notes:91]
|  |  | As of March 31, 2022 |  |  | As of December 31, 2021 |  |
| (In thousands) |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Net Book Value |  |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Net Book Value |  |
| Customer relationships |  | $ | 20,677 |  |  | $ | (10,192 | ) |  | $ | 10,485 |  |  | $ | 20,796 |  |  | $ | (9,906 | ) |  | $ | 10,890 |  |
| Developed technology |  |  | 8,200 |  |  |  | (3,967 | ) |  |  | 4,233 |  |  |  | 8,200 |  |  |  | (3,683 | ) |  |  | 4,517 |  |
| Licensed technology |  |  | 5,900 |  |  |  | (2,650 | ) |  |  | 3,250 |  |  |  | 5,900 |  |  |  | (2,486 | ) |  |  | 3,414 |  |
| Licensing agreements |  |  | 560 |  |  |  | (243 | ) |  |  | 317 |  |  |  | 560 |  |  |  | (225 | ) |  |  | 335 |  |
| Patents |  |  | 500 |  |  |  | (380 | ) |  |  | 120 |  |  |  | 500 |  |  |  | (363 | ) |  |  | 137 |  |
| Trade names |  |  | 210 |  |  |  | (210 | ) |  |  | — |  |  |  | 210 |  |  |  | (210 | ) |  |  | — |  |
| Total |  | $ | 36,047 |  |  | $ | (17,642 | ) |  | $ | 18,405 |  |  | $ | 36,166 |  |  | $ | (16,873 | ) |  | $ | 19,293 |  |

[0000950170-22-008077:notes:92]
The Company evaluates the carrying value of intangible assets whenever events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable and the undiscounted cash flows estimated to be generated by the asset are less than the asset’s carrying value. Due to the current economic environment, particularly related to COVID-19, the Company assessed impairment

[0000950170-22-008077:notes:93]
triggers related to intangible assets during the first quarters of 2022 and 2021. As a result, no impairment test of long-lived assets was performed as of March 31, 2022 and 2021, and no impairment losses of intangible assets were recorded during the three months ended March 31, 2022 and 2021.

[0000950170-22-008077:notes:94]
Amortization expense was $0.9 million and $1.0 million in each of the three months ended March 31, 2022 and 2021, respectively, and was included in cost of revenue, selling, general and administrative expenses and research and development expenses in the Condensed Consolidated Statements of (Loss) Income.

[0000950170-22-008077:notes:95]
[same as prior period, unchanged from 0000950170-21-003219:notes:105]

[0000950170-22-008077:notes:96]
|  |  | As of |  |
| (In thousands) |  | March 31, 2022 |  |
| 2022 |  | $ | 2,601 |  |
| 2023 |  |  | 3,316 |  |
| 2024 |  |  | 3,224 |  |
| 2025 |  |  | 3,023 |  |
| 2026 |  |  | 1,986 |  |
| Thereafter |  |  | 4,255 |  |
| Total |  | $ | 18,405 |  |


## us-gaap:LessorSalesTypeLeasesTextBlock

[0000950170-22-008077:notes:97]
[same as prior period, unchanged from 0000950170-21-003219:notes:107]

[0000950170-22-008077:notes:98]
[same as prior period, unchanged from 0000950170-21-003219:notes:108]

[0000950170-22-008077:notes:99]
[same as prior period, unchanged from 0000950170-21-003219:notes:109]

[0000950170-22-008077:notes:100]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | March 31, 2022 |  |  | December 31, 2021 |  |
| Current minimum lease payments receivable(1) |  | $ | 66 |  |  | $ | 92 |  |
| Non-current minimum lease payments receivable(2) |  |  | 1 |  |  |  | 4 |  |
| Total minimum lease payments receivable |  |  | 67 |  |  |  | 96 |  |
| Less: Current unearned revenue(1) |  |  | 50 |  |  |  | 70 |  |
| Less: Non-current unearned revenue(2) |  |  | — |  |  |  | 1 |  |
| Net investment in sales-type leases |  | $ | 17 |  |  | $ | 25 |  |

[0000950170-22-008077:notes:101]
[same as prior period, unchanged from 0000950170-21-003219:notes:111]

[0000950170-22-008077:notes:102]
[same as prior period, unchanged from 0000950170-21-003219:notes:112]


## us-gaap:DebtDisclosureTextBlock

[0000950170-22-008077:notes:103]
12. CADENCE REVOLVING CREDIT AGREEMENT

[0000950170-22-008077:notes:104]
On November 2, 2021, the Company, as borrower, renewed its Revolving Credit and Security Agreement and related Promissory Note (together, the “Cadence Revolving Credit Agreement”) with Cadence Bank, N.A., as lender (the “Cadence Lender”). The Cadence Revolving Credit Agreement provides the Company with a $10.0 million secured revolving credit facility. Loans under the Cadence Revolving Credit Agreement will bear interest at a rate equal to 1.50% over the screen rate as obtained by Reuter’s, Bloomberg or another commercially available source as may be designated by the Cadence Lender from time to time; provided, however, that in no event shall the applicable rate of interest under the Cadence Revolving Credit Agreement be less than 1.50% per annum. Such loans are secured by all of the cash, securities, securities entitlements and investment property in a certain bank account, as outlined in the Cadence Revolving Credit Agreement, at a maximum loan-to-value ratio of 75% determined by dividing the full commitment amount under the Cadence Revolving Credit Agreement on the date of testing, determined by the Cadence Lender each fiscal quarter, by the market value of the collateral. The Cadence Revolving Credit Agreement matures on November 3, 2022, subject to earlier termination upon the concurrence of certain events of default. The Company entered into the Cadence Revolving Credit Agreement in order to increase the flexibility and management of its short-term liquidity. During the first quarter of 2022, the Company made draws totaling $8.0 million under the Cadence Revolving Credit Agreement all of which had been repaid as of March 31, 2022. The Company agreed to certain negative covenants that are customary for credit arrangements of this type, including, among other things, restrictions on the Company’s ability to enter into mergers, acquisitions or other business combination transactions, grant liens or suffer a material adverse change in the condition or affairs (financial or otherwise) of the Company. As of March 31, 2022, the Company was in compliance with all contractual requirements under the Cadence Revolving Credit Agreement.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000950170-22-008077:notes:105]
13. STOCKHOLDERS’ EQUITY

[0000950170-22-008077:notes:106]
[same as prior period, unchanged from 0000950170-21-003219:notes:118]

[0000950170-22-008077:notes:107]
Since 1997, the Company’s Board of Directors has approved multiple share repurchase programs that have authorized repurchases of the Company's common stock, which are implemented through open market or private purchases from time to time as conditions warrant. During the three months ended March 31, 2022, we did not repurchase any shares of our common stock. As of March 31, 2022, we had the authority to purchase an additional 2.5 million shares of our common stock under the current authorization of up to 5.0 million shares.

[0000950170-22-008077:notes:108]
Accumulated Other Comprehensive (Loss) Income

[0000950170-22-008077:notes:109]
The following tables present the changes in accumulated other comprehensive (loss) income, net of tax, by component:

[0000950170-22-008077:notes:110]
|  |  | Three Months Ended March 31, 2022 |  |
| (In thousands) |  | Unrealized(Losses) GainsonAvailable-for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | ASU 2018-02 Adoption |  |  | Total |  |
| Balance as of December 31, 2021 |  | $ | (552 | ) |  | $ | (5,613 | ) |  | $ | (6,134 | ) |  | $ | 385 |  |  | $ | (11,914 | ) |
| Other comprehensive loss before reclassifications |  |  | (975 | ) |  |  | — |  |  |  | (905 | ) |  |  | — |  |  |  | (1,880 | ) |
| Amounts reclassified from accumulated other comprehensive income (loss) |  |  | 251 |  |  |  | (13 | ) |  |  | — |  |  |  | — |  |  |  | 238 |  |
| Balance as of March 31, 2022 |  | $ | (1,276 | ) |  | $ | (5,626 | ) |  | $ | (7,039 | ) |  | $ | 385 |  |  | $ | (13,556 | ) |

[0000950170-22-008077:notes:111]
|  |  | Three Months Ended March 31, 2021 |  |
| (In thousands) |  | UnrealizedGains(Losses)onAvailable-for-Sale Securities |  |  | DefinedBenefit Plan Adjustments |  |  | ForeignCurrency Adjustments |  |  | ASU 2018-02 Adoption |  |  | Total |  |
| Balance as of December 31, 2020 |  | $ | 32 |  |  | $ | (9,621 | ) |  | $ | (2,435 | ) |  | $ | 385 |  |  | $ | (11,639 | ) |
| Other comprehensive loss before reclassifications |  |  | (57 | ) |  |  | — |  |  |  | (1,863 | ) |  |  | — |  |  |  | (1,920 | ) |
| Amounts reclassified from accumulated other comprehensive (loss) income |  |  | (135 | ) |  |  | 99 |  |  |  | — |  |  |  | — |  |  |  | (36 | ) |
| Balance as of March 31, 2021 |  | $ | (160 | ) |  | $ | (9,522 | ) |  | $ | (4,298 | ) |  | $ | 385 |  |  | $ | (13,595 | ) |

[0000950170-22-008077:notes:112]
The following tables present the details of reclassifications out of accumulated other comprehensive loss:

[0000950170-22-008077:notes:113]
|  |  | Three Months Ended March 31, 2022 |
| (In thousands) |  | Amount ReclassifiedfromAccumulated Other Comprehensive (Loss) Income |  |  | Affected Line Item in theStatement Where Net(Loss) Income Is Presented |
| Unrealized gain (loss) on available-for-sale securities: |  |  |  |  |  |
| Net realized loss on sales of securities |  | $ | (330 | ) |  | Net investment gain (loss) |
| Defined benefit plan adjustments – actuarial gain |  |  | 19 |  |  | (1) |
| Total reclassifications for the period, before tax |  |  | (311 | ) |  |  |
| Tax benefit |  |  | 73 |  |  |  |
| Total reclassifications for the period, net of tax |  | $ | (238 | ) |  |  |

[0000950170-22-008077:notes:114]
(1)
A part of the computation of net periodic pension cost, which is included in other (expense) income, net in the Condensed Consolidated Statements of (Loss) Income.

[0000950170-22-008077:notes:115]
|  |  | Three Months Ended March 31, 2021 |
| (In thousands) |  | Amount ReclassifiedfromAccumulated Other Comprehensive (Loss) Income |  |  | Affected Line Item in the Statement Where Net (Loss) Income Is Presented |
| Unrealized gain (loss) on available-for-sale securities: |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 178 |  |  | Net investment gain (loss) |
| Defined benefit plan adjustments – actuarial losses |  |  | (143 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | 35 |  |  |  |
| Tax benefit |  |  | 1 |  |  |  |
| Total reclassifications for the period, net of tax |  | $ | 36 |  |  |  |

[0000950170-22-008077:notes:116]
The following tables present the tax effects related to the change in each component of other comprehensive (loss) income:

[0000950170-22-008077:notes:117]
|  |  | Three Months Ended |  |  | Three Months Ended |  |
|  |  | March 31, 2022 |  |  | March 31, 2021 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense)Benefit |  |  | Net-of-Tax Amount |  |  | Before-Tax Amount |  |  | Tax(Expense)Benefit |  |  | Net-of-TaxAmount |  |
| Unrealized loss on available-for-sale securities |  | $ | (1,283 | ) |  | $ | 308 |  |  | $ | (975 | ) |  | $ | (75 | ) |  | $ | 18 |  |  | $ | (57 | ) |
| Reclassification adjustment for amounts related to available-for-sale investments included in net (loss) income |  |  | 330 |  |  |  | (79 | ) |  |  | 251 |  |  |  | (178 | ) |  |  | 43 |  |  |  | (135 | ) |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net (loss) income |  |  | (19 | ) |  |  | 6 |  |  |  | (13 | ) |  |  | 143 |  |  |  | (44 | ) |  |  | 99 |  |
| Foreign currency translation adjustment |  |  | (905 | ) |  |  | — |  |  |  | (905 | ) |  |  | (1,863 | ) |  |  | — |  |  |  | (1,863 | ) |
| Total Other Comprehensive (Loss) Income |  | $ | (1,877 | ) |  | $ | 235 |  |  | $ | (1,642 | ) |  | $ | (1,973 | ) |  | $ | 17 |  |  | $ | (1,956 | ) |


## us-gaap:EarningsPerShareTextBlock

[0000950170-22-008077:notes:118]
14. (LOSS) EARNINGS PER SHARE

[0000950170-22-008077:notes:119]
The calculation of basic and diluted (loss) earnings per share is as follows:

[0000950170-22-008077:notes:120]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands, except per share amounts) |  | 2022 |  |  | 2021 |  |
| Numerator |  |  |  |  |  |  |
| Net (loss) income |  | $ | (1,127 | ) |  | $ | 896 |  |
| Denominator |  |  |  |  |  |  |
| Weighted average number of shares – basic |  |  | 49,113 |  |  |  | 48,336 |  |
| Effect of dilutive securities |  |  |  |  |  |  |
| Stock options |  |  | — |  |  | 56 |  |
| PSUs, RSUs and restricted stock |  |  | — |  |  |  | 612 |  |
| Weighted average number of shares – diluted |  |  | 49,113 |  |  |  | 49,004 |  |
| (Loss) earnings per share – basic |  | $ | (0.02 | ) |  | $ | 0.02 |  |
| (Loss) earnings per share – diluted |  | $ | (0.02 | ) |  | $ | 0.02 |  |

[0000950170-22-008077:notes:121]
For the three months ended March 31, 2022 and 2021, five thousand and one thousand shares, respectively, of unvested PSUs, RSUs and restricted stock were excluded from the calculation of diluted earnings per share due to their anti-dilutive effect.

[0000950170-22-008077:notes:122]
For the three months ended March 31, 2022 and 2021, 0.1 million and 0.7 million stock options, respectively, were outstanding but were not included in the computation of diluted earnings per share. These stock options were excluded because their exercise prices were greater than the average market price of the common shares during the applicable period, making them anti-dilutive under the treasury stock method.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000950170-22-008077:notes:123]
15. SEGMENT INFORMATION

[0000950170-22-008077:notes:124]
[same as prior period, unchanged from 0000950170-21-003219:notes:141]

[0000950170-22-008077:notes:125]
[same as prior period, unchanged from 0000950170-21-003219:notes:142]

[0000950170-22-008077:notes:126]
The following table presents information about the revenue and gross profit of our reportable segments:

[0000950170-22-008077:notes:127]
|  |  | Three Months Ended |  |
|  |  | March 31, 2022 |  |  | March 31, 2021 |  |
| (In thousands) |  | Revenue |  |  | Gross Profit |  |  | Revenue |  |  | Gross Profit |  |
| Network Solutions |  | $ | 138,374 |  |  | $ | 47,721 |  |  | $ | 113,809 |  |  | $ | 48,808 |  |
| Services & Support |  |  | 16,144 |  |  |  | 6,595 |  |  |  | 13,724 |  |  |  | 4,793 |  |
| Total |  | $ | 154,518 |  |  | $ | 54,316 |  |  | $ | 127,533 |  |  | $ | 53,601 |  |

[0000950170-22-008077:notes:128]
The table below presents revenue information by category:

[0000950170-22-008077:notes:129]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2022 |  |  | 2021 |  |
| Access & Aggregation |  | $ | 95,460 |  |  | $ | 69,074 |  |
| Subscriber Solutions & Experience |  |  | 54,606 |  |  |  | 54,569 |  |
| Traditional & Other Products |  |  | 4,452 |  |  |  | 3,890 |  |
| Total |  | $ | 154,518 |  |  | $ | 127,533 |  |

[0000950170-22-008077:notes:130]
[same as prior period, unchanged from 0000950170-21-003219:notes:146]

[0000950170-22-008077:notes:131]
[same as prior period, unchanged from 0000950170-21-003219:notes:147]

[0000950170-22-008077:notes:132]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2022 |  |  | 2021 |  |
| United States |  | $ | 99,048 |  |  | $ | 86,485 |  |
| United Kingdom |  |  | 30,388 |  |  |  | 8,042 |  |
| Germany |  |  | 10,920 |  |  |  | 14,374 |  |
| Other international |  |  | 14,162 |  |  |  | 18,632 |  |
| Total |  | $ | 154,518 |  |  | $ | 127,533 |  |


## us-gaap:ProductWarrantyDisclosureTextBlock

[0000950170-22-008077:notes:133]
16. LIABILITY FOR WARRANTY RETURNS

[0000950170-22-008077:notes:134]
Our products generally include warranties of 90 days to five years for product defects. We accrue for warranty returns at the time of product shipment based on our historical return rate and estimate of the cost to repair or replace the defective products. We engage in extensive product quality programs and processes, including actively monitoring and evaluating the quality of our component suppliers. The increasing complexity of our products may cause warranty incidences, when they arise, to be more costly. Estimates regarding future warranty obligations may change due to product failure rates, material usage and other rework costs incurred in correcting a product failure. In addition, from time to time, specific warranty accruals may be recorded if unforeseen problems arise. Should our actual experience relative to these factors be worse than our estimates, we will be required to record additional warranty expense. The liability for warranty obligations totaled $5.1 million and $5.4 million as of March 31, 2022 and December 31, 2021, respectively, and is included in accrued expenses and other liabilities in the Condensed Consolidated Balance Sheets. During the three months ended March 31, 2021, we had a net reversal of prior provisions related to warranty expirations the impact of which is reflected in the table below. The warranty expense and write-off activity for the three months ended March 31, 2022 and 2021 is summarized as follows:

[0000950170-22-008077:notes:135]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2022 |  |  | 2021 |  |
| Balance at beginning of period |  | $ | 5,403 |  |  | $ | 7,146 |  |
| Plus: Amounts charged to cost and expenses |  |  | 344 |  |  |  | (231 | ) |
| Less: Deductions |  |  | (604 | ) |  |  | (443 | ) |
| Balance at end of period |  | $ | 5,143 |  |  | $ | 6,472 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000950170-22-008077:notes:136]
17. COMMITMENTS AND CONTINGENCIES

[0000950170-22-008077:notes:137]
Shareholder Derivative Lawsuit

[0000950170-22-008077:notes:138]
On March 31, 2020, a shareholder derivative suit, captioned Johnson (Derivatively on behalf of ADTRAN) v. Stanton, et al., Case No. 5:20-cv-00447, was filed in the U.S. District Court for the Northern District of Alabama against two of the Company’s current executive officers, one of its former executive officers, and certain current and former members of its Board of Directors, alleging, among other things, that the defendants made or caused the Company to make materially false and misleading statements regarding, and/or failed to disclose material adverse facts about, the Company’s business, operations and prospects, specifically relating to the Company’s internal control over financial reporting, excess and obsolete inventory reserves, financial results and demand from certain customers. The plaintiff in the shareholder derivative suit sent a demand letter dated June 29, 2021 to ADTRAN’s Board of Directors. The letter contains similar allegations to those made in the plaintiff’s filed complaint and in the now dismissed securities class action, and it demands, among other things, that the Board of Directors commence an investigation into the alleged wrongdoing. On December 10, 2021, after investigating the allegations in the plaintiff’s demand with the assistance of independent counsel, the independent members of the Board of Directors concluded that pursuing the claims asserted in the demand would not be in the Company's best interests and exercised their business judgment to refuse the demand. The plaintiff subsequently dismissed the case. On February 25, 2022, the Court entered an order on the parties’ joint stipulation dismissing the case without prejudice.

[0000950170-22-008077:notes:139]
Other Legal Matters

[0000950170-22-008077:notes:140]
In addition to the litigation described above, from time to time we are subject to or otherwise involved in various lawsuits, claims, investigations and legal proceedings that arise out of or are incidental to the conduct of our business (collectively, “Legal Matters”), including those relating to employment matters, patent rights, regulatory compliance matters, stockholder claims, and contractual and other commercial disputes. Such Legal Matters, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Additionally, an unfavorable outcome in any legal matter, including in a patent dispute, could require the Company to pay damages, entitle claimants to other relief, such as royalties, or could prevent the Company from selling some of its products in certain jurisdictions. While the Company cannot predict with certainty the results of Legal Matters in which it is currently involved, the Company does not expect that the ultimate outcome of such Legal Matters will individually or in the aggregate have a material adverse effect on its business, results of operations, financial condition or cash flows.

[0000950170-22-008077:notes:141]
Business Combination Agreement

[0000950170-22-008077:notes:142]
On August 30, 2021, the Company and ADVA, entered into a business combination agreement (the “Business Combination Agreement”), pursuant to which both companies agreed to combine their respective businesses and each become subsidiaries of a new holding company, Acorn HoldCo, a Delaware corporation and currently a wholly-owned direct subsidiary of the Company.

[0000950170-22-008077:notes:143]
Under the terms of the Business Combination Agreement, Acorn MergeCo, Inc., a newly formed Delaware corporation and wholly-owned direct subsidiary of Acorn HoldCo (“Merger Sub”), will merge with and into ADTRAN, with ADTRAN surviving the merger (the “Merger”) as a wholly-owned direct subsidiary of Acorn HoldCo. Pursuant to the Merger, each outstanding share of common stock of the Company will be converted into the right to receive one share of common stock of Acorn HoldCo. Acorn HoldCo has also made a public exchange offer to exchange each issued and outstanding no-par value bearer share of ADVA, pursuant to which each ADVA share tendered and accepted for exchange will be exchanged for 0.8244 shares of common stock of Acorn HoldCo (the “Exchange Offer”, and together with the Merger, the “Business Combination”). Upon completion of the Business Combination, and assuming that all of the outstanding ADVA shares are exchanged in the Exchange Offer, former ADTRAN stockholders and former ADVA shareholders will own approximately 54% and 46%, respectively, of the outstanding Acorn HoldCo shares.

[0000950170-22-008077:notes:144]
The Business Combination Agreement was unanimously approved by the Board of Directors of the Company and by the supervisory board and management board of ADVA. On January 6, 2022, the Company's stockholders approved the Business Combination by an overwhelming majority. The end of the ADVA shareholder tender offer acceptance period was on January 26, 2022, which resulted in the acceptance of the Exchange Offer by more than 60% of all shares of ADVA entitled to voting rights existing as of October 31, 2021, thus exceeding the required minimum acceptance threshold. According to the rules of the German Securities Acquisition and Takeover Act, ADVA shareholders who did not tender their shares during the initial acceptance period could do so during a two-week additional acceptance period that began on February 1, 2022 and ended February 14, 2022. This resulted in the acceptance of the Exchange Offer by approximately 66% of all shares of ADVA entitled to voting rights existing as of November 30, 2021. On January 24, 2022, the Committee on Foreign Investment in the U.S. ("CFIUS") completed its review of the Business Combination and determined that the transaction was not a “covered transaction” subject to CFIUS’ jurisdiction, satisfying the condition of the Business Combination Agreement related to CFIUS notification. On February 16, 2022, the U.K. Secretary of State for Business, Energy and Industrial Strategy completed its review of the Business Combination and determined that the Secretary of State will be taking no further action under the NS&I Act, satisfying the condition of the Business Combination Agreement related to NS&I Act approval. Cooperative proceedings continue with the foreign direct investment authorities in Germany.

[0000950170-22-008077:notes:145]
The Company anticipates the consummation of the Business Combination around the middle of 2022, subject to customary closing conditions, and regulatory approvals from the foreign direct investment authorities in Germany.

[0000950170-22-008077:notes:146]
Additional information about the Business Combination Agreement and proposed Business Combination is set forth in the Company’s filings with the SEC, as well as in the registration statement on Form S-4 that Acorn HoldCo filed with the SEC, which was declared effective December 2, 2021 (the “Acorn HoldCo Registration Statement”).

[0000950170-22-008077:notes:147]
Performance Bonds

[0000950170-22-008077:notes:148]
Certain contracts, customers and jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of March 31, 2022 and December 31, 2021, we had commitments related to these bonds totaling $20.9 million and $22.9 million, respectively, which expire at various dates through April 2025. In general we would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which we believe is remote.

[0000950170-22-008077:notes:149]
In June 2020, the Company entered into a letter of credit with a bank to guarantee performance obligations under a contract with a certain customer. The obligations under this customer contract will be performed over multiple years. We reached the maximum value of our minimum collateral requirement of $15.0 million during the three months ended March 31, 2021 as the Company reached certain milestones through the first quarter of 2021 as outlined in the customer contract. The letter of credit was secured by a pledge of a portion of the Company’s fixed-income securities, which totaled $18.0 million as of March 31, 2022, of which $0.1 million is included in restricted cash and $17.9 million is included in long-term investments on the Condensed Consolidated Balance Sheets. This pledged collateral value will fluctuate as the Company changes the mix of the pledged collateral between restricted cash and investments. Any shortfalls in the minimum collateral value are required to be restored by the Company from available cash and cash equivalents, short-term investments and/or long-term investments. The collateral under the letter of credit will be released when all obligations under the customer contract have been met. As of March 31, 2022, the Company believes it was in compliance with all contractual requirements under the letter of credit.

[0000950170-22-008077:notes:150]
Investment Commitment

[0000950170-22-008077:notes:151]
We have committed to invest up to an aggregate of $5.0 million in a private equity fund, of which $4.9 million has been invested as of March 31, 2022.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000950170-22-008077:notes:152]
18. RESTRUCTURING

[0000950170-22-008077:notes:153]
During the second half of 2019, the Company initiated a restructuring plan to realign its expense structure with the reduction in revenue experienced in recent years and overall Company objectives. As part of this restructuring plan, the Company announced plans to reduce its overall operating expenses, both in the U.S. and internationally. Management continued to assess the efficiency of operations during 2020 and the first three months of 2021 and, in turn, consolidated locations and personnel, among other things, where possible.

[0000950170-22-008077:notes:154]
[same as prior period, unchanged from 0000950170-21-003219:notes:171]

[0000950170-22-008077:notes:155]
The cumulative amount of restructuring expenses incurred as of March 31, 2022 for the restructuring plans was $12.7 million.

[0000950170-22-008077:notes:156]
[same as prior period, unchanged from 0000950170-21-003219:notes:173]

[0000950170-22-008077:notes:157]
|  |  | Three Months Ended |  |
| (In thousands) |  | March 31, 2022 |  |
| Balance as of December 31, 2021 |  | $ | 1,514 |  |
| Plus: Amounts charged to cost and expense |  |  | 2 |  |
| Less: Amounts paid |  |  | (1,256 | ) |
| Balance as of March 31, 2022 |  | $ | 260 |  |

[0000950170-22-008077:notes:158]
| (In thousands) |  | For the Year Ended December 31, 2021 |  |
| Balance as of December 31, 2020 |  | $ | 4,186 |  |
| Plus: Amounts charged to cost and expense |  |  | 411 |  |
| Less: Amounts paid |  |  | (3,083 | ) |
| Balance as of December 31, 2021 |  | $ | 1,514 |  |

[0000950170-22-008077:notes:159]
Restructuring expenses included in the Condensed Consolidated Statements of (Loss) Income were as follows:

[0000950170-22-008077:notes:160]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2022 |  |  | 2021 |  |
| Network Solutions - Cost of revenue |  | $ | — |  |  | $ | 12 |  |
| Services & Support - Cost of revenue |  |  | — |  |  |  | 3 |  |
| Cost of revenue |  | $ | — |  |  | $ | 15 |  |
| Selling, general and administrative expenses (1) |  |  | 2 |  |  |  | 142 |  |
| Research and development expenses (1) |  |  | — |  |  |  | 144 |  |
| Total restructuring expenses |  | $ | 2 |  |  | $ | 301 |  |

[0000950170-22-008077:notes:161]
[same as prior period, unchanged from 0000950170-21-003219:notes:178]

[0000950170-22-008077:notes:162]
[same as prior period, unchanged from 0000950170-21-003219:notes:179]

[0000950170-22-008077:notes:163]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2022 |  |  | 2021 |  |
| United States |  | $ | 2 |  |  | $ | 209 |  |
| International |  |  | — |  |  |  | 92 |  |
| Total restructuring expenses |  | $ | 2 |  |  | $ | 301 |  |


## us-gaap:SubsequentEventsTextBlock

[0000950170-22-008077:notes:164]
19. SUBSEQUENT EVENTS

[0000950170-22-008077:notes:165]
On May 4, 2022, we announced that our Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to the Company’s stockholders of record as of the close of business on May 19, 2022. The payment date will be June 2, 2022 in the aggregate amount of approximately $4.4 million.

[0000950170-22-008077:notes:166]
On April 1, 2022, the Company entered into a Credit Agreement and related Revolving Line of Credit Note (together, the “Wells Revolving Credit Agreement”) in favor of Wells Fargo Bank, National Association, as lender (the “Wells Lender”). The Wells Revolving Credit Agreement provides the Company with a new $25 million secured revolving credit facility. The Wells Revolving Credit Agreement matures on April 1, 2023, subject to earlier termination upon the occurrence of certain events of default as set forth in the Wells Revolving Credit Agreement.  Loans under the Wells Revolving Credit Agreement will bear interest at a fluctuating rate per annum equal to: (i) the Daily Simple SOFR (as defined herein) plus (ii) an applicable margin, which will equal 1.00%, 1.25%, 1.5% or 2.0% per annum depending on the Company’s senior funded debt to EBITDA ratio. The “Daily Simple SOFR” is calculated based upon the greater of (x) a floor of 0.00% and (b) the Secured Overnight Financing Rate, as established by the Federal Reserve Bank of New York (or a successor thereto) from time to time. Accrued interest is payable on the last day of each quarter, commencing June 30, 2022. Borrowings under the Wells Revolving Credit Agreement may be used solely for issuing letters of credit, financing capital expenditures, and working capital and general corporate purposes. Loans under the Wells Revolving Credit Agreement are secured by a first priority security interest in all of the accounts receivable of the Company and its subsidiary, ADTRAN International, Inc. Specifically, in connection with the Wells Revolving Credit Agreement, the Company entered into a security agreement, dated April 1, 2022, pursuant to which the Company pledged to the Wells Lender all of the rights to payment, accounts, deposit accounts, chattel paper (whether electronic or tangible), instruments, promissory notes, documents, licenses, general intangibles, payment intangibles, software, letter of credit rights and healthcare insurance receivables existing as of the date of execution or arising at any time thereafter.
