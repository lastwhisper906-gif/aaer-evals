# ADTN MD&A — 0000950170-22-008077


## mdna

[0000950170-22-008077:mdna:1]
[same as prior period, unchanged from 0000950170-21-003219:mdna:1]

[0000950170-22-008077:mdna:2]
The following discussion should be read in conjunction with the consolidated financial statements and the related notes that appear in Part I, Item 1 of this document.  In addition, the following discussion should be read in conjunction with our audited consolidated financial statements for the year ended December 31, 2021, Part II, Item 7, Management’s Discussion and Analysis of Financial Condition and Results of Operations, Part I, Item 1, Business, and Item 1A, Risk Factors, included in our Annual Report on Form 10-K for the year ended December 31, 2021, filed with the SEC on February 25, 2022 (the “2021 Form 10-K”).

[0000950170-22-008077:mdna:3]
This discussion is designed to provide the reader with information that will assist in understanding our condensed consolidated financial statements, the changes in certain key items in those financial statements from period to period, and the primary factors that accounted for those changes, as well as how certain accounting principles affect our condensed consolidated financial statements. See “Cautionary Note Regarding Forward-Looking Statements” on page 3 of this report for a description of important factors that could cause actual results to differ from expected results. See also Part 1, Item 1A, Risk Factors, of the 2021 Form 10‑K and Part II, Item 1A, Risk Factors of this Form 10-Q.

[0000950170-22-008077:mdna:4]
[same as prior period, unchanged from 0000950170-21-003219:mdna:4]

[0000950170-22-008077:mdna:5]
[same as prior period, unchanged from 0000950170-21-003219:mdna:5]

[0000950170-22-008077:mdna:6]
We ended the first quarter of 2022 with a year-over-year revenue increase of 21.2% as compared to the three months ended March 31, 2021, driven by increased shipments to a diverse mix of global Tier-1 and regional service providers. During the first quarter of 2022, we had three 10% revenue customers geographically diversified, one U.S. distributor, one international service provider customer and one U.S. service provider customer. Our year-over-year domestic revenue increased by 14.5%, driven by increased volume of network termination and Fiber CPE in our Network Solutions segment. Internationally, our revenue increased by 35.1% compared to the prior year period, primarily driven by increased shipments to a Tier-1 network operator and multiple alternative network operators in Europe. We experienced strong demand for our solutions in the first quarter of 2022 and achieved significant year-over-year bookings growth. Bookings are defined as orders received for a product or service during a fiscal period that will be delivered or performed sometime in the future and is a forward looking metric that we utilize to help us understand future revenue growth for the Company. Bookings are generally subject to modification and or cancellation per the terms of the order. A substantial portion of our shipments in any fiscal period relates to orders received and shipped within that fiscal period for customers under agreements containing nonbinding purchase commitments. Our increase in demand comes from service providers planning to deploy our fiber access platforms, in-home service delivery platforms and SaaS applications. We expect this growth to accelerate. During 2021 and continuing in 2022, we secured several Tier-1 next-generation fiber customers, and previously announced Tier-1 fiber customers significantly increased their bookings for our fiber access platforms. Although we expect our revenue growth and profitability in the near-term to continue to be negatively impacted by supply chain issues, our outlook continues to strengthen given the increased demand for our products and our expectation of an improving supply chain over the longer term.

[0000950170-22-008077:mdna:7]
In March 2020, the World Health Organization declared the novel coronavirus (COVID-19) outbreak a global pandemic. The SARS-CoV-2 coronavirus (or variants of the SARS-CoV-2 coronavirus) continues to spread throughout the U.S. and the world and has resulted in authorities implementing varying measures to contain the virus, including travel bans and restrictions, quarantines, shelter-in-place orders, and business limitations and shutdowns. Although vaccines have been approved and are being distributed, it cannot be predicted how long it will take before market conditions return to normal and there can be no assurance that the economic recovery will occur or offset the uncertainty and instability triggered by the pandemic. New and potentially more contagious variants of the COVID-19 virus may develop in various countries, including in regions in which we have significant operations. The COVID-19 variants could further amplify the impact of the pandemic. While we are unable to accurately predict the full impact that the COVID-19 global pandemic will have on our results of operations, financial condition, liquidity and cash flows due to numerous uncertainties, including the duration and severity of the pandemic and containment measures, our compliance with these measures has impacted our day-to-day operations and could disrupt our business and operations, as well as that of our key customers, suppliers and other counterparties, for an indefinite period of time. We have experienced a significant impact to our supply chain given COVID-19 and the related global semiconductor chip shortage, including delays in supply chain deliveries, extended lead times and shortages of some key components, some raw material cost increases and slowdowns at certain production facilities. We have also had to increase our volume of inventory to ensure supply continuity during the pandemic. In addition, we have experienced significant increases in freight-related costs due to global shipping disruptions. Starting in the third quarter of 2021 and continuing into 2022, the Company has incurred supply chain constraint expenses, including price inflation for certain electronic components, semiconductor chips and transportation related costs, which have lowered our gross margins and decreased our profitability. While throughout the pandemic we have seen increased demand in networking requirements and utilization due to social distancing guidelines issued by governments, as well as COVID-19 related reductions in travel and infrastructure expenses, it is possible that we could experience some slowdown in demand, further supply chain issues and an increased impact from the ongoing semiconductor shortage and shortages of certain other key components as the pandemic continues. If the impacts of this shortage are more severe than we expect, it could result in longer lead times, inventory supply challenges and further increased costs, all of which could result in the deterioration of our results, potentially for a longer period than currently anticipated. To support the health and well-being of our employees, customers, partners and communities, many of our employees are working remotely or on a hybrid schedule as of the date of filing this report. Additionally, there is risk that a number of our employees may become infected with COVID-19, including our key personnel. In addition, actions that have been taken and that may be taken by the Company, its customers, suppliers and counterparties in response to the pandemic, including the implementation of alternative work arrangements for certain employees, as well as the impacts to our supply chain, including delays in supply chain deliveries and the related global semiconductor chip shortage, have delayed and may continue to delay the timing of some orders and expected deliveries. Lastly, even after the COVID-19 pandemic has subsided, we may continue to experience adverse impacts to our business as a result of any economic recession that has occurred or may occur in the future as a result of the COVID-19 pandemic.

[0000950170-22-008077:mdna:8]
Among our customers, we made progress with our fiber, fiber-extension, in-home service delivery platforms and cloud services while also continuing to engage in value-added service opportunities that contributed to sales in 2021 and we expect will contribute to sales during 2022 and beyond. In addition, we believe that we are at the beginning of a significant investment cycle for fiber deployment and in-home Wi-Fi connectivity driven by technology advancements and regulatory influences. Payments to service providers under government funding programs such as the FCC RDOF started in 2021, and they are expected to continue in 2022. The transition to next-generation network architectures is beginning, and we are seeing demand for our next-generation fiber access and connected home solutions.

[0000950170-22-008077:mdna:9]
[same as prior period, unchanged from 0000950170-21-003219:mdna:9]

[0000950170-22-008077:mdna:10]
[same as prior period, unchanged from 0000950170-21-003219:mdna:10]

[0000950170-22-008077:mdna:11]
[same as prior period, unchanged from 0000950170-21-003219:mdna:11]

[0000950170-22-008077:mdna:12]
[same as prior period, unchanged from 0000950170-21-003219:mdna:12]

[0000950170-22-008077:mdna:13]
Our operating results have fluctuated, and may continue to fluctuate, on a quarterly basis due to several factors, including customer order activity, supply chain constraints, component availability, and backlog. A substantial portion of our shipments in any fiscal period relates to orders received and shipped within that fiscal period for customers under agreements containing non-binding purchase commitments. Further, a significant percentage of orders require delivery within a few days requiring us to maintain higher inventory levels.  These factors normally result in a varying order backlog and limited order flow visibility; however, with the current global supply chain and transportation constraints, and limited availability of semiconductor chips and other components of our products, we have experienced and may continue to experience extended lead times, increased logistics intervals and costs, and lower volume of

[0000950170-22-008077:mdna:14]
products deliveries, which has had and may continue to have a material adverse effect on our operating results and could have a material adverse effect on customer relations and our financial condition. Normal operating expenses are relatively fixed in the short term; therefore, a shortfall in quarterly revenues could significantly impact our financial results in a given quarter.

[0000950170-22-008077:mdna:15]
We are exposed to changes in foreign currencies relative to the U.S. dollar, which are references to the differences between the foreign-exchanges rates we use to convert the financial results of our international operations from local currencies into U.S. dollars for financial reporting purposes. This impact of foreign-exchange rate changes is calculated based on the difference between the current period’s currency exchange rates and that of the comparable prior period. Our primary exposures to foreign currency exchange rate movements are with our German subsidiary, whose functional currency is the Euro, our Australian subsidiary, whose functional currency is the Australian dollar, and our U.K. subsidiary, who transacts in the British pound sterling with a U.S. dollar functional currency. As a result of our global operations, our revenue, gross margins, operating expense and operating income in some international markets have been and may continue to be affected by foreign currency fluctuations.

[0000950170-22-008077:mdna:16]
[same as prior period, unchanged from 0000950170-21-003219:mdna:15]

[0000950170-22-008077:mdna:17]
Our operating results may also fluctuate as a result of a number of other factors, including a decline in general economic and market conditions, specifically the decline that initially resulted from the COVID-19 pandemic and that may recur, foreign currency exchange rate movements, inflation, regional conflicts, increased competition, customer order patterns, changes in product and services mix, timing differences between price decreases and product cost reductions, product warranty returns, expediting costs, tariffs and announcements of new products by us or our competitors. Specifically, we expect inflationary pressures on input costs, such as raw materials and labor, and distribution costs to increase. Our attempts to offset these cost pressures, such as through increases in the selling prices of some of our products and services, may not be successful and could negatively affect our operating results. Additionally, maintaining sufficient inventory levels to assure prompt delivery of our products increases the amount of inventory that may become obsolete and increases the risk that the obsolescence of this inventory may have an adverse effect on our business and operating results. Also, not maintaining sufficient inventory levels to assure prompt delivery of our products may cause us to incur expediting costs to meet customer delivery requirements, which may negatively impact our operating results. In recent years, the Company initiated restructuring plans to realign its expense structure with the reduction in revenue experienced and with overall Company objectives. Management assessed the efficiency of our operations and consolidated locations and personnel, among other things, and implemented certain cost savings initiatives, where possible. See Note 18 of the Notes to Condensed Consolidated Financial Statements included in Part 1, Item 1 of this report for additional information on this restructuring.

[0000950170-22-008077:mdna:18]
Our historical financial performance is not necessarily a meaningful indicator of future results, and in general, management expects that our financial results may vary from period to period. Factors that could materially affect our business, financial condition or operating results are included in Part I, Item 1A of the 2021 Form 10-K and Part II, Item 1A of this Form 10-Q.

[0000950170-22-008077:mdna:19]
[same as prior period, unchanged from 0000950170-21-003219:mdna:18]

[0000950170-22-008077:mdna:20]
On August 30, 2021, the Company and ADVA, entered into a business combination agreement (the “Business Combination Agreement”), pursuant to which both companies agreed to combine their respective businesses and each become subsidiaries of a new holding company, Acorn HoldCo, a Delaware corporation and currently a wholly-owned direct subsidiary of the Company.

[0000950170-22-008077:mdna:21]
Under the terms of the Business Combination Agreement, Acorn MergeCo, Inc., a newly formed Delaware corporation and wholly-owned direct subsidiary of Acorn HoldCo (“Merger Sub”), will merge with and into ADTRAN, with ADTRAN surviving the merger (the “Merger”) as a wholly-owned direct subsidiary of Acorn HoldCo. Pursuant to the Merger, each outstanding share of common stock of the Company will be converted into the right to receive one share of common stock of Acorn HoldCo. Acorn HoldCo has also made a public exchange offer to exchange each issued and outstanding no-par value bearer share of ADVA, pursuant to which each ADVA share tendered and accepted for exchange will be exchanged for 0.8244 shares of common stock of Acorn HoldCo (the “Exchange Offer”, and together with the Merger, the “Business Combination”). Upon completion of the Business Combination, and assuming that all of the outstanding ADVA shares are exchanged in the Exchange Offer, former ADTRAN stockholders and former ADVA shareholders will own approximately 54% and 46%,respectively, of the outstanding Acorn HoldCo shares.

[0000950170-22-008077:mdna:22]
The Business Combination Agreement was unanimously approved by the Board of Directors of the Company and by the supervisory board and management board of ADVA. On January 6, 2022, the Company's stockholders approved the Business Combination by an overwhelming majority. The end of the ADVA shareholder tender offer acceptance period was on January 26, 2022, which resulted in the acceptance of the Exchange Offer by more than 60% of all shares of ADVA entitled to voting rights existing as of October 31, 2021, thus exceeding the required minimum acceptance threshold. According to the rules of the German Securities Acquisition and Takeover Act, ADVA shareholders who did not tender their shares during the initial acceptance period could do so during a two-week additional acceptance period that began on February 1, 2022 and ended February 14, 2022. This resulted in the acceptance of the Exchange Offer by approximately 66% of all shares of ADVA entitled to voting rights existing as of November 30, 2021. On January 24, 2022, the Committee on Foreign Investment in the U.S. ("CFIUS") completed its review of the Business Combination and determined that the

[0000950170-22-008077:mdna:23]
transaction was not a “covered transaction” subject to CFIUS’ jurisdiction, satisfying the condition of the Business Combination Agreement related to CFIUS notification. On February 16, 2022, the U.K. Secretary of State for Business, Energy and Industrial Strategy completed its review of the Business Combination and determined that the Secretary of State will be taking no further action under the NS&I Act, satisfying the condition of the Business Combination Agreement related to NS&I Act approval. Cooperative proceedings continue with the foreign direct investment authorities in Germany.

[0000950170-22-008077:mdna:24]
The Company anticipates the consummation of the Business Combination around the middle of 2022, subject to customary closing conditions, and regulatory approvals from the foreign direct investment authorities in Germany.

[0000950170-22-008077:mdna:25]
Additional information about the Business Combination Agreement and proposed Business Combination is set forth in the Company’s filings with the SEC, as well as in the registration statement on Form S-4 that Acorn HoldCo filed with the SEC, which was declared effective December 2, 2021 (the “Acorn HoldCo Registration Statement”).

[0000950170-22-008077:mdna:26]
[same as prior period, unchanged from 0000950170-21-003219:mdna:24]

[0000950170-22-008077:mdna:27]
There have been no material changes to our critical accounting policies and estimates from those disclosed in our 2021 Form 10-K.

[0000950170-22-008077:mdna:28]
[same as prior period, unchanged from 0000950170-21-003219:mdna:26]

[0000950170-22-008077:mdna:29]
[same as prior period, unchanged from 0000950170-21-003219:mdna:27]

[0000950170-22-008077:mdna:30]
RESULTS OF OPERATIONS – THREE MONTHS ENDED MARCH 31, 2022 COMPARED TO THREE MONTHS ENDED MARCH 31, 2021

[0000950170-22-008077:mdna:31]
The following table presents selected financial information derived from our Condensed Consolidated Statements of (Loss) Income  expressed as a percentage of revenue for the periods indicated. Amounts may not foot due to rounding.

[0000950170-22-008077:mdna:32]
|  |  | Three Months Ended |  |  |
|  |  | March 31, |  |  |
|  |  | 2022 |  |  | 2021 |  |  |
| Revenue |  |  |  |  |  |  |  |
| Network Solutions |  |  | 89.6 |  | % |  | 89.2 |  | % |
| Services & Support |  |  | 10.4 |  |  |  | 10.8 |  |  |
| Total Revenue |  |  | 100.0 |  |  |  | 100.0 |  |  |
| Cost of Revenue |  |  |  |  |  |  |  |
| Network Solutions |  |  | 58.7 |  |  |  | 51.0 |  |  |
| Services & Support |  |  | 6.2 |  |  |  | 7.0 |  |  |
| Total Cost of Revenue |  |  | 64.8 |  |  |  | 58.0 |  |  |
| Gross Profit |  |  | 35.2 |  |  |  | 42.0 |  |  |
| Selling, general and administrative expenses |  |  | 18.1 |  |  |  | 21.5 |  |  |
| Research and development expenses |  |  | 17.1 |  |  |  | 21.6 |  |  |
| Operating Loss |  |  | — |  |  |  | (1.0 | ) |  |
| Interest and dividend income |  |  | 0.1 |  |  |  | 0.2 |  |  |
| Interest expense |  |  | — |  |  |  | — |  |  |
| Net investment (loss) gain |  |  | (2.2 | ) |  |  | 0.8 |  |  |
| Other (expense) income, net |  |  | (0.1 | ) |  |  | 1.6 |  |  |
| (Loss) Income Before Income Taxes |  |  | (2.3 | ) |  |  | 1.5 |  |  |
| Income tax benefit (expense) |  |  | 1.6 |  |  |  | (0.8 | ) |  |
| Net (Loss) Income |  |  | (0.7 | ) | % |  | 0.7 |  | % |

[0000950170-22-008077:mdna:33]
[same as prior period, unchanged from 0000950170-21-003219:mdna:32]

[0000950170-22-008077:mdna:34]
Our revenue increased 21.2% from $127.5 million for the three months ended March 31, 2021 to $154.5 million for the three months ended March 31, 2022. The increase in revenue for the three months ended March 31, 2022 was primarily attributable to a $26.4 million increase in Access & Aggregation revenue and a $0.6 million increase in the revenue of our Traditional & Other Products, respectively. Although our revenue increased, supply of semiconductor chips and other components of our products has become constrained resulting in extended lead times and increased costs. Transportation constraints, including shortages for both air and surface freight, as well as labor shortages in the transportation industry, have also affected the timing and the cost of obtaining raw materials and production supplies. Although our revenue growth and profitability in the near-term may be impacted by these global supply chain issues, our longer term outlook continues to strengthen given our progress with new customer opportunities and the increased customer demand.

[0000950170-22-008077:mdna:35]
Network Solutions segment revenue increased 21.6% from $113.8 million for the three months ended March 31, 2021 to $138.4 million for the three months ended March 31, 2022. The increase in revenue for the three months ended March 31, 2022 was due primarily to revenue of Access & Aggregation products and Traditional & Other Products partially offset by Subscriber Solutions & Experience products. While we expect that revenue from Traditional & Other Products will continue to decline over time, this revenue may fluctuate and continue for years because of the time required for our customers to transition to newer technologies.

[0000950170-22-008077:mdna:36]
Services & Support segment revenue increased 17.6% from $13.7 million for the three months ended March 31, 2021 to $16.1 million for the three months ended March 31, 2022. The increase in revenue for the three months ended March 31, 2022 was primarily attributable to increased network planning and implementation services as well as maintenance and managed services.

[0000950170-22-008077:mdna:37]
34

[0000950170-22-008077:mdna:38]
International revenue, which is defined as revenue generated from the Network Solutions and Services & Support segments provided to a customer outside of the U.S., increased by 35.1% from $41.0 million for the three months ended March 31, 2021 to $55.5 million for the three months ended March 31, 2022. International revenue, as a percentage of total revenue, increased from 32.2% for the three months ended March 31, 2021 to 35.9% for the three months ended March 31, 2022. The increase in percentage of international revenue for the three months ended March 31, 2022, was primarily driven by increased shipments to a Tier-1 network operator and multiple alternative network operators in Europe. For the three months ended March 31, 2022 as compared to the three months ended March 31, 2021, changes in foreign currencies relative to the U.S dollar decreased our net sales by approximately $2.3 million.

[0000950170-22-008077:mdna:39]
Our international revenue is largely focused on broadband infrastructure and is consequently affected by the decisions of our customers as to timing for installation of new technologies, expansion of their networks and/or network upgrades. Our international customers must make these decisions in the regulatory and political environment in which they operate – both nationally and in some instances, regionally – whether of a multi-country region or a more local region within a country. Consequently, while we expect the global trend towards deployment of more robust broadband speeds and access to continue creating additional market opportunities for us, the factors described above may result in pressure on revenue and operating income.

[0000950170-22-008077:mdna:40]
[same as prior period, unchanged from 0000950170-21-003219:mdna:39]

[0000950170-22-008077:mdna:41]
As a percentage of revenue, cost of revenue increased from 58.0% for the three months ended March 31, 2021 to 64.8% for the three months ended March 31, 2022. For the three months ended March 31, 2022, the increase was primarily attributable to supply chain constraint related expenses and to a lesser extent changes in customer and product mix and a regional revenue shift. For the three months ended March 31, 2022 as compared to the three months ended March 31, 2021, changes in foreign currencies relative to the U.S dollar decreased our cost of revenue by approximately $0.9 million.

[0000950170-22-008077:mdna:42]
Network Solutions cost of revenue, as a percentage of that segment’s revenue, increased from 57.1% for the three months ended March 31, 2021 to 65.5% for the three months ended March 31, 2022. The increase in cost of revenue as a percentage of revenue for the three months ended March 31, 2022 was primarily attributable to supply chain constraint related expenses and to a lesser extent changes in customer and product mix and a regional revenue shift.

[0000950170-22-008077:mdna:43]
Services & Support cost of revenue, as a percentage of that segment’s revenue, decreased from 65.1% for the three months ended March 31, 2021 to 59.1% for the three months ended March 31, 2022. The decrease in cost of revenue as a percentage of revenue for the three months ended March 31, 2022 was primarily attributable to customer mix, changes in services and support mix.

[0000950170-22-008077:mdna:44]
[same as prior period, unchanged from 0000950170-21-003219:mdna:43]

[0000950170-22-008077:mdna:45]
[same as prior period, unchanged from 0000950170-21-003219:mdna:44]

[0000950170-22-008077:mdna:46]
As a percentage of revenue, selling, general and administrative expenses decreased from 21.5% for the three months ended March 31, 2021 to 18.1% for the three months ended March 31, 2022. Selling, general and administrative expenses as a percentage of revenue will generally fluctuate whenever there is a significant fluctuation in revenue for the periods being compared.

[0000950170-22-008077:mdna:47]
Selling, general and administrative expenses increased 1.7% from $27.4 million for the three months ended March 31, 2021 to $27.9 million for the three months ended March 31, 2022. The increase in selling, general and administrative expenses for the three months ended March 31, 2022 was primarily attributable to increased acquisition expenses, salary and commission expenses, travel expense and insurance expense, partially offset by decreases in market driven fluctuations in our deferred compensation related costs and legal expenses. For the three months ended March 31, 2022 as compared to the three months ended March 31, 2021, changes in foreign currencies relative to the U.S dollar decreased our selling, general and administrative expenses by approximately $0.4 million.

[0000950170-22-008077:mdna:48]
[same as prior period, unchanged from 0000950170-21-003219:mdna:47]

[0000950170-22-008077:mdna:49]
As a percentage of revenue, research and development expenses decreased from 21.6% for the three months ended March 31, 2021 to 17.1% for the three months ended March 31, 2022. Research and development expenses as a percentage of revenue will fluctuate whenever there are incremental product development activities or significant fluctuations in revenue for the periods being compared.

[0000950170-22-008077:mdna:50]
Research and development expenses decreased 3.7% from $27.5 million for the three months ended March 31, 2021 to $26.5 million for the three months ended March 31, 2022. The decrease in research and development expenses for the three months ended March 31,

[0000950170-22-008077:mdna:51]
2022 was primarily attributable to lower labor and engineering project expenses which fluctuate across the various phases of the projects. For the three months ended March 31, 2022 as compared to the three months ended March 31, 2021, changes in foreign currencies relative to the U.S dollar decreased our research and development expenses by approximately $0.4 million.

[0000950170-22-008077:mdna:52]
[same as prior period, unchanged from 0000950170-21-003219:mdna:50]

[0000950170-22-008077:mdna:53]
[same as prior period, unchanged from 0000950170-21-003219:mdna:53]

[0000950170-22-008077:mdna:54]
Interest and dividend income decreased 29.7% from $0.3 million for the three months ended March 31, 2021 to $0.2 million for the three months ended March 31, 2022. The decrease in interest and dividend income was primarily attributable to a decrease in the rate of return on our long-term investments and a decrease in the investment balance. Our total long-term investments decreased from $70.6 million as of March 31, 2021 to $67.7 million as of March 31, 2022.

[0000950170-22-008077:mdna:55]
[same as prior period, unchanged from 0000950170-21-003219:mdna:55]

[0000950170-22-008077:mdna:56]
Interest expense was less than $0.1 million for each of the three months ended March 31, 2022 and 2021. Interest expense during the first three months of 2022 was primarily related to our Revolving Credit Agreement. See Note 12 of the Notes to Condensed Consolidated Financial Statements, included in Part I, Item 1 of this report.

[0000950170-22-008077:mdna:57]
NET INVESTMENT (LOSS) GAIN

[0000950170-22-008077:mdna:58]
We recognized a net investment gain of $1.0 million and a net investment loss of $3.4 million for the three months ended March 31, 2021 and 2022, respectively. The fluctuations in our net investments were primarily attributable to changes in the fair value of our securities recognized during the period. We expect that any future market volatility could result in continued fluctuations in our investment portfolio See Note 6 of the Notes to Condensed Consolidated Financial Statements, included in Part I, Item 1 of this report, and “Investing Activities” in “Liquidity and Capital Resources” below for additional information.

[0000950170-22-008077:mdna:59]
OTHER (EXPENSE) INCOME, NET

[0000950170-22-008077:mdna:60]
Other income (expense), net, which primarily consisted of gains and losses on foreign currency transactions and income from excess material sales, decreased from income of $2.0 million for the three months ended March 31, 2021 to expense of $0.2 million for the three months ended March 31, 2022.

[0000950170-22-008077:mdna:61]
INCOME TAX (BENEFIT) EXPENSE

[0000950170-22-008077:mdna:62]
Our effective tax rate changed from an expense of 53.9% of pre-tax income for the three months ended March 31, 2021, to a benefit of 68.1% of pre-tax loss for the three months ended March 31, 2022. The change in the effective tax rate for the three months ended March 31, 2022, was driven primarily by a change in our annual estimated tax rate as a result of the requirement to begin capitalizing Research and Development expenses for U.S. tax purposes beginning in 2022 as previously passed as part of the Tax Cuts and Jobs Act in December 2017 and the associated impact of those changes on our previously established valuation allowance. See Note 4 of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this report for additional information

[0000950170-22-008077:mdna:63]
NET (LOSS) INCOME

[0000950170-22-008077:mdna:64]
As a result of the above factors, net (loss) income decreased from net income of $0.9 million for the three months ended March 31, 2021 to a net loss of $1.1 million for the three months ended March 31, 2022.

[0000950170-22-008077:mdna:65]
[same as prior period, unchanged from 0000950170-21-003219:mdna:65]

[0000950170-22-008077:mdna:66]
[same as prior period, unchanged from 0000950170-21-003219:mdna:66]

[0000950170-22-008077:mdna:67]
We have historically financed, and currently expect to continue to finance, our ongoing business with existing cash, investments and cash flow from operations. In the current supply environment we also expect to utilize our credit arrangements to manage our working capital needs. We have used, and expect to continue to use, existing cash, investments, credit arrangements and cash generated from operations for working capital, business acquisitions, purchases of treasury stock, shareholder dividends and other general corporate purposes, including product development activities to enhance our existing products and develop new products, expand our sales and marketing activities and fund capital expenditures. Under the Business Combination Agreement, the Company will bear the transaction costs of the Business Combination attributable to Acorn HoldCo and the Company. As of March 31, 2022, the Company will incur an estimated $10.0 million of additional transaction costs related to the Business Combination Agreement. We believe that our cash and cash equivalents, investments, cash generated from operations and access to funds under various borrowing arrangements will be adequate to meet our operating and capital needs for at least the next 12 months.

[0000950170-22-008077:mdna:68]
As of March 31, 2022, cash on hand was $54.0 million and short-term investments were $0.4 million, which resulted in available short-term liquidity of $54.4 million, of which $45.1 million was held by our foreign subsidiaries. As of December 31, 2021, cash on hand was $56.6 million and short-term investments were $0.4 million, which resulted in available short-term liquidity of $57.0 million, of which $47.7 million was held by our foreign subsidiaries. Generally, we intend to permanently reinvest funds held outside the U.S., except to the extent that any of these funds can be repatriated without withholding tax.

[0000950170-22-008077:mdna:69]
[same as prior period, unchanged from 0000950170-21-003219:mdna:70]

[0000950170-22-008077:mdna:70]
Net cash provided by operating activities of $4.9 million during the three months ended March 31, 2022 decreased by $5.8 million compared to net cash provided of $10.7 million during the three months ended March 31, 2021. This decrease was primarily due to net cash outflows from working capital, specifically, an inventory build related to component availability and an increase in other receivables partially offset by an increase in the average number of days payable to our trade suppliers, and a decrease in accounts receivable. Additional details related to our working capital and its drivers are discussed below.

[0000950170-22-008077:mdna:71]
Net accounts receivable decreased 5.4% from $158.7 million as of December 31, 2021 to $150.1 million as of March 31, 2022. There was no allowance for credit losses as of March 31, 2022 and December 31, 2021. The decrease in net accounts receivable was due primarily to customer and geographical mix. Quarterly accounts receivable DSO decreased from 95 days as of December 31, 2021 to 87 days as of March 31, 2022. The decrease in DSO was due to customer and geographical mix.

[0000950170-22-008077:mdna:72]
Other receivables increased 54.7% from $11.2 million as of December 31, 2021 to $17.4 million as of March 31, 2022. The increase in other receivables was primarily attributable to the increase in contract assets.

[0000950170-22-008077:mdna:73]
Quarterly inventory turnover was 3.0 turns as of December 31, 2021 and 2.6 turns as of March 31, 2022, respectively. Inventory increased 22.3% from $139.9 million as of December 31, 2021 to $171.1 million as of March 31, 2022. The increase in inventory was due to strategic inventory buffer purchases given extended component lead times and availability constraints as well as new product ramp ups to ensure supply continuity during the COVID-19 pandemic. We expect inventory levels to fluctuate as we attempt to maintain sufficient inventory in response to COVID-19 uncertainties related to supply chain and supply, seasonal cycles of our business and ensuring competitive lead times while managing the risk of inventory.

[0000950170-22-008077:mdna:74]
Accounts payable increased 24.0% from $102.5 million as of December 31, 2021 to $127.1 million as of March 31, 2022. Accounts payable will fluctuate due to variations in the timing of the receipt of inventory, supplies and services and our subsequent payments for these purchases. The significant increase in the first quarter was due to additional purchases of raw material inventory.

[0000950170-22-008077:mdna:75]
[same as prior period, unchanged from 0000950170-21-003219:mdna:76]

[0000950170-22-008077:mdna:76]
Capital expenditures totaled approximately $1.5 million and $0.7 million for the three months ended March 31, 2022 and 2021, respectively. These expenditures were primarily used to purchase manufacturing and test equipment, software, computer hardware and  building improvements.

[0000950170-22-008077:mdna:77]
Our combined short-term and long-term investments decreased $2.9 million from $71.0 million as of December 31, 2021 to $68.1 million as of March 31, 2022. This decrease reflects the impact of net realized and unrealized gains and losses on our investments.

[0000950170-22-008077:mdna:78]
We typically invest all available cash not required for immediate use in operations, primarily in securities that we believe bear minimal risk of loss. See Note 6 of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this report for additional information.

[0000950170-22-008077:mdna:79]
As of March 31, 2022, our corporate bonds, municipal bonds, asset-backed bonds, mortgage/agency bonds, U.S. government bonds, other government bonds and variable-rate demand notes were classified as available-for-sale and had a combined duration of 1.79 years with an average Standard & Poor’s credit rating of AA-. Because our investment portfolio has a high-quality rating and contractual maturities of short duration, we are able to obtain prices for these bonds derived from observable market inputs, or for similar securities traded in an active market, on a daily basis.

[0000950170-22-008077:mdna:80]
Our long-term investments decreased 4.1% from $70.6 million as of December 31, 2021 to $67.7 million as of March 31, 2022.  Our investments include various marketable equity securities classified as long-term investments with a fair market value of $11.1 million and $12.6 million as of March 31, 2022 and December 31, 2021, respectively. Long-term investments as of March 31, 2022 and December 31, 2021 also included $26.1 million and $26.9 million, respectively, related to our deferred compensation plans.

[0000950170-22-008077:mdna:81]
[same as prior period, unchanged from 0000950170-21-003219:mdna:81]

[0000950170-22-008077:mdna:82]
Cadence Revolving Credit Agreement

[0000950170-22-008077:mdna:83]
On November 2, 2021, the Company renewed its Revolving Credit and Security Agreement and related Promissory Note (together, the “Cadence Revolving Credit Agreement”) with Cadence Bank, N.A., as lender (the “Cadence Lender”). The Cadence Revolving Credit Agreement provides the Company with a $10.0 million secured revolving credit facility. Loans under the Cadence Revolving Credit Agreement will bear interest at a rate equal to 1.50% over the screen rate as obtained by Reuter’s, Bloomberg or another commercially available source as may be designated by the Cadence Lender from time to time; provided, however, that in no event shall the applicable rate of interest under the Cadence Revolving Credit Agreement be less than 1.50% per annum. Such loans are secured by all of the cash, securities, securities entitlements and investment property in a certain bank account, as outlined in the Cadence Revolving Credit Agreement, at a maximum loan-to-value ratio of 75% determined by dividing the full commitment amount under the Cadence Revolving Credit Agreement on the date of testing, determined by the Cadence Lender each fiscal quarter, by the market value of the collateral. The Cadence Revolving Credit Agreement matures on November 3, 2022, subject to earlier termination upon the occurrence of certain events of default. The Company entered into the Cadence Revolving Credit Agreement in order to increase the flexibility and management of its short-term liquidity. During the first quarter of 2021, the Company made draws totaling $8.0 million under the Cadence Revolving Credit Agreement all of which had been repaid as of March 31, 2022. The Company agreed to certain negative covenants that are customary for credit arrangements of this type, including, among other things, restrictions on the Company’s ability to enter into mergers, acquisitions or other business combination transactions, grant liens or suffer a material adverse change in the condition or affairs (financial or otherwise) of the Company. As of March 31, 2022, the Company believes it was in compliance with all contractual requirements under the Cadence Revolving Credit Agreement.

[0000950170-22-008077:mdna:84]
Wells Revolving Credit Agreement

[0000950170-22-008077:mdna:85]
On April 1, 2022, the Company entered into a Credit Agreement and related Revolving Line of Credit Note (together, the “Wells Revolving Credit Agreement”) in favor of Wells Fargo Bank, National Association, as lender (the “Wells Lender”). The Wells Revolving Credit Agreement provides the Company with a new $25 million secured revolving credit facility. The Wells Revolving Credit Agreement matures on April 1, 2023, subject to earlier termination upon the occurrence of certain events of default as set forth in the Wells Revolving Credit Agreement.  Loans under the Wells Revolving Credit Agreement will bear interest at a fluctuating rate per annum equal to: (i) the Daily Simple SOFR (as defined herein) plus (ii) an applicable margin, which will equal 1.00%, 1.25%, 1.5% or 2.0% per annum depending on the Company’s senior funded debt to EBITDA ratio. The “Daily Simple SOFR” is calculated based upon the greater of (x) a floor of 0.00% and (b) the Secured Overnight Financing Rate, as established by the Federal Reserve Bank of New York (or a successor thereto) from time to time. Accrued interest is payable on the last day of each quarter, commencing June 30, 2022. Borrowings under the Wells Revolving Credit Agreement may be used solely for issuing letters of credit, financing capital expenditures, and working capital and general corporate purposes. Loans under the Wells Revolving Credit Agreement are secured by a first priority security interest in all of the accounts receivable of the Company and its subsidiary, ADTRAN International, Inc. Specifically, in connection with the Wells Revolving Credit Agreement, the Company entered into a security agreement, dated April 1, 2022, pursuant to which the Company pledged to the Wells Lender all of the rights to payment, accounts, deposit accounts, chattel paper (whether electronic or tangible), instruments, promissory notes, documents, licenses, general intangibles, payment intangibles, software, letter of credit rights and healthcare insurance receivables existing as of the date of execution or arising at any time thereafter.

[0000950170-22-008077:mdna:86]
[same as prior period, unchanged from 0000950170-21-003219:mdna:82]

[0000950170-22-008077:mdna:87]
In July 2003, our Board of Directors elected to begin declaring quarterly dividends on our common stock considering the tax treatment of dividends and adequate levels of Company liquidity. During each of the three month periods ended March 31, 2022 and 2021, we paid dividends totaling $4.4 million. The continued payment of dividends is at the discretion of the Company’s Board of Directors and is subject to general business conditions and ongoing financial results of the Company.

[0000950170-22-008077:mdna:88]
[same as prior period, unchanged from 0000950170-21-003219:mdna:84]

[0000950170-22-008077:mdna:89]
To accommodate employee stock option exercises, the Company issued 33 thousand and 0.1 million shares of treasury stock which resulted in proceeds of $0.6 million and $1.2 million during the three months ended March 31, 2022 and 2021, respectively.

[0000950170-22-008077:mdna:90]
[same as prior period, unchanged from 0000950170-21-003219:mdna:86]

[0000950170-22-008077:mdna:91]
We do not have off-balance sheet financing arrangements and have not engaged in any related party transactions or arrangements with unconsolidated entities or other persons that are reasonably likely to materially affect liquidity or the availability of or requirements for capital resources.

[0000950170-22-008077:mdna:92]
Cash Requirements

[0000950170-22-008077:mdna:93]
Certain contracts, customers and jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of March 31, 2022 and December 31, 2021, we had commitments related to these bonds totaling $20.9 million and $22.9 million, respectively, which expire at various dates through April 2025. Although the triggering events vary from contract to contract, in general we would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which we believe is remote.

[0000950170-22-008077:mdna:94]
In June 2020, the Company entered into a letter of credit with a bank to guarantee performance obligations under a contract with a certain customer. The obligations under this customer contract will be performed over multiple years. We reached the maximum value of our minimum collateral requirement of $15.0 million during the three months ended March 31, 2021, as the Company reached certain milestones through the first quarter of 2021 as outlined in the customer contract. The letter of credit was secured by a pledge of a portion of the Company’s fixed-income securities, which totaled $18.0 million as of March 31, 2022, of which $0.1 million is included in restricted cash and $17.9 million is included in long-term investments on the Condensed Consolidated Balance Sheet. This pledged collateral value will fluctuate as the Company changes the mix of the pledged collateral between restricted cash and investments. Any shortfalls in the minimum collateral value are required to be restored by the Company from available cash and cash equivalents, short-term investments and/or long-term investments. The collateral under the letter of credit will be released when all obligations under the customer contract have been met. As of March 31, 2022, the Company believes it was in compliance with all contractual requirements under the letter of credit.

[0000950170-22-008077:mdna:95]
Under the Business Combination Agreement, the Company will bear the transaction costs of the Business Combination attributable to Acorn HoldCo and the Company. For additional information on the Business Combination, see Note 17 of Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this report.

[0000950170-22-008077:mdna:96]
We have committed to invest up to an aggregate of $5.0 million in a private equity fund, of which $4.9 million has been invested as of March 31, 2022.

[0000950170-22-008077:mdna:97]
During the three months ended March 31, 2022, there have been no other material changes in cash requirements from those discussed in the 2021 Form 10-K.
