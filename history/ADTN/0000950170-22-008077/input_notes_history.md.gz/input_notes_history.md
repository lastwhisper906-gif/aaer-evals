# ADTN note change history — 0000950170-21-003219 → 0000950170-22-008077


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2022-05-06):
[0000950170-22-008077:note_history:1]
On March 31, 2020, a shareholder derivative suit, captioned Johnson (Derivatively on behalf of ADTRAN) v. Stanton, et al., Case No. 5:20-cv-00447, was filed in the U.S. District Court for the Northern District of Alabama against two of the Company’s current executive officers, one of its former executive officers, and certain current and former members of its Board of Directors, alleging, among other things, that the defendants made or caused the Company to make materially false and misleading statements regarding, and/or failed to disclose material adverse facts about, the Company’s business, operations and prospects, specifically relating to the Company’s internal control over financial reporting, excess and obsolete inventory reserves, financial results and demand from certain customers. The plaintiff in the shareholder derivative suit sent a demand letter dated June 29, 2021 to ADTRAN’s Board of Directors. The letter contains similar allegations to those made in the plaintiff’s filed complaint and in the now dismissed securities class action, and it demands, among other things, that the Board of Directors commence an investigation into the alleged wrongdoing. On December 10, 2021, after investigating the allegations in the plaintiff’s demand with the assistance of independent counsel, the independent members of the Board of Directors concluded that pursuing the claims asserted in the demand would not be in the Company's best interests and exercised their business judgment to refuse the demand. The plaintiff subsequently dismissed the case. On February 25, 2022, the Court entered an order on the parties’ joint stipulation dismissing the case without prejudice.
  (was, 2021-11-05, similarity 0.6591):
[0000950170-21-003219:note_history:1]
On March 31, 2020, a shareholder derivative suit, captioned Johnson (Derivatively on behalf of ADTRAN) v. Stanton, et al., Case No. 5:20-cv-00447, was filed in the U.S. District Court for the Northern District of Alabama against two of the Company’s current executive officers, one of its former executive officers, and certain current and former members of its Board of Directors. The derivative suit alleges, among other things, that the defendants made or caused the Company to make materially false and misleading statements regarding, and/or failed to disclose material adverse facts about, the Company’s business, operations and prospects, specifically relating to the Company’s internal control over financial reporting, excess and obsolete inventory reserves, financial results and demand from certain customers. The case was temporarily stayed pending an order on the defendants’ motion to dismiss in a separate securities class action case that included similar factual allegations, Burbridge v. ADTRAN, Inc., et al., Case No. 5:20-cv-00050-LCB (N.D. Ala.). The Burbridge case was dismissed on March 31, 2021, and the time to appeal the dismissal has expired, such that the dismissal is now final.  Following the dismissal, the plaintiff in the shareholder derivative suit sent a demand letter dated June 29, 2021 to ADTRAN’s Board of Directors.  The letter contains similar allegations to those made in the plaintiff’s filed complaint and in the now dismissed securities class action, and it demands, among other things, that the Board commence an investigation into the alleged wrongdoing.  We expect that the derivative suit will remain stayed pending the Board’s response to the demand. At this time, we are unable to predict the outcome of or estimate the possible loss or range of loss, if any, associated with the derivative lawsuit or the demand letter.

- changed (2022-05-06):
[0000950170-22-008077:note_history:2]
In addition to the litigation described above, from time to time we are subject to or otherwise involved in various lawsuits, claims, investigations and legal proceedings that arise out of or are incidental to the conduct of our business (collectively, “Legal Matters”), including those relating to employment matters, patent rights, regulatory compliance matters, stockholder claims, and contractual and other commercial disputes. Such Legal Matters, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Additionally, an unfavorable outcome in any legal matter, including in a patent dispute, could require the Company to pay damages, entitle claimants to other relief, such as royalties, or could prevent the Company from selling some of its products in certain jurisdictions. While the Company cannot predict with certainty the results of Legal Matters in which it is currently involved, the Company does not expect that the ultimate outcome of such Legal Matters will individually or in the aggregate have a material adverse effect on its business, results of operations, financial condition or cash flows.
  (was, 2021-11-05, similarity 0.9709):
[0000950170-21-003219:note_history:2]
In addition to the litigation described above, from time to time we are subject to or otherwise involved in various lawsuits, claims, investigations and legal proceedings that arise out of or are incidental to the conduct of our business (collectively, “Legal Matters”), including those relating to patent rights, employment matters, regulatory compliance matters, stockholder claims, and contractual and other commercial disputes. Such Legal Matters, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Additionally, an unfavorable outcome in any legal matter, including in a patent dispute, could require the Company to pay damages, entitle claimants to other relief, such as royalties, or could prevent the Company from selling some of its products in certain jurisdictions. While the Company cannot predict with certainty the results of the Legal Matters in which it is currently involved, the Company does not expect that the ultimate outcome of such Legal Matters will individually or in the aggregate have a material adverse effect on its business, results of operations, financial condition or cash flows.

- changed (2022-05-06):
[0000950170-22-008077:note_history:3]
On August 30, 2021, the Company and ADVA, entered into a business combination agreement (the “Business Combination Agreement”), pursuant to which both companies agreed to combine their respective businesses and each become subsidiaries of a new holding company, Acorn HoldCo, a Delaware corporation and currently a wholly-owned direct subsidiary of the Company.
  (was, 2021-11-05, similarity 0.6299):
[0000950170-21-003219:note_history:3]
On August 30, 2021, the Company, and ADVA Optical Networking SE, a European stock corporation incorporated under the laws of the European Union and Germany (“ADVA”), entered into a business combination agreement (the “Business Combination Agreement”), pursuant to which both companies agreed to combine their respective businesses and each become subsidiaries of a new holding company, Acorn HoldCo, Inc. (the "surviving corporation"), a Delaware corporation and currently a wholly-owned direct subsidiary of the Company.

- changed (2022-05-06):
[0000950170-22-008077:note_history:4]
Under the terms of the Business Combination Agreement, Acorn MergeCo, Inc., a newly formed Delaware corporation and wholly-owned direct subsidiary of Acorn HoldCo (“Merger Sub”), will merge with and into ADTRAN, with ADTRAN surviving the merger (the “Merger”) as a wholly-owned direct subsidiary of Acorn HoldCo. Pursuant to the Merger, each outstanding share of common stock of the Company will be converted into the right to receive one share of common stock of Acorn HoldCo. Acorn HoldCo has also made a public exchange offer to exchange each issued and outstanding no-par value bearer share of ADVA, pursuant to which each ADVA share tendered and accepted for exchange will be exchanged for 0.8244 shares of common stock of Acorn HoldCo (the “Exchange Offer”, and together with the Merger, the “Business Combination”). Upon completion of the Business Combination, and assuming that all of the outstanding ADVA shares are exchanged in the Exchange Offer, former ADTRAN stockholders and former ADVA shareholders will own approximately 54% and 46%, respectively, of the outstanding Acorn HoldCo shares.
  (was, 2021-11-05, similarity 0.9886):
[0000950170-21-003219:note_history:4]
Under the terms of the Business Combination Agreement, Acorn MergeCo, Inc., a newly formed Delaware corporation and wholly-owned direct subsidiary of Acorn HoldCo (“Merger Sub”), will merge with and into ADTRAN, with ADTRAN surviving the merger (the “Merger”) as a wholly-owned direct subsidiary of Acorn HoldCo. Pursuant to the Merger, each outstanding share of common stock of the Company will be converted into the right to receive one share of common stock of Acorn HoldCo. Acorn HoldCo will also make a public exchange offer to exchange each issued and outstanding no-par value bearer share of ADVA, pursuant to which each ADVA share tendered and accepted for exchange will be exchanged for 0.8244 shares of common stock of Acorn HoldCo (the “Exchange Offer”, and together with the Merger, the “Business Combination”). Upon completion of the Business Combination, and assuming that all of the outstanding ADVA shares are exchanged in the Exchange Offer, former ADTRAN stockholders and former ADVA shareholders will own approximately 54% and 46%, respectively, of the outstanding Acorn HoldCo shares.

- added (2022-05-06):
[0000950170-22-008077:note_history:5]
The Business Combination Agreement was unanimously approved by the Board of Directors of the Company and by the supervisory board and management board of ADVA. On January 6, 2022, the Company's stockholders approved the Business Combination by an overwhelming majority. The end of the ADVA shareholder tender offer acceptance period was on January 26, 2022, which resulted in the acceptance of the Exchange Offer by more than 60% of all shares of ADVA entitled to voting rights existing as of October 31, 2021, thus exceeding the required minimum acceptance threshold. According to the rules of the German Securities Acquisition and Takeover Act, ADVA shareholders who did not tender their shares during the initial acceptance period could do so during a two-week additional acceptance period that began on February 1, 2022 and ended February 14, 2022. This resulted in the acceptance of the Exchange Offer by approximately 66% of all shares of ADVA entitled to voting rights existing as of November 30, 2021. On January 24, 2022, the Committee on Foreign Investment in the U.S. ("CFIUS") completed its review of the Business Combination and determined that the transaction was not a “covered transaction” subject to CFIUS’ jurisdiction, satisfying the condition of the Business Combination Agreement related to CFIUS notification. On February 16, 2022, the U.K. Secretary of State for Business, Energy and Industrial Strategy completed its review of the Business Combination and determined that the Secretary of State will be taking no further action under the NS&I Act, satisfying the condition of the Business Combination Agreement related to NS&I Act approval. Cooperative proceedings continue with the foreign direct investment authorities in Germany.

- added (2022-05-06):
[0000950170-22-008077:note_history:6]
The Company anticipates the consummation of the Business Combination around the middle of 2022, subject to customary closing conditions, and regulatory approvals from the foreign direct investment authorities in Germany.

- changed (2022-05-06):
[0000950170-22-008077:note_history:7]
Additional information about the Business Combination Agreement and proposed Business Combination is set forth in the Company’s filings with the SEC, as well as in the registration statement on Form S-4 that Acorn HoldCo filed with the SEC, which was declared effective December 2, 2021 (the “Acorn HoldCo Registration Statement”).
  (was, 2021-11-05, similarity 0.8557):
[0000950170-21-003219:note_history:7]
Additional information about the Business Combination Agreement and proposed Business Combination is set forth in the Company’s filings with the SEC, as well as in the registration statement on Form S-4 that Acorn HoldCo filed with the SEC, which has not yet become effective.

- changed (2022-05-06):
[0000950170-22-008077:note_history:8]
Certain contracts, customers and jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of March 31, 2022 and December 31, 2021, we had commitments related to these bonds totaling $20.9 million and $22.9 million, respectively, which expire at various dates through April 2025. In general we would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which we believe is remote.
  (was, 2021-11-05, similarity 0.9662):
[0000950170-21-003219:note_history:8]
Certain contracts, customers and jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of September 30, 2021 and December 31, 2020, we had commitments related to these bonds totaling $20.9 million and $15.2 million, respectively, which expire at various dates through August 2024. In general we would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which we believe is remote.

- changed (2022-05-06):
[0000950170-22-008077:note_history:9]
In June 2020, the Company entered into a letter of credit with a bank to guarantee performance obligations under a contract with a certain customer. The obligations under this customer contract will be performed over multiple years. We reached the maximum value of our minimum collateral requirement of $15.0 million during the three months ended March 31, 2021 as the Company reached certain milestones through the first quarter of 2021 as outlined in the customer contract. The letter of credit was secured by a pledge of a portion of the Company’s fixed-income securities, which totaled $18.0 million as of March 31, 2022, of which $0.1 million is included in restricted cash and $17.9 million is included in long-term investments on the Condensed Consolidated Balance Sheets. This pledged collateral value will fluctuate as the Company changes the mix of the pledged collateral between restricted cash and investments. Any shortfalls in the minimum collateral value are required to be restored by the Company from available cash and cash equivalents, short-term investments and/or long-term investments. The collateral under the letter of credit will be released when all obligations under the customer contract have been met. As of March 31, 2022, the Company believes it was in compliance with all contractual requirements under the letter of credit.
  (was, 2021-11-05, similarity 0.933):
[0000950170-21-003219:note_history:9]
In June 2020, the Company entered into a letter of credit with a bank to guarantee performance obligations under a contract with a certain customer. The obligations under this customer contract will be performed over multiple years. We reached the maximum value of our minimum collateral requirement of $15.0 million during the three months ended March 31, 2021 as the Company reached certain milestones through the first quarter of 2021 as outlined in the customer contract. The letter of credit was secured by a pledge of a portion of the Company’s fixed-income securities, which totaled $18.4 million as of September 30, 2021, of which $0.1 million is included in restricted cash and $18.3 million is included in long-term investments on the Condensed Consolidated Balance Sheets. This pledged collateral value will fluctuate as the Company changes the mix of the pledged collateral between restricted cash and investments. Any shortfalls in the minimum collateral value are required to be restored by the Company from available cash and cash equivalents, short-term investments and/or long-term investments. The collateral under the letter of credit will be released when all obligations under the

- changed (2022-05-06):
[0000950170-22-008077:note_history:10]
We have committed to invest up to an aggregate of $5.0 million in a private equity fund, of which $4.9 million has been invested as of March 31, 2022.
  (was, 2021-11-05, similarity 0.9648):
[0000950170-21-003219:note_history:10]
We have committed to invest up to an aggregate of $5.0 million in a private equity fund, of which $4.9 million has been invested as of September 30, 2021.

- removed (2022-05-06):
[0000950170-21-003219:note_history:11]
The Business Combination Agreement was unanimously approved by the Board of Directors of the Company and by the supervisory board and management board of ADVA. The Company anticipates consummation of the Business Combination during mid-2022, subject to customary closing conditions as well as regulatory and shareholder approvals.

- removed (2022-05-06):
[0000950170-21-003219:note_history:12]
Acorn HoldCo has entered into an irrevocable undertaking agreement (the “Irrevocable Undertaking”) with EGORA Holding GmbH and Egora Investments GmbH (collectively, the “Supporting Shareholders”) to validly accept the public exchange offer with respect to 7,000,000 shares held by them, representing 13.7% of the share capital of ADVA. The Irrevocable Undertaking includes other customary provisions, including certain restrictions on the Supporting Shareholders from disposing of the relevant shares.

- removed (2022-05-06):
[0000950170-21-003219:note_history:13]
customer contract have been met. As of September 30, 2021, the Company was in compliance with all contractual requirements under the letter of credit.


## us-gaap:SummaryOfIncomeTaxContingenciesTextBlock (contingencies) — matched_by: no_current_note, score: 0.0

- removed (2022-05-06):
[0000950170-21-003219:note_history:14]
The change in the unrecognized income tax benefits for the nine months ended September 30, 2021 and year ended December 31, 2020, is reconciled below:

- removed (2022-05-06):
[0000950170-21-003219:note_history:15]
| (In thousands) |  | For the Nine Months Ended September 30, 2021 |  |  | For the Year Ended December 31, 2020 |  |
| Balance at beginning of period |  | $ | 1,078 |  |  | $ | 1,487 |  |
| Increases for tax position related to: |  |  |  |  |  |  |
| Prior years |  |  | 17,025 |  |  |  | 4 |  |
| Current year |  |  | 102 |  |  |  | 165 |  |
| Decreases for tax positions related to: |  |  |  |  |  |  |
| Prior years |  |  | (27 | ) |  |  | — |  |
| Expiration of applicable statute of limitations |  |  | — |  |  |  | (578 | ) |
| Balance at end of period |  | $ | 18,178 |  |  | $ | 1,078 |  |


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2022-05-06):
[0000950170-22-008077:note_history:16]
The accompanying unaudited condensed consolidated financial statements of ADTRAN®, Inc. and its subsidiaries (“ADTRAN”, the “Company”, “we”, “our” or “us”) have been prepared pursuant to the rules and regulations of the Securities and Exchange Commission (the “SEC”) applicable to interim financial information presented in Quarterly Reports on Form 10-Q. Accordingly, certain information and notes required by generally accepted accounting principles in the United States of America (“U.S. GAAP”) for complete financial statements are not included herein. Certain prior year amounts have been reclassified to conform to the current period presentation. The December 31, 2021 Condensed Consolidated Balance Sheet is derived from audited financial statements but does not include all disclosures required by U.S. GAAP.
  (was, 2021-11-05, similarity 0.9364):
[0000950170-21-003219:note_history:16]
The accompanying unaudited condensed consolidated financial statements of ADTRAN®, Inc. and its subsidiaries (“ADTRAN”, the “Company”, “we”, “our” or “us”) have been prepared pursuant to the rules and regulations of the Securities and Exchange Commission (the “SEC”) applicable to interim financial information presented in Quarterly Reports on Form 10-Q. Accordingly, certain information and notes required by generally accepted accounting principles in the United States of America (“U.S. GAAP”) for complete financial statements are not included herein. The December 31, 2020 Condensed Consolidated Balance Sheet is derived from audited financial statements but does not include all disclosures required by U.S. GAAP.

- changed (2022-05-06):
[0000950170-22-008077:note_history:17]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenue and expense during the reporting period. Significant estimates include excess and obsolete inventory reserves, warranty reserves, customer rebates, determination and accrual of the deferred revenue related to performance obligations under contracts with customers, estimated costs to complete obligations associated with deferred and accrued revenues and network installations, estimated income tax provision and income tax contingencies, fair value of stock-based compensation, assessment of goodwill and other intangibles for impairment, estimated lives of intangible assets, estimated pension liability and fair value of investments. Actual amounts could differ significantly from these estimates.
  (was, 2021-11-05, similarity 0.9233):
[0000950170-21-003219:note_history:17]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenue and expense during the reporting period. The more significant estimates include excess and obsolete inventory reserves, warranty reserves, customer rebates, determination and accrual of deferred revenue components of multi-element sales agreements, estimated costs to complete obligations associated with deferred and accrued revenues and network installations, estimated income tax provision and income tax contingencies, fair value of stock-based compensation, assessment of goodwill and other intangibles for impairment, estimated lives of intangible assets, estimated pension liability and fair value of investments. Actual amounts could differ significantly from these estimates.

- changed (2022-05-06):
[0000950170-22-008077:note_history:18]
We assessed certain accounting matters that generally require consideration of forecasted financial information in context with the information reasonably available to us and the unknown future impacts of the SARS-CoV-2 coronavirus/COVID-19 global pandemic (or variants of the SARS-CoV-2 coronavirus) as well as supply chain constraints as of March 31, 2022 and through the date of this report. The accounting matters assessed included, but were not limited to, the allowance for credit losses, stock-based compensation, carrying value of goodwill, intangibles and other long-lived assets, financial assets, valuation allowances for tax assets, revenue recognition and costs of revenue. Future conditions related to the magnitude and duration of the COVID-19 pandemic, as well as other factors, including supply chain constraints, could result in further impacts to our consolidated financial statements in future reporting periods.
  (was, 2021-11-05, similarity 0.9725):
[0000950170-21-003219:note_history:18]
We assessed certain accounting matters that generally require consideration of forecasted financial information in context with the information reasonably available to us and the unknown future impacts of the SARS-CoV-2 coronavirus/COVID-19 global pandemic (or variants of the SARS-CoV-2 coronavirus, including the Delta variant) as well as supply chain constraints as of September 30, 2021 and through the date of this report. The accounting matters assessed included, but were not limited to, the allowance for expected credit losses, stock-based compensation, carrying value of goodwill, intangibles and other long-lived assets, financial assets, valuation allowances for tax assets, revenue recognition and costs of revenue. Future conditions related to the magnitude and duration of the COVID-19 pandemic, as well as other factors, including supply chain constraints, could result in further impacts to our consolidated financial statements in future reporting periods.

- changed (2022-05-06):
[0000950170-22-008077:note_history:19]
There are currently no recently adopted accounting pronouncements that had a material effect on the condensed consolidated financial statements.
  (was, 2021-11-05, similarity 0.629):
[0000950170-21-003219:note_history:19]
We recently adopted the following accounting standards, which had the following impacts on our condensed consolidated financial statements:

- added (2022-05-06):
[0000950170-22-008077:note_history:20]
In October 2021, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update ("ASU") 2021-08, Business Combinations (Topic 805) Accounting for Contract Assets and Contract Liabilities from Contracts with Customers, which would require an acquirer to recognize and measure acquired contract assets and contract liabilities in a manner consistent with how the acquiree recognized and measured them in its pre-acquisition financial statements in accordance with Topic 606, Revenue Recognition. ASU 2021-08 is effective for annual periods beginning after December 15, 2022, including interim periods within those fiscal years. Adoption of the ASU should be applied prospectively. Early adoption is also permitted, including adoption in an interim period. If early adopted, the amendments are applied retrospectively to all business combinations for which the acquisition date occurred during the fiscal year of adoption. The Company plans to early adopt ASU 2021-08 in the event that the Business Combination Agreement with ADVA closes during 2022. However, we are unable to estimate the effect on our Condensed Consolidated Financial Statements as of the date of this report.

- removed (2022-05-06):
[0000950170-21-003219:note_history:21]
Correction of an Immaterial Misstatement

- removed (2022-05-06):
[0000950170-21-003219:note_history:22]
During the three months ended March 31, 2020, it was determined that certain investments held in the Company’s stock for a deferred compensation plan accounted for as a Rabbi trust were incorrectly classified as long-term investments with the fair value of such investments incorrectly marked to market at each period end rather than classified as Treasury stock held at historical cost. This plan has been in existence since 2011. The Company corrected this misstatement as an out-of-period adjustment in the three months ended March 31, 2020 by remeasuring the investment assets to their historical cost basis through the recording of a net investment gain of $1.5 million in the unaudited Condensed Consolidated Statement of Income (Loss) and then correcting the classification by decreasing the long-term investment balance at its remeasured cost basis of $2.8 million to Treasury stock in the unaudited Condensed Consolidated Balance Sheet as of March 31, 2020. Management has determined that this misstatement was not material to any of its previously issued financial statements and that the correction of the misstatement was not material to the Company’s 2020 annual financial results on either a quantitative or qualitative basis.

- removed (2022-05-06):
[0000950170-21-003219:note_history:23]
In August 2018, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2018-14, Compensation – Retirement Benefits – Defined Benefit Plans – General (Subtopic 715-20): Disclosure Framework – Changes to the Disclosure Requirements for Defined Benefit Plans, which makes changes to and clarifies the disclosure requirements related to defined benefit pension and other postretirement plans. ASU 2018-14 requires additional disclosures related to the reasons for significant gains and losses affecting the benefit obligation and an explanation of any other significant changes in the benefit obligation or plan assets that are not otherwise apparent in other disclosures required by Accounting Standards Codification (“ASC”) 715. ASU 2018-14 also clarifies the guidance in ASC 715 to require disclosure of the projected benefit obligation (“PBO”) and fair value of plan assets for pension plans with PBOs in excess of plan assets and the accumulated benefit obligation (“ABO”) and fair value of plan assets for pension plans with ABOs in excess of plan assets. ASU 2018-14 became effective for public business entities for fiscal years ending after December 15, 2020. The adoption of this standard did not have a material effect on the disclosures in the condensed consolidated financial statements.

- removed (2022-05-06):
[0000950170-21-003219:note_history:24]
In December 2019, the FASB issued ASU 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes, which simplifies the accounting for income taxes by removing various exceptions, such as the exception to the incremental approach for intra-period tax allocation when there is a loss from continuing operations and income or a gain from other items. The amendments in this update also simplify the accounting for income taxes related to income-based franchise taxes and require that an entity reflect enacted tax laws or rates in the annual effective tax rate computation in the interim period that includes the enactment date. The Company early adopted ASU 2019-12 on April 1, 2020, which was applied on a prospective basis as if the Company adopted the standard on January 1, 2020. The Company early adopted the standard to take advantage of the simplification of rules for income taxes on intra-period tax allocations. Specifically, the adoption of this standard resulted in the recognition of approximately $0.1 million of tax benefit in other comprehensive income (loss) for the three months ended March 31, 2020, that otherwise would have been recognized in continuing operations had the intra-period tax allocation been completed. There were no other impacts from this standard on the condensed consolidated financial statements.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-05-06):
[0000950170-22-008077:note_history:25]
12. CADENCE REVOLVING CREDIT AGREEMENT
  (was, 2021-11-05, similarity 0.875):
[0000950170-21-003219:note_history:25]
12. REVOLVING CREDIT AGREEMENT

- changed (2022-05-06):
[0000950170-22-008077:note_history:26]
On November 2, 2021, the Company, as borrower, renewed its Revolving Credit and Security Agreement and related Promissory Note (together, the “Cadence Revolving Credit Agreement”) with Cadence Bank, N.A., as lender (the “Cadence Lender”). The Cadence Revolving Credit Agreement provides the Company with a $10.0 million secured revolving credit facility. Loans under the Cadence Revolving Credit Agreement will bear interest at a rate equal to 1.50% over the screen rate as obtained by Reuter’s, Bloomberg or another commercially available source as may be designated by the Cadence Lender from time to time; provided, however, that in no event shall the applicable rate of interest under the Cadence Revolving Credit Agreement be less than 1.50% per annum. Such loans are secured by all of the cash, securities, securities entitlements and investment property in a certain bank account, as outlined in the Cadence Revolving Credit Agreement, at a maximum loan-to-value ratio of 75% determined by dividing the full commitment amount under the Cadence Revolving Credit Agreement on the date of testing, determined by the Cadence Lender each fiscal quarter, by the market value of the collateral. The Cadence Revolving Credit Agreement matures on November 3, 2022, subject to earlier termination upon the concurrence of certain events of default. The Company entered into the Cadence Revolving Credit Agreement in order to increase the flexibility and management of its short-term liquidity. During the first quarter of 2022, the Company made draws totaling $8.0 million under the Cadence Revolving Credit Agreement all of which had been repaid as of March 31, 2022. The Company agreed to certain negative covenants that are customary for credit arrangements of this type, including, among other things, restrictions on the Company’s ability to enter into mergers, acquisitions or other business combination transactions, grant liens or suffer a material adverse change in the condition or affairs (financial or otherwise) of the Company. As of March 31, 2022, the Company was in compliance with all contractual requirements under the Cadence Revolving Credit Agreement.
  (was, 2021-11-05, similarity 0.7189):
[0000950170-21-003219:note_history:26]
On November 4, 2020, the Company, as borrower, entered into a Revolving Credit and Security Agreement and related Promissory Note (together, the “Revolving Credit Agreement”) with Cadence Bank, N.A., as lender (the “Lender”). The Revolving Credit Agreement provides the Company with a new $10.0 million secured revolving credit facility. Loans under the Revolving Credit Agreement will bear interest at a rate equal to 1.50% over the screen rate as obtained by Reuter’s, Bloomberg or another commercially available source as may be designated by the Lender from time to time; provided, however, that in no event shall the applicable rate of interest under the Revolving Credit Agreement be less than 1.50% per annum. Such loans are secured by all of the cash, securities, securities entitlements and investment property in a certain bank account, as outlined in the Revolving Credit Agreement, at a maximum loan-to-value ratio of 75% determined by dividing the full commitment amount under the Revolving Credit Agreement on the date of testing, determined by the Lender each fiscal quarter, by the market value of the collateral. The Revolving Credit Agreement matures on November 4, 2021, subject to earlier termination upon the occurrence of certain events of default. The Company had not made any draws under the Revolving Credit Agreement as of September 30, 2021.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2022-05-06):
[0000950170-22-008077:note_history:27]
|  |  | As of March 31, 2022 |  |
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 9,299 |  |  | $ | 1 |  |  | $ | (206 | ) |  | $ | 9,094 |  |
| Municipal fixed-rate bonds |  |  | 1,684 |  |  |  | — |  |  |  | (37 | ) |  |  | 1,647 |  |
| Asset-backed bonds |  |  | 318 |  |  |  | — |  |  |  | (11 | ) |  |  | 307 |  |
| Mortgage/Agency-backed bonds |  |  | 4,703 |  |  |  | 1 |  |  |  | (142 | ) |  |  | 4,562 |  |
| U.S. government bonds |  |  | 14,000 |  |  |  | — |  |  |  | (446 | ) |  |  | 13,554 |  |
| Foreign government bonds |  |  | 411 |  |  |  | — |  |  |  | (17 | ) |  |  | 394 |  |
| Available-for-sale debt securities held at fair value |  | $ | 30,415 |  |  | $ | 2 |  |  | $ | (859 | ) |  | $ | 29,558 |  |
  (was, 2021-11-05, similarity 0.8479):
[0000950170-21-003219:note_history:27]
|  |  | As of September 30, 2021 |  |
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 13,381 |  |  | $ | 39 |  |  | $ | (6 | ) |  | $ | 13,414 |  |
| Municipal fixed-rate bonds |  |  | 2,236 |  |  |  | 13 |  |  |  | (1 | ) |  |  | 2,248 |  |
| Asset-backed bonds |  |  | 3,497 |  |  |  | 17 |  |  |  | (1 | ) |  |  | 3,513 |  |
| Mortgage/Agency-backed bonds |  |  | 9,194 |  |  |  | 35 |  |  |  | (17 | ) |  |  | 9,212 |  |
| U.S. government bonds |  |  | 16,031 |  |  |  | 34 |  |  |  | (13 | ) |  |  | 16,052 |  |
| Foreign government bonds |  |  | 544 |  |  |  | 1 |  |  |  | (2 | ) |  |  | 543 |  |
| Other |  |  | 533 |  |  |  | — |  |  |  | — |  |  |  | 533 |  |
| Available-for-sale debt securities held at fair value |  | $ | 45,416 |  |  | $ | 139 |  |  | $ | (40 | ) |  | $ | 45,515 |  |

- changed (2022-05-06):
[0000950170-22-008077:note_history:28]
|  |  | As of December 31, 2021 |  |
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 10,776 |  |  | $ | 6 |  |  | $ | (35 | ) |  | $ | 10,747 |  |
| Municipal fixed-rate bonds |  |  | 1,553 |  |  |  | 2 |  |  |  | (4 | ) |  |  | 1,551 |  |
| Asset-backed bonds |  |  | 322 |  |  |  | 3 |  |  |  | (3 | ) |  |  | 322 |  |
| Mortgage/Agency-backed bonds |  |  | 4,754 |  |  |  | 15 |  |  |  | (33 | ) |  |  | 4,736 |  |
| U.S. government bonds |  |  | 12,251 |  |  |  | 12 |  |  |  | (92 | ) |  |  | 12,171 |  |
| Foreign government bonds |  |  | 543 |  |  |  | — |  |  |  | (4 | ) |  |  | 539 |  |
| Available-for-sale debt securities held at fair value |  | $ | 30,199 |  |  | $ | 38 |  |  | $ | (171 | ) |  | $ | 30,066 |  |
  (was, 2021-11-05, similarity 0.8688):
[0000950170-21-003219:note_history:28]
|  |  | As of December 31, 2020 |  |
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 11,762 |  |  | $ | 123 |  |  | $ | — |  |  | $ | 11,885 |  |
| Municipal fixed-rate bonds |  |  | 2,854 |  |  |  | 30 |  |  |  | — |  |  |  | 2,884 |  |
| Asset-backed bonds |  |  | 6,634 |  |  |  | 74 |  |  |  | — |  |  |  | 6,708 |  |
| Mortgage/Agency-backed bonds |  |  | 11,536 |  |  |  | 114 |  |  |  | (6 | ) |  |  | 11,644 |  |
| U.S. government bonds |  |  | 9,763 |  |  |  | 112 |  |  |  | — |  |  |  | 9,875 |  |
| Foreign government bonds |  |  | 1,334 |  |  |  | 4 |  |  |  | (1 | ) |  |  | 1,337 |  |
| Commercial Paper |  |  | 250 |  |  |  | — |  |  |  | — |  |  |  | 250 |  |
| Other |  |  | 533 |  |  |  | — |  |  |  | — |  |  |  | 533 |  |
| Available-for-sale debt securities held at fair value |  | $ | 44,666 |  |  | $ | 457 |  |  | $ | (7 | ) |  | $ | 45,116 |  |

- changed (2022-05-06):
[0000950170-22-008077:note_history:29]
|  |  | As of March 31, 2022 |
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset-backed bonds |  |  | Mortgage/ Agency-backed bonds |  |  | U.S. government bonds |  |  | Foreign government bonds |  |  |
| Less than one year |  | $ | 295 |  |  | $ | 269 |  |  | $ | — |  |  | $ | 1,050 |  |  | $ | 979 |  |  | $ | — |  |  |
| One to two years |  |  | 5,965 |  |  |  | 1,265 |  |  |  | — |  |  |  | 479 |  |  |  | 4,800 |  |  |  | — |  |  |
| Two to three years |  |  | 2,596 |  |  |  | 113 |  |  |  | — |  |  |  | 289 |  |  |  | 7,106 |  |  |  | 394 |  |  |
| Three to five years |  |  | 238 |  |  |  | — |  |  |  | 49 |  |  |  | 371 |  |  |  | 669 |  |  |  | — |  |  |
| Five to ten years |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 915 |  |  |  | — |  |  |  | — |  |  |
| More than ten years |  |  | — |  |  |  | — |  |  |  | 258 |  |  |  | 1,458 |  |  |  | — |  |  |  | — |  |  |
| Total |  | $ | 9,094 |  |  | $ | 1,647 |  |  | $ | 307 |  |  | $ | 4,562 |  |  | $ | 13,554 |  |  | $ | 394 |  |  |
  (was, 2021-11-05, similarity 0.8167):
[0000950170-21-003219:note_history:29]
|  |  | As of September 30, 2021 |  |
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset-backed bonds |  |  | Mortgage/ Agency-backed bonds |  |  | U.S. government bonds |  |  | Foreign government bonds |  |  | Other |  |
| Less than one year |  | $ | 275 |  |  | $ | 652 |  |  | $ | — |  |  | $ | 638 |  |  | $ | 2,593 |  |  | $ | — |  |  | $ | 533 |  |
| One to two years |  |  | 4,494 |  |  |  | 534 |  |  |  | — |  |  |  | 1,005 |  |  |  | 4,021 |  |  |  | 246 |  |  |  | — |  |
| Two to three years |  |  | 6,616 |  |  |  | 761 |  |  |  | 93 |  |  |  | 1,102 |  |  |  | 5,810 |  |  |  | 297 |  |  |  | — |  |
| Three to five years |  |  | 2,029 |  |  |  | 301 |  |  |  | 1,573 |  |  |  | 235 |  |  |  | 3,628 |  |  |  | — |  |  |  | — |  |
| Five to ten years |  |  | — |  |  |  | — |  |  |  | 785 |  |  |  | 1,322 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| More than ten years |  |  | — |  |  |  | — |  |  |  | 1,062 |  |  |  | 4,910 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 13,414 |  |  | $ | 2,248 |  |  | $ | 3,513 |  |  | $ | 9,212 |  |  | $ | 16,052 |  |  | $ | 543 |  |  | $ | 533 |  |

- changed (2022-05-06):
[0000950170-22-008077:note_history:30]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2022 |  |  | 2021 |  |
| Gross realized gain on debt securities |  | $ | 12 |  |  | $ | 87 |  |
| Gross realized loss on debt securities |  |  | (40 | ) |  |  | (16 | ) |
| Total (loss) gain recognized, net |  | $ | (28 | ) |  | $ | 71 |  |
  (was, 2021-11-05, similarity 0.7217):
[0000950170-21-003219:note_history:30]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Gross realized gain on debt securities |  | $ | 22 |  |  | $ | 70 |  |  | $ | 206 |  |  | $ | 303 |  |
| Gross realized loss on debt securities |  |  | (17 | ) |  |  | (6 | ) |  |  | (53 | ) |  |  | (45 | ) |
| Total gain recognized, net |  | $ | 5 |  |  | $ | 64 |  |  | $ | 153 |  |  | $ | 258 |  |

- changed (2022-05-06):
[0000950170-22-008077:note_history:31]
Income generated from available-for-sale debt securities was recorded as interest and dividend income in the Condensed Consolidated Statements of (Loss) Income. No allowance for credit losses was recorded for the three months ended March 31, 2022 and 2021 related to available-for-sale debt securities. The Company’s investment policy provides limitations for issuer concentration, which limits, at the time of purchase, the concentration in any one issuer to 5% of the market value of our total investment portfolio. The Company did not purchase any available-for-sale debt security with credit deterioration during the three months ended March 31, 2022.
  (was, 2021-11-05, similarity 0.9082):
[0000950170-21-003219:note_history:31]
Income generated from available-for-sale debt securities was recorded as interest and dividend income in the Condensed Consolidated Statements of Income (Loss). No allowance for credit loss was recorded for the nine months ended September 30, 2021 and 2020 related to available-for-sale debt securities. The Company’s investment policy provides limitations for issuer concentration, which limits, at the time of purchase, the concentration in any one issuer to 5% of the market value of our total investment portfolio. The Company did not purchase any available-for-sale debt security with credit deterioration during the nine months ended September 30, 2021.

- added (2022-05-06):
[0000950170-22-008077:note_history:32]
The Company has an equity investment which does not have a readily determinable fair value, and is recorded using the measurement alternative. Under the measurement alternative, equity investments that do not have a readily determinable fair value can be recorded at cost less impairment, if any, adjusted for observable price changes for an identical or similar investment. The carrying value of the equity investment as of March 31, 2022 and December 31, 2021 was $1.0 million. During the year ended December 31, 2021, impairment charges totaling $0.4 million, were recorded related to the equity investment. As of March 31 2022, cumulative impairment charges totaling $2.4 million were recorded related to the equity investment. There were no impairment charges during the three months ended March 31, 2022 and 2021. During the year ended December 31, 2021, an unsecured loan totaling $0.5 million was converted to equity which increased the Company's carrying value of the equity investment.

- added (2022-05-06):
[0000950170-22-008077:note_history:33]
The Company has a secured note receivable as of March 31, 2022 and December 31, 2021 which totaled $0.4 million and is included in long term investments on the Consolidated Balance Sheets. During the year ended December 31, 2021, an impairment charge of $0.5 million was recognized against the secured note receivable. There were no impairment charges during the three months ended March 31, 2022 and 2021.

- added (2022-05-06):
[0000950170-22-008077:note_history:34]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2022 |  |  | 2021 |  |
| Realized (loss) gain on equity securities sold |  | $ | (25 | ) |  | $ | 24 |  |
| Unrealized (loss) gain on equity securities held |  |  | (3,362 | ) |  |  | 901 |  |
| Total (loss) gain recognized, net |  | $ | (3,387 | ) |  | $ | 925 |  |

- changed (2022-05-06):
[0000950170-22-008077:note_history:35]
Income generated from marketable equity securities was recorded as interest and dividend income in the Condensed Consolidated Statements of (Loss) Income. U.S. GAAP establishes a three-level valuation hierarchy based upon observable and unobservable inputs for fair value measurement of financial instruments:
  (was, 2021-11-05, similarity 0.9773):
[0000950170-21-003219:note_history:35]
Income generated from marketable equity securities was recorded as interest and dividend income in the Condensed Consolidated Statements of Income (Loss). U.S. GAAP establishes a three-level valuation hierarchy based upon observable and unobservable inputs for fair value measurement of financial instruments:

- changed (2022-05-06):
[0000950170-22-008077:note_history:36]
|  |  |  |  |  | Fair Value Measurements as of March 31, 2022 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket for IdenticalAssets (Level 1) |  |  | SignificantOtherObservableInputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 457 |  |  | $ | 457 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 9,094 |  |  |  | — |  |  |  | 9,094 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 1,647 |  |  |  | — |  |  |  | 1,647 |  |  |  | — |  |
| Asset-backed bonds |  |  | 307 |  |  |  | — |  |  |  | 307 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 4,562 |  |  |  | — |  |  |  | 4,562 |  |  |  | — |  |
| U.S. government bonds |  |  | 13,554 |  |  |  | 13,554 |  |  |  |  |  |  | — |  |
| Foreign government securities |  |  | 394 |  |  |  | — |  |  |  | 394 |  |  |  | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 11,143 |  |  |  | 11,143 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 26,081 |  |  |  | 26,081 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 67,239 |  |  | $ | 51,235 |  |  | $ | 16,004 |  |  | $ | — |  |
  (was, 2021-11-05, similarity 0.6631):
[0000950170-21-003219:note_history:36]
|  |  |  |  |  | Fair Value Measurements as of September 30, 2021 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket for IdenticalAssets (Level 1) |  |  | SignificantOtherObservableInputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 532 |  |  | $ | 532 |  |  | $ | — |  |  | $ | — |  |
| Commercial paper |  |  | 400 |  |  |  | — |  |  |  | 400 |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 13,414 |  |  |  | — |  |  |  | 13,414 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 2,248 |  |  |  | — |  |  |  | 2,248 |  |  |  | — |  |
| Asset-backed bonds |  |  | 3,513 |  |  |  | — |  |  |  | 3,513 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 9,212 |  |  |  | — |  |  |  | 9,212 |  |  |  | — |  |
| U.S. government bonds |  |  | 16,052 |  |  |  | 16,052 |  |  |  | — |  |  |  | — |  |
| Foreign government securities |  |  | 543 |  |  |  | — |  |  |  | 543 |  |  |  | — |  |
| Other |  |  | 533 |  |  |  | — |  |  |  | — |  |  |  | 533 |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 12,144 |  |  |  | 12,144 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 25,733 |  |  |  | 25,733 |  |  |  | — |  |  |  | — |  |
| Other investments |  |  | 1,400 |  |  |  | 1,400 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 85,724 |  |  | $ | 55,861 |  |  | $ | 29,330 |  |  | $ | 533 |  |

- changed (2022-05-06):
[0000950170-22-008077:note_history:37]
|  |  |  |  |  | Fair Value Measurements as of December 31, 2021 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket for IdenticalAssets (Level 1) |  |  | SignificantOtherObservableInputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 652 |  |  | $ | 652 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 10,747 |  |  |  | — |  |  |  | 10,747 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 1,551 |  |  |  | — |  |  |  | 1,551 |  |  |  | — |  |
| Asset-backed bonds |  |  | 322 |  |  |  | — |  |  |  | 322 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 4,736 |  |  |  | — |  |  |  | 4,736 |  |  |  | — |  |
| U.S. government bonds |  |  | 12,171 |  |  |  | 12,171 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 539 |  |  |  | — |  |  |  | 539 |  |  |  | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 12,606 |  |  |  | 12,606 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 26,935 |  |  |  | 26,935 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 70,259 |  |  | $ | 52,364 |  |  | $ | 17,895 |  |  | $ | — |  |
  (was, 2021-11-05, similarity 0.9004):
[0000950170-21-003219:note_history:37]
|  |  |  |  |  | Fair Value Measurements as of December 31, 2020 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket for IdenticalAssets (Level 1) |  |  | SignificantOtherObservableInputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 497 |  |  | $ | 497 |  |  | $ | — |  |  | $ | — |  |
| U.S. government bonds |  |  | 350 |  |  |  | 350 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 11,885 |  |  |  | — |  |  |  | 11,885 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 2,884 |  |  |  | — |  |  |  | 2,884 |  |  |  | — |  |
| Asset-backed bonds |  |  | 6,708 |  |  |  | — |  |  |  | 6,708 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 11,644 |  |  |  | — |  |  |  | 11,644 |  |  |  | — |  |
| U.S. government bonds |  |  | 9,875 |  |  |  | 9,875 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 1,337 |  |  |  | — |  |  |  | 1,337 |  |  |  | — |  |
| Commercial paper |  |  | 250 |  |  |  | — |  |  |  | 250 |  |  |  | — |  |
| Other |  |  | 533 |  |  |  | — |  |  |  | — |  |  |  | 533 |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 10,963 |  |  |  | 10,963 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 23,891 |  |  |  | 23,891 |  |  |  | — |  |  |  | — |  |
| Other investments |  |  | 1,400 |  |  |  | 1,400 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 82,217 |  |  | $ | 46,976 |  |  | $ | 34,708 |  |  | $ | 533 |  |

- removed (2022-05-06):
[0000950170-21-003219:note_history:38]
In March 2019, an outstanding note receivable of $4.3 million owed to the Company was repaid and reissued in the form of debt and equity. Of the outstanding $4.3 million, $3.4 million was issued as an equity investment. The Company elected to record this equity investment that does not have a readily determinable fair value using the measurement alternative. Under the measurement alternative, equity investments that do not have a readily determinable fair value can be recorded at cost less impairment, if any, adjusted for observable price changes for an identical or similar investment. During the year ended December 31, 2020, impairment charges totaling $2.6 million were recorded related to this equity investment, which was included in net investment gain (loss) on the Condensed Consolidated Statement of Income (Loss). As a result, the carrying value of this investment was $0.8 million as of September 30, 2021 and December 31, 2020. The remaining amount, $0.9 million of the original $4.3 million note receivable, was reissued as a new note receivable, which is included in long-term investments on the Condensed Consolidated Balance Sheets as of September 30, 2021 and December 31, 2020. No impairment charge was recognized related to the note receivable as it is a secured loan.

- removed (2022-05-06):
[0000950170-21-003219:note_history:39]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Realized gain (loss) on equity securities sold |  | $ | — |  |  | $ | 623 |  |  | $ | (55 | ) |  | $ | (1,485 | ) |
| Unrealized (loss) gain on equity securities held |  |  | (68 | ) |  |  | 2,157 |  |  |  | 2,844 |  |  |  | 3,046 |  |
| Total gain (loss) recognized, net |  | $ | (68 | ) |  | $ | 2,780 |  |  | $ | 2,789 |  |  | $ | 1,561 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-05-06):
[0000950170-22-008077:note_history:40]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2022 |  |  | 2021 |  |
| Access & Aggregation |  | $ | 95,460 |  |  | $ | 69,074 |  |
| Subscriber Solutions & Experience |  |  | 54,606 |  |  |  | 54,569 |  |
| Traditional & Other Products |  |  | 4,452 |  |  |  | 3,890 |  |
| Total |  | $ | 154,518 |  |  | $ | 127,533 |  |
  (was, 2021-11-05, similarity 0.7686):
[0000950170-21-003219:note_history:40]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Access & Aggregation |  | $ | 89,173 |  |  | $ | 85,423 |  |  | $ | 249,211 |  |  | $ | 234,165 |  |
| Subscriber Solutions & Experience |  |  | 44,912 |  |  |  | 43,125 |  |  |  | 147,291 |  |  |  | 125,697 |  |
| Traditional & Other Products |  |  | 3,996 |  |  |  | 4,595 |  |  |  | 12,344 |  |  |  | 16,519 |  |
| Total |  | $ | 138,081 |  |  | $ | 133,143 |  |  | $ | 408,846 |  |  | $ | 376,381 |  |

- removed (2022-05-06):
[0000950170-21-003219:note_history:41]
The following tables disaggregate revenue by reportable segment and revenue category:

- removed (2022-05-06):
[0000950170-21-003219:note_history:42]
|  |  | Three Months Ended |  |
|  |  | September 30, 2021 |  |  | September 30, 2020 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 77,104 |  |  | $ | 12,069 |  |  | $ | 89,173 |  |  | $ | 71,919 |  |  | $ | 13,504 |  |  | $ | 85,423 |  |
| Subscriber Solutions & Experience |  |  | 42,093 |  |  |  | 2,819 |  |  |  | 44,912 |  |  |  | 40,843 |  |  |  | 2,282 |  |  |  | 43,125 |  |
| Traditional & Other Products |  |  | 1,570 |  |  |  | 2,426 |  |  |  | 3,996 |  |  |  | 2,467 |  |  |  | 2,128 |  |  |  | 4,595 |  |
| Total |  | $ | 120,767 |  |  | $ | 17,314 |  |  | $ | 138,081 |  |  | $ | 115,229 |  |  | $ | 17,914 |  |  | $ | 133,143 |  |

- removed (2022-05-06):
[0000950170-21-003219:note_history:43]
|  |  | Nine Months Ended |  |
|  |  | September 30, 2021 |  |  | September 30, 2020 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 215,464 |  |  | $ | 33,747 |  |  | $ | 249,211 |  |  | $ | 194,695 |  |  | $ | 39,470 |  |  | $ | 234,165 |  |
| Subscriber Solutions & Experience |  |  | 139,459 |  |  |  | 7,832 |  |  |  | 147,291 |  |  |  | 118,907 |  |  |  | 6,790 |  |  |  | 125,697 |  |
| Traditional & Other Products |  |  | 5,102 |  |  |  | 7,242 |  |  |  | 12,344 |  |  |  | 10,322 |  |  |  | 6,197 |  |  |  | 16,519 |  |
| Total |  | $ | 360,025 |  |  | $ | 48,821 |  |  | $ | 408,846 |  |  | $ | 323,924 |  |  | $ | 52,457 |  |  | $ | 376,381 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2022-05-06):
[0000950170-22-008077:note_history:44]
|  |  | Three Months Ended |  |
|  |  | March 31, 2022 |  |  | March 31, 2021 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 84,289 |  |  | $ | 11,171 |  |  | $ | 95,460 |  |  | $ | 60,053 |  |  | $ | 9,021 |  |  | $ | 69,074 |  |
| Subscriber Solutions & Experience |  |  | 51,823 |  |  |  | 2,783 |  |  |  | 54,606 |  |  |  | 52,269 |  |  |  | 2,300 |  |  |  | 54,569 |  |
| Traditional & Other Products |  |  | 2,262 |  |  |  | 2,190 |  |  |  | 4,452 |  |  |  | 1,487 |  |  |  | 2,403 |  |  |  | 3,890 |  |
| Total |  | $ | 138,374 |  |  | $ | 16,144 |  |  | $ | 154,518 |  |  | $ | 113,809 |  |  | $ | 13,724 |  |  | $ | 127,533 |  |
  (was, 2021-11-05, similarity 0.9603):
[0000950170-21-003219:note_history:44]
|  |  | Three Months Ended |  |
|  |  | September 30, 2021 |  |  | September 30, 2020 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 77,104 |  |  | $ | 12,069 |  |  | $ | 89,173 |  |  | $ | 71,919 |  |  | $ | 13,504 |  |  | $ | 85,423 |  |
| Subscriber Solutions & Experience |  |  | 42,093 |  |  |  | 2,819 |  |  |  | 44,912 |  |  |  | 40,843 |  |  |  | 2,282 |  |  |  | 43,125 |  |
| Traditional & Other Products |  |  | 1,570 |  |  |  | 2,426 |  |  |  | 3,996 |  |  |  | 2,467 |  |  |  | 2,128 |  |  |  | 4,595 |  |
| Total |  | $ | 120,767 |  |  | $ | 17,314 |  |  | $ | 138,081 |  |  | $ | 115,229 |  |  | $ | 17,914 |  |  | $ | 133,143 |  |

- added (2022-05-06):
[0000950170-22-008077:note_history:45]
The aggregate amount of transaction price allocated to remaining performance obligations that have not been satisfied as of March 31, 2022 and December 31, 2021 related to contractual maintenance agreements, contractual SaaS and subscription services, and hardware contracts that exceed one year in duration amounted to $133.1 million and $101.1 million, respectively. As of March 31, 2022, approximately 81.1% is expected to be recognized over the next 12 months and the remainder recognized thereafter. The majority of the Company's remaining performance obligations at March 31, 2022 are related to contracts or orders that have an original expected duration of one year or less, for which the Company is electing to utilize the practical expedient available within the guidance, and are excluded from the transaction price related to these future obligations. The Company will generally satisfy the remaining performance obligations as we transfer control of the products ordered or services to our customers, excluding maintenance services, which are satisfied over time.

- changed (2022-05-06):
[0000950170-22-008077:note_history:46]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | March 31, 2022 |  |  | December 31, 2021 |  |
| Accounts receivable, net |  | $ | 150,111 |  |  | $ | 158,742 |  |
| Contract assets(1) |  | $ | 8,243 |  |  | $ | 464 |  |
| Unearned revenue |  | $ | 19,454 |  |  | $ | 17,737 |  |
| Non-current unearned revenue |  | $ | 9,381 |  |  | $ | 9,271 |  |
  (was, 2021-11-05, similarity 0.9263):
[0000950170-21-003219:note_history:46]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | September 30, 2021 |  |  | December 31, 2020 |  |
| Accounts receivable, net |  | $ | 124,146 |  |  | $ | 98,827 |  |
| Contract assets(1) |  | $ | 999 |  |  | $ | 63 |  |
| Unearned revenue |  | $ | 16,394 |  |  | $ | 14,092 |  |
| Non-current unearned revenue |  | $ | 7,426 |  |  | $ | 6,888 |  |

- added (2022-05-06):
[0000950170-22-008077:note_history:47]
Of the outstanding unearned revenue balances as of December 31, 2021, $5.4 million was recognized as revenue during the three months ended March 31, 2022. Of the $14.1 million of outstanding unearned revenue balances as of December 31, 2020, $5.0 million was recognized as revenue during the three months ended March 31, 2021.

- removed (2022-05-06):
[0000950170-21-003219:note_history:48]
|  |  | Nine Months Ended |  |
|  |  | September 30, 2021 |  |  | September 30, 2020 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 215,464 |  |  | $ | 33,747 |  |  | $ | 249,211 |  |  | $ | 194,695 |  |  | $ | 39,470 |  |  | $ | 234,165 |  |
| Subscriber Solutions & Experience |  |  | 139,459 |  |  |  | 7,832 |  |  |  | 147,291 |  |  |  | 118,907 |  |  |  | 6,790 |  |  |  | 125,697 |  |
| Traditional & Other Products |  |  | 5,102 |  |  |  | 7,242 |  |  |  | 12,344 |  |  |  | 10,322 |  |  |  | 6,197 |  |  |  | 16,519 |  |
| Total |  | $ | 360,025 |  |  | $ | 48,821 |  |  | $ | 408,846 |  |  | $ | 323,924 |  |  | $ | 52,457 |  |  | $ | 376,381 |  |

- removed (2022-05-06):
[0000950170-21-003219:note_history:49]
Revenue allocated to remaining performance obligations represents contract revenue that has not yet been recognized for contracts with a duration of greater than one year. As of September 30, 2021, we did not have any significant performance obligations related to customer contracts that had an original expected duration of one year or more, other than maintenance services, which are satisfied over time. As a practical expedient, for certain contracts we recognize revenue equal to the amounts that we are entitled to invoice, which correspond to the value of completed performance obligations to date. The amount related to these performance obligations was $20.7 million and $17.7 million as of September 30, 2021 and December 31, 2020, respectively. The Company expects to recognize 64% of the $20.7 million as of September 30, 2021 over the next 12 months, with the remainder to be recognized thereafter.

- removed (2022-05-06):
[0000950170-21-003219:note_history:50]
Of the outstanding unearned revenue balances as of December 31, 2020, $2.0 million and $9.8 million were recognized as revenue during the three and nine months ended September 30, 2021, respectively.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2022-05-06):
[0000950170-22-008077:note_history:51]
On May 4, 2022, we announced that our Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to the Company’s stockholders of record as of the close of business on May 19, 2022. The payment date will be June 2, 2022 in the aggregate amount of approximately $4.4 million.
  (was, 2021-11-05, similarity 0.9078):
[0000950170-21-003219:note_history:51]
On November 1, 2021, we announced that our Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to the Company’s stockholders of record as of the close of business on November 16, 2021. The payment date will be November 30, 2021 in the aggregate amount of approximately $4.4 million.

- added (2022-05-06):
[0000950170-22-008077:note_history:52]
On April 1, 2022, the Company entered into a Credit Agreement and related Revolving Line of Credit Note (together, the “Wells Revolving Credit Agreement”) in favor of Wells Fargo Bank, National Association, as lender (the “Wells Lender”). The Wells Revolving Credit Agreement provides the Company with a new $25 million secured revolving credit facility. The Wells Revolving Credit Agreement matures on April 1, 2023, subject to earlier termination upon the occurrence of certain events of default as set forth in the Wells Revolving Credit Agreement.  Loans under the Wells Revolving Credit Agreement will bear interest at a fluctuating rate per annum equal to: (i) the Daily Simple SOFR (as defined herein) plus (ii) an applicable margin, which will equal 1.00%, 1.25%, 1.5% or 2.0% per annum depending on the Company’s senior funded debt to EBITDA ratio. The “Daily Simple SOFR” is calculated based upon the greater of (x) a floor of 0.00% and (b) the Secured Overnight Financing Rate, as established by the Federal Reserve Bank of New York (or a successor thereto) from time to time. Accrued interest is payable on the last day of each quarter, commencing June 30, 2022. Borrowings under the Wells Revolving Credit Agreement may be used solely for issuing letters of credit, financing capital expenditures, and working capital and general corporate purposes. Loans under the Wells Revolving Credit Agreement are secured by a first priority security interest in all of the accounts receivable of the Company and its subsidiary, ADTRAN International, Inc. Specifically, in connection with the Wells Revolving Credit Agreement, the Company entered into a security agreement, dated April 1, 2022, pursuant to which the Company pledged to the Wells Lender all of the rights to payment, accounts, deposit accounts, chattel paper (whether electronic or tangible), instruments, promissory notes, documents, licenses, general intangibles, payment intangibles, software, letter of credit rights and healthcare insurance receivables existing as of the date of execution or arising at any time thereafter.

- removed (2022-05-06):
[0000950170-21-003219:note_history:53]
On November 4, 2021, the Company entered into a loan modification agreement and amendment to loan documents to extend the maturity date of the Revolving Credit Agreement through November 3, 2022. See Item 5, Other Information, of this report for additional information regarding the loan modification agreement.
