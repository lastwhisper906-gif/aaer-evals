# ADTN 8-K — 0001564590-19-038936 filed 2019-10-31

## item codes, every 8-K on or before 2019-11-05

- 2019-10-31 0001564590-19-038936 — 2.02, 9.01
- 2019-10-10 0001564590-19-036732 — 2.02, 9.01
- 2019-09-20 0001564590-19-035144 — 2.02, 9.01
- 2019-08-21 0001564590-19-032757 — 3.01, 9.01
- 2019-07-18 0001564590-19-025186 — 2.02, 9.01
- 2019-05-09 0001564590-19-017956 — 5.07
- 2019-04-18 0001564590-19-011897 — 2.02, 9.01
- 2019-03-07 0001564590-19-006575 — 5.02, 9.01
- 2019-01-24 0001564590-19-001024 — 2.02, 9.01
- 2018-12-06 0001564590-18-030615 — 8.01, 9.01
- 2018-10-17 0001564590-18-024365 — 2.02, 9.01
- 2018-07-18 0001564590-18-016946 — 2.02, 9.01
- 2018-05-10 0001564590-18-012968 — 5.07
- 2018-04-18 0001564590-18-008361 — 2.02, 9.01
- 2018-03-21 0001564590-18-006409 — 8.01, 9.01
- 2018-01-17 0001564590-18-000519 — 2.02, 9.01
- 2017-12-29 0001564590-17-025375 — 2.02, 9.01
- 2017-11-16 0001193125-17-345232 — 5.02
- 2017-10-18 0001564590-17-019582 — 2.02, 9.01
- 2017-07-19 0001564590-17-013609 — 2.02, 9.01
- 2017-05-11 0001564590-17-010459 — 5.02, 9.01
- 2017-05-11 0001564590-17-010452 — 5.07
- 2017-04-19 0001193125-17-127926 — 2.02, 9.01
- 2017-02-07 0001193125-17-032714 — 8.01
- 2017-01-18 0001193125-17-011669 — 2.02, 9.01
- 2016-11-16 0001193125-16-769505 — 5.02, 9.01
- 2016-10-19 0001193125-16-741087 — 2.02, 9.01
- 2016-09-14 0001193125-16-709148 — 8.01, 9.01
- 2016-08-17 0001193125-16-683980 — 5.02, 9.01
- 2016-07-13 0001193125-16-646816 — 2.02, 9.01
- 2016-05-13 0001193125-16-590263 — 5.07
- 2016-04-13 0001193125-16-539019 — 2.02, 9.01
- 2016-04-08 0001193125-16-535035 — 7.01
- 2016-02-11 0001193125-16-459453 — 5.02, 9.01
- 2016-01-20 0001193125-16-432934 — 2.02, 9.01
- 2015-11-16 0001193125-15-378019 — 5.02, 9.01
- 2015-10-14 0001193125-15-343083 — 2.02, 9.01
- 2015-07-16 0001193125-15-254729 — 8.01, 9.01
- 2015-07-15 0001193125-15-253068 — 2.02, 9.01
- 2015-05-15 0001193125-15-189160 — 5.07, 9.01
- 2015-04-22 0001193125-15-140997 — 2.02, 9.01
- 2015-02-23 0001193125-15-056741 — 5.02, 9.01
- 2015-01-21 0001193125-15-015465 — 2.02, 9.01
- 2014-10-15 0001193125-14-372076 — 2.02, 9.01
- 2014-10-03 0001193125-14-363152 — 2.02, 9.01
- 2014-07-16 0001193125-14-269660 — 2.02, 9.01
- 2014-05-20 0001193125-14-205916 — 8.01, 9.01
- 2014-05-20 0001193125-14-205906 — 5.02, 9.01
- 2014-05-15 0001193125-14-201144 — 5.07
- 2014-04-16 0001193125-14-144665 — 2.02, 9.01
- 2014-04-03 0001193125-14-129578 — 2.02, 9.01
- 2014-01-22 0001157523-14-000154 — 2.02, 9.01
- 2013-10-15 0001193125-13-399540 — 5.02
- 2013-10-09 0001157523-13-004657 — 2.02, 9.01
- 2013-07-10 0001157523-13-003290 — 2.02, 9.01
- 2013-05-10 0001193125-13-213728 — 5.07
- 2013-05-03 0001193125-13-198816 — 8.01, 9.01
- 2013-04-10 0001157523-13-001730 — 2.02, 9.01
- 2013-01-16 0001157523-13-000139 — 2.02, 9.01
- 2012-10-10 0001157523-12-005081 — 2.02, 9.01
- 2012-10-03 0001193125-12-413609 — 7.01
- 2012-09-28 0001193125-12-408878 — 2.02, 9.01
- 2012-07-11 0001157523-12-003592 — 2.02, 9.01
- 2012-05-10 0001193125-12-225669 — 5.07
- 2012-05-10 0001193125-12-225639 — 8.01, 9.01
- 2012-04-11 0001157523-12-001772 — 2.02, 9.01
- 2012-03-15 0001193125-12-116494 — 2.02, 9.01
- 2012-01-18 0001157523-12-000174 — 2.02, 9.01
- 2011-12-12 0001193125-11-337271 — 7.01, 9.01
- 2011-10-13 0000950123-11-089785 — 5.03, 9.01
- 2011-10-12 0001157523-11-005682 — 2.02, 9.01
- 2011-07-13 0001157523-11-003986 — 2.02, 9.01
- 2011-05-09 0000950123-11-047191 — 5.02, 5.07, 9.01
- 2011-04-13 0001157523-11-002001 — 2.02, 9.01
- 2011-01-19 0001157523-11-000232 — 2.02, 9.01
- 2010-11-09 0000950123-10-103195 — 5.02, 9.01
- 2010-10-13 0001157523-10-005798 — 2.02, 9.01
- 2010-07-14 0001157523-10-004011 — 2.02, 9.01
- 2010-05-28 0000950123-10-053947 — 5.07
- 2010-04-14 0001157523-10-002022 — 2.02, 9.01
- 2010-01-20 0001157523-10-000200 — 2.02, 9.01
- 2009-10-28 0000950123-09-053984 — 8.01
- 2009-10-14 0001157523-09-006877 — 2.02, 9.01
- 2009-07-15 0001157523-09-004878 — 2.02, 9.01
- 2009-04-15 0001157523-09-002687 — 2.02, 9.01
- 2009-01-21 0001157523-09-000340 — 2.02, 9.01
- 2008-11-12 0001193125-08-233181 — 5.02, 9.01
- 2008-10-14 0001157523-08-007999 — 2.02, 9.01
- 2008-07-15 0001157523-08-005504 — 2.02, 9.01
- 2008-04-15 0001157523-08-002896 — 2.02, 9.01
- 2008-01-22 0001157523-08-000408 — 2.02, 9.01
- 2007-10-16 0001193125-07-219356 — 5.03, 9.01
- 2007-10-16 0001157523-07-009850 — 2.02, 9.01
- 2007-07-17 0001157523-07-006912 — 2.02, 9.01
- 2007-04-17 0001157523-07-003630 — 2.02, 9.01
- 2007-04-03 0001179022-07-000068 — 5.02
- 2007-03-28 0001179022-07-000064 — 5.02
- 2007-02-23 0001193125-07-038337 — 5.02
- 2007-02-23 0001193125-07-038335 — 5.02
- 2007-01-30 0001193125-07-015912 — 5.02, 9.01
- 2007-01-26 0001193125-07-014234 — 5.02
- 2007-01-23 0001157523-07-000494 — 2.02, 9.01 — amendment of 0001157523-07-000481
- 2007-01-23 0001157523-07-000481 — 2.02, 9.01
- 2006-10-17 0001157523-06-009945 — 2.02, 9.01
- 2006-07-18 0001157523-06-006929 — 2.02, 9.01
- 2006-06-08 0001193125-06-126486 — 1.01, 9.01
- 2006-05-10 0001193125-06-107316 — 1.01, 9.01
- 2006-04-18 0001157523-06-003699 — 2.02, 9.01
- 2006-02-03 0001179022-06-000014 — 1.01
- 2006-01-27 0001157523-06-000754 — 5.02, 9.01
- 2006-01-24 0001157523-06-000551 — 2.02, 9.01
- 2005-10-18 0001157523-05-008826 — 2.02, 9.01
- 2005-07-19 0001193125-05-143958 — 1.01, 5.02, 9.01
- 2005-07-19 0001193125-05-143957 — 2.02, 9.01
- 2005-05-20 0001193125-05-112019 — 1.01, 9.01
- 2005-04-19 0001157523-05-003418 — 2.02, 9.01
- 2005-01-25 0001193125-05-010721 — 2.02, 9.01
- 2004-10-12 0001193125-04-169652 — 2.02, 9.01
- 2004-07-13 0001193125-04-116820 — 12, 7
- 2004-04-14 0001193125-04-061547 — 12, 7
- 2004-01-21 0001193125-04-006366 — 12, 7
- 2003-10-14 0001193125-03-061018 — 12, 5, 7
- 2003-07-15 0001193125-03-019292 — 7, 9
- 2003-04-15 0000931763-03-000968 — 7, 9
- 1996-09-12 0000931763-96-000667 — 5, 7

## late-filing notifications on or before 2019-11-05

- 2019-08-12 0001564590-19-031524 — NT 10-Q, for the period ended 2019-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001564590-19-038936:8k_2_02:1]
EX-99.1
2
adtn-ex991_6.htm
EX-99.1

[0001564590-19-038936:8k_2_02:2]
adtn-ex991_6.htm

[0001564590-19-038936:8k_2_02:3]
EXHIBIT 99.1

[0001564590-19-038936:8k_2_02:4]
ADTRAN, Inc. Reports Earnings for the Third Quarter 2019 and Declares Quarterly Cash Dividend

[0001564590-19-038936:8k_2_02:5]
HUNTSVILLE, Ala.--(BUSINESS WIRE) – October 30, 2019 -- ADTRAN, Inc. (NASDAQ:ADTN) (“ADTRAN” or the “Company”) reported financial results for the third quarter 2019. For the quarter, revenue was $114.1 million compared to $140.3 million for the third quarter of 2018. Net income was a net loss of $46.1 million compared to net income of $7.6 million for the third quarter of 2018. Earnings per share was a loss of $0.96 per share compared to earnings per share, assuming dilution, of $0.16 for the third quarter of 2018. Non-GAAP net income was a net loss of $2.8 million compared to non-GAAP net income of $9.9 million for the third quarter of 2018. Non-GAAP earnings per share was a loss of $0.06 per share compared to non-GAAP income per share, assuming dilution, of $0.21 for the third quarter of 2018. Earnings per share was affected by a one-time, non-cash, valuation allowance of $37.1 million, that was recorded to income tax expense in the Company’s consolidated income statement to reduce the carrying value of the Company’s deferred tax assets. Non-GAAP earnings per share exclude stock-based compensation expense, acquisition related amortizations and other expenses, restructuring expenses, amortization of pension actuarial losses, valuation allowance related to our deferred tax assets, asset impairments, gain on bargain purchase of a business and other contingencies and the reimbursement from a claim settlement. The reconciliation between GAAP net income (loss) and earnings (loss) per share to non-GAAP net income (loss) and non-GAAP earnings (loss) per share is in the table provided.

[0001564590-19-038936:8k_2_02:6]
ADTRAN Chairman and Chief Executive Officer Tom Stanton stated, “Our progress in the quarter was overshadowed by a pause in shipments to a Tier 1 customer in Latin America and a slowdown in spending by a Tier 1 customer in Europe.  With the exception of these two international customers, our business grew 20% over the previous period which was largely driven by increased sales in our GPON fiber access business and strong results in ONT sales.  Our GPON business grew 38% year-to-date as compared to the same period last year and we continue to gain strong traction globally with our 10G PON and fiber-extension solutions.  During the quarter, ADTRAN introduced a range of new products, services and technology innovations that we believe will be instrumental in our success moving forward.”

[0001564590-19-038936:8k_2_02:7]
The Company also announced that its Board of Directors declared a cash dividend for the third quarter of 2019. The quarterly cash dividend is $0.09 per common share to be paid to the Company’s stockholders of record as of the close of business on November 14, 2019. The payment date will be December 2, 2019.

[0001564590-19-038936:8k_2_02:8]
The Company confirmed that it will hold a conference call to discuss its third quarter results Thursday, October 31, 2019, at 9:30 a.m. Central Time. ADTRAN will webcast this conference call. To listen, visit the Investor Relations site at www.investors.adtran.com approximately ten minutes prior to the start of the call and click on the conference call link provided.

[0001564590-19-038936:8k_2_02:9]
An online replay of the conference call, as well as the text of the Company's conference call, will be available on the Investor Relations site approximately 24 hours following the call and will remain available for at least 12 months. For more information, visit www.investors.adtran.com or email at investor.relations@adtran.com.

[0001564590-19-038936:8k_2_02:10]
At ADTRAN, we believe amazing things happen when people connect. From the cloud edge to the subscriber edge, we help communications service providers around the world manage and scale services that connect people, places and things to advance human progress. Whether rural or urban, domestic or international, telco or cable, enterprise or residential—ADTRAN solutions optimize existing technology infrastructures and create new, multi-gigabit platforms that leverage cloud economics, data analytics, machine learning and open ecosystems—the future of global networking. Find more at ADTRAN.com, LinkedIn and Twitter.

[0001564590-19-038936:8k_2_02:11]
This press release contains forward-looking statements, generally identified by the use of words such as “believe,” “expect,” “intend,” “estimate,” “anticipate,” “will,” “may,” “could” and similar expressions, which forward-looking statements reflect management’s best judgment based on factors currently known. However, these statements involve risks and uncertainties, including the successful development and market acceptance of new products, the degree of competition in the market for such products, the product and channel mix, component costs, manufacturing efficiencies, and other risks detailed in our annual report on Form 10-K and Form 10-K/A for the year ended December 31, 2018 and our quarterly reports on Form 10-Q for the quarters ended March 31, 2019 and June 30, 2019. These risks and uncertainties could cause actual results to differ materially from those in the forward-looking statements included in this press release.

[0001564590-19-038936:8k_2_02:12]
To provide additional transparency, we have disclosed non-GAAP operating income (loss) which has been reconciled to operating income (loss) and non-GAAP net income (loss) and non-GAAP earnings (loss) per share - basic and diluted which have been reconciled to net income (loss) and earnings (loss) per share - basic and diluted as reported based on Generally Accepted Accounting Principles in the United States (U.S. GAAP). These measures exclude certain items which management believes are not reflective of the ongoing operating performance of the business. We believe this information is useful in providing period-to-period comparisons of the results of our ongoing operations. Additionally, these measures are used by management in our ongoing planning and annual budgeting processes. The presentation of non-GAAP operating income (loss), non-GAAP net income (loss) and non-GAAP earnings (loss) per share- basic and diluted, when combined with the U.S. GAAP presentation of operating income (loss), net income (loss), and net income (loss) per share – basic and diluted is beneficial to the overall understanding of ongoing operating performance of the Company.

[0001564590-19-038936:8k_2_02:13]
These measures are not in accordance with, or an alternative for, U.S. GAAP and therefore should not be considered in isolation or as a substitution for analysis of our results as reported under U.S. GAAP. Our calculation of non-GAAP operating income (loss), non-GAAP net income (loss) and non-GAAP earnings (loss) per share - basic and diluted may not be comparable to similar measures calculated by other companies.

[0001564590-19-038936:8k_2_02:14]
Condensed Consolidated Balance Sheets

[0001564590-19-038936:8k_2_02:15]
(Unaudited)

[0001564590-19-038936:8k_2_02:16]
(In thousands)

[0001564590-19-038936:8k_2_02:17]
|  | September 30, |  |  | December 31, |  |
|  | 2019 |  |  | 2018 |  |
| Assets |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 96,407 |  |  | $ | 105,504 |  |
| Short-term investments |  | 28,754 |  |  |  | 3,246 |  |
| Accounts receivable, net |  | 90,647 |  |  |  | 99,385 |  |
| Other receivables |  | 18,927 |  |  |  | 36,699 |  |
| Inventory, net |  | 104,941 |  |  |  | 99,848 |  |
| Prepaid expenses and other current assets |  | 10,327 |  |  |  | 10,744 |  |
| Total Current Assets |  | 350,003 |  |  |  | 355,426 |  |
| Property, plant and equipment, net |  | 73,384 |  |  |  | 80,635 |  |
| Deferred tax assets, net |  | 6,492 |  |  |  | 37,187 |  |
| Goodwill |  | 6,968 |  |  |  | 7,106 |  |
| Intangibles, net |  | 29,113 |  |  |  | 33,183 |  |
| Other assets |  | 23,283 |  |  |  | 5,668 |  |
| Long-term investments |  | 90,632 |  |  |  | 108,822 |  |
| Total Assets | $ | 579,875 |  |  | $ | 628,027 |  |
| Liabilities and Stockholders' Equity |  |  |  |  |  |  |  |
| Accounts payable | $ | 52,842 |  |  | $ | 60,054 |  |
| Bonds payable |  | 25,600 |  |  |  | 1,000 |  |
| Unearned revenue |  | 14,022 |  |  |  | 17,940 |  |
| Accrued expenses |  | 15,697 |  |  |  | 11,746 |  |
| Accrued wages and benefits |  | 16,569 |  |  |  | 14,752 |  |
| Income tax payable, net |  | 3,420 |  |  |  | 12,518 |  |
| Total Current Liabilities |  | 128,150 |  |  |  | 118,010 |  |
| Non-current unearned revenue |  | 4,581 |  |  |  | 5,296 |  |
| Other non-current liabilities |  | 52,189 |  |  |  | 33,842 |  |
| Bonds payable |  | — |  |  |  | 24,600 |  |
| Total Liabilities |  | 184,920 |  |  |  | 181,748 |  |
| Stockholders' Equity |  | 394,955 |  |  |  | 446,279 |  |
| Total Liabilities and Stockholders' Equity | $ | 579,875 |  |  | $ | 628,027 |  |

[0001564590-19-038936:8k_2_02:18]
Condensed Consolidated Statements of Income (Loss)

[0001564590-19-038936:8k_2_02:19]
(Unaudited)

[0001564590-19-038936:8k_2_02:20]
(In thousands, except per share data)

[0001564590-19-038936:8k_2_02:21]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Network Solutions |  | $ | 94,018 |  |  | $ | 121,043 |  |  | $ | 359,007 |  |  | $ | 341,359 |  |
| Services & Support |  |  | 20,074 |  |  |  | 19,292 |  |  |  | 55,267 |  |  |  | 47,830 |  |
| Total Sales |  |  | 114,092 |  |  |  | 140,335 |  |  |  | 414,274 |  |  |  | 389,189 |  |
| Cost of Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Network Solutions |  |  | 56,444 |  |  |  | 69,943 |  |  |  | 207,353 |  |  |  | 208,184 |  |
| Services & Support |  |  | 11,317 |  |  |  | 11,944 |  |  |  | 34,963 |  |  |  | 32,828 |  |
| Total Cost of Sales |  |  | 67,761 |  |  |  | 81,887 |  |  |  | 242,316 |  |  |  | 241,012 |  |
| Gross Profit |  |  | 46,331 |  |  |  | 58,448 |  |  |  | 171,958 |  |  |  | 148,177 |  |
| Selling, general and administrative expenses |  |  | 30,912 |  |  |  | 30,750 |  |  |  | 99,663 |  |  |  | 96,361 |  |
| Research and development expenses |  |  | 31,835 |  |  |  | 29,877 |  |  |  | 95,546 |  |  |  | 93,455 |  |
| Asset impairments |  |  | 3,872 |  |  |  | — |  |  |  | 3,872 |  |  |  | — |  |
| Gain on contingency |  |  | — |  |  |  | — |  |  |  | (1,230 | ) |  |  | — |  |
| Operating Loss |  |  | (20,288 | ) |  |  | (2,179 | ) |  |  | (25,893 | ) |  |  | (41,639 | ) |
| Interest and dividend income |  |  | 610 |  |  |  | 825 |  |  |  | 1,893 |  |  |  | 2,604 |  |
| Interest expense |  |  | (128 | ) |  |  | (134 | ) |  |  | (382 | ) |  |  | (398 | ) |
| Net investment gain (loss) |  |  | (216 | ) |  |  | 4,507 |  |  |  | 8,195 |  |  |  | 5,400 |  |
| Other income (expense), net |  |  | 1,616 |  |  |  | 201 |  |  |  | 2,266 |  |  |  | (73 | ) |
| Gain on bargain purchase of a business, net |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 11,322 |  |
| Income (Loss) Before Income Taxes |  |  | (18,406 | ) |  |  | 3,220 |  |  |  | (13,921 | ) |  |  | (22,784 | ) |
| Income tax (expense) benefit |  |  | (27,717 | ) |  |  | 4,369 |  |  |  | (27,437 | ) |  |  | 11,889 |  |
| Net Income (Loss) |  | $ | (46,123 | ) |  | $ | 7,589 |  |  | $ | (41,358 | ) |  | $ | (10,895 | ) |
| Weighted average shares outstanding – basic |  |  | 47,824 |  |  |  | 47,710 |  |  |  | 47,803 |  |  |  | 47,927 |  |
| Weighted average shares outstanding – diluted |  |  | 47,824 |  |  |  | 47,834 |  | (1) |  | 47,803 |  |  |  | 47,927 |  |
| Earnings (loss) per common share – basic |  | $ | (0.96 | ) |  | $ | 0.16 |  |  | $ | (0.87 | ) |  | $ | (0.23 | ) |
| Earnings (loss) per common share – diluted |  | $ | (0.96 | ) |  | $ | 0.16 |  | (1) | $ | (0.87 | ) |  | $ | (0.23 | ) |

[0001564590-19-038936:8k_2_02:22]
(1) Assumes exercise of dilutive stock options calculated under the treasury stock method.

[0001564590-19-038936:8k_2_02:23]
Condensed Consolidated Statements of Comprehensive Income (Loss)

[0001564590-19-038936:8k_2_02:24]
(Unaudited)

[0001564590-19-038936:8k_2_02:25]
(In thousands)

[0001564590-19-038936:8k_2_02:26]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Net Income (Loss) |  | $ | (46,123 | ) |  | $ | 7,589 |  |  | $ | (41,358 | ) |  | $ | (10,895 | ) |
| Other Comprehensive Loss, net of tax |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net unrealized gains (losses) on available-for-sale securities |  |  | (15 | ) |  |  | (32 | ) |  |  | 277 |  |  |  | (3,340 | ) |
| Defined benefit plan adjustments |  |  | 90 |  |  |  | 37 |  |  |  | 361 |  |  |  | 104 |  |
| Foreign currency translation |  |  | (2,486 | ) |  |  | (451 | ) |  |  | (3,113 | ) |  |  | (3,033 | ) |
| Other Comprehensive Loss, net of tax |  |  | (2,411 | ) |  |  | (446 | ) |  |  | (2,475 | ) |  |  | (6,269 | ) |
| Comprehensive Income (Loss), net of tax |  | $ | (48,534 | ) |  | $ | 7,143 |  |  | $ | (43,833 | ) |  | $ | (17,164 | ) |

[0001564590-19-038936:8k_2_02:27]
Condensed Consolidated Statements of Cash Flows

[0001564590-19-038936:8k_2_02:28]
(Unaudited)

[0001564590-19-038936:8k_2_02:29]
(In thousands)

[0001564590-19-038936:8k_2_02:30]
|  |  | Nine Months Ended |  |
|  |  | September 30, |  |
|  |  | 2019 |  |  | 2018 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net loss |  | $ | (41,358 | ) |  | $ | (10,895 | ) |
| Adjustments to reconcile net loss to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 13,315 |  |  |  | 11,952 |  |
| Asset impairments |  |  | 3,872 |  |  |  | — |  |
| Amortization of net premium (discount) on available-for-sale investments |  |  | (86 | ) |  |  | (14 | ) |
| Net gain on long-term investments |  |  | (8,195 | ) |  |  | (5,400 | ) |
| Net loss on disposal of property, plant and equipment |  |  | 58 |  |  |  | 68 |  |
| Gain on contingency |  |  | (1,230 | ) |  |  | — |  |
| Gain on life insurance proceeds |  |  | (1,000 | ) |  |  | — |  |
| Gain on bargain purchase of a business |  |  | — |  |  |  | (11,322 | ) |
| Stock-based compensation expense |  |  | 5,184 |  |  |  | 5,243 |  |
| Deferred income taxes |  |  | 30,421 |  |  |  | (20,368 | ) |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  |  | 7,603 |  |  |  | 41,166 |  |
| Other receivables |  |  | 17,645 |  |  |  | (1,842 | ) |
| Inventory, net |  |  | (5,998 | ) |  |  | 16,543 |  |
| Prepaid expenses and other assets |  |  | (10,071 | ) |  |  | 8,722 |  |
| Accounts payable, net |  |  | (5,569 | ) |  |  | 5,223 |  |
| Accrued expenses and other liabilities |  |  | 10,564 |  |  |  | 156 |  |
| Income tax payable |  |  | (5,073 | ) |  |  | 9,461 |  |
| Net cash provided by operating activities |  |  | 10,082 |  |  |  | 48,693 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (6,008 | ) |  |  | (5,695 | ) |
| Proceeds from sales and maturities of debt and equity investments |  |  | 38,561 |  |  |  | 116,757 |  |
| Purchases of debt and equity investments |  |  | (37,223 | ) |  |  | (115,271 | ) |
| Life insurance proceeds received |  |  | 1,000 |  |  |  | — |  |
| Acquisition of business |  |  | 13 |  |  |  | (7,806 | ) |
| Net cash used in investing activities |  |  | (3,657 | ) |  |  | (12,015 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Proceeds from stock option exercises |  |  | 526 |  |  |  | 1,321 |  |
| Purchases of treasury stock |  |  | (184 | ) |  |  | (14,185 | ) |
| Dividend payments |  |  | (12,908 | ) |  |  | (12,976 | ) |
| Net cash used in financing activities |  |  | (12,566 | ) |  |  | (25,840 | ) |
| Net increase (decrease) in cash and cash equivalents |  |  | (6,141 | ) |  |  | 10,838 |  |
| Effect of exchange rate changes |  |  | (2,956 | ) |  |  | (3,098 | ) |
| Cash and cash equivalents, beginning of period |  |  | 105,504 |  |  |  | 86,433 |  |
| Cash and cash equivalents, end of period |  | $ | 96,407 |  |  | $ | 94,173 |  |
| Supplemental disclosure of non-cash investing activities: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment included in accounts payable |  | $ | 135 |  |  | $ | 355 |  |

[0001564590-19-038936:8k_2_02:31]
Supplemental Information

[0001564590-19-038936:8k_2_02:32]
Reconciliation of Operating Loss to Non-GAAP Operating Income (Loss)

[0001564590-19-038936:8k_2_02:33]
(Unaudited)

[0001564590-19-038936:8k_2_02:34]
|  |  | Three Months ended September 30, |  |  | Nine Months ended September 30, |  |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |  |
| Operating Loss |  | $ | (20,288 | ) |  | $ | (2,179 | ) |  | $ | (25,893 | ) |  | $ | (41,639 | ) |  |
| Acquisition related expenses, amortizations and adjustments |  |  | 1,343 |  | (1) |  | 926 |  | (6) |  | 4,346 |  | (9) |  | 2,651 |  | (14) |
| Stock-based compensation expense |  |  | 1,871 |  | (2) |  | 1,640 |  | (7) |  | 5,184 |  | (10) |  | 5,243 |  | (15) |
| Restructuring expenses |  |  | 1,195 |  | (3) |  | 261 |  | (8) |  | 4,658 |  | (11) |  | 7,236 |  | (16) |
| Deferred compensation income (expense) |  |  | (576 | ) | (4) |  | 874 |  | (4) |  | 2,231 |  | (4) |  | 620 |  | (4) |
| Asset impairments |  |  | 3,872 |  | (5) |  | — |  |  |  | 3,872 |  | (5) |  | — |  |  |
| Gain on contingency |  |  | — |  |  |  | — |  |  |  | (1,230 | ) | (12) |  | — |  |  |
| Settlement income |  |  | — |  |  |  | — |  |  |  | (746 | ) | (13) |  | — |  |  |
| Non-GAAP Operating Income (Loss) |  | $ | (12,583 | ) |  | $ | 1,522 |  |  | $ | (7,578 | ) |  | $ | (25,889 | ) |  |

[0001564590-19-038936:8k_2_02:35]
(1) $0.3 million is included in total cost of sales, $0.5 million is included in selling, general and administrative expenses and $0.5 million is included in research and development expenses on the consolidated statements of income.

[0001564590-19-038936:8k_2_02:36]
(2) $0.1 million is included in total cost of sales, $1.1 million is included in selling, general and administrative expenses and $0.7 million is included in research and development expenses on the consolidated statements of income.

[0001564590-19-038936:8k_2_02:37]
(3) $0.1 million is included in total cost of sales, $0.5 million is included in selling, general and administrative expenses and $0.6 million is included in research and development expenses on the consolidated statements of income.

[0001564590-19-038936:8k_2_02:38]
(4) Includes non-cash change in fair value of equity investments held in the ADTRAN, Inc. Deferred Compensation Program for Employees (as amended and restated as of June 1, 2010) per ASU 2016-01, all of which is included in selling, general and administrative expenses on the consolidated statement of income.

[0001564590-19-038936:8k_2_02:39]
(5) Includes abandonment of certain information technology projects.

[0001564590-19-038936:8k_2_02:40]
(6) $0.3 million is included in total cost of sales, $0.3 million is included in selling, general and administrative expenses and $0.3 million is included in research and development expenses on the consolidated statements of income.

[0001564590-19-038936:8k_2_02:41]
(7) $0.9 million is included in selling, general and administrative expenses and $0.7 million is included in research and development expenses on the consolidated statements of income.

[0001564590-19-038936:8k_2_02:42]
(8) $0.3 million is included in selling, general and administrative expenses on the consolidated statements of income.

[0001564590-19-038936:8k_2_02:43]
(9) $1.3 million is included in total cost of sales, $1.6 million is included in selling, general and administrative expenses and $1.4 million is included in research and development expenses on the consolidated statements of income.

[0001564590-19-038936:8k_2_02:44]
(10) $0.3 million is included in total cost of sales, $2.9 million is included in selling, general and administrative expenses and $2.0 million is included in research and development expenses on the consolidated statements of income.

[0001564590-19-038936:8k_2_02:45]
(11) $0.8 million is included in total cost of sales, $2.1 million is included in selling, general and administrative expenses and $1.8 million is included in research and development expenses on the consolidated statements of income.

[0001564590-19-038936:8k_2_02:46]
(12) Includes gain related to unearned contingent liabilities recognized upon the acquisition of a business in November 2018.

[0001564590-19-038936:8k_2_02:47]
(13) Includes income related to certain freight forwarder claim settlements which were received during the nine months ended September 30, 2019, all of which is included in total cost of sales on the consolidated statements of income.

[0001564590-19-038936:8k_2_02:48]
(14) $0.8 million is included in total cost of sales, $0.9 million is included in selling, general and administrative expenses and $0.9 million is included in research and development expenses on the consolidated statements of income.

[0001564590-19-038936:8k_2_02:49]
(15) $0.3 million is included in total cost of sales, $2.9 million is included in selling, general and administrative expenses and $2.0 million is included in research and development expenses on the consolidated statements of income.

[0001564590-19-038936:8k_2_02:50]
(16) $2.8 million is included in total cost of sales, $2.6 million is included in selling, general and administrative expenses and $1.8 million is included in research and development expenses on the consolidated statements of income.

[0001564590-19-038936:8k_2_02:51]
Supplemental Information

[0001564590-19-038936:8k_2_02:52]
Reconciliation of Net Income (Loss) and Earnings (Loss) per Common Share – Basic and Diluted to Non-GAAP

[0001564590-19-038936:8k_2_02:53]
Net Income (Loss) and Non-GAAP Earnings (Loss) per Common Share – Basic and Diluted

[0001564590-19-038936:8k_2_02:54]
(Unaudited)

[0001564590-19-038936:8k_2_02:55]
|  |  | Three Months ended September 30, |  |  |  | Nine Months ended September 30, |  |
|  |  | 2019 |  |  | 2018 |  |  |  | 2019 |  |  | 2018 |  |
| Net Income (Loss) |  | $ | (46,123 | ) |  | $ | 7,589 |  |  |  | $ | (41,358 | ) |  | $ | (10,895 | ) |
| Acquisition related expenses, amortizations and adjustments |  |  | 1,343 |  |  |  | 926 |  |  |  |  | 4,346 |  |  |  | 2,651 |  |
| Stock-based compensation expense |  |  | 1,871 |  |  |  | 1,640 |  |  |  |  | 5,184 |  |  |  | 5,243 |  |
| Restructuring expenses |  |  | 1,195 |  |  |  | 261 |  |  |  |  | 4,658 |  |  |  | 7,236 |  |
| Pension expense(1) |  |  | 198 |  |  |  | 61 |  |  |  |  | 600 |  |  |  | 188 |  |
| Asset impairments |  |  | 3,872 |  |  |  | — |  |  |  |  | 3,872 |  |  |  | — |  |
| Valuation allowance |  |  | 37,055 |  |  |  | — |  |  |  |  | 37,055 |  |  |  | — |  |
| Gain on contingency |  |  | — |  |  |  | — |  |  |  |  | (1,230 | ) |  |  | — |  |
| Settlement income |  |  | — |  |  |  | — |  |  |  |  | (746 | ) |  |  | — |  |
| Gain on bargain purchase of a business |  |  | — |  |  |  | — |  |  |  |  | — |  |  |  | (11,322 | ) |
| Tax effect of adjustments to net income (loss) |  |  | (2,186 | ) |  |  | (624 | ) |  |  |  | (4,424 | ) |  |  | (3,658 | ) |
| Non-GAAP Net Income (Loss) |  | $ | (2,775 | ) |  | $ | 9,853 |  |  |  | $ | 7,957 |  |  | $ | (10,557 | ) |
| Weighted average shares outstanding – basic |  |  | 47,824 |  |  |  | 47,710 |  |  |  |  | 47,803 |  |  |  | 47,927 |  |
| Weighted average shares outstanding – diluted |  |  | 47,824 |  |  |  | 47,834 |  |  |  |  | 47,803 |  |  |  | 47,927 |  |
| Earnings (loss) per common share - basic |  | $ | (0.96 | ) |  | $ | 0.16 |  |  |  | $ | (0.87 | ) |  | $ | (0.23 | ) |
| Earnings (loss) per common share - diluted |  | $ | (0.96 | ) |  | $ | 0.16 |  |  |  | $ | (0.87 | ) |  | $ | (0.23 | ) |
| Non-GAAP earnings (loss) per common share - basic |  | $ | (0.06 | ) |  | $ | 0.21 |  |  |  | $ | 0.17 |  |  | $ | (0.22 | ) |
| Non-GAAP earnings (loss) per common share - diluted |  | $ | (0.06 | ) |  | $ | 0.21 |  |  |  | $ | 0.17 |  |  | $ | (0.22 | ) |

[0001564590-19-038936:8k_2_02:56]
(1) Includes amortization of actuarial losses related to the Company's pension plan for employees in certain foreign countries.
