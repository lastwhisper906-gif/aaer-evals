# ADTN MD&A — 0001564590-19-040490


## mdna

[0001564590-19-040490:mdna:1]
[same as prior period, unchanged from 0001564590-19-035143:mdna:1]

[0001564590-19-040490:mdna:2]
The following discussion should be read in conjunction with the consolidated financial statements and the related notes that appear in Part I, Item 1 of this document.  In addition, the following discussion should be read in conjunction with our audited consolidated financial statements for the year ended December 31, 2018, Part II, Item 7, Management’s Discussion and Analysis of Financial Condition and Results of Operations, Part I, Item 1, Business, and Item 1A, Risk Factors, included in our Annual Report on Form 10-K for the year ended December 31, 2018, filed with the SEC on February 28, 2019 (as amended on September 20, 2019, the “2018

[0001564590-19-040490:mdna:3]
Form 10-K”).

[0001564590-19-040490:mdna:4]
This discussion is designed to provide the reader with information that will assist in understanding our consolidated financial statements, the changes in certain key items in those financial statements from period to period, and the primary factors that accounted for those changes, as well as how certain accounting principles affect our condensed consolidated financial statements.  See “Cautionary Note Regarding Forward-Looking Statements” on page 3 of this report for a description of important factors that could cause actual results to differ from expected results.  See also Item 1A, Risk Factors, of the 2018 Form 10‑K.

[0001564590-19-040490:mdna:5]
[same as prior period, unchanged from 0001564590-19-035143:mdna:4]

[0001564590-19-040490:mdna:6]
ADTRAN is a leading global provider of networking and communications equipment, serving a diverse domestic and international customer base in multiple countries that includes Tier-1, -2 and -3 service providers, cable/multiple system operators (“MSO”) and distributed enterprises. Our innovative solutions and services enable voice, data, video and internet communications across a variety of network infrastructures and are currently in use by millions worldwide. We support our customers through our direct global sales organization and our distribution networks. Our success depends upon our ability to increase unit volume and market share through the introduction of new products and succeeding generations of products having lower selling prices and increased functionality as compared to both the prior generation of a product and to the products of competitors. In order to service our customers and grow revenue, we are constantly conducting research and development of new products addressing customer needs and testing those products for the particular specifications of the particular customers. We are focused on being a top global supplier of access infrastructure and related value-added solutions from the cloud edge to the subscriber edge. We offer a broad portfolio of flexible software and hardware network solutions and services that enable service providers to meet today’s service demands, while enabling them to transition to the fully-converged, scalable, highly-automated, cloud-controlled voice, data, internet and video network of the future. In addition to our corporate headquarters in Huntsville, Alabama, we have research and development facilities in strategic global locations.

[0001564590-19-040490:mdna:7]
[same as prior period, unchanged from 0001564590-19-035143:mdna:6]

[0001564590-19-040490:mdna:8]
We made two acquisitions in 2018, strengthening our position in both the cable/MSOs and connected home markets. In the first quarter of 2018, we acquired Sumitomo Electric Lightwave Corp.’s North American EPON business and certain assets for North America and entered into a technology license and original equipment manufacturer supply agreement with Sumitomo Electric Industries, Ltd. These solutions, combined with our organic fiber access product portfolio and our distributed access expertise, present new opportunities in the cable/MSO market. Also, in the fourth quarter of 2018, we acquired U.S.-based SmartRG, an industry-leading provider of carrier-class, connected-home software platforms and cloud services for broadband service providers. With this acquisition, ADTRAN now offers a complete cloud-to-consumer portfolio of virtualized management, data analytics, Wi-Fi-enabled residential gateways and software platforms.

[0001564590-19-040490:mdna:9]
We review our financial performance, specifically revenue and gross profit, based on two reportable segments – Network Solutions and Services & Support. Network Solutions software and hardware products provide solutions supporting fiber-, copper- and coaxial-based infrastructures and a growing number of wireless solutions, lowering the overall cost to deploy advanced services across a wide range of applications for carrier, cable/MSO networks and business networks, as well as for prior-generation products. Services & Support enables our customers to accelerate time to market, reduce costs and improve customer satisfaction through a complete portfolio of services, including maintenance, turnkey network implementation, solutions integration, and managed services. ADTRAN’s comprehensive network implementation services include engineering design and documentation (pre-construction), construction and installation (construction), and test, turn-up and provisioning (post-construction). Additionally, we partner with customers to tailor a program to each specific service-delivery need.

[0001564590-19-040490:mdna:10]
[same as prior period, unchanged from 0001564590-19-035143:mdna:9]

[0001564590-19-040490:mdna:11]
[same as prior period, unchanged from 0001564590-19-035143:mdna:10]

[0001564590-19-040490:mdna:12]
|  | • | Subscriber Solutions & Experience (formerly Customer Devices) includes open connected home platforms, cloud services and any of our solutions and services that deliver residential and/or enterprise subscribers an immersive and interactive broadband experience from the service provider’s access network. These products, software and services include SmartRG solutions and applications, NetVanta Enterprise IP business gateways, access routers, Ethernet switches, ProCloud service offerings, residential and enterprise operating systems (such as SmartOS and AOS), Bluesocket Wi-Fi portfolio, service provider and cable/MSO Optical Network Terminals (“ONTs”), as well as related software applications and services. In alignment with our increased focus on enhancing customer experience for both business and consumer broadband customers as well as the addition of SmartRG during 2018, Customer Devices is now known as Subscriber Solutions & Experience, as this more accurately represents this revenue category and our vision moving forward. |

[0001564590-19-040490:mdna:13]
[same as prior period, unchanged from 0001564590-19-035143:mdna:12]

[0001564590-19-040490:mdna:14]
See Note 14 of the Notes to Consolidated Financial Statements included in Part I, Item 1 of this report for further information regarding the Company’s segments and revenue categories.

[0001564590-19-040490:mdna:15]
Our operating results have fluctuated on a quarterly basis in the past, and may vary significantly in future periods, due to a number of factors, including customer order activity and purchase order backlog. Although the timing of our product deliveries in response to customer orders results in very little purchase order backlog, such backlog levels vary because of seasonal trends, the timing of customer projects and other factors that affect customer order lead times. Many of our customers require prompt delivery of products. This requires us to maintain sufficient inventory levels to satisfy anticipated customer demand. If near-term demand for our products declines, or if potential sales in any quarter do not occur as anticipated, our financial results could be adversely affected. Operating expenses are relatively fixed in the short term; therefore, a shortfall in quarterly revenue could significantly impact our financial results in a given quarter.

[0001564590-19-040490:mdna:16]
In the third quarter of 2019, we had one customer whose orders accounted for more than 10% of our revenue. Our third quarter 2019 revenue was negatively impacted by a pause in shipments to a Tier 1 customer in Latin America (“LATAM”) and the continued slowdown in spending at another international Tier 1 customer. For the fourth quarter of 2019, our current expectations include a continued impact from a decline in sales related to these two customers. Although we expect sales to the LATAM customer to rebound, our current visibility regarding timing is limited. For the international Tier 1 customer, we believe that normal spending should resume in 2020.

[0001564590-19-040490:mdna:17]
Our operating results may also fluctuate as a result of a number of other factors, including a decline in global economic and financial market conditions, foreign currency exchange rate movements, changes related to domestic and international tariffs, increased competition, customer order patterns, changes in product and services mix, timing differences between price decreases and product cost reductions, product warranty returns, expediting costs and announcements of new products by us or our competitors. Additionally, maintaining sufficient inventory levels to assure prompt delivery of our products increases the amount of inventory that may become obsolete and increases the risk that the obsolescence of this inventory may have an adverse effect on our business and operating results. Also, not maintaining sufficient inventory levels to assure prompt delivery of our products may cause us to incur expediting costs to meet customer delivery requirements, which may negatively impact our operating results in a given quarter.

[0001564590-19-040490:mdna:18]
Our historical financial performance is not necessarily a meaningful indicator of future results, and in general, management expects that our financial results may vary from period to period. Factors that could materially affect our business, financial condition or operating results are included in Part I, Item 1A of the 2018 Form 10-K and in Part II, Item 1A of this Form 10-Q.

[0001564590-19-040490:mdna:19]
[same as prior period, unchanged from 0001564590-19-035143:mdna:30]

[0001564590-19-040490:mdna:20]
[same as prior period, unchanged from 0001564590-19-035143:mdna:18]

[0001564590-19-040490:mdna:21]
There have been no material changes to our critical accounting policies and estimates from those disclosed in our 2018 Form 10-K/A, other than as described below.

[0001564590-19-040490:mdna:22]
During the three months ended June 30, 2019, the Company changed the manner in which it estimates its excess and obsolete inventory reserves. Under the new policy, we establish reserves for estimated excess and obsolete inventory equal to the difference between the cost of the inventory and the estimated net realizable value of the inventory based on historical usage, known trends, inventory age, and market conditions. When we dispose of excess and obsolete inventories, the related disposals are charged against the inventory reserves. See Note 8 of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this report for additional information.

[0001564590-19-040490:mdna:23]
[same as prior period, unchanged from 0001564590-19-035143:mdna:21]

[0001564590-19-040490:mdna:24]
See Note 1 of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this report for a full description of recent accounting pronouncements, including the expected dates of adoption and estimated effects on results of operations and financial condition, which is incorporated herein by reference.

[0001564590-19-040490:mdna:25]
RESULTS OF OPERATIONS – THREE AND NINE MONTHS ENDED SEPTEMBER 30, 2019 COMPARED TO THREE AND NINE MONTHS ENDED SEPTEMBER 30, 2018

[0001564590-19-040490:mdna:26]
[same as prior period, unchanged from 0001564590-19-035143:mdna:24]

[0001564590-19-040490:mdna:27]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |  |
|  |  | September 30, |  |  | September 30, |  |  |
|  |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |  |
| Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Network Solutions |  |  | 82.4 |  | % |  | 86.3 |  | % |  | 86.7 |  | % |  | 87.7 |  | % |
| Services & Support |  |  | 17.6 |  |  |  | 13.7 |  |  |  | 13.3 |  |  |  | 12.3 |  |  |
| Total Sales |  |  | 100.0 |  |  |  | 100.0 |  |  |  | 100.0 |  |  |  | 100.0 |  |  |
| Cost of Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Network Solutions |  |  | 49.5 |  |  |  | 49.8 |  |  |  | 50.1 |  |  |  | 53.5 |  |  |
| Services & Support |  |  | 9.9 |  |  |  | 8.5 |  |  |  | 8.4 |  |  |  | 8.4 |  |  |
| Total Cost of Sales |  |  | 59.4 |  |  |  | 58.4 |  |  |  | 58.5 |  |  |  | 61.9 |  |  |
| Gross Profit |  |  | 40.6 |  |  |  | 41.6 |  |  |  | 41.5 |  |  |  | 38.1 |  |  |
| Selling, general and administrative expenses |  |  | 27.1 |  |  |  | 21.9 |  |  |  | 24.1 |  |  |  | 24.8 |  |  |
| Research and development expenses |  |  | 27.9 |  |  |  | 21.3 |  |  |  | 23.1 |  |  |  | 24.0 |  |  |
| Asset impairments |  |  | 3.4 |  |  |  | — |  |  |  | 0.9 |  |  |  | — |  |  |
| Gain on contingency |  |  | — |  |  |  | — |  |  |  | (0.3 | ) |  |  | — |  |  |
| Operating Loss |  |  | (17.8 | ) |  |  | (1.6 | ) |  |  | (6.3 | ) |  |  | (10.7 | ) |  |
| Interest and dividend income |  |  | 0.5 |  |  |  | 0.6 |  |  |  | 0.5 |  |  |  | 0.7 |  |  |
| Interest expense |  |  | (0.1 | ) |  |  | (0.1 | ) |  |  | (0.1 | ) |  |  | (0.1 | ) |  |
| Net investment gain (loss) |  |  | (0.2 | ) |  |  | 3.2 |  |  |  | 2.0 |  |  |  | 1.4 |  |  |
| Other income (expense), net |  |  | 1.4 |  |  |  | 0.1 |  |  |  | 0.5 |  |  |  | — |  |  |
| Gain on bargain purchase of a business, net |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 2.9 |  |  |
| Income (Loss) Before Income Taxes |  |  | (16.1 | ) |  |  | 2.3 |  |  |  | (3.4 | ) |  |  | (5.9 | ) |  |
| Income tax (expense) benefit |  |  | (24.3 | ) |  |  | 3.1 |  |  |  | (6.6 | ) |  |  | 3.1 |  |  |
| Net Income (Loss) |  |  | (40.4 | ) | % |  | 5.4 |  | % |  | (10.0 | ) | % |  | (2.8 | ) | % |

[0001564590-19-040490:mdna:28]
[same as prior period, unchanged from 0001564590-19-035143:mdna:26]

[0001564590-19-040490:mdna:29]
Our sales decreased 18.7% from $140.3 million for the three months ended September 30, 2018 to $114.1 million for the three months ended September 30, 2019, and increased 6.4% from $389.2 million for the nine months ended September 30, 2018 to $414.3 million for the nine months ended September 30, 2019. The decrease in sales for the three months ended September 30, 2019 was primarily attributable to a $26.8 million decrease in Access & Aggregation sales and a $3.4 million decrease in sales of our Traditional & Other Products, partially offset by a $3.9 million increase in Subscriber Solutions & Experience sales. The increase in sales for the nine months ended September 30, 2019 was primarily attributable to a $16.5 million increase in Subscriber Solutions & Experience sales and a $16.0 million increase in Access & Aggregation sales, partially offset by a $7.4 million decrease in sales of our Traditional & Other Products.

[0001564590-19-040490:mdna:30]
Network Solutions segment sales decreased 22.3% from $121.0 million for the three months ended September 30, 2018 to $94.0 million for the three months ended September 30, 2019, and increased 5.2% from $341.4 million for the nine months ended September 30, 2018 to $359.0 million for the nine months ended September 30, 2019. The decrease in sales for the three months ended September 30, 2019 was primarily attributable to the slowdown in shipments to two Tier-1 customers as previously discussed. For the three months ended September 30, 2019, sales in the Access & Aggregation and Traditional & Other Products categories decreased, partially offset by a increase in Subscriber Solutions & Experience category sales. The decrease in Access & Aggregation sales for the three months ended September 30, 2019 was primarily attributable to decreased fiber to the node (“FTTN”) products, offset by an increase in G.fast DPUs.  The increase in Subscriber Solutions & Experience sales for the three months ended September 30, 2019 was primarily attributable to increased Residential CPE, partially offset by a decrease in SP Business CPE and WiFi access points and infrastructure. The increase in sales for the nine months ended September 30, 2019 was primarily attributable to an increase in Access & Aggregation and Subscriber Solutions & Experience sales. The increase in Access & Aggregation sales for the nine months ended September 30, 2019 was primarily attributable to increased FTTN products and G.fast DPUs. The increase in Subscriber Solutions & Experience for the nine months ended September 30, 2019 was primarily attributable to increased Residential CPE and fiber CPE sales, partially offset by a decrease in SP Business CPE and WiFi access points and infrastructure. While we expect that revenue from Traditional & Other Products will continue to decline over time, this revenue may fluctuate and continue for years because of the time required for our customers to transition to newer technologies.

[0001564590-19-040490:mdna:31]
38

[0001564590-19-040490:mdna:32]
Services & Support segment sales increased 4.1% from $19.3 million for the three months ended September 30, 2018 to $20.1 million for the three months ended September 30, 2019, and increased 15.5% from $47.8 million for the nine months ended September 30, 2018 to $55.3 million for the nine months ended September 30, 2019. The increase in sales for the three and nine months ended September 30, 2019 was primarily attributable to an increase in network installation and maintenance services for Access & Aggregation products.

[0001564590-19-040490:mdna:33]
International sales, which are included in the amounts for the Network Solutions and Services & Support segments amounts discussed above, decreased 45.3% from $56.6 million for the three months ended September 30, 2018 to $30.9 million for the three months ended September 30, 2019 and increased 4.7% from $175.2 million for the nine months ended September 30, 2018 to $183.3 million for the nine months ended September 30, 2019. International sales, as a percentage of total sales, decreased from 40.3% for the three months ended September 30, 2018 to 27.1% for the three months ended September 30, 2019 and decreased from 45.0% for the nine months ended September 30, 2018 to 44.2% for the nine months ended September 30, 2019. The decrease in sales for the three months ended September 30, 2019, was primarily attributable the slowdown in shipments to two international Tier-1 customers.  The increase in sales for the nine months ended September 30, 2019, was primarily attributable to an increase in sales in LATAM and Asia Pacific (“APAC”), primarily attributable to network expansion programs of large Tier-1 customers.

[0001564590-19-040490:mdna:34]
[same as prior period, unchanged from 0001564590-19-035143:mdna:32]

[0001564590-19-040490:mdna:35]
[same as prior period, unchanged from 0001564590-19-035143:mdna:33]

[0001564590-19-040490:mdna:36]
As a percentage of sales, cost of sales increased from 58.4% for the three months ended September 30, 2018 to 59.4% for the three months ended September 30, 2019 and decreased from 61.9% for the nine months ended September 30, 2018 to 58.5% for the nine months ended September 30, 2019. The increase in cost of sales as a percentage of sales for the three months ended September 30, 2019 was primarily attributable to a decrease in volume, changes in customer and product mix and changes in services and support mix. The decrease in cost of sales as a percentage of sales for the nine months ended September 30, 2019 was primarily attributable to an increase in volume, a regional revenue shift, changes in customer and product mix, changes in services and support mix and a decrease in labor expense as a result of a restructuring program initiated in the first quarter of 2018.

[0001564590-19-040490:mdna:37]
Network Solutions segment cost of sales, as a percentage of that segment’s sales, increased from 57.8% for the three months ended September 30, 2018 to 60.0% for the three months ended September 30, 2019 and decreased from 61.0% for the nine months ended September 30, 2018 to 57.8% for the nine months ended September 30, 2019. The increase in cost of sales as a percentage of sales for the three months ended September 30, 2019 was primarily attributable to a decrease in volume, a regional revenue shift and changes in customer and product mix. The decrease in cost of sales as a percentage of sales for the nine months ended September 30, 2019 was primarily attributable to an increase in volume, a regional revenue shift, changes in customer and product mix and a decrease in labor expense due to a restructuring program initiated in the first quarter of 2018.

[0001564590-19-040490:mdna:38]
An important part of our strategy is to reduce the cost of each succeeding generation of product and then lower the product’s selling price based on the cost savings achieved in order to gain market share and/or improve gross margins. This may cause variations in our gross profit percentage due to timing differences between the recognition of cost reductions and the lowering of product selling prices.

[0001564590-19-040490:mdna:39]
Services & Support segment cost of sales, as a percentage of that segment’s sales, decreased from 61.9% for the three months ended September 30, 2018 to 56.4% for the three months ended September 30, 2019 and decreased from 68.6% for the nine months ended September 30, 2018 to 63.3% for the nine months ended September 30, 2019. The decrease in cost of sales as a percentage of sales for the three months ended September 30, 2019 was primarily attributable to an increase in volume, customer mix and changes in services and support mix. The decrease in cost of sales as a percentage of sales for the nine months ended September 30, 2019 was primarily attributable to an increase in volume, lower fixed personnel costs due to a restructuring program initiated in the first quarter of 2018, changes in customer mix and changes in services and support mix.

[0001564590-19-040490:mdna:40]
[same as prior period, unchanged from 0001564590-19-035143:mdna:38]

[0001564590-19-040490:mdna:41]
As our network planning and implementation revenue grew to become the largest component of our Services & Support segment business, our Services & Support segment gross margins decreased versus those reported when maintenance and support comprised the majority of the business. Further, because the growth in our network planning and implementation services has resulted in our Services & Support segment revenue comprising a larger percentage of our overall revenue, and because our Services & Support segment gross margins are generally below those of the Network Solutions segment, our overall corporate gross margins have declined as that business has continued to grow. Within the Services & Support segment, we do expect variability in gross margins from quarter-to-quarter based on the mix of the services recognized.

[0001564590-19-040490:mdna:42]
[same as prior period, unchanged from 0001564590-19-035143:mdna:40]

[0001564590-19-040490:mdna:43]
Selling, general and administrative expenses increased 0.5% from $30.8 million for the three months ended September 30, 2018 to $30.9 million for the three months ended September 30, 2019, and increased 3.4% from $96.4 million for the nine months ended September 30, 2018 to $99.7 million for the nine months ended September 30, 2019. The increase in selling, general and administrative expenses for the three months ended September 30, 2019 was primarily attributable to incremental expenses as a result of the SmartRG acquisition, IP litigation costs and professional and contract services offset by decreases in personnel-related expenses. The increase in selling, general and administrative expenses for the nine months ended September 30, 2019 was primarily attributable to incremental expenses as a result of the SmartRG acquisition, IP litigation costs and deferred compensation offset by a decrease in personnel-related expenses.

[0001564590-19-040490:mdna:44]
As a percentage of sales, selling, general and administrative expenses increased from 21.9% for the three months ended September 30, 2018 to 27.1% for the three months ended September 30, 2019, and decreased from 24.8% for the nine months ended September 30, 2018 to 24.1% for the nine months ended September 30, 2019. Selling, general and administrative expenses as a percentage of sales may fluctuate whenever there is a significant fluctuation in revenue for the periods being compared.

[0001564590-19-040490:mdna:45]
[same as prior period, unchanged from 0001564590-19-035143:mdna:43]

[0001564590-19-040490:mdna:46]
Research and development expenses increased 6.6% from $29.9 million for the three months ended September 30, 2018 to $31.8 million for the three months ended September 30, 2019 and increased 2.2% from $93.5 million for the nine months ended September 30, 2018 to $95.5 million for the nine months ended September 30, 2019. The increase in research and development expenses for the three months ended September 30, 2019 was primarily attributable to increases in incremental expenses as a result of the SmartRG acquisition, personnel-related expenses and restructuring expenses. The increase in research and development expense for the nine months ended September 30, 2019 was primarily attributable to increases in incremental expenses as a result of the SmartRG acquisition, contract services and lease expense, offset by a decrease in personnel-related expenses.

[0001564590-19-040490:mdna:47]
As a percentage of sales, research and development expenses increased from 21.3% for the three months ended September 30, 2018 to 27.9% for the three months ended September 30, 2019, and decreased from 24.0% for the nine months ended September 30, 2018 to 23.1% for the nine months ended September 30, 2019. Research and development expenses as a percentage of sales will fluctuate whenever there are incremental product development activities or significant fluctuations in revenue for the periods being compared.

[0001564590-19-040490:mdna:48]
[same as prior period, unchanged from 0001564590-19-035143:mdna:46]

[0001564590-19-040490:mdna:49]
ASSET IMPAIRMENTS

[0001564590-19-040490:mdna:50]
Asset impairment, which were $3.9 million for the three and nine months ended September 30, 2019, relate to the abandonment of certain information technology implementation projects which we had previously capitalized costs related to these projects. There were no impairment charges recognized during the three and nine months ended September 30, 2018.

[0001564590-19-040490:mdna:51]
GAIN ON CONTINGENCY

[0001564590-19-040490:mdna:52]
Gain on contingency, which was $1.2 million for the nine months ended September 30, 2019, relates to the reversal of contingent liabilities which were initially recognized upon the acquisition of SmartRG in the fourth quarter of 2018. See Note 2 of the Notes to Consolidated Financial Statements included in Part I, Item 1 of this report for additional information. There was no gain on contingency recognized during the three and nine months ended September 30, 2018.

[0001564590-19-040490:mdna:53]
[same as prior period, unchanged from 0001564590-19-035143:mdna:49]

[0001564590-19-040490:mdna:54]
Interest and dividend income decreased 26.1% from $0.8 million for the three months ended September 30, 2018 to $0.6 million for the three months ended September 30, 2019, and decreased 27.3% from $2.6 million for the nine months ended September 30, 2018 to $1.9 million for the nine months ended September 30, 2019. The changes in interest and dividend income for the three and nine months ended September 30, 2019 were primarily attributable to fluctuations in investment balances.

[0001564590-19-040490:mdna:55]
[same as prior period, unchanged from 0001564590-19-035143:mdna:51]

[0001564590-19-040490:mdna:56]
Interest expense, which is primarily related to our taxable revenue bond, remained constant at $0.1 million in the three months ended September 30, 2018 and 2019 and $0.4 million in the nine months ended September 30, 2018 and 2019, as we had no substantial change in our fixed-rate borrowing. See “Liquidity and Capital Resources” below for additional information on our revenue bond.

[0001564590-19-040490:mdna:57]
NET INVESTMENT GAIN (LOSS)

[0001564590-19-040490:mdna:58]
Net investment gain decreased from a gain of $4.5 million for the three months ended September 30, 2018 to a loss of $0.2 million for the three months ended September 30, 2019, and increased from a gain of $5.4 million for the nine months ended September 30, 2018 to a gain of $8.2 million for the nine months ended September 30, 2019. The fluctuation in our net investment gain was primarily attributable to changes in fair value of equity securities recognized during the period. See Note 7 of the Notes to Condensed Consolidated Financial Statements, included in Part I, Item 1 of this report, and “Investing Activities” in “Liquidity and Capital Resources” below for additional information.

[0001564590-19-040490:mdna:59]
[same as prior period, unchanged from 0001564590-19-035143:mdna:55]

[0001564590-19-040490:mdna:60]
Other income (expense), net is comprised primarily of miscellaneous income and gains and losses on foreign currency transactions. Other income (expense), net increased from income of $0.2 million for the three months ended September 30, 2018 to income of $1.6 million for the three months ended September 30, 2019 and increased from expense of $0.1 million for the nine months ended September 30, 2018 to income of $2.3 million for the nine months ended September 30, 2019. The fluctuations in other income (expense), net for the three and nine months ended September 30, 2019 was primarily attributable to gains on foreign currency transactions.

[0001564590-19-040490:mdna:61]
[same as prior period, unchanged from 0001564590-19-035143:mdna:57]

[0001564590-19-040490:mdna:62]
Gain on bargain purchase of a business, net, which was $11.3 million during the nine months ended September 30, 2018, was related to our acquisition of Sumitomo Electric Lightwave Corp.’s North American EPON business and entry into a technology license and supply agreement with Sumitomo Electric Industries, Ltd. in March 2018. No gain on bargain purchase of a business was recorded during the three or nine months ended September 30, 2019.

[0001564590-19-040490:mdna:63]
BENEFIT (EXPENSE) FOR INCOME TAXES

[0001564590-19-040490:mdna:64]
Our effective tax rate increased from a benefit of 135.7% for the three months ended September 30, 2018 to an expense of 150.6% for the three months ended September 30, 2019, and increased from a benefit of 34.9%, excluding the tax effect of the bargain purchase gain, for the nine months ended September 30, 2018 to an expense of 197.1% for the nine months ended September 30, 2019. The increase in the effective tax rate between the two periods was primarily driven by the establishment of a valuation allowance against our domestic deferred tax assets in the amount of $37.1 million during the three months ending September 30, 2019, offset by a 9.38% rate reduction related to a transfer pricing study completed during the second quarter of 2019 that resulted in the assignment of operating expenditures to specific company locations, and the effective income tax rates among the respective jurisdictions. See Note 4 of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this report for additional information.

[0001564590-19-040490:mdna:65]
[same as prior period, unchanged from 0001564590-19-035143:mdna:61]

[0001564590-19-040490:mdna:66]
As a result of the above factors, net income (loss) decreased 707.8% from net income of $7.6 million for the three months ended September 30, 2018 to a net loss of $46.1 million for the three months ended September 30, 2019, and decreased 279.6% from a net loss of $10.9 million for the nine months ended September 30, 2018 to a net loss of $41.4 million for the nine months ended September 30, 2019.

[0001564590-19-040490:mdna:67]
[same as prior period, unchanged from 0001564590-19-035143:mdna:63]

[0001564590-19-040490:mdna:68]
[same as prior period, unchanged from 0001564590-19-035143:mdna:64]

[0001564590-19-040490:mdna:69]
We intend to finance our future operations with cash flow from operations. We have used, and expect to continue to use, cash generated from operations for working capital, purchases of treasury stock, shareholder dividends, future business acquisitions and other general corporate purposes, including (i) product development activities to enhance our existing products and develop new products and (ii) expansion of sales and marketing activities. We believe our cash and cash equivalents, investments and cash generated from operations to be adequate to meet our operating and capital needs for at least the next 12 months.

[0001564590-19-040490:mdna:70]
At September 30, 2019, cash on hand was $96.4 million and short-term investments were $28.8 million, which resulted in available short-term liquidity of $125.2 million, of which $62.5 million was held by our foreign subsidiaries. At December 31, 2018, cash on hand was $105.5 million and short-term investments were $3.2 million, which resulted in available short-term liquidity of $108.7 million, of which $87.1 million was held by our foreign subsidiaries. The increase in short-term liquidity from December 31, 2018 to September 30, 2019 is primarily attributable to a restricted certificate of deposit of $25.6 million, which serves as collateral for our revenue bond, being reclassified from a long-term investment to a short-term investment in 2019 as it matures in January 2020.

[0001564590-19-040490:mdna:71]
[same as prior period, unchanged from 0001564590-19-035143:mdna:67]

[0001564590-19-040490:mdna:72]
Our working capital, which consists of current assets less current liabilities, decreased 6.6% from $237.4 million as of December 31, 2018 to $221.9 million as of September 30, 2019, and our current ratio, defined as current assets divided by current liabilities, decreased from 3.01 as of December 31, 2018 to 2.73 as of September 30, 2019. The decrease in our working capital and our current ratio was primarily attributable to the reclassification of our bond payable to current liabilities as it matures in January 2020, as well as the reclassification of the related restricted certificate of deposit from a long-term investment to a short-term investment. The quick ratio, defined as cash, cash equivalents, short-term investments, and net accounts receivable, divided by current liabilities, decreased from 1.76 as of December 31, 2018 to 1.68 as of September 30, 2019. The decrease in the quick ratio was primarily attributable to the reclassification of our bond payable to current liabilities as it matures in January 2020, partially offset by an increase in short-term investments, primarily related to the reclassification of our restricted certificate of deposit from a long-term investment to a short-term investment.

[0001564590-19-040490:mdna:73]
Net accounts receivable decreased 8.8% from $99.4 million at December 31, 2018 to $90.6 million at September 30, 2019. Our allowance for doubtful accounts was $0.1 million at December 31, 2018 and September 30, 2019. The decrease in net accounts receivable was due to a decrease in sales volume. Quarterly accounts receivable day’s sales outstanding (“DSO”) increased from 65 days as of December 31, 2018 to 73 days as of September 30, 2019. The increase in DSO is due the timing of product shipments and customer mix.

[0001564590-19-040490:mdna:74]
Other receivables decreased 48.4% from $36.7 million at December 31, 2018 to $18.9 million at September 30, 2019. The decrease in other receivables was primarily attributable to a decrease in leased equipment receivables, repayment of certain outstanding notes receivable in the first quarter of 2019, contract manufacturers’ receivables and income tax receivables.

[0001564590-19-040490:mdna:75]
Quarterly inventory turnover decreased from 3.29 turns as of December 31, 2018 to 2.71 turns at September 30, 2019. Inventory increased 5.1% from $99.8 million at December 31, 2018 to $104.9 million at September 30, 2019. We expect inventory levels to fluctuate as we attempt to maintain sufficient inventory in response to services activity and seasonal cycles of our business, ensuring competitive lead times while managing the risk of inventory obsolescence that may occur due to rapidly changing technology and customer demand.

[0001564590-19-040490:mdna:76]
Accounts payable decreased 12.0% from $60.1 million at December 31, 2018 to $52.8 million at September 30, 2019. Accounts payable will fluctuate due to variations in the timing of the receipt of supplies, inventory and services and our subsequent payments for these purchases.

[0001564590-19-040490:mdna:77]
[same as prior period, unchanged from 0001564590-19-035143:mdna:73]

[0001564590-19-040490:mdna:78]
Capital expenditures totaled approximately $6.0 million and $5.7 million for the nine months ended September 30, 2019 and 2018, respectively. These expenditures were primarily used to purchase manufacturing and test equipment, software, computer hardware and for building improvements.

[0001564590-19-040490:mdna:79]
Our combined short-term and long-term investments increased $7.3 million from $112.1 million at December 31, 2018 to $119.4 million at September 30, 2019. This increase reflects the impact of net realized and unrealized gains and losses on our combined investments as well as new investments.

[0001564590-19-040490:mdna:80]
We typically invest all available cash not required for immediate use in operations, primarily in securities that we believe bear minimal risk of loss. See Note 7 of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this report for additional information. As of September 30, 2019, our corporate bonds, municipal fixed-rate bonds, asset-backed bonds, mortgage/agency-backed bonds, U.S. government bonds and foreign government bonds were classified as available-for-sale and had a combined duration of 1.6 years with an average Moody’s credit rating of A. Because our bond portfolio has a high-quality rating and contractual maturities of short duration, we are able to obtain prices for these bonds derived from observable market inputs, or for similar securities traded in an active market, on a daily basis.

[0001564590-19-040490:mdna:81]
Our long-term investments at December 31, 2018 included an investment in a certificate of deposit of $25.6 million, which serves as collateral for our revenue bond. This certificate of deposit is now included in short-term investments as of September 30, 2019, as this bond matures on January 1, 2020. See Note 7 of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this report and “Financing Activities: Debt” below for additional information. We also have investments in various marketable equity securities classified as long-term investments with a fair market value of $32.7 million and $27.0 million, at September 30, 2019 and December 31, 2018, respectively. Long-term investments at September 30, 2019 and December 31, 2018 also included $20.6 million and $18.3 million, respectively, related to our deferred compensation plans.

[0001564590-19-040490:mdna:82]
No businesses were acquired during the nine months ended September 30, 2019. Acquisition of businesses, net of cash acquired, totaled $7.8 million for the nine months ended September 30, 2018. See Note 2 of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this report for additional information.

[0001564590-19-040490:mdna:83]
[same as prior period, unchanged from 0001564590-19-035143:mdna:79]

[0001564590-19-040490:mdna:84]
[same as prior period, unchanged from 0001564590-19-035143:mdna:80]

[0001564590-19-040490:mdna:85]
In July 2003, our Board of Directors elected to begin declaring quarterly dividends on our common stock considering the tax treatment of dividends and adequate levels of Company liquidity. During the nine months ended September 30, 2019 and 2018, we paid dividends totaling $12.9 million and $13.0 million, respectively. The continued payment of dividends is at the discretion of the Company’s Board of Directors and is subject to general business conditions and ongoing financial results of the Company.

[0001564590-19-040490:mdna:86]
[same as prior period, unchanged from 0001564590-19-035143:mdna:82]

[0001564590-19-040490:mdna:87]
We have amounts outstanding under loans made pursuant to an Alabama State Industrial Development Authority revenue bond (the “Bond”) which totaled $25.6 million at September 30, 2019 and December 31, 2018. At September 30, 2019, the estimated fair value of the Bond was $25.6 million, based on a debt security with a comparable interest rate and maturity and a Standard & Poor’s credit rating of AA+. Restricted funds serving as a collateral deposit against the principal amount of the Bond in the amount of $25.6 million were included in short-term investments at September 30, 2019 and long-term investments at December 31, 2018, respectively. We have the right to offset the balance of the Bond with the collateral deposit in order to reduce the balance of the indebtedness. The Bond matures on January 1, 2020, and bears interest at the rate of 2% per annum. In conjunction with this program, we are eligible to receive certain economic incentives from the state of Alabama that reduce the amount of payroll withholdings we are required to remit to the state for those employment positions that qualify under this program. We are required to make payments in the amounts necessary to pay the interest on the amounts currently outstanding. The restricted funds held as collateral against the principal amount of the Bond will be used to pay the outstanding principal and interest upon the Bond’s maturity.

[0001564590-19-040490:mdna:88]
[same as prior period, unchanged from 0001564590-19-035143:mdna:84]

[0001564590-19-040490:mdna:89]
Since 1997, our Board of Directors has approved multiple share repurchase programs that have authorized repurchases of our common stock, which are implemented through open market or private purchases from time to time as conditions warrant. During the nine months ended September 30, 2019, we repurchased 13,000 shares of our common stock for $0.2 million at an average price of $14.06 per share. We currently have authorization to repurchase an additional 2.5 million shares of our common stock under the current authorization of up to 5.0 million shares.

[0001564590-19-040490:mdna:90]
[same as prior period, unchanged from 0001564590-19-035143:mdna:86]

[0001564590-19-040490:mdna:91]
We issued 34,000 shares of treasury stock during the nine months ended September 30, 2019 to accommodate employee stock option exercises. The stock options had exercise prices ranging from $15.33 to $16.97. We received proceeds totaling $0.5 million from the exercise of these stock options during the nine months ended September 30, 2019.

[0001564590-19-040490:mdna:92]
[same as prior period, unchanged from 0001564590-19-035143:mdna:88]

[0001564590-19-040490:mdna:93]
We do not have off-balance sheet financing arrangements and have not engaged in any related party transactions or arrangements with unconsolidated entities or other persons that are reasonably likely to materially affect liquidity or the availability of or requirements for capital resources. During the nine months ended September 30, 2019, there have been no material changes in contractual obligations and commercial commitments from those discussed in the 2018 Form 10-K, except for a new operating lease for office space in India. This lease has an initial term of five years and includes an option to renew for an additional five-year period.

[0001564590-19-040490:mdna:94]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, of which $7.7 million has been applied as of September 30, 2019.

[0001564590-19-040490:mdna:95]
44
