# ADTN notes — 0001564590-19-040490


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001564590-19-040490:notes:1]
[same as prior period, unchanged from 0001564590-19-035143:notes:1]

[0001564590-19-040490:notes:2]
[same as prior period, unchanged from 0001564590-19-035143:notes:2]

[0001564590-19-040490:notes:3]
[same as prior period, unchanged from 0001564590-19-035143:notes:3]

[0001564590-19-040490:notes:4]
In the opinion of management, all adjustments necessary to fairly state these interim statements have been recorded and are of a normal and recurring nature. The results of operations for an interim period are not necessarily indicative of the results for the full year. The interim financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in ADTRAN’s Annual Report on Form 10-K for the year ended December 31, 2018, filed with the SEC on February 28, 2019 (as amended on September 20, 2019, the “2018 Form 10-K”).

[0001564590-19-040490:notes:5]
[same as prior period, unchanged from 0001564590-19-035143:notes:5]

[0001564590-19-040490:notes:6]
The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenue and expense during the reporting period. Our more significant estimates include the excess and obsolete inventory reserves, warranty reserves, customer rebates, determination of the deferred and accrued revenue components of multiple performance obligations sales agreements, estimated costs to complete obligations associated with deferred and accrued revenue, estimated income tax provision and income tax contingencies, the fair value of stock-based compensation, impairment of goodwill, valuation and estimated lives of intangible assets, estimated pension liability, fair value of investments and the evaluation of other-than-temporary declines in the value of investments. Actual amounts could differ significantly from these estimates.

[0001564590-19-040490:notes:7]
During the three months ended June 30, 2019, the Company revised the methodology used in estimating its excess and obsolete inventory reserves. Under the revised methodology, we establish reserves for estimated excess and obsolete inventory equal to the difference between the cost of the inventory and the estimated net realizable value of the inventory based on historical usage, known trends, inventory age, and market conditions. When we dispose of excess and obsolete inventories, the related disposals are charged against the inventory reserves. See Note 8 for additional information.

[0001564590-19-040490:notes:8]
Correction of Immaterial Misstatements

[0001564590-19-040490:notes:9]
During the three months ended June 30, 2019, the Company determined that there was an immaterial misstatement of its excess and obsolete inventory reserves in its previously issued annual and interim financial statements. The Company corrected this misstatement by recognizing a $0.8 million out-of-period adjustment during the three months ended June 30, 2019, which increased its excess and obsolete inventory reserves and cost of goods sold for the period. For the six months ended June 30, 2019, the out-of-period adjustment was a cumulative $0.2 million reduction in the Company’s excess and obsolete inventory reserves and cost of goods sold. In addition, the Company determined that a $1.0 million cash inflow related to an insurance recovery was incorrectly classified as a cash flow from operations instead of a cash flow from investing activities within the unaudited Condensed Consolidated Statement of Cash Flows for the three months ended March 31, 2019. The Company has corrected this misstatement in the Unaudited Condensed Consolidated Statement of Cash Flows for the nine months ended September 30, 2019 to correctly reflect the $1.0 million insurance recovery as a cash inflow from investing activities. Management has determined that these misstatements were not material to any of its previously issued financial statements and that correction of the misstatements is also not material to the current or estimated annual 2019 financial results on either a quantitative and qualitative basis.

[0001564590-19-040490:notes:10]
[same as prior period, unchanged from 0001564590-19-035143:notes:10]

[0001564590-19-040490:notes:11]
In June 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. ASU 2016-13 requires the measurement and recognition of expected credit losses for financial instruments held at amortized cost. In November 2018, the FASB issued ASU 2018-19, Codification Improvements to Topic 326 Financial Instruments – Credit Losses, that clarifies receivables arising from operating leases are not within the scope of the credit losses standard, but rather should be accounted for in accordance with the leases standard. In April 2019, the FASB issued ASU 2019-04, Codification Improvements to Topic 326, Financial Instruments–Credit Losses, Topic 815, Derivatives and Hedging, and Topic 825, Financial Instruments, which clarifies the accounting for transfers between classifications of debt securities and clarifies that entities should include expected recoveries on financial assets in the calculation of the current expected credit loss allowance. In addition, renewal options that are not unconditionally cancelable should be considered in the determination of expected credit losses. In May 2019, the FASB issued ASU 2019-05, Financial Instruments – Credit Losses (Topic 326): Targeted Transition Relief, which amends ASU 2016-13 to allow companies, upon adoption, to elect the fair value option on financial instruments that were previously recorded at amortized cost if they meet certain criteria. All of these ASUs are effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019, with early adoption permitted. We are currently evaluating the effect these ASUs will have on our consolidated financial statements.

[0001564590-19-040490:notes:12]
In January 2017, the FASB issued ASU 2017-04, Intangibles – Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment. ASU 2017-04 simplifies the measurement of goodwill by eliminating step 2 of the goodwill impairment test. Under ASU 2017-04, entities will be required to compare the fair value of a reporting unit to its carrying amount and recognize an impairment charge for the amount by which the carrying amount exceeds the reporting unit’s fair value. ASU 2017-04 is effective for annual or interim impairment tests performed in fiscal years beginning after December 15, 2019, with early adoption permitted for annual or interim impairment tests performed on testing dates after January 1, 2017. The amendments should be applied prospectively. We are currently evaluating whether to early adopt ASU 2017-04, but do not expect it will have a material effect on our consolidated financial statements.

[0001564590-19-040490:notes:13]
In August 2018, the FASB issued ASU 2018-13, Fair Value Measurement (Topic 820): Disclosure Framework-Changes to the Disclosure Requirements for Fair Value Measurement, which changes the fair value measurement disclosure requirements of ASC 820, Fair Value Measurement. The amendments in this ASU are the result of a broader disclosure project, Concepts Statement No. 8 — Conceptual Framework for Financial Reporting — Chapter 8 — Notes to Financial Statements, which the FASB finalized on August 28, 2018. The FASB used the guidance in the Concepts Statement to improve the effectiveness of ASC 820’s disclosure requirements. ASU 2018-13 provides users of financial statements with information about assets and liabilities measured at fair value in the statement of financial position or disclosed in the notes to the financial statements. More specifically, ASU 2018-13 requires disclosures about the valuation techniques and inputs that are used to arrive at measures of fair value, including judgments and assumptions that are made in determining fair value. In addition, ASU 2018-13 requires disclosures regarding the uncertainty in the fair value measurements as of the reporting date and how changes in fair value measurements affect performance and cash flows. ASU 2018-13 is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. We are currently evaluating the effect of ASU 2018-13, but do not expect it will have a material effect on our financial statement disclosures.

[0001564590-19-040490:notes:14]
In August 2018, the FASB issued ASU 2018-14, Compensation-Retirement Benefits-Defined Benefit Plans-General (Subtopic 715-20): Disclosure Framework-Changes to the Disclosure Requirements for Defined Benefit Plans, which makes changes to and clarifies the disclosure requirements related to defined benefit pension and other postretirement plans. ASU 2018-14 requires additional disclosures related to the reasons for significant gains and losses affecting the benefit obligation and an explanation of any other significant changes in the benefit obligation or plan assets that are not otherwise apparent in other disclosures required by ASC 715. ASU 2018-14 also clarifies the guidance in ASC 715 to require disclosure of the projected benefit obligation (“PBO”) and fair value of plan assets for pension plans with PBOs in excess of plan assets and the accumulated benefit obligation (“ABO”) and fair value of plan assets for pension plans with ABOs in excess of plan assets. ASU 2018-14 is effective for public business entities for fiscal years ending after December 15, 2020. We are currently evaluating the effect of ASU 2018-14, but do not expect it will have a material effect on our financial statement disclosures.

[0001564590-19-040490:notes:15]
In August 2018, the FASB issued ASU 2018-15, Intangibles-Goodwill and Other-Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract.  ASU 2018-15 clarifies certain aspects of ASU 2015-05, Customer’s Accounting for Fees Paid in a Cloud Computing Arrangement. Specifically, ASU 2018-15 aligns the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementations costs incurred to develop or obtain internal use software. ASU 2018-15 is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019, with early adoption permitted. We are currently evaluating the effect of ASU 2018-15, but do not expect it will have a material effect on our consolidated financial statements.

[0001564590-19-040490:notes:16]
Recently Adopted Accounting Pronouncements

[0001564590-19-040490:notes:17]
[same as prior period, unchanged from 0001564590-19-035143:notes:17]

[0001564590-19-040490:notes:18]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842), which requires an entity to recognize right-of-use assets and lease liabilities on the balance sheet and to disclose key information about the entity’s leasing arrangements. In July 2018, the FASB issued ASU 2018-10, Codification Improvements to Topic 842, Leases, which clarified certain aspects of ASU 2016-02, as well as ASU 2018-11, Leases (Topic 842), Targeted Improvements, which provided for an optional transition method allowing for the application of the legacy lease guidance, Leases (Topic 840), including its disclosure requirements, for the comparative periods presented in the year of adoption, with the cumulative effect of initially applying the new lease standard recognized as an adjustment to retained earnings as of the date of adoption. In March 2019, the FASB issued ASU 2019-01, Leases (Topic 842) Codification Improvements, which removed the requirement for an entity to disclose in the interim periods after adoption, the effect of the change on income from continuing operations, net income, any other affected financial statement line item, and any affected per share amount. For lessors, the new leasing standard requires leases to be classified as sales-type, direct financing or operating leases. These criteria focus on the transfer of control of the underlying lease asset. This standard and related updates were effective for fiscal years beginning after December 15, 2018, and interim periods within those fiscal years.

[0001564590-19-040490:notes:19]
The Company adopted the new standard on January 1, 2019, the effective date of our initial application, using the optional transition method. At that time, the Company elected to carry forward the legacy ASC 840 disclosures for comparative periods and, therefore, did not adjust the comparative period financial information prior to January 1, 2019. In addition, the Company elected the package of practical expedients which allows for companies to not reassess whether any expired or existing contracts are or contain leases, not reassess historical lease classifications for expired or existing contracts and not reassess initial direct costs for existing leases. Additionally, the Company elected the practical expedients which allow the use of hindsight when determining the lease term, the short-term lease recognition exemption and the option to not separate lease and non-lease components. The adoption of this standard resulted in the recognition of a right-of-use asset and corresponding right-of-use liability on our Condensed Consolidated Balance Sheet of $10.3 million as of January 1, 2019, primarily related to our operating leases for office space, automobiles and other equipment.

[0001564590-19-040490:notes:20]
As a lessee, the adoption of this standard did not have a material impact on our Condensed Consolidated Statement of Income or Statement of Cash Flows. See Note 12 for additional information.

[0001564590-19-040490:notes:21]
As a lessor, the adoption of this standard did not have a material impact on the Company’s Condensed Consolidated Balance Sheet, Condensed Consolidated Statement of Income or Condensed Consolidated Statement of Cash Flows. Prior to and after adoption, all of our leases in which we are the lessor were classified as sales-type leases.

[0001564590-19-040490:notes:22]
In March 2017, the FASB issued ASU 2017-08, Receivables – Nonrefundable Fees and Other Costs (Subtopic 310-20): Premium Amortization on Purchased Callable Debt Securities, which shortened the amortization period for the premium on certain purchased callable debt securities to the earliest call date. ASU 2017-08 was effective for fiscal years and interim periods within those fiscal years, beginning after December 15, 2018. The amendments were required to be applied through a modified-retrospective transition approach that required a cumulative-effect adjustment directly to retained earnings as of the beginning of the period of adoption. The Company adopted ASU 2017-08 on January 1, 2019, and the adoption of this standard did not have a material effect on our consolidated financial statements.

[0001564590-19-040490:notes:23]
In August 2017, the FASB issued ASU 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities. ASU 2017-12 expanded and refined hedge accounting for both financial and non-financial risk components, aligned the recognition and presentation of the effects of hedging instruments and hedge items in the financial statements, and included certain targeted improvements to ease the application of current guidance related to the assessment of hedge effectiveness.  In October 2018, the FASB issued ASU 2018-16, Derivatives and Hedging (Topic 815): Inclusion of the Secured Overnight Financing Rate (“SOFR”) Overnight Index Swap (“OIS”) Rate as a Benchmark Interest Rate for Hedge Accounting, which permits the OIS rate based on SOFR as a U.S. benchmark interest rate. Both ASU 2017-12 and ASU 2018-16 were effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2018. The Company adopted ASU 2017-12 on January 1, 2019, and the adoption of this standard did not have a material effect on our consolidated financial statements as we did not have any hedging instruments as of the date of adoption.

[0001564590-19-040490:notes:24]
In February 2018, the FASB issued ASU 2018-02, Income Statement – Reporting Comprehensive Income (Topic 220): Reclassification of Certain Tax Effects from Accumulated Comprehensive Income. ASU 2018-02 allowed for an optional reclassification from accumulated other comprehensive income to retained earnings for stranded tax effects resulting from the Tax Cuts and Jobs Act of 2017. ASU 2018-02 was effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2018. The Company adopted ASU 2018-02 on January 1, 2019, and upon adoption reclassified $0.4 million of stranded tax effects created by rate changes related to the Tax Cuts and Jobs Act of 2017 to retained earnings. See Note 13 for additional information.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001564590-19-040490:notes:25]
[same as prior period, unchanged from 0001564590-19-035143:notes:25]

[0001564590-19-040490:notes:26]
On November 30, 2018, we acquired SmartRG, Inc. (“SmartRG”), a provider of carrier-class, open connected home platforms and cloud services for broadband service providers in exchange for cash consideration. This transaction was accounted for as a business combination. We have included the financial results of this acquisition in our consolidated financial statements since the date of acquisition. The revenue from the SmartRG portfolio is included in the Subscriber Solutions & Experience category within the Network Solutions and Services & Support reportable segments.

[0001564590-19-040490:notes:27]
[same as prior period, unchanged from 0001564590-19-035143:notes:27]

[0001564590-19-040490:notes:28]
An escrow in the amount of $2.8 million was set up at the acquisition date to fund post-closing working capital settlements and to satisfy indemnity obligations to the Company arising from any inaccuracy or breach of representations, warranties, covenants, agreements or obligations of the sellers. The escrow is subject to arbitration with final settlement expected during the fourth quarter of 2020. The minimum and maximum potential release of funds to the sellers ranges from zero to $2.8 million.

[0001564590-19-040490:notes:29]
[same as prior period, unchanged from 0001564590-19-035143:notes:29]

[0001564590-19-040490:notes:30]
[same as prior period, unchanged from 0001564590-19-035143:notes:30]

[0001564590-19-040490:notes:31]
[same as prior period, unchanged from 0001564590-19-035143:notes:31]

[0001564590-19-040490:notes:32]
[same as prior period, unchanged from 0001564590-19-035143:notes:32]

[0001564590-19-040490:notes:33]
[same as prior period, unchanged from 0001564590-19-035143:notes:33]

[0001564590-19-040490:notes:34]
For the three and nine months ended September 30, 2019, we incurred acquisition and integration related expenses and amortization of acquired intangibles of $0.5 million and $1.7 million, respectively, related to the SmartRG acquisition. No acquisition-related expenses were incurred during the three and nine months ended September 30, 2018 related to the SmartRG acquisition.

[0001564590-19-040490:notes:35]
On March 19, 2018, we acquired Sumitomo Electric Lightwave Corp.’s North American EPON business and entered into a technology license and OEM supply agreement with Sumitomo Electric Industries, Ltd. This transaction was accounted for as a business combination. We have included the financial results of this acquisition in our consolidated financial statements since the date of acquisition. This revenue is included in the Access & Aggregation and Subscriber Solutions & Experience categories within the Network Solutions reportable segment.

[0001564590-19-040490:notes:36]
We recorded a bargain purchase gain, net of income taxes, of $11.3 million during the first quarter of 2018, which represents the difference between the fair value of the net assets acquired over the cash paid. We assessed the recognition and measurement of the assets acquired and liabilities assumed based on historical and forecasted data for future periods and concluded that our valuation procedures and resulting measures were appropriate.

[0001564590-19-040490:notes:37]
The following unaudited supplemental pro forma information presents the financial results of the Company for the nine months ended September 30, 2018 as if the acquisition of the Sumitomo EPON business had occurred on January 1, 2018. This unaudited supplemental pro forma information does not purport to be indicative of what would have occurred had the acquisition been completed on January 1, 2018, nor is it indicative of any future results. There were no material, non-recurring adjustments to this unaudited pro forma information.

[0001564590-19-040490:notes:38]
|  | Nine Months Ended |  |
| (In thousands) | September 30, 2018 |  |
| Pro forma revenue | $ | 390,449 |  |
| Pro forma net loss | $ | (23,431 | ) |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001564590-19-040490:notes:39]
[same as prior period, unchanged from 0001564590-19-035143:notes:39]

[0001564590-19-040490:notes:40]
[same as prior period, unchanged from 0001564590-19-035143:notes:40]

[0001564590-19-040490:notes:41]
[same as prior period, unchanged from 0001564590-19-035143:notes:41]

[0001564590-19-040490:notes:42]
Network Solutions includes hardware products and software-defined next-generation virtualized solutions used in service provider or business networks, as well as prior generation products. The majority of the revenue from this segment is from hardware sales. In certain transactions, we are also the lessor in sales-type lease arrangements for network equipment. These arrangements typically include network equipment, network implementation services and maintenance services. Network implementation services and maintenance services are included in the Services & Support segment discussed below. See Note 12 for additional information.

[0001564590-19-040490:notes:43]
[same as prior period, unchanged from 0001564590-19-035143:notes:43]

[0001564590-19-040490:notes:44]
To complement our Network Solutions segment, we offer a complete portfolio of maintenance, network implementation, solutions integration and managed services, which include hosted cloud services and subscription services.

[0001564590-19-040490:notes:45]
Sales by Category

[0001564590-19-040490:notes:46]
In addition to our reporting segments, we also report revenue in the following three categories – Access & Aggregation, Subscriber Solutions & Experience and Traditional & Other Products.

[0001564590-19-040490:notes:47]
The following table disaggregates our revenue by reportable segment and revenue category for the three months ended September 30, 2019 and 2018:

[0001564590-19-040490:notes:48]
|  |  | Three Months Ended |  |
|  |  | September 30, 2019 |  |  | September 30, 2018 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 48,902 |  |  | $ | 16,212 |  |  | $ | 65,114 |  |  | $ | 76,046 |  |  | $ | 15,855 |  |  | $ | 91,901 |  |
| Subscriber Solutions & Experience(1) |  |  | 40,382 |  |  |  | 2,094 |  |  |  | 42,476 |  |  |  | 37,313 |  |  |  | 1,239 |  |  |  | 38,552 |  |
| Traditional & Other Products |  |  | 4,734 |  |  |  | 1,768 |  |  |  | 6,502 |  |  |  | 7,684 |  |  |  | 2,198 |  |  |  | 9,882 |  |
| Total |  | $ | 94,018 |  |  | $ | 20,074 |  |  | $ | 114,092 |  |  | $ | 121,043 |  |  | $ | 19,292 |  |  | $ | 140,335 |  |

[0001564590-19-040490:notes:49]
[same as prior period, unchanged from 0001564590-19-035143:notes:48]

[0001564590-19-040490:notes:50]
The following table disaggregates our revenue by reportable segment and revenue category for the nine months ended September 30, 2019 and 2018:

[0001564590-19-040490:notes:51]
|  |  | Nine Months Ended |  |
|  |  | September 30, 2019 |  |  | September 30, 2018 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 230,837 |  |  | $ | 43,476 |  |  | $ | 274,313 |  |  | $ | 220,653 |  |  | $ | 37,670 |  |  | $ | 258,323 |  |
| Subscriber Solutions & Experience(1) |  |  | 113,545 |  |  |  | 6,186 |  |  |  | 119,731 |  |  |  | 99,396 |  |  |  | 3,817 |  |  |  | 103,213 |  |
| Traditional & Other Products |  |  | 14,625 |  |  |  | 5,605 |  |  |  | 20,230 |  |  |  | 21,310 |  |  |  | 6,343 |  |  |  | 27,653 |  |
| Total |  | $ | 359,007 |  |  | $ | 55,267 |  |  | $ | 414,274 |  |  | $ | 341,359 |  |  | $ | 47,830 |  |  | $ | 389,189 |  |

[0001564590-19-040490:notes:52]
Revenue is measured based on the consideration we expect to receive in exchange for transferring goods or providing services to a customer and as performance obligations under the terms of the contract are satisfied. For transactions where there are multiple performance obligations, we account for individual products and services separately if they are distinct (if a product or service is separately identifiable from other items and if a customer can benefit from it on its own or with other resources that are readily available to the customer). As of September 30, 2019, we did not have any significant performance obligations related to customer contracts that had an original expected duration of one year or more, other than maintenance services, which are satisfied over time.

[0001564590-19-040490:notes:53]
[same as prior period, unchanged from 0001564590-19-035143:notes:52]

[0001564590-19-040490:notes:54]
| (In thousands) |  | September 30, 2019 |  |  | December 31, 2018 |  |
| Accounts receivable, net |  | $ | 90,647 |  |  | $ | 99,385 |  |
| Contract assets(1) |  | $ | 2,434 |  |  | $ | 3,766 |  |
| Unearned revenue |  | $ | 14,022 |  |  | $ | 17,940 |  |
| Non-current unearned revenue |  | $ | 4,581 |  |  | $ | 5,296 |  |

[0001564590-19-040490:notes:55]
[same as prior period, unchanged from 0001564590-19-035143:notes:54]

[0001564590-19-040490:notes:56]
Of the outstanding unearned revenue balance at December 31, 2018, $1.2 million and $11.7 million was recognized as revenue during the three and nine months ended September 30, 2019, respectively.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0001564590-19-040490:notes:57]
The table below presents sales information by category for the three and nine months ended September 30, 2019 and 2018:

[0001564590-19-040490:notes:58]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Access & Aggregation |  | $ | 65,114 |  |  | $ | 91,901 |  |  | $ | 274,313 |  |  | $ | 258,323 |  |
| Subscriber Solutions & Experience |  |  | 42,476 |  |  |  | 38,552 |  |  |  | 119,731 |  |  |  | 103,213 |  |
| Traditional & Other Products |  |  | 6,502 |  |  |  | 9,882 |  |  |  | 20,230 |  |  |  | 27,653 |  |
| Total |  | $ | 114,092 |  |  | $ | 140,335 |  |  | $ | 414,274 |  |  | $ | 389,189 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-19-040490:notes:59]
[same as prior period, unchanged from 0001564590-19-035143:notes:58]

[0001564590-19-040490:notes:60]
Our effective tax rate increased from a benefit of 34.9%, excluding the tax effect of the bargain purchase gain, in the nine months ended September 30, 2018, to an expense of 197.1% in the nine months ended September 30, 2019. The increase in the effective tax rate between the two periods was primarily driven by the establishment of a valuation allowance against our domestic deferred tax assets in the amount of $37.1 million during the three months ended September 30, 2019, offset by a 9.38% rate reduction related to a transfer pricing study completed during the second quarter of 2019 that resulted in the assignment of operating expenditures to specific company locations, and the effective income tax rates among the respective jurisdictions.

[0001564590-19-040490:notes:61]
As of September 30, 2019, the Company had deferred tax assets totaling $49.4 million. As of September 30, 2019, a valuation allowance totaling $42.9 million has been established against our deferred tax assets. Of this amount, $37.1 million was established during the third quarter of 2019 relating to our domestic deferred tax assets. The remaining $5.8 million that was established in prior periods relates to state research and development credit carryforwards, and foreign net operating loss and research and development credit carryforwards, where we lack sufficient activity to realize those deferred tax assets. The remaining $6.5 million in deferred tax assets not offset by a valuation allowance are located in various foreign jurisdictions where the Company believes it is more likely than not we will realize these deferred tax assets.

[0001564590-19-040490:notes:62]
Supplemental balance sheet information related to deferred tax assets is as follows:

[0001564590-19-040490:notes:63]
|  |  | September 30, 2019 |  |
| (In thousands) |  | Deferred Tax Assets |  |  | Valuation Allowance |  |  | Deferred Tax Assets, net |  |
| Domestic |  | $ | 40,496 |  |  | $ | (40,496 | ) |  | $ | — |  |
| International |  |  | 8,909 |  |  |  | (2,417 | ) |  |  | 6,492 |  |
| Total |  | $ | 49,405 |  |  | $ | (42,913 | ) |  | $ | 6,492 |  |

[0001564590-19-040490:notes:64]
The Company continually reviews the adequacy of our valuation allowance and recognizes the benefits of deferred tax assets only as the reassessment indicates that it is more likely than not that the deferred tax assets will be realized in accordance with ASC 740, Income Taxes. Due to our recent decrease in revenue and profitability for the third quarter of 2019, management’s current expectations for revenue for the remainder of 2019, and all other positive and negative objective evidence considered as part of our analysis, our ability to consider other subjective evidence such as projections for future growth is limited when evaluating whether our deferred tax assets will be realized. As such, the Company is no longer able to conclude that it is more likely than not that our domestic deferred tax assets will be realized. The amount of the deferred tax assets considered realizable, however, could be adjusted in future periods in the event sufficient evidence is present to support a conclusion that it is more likely than not that all or a portion of our domestic deferred tax assets will be realized.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001564590-19-040490:notes:65]
[same as prior period, unchanged from 0001564590-19-035143:notes:61]

[0001564590-19-040490:notes:66]
[same as prior period, unchanged from 0001564590-19-035143:notes:62]

[0001564590-19-040490:notes:67]
The following table summarizes the components of net periodic pension cost for the three and nine months ended September 30, 2019 and 2018:

[0001564590-19-040490:notes:68]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Service cost |  | $ | 366 |  |  | $ | 294 |  |  | $ | 1,109 |  |  | $ | 905 |  |
| Interest cost |  |  | 158 |  |  |  | 179 |  |  |  | 479 |  |  |  | 551 |  |
| Expected return on plan assets |  |  | (346 | ) |  |  | (381 | ) |  |  | (1,049 | ) |  |  | (1,174 | ) |
| Amortization of actuarial losses |  |  | 198 |  |  |  | 61 |  |  |  | 600 |  |  |  | 188 |  |
| Net periodic pension cost |  | $ | 376 |  |  | $ | 153 |  |  | $ | 1,139 |  |  | $ | 470 |  |

[0001564590-19-040490:notes:69]
[same as prior period, unchanged from 0001564590-19-035143:notes:65]


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-19-040490:notes:70]
[same as prior period, unchanged from 0001564590-19-035143:notes:66]

[0001564590-19-040490:notes:71]
The following table summarizes stock-based compensation expense related to stock options, performance stock units (“PSUs”), restricted stock units (“RSUs”) and restricted stock for the three and nine months ended September 30, 2019 and 2018:

[0001564590-19-040490:notes:72]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Stock-based compensation expense included in cost of sales |  | $ | 83 |  |  | $ | 101 |  |  | $ | 272 |  |  | $ | 298 |  |
| Selling, general and administrative expense |  |  | 1,142 |  |  |  | 894 |  |  |  | 2,867 |  |  |  | 2,924 |  |
| Research and development expense |  |  | 646 |  |  |  | 645 |  |  |  | 2,045 |  |  |  | 2,021 |  |
| Stock-based compensation expense included in operating expenses |  |  | 1,788 |  |  |  | 1,539 |  |  |  | 4,912 |  |  |  | 4,945 |  |
| Total stock-based compensation expense |  |  | 1,871 |  |  |  | 1,640 |  |  |  | 5,184 |  |  |  | 5,243 |  |
| Tax benefit for expense associated with stock options, PSUs, RSUs and restricted stock |  |  | (446 | ) |  |  | (292 | ) |  |  | (1,235 | ) |  |  | (1,016 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 1,425 |  |  | $ | 1,348 |  |  | $ | 3,949 |  |  | $ | 4,227 |  |

[0001564590-19-040490:notes:73]
[same as prior period, unchanged from 0001564590-19-035143:notes:69]

[0001564590-19-040490:notes:74]
The following table is a summary of our stock options outstanding as of December 31, 2018 and September 30, 2019, and the changes that occurred during the nine months ended September 30, 2019:

[0001564590-19-040490:notes:75]
|  |  | Number of Stock Options (in thousands) |  |  | Weighted Avg. Exercise Price (per share) |  |  | Weighted Avg. Remaining Contractual Life (in years) |  |  | Aggregate Intrinsic Value (in thousands) |  |
| Stock options outstanding, December 31, 2018 |  |  | 4,382 |  |  | $ | 22.91 |  |  |  | 4.10 |  |  | $ | — |  |
| Stock options exercised |  |  | (34 | ) |  | $ | 15.53 |  |  |  |  |  |  |  |  |  |
| Stock options forfeited |  |  | (28 | ) |  | $ | 15.53 |  |  |  |  |  |  |  |  |  |
| Stock options expired |  |  | (183 | ) |  | $ | 24.41 |  |  |  |  |  |  |  |  |  |
| Stock options outstanding, September 30, 2019 |  |  | 4,137 |  |  | $ | 22.96 |  |  |  | 3.27 |  |  | $ | — |  |
| Stock options exercisable, September 30, 2019 |  |  | 3,915 |  |  | $ | 23.39 |  |  |  | 3.11 |  |  | $ | — |  |

[0001564590-19-040490:notes:76]
At September 30, 2019, total unrecognized compensation expense related to non-vested stock options was approximately $0.1 million, which is expected to be recognized over an average remaining recognition period of 0.3 years. Unrecognized compensation expense will be adjusted for actual forfeitures.

[0001564590-19-040490:notes:77]
[same as prior period, unchanged from 0001564590-19-035143:notes:73]

[0001564590-19-040490:notes:78]
The aggregate intrinsic value of stock options represents the total pre-tax intrinsic value (the difference between ADTRAN’s closing stock price on the last trading day of the quarter and the exercise price, multiplied by the number of in-the-money options) that would have been received by the option holders had all option holders exercised their options on September 30, 2019. The amount of aggregate intrinsic value will change based on the fair market value of ADTRAN’s stock and was zero as of September 30, 2019. The total pre-tax intrinsic value of options exercised during the nine months ended September 30, 2019 was $0.1 million.

[0001564590-19-040490:notes:79]
The fair value of our stock options is estimated using the Black-Scholes model. The determination of the fair value of stock options on the date of grant using the Black-Scholes model is affected by our stock price, as well as assumptions regarding a number of complex and subjective variables that may have a significant impact on the fair value estimate. These variables include, but are not limited to, the volatility of our stock price and employee exercise behaviors.

[0001564590-19-040490:notes:80]
There were no stock options granted during the three and nine months ended September 30, 2019 and 2018.

[0001564590-19-040490:notes:81]
[same as prior period, unchanged from 0001564590-19-035143:notes:77]

[0001564590-19-040490:notes:82]
The following table is a summary of our PSUs, RSUs and restricted stock outstanding as of December 31, 2018 and September 30, 2019 and the changes that occurred during the nine months ended September 30, 2019.

[0001564590-19-040490:notes:83]
|  |  | Number of Shares (in thousands) |  |  | Weighted Avg. Grant Date Fair Value (per share) |  |
| Unvested PSUs, RSUs and restricted stock outstanding, December 31, 2018 |  |  | 1,570 |  |  | $ | 18.52 |  |
| PSUs, RSUs and restricted stock granted |  |  | 63 |  |  | $ | 12.81 |  |
| PSUs, RSUs and restricted stock vested |  |  | (22 | ) |  | $ | 17.13 |  |
| PSUs, RSUs and restricted stock forfeited |  |  | (175 | ) |  | $ | 18.69 |  |
| Unvested PSUs, RSUs and restricted stock outstanding, September 30, 2019 |  |  | 1,436 |  |  | $ | 18.27 |  |

[0001564590-19-040490:notes:84]
[same as prior period, unchanged from 0001564590-19-035143:notes:80]

[0001564590-19-040490:notes:85]
At September 30, 2019, total unrecognized compensation expense related to the non-vested portion of market-based PSUs, RSUs and restricted stock was approximately $11.6 million, which is expected to be recognized over an average remaining recognition period of 2.4 years. In addition, there was $8.2 million of unrecognized compensation expense related to unvested 2017 performance-based PSUs, which will be recognized over the remaining requisite service period of 0.3 years if achievement of the performance obligation becomes probable. For the three and nine months ended September 30, 2019 and 2018, no compensation expense was recognized related to these 2017 performance-based PSUs. Unrecognized compensation expense will be adjusted for actual forfeitures.

[0001564590-19-040490:notes:86]
At September 30, 2019, 2.7  million shares were available for issuance under shareholder-approved equity plans in connection with the grant and exercise of stock options, PSUs, RSUs or restricted stock.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001564590-19-040490:notes:87]
7. INVESTMENTS

[0001564590-19-040490:notes:88]
Debt Securities and Other Investments

[0001564590-19-040490:notes:89]
At September 30, 2019, we held the following debt securities and other investments, recorded at fair value:

[0001564590-19-040490:notes:90]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 10,733 |  |  | $ | 95 |  |  | $ | — |  |  | $ | 10,828 |  |
| Municipal fixed-rate bonds |  |  | 931 |  |  |  | — |  |  |  | (1 | ) |  |  | 930 |  |
| Asset-backed bonds |  |  | 7,222 |  |  |  | 35 |  |  |  | (2 | ) |  |  | 7,255 |  |
| Mortgage/Agency-backed bonds |  |  | 7,366 |  |  |  | 29 |  |  |  | (7 | ) |  |  | 7,388 |  |
| U.S. government bonds |  |  | 9,160 |  |  |  | 4 |  |  |  | (21 | ) |  |  | 9,143 |  |
| Foreign government bonds |  |  | 372 |  |  |  | — |  |  |  | (3 | ) |  |  | 369 |  |
| Available-for-sale debt securities held at fair value |  | $ | 35,784 |  |  | $ | 163 |  |  | $ | (34 | ) |  | $ | 35,913 |  |

[0001564590-19-040490:notes:91]
At December 31, 2018, we held the following debt securities and other investments, recorded at fair value:

[0001564590-19-040490:notes:92]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 20,777 |  |  | $ | 19 |  |  | $ | (112 | ) |  | $ | 20,684 |  |
| Municipal fixed-rate bonds |  |  | 1,339 |  |  |  | — |  |  |  | (26 | ) |  |  | 1,313 |  |
| Asset-backed bonds |  |  | 5,230 |  |  |  | 5 |  |  |  | (14 | ) |  |  | 5,221 |  |
| Mortgage/Agency-backed bonds |  |  | 3,833 |  |  |  | 2 |  |  |  | (44 | ) |  |  | 3,791 |  |
| U.S. government bonds |  |  | 9,271 |  |  |  | 1 |  |  |  | (66 | ) |  |  | 9,206 |  |
| Foreign government bonds |  |  | 592 |  |  |  | — |  |  |  | (8 | ) |  |  | 584 |  |
| Available-for-sale debt securities held at fair value |  | $ | 41,042 |  |  | $ | 27 |  |  | $ | (270 | ) |  | $ | 40,799 |  |

[0001564590-19-040490:notes:93]
As of September 30, 2019, our debt securities had the following contractual maturities:

[0001564590-19-040490:notes:94]
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset- backed bonds |  |  | Mortgage / Agency- backed bonds |  |  | U.S. government bonds |  |  | Foreign government bonds |  |
| Less than one year |  | $ | 3,154 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| One to two years |  |  | 4,316 |  |  |  | 930 |  |  |  | 941 |  |  |  | 215 |  |  |  | — |  |  |  | — |  |
| Two to three years |  |  | 3,068 |  |  |  | — |  |  |  | 2,475 |  |  |  | 1,072 |  |  |  | 7,528 |  |  |  | — |  |
| Three to five years |  |  | 290 |  |  |  | — |  |  |  | 1,593 |  |  |  | 920 |  |  |  | 1,615 |  |  |  | 369 |  |
| Five to ten years |  |  | — |  |  |  | — |  |  |  | 1,666 |  |  |  | 680 |  |  |  | — |  |  |  | — |  |
| More than ten years |  |  | — |  |  |  | — |  |  |  | 580 |  |  |  | 4,501 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 10,828 |  |  | $ | 930 |  |  | $ | 7,255 |  |  | $ | 7,388 |  |  | $ | 9,143 |  |  | $ | 369 |  |

[0001564590-19-040490:notes:95]
Actual maturities may differ from contractual maturities as some borrowers have the right to call or prepay obligations with or without call or prepayment penalties.

[0001564590-19-040490:notes:96]
Realized gains and losses on sales of debt securities are computed under the specific identification method. The following table presents gross realized gains and losses related to our debt securities:

[0001564590-19-040490:notes:97]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Gross realized gains on debt securities |  | $ | 36 |  |  | $ | 24 |  |  | $ | 85 |  |  | $ | 49 |  |
| Gross realized losses on debt securities |  |  | (7 | ) |  |  | (50 | ) |  |  | (40 | ) |  |  | (365 | ) |
| Total gain (loss) recognized, net |  | $ | 29 |  |  | $ | (26 | ) |  | $ | 45 |  |  | $ | (316 | ) |

[0001564590-19-040490:notes:98]
Our investment policy provides limitations for issuer concentration, which limits, at the time of purchase, the concentration in any one issuer to 5% of the market value of our total investment portfolio.

[0001564590-19-040490:notes:99]
At September 30, 2019, we held a $25.6 million restricted certificate of deposit that is carried at cost and matures on January 8, 2020. This investment serves as a collateral deposit against the principal amount outstanding under loans made to ADTRAN pursuant to an Alabama State Industrial Development Authority revenue bond (the “Bond”), which totaled $25.6 million at September 30, 2019 and December 31, 2018. At September 30, 2019 and December 31, 2018, the estimated fair value of the Bond using a level 2 valuation technique was approximately $25.6 million and $25.4 million, respectively, based on a debt security with a comparable interest rate and maturity and a Standard and Poor’s credit rating of AA+. We have the right to offset the balance of the Bond with the collateral deposit in order to reduce the balance of the indebtedness. The Bond matures on January 1, 2020, and bears interest at the rate of 2% per annum. In conjunction with this program, we are eligible to receive certain economic incentives from the State of Alabama that reduce the amount of payroll withholdings we are required to remit to the state for those employment positions that qualify under this program. We are required to make payments in the amounts necessary to pay the interest on the amounts currently outstanding. We have made annual principal payments in addition to the interest amounts that are due. The restricted funds held as collateral against the outstanding principal amount of the Bond will be used to pay the outstanding principal and interest upon the Bond’s maturity.

[0001564590-19-040490:notes:100]
Marketable Equity Securities

[0001564590-19-040490:notes:101]
Our marketable equity securities consist of publicly traded stock, funds and certain other investments measured at fair value or cost (where appropriate).

[0001564590-19-040490:notes:102]
On January 1, 2018, we adopted ASU 2016-01, which requires us to measure all equity investments that do not result in consolidation and are not accounted for under the equity method at fair value, with any changes in fair value recognized in net investment gain (loss). Upon adoption, we reclassified $3.2 million of net unrealized gains related to marketable equity securities from accumulated other comprehensive income (loss) to retained earnings.

[0001564590-19-040490:notes:103]
ASU 2016-01 also provides a measurement alternative for equity investments that do not have a readily determinable fair value in which investments can be recorded at cost less impairment, if any, adjusted for observable price changes for an identical or similar investment. We elected to record our equity investment that does not have a readily determinable fair value using the measurement alternative method. As of December 31, 2018, the Company had a note receivable of approximately $4.3 million, which was included in other receivables on the Condensed Consolidated Balance Sheet. During the three months ended March 31, 2019, this amount was repaid and reissued in the form of debt and equity. Approximately $3.4 million was issued as an equity investment, which represented a non-cash investing activity. The carrying value of this investment under the measurement alternative was $3.4 million as of September 30, 2019. The remaining amount, approximately $0.9 million, was converted into a new note receivable, which is included in other receivables on the Condensed Consolidated Balance Sheet and represents a non-cash operating activity.

[0001564590-19-040490:notes:104]
Realized and unrealized gains and losses for our marketable equity securities for the three and nine months ended September 30, 2019 and 2018 were as follows:

[0001564590-19-040490:notes:105]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Realized gains (losses) on equity securities sold |  | $ | (20 | ) |  | $ | 1,240 |  |  | $ | (83 | ) |  | $ | 1,587 |  |
| Unrealized gains (losses) on equity securities held |  |  | (225 | ) |  |  | 3,293 |  |  |  | 8,233 |  |  |  | 4,129 |  |
| Total gain (loss) recognized, net |  | $ | (245 | ) |  | $ | 4,533 |  |  | $ | 8,150 |  |  | $ | 5,716 |  |

[0001564590-19-040490:notes:106]
As of September 30, 2019 and 2018, gross unrealized losses related to individual investments in a continuous loss position for twelve months or longer were not material.

[0001564590-19-040490:notes:107]
We have categorized our cash equivalents and our investments held at fair value into a three-level fair value hierarchy based on the priority of the inputs to the valuation technique for the cash equivalents and investments as follows: Level 1 - Values based on unadjusted quoted prices for identical assets or liabilities in an active market; Level 2 - Values based on quoted prices in markets that are not active or model inputs that are observable either directly or indirectly; Level 3 - Values based on prices or valuation techniques that require inputs that are both unobservable and significant to the overall fair value measurement. These inputs include information supplied by investees.

[0001564590-19-040490:notes:108]
|  |  |  |  |  |  | Fair Value Measurements at September 30, 2019 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,817 |  |  | $ | 1,817 |  |  | $ | — |  |  | $ | — |  |
| Commercial paper |  |  | 1,295 |  |  |  | — |  |  |  | 1,295 |  |  |  | — |  |
| Cash equivalents |  |  | 3,112 |  |  |  | 1,817 |  |  |  | 1,295 |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 10,828 |  |  |  | — |  |  |  | 10,828 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 930 |  |  |  | — |  |  |  | 930 |  |  |  | — |  |
| Asset-backed bonds |  |  | 7,255 |  |  |  | — |  |  |  | 7,255 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 7,388 |  |  |  | — |  |  |  | 7,388 |  |  |  | — |  |
| U.S. government bonds |  |  | 9,143 |  |  |  | 9,143 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 369 |  |  |  | — |  |  |  | 369 |  |  |  | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 32,543 |  |  |  | 32,543 |  |  |  | — |  |  |  | — |  |
| Equity in escrow |  |  | 165 |  |  |  | 165 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 20,580 |  |  |  | 20,580 |  |  |  | — |  |  |  | — |  |
| Total debt and equity securities at fair value |  |  | 89,201 |  |  |  | 62,431 |  |  |  | 26,770 |  |  |  | — |  |
| Total |  | $ | 92,313 |  |  | $ | 64,248 |  |  | $ | 28,065 |  |  | $ | — |  |

[0001564590-19-040490:notes:109]
|  |  |  |  |  |  | Fair Value Measurements at December 31, 2018 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,554 |  |  | $ | 1,554 |  |  | $ | — |  |  | $ | — |  |
| Cash equivalents |  |  | 1,554 |  |  |  | 1,554 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 20,684 |  |  |  | — |  |  |  | 20,684 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 1,313 |  |  |  | — |  |  |  | 1,313 |  |  |  | — |  |
| Asset-backed bonds |  |  | 5,221 |  |  |  | — |  |  |  | 5,221 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 3,791 |  |  |  | — |  |  |  | 3,791 |  |  |  | — |  |
| U.S. government bonds |  |  | 9,206 |  |  |  | 9,206 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 584 |  |  |  | — |  |  |  | 584 |  |  |  | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 26,763 |  |  |  | 26,763 |  |  |  | — |  |  |  | — |  |
| Equity in escrow |  |  | 253 |  |  |  | 253 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 18,256 |  |  |  | 18,256 |  |  |  | — |  |  |  | — |  |
| Total debt and equity securities at fair value |  |  | 86,071 |  |  |  | 54,478 |  |  |  | 31,593 |  |  |  | — |  |
| Total |  | $ | 87,625 |  |  | $ | 56,032 |  |  | $ | 31,593 |  |  | $ | — |  |

[0001564590-19-040490:notes:110]
The fair value of our Level 2 securities is calculated using a weighted average market price for each security. Market prices are obtained from a variety of industry standard data providers, large financial institutions, and other third-party sources. These multiple market prices are used as inputs into a distribution-curve-based algorithm to determine the daily market value of each security.


## us-gaap:InventoryDisclosureTextBlock

[0001564590-19-040490:notes:111]
[same as prior period, unchanged from 0001564590-19-035143:notes:107]

[0001564590-19-040490:notes:112]
At September 30, 2019 and December 31, 2018, inventory consisted of the following:

[0001564590-19-040490:notes:113]
|  |  | September 30, |  |  | December 31, |  |
| (In thousands) |  | 2019 |  |  | 2018 |  |
| Raw materials |  | $ | 39,133 |  |  | $ | 45,333 |  |
| Work in process |  |  | 1,083 |  |  |  | 1,638 |  |
| Finished goods |  |  | 64,725 |  |  |  | 52,877 |  |
| Total |  | $ | 104,941 |  |  | $ | 99,848 |  |

[0001564590-19-040490:notes:114]
Inventory reserves are established for estimated excess and obsolete inventory equal to the difference between the cost of the inventory and the estimated net realizable value of the inventory based on historical usage, known trends, inventory age, and market conditions. At September 30, 2019 and December 31, 2018, our inventory reserve was $32.0 million and $30.0 million, respectively.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001564590-19-040490:notes:115]
9. PROPERTY, PLANT AND EQUIPMENT

[0001564590-19-040490:notes:116]
At September 30, 2019 and December 31, 2018, property, plant and equipment consisted of the following:

[0001564590-19-040490:notes:117]
|  |  | September 30, |  |  | December 31, |  |
| (In thousands) |  | 2019 |  |  | 2018 |  |
| Land |  | $ | 4,575 |  |  | $ | 4,575 |  |
| Building and land improvements |  |  | 34,634 |  |  |  | 34,379 |  |
| Building |  |  | 68,247 |  |  |  | 68,183 |  |
| Furniture and fixtures |  |  | 19,878 |  |  |  | 19,831 |  |
| Computer hardware and software |  |  | 72,390 |  |  |  | 92,071 |  |
| Engineering and other equipment |  |  | 129,479 |  |  |  | 127,060 |  |
| Total Property, Plant and Equipment |  |  | 329,203 |  |  |  | 346,099 |  |
| Less accumulated depreciation |  |  | (255,819 | ) |  |  | (265,464 | ) |
| Total Property, Plant and Equipment, net |  | $ | 73,384 |  |  | $ | 80,635 |  |

[0001564590-19-040490:notes:118]
Depreciation expense was $3.1 million for the three months ended September 30, 2019 and 2018 and was $9.3 million and $9.5 million for the nine months ended September 30, 2019 and 2018, respectively, which is recorded in cost of sales, selling, general and administrative expenses and research and development expenses in the Condensed Consolidated Statements of Income.

[0001564590-19-040490:notes:119]
We review long-lived assets used in operations for impairment whenever events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable and the undiscounted cash flows estimated to be generated by the asset are less than the asset’s carrying value. During the three and nine months ended September 30, 2019, the Company recognized impairment charges of $3.9 million related to the abandonment of certain information technology projects in which we had previously capitalized costs related to these projects. The impairment charges were determined based on actual costs incurred as part of the projects.


## us-gaap:GoodwillDisclosureTextBlock

[0001564590-19-040490:notes:120]
10. GOODWILL

[0001564590-19-040490:notes:121]
Goodwill, all of which relates to our acquisitions of Bluesocket, Inc. in 2011 and SmartRG in 2018, was $7.0 million and $7.1 million at September 30, 2019 and December 31, 2018, respectively, of which $6.6 million and $0.4 million was allocated to our Network Solutions and Services & Support reportable segments, respectively, as of September 30, 2019, and of which $6.7 million and $0.4 million was allocated to our Network Solutions and Services & Support reportable segments, respectively, as of December 31, 2018. Goodwill related to our SmartRG acquisition was reduced by $0.1 million during the nine months ended September 30, 2019 as a result of a measurement period adjustment.

[0001564590-19-040490:notes:122]
We evaluate the carrying value of goodwill during the fourth quarter of each year and between annual evaluations if events occur or circumstances change that would more likely than not reduce the fair value of the reporting unit below its carrying amount. We have elected to first assess the qualitative factors to determine whether it is more likely than not that the fair value of the reporting unit to which the goodwill is assigned is less than its carrying amount as a basis for determining whether it is necessary to perform the two-step impairment test. If we determine that it is more likely than not that its fair value is less than its carrying amount, then the two-step impairment test will be performed. Based on the results of our qualitative assessment in the fourth quarter of 2018, we concluded that it was not necessary to perform the two-step impairment test. No events or circumstances occurred during the nine months ended September 30, 2019 that would more likely than not reduce the fair value of goodwill below its carrying value.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001564590-19-040490:notes:123]
11. INTANGIBLE ASSETS

[0001564590-19-040490:notes:124]
Intangible assets include those acquired in conjunction with several acquisitions since 2011, with the most recent being SmartRG, Inc. in November 2018.

[0001564590-19-040490:notes:125]
The following table presents our intangible assets as of September 30, 2019 and December 31, 2018:

[0001564590-19-040490:notes:126]
|  |  | September 30, 2019 |  |  | December 31, 2018 |  |
| (In thousands) |  | Gross Value |  |  | Accumulated Amortization |  |  | Net Value |  |  | Gross Value |  |  | Accumulated Amortization |  |  | Net Value |  |
| Customer relationships |  | $ | 22,235 |  |  | $ | (6,671 | ) |  | $ | 15,564 |  |  | $ | 22,455 |  |  | $ | (5,380 | ) |  | $ | 17,075 |  |
| Developed technology |  |  | 10,170 |  |  |  | (3,094 | ) |  |  | 7,076 |  |  |  | 12,801 |  |  |  | (4,867 | ) |  |  | 7,934 |  |
| Licensed technology |  |  | 5,900 |  |  |  | (1,011 | ) |  |  | 4,889 |  |  |  | 5,900 |  |  |  | (520 | ) |  |  | 5,380 |  |
| Supplier relationships |  |  | 2,800 |  |  |  | (2,158 | ) |  |  | 642 |  |  |  | 2,800 |  |  |  | (1,108 | ) |  |  | 1,692 |  |
| Licensing agreements |  |  | 560 |  |  |  | (61 | ) |  |  | 499 |  |  |  | 560 |  |  |  | (5 | ) |  |  | 555 |  |
| Patents |  |  | 500 |  |  |  | (209 | ) |  |  | 291 |  |  |  | 500 |  |  |  | (157 | ) |  |  | 343 |  |
| Trade names |  |  | 310 |  |  |  | (158 | ) |  |  | 152 |  |  |  | 310 |  |  |  | (106 | ) |  |  | 204 |  |
| Total |  | $ | 42,475 |  |  | $ | (13,362 | ) |  | $ | 29,113 |  |  | $ | 45,326 |  |  | $ | (12,143 | ) |  | $ | 33,183 |  |

[0001564590-19-040490:notes:127]
Amortization expense was $1.3 million and $0.9 million for the three months ended September 30, 2019 and 2018, respectively, and $4.0 million and $2.4 million for the nine months ended September 30, 2019 and 2018, respectively.

[0001564590-19-040490:notes:128]
As of September 30, 2019, estimated future amortization expense of our intangible assets was as follows:

[0001564590-19-040490:notes:129]
| (In thousands) |  | Amount |  |
| Remainder of 2019 |  | $ | 1,329 |  |
| 2020 |  |  | 4,436 |  |
| 2021 |  |  | 4,088 |  |
| 2022 |  |  | 3,464 |  |
| 2023 |  |  | 3,313 |  |
| Thereafter |  |  | 12,483 |  |
| Total |  | $ | 29,113 |  |


## adtn:LeasesDisclosureTextBlock

[0001564590-19-040490:notes:130]
12. LEASES

[0001564590-19-040490:notes:131]
Operating Leases

[0001564590-19-040490:notes:132]
[same as prior period, unchanged from 0001564590-19-035143:notes:123]

[0001564590-19-040490:notes:133]
As of September 30, 2019, our operating leases have remaining lease terms of two months to six years, some of which include options to extend the leases for up to five years, and some of which include options to terminate the leases within three months. For those leases that are reasonably assured to be renewed, we have included the option to extend as part of our right of use asset and lease liability. Leases with an initial term of 12 months or less are not recorded on the balance sheet and lease expense for these leases is recognized on a straight-line basis over the lease term. Lease expense related to these short-term leases was $0.1 million and $0.3 million for the three and nine months ended September 30, 2019, respectively, and is included in cost of sales, selling, general and administrative expenses and research and development expenses in the Condensed Consolidated Statements of Income. Lease expense related to variable lease payments that do not depend on an index or rate, such as real estate taxes and insurance reimbursements, was $0.3 million and $0.7 million for the three and nine months ended September 30, 2019. For lease agreements entered into or reassessed after the adoption of Topic 842, we elected to not separate lease and non-lease components. None of our lease agreements contain any material residual value guarantees or material restrictive covenants.

[0001564590-19-040490:notes:134]
[same as prior period, unchanged from 0001564590-19-035143:notes:125]

[0001564590-19-040490:notes:135]
|  |  |  |  | September 30, |  |  | January 1, |  |
| (In thousands) |  | Classification |  | 2019 |  |  | 2019 (1) |  |
| Assets |  |  |  |  |  |  |  |  |  |  |
| Operating lease asset |  | Other assets |  | $ | 18,529 |  |  | $ | 10,322 |  |
| Total lease assets |  |  |  | $ | 18,529 |  |  | $ | 10,322 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |
| Current operating lease liability |  | Accrued expenses |  | $ | 3,063 |  |  | $ | 2,948 |  |
| Non-current operating lease liability |  | Other non-current liabilities |  |  | 15,659 |  |  |  | 7,374 |  |
| Total lease liability |  |  |  | $ | 18,722 |  |  | $ | 10,322 |  |

[0001564590-19-040490:notes:136]
[same as prior period, unchanged from 0001564590-19-035143:notes:127]

[0001564590-19-040490:notes:137]
The components of lease expense included in the Condensed Consolidated Statements of Income for the three and nine months ended September 30, 2019 were as follows:

[0001564590-19-040490:notes:138]
| (in thousands) |  | Three Months Ended September 30, 2019 |  |  | Nine Months Ended September 30, 2019 |  |
| Selling, general and administrative expenses |  | $ | 352 |  |  | $ | 1,050 |  |
| Research and development expenses |  |  | 847 |  |  |  | 1,731 |  |
| Cost of sales |  |  | 16 |  |  |  | 49 |  |
| Total operating lease expense |  | $ | 1,215 |  |  | $ | 2,830 |  |

[0001564590-19-040490:notes:139]
As of September 30, 2019, operating lease liabilities included on the Condensed Consolidated Balance Sheet by future maturity were as follows:

[0001564590-19-040490:notes:140]
| (In thousands) |  | Amount |  |
| Remainder of 2019 |  | $ | 1,044 |  |
| 2020 |  |  | 3,417 |  |
| 2021 |  |  | 3,071 |  |
| 2022 |  |  | 2,672 |  |
| 2023 |  |  | 2,350 |  |
| Thereafter |  |  | 8,258 |  |
| Total lease payments |  |  | 20,812 |  |
| Less: Interest |  |  | (2,090 | ) |
| Present value of lease liabilities |  | $ | 18,722 |  |

[0001564590-19-040490:notes:141]
Future operating lease payments include $7.6 million related to options to extend lease terms that are reasonably certain of being exercised. There are no legally binding leases that have not yet commenced.

[0001564590-19-040490:notes:142]
As of December 31, 2018, future minimum rental payments under non-cancelable operating leases, including renewals determined to be reasonably assured as of December 31, 2018, with original maturities of greater than 12 months, were as follows:

[0001564590-19-040490:notes:143]
[same as prior period, unchanged from 0001564590-19-035143:notes:134]

[0001564590-19-040490:notes:144]
[same as prior period, unchanged from 0001564590-19-035143:notes:135]

[0001564590-19-040490:notes:145]
Our leases do not provide an implicit borrowing rate and therefore we use an incremental borrowing rate based on the information available at commencement date in determining the present value of lease payments. We used the incremental borrowing rate on January 1, 2019, for operating leases that commenced on or prior to that date. The incremental borrowing rate was determined on a portfolio basis by grouping leases with similar terms as well as grouping leases based on a U.S. dollar or Euro functional currency.  The actual rate is then determined based on a credit spread over LIBOR as well as the Bloomberg Curve Matrix for the U.S. Communications section. The following table provides information about our weighted average lease terms and weighted average discount rates as of September 30, 2019:

[0001564590-19-040490:notes:146]
|  |  | September 30, 2019 |  |
| Weighted average remaining lease term (years) |  |  |  |  |
| Operating leases with USD functional currency |  |  | 8.4 |  |
| Operating leases with Euro functional currency |  |  | 4.6 |  |
| Weighted average discount rate |  |  |  |  |
| Operating leases with USD functional currency |  |  | 3.22 | % |
| Operating leases with Euro functional currency |  |  | 1.84 | % |

[0001564590-19-040490:notes:147]
Supplemental cash flow information related to operating leases is as follows:

[0001564590-19-040490:notes:148]
|  |  | Nine Months Ended |  |
| (In thousands) |  | September 30, 2019 |  |
| Cash paid for amounts included in the measurement of operating lease assets / liabilities |  |  |  |  |
| Cash used in operating activities related to operating leases |  | $ | (775 | ) |
| Right-of-use assets obtained in exchange for lease obligations |  | $ | 21,418 |  |

[0001564590-19-040490:notes:149]
Sales-Type Leases

[0001564590-19-040490:notes:150]
We are the lessor in sales-type lease arrangements for network equipment, which have initial terms of up to five years. Our sales-type lease arrangements contain either a provision whereby the network equipment reverts back to us upon the expiration of the lease or a provision that allows the lessee to purchase the network equipment at a bargain purchase amount. In addition, our sales-type lease arrangements do not contain any residual value guarantees or material restrictive covenants. The allocation of the consideration between lease and non-lease components is determined by standalone sales price by component. The net investment in sales-type leases consists of lease receivables less unearned income. Collectability of sales-type leases is evaluated periodically at an individual customer level. At September 30, 2019 and December 31, 2018, we had no allowance for credit losses for our net investment in sales-type leases. As of September 30, 2019 and December 31, 2018, the components of the net investment in sales-type leases were as follows:

[0001564590-19-040490:notes:151]
|  |  | September 30, |  |  | December 31, |  |
| (In thousands) |  | 2019 |  |  | 2018 |  |
| Current minimum lease payments receivable(1) |  | $ | 3,643 |  |  | $ | 11,339 |  |
| Non-current minimum lease payments receivable(2) |  |  | 1,073 |  |  |  | 1,670 |  |
| Total minimum lease payments receivable |  |  | 4,716 |  |  |  | 13,009 |  |
| Less: Current unearned revenue |  |  | 445 |  |  |  | 631 |  |
| Less: Non-current unearned revenue |  |  | 210 |  |  |  | 473 |  |
| Net investment in sales-type leases |  | $ | 4,061 |  |  | $ | 11,905 |  |

[0001564590-19-040490:notes:152]
|  | (2) | Included in other assets on the Condensed Consolidated Balance Sheet. |

[0001564590-19-040490:notes:153]
The components of sales-type lease gross profit recognized at the lease commencement date and interest and dividend income, included in the Condensed Consolidated Statements of Income for the three and nine months ended September 30, 2019, were as follows:

[0001564590-19-040490:notes:154]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
| (In thousands) |  | September 30, 2019 |  |  | September 30, 2019 |  |
| Sales - Network Solutions |  | $ | 47 |  |  | $ | 1,668 |  |
| Cost of sales - Network Solutions |  |  | 25 |  |  |  | 660 |  |
| Gross profit |  | $ | 22 |  |  | $ | 1,008 |  |
| Interest and dividend income |  | $ | 92 |  |  | $ | 278 |  |

[0001564590-19-040490:notes:155]
As of September 30, 2019, future minimum lease payments to be received from sales-type leases were as follows:

[0001564590-19-040490:notes:156]
| (In thousands) |  | Amount |  |
| Remainder of 2019 |  | $ | 2,700 |  |
| 2020 |  |  | 1,162 |  |
| 2021 |  |  | 542 |  |
| 2022 |  |  | 225 |  |
| 2023 |  |  | 83 |  |
| Thereafter |  |  | 4 |  |
| Total |  | $ | 4,716 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001564590-19-040490:notes:157]
13. STOCKHOLDERS’ EQUITY

[0001564590-19-040490:notes:158]
[same as prior period, unchanged from 0001564590-19-035143:notes:148]

[0001564590-19-040490:notes:159]
Since 1997, our Board of Directors has approved multiple share repurchase programs that have authorized repurchases of our common stock, which are implemented through open market or private purchases from time to time as conditions warrant. During the nine months ended September 30, 2019, we repurchased 13,000 shares of our common stock at an average price of $14.06 per share. As of September 30, 2019, we had the authority to purchase an additional 2.5 million shares of our common stock under the current authorization of up to 5.0 million shares.

[0001564590-19-040490:notes:160]
Other Comprehensive Income (Loss)

[0001564590-19-040490:notes:161]
The following tables present the changes in accumulated other comprehensive income (loss), net of tax, by component for the three months ended September 30, 2019 and 2018:

[0001564590-19-040490:notes:162]
|  |  | Three Months Ended September 30, 2019 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | ASU 2018-02 Adoption (1) |  |  | Total |  |
| As of June 30, 2019 |  | $ | (271 | ) |  | $ | (7,770 | ) |  | $ | (6,439 | ) |  | $ | 385 |  |  | $ | (14,095 | ) |
| Other comprehensive loss before reclassifications |  |  | (39 | ) |  |  | — |  |  |  | (2,486 | ) |  |  | — |  |  |  | (2,525 | ) |
| Amounts reclassified from accumulated other comprehensive income (loss) |  |  | 24 |  |  |  | 90 |  |  |  | — |  |  |  | — |  |  |  | 114 |  |
| Net current period other comprehensive income (loss) |  |  | (15 | ) |  |  | 90 |  |  |  | (2,486 | ) |  |  | — |  |  |  | (2,411 | ) |
| As of September 30, 2019 |  | $ | (286 | ) |  | $ | (7,680 | ) |  | $ | (8,925 | ) |  | $ | 385 |  |  | $ | (16,506 | ) |

[0001564590-19-040490:notes:163]
|  | (1) | With the adoption of ASU 2018-02 on January 1, 2019, stranded tax effects related to the Tax Cuts and Jobs Act of 2017 were reclassified to retained earnings. See Note 1. |

[0001564590-19-040490:notes:164]
|  |  | Three Months Ended September 30, 2018 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | Total |  |
| As of June 30, 2018 |  | $ | (741 | ) |  | $ | (4,219 | ) |  | $ | (4,158 | ) |  | $ | (9,118 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | 1,208 |  |  |  | — |  |  |  | (451 | ) |  |  | 757 |  |
| Amounts reclassified from accumulated other comprehensive income (loss) |  |  | (1,240 | ) |  |  | 37 |  |  |  | — |  |  |  | (1,203 | ) |
| Net current period other comprehensive income (loss) |  |  | (32 | ) |  |  | 37 |  |  |  | (451 | ) |  |  | (446 | ) |
| As of September 30, 2018 |  | $ | (773 | ) |  | $ | (4,182 | ) |  | $ | (4,609 | ) |  | $ | (9,564 | ) |

[0001564590-19-040490:notes:165]
The following tables present the changes in accumulated other comprehensive income (loss), net of tax, by component for the nine months ended September 30, 2019 and 2018:

[0001564590-19-040490:notes:166]
|  |  | Nine Months Ended September 30, 2019 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | ASU 2018-02 Adoption(1) |  |  | Total |  |
| As of December 31, 2018 |  | $ | (563 | ) |  | $ | (8,041 | ) |  | $ | (5,812 | ) |  | $ | — |  |  | $ | (14,416 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | 372 |  |  |  | — |  |  |  | (3,113 | ) |  |  | — |  |  |  | (2,741 | ) |
| Amounts reclassified from accumulated other comprehensive income (loss) |  |  | (95 | ) |  |  | 361 |  |  |  | — |  |  |  | — |  |  |  | 266 |  |
| Amounts reclassified to retained earnings (1) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 385 |  |  |  | 385 |  |
| Net current period other comprehensive income (loss) |  |  | 277 |  |  |  | 361 |  |  |  | (3,113 | ) |  |  | 385 |  |  |  | (2,090 | ) |
| As of September 30, 2019 |  | $ | (286 | ) |  | $ | (7,680 | ) |  | $ | (8,925 | ) |  | $ | 385 |  |  | $ | (16,506 | ) |

[0001564590-19-040490:notes:167]
|  |  | Nine Months Ended September 30, 2018 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | Total |  |
| As of December 31, 2017 |  | $ | 2,567 |  |  | $ | (4,286 | ) |  | $ | (1,576 | ) |  | $ | (3,295 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | 869 |  |  |  | — |  |  |  | (3,033 | ) |  |  | (2,164 | ) |
| Amounts reclassified from accumulated other comprehensive income (loss) |  |  | (989 | ) |  |  | 104 |  |  |  | — |  |  |  | (885 | ) |
| Amounts reclassified to retained earnings (1) |  |  | (3,220 | ) |  |  | — |  |  |  | — |  |  |  | (3,220 | ) |
| Net current period other comprehensive income (loss) |  |  | (3,340 | ) |  |  | 104 |  |  |  | (3,033 | ) |  |  | (6,269 | ) |
| As of September 30, 2018 |  | $ | (773 | ) |  | $ | (4,182 | ) |  | $ | (4,609 | ) |  | $ | (9,564 | ) |

[0001564590-19-040490:notes:168]
|  | (1) | With the Company’s adoption of ASU 2016-01 on January 1, 2018, unrealized gains on our equity investments were reclassified to retained earnings. See Note 7. |

[0001564590-19-040490:notes:169]
The following tables present the details of reclassifications out of accumulated other comprehensive income (loss) for the three months ended September 30, 2019 and 2018:

[0001564590-19-040490:notes:170]
|  |  | Three Months Ended September 30, 2019 |
| (In thousands) |  | Amount Reclassified from Accumulated Other Comprehensive Income (Loss) |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for-sale securities: |  |  |  |  |  |  |
| Net realized losses on sales of securities |  | $ | (32 | ) |  | Net investment gain |
| Defined benefit plan adjustments – actuarial losses |  |  | (130 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | (162 | ) |  |  |
| Tax benefit |  |  | 48 |  |  |  |
| Total reclassifications for the period, net of tax |  | $ | (114 | ) |  |  |

[0001564590-19-040490:notes:171]
[same as prior period, unchanged from 0001564590-19-035143:notes:161]

[0001564590-19-040490:notes:172]
|  |  | Three Months Ended September 30, 2018 |
| (In thousands) |  | Amount Reclassified from Accumulated Other Comprehensive Income (Loss) |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for-sale securities: |  |  |  |  |  |  |
| Net realized gains on sales of securities |  | $ | 1,676 |  |  | Net investment gain |
| Defined benefit plan adjustments – actuarial losses |  |  | (54 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | 1,622 |  |  |  |
| Tax expense |  |  | (419 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 1,203 |  |  |  |

[0001564590-19-040490:notes:173]
The following tables present the details of reclassifications out of accumulated other comprehensive income (loss) for the nine months ended September 30, 2019 and 2018:

[0001564590-19-040490:notes:174]
|  |  | Nine Months Ended September 30, 2019 |
| (In thousands) |  | Amount Reclassified from Accumulated Other Comprehensive Income (Loss) |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for-sale securities: |  |  |  |  |  |  |
| Net realized gains on sales of securities |  | $ | 128 |  |  | Net investment gain |
| Defined benefit plan adjustments – actuarial losses |  |  | (523 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | (395 | ) |  |  |
| Tax benefit |  |  | 129 |  |  |  |
| Total reclassifications for the period, net of tax |  | $ | (266 | ) |  |  |

[0001564590-19-040490:notes:175]
|  |  | Nine Months Ended September 30, 2018 |
| (In thousands) |  | Amount Reclassified from Accumulated Other Comprehensive Income (Loss) |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for-sale securities: |  |  |  |  |  |  |
| Net realized gains on sales of securities |  | $ | 1,352 |  |  | Net investment gain |
| Defined benefit plan adjustments – actuarial losses |  |  | (151 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | 1,201 |  |  |  |
| Tax expense |  |  | (316 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 885 |  |  |  |

[0001564590-19-040490:notes:176]
The following table presents the tax effects related to the change in each component of other comprehensive income (loss) for the three months ended September 30, 2019 and 2018:

[0001564590-19-040490:notes:177]
|  |  | Three Months Ended |  |  | Three Months Ended |  |
|  |  | September 30, 2019 |  |  | September 30, 2018 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |
| Unrealized gain (loss) on available-for-sale securities |  | $ | (53 | ) |  | $ | 14 |  |  | $ | (39 | ) |  | $ | 1,632 |  |  | $ | (424 | ) |  | $ | 1,208 |  |
| Reclassification adjustment for amounts related to available-for-sale investments included in net income (loss) |  |  | 32 |  |  |  | (8 | ) |  |  | 24 |  |  |  | (1,676 | ) |  |  | 436 |  |  |  | (1,240 | ) |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net income (loss) |  |  | 130 |  |  |  | (40 | ) |  |  | 90 |  |  |  | 54 |  |  |  | (17 | ) |  |  | 37 |  |
| Foreign currency translation adjustment |  |  | (2,486 | ) |  |  | — |  |  |  | (2,486 | ) |  |  | (451 | ) |  |  | — |  |  |  | (451 | ) |
| Total Other Comprehensive Loss |  | $ | (2,377 | ) |  | $ | (34 | ) |  | $ | (2,411 | ) |  | $ | (441 | ) |  | $ | (5 | ) |  | $ | (446 | ) |

[0001564590-19-040490:notes:178]
The following table presents the tax effects related to the change in each component of other comprehensive income (loss) for the nine months ended September 30, 2019 and 2018:

[0001564590-19-040490:notes:179]
|  |  | Nine Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, 2019 |  |  | September 30, 2018 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |
| Unrealized gain (loss) on available-for-sale securities |  | $ | 503 |  |  | $ | (131 | ) |  | $ | 372 |  |  | $ | 1,174 |  |  | $ | (305 | ) |  | $ | 869 |  |
| Reclassification adjustment for amounts related to available-for-sale investments included in net income (loss) |  |  | (128 | ) |  |  | 33 |  |  |  | (95 | ) |  |  | (1,352 | ) |  |  | 363 |  |  |  | (989 | ) |
| Reclassification adjustment for amounts reclassed to retained earnings related to the adoption of ASU 2016-01 |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (3,220 | ) |  |  | — |  |  |  | (3,220 | ) |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net income (loss) |  |  | 523 |  |  |  | (162 | ) |  |  | 361 |  |  |  | 151 |  |  |  | (47 | ) |  |  | 104 |  |
| Foreign currency translation adjustment |  |  | (3,113 | ) |  |  | — |  |  |  | (3,113 | ) |  |  | (3,033 | ) |  |  | — |  |  |  | (3,033 | ) |
| Total Other Comprehensive Income (Loss) |  | $ | (2,215 | ) |  | $ | (260 | ) |  | $ | (2,475 | ) |  | $ | (6,280 | ) |  | $ | 11 |  |  | $ | (6,269 | ) |


## us-gaap:EarningsPerShareTextBlock

[0001564590-19-040490:notes:180]
14. EARNINGS (LOSS) PER SHARE

[0001564590-19-040490:notes:181]
A summary of the calculation of basic and diluted earnings (loss) per share for the three and nine months ended September 30, 2019 and 2018 is as follows:

[0001564590-19-040490:notes:182]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands, except per share amounts) |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Numerator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) |  | $ | (46,123 | ) |  | $ | 7,589 |  |  | $ | (41,358 | ) |  | $ | (10,895 | ) |
| Denominator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average number of shares – basic |  |  | 47,824 |  |  |  | 47,710 |  |  |  | 47,803 |  |  |  | 47,927 |  |
| Effect of dilutive securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock options |  |  | — |  |  |  | 27 |  |  |  | — |  |  |  | — |  |
| PSUs, RSUs and restricted stock |  |  | — |  |  |  | 97 |  |  |  | — |  |  |  | — |  |
| Weighted average number of shares – diluted |  |  | 47,824 |  |  |  | 47,834 |  |  |  | 47,803 |  |  |  | 47,927 |  |
| Earnings (loss) per share – basic |  | $ | (0.96 | ) |  | $ | 0.16 |  |  | $ | (0.87 | ) |  | $ | (0.23 | ) |
| Earnings (loss) per share – diluted |  | $ | (0.96 | ) |  | $ | 0.16 |  |  | $ | (0.87 | ) |  | $ | (0.23 | ) |

[0001564590-19-040490:notes:183]
For the three months ended September 30, 2018, 1.8 million stock options were outstanding but were not included in the computation of diluted earnings per share. These stock options were excluded because their exercise prices were greater than the average market price of the common shares, during the quarter, therefore making them anti-dilutive under the treasury stock method.

[0001564590-19-040490:notes:184]
As a result of the net loss for the three months ended September 30, 2019, and for the nine months ended September 30, 2019 and 2018, 4.1 million, 3.0 million and 2.3 million, respectively, shares of unvested stock options, PSUs, RSUs and restricted stock were excluded from the calculation of diluted EPS due to their anti-dilutive effect.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-19-040490:notes:185]
15. SEGMENT INFORMATION

[0001564590-19-040490:notes:186]
[same as prior period, unchanged from 0001564590-19-035143:notes:175]

[0001564590-19-040490:notes:187]
We evaluate the performance of our segments based on gross profit; therefore, selling, general and administrative expenses, research and development expenses, interest and dividend income, interest expense, net investment gain (loss), other income (expense) and (provision) benefit for income taxes are reported on a company-wide, functional basis only. There is no inter-segment revenue.

[0001564590-19-040490:notes:188]
The following table presents information about the sales and gross profit of our reportable segments for the three and nine months ended September 30, 2019 and 2018. We do not produce asset information by reportable segment; therefore, it is not reported.

[0001564590-19-040490:notes:189]
|  |  | Three Months Ended |  |
|  |  | September 30, 2019 |  |  | September 30, 2018 |  |
| (In thousands) |  | Sales |  |  | Gross Profit |  |  | Sales |  |  | Gross Profit |  |
| Network Solutions |  | $ | 94,018 |  |  | $ | 37,574 |  |  | $ | 121,043 |  |  | $ | 51,100 |  |
| Services & Support |  |  | 20,074 |  |  |  | 8,757 |  |  |  | 19,292 |  |  |  | 7,348 |  |
| Total |  | $ | 114,092 |  |  | $ | 46,331 |  |  | $ | 140,335 |  |  | $ | 58,448 |  |

[0001564590-19-040490:notes:190]
|  |  | Nine Months Ended |  |
|  |  | September 30, 2019 |  |  | September 30, 2018 |  |
| (In thousands) |  | Sales |  |  | Gross Profit |  |  | Sales |  |  | Gross Profit |  |
| Network Solutions |  | $ | 359,007 |  |  | $ | 151,654 |  |  | $ | 341,359 |  |  | $ | 133,175 |  |
| Services & Support |  |  | 55,267 |  |  |  | 20,304 |  |  |  | 47,830 |  |  |  | 15,002 |  |
| Total |  | $ | 414,274 |  |  | $ | 171,958 |  |  | $ | 389,189 |  |  | $ | 148,177 |  |

[0001564590-19-040490:notes:191]
[same as prior period, unchanged from 0001564590-19-035143:notes:181]

[0001564590-19-040490:notes:192]
The following table represents sales information by geographic area for the three and nine months ended September 30, 2019 and 2018:

[0001564590-19-040490:notes:193]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| United States |  | $ | 83,144 |  |  | $ | 83,730 |  |  | $ | 230,960 |  |  | $ | 214,039 |  |
| International |  |  | 30,948 |  |  |  | 56,605 |  |  |  | 183,314 |  |  |  | 175,150 |  |
| Total |  | $ | 114,092 |  |  | $ | 140,335 |  |  | $ | 414,274 |  |  | $ | 389,189 |  |


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001564590-19-040490:notes:194]
16. LIABILITY FOR WARRANTY RETURNS

[0001564590-19-040490:notes:195]
Our products generally include warranties of 90 days to five years for product defects. We accrue for warranty returns at the time revenue is recognized based on our estimate of the cost to repair or replace the defective products. We engage in extensive product quality programs and processes, including actively monitoring and evaluating the quality of our component suppliers. Our products continue to become more complex in both size and functionality as many of our product offerings migrate from line card applications to total systems. The increasing complexity of our products will cause warranty incidences, when they arise, to be more costly. Our estimates regarding future warranty obligations may change due to product failure rates, material usage and other rework costs incurred in correcting a product failure. In addition, from time to time, specific warranty accruals may be recorded if unforeseen problems arise. Should our actual experience relative to these factors be worse than our estimates, we will be required to record additional warranty expense. Alternatively, if we provide for more reserves than we require, we will reverse a portion of such provisions in future periods. The liability for warranty obligations totaled $8.7 million and $8.6 million at September 30, 2019 and December 31, 2018, respectively, which amounts are included in accrued expenses in the accompanying Condensed Consolidated Balance Sheets. During the three months ended September 30, 2018, we had a reversal of prior provisions, the impact of which is reflected in the table below.

[0001564590-19-040490:notes:196]
A reconciliation of the beginning and ending warranty accrual for the three and nine months ended September 30, 2019 and 2018 is as follows:

[0001564590-19-040490:notes:197]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Balance at beginning of period |  | $ | 8,972 |  |  | $ | 10,111 |  |  | $ | 8,623 |  |  | $ | 9,724 |  |
| Plus: Amounts charged to cost and expenses |  |  | 816 |  |  |  | (34 | ) |  |  | 3,796 |  |  |  | 6,649 |  |
| Less: Deductions |  |  | (1,131 | ) |  |  | (1,053 | ) |  |  | (3,762 | ) |  |  | (7,349 | ) |
| Balance at end of period |  | $ | 8,657 |  |  | $ | 9,024 |  |  | $ | 8,657 |  |  | $ | 9,024 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-19-040490:notes:198]
17. COMMITMENTS AND CONTINGENCIES

[0001564590-19-040490:notes:199]
Securities Class Action Lawsuit

[0001564590-19-040490:notes:200]
On October 17, 2019, a purported stockholder class action lawsuit, captioned Burbridge v. ADTRAN, Inc. et al., Docket No. 19-cv-09619, was filed in the United States District Court for the Southern District of New York against the Company, two of its current executive officers and one of its former executive officers.  The complaint alleges violations of federal securities laws and seeks unspecified compensatory damages on behalf of purported purchasers of ADTRAN securities between February 28, 2019 and October 9, 2019.  The lawsuit claims that the defendants made materially false and misleading statements regarding, and/or failed to disclose material adverse facts about, the Company’s business, operations and prospects, specifically relating to the Company’s internal control over financial reporting, excess and obsolete inventory reserves, financial results and shipments from a Latin American customer.  Investors in ADTRAN securities have until December 16, 2019 to move the court to serve as lead plaintiff in this action.  We disagree with the claims made in the complaint and intend to vigorously defend against this lawsuit.  At this time, we are unable to predict the outcome of or estimate the possible loss or range of loss, if any, associated with this lawsuit.

[0001564590-19-040490:notes:201]
Other Legal Matters

[0001564590-19-040490:notes:202]
In addition to the litigation described above, from time to time we are subject to or otherwise involved in various lawsuits, claims, investigations and legal proceedings that arise out of or are incidental to the conduct of our business (collectively, “Legal Matters”), including those relating to employment matters, patent rights, regulatory compliance matters, stockholder claims, and contractual and other commercial disputes.  Such Legal Matters, even if not meritorious, could result in the expenditure of significant financial and managerial resources.  Additionally, an unfavorable outcome in a legal matter, including in a patent dispute, could require the Company to pay damages, entitle claimants to other relief, such as royalties, or could prevent the Company from selling some of its products in certain jurisdictions.  While the Company cannot predict with certainty the results of the Legal Matters in which it is currently involved, the Company does not expect that the ultimate outcome of such Legal Matters will individually or in the aggregate have a material adverse effect on its business, results of operations, financial condition or cash flows.

[0001564590-19-040490:notes:203]
Investment Commitment

[0001564590-19-040490:notes:204]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, of which $7.7 million has been applied as of September 30, 2019.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-19-040490:notes:205]
18. RESTRUCTURING

[0001564590-19-040490:notes:206]
In October 2019, the Company announced its plans to reduce its operating expenses, including global restructuring. During the three and nine months ended September 30, 2019, the Company incurred approximately $1.1 million and $1.9 million, respectively, related to these plans.

[0001564590-19-040490:notes:207]
In February 2019, we announced the restructuring of certain of our workforce predominantly in Germany, which included the closure of our office location in Munich, Germany accompanied by relocation or severance benefits for the affected employees. We also offered voluntary early retirement to certain other employees, which was announced in March 2019.  The restructuring is expected to be completed in the fourth quarter of 2019.

[0001564590-19-040490:notes:208]
In January 2018, we announced an early retirement incentive program for employees that met certain requirements. The cumulative amount incurred during the year ended December 31, 2018 related to this restructuring program was $7.3 million, of which $0.3 million and $7.2 million was incurred during the three and nine months ended September 30, 2018, respectively. We do not expect to incur any additional expenses related to this restructuring program.

[0001564590-19-040490:notes:209]
A reconciliation of the beginning and ending restructuring liability, which is included in accrued wages and benefits in the Condensed Consolidated Balance Sheets, is as follows:

[0001564590-19-040490:notes:210]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
| (In thousands) |  | September 30, 2019 |  |  | September 30, 2019 |  |
| Balance at beginning of period |  | $ | 2,655 |  |  | $ | 185 |  |
| Plus: Amounts charged to cost and expense |  |  | 1,195 |  |  |  | 4,658 |  |
| Less: Amounts paid |  |  | (252 | ) |  |  | (1,245 | ) |
| Balance at end of period |  | $ | 3,598 |  |  | $ | 3,598 |  |

[0001564590-19-040490:notes:211]
[same as prior period, unchanged from 0001564590-19-035143:notes:196]

[0001564590-19-040490:notes:212]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Selling, general and administrative expenses |  | $ | 531 |  |  | $ | 261 |  |  | $ | 2,078 |  |  | $ | 2,661 |  |
| Research and development expenses |  |  | 602 |  |  |  | — |  |  |  | 1,833 |  |  |  | 1,814 |  |
| Cost of sales |  |  | 62 |  |  |  | — |  |  |  | 747 |  |  |  | 2,761 |  |
| Total restructuring expenses |  | $ | 1,195 |  |  | $ | 261 |  |  | $ | 4,658 |  |  | $ | 7,236 |  |

[0001564590-19-040490:notes:213]
The following table represents the components of restructuring expense by geographic area for the three and nine months ended September 30, 2019 and 2018:

[0001564590-19-040490:notes:214]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Domestic |  | $ | 1,116 |  |  | $ | 256 |  |  | $ | 1,941 |  |  | $ | 7,096 |  |
| International |  |  | 79 |  |  |  | 5 |  |  |  | 2,717 |  |  |  | 140 |  |
| Total restructuring expenses |  | $ | 1,195 |  |  | $ | 261 |  |  | $ | 4,658 |  |  | $ | 7,236 |  |


## us-gaap:SubsequentEventsTextBlock

[0001564590-19-040490:notes:215]
19. SUBSEQUENT EVENTS

[0001564590-19-040490:notes:216]
On October 30, 2019, we announced that our Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to the Company’s stockholders of record as of the close of business on November 14, 2019. The payment date will be December 2, 2019 in the aggregate amount of approximately $4.3 million.
