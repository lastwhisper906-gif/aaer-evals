# ADTN MD&A — 0000950170-23-062173


## mdna

[0000950170-23-062173:mdna:1]
ITEM 2. MANAGEMENT'S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF                     OPERATIONS

[0000950170-23-062173:mdna:2]
The following discussion should be read in conjunction with the Condensed Consolidated Financial Statements and the related notes that appear in Part I, Item 1 of this document. In addition, the following discussion should be read in conjunction with our audited consolidated financial statements for the year ended December 31, 2022, Part II, Item 7, Management’s Discussion and Analysis of Financial Condition and Results of Operations, and Part I, Item 1A, Risk Factors, included in Amendment No. 1 to our Annual Report on Form 10-K for the year ended December 31, 2022, filed with the SEC on August 14, 2023 (the “2022 Form 10-K/A”), as well as Part I, Item 1, Business, included in our Annual Report on Form 10-K filed with the SEC on March 1, 2023.

[0000950170-23-062173:mdna:3]
[same as prior period, unchanged from 0000950170-23-042449:mdna:3]

[0000950170-23-062173:mdna:4]
Unless the context otherwise indicates or requires, references in this Quarterly Report on Form 10-Q to "ADTRAN", the “Company,” “we,” “us” and “our” refer to ADTRAN Holdings, Inc. and its consolidated subsidiaries for periods subsequent to the Merger and to ADTRAN, Inc. and its consolidated subsidiaries for periods prior to the Merger. The prior period results do not include the results of Adtran Networks prior to the Business Combination which occurred on July 15, 2022.

[0000950170-23-062173:mdna:5]
[same as prior period, unchanged from 0000950170-23-042449:mdna:5]

[0000950170-23-062173:mdna:6]
The Company is a leading global provider of networking and communications platforms, software, systems and services focused on the broadband access market, serving a diverse domestic and international customer base in multiple countries that includes Large, Medium and Small Service Providers, alternative Service Providers, such as utilities, municipalities and fiber overbuilders, cable/MSOs, SMBs and distributed enterprises. Our innovative solutions and services enable voice, data, video and internet-communications across a variety of network infrastructures and are currently in use by millions worldwide. We support our customers through our direct global sales organization and our distribution networks. Our success depends upon our ability to increase unit volume and market share through the introduction of new products and succeeding generations of products having optimal selling prices and increased functionality as compared to both the prior generation of a product and the products of competitors in order to gain market share. To service our customers and grow revenue, we are continually conducting research and developing new products addressing customer needs and testing those products for the specific requirements of the particular customers. We offer a broad portfolio of flexible software and hardware network solutions and services that enable Service Providers to meet today’s service demands while enabling them to transition to the fully converged, scalable, highly-automated, cloud-controlled voice, data, internet and video network of the future. In addition to our global headquarters in Huntsville, Alabama, and our European headquarters in Munich, Germany, we have sales and research and development facilities in strategic global locations.

[0000950170-23-062173:mdna:7]
ADTRAN Holdings, Inc. solely owns ADTRAN, Inc. and is the majority shareholder of Adtran Networks (formerly ADVA Optical Networking SE). ADTRAN is a leading global provider of open, disaggregated networking and communications solutions. Adtran Networks is a global provider of network solutions for data, storage, voice and video services. The combined technology portfolio can best address current and future requirements, especially regarding the convergence of solutions at the network edge.

[0000950170-23-062173:mdna:8]
[same as prior period, unchanged from 0000950170-23-042449:mdna:9]

[0000950170-23-062173:mdna:9]
[same as prior period, unchanged from 0000950170-23-042449:mdna:10]

[0000950170-23-062173:mdna:10]
[same as prior period, unchanged from 0000950170-23-042449:mdna:11]

[0000950170-23-062173:mdna:11]
[same as prior period, unchanged from 0000950170-23-042449:mdna:12]

[0000950170-23-062173:mdna:12]
[same as prior period, unchanged from 0000950170-23-042449:mdna:13]

[0000950170-23-062173:mdna:13]
[same as prior period, unchanged from 0000950170-23-042449:mdna:15]

[0000950170-23-062173:mdna:14]
[same as prior period, unchanged from 0000950170-23-042449:mdna:16]

[0000950170-23-062173:mdna:15]
[same as prior period, unchanged from 0000950170-23-042449:mdna:17]

[0000950170-23-062173:mdna:16]
Additionally, and subject to certain limitations pursuant to applicable law and the specific terms of the DPLTA, the DPLTA provides that Adtran Networks shareholders (other than us) be offered, at their election, (i) to put their Adtran Networks shares to the Company in exchange for compensation in cash of €17.21 per share plus guaranteed interest (the "Exit Compensation"), or (ii) to remain Adtran Networks shareholders and receive a recurring compensation in cash of €0.59 (€0.52 net under the current tax regime) per share for each full fiscal year of Adtran Networks (the “Annual Recurring Compensation”). The guaranteed interest component under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid. The guaranteed interest rate is 5.0% plus a variable component that was 3.12% as of September 30, 2023. The Annual Recurring Compensation is due on the third banking day following the ordinary general shareholders’ meeting of Adtran Networks for the respective preceding fiscal year (but in any event within eight months following expiration of the fiscal year) and is first granted for the 2023 fiscal year, payable for the first time after the ordinary general shareholders’ meeting of Adtran Networks in 2024. The adequacy of both forms of compensation has been challenged by minority shareholders of Adtran Networks via court-led appraisal proceedings under German law, and it is possible that the courts in such appraisal proceedings may adjudicate a higher Exit Compensation or Annual Recurring Compensation (in each case, including interest thereon) than agreed upon in the DPLTA.

[0000950170-23-062173:mdna:17]
The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that have been initiated in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger). For the three and nine months ended September 30, 2023, less than one thousand shares and 64 thousand shares, respectively, of Adtran Networks stock was tendered to the Company and Exit Compensation payments of approximately €8 thousand and €1.1 million, respectively, or approximately $9 thousand and $1.2 million, respectively, based on an exchange rate as of September 30, 2023, were paid to Adtran Networks' shareholders.

[0000950170-23-062173:mdna:18]
We currently hold 33,957,538 no-par value bearer shares of Adtran Networks, representing 65.36% of Adtran Networks outstanding shares as of September 30, 2023.

[0000950170-23-062173:mdna:19]
[same as prior period, unchanged from 0000950170-23-042449:mdna:21]

[0000950170-23-062173:mdna:20]
As of September 30, 2023, the Company has incurred $26.2 million of transaction costs related to the Business Combination. During the three and nine months ended September 30, 2023, $8 thousand and $0.1 million of transaction costs were incurred, respectively. During the three and nine months ended September 30, 2022, $10.6 million and $13.3 million of transaction costs were incurred, respectively. These transaction costs are recorded in selling, general and administrative expenses in the Consolidated Statements of Loss.

[0000950170-23-062173:mdna:21]
[same as prior period, unchanged from 0000950170-23-042449:mdna:23]

[0000950170-23-062173:mdna:22]
During the fourth quarter of 2022, the Company initiated a two-year integration program designed to optimize the assets, business processes, and information technology systems of the Company.

[0000950170-23-062173:mdna:23]
[same as prior period, unchanged from 0000950170-23-042449:mdna:25]

[0000950170-23-062173:mdna:24]
[same as prior period, unchanged from 0000950170-23-042449:mdna:26]

[0000950170-23-062173:mdna:25]
[same as prior period, unchanged from 0000950170-23-042449:mdna:27]

[0000950170-23-062173:mdna:26]
[same as prior period, unchanged from 0000950170-23-042449:mdna:28]

[0000950170-23-062173:mdna:27]
[same as prior period, unchanged from 0000950170-23-042449:mdna:29]

[0000950170-23-062173:mdna:28]
We have and will continue to invest significant dollars to restructure the workforce, optimize legacy systems, streamline legal entities and consolidate real estate holdings. By executing these integration activities, we expect to deliver greater innovation for customers, career enrichment opportunities for employees, and enhanced value for shareholders. During the three and nine months ended September 30, 2023, we recognized $1.7 million and $3.1 million of integration costs related to the Business Combination, respectively, that are included in selling, general and administrative expenses in the Condensed Consolidated Statement of Loss. We expect to incur additional integration costs and costs associated with the implementation of the DPLTA during the remainder of 2023 and into 2024 and such costs are expected to be material.

[0000950170-23-062173:mdna:29]
During the three and nine months ended September 30, 2023, we recognized $24.9 million and $33.2 million of restructuring costs relating to the Business Combination that are included in cost of revenue, selling, general and administrative expenses and research and development expenses in the Condensed Consolidated Statement of Loss, respectively. See Note 21 of the Notes to Condensed Consolidated Financial Statements, included in Part I, Item 1 of this report for additional information.

[0000950170-23-062173:mdna:30]
[same as prior period, unchanged from 0000950170-23-042449:mdna:33]

[0000950170-23-062173:mdna:31]
We ended the third quarter of 2023 with a year-over-year revenue decrease of 20.1% as compared to the three months ended September 30, 2022, driven by decreased volume of sales activity due to customers' focus on reducing inventory levels and due to the unfavorable impact on revenue generated outside of the U.S. as a result of the strengthened U.S. dollar. During the third quarter of 2023, we had one customer with revenues greater than 10.0% which was an international Service Provider customer and our five largest customers comprised 36.5% of our revenue. Our year-over-year domestic revenue decreased by 34.3%, driven by decreased volume of sales activity due to customer focus on reducing inventory levels. Internationally, our year-over-year revenue decreased by 6.0%, primarily driven by the unfavorable impact on revenue as a result of the strengthened U.S. dollar and decreased shipments to two Large network operators and one alternative network operator in Europe.

[0000950170-23-062173:mdna:32]
Growing customer concerns over inventory stocking levels affected our third quarter Subscriber Solutions category. We believe that this over-supply of CPE products will continue into the fourth quarter of 2023 and the first half of 2024. Revenue for our Optical Networking products was unfavorably impacted by strengthened U.S. dollar in the third quarter. Revenue for our Access products grew sequentially. We expect to see some improvement to the over-supply of CPE products in the coming quarters. Despite these challenges, we have maintained our emphasis on product development to enable us to respond to rapidly changing technology and evolving industry standards. For example, we expect public funding through projects such as IPCEI ME/CT to further our research and development for new communication technologies. Additionally, public funding through the Broadband Equity, Access and Deployment Program is expected to commence in late 2024 through 2026, which provides a positive outlook for the future.

[0000950170-23-062173:mdna:33]
Our operating results have fluctuated and may continue to fluctuate on a quarterly basis due to several factors, including customer order activity, supply chain constraints, component availability, and the Company's consolidation, purchase accounting, and integration with Adtran Networks. Further, a significant percentage of orders require delivery within a few-days requiring us to maintain higher inventory levels. These factors may result in limited order flow visibility. For example, during the recent pandemic and a global semiconductor chip shortage, we experienced disruption and delays in our supply chain and significant price increases with certain of our manufacturing partners. Although, expedite fees and lead times for semiconductor chips and other key components began to ease during the first three quarters of 2023, we continued to be negatively impacted by price increases, which could continue to have a material adverse effect on customer relations and our financial condition. We have taken decisive steps to transform our business into a leaner, more efficient and more profitable company, including through the implementation of a comprehensive business efficiency program, which includes a significant cost efficiency program targeting a reduction of ongoing operating expenses, a capital efficiency program that includes a site consolidation plan that management expects to generate proceeds through the partial sale of owned real estate (including the potential sale of our headquarters),  and the suspension of the quarterly dividend. Nevertheless, our operating expenses are relatively fixed in the short term; therefore, a shortfall in quarterly revenues has and may again in the future significantly impact our financial results in a given quarter.

[0000950170-23-062173:mdna:34]
The coronavirus ("COVID-19") pandemic and related countermeasures previously impacted our operations. Notwithstanding improvement in many markets in which we operate due to a return to more normalized business operations, certain markets may in the future be adversely impacted by pandemic or endemic diseases including COVID-19 or as a result of policies relating to such diseases.

[0000950170-23-062173:mdna:35]
Our operating results have significantly fluctuated and may do so in the future as a result of a number of other factors, including a decline in general economic and market conditions, foreign currency exchange rate movements, inflation, regional conflicts, increased competition, customer order patterns, changes in product and services mix, timing differences between price decreases and product cost

[0000950170-23-062173:mdna:36]
reductions, product warranty returns, expediting costs, tariffs and announcements of new products by us or our competitors. In recent years, inflationary pressures on input costs, such as raw materials and labor, and distribution costs  had a negative impact on our operating results. However, inflationary pressures on our supply chain have eased somewhat, which has led to reductions in cost premiums on raw material costs and freight. We continue to support our customer demand for our products by working with our suppliers, contract manufacturers, distributors, and customers to address and to limit the disruption to our operations and order fulfillment. Additionally, maintaining sufficient inventory levels to assure prompt delivery of our products increases the amount of inventory that may become obsolete and increases the risk that the obsolescence of this inventory may have an adverse effect on our business and operating results. Also, not maintaining sufficient inventory levels to ensure prompt delivery of our products may cause us to incur expediting costs to meet customer delivery requirements, which may negatively impact our operating results.

[0000950170-23-062173:mdna:37]
We are exposed to changes in foreign currencies relative to the U.S. dollar, which are references to the differences between the foreign-exchanges rates we use to convert the financial results of our international operations from local currencies into U.S. dollars for financial reporting purposes. This impact of foreign-exchange rate changes is calculated based on the difference between the current period’s currency exchange rates and that of the comparable prior period. Our primary exposures to foreign currency exchange rate movements are with the Euro and the British pound sterling. As a result of our global operations, our revenue, gross margins, operating expense and operating loss in some international markets have been and may continue to be affected by foreign currency fluctuations.

[0000950170-23-062173:mdna:38]
The Company’s policy is to assess the realizability of its goodwill, and to evaluate such assets for impairment whenever events or changes in circumstances indicate that the carrying amount of such assets (or group of assets) may not be recoverable. During the third quarter of 2023, qualitative factors, such as a decrease in the Company's market capitalization and changes in the Company's long-term projections, triggered a quantitative impairment assessment for our reporting units. The Company determined the fair value of each of its reporting units using a combination of an income approach and a market based peer group analysis. It was determined that decreases in projected future cash flows, discount rates, overall macroeconomic conditions, as well as decreases in our market capitalization applied in the valuation, were required to align with market-based assumptions and company-specific risk, which resulted in lower fair values of the Services & Support reporting unit. The Company determined upon its quantitative impairment assessment to recognize a $37.9 million non-cash goodwill impairment charge for the Services & Support reporting unit. The Company does not expect the impairment charge for the Services & Support Unit to result in any future cash expenditures. The Company did not recognize any impairment charges for the Network Solutions reporting unit as of September 30, 2023.

[0000950170-23-062173:mdna:39]
[same as prior period, unchanged from 0000950170-23-042449:mdna:41]

[0000950170-23-062173:mdna:40]
[same as prior period, unchanged from 0000950170-23-042449:mdna:42]

[0000950170-23-062173:mdna:41]
[same as prior period, unchanged from 0000950170-23-042449:mdna:43]

[0000950170-23-062173:mdna:42]
48

[0000950170-23-062173:mdna:43]
RESULTS OF OPERATIONS – THREE AND NINE MONTHS ENDED SEPTEMBER 30, 2023 COMPARED TO THE THREE AND NINE MONTHS ENDED SEPTEMBER 30, 2022

[0000950170-23-062173:mdna:44]
The following table presents selected financial information derived from our Condensed Consolidated Statements of Loss expressed as a percentage of revenue for the periods indicated. Amounts may not foot due to rounding.

[0000950170-23-062173:mdna:45]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |  |
|  |  | September 30, |  |  | September 30, |  |  |
|  |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |  |
| Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Network Solutions |  |  | 83.9 |  | % |  | 89.5 |  | % |  | 86.0 |  | % |  | 89.8 |  | % |
| Services & Support |  |  | 16.1 |  |  |  | 10.5 |  |  |  | 14.0 |  |  |  | 10.2 |  |  |
| Total Revenue |  |  | 100.0 |  |  |  | 100.0 |  |  |  | 100.0 |  |  |  | 100.0 |  |  |
| Cost of Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Network Solutions |  |  | 58.8 |  |  |  | 65.3 |  |  |  | 64.6 |  |  |  | 61.9 |  |  |
| Network Solutions - Inventory Write Down |  |  | 7.7 |  |  |  | — |  |  |  | 2.3 |  |  |  | — |  |  |
| Services & Support |  |  | 6.2 |  |  |  | 4.4 |  |  |  | 5.6 |  |  |  | 5.1 |  |  |
| Total Cost of Revenue |  |  | 72.7 |  |  |  | 69.8 |  |  |  | 72.4 |  |  |  | 67.1 |  |  |
| Gross Profit |  |  | 27.3 |  |  |  | 30.2 |  |  |  | 27.6 |  |  |  | 32.9 |  |  |
| Selling, general and administrative expenses |  |  | 23.1 |  |  |  | 22.0 |  |  |  | 21.3 |  |  |  | 19.6 |  |  |
| Research and development expenses |  |  | 23.0 |  |  |  | 17.4 |  |  |  | 22.0 |  |  |  | 16.8 |  |  |
| Asset impairment |  |  | — |  |  |  | 5.0 |  |  |  | — |  |  |  | 2.5 |  |  |
| Goodwill impairment |  |  | 13.9 |  |  |  | — |  |  |  | 4.1 |  |  |  | — |  |  |
| Operating Loss |  |  | (32.8 | ) |  |  | (14.1 | ) |  |  | (19.9 | ) |  |  | (6.0 | ) |  |
| Interest and dividend income |  |  | 0.2 |  |  |  | 0.1 |  |  |  | 0.1 |  |  |  | 0.1 |  |  |
| Interest expense |  |  | (1.7 | ) |  |  | (0.4 | ) |  |  | (1.3 | ) |  |  | (0.2 | ) |  |
| Net investment (loss) gain |  |  | (0.5 | ) |  |  | (0.8 | ) |  |  | 0.1 |  |  |  | (1.6 | ) |  |
| Other income, net |  |  | 0.9 |  |  |  | 0.7 |  |  |  | 0.5 |  |  |  | 0.4 |  |  |
| Loss Before Income Taxes |  |  | (33.9 | ) |  |  | (14.4 | ) |  |  | (20.4 | ) |  |  | (7.3 | ) |  |
| Income tax benefit |  |  | 6.1 |  |  |  | 1.3 |  |  |  | 3.9 |  |  |  | 0.7 |  |  |
| Net Loss |  |  | (27.8 | ) | % |  | (13.2 | ) | % |  | (16.5 | ) | % |  | (6.6 | ) | % |
| Less: Net Loss attributable to non-controlling interest |  |  | (1.1 | ) |  |  | — |  |  |  | (1.3 | ) |  |  | — |  |  |
| Net Loss attributable to ADTRAN Holdings, Inc. |  |  | (26.7 | ) | % |  | (12.3 | ) | % |  | (15.2 | ) | % |  | (6.1 | ) | % |

[0000950170-23-062173:mdna:46]
[same as prior period, unchanged from 0000950170-23-042449:mdna:48]

[0000950170-23-062173:mdna:47]
Our revenue decreased 20.1% from $340.7 million for the three months ended September 30, 2022 to $272.3 million for the three months ended September 30, 2023 and increased 38.4% from $667.3 million for the nine months ended September 30, 2022 to $923.6 million for the nine months ended September 30, 2023. The decrease in revenue for the three months ended September 30, 2023 is primarily driven by a $63.0 million decrease in volume of sales activity related to our ADTRAN, Inc. operations due to customers’ focus on reducing inventory levels and $5.4 million decrease due to the unfavorable impact on revenue generated outside of the U.S. as a result of the strengthened U.S. dollar. The increase in revenue for the nine months ended September 30, 2023 is primarily attributable to a $379.0 million increase in volume of sales activity due to the Business Combination with Adtran Networks during the first half of 2023 partially offset by a $117.3 million decrease in volume of sales activity due to customers’ focus on reducing inventory levels in our domestic ADTRAN, Inc. operations. The decrease in revenue by category for the three months ended September 30, 2023 was primarily attributable to a $72.2 million decrease in Subscriber Solutions products, and a $2.6 million decrease in Optical Networking Solutions products partially offset by a $6.5 million increase in Access & Aggregation revenue. The increase in revenue by category for the nine months ended September 30, 2023 was primarily attributable to a $288.1 million increase in Optical Networking Solutions products and a $15.9 million increase in Access and Aggregation revenue partially offset by a $47.7 million decrease in Subscriber Solutions products. Growing customer concerns over inventory stocking levels have affected our revenue in the first three quarters in our Subscriber Solutions category. We believe that this over-supply of CPE products will continue into the fourth quarter of 2023 and into the first half of 2024. Revenue for our Access and Optical Networking products grew sequentially. We do not see any material changes to our near-term opportunities and our long-term growth catalysts as carriers around the world upgrade their networks to fiber.

[0000950170-23-062173:mdna:48]
Network Solutions segment revenue decreased 25.0% from $304.9 million for the three months ended September 30, 2022 to $228.6 million for the three months ended September 30, 2023 and increased 32.5% from $599.3 million for the nine months ended September 30, 2022 to $794.0 million for the nine months ended September 30, 2023. The decrease in Network Solutions revenue for the three months ended September 30, 2023 was due to the decrease of $72.4 million in volume of sales activity in Subscriber Solutions products primarily in our ADTRAN, Inc. operations and a decrease of $8.4 million in Optical Networking products partially offset by an increase of $4.5 million in volume of sales activity in Access & Aggregation revenue. The increase in revenue for the nine months

[0000950170-23-062173:mdna:49]
ended September 30, 2023 was due to an increase of $326.9 million in volume of sales activity due to the Business Combination with Adtran Networks during the first half of 2023 partially offset by a decrease of $114.8 million in Subscriber Solutions products, a decrease of $8.9 million in Access & Aggregation Solutions and a decrease of $8.4 million in Optical Networking products. More specifically, the decrease in revenue for the three and nine months ended September 30, 2023 of our Subscriber Solutions products was primarily due to lower volume of sales of our residential solutions products as a result of customers focus on reducing inventory levels.

[0000950170-23-062173:mdna:50]
Services & Support segment revenue increased 22.4% from $35.8 million for the three months ended September 30, 2022 to $43.8 million for the three months ended September 30, 2023 and increased 90.8% from $68.0 million for the nine months ended September 30, 2022 to $129.6 million for the nine months ended September 30, 2023. The increase in revenue for the three months ended September 30, 2023 was primarily attributable a $5.8 million increase in revenue for Optical Networking products a $2.0 million increase in revenue for Access & Aggregation revenue and a $0.2 million increase in revenue for Subscriber Solutions services. The increase in revenue for the nine months ended September 30, 2023 was primarily attributable to the increase of $52.2 million in volume of sales activity from the Business Combination with Adtran Networks a $5.8 million increase in revenue for Optical Networking products a $2.0 million increase in revenue for Access & Aggregation revenue and a $1.8 million increase in revenue for Subscriber Solutions services. More specifically, the increase in revenue for the three and nine months ended September 30, 2023 of our ADTRAN, Inc. operations was primarily due to higher volume of sales of our software services and business solutions services.

[0000950170-23-062173:mdna:51]
Domestic revenue decreased by 34.3% from $169.7 million for the three months ended September 30, 2022 to $111.5 million for the three months ended September 30, 2023 and increased by 0.2% from $374.5 million for the nine months ended September 30, 2022 to $375.3 million for the nine months ended September 30, 2023. The decrease in domestic revenue for the three months ended September 30, 2023 was primarily due to lower volume of sales of our residential solutions products as a result of customers focus on reducing inventory levels in our Subscriber Solutions segment. The increase in domestic revenue for the nine months ended September 30, 2023 was primarily due to an increase in volume of sales activity from the Business Combination with Adtran Networks in the first half of 2023 partially offset by lower volume of sales of our residential solutions products as a result of customers focus on reducing inventory levels in our Subscriber Solutions segment.

[0000950170-23-062173:mdna:52]
International revenue, which is defined as revenue generated from the Network Solutions and Services & Support segments provided to a customer outside of the U.S., decreased by 6.0% from $171.0 million for the three months ended September 30, 2022 to $160.8 million for the three months ended September 30, 2023 and increased by 87.3% from $292.8 million for the nine months ended September 30, 2022 to $548.4 million for the nine months ended September 30, 2023. International revenue, as a percentage of total revenue, increased from 50.2% for the three months ended September 30, 2022 to 59.1% for the three months ended September 30, 2023 and increased from 43.9% for the nine months ended September 30, 2022 to 59.4% for the nine months ended September 30, 2023. The decrease in international revenue for the three months ended September 30, 2023 was primarily due to the unfavorable impact on revenue generated outside of the U.S. as a result of the strengthened U.S. dollar. The change for the nine months ended September 30, 2023 was primarily attributable to an increase in volume of sales activity from the Business Combination with Adtran Networks in the first half of 2023 and increased shipments partially offset by the unfavorable impact on revenue generated outside of the U.S. as a result of the strengthened U.S. dollar. While international revenue has increased to approximately 59.1% and 59.4% of total revenues for the three and nine months ended September 30, 2023, the mix of our Network Solutions and Services & Support segments as a percentage of total international revenue remains relatively linear. For the three and nine months ended September 30, 2023 as compared to the three and nine months ended September 30, 2022, changes in foreign currencies relative to the U.S. dollar increased our net revenue by approximately $11.1 million and increased our net revenue by approximately $3.6 million, respectively.

[0000950170-23-062173:mdna:53]
Our ADTRAN, Inc. international revenue is largely focused on broadband infrastructure and is consequently affected by the decisions of our customers as to timing for installation of new technologies, expansion of their networks and/or network upgrades. Our international customers must make these decisions in the regulatory and political environment in which they operate – both nationally and, in some instances, regionally – whether of a multi-country region or a more local region within a country. Consequently, while we expect the global trend towards deployment of more robust broadband speeds and access to continue creating additional market opportunities for us, the factors described above have resulted in and may continue to result in pressure on revenue and operating income. Our Adtran Networks international revenue is largely focused on the manufacture and selling of networking solutions that are based on three core areas of expertise: fiber-optic transmission technology (cloud interconnect), cloud access technology for rapid creation of innovative services around the network edge and solutions for precise timing and synchronization of networks. In addition, Adtran

[0000950170-23-062173:mdna:54]
50

[0000950170-23-062173:mdna:55]
Networks international operations offers a comprehensive portfolio of network design, implementation and maintenance services to assist operators in the deployment of market-leading networks while reducing costs to maintain these networks.

[0000950170-23-062173:mdna:56]
[same as prior period, unchanged from 0000950170-23-042449:mdna:56]

[0000950170-23-062173:mdna:57]
As a percentage of revenue, cost of revenue increased from 69.8% for the three months ended September 30, 2022 to 72.7% for the three months ended September 30, 2023 and increased from 67.1% for the nine months ended September 30, 2022 to 72.4% for the nine months ended September 30, 2023. The increase for the three and nine months ended September 30, 2023 was primarily attributable to $13.5 million and $79.6 million, respectively, of adjustments consisting of intangible amortization of backlog, developed technology and fair value adjustments to inventory costs that flow through to cost of revenue as a result of the Business Combination with Adtran Networks, acquisition related expenses, a $21.0 million write down of inventory due to a restructuring discontinuation of certain product lines within our Network Solutions segment, and to a lesser extent changes in customer and product mix and a regional revenue shift in our ADTRAN, Inc. operations partially offset by supply chain cost improvements. As the inventory that was acquired in the Business Combination with Adtran Networks is sold, our cost of revenue as a percentage of revenue will return to more normalized levels. For the three and nine months ended September 30, 2023 as compared to the three and nine months ended September 30, 2022, changes in foreign currencies relative to the U.S. dollar increased our cost of revenue by approximately $1.8 million and increased our cost of revenue by approximately $0.1 million, respectively. See additional information related to amortization lives and expense in Notes 2 and 10 of Notes to the Condensed Consolidated Financial Statements included in Part I, Item 1 of this report.

[0000950170-23-062173:mdna:58]
Network Solutions cost of revenue including the inventory write down, as a percentage of that segment’s revenue, increased from 73.0% for the three months ended September 30, 2022 to 79.3% for the three months ended September 30, 2023 and increased from 68.9% for the nine months ended September 30, 2022 to 77.8% for the nine months ended September 30, 2023. The increase in cost of revenue as a percentage of revenue for the three and nine months ended September 30, 2023 was primarily attributable to acquisition related expenses, amortizations and adjustments consisting of intangible amortization of backlog, developed technology and fair value adjustments to inventory costs that flow through to cost of revenue as a result of the Business Combination with Adtran Networks, a write down of inventory due to a restructuring discontinuation of certain product lines and to a lesser extent changes in customer and product mix and a regional revenue shift in our ADTRAN, Inc. operations partially offset by supply chain cost improvements.

[0000950170-23-062173:mdna:59]
Services & Support cost of revenue, as a percentage of that segment’s revenue, decreased from 42.1% for the three months ended September 30, 2022 to 38.4% for the three months ended September 30, 2023 and decreased from 50.4% for the nine months ended September 30, 2022 to 39.8% for the nine months ended September 30, 2023. The decrease in cost of revenue as a percentage of revenue for the three and nine months ended September 30, 2023 was primarily attributable to customer mix and changes in Services & Support mix as a result of the Business Combination with Adtran Networks.

[0000950170-23-062173:mdna:60]
[same as prior period, unchanged from 0000950170-23-042449:mdna:60]

[0000950170-23-062173:mdna:61]
[same as prior period, unchanged from 0000950170-23-042449:mdna:61]

[0000950170-23-062173:mdna:62]
As a percentage of revenue, gross profit decreased from 30.2% for the three months ended September 30, 2022 to 27.3% for the three months ended September 30, 2023 and decreased from 32.9% for the nine months ended September 30, 2022 to 27.6% for the nine months ended September 30, 2023. The decrease for the three months ended September 30, 2023 was primarily attributable to $13.5 million and $79.6 million, respectively, of adjustments consisting of intangible amortization of backlog, developed technology and fair value adjustments to inventory costs that flow through to cost of revenue as a result of the Business Combination with Adtran Networks, acquisition related expenses, a decrease in volume of sales activity due to customers focus on reducing inventory levels in our domestic ADTRAN, Inc. operations a decrease due to the unfavorable impact on revenue generated outside of the U.S. as a result of the strengthened U.S. dollar and a write down of inventory due to a restructuring discontinuation of certain product lines.

[0000950170-23-062173:mdna:63]
As a percentage of that segment's revenue, Network Solutions gross profit decreased from 27.0% for the three months ended September 30, 2022 to 20.7% for the three months ended September 30, 2023 and decreased from 31.1% for the nine months ended September 30, 2022 to 22.2% for the nine months ended September 30, 2023. The decrease was primarily attributable to increases in cost of revenue related to acquisition related expenses, adjustments consisting of intangible amortization of backlog, developed technology and fair value adjustments to inventory costs that flow through to cost of revenue as a result of the Business Combination with Adtran Networks and a decrease in volume of sales activity related to our ADTRAN, Inc. operations, a decrease in volume of sales activity due to customers focus on reducing inventory levels in our domestic ADTRAN, Inc. operations a decrease due to the unfavorable impact on revenue generated outside of the U.S. as a result of the strengthened U.S. dollar and a write down of inventory due to a restructuring discontinuation of certain product lines partially offset by an increase in volume of sales activity in the first half of 2023 due to the Business Combination with Adtran Networks.

[0000950170-23-062173:mdna:64]
As a percentage of that segment's revenue, Services & Support gross profit increased from 57.9% for the three months ended September 30, 2022 to 61.6% for the three months ended September 30, 2023 and increased from 49.6% for the nine months ended September 30, 2022 to 60.2% for the nine months ended September 30, 2023. The increase was primarily attributable to an increase in volume of sales activity in the first half of 2023 due to the Business Combination with Adtran Networks and a decrease in cost of revenue as a percentage of revenue attributable to customer mix and changes in Services & Support mix as a result of the Business Combination with Adtran Networks.

[0000950170-23-062173:mdna:65]
[same as prior period, unchanged from 0000950170-23-042449:mdna:65]

[0000950170-23-062173:mdna:66]
As a percentage of revenue, selling, general and administrative expenses increased from 22.0% for the three months ended September 30, 2022 to 23.1% for the three months ended September 30, 2023 and increased from 19.6% for the nine months ended September 30, 2022 to 21.3% for the nine months ended September 30, 2023. While selling, general and administrative expenses as a percentage of revenue will generally fluctuate whenever there is a significant fluctuation in revenue for the periods being compared, in the three and nine months ended September 30, 2023 we saw a more significant increase due to higher expenses related to the Business Combination with Adtran Networks and other items described below. Our restructuring and integration programs are in the process of consolidating, streamlining and integrating the workforce, systems and processes of ADTRAN and Adtran Networks, which we expect will lower selling, general and administrative expense as a percentage of revenue over time.

[0000950170-23-062173:mdna:67]
Selling, general and administrative expenses decreased 16.0% from $74.9 million for the three months ended September 30, 2022 to $62.9 million for the three months ended September 30, 2023 and increased 50.7% from $130.6 million for the nine months ended September 30, 2022 to $196.9 million for the nine months ended September 30, 2023. Selling, general and administrative expenses include personnel costs for management, accounting, information technology, human resources, sales and marketing, as well as independent auditor, tax and other professional fees, contract services and legal and litigation related costs. The decrease in selling, general and administrative expenses for the three months ended September 30, 2023 was primarily attributable to decreased expenses for employee-related costs, depreciation of property, plant and equipment, and stock-based compensation expense partially offset by increased costs related to our restructuring program and amortization of intangible assets. The increase in selling, general and administrative expenses for the nine months ended September 30, 2023 was primarily attributable to increased expenses in the first half of 2023 related to the Business Combination with Adtran Networks such as employee-related costs due to an increase in the number of employees, costs related to our restructuring program, amortization of intangible assets, depreciation of property, plant and equipment, restructuring expenses and transactions costs partially offset by decreased stock-based compensation expense. For the three and nine months ended September 30, 2023 as compared to the three and nine months ended September 30, 2022, changes in foreign currencies relative to the U.S dollar increased our selling, general and administrative expenses by approximately $1.5 million and increased our selling, general and administrative expenses by approximately $0.2 million, respectively.

[0000950170-23-062173:mdna:68]
[same as prior period, unchanged from 0000950170-23-042449:mdna:68]

[0000950170-23-062173:mdna:69]
As a percentage of revenue, research and development expenses increased from 17.4% for the three months ended September 30, 2022 to 23.0% for the three months ended September 30, 2023 and increased from 16.8% for the nine months ended September 30, 2022 to 22.0% for the nine months ended September 30, 2023. Although, research and development expenses as a percentage of revenue will fluctuate whenever there are incremental product development activities or significant fluctuations in revenue for the periods being compared, in the first half of 2023 we saw a more significant increase due to increased expenses related to the Business Combination with Adtran Networks and other items described below. Our restructuring and integration programs are in the process of consolidating, streamlining and integrating the workforce, systems and processes of ADTRAN and Adtran Networks, which we expect will lower research and development expense as a percentage of revenue over time.

[0000950170-23-062173:mdna:70]
Research and development expenses increased 6.0% from $59.2 million for the three months ended September 30, 2022 to $62.8 million for the three months ended September 30, 2023 and increased 81.4% from $112.2 million for the nine months ended September 30, 2022 to $203.5 million for the nine months ended September 30, 2023. The increase in research and development expenses was primarily attributable to increased expenses in the first half of 2023 related to the Business Combination with Adtran Networks such as employee-related costs due to an increase in the number of employees, restructuring expenses and depreciation of property, plant and equipment. For the three and nine months ended September 30, 2023 as compared to the three and nine months ended September 30, 2022, changes in foreign currencies relative to the U.S. dollar increased our research and development expenses by approximately $1.2 million and decreased our research and development expenses by approximately $0.90 million, respectively.

[0000950170-23-062173:mdna:71]
Adtran Networks has arrangements with governmental entities for the purpose of obtaining funding for research and development activities. The Company classifies government grants received under these arrangements as a reduction to research and development expense incurred. For the three and nine months ended September 30, 2023, the Company recognized $0.8 million and $2.3 million as a reduction of research and development expense, respectively.

[0000950170-23-062173:mdna:72]
[same as prior period, unchanged from 0000950170-23-042449:mdna:72]

[0000950170-23-062173:mdna:73]
GOODWILL IMPAIRMENT

[0000950170-23-062173:mdna:74]
The Company’s policy is to assess the realizability of its goodwill, and to evaluate such assets for impairment whenever events or changes in circumstances indicate that the carrying amount of such assets (or group of assets) may not be recoverable. During the third quarter of 2023, qualitative factors, such as a decrease in the Company's market capitalization and long-term projections, triggered a quantitative impairment assessment for our reporting units. The Company determined the fair value of each of its reporting units using a combination of an income approach and a market based peer group analysis. It was determined that the decreases in projected future cash flows, discount rates, overall macroeconomic conditions, as well as the decrease in our market capitalization applied in the valuation were required to align with market-based assumptions and company-specific risk, which resulted in lower fair values of the Services & Support reporting unit. The Company determined upon its quantitative impairment assessment to recognize a $37.9 million non-cash goodwill impairment charge for the Services & Support reporting unit. The Company does not expect the impairment charge for the Services & Support Unit to result in any future cash expenditures. The Company did not recognize any impairment charges for the Network Solutions reporting unit as of September 30, 2023. Furthermore, no impairment of goodwill was recorded for either reporting unit as of September 30, 2022.

[0000950170-23-062173:mdna:75]
ASSET IMPAIRMENT

[0000950170-23-062173:mdna:76]
In connection with the planned integration of information technology following the Business Combination, we determined that certain projects no longer fit our needs. As a result the Company recognized impairment charges of $17.0 million during the three and nine months ended September 30, 2022 related to capitalized implementation costs for a cloud computing arrangement. There were no asset impairments recognized during the three and nine months ended September 30, 2023. See Note 8 of Notes to the Condensed Consolidated Financial Statements included in Part I, Item 1 of this report for additional information.

[0000950170-23-062173:mdna:77]
[same as prior period, unchanged from 0000950170-23-042449:mdna:73]

[0000950170-23-062173:mdna:78]
Interest and dividend income increased from $0.3 million for the three months ended September 30, 2022 to $0.5 million for the three months ended September 30, 2023 and increased from $0.8 million for the nine months ended September 30, 2022 to $1.2 million for the nine months ended September 30, 2023. Interest and dividend income was up due to increased income related to the Business Combination with Adtran Networks in the first half of 2023 and increased dividend income from the deferred compensation plan.

[0000950170-23-062173:mdna:79]
[same as prior period, unchanged from 0000950170-23-042449:mdna:75]

[0000950170-23-062173:mdna:80]
Interest expense increased from $1.3 million for the three months ended September 30, 2022 to $4.5 million for the three months ended September 30, 2023 and increased from $1.4 million for the nine months ended September 30, 2022 to $11.9 million for the nine months ended September 30, 2023. The increase in interest expense during the three and nine months ended September 30, 2023 was primarily related to an increase in the Wells Fargo Credit Agreement and the assumed debt associated with the Business Combination with Adtran Networks. See Note 12 and Note 13 of the Notes to Condensed Consolidated Financial Statements, included in Part I, Item 1 of this report.

[0000950170-23-062173:mdna:81]
[same as prior period, unchanged from 0000950170-23-042449:mdna:77]

[0000950170-23-062173:mdna:82]
We recognized a net investment loss of $2.7 million and $1.4 million for the three months ended September 30, 2022 and 2023, respectively and recognized a net investment loss of $10.8 million compared to a gain of $1.1 million for the nine months ended September 30, 2022 and 2023, respectively. The fluctuations in our net investments were primarily attributable to changes in the fair value of our securities recognized during the period. We expect that any future market volatility could result in continued fluctuations in our investment portfolio. See Note 6 of the Notes to Condensed Consolidated Financial Statements, included in Part I, Item 1 of this report, and “Investing Activities” in “Liquidity and Capital Resources” below for additional information.

[0000950170-23-062173:mdna:83]
[same as prior period, unchanged from 0000950170-23-042449:mdna:79]

[0000950170-23-062173:mdna:84]
Other expense, net, which primarily consisted of gains and losses on foreign currency transactions and income from excess material sales, was flat with income of $2.5 million for the three months ended September 30, 2022 and 2023 and increased from $2.9 million for the nine months ended September 30, 2022 compared to $4.7 million for the nine months ended September 30, 2023.

[0000950170-23-062173:mdna:85]
INCOME TAX BENEFIT

[0000950170-23-062173:mdna:86]
The Company's effective tax rate changed from a benefit of 8.8% of pre-tax loss for the three months ended September 30, 2022, to a benefit of 18.0% of pre-tax loss for the three months ended September 30, 2023 and changed from a benefit of 9.4% of pre-tax loss for the nine months ended September 30, 2022, to a benefit of 19.2% of pre-tax loss for the nine months ended September 30, 2023. In 2022, we benefited from a change in our annual estimated tax rate as a result of the requirement to begin capitalizing research and development expenses for U.S. tax purposes beginning in 2022 as previously passed as part of the Tax Cuts and Jobs Act in December 2017, and the associated impact of those changes on our previously established valuation allowance. The change in the effective tax rate for the three and nine months ended September 30, 2023, was driven primarily by a change in our estimated tax rate as a result of the closing of the Business Combination with Adtran Networks during the third quarter of 2022, as well as the release of our domestic

[0000950170-23-062173:mdna:87]
valuation allowance during the fourth quarter of 2022, with exception for certain research and development credits in a particular State in which we do not have sufficient activity to utilize them prior to expiration.

[0000950170-23-062173:mdna:88]
NET LOSS ATTRIBUTABLE TO ADTRAN HOLDINGS, INC.

[0000950170-23-062173:mdna:89]
As a result of the above factors, net loss attributable to ADTRAN Holdings, Inc. increased from net loss of $41.9 million for the three months ended September 30, 2022 to a net loss of $72.7 million for the three months ended September 30, 2023 and increased from net loss of $40.9 million for the nine months ended September 30, 2022 to a net loss of $140.5 million for the nine months ended September 30, 2023. Upon the DPLTA becoming effective on January 16, 2023, the Company began absorbing all Adtran Networks losses rather than just the loss related to the Company's ownership percentage in Adtran Networks.

[0000950170-23-062173:mdna:90]
[same as prior period, unchanged from 0000950170-23-042449:mdna:85]

[0000950170-23-062173:mdna:91]
We have historically financed our ongoing business with existing cash, investments and cash flow from operations. In the current environment we have begun to and expect to continue to utilize our credit arrangements to manage our working capital needs. We have used, and expect to continue to use, existing cash, investments, credit arrangements and cash generated from operations for working capital, business acquisitions, shareholder dividends and other general corporate purposes, including product development activities to enhance our existing products and develop new products, expand our sales and marketing activities and fund capital expenditures.

[0000950170-23-062173:mdna:92]
Pursuant to the terms of the DPLTA, each Adtran Networks shareholder (other than the Company) has received an offer to elect either (1) to remain an Adtran Networks shareholder and receive from us an Annual Recurring Compensation payment, or (2) to receive Exit Compensation plus guaranteed interest. The guaranteed interest under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid. The guaranteed interest rate is 5.0% plus a variable component (according to the German Civil Code) that was 3.12% as of September 30, 2023. Assuming all the minority holders of currently outstanding Adtran Networks shares were to elect the second option, we would be obligated to make aggregate Exit Compensation payments, including guaranteed interest, of approximately €325.3 million or approximately $344.2 million, based on an exchange rate as of September 30, 2023 and reflecting interest accrued through September 30, 2023 during the pendency of the appraisal proceedings discussed below. Shareholders electing the first option of Annual Recurring Compensation may later elect the second option. The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that have been initiated in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger).

[0000950170-23-062173:mdna:93]
We are also obligated to absorb any annual net loss of Adtran Networks under the DPLTA. Additionally, our obligation to pay Annual Recurring Compensation under the DPLTA is a continuing payment obligation, which will amount to approximately €10.6 million or $11.2 million (based on the current exchange rate) per year assuming none of the minority Adtran Networks shareholders were to elect Exit Compensation. The foregoing amounts do not reflect any potential increase in payment obligations that we may have depending on the outcome of ongoing appraisal proceedings in Germany. During the three and nine months ended September 30, 2023, we accrued $2.9 million and $8.6 million in Annual Recurring Compensation, which was reflected as a reduction to retained (deficit) earnings, respectively. For the three and nine months ended September 30, 2023, less than 1 thousand shares and 64 thousand shares, respectively, of Adtran Networks stock was tendered to the Company and Exit Compensation payments of approximately €8 thousand and €1.1 million, respectively, or approximately $9 thousand and $1.2 million, respectively, based on an exchange rate as of September 30, 2023, were paid to Adtran Networks shareholders.

[0000950170-23-062173:mdna:94]
As of September 30, 2023, the Company does not have sufficient liquidity to meet payment obligations under the DPLTA pertaining to Exit Compensation assuming a substantial majority of Adtran Networks shareholders elect such option in the current period. We believe the probability that a substantial majority of Adtran Networks shareholders elect to receive Exit Compensation in the next twelve months is remote based on the diverse base of shareholders that must make this election on an individual shareholder basis, the current ongoing appraisal proceedings involving a dispute on the value of the Exit Compensation which is expected to take 24-36 months to resolve, the current guaranteed Annual Recurring Compensation payment plus the interest earned on such shares during the ongoing appraisal proceedings, and the current trading value of Adtran Networks SE shares.

[0000950170-23-062173:mdna:95]
Therefore, we believe that our cash and cash equivalents, investments, working capital management initiatives and access to funds under the Wells Fargo credit facility, including additional funding provided for under the First Amendment to the Wells Fargo credit facility that was signed on August 9, 2023, (described below) will be adequate to meet our operating and capital needs and our obligations under the DPLTA, including potential Exit Compensation, for at least the next 12 months, from the issuance of these financial statements, although we have suspended dividend payments and are implementing a business efficiency program, which includes, but is not limited to, planned reductions in our operating expenses and a site consolidation plan. In connection with the site consolidation plan, we are also exploring a potential sale of our headquarters in Huntsville. We may also need to further reduce capital expenditures and/or take other steps to preserve working capital in order to ensure that we can meet such needs and obligations.

[0000950170-23-062173:mdna:96]
[same as prior period, unchanged from 0000950170-23-042449:mdna:91]

[0000950170-23-062173:mdna:97]
On July 18, 2022, ADTRAN Holdings, Inc. and ADTRAN, Inc., as the borrower, entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (the “Credit Agreement”). The Credit Agreement initially allowed for borrowings of up to $100.0 million in aggregate principal amount, but the permitted borrowings increased to up to $400.0 million in aggregate principal amount upon the DPLTA becoming effective on January 16, 2023.

[0000950170-23-062173:mdna:98]
On August 9, 2023, (the "First Amendment Effective Date") the Company, its wholly-owned direct subsidiary, ADTRAN, Inc., the lenders party thereto and the Administrative Agent entered into a First Amendment to the Credit Agreement (the “First Amendment” and together with the Credit Agreement, the "Credit Facility").

[0000950170-23-062173:mdna:99]
The First Amendment, provides for, among other things, a new $50.0 million delayed draw term loan (“DDTL”), which is available for borrowing in the event of the purchase by the Company of at least sixty percent (60.0%) of the outstanding shares of Adtran Networks that were not owned by the Company as of the First Amendment Effective Date (such event, a “Springing Covenant Event”). Proceeds of the DDTL may only be used to repurchase minority shares of Adtran Networks. The DDTL remains available for borrowing from the occurrence of a Springing Covenant Event through the period that is three consecutive fiscal quarters thereafter.

[0000950170-23-062173:mdna:100]
The First Amendment further added additional financial flexibility by amending the $30.0 million external debt capped basket to be an unlimited amount and permitting, subject to certain requirements, the incurrence of convertible indebtedness by the Company in an aggregate principal amount of up to $172.5 million. Any such convertible indebtedness must be incurred in pro forma compliance with the financial covenants in the Credit Agreement, unsecured and otherwise rank junior to borrowings under the Credit Agreement, and have a stated maturity date of at least 91 days after the latest scheduled maturity date of loans and commitments under the Credit Agreement. Net cash proceeds from any incurrence of convertible indebtedness must be used to repurchase minority shares of Adtran Networks or repay revolver borrowings under the Credit Agreement.

[0000950170-23-062173:mdna:101]
As of September 30, 2023, ADTRAN, Inc.’s borrowings under the revolving line of credit were $200.0 million. As of September 30, 2023, there were no borrowings under the DDTL. The Credit Facility matures in July 2027; however, the Company has an option to request extensions subject to customary conditions. In addition, we may issue up to $25.0 million in letters of credit against our $400.0 million total facility. As of September 30, 2023, we had a total of $2.2 million in letters of credit under ADTRAN, Inc. outstanding against our eligible borrowings, leaving a net amount of $197.8 million available for future borrowings. Any future credit extensions under the Credit Agreement are subject to customary conditions precedent. The proceeds of any loans are expected to be used for general corporate purposes and to pay a portion of the Exchange Offer consideration.

[0000950170-23-062173:mdna:102]
Revolving Line of Credit Interest Rate

[0000950170-23-062173:mdna:103]
All U.S. borrowings under the revolving line of credit (other than swingline loans, which bear interest at the Base Rate (as defined below)) bear interest, at the Company’s option, at a rate per annum equal to (A)(i) the highest of (a) the federal funds rate (i.e., for any day, the rate per annum equal to the weighted average of the rates on overnight federal funds transactions with members of the Federal Reserve System, as published by the Federal Reserve Bank of New York on the business day next succeeding such day) plus ½ of 1.0%, (b) the prime commercial lending rate of the Administrative Agent, as established from time to time at its principal U.S. office (which such rate is an index or base rate and will not necessarily be its lowest or best rate charged to its customers or other banks), and (c) the daily Adjusted Term SOFR (as defined in the Credit Agreement) for a one-month tenor plus 1.0%, plus (ii) the applicable rate, ranging from 0.65% to 1.65% (the “Base Rate”), or (B) the sum of the Adjusted Term SOFR (as defined in the Credit Agreement) plus the applicable rate, ranging from 1.65% to 2.65%, provided that such sum is subject to a 0.0% floor (such loans utilizing this interest rate, “SOFR Loans”). All E.U. borrowings under the Credit Agreement (other than swingline loans) bear interest at a rate per annum equal to the sum of the Euro Interbank Offered Rate as administered by the European Money Markets Institute (or a comparable or successor administrator approved by the Administrative Agent) plus the applicable rate, ranging from 1.75% to 2.75%, provided that such sum is subject to a 0.0% floor (such loans utilizing this interest rate, “EURIBOR Loans”). The applicable rate is based on the consolidated net leverage ratio of the Company and its subsidiaries as determined pursuant to the terms of the Credit Agreement. Default interest is 2.0% per annum in excess of the rate otherwise applicable in the case of any overdue principal or any other overdue amount.

[0000950170-23-062173:mdna:104]
In addition to paying interest on outstanding principal under the Credit Agreement, the Company is required to pay a commitment fee to the lenders under the Credit Agreement in respect of unutilized revolving loan commitments and an additional commitment ticking fee at a rate ranging from 0.20% to 0.25% per annum on the average daily unused portion of the revolving credit commitment of each lender until the earliest of (i) the date of the Senior Credit Facilities Increase, (ii) the Company’s voluntary termination of the credit facility commitment, and (iii) December 31, 2023. The Company is also required to pay a participation fee to the Administrative Agent for the account of each lender with respect to the Company’s participation in letters of credit at the then applicable rate for SOFR Loans.

[0000950170-23-062173:mdna:105]
DDTL Interest Rate

[0000950170-23-062173:mdna:106]
All U.S. borrowings under the DDTL bear interest, at the Company’s option, at a rate per annum equal to (A)(i) the highest of (a) the federal funds rate (i.e., for any day, the rate per annum equal to the weighted average of the rates on overnight federal funds transactions with members of the Federal Reserve System, as published by the Federal Reserve Bank of New York on the business day next succeeding such day) plus ½ of 1.0%, (b) the prime commercial lending rate of the Administrative Agent, as established from time to

[0000950170-23-062173:mdna:107]
time at its principal U.S. office (which such rate is an index or base rate and will not necessarily be its lowest or best rate charged to its customers or other banks), and (c) the sum of the Adjusted Term SOFR (as defined in the Credit Agreement) plus the applicable rate, ranging from 1.9% to 2.9%, provided that such sum is subject to a 0.0% floor (such loans utilizing this interest rate, “SOFR Loans”) or (B) the sum of the daily Adjusted Term SOFR (as defined in the Credit Agreement) for a one-month tenor plus 1.0%, plus (ii) the applicable rate, ranging from 0.9% to 1.9%. The applicable rate is based on the consolidated net leverage ratio of the Company and its subsidiaries as determined pursuant to the terms of the Credit Agreement. Default interest is 2.0% per annum in excess of the rate otherwise applicable in the case of any overdue principal or any other overdue amount.

[0000950170-23-062173:mdna:108]
In addition to paying interest on outstanding principal under the a DDTL loan, the Company is required to pay a commitment fee to the lenders under the Credit Agreement in respect of unutilized DDTL commitments at a rate of 0.25% per annum on the daily unused portion of the aggregate DDTL commitment until the earliest of (i) the delayed draw funding date, (ii) the delayed draw funding deadline and (iii) the termination in full of the DDTL commitments.

[0000950170-23-062173:mdna:109]
Covenants Under the Credit Agreement

[0000950170-23-062173:mdna:110]
The First Amendment permits the Company to prepay any or all of the outstanding loans or to reduce the commitments under the First Amendment without incurring premiums or penalties (except breakage costs with respect to SOFR Loans and EURIBOR Loans). The First Amendment contains customary affirmative and negative covenants, including incurrence covenants and certain other limitations on the ability of the Company and the Company’s subsidiaries to incur additional debt, guarantee other obligations, grant liens on assets, make investments, dispose of assets, pay dividends or other payments on capital stock, make restricted payments, engage in mergers or consolidations, engage in transactions with affiliates, modify its organizational documents, and enter into certain restrictive agreements. It also contains customary events of default (subject to customary cure periods and materiality thresholds).

[0000950170-23-062173:mdna:111]
The First Amendment further included the following revised financial covenants; (i) the addition of an automatic step up in the consolidated total net leverage ratio to 5.00:1.00 from 3.25:1.00 upon the occurrence of a Springing Covenant Event and continuing for the fiscal quarter in which the Springing Covenant Event occurs and the next three consecutive fiscal quarters thereafter (such period, a “Springing Covenant Period”) and (ii) the addition of a consolidated senior secured net leverage ratio covenant to be tested quarterly during a Springing Covenant Period and sized at 4.00:1.00 during the first quarter ending after a Springing Covenant Event, 3.75:1.00 during the second quarter ending after a Springing Covenant Event and 3.50:1.00 during the third and fourth quarters ending after a Springing Covenant Event. Further, if the Company or any of its subsidiaries incurs unsecured indebtedness under the uncapped general indebtedness basket or permitted convertible indebtedness basket of the Credit Agreement in excess of $50.0 million in connection with a transaction that is a Springing Covenant Event or during a Springing Covenant Period, then the maximum consolidated senior secured net leverage ratio shall be, or shall automatically step down to, 3.50:1.00 at the time of such incurrence.

[0000950170-23-062173:mdna:112]
The First Amendment also requires that the consolidated interest coverage ratio (as defined in the First Amendment) of the Company and its subsidiaries tested on the last day of each fiscal quarter not fall below 3.00 to 1.00. As of September 30, 2023, the Company was in compliance with all material covenants.

[0000950170-23-062173:mdna:113]
Finally, pursuant to a Collateral Agreement, dated as of July 18, 2022, among the Company, ADTRAN, Inc. and the Administrative Agent, ADTRAN, Inc.’s obligations under the First Amendment are secured by substantially all of the assets of ADTRAN, Inc. and the Company. In addition, the Company has guaranteed ADTRAN, Inc.’s obligations under the First Amendment pursuant to a Guaranty Agreement, dated as of July 18, 2022, by ADTRAN, Inc. and the Company in favor of the Administrative Agent.

[0000950170-23-062173:mdna:114]
As of September 30, 2023, our cash on hand was $116.1 million of which $94.4 million was held by our foreign subsidiaries. As of December 31, 2022, cash on hand was $108.6 million and short-term investments were $0.3 million, which resulted in available short-term liquidity of $108.9 million, of which $86.3 million was held by our foreign subsidiaries. Generally, we intend to permanently reinvest funds held outside the U.S., except to the extent that any of these funds can be repatriated without withholding tax.

[0000950170-23-062173:mdna:115]
In addition to our cash and cash equivalents and the credit facility, we may fund a portion or all of the Exit Compensation through the sale of securities or additional alternative funding sources, if available. There can be no assurances that we would be successful in effecting these actions on commercially reasonable terms or at all. If we cannot raise additional funds as needed, it could have a material adverse impact on our financial results and financial condition.

[0000950170-23-062173:mdna:116]
[same as prior period, unchanged from 0000950170-23-042449:mdna:105]

[0000950170-23-062173:mdna:117]
Net cash used in operating activities of $29.3 million during the nine months ended September 30, 2023 improved by $13.4 million compared to net cash used in operating activities of $42.7 million during the nine months ended September 30, 2022. The decrease in net cash used was primarily due to the net loss for the period, for the reasons discussed above, as adjusted primarily for increased depreciation and increased deferred taxes, increased impairments and write downs and decreased net cash outflows from working capital. Additional details related to our working capital and its drivers are discussed below.

[0000950170-23-062173:mdna:118]
Net accounts receivable decreased 17.9% from $279.4 million as of December 31, 2022 to $229.3 million as of September 30, 2023. There was an allowance for credit losses of less than $15 thousand as of September 30, 2023 and an allowance for credit losses of less than $0.1 million as of December 31, 2022. The decrease in net accounts receivable was due primarily to sales volume and timing within the quarter, customer and geographical mix. Quarterly accounts receivable DSO increased from 72 days as of December 31, 2022 to 77

[0000950170-23-062173:mdna:119]
days as of September 30, 2023. The increase in DSO was due to customer and geographical mix associated with the Business Combination with Adtran Networks and timing of sales within the quarter.

[0000950170-23-062173:mdna:120]
Other receivables decreased 25.9% from $32.8 million as of December 31, 2022 to $24.3 million as of September 30, 2023. The decrease in other receivables was primarily attributable to a decrease for sales of raw materials.

[0000950170-23-062173:mdna:121]
Quarterly inventory turnover was 2.5 turns as of December 31, 2022 and 2.0 turns as of September 30, 2023. Inventory decreased 12.5% from $427.5 million as of December 31, 2022 to $374.0 million as of September 30, 2023. The decrease in inventory was primarily due to a $21.0 million write down of inventory due to a restructuring discontinuation of certain product lines within our Network Solutions segment, a reduction in component purchases due to improved lead times and utilization of buffer stock. We expect inventory levels to fluctuate as we attempt to maintain sufficient inventory in response to supply chain uncertainties.

[0000950170-23-062173:mdna:122]
Accounts payable decreased 37.4% from $237.7 million as of December 31, 2022 to $148.9 million as of September 30, 2023. The decrease in accounts payable was primarily due to a decrease in the average number of days payable to our trade suppliers. Accounts payable will fluctuate due to variations in the timing of the receipt of inventory, supplies and services and our subsequent payments for these purchases.

[0000950170-23-062173:mdna:123]
[same as prior period, unchanged from 0000950170-23-042449:mdna:112]

[0000950170-23-062173:mdna:124]
Capital expenditures totaled approximately $33.7 million and $10.1 million for the nine months ended September 30, 2023 and 2022, respectively. These expenditures were primarily used to purchase manufacturing and test equipment, software, computer hardware and building improvements. The increase in capital expenditures for the nine months ended September 30, 2023 is primarily attributable to an increase in expenditures due to the Business Combination with Adtran Networks and for expenditures related to the construction of a terafactory building in Europe.

[0000950170-23-062173:mdna:125]
Our combined short-term and long-term investments decreased $7.8 million from $33.0 million as of December 31, 2022 to $25.2 million as of September 30, 2023. This decrease reflects the impact of the net unrealized and realized gains and losses on our investments and the sale of our fixed income investments.

[0000950170-23-062173:mdna:126]
[same as prior period, unchanged from 0000950170-23-042449:mdna:115]

[0000950170-23-062173:mdna:127]
Our long-term investments decreased 22.9% from $32.7 million as of December 31, 2022 to $25.2 million as of September 30, 2023. Our investments include various marketable equity securities classified as long-term investments with a fair market value of $0.7 million and $0.8 million as of September 30, 2023 and December 31, 2022, respectively. Our investments include various available-for-sale debt securities classified as long-term investments with a fair market value of $9.3 million as of December 31, 2022. The Company did not hold any available-for-sale debt securities as of September 30, 2023. Long-term investments as of September 30, 2023 and December 31, 2022 also included $24.4 million and $22.9 million, respectively, related to our deferred compensation plans.

[0000950170-23-062173:mdna:128]
[same as prior period, unchanged from 0000950170-23-042449:mdna:118]

[0000950170-23-062173:mdna:129]
[same as prior period, unchanged from 0000950170-23-042449:mdna:119]

[0000950170-23-062173:mdna:130]
During the nine month periods ended September 30, 2023 and 2022, we paid dividends totaling $21.2 million and $15.9 million, respectively. On November 6, 2023, the Board of Directors suspended the Company’s quarterly cash dividend which will be redirected to reduce debt and interest expense and support the Company's capital efficiency program. The payment of any future dividends will be at the discretion of the Board of Directors and will depend on the Company’s financial condition, results of operations, capital requirements, and any other factors deemed relevant by the Board of Directors.

[0000950170-23-062173:mdna:131]
[same as prior period, unchanged from 0000950170-23-042449:mdna:121]

[0000950170-23-062173:mdna:132]
There were no stock repurchases during the periods ended September 30, 2023 and 2022, and there currently is no authorized stock repurchase program.

[0000950170-23-062173:mdna:133]
[same as prior period, unchanged from 0000950170-23-042449:mdna:123]

[0000950170-23-062173:mdna:134]
To accommodate employee stock option exercises, the Company issued 8 thousand and 0.4 million shares of common stock and treasury stock which resulted in proceeds of $0.1 million and $4.8 million during the nine months ended September 30, 2023 and 2022, respectively. Additionally, to accommodate Adtran Networks SE stock option exercises, Adtran Networks issued 13 thousand shares of Adtran Networks common stock which resulted in proceeds of $0.1 million, for the nine months ended September 30, 2023. Adtran Networks SE stock options outstanding as of September 30, 2023 totaled 58 thousand (representing less than 0.2% of Adtran Networks outstanding shares), of which 12 thousand were exercisable.

[0000950170-23-062173:mdna:135]
[same as prior period, unchanged from 0000950170-23-042449:mdna:125]

[0000950170-23-062173:mdna:136]
We have exposure to credit losses from off-balance sheet exposures, to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds, where we believe the risk of loss is immaterial to our financial statements as of September 30, 2023. Otherwise, we do not have off-balance sheet financing arrangements and have not engaged in any related party transactions or arrangements with unconsolidated entities or other persons that are reasonably likely to materially affect liquidity or the availability of or requirements for capital resources. See Note 20 of the Notes to Condensed Consolidated Financial Statements, included in Part I, Item 1 of this report for additional information.

[0000950170-23-062173:mdna:137]
[same as prior period, unchanged from 0000950170-23-042449:mdna:127]

[0000950170-23-062173:mdna:138]
The following table summarizes the Company’s material short- and long-term cash requirements from known obligations pursuant to certain contracts and commitments as of September 30, 2023, as well as an estimate of the timing in which such obligations and payments are expected to be satisfied (but excluding payments that may be made pursuant to the DPLTA and currency hedging arrangements, which are discussed below). Other than operating lease obligations, the cash requirements table excludes interest payments.

[0000950170-23-062173:mdna:139]
| (In thousands) |  | Total |  |  | 2023 |  |  | 2024 |  |  | 2025 |  |  | 2026 |  |  | 2027 |  |  | After 2027 |  |
| Wells Fargo credit agreement(1) |  | $ | 200,000 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 200,000 |  |  | $ | — |  |
| Nord/LB revolving line of credit(2) |  |  | 10,580 |  |  |  | 10,580 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Purchase obligations(3) |  |  | 308,424 |  |  |  | 187,247 |  |  |  | 108,054 |  |  |  | 12,822 |  |  |  | 301 |  |  |  | — |  |  |  | — |  |
| Operating lease obligations(4) |  |  | 39,095 |  |  |  | 2,206 |  |  |  | 8,708 |  |  |  | 7,308 |  |  |  | 5,280 |  |  |  | 3,857 |  |  |  | 11,736 |  |
| Totals |  | $ | 558,099 |  |  | $ | 200,033 |  |  | $ | 116,762 |  |  | $ | 20,130 |  |  | $ | 5,581 |  |  | $ | 203,857 |  |  | $ | 11,736 |  |

[0000950170-23-062173:mdna:140]
[same as prior period, unchanged from 0000950170-23-042449:mdna:130]

[0000950170-23-062173:mdna:141]
[same as prior period, unchanged from 0000950170-23-042449:mdna:131]

[0000950170-23-062173:mdna:142]
[same as prior period, unchanged from 0000950170-23-042449:mdna:132]

[0000950170-23-062173:mdna:143]
[same as prior period, unchanged from 0000950170-23-042449:mdna:133]

[0000950170-23-062173:mdna:144]
[same as prior period, unchanged from 0000950170-23-042449:mdna:134]

[0000950170-23-062173:mdna:145]
[same as prior period, unchanged from 0000950170-23-042449:mdna:135]

[0000950170-23-062173:mdna:146]
[same as prior period, unchanged from 0000950170-23-042449:mdna:136]

[0000950170-23-062173:mdna:147]
locations. Our operating leases had remaining lease terms ranging from two months to 117 months as of September 30, 2023.

[0000950170-23-062173:mdna:148]
[same as prior period, unchanged from 0000950170-23-042449:mdna:138]

[0000950170-23-062173:mdna:149]
On July 18, 2022, ADTRAN Holdings, Inc. and ADTRAN, Inc., as the borrower, entered into a credit agreement with a syndicate of banks, including the Administrative Agent and the other lenders named therein. See “Liquidity and Capital Resources” above for additional information regarding the Wells Fargo credit agreement.

[0000950170-23-062173:mdna:150]
[same as prior period, unchanged from 0000950170-23-042449:mdna:145]

[0000950170-23-062173:mdna:151]
On March 29, 2023, Adtran Networks entered into a $16.1 million unsecured revolving line of credit with Norddeutsche Landesbark - Girozentrale (Nord/LB) that bears interest of Euro Short Term Rate plus 1.94%. The line of credit has a perpetual term that can be terminated by the Company or Nord/LB at any time. As of September 30, 2023, Adtran Networks borrowed $10.6 million under this facility.

[0000950170-23-062173:mdna:152]
Prior Nord/LB Revolving Line of Credit

[0000950170-23-062173:mdna:153]
On August 8, 2022, Adtran Networks entered into a $16.1 million revolving line of credit with Norddeutsche Landesbark - Girozentrale (Nord/LB) that bears interest of Euro Short Term Rate plus 1.4% and matured in August 2023. On January 31, 2023, the Company repaid the outstanding borrowings under the Nord/LB revolving line of credit. No amounts are available for future borrowings.

[0000950170-23-062173:mdna:154]
Syndicated Credit Agreement Working Capital Line of Credit

[0000950170-23-062173:mdna:155]
In September 2018, Adtran Networks entered into a syndicated credit agreement with Bayerische Landesbank and Deutsche Bank AG Branch German Business to borrow up to $10.7 million as part of a working capital line of credit. On January 31, 2023, the Company

[0000950170-23-062173:mdna:156]
repaid the outstanding borrowings under the syndicated credit agreement working capital line of credit. No amounts are available for future borrowings.

[0000950170-23-062173:mdna:157]
DZ Bank Revolving Line of Credit

[0000950170-23-062173:mdna:158]
In the fourth quarter of 2022, Adtran Networks entered into a revolving line of credit with DZ Bank to borrow up to $9.1 million. Interest on the line of credit reset monthly based on renewal of the loan and was 2.8% at the time the loan was repaid. On March 12, 2023, the Company repaid the outstanding borrowings under the DZ Bank revolving line of credit. No amounts are available for future borrowings.

[0000950170-23-062173:mdna:159]
[same as prior period, unchanged from 0000950170-23-042449:mdna:147]

[0000950170-23-062173:mdna:160]
On November 3, 2022, the Company entered into a Euro/U.S. forward contract arrangement (the “Initial Forward”) with Wells Fargo Bank, N.A. (the “Hedge Counterparty”). The Initial Forward, which is governed by the provisions of an ISDA Master Agreement (including schedules thereto and transaction confirmations that supplement such agreement) entered into between the Company and the Hedge Counterparty, enables the Company to convert a portion of its Euro denominated payment obligations under the DPLTA into U.S. Dollars. Under the Initial Forward, the Company agreed to exchange an aggregate notional amount of €160.0 million for U.S. dollars at a daily fixed forward rate ranging from $0.98286 to $1.03290. The aggregate amount of €160.0 million is divided into eight quarterly tranches of €20.0 million which commenced in the fourth quarter of 2022. During the nine months ended September 30, 2023, the Company settled three €20.0 million forward contract tranches and the remaining amount will be divided into five quarterly tranches of €20.0 million. The Company, at its sole discretion, may exchange all or part of each tranche on any given day within the applicable quarter; provided, however, that it must exchange the full tranche by the end of such quarter. The Initial Forward may be accelerated or terminated early for a number of reasons, including but not limited to (i) non-payment by the Company or the Hedge Counterparty, (ii) breach of representation or warranty or covenant by either party or (iii) insolvency or bankruptcy of either party.

[0000950170-23-062173:mdna:161]
On March 21, 2023, the Company entered into a Euro/U.S. dollar forward contract arrangement (the “Forward”) with the Hedge Counterparty. Under the Forward, which is governed by the provisions of an ISDA Master Agreement (including schedules thereto and transaction confirmations that supplement such agreement) entered into between the Company and the Hedge Counterparty, the Company will exchange an aggregate notional amount of €160.0 million for U.S. dollars at a daily fixed forward rate of $1.085 per €1.00 in average. During the nine months ended September 30, 2023, the Company settled three €20.0 million forward contract tranches, and the remaining amount will be divided into five quarterly tranches of €20.0 million. These forward contracts were executed on March 21, 2023 (to sell EUR/buy USD) and were entered into for the purpose of unwinding the Initial Forward (to buy EUR/sell USD). The drawdown dates of the Initial Forward are set to the same date as the maturity of the new offsetting Forward.

[0000950170-23-062173:mdna:162]
59

[0000950170-23-062173:mdna:163]
[same as prior period, unchanged from 0000950170-23-042449:mdna:152]

[0000950170-23-062173:mdna:164]
[same as prior period, unchanged from 0000950170-23-042449:mdna:153]

[0000950170-23-062173:mdna:165]
[same as prior period, unchanged from 0000950170-23-042449:mdna:154]

[0000950170-23-062173:mdna:166]
Additionally, and subject to certain limitations pursuant to applicable law and the specific terms of the DPLTA, the DPLTA provides that Adtran Networks shareholders (other than us) be offered, at their election, (i) to put their Adtran Networks shares to the Company in exchange for compensation in cash of €17.21 per share plus guaranteed interest (the "Exit Compensation"), or (ii) to remain Adtran Networks shareholders and receive a recurring compensation in cash of €0.59 (€0.52 net under the current tax regime) per share for each full fiscal year of Adtran Networks (the “Annual Recurring Compensation”). The guaranteed interest component under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid. The guaranteed interest rate is 5.0% plus a variable component that was 3.12% as of September 30, 2023. The Annual Recurring Compensation is due on the third banking day following the ordinary general shareholders’ meeting of Adtran Networks for the respective preceding fiscal year (but in any event within eight months following expiration of the fiscal year) and is first granted for the 2023 fiscal year, payable for the first time after the ordinary general shareholders’ meeting of Adtran Networks in 2024. The adequacy of both forms of compensation have been challenged by minority shareholders of Adtran Networks via court-led appraisal proceedings under German law, and it is possible that the courts in such appraisal proceedings may adjudicate a higher Exit Compensation or Annual Recurring Compensation (in each case, including interest thereon) than agreed upon in the DPLTA. Our aggregate potential payment obligations under the DPLTA are discussed above under "Liquidity".

[0000950170-23-062173:mdna:167]
[same as prior period, unchanged from 0000950170-23-042449:mdna:156]

[0000950170-23-062173:mdna:168]
We currently hold 33,957,538 no-par value bearer shares of Adtran Networks, representing 65.36% of Adtran Networks outstanding shares as of September 30, 2023.

[0000950170-23-062173:mdna:169]
[same as prior period, unchanged from 0000950170-23-042449:mdna:158]

[0000950170-23-062173:mdna:170]
As of September 30, 2023, the Company has incurred $26.2 million of transaction costs related to the Business Combination. During the three and nine months ended September 30, 2023, $8 thousand and $0.1 million of transaction costs were incurred, respectively. During the three and nine months ended September 30, 2022, $10.6 million and $13.3 million of transaction costs were incurred, respectively.

[0000950170-23-062173:mdna:171]
During the three and nine months ended September 30, 2023, we recognized $1.7 million and $3.1 million of integration costs related to the Business Combination, respectively, that are included in selling, general and administrative expenses in the Condensed Consolidated Statement of Loss. We expect to incur additional integration costs and costs associated with the implementation of the DPLTA during the remainder of 2023 and 2024 and such costs are expected to be material.

[0000950170-23-062173:mdna:172]
During the three and nine months ended September 30, 2023, we recognized $24.9 million and $33.2 million of restructuring costs relating to the Business Combination, respectively, that are included in cost of revenue, selling, general and administrative expenses and research and development expenses in the Condensed Consolidated Statement of Loss. See Note 21 of the Notes to Condensed Consolidated Financial Statements, included in Part I, Item 1 of this report for additional information.

[0000950170-23-062173:mdna:173]
[same as prior period, unchanged from 0000950170-23-042449:mdna:162]

[0000950170-23-062173:mdna:174]
During the nine months ended September 30, 2023, other than the Exit Compensation payments, Annual Recurring Compensation under the DPLTA, restructuring costs and increased debt service costs, there have been no other material changes in cash requirements from those discussed in the 2022 Form 10-K/A and our cash requirements table shown in Liquidity and Capital Resources above.

[0000950170-23-062173:mdna:175]
[same as prior period, unchanged from 0000950170-23-042449:mdna:164]

[0000950170-23-062173:mdna:176]
Certain contracts, customers and jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of September 30, 2023 and December 31, 2022, we had commitments related to these bonds totaling $11.8 million and $22.0 million, respectively, which expire at various dates through April 2031. In general, we would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which we believe is remote.

[0000950170-23-062173:mdna:177]
[same as prior period, unchanged from 0000950170-23-042449:mdna:166]

[0000950170-23-062173:mdna:178]
Goodwill

[0000950170-23-062173:mdna:179]
Goodwill represents the excess purchase price over the fair value of net assets acquired. The Company performed an impairment assessment as of September 30, 2023, prior to our October 1, 2023 annual measurement date. The quantitative goodwill impairment test is performed at the level of the reporting unit. The identification of our reporting units begins at the operating segment level and considers whether components one level below the operating segment levels should be identified as reporting units for the purpose of testing goodwill for impairment. For goodwill impairment testing purposes, we determined the Company's reporting units are generally the same as its operating segments, which are identified in Note 18 to the Condensed Consolidated Financial Statements. Our general policy is to qualitatively assess the carrying value of goodwill each reporting period for events or changes in circumstances that would more likely than not reduce the fair value of the reporting unit below its carrying amount. During the third quarter of 2023, qualitative factors such as a decrease in the Company's market capitalization and long-term projections, triggered a quantitative impairment assessment for our reporting units. The Company determined the fair value of each reporting unit using a combination of an income approach and a market based peer group analysis. It was determined that the decreases in projected future cash flows, discount rates, overall macroeconomic conditions, as well as the decrease in our market capitalization applied in the valuation were required to align with market-based assumptions and company-specific risk, which resulted in lower fair values of the Services & Support reporting unit. The Company determined upon its quantitative impairment assessment to recognized a $37.9 million non-cash goodwill impairment charge for the Services & Support reporting unit. The Company does not expect the impairment charge for the Services & Support Unit to result in any future cash expenditures. There was no impairment for the Network Solutions reporting unit during the three and nine months ended September 30, 2023. The balance of our goodwill was $339.1 million and $381.7 million as of September 30, 2023 and December 31, 2022, respectively.

[0000950170-23-062173:mdna:180]
Accounting Policies

[0000950170-23-062173:mdna:181]
An accounting policy is deemed to be critical if it requires an accounting estimate to be made based on assumptions about matters that are highly uncertain at the time the estimate is made, if different estimates reasonably could have been used or if changes in the accounting estimate that are reasonably likely to occur could materially impact the results of financial operations. Several accounting policies, as described in Note 1 of Notes to the Consolidated Financial Statements included in Part I, Item 1 of this report, require material subjective or complex judgment and have a significant impact on our financial condition and results of operations, as applicable. We believe the critical accounting policies affect our more significant judgments and estimates used in the preparation of our Condensed Consolidated Financial Statements. During the nine months ended September 30, 2023, other than the change in accounting policy regarding non-controlling interests as outlined in Note 1 and Note 16 to Condensed Consolidated Financial Statements included in Part I, Item 1 of this report, there were no significant changes to our critical accounting policies and estimates as described in the financial statements contained in the 2022 Form 10-K/A.
