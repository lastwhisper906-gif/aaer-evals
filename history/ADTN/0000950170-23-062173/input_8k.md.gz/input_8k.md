# ADTN 8-K — 0001193125-23-271842 filed 2023-11-07

## item codes, every 8-K on or before 2023-11-09

- 2023-11-07 0001193125-23-271842 — 2.02, 7.01, 9.01
- 2023-10-24 0001193125-23-261665 — 5.02, 5.03, 9.01
- 2023-10-17 0001193125-23-257289 — 2.02, 7.01, 9.01
- 2023-09-29 0001193125-23-246498 — 5.02
- 2023-08-14 0001193125-23-212439 — 2.02, 9.01 — amendment of 0001193125-23-204377
- 2023-08-10 0001193125-23-209039 — 4.02, 9.01
- 2023-08-10 0001193125-23-209024 — 2.02, 9.01 — amendment of 0001193125-23-204377
- 2023-08-07 0001193125-23-204377 — 2.02, 7.01, 9.01
- 2023-06-28 0001193125-23-177593 — 5.02, 9.01
- 2023-06-01 0001193125-23-158986 — 5.02, 9.01
- 2023-05-30 0001193125-23-156741 — 5.02
- 2023-05-15 0000950170-23-021860 — 5.07, 9.01
- 2023-05-09 0000950170-23-019145 — 2.02, 9.01
- 2023-04-11 0001193125-23-097240 — 2.02, 9.01
- 2023-04-03 0001193125-23-089517 — 5.02, 9.01
- 2023-03-30 0001193125-23-085151 — 5.02, 9.01
- 2023-02-21 0000950170-23-003277 — 2.02, 9.01
- 2023-02-08 0001193125-23-028386 — 1.02, 9.01
- 2023-01-26 0001193125-23-016354 — 5.02, 9.01
- 2023-01-19 0001193125-23-010702 — 8.01, 9.01
- 2022-12-05 0001193125-22-298171 — 1.01, 9.01
- 2022-11-09 0000950170-22-023662 — 2.02 — amendment of 0000950170-22-022906
- 2022-11-08 0000950170-22-022906 — 2.02, 9.01
- 2022-10-26 0001193125-22-269383 — 8.01
- 2022-10-25 0001193125-22-268261 — 2.02, 9.01 — amendment, the index does not say of what
- 2022-10-25 0001193125-22-267712 — 2.02, 9.01
- 2022-10-18 0001193125-22-264344 — 8.01, 9.01
- 2022-09-30 0000950170-22-019126 — 5.02, 9.01 — amendment of 0001193125-22-195093
- 2022-08-04 0000950170-22-014476 — 2.02, 9.01
- 2022-07-22 0001193125-22-200018 — 1.01, 1.02, 2.03, 9.01
- 2022-07-15 0001193125-22-195093 — 2.01, 5.02, 9.01
- 2022-07-08 0001193125-22-190213 — 2.01, 3.01, 3.03, 5.01, 5.02, 5.03, 7.01, 9.01
- 2022-07-07 0001193125-22-188934 — 7.01, 9.01
- 2022-06-30 0001193125-22-186294 — 5.04, 9.01
- 2022-05-23 0000950170-22-010455 — 1.01, 2.03, 9.01
- 2022-05-13 0000950170-22-009818 — 5.07
- 2022-05-05 0000950170-22-007563 — 2.02, 9.01
- 2022-04-06 0000950170-22-005405 — 1.01, 2.03, 9.01
- 2022-02-03 0000950170-22-000705 — 2.02, 9.01
- 2022-01-06 0001193125-22-003467 — 5.07, 7.01, 9.01
- 2021-12-28 0001193125-21-368041 — 8.01
- 2021-11-29 0000950170-21-004926 — 5.02, 9.01
- 2021-11-02 0000950170-21-002595 — 7.01, 9.01
- 2021-11-02 0000950170-21-002593 — 2.02, 9.01
- 2021-10-15 0000950170-21-002127 — 2.02, 9.01
- 2021-10-07 0000950170-21-002053 — 5.02
- 2021-09-01 0000950170-21-001615 — 5.02
- 2021-08-30 0001193125-21-260059 — 1.01, 7.01, 9.01
- 2021-08-05 0001564590-21-041127 — 2.02, 9.01
- 2021-05-18 0001564590-21-028541 — 5.07
- 2021-05-06 0001564590-21-024430 — 2.02, 9.01
- 2021-02-26 0001564590-21-009408 — 2.02, 9.01 — amendment of 0001564590-21-004167
- 2021-02-04 0001564590-21-004167 — 2.02, 9.01
- 2020-11-03 0001564590-20-049784 — 2.02, 9.01
- 2020-08-06 0001564590-20-037168 — 2.02, 9.01
- 2020-07-23 0001564590-20-033184 — 5.03, 9.01
- 2020-05-15 0001564590-20-025794 — 5.07
- 2020-05-11 0001564590-20-024328 — 5.02, 9.01
- 2020-05-07 0001564590-20-022297 — 2.02, 9.01
- 2020-02-25 0001564590-20-006448 — 2.02, 9.01
- 2020-02-06 0001564590-20-003580 — 2.02, 9.01
- 2019-10-31 0001564590-19-038936 — 2.02, 9.01
- 2019-10-10 0001564590-19-036732 — 2.02, 9.01
- 2019-09-20 0001564590-19-035144 — 2.02, 9.01
- 2019-08-21 0001564590-19-032757 — 3.01, 9.01
- 2019-07-18 0001564590-19-025186 — 2.02, 9.01
- 2019-05-09 0001564590-19-017956 — 5.07
- 2019-04-18 0001564590-19-011897 — 2.02, 9.01
- 2019-03-07 0001564590-19-006575 — 5.02, 9.01
- 2019-01-24 0001564590-19-001024 — 2.02, 9.01
- 2018-12-06 0001564590-18-030615 — 8.01, 9.01
- 2018-10-17 0001564590-18-024365 — 2.02, 9.01
- 2018-07-18 0001564590-18-016946 — 2.02, 9.01
- 2018-05-10 0001564590-18-012968 — 5.07
- 2018-04-18 0001564590-18-008361 — 2.02, 9.01
- 2018-03-21 0001564590-18-006409 — 8.01, 9.01
- 2018-01-17 0001564590-18-000519 — 2.02, 9.01
- 2017-12-29 0001564590-17-025375 — 2.02, 9.01
- 2017-11-16 0001193125-17-345232 — 5.02
- 2017-10-18 0001564590-17-019582 — 2.02, 9.01
- 2017-07-19 0001564590-17-013609 — 2.02, 9.01
- 2017-05-11 0001564590-17-010459 — 5.02, 9.01
- 2017-05-11 0001564590-17-010452 — 5.07
- 2017-04-19 0001193125-17-127926 — 2.02, 9.01
- 2017-02-07 0001193125-17-032714 — 8.01
- 2017-01-18 0001193125-17-011669 — 2.02, 9.01
- 2016-11-16 0001193125-16-769505 — 5.02, 9.01
- 2016-10-19 0001193125-16-741087 — 2.02, 9.01
- 2016-09-14 0001193125-16-709148 — 8.01, 9.01
- 2016-08-17 0001193125-16-683980 — 5.02, 9.01
- 2016-07-13 0001193125-16-646816 — 2.02, 9.01
- 2016-05-13 0001193125-16-590263 — 5.07
- 2016-04-13 0001193125-16-539019 — 2.02, 9.01
- 2016-04-08 0001193125-16-535035 — 7.01
- 2016-02-11 0001193125-16-459453 — 5.02, 9.01
- 2016-01-20 0001193125-16-432934 — 2.02, 9.01
- 2015-11-16 0001193125-15-378019 — 5.02, 9.01
- 2015-10-14 0001193125-15-343083 — 2.02, 9.01
- 2015-07-16 0001193125-15-254729 — 8.01, 9.01
- 2015-07-15 0001193125-15-253068 — 2.02, 9.01
- 2015-05-15 0001193125-15-189160 — 5.07, 9.01
- 2015-04-22 0001193125-15-140997 — 2.02, 9.01
- 2015-02-23 0001193125-15-056741 — 5.02, 9.01
- 2015-01-21 0001193125-15-015465 — 2.02, 9.01
- 2014-10-15 0001193125-14-372076 — 2.02, 9.01
- 2014-10-03 0001193125-14-363152 — 2.02, 9.01
- 2014-07-16 0001193125-14-269660 — 2.02, 9.01
- 2014-05-20 0001193125-14-205916 — 8.01, 9.01
- 2014-05-20 0001193125-14-205906 — 5.02, 9.01
- 2014-05-15 0001193125-14-201144 — 5.07
- 2014-04-16 0001193125-14-144665 — 2.02, 9.01
- 2014-04-03 0001193125-14-129578 — 2.02, 9.01
- 2014-01-22 0001157523-14-000154 — 2.02, 9.01
- 2013-10-15 0001193125-13-399540 — 5.02
- 2013-10-09 0001157523-13-004657 — 2.02, 9.01
- 2013-07-10 0001157523-13-003290 — 2.02, 9.01
- 2013-05-10 0001193125-13-213728 — 5.07
- 2013-05-03 0001193125-13-198816 — 8.01, 9.01
- 2013-04-10 0001157523-13-001730 — 2.02, 9.01
- 2013-01-16 0001157523-13-000139 — 2.02, 9.01
- 2012-10-10 0001157523-12-005081 — 2.02, 9.01
- 2012-10-03 0001193125-12-413609 — 7.01
- 2012-09-28 0001193125-12-408878 — 2.02, 9.01
- 2012-07-11 0001157523-12-003592 — 2.02, 9.01
- 2012-05-10 0001193125-12-225669 — 5.07
- 2012-05-10 0001193125-12-225639 — 8.01, 9.01
- 2012-04-11 0001157523-12-001772 — 2.02, 9.01
- 2012-03-15 0001193125-12-116494 — 2.02, 9.01
- 2012-01-18 0001157523-12-000174 — 2.02, 9.01
- 2011-12-12 0001193125-11-337271 — 7.01, 9.01
- 2011-10-13 0000950123-11-089785 — 5.03, 9.01
- 2011-10-12 0001157523-11-005682 — 2.02, 9.01
- 2011-07-13 0001157523-11-003986 — 2.02, 9.01
- 2011-05-09 0000950123-11-047191 — 5.02, 5.07, 9.01
- 2011-04-13 0001157523-11-002001 — 2.02, 9.01
- 2011-01-19 0001157523-11-000232 — 2.02, 9.01
- 2010-11-09 0000950123-10-103195 — 5.02, 9.01
- 2010-10-13 0001157523-10-005798 — 2.02, 9.01
- 2010-07-14 0001157523-10-004011 — 2.02, 9.01
- 2010-05-28 0000950123-10-053947 — 5.07
- 2010-04-14 0001157523-10-002022 — 2.02, 9.01
- 2010-01-20 0001157523-10-000200 — 2.02, 9.01
- 2009-10-28 0000950123-09-053984 — 8.01
- 2009-10-14 0001157523-09-006877 — 2.02, 9.01
- 2009-07-15 0001157523-09-004878 — 2.02, 9.01
- 2009-04-15 0001157523-09-002687 — 2.02, 9.01
- 2009-01-21 0001157523-09-000340 — 2.02, 9.01
- 2008-11-12 0001193125-08-233181 — 5.02, 9.01
- 2008-10-14 0001157523-08-007999 — 2.02, 9.01
- 2008-07-15 0001157523-08-005504 — 2.02, 9.01
- 2008-04-15 0001157523-08-002896 — 2.02, 9.01
- 2008-01-22 0001157523-08-000408 — 2.02, 9.01
- 2007-10-16 0001193125-07-219356 — 5.03, 9.01
- 2007-10-16 0001157523-07-009850 — 2.02, 9.01
- 2007-07-17 0001157523-07-006912 — 2.02, 9.01
- 2007-04-17 0001157523-07-003630 — 2.02, 9.01
- 2007-04-03 0001179022-07-000068 — 5.02
- 2007-03-28 0001179022-07-000064 — 5.02
- 2007-02-23 0001193125-07-038337 — 5.02
- 2007-02-23 0001193125-07-038335 — 5.02
- 2007-01-30 0001193125-07-015912 — 5.02, 9.01
- 2007-01-26 0001193125-07-014234 — 5.02
- 2007-01-23 0001157523-07-000494 — 2.02, 9.01 — amendment of 0001157523-07-000481
- 2007-01-23 0001157523-07-000481 — 2.02, 9.01
- 2006-10-17 0001157523-06-009945 — 2.02, 9.01
- 2006-07-18 0001157523-06-006929 — 2.02, 9.01
- 2006-06-08 0001193125-06-126486 — 1.01, 9.01
- 2006-05-10 0001193125-06-107316 — 1.01, 9.01
- 2006-04-18 0001157523-06-003699 — 2.02, 9.01
- 2006-02-03 0001179022-06-000014 — 1.01
- 2006-01-27 0001157523-06-000754 — 5.02, 9.01
- 2006-01-24 0001157523-06-000551 — 2.02, 9.01
- 2005-10-18 0001157523-05-008826 — 2.02, 9.01
- 2005-07-19 0001193125-05-143958 — 1.01, 5.02, 9.01
- 2005-07-19 0001193125-05-143957 — 2.02, 9.01
- 2005-05-20 0001193125-05-112019 — 1.01, 9.01
- 2005-04-19 0001157523-05-003418 — 2.02, 9.01
- 2005-01-25 0001193125-05-010721 — 2.02, 9.01
- 2004-10-12 0001193125-04-169652 — 2.02, 9.01
- 2004-07-13 0001193125-04-116820 — 12, 7
- 2004-04-14 0001193125-04-061547 — 12, 7
- 2004-01-21 0001193125-04-006366 — 12, 7
- 2003-10-14 0001193125-03-061018 — 12, 5, 7
- 2003-07-15 0001193125-03-019292 — 7, 9
- 2003-04-15 0000931763-03-000968 — 7, 9
- 1996-09-12 0000931763-96-000667 — 5, 7

## late-filing notifications on or before 2023-11-09

- 2023-08-10 0001193125-23-209042 — NT 10-Q, for the period ended 2023-06-30
- 2019-08-12 0001564590-19-031524 — NT 10-Q, for the period ended 2019-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001193125-23-271842:8k_2_02:1]
EX-99.1
2
d578796dex991.htm
EX-99.1

[0001193125-23-271842:8k_2_02:2]
EX-99.1

[0001193125-23-271842:8k_2_02:3]
Exhibit 99.1

[0001193125-23-271842:8k_2_02:4]
ADTRAN Holdings, Inc. reports third quarter 2023 financial results and announces business efficiency program

[0001193125-23-271842:8k_2_02:5]
|  | • |  | Q3 revenue at $272.3 million with sequential improvement in GAAP and non-GAAP operating expenses |

[0001193125-23-271842:8k_2_02:6]
|  | • |  | 15% projected reduction in non-GAAP operating expenses in Q4 2023 as compared to Q3 2023 |

[0001193125-23-271842:8k_2_02:7]
|  | • |  | Targeting positive non-GAAP operating margin for the second quarter 2024 |

[0001193125-23-271842:8k_2_02:8]
|  | • |  | Expected reduction of non-GAAP operating expenses of approximately $90 million for the year 2024 as compared to 2023 |

[0001193125-23-271842:8k_2_02:9]
|  | • |  | As part of the capital efficiency program, the Company has decided to suspend its quarterly dividend to reduce interest expense and support its long-term capital plan |

[0001193125-23-271842:8k_2_02:10]
|  | • |  | Target Financial Model: Non-GAAP operating margin to be in the low teens for the full year 2025 |

[0001193125-23-271842:8k_2_02:11]
Huntsville, Alabama, USA. — November 6, 2023 — ADTRAN Holdings, Inc.
(NASDAQ: ADTN and FSE: QH9) (“ADTRAN Holdings” or the “Company”) today announced its financial results for the third quarter of 2023.

[0001193125-23-271842:8k_2_02:12]
As reflected in the preliminary release, revenue for the third quarter was $272.3 million, slightly below the lower end of the guidance range.

[0001193125-23-271842:8k_2_02:13]
GAAP gross margin for the quarter was 27.3%, and it was negatively impacted by an inventory
write-off of approximately $21.0 million as a result of the exit from certain product lines in connection with our restructuring and the newly implemented and expanded business efficiency program.

[0001193125-23-271842:8k_2_02:14]
Non-GAAP gross margin was 40.3%, and it was positively impacted by a more favorable customer and product mix and lower
purchasing and transportation costs.

[0001193125-23-271842:8k_2_02:15]
GAAP operating margin for the quarter was negative 32.8%, and it was negatively impacted by the exit from
certain product lines discussed above and a $37.9 million goodwill impairment charge related to our Services & Support reporting unit. Sequentially, the Company reduced GAAP operating expenses by 8% from $137.2 million in the
second quarter 2023 to $125.7 million in the third quarter 2023.

[0001193125-23-271842:8k_2_02:16]
Non-GAAP operating margin for the quarter
was negative 1.9%, which was at the upper end of the guidance range. The Company reduced non-GAAP operating expenses by 6.3% from $122.7 million in the second quarter 2023 to $114.9 million in the
third quarter 2023.

[0001193125-23-271842:8k_2_02:17]
GAAP net loss attributable to the Company for the third quarter of 2023 was $72.7 million. Diluted loss per share attributable
to the Company for the quarter was $0.93.

[0001193125-23-271842:8k_2_02:18]
Non-GAAP net loss attributable to the Company was $10.8 million. Non-GAAP diluted loss per share attributable to the Company was $0.14.

[0001193125-23-271842:8k_2_02:19]
Business efficiency program

[0001193125-23-271842:8k_2_02:20]
Due to the uncertainty around the current macro-economic environment, customer inventory levels and its impact on customer spending levels, the Company has
implemented a comprehensive business efficiency program. The program includes:

[0001193125-23-271842:8k_2_02:21]
|  | • |  | a significant cost efficiency program targeting a reduction of non-GAAP operating expenses of approximately $90 million for the year 2024 as compared to 2023 and a projected $15 million reduction in non-GAAP operating expenses for the fourth quarter of 2023 compared to the third quarter of 2023; and |

[0001193125-23-271842:8k_2_02:22]
|  | • |  | a capital efficiency program which includes a site consolidation plan that management expects to generate proceeds up to $150 million and the suspension of the quarterly dividend. |

[0001193125-23-271842:8k_2_02:23]
Ultimately, we believe the successful execution of our
business efficiency program will benefit our shareholders.

[0001193125-23-271842:8k_2_02:24]
ADTRAN Holdings’ Chairman and Chief Executive Officer Tom Stanton stated, “We
anticipate that the ongoing uncertainty affecting customer spending will extend into 2024. We are actively addressing the challenges in our industry and have implemented a business

[0001193125-23-271842:8k_2_02:25]
efficiency program to ensure improvement in long-term shareholder return. Through this program, we are aiming to lower our costs by $90 million by the end of 2024 as compared to 2023.
Although the environment has proven to be very challenging, interest in our products continues to grow as we gained market share and added new customers during the quarter. We expect the combination of our continued growth in market share with our
new operating model to substantially improve returns to all our stakeholders.”

[0001193125-23-271842:8k_2_02:26]
Financial Outlook for the fourth quarter 2023

[0001193125-23-271842:8k_2_02:27]
The outlook for the fourth quarter 2023, is as follows:

[0001193125-23-271842:8k_2_02:28]
|  | • |  | revenue to be between $210 million and $240 million; and |

[0001193125-23-271842:8k_2_02:29]
|  | • |  | non-GAAP operating margin between negative 7% and 0%. |

[0001193125-23-271842:8k_2_02:30]
Non-GAAP operating margin (which is calculated as
non-GAAP operating (loss) income divided by revenue) and non-GAAP operating expense are non-GAAP financial measures. The Company
has provided fourth quarter guidance with regard to non-GAAP operating margin and projected reductions in non-GAAP operating expense as a result of its business
efficiency program. These measures exclude from the corresponding GAAP financial measures the effect of adjustments as described below under “Explanation of Use of Non-GAAP Financial Measures.” The
Company has not provided a reconciliation of such non-GAAP guidance to guidance presented on a GAAP basis because it cannot predict and quantify without unreasonable effort all of the adjustments that may
occur during the period due to the difficulty of predicting the timing and amounts of various items within a reasonable range. In particular, these non-GAAP financial measures exclude certain items, including
continued restructuring and integration expenses that will continue to evolve as our business efficiency program is implemented and, therefore, the Company is unable to quantitatively predict. Depending on the materiality of these items, they could
have a significant impact on the Company’s GAAP financial results.

[0001193125-23-271842:8k_2_02:31]
The Company confirmed that it will hold a conference call to discuss its third
quarter results on Tuesday, November 7, 2023, at 9:30 a.m. Central Time, or 4:30 p.m. Central European Summer Time. ADTRAN Holdings will webcast this conference call. To listen and view our investor presentation, simply visit our Investor
Relations site at investors.adtran.com approximately 10 minutes prior to the start of the call, click on the event “ADTRAN Holdings Releases 3rd Quarter 2023 Financial Results and Earnings
Call”, and click on the webcast link.

[0001193125-23-271842:8k_2_02:32]
An online replay of the Company’s conference call, as well as the transcript of the Company’s
conference call, will be available on the Investor Relations site approximately 24 hours following the call and will remain available for at least 12 months. For more information, visit investors.adtran.com or email
investor.relations@adtran.com.

[0001193125-23-271842:8k_2_02:33]
Cautionary Note Regarding Forward-Looking Statements

[0001193125-23-271842:8k_2_02:34]
sales and approval processes required by major and other service providers for new products, as well as ongoing tighter inventory management of ADTRAN Holdings’ customers; (vi) the risk
posed by potential breaches of information systems and cyber-attacks; (vii) the risk that ADTRAN Holdings may not be able to effectively compete, including through product improvements and development; and (viii) other risks set forth in
ADTRAN Holdings’ public filings made with the Securities and Exchange Commission, including its Annual Report on Form 10-K for the year ended December 31, 2022, as amended, as well as its Form 10-Q for the quarter ended June 30, 2023.

[0001193125-23-271842:8k_2_02:35]
Explanation of Use of
Non-GAAP Financial Measures

[0001193125-23-271842:8k_2_02:36]
Set forth in the tables below are reconciliations of gross profit, gross margin,
operating expenses, operating loss, other (expense) income, net (loss) income inclusive of the non-controlling interest, net loss attributable to the Company, net loss attributable to the non-controlling interest, and loss per share - basic and diluted, attributable to the Company, in each case as reported based on generally accepted accounting principles in the United States (“GAAP”), to non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating
(loss) income, non-GAAP other (expense) income, non-GAAP net (loss) income inclusive of the non-controlling interest, non-GAAP net (loss) income attributable to the Company, non-GAAP net (loss) income attributable to the non-controlling interest, and non-GAAP (loss) earnings per share - basic and diluted, attributable to the Company, respectively. Such non-GAAP measures exclude acquisition related expenses, amortization
and adjustments (consisting of intangible amortization of backlog, developed technology, customer relationships, and trade names acquired in connection with business combinations and amortization of inventory fair value adjustments), stock-based
compensation expense, amortization of pension actuarial losses, deferred compensation

[0001193125-23-271842:8k_2_02:37]
adjustments, integration expenses, restructuring expenses, asset and
goodwill impairments, changes in valuation allowance related to our deferred tax assets, and the tax effect of these adjustments to net income. These measures are used by management in our ongoing planning and annual budgeting processes.
Additionally, we believe the presentation of these non-GAAP measures when combined with the presentation of the most directly comparable GAAP financial measure, is beneficial to the overall understanding of
ongoing operating performance of the Company.

[0001193125-23-271842:8k_2_02:38]
The information contained in this press release is solely based on unaudited condensed consolidated
results. These non-GAAP financial measures are not prepared in accordance with, or an alternative for, GAAP and therefore should not be considered in isolation or as a

[0001193125-23-271842:8k_2_02:39]
substitution for analysis of our results as reported under GAAP. Additionally, our calculation of non-GAAP measures may not be comparable to similar
measures calculated by other companies.

[0001193125-23-271842:8k_2_02:40]
About Adtran

[0001193125-23-271842:8k_2_02:41]
ADTRAN Holdings, Inc. (NASDAQ: ADTN and
FSE: QH9) is the parent company of Adtran, Inc., a leading global provider of open, disaggregated networking and communications solutions that enable voice, data, video and internet communications across any network infrastructure. From the cloud
edge to the subscriber edge, Adtran empowers communications service providers around the world to manage and scale services that connect people, places and things. Adtran solutions are used by service providers, private enterprises, government
organizations and millions of individual users worldwide. ADTRAN Holdings, Inc. is also the largest shareholder of Adtran Networks SE, formerly ADVA Optical Networking SE. Find more at Adtran, LinkedIn and Twitter.

[0001193125-23-271842:8k_2_02:42]
Published by

[0001193125-23-271842:8k_2_02:43]
ADTRAN Holdings, Inc.

[0001193125-23-271842:8k_2_02:44]
www.adtran.com

[0001193125-23-271842:8k_2_02:45]
For media

[0001193125-23-271842:8k_2_02:46]
Gareth Spence

[0001193125-23-271842:8k_2_02:47]
+44 1904 699 358

[0001193125-23-271842:8k_2_02:48]
public.relations@adtran.com

[0001193125-23-271842:8k_2_02:49]
For investors

[0001193125-23-271842:8k_2_02:50]
Steven Williams

[0001193125-23-271842:8k_2_02:51]
+49 89 890 665 918

[0001193125-23-271842:8k_2_02:52]
investor@adtran.com

[0001193125-23-271842:8k_2_02:53]
Condensed Consolidated Balance Sheets

[0001193125-23-271842:8k_2_02:54]
(Unaudited)

[0001193125-23-271842:8k_2_02:55]
(In
thousands)

[0001193125-23-271842:8k_2_02:56]
|  |  | September 30,2023 |  |  | December 31,2022 |  |
| Assets |  |  |  |  |  |  |  |  |
| Current Assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 116,092 |  |  | $ | 108,644 |  |
| Short-term investments |  |  | — |  |  |  | 340 |  |
| Accounts receivable, net |  |  | 229,333 |  |  |  | 279,435 |  |
| Other receivables |  |  | 24,337 |  |  |  | 32,831 |  |
| Inventory, net |  |  | 373,971 |  |  |  | 427,531 |  |
| Prepaid expenses and other current assets |  |  | 35,826 |  |  |  | 33,577 |  |
| Total Current Assets |  |  | 779,559 |  |  |  | 882,358 |  |
| Property, plant and equipment, net |  |  | 118,623 |  |  |  | 110,699 |  |
| Deferred tax assets |  |  | 90,260 |  |  |  | 67,839 |  |
| Goodwill |  |  | 339,083 |  |  |  | 381,724 |  |
| Intangibles, net |  |  | 328,695 |  |  |  | 401,211 |  |
| Other non-current assets |  |  | 60,770 |  |  |  | 66,998 |  |
| Long-term investments |  |  | 25,179 |  |  |  | 32,665 |  |
| Total Assets |  | $ | 1,742,169 |  |  | $ | 1,943,494 |  |
| Liabilities, Redeemable Non-Controlling Interest and Equity |  |  |  |  |  |  |  |  |
| Current Liabilities |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 148,913 |  |  | $ | 237,699 |  |
| Revolving credit agreements outstanding |  |  | 10,580 |  |  |  | 35,936 |  |
| Notes payable |  |  | — |  |  |  | 24,598 |  |
| Unearned revenue |  |  | 49,832 |  |  |  | 41,193 |  |
| Accrued expenses and other liabilities |  |  | 29,708 |  |  |  | 35,235 |  |
| Accrued wages and benefits |  |  | 35,957 |  |  |  | 44,882 |  |
| Income tax payable, net |  |  | 10,302 |  |  |  | 9,032 |  |
| Total Current Liabilities |  |  | 285,292 |  |  |  | 428,575 |  |
| Non-current revolving credit agreement outstanding |  |  | 200,000 |  |  |  | 60,000 |  |
| Deferred tax liabilities |  |  | 37,977 |  |  |  | 61,629 |  |
| Non-current unearned revenue |  |  | 23,501 |  |  |  | 19,239 |  |
| Pension liability |  |  | 10,732 |  |  |  | 10,624 |  |
| Deferred compensation liability |  |  | 26,833 |  |  |  | 26,668 |  |
| Non-current lease obligations |  |  | 23,612 |  |  |  | 22,807 |  |
| Other non-current liabilities |  |  | 17,408 |  |  |  | 10,339 |  |
| Total Liabilities |  |  | 625,355 |  |  |  | 639,881 |  |
| Redeemable Non-Controlling Interest |  |  | 431,921 |  |  |  | — |  |
| Equity |  |  |  |  |  |  |  |  |
| Common stock |  |  | 787 |  |  |  | 781 |  |
| Additional paid-in capital |  |  | 770,565 |  |  |  | 895,834 |  |
| Accumulated other comprehensive income |  |  | 32,800 |  |  |  | 46,713 |  |
| Retained (deficit) earnings |  |  | (113,289 | ) |  |  | 55,338 |  |
| Treasury stock |  |  | (5,970 | ) |  |  | (4,125 | ) |
| Non-controlling interest |  |  | — |  |  |  | 309,072 |  |
| Total Equity |  |  | 684,893 |  |  |  | 1,303,613 |  |
| Total Liabilities, Redeemable Non-Controlling Interest and Equity |  | $ | 1,742,169 |  |  | $ | 1,943,494 |  |

[0001193125-23-271842:8k_2_02:57]
Condensed Consolidated Statements of Loss

[0001193125-23-271842:8k_2_02:58]
(Unaudited)

[0001193125-23-271842:8k_2_02:59]
(In
thousands, except per share amounts)

[0001193125-23-271842:8k_2_02:60]
|  |  | Three Months EndedSeptember 30, |  |  | Nine Months EndedSeptember 30, |  |
|  |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Network Solutions |  | $ | 228,564 |  |  | $ | 304,940 |  |  | $ | 793,984 |  |  | $ | 599,306 |  |
| Services & Support |  |  | 43,767 |  |  |  | 35,769 |  |  |  | 129,637 |  |  |  | 67,959 |  |
| Total Revenue |  |  | 272,331 |  |  |  | 340,709 |  |  |  | 923,621 |  |  |  | 667,265 |  |
| Cost of Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Network Solutions |  |  | 160,244 |  |  |  | 222,606 |  |  |  | 596,334 |  |  |  | 413,180 |  |
| Network Solutions - Inventory Write Down |  |  | 21,043 |  |  |  | — |  |  |  | 21,043 |  |  |  | — |  |
| Services & Support |  |  | 16,807 |  |  |  | 15,076 |  |  |  | 51,646 |  |  |  | 34,236 |  |
| Total Cost of Revenue |  |  | 198,094 |  |  |  | 237,682 |  |  |  | 669,023 |  |  |  | 447,416 |  |
| Gross Profit |  |  | 74,237 |  |  |  | 103,027 |  |  |  | 254,598 |  |  |  | 219,849 |  |
| Selling, general and administrative expenses |  |  | 62,907 |  |  |  | 74,880 |  |  |  | 196,887 |  |  |  | 130,646 |  |
| Research and development expenses |  |  | 62,752 |  |  |  | 59,196 |  |  |  | 203,493 |  |  |  | 112,187 |  |
| Asset impairment |  |  | — |  |  |  | 16,969 |  |  |  | — |  |  |  | 16,969 |  |
| Goodwill Impairment |  |  | 37,874 |  |  |  | — |  |  |  | 37,874 |  |  |  | — |  |
| Operating Loss |  |  | (89,296 | ) |  |  | (48,018 | ) |  |  | (183,656 | ) |  |  | (39,953 | ) |
| Interest and dividend income |  |  | 521 |  |  |  | 347 |  |  |  | 1,183 |  |  |  | 768 |  |
| Interest expense |  |  | (4,507 | ) |  |  | (1,303 | ) |  |  | (11,858 | ) |  |  | (1,427 | ) |
| Net investment (loss) gain |  |  | (1,443 | ) |  |  | (2,691 | ) |  |  | 1,071 |  |  |  | (10,752 | ) |
| Other income, net |  |  | 2,523 |  |  |  | 2,494 |  |  |  | 4,714 |  |  |  | 2,949 |  |
| Loss Before Income Taxes |  |  | (92,202 | ) |  |  | (49,171 | ) |  |  | (188,546 | ) |  |  | (48,415 | ) |
| Income tax benefit |  |  | 16,553 |  |  |  | 4,312 |  |  |  | 36,229 |  |  |  | 4,572 |  |
| Net Loss |  | $ | (75,649 | ) |  | $ | (44,859 | ) |  | $ | (152,317 | ) |  | $ | (43,843 | ) |
| Less: Net Loss attributable to non-controlling interest(1) |  |  | (2,914 | ) |  |  | (2,925 | ) |  |  | (11,784 | ) |  |  | (2,925 | ) |
| Net Loss attributable to ADTRAN Holdings, Inc. |  | $ | (72,735 | ) |  | $ | (41,934 | ) |  | $ | (140,533 | ) |  | $ | (40,918 | ) |
| Weighted average shares outstanding – basic |  |  | 78,389 |  |  |  | 73,036 |  |  |  | 78,378 |  |  |  | 57,175 |  |
| Weighted average shares outstanding – diluted |  |  | 78,389 |  |  |  | 73,036 |  |  |  | 78,378 |  |  |  | 57,175 |  |
| Loss per common share attributable to ADTRAN Holdings, Inc. – basic |  | $ | (0.93 | ) |  | $ | (0.57 | ) |  | $ | (1.79 | ) |  | $ | (0.72 | ) |
| Loss per common share attributable to ADTRAN Holdings, Inc. – diluted |  | $ | (0.93 | ) |  | $ | (0.57 | ) |  | $ | (1.79 | ) |  | $ | (0.72 | ) |

[0001193125-23-271842:8k_2_02:61]
| (1) | For the three and six months ended September 30, 2023, we have recognized $2.9 million and $8.6 million, respectively, representing the recurring cash compensation earned by non-controlling interest shareholders post-DPLTA and an incremental $3.2 million net loss attributable to non-controlling interests pre-DPLTA for the six months ended September 30, 2023. |

[0001193125-23-271842:8k_2_02:62]
Condensed Consolidated Statements of Cash Flows

[0001193125-23-271842:8k_2_02:63]
(Unaudited)

[0001193125-23-271842:8k_2_02:64]
(In
thousands)

[0001193125-23-271842:8k_2_02:65]
|  |  | Nine Months EndedSeptember 30, |  |
|  |  | 2023 |  |  | 2022 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net loss |  | $ | (152,317 | ) |  | $ | (43,843 | ) |
| Adjustments to reconcile net loss to net cash used in operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 91,422 |  |  |  | 34,783 |  |
| Asset impairment |  |  | — |  |  |  | 16,969 |  |
| Goodwill impairment |  |  | 37,874 |  |  |  | — |  |
| Amortization of debt issuance cost |  |  | 607 |  |  |  | 200 |  |
| (Gain) loss on investments, net |  |  | (3,316 | ) |  |  | 10,395 |  |
| Stock-based compensation expense |  |  | 12,229 |  |  |  | 15,912 |  |
| Deferred income taxes |  |  | (45,941 | ) |  |  | (26,366 | ) |
| Other, net |  |  | 204 |  |  |  | 32 |  |
| Inventory write down |  |  | 21,043 |  |  |  | — |  |
| Inventory reserves |  |  | 29,836 |  |  |  | (6,681 | ) |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  |  | 47,347 |  |  |  | (34,535 | ) |
| Other receivables |  |  | 8,340 |  |  |  | (2,154 | ) |
| Inventory |  |  | 536 |  |  |  | (76,293 | ) |
| Prepaid expenses, other current assets and other assets |  |  | 1,816 |  |  |  | 610 |  |
| Accounts payable |  |  | (87,903 | ) |  |  | 70,381 |  |
| Accrued expenses and other liabilities |  |  | 6,476 |  |  |  | (23,005 | ) |
| Income taxes payable, net |  |  | 2,433 |  |  |  | 20,862 |  |
| Net cash used in operating activities |  |  | (29,314 | ) |  |  | (42,733 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (33,674 | ) |  |  | (10,141 | ) |
| Proceeds from sales and maturities of available-for-sale investments |  |  | 10,545 |  |  |  | 30,474 |  |
| Purchases of available-for-sale investments |  |  | (807 | ) |  |  | (22,215 | ) |
| Proceeds from beneficial interests in securitized accounts receivable |  |  | 1,178 |  |  |  | 1,294 |  |
| Proceeds from disposals of property, plant and equipment |  |  | — |  |  |  | 12 |  |
| Acquisition of business, net of cash acquired |  |  | — |  |  |  | 43,957 |  |
| Net cash (used in) provided by investing activities |  |  | (22,758 | ) |  |  | 43,381 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Tax withholdings related to stock-based compensation settlements |  |  | (6,331 | ) |  |  | (515 | ) |
| Proceeds from stock option exercises |  |  | 187 |  |  |  | 5,434 |  |
| Dividend payments |  |  | (21,237 | ) |  |  | (15,859 | ) |
| Proceeds from draw on revolving credit agreements |  |  | 163,760 |  |  |  | 133,141 |  |
| Repayment of revolving credit agreements |  |  | (49,233 | ) |  |  | (48,000 | ) |
| Non-controlling interest put option buyback |  |  | (1,196 | ) |  |  | — |  |
| Payment of debt issuance cost |  |  | (708 | ) |  |  | (3,015 | ) |
| Repayment of notes payable |  |  | (24,931 | ) |  |  | (10,057 | ) |
| Net cash provided by financing activities |  |  | 60,311 |  |  |  | 61,129 |  |
| Net increase in cash and cash equivalents |  |  | 8,239 |  |  |  | 61,777 |  |
| Effect of exchange rate changes |  |  | (791 | ) |  |  | (7,496 | ) |
| Cash and cash equivalents, beginning of period |  |  | 108,644 |  |  |  | 56,818 |  |
| Cash and cash equivalents, end of period |  | $ | 116,092 |  |  | $ | 111,099 |  |
| Supplemental disclosure of cash financing activities: |  |  |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 8,540 |  |  | $ | 633 |  |
| Cash used in operating activities related to operating leases |  | $ | 7,378 |  |  | $ | 2,272 |  |
| Supplemental disclosure of non-cash investing activities: |  |  |  |  |  |  |  |  |
| Right-of-use assets obtained in exchange for lease obligations |  | $ | 8,490 |  |  | $ | 904 |  |
| Purchases of property, plant and equipment included in accounts payable |  | $ | 2,508 |  |  | $ | 1,037 |  |
| Adtran Networks common shares exchanged in acquisition |  | $ | — |  |  | $ | 565,491 |  |
| Adtran Networks options assumed in acquisition |  | $ | — |  |  | $ | 12,769 |  |
| Non-controlling interest related to Adtran Networks |  | $ | — |  |  | $ | 315,415 |  |

[0001193125-23-271842:8k_2_02:66]
Supplemental Information

[0001193125-23-271842:8k_2_02:67]
Reconciliation of Gross Profit and Gross Margin to

[0001193125-23-271842:8k_2_02:68]
Non-GAAP Gross Profit and Non-GAAP Gross Margin

[0001193125-23-271842:8k_2_02:69]
(Unaudited)

[0001193125-23-271842:8k_2_02:70]
(In
thousands)

[0001193125-23-271842:8k_2_02:71]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30,2023 |  |  | June 30,2023 |  |  | September 30,2022 |  |  | September 30,2023 |  |  | September 30,2022 |  |
| Total Revenue |  | $ | 272,331 |  |  | $ | 327,378 |  |  | $ | 340,709 |  |  | $ | 923,621 |  |  | $ | 667,265 |  |
| Cost of Revenue |  | $ | 198,094 |  |  | $ | 234,825 |  |  | $ | 237,682 |  |  | $ | 669,023 |  |  | $ | 447,416 |  |
| Acquisition-related expenses, amortization and adjustments(1) |  |  | (13,537 | ) |  |  | (33,439 | ) |  |  | (25,530 | ) |  |  | (79,554 | ) |  |  | (25,530 | ) |
| Stock-based compensation expense |  |  | (279 | ) |  |  | (335 | ) |  |  | (1,269 | ) |  |  | (854 | ) |  |  | (1,590 | ) |
| Pension adjustments |  |  | — |  |  |  | — |  |  |  | (59 | ) |  |  | — |  |  |  | (59 | ) |
| Restructuring expenses(2) |  |  | (21,630 | ) |  |  | — |  |  |  | — |  |  |  | (21,706 | ) |  |  | — |  |
| Integration expenses(3) |  |  | (154 | ) |  |  | — |  |  |  | — |  |  |  | (154 | ) |  |  | — |  |
| Non-GAAP Cost of Revenue |  | $ | 162,494 |  |  | $ | 201,051 |  |  | $ | 210,824 |  |  | $ | 566,755 |  |  | $ | 420,237 |  |
| Gross Profit |  | $ | 74,237 |  |  | $ | 92,553 |  |  | $ | 103,027 |  |  | $ | 254,598 |  |  | $ | 219,849 |  |
| Non-GAAP Gross Profit |  | $ | 109,837 |  |  | $ | 126,327 |  |  | $ | 129,885 |  |  | $ | 356,866 |  |  | $ | 247,028 |  |
| Gross Margin |  |  | 27.3 | % |  |  | 28.3 | % |  |  | 30.2 | % |  |  | 27.6 | % |  |  | 32.9 | % |
| Non-GAAP Gross Margin |  |  | 40.3 | % |  |  | 38.6 | % |  |  | 38.1 | % |  |  | 38.6 | % |  |  | 37.0 | % |

[0001193125-23-271842:8k_2_02:72]
| (1) | Includes intangible amortization of backlog, inventory fair value adjustments, developed technology, customer relationships, and trade names acquired in connection with business combinations. |

[0001193125-23-271842:8k_2_02:73]
| (2) | Includes expenses for restructuring program designed to optimize the assets and business processes following the business combination with Adtran Networks. These expenses include inventory write down charges totaling approximately $21.0 million incurred as a result of the exit from certain product lines in connection with the restructuring program. The restructuring program commenced upon the closing of the business combination with Adtran Networks and is expected to be completed in late 2024. |

[0001193125-23-271842:8k_2_02:74]
| (3) | Includes expenses related to the Company’s one-time integration bonus program in connection with synergy targets as a result of the business combination with Adtran Networks of which $73.4 thousand is stock compensation expense for the program. |

[0001193125-23-271842:8k_2_02:75]
Supplemental Information

[0001193125-23-271842:8k_2_02:76]
Reconciliation of Operating Expenses to Non-GAAP Operating Expenses

[0001193125-23-271842:8k_2_02:77]
(Unaudited)

[0001193125-23-271842:8k_2_02:78]
(In
thousands)

[0001193125-23-271842:8k_2_02:79]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30,2023 |  |  | June 30,2023 |  |  | September 30,2022 |  |  | September 30,2023 |  |  | September 30,2022 |  |
| Operating Expenses |  | $ | 125,659 |  |  | $ | 137,181 |  |  | $ | 134,076 |  |  | $ | 400,380 |  |  | $ | 242,833 |  |
| Acquisition-related expenses, amortization and adjustments |  |  | (4,534 | )(1) |  |  | (4,398 | )(6) |  |  | (14,780 | )(10) |  |  | (13,516 | )(13) |  |  | (19,233 | )(17) |
| Stock-based compensation expense |  |  | (3,251 | )(2) |  |  | (3,974 | )(7) |  |  | (10,862 | )(11) |  |  | (10,683 | )(14) |  |  | (14,322 | )(18) |
| Restructuring expenses |  |  | (3,243 | )(3) |  |  | (5,868 | )(8) |  |  | — |  |  |  | (11,472 | )(15) |  |  | (2 | ) |
| Integration expenses |  |  | (1,485 | )(4) |  |  | (563 | )(9) |  |  | — |  |  |  | (2,897 | )(16) |  |  | — |  |
| Pension adjustments |  |  | — |  |  |  | — |  |  |  | (185 | )(12) |  |  | — |  |  |  | (185 | )(12) |
| Deferred compensation adjustments(5) |  |  | 1,801 |  |  |  | 307 |  |  |  | 740 |  |  |  | 1,714 |  |  |  | 7,173 |  |
| Non-GAAP Operating Expenses |  | $ | 114,947 |  |  | $ | 122,685 |  |  | $ | 108,989 |  |  | $ | 363,526 |  |  | $ | 216,264 |  |

[0001193125-23-271842:8k_2_02:80]
| (1) | Includes intangible amortization of developed technology, customer relationships, and trade names acquired in connection with business combinations, of which $4.0 million is included in selling, general and administrative expenses and $0.5 million is included in research and development expenses on the condensed consolidated statements of loss. |

[0001193125-23-271842:8k_2_02:81]
| (2) | $2.4 million is included in selling, general and administrative expenses and $0.8 million is included in research and development expenses on the condensed consolidated statements of loss. |

[0001193125-23-271842:8k_2_02:82]
| (3) | $3.4 million is included in selling, general and administrative expenses and $(0.2) million is included in research and development expenses on the condensed consolidated statements of loss. |

[0001193125-23-271842:8k_2_02:83]
| (4) | $1.4 million is included in selling, general and administrative expenses and $0.1 million is included in research and development expenses on the condensed consolidated statements of loss. Includes fees relating to the expansion of internal controls at Adtran Networks and the implementation of the DPLTA. Additionally, includes expenses related to the Company’s one-time integration bonus program in connection with synergy targets as a result of the business combination with Adtran Networks of which $0.5 million is stock compensation expense for the program. |

[0001193125-23-271842:8k_2_02:84]
| (5) | Includes non-cash change in fair value of equity investments held in the ADTRAN Holdings, Inc. Deferred Compensation Program for Employees, all of which is included in selling, general and administrative expenses on the condensed consolidated statement of loss. |

[0001193125-23-271842:8k_2_02:85]
| (6) | Includes intangible amortization of developed technology, customer relationships, and trade names acquired in connection with business combinations, of which $3.9 million is included in selling, general and administrative expenses and $0.5 million is included in research and development expenses on the condensed consolidated statements of loss. |

[0001193125-23-271842:8k_2_02:86]
| (7) | $2.7 million is included in selling, general and administrative expenses and $1.3 million is included in research and development expenses on the condensed consolidated statements of loss. |

[0001193125-23-271842:8k_2_02:87]
| (8) | $1.4 million is included in selling, general and administrative expenses and $4.5 million is included in research and development expenses on the condensed consolidated statements of loss. |

[0001193125-23-271842:8k_2_02:88]
| (9) | $0.6 million is included in selling, general and administrative expenses on the condensed consolidated statements of loss. Includes fees relating to the expansion of internal controls at Adtran Networks and the implementation of the DPLTA. |

[0001193125-23-271842:8k_2_02:89]
| (10) | Includes intangible amortization of developed technology, customer relationships, and trade names acquired in connection with business combinations, of which $14.3 million is included in selling, general and administrative expenses and $0.5 million is included in research and development expenses on the condensed consolidated statements of loss. |

[0001193125-23-271842:8k_2_02:90]
| (11) | $9.2 million is included in selling, general and administrative expenses and $1.7 million is included in research and development expenses on the condensed consolidated statements of loss. |

[0001193125-23-271842:8k_2_02:91]
| (12) | $0.1 million is included in selling, general and administrative expenses and $0.1 million is included in research and development expenses on the condensed consolidated statements of loss. Includes amortization of actuarial losses related to the Company’s pension plan for employees in certain foreign countries. |

[0001193125-23-271842:8k_2_02:92]
| (13) | Includes intangible amortization of developed technology, customer relationships, and trade names acquired in connection with business combinations, of which $12.0 million is included in selling, general and administrative expenses and $1.5 million is included in research and development expenses on the condensed consolidated statements of loss. |

[0001193125-23-271842:8k_2_02:93]
| (14) | $7.6 million is included in selling, general and administrative expenses and $3.1 million is included in research and development expenses on the condensed consolidated statements of loss. |

[0001193125-23-271842:8k_2_02:94]
| (15) | $7.0 million is included in selling, general and administrative expenses and $4.5 million is included in research and development expenses on the condensed consolidated statements of loss. |

[0001193125-23-271842:8k_2_02:95]
| (16) | $2.8 million is included in selling, general and administrative expenses and $0.1 million is included in research and development expenses on the condensed consolidated statements of loss. Includes fees relating to the expansion of internal controls at Adtran Networks and the implementation of the DPLTA. Additionally, includes expenses related to the Company’s one-time integration bonus program in connection with synergy targets as a result of the business combination with Adtran Networks of which $0.5 million is stock compensation expense for the program. |

[0001193125-23-271842:8k_2_02:96]
| (17) | Includes intangible amortization of developed technology, customer relationships, and trade names acquired in connection with business combinations, of which $17.7 million is included in selling, general and administrative expenses and $1.5 million is included in research and development expenses on the condensed consolidated statements of loss. |

[0001193125-23-271842:8k_2_02:97]
| (18) | $11.4 million is included in selling, general and administrative expenses and $2.9 million is included in research and development expenses on the condensed consolidated statements of loss. |

[0001193125-23-271842:8k_2_02:98]
Supplemental Information

[0001193125-23-271842:8k_2_02:99]
Reconciliation of Operating Loss to Non-GAAP Operating (Loss) Income

[0001193125-23-271842:8k_2_02:100]
(Unaudited)

[0001193125-23-271842:8k_2_02:101]
(In
thousands)

[0001193125-23-271842:8k_2_02:102]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30,2023 |  |  | June 30,2023 |  |  | September 30,2022 |  |  | September 30,2023 |  |  | September 30,2022 |  |
| Operating Loss |  | $ | (89,296 | ) |  | $ | (44,628 | ) |  | $ | (48,018 | ) |  | $ | (183,656 | ) |  | $ | (39,953 | ) |
| Acquisition related expenses, amortization and adjustments(1) |  |  | 18,070 |  |  |  | 37,837 |  |  |  | 40,310 |  |  |  | 93,069 |  |  |  | 44,763 |  |
| Asset impairments(2) |  |  | — |  |  |  | — |  |  |  | 16,969 |  |  |  | — |  |  |  | 16,969 |  |
| Stock-based compensation expense |  |  | 3,530 |  |  |  | 4,309 |  |  |  | 12,131 |  |  |  | 11,537 |  |  |  | 15,912 |  |
| Pension adjustments |  |  | — |  |  |  | — |  |  |  | 244 |  |  |  | — |  |  |  | 244 |  |
| Restructuring expenses(3) |  |  | 24,873 |  |  |  | 5,868 |  |  |  | — |  |  |  | 33,178 |  |  |  | 2 |  |
| Integration expenses(4) |  |  | 1,639 |  |  |  | 563 |  |  |  | — |  |  |  | 3,051 |  |  |  | — |  |
| Deferred compensation adjustments(5) |  |  | (1,801 | ) |  |  | (307 | ) |  |  | (740 | ) |  |  | (1,714 | ) |  |  | (7,173 | ) |
| Goodwill impairment(6) |  |  | 37,874 |  |  |  | — |  |  |  | — |  |  |  | 37,874 |  |  |  | — |  |
| Non-GAAP Operating (Loss) Income |  | $ | (5,111 | ) |  | $ | 3,642 |  |  | $ | 20,896 |  |  | $ | (6,661 | ) |  | $ | 30,764 |  |

[0001193125-23-271842:8k_2_02:103]
| (1) | Includes intangible amortization of backlog, inventory fair value adjustments, developed technology, customer relationships, and trade names acquired in connection with business combinations. |

[0001193125-23-271842:8k_2_02:104]
| (2) | Includes impairment charges related to the abandonment of certain information technology projects due to the business combination. |

[0001193125-23-271842:8k_2_02:105]
| (3) | Includes expenses for restructuring program designed to optimize the assets and business processes following the business combination with Adtran Networks. These expenses include inventory write down charges totaling approximately $21.0 million incurred as a result of the exit from certain product lines in connection with the restructuring program. The restructuring program commenced upon the closing of the business combination with Adtran Networks and is expected to be completed in late 2024. |

[0001193125-23-271842:8k_2_02:106]
| (4) | Includes fees relating to the expansion of internal controls at Adtran Networks and the implementation of the DPTLA. Additionally, includes expenses related to the Company’s one-time integration bonus program in connection with synergy targets as a results of the business combination with Adtran Networks. |

[0001193125-23-271842:8k_2_02:107]
| (5) | Includes non-cash change in fair value of equity investments held in the ADTRAN Holdings, Inc. Deferred Compensation Program for Employees, all of which is included in selling, general and administrative expenses on the condensed consolidated statement of loss. |

[0001193125-23-271842:8k_2_02:108]
| (6) | Includes non-cash goodwill impairment charge related to our Services and Support reporting unit. The impairment primarily resulted from a decrease in projected revenue growth rates and EBITDA margins. |

[0001193125-23-271842:8k_2_02:109]
Supplemental Information

[0001193125-23-271842:8k_2_02:110]
Reconciliation of Other (Expense) Income to Non-GAAP Other (Expense) Income

[0001193125-23-271842:8k_2_02:111]
(Unaudited)

[0001193125-23-271842:8k_2_02:112]
(In
thousands)

[0001193125-23-271842:8k_2_02:113]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30,2023 |  |  | June 30,2023 |  |  | September 30,2022 |  |  | September 30,2023 |  |  | September 30,2022 |  |
| Interest and dividend income |  | $ | 521 |  |  | $ | 358 |  |  | $ | 347 |  |  | $ | 1,183 |  |  | $ | 768 |  |
| Interest expense |  |  | (4,507 | ) |  |  | (4,064 | ) |  |  | (1,303 | ) |  |  | (11,858 | ) |  |  | (1,427 | ) |
| Net investment (loss) gain |  |  | (1,443 | ) |  |  | 1,262 |  |  |  | (2,691 | ) |  |  | 1,071 |  |  |  | (10,752 | ) |
| Other income, net |  |  | 2,523 |  |  |  | 2,494 |  |  |  | 2,494 |  |  |  | 4,714 |  |  |  | 2,949 |  |
| Total Other (Expense) Income |  | $ | (2,906 | ) |  | $ | 50 |  |  | $ | (1,153 | ) |  | $ | (4,890 | ) |  | $ | (8,462 | ) |
| Deferred compensation adjustments(1) |  |  | 1,117 |  |  |  | (1,254 | ) |  |  | 1,124 |  |  |  | (1,387 | ) |  |  | 6,561 |  |
| Pension expense(2) |  |  | 7 |  |  |  | 6 |  |  |  | 81 |  |  |  | 20 |  |  |  | 255 |  |
| Non-GAAP Other (Expense) Income |  | $ | (1,782 | ) |  | $ | (1,198 | ) |  | $ | 52 |  |  | $ | (6,257 | ) |  | $ | (1,646 | ) |

[0001193125-23-271842:8k_2_02:114]
| (1) | Includes non-cash change in fair value of equity investments held in the ADTRAN Holdings, Inc. Deferred Compensation Program for Employees. |

[0001193125-23-271842:8k_2_02:115]
| (2) | Includes amortization of actuarial losses related to the Company’s pension plan for employees in certain foreign countries. |

[0001193125-23-271842:8k_2_02:116]
Supplemental Information

[0001193125-23-271842:8k_2_02:117]
Reconciliation of Net Loss inclusive of Non-Controlling Interest to

[0001193125-23-271842:8k_2_02:118]
Non-GAAP Net (Loss) Income inclusive of Non-Controlling
Interest

[0001193125-23-271842:8k_2_02:119]
(Unaudited)

[0001193125-23-271842:8k_2_02:120]
and

[0001193125-23-271842:8k_2_02:121]
Reconciliation of
Net Loss attributable to Non-Controlling Interest to

[0001193125-23-271842:8k_2_02:122]
Non-GAAP Net Loss (Income) attributable to Non-Controlling
Interest

[0001193125-23-271842:8k_2_02:123]
(Unaudited)

[0001193125-23-271842:8k_2_02:124]
and

[0001193125-23-271842:8k_2_02:125]
Reconciliation of
Net Loss attributable to ADTRAN Holdings, Inc. and

[0001193125-23-271842:8k_2_02:126]
Loss per Common Share attributable to ADTRAN Holdings, Inc. – Basic and
Diluted to

[0001193125-23-271842:8k_2_02:127]
Non-GAAP Net (Loss) Income attributable to ADTRAN Holdings, Inc. and

[0001193125-23-271842:8k_2_02:128]
Non-GAAP (Loss) Earnings per Common Share attributable to ADTRAN Holdings, Inc. – Basic and
Diluted

[0001193125-23-271842:8k_2_02:129]
(Unaudited)

[0001193125-23-271842:8k_2_02:130]
(In thousands, except per share amounts)

[0001193125-23-271842:8k_2_02:131]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30,2023 |  |  | June 30,2023 |  |  | September 30,2022 |  |  | September 30,2023 |  |  | September 30,2022 |  |
| Net Loss attributable to ADTRAN Holdings, Inc. |  | $ | (72,735 | ) |  | $ | (33,334 | ) |  | $ | (41,934 | ) |  | $ | (140,533 | ) |  | $ | (40,918 | ) |
| Plus: Net Loss attributable to non-controlling interest(1) |  |  | (2,914 | ) |  |  | (2,881 | ) |  |  | (2,925 | ) |  |  | (11,784 | ) |  |  | (2,925 | ) |
| Net Loss inclusive of non-controlling interest |  | $ | (75,649 | ) |  | $ | (36,215 | ) |  | $ | (44,859 | ) |  | $ | (152,317 | ) |  | $ | (43,843 | ) |
| Acquisition related expenses, amortization and adjustments |  |  | 18,070 |  |  |  | 37,837 |  |  |  | 40,310 |  |  |  | 93,069 |  |  |  | 44,763 |  |
| Asset impairments |  |  | — |  |  |  | — |  |  |  | 16,969 |  |  |  | — |  |  |  | 16,969 |  |
| Stock-based compensation expense |  |  | 3,530 |  |  |  | 4,309 |  |  |  | 12,131 |  |  |  | 11,537 |  |  |  | 15,912 |  |
| Valuation allowance |  |  | — |  |  |  | (185 | ) |  |  | 3,182 |  |  |  | (185 | ) |  |  | 15,550 |  |
| Deferred compensation adjustments(2) |  |  | (684 | ) |  |  | (1,561 | ) |  |  | 383 |  |  |  | (3,101 | ) |  |  | (612 | ) |
| Pension adjustments(3) |  |  | 7 |  |  |  | 6 |  |  |  | 325 |  |  |  | 20 |  |  |  | 499 |  |
| Restructuring expenses |  |  | 24,873 |  |  |  | 5,868 |  |  |  | — |  |  |  | 33,178 |  |  |  | 2 |  |
| Integration expenses |  |  | 1,639 |  |  |  | 563 |  |  |  | — |  |  |  | 3,051 |  |  |  | — |  |
| Goodwill impairment |  |  | 37,874 |  |  |  | — |  |  |  | — |  |  |  | 37,874 |  |  |  | — |  |
| Tax effect of adjustments to net loss |  |  | (23,366 | ) |  |  | (13,426 | ) |  |  | (16,245 | ) |  |  | (49,099 | ) |  |  | (17,430 | ) |
| Non-GAAP Net (Loss) Income inclusive of non-controlling interest |  | $ | (13,706 | ) |  | $ | (2,804 | ) |  | $ | 12,196 |  |  | $ | (25,973 | ) |  | $ | 31,810 |  |
| Less: Non-GAAP Net Loss (Income) attributable to non-controlling interest(1) |  |  | (2,914 | ) |  |  | (2,881 | ) |  |  | 4,486 |  |  |  | (10,255 | ) |  |  | 4,486 |  |
| Non-GAAP Net (Loss) Income attributable to ADTRAN Holdings, Inc. |  | $ | (10,792 | ) |  | $ | 77 |  |  | $ | 7,710 |  |  | $ | (15,718 | ) |  | $ | 27,324 |  |
| GAAP Net Loss attributable to non-controlling interest(1) |  | $ | (2,914 | ) |  | $ | (2,881 | ) |  | $ | (2,925 | ) |  | $ | (11,784 | ) |  | $ | (2,925 | ) |
| Acquisition related expenses, amortization and adjustments |  |  | — |  |  |  | — |  |  |  | 7,120 |  |  |  | 1,457 |  |  |  | 7,120 |  |
| Restructuring expenses |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 29 |  |  |  | — |  |
| Integration expenses |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 6 |  |  |  | — |  |
| Stock-based compensation expense |  |  | — |  |  |  | — |  |  |  | 231 |  |  |  | 37 |  |  |  | 231 |  |
| Pension adjustments |  |  | — |  |  |  | — |  |  |  | 60 |  |  |  | — |  |  |  | 60 |  |
| Non-GAAP Net Loss (Income) attributable to non-controlling interest(1) |  | $ | (2,914 | ) |  | $ | (2,881 | ) |  | $ | 4,486 |  |  | $ | (10,255 | ) |  | $ | 4,486 |  |
| Weighted average shares outstanding – basic |  |  | 78,389 |  |  |  | 78,366 |  |  |  | 73,036 |  |  |  | 78,378 |  |  |  | 57,175 |  |
| Weighted average shares outstanding – diluted |  |  | 78,389 |  |  |  | 78,366 |  |  |  | 73,036 |  |  |  | 78,378 |  |  |  | 57,175 |  |
| Loss per common share attributable to ADTRAN Holdings, Inc. – basic |  | $ | (0.93 | ) |  | $ | (0.43 | ) |  | $ | (0.57 | ) |  | $ | (1.79 | ) |  | $ | (0.72 | ) |
| Loss per common share attributable to ADTRAN Holdings, Inc. – diluted |  | $ | (0.93 | ) |  | $ | (0.43 | ) |  | $ | (0.57 | ) |  | $ | (1.79 | ) |  | $ | (0.72 | ) |
| Non-GAAP (Loss) Earnings per common share attributable to ADTRAN – basic |  | $ | (0.14 | ) |  | $ | 0.00 |  |  | $ | 0.11 |  |  | $ | (0.20 | ) |  | $ | 0.48 |  |
| Non-GAAP (Loss) Earnings per common share attributable to ADTRAN – diluted |  | $ | (0.14 | ) |  | $ | 0.00 |  |  | $ | 0.11 |  |  | $ | (0.20 | ) |  | $ | 0.48 |  |

[0001193125-23-271842:8k_2_02:132]
| (1) | Represents the non-controlling interest portion of the Company’s ownership of Adtran Networks pre-DPLTA and the annual recurring compensation earned by redeemable non-controlling interests and accrued by the Company post-DPLTA. |

[0001193125-23-271842:8k_2_02:133]
| (2) | Includes non-cash change in fair value of equity investments held in deferred compensation plans offered to certain employees. |

[0001193125-23-271842:8k_2_02:134]
| (3) | Includes amortization of actuarial losses related to the Company’s pension plan for employees in certain foreign countries. |
