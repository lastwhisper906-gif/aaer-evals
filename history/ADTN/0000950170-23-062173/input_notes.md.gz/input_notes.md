# ADTN notes — 0000950170-23-062173


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000950170-23-062173:notes:1]
[same as prior period, unchanged from 0000950170-23-042449:notes:1]

[0000950170-23-062173:notes:2]
ADTRAN Holdings, Inc. (“ADTRAN” or the “Company”) is a leading global provider of networking and communications platforms, software, systems and services focused on the broadband access market, serving a diverse domestic and international customer base in multiple countries that includes large, medium and small Service Providers, alternative Service Providers, such as utilities, municipalities and fiber overbuilders, cable/MSOs, SMBs and distributed enterprises. Our innovative solutions and services enable voice, data, video and internet-communications across a variety of network infrastructures and are currently in use by millions worldwide. We support our customers through our direct global sales organization and our distribution networks. Our success depends upon our ability to increase unit volume and market share through the introduction of new products and succeeding generations of products having optimal selling prices and increased functionality as compared to both the prior generation of a product and to the products of competitors in order to gain market share. To service our customers and grow revenue, we are continually conducting research and developing new products addressing customer needs and testing those products for the specific requirements of the particular customers. We offer a broad portfolio of flexible software and hardware network solutions and services that enable Service Providers to meet today’s service demands, while enabling them to transition to the fully converged, scalable, highly-automated, cloud-controlled voice, data, internet and video network of the future. In addition to our global headquarters in Huntsville, Alabama, and our European headquarters in Munich, Germany, we have sales and research and development facilities in strategic global locations.

[0000950170-23-062173:notes:3]
ADTRAN Holdings, Inc. solely owns ADTRAN, Inc. and is the majority shareholder of Adtran Networks (formerly ADVA Optical Networking SE). ADTRAN is a leading global provider of open, disaggregated networking and communications solutions. Adtran Networks is a global provider of network solutions for data, storage, voice and video services. The combined technology portfolio can best address current and future requirements, especially regarding the convergence of solutions at the network edge.

[0000950170-23-062173:notes:4]
Domination and Profit and Loss Transfer Agreement

[0000950170-23-062173:notes:5]
[same as prior period, unchanged from 0000950170-23-042449:notes:6]

[0000950170-23-062173:notes:6]
[same as prior period, unchanged from 0000950170-23-042449:notes:7]

[0000950170-23-062173:notes:7]
Pursuant to the terms of the DPLTA, each Adtran Networks shareholder (other than the Company) has received an offer to elect either (1) to remain an Adtran Networks shareholder and receive from us an Annual Recurring Compensation payment, or (2) to receive Exit Compensation plus guaranteed interest. The guaranteed interest under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid. The guaranteed interest rate is 5.0% plus a variable component (according to the German Civil Code) that was 3.12% as of September 30, 2023. Assuming all the minority holders of currently outstanding Adtran Networks shares were to elect the second option, we would be obligated to make aggregate Exit Compensation payments, including guaranteed interest, of approximately €325.3 million or approximately $344.2 million, based on an exchange rate as of September 30, 2023 and reflecting interest accrued through September 30, 2023 during the pendency of the appraisal proceedings discussed below. Shareholders electing the first option of Annual Recurring Compensation may later elect the second option. The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that have been initiated in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger).

[0000950170-23-062173:notes:8]
We are also obligated to absorb any annual net loss of Adtran Networks under the DPLTA. Additionally, our obligation to pay Annual Recurring Compensation under the DPLTA is a continuing payment obligation, which will amount to approximately €10.6 million or $11.2 million (based on the current exchange rate) per year assuming none of the minority Adtran Networks shareholders were to elect Exit Compensation. The foregoing amounts do not reflect any potential increase in payment obligations that we may have depending on the outcome of ongoing appraisal proceedings in Germany. During the three and nine months ended September 30, 2023, we accrued $2.9 million and $8.6 million in Annual Recurring Compensation, which was reflected as a reduction to retained (deficit) earnings, respectively.

[0000950170-23-062173:notes:9]
On October 18, 2022, the Company's Board of Directors authorized the Company to purchase additional shares of Adtran Networks through open market purchases not to exceed 15,346,544 shares. For the three and nine months ended September 30, 2023, less than 1 thousand shares and 64 thousand shares, respectively, of Adtran Networks stock was tendered to the Company and Exit Compensation payments of approximately €8 thousand and €1.1 million, respectively, or approximately $9 thousand and $1.2 million, respectively, based on an exchange rate as of September 30, 2023, were paid to Adtran Networks shareholders.

[0000950170-23-062173:notes:10]
As of September 30, 2023, and as of the date of issuance of these financial statements, the Company does not have sufficient liquidity to meet payment obligations under the DPLTA pertaining to Exit Compensation assuming a substantial majority of Adtran Networks shareholders elect such option in the current period. We believe the probability that a substantial majority of Adtran Networks shareholders elect to receive Exit Compensation in the next twelve months is remote based on the diverse base of shareholders that must make this election on an individual shareholder basis, the current ongoing appraisal proceedings involving a dispute on the value of the Exit Compensation which is expected to take 24-36 months to resolve, the current guaranteed Annual Recurring Compensation payment plus the interest earned on such shares during the ongoing appraisal proceedings, and the current trading value of Adtran Networks SE shares.

[0000950170-23-062173:notes:11]
Therefore, we believe that our cash and cash equivalents, investments, working capital management initiatives and access to funds under the Wells Fargo credit facility, including additional funding provided for under the First Amendment to the Wells Fargo credit facility that was signed on August 9, 2023, (described below) will be adequate to meet our operating and capital needs and our obligations under the DPLTA, including potential Exit Compensation, for at least the next 12 months, from the issuance of these financial statements, although we have suspended dividend payments and are implementing a business efficiency program, which includes, but is not limited to, planned reductions in our operating expenses and a site consolidation plan. In connection with the site consolidation plan, we are also exploring a potential sale of our headquarters in Huntsville. We may also need to further reduce capital expenditures and/or take other steps to preserve working capital in order to ensure that we can meet such needs and obligations. See Note 22, Subsequent Events, for additional information regarding  the suspension of the quarterly dividend.

[0000950170-23-062173:notes:12]
On July 18, 2022, ADTRAN Holdings, Inc. and ADTRAN, Inc., as the borrower, entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (the “Credit Agreement”). The Credit Agreement allowed for borrowings of up to $100.0 million in aggregate principal amount, but the borrowings increased to up to $400.0 million in aggregate principal amount upon the DPLTA becoming effective on January 16, 2023.

[0000950170-23-062173:notes:13]
On August 9, 2023, the Company, its wholly-owned direct subsidiary, ADTRAN, Inc., the lenders party thereto and the Administrative Agent entered into a First Amendment to the Credit Agreement (the “First Amendment” and, together with the Credit Agreement, the “Credit Facility”). The Credit Facility matures in July 2027; however, the Company has an option to request extensions subject to customary conditions. See Note 12, Revolving Credit Agreements, for additional information regarding the terms of the Credit Facility.

[0000950170-23-062173:notes:14]
[same as prior period, unchanged from 0000950170-23-042449:notes:16]

[0000950170-23-062173:notes:15]
[same as prior period, unchanged from 0000950170-23-042449:notes:17]

[0000950170-23-062173:notes:16]
[same as prior period, unchanged from 0000950170-23-042449:notes:18]

[0000950170-23-062173:notes:17]
[same as prior period, unchanged from 0000950170-23-042449:notes:19]

[0000950170-23-062173:notes:18]
[same as prior period, unchanged from 0000950170-23-042449:notes:20]

[0000950170-23-062173:notes:19]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenue and expense during the reporting period. Significant estimates include allowance for credit losses on accounts receivable and contract assets, excess and obsolete inventory reserves, warranty reserves, customer rebates, determination and accrual of the deferred revenue related to performance obligations under contracts with customers, estimated costs to complete obligations associated with deferred and accrued revenues and network installations, estimated income tax provision and income tax contingencies, fair value of stock-based compensation, assessment of goodwill and other intangibles for impairment, estimated lives of intangible assets, estimates of intangible assets upon measurement, estimated pension liability and fair value of investments and estimated contingent liabilities. Actual amounts could differ significantly from these estimates.

[0000950170-23-062173:notes:20]
We assessed certain accounting matters that generally require consideration of forecasted financial information in context with the information reasonably available to us and the unknown future impacts of supply chain constraints, inflationary pressures, the energy crisis, currency fluctuations and political tensions as of September 30, 2023, and through the date of this report. The accounting matters assessed included, but were not limited to, the allowance for credit losses, stock-based compensation, carrying value of goodwill, intangibles and other long-lived assets, financial assets, valuation allowances for tax assets, revenue recognition and costs of revenue. Future conditions related to supply chain constraints, inflationary pressures, the energy crisis, rising interest rates, instability in the financial services industry, currency fluctuations and political tensions could result in further impacts to the Company's consolidated financial statements in future reporting periods.

[0000950170-23-062173:notes:21]
[same as prior period, unchanged from 0000950170-23-042449:notes:23]

[0000950170-23-062173:notes:22]
As of September 30, 2023 and December 31, 2022, the non-controlling Adtran Networks stockholders’ equity ownership percentage in Adtran Networks was approximately 34.6% and 34.7%, respectively.

[0000950170-23-062173:notes:23]
[same as prior period, unchanged from 0000950170-23-042449:notes:25]

[0000950170-23-062173:notes:24]
[same as prior period, unchanged from 0000950170-23-042449:notes:26]

[0000950170-23-062173:notes:25]
[same as prior period, unchanged from 0000950170-23-042449:notes:27]

[0000950170-23-062173:notes:26]
Recently Adopted Accounting Pronouncements

[0000950170-23-062173:notes:27]
In October 2021, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update ("ASU") 2021-08, Business Combinations (Topic 805) Accounting for Contract Assets and Contract Liabilities from Contracts with Customers, which would require an acquirer to recognize and measure acquired contract assets and contract liabilities in a manner consistent with how the acquiree recognized and measured them in its pre-acquisition financial statements in accordance with Topic 606, Revenue Recognition. The Company early adopted ASU 2021-08 on July 1, 2022 and the standard was applied retrospectively beginning with January 1, 2022.

[0000950170-23-062173:notes:28]
[same as prior period, unchanged from 0000950170-23-042449:notes:30]

[0000950170-23-062173:notes:29]
[same as prior period, unchanged from 0000950170-23-042449:notes:31]


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000950170-23-062173:notes:30]
[same as prior period, unchanged from 0000950170-23-042449:notes:32]

[0000950170-23-062173:notes:31]
[same as prior period, unchanged from 0000950170-23-042449:notes:33]

[0000950170-23-062173:notes:32]
[same as prior period, unchanged from 0000950170-23-042449:notes:34]

[0000950170-23-062173:notes:33]
[same as prior period, unchanged from 0000950170-23-042449:notes:35]

[0000950170-23-062173:notes:34]
ADTRAN, Inc. and Adtran Networks became subsidiaries of ADTRAN Holdings, Inc. as a result of the Business Combination. ADTRAN, Inc. was determined to be the accounting acquirer of Adtran Networks based on ADTRAN, Inc. shareholders’ majority equity stake in the combined company, the composition of the board of directors and senior management of the combined company, among other factors. The Business Combination with Adtran Networks has been accounted for using the acquisition method of accounting as per the provisions of Accounting Standards Codification 805, “Business Combinations” (“ASC 805”). The Business Combination Agreement used a fixed exchange ratio of Company Common Stock for Adtran Networks shares of common stock, which resulted in a 36.0% equity stake for Adtran Networks stockholders and a 64.0% equity stake for ADTRAN,  Inc. stockholders in the post-closing combined company (calculated on a fully diluted basis and utilizing the tender of 65.43% of Adtran Networks’ current issued and outstanding share capital) as of July 15, 2022. Therefore, ADTRAN, Inc. shareholders continued to hold a majority interest in the combined company following the completion of the Business Combination. Additionally, following the transaction, the Board of Directors was comprised of six members from ADTRAN, Inc. and three members from Adtran Networks; the ADTRAN, Inc. chief executive officer became and continues to act as the chairman of the Board of Directors and the former Adtran Networks chief executive officer became the vice chairman of the Board of Directors. Additionally, the ADTRAN, Inc. chief executive officer and ADTRAN, Inc. chief financial officer held these positions within the combined company immediately following the completion of the Business Combination. Based upon these and other considerations as outlined in ASC 805, ADTRAN, Inc. represented the accounting acquirer.

[0000950170-23-062173:notes:35]
[same as prior period, unchanged from 0000950170-23-042449:notes:37]

[0000950170-23-062173:notes:36]
[same as prior period, unchanged from 0000950170-23-042449:notes:38]

[0000950170-23-062173:notes:37]
[same as prior period, unchanged from 0000950170-23-042449:notes:39]

[0000950170-23-062173:notes:38]
[same as prior period, unchanged from 0000950170-23-042449:notes:40]

[0000950170-23-062173:notes:39]
[same as prior period, unchanged from 0000950170-23-042449:notes:41]

[0000950170-23-062173:notes:40]
[same as prior period, unchanged from 0000950170-23-042449:notes:42]

[0000950170-23-062173:notes:41]
The following table summarizes the final purchase price allocation for each major class of assets acquired and liabilities assumed in the Business Combination (in thousands):

[0000950170-23-062173:notes:42]
[same as prior period, unchanged from 0000950170-23-042449:notes:44]

[0000950170-23-062173:notes:43]
The fair value of the assets acquired included accounts receivable of $114.7 million and other receivables of $1.5 million. The unpaid principal balance under these receivables was $118.5 million and $1.5 million, respectively. The difference between the fair value and the unpaid principal balance primarily represents amounts determined to be uncollectible.

[0000950170-23-062173:notes:44]
[same as prior period, unchanged from 0000950170-23-042449:notes:46]

[0000950170-23-062173:notes:45]
[same as prior period, unchanged from 0000950170-23-042449:notes:47]

[0000950170-23-062173:notes:46]
[same as prior period, unchanged from 0000950170-23-042449:notes:48]

[0000950170-23-062173:notes:47]
[same as prior period, unchanged from 0000950170-23-042449:notes:49]

[0000950170-23-062173:notes:48]
[same as prior period, unchanged from 0000950170-23-042449:notes:50]

[0000950170-23-062173:notes:49]
[same as prior period, unchanged from 0000950170-23-042449:notes:51]

[0000950170-23-062173:notes:50]
The Company has included the financial results of Adtran Networks in its consolidated financial statements since July 15, 2022, the acquisition date. The net revenue from the Adtran Networks business for the three and nine months ended September 30, 2023, was $158.4 million and $537.5 million, respectively, and the net loss from the Adtran Networks business for the three and nine months ended September 30, 2023, was $38.8 million and $79.4 million, respectively, which are included in the Company’s Consolidated Statement of Loss. There was no net loss attributable to non-controlling interest from the Adtran Networks business for the three months ended September 30, 2023. The net loss attributable to non-controlling interest from the Adtran Networks business for the nine months ended September 30, 2023 was $3.2 million. For the three and nine months ended September 30, 2023, we recognized $2.9 million and $8.6 million, respectively, representing the portion of the annual recurring cash compensation to the non-controlling shareholders accrued during such periods, which will be paid after the ordinary general shareholders' meeting of Adtran Networks beginning in 2024. See Note 1 and Note 20 for additional information on RNCI and the annual dividend.

[0000950170-23-062173:notes:51]
As of September 30, 2023, the Company has incurred $26.2 million of transaction costs related to the Business Combination. During the three and nine months ended September 30, 2023, $8 thousand and $0.1 million of transaction costs were incurred, respectively. During the three and nine months ended September 30, 2022, $10.6 million and $13.3 million of transaction costs were incurred, respectively. These transaction costs are recorded in selling, general and administrative expenses in the Consolidated Statements of Loss.

[0000950170-23-062173:notes:52]
[same as prior period, unchanged from 0000950170-23-042449:notes:54]

[0000950170-23-062173:notes:53]
[same as prior period, unchanged from 0000950170-23-042449:notes:55]

[0000950170-23-062173:notes:54]
[same as prior period, unchanged from 0000950170-23-042449:notes:56]

[0000950170-23-062173:notes:55]
|  | Three Months Ended |  |  | Nine Months Ended |  |
| (In thousands) | September 30, 2022 |  |  | September 30, 2022 |  |
| Revenue | $ | 368,192 |  |  | $ | 1,053,510 |  |
| Net loss | $ | (48,084 | ) |  | $ | (60,494 | ) |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000950170-23-062173:notes:56]
[same as prior period, unchanged from 0000950170-23-042449:notes:58]

[0000950170-23-062173:notes:57]
[same as prior period, unchanged from 0000950170-23-042449:notes:59]

[0000950170-23-062173:notes:58]
[same as prior period, unchanged from 0000950170-23-042449:notes:60]

[0000950170-23-062173:notes:59]
[same as prior period, unchanged from 0000950170-23-042449:notes:61]

[0000950170-23-062173:notes:60]
[same as prior period, unchanged from 0000950170-23-042449:notes:62]

[0000950170-23-062173:notes:61]
[same as prior period, unchanged from 0000950170-23-042449:notes:63]

[0000950170-23-062173:notes:62]
Prior to the Business Combination with Adtran Networks on July 15, 2022, ADTRAN reported revenue across the following three categories: (1) Access & Aggregation, (2) Subscriber Solutions & Experience and (3) Traditional & Other Products. Following the Business Combination with Adtran Networks, we have recast these revenues such that ADTRAN’s former Access & Aggregation revenue is combined with a portion of the applicable Adtran Networks SE solutions to create Access & Aggregation Solutions; ADTRAN’s former Subscriber Solutions & Experience revenue is combined with a portion of the applicable Adtran Networks solutions to create Subscriber Solutions; and the revenue from Traditional & Other products is now included in the applicable Access & Aggregation Solutions or Subscriber Solutions category. Optical Networking Solutions is a new revenue category added to represent a meaningful portion of Adtran Networks' portfolio.

[0000950170-23-062173:notes:63]
[same as prior period, unchanged from 0000950170-23-042449:notes:65]

[0000950170-23-062173:notes:64]
[same as prior period, unchanged from 0000950170-23-042449:notes:66]

[0000950170-23-062173:notes:65]
[same as prior period, unchanged from 0000950170-23-042449:notes:67]

[0000950170-23-062173:notes:66]
[same as prior period, unchanged from 0000950170-23-042449:notes:68]

[0000950170-23-062173:notes:67]
|  |  | Three Months Ended |  |
|  |  | September 30, 2023 |  |  | September 30, 2022 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Optical Networking Solutions |  | $ | 94,592 |  |  | $ | 21,608 |  |  | $ | 116,200 |  |  | $ | 103,011 |  |  | $ | 15,834 |  |  | $ | 118,845 |  |
| Access & Aggregation Solutions |  |  | 81,051 |  |  |  | 13,595 |  |  |  | 94,646 |  |  |  | 76,591 |  |  |  | 11,598 |  |  |  | 88,189 |  |
| Subscriber Solutions |  |  | 52,921 |  |  |  | 8,564 |  |  |  | 61,485 |  |  |  | 125,338 |  |  |  | 8,337 |  |  |  | 133,675 |  |
| Total |  | $ | 228,564 |  |  | $ | 43,767 |  |  | $ | 272,331 |  |  | $ | 304,940 |  |  | $ | 35,769 |  |  | $ | 340,709 |  |

[0000950170-23-062173:notes:68]
|  |  | Nine Months Ended |  |
|  |  | September 30, 2023 |  |  | September 30, 2022 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Optical Networking Solutions |  | $ | 342,390 |  |  | $ | 64,562 |  |  | $ | 406,952 |  |  | $ | 103,011 |  |  | $ | 15,834 |  |  | $ | 118,845 |  |
| Access & Aggregation Solutions |  |  | 254,868 |  |  |  | 39,315 |  |  |  | 294,183 |  |  |  | 243,396 |  |  |  | 34,877 |  |  |  | 278,273 |  |
| Subscriber Solutions |  |  | 196,726 |  |  |  | 25,760 |  |  |  | 222,486 |  |  |  | 252,899 |  |  |  | 17,248 |  |  |  | 270,147 |  |
| Total |  | $ | 793,984 |  |  | $ | 129,637 |  |  | $ | 923,621 |  |  | $ | 599,306 |  |  | $ | 67,959 |  |  | $ | 667,265 |  |

[0000950170-23-062173:notes:69]
The aggregate amount of transaction price allocated to remaining performance obligations that have not been satisfied as of September 30, 2023 and December 31, 2022 related to contractual maintenance agreements, contractual SaaS and subscription services, and hardware contracts that exceed one year in duration amounted to $314.0 million and $277.2 million, respectively. As of September 30, 2023, approximately 68.6% is expected to be recognized over the next 12 months and the remainder recognized thereafter. The majority of the Company's remaining performance obligations as of September 30, 2023 are related to contracts or orders that have an original expected duration of one year or less, for which the Company is electing to utilize the practical expedient available within the guidance, and are excluded from the transaction price related to these future obligations. The Company will generally satisfy the remaining performance obligations as we transfer control of the products ordered or services to our customers, excluding maintenance services, which are satisfied over time.

[0000950170-23-062173:notes:70]
[same as prior period, unchanged from 0000950170-23-042449:notes:72]

[0000950170-23-062173:notes:71]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | September 30, 2023 |  |  | December 31, 2022 |  |
| Accounts receivable, net |  | $ | 229,333 |  |  | $ | 279,435 |  |
| Contract assets(1) |  | $ | 888 |  |  | $ | 1,852 |  |
| Unearned revenue |  | $ | 49,832 |  |  | $ | 41,193 |  |
| Non-current unearned revenue |  | $ | 23,501 |  |  | $ | 19,239 |  |

[0000950170-23-062173:notes:72]
[same as prior period, unchanged from 0000950170-23-042449:notes:74]

[0000950170-23-062173:notes:73]
The Company is party to a receivables purchase agreement with a third-party financial institution (the “Factor”), which accelerates receivable collection and helps to better manage cash flow. Total accounts receivables sold for the nine months ended September 30, 2023 and the twelve months ended December 31, 2022, totaled $17.8 million and $14.9 million, respectively, of which $1.4 million was retained by the Factor in the reserve account. The balance in the reserve account is included in other assets on the Condensed Consolidated Balance Sheets. As of September 30, 2023 and December 31, 2022, the Company had an allowance for credit losses related to factored accounts receivable totaling less than $0.1 million. The cost of the receivables purchase agreement is included in interest expense in the Condensed Consolidated Statements of Loss and totaled $0.3 million and $0.9 million for the three and nine months ended September 30, 2023, respectively.

[0000950170-23-062173:notes:74]
Of the outstanding unearned revenue balances as of December 31, 2022, $6.1 million and $31.3 million were recognized as revenue during the three and nine months ended September 30, 2023, respectively. Of the $17.7 million of outstanding unearned revenue balances as of December 31, 2021, $2.8 million and $12.3 million were recognized as revenue during the three and nine months ended September 30, 2022, respectively.

[0000950170-23-062173:notes:75]
[same as prior period, unchanged from 0000950170-23-042449:notes:77]

[0000950170-23-062173:notes:76]
[same as prior period, unchanged from 0000950170-23-042449:notes:78]

[0000950170-23-062173:notes:77]
As of September 30, 2023 and December 31, 2022, the Company’s outstanding accounts receivable balance was $229.3 million and $279.4 million, respectively. The Company assessed the need for an allowance for credit losses related to its outstanding accounts receivable using the historical loss-rate method, as well as assessing asset-specific risks. The assessment of asset-specific risks included the evaluation of relevant available information, from internal and external sources, relating to current conditions that may affect a customer’s ability to pay, such as the customer’s current financial condition, credit rating by geographic location, as provided by a third party and/or by customer, if needed, and the overall macro-economic conditions in which the customer operates. The Company pooled assets by geographic location to determine if an allowance should be applied to its accounts receivable balance, assessing the specific country risk rating and overall economics of that particular country. If elevated risk existed, or customer specific risk indicated the accounts receivable balance was at risk, the Company further analyzed the need for an allowance related to specific accounts receivable balances. Additionally, the Company determined that significant changes to customer country risk rating from period-to-period and from the end of the prior year to the end of the current quarter would require further review and analysis by the Company.

[0000950170-23-062173:notes:78]
The allowance for credit losses was $15 thousand and $49 thousand as of September 30, 2023 and December 31, 2022, respectively, related to accounts receivable.

[0000950170-23-062173:notes:79]
[same as prior period, unchanged from 0000950170-23-042449:notes:81]

[0000950170-23-062173:notes:80]
The Company records contract assets when it has recognized revenue but has not yet billed the customer. As of September 30, 2023 and December 31, 2022, the Company’s outstanding contract asset balance was $0.9 million and $1.9 million, respectively, which is included in other receivables on the Consolidated Balance Sheets. The Company assessed the need for an allowance for credit losses related to its outstanding contract assets using the historical loss-rate method, as well as asset-specific risks. The Company’s historical losses related to contract assets receivable have been immaterial as evidenced by historical write-offs due to collectability. Asset-specific risk included the evaluation of relevant available information, from internal and external sources, relating to current conditions that may affect a customer’s ability to pay once invoiced, such as the customer’s financial condition, credit rating by geographic location as provided by a third party and/or by customer, if needed, and the overall macro-economic conditions in which the customer operates. The Company pooled assets by geographic location to determine if an allowance should be applied to its contract asset balance, assessing the specific country risk rating and the overall economics of that particular country. If elevated risk existed, or customer specific risk indicated the contract balance was at risk, the Company further analyzed the need for an allowance related to specific customer balances. Additionally, the Company determined that significant changes to customer country risk rating from period-to-period and from the end of the prior year to the end of the current quarter would be subject to further review and analysis by the Company.

[0000950170-23-062173:notes:81]
No allowance for credit losses was recorded for the three months ended September 30, 2023 and 2022 related to contract assets.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0000950170-23-062173:notes:82]
[same as prior period, unchanged from 0000950170-23-042449:notes:84]

[0000950170-23-062173:notes:83]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Optical Networking Solutions |  | $ | 116,200 |  |  | $ | 118,845 |  |  | $ | 406,952 |  |  | $ | 118,845 |  |
| Access & Aggregation Solutions |  |  | 94,646 |  |  |  | 88,189 |  |  |  | 294,183 |  |  |  | 278,273 |  |
| Subscriber Solutions |  |  | 61,485 |  |  |  | 133,675 |  |  |  | 222,486 |  |  |  | 270,147 |  |
| Total |  | $ | 272,331 |  |  | $ | 340,709 |  |  | $ | 923,621 |  |  | $ | 667,265 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000950170-23-062173:notes:84]
[same as prior period, unchanged from 0000950170-23-042449:notes:86]

[0000950170-23-062173:notes:85]
The Company’s effective tax rate changed from a benefit of 8.8% of pre-tax loss for the three months ended September 30, 2022, to a benefit of 18.0% of pre-tax loss for the three months ended September 30, 2023 and changed from a benefit of 9.4% of pre-tax loss for the nine months ended September 30, 2022, to a benefit of 19.2% of pre-tax loss for the nine months ended September 30, 2023. The change in the effective tax rate for the three and nine months ended September 30, 2023, was driven primarily by a change in our estimated tax rate as a result of the closing of the Business Combination with Adtran Networks during the third quarter of 2022, as well as the release of our domestic valuation allowance during the fourth quarter of 2022, with exception for certain research and development credits in a particular state in which we do not have sufficient activity to utilize them prior to expiration.

[0000950170-23-062173:notes:86]
During the second quarter of 2023, the Company concluded a review with the Internal Revenue Services of its amended tax returns previously filed related to refund claims arising from the Company’s request to revoke an IRC Section 59(e) election made on the Company’s originally filed 2018 U.S. federal tax return. The Company had previously received an unfavorable response to its Private Letter Ruling request, in which it requested the Commissioner's approval for revoking the election. As a result of that review, and after taking into consideration other factors, including weighing the potential benefits with projected costs to litigate and the hazards of litigation, management has concluded that it will not pursue the claims any further. As a result, the Company has removed the previously recorded receivable of $15.2 million and related research and development credit carryforward of $1.8 million, as well as the offsetting uncertain tax position reserves against them of $17.0 million during the second quarter of 2023.

[0000950170-23-062173:notes:87]
The Company continually reviews the adequacy of its valuation allowance and recognizes the benefits of deferred tax assets only as the assessment indicates that it is more likely than not that the deferred tax assets will be recognized in accordance with ASC 740, Income Taxes. As of September 30, 2023, the Company had net deferred tax assets totaling $57.3 million, and a valuation allowance totaling $5.0 million against those deferred tax assets. The remaining $52.3 million in deferred tax assets are primarily related to capitalized R&D expenses in the U.S., partially offset by net purchase price intangibles from the Business Combination closed with Adtran Networks during the third quarter of 2022. Our assessment of the realizability of our deferred tax assets includes the evaluation of historical operating results, as well as the evaluation of evidence which requires significant judgment, including the evaluation of our three-year cumulative income position, future taxable income projections and tax planning strategies. Should management’s conclusion change in the future and an additional valuation allowance, or a partial or full release of the valuation allowance becomes necessary, it may have a material effect on our consolidated financial statements.

[0000950170-23-062173:notes:88]
[same as prior period, unchanged from 0000950170-23-042449:notes:90]

[0000950170-23-062173:notes:89]
|  |  | As of September 30, 2023 |  |
| (In thousands) |  | Deferred Tax Assets (Liabilities) |  |  | Valuation Allowance |  |  | Deferred Tax Assets (Liabilities), net |  |
| Domestic |  | $ | 84,274 |  |  | $ | (3,177 | ) |  | $ | 81,097 |  |
| International |  |  | (26,975 | ) |  |  | (1,839 | ) |  |  | (28,814 | ) |
| Total |  | $ | 57,299 |  |  | $ | (5,016 | ) |  | $ | 52,283 |  |

[0000950170-23-062173:notes:90]
[same as prior period, unchanged from 0000950170-23-042449:notes:92]


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000950170-23-062173:notes:91]
[same as prior period, unchanged from 0000950170-23-042449:notes:93]

[0000950170-23-062173:notes:92]
For the three months ended September 30, 2023 and 2022, stock-based compensation expense was $4.2 million and $12.1 million, respectively, and for the nine months ended September 30, 2023 and 2022, stock-based compensation expense was $12.2 million and $15.9 million, respectively.

[0000950170-23-062173:notes:93]
[same as prior period, unchanged from 0000950170-23-042449:notes:95]

[0000950170-23-062173:notes:94]
The following table summarizes the RSUs and restricted stock outstanding as of December 31, 2022 and September 30, 2023 and the changes that occurred during the nine months ended September 30, 2023:

[0000950170-23-062173:notes:95]
|  |  | Number of Shares(in thousands) |  |  | Weighted Avg. Grant Date Fair Value(per share) |  |
| Unvested RSUs and restricted stock outstanding, December 31, 2022 |  |  | 1,086 |  |  | $ | 17.54 |  |
| RSUs and restricted stock granted |  |  | 1,484 |  |  | $ | 16.58 |  |
| RSUs and restricted stock vested |  |  | (56 | ) |  | $ | 20.37 |  |
| RSUs and restricted stock forfeited |  |  | (51 | ) |  | $ | 16.42 |  |
| Unvested RSUs and restricted stock outstanding, September 30, 2023 |  |  | 2,463 |  |  | $ | 17.01 |  |

[0000950170-23-062173:notes:96]
During the nine months ended September 30, 2023, the Company granted 0.9 million performance-based PSUs to its executive officers and certain employees. The grant-date fair value of these performance-based awards was based on the closing price of the Company’s stock on the date of grant. These awards vest over either a two or three-year period, subject to the grantee’s continued employment, with the ability to earn shares in a range of 0% to either 100% or 150% of the awarded number of PSUs based on the achievement of defined performance targets. Equity-based compensation expense and liabilities with respect to these awards may be adjusted over the vesting period to reflect the probability of achievement of performance targets defined in the award agreements.

[0000950170-23-062173:notes:97]
[same as prior period, unchanged from 0000950170-23-042449:notes:99]

[0000950170-23-062173:notes:98]
As of September 30, 2023, total unrecognized compensation expense related to non-vested market-based RSUs and restricted stock was approximately $19.1 million, which will be recognized over the remaining weighted-average period of 2.2 years. There was $11.3 million of unrecognized compensation expense related to unvested 2023 performance-based PSUs, which will be recognized over the remaining requisite service period of 2.3 years if achievement of the performance obligation becomes probable. Unrecognized compensation expense will be adjusted for actual forfeitures.

[0000950170-23-062173:notes:99]
As of September 30, 2023, 2.0 million shares were available for issuance under stockholder-approved equity plans.

[0000950170-23-062173:notes:100]
[same as prior period, unchanged from 0000950170-23-042449:notes:102]

[0000950170-23-062173:notes:101]
The following table summarizes the ADTRAN Holdings, Inc. stock options outstanding as of December 31, 2022 and September 30, 2023 and the changes that occurred during the nine months ended September 30, 2023:

[0000950170-23-062173:notes:102]
|  |  | Number of Stock Options(in thousands) |  |  | Weighted Avg. Exercise Price(per share) |  |  | Weighted Avg. Remaining Contractual Life(in years) |  |  | Aggregate Intrinsic Value(in thousands) |  |
| Stock options outstanding, December 31, 2022 |  |  | 3,148 |  |  | $ | 14.37 |  |  |  | 3.42 |  |  | $ | 16,251 |  |
| Stock options granted |  |  | 7 |  |  | $ | 12.17 |  |  |  |  |  |  |  |
| Stock options exercised |  |  | (8 | ) |  | $ | 8.72 |  |  |  |  |  |  |  |
| Stock options forfeited |  |  | (40 | ) |  | $ | 11.93 |  |  |  |  |  |  |  |
| Stock options expired |  |  | (33 | ) |  | $ | 16.44 |  |  |  |  |  |  |  |
| Stock options outstanding, September 30, 2023 |  |  | 3,074 |  |  | $ | 14.39 |  |  |  | 2.68 |  |  | $ | 736 |  |
| Stock options exercisable, September 30, 2023 |  |  | 1,691 |  |  | $ | 15.88 |  |  |  | 1.23 |  |  | $ | 556 |  |

[0000950170-23-062173:notes:103]
As of September 30, 2023, there was $5.2 million of unrecognized compensation expense related to stock options which will be recognized over the remaining weighted-average period of 1.9 years.

[0000950170-23-062173:notes:104]
Pursuant to the Business Combination, which closed on July 15, 2022, Adtran Networks stock option holders were entitled to have their Adtran Networks stock options assumed by ADTRAN Holdings, Inc. (applying the exchange ratio in the Business Combination Agreement), thereafter representing options to acquire stock of ADTRAN Holdings, Inc. The maximum number of shares of ADTRAN Holdings, Inc. stock potentially issuable upon such assumption was 2.3 million shares. The period in which such options could be assumed ended on July 22, 2022. A total of 2.1 million shares of ADTRAN Holdings, Inc. stock could be issued pursuant to the exercise of the assumed Adtran Networks options. The determination of the fair value of stock options assumed by ADTRAN Holdings, Inc. was estimated using the Monte Carlo method and is affected by its stock price, as well as assumptions regarding a number of complex and subjective variables that may have a significant impact on the fair value estimate. The stock option pricing model requires the use of several assumptions that impact the fair value estimate. These variables include, but are not limited to, the volatility of the Company's stock price and employee exercise behaviors.

[0000950170-23-062173:notes:105]
[same as prior period, unchanged from 0000950170-23-042449:notes:107]

[0000950170-23-062173:notes:106]
The aggregate intrinsic value of stock options represents the total pre-tax intrinsic value (the difference between the Company's closing stock price on the last trading day of the quarter and the exercise price, multiplied by the number of in-the-money options) that would have been received by the option holders had all option holders exercised their options on September 30, 2023. The amount of aggregate intrinsic value was $0.7 million as of September 30, 2023, which will change based on the fair market value of the Company's stock. The total pre-tax intrinsic value of options exercised during the nine months ended September 30, 2023 was $50 thousand.

[0000950170-23-062173:notes:107]
[same as prior period, unchanged from 0000950170-23-042449:notes:109]

[0000950170-23-062173:notes:108]
The following table summarizes the Adtran Networks stock options outstanding as of December 31, 2022 and September 30, 2023 and the changes that occurred during the nine months ended September 30, 2023:

[0000950170-23-062173:notes:109]
|  |  | Number ofOptions(In thousands) |  |  | WeightedAverageExercise Price(Per share) |  |  | Weighted Avg.RemainingContractual Lifein Years |  |  | AggregateIntrinsic Value(In thousands) |  |
| Stock options outstanding, December 31, 2022 |  |  | 81 |  |  | $ | 8.58 |  |  |  | 4.00 |  |  | $ | 1,222 |  |
| Stock options exercised |  |  | (13 | ) |  | $ | 8.22 |  |  |  |  |  |  |  |
| Stock options forfeited |  |  | (9 | ) |  | $ | 10.58 |  |  |  |  |  |  |  |
| Stock options expired |  |  | (1 | ) |  | $ | 9.20 |  |  |  |  |  |  |  |
| Stock options outstanding, September 30, 2023 |  |  | 58 |  |  | $ | 8.18 |  |  |  | 3.39 |  |  | $ | 746 |  |
| Stock options exercisable, September 30, 2023 |  |  | 12 |  |  | $ | 6.03 |  |  |  | 1.48 |  |  | $ | 182 |  |

[0000950170-23-062173:notes:110]
As of September 30, 2023, there was $0.1 million of unrecognized compensation expense related to Adtran Networks stock options which will be recognized over the remaining weighted-average period of 3.4 years.

[0000950170-23-062173:notes:111]
[same as prior period, unchanged from 0000950170-23-042449:notes:113]

[0000950170-23-062173:notes:112]
The aggregate intrinsic value of Adtran Networks stock options represents the total pre-tax intrinsic value (the difference between Adtran Networks closing stock price on the last trading day of the quarter and the exercise price, multiplied by the number of in-the-money options) that would have been received by the option holders had all option holders exercised their options on September 30, 2023. The amount of aggregate intrinsic value was $0.7 million as of September 30, 2023 and will change based on the fair market value of Adtran Networks stock. The total pre-tax intrinsic value of Adtran Networks options exercised during the nine months ended September 30, 2023 was $0.2 million.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000950170-23-062173:notes:113]
6. INVESTMENTS

[0000950170-23-062173:notes:114]
Debt Securities and Other Investments

[0000950170-23-062173:notes:115]
The following debt securities and other investments were included on the Condensed Consolidated Balance Sheets and recorded at fair value as of December 31, 2022:

[0000950170-23-062173:notes:116]
|  |  | As of December 31, 2022 |  |
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 2,538 |  |  | $ | 5 |  |  | $ | (81 | ) |  | $ | 2,462 |  |
| Municipal fixed-rate bonds |  |  | 185 |  |  |  | — |  |  |  | (5 | ) |  |  | 180 |  |
| Asset-backed bonds |  |  | 818 |  |  |  | 1 |  |  |  | (24 | ) |  |  | 795 |  |
| Mortgage/Agency-backed bonds |  |  | 1,853 |  |  |  | — |  |  |  | (105 | ) |  |  | 1,748 |  |
| U.S. government bonds |  |  | 3,870 |  |  |  | 3 |  |  |  | (188 | ) |  |  | 3,685 |  |
| Foreign government bonds |  |  | 407 |  |  |  | — |  |  |  | (24 | ) |  |  | 383 |  |
| Available-for-sale debt securities held at fair value |  | $ | 9,671 |  |  | $ | 9 |  |  | $ | (427 | ) |  | $ | 9,253 |  |

[0000950170-23-062173:notes:117]
The Company did not have any debt securities and other investments as of September 30, 2023.

[0000950170-23-062173:notes:118]
Realized gains and losses on sales of debt securities are computed under the specific identification method. The following table presents the gross realized gains and losses related to its debt securities:

[0000950170-23-062173:notes:119]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Gross realized gain on debt securities |  | $ | 5 |  |  | $ | 1 |  |  | $ | 9 |  |  | $ | 14 |  |
| Gross realized loss on debt securities |  |  | (317 | ) |  |  | (116 | ) |  |  | (355 | ) |  |  | (242 | ) |
| Total loss recognized, net |  | $ | (312 | ) |  | $ | (115 | ) |  | $ | (346 | ) |  | $ | (228 | ) |

[0000950170-23-062173:notes:120]
Income generated from available-for-sale debt securities was recorded as interest and dividend income in the Condensed Consolidated Statements of Loss. No allowance for credit losses was recorded for the nine months ended September 30, 2023 and 2022 related to available-for-sale debt securities. The Company’s investment policy provides limitations for issuer concentration, which limits, at the time of purchase, the concentration in any one issuer to 5.0% of the market value of its total investment portfolio. The Company did not purchase any available-for-sale debt security with credit deterioration during the nine months ended September 30, 2023.

[0000950170-23-062173:notes:121]
Realized and unrealized gains and losses related to marketable equity securities were as follows:

[0000950170-23-062173:notes:122]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Unrealized gain (loss) on equity securities held |  | $ | (1,130 | ) |  | $ | (1,217 | ) |  | $ | 1,404 |  |  | $ | (8,849 | ) |
| Realized gain (loss) on equity securities sold |  |  | (1 | ) |  |  | (1,358 | ) |  |  | 13 |  |  |  | (1,675 | ) |
| Total gain (loss) recognized, net |  | $ | (1,131 | ) |  | $ | (2,575 | ) |  | $ | 1,417 |  |  | $ | (10,524 | ) |

[0000950170-23-062173:notes:123]
Income generated from marketable equity securities was recorded as interest and dividend income in the Condensed Consolidated Statements of Loss. U.S. GAAP establishes a three-level valuation hierarchy based upon observable and unobservable inputs for fair value measurement of financial instruments:

[0000950170-23-062173:notes:124]
 Level 1 – Observable outputs; values based on unadjusted quoted prices for identical assets or liabilities in an active market;

[0000950170-23-062173:notes:125]
 Level 2 – Significant inputs that are observable; values based on quoted prices in markets that are not active or model inputs that are observable either directly or indirectly;

[0000950170-23-062173:notes:126]
 Level 3 – Significant unobservable inputs; values based on prices or valuation techniques that require inputs that are both unobservable and significant to the overall fair value measurement. These inputs could include information supplied by investees.

[0000950170-23-062173:notes:127]
The Company’s cash equivalents and investments held at fair value are categorized into this hierarchy as follows:

[0000950170-23-062173:notes:128]
|  |  |  |  |  | Fair Value Measurements as of September 30, 2023 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket for IdenticalAssets (Level 1) |  |  | SignificantOtherObservableInputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Money market funds |  |  | 5,245 |  |  |  | 5,245 |  |  |  | — |  |  |  | — |  |
| Commercial paper |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total cash equivalents |  | $ | 5,245 |  |  | $ | 5,245 |  |  | $ | - |  |  | $ | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 815 |  |  |  | 815 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 24,364 |  |  |  | 24,364 |  |  |  | — |  |  |  | — |  |
| Total long-term investments |  | $ | 25,179 |  |  | $ | 25,179 |  |  | $ | — |  |  | $ | — |  |
| Total |  | $ | 30,424 |  |  | $ | 30,424 |  |  | $ | — |  |  | $ | — |  |

[0000950170-23-062173:notes:129]
|  |  |  |  |  | Fair Value Measurements as of December 31, 2022 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket for IdenticalAssets (Level 1) |  |  | SignificantOtherObservableInputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 228 |  |  | $ | 228 |  |  | $ | — |  |  | $ | — |  |
| Total cash equivalents |  | $ | 228 |  |  | $ | 228 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  | $ | 2,462 |  |  | $ | — |  |  | $ | 2,462 |  |  | $ | — |  |
| Municipal fixed-rate bonds |  |  | 180 |  |  |  | — |  |  |  | 180 |  |  |  | — |  |
| Asset-backed bonds |  |  | 795 |  |  |  | — |  |  |  | 795 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 1,748 |  |  |  | — |  |  |  | 1,748 |  |  |  | — |  |
| U.S. government bonds |  |  | 3,685 |  |  |  | 3,685 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 383 |  |  |  | — |  |  |  | 383 |  |  |  | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 810 |  |  |  | 810 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 22,942 |  |  |  | 22,942 |  |  |  | — |  |  |  | — |  |
| Total short-term and long-term investments |  | $ | 33,005 |  |  | $ | 27,437 |  |  | $ | 5,568 |  |  | $ | - |  |
| Total |  | $ | 33,233 |  |  | $ | 27,665 |  |  | $ | 5,568 |  |  | $ | — |  |

[0000950170-23-062173:notes:130]
The fair value of its Level 2 securities is calculated using a weighted average market price for each security. Market prices are obtained from a variety of industry standard data providers, large financial institutions and other third-party sources. These multiple market prices are used as inputs into a distribution-curve-based algorithm to determine the daily market value of each security.


## us-gaap:InventoryDisclosureTextBlock

[0000950170-23-062173:notes:131]
[same as prior period, unchanged from 0000950170-23-042449:notes:136]

[0000950170-23-062173:notes:132]
[same as prior period, unchanged from 0000950170-23-042449:notes:137]

[0000950170-23-062173:notes:133]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | September 30, 2023 |  |  | December 31, 2022 |  |
| Raw materials |  | $ | 156,287 |  |  | $ | 186,346 |  |
| Work in process |  |  | 15,648 |  |  |  | 12,087 |  |
| Finished goods |  |  | 202,036 |  |  |  | 229,098 |  |
| Total inventory, net |  | $ | 373,971 |  |  | $ | 427,531 |  |

[0000950170-23-062173:notes:134]
Inventory reserves are established for estimated excess and obsolete inventory equal to the difference between the cost of the inventory and the estimated net realizable value of the inventory based on estimated reserve percentages, which considers historical usage, known trends, inventory age and market conditions. As of September 30, 2023 and December 31, 2022, inventory reserves were $86.3 million and $57.0 million, respectively.

[0000950170-23-062173:notes:135]
In connection with the Company’s restructuring efforts, during the quarter ended September 30, 2023, management determined that there would be a discontinuation of product lines in the Network solutions segment and, as a result, wrote-down related inventories of $21.0 million and is included in cost of revenue in the Condensed Consolidated Statements of Loss. There was no write-down of inventory during the three and nine months ended September 30, 2022.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000950170-23-062173:notes:136]
[same as prior period, unchanged from 0000950170-23-042449:notes:140]

[0000950170-23-062173:notes:137]
[same as prior period, unchanged from 0000950170-23-042449:notes:141]

[0000950170-23-062173:notes:138]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | September 30, 2023 |  |  | December 31, 2022 |  |
| Engineering and other equipment |  | $ | 179,049 |  |  | $ | 170,785 |  |
| Building |  |  | 85,966 |  |  |  | 82,932 |  |
| Computer hardware and software |  |  | 97,192 |  |  |  | 80,455 |  |
| Building and land improvements |  |  | 51,284 |  |  |  | 47,861 |  |
| Furniture and fixtures |  |  | 23,686 |  |  |  | 22,403 |  |
| Land |  |  | 5,325 |  |  |  | 5,364 |  |
| Total property, plant and equipment |  |  | 442,502 |  |  |  | 409,800 |  |
| Less: accumulated depreciation |  |  | (323,879 | ) |  |  | (299,101 | ) |
| Total property, plant and equipment, net |  | $ | 118,623 |  |  | $ | 110,699 |  |

[0000950170-23-062173:notes:139]
Long-lived assets used in operations are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable and the undiscounted cash flows estimated to be generated by the asset are less than the asset’s carrying value. In connection with the planned integration of information technology following the Business Combination, we determined that certain projects no longer fit our needs. As a result, the Company recognized impairment charges of $17.0 million during the three and nine months ended September 30, 2022 related to capitalized implementation costs for a cloud computing arrangement. The impairment charges were determined based on actual costs incurred. During the three and nine months ended September 30, 2023, no impairment charges were recognized.

[0000950170-23-062173:notes:140]
Depreciation expense was $7.4 million and $7.1 million for the three months ended September 30, 2023 and 2022, respectively, and $22.6 million and $12.6 million for the nine months ended September 30, 2023 and 2022, respectively, which is recorded in cost of revenue, selling, general and administrative expenses and research and development expenses in the Condensed Consolidated Statements of Loss.


## us-gaap:GoodwillDisclosureTextBlock

[0000950170-23-062173:notes:141]
[same as prior period, unchanged from 0000950170-23-042449:notes:145]

[0000950170-23-062173:notes:142]
The changes in the carrying amount of goodwill for the nine months ended September 30, 2023 are as follows:

[0000950170-23-062173:notes:143]
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| As of December 31, 2022 |  | $ | 298,280 |  |  | $ | 83,444 |  |  | $ | 381,724 |  |
| Goodwill impairment |  |  | — |  |  |  | (37,500 | ) |  |  | (37,500 | ) |
| Foreign currency translation adjustments |  |  | (3,873 | ) |  |  | (1,268 | ) |  |  | (5,141 | ) |
| As of September 30, 2023 |  | $ | 294,407 |  |  | $ | 44,676 |  |  | $ | 339,083 |  |

[0000950170-23-062173:notes:144]
Related to the Business Combination with Adtran Networks, the Company recognized $350.5 million of goodwill upon the closing of the Business Combination on July 15, 2022. Goodwill represents the excess purchase price over the fair value of net assets acquired. The Company performed an impairment assessment as of September 30, 2023, prior to our October 1, 2023 annual measurement date. The Company’s policy is to assess the realizability of its goodwill, and to evaluate such assets for impairment whenever events or changes in circumstances indicate that the carrying amount of such assets (or group of assets) may not be recoverable. During the third quarter of 2023, qualitative factors such as a decrease in the Company's market capitalization and long-term projections, triggered a quantitative impairment assessment for our reporting units. The Company determined the fair value of each reporting unit using a combination of an income approach and a market based peer group analysis. It was determined that the decreases in projected future cash flows, discount rates, overall macroeconomic conditions, as well as the decrease in our market capitalization applied in the valuation, were required to align with market-based assumptions and company-specific risk, which resulted in lower fair values of the Services & Support reporting unit. The Company determined upon its quantitative impairment assessment to recognize a $37.9 million non-cash goodwill impairment charge for the Services & Support reporting unit. The Company does not expect the impairment charge for the Services & Support Unit to result in any future cash expenditures. The Company did not recognize any impairment charges for the Network Solutions reporting unit as of September 30, 2023.

[0000950170-23-062173:notes:145]
Subsequent to September 30, 2023, the Company has experienced volatility in its stock price which reduced the market value of the Company’s common stock as of this filing. The Company will continue to monitor its stock price, operating results and other macroeconomic factors to determine if there is further indication of a sustained decline in fair value requiring an event driven assessment of the recoverability of its goodwill within the fourth quarter of 2023.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0000950170-23-062173:notes:146]
[same as prior period, unchanged from 0000950170-23-042449:notes:149]

[0000950170-23-062173:notes:147]
[same as prior period, unchanged from 0000950170-23-042449:notes:150]

[0000950170-23-062173:notes:148]
|  |  |  |  | As of September 30, 2023 |  |  | As of December 31, 2022 |  |
| (In thousands) | Weighted Average Useful Life(in years) |  |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Net Book Value |  |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Net Book Value |  |
| Customer relationships |  | 10.9 |  |  | $ | 53,247 |  |  | $ | (14,490 | ) |  | $ | 38,757 |  |  | $ | 55,517 |  |  | $ | (12,772 | ) |  | $ | 42,745 |  |
| Backlog |  | 1.6 |  |  |  | 55,017 |  |  |  | (49,061 | ) |  |  | 5,956 |  |  |  | 55,782 |  |  |  | (22,725 | ) |  |  | 33,057 |  |
| Developed technology |  | 8.5 |  |  |  | 316,083 |  |  |  | (49,944 | ) |  |  | 266,139 |  |  |  | 320,364 |  |  |  | (21,856 | ) |  |  | 298,508 |  |
| Licensed technology |  | 9.0 |  |  |  | 5,900 |  |  |  | (3,633 | ) |  |  | 2,267 |  |  |  | 5,900 |  |  |  | (3,141 | ) |  |  | 2,759 |  |
| Licensing agreements |  | 8.5 |  |  |  | 560 |  |  |  | (353 | ) |  |  | 207 |  |  |  | 560 |  |  |  | (298 | ) |  |  | 262 |  |
| Patents |  | 7.3 |  |  |  | 500 |  |  |  | (483 | ) |  |  | 17 |  |  |  | 500 |  |  |  | (431 | ) |  |  | 69 |  |
| Trade names |  | 3.0 |  |  |  | 28,461 |  |  |  | (13,109 | ) |  |  | 15,352 |  |  |  | 29,066 |  |  |  | (5,255 | ) |  |  | 23,811 |  |
| Total |  |  |  | $ | 459,768 |  |  | $ | (131,073 | ) |  | $ | 328,695 |  |  | $ | 467,689 |  |  | $ | (66,478 | ) |  | $ | 401,211 |  |

[0000950170-23-062173:notes:149]
Intangible assets are reviewed for impairment whenever events and circumstances indicate impairment may have occurred. The Company assessed impairment triggers related to intangible assets during each financial period in 2023 and 2022. During the third quarter of 2023, the Company's market capitalization and long-term projections decreased which triggered a reassessment of our estimated future undiscounted cash flows.  The Company determined that our estimated future undiscounted cash flows exceeded the carrying amount of intangible assets as of September 30, 2023. No quantitative impairment test of long-lived assets was performed as of September 30, 2022. No impairment losses of intangible assets were recorded during the three and nine months ended September 30, 2023 and 2022.

[0000950170-23-062173:notes:150]
Amortization expense was $16.5 million and $20.4 million in the three months ended September 30, 2023 and 2022, respectively, and $68.8 million and $22.2 million in the nine months ended September 30, 2023 and 2022, respectively and was included in cost of revenue, selling, general and administrative expenses and research and development expenses in the Condensed Consolidated Statements of Loss.

[0000950170-23-062173:notes:151]
[same as prior period, unchanged from 0000950170-23-042449:notes:154]

[0000950170-23-062173:notes:152]
|  |  | As of |  |
| (In thousands) |  | September 30, 2023 |  |
| 2023 |  | $ | 13,770 |  |
| 2024 |  |  | 56,800 |  |
| 2025 |  |  | 45,504 |  |
| 2026 |  |  | 42,290 |  |
| 2027 |  |  | 40,941 |  |
| Thereafter |  |  | 129,390 |  |
| Total |  | $ | 328,695 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000950170-23-062173:notes:153]
[same as prior period, unchanged from 0000950170-23-042449:notes:156]

[0000950170-23-062173:notes:154]
The Company has certain forward rate agreements to hedge foreign currency exposure of expected future cash flows in foreign currency. The Company does not hold or issue derivative instruments for trading or other speculative purposes. Derivatives are initially recognized at fair value on the date a derivative contract is entered into and are subsequently re-measured to their fair value at the end of each reporting period. All changes in the fair value of derivative instruments are recognized as other income (expense) in the Consolidated Statements of Loss and are classified as Level II under the fair value hierarchy. The derivative instruments are not subject to master netting agreements and are not offset in the Consolidated Balance Sheets. We are exposed to risk from credit-related losses resulting from nonperformance by counterparties to our financial instruments. We perform credit evaluations of our counterparties under forward exchange contracts and expect all counterparties to meet their obligations. We have not experienced credit losses from our counterparties. As of September 30, 2023, the Company had 49 forward rate contracts outstanding.

[0000950170-23-062173:notes:155]
[same as prior period, unchanged from 0000950170-23-042449:notes:158]

[0000950170-23-062173:notes:156]
On November 3, 2022, the Company entered into a Euro/U.S. forward contract arrangement (the “Initial Forward”) with Wells Fargo Bank, N.A. (the “Hedge Counterparty”). The Initial Forward, which is governed by the provisions of an ISDA Master Agreement (including schedules thereto and transaction confirmations that supplement such agreement) entered into between the Company and the Hedge Counterparty, enables the Company to convert a portion of its Euro denominated payment obligations under the DPLTA into U.S. Dollars. Under the Initial Forward, the Company agreed to exchange an aggregate notional amount of €160.0 million for U.S. dollars at a daily fixed forward rate ranging from $0.98286 to $1.03290. The aggregate amount of €160.0 million is divided into eight quarterly tranches of €20.0 million, which commenced in the fourth quarter of 2022. During the nine months ended September 30, 2023, the Company settled three €20.0 million forward contract tranches and the remaining amount will be divided into five quarterly tranches of €20.0 million. The Company, at its sole discretion, may exchange all or part of each tranche on any given day within the applicable quarter; provided, however, that it must exchange the full tranche by the end of such quarter. The Initial Forward may be accelerated or terminated early for a number of reasons, including but not limited to (i) non-payment by the Company or the Hedge Counterparty, (ii) breach of representation or warranty or covenant by either party or (iii) insolvency or bankruptcy of either party.

[0000950170-23-062173:notes:157]
On March 21, 2023, the Company entered into a Euro/U.S. dollar forward contract arrangement (the “Forward”) with the Hedge Counterparty. Under the Forward, which is governed by the provisions of an ISDA Master Agreement (including schedules thereto and transaction confirmations that supplement such agreement) entered into between the Company and the Hedge Counterparty, the Company will exchange an aggregate notional amount of €160.0 million for U.S. dollars at a daily fixed forward rate of $1.085 per €1.00 in average. During the nine months ended September 30, 2023, the Company settled three €20.0 million forward contract tranches, and the remaining amount will be divided into five quarterly tranches of €20.0 million. These forward contracts were executed on March 21, 2023 (to sell EUR/buy USD) and were entered into for the purpose of unwinding the Initial Forward (to buy EUR/sell USD). The drawdown dates of the Initial Forward are set to the same date as the maturity of the new offsetting Forward.

[0000950170-23-062173:notes:158]
The fair values of the Company's derivative instruments recorded in the Condensed Consolidated Balance Sheet as of September 30, 2023 and December 31, 2022 were as follows:

[0000950170-23-062173:notes:159]
| (In thousands) |  | Balance Sheet Location |  | September 30, 2023 |  |  | December 31, 2022 |  |
| Derivatives Not Designated as Hedging Instruments (Level 2): |  |  |  |  |  |  |  |  |
| Foreign exchange contracts – derivative assets |  | Other receivables |  | $ | 7,530 |  |  | $ | 11,992 |  |
| Foreign exchange contracts – derivative liabilities |  | Accounts payable |  | $ | (10 | ) |  | $ | (633 | ) |
| Total derivatives |  |  |  | $ | 7,520 |  |  | $ | 11,359 |  |

[0000950170-23-062173:notes:160]
The change in the fair values of the Company's derivative instruments recorded in the Condensed Consolidated Statements of Loss during the three and nine months ended September 30, 2023 and 2022 were as follows:

[0000950170-23-062173:notes:161]
|  |  |  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  |  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | Income StatementLocation |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Derivatives Not Designated as Hedging Instruments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Other income, net |  | $ | 1,012 |  |  | $ | — |  |  | $ | 1,076 |  |  | $ | — |  |


## us-gaap:DebtDisclosureTextBlock

[0000950170-23-062173:notes:162]
12. REVOLVING CREDIT AGREEMENTS

[0000950170-23-062173:notes:163]
The carrying amounts of the Company's current and non-current revolving credit agreements in its Condensed Consolidated Balance Sheets were as follows:

[0000950170-23-062173:notes:164]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | September 30, 2023 |  |  | December 31, 2022 |  |
| New Nord/LB revolving line of credit |  | $ | 10,580 |  |  | $ | — |  |
| Nord/LB revolving line of credit |  |  | — |  |  |  | 16,091 |  |
| Syndicated credit agreement working capital line of credit |  |  | — |  |  |  | 10,727 |  |
| DZ bank revolving line of credit |  |  | — |  |  |  | 9,118 |  |
| Total current revolving credit agreements |  | $ | 10,580 |  |  | $ | 35,936 |  |

[0000950170-23-062173:notes:165]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | September 30, 2023 |  |  | December 31, 2022 |  |
| Wells Fargo credit agreement |  | $ | 200,000 |  |  | $ | 60,000 |  |
| Total non-current revolving credit agreement |  | $ | 200,000 |  |  | $ | 60,000 |  |

[0000950170-23-062173:notes:166]
As of September 30, 2023, the weighted average interest rate on our revolving credit agreements was 7.11%.

[0000950170-23-062173:notes:167]
Wells Fargo Credit Agreement

[0000950170-23-062173:notes:168]
On July 18, 2022, ADTRAN Holdings, Inc. and ADTRAN, Inc., as the borrower, entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (the “Credit Agreement”). The Credit Agreement initially allowed for borrowings of up to $100.0 million in aggregate principal amount, but the permitted borrowings increased to up to $400.0 million in aggregate principal amount upon the DPLTA becoming effective on January 16, 2023.

[0000950170-23-062173:notes:169]
On August 9, 2023, (the "First Amendment Effective Date") the Company, its wholly-owned direct subsidiary, ADTRAN, Inc., the lenders party thereto and the Administrative Agent entered into a First Amendment to the Credit Agreement (the “First Amendment” and together with the Credit Agreement, the "Credit Facility").

[0000950170-23-062173:notes:170]
The First Amendment, provides for, among other things, a new $50.0 million delayed draw term loan (“DDTL”), which is available for borrowing in the event of the purchase by the Company of at least sixty percent (60.0%) of the outstanding shares of Adtran Networks that were not owned by the Company as of the First Amendment Effective Date (such event, a “Springing Covenant Event”). Proceeds of the DDTL may only be used to repurchase minority shares of Adtran Networks. The DDTL remains available for borrowing from the occurrence of a Springing Covenant Event through the period that is three consecutive fiscal quarters thereafter.

[0000950170-23-062173:notes:171]
The First Amendment further added additional financial flexibility by amending the $30.0 million external debt capped basket to be an unlimited amount and permitting, subject to certain requirements, the incurrence of convertible indebtedness by the Company in an aggregate principal amount of up to $172.5 million. Any such convertible indebtedness must be incurred in pro forma compliance with the financial covenants in the Credit Agreement, unsecured and otherwise rank junior to borrowings under the Credit Agreement, and have a stated maturity date of at least 91 days after the latest scheduled maturity date of loans and commitments under the Credit Agreement. Net cash proceeds from any incurrence of convertible indebtedness must be used to repurchase minority shares of Adtran Networks or repay revolver borrowings under the Credit Agreement.

[0000950170-23-062173:notes:172]
As of September 30, 2023, ADTRAN, Inc.’s borrowings under the revolving line of credit were $200.0 million. As of September 30, 2023, there were no borrowings under the DDTL. The Credit Facility matures in July 2027; however, the Company has an option to request extensions subject to customary conditions. In addition, we may issue up to $25.0 million in letters of credit against our $400.0 million total facility. As of September 30, 2023, we had a total of $2.2 million in letters of credit under ADTRAN, Inc. outstanding against our eligible borrowings, leaving a net amount of $197.8 million available for future borrowings. Any future credit extensions

[0000950170-23-062173:notes:173]
under the Credit Agreement are subject to customary conditions precedent. The proceeds of any loans are expected to be used for general corporate purposes and to pay a portion of the Exchange Offer consideration.

[0000950170-23-062173:notes:174]
Revolving Line of Credit Interest Rate

[0000950170-23-062173:notes:175]
All U.S. borrowings under the revolving line of credit (other than swingline loans, which bear interest at the Base Rate (as defined below)) bear interest, at the Company’s option, at a rate per annum equal to (A)(i) the highest of (a) the federal funds rate (i.e., for any day, the rate per annum equal to the weighted average of the rates on overnight federal funds transactions with members of the Federal Reserve System, as published by the Federal Reserve Bank of New York on the business day next succeeding such day) plus ½ of 1.0%, (b) the prime commercial lending rate of the Administrative Agent, as established from time to time at its principal U.S. office (which such rate is an index or base rate and will not necessarily be its lowest or best rate charged to its customers or other banks), and (c) the daily Adjusted Term SOFR (as defined in the Credit Agreement) for a one-month tenor plus 1.0%, plus (ii) the applicable rate, ranging from 0.65% to 1.65% (the “Base Rate”), or (B) the sum of the Adjusted Term SOFR (as defined in the Credit Agreement) plus the applicable rate, ranging from 1.65% to 2.65%, provided that such sum is subject to a 0.0% floor (such loans utilizing this interest rate, “SOFR Loans”). All E.U. borrowings under the Credit Agreement (other than swingline loans) bear interest at a rate per annum equal to the sum of the Euro Interbank Offered Rate as administered by the European Money Markets Institute (or a comparable or successor administrator approved by the Administrative Agent) plus the applicable rate, ranging from 1.75% to 2.75%, provided that such sum is subject to a 0.0% floor (such loans utilizing this interest rate, “EURIBOR Loans”). The applicable rate is based on the consolidated net leverage ratio of the Company and its subsidiaries as determined pursuant to the terms of the Credit Agreement. Default interest is 2.0% per annum in excess of the rate otherwise applicable in the case of any overdue principal or any other overdue amount.

[0000950170-23-062173:notes:176]
In addition to paying interest on outstanding principal under the Credit Agreement, the Company is required to pay a commitment fee to the lenders under the Credit Agreement in respect of unutilized revolving loan commitments and an additional commitment ticking fee at a rate ranging from 0.20% to 0.25% per annum on the average daily unused portion of the revolving credit commitment of each lender until the earliest of (i) the date of the Senior Credit Facilities Increase, (ii) the Company’s voluntary termination of the credit facility commitment, and (iii) December 31, 2023. The Company is also required to pay a participation fee to the Administrative Agent for the account of each lender with respect to the Company’s participation in letters of credit at the then applicable rate for SOFR Loans.

[0000950170-23-062173:notes:177]
DDTL Interest Rate

[0000950170-23-062173:notes:178]
All U.S. borrowings under the DDTL bear interest, at the Company’s option, at a rate per annum equal to (A)(i) the highest of (a) the federal funds rate (i.e., for any day, the rate per annum equal to the weighted average of the rates on overnight federal funds transactions with members of the Federal Reserve System, as published by the Federal Reserve Bank of New York on the business day next succeeding such day) plus ½ of 1.0%, (b) the prime commercial lending rate of the Administrative Agent, as established from time to time at its principal U.S. office (which such rate is an index or base rate and will not necessarily be its lowest or best rate charged to its customers or other banks), and (c) the sum of the Adjusted Term SOFR (as defined in the Credit Agreement) plus the applicable rate, ranging from 1.9% to 2.9%, provided that such sum is subject to a 0.0% floor (such loans utilizing this interest rate, “SOFR Loans”) or (B) the sum of the daily Adjusted Term SOFR (as defined in the Credit Agreement) for a one-month tenor plus 1.0%, plus (ii) the applicable rate, ranging from 0.9% to 1.9%. The applicable rate is based on the consolidated net leverage ratio of the Company and its subsidiaries as determined pursuant to the terms of the Credit Agreement. Default interest is 2.0% per annum in excess of the rate otherwise applicable in the case of any overdue principal or any other overdue amount.

[0000950170-23-062173:notes:179]
In addition to paying interest on outstanding principal under the DDTL loan, the Company is required to pay a commitment fee to the lenders under the Credit Agreement in respect of unutilized DDTL commitments at a rate of 0.25% per annum on the daily unused portion of the aggregate DDTL commitment until the earliest of (i) the delayed draw funding date, (ii) the delayed draw funding deadline and (iii) the termination in full of the DDTL commitments.

[0000950170-23-062173:notes:180]
Covenants Under the Credit Agreement

[0000950170-23-062173:notes:181]
The First Amendment permits the Company to prepay any or all of the outstanding loans or to reduce the commitments under the First Amendment without incurring premiums or penalties (except breakage costs with respect to SOFR Loans and EURIBOR Loans). The First Amendment contains customary affirmative and negative covenants, including incurrence covenants and certain other limitations on the ability of the Company and the Company’s subsidiaries to incur additional debt, guarantee other obligations, grant liens on assets, make investments, dispose of assets, pay dividends or other payments on capital stock, make restricted payments, engage in mergers or consolidations, engage in transactions with affiliates, modify its organizational documents, and enter into certain restrictive agreements. It also contains customary events of default (subject to customary cure periods and materiality thresholds).

[0000950170-23-062173:notes:182]
The First Amendment further included the following revised financial covenants; (i) the addition of an automatic step up in the consolidated total net leverage ratio to 5.00:1.00 from 3.25:1.00 upon the occurrence of a Springing Covenant Event and continuing for the fiscal quarter in which the Springing Covenant Event occurs and the next three consecutive fiscal quarters thereafter (such period, a “Springing Covenant Period”) and (ii) the addition of a consolidated senior secured net leverage ratio covenant to be tested quarterly during a Springing Covenant Period and sized at 4.00:1.00 during the first quarter ending after a Springing Covenant Event, 3.75:1.00 during the second quarter ending after a Springing Covenant Event and 3.50:1.00 during the third and fourth quarters ending after a Springing Covenant Event. Further, if the Company or any of its subsidiaries incurs unsecured indebtedness under the uncapped general indebtedness basket or permitted convertible indebtedness basket of the Credit Agreement in excess of $50.0 million in connection with a transaction that is a Springing Covenant Event or during a Springing Covenant Period, then the maximum consolidated senior secured net leverage ratio shall be, or shall automatically step down to, 3.50:1.00 at the time of such incurrence.

[0000950170-23-062173:notes:183]
The First Amendment also requires that the consolidated interest coverage ratio (as defined in the First Amendment) of the Company and its subsidiaries tested on the last day of each fiscal quarter not fall below 3.00 to 1.00. As of September 30, 2023, the Company was in compliance with all material covenants.

[0000950170-23-062173:notes:184]
Finally, pursuant to a Collateral Agreement, dated as of July 18, 2022, among the Company, ADTRAN, Inc. and the Administrative Agent, ADTRAN, Inc.’s obligations under the First Amendment are secured by substantially all of the assets of ADTRAN, Inc. and the Company. In addition, the Company has guaranteed ADTRAN, Inc.’s obligations under the First Amendment pursuant to a Guaranty Agreement, dated as of July 18, 2022, by ADTRAN, Inc. and the Company in favor of the Administrative Agent.

[0000950170-23-062173:notes:185]
Nord/LB Revolving Line of Credit

[0000950170-23-062173:notes:186]
On March 29, 2023, Adtran Networks entered into a $16.1 million unsecured revolving line of credit with Norddeutsche Landesbark - Girozentrale (Nord/LB) that bears interest of Euro Short Term Rate plus 1.94%. The line of credit has a perpetual term that can be terminated by the Company or Nord/LB at any time. As of September 30, 2023, Adtran Networks borrowed $10.6 million under this facility.

[0000950170-23-062173:notes:187]
Prior Nord/LB Revolving Line of Credit

[0000950170-23-062173:notes:188]
On August 8, 2022, Adtran Networks entered into a $16.1 million revolving line of credit with Norddeutsche Landesbark - Girozentrale (Nord/LB) that bears interest of Euro Short Term Rate plus 1.4% and matured in August 2023. On January 31, 2023, the Company repaid the outstanding borrowings under the Nord/LB revolving line of credit. No amounts are available for future borrowings.

[0000950170-23-062173:notes:189]
Syndicated Credit Agreement Working Capital Line of Credit

[0000950170-23-062173:notes:190]
In September 2018, Adtran Networks entered into a syndicated credit agreement with Bayerische Landesbank and Deutsche Bank AG Branch German Business to borrow up to $10.7 million as part of a working capital line of credit. On January 31, 2023, the Company repaid the outstanding borrowings under the syndicated credit agreement working capital line of credit. No amounts are available for future borrowings.

[0000950170-23-062173:notes:191]
DZ Bank Revolving Line of Credit

[0000950170-23-062173:notes:192]
In the fourth quarter of 2022, Adtran Networks entered into a revolving line of credit with DZ Bank to borrow up to $9.1 million. Interest on the line of credit reset monthly based on renewal of the loan and was 2.8% at the time the loan was repaid. On March 12, 2023, the Company repaid the outstanding borrowings under the DZ Bank revolving line of credit. No amounts are available for future borrowings.


## adtn:NotesPayableDisclosureTextBlock

[0000950170-23-062173:notes:193]
13. NOTES PAYABLE

[0000950170-23-062173:notes:194]
The carrying amounts of the Company's notes payable in its Condensed Consolidated Balance Sheets were as follows:

[0000950170-23-062173:notes:195]
|  |  | Fair Value as of |  |  | Carrying Value as of |  |  | Carrying Value as of |  |
| (In thousands) |  | September 30, 2023 |  |  | September 30, 2023 |  |  | December 31, 2022 |  |
| Syndicated credit agreement notes payable |  | $ | — |  |  | $ | — |  |  | $ | 24,598 |  |
| Total Notes Payable |  | $ | — |  |  | $ | — |  |  | $ | 24,598 |  |

[0000950170-23-062173:notes:196]
Syndicated Credit Agreement Note Payable

[0000950170-23-062173:notes:197]
In September 2018, Adtran Networks entered into a syndicated credit agreement with Bayerische Landesbank and Deutsche Bank AG Branch German Business to borrow $63.7 million. On January 31, 2023, the Company repaid the outstanding borrowings under the syndicated credit agreement note payable. No amounts are available for future borrowings.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000950170-23-062173:notes:198]
[same as prior period, unchanged from 0000950170-23-042449:notes:192]

[0000950170-23-062173:notes:199]
[same as prior period, unchanged from 0000950170-23-042449:notes:193]

[0000950170-23-062173:notes:200]
[same as prior period, unchanged from 0000950170-23-042449:notes:194]

[0000950170-23-062173:notes:201]
[same as prior period, unchanged from 0000950170-23-042449:notes:195]

[0000950170-23-062173:notes:202]
[same as prior period, unchanged from 0000950170-23-042449:notes:196]

[0000950170-23-062173:notes:203]
[same as prior period, unchanged from 0000950170-23-042449:notes:197]

[0000950170-23-062173:notes:204]
[same as prior period, unchanged from 0000950170-23-042449:notes:198]

[0000950170-23-062173:notes:205]
The Company's net pension liability for all defined benefit pension plans totaled $10.7 million and $10.6 million as of September 30, 2023 and December 31, 2022, respectively.

[0000950170-23-062173:notes:206]
[same as prior period, unchanged from 0000950170-23-042449:notes:200]

[0000950170-23-062173:notes:207]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Service cost |  | $ | 401 |  |  | $ | 478 |  |  | $ | 1,203 |  |  | $ | 981 |  |
| Interest cost |  |  | (33 | ) |  |  | 204 |  |  |  | (99 | ) |  |  | 638 |  |
| Expected return on plan assets |  |  | 59 |  |  |  | (465 | ) |  |  | 177 |  |  |  | (1,384 | ) |
| Amortization of actuarial losses |  |  | 7 |  |  |  | 81 |  |  |  | 20 |  |  |  | 254 |  |
| Net periodic pension cost |  | $ | 434 |  |  | $ | 298 |  |  | $ | 1,300 |  |  | $ | 489 |  |

[0000950170-23-062173:notes:208]
The components of net periodic pension cost, other than the service cost component, are included in other income, net in the Condensed Consolidated Statements of Loss. Service cost is included in cost of revenue, selling, general and administrative expenses and research and development expenses in the Condensed Consolidated Statements of Loss. The Company made contributions to the defined benefit pension plans totaling $2.8 million and $1.2 million during the nine months ended September 30, 2023 and 2022, respectively. Contributions to the defined benefit pension plans for the remainder of 2023 will be limited to benefit payments to retirees which are paid out of the operating cash flows of the Company and are expected to be approximately $0.9 million.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000950170-23-062173:notes:209]
[same as prior period, unchanged from 0000950170-23-042449:notes:203]

[0000950170-23-062173:notes:210]
Accumulated Other Comprehensive (Loss) Income

[0000950170-23-062173:notes:211]
The following tables present the changes in accumulated other comprehensive (loss) income, net of tax, by component:

[0000950170-23-062173:notes:212]
|  |  | Three Months Ended September 30, 2023 |  |
| (In thousands) |  | Unrealized(Losses) GainsonAvailable-for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | ASU 2018-02 Adoption |  |  | Total |  |
| Balance as of June 30, 2023 |  | $ | (773 | ) |  | $ | (958 | ) |  | $ | 63,554 |  |  | $ | 385 |  |  | $ | 62,208 |  |
| Other comprehensive income (loss) before reclassifications |  |  | 635 |  |  |  | — |  |  |  | (29,716 | ) |  |  | — |  |  |  | (29,081 | ) |
| Amounts reclassified from accumulated other comprehensive loss |  |  | (244 | ) |  |  | (83 | ) |  |  | — |  |  |  | — |  |  |  | (327 | ) |
| Net current period other comprehensive income (loss) |  |  | 391 |  |  |  | (83 | ) |  |  | (29,716 | ) |  |  | — |  |  |  | (29,408 | ) |
| Balance as of September 30, 2023 |  | $ | (382 | ) |  | $ | (1,041 | ) |  | $ | 33,838 |  |  | $ | 385 |  |  | $ | 32,800 |  |

[0000950170-23-062173:notes:213]
|  |  | Three Months Ended September 30, 2022 |  |
| (In thousands) |  | Unrealized(Losses) GainsonAvailable-for-Sale Securities |  |  | DefinedBenefit Plan Adjustments |  |  | ForeignCurrency Adjustments |  |  | ASU 2018-02 Adoption |  |  | Total |  |
| Balance as of June 30, 2022 |  | $ | (1,476 | ) |  | $ | (5,713 | ) |  | $ | (9,892 | ) |  | $ | 385 |  |  | $ | (16,696 | ) |
| Other comprehensive loss before reclassifications |  |  | (254 | ) |  |  | — |  |  |  | (23,172 | ) |  |  | — |  |  |  | (23,426 | ) |
| Amounts reclassified from accumulated other comprehensive loss |  |  | (142 | ) |  |  | (118 | ) |  |  | — |  |  |  | — |  |  |  | (260 | ) |
| Net current period other comprehensive loss |  |  | (396 | ) |  |  | (118 | ) |  |  | (23,172 | ) |  |  | — |  |  |  | (23,686 | ) |
| Less: Comprehensive loss attributable to non-controlling interest, net of tax |  |  | — |  |  |  | — |  |  |  | (94 | ) |  |  | — |  |  |  | (94 | ) |
| Balance as of September 30, 2022 |  | $ | (1,872 | ) |  | $ | (5,831 | ) |  | $ | (32,970 | ) |  | $ | 385 |  |  | $ | (40,288 | ) |

[0000950170-23-062173:notes:214]
|  |  | Nine Months Ended September 30, 2023 |  |
| (In thousands) |  | Unrealized(Losses) GainsonAvailable-for-SaleSecurities |  |  | DefinedBenefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | ASU 2018-02 Adoption |  |  | Total |  |
| Balance as of December 31, 2022 |  | $ | (836 | ) |  | $ | (1,016 | ) |  | $ | 48,180 |  |  | $ | 385 |  |  | $ | 46,713 |  |
| Other comprehensive income (loss) before reclassifications |  |  | 733 |  |  |  | — |  |  |  | (14,098 | ) |  |  | — |  |  |  | (13,365 | ) |
| Amounts reclassified from accumulated other comprehensive loss |  |  | (279 | ) |  |  | (25 | ) |  |  | — |  |  |  | — |  |  |  | (304 | ) |
| Net current period other comprehensive income (loss) |  |  | 454 |  |  |  | (25 | ) |  |  | (14,098 | ) |  |  | — |  |  |  | (13,669 | ) |
| Less: Comprehensive income attributable to non-controlling interest, net of tax |  |  | — |  |  |  | — |  |  |  | 244 |  |  |  | — |  |  |  | 244 |  |
| Balance as of September 30, 2023 |  | $ | (382 | ) |  | $ | (1,041 | ) |  | $ | 33,838 |  |  | $ | 385 |  |  | $ | 32,800 |  |

[0000950170-23-062173:notes:215]
|  |  | Nine Months Ended September 30, 2022 |  |
| (In thousands) |  | Unrealized(Losses) Gains on Available-for-Sale Securities |  |  | DefinedBenefit Plan Adjustments |  |  | ForeignCurrency Adjustments |  |  | ASU 2018-02 Adoption |  |  | Total |  |
| Balance as of December 31, 2021 |  | $ | (552 | ) |  | $ | (5,613 | ) |  | $ | (6,134 | ) |  | $ | 385 |  |  | $ | (11,914 | ) |
| Other comprehensive loss before reclassifications |  |  | (1,818 | ) |  |  | — |  |  |  | (26,930 | ) |  |  | — |  |  |  | (28,748 | ) |
| Amounts reclassified from accumulated other comprehensive income (loss) |  |  | 498 |  |  |  | (218 | ) |  |  | — |  |  |  | — |  |  |  | 280 |  |
| Net current period other comprehensive loss |  |  | (1,320 | ) |  |  | (218 | ) |  |  | (26,930 | ) |  |  | — |  |  |  | (28,468 | ) |
| Less: Comprehensive loss attributable to non-controlling interest, net of tax |  |  | — |  |  |  | — |  |  |  | (94 | ) |  |  | — |  |  |  | (94 | ) |
| Balance as of September 30, 2022 |  | $ | (1,872 | ) |  | $ | (5,831 | ) |  | $ | (32,970 | ) |  | $ | 385 |  |  | $ | (40,288 | ) |

[0000950170-23-062173:notes:216]
[same as prior period, unchanged from 0000950170-23-042449:notes:210]

[0000950170-23-062173:notes:217]
|  |  | Three Months Ended September 30, 2023 |
| (In thousands) |  | Amount ReclassifiedfromAccumulated Other Comprehensive Loss |  |  | Affected Line Item in theStatement Where NetLoss Is Presented |
| Unrealized gain (loss) on available-for-sale securities: |  |  |  |  |  |
| Net realized loss on sales of securities |  | $ | 321 |  |  | Net investment (loss) gain |
| Defined benefit plan adjustments – actuarial loss |  |  | 120 |  |  | (1) |
| Total reclassifications for the period, before tax |  |  | 441 |  |  |  |
| Tax benefit |  |  | (114 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 327 |  |  |  |

[0000950170-23-062173:notes:218]
(1)
A part of the computation of net periodic pension cost, which is included in other income, net in the Condensed Consolidated Statements of Loss.

[0000950170-23-062173:notes:219]
|  |  | Three Months Ended September 30, 2022 |
| (In thousands) |  | Amount ReclassifiedfromAccumulated Other Comprehensive Loss |  |  | Affected Line Item in the Statement Where Net Loss Is Presented |
| Unrealized gain (loss) on available-for-sale securities: |  |  |  |  |  |
| Net realized loss on sales of securities |  | $ | 187 |  |  | Net investment (loss) gain |
| Defined benefit plan adjustments – actuarial loss |  |  | 171 |  |  | (1) |
| Total reclassifications for the period, before tax |  |  | 358 |  |  |  |
| Tax benefit |  |  | (98 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 260 |  |  |  |

[0000950170-23-062173:notes:220]
|  |  | Nine Months Ended September 30, 2023 |
| (In thousands) |  | Amount ReclassifiedfromAccumulated Other Comprehensive Loss |  |  | Affected Line Item in the Statement Where Net Loss Is Presented |
| Unrealized gain (loss) on available-for-sale securities: |  |  |  |  |  |
| Net realized loss on sales of securities |  | $ | 367 |  |  | Net investment (loss) gain |
| Defined benefit plan adjustments – actuarial loss |  |  | 36 |  |  | (1) |
| Total reclassifications for the period, before tax |  |  | 403 |  |  |  |
| Tax benefit |  |  | (99 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 304 |  |  |  |

[0000950170-23-062173:notes:221]
|  |  | Nine Months Ended September 30, 2022 |
| (In thousands) |  | Amount ReclassifiedfromAccumulated Other Comprehensive Loss |  |  | Affected Line Item in the Statement Where Net Loss Is Presented |
| Unrealized gain (loss) on available-for-sale securities: |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | (655 | ) |  | Net investment (loss) gain |
| Defined benefit plan adjustments – actuarial loss |  |  | 316 |  |  | (1) |
| Total reclassifications for the period, before tax |  |  | (339 | ) |  |  |
| Tax expense |  |  | 59 |  |  |  |
| Total reclassifications for the period, net of tax |  | $ | (280 | ) |  |  |

[0000950170-23-062173:notes:222]
The following table presents the tax effects related to the change in each component of other comprehensive (loss) income:

[0000950170-23-062173:notes:223]
|  |  | Three Months Ended |  |  | Three Months Ended |  |
|  |  | September 30, 2023 |  |  | September 30, 2022 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense)Benefit |  |  | Net-of-Tax Amount |  |  | Before-Tax Amount |  |  | Tax(Expense)Benefit |  |  | Net-of-TaxAmount |  |
| Unrealized gain (loss) on available-for-sale securities |  | $ | 836 |  |  | $ | (201 | ) |  | $ | 635 |  |  | $ | (334 | ) |  | $ | 80 |  |  | $ | (254 | ) |
| Reclassification adjustment for amounts related to available-for-sale investments included in net (loss) gain |  |  | (321 | ) |  |  | 77 |  |  |  | (244 | ) |  |  | (187 | ) |  |  | 45 |  |  |  | (142 | ) |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net loss |  |  | (120 | ) |  |  | 37 |  |  |  | (83 | ) |  |  | (171 | ) |  |  | 53 |  |  |  | (118 | ) |
| Foreign currency translation adjustments |  |  | (29,716 | ) |  |  | — |  |  |  | (29,716 | ) |  |  | (23,172 | ) |  |  | — |  |  |  | (23,172 | ) |
| Total Other Comprehensive Loss |  | $ | (29,321 | ) |  | $ | (87 | ) |  | $ | (29,408 | ) |  | $ | (23,864 | ) |  | $ | 178 |  |  | $ | (23,686 | ) |

[0000950170-23-062173:notes:224]
|  |  | Nine Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, 2023 |  |  | September 30, 2022 |  |
| (In thousands) |  | Before-TaxAmount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |  | Before-Tax Amount |  |  | Tax (Expense)Benefit |  |  | Net-of-Tax Amount |  |
| Unrealized gain (loss) on available-for-sale securities |  | $ | 964 |  |  | $ | (231 | ) |  | $ | 733 |  |  | $ | (2,392 | ) |  | $ | 574 |  |  | $ | (1,818 | ) |
| Reclassification adjustment for amounts related to available-for-sale investments included in net (loss) gain |  |  | (367 | ) |  |  | 88 |  |  |  | (279 | ) |  |  | 655 |  |  |  | (157 | ) |  |  | 498 |  |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net loss |  |  | (36 | ) |  |  | 11 |  |  |  | (25 | ) |  |  | (316 | ) |  |  | 98 |  |  |  | (218 | ) |
| Foreign currency translation adjustments |  |  | (14,098 | ) |  |  | — |  |  |  | (14,098 | ) |  |  | (26,930 | ) |  |  | — |  |  |  | (26,930 | ) |
| Total Other Comprehensive Loss |  | $ | (13,537 | ) |  | $ | (132 | ) |  | $ | (13,669 | ) |  | $ | (28,983 | ) |  | $ | 515 |  |  | $ | (28,468 | ) |


## us-gaap:RedeemableNoncontrollingInterestTableTextBlock

[0000950170-23-062173:notes:225]
The following table summarizes the redeemable non-controlling interest activity for the nine months ended September 30, 2023:

[0000950170-23-062173:notes:226]
|  |  | Nine Months Ended |  |
| (In thousands) |  | September 30, 2023 |  |
| Balance at beginning of period |  | $ | — |  |
| Reclassification of non-controlling interests |  |  | 443,757 |  |
| Redemption of redeemable non-controlling interest |  |  | (1,558 | ) |
| Net income attributable to redeemable non-controlling interests |  |  | 8,605 |  |
| Annual recurring compensation earned |  |  | (8,605 | ) |
| Translation adjustment |  |  | (10,291 | ) |
| Adtran Networks stock option exercises |  |  | 13 |  |
| Balance as of September 30, 2023 |  | $ | 431,921 |  |


## us-gaap:EarningsPerShareTextBlock

[0000950170-23-062173:notes:227]
17. LOSS PER SHARE

[0000950170-23-062173:notes:228]
The calculation of basic and diluted loss per share is as follows:

[0000950170-23-062173:notes:229]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands, except per share amounts) |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Numerator |  |  |  |  |  |  |  |  |  |  |  |  |
| Net loss attributable to ADTRAN Holdings, Inc. |  | $ | (72,735 | ) |  | $ | (41,934 | ) |  | $ | (140,533 | ) |  | $ | (40,918 | ) |
| Denominator |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average number of shares – basic |  |  | 78,389 |  |  |  | 73,036 |  |  |  | 78,378 |  |  |  | 57,175 |  |
| Effect of dilutive securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock options |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| PSUs, RSUs and restricted stock |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Weighted average number of shares – diluted |  |  | 78,389 |  |  |  | 73,036 |  |  |  | 78,378 |  |  |  | 57,175 |  |
| Loss per share attributable to ADTRAN Holdings, Inc. – basic |  | $ | (0.93 | ) |  | $ | (0.57 | ) |  | $ | (1.79 | ) |  | $ | (0.72 | ) |
| Loss per share attributable to ADTRAN Holdings, Inc. – diluted |  | $ | (0.93 | ) |  | $ | (0.57 | ) |  | $ | (1.79 | ) |  | $ | (0.72 | ) |

[0000950170-23-062173:notes:230]
For the three months ended September 30, 2023 and 2022, 0.5 million and 4 thousand shares, respectively, and for the nine months ended September 30, 2023 and 2022, 0.4 million and 4 thousand shares, respectively, of unvested PSUs, RSUs and restricted stock were excluded from the calculation of diluted earnings per share due to their anti-dilutive effect.

[0000950170-23-062173:notes:231]
For the three months ended September 30, 2023 and 2022, 2.6 million and 0.1 million stock options, respectively, and for the nine months ended September 30, 2023 and 2022, 1.4 million and 0.2 million stock options, respectively, were outstanding but were not included in the computation of diluted earnings per share. These stock options were excluded because their exercise prices were greater than the average market price of the common shares during the applicable period, making them anti-dilutive under the treasury stock method.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000950170-23-062173:notes:232]
[same as prior period, unchanged from 0000950170-23-042449:notes:226]

[0000950170-23-062173:notes:233]
[same as prior period, unchanged from 0000950170-23-042449:notes:227]

[0000950170-23-062173:notes:234]
[same as prior period, unchanged from 0000950170-23-042449:notes:228]

[0000950170-23-062173:notes:235]
[same as prior period, unchanged from 0000950170-23-042449:notes:229]

[0000950170-23-062173:notes:236]
The performance of these segments is evaluated based on revenue, gross profit and gross margin; therefore, selling, general and administrative expenses, research and development expenses, interest and dividend income, interest expense, net investment (loss) gain, other income, net and income tax benefit are reported on a Company-wide basis only. There is no inter-segment revenue. Asset information by reportable segment is not produced and, therefore, is not reported.

[0000950170-23-062173:notes:237]
[same as prior period, unchanged from 0000950170-23-042449:notes:231]

[0000950170-23-062173:notes:238]
|  |  | Three Months Ended |  |
|  |  | September 30, 2023 |  |  | September 30, 2022 |  |
| (In thousands) |  | Revenue |  |  | Gross Profit |  |  | Revenue |  |  | Gross Profit |  |
| Network Solutions |  | $ | 228,564 |  |  | $ | 47,277 |  |  | $ | 304,940 |  |  | $ | 82,334 |  |
| Services & Support |  |  | 43,767 |  |  |  | 26,960 |  |  |  | 35,769 |  |  |  | 20,693 |  |
| Total |  | $ | 272,331 |  |  | $ | 74,237 |  |  | $ | 340,709 |  |  | $ | 103,027 |  |

[0000950170-23-062173:notes:239]
|  |  | Nine Months Ended |  |
|  |  | September 30, 2023 |  |  | September 30, 2022 |  |
| (In thousands) |  | Revenue |  |  | Gross Profit |  |  | Revenue |  |  | Gross Profit |  |
| Network Solutions |  | $ | 793,984 |  |  | $ | 176,607 |  |  | $ | 599,306 |  |  | $ | 186,126 |  |
| Services & Support |  |  | 129,637 |  |  |  | 77,991 |  |  |  | 67,959 |  |  |  | 33,723 |  |
| Total |  | $ | 923,621 |  |  | $ | 254,598 |  |  | $ | 667,265 |  |  | $ | 219,849 |  |

[0000950170-23-062173:notes:240]
For the three months ended September 30, 2023 and 2022, $1.5 million and $1.1 million, respectively, of depreciation expense was included in gross profit for our Network Solutions segment. For the nine months ended September 30, 2023 and 2022, $4.5 million and $1.6 million, respectively, of depreciation expense was included in gross profit for our Network Solutions segment. For the three months ended September 30, 2023 and 2022, $2.4 thousand of depreciation expense was included in gross profit for our Services & Support segment. For the nine months ended September 30, 2023 and 2022, $7.3 thousand and $8.0 thousand, respectively, of depreciation expense was included in gross profit for our Services & Support segment.

[0000950170-23-062173:notes:241]
[same as prior period, unchanged from 0000950170-23-042449:notes:235]

[0000950170-23-062173:notes:242]
[same as prior period, unchanged from 0000950170-23-042449:notes:236]

[0000950170-23-062173:notes:243]
[same as prior period, unchanged from 0000950170-23-042449:notes:237]

[0000950170-23-062173:notes:244]
[same as prior period, unchanged from 0000950170-23-042449:notes:238]

[0000950170-23-062173:notes:245]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| United States |  | $ | 111,494 |  |  | $ | 169,669 |  |  | $ | 375,254 |  |  | $ | 374,470 |  |
| Germany |  |  | 60,347 |  |  |  | 64,234 |  |  |  | 212,171 |  |  |  | 71,945 |  |
| United Kingdom |  |  | 41,242 |  |  |  | 46,569 |  |  |  | 150,710 |  |  |  | 123,477 |  |
| Other international |  |  | 59,248 |  |  |  | 60,237 |  |  |  | 185,486 |  |  |  | 97,373 |  |
| Total |  | $ | 272,331 |  |  | $ | 340,709 |  |  | $ | 923,621 |  |  | $ | 667,265 |  |


## us-gaap:ProductWarrantyDisclosureTextBlock

[0000950170-23-062173:notes:246]
[same as prior period, unchanged from 0000950170-23-042449:notes:240]

[0000950170-23-062173:notes:247]
The Company's products generally include warranties of 90 days to five years for product defects. The Company accrues for warranty returns at the time of product shipment based on its historical return rate and estimate of the cost to repair or replace the defective products. The Company engages in extensive product quality programs and processes, including actively monitoring and evaluating the quality of its component suppliers. The increasing complexity of the Company's products may cause warranty incidences, when they arise, to be more costly. Estimates regarding future warranty obligations may change due to product failure rates, material usage and other rework costs incurred in correcting a product failure. In addition, from time to time, specific warranty accruals may be recorded if unforeseen problems arise. Should the Company's actual experience relative to these factors be worse than its estimates, the Company will be required to record additional warranty expense. The liability for warranty obligations totaled $6.6 million and $7.2 million as of September 30, 2023 and December 31, 2022, respectively, and is included in accrued expenses and other liabilities in the Condensed Consolidated Balance Sheets. The warranty expense and write-off activity for the three and nine months ended September 30, 2023 and 2022 are summarized as follows:

[0000950170-23-062173:notes:248]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Balance at beginning of period |  | $ | 6,831 |  |  | $ | 4,842 |  |  | $ | 7,196 |  |  | $ | 5,403 |  |
| Plus: Adtran Networks acquisition |  |  | — |  |  |  | 3,756 |  |  |  | — |  |  |  | 3,756 |  |
| Plus: Amounts charged to cost and expenses |  |  | 752 |  |  |  | 616 |  |  |  | 2,289 |  |  |  | 1,727 |  |
| Plus: Foreign currency translation adjustments |  |  | (73 | ) |  |  | — |  |  |  | (33 | ) |  |  | — |  |
| Less: Deductions |  |  | (943 | ) |  |  | (613 | ) |  |  | (2,885 | ) |  |  | (2,285 | ) |
| Balance at end of period |  | $ | 6,567 |  |  | $ | 8,601 |  |  | $ | 6,567 |  |  | $ | 8,601 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000950170-23-062173:notes:249]
20. COMMITMENTS AND CONTINGENCIES

[0000950170-23-062173:notes:250]
Legal Matters

[0000950170-23-062173:notes:251]
From time to time, the Company is subject to or otherwise involved in various lawsuits, claims, investigations and legal proceedings that arise out of or are incidental to the conduct of our business (collectively, “Legal Matters”), including those relating to employment matters, patent rights, regulatory compliance matters, stockholder claims, and contractual and other commercial disputes. Such Legal Matters, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Additionally, an unfavorable outcome in a legal matter, including in a patent dispute, could require the Company to pay damages, entitle claimants to other relief, such as royalties, or could prevent the Company from selling some of its products in certain jurisdictions. At this time, the Company is unable to predict the outcome of or estimate the possible loss or range of loss, if any, associated with such legal matters.

[0000950170-23-062173:notes:252]
Adtran Networks Legal Matter

[0000950170-23-062173:notes:253]
On May 8, 2023, Adtran Networks SE and its subsidiary, ADVA Optical Networking North America, Inc. (together, “Adtran Networks”), filed a lawsuit in the U.S District Court for the Eastern District of Texas (“EDTX”) against Huawei Technologies Co. Ltd (“Huawei”) seeking a declaration from the court that Huawei violated its commitments to negotiate in good faith and to license standard essential patents (“SEPs”), to the extent any SEPs are practiced by Adtran Networks, on Fair, Reasonable and Non-Discriminatory (“FRAND”) terms and conditions. The case also sought to obtain a ruling by the EDTX that Adtran Networks has complied with its own commitments and requested that the Court establish FRAND terms and conditions for obtaining a FRAND license on any SEPs to the extent they are practiced by Adtran Networks. The lawsuit further sought to enjoin Huawei from enforcing certain Huawei patents that Adtran Networks considers invalid and/or not practiced, and Adtran Networks alleged that Huawei had infringed upon an Adtran Networks patent. On July 20, 2023, Adtran Networks SE was served with a complaint filed by Huawei against Adtran Networks SE in the District Court München I, Germany, alleging that certain of its products infringe upon one of Huawei’s patents. On August 22, 2023, Adtran Networks entered into a settlement agreement with Huawei pursuant to which the parties agreed to, among other things, dismiss the lawsuits described above.

[0000950170-23-062173:notes:254]
DPLTA Exit and Recurring Compensation Costs

[0000950170-23-062173:notes:255]
Our obligation to pay Annual Recurring Compensation under the DPLTA is a continuing payment obligation, which will amount to approximately €10.6 million or $11.2 million (based on the current exchange rate) per year assuming none of the minority Adtran Networks shareholders were to elect Exit Compensation. The foregoing amounts do not reflect any potential increase in payment obligations that we may have depending on the outcome of ongoing appraisal proceedings in Germany. During the three and nine months ended September 30, 2023, we accrued $2.9 million and $8.6 million in Annual Recurring Compensation, which was reflected as a reduction to retained (deficit) earnings, respectively.

[0000950170-23-062173:notes:256]
For the three and nine months ended September 30, 2023, less than 1 thousand shares and 64 thousand shares, respectively, of Adtran Networks stock was tendered to the Company and Exit Compensation payments of approximately €8 thousand and €1.1 million, respectively, or approximately $9 thousand and $1.2 million, respectively, based on an exchange rate as of September 30, 2023, were paid to Adtran Networks shareholders.

[0000950170-23-062173:notes:257]
Performance Bonds

[0000950170-23-062173:notes:258]
Certain contracts, customers and jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of September 30, 2023 and December 31, 2022, we had commitments related to these bonds totaling $11.8 million and $22.0 million, respectively, which expire at various dates through April 2031. In general, we would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which we believe is remote.

[0000950170-23-062173:notes:259]
Purchase Commitments

[0000950170-23-062173:notes:260]
The Company purchases components from a variety of suppliers and use contract manufacturers to provide manufacturing services for our products. Our inventory purchase commitments are for short-term product manufacturing requirements, as well as for commitments to suppliers to secure manufacturing capacity. Certain of our inventory purchase commitments with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. As of September 30, 2023, purchase commitments totaled $308.4 million.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000950170-23-062173:notes:261]
[same as prior period, unchanged from 0000950170-23-042449:notes:256]

[0000950170-23-062173:notes:262]
[same as prior period, unchanged from 0000950170-23-042449:notes:257]

[0000950170-23-062173:notes:263]
[same as prior period, unchanged from 0000950170-23-042449:notes:258]

[0000950170-23-062173:notes:264]
During the three and nine months ended September 30, 2023, we recognized a certain write down of inventory of $21.0 million due to a restructuring discontinuation of certain product lines within our Network Solutions segment. There was no write down of inventory during the three and nine months ended September 30, 2022. See Note 7, Inventory, for additional information regarding the write down of inventory.

[0000950170-23-062173:notes:265]
A reconciliation of the beginning and ending restructuring liabilities, which is included in accrued wages and benefits in the Condensed Consolidated Balance Sheets as of September 30, 2023 and December 31, 2022, is as follows:

[0000950170-23-062173:notes:266]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
| (In thousands) |  | September 30, 2023 |  |  | September 30, 2023 |  |
| Balance at beginning of period |  | $ | 6,452 |  |  | $ | 159 |  |
| Plus: Amounts charged to cost and expense |  |  | 3,830 |  |  |  | 12,135 |  |
| Less: Amounts paid |  |  | (4,729 | ) |  |  | (6,741 | ) |
| Balance as of September 30, 2023 |  | $ | 5,553 |  |  | $ | 5,553 |  |

[0000950170-23-062173:notes:267]
[same as prior period, unchanged from 0000950170-23-042449:notes:261]

[0000950170-23-062173:notes:268]
Restructuring expenses included in the Condensed Consolidated Statements of Loss are for the three and nine months ended September 30, 2023 and 2022:

[0000950170-23-062173:notes:269]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Network Solutions - Cost of revenue |  | $ | 611 |  |  | $ | — |  |  | $ | 669 |  |  | $ | — |  |
| Network Solutions - Inventory write down |  |  | 21,043 |  |  |  | — |  |  |  | 21,043 |  |  |  | — |  |
| Services & Support - Cost of revenue |  |  | (24 | ) |  |  | — |  |  |  | (6 | ) |  |  | — |  |
| Cost of revenue |  | $ | 21,630 |  |  | $ | — |  |  | $ | 21,706 |  |  | $ | — |  |
| Selling, general and administrative expenses |  |  | 3,387 |  |  |  | — |  |  |  | 6,960 |  |  |  | 2 |  |
| Research and development expenses |  |  | (144 | ) |  |  | — |  |  |  | 4,512 |  |  |  | — |  |
| Total restructuring expenses |  | $ | 24,873 |  |  | $ | — |  |  | $ | 33,178 |  |  | $ | 2 |  |

[0000950170-23-062173:notes:270]
The following table represents the components of restructuring expenses by geographic area for the three and nine months ended September 30, 2023 and 2022:

[0000950170-23-062173:notes:271]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| United States |  | $ | 22,598 |  |  | $ | — |  |  | $ | 25,217 |  |  | $ | 2 |  |
| International |  |  | 2,275 |  |  |  | — |  |  |  | 7,961 |  |  |  | — |  |
| Total restructuring expenses |  | $ | 24,873 |  |  | $ | — |  |  | $ | 33,178 |  |  | $ | 2 |  |


## us-gaap:SubsequentEventsTextBlock

[0000950170-23-062173:notes:272]
22. SUBSEQUENT EVENTS

[0000950170-23-062173:notes:273]
Dividend Suspension

[0000950170-23-062173:notes:274]
On November 6, 2023, the Board of Directors suspended the Company’s quarterly cash dividend which will be redirected to reduce debt and interest expense and support the Company's capital efficiency program. The payment of any future dividends will be at the discretion of the Board of Directors and will depend on the Company’s financial condition, results of operations, capital requirements, and any other factors deemed relevant by the Board of Directors.

[0000950170-23-062173:notes:275]
Business Efficiency Program

[0000950170-23-062173:notes:276]
On November 6, 2023, due to the uncertainty around the current macroeconomic environment and its impact on customer spending levels, the Company’s management determined to implement a comprehensive business efficiency program, which includes (i) a cost efficiency program targeting the reduction of ongoing operating expenses, and (ii) a capital efficiency program, which includes a site consolidation plan exploring the partial sale of owned real estate and the suspension of the quarterly dividend. See Part II, Item 5 (a) of this report for additional information regarding the business efficiency program.
