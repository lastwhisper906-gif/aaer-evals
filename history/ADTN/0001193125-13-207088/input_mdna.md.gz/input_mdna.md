# ADTN MD&A — 0001193125-13-207088


## mdna

[0001193125-13-207088:mdna:1]
[same as prior period, unchanged from 0001193125-12-451437:mdna:1]

[0001193125-13-207088:mdna:2]
The following discussion should be read in conjunction with the Consolidated Financial Statements and the
related notes that appear elsewhere in this document.

[0001193125-13-207088:mdna:3]
[same as prior period, unchanged from 0001193125-12-451437:mdna:3]

[0001193125-13-207088:mdna:4]
ADTRAN, Inc. designs, manufactures and markets solutions and provides services and support for communications networks. Our solutions are widely deployed by providers of communications services (serviced
by our Carrier Networks Division), and small, mid-sized and distributed enterprises (serviced by our Enterprise Networks Division), and enable voice, data, video and Internet communications across a variety of network infrastructures. Many of these
solutions are currently in use by every major United States service provider, many global service providers, as well as many public, private and governmental organizations worldwide.

[0001193125-13-207088:mdna:5]
[same as prior period, unchanged from 0001193125-12-451437:mdna:5]

[0001193125-13-207088:mdna:6]
Our three major product categories are Carrier Systems, Business Networking and Loop Access.

[0001193125-13-207088:mdna:7]
Carrier Systems products are used by communications service providers to provide data, voice and video services to consumers and enterprises. This
category includes the following product areas and related services:

[0001193125-13-207088:mdna:8]
|  | • |  | Broadband Access |

[0001193125-13-207088:mdna:9]
|  | • |  | Total Access® 5000 Multi-Service Access and Aggregation Platform (MSAP) |

[0001193125-13-207088:mdna:10]
|  | • |  | hiX family of MSAPs |

[0001193125-13-207088:mdna:11]
|  | • |  | Total Access 1100/1200 Series of Fiber to the Node (FTTN) products |

[0001193125-13-207088:mdna:12]
|  | • |  | Ultra Broadband Ethernet (UBE) |

[0001193125-13-207088:mdna:13]
|  | • |  | Digital Subscriber Line Access Multiplexer (DSLAM) products |

[0001193125-13-207088:mdna:14]
|  | • |  | Optical |

[0001193125-13-207088:mdna:15]
|  | • |  | Optical Networking Edge (ONE) |

[0001193125-13-207088:mdna:16]
|  | • |  | NetVanta 8000 Series |

[0001193125-13-207088:mdna:17]
|  | • |  | OPTI and TA 3000 optical products |

[0001193125-13-207088:mdna:18]
|  | • |  | Small Form-Factor Pluggable (SFP) products |

[0001193125-13-207088:mdna:19]
|  | • |  | TDM systems |

[0001193125-13-207088:mdna:20]
|  | • |  | Network Management Solutions |

[0001193125-13-207088:mdna:21]
Business Networking products provide access to telecommunication services and facilitate the delivery
of cloud connectivity, enterprise communications and virtual mobility to the small and mid-sized enterprise (SME) market. This category includes the following product areas and related services:

[0001193125-13-207088:mdna:22]
|  | • |  | Internetworking products |

[0001193125-13-207088:mdna:23]
|  | • |  | Total Access IP Business Gateways |

[0001193125-13-207088:mdna:24]
|  | • |  | Optical Network Terminals (ONTs) |

[0001193125-13-207088:mdna:25]
|  | • |  | Bluesocket® virtual Wireless LAN (WLAN) |

[0001193125-13-207088:mdna:26]
|  | • |  | NetVanta® |

[0001193125-13-207088:mdna:27]
|  | • |  | Multiservice Routers |

[0001193125-13-207088:mdna:28]
|  | • |  | Managed Ethernet Switches |

[0001193125-13-207088:mdna:29]
|  | • |  | IP Business Gateways |

[0001193125-13-207088:mdna:30]
|  | • |  | Unified Communications (UC) solutions |

[0001193125-13-207088:mdna:31]
|  | • |  | Carrier Ethernet Network Terminating Equipment (NTE) |

[0001193125-13-207088:mdna:32]
|  | • |  | Network Management Solutions |

[0001193125-13-207088:mdna:33]
|  | • |  | Integrated Access Devices (IADs) |

[0001193125-13-207088:mdna:34]
Loop Access products are used by carrier and enterprise customers for access to copper-based telecommunications networks. The Loop Access category includes the following product areas:

[0001193125-13-207088:mdna:35]
|  | • |  | High bit-rate Digital Subscriber Line (HDSL) products |

[0001193125-13-207088:mdna:36]
|  | • |  | Digital Data Service (DDS) |

[0001193125-13-207088:mdna:37]
|  | • |  | Integrated Services Digital Network (ISDN) products |

[0001193125-13-207088:mdna:38]
|  | • |  | T1/E1/T3 Channel Service Units/Data Service Units (CSUs/DSUs) |

[0001193125-13-207088:mdna:39]
|  | • |  | TRACER fixed-wireless products |

[0001193125-13-207088:mdna:40]
In addition, we identify subcategories of product revenues, which we divide into our core products and legacy products. Our core products consist of Broadband Access and Optical products (included in
Carrier Systems) and Internetworking products (included in Business Networking). Our legacy products include HDSL products (included in Loop Access) and other products not included in the aforementioned core products. Many of our customers are
migrating their networks to deliver higher bandwidth services by utilizing newer technologies. We believe that products and services offered in our core product areas position us well for this migration. Despite occasional increases, we anticipate
that revenues of many of our legacy products, including HDSL, will decline over time; however, revenues from these products may continue for years because of the time required for our customers to transition to newer technologies.

[0001193125-13-207088:mdna:41]
See Note 12 of Notes to Consolidated Financial Statements in this report for further information regarding these product categories.

[0001193125-13-207088:mdna:42]
Sales were $143.0 million for the three months ended March 31, 2013 compared to $134.7 million for the three months ended March 31, 2012.
Product revenues for our three core areas, Broadband Access, Optical and Internetworking, were $118.0 million for the three months ended March 31, 2013 compared to $104.7 million for the three months ended March 31, 2012. Our gross margin
decreased to 48.7% for the three months ended March 31, 2013 from 55.0% for the three months ended March 31, 2012. Our operating income margin decreased to 4.6% for the three months ended March 31, 2013 from 12.0% for the three months
ended March 31, 2012. Net income was $7.9 million for the three months ended March 31, 2013 compared to $13.0 million for the three months ended March 31, 2012. Our effective tax rate decreased to 18.9% for the three months ended
March 31, 2013 from 35.4% for the three months ended March 31, 2012. Earnings per share, assuming dilution, were $0.13 for the three months ended March 31, 2013 compared to $0.20 for the three months ended March 31, 2012.

[0001193125-13-207088:mdna:43]
24

[0001193125-13-207088:mdna:44]
[same as prior period, unchanged from 0001193125-12-451437:mdna:10]

[0001193125-13-207088:mdna:45]
Our operating results may also fluctuate as a result of a number of other factors, including a decline in general economic and market conditions,
increased competition, customer order patterns, changes in product and services mix, timing differences between price decreases and product cost reductions, product warranty returns, expediting costs and announcements of new products by us or our
competitors. Additionally, maintaining sufficient inventory levels to assure prompt delivery of our products increases the amount of inventory that may become obsolete and increases the risk that the obsolescence of this inventory may have an
adverse effect on our business and operating results. Also, not maintaining sufficient inventory levels to assure prompt delivery of our products may cause us to incur expediting costs to meet customer delivery requirements, which may negatively
impact our operating results in a given quarter.

[0001193125-13-207088:mdna:46]
Accordingly, our historical financial performance is not necessarily a meaningful indicator
of future results, and, in general, management expects that our financial results may vary from period to period. A list of factors that could materially affect our business, financial condition or operating results is included under “Factors
That Could Affect Our Future Results” in “Management’s Discussion and Analysis of Financial Condition and Results of Operations” contained in Item 2 of Part I of this report. These factors have also been discussed in more
detail in Item 1A of Part I in our most recent Annual Report on Form 10-K for the year ended December 31, 2012, filed on February 28, 2013 with the SEC.

[0001193125-13-207088:mdna:47]
[same as prior period, unchanged from 0001193125-12-451437:mdna:13]

[0001193125-13-207088:mdna:48]
Our critical accounting policies and estimates
have not changed significantly from those detailed in our most recent Annual Report on Form 10-K for the year ended December 31, 2012, filed on February 28, 2013 with the SEC.

[0001193125-13-207088:mdna:49]
[same as prior period, unchanged from 0001193125-12-451437:mdna:15]

[0001193125-13-207088:mdna:50]
[same as prior period, unchanged from 0001193125-12-451437:mdna:16]

[0001193125-13-207088:mdna:51]
[same as prior period, unchanged from 0001193125-12-451437:mdna:17]

[0001193125-13-207088:mdna:52]
On May 4, 2012, we closed on the acquisition of the Nokia Siemens Networks Broadband Access business (NSN BBA). Acquisition related expenses, amortizations and adjustments for the three months ended
March 31, 2013 and 2012 for that transaction is as follows:

[0001193125-13-207088:mdna:53]
|  |  | Three Months Ended March 31, |  |
|  |  | 2013 |  |  | 2012 |  |
| Amortization of acquired intangible assets |  | $ | 294 |  |  | $ | — |  |
| Amortization of other purchase accounting adjustments |  |  | 410 |  |  |  | — |  |
| Acquisition related professional fees, travel and other expenses |  |  | 154 |  |  |  | 1,580 |  |
| Total acquisition related expenses, amortizations and adjustments |  |  | 858 |  |  |  | 1,580 |  |
| Tax effect |  |  | (266 | ) |  |  | (615 | ) |
| Total acquisition related expenses, amortizations and adjustments, net of tax |  | $ | 592 |  |  | $ | 965 |  |

[0001193125-13-207088:mdna:54]
The acquisition related expenses, amortizations and adjustments above were recorded in the following Consolidated
Statements of Income categories for the three months ended March 31, 2013 and 2012:

[0001193125-13-207088:mdna:55]
|  |  | Three Months Ended March 31, |  |
|  |  | 2013 |  |  | 2012 |  |
| Revenue (adjustments to deferred revenue recognized in the period) |  | $ | 236 |  |  | $ | — |  |
| Cost of goods sold |  |  | 87 |  |  |  | 17 |  |
| Subtotal |  |  | 323 |  |  |  | 17 |  |
| Selling, general and administrative expenses |  |  | 161 |  |  |  | 1,561 |  |
| Research and development expenses |  |  | 374 |  |  |  | 2 |  |
| Subtotal |  |  | 535 |  |  |  | 1,563 |  |
| Total acquisition related expenses, amortizations and adjustments |  |  | 858 |  |  |  | 1,580 |  |
| Tax effect |  |  | (266 | ) |  |  | (615 | ) |
| Total acquisition related expenses, amortizations and adjustments, net of tax |  | $ | 592 |  |  | $ | 965 |  |

[0001193125-13-207088:mdna:56]
See Note 9 of Notes to Consolidated Financial Statements in Item 1 of this Form 10-Q for additional information on
amortization of intangible assets acquired in previous business acquisitions.

[0001193125-13-207088:mdna:57]
26

[0001193125-13-207088:mdna:58]
RESULTS OF OPERATIONS – THREE MONTHS ENDED MARCH 31, 2013 COMPARED TO THREE MONTHS ENDED
MARCH 31, 2012

[0001193125-13-207088:mdna:59]
[same as prior period, unchanged from 0001193125-12-451437:mdna:24]

[0001193125-13-207088:mdna:60]
ADTRAN’s sales increased 6.1% from $134.7 million in the three months ended March 31, 2012 to $143.0 million in the three months ended March 31, 2013. The increase in sales is primarily
attributable to a $22.8 million increase in sales of our Broadband Access products, partially offset by a $5.4 million decrease in sales of our Optical products, a $5.0 million decrease in sales of our HDSL and other legacy products, and a $4.1
million decrease in sales of our Internetworking products.

[0001193125-13-207088:mdna:61]
Carrier Networks sales increased 13.7% from $96.7 million in the three months
ended March 31, 2012 to $109.9 million in the three months ended March 31, 2013. The increase in sales for the three months ended March 31, 2013 is primarily attributable to an increase in sales of our Broadband Access products,
partially offset by decreases in sales of our Optical products, HDSL and other legacy products. The increase in Broadband Access sales was primarily attributable to the added sales of the acquired broadband access business. The decrease in sales of
Optical products is primarily attributable to the market transitioning to Ethernet and our transition to new products to address this market. The decreases in HDSL and other legacy product revenues have been expected as we evolve our products
towards packet-based technologies.

[0001193125-13-207088:mdna:62]
Enterprise Networks sales decreased 13.0% from $38.1 million in the three months ended March 31, 2012
to $33.1 million in the three months ended March 31, 2013. The decrease in sales for the three months ended March 31, 2013 is primarily attributable to decreases in sales of Internetworking products and legacy products. The decrease in
Internetworking product sales is primarily due to uncertainties caused by the macro-economic environment, which resulted in delays in end-customer purchases. The impact of this environment was partially offset by increases in sales of our WLAN
solutions and switches. Internetworking product sales attributable to Enterprise Networks were 94.1% of the division’s sales in the three months ended March 31, 2013, compared to 91.2% in the three months ended March 31, 2012.
Legacy products primarily comprise the remainder of Enterprise Networks sales. Enterprise Networks sales as a percentage of total sales decreased from 28.3% for the three months ended March 31, 2012 to 23.2% for the three months ended
March 31, 2013.

[0001193125-13-207088:mdna:63]
International sales, which are included in the Carrier Networks and Enterprise Networks amounts discussed above,
increased 90.8% from $18.3 million in the three months ended March 31, 2012 to $34.9 million in the three months ended March 31, 2013. International sales, as a percentage of total sales, increased from 13.6% for the three months ended
March 31, 2012 to 24.4% for the three months ended March 31, 2013. International sales increased in the three months ended March 31, 2013 compared to the three months ended March 31, 2012 primarily due to sales attributable to
the acquired broadband access business, partially offset by a decrease in organic sales in Latin America.

[0001193125-13-207088:mdna:64]
Carrier System product sales
increased $21.5 million in the three months ended March 31, 2013 compared to the three months ended March 31, 2012. The increase for the three months ended March 31, 2013 is primarily due to a $22.8 million increase in Broadband
Access product sales and a $4.2 million increase in legacy product sales, partially offset by a decrease of $5.4 million in Optical product sales. The increase in Broadband Access sales was due to the added sales of the acquired broadband access
business. The decrease in sales of Optical products for the three months ended March 31, 2013 is primarily attributable to the market transitioning to Ethernet and our transition to new products to address this market.

[0001193125-13-207088:mdna:65]
Business Networking product sales decreased $5.1 million in the three months ended March 31, 2013 compared to the three months ended March 31,
2012. The decrease for the three months ended March 31, 2013 is primarily due to a $4.1 million decrease in Interworking product sales across both divisions and a $1.0 million decrease in legacy product sales. The decrease in Internetworking
product sales is primarily due to uncertainties caused by the macro-economic environment, which resulted in delays in end-customer purchases. The impact of this environment was partially offset by increases in sales of our WLAN solutions and
switches. The decrease in sales of legacy products is a result of customers shifting to newer technologies. Many of these newer technologies are integral to our Internetworking product area.

[0001193125-13-207088:mdna:66]
Loop Access product sales decreased $8.2 million in the three months ended March 31, 2013 compared to
the three months ended March 31, 2012. The decrease for the three months ended March 31, 2013 is primarily due to a $7.6 million decrease in HDSL product sales. The declining trend in HDSL and other legacy products has been expected as we
evolve our products towards packet-based technologies.

[0001193125-13-207088:mdna:67]
[same as prior period, unchanged from 0001193125-12-451437:mdna:33]

[0001193125-13-207088:mdna:68]
As a percentage of sales, cost of sales increased from 45.0% in the three months ended March 31, 2012 to 51.3% in the three months ended March 31, 2013. This increase is primarily
attributable to lower gross margins related to the acquired broadband access business, lower cost absorption due to lower production volumes on the organic business, customer price movements to achieve market share position and shifts in customer
mix.

[0001193125-13-207088:mdna:69]
Carrier Networks cost of sales, as a percent of division sales, increased from 45.3% in the three months ended March 31, 2012 to
53.1% in the three months ended March 31, 2013. The increase in Carrier Networks cost of sales as a percentage of sales is primarily attributable to the factors outlined above.

[0001193125-13-207088:mdna:70]
Enterprise Networks cost of sales, as a percent of division sales, increased from 44.3% in the three months ended March 31, 2012 to 45.4% in the three months ended March 31, 2013. The
increase is primarily attributable to lower cost absorption due to lower production volumes and customer price movements to achieve market share position.

[0001193125-13-207088:mdna:71]
An important part of our strategy is to reduce the product cost of each succeeding product generation and then to lower the product’s price based on the cost savings achieved. This may cause
variations in our gross profit percentage due to timing differences between the recognition of cost reductions and the lowering of product selling prices.

[0001193125-13-207088:mdna:72]
[same as prior period, unchanged from 0001193125-12-451437:mdna:38]

[0001193125-13-207088:mdna:73]
Selling, general and administrative
expenses decreased 7.6% from $33.1 million in the three months ended March 31, 2012 to $30.6 million in the three months ended March 31, 2013. The decrease in selling, general and administrative expenses is primarily related to decreases
in professional services, legal services and travel expense, which were higher in 2012 due to pre-acquisition activities related to the acquired broadband access business.

[0001193125-13-207088:mdna:74]
Selling, general and administrative expenses as a percentage of sales decreased from 24.6% in the three months ended March 31, 2012 to 21.4% in the three months ended March 31, 2013. Selling,
general and administrative expenses as a percentage of sales may fluctuate whenever there is a significant fluctuation in revenues for the periods being compared.

[0001193125-13-207088:mdna:75]
[same as prior period, unchanged from 0001193125-12-451437:mdna:41]

[0001193125-13-207088:mdna:76]
Research and development expenses increased 31.1%
from $24.8 million in the three months ended March 31, 2012 to $32.5 million in the three months ended March 31, 2013. The increase in research and development expenses is primarily related to increases in staffing and fringe benefit costs
due to increased headcount related to the broadband access business acquired on May 4, 2012, and increases in amortization of acquired intangible assets, independent contractor expense and office lease expense related to this acquisition.

[0001193125-13-207088:mdna:77]
As a percentage of sales, research and development expenses increased from 18.4% in the three months ended March 31, 2012 to 22.7% in
the three months ended March 31, 2013. Research and development expenses as a percentage of sales will fluctuate whenever there are incremental product development activities or a significant fluctuation in revenues for the periods being
compared.

[0001193125-13-207088:mdna:78]
We expect to continue to incur research and development expenses in connection with our new and existing products and our expansion
into international markets. We continually evaluate new product opportunities and engage in intensive research and product development efforts which provides for new product development, enhancement of existing products and product cost reductions.
We may incur significant research and development expenses prior to the receipt of revenues from a major new product group.

[0001193125-13-207088:mdna:79]
INTEREST
AND DIVIDEND INCOME

[0001193125-13-207088:mdna:80]
Interest and dividend income remained consistent at $1.9 million and $1.8 million in the three months ended
March 31, 2012 and 2013, respectively, as we had no substantial change in interest-bearing investment balances or interest rates.

[0001193125-13-207088:mdna:81]
[same as prior period, unchanged from 0001193125-12-451437:mdna:47]

[0001193125-13-207088:mdna:82]
Interest expense, which is primarily related to our taxable revenue bond, remained constant at $0.6 million in each of the three months ended March 31, 2013 and 2012, as we had no substantial change
in our fixed-rate borrowing. See “Liquidity and Capital Resources” below for additional information on our revenue bond.

[0001193125-13-207088:mdna:83]
NET
REALIZED INVESTMENT GAIN

[0001193125-13-207088:mdna:84]
Net realized investment gain increased 47.8% from $2.5 million in the three months ended March 31, 2012
to $3.6 million in the three months ended March 31, 2013. The higher amount of realized gains in the period ended March 31, 2013 is primarily driven by higher sales of equity securities and reallocation of the marketable equity security
portfolio. See “Investing Activities” in “Liquidity and Capital Resources” below for additional information.

[0001193125-13-207088:mdna:85]
OTHER
INCOME (EXPENSE), NET

[0001193125-13-207088:mdna:86]
Other income (expense), net, comprised primarily of miscellaneous income, gains and losses on foreign currency
transactions, investment account management fees, scrap raw material sales, and gains and losses on the disposal of property, plant and equipment occurring in the normal course of business, changed from $0.1 million of income in the three months
ended March 31, 2012 to $1.7 million of expense in the three months ended March 31, 2013. This change was primarily attributable to losses on foreign currency transactions during the first quarter of 2013.

[0001193125-13-207088:mdna:87]
[same as prior period, unchanged from 0001193125-12-451437:mdna:53]

[0001193125-13-207088:mdna:88]
Our effective tax
rate decreased from 35.4% in the three months ended March 31, 2012 to 18.9% in the three months ended March 31, 2013. The tax provision rate in the three months ended March 31, 2013 included a benefit for the research tax credit,
which was extended for 2012 and 2013 by legislation passed in January 2013. The inclusion of an annual benefit for 2012 and a quarterly benefit for 2013 during the three months ended March 31, 2013 resulted in a 24.5 percentage point decrease
in our effective tax rate. This decrease was partially offset by a valuation allowance related to a foreign subsidiary, which resulted in a 6.2 percentage point increase in our effective tax rate, and other miscellaneous items that increased
our tax rate 1.8 percentage points for the three months ended March 31, 2013.

[0001193125-13-207088:mdna:89]
[same as prior period, unchanged from 0001193125-12-451437:mdna:56]

[0001193125-13-207088:mdna:90]
As a result of the above factors, net income decreased $5.1 million from $13.0 million in the three months ended March 31, 2012 to $7.9 million in
the three months ended March 31, 2013.

[0001193125-13-207088:mdna:91]
As a percentage of sales, net income decreased from 9.6% in the three months ended March 31,
2012 to 5.5% in the three months ended March 31, 2013.

[0001193125-13-207088:mdna:92]
[same as prior period, unchanged from 0001193125-12-451437:mdna:59]

[0001193125-13-207088:mdna:93]
[same as prior period, unchanged from 0001193125-12-451437:mdna:60]

[0001193125-13-207088:mdna:94]
We intend to finance our
operations with cash flow from operations. We have used, and expect to continue to use, the cash generated from operations for working capital, purchases of treasury stock, dividend payments, and other general corporate purposes, including
(i) product development activities to enhance our existing products and develop new products and (ii) expansion of sales and marketing activities. We believe our cash and cash equivalents, investments and cash generated from operations to
be adequate to meet our operating and capital needs for the foreseeable future.

[0001193125-13-207088:mdna:95]
At March 31, 2013, cash on hand was $58.6 million and
short-term investments were $189.2 million, which resulted in available short-term liquidity of $247.9 million. At December 31, 2012, our cash on hand of $68.5 million and short-term investments of $160.5 million resulted in available
short-term liquidity of $228.9 million. The increase in short-term liquidity from December 31, 2012 to March 31, 2013 primarily reflects funds provided by our operating activities and long-term corporate bonds moving to short-term status,
partially offset by equipment acquisitions, share repurchases and dividends.

[0001193125-13-207088:mdna:96]
[same as prior period, unchanged from 0001193125-12-451437:mdna:63]

[0001193125-13-207088:mdna:97]
Our working capital, which consists of current assets less current liabilities, increased 2.4% from $339.4 million as of December 31, 2012 to $347.6 million as of March 31, 2013. The quick
ratio, defined as cash, cash equivalents, short-term investments, and net accounts receivable, divided by current liabilities, increased from 2.90 as of December 31, 2012 to 2.95 as of March 31, 2013. The current ratio, defined as current
assets divided by current liabilities, decreased from 4.18 as of December 31, 2012 to 4.11 as of March 31, 2013. The increase in our working capital is primarily attributable to an increase in short-term investments and a decrease in
unearned revenue, partially offset by a decrease in inventory and an increase in accounts payable. Generally, fluctuations in unearned revenue result from variations in the timing of customer payments received in advance of revenue recognition and
our revenue recognition under contract terms for hardware acceptance, installation services and post-sale support and maintenance services. We expect inventory levels to fluctuate as we attempt to maintain sufficient inventory in response to
seasonal cycles of our business ensuring competitive lead times while managing the risk of inventory obsolescence that may occur due to rapidly changing technology and customer demand. Generally, fluctuations in accounts payable result from
variations in the timing of the receipt of supplies, inventory and services and our subsequent payments for these purchases.

[0001193125-13-207088:mdna:98]
Net accounts
receivable increased 1.1% from $81.2 million at December 31, 2012 to $82.1 million at March 31, 2013. Our allowance for doubtful accounts was $6 thousand at December 31, 2012 and $21 thousand at March 31, 2013. Quarterly accounts
receivable days sales outstanding (DSO) decreased from 53 days as of December 31, 2012 to 52 days as of March 31, 2013.

[0001193125-13-207088:mdna:99]
Quarterly
inventory turnover increased from 2.8 turns as of December 31, 2012 to 3.0 turns as of March 31, 2013. Inventory decreased 6.6% from December 31, 2012 to March 31, 2013. We expect inventory levels to fluctuate as we attempt to
maintain sufficient inventory in response to seasonal cycles of our business ensuring competitive lead times while managing the risk of inventory obsolescence that may occur due to rapidly changing technology and customer demand.

[0001193125-13-207088:mdna:100]
Accounts payable increased 16.0% from $42.2 million at December 31, 2012 to $48.9 million at March 31, 2013. Accounts payable will fluctuate
due to variations in the timing of the receipt of supplies, inventory and services and our subsequent payments for these purchases.

[0001193125-13-207088:mdna:101]
[same as prior period, unchanged from 0001193125-12-451437:mdna:68]

[0001193125-13-207088:mdna:102]
Capital
expenditures totaled approximately $0.7 million and $4.1 million for the three months ended March 31, 2013 and 2012, respectively. These expenditures were primarily used to purchase manufacturing and test equipment and computer software and
hardware.

[0001193125-13-207088:mdna:103]
Our combined short-term and long-term investments increased $6.5 million from $493.2 million at December 31, 2012 to $499.7
million at March 31, 2013. This increase reflects the impact of additional funds available for investment provided by our operating activities and stock option exercises by our employees, reduced by our cash needs for equipment acquisitions,
share repurchases and dividends, as well as net realized and unrealized losses and amortization of net premiums on our combined investments.

[0001193125-13-207088:mdna:104]
We invest all available cash not required for immediate use in operations primarily in securities that we believe bear minimal risk of loss. At
March 31, 2013 these investments included corporate bonds of $191.3 million, municipal fixed-rate bonds of $172.1 million and municipal variable rate demand notes of $40.8 million. At December 31, 2012, these investments included corporate
bonds of $186.4 million, municipal fixed-rate bonds of $175.1 million and municipal variable rate demand notes of $34.4 million. As of March 31, 2013, our corporate bonds, municipal fixed-rate bonds, and municipal variable rate demand notes
were classified as available-for-sale and had a combined duration of 1.0 years with an average credit rating of AA-. Because our bond portfolio has a high quality rating and contractual maturities of a short duration, we are able to obtain prices
for these bonds derived from observable market inputs, or for similar securities traded in an active market, on a daily basis.

[0001193125-13-207088:mdna:105]
Our long-term
investments decreased 6.7% from $332.7 million at December 31, 2012 to $310.5 million at March 31, 2013. The primary reason for the decrease in our long-term investments during 2013 was the movement of certain long-term corporate bonds and
long-term municipal bonds to short-term status. Long-term investments at March 31, 2013 and December 31, 2012 included an investment in a certificate of deposit of $48.3 million, which serves as collateral for our revenue bonds, as
discussed below. We have various equity investments included in long-term investments at a cost of $22.2 million and $21.0 million, and with a fair value of $33.1 million and $35.2 million, at March 31, 2013 and December 31, 2012,
respectively.

[0001193125-13-207088:mdna:106]
Long-term investments at March 31, 2013 also includes $12.4 million related to our deferred
compensation plans; $1.8 million of other investments carried at cost, consisting of interests in two private equity funds and an investment in a privately held telecommunications equipment manufacturer.

[0001193125-13-207088:mdna:107]
We review our investment portfolio for potential “other-than-temporary” declines in value on an individual investment basis. We assess, on a
quarterly basis, significant declines in value which may be considered other-than-temporary and, if necessary, recognize and record the appropriate charge to write-down the carrying value of such investments. In making this assessment, we take into
consideration qualitative and quantitative information, including but not limited to the following: the magnitude and duration of historical declines in market prices, credit rating activity, assessments of liquidity, public filings, and statements
made by the issuer. We generally begin our identification of potential other-than-temporary impairments by reviewing any security with a fair value that has declined from its original or adjusted cost basis by 25% or more for six or more consecutive
months. We then evaluate the individual security based on the previously identified factors to determine the amount of the write-down, if any. As a result of our review, we recorded an other-than-temporary impairment charge of $4 thousand during the
three months ended March 31, 2013 related to one marketable equity security. For the three months ended March 31, 2012, we recorded an other-than-temporary impairment charge of $33 thousand related to seven marketable equity securities.

[0001193125-13-207088:mdna:108]
[same as prior period, unchanged from 0001193125-12-451437:mdna:76]

[0001193125-13-207088:mdna:109]
[same as prior period, unchanged from 0001193125-12-451437:mdna:77]

[0001193125-13-207088:mdna:110]
In July 2003, our Board of
Directors elected to begin declaring quarterly dividends on our common stock considering the tax treatment of dividends and adequate levels of Company liquidity. During the three months ended March 31, 2013, we paid dividends totaling $5.6
million.

[0001193125-13-207088:mdna:111]
[same as prior period, unchanged from 0001193125-12-451437:mdna:79]

[0001193125-13-207088:mdna:112]
We
have amounts outstanding under loans made pursuant to an Alabama State Industrial Development Authority revenue bond (the Bond) which totaled $46.5 million at March 31, 2013 and December 31, 2012. At March 31,
2013, the estimated fair value of the Bond was approximately $47.9 million, based on a debt security with a comparable interest rate and maturity and a Standard & Poor’s credit rating of A-. Included in long-term investments are
restricted funds in the amount of $48.3 million at March 31, 2013 and December 31, 2012, which is a collateral deposit against the principal amount of the Bond. We have the right to set-off the balance of the Bond with the
collateral deposit in order to reduce the balance of the indebtedness. The Bond matures on January 1, 2020, and bears interest at the rate of 5% per annum. In conjunction with this program, we are eligible to receive certain economic
incentives from the state of Alabama that reduce the amount of payroll withholdings we are required to remit to the state for those employment positions that qualify under this program.

[0001193125-13-207088:mdna:113]
We are required to make payments in the amounts necessary to pay the principal and interest on the amounts currently outstanding. Based on positive cash flow from operating activities, we have
decided to continue early partial redemptions of the Bond. It is our intent to make annual principal payments in addition to the interest amounts that are due. In connection with this decision, $0.5 million of the Bond debt has been classified
as a current liability in accounts payable in the Consolidated Balance Sheet at March 31, 2013.

[0001193125-13-207088:mdna:114]
[same as prior period, unchanged from 0001193125-12-451437:mdna:82]

[0001193125-13-207088:mdna:115]
Since 1997, our Board of Directors has approved multiple share repurchase programs that have authorized open market repurchase
transactions of up to 35 million shares of our common stock. During the three months ended March 31, 2013, we repurchased 1.0 million shares of our common stock at an average price of $22.46 per share. We currently have the authority
to purchase an additional 3.1 million shares of our common stock under the current plan approved by the Board of Directors.

[0001193125-13-207088:mdna:116]
Stock
Option Exercises

[0001193125-13-207088:mdna:117]
To accommodate employee stock option exercises, we issued four thousand shares of treasury stock for $55 thousand during
the three months ended March 31, 2013. During the three months ended March 31, 2012, we issued 0.2 million shares of treasury stock for $3.6 million.

[0001193125-13-207088:mdna:118]
[same as prior period, unchanged from 0001193125-12-451437:mdna:86]

[0001193125-13-207088:mdna:119]
We do not have off-balance sheet financing arrangements and have not engaged in any related party transactions or arrangements with unconsolidated
entities or other persons that are reasonably likely to materially affect liquidity or the availability of or requirements for capital resources. During the three months ended March 31, 2013, there have been no material changes in contractual
obligations and commercial commitments from those discussed in our most recent Annual Report on Form 10-K for the year ended December 31, 2012 filed on February 28, 2013 with the SEC.

[0001193125-13-207088:mdna:120]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, and we have contributed $8.4 million as of March 31,
2013, of which $7.7 million has been applied to these commitments.

[0001193125-13-207088:mdna:121]
[same as prior period, unchanged from 0001193125-12-451437:mdna:89]

[0001193125-13-207088:mdna:122]
The following are some of the risks that could affect our financial performance or could cause actual results to differ materially from those expressed or
implied in our forward-looking statements:

[0001193125-13-207088:mdna:123]
|  | • | Our operating results may fluctuate in future periods, which may adversely affect our stock price. |

[0001193125-13-207088:mdna:124]
|  | • | Our revenue for a particular period can be difficult to predict, and a shortfall in revenue may harm our operating results. |

[0001193125-13-207088:mdna:125]
|  | • | The failure to realize future benefits from the acquisition of the NSN BBA business as significant as we expect may affect our future results of operations and financial condition, and could affect our stock price. |

[0001193125-13-207088:mdna:126]
|  | • | General economic conditions may reduce our revenues and harm our operating results. |

[0001193125-13-207088:mdna:127]
|  | • | Our exposure to the credit risks of our customers and distributors may make it difficult to collect accounts receivable and could adversely affect our operating results and financial condition. |

[0001193125-13-207088:mdna:128]
|  | • | We expect gross margin to vary over time, and our level of product gross margin may not be sustainable. |

[0001193125-13-207088:mdna:129]
|  | • | We must continue to update and improve our products and develop new products in order to compete and to keep pace with improvements in communications technology. |

[0001193125-13-207088:mdna:130]
|  | • | Our products may not continue to comply with the regulations governing their sale, which may harm our business. |

[0001193125-13-207088:mdna:131]
|  | • | Our failure or the failure of our contract manufacturers to comply with applicable environmental regulations could adversely impact our results of operations. |

[0001193125-13-207088:mdna:132]
|  | • | If our products do not interoperate with our customers’ networks, installations may be delayed or cancelled, which could harm our business. |

[0001193125-13-207088:mdna:133]
|  | • | The lengthy approval process required by major and other service providers for new products could result in fluctuations in our revenue. |

[0001193125-13-207088:mdna:134]
|  | • | We engage in research and development activities to improve the application of developed technologies, and as a consequence may miss certain market opportunities enjoyed by larger companies with substantially greater research and development efforts who may focus on more leading edge development. |

[0001193125-13-207088:mdna:135]
|  | • | We depend heavily on sales to certain customers; the loss of any of these customers would significantly reduce our revenues and net income. |

[0001193125-13-207088:mdna:136]
|  | • | Our strategy of outsourcing a portion of our manufacturing requirements to subcontractors located in Asia or other international regions may result in us not meeting our cost, quality or performance standards. |

[0001193125-13-207088:mdna:137]
|  | • | Our dependence on a limited number of suppliers may prevent us from delivering our products on a timely basis, which could have a material adverse effect on customer relations and operating results. |

[0001193125-13-207088:mdna:138]
|  | • | We compete in markets that have become increasingly competitive, which may result in reduced gross profit margins and market share. |

[0001193125-13-207088:mdna:139]
|  | • | Our estimates regarding future warranty obligations may change due to product failure rates, shipment volumes, field service obligations and other rework costs incurred in correcting product failures. If our estimates change, the liability for warranty obligations may be increased or decreased, impacting future cost of goods sold. |

[0001193125-13-207088:mdna:140]
|  | • | Managing our inventory is complex and may include write-downs of excess or obsolete inventory. |

[0001193125-13-207088:mdna:141]
|  | • | The continuing growth of our international operations could expose us to additional risks, increase our costs and adversely affect our operating results and financial condition. |

[0001193125-13-207088:mdna:142]
32

[0001193125-13-207088:mdna:143]
|  | • | We may be adversely affected by fluctuations in currency exchange rates. |

[0001193125-13-207088:mdna:144]
|  | • | Our success depends on our ability to reduce the selling prices of succeeding generations of our products. |

[0001193125-13-207088:mdna:145]
|  | • | Our failure to maintain rights to intellectual property used in our business could adversely affect the development, functionality, and commercial value of our products. |

[0001193125-13-207088:mdna:146]
|  | • | Software under license from third parties for use in certain of our products may not continue to be available to us on commercially reasonable terms. |

[0001193125-13-207088:mdna:147]
|  | • | We may incur liabilities or become subject to litigation that would have a material effect on our business. |

[0001193125-13-207088:mdna:148]
|  | • | Consolidation and deterioration in the competitive service provider market could result in a significant decrease in our revenue. |

[0001193125-13-207088:mdna:149]
|  | • | We depend on distributors who maintain inventories of our products. If the distributors reduce their inventories of these products, our sales could be adversely affected. |

[0001193125-13-207088:mdna:150]
|  | • | If we are unable to successfully develop relationships with system integrators, service providers, and enterprise value added resellers, our sales may be negatively affected. |

[0001193125-13-207088:mdna:151]
|  | • | If we fail to manage our exposure to worldwide financial and securities markets successfully, our operating results and financial statements could be materially impacted. |

[0001193125-13-207088:mdna:152]
|  | • | Changes in our effective tax rate or assessments arising from tax audits may have an adverse impact on our results. |

[0001193125-13-207088:mdna:153]
|  | • | We are required to periodically evaluate the value of our long-lived assets, including the value of intangibles acquired and goodwill resulting from business acquisitions. Any future impairment charges required may adversely affect our operating results. |

[0001193125-13-207088:mdna:154]
|  | • | Our success depends on attracting and retaining key personnel. |

[0001193125-13-207088:mdna:155]
|  | • | Regulatory and potential physical impacts of climate change and other natural events may affect our customers and our production operations, resulting in adverse effects on our operating results. |

[0001193125-13-207088:mdna:156]
|  | • | While we believe our internal control over financial reporting is adequate, a failure to maintain effective internal control over financial reporting as our business expands could result in a loss of investor confidence in our financial reports and have an adverse effect on our stock price. |

[0001193125-13-207088:mdna:157]
|  | • | The price of our common stock has been volatile and may continue to fluctuate significantly. |

[0001193125-13-207088:mdna:158]
The foregoing list of risks is not exclusive. For a more detailed description of the risk factors associated with our business, see Item 1A of our Annual Report on Form 10-K for the year ended
December 31, 2012, filed on February 28, 2013 with the SEC.
