# ADTN notes — 0001193125-13-207088


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001193125-13-207088:notes:1]
[same as prior period, unchanged from 0001193125-12-451437:notes:1]

[0001193125-13-207088:notes:2]
[same as prior period, unchanged from 0001193125-12-451437:notes:2]

[0001193125-13-207088:notes:3]
The following table
summarizes the components of net periodic pension cost for the
three months ended March 31, 2013:

[0001193125-13-207088:notes:4]
|  |  | Three Months Ended |  |
| (In thousands) |  | March 31, 2013 |  |
| Service cost |  | $ | 300 |  |
| Interest cost |  |  | 187 |  |
| Expected return on plan assets |  |  | (253 | ) |
| Net periodic pension cost |  | $ | 234 |  |


## us-gaap:EarningsPerShareTextBlock

[0001193125-13-207088:notes:5]
11. EARNINGS PER
SHARE

[0001193125-13-207088:notes:6]
A summary of the
calculation of basic and diluted earnings per share for the three
months ended March 31, 2013 and 2012 is as follows:

[0001193125-13-207088:notes:7]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands, except per share amounts) |  | 2013 |  |  | 2012 |  |
| Numerator |  |  |  |  |  |  |  |  |
| Net income |  | $ | 7,890 |  |  | $ | 12,960 |  |
| Denominator |  |  |  |  |  |  |  |  |
| Weighted average number of shares – basic |  |  | 61,847 |  |  |  | 63,809 |  |
| Effect of dilutive securities |  |  |  |  |  |  |  |  |
| Stock options |  |  | 162 |  |  |  | 1,008 |  |
| Restricted stock and restricted stock units |  |  | 21 |  |  |  | 32 |  |
| Weighted average number of shares – diluted |  |  | 62,030 |  |  |  | 64,849 |  |
| Net income per share – basic |  | $ | 0.13 |  |  | $ | 0.20 |  |
| Net income per share – diluted |  | $ | 0.13 |  |  | $ | 0.20 |  |

[0001193125-13-207088:notes:8]
Anti-dilutive options to
purchase common stock outstanding were excluded from the above
calculations. Anti-dilutive options totaled 5.4 million
and 1.9 million for the three months ended March 31, 2013
and 2012, respectively.


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0001193125-13-207088:notes:9]
This supplemental pro forma
information does not purport to be indicative of what would have
occurred had the acquisition of the NSN BBA business been completed
on January 1, 2012, nor are they indicative of any future
results.

[0001193125-13-207088:notes:10]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2012 |  |
| Pro forma revenue |  | $ | 33,906 |  |
| Pro forma pre-tax loss |  | $ | (11,645 | ) |
| Weighted average exchange rate during the period (EURO/USD) |  | € | 1.00/$1.31 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001193125-13-207088:notes:11]
14. RELATED PARTY
TRANSACTIONS

[0001193125-13-207088:notes:12]
We employ the law firm of
our director emeritus for legal services. All bills for services
rendered by this firm are reviewed and approved by our Chief
Financial Officer. We believe that the fees for such services are
comparable to those charged by other firms for services rendered to
us. For the three month periods ended March 31, 2013 and 2012,
we incurred fees of $10 thousand per month for these legal
services.


## us-gaap:ScheduleOfAvailableForSaleSecuritiesReconciliationTableTextBlock

[0001193125-13-207088:notes:13]
At March 31, 2013, we
held the following securities and investments, recorded at either
fair value or cost.

[0001193125-13-207088:notes:14]
|  |  |  |  |  | Gross Unrealized |  |  |  |  |
| (In thousands) |  | Amortized Cost |  |  | Gains |  |  | Losses |  |  | Carrying Value |  |
| Deferred compensation plan assets |  | $ | 10,907 |  |  | $ | 1,448 |  |  | $ | (5 | ) |  | $ | 12,350 |  |
| Corporate bonds |  |  | 190,540 |  |  |  | 783 |  |  |  | (18 | ) |  |  | 191,305 |  |
| Municipal fixed-rate bonds |  |  | 171,282 |  |  |  | 849 |  |  |  | (10 | ) |  |  | 172,121 |  |
| Municipal variable rate demand notes |  |  | 40,780 |  |  |  | — |  |  |  | — |  |  |  | 40,780 |  |
| Marketable equity securities |  |  | 22,226 |  |  |  | 11,179 |  |  |  | (309 | ) |  |  | 33,096 |  |
| Available-for-sale securities held at fair value |  | $ | 435,735 |  |  | $ | 14,259 |  |  | $ | (342 | ) |  | $ | 449,652 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 48,250 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1,818 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 499,720 |  |

[0001193125-13-207088:notes:15]
At December 31, 2012,
we held the following securities and investments, recorded at
either fair value or cost.

[0001193125-13-207088:notes:16]
|  |  |  |  |  | Gross Unrealized |  |  |  |  |
| (In thousands) |  | Amortized Cost |  |  | Gains |  |  | Losses |  |  | Carrying Value |  |
| Deferred compensation plan assets |  | $ | 10,688 |  |  | $ | 846 |  |  | $ | (7 | ) |  | $ | 11,527 |  |
| Corporate bonds |  |  | 185,464 |  |  |  | 966 |  |  |  | (18 | ) |  |  | 186,412 |  |
| Municipal fixed-rate bonds |  |  | 174,530 |  |  |  | 627 |  |  |  | (73 | ) |  |  | 175,084 |  |
| Municipal variable rate demand notes |  |  | 34,375 |  |  |  | — |  |  |  | — |  |  |  | 34,375 |  |
| Fixed income bond fund |  |  | 444 |  |  |  | 12 |  |  |  | — |  |  |  | 456 |  |
| Marketable equity securities |  |  | 20,966 |  |  |  | 14,630 |  |  |  | (392 | ) |  |  | 35,204 |  |
| Available-for-sale securities held at fair value |  | $ | 426,467 |  |  | $ | 17,081 |  |  | $ | (490 | ) |  | $ | 443,058 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 48,250 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1,902 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 493,210 |  |


## us-gaap:SubsequentEventsTextBlock

[0001193125-13-207088:notes:17]
16. SUBSEQUENT
EVENTS

[0001193125-13-207088:notes:18]
On April 9, 2013, we
announced that our Board of Directors declared a quarterly cash
dividend of $0.09 per common share to be paid to stockholders of
record at the close of business on April 25, 2013. The payment
date will be May 9, 2013. The quarterly dividend payment will
be approximately $5.3 million. In July 2003, our Board of Directors
elected to begin declaring quarterly dividends on our common stock
considering the tax treatment of dividends and adequate levels of
Company liquidity.

[0001193125-13-207088:notes:19]
During the second quarter
of 2013 and as of May 8, 2013, we repurchased 2.7 million
shares of our common stock through open market purchases at an
average cost of $21.03 per share. We currently have the authority
to purchase an additional 0.3 million shares of our common
stock under the current plan approved by the Board of
Directors.

[0001193125-13-207088:notes:20]
On May 1, 2013, we
announced that our Board of Directors authorized the repurchase of
an additional 5.0 million shares of our common stock to
commence upon completion of the repurchase plan announced on
October 11, 2011. This new authorization will be implemented
through open market or private purchases from time to time as
conditions warrant.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-13-207088:notes:21]
[same as prior period, unchanged from 0001193125-12-451437:notes:20]

[0001193125-13-207088:notes:22]
Our effective tax rate
decreased from 35.4% in the three months ended March 31, 2012
to 18.9% in the three months ended March 31, 2013. The
tax provision rate in the three months ended March 31, 2013
included a benefit for the research tax credit, which was extended
for 2012 and 2013 by legislation passed in January 2013. The
inclusion of an annual benefit for 2012 and a quarterly benefit for
2013 during the three months ended March 31, 2013 resulted in
a 24.5 percentage point decrease in our effective tax
rate. This decrease was partially offset by a valuation
allowance related to a foreign subsidiary, which resulted in a 6.2
percentage point increase in our effective tax rate, and other
miscellaneous items that increased our tax rate 1.8 percentage
points for the three months ended March 31, 2013.


## us-gaap:ScheduleOfSegmentReportingInformationBySegmentTextBlock

[0001193125-13-207088:notes:23]
The following table
presents information about the reported sales and gross profit of
our reportable segments for the three months ended March 31,
2013 and 2012. Asset information by reportable segment is not
reported, since we do not produce such information
internally.

[0001193125-13-207088:notes:24]
|  |  | Three Months Ended |  |
|  |  | March 31, 2013 |  |  | March 31, 2012 |  |
| (In thousands) |  | Sales |  |  | Gross Profit |  |  | Sales |  |  | Gross Profit |  |
| Carrier Networks |  | $ | 109,887 |  |  | $ | 51,591 |  |  | $ | 96,654 |  |  | $ | 52,883 |  |
| Enterprise Networks |  |  | 33,126 |  |  |  | 18,086 |  |  |  | 38,081 |  |  |  | 21,204 |  |
| Total |  | $ | 143,013 |  |  | $ | 69,677 |  |  | $ | 134,735 |  |  | $ | 74,087 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001193125-13-207088:notes:25]
We have categorized our
cash equivalents held in money market funds and our investments
held at fair value into a three-level fair value hierarchy based on
the priority of the inputs to the valuation technique for the cash
equivalents and investments as follows: Level 1 – Values
based on unadjusted quoted prices for identical assets or
liabilities in an active market; Level 2 – Values based on
quoted prices in markets that are not active or model inputs that
are observable either directly or indirectly; Level 3 –
Values based on prices or valuation techniques that require inputs
that are both unobservable and significant to the overall fair
value measurement. These inputs include information supplied by
investees.

[0001193125-13-207088:notes:26]
|  |  | Fair Value Measurements at March 31, 2013 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 19,140 |  |  | $ | 19,140 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 12,350 |  |  |  | 12,350 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 191,305 |  |  |  | — |  |  |  | 191,305 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 172,121 |  |  |  | — |  |  |  | 172,121 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 40,780 |  |  |  | — |  |  |  | 40,780 |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity securities – technology industry |  |  | 9,307 |  |  |  | 9,307 |  |  |  | — |  |  |  | — |  |
| Equity securities – other |  |  | 23,789 |  |  |  | 23,789 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 449,652 |  |  |  | 45,446 |  |  |  | 404,206 |  |  |  | — |  |
| Total |  | $ | 468,792 |  |  | $ | 64,586 |  |  | $ | 404,206 |  |  | $ | — |  |
|  |  | Fair Value Measurements at December 31, 2012 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 28,071 |  |  | $ | 28,071 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 11,527 |  |  |  | 11,527 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 186,412 |  |  |  | — |  |  |  | 186,412 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 175,084 |  |  |  | — |  |  |  | 175,084 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 34,375 |  |  |  | — |  |  |  | 34,375 |  |  |  | — |  |
| Fixed income bond fund |  |  | 456 |  |  |  | 456 |  |  |  | — |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity securities – technology industry |  |  | 14,099 |  |  |  | 14,099 |  |  |  | — |  |  |  | — |  |
| Equity securities – other |  |  | 21,105 |  |  |  | 21,105 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 443,058 |  |  |  | 47,187 |  |  |  | 395,871 |  |  |  | — |  |
| Total |  | $ | 471,129 |  |  | $ | 75,258 |  |  | $ | 395,871 |  |  | $ | — |  |


## us-gaap:ScheduleOfStockholdersEquityTableTextBlock

[0001193125-13-207088:notes:27]
A summary of the changes in
stockholders’ equity for the three months ended
March 31, 2013 is as follows:

[0001193125-13-207088:notes:28]
| (In thousands) |  | Stockholders’ Equity |  |
| Balance, December 31, 2012 |  | $ | 692,406 |  |
| Net income |  |  | 7,890 |  |
| Dividend payments |  |  | (5,586 | ) |
| Dividends accrued for unvested restricted stock units |  |  | (2 | ) |
| Unrealized gains and losses on available-for-sale securities (net of tax) |  |  | (1,644 | ) |
| Foreign currency translation adjustment |  |  | 323 |  |
| Proceeds from stock option exercises |  |  | 55 |  |
| Purchase of treasury stock |  |  | (22,546 | ) |
| Stock-based compensation expense |  |  | 2,232 |  |
| Balance, March 31, 2013 |  | $ | 673,128 |  |


## us-gaap:ConsolidationPolicyTextBlock

[0001193125-13-207088:notes:29]
[same as prior period, unchanged from 0001193125-12-451437:notes:31]

[0001193125-13-207088:notes:30]
The
accompanying unaudited consolidated financial statements of
ADTRAN®,
Inc. and its subsidiaries (ADTRAN) have been prepared pursuant to
the rules and regulations for reporting on Quarterly Reports on
Form 10-Q. Accordingly, certain information and notes required by
generally accepted accounting principles for complete financial
statements are not included herein. The December 31, 2012
Consolidated Balance Sheet is derived from audited financial
statements, but does not include all disclosures required by
accounting principles generally accepted in the United
States.

[0001193125-13-207088:notes:31]
In the opinion of
management, all adjustments necessary for a fair presentation of
these interim statements have been included and are of a normal and
recurring nature. The results of operations for an interim period
are not necessarily indicative of the results for the full year.
The interim statements should be read in conjunction with the
financial statements and notes thereto included in ADTRAN’s
Annual Report on Form 10-K for the year ended December 31,
2012, filed on February 28, 2013 with the SEC.


## us-gaap:InventoryDisclosureTextBlock

[0001193125-13-207088:notes:32]
8.
INVENTORY

[0001193125-13-207088:notes:33]
At March 31, 2013 and
December 31, 2012, inventory consisted of the
following:

[0001193125-13-207088:notes:34]
|  |  | March 31, |  |  | December 31, |  |
| (In thousands) |  | 2013 |  |  | 2012 |  |
| Raw materials |  | $ | 46,049 |  |  | $ | 47,054 |  |
| Work in process |  |  | 5,020 |  |  |  | 3,262 |  |
| Finished goods |  |  | 44,698 |  |  |  | 52,267 |  |
| Total |  | $ | 95,767 |  |  | $ | 102,583 |  |

[0001193125-13-207088:notes:35]
We establish reserves for
estimated excess, obsolete, or unmarketable inventory equal to the
difference between the cost of the inventory and the estimated fair
value of the inventory based upon assumptions about future demand
and market conditions. At March 31, 2013 and December 31,
2012, raw materials reserves totaled $14.1 million and $9.9
million, respectively, and finished goods inventory reserves
totaled $2.5 million and $2.1 million, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001193125-13-207088:notes:36]
10. STOCKHOLDERS’
EQUITY

[0001193125-13-207088:notes:37]
[same as prior period, unchanged from 0001193125-12-451437:notes:39]

[0001193125-13-207088:notes:38]
Since 1997, our Board of
Directors has approved multiple share repurchase programs that have
authorized open market repurchase transactions of up to
35 million shares of our common stock. During the three months
ended March 31, 2013, we repurchased 1.0 million shares
of our common stock at an average price of $22.46 per share. We
currently have the authority to purchase an additional
3.1 million shares of our common stock under the current plan
approved by the Board of Directors.

[0001193125-13-207088:notes:39]
[same as prior period, unchanged from 0001193125-12-451437:notes:41]

[0001193125-13-207088:notes:40]
We issued four thousand
shares of treasury stock during the three months ended
March 31, 2013 to accommodate employee stock option exercises.
The stock options had exercise prices of $15.29. We received
proceeds totaling $55 thousand from the exercise of these stock
options during the three months ended March 31,
2013.

[0001193125-13-207088:notes:41]
[same as prior period, unchanged from 0001193125-12-451437:notes:43]

[0001193125-13-207088:notes:42]
During the three months
ended March 31, 2013, we paid cash dividends as follows (in
thousands except per share amount):

[0001193125-13-207088:notes:43]
| Record Date |  | Payment Date |  |  | Per Share Amount |  |  | Total Dividend Paid |  |
| February 7, 2013 |  |  | February 21, 2013 |  |  | $ | 0.09 |  |  | $ | 5,586 |  |

[0001193125-13-207088:notes:44]
[same as prior period, unchanged from 0001193125-12-451437:notes:46]

[0001193125-13-207088:notes:45]
Other comprehensive income
consists of unrealized gains (losses) on available-for-sale
securities, reclassification adjustments for amounts included in
net income related to impairments of available-for-sale securities
and realized gains (losses) on available-for-sale securities,
defined benefit plan adjustments and foreign currency translation
adjustments.

[0001193125-13-207088:notes:46]
The following tables
present the details of reclassifications out of accumulated other
comprehensive income for the three months ended March 31, 2013
and 2012:

[0001193125-13-207088:notes:47]
| (In thousands) |  | Three Months Ended March 31, 2013 |  |
| Details about Accumulated Other Comprehensive Income Components |  | Amount Reclassified from Accumulated Other Comprehensive Income |  |  | Affected Line Item in the Statement Where Net Income Is Presented |  |
| Unrealized gains (losses) on available-for-sale securities: |  |  |  |  |  |  |  |  |
| Realized gain on sales of securities |  | $ | 3,444 |  |  |  | Net realized investment gain |  |
| Impairment expense |  |  | (4 | ) |  |  | Net realized investment gain |  |
| Total reclassifications for the period, before tax |  |  | 3,440 |  |  |  |  |  |
| Tax (expense) benefit |  |  | (1,342 | ) |  |  |  |  |
| Total reclassifications for the period, net of tax |  | $ | 2,098 |  |  |  |  |  |
| (In thousands) |  | Three Months Ended March 31, 2012 |  |
| Details about Accumulated Other Comprehensive Income Components |  | Amount Reclassified from Accumulated Other Comprehensive Income |  |  | Affected Line Item in the Statement Where Net Income Is Presented |  |
| Unrealized gains (losses) on available-for-sale securities: |  |  |  |  |  |  |  |  |
| Realized gain on sales of securities |  | $ | 2,406 |  |  |  | Net realized investment gain |  |
| Impairment expense |  |  | (33 | ) |  |  | Net realized investment gain |  |
| Total reclassifications for the period, before tax |  |  | 2,373 |  |  |  |  |  |
| Tax (expense) benefit |  |  | (925 | ) |  |  |  |  |
| Total reclassifications for the period, net of tax |  | $ | 1,448 |  |  |  |  |  |

[0001193125-13-207088:notes:48]
The following tables
present changes in accumulated other comprehensive income, net of
tax, by component for the three months ended March 31, 2013
and 2012:

[0001193125-13-207088:notes:49]
|  |  | Three Months Ended March 31, 2013 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | Total |  |
| Beginning balance |  | $ | 10,108 |  |  | $ | (1,952 | ) |  | $ | 3,112 |  |  | $ | 11,268 |  |
| Other comprehensive income (loss) before reclassifications |  |  | 454 |  |  |  | — |  |  |  | 323 |  |  |  | 777 |  |
| Amounts reclassified from accumulated other comprehensive income |  |  | (2,098 | ) |  |  | — |  |  |  | — |  |  |  | (2,098 | ) |
| Net current period other comprehensive income (loss) |  |  | (1,644 | ) |  |  | — |  |  |  | 323 |  |  |  | (1,321 | ) |
| Ending balance |  | $ | 8,464 |  |  | $ | (1,952 | ) |  | $ | 3,435 |  |  | $ | 9,947 |  |

[0001193125-13-207088:notes:50]
|  |  | Three Months Ended March 31, 2012 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Foreign Currency Adjustments |  |  | Total |  |
| Beginning balance |  | $ | 10,160 |  |  | $ | 2,942 |  |  | $ | 13,102 |  |
| Other comprehensive income (loss) before reclassifications |  |  | 8,205 |  |  |  | 153 |  |  |  | 8,358 |  |
| Amounts reclassified from accumulated other comprehensive income |  |  | (1,448 | ) |  |  | — |  |  |  | (1,448 | ) |
| Net current period other comprehensive income (loss) |  |  | 6,757 |  |  |  | 153 |  |  |  | 6,910 |  |
| Ending balance |  | $ | 16,917 |  |  | $ | 3,095 |  |  | $ | 20,012 |  |

[0001193125-13-207088:notes:51]
The following table
presents the tax effects related to the change in each component of
other comprehensive income for the three months ended
March 31, 2013 and 2012:

[0001193125-13-207088:notes:52]
|  |  | Three Months Ended March 31, 2013 |  |  | Three Months Ended March 31, 2012 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |
| Unrealized gains (losses) on available-for-sale securities |  | $ | 744 |  |  | $ | (290 | ) |  | $ | 454 |  |  | $ | 13,449 |  |  | $ | (5,244 | ) |  | $ | 8,205 |  |
| Reclassification adjustment for amounts included in net income |  |  | (3,440 | ) |  |  | 1,342 |  |  |  | (2,098 | ) |  |  | (2,373 | ) |  |  | 925 |  |  |  | (1,448 | ) |
| Foreign currency translation adjustment |  |  | 323 |  |  |  | — |  |  |  | 323 |  |  |  | 153 |  |  |  | — |  |  |  | 153 |  |
| Total Other Comprehensive Income (Loss) |  | $ | (2,373 | ) |  | $ | 1,052 |  |  | $ | (1,321 | ) |  | $ | 11,229 |  |  | $ | (4,319 | ) |  | $ | 6,910 |  |


## us-gaap:ScheduleOfPurchasePriceAllocationTableTextBlock

[0001193125-13-207088:notes:53]
The preliminary allocation
of the purchase price to the estimated fair value of the assets
acquired and liabilities assumed at the acquisition date is as
follows:

[0001193125-13-207088:notes:54]
| (In Thousands) |  |  |  |
| Other receivables |  | $ | 9,486 |  |
| Inventory |  |  | 22,278 |  |
| Property, plant and equipment |  |  | 5,035 |  |
| Accounts payable |  |  | (5,194 | ) |
| Unearned revenue |  |  | (19,413 | ) |
| Accrued expenses |  |  | (1,931 | ) |
| Accrued wages and benefits |  |  | (2,251 | ) |
| Deferred tax liability |  |  | (788 | ) |
| Non-current unearned revenue |  |  | (21,316 | ) |
| Net liabilities assumed |  |  | (14,094 | ) |
| Customer relationships |  |  | 5,162 |  |
| Developed technology |  |  | 3,176 |  |
| Other |  |  | 13 |  |
| Gain on bargain purchase of a business, net of tax |  |  | (1,753 | ) |
| Net consideration received by buyer |  | $ | (7,496 | ) |


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001193125-13-207088:notes:55]
As of March 31, 2013,
our corporate bonds and municipal fixed-rate bonds had the
following contractual maturities:

[0001193125-13-207088:notes:56]
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |
| Less than one year |  | $ | 79,983 |  |  | $ | 64,292 |  |
| One to two years |  |  | 55,000 |  |  |  | 30,694 |  |
| Two to three years |  |  | 53,098 |  |  |  | 50,405 |  |
| Three to five years |  |  | 3,224 |  |  |  | 26,730 |  |
| Total |  | $ | 191,305 |  |  | $ | 172,121 |  |


## us-gaap:ScheduleOfRealizedGainLossTableTextBlock

[0001193125-13-207088:notes:57]
The following table
presents gross realized gains and losses related to our
investments.

[0001193125-13-207088:notes:58]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2013 |  |  | 2012 |  |
| Gross realized gains |  | $ | 3,727 |  |  | $ | 2,669 |  |
| Gross realized losses |  | $ | (82 | ) |  | $ | (202 | ) |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001193125-13-207088:notes:59]
7. DERIVATIVE
INSTRUMENTS AND HEDGING ACTIVITIES

[0001193125-13-207088:notes:60]
We have certain
international customers who are billed in their local currency.
Changes in the monetary exchange rates may adversely affect our
results of operations and financial condition. When appropriate, we
enter into various derivative transactions to enhance our ability
to manage the volatility relating to these typical business
exposures. We do not hold or issue derivative instruments for
trading or other speculative purposes. Our derivative instruments
are recorded in the Consolidated Balance Sheets at their fair
values. Our derivative instruments are not designated as hedges,
and accordingly, all changes in the fair value of the instruments
are recognized as other income (expense) in the Consolidated
Statements of Income. The maximum time frame for our derivatives is
currently less than twelve months. Our derivative instruments are
not subject to master netting arrangements and are not offset in
the Consolidated Balance Sheets.

[0001193125-13-207088:notes:61]
As of March 31, 2013,
we had forward contracts and swaps outstanding with notional
amounts totaling €4.9 million ($6.3 million) and
€1.8 million ($2.4 million), respectively, which mature
through 2013.

[0001193125-13-207088:notes:62]
The fair values of our
derivative instruments recorded in the Consolidated Balance Sheet
as of March 31, 2013 were as follows:

[0001193125-13-207088:notes:63]
|  |  | March 31, 2013 |  |
| (In thousands) |  | Balance Sheet Location |  |  | Fair Value |  |
| Derivatives Not Designated as Hedging Instruments: |  |  |  |  |  |  |  |  |
| Foreign exchange contracts – asset derivatives |  |  | Other receivables |  |  | $ | 25 |  |
| Foreign exchange contracts – liability derivatives |  |  | Accounts payable |  |  | $ | (237 | ) |

[0001193125-13-207088:notes:64]
The change in the fair
values of our derivative instruments recorded in the Consolidated
Statements of Income during the three months ended March 31,
2013 were as follows:

[0001193125-13-207088:notes:65]
| (In thousands) |  | Income Statement Location |  |  | Three Months Ended March 31, 2013 |  |
| Derivatives Not Designated as Hedging Instruments: |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  |  | Other income (expense) |  |  | $ | (224 | ) |


## us-gaap:ScheduleofFiniteLivedIntangibleAssetsFutureAmortizationExpenseTableTextBlock

[0001193125-13-207088:notes:66]
As of March 31, 2013,
the estimated future amortization expense of our intangible assets
is as follows:

[0001193125-13-207088:notes:67]
| (In thousands) |  | Amount |  |
| Remainder of 2013 |  | $ | 1,804 |  |
| 2014 |  |  | 2,251 |  |
| 2015 |  |  | 2,116 |  |
| 2016 |  |  | 1,845 |  |
| 2017 |  |  | 1,255 |  |
| Thereafter |  |  | 2,641 |  |
| Total |  | $ | 11,912 |  |


## us-gaap:ScheduleOfRevenuesFromExternalCustomersAndLongLivedAssetsByGeographicalAreasTableTextBlock

[0001193125-13-207088:notes:68]
The following table
presents sales information by geographic area for the three months
ended March 31, 2013 and 2012. International sales correlate
to shipments with a non-U.S. destination.

[0001193125-13-207088:notes:69]
|  |  | Three Months Ended |  |
| (In thousands) |  | March 31, |  |
|  | 2013 |  |  | 2012 |  |
| United States |  | $ | 108,106 |  |  | $ | 116,443 |  |
| International |  |  | 34,907 |  |  |  | 18,292 |  |
| Total |  | $ | 143,013 |  |  | $ | 134,735 |  |


## us-gaap:ScheduleOfShareBasedCompensationStockOptionsActivityTableTextBlock

[0001193125-13-207088:notes:70]
The following table is a
summary of our stock options outstanding as of December 31,
2012 and March 31, 2013 and the changes that occurred during
the three months ended March 31, 2013:

[0001193125-13-207088:notes:71]
| (In thousands, except per share amounts) |  | Number of Options |  |  | Weighted Avg. Exercise Price |  |  | Weighted Avg. Remaining Contractual Life In Years |  |  | Aggregate Intrinsic Value |  |
| Options outstanding, December 31, 2012 |  |  | 6,035 |  |  | $ | 24.81 |  |  |  | 6.69 |  |  | $ | 5,154 |  |
| Options granted |  |  | — |  |  | $ | — |  |  |  |  |  |  |  |  |  |
| Options cancelled/forfeited |  |  | (46 | ) |  | $ | 26.33 |  |  |  |  |  |  |  |  |  |
| Options exercised |  |  | (4 | ) |  | $ | 15.29 |  |  |  |  |  |  |  |  |  |
| Options outstanding, March 31, 2013 |  |  | 5,985 |  |  | $ | 24.80 |  |  |  | 6.46 |  |  | $ | 5,290 |  |
| Options exercisable, March 31, 2013 |  |  | 3,528 |  |  | $ | 24.81 |  |  |  | 4.95 |  |  | $ | 2,628 |  |


## us-gaap:ScheduleOfEntityWideInformationRevenueFromExternalCustomersByProductsAndServicesTextBlock

[0001193125-13-207088:notes:72]
The table below presents
sales information by product category for the three months ended
March 31, 2013 and 2012.

[0001193125-13-207088:notes:73]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2013 |  |  | 2012 |  |
| Carrier Systems |  | $ | 92,804 |  |  | $ | 71,258 |  |
| Business Networking |  |  | 38,076 |  |  |  | 43,142 |  |
| Loop Access |  |  | 12,133 |  |  |  | 20,335 |  |
| Total |  | $ | 143,013 |  |  | $ | 134,735 |  |


## us-gaap:GoodwillDisclosureTextBlock

[0001193125-13-207088:notes:74]
9. GOODWILL AND
INTANGIBLE ASSETS

[0001193125-13-207088:notes:75]
The changes in the carrying
value of goodwill, all of which is included in our Enterprise
Networks division, for the three months ended March 31, 2013
are as follows:

[0001193125-13-207088:notes:76]
| (In thousands) |  |  |  |
| Balance, December 31, 2012 |  | $ | 3,492 |  |
| Acquisitions |  |  | — |  |
| Impairment losses |  |  | — |  |
| Balance, March 31, 2013 |  | $ | 3,492 |  |
| Balance as of March 31, 2013 |  |  |  |  |
| Goodwill |  | $ | 3,492 |  |
| Accumulated impairment losses |  |  | — |  |
| Total goodwill |  | $ | 3,492 |  |

[0001193125-13-207088:notes:77]
We evaluate the carrying
value of goodwill during the fourth quarter of each year and
between annual evaluations if events occur or circumstances change
that would more likely than not reduce the fair value of the
reporting unit below its carrying amount. When evaluating whether
goodwill is impaired, we first assess qualitative factors to
determine whether it is necessary to perform the two-step
quantitative goodwill impairment test. If we determine that the
two-step quantitative test is necessary, then we compare the fair
value of the reporting unit to which the goodwill is assigned to
the reporting unit’s carrying amount, including goodwill. If
the carrying amount of the reporting unit exceeds its fair value,
then the amount of the impairment loss is measured. There were no
impairment losses recorded during the three months ended
March 31, 2013 or 2012.

[0001193125-13-207088:notes:78]
Intangible assets are
included in other assets in the accompanying Consolidated Balance
Sheets and include intangibles acquired in conjunction with our
acquisition of Objectworld Communications Corporation on
September 15, 2009, Bluesocket, Inc. on August 4, 2011,
and the NSN BBA business on May 4, 2012.

[0001193125-13-207088:notes:79]
The following table
presents our intangible assets as of March 31, 2013 and
December 31, 2012:

[0001193125-13-207088:notes:80]
|  |  | March 31, 2013 |  |  | December 31, 2012 |  |
| (In thousands) |  | Gross Value |  |  | Accumulated Amortization |  |  | Net Value |  |  | Gross Value |  |  | Accumulated Amortization |  |  | Net Value |  |
| Customer relationships |  | $ | 6,622 |  |  | $ | (939 | ) |  | $ | 5,683 |  |  | $ | 6,769 |  |  | $ | (766 | ) |  | $ | 6,003 |  |
| Developed technology |  |  | 6,306 |  |  |  | (1,661 | ) |  |  | 4,645 |  |  |  | 6,397 |  |  |  | (1,354 | ) |  |  | 5,043 |  |
| Intellectual property |  |  | 2,340 |  |  |  | (935 | ) |  |  | 1,405 |  |  |  | 2,340 |  |  |  | (851 | ) |  |  | 1,489 |  |
| Trade names |  |  | 270 |  |  |  | (100 | ) |  |  | 170 |  |  |  | 270 |  |  |  | (85 | ) |  |  | 185 |  |
| Other |  |  | 13 |  |  |  | (4 | ) |  |  | 9 |  |  |  | 13 |  |  |  | (3 | ) |  |  | 10 |  |
| Total |  | $ | 15,551 |  |  | $ | (3,639 | ) |  | $ | 11,912 |  |  | $ | 15,789 |  |  | $ | (3,059 | ) |  | $ | 12,730 |  |

[0001193125-13-207088:notes:81]
Amortization expense, all
of which relates to business acquisitions, was $0.6 million and
$0.3 million for the three months ended March 31, 2013 and
2012, respectively.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-13-207088:notes:82]
[same as prior period, unchanged from 0001193125-12-451437:notes:71]

[0001193125-13-207088:notes:83]
The following table
summarizes the stock-based compensation expense related to stock
options, restricted stock units (RSUs) and restricted stock for the
three months ended March 31, 2013 and 2012, which was
recognized as follows:

[0001193125-13-207088:notes:84]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2013 |  |  | 2012 |  |
| Stock-based compensation expense included in cost of sales |  | $ | 106 |  |  | $ | 101 |  |
| Selling, general and administrative expense |  |  | 1,063 |  |  |  | 1,051 |  |
| Research and development expense |  |  | 1,063 |  |  |  | 1,069 |  |
| Stock-based compensation expense included in operating expenses |  |  | 2,126 |  |  |  | 2,120 |  |
| Total stock-based compensation expense |  |  | 2,232 |  |  |  | 2,221 |  |
| Tax benefit for expense associated with non-qualified options |  |  | (307 | ) |  |  | (301 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 1,925 |  |  | $ | 1,920 |  |

[0001193125-13-207088:notes:85]
[same as prior period, unchanged from 0001193125-12-451437:notes:74]

[0001193125-13-207088:notes:86]
There were no options
granted during the three months ended March 31, 2013 or
2012.

[0001193125-13-207088:notes:87]
The fair value of our RSUs
is calculated using a Monte Carlo Simulation valuation method.
There were no RSU grants during the three months ended
March 31, 2013 or 2012.

[0001193125-13-207088:notes:88]
The fair value of
restricted stock is equal to the closing price of our stock on the
date of grant. There were no restricted stock grants during the
three months ended March 31, 2013 or 2012.

[0001193125-13-207088:notes:89]
Stock-based compensation
expense recognized in our Consolidated Statements of Income for the
three months ended March 31, 2013 and 2012 is based on
options, RSUs and restricted stock ultimately expected to vest, and
has been reduced for estimated forfeitures. Estimated forfeitures
for stock options were based upon historical experience and
approximate 1.6% annually. We estimated a 0% forfeiture rate for
our RSUs and restricted stock due to the limited number of
recipients and historical experience for these awards.

[0001193125-13-207088:notes:90]
As of March 31, 2013,
total compensation expense related to non-vested stock options,
RSUs and restricted stock not yet recognized was approximately
$16.9 million, which is expected to be recognized over an average
remaining recognition period of 2.4 years.

[0001193125-13-207088:notes:91]
The aggregate intrinsic
values in the table above represent the total pre-tax intrinsic
value (the difference between ADTRAN’s closing stock price on
the last trading day of the quarter and the exercise price,
multiplied by the number of in-the-money options) that would have
been received by the option holders had all option holders
exercised their options on March 31, 2013. The aggregate
intrinsic value will change based on the fair market value of
ADTRAN’s stock.

[0001193125-13-207088:notes:92]
The total pre-tax intrinsic
value of options exercised during the three month period ended
March 31, 2013 was $21 thousand.

[0001193125-13-207088:notes:93]
The following table is a
summary of our RSUs and restricted stock outstanding as of
December 31, 2012 and March 31, 2013 and the changes that
occurred during the three months ended March 31,
2013:

[0001193125-13-207088:notes:94]
| (In thousands, except per share amounts) |  | Number of Shares |  |  | Weighted Average Grant Date Fair Value |  |
| Unvested RSUs and restricted stock outstanding, December 31, 2012 |  |  | 103 |  |  | $ | 29.25 |  |
| RSUs and restricted stock granted |  |  | — |  |  | $ | — |  |
| RSUs and restricted stock vested |  |  | — |  |  | $ | — |  |
| RSUs and restricted stock cancelled/forfeited |  |  | — |  |  | $ | — |  |
| Unvested RSUs and restricted stock, March 31, 2013 |  |  | 103 |  |  | $ | 29.25 |  |


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001193125-13-207088:notes:95]
13. LIABILITY FOR
WARRANTY RETURNS

[0001193125-13-207088:notes:96]
Our products generally
include warranties of 90 days to ten years for product defects. We
accrue for warranty returns at the time revenue is recognized based
on our estimate of the cost to repair or replace the defective
products. We engage in extensive product quality programs and
processes, including actively monitoring and evaluating the quality
of our component suppliers. Our products continue to become more
complex in both size and functionality as many of our product
offerings migrate from line card applications to systems products.
The increasing complexity of our products will cause warranty
incidences, when they arise, to be more costly. Our estimates
regarding future warranty obligations may change due to product
failure rates, material usage, and other rework costs incurred in
correcting a product failure. In addition, from time to time,
specific warranty accruals may be recorded if unforeseen problems
arise. Should our actual experience relative to these factors be
worse than our estimates, we will be required to record additional
warranty expense. Alternatively, if we provide for more reserves
than we require, we will reverse a portion of such provisions in
future periods. The liability for warranty obligations totaled $8.8
million at March 31, 2013 and $9.7 million at
December 31, 2012. These liabilities are included in accrued
expenses in the accompanying Consolidated Balance
Sheets.

[0001193125-13-207088:notes:97]
A summary of warranty
expense and write-off activity for the three months ended
March 31, 2013 and 2012 is as follows:

[0001193125-13-207088:notes:98]
| Three Months Ended March 31, |  | 2013 |  |  | 2012 |  |
| (In thousands) |  |  |  |  |  |  |
| Balance at beginning of period |  | $ | 9,653 |  |  | $ | 4,118 |  |
| Plus: Amounts charged to cost and expenses |  |  | 397 |  |  |  | 1,181 |  |
| Less: Deductions |  |  | (1,258 | ) |  |  | (568 | ) |
| Balance at end of period |  | $ | 8,792 |  |  | $ | 4,731 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-13-207088:notes:99]
15. COMMITMENTS AND
CONTINGENCIES

[0001193125-13-207088:notes:100]
In the ordinary course of
business, we may be subject to various legal proceedings and
claims, including employment disputes, patent claims, disputes over
contract agreements and other commercial disputes. In some cases,
claimants seek damages or other relief, such as royalty payments
related to patents, which, if granted, could require significant
expenditures. Although the outcome of any claim or litigation can
never be certain, it is our opinion that the outcome of all
contingencies of which we are currently aware will not materially
affect our business, operations, financial condition or cash
flows.

[0001193125-13-207088:notes:101]
We have committed to invest
up to an aggregate of $7.9 million in two private equity funds, and
we have contributed $8.4 million as of March 31, 2013, of
which $7.7 million has been applied to these
commitments.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-13-207088:notes:102]
12. SEGMENT
INFORMATION

[0001193125-13-207088:notes:103]
[same as prior period, unchanged from 0001193125-12-451437:notes:93]

[0001193125-13-207088:notes:104]
[same as prior period, unchanged from 0001193125-12-451437:notes:94]

[0001193125-13-207088:notes:105]
[same as prior period, unchanged from 0001193125-12-451437:notes:95]

[0001193125-13-207088:notes:106]
Carrier Systems
products are used by communications service providers to provide
data, voice and video services to consumers and enterprises. This
category includes the following product areas and related
services:

[0001193125-13-207088:notes:107]
|  | • |  | Broadband Access |

[0001193125-13-207088:notes:108]
|  | • |  | Total Access® 5000 Multi-Service Access and Aggregation Platform (MSAP) |

[0001193125-13-207088:notes:109]
|  | • |  | hiX family of MSAPs |

[0001193125-13-207088:notes:110]
|  | • |  | Total Access 1100/1200 Series of Fiber to the Node (FTTN) products |

[0001193125-13-207088:notes:111]
|  | • |  | Ultra Broadband Ethernet (UBE) |

[0001193125-13-207088:notes:112]
|  | • |  | Digital Subscriber Line Access Multiplexer (DSLAM) products |

[0001193125-13-207088:notes:113]
|  | • |  | Optical |

[0001193125-13-207088:notes:114]
|  | • |  | Optical Networking Edge (ONE) |

[0001193125-13-207088:notes:115]
|  | • |  | NetVanta 8000 Series |

[0001193125-13-207088:notes:116]
|  | • |  | OPTI and TA 3000 optical products |

[0001193125-13-207088:notes:117]
|  | • |  | Small Form-Factor Pluggable (SFP) products |

[0001193125-13-207088:notes:118]
|  | • |  | TDM systems |

[0001193125-13-207088:notes:119]
|  | • |  | Network Management Solutions |

[0001193125-13-207088:notes:120]
Business Networking
products provide access to telecommunication services and
facilitate the delivery of cloud connectivity, enterprise
communications and virtual mobility to the small and mid-sized
enterprise (SME) market. This category includes the following
product areas and related services:

[0001193125-13-207088:notes:121]
|  | • |  | Internetworking products |

[0001193125-13-207088:notes:122]
|  | • |  | Total Access IP Business Gateways |

[0001193125-13-207088:notes:123]
|  | • |  | Optical Network Terminals (ONTs) |

[0001193125-13-207088:notes:124]
|  | • |  | Bluesocket® virtual Wireless LAN (WLAN) |

[0001193125-13-207088:notes:125]
|  | • |  | NetVanta® |

[0001193125-13-207088:notes:126]
|  | • |  | Multiservice Routers |

[0001193125-13-207088:notes:127]
|  | • |  | Managed Ethernet Switches |

[0001193125-13-207088:notes:128]
|  | • |  | IP Business Gateways |

[0001193125-13-207088:notes:129]
|  | • |  | Unified Communications (UC) solutions |

[0001193125-13-207088:notes:130]
|  | • |  | Carrier Ethernet Network Terminating Equipment (NTE) |

[0001193125-13-207088:notes:131]
|  | • |  | Integrated Access Devices (IADs) |

[0001193125-13-207088:notes:132]
Loop Access products
are used by carrier and enterprise customers for access to
copper-based telecommunications networks. The Loop Access category
includes the following product areas:

[0001193125-13-207088:notes:133]
|  | • |  | High bit-rate Digital Subscriber Line (HDSL) products |

[0001193125-13-207088:notes:134]
|  | • |  | Digital Data Service (DDS) |

[0001193125-13-207088:notes:135]
|  | • |  | Integrated Services Digital Network (ISDN) products |

[0001193125-13-207088:notes:136]
|  | • |  | T1/E1/T3 Channel Service Units/Data Service Units (CSUs/DSUs) |

[0001193125-13-207088:notes:137]
|  | • |  | TRACER fixed-wireless products |

[0001193125-13-207088:notes:138]
In addition, we identify
subcategories of product revenues, which we divide into our core
products and legacy products. Our core products consist of
Broadband Access and Optical products (included in Carrier Systems)
and Internetworking products (included in Business Networking). Our
legacy products include HDSL products (included in Loop Access) and
other products not included in the aforementioned core
products.

[0001193125-13-207088:notes:139]
The table below presents
subcategory revenues for the three month ended March 31, 2013
and 2012:

[0001193125-13-207088:notes:140]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2013 |  |  | 2012 |  |
| Core Products |  |  |  |  |  |  |  |  |
| Broadband Access (included in Carrier Systems) |  | $ | 72,234 |  |  | $ | 49,482 |  |
| Optical (included in Carrier Systems) |  |  | 8,874 |  |  |  | 14,255 |  |
| Internetworking (NetVanta & Multi-service Access Gateways) (included in Business Networking) |  |  | 36,912 |  |  |  | 40,974 |  |
| Subtotal |  |  | 118,020 |  |  |  | 104,711 |  |
| Legacy Products |  |  |  |  |  |  |  |  |
| HDSL (does not include T1) (included in Loop Access) |  |  | 11,407 |  |  |  | 18,959 |  |
| Other products (excluding HDSL) |  |  | 13,586 |  |  |  | 11,065 |  |
| Subtotal |  |  | 24,993 |  |  |  | 30,024 |  |
| Total |  | $ | 143,013 |  |  | $ | 134,735 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001193125-13-207088:notes:141]
[same as prior period, unchanged from 0001193125-12-451437:notes:103]

[0001193125-13-207088:notes:142]
Changes in
Classifications

[0001193125-13-207088:notes:143]
Certain changes in
classifications have been made to the prior period balances in
other comprehensive income to conform to the current period’s
presentation as a result of our adoption of Accounting Standards
Update No. 2013-02, Reporting of Amounts Reclassified Out of
Accumulated Comprehensive Income.

[0001193125-13-207088:notes:144]
[same as prior period, unchanged from 0001193125-12-451437:notes:105]

[0001193125-13-207088:notes:145]
The preparation of
financial statements in conformity with accounting principles
generally accepted in the United States of America requires
management to make estimates and assumptions that affect the
reported amounts of assets and liabilities, the disclosure of
contingent assets and liabilities at the date of the financial
statements, and the reported amounts of revenue and expense during
the reporting period. Our more significant estimates include the
allowance for doubtful accounts, obsolete and excess inventory
reserves, warranty reserves, customer rebates, allowance for sales
returns, determination of the deferred revenue components of
multiple element sales agreements, estimated costs to complete
obligations associated with deferred revenues, estimated income tax
contingencies, the fair value of stock-based compensation,
impairment of goodwill, value and estimated lives of intangible
assets, estimated working capital adjustments under negotiation
related to the Nokia Siemens Networks Broadband Access business
acquisition, and the evaluation of other-than-temporary declines in
the value of investments. Actual amounts could differ significantly
from these estimates.

[0001193125-13-207088:notes:146]
[same as prior period, unchanged from 0001193125-12-451437:notes:107]

[0001193125-13-207088:notes:147]
During the three months
ended March 31, 2013, we adopted the following accounting
standard, which had no material effect on our consolidated results
of operations or financial condition:

[0001193125-13-207088:notes:148]
In February 2013, the FASB
issued Accounting Standards Update No. 2013-02, Reporting of
Amounts Reclassified Out of Accumulated Other Comprehensive Income
(ASU 2013-02). ASU 2013-02 requires entities to provide information
about the amounts reclassified out of accumulated other
comprehensive income by component either on the face of the
financial statements or in the footnotes. ASU 2013-02 does not
change the current requirements for reporting net income or other
comprehensive income in the financial statements. This update is
effective prospectively for reporting periods beginning after
December 15, 2012. We adopted this amendment during the first
quarter of 2013, and we have provided the disclosures required for
the period ended March 31, 2013 in Note 10 of Notes to
Consolidated Financial Statements.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001193125-13-207088:notes:149]
6.
INVESTMENTS

[0001193125-13-207088:notes:150]
Our investment policy
provides limitations for issuer concentration, which limits, at the
time of purchase, the concentration in any one issuer to 5% of the
market value of our total investment portfolio.

[0001193125-13-207088:notes:151]
At March 31, 2013, we
held a $48.3 million restricted certificate of deposit, which is
carried at cost. This investment serves as a collateral deposit
against the principal amount outstanding under loans made to ADTRAN
pursuant to an Alabama State Industrial Development Authority
revenue bond (the Bond). At March 31, 2013, the estimated fair
value of the Bond was approximately $47.9 million, based on a debt
security with a comparable interest rate and maturity and a
Standard and Poor’s credit rating of A-. For more information
on the Bond, see “Debt” under “Liquidity and
Capital Resources” in the “Management’s
Discussion and Analysis of Financial Condition and Results of
Operations” contained in Item 2 of Part I of this
report.

[0001193125-13-207088:notes:152]
We review our investment
portfolio for potential “other-than-temporary” declines
in value on an individual investment basis. We assess, on a
quarterly basis, significant declines in value which may be
considered other-than-temporary and, if necessary, recognize and
record the appropriate charge to write-down the carrying value of
such investments. In making this assessment, we take into
consideration qualitative and quantitative information, including
but not limited to the following: the magnitude and duration of
historical declines in market prices, credit rating activity,
assessments of liquidity, public filings, and statements made by
the issuer. We generally begin our identification of potential
other-than-temporary impairments by reviewing any security with a
fair value that has declined from its original or adjusted cost
basis by 25% or more for six or more consecutive months. We then
evaluate the individual security based on the previously identified
factors to determine the amount of the write-down, if any. As a
result of our review, we recorded an other-than-temporary
impairment charge of $4 thousand during the three months ended
March 31, 2013 related to one marketable equity security. For
the three months ended March 31, 2012, we recorded an
other-than-temporary impairment charge of $33 thousand related to
seven marketable equity securities.

[0001193125-13-207088:notes:153]
Realized gains and losses
on sales of securities are computed under the specific
identification method. The following table presents gross realized
gains and losses related to our investments.

[0001193125-13-207088:notes:154]
As of March 31, 2013
and 2012, gross unrealized losses related to individual securities
that had been in a continuous loss position for 12 months or longer
were not significant.

[0001193125-13-207088:notes:155]
The fair value of our Level
2 securities is calculated using a weighted average market price
for each security. Market prices are obtained from a variety of
industry standard data providers, security master files from large
financial institutions, and other third-party sources. These
multiple market prices are used as inputs into a
distribution-curve-based algorithm to determine the daily market
value of each security.

[0001193125-13-207088:notes:156]
Our municipal variable rate
demand notes have a structure that implies a standard expected
market price. The frequent interest rate resets make it reasonable
to expect the price to stay at par. These securities are priced at
the expected market price.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001193125-13-207088:notes:157]
[same as prior period, unchanged from 0001193125-12-451437:notes:118]

[0001193125-13-207088:notes:158]
On May 4, 2012, we
acquired the Nokia Siemens Networks Broadband Access business (NSN
BBA business). This acquisition provides us with an established
customer base in key markets and complementary, market-focused
products and was accounted for as a business combination. We have
included the financial results of the NSN BBA business in our
consolidated financial statements since the date of acquisition.
These revenues are included in the Carrier Networks division in the
Broadband Access subcategory.

[0001193125-13-207088:notes:159]
We received a cash payment
of $7.5 million from NSN and recorded a bargain purchase gain of
$1.8 million, net of income taxes, in the second quarter of 2012,
subject to customary working capital adjustments between the
parties as defined in the purchase agreement. As of March 31,
2013, the parties were in the process of resolving the working
capital adjustments. We adjusted the purchase price allocation
during the fourth quarter of 2012 to record additional estimated
liabilities and an estimated receivable from NSN related to working
capital adjustments under negotiation. The bargain purchase gain of
$1.8 million represents the excess of the consideration exchanged
over the fair value of the assets acquired and liabilities assumed.
We have assessed the recognition and measurements of the assets
acquired and liabilities assumed based on historical and pro forma
data for future periods and have concluded that our valuation
procedures and resulting measures were appropriate.

[0001193125-13-207088:notes:160]
[same as prior period, unchanged from 0001193125-12-451437:notes:123]

[0001193125-13-207088:notes:161]
The following supplemental
pro forma information presents the financial results of the
acquired NSN BBA business for the three months ended March 31,
2012. These results are not included in our consolidated financial
statements.

[0001193125-13-207088:notes:162]
For the three months ended
March 31, 2013, we incurred acquisition and integration
related expenses and amortization of acquired intangibles of $0.9
million related to this acquisition.
