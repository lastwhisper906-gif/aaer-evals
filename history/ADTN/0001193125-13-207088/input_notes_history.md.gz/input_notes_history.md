# ADTN note change history — 0001193125-12-451437 → 0001193125-13-207088


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2013-05-08):
[0001193125-13-207088:note_history:1]
We have committed to invest
up to an aggregate of $7.9 million in two private equity funds, and
we have contributed $8.4 million as of March 31, 2013, of
which $7.7 million has been applied to these
commitments.
  (was, 2012-11-05, similarity 0.9652):
[0001193125-12-451437:note_history:1]
We have committed to invest
up to an aggregate of $7.9 million in two private equity funds, and
we have contributed $8.4 million as of September 30, 2012, of
which $7.7 million has been applied to these
commitments.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2013-05-08):
[0001193125-13-207088:note_history:2]
Changes in
Classifications

- added (2013-05-08):
[0001193125-13-207088:note_history:3]
Certain changes in
classifications have been made to the prior period balances in
other comprehensive income to conform to the current period’s
presentation as a result of our adoption of Accounting Standards
Update No. 2013-02, Reporting of Amounts Reclassified Out of
Accumulated Comprehensive Income.

- changed (2013-05-08):
[0001193125-13-207088:note_history:4]
The preparation of
financial statements in conformity with accounting principles
generally accepted in the United States of America requires
management to make estimates and assumptions that affect the
reported amounts of assets and liabilities, the disclosure of
contingent assets and liabilities at the date of the financial
statements, and the reported amounts of revenue and expense during
the reporting period. Our more significant estimates include the
allowance for doubtful accounts, obsolete and excess inventory
reserves, warranty reserves, customer rebates, allowance for sales
returns, determination of the deferred revenue components of
multiple element sales agreements, estimated costs to complete
obligations associated with deferred revenues, estimated income tax
contingencies, the fair value of stock-based compensation,
impairment of goodwill, value and estimated lives of intangible
assets, estimated working capital adjustments under negotiation
related to the Nokia Siemens Networks Broadband Access business
acquisition, and the evaluation of other-than-temporary declines in
the value of investments. Actual amounts could differ significantly
from these estimates.
  (was, 2012-11-05, similarity 0.9408):
[0001193125-12-451437:note_history:4]
The preparation of
financial statements in conformity with accounting principles
generally accepted in the United States of America requires
management to make estimates and assumptions that affect the
reported amounts of assets and liabilities, the disclosure of
contingent assets and liabilities at the date of the financial
statements, and the reported amounts of revenue and expense during
the reporting period. Our more significant estimates include the
allowance for doubtful accounts, obsolete and excess inventory
reserves, warranty reserves, customer rebates, allowance for sales
returns, determination of the deferred revenue components of
multiple element sales agreements, estimated costs to complete
obligations associated with deferred revenues, estimated income tax
contingencies, the fair value of stock-based compensation,
impairment of goodwill, value and estimated lives of intangible
assets, and the evaluation of other-than-temporary declines in the
value of investments. Actual amounts could differ significantly
from these estimates.

- changed (2013-05-08):
[0001193125-13-207088:note_history:5]
During the three months
ended March 31, 2013, we adopted the following accounting
standard, which had no material effect on our consolidated results
of operations or financial condition:
  (was, 2012-11-05, similarity 0.9505):
[0001193125-12-451437:note_history:5]
During the nine months
ended September 30, 2012, we adopted the following accounting
standards, which had no material effect on our consolidated results
of operations or financial condition:

- added (2013-05-08):
[0001193125-13-207088:note_history:6]
In February 2013, the FASB
issued Accounting Standards Update No. 2013-02, Reporting of
Amounts Reclassified Out of Accumulated Other Comprehensive Income
(ASU 2013-02). ASU 2013-02 requires entities to provide information
about the amounts reclassified out of accumulated other
comprehensive income by component either on the face of the
financial statements or in the footnotes. ASU 2013-02 does not
change the current requirements for reporting net income or other
comprehensive income in the financial statements. This update is
effective prospectively for reporting periods beginning after
December 15, 2012. We adopted this amendment during the first
quarter of 2013, and we have provided the disclosures required for
the period ended March 31, 2013 in Note 10 of Notes to
Consolidated Financial Statements.

- removed (2013-05-08):
[0001193125-12-451437:note_history:7]
In June 2011, the Financial
Accounting Standards Board (FASB) issued Accounting Standards
Update No. 2011-05, Presentation of Comprehensive Income (ASU
2011-05). ASU 2011-05 requires companies to present the components
of net income and other comprehensive income either as one
continuous statement or as two consecutive statements. ASU 2011-05
eliminates the option to present the components of other
comprehensive income as part of the statement of changes in
stockholders’ equity. While ASU 2011-05 changes the
presentation of comprehensive income, it does not change the
components that are recognized in net income or comprehensive
income under current accounting guidance. This update is effective
for fiscal years, and interim periods within those years, ending
after December 15, 2011, with early adoption permitted. We
adopted this amendment during the first quarter of 2012, and we
have provided the disclosures required for the three and nine
months ended September 30, 2012 and 2011.

- removed (2013-05-08):
[0001193125-12-451437:note_history:8]
In December 2011, the FASB
issued Accounting Standards Update No. 2011-12, Deferral of
the Effective Date for Amendments to the Presentation of
Reclassifications of Items Out of Accumulated Other Comprehensive
Income in Accounting Standards Update No. 2011-05 (ASU
2011-12). ASU 2011-12 defers the effective date for certain
presentation requirements that relate to reclassification
adjustments and the effect of those reclassification adjustments on
the financial statements. This update is effective for fiscal
years, and interim periods within those years, ending after
December 15, 2011, with early adoption permitted. We adopted
this amendment during the first quarter of 2012. The adoption of
this amendment had no effect on our consolidated results of
operations and financial condition for the three and nine months
ended September 30, 2012.

- removed (2013-05-08):
[0001193125-12-451437:note_history:9]
In May 2011, the FASB
issued Accounting Standards Update No. 2011-04, Amendments to
Achieve Common Fair Value Measurement and Disclosure Requirements
in U.S. GAAP and IFRSs (ASU 2011-04). ASU 2011-04 is intended to
improve the comparability of fair value measurements presented and
disclosed in financial statements prepared in accordance with U.S.
GAAP and IFRS. The amendments are of two types: (i) those that
clarify the Board’s intent about the application of existing
fair value measurement and disclosure requirements and
(ii) those that change a particular principle or requirement
for measuring fair value or for disclosing information about fair
value measurements. This update is effective for annual periods
beginning after December 15, 2011. We adopted this amendment
during the first quarter of 2012. The adoption of this amendment
had no effect on our consolidated results of operations and
financial condition for the three and nine months ended
September 30, 2012.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2013-05-08):
[0001193125-13-207088:note_history:10]
At March 31, 2013, we
held the following securities and investments, recorded at either
fair value or cost.
  (was, 2012-11-05, similarity 0.9515):
[0001193125-12-451437:note_history:10]
At September 30, 2012,
we held the following securities and investments, recorded at
either fair value or cost.

- changed (2013-05-08):
[0001193125-13-207088:note_history:11]
|  |  |  |  |  | Gross Unrealized |  |  |  |  |
| (In thousands) |  | Amortized Cost |  |  | Gains |  |  | Losses |  |  | Carrying Value |  |
| Deferred compensation plan assets |  | $ | 10,907 |  |  | $ | 1,448 |  |  | $ | (5 | ) |  | $ | 12,350 |  |
| Corporate bonds |  |  | 190,540 |  |  |  | 783 |  |  |  | (18 | ) |  |  | 191,305 |  |
| Municipal fixed-rate bonds |  |  | 171,282 |  |  |  | 849 |  |  |  | (10 | ) |  |  | 172,121 |  |
| Municipal variable rate demand notes |  |  | 40,780 |  |  |  | — |  |  |  | — |  |  |  | 40,780 |  |
| Marketable equity securities |  |  | 22,226 |  |  |  | 11,179 |  |  |  | (309 | ) |  |  | 33,096 |  |
| Available-for-sale securities held at fair value |  | $ | 435,735 |  |  | $ | 14,259 |  |  | $ | (342 | ) |  | $ | 449,652 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 48,250 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1,818 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 499,720 |  |
  (was, 2012-11-05, similarity 0.8694):
[0001193125-12-451437:note_history:11]
| (In thousands) |  | Amortized Cost |  |  | Gross Unrealized |  |  | Carrying Value |  |
|  |  | Gains |  |  | Losses |  |  |
| Deferred compensation plan assets |  | $ | 10,199 |  |  | $ | 795 |  |  | $ | (6 | ) |  | $ | 10,988 |  |
| Corporate bonds |  |  | 165,912 |  |  |  | 1,080 |  |  |  | (65 | ) |  |  | 166,927 |  |
| Municipal fixed-rate bonds |  |  | 190,893 |  |  |  | 947 |  |  |  | (9 | ) |  |  | 191,831 |  |
| Municipal variable rate demand notes |  |  | 58,780 |  |  |  | — |  |  |  | — |  |  |  | 58,780 |  |
| Fixed income bond fund |  |  | 862 |  |  |  | 18 |  |  |  | — |  |  |  | 880 |  |
| Marketable equity securities |  |  | 20,618 |  |  |  | 17,550 |  |  |  | (348 | ) |  |  | 37,820 |  |
| Available-for-sale securities held at fair value |  | $ | 447,264 |  |  | $ | 20,390 |  |  | $ | (428 | ) |  | $ | 467,226 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 48,250 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1,963 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 517,439 |  |

- changed (2013-05-08):
[0001193125-13-207088:note_history:12]
|  |  |  |  |  | Gross Unrealized |  |  |  |  |
| (In thousands) |  | Amortized Cost |  |  | Gains |  |  | Losses |  |  | Carrying Value |  |
| Deferred compensation plan assets |  | $ | 10,688 |  |  | $ | 846 |  |  | $ | (7 | ) |  | $ | 11,527 |  |
| Corporate bonds |  |  | 185,464 |  |  |  | 966 |  |  |  | (18 | ) |  |  | 186,412 |  |
| Municipal fixed-rate bonds |  |  | 174,530 |  |  |  | 627 |  |  |  | (73 | ) |  |  | 175,084 |  |
| Municipal variable rate demand notes |  |  | 34,375 |  |  |  | — |  |  |  | — |  |  |  | 34,375 |  |
| Fixed income bond fund |  |  | 444 |  |  |  | 12 |  |  |  | — |  |  |  | 456 |  |
| Marketable equity securities |  |  | 20,966 |  |  |  | 14,630 |  |  |  | (392 | ) |  |  | 35,204 |  |
| Available-for-sale securities held at fair value |  | $ | 426,467 |  |  | $ | 17,081 |  |  | $ | (490 | ) |  | $ | 443,058 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 48,250 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1,902 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 493,210 |  |
  (was, 2012-11-05, similarity 0.911):
[0001193125-12-451437:note_history:12]
| (In thousands) |  | Amortized Cost |  |  | Gross Unrealized |  |  | Carrying Value |  |
|  |  | Gains |  |  | Losses |  |  |
| Deferred compensation plan assets |  | $ | 7,994 |  |  | $ | 119 |  |  | $ | (401 | ) |  | $ | 7,712 |  |
| Corporate bonds |  |  | 159,077 |  |  |  | 181 |  |  |  | (2,505 | ) |  |  | 156,753 |  |
| Municipal fixed-rate bonds |  |  | 174,300 |  |  |  | 579 |  |  |  | (53 | ) |  |  | 174,826 |  |
| Municipal variable rate demand notes |  |  | 69,660 |  |  |  | — |  |  |  | — |  |  |  | 69,660 |  |
| Fixed income bond fund |  |  | 527 |  |  |  | 194 |  |  |  | — |  |  |  | 721 |  |
| Marketable equity securities |  |  | 12,771 |  |  |  | 19,098 |  |  |  | (559 | ) |  |  | 31,310 |  |
| Available-for-sale securities held at fair value |  | $ | 424,329 |  |  | $ | 20,171 |  |  | $ | (3,518 | ) |  | $ | 440,982 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 48,250 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 2,123 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 491,355 |  |

- changed (2013-05-08):
[0001193125-13-207088:note_history:13]
As of March 31, 2013,
our corporate bonds and municipal fixed-rate bonds had the
following contractual maturities:
  (was, 2012-11-05, similarity 0.9545):
[0001193125-12-451437:note_history:13]
As of September 30,
2012, our corporate bonds and municipal fixed-rate bonds had the
following contractual maturities:

- changed (2013-05-08):
[0001193125-13-207088:note_history:14]
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |
| Less than one year |  | $ | 79,983 |  |  | $ | 64,292 |  |
| One to two years |  |  | 55,000 |  |  |  | 30,694 |  |
| Two to three years |  |  | 53,098 |  |  |  | 50,405 |  |
| Three to five years |  |  | 3,224 |  |  |  | 26,730 |  |
| Total |  | $ | 191,305 |  |  | $ | 172,121 |  |
  (was, 2012-11-05, similarity 0.9965):
[0001193125-12-451437:note_history:14]
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |
| Less than one year |  | $ | 55,739 |  |  | $ | 73,594 |  |
| One to two years |  |  | 99,858 |  |  |  | 53,694 |  |
| Two to three years |  |  | 11,330 |  |  |  | 12,286 |  |
| Three to five years |  |  | — |  |  |  | 52,257 |  |
| Total |  | $ | 166,927 |  |  | $ | 191,831 |  |

- added (2013-05-08):
[0001193125-13-207088:note_history:15]
At March 31, 2013, we
held a $48.3 million restricted certificate of deposit, which is
carried at cost. This investment serves as a collateral deposit
against the principal amount outstanding under loans made to ADTRAN
pursuant to an Alabama State Industrial Development Authority
revenue bond (the Bond). At March 31, 2013, the estimated fair
value of the Bond was approximately $47.9 million, based on a debt
security with a comparable interest rate and maturity and a
Standard and Poor’s credit rating of A-. For more information
on the Bond, see “Debt” under “Liquidity and
Capital Resources” in the “Management’s
Discussion and Analysis of Financial Condition and Results of
Operations” contained in Item 2 of Part I of this
report.

- changed (2013-05-08):
[0001193125-13-207088:note_history:16]
We review our investment
portfolio for potential “other-than-temporary” declines
in value on an individual investment basis. We assess, on a
quarterly basis, significant declines in value which may be
considered other-than-temporary and, if necessary, recognize and
record the appropriate charge to write-down the carrying value of
such investments. In making this assessment, we take into
consideration qualitative and quantitative information, including
but not limited to the following: the magnitude and duration of
historical declines in market prices, credit rating activity,
assessments of liquidity, public filings, and statements made by
the issuer. We generally begin our identification of potential
other-than-temporary impairments by reviewing any security with a
fair value that has declined from its original or adjusted cost
basis by 25% or more for six or more consecutive months. We then
evaluate the individual security based on the previously identified
factors to determine the amount of the write-down, if any. As a
result of our review, we recorded an other-than-temporary
impairment charge of $4 thousand during the three months ended
March 31, 2013 related to one marketable equity security. For
the three months ended March 31, 2012, we recorded an
other-than-temporary impairment charge of $33 thousand related to
seven marketable equity securities.
  (was, 2012-11-05, similarity 0.8237):
[0001193125-12-451437:note_history:16]
We review our investment
portfolio for potential “other-than-temporary” declines
in value on an individual investment basis. We assess, on a
quarterly basis, significant declines in value which may be
considered other-than-temporary and, if necessary, recognize and
record the appropriate charge to write-down the carrying value of
such investments. In making this assessment, we take into
consideration qualitative and quantitative information, including
but not limited to the following: the magnitude and duration of
historical declines in market prices, credit rating activity,
assessments of liquidity, public filings, and statements made by
the issuer. We generally begin our identification of potential
other-than-temporary impairments by reviewing any security with a
fair value that has declined from its original or adjusted cost
basis by 25% or more for six or more consecutive months. We then
evaluate the individual security based on the previously identified
factors to determine the amount of the write-down, if any. As a
result of our review, we recorded an other-than-temporary
impairment charge of $0.1 million during the nine months ended
September 30, 2012 related to 21 marketable equity securities.
In addition to the impairment charge we recorded on our marketable
equity securities, we recorded an impairment of $0.6 million during
the nine months ended September 30, 2012 related to our
deferred compensation plan as a result of similar reviews. For the
nine months ended September 30, 2011, we recorded an
other-than-temporary impairment charge of $32 thousand related to
seven marketable equity securities.

- changed (2013-05-08):
[0001193125-13-207088:note_history:17]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2013 |  |  | 2012 |  |
| Gross realized gains |  | $ | 3,727 |  |  | $ | 2,669 |  |
| Gross realized losses |  | $ | (82 | ) |  | $ | (202 | ) |
  (was, 2012-11-05, similarity 0.6434):
[0001193125-12-451437:note_history:17]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |
| Gross realized gains |  | $ | 3,388 |  |  | $ | 3,401 |  |  | $ | 8,688 |  |  | $ | 9,770 |  |
| Gross realized losses |  | $ | (858 | ) |  | $ | (419 | ) |  | $ | (1,335 | ) |  | $ | (649 | ) |

- changed (2013-05-08):
[0001193125-13-207088:note_history:18]
As of March 31, 2013
and 2012, gross unrealized losses related to individual securities
that had been in a continuous loss position for 12 months or longer
were not significant.
  (was, 2012-11-05, similarity 0.9704):
[0001193125-12-451437:note_history:18]
As of September 30,
2012 and 2011, gross unrealized losses related to individual
securities that had been in a continuous loss position for 12
months or longer were not significant.

- changed (2013-05-08):
[0001193125-13-207088:note_history:19]
We have categorized our
cash equivalents held in money market funds and our investments
held at fair value into a three-level fair value hierarchy based on
the priority of the inputs to the valuation technique for the cash
equivalents and investments as follows: Level 1 – Values
based on unadjusted quoted prices for identical assets or
liabilities in an active market; Level 2 – Values based on
quoted prices in markets that are not active or model inputs that
are observable either directly or indirectly; Level 3 –
Values based on prices or valuation techniques that require inputs
that are both unobservable and significant to the overall fair
value measurement. These inputs include information supplied by
investees.
  (was, 2012-11-05, similarity 0.9439):
[0001193125-12-451437:note_history:19]
In accordance with the Fair
Value Measurements and Disclosures Topic of the FASB ASC, we have
categorized our cash equivalents held in money market funds and our
investments held at fair value into a three-level fair value
hierarchy based on the priority of the inputs to the valuation
technique for the cash equivalents and investments as follows:
Level 1 – Values based on unadjusted quoted prices for
identical assets or liabilities in an active market; Level 2
– Values based on quoted prices in markets that are not
active or model inputs that are observable either directly or
indirectly; Level 3 – Values based on prices or valuation
techniques that require inputs that are both unobservable and
significant to the overall fair value measurement. These inputs
include information supplied by investees.

- changed (2013-05-08):
[0001193125-13-207088:note_history:20]
|  |  | Fair Value Measurements at March 31, 2013 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 19,140 |  |  | $ | 19,140 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 12,350 |  |  |  | 12,350 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 191,305 |  |  |  | — |  |  |  | 191,305 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 172,121 |  |  |  | — |  |  |  | 172,121 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 40,780 |  |  |  | — |  |  |  | 40,780 |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity securities – technology industry |  |  | 9,307 |  |  |  | 9,307 |  |  |  | — |  |  |  | — |  |
| Equity securities – other |  |  | 23,789 |  |  |  | 23,789 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 449,652 |  |  |  | 45,446 |  |  |  | 404,206 |  |  |  | — |  |
| Total |  | $ | 468,792 |  |  | $ | 64,586 |  |  | $ | 404,206 |  |  | $ | — |  |
|  |  | Fair Value Measurements at December 31, 2012 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 28,071 |  |  | $ | 28,071 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 11,527 |  |  |  | 11,527 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 186,412 |  |  |  | — |  |  |  | 186,412 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 175,084 |  |  |  | — |  |  |  | 175,084 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 34,375 |  |  |  | — |  |  |  | 34,375 |  |  |  | — |  |
| Fixed income bond fund |  |  | 456 |  |  |  | 456 |  |  |  | — |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity securities – technology industry |  |  | 14,099 |  |  |  | 14,099 |  |  |  | — |  |  |  | — |  |
| Equity securities – other |  |  | 21,105 |  |  |  | 21,105 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 443,058 |  |  |  | 47,187 |  |  |  | 395,871 |  |  |  | — |  |
| Total |  | $ | 471,129 |  |  | $ | 75,258 |  |  | $ | 395,871 |  |  | $ | — |  |
  (was, 2012-11-05, similarity 0.6389):
[0001193125-12-451437:note_history:20]
|  |  | Fair Value Measurements at December 31, 2011 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 13,696 |  |  | $ | 13,696 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 7,712 |  |  |  | 7,712 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 156,753 |  |  |  | — |  |  |  | 156,753 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 174,826 |  |  |  | — |  |  |  | 174,826 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 69,660 |  |  |  | — |  |  |  | 69,660 |  |  |  | — |  |
| Fixed income bond fund |  |  | 721 |  |  |  | 721 |  |  |  | — |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity securities – technology industry |  |  | 18,743 |  |  |  | 18,743 |  |  |  | — |  |  |  | — |  |
| Equity securities – other |  |  | 12,567 |  |  |  | 12,567 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 440,982 |  |  |  | 39,743 |  |  |  | 401,239 |  |  |  | — |  |
| Total |  | $ | 454,678 |  |  | $ | 53,439 |  |  | $ | 401,239 |  |  | $ | — |  |

- removed (2013-05-08):
[0001193125-12-451437:note_history:21]
|  |  | Fair Value Measurements at September 30, 2012 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 16,861 |  |  | $ | 16,861 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 10,988 |  |  |  | 10,988 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 166,927 |  |  |  | — |  |  |  | 166,927 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 191,831 |  |  |  | — |  |  |  | 191,831 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 58,780 |  |  |  | — |  |  |  | 58,780 |  |  |  | — |  |
| Fixed income bond fund |  |  | 880 |  |  |  | 880 |  |  |  | — |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity securities – technology industry |  |  | 17,360 |  |  |  | 17,360 |  |  |  | — |  |  |  | — |  |
| Equity securities – other |  |  | 20,460 |  |  |  | 20,460 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 467,226 |  |  |  | 49,688 |  |  |  | 417,538 |  |  |  | — |  |
| Total |  | $ | 484,087 |  |  | $ | 66,549 |  |  | $ | 417,538 |  |  | $ | — |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2013-05-08):
[0001193125-13-207088:note_history:22]
We employ the law firm of
our director emeritus for legal services. All bills for services
rendered by this firm are reviewed and approved by our Chief
Financial Officer. We believe that the fees for such services are
comparable to those charged by other firms for services rendered to
us. For the three month periods ended March 31, 2013 and 2012,
we incurred fees of $10 thousand per month for these legal
services.
  (was, 2012-11-05, similarity 0.9238):
[0001193125-12-451437:note_history:22]
We employ the law firm of
our director emeritus for legal services. All bills for services
rendered by this firm are reviewed and approved by our Chief
Financial Officer. We believe that the fees for such services are
comparable to those charged by other firms for services rendered to
us. For the three and nine month periods ended September 30,
2012 and 2011, we incurred fees of $10 thousand per month for these
legal services.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2013-05-08):
[0001193125-13-207088:note_history:23]
On April 9, 2013, we
announced that our Board of Directors declared a quarterly cash
dividend of $0.09 per common share to be paid to stockholders of
record at the close of business on April 25, 2013. The payment
date will be May 9, 2013. The quarterly dividend payment will
be approximately $5.3 million. In July 2003, our Board of Directors
elected to begin declaring quarterly dividends on our common stock
considering the tax treatment of dividends and adequate levels of
Company liquidity.
  (was, 2012-11-05, similarity 0.963):
[0001193125-12-451437:note_history:23]
On October 9, 2012, we
announced that our Board of Directors declared a quarterly cash
dividend of $0.09 per common share to be paid to stockholders of
record at the close of business on October 25, 2012. The
payment date will be November 8, 2012. The quarterly dividend
payment will be approximately $5.6 million. In July 2003, our Board
of Directors elected to begin declaring quarterly dividends on our
common stock considering the tax treatment of dividends and
adequate levels of Company liquidity.

- changed (2013-05-08):
[0001193125-13-207088:note_history:24]
During the second quarter
of 2013 and as of May 8, 2013, we repurchased 2.7 million
shares of our common stock through open market purchases at an
average cost of $21.03 per share. We currently have the authority
to purchase an additional 0.3 million shares of our common
stock under the current plan approved by the Board of
Directors.
  (was, 2012-11-05, similarity 0.9643):
[0001193125-12-451437:note_history:24]
During the fourth quarter
of 2012 and as of November 5, 2012, we repurchased
0.3 million shares of our common stock through open market
purchases at an average cost of $16.01 per share. We currently have
the authority to purchase an additional 4.4 million shares of
our common stock under the current plan approved by the Board of
Directors.

- added (2013-05-08):
[0001193125-13-207088:note_history:25]
On May 1, 2013, we
announced that our Board of Directors authorized the repurchase of
an additional 5.0 million shares of our common stock to
commence upon completion of the repurchase plan announced on
October 11, 2011. This new authorization will be implemented
through open market or private purchases from time to time as
conditions warrant.
