# ADTN 8-K — 0001157523-13-001730 filed 2013-04-10

## item codes, every 8-K on or before 2013-05-08

- 2013-05-03 0001193125-13-198816 — 8.01, 9.01
- 2013-04-10 0001157523-13-001730 — 2.02, 9.01
- 2013-01-16 0001157523-13-000139 — 2.02, 9.01
- 2012-10-10 0001157523-12-005081 — 2.02, 9.01
- 2012-10-03 0001193125-12-413609 — 7.01
- 2012-09-28 0001193125-12-408878 — 2.02, 9.01
- 2012-07-11 0001157523-12-003592 — 2.02, 9.01
- 2012-05-10 0001193125-12-225669 — 5.07
- 2012-05-10 0001193125-12-225639 — 8.01, 9.01
- 2012-04-11 0001157523-12-001772 — 2.02, 9.01
- 2012-03-15 0001193125-12-116494 — 2.02, 9.01
- 2012-01-18 0001157523-12-000174 — 2.02, 9.01
- 2011-12-12 0001193125-11-337271 — 7.01, 9.01
- 2011-10-13 0000950123-11-089785 — 5.03, 9.01
- 2011-10-12 0001157523-11-005682 — 2.02, 9.01
- 2011-07-13 0001157523-11-003986 — 2.02, 9.01
- 2011-05-09 0000950123-11-047191 — 5.02, 5.07, 9.01
- 2011-04-13 0001157523-11-002001 — 2.02, 9.01
- 2011-01-19 0001157523-11-000232 — 2.02, 9.01
- 2010-11-09 0000950123-10-103195 — 5.02, 9.01
- 2010-10-13 0001157523-10-005798 — 2.02, 9.01
- 2010-07-14 0001157523-10-004011 — 2.02, 9.01
- 2010-05-28 0000950123-10-053947 — 5.07
- 2010-04-14 0001157523-10-002022 — 2.02, 9.01
- 2010-01-20 0001157523-10-000200 — 2.02, 9.01
- 2009-10-28 0000950123-09-053984 — 8.01
- 2009-10-14 0001157523-09-006877 — 2.02, 9.01
- 2009-07-15 0001157523-09-004878 — 2.02, 9.01
- 2009-04-15 0001157523-09-002687 — 2.02, 9.01
- 2009-01-21 0001157523-09-000340 — 2.02, 9.01
- 2008-11-12 0001193125-08-233181 — 5.02, 9.01
- 2008-10-14 0001157523-08-007999 — 2.02, 9.01
- 2008-07-15 0001157523-08-005504 — 2.02, 9.01
- 2008-04-15 0001157523-08-002896 — 2.02, 9.01
- 2008-01-22 0001157523-08-000408 — 2.02, 9.01
- 2007-10-16 0001193125-07-219356 — 5.03, 9.01
- 2007-10-16 0001157523-07-009850 — 2.02, 9.01
- 2007-07-17 0001157523-07-006912 — 2.02, 9.01
- 2007-04-17 0001157523-07-003630 — 2.02, 9.01
- 2007-04-03 0001179022-07-000068 — 5.02
- 2007-03-28 0001179022-07-000064 — 5.02
- 2007-02-23 0001193125-07-038337 — 5.02
- 2007-02-23 0001193125-07-038335 — 5.02
- 2007-01-30 0001193125-07-015912 — 5.02, 9.01
- 2007-01-26 0001193125-07-014234 — 5.02
- 2007-01-23 0001157523-07-000494 — 2.02, 9.01 — amendment of 0001157523-07-000481
- 2007-01-23 0001157523-07-000481 — 2.02, 9.01
- 2006-10-17 0001157523-06-009945 — 2.02, 9.01
- 2006-07-18 0001157523-06-006929 — 2.02, 9.01
- 2006-06-08 0001193125-06-126486 — 1.01, 9.01
- 2006-05-10 0001193125-06-107316 — 1.01, 9.01
- 2006-04-18 0001157523-06-003699 — 2.02, 9.01
- 2006-02-03 0001179022-06-000014 — 1.01
- 2006-01-27 0001157523-06-000754 — 5.02, 9.01
- 2006-01-24 0001157523-06-000551 — 2.02, 9.01
- 2005-10-18 0001157523-05-008826 — 2.02, 9.01
- 2005-07-19 0001193125-05-143958 — 1.01, 5.02, 9.01
- 2005-07-19 0001193125-05-143957 — 2.02, 9.01
- 2005-05-20 0001193125-05-112019 — 1.01, 9.01
- 2005-04-19 0001157523-05-003418 — 2.02, 9.01
- 2005-01-25 0001193125-05-010721 — 2.02, 9.01
- 2004-10-12 0001193125-04-169652 — 2.02, 9.01
- 2004-07-13 0001193125-04-116820 — 12, 7
- 2004-04-14 0001193125-04-061547 — 12, 7
- 2004-01-21 0001193125-04-006366 — 12, 7
- 2003-10-14 0001193125-03-061018 — 12, 5, 7
- 2003-07-15 0001193125-03-019292 — 7, 9
- 2003-04-15 0000931763-03-000968 — 7, 9
- 1996-09-12 0000931763-96-000667 — 5, 7

## late-filing notifications on or before 2013-05-08

- none on or before 2013-05-08

## item 2.02 — earnings release, exhibit 99.1

[0001157523-13-001730:8k_2_02:1]
EX-99.1
2
a50606831ex99_1.htm
EXHIBIT 99.1

[0001157523-13-001730:8k_2_02:2]
Exhibit 99.1

[0001157523-13-001730:8k_2_02:3]
ADTRAN,
      Inc. Reports Results for the First Quarter 2013 and Declares Quarterly
      Cash Dividend

[0001157523-13-001730:8k_2_02:4]
HUNTSVILLE, Ala.--(BUSINESS WIRE)--April 9, 2013--ADTRAN, Inc.
      (NASDAQ:ADTN) reported results for the first quarter 2013. For the
      quarter, sales were $143,013,000 compared to $134,735,000 for the first
      quarter of 2012. Net income was $7,890,000 for the quarter compared to
      $12,960,000 for the first quarter of 2012. Earnings per share, assuming
      dilution, were $0.13 for the quarter compared to $0.20 for the first
      quarter of 2012. Non-GAAP earnings per share for the quarter were $0.17
      compared to $0.25 for the first quarter of 2012. The reconciliation
      between GAAP earnings per share, diluted, and non-GAAP earnings per
      share, diluted, is in the table provided.

[0001157523-13-001730:8k_2_02:5]
ADTRAN Chief Executive Officer Tom Stanton stated, “Operating results
      for the quarter came in as expected with our domestic carrier business
      continuing to solidify and our overall revenue positively impacted by
      sequential growth internationally and in our Enterprise business. We
      believe our company is well positioned for an improving spending
      environment in our markets and strategic investments by our carrier
      customers.”

[0001157523-13-001730:8k_2_02:6]
The Company also announced that its Board of Directors declared a cash
      dividend for the first quarter of 2013. The quarterly cash dividend is
      $0.09 per common share to be paid to holders of record at the close of
      business on April 25, 2013. The ex-dividend date is April 23, 2013 and
      the payment date is May 9, 2013.

[0001157523-13-001730:8k_2_02:7]
Non-GAAP earnings per share exclude the effect of acquisition related
      expenses, amortizations and adjustments, and stock compensation expense.

[0001157523-13-001730:8k_2_02:8]
The Company confirmed that its first quarter conference call will be
      held Wednesday, April 10, 2013 at 9:30 a.m. Central Time. This
      conference call will be web cast live through StreetEvents.com. To
      listen, simply visit the Investor Relations site at http://www.adtran.com
      or http://www.streetevents.com approximately 10 minutes prior to
      the start of the call and click on the conference call link provided.

[0001157523-13-001730:8k_2_02:9]
An online replay of the conference call will be available for seven days
      at http://www.streetevents.com. In addition, an online replay of
      the conference call, as well as the text of the Company’s earnings
      release, will be available on the Investor Relations site at http://www.adtran.com
      for at least 12 months following the call.

[0001157523-13-001730:8k_2_02:10]
ADTRAN, Inc. is a leading global provider of networking and
      communications equipment. ADTRAN’s products enable voice, data, video
      and Internet communications across a variety of network infrastructures.
      ADTRAN solutions are currently in use by service providers, private
      enterprises, government organizations, and millions of individual users
      worldwide. For more information, please visit www.adtran.com.

[0001157523-13-001730:8k_2_02:11]
For more information, contact the company at 800 9ADTRAN (800 923-8726)
      or via email at info@adtran.com. On the Web, visit www.adtran.com.

[0001157523-13-001730:8k_2_02:12]
This press release contains forward-looking statements which reflect
      management’s best judgment based on factors currently known. However,
      these statements involve risks and uncertainties, including the
      successful development and market acceptance of new products, the degree
      of competition in the market for such products, the product and channel
      mix, component costs, manufacturing efficiencies, and other risks
      detailed in our annual report on Form 10-K for the year ended December
      31, 2012. These risks and uncertainties could cause actual results to
      differ materially from those in the forward-looking statements included
      in this press release.

[0001157523-13-001730:8k_2_02:13]
| Condensed Consolidated Balance Sheet(Unaudited)(In thousands) |
|  |  | March 31,2013 |  | December 31,2012 |
| Assets |  |  |  |  |
| Cash and cash equivalents |  | $ | 58,640 |  | $ | 68,457 |
| Short-term investments |  |  | 189,236 |  |  | 160,481 |
| Accounts receivable, net |  |  | 82,102 |  |  | 81,194 |
| Other receivables |  |  | 16,164 |  |  | 16,253 |
| Inventory |  |  | 95,767 |  |  | 102,583 |
| Prepaid expenses |  |  | 4,419 |  |  | 4,148 |
| Deferred tax assets, net |  |  | 12,972 |  |  | 13,055 |
| Total Current Assets |  |  | 459,300 |  |  | 446,171 |
| Property, plant and equipment, net |  |  | 77,781 |  |  | 80,246 |
| Deferred tax assets, net |  |  | 10,680 |  |  | 10,261 |
| Goodwill |  |  | 3,492 |  |  | 3,492 |
| Other assets |  |  | 12,599 |  |  | 13,482 |
| Long-term investments |  |  | 310,484 |  |  | 332,729 |
| Total Assets |  | $ | 874,336 |  | $ | 886,381 |
| Liabilities and Stockholders' Equity |  |  |  |  |
| Accounts payable |  | $ | 48,933 |  | $ | 42,173 |
| Unearned revenue |  |  | 33,563 |  |  | 38,051 |
| Accrued expenses |  |  | 11,117 |  |  | 10,309 |
| Accrued wages and benefits |  |  | 16,479 |  |  | 15,022 |
| Income tax payable, net |  |  | 1,585 |  |  | 1,211 |
| Total Current Liabilities |  |  | 111,677 |  |  | 106,766 |
| Non-current unearned revenue |  |  | 24,990 |  |  | 23,803 |
| Other non-current liabilities |  |  | 18,541 |  |  | 17,406 |
| Bonds payable |  |  | 46,000 |  |  | 46,000 |
| Total Liabilities |  |  | 201,208 |  |  | 193,975 |
| Stockholders' Equity |  |  | 673,128 |  |  | 692,406 |
| Total Liabilities and Stockholders' Equity |  | $ | 874,336 |  | $ | 886,381 |

[0001157523-13-001730:8k_2_02:14]
| Consolidated Statements of Income(Unaudited)(In thousands, except per share data) |
|  |  |  | Three Months Ended |
|  |  |  | March 31, |
|  |  |  | 2013 |  | 2012 |
| Sales |  | $ | 143,013 |  |  | $ | 134,735 |  |
| Cost of sales |  |  | 73,336 |  |  |  | 60,648 |  |
| Gross Profit |  |  | 69,677 |  |  |  | 74,087 |  |
| Selling, general and administrative expenses |  |  | 30,603 |  |  |  | 33,111 |  |
| Research and development expenses |  |  | 32,511 |  |  |  | 24,795 |  |
| Operating Income |  |  | 6,563 |  |  |  | 16,181 |  |
| Interest and dividend income |  |  | 1,768 |  |  |  | 1,861 |  |
| Interest expense |  |  | (581 | ) |  |  | (588 | ) |
| Net realized investment gain |  |  | 3,645 |  |  |  | 2,467 |  |
| Other income (expense), net |  |  | (1,672 | ) |  |  | 141 |  |
| Income before provision for income taxes |  |  | 9,723 |  |  |  | 20,062 |  |
| Provision for income taxes |  |  | (1,833 | ) |  |  | (7,102 | ) |
| Net Income |  | $ | 7,890 |  |  | $ | 12,960 |  |
| Weighted average shares outstanding - basic |  |  | 61,847 |  |  |  | 63,809 |  |
| Weighted average shares outstanding - diluted (1) |  |  | 62,030 |  |  |  | 64,849 |  |
| Earnings per common share - basic |  | $ | 0.13 |  |  | $ | 0.20 |  |
| Earnings per common share - diluted (1) |  | $ | 0.13 |  |  | $ | 0.20 |  |
| (1) Assumes exercise of dilutive stock options calculated under the treasury stock method. |

[0001157523-13-001730:8k_2_02:15]
| Consolidated Statements of Comprehensive Income(Unaudited)(In thousands) |
|  |  | Three Months Ended |
|  |  | March 31, |
|  |  | 2013 |  | 2012 |
| Net Income |  | $ | 7,890 |  |  | $ | 12,960 |
| Other Comprehensive Income (Loss), net of tax: |  |  |  |  |
| Unrealized gains (losses) on available-for-sale securities |  |  | (1,644 | ) |  |  | 6,757 |
| Foreign currency translation |  |  | 323 |  |  |  | 153 |
| Other Comprehensive Income (Loss), net of tax |  |  | (1,321 | ) |  |  | 6,910 |
| Comprehensive Income, net of tax |  | $ | 6,569 |  |  | $ | 19,870 |

[0001157523-13-001730:8k_2_02:16]
| Consolidated Statements of Cash Flows(Unaudited)(In thousands) |
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
|  |  | 2013 |  |  |  | 2012 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |
| Net income |  | $ | 7,890 |  |  |  |  | $ | 12,960 |  |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 3,663 |  |  |  |  |  | 3,095 |  |  |
| Amortization of net premium on available-for-sale investments |  |  | 1,754 |  |  |  |  |  | 2,171 |  |  |
| Net realized gain on long-term investments |  |  | (3,645 | ) |  |  |  |  | (2,467 | ) |  |
| Net (gain) loss on disposal of property, plant and equipment |  |  | 17 |  |  |  |  |  | (214 | ) |  |
| Stock-based compensation expense |  |  | 2,232 |  |  |  |  |  | 2,221 |  |  |
| Deferred income taxes |  |  | 715 |  |  |  |  |  | (2,030 | ) |  |
| Tax benefit from stock option exercises |  |  | - |  |  |  |  |  | 1,492 |  |  |
| Excess tax benefits from stock-based compensation arrangements |  |  | - |  |  |  |  |  | (1,153 | ) |  |
| Change in operating assets and liabilities: |  |  |  |  |  |  |  |
| Accounts receivable, net |  |  | (1,306 | ) |  |  |  |  | 1,334 |  |  |
| Other receivables |  |  | (224 | ) |  |  |  |  | 1,706 |  |  |
| Inventory |  |  | 6,540 |  |  |  |  |  | (8,005 | ) |  |
| Prepaid expenses and other assets |  |  | (217 | ) |  |  |  |  | (710 | ) |  |
| Accounts payable |  |  | 7,262 |  |  |  |  |  | 1,831 |  |  |
| Accrued expenses and other liabilities |  |  | 1,188 |  |  |  |  |  | 5,287 |  |  |
| Income tax payable, net |  |  | 379 |  |  |  |  |  | 7,017 |  |  |
| Net cash provided by operating activities |  |  | 26,248 |  |  |  |  |  | 24,535 |  |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (735 | ) |  |  |  |  | (4,086 | ) |  |
| Proceeds from disposals of property, plant and equipment |  |  | - |  |  |  |  |  | 266 |  |  |
| Proceeds from sales and maturities of available-for-sale investments |  |  | 118,133 |  |  |  |  |  | 69,364 |  |  |
| Purchases of available-for-sale investments |  |  | (125,411 | ) |  |  |  |  | (95,646 | ) |  |
| Net cash used in investing activities |  |  | (8,013 | ) |  |  |  |  | (30,102 | ) |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |
| Proceeds from stock option exercises |  |  | 55 |  |  |  |  |  | 3,560 |  |  |
| Purchases of treasury stock |  |  | (22,546 | ) |  |  |  |  | - |  |  |
| Dividend payments |  |  | (5,586 | ) |  |  |  |  | (5,739 | ) |  |
| Excess tax benefits from stock-based compensation arrangements |  |  | - |  |  |  |  |  | 1,153 |  |  |
| Net cash used in financing activities |  |  | (28,077 | ) |  |  |  |  | (1,026 | ) |  |
| Net decrease in cash and cash equivalents |  |  | (9,842 | ) |  |  |  |  | (6,593 | ) |  |
| Effect of exchange rate changes |  |  | 25 |  |  |  |  |  | 153 |  |  |
| Cash and cash equivalents, beginning of period |  |  | 68,457 |  |  |  |  |  | 42,979 |  |  |
| Cash and cash equivalents, end of period |  | $ | 58,640 |  |  |  |  | $ | 36,539 |  |  |

[0001157523-13-001730:8k_2_02:17]
Supplemental Information
Acquisition Related Expenses,
      Amortizations and Adjustments
(Unaudited)
(In
      thousands)

[0001157523-13-001730:8k_2_02:18]
On August 4, 2011, we closed on the acquisition of Bluesocket, Inc. and
      on May 4, 2012, we closed on the acquisition of the Nokia Siemens
      Networks Broadband Access business (NSN BBA). Acquisition related
      expenses, amortizations and adjustments for the three months ended March
      31, 2013 and 2012 for both transactions are as follows:

[0001157523-13-001730:8k_2_02:19]
|  |  | Three Months Ended |
|  |  | March 31, |
|  |  | 2013 |  | 2012 |
| Bluesocket, Inc. acquisition |  |  |  |  |
| Amortization of acquired intangible assets and other purchase accounting adjustments |  | $ | 293 |  |  | $ | 484 |  |
| NSN BBA acquisition |  |  |  |  |
| Amortization of acquired intangible assets |  |  | 294 |  |  |  | - |  |
| Amortization of other purchase accounting adjustments |  |  | 410 |  |  |  | - |  |
| Acquisition related professional fees, travel and other expenses |  |  | 154 |  |  |  | 1,580 |  |
| Subtotal |  |  | 858 |  |  |  | 1,580 |  |
| Total acquisition related expenses, amortizations and adjustments |  |  | 1,151 |  |  |  | 2,064 |  |
| Tax effect |  |  | (380 | ) |  |  | (803 | ) |
| Total acquisition related expenses, amortizations and adjustments, net of tax |  | $ | 771 |  |  | $ | 1,261 |  |

[0001157523-13-001730:8k_2_02:20]
The acquisition related expenses, amortizations and adjustments above
      were recorded in the following Consolidated Statements of Income
      categories for the three months ended March 31, 2013 and 2012:

[0001157523-13-001730:8k_2_02:21]
|  |  | Three Months Ended |
|  |  | March 31, |
|  |  | 2013 |  | 2012 |
| Revenue (adjustments to deferred revenue recognized in the period) |  | $ | 262 |  |  | $ | 146 |  |
| Cost of goods sold |  |  | 87 |  |  |  | 137 |  |
| Subtotal |  |  | 349 |  |  |  | 283 |  |
| Selling, general and administrative expenses |  |  | 161 |  |  |  | 1,561 |  |
| Research and development expenses |  |  | 641 |  |  |  | 220 |  |
| Subtotal |  |  | 802 |  |  |  | 1,781 |  |
| Total acquisition related expenses, amortizations and adjustments |  |  | 1,151 |  |  |  | 2,064 |  |
| Tax effect |  |  | (380 | ) |  |  | (803 | ) |
| Total acquisition related expenses, amortizations and adjustments, net of tax |  | $ | 771 |  |  | $ | 1,261 |  |

[0001157523-13-001730:8k_2_02:22]
| Supplemental InformationStock-based Compensation Expense(Unaudited)(In thousands) |
|  |  | Three Months Ended |
|  |  | March 31, |
|  |  | 2013 |  | 2012 |
| Stock-based compensation expense included in cost of sales |  | $ | 106 |  |  | $ | 101 |  |
| Selling, general and administrative expense |  |  | 1,063 |  |  |  | 1,051 |  |
| Research and development expense |  |  | 1,063 |  |  |  | 1,069 |  |
| Stock-based compensation expense included in operating expenses |  |  | 2,126 |  |  |  | 2,120 |  |
| Total stock-based compensation expense |  |  | 2,232 |  |  |  | 2,221 |  |
| Tax benefit for expense associated with non-qualified options |  |  | (307 | ) |  |  | (301 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 1,925 |  |  | $ | 1,920 |  |

[0001157523-13-001730:8k_2_02:23]
| Reconciliation of GAAP net income per share, diluted, toNon-GAAP net income per share, diluted(Unaudited) |
|  |  | Three Months Ended |
|  |  | March 31, |
|  |  | 2013 |  | 2012 |
| GAAP earnings per common share – diluted |  | $ | 0.13 |  | $ | 0.20 |
| Acquisition related expenses, amortizations and adjustments |  |  | 0.01 |  |  | 0.02 |
| Stock-based compensation expense |  |  | 0.03 |  |  | 0.03 |
| Non-GAAP earnings per common share – diluted |  | $ | 0.17 |  | $ | 0.25 |

[0001157523-13-001730:8k_2_02:24]
CONTACT:
ADTRAN, Inc.
Jim Matthews, 256-963-8775
Senior Vice
      President/CFO
or
Investor Services/Assistance:
Gayle Ellis,
      256-963-8220
