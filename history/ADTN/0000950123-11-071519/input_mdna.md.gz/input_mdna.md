# ADTN MD&A — 0000950123-11-071519


## mdna

[0000950123-11-071519:mdna:1]
| ITEM 2. |  | MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS |

[0000950123-11-071519:mdna:2]
[same as prior period, unchanged from 0000950123-11-045439:mdna:2]

[0000950123-11-071519:mdna:3]
[same as prior period, unchanged from 0000950123-11-045439:mdna:3]

[0000950123-11-071519:mdna:4]
[same as prior period, unchanged from 0000950123-11-045439:mdna:4]

[0000950123-11-071519:mdna:5]
[same as prior period, unchanged from 0000950123-11-045439:mdna:5]

[0000950123-11-071519:mdna:6]
[same as prior period, unchanged from 0000950123-11-045439:mdna:6]

[0000950123-11-071519:mdna:7]
In addition, we identify subcategories of product revenues, which we divide into growth products,
representing our primary growth areas, and traditional products. Our growth products consist of
Broadband Access and Optical Access products (included in Carrier Systems) and Internetworking
products (included in Business Networking) and our traditional products include HDSL products
(included in Loop Access) and other products not included in the aforementioned growth products.
Many of our customers are migrating their networks to deliver higher bandwidth services by
utilizing newer technologies. We believe that products and services offered in our primary growth
areas position us well for this migration. We anticipate that revenues of many of our traditional
products, including HDSL, will decline over time; however, revenues from these products may
continue for years because of the time required for our customers to transition to newer
technologies.

[0000950123-11-071519:mdna:8]
[same as prior period, unchanged from 0000950123-11-045439:mdna:8]

[0000950123-11-071519:mdna:9]
Sales were $184.2 million and $349.7 million for the three and six months ended June 30, 2011
compared to $150.4 million and $277.4 million for the three and six months ended June 30, 2010.
Product revenues for our three primary growth areas, Broadband Access, Optical Access and
Internetworking, were $132.1 million and $237.7 million for the three and six months ended June 30,
2011 compared to $89.0 million and $158.8 million for the three and six months ended June 30, 2010.
Our gross margin decreased to 58.0% and 58.8% for the three and six months ended June 30, 2011
from 59.4% for the three and six months ended June 30, 2010. Our operating income margin increased
to 27.9% and 27.7% for the three and six months ended June 30, 2011 from 25.7% and 23.1% for the
three and six months ended June 30, 2010. Net income was $36.9 million and $71.2 million for the
three and six months ended June 30, 2011 compared to $27.8 million and $45.9 million for the three
and six months ended June 30, 2010. Our effective tax rate increased to 34.0% for the three months
ended June 30, 2011 from 33.9% for the three months ended June 30, 2010 and decreased to
32.5% for the six months ended June 30, 2011 from 34.6% for the six months ended June 30, 2010.
Earnings per share, assuming dilution, were $0.56 and $1.08 for the three and six months ended June
30, 2011 compared to $0.44 and $0.73 for the three and six months ended June 30, 2010.

[0000950123-11-071519:mdna:10]
[same as prior period, unchanged from 0000950123-11-045439:mdna:10]

[0000950123-11-071519:mdna:11]
[same as prior period, unchanged from 0000950123-11-045439:mdna:11]

[0000950123-11-071519:mdna:12]
[same as prior period, unchanged from 0000950123-11-045439:mdna:12]

[0000950123-11-071519:mdna:13]
[same as prior period, unchanged from 0000950123-11-045439:mdna:13]

[0000950123-11-071519:mdna:14]
[same as prior period, unchanged from 0000950123-11-045439:mdna:14]

[0000950123-11-071519:mdna:15]
[same as prior period, unchanged from 0000950123-11-045439:mdna:15]

[0000950123-11-071519:mdna:16]
[same as prior period, unchanged from 0000950123-11-045439:mdna:16]

[0000950123-11-071519:mdna:17]
RESULTS OF OPERATIONS — THREE AND SIX MONTHS ENDED JUNE 30, 2011 COMPARED TO THREE AND SIX MONTHS
ENDED JUNE 30, 2010

[0000950123-11-071519:mdna:18]
[same as prior period, unchanged from 0000950123-11-045439:mdna:18]

[0000950123-11-071519:mdna:19]
ADTRAN’s sales increased 22.5% from $150.4 million in the three months ended June 30, 2010 to
$184.2 million in the three months ended June 30, 2011, and increased 26.1% from $277.4 million in
the six months ended June 30, 2010 to $349.7 million in the six months ended June 30, 2011. The
increase in sales for the three months ended June 30, 2011 is primarily attributable to a $32.1
million increase in our Broadband Access products, a $5.9 million increase in sales of our Optical
Access products, and a $5.1 million increase in sales of our Internetworking products, partially
offset by an $8.1 million decrease in sales of our HDSL products. The increase in sales for the
six months ended June 30, 2011 is primarily attributable to a $47.5 million increase in sales of
our Broadband Access products, a $15.8 million increase in sales of our Internetworking products,
and a $15.5 million increase in sales of our Optical Access products, partially offset by a $7.1
million decrease in sales of our HDSL products.

[0000950123-11-071519:mdna:20]
Carrier Networks sales increased 28.0% from $117.6 million in the three months ended June 30, 2010
to $150.5 million in the three months ended June 30, 2011, and increased 30.3% from $217.1 million
in the six months ended June 30, 2010 to $282.9 in the six months ended June 30, 2011. The
increase in sales for the three and six months ended June 30, 2011 is primarily attributable to
increases in Broadband Access, Optical Access and Internetworking NTE products sales, partially
offset by a decrease in HDSL and other traditional product sales.

[0000950123-11-071519:mdna:21]
Enterprise Networks sales increased 2.9% from $32.8 million in the three months ended June 30, 2010
to $33.7 million in the three months ended June 30, 2011, and increased 11.0% from $60.3 million in
the six months ended June 30, 2010 to $66.9 million in the six months ended June 30, 2011. The
increase for the three and six months ended June 30, 2011 is primarily attributable to an increase
in sales of Internetworking products, partially offset by a decrease in sales of traditional
products. Internetworking product sales attributable to Enterprise Networks were 85.4% and 85.2%
of the division’s sales in the three and six months ended June 30, 2011, compared to 75.7% and
74.7% in the three and six months ended June 30, 2010. Traditional products primarily comprise the
remainder of Enterprise Networks sales. Enterprise Networks sales as a percentage of total sales
decreased from 21.8% for the three months ended June 30, 2010 to 18.3% for the three months ended
June 30, 2011 and decreased from 21.7% for the six months ended June 30, 2010 to 19.1% for the six
months ended June 30, 2011.

[0000950123-11-071519:mdna:22]
International sales, which are included in the Carrier Networks and Enterprise Networks amounts
discussed above, increased 181.7% from $8.3 million in the three months ended June 30, 2010 to
$23.4 million in the three months ended June 30, 2011, and increased 138.2% from $15.0 million in
the six months ended June 30, 2010 to $35.8 million in the six months ended June 30, 2011.
International sales, as a percentage of total sales, increased from 5.5% for the three months ended
June 30, 2010 to 12.7% for the three months ended June 30, 2011, and increased from 5.4% for the
six months ended June 30, 2010 to 10.2% for the six ended June 30, 2011. International
sales increased in the three and six months ended June 30, 2011 compared to the three and six
months ended June 30, 2010 primarily due to an increase in sales to Latin America and Europe, partially
offset by a decrease in sales to Australia and Asia.

[0000950123-11-071519:mdna:23]
Carrier System product sales increased $39.1 million and $67.8 million in the three and six months
ended June 30, 2011 compared to the three and six months ended June 30, 2010. The increase for the
three months ended June 30, 2011 is primarily due to a $32.1 million increase in Broadband Access
product sales and a $5.9 million increase in Optical Access product sales. The increase for the
six months ended June 30, 2011 is primarily due to a $47.5 million increase in Broadband Access
product sales and a $15.5 million increase in Optical Access product sales. The increase in
Broadband Access product sales is primarily attributable to continued growth in deployments of our
Total Access 5000 and Fiber-to-the-Node platforms.

[0000950123-11-071519:mdna:24]
Business Networking product sales increased $3.5 million and $13.4 million in the three and six
months ended June 30, 2011 compared to the three and six months ended June 30, 2010. The increase
for the three months ended June 30, 2011 is primarily due to a $5.1 million increase in
Internetworking product sales across both divisions, partially offset by a $1.6 million decrease in
other traditional product sales. The increase for the six months ended June 30, 2011 is primarily
due to a $15.8 million increase in Internetworking product sales across both divisions, partially
offset by a $2.4 million decrease in other traditional product sales. The decrease in sales of
traditional products is a result of customers shifting to newer technologies. Many of these newer
technologies are integral to our Internetworking product area.

[0000950123-11-071519:mdna:25]
Loop Access product sales decreased $8.8 million and $8.9 million in the three and six months ended
June 30, 2011 compared to the three and six months ended June 30, 2010. The decrease for the three
months ended June 30, 2011 is primarily due to an $8.1 million decrease in HDSL product sales. The
decrease for the six months ended June 30, 2011 is primarily due to a $7.1 million decrease in HDSL
product sales.

[0000950123-11-071519:mdna:26]
[same as prior period, unchanged from 0000950123-11-045439:mdna:26]

[0000950123-11-071519:mdna:27]
As a percentage of sales, cost of sales increased from 40.6% in the three months ended June 30,
2010 to 42.0% in the three months ended June 30, 2011 and increased from 40.6% in the six months
ended June 30, 2010 to 41.2% in the six months ended June 30, 2011. This increase is primarily the
result of a higher mix of lower gross margin professional services revenue and cabinet revenue, and
expediting costs of production materials related to a specific customer project.

[0000950123-11-071519:mdna:28]
Carrier Networks cost of sales, as a percent of division sales, increased from 40.2% in the three
months ended June 30, 2010 to 41.9% in the three months ended June 30, 2011 and increased from
40.3% in the six months ended June 30, 2010
to 41.0% in the six months ended June 30, 2011. The increase in Carrier Networks cost of sales as
a percentage of sales is primarily attributable to the impact of changes in sales mix and cost
elements discussed above.

[0000950123-11-071519:mdna:29]
Enterprise Networks cost of sales, as a percent of division sales, increased from 41.9% in the
three months ended June 30, 2010 to 42.6% in the three months ended June 30, 2011 and increased
from 41.7% in the six months ended June 30, 2010 to 42.2% in the six months ended June 30, 2011.
The increase is primarily attributable to a higher cost product mix.

[0000950123-11-071519:mdna:30]
[same as prior period, unchanged from 0000950123-11-045439:mdna:30]

[0000950123-11-071519:mdna:31]
[same as prior period, unchanged from 0000950123-11-045439:mdna:31]

[0000950123-11-071519:mdna:32]
Selling, general and administrative expenses increased 8.6% from $28.5 million in the three months
ended June 30, 2010 to $30.9 million in the three months ended June 30, 2011 and increased 8.6%
from $55.7 million in the six months ended June 30, 2010 to $60.5 million in the six months ended
June 30, 2011. The increase in selling, general and administrative expenses for the three and six
month periods ended June 30, 2011 is primarily related to increased staffing and fringe benefit
costs due to increased headcount, and increases in incentive compensation, contract services and
recruiting expenses.

[0000950123-11-071519:mdna:33]
Selling, general and administrative expenses as a percentage of sales decreased from 18.9% in the
three months ended June 30, 2010 to 16.8% in the three months ended June 30, 2011 and decreased
from 20.1% in the six months ended June 30, 2011 to 17.3% in the six months ended June 30, 2011.
Selling, general and administrative expenses as a percentage of sales may fluctuate whenever there
is a significant fluctuation in revenues for the periods being compared.

[0000950123-11-071519:mdna:34]
[same as prior period, unchanged from 0000950123-11-045439:mdna:34]

[0000950123-11-071519:mdna:35]
Research and development expenses increased 10.6% from $22.3 million in the three months ended June
30, 2010 to $24.6 million in the three months ended June 30, 2011 and increased 7.1% from $45.0
million in the six months ended June 30, 2010 to $48.3 million in the six months ended June 30,
2011. The increase in research and development expenses for the three and six months ended June
30, 2011 reflects increased staffing and fringe benefit costs due to increased headcount, and an
increase in customer specific testing expenses. As a percentage of sales, research and development expenses
decreased from 14.8% in the three months ended June 30, 2010 to 13.4% in the three months ended
June 30, 2011 and decreased from 16.2% in the six months ended June 30, 2010 to 13.8% in the six
months ended June 30, 2011. Research and development expenses as a percentage of sales will
fluctuate whenever there are incremental product development activities or a significant
fluctuation in revenues for the periods being compared.

[0000950123-11-071519:mdna:36]
[same as prior period, unchanged from 0000950123-11-045439:mdna:36]

[0000950123-11-071519:mdna:37]
[same as prior period, unchanged from 0000950123-11-045439:mdna:37]

[0000950123-11-071519:mdna:38]
Interest and dividend income increased 21.1% from $1.7 million in the three months ended June 30,
2010 to $2.0 million in the three months ended June 30, 2011 and increased 19.2% from $3.2 million
in the six months ended June 30, 2010 to $3.8 million in the six months ended June 30, 2011. The
increase for the three months ended June 30, 2011 is primarily driven by a 25.5% increase in our
average investment balances, partially offset by a 26.3% reduction in the average rate of return on
our investments as a result of lower interest rates. The increase for the six months ended June
30, 2011 is primarily driven by a 23.1% increase in our average investment balances, partially
offset by a 20.0% reduction in the average rate of return on our investments as a result of lower
interest rates.

[0000950123-11-071519:mdna:39]
[same as prior period, unchanged from 0000950123-11-045439:mdna:39]

[0000950123-11-071519:mdna:40]
Interest expense, which is primarily related to our taxable revenue bond, remained constant at $0.6
million in each of the three months ended June 30, 2011 and 2010 and $1.2 million in each of the
six months ended June 30, 2011 and 2010, respectively. See “Liquidity and Capital Resources” below
for additional information on our revenue bond.

[0000950123-11-071519:mdna:41]
[same as prior period, unchanged from 0000950123-11-045439:mdna:41]

[0000950123-11-071519:mdna:42]
Net realized investment gain increased 36.9% from $2.5 million in the three months ended June 30,
2010 to $3.4 million in the three months ended June 30, 2011 and increased 31.9% from $4.7 million
in the six months ended June 30, 2010 to a $6.1 million in the six months ended June 30, 2011. The
increase for the three and six months ended June 30, 2011 is the result of realized gains from the
realignment of our fixed income and deferred compensation portfolios. See “Investing Activities”
in “Liquidity and Capital Resources” below for additional information.

[0000950123-11-071519:mdna:43]
[same as prior period, unchanged from 0000950123-11-045439:mdna:43]

[0000950123-11-071519:mdna:44]
Other expense, net, comprised primarily of miscellaneous income, gains and losses on foreign
currency transactions, investment account management fees, scrap raw material sales, and gains and
losses on the disposal of property, plant and equipment occurring in the normal course of business,
decreased from $0.2 million in the three months ended June 30, 2010 to $0.1 million in the three
months ended June 30, 2011 and decreased from $0.4 million in the six months ended June 30, 2010 to
$0.2 million in the six months ended June 30, 2011.

[0000950123-11-071519:mdna:45]
[same as prior period, unchanged from 0000950123-11-045439:mdna:45]

[0000950123-11-071519:mdna:46]
Our effective tax rate decreased from 34.6% in the six months ended June 30, 2010 to 32.5% in the six months ended June 30, 2011. The decrease is primarily attributable to the research tax credit and increased tax benefits from a higher volume of stock option exercises during the six months ended June 30, 2011. The inclusion of the benefit for the research tax credit in the six months ended June 30,
2011 resulted in a 2.2 percentage point decrease in our tax rate. In addition, increased benefits from a higher volume of stock
option exercises during the six months ended June 30, 2011 resulted in a 1.6 percentage point decrease in
our tax rate.

[0000950123-11-071519:mdna:47]
The tax provision rate in 2010 was affected by a benefit related to the completion of an audit for the years 2006 and 2007
by the Internal Revenue Service and a larger manufacturer's deduction. The completion of the audit provided a 1.0 percentage point
benefit during the six months ended June 30, 2010. The higher manufacturer's deduction resulted in a 0.7 percentage point benefit in our effective tax rate for the six months ended June 30, 2010. Also, the tax provision rate in the first six months of 2010 did not include the benefit of the research tax credit,
which expired on December 31, 2009. The credit was reinstated during the fourth quarter of 2010.

[0000950123-11-071519:mdna:48]
[same as prior period, unchanged from 0000950123-11-045439:mdna:47]

[0000950123-11-071519:mdna:49]
As a result of the above factors, net income increased $9.2 million from $27.8 million in the three
months ended June 30, 2010 to $36.9 million in the three months ended June 30, 2011 and increased
$25.3 million from $45.9 million in the six months ended June 30, 2010 to $71.2 million in the six
months ended June 30, 2011.

[0000950123-11-071519:mdna:50]
As a percentage of sales, net income increased from 18.5% in the three months ended June 30, 2010
to 20.1% in the three months ended June 30, 2011 and increased from 16.6% in the six months ended
June 30, 2010 to 20.4% in the six months ended June 30, 2011.

[0000950123-11-071519:mdna:51]
[same as prior period, unchanged from 0000950123-11-045439:mdna:50]

[0000950123-11-071519:mdna:52]
[same as prior period, unchanged from 0000950123-11-045439:mdna:51]

[0000950123-11-071519:mdna:53]
[same as prior period, unchanged from 0000950123-11-045439:mdna:52]

[0000950123-11-071519:mdna:54]
At June 30, 2011, cash on hand was $23.8 million and short-term investments were $138.7 million,
which resulted in available short-term liquidity of $162.5 million. At December 31, 2010, our cash
on hand of $31.7 million and short-term investments of $157.5 million resulted in available
short-term liquidity of $189.2 million. The decrease in short-term liquidity from December 31,
2010 to June 30, 2011 primarily reflects a realignment of our fixed income portfolio from
short-term to long-term, which increased long-term investments by $111.3 million during the six
months ended June 30, 2011.

[0000950123-11-071519:mdna:55]
[same as prior period, unchanged from 0000950123-11-045439:mdna:54]

[0000950123-11-071519:mdna:56]
Our working capital, which consists of current assets less current liabilities, decreased 3.3% from
$305.0 million as of December 31, 2010 to $294.9 million as of June 30, 2011. The quick ratio,
defined as cash, cash equivalents, short-term investments, and net accounts receivable, divided by
current liabilities, decreased from 5.21 as of December 31, 2010 to 3.82 as of June 30, 2011. The
current ratio, defined as current assets divided by current liabilities, decreased from 7.10 as of
December 31, 2010 to 5.59 as of June 30, 2011. Our working capital, the quick ratio, and the
current ratio decreased due to a decrease in short-term investments of $18.8 million, which was a
result of the realignment of our fixed income portfolio from short-term to long-term, and an
increase in accounts payable of $15.7 million. Generally, the change in accounts payable is due to
variations in the timing of the receipt of supplies, inventory and services and our subsequent
payments for these purchases.

[0000950123-11-071519:mdna:57]
Net accounts receivable increased 17.5% from $70.9 million at December 31, 2010 to $83.3 million at
June 30, 2011. Our allowance for doubtful accounts was $0.2 million at December 31, 2010 and $21
thousand at June 30, 2011. Quarterly accounts receivable days sales outstanding (DSO) increased
from 39 days as of December 31, 2010 to 41 days as of June 30, 2011. Net accounts receivable and
DSO increased for the quarter ended June 30, 2011 due to the timing of sales and collections during
the quarter. Other receivables increased from $4.0 million at December 31, 2010 to $10.4 million
at June 30, 2011. Generally, the change in other receivables is due to the timing of shipments and
payments received for materials supplied to our contract manufacturers.

[0000950123-11-071519:mdna:58]
Quarterly inventory turnover decreased from 3.8 turns as of December 31, 2010 to 3.7 turns as of
June 30, 2011. Inventory increased 16.7% from December 31, 2010 to June 30, 2011. Our investment
in inventory increased during the six months ended June 30, 2011 to support increasing customer
demand, increases in inventories related to an increase in installation services activities, and to
mitigate component supply constraints broadly affecting the industry. We expect inventory levels
to fluctuate as we attempt to maintain sufficient inventory in response to seasonal cycles of our
business; ensuring competitive lead times while managing the risk of inventory obsolescence that
may occur due to rapidly changing technology and customer demand.

[0000950123-11-071519:mdna:59]
Accounts payable increased 68.9% from $22.8 million at December 31, 2010 to $38.5 million at June
30, 2011. Generally, the change in accounts payable is due to variations in the timing of the
receipt of supplies, inventory and services and our subsequent payments for these purchases.

[0000950123-11-071519:mdna:60]
[same as prior period, unchanged from 0000950123-11-045439:mdna:59]

[0000950123-11-071519:mdna:61]
Capital expenditures totaled approximately $6.3 million and $4.8 million for the six months ended
June 30, 2011 and 2010, respectively. These expenditures were primarily used to purchase
manufacturing and test equipment and computer software and hardware.

[0000950123-11-071519:mdna:62]
Our combined short-term and long-term investments increased $92.5 million from $418.6 million at
December 31, 2010 to $511.1 million at June 30, 2011. This increase reflects the impact of
additional funds available for investment provided by our operating activities and proceeds from
stock option exercises by our employees, reduced by our cash needs for equipment acquisitions and
dividends, as well as net realized and unrealized losses and amortization of net premiums on our
combined investments.

[0000950123-11-071519:mdna:63]
We invest all available cash not required for immediate use in operations primarily in securities
that we believe bear minimal risk of loss. At June 30, 2011 these investments included municipal
variable rate demand notes of $94.9 million, municipal fixed-rate bonds of $117.9 million and
corporate bonds of $200.9 million. At December 31, 2010, these investments included municipal
variable rate demand notes of $116.7 million, municipal fixed-rate bonds of $71.5 million and
corporate bonds of $127.1 million.

[0000950123-11-071519:mdna:64]
At June 30, 2011, we held $94.9 million of municipal variable rate demand notes, all of which were
classified as available-for-sale. At June 30, 2011, 27% of our municipal variable rate demand
notes had a credit rating of AAA, 63% had a credit rating of AA, 10% had a credit rating of A, and
all contained put options of seven days. Despite the long-term nature of their stated contractual
maturities, we routinely buy and sell these securities and we believe that we have the ability to
quickly liquidate them. Our investments in these securities are recorded at fair value, and the
interest rates reset every seven days. We believe we have the ability to sell our variable rate
demand notes to the remarketing agent, tender agent or issuer at par value plus accrued interest in
the event we decide to liquidate our investment in a particular variable rate demand note. At June
30, 2011, approximately 24% of our variable rate demand notes were supported by
letters of credit from banks that we believe to be in good financial condition. The remaining 76%
of our variable rate demand notes were supported by standby purchase agreements. As a result of
these factors, we had no cumulative gross unrealized holding gains (losses) or gross realized gains
(losses) from these investments. All income generated from these investments was recorded as
interest income. We have not recorded any losses relating to municipal variable rate demand notes.

[0000950123-11-071519:mdna:65]
At June 30, 2011, we held $117.9 million of municipal fixed-rate bonds. These bonds are classified
as available-for-sale and had an average duration of 1.3 years at June 30, 2011. At June 30, 2011,
approximately 24% of our municipal fixed-rate bond portfolio had a credit rating of AAA, 58% had a
credit rating of AA, and 18% had a credit rating of A. Because our bond portfolio has a high
quality rating and contractual maturities of a short duration, we are able to obtain prices for
these bonds derived from observable market inputs, or for similar securities traded in an active
market, on a daily basis.

[0000950123-11-071519:mdna:66]
At June 30, 2011, we held $200.9 million of corporate bonds. These bonds are classified as
available-for-sale and had an average duration of 2.2 years at June 30, 2011. At June 30, 2011,
approximately 1% of our corporate bond portfolio had a credit rating of AAA, 14% had a credit
rating of AA, 55% had a credit rating of A, and 30% had a credit rating of BBB. Because our bond
portfolio has a high quality rating and contractual maturities of a short duration, we are able to
obtain prices for these bonds derived from observable market inputs, or for similar securities
traded in an active market, on a daily basis.

[0000950123-11-071519:mdna:67]
Our long-term investments increased 42.6% from $261.2 million at December 31, 2010 to $372.4
million at June 30, 2011. The primary reasons for the increase in our long-term investments were
cash generated from operations and proceeds from stock option exercises by our employees.
Long-term investments at June 30, 2011 and December 31, 2010 included an investment in a
certificate of deposit of $48.3 million, which serves as collateral for our revenue bonds, as
discussed below. We have various equity investments included in long-term investments at a cost of
$12.1 million and $11.5 million, and with a fair value of $39.4 million and $48.0 million, at June
30, 2011 and December 31, 2010, respectively, including a single equity security, of which we held
1.3 million shares and 1.5 million shares, carried at $24.3 million and $34.2 million of fair value
at June 30, 2011 and December 31, 2010, respectively. The single security traded approximately 0.9
million shares per day in the six months ended June 30, 2011 in an active market on a European
stock exchange. Of the gross unrealized gains included in the fair value of our marketable
securities at June 30, 2011, this single security comprised $23.8 million of this unrealized gain.
Long-term investments at June 30, 2011 also include $6.8 million related to our deferred
compensation plan; $2.3 million of other investments carried at cost, consisting of interests in
two private equity funds and an investment in a privately held telecommunications equipment
manufacturer; and $0.8 million of a fixed income bond fund.

[0000950123-11-071519:mdna:68]
We review our investment portfolio for potential “other-than-temporary” declines in value on an
individual investment basis. We assess, on a quarterly basis, significant declines in value which
may be considered other-than-temporary and, if necessary, recognize and record the appropriate
charge to write-down the carrying value of such investments. In making this assessment, we take
into consideration qualitative and quantitative information, including but not limited to the
following: the magnitude and duration of historical declines in market prices, credit rating
activity, assessments of liquidity, public filings, and statements made by the issuer. We
generally begin our identification of potential other-than-temporary impairments by reviewing any
security with a fair value that has declined from its original or adjusted cost basis by 25% or
more for six or more consecutive months. We then evaluate the individual security based on the
previously identified factors to determine the amount of the write-down, if any. As a result of
our review, we recorded an other-than-temporary impairment charge of $12 thousand during the six
months ended June 30, 2011 related to three marketable equity securities. For the six months ended
June 30, 2010, we recorded an other-than-temporary impairment charge of $42 thousand related to
three marketable equity securities.

[0000950123-11-071519:mdna:69]
[same as prior period, unchanged from 0000950123-11-045439:mdna:69]

[0000950123-11-071519:mdna:70]
[same as prior period, unchanged from 0000950123-11-045439:mdna:70]

[0000950123-11-071519:mdna:71]
In July 2003, our Board of Directors elected to begin declaring quarterly dividends on our common
stock considering the tax treatment of dividends and adequate levels of Company liquidity. During
the six months ended June 30, 2011, we paid dividends totaling $11.6 million.

[0000950123-11-071519:mdna:72]
[same as prior period, unchanged from 0000950123-11-045439:mdna:72]

[0000950123-11-071519:mdna:73]
We have amounts outstanding under loans made pursuant to an Alabama State Industrial Development
Authority revenue bond (the Bond) which totaled $48.0 million at June 30, 2011 and December 31,
2010. At June 30, 2011, the estimated fair value of the Bond was approximately $46.0 million,
based on a debt security with a comparable interest rate and maturity and a Standard & Poor’s
credit rating of A+. Included in long-term investments are restricted funds in the amount of $48.3
million at June 30, 2011 and December 31, 2010, which is a collateral deposit against the principal
amount of the Bond. We have the right to set-off the balance of the Bond with the collateral
deposit in order to reduce the balance of the indebtedness. The Bond matures on January 1, 2020,
and bears interest at the rate of 5% per annum. In conjunction with this program, we are eligible
to receive certain economic incentives from the state of Alabama that reduce the amount of payroll
withholdings we are required to remit to the state for those employment positions that qualify
under this program.

[0000950123-11-071519:mdna:74]
[same as prior period, unchanged from 0000950123-11-045439:mdna:74]

[0000950123-11-071519:mdna:75]
[same as prior period, unchanged from 0000950123-11-045439:mdna:75]

[0000950123-11-071519:mdna:76]
Since 1997, our Board of Directors has approved multiple share repurchase programs authorizing open
market repurchase transactions of up to 30 million shares of our common stock. During the six
months ended June 30, 2011, we did not repurchase any shares of our common stock. We have the
authority to purchase an additional 2.0 million shares of our common stock under the plan approved
by the Board of Directors on April 14, 2008.

[0000950123-11-071519:mdna:77]
To accommodate employee stock option exercises, we issued 1.7 million shares of treasury stock for
$33.0 million during the six months ended June 30, 2011. During the six months ended June 30,
2010, we issued 0.5 million shares of treasury stock for $7.4 million.

[0000950123-11-071519:mdna:78]
[same as prior period, unchanged from 0000950123-11-045439:mdna:78]

[0000950123-11-071519:mdna:79]
We do not have off-balance sheet financing arrangements and have not engaged in any related party
transactions or arrangements with unconsolidated entities or other persons that are reasonably
likely to materially affect liquidity or the availability of or requirements for capital resources.
During the six months ended June 30, 2011, there have been no material changes in contractual
obligations and commercial commitments from those discussed in our most recent Annual Report on
Form 10-K for the year ended December 31, 2010 filed on February 25, 2011 with the SEC.

[0000950123-11-071519:mdna:80]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, and we
have contributed $8.4 million as of June 30, 2011, of which $7.7 million has been applied to these
commitments. See Note 4 of Notes to Consolidated Financial Statements for additional information.

[0000950123-11-071519:mdna:81]
[same as prior period, unchanged from 0000950123-11-045439:mdna:81]

[0000950123-11-071519:mdna:82]
[same as prior period, unchanged from 0000950123-11-045439:mdna:82]

[0000950123-11-071519:mdna:83]
|  | • |  | Our operating results may fluctuate in future periods, which may adversely affect our stock price. |

[0000950123-11-071519:mdna:84]
|  | • |  | Our revenue for a particular period can be difficult to predict, and a shortfall in revenue may harm our operating results. |

[0000950123-11-071519:mdna:85]
|  | • |  | General economic conditions may reduce our revenues and harm our operating results. |

[0000950123-11-071519:mdna:86]
|  | • |  | Our exposure to the credit risks of our customers and distributors may make it difficult to collect accounts receivable and could adversely affect our operating results and financial condition. |

[0000950123-11-071519:mdna:87]
|  | • |  | We expect gross margin to vary over time, and our level of product gross margin may not be sustainable. |

[0000950123-11-071519:mdna:88]
|  | • |  | We must continue to update and improve our products and develop new products in order to compete and to keep pace with improvements in telecommunications technology. |

[0000950123-11-071519:mdna:89]
|  | • |  | Our products may not continue to comply with the regulations governing their sale, which may harm our business. |

[0000950123-11-071519:mdna:90]
|  | • |  | Our failure or the failure of our contract manufacturers to comply with applicable environmental regulations could adversely impact our results of operations. |

[0000950123-11-071519:mdna:91]
|  | • |  | If our products do not interoperate with our customers’ networks, installations may be delayed or cancelled, which could harm our business. |

[0000950123-11-071519:mdna:92]
|  | • |  | The lengthy approval process required by major and other service providers for new products could result in fluctuations in our revenue. |

[0000950123-11-071519:mdna:93]
|  | • |  | We engage in research and development activities to improve the application of developed technologies, and as a consequence may miss certain market opportunities enjoyed by larger companies with substantially greater research and development efforts who may focus on more leading edge development. |

[0000950123-11-071519:mdna:94]
|  | • |  | We depend heavily on sales to certain customers; the loss of any of these customers would significantly reduce our revenues and net income. |

[0000950123-11-071519:mdna:95]
|  | • |  | Our strategy of outsourcing a portion of our manufacturing requirements to subcontractors located in Asia may result in us not meeting our cost, quality or performance standards. |

[0000950123-11-071519:mdna:96]
|  | • |  | Our dependence on a limited number of suppliers may prevent us from delivering our products on a timely basis, which could have a material adverse effect on customer relations and operating results. |

[0000950123-11-071519:mdna:97]
|  | • |  | We compete in markets that have become increasingly competitive, which may result in reduced gross profit margins and market share. |

[0000950123-11-071519:mdna:98]
|  | • |  | Our estimates regarding future warranty obligations may change due to product failure rates, shipment volumes, field service obligations and other rework costs incurred in correcting product failures. If our estimates change, the liability for warranty obligations may be increased or decreased, impacting future cost of goods sold. |

[0000950123-11-071519:mdna:99]
|  | • |  | Managing our inventory is complex and may include write-downs of excess or obsolete inventory. |

[0000950123-11-071519:mdna:100]
|  | • |  | We may pursue acquisitions, which may expose us to a number of risks. If we are unable to mitigate these risks, our business may be negatively impacted. |

[0000950123-11-071519:mdna:101]
|  | • |  | Increased sales volume in international markets could result in increased costs or loss of revenue due to factors inherent in these markets. |

[0000950123-11-071519:mdna:102]
|  | • |  | We may be adversely affected by fluctuations in currency exchange rates. |

[0000950123-11-071519:mdna:103]
|  | • |  | Our success depends on our ability to reduce the selling prices of succeeding generations of our products. |

[0000950123-11-071519:mdna:104]
|  | • |  | Our failure to maintain rights to intellectual property used in our business could adversely affect the development, functionality, and commercial value of our products. |

[0000950123-11-071519:mdna:105]
|  | • |  | Software under license from third parties for use in certain of our products may not continue to be available to us on commercially reasonable terms. |

[0000950123-11-071519:mdna:106]
|  | • |  | We may incur liabilities or become subject to litigation that would have a material effect on our business. |

[0000950123-11-071519:mdna:107]
|  | • |  | Consolidation and deterioration in the competitive service provider market could result in a significant decrease in our revenue. |

[0000950123-11-071519:mdna:108]
|  | • |  | We depend on distributors who maintain inventories of our products. If the distributors reduce their inventories of these products, our sales could be adversely affected. |

[0000950123-11-071519:mdna:109]
|  | • |  | If we are unable to successfully develop relationships with system integrators, service providers, and enterprise value added resellers, our sales may be negatively affected. |

[0000950123-11-071519:mdna:110]
|  | • |  | If we fail to manage our exposure to worldwide financial and securities markets successfully, our operating results and financial statements could be materially impacted. |

[0000950123-11-071519:mdna:111]
|  | • |  | Changes in our effective tax rate or assessments arising from tax audits may have an adverse impact on our results. |

[0000950123-11-071519:mdna:112]
|  | • |  | Our success depends on attracting and retaining key personnel. |

[0000950123-11-071519:mdna:113]
|  | • |  | Regulatory and potential physical impacts of climate change may affect our customers and our production operations, resulting in adverse effects on our operating results. |

[0000950123-11-071519:mdna:114]
|  | • |  | While we believe our internal control over financial reporting is adequate, a failure to maintain effective internal control over financial reporting as our business expands could result in a loss of investor confidence in our financial reports and have an adverse effect on our stock price. |

[0000950123-11-071519:mdna:115]
|  | • |  | The price of our common stock has been volatile and may continue to fluctuate significantly. |

[0000950123-11-071519:mdna:116]
[same as prior period, unchanged from 0000950123-11-045439:mdna:117]

[0000950123-11-071519:mdna:117]
27
