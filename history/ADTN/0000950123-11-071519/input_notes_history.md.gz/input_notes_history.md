# ADTN note change history — 0000950123-11-045439 → 0000950123-11-071519


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2011-08-02):
[0000950123-11-071519:note_history:1]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, and we
   have contributed $8.4 million as of June 30, 2011, of which $7.7 million has been applied to these
   commitments. See Note 4 of Notes to Consolidated Financial Statements for additional information.
  (was, 2011-05-05, similarity 0.9841):
[0000950123-11-045439:note_history:1]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, and we
   have contributed $8.0 million as of March 31, 2011, of which $7.4 million has been applied to these
   commitments. See Note 4 of Notes to Consolidated Financial Statements for additional information.


## adtn:BasisOfPresentationPolicyTextBlock (critical_accounting_estimates) — matched_by: no_prior_note, score: 0.0

- added (2011-08-02):
[0000950123-11-071519:note_history:2]
The accompanying unaudited consolidated financial statements of ADTRAN®, Inc. and its
   subsidiaries (ADTRAN) have been prepared pursuant to the rules and regulations for reporting on
   Quarterly Reports on Form 10-Q. Accordingly, certain information and notes required by generally
   accepted accounting principles for complete financial statements are not included herein. The
   December 31, 2010 Consolidated Balance Sheet is derived from audited financial statements, but does
   not include all disclosures required by accounting principles generally accepted in the United
   States.

- added (2011-08-02):
[0000950123-11-071519:note_history:3]
In the opinion of management, all adjustments necessary for a fair presentation of these interim
   statements have been included and are of a normal and recurring nature. The results of operations
   for an interim period are not necessarily indicative of the results for the full year. The interim
   statements should be read in conjunction with the financial statements and notes thereto included
   in ADTRAN’s Annual Report on Form 10-K for the year ended December 31, 2010, filed on February 25,
   2011 with the SEC.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2011-08-02):
[0000950123-11-071519:note_history:4]
In June 2011, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update
   No. 2011-05, Presentation of Comprehensive Income (ASU 2011-05). ASU 2011-05 requires companies to
   present the components of net income and other comprehensive income either as one continuous
   statement or as two consecutive statements. ASU 2011-05 eliminates the option to present the
   components of other comprehensive income as part of the statement of changes in stockholders’
   equity. While ASU 2011-05 changes the presentation of comprehensive income, it does not change the
   components that are recognized in net income or comprehensive income under current accounting
   guidance. This update is effective for fiscal years, and interim periods within those years,
   ending after December 15, 2011, with early adoption permitted. Since ASU 2011-05 affects
   presentation only, it will have no effect on our consolidated results of operations or financial
   condition.

- added (2011-08-02):
[0000950123-11-071519:note_history:5]
In May 2011, the FASB issued Accounting Standards Update No. 2011-04, Amendments to Achieve Common
   Fair Value Measurement and Disclosure Requirements in U.S. GAAP and IFRSs(ASU 2011-04). ASU
   2011-04 is intended to improve the comparability of fair value measurements presented and disclosed
   in financial statements prepared in accordance with U.S. GAAP and IFRS. The amendments are of two
   types: (i) those that clarify the Board’s intent about the application of existing fair value
   measurement and disclosure requirements and (ii) those that change a particular principle or
   requirement for measuring fair value or for disclosing information about fair value measurements.
   This update is effective for annual periods beginning after December 15, 2011. We do not expect
   the adoption of this amendment will have a material impact on our consolidated results of
   operations or financial condition.

- changed (2011-08-02):
[0000950123-11-071519:note_history:6]
During the six months ended June 30, 2011, we adopted the following accounting standards, which had no material effect on our
   consolidated results of operations or financial condition:
  (was, 2011-05-05, similarity 0.9054):
[0000950123-11-045439:note_history:6]
During the first quarter of 2011, we adopted the following accounting standards, which had no
   material effect on our consolidated results of operations or financial condition:

- changed (2011-08-02):
[0000950123-11-071519:note_history:7]
In October 2009, the FASB issued Accounting Standards Update No. 2009-13, Multiple-Deliverable
   Revenue Arrangements (ASU 2009-13). ASU 2009-13 provides amendments to the criteria in Subtopic
   605-25 of the ASC for separating consideration in multiple-deliverable arrangements. As a result
   of those amendments, multiple-deliverable
   arrangements will be separated in more circumstances than under existing U.S. GAAP. ASU 2009-13
   establishes a selling price hierarchy for determining the selling price of a deliverable and will
   replace the term fair value in the revenue allocation guidance with selling price to clarify that
   the allocation of revenue is based on entity-specific assumptions rather than assumptions of a
   marketplace participant. ASU 2009 -13 will also eliminate the residual method of allocation and
   require that arrangement consideration be allocated at the inception of the arrangement to all
   deliverables using the relative selling price method and will require that a vendor determine its
   best estimate of selling price in a manner that is consistent with that used to determine the price
   to sell the deliverable on a standalone basis.
  (was, 2011-05-05, similarity 0.6489):
[0000950123-11-045439:note_history:7]
In October 2009, the Financial Accounting Standards Board (FASB) issued Update No. 2009-13, which
   amends the Revenue Recognition topic of the FASB Accounting Standards Codification (ASC). This
   update provides amendments to the criteria in Subtopic 605-25 of the ASC for separating
   consideration in multiple-deliverable arrangements. As a result of those amendments,
   multiple-deliverable arrangements will be separated in more circumstances than under existing U.S.
   GAAP. The amendments establish a selling price hierarchy for determining the selling price of a
   deliverable and will replace the term fair value in the revenue allocation guidance with selling
   price to clarify that the allocation of revenue is based on entity-specific assumptions rather than
   assumptions of a marketplace participant. The amendments will also eliminate the residual method
   of allocation and require that arrangement consideration be allocated at the inception of the
   arrangement to all deliverables using the relative selling price method and will require that a
   vendor determine its best estimate of selling price in a manner that is consistent with that used
   to determine the price to sell the deliverable on a standalone basis.

- changed (2011-08-02):
[0000950123-11-071519:note_history:8]
We adopted this amendment during the first quarter of 2011. The adoption of this amendment had no
   effect on our consolidated results of operations and financial condition for the three or six
   months ended June 30, 2011.
  (was, 2011-05-05, similarity 0.6523):
[0000950123-11-045439:note_history:8]
We adopted this guidance for the three months ended March 31, 2011. The adoption of this guidance
   had no effect on our consolidated results of operations and financial condition for the three
   months ended March 31, 2011.

- added (2011-08-02):
[0000950123-11-071519:note_history:9]
In October 2009, the FASB issued Accounting Standards Update No. 2009-14, Certain Revenue
   Arrangements that Include Software Arrangements. ASU 2009-14 changes the accounting model for
   revenue arrangements that include both tangible products and software elements. Tangible products
   containing software components and non-software components that function together to deliver the
   tangible product’s essential functionality are no longer within the scope of the software revenue
   guidance in Subtopic 985-605 of the ASC. In addition, ASU 2009-14 requires that hardware
   components of a tangible product containing software components always be excluded from the
   software revenue guidance. In that regard, ASU 2009-14 provides additional guidance on how to
   determine which software, if any, relating to the tangible product also would be excluded from the
   scope of the software revenue guidance. ASU 2009-14 also provides guidance on how a vendor should
   allocate arrangement consideration to deliverables in an arrangement that includes both tangible
   products and software. ASU 2009-14 also provides further guidance on how to allocate arrangement
   consideration when an arrangement includes deliverables both included and excluded from the scope
   of the software revenue guidance. We adopted this amendment during the first quarter of 2011. The
   adoption of this amendment had no effect on our consolidated results of operations and financial
   condition for the three or six months ended June 30, 2011.

- removed (2011-08-02):
[0000950123-11-045439:note_history:10]
In October 2009, the FASB issued Update No. 2009-14, which amends the Software topic of the ASC.
   The amendments in this update change the accounting model for revenue arrangements that include
   both tangible products and software elements. Tangible products containing software components and
   non-software components that function together to deliver the tangible product’s essential
   functionality is no longer within the scope of the software revenue guidance in Subtopic 985-605 of
   the ASC. In addition, the amendments in this update require that hardware components of a tangible
   product containing software components always be excluded from the software revenue guidance. In
   that regard, the amendments provide additional guidance on how to determine which software, if any,
   relating to the tangible product also would be excluded from the scope of the software revenue
   guidance. The amendments also provide guidance on how a vendor should allocate arrangement
   consideration to deliverables in an arrangement that includes both tangible products and software.
   The amendments also provide further guidance on how to allocate arrangement consideration when an
   arrangement includes deliverables both included and excluded from the scope of the software revenue
   guidance. We adopted this guidance for the three months ended March 31, 2011. The adoption of
   this guidance had no effect on our consolidated results of operations and financial condition for
   the three months ended March 31, 2011.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2011-08-02):
[0000950123-11-071519:note_history:11]
At June 30, 2011, we held the following securities and investments, recorded at either fair
   value or cost.
  (was, 2011-05-05, similarity 0.9552):
[0000950123-11-045439:note_history:11]
At March 31, 2011, we held the following securities and investments, recorded at either fair value
   or cost.

- changed (2011-08-02):
[0000950123-11-071519:note_history:12]
At June 30, 2011, we held $6.8 million of deferred compensation plan assets, carried at fair value.
  (was, 2011-05-05, similarity 0.9508):
[0000950123-11-045439:note_history:12]
At March 31, 2011, we held $6.6 million of deferred compensation plan assets, carried at fair
   value.

- added (2011-08-02):
[0000950123-11-071519:note_history:13]
At June 30, 2011, we held $200.9 million of corporate bonds. These bonds are classified as
   available-for-sale and had an average duration of 2.2 years at June 30, 2011. At June 30, 2011,
   approximately 1% of our corporate bond portfolio had a credit rating of AAA, 14% had a credit
   rating of AA, 55% had a credit rating of A, and 30% had a credit rating of BBB. Because our bond
   portfolio has a high quality rating and contractual maturities of a short duration, we are able to
   obtain prices for these bonds derived from observable market inputs, or for similar securities
   traded in an active market, on a daily basis.

- changed (2011-08-02):
[0000950123-11-071519:note_history:14]
At June 30, 2011, we held $117.9 million of municipal fixed-rate bonds. These bonds are classified
   as available-for-sale and had an average duration of 1.3 years at June 30, 2011. At June 30, 2011,
   approximately 24% of our municipal fixed-rate bond portfolio had a credit rating of AAA, 58% had a
   credit rating of AA, and 18% had a credit rating of A. Because
   our bond portfolio has a high quality rating and contractual maturities of a short duration, we are
   able to obtain prices for these bonds derived from observable market inputs, or for similar
   securities traded in an active market, on a daily basis.
  (was, 2011-05-05, similarity 0.9631):
[0000950123-11-045439:note_history:14]
At March 31, 2011, we held $134.0 million of municipal fixed-rate bonds. These bonds are
   classified as available-for-sale and had an average duration of 1.5 years at March 31, 2011. At
   March 31, 2011, approximately 21% of our municipal fixed-rate bond portfolio had a credit rating of
   AAA, 64% had a credit rating of AA, and 15% had a credit rating of A. Because our bond portfolio
   has a high quality rating and contractual maturities of a short duration, we are able to obtain
   prices for these bonds derived from observable market inputs, or for similar securities traded in
   an active market, on a daily basis.

- changed (2011-08-02):
[0000950123-11-071519:note_history:15]
At June 30, 2011, we held $94.9 million of municipal variable rate demand notes, all of which were
   classified as available-for-sale. At June 30, 2011, 27% of our municipal variable rate demand
   notes had a credit rating of AAA, 63% had a credit rating of AA, 10% had a credit rating of A, and
   all contained put options of seven days. Despite the long-term nature of their stated contractual
   maturities, we routinely buy and sell these securities and we believe that we have the ability to
   quickly liquidate them. Our investments in these securities are recorded at fair value, and the
   interest rates reset every seven days. We believe we have the ability to sell our variable rate
   demand notes to the remarketing agent, tender agent or issuer at par value plus accrued interest in
   the event we decide to liquidate our investment in a particular variable rate demand note. At June
   30, 2011, approximately 24% of our variable rate demand notes were supported by letters of credit
   from banks that we believe to be in good financial condition. The remaining 76% of our variable
   rate demand notes were supported by standby purchase agreements. As a result of these factors, we
   had no cumulative gross unrealized holding gains (losses) or gross realized gains (losses) from
   these investments. All income generated from these investments was recorded as interest income.
   We have not recorded any losses relating to municipal variable rate demand notes.
  (was, 2011-05-05, similarity 0.9905):
[0000950123-11-045439:note_history:15]
At March 31, 2011, we held $58.7 million of municipal variable rate demand notes, all of which were
   classified as available-for-sale. At March 31, 2011, 30% of our municipal variable rate demand
   notes had a credit rating of AAA, 55% had a credit rating of AA, 15% had a credit rating of A, and
   all contained put options of seven days. Despite the long-term nature of their stated contractual
   maturities, we routinely buy and sell these securities and we believe that we have the ability to
   quickly liquidate them. Our investments in these securities are recorded at fair value, and the
   interest rates reset every seven days. We believe we have the ability to sell our variable rate
   demand notes to the remarketing agent, tender agent or issuer at par value plus accrued interest in
   the event we decide to liquidate our investment in a particular variable rate demand note. At
   March 31, 2011, approximately 38% of our variable rate demand notes were supported by letters of
   credit from banks that we believe to be in good financial condition. The remaining 62% of our
   variable rate demand notes were supported by standby purchase agreements. As a result of these
   factors, we had no cumulative gross unrealized holding gains (losses) or gross realized gains
   (losses) from these investments. All income generated from these investments was recorded as
   interest income. We have not recorded any losses relating to municipal variable rate demand notes.

- changed (2011-08-02):
[0000950123-11-071519:note_history:16]
At June 30, 2011, we held $0.8 million of a fixed income bond fund.
  (was, 2011-05-05, similarity 0.9244):
[0000950123-11-045439:note_history:16]
At March 31, 2011, we held $0.8 million of a fixed income bond fund.

- added (2011-08-02):
[0000950123-11-071519:note_history:17]
At June 30, 2011, we held $39.4 million of marketable equity securities, including a single
   security, of which we held 1.3 million shares, carried at a fair value of $24.3 million. We sold
   0.2 million shares of this security during the six months ended June 30, 2011. The sale of this
   security resulted in proceeds of $4.2 million and a realized gain of $4.1 million. This single
   security traded approximately 0.9 million shares per day in the first six months of 2011 in an
   active market on a European stock exchange. This single security comprises $23.8 million of the
   gross unrealized gains included in the fair value of our marketable equity securities at June 30,
   2011. The remaining $3.7 million of gross unrealized gains and $0.2 million of gross unrealized
   losses at June 30, 2011 were spread amongst more than 400 equity securities.

- changed (2011-08-02):
[0000950123-11-071519:note_history:18]
At June 30, 2011, we held a $48.3 million restricted certificate of deposit, which is carried at
   cost. This investment serves as a collateral deposit against the principal amount outstanding
   under loans made to ADTRAN pursuant to an Alabama State Industrial Development Authority revenue
   bond (the Bond). At June 30, 2011, the estimated fair value of the Bond was approximately $46.0
   million, based on a debt security with a comparable interest rate and maturity and a Standard and
   Poor’s credit rating of A+. We have the right to set-off the balance of the Bond with the
   collateral deposit in order to reduce the balance of the indebtedness. For more information on the
   Bond, see “Debt” under “Liquidity and Capital Resources” in the “Management’s Discussion and
   Analysis of Financial Condition and Results of Operations” contained in Item 2 of Part I of this
   report.
  (was, 2011-05-05, similarity 0.9894):
[0000950123-11-045439:note_history:18]
At March 31, 2011, we held a $48.3 million restricted certificate of deposit, which is carried at
   cost. This investment serves as a collateral deposit against the principal amount outstanding
   under loans made to ADTRAN pursuant to an Alabama State Industrial Development Authority revenue
   bond (the Bond). At March 31, 2011, the estimated fair value of the Bond was approximately $43.7
   million, based on a debt security with a comparable interest rate and maturity and a Standard and
   Poor’s credit rating of A+. We have the right to set-off the balance of the Bond with the
   collateral deposit in order to reduce the balance of the indebtedness. For more information on the
   Bond, see “Debt” under “Liquidity and Capital Resources” in the “Management’s Discussion and
   Analysis of Financial Condition and Results of Operations” contained in Item 2 of Part I of this
   report.

- changed (2011-08-02):
[0000950123-11-071519:note_history:19]
At June 30, 2011, we held $2.3 million of other investments carried at cost, consisting of
   interests in two private equity funds and an investment in a privately held telecommunications
   equipment manufacturer. The fair value of these investments was estimated to be approximately
   $10.5 million at June 30, 2011, based on unobservable inputs including information supplied by the
   company and the fund managers. We have committed to invest up to an aggregate of $7.9 million in
   the two private equity funds, and we have contributed $8.4 million as of June 30, 2011, of which
   $7.7 million has been applied toward these commitments. As of June 30, 2011, we have received
   distributions related to these two private equity funds of $7.9 million, of which $1.4 million was
   recorded as investment income. These investments are carried at cost, net of distributions, with
   distributions in excess of our investment recorded as investment income. The remaining commitment
   under the funds is $0.2 million, which expires in 2013. We have not been required to record any
   impairment losses related to these investments during the six months ended June 30, 2011.
  (was, 2011-05-05, similarity 0.9034):
[0000950123-11-045439:note_history:19]
At March 31, 2011, we held $2.1 million of other investments carried at cost, consisting of
   interests in two private equity funds and an investment in a privately held telecommunications
   equipment manufacturer. The fair value of these investments was estimated to be approximately
   $10.8 million at March 31, 2011, based on unobservable inputs including information supplied by the
   company and the fund managers. We have committed to invest up to an aggregate of $7.9 million in
   the two private equity funds, and we have contributed $8.0 million as of March 31, 2011, of which
   $7.4 million has been applied toward these commitments. As of March 31, 2011, we have received
   distributions related to these two private equity funds of $7.2 million, of which $0.9 million was
   recorded as investment income. These investments are
   carried at cost, net of distributions, with distributions in excess of our investment recorded as
   investment income. The duration of each of these commitments is ten years with $0.4 million
   expiring in 2013 and $0.1 million expiring in 2012. We have not been required to record any
   impairment losses related to these investments during the three months ended March 31, 2011.

- changed (2011-08-02):
[0000950123-11-071519:note_history:20]
We review our investment portfolio for potential “other-than-temporary” declines in value on an
   individual investment basis. We assess, on a quarterly basis, significant declines in value which
   may be considered other-than-temporary and, if necessary, recognize and record the appropriate
   charge to write-down the carrying value of such investments. In making this assessment, we take
   into consideration qualitative and quantitative information, including but not limited to the
   following: the magnitude and duration of historical declines in market prices, credit rating
   activity, assessments of liquidity, public filings, and statements made by the issuer. We
   generally begin our identification of potential other-than-temporary impairments by reviewing any
   security with a fair value that has declined from its original or adjusted cost basis by 25% or
   more for six or more consecutive months. We then evaluate the individual security based on the
   previously identified factors to determine the amount of the write-down, if any. As a result of
   our review, we recorded an other-than-temporary impairment charge of $12 thousand during the six
   months ended June 30, 2011 related to three marketable equity securities. For the six months ended
   June 30, 2010, we recorded an other-than-temporary impairment charge of $42 thousand related to
   three marketable equity securities.
  (was, 2011-05-05, similarity 0.9535):
[0000950123-11-045439:note_history:20]
We review our investment portfolio for potential “other-than-temporary” declines in value on an
   individual investment basis. We assess, on a quarterly basis, significant declines in value which
   may be considered other-than-temporary and, if necessary, recognize and record the appropriate
   charge to write-down the carrying value of such investments. In making this assessment, we take
   into consideration qualitative and quantitative information, including but not limited to the
   following: the magnitude and duration of historical declines in market prices, credit rating
   activity, assessments of liquidity, public filings, and statements made by the issuer. We
   generally begin our identification of potential other-than-temporary impairments by reviewing any
   security with a fair value that has declined from its original or adjusted cost basis by 25% or
   more for six or more consecutive months. We then evaluate the individual security based on the
   previously identified factors to determine the amount of the write-down, if any. As a result of
   our review, we recorded an other-than-temporary impairment charge of $4 thousand during the first
   quarter of 2011 related to one marketable equity security. For the three months ended March 31,
   2010, we recorded an other-than-temporary impairment charge of $2 thousand related to one
   marketable equity security.

- changed (2011-08-02):
[0000950123-11-071519:note_history:21]
|  |  | Fair Value Measurements at June 30, 2011 Using |  |
|  |  |  |  |  |  | Quoted Prices |  |  |  |  |  |  |  |
|  |  |  |  |  |  | in Active |  |  | Significant |  |  |  |  |
|  |  |  |  |  |  | Market for |  |  | Other |  |  | Significant |  |
|  |  |  |  |  |  | Identical |  |  | Observable |  |  | Unobservable |  |
|  |  |  |  |  |  | Assets |  |  | Inputs |  |  | Inputs |  |
| (In thousands) |  | Fair Value |  |  | (Level 1) |  |  | (Level 2) |  |  | (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 10,737 |  |  | $ | 10,737 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 6,789 |  |  |  | 6,789 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 200,889 |  |  |  | — |  |  |  | 200,889 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 117,854 |  |  |  | — |  |  |  | 117,854 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 94,870 |  |  |  | — |  |  |  | 94,870 |  |  |  | — |  |
| Fixed income bond fund |  |  | 751 |  |  |  | 751 |  |  |  | — |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity securities — technology industry |  |  | 25,591 |  |  |  | 25,591 |  |  |  | — |  |  |  | — |  |
| Equity securities — other |  |  | 13,832 |  |  |  | 13,832 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 460,576 |  |  |  | 46,963 |  |  |  | 413,613 |  |  |  | — |  |
| Total |  | $ | 471,313 |  |  | $ | 57,700 |  |  | $ | 413,613 |  |  | $ | — |  |
  (was, 2011-05-05, similarity 0.9968):
[0000950123-11-045439:note_history:21]
|  |  | Fair Value Measurements at March 31, 2011 Using |  |
|  |  |  |  |  |  | Quoted Prices |  |  |  |  |  |  |  |
|  |  |  |  |  |  | in Active |  |  | Significant |  |  |  |  |
|  |  |  |  |  |  | Market for |  |  | Other |  |  | Significant |  |
|  |  |  |  |  |  | Identical |  |  | Observable |  |  | Unobservable |  |
|  |  |  |  |  |  | Assets |  |  | Inputs |  |  | Inputs |  |
| (In thousands) |  | Fair Value |  |  | (Level 1) |  |  | (Level 2) |  |  | (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 14,276 |  |  | $ | 14,276 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 6,577 |  |  |  | 6,577 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 184,135 |  |  |  | — |  |  |  | 184,135 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 134,018 |  |  |  | — |  |  |  | 134,018 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 58,710 |  |  |  | — |  |  |  | 58,710 |  |  |  | — |  |
| Fixed income bond fund |  |  | 759 |  |  |  | 759 |  |  |  | — |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity securities — technology industry |  |  | 31,201 |  |  |  | 31,201 |  |  |  | — |  |  |  | — |  |
| Equity securities — other |  |  | 13,600 |  |  |  | 13,600 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 429,000 |  |  |  | 52,137 |  |  |  | 376,863 |  |  |  | — |  |
| Total |  | $ | 443,276 |  |  | $ | 66,413 |  |  | $ | 376,863 |  |  | $ | — |  |

- changed (2011-08-02):
[0000950123-11-071519:note_history:22]
As of June 30, 2011 and December 31, 2010, the fair value of the investments in available-for-sale
   Level 2 corporate bonds and municipal fixed-rate bonds was $318.7 million and $198.5 million,
   respectively. The fair value of these securities is calculated using a weighted average market
   price for each security. Market prices are obtained from a variety of industry standard data
   providers, security master files from large financial institutions, and other third-party sources.
   These multiple market prices are used as inputs into a distribution-curve-based algorithm to
   determine the daily market value of each security.
  (was, 2011-05-05, similarity 0.9926):
[0000950123-11-045439:note_history:22]
As of March 31, 2011 and December 31, 2010, the fair value of the investments in available-for-sale
   Level 2 corporate bonds and municipal fixed-rate bonds was $318.2 million and $198.5 million,
   respectively. The fair value of these securities is calculated using a weighted average market
   price for each security. Market prices are obtained from a variety of industry standard data
   providers, security master files from large financial institutions, and other third-party sources.
   These multiple market prices are used as inputs into a distribution-curve-based algorithm to
   determine the daily market value of each security.

- changed (2011-08-02):
[0000950123-11-071519:note_history:23]
As of June 30, 2011 and December 31, 2010, the fair value of the investments in available-for-sale
   Level 2 municipal variable rate demand notes was $94.9 million and $116.7 million, respectively.
   These securities have a structure that implies a standard expected market price. The frequent
   interest rate resets make it reasonable to expect the price to stay at par. These securities are
   priced at the expected market price.
  (was, 2011-05-05, similarity 0.9889):
[0000950123-11-045439:note_history:23]
As of March 31, 2011 and December 31, 2010, the fair value of the investments in available-for-sale
   Level 2 municipal variable rate demand notes was $58.7 million and $116.7 million, respectively.
   These securities have a structure that implies a standard expected market price. The frequent
   interest rate resets make it reasonable to expect the price to stay at par. These securities are
   priced at the expected market price.

- removed (2011-08-02):
[0000950123-11-045439:note_history:24]
At March 31, 2011, we held $184.1 million of corporate bonds. These bonds are classified as
   available-for-sale and had an average duration of 2.3 years at March 31, 2011. At March 31, 2011,
   approximately 1% of our corporate bond portfolio had a credit rating of AAA, 16% had a credit
   rating of AA, 52% had a credit rating of A, and 31% had a credit rating of BBB.

- removed (2011-08-02):
[0000950123-11-045439:note_history:25]
At March 31, 2011, we held $44.8 million of marketable equity securities, including a single
   security, of which we held 1.4 million shares, carried at a fair value of $29.8 million. We sold
   93 thousand shares of this security during the three months ended March 31, 2011. The sale of this
   security resulted in proceeds of $2.1 million and a realized gain of $2.0 million. This single
   security traded approximately 1.1 million shares per day in the first quarter of 2011 in an active
   market on a European stock exchange. This single security comprises $29.3 million of the gross
   unrealized gains included in the fair value of our marketable equity securities at March 31, 2011.
   The remaining $3.7 million of gross unrealized gains and $0.1 million of gross unrealized losses at
   March 31, 2011 were spread amongst more than 400 equity securities.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2011-08-02):
[0000950123-11-071519:note_history:26]
We employ the law firm of our director emeritus for legal services. All bills for services
   rendered by this firm are reviewed and approved by our Chief Financial Officer. We believe that
   the fees for such services are comparable to those charged by other firms for services rendered to
   us. For the three and six month periods ended June 30, 2011 and 2010, we incurred fees of $10
   thousand per month for these legal services.
  (was, 2011-05-05, similarity 0.9386):
[0000950123-11-045439:note_history:26]
We employ the law firm of our director emeritus for legal services. All bills for services
   rendered by this firm are reviewed and approved by our Chief Financial Officer. We believe that
   the fees for such services are comparable to those charged by other firms for services rendered to
   us. For the three months ended March 31, 2011 and 2010, we incurred fees of $10 thousand per month
   for these legal services.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: title_similarity, score: 1.0

- added (2011-08-02):
[0000950123-11-071519:note_history:27]
On July 12, 2011, we announced that our Board of Directors declared a quarterly cash dividend of
   $0.09 per common share to be paid to stockholders of record at the close of business on July 28,
   2011. The payment date will be August 11, 2011. The quarterly dividend payment will be
   approximately $5.8 million. In July 2003, our Board of Directors elected to begin declaring
   quarterly dividends on our common stock considering the tax treatment of dividends and adequate
   levels of Company liquidity.

- added (2011-08-02):
[0000950123-11-071519:note_history:28]
During the third quarter of 2011 and as of August 2, 2011, we repurchased 0.6 million shares of our
   common stock through open market purchases at an average cost of $34.25 per share. We have the
   authority to purchase an additional 1.4 million shares of our common stock under the plan approved
   by the Board of Directors on April 14, 2008.

- removed (2011-08-02):
[0000950123-11-045439:note_history:29]
On April 12, 2011, we announced that our Board of Directors declared a quarterly cash dividend of
   $0.09 per common share to be paid to stockholders of record at the close of business on April 28,
   2011. The payment date will be May 12, 2011. The quarterly dividend payment will be approximately
   $5.8 million. In July 2003, our Board of Directors elected to begin declaring quarterly dividends
   on our common stock considering the tax treatment of dividends and adequate levels of Company
   liquidity.
