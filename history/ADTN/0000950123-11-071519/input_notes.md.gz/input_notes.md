# ADTN notes — 0000950123-11-071519


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000950123-11-071519:notes:1]
[same as prior period, unchanged from 0000950123-11-045439:notes:1]

[0000950123-11-071519:notes:2]
[same as prior period, unchanged from 0000950123-11-045439:notes:2]

[0000950123-11-071519:notes:3]
[same as prior period, unchanged from 0000950123-11-045439:notes:3]

[0000950123-11-071519:notes:4]
[same as prior period, unchanged from 0000950123-11-045439:notes:4]

[0000950123-11-071519:notes:5]
[same as prior period, unchanged from 0000950123-11-045439:notes:5]

[0000950123-11-071519:notes:6]
The preparation of financial statements in conformity with accounting principles generally accepted
   in the United States of America requires management to make estimates and assumptions that affect
   the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities
   at the date of the financial statements, and the reported amounts of revenue and expense during the
   reporting period. Our more significant estimates include the allowance for doubtful accounts,
   obsolete and excess inventory reserves, warranty reserves, customer rebates, allowance for sales
   returns, estimated income tax contingencies, the fair value of stock-based compensation, and the
   evaluation of other-than-temporary declines in the value of investments. Actual amounts could
   differ significantly from these estimates.

[0000950123-11-071519:notes:7]
[same as prior period, unchanged from 0000950123-11-045439:notes:7]

[0000950123-11-071519:notes:8]
In June 2011, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update
   No. 2011-05, Presentation of Comprehensive Income (ASU 2011-05). ASU 2011-05 requires companies to
   present the components of net income and other comprehensive income either as one continuous
   statement or as two consecutive statements. ASU 2011-05 eliminates the option to present the
   components of other comprehensive income as part of the statement of changes in stockholders’
   equity. While ASU 2011-05 changes the presentation of comprehensive income, it does not change the
   components that are recognized in net income or comprehensive income under current accounting
   guidance. This update is effective for fiscal years, and interim periods within those years,
   ending after December 15, 2011, with early adoption permitted. Since ASU 2011-05 affects
   presentation only, it will have no effect on our consolidated results of operations or financial
   condition.

[0000950123-11-071519:notes:9]
In May 2011, the FASB issued Accounting Standards Update No. 2011-04, Amendments to Achieve Common
   Fair Value Measurement and Disclosure Requirements in U.S. GAAP and IFRSs(ASU 2011-04). ASU
   2011-04 is intended to improve the comparability of fair value measurements presented and disclosed
   in financial statements prepared in accordance with U.S. GAAP and IFRS. The amendments are of two
   types: (i) those that clarify the Board’s intent about the application of existing fair value
   measurement and disclosure requirements and (ii) those that change a particular principle or
   requirement for measuring fair value or for disclosing information about fair value measurements.
   This update is effective for annual periods beginning after December 15, 2011. We do not expect
   the adoption of this amendment will have a material impact on our consolidated results of
   operations or financial condition.

[0000950123-11-071519:notes:10]
During the six months ended June 30, 2011, we adopted the following accounting standards, which had no material effect on our
   consolidated results of operations or financial condition:

[0000950123-11-071519:notes:11]
In October 2009, the FASB issued Accounting Standards Update No. 2009-13, Multiple-Deliverable
   Revenue Arrangements (ASU 2009-13). ASU 2009-13 provides amendments to the criteria in Subtopic
   605-25 of the ASC for separating consideration in multiple-deliverable arrangements. As a result
   of those amendments, multiple-deliverable
   arrangements will be separated in more circumstances than under existing U.S. GAAP. ASU 2009-13
   establishes a selling price hierarchy for determining the selling price of a deliverable and will
   replace the term fair value in the revenue allocation guidance with selling price to clarify that
   the allocation of revenue is based on entity-specific assumptions rather than assumptions of a
   marketplace participant. ASU 2009 -13 will also eliminate the residual method of allocation and
   require that arrangement consideration be allocated at the inception of the arrangement to all
   deliverables using the relative selling price method and will require that a vendor determine its
   best estimate of selling price in a manner that is consistent with that used to determine the price
   to sell the deliverable on a standalone basis.

[0000950123-11-071519:notes:12]
[same as prior period, unchanged from 0000950123-11-045439:notes:10]

[0000950123-11-071519:notes:13]
We adopted this amendment during the first quarter of 2011. The adoption of this amendment had no
   effect on our consolidated results of operations and financial condition for the three or six
   months ended June 30, 2011.

[0000950123-11-071519:notes:14]
In October 2009, the FASB issued Accounting Standards Update No. 2009-14, Certain Revenue
   Arrangements that Include Software Arrangements. ASU 2009-14 changes the accounting model for
   revenue arrangements that include both tangible products and software elements. Tangible products
   containing software components and non-software components that function together to deliver the
   tangible product’s essential functionality are no longer within the scope of the software revenue
   guidance in Subtopic 985-605 of the ASC. In addition, ASU 2009-14 requires that hardware
   components of a tangible product containing software components always be excluded from the
   software revenue guidance. In that regard, ASU 2009-14 provides additional guidance on how to
   determine which software, if any, relating to the tangible product also would be excluded from the
   scope of the software revenue guidance. ASU 2009-14 also provides guidance on how a vendor should
   allocate arrangement consideration to deliverables in an arrangement that includes both tangible
   products and software. ASU 2009-14 also provides further guidance on how to allocate arrangement
   consideration when an arrangement includes deliverables both included and excluded from the scope
   of the software revenue guidance. We adopted this amendment during the first quarter of 2011. The
   adoption of this amendment had no effect on our consolidated results of operations and financial
   condition for the three or six months ended June 30, 2011.


## us-gaap:IncomeTaxDisclosureTextBlock

[0000950123-11-071519:notes:15]
[same as prior period, unchanged from 0000950123-11-045439:notes:13]

[0000950123-11-071519:notes:16]
Our effective tax rate decreased from 34.6% in the six months ended June 30, 2010 to 32.5% in the six months ended June 30, 2011. The decrease is primarily attributable to the research tax credit and increased tax benefits from a higher volume of stock option exercises during the six months ended June 30, 2011. The inclusion of the benefit for the research tax credit in the six months ended June 30,
   2011 resulted in a 2.2 percentage point decrease in our tax rate. In addition, increased benefits from a higher volume of stock
   option exercises during the six months ended June 30, 2011 resulted in a 1.6 percentage point decrease in
   our tax rate.

[0000950123-11-071519:notes:17]
The tax provision rate in 2010 was affected by a benefit related to the completion of an audit for the years 2006 and 2007
   by the Internal Revenue Service and a larger manufacturer's deduction. The completion of the audit provided a 1.0 percentage point
   benefit during the six months ended June 30, 2010. The higher manufacturer's deduction resulted in a 0.7 percentage point benefit in our effective tax rate for the six months ended June 30, 2010. Also, the tax provision rate in the first six months of 2010 did not include the benefit of the research tax credit,
   which expired on December 31, 2009. The credit was reinstated during the fourth quarter of 2010.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000950123-11-071519:notes:18]
[same as prior period, unchanged from 0000950123-11-045439:notes:15]

[0000950123-11-071519:notes:19]
The following table summarizes the stock-based compensation expense related to stock options,
   restricted stock units (RSUs) and restricted stock under the Stock Compensation Topic of the FASB
   Accounting Standards Codification (ASC) for the three and six months ended June 30, 2011 and 2010,
   which was recognized as follows:

[0000950123-11-071519:notes:20]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
| Stock-based compensation expense included in cost of sales |  | $ | 89 |  |  | $ | 73 |  |  | $ | 180 |  |  | $ | 141 |  |
| Selling, general and administrative expense |  |  | 999 |  |  |  | 835 |  |  |  | 2,006 |  |  |  | 1,585 |  |
| Research and development expense |  |  | 988 |  |  |  | 900 |  |  |  | 1,979 |  |  |  | 1,771 |  |
| Stock-based compensation expense included in operating expenses |  |  | 1,987 |  |  |  | 1,735 |  |  |  | 3,985 |  |  |  | 3,356 |  |
| Total stock-based compensation expense |  |  | 2,076 |  |  |  | 1,808 |  |  |  | 4,165 |  |  |  | 3,497 |  |
| Tax benefit for expense associated with non-qualified options |  |  | (276 | ) |  |  | (195 | ) |  |  | (716 | ) |  |  | (372 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 1,800 |  |  | $ | 1,613 |  |  | $ | 3,449 |  |  | $ | 3,125 |  |

[0000950123-11-071519:notes:21]
[same as prior period, unchanged from 0000950123-11-045439:notes:18]

[0000950123-11-071519:notes:22]
The weighted-average assumptions and value of options granted for the three and six months ended
   June 30, 2011 and 2010 are summarized as follows:

[0000950123-11-071519:notes:23]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
|  |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
| Expected volatility |  |  | 37.68 | % |  |  | 39.94 | % |  |  | 37.68 | % |  |  | 41.00 | % |
| Risk-free interest rate |  |  | 2.18 | % |  |  | 2.45 | % |  |  | 2.18 | % |  |  | 2.50 | % |
| Expected dividend yield |  |  | 0.86 | % |  |  | 1.31 | % |  |  | 0.86 | % |  |  | 1.53 | % |
| Expected life (in years) |  |  | 4.94 |  |  |  | 5.04 |  |  |  | 4.94 |  |  |  | 5.18 |  |
| Weighted-average estimated value |  | $ | 13.93 |  |  | $ | 9.39 |  |  | $ | 13.93 |  |  | $ | 8.19 |  |

[0000950123-11-071519:notes:24]
The fair value of our RSUs is calculated using a Monte Carlo Simulation valuation method. There
   were no RSU grants during the six months ended June 30, 2011 or 2010.

[0000950123-11-071519:notes:25]
The fair value of restricted stock is equal to the closing price of our stock on the date of grant.
   There were no restricted stock grants during the six months ended June 30, 2011 or 2010.

[0000950123-11-071519:notes:26]
Stock-based compensation expense recognized in our Consolidated Statements of Income for the three
   and six months ended June 30, 2011 and 2010 is based on options, RSUs and restricted stock
   ultimately expected to vest, and has been reduced for estimated forfeitures. Estimated forfeitures
   for stock options were based upon historical experience and approximate 2% annually. We estimated
   a 0% forfeiture rate for our RSUs and restricted stock due to the limited number of recipients and
   historical experience for these awards.

[0000950123-11-071519:notes:27]
As of June 30, 2011, total compensation expense related to non-vested stock options, RSUs and
   restricted stock not yet recognized was approximately $16.0 million, which is expected to be
   recognized over an average remaining recognition period of 2.7 years.

[0000950123-11-071519:notes:28]
The following table is a summary of our stock options outstanding as of December 31, 2010 and June
   30, 2011 and the changes that occurred during the six months ended June 30, 2011:

[0000950123-11-071519:notes:29]
|  |  |  |  |  |  |  |  |  |  | Weighted Avg. |  |  |  |  |
|  |  |  |  |  |  |  |  |  |  | Remaining |  |  | Aggregate |  |
|  |  | Number of |  |  | Weighted Avg. |  |  | Contractual |  |  | Intrinsic |  |
| (In thousands, except per share amounts) |  | Options |  |  | Exercise Price |  |  | Life In Years |  |  | Value |  |
| Options outstanding, December 31, 2010 |  |  | 6,234 |  |  | $ | 23.09 |  |  |  | 6.21 |  |  | $ | 81,561 |  |
| Options granted |  |  | 5 |  |  | $ | 41.92 |  |  |  |  |  |  |  |  |  |
| Options cancelled/forfeited |  |  | (40 | ) |  | $ | 25.15 |  |  |  |  |  |  |  |  |  |
| Options exercised |  |  | (1,719 | ) |  | $ | 19.39 |  |  |  |  |  |  |  |  |  |
| Options outstanding, June 30, 2011 |  |  | 4,480 |  |  | $ | 24.51 |  |  |  | 6.59 |  |  | $ | 63,635 |  |
| Options exercisable, June 30, 2011 |  |  | 2,256 |  |  | $ | 23.22 |  |  |  | 4.85 |  |  | $ | 34,947 |  |

[0000950123-11-071519:notes:30]
The aggregate intrinsic values in the table above represent the total pre-tax intrinsic value (the
   difference between ADTRAN’s closing stock price on the last trading day of the quarter and the
   exercise price, multiplied by the number of in-the-money options) that would have been received by
   the option holders had all option holders exercised their options on June 30, 2011. The aggregate
   intrinsic value will change based on the fair market value of ADTRAN’s stock.

[0000950123-11-071519:notes:31]
The total pre-tax intrinsic value of options exercised during the three and six month periods ended
   June 30, 2011 was $1.5 million and $38.9 million, respectively.

[0000950123-11-071519:notes:32]
The following table is a summary of our RSUs and restricted stock outstanding as of December 31,
   2010 and June 30, 2011 and the changes that occurred during the six months ended June 30, 2011:

[0000950123-11-071519:notes:33]
|  |  |  |  |  |  | Weighted |  |
|  |  |  |  |  |  | Average |  |
|  |  | Number of |  |  | Grant Date |  |
| (In thousands, except per share amounts) |  | Shares |  |  | Fair Value |  |
| RSUs and restricted stock outstanding, December 31, 2010 |  |  | 87 |  |  | $ | 28.46 |  |
| RSUs and restricted stock granted |  |  | — |  |  | $ | — |  |
| RSUs and restricted stock vested |  |  | — |  |  | $ | — |  |
| RSUs and restricted stock cancelled/forfeited |  |  | — |  |  | $ | — |  |
| Unvested RSUs and restricted stock, June 30, 2011 |  |  | 87 |  |  | $ | 28.46 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000950123-11-071519:notes:34]
4. INVESTMENTS

[0000950123-11-071519:notes:35]
At June 30, 2011, we held the following securities and investments, recorded at either fair
   value or cost.

[0000950123-11-071519:notes:36]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Carrying |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Deferred compensation plan assets |  | $ | 6,438 |  |  | $ | 351 |  |  | $ | — |  |  | $ | 6,789 |  |
| Corporate bonds |  |  | 200,280 |  |  |  | 971 |  |  |  | (362 | ) |  |  | 200,889 |  |
| Municipal fixed-rate bonds |  |  | 117,262 |  |  |  | 597 |  |  |  | (5 | ) |  |  | 117,854 |  |
| Municipal variable rate demand notes |  |  | 94,870 |  |  |  | — |  |  |  | — |  |  |  | 94,870 |  |
| Fixed income bond fund |  |  | 526 |  |  |  | 225 |  |  |  | — |  |  |  | 751 |  |
| Marketable equity securities |  |  | 12,119 |  |  |  | 27,516 |  |  |  | (212 | ) |  |  | 39,423 |  |
| Available-for-sale securities held at fair value |  | $ | 431,495 |  |  | $ | 29,660 |  |  | $ | (579 | ) |  | $ | 460,576 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 48,250 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 2,296 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 511,122 |  |

[0000950123-11-071519:notes:37]
At December 31, 2010, we held the following securities and investments, recorded at either fair
   value or cost.

[0000950123-11-071519:notes:38]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Carrying |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Deferred compensation plan assets |  | $ | 3,483 |  |  | $ | 770 |  |  | $ | (7 | ) |  | $ | 4,246 |  |
| Corporate bonds |  |  | 126,671 |  |  |  | 630 |  |  |  | (229 | ) |  |  | 127,072 |  |
| Municipal fixed-rate bonds |  |  | 71,212 |  |  |  | 268 |  |  |  | (13 | ) |  |  | 71,467 |  |
| Municipal variable rate demand notes |  |  | 116,745 |  |  |  | — |  |  |  | — |  |  |  | 116,745 |  |
| Fixed income bond fund |  |  | 526 |  |  |  | 220 |  |  |  | — |  |  |  | 746 |  |
| Marketable equity securities |  |  | 11,486 |  |  |  | 36,657 |  |  |  | (133 | ) |  |  | 48,010 |  |
| Available-for-sale securities held at fair value |  | $ | 330,123 |  |  | $ | 38,545 |  |  | $ | (382 | ) |  | $ | 368,286 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 48,250 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 2,103 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 418,639 |  |

[0000950123-11-071519:notes:39]
At June 30, 2011, we held $6.8 million of deferred compensation plan assets, carried at fair value.

[0000950123-11-071519:notes:40]
At June 30, 2011, we held $200.9 million of corporate bonds. These bonds are classified as
   available-for-sale and had an average duration of 2.2 years at June 30, 2011. At June 30, 2011,
   approximately 1% of our corporate bond portfolio had a credit rating of AAA, 14% had a credit
   rating of AA, 55% had a credit rating of A, and 30% had a credit rating of BBB. Because our bond
   portfolio has a high quality rating and contractual maturities of a short duration, we are able to
   obtain prices for these bonds derived from observable market inputs, or for similar securities
   traded in an active market, on a daily basis.

[0000950123-11-071519:notes:41]
At June 30, 2011, we held $117.9 million of municipal fixed-rate bonds. These bonds are classified
   as available-for-sale and had an average duration of 1.3 years at June 30, 2011. At June 30, 2011,
   approximately 24% of our municipal fixed-rate bond portfolio had a credit rating of AAA, 58% had a
   credit rating of AA, and 18% had a credit rating of A. Because
   our bond portfolio has a high quality rating and contractual maturities of a short duration, we are
   able to obtain prices for these bonds derived from observable market inputs, or for similar
   securities traded in an active market, on a daily basis.

[0000950123-11-071519:notes:42]
At June 30, 2011, we held $94.9 million of municipal variable rate demand notes, all of which were
   classified as available-for-sale. At June 30, 2011, 27% of our municipal variable rate demand
   notes had a credit rating of AAA, 63% had a credit rating of AA, 10% had a credit rating of A, and
   all contained put options of seven days. Despite the long-term nature of their stated contractual
   maturities, we routinely buy and sell these securities and we believe that we have the ability to
   quickly liquidate them. Our investments in these securities are recorded at fair value, and the
   interest rates reset every seven days. We believe we have the ability to sell our variable rate
   demand notes to the remarketing agent, tender agent or issuer at par value plus accrued interest in
   the event we decide to liquidate our investment in a particular variable rate demand note. At June
   30, 2011, approximately 24% of our variable rate demand notes were supported by letters of credit
   from banks that we believe to be in good financial condition. The remaining 76% of our variable
   rate demand notes were supported by standby purchase agreements. As a result of these factors, we
   had no cumulative gross unrealized holding gains (losses) or gross realized gains (losses) from
   these investments. All income generated from these investments was recorded as interest income.
   We have not recorded any losses relating to municipal variable rate demand notes.

[0000950123-11-071519:notes:43]
At June 30, 2011, we held $0.8 million of a fixed income bond fund.

[0000950123-11-071519:notes:44]
At June 30, 2011, we held $39.4 million of marketable equity securities, including a single
   security, of which we held 1.3 million shares, carried at a fair value of $24.3 million. We sold
   0.2 million shares of this security during the six months ended June 30, 2011. The sale of this
   security resulted in proceeds of $4.2 million and a realized gain of $4.1 million. This single
   security traded approximately 0.9 million shares per day in the first six months of 2011 in an
   active market on a European stock exchange. This single security comprises $23.8 million of the
   gross unrealized gains included in the fair value of our marketable equity securities at June 30,
   2011. The remaining $3.7 million of gross unrealized gains and $0.2 million of gross unrealized
   losses at June 30, 2011 were spread amongst more than 400 equity securities.

[0000950123-11-071519:notes:45]
At June 30, 2011, we held a $48.3 million restricted certificate of deposit, which is carried at
   cost. This investment serves as a collateral deposit against the principal amount outstanding
   under loans made to ADTRAN pursuant to an Alabama State Industrial Development Authority revenue
   bond (the Bond). At June 30, 2011, the estimated fair value of the Bond was approximately $46.0
   million, based on a debt security with a comparable interest rate and maturity and a Standard and
   Poor’s credit rating of A+. We have the right to set-off the balance of the Bond with the
   collateral deposit in order to reduce the balance of the indebtedness. For more information on the
   Bond, see “Debt” under “Liquidity and Capital Resources” in the “Management’s Discussion and
   Analysis of Financial Condition and Results of Operations” contained in Item 2 of Part I of this
   report.

[0000950123-11-071519:notes:46]
At June 30, 2011, we held $2.3 million of other investments carried at cost, consisting of
   interests in two private equity funds and an investment in a privately held telecommunications
   equipment manufacturer. The fair value of these investments was estimated to be approximately
   $10.5 million at June 30, 2011, based on unobservable inputs including information supplied by the
   company and the fund managers. We have committed to invest up to an aggregate of $7.9 million in
   the two private equity funds, and we have contributed $8.4 million as of June 30, 2011, of which
   $7.7 million has been applied toward these commitments. As of June 30, 2011, we have received
   distributions related to these two private equity funds of $7.9 million, of which $1.4 million was
   recorded as investment income. These investments are carried at cost, net of distributions, with
   distributions in excess of our investment recorded as investment income. The remaining commitment
   under the funds is $0.2 million, which expires in 2013. We have not been required to record any
   impairment losses related to these investments during the six months ended June 30, 2011.

[0000950123-11-071519:notes:47]
We review our investment portfolio for potential “other-than-temporary” declines in value on an
   individual investment basis. We assess, on a quarterly basis, significant declines in value which
   may be considered other-than-temporary and, if necessary, recognize and record the appropriate
   charge to write-down the carrying value of such investments. In making this assessment, we take
   into consideration qualitative and quantitative information, including but not limited to the
   following: the magnitude and duration of historical declines in market prices, credit rating
   activity, assessments of liquidity, public filings, and statements made by the issuer. We
   generally begin our identification of potential other-than-temporary impairments by reviewing any
   security with a fair value that has declined from its original or adjusted cost basis by 25% or
   more for six or more consecutive months. We then evaluate the individual security based on the
   previously identified factors to determine the amount of the write-down, if any. As a result of
   our review, we recorded an other-than-temporary impairment charge of $12 thousand during the six
   months ended June 30, 2011 related to three marketable equity securities. For the six months ended
   June 30, 2010, we recorded an other-than-temporary impairment charge of $42 thousand related to
   three marketable equity securities.

[0000950123-11-071519:notes:48]
In accordance with the Fair Value Measurements and Disclosures Topic of the FASB ASC, we have
   categorized our cash equivalents held in money market funds and our investments held at fair value
   into a three-level fair value hierarchy based on the priority of the inputs to the valuation
   technique for the cash equivalents and investments as follows: Level 1 — Values based on
   unadjusted quoted prices for identical assets or liabilities in an active market; Level 2 — Values
   based on quoted prices in markets that are not active or model inputs that are observable either
   directly or indirectly; Level 3 — Values based on prices or valuation techniques that require
   inputs that are both unobservable and significant to the overall fair value measurement. These
   inputs include information supplied by investees.

[0000950123-11-071519:notes:49]
|  |  | Fair Value Measurements at June 30, 2011 Using |  |
|  |  |  |  |  |  | Quoted Prices |  |  |  |  |  |  |  |
|  |  |  |  |  |  | in Active |  |  | Significant |  |  |  |  |
|  |  |  |  |  |  | Market for |  |  | Other |  |  | Significant |  |
|  |  |  |  |  |  | Identical |  |  | Observable |  |  | Unobservable |  |
|  |  |  |  |  |  | Assets |  |  | Inputs |  |  | Inputs |  |
| (In thousands) |  | Fair Value |  |  | (Level 1) |  |  | (Level 2) |  |  | (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 10,737 |  |  | $ | 10,737 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 6,789 |  |  |  | 6,789 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 200,889 |  |  |  | — |  |  |  | 200,889 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 117,854 |  |  |  | — |  |  |  | 117,854 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 94,870 |  |  |  | — |  |  |  | 94,870 |  |  |  | — |  |
| Fixed income bond fund |  |  | 751 |  |  |  | 751 |  |  |  | — |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity securities — technology industry |  |  | 25,591 |  |  |  | 25,591 |  |  |  | — |  |  |  | — |  |
| Equity securities — other |  |  | 13,832 |  |  |  | 13,832 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 460,576 |  |  |  | 46,963 |  |  |  | 413,613 |  |  |  | — |  |
| Total |  | $ | 471,313 |  |  | $ | 57,700 |  |  | $ | 413,613 |  |  | $ | — |  |

[0000950123-11-071519:notes:50]
|  |  | Fair Value Measurements at December 31, 2010 Using |  |
|  |  |  |  |  |  | Quoted Prices |  |  |  |  |  |  |  |
|  |  |  |  |  |  | in Active |  |  | Significant |  |  |  |  |
|  |  |  |  |  |  | Market for |  |  | Other |  |  | Significant |  |
|  |  |  |  |  |  | Identical |  |  | Observable |  |  | Unobservable |  |
|  |  |  |  |  |  | Assets |  |  | Inputs |  |  | Inputs |  |
| (In thousands) |  | Fair Value |  |  | (Level 1) |  |  | (Level 2) |  |  | (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 14,532 |  |  | $ | 14,532 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 4,246 |  |  |  | 4,246 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 127,072 |  |  |  | — |  |  |  | 127,072 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 71,467 |  |  |  | — |  |  |  | 71,467 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 116,745 |  |  |  | — |  |  |  | 116,745 |  |  |  | — |  |
| Fixed income bond fund |  |  | 746 |  |  |  | 746 |  |  |  | — |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity securities — technology industry |  |  | 35,596 |  |  |  | 35,596 |  |  |  | — |  |  |  | — |  |
| Equity securities — other |  |  | 12,414 |  |  |  | 12,414 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 368,286 |  |  |  | 53,002 |  |  |  | 315,284 |  |  |  | — |  |
| Total |  | $ | 382,818 |  |  | $ | 67,534 |  |  | $ | 315,284 |  |  | $ | — |  |

[0000950123-11-071519:notes:51]
As of June 30, 2011 and December 31, 2010, the fair value of the investments in available-for-sale
   Level 2 corporate bonds and municipal fixed-rate bonds was $318.7 million and $198.5 million,
   respectively. The fair value of these securities is calculated using a weighted average market
   price for each security. Market prices are obtained from a variety of industry standard data
   providers, security master files from large financial institutions, and other third-party sources.
   These multiple market prices are used as inputs into a distribution-curve-based algorithm to
   determine the daily market value of each security.

[0000950123-11-071519:notes:52]
As of June 30, 2011 and December 31, 2010, the fair value of the investments in available-for-sale
   Level 2 municipal variable rate demand notes was $94.9 million and $116.7 million, respectively.
   These securities have a structure that implies a standard expected market price. The frequent
   interest rate resets make it reasonable to expect the price to stay at par. These securities are
   priced at the expected market price.


## us-gaap:InventoryDisclosureTextBlock

[0000950123-11-071519:notes:53]
[same as prior period, unchanged from 0000950123-11-045439:notes:50]

[0000950123-11-071519:notes:54]
At June 30, 2011 and December 31, 2010, inventory consisted of the following:

[0000950123-11-071519:notes:55]
|  |  | June 30, |  |  | December 31, |  |
| (In thousands) |  | 2011 |  |  | 2010 |  |
| Raw materials |  | $ | 44,177 |  |  | $ | 43,897 |  |
| Work in process |  |  | 6,327 |  |  |  | 2,871 |  |
| Finished goods |  |  | 36,172 |  |  |  | 27,506 |  |
| Total |  | $ | 86,676 |  |  | $ | 74,274 |  |

[0000950123-11-071519:notes:56]
We establish reserves for estimated excess, obsolete, or unmarketable inventory equal to the
   difference between the cost of the inventory and the estimated fair value of the inventory based
   upon assumptions about future demand and market conditions. At June 30, 2011 and December 31,
   2010, raw materials reserves totaled $7.8 million and $7.3 million, respectively, and finished
   goods inventory reserves totaled $2.0 million and $1.6 million, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000950123-11-071519:notes:57]
[same as prior period, unchanged from 0000950123-11-045439:notes:54]

[0000950123-11-071519:notes:58]
A summary of the changes in stockholders’ equity for the six months ended June 30, 2011 is as
   follows:

[0000950123-11-071519:notes:59]
|  |  | Stockholders’ |  |
| (In thousands) |  | Equity |  |
| Balance, December 31, 2010 |  | $ | 572,322 |  |
| Net income |  |  | 71,201 |  |
| Dividend payments |  |  | (11,596 | ) |
| Dividends accrued for unvested restricted stock units |  |  | (19 | ) |
| Net change in unrealized gains and losses on marketable securities (net of deferred taxes) |  |  | (5,791 | ) |
| Reclassification adjustment for amounts included in net income (net of deferred taxes) |  |  | (395 | ) |
| Foreign currency translation adjustment |  |  | 456 |  |
| Proceeds from stock option exercises |  |  | 33,022 |  |
| Tax benefits from stock option exercises |  |  | 10,318 |  |
| Stock-based compensation expense |  |  | 4,165 |  |
| Balance, June 30, 2011 |  | $ | 673,683 |  |

[0000950123-11-071519:notes:60]
[same as prior period, unchanged from 0000950123-11-045439:notes:57]

[0000950123-11-071519:notes:61]
Since 1997, our Board of Directors has approved multiple share repurchase programs that have
   authorized open market repurchase transactions of up to 30 million shares of our common stock.
   During the six months ended June 30, 2011, we did not repurchase any shares of our common stock.
   We have the authority to purchase an additional 2.0 million shares of our common stock under the
   plan approved by the Board of Directors on April 14, 2008.

[0000950123-11-071519:notes:62]
[same as prior period, unchanged from 0000950123-11-045439:notes:59]

[0000950123-11-071519:notes:63]
We issued 1.7 million shares of treasury stock during the six months ended June 30, 2011 to
   accommodate employee stock option exercises. The stock options had exercise prices ranging from
   $10.50 to $36.64. We received proceeds totaling $33.0 million from the exercise of these stock
   options during the six months ended June 30, 2011.

[0000950123-11-071519:notes:64]
[same as prior period, unchanged from 0000950123-11-045439:notes:61]

[0000950123-11-071519:notes:65]
During the six months ended June 30, 2011, we paid cash dividends as follows (in thousands except
   per share amount):

[0000950123-11-071519:notes:66]
| Record Date |  | Payment Date |  | Per Share Amount |  |  | Total Dividend Paid |  |
| February 3, 2011 |  | February 17, 2011 |  | $ | 0.09 |  |  | $ | 5,775 |  |
| April 28, 2011 |  | May 12, 2011 |  | $ | 0.09 |  |  | $ | 5,821 |  |

[0000950123-11-071519:notes:67]
[same as prior period, unchanged from 0000950123-11-045439:notes:64]

[0000950123-11-071519:notes:68]
[same as prior period, unchanged from 0000950123-11-045439:notes:65]

[0000950123-11-071519:notes:69]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
| Net income |  | $ | 36,943 |  |  | $ | 27,751 |  |  | $ | 71,201 |  |  | $ | 45,945 |  |
| Net change in unrealized gains and losses related to marketable securities, net of deferred tax benefit of $2,029 and $3,404 for the three months ended June 30, 2011 and 2010, respectively, and $2,702 and $631 for the six months ended June 30, 2011 and 2010, respectively |  |  | (3,140 | ) |  |  | (5,678 | ) |  |  | (5,791 | ) |  |  | (1,056 | ) |
| Reclassification adjustment for amounts included in net income, net of deferred tax benefit of $146 and $96 for the three months ended June 30, 2011 and 2010, respectively, and $186 and $127 for the six months ended June 30, 2011 and 2010, respectively |  |  | (236 | ) |  |  | (160 | ) |  |  | (395 | ) |  |  | (212 | ) |
| Foreign currency translation adjustment |  |  | 369 |  |  |  | (770 | ) |  |  | 456 |  |  |  | (602 | ) |
| Total comprehensive income |  | $ | 33,936 |  |  | $ | 21,143 |  |  | $ | 65,471 |  |  | $ | 44,075 |  |


## us-gaap:EarningsPerShareTextBlock

[0000950123-11-071519:notes:70]
[same as prior period, unchanged from 0000950123-11-045439:notes:67]

[0000950123-11-071519:notes:71]
A summary of the calculation of basic and diluted earnings per share for the three and six months
   ended June 30, 2011 and 2010 is as follows:

[0000950123-11-071519:notes:72]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands, except per share amounts) |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
| Numerator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 36,943 |  |  | $ | 27,751 |  |  | $ | 71,201 |  |  | $ | 45,945 |  |
| Denominator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average number of shares — basic |  |  | 64,690 |  |  |  | 62,172 |  |  |  | 64,441 |  |  |  | 62,086 |  |
| Effect of dilutive securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock options |  |  | 1,387 |  |  |  | 1,281 |  |  |  | 1,547 |  |  |  | 1,169 |  |
| Restricted stock and restricted stock units |  |  | 58 |  |  |  | 35 |  |  |  | 56 |  |  |  | 26 |  |
| Weighted average number of shares — diluted |  |  | 66,135 |  |  |  | 63,488 |  |  |  | 66,044 |  |  |  | 63,281 |  |
| Net income per share — basic |  | $ | 0.57 |  |  | $ | 0.45 |  |  | $ | 1.10 |  |  | $ | 0.74 |  |
| Net income per share — diluted |  | $ | 0.56 |  |  | $ | 0.44 |  |  | $ | 1.08 |  |  | $ | 0.73 |  |

[0000950123-11-071519:notes:73]
Anti-dilutive options to purchase common stock outstanding were excluded from the above
   calculations. Anti-dilutive options totaled 0.9 million and 2.1 million for the three months ended
   June 30, 2011 and 2010, respectively, and 0.9 million and 2.8 million for the six months ended June
   30, 2011 and 2010, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000950123-11-071519:notes:74]
[same as prior period, unchanged from 0000950123-11-045439:notes:71]

[0000950123-11-071519:notes:75]
[same as prior period, unchanged from 0000950123-11-045439:notes:72]

[0000950123-11-071519:notes:76]
The following table presents information about the reported sales and gross profit of our
   reportable segments for the three and six months ended June 30, 2011 and 2010. Asset information
   by reportable segment is not reported, since we do not produce such information internally.

[0000950123-11-071519:notes:77]
|  |  | Three Months Ended |  |
|  |  | June 30, 2011 |  |  | June 30, 2010 |  |
| (In thousands) |  | Sales |  |  | Gross Profit |  |  | Sales |  |  | Gross Profit |  |
| Carrier Networks |  | $ | 150,492 |  |  | $ | 87,465 |  |  | $ | 117,579 |  |  | $ | 70,273 |  |
| Enterprise Networks |  |  | 33,735 |  |  |  | 19,362 |  |  |  | 32,782 |  |  |  | 19,056 |  |
| Total |  | $ | 184,227 |  |  | $ | 106,827 |  |  | $ | 150,361 |  |  | $ | 89,329 |  |

[0000950123-11-071519:notes:78]
|  |  | Six Months Ended |  |
|  |  | June 30, 2011 |  |  | June 30, 2010 |  |
| (In thousands) |  | Sales |  |  | Gross Profit |  |  | Sales |  |  | Gross Profit |  |
| Carrier Networks |  | $ | 282,852 |  |  | $ | 166,963 |  |  | $ | 217,103 |  |  | $ | 129,539 |  |
| Enterprise Networks |  |  | 66,897 |  |  |  | 38,659 |  |  |  | 60,285 |  |  |  | 35,118 |  |
| Total |  | $ | 349,749 |  |  | $ | 205,622 |  |  | $ | 277,388 |  |  | $ | 164,657 |  |

[0000950123-11-071519:notes:79]
[same as prior period, unchanged from 0000950123-11-045439:notes:75]

[0000950123-11-071519:notes:80]
[same as prior period, unchanged from 0000950123-11-045439:notes:76]

[0000950123-11-071519:notes:81]
Carrier Systems products are used by communications service providers to provide data, voice and
   video services to consumers and enterprises. The Carrier Systems category includes our broadband
   access products comprised of Total Access® 5000 multi-service access and aggregation platform
   products, Total Access 1100/1200 Series Fiber-To-The-Node (FTTN) products, and Digital Subscriber
   Line Access Multiplexer (DSLAM) products. Our broadband access products are used by service
   providers to deliver high-speed Internet access, Voice over Internet Protocol (VoIP), IP Television
   (IPTV), and/or Ethernet services from the central office or remote terminal locations to customer
   premises. The Carrier Systems category also includes our optical access products. These products
   consist of optical access multiplexers including our family of OPTI products and our Optical
   Networking Edge (ONE) products. Optical access
   products are used to deliver higher bandwidth services, or to aggregate large numbers of low
   bandwidth services for transportation across fiber optic infrastructure. Total Access 1500
   products, 303 concentrator products, M13 multiplexer products, and a number of mobile backhaul
   products are also included in the Carrier Systems product category.

[0000950123-11-071519:notes:82]
[same as prior period, unchanged from 0000950123-11-045439:notes:78]

[0000950123-11-071519:notes:83]
[same as prior period, unchanged from 0000950123-11-045439:notes:79]

[0000950123-11-071519:notes:84]
The table below presents sales information by product category for the three and six months ended
   June 30, 2011 and 2010.

[0000950123-11-071519:notes:85]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
| Carrier Systems |  | $ | 112,289 |  |  | $ | 73,148 |  |  | $ | 199,039 |  |  | $ | 131,241 |  |
| Business Networking |  |  | 35,699 |  |  |  | 32,165 |  |  |  | 72,062 |  |  |  | 58,622 |  |
| Loop Access |  |  | 36,239 |  |  |  | 45,048 |  |  |  | 78,648 |  |  |  | 87,525 |  |
| Total |  | $ | 184,227 |  |  | $ | 150,361 |  |  | $ | 349,749 |  |  | $ | 277,388 |  |

[0000950123-11-071519:notes:86]
In addition, we identify subcategories of product revenues, which we divide into growth products,
   representing our primary growth areas, and traditional products. Our growth products consist of
   Broadband Access and Optical Access products (included in Carrier Systems) and Internetworking
   products (included in Business Networking) and our traditional products include HDSL products
   (included in Loop Access) and other products not included in the aforementioned growth products.

[0000950123-11-071519:notes:87]
[same as prior period, unchanged from 0000950123-11-045439:notes:83]

[0000950123-11-071519:notes:88]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
| Growth Products |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Broadband Access (included in Carrier Systems) |  | $ | 77,062 |  |  | $ | 44,971 |  |  | $ | 128,844 |  |  | $ | 81,333 |  |
| Optical Access (included in Carrier Systems) |  |  | 22,008 |  |  |  | 16,128 |  |  |  | 42,924 |  |  |  | 27,387 |  |
| Internetworking (NetVanta & Multi-service Access Gateways) (included in Business Networking) |  |  | 33,029 |  |  |  | 27,902 |  |  |  | 65,912 |  |  |  | 50,085 |  |
| Total |  |  | 132,099 |  |  |  | 89,001 |  |  |  | 237,680 |  |  |  | 158,805 |  |
| Traditional Products |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| HDSL (does not include T1) (included in Loop Access) |  |  | 34,049 |  |  |  | 42,174 |  |  |  | 74,994 |  |  |  | 82,104 |  |
| Other products (excluding HDSL) |  |  | 18,079 |  |  |  | 19,186 |  |  |  | 37,075 |  |  |  | 36,479 |  |
| Total |  |  | 52,128 |  |  |  | 61,360 |  |  |  | 112,069 |  |  |  | 118,583 |  |
| Total |  | $ | 184,227 |  |  | $ | 150,361 |  |  | $ | 349,749 |  |  | $ | 277,388 |  |

[0000950123-11-071519:notes:89]
[same as prior period, unchanged from 0000950123-11-045439:notes:85]

[0000950123-11-071519:notes:90]
The table below presents sales information by geographic area for the three and six months ended
   June 30, 2011 and 2010. International sales correlate to shipments with a non-U.S. destination.

[0000950123-11-071519:notes:91]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2011 |  |  | 2010 |  |  | 2011 |  |  | 2010 |  |
| United States |  | $ | 160,804 |  |  | $ | 142,046 |  |  | $ | 313,917 |  |  | $ | 262,346 |  |
| International |  |  | 23,423 |  |  |  | 8,315 |  |  |  | 35,832 |  |  |  | 15,042 |  |
| Total |  | $ | 184,227 |  |  | $ | 150,361 |  |  | $ | 349,749 |  |  | $ | 277,388 |  |


## us-gaap:ProductWarrantyDisclosureTextBlock

[0000950123-11-071519:notes:92]
[same as prior period, unchanged from 0000950123-11-045439:notes:88]

[0000950123-11-071519:notes:93]
Our products generally include warranties of one to ten years for product defects. We accrue for
   warranty returns at the time revenue is recognized based on our estimate of the cost to repair or
   replace the defective products. We engage in extensive product quality programs and processes,
   including actively monitoring and evaluating the quality of our
   component suppliers. Our products continue to become more complex in both size and functionality
   as many of our product offerings migrate from line card applications to systems products. The
   increasing complexity of our products will cause warranty incidences, when they arise, to be more
   costly. Our estimates regarding future warranty obligations may change due to product failure
   rates, material usage, and other rework costs incurred in correcting a product failure. In
   addition, from time to time, specific warranty accruals may be recorded if unforeseen problems
   arise. Should our actual experience relative to these factors be worse than our estimates, we will
   be required to record additional warranty expense. Alternatively, if we provide for more reserves
   than we require, we will reverse a portion of such provisions in future periods. The liability for
   warranty obligations totaled $3.6 million at June 30, 2011 and $3.3 million at December 31, 2010.
   These liabilities are included in accrued expenses in the accompanying Consolidated Balance Sheets.

[0000950123-11-071519:notes:94]
A summary of warranty expense and write-off activity for the six months ended June 30, 2011 and
   2010 is as follows:

[0000950123-11-071519:notes:95]
| Six Months Ended June 30, |  |  |  |
| (In thousands) |  | 2011 |  |  | 2010 |  |
| Balance at beginning of period |  | $ | 3,304 |  |  | $ | 2,833 |  |
| Plus: Amounts charged to cost and expenses |  |  | 1,525 |  |  |  | 1,377 |  |
| Less: Deductions |  |  | (1,183 | ) |  |  | (1,050 | ) |
| Balance at end of period |  | $ | 3,646 |  |  | $ | 3,160 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0000950123-11-071519:notes:96]
10. RELATED PARTY TRANSACTIONS

[0000950123-11-071519:notes:97]
We employ the law firm of our director emeritus for legal services. All bills for services
   rendered by this firm are reviewed and approved by our Chief Financial Officer. We believe that
   the fees for such services are comparable to those charged by other firms for services rendered to
   us. For the three and six month periods ended June 30, 2011 and 2010, we incurred fees of $10
   thousand per month for these legal services.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000950123-11-071519:notes:98]
11. COMMITMENTS AND CONTINGENCIES

[0000950123-11-071519:notes:99]
In the ordinary course of business, we may be subject to various legal proceedings and claims,
   including employment disputes, patent claims, disputes over contract agreements and other
   commercial disputes. In some cases, claimants seek damages or other relief, such as royalty
   payments related to patents, which, if granted, could require significant expenditures. Although
   the outcome of any claim or litigation can never be certain, it is our opinion that the outcome of
   all contingencies of which we are currently aware will not materially affect our business,
   operations, financial condition or cash flows.

[0000950123-11-071519:notes:100]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, and we
   have contributed $8.4 million as of June 30, 2011, of which $7.7 million has been applied to these
   commitments. See Note 4 of Notes to Consolidated Financial Statements for additional information.


## us-gaap:SubsequentEventsTextBlock

[0000950123-11-071519:notes:101]
12. SUBSEQUENT EVENTS

[0000950123-11-071519:notes:102]
On July 12, 2011, we announced that our Board of Directors declared a quarterly cash dividend of
   $0.09 per common share to be paid to stockholders of record at the close of business on July 28,
   2011. The payment date will be August 11, 2011. The quarterly dividend payment will be
   approximately $5.8 million. In July 2003, our Board of Directors elected to begin declaring
   quarterly dividends on our common stock considering the tax treatment of dividends and adequate
   levels of Company liquidity.

[0000950123-11-071519:notes:103]
During the third quarter of 2011 and as of August 2, 2011, we repurchased 0.6 million shares of our
   common stock through open market purchases at an average cost of $34.25 per share. We have the
   authority to purchase an additional 1.4 million shares of our common stock under the plan approved
   by the Board of Directors on April 14, 2008.
