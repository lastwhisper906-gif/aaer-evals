# ADTN 8-K — 0001157523-11-003986 filed 2011-07-13

## item codes, every 8-K on or before 2011-08-02

- 2011-07-13 0001157523-11-003986 — 2.02, 9.01
- 2011-05-09 0000950123-11-047191 — 5.02, 5.07, 9.01
- 2011-04-13 0001157523-11-002001 — 2.02, 9.01
- 2011-01-19 0001157523-11-000232 — 2.02, 9.01
- 2010-11-09 0000950123-10-103195 — 5.02, 9.01
- 2010-10-13 0001157523-10-005798 — 2.02, 9.01
- 2010-07-14 0001157523-10-004011 — 2.02, 9.01
- 2010-05-28 0000950123-10-053947 — 5.07
- 2010-04-14 0001157523-10-002022 — 2.02, 9.01
- 2010-01-20 0001157523-10-000200 — 2.02, 9.01
- 2009-10-28 0000950123-09-053984 — 8.01
- 2009-10-14 0001157523-09-006877 — 2.02, 9.01
- 2009-07-15 0001157523-09-004878 — 2.02, 9.01
- 2009-04-15 0001157523-09-002687 — 2.02, 9.01
- 2009-01-21 0001157523-09-000340 — 2.02, 9.01
- 2008-11-12 0001193125-08-233181 — 5.02, 9.01
- 2008-10-14 0001157523-08-007999 — 2.02, 9.01
- 2008-07-15 0001157523-08-005504 — 2.02, 9.01
- 2008-04-15 0001157523-08-002896 — 2.02, 9.01
- 2008-01-22 0001157523-08-000408 — 2.02, 9.01
- 2007-10-16 0001193125-07-219356 — 5.03, 9.01
- 2007-10-16 0001157523-07-009850 — 2.02, 9.01
- 2007-07-17 0001157523-07-006912 — 2.02, 9.01
- 2007-04-17 0001157523-07-003630 — 2.02, 9.01
- 2007-04-03 0001179022-07-000068 — 5.02
- 2007-03-28 0001179022-07-000064 — 5.02
- 2007-02-23 0001193125-07-038337 — 5.02
- 2007-02-23 0001193125-07-038335 — 5.02
- 2007-01-30 0001193125-07-015912 — 5.02, 9.01
- 2007-01-26 0001193125-07-014234 — 5.02
- 2007-01-23 0001157523-07-000494 — 2.02, 9.01 — amendment of 0001157523-07-000481
- 2007-01-23 0001157523-07-000481 — 2.02, 9.01
- 2006-10-17 0001157523-06-009945 — 2.02, 9.01
- 2006-07-18 0001157523-06-006929 — 2.02, 9.01
- 2006-06-08 0001193125-06-126486 — 1.01, 9.01
- 2006-05-10 0001193125-06-107316 — 1.01, 9.01
- 2006-04-18 0001157523-06-003699 — 2.02, 9.01
- 2006-02-03 0001179022-06-000014 — 1.01
- 2006-01-27 0001157523-06-000754 — 5.02, 9.01
- 2006-01-24 0001157523-06-000551 — 2.02, 9.01
- 2005-10-18 0001157523-05-008826 — 2.02, 9.01
- 2005-07-19 0001193125-05-143958 — 1.01, 5.02, 9.01
- 2005-07-19 0001193125-05-143957 — 2.02, 9.01
- 2005-05-20 0001193125-05-112019 — 1.01, 9.01
- 2005-04-19 0001157523-05-003418 — 2.02, 9.01
- 2005-01-25 0001193125-05-010721 — 2.02, 9.01
- 2004-10-12 0001193125-04-169652 — 2.02, 9.01
- 2004-07-13 0001193125-04-116820 — 12, 7
- 2004-04-14 0001193125-04-061547 — 12, 7
- 2004-01-21 0001193125-04-006366 — 12, 7
- 2003-10-14 0001193125-03-061018 — 12, 5, 7
- 2003-07-15 0001193125-03-019292 — 7, 9
- 2003-04-15 0000931763-03-000968 — 7, 9
- 1996-09-12 0000931763-96-000667 — 5, 7

## late-filing notifications on or before 2011-08-02

- none on or before 2011-08-02

## item 2.02 — earnings release, exhibit 99.1

[0001157523-11-003986:8k_2_02:1]
EX-99.1
2
a6791224ex99-1.htm
EXHIBIT 99.1

[0001157523-11-003986:8k_2_02:2]
Exhibit 99.1

[0001157523-11-003986:8k_2_02:3]
ADTRAN,
      Inc. Reports Record Results for Second Quarter 2011 and Declares
      Quarterly Cash Dividend

[0001157523-11-003986:8k_2_02:4]
HUNTSVILLE, Ala.--(BUSINESS WIRE)--July 12, 2011--ADTRAN, Inc.
      (NASDAQ:ADTN) reported results for the second quarter of 2011. Sales
      increased 23% to an all time record level of $184,227,000 for the
      quarter, compared to $150,361,000 for the second quarter of 2010.
      Operating income increased 33% to an all time record level of
      $51,310,000 for the quarter compared to $38,617,000 for the second
      quarter of 2010. Net income increased 33% to $36,943,000 for the
      quarter, compared to $27,751,000 for the second quarter of 2010.
      Earnings per share, assuming dilution, increased 27% to $0.56 for the
      quarter, compared to $0.44 for the second quarter of 2010.

[0001157523-11-003986:8k_2_02:5]
ADTRAN Chief Executive Officer Tom Stanton stated, “Our Company had an
      outstanding quarter reaching new highs on multiple fronts. The
      performance was led by our growth areas which combined grew 48% over the
      prior year, now representing 72% of our total company revenue. Moreover,
      every component of our growth areas, which include Broadband Access,
      Optical Access and Internetworking, individually attained new revenue
      highs. Broadband Access grew an impressive 71% over second quarter 2010,
      driven by the continued success of our Total Access 5000 and
      Fiber-to-the-Node platforms. Optical Access grew 36% and Internetworking
      grew 18%. These results allowed the company to achieve its fifth
      consecutive quarterly revenue record. As demonstrated by our results, we
      believe our highly differentiated solutions are exceptionally well
      positioned to take advantage of secular trends occurring in the markets
      we serve.”

[0001157523-11-003986:8k_2_02:6]
The Company reported that stock-based compensation expense for the
      second quarter of 2011 reduced diluted earnings per share by $0.03
      compared to a reduction of $0.03 for the second quarter of 2010.

[0001157523-11-003986:8k_2_02:7]
The Company also announced that its Board of Directors declared a cash
      dividend for the second quarter of 2011. The quarterly cash dividend is
      $0.09 per common share to be paid to holders of record at the close of
      business on July 28, 2011. The ex-dividend date is July 26, 2011 and the
      payment date is August 11, 2011.

[0001157523-11-003986:8k_2_02:8]
The Company confirmed that its second quarter conference call will be
      held Wednesday, July 13, 2011 at 9:30 a.m. Central Time. This conference
      call will be web cast live through StreetEvents.com. To listen, simply
      visit the Investor Relations site at http://www.adtran.com or http://www.streetevents.com
      approximately 10 minutes prior to the start of the call and click on the
      conference call link provided.

[0001157523-11-003986:8k_2_02:9]
An online replay of the conference call will be available for seven days
      at http://www.streetevents.com. In addition, an online replay of
      the conference call, as well as the text of the Company's earnings
      release, will be available on the Investor Relations site at http://www.adtran.com
      for at least 12 months following the call.

[0001157523-11-003986:8k_2_02:10]
ADTRAN, Inc. is a leading global provider of networking and
      communications equipment, with a portfolio of more than 1,700 solutions.
      ADTRAN’s products enable voice, data, video, and Internet communications
      across a variety of network infrastructures. ADTRAN solutions are
      currently in use by service providers, private enterprises, government
      organizations, and millions of individual users worldwide.

[0001157523-11-003986:8k_2_02:11]
For more information, contact the company at 800 9ADTRAN (800 923-8726)
      or via email at info@adtran.com. On the Web, visit www.adtran.com.

[0001157523-11-003986:8k_2_02:12]
This press release contains forward-looking statements which reflect
      management’s best judgment based on factors currently known. However,
      these statements involve risks and uncertainties, including the
      successful development and market acceptance of new products, the degree
      of competition in the market for such products, the product and channel
      mix, component costs, manufacturing efficiencies, and other risks
      detailed in our annual report on Form 10-K for the year ended December
      31, 2010 and our quarterly report on Form 10Q for the quarter ended
      March 31, 2011. These risks and uncertainties could cause actual results
      to differ materially from those in the forward-looking statements
      included in this press release.

[0001157523-11-003986:8k_2_02:13]
| Condensed Consolidated Balance Sheet Unaudited (In thousands) |
|  |  | June 30,2011 |  | December 31,2010 |
| Assets |  |  |  |  |
| Cash and cash equivalents |  | $ | 23,787 |  | $ | 31,677 |
| Short-term investments |  |  | 138,690 |  |  | 157,479 |
| Accounts receivable, net |  |  | 83,266 |  |  | 70,893 |
| Other receivables |  |  | 10,425 |  |  | 3,962 |
| Income tax receivable, net |  |  | 805 |  |  | 2,741 |
| Inventory |  |  | 86,676 |  |  | 74,274 |
| Prepaid expenses |  |  | 3,362 |  |  | 3,270 |
| Deferred tax assets, net |  |  | 12,150 |  |  | 10,617 |
| Total current assets |  |  | 359,161 |  |  | 354,913 |
| Property, plant and equipment, net |  |  | 74,961 |  |  | 73,986 |
| Other assets |  |  | 1,825 |  |  | 1,915 |
| Long-term investments |  |  | 372,432 |  |  | 261,160 |
| Total assets |  | $ | 808,379 |  | $ | 691,974 |
| Liabilities and Stockholders' Equity |  |  |  |  |
| Accounts payable |  | $ | 38,488 |  | $ | 22,785 |
| Unearned revenue |  |  | 9,312 |  |  | 10,138 |
| Accrued expenses |  |  | 5,957 |  |  | 4,913 |
| Accrued wages and benefits |  |  | 10,551 |  |  | 12,125 |
| Total current liabilities |  |  | 64,308 |  |  | 49,961 |
| Deferred tax liabilities, net |  |  | 8,802 |  |  | 10,350 |
| Other non-current liabilities |  |  | 15,086 |  |  | 11,841 |
| Bonds payable |  |  | 46,500 |  |  | 47,500 |
| Total liabilities |  |  | 134,696 |  |  | 119,652 |
| Stockholders' equity |  |  | 673,683 |  |  | 572,322 |
| Total liabilities and stockholders' equity |  | $ | 808,379 |  | $ | 691,974 |

[0001157523-11-003986:8k_2_02:14]
| Consolidated Statements of Income Unaudited (In thousands, except per share data) |
|  |  |  | Three Months Ended |  | Six Months Ended |
|  |  |  | June 30, |  | June 30, |
|  |  |  | 2011 |  | 2010 |  | 2011 |  | 2010 |
| Sales |  | $ | 184,227 |  |  | $ | 150,361 |  |  | $ | 349,749 |  |  | $ | 277,388 |  |
| Cost of sales |  |  | 77,400 |  |  |  | 61,032 |  |  |  | 144,127 |  |  |  | 112,731 |  |
| Gross Profit |  |  | 106,827 |  |  |  | 89,329 |  |  |  | 205,622 |  |  |  | 164,657 |  |
| Selling, general and administrative expenses |  |  | 30,898 |  |  |  | 28,455 |  |  |  | 60,450 |  |  |  | 55,659 |  |
| Research and development expenses |  |  | 24,619 |  |  |  | 22,257 |  |  |  | 48,256 |  |  |  | 45,036 |  |
| Operating Income |  |  | 51,310 |  |  |  | 38,617 |  |  |  | 96,916 |  |  |  | 63,962 |  |
| Interest and dividend income |  |  | 2,003 |  |  |  | 1,654 |  |  |  | 3,792 |  |  |  | 3,181 |  |
| Interest expense |  |  | (594 | ) |  |  | (595 | ) |  |  | (1,196 | ) |  |  | (1,198 | ) |
| Net realized investment gain |  |  | 3,372 |  |  |  | 2,464 |  |  |  | 6,139 |  |  |  | 4,656 |  |
| Other expense, net |  |  | (117 | ) |  |  | (188 | ) |  |  | (242 | ) |  |  | (375 | ) |
| Income before provision for income taxes |  |  | 55,974 |  |  |  | 41,952 |  |  |  | 105,409 |  |  |  | 70,226 |  |
| Provision for income taxes |  |  | (19,031 | ) |  |  | (14,201 | ) |  |  | (34,208 | ) |  |  | (24,281 | ) |
| Net Income |  | $ | 36,943 |  |  | $ | 27,751 |  |  | $ | 71,201 |  |  | $ | 45,945 |  |
| Weighted average shares outstanding - basic |  |  | 64,690 |  |  |  | 62,172 |  |  |  | 64,441 |  |  |  | 62,086 |  |
| Weighted average shares outstanding - diluted (1) |  |  | 66,135 |  |  |  | 63,488 |  |  |  | 66,044 |  |  |  | 63,281 |  |
| Earnings per common share - basic |  | $ | 0.57 |  |  | $ | 0.45 |  |  | $ | 1.10 |  |  | $ | 0.74 |  |
| Earnings per common share - diluted (1) |  | $ | 0.56 |  |  | $ | 0.44 |  |  | $ | 1.08 |  |  | $ | 0.73 |  |
| (1) Assumes exercise of dilutive stock options calculated under the treasury stock method. |  |  |  |

[0001157523-11-003986:8k_2_02:15]
| Supplemental Information Stock-based Compensation Expense Unaudited (In thousands) |
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | June 30, |  | June 30, |
|  |  | 2011 |  | 2010 |  | 2011 |  | 2010 |
| Stock-based compensation expense included in cost of sales |  | $ | 89 |  |  | $ | 73 |  |  | $ | 180 |  |  | $ | 141 |  |
| Selling, general and administrative expense |  |  | 999 |  |  |  | 835 |  |  |  | 2,006 |  |  |  | 1,585 |  |
| Research and development expense |  |  | 988 |  |  |  | 900 |  |  |  | 1,979 |  |  |  | 1,771 |  |
| Stock-based compensation expense included in operating expenses |  |  | 1,987 |  |  |  | 1,735 |  |  |  | 3,985 |  |  |  | 3,356 |  |
| Total stock-based compensation expense |  |  | 2,076 |  |  |  | 1,808 |  |  |  | 4,165 |  |  |  | 3,497 |  |
| Tax benefit for expense associated with non-qualified options |  |  | (276 | ) |  |  | (195 | ) |  |  | (716 | ) |  |  | (372 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 1,800 |  |  | $ | 1,613 |  |  | $ | 3,449 |  |  | $ | 3,125 |  |

[0001157523-11-003986:8k_2_02:16]
| Consolidated Statements of Cash Flow Unaudited (In thousands) |
|  |  | Six Months Ended |
|  |  | June 30, |
|  |  | 2011 |  | 2010 |
| Cash flows from operating activities: |  |  |  |  |
| Net income |  | $ | 71,201 |  |  | $ | 45,945 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Depreciation and amortization |  |  | 5,469 |  |  |  | 5,218 |  |
| Amortization of net premium on available-for-sale investments |  |  | 2,992 |  |  |  | 2,211 |  |
| Net realized gain on long-term investments |  |  | (6,139 | ) |  |  | (4,656 | ) |
| Net loss on disposal of property, plant and equipment |  |  | 17 |  |  |  | 12 |  |
| Stock-based compensation expense |  |  | 4,165 |  |  |  | 3,497 |  |
| Deferred income taxes |  |  | (192 | ) |  |  | (2,183 | ) |
| Tax benefit from stock option exercises |  |  | 10,318 |  |  |  | 1,757 |  |
| Excess tax benefits from stock-based compensation arrangements |  |  | (9,180 | ) |  |  | (1,579 | ) |
| Change in operating assets and liabilities: |  |  |  |  |
| Accounts receivable, net |  |  | (12,373 | ) |  |  | (3,596 | ) |
| Other receivables |  |  | (6,463 | ) |  |  | (3,929 | ) |
| Income tax receivable, net |  |  | 1,936 |  |  |  | - |  |
| Inventory |  |  | (12,402 | ) |  |  | (18,273 | ) |
| Prepaid expenses and other assets |  |  | (176 | ) |  |  | (647 | ) |
| Accounts payable |  |  | 14,703 |  |  |  | 18,512 |  |
| Accrued expenses and other liabilities |  |  | 1,870 |  |  |  | 5,798 |  |
| Income tax payable, net |  |  | - |  |  |  | 892 |  |
| Net cash provided by operating activities |  |  | 65,746 |  |  |  | 48,979 |  |
| Cash flows from investing activities: |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (6,287 | ) |  |  | (4,789 | ) |
| Proceeds from sales and maturities of available-for-sale investments |  |  | 237,459 |  |  |  | 111,985 |  |
| Purchases of available-for-sale investments |  |  | (335,870 | ) |  |  | (137,688 | ) |
| Net cash used in investing activities |  |  | (104,698 | ) |  |  | (30,492 | ) |
| Cash flows from financing activities: |  |  |  |  |
| Proceeds from stock option exercises |  |  | 33,022 |  |  |  | 7,409 |  |
| Purchases of treasury stock |  |  | - |  |  |  | (10,330 | ) |
| Dividend payments |  |  | (11,596 | ) |  |  | (11,171 | ) |
| Excess tax benefits from stock-based compensation arrangements |  |  | 9,180 |  |  |  | 1,579 |  |
| Net cash provided by (used in) financing activities |  |  | 30,606 |  |  |  | (12,513 | ) |
| Net increase (decrease) in cash and cash equivalents |  |  | (8,346 | ) |  |  | 5,974 |  |
| Effect of exchange rate changes |  |  | 456 |  |  |  | (602 | ) |
| Cash and cash equivalents, beginning of period |  |  | 31,677 |  |  |  | 24,135 |  |
| Cash and cash equivalents, end of period |  | $ | 23,787 |  |  | $ | 29,507 |  |

[0001157523-11-003986:8k_2_02:17]
CONTACT:
ADTRAN, Inc.
Jim Matthews, 256-963-8775
Senior
      Vice President/CFO
or
INVESTOR SERVICES/ASSISTANCE:
Gayle
      Ellis, 256-963-8220
