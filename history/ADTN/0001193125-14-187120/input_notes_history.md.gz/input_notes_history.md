# ADTN note change history — 0001193125-13-422365 → 0001193125-14-187120


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2014-05-07):
[0001193125-14-187120:note_history:1]
14. COMMITMENTS AND CONTINGENCIES
  (was, 2013-11-01, similarity 0.9118):
[0001193125-13-422365:note_history:1]
| 15. | COMMITMENTS AND CONTINGENCIES |

- changed (2014-05-07):
[0001193125-14-187120:note_history:2]
We have committed to invest up to an aggregate of $7.9 million in
 two private equity funds, and we have contributed $8.4 million as
 of March 31, 2014, of which $7.7 million has been applied to
 these commitments.
  (was, 2013-11-01, similarity 0.9652):
[0001193125-13-422365:note_history:2]
We have
 committed to invest up to an aggregate of $7.9 million in two
 private equity funds, and we have contributed $8.4 million as of
 September 30, 2013, of which $7.7 million has been applied to
 these commitments.


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2014-05-07):
[0001193125-14-187120:note_history:3]
1. SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES
  (was, 2013-11-01, similarity 0.9362):
[0001193125-13-422365:note_history:3]
| 1. | SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES |

- changed (2014-05-07):
[0001193125-14-187120:note_history:4]
In the opinion of management, all adjustments necessary for a fair
 presentation of these interim statements have been recorded and are
 of a normal and recurring nature. The results of operations for an
 interim period are not necessarily indicative of the results for
 the full year. The interim statements should be read in conjunction
 with the financial statements and notes thereto included in
 ADTRAN’s Annual Report on Form 10-K for the year ended
 December 31, 2013, filed on February 27, 2014 with the
 SEC.
  (was, 2013-11-01, similarity 0.9118):
[0001193125-13-422365:note_history:4]
In the opinion of management, all adjustments necessary for a fair
 presentation of these interim statements have been recorded,
 including the out of period adjustment discussed below. The results
 of operations for an interim period are not necessarily indicative
 of the results for the full year. The interim statements should be
 read in conjunction with the financial statements and notes thereto
 included in ADTRAN’s Annual Report on Form 10-K for the year
 ended December 31, 2012, filed on February 28, 2013 with
 the SEC.

- added (2014-05-07):
[0001193125-14-187120:note_history:5]
We corrected immaterial misclassifications between the operating
 and investing sections of our consolidated statements of cash flows
 and adjusted our cash flows for the three months ended
 March 31, 2013 in these categories by $0.1 million in order to
 be consistent with the 2014 presentation.

- changed (2014-05-07):
[0001193125-14-187120:note_history:6]
During the year ended December 31, 2013, we identified two
 adjustments in the acquired NSN (formerly Nokia Siemens Networks)
 Broadband Access business (NSN BBA business) relating to customer
 payment discounts for one customer, and recoverable VAT taxes on
 certain vendor freight invoices that should have been recorded in
 prior periods. These adjustments resulted from a $0.3 million
 understatement of net income in the first quarter of 2013. We
 evaluated the impact of the adjustments on the results of our
 previously issued financial statements for first quarter of 2013
 and concluded that the impact was not material. We also evaluated
 the impact of the cumulative effect of the adjustments in 2013 and
 concluded that the impact was not material to our results for
 the year 2013. Accordingly, during the three months ended
 September 30, 2013 we recorded an out of period adjustment to
 correct these issues.
  (was, 2013-11-01, similarity 0.8326):
[0001193125-13-422365:note_history:6]
During the three months ended September 30, 2013, we
 identified two adjustments in the acquired Nokia Siemens Networks
 Broadband Access business (NSN BBA business) relating to customer
 payment discounts for one customer, and recoverable VAT taxes on
 certain vendor freight invoices that should have been recorded in
 prior periods. These adjustments resulted from a $0.4 million
 understatement of net income in 2012 and $0.5 million
 understatement of net income in the first two quarters of 2013. We
 evaluated the impact of the adjustments on the results of our
 previously issued financial statements for each of the prior
 periods affected and concluded that the impact was not material. We
 also evaluated the impact of the cumulative effect of the
 adjustments in the current year and concluded that the impact is
 not material to our projected results for the year 2013.
 Accordingly, during the three months ended September 30, 2013
 we recorded an out of period adjustment to correct these
 issues.

- changed (2014-05-07):
[0001193125-14-187120:note_history:7]
The preparation of financial statements in conformity with
 accounting principles generally accepted in the United States of
 America requires management to make estimates and assumptions that
 affect the reported amounts of assets and liabilities, the
 disclosure of contingent assets and liabilities at the date of the
 financial statements, and the reported amounts of revenue and
 expense during the reporting period. Our more significant estimates
 include the obsolete and excess inventory reserves, warranty
 reserves, customer rebates, determination of the deferred revenue
 components of multiple element sales agreements, estimated costs to
 complete obligations associated with deferred revenues, estimated
 income tax provision and income tax contingencies, the fair value
 of stock-based compensation, impairment of goodwill, valuation and
 estimated lives of intangible assets, estimated working capital
 adjustments under negotiation related to the NSN BBA business
 acquisition, estimated pension liability, fair value of
 investments, and the evaluation of other-than-temporary declines in
 the value of investments. Actual amounts could differ significantly
 from these estimates.
  (was, 2013-11-01, similarity 0.8243):
[0001193125-13-422365:note_history:7]
The preparation of financial statements in conformity with
 accounting principles generally accepted in the United States of
 America requires management to make estimates and assumptions that
 affect the reported amounts of assets and liabilities, the
 disclosure of contingent assets and liabilities at the date of the
 financial statements, and the reported amounts of revenue and
 expense during the reporting period. Our more significant estimates
 include the allowance for doubtful accounts, obsolete and excess
 inventory reserves, warranty reserves, customer rebates, allowance
 for sales returns, determination of the deferred revenue components
 of multiple element sales agreements, estimated costs to complete
 obligations associated with deferred revenues, estimated income tax
 contingencies, the fair value of stock-based compensation,
 impairment of goodwill, valuation and estimated lives of intangible
 assets, estimated working capital adjustments under negotiation
 related to the Nokia Siemens Networks Broadband Access business
 acquisition, and the evaluation of other-than-temporary declines in
 the value of investments. Actual amounts could differ significantly
 from these estimates.

- changed (2014-05-07):
[0001193125-14-187120:note_history:8]
During the three months ended March 31, 2014, no accounting
 pronouncements were issued that would have a material effect on our
 consolidated results of operations or financial condition.
  (was, 2013-11-01, similarity 0.7493):
[0001193125-13-422365:note_history:8]
During the nine months ended September 30, 2013, we adopted
 the following accounting standard, which had no material effect on
 our consolidated results of operations or financial condition:

- removed (2014-05-07):
[0001193125-13-422365:note_history:9]
Certain changes in classifications have been made to the prior
 period balances in other comprehensive income to conform to the
 current period’s presentation as a result of our adoption of
 Accounting Standards Update No. 2013-02, Reporting of Amounts
 Reclassified Out of Accumulated Comprehensive Income.

- removed (2014-05-07):
[0001193125-13-422365:note_history:10]
In February 2013, the FASB issued Accounting Standards Update
 No. 2013-02, Reporting of Amounts Reclassified Out of
 Accumulated Other Comprehensive Income (ASU 2013-02). ASU 2013-02
 requires entities to provide information about the amounts
 reclassified out of accumulated other comprehensive income by
 component either on the face of the financial statements or in the
 footnotes. ASU 2013-02 does not change the current requirements for
 reporting net income or other comprehensive income in the financial
 statements. This update is effective prospectively for reporting
 periods beginning after December 15, 2012. We adopted this
 amendment during the first quarter of 2013, and we have provided
 the disclosures required for the periods ended September 30,
 2013 and 2012 in Note 10 of Notes to Consolidated Financial
 Statements.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2014-05-07):
[0001193125-14-187120:note_history:11]
5. INVESTMENTS
  (was, 2013-11-01, similarity 0.8125):
[0001193125-13-422365:note_history:11]
| 6. | INVESTMENTS |

- changed (2014-05-07):
[0001193125-14-187120:note_history:12]
At March 31, 2014, we held the following securities and
 investments, recorded at either fair value or cost.
  (was, 2013-11-01, similarity 0.9515):
[0001193125-13-422365:note_history:12]
At September 30, 2013, we held the following securities and
 investments, recorded at either fair value or cost.

- changed (2014-05-07):
[0001193125-14-187120:note_history:13]
| (In thousands) |  | Amortized Cost |  |  | Gross Unrealized |  |  | Carrying Value |  |
|  |  | Gains |  |  | Losses |  |  |
| Deferred compensation plan assets |  | $ | 12,300 |  |  | $ | 2,847 |  |  | $ | (24 | ) |  | $ | 15,123 |  |
| Corporate bonds |  |  | 166,370 |  |  |  | 534 |  |  |  | (45 | ) |  |  | 166,859 |  |
| Municipal fixed-rate bonds |  |  | 135,773 |  |  |  | 583 |  |  |  | (54 | ) |  |  | 136,302 |  |
| Municipal variable rate demand notes |  |  | 8,310 |  |  |  | — |  |  |  | — |  |  |  | 8,310 |  |
| Marketable equity securities |  |  | 24,654 |  |  |  | 13,975 |  |  |  | (177 | ) |  |  | 38,452 |  |
| Available-for-sale securities held at fair value |  | $ | 347,407 |  |  | $ | 17,939 |  |  | $ | (300 | ) |  | $ | 365,046 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 48,250 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1,689 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 414,985 |  |
  (was, 2013-11-01, similarity 0.9616):
[0001193125-13-422365:note_history:13]
| (In thousands) |  | Amortized Cost |  |  | Gross Unrealized |  |  | Carrying Value |  |
|  |  | Gains |  |  | Losses |  |  |
| Deferred compensation plan assets |  | $ | 10,688 |  |  | $ | 846 |  |  | $ | (7 | ) |  | $ | 11,527 |  |
| Corporate bonds |  |  | 185,464 |  |  |  | 966 |  |  |  | (18 | ) |  |  | 186,412 |  |
| Municipal fixed-rate bonds |  |  | 174,530 |  |  |  | 627 |  |  |  | (73 | ) |  |  | 175,084 |  |
| Municipal variable rate demand notes |  |  | 34,375 |  |  |  | — |  |  |  | — |  |  |  | 34,375 |  |
| Fixed income bond fund |  |  | 444 |  |  |  | 12 |  |  |  | — |  |  |  | 456 |  |
| Marketable equity securities |  |  | 20,966 |  |  |  | 14,630 |  |  |  | (392 | ) |  |  | 35,204 |  |
| Available-for-sale securities held at fair value |  | $ | 426,467 |  |  | $ | 17,081 |  |  | $ | (490 | ) |  | $ | 443,058 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 48,250 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1,902 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 493,210 |  |

- changed (2014-05-07):
[0001193125-14-187120:note_history:14]
As of March 31, 2014, our corporate bonds and municipal
 fixed-rate bonds had the following contractual maturities:
  (was, 2013-11-01, similarity 0.9545):
[0001193125-13-422365:note_history:14]
As of September 30, 2013, our corporate bonds and municipal
 fixed-rate bonds had the following contractual maturities:

- changed (2014-05-07):
[0001193125-14-187120:note_history:15]
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |
| Less than one year |  | $ | 34,248 |  |  | $ | 34,630 |  |
| One to two years |  |  | 52,222 |  |  |  | 60,991 |  |
| Two to three years |  |  | 44,393 |  |  |  | 47,713 |  |
| Three to five years |  |  | — |  |  |  | 15,053 |  |
| Total |  | $ | 130,863 |  |  | $ | 158,387 |  |
  (was, 2013-11-01, similarity 0.9965):
[0001193125-13-422365:note_history:15]
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |
| Less than one year |  | $ | 66,267 |  |  | $ | 58,413 |  |
| One to two years |  |  | 32,231 |  |  |  | 18,638 |  |
| Two to three years |  |  | 76,460 |  |  |  | 58,389 |  |
| Three to five years |  |  | 3,183 |  |  |  | 10,495 |  |
| Total |  | $ | 178,141 |  |  | $ | 145,935 |  |

- changed (2014-05-07):
[0001193125-14-187120:note_history:16]
At March 31, 2014, we held a $30.0 million restricted
 certificate of deposit, which is carried at cost. This investment
 serves as a collateral deposit against the principal amount
 outstanding under loans made to ADTRAN pursuant to an Alabama State
 Industrial Development Authority revenue bond (the Bond). During
 the first quarter of 2014, we made a principal payment on the Bond
 of $16.5 million. At March 31, 2014, the estimated fair value
 of the Bond using a level 2 valuation technique was approximately
 $29.6 million, based on a debt security with a comparable interest
 rate and maturity and a Standard and Poor’s credit rating of
 AAA-. For more information on the Bond, see “Debt”
 under “Liquidity and Capital Resources” in the
 “Management’s Discussion and Analysis of Financial
 Condition and Results of Operations” contained in Item 2
 of Part I of this report.
  (was, 2013-11-01, similarity 0.6791):
[0001193125-13-422365:note_history:16]
At September 30, 2013, we held a $48.3 million restricted
 certificate of deposit, which is carried at cost. This investment
 serves as a collateral deposit against the principal amount
 outstanding under loans made to ADTRAN pursuant to an Alabama State
 Industrial Development Authority revenue bond (the Bond). At
 September 30, 2013, the estimated fair value of the Bond using
 a level 2 valuation technique was approximately $44.9 million,
 based on a debt security with a comparable interest rate and
 maturity and a Standard and Poor’s credit rating of A-. For
 more information on the Bond, see “Debt” under
 “Liquidity and Capital Resources” in the
 “Management’s Discussion and Analysis of Financial
 Condition and Results of Operations” contained in Item 2
 of Part I of this report.

- changed (2014-05-07):
[0001193125-14-187120:note_history:17]
We review our investment portfolio for potential
 “other-than-temporary” declines in value on an
 individual investment basis. We assess, on a quarterly basis,
 significant declines in value which may be considered
 other-than-temporary and, if necessary, recognize and record the
 appropriate charge to write-down the carrying value of such
 investments. In making this assessment, we take into consideration
 qualitative and quantitative information, including but not limited
 to the following: the magnitude and duration of historical declines
 in market prices, credit rating activity, assessments of liquidity,
 public filings, and statements made by the issuer. We generally
 begin our identification of potential other-than-temporary
 impairments by reviewing any security with a fair value that has
 declined from its original or adjusted cost basis by 25% or more
 for six or more consecutive months. We then evaluate the individual
 security based on the previously identified factors to determine
 the amount of the write-down, if any. As a result of our review, we
 recorded no other-than-temporary impairment charges during the
 three months ended March 31, 2014. For the three months ended
 March 31, 2013, we recorded an other-than-temporary impairment
 charge of $4 thousand related to one marketable equity
 security.
  (was, 2013-11-01, similarity 0.8684):
[0001193125-13-422365:note_history:17]
We review our investment portfolio for potential
 “other-than-temporary” declines in value on an
 individual investment basis. We assess, on a quarterly basis,
 significant declines in value which may be considered
 other-than-temporary and, if necessary, recognize and record the
 appropriate charge to write-down the carrying value of such
 investments. In making this assessment, we take into consideration
 qualitative and quantitative information, including but not limited
 to the following: the magnitude and duration of historical declines
 in market prices, credit rating activity, assessments of liquidity,
 public filings, and statements made by the issuer. We generally
 begin our identification of potential other-than-temporary
 impairments by reviewing any security with a fair value that has
 declined from its original or adjusted cost basis by 25% or more
 for six or more consecutive months. We then evaluate the individual
 security based on the previously identified factors to determine
 the amount of the write-down, if any. As a result of our review, we
 recorded an other-than-temporary impairment charge of $13 thousand
 during the nine months ended September 30, 2013 related to
 five marketable securities. For the nine months ended
 September 30, 2012, we recorded an other-than-temporary
 impairment charge of $0.1 million related to 21 marketable equity
 securities.

- changed (2014-05-07):
[0001193125-14-187120:note_history:18]
|  |  | Three Months Ended March 31, |  |
| (In thousands) |  | 2014 |  |  | 2013 |  |
| Gross realized gains |  | $ | 2,228 |  |  | $ | 3,727 |  |
| Gross realized losses |  | $ | (36 | ) |  | $ | (82 | ) |
  (was, 2013-11-01, similarity 0.6276):
[0001193125-13-422365:note_history:18]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
| Gross realized gains |  | $ | 1,797 |  |  | $ | 3,388 |  |  | $ | 7,252 |  |  | $ | 8,688 |  |
| Gross realized losses |  | $ | (46 | ) |  | $ | (858 | ) |  | $ | (303 | ) |  | $ | (1,335 | ) |

- changed (2014-05-07):
[0001193125-14-187120:note_history:19]
As of March 31, 2014 and 2013, gross unrealized losses related
 to individual securities in a continuous loss position for 12
 months or longer were not significant.
  (was, 2013-11-01, similarity 0.9677):
[0001193125-13-422365:note_history:19]
As of September 30, 2013 and 2012, gross unrealized losses
 related to individual securities in a continuous loss position for
 12 months or longer were not significant.

- added (2014-05-07):
[0001193125-14-187120:note_history:20]
We have categorized our cash equivalents held in money market funds
 and our investments held at fair value into a three-level fair
 value hierarchy based on the priority of the inputs to the
 valuation technique for the cash equivalents and investments as
 follows: Level 1—Values based on unadjusted quoted prices for
 identical assets or liabilities in an active market; Level
 2—Values based on quoted prices in markets that are not
 active or model inputs that are observable either directly or
 indirectly; Level 3—Values based on prices or valuation
 techniques that require inputs that are both unobservable and
 significant to the overall fair value measurement. These inputs
 include information supplied by investees.

- changed (2014-05-07):
[0001193125-14-187120:note_history:21]
|  |  | Fair Value Measurements at March 31, 2014 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 11,742 |  |  | $ | 11,742 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 15,277 |  |  |  | 15,277 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 130,863 |  |  |  | — |  |  |  | 130,863 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 158,387 |  |  |  | — |  |  |  | 158,387 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 24,840 |  |  |  | — |  |  |  | 24,840 |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity securities – technology industry |  |  | 10,639 |  |  |  | 10,639 |  |  |  | — |  |  |  | — |  |
| Equity securities – other |  |  | 26,947 |  |  |  | 26,947 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 366,953 |  |  |  | 52,863 |  |  |  | 314,090 |  |  |  | — |  |
| Total |  | $ | 378,695 |  |  | $ | 64,605 |  |  | $ | 314,090 |  |  | $ | — |  |
|  |  | Fair Value Measurements at December 31, 2013 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 3,949 |  |  | $ | 3,949 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 15,123 |  |  |  | 15,123 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 166,859 |  |  |  | — |  |  |  | 166,859 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 136,302 |  |  |  | — |  |  |  | 136,302 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 8,310 |  |  |  | — |  |  |  | 8,310 |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity securities – technology industry |  |  | 11,398 |  |  |  | 11,398 |  |  |  | — |  |  |  | — |  |
| Equity securities – other |  |  | 27,054 |  |  |  | 27,054 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 365,046 |  |  |  | 53,575 |  |  |  | 311,471 |  |  |  | — |  |
| Total |  | $ | 368,995 |  |  | $ | 57,524 |  |  | $ | 311,471 |  |  | $ | — |  |
  (was, 2013-11-01, similarity 0.6629):
[0001193125-13-422365:note_history:21]
|  |  | Fair Value Measurements at September 30, 2013 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 6,594 |  |  | $ | 6,594 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 13,780 |  |  |  | 13,780 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 178,141 |  |  |  | — |  |  |  | 178,141 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 145,935 |  |  |  | — |  |  |  | 145,935 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 11,960 |  |  |  | — |  |  |  | 11,960 |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity securities – technology industry |  |  | 9,973 |  |  |  | 9,973 |  |  |  | — |  |  |  | — |  |
| Equity securities – other |  |  | 24,970 |  |  |  | 24,970 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 384,759 |  |  |  | 48,723 |  |  |  | 336,036 |  |  |  | — |  |
| Total |  | $ | 391,353 |  |  | $ | 55,317 |  |  | $ | 336,036 |  |  | $ | — |  |

- removed (2014-05-07):
[0001193125-13-422365:note_history:22]
We have categorized our cash equivalents held in money market funds
 and our investments held at fair value into a three-level fair
 value hierarchy based on the priority of the inputs to the
 valuation technique for the cash equivalents and investments as
 follows: Level 1 – Values based on unadjusted, quoted prices
 in active markets for identical assets or liabilities; Level 2
 – Values based on inputs other than quoted prices included
 within Level 1 that are directly or indirectly observable for the
 asset or liability; Level 3 – Values based on
 unobservable inputs for the asset or liability. These inputs
 include information supplied by investees.

- removed (2014-05-07):
[0001193125-13-422365:note_history:23]
|  |  | Fair Value Measurements at December 31, 2012 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 28,071 |  |  | $ | 28,071 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 11,527 |  |  |  | 11,527 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 186,412 |  |  |  | — |  |  |  | 186,412 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 175,084 |  |  |  | — |  |  |  | 175,084 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 34,375 |  |  |  | — |  |  |  | 34,375 |  |  |  | — |  |
| Fixed income bond fund |  |  | 456 |  |  |  | 456 |  |  |  | — |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity securities – technology industry |  |  | 14,099 |  |  |  | 14,099 |  |  |  | — |  |  |  | — |  |
| Equity securities – other |  |  | 21,105 |  |  |  | 21,105 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 443,058 |  |  |  | 47,187 |  |  |  | 395,871 |  |  |  | — |  |
| Total |  | $ | 471,129 |  |  | $ | 75,258 |  |  | $ | 395,871 |  |  | $ | — |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2014-05-07):
[0001193125-14-187120:note_history:24]
13. RELATED PARTY TRANSACTIONS
  (was, 2013-11-01, similarity 0.9032):
[0001193125-13-422365:note_history:24]
| 14. | RELATED PARTY TRANSACTIONS |

- changed (2014-05-07):
[0001193125-14-187120:note_history:25]
We employ the law firm of our director emeritus for legal services.
 All bills for services rendered by this firm are reviewed and
 approved by our Chief Financial Officer. We believe that the fees
 for such services are comparable to those charged by other firms
 for services rendered to us. For the three months ended
 March 31, 2014 and 2013, we incurred fees of $10 thousand per
 month for these legal services.
  (was, 2013-11-01, similarity 0.9317):
[0001193125-13-422365:note_history:25]
We employ the
 law firm of our director emeritus for legal services. All bills for
 services rendered by this firm are reviewed and approved by our
 Chief Financial Officer. We believe that the fees for such services
 are comparable to those charged by other firms for services
 rendered to us. For the three and nine month periods ended
 September 30, 2013 and 2012, we incurred fees of $10 thousand
 per month for these legal services.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2014-05-07):
[0001193125-14-187120:note_history:26]
15. SUBSEQUENT EVENTS
  (was, 2013-11-01, similarity 0.8636):
[0001193125-13-422365:note_history:26]
| 16. | SUBSEQUENT EVENTS |

- changed (2014-05-07):
[0001193125-14-187120:note_history:27]
On April 15, 2014, we announced that our Board of Directors
 declared a quarterly cash dividend of $0.09 per common share to be
 paid to stockholders of record at the close of business on
 May 1, 2014. The payment date will be May 15, 2014. The
 quarterly dividend payment will be approximately $5.0 million. In
 July 2003, our Board of Directors elected to begin declaring
 quarterly dividends on our common stock considering the tax
 treatment of dividends and adequate levels of Company
 liquidity.
  (was, 2013-11-01, similarity 0.9651):
[0001193125-13-422365:note_history:27]
On October 8, 2013, we announced that our Board of Directors
 declared a quarterly cash dividend of $0.09 per common share to be
 paid to stockholders of record at the close of business on
 October 24, 2013. The payment date will be November 7,
 2013. The quarterly dividend payment will be approximately $5.2
 million. In July 2003, our Board of Directors elected to begin
 declaring quarterly dividends on our common stock considering the
 tax treatment of dividends and adequate levels of Company
 liquidity.

- changed (2014-05-07):
[0001193125-14-187120:note_history:28]
During the second quarter and as of May 7, 2014, we have
 repurchased 1.3 million shares of our common stock through
 open market purchases at an average cost of $22.63 per share. We
 currently have the authority to purchase an additional 1.8 million
 shares of our common stock under the current plan approved by the
 Board of Directors.
  (was, 2013-11-01, similarity 0.9178):
[0001193125-13-422365:note_history:28]
During the fourth quarter of 2013 and as of November 1, 2013,
 we repurchased 0.4 million shares of our common stock through
 open market purchases at an average cost of $23.85 per share. We
 currently have the authority to purchase an additional 3.9 million
 shares of our common stock under the current plan approved by the
 Board of Directors.
