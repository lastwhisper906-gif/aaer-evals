# ADTN notes — 0001193125-14-187120


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-14-187120:notes:1]
4. STOCK-BASED COMPENSATION

[0001193125-14-187120:notes:2]
The following table summarizes the stock-based compensation expense
 related to stock options, restricted stock units (RSUs) and
 restricted stock for the three months ended March 31, 2014 and
 2013, which was recognized as follows:

[0001193125-14-187120:notes:3]
|  |  | Three Months Ended March 31, |  |
| (In thousands) |  | 2014 |  |  | 2013 |  |
| Stock-based compensation expense included in cost of sales |  | $ | 116 |  |  | $ | 106 |  |
| Selling, general and administrative expense |  |  | 1,026 |  |  |  | 1,063 |  |
| Research and development expense |  |  | 915 |  |  |  | 1,063 |  |
| Stock-based compensation expense included in operating expenses |  |  | 1,941 |  |  |  | 2,126 |  |
| Total stock-based compensation expense |  |  | 2,057 |  |  |  | 2,232 |  |
| Tax benefit for expense associated with non-qualified options |  |  | (284 | ) |  |  | (307 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 1,773 |  |  | $ | 1,925 |  |

[0001193125-14-187120:notes:4]
The fair value of our stock options was estimated using the
 Black-Scholes model. The determination of the fair value of stock
 options on the date of grant using the Black-Scholes model is
 affected by our stock price as well as assumptions regarding a
 number of complex and subjective variables that may have a
 significant impact on the fair value estimate.

[0001193125-14-187120:notes:5]
There were no options granted during the three months ended
 March 31, 2013. The weighted-average assumptions and value of
 options granted for the three months ended March 31, 2014 are
 summarized as follows:

[0001193125-14-187120:notes:6]
|  |  | Three Months Ended March 31, 2014 |  |
| Expected volatility |  |  | 39.57 | % |
| Risk-free interest rate |  |  | 1.86 | % |
| Expected dividend yield |  |  | 1.38 | % |
| Expected life (in years) |  |  | 6.25 |  |
| Weighted-average estimated value |  | $ | 9.28 |  |

[0001193125-14-187120:notes:7]
The fair value of our RSUs is calculated using a Monte Carlo
 Simulation valuation method. No RSUs were granted, forfeited, or
 vested during the three months ended March 31, 2014 or
 2013.

[0001193125-14-187120:notes:8]
The fair value of restricted stock is equal to the closing price of
 our stock on the date of grant. No restricted stock was granted,
 forfeited, or vested during the three months ended March 31,
 2014 or 2013.

[0001193125-14-187120:notes:9]
Stock-based compensation expense recognized in our Consolidated
 Statements of Income for the three months ended March 31, 2014
 and 2013 is based on options, RSUs and restricted stock ultimately
 expected to vest, and has been reduced for estimated forfeitures.
 Estimated forfeitures for stock options were based upon historical
 experience and approximate 2.5% annually. We estimated a 0%
 forfeiture rate for our RSUs and restricted stock due to the
 limited number of recipients and historical experience for these
 awards.

[0001193125-14-187120:notes:10]
As of March 31, 2014, total compensation expense related to
 non-vested stock options, RSUs and restricted stock not yet
 recognized was approximately $16.4 million, which is expected to be
 recognized over an average remaining recognition period of 2.5
 years.

[0001193125-14-187120:notes:11]
The following table is a summary of our stock options outstanding
 as of December 31, 2013 and March 31, 2014 and the
 changes that occurred during the three months ended March 31,
 2014:

[0001193125-14-187120:notes:12]
| (In thousands, except per share amounts) |  | Number of Options |  |  | Weighted Avg. Exercise Price |  |  | Weighted Avg. Remaining Contractual Life In Years |  |  | Aggregate Intrinsic Value |  |
| Options outstanding, December 31, 2013 |  |  | 6,358 |  |  | $ | 24.43 |  |  |  | 6.60 |  |  | $ | 25,878 |  |
| Options granted |  |  | 2 |  |  | $ | 26.03 |  |  |  |  |  |  |  |  |  |
| Options cancelled/forfeited |  |  | (61 | ) |  | $ | 25.16 |  |  |  |  |  |  |  |  |  |
| Options exercised |  |  | (78 | ) |  | $ | 19.71 |  |  |  |  |  |  |  |  |  |
| Options outstanding, March 31, 2014 |  |  | 6,221 |  |  | $ | 24.48 |  |  |  | 6.35 |  |  | $ | 14,478 |  |
| Options exercisable, March 31, 2014 |  |  | 3,826 |  |  | $ | 24.84 |  |  |  | 4.93 |  |  | $ | 8,526 |  |

[0001193125-14-187120:notes:13]
The aggregate intrinsic values in the table above represent the
 total pre-tax intrinsic value (the difference between the closing
 price of our stock on the last trading day of the quarter and the
 exercise price, multiplied by the number of in-the-money options)
 that would have been received by the option holders had all option
 holders exercised their options on March 31, 2014. The
 aggregate intrinsic value will change based on the fair market
 value of our stock.

[0001193125-14-187120:notes:14]
The total pre-tax intrinsic value of options exercised during the
 three months ended March 31, 2014 was $0.5 million.


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001193125-14-187120:notes:15]
12. LIABILITY FOR WARRANTY RETURNS

[0001193125-14-187120:notes:16]
Our products generally include warranties of 90 days to ten years
 for product defects. We accrue for warranty returns at the time
 revenue is recognized based on our estimate of the cost to repair
 or replace the defective products. We engage in extensive product
 quality programs and processes, including actively monitoring and
 evaluating the quality of our component suppliers. Our products
 continue to become more complex in both size and functionality as
 many of our product offerings migrate from line card applications
 to systems products. The increasing complexity of our products will
 cause warranty incidences, when they arise, to be more costly. Our
 estimates regarding future warranty obligations may change due to
 product failure rates, material usage, and other rework costs
 incurred in correcting a product failure. In addition, from time to
 time, specific warranty accruals may be recorded if unforeseen
 problems arise. Should our actual experience relative to these
 factors be worse than our estimates, we will be required to record
 additional warranty expense. Alternatively, if we provide for more
 reserves than we require, we will reverse a portion of such
 provisions in future periods. The liability for warranty
 obligations totaled $7.4 million at March 31, 2014 and $9.0
 million at December 31, 2013. The decrease from
 December 31, 2013 to March 31, 2014 includes a $1.5
 million decrease related to the settlement of an outstanding
 warranty claim, which corresponds to a reduction in Other
 Receivables. These liabilities are included in accrued expenses in
 the accompanying Consolidated Balance Sheets.

[0001193125-14-187120:notes:17]
A summary of warranty expense and write-off activity for the three
 months ended March 31, 2014 and 2013 is as follows:

[0001193125-14-187120:notes:18]
|  |  | Three Months Ended March 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| (In thousands) |  |  |  |  |  |  |
| Balance at beginning of period |  | $ | 8,977 |  |  | $ | 9,653 |  |
| Plus: Amounts charged to cost and expenses |  |  | 434 |  |  |  | 397 |  |
| Less: Deductions |  |  | (2,019 | ) |  |  | (1,258 | ) |
| Balance at end of period |  | $ | 7,392 |  |  | $ | 8,792 |  |

[0001193125-14-187120:notes:19]
Deductions for the three months ended March 31, 2014 include a
 $1.5 million reduction that relates to the settlement of an
 outstanding warranty claim, which corresponds to a reduction in
 Other Receivables.


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001193125-14-187120:notes:20]
Recent Accounting Pronouncements

[0001193125-14-187120:notes:21]
During the three months ended March 31, 2014, no accounting
 pronouncements were issued that would have a material effect on our
 consolidated results of operations or financial condition.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-14-187120:notes:22]
11. SEGMENT INFORMATION

[0001193125-14-187120:notes:23]
[same as prior period, unchanged from 0001193125-13-422365:notes:25]

[0001193125-14-187120:notes:24]
The following table presents information about the reported sales
 and gross profit of our reportable segments for the three months
 ended March 31, 2014 and 2013. Asset information by reportable
 segment is not reported, since we do not produce such information
 internally.

[0001193125-14-187120:notes:25]
|  |  | Three Months Ended |  |
|  |  | March 31, 2014 |  |  | March 31, 2013 |  |
| (In thousands) |  | Sales |  |  | Gross Profit |  |  | Sales |  |  | Gross Profit |  |
| Carrier Networks |  | $ | 118,162 |  |  | $ | 61,353 |  |  | $ | 109,887 |  |  | $ | 51,591 |  |
| Enterprise Networks |  |  | 28,842 |  |  |  | 16,437 |  |  |  | 33,126 |  |  |  | 18,086 |  |
| Total |  | $ | 147,004 |  |  | $ | 77,790 |  |  | $ | 143,013 |  |  | $ | 69,677 |  |

[0001193125-14-187120:notes:26]
[same as prior period, unchanged from 0001193125-13-422365:notes:29]

[0001193125-14-187120:notes:27]
[same as prior period, unchanged from 0001193125-13-422365:notes:30]

[0001193125-14-187120:notes:28]
Carrier Systems products are used by communications service
 providers to provide data, voice and video services to consumers
 and enterprises. This category includes the following product areas
 and related services:

[0001193125-14-187120:notes:29]
[same as prior period, unchanged from 0001193125-13-422365:notes:32]

[0001193125-14-187120:notes:30]
|  | • |  | Total Access® 5000 Multi-Service Access Node (MSAN) |

[0001193125-14-187120:notes:31]
|  | • |  | hiX family of MSANs |

[0001193125-14-187120:notes:32]
[same as prior period, unchanged from 0001193125-13-422365:notes:35]

[0001193125-14-187120:notes:33]
[same as prior period, unchanged from 0001193125-13-422365:notes:36]

[0001193125-14-187120:notes:34]
[same as prior period, unchanged from 0001193125-13-422365:notes:37]

[0001193125-14-187120:notes:35]
[same as prior period, unchanged from 0001193125-13-422365:notes:38]

[0001193125-14-187120:notes:36]
[same as prior period, unchanged from 0001193125-13-422365:notes:39]

[0001193125-14-187120:notes:37]
|  | • |  | NetVanta 8000 Series of Fiber Ethernet Access Devices (EAD) |

[0001193125-14-187120:notes:38]
|  | • |  | OPTI-6100 and Total Access 3000 optical Multi-Service Provisioning Platforms (MSPP) |

[0001193125-14-187120:notes:39]
|  | • |  | Pluggable Optical Products, including SFP, XFP, and SFP+ |

[0001193125-14-187120:notes:40]
[same as prior period, unchanged from 0001193125-13-422365:notes:43]

[0001193125-14-187120:notes:41]
Business Networking products provide access to communication
 services and facilitate the delivery of cloud connectivity and
 enterprise communications to the small and mid-sized enterprise
 (SME) market. This category includes the following product areas
 and related services:

[0001193125-14-187120:notes:42]
[same as prior period, unchanged from 0001193125-13-422365:notes:46]

[0001193125-14-187120:notes:43]
[same as prior period, unchanged from 0001193125-13-422365:notes:47]

[0001193125-14-187120:notes:44]
[same as prior period, unchanged from 0001193125-13-422365:notes:48]

[0001193125-14-187120:notes:45]
|  | • |  | Bluesocket® virtual Wireless LAN (vWLAN®) |

[0001193125-14-187120:notes:46]
[same as prior period, unchanged from 0001193125-13-422365:notes:50]

[0001193125-14-187120:notes:47]
[same as prior period, unchanged from 0001193125-13-422365:notes:51]

[0001193125-14-187120:notes:48]
[same as prior period, unchanged from 0001193125-13-422365:notes:52]

[0001193125-14-187120:notes:49]
[same as prior period, unchanged from 0001193125-13-422365:notes:53]

[0001193125-14-187120:notes:50]
[same as prior period, unchanged from 0001193125-13-422365:notes:54]

[0001193125-14-187120:notes:51]
[same as prior period, unchanged from 0001193125-13-422365:notes:55]

[0001193125-14-187120:notes:52]
[same as prior period, unchanged from 0001193125-13-422365:notes:44]

[0001193125-14-187120:notes:53]
[same as prior period, unchanged from 0001193125-13-422365:notes:56]

[0001193125-14-187120:notes:54]
Loop Access products are used by carrier and enterprise
 customers for access to copper-based communications networks. The
 Loop Access category includes the following product areas and
 related services:

[0001193125-14-187120:notes:55]
[same as prior period, unchanged from 0001193125-13-422365:notes:58]

[0001193125-14-187120:notes:56]
[same as prior period, unchanged from 0001193125-13-422365:notes:59]

[0001193125-14-187120:notes:57]
[same as prior period, unchanged from 0001193125-13-422365:notes:60]

[0001193125-14-187120:notes:58]
[same as prior period, unchanged from 0001193125-13-422365:notes:61]

[0001193125-14-187120:notes:59]
[same as prior period, unchanged from 0001193125-13-422365:notes:62]

[0001193125-14-187120:notes:60]
The table below presents sales information by product category for
 the three months ended March 31, 2014 and 2013:

[0001193125-14-187120:notes:61]
|  |  | Three Months Ended March 31, |  |
| (In thousands) |  | 2014 |  |  | 2013 |  |
| Carrier Systems |  | $ | 99,553 |  |  | $ | 92,804 |  |
| Business Networking |  |  | 37,919 |  |  |  | 38,076 |  |
| Loop Access |  |  | 9,532 |  |  |  | 12,133 |  |
| Total |  | $ | 147,004 |  |  | $ | 143,013 |  |

[0001193125-14-187120:notes:62]
In addition, we identify subcategories of product revenues, which
 we divide into core products and legacy products. Our core products
 consist of Broadband Access and Optical products (included in
 Carrier Systems), and Internetworking products (included in
 Business Networking). Our legacy products include HDSL products
 (included in Loop Access) and other products not included in the
 aforementioned core products.

[0001193125-14-187120:notes:63]
The table below presents subcategory revenues for the three months
 ended March 31, 2014 and 2013:

[0001193125-14-187120:notes:64]
|  |  | Three Months Ended March 31, |  |
| (In thousands) |  | 2014 |  |  | 2013 |  |
| Core Products |  |  |  |  |  |  |  |  |
| Broadband Access (included in Carrier Systems) |  | $ | 81,527 |  |  | $ | 72,234 |  |
| Optical (included in Carrier Systems) |  |  | 12,789 |  |  |  | 8,874 |  |
| Internetworking (included in Business Networking) |  |  | 36,946 |  |  |  | 36,912 |  |
| Subtotal |  |  | 131,262 |  |  |  | 118,020 |  |
| Legacy Products |  |  |  |  |  |  |  |  |
| HDSL (does not include T1) (included in Loop Access) |  |  | 8,877 |  |  |  | 11,407 |  |
| Other products (excluding HDSL) |  |  | 6,865 |  |  |  | 13,586 |  |
| Subtotal |  |  | 15,742 |  |  |  | 24,993 |  |
| Total |  | $ | 147,004 |  |  | $ | 143,013 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-14-187120:notes:65]
14. COMMITMENTS AND CONTINGENCIES

[0001193125-14-187120:notes:66]
In the ordinary course of business, we may be subject to various
 legal proceedings and claims, including employment disputes, patent
 claims, disputes over contract agreements and other commercial
 disputes. In some cases, claimants seek damages or other relief,
 such as royalty payments related to patents, which, if granted,
 could require significant expenditures. Although the outcome of any
 claim or litigation can never be certain, it is our opinion that
 the outcome of all contingencies of which we are currently aware
 will not materially affect our business, operations, financial
 condition or cash flows.

[0001193125-14-187120:notes:67]
We have committed to invest up to an aggregate of $7.9 million in
 two private equity funds, and we have contributed $8.4 million as
 of March 31, 2014, of which $7.7 million has been applied to
 these commitments.


## us-gaap:ScheduleOfDerivativeInstrumentsInStatementOfFinancialPositionFairValueTextBlock

[0001193125-14-187120:notes:68]
The fair values of our derivative instruments recorded in the
 Consolidated Balance Sheet as of March 31, 2014 and
 December 31, 2013 were as follows:

[0001193125-14-187120:notes:69]
| (In thousands) |  | Balance Sheet Location |  | March 31, 2014 |  |  | December 31, 2013 |  |
| Derivatives Not Designated as Hedging Instruments (Level 2): |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts – asset derivatives |  | Other receivables |  | $ | 1 |  |  | $ | 18 |  |
| Foreign exchange contracts – liability derivatives |  | Accounts payable |  | $ | (8 | ) |  | $ | (15 | ) |


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001193125-14-187120:notes:70]
The following tables present changes in accumulated other
 comprehensive income, net of tax, by component for the three months
 ended March 31, 2014 and 2013:

[0001193125-14-187120:notes:71]
|  |  | Three Months Ended March 31, 2014 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | Total |  |
| Beginning balance |  | $ | 10,737 |  |  | $ | (891 | ) |  | $ | 907 |  |  | $ | 10,753 |  |
| Other comprehensive income (loss) before reclassifications |  |  | 402 |  |  |  | — |  |  |  | 252 |  |  |  | 654 |  |
| Amounts reclassified from accumulated other comprehensive income |  |  | (1,323 | ) |  |  | — |  |  |  | — |  |  |  | (1,323 | ) |
| Net current period other comprehensive income (loss) |  |  | (921 | ) |  |  | — |  |  |  | 252 |  |  |  | (669 | ) |
| Ending balance |  | $ | 9,816 |  |  | $ | (891 | ) |  | $ | 1,159 |  |  | $ | 10,084 |  |

[0001193125-14-187120:notes:72]
|  |  | Three Months Ended March 31, 2013 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | Total |  |
| Beginning balance |  | $ | 10,108 |  |  | $ | (1,952 | ) |  | $ | 3,112 |  |  | $ | 11,268 |  |
| Other comprehensive income (loss) before reclassifications |  |  | 454 |  |  |  | — |  |  |  | 323 |  |  |  | 777 |  |
| Amounts reclassified from accumulated other comprehensive income |  |  | (2,098 | ) |  |  | — |  |  |  | — |  |  |  | (2,098 | ) |
| Net current period other comprehensive income (loss) |  |  | (1,644 | ) |  |  | — |  |  |  | 323 |  |  |  | (1,321 | ) |
| Ending balance |  | $ | 8,464 |  |  | $ | (1,952 | ) |  | $ | 3,435 |  |  | $ | 9,947 |  |


## us-gaap:ScheduleofFiniteLivedIntangibleAssetsFutureAmortizationExpenseTableTextBlock

[0001193125-14-187120:notes:73]
As of March 31, 2014, the estimated future amortization
 expense of our intangible assets is as follows:

[0001193125-14-187120:notes:74]
| (In thousands) |  | Amount |  |
| Remainder of 2014 |  | $ | 1,718 |  |
| 2015 |  |  | 2,168 |  |
| 2016 |  |  | 1,893 |  |
| 2017 |  |  | 1,290 |  |
| 2018 |  |  | 782 |  |
| Thereafter |  |  | 2,009 |  |
| Total |  | $ | 9,860 |  |


## us-gaap:ScheduleOfCostsOfRetirementPlansTableTextBlock

[0001193125-14-187120:notes:75]
The following table summarizes the components of net periodic
 pension cost for the three months ended March 31, 2014 and
 2013:

[0001193125-14-187120:notes:76]
|  |  | Three Months Ended March 31, |  |
| (In thousands) |  | 2014 |  |  | 2013 |  |
| Service cost |  | $ | 305 |  |  | $ | 300 |  |
| Interest cost |  |  | 215 |  |  |  | 187 |  |
| Expected return on plan assets |  |  | (279 | ) |  |  | (253 | ) |
| Net periodic pension cost |  | $ | 241 |  |  | $ | 234 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001193125-14-187120:notes:77]
We have categorized our cash equivalents held in money market funds
 and our investments held at fair value into a three-level fair
 value hierarchy based on the priority of the inputs to the
 valuation technique for the cash equivalents and investments as
 follows: Level 1—Values based on unadjusted quoted prices for
 identical assets or liabilities in an active market; Level
 2—Values based on quoted prices in markets that are not
 active or model inputs that are observable either directly or
 indirectly; Level 3—Values based on prices or valuation
 techniques that require inputs that are both unobservable and
 significant to the overall fair value measurement. These inputs
 include information supplied by investees.

[0001193125-14-187120:notes:78]
|  |  | Fair Value Measurements at March 31, 2014 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 11,742 |  |  | $ | 11,742 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 15,277 |  |  |  | 15,277 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 130,863 |  |  |  | — |  |  |  | 130,863 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 158,387 |  |  |  | — |  |  |  | 158,387 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 24,840 |  |  |  | — |  |  |  | 24,840 |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity securities – technology industry |  |  | 10,639 |  |  |  | 10,639 |  |  |  | — |  |  |  | — |  |
| Equity securities – other |  |  | 26,947 |  |  |  | 26,947 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 366,953 |  |  |  | 52,863 |  |  |  | 314,090 |  |  |  | — |  |
| Total |  | $ | 378,695 |  |  | $ | 64,605 |  |  | $ | 314,090 |  |  | $ | — |  |
|  |  | Fair Value Measurements at December 31, 2013 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 3,949 |  |  | $ | 3,949 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 15,123 |  |  |  | 15,123 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 166,859 |  |  |  | — |  |  |  | 166,859 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 136,302 |  |  |  | — |  |  |  | 136,302 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 8,310 |  |  |  | — |  |  |  | 8,310 |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity securities – technology industry |  |  | 11,398 |  |  |  | 11,398 |  |  |  | — |  |  |  | — |  |
| Equity securities – other |  |  | 27,054 |  |  |  | 27,054 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 365,046 |  |  |  | 53,575 |  |  |  | 311,471 |  |  |  | — |  |
| Total |  | $ | 368,995 |  |  | $ | 57,524 |  |  | $ | 311,471 |  |  | $ | — |  |


## us-gaap:ScheduleOfStockholdersEquityTableTextBlock

[0001193125-14-187120:notes:79]
A summary of the changes in stockholders’ equity for the
 three months ended March 31, 2014 is as follows:

[0001193125-14-187120:notes:80]
|  |  | Stockholders’ |  |
| (In thousands) |  | Equity |  |
| Balance, December 31, 2013 |  | $ | 604,606 |  |
| Net income |  |  | 9,607 |  |
| Dividend payments |  |  | (5,102 | ) |
| Dividends accrued for unvested restricted stock units |  |  | 6 |  |
| Net unrealized gains (losses) on available-for-sale securities (net of tax) |  |  | (921 | ) |
| Foreign currency translation adjustment |  |  | 252 |  |
| Proceeds from stock option exercises |  |  | 1,541 |  |
| Purchase of treasury stock |  |  | (9,427 | ) |
| Income tax benefit from exercise of stock options |  |  | 57 |  |
| Stock-based compensation expense |  |  | 2,057 |  |
| Balance, March 31, 2014 |  | $ | 602,676 |  |


## us-gaap:ConsolidationPolicyTextBlock

[0001193125-14-187120:notes:81]
Basis of Presentation

[0001193125-14-187120:notes:82]
The accompanying unaudited consolidated financial statements of
 ADTRAN®, Inc. and its
 subsidiaries (ADTRAN) have been prepared pursuant to the rules and
 regulations for reporting on Quarterly Reports on Form 10-Q.
 Accordingly, certain information and notes required by generally
 accepted accounting principles for complete financial statements
 are not included herein. The December 31, 2013 Consolidated
 Balance Sheet is derived from audited financial statements, but
 does not include all disclosures required by accounting principles
 generally accepted in the United States.

[0001193125-14-187120:notes:83]
In the opinion of management, all adjustments necessary for a fair
 presentation of these interim statements have been recorded and are
 of a normal and recurring nature. The results of operations for an
 interim period are not necessarily indicative of the results for
 the full year. The interim statements should be read in conjunction
 with the financial statements and notes thereto included in
 ADTRAN’s Annual Report on Form 10-K for the year ended
 December 31, 2013, filed on February 27, 2014 with the
 SEC.


## us-gaap:InventoryDisclosureTextBlock

[0001193125-14-187120:notes:84]
7. INVENTORY

[0001193125-14-187120:notes:85]
At March 31, 2014 and December 31, 2013, inventory
 consisted of the following:

[0001193125-14-187120:notes:86]
|  |  | March 31, |  |  | December 31, |  |
| (In thousands) |  | 2014 |  |  | 2013 |  |
| Raw materials |  | $ | 41,546 |  |  | $ | 44,093 |  |
| Work in process |  |  | 3,217 |  |  |  | 3,484 |  |
| Finished goods |  |  | 42,633 |  |  |  | 42,534 |  |
| Total |  | $ | 87,396 |  |  | $ | 90,111 |  |

[0001193125-14-187120:notes:87]
We establish reserves for estimated excess, obsolete, or
 unmarketable inventory equal to the difference between the cost of
 the inventory and the estimated fair value of the inventory based
 upon assumptions about future demand and market conditions. At
 March 31, 2014 and December 31, 2013, raw materials
 reserves totaled $17.0 million and $16.9 million, respectively, and
 finished goods inventory reserves totaled $4.9 million and $6.1
 million, respectively. The decrease in finished goods inventory
 reserve from December 31, 2013 to March 31, 2014 is primarily
 attributable to the disposal of inventory that was fully
 reserved.


## us-gaap:ScheduleOfEarningsPerShareBasicAndDilutedTableTextBlock

[0001193125-14-187120:notes:88]
A summary of the calculation of basic and diluted earnings per
 share for the three months ended March 31, 2014 and 2013 is as
 follows:

[0001193125-14-187120:notes:89]
|  |  | Three Months Ended March 31, |  |
| (In thousands, except per share amounts) |  | 2014 |  |  | 2013 |  |
| Numerator |  |  |  |  |  |  |  |  |
| Net income |  | $ | 9,607 |  |  | $ | 7,890 |  |
| Denominator |  |  |  |  |  |  |  |  |
| Weighted average number of shares – basic |  |  | 56,751 |  |  |  | 61,847 |  |
| Effect of dilutive securities |  |  |  |  |  |  |  |  |
| Stock options |  |  | 602 |  |  |  | 162 |  |
| Restricted stock and restricted stock units |  |  | 15 |  |  |  | 21 |  |
| Weighted average number of shares – diluted |  |  | 57,368 |  |  |  | 62,030 |  |
| Net income per share – basic |  | $ | 0.17 |  |  | $ | 0.13 |  |
| Net income per share – diluted |  | $ | 0.17 |  |  | $ | 0.13 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001193125-14-187120:notes:90]
9. STOCKHOLDERS’ EQUITY

[0001193125-14-187120:notes:91]
[same as prior period, unchanged from 0001193125-13-422365:notes:102]

[0001193125-14-187120:notes:92]
Since 1997, our Board of Directors has approved multiple share
 repurchase programs that have authorized open market repurchase
 transactions of up to 40.0 million shares of our common stock.
 During the three months ended March 31, 2014, we repurchased
 0.4 million shares of our common stock at an average price of
 $25.13 per share. We currently have the authority to purchase an
 additional 3.1 million shares of our common stock under the
 current plan approved by the Board of Directors on May 1,
 2013.

[0001193125-14-187120:notes:93]
[same as prior period, unchanged from 0001193125-13-422365:notes:105]

[0001193125-14-187120:notes:94]
We issued 0.1 million shares of treasury stock during the
 three months ended March 31, 2014 to accommodate employee
 stock option exercises. The stock options had exercise prices
 ranging from $15.29 to $23.46. We received proceeds totaling $1.5
 million from the exercise of these stock options during the three
 months ended March 31, 2014.

[0001193125-14-187120:notes:95]
[same as prior period, unchanged from 0001193125-13-422365:notes:107]

[0001193125-14-187120:notes:96]
During the three months ended March 31, 2014, we paid cash
 dividends as follows (in thousands except per share amounts):

[0001193125-14-187120:notes:97]
| Record Date |  | Payment Date |  |  | Per Share Amount |  |  | Total Dividend Paid |  |
| February 6, 2014 |  |  | February 20, 2014 |  |  | $ | 0.09 |  |  | $ | 5,102 |  |

[0001193125-14-187120:notes:98]
[same as prior period, unchanged from 0001193125-13-422365:notes:110]

[0001193125-14-187120:notes:99]
[same as prior period, unchanged from 0001193125-13-422365:notes:111]

[0001193125-14-187120:notes:100]
The following tables present the details of reclassifications out
 of accumulated other comprehensive income for the three months
 ended March 31, 2014 and 2013:

[0001193125-14-187120:notes:101]
| (In thousands) |  | Three Months Ended March 31, 2014 |
| Details about Accumulated Other Comprehensive Income Components |  | Amount Reclassified from Accumulated Other Comprehensive Income |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for-sale securities: |  |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 2,170 |  |  | Net realized investment gain |
| Impairment expense |  |  | — |  |  | Net realized investment gain |
| Total reclassifications for the period, before tax |  |  | 2,170 |  |  |  |
| Tax (expense) benefit |  |  | (847 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 1,323 |  |  |  |

[0001193125-14-187120:notes:102]
| (In thousands) |  | Three Months Ended March 31, 2013 |
| Details about Accumulated Other Comprehensive Income Components |  | Amount Reclassified from Accumulated Other Comprehensive Income |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for-sale securities: |  |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 3,444 |  |  | Net realized investment gain |
| Impairment expense |  |  | (4 | ) |  | Net realized investment gain |
| Total reclassifications for the period, before tax |  |  | 3,440 |  |  |  |
| Tax (expense) benefit |  |  | (1,342 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 2,098 |  |  |  |

[0001193125-14-187120:notes:103]
The following table presents the tax effects related to the change
 in each component of other comprehensive income for the three
 months ended March 31, 2014 and 2013:

[0001193125-14-187120:notes:104]
|  |  | Three Months Ended March 31, 2014 |  |  | Three Months Ended March 31, 2013 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |
| Unrealized gains (losses) on available-for-sale securities |  | $ | 659 |  |  | $ | (257 | ) |  | $ | 402 |  |  | $ | 744 |  |  | $ | (290 | ) |  | $ | 454 |  |
| Reclassification adjustment for amounts included in net income |  |  | (2,170 | ) |  |  | 847 |  |  |  | (1,323 | ) |  |  | (3,440 | ) |  |  | 1,342 |  |  |  | (2,098 | ) |
| Foreign currency translation adjustment |  |  | 252 |  |  |  | — |  |  |  | 252 |  |  |  | 323 |  |  |  | — |  |  |  | 323 |  |
| Total Other Comprehensive Income (Loss) |  | $ | (1,259 | ) |  | $ | 590 |  |  | $ | (669 | ) |  | $ | (2,373 | ) |  | $ | 1,052 |  |  | $ | (1,321 | ) |


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001193125-14-187120:notes:105]
As of March 31, 2014, our corporate bonds and municipal
 fixed-rate bonds had the following contractual maturities:

[0001193125-14-187120:notes:106]
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |
| Less than one year |  | $ | 34,248 |  |  | $ | 34,630 |  |
| One to two years |  |  | 52,222 |  |  |  | 60,991 |  |
| Two to three years |  |  | 44,393 |  |  |  | 47,713 |  |
| Three to five years |  |  | — |  |  |  | 15,053 |  |
| Total |  | $ | 130,863 |  |  | $ | 158,387 |  |


## us-gaap:ScheduleOfRealizedGainLossTableTextBlock

[0001193125-14-187120:notes:107]
The following table presents gross realized gains and losses
 related to our investments.

[0001193125-14-187120:notes:108]
|  |  | Three Months Ended March 31, |  |
| (In thousands) |  | 2014 |  |  | 2013 |  |
| Gross realized gains |  | $ | 2,228 |  |  | $ | 3,727 |  |
| Gross realized losses |  | $ | (36 | ) |  | $ | (82 | ) |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001193125-14-187120:notes:109]
6. DERIVATIVE INSTRUMENTS AND HEDGING ACTIVITIES

[0001193125-14-187120:notes:110]
[same as prior period, unchanged from 0001193125-13-422365:notes:130]

[0001193125-14-187120:notes:111]
As of March 31, 2014, we had forward contracts outstanding
 with notional amounts totaling €20.7 million ($28.5
 million), which mature through 2014.

[0001193125-14-187120:notes:112]
The change in the fair values of our derivative instruments
 recorded in the Consolidated Statements of Income during the three
 months ended March 31, 2014 were as follows:

[0001193125-14-187120:notes:113]
|  |  |  |  | Three Months Ended |  |
| (In thousands) |  | Income Statement Location |  | March 31, 2014 |  |  | March 31, 2013 |  |
| Derivatives Not Designated as Hedging Instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Other income (expense) |  | $ | (110 | ) |  | $ | (224 | ) |


## us-gaap:ScheduleOfGoodwillTextBlock

[0001193125-14-187120:notes:114]
The change in the carrying value of goodwill, all of which is
 included in our Enterprise Networks division, for the three months
 ended March 31, 2014 is as follows:

[0001193125-14-187120:notes:115]
| (In thousands) |  |  |  |
| Balance, December 31, 2013 |  | $ | 3,492 |  |
| Acquisitions |  |  | — |  |
| Impairment losses |  |  | — |  |
| Balance, March 31, 2014 |  | $ | 3,492 |  |
| Balance as of March 31, 2014 |  |  |  |  |
| Goodwill |  | $ | 3,492 |  |
| Accumulated impairment losses |  |  | — |  |
| Total goodwill |  | $ | 3,492 |  |


## us-gaap:SubsequentEventsTextBlock

[0001193125-14-187120:notes:116]
15. SUBSEQUENT EVENTS

[0001193125-14-187120:notes:117]
On April 15, 2014, we announced that our Board of Directors
 declared a quarterly cash dividend of $0.09 per common share to be
 paid to stockholders of record at the close of business on
 May 1, 2014. The payment date will be May 15, 2014. The
 quarterly dividend payment will be approximately $5.0 million. In
 July 2003, our Board of Directors elected to begin declaring
 quarterly dividends on our common stock considering the tax
 treatment of dividends and adequate levels of Company
 liquidity.

[0001193125-14-187120:notes:118]
During the second quarter and as of May 7, 2014, we have
 repurchased 1.3 million shares of our common stock through
 open market purchases at an average cost of $22.63 per share. We
 currently have the authority to purchase an additional 1.8 million
 shares of our common stock under the current plan approved by the
 Board of Directors.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-14-187120:notes:119]
2. INCOME TAXES

[0001193125-14-187120:notes:120]
Our effective tax rate increased from 18.9% in the three months
 ended March 31, 2013 to 34.6% in the three months ended
 March 31, 2014. The increase in the effective tax rate between
 the two periods is primarily attributable to the net effect of
 recording the benefit for the research tax credit for the 2012 tax
 year in January 2013 pursuant to the American Taxpayer Relief Act
 of 2012, and the inclusion of the benefit of the estimated 2013
 research tax credit in the estimated annual effective rate for
 2013. Additionally, the effective tax rate in the first quarter of
 2014 did not include a benefit for the research tax credit, which
 expired on December 31, 2013. This increase was partially
 offset


## us-gaap:ScheduleOfAvailableForSaleSecuritiesReconciliationTableTextBlock

[0001193125-14-187120:notes:121]
At March 31, 2014, we held the following securities and
 investments, recorded at either fair value or cost.

[0001193125-14-187120:notes:122]
| (In thousands) |  | Amortized Cost |  |  | Gross Unrealized |  |  | Carrying Value |  |
|  |  | Gains |  |  | Losses |  |  |
| Deferred compensation plan assets |  | $ | 12,523 |  |  | $ | 2,770 |  |  | $ | (16 | ) |  | $ | 15,277 |  |
| Corporate bonds |  |  | 130,437 |  |  |  | 456 |  |  |  | (30 | ) |  |  | 130,863 |  |
| Municipal fixed-rate bonds |  |  | 157,851 |  |  |  | 673 |  |  |  | (137 | ) |  |  | 158,387 |  |
| Municipal variable rate demand notes |  |  | 24,840 |  |  |  | — |  |  |  | — |  |  |  | 24,840 |  |
| Marketable equity securities |  |  | 25,166 |  |  |  | 12,798 |  |  |  | (378 | ) |  |  | 37,586 |  |
| Available-for-sale securities held at fair value |  | $ | 350,817 |  |  | $ | 16,697 |  |  | $ | (561 | ) |  | $ | 366,953 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 30,000 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1,659 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 398,612 |  |

[0001193125-14-187120:notes:123]
At December 31, 2013, we held the following securities and
 investments, recorded at either fair value or cost.

[0001193125-14-187120:notes:124]
| (In thousands) |  | Amortized Cost |  |  | Gross Unrealized |  |  | Carrying Value |  |
|  |  | Gains |  |  | Losses |  |  |
| Deferred compensation plan assets |  | $ | 12,300 |  |  | $ | 2,847 |  |  | $ | (24 | ) |  | $ | 15,123 |  |
| Corporate bonds |  |  | 166,370 |  |  |  | 534 |  |  |  | (45 | ) |  |  | 166,859 |  |
| Municipal fixed-rate bonds |  |  | 135,773 |  |  |  | 583 |  |  |  | (54 | ) |  |  | 136,302 |  |
| Municipal variable rate demand notes |  |  | 8,310 |  |  |  | — |  |  |  | — |  |  |  | 8,310 |  |
| Marketable equity securities |  |  | 24,654 |  |  |  | 13,975 |  |  |  | (177 | ) |  |  | 38,452 |  |
| Available-for-sale securities held at fair value |  | $ | 347,407 |  |  | $ | 17,939 |  |  | $ | (300 | ) |  | $ | 365,046 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 48,250 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1,689 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 414,985 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001193125-14-187120:notes:125]
3. PENSION BENEFIT PLAN

[0001193125-14-187120:notes:126]
We maintain a defined benefit pension plan covering employees in
 certain foreign countries.


## us-gaap:EarningsPerShareTextBlock

[0001193125-14-187120:notes:127]
10. EARNINGS PER SHARE

[0001193125-14-187120:notes:128]
Anti-dilutive options to purchase common stock outstanding were
 excluded from the above calculations. Anti-dilutive options totaled
 3.1 million and 5.4 million for the three months ended
 March 31, 2014 and 2013, respectively.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001193125-14-187120:notes:129]
13. RELATED PARTY TRANSACTIONS

[0001193125-14-187120:notes:130]
We employ the law firm of our director emeritus for legal services.
 All bills for services rendered by this firm are reviewed and
 approved by our Chief Financial Officer. We believe that the fees
 for such services are comparable to those charged by other firms
 for services rendered to us. For the three months ended
 March 31, 2014 and 2013, we incurred fees of $10 thousand per
 month for these legal services.


## us-gaap:ScheduleOfFiniteLivedIntangibleAssetsTableTextBlock

[0001193125-14-187120:notes:131]
The following table presents our intangible assets as of
 March 31, 2014 and December 31, 2013:

[0001193125-14-187120:notes:132]
| (In thousands) |  | March 31, 2014 |  |  | December 31, 2013 |  |
|  | Gross Value |  |  | Accumulated Amortization |  |  | Net Value |  |  | Gross Value |  |  | Accumulated Amortization |  |  | Net Value |  |
| Customer relationships |  | $ | 6,963 |  |  | $ | (1,742 | ) |  | $ | 5,221 |  |  | $ | 6,996 |  |  | $ | (1,555 | ) |  | $ | 5,441 |  |
| Developed technology |  |  | 6,392 |  |  |  | (2,939 | ) |  |  | 3,453 |  |  |  | 6,537 |  |  |  | (2,692 | ) |  |  | 3,845 |  |
| Intellectual property |  |  | 2,340 |  |  |  | (1,269 | ) |  |  | 1,071 |  |  |  | 2,340 |  |  |  | (1,185 | ) |  |  | 1,155 |  |
| Trade names |  |  | 270 |  |  |  | (160 | ) |  |  | 110 |  |  |  | 270 |  |  |  | (145 | ) |  |  | 125 |  |
| Other |  |  | 14 |  |  |  | (9 | ) |  |  | 5 |  |  |  | 14 |  |  |  | (8 | ) |  |  | 6 |  |
| Total |  | $ | 15,979 |  |  | $ | (6,119 | ) |  | $ | 9,860 |  |  | $ | 16,157 |  |  | $ | (5,585 | ) |  | $ | 10,572 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001193125-14-187120:notes:133]
1. SUMMARY OF SIGNIFICANT ACCOUNTING POLICIES

[0001193125-14-187120:notes:134]
[same as prior period, unchanged from 0001193125-13-422365:notes:171]

[0001193125-14-187120:notes:135]
We corrected immaterial misclassifications between the operating
 and investing sections of our consolidated statements of cash flows
 and adjusted our cash flows for the three months ended
 March 31, 2013 in these categories by $0.1 million in order to
 be consistent with the 2014 presentation.

[0001193125-14-187120:notes:136]
[same as prior period, unchanged from 0001193125-13-422365:notes:173]

[0001193125-14-187120:notes:137]
During the year ended December 31, 2013, we identified two
 adjustments in the acquired NSN (formerly Nokia Siemens Networks)
 Broadband Access business (NSN BBA business) relating to customer
 payment discounts for one customer, and recoverable VAT taxes on
 certain vendor freight invoices that should have been recorded in
 prior periods. These adjustments resulted from a $0.3 million
 understatement of net income in the first quarter of 2013. We
 evaluated the impact of the adjustments on the results of our
 previously issued financial statements for first quarter of 2013
 and concluded that the impact was not material. We also evaluated
 the impact of the cumulative effect of the adjustments in 2013 and
 concluded that the impact was not material to our results for
 the year 2013. Accordingly, during the three months ended
 September 30, 2013 we recorded an out of period adjustment to
 correct these issues.

[0001193125-14-187120:notes:138]
[same as prior period, unchanged from 0001193125-13-422365:notes:175]

[0001193125-14-187120:notes:139]
The preparation of financial statements in conformity with
 accounting principles generally accepted in the United States of
 America requires management to make estimates and assumptions that
 affect the reported amounts of assets and liabilities, the
 disclosure of contingent assets and liabilities at the date of the
 financial statements, and the reported amounts of revenue and
 expense during the reporting period. Our more significant estimates
 include the obsolete and excess inventory reserves, warranty
 reserves, customer rebates, determination of the deferred revenue
 components of multiple element sales agreements, estimated costs to
 complete obligations associated with deferred revenues, estimated
 income tax provision and income tax contingencies, the fair value
 of stock-based compensation, impairment of goodwill, valuation and
 estimated lives of intangible assets, estimated working capital
 adjustments under negotiation related to the NSN BBA business
 acquisition, estimated pension liability, fair value of
 investments, and the evaluation of other-than-temporary declines in
 the value of investments. Actual amounts could differ significantly
 from these estimates.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001193125-14-187120:notes:140]
5. INVESTMENTS

[0001193125-14-187120:notes:141]
Our investment policy provides limitations for issuer
 concentration, which limits, at the time of purchase, the
 concentration in any one issuer to 5% of the market value of our
 total investment portfolio.

[0001193125-14-187120:notes:142]
At March 31, 2014, we held a $30.0 million restricted
 certificate of deposit, which is carried at cost. This investment
 serves as a collateral deposit against the principal amount
 outstanding under loans made to ADTRAN pursuant to an Alabama State
 Industrial Development Authority revenue bond (the Bond). During
 the first quarter of 2014, we made a principal payment on the Bond
 of $16.5 million. At March 31, 2014, the estimated fair value
 of the Bond using a level 2 valuation technique was approximately
 $29.6 million, based on a debt security with a comparable interest
 rate and maturity and a Standard and Poor’s credit rating of
 AAA-. For more information on the Bond, see “Debt”
 under “Liquidity and Capital Resources” in the
 “Management’s Discussion and Analysis of Financial
 Condition and Results of Operations” contained in Item 2
 of Part I of this report.

[0001193125-14-187120:notes:143]
We review our investment portfolio for potential
 “other-than-temporary” declines in value on an
 individual investment basis. We assess, on a quarterly basis,
 significant declines in value which may be considered
 other-than-temporary and, if necessary, recognize and record the
 appropriate charge to write-down the carrying value of such
 investments. In making this assessment, we take into consideration
 qualitative and quantitative information, including but not limited
 to the following: the magnitude and duration of historical declines
 in market prices, credit rating activity, assessments of liquidity,
 public filings, and statements made by the issuer. We generally
 begin our identification of potential other-than-temporary
 impairments by reviewing any security with a fair value that has
 declined from its original or adjusted cost basis by 25% or more
 for six or more consecutive months. We then evaluate the individual
 security based on the previously identified factors to determine
 the amount of the write-down, if any. As a result of our review, we
 recorded no other-than-temporary impairment charges during the
 three months ended March 31, 2014. For the three months ended
 March 31, 2013, we recorded an other-than-temporary impairment
 charge of $4 thousand related to one marketable equity
 security.

[0001193125-14-187120:notes:144]
Realized gains and losses on sales of securities are computed under
 the specific identification method. The following table presents
 gross realized gains and losses related to our investments.

[0001193125-14-187120:notes:145]
As of March 31, 2014 and 2013, gross unrealized losses related
 to individual securities in a continuous loss position for 12
 months or longer were not significant.

[0001193125-14-187120:notes:146]
The fair value of our Level 2 securities is calculated using a
 weighted average market price for each security. Market prices are
 obtained from a variety of industry standard data providers,
 security master files from large financial institutions, and other
 third-party sources. These multiple market prices are used as
 inputs into a distribution-curve-based algorithm to determine the
 daily market value of each security.

[0001193125-14-187120:notes:147]
Our municipal variable rate demand notes have a structure that
 implies a standard expected market price. The frequent interest
 rate resets make it reasonable to expect the price to stay at par.
 These securities are priced at the expected market price.


## us-gaap:GoodwillDisclosureTextBlock

[0001193125-14-187120:notes:148]
8. GOODWILL AND INTANGIBLE ASSETS

[0001193125-14-187120:notes:149]
We evaluate the carrying value of goodwill during the fourth
 quarter of each year and between annual evaluations if events occur
 or circumstances change that would more likely than not reduce the
 fair value of the reporting unit below its carrying amount. When
 evaluating whether goodwill is impaired, we compare the fair value
 of the reporting unit to which the goodwill is assigned to the
 reporting unit’s carrying amount, including goodwill. If the
 carrying amount of the reporting unit exceeds its fair value, then
 the amount of the impairment loss is measured. There were no
 impairment losses recorded during the three months ended
 March 31, 2014 or 2013.

[0001193125-14-187120:notes:150]
Intangible assets are included in other assets in the accompanying
 Consolidated Balance Sheets and include intangibles acquired in
 conjunction with our acquisition of Objectworld Communications
 Corporation on September 15, 2009, Bluesocket, Inc. on
 August 4, 2011, and the NSN BBA business on May 4,
 2012.

[0001193125-14-187120:notes:151]
Amortization expense, all of which relates to business
 acquisitions, was $0.6 million for the three months ended
 March 31, 2014 and 2013.
