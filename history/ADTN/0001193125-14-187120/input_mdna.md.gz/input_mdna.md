# ADTN MD&A — 0001193125-14-187120


## mdna

[0001193125-14-187120:mdna:1]
[same as prior period, unchanged from 0001193125-13-422365:mdna:1]

[0001193125-14-187120:mdna:2]
[same as prior period, unchanged from 0001193125-13-422365:mdna:2]

[0001193125-14-187120:mdna:3]
[same as prior period, unchanged from 0001193125-13-422365:mdna:3]

[0001193125-14-187120:mdna:4]
ADTRAN, Inc. is a leading global provider of networking and communications equipment. Our solutions enable voice, data, video and Internet communications
across a variety of network infrastructures. These solutions are deployed by some of the world’s largest service providers, distributed enterprises and small and medium-sized businesses, public and private enterprises, and millions of
individual users worldwide.

[0001193125-14-187120:mdna:5]
Our success depends upon our ability to increase unit volume and market share through the introduction of new products and
succeeding generations of products having lower selling prices and increased functionality as compared to both the prior generation of a product and to the products of competitors. An important part of our strategy is to reduce the cost of each
succeeding product generation and then lower the product’s selling price based on the cost savings achieved in order to gain market share and/or improve gross margins. As a part of this strategy, we seek in most instances to be a high-quality,
low-cost provider of products in our markets. Our success to date is attributable in large measure to our ability to design our products initially with a view to their subsequent redesign, allowing both increased functionality and reduced
manufacturing costs in each succeeding product generation. This strategy enables us to sell succeeding generations of products to existing customers, while increasing our market share by selling these enhanced products to new customers.

[0001193125-14-187120:mdna:6]
[same as prior period, unchanged from 0001193125-13-422365:mdna:6]

[0001193125-14-187120:mdna:7]
[same as prior period, unchanged from 0001193125-13-422365:mdna:7]

[0001193125-14-187120:mdna:8]
[same as prior period, unchanged from 0001193125-13-422365:mdna:8]

[0001193125-14-187120:mdna:9]
|  | • |  | Total Access® 5000 Multi-Service Access Node (MSAN) |

[0001193125-14-187120:mdna:10]
|  | • |  | hiX family of MSANs |

[0001193125-14-187120:mdna:11]
[same as prior period, unchanged from 0001193125-13-422365:mdna:11]

[0001193125-14-187120:mdna:12]
[same as prior period, unchanged from 0001193125-13-422365:mdna:12]

[0001193125-14-187120:mdna:13]
[same as prior period, unchanged from 0001193125-13-422365:mdna:13]

[0001193125-14-187120:mdna:14]
[same as prior period, unchanged from 0001193125-13-422365:mdna:14]

[0001193125-14-187120:mdna:15]
[same as prior period, unchanged from 0001193125-13-422365:mdna:15]

[0001193125-14-187120:mdna:16]
|  | • |  | NetVanta 8000 Series of Fiber Ethernet Access Devices (EAD) |

[0001193125-14-187120:mdna:17]
|  | • |  | OPTI-6100 and Total Access 3000 optical Multi-Service Provisioning Platforms (MSPP) |

[0001193125-14-187120:mdna:18]
|  | • |  | Pluggable Optical Products, including SFP, XFP, and SFP+ |

[0001193125-14-187120:mdna:19]
[same as prior period, unchanged from 0001193125-13-422365:mdna:19]

[0001193125-14-187120:mdna:20]
Business Networking products provide access to communication services and facilitate the delivery of cloud
connectivity and enterprise communications to the small and mid-sized enterprise (SME) market. This category includes the following product areas and related services:

[0001193125-14-187120:mdna:21]
[same as prior period, unchanged from 0001193125-13-422365:mdna:22]

[0001193125-14-187120:mdna:22]
[same as prior period, unchanged from 0001193125-13-422365:mdna:23]

[0001193125-14-187120:mdna:23]
[same as prior period, unchanged from 0001193125-13-422365:mdna:24]

[0001193125-14-187120:mdna:24]
|  | • |  | Bluesocket® virtual Wireless LAN (vWLAN®) |

[0001193125-14-187120:mdna:25]
[same as prior period, unchanged from 0001193125-13-422365:mdna:26]

[0001193125-14-187120:mdna:26]
[same as prior period, unchanged from 0001193125-13-422365:mdna:27]

[0001193125-14-187120:mdna:27]
[same as prior period, unchanged from 0001193125-13-422365:mdna:28]

[0001193125-14-187120:mdna:28]
[same as prior period, unchanged from 0001193125-13-422365:mdna:29]

[0001193125-14-187120:mdna:29]
[same as prior period, unchanged from 0001193125-13-422365:mdna:30]

[0001193125-14-187120:mdna:30]
[same as prior period, unchanged from 0001193125-13-422365:mdna:31]

[0001193125-14-187120:mdna:31]
[same as prior period, unchanged from 0001193125-13-422365:mdna:20]

[0001193125-14-187120:mdna:32]
[same as prior period, unchanged from 0001193125-13-422365:mdna:33]

[0001193125-14-187120:mdna:33]
Loop Access products are used by carrier and enterprise customers for
access to copper-based communications networks. The Loop Access category includes the following product areas and related services:

[0001193125-14-187120:mdna:34]
[same as prior period, unchanged from 0001193125-13-422365:mdna:35]

[0001193125-14-187120:mdna:35]
[same as prior period, unchanged from 0001193125-13-422365:mdna:36]

[0001193125-14-187120:mdna:36]
[same as prior period, unchanged from 0001193125-13-422365:mdna:37]

[0001193125-14-187120:mdna:37]
[same as prior period, unchanged from 0001193125-13-422365:mdna:38]

[0001193125-14-187120:mdna:38]
[same as prior period, unchanged from 0001193125-13-422365:mdna:39]

[0001193125-14-187120:mdna:39]
In addition, we identify subcategories of product revenues, which we divide
into core products and legacy products. Our core products consist of Broadband Access and Optical products (included in Carrier Systems) and Internetworking products (included in Business Networking). Our legacy products include HDSL products
(included in Loop Access) and other products not included in the aforementioned core products. Many of our customers are migrating their networks to deliver higher bandwidth services by utilizing newer technologies. We believe that products and
services offered in our core product areas position us well for this migration. Despite occasional increases, we anticipate that revenues of many of our legacy products, including HDSL, will decline over time; however, revenues from these products
may continue for years because of the time required for our customers to transition to newer technologies.

[0001193125-14-187120:mdna:40]
See Note 11 of Notes to Consolidated Financial
Statements in this report for further information regarding these product categories.

[0001193125-14-187120:mdna:41]
Sales were $147.0 million for the three months ended March 31,
2014 compared to $143.0 million for the three months ended March 31, 2013. Product revenues for our three core areas, Broadband Access, Optical and Internetworking, were $131.3 million for the three months ended March 31, 2014 compared to
$118.0 million for the three months ended March 31, 2013. Our gross margin increased to 52.9% for the three months ended March 31, 2014 from 48.7% for the three months ended March 31, 2013. Our operating income margin increased to
7.7% for the three months ended March 31, 2014 from 4.6% for the three months ended March 31, 2013. Net income was $9.6 million for the three months ended March 31, 2014 compared to $7.9 million for the three months ended
March 31, 2013. Our effective tax rate increased to 34.6% for the three months ended March 31, 2014 from 18.9% for the three months ended March 31, 2013. Earnings per share, assuming dilution, were $0.17 for the three months ended
March 31, 2014 compared to $0.13 for the three months ended March 31, 2013.

[0001193125-14-187120:mdna:42]
23

[0001193125-14-187120:mdna:43]
[same as prior period, unchanged from 0001193125-13-422365:mdna:44]

[0001193125-14-187120:mdna:44]
[same as prior period, unchanged from 0001193125-13-422365:mdna:45]

[0001193125-14-187120:mdna:45]
Accordingly, our historical financial performance is not necessarily a meaningful indicator of future results, and, in
general, management expects that our financial results may vary from period to period. A list of factors that could materially affect our business, financial condition or operating results is included under “Factors That Could Affect Our Future
Results” in “Management’s Discussion and Analysis of Financial Condition and Results of Operations” contained in Item 2 of Part I of this report. These factors have also been discussed in more detail in Item 1A of Part
I in our most recent Annual Report on Form 10-K for the year ended December 31, 2013, filed on February 27, 2014 with the SEC.

[0001193125-14-187120:mdna:46]
[same as prior period, unchanged from 0001193125-13-422365:mdna:47]

[0001193125-14-187120:mdna:47]
Our critical accounting policies and estimates have not changed significantly from those detailed in our most recent
Annual Report on Form 10-K for the year ended December 31, 2013, filed on February 27, 2014 with the SEC.

[0001193125-14-187120:mdna:48]
[same as prior period, unchanged from 0001193125-13-422365:mdna:49]

[0001193125-14-187120:mdna:49]
[same as prior period, unchanged from 0001193125-13-422365:mdna:50]

[0001193125-14-187120:mdna:50]
RESULTS OF OPERATIONS – THREE MONTHS ENDED MARCH 31, 2014 COMPARED TO THREE MONTHS ENDED MARCH 31, 2013

[0001193125-14-187120:mdna:51]
[same as prior period, unchanged from 0001193125-13-422365:mdna:59]

[0001193125-14-187120:mdna:52]
ADTRAN’s sales increased 2.8% from
$143.0 million in the three months ended March 31, 2013 to $147.0 million in the three months ended March 31, 2014. The increase in sales is primarily attributable to a $9.3 million increase in sales of our Broadband Access products and a
$3.9 million increase in sales of our Optical products, partially offset by a $9.3 million decrease in sales of our HDSL and other legacy products.

[0001193125-14-187120:mdna:53]
Carrier Networks sales increased 7.5% from $109.9 million in the three months ended March 31, 2013 to $118.2
million in the three months ended March 31, 2014. The increase in sales for the three months ended March 31, 2014 is primarily attributable to increases in sales of our Broadband Access products, Optical products, and Internetworking
products, partially offset by decreases in sales of our HDSL and other legacy products. The increase in sales of our Broadband Access products for the three months ended March 31, 2014 is primarily attributable to increases in hiX and FTTN
product sales. The increase in sales of our Optical products for the three months ended March 31, 2014 is primarily attributable to increased shipments of optical products for broadband access and increased shipments of our OPTI-6100 products
for wireless backhaul to a domestic tier 1 carrier. The increase in sales of our Internetworking products for the three months ended March 31, 2014 is primarily attributable to increases in Carrier Ethernet sales and FTTP ONT sales to carriers.
The decrease in sales of HDSL and other legacy products for the three months ended March 31, 2014 has been expected as customers continue to upgrade their networks to deliver higher bandwidth services by migrating to newer technologies,
including to our core products from our Broadband Access, Internetworking and Optical product lines. While we expect that revenues from HDSL and our other legacy products will continue to decline over time, these revenues may continue for years
because of the time required for our customers to transition to newer technologies.

[0001193125-14-187120:mdna:54]
Enterprise Networks sales decreased 12.9% from $33.1 million in the
three months ended March 31, 2013 to $28.8 million in the three months ended March 31, 2014. The decrease in sales for the three months ended March 31, 2014 is primarily attributable to decreases in sales of our Internetworking
products and sales of our legacy products. The decrease in sales of our Internetworking products was primarily attributable to lower sales of products through service provider channels. The decrease in legacy products was expected and discussed
further above. Internetworking product sales attributable to Enterprise Networks were 94.3% of the division’s sales in the three months ended March 31, 2014, compared to 94.1% in the three months ended March 31, 2013. Legacy products
primarily comprise the remainder of Enterprise Networks sales. Enterprise Networks sales as a percentage of total sales decreased from 23.2% for the three months ended March 31, 2013 to 19.6% for the three months ended March 31, 2014.

[0001193125-14-187120:mdna:55]
International sales, which are included in the Carrier Networks and Enterprise Networks amounts discussed above, increased 55.6% from $34.9 million in the
three months ended March 31, 2013 to $54.3 million in the three months ended March 31, 2014. International sales, as a percentage of total sales, increased from 24.4% for the three months ended March 31, 2013 to 36.9% for the three
months ended March 31, 2014. International sales increased in the three months ended March 31, 2014 compared to the three months ended March 31, 2013 primarily due to an increase in sales in the EMEA region and Latin America,
partially offset by a decrease in sales in the Asia-Pacific region.

[0001193125-14-187120:mdna:56]
Carrier System product sales increased $6.7 million in the three months ended
March 31, 2014 compared to the three months ended March 31, 2013. The increase for the three months ended March 31, 2014 is primarily attributable to a $9.3 million increase in Broadband Access product sales, a $3.9 million increase
in Optical product sales, partially offset by a $6.5 million decrease in sales of our legacy products. The changes for the three months ended March 31, 2014 are primarily attributable to the factors discussed above.

[0001193125-14-187120:mdna:57]
Business Networking product sales decreased $0.2 million in the three months ended March 31, 2014 compared to the three months ended March 31, 2013.
The decrease for the three months ended March 31, 2014 is primarily due to a $0.2 million decrease in legacy product sales. The changes for the three months ended March 31, 2014 are primarily attributable to the factors discussed above.

[0001193125-14-187120:mdna:58]
Loop Access product sales decreased $2.6 million in the three months ended March 31, 2014 compared to the three months ended March 31, 2013.
The decrease for the three months ended March 31, 2014 is primarily due to a $2.5 million decrease in HDSL product sales, which is discussed further above.

[0001193125-14-187120:mdna:59]
[same as prior period, unchanged from 0001193125-13-422365:mdna:67]

[0001193125-14-187120:mdna:60]
As a percentage of sales, cost of
sales decreased from 51.3% in the three months ended March 31, 2013 to 47.1% in the three months ended March 31, 2014. The decrease for the three months ended March 31, 2014 is primarily attributable to reduced manufacturing costs and
favorable shifts in product mix.

[0001193125-14-187120:mdna:61]
Carrier Networks cost of sales, as a percent of division sales, decreased from 53.1% in the three months ended
March 31, 2013 to 48.1% in the three months ended March 31, 2014. The decrease for the three months ended March 31, 2014 is primarily attributable to reduced manufacturing costs and favorable shifts in product mix.

[0001193125-14-187120:mdna:62]
Enterprise Networks cost of sales, as a percent of division sales, decreased from 45.4% in the three months ended
March 31, 2013 to 43.0% in the three months ended March 31, 2014. The decrease for the three months ended March 31, 2014 is primarily attributable to reduced manufacturing costs and favorable shifts in product mix.

[0001193125-14-187120:mdna:63]
An important part of our strategy is to reduce the product cost of each succeeding product generation and then to lower the product’s price based on the
cost savings achieved. This may cause variations in our gross profit percentage due to timing differences between the recognition of cost reductions and the lowering of product selling prices.

[0001193125-14-187120:mdna:64]
[same as prior period, unchanged from 0001193125-13-422365:mdna:72]

[0001193125-14-187120:mdna:65]
Selling, general and administrative expenses increased 10.9% from $30.6 million in the three months ended March 31, 2013 to $33.9 million in the three
months ended March 31, 2014. The increase in selling, general and administrative expenses for the three months ended March 31, 2014 is primarily attributable to increases in compensation and fringe benefit costs, legal expenses, travel
expenses and marketing expenses.

[0001193125-14-187120:mdna:66]
Selling, general and administrative expenses as a percentage of sales increased from 21.4% in the three months ended
March 31, 2013 to 23.1% in the three months ended March 31, 2014. Selling, general and administrative expenses as a percentage of sales may fluctuate whenever there is a significant fluctuation in revenues for the periods being compared.

[0001193125-14-187120:mdna:67]
[same as prior period, unchanged from 0001193125-13-422365:mdna:75]

[0001193125-14-187120:mdna:68]
Research
and development expenses remained constant at $32.5 million in the three months ended March 31, 2013 and $32.6 million in the three months ended March 31, 2014.

[0001193125-14-187120:mdna:69]
As a percentage of sales, research and development expenses decreased from 22.7% in the three months ended March 31, 2013 to 22.1% in the three months
ended March 31, 2014. Research and development expenses as a percentage of sales will fluctuate whenever there are incremental product development activities or a significant fluctuation in revenues for the periods being compared.

[0001193125-14-187120:mdna:70]
We expect to continue to incur research and development expenses in connection with our new and existing products and our expansion into international
markets. We continually evaluate new product opportunities and engage in intensive research and product development efforts which provides for new product development, enhancement of existing products and product cost reductions. We may incur
significant research and development expenses prior to the receipt of revenues from a major new product group.

[0001193125-14-187120:mdna:71]
[same as prior period, unchanged from 0001193125-13-422365:mdna:79]

[0001193125-14-187120:mdna:72]
Interest and dividend income decreased 26.8% from $1.8 million in the three months ended March 31, 2013 to $1.3 million in the three months
ended March 31, 2014. The decrease in interest and dividend income is primarily attributable to a reduction in the average rate of return on our investments as well as a decrease in our average investment balances.

[0001193125-14-187120:mdna:73]
[same as prior period, unchanged from 0001193125-13-422365:mdna:81]

[0001193125-14-187120:mdna:74]
Interest expense, which is
primarily related to our taxable revenue bond, decreased 60.9% from $0.6 million in the three months ended March 31, 2013 to $0.2 million in the three months ended March 31, 2014. The decrease is primarily attributable to a $16.5 million
principal payment made on our taxable revenue bond during the quarter and a reduction in the interest rate of that bond from 5% to 2%. See “Liquidity and Capital Resources” below for additional information on our revenue bond.

[0001193125-14-187120:mdna:75]
[same as prior period, unchanged from 0001193125-13-422365:mdna:83]

[0001193125-14-187120:mdna:76]
Net realized investment gain decreased 39.9% from $3.6 million in the three months ended March 31, 2013 to $2.2 million in the three months ended
March 31, 2014. The decrease in realized investment gains is primarily attributable to lower gains from the sale of equity securities compared to the same period in 2013. See “Investing Activities” in “Liquidity and Capital
Resources” below for additional information.

[0001193125-14-187120:mdna:77]
[same as prior period, unchanged from 0001193125-13-422365:mdna:85]

[0001193125-14-187120:mdna:78]
Other income (expense), net, comprised primarily of miscellaneous income, gains and losses on foreign currency transactions, investment account management
fees, scrap raw material sales, and gains and losses on the disposal of property, plant and equipment occurring in the normal course of business, changed from $1.7 million of expense in the three months ended March 31, 2013 to $0.1 million of
income in the three months ended March 31, 2014. This change was primarily attributable to losses on foreign currency transactions during the first quarter of 2013.

[0001193125-14-187120:mdna:79]
INCOME TAXES

[0001193125-14-187120:mdna:80]
Our effective tax rate increased
from 18.9% in the three months ended March 31, 2013 to 34.6% in the three months ended March 31, 2014. The increase in the effective tax rate between the two periods is primarily attributable to the net effect of recording the benefit for
the research tax credit for the 2012 tax year in January 2013 pursuant to the American Taxpayer Relief Act of 2012, and the inclusion of the benefit of the estimated 2013 research tax credit in the estimated annual effective rate for 2013.
Additionally, the effective tax rate in the first quarter of 2014 did not include a benefit for the research tax credit, which expired on December 31, 2013. This increase was partially offset by the release of a valuation allowance attributable
to a foreign subsidiary.

[0001193125-14-187120:mdna:81]
[same as prior period, unchanged from 0001193125-13-422365:mdna:89]

[0001193125-14-187120:mdna:82]
As a
result of the above factors, net income increased $1.7 million from $7.9 million in the three months ended March 31, 2013 to $9.6 million in the three months ended March 31, 2014.

[0001193125-14-187120:mdna:83]
As a percentage of sales, net income increased from 5.5% in the three months ended March 31, 2013 to 6.5% in the three months ended March 31, 2014.

[0001193125-14-187120:mdna:84]
[same as prior period, unchanged from 0001193125-13-422365:mdna:92]

[0001193125-14-187120:mdna:85]
[same as prior period, unchanged from 0001193125-13-422365:mdna:93]

[0001193125-14-187120:mdna:86]
We intend to finance our operations with cash flow from operations. We have used, and expect to continue to use, the cash generated from operations
for working capital, purchases of treasury stock, shareholder dividends, and other general corporate purposes, including (i) product development activities to enhance our existing products and develop new products and (ii) expansion of
sales and marketing activities. We believe our cash and cash equivalents, investments and cash generated from operations to be adequate to meet our operating and capital needs for at least the next 12 months.

[0001193125-14-187120:mdna:87]
At March 31, 2014, cash on hand was $52.8 million and short-term investments were $89.2 million, which resulted in available short-term liquidity of
$142.0 million. At December 31, 2013, our cash on hand of $58.3 million and short-term investments of $105.8 million resulted in available short-term liquidity of $164.1 million. The decrease in short-term liquidity from December 31, 2013
to March 31, 2014 primarily reflects funds used for equipment acquisitions, share repurchases and dividends, partially offset by funds provided by our operating activities.

[0001193125-14-187120:mdna:88]
[same as prior period, unchanged from 0001193125-13-422365:mdna:96]

[0001193125-14-187120:mdna:89]
Our working capital, which consists
of current assets less current liabilities, decreased 6.6% from $277.3 million as of December 31, 2013 to $259.0 million as of March 31, 2014. The quick ratio, defined as cash, cash equivalents, short-term investments, and net accounts
receivable, divided by current liabilities, decreased from 2.44 as of December 31, 2013 to 2.02 as of March 31, 2014. The current ratio, defined as current assets divided by current liabilities, decreased from 3.71 as of December 31,
2013 to 3.16 as of March 31, 2014. The decreases in our working capital, quick ratio and current ratio are primarily attributable to an increase in accounts payable and unearned revenue during the three months ended March 31, 2014.

[0001193125-14-187120:mdna:90]
Net accounts receivable increased 17.1% from $85.8 million at December 31, 2013 to $100.5 million at
March 31, 2014. Our allowance for doubtful accounts was $130 thousand at December 31, 2013 and $133 thousand at March 31, 2014. Quarterly accounts receivable days sales outstanding (DSO) increased from 50 days as of December 31,
2013 to 62 days as of March 31, 2014. The change in net accounts receivable and DSO is due to changes in customer mix and the timing of sales and collections during the quarter. Certain international customers can have longer payment terms than
U.S. customers. Other receivables increased from $18.2 million at December 31, 2013 to $29.0 million at March 31, 2014. The increase in other receivables is primarily attributable to an increase in deferred revenues in the acquired
business and the timing of filing returns and collections of VAT receivables in our international subsidiaries. Other receivables will also fluctuate due to the timing of shipments and collections for materials supplied to our contract manufacturers
during the quarter.

[0001193125-14-187120:mdna:91]
Quarterly inventory turnover decreased from 3.6 turns as of December 31, 2013 to 3.1 turns as of March 31, 2014. Inventory
decreased 3.0% from December 31, 2013 to March 31, 2014. We expect inventory levels to fluctuate as we attempt to maintain sufficient inventory in response to seasonal cycles of our business ensuring competitive lead times while managing
the risk of inventory obsolescence that may occur due to rapidly changing technology and customer demand.

[0001193125-14-187120:mdna:92]
Accounts payable increased 22.4% from $48.3
million at December 31, 2013 to $59.1 million at March 31, 2014. Accounts payable will fluctuate due to variations in the timing of the receipt of supplies, inventory and services and our subsequent payments for these purchases.

[0001193125-14-187120:mdna:93]
[same as prior period, unchanged from 0001193125-13-422365:mdna:101]

[0001193125-14-187120:mdna:94]
Capital expenditures totaled
approximately $2.0 million and $0.6 million for the three months ended March 31, 2014 and 2013, respectively. These expenditures were primarily used to purchase manufacturing and test equipment and computer software and hardware.

[0001193125-14-187120:mdna:95]
Our combined short-term and long-term investments decreased $16.4 million from $415.0 million at December 31, 2013 to $398.6 million at March 31,
2014. This decrease reflects the impact of our cash needs for equipment acquisitions, share repurchases, dividends, and bond payment, as well as net realized and unrealized losses and amortization of net premiums on our combined investments,
partially offset by additional funds available for investment provided by our operating activities and stock option exercises by our employees.

[0001193125-14-187120:mdna:96]
We invest
all available cash not required for immediate use in operations primarily in securities that we believe bear minimal risk of loss. At March 31, 2014 these investments included corporate bonds of $130.9 million, municipal fixed-rate bonds of
$158.4 million, and municipal variable rate demand notes of $24.8 million. At December 31, 2013, these investments included corporate bonds of $166.9 million, municipal fixed-rate bonds of $136.3 million, and municipal variable rate demand
notes of $8.3 million. As of March 31, 2014, our corporate bonds, municipal fixed-rate bonds, and municipal variable rate demand notes were classified as available-for-sale and had a combined duration of 1.0 years with an average credit rating
of AA-. Because our bond portfolio has a high quality rating and contractual maturities of a short duration, we are able to obtain prices for these bonds derived from observable market inputs, or for similar securities traded in an active market, on
a daily basis.

[0001193125-14-187120:mdna:97]
Our long-term investments increased 0.1% from $309.2 million at December 31, 2013 to $309.5 million at March 31, 2014. Long-term
investments at March 31, 2014 and December 31, 2013 included an investment in a certificate of deposit of $30.0 million and $48.3 million, respectively, which serves as collateral for our revenue bonds, as discussed below. We have various
equity investments included in long-term investments at a cost of $25.2 million and $24.7 million, and with a fair value of $37.6 million and $38.5 million, at March 31, 2014 and December 31, 2013, respectively.

[0001193125-14-187120:mdna:98]
Long-term investments at March 31, 2014 and December 31, 2013 also included $15.3 million and $15.1 million, respectively, related to our deferred
compensation plans, and $1.7 million of other investments carried at cost, consisting of interests in two private equity funds and an investment in a privately held telecommunications equipment manufacturer.

[0001193125-14-187120:mdna:99]
We review our investment portfolio for potential “other-than-temporary” declines in value on an
individual investment basis. We assess, on a quarterly basis, significant declines in value which may be considered other-than-temporary and, if necessary, recognize and record the appropriate charge to write-down the carrying value of such
investments. In making this assessment, we take into consideration qualitative and quantitative information, including but not limited to the following: the magnitude and duration of historical declines in market prices, credit rating activity,
assessments of liquidity, public filings, and statements made by the issuer. We generally begin our identification of potential other-than-temporary impairments by reviewing any security with a fair value that has declined from its original or
adjusted cost basis by 25% or more for six or more consecutive months. We then evaluate the individual security based on the previously identified factors to determine the amount of the write-down, if any. As a result of our review, we recorded no
other-than-temporary impairment charges during the three months ended March 31, 2014. For the three months ended March 31, 2013, we recorded an other-than-temporary impairment charge of $4 thousand related to one marketable equity
security.

[0001193125-14-187120:mdna:100]
[same as prior period, unchanged from 0001193125-13-422365:mdna:108]

[0001193125-14-187120:mdna:101]
[same as prior period, unchanged from 0001193125-13-422365:mdna:109]

[0001193125-14-187120:mdna:102]
In July 2003, our Board of Directors elected to begin declaring quarterly dividends on our common stock considering the tax treatment of dividends and
adequate levels of Company liquidity. During the three months ended March 31, 2014, we paid dividends totaling $5.1 million.

[0001193125-14-187120:mdna:103]
[same as prior period, unchanged from 0001193125-13-422365:mdna:111]

[0001193125-14-187120:mdna:104]
We have amounts outstanding under loans made pursuant to an Alabama State Industrial Development Authority revenue bond (the Bond) which totaled
$30.0 million and $46.5 million at March 31, 2014 and December 31, 2013, respectively. At March 31, 2014, the estimated fair value of the Bond was approximately $29.6 million, based on a debt security with a comparable interest rate
and maturity and a Standard & Poor’s credit rating of AAA-. Included in long-term investments are restricted funds in the amount of $30.0 million and $48.3 million at March 31, 2014 and December 31, 2013, which is a
collateral deposit against the principal amount of the Bond. We have the right to set-off the balance of the Bond with the collateral deposit in order to reduce the balance of the indebtedness. The Bond matures on January 1, 2020, and bears
interest at the rate of 2% per annum. In conjunction with this program, we are eligible to receive certain economic incentives from the state of Alabama that reduce the amount of payroll withholdings we are required to remit to the state for
those employment positions that qualify under this program. We are required to make payments in the amounts necessary to pay the interest on the amounts currently outstanding. During the first quarter of 2014, we made a principal payment on the Bond
of $16.5 million.

[0001193125-14-187120:mdna:105]
[same as prior period, unchanged from 0001193125-13-422365:mdna:113]

[0001193125-14-187120:mdna:106]
Since
1997, our Board of Directors has approved multiple share repurchase programs that have authorized open market repurchase transactions of up to 40.0 million shares of our common stock. During the three months ended March 31, 2014, we
repurchased 0.4 million shares of our common stock at an average price of $25.13 per share. We currently have the authority to purchase an additional 3.1 million shares of our common stock under the current plan approved by the Board of
Directors on May 1, 2013.

[0001193125-14-187120:mdna:107]
[same as prior period, unchanged from 0001193125-13-422365:mdna:116]

[0001193125-14-187120:mdna:108]
To accommodate employee stock option exercises, we issued 0.1 million shares of treasury stock for $1.5 million during the three months ended
March 31, 2014. During the three months ended March 31, 2013, we issued four thousand shares of treasury stock for $55 thousand.

[0001193125-14-187120:mdna:109]
Off-Balance
Sheet Arrangements and Contractual Obligations

[0001193125-14-187120:mdna:110]
We do not have off-balance sheet financing arrangements and have not engaged in any related party
transactions or arrangements with unconsolidated entities or other persons that are reasonably likely to materially affect liquidity or the availability of or requirements for capital resources. During the three months ended March 31, 2014, the
only material change in contractual obligations and commercial commitments from those discussed in our most recent Annual Report on Form 10-K for the year ended December 31, 2013 filed on February 27, 2014 with the SEC was due to a $16.5
million principal payment on our taxable revenue bond.

[0001193125-14-187120:mdna:111]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, and we have
contributed $8.4 million as of March 31, 2014, of which $7.7 million has been applied to these commitments.

[0001193125-14-187120:mdna:112]
FACTORS THAT COULD AFFECT OUR FUTURE
RESULTS

[0001193125-14-187120:mdna:113]
The following are some of the risks that could affect our financial performance or could cause actual results to differ materially from those
expressed or implied in our forward-looking statements:

[0001193125-14-187120:mdna:114]
[same as prior period, unchanged from 0001193125-13-422365:mdna:123]

[0001193125-14-187120:mdna:115]
[same as prior period, unchanged from 0001193125-13-422365:mdna:124]

[0001193125-14-187120:mdna:116]
|  | • |  | The failure to realize future benefits from the acquisition of the NSN BBA business as significantly as we expect may affect our future results of operations and financial condition, and could affect our stock price. |

[0001193125-14-187120:mdna:117]
[same as prior period, unchanged from 0001193125-13-422365:mdna:126]

[0001193125-14-187120:mdna:118]
[same as prior period, unchanged from 0001193125-13-422365:mdna:127]

[0001193125-14-187120:mdna:119]
[same as prior period, unchanged from 0001193125-13-422365:mdna:128]

[0001193125-14-187120:mdna:120]
[same as prior period, unchanged from 0001193125-13-422365:mdna:129]

[0001193125-14-187120:mdna:121]
|  | • |  | Our products may not continue to comply with evolving regulations governing their sale, which may harm our business. |

[0001193125-14-187120:mdna:122]
[same as prior period, unchanged from 0001193125-13-422365:mdna:131]

[0001193125-14-187120:mdna:123]
[same as prior period, unchanged from 0001193125-13-422365:mdna:132]

[0001193125-14-187120:mdna:124]
[same as prior period, unchanged from 0001193125-13-422365:mdna:133]

[0001193125-14-187120:mdna:125]
[same as prior period, unchanged from 0001193125-13-422365:mdna:134]

[0001193125-14-187120:mdna:126]
[same as prior period, unchanged from 0001193125-13-422365:mdna:135]

[0001193125-14-187120:mdna:127]
[same as prior period, unchanged from 0001193125-13-422365:mdna:136]

[0001193125-14-187120:mdna:128]
[same as prior period, unchanged from 0001193125-13-422365:mdna:137]

[0001193125-14-187120:mdna:129]
[same as prior period, unchanged from 0001193125-13-422365:mdna:138]

[0001193125-14-187120:mdna:130]
[same as prior period, unchanged from 0001193125-13-422365:mdna:139]

[0001193125-14-187120:mdna:131]
[same as prior period, unchanged from 0001193125-13-422365:mdna:140]

[0001193125-14-187120:mdna:132]
[same as prior period, unchanged from 0001193125-13-422365:mdna:141]

[0001193125-14-187120:mdna:133]
[same as prior period, unchanged from 0001193125-13-422365:mdna:142]

[0001193125-14-187120:mdna:134]
[same as prior period, unchanged from 0001193125-13-422365:mdna:144]

[0001193125-14-187120:mdna:135]
|  | • |  | Breaches in our information systems could cause significant damage to our business and reputation. |

[0001193125-14-187120:mdna:136]
[same as prior period, unchanged from 0001193125-13-422365:mdna:145]

[0001193125-14-187120:mdna:137]
[same as prior period, unchanged from 0001193125-13-422365:mdna:146]

[0001193125-14-187120:mdna:138]
|  | • |  | We may incur liabilities or become subject to litigation that would have a material effect on our business. |

[0001193125-14-187120:mdna:139]
[same as prior period, unchanged from 0001193125-13-422365:mdna:57]

[0001193125-14-187120:mdna:140]
[same as prior period, unchanged from 0001193125-13-422365:mdna:148]

[0001193125-14-187120:mdna:141]
[same as prior period, unchanged from 0001193125-13-422365:mdna:149]

[0001193125-14-187120:mdna:142]
[same as prior period, unchanged from 0001193125-13-422365:mdna:150]

[0001193125-14-187120:mdna:143]
[same as prior period, unchanged from 0001193125-13-422365:mdna:151]

[0001193125-14-187120:mdna:144]
[same as prior period, unchanged from 0001193125-13-422365:mdna:152]

[0001193125-14-187120:mdna:145]
[same as prior period, unchanged from 0001193125-13-422365:mdna:153]

[0001193125-14-187120:mdna:146]
[same as prior period, unchanged from 0001193125-13-422365:mdna:154]

[0001193125-14-187120:mdna:147]
[same as prior period, unchanged from 0001193125-13-422365:mdna:155]

[0001193125-14-187120:mdna:148]
[same as prior period, unchanged from 0001193125-13-422365:mdna:156]

[0001193125-14-187120:mdna:149]
[same as prior period, unchanged from 0001193125-13-422365:mdna:157]

[0001193125-14-187120:mdna:150]
The foregoing
list of risks is not exclusive. For a more detailed description of the risk factors associated with our business, see Item 1A of our Annual Report on Form 10-K for the year ended December 31, 2013, filed on February 27, 2014 with the
SEC.
