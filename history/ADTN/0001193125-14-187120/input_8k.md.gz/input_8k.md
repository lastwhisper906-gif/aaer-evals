# ADTN 8-K — 0001193125-14-144665 filed 2014-04-16

## item codes, every 8-K on or before 2014-05-07

- 2014-04-16 0001193125-14-144665 — 2.02, 9.01
- 2014-04-03 0001193125-14-129578 — 2.02, 9.01
- 2014-01-22 0001157523-14-000154 — 2.02, 9.01
- 2013-10-15 0001193125-13-399540 — 5.02
- 2013-10-09 0001157523-13-004657 — 2.02, 9.01
- 2013-07-10 0001157523-13-003290 — 2.02, 9.01
- 2013-05-10 0001193125-13-213728 — 5.07
- 2013-05-03 0001193125-13-198816 — 8.01, 9.01
- 2013-04-10 0001157523-13-001730 — 2.02, 9.01
- 2013-01-16 0001157523-13-000139 — 2.02, 9.01
- 2012-10-10 0001157523-12-005081 — 2.02, 9.01
- 2012-10-03 0001193125-12-413609 — 7.01
- 2012-09-28 0001193125-12-408878 — 2.02, 9.01
- 2012-07-11 0001157523-12-003592 — 2.02, 9.01
- 2012-05-10 0001193125-12-225669 — 5.07
- 2012-05-10 0001193125-12-225639 — 8.01, 9.01
- 2012-04-11 0001157523-12-001772 — 2.02, 9.01
- 2012-03-15 0001193125-12-116494 — 2.02, 9.01
- 2012-01-18 0001157523-12-000174 — 2.02, 9.01
- 2011-12-12 0001193125-11-337271 — 7.01, 9.01
- 2011-10-13 0000950123-11-089785 — 5.03, 9.01
- 2011-10-12 0001157523-11-005682 — 2.02, 9.01
- 2011-07-13 0001157523-11-003986 — 2.02, 9.01
- 2011-05-09 0000950123-11-047191 — 5.02, 5.07, 9.01
- 2011-04-13 0001157523-11-002001 — 2.02, 9.01
- 2011-01-19 0001157523-11-000232 — 2.02, 9.01
- 2010-11-09 0000950123-10-103195 — 5.02, 9.01
- 2010-10-13 0001157523-10-005798 — 2.02, 9.01
- 2010-07-14 0001157523-10-004011 — 2.02, 9.01
- 2010-05-28 0000950123-10-053947 — 5.07
- 2010-04-14 0001157523-10-002022 — 2.02, 9.01
- 2010-01-20 0001157523-10-000200 — 2.02, 9.01
- 2009-10-28 0000950123-09-053984 — 8.01
- 2009-10-14 0001157523-09-006877 — 2.02, 9.01
- 2009-07-15 0001157523-09-004878 — 2.02, 9.01
- 2009-04-15 0001157523-09-002687 — 2.02, 9.01
- 2009-01-21 0001157523-09-000340 — 2.02, 9.01
- 2008-11-12 0001193125-08-233181 — 5.02, 9.01
- 2008-10-14 0001157523-08-007999 — 2.02, 9.01
- 2008-07-15 0001157523-08-005504 — 2.02, 9.01
- 2008-04-15 0001157523-08-002896 — 2.02, 9.01
- 2008-01-22 0001157523-08-000408 — 2.02, 9.01
- 2007-10-16 0001193125-07-219356 — 5.03, 9.01
- 2007-10-16 0001157523-07-009850 — 2.02, 9.01
- 2007-07-17 0001157523-07-006912 — 2.02, 9.01
- 2007-04-17 0001157523-07-003630 — 2.02, 9.01
- 2007-04-03 0001179022-07-000068 — 5.02
- 2007-03-28 0001179022-07-000064 — 5.02
- 2007-02-23 0001193125-07-038337 — 5.02
- 2007-02-23 0001193125-07-038335 — 5.02
- 2007-01-30 0001193125-07-015912 — 5.02, 9.01
- 2007-01-26 0001193125-07-014234 — 5.02
- 2007-01-23 0001157523-07-000494 — 2.02, 9.01 — amendment of 0001157523-07-000481
- 2007-01-23 0001157523-07-000481 — 2.02, 9.01
- 2006-10-17 0001157523-06-009945 — 2.02, 9.01
- 2006-07-18 0001157523-06-006929 — 2.02, 9.01
- 2006-06-08 0001193125-06-126486 — 1.01, 9.01
- 2006-05-10 0001193125-06-107316 — 1.01, 9.01
- 2006-04-18 0001157523-06-003699 — 2.02, 9.01
- 2006-02-03 0001179022-06-000014 — 1.01
- 2006-01-27 0001157523-06-000754 — 5.02, 9.01
- 2006-01-24 0001157523-06-000551 — 2.02, 9.01
- 2005-10-18 0001157523-05-008826 — 2.02, 9.01
- 2005-07-19 0001193125-05-143958 — 1.01, 5.02, 9.01
- 2005-07-19 0001193125-05-143957 — 2.02, 9.01
- 2005-05-20 0001193125-05-112019 — 1.01, 9.01
- 2005-04-19 0001157523-05-003418 — 2.02, 9.01
- 2005-01-25 0001193125-05-010721 — 2.02, 9.01
- 2004-10-12 0001193125-04-169652 — 2.02, 9.01
- 2004-07-13 0001193125-04-116820 — 12, 7
- 2004-04-14 0001193125-04-061547 — 12, 7
- 2004-01-21 0001193125-04-006366 — 12, 7
- 2003-10-14 0001193125-03-061018 — 12, 5, 7
- 2003-07-15 0001193125-03-019292 — 7, 9
- 2003-04-15 0000931763-03-000968 — 7, 9
- 1996-09-12 0000931763-96-000667 — 5, 7

## late-filing notifications on or before 2014-05-07

- none on or before 2014-05-07

## item 2.02 — earnings release, exhibit 99.1

[0001193125-14-144665:8k_2_02:1]
EX-99.1
2
d711158dex991.htm
EX-99.1

[0001193125-14-144665:8k_2_02:2]
EX-99.1

[0001193125-14-144665:8k_2_02:3]
Exhibit 99.1

[0001193125-14-144665:8k_2_02:4]
ADTRAN, INC.

[0001193125-14-144665:8k_2_02:5]
REPORTS RESULTS for the FIRST QUARTER 2014 and DECLARES QUARTERLY CASH

[0001193125-14-144665:8k_2_02:6]
DIVIDEND

[0001193125-14-144665:8k_2_02:7]
HUNTSVILLE,
Ala.—(BUSINESS WIRE)—April 15, 2014—ADTRAN, Inc. (NASDAQ:ADTN) reported results for the first quarter 2014. For the quarter, sales were $147,004,000 compared to $143,013,000 for the first quarter of 2013. Operating income was
$11,298,000 compared to $6,563,000 for the first quarter of 2013. Net income was $9,607,000 compared to $7,890,000 for the first quarter of 2013. Earnings per share, assuming dilution, were $0.17 compared to $0.13 for the first quarter of 2013.
Non-GAAP earnings per share were $0.21 compared to $0.17 for the first quarter of 2013. The reconciliation between GAAP earnings per share, diluted, and non-GAAP earnings per share, diluted, is in the table provided.

[0001193125-14-144665:8k_2_02:8]
ADTRAN Chief Executive Officer Tom Stanton stated, “Revenue for the quarter came in at $147 million, up 3% over last year. Lower sales in the US were
offset by international sales which grew 56% over the same period last year. Operating income increased 72% buoyed by higher gross margins in both our US and international businesses.”

[0001193125-14-144665:8k_2_02:9]
The Company also announced that its Board of Directors declared a cash dividend for the first quarter of 2014. The quarterly cash dividend is $0.09 per common
share to be paid to holders of record at the close of business on May 1, 2014. The ex-dividend date is April 29, 2014 and the payment date is May 15, 2014.

[0001193125-14-144665:8k_2_02:10]
The Company confirmed that its first quarter conference call will be held Wednesday, April 16, 2014 at 9:30 a.m. Central Time. This conference call will
be web cast live through StreetEvents.com. To listen, simply visit the Investor Relations site at www.adtran.com or www.streetevents.com approximately 10 minutes prior to the start of the call and click on the conference call link
provided.

[0001193125-14-144665:8k_2_02:11]
An online replay of the conference call will be available for seven days at www.streetevents.com. In addition, an online replay of the
conference call, as well as the text of the Company’s earnings release, will be available on the Investor Relations site at www.adtran.com for at least 12 months following the call.

[0001193125-14-144665:8k_2_02:12]
ADTRAN, Inc. is a leading global provider of networking and communications equipment. ADTRAN’s products enable voice, data, video and Internet
communications across a variety of network infrastructures. ADTRAN solutions are currently in use by service providers, private enterprises, government organizations, and millions of individual users worldwide. For more information, please visit
www.adtran.com.

[0001193125-14-144665:8k_2_02:13]
For more information, contact the company at 800 9ADTRAN (800 923-8726) or via email at info@adtran.com. On the Web, visit
www.adtran.com.

[0001193125-14-144665:8k_2_02:14]
This press release contains forward-looking statements which reflect management’s best judgment based on factors currently
known. However, these statements involve risks and uncertainties, including the successful development and market acceptance of new products, the degree of competition in the market for such products, the product and channel mix, component costs,
manufacturing efficiencies, and other risks detailed in our annual report on Form 10-K for the year ended December 31, 2013. These risks and uncertainties could cause actual results to differ materially from those in the forward-looking
statements included in this press release.

[0001193125-14-144665:8k_2_02:15]
| CONTACT: Jim Matthews Senior Vice President/CFO 256-963-8775 |  | INVESTOR SERVICES/ASSISTANCE: Gayle Ellis 256-963-8220 |

[0001193125-14-144665:8k_2_02:16]
Condensed Consolidated Balance Sheet

[0001193125-14-144665:8k_2_02:17]
(Unaudited)

[0001193125-14-144665:8k_2_02:18]
(In
thousands)

[0001193125-14-144665:8k_2_02:19]
|  |  | March 31,2014 |  |  | December 31,2013 |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 52,815 |  |  | $ | 58,298 |  |
| Short-term investments |  |  | 89,160 |  |  |  | 105,760 |  |
| Accounts receivable, net |  |  | 100,524 |  |  |  | 85,814 |  |
| Other receivables |  |  | 28,967 |  |  |  | 18,249 |  |
| Inventory |  |  | 87,396 |  |  |  | 90,111 |  |
| Prepaid expenses |  |  | 5,005 |  |  |  | 4,325 |  |
| Deferred tax assets, net |  |  | 15,181 |  |  |  | 17,083 |  |
| Total Current Assets |  |  | 379,048 |  |  |  | 379,640 |  |
| Property, plant and equipment, net |  |  | 75,885 |  |  |  | 76,739 |  |
| Deferred tax assets, net |  |  | 11,491 |  |  |  | 9,622 |  |
| Goodwill |  |  | 3,492 |  |  |  | 3,492 |  |
| Other assets |  |  | 11,933 |  |  |  | 11,180 |  |
| Long-term investments |  |  | 309,452 |  |  |  | 309,225 |  |
| Total Assets |  | $ | 791,301 |  |  | $ | 789,898 |  |
| Liabilities and Stockholders’ Equity |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 59,097 |  |  | $ | 48,282 |  |
| Unearned revenue |  |  | 27,533 |  |  |  | 22,205 |  |
| Accrued expenses |  |  | 10,683 |  |  |  | 12,776 |  |
| Accrued wages and benefits |  |  | 17,448 |  |  |  | 14,040 |  |
| Income tax payable, net |  |  | 5,272 |  |  |  | 5,002 |  |
| Total Current Liabilities |  |  | 120,033 |  |  |  | 102,305 |  |
| Non-current unearned revenue |  |  | 15,116 |  |  |  | 14,643 |  |
| Other non-current liabilities |  |  | 23,476 |  |  |  | 22,144 |  |
| Bonds payable |  |  | 30,000 |  |  |  | 46,200 |  |
| Total Liabilities |  |  | 188,625 |  |  |  | 185,292 |  |
| Stockholders’ Equity |  |  | 602,676 |  |  |  | 604,606 |  |
| Total Liabilities and Stockholders’ Equity |  | $ | 791,301 |  |  | $ | 789,898 |  |

[0001193125-14-144665:8k_2_02:20]
Consolidated Statements of Income

[0001193125-14-144665:8k_2_02:21]
(Unaudited)

[0001193125-14-144665:8k_2_02:22]
(In
thousands, except per share data)

[0001193125-14-144665:8k_2_02:23]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| Sales |  | $ | 147,004 |  |  | $ | 143,013 |  |
| Cost of sales |  |  | 69,214 |  |  |  | 73,336 |  |
| Gross Profit |  |  | 77,790 |  |  |  | 69,677 |  |
| Selling, general and administrative expenses |  |  | 33,939 |  |  |  | 30,603 |  |
| Research and development expenses |  |  | 32,553 |  |  |  | 32,511 |  |
| Operating Income |  |  | 11,298 |  |  |  | 6,563 |  |
| Interest and dividend income |  |  | 1,294 |  |  |  | 1,768 |  |
| Interest expense |  |  | (227 | ) |  |  | (581 | ) |
| Net realized investment gain |  |  | 2,192 |  |  |  | 3,645 |  |
| Other income (expense), net |  |  | 122 |  |  |  | (1,672 | ) |
| Income before provision for income taxes |  |  | 14,679 |  |  |  | 9,723 |  |
| Provision for income taxes |  |  | (5,072 | ) |  |  | (1,833 | ) |
| Net Income |  | $ | 9,607 |  |  | $ | 7,890 |  |
| Weighted average shares outstanding – basic |  |  | 56,751 |  |  |  | 61,847 |  |
| Weighted average shares outstanding – diluted (1) |  |  | 57,368 |  |  |  | 62,030 |  |
| Earnings per common share – basic |  | $ | 0.17 |  |  | $ | 0.13 |  |
| Earnings per common share – diluted (1) |  | $ | 0.17 |  |  | $ | 0.13 |  |

[0001193125-14-144665:8k_2_02:24]
(1) Assumes exercise of dilutive stock options calculated under the
treasury stock method.

[0001193125-14-144665:8k_2_02:25]
Consolidated Statements of Comprehensive Income

[0001193125-14-144665:8k_2_02:26]
(Unaudited)

[0001193125-14-144665:8k_2_02:27]
(In
thousands)

[0001193125-14-144665:8k_2_02:28]
|  |  | Three Months EndedMarch 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| Net Income |  | $ | 9,607 |  |  | $ | 7,890 |  |
| Other Comprehensive Loss, net of tax: |  |  |  |  |  |  |  |  |
| Unrealized losses on available-for-sale securities |  |  | (921 | ) |  |  | (1,644 | ) |
| Foreign currency translation |  |  | 252 |  |  |  | 323 |  |
| Other Comprehensive Loss, net of tax |  |  | (669 | ) |  |  | (1,321 | ) |
| Comprehensive Income, net of tax |  | $ | 8,938 |  |  | $ | 6,569 |  |

[0001193125-14-144665:8k_2_02:29]
Consolidated Statements of Cash Flows

[0001193125-14-144665:8k_2_02:30]
(Unaudited)

[0001193125-14-144665:8k_2_02:31]
(In
thousands)

[0001193125-14-144665:8k_2_02:32]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 9,607 |  |  | $ | 7,890 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 3,580 |  |  |  | 3,663 |  |
| Amortization of net premium on available-for-sale investments |  |  | 1,135 |  |  |  | 1,754 |  |
| Net realized gain on long-term investments |  |  | (2,192 | ) |  |  | (3,645 | ) |
| Net (gain) loss on disposal of property, plant and equipment |  |  | (3 | ) |  |  | 17 |  |
| Stock-based compensation expense |  |  | 2,057 |  |  |  | 2,232 |  |
| Deferred income taxes |  |  | 627 |  |  |  | 715 |  |
| Tax benefit from stock option exercises |  |  | 57 |  |  |  | — |  |
| Excess tax benefits from stock-based compensation arrangements |  |  | (55 | ) |  |  | — |  |
| Change in operating assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  |  | (14,668 | ) |  |  | (1,306 | ) |
| Other receivables |  |  | (10,710 | ) |  |  | (224 | ) |
| Inventory |  |  | 2,739 |  |  |  | 6,540 |  |
| Prepaid expenses and other assets |  |  | (2,024 | ) |  |  | (217 | ) |
| Accounts payable |  |  | 11,043 |  |  |  | 7,170 |  |
| Accrued expenses and other liabilities |  |  | 8,431 |  |  |  | 1,188 |  |
| Income tax payable, net |  |  | 275 |  |  |  | 379 |  |
| Net cash provided by operating activities |  |  | 9,899 |  |  |  | 26,156 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (2,042 | ) |  |  | (643 | ) |
| Proceeds from disposals of property, plant and equipment |  |  | 1 |  |  |  | — |  |
| Proceeds from sales and maturities of available-for-sale investments |  |  | 85,072 |  |  |  | 118,133 |  |
| Purchases of available-for-sale investments |  |  | (69,182 | ) |  |  | (125,411 | ) |
| Net cash provided by (used in) investing activities |  |  | 13,849 |  |  |  | (7,921 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Proceeds from stock option exercises |  |  | 1,541 |  |  |  | 55 |  |
| Purchases of treasury stock |  |  | (9,427 | ) |  |  | (22,546 | ) |
| Dividend payments |  |  | (5,102 | ) |  |  | (5,586 | ) |
| Payments on long-term debt |  |  | (16,500 | ) |  |  | — |  |
| Excess tax benefits from stock-based compensation arrangements |  |  | 55 |  |  |  | — |  |
| Net cash used in financing activities |  |  | (29,433 | ) |  |  | (28,077 | ) |
| Net decrease in cash and cash equivalents |  |  | (5,685 | ) |  |  | (9,842 | ) |
| Effect of exchange rate changes |  |  | 202 |  |  |  | 25 |  |
| Cash and cash equivalents, beginning of period |  |  | 58,298 |  |  |  | 68,457 |  |
| Cash and cash equivalents, end of period |  | $ | 52,815 |  |  | $ | 58,640 |  |
| Supplemental disclosure of non-cash investing activities |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment included in accounts payable |  | $ | 85 |  |  | $ | 92 |  |

[0001193125-14-144665:8k_2_02:33]
Supplemental Information

[0001193125-14-144665:8k_2_02:34]
Acquisition Related Expenses, Amortizations and Adjustments

[0001193125-14-144665:8k_2_02:35]
(Unaudited)

[0001193125-14-144665:8k_2_02:36]
(In
thousands)

[0001193125-14-144665:8k_2_02:37]
On August 4, 2011, we closed on the acquisition of Bluesocket, Inc. and on May 4, 2012, we closed on the acquisition of the
Nokia Siemens Networks Broadband Access business (NSN BBA). Acquisition related expenses, amortizations and adjustments for the three months ended March 31, 2014 and 2013 for both transactions are as follows:

[0001193125-14-144665:8k_2_02:38]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| Bluesocket, Inc. acquisition |  |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets and other purchase accounting adjustments |  | $ | 246 |  |  | $ | 293 |  |
| NSN BBA acquisition |  |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets |  |  | 302 |  |  |  | 294 |  |
| Amortization of other purchase accounting adjustments |  |  | 361 |  |  |  | 410 |  |
| Acquisition related professional fees, travel and other expenses |  |  | 48 |  |  |  | 154 |  |
| Subtotal |  |  | 711 |  |  |  | 858 |  |
| Total acquisition related expenses, amortizations and adjustments |  |  | 957 |  |  |  | 1,151 |  |
| Provision for income taxes |  |  | (316 | ) |  |  | (380 | ) |
| Total acquisition related expenses, amortizations and adjustments, net of tax |  | $ | 641 |  |  | $ | 771 |  |

[0001193125-14-144665:8k_2_02:39]
The acquisition related expenses, amortizations and adjustments above were recorded in the following Consolidated Statements
of Income categories for the three months ended March 31, 2014 and 2013:

[0001193125-14-144665:8k_2_02:40]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| Revenue (adjustments to deferred revenue recognized in the period) |  | $ | 243 |  |  | $ | 262 |  |
| Cost of goods sold |  |  | 34 |  |  |  | 87 |  |
| Subtotal |  |  | 277 |  |  |  | 349 |  |
| Selling, general and administrative expenses |  |  | 55 |  |  |  | 161 |  |
| Research and development expenses |  |  | 625 |  |  |  | 641 |  |
| Subtotal |  |  | 680 |  |  |  | 802 |  |
| Total acquisition related expenses, amortizations and adjustments |  |  | 957 |  |  |  | 1,151 |  |
| Provision for income taxes |  |  | (316 | ) |  |  | (380 | ) |
| Total acquisition related expenses, amortizations and adjustments, net of tax |  | $ | 641 |  |  | $ | 771 |  |

[0001193125-14-144665:8k_2_02:41]
Supplemental Information

[0001193125-14-144665:8k_2_02:42]
Stock-based Compensation Expense

[0001193125-14-144665:8k_2_02:43]
(Unaudited)

[0001193125-14-144665:8k_2_02:44]
(In
thousands)

[0001193125-14-144665:8k_2_02:45]
|  |  | Three Month Ended |  |
|  |  | March 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| Stock-based compensation expense included in cost of sales |  | $ | 116 |  |  | $ | 106 |  |
| Selling, general and administrative expense |  |  | 1,026 |  |  |  | 1,063 |  |
| Research and development expense |  |  | 915 |  |  |  | 1,063 |  |
| Stock-based compensation expense included in operating expenses |  |  | 1,941 |  |  |  | 2,126 |  |
| Total stock-based compensation expense |  |  | 2,057 |  |  |  | 2,232 |  |
| Tax benefit for expense associated with non-qualified options |  |  | (284 | ) |  |  | (307 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 1,773 |  |  | $ | 1,925 |  |

[0001193125-14-144665:8k_2_02:46]
Reconciliation of GAAP net income per share, diluted, to

[0001193125-14-144665:8k_2_02:47]
Non-GAAP net income per share, diluted

[0001193125-14-144665:8k_2_02:48]
(Unaudited)

[0001193125-14-144665:8k_2_02:49]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
|  |  | 2014 |  |  | 2013 |  |
| GAAP earnings per common share – diluted |  | $ | 0.17 |  |  | $ | 0.13 |  |
| Acquisition related expenses, amortizations and adjustments |  |  | 0.01 |  |  |  | 0.01 |  |
| Stock-based compensation expense |  |  | 0.03 |  |  |  | 0.03 |  |
| Non-GAAP earnings per common share – diluted |  | $ | 0.21 |  |  | $ | 0.17 |  |
