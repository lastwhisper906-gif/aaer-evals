# ADTN notes — 0001564590-18-019154


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001564590-18-019154:notes:1]
[same as prior period, unchanged from 0001564590-18-012467:notes:1]

[0001564590-18-019154:notes:2]
[same as prior period, unchanged from 0001564590-18-012467:notes:2]

[0001564590-18-019154:notes:3]
[same as prior period, unchanged from 0001564590-18-012467:notes:3]

[0001564590-18-019154:notes:4]
[same as prior period, unchanged from 0001564590-18-012467:notes:4]

[0001564590-18-019154:notes:5]
[same as prior period, unchanged from 0001564590-18-012467:notes:5]

[0001564590-18-019154:notes:6]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States of America requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenue and expense during the reporting period. Our more significant estimates include the obsolete and excess inventory reserves, warranty reserves, customer rebates, determination of the deferred revenue components of multiple element sales agreements, estimated costs to complete obligations associated with deferred revenues, estimated income tax provision and income tax contingencies, the fair value of stock-based compensation, impairment of goodwill, valuation and estimated lives of intangible assets, estimated pension liability, fair value of investments, and the evaluation of other-than-temporary declines in the value of investments. Actual amounts could differ significantly from these estimates.

[0001564590-18-019154:notes:7]
[same as prior period, unchanged from 0001564590-18-012467:notes:7]

[0001564590-18-019154:notes:8]
In February 2016, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) 2016-02, Leases (Topic 842). ASU 2016-02 requires an entity to recognize lease assets and lease liabilities on the balance sheet and to disclose key information about the entity's leasing arrangements. Subsequently, in July 2018, the FASB issued ASU 2018-10, Codification Improvements to Topic 842, Leases, which clarified certain aspects of ASU 2016-02. ASU 2016-02 and ASU 2018-10 are effective for fiscal years beginning after December 15, 2018, and interim periods within those fiscal years. A modified retrospective approach is required. We anticipate the adoption of these ASUs will have a material increase in the assets and liabilities of our consolidated balance sheets; however, we do not believe adoption will have a material effect on our results of operations. We believe the most significant effect relates to our accounting for operating leases for office space and equipment.

[0001564590-18-019154:notes:9]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. ASU 2016-13 requires the measurement and recognition of expected credit losses for financial instruments held at amortized cost. ASU 2016-13 is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019, with early adoption permitted. We are currently evaluating the effect ASU 2016-13 will have on our consolidated financial statements.

[0001564590-18-019154:notes:10]
In January 2017, the FASB issued ASU 2017-04, Intangibles – Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment. ASU 2017-04 simplifies the measurement of goodwill by eliminating step 2 of the goodwill impairment test. Under ASU 2017-04, entities will be required to compare the fair value of a reporting unit to its carrying amount and recognize an impairment charge for the amount by which the carrying amount exceeds the reporting unit’s fair value. ASU 2017-04 is effective for annual or interim impairment tests performed in fiscal years beginning after December 15, 2019, with early adoption permitted for annual or interim impairment tests performed on testing dates after January 1, 2017. The amendments should be applied prospectively. We are currently evaluating whether to early adopt ASU 2017-04, but we do not expect it will have a material effect on our consolidated financial statements.

[0001564590-18-019154:notes:11]
In August 2017, the FASB issued ASU 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities. ASU 2017-12 expands and refines hedge accounting for both financial and non-financial risk components, aligns the recognition and presentation of the effects of hedging instruments and hedge items in the financial statements, and includes certain targeted improvements to ease the application of current guidance related to the assessment of hedge effectiveness. ASU 2017-12 is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2018, with early adoption permitted. We are currently evaluating the effect ASU 2017-12 will have on our consolidated financial statements.

[0001564590-18-019154:notes:12]
In February 2018, the FASB issued ASU 2018-02, Income Statement – Reporting Comprehensive Income (Topic 220): Reclassification of Certain Tax Effects from Accumulated Comprehensive Income. ASU 2018-02 allows for an optional reclassification from accumulated other comprehensive income to retained earnings for stranded tax effects resulting from the Tax Cuts and Jobs Act of 2017. ASU 2018-02 is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2018, with early adoption permitted. We are currently evaluating whether to reclassify stranded tax effects related to the Tax Cuts and Jobs Act of 2017, but we do not expect ASU 2018-02 will have a material effect on our consolidated financial statements.

[0001564590-18-019154:notes:13]
During 2018, we adopted the following accounting standards, which had the following effects on our consolidated financial statements:

[0001564590-18-019154:notes:14]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers (Topic 606), which supersedes the revenue recognition requirements in Topic 605, Revenue Recognition, including most industry-specific revenue recognition guidance throughout the Industry Topics of the Codification. The core principle of ASU 2014-09 is to recognize revenues when promised goods or services are transferred to customers in an amount that reflects the consideration that is expected to be received for those goods or services. In August 2015, the FASB issued ASU 2015-14, which deferred the effective date of ASU 2014-09 to fiscal years beginning after December 31, 2017, and interim periods within those fiscal years, with early adoption permitted for reporting periods beginning after December 15, 2016. Subsequently, the FASB issued ASUs in 2016 containing implementation guidance related to ASU 2014-09, including: ASU 2016-08, Revenue from Contracts with Customers (Topic 606): Principal versus Agent Considerations (Reporting Revenue Gross versus Net), which is intended to improve the operability and understandability of the implementation guidance on principal versus agent considerations; ASU 2016-10, Revenue from Contracts with Customers (Topic 606): Identifying Performance Obligations and Licensing, which is intended to clarify two aspects of Topic 606: identifying performance obligations and the licensing implementation guidance; ASU 2016-12, Revenue from Contracts with Customers (Topic 606): Narrow-Scope Improvements and Practical Expedients, which contains certain provisions and practical expedients in response to identified implementation issues; and ASU 2016-20, Technical Corrections and Improvements to Topic 606, Revenue from Contracts with Customers, which is intended to clarify the Codification and/or to correct unintended application of guidance. ASU 2014-09 allows for either full retrospective or modified retrospective adoption. We adopted ASU 2014-09 and the related ASUs on January 1, 2018 using the modified retrospective method, which was applied to all contracts on the date of initial adoption.

[0001564590-18-019154:notes:15]
These ASUs primarily affected our network implementation service revenue performance obligations and contract costs. We are using the “output method” to measure network implementation services progress, which 1) accelerates revenue recognition for certain performance obligations related to service revenue arrangements that were previously deferred until customer acceptance and 2) requires capitalization and amortization of the incremental costs of obtaining a contract as described below.

[0001564590-18-019154:notes:16]
In connection with the adoption of the new revenue standard, effective January 1, 2018, we adopted ASC 340-40, Other Assets and Deferred Costs – Contracts with Customers, with respect to capitalization and amortization of incremental costs of obtaining a contract. As a result, certain costs of obtaining a contract, including sales commissions, will be capitalized, as the guidance requires the capitalization of all incremental costs incurred to obtain a contract with a customer that it would not have incurred if the contract had not been obtained, provided the costs are recoverable. The primary effect was the capitalization of certain sales commissions for our extended maintenance and support contracts in excess of one year and amortization of those costs over the period that the related revenue is recognized.

[0001564590-18-019154:notes:17]
The cumulative effect of the changes made to our Consolidated Balance Sheet on January 1, 2018 for the adoption of ASU 2014-09 and the related ASUs was as follows:

[0001564590-18-019154:notes:18]
| (In thousands) |  | Balance at December 31, 2017 |  |  | Adjustments due to ASU 2014-09 |  |  | Balance at January 1, 2018 |  |
| Other receivables |  | $ | 26,578 |  |  |  | 374 |  |  | $ | 26,952 |  |
| Deferred tax assets, net |  | $ | 23,428 |  |  |  | (96 | ) |  | $ | 23,332 |  |
| Retained earnings |  | $ | 922,178 |  |  |  | 278 |  |  | $ | 922,456 |  |

[0001564590-18-019154:notes:19]
The effect of the adoption of ASU 2014-09 and the related ASUs on our financial statements was as follows:

[0001564590-18-019154:notes:20]
|  |  | For the three months ended June 30, 2018 |  |
| (In thousands) |  | As Reported |  |  | Balances Without Adoption of ASC 606 |  |  | Effect of Adoption of ASC 606 |  |
| Sales |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  | $ | 115,063 |  |  |  | 115,437 |  |  | $ | (374 | ) |
| Services |  | $ | 12,985 |  |  |  | 13,430 |  |  | $ | (445 | ) |
| Cost of Sales |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  | $ | 69,629 |  |  |  | 70,003 |  |  | $ | (374 | ) |
| Services |  | $ | 8,423 |  |  |  | 8,772 |  |  | $ | (349 | ) |
| Loss before benefit for income taxes |  | $ | (11,259 | ) |  |  | (11,163 | ) |  | $ | (96 | ) |
| Benefit for income taxes |  | $ | 3,589 |  |  |  | 3,558 |  |  | $ | 31 |  |
| Net loss |  | $ | (7,670 | ) |  |  | (7,605 | ) |  | $ | (65 | ) |

[0001564590-18-019154:notes:21]
|  |  | For the six months ended June 30, 2018 |  |
| (In thousands) |  | As Reported |  |  | Balances Without Adoption of ASC 606 |  |  | Effect of Adoption of ASC 606 |  |
| Sales |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  | $ | 220,316 |  |  |  | 220,876 |  |  | $ | (560 | ) |
| Services |  | $ | 28,538 |  |  |  | 28,130 |  |  | $ | 408 |  |
| Cost of Sales |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  | $ | 138,241 |  |  |  | 138,726 |  |  | $ | (485 | ) |
| Services |  | $ | 20,884 |  |  |  | 20,697 |  |  | $ | 187 |  |
| Loss before benefit for income taxes |  | $ | (26,004 | ) |  |  | (26,150 | ) |  | $ | 146 |  |
| Benefit for income taxes |  | $ | 7,520 |  |  |  | 7,556 |  |  | $ | (36 | ) |
| Net loss |  | $ | (18,484 | ) |  |  | (18,594 | ) |  | $ | 110 |  |

[0001564590-18-019154:notes:22]
|  |  | As of June 30, 2018 |  |
| (In thousands) |  | As Reported |  |  | Balances Without Adoption of ASC 606 |  |  | Effect of Adoption of ASC 606 |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Other receivables |  | $ | 28,163 |  |  |  | 28,164 |  |  | $ | (1 | ) |
| Inventory |  | $ | 120,537 |  |  |  | 120,426 |  |  | $ | 111 |  |
| Equity |  |  |  |  |  |  |  |  |  |  |  |  |
| Retained earnings |  | $ | 897,586 |  |  |  | 897,476 |  |  | $ | 110 |  |

[0001564590-18-019154:notes:23]
In January 2016, the FASB issued ASU 2016-01, Financial Instruments — Overall: Recognition and Measurement of Financial Assets and Financial Liabilities, which addresses certain aspects of the recognition, measurement, presentation and disclosure of financial instruments. Subsequently, the FASB issued ASU 2018-03, Technical Corrections and Improvements to Financial Instruments – Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities, which issued technical corrections and improvements intended to clarify certain aspects of ASU 2016-01. ASU 2016-01 was effective beginning January 1, 2018 and we now recognize any changes in the fair value of certain equity investments in net income as prescribed by the new standard rather than in other comprehensive income. We adopted ASU 2016-01 on January 1, 2018 using the modified retrospective method, which resulted in a $3.2 million reclassification of net unrealized gains from accumulated other comprehensive income to opening retained earnings. ASU 2018-03 is effective for us with the interim period beginning after June 15, 2018. We are currently evaluating the effect ASU 2018-03 will have on our consolidated financial statements.

[0001564590-18-019154:notes:24]
In March 2017, the FASB issued ASU 2017-07, Compensation – Retirement Benefits (Topic 715): Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost. ASU 2017-07 amends ASC 715, Compensation — Retirement Benefits, to require employers that present a measure of operating income in their statements of earnings to include only the service cost component of net periodic pension cost and net periodic postretirement benefit cost in operating expenses (together with other employee compensation costs). The other components of net benefit cost, including amortization of prior service cost/credit, and settlement and curtailment effects, are to be included in non-operating expenses. We adopted ASU 2017-07 on January 1, 2018. We retrospectively adopted the presentation of service cost separate from other components of net periodic pension costs. As a result, $0.1 million and $0.2 million have been reclassified from cost of sales, selling, general and administrative expenses, and research and development expense to other expense, net for the three and six months ended June 30, 2017, respectively.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001564590-18-019154:notes:25]
[same as prior period, unchanged from 0001564590-18-012467:notes:22]

[0001564590-18-019154:notes:26]
On March 19, 2018, we acquired Sumitomo Electric Lightwave Corp.’s (SEL) North American EPON business and entered into a technology license and OEM supply agreement with Sumitomo Electric Industries, Ltd. (SEI). This acquisition establishes ADTRAN as the North American market leader for EPON solutions for the cable MSO industry and it will accelerate the MSO market’s adoption of our open, programmable and scalable architectures. This transaction was accounted for as a business combination. We have included the financial results of this acquisition in our consolidated financial statements since the date of acquisition. These revenues are included in the Access & Aggregation and Customer Devices categories within the Network Solutions reportable segment.

[0001564590-18-019154:notes:27]
We recorded a bargain purchase gain of $11.3 million during the first quarter of 2018, net of income taxes, which is subject to customary working capital adjustments between the parties. The bargain purchase gain of $11.3 million represents the difference between the fair value of the net assets acquired over the cash paid. SEI, an OEM supplier based in Japan, is the global market leader in EPON. SEI’s Broadband Networks Division, through its SEL subsidiary, operated a North American EPON business that included sales, marketing, support, and region-specific engineering development. The North American EPON market is primarily driven by the Tier 1 cable MSO operators and has developed more slowly than anticipated. Through the transaction, SEI divested its North American EPON assets and established a relationship with ADTRAN. The transfer of these assets to ADTRAN, which included key customer relationships and a required assumption by ADTRAN of relatively low incremental expenses, along with the value of the technology license and OEM supply agreement, resulted in the bargain purchase gain. We have assessed the recognition and measurement of the assets acquired and liabilities assumed based on historical and forecasted data for future periods and we have concluded that our valuation procedures and resulting measures were appropriate.

[0001564590-18-019154:notes:28]
The preliminary allocation of the purchase price to the estimated fair value of the assets acquired and liabilities assumed at the acquisition date is as follows:

[0001564590-18-019154:notes:29]
| (In thousands) |  |  |  |
| Assets |  |  |  |
| Other receivables | $ | 104 |  |
| Inventory |  | 510 |  |
| Property, plant and equipment |  | 392 |  |
| Intangible assets |  | 22,100 |  |
| Total assets acquired |  | 23,106 |  |
| Liabilities |  |  |  |
| Deferred income taxes |  | (3,978 | ) |
| Total liabilities assumed |  | (3,978 | ) |
| Total net assets |  | 19,128 |  |
| Gain on bargain purchase of a business, net of tax |  | (11,322 | ) |
| Total purchase price | $ | 7,806 |  |

[0001564590-18-019154:notes:30]
The actual revenue and net loss included in our Consolidated Statements of Income for the three months ended June 30, 2018 and the period March 19, 2018 to June 30, 2018 are as follows:

[0001564590-18-019154:notes:31]
|  | Three Months Ended |  |  | March 19, 2018 to |  |
| (In thousands) | June 30, 2018 |  |  | June 30, 2018 |  |
| Revenue | $ | 1,197 |  |  | $ | 1,197 |  |
| Net loss | $ | (809 | ) |  | $ | (886 | ) |

[0001564590-18-019154:notes:32]
[same as prior period, unchanged from 0001564590-18-012467:notes:29]

[0001564590-18-019154:notes:33]
| (In thousands) | Value |  |  | Life (years) |  |
| Customer relationships | $ | 13,400 |  |  |  | 12.0 |  |
| Licensed technology |  | 5,900 |  |  |  | 9.0 |  |
| Supplier relationship |  | 2,800 |  |  |  | 2.0 |  |
| Total | $ | 22,100 |  |  |  |  |  |

[0001564590-18-019154:notes:34]
[same as prior period, unchanged from 0001564590-18-012467:notes:31]

[0001564590-18-019154:notes:35]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Pro forma revenue |  | $ | 187,987 |  |  | $ | 250,114 |  |  | $ | 358,679 |  |
| Pro forma net income (loss) |  | $ | 11,628 |  |  | $ | (31,020 | ) |  | $ | 28,829 |  |
| Pro forma earnings per share - basic |  | $ | 0.24 |  |  | $ | (0.65 | ) |  | $ | 0.60 |  |
| Pro forma earnings per share - diluted |  | $ | 0.24 |  |  | $ | (0.65 | ) |  | $ | 0.59 |  |

[0001564590-18-019154:notes:36]
For the three and six months ended June 30, 2018, we incurred acquisition and integration related expenses and amortization of acquired intangibles of $0.8 million and $1.0 million, respectively, related to this acquisition.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001564590-18-019154:notes:37]
[same as prior period, unchanged from 0001564590-18-012467:notes:34]

[0001564590-18-019154:notes:38]
Revenue is measured based on the consideration we expect to receive in exchange for transferring goods or providing services to a customer and as performance obligations under the terms of the contract are satisfied. Generally, this occurs with the transfer of control of a product or service to the customer. For transactions where there are multiple performance obligations, we account for individual products and services separately if they are distinct (if a product or service is separately identifiable from other items and if a customer can benefit from it on its own or with other resources that are readily available to the customer). The consideration, including any discounts, is allocated between separate products and services based on their stand-alone selling prices. The stand-alone selling prices are determined based on the prices at which we sell the separate products and services and are allocated based on each item’s relative value to the total value of the products and services in the arrangement. For items that are not sold separately, we estimate stand-alone selling prices primarily using the “expected cost plus a margin” approach. Payment terms are typically 30 days. Shipping fees are recorded as revenue and the related cost is included in cost of sales. Sales, value-added, and other taxes collected concurrently with revenue-producing activities are excluded from revenue. Costs of obtaining a contract are capitalized and amortized over the period that the related revenue is recognized if greater than one year. We have elected to apply the practical expedient related to the incremental costs of obtaining contracts and recognize those costs as an expense when incurred if the amortization period of the assets is one year or less. These costs are included in selling, general and administrative expenses. Capitalized costs with an amortization period greater than one year were immaterial.

[0001564590-18-019154:notes:39]
[same as prior period, unchanged from 0001564590-18-012467:notes:36]

[0001564590-18-019154:notes:40]
[same as prior period, unchanged from 0001564590-18-012467:notes:37]

[0001564590-18-019154:notes:41]
[same as prior period, unchanged from 0001564590-18-012467:notes:38]

[0001564590-18-019154:notes:42]
[same as prior period, unchanged from 0001564590-18-012467:notes:39]

[0001564590-18-019154:notes:43]
The majority of the revenue from this segment is from hardware sales and is recognized when control is transferred to our customers, which is generally when we ship the products. Shipping terms are generally FOB shipping point. Revenue is recorded net of estimated discounts and rebates using the most likely amount. Customers are typically invoiced when control is transferred and revenue is recognized. Our products generally include assurance-based warranties of 90 days to five years for product defects, which are accrued at the time revenue is recognized.

[0001564590-18-019154:notes:44]
In certain transactions, we are also the lessor in sales-type lease arrangements for network equipment that have terms of 18 months to five years. These arrangements typically include network equipment, network implementation services and maintenance services. Product revenue for these leases is generally recorded when we transfer control of the product to our customers. Revenue for network implementation and maintenance services is recognized as described below. Customers are typically invoiced and pay in equal installments over the lease term. In relation to these lease agreements, during the three months ended June 30, 2018 and 2017, we recognized revenue of $4.0 million and $5.2 million, respectively, and during the six months ended June 30, 2018 and 2017 we recognized revenue of $6.3 million and $7.0 million, respectively.

[0001564590-18-019154:notes:45]
[same as prior period, unchanged from 0001564590-18-012467:notes:42]

[0001564590-18-019154:notes:46]
To complement our Network Solutions segment, we offer a complete portfolio of maintenance, network implementation, solutions integration and managed services, which include hosted cloud services and subscription services.

[0001564590-18-019154:notes:47]
[same as prior period, unchanged from 0001564590-18-012467:notes:44]

[0001564590-18-019154:notes:48]
Our maintenance service periods range from one month to five years. Customers are typically invoiced and pay for maintenance services at the beginning of the maintenance period. Payments received are recorded in current or non-current unearned revenue depending on the length of the service period. We recognize revenue for maintenance services on a straight-line basis over the maintenance period in services revenue as our customers benefit evenly throughout the contract term.

[0001564590-18-019154:notes:49]
[same as prior period, unchanged from 0001564590-18-012467:notes:46]

[0001564590-18-019154:notes:50]
We recognize revenue for network implementation, which primarily consists of engineering, execution and enablement services, at a point in time when each performance obligation is complete. If we have recognized revenue, but have not billed the customer, the right to consideration is recognized as a contract asset that is included in other receivables in the Consolidated Balance Sheet. The contract asset is transferred to accounts receivable when the completed performance obligation is invoiced to the customer.

[0001564590-18-019154:notes:51]
As of June 30, 2018, we did not have any remaining performance obligations related to customer contracts that had an original expected duration of one year or more, other than maintenance services, which are satisfied over time.

[0001564590-18-019154:notes:52]
[same as prior period, unchanged from 0001564590-18-012467:notes:49]

[0001564590-18-019154:notes:53]
| (In thousands) |  | June 30, 2018 |  |  | January 1, 2018 |  |
| Accounts receivable |  | $ | 76,135 |  |  | $ | 144,150 |  |
| Contract assets |  |  | 1,672 |  |  |  | 374 |  |
| Unearned revenue |  |  | 14,307 |  |  |  | 13,070 |  |
| Non-current unearned revenue |  |  | 3,639 |  |  |  | 4,556 |  |

[0001564590-18-019154:notes:54]
The decrease in accounts receivable is due to the collection of customer specific payment terms that became due in the first quarter of 2018. The increase in the contract asset balance for the six months ended June 30, 2018 is primarily attributable to revenue recognized that has not yet been billed to the customer during the period. The increase in the unearned revenue balance as of June 30, 2018 is primarily attributable to cash payments received or due in advance of satisfying our performance obligations, offset by $7.1 million of revenues recognized that were included in the unearned revenue balance as of December 31, 2017.

[0001564590-18-019154:notes:55]
The following table disaggregates our revenue by major source for the three months ended June 30, 2018:

[0001564590-18-019154:notes:56]
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 75,222 |  |  | $ | 9,520 |  |  | $ | 84,742 |  |
| Customer Devices |  |  | 33,306 |  |  |  | 1,254 |  |  |  | 34,560 |  |
| Traditional & Other Products |  |  | 6,535 |  |  |  | 2,211 |  |  |  | 8,746 |  |
| Total |  | $ | 115,063 |  |  | $ | 12,985 |  |  | $ | 128,048 |  |

[0001564590-18-019154:notes:57]
The following table disaggregates our revenue by major source for the six months ended June 30, 2018:

[0001564590-18-019154:notes:58]
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 144,607 |  |  | $ | 21,815 |  |  | $ | 166,422 |  |
| Customer Devices |  |  | 62,083 |  |  |  | 2,578 |  |  |  | 64,661 |  |
| Traditional & Other Products |  |  | 13,626 |  |  |  | 4,145 |  |  |  | 17,771 |  |
| Total |  | $ | 220,316 |  |  | $ | 28,538 |  |  | $ | 248,854 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-18-019154:notes:59]
[same as prior period, unchanged from 0001564590-18-012467:notes:54]

[0001564590-18-019154:notes:60]
Our effective tax rate decreased from an expense of 27.3% in the six months ended June 30, 2017, to a benefit of 20.1%, excluding the tax effect of the bargain purchase gain, in the six months ended June 30, 2018. The decrease in the effective tax rate between the two periods is primarily attributable to the change in income and the effect of the U.S. Tax Cuts and Jobs Act, which was signed into law on December 22, 2017.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001564590-18-019154:notes:61]
[same as prior period, unchanged from 0001564590-18-012467:notes:56]

[0001564590-18-019154:notes:62]
[same as prior period, unchanged from 0001564590-18-012467:notes:57]

[0001564590-18-019154:notes:63]
The following table summarizes the components of net periodic pension cost for the three and six months ended June 30, 2018 and 2017:

[0001564590-18-019154:notes:64]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Service cost |  | $ | 303 |  |  | $ | 306 |  |  | $ | 611 |  |  | $ | 603 |  |
| Interest cost |  |  | 185 |  |  |  | 147 |  |  |  | 372 |  |  |  | 290 |  |
| Expected return on plan assets |  |  | (394 | ) |  |  | (307 | ) |  |  | (793 | ) |  |  | (606 | ) |
| Amortization of actuarial losses |  |  | 63 |  |  |  | 75 |  |  |  | 127 |  |  |  | 148 |  |
| Net periodic pension cost |  | $ | 157 |  |  | $ | 221 |  |  | $ | 317 |  |  | $ | 435 |  |

[0001564590-18-019154:notes:65]
The components of net periodic pension cost other than the service cost component are included in the line item “Other expense, net” in the Consolidated Statements of Income.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-18-019154:notes:66]
[same as prior period, unchanged from 0001564590-18-012467:notes:61]

[0001564590-18-019154:notes:67]
The following table summarizes the stock-based compensation expense related to stock options, performance stock units (PSUs), restricted stock units (RSUs) and restricted stock for the three and six months ended June 30, 2018 and 2017, which was recognized as follows:

[0001564590-18-019154:notes:68]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Stock-based compensation expense included in cost of sales |  | $ | 102 |  |  | $ | 93 |  |  | $ | 197 |  |  | $ | 184 |  |
| Selling, general and administrative expense |  |  | 995 |  |  |  | 1,008 |  |  |  | 2,030 |  |  |  | 2,024 |  |
| Research and development expense |  |  | 687 |  |  |  | 755 |  |  |  | 1,376 |  |  |  | 1,531 |  |
| Stock-based compensation expense included in operating expenses |  |  | 1,682 |  |  |  | 1,763 |  |  |  | 3,406 |  |  |  | 3,555 |  |
| Total stock-based compensation expense |  |  | 1,784 |  |  |  | 1,856 |  |  |  | 3,603 |  |  |  | 3,739 |  |
| Tax benefit for expense associated with non-qualified options, PSUs, RSUs and restricted stock |  |  | (340 | ) |  |  | (433 | ) |  |  | (724 | ) |  |  | (813 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 1,444 |  |  | $ | 1,423 |  |  | $ | 2,879 |  |  | $ | 2,926 |  |

[0001564590-18-019154:notes:69]
[same as prior period, unchanged from 0001564590-18-012467:notes:64]

[0001564590-18-019154:notes:70]
The following table is a summary of our stock options outstanding as of December 31, 2017 and June 30, 2018 and the changes that occurred during the six months ended June 30, 2018:

[0001564590-18-019154:notes:71]
| (In thousands, except per share amounts) |  | Number of Stock Options |  |  | Weighted Avg. Exercise Price |  |  | Weighted Avg. Remaining Contractual Life In Years |  |  | Aggregate Intrinsic Value |  |
| Stock options outstanding, December 31, 2017 |  |  | 5,148 |  |  | $ | 22.65 |  |  |  | 4.87 |  |  | $ | 6,109 |  |
| Stock options granted |  |  | — |  |  | $ | — |  |  |  |  |  |  |  |  |  |
| Stock options exercised |  |  | (24 | ) |  | $ | 15.48 |  |  |  |  |  |  |  |  |  |
| Stock options forfeited |  |  | (42 | ) |  | $ | 16.54 |  |  |  |  |  |  |  |  |  |
| Stock options expired |  |  | (282 | ) |  | $ | 25.63 |  |  |  |  |  |  |  |  |  |
| Stock options outstanding, June 30, 2018 |  |  | 4,800 |  |  | $ | 22.56 |  |  |  | 4.39 |  |  | $ | — |  |
| Stock options vested and expected to vest, June 30, 2018 |  |  | 4,800 |  |  | $ | 22.56 |  |  |  | 4.39 |  |  | $ | — |  |
| Stock options exercisable, June 30, 2018 |  |  | 4,063 |  |  | $ | 23.67 |  |  |  | 3.90 |  |  | $ | — |  |

[0001564590-18-019154:notes:72]
The aggregate intrinsic values in the table above represent the total pre-tax intrinsic value (the difference between the closing price of our stock on the last trading day of the quarter and the exercise price, multiplied by the number of in-the-money stock options) that would have been received by the option holders had all option holders exercised their options on June 30, 2018. The aggregate intrinsic value will change based on the fair market value of our stock.

[0001564590-18-019154:notes:73]
The total pre-tax intrinsic value of options exercised during the six months ended June 30, 2018 was $33 thousand. There were no options exercised during the three months ended June 30, 2018.

[0001564590-18-019154:notes:74]
As of June 30, 2018, there was $1.9 million of unrecognized compensation expense related to unvested stock options, which is expected to be recognized over an average remaining recognition period of 1.1 years.

[0001564590-18-019154:notes:75]
[same as prior period, unchanged from 0001564590-18-012467:notes:70]

[0001564590-18-019154:notes:76]
There were no stock options granted during the three and six months ended June 30, 2018 or 2017.

[0001564590-18-019154:notes:77]
[same as prior period, unchanged from 0001564590-18-012467:notes:72]

[0001564590-18-019154:notes:78]
The following table is a summary of our PSUs, RSUs and restricted stock outstanding as of December 31, 2017 and the changes that occurred during the six months ended June 30, 2018:

[0001564590-18-019154:notes:79]
| (In thousands, except per share amounts) |  | Number of Shares |  |  | Weighted Avg. Grant Date Fair Value |  |
| Unvested PSUs, RSUs and restricted stock outstanding, December 31, 2017 |  |  | 1,292 |  |  | $ | 21.33 |  |
| PSUs, RSUs and restricted stock granted |  |  | 8 |  |  | $ | 20.68 |  |
| PSUs, RSUs and restricted stock vested |  |  | (7 | ) |  | $ | 19.99 |  |
| PSUs, RSUs and restricted stock forfeited |  |  | (105 | ) |  | $ | 21.59 |  |
| Unvested PSUs, RSUs and restricted stock outstanding, June 30, 2018 |  |  | 1,188 |  |  | $ | 21.31 |  |

[0001564590-18-019154:notes:80]
[same as prior period, unchanged from 0001564590-18-012467:notes:75]

[0001564590-18-019154:notes:81]
As of June 30, 2018, there was $11.4 million of unrecognized compensation expense related to unvested market-based PSUs, RSUs and restricted stock, which is expected to be recognized over an average remaining recognition period of 2.7 years. In addition, there was $10.1 million of unrecognized compensation expense related to unvested performance-based PSUs, which will be recognized over the requisite service period of three years as the achievement of the performance objective becomes probable. For the three and six months ended June 30, 2018, no compensation expense was recognized related to these performance-based PSU awards.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001564590-18-019154:notes:82]
7. INVESTMENTS

[0001564590-18-019154:notes:83]
Debt Securities and Other Investments

[0001564590-18-019154:notes:84]
At June 30, 2018, we held the following debt securities and other investments, recorded at either fair value or cost:

[0001564590-18-019154:notes:85]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Carrying |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 35,896 |  |  | $ | 27 |  |  | $ | (250 | ) |  | $ | 35,673 |  |
| Municipal fixed-rate bonds |  |  | 2,259 |  |  |  | — |  |  |  | (38 | ) |  |  | 2,221 |  |
| Asset-backed bonds |  |  | 10,355 |  |  |  | 1 |  |  |  | (37 | ) |  |  | 10,319 |  |
| Mortgage/Agency-backed bonds |  |  | 7,292 |  |  |  | — |  |  |  | (85 | ) |  |  | 7,207 |  |
| U.S. government bonds |  |  | 8,953 |  |  |  | — |  |  |  | (104 | ) |  |  | 8,849 |  |
| Foreign government bonds |  |  | 1,036 |  |  |  | 2 |  |  |  | — |  |  |  | 1,038 |  |
| Available-for-sale debt securities held at fair value |  | $ | 65,791 |  |  | $ | 30 |  |  | $ | (514 | ) |  | $ | 65,307 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 26,700 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 520 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 92,527 |  |

[0001564590-18-019154:notes:86]
At December 31, 2017, we held the following debt securities and other investments, recorded at either fair value or cost:

[0001564590-18-019154:notes:87]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Carrying |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 32,654 |  |  | $ | 44 |  |  | $ | (155 | ) |  | $ | 32,543 |  |
| Municipal fixed-rate bonds |  |  | 2,902 |  |  |  | 2 |  |  |  | (22 | ) |  |  | 2,882 |  |
| Asset-backed bonds |  |  | 6,545 |  |  |  | 1 |  |  |  | (20 | ) |  |  | 6,526 |  |
| Mortgage/Agency-backed bonds |  |  | 5,554 |  |  |  | 1 |  |  |  | (46 | ) |  |  | 5,509 |  |
| U.S. government bonds |  |  | 14,477 |  |  |  | — |  |  |  | (174 | ) |  |  | 14,303 |  |
| Foreign government bonds |  |  | 725 |  |  |  | 5 |  |  |  | — |  |  |  | 730 |  |
| Available-for-sale debt securities held at fair value |  | $ | 62,857 |  |  | $ | 53 |  |  | $ | (417 | ) |  | $ | 62,493 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 27,800 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 547 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 90,840 |  |

[0001564590-18-019154:notes:88]
As of June 30, 2018, our debt securities had the following contractual maturities:

[0001564590-18-019154:notes:89]
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset- backed bonds |  |  | Mortgage / Agency- backed bonds |  |  | U.S. government bonds |  |  | Foreign government bonds |  |
| Less than one year |  | $ | 1,500 |  |  | $ | 490 |  |  | $ | 4,079 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| One to two years |  |  | 16,694 |  |  |  | 603 |  |  |  | 2,270 |  |  |  | — |  |  |  | 1,519 |  |  |  | 729 |  |
| Two to three years |  |  | 12,264 |  |  |  | 1,128 |  |  |  | 556 |  |  |  | — |  |  |  | 3,845 |  |  |  | 309 |  |
| Three to five years |  |  | 5,215 |  |  |  | — |  |  |  | 1,939 |  |  |  | 1,970 |  |  |  | 3,485 |  |  |  | — |  |
| Five to ten years |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 588 |  |  |  | — |  |  |  | — |  |
| More than ten years |  |  | — |  |  |  | — |  |  |  | 1,475 |  |  |  | 4,649 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 35,673 |  |  | $ | 2,221 |  |  | $ | 10,319 |  |  | $ | 7,207 |  |  | $ | 8,849 |  |  | $ | 1,038 |  |

[0001564590-18-019154:notes:90]
Actual maturities may differ from contractual maturities because some borrowers have the right to call or prepay obligations with or without call or prepayment penalties.

[0001564590-18-019154:notes:91]
Realized gains and losses on sales of debt securities are computed under the specific identification method. The following table presents gross realized gains and losses related to our debt securities:

[0001564590-18-019154:notes:92]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Gross realized gains |  | $ | 25 |  |  | $ | 33 |  |  | $ | 25 |  |  | $ | 57 |  |
| Gross realized losses |  | $ | (241 | ) |  | $ | (113 | ) |  | $ | (315 | ) |  | $ | (152 | ) |

[0001564590-18-019154:notes:93]
Our investment policy provides limitations for issuer concentration, which limits, at the time of purchase, the concentration in any one issuer to 5% of the market value of our total investment portfolio.

[0001564590-18-019154:notes:94]
At June 30, 2018, we held a $26.7 million restricted certificate of deposit that is carried at cost. This investment serves as a collateral deposit against the principal amount outstanding under loans made to ADTRAN pursuant to an Alabama State Industrial Development Authority revenue bond (the Bond), which totaled $26.7 million at June 30, 2018 and December 31, 2017. At June 30, 2018 and December 31, 2017, the estimated fair value of the Bond using a level 2 valuation technique was approximately $26.5 million and $26.7 million, respectively, based on a debt security with a comparable interest rate and maturity and a Standard and Poor’s credit rating of AAA. We have the right to set-off the balance of the Bond with the collateral deposit in order to reduce the balance of the indebtedness. The Bond matures on January 1, 2020, and bears interest at the rate of 2% per annum. In conjunction with this program, we are eligible to receive certain economic incentives from the state of Alabama that reduce the amount of payroll withholdings we are required to remit to the state for those employment positions that qualify under this program. We are required to make payments in the amounts necessary to pay the interest on the amounts currently outstanding. It is our intent to make annual principal payments in addition to the interest amounts that are due.

[0001564590-18-019154:notes:95]
Marketable Equity Securities

[0001564590-18-019154:notes:96]
Our marketable equity securities consist of publicly traded stocks or funds measured at fair value.

[0001564590-18-019154:notes:97]
Prior to January 1, 2018, our marketable equity securities were classified as available-for-sale. Realized gains and losses on marketable equity securities were included in net realized investment gain (loss). Unrealized gains and losses were recognized in accumulated other comprehensive income, net of deferred taxes, on the balance sheet.

[0001564590-18-019154:notes:98]
On January 1, 2018, we adopted ASU 2016-01, which requires us to measure all equity investments that do not result in consolidation and are not accounted for under the equity method at fair value, with any changes in fair value recognized in net realized investment gain (loss). Upon adoption, we reclassified $3.2 million of net unrealized gains related to marketable equity securities from accumulated other comprehensive income (loss) to opening retained earnings.

[0001564590-18-019154:notes:99]
Realized and unrealized gains and losses for our marketable equity securities for the three and six months ended June 30, 2018 were as follows:

[0001564590-18-019154:notes:100]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2018 |  |  | 2018 |  |
| Realized gains (losses) on equity securities sold |  | $ | (52 | ) |  | $ | 347 |  |
| Unrealized gains (losses) on equity securities held |  |  | 1,258 |  |  |  | 836 |  |
| Total gain (loss) recognized, net |  | $ | 1,206 |  |  | $ | 1,183 |  |

[0001564590-18-019154:notes:101]
As of June 30, 2018 and 2017, gross unrealized losses related to individual investments in a continuous loss position for 12 months or longer were not significant.

[0001564590-18-019154:notes:102]
We have categorized our cash equivalents and our investments held at fair value into a three-level fair value hierarchy based on the priority of the inputs to the valuation technique for the cash equivalents and investments as follows:  Level 1 - Values based on unadjusted quoted prices for identical assets or liabilities in an active market; Level 2 - Values based on quoted prices in markets that are not active or model inputs that are observable either directly or indirectly; Level 3 - Values based on prices or valuation techniques that require inputs that are both unobservable and significant to the overall fair value measurement. These inputs include information supplied by investees.

[0001564590-18-019154:notes:103]
|  |  | Fair Value Measurements at June 30, 2018 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 2,008 |  |  | $ | 2,008 |  |  | $ | — |  |  | $ | — |  |
| Foreign government securities |  |  | 350 |  |  |  | — |  |  |  | 350 |  |  |  | — |  |
| Cash equivalents |  |  | 2,358 |  |  |  | 2,008 |  |  |  | 350 |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 35,673 |  |  |  | — |  |  |  | 35,673 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 2,221 |  |  |  | — |  |  |  | 2,221 |  |  |  | — |  |
| Asset-backed bonds |  |  | 10,319 |  |  |  | — |  |  |  | 10,319 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 7,207 |  |  |  | — |  |  |  | 7,207 |  |  |  | — |  |
| U.S. government bonds |  |  | 8,849 |  |  |  | 8,849 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 1,038 |  |  |  | — |  |  |  | 1,038 |  |  |  | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 37,600 |  |  |  | 37,600 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 20,379 |  |  |  | 20,379 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 123,286 |  |  |  | 66,828 |  |  |  | 56,458 |  |  |  | — |  |
| Total |  | $ | 125,644 |  |  | $ | 68,836 |  |  | $ | 56,808 |  |  | $ | — |  |

[0001564590-18-019154:notes:104]
|  |  | Fair Value Measurements at December 31, 2017 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 5,851 |  |  | $ | 5,851 |  |  | $ | — |  |  | $ | — |  |
| Commercial paper |  |  | 3,999 |  |  |  | — |  |  |  | 3,999 |  |  |  | — |  |
| Cash equivalents |  |  | 9,850 |  |  |  | 5,851 |  |  |  | 3,999 |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 32,543 |  |  |  | — |  |  |  | 32,543 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 2,882 |  |  |  | — |  |  |  | 2,882 |  |  |  | — |  |
| Asset-backed bonds |  |  | 6,526 |  |  |  | — |  |  |  | 6,526 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 5,509 |  |  |  | — |  |  |  | 5,509 |  |  |  | — |  |
| U.S. government bonds |  |  | 14,303 |  |  |  | 14,303 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 730 |  |  |  | — |  |  |  | 730 |  |  |  | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 35,662 |  |  |  | 35,662 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 19,883 |  |  |  | 19,883 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 118,038 |  |  |  | 69,848 |  |  |  | 48,190 |  |  |  | — |  |
| Total |  | $ | 127,888 |  |  | $ | 75,699 |  |  | $ | 52,189 |  |  | $ | — |  |

[0001564590-18-019154:notes:105]
The fair value of our Level 2 securities is calculated using a weighted average market price for each security. Market prices are obtained from a variety of industry standard data providers, security master files from large financial institutions, and other third-party sources. These multiple market prices are used as inputs into a distribution-curve-based algorithm to determine the daily market value of each security.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001564590-18-019154:notes:106]
[same as prior period, unchanged from 0001564590-18-012467:notes:101]

[0001564590-18-019154:notes:107]
[same as prior period, unchanged from 0001564590-18-012467:notes:102]

[0001564590-18-019154:notes:108]
[same as prior period, unchanged from 0001564590-18-012467:notes:103]

[0001564590-18-019154:notes:109]
Our cash flow hedging activities utilize foreign exchange forward contracts to reduce the risk that movements in exchange rates will adversely affect the net cash flows resulting from the planned purchase of products from foreign suppliers. Purchases of U.S. denominated inventory by our European subsidiary represent our primary exposure. Changes in the fair value of derivatives designated as cash flow hedges are not recognized in current operating results, but are recorded in accumulated other comprehensive income.  Amounts related to cash flow hedges are reclassified from accumulated other comprehensive income when the underlying hedged item impacts earnings. This reclassification is recorded in cost of sales, the same line item of the Consolidated Statements of Income at which the effects of the hedged item are recorded.

[0001564590-18-019154:notes:110]
[same as prior period, unchanged from 0001564590-18-012467:notes:105]

[0001564590-18-019154:notes:111]
We have certain customers and suppliers who are invoiced or pay in a non-functional currency. Changes in the monetary exchange rates may adversely affect our results of operations and financial condition, as outstanding non-functional balances are revalued to the functional currency through profit and loss. When appropriate, we utilize foreign exchange forward contracts to help manage the volatility relating to these valuation exposures. All changes in the fair value of our derivative instruments that do not qualify for or are not designated for hedged accounting transactions are recognized as other expense, net in the Consolidated Statements of Income.

[0001564590-18-019154:notes:112]
[same as prior period, unchanged from 0001564590-18-012467:notes:107]

[0001564590-18-019154:notes:113]
As of June 30, 2018, we had no foreign exchange forward contracts.

[0001564590-18-019154:notes:114]
The changes in the fair values of our derivative instruments recorded in the Consolidated Statements of Income during the three and six months ended June 30, 2018 and 2017 were as follows:

[0001564590-18-019154:notes:115]
|  |  |  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | Income Statement |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | Location |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Derivatives Not Designated as Hedging Instruments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Other expense, net |  | $ | — |  |  | $ | (451 | ) |  | $ | 13 |  |  | $ | (485 | ) |

[0001564590-18-019154:notes:116]
The changes in our derivatives designated as hedging instruments recorded in other comprehensive income (OCI) and reclassified to income, net of tax, during the three and six months ended June 30, 2018 and 2017, were as follows:

[0001564590-18-019154:notes:117]
|  |  | Amount of Gains (Losses) Recognized in |  |  |  |  | Amount of Gains (Losses) Reclassified |  |
|  |  | OCI on Derivatives |  |  |  |  | from AOCI into Income |  |
|  |  | Three Months Ended |  |  | Location of Gains |  | Three Months Ended |  |
|  |  | June 30, |  |  | (Losses) Reclassified |  | June 30, |  |
| (In thousands) |  | 2018 |  |  | 2017 |  |  | from AOCI into Income |  | 2018 |  |  | 2017 |  |
| Derivatives Designated as Hedging Instruments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | — |  |  | $ | (571 | ) |  | Cost of Sales |  | $ | — |  |  | $ | (154 | ) |

[0001564590-18-019154:notes:118]
|  |  | Amount of Gains (Losses) Recognized in |  |  |  |  | Amount of Gains (Losses) Reclassified |  |
|  |  | OCI on Derivatives |  |  |  |  | from AOCI into Income |  |
|  |  | Six Months Ended |  |  | Location of Gains |  | Six Months Ended |  |
|  |  | June 30, |  |  | (Losses) Reclassified |  | June 30, |  |
| (In thousands) |  | 2018 |  |  | 2017 |  |  | from AOCI into Income |  | 2018 |  |  | 2017 |  |
| Derivatives Designated as Hedging Instruments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | $ | — |  |  | $ | (492 | ) |  | Cost of Sales |  | $ | — |  |  | $ | (154 | ) |


## us-gaap:InventoryDisclosureTextBlock

[0001564590-18-019154:notes:119]
[same as prior period, unchanged from 0001564590-18-012467:notes:113]

[0001564590-18-019154:notes:120]
At June 30, 2018 and December 31, 2017, inventory consisted of the following:

[0001564590-18-019154:notes:121]
|  |  | June 30, |  |  | December 31, |  |
| (In thousands) |  | 2018 |  |  | 2017 |  |
| Raw materials |  | $ | 50,844 |  |  | $ | 44,185 |  |
| Work in process |  |  | 1,985 |  |  |  | 1,939 |  |
| Finished goods |  |  | 67,708 |  |  |  | 76,418 |  |
| Total |  | $ | 120,537 |  |  | $ | 122,542 |  |

[0001564590-18-019154:notes:122]
We establish reserves for estimated excess, obsolete, or unmarketable inventory equal to the difference between the cost of the inventory and the estimated fair value of the inventory based upon assumptions about future demand and market conditions. At June 30, 2018 and December 31, 2017, raw materials reserves totaled $17.5 million and $15.0 million, respectively, and finished goods inventory reserves totaled $9.7 million and $8.3 million, respectively.


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001564590-18-019154:notes:123]
[same as prior period, unchanged from 0001564590-18-012467:notes:117]

[0001564590-18-019154:notes:124]
Goodwill, all of which relates to our acquisition of Bluesocket, Inc., was $3.5 million at June 30, 2018 and December 31, 2017, of which $3.1 million and $0.4 million is allocated to our Network Solutions and Services & Support reportable segments, respectively.

[0001564590-18-019154:notes:125]
[same as prior period, unchanged from 0001564590-18-012467:notes:119]

[0001564590-18-019154:notes:126]
[same as prior period, unchanged from 0001564590-18-012467:notes:120]

[0001564590-18-019154:notes:127]
The following table presents our intangible assets as of June 30, 2018 and December 31, 2017. Fully amortized intangible assets have been removed from prior year balances for comparability.

[0001564590-18-019154:notes:128]
| (In thousands) |  | June 30, 2018 |  |  | December 31, 2017 |  |
|  |  | Gross Value |  |  | Accumulated Amortization |  |  | Net Value |  |  | Gross Value |  |  | Accumulated Amortization |  |  | Net Value |  |
| Customer relationships |  | $ | 20,752 |  |  | $ | (4,781 | ) |  | $ | 15,971 |  |  | $ | 7,474 |  |  | $ | (4,283 | ) |  | $ | 3,191 |  |
| Licensed technology |  |  | 5,900 |  |  |  | (191 | ) |  |  | 5,709 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Developed technology |  |  | 5,452 |  |  |  | (4,772 | ) |  |  | 680 |  |  |  | 5,524 |  |  |  | (4,663 | ) |  |  | 861 |  |
| Supplier relationship |  |  | 2,800 |  |  |  | (408 | ) |  |  | 2,392 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Intellectual property |  |  | 930 |  |  |  | (919 | ) |  |  | 11 |  |  |  | 930 |  |  |  | (852 | ) |  |  | 78 |  |
| Patent |  |  | 500 |  |  |  | (123 | ) |  |  | 377 |  |  |  | 500 |  |  |  | (89 | ) |  |  | 411 |  |
| Non-compete |  |  | 200 |  |  |  | (159 | ) |  |  | 41 |  |  |  | 200 |  |  |  | (115 | ) |  |  | 85 |  |
| Trade names |  |  | 100 |  |  |  | (90 | ) |  |  | 10 |  |  |  | 100 |  |  |  | (65 | ) |  |  | 35 |  |
| Total |  | $ | 36,634 |  |  | $ | (11,443 | ) |  | $ | 25,191 |  |  | $ | 14,728 |  |  | $ | (10,067 | ) |  | $ | 4,661 |  |

[0001564590-18-019154:notes:129]
Amortization expense, all of which relates to business acquisitions, was $1.0 million and $1.1 million for the three months ended June 30, 2018 and 2017, respectively, and $1.5 million and $1.9 million for the six months ended June 30, 2018 and 2017, respectively.

[0001564590-18-019154:notes:130]
As of June 30, 2018, the estimated future amortization expense of our intangible assets is as follows:

[0001564590-18-019154:notes:131]
| (In thousands) |  | Amount |  |
| Remainder of 2018 |  | $ | 1,785 |  |
| 2019 |  |  | 3,542 |  |
| 2020 |  |  | 2,659 |  |
| 2021 |  |  | 2,365 |  |
| 2022 |  |  | 2,352 |  |
| Thereafter |  |  | 12,488 |  |
| Total |  | $ | 25,191 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001564590-18-019154:notes:132]
[same as prior period, unchanged from 0001564590-18-012467:notes:126]

[0001564590-18-019154:notes:133]
A summary of the changes in stockholders’ equity for the six months ended June 30, 2018 is as follows:

[0001564590-18-019154:notes:134]
| (In thousands) |  | Stockholders’ Equity |  |
| Balance, December 31, 2017 |  | $ | 497,911 |  |
| Net income (loss) |  |  | (18,484 | ) |
| Dividend payments |  |  | (8,679 | ) |
| Dividends accrued for unvested restricted stock units |  |  | 5 |  |
| Net unrealized gains (losses) on available-for-sale securities (net of tax) |  |  | (3,308 | ) |
| Defined benefit plan adjustments (net of tax) |  |  | 67 |  |
| Foreign currency translation adjustment |  |  | (2,582 | ) |
| Proceeds from stock option exercises |  |  | 369 |  |
| Purchase of treasury stock |  |  | (12,774 | ) |
| Adoption of new accounting standards (see Note 1) |  |  | 3,499 |  |
| Stock-based compensation expense |  |  | 3,603 |  |
| Balance, June 30, 2018 |  | $ | 459,627 |  |

[0001564590-18-019154:notes:135]
[same as prior period, unchanged from 0001564590-18-012467:notes:129]

[0001564590-18-019154:notes:136]
Since 1997, our Board of Directors has approved multiple share repurchase programs that have authorized open market repurchase transactions of up to 50.0 million shares of our common stock that are implemented through open market or private purchases from time to time as conditions warrant. During the six months ended June 30, 2018, we repurchased 0.8 million shares of our common stock at an average price of $15.72 per share. As of June 30, 2018, we have the authority to purchase an additional 2.7 million shares of our common stock under the current plans approved by the Board of Directors.

[0001564590-18-019154:notes:137]
[same as prior period, unchanged from 0001564590-18-012467:notes:131]

[0001564590-18-019154:notes:138]
We issued 24 thousand shares of treasury stock during the six months ended June 30, 2018 to accommodate employee stock option exercises. The stock options had exercise prices ranging from $15.29 to $18.97. We received proceeds totaling $0.4 million from the exercise of these stock options during the six months ended June 30, 2018.

[0001564590-18-019154:notes:139]
[same as prior period, unchanged from 0001564590-18-012467:notes:133]

[0001564590-18-019154:notes:140]
During the six months ended June 30, 2018, we paid cash dividends as follows (in thousands except per share amounts):

[0001564590-18-019154:notes:141]
| Record Date |  | Payment Date |  | Per Share Amount |  |  | Total Dividend Paid |  |
| January 31, 2018 |  | February 14, 2018 |  | $ | 0.09 |  |  | $ | 4,367 |  |
| May 2, 2018 |  | May 16, 2018 |  | $ | 0.09 |  |  | $ | 4,312 |  |

[0001564590-18-019154:notes:142]
[same as prior period, unchanged from 0001564590-18-012467:notes:136]

[0001564590-18-019154:notes:143]
Other comprehensive income consists of unrealized gains (losses) on available-for-sale debt securities; unrealized gains (losses) on cash flow hedges; reclassification adjustments for amounts included in net income related to impairments of available-for-sale debt securities, realized gains (losses) on available-for-sale debt securities, realized gains (losses) on cash flow hedges, and amortization of actuarial gains (losses) related to our defined benefit plan; defined benefit plan adjustments; and foreign currency translation adjustments.

[0001564590-18-019154:notes:144]
The following tables present the changes in accumulated other comprehensive income (loss), net of tax, by component for the three months ended June 30, 2018 and 2017:

[0001564590-18-019154:notes:145]
|  |  | Three Months Ended June 30, 2018 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | Total |  |
| Beginning balance |  | $ | (845 | ) |  | $ | (4,224 | ) |  | $ | (734 | ) |  | $ | (5,803 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | (82 | ) |  |  | — |  |  |  | (3,424 | ) |  |  | (3,506 | ) |
| Amounts reclassified from accumulated other comprehensive income (loss) |  |  | 186 |  |  |  | 5 |  |  |  | — |  |  |  | 191 |  |
| Net current period other comprehensive income (loss) |  |  | 104 |  |  |  | 5 |  |  |  | (3,424 | ) |  |  | (3,315 | ) |
| Ending balance |  | $ | (741 | ) |  | $ | (4,219 | ) |  | $ | (4,158 | ) |  | $ | (9,118 | ) |

[0001564590-18-019154:notes:146]
|  |  | Three Months Ended June 30, 2017 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Unrealized Gains (Losses) on Cash Flow Hedges |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | Total |  |
| Beginning balance |  | $ | 1,739 |  |  | $ | 79 |  |  | $ | (4,962 | ) |  | $ | (6,333 | ) |  | $ | (9,477 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | 1,222 |  |  |  | (571 | ) |  |  | — |  |  |  | 2,619 |  |  |  | 3,270 |  |
| Amounts reclassified from accumulated other comprehensive income (loss) |  |  | (849 | ) |  |  | 154 |  |  |  | 86 |  |  |  | — |  |  |  | (609 | ) |
| Net current period other comprehensive income (loss) |  |  | 373 |  |  |  | (417 | ) |  |  | 86 |  |  |  | 2,619 |  |  |  | 2,661 |  |
| Ending balance |  | $ | 2,112 |  |  | $ | (338 | ) |  | $ | (4,876 | ) |  | $ | (3,714 | ) |  | $ | (6,816 | ) |

[0001564590-18-019154:notes:147]
The following tables present the changes in accumulated other comprehensive income (loss), net of tax, by component for the six months ended June 30, 2018 and 2017:

[0001564590-18-019154:notes:148]
|  |  | Six Months Ended June 30, 2018 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | Total |  |
| Beginning balance |  | $ | 2,567 |  |  | $ | (4,286 | ) |  | $ | (1,576 | ) |  | $ | (3,295 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | (339 | ) |  |  | — |  |  |  | (2,582 | ) |  |  | (2,921 | ) |
| Amounts reclassified from accumulated other comprehensive income (loss) |  |  | 251 |  |  |  | 67 |  |  |  | — |  |  |  | 318 |  |
| Amounts reclassified to retained earnings (1) |  |  | (3,220 | ) |  |  | — |  |  |  | — |  |  |  | (3,220 | ) |
| Net current period other comprehensive income (loss) |  |  | (3,308 | ) |  |  | 67 |  |  |  | (2,582 | ) |  |  | (5,823 | ) |
| Ending balance |  | $ | (741 | ) |  | $ | (4,219 | ) |  | $ | (4,158 | ) |  | $ | (9,118 | ) |

[0001564590-18-019154:notes:149]
|  | (1) | With the adoption of ASU 2016-01, the unrealized gains on our equity investments were reclassified to retained earnings. See Note 1 for more information. |

[0001564590-18-019154:notes:150]
|  |  | Six Months Ended June 30, 2017 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Unrealized Gains (Losses) on Cash Flow Hedges |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | Total |  |
| Beginning balance |  | $ | 404 |  |  | $ | — |  |  | $ | (5,017 | ) |  | $ | (7,575 | ) |  | $ | (12,188 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | 2,842 |  |  |  | (492 | ) |  |  | — |  |  |  | 3,861 |  |  |  | 6,211 |  |
| Amounts reclassified from accumulated other comprehensive income (loss) |  |  | (1,134 | ) |  |  | 154 |  |  |  | 141 |  |  |  | — |  |  |  | (839 | ) |
| Net current period other comprehensive income (loss) |  |  | 1,708 |  |  |  | (338 | ) |  |  | 141 |  |  |  | 3,861 |  |  |  | 5,372 |  |
| Ending balance |  | $ | 2,112 |  |  | $ | (338 | ) |  | $ | (4,876 | ) |  | $ | (3,714 | ) |  | $ | (6,816 | ) |

[0001564590-18-019154:notes:151]
The following tables present the details of reclassifications out of accumulated other comprehensive income (loss) for the three months ended June 30, 2018 and 2017:

[0001564590-18-019154:notes:152]
| (In thousands) |  | Three Months Ended June 30, 2018 |
| Details about Accumulated Other Comprehensive Income (Loss) Components |  | Amount Reclassified from Accumulated Other Comprehensive Income (Loss) |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for-sale securities: |  |  |  |  |  |  |
| Net realized gain (loss) on sales of securities |  | $ | (251 | ) |  | Net realized investment gain |
| Defined benefit plan adjustments – actuarial losses |  |  | (7 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | (258 | ) |  |  |
| Tax (expense) benefit |  |  | 67 |  |  |  |
| Total reclassifications for the period, net of tax |  | $ | (191 | ) |  |  |

[0001564590-18-019154:notes:153]
[same as prior period, unchanged from 0001564590-18-012467:notes:144]

[0001564590-18-019154:notes:154]
| (In thousands) |  | Three Months Ended June 30, 2017 |
| Details about Accumulated Other Comprehensive Income (Loss) Components |  | Amount Reclassified from Accumulated Other Comprehensive Income (Loss) |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for-sale securities: |  |  |  |  |  |  |
| Net realized gain (loss) on sales of securities |  | $ | 1,393 |  |  | Net realized investment gain |
| Impairment expense |  |  | (2 | ) |  | Net realized investment gain |
| Net losses on derivatives designated as hedging instruments |  |  | (154 | ) |  | Cost of sales |
| Defined benefit plan adjustments – actuarial losses |  |  | (124 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | 1,113 |  |  |  |
| Tax (expense) benefit |  |  | (504 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 609 |  |  |  |

[0001564590-18-019154:notes:155]
[same as prior period, unchanged from 0001564590-18-012467:notes:146]

[0001564590-18-019154:notes:156]
The following tables present the details of reclassifications out of accumulated other comprehensive income (loss) for the six months ended June 30, 2018 and 2017:

[0001564590-18-019154:notes:157]
| (In thousands) |  | Six Months Ended June 30, 2018 |
| Details about Accumulated Other Comprehensive Income (Loss) Components |  | Amount Reclassified from Accumulated Other Comprehensive Income (Loss) |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for-sale securities: |  |  |  |  |  |  |
| Net realized gain (loss) on sales of securities |  | $ | (324 | ) |  | Net realized investment gain |
| Defined benefit plan adjustments – actuarial losses |  |  | (97 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | (421 | ) |  |  |
| Tax (expense) benefit |  |  | 103 |  |  |  |
| Total reclassifications for the period, net of tax |  | $ | (318 | ) |  |  |

[0001564590-18-019154:notes:158]
| (In thousands) |  | Six Months Ended June 30, 2017 |
| Details about Accumulated Other Comprehensive Income (Loss) Components |  | Amount Reclassified from Accumulated Other Comprehensive Income (Loss) |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for- sale securities: |  |  |  |  |  |  |
| Net realized gain (loss) on sales of securities |  | $ | 1,965 |  |  | Net realized investment gain |
| Impairment expense |  |  | (105 | ) |  | Net realized investment gain |
| Net losses on derivatives designated as hedging instruments |  |  | (154 | ) |  | Cost of sales |
| Defined benefit plan adjustments – actuarial losses |  |  | (204 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | 1,502 |  |  |  |
| Tax (expense) benefit |  |  | (663 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 839 |  |  |  |

[0001564590-18-019154:notes:159]
The following table presents the tax effects related to the change in each component of other comprehensive income (loss) for the three months ended June 30, 2018 and 2017:

[0001564590-18-019154:notes:160]
|  |  | Three Months Ended |  |  | Three Months Ended |  |
|  |  | June 30, 2018 |  |  | June 30, 2017 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |
| Unrealized gains (losses) on available-for-sale securities |  | $ | (111 | ) |  | $ | 29 |  |  | $ | (82 | ) |  | $ | 2,003 |  |  | $ | (781 | ) |  | $ | 1,222 |  |
| Unrealized gains (losses) on cash flow hedges |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (571 | ) |  |  | — |  |  |  | (571 | ) |
| Reclassification adjustment for amounts related to available-for-sale investments included in net income |  |  | 251 |  |  |  | (65 | ) |  |  | 186 |  |  |  | (1,391 | ) |  |  | 542 |  |  |  | (849 | ) |
| Reclassification adjustment for amounts related to cash flow hedges included in net income |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 154 |  |  |  | — |  |  |  | 154 |  |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net income |  |  | 7 |  |  |  | (2 | ) |  |  | 5 |  |  |  | 124 |  |  |  | (38 | ) |  |  | 86 |  |
| Foreign currency translation adjustment |  |  | (3,424 | ) |  |  | — |  |  |  | (3,424 | ) |  |  | 2,619 |  |  |  | — |  |  |  | 2,619 |  |
| Total Other Comprehensive Income (Loss) |  | $ | (3,277 | ) |  | $ | (38 | ) |  | $ | (3,315 | ) |  | $ | 2,938 |  |  | $ | (277 | ) |  | $ | 2,661 |  |

[0001564590-18-019154:notes:161]
The following table presents the tax effects related to the change in each component of other comprehensive income for the six months ended June 30, 2018 and 2017:

[0001564590-18-019154:notes:162]
|  |  | Six Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, 2018 |  |  | June 30, 2017 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |
| Unrealized gains (losses) on available-for-sale securities |  | $ | (458 | ) |  | $ | 119 |  |  | $ | (339 | ) |  | $ | 4,659 |  |  | $ | (1,817 | ) |  | $ | 2,842 |  |
| Unrealized gains (losses) on cash flow hedges |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (492 | ) |  |  | — |  |  |  | (492 | ) |
| Reclassification adjustment for amounts related to available-for-sale investments included in net income |  |  | 324 |  |  |  | (73 | ) |  |  | 251 |  |  |  | (1,860 | ) |  |  | 726 |  |  |  | (1,134 | ) |
| Reclassification adjustment for amounts reclassed to retained earnings related to the adoption of ASU 2016-01 |  |  | (3,220 | ) |  |  | — |  |  |  | (3,220 | ) |  |  | — |  |  |  | — |  |  |  | — |  |
| Reclassification adjustment for amounts related to cash flow hedges included in net income |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 154 |  |  |  | — |  |  |  | 154 |  |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net income |  |  | 97 |  |  |  | (30 | ) |  |  | 67 |  |  |  | 204 |  |  |  | (63 | ) |  |  | 141 |  |
| Foreign currency translation adjustment |  |  | (2,582 | ) |  |  | — |  |  |  | (2,582 | ) |  |  | 3,861 |  |  |  | — |  |  |  | 3,861 |  |
| Total Other Comprehensive Income (Loss) |  | $ | (5,839 | ) |  | $ | 16 |  |  | $ | (5,823 | ) |  | $ | 6,526 |  |  | $ | (1,154 | ) |  | $ | 5,372 |  |


## us-gaap:EarningsPerShareTextBlock

[0001564590-18-019154:notes:163]
[same as prior period, unchanged from 0001564590-18-012467:notes:149]

[0001564590-18-019154:notes:164]
A summary of the calculation of basic and diluted earnings per share for the three and six months ended June 30, 2018 and 2017 is as follows:

[0001564590-18-019154:notes:165]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands, except per share amounts) |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Numerator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) |  | $ | (7,670 | ) |  | $ | 12,401 |  |  | $ | (18,484 | ) |  | $ | 19,052 |  |
| Denominator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average number of shares – basic |  |  | 47,856 |  |  |  | 48,036 |  |  |  | 48,043 |  |  |  | 48,232 |  |
| Effect of dilutive securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock options |  |  | — |  |  |  | 279 |  |  |  | 8 |  |  |  | 348 |  |
| PSUs, RSUs and restricted stock |  |  | 46 |  |  |  | 98 |  |  |  | 40 |  |  |  | 95 |  |
| Weighted average number of shares – diluted |  |  | 47,902 |  |  |  | 48,413 |  |  |  | 48,091 |  |  |  | 48,675 |  |
| Net income (loss) per share – basic |  | $ | (0.16 | ) |  | $ | 0.26 |  |  | $ | (0.38 | ) |  | $ | 0.40 |  |
| Net income (loss) per share – diluted |  | $ | (0.16 | ) |  | $ | 0.26 |  |  | $ | (0.38 | ) |  | $ | 0.39 |  |

[0001564590-18-019154:notes:166]
Anti-dilutive options to purchase common stock outstanding were excluded from the above calculations. Anti-dilutive options totaled 5.0 million and 4.1 million for the three months ended June 30, 2018 and 2017, respectively, and 4.8 million and 4.1 million for the six months ended June 30, 2018 and 2017.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-18-019154:notes:167]
[same as prior period, unchanged from 0001564590-18-012467:notes:153]

[0001564590-18-019154:notes:168]
[same as prior period, unchanged from 0001564590-18-012467:notes:154]

[0001564590-18-019154:notes:169]
[same as prior period, unchanged from 0001564590-18-012467:notes:155]

[0001564590-18-019154:notes:170]
The following table presents information about the reported sales and gross profit of our reportable segments for the three and six months ended June 30, 2018 and 2017. We do not produce asset information by reportable segment; therefore, it is not reported.

[0001564590-18-019154:notes:171]
|  |  | Three Months Ended |  |
|  |  | June 30, 2018 |  |  | June 30, 2017 |  |
| (In thousands) |  | Sales |  |  | Gross Profit |  |  | Sales |  |  | Gross Profit |  |
| Network Solutions |  | $ | 115,063 |  |  | $ | 45,434 |  |  | $ | 155,543 |  |  | $ | 75,880 |  |
| Services & Support |  |  | 12,985 |  |  |  | 4,562 |  |  |  | 29,130 |  |  |  | 8,746 |  |
| Total |  | $ | 128,048 |  |  | $ | 49,996 |  |  | $ | 184,673 |  |  | $ | 84,626 |  |

[0001564590-18-019154:notes:172]
|  |  | Six Months Ended |  |
|  |  | June 30, 2018 |  |  | June 30, 2017 |  |
| (In thousands) |  | Sales |  |  | Gross Profit |  |  | Sales |  |  | Gross Profit |  |
| Network Solutions |  | $ | 220,316 |  |  | $ | 82,075 |  |  | $ | 299,140 |  |  | $ | 142,813 |  |
| Services & Support |  |  | 28,538 |  |  |  | 7,654 |  |  |  | 55,812 |  |  |  | 15,522 |  |
| Total |  | $ | 248,854 |  |  | $ | 89,729 |  |  | $ | 354,952 |  |  | $ | 158,335 |  |

[0001564590-18-019154:notes:173]
[same as prior period, unchanged from 0001564590-18-012467:notes:158]

[0001564590-18-019154:notes:174]
[same as prior period, unchanged from 0001564590-18-012467:notes:159]

[0001564590-18-019154:notes:175]
The table below presents sales information by category for the three and six months ended June 30, 2018 and 2017:

[0001564590-18-019154:notes:176]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Access & Aggregation |  | $ | 84,742 |  |  | $ | 138,639 |  |  | $ | 166,422 |  |  | $ | 258,782 |  |
| Customer Devices |  |  | 34,560 |  |  |  | 33,833 |  |  |  | 64,661 |  |  |  | 70,101 |  |
| Traditional & Other Products |  |  | 8,746 |  |  |  | 12,201 |  |  |  | 17,771 |  |  |  | 26,069 |  |
| Total |  | $ | 128,048 |  |  | $ | 184,673 |  |  | $ | 248,854 |  |  | $ | 354,952 |  |


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001564590-18-019154:notes:177]
[same as prior period, unchanged from 0001564590-18-012467:notes:162]

[0001564590-18-019154:notes:178]
Our products generally include warranties of 90 days to five years for product defects. We accrue for warranty returns at the time revenue is recognized based on our estimate of the cost to repair or replace the defective products. We engage in extensive product quality programs and processes, including actively monitoring and evaluating the quality of our component suppliers. Our products continue to become more complex in both size and functionality as many of our product offerings migrate from line card applications to total systems. The increasing complexity of our products will cause warranty incidences, when they arise, to be more costly. Our estimates regarding future warranty obligations may change due to product failure rates, material usage, and other rework costs incurred in correcting a product failure. In addition, from time to time, specific warranty accruals may be recorded if unforeseen problems arise. Should our actual experience relative to these factors be worse than our estimates, we will be required to record additional warranty expense. Alternatively, if we provide for more reserves than we require, we will reverse a portion of such provisions in future periods. The liability for warranty obligations totaled $10.1 million and $9.7 million at June 30, 2018 and December 31, 2017, respectively. During the three months ended March 31, 2017, we recorded a receivable and a reduction in warranty expense related to a settlement with a third party supplier for a defective component, the impact of which is reflected in the table below. These liabilities are included in accrued expenses in the accompanying Consolidated Balance Sheets.

[0001564590-18-019154:notes:179]
A summary of warranty expense and write-off activity for the three and six months ended June 30, 2018 and 2017 is as follows:

[0001564590-18-019154:notes:180]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Balance at beginning of period |  | $ | 9,687 |  |  | $ | 8,988 |  |  | $ | 9,724 |  |  | $ | 8,548 |  |
| Plus: Amounts charged to cost and expenses |  |  | 4,860 |  |  |  | 3,055 |  |  |  | 6,683 |  |  |  | 2,314 |  |
| Less: Deductions |  |  | (4,436 | ) |  |  | (2,863 | ) |  |  | (6,296 | ) |  |  | (1,682 | ) |
| Balance at end of period |  | $ | 10,111 |  |  | $ | 9,180 |  |  | $ | 10,111 |  |  | $ | 9,180 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-18-019154:notes:181]
15. COMMITMENTS AND CONTINGENCIES

[0001564590-18-019154:notes:182]
In the ordinary course of business, we may be subject to various legal proceedings and claims, including employment disputes, patent claims, disputes over contract agreements and other commercial disputes. In some cases, claimants seek damages or other relief, such as royalty payments related to patents, which, if granted, could require significant expenditures. Although the outcome of any claim or litigation can never be certain, it is our opinion that the outcome of all contingencies of which we are currently aware will not materially affect our business, operations, financial condition or cash flows.

[0001564590-18-019154:notes:183]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, and we have contributed $8.4 million as of June 30, 2018, of which $7.7 million has been applied to these commitments.


## us-gaap:SubsequentEventsTextBlock

[0001564590-18-019154:notes:184]
16. SUBSEQUENT EVENTS

[0001564590-18-019154:notes:185]
On July 17, 2018, we announced that our Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to stockholders of record at the close of business on August 1, 2018. The payment date will be August 15, 2018. The quarterly dividend payment will be approximately $4.3 million. In July 2003, our Board of Directors elected to begin declaring quarterly dividends on our common stock considering the tax treatment of dividends and adequate levels of Company liquidity.
