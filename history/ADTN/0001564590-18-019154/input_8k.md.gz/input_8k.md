# ADTN 8-K — 0001564590-18-016946 filed 2018-07-18

## item codes, every 8-K on or before 2018-08-03

- 2018-07-18 0001564590-18-016946 — 2.02, 9.01
- 2018-05-10 0001564590-18-012968 — 5.07
- 2018-04-18 0001564590-18-008361 — 2.02, 9.01
- 2018-03-21 0001564590-18-006409 — 8.01, 9.01
- 2018-01-17 0001564590-18-000519 — 2.02, 9.01
- 2017-12-29 0001564590-17-025375 — 2.02, 9.01
- 2017-11-16 0001193125-17-345232 — 5.02
- 2017-10-18 0001564590-17-019582 — 2.02, 9.01
- 2017-07-19 0001564590-17-013609 — 2.02, 9.01
- 2017-05-11 0001564590-17-010459 — 5.02, 9.01
- 2017-05-11 0001564590-17-010452 — 5.07
- 2017-04-19 0001193125-17-127926 — 2.02, 9.01
- 2017-02-07 0001193125-17-032714 — 8.01
- 2017-01-18 0001193125-17-011669 — 2.02, 9.01
- 2016-11-16 0001193125-16-769505 — 5.02, 9.01
- 2016-10-19 0001193125-16-741087 — 2.02, 9.01
- 2016-09-14 0001193125-16-709148 — 8.01, 9.01
- 2016-08-17 0001193125-16-683980 — 5.02, 9.01
- 2016-07-13 0001193125-16-646816 — 2.02, 9.01
- 2016-05-13 0001193125-16-590263 — 5.07
- 2016-04-13 0001193125-16-539019 — 2.02, 9.01
- 2016-04-08 0001193125-16-535035 — 7.01
- 2016-02-11 0001193125-16-459453 — 5.02, 9.01
- 2016-01-20 0001193125-16-432934 — 2.02, 9.01
- 2015-11-16 0001193125-15-378019 — 5.02, 9.01
- 2015-10-14 0001193125-15-343083 — 2.02, 9.01
- 2015-07-16 0001193125-15-254729 — 8.01, 9.01
- 2015-07-15 0001193125-15-253068 — 2.02, 9.01
- 2015-05-15 0001193125-15-189160 — 5.07, 9.01
- 2015-04-22 0001193125-15-140997 — 2.02, 9.01
- 2015-02-23 0001193125-15-056741 — 5.02, 9.01
- 2015-01-21 0001193125-15-015465 — 2.02, 9.01
- 2014-10-15 0001193125-14-372076 — 2.02, 9.01
- 2014-10-03 0001193125-14-363152 — 2.02, 9.01
- 2014-07-16 0001193125-14-269660 — 2.02, 9.01
- 2014-05-20 0001193125-14-205916 — 8.01, 9.01
- 2014-05-20 0001193125-14-205906 — 5.02, 9.01
- 2014-05-15 0001193125-14-201144 — 5.07
- 2014-04-16 0001193125-14-144665 — 2.02, 9.01
- 2014-04-03 0001193125-14-129578 — 2.02, 9.01
- 2014-01-22 0001157523-14-000154 — 2.02, 9.01
- 2013-10-15 0001193125-13-399540 — 5.02
- 2013-10-09 0001157523-13-004657 — 2.02, 9.01
- 2013-07-10 0001157523-13-003290 — 2.02, 9.01
- 2013-05-10 0001193125-13-213728 — 5.07
- 2013-05-03 0001193125-13-198816 — 8.01, 9.01
- 2013-04-10 0001157523-13-001730 — 2.02, 9.01
- 2013-01-16 0001157523-13-000139 — 2.02, 9.01
- 2012-10-10 0001157523-12-005081 — 2.02, 9.01
- 2012-10-03 0001193125-12-413609 — 7.01
- 2012-09-28 0001193125-12-408878 — 2.02, 9.01
- 2012-07-11 0001157523-12-003592 — 2.02, 9.01
- 2012-05-10 0001193125-12-225669 — 5.07
- 2012-05-10 0001193125-12-225639 — 8.01, 9.01
- 2012-04-11 0001157523-12-001772 — 2.02, 9.01
- 2012-03-15 0001193125-12-116494 — 2.02, 9.01
- 2012-01-18 0001157523-12-000174 — 2.02, 9.01
- 2011-12-12 0001193125-11-337271 — 7.01, 9.01
- 2011-10-13 0000950123-11-089785 — 5.03, 9.01
- 2011-10-12 0001157523-11-005682 — 2.02, 9.01
- 2011-07-13 0001157523-11-003986 — 2.02, 9.01
- 2011-05-09 0000950123-11-047191 — 5.02, 5.07, 9.01
- 2011-04-13 0001157523-11-002001 — 2.02, 9.01
- 2011-01-19 0001157523-11-000232 — 2.02, 9.01
- 2010-11-09 0000950123-10-103195 — 5.02, 9.01
- 2010-10-13 0001157523-10-005798 — 2.02, 9.01
- 2010-07-14 0001157523-10-004011 — 2.02, 9.01
- 2010-05-28 0000950123-10-053947 — 5.07
- 2010-04-14 0001157523-10-002022 — 2.02, 9.01
- 2010-01-20 0001157523-10-000200 — 2.02, 9.01
- 2009-10-28 0000950123-09-053984 — 8.01
- 2009-10-14 0001157523-09-006877 — 2.02, 9.01
- 2009-07-15 0001157523-09-004878 — 2.02, 9.01
- 2009-04-15 0001157523-09-002687 — 2.02, 9.01
- 2009-01-21 0001157523-09-000340 — 2.02, 9.01
- 2008-11-12 0001193125-08-233181 — 5.02, 9.01
- 2008-10-14 0001157523-08-007999 — 2.02, 9.01
- 2008-07-15 0001157523-08-005504 — 2.02, 9.01
- 2008-04-15 0001157523-08-002896 — 2.02, 9.01
- 2008-01-22 0001157523-08-000408 — 2.02, 9.01
- 2007-10-16 0001193125-07-219356 — 5.03, 9.01
- 2007-10-16 0001157523-07-009850 — 2.02, 9.01
- 2007-07-17 0001157523-07-006912 — 2.02, 9.01
- 2007-04-17 0001157523-07-003630 — 2.02, 9.01
- 2007-04-03 0001179022-07-000068 — 5.02
- 2007-03-28 0001179022-07-000064 — 5.02
- 2007-02-23 0001193125-07-038337 — 5.02
- 2007-02-23 0001193125-07-038335 — 5.02
- 2007-01-30 0001193125-07-015912 — 5.02, 9.01
- 2007-01-26 0001193125-07-014234 — 5.02
- 2007-01-23 0001157523-07-000494 — 2.02, 9.01 — amendment of 0001157523-07-000481
- 2007-01-23 0001157523-07-000481 — 2.02, 9.01
- 2006-10-17 0001157523-06-009945 — 2.02, 9.01
- 2006-07-18 0001157523-06-006929 — 2.02, 9.01
- 2006-06-08 0001193125-06-126486 — 1.01, 9.01
- 2006-05-10 0001193125-06-107316 — 1.01, 9.01
- 2006-04-18 0001157523-06-003699 — 2.02, 9.01
- 2006-02-03 0001179022-06-000014 — 1.01
- 2006-01-27 0001157523-06-000754 — 5.02, 9.01
- 2006-01-24 0001157523-06-000551 — 2.02, 9.01
- 2005-10-18 0001157523-05-008826 — 2.02, 9.01
- 2005-07-19 0001193125-05-143958 — 1.01, 5.02, 9.01
- 2005-07-19 0001193125-05-143957 — 2.02, 9.01
- 2005-05-20 0001193125-05-112019 — 1.01, 9.01
- 2005-04-19 0001157523-05-003418 — 2.02, 9.01
- 2005-01-25 0001193125-05-010721 — 2.02, 9.01
- 2004-10-12 0001193125-04-169652 — 2.02, 9.01
- 2004-07-13 0001193125-04-116820 — 12, 7
- 2004-04-14 0001193125-04-061547 — 12, 7
- 2004-01-21 0001193125-04-006366 — 12, 7
- 2003-10-14 0001193125-03-061018 — 12, 5, 7
- 2003-07-15 0001193125-03-019292 — 7, 9
- 2003-04-15 0000931763-03-000968 — 7, 9
- 1996-09-12 0000931763-96-000667 — 5, 7

## late-filing notifications on or before 2018-08-03

- none on or before 2018-08-03

## item 2.02 — earnings release, exhibit 99.1

[0001564590-18-016946:8k_2_02:1]
EX-99.1
2
adtn-ex991_7.htm
EX-99.1

[0001564590-18-016946:8k_2_02:2]
adtn-ex991_7.htm

[0001564590-18-016946:8k_2_02:3]
EXHIBIT 99.1

[0001564590-18-016946:8k_2_02:4]
ADTRAN, Inc. Reports Earnings for the Second Quarter 2018 and Declares Quarterly Cash Dividend

[0001564590-18-016946:8k_2_02:5]
HUNTSVILLE, Ala.--(BUSINESS WIRE)—July 17, 2018-- ADTRAN, Inc. (NASDAQ:ADTN) reported results for the second quarter 2018. For the quarter, sales were $128.0 million compared to $184.7 million for the second quarter of 2017. Net loss was $7.7 million compared to net income of $12.4 million for the second quarter of 2017. Earnings per share, assuming dilution, were a loss of $0.16 compared to income of $0.26 for the second quarter of 2017. Non-GAAP earnings per share were a loss of $0.10 compared to income of $0.30 for the second quarter of 2017. GAAP earnings per share include the expense of stock-based compensation, acquisition related amortizations and other expenses, and a restructuring program. The reconciliation between GAAP earnings per share, diluted, and non-GAAP earnings per share, diluted, is in the table provided.

[0001564590-18-016946:8k_2_02:6]
ADTRAN Chairman and Chief Executive Officer Tom Stanton stated, “Our second quarter results showed steady improvement from the previous quarter.  We are pleased with our quarter-over-quarter growth in revenue and gross margins.  Looking ahead, we expect our international business to remain strong through the second half of the year. We are also encouraged by what we are seeing in our North American carrier and cable/MSO business – all of which indicate further momentum as we head into 2019.”

[0001564590-18-016946:8k_2_02:7]
The Company also announced that its Board of Directors declared a cash dividend for the second quarter of 2018. The quarterly cash dividend is $0.09 per common share to be paid to holders of record at the close of business on August 1, 2018. The ex-dividend date is July 31, 2018, and the payment date is August 15, 2018.

[0001564590-18-016946:8k_2_02:8]
The Company confirmed that it will hold its second quarter conference call Wednesday, July 18, 2018, at 9:30 a.m. Central Time. ADTRAN will webcast this conference. To listen, simply visit the Investor Relations site at www.investors.adtran.com approximately 10 minutes prior to the start of the call and click on the conference call link provided.

[0001564590-18-016946:8k_2_02:9]
An online replay of the conference call, as well as the text of the Company's earnings release, will be available on the Investor Relations site approximately 24 hours following the call and will remain available for at least 12 months. For more information, visit www.investors.adtran.com or via email at investor.relations@adtran.com. ADTRAN, Inc. is the leading global provider of networking and communications equipment. ADTRAN’s products enable voice, data, video and Internet communications across a variety of network infrastructures. ADTRAN solutions are currently in use by service providers, private enterprises, government organizations, and millions of individual users worldwide. Please visit us at www.adtran.com, LinkedIn and Twitter.

[0001564590-18-016946:8k_2_02:10]
This press release contains forward-looking statements which reflect management’s best judgment based on factors currently known. However, these statements involve risks and uncertainties, including the successful development and market acceptance of new products, the degree of competition in the market for such products, the product and channel mix, component costs, manufacturing efficiencies, and other risks detailed in our annual report on Form 10-K for the year ended December 31, 2017. These risks and uncertainties could cause actual results to differ materially from those in the forward-looking statements included in this press release.

[0001564590-18-016946:8k_2_02:11]
Condensed Consolidated Balance Sheet

[0001564590-18-016946:8k_2_02:12]
(Unaudited)

[0001564590-18-016946:8k_2_02:13]
(In thousands)

[0001564590-18-016946:8k_2_02:14]
|  | June 30, |  |  | December 31, |  |
|  | 2018 |  |  | 2017 |  |
| Assets |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 100,319 |  |  | $ | 86,433 |  |
| Short-term investments |  | 6,069 |  |  |  | 16,129 |  |
| Accounts receivable, net |  | 76,135 |  |  |  | 144,150 |  |
| Other receivables |  | 28,163 |  |  |  | 26,578 |  |
| Inventory, net |  | 120,537 |  |  |  | 122,542 |  |
| Prepaid expenses and other current assets |  | 9,464 |  |  |  | 17,282 |  |
| Total Current Assets |  | 340,687 |  |  |  | 413,114 |  |
| Property, plant and equipment, net |  | 82,910 |  |  |  | 85,079 |  |
| Deferred tax assets, net |  | 35,615 |  |  |  | 23,428 |  |
| Goodwill |  | 3,492 |  |  |  | 3,492 |  |
| Other assets |  | 32,429 |  |  |  | 13,725 |  |
| Long-term investments |  | 144,437 |  |  |  | 130,256 |  |
| Total Assets | $ | 639,570 |  |  | $ | 669,094 |  |
| Liabilities and Stockholders' Equity |  |  |  |  |  |  |  |
| Accounts payable | $ | 60,150 |  |  | $ | 60,632 |  |
| Unearned revenue |  | 14,307 |  |  |  | 13,070 |  |
| Accrued expenses |  | 14,785 |  |  |  | 13,232 |  |
| Accrued wages and benefits |  | 14,913 |  |  |  | 15,948 |  |
| Income tax payable |  | 11,948 |  |  |  | 3,936 |  |
| Total Current Liabilities |  | 116,103 |  |  |  | 106,818 |  |
| Non-current unearned revenue |  | 3,639 |  |  |  | 4,556 |  |
| Other non-current liabilities |  | 34,601 |  |  |  | 34,209 |  |
| Bonds payable |  | 25,600 |  |  |  | 25,600 |  |
| Total Liabilities |  | 179,943 |  |  |  | 171,183 |  |
| Stockholders' Equity |  | 459,627 |  |  |  | 497,911 |  |
| Total Liabilities and Stockholders' Equity | $ | 639,570 |  |  | $ | 669,094 |  |

[0001564590-18-016946:8k_2_02:15]
Consolidated Statements of Income

[0001564590-18-016946:8k_2_02:16]
(Unaudited)

[0001564590-18-016946:8k_2_02:17]
(In thousands, except per share data)

[0001564590-18-016946:8k_2_02:18]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  | $ | 115,063 |  |  | $ | 155,543 |  |  | $ | 220,316 |  |  | $ | 299,140 |  |
| Services |  |  | 12,985 |  |  |  | 29,130 |  |  |  | 28,538 |  |  |  | 55,812 |  |
| Total Sales |  |  | 128,048 |  |  |  | 184,673 |  |  |  | 248,854 |  |  |  | 354,952 |  |
| Cost of Sales |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  |  | 69,629 |  |  |  | 79,663 |  |  |  | 138,241 |  |  |  | 156,327 |  |
| Services |  |  | 8,423 |  |  |  | 20,384 |  |  |  | 20,884 |  |  |  | 40,290 |  |
| Total Cost of Sales |  |  | 78,052 |  |  |  | 100,047 |  |  |  | 159,125 |  |  |  | 196,617 |  |
| Gross Profit |  |  | 49,996 |  |  |  | 84,626 |  |  |  | 89,729 |  |  |  | 158,335 |  |
| Selling, general and administrative expenses |  |  | 32,080 |  |  |  | 34,706 |  |  |  | 65,611 |  |  |  | 69,495 |  |
| Research and development expenses |  |  | 30,729 |  |  |  | 33,557 |  |  |  | 63,578 |  |  |  | 65,528 |  |
| Operating Income (Loss) |  |  | (12,813 | ) |  |  | 16,363 |  |  |  | (39,460 | ) |  |  | 23,312 |  |
| Interest and dividend income |  |  | 913 |  |  |  | 972 |  |  |  | 1,779 |  |  |  | 1,905 |  |
| Interest expense |  |  | (132 | ) |  |  | (137 | ) |  |  | (264 | ) |  |  | (278 | ) |
| Net realized investment gain |  |  | 990 |  |  |  | 1,390 |  |  |  | 893 |  |  |  | 1,860 |  |
| Other expense, net |  |  | (217 | ) |  |  | (719 | ) |  |  | (274 | ) |  |  | (585 | ) |
| Gain on bargain purchase of a business |  |  | — |  |  |  | — |  |  |  | 11,322 |  |  |  | — |  |
| Income (loss) before provision for income taxes |  |  | (11,259 | ) |  |  | 17,869 |  |  |  | (26,004 | ) |  |  | 26,214 |  |
| (Provision) benefit for income taxes |  |  | 3,589 |  |  |  | (5,468 | ) |  |  | 7,520 |  |  |  | (7,162 | ) |
| Net Income (Loss) |  | $ | (7,670 | ) |  | $ | 12,401 |  |  | $ | (18,484 | ) |  | $ | 19,052 |  |
| Weighted average shares outstanding – basic |  |  | 47,856 |  |  |  | 48,036 |  |  |  | 48,043 |  |  |  | 48,232 |  |
| Weighted average shares outstanding – diluted |  |  | 47,902 |  |  |  | 48,413 |  |  |  | 48,091 |  |  |  | 48,675 |  |
| Earnings (loss) per common share – basic |  | $ | (0.16 | ) |  | $ | 0.26 |  |  | $ | (0.38 | ) |  | $ | 0.40 |  |
| Earnings (loss) per common share – diluted |  | $ | (0.16 | ) |  | $ | 0.26 |  |  | $ | (0.38 | ) |  | $ | 0.39 |  |

[0001564590-18-016946:8k_2_02:19]
(1) Assumes exercise of dilutive stock options calculated under the treasury stock method.

[0001564590-18-016946:8k_2_02:20]
Consolidated Statements of Comprehensive Income

[0001564590-18-016946:8k_2_02:21]
(Unaudited)

[0001564590-18-016946:8k_2_02:22]
(In thousands)

[0001564590-18-016946:8k_2_02:23]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Net Income (Loss) |  | $ | (7,670 | ) |  | $ | 12,401 |  |  | $ | (18,484 | ) |  | $ | 19,052 |  |
| Other Comprehensive Income (Loss), net of tax |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net unrealized gains (losses) on available-for-sale securities |  |  | 104 |  |  |  | 373 |  |  |  | (3,308 | ) |  |  | 1,708 |  |
| Net unrealized losses on cash flow hedges |  |  | — |  |  |  | (417 | ) |  |  | — |  |  |  | (338 | ) |
| Defined benefit plan adjustments |  |  | 5 |  |  |  | 86 |  |  |  | 67 |  |  |  | 141 |  |
| Foreign currency translation |  |  | (3,424 | ) |  |  | 2,619 |  |  |  | (2,582 | ) |  |  | 3,861 |  |
| Other Comprehensive Income (Loss), net of tax |  |  | (3,315 | ) |  |  | 2,661 |  |  |  | (5,823 | ) |  |  | 5,372 |  |
| Comprehensive Income (Loss), net of tax |  | $ | (10,985 | ) |  | $ | 15,062 |  |  | $ | (24,307 | ) |  | $ | 24,424 |  |

[0001564590-18-016946:8k_2_02:24]
Consolidated Statements of Cash Flows

[0001564590-18-016946:8k_2_02:25]
(Unaudited)

[0001564590-18-016946:8k_2_02:26]
(In thousands)

[0001564590-18-016946:8k_2_02:27]
|  |  | Six Months Ended |  |
|  |  | June 30, |  |
|  |  | 2018 |  |  | 2017 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income (loss) |  | $ | (18,484 | ) |  | $ | 19,052 |  |
| Adjustments to reconcile net income (loss) to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 7,526 |  |  |  | 8,377 |  |
| Amortization of net premium on available-for-sale investments |  |  | 20 |  |  |  | 238 |  |
| Net realized gain on long-term investments |  |  | (893 | ) |  |  | (1,860 | ) |
| Net (gain) loss on disposal of property, plant and equipment |  |  | 68 |  |  |  | (11 | ) |
| Gain on bargain purchase of a business |  |  | (11,322 | ) |  |  | — |  |
| Stock-based compensation expense |  |  | 3,603 |  |  |  | 3,739 |  |
| Deferred income taxes |  |  | (16,384 | ) |  |  | (2,772 | ) |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  |  | 66,931 |  |  |  | 13,911 |  |
| Other receivables |  |  | 9 |  |  |  | 571 |  |
| Inventory |  |  | 2,063 |  |  |  | (7,547 | ) |
| Prepaid expenses and other assets |  |  | 10,157 |  |  |  | (9,853 | ) |
| Accounts payable |  |  | 683 |  |  |  | (10,910 | ) |
| Accrued expenses and other liabilities |  |  | 2,008 |  |  |  | (2,629 | ) |
| Income tax payable |  |  | 6,945 |  |  |  | 10,273 |  |
| Net cash provided by operating activities |  |  | 52,930 |  |  |  | 20,579 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (4,183 | ) |  |  | (7,509 | ) |
| Proceeds from disposals of property, plant and equipment |  |  | — |  |  |  | 16 |  |
| Proceeds from sales and maturities of available-for-sale investments |  |  | 86,436 |  |  |  | 81,891 |  |
| Purchases of available-for-sale investments |  |  | (89,801 | ) |  |  | (65,140 | ) |
| Acquisition of business |  |  | (7,806 | ) |  |  | — |  |
| Net cash provided by (used in) investing activities |  |  | (15,354 | ) |  |  | 9,258 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Proceeds from stock option exercises |  |  | 369 |  |  |  | 1,722 |  |
| Purchases of treasury stock |  |  | (12,774 | ) |  |  | (17,311 | ) |
| Dividend payments |  |  | (8,679 | ) |  |  | (8,719 | ) |
| Net cash used in financing activities |  |  | (21,084 | ) |  |  | (24,308 | ) |
| Net increase in cash and cash equivalents |  |  | 16,492 |  |  |  | 5,529 |  |
| Effect of exchange rate changes |  |  | (2,606 | ) |  |  | 3,374 |  |
| Cash and cash equivalents, beginning of period |  |  | 86,433 |  |  |  | 79,895 |  |
| Cash and cash equivalents, end of period |  | $ | 100,319 |  |  | $ | 88,798 |  |
| Supplemental disclosure of non-cash investing activities: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment included in accounts payable |  | $ | 209 |  |  | $ | 454 |  |

[0001564590-18-016946:8k_2_02:28]
Supplemental Information

[0001564590-18-016946:8k_2_02:29]
Restructuring Expenses

[0001564590-18-016946:8k_2_02:30]
(Unaudited)

[0001564590-18-016946:8k_2_02:31]
(In thousands)

[0001564590-18-016946:8k_2_02:32]
Restructuring expense was recorded in the following Consolidated Statements of Income categories for three and six months ended June 30, 2018 and 2017:

[0001564590-18-016946:8k_2_02:33]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Restructuring expense included in cost of sales |  | $ | 391 |  |  | $ | — |  |  | $ | 2,761 |  |  | $ | — |  |
| Selling, general and administrative expense |  |  | 634 |  |  |  | — |  |  |  | 2,400 |  |  |  | — |  |
| Research and development expense |  |  | — |  |  |  | — |  |  |  | 1,814 |  |  |  | — |  |
| Restructuring expense included in operating expenses |  |  | 634 |  |  |  | — |  |  |  | 4,214 |  |  |  | — |  |
| Total restructuring expense |  |  | 1,025 |  |  |  | — |  |  |  | 6,975 |  |  |  | — |  |
| Provision for income taxes |  |  | (267 | ) |  |  | — |  |  |  | (1,814 | ) |  |  | — |  |
| Total restructuring expense, net of tax |  | $ | 758 |  |  | $ | — |  |  | $ | 5,161 |  |  | $ | — |  |

[0001564590-18-016946:8k_2_02:34]
Supplemental Information

[0001564590-18-016946:8k_2_02:35]
Acquisition Related Expenses, Amortizations and Adjustments

[0001564590-18-016946:8k_2_02:36]
(Unaudited)

[0001564590-18-016946:8k_2_02:37]
(In thousands)

[0001564590-18-016946:8k_2_02:38]
On August 4, 2011, we closed on the acquisition of Bluesocket, Inc., on May 4, 2012, we closed on the acquisition of the Nokia Siemens Networks Broadband Access business (NSN BBA), on September 13, 2016, we closed on the acquisition of CommScope’s active fiber business (CommScope), and on March 19, 2018, we closed on the acquisition of Sumitomo Electric Lightwave Corp.’s North American EPON business (Sumitomo). Acquisition related expenses, amortizations and adjustments for the three and six months ended June 30, 2018 and 2017 for all four transactions are as follows:

[0001564590-18-016946:8k_2_02:39]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Bluesocket, Inc. acquisition |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets |  | $ | 158 |  |  | $ | 158 |  |  | $ | 316 |  |  | $ | 316 |  |
| NSN BBA acquisition |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets |  |  | 90 |  |  |  | 129 |  |  |  | 182 |  |  |  | 337 |  |
| Amortization of other purchase accounting adjustments |  |  | 1 |  |  |  | 10 |  |  |  | 1 |  |  |  | 38 |  |
| Subtotal - NSN BBA acquisition |  |  | 91 |  |  |  | 139 |  |  |  | 183 |  |  |  | 375 |  |
| CommScope acquisition |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets |  |  | 125 |  |  |  | 608 |  |  |  | 250 |  |  |  | 1,294 |  |
| Amortization of other purchase accounting adjustments |  |  | — |  |  |  | 31 |  |  |  | 1 |  |  |  | 81 |  |
| Acquisition related professional fees, travel and other expenses |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 8 |  |
| Subtotal - CommScope acquisition |  |  | 125 |  |  |  | 639 |  |  |  | 251 |  |  |  | 1,383 |  |
| Sumitomo acquisition |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets |  |  | 662 |  |  |  | — |  |  |  | 772 |  |  |  | — |  |
| Amotization of other purchase accounting adjustments |  |  | 79 |  |  |  | — |  |  |  | 79 |  |  |  | — |  |
| Acquisition related professional fees, travel and other expenses |  |  | 27 |  |  |  | — |  |  |  | 124 |  |  |  | — |  |
| Subtotal - Sumitomo acquisition |  |  | 768 |  |  |  | — |  |  |  | 975 |  |  |  | — |  |
| Total acquisition related expenses, amortizations and adjustments |  |  | 1,142 |  |  |  | 936 |  |  |  | 1,725 |  |  |  | 2,074 |  |
| Provision for income taxes |  |  | (301 | ) |  |  | (354 | ) |  |  | (457 | ) |  |  | (779 | ) |
| Total acquisition related expenses, amortizations and adjustments, net of tax |  | $ | 841 |  |  | $ | 582 |  |  | $ | 1,268 |  |  | $ | 1,295 |  |

[0001564590-18-016946:8k_2_02:40]
The acquisition related expenses, amortizations and adjustments above were recorded in the following Consolidated Statements of Income categories for the three and six months ended June 30, 2018 and 2017:

[0001564590-18-016946:8k_2_02:41]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Cost of goods sold |  | $ | 430 |  |  | $ | 31 |  |  | $ | 489 |  |  | $ | 81 |  |
| Selling, general and administrative expenses |  |  | 319 |  |  |  | 52 |  |  |  | 585 |  |  |  | 114 |  |
| Research and development expenses |  |  | 393 |  |  |  | 853 |  |  |  | 651 |  |  |  | 1,879 |  |
| Total acquisition related expenses, amortizations and adjustments included in operating expenses |  |  | 712 |  |  |  | 905 |  |  |  | 1,236 |  |  |  | 1,993 |  |
| Total acquisition related expenses, amortizations and adjustments |  |  | 1,142 |  |  |  | 936 |  |  |  | 1,725 |  |  |  | 2,074 |  |
| Provision for income taxes |  |  | (301 | ) |  |  | (354 | ) |  |  | (457 | ) |  |  | (779 | ) |
| Total acquisition related expenses, amortizations and adjustments, net of tax |  | $ | 841 |  |  | $ | 582 |  |  | $ | 1,268 |  |  | $ | 1,295 |  |

[0001564590-18-016946:8k_2_02:42]
Supplemental Information

[0001564590-18-016946:8k_2_02:43]
Stock-based Compensation Expense

[0001564590-18-016946:8k_2_02:44]
(Unaudited)

[0001564590-18-016946:8k_2_02:45]
(In thousands)

[0001564590-18-016946:8k_2_02:46]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
|  |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Stock-based compensation expense included in cost of sales |  | $ | 102 |  |  | $ | 93 |  |  | $ | 197 |  |  | $ | 184 |  |
| Selling, general and administrative expense |  |  | 995 |  |  |  | 1,008 |  |  |  | 2,030 |  |  |  | 2,024 |  |
| Research and development expense |  |  | 687 |  |  |  | 755 |  |  |  | 1,376 |  |  |  | 1,531 |  |
| Stock-based compensation expense included in operating expenses |  |  | 1,682 |  |  |  | 1,763 |  |  |  | 3,406 |  |  |  | 3,555 |  |
| Total stock-based compensation expense |  |  | 1,784 |  |  |  | 1,856 |  |  |  | 3,603 |  |  |  | 3,739 |  |
| Tax benefit for expense associated with non-qualified options, PSUs, RSUs and restricted stock |  |  | (340 | ) |  |  | (433 | ) |  |  | (724 | ) |  |  | (813 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 1,444 |  |  | $ | 1,423 |  |  | $ | 2,879 |  |  | $ | 2,926 |  |

[0001564590-18-016946:8k_2_02:47]
Reconciliation of GAAP net income per share, diluted, to

[0001564590-18-016946:8k_2_02:48]
Non-GAAP net income per share, diluted

[0001564590-18-016946:8k_2_02:49]
(Unaudited)

[0001564590-18-016946:8k_2_02:50]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
|  |  | 2018 |  |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| GAAP earnings per common share - diluted |  | $ | (0.16 | ) |  |  | 0.26 |  |  | $ | (0.38 | ) |  | $ | 0.39 |  |
| Restructuring expense |  |  | 0.02 |  |  |  | — |  |  |  | 0.11 |  |  |  | — |  |
| Acquisition related expenses, amortizations and adjustments |  |  | 0.02 |  |  |  | 0.01 |  |  |  | 0.03 |  |  |  | 0.03 |  |
| Stock-based compensation expense |  |  | 0.03 |  |  |  | 0.03 |  |  |  | 0.06 |  |  |  | 0.06 |  |
| Gain on bargain purchase of a business |  |  | — |  |  |  | — |  |  |  | (0.24 | ) |  |  | — |  |
| Non-GAAP earnings per common share - diluted(1) |  | $ | (0.10 | ) |  |  | 0.30 |  |  | $ | (0.43 | ) |  | $ | 0.48 |  |

[0001564590-18-016946:8k_2_02:51]
(1) Table may not foot due to rounding
