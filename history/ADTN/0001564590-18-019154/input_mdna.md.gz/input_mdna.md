# ADTN MD&A — 0001564590-18-019154


## mdna

[0001564590-18-019154:mdna:1]
[same as prior period, unchanged from 0001564590-18-012467:mdna:1]

[0001564590-18-019154:mdna:2]
[same as prior period, unchanged from 0001564590-18-012467:mdna:2]

[0001564590-18-019154:mdna:3]
[same as prior period, unchanged from 0001564590-18-012467:mdna:3]

[0001564590-18-019154:mdna:4]
[same as prior period, unchanged from 0001564590-18-012467:mdna:4]

[0001564590-18-019154:mdna:5]
[same as prior period, unchanged from 0001564590-18-012467:mdna:5]

[0001564590-18-019154:mdna:6]
[same as prior period, unchanged from 0001564590-18-012467:mdna:6]

[0001564590-18-019154:mdna:7]
[same as prior period, unchanged from 0001564590-18-012467:mdna:7]

[0001564590-18-019154:mdna:8]
[same as prior period, unchanged from 0001564590-18-012467:mdna:8]

[0001564590-18-019154:mdna:9]
[same as prior period, unchanged from 0001564590-18-012467:mdna:9]

[0001564590-18-019154:mdna:10]
[same as prior period, unchanged from 0001564590-18-012467:mdna:10]

[0001564590-18-019154:mdna:11]
Sales were $128.0 million and $248.9 million for the three and six months ended June 30, 2018, compared to $184.7 million and $355.0 million for the three and six months ended June 30, 2017. Our gross margin decreased to 39.0% and 36.1% in the three and six months ended June 30, 2018, from 45.8% and 44.6% in the three and six months ended June 30, 2017. Our operating income margin decreased to (10.0)% and (15.9)% for the three and six months ended June 30, 2018, from 8.9% and 6.6% for the three and six months ended June 30, 2017. Net income (loss) was $(7.7) million and $(18.5) million for the three and six months ended June 30, 2018, compared to $12.4 million and $19.1 million for the three and six months ended June 30, 2017. Our effective tax rate, excluding the effect of the bargain purchase gain in 2018, increased to 31.9% for the three months ended June 30, 2018 from 30.6% for the three months ended June 30, 2017, and decreased to 20.1% for the six months ended June 30, 2018 from 27.3% for the six months ended June 30, 2017. Earnings (loss) per share, assuming dilution, were $(0.16) and $(0.38) for the three and six months ended June 30, 2018, compared to $0.26 and $0.39 for the three and six months ended June 30, 2017.

[0001564590-18-019154:mdna:12]
[same as prior period, unchanged from 0001564590-18-012467:mdna:12]

[0001564590-18-019154:mdna:13]
[same as prior period, unchanged from 0001564590-18-012467:mdna:13]

[0001564590-18-019154:mdna:14]
Accordingly, our historical financial performance is not necessarily a meaningful indicator of future results, and in general, management expects that our financial results may vary from period to period. Factors that could materially affect our business, financial condition or operating results are included in Item 1A of Part I in our most recent Annual Report on Form 10-K for the year ended December 31, 2017, filed on February 23, 2018 with the SEC.

[0001564590-18-019154:mdna:15]
[same as prior period, unchanged from 0001564590-18-012467:mdna:15]

[0001564590-18-019154:mdna:16]
[same as prior period, unchanged from 0001564590-18-012467:mdna:16]

[0001564590-18-019154:mdna:17]
[same as prior period, unchanged from 0001564590-18-012467:mdna:17]

[0001564590-18-019154:mdna:18]
[same as prior period, unchanged from 0001564590-18-012467:mdna:18]

[0001564590-18-019154:mdna:19]
RESULTS OF OPERATIONS – THREE AND SIX MONTHS ENDED JUNE 30, 2018 COMPARED TO THREE AND SIX MONTHS ENDED JUNE 30, 2017

[0001564590-18-019154:mdna:20]
[same as prior period, unchanged from 0001564590-18-012467:mdna:20]

[0001564590-18-019154:mdna:21]
Our sales decreased 30.7% from $184.7 million in the three months ended June 30, 2017 to $128.0 million in the three months ended June 30, 2018, and decreased 29.9% from $355.0 million in the six months ended June 30, 2017 to $248.9 million in the six months ended June 30, 2018. The decrease in sales for the three and six months ended June 30, 2018 is primarily attributable to a merger-related review and slowdown in spending at a domestic Tier 1 customer that particularly affected our Access & Aggregation products, which decreased $53.9 million and $92.4 million over the same three and six month periods last year. The decline in sales to the previously mentioned domestic Tier 1 customer was partially offset by an increase in sales to an international Tier 1 customer. Compared to the same three and six month periods last year, our Customer Devices products increased $0.7 million and decreased $5.4 million, respectively, and our Traditional & Other Products decreased $3.5 million and $8.3 million, respectively.

[0001564590-18-019154:mdna:22]
Network Solutions sales decreased 26.0% from $155.5 million in the three months ended June 30, 2017 to $115.1 million in the three months ended June 30, 2018, and decreased 26.4% from $299.1 million in the six months ended June 30, 2017 to $220.3 million in the six months ended June 30, 2018. The decrease in sales of our Access & Aggregation products for the three and six months ended June 30, 2018 is primarily attributable to a merger-related review and slowdown in spending at a domestic Tier 1 customer, partially offset by an increase in sales to an international Tier 1 customer as discussed further below. The changes for the three and six months ended June 30, 2018 in sales of our Customer Devices products are primarily attributable to the changes in sales of fiber CPE products. While we expect that revenues from Traditional & Other Products will continue to decline over time, these revenues may fluctuate and continue for years because of the time required for our customers to transition to newer technologies.

[0001564590-18-019154:mdna:23]
Services & Support sales decreased 55.4% from $29.1 million in the three months ended June 30, 2017 to $13.0 million in the three months ended June 30, 2018, and decreased 48.9% from $55.8 million in the six months ended June 30, 2017 to $28.5 million in the six months ended June 30, 2018. The decrease in sales for the three and six months ended June 30, 2018 is primarily attributable to a decrease in network installation services for Access & Aggregation products related to the above mentioned merger-related review and slowdown in spending at a domestic Tier 1 customer.

[0001564590-18-019154:mdna:24]
International sales, which are included in the Network Solutions and Services & Support amounts discussed above, increased 57.6% from $38.0 million in the three months ended June 30, 2017 to $59.8 million in the three months ended June 30, 2018, and increased 33.2% from $89.0 million in the six months ended June 30, 2017 to $118.5 million in the six months ended June 30, 2018. International sales, as a percentage of total sales, increased from 20.6% for the three months ended June 30, 2017 to 46.7% for the three months ended June 30, 2018, and increased from 25.1% for the six months ended June 30, 2017 to 47.6% in the six months ended June 30, 2018. The increase in sales for the three months ended June 30, 2018 is primarily attributable to an increase in sales in EMEA, partially offset by a decrease in sales in Americas International. The increase in sales for the six months ended June 30, 2018 is primarily attributable to an increase in sales in EMEA, partially offset by a decrease in sales in APAC and Americas International. The increase in sales in EMEA for the three and six months ended June 30, 2018 is primarily attributable to a network expansion program and a Services award by a large European Tier-1 customer.

[0001564590-18-019154:mdna:25]
Our international revenues are largely focused on broadband infrastructure and are impacted by the decisions of our customers as to timing for installation of new technologies, expansion of their networks and/or network upgrades. Our international customers must make these decisions in the regulatory and political environment in which they operate – both nationally and in some instances, regionally – whether of a multi-country region or a more local region within a country. For example, the European Commission launched a Gigabit Society initiative, and before that, the Digital Agenda, which has provided a favorable market environment for the deployment of ultra-broadband and Gigabit network solutions. Although the overall environment and market demand for broadband service deployment in the European Union have improved, some new broadband technologies are still being reviewed for regulatory and standards compliance, which may affect the timing of those technologies. In Mexico, regulatory changes have created uncertainty for customers resulting in slowdowns in their network buying patterns. The competitive landscape in certain international markets is also impacted by the increased presence of Asian manufacturers that seek to compete aggressively on price. A strengthening U.S. dollar can also negatively impact our revenues in regions such as Latin America, where our products are traditionally priced in U.S. dollars, while in regions where our products are sold in local currency, such as Europe, a stronger U.S. dollar can negatively impact operating income. Consequently, while we expect the global trend towards deployment of more robust broadband speeds and access to continue creating additional market opportunities for us, the factors described above may result in pressure on revenues and operating income. However, we do not presently foresee a significant negative impact to our financial condition based on our strong liquidity and the generally positive environment described above.

[0001564590-18-019154:mdna:26]
We recognized a positive revenue impact in the first half of 2017 due to our being awarded a network expansion program by a large European Tier-1 customer. During the first and second quarters of 2018, this European Tier 1 customer undertook an additional network expansion project. We anticipate that as our Latin American customers resume their network upgrade projects, we may experience further enhancement to our revenues. We have recently announced receipt of a new nation-wide award in the APAC region, as well as additional awards based on new ADTRAN technologies in the EMEA region that we believe will likely result in a positive impact to our revenues. However, a resolution of the regulatory changes affecting a major customer in Mexico has been slower than anticipated, and business with one of our customers in that region has not yet returned to normal levels. We are continuing to pursue opportunities with new customers in this region.

[0001564590-18-019154:mdna:27]
[same as prior period, unchanged from 0001564590-18-012467:mdna:27]

[0001564590-18-019154:mdna:28]
As a percentage of sales, cost of sales increased from 54.2% in the three months ended June 30, 2017 to 61.0% in the three months ended June 30, 2018, and increased from 55.4% in the six months ended June 30, 2017 to 63.9% in the six months ended June 30, 2018. The increase in cost of sales as a percentage of sales for the three months ended June 30, 2018 is primarily attributable to a regional revenue shift, customer and product mix, services and support mix and an increase in warranty expense. The increase in cost of sales as a percentage of sales for the six months ended June 30, 2018 is primarily attributable to a regional revenue shift, customer and product mix, services and support mix, an increase in labor expense due to a restructuring program and an increase in warranty expense.

[0001564590-18-019154:mdna:29]
Network Solutions cost of sales, as a percent of that segment’s sales, increased from 51.2% in the three months ended June 30, 2017 to 60.5% in the three months ended June 30, 2018, and increased from 52.3% in the six months ended June 30, 2017 to 62.7% in the six months ended June 30, 2018. The increase in cost of sales as a percentage of sales for the three months ended June 30, 2018 is primarily attributable to a regional revenue shift, customer and product mix and an increase in warranty expense. The increase in cost of sales as a percentage of sales for the six months ended June 30, 2018 is primarily attributable to a regional revenue shift, customer and product mix, an increase in labor expense due to a restructuring program, an increase in warranty expense due to a settlement in first quarter of 2017 with a third party supplier for a defective component and purchase discounts received from a contract manufacturer in the first quarter of 2017.

[0001564590-18-019154:mdna:30]
[same as prior period, unchanged from 0001564590-18-012467:mdna:30]

[0001564590-18-019154:mdna:31]
Services & Support cost of sales, as a percent of that segment’s sales, decreased from 70.0% in the three months ended June 30, 2017 to 64.9% in the three months ended June 30, 2018, and increased from 72.2% in the six months ended June 30, 2017 to 73.2% in the six months ended June 30, 2018. The decrease in cost of sales as a percentage of sales for the three months ended June 30, 2018 is primarily attributable to services and support mix. The increase in cost of sales as a percentage of sales for the six months ended June 30, 2018 is primarily attributable to services and support mix and an increase in labor expense due to a restructuring program.

[0001564590-18-019154:mdna:32]
Our Services business has experienced significant growth since 2015 as competitive pressures to expand broadband access and speeds have strained carriers’ ability to respond to customer demand. Our Services & Support revenues are comprised of network planning and implementation, maintenance, support and cloud-based management services, with network planning and implementation being the largest and fastest growing component. Compared to our other services, such as maintenance, support and cloud-based management services, our network planning and implementation services typically utilize a higher percentage of internal and subcontracted engineers, professionals and contractors to perform the work for customers. The additional costs incurred to perform these infrastructure and labor-intensive services inherently result in lower average gross margins as compared to maintenance and support services.

[0001564590-18-019154:mdna:33]
As our network planning and implementation revenues grew and are now the largest component of our Services & Support business, our Services & Support segment gross margins decreased versus those reported when maintenance and support comprised the majority of the business. Further, because the growth in our network planning and implementation services has resulted in our Services & Support revenues comprising a larger percentage of our overall revenues, and because our Services & Support gross margins are below those of the Network Solutions segment, our overall corporate gross margins have declined as that business has continued to grow. Within the Services & Support segment, we do expect variability in gross margins from quarter-to-quarter based on the mix of the services recognized.

[0001564590-18-019154:mdna:34]
[same as prior period, unchanged from 0001564590-18-012467:mdna:34]

[0001564590-18-019154:mdna:35]
Selling, general and administrative expenses decreased 7.6% from $34.7 million in the three months ended June 30, 2017 to $32.1 million in the three months ended June 30, 2018, and decreased 5.6% from $69.5 million in the six months ended June 30, 2017 to $65.6 million in the six months ended June 30, 2018. The decrease in selling, general and administrative expenses for the three months ended June 30, 2018 is primarily attributable to decreases in performance-based compensation expense, travel expense, deferred compensation expense, and independent contractor expense, partially offset by an increase in labor expense due to a restructuring program. The decrease in selling, general and administrative expenses for the six months ended June 30, 2018 is primarily attributable to a decrease in deferred compensation expense, performance-based compensation expense, travel expense, and independent contractor expense, partially offset by an increase in labor expense due to a restructuring program.

[0001564590-18-019154:mdna:36]
As a percentage of sales, selling, general and administrative expenses increased from 18.8% in the three months ended June 30, 2017 to 25.1% in the three months ended June 30, 2018, and increased from 19.6% in the six months ended June 30, 2017 to 26.4% in the six months ended June 30, 2018. Selling, general and administrative expenses as a percentage of sales may fluctuate whenever there is a significant fluctuation in revenues for the periods being compared.

[0001564590-18-019154:mdna:37]
[same as prior period, unchanged from 0001564590-18-012467:mdna:37]

[0001564590-18-019154:mdna:38]
Research and development expenses decreased 8.4% from $33.6 million in the three months ended June 30, 2017 to $30.7 million in the three months ended June 30, 2018, and decreased 3.0% from $65.5 million in the six months ended June 30, 2017 to $63.6 million in the six months ended June 30, 2018. The decrease in research and development expenses for the three months ended June 30, 2018 is primarily attributable to decreases in engineering materials, independent contractor expense, amortization of intangibles acquired in the third quarter of 2016 that were fully amortized in 2017, and performance-based compensation expense. The decrease in research and development expenses for the six months ended June 30, 2018 is primarily attributable to decreases in engineering materials and amortization of intangibles acquired in the third quarter of 2016 that were fully amortized in 2017, partially offset by an increase in labor expense due to a restructuring program.

[0001564590-18-019154:mdna:39]
As a percentage of sales, research and development expenses increased from 18.2% in the three months ended June 30, 2017 to 24.0% in the three months ended June 30, 2018, and increased from 18.5% in the six months ended June 30, 2017 to 25.5% in the six months ended June 30, 2018. Research and development expenses as a percentage of sales will fluctuate whenever there are incremental product development activities or significant fluctuations in revenues for the periods being compared.

[0001564590-18-019154:mdna:40]
[same as prior period, unchanged from 0001564590-18-012467:mdna:40]

[0001564590-18-019154:mdna:41]
[same as prior period, unchanged from 0001564590-18-012467:mdna:41]

[0001564590-18-019154:mdna:42]
Interest and dividend income decreased 6.1% from $1.0 million in the three months ended June 30, 2017 to $0.9 million in the three months ended June 30, 2018, and decreased 6.6% from $1.9 million in the six months ended June 30, 2017 to $1.8 million in the six months ended June 30, 2018. The decrease in interest and dividend income for the three and six months ended June 30, 2018 is primarily attributable to a decrease in investment balances and a decrease in the rate of return on those investments.

[0001564590-18-019154:mdna:43]
[same as prior period, unchanged from 0001564590-18-012467:mdna:43]

[0001564590-18-019154:mdna:44]
Interest expense, which is primarily related to our taxable revenue bond, remained constant at $0.1 million in the three months ended June 30, 2017 and 2018, and $0.3 million in the six months ended June 30, 2017 and 2018, as we had no substantial change in our fixed-rate borrowing. See “Liquidity and Capital Resources” below for additional information on our revenue bond.

[0001564590-18-019154:mdna:45]
[same as prior period, unchanged from 0001564590-18-012467:mdna:45]

[0001564590-18-019154:mdna:46]
Net realized investment gains decreased 28.8% from $1.4 million in the three months ended June 30, 2017 to $1.0 million in the three months ended June 30, 2018, and decreased 52.0% from $1.9 million in the six months ended June 30, 2017 to $0.9 million in the six months ended June 30, 2018. The decrease in net realized investment gains for the three and six months ended June 30, 2018 is primarily attributable to changes in fair value on equity securities recognized during the period under ASC 2016-01. Prior to January 1, 2018, changes in fair value were recognized in accumulated other comprehensive income, net of deferred taxes, on the balance sheet. See Note 1, Note 7 and “Investing Activities” in “Liquidity and Capital Resources” below for additional information.

[0001564590-18-019154:mdna:47]
OTHER EXPENSE, NET

[0001564590-18-019154:mdna:48]
Other expense, net, comprised primarily of miscellaneous income, gains and losses on foreign currency transactions, gains and losses on foreign exchange forward contracts, investment account management fees, and scrap raw material sales, decreased 69.8% from $0.7 million of expense in the three months ended June 30, 2017 to $0.2 million of expense in the three months ended June 30, 2018, and decreased 53.2% from $0.6 million of expense in the six months ended June 30, 2017 to $0.3 million of expense in the six months ended June 30, 2018. The change in other expense, net for the three and six months ended June 30, 2018 is primarily attributable to higher losses on foreign exchange contracts in 2017.

[0001564590-18-019154:mdna:49]
[same as prior period, unchanged from 0001564590-18-012467:mdna:49]

[0001564590-18-019154:mdna:50]
[same as prior period, unchanged from 0001564590-18-012467:mdna:50]

[0001564590-18-019154:mdna:51]
[same as prior period, unchanged from 0001564590-18-012467:mdna:51]

[0001564590-18-019154:mdna:52]
Our effective tax rate decreased from an expense of 27.3% in the six months ended June 30, 2017 to a benefit of 20.1%, excluding the tax effect of the bargain purchase gain, in the six months ended June 30, 2018. The decrease in the effective tax rate between the two periods is primarily attributable to the change in income and the effect of the U.S. Tax Cuts and Jobs Act, which was signed into law on December 22, 2017.

[0001564590-18-019154:mdna:53]
[same as prior period, unchanged from 0001564590-18-012467:mdna:53]

[0001564590-18-019154:mdna:54]
As a result of the above factors, net income (loss) decreased $20.1 million from $12.4 million in the three months ended June 30, 2017 to $(7.7) million in the three months ended June 30, 2018, and decreased $37.5 million from $19.1 million in the six months ended June 30, 2017 to $(18.5) million in the six months ended June 30, 2018.

[0001564590-18-019154:mdna:55]
[same as prior period, unchanged from 0001564590-18-012467:mdna:55]

[0001564590-18-019154:mdna:56]
[same as prior period, unchanged from 0001564590-18-012467:mdna:56]

[0001564590-18-019154:mdna:57]
[same as prior period, unchanged from 0001564590-18-012467:mdna:57]

[0001564590-18-019154:mdna:58]
At June 30, 2018, cash on hand was $100.3 million and short-term investments were $6.1 million, which resulted in available short-term liquidity of $106.4 million, of which $83.0 million was held by our foreign subsidiaries. At December 31, 2017, cash on hand was $86.4 million and short-term investments were $16.1 million, which resulted in available short-term liquidity of $102.6 million, of which $56.8 million was held by our foreign subsidiaries. We intend to permanently reinvest the funds held by our foreign subsidiaries outside the U.S. and our current business plans do not indicate a need to repatriate these funds to finance domestic operations. The increase in short-term liquidity from December 31, 2017 to June 30, 2018 is primarily attributable to shifts among available investment option tenures to provide funds for our short-term cash needs.

[0001564590-18-019154:mdna:59]
[same as prior period, unchanged from 0001564590-18-012467:mdna:59]

[0001564590-18-019154:mdna:60]
Our working capital, which consists of current assets less current liabilities, decreased 26.7% from $306.3 million as of December 31, 2017 to $224.6 million as of June 30, 2018, and our current ratio, defined as current assets divided by current liabilities, decreased from 3.87 as of December 31, 2017 to 2.93 as of June 30, 2018. The decreases in our working capital and current ratio are primarily attributable to decreases in accounts receivable and prepaid expenses and other current assets, and an increase in income tax payable. The quick ratio, defined as cash, cash equivalents, short-term investments, and net accounts receivable, divided by current liabilities, decreased from 2.31 as of December 31, 2017 to 1.57 as of June 30, 2018. The decrease in the quick ratio is primarily attributable to a decrease in accounts receivable and an increase in income tax payable.

[0001564590-18-019154:mdna:61]
Accounts receivable decreased 47.2% from $144.2 million at December 31, 2017 to $76.1 million at June 30, 2018. We had no allowance for doubtful accounts at December 31, 2017 or June 30, 2018. Quarterly accounts receivable days sales outstanding (DSO) decreased from 105 days as of December 31, 2017 to 54 days as of June 30, 2018. The decrease in net accounts receivable is due to the collection of customer-specific payment terms that became due in the first quarter of 2018 and the timing of sales and collections during the quarter. Additionally, certain international customers may have longer payment terms than U.S. customers.

[0001564590-18-019154:mdna:62]
Quarterly inventory turnover decreased from 3.09 turns as of December 31, 2017 to 2.60 turns at June 30, 2018. Inventory decreased 1.6% from $122.5 million at December 31, 2017 to $120.5 million at June 30, 2018. We expect inventory levels to fluctuate as we attempt to maintain sufficient inventory in response to services activity and seasonal cycles of our business, ensuring competitive lead times while managing the risk of inventory obsolescence that may occur due to rapidly changing technology and customer demand.

[0001564590-18-019154:mdna:63]
Prepaid expense and other current assets decreased 45.2% from $17.3 million at December 31, 2017 to $9.5 million at June 30, 2018. The decrease in prepaid expenses and other current assets is primarily attributable to the recognition of deferred costs related to network installation services that were completed during the first quarter.

[0001564590-18-019154:mdna:64]
Income tax payable increased 203.6% from $3.9 million at December 31, 2017 to $11.9 million at June 30, 2018. The increase in income tax payable is primarily attributable to income taxes accrued for foreign jurisdictions.

[0001564590-18-019154:mdna:65]
[same as prior period, unchanged from 0001564590-18-012467:mdna:66]

[0001564590-18-019154:mdna:66]
Capital expenditures totaled approximately $4.2 million and $7.5 million for the six months ended June 30, 2018 and 2017, respectively. These expenditures were primarily used to purchase computer hardware, software, manufacturing and test equipment, and building improvements.

[0001564590-18-019154:mdna:67]
Our combined short-term and long-term investments increased $4.1 million from $146.4 million at December 31, 2017 to $150.5 million at June 30, 2018. This increase reflects funds available for investment provided by our operating activities, as well as net realized and unrealized gains and losses and amortization of net premiums on our combined investments, partially offset by our cash needs for capital expenditures, purchases of treasury stock, and shareholder dividends.

[0001564590-18-019154:mdna:68]
We invest all available cash not required for immediate use in operations primarily in securities that we believe bear minimal risk of loss. At June 30, 2018 these investments included corporate bonds of $35.7 million, municipal fixed-rate bonds of $2.2 million, asset-backed bonds of $10.3 million, mortgage/agency-backed bonds of $7.2 million, U.S. government bonds of $8.8 million, and foreign government bonds of $1.4 million. At December 31, 2017, these investments included corporate bonds of $32.5 million, municipal fixed-rate bonds of $2.9 million, asset-backed bonds of $6.5 million, mortgage/agency-backed bonds of $5.5 million, U.S. government bonds of $14.3 million, and foreign government bonds of $0.7 million. As of June 30, 2018, our corporate bonds, municipal fixed-rate bonds, asset-backed bonds, mortgage/agency-backed bonds, U.S. government bonds, and foreign government bonds were classified as available-for-sale and had a combined duration of 1.3 years with an average Standard & Poor’s credit rating of AA-. Because our bond portfolio has a high-quality rating and contractual maturities of short duration, we are able to obtain prices for these bonds derived from observable market inputs, or for similar securities traded in an active market, on a daily basis.

[0001564590-18-019154:mdna:69]
Our long-term investments increased 10.9% from $130.3 million at December 31, 2017 to $144.4 million at June 30, 2018. Long-term investments at June 30, 2018 and December 31, 2017 included an investment in a certificate of deposit of $26.7 million and $27.8 million, respectively, which serves as collateral for our revenue bond. See “Debt” below for additional information. We have various equity investments included in long-term investments with a fair value of $37.6 million and $35.7 million, at June 30, 2018 and December 31, 2017, respectively.

[0001564590-18-019154:mdna:70]
Long-term investments at June 30, 2018 and December 31, 2017 also included $20.4 million and $19.9 million, respectively, related to our deferred compensation plans, and $0.5 million of other investments carried at cost, consisting of interests in two private equity funds and an investment in a privately held telecommunications equipment manufacturer.

[0001564590-18-019154:mdna:71]
[same as prior period, unchanged from 0001564590-18-012467:mdna:72]

[0001564590-18-019154:mdna:72]
[same as prior period, unchanged from 0001564590-18-012467:mdna:73]

[0001564590-18-019154:mdna:73]
In July 2003, our Board of Directors elected to begin declaring quarterly dividends on our common stock considering the tax treatment of dividends and adequate levels of Company liquidity. During the six months ended June 30, 2018, we paid dividends totaling $8.7 million.

[0001564590-18-019154:mdna:74]
[same as prior period, unchanged from 0001564590-18-012467:mdna:75]

[0001564590-18-019154:mdna:75]
We have amounts outstanding under loans made pursuant to an Alabama State Industrial Development Authority revenue bond (the Bond) which totaled $26.7 million at June 30, 2018 and December 31, 2017. At June 30, 2018, the estimated fair value of the Bond was approximately $26.5 million, based on a debt security with a comparable interest rate and maturity and a Standard & Poor’s credit rating of AAA. Included in long-term investments are restricted funds in the amount of $26.7 million and $27.8 million at June 30, 2018 and December 31, 2017, respectively, which is a collateral deposit against the principal amount of the Bond. We have the right to set-off the balance of the Bond with the collateral deposit in order to reduce the balance of the indebtedness. The Bond matures on January 1, 2020, and bears interest at the rate of 2% per annum. In conjunction with this program, we are eligible to receive certain economic incentives from the state of Alabama that reduce the amount of payroll withholdings we are required to remit to the state for those employment positions that qualify under this program. We are required to make payments in the amounts necessary to pay the interest on the amounts currently outstanding. It is our intent to make annual principal payments in addition to the interest amounts that are due. In connection with this decision, $1.1 million of the Bond has been classified as a current liability in accounts payable in the Consolidated Balance Sheet at June 30, 2018.

[0001564590-18-019154:mdna:76]
[same as prior period, unchanged from 0001564590-18-012467:mdna:77]

[0001564590-18-019154:mdna:77]
Since 1997, our Board of Directors has approved multiple share repurchase programs that have authorized open market repurchase transactions of up to 50.0 million shares of our common stock that are implemented through open market or private purchases from time to time as conditions warrant. During the six months ended June 30, 2018, we repurchased 0.8 million shares of our common stock at an average price of $15.72 per share. As of June 30, 2018, we have the authority to purchase an additional 2.7 million shares of our common stock under the current plans approved by the Board of Directors.

[0001564590-18-019154:mdna:78]
[same as prior period, unchanged from 0001564590-18-012467:mdna:79]

[0001564590-18-019154:mdna:79]
We issued 24 thousand shares of treasury stock during the six months ended June 30, 2018 to accommodate employee stock option exercises. The stock options had exercise prices ranging from $15.29 to $18.97. We received proceeds totaling $0.4 million from the exercise of these stock options during the six months ended June 30, 2018.

[0001564590-18-019154:mdna:80]
[same as prior period, unchanged from 0001564590-18-012467:mdna:81]

[0001564590-18-019154:mdna:81]
We do not have off-balance sheet financing arrangements and have not engaged in any related party transactions or arrangements with unconsolidated entities or other persons that are reasonably likely to materially affect liquidity or the availability of or requirements for capital resources. During the six months ended June 30, 2018, there have been no material changes in contractual obligations and commercial commitments from those discussed in our most recent Annual Report on Form 10-K for the year ended December 31, 2017 filed on February 23, 2018 with the SEC.

[0001564590-18-019154:mdna:82]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, and we have contributed $8.4 million as of June 30, 2018, of which $7.7 million has been applied to these commitments.
