# ADTN note change history — 0001564590-18-012467 → 0001564590-18-019154


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2018-08-03):
[0001564590-18-019154:note_history:1]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, and we have contributed $8.4 million as of June 30, 2018, of which $7.7 million has been applied to these commitments.
  (was, 2018-05-09, similarity 0.9773):
[0001564590-18-012467:note_history:1]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, and we have contributed $8.4 million as of March 31, 2018, of which $7.7 million has been applied to these commitments.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2018-08-03):
[0001564590-18-019154:note_history:2]
In February 2016, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update (ASU) 2016-02, Leases (Topic 842). ASU 2016-02 requires an entity to recognize lease assets and lease liabilities on the balance sheet and to disclose key information about the entity's leasing arrangements. Subsequently, in July 2018, the FASB issued ASU 2018-10, Codification Improvements to Topic 842, Leases, which clarified certain aspects of ASU 2016-02. ASU 2016-02 and ASU 2018-10 are effective for fiscal years beginning after December 15, 2018, and interim periods within those fiscal years. A modified retrospective approach is required. We anticipate the adoption of these ASUs will have a material increase in the assets and liabilities of our consolidated balance sheets; however, we do not believe adoption will have a material effect on our results of operations. We believe the most significant effect relates to our accounting for operating leases for office space and equipment.

- added (2018-08-03):
[0001564590-18-019154:note_history:3]
In June 2016, the FASB issued ASU 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. ASU 2016-13 requires the measurement and recognition of expected credit losses for financial instruments held at amortized cost. ASU 2016-13 is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019, with early adoption permitted. We are currently evaluating the effect ASU 2016-13 will have on our consolidated financial statements.

- changed (2018-08-03):
[0001564590-18-019154:note_history:4]
In January 2017, the FASB issued ASU 2017-04, Intangibles – Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment. ASU 2017-04 simplifies the measurement of goodwill by eliminating step 2 of the goodwill impairment test. Under ASU 2017-04, entities will be required to compare the fair value of a reporting unit to its carrying amount and recognize an impairment charge for the amount by which the carrying amount exceeds the reporting unit’s fair value. ASU 2017-04 is effective for annual or interim impairment tests performed in fiscal years beginning after December 15, 2019, with early adoption permitted for annual or interim impairment tests performed on testing dates after January 1, 2017. The amendments should be applied prospectively. We are currently evaluating whether to early adopt ASU 2017-04, but we do not expect it will have a material effect on our consolidated financial statements.
  (was, 2018-05-09, similarity 0.9149):
[0001564590-18-012467:note_history:4]
In January 2017, the FASB issued Accounting Standards Update No. 2017-04, Intangibles – Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment (ASU 2017-04). ASU 2017-04 simplifies the measurement of goodwill by eliminating step 2 of the goodwill impairment test. Under ASU 2017-04, entities will be required to compare the fair value of a reporting unit to its carrying amount and recognize an impairment charge for the amount by which the carrying amount exceeds the reporting unit’s fair value. ASU 2017-04 is effective for annual or interim impairment tests performed in fiscal years beginning after December 15, 2019, with early adoption permitted for annual or interim impairment tests performed on testing dates after January 1, 2017. The amendments should be applied prospectively. We are currently evaluating whether to early adopt ASU 2017-04, but we do not expect it will have a material impact on our financial position, results of operations or cash flows.

- changed (2018-08-03):
[0001564590-18-019154:note_history:5]
In August 2017, the FASB issued ASU 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities. ASU 2017-12 expands and refines hedge accounting for both financial and non-financial risk components, aligns the recognition and presentation of the effects of hedging instruments and hedge items in the financial statements, and includes certain targeted improvements to ease the application of current guidance related to the assessment of hedge effectiveness. ASU 2017-12 is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2018, with early adoption permitted. We are currently evaluating the effect ASU 2017-12 will have on our consolidated financial statements.
  (was, 2018-05-09, similarity 0.9104):
[0001564590-18-012467:note_history:5]
In August 2017, the FASB issued Accounting Standards Update No. 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities (ASU 2017-12). ASU 2017-12 expands and refines hedge accounting for both financial and non-financial risk components, aligns the recognition and presentation of the effects of hedging instruments and hedge items in the financial statements, and includes certain targeted improvements to ease the application of current guidance related to the assessment of hedge effectiveness. ASU 2017-12 is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2018, with early adoption permitted. We are currently evaluating the impact ASU 2017-12 will have on our financial position, results of operations and cash flows.

- added (2018-08-03):
[0001564590-18-019154:note_history:6]
In February 2018, the FASB issued ASU 2018-02, Income Statement – Reporting Comprehensive Income (Topic 220): Reclassification of Certain Tax Effects from Accumulated Comprehensive Income. ASU 2018-02 allows for an optional reclassification from accumulated other comprehensive income to retained earnings for stranded tax effects resulting from the Tax Cuts and Jobs Act of 2017. ASU 2018-02 is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2018, with early adoption permitted. We are currently evaluating whether to reclassify stranded tax effects related to the Tax Cuts and Jobs Act of 2017, but we do not expect ASU 2018-02 will have a material effect on our consolidated financial statements.

- changed (2018-08-03):
[0001564590-18-019154:note_history:7]
During 2018, we adopted the following accounting standards, which had the following effects on our consolidated financial statements:
  (was, 2018-05-09, similarity 0.7292):
[0001564590-18-012467:note_history:7]
During 2018, we adopted the following accounting standards, which had no material effect on our financial position, results of operations or cash flows:

- changed (2018-08-03):
[0001564590-18-019154:note_history:8]
In May 2014, the FASB issued ASU 2014-09, Revenue from Contracts with Customers (Topic 606), which supersedes the revenue recognition requirements in Topic 605, Revenue Recognition, including most industry-specific revenue recognition guidance throughout the Industry Topics of the Codification. The core principle of ASU 2014-09 is to recognize revenues when promised goods or services are transferred to customers in an amount that reflects the consideration that is expected to be received for those goods or services. In August 2015, the FASB issued ASU 2015-14, which deferred the effective date of ASU 2014-09 to fiscal years beginning after December 31, 2017, and interim periods within those fiscal years, with early adoption permitted for reporting periods beginning after December 15, 2016. Subsequently, the FASB issued ASUs in 2016 containing implementation guidance related to ASU 2014-09, including: ASU 2016-08, Revenue from Contracts with Customers (Topic 606): Principal versus Agent Considerations (Reporting Revenue Gross versus Net), which is intended to improve the operability and understandability of the implementation guidance on principal versus agent considerations; ASU 2016-10, Revenue from Contracts with Customers (Topic 606): Identifying Performance Obligations and Licensing, which is intended to clarify two aspects of Topic 606: identifying performance obligations and the licensing implementation guidance; ASU 2016-12, Revenue from Contracts with Customers (Topic 606): Narrow-Scope Improvements and Practical Expedients, which contains certain provisions and practical expedients in response to identified implementation issues; and ASU 2016-20, Technical Corrections and Improvements to Topic 606, Revenue from Contracts with Customers, which is intended to clarify the Codification and/or to correct unintended application of guidance. ASU 2014-09 allows for either full retrospective or modified retrospective adoption. We adopted ASU 2014-09 and the related ASUs on January 1, 2018 using the modified retrospective method, which was applied to all contracts on the date of initial adoption.
  (was, 2018-05-09, similarity 0.9742):
[0001564590-18-012467:note_history:8]
In May 2014, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update No. 2014-09, Revenue from Contracts with Customers (Topic 606) (ASU 2014-09), which supersedes the revenue recognition requirements in Topic 605, Revenue Recognition, including most industry-specific revenue recognition guidance throughout the Industry Topics of the Codification. The core principle of ASU 2014-09 is to recognize revenues when promised goods or services are transferred to customers in an amount that reflects the consideration that is expected to be received for those goods or services. In August 2015, the FASB issued ASU 2015-14, which deferred the effective date of ASU 2014-09 to fiscal years beginning after December 31, 2017, and interim periods within those fiscal years, with early adoption permitted for reporting periods beginning after December 15, 2016. Subsequently, the FASB issued ASUs in 2016 containing implementation guidance related to ASU 2014-09, including: ASU 2016-08, Revenue from Contracts with Customers (Topic 606): Principal versus Agent Considerations (Reporting Revenue Gross versus Net), which is intended to improve the operability and understandability of the implementation guidance on principal versus agent considerations; ASU 2016-10, Revenue from Contracts with Customers (Topic 606): Identifying Performance Obligations and Licensing, which is intended to clarify two aspects of Topic 606: identifying performance obligations and the licensing implementation guidance; ASU 2016-12, Revenue from Contracts with Customers (Topic 606): Narrow-Scope Improvements and Practical Expedients, which contains certain provisions and practical expedients in response to identified implementation issues; and ASU 2016-20, Technical Corrections and Improvements to Topic 606, Revenue from Contracts with Customers, which is intended to clarify the Codification or to correct unintended application of guidance. ASU 2014-09 allows for either full retrospective or modified retrospective adoption. We adopted ASU 2014-09 and the related ASUs on January 1, 2018 using the modified retrospective method, which was applied to all contracts on the date of initial adoption.

- added (2018-08-03):
[0001564590-18-019154:note_history:9]
These ASUs primarily affected our network implementation service revenue performance obligations and contract costs. We are using the “output method” to measure network implementation services progress, which 1) accelerates revenue recognition for certain performance obligations related to service revenue arrangements that were previously deferred until customer acceptance and 2) requires capitalization and amortization of the incremental costs of obtaining a contract as described below.

- added (2018-08-03):
[0001564590-18-019154:note_history:10]
In connection with the adoption of the new revenue standard, effective January 1, 2018, we adopted ASC 340-40, Other Assets and Deferred Costs – Contracts with Customers, with respect to capitalization and amortization of incremental costs of obtaining a contract. As a result, certain costs of obtaining a contract, including sales commissions, will be capitalized, as the guidance requires the capitalization of all incremental costs incurred to obtain a contract with a customer that it would not have incurred if the contract had not been obtained, provided the costs are recoverable. The primary effect was the capitalization of certain sales commissions for our extended maintenance and support contracts in excess of one year and amortization of those costs over the period that the related revenue is recognized.

- changed (2018-08-03):
[0001564590-18-019154:note_history:11]
The effect of the adoption of ASU 2014-09 and the related ASUs on our financial statements was as follows:
  (was, 2018-05-09, similarity 0.9608):
[0001564590-18-012467:note_history:11]
The impact of the adoption of ASU 2014-09 and the related ASUs on our financial statements was as follows:

- changed (2018-08-03):
[0001564590-18-019154:note_history:12]
|  |  | For the three months ended June 30, 2018 |  |
| (In thousands) |  | As Reported |  |  | Balances Without Adoption of ASC 606 |  |  | Effect of Adoption of ASC 606 |  |
| Sales |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  | $ | 115,063 |  |  |  | 115,437 |  |  | $ | (374 | ) |
| Services |  | $ | 12,985 |  |  |  | 13,430 |  |  | $ | (445 | ) |
| Cost of Sales |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  | $ | 69,629 |  |  |  | 70,003 |  |  | $ | (374 | ) |
| Services |  | $ | 8,423 |  |  |  | 8,772 |  |  | $ | (349 | ) |
| Loss before benefit for income taxes |  | $ | (11,259 | ) |  |  | (11,163 | ) |  | $ | (96 | ) |
| Benefit for income taxes |  | $ | 3,589 |  |  |  | 3,558 |  |  | $ | 31 |  |
| Net loss |  | $ | (7,670 | ) |  |  | (7,605 | ) |  | $ | (65 | ) |
  (was, 2018-05-09, similarity 0.7823):
[0001564590-18-012467:note_history:12]
|  |  | For the three months ended March 31, 2018 |  |
| (In thousands) |  | As Reported |  |  | Balances Without Adoption of ASC 606 |  |  | Effect of Change Higher/(Lower) |  |
| Sales |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  | $ | 105,253 |  |  |  | 105,439 |  |  | $ | (186 | ) |
| Services |  | $ | 15,553 |  |  |  | 14,700 |  |  | $ | 853 |  |
| Cost of Sales |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  | $ | 68,612 |  |  |  | 68,723 |  |  | $ | (111 | ) |
| Services |  | $ | 12,461 |  |  |  | 11,925 |  |  | $ | 536 |  |
| Loss before benefit for income taxes |  | $ | (14,745 | ) |  |  | (14,987 | ) |  | $ | 242 |  |
| Benefit for income taxes |  | $ | 3,931 |  |  |  | 3,998 |  |  | $ | (67 | ) |
| Net loss |  | $ | (10,814 | ) |  |  | (10,989 | ) |  | $ | 175 |  |

- added (2018-08-03):
[0001564590-18-019154:note_history:13]
|  |  | For the six months ended June 30, 2018 |  |
| (In thousands) |  | As Reported |  |  | Balances Without Adoption of ASC 606 |  |  | Effect of Adoption of ASC 606 |  |
| Sales |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  | $ | 220,316 |  |  |  | 220,876 |  |  | $ | (560 | ) |
| Services |  | $ | 28,538 |  |  |  | 28,130 |  |  | $ | 408 |  |
| Cost of Sales |  |  |  |  |  |  |  |  |  |  |  |  |
| Products |  | $ | 138,241 |  |  |  | 138,726 |  |  | $ | (485 | ) |
| Services |  | $ | 20,884 |  |  |  | 20,697 |  |  | $ | 187 |  |
| Loss before benefit for income taxes |  | $ | (26,004 | ) |  |  | (26,150 | ) |  | $ | 146 |  |
| Benefit for income taxes |  | $ | 7,520 |  |  |  | 7,556 |  |  | $ | (36 | ) |
| Net loss |  | $ | (18,484 | ) |  |  | (18,594 | ) |  | $ | 110 |  |

- changed (2018-08-03):
[0001564590-18-019154:note_history:14]
|  |  | As of June 30, 2018 |  |
| (In thousands) |  | As Reported |  |  | Balances Without Adoption of ASC 606 |  |  | Effect of Adoption of ASC 606 |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Other receivables |  | $ | 28,163 |  |  |  | 28,164 |  |  | $ | (1 | ) |
| Inventory |  | $ | 120,537 |  |  |  | 120,426 |  |  | $ | 111 |  |
| Equity |  |  |  |  |  |  |  |  |  |  |  |  |
| Retained earnings |  | $ | 897,586 |  |  |  | 897,476 |  |  | $ | 110 |  |
  (was, 2018-05-09, similarity 0.6649):
[0001564590-18-012467:note_history:14]
|  |  | As of March 31, 2018 |  |
| (In thousands) |  | As Reported |  |  | Balances Without Adoption of ASC 606 |  |  | Effect of Change Higher/(Lower) |  |
| Assets |  |  |  |  |  |  |  |  |  |  |  |  |
| Other receivables |  | $ | 35,124 |  |  |  | 35,060 |  |  | $ | 64 |  |
| Inventory |  | $ | 120,021 |  |  |  | 119,910 |  |  | $ | 111 |  |
| Equity |  |  |  |  |  |  |  |  |  |  |  |  |
| Retained earnings |  | $ | 909,611 |  |  |  | 909,436 |  |  | $ | 175 |  |

- added (2018-08-03):
[0001564590-18-019154:note_history:15]
In January 2016, the FASB issued ASU 2016-01, Financial Instruments — Overall: Recognition and Measurement of Financial Assets and Financial Liabilities, which addresses certain aspects of the recognition, measurement, presentation and disclosure of financial instruments. Subsequently, the FASB issued ASU 2018-03, Technical Corrections and Improvements to Financial Instruments – Overall (Subtopic 825-10): Recognition and Measurement of Financial Assets and Financial Liabilities, which issued technical corrections and improvements intended to clarify certain aspects of ASU 2016-01. ASU 2016-01 was effective beginning January 1, 2018 and we now recognize any changes in the fair value of certain equity investments in net income as prescribed by the new standard rather than in other comprehensive income. We adopted ASU 2016-01 on January 1, 2018 using the modified retrospective method, which resulted in a $3.2 million reclassification of net unrealized gains from accumulated other comprehensive income to opening retained earnings. ASU 2018-03 is effective for us with the interim period beginning after June 15, 2018. We are currently evaluating the effect ASU 2018-03 will have on our consolidated financial statements.

- changed (2018-08-03):
[0001564590-18-019154:note_history:16]
In March 2017, the FASB issued ASU 2017-07, Compensation – Retirement Benefits (Topic 715): Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost. ASU 2017-07 amends ASC 715, Compensation — Retirement Benefits, to require employers that present a measure of operating income in their statements of earnings to include only the service cost component of net periodic pension cost and net periodic postretirement benefit cost in operating expenses (together with other employee compensation costs). The other components of net benefit cost, including amortization of prior service cost/credit, and settlement and curtailment effects, are to be included in non-operating expenses. We adopted ASU 2017-07 on January 1, 2018. We retrospectively adopted the presentation of service cost separate from other components of net periodic pension costs. As a result, $0.1 million and $0.2 million have been reclassified from cost of sales, selling, general and administrative expenses, and research and development expense to other expense, net for the three and six months ended June 30, 2017, respectively.
  (was, 2018-05-09, similarity 0.6003):
[0001564590-18-012467:note_history:16]
In March 2017, the FASB issued Accounting Standards Update No. 2017-07, Compensation – Retirement Benefits (Topic 715): Improving the Presentation of Net Periodic Pension Cost and Net Periodic Postretirement Benefit Cost (ASU 2017-07). ASU 2017-07 amends ASC 715, Compensation — Retirement Benefits, to require employers that present a measure of operating income in their statements of earnings to include only the service cost component of net periodic pension cost and net periodic postretirement benefit cost in operating expenses (together with other employee compensation costs). The other components of net benefit cost, including amortization of prior service cost/credit, and settlement and curtailment effects, are to be included in non-operating expenses. We adopted ASU 2017-07 on January 1, 2018. We retrospectively adopted the presentation of service cost separate from other components of net periodic pension costs. As a result, $0.1 million was reclassified from cost of sales, selling, general and administrative expenses, and research and development expense to other income (expense), net for the three months ended March 31, 2017.

- removed (2018-08-03):
[0001564590-18-012467:note_history:17]
In February 2016, the FASB issued Accounting Standards Update No. 2016-02, Leases (Topic 842) (ASU 2016-02). ASU 2016-02 requires an entity to recognize lease assets and lease liabilities on the balance sheet and to disclose key information about the entity's leasing arrangements. ASU 2016-02 is effective for fiscal years beginning after December 15, 2018, and interim periods within those fiscal years. A modified retrospective approach is required. We anticipate the adoption of ASU 2016-02 will have a material impact on our financial position; however, we do not believe adoption will have a material impact on our results of operations. We believe the most significant impact relates to our accounting for operating leases for office space and equipment.

- removed (2018-08-03):
[0001564590-18-012467:note_history:18]
The two primary areas of impact of these ASUs were network implementation service revenue performance obligations and contract costs. The output method will be used to measure network implementation services progress. The primary impact will be accelerated revenue recognition for certain performance obligations related to service revenue arrangements that were previously deferred until customer acceptance and capitalization and amortization of incremental costs of obtaining a contract as described below.

- removed (2018-08-03):
[0001564590-18-012467:note_history:19]
In connection with the adoption of the new revenue standard, effective January 1, 2018, we adopted ASC 340-40, Other Assets and Deferred Costs - Contracts with Customers, with respect to capitalization and amortization of incremental costs of obtaining a contract. As a result, certain costs of obtaining a contract will need to be capitalized, including sales commissions, as the guidance requires the capitalization of all incremental costs incurred to obtain a contract with a customer that it would not have incurred if the contract had not been obtained, provided the costs are recoverable. The primary impact was capitalization of certain sales commissions for our extended maintenance and support contracts in excess of one year and amortization of those costs over the period that the related revenue is recognized.

- removed (2018-08-03):
[0001564590-18-012467:note_history:20]
In January 2016, the FASB issued Accounting Standards Update 2016-01, Financial Instruments — Overall: Recognition and Measurement of Financial Assets and Financial Liabilities (ASU 2016-01) which addresses certain aspects of the recognition, measurement, presentation and disclosure of financial instruments. ASU 2016-01 was effective beginning January 1, 2018 and we are now recognizing any changes in the fair value of certain equity investments in net income as prescribed by the new standard rather than in other comprehensive income. We adopted ASU 2016-01 on January 1, 2018 using the modified retrospective method, which resulted in $3.2 million reclassification of net unrealized gains from accumulated other comprehensive income to opening retained earnings.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2018-08-03):
[0001564590-18-019154:note_history:21]
At June 30, 2018, we held the following debt securities and other investments, recorded at either fair value or cost:
  (was, 2018-05-09, similarity 0.9596):
[0001564590-18-012467:note_history:21]
At March 31, 2018, we held the following debt securities and other investments, recorded at either fair value or cost:

- changed (2018-08-03):
[0001564590-18-019154:note_history:22]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Carrying |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 35,896 |  |  | $ | 27 |  |  | $ | (250 | ) |  | $ | 35,673 |  |
| Municipal fixed-rate bonds |  |  | 2,259 |  |  |  | — |  |  |  | (38 | ) |  |  | 2,221 |  |
| Asset-backed bonds |  |  | 10,355 |  |  |  | 1 |  |  |  | (37 | ) |  |  | 10,319 |  |
| Mortgage/Agency-backed bonds |  |  | 7,292 |  |  |  | — |  |  |  | (85 | ) |  |  | 7,207 |  |
| U.S. government bonds |  |  | 8,953 |  |  |  | — |  |  |  | (104 | ) |  |  | 8,849 |  |
| Foreign government bonds |  |  | 1,036 |  |  |  | 2 |  |  |  | — |  |  |  | 1,038 |  |
| Available-for-sale debt securities held at fair value |  | $ | 65,791 |  |  | $ | 30 |  |  | $ | (514 | ) |  | $ | 65,307 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 26,700 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 520 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 92,527 |  |
  (was, 2018-05-09, similarity 0.9719):
[0001564590-18-012467:note_history:22]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Carrying |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  |  | 32,654 |  |  |  | 44 |  |  |  | (155 | ) |  |  | 32,543 |  |
| Municipal fixed-rate bonds |  |  | 2,902 |  |  |  | 2 |  |  |  | (22 | ) |  |  | 2,882 |  |
| Asset-backed bonds |  |  | 6,545 |  |  |  | 1 |  |  |  | (20 | ) |  |  | 6,526 |  |
| Mortgage/Agency-backed bonds |  |  | 5,554 |  |  |  | 1 |  |  |  | (46 | ) |  |  | 5,509 |  |
| U.S. government bonds |  |  | 14,477 |  |  |  | — |  |  |  | (174 | ) |  |  | 14,303 |  |
| Foreign government bonds |  |  | 725 |  |  |  | 5 |  |  |  | — |  |  |  | 730 |  |
| Available-for-sale debt securities held at fair value |  | $ | 62,857 |  |  | $ | 53 |  |  | $ | (417 | ) |  | $ | 62,493 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 27,800 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 547 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 90,840 |  |

- changed (2018-08-03):
[0001564590-18-019154:note_history:23]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Carrying |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 32,654 |  |  | $ | 44 |  |  | $ | (155 | ) |  | $ | 32,543 |  |
| Municipal fixed-rate bonds |  |  | 2,902 |  |  |  | 2 |  |  |  | (22 | ) |  |  | 2,882 |  |
| Asset-backed bonds |  |  | 6,545 |  |  |  | 1 |  |  |  | (20 | ) |  |  | 6,526 |  |
| Mortgage/Agency-backed bonds |  |  | 5,554 |  |  |  | 1 |  |  |  | (46 | ) |  |  | 5,509 |  |
| U.S. government bonds |  |  | 14,477 |  |  |  | — |  |  |  | (174 | ) |  |  | 14,303 |  |
| Foreign government bonds |  |  | 725 |  |  |  | 5 |  |  |  | — |  |  |  | 730 |  |
| Available-for-sale debt securities held at fair value |  | $ | 62,857 |  |  | $ | 53 |  |  | $ | (417 | ) |  | $ | 62,493 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 27,800 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 547 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 90,840 |  |
  (was, 2018-05-09, similarity 0.9658):
[0001564590-18-012467:note_history:23]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Carrying |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  |  | 49,109 |  |  |  | 43 |  |  |  | (333 | ) |  |  | 48,819 |  |
| Municipal fixed-rate bonds |  |  | 2,413 |  |  |  | — |  |  |  | (30 | ) |  |  | 2,383 |  |
| Asset-backed bonds |  |  | 13,334 |  |  |  | — |  |  |  | (44 | ) |  |  | 13,290 |  |
| Mortgage/Agency-backed bonds |  |  | 8,906 |  |  |  | 2 |  |  |  | (72 | ) |  |  | 8,836 |  |
| U.S. government bonds |  |  | 14,703 |  |  |  | 10 |  |  |  | (204 | ) |  |  | 14,509 |  |
| Foreign government bonds |  |  | 1,228 |  |  |  | 4 |  |  |  | (1 | ) |  |  | 1,231 |  |
| Available-for-sale debt securities held at fair value |  | $ | 89,693 |  |  | $ | 59 |  |  | $ | (684 | ) |  | $ | 89,068 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 26,700 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 520 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 116,288 |  |

- changed (2018-08-03):
[0001564590-18-019154:note_history:24]
As of June 30, 2018, our debt securities had the following contractual maturities:
  (was, 2018-05-09, similarity 0.9412):
[0001564590-18-012467:note_history:24]
As of March 31, 2018, our debt securities had the following contractual maturities:

- changed (2018-08-03):
[0001564590-18-019154:note_history:25]
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset- backed bonds |  |  | Mortgage / Agency- backed bonds |  |  | U.S. government bonds |  |  | Foreign government bonds |  |
| Less than one year |  | $ | 1,500 |  |  | $ | 490 |  |  | $ | 4,079 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| One to two years |  |  | 16,694 |  |  |  | 603 |  |  |  | 2,270 |  |  |  | — |  |  |  | 1,519 |  |  |  | 729 |  |
| Two to three years |  |  | 12,264 |  |  |  | 1,128 |  |  |  | 556 |  |  |  | — |  |  |  | 3,845 |  |  |  | 309 |  |
| Three to five years |  |  | 5,215 |  |  |  | — |  |  |  | 1,939 |  |  |  | 1,970 |  |  |  | 3,485 |  |  |  | — |  |
| Five to ten years |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 588 |  |  |  | — |  |  |  | — |  |
| More than ten years |  |  | — |  |  |  | — |  |  |  | 1,475 |  |  |  | 4,649 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 35,673 |  |  | $ | 2,221 |  |  | $ | 10,319 |  |  | $ | 7,207 |  |  | $ | 8,849 |  |  | $ | 1,038 |  |
  (was, 2018-05-09, similarity 0.9556):
[0001564590-18-012467:note_history:25]
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset- backed bonds |  |  | Mortgage / Agency- backed bonds |  |  | U.S. government bonds |  |  | Foreign government bonds |  |
| Less than one year |  | $ | 11,391 |  |  | $ | 490 |  |  | $ | 4,520 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| One to two years |  |  | 18,406 |  |  |  | 737 |  |  | $ | 2,459 |  |  |  | — |  |  |  | 6,149 |  |  |  | — |  |
| Two to three years |  |  | 10,639 |  |  |  | 210 |  |  |  | 2,669 |  |  |  | — |  |  |  | 2,491 |  |  |  | 1,231 |  |
| Three to five years |  |  | 8,383 |  |  |  | 946 |  |  |  | 1,631 |  |  |  | 2,046 |  |  |  | 5,869 |  |  |  | — |  |
| Five to ten years |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 974 |  |  |  | — |  |  |  | — |  |
| More than ten years |  |  | — |  |  |  | — |  |  |  | 2,011 |  |  |  | 5,816 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 48,819 |  |  | $ | 2,383 |  |  | $ | 13,290 |  |  | $ | 8,836 |  |  | $ | 14,509 |  |  | $ | 1,231 |  |

- changed (2018-08-03):
[0001564590-18-019154:note_history:26]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2018 |  |  | 2017 |  |  | 2018 |  |  | 2017 |  |
| Gross realized gains |  | $ | 25 |  |  | $ | 33 |  |  | $ | 25 |  |  | $ | 57 |  |
| Gross realized losses |  | $ | (241 | ) |  | $ | (113 | ) |  | $ | (315 | ) |  | $ | (152 | ) |
  (was, 2018-05-09, similarity 0.7505):
[0001564590-18-012467:note_history:26]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2018 |  |  | 2017 |  |
| Gross realized gains |  | $ | — |  |  | $ | — |  |
| Gross realized losses |  | $ | (73 | ) |  | $ | (15 | ) |

- changed (2018-08-03):
[0001564590-18-019154:note_history:27]
At June 30, 2018, we held a $26.7 million restricted certificate of deposit that is carried at cost. This investment serves as a collateral deposit against the principal amount outstanding under loans made to ADTRAN pursuant to an Alabama State Industrial Development Authority revenue bond (the Bond), which totaled $26.7 million at June 30, 2018 and December 31, 2017. At June 30, 2018 and December 31, 2017, the estimated fair value of the Bond using a level 2 valuation technique was approximately $26.5 million and $26.7 million, respectively, based on a debt security with a comparable interest rate and maturity and a Standard and Poor’s credit rating of AAA. We have the right to set-off the balance of the Bond with the collateral deposit in order to reduce the balance of the indebtedness. The Bond matures on January 1, 2020, and bears interest at the rate of 2% per annum. In conjunction with this program, we are eligible to receive certain economic incentives from the state of Alabama that reduce the amount of payroll withholdings we are required to remit to the state for those employment positions that qualify under this program. We are required to make payments in the amounts necessary to pay the interest on the amounts currently outstanding. It is our intent to make annual principal payments in addition to the interest amounts that are due.
  (was, 2018-05-09, similarity 0.9664):
[0001564590-18-012467:note_history:27]
At March 31, 2018, we held a $26.7 million restricted certificate of deposit, which is carried at cost. This investment serves as a collateral deposit against the principal amount outstanding under loans made to ADTRAN pursuant to an Alabama State Industrial Development Authority revenue bond (the Bond), which totaled $26.7 million at March 31, 2018 and December 31, 2017. At March 31, 2018 and December 31, 2017, the estimated fair value of the Bond using a level 2 valuation technique was approximately $26.6 million and $26.7 million, respectively, based on a debt security with a comparable interest rate and maturity and a Standard and Poor’s credit rating of AAA. We have the right to set-off the balance of the Bond with the collateral deposit in order to reduce the balance of the indebtedness. The Bond matures on January 1, 2020, and bears interest at the rate of 2% per annum. In conjunction with this program, we are eligible to receive certain economic incentives from the state of Alabama that reduce the amount of payroll withholdings we are required to remit to the state for those employment positions that qualify under this program. We are required to make payments in the amounts necessary to pay the interest on the amounts currently outstanding. It is our intent to make annual principal payments in addition to the interest amounts that are due.

- changed (2018-08-03):
[0001564590-18-019154:note_history:28]
On January 1, 2018, we adopted ASU 2016-01, which requires us to measure all equity investments that do not result in consolidation and are not accounted for under the equity method at fair value, with any changes in fair value recognized in net realized investment gain (loss). Upon adoption, we reclassified $3.2 million of net unrealized gains related to marketable equity securities from accumulated other comprehensive income (loss) to opening retained earnings.
  (was, 2018-05-09, similarity 0.9922):
[0001564590-18-012467:note_history:28]
On January 1, 2018, we adopted ASU 2016-01, which requires us to measure all equity investments that do not result in consolidation and are not accounted for under the equity method at fair value, with any changes in fair value recognized in net realized investment gain (loss). Upon adoption, we reclassified $3.2 million of net unrealized gains related to marketable equity securities from accumulated other comprehensive income to opening retained earnings.

- changed (2018-08-03):
[0001564590-18-019154:note_history:29]
Realized and unrealized gains and losses for our marketable equity securities for the three and six months ended June 30, 2018 were as follows:
  (was, 2018-05-09, similarity 0.9368):
[0001564590-18-012467:note_history:29]
Realized and unrealized gains and losses for our marketable equity securities for the three months ended March 31, 2018 were as follows:

- added (2018-08-03):
[0001564590-18-019154:note_history:30]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2018 |  |  | 2018 |  |
| Realized gains (losses) on equity securities sold |  | $ | (52 | ) |  | $ | 347 |  |
| Unrealized gains (losses) on equity securities held |  |  | 1,258 |  |  |  | 836 |  |
| Total gain (loss) recognized, net |  | $ | 1,206 |  |  | $ | 1,183 |  |

- changed (2018-08-03):
[0001564590-18-019154:note_history:31]
As of June 30, 2018 and 2017, gross unrealized losses related to individual investments in a continuous loss position for 12 months or longer were not significant.
  (was, 2018-05-09, similarity 0.9707):
[0001564590-18-012467:note_history:31]
As of March 31, 2018 and 2017, gross unrealized losses related to individual investments in a continuous loss position for 12 months or longer were not significant.

- changed (2018-08-03):
[0001564590-18-019154:note_history:32]
|  |  | Fair Value Measurements at June 30, 2018 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 2,008 |  |  | $ | 2,008 |  |  | $ | — |  |  | $ | — |  |
| Foreign government securities |  |  | 350 |  |  |  | — |  |  |  | 350 |  |  |  | — |  |
| Cash equivalents |  |  | 2,358 |  |  |  | 2,008 |  |  |  | 350 |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 35,673 |  |  |  | — |  |  |  | 35,673 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 2,221 |  |  |  | — |  |  |  | 2,221 |  |  |  | — |  |
| Asset-backed bonds |  |  | 10,319 |  |  |  | — |  |  |  | 10,319 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 7,207 |  |  |  | — |  |  |  | 7,207 |  |  |  | — |  |
| U.S. government bonds |  |  | 8,849 |  |  |  | 8,849 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 1,038 |  |  |  | — |  |  |  | 1,038 |  |  |  | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 37,600 |  |  |  | 37,600 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 20,379 |  |  |  | 20,379 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 123,286 |  |  |  | 66,828 |  |  |  | 56,458 |  |  |  | — |  |
| Total |  | $ | 125,644 |  |  | $ | 68,836 |  |  | $ | 56,808 |  |  | $ | — |  |
  (was, 2018-05-09, similarity 0.9856):
[0001564590-18-012467:note_history:32]
|  |  | Fair Value Measurements at March 31, 2018 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 6,770 |  |  | $ | 6,770 |  |  | $ | — |  |  | $ | — |  |
| Asset-backed securities |  |  | 1,000 |  |  |  | — |  |  |  | 1,000 |  |  |  | — |  |
| Cash equivalents |  |  | 7,770 |  |  |  | 6,770 |  |  |  | 1,000 |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 48,819 |  |  |  | — |  |  |  | 48,819 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 2,383 |  |  |  | — |  |  |  | 2,383 |  |  |  | — |  |
| Asset-backed bonds |  |  | 13,290 |  |  |  | — |  |  |  | 13,290 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 8,836 |  |  |  | — |  |  |  | 8,836 |  |  |  | — |  |
| U.S. government bonds |  |  | 14,509 |  |  |  | 14,509 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 1,231 |  |  |  | — |  |  |  | 1,231 |  |  |  | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 36,519 |  |  |  | 36,519 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 20,067 |  |  |  | 20,067 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 145,654 |  |  |  | 71,095 |  |  |  | 74,559 |  |  |  | — |  |
| Total |  | $ | 153,424 |  |  | $ | 77,865 |  |  | $ | 75,559 |  |  | $ | — |  |

- removed (2018-08-03):
[0001564590-18-012467:note_history:33]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2018 |  |
| Realized gains (losses) on equity securities sold |  | $ | (1 | ) |
| Unrealized gains (losses) on equity securities held |  |  | (23 | ) |
| Total gain (loss) recognized, net |  | $ | (24 | ) |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2018-08-03):
[0001564590-18-019154:note_history:34]
The following table disaggregates our revenue by major source for the three months ended June 30, 2018:
  (was, 2018-05-09, similarity 0.775):
[0001564590-18-012467:note_history:34]
The following table disaggregates our revenue by major source:

- added (2018-08-03):
[0001564590-18-019154:note_history:35]
The following table disaggregates our revenue by major source for the six months ended June 30, 2018:

- added (2018-08-03):
[0001564590-18-019154:note_history:36]
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 144,607 |  |  | $ | 21,815 |  |  | $ | 166,422 |  |
| Customer Devices |  |  | 62,083 |  |  |  | 2,578 |  |  |  | 64,661 |  |
| Traditional & Other Products |  |  | 13,626 |  |  |  | 4,145 |  |  |  | 17,771 |  |
| Total |  | $ | 220,316 |  |  | $ | 28,538 |  |  | $ | 248,854 |  |

- removed (2018-08-03):
[0001564590-18-012467:note_history:37]
During the three months ended March 31, 2018, we recognized $3.5 million of revenue that was included in unearned revenue at the beginning of the period.


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- added (2018-08-03):
[0001564590-18-019154:note_history:38]
Revenue is measured based on the consideration we expect to receive in exchange for transferring goods or providing services to a customer and as performance obligations under the terms of the contract are satisfied. Generally, this occurs with the transfer of control of a product or service to the customer. For transactions where there are multiple performance obligations, we account for individual products and services separately if they are distinct (if a product or service is separately identifiable from other items and if a customer can benefit from it on its own or with other resources that are readily available to the customer). The consideration, including any discounts, is allocated between separate products and services based on their stand-alone selling prices. The stand-alone selling prices are determined based on the prices at which we sell the separate products and services and are allocated based on each item’s relative value to the total value of the products and services in the arrangement. For items that are not sold separately, we estimate stand-alone selling prices primarily using the “expected cost plus a margin” approach. Payment terms are typically 30 days. Shipping fees are recorded as revenue and the related cost is included in cost of sales. Sales, value-added, and other taxes collected concurrently with revenue-producing activities are excluded from revenue. Costs of obtaining a contract are capitalized and amortized over the period that the related revenue is recognized if greater than one year. We have elected to apply the practical expedient related to the incremental costs of obtaining contracts and recognize those costs as an expense when incurred if the amortization period of the assets is one year or less. These costs are included in selling, general and administrative expenses. Capitalized costs with an amortization period greater than one year were immaterial.

- changed (2018-08-03):
[0001564590-18-019154:note_history:39]
The majority of the revenue from this segment is from hardware sales and is recognized when control is transferred to our customers, which is generally when we ship the products. Shipping terms are generally FOB shipping point. Revenue is recorded net of estimated discounts and rebates using the most likely amount. Customers are typically invoiced when control is transferred and revenue is recognized. Our products generally include assurance-based warranties of 90 days to five years for product defects, which are accrued at the time revenue is recognized.
  (was, 2018-05-09, similarity 0.991):
[0001564590-18-012467:note_history:39]
The majority of the revenue from this segment is from hardware sales and is recognized when control is transferred to our customers, which is generally when we ship the products. Shipping terms are generally FOB shipping point. Revenue is recorded net of discounts and rebates using the most likely amount. Customers are typically invoiced when control is transferred and revenue is recognized. Our products generally include assurance-based warranties of 90 days to five years for product defects, which are accrued at the time revenue is recognized.

- changed (2018-08-03):
[0001564590-18-019154:note_history:40]
In certain transactions, we are also the lessor in sales-type lease arrangements for network equipment that have terms of 18 months to five years. These arrangements typically include network equipment, network implementation services and maintenance services. Product revenue for these leases is generally recorded when we transfer control of the product to our customers. Revenue for network implementation and maintenance services is recognized as described below. Customers are typically invoiced and pay in equal installments over the lease term. In relation to these lease agreements, during the three months ended June 30, 2018 and 2017, we recognized revenue of $4.0 million and $5.2 million, respectively, and during the six months ended June 30, 2018 and 2017 we recognized revenue of $6.3 million and $7.0 million, respectively.
  (was, 2018-05-09, similarity 0.7985):
[0001564590-18-012467:note_history:40]
In certain transactions, we are also the lessor in sales-type lease arrangements for network equipment, which have terms of 18 months to five years. These arrangements typically include network equipment, network implementation services and maintenance services. Product revenue for these leases is generally recorded when we transfer control of the product to our customers. Revenue for network implementation and maintenance services is recognized as described below. Customers are typically invoiced and pay in equal installments over the lease term.

- changed (2018-08-03):
[0001564590-18-019154:note_history:41]
To complement our Network Solutions segment, we offer a complete portfolio of maintenance, network implementation, solutions integration and managed services, which include hosted cloud services and subscription services.
  (was, 2018-05-09, similarity 0.9977):
[0001564590-18-012467:note_history:41]
To complement our Network Solutions segment, we offer a complete portfolio of maintenance, network implementation, solutions integration and managed services, which include hosted, cloud services and subscription services.

- added (2018-08-03):
[0001564590-18-019154:note_history:42]
Our maintenance service periods range from one month to five years. Customers are typically invoiced and pay for maintenance services at the beginning of the maintenance period. Payments received are recorded in current or non-current unearned revenue depending on the length of the service period. We recognize revenue for maintenance services on a straight-line basis over the maintenance period in services revenue as our customers benefit evenly throughout the contract term.

- added (2018-08-03):
[0001564590-18-019154:note_history:43]
We recognize revenue for network implementation, which primarily consists of engineering, execution and enablement services, at a point in time when each performance obligation is complete. If we have recognized revenue, but have not billed the customer, the right to consideration is recognized as a contract asset that is included in other receivables in the Consolidated Balance Sheet. The contract asset is transferred to accounts receivable when the completed performance obligation is invoiced to the customer.

- changed (2018-08-03):
[0001564590-18-019154:note_history:44]
As of June 30, 2018, we did not have any remaining performance obligations related to customer contracts that had an original expected duration of one year or more, other than maintenance services, which are satisfied over time.
  (was, 2018-05-09, similarity 0.9798):
[0001564590-18-012467:note_history:44]
As of March 31, 2018, we did not have any remaining performance obligations related to customer contracts that had an original expected duration of one year or more, other than maintenance services, which are satisfied over time.

- changed (2018-08-03):
[0001564590-18-019154:note_history:45]
| (In thousands) |  | June 30, 2018 |  |  | January 1, 2018 |  |
| Accounts receivable |  | $ | 76,135 |  |  | $ | 144,150 |  |
| Contract assets |  |  | 1,672 |  |  |  | 374 |  |
| Unearned revenue |  |  | 14,307 |  |  |  | 13,070 |  |
| Non-current unearned revenue |  |  | 3,639 |  |  |  | 4,556 |  |
  (was, 2018-05-09, similarity 0.8974):
[0001564590-18-012467:note_history:45]
| (In thousands) |  | March 31, 2018 |  |  | December 31, 2017 |  |
| Accounts receivable |  | $ | 80,883 |  |  | $ | 144,150 |  |
| Contract assets |  |  | 1,442 |  |  |  | — |  |
| Unearned revenue |  |  | 13,948 |  |  |  | 13,070 |  |
| Non-current unearned revenue |  |  | 4,154 |  |  |  | 4,556 |  |

- added (2018-08-03):
[0001564590-18-019154:note_history:46]
The decrease in accounts receivable is due to the collection of customer specific payment terms that became due in the first quarter of 2018. The increase in the contract asset balance for the six months ended June 30, 2018 is primarily attributable to revenue recognized that has not yet been billed to the customer during the period. The increase in the unearned revenue balance as of June 30, 2018 is primarily attributable to cash payments received or due in advance of satisfying our performance obligations, offset by $7.1 million of revenues recognized that were included in the unearned revenue balance as of December 31, 2017.

- changed (2018-08-03):
[0001564590-18-019154:note_history:47]
The following table disaggregates our revenue by major source for the three months ended June 30, 2018:
  (was, 2018-05-09, similarity 0.775):
[0001564590-18-012467:note_history:47]
The following table disaggregates our revenue by major source:

- added (2018-08-03):
[0001564590-18-019154:note_history:48]
The following table disaggregates our revenue by major source for the six months ended June 30, 2018:

- added (2018-08-03):
[0001564590-18-019154:note_history:49]
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 144,607 |  |  | $ | 21,815 |  |  | $ | 166,422 |  |
| Customer Devices |  |  | 62,083 |  |  |  | 2,578 |  |  |  | 64,661 |  |
| Traditional & Other Products |  |  | 13,626 |  |  |  | 4,145 |  |  |  | 17,771 |  |
| Total |  | $ | 220,316 |  |  | $ | 28,538 |  |  | $ | 248,854 |  |

- removed (2018-08-03):
[0001564590-18-012467:note_history:50]
Revenue is measured based on the consideration we expect to receive in exchange for transferring goods or providing services to a customer and as performance obligations under the terms of the contract are satisfied. Generally, this occurs with the transfer of control of a product or service to the customer. For transactions where there are multiple performance obligations, we account for individual products and services separately if they are distinct (if a product or service is separately identifiable from other items and if a customer can benefit from it on its own or with other resources that are readily available to the customer). The consideration, including any discounts, is allocated between separate products and services based on their stand-alone selling prices using the most likely amount. The stand-alone selling prices are determined based on the prices at which we sell the separate products and services. For items that are not sold separately, we estimate stand-alone selling prices primarily using reasonable internal analysis. Shipping fees are recorded as revenue and the related cost is included in cost of sales. Sales, value added, and other taxes collected concurrent with revenue-producing activities are excluded from revenue. Costs of obtaining a contract are capitalized and amortized over the period that the related revenue is recognized. We have elected to apply the practical expedient related to the incremental costs of obtaining contracts and recognize those costs as expense when incurred if the amortization period of the assets is one year or less. These costs are included in selling, general and administrative expenses. Capitalized costs with an amortization period greater than one year were immaterial.

- removed (2018-08-03):
[0001564590-18-012467:note_history:51]
Our maintenance service periods range from one month to five years. Customers are typically invoiced and pay for maintenance services at the beginning of the maintenance period, which is recorded in current or non-current unearned revenue depending on the length of the service period. Maintenance services are provided on an as-needed basis and our customers benefit evenly throughout the contract term. Accordingly, we recognize revenue for maintenance services on a straight-line basis over the maintenance period in services revenue.

- removed (2018-08-03):
[0001564590-18-012467:note_history:52]
We recognize revenue for network implementation, which primarily consists of engineering, execution and enablement services, when performance obligations are complete at a point in time. If we have recognized revenue, but not billed the customer, the right to consideration is recognized as a contract asset, which is included in other receivables in the Consolidated Balance Sheet. The contract asset is transferred to accounts receivable when the right to consideration to payment becomes unconditional.

- removed (2018-08-03):
[0001564590-18-012467:note_history:53]
During the three months ended March 31, 2018, we recognized $3.5 million of revenue that was included in unearned revenue at the beginning of the period.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2018-08-03):
[0001564590-18-019154:note_history:54]
On July 17, 2018, we announced that our Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to stockholders of record at the close of business on August 1, 2018. The payment date will be August 15, 2018. The quarterly dividend payment will be approximately $4.3 million. In July 2003, our Board of Directors elected to begin declaring quarterly dividends on our common stock considering the tax treatment of dividends and adequate levels of Company liquidity.

- removed (2018-08-03):
[0001564590-18-012467:note_history:55]
On April 17, 2018, we announced that our Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to stockholders of record at the close of business on May 2, 2018. The payment date will be May 16, 2018. The quarterly dividend payment will be approximately $4.3 million. In July 2003, our Board of Directors elected to begin declaring quarterly dividends on our common stock considering the tax treatment of dividends and adequate levels of Company liquidity.
