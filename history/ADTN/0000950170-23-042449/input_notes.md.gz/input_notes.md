# ADTN notes — 0000950170-23-042449


## us-gaap:SignificantAccountingPoliciesTextBlock

[0000950170-23-042449:notes:1]
[same as prior period, unchanged from 0000950170-23-020333:notes:1]

[0000950170-23-042449:notes:2]
[same as prior period, unchanged from 0000950170-23-020333:notes:2]

[0000950170-23-042449:notes:3]
On May 24, 2023, at the annual general meeting of the shareholders of ADVA Optical Networking SE, a subsidiary of the Company ("ADVA"), the shareholders of ADVA approved the proposed change of its name to Adtran Networks SE ("Adtran Networks"), which was registered in the commercial register of the local court of Jena, Germany on June 8, 2023. Unless the context otherwise indicates or requires, references in this Quarterly Report on Form 10-Q to “Adtran Networks” refer to Adtran Networks SE (formerly ADVA Optical Networking SE).

[0000950170-23-042449:notes:4]
ADTRAN Holdings, Inc. solely owns ADTRAN, Inc. and is the majority shareholder of Adtran Networks. ADTRAN is a leading global provider of open, disaggregated networking and communications solutions. Adtran Networks is a global provider of network solutions for data, storage, voice and video services. The combined technology portfolio can best address current and future requirements, especially regarding the convergence of solutions at the network edge.

[0000950170-23-042449:notes:5]
[same as prior period, unchanged from 0000950170-23-020333:notes:4]

[0000950170-23-042449:notes:6]
The DPLTA between the Company, as the controlling company, and Adtran Networks SE, as the controlled company, as executed on December 1, 2022, became effective on January 16, 2023, as a result of its registration with the commercial register (Handelsregister) of the local court (Amtsgericht) at the registered seat of Adtran Networks (Jena).

[0000950170-23-042449:notes:7]
Under the DPLTA, subject to certain limitations pursuant to applicable law and the specific terms of the DPLTA, (i) the Company is entitled to issue binding instructions to the management board of Adtran Networks, (ii) Adtran Networks will transfer its annual profit to the Company, subject to, among other things, the creation or dissolution of certain reserves, and (iii) the Company will generally absorb the annual net loss incurred by Adtran Networks. The obligation of Adtran Networks to transfer its annual profit to the Company applies for the first time to the profit, if any, generated in the Adtran Networks fiscal year 2023. The obligation of the Company to absorb Adtran Networks annual net loss applies for the first time to the loss, if any, generated in the Adtran Networks fiscal year 2023.

[0000950170-23-042449:notes:8]
Pursuant to the terms of the DPLTA, each Adtran Networks shareholder (other than the Company) has received an offer to elect either (1) to remain an Adtran Networks shareholder and receive from us an Annual Recurring Compensation payment, or (2) to receive Exit Compensation plus guaranteed interest. The guaranteed interest under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid. The guaranteed interest rate is 5% plus a variable component that was 1.62% as of June 30, 2023. Assuming all the minority holders of currently outstanding Adtran Networks shares were to elect the second option, we would be obligated to make aggregate Exit Compensation payments, including guaranteed interest, of approximately €319.0 million or approximately $348.1 million, based on an exchange rate as of June 30, 2023 and reflecting interest accrued through June 30, 2023 at a rate of 5.0% in addition to the variable base interest rate according to the German Civil Code (currently 3.12%) during the pendency of the appraisal proceedings discussed below. Shareholders electing the first option of Annual Recurring Compensation may later elect the second option. The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that have been initiated in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger).

[0000950170-23-042449:notes:9]
We are also obligated to absorb any annual net loss of Adtran Networks under the DPLTA. Additionally, our obligation to pay Annual Recurring Compensation under the DPLTA is a continuing payment obligation, which will amount to approximately €10.6 million or $11.6 million (based on the current exchange rate) per year assuming none of the minority Adtran Networks shareholders were to elect Exit Compensation. The foregoing amounts do not reflect any potential increase in payment obligations that we may have depending on the outcome of ongoing appraisal proceedings in Germany. During the three and six months ended June 30, 2023, we accrued $2.9 million and $5.7 million in Annual Recurring Compensation, which was reflected as a reduction to retained (deficit) earnings, respectively. For the three and six months ended June 30, 2023, a total of approximately 46 thousand shares and 63 thousand shares, respectively, of Adtran Networks stock was tendered to the Company and Exit Compensation payments of approximately €0.8 million and €1.1 million, respectively, or approximately $0.9 million and $1.2 million, respectively, based on an exchange rate as of June 30, 2023, were paid to Adtran Networks shareholders.

[0000950170-23-042449:notes:10]
As of June 30, 2023, and as of the date of issuance of these financial statements, the Company does not have sufficient liquidity to meet payment obligations under the DPLTA pertaining to Exit Compensation assuming a substantial majority of Adtran Networks shareholders elect such option in the current period. We believe the probability that a substantial majority of Adtran Networks shareholders elect to receive Exit Compensation in the next twelve months is remote based on the diverse base of shareholders that must make this election on an individual shareholder basis, the current ongoing appraisal proceedings involving a dispute on the value of the Exit Compensation which is expected to take 24-36 months to resolve, the current guaranteed Annual Recurring Compensation payment plus the interest earned on such shares during the ongoing appraisal proceedings, and the current trading value of Adtran Networks SE shares.

[0000950170-23-042449:notes:11]
Therefore, we believe that our cash and cash equivalents, investments, working capital management initiatives and access to funds under the Wells Fargo credit facility, including additional funding provided for under the First Amendment to the Wells Fargo credit facility that was signed on August 9, 2023, (described below and as recently expanded) will be adequate to meet our operating and capital needs and our obligations under the DPLTA, including potential Exit Compensation, for at least the next 12 months, from the issuance of these financial statements, although we may need to suspend payment of dividends, reduce capital expenditures and/or take other steps to preserve working capital in order to ensure that we can meet such needs and obligations.

[0000950170-23-042449:notes:12]
On July 18, 2022, ADTRAN Holdings, Inc. and ADTRAN, Inc., as the borrower, entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (the “Credit Agreement”). The Credit Agreement allowed for borrowings of up to $100.0 million in aggregate principal amount, but the borrowings increased to up to $400.0 million in aggregate principal amount upon the DPLTA becoming effective on January 16, 2023. The Credit Agreement matures in July 2027, but provides the Company with an option to request extensions subject to customary conditions.

[0000950170-23-042449:notes:13]
On August 9, 2023, the Company, its wholly-owned direct subsidiary, ADTRAN, Inc., the lenders party thereto and Wells Fargo Bank, National Association, as administrative agent and as collateral agent, entered into a First Amendment to Credit Agreement (the “First Amendment”), which amended the Credit Agreement. See Note 22, Subsequent Events, for additional information.

[0000950170-23-042449:notes:14]
Board Approval Purchase of Adtran Networks Common Stock

[0000950170-23-042449:notes:15]
On October 18, 2022, the Company's Board of Directors authorized the Company to purchase additional shares of Adtran Networks through open market purchases not to exceed 15,346,544 shares. For the three and six months ended June 30, 2023, a total of approximately 46 thousand shares and 63 thousand shares, respectively, of Adtran Networks stock was tendered to the Company and Exit Compensation payments of approximately €0.8 million and €1.1 million, respectively, or approximately $0.9 million and $1.2 million, respectively, based on an exchange rate as of June 30, 2023 were paid to Adtran Networks' shareholders.

[0000950170-23-042449:notes:16]
[same as prior period, unchanged from 0000950170-23-020333:notes:12]

[0000950170-23-042449:notes:17]
[same as prior period, unchanged from 0000950170-23-020333:notes:13]

[0000950170-23-042449:notes:18]
[same as prior period, unchanged from 0000950170-23-020333:notes:14]

[0000950170-23-042449:notes:19]
In the opinion of management, all adjustments necessary to fairly state these interim statements have been recorded and are of a normal and recurring nature. The results of operations for an interim period are not necessarily indicative of the results for the full year. The interim financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in Amendment No. 1 to the ADTRAN Holdings, Inc. Annual Report on Form 10-K for the year ended December 31, 2022, filed with the SEC on August 14, 2023.

[0000950170-23-042449:notes:20]
[same as prior period, unchanged from 0000950170-23-020333:notes:16]

[0000950170-23-042449:notes:21]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenue and expense during the reporting period. Significant estimates include allowance for credit losses on accounts receivable and contract assets, excess and obsolete inventory reserves, warranty reserves, customer rebates, determination and accrual of the deferred revenue related to performance obligations under contracts with customers, estimated costs to complete obligations associated with deferred and accrued revenues and network installations, estimated income tax provision and income tax contingencies, fair value of stock-based compensation, assessment of goodwill and other intangibles for impairment, estimated lives of intangible assets, estimates of intangible assets upon measurement, estimated pension liability and fair value of investments and estimated contingent liabilities. Actual amounts could differ significantly from these estimates.

[0000950170-23-042449:notes:22]
We assessed certain accounting matters that generally require consideration of forecasted financial information in context with the information reasonably available to us and the unknown future impacts of supply chain constraints, inflationary pressures, the energy crisis, currency fluctuations and political tensions as of June 30, 2023, and through the date of this report. The accounting matters assessed included, but were not limited to, the allowance for credit losses, stock-based compensation, carrying value of goodwill, intangibles and other long-lived assets, financial assets, valuation allowances for tax assets, revenue recognition and costs of revenue. Future conditions related to supply chain constraints, inflationary pressures, the energy crisis, rising interest rates, instability in the financial services industry, currency fluctuations and political tensions could result in further impacts to the Company's consolidated financial statements in future reporting periods.

[0000950170-23-042449:notes:23]
[same as prior period, unchanged from 0000950170-23-020333:notes:23]

[0000950170-23-042449:notes:24]
As of June 30, 2023 and December 31, 2022, the Adtran Networks stockholders’ equity ownership percentage in Adtran Networks was approximately 34.6% and 34.7%, respectively.

[0000950170-23-042449:notes:25]
As a result of the effectiveness of the DPLTA on January 16, 2023, the Adtran Networks shares, representing the equity interest in Adtran Networks held by holders other than the Company, can be tendered at any time and are, therefore, redeemable and must be classified outside stockholders’ equity. Therefore, the permanent equity noncontrolling interest balance was reclassified to redeemable non-controlling interest on January 16, 2023 and was remeasured to fair value based on the trading market price of the Adtran Networks shares.

[0000950170-23-042449:notes:26]
Subsequently, the carrying value of the RNCI is adjusted to its maximum redemption value at each reporting date when the maximum redemption value is greater than the initial carrying amount of the RNCI. However, the RNCI will be remeasured using the current exchange rate at each reporting date as long as the RNCI is currently redeemable. For the period of time that the DPLTA is in effect, the RNCI will continue to be presented as RNCI outside of stockholders’ equity in the Condensed Consolidated Balance Sheets.

[0000950170-23-042449:notes:27]
[same as prior period, unchanged from 0000950170-23-020333:notes:27]

[0000950170-23-042449:notes:28]
Recently Adopted Accounting Pronouncements

[0000950170-23-042449:notes:29]
In October 2021, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update ("ASU") 2021-08, Business Combinations (Topic 805) Accounting for Contract Assets and Contract Liabilities from Contracts with Customers, which would require an acquirer to recognize and measure acquired contract assets and contract liabilities in a manner consistent with how the acquiree recognized and measured them in its pre-acquisition financial statements in accordance with Topic 606, Revenue Recognition. The Company early adopted ASU 2021-08 on July 1, 2022 and the standard was applied retrospectively beginning with January 1, 2022.

[0000950170-23-042449:notes:30]
[same as prior period, unchanged from 0000950170-23-020333:notes:30]

[0000950170-23-042449:notes:31]
[same as prior period, unchanged from 0000950170-23-020333:notes:31]


## us-gaap:BusinessCombinationDisclosureTextBlock

[0000950170-23-042449:notes:32]
[same as prior period, unchanged from 0000950170-23-020333:notes:32]

[0000950170-23-042449:notes:33]
Adtran Networks SE (formerly ADVA Optical Networking SE)

[0000950170-23-042449:notes:34]
On August 30, 2021, ADTRAN, Inc. and Adtran Networks (then known as ADVA Optical Networking SE) entered into a Business Combination Agreement, pursuant to which both companies agreed to combine their respective businesses and each become subsidiaries of a new holding company, ADTRAN Holdings, Inc. (formerly known as Acorn HoldCo, Inc.), which was formed as a wholly-owned subsidiary of ADTRAN, Inc. in order to consummate the transactions under the Business Combination Agreement. Under the terms of the Business Combination Agreement, on July 8, 2022, Acorn MergeCo, Inc, a Delaware corporation and wholly-owned direct subsidiary of the Company, merged with and into ADTRAN, Inc., with ADTRAN, Inc. surviving the Business Combination as a wholly-owned direct subsidiary of the Company.

[0000950170-23-042449:notes:35]
Additionally, pursuant to the Business Combination Agreement, on July 15, 2022, the Company made a public offer to exchange each issued and outstanding no-par value bearer share of Adtran Networks for 0.8244 shares of Company Common Stock, par value $0.01 per share of the Company. The Exchange Offer was settled on July 15, 2022 (the "Exchange Offer Settlement Date"), on which date the Company acquired 33,957,538 bearer shares of Adtran Networks, or 65.43% of Adtran Networks’ outstanding bearer shares as of the Exchange Offer Settlement Date, in exchange for the issuance of an aggregate of 27,994,595 shares of Company Common Stock. Additionally, pursuant to the Business Combination Agreement, Adtran Networks stock option holders were entitled to have their Adtran Networks stock options assumed by ADTRAN Holdings, Inc. (applying the exchange ratio in the Business Combination Agreement), thereafter representing options to acquire stock of ADTRAN, Holdings, Inc. The fair value of the Adtran Networks stock options assumed by ADTRAN Holdings, Inc. was $12.8 million, estimated using the Monte Carlo method.

[0000950170-23-042449:notes:36]
ADTRAN, Inc. and Adtran Networks became subsidiaries of ADTRAN Holdings, Inc. as a result of the Business Combination. ADTRAN, Inc. was determined to be the accounting acquirer of Adtran Networks based on ADTRAN, Inc. shareholders’ majority equity stake in the combined company, the composition of the board of directors and senior management of the combined company, among other factors. The Business Combination with Adtran Networks has been accounted for using the acquisition method of accounting as per the provisions of Accounting Standards Codification 805, “Business Combinations” (“ASC 805”). The Business Combination Agreement used a fixed exchange ratio of Company Common Stock for Adtran Networks shares of common stock, which resulted in a 36% equity stake for Adtran Networks stockholders and a 64% equity stake for ADTRAN, Inc. stockholders in the post-closing combined company (calculated on a fully diluted basis and utilizing the tender of 65.43% of Adtran Networks’ current issued and outstanding share capital) as of July 15, 2022. Therefore, ADTRAN, Inc. shareholders continued to hold a majority interest in the combined company following the completion of the Business Combination. Additionally, the Board of Directors is comprised of six members from ADTRAN, Inc. and three members from Adtran Networks; the current ADTRAN, Inc. chief executive officer acts as the chairman of the Board of Directors and the former Adtran Networks chief executive officer as the vice chairman of the Board of Directors. Additionally, the current ADTRAN, Inc. chief executive officer and ADTRAN, Inc. chief financial officer held these positions within the combined company immediately following the completion of the Business Combination. Based upon these and other considerations as outlined in ASC 805, ADTRAN, Inc. represents the accounting acquirer.

[0000950170-23-042449:notes:37]
The following table summarizes the purchase price for the Adtran Networks business combination:

[0000950170-23-042449:notes:38]
| (In thousands, except shares, share price and exchange ratio) |  | Purchase Price |  |
| Adtran Networks shares exchanged |  |  | 33,957,538 |  |
| Exchange ratio |  |  | 0.8244 |  |
| ADTRAN Holdings, Inc. shares issued |  |  | 27,994,595 |  |
| ADTRAN Holdings, Inc. share price on July 15, 2022 |  | $ | 20.20 |  |
| Purchase price paid for Adtran Networks shares |  | $ | 565,491 |  |
| Equity compensation (1) |  | $ | 12,769 |  |
| Total purchase price |  | $ | 578,260 |  |

[0000950170-23-042449:notes:39]
[same as prior period, unchanged from 0000950170-23-020333:notes:39]

[0000950170-23-042449:notes:40]
[same as prior period, unchanged from 0000950170-23-020333:notes:40]

[0000950170-23-042449:notes:41]
[same as prior period, unchanged from 0000950170-23-020333:notes:41]

[0000950170-23-042449:notes:42]
[same as prior period, unchanged from 0000950170-23-020333:notes:42]

[0000950170-23-042449:notes:43]
The following table summarizes the purchase price allocation for each major class of assets acquired and liabilities assumed in the Business Combination (in thousands):

[0000950170-23-042449:notes:44]
[same as prior period, unchanged from 0000950170-23-020333:notes:44]

[0000950170-23-042449:notes:45]
[same as prior period, unchanged from 0000950170-23-020333:notes:45]

[0000950170-23-042449:notes:46]
[same as prior period, unchanged from 0000950170-23-020333:notes:46]

[0000950170-23-042449:notes:47]
[same as prior period, unchanged from 0000950170-23-020333:notes:47]

[0000950170-23-042449:notes:48]
[same as prior period, unchanged from 0000950170-23-020333:notes:48]

[0000950170-23-042449:notes:49]
Goodwill represents the excess of the purchase price over the fair value of the net tangible and intangible assets acquired. The Business Combination resulted in the recognition of goodwill of $350.5 million, which the Company believes is attributable to the value driven by the Company’s expected growth of the business, synergies, and expanded market and product opportunities. Goodwill created as a result of the Business Combination is not deductible for tax purposes.

[0000950170-23-042449:notes:50]
[same as prior period, unchanged from 0000950170-23-020333:notes:50]

[0000950170-23-042449:notes:51]
As of the acquisition date, the fair value of the non-controlling interest was approximately $316.4 million and determined using a market approach. As a portion of Adtran Networks' shares remains trading after the Business Combination, the non-controlling interest was calculated using 17,941,496 Adtran Networks shares held by non-controlling interest multiplied by the Adtran Networks closing share price of €17.58 ($17.64 using the July 15, 2022 EUR to USD conversion rate of $1.00318) on July 15, 2022.

[0000950170-23-042449:notes:52]
The Company has included the financial results of Adtran Networks in its consolidated financial statements since July 15, 2022, the acquisition date. The net revenue from the Adtran Networks business for the three and six months ended June 30, 2023, was $186.7 million and $379.0 million, respectively, and the net loss from the Adtran Networks business for the three and six months ended June 30, 2023, was $31.7 million and $67.5 million, respectively, which are included in the Company’s Consolidated Statement of (Loss) Income. There was no net loss attributable to non-controlling interest from the Adtran Networks business for the three months ended June 30, 2023. The net loss attributable to non-controlling interest from the Adtran Networks business for the six months ended June 30, 2023 was $6.0 million.

[0000950170-23-042449:notes:53]
As of June 30, 2023, the Company has incurred $26.2 million of transaction costs related to the Business Combination. During the three and six months ended June 30, 2023, $0.1 million of transaction costs were incurred. During the three and six months ended June 30, 2022, $1.2 million and $2.7 million of transaction costs were incurred, respectively. These transaction costs are recorded in selling, general and administrative expenses in the Consolidated Statements of (Loss) Income.

[0000950170-23-042449:notes:54]
[same as prior period, unchanged from 0000950170-23-020333:notes:54]

[0000950170-23-042449:notes:55]
The unaudited pro forma financial information in the table below summarizes the combined results of operations for ADTRAN, Inc. and Adtran Networks as though the Business Combination had occurred on January 1, 2022. The pro forma amounts have been adjusted for differences in basis of accounting which are determined before taking into effect the impacts of purchase accounting and Business Combination accounting impacts.

[0000950170-23-042449:notes:56]
The following unaudited pro forma information is presented for illustrative purposes only. It is not necessarily indicative of the results of operations of future periods, the results of operations that actually would have been realized had the entities been a single company as of January 1, 2022, or the future operating results of the combined entities. The unaudited pro forma information does not give effect to the potential impact of current financial conditions, regulatory matters or any anticipated synergies, operating efficiencies or cost savings that may be associated with the acquisition. The unaudited pro forma information also does not include any integration costs that the Company has incurred and may continue to incur related to the Business Combination as part of combining the operations of the companies.

[0000950170-23-042449:notes:57]
|  | Three Months Ended |  |  | Six Months Ended |  |
| (In thousands) | June 30, 2022 |  |  | June 30, 2022 |  |
| Revenue | $ | 339,474 |  |  | $ | 685,318 |  |
| Net income (loss) | $ | 61,079 |  |  | $ | (12,410 | ) |


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0000950170-23-042449:notes:58]
[same as prior period, unchanged from 0000950170-23-020333:notes:58]

[0000950170-23-042449:notes:59]
[same as prior period, unchanged from 0000950170-23-020333:notes:59]

[0000950170-23-042449:notes:60]
Network Solutions Segment - Includes hardware and software products that enable a digital future which support the Company's Subscriber, Access & Aggregation, and Optical Networking Solutions.

[0000950170-23-042449:notes:61]
Services & Support Segment - Includes network design, implementation, maintenance and cloud-hosted services supporting the Company's Subscriber, Access & Aggregation, and Optical Networking Solutions.

[0000950170-23-042449:notes:62]
[same as prior period, unchanged from 0000950170-23-020333:notes:62]

[0000950170-23-042449:notes:63]
[same as prior period, unchanged from 0000950170-23-020333:notes:63]

[0000950170-23-042449:notes:64]
Prior to the Business Combination with Adtran Networks on July 15, 2022, ADTRAN reported revenue across the following three categories: (1) Access & Aggregation, (2) Subscriber Solutions & Experience and (3) Traditional & Other Products. Following the Business Combination with Adtran Networks, we have recast these revenues such that ADTRAN’s former Access & Aggregation revenue is combined with a portion of the applicable Adtran Networks solutions to create Access & Aggregation Solutions, ADTRAN’s former Subscriber Solutions & Experience revenue is combined with a portion of the applicable Adtran Networks solutions to create Subscriber Solutions, and the revenue from Traditional & Other products is now included in the applicable Access & Aggregation Solutions or Subscriber Solutions category. Optical Networking Solutions is a new revenue category added to represent a meaningful portion of Adtran Networks' portfolio.

[0000950170-23-042449:notes:65]
[same as prior period, unchanged from 0000950170-23-020333:notes:65]

[0000950170-23-042449:notes:66]
[same as prior period, unchanged from 0000950170-23-020333:notes:66]

[0000950170-23-042449:notes:67]
[same as prior period, unchanged from 0000950170-23-020333:notes:67]

[0000950170-23-042449:notes:68]
The following tables disaggregate revenue by reportable segment and revenue category. Prior year amounts presented below have been reclassified to conform to the current period revenue category presentation:

[0000950170-23-042449:notes:69]
|  |  | Three Months Ended |  |
|  |  | June 30, 2023 |  |  | June 30, 2022 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Optical Networking Solutions |  | $ | 120,221 |  |  | $ | 22,775 |  |  | $ | 142,996 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Access & Aggregation Solutions |  |  | 89,263 |  |  |  | 13,454 |  |  |  | 102,717 |  |  |  | 80,821 |  |  |  | 11,467 |  |  |  | 92,288 |  |
| Subscriber Solutions |  |  | 73,518 |  |  |  | 8,147 |  |  |  | 81,665 |  |  |  | 75,171 |  |  |  | 4,579 |  |  |  | 79,750 |  |
| Total |  | $ | 283,002 |  |  | $ | 44,376 |  |  | $ | 327,378 |  |  | $ | 155,992 |  |  | $ | 16,046 |  |  | $ | 172,038 |  |

[0000950170-23-042449:notes:70]
|  |  | Six Months Ended |  |
|  |  | June 30, 2023 |  |  | June 30, 2022 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Optical Networking Solutions |  | $ | 247,798 |  |  | $ | 42,954 |  |  | $ | 290,752 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Access & Aggregation Solutions |  |  | 173,817 |  |  |  | 25,720 |  |  |  | 199,537 |  |  |  | 166,805 |  |  |  | 23,279 |  |  |  | 190,084 |  |
| Subscriber Solutions |  |  | 143,805 |  |  |  | 17,196 |  |  |  | 161,001 |  |  |  | 127,561 |  |  |  | 8,911 |  |  |  | 136,472 |  |
| Total |  | $ | 565,420 |  |  | $ | 85,870 |  |  | $ | 651,290 |  |  | $ | 294,366 |  |  | $ | 32,190 |  |  | $ | 326,556 |  |

[0000950170-23-042449:notes:71]
The aggregate amount of transaction price allocated to remaining performance obligations that have not been satisfied as of June 30, 2023 and December 31, 2022 related to contractual maintenance agreements, contractual SaaS and subscription services, and hardware contracts that exceed one year in duration amounted to $369.3 million and $277.2 million, respectively. As of June 30, 2023, approximately 46.5% is expected to be recognized over the next 12 months and the remainder recognized thereafter. The majority of the Company's remaining performance obligations as of June 30, 2023 are related to contracts or orders that have an original expected duration of one year or less, for which the Company is electing to utilize the practical expedient available within the guidance, and are excluded from the transaction price related to these future obligations. The Company will generally satisfy the remaining performance obligations as we transfer control of the products ordered or services to our customers, excluding maintenance services, which are satisfied over time.

[0000950170-23-042449:notes:72]
[same as prior period, unchanged from 0000950170-23-020333:notes:71]

[0000950170-23-042449:notes:73]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | June 30, 2023 |  |  | December 31, 2022 |  |
| Accounts receivable, net |  | $ | 239,565 |  |  | $ | 279,435 |  |
| Contract assets(1) |  | $ | 1,153 |  |  | $ | 1,852 |  |
| Unearned revenue |  | $ | 48,030 |  |  | $ | 41,193 |  |
| Non-current unearned revenue |  | $ | 24,111 |  |  | $ | 19,239 |  |

[0000950170-23-042449:notes:74]
[same as prior period, unchanged from 0000950170-23-020333:notes:73]

[0000950170-23-042449:notes:75]
The Company is party to a receivables purchase agreement with a third-party financial institution (the “Factor”), which accelerates receivable collection and helps to better manage cash flow. Total accounts receivables sold for the six months ended June 30, 2023 and the twelve months ended December 31, 2022, totaled $14.7 million and $14.9 million, respectively, of which $1.2 million was retained by the Factor in the reserve account. The balance in the reserve account is included in other assets on the Condensed Consolidated Balance Sheets. As of June 30, 2023 and December 31, 2022, the Company had an allowance for credit losses related to factored accounts receivable totaling less than $0.1 million. The cost of the receivables purchase agreement is included in interest expense in the Condensed Consolidated Statements of (Loss) Income and totaled $0.3 million and $0.6 million for the three and six months ended June 30, 2023, respectively.

[0000950170-23-042449:notes:76]
Of the outstanding unearned revenue balances as of December 31, 2022, $24.8 million and $50.5 million was recognized as revenue during the three and six months ended June 30, 2023, respectively. Of the $17.7 million of outstanding unearned revenue balances as of December 31, 2021, $4.1 million and $9.5 million was recognized as revenue during the three and six months ended June 30, 2022, respectively.

[0000950170-23-042449:notes:77]
[same as prior period, unchanged from 0000950170-23-020333:notes:76]

[0000950170-23-042449:notes:78]
[same as prior period, unchanged from 0000950170-23-020333:notes:77]

[0000950170-23-042449:notes:79]
As of June 30, 2023 and December 31, 2022, the Company’s outstanding accounts receivable balance was $239.6 million and $279.4 million, respectively. The Company assessed the need for an allowance for credit losses related to its outstanding accounts receivable using the historical loss-rate method as well as assessing asset-specific risks. The assessment of asset-specific risks included the evaluation of relevant available information, from internal and external sources, relating to current conditions that may affect a customer’s ability to pay, such as the customer’s current financial condition, credit rating by geographic location, as provided by a third party and/or by customer, if needed, and the overall macro-economic conditions in which the customer operates. The Company pooled assets by geographic location to determine if an allowance should be applied to its accounts receivable balance, assessing the specific country risk rating and overall economics of that particular country. If elevated risk existed, or customer specific risk indicated the accounts receivable balance was at risk, the Company further analyzed the need for an allowance related to specific accounts receivable balances. Additionally, the Company determined that significant changes to customer country risk rating from period-to-period and from the end of the prior year to the end of the current quarter would require further review and analysis by the Company.

[0000950170-23-042449:notes:80]
The allowance for credit losses was $26 thousand and $49 thousand as of June 30, 2023 and December 31, 2022, respectively, related to accounts receivable.

[0000950170-23-042449:notes:81]
[same as prior period, unchanged from 0000950170-23-020333:notes:80]

[0000950170-23-042449:notes:82]
The Company records contract assets when it has recognized revenue but has not yet billed the customer. As of June 30, 2023 and December 31, 2022, the Company’s outstanding contract asset balance was $1.2 million and $1.9 million, respectively, which is included in other receivables on the Consolidated Balance Sheets. The Company assessed the need for an allowance for credit losses related to its outstanding contract assets using the historical loss-rate method as well as asset-specific risks. The Company’s historical losses related to contract assets receivable have been immaterial as evidenced by historical write-offs due to collectability. Asset-specific risk included the evaluation of relevant available information, from internal and external sources, relating to current conditions that may affect a customer’s ability to pay once invoiced, such as the customer’s financial condition, credit rating by geographic location as provided by a third party and/or by customer, if needed, and the overall macro-economic conditions in which the customer operates. The Company pooled assets by geographic location to determine if an allowance should be applied to its contract asset balance, assessing the specific country risk rating and the overall economics of that particular country. If elevated risk existed, or customer specific risk indicated the contract balance was at risk, the Company further analyzed the need for an allowance related to specific customer balances. Additionally, the Company determined that significant changes to customer country risk rating from period-to-period and from the end of the prior year to the end of the current quarter would be subject to further review and analysis by the Company.

[0000950170-23-042449:notes:83]
No allowance for credit losses was recorded for the three months ended June 30, 2023 and 2022 related to contract assets.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0000950170-23-042449:notes:84]
[same as prior period, unchanged from 0000950170-23-020333:notes:83]

[0000950170-23-042449:notes:85]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Optical Networking Solutions |  | $ | 142,996 |  |  | $ | — |  |  | $ | 290,752 |  |  | $ | — |  |
| Access & Aggregation Solutions |  |  | 102,717 |  |  |  | 92,288 |  |  |  | 199,537 |  |  |  | 190,084 |  |
| Subscriber Solutions |  |  | 81,665 |  |  |  | 79,750 |  |  |  | 161,001 |  |  |  | 136,472 |  |
| Total |  | $ | 327,378 |  |  | $ | 172,038 |  |  | $ | 651,290 |  |  | $ | 326,556 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0000950170-23-042449:notes:86]
[same as prior period, unchanged from 0000950170-23-020333:notes:85]

[0000950170-23-042449:notes:87]
The Company's effective tax rate changed from an expense of 50.1% of pre-tax income for the three months ended June 30, 2022, to a benefit of 18.8% of pre-tax loss for the three months ended June 30, 2023 and changed from a benefit of 34.3% of pre-tax income for the six months ended June 30, 2022, to a benefit of 20.4% of pre-tax loss for the six months ended June 30, 2023. The change in the effective tax rate for the three and six months ended June 30, 2023, was driven primarily by a change in our estimated tax rate as a result of the closing of the Business Combination with Adtran Networks during the third quarter of 2022, as well as the release of our domestic valuation allowance during the fourth quarter of 2022.

[0000950170-23-042449:notes:88]
During the second quarter of 2023, the Company concluded a review with the Internal Revenue Services of its amended tax returns previously filed related to refund claims arising from the Company’s request to revoke an IRC Section 59(e) election made on the Company’s originally filed 2018 U.S. federal tax return, and received an unfavorable response, Private Letter Ruling request. As a result of that review, and after taking into consideration other factors, including weighing the potential benefits with projected costs to litigate and the hazards of litigation, management has concluded that it will not pursue the claims any further. As a result, the company has removed the previously recorded receivable of $15.2 million and related research and development credit carryforward of $1.8 million as well as the offsetting uncertain tax position reserves against them of $17.0 million within our financials as of June 30, 2023.

[0000950170-23-042449:notes:89]
The Company continually reviews the adequacy of its valuation allowance and recognizes the benefits of deferred tax assets only as the assessment indicates that it is more likely than not that the deferred tax assets will be recognized in accordance with ASC 740, Income Taxes. As of June 30, 2023, the Company had net deferred tax assets totaling $42.5 million, and a valuation allowance totaling $5.0 million against those deferred tax assets. The remaining $37.5 million in deferred tax assets are primarily related to capitalized R&D expenses in the U.S., partially offset by net purchase price intangibles from the Business Combination closed with Adtran Networks during the third quarter of 2022. Our assessment of the realizability of our deferred tax assets includes the evaluation of historical operating results as well as the evaluation of evidence which requires significant judgment, including the evaluation of our three-year cumulative income position, future taxable income projections and tax planning strategies. Should management’s conclusion change in the future and an additional valuation allowance, or a partial or full release of the valuation allowance becomes necessary, it may have a material effect on our consolidated financial statements.

[0000950170-23-042449:notes:90]
[same as prior period, unchanged from 0000950170-23-020333:notes:88]

[0000950170-23-042449:notes:91]
|  |  | As of June 30, 2023 |  |
| (In thousands) |  | Deferred Tax Assets (Liabilities) |  |  | Valuation Allowance |  |  | Deferred Tax Assets (Liabilities), net |  |
| Domestic |  | $ | 75,809 |  |  | $ | (3,177 | ) |  | $ | 72,632 |  |
| International |  |  | (33,331 | ) |  |  | (1,839 | ) |  |  | (35,170 | ) |
| Total |  | $ | 42,478 |  |  | $ | (5,016 | ) |  | $ | 37,462 |  |

[0000950170-23-042449:notes:92]
[same as prior period, unchanged from 0000950170-23-020333:notes:90]


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0000950170-23-042449:notes:93]
[same as prior period, unchanged from 0000950170-23-020333:notes:91]

[0000950170-23-042449:notes:94]
For the three months ended June 30, 2023 and 2022, stock-based compensation expense was $4.3 million and $1.9 million, respectively, and for the six months ended June 30, 2023 and 2022, stock-based compensation expense was $8.0 million and $3.8 million, respectively.

[0000950170-23-042449:notes:95]
[same as prior period, unchanged from 0000950170-23-020333:notes:93]

[0000950170-23-042449:notes:96]
The following table summarizes the RSUs and restricted stock outstanding as of December 31, 2022 and June 30, 2023 and the changes that occurred during the six months ended June 30, 2023:

[0000950170-23-042449:notes:97]
|  |  | Number of Shares(in thousands) |  |  | Weighted Avg. Grant Date Fair Value(per share) |  |
| Unvested RSUs and restricted stock outstanding, December 31, 2022 |  |  | 1,086 |  |  | $ | 17.54 |  |
| RSUs and restricted stock granted |  |  | 1,484 |  |  | $ | 16.33 |  |
| RSUs and restricted stock vested |  |  | (52 | ) |  | $ | 20.36 |  |
| RSUs and restricted stock forfeited |  |  | (27 | ) |  | $ | 16.11 |  |
| Unvested RSUs and restricted stock outstanding, June 30, 2023 |  |  | 2,491 |  |  | $ | 17.02 |  |

[0000950170-23-042449:notes:98]
During the six months ended June 30, 2023, the Company granted 0.9 million performance-based PSUs to its executive officers and certain employees. The grant-date fair value of these performance-based awards was based on the closing price of the Company’s stock on the date of grant. These awards vest over either a two or three-year period, subject to the grantee’s continued employment, with the ability to earn shares in a range of 0% to either 100% or 150% of the awarded number of PSUs based on the achievement of defined performance targets. Equity-based compensation expense with respect to these awards may be adjusted over the vesting period to reflect the probability of achievement of performance targets defined in the award agreements.

[0000950170-23-042449:notes:99]
[same as prior period, unchanged from 0000950170-23-020333:notes:98]

[0000950170-23-042449:notes:100]
As of June 30, 2023, total unrecognized compensation expense related to non-vested market-based RSUs and restricted stock was approximately $21.8 million, which will be recognized over the remaining weighted-average period of 2.4 years. There was $13.9 million of unrecognized compensation expense related to unvested 2023 performance-based PSUs, which will be recognized over the remaining requisite service period of 2.4 years if achievement of the performance obligation becomes probable. Unrecognized compensation expense will be adjusted for actual forfeitures.

[0000950170-23-042449:notes:101]
As of June 30, 2023, 2.0 million shares were available for issuance under stockholder-approved equity plans.

[0000950170-23-042449:notes:102]
[same as prior period, unchanged from 0000950170-23-020333:notes:101]

[0000950170-23-042449:notes:103]
The following table summarizes the ADTRAN Holdings, Inc. stock options outstanding as of December 31, 2022 and June 30, 2023 and the changes that occurred during the six months ended June 30, 2023:

[0000950170-23-042449:notes:104]
|  |  | Number of Stock Options(in thousands) |  |  | Weighted Avg. Exercise Price(per share) |  |  | Weighted Avg. Remaining Contractual Life(in years) |  |  | Aggregate Intrinsic Value(in thousands) |  |
| Stock options outstanding, December 31, 2022 |  |  | 3,148 |  |  | $ | 14.37 |  |  |  | 3.42 |  |  | $ | 16,251 |  |
| Stock options granted |  |  | 8 |  |  | $ | 12.17 |  |  |  |  |  |  |  |
| Stock options exercised |  |  | (6 | ) |  | $ | 9.82 |  |  |  |  |  |  |  |
| Stock options forfeited |  |  | (36 | ) |  | $ | 12.24 |  |  |  |  |  |  |  |
| Stock options expired |  |  | (26 | ) |  | $ | 15.46 |  |  |  |  |  |  |  |
| Stock options outstanding, June 30, 2023 |  |  | 3,088 |  |  | $ | 14.39 |  |  |  | 2.93 |  |  | $ | 2,582 |  |
| Stock options exercisable, June 30, 2023 |  |  | 1,701 |  |  | $ | 15.89 |  |  |  | 1.48 |  |  | $ | 1,514 |  |

[0000950170-23-042449:notes:105]
As of June 30, 2023, there was $6.3 million of unrecognized compensation expense related to stock options which will be recognized over the remaining weighted-average period of 2.0 years.

[0000950170-23-042449:notes:106]
Pursuant to the Business Combination, which closed on July 15, 2022, Adtran Networks stock option holders were entitled to have their Adtran Networks stock options assumed by ADTRAN Holdings, Inc. (applying the exchange ratio in the Business Combination Agreement), thereafter representing options to acquire stock of ADTRAN Holdings, Inc. The maximum number of shares of ADTRAN Holdings, Inc. stock potentially issuable upon such assumption was 2.3 million shares. The period in which such options could be assumed ended July 22, 2022. A total of 2.1 million shares of ADTRAN Holdings, Inc. stock could be issued pursuant to the exercise of the assumed Adtran Networks options. The determination of the fair value of stock options assumed by ADTRAN Holdings, Inc. was estimated using the Monte Carlo method and is affected by its stock price, as well as assumptions regarding a number of complex and subjective variables that may have a significant impact on the fair value estimate. The stock option pricing model requires the use of several assumptions that impact the fair value estimate. These variables include, but are not limited to, the volatility of the Company's stock price and employee exercise behaviors.

[0000950170-23-042449:notes:107]
[same as prior period, unchanged from 0000950170-23-020333:notes:107]

[0000950170-23-042449:notes:108]
The aggregate intrinsic value of stock options represents the total pre-tax intrinsic value (the difference between the Company's closing stock price on the last trading day of the quarter and the exercise price, multiplied by the number of in-the-money options) that would have been received by the option holders had all option holders exercised their options on June 30, 2023. The amount of aggregate intrinsic value was $2.6 million as of June 30, 2023 and will change based on the fair market value of the Company's stock. The total pre-tax intrinsic value of options exercised during the six months ended June 30, 2023 was $43 thousand.

[0000950170-23-042449:notes:109]
Stock Options - Adtran Networks

[0000950170-23-042449:notes:110]
The following table summarizes the Adtran Networks stock options outstanding as of December 31, 2022 and June 30, 2023 and the changes that occurred during the six months ended June 30, 2023:

[0000950170-23-042449:notes:111]
|  |  | Number ofOptions(In thousands) |  |  | WeightedAverageExercise Price(Per share) |  |  | Weighted Avg.RemainingContractual Lifein Years |  |  | AggregateIntrinsic Value(In thousands) |  |
| Stock options outstanding, December 31, 2022 |  |  | 81 |  |  | $ | 8.58 |  |  |  | 4.00 |  |  | $ | 1,222 |  |
| Stock options exercised |  |  | (12 | ) |  | $ | 8.47 |  |  |  |  |  |  |  |
| Stock options expired |  |  | (1 | ) |  | $ | 9.49 |  |  |  |  |  |  |  |
| Stock options outstanding, June 30, 2023 |  |  | 68 |  |  | $ | 8.77 |  |  |  | 3.88 |  |  | $ | 865 |  |
| Stock options exercisable, June 30, 2023 |  |  | 13 |  |  | $ | 6.41 |  |  |  | 1.39 |  |  | $ | 197 |  |

[0000950170-23-042449:notes:112]
As of June 30, 2023, there was $0.1 million of unrecognized compensation expense related to Adtran Networks stock options which will be recognized over the remaining weighted-average period of 3.9 years.

[0000950170-23-042449:notes:113]
All of the Adtran Networks options were previously issued at exercise prices that approximated fair market value at the date of grant.

[0000950170-23-042449:notes:114]
The aggregate intrinsic value of Adtran Networks stock options represents the total pre-tax intrinsic value (the difference between Adtran Networks closing stock price on the last trading day of the quarter and the exercise price, multiplied by the number of in-the-money options) that would have been received by the option holders had all option holders exercised their options on June 30, 2023. The amount of aggregate intrinsic value was $0.9 million as of June 30, 2023 and will change based on the fair market value of Adtran Networks stock. The total pre-tax intrinsic value of Adtran Networks options exercised during the six months ended June 30, 2023 was $0.2 million.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0000950170-23-042449:notes:115]
6. INVESTMENTS

[0000950170-23-042449:notes:116]
Debt Securities and Other Investments

[0000950170-23-042449:notes:117]
The following debt securities and other investments were included on the Condensed Consolidated Balance Sheets and recorded at fair value:

[0000950170-23-042449:notes:118]
|  |  | As of June 30, 2023 |  |
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 1,897 |  |  | $ | 1 |  |  | $ | (58 | ) |  | $ | 1,840 |  |
| Municipal fixed-rate bonds |  |  | 185 |  |  |  | — |  |  |  | (2 | ) |  |  | 183 |  |
| Asset-backed bonds |  |  | 670 |  |  |  | — |  |  |  | (22 | ) |  |  | 648 |  |
| Mortgage/Agency-backed bonds |  |  | 1,298 |  |  |  | — |  |  |  | (74 | ) |  |  | 1,224 |  |
| U.S. government bonds |  |  | 3,955 |  |  |  | — |  |  |  | (162 | ) |  |  | 3,793 |  |
| Foreign government bonds |  |  | 405 |  |  |  | — |  |  |  | (19 | ) |  |  | 386 |  |
| Available-for-sale debt securities held at fair value |  | $ | 8,410 |  |  | $ | 1 |  |  | $ | (337 | ) |  | $ | 8,074 |  |

[0000950170-23-042449:notes:119]
|  |  | As of December 31, 2022 |  |
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 2,538 |  |  | $ | 5 |  |  | $ | (81 | ) |  | $ | 2,462 |  |
| Municipal fixed-rate bonds |  |  | 185 |  |  |  | — |  |  |  | (5 | ) |  |  | 180 |  |
| Asset-backed bonds |  |  | 818 |  |  |  | 1 |  |  |  | (24 | ) |  |  | 795 |  |
| Mortgage/Agency-backed bonds |  |  | 1,853 |  |  |  | — |  |  |  | (105 | ) |  |  | 1,748 |  |
| U.S. government bonds |  |  | 3,870 |  |  |  | 3 |  |  |  | (188 | ) |  |  | 3,685 |  |
| Foreign government bonds |  |  | 407 |  |  |  | — |  |  |  | (24 | ) |  |  | 383 |  |
| Available-for-sale debt securities held at fair value |  | $ | 9,671 |  |  | $ | 9 |  |  | $ | (427 | ) |  | $ | 9,253 |  |

[0000950170-23-042449:notes:120]
The contractual maturities related to debt securities and other investments were as follows:

[0000950170-23-042449:notes:121]
|  |  | As of June 30, 2023 |
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset-backed bonds |  |  | Mortgage/ Agency-backed bonds |  |  | U.S. government bonds |  |  | Foreign government bonds |  |  |
| Less than one year |  | $ | 470 |  |  | $ | 183 |  |  | $ | — |  |  | $ | — |  |  | $ | 2,158 |  |  | $ | 278 |  |  |
| One to two years |  |  | 1,048 |  |  |  | — |  |  |  | 218 |  |  |  | 164 |  |  |  | 1,266 |  |  |  | 108 |  |  |
| Two to three years |  |  | 322 |  |  |  | — |  |  |  | — |  |  |  | 288 |  |  |  | 249 |  |  |  | — |  |  |
| Three to five years |  |  | — |  |  |  | — |  |  |  | 287 |  |  |  | 226 |  |  |  | 120 |  |  |  | — |  |  |
| Five to ten years |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 200 |  |  |  | — |  |  |  | — |  |  |
| More than ten years |  |  | — |  |  |  | — |  |  |  | 143 |  |  |  | 346 |  |  |  | — |  |  |  | — |  |  |
| Total |  | $ | 1,840 |  |  | $ | 183 |  |  | $ | 648 |  |  | $ | 1,224 |  |  | $ | 3,793 |  |  | $ | 386 |  |  |

[0000950170-23-042449:notes:122]
Actual maturities may differ from contractual maturities as some borrowers have the right to call or prepay obligations with or without call or prepayment penalties.

[0000950170-23-042449:notes:123]
Realized gains and losses on sales of debt securities are computed under the specific identification method. The following table presents the gross realized gains and losses related to its debt securities:

[0000950170-23-042449:notes:124]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Gross realized gain on debt securities |  | $ | — |  |  | $ | — |  |  | $ | 4 |  |  | $ | 12 |  |
| Gross realized loss on debt securities |  |  | (27 | ) |  |  | (85 | ) |  |  | (39 | ) |  |  | (125 | ) |
| Total loss recognized, net |  | $ | (27 | ) |  | $ | (85 | ) |  | $ | (35 | ) |  | $ | (113 | ) |

[0000950170-23-042449:notes:125]
Income generated from available-for-sale debt securities was recorded as interest and dividend income in the Condensed Consolidated Statements of (Loss) Income. No allowance for credit losses was recorded for the six months ended June 30, 2023 and 2022 related to available-for-sale debt securities. The Company’s investment policy provides limitations for issuer concentration, which limits, at the time of purchase, the concentration in any one issuer to 5% of the market value of its total investment portfolio. The Company did not purchase any available-for-sale debt security with credit deterioration during the six months ended June 30, 2023.

[0000950170-23-042449:notes:126]
Realized and unrealized gains and losses related to marketable equity securities were as follows:

[0000950170-23-042449:notes:127]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Unrealized gain (loss) on equity securities held |  | $ | 1,288 |  |  | $ | (4,268 | ) |  | $ | 2,535 |  |  | $ | (7,630 | ) |
| Realized gain (loss) on equity securities sold |  |  | 1 |  |  |  | (293 | ) |  |  | 14 |  |  |  | (318 | ) |
| Total gain (loss) recognized, net |  | $ | 1,289 |  |  | $ | (4,561 | ) |  | $ | 2,549 |  |  | $ | (7,948 | ) |

[0000950170-23-042449:notes:128]
Income generated from marketable equity securities was recorded as interest and dividend income in the Condensed Consolidated Statements of (Loss) Income. U.S. GAAP establishes a three-level valuation hierarchy based upon observable and unobservable inputs for fair value measurement of financial instruments:

[0000950170-23-042449:notes:129]
 Level 1 – Observable outputs; values based on unadjusted quoted prices for identical assets or liabilities in an active market;

[0000950170-23-042449:notes:130]
 Level 2 – Significant inputs that are observable; values based on quoted prices in markets that are not active or model inputs that are observable either directly or indirectly;

[0000950170-23-042449:notes:131]
 Level 3 – Significant unobservable inputs; values based on prices or valuation techniques that require inputs that are both unobservable and significant to the overall fair value measurement. These inputs could include information supplied by investees.

[0000950170-23-042449:notes:132]
The Company’s cash equivalents and investments held at fair value are categorized into this hierarchy as follows:

[0000950170-23-042449:notes:133]
|  |  |  |  |  | Fair Value Measurements as of June 30, 2023 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket for IdenticalAssets (Level 1) |  |  | SignificantOtherObservableInputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities |  | $ | 1,019 |  |  | $ | 1,019 |  |  | $ | — |  |  | $ | — |  |
| Money market funds |  |  | 272 |  |  |  | 272 |  |  |  | — |  |  |  | — |  |
| Commercial paper |  |  | 310 |  |  |  | — |  |  |  | 310 |  |  |  | — |  |
| Total cash equivalents |  | $ | 1,601 |  |  | $ | 1,291 |  |  | $ | 310 |  |  | $ | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  | $ | 1,840 |  |  | $ | — |  |  | $ | 1,840 |  |  | $ | — |  |
| Municipal fixed-rate bonds |  |  | 183 |  |  |  | — |  |  |  | 183 |  |  |  | — |  |
| Asset-backed bonds |  |  | 648 |  |  |  | — |  |  |  | 648 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 1,224 |  |  |  | — |  |  |  | 1,224 |  |  |  | — |  |
| U.S. government bonds |  |  | 3,793 |  |  |  | 3,793 |  |  |  | — |  |  |  | — |  |
| Foreign government securities |  |  | 386 |  |  |  | — |  |  |  | 386 |  |  |  | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 858 |  |  |  | 854 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 25,395 |  |  |  | 25,395 |  |  |  | — |  |  |  | — |  |
| Total short-term and long-term investments |  | $ | 34,327 |  |  | $ | 30,042 |  |  | $ | 4,281 |  |  | $ | — |  |
| Total |  | $ | 35,928 |  |  | $ | 31,333 |  |  | $ | 4,591 |  |  | $ | — |  |

[0000950170-23-042449:notes:134]
|  |  |  |  |  | Fair Value Measurements as of December 31, 2022 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket for IdenticalAssets (Level 1) |  |  | SignificantOtherObservableInputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 228 |  |  | $ | 228 |  |  | $ | — |  |  | $ | — |  |
| Total cash equivalents |  | $ | 228 |  |  | $ | 228 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  | $ | 2,462 |  |  | $ | — |  |  | $ | 2,462 |  |  | $ | — |  |
| Municipal fixed-rate bonds |  |  | 180 |  |  |  | — |  |  |  | 180 |  |  |  | — |  |
| Asset-backed bonds |  |  | 795 |  |  |  | — |  |  |  | 795 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 1,748 |  |  |  | — |  |  |  | 1,748 |  |  |  | — |  |
| U.S. government bonds |  |  | 3,685 |  |  |  | 3,685 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 383 |  |  |  | — |  |  |  | 383 |  |  |  | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 810 |  |  |  | 810 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 22,942 |  |  |  | 22,942 |  |  |  | — |  |  |  | — |  |
| Total short-term and long-term investments |  | $ | 33,005 |  |  | $ | 27,437 |  |  | $ | 5,568 |  |  | $ | - |  |
| Total |  | $ | 33,233 |  |  | $ | 27,665 |  |  | $ | 5,568 |  |  | $ | — |  |

[0000950170-23-042449:notes:135]
The fair value of its Level 2 securities is calculated using a weighted average market price for each security. Market prices are obtained from a variety of industry standard data providers, large financial institutions and other third-party sources. These multiple market prices are used as inputs into a distribution-curve-based algorithm to determine the daily market value of each security.


## us-gaap:InventoryDisclosureTextBlock

[0000950170-23-042449:notes:136]
[same as prior period, unchanged from 0000950170-23-020333:notes:135]

[0000950170-23-042449:notes:137]
[same as prior period, unchanged from 0000950170-23-020333:notes:136]

[0000950170-23-042449:notes:138]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | June 30, 2023 |  |  | December 31, 2022 |  |
| Raw materials |  | $ | 186,262 |  |  | $ | 186,346 |  |
| Work in process |  |  | 13,576 |  |  |  | 12,087 |  |
| Finished goods |  |  | 216,964 |  |  |  | 229,098 |  |
| Total inventory, net |  | $ | 416,802 |  |  | $ | 427,531 |  |

[0000950170-23-042449:notes:139]
Inventory reserves are established for estimated excess and obsolete inventory equal to the difference between the cost of the inventory and the estimated net realizable value of the inventory based on estimated reserve percentages, which considers historical usage, known trends, inventory age and market conditions. As of June 30, 2023 and December 31, 2022, inventory reserves were $79.6 million and $57.0 million, respectively.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0000950170-23-042449:notes:140]
[same as prior period, unchanged from 0000950170-23-020333:notes:139]

[0000950170-23-042449:notes:141]
[same as prior period, unchanged from 0000950170-23-020333:notes:140]

[0000950170-23-042449:notes:142]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | June 30, 2023 |  |  | December 31, 2022 |  |
| Engineering and other equipment |  | $ | 178,493 |  |  | $ | 170,785 |  |
| Building |  |  | 83,420 |  |  |  | 82,932 |  |
| Computer hardware and software |  |  | 87,114 |  |  |  | 80,455 |  |
| Building and land improvements |  |  | 53,734 |  |  |  | 47,861 |  |
| Furniture and fixtures |  |  | 23,647 |  |  |  | 22,403 |  |
| Land |  |  | 5,379 |  |  |  | 5,364 |  |
| Total property, plant and equipment |  |  | 431,787 |  |  |  | 409,800 |  |
| Less: accumulated depreciation |  |  | (316,068 | ) |  |  | (299,101 | ) |
| Total property, plant and equipment, net |  | $ | 115,719 |  |  | $ | 110,699 |  |

[0000950170-23-042449:notes:143]
Long-lived assets used in operations are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable and the undiscounted cash flows estimated to be generated by the asset are less than the asset’s carrying value. During the three and six months ended June 30, 2023 and 2022, no impairment charges were recognized.

[0000950170-23-042449:notes:144]
Depreciation expense was $6.2 million and $2.7 million for the three months ended June 30, 2023 and 2022, respectively, and $13.8 million and $5.5 million for the six months ended June 30, 2023 and 2022, respectively, which is recorded in cost of revenue, selling, general and administrative expenses and research and development expenses in the Condensed Consolidated Statements of (Loss) Income.


## us-gaap:GoodwillDisclosureTextBlock

[0000950170-23-042449:notes:145]
[same as prior period, unchanged from 0000950170-23-020333:notes:144]

[0000950170-23-042449:notes:146]
The changes in the carrying amount of goodwill for the six months ended June 30, 2023 are as follows:

[0000950170-23-042449:notes:147]
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| As of December 31, 2022 |  | $ | 298,280 |  |  | $ | 83,444 |  |  | $ | 381,724 |  |
| Foreign currency translation adjustments |  |  | 5,013 |  |  |  | 1,426 |  |  |  | 6,439 |  |
| As of June 30, 2023 |  | $ | 303,293 |  |  | $ | 84,870 |  |  | $ | 388,163 |  |

[0000950170-23-042449:notes:148]
Related to the Business Combination with Adtran Networks the Company recognized $350.5 million of goodwill upon the closing of the Business Combination on July 15, 2022. Goodwill represents the excess purchase price over the fair value of net assets acquired. We qualitatively assess the carrying value of goodwill each reporting period for events or circumstance changes that would more likely than not reduce the fair value of the reporting unit below its carrying amount. Based on its assessment of certain qualitative factors such as macro-economic conditions, industry and market considerations, costs factors and overall financial performance, management concluded that no such events or circumstance changes were identified that would suggest that the fair value of the goodwill was more likely than not greater than it's carrying amount as of June 30, 2023. No impairment of goodwill was recorded during the three and six months ended June 30, 2023 and 2022.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0000950170-23-042449:notes:149]
[same as prior period, unchanged from 0000950170-23-020333:notes:149]

[0000950170-23-042449:notes:150]
[same as prior period, unchanged from 0000950170-23-020333:notes:150]

[0000950170-23-042449:notes:151]
|  |  |  |  | As of June 30, 2023 |  |  | As of December 31, 2022 |  |
| (In thousands) | Weighted Average Useful Life(in years) |  |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Net Book Value |  |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Net Book Value |  |
| Customer relationships |  | 10.9 |  |  | $ | 54,328 |  |  | $ | (13,393 | ) |  | $ | 40,935 |  |  | $ | 55,517 |  |  | $ | (12,772 | ) |  | $ | 42,745 |  |
| Backlog |  | 1.6 |  |  |  | 56,740 |  |  |  | (48,169 | ) |  |  | 8,571 |  |  |  | 55,782 |  |  |  | (22,725 | ) |  |  | 33,057 |  |
| Developed technology |  | 8.5 |  |  |  | 325,729 |  |  |  | (41,500 | ) |  |  | 284,229 |  |  |  | 320,364 |  |  |  | (21,856 | ) |  |  | 298,508 |  |
| Licensed technology |  | 9.0 |  |  |  | 5,900 |  |  |  | (3,469 | ) |  |  | 2,431 |  |  |  | 5,900 |  |  |  | (3,141 | ) |  |  | 2,759 |  |
| Licensing agreements |  | 8.5 |  |  |  | 560 |  |  |  | (335 | ) |  |  | 225 |  |  |  | 560 |  |  |  | (298 | ) |  |  | 262 |  |
| Patents |  | 7.3 |  |  |  | 500 |  |  |  | (466 | ) |  |  | 34 |  |  |  | 500 |  |  |  | (431 | ) |  |  | 69 |  |
| Trade names |  | 3.0 |  |  |  | 29,352 |  |  |  | (10,693 | ) |  |  | 18,659 |  |  |  | 29,066 |  |  |  | (5,255 | ) |  |  | 23,811 |  |
| Total |  |  |  | $ | 473,109 |  |  | $ | (118,025 | ) |  | $ | 355,084 |  |  | $ | 467,689 |  |  | $ | (66,478 | ) |  | $ | 401,211 |  |

[0000950170-23-042449:notes:152]
Intangible assets are reviewed for impairment whenever events and circumstances indicate impairment may have occurred. The Company assessed impairment triggers related to intangible assets during each financial period in 2023 and 2022. As a result, no quantitative impairment test of long-lived assets was performed as of June 30, 2023 and 2022, and no impairment losses of intangible assets were recorded during the three and six months ended June 30, 2023 and 2022.

[0000950170-23-042449:notes:153]
Amortization expense was $26.5 million and $0.9 million in the three months ended June 30, 2023 and 2022, respectively, and $52.3 million and $1.8 million in the six months ended June 30, 2023 and 2022, respectively and was included in cost of revenue, selling, general and administrative expenses and research and development expenses in the Condensed Consolidated Statements of (Loss) Income.

[0000950170-23-042449:notes:154]
Estimated future amortization expense of intangible assets is as follows:

[0000950170-23-042449:notes:155]
|  |  | As of |  |
| (In thousands) |  | June 30, 2023 |  |
| 2023 |  | $ | 30,683 |  |
| 2024 |  |  | 58,478 |  |
| 2025 |  |  | 46,835 |  |
| 2026 |  |  | 43,554 |  |
| 2027 |  |  | 42,180 |  |
| Thereafter |  |  | 133,354 |  |
| Total |  | $ | 355,084 |  |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0000950170-23-042449:notes:156]
[same as prior period, unchanged from 0000950170-23-020333:notes:156]

[0000950170-23-042449:notes:157]
The Company has certain forward rate agreements to hedge foreign currency exposure of expected future cash flows in foreign currency. The Company does not hold or issue derivative instruments for trading or other speculative purposes. Derivatives are initially recognized at fair value on the date a derivative contract is entered into and are subsequently re-measured to their fair value at the end of each reporting period. All changes in the fair value of derivative instruments are recognized as other income (expense) in the Consolidated Statements of (Loss) Income and are classified as Level II under the fair value hierarchy. The derivative instruments are not subject to master netting agreements and are not offset in the Consolidated Balance Sheets. We are exposed to risk from credit-related losses resulting from nonperformance by counterparties to our financial instruments. We perform credit evaluations of our counterparties under forward exchange contracts and expect all counterparties to meet their obligations. We have not experienced credit losses from our counterparties. As of June 30, 2023, the Company had 51 forward rate contracts outstanding.

[0000950170-23-042449:notes:158]
Foreign Currency Hedging Arrangements

[0000950170-23-042449:notes:159]
On November 3, 2022, the Company entered into a Euro/U.S. forward contract arrangement (the “Initial Forward”) with Wells Fargo Bank, N.A. (the “Hedge Counterparty”). The Initial Forward, which is governed by the provisions of an ISDA Master Agreement (including schedules thereto and transaction confirmations that supplement such agreement) entered into between the Company and the Hedge Counterparty, enables the Company to convert a portion of its Euro denominated payment obligations under the DPLTA into U.S. Dollars. Under the Initial Forward, the Company agreed to exchange an aggregate notional amount of $160.0 million U.S. dollars for Euros at a daily fixed forward rate ranging from $0.98286 to $1.03290. The aggregate amount of $160.0 million is divided into eight quarterly tranches of $20.0 million, commencing in the fourth quarter of 2022. The Company, at its sole discretion, may exchange all or part of each tranche on any given day within the applicable quarter; provided, however, that it must exchange the full tranche by the end of such quarter. The Initial Forward may be accelerated or terminated early for a number of reasons, including but not limited to (i) non-payment by the Company or the Hedge Counterparty, (ii) breach of representation or warranty or covenant by either party or (iii) insolvency or bankruptcy of either party.

[0000950170-23-042449:notes:160]
On March 21, 2023, the Company entered into a Euro/U.S. dollar forward contract arrangement (the “Forward”) with the Hedge Counterparty. Under the Forward, which is governed by the provisions of an ISDA Master Agreement (including schedules thereto and transaction confirmations that supplement such agreement) entered into between the Company and the Hedge Counterparty, the Company will exchange an aggregate notional amount of $160.0 million U.S. dollars for Euros at a daily fixed forward rate of $1.085 per €1.00 in average. During the six months ended June 30, 2023, the Company settled two $20.0 million forward contract tranches and the remaining will be divided into six quarterly tranches of $20.0 million. These forward contracts transacted on March 21, 2023 (to sell EUR/buy USD) were entered into for the purpose of unwinding the previously transacted forward contracts (to buy EUR/sell USD), transacted in November 2022. The drawdown dates of the original ratchet forwards are set to the same date as the maturity of the new offsetting forward contracts.

[0000950170-23-042449:notes:161]
The fair values of the Company's derivative instruments recorded in the Condensed Consolidated Balance Sheet as of June 30, 2023 and December 31, 2022 were as follows:

[0000950170-23-042449:notes:162]
| (In thousands) |  | Balance Sheet Location |  | June 30, 2023 |  |  | December 31, 2022 |  |
| Derivatives Not Designated as Hedging Instruments (Level 2): |  |  |  |  |  |  |  |  |
| Foreign exchange contracts – derivative assets |  | Other receivables |  | $ | 10,467 |  |  | $ | 11,992 |  |
| Foreign exchange contracts – derivative liabilities |  | Accounts payable |  | $ | (2,378 | ) |  | $ | (633 | ) |
| Total derivatives |  |  |  | $ | 8,089 |  |  | $ | 11,359 |  |

[0000950170-23-042449:notes:163]
The change in the fair values of the Company's derivative instruments recorded in the Condensed Consolidated Statements of (Loss) Income during the three and six months ended June 30, 2023 and 2022 were as follows:

[0000950170-23-042449:notes:164]
|  |  |  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  |  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | Income StatementLocation |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Derivatives Not Designated as Hedging Instruments: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Other income, net |  | $ | 158 |  |  | $ | — |  |  | $ | 89 |  |  | $ | — |  |


## us-gaap:DebtDisclosureTextBlock

[0000950170-23-042449:notes:165]
12. REVOLVING CREDIT AGREEMENTS

[0000950170-23-042449:notes:166]
The carrying amounts of the Company's current and non-current revolving credit agreements in its Condensed Consolidated Balance Sheets were as follows:

[0000950170-23-042449:notes:167]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | June 30, 2023 |  |  | December 31, 2022 |  |
| New Nord/LB revolving line of credit |  | $ | 10,912 |  |  | $ | — |  |
| Nord/LB revolving line of credit |  |  | — |  |  |  | 16,091 |  |
| Syndicated credit agreement working capital line of credit |  |  | — |  |  |  | 10,727 |  |
| DZ bank revolving line of credit |  |  | — |  |  |  | 9,118 |  |
| Total current revolving credit agreements |  | $ | 10,912 |  |  | $ | 35,936 |  |

[0000950170-23-042449:notes:168]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | June 30, 2023 |  |  | December 31, 2022 |  |
| Wells Fargo credit agreement |  | $ | 200,000 |  |  | $ | 60,000 |  |
| Total non-current revolving credit agreement |  | $ | 200,000 |  |  | $ | 60,000 |  |

[0000950170-23-042449:notes:169]
As of June 30, 2023, the weighted average interest rate on our revolving credit agreements was 6.4%.

[0000950170-23-042449:notes:170]
Wells Fargo Credit Agreement

[0000950170-23-042449:notes:171]
On July 18, 2022, ADTRAN Holdings, Inc. and ADTRAN, Inc., as the borrower, entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (the “Credit Agreement”). The Credit Agreement initially allowed for borrowings of up to $100.0 million in aggregate principal amount, but the permitted borrowings increased to up to $400.0 million in aggregate principal amount upon the DPLTA becoming effective on January 16, 2023.

[0000950170-23-042449:notes:172]
The Credit Agreement replaced the Cadence Revolving Credit Agreement and the prior Wells Fargo Revolving Credit Agreement. In connection with the entry into the Credit Agreement, all outstanding borrowings under such credit agreements have been repaid and the agreements terminated.

[0000950170-23-042449:notes:173]
As of June 30, 2023, ADTRAN, Inc.’s borrowings under the revolving line of credit were $200.0 million. The Credit Agreement matures in July 2027 but provides the Company with an option to request extensions subject to customary conditions. In addition, we may issue up to $25.0 million in letters of credit against our $400.0 million total facility. As of June 30, 2023, we had a total of $2.2 million in letters of credit under ADTRAN, Inc. outstanding against our eligible borrowings, leaving a net amount of $197.8 million available for future borrowings. Any future credit extensions under the Credit Agreement are subject to customary conditions precedent. The proceeds of any loans are expected to be used for general corporate purposes and to pay a portion of the Exchange Offer consideration.

[0000950170-23-042449:notes:174]
All U.S. borrowings under the Credit Agreement (other than swingline loans, which bear interest at the Base Rate (as defined below)) bear interest, at the Company’s option, at a rate per annum equal to (A)(i) the highest of (a) the federal funds rate (i.e., for any day, the rate per annum equal to the weighted average of the rates on overnight federal funds transactions with members of the Federal Reserve System, as published by the Federal Reserve Bank of New York on the business day next succeeding such day) plus ½ of 1%, (b) the prime commercial lending rate of the Administrative Agent, as established from time to time at its principal U.S. office (which such rate is an index or base rate and will not necessarily be its lowest or best rate charged to its customers or other banks), and (c) the daily Adjusted Term SOFR (as defined in the Credit Agreement) for a one-month tenor plus 1%, plus (ii) the applicable rate, ranging from 0.5% to 1.25% (the “Base Rate”), or (B) the sum of the Adjusted Term SOFR (as defined in the Credit Agreement) plus the applicable rate, ranging from 1.4% to 2.15%, provided that such sum is subject to a 0.0% floor (such loans utilizing this interest rate, “SOFR Loans”). All E.U. borrowings under the Credit Agreement (other than swingline loans) bear interest at a rate per annum equal to the sum of the Euro Interbank Offered Rate as administered by the European Money Markets Institute (or a comparable or successor administrator approved by the Administrative Agent) plus the applicable rate, ranging from 1.5% to 2.25%, provided that such sum is subject to a 0.0% floor (such loans utilizing this interest rate, “EURIBOR Loans”). The applicable rate is based on the consolidated net leverage ratio of the Company and its subsidiaries as determined pursuant to the terms of the Credit Agreement. Default interest is 2.00% per annum in excess of the rate otherwise applicable in the case of any overdue principal or any other overdue amount.

[0000950170-23-042449:notes:175]
In addition to paying interest on outstanding principal under the Credit Agreement, the Company is required to pay a commitment fee to the lenders under the Credit Agreement in respect of unutilized revolving loan commitments and an additional commitment ticking fee at a rate of 0.25% on the commitment amounts of each lender until the earliest of (i) the date of the Senior Credit Facilities Increase, (ii) the Company’s voluntary termination of the credit facility commitment, and (iii) December 31, 2023. The Company is also required to pay a participation fee to the Administrative Agent for the account of each lender with respect to the Company’s participation in letters of credit at the then applicable rate for SOFR Loans.

[0000950170-23-042449:notes:176]
The Credit Agreement permits the Company to prepay any or all of the outstanding loans or to reduce the commitments under the Credit Agreement without incurring premiums or penalties (except breakage costs with respect to SOFR Loans and EURIBOR Loans). The Credit Agreement contains customary affirmative and negative covenants, including incurrence covenants and certain other limitations on the ability of the Company and the Company’s subsidiaries to incur additional debt, guarantee other obligations, grant liens on assets, make investments, dispose of assets, pay dividends or other payments on capital stock, make restricted payments, engage in mergers or consolidations, engage in transactions with affiliates, modify its organizational documents, and enter into certain restrictive agreements. It also contains customary events of default (subject to customary cure periods and materiality thresholds). Furthermore, the Credit Agreement requires that the consolidated total net leverage ratio (as defined in the Credit Agreement) of the Company and its subsidiaries tested on the last day of each fiscal quarter not exceed 3.25 to 1.0 through September 30, 2024 and 2.75 to 1.00 from December 31, 2024 and thereafter, subject to certain exceptions. The Credit Agreement also requires that the consolidated interest coverage ratio (as defined in the Credit Agreement) of the Company and its subsidiaries tested on the last day of each fiscal quarter not fall below 3.00 to 1.00. As of June 30, 2023, the Company was in compliance with all material covenants.

[0000950170-23-042449:notes:177]
Finally, pursuant to a Collateral Agreement, dated as of July 18, 2022, among the Company, ADTRAN, Inc. and the Administrative Agent, ADTRAN, Inc.’s obligations under the Credit Agreement are secured by substantially all of the assets of ADTRAN, Inc. and the

[0000950170-23-042449:notes:178]
Company. In addition, the Company has guaranteed ADTRAN, Inc.’s obligations under the Credit Agreement pursuant to a Guaranty Agreement, dated as of July 18, 2022, by ADTRAN, Inc. and the Company in favor of the Administrative Agent.

[0000950170-23-042449:notes:179]
Nord/LB Revolving Line of Credit

[0000950170-23-042449:notes:180]
On March 29, 2023, Adtran Networks entered into a $16.1 million unsecured revolving line of credit with Norddeutsche Landesbark - Girozentrale (Nord/LB) that bears interest of Euro Short Term Rate plus 1.94%. The line of credit has a perpetual term that can be terminated by the Company or Nord/LB at any time. As of June 30, 2023, Adtran Networks borrowed $10.9 million under this facility.

[0000950170-23-042449:notes:181]
Prior Nord/LB Revolving Line of Credit

[0000950170-23-042449:notes:182]
On August 8, 2022, Adtran Networks entered into a $16.1 million revolving line of credit with Norddeutsche Landesbark - Girozentrale (Nord/LB) that bears interest of Euro Short Term Rate plus 1.4% and which matures in August 2023. On January 31, 2023, the Company repaid the outstanding borrowings under the Nord/LB revolving line of credit. No amounts are available for future borrowings.

[0000950170-23-042449:notes:183]
Syndicated Credit Agreement Working Capital Line of Credit

[0000950170-23-042449:notes:184]
In September 2018, Adtran Networks entered into a syndicated credit agreement with Bayerische Landesbank and Deutsche Bank AG Branch German Business to borrow up to $10.7 million as part of a working capital line of credit. On January 31, 2023, the Company repaid the outstanding borrowings under the syndicated credit agreement working capital line of credit. No amounts are available for future borrowings.

[0000950170-23-042449:notes:185]
DZ Bank Revolving Line of Credit

[0000950170-23-042449:notes:186]
In the fourth quarter of 2022, Adtran Networks entered into a revolving line of credit with DZ Bank to borrow up to $9.1 million. Interest on the line of credit reset monthly based on renewal of the loan and was 2.8% at the time the loan was repaid. On March 12, 2023, the Company repaid the outstanding borrowings under the DZ Bank revolving line of credit. No amounts are available for future borrowings.


## adtn:NotesPayableDisclosureTextBlock

[0000950170-23-042449:notes:187]
13. NOTES PAYABLE

[0000950170-23-042449:notes:188]
The carrying amounts of the Company's notes payable in its Condensed Consolidated Balance Sheets were as follows:

[0000950170-23-042449:notes:189]
|  |  | Fair Value as of |  |  | Carrying Value as of |  |  | Carrying Value as of |  |
| (In thousands) |  | June 30, 2023 |  |  | June 30, 2023 |  |  | December 31, 2022 |  |
| Syndicated credit agreement notes payable |  | $ | — |  |  | $ | — |  |  | $ | 24,598 |  |
| Total Notes Payable |  | $ | — |  |  | $ | — |  |  | $ | 24,598 |  |

[0000950170-23-042449:notes:190]
Syndicated Credit Agreement Note Payable

[0000950170-23-042449:notes:191]
In September 2018, Adtran Networks entered into a syndicated credit agreement with Bayerische Landesbank and Deutsche Bank AG Branch German Business to borrow $63.7 million. On January 31, 2023, the Company repaid the outstanding borrowings under the syndicated credit agreement note payable. No amounts are available for future borrowings.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0000950170-23-042449:notes:192]
[same as prior period, unchanged from 0000950170-23-020333:notes:191]

[0000950170-23-042449:notes:193]
The Company maintains defined benefit pension plans covering employees in certain foreign countries.

[0000950170-23-042449:notes:194]
[same as prior period, unchanged from 0000950170-23-020333:notes:193]

[0000950170-23-042449:notes:195]
[same as prior period, unchanged from 0000950170-23-020333:notes:194]

[0000950170-23-042449:notes:196]
[same as prior period, unchanged from 0000950170-23-020333:notes:195]

[0000950170-23-042449:notes:197]
[same as prior period, unchanged from 0000950170-23-020333:notes:196]

[0000950170-23-042449:notes:198]
[same as prior period, unchanged from 0000950170-23-020333:notes:197]

[0000950170-23-042449:notes:199]
The Company's net pension liability for all defined benefit pension plans totaled $10.9 million and $10.6 million as of June 30, 2023 and December 31, 2022, respectively.

[0000950170-23-042449:notes:200]
The following table summarizes the components of net periodic pension cost related to the Company's defined benefit pension plans:

[0000950170-23-042449:notes:201]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Service cost |  | $ | 404 |  |  | $ | 246 |  |  | $ | 802 |  |  | $ | 502 |  |
| Interest cost |  |  | (33 | ) |  |  | 212 |  |  |  | (66 | ) |  |  | 434 |  |
| Expected return on plan assets |  |  | 59 |  |  |  | (449 | ) |  |  | 118 |  |  |  | (919 | ) |
| Amortization of actuarial losses |  |  | 6 |  |  |  | 85 |  |  |  | 13 |  |  |  | 174 |  |
| Net periodic pension cost |  | $ | 436 |  |  | $ | 94 |  |  | $ | 867 |  |  | $ | 191 |  |

[0000950170-23-042449:notes:202]
The components of net periodic pension cost, other than the service cost component, are included in other income, net in the Condensed Consolidated Statements of (Loss) Income. Service cost is included in cost of revenue, selling, general and administrative expenses and research and development expenses in the Condensed Consolidated Statements of (Loss) Income. The Company made contributions to the defined benefit pension plans totaling $1.8 million and $0.6 million during the six months ending June 30, 2023 and 2022, respectively. Contributions to the defined benefit pension plans for the remainder of 2023 will be limited to benefit payments to retirees which are paid out of the operating cash flows of the Company and are expected to be approximately $1.8 million.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0000950170-23-042449:notes:203]
[same as prior period, unchanged from 0000950170-23-020333:notes:202]

[0000950170-23-042449:notes:204]
[same as prior period, unchanged from 0000950170-23-020333:notes:203]

[0000950170-23-042449:notes:205]
[same as prior period, unchanged from 0000950170-23-020333:notes:204]

[0000950170-23-042449:notes:206]
|  |  | Three Months Ended June 30, 2023 |  |
| (In thousands) |  | Unrealized(Losses) GainsonAvailable-for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | ASU 2018-02 Adoption |  |  | Total |  |
| Balance as of March 31, 2023 |  | $ | (767 | ) |  | $ | (981 | ) |  | $ | 56,614 |  |  | $ | 385 |  |  | $ | 55,251 |  |
| Other comprehensive income before reclassifications |  |  | 15 |  |  |  | — |  |  |  | 6,940 |  |  |  | — |  |  |  | 6,955 |  |
| Amounts reclassified from accumulated other comprehensive (loss) income |  |  | (21 | ) |  |  | 23 |  |  |  | — |  |  |  | — |  |  |  | 2 |  |
| Net current period other comprehensive (loss) income |  |  | (6 | ) |  |  | 23 |  |  |  | 6,940 |  |  |  | — |  |  |  | 6,957 |  |
| Balance as of June 30, 2023 |  | $ | (773 | ) |  | $ | (958 | ) |  | $ | 63,554 |  |  | $ | 385 |  |  | $ | 62,208 |  |

[0000950170-23-042449:notes:207]
|  |  | Three Months Ended June 30, 2022 |  |
| (In thousands) |  | Unrealized(Losses) GainsonAvailable-for-Sale Securities |  |  | DefinedBenefit Plan Adjustments |  |  | ForeignCurrency Adjustments |  |  | ASU 2018-02 Adoption |  |  | Total |  |
| Balance as of March 31, 2022 |  | $ | (1,276 | ) |  | $ | (5,626 | ) |  | $ | (7,039 | ) |  | $ | 385 |  |  | $ | (13,556 | ) |
| Other comprehensive loss before reclassifications |  |  | (589 | ) |  |  | — |  |  |  | (2,853 | ) |  |  | — |  |  |  | (3,442 | ) |
| Amounts reclassified from accumulated other comprehensive income (loss) |  |  | 389 |  |  |  | (87 | ) |  |  | — |  |  |  | — |  |  |  | 302 |  |
| Net current period other comprehensive loss |  |  | (200 | ) |  |  | (87 | ) |  |  | (2,853 | ) |  |  | — |  |  |  | (3,140 | ) |
| Balance as of June 30, 2022 |  | $ | (1,476 | ) |  | $ | (5,713 | ) |  | $ | (9,892 | ) |  | $ | 385 |  |  | $ | (16,696 | ) |

[0000950170-23-042449:notes:208]
|  |  | Six Months Ended June 30, 2023 |  |
| (In thousands) |  | UnrealizedGains (Losses)onAvailable-for-SaleSecurities |  |  | DefinedBenefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | ASU 2018-02 Adoption |  |  | Total |  |
| Balance as of December 31, 2022 |  | $ | (836 | ) |  | $ | (1,016 | ) |  | $ | 48,180 |  |  | $ | 385 |  |  | $ | 46,713 |  |
| Other comprehensive income before reclassifications |  |  | 98 |  |  |  | — |  |  |  | 15,618 |  |  |  | — |  |  |  | 15,716 |  |
| Amounts reclassified from accumulated other comprehensive (loss) income |  |  | (35 | ) |  |  | 58 |  |  |  | — |  |  |  | — |  |  |  | 23 |  |
| Net current period other comprehensive income |  |  | 63 |  |  |  | 58 |  |  |  | 15,618 |  |  |  | — |  |  |  | 15,739 |  |
| Less: Comprehensive income attributable to non-controlling interest, net of tax |  |  | — |  |  |  | — |  |  |  | 244 |  |  |  | — |  |  |  | 244 |  |
| Balance as of June 30, 2023 |  | $ | (773 | ) |  | $ | (958 | ) |  | $ | 63,554 |  |  | $ | 385 |  |  | $ | 62,208 |  |

[0000950170-23-042449:notes:209]
|  |  | Six Months Ended June 30, 2022 |  |
| (In thousands) |  | UnrealizedGains (Losses) on Available-for-Sale Securities |  |  | DefinedBenefit Plan Adjustments |  |  | ForeignCurrency Adjustments |  |  | ASU 2018-02 Adoption |  |  | Total |  |
| Balance as of December 31, 2021 |  | $ | (552 | ) |  | $ | (5,613 | ) |  | $ | (6,134 | ) |  | $ | 385 |  |  | $ | (11,914 | ) |
| Other comprehensive loss before reclassifications |  |  | (1,564 | ) |  |  | — |  |  |  | (3,758 | ) |  |  | — |  |  |  | (5,322 | ) |
| Amounts reclassified from accumulated other comprehensive income (loss) |  |  | 640 |  |  |  | (100 | ) |  |  | — |  |  |  | — |  |  |  | 540 |  |
| Net current period other comprehensive loss |  |  | (924 | ) |  |  | (100 | ) |  |  | (3,758 | ) |  |  | — |  |  |  | (4,782 | ) |
| Balance as of June 30, 2022 |  | $ | (1,476 | ) |  | $ | (5,713 | ) |  | $ | (9,892 | ) |  | $ | 385 |  |  | $ | (16,696 | ) |

[0000950170-23-042449:notes:210]
[same as prior period, unchanged from 0000950170-23-020333:notes:207]

[0000950170-23-042449:notes:211]
|  |  | Three Months Ended June 30, 2023 |
| (In thousands) |  | Amount ReclassifiedfromAccumulated Other Comprehensive (Loss) Income |  |  | Affected Line Item in theStatement Where Net(Loss) Income Is Presented |
| Unrealized gain (loss) on available-for-sale securities: |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 28 |  |  | Net investment gain (loss) |
| Defined benefit plan adjustments – actuarial loss |  |  | (33 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | (5 | ) |  |  |
| Tax benefit |  |  | 3 |  |  |  |
| Total reclassifications for the period, net of tax |  | $ | (2 | ) |  |  |

[0000950170-23-042449:notes:212]
(1)
A part of the computation of net periodic pension cost, which is included in other income, net in the Condensed Consolidated Statements of (Loss) Income.

[0000950170-23-042449:notes:213]
|  |  | Three Months Ended June 30, 2022 |
| (In thousands) |  | Amount ReclassifiedfromAccumulated Other Comprehensive (Loss) Income |  |  | Affected Line Item in the Statement Where Net (Loss) Income Is Presented |
| Unrealized gain (loss) on available-for-sale securities: |  |  |  |  |  |
| Net realized loss on sales of securities |  | $ | (512 | ) |  | Net investment gain (loss) |
| Defined benefit plan adjustments – actuarial gain |  |  | 126 |  |  | (1) |
| Total reclassifications for the period, before tax |  |  | (386 | ) |  |  |
| Tax benefit |  |  | 84 |  |  |  |
| Total reclassifications for the period, net of tax |  | $ | (302 | ) |  |  |

[0000950170-23-042449:notes:214]
|  |  | Six Months Ended June 30, 2023 |
| (In thousands) |  | Amount ReclassifiedfromAccumulated Other Comprehensive (Loss) Income |  |  | Affected Line Item in the Statement Where Net (Loss)Income Is Presented |
| Unrealized gain (loss) on available-for-sale securities: |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 46 |  |  | Net investment gain (loss) |
| Defined benefit plan adjustments – actuarial loss |  |  | (84 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | (38 | ) |  |  |
| Tax benefit |  |  | 15 |  |  |  |
| Total reclassifications for the period, net of tax |  | $ | (23 | ) |  |  |

[0000950170-23-042449:notes:215]
|  |  | Six Months Ended June 30, 2022 |
| (In thousands) |  | Amount ReclassifiedfromAccumulated Other Comprehensive (Loss) Income |  |  | Affected Line Item in the Statement Where Net (Loss)Income Is Presented |
| Unrealized gain (loss) on available-for-sale securities: |  |  |  |  |  |
| Net realized loss on sales of securities |  | $ | (842 | ) |  | Net investment gain (loss) |
| Defined benefit plan adjustments – actuarial gain |  |  | 145 |  |  | (1) |
| Total reclassifications for the period, before tax |  |  | (697 | ) |  |  |
| Tax benefit |  |  | 157 |  |  |  |
| Total reclassifications for the period, net of tax |  | $ | (540 | ) |  |  |

[0000950170-23-042449:notes:216]
[same as prior period, unchanged from 0000950170-23-020333:notes:211]

[0000950170-23-042449:notes:217]
|  |  | Three Months Ended |  |  | Three Months Ended |  |
|  |  | June 30, 2023 |  |  | June 30, 2022 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense)Benefit |  |  | Net-of-Tax Amount |  |  | Before-Tax Amount |  |  | Tax(Expense)Benefit |  |  | Net-of-TaxAmount |  |
| Unrealized gain (loss) on available-for-sale securities |  | $ | 20 |  |  | $ | (5 | ) |  | $ | 15 |  |  | $ | (775 | ) |  | $ | 186 |  |  | $ | (589 | ) |
| Reclassification adjustment for amounts related to available-for-sale investments included in net (loss) gain |  |  | (28 | ) |  |  | 7 |  |  |  | (21 | ) |  |  | 512 |  |  |  | (123 | ) |  |  | 389 |  |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net gain (loss) |  |  | 33 |  |  |  | (10 | ) |  |  | 23 |  |  |  | (126 | ) |  |  | 39 |  |  |  | (87 | ) |
| Foreign currency translation adjustments |  |  | 6,940 |  |  |  | — |  |  |  | 6,940 |  |  |  | (2,853 | ) |  |  | — |  |  |  | (2,853 | ) |
| Total Other Comprehensive Income (Loss) |  | $ | 6,965 |  |  | $ | (8 | ) |  | $ | 6,957 |  |  | $ | (3,242 | ) |  | $ | 102 |  |  | $ | (3,140 | ) |

[0000950170-23-042449:notes:218]
|  |  | Six Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, 2023 |  |  | June 30, 2022 |  |
| (In thousands) |  | Before-TaxAmount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |  | Before-Tax Amount |  |  | Tax (Expense)Benefit |  |  | Net-of-Tax Amount |  |
| Unrealized gain (loss) on available-for-sale securities |  | $ | 129 |  |  | $ | (31 | ) |  | $ | 98 |  |  | $ | (2,058 | ) |  | $ | 494 |  |  | $ | (1,564 | ) |
| Reclassification adjustment for amounts related to available-for-sale investments included in net (loss) gain |  |  | (46 | ) |  |  | 11 |  |  |  | (35 | ) |  |  | 842 |  |  |  | (202 | ) |  |  | 640 |  |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net gain (loss) |  |  | 84 |  |  |  | (26 | ) |  |  | 58 |  |  |  | (145 | ) |  |  | 45 |  |  |  | (100 | ) |
| Foreign currency translation adjustments |  |  | 15,618 |  |  |  | — |  |  |  | 15,618 |  |  |  | (3,758 | ) |  |  | — |  |  |  | (3,758 | ) |
| Total Other Comprehensive Gain (Loss) |  | $ | 15,785 |  |  | $ | (46 | ) |  | $ | 15,739 |  |  | $ | (5,119 | ) |  | $ | 337 |  |  | $ | (4,782 | ) |


## us-gaap:RedeemableNoncontrollingInterestTableTextBlock

[0000950170-23-042449:notes:219]
The following table summarizes the redeemable non-controlling interest activity for the six months ended June 30, 2023:

[0000950170-23-042449:notes:220]
|  |  | Six Months Ended |  |
| (In thousands) |  | June 30, 2023 |  |
| Balance at beginning of period |  | $ | — |  |
| Reclassification of non-controlling interests |  |  | 443,757 |  |
| Redemption of redeemable non-controlling interest |  |  | (1,552 | ) |
| Net income attributable to redeemable non-controlling interests |  |  | 5,691 |  |
| Annual recurring compensation earned |  |  | (5,691 | ) |
| Translation adjustment |  |  | 3,244 |  |
| Adtran Networks stock option exercises |  |  | 13 |  |
| Balance as of June 30, 2023 |  | $ | 445,462 |  |


## us-gaap:EarningsPerShareTextBlock

[0000950170-23-042449:notes:221]
17. (LOSS) EARNINGS PER SHARE

[0000950170-23-042449:notes:222]
The calculation of basic and diluted (loss) earnings per share is as follows:

[0000950170-23-042449:notes:223]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands, except per share amounts) |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Numerator |  |  |  |  |  |  |  |  |  |  |  |  |
| Net (loss) income attributable to ADTRAN Holdings, Inc. |  | $ | (33,334 | ) |  | $ | 2,143 |  |  | $ | (67,798 | ) |  | $ | 1,016 |  |
| Denominator |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average number of shares – basic |  |  | 78,366 |  |  |  | 49,123 |  |  |  | 78,364 |  |  |  | 49,110 |  |
| Effect of dilutive securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock options |  |  | — |  |  |  | 84 |  |  |  | — |  |  |  | 111 |  |
| PSUs, RSUs and restricted stock |  |  | — |  |  |  | 602 |  |  |  | — |  |  |  | 592 |  |
| Weighted average number of shares – diluted |  |  | 78,366 |  |  |  | 49,809 |  |  |  | 78,364 |  |  |  | 49,813 |  |
| (Loss) earnings per share attributable to ADTRAN Holdings, Inc. – basic |  | $ | (0.43 | ) |  | $ | 0.04 |  |  | $ | (0.87 | ) |  | $ | 0.02 |  |
| (Loss) earnings per share attributable to ADTRAN Holdings, Inc. – diluted |  | $ | (0.43 | ) |  | $ | 0.04 |  |  | $ | (0.87 | ) |  | $ | 0.02 |  |

[0000950170-23-042449:notes:224]
For the three months ended June 30, 2023 and 2022, 0.8 million and 33 thousand shares, respectively, and for the six months ended June 30, 2023 and 2022, 0.3 million and 8 thousand shares, respectively, of unvested PSUs, RSUs and restricted stock were excluded from the calculation of diluted earnings per share due to their anti-dilutive effect.

[0000950170-23-042449:notes:225]
For the three months ended June 30, 2023 and 2022, 2.2 million and 0.2 million stock options, respectively, and for the six months ended June 30, 2023 and 2022, 1.0 million and 0.1 million stock options, respectively, were outstanding but were not included in the computation of diluted earnings per share. These stock options were excluded because their exercise prices were greater than the average market price of the common shares during the applicable period, making them anti-dilutive under the treasury stock method.


## us-gaap:SegmentReportingDisclosureTextBlock

[0000950170-23-042449:notes:226]
[same as prior period, unchanged from 0000950170-23-020333:notes:220]

[0000950170-23-042449:notes:227]
[same as prior period, unchanged from 0000950170-23-020333:notes:221]

[0000950170-23-042449:notes:228]
The Network Solutions segment includes hardware and software products that enable a digital future which support the Company's Subscriber, Access & Aggregation, and Optical Networking Solutions. The Company's cloud-managed Wi-Fi gateways, virtualization software, and switches provide a mix of wired and wireless connectivity at the customer premises. In addition, its Carrier Ethernet products support a variety of applications at the network edge ranging from mobile backhaul to connecting enterprise customers (“Subscriber Solutions"). The Company's portfolio includes products for multi-gigabit service delivery over fiber or alternative media to homes and businesses.

[0000950170-23-042449:notes:229]
The Services & Support segment offers a comprehensive portfolio of network design, implementation, maintenance and cloud-hosted services supporting its Subscriber, Access & Aggregation, and Optical Networking Solutions. These services assist operators in the deployment of multi-vendor networks while reducing their cost to maintain these networks. The cloud-hosted services include a suite of SaaS applications under the Company's Mosaic One platform that manages end-to-end network and service optimization for both fiber access infrastructure and mesh Wi-Fi connectivity. The Company backs these services with a global support organization that offers on-site and off-site support services with varying SLAs.

[0000950170-23-042449:notes:230]
The performance of these segments is evaluated based on revenue, gross profit and gross margin; therefore, selling, general and administrative expenses, research and development expenses, interest and dividend income, interest expense, net investment gain (loss), other income (loss), net and income tax benefit (expense) are reported on a Company-wide basis only. There is no inter-segment revenue. Asset information by reportable segment is not produced and, therefore, is not reported.

[0000950170-23-042449:notes:231]
The following tables present information about the revenue and gross profit of the Company's reportable segments:

[0000950170-23-042449:notes:232]
|  |  | Three Months Ended |  |
|  |  | June 30, 2023 |  |  | June 30, 2022 |  |
| (In thousands) |  | Revenue |  |  | Gross Profit |  |  | Revenue |  |  | Gross Profit |  |
| Network Solutions |  | $ | 283,002 |  |  | $ | 66,042 |  |  | $ | 155,992 |  |  | $ | 56,071 |  |
| Services & Support |  |  | 44,376 |  |  |  | 26,511 |  |  |  | 16,046 |  |  |  | 6,435 |  |
| Total |  | $ | 327,378 |  |  | $ | 92,553 |  |  | $ | 172,038 |  |  | $ | 62,506 |  |

[0000950170-23-042449:notes:233]
|  |  | Six Months Ended |  |
|  |  | June 30, 2023 |  |  | June 30, 2022 |  |
| (In thousands) |  | Revenue |  |  | Gross Profit |  |  | Revenue |  |  | Gross Profit |  |
| Network Solutions |  | $ | 565,420 |  |  | $ | 129,330 |  |  | $ | 294,366 |  |  | $ | 103,791 |  |
| Services & Support |  |  | 85,870 |  |  |  | 51,031 |  |  |  | 32,190 |  |  |  | 13,031 |  |
| Total |  | $ | 651,290 |  |  | $ | 180,361 |  |  | $ | 326,556 |  |  | $ | 116,822 |  |

[0000950170-23-042449:notes:234]
For the three months ended June 30, 2023 and 2022, $1.5 million and $0.2 million, respectively, of depreciation expense was included in gross profit for our Network Solutions segment. For the six months ended June 30, 2023 and 2022, $2.9 million and $0.5 million, respectively, of depreciation expense was included in gross profit for our Network Solutions segment. For the three months ended June 30, 2023 and 2022, $2 thousand and $3 thousand, respectively, of depreciation expense was included in gross profit for our Services & Support segment. For the six months ended June 30, 2023 and 2022, $5 thousand and $6 thousand, respectively, of depreciation expense was included in gross profit for our Services & Support segment.

[0000950170-23-042449:notes:235]
In addition to its reportable segments, revenue is also reported for the following three categories – Subscriber Solutions, Access & Aggregation Solutions and Optical Networking Solutions.

[0000950170-23-042449:notes:236]
Prior to the Business Combination with Adtran Networks on July 15, 2022, ADTRAN reported revenue across the following three categories: (1) Access & Aggregation, (2) Subscriber Solutions & Experience and (3) Traditional & Other Products. Following the Business Combination with Adtran Networks, the Company has recast these revenues such that ADTRAN’s former Access & Aggregation revenue is combined with a portion of the applicable Adtran Networks solutions to create Access & Aggregation Solutions, ADTRAN’s former Subscriber Solutions & Experience revenue is combined with a portion of the applicable Adtran Networks solutions to create Subscriber Solutions, and the revenue from Traditional & Other products is now included in the applicable Access & Aggregation Solutions or Subscriber Solutions category. Optical Networking Solutions is a new revenue category added to represent a meaningful portion of Adtran Networks' portfolio.

[0000950170-23-042449:notes:237]
[same as prior period, unchanged from 0000950170-23-020333:notes:230]

[0000950170-23-042449:notes:238]
[same as prior period, unchanged from 0000950170-23-020333:notes:231]

[0000950170-23-042449:notes:239]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| United States |  | $ | 132,294 |  |  | $ | 105,752 |  |  | $ | 263,760 |  |  | $ | 204,801 |  |
| Germany |  |  | 75,538 |  |  |  | 14,859 |  |  |  | 151,824 |  |  |  | 25,376 |  |
| United Kingdom |  |  | 52,071 |  |  |  | 28,838 |  |  |  | 109,468 |  |  |  | 59,243 |  |
| Other international |  |  | 67,475 |  |  |  | 22,589 |  |  |  | 126,238 |  |  |  | 37,136 |  |
| Total |  | $ | 327,378 |  |  | $ | 172,038 |  |  | $ | 651,290 |  |  | $ | 326,556 |  |


## us-gaap:ProductWarrantyDisclosureTextBlock

[0000950170-23-042449:notes:240]
[same as prior period, unchanged from 0000950170-23-020333:notes:233]

[0000950170-23-042449:notes:241]
The Company's products generally include warranties of 90 days to five years for product defects. The Company accrues for warranty returns at the time of product shipment based on its historical return rate and estimate of the cost to repair or replace the defective products. The Company engages in extensive product quality programs and processes, including actively monitoring and evaluating the quality of its component suppliers. The increasing complexity of the Company's products may cause warranty incidences, when they arise, to be more costly. Estimates regarding future warranty obligations may change due to product failure rates, material usage and other rework costs incurred in correcting a product failure. In addition, from time to time, specific warranty accruals may be recorded if unforeseen problems arise. Should the Company's actual experience relative to these factors be worse than its estimates, the Company will be required to record additional warranty expense. The liability for warranty obligations totaled $6.8 million and $7.2 million as of June 30, 2023 and December 31, 2022, respectively, and is included in accrued expenses and other liabilities in the Condensed Consolidated Balance Sheets. The warranty expense and write-off activity for the three and six months ended June 30, 2023 and 2022 are summarized as follows:

[0000950170-23-042449:notes:242]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Balance at beginning of period |  | $ | 7,200 |  |  | $ | 5,143 |  |  | $ | 7,196 |  |  | $ | 5,403 |  |
| Plus: Amounts charged to cost and expenses |  |  | 459 |  |  |  | 814 |  |  |  | 1,539 |  |  |  | 1,111 |  |
| Plus: Foreign currency translation adjustments |  |  | 14 |  |  |  | — |  |  |  | 40 |  |  |  | — |  |
| Less: Deductions |  |  | (842 | ) |  |  | (1,115 | ) |  |  | (1,944 | ) |  |  | (1,672 | ) |
| Balance at end of period |  | $ | 6,831 |  |  | $ | 4,842 |  |  | $ | 6,831 |  |  | $ | 4,842 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0000950170-23-042449:notes:243]
20. COMMITMENTS AND CONTINGENCIES

[0000950170-23-042449:notes:244]
Legal Matters

[0000950170-23-042449:notes:245]
From time to time the Company is subject to or otherwise involved in various lawsuits, claims, investigations and legal proceedings that arise out of or are incidental to the conduct of our business (collectively, “Legal Matters”), including those relating to employment matters, patent rights, regulatory compliance matters, stockholder claims, and contractual and other commercial disputes. Such Legal Matters, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Additionally, an unfavorable outcome in a legal matter, including in a patent dispute, could require the Company to pay damages, entitle claimants to other relief, such as royalties, or could prevent the Company from selling some of its products in certain jurisdictions. At this time, the Company is unable to predict the outcome of or estimate the possible loss or range of loss, if any, associated with such legal matters.

[0000950170-23-042449:notes:246]
Adtran Networks Legal Matter

[0000950170-23-042449:notes:247]
On May 8, 2023, ADVA and its subsidiary, ADVA Optical Networking North America, Inc. filed a lawsuit in the U.S District Court for the Eastern District of Texas (“EDTX”) against Huawei Technologies Co. Ltd (“Huawei”) seeking a declaration from the court that Huawei violated its commitments to negotiate in good faith and to license standard essential patents (“SEPs”), to the extent any SEPs are practiced by Adtran Networks, on Fair, Reasonable and Non-Discriminatory (“FRAND”) terms and conditions. The case also seeks to obtain a ruling by the court that Adtran Networks has complied with its own commitments and requests that the Court establish FRAND terms and conditions for obtaining a FRAND license on any SEPs to the extend they are practiced by Adtran Networks. The lawsuit also seeks to enjoin Huawei from enforcing five Huawei patents that Adtran Networks considers invalid and/or not practiced, and that Huawei has infringed an Adtran Networks patent. Adtran Networks expects Huawei to respond to the action in August 2023 and expects a trial to be scheduled for the second half of 2024. On July 20, 2023, ADVA Optical Networking SE ("ADVA Germany") was served with a complaint filed by Huawei against ADVA Germany in the District Court München I, Germany, alleging that certain of its products infringe upon one of Huawei’s patents. ADVA Germany's response in the case is due in November 2023, and the filing of a separate nullity action to invalidate the patent is also available in Germany. The Company intends to continue to vigorously defend its interests; however, these matters are subject to many uncertainties, and an adverse outcome in any one of these matters could potentially have a materially adverse impact on the Company's financial position, results of operations and cash flows. Given the current status of these matters, the Company is unable to predict the outcome of or estimate the possible loss or range of loss, if any, associated with such legal matters.

[0000950170-23-042449:notes:248]
DPLTA Exit and Recurring Compensation Costs

[0000950170-23-042449:notes:249]
Pursuant to the terms of the DPLTA, each Adtran Networks shareholder (other than the Company) has received an offer to elect either (1) to remain an Adtran Networks shareholder and receive from us an Annual Recurring Compensation payment, or (2) to receive Exit Compensation plus guaranteed interest. The guaranteed interest under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid.  The guaranteed interest rate is 5% plus a variable component that was 1.62% as of June 30, 2023. Assuming all the minority holders of currently outstanding Adtran Networks shares were to elect the second option, we would be obligated to make aggregate Exit Compensation payments, including guaranteed interest, of approximately €319.0 million or approximately $348.1 million, based on an exchange rate as of June 30, 2023 and reflecting interest accrued through June 30, 2023 at a rate of 5.0% in addition to the variable base interest rate according to the German Civil Code (currently 3.12%) during the pendency of the appraisal proceedings discussed below. Shareholders electing the first option of Annual Recurring Compensation may later elect the second option. The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that have been initiated in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger).

[0000950170-23-042449:notes:250]
Our obligation to pay Annual Recurring Compensation under the DPLTA is a continuing payment obligation, which will amount to approximately €10.6 million or $11.6 million (based on the current exchange rate) per year assuming none of the minority Adtran Networks shareholders were to elect Exit Compensation. The foregoing amounts do not reflect any potential increase in payment obligations that we may have depending on the outcome of ongoing appraisal proceedings in Germany. During the three and six months ended June 30, 2023, we accrued $2.9 million and $5.7 million in Annual Recurring Compensation, which was reflected as a reduction to retained (deficit) earnings, respectively.

[0000950170-23-042449:notes:251]
For the three and six months ended June 30, 2023, a total of approximately 46 thousand shares and 63 thousand shares, respectively, of Adtran Networks stock was tendered to the Company and Exit Compensation payments of approximately €0.8 million and €1.1 million, respectively, or approximately $0.9 million and $1.2 million, respectively, based on an exchange rate as of June 30, 2023, were paid to Adtran Networks shareholders.

[0000950170-23-042449:notes:252]
Performance Bonds

[0000950170-23-042449:notes:253]
Certain contracts, customers and jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of June 30, 2023 and December 31, 2022, we had commitments related to these bonds totaling $12.2 million and $22.0 million, respectively, which expire at various dates through April 2031. In general, we would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which we believe is remote.

[0000950170-23-042449:notes:254]
Purchase Commitments

[0000950170-23-042449:notes:255]
The Company purchases components from a variety of suppliers and use contract manufacturers to provide manufacturing services for our products. Our inventory purchase commitments are for short-term product manufacturing requirements as well as for commitments to suppliers to secure manufacturing capacity. Certain of our inventory purchase commitments with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. As of June 30, 2023, purchase commitments totaled $377.4 million.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0000950170-23-042449:notes:256]
[same as prior period, unchanged from 0000950170-23-020333:notes:246]

[0000950170-23-042449:notes:257]
During the fourth quarter of 2022, the Company initiated a restructuring program designed to optimize the assets and business processes, and information technology systems of the Company in relation to the Business Combination with Adtran Networks. The restructuring program is expected to maximize cost synergies by realizing operation scale, combining sales channels, streamlining corporate and general and administrative functions, including human capital resources and combining sourcing and production costs. This restructuring program is expected to be completed in late 2024.

[0000950170-23-042449:notes:258]
In February 2019, the Company announced the restructuring of a certain portion of its workforce predominantly in Germany, which included the closure of a subsidiary's office location in Munich, Germany accompanied by relocation or severance benefits for the affected employees. Voluntary early retirement was offered to certain other employees and was announced in March 2019 and again in August 2020. This plan was completed in 2021 and all amounts were paid in 2022.

[0000950170-23-042449:notes:259]
A reconciliation of the beginning and ending restructuring liability, which is included in accrued wages and benefits in the Condensed Consolidated Balance Sheets as of June 30, 2023 and December 31, 2022, is as follows:

[0000950170-23-042449:notes:260]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
| (In thousands) |  | June 30, 2023 |  |  | June 30, 2023 |  |
| Balance at beginning of period |  | $ | 1,022 |  |  | $ | 159 |  |
| Plus: Amounts charged to cost and expense |  |  | 5,868 |  |  |  | 8,305 |  |
| Less: Amounts paid |  |  | (438 | ) |  |  | (2,012 | ) |
| Balance as of June 30, 2023 |  | $ | 6,452 |  |  | $ | 6,452 |  |

[0000950170-23-042449:notes:261]
[same as prior period, unchanged from 0000950170-23-020333:notes:251]

[0000950170-23-042449:notes:262]
Restructuring expenses included in the Condensed Consolidated Statements of (Loss) Income are for the three and six months ended June 30, 2023 and 2022:

[0000950170-23-042449:notes:263]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Network Solutions - Cost of revenue |  | $ | — |  |  | $ | — |  |  | $ | 58 |  |  | $ | — |  |
| Services & Support - Cost of revenue |  |  | — |  |  |  | — |  |  |  | 18 |  |  |  | — |  |
| Cost of revenue |  | $ | — |  |  | $ | — |  |  | $ | 76 |  |  | $ | — |  |
| Selling, general and administrative expenses (1) |  |  | 1,393 |  |  |  | — |  |  |  | 3,573 |  |  |  | 2 |  |
| Research and development expenses (1) |  |  | 4,475 |  |  |  | — |  |  |  | 4,656 |  |  |  | — |  |
| Total restructuring expenses |  | $ | 5,868 |  |  | $ | — |  |  | $ | 8,305 |  |  | $ | 2 |  |

[0000950170-23-042449:notes:264]
The following table represents the components of restructuring expense by geographic area for the three and six months ended June 30, 2023 and 2022:

[0000950170-23-042449:notes:265]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| United States |  | $ | 1,501 |  |  | $ | — |  |  | $ | 2,619 |  |  | $ | 2 |  |
| International |  |  | 4,367 |  |  |  | — |  |  |  | 5,686 |  |  |  | — |  |
| Total restructuring expenses |  | $ | 5,868 |  |  | $ | — |  |  | $ | 8,305 |  |  | $ | 2 |  |


## us-gaap:SubsequentEventsTextBlock

[0000950170-23-042449:notes:266]
22. SUBSEQUENT EVENTS

[0000950170-23-042449:notes:267]
Dividend Approval

[0000950170-23-042449:notes:268]
On August 6, 2023, the Company announced that its Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to the Company’s stockholders of record as of the close of business on August 21, 2023. The payment date will be September 5, 2023 in the aggregate amount of approximately $7.1 million.

[0000950170-23-042449:notes:269]
Wells Fargo Credit Agreement Amendment

[0000950170-23-042449:notes:270]
On August 9, 2023, the Company, its wholly-owned direct subsidiary, ADTRAN, Inc., the lenders party thereto and the Administrative Agent entered into a First Amendment to the Credit Agreement (the “First Amendment”).

[0000950170-23-042449:notes:271]
The First Amendment, among other things, provides for:

[0000950170-23-042449:notes:272]
•
a new $50 million delayed draw term loan A tranche (“DDTL”), which is available for borrowing in the event of the purchase by the Company of at least sixty percent (60%) of the outstanding shares of Adtran Networks that are not currently owned by the Company (such event, a “Springing Covenant Event”). Proceeds of the DDTL may only be used to repurchase minority shares of Adtran Networks. The DDTL remains available for borrowing from the occurrence of a Springing Covenant Event through the period that is three consecutive fiscal quarters thereafter;

[0000950170-23-042449:notes:273]
•
a revised applicable margin, which varies based on consolidated total net leverage ratio and ranges from, (a) in the case of revolving loans, (i) 1.65%, with respect to term SOFR loans, to 2.65%, (ii) 1.75%, with respect to EURIBOR loans, to 2.75% and (iii) 0.65%, with respect to base rate loans (including swingline loans) to 1.65%, and (b) in the case of term loans, ranging from (i) 1.90%, with respect to term SOFR loans, to 2.90% and (ii) 0.90%, with respect to Base Rate Loans, to 1.90% (each as defined in the First Amendment to the Credit Agreement);

[0000950170-23-042449:notes:274]
•
a revised commitment fee, which varies based on consolidated total net leverage ratio and ranges from 0.20% to 0.25% per annum on the average daily unused portion of the revolving credit commitment of the revolving credit lenders (other than the defaulting lenders, if any) (each as defined in the credit agreement); and

[0000950170-23-042449:notes:275]
•
revised financial covenants, including (i) the addition of an automatic step up in the consolidated total net leverage ratio to 5.00:1.00 from 3.25:1.00 upon the occurrence of a Springing Covenant Event and continuing for the fiscal quarter in which the Springing Covenant Event occurs and the next three consecutive fiscal quarters thereafter (such period, a “Springing Covenant Period”) and (ii) the addition of a consolidated senior secured net leverage ratio covenant to be tested quarterly during a Springing Covenant Period and sized at 4.00:1.00 during the first quarter ending after a Springing Covenant Event, 3.75:1.00 during the second quarter ending after a Springing Covenant Event and 3.50:1.00 during the third and fourth quarters ending after a Springing Covenant Event. Further, if the Company or any of its subsidiaries incurs unsecured indebtedness under the uncapped general indebtedness basket or permitted convertible indebtedness basket of the Credit Agreement in excess of $50 million in connection with a transaction that is a Springing Covenant Event or during a Springing Covenant Period, then the maximum consolidated senior secured net leverage ratio shall be, or shall automatically step down to, 3.50:1.00 at the time of such incurrence.

[0000950170-23-042449:notes:276]
The First Amendment further added additional financial flexibility by amending the $30 million external debt capped basket to be an unlimited amount and permitting, subject to certain requirements, the incurrence of convertible indebtedness by the Company in an aggregate principal amount of up to $172.5 million. Any such convertible indebtedness must be incurred in pro forma compliance with the financial covenants in the Credit Agreement, unsecured and otherwise rank junior to borrowings under the Credit Agreement, and have a stated maturity date of at least 91 days after the latest scheduled maturity date of loans and commitments under the Credit Agreement. Net cash proceeds from any incurrence of convertible indebtedness must be used to repurchase minority shares of Adtran Networks or repay revolver borrowings under the Credit Agreement.

[0000950170-23-042449:notes:277]
Lastly, the First Amendment added market environmental, social and governance provisions and extended the required delivery date of the financial statements of the Company and its subsidiaries for the fiscal quarter ended June 30, 2023 to August 18, 2023.
