# ADTN MD&A — 0000950170-23-042449


## mdna

[0000950170-23-042449:mdna:1]
[same as prior period, unchanged from 0000950170-23-020333:mdna:1]

[0000950170-23-042449:mdna:2]
The following discussion should be read in conjunction with the Condensed Consolidated Financial Statements and the related notes that appear in Part I, Item 1 of this document. In addition, the following discussion should be read in conjunction with our audited consolidated financial statements for the year ended December 31, 2022, Part II, Item 7, Management’s Discussion and Analysis of Financial Condition and Results of Operations, and Part I, Item 1A, Risk Factors, included in Amendment No. 1 to our Annual Report on Form 10-K for the year ended December 31, 2022, filed with the SEC on August 14, 2023 (the “2022 Form 10-K/A”), as well as Part I, Item 1, Business, included in our Annual Report on Form 10-K filed with the SEC on March 1, 2023,.

[0000950170-23-042449:mdna:3]
This discussion is designed to provide the reader with information that will assist in understanding our Condensed Consolidated Financial Statements, the changes in certain key items in those financial statements from period to period, and the primary factors that accounted for those changes, as well as how certain accounting principles affect our Condensed Consolidated Financial Statements. See “Cautionary Note Regarding Forward-Looking Statements” on page 4 of this report for a description of important factors that could cause actual results to differ from expected results. See also Part 1, Item 1A, Risk Factors, of the 2022 Form 10‑K/A and Part II, Item 1A, Risk Factors of this Form 10-Q.

[0000950170-23-042449:mdna:4]
Unless the context otherwise indicates or requires, references in this Quarterly Report on Form 10-Q to "ADTRAN", the “Company,” “we,” “us” and “our” refer to ADTRAN Holdings, Inc. and its consolidated subsidiaries for periods subsequent to the Merger and to ADTRAN, Inc. and its consolidated subsidiaries for periods prior to the Merger. The prior period results do not include the results of Adtran Networks prior to the Business Combination.

[0000950170-23-042449:mdna:5]
[same as prior period, unchanged from 0000950170-23-020333:mdna:5]

[0000950170-23-042449:mdna:6]
[same as prior period, unchanged from 0000950170-23-020333:mdna:6]

[0000950170-23-042449:mdna:7]
On May 24, 2023, at the annual general meeting of the shareholders of ADVA Optical Networking SE, a subsidiary of the Company ("ADVA"), the shareholders of ADVA approved the proposed change of its name to Adtran Networks SE ("Adtran Networks"), which was registered in the commercial register of the local court of Jena, Germany on June 8, 2023. Unless the context otherwise indicates or requires, references in this Quarterly Report on Form 10-Q to “Adtran Networks” refer to Adtran Networks SE (formerly ADVA Optical Networking SE).

[0000950170-23-042449:mdna:8]
ADTRAN Holdings, Inc. solely owns ADTRAN, Inc. and is the majority shareholder of Adtran Networks. ADTRAN is a leading global provider of open, disaggregated networking and communications solutions. Adtran Networks is a global provider of network solutions for data, storage, voice and video services. The combined technology portfolio can best address current and future requirements, especially regarding the convergence of solutions at the network edge.

[0000950170-23-042449:mdna:9]
[same as prior period, unchanged from 0000950170-23-020333:mdna:8]

[0000950170-23-042449:mdna:10]
Prior to the Business Combination with Adtran Networks on July 15, 2022, ADTRAN reported revenue across the following three categories: (1) Access & Aggregation, (2) Subscriber Solutions & Experience and (3) Traditional & Other Products. Following the Business Combination with Adtran Networks, we have recast these revenues such that ADTRAN’s former Access & Aggregation revenue is combined with a portion of the applicable Adtran Networks solutions to create Access & Aggregation Solutions, ADTRAN’s former Subscriber Solutions & Experience revenue is combined with a portion of the applicable Adtran Networks solutions to create Subscriber Solutions and the revenue from Traditional & Other products is now included in the applicable Access & Aggregation Solutions or Subscriber Solutions category. Optical Networking Solutions is a new revenue category added to represent a meaningful portion of Adtran Networks portfolio.

[0000950170-23-042449:mdna:11]
[same as prior period, unchanged from 0000950170-23-020333:mdna:10]

[0000950170-23-042449:mdna:12]
[same as prior period, unchanged from 0000950170-23-020333:mdna:11]

[0000950170-23-042449:mdna:13]
[same as prior period, unchanged from 0000950170-23-020333:mdna:12]

[0000950170-23-042449:mdna:14]
46

[0000950170-23-042449:mdna:15]
ADTRAN NETWORKS DOMINATION AND PROFIT AND LOSS TRANSFER AGREEMENT

[0000950170-23-042449:mdna:16]
The DPLTA between the Company, as the controlling company, and Adtran Networks, as the controlled company, which was executed on December 1, 2022, became effective on January 16, 2023, as a result of its registration with the commercial register (Handelsregister) of the local court (Amtsgericht) at the registered seat of Adtran Networks (Jena).

[0000950170-23-042449:mdna:17]
Under the DPLTA, subject to certain limitations pursuant to applicable law and the specific terms of the DPLTA, (i) the Company is
entitled to issue binding instructions to the management board of Adtran Networks, (ii) Adtran Networks will transfer its annual profit to the Company, subject to, among other things, the creation or dissolution of certain reserves, and (iii) the Company will generally absorb the annual net loss incurred by Adtran Networks. The obligation of Adtran Networks to transfer its annual profit to the Company applies for the first time to the profit, if any, generated in the Adtran Networks fiscal year 2023. The obligation of the Company to absorb Adtran Networks annual net loss applies for the first time to the loss, if any, generated in the Adtran Networks fiscal year 2023.

[0000950170-23-042449:mdna:18]
Additionally, and subject to certain limitations pursuant to applicable law and the specific terms of the DPLTA, the DPLTA provides that Adtran Networks shareholders (other than us) be offered, at their election, (i) to put their Adtran Networks shares to the Company in exchange for compensation in cash of €17.21 per share plus guaranteed interest (the "Exit Compensation"), or (ii) to remain Adtran Networks shareholders and receive a recurring compensation in cash of €0.59 (€0.52 net under the current tax regime) per share for each full fiscal year of Adtran Networks (the “Annual Recurring Compensation”). The guaranteed interest component under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid. The guaranteed interest rate is 5% plus a variable component that was 1.62% as of June 30, 2023. The Annual Recurring Compensation is due on the third banking day following the ordinary general shareholders’ meeting of Adtran Networks for the respective preceding fiscal year (but in any event within eight months following expiration of the fiscal year) and is first granted for the 2023 fiscal year, payable for the first time after the ordinary general shareholders’ meeting of Adtran Networks in 2024. The adequacy of both forms of compensation has been challenged by minority shareholders of Adtran Networks via court-led appraisal proceedings under German law, and it is possible that the courts in such appraisal proceedings may adjudicate a higher Exit Compensation or Annual Recurring Compensation (in each case, including interest thereon) than agreed upon in the DPLTA.

[0000950170-23-042449:mdna:19]
The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that have been initiated in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger). For the three and six months ended June 30, 2023, a total of approximately 46 thousand shares and 63 thousand shares, respectively, of Adtran Networks stock was tendered to the Company and Exit Compensation payments of approximately €0.8 million and €1.1 million, respectively, or approximately $0.9 million and $1.2 million, respectively, based on an exchange rate as of June 30, 2023, were paid to Adtran Networks' shareholders.

[0000950170-23-042449:mdna:20]
We currently hold 33,957,538 no-par value bearer shares of Adtran Networks, representing 65.36% of Adtran Networks outstanding shares as of June 30, 2023.

[0000950170-23-042449:mdna:21]
The foregoing description of the DPLTA does not purport to be complete and is qualified in its entirety by reference to the DPLTA, a non-binding English translation of which is incorporated by reference to Exhibit 10.5 of the 2022 Form 10-K/A.

[0000950170-23-042449:mdna:22]
As of June 30, 2023, the Company has incurred $26.2 million of transaction costs related to the Business Combination. During the three and six months ended June 30, 2023, $0.1 million of transaction costs were incurred. During the three and six months ended June 30, 2022, $1.2 million and $2.7 million of transaction costs were incurred, respectively. These transaction costs are recorded in selling, general and administrative expenses in the Consolidated Statements of (Loss) Income.

[0000950170-23-042449:mdna:23]
[same as prior period, unchanged from 0000950170-23-020333:mdna:21]

[0000950170-23-042449:mdna:24]
[same as prior period, unchanged from 0000950170-23-020333:mdna:22]

[0000950170-23-042449:mdna:25]
[same as prior period, unchanged from 0000950170-23-020333:mdna:23]

[0000950170-23-042449:mdna:26]
[same as prior period, unchanged from 0000950170-23-020333:mdna:24]

[0000950170-23-042449:mdna:27]
[same as prior period, unchanged from 0000950170-23-020333:mdna:25]

[0000950170-23-042449:mdna:28]
[same as prior period, unchanged from 0000950170-23-020333:mdna:26]

[0000950170-23-042449:mdna:29]
[same as prior period, unchanged from 0000950170-23-020333:mdna:27]

[0000950170-23-042449:mdna:30]
We have and will continue to invest significant dollars to restructure the workforce, optimize legacy systems, streamline legal entities and consolidate real estate holdings. By executing these integration activities, we expect to deliver greater innovation for customers, career enrichment opportunities for employees, and enhanced value for shareholders. During the three and six months ended June 30, 2023, we recognized $0.6 million and $1.4 million of integration costs related to the Business Combination, respectively, that are

[0000950170-23-042449:mdna:31]
included in selling, general and administrative expenses in the Condensed Consolidated Statement of (Loss) Income. We expect to incur additional integration costs and costs associated with the implementation of the DPLTA during the remainder of 2023 and such costs are expected to be material.

[0000950170-23-042449:mdna:32]
During the three and six months ended June 30, 2023, we recognized $5.9 million and $8.3 million of restructuring costs relating to the Business Combination that are included in cost of revenue, selling, general and administrative expenses and research and development expenses in the Condensed Consolidated Statement of (Loss) Income, respectively. See Note 21 of the Notes to Condensed Consolidated Financial Statements, included in Part I, Item 1 of this report for additional information.

[0000950170-23-042449:mdna:33]
[same as prior period, unchanged from 0000950170-23-020333:mdna:30]

[0000950170-23-042449:mdna:34]
We ended the second quarter of 2023 with a year-over-year revenue increase of 90.3% as compared to the three months ended June 30, 2022, driven by increased volume of sales activity due to the Business Combination with Adtran Networks and to Service Provider customers. During the second quarter of 2023, we had one 10% revenue customer, which was an international Service Provider customer and our five largest customers comprised 39.1% of our revenue. Our year-over-year domestic revenue increased by 25.1%, driven by increased sales volume due to the Business Combination with Adtran Networks and partially offset by decreases due to the macro-economic environment and customers optimizing their inventory, which impacted our Subscriber Solutions product line. Internationally, our year-over-year revenue increased by 194.3%, primarily driven by increased volume of sales activity due to the Business Combination with Adtran Networks and increased shipments to a Tier-1 network operator and multiple alternative network operators in Europe.

[0000950170-23-042449:mdna:35]
Growing customer concerns over inventory stocking levels affected our second quarter Subscriber Solutions category. We believe that this over-supply of CPE products will continue into the third quarter of 2023. Revenue for our Access and Optical Networking products grew sequentially. Supply constraints, however, limited our flexibility to clear past-due backlog across all product categories. We believe that the inventory impact is transitory, and we expect to see some improvement to both the over-supply of CPE products and the backlog of products across all categories in the coming quarters. Despite these challenges, we have maintained our emphasis on product development to enable us to respond to rapidly changing technology and evolving industry standards. For example, public funding through projects such as IPCEI ME/CT will further our research and development for new communication technologies. Additionally, public funding through BEAD is expected to commence in late 2024 to early 2025, which provides a positive outlook for the future.

[0000950170-23-042449:mdna:36]
Our operating results have fluctuated and may continue to fluctuate on a quarterly basis due to several factors, including customer order activity, supply chain constraints, component availability, the Company's consolidation, purchase accounting, and integration with Adtran Networks. Further, a significant percentage of orders require delivery within a few-days requiring us to maintain higher inventory levels. These factors may result in limited order flow visibility. For example, during the recent pandemic and a global semiconductor chip shortage, we experienced disruption and delays in our supply chain and significant price increases with certain of our manufacturing partners. Although, expedite fees and lead times for semiconductor chips and other key components began to ease during the first half of 2023, we continued to be negatively impacted by price increases, which could continue to have a material adverse effect on customer relations and our financial condition. Our operating expenses are relatively fixed in the short term; therefore, a shortfall in quarterly revenues could significantly impact our financial results in a given quarter.

[0000950170-23-042449:mdna:37]
[same as prior period, unchanged from 0000950170-23-020333:mdna:34]

[0000950170-23-042449:mdna:38]
[same as prior period, unchanged from 0000950170-23-020333:mdna:37]

[0000950170-23-042449:mdna:39]
[same as prior period, unchanged from 0000950170-23-020333:mdna:38]

[0000950170-23-042449:mdna:40]
Subsequent to June 30, 2023, the Company has experienced volatility in its stock price which reduced the market value of the Company’s common stock as of this filing.  The Company will continue to monitor its stock price, operating results and other macroeconomic factors to determine if there has been any indication of a sustained decline in fair value requiring an event driven assessment of the recoverability of its goodwill within the third quarter of 2023.

[0000950170-23-042449:mdna:41]
Our historical financial performance is not necessarily a meaningful indicator of future results, and in general, management expects that our financial results may vary from period to period. Factors that could materially affect our business, financial condition or operating results are included in Part I, Item 1A of the 2022 Form 10-K/A and Part II, Item 1A of this Form 10-Q.

[0000950170-23-042449:mdna:42]
[same as prior period, unchanged from 0000950170-23-020333:mdna:40]

[0000950170-23-042449:mdna:43]
[same as prior period, unchanged from 0000950170-23-020333:mdna:41]

[0000950170-23-042449:mdna:44]
49

[0000950170-23-042449:mdna:45]
RESULTS OF OPERATIONS – THREE AND SIX MONTHS ENDED JUNE 30, 2023 COMPARED TO THE THREE AND SIX MONTHS ENDED JUNE 30, 2022

[0000950170-23-042449:mdna:46]
The following table presents selected financial information derived from our Condensed Consolidated Statements of (Loss) Income expressed as a percentage of revenue for the periods indicated. Amounts may not foot due to rounding.

[0000950170-23-042449:mdna:47]
|  |  | Three Months Ended |  |  | Six Months Ended |  |  |
|  |  | June 30, |  |  | June 30, |  |  |
|  |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |  |
| Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Network Solutions |  |  | 86.4 |  | % |  | 90.7 |  | % |  | 86.8 |  | % |  | 90.1 |  | % |
| Services & Support |  |  | 13.6 |  |  |  | 9.3 |  |  |  | 13.2 |  |  |  | 9.9 |  |  |
| Total Revenue |  |  | 100.0 |  |  |  | 100.0 |  |  |  | 100.0 |  |  |  | 100.0 |  |  |
| Cost of Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Network Solutions |  |  | 66.3 |  |  |  | 58.1 |  |  |  | 67.0 |  |  |  | 58.4 |  |  |
| Services & Support |  |  | 5.5 |  |  |  | 5.6 |  |  |  | 5.3 |  |  |  | 5.9 |  |  |
| Total Cost of Revenue |  |  | 71.7 |  |  |  | 63.7 |  |  |  | 72.3 |  |  |  | 64.2 |  |  |
| Gross Profit |  |  | 28.3 |  |  |  | 36.3 |  |  |  | 27.7 |  |  |  | 35.8 |  |  |
| Selling, general and administrative expenses |  |  | 20.3 |  |  |  | 16.2 |  |  |  | 20.6 |  |  |  | 17.1 |  |  |
| Research and development expenses |  |  | 21.6 |  |  |  | 15.4 |  |  |  | 21.6 |  |  |  | 16.2 |  |  |
| Operating (Loss) Income |  |  | (13.6 | ) |  |  | 4.7 |  |  |  | (14.5 | ) |  |  | 2.5 |  |  |
| Interest and dividend income |  |  | 0.1 |  |  |  | 0.1 |  |  |  | 0.1 |  |  |  | 0.1 |  |  |
| Interest expense |  |  | (1.2 | ) |  |  | (0.1 | ) |  |  | (1.1 | ) |  |  | — |  |  |
| Net investment gain (loss) |  |  | 0.4 |  |  |  | (2.7 | ) |  |  | 0.4 |  |  |  | (2.5 | ) |  |
| Other income, net |  |  | 0.8 |  |  |  | 0.4 |  |  |  | 0.3 |  |  |  | 0.1 |  |  |
| (Loss) Income Before Income Taxes |  |  | (13.6 | ) |  |  | 2.5 |  |  |  | (14.8 | ) |  |  | 0.2 |  |  |
| Income tax benefit (expense) |  |  | 2.6 |  |  |  | (1.2 | ) |  |  | 3.0 |  |  |  | 0.1 |  |  |
| Net (Loss) Income |  |  | (11.1 | ) | % |  | 1.2 |  | % |  | (11.8 | ) | % |  | 0.3 |  | % |
| Less: Net Loss attributable to non-controlling interest |  |  | (0.9 | ) |  |  | — |  |  |  | (1.4 | ) |  |  | — |  |  |
| Net (Loss) Income attributable to ADTRAN Holdings, Inc. |  |  | (10.2 | ) | % |  | 1.2 |  | % |  | (10.4 | ) | % |  | 0.3 |  | % |

[0000950170-23-042449:mdna:48]
[same as prior period, unchanged from 0000950170-23-020333:mdna:46]

[0000950170-23-042449:mdna:49]
Our revenue increased 90.3% from $172.0 million for the three months ended June 30, 2022 to $327.4 million for the three months ended June 30, 2023 and increased 99.4% from $326.6 million for the six months ended June 30, 2022 to $651.3 million for the six months ended June 30, 2023. The increase in revenue for the three months ended June 30, 2023 is primarily attributable to a $186.7 million increase in volume of sales activity due to the Business Combination with Adtran Networks and partially offset by a $31.4 million decrease in volume of sales activity related to our ADTRAN, Inc. operations. The increase in revenue for the six months ended June 30, 2023 is primarily attributable to a $379.0 million increase in volume of sales activity due to the Business Combination with Adtran Networks partially offset by a $54.3 million decrease in volume of sales activity related to our ADTRAN, Inc. operations. The increase in revenue by category for the three months ended June 30, 2023 was primarily attributable to a $143.0 million increase in Optical Networking Solutions products due to the Business Combination with Adtran Networks, a $10.4 million increase in Access & Aggregation revenue and a $1.9 million increase in Subscriber Solutions products. The increase in revenue by category for the six months ended June 30, 2023 was primarily attributable to a $290.8 million increase in Optical Networking Solutions products due to the Business Combination with Adtran Networks, a $24.5 million increase in Subscriber Solutions products, and a $9.5 million increase in Access & Aggregation Solutions revenue. Growing customer concerns over inventory stocking levels affected our first and second quarter Subscriber Solutions category. We believe that this over-supply of CPE products will continue into the third quarter of 2023. Revenue for our Access and Optical Networking products grew sequentially. Supply constraints, however, limited our flexibility to clear past-due backlog across all product categories. We believe that the inventory impact is transitory, and we expect to see some improvement to both the over-supply of CPE products and the backlog of products across all categories in the coming quarters. We do not see any material changes to our near-term opportunities and our long-term growth catalysts as carriers around the world upgrade their networks to fiber.

[0000950170-23-042449:mdna:50]
Network Solutions segment revenue increased 81.4% from $156.0 million for the three months ended June 30, 2022 to $283.0 million for the three months ended June 30, 2023 and increased 92.1% from $294.4 million for the six months ended June 30, 2022 to $565.4 million for the six months ended June 30, 2023. The increase in Network Solutions revenue for the three months ended June 30, 2023 was due to the increase of $159.9 million in volume of sales activity due to the Business Combination with Adtran Networks, partially offset by a decrease of $31.3 million in Subscriber Solutions products and a decrease of $1.5 million in Access & Aggregation revenue in our ADTRAN, Inc. operations. The increase in revenue for the six months ended June 30, 2023 was due to an increase of $326.9 million in volume of sales activity due to the Business Combination with Adtran Networks, partially offset by a decrease of $42.4 million

[0000950170-23-042449:mdna:51]
in Subscriber Solutions products and a decrease of $13.4 million in Access & Aggregation Solutions in our ADTRAN, Inc. operations. More specifically, the decrease in revenue for the three and six months ended June 30, 2023 of our ADTRAN, Inc. operations was primarily due to lower volume of sales of our residential solutions products.

[0000950170-23-042449:mdna:52]
Services & Support segment revenue increased 176.6% from $16.0 million for the three months ended June 30, 2022 to $44.4 million for the three months ended June 30, 2023 and increased 166.8% from $32.2 million for the six months ended June 30, 2022 to $85.9 million for the six months ended June 30, 2023. The increase in revenue for the three months ended June 30, 2023 was primarily attributable to the increase of $26.9 million in volume of sales activity from the Business Combination with Adtran Networks a $0.8 million increase in revenue for Subscriber Solutions services in our ADTRAN, Inc. operations and a $0.7 million increase in revenue for Access & Aggregation Solutions services in our ADTRAN, Inc. operations. The increase in revenue for the six months ended June 30, 2023 was primarily attributable to the increase of $52.2 million in volume of sales activity from the Business Combination with Adtran Networks and a $1.5 million increase in revenue for Subscriber Solutions services in our ADTRAN, Inc. operations. More specifically, the increase in revenue for the three and six months ended June 30, 2023 of our ADTRAN, Inc. operations was primarily due to higher volume of sales of our software services and business solutions services.

[0000950170-23-042449:mdna:53]
Domestic revenue increased by 25.1% from $105.6 million for the three months ended June 30, 2022 to $132.3 million for the three months ended June 30, 2023 and increased by 28.8% from $204.8 million for the six months ended June 30, 2022 to $263.8 million for the six months ended June 30, 2023, driven by increased volume of network termination and fiber CPE in our Network Solutions segment. In addition, such growth was a result of increased revenue to Tier-2 and Tier-3 customers with diversified businesses among our fiber access and CPE, Service Provider CPE and services.

[0000950170-23-042449:mdna:54]
International revenue, which is defined as revenue generated from the Network Solutions and Services & Support segments provided to a customer outside of the U.S., increased by 194.3% from $66.3 million for the three months ended June 30, 2022 to $195.1 million for the three months ended June 30, 2023 and increased by 218.3% from $121.8 million for the six months ended June 30, 2022 to $387.5 million for the six months ended June 30, 2023. International revenue, as a percentage of total revenue, increased from 38.5% for the three months ended June 30, 2022 to 59.6% for the three months ended June 30, 2023 and increased from 37.3% for the six months ended June 30, 2022 to 59.5% for the six months ended June 30, 2023. The change for the three months ended June 30, 2023 was primarily attributable to a $126.4 million increase in volume of sales activity from the Business Combination with Adtran Networks and increased shipments to a Tier-1 network operator and multiple alternative network operators in Europe. The change for the six months ended June 30, 2023 was primarily attributable to a $256.8 million increase in volume of sales activity from the Business Combination with Adtran Networks and increased shipments to a Tier-1 network operator and multiple alternative network operators in Europe. While international revenue has increased to approximately 59.6% and 59.5% of total revenues for the three and six months ended June 30, 2023, the mix of our Network Solutions and Services & Support segments as a percentage of total international revenue remains relatively linear. For the three and six months ended June 30, 2023 as compared to the three and six months ended June 30, 2022, changes in foreign currencies relative to the U.S. dollar increased our net revenue by approximately $2.6 million and decreased our net revenue by approximately $7.5 million, respectively.

[0000950170-23-042449:mdna:55]
Our ADTRAN, Inc. international revenue is largely focused on broadband infrastructure and is consequently affected by the decisions of our customers as to timing for installation of new technologies, expansion of their networks and/or network upgrades. Our international customers must make these decisions in the regulatory and political environment in which they operate – both nationally and, in some instances, regionally – whether of a multi-country region or a more local region within a country. Consequently, while we expect the global trend towards deployment of more robust broadband speeds and access to continue creating additional market opportunities for us, the factors described above may result in pressure on revenue and operating income. Our Adtran Networks international revenue is largely focused on the manufacture and selling of networking solutions that are based on three core areas of expertise: fiber-optic transmission technology (cloud interconnect), cloud access technology for rapid creation of innovative services around the network edge and solutions for precise timing and synchronization of networks. In addition, Adtran Networks international operations offers a comprehensive portfolio of network design, implementation and maintenance services to assist operators in the deployment of market-leading networks while reducing costs to maintain these networks.

[0000950170-23-042449:mdna:56]
[same as prior period, unchanged from 0000950170-23-020333:mdna:54]

[0000950170-23-042449:mdna:57]
As a percentage of revenue, cost of revenue increased from 63.7% for the three months ended June 30, 2022 to 71.7% for the three months ended June 30, 2023 and increased from 64.2% for the six months ended June 30, 2022 to 72.3% for the six months ended June 30, 2023. The increase for the three and six months ended June 30, 2022 was primarily attributable to $33.4 million and $66.0 million, respectively, of adjustments consisting of intangible amortization of backlog, developed technology and fair value adjustments to inventory costs that flow through to cost of revenue as a result of the Business Combination with Adtran Networks, acquisition related expenses, and to a lesser extent changes in customer and product mix and a regional revenue shift in our ADTRAN, Inc. operations, partially offset by lower freight and expedite fees. As the current inventory that was acquired in the Business Combination with Adtran Networks is sold, we expect that our cost of revenue as a percentage of revenue will return to more normalized levels. For the three and six months ended June 30, 2023 as compared to the three and six months ended June 30, 2022, changes in foreign currencies relative to the U.S. dollar increased our cost of revenue by approximately $0.3 million and decreased our cost of revenue by approximately $1.7 million, respectively. See additional information related to amortization lives and expense in Notes 2 and 10 of Notes to the Condensed Consolidated Financial Statements included in Part I, Item 1 of this report.

[0000950170-23-042449:mdna:58]
Network Solutions cost of revenue, as a percentage of that segment’s revenue, increased from 64.1% for the three months ended June 30, 2022 to 76.7% for the three months ended June 30, 2023 and increased from 64.7% for the six months ended June 30, 2022 to 77.1% for the six months ended June 30, 2023. The increase in cost of revenue as a percentage of revenue for the three and six months ended June 30, 2023 was primarily attributable to acquisition related expenses, amortizations and adjustments consisting of intangible amortization of backlog, developed technology and fair value adjustments to inventory costs that flow through to cost of revenue as a result of the Business Combination with Adtran Networks and to a lesser extent changes in customer and product mix and a regional revenue shift in our ADTRAN, Inc. operations, partially offset by lower freight and expedite fees.

[0000950170-23-042449:mdna:59]
Services & Support cost of revenue, as a percentage of that segment’s revenue, decreased from 59.9% for the three months ended June 30, 2022 to 40.3% for the three months ended June 30, 2023 and decreased from 59.5% for the six months ended June 30, 2022 to 40.6% for the six months ended June 30, 2023. The decrease in cost of revenue as a percentage of revenue for the three and six months ended June 30, 2023 was primarily attributable to customer mix and changes in Services & Support mix as a result of the Business Combination with Adtran Networks.

[0000950170-23-042449:mdna:60]
[same as prior period, unchanged from 0000950170-23-020333:mdna:58]

[0000950170-23-042449:mdna:61]
[same as prior period, unchanged from 0000950170-23-020333:mdna:59]

[0000950170-23-042449:mdna:62]
As a percentage of revenue, gross profit decreased from 36.3% for the three months ended June 30, 2022 to 28.3% for the three months ended June 30, 2023 and decreased from 35.8% for the six months ended June 30, 2022 to 27.7% for the six months ended June 30, 2023. The decrease for the three and six months ended June 30, 2023 was primarily attributable to $33.4 million and $66.0 million, respectively, of adjustments consisting of intangible amortization of backlog, developed technology and fair value adjustments to inventory costs that flow through to cost of revenue as a result of the Business Combination with Adtran Networks, acquisition related expenses and a decrease in volume of sales activity related to our ADTRAN, Inc. operations.

[0000950170-23-042449:mdna:63]
As a percentage of that segment's revenue, Network Solutions gross profit decreased from 35.9% for the three months ended June 30, 2022 to 23.3% for the three months ended June 30, 2023 and decreased from 35.3% for the six months ended June 30, 2022 to 22.9% for the six months ended June 30, 2023. The decrease was primarily attributable to increases in cost of revenue related to acquisition related expenses, adjustments consisting of intangible amortization of backlog, developed technology and fair value adjustments to inventory costs that flow through to cost of revenue as a result of the Business Combination with Adtran Networks and a decrease in volume of sales activity related to our ADTRAN, Inc. operations partially offset by an increase in volume of sales activity due to the Business Combination with Adtran Networks.

[0000950170-23-042449:mdna:64]
As a percentage of that segment's revenue, Services & Support gross profit increased from 40.1% for the three months ended June 30, 2022 to 59.7% for the three months ended June 30, 2023 and increased from 40.5% for the six months ended June 30, 2022 to 59.4% for the six months ended June 30, 2023. The increase was primarily attributable to an increase in volume of sales activity due to the Business Combination with Adtran Networks, an increase in volume of sales activity related to our ADTRAN, Inc. operations and a decrease in cost of revenue attributable to customer mix and changes in Services & Support mix as a result of the Business Combination with Adtran Networks.

[0000950170-23-042449:mdna:65]
[same as prior period, unchanged from 0000950170-23-020333:mdna:64]

[0000950170-23-042449:mdna:66]
As a percentage of revenue, selling, general and administrative expenses increased from 16.2% for the three months ended June 30, 2022 to 20.3% for the three months ended June 30, 2023 and increased from 17.1% for the six months ended June 30, 2023 to 20.6% for the six months ended June 30, 2023. While selling, general and administrative expenses as a percentage of revenue will generally fluctuate whenever there is a significant fluctuation in revenue for the periods being compared, in the three and six months ended June 30, 2023 we saw a more significant increase due to increased expenses related to the Business Combination with Adtran Networks and other items described below. Our restructuring and integration programs are in the process of consolidating, streamlining and integrating the workforce, systems and processes of ADTRAN and Adtran Networks, which we expect will lower selling, general and administrative expense as a percentage of revenue over time.

[0000950170-23-042449:mdna:67]
Selling, general and administrative expenses increased 138.9% from $27.9 million for the three months ended June 30, 2022 to $66.6 million for the three months ended June 30, 2023 and increased 140.3% from $55.8 million for the six months ended June 30, 2022 to $134.0 million for the six months ended June 30, 2023. Although selling, general and administrative expenses include personnel costs for management, accounting, information technology, human resources, sales and marketing, as well as independent auditor, tax and other professional fees, contract services and legal and litigation related costs. The increase in selling, general and administrative expenses for the three and six months ended June 30, 2023 was primarily attributable to increased expenses related to the Business Combination with Adtran Networks such as employee-related costs due to an increase in the number of employees, costs related to our restructuring program, amortization of intangible assets, depreciation of property, plant and equipment, restructuring expenses, stock-based compensation expense and transactions costs. For the three and six months ended June 30, 2023 as compared to the three and six months ended June 30, 2022, changes in foreign currencies relative to the U.S dollar increased our selling, general and administrative expenses by approximately $0.2 million and decreased our selling, general and administrative expenses by approximately $1.2 million, respectively.

[0000950170-23-042449:mdna:68]
[same as prior period, unchanged from 0000950170-23-020333:mdna:67]

[0000950170-23-042449:mdna:69]
As a percentage of revenue, research and development expenses increased from 15.4% for the three months ended June 30, 2022 to 21.6% for the three months ended June 30, 2023 and increased from 16.2% for the six months ended June 30, 2022 to 21.6% for the six months ended June 30, 2023. Although, research and development expenses as a percentage of revenue will fluctuate whenever there are incremental product development activities or significant fluctuations in revenue for the periods being compared, in the first half of 2023 we saw a more significant increase due to increased expenses related to the Business Combination with Adtran Networks and other items described below. Our restructuring and integration programs are in the process of consolidating, streamlining and integrating the workforce, systems and processes of ADTRAN and Adtran Networks, which we expect will lower research and development expense as a percentage of revenue over time.

[0000950170-23-042449:mdna:70]
Research and development expenses increased 166.4% from $26.5 million for the three months ended June 30, 2022 to $70.6 million for the three months ended June 30, 2023 and increased 165.6% from $53.0 million for the six months ended June 30, 2022 to $140.7 million for the six months ended June 30, 2023. The increase in research and development expenses was primarily attributable to increased expenses related to the Business Combination with Adtran Networks such as employee-related costs due to an increase in the number of employees and expenses related to our multi-year integration program, restructuring expenses, amortization of intangible assets, depreciation of property, plant and equipment and stock-based compensation expense. For the three and six months ended June 30, 2023 as compared to the three and six months ended June 30, 2022, changes in foreign currencies relative to the U.S. dollar increased our research and development expenses by approximately $0.1 million and decreased our research and development expenses by approximately $2.1 million, respectively.

[0000950170-23-042449:mdna:71]
Adtran Networks has arrangements with governmental entities for the purpose of obtaining funding for research and development activities. The Company classifies government grants received under these arrangements as a reduction to research and development expense incurred. For the three and six months ended June 30, 2023, the Company recognized $0.9 million and $1.5 million as a reduction of research and development expense, respectively.

[0000950170-23-042449:mdna:72]
[same as prior period, unchanged from 0000950170-23-020333:mdna:71]

[0000950170-23-042449:mdna:73]
[same as prior period, unchanged from 0000950170-23-020333:mdna:72]

[0000950170-23-042449:mdna:74]
Interest and dividend income increased from $0.2 million for the three months ended June 30, 2022 to $0.4 million for the three months ended June 30, 2023 and increased from $0.4 million for the six months ended June 30, 2022 to $0.7 million for the six months ended June 30, 2023. Interest and dividend income was up due to increased income related to the Business Combination with Adtran Networks for the three and six months ended June 30, 2023.

[0000950170-23-042449:mdna:75]
[same as prior period, unchanged from 0000950170-23-020333:mdna:74]

[0000950170-23-042449:mdna:76]
Interest expense increased from $0.1 million for the three months ended June 30, 2022 to $4.1 million for the three months ended June 30, 2023 and increased from $0.1 million for the six months ended June 30, 2022 to $7.4 million for the six months ended June 30, 2023. The increase in interest expense during the three and six months ended June 30, 2023 was primarily related to an increase in the  Wells Fargo Credit Agreement and the assumed debt associated with the Business Combination with Adtran Networks. See Note 12 and Note 13 of the Notes to Condensed Consolidated Financial Statements, included in Part I, Item 1 of this report.

[0000950170-23-042449:mdna:77]
[same as prior period, unchanged from 0000950170-23-020333:mdna:76]

[0000950170-23-042449:mdna:78]
We recognized a net investment loss of $4.6 million and a gain of $1.3 million for the three months ended June 30, 2022 and 2023, respectively and recognized a net investment loss of $8.1 million and a gain of $2.5 million for the six months ended June 30, 2022 and 2023, respectively. The fluctuations in our net investments were primarily attributable to changes in the fair value of our securities recognized during the period. We expect that any future market volatility could result in continued fluctuations in our investment portfolio. See Note 6 of the Notes to Condensed Consolidated Financial Statements, included in Part I, Item 1 of this report, and “Investing Activities” in “Liquidity and Capital Resources” below for additional information.

[0000950170-23-042449:mdna:79]
OTHER INCOME, NET

[0000950170-23-042449:mdna:80]
Other expense, net, which primarily consisted of gains and losses on foreign currency transactions and income from excess material sales, increased from income of $0.7 million for the three months ended June 30, 2022 to income of $2.5 million for the three months ended June 30, 2023 and increased from income of $0.5 million for the six months ended June 30, 2022 to income of $2.2 million for the six months ended June 30, 2023.

[0000950170-23-042449:mdna:81]
INCOME TAX BENEFIT (EXPENSE)

[0000950170-23-042449:mdna:82]
The Company's effective tax rate changed from an expense of 50.1% of pre-tax income for the three months ended June 30, 2022, to a benefit of 18.8% of pre-tax income for the three months ended June 30, 2023 and changed from a benefit of 34.3% of pre-tax income for the six months ended June 30, 2022, to a benefit of 20.4% of pre-tax income for the six months ended June 30, 2023. In 2022, we benefited from a change in our annual estimated tax rate as a result of the requirement to begin capitalizing research and development expenses for U.S. tax purposes beginning in 2022 as previously passed as part of the Tax Cuts and Jobs Act in December 2017, and the associated impact of those changes on our previously established valuation allowance. The change in the effective tax rate for the three and six months ended June 30, 2023, was driven primarily by a change in our estimated tax rate as a result of the closing of the Business Combination with Adtran Networks during the third quarter of 2022 as well as the release of our domestic valuation allowance during the fourth quarter of 2022.

[0000950170-23-042449:mdna:83]
NET (LOSS) INCOME ATTRIBUTABLE TO ADTRAN HOLDINGS, INC.

[0000950170-23-042449:mdna:84]
As a result of the above factors, net (loss) income attributable to ADTRAN Holdings, Inc. decreased from net income of $2.1 million for the three months ended June 30, 2022 to a net loss of $33.3 million for the three months ended June 30, 2023 and decreased from net income of $1.0 million for the six months ended June 30, 2022 to a net loss of $67.8 million for the six months ended June 30, 2023. Upon the DPLTA becoming effective on January 16, 2023, the Company began absorbing all Adtran Networks losses rather than just the loss related to the Company's ownership percentage in Adtran Networks.

[0000950170-23-042449:mdna:85]
[same as prior period, unchanged from 0000950170-23-020333:mdna:84]

[0000950170-23-042449:mdna:86]
We have historically financed our ongoing business with existing cash, investments and cash flow from operations. In the current supply environment we also expect to utilize our credit arrangements to manage our working capital needs. We have used, and expect to continue to use, existing cash, investments, credit arrangements and cash generated from operations for working capital, business acquisitions, shareholder dividends and other general corporate purposes, including product development activities to enhance our existing products and develop new products, expand our sales and marketing activities and fund capital expenditures.

[0000950170-23-042449:mdna:87]
Pursuant to the terms of the DPLTA, each Adtran Networks shareholder (other than the Company) has received an offer to elect either (1) to remain an Adtran Networks shareholder and receive from us an Annual Recurring Compensation payment, or (2) to receive Exit Compensation plus guaranteed interest. The guaranteed interest under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid. The guaranteed interest rate is 5% plus a variable component that was 1.62% as of June 30, 2023. Assuming all the minority holders of currently outstanding Adtran Networks shares were to elect the second option, we would be obligated to make aggregate Exit Compensation payments, including guaranteed interest, of approximately €319.0 million or approximately $348.1 million, based on an exchange rate as of June 30, 2023 and reflecting interest accrued through June 30, 2023 at a rate of 5.0% in addition to the variable base interest rate according to the German Civil Code (currently 3.12%) during the pendency of the appraisal proceedings discussed below. Shareholders electing the first option of Annual Recurring Compensation may later elect the second option. The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that have been initiated in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger).

[0000950170-23-042449:mdna:88]
We are also obligated to absorb any annual net loss of Adtran Networks under the DPLTA. Additionally, our obligation to pay Annual Recurring Compensation under the DPLTA is a continuing payment obligation, which will amount to approximately €10.6 million or $11.6 million (based on the current exchange rate) per year assuming none of the minority Adtran Networks shareholders were to elect Exit Compensation. The foregoing amounts do not reflect any potential increase in payment obligations that we may have depending on the outcome of ongoing appraisal proceedings in Germany. During the three and six months ended June 30, 2023, we accrued $2.9 million and $5.7 million in Annual Recurring Compensation, which was reflected as a reduction to retained (deficit) earnings, respectively. For the three and six months ended June 30, 2023, a total of approximately 46 thousand shares and 63 thousand shares, respectively, of Adtran Networks stock was tendered to the Company and Exit Compensation payments of approximately €0.8 million and €1.1 million, respectively, or approximately $0.9 million and $1.2 million, respectively, based on an exchange rate as of June 30, 2023, were paid to Adtran Networks shareholders.

[0000950170-23-042449:mdna:89]
As of June 30, 2023, the Company does not have sufficient liquidity to meet payment obligations under the DPLTA pertaining to Exit Compensation assuming a substantial majority of Adtran Networks shareholders elect such option in the current period. We believe the probability that a substantial majority of Adtran Networks shareholders elect to receive Exit Compensation in the next twelve months is remote based on the diverse base of shareholders that must make this election on an individual shareholder basis, the current ongoing appraisal proceedings involving a dispute on the value of the Exit Compensation which is expected to take 24-36 months to resolve, the current guaranteed Annual Recurring Compensation payment plus the interest earned on such shares during the ongoing appraisal proceedings, and the current trading value of Adtran Networks SE shares.

[0000950170-23-042449:mdna:90]
Therefore, we believe that our cash and cash equivalents, investments, working capital management initiatives and access to funds under the Wells Fargo credit facility, including the August 9, 2023, $50 million term loan amendment, (described below) will be adequate to meet our operating and capital needs and our obligations under the  DPLTA, including potential Exit Compensation, for at least the next 12 months, although we may need to suspend payment of dividends, reduce capital expenditures and/or take other steps to preserve working capital in order to ensure that we can meet such needs and obligations.

[0000950170-23-042449:mdna:91]
[same as prior period, unchanged from 0000950170-23-020333:mdna:124]

[0000950170-23-042449:mdna:92]
On July 18, 2022, ADTRAN Holdings, Inc. and ADTRAN, Inc., as the borrower, entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (the “Credit Agreement”). The Credit Agreement allowed for borrowings of up to $100.0 million in aggregate principal amount, but the borrowings increased to up to $400.0 million in aggregate principal amount upon the DPLTA becoming effective on January 16, 2023. The Credit Agreement matures in July 2027, but provides the Company with an option to request extensions subject to customary conditions.

[0000950170-23-042449:mdna:93]
As of June 30, 2023, ADTRAN, Inc.’s outstanding borrowings under the revolving line of credit were $200.0 million. The Credit Agreement matures in July 2027 but provides the Company with an option to request extensions subject to customary conditions. In addition, we may issue up to $25.0 million in letters of credit against our $400.0 million total facility. As of June 30, 2023, we had a total of $2.2 million in letters of credit outstanding against our eligible borrowings, leaving a net amount of $197.8 million available for future borrowings. Any future credit extensions under the Credit Agreement are subject to customary conditions precedent, including a net leverage ratio financial covenant and a material adverse effect condition. In consideration of the factors described above in respect of expected timing of payment of the Exit Compensation and our assessment of compliance with these  covenants we believe that we will have access to sufficient funding to meet any obligations that come due under the terms of the DPLTA in the next 12 months from the date of issuance of these condensed consolidated financial statements.

[0000950170-23-042449:mdna:94]
Wells Fargo Credit Agreement Amendment

[0000950170-23-042449:mdna:95]
On August 9, 2023, the Company, its wholly-owned direct subsidiary, ADTRAN, Inc., the lenders party thereto and Wells Fargo Bank, National Association, as administrative agent and as collateral agent, entered into a First Amendment to the Credit Agreement (the “First Amendment”).

[0000950170-23-042449:mdna:96]
The First Amendment, among other things, provides for:

[0000950170-23-042449:mdna:97]
•
a new $50 million delayed draw term loan A tranche (“DDTL”), which is available for borrowing in the event of the purchase by the Company of at least sixty percent (60%) of the outstanding shares of Adtran Networks that are not currently owned by the Company (such event, a “Springing Covenant Event”). Proceeds of the DDTL may only be used to repurchase minority shares of Adtran Networks. The DDTL remains available for borrowing from the occurrence of a Springing Covenant Event through the period that is three consecutive fiscal quarters thereafter;

[0000950170-23-042449:mdna:98]
•
a revised applicable margin, which varies based on consolidated total net leverage ratio and ranges from, (a) in the case of revolving loans, (i) 1.65%, with respect to term SOFR loans, to 2.65%, (ii) 1.75%, with respect to EUIBOR loans, to 2.75% and (iii) 0.65%, with respect to base rate loans (including swingline loans) to 1.65%, and (b) in the case of term loans, ranging from (i) 1.90%, with respect to term SOFR loans, to 2.90% and (ii) 0.90%, with respect to Base Rate Loans, to 1.90% (each as defined in the First Amendment to the Credit Agreement);

[0000950170-23-042449:mdna:99]
•
a revised commitment fee, which varies based on consolidated total net leverage ratio and ranges from 0.20% to 0.25% per annum on the average daily unused portion of the revolving credit commitment of the revolving credit lenders (other than the defaulting lenders, if any) (each as defined in the credit agreement); and

[0000950170-23-042449:mdna:100]
•
revised financial covenants, including (i) the addition of an automatic step up in the consolidated total net leverage ratio to 5.00:1.00 from 3.25:1.00 upon the occurrence of a Springing Covenant Event and continuing for the fiscal quarter in which the Springing Covenant Event occurs and the next three consecutive fiscal quarters thereafter (such period, a “Springing Covenant Period”) and (ii) the addition of a consolidated senior secured net leverage ratio covenant to be tested quarterly during a Springing Covenant Period and sized at 4.00:1.00 during the first quarter ending after a Springing Covenant Event, 3.75:1.00 during the second quarter ending after a Springing Covenant Event and 3.50:1.00 during the third and fourth quarters ending after a Springing Covenant Event. Further, if the Company or any of its subsidiaries incurs unsecured indebtedness under the uncapped general indebtedness basket or permitted convertible indebtedness basket of the Credit Agreement in excess of $50 million in connection with a transaction that is a Springing Covenant Event or during a Springing Covenant Period, then the maximum consolidated senior secured net leverage ratio shall be, or shall automatically step down to, 3.50:1.00 at the time of such incurrence.

[0000950170-23-042449:mdna:101]
The First Amendment further added additional financial flexibility by amending the $30 million external debt capped basket to be an unlimited amount and permitting, subject to certain requirements, the incurrence of convertible indebtedness by the Company in an aggregate principal amount of up to $172.5 million. Any such convertible indebtedness must be incurred in pro forma compliance with the financial covenants in the Credit Agreement, unsecured and otherwise rank junior to borrowings under the Credit Agreement, and have a stated maturity date of at least 91 days after the latest scheduled maturity date of loans and commitments under the Credit Agreement. Net cash proceeds from any incurrence of convertible indebtedness must be used to repurchase minority shares of Adtran Networks or repay revolver borrowings under the Credit Agreement.

[0000950170-23-042449:mdna:102]
Lastly, the First Amendment added market environmental, social and governance provisions and extended the required delivery date of the financial statements of the Company and its subsidiaries for the fiscal quarter ended June 30, 2023 to August 18, 2023.

[0000950170-23-042449:mdna:103]
As of June 30, 2023, our cash on hand was $124.3 million and short-term investments were $3.1 million, which resulted in available short-term liquidity of $127.4 million, of which $86.3 million was held by our foreign subsidiaries. As of December 31, 2022, cash on hand was $108.6 million and short-term investments were $0.3 million, which resulted in available short-term liquidity of $108.9 million, of which $86.3 million was held by our foreign subsidiaries. Generally, we intend to permanently reinvest funds held outside the U.S., except to the extent that any of these funds can be repatriated without withholding tax.

[0000950170-23-042449:mdna:104]
In addition to our cash and cash equivalents and the credit facility, we may fund a portion or all of the Exit Compensation through the sale of securities or additional alternative funding sources, if available. There can be no assurances that we would be successful in effecting these actions on commercially reasonable terms or at all. If we cannot raise additional funds as needed, it could have a material adverse impact on our financial results and financial condition.

[0000950170-23-042449:mdna:105]
[same as prior period, unchanged from 0000950170-23-020333:mdna:91]

[0000950170-23-042449:mdna:106]
Net cash used in operating activities of $36.2 million during the six months ended June 30, 2023 increased by $30.2 million compared to net cash used in operating activities of $5.9 million during the six months ended June 30, 2022. This increase in net cash used was primarily due to the net loss for the period, for the reasons discussed above, as adjusted primarily for depreciation and deferred taxes, and net cash outflows from working capital, specifically, a decrease in the average number of days payable to our trade suppliers. Additional details related to our working capital and its drivers are discussed below.

[0000950170-23-042449:mdna:107]
Net accounts receivable decreased 14.3% from $279.4 million as of December 31, 2022 to $239.6 million as of June 30, 2023. There was an allowance for credit losses of less than $0.1 million as of June 30, 2023 and an allowance for credit losses of less than $0.1 million as of December 31, 2022. The decrease in net accounts receivable was due primarily to customer and geographical mix. Quarterly accounts receivable DSO decreased from 72 days as of December 31, 2022 to 67 days as of June 30, 2023. The decrease in DSO was

[0000950170-23-042449:mdna:108]
due to customer and geographical mix associated with the Business Combination with Adtran Networks and timing of sales within the quarter.

[0000950170-23-042449:mdna:109]
Other receivables decreased 1.3% from $32.8 million as of December 31, 2022 to $32.4 million as of June 30, 2023. The decrease in other receivables was primarily attributable to a decrease for sales of raw materials.

[0000950170-23-042449:mdna:110]
Quarterly inventory turnover was 2.5 turns as of December 31, 2022 and 2.3 turns as of June 30, 2023. Inventory decreased 2.5% from $427.5 million as of December 31, 2022 to $416.8 million as of June 30, 2023. The decrease in inventory was due to a reduction in component purchases due to improved lead times as well as utilization of buffer stock. We expect inventory levels to fluctuate as we attempt to maintain sufficient inventory in response to supply chain uncertainties.

[0000950170-23-042449:mdna:111]
Accounts payable decreased 27.8% from $237.7 million as of December 31, 2022 to $171.7 million as of June 30, 2023. The decrease in accounts payable was primarily due to a decrease in the average number of days payable to our trade suppliers. Accounts payable will fluctuate due to variations in the timing of the receipt of inventory, supplies and services and our subsequent payments for these purchases.

[0000950170-23-042449:mdna:112]
[same as prior period, unchanged from 0000950170-23-020333:mdna:97]

[0000950170-23-042449:mdna:113]
Capital expenditures totaled approximately $20.1 million and $3.3 million for the six months ended June 30, 2023 and 2022, respectively. These expenditures were primarily used to purchase manufacturing and test equipment, software, computer hardware and building improvements.

[0000950170-23-042449:mdna:114]
Our combined short-term and long-term investments increased $1.3 million from $33.0 million as of December 31, 2022 to $34.3 million as of June 30, 2023. This increase reflects the impact of the net unrealized and realized gains and losses on our investments.

[0000950170-23-042449:mdna:115]
[same as prior period, unchanged from 0000950170-23-020333:mdna:100]

[0000950170-23-042449:mdna:116]
As of June 30, 2023, our corporate bonds, municipal bonds, asset-backed bonds, mortgage/agency bonds, U.S. government bonds and other government bonds were classified as available-for-sale and had a combined duration of 15 years with an average Standard & Poor’s credit rating of AA. Because our investment portfolio has a high-quality rating and contractual maturities of short duration, we are able to obtain prices for these bonds derived from observable market inputs, or for similar securities traded in an active market, on a daily basis.

[0000950170-23-042449:mdna:117]
Our long-term investments decreased 4.4% from $32.7 million as of December 31, 2022 to $31.2 million as of June 30, 2023. Our investments include various marketable equity securities classified as long-term investments with a fair market value of $0.9 million and $0.8 million as of June 30, 2023 and December 31, 2022, respectively. Our investments include various available-for-sale debt securities classified as long-term investments with a fair market value of $8.1 million and $9.3 million as of June 30, 2023 and December 31, 2022. Long-term investments as of June 30, 2023 and December 31, 2022 also included $25.4 million and $22.9 million, respectively, related to our deferred compensation plans.

[0000950170-23-042449:mdna:118]
[same as prior period, unchanged from 0000950170-23-020333:mdna:104]

[0000950170-23-042449:mdna:119]
[same as prior period, unchanged from 0000950170-23-020333:mdna:105]

[0000950170-23-042449:mdna:120]
During the six month periods ended June 30, 2023 and 2022, we paid dividends totaling $14.2 million and $8.9 million, respectively. The continued payment of dividends is at the discretion of the Company’s Board of Directors and is subject to general business conditions and ongoing financial results of the Company.

[0000950170-23-042449:mdna:121]
[same as prior period, unchanged from 0000950170-23-020333:mdna:107]

[0000950170-23-042449:mdna:122]
There were no stock repurchases during the periods ended June 30, 2023 and 2022, and there currently is no authorized stock repurchase program.

[0000950170-23-042449:mdna:123]
[same as prior period, unchanged from 0000950170-23-020333:mdna:109]

[0000950170-23-042449:mdna:124]
To accommodate employee stock option exercises, the Company issued 6 thousand and 37 thousand shares of common stock and treasury stock which resulted in proceeds of $58 thousand and $0.6 million during the six months ended June 30, 2023 and 2022, respectively. Additionally, to accommodate Adtran Networks SE stock option exercises, Adtran Networks issued 13 thousand shares of Adtran Networks common stock which resulted in proceeds of $0.1 million, for the six months ended June 30, 2023. Adtran Networks SE stock options outstanding as of June 30, 2023 totaled 68 thousand (representing less than 0.2% of Adtran Networks outstanding shares), of which 13 thousand were exercisable.

[0000950170-23-042449:mdna:125]
[same as prior period, unchanged from 0000950170-23-020333:mdna:111]

[0000950170-23-042449:mdna:126]
We have exposure to credit losses from off-balance sheet exposures, to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds, where we believe the risk of loss is immaterial to our financial statements as of June 30, 2023. Otherwise, we do not have off-balance sheet financing arrangements and have not engaged in any related party transactions or arrangements with unconsolidated entities or other persons that are reasonably likely to materially affect liquidity or the availability of or requirements for capital resources. See Note 20 of the Notes to Condensed Consolidated Financial Statements, included in Part I, Item 1 of this report for additional information.

[0000950170-23-042449:mdna:127]
[same as prior period, unchanged from 0000950170-23-020333:mdna:113]

[0000950170-23-042449:mdna:128]
The following table summarizes the Company’s material short- and long-term cash requirements from known obligations pursuant to certain contracts and commitments as of June 30, 2023, as well as an estimate of the timing in which such obligations and payments are expected to be satisfied (but excluding payments that may be made pursuant to the DPLTA and currency hedging arrangements, which are discussed below). Other than operating lease obligations, the cash requirements table excludes interest payments.

[0000950170-23-042449:mdna:129]
| (In thousands) |  | Total |  |  | 2023 |  |  | 2024 |  |  | 2025 |  |  | 2026 |  |  | 2027 |  |  | After 2027 |  |
| Wells Fargo credit agreement(1) |  | $ | 200,000 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 200,000 |  |  | $ | — |  |
| Nord/LB revolving line of credit(2) |  |  | 10,912 |  |  |  | 10,912 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Purchase obligations(3) |  |  | 377,427 |  |  |  | 308,708 |  |  |  | 62,976 |  |  |  | 5,736 |  |  |  | 7 |  |  |  | — |  |  |  | — |  |
| Operating lease obligations(4) |  |  | 32,499 |  |  |  | 4,662 |  |  |  | 8,658 |  |  |  | 7,159 |  |  |  | 4,506 |  |  |  | 2,950 |  |  |  | 4,564 |  |
| Totals |  | $ | 620,838 |  |  | $ | 324,282 |  |  | $ | 71,634 |  |  | $ | 12,895 |  |  | $ | 4,513 |  |  | $ | 202,950 |  |  | $ | 4,564 |  |

[0000950170-23-042449:mdna:130]
[same as prior period, unchanged from 0000950170-23-020333:mdna:116]

[0000950170-23-042449:mdna:131]
[same as prior period, unchanged from 0000950170-23-020333:mdna:117]

[0000950170-23-042449:mdna:132]
[same as prior period, unchanged from 0000950170-23-020333:mdna:118]

[0000950170-23-042449:mdna:133]
[same as prior period, unchanged from 0000950170-23-020333:mdna:119]

[0000950170-23-042449:mdna:134]
[same as prior period, unchanged from 0000950170-23-020333:mdna:120]

[0000950170-23-042449:mdna:135]
[same as prior period, unchanged from 0000950170-23-020333:mdna:121]

[0000950170-23-042449:mdna:136]
[same as prior period, unchanged from 0000950170-23-020333:mdna:122]

[0000950170-23-042449:mdna:137]
locations. Our operating leases had remaining lease terms ranging from once month to 113 months as of June 30, 2023.

[0000950170-23-042449:mdna:138]
Wells Fargo Credit Agreement

[0000950170-23-042449:mdna:139]
On July 18, 2022, ADTRAN Holdings, Inc. and ADTRAN, Inc., as the borrower, entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (the “Credit Agreement”). The Credit Agreement allowed for borrowings of up to $100 million in aggregate principal amount, but the borrowings increased to up to $400.0 million in aggregate principal amount upon the DPLTA becoming effective on January 16, 2023.

[0000950170-23-042449:mdna:140]
As of June 30, 2023, ADTRAN, Inc.’s borrowings under the revolving line of credit were $200.0 million. The Credit Agreement matures in July 2027 but provides the Company with an option to request extensions subject to customary conditions. In addition, we may issue up to $25.0 million in letters of credit against our $400.0 million dollar total facility. As of June 30, 2023, we had a total of $2.2 million in letters of credit under ADTRAN, Inc. outstanding against our eligible borrowings, leaving a net amount of $197.8 million available for future borrowings. Any future credit extensions under the Credit Agreement are subject to customary conditions precedent. Any future credit extensions under the Credit Agreement are subject to customary conditions precedent. The proceeds of any loans are expected to be used for general corporate purposes and to pay a portion of the Exit Compensation consideration.

[0000950170-23-042449:mdna:141]
All U.S. borrowings under the Credit Agreement (other than swingline loans, which bear interest at the Base Rate (as defined below)) bear interest, at the Company’s option, at a rate per annum equal to (A)(i) the highest of (a) the federal funds rate (i.e., for any day, the rate per annum equal to the weighted average of the rates on overnight federal funds transactions with members of the Federal Reserve System, as published by the Federal Reserve Bank of New York on the business day next succeeding such day) plus ½ of 1%, (b) the prime commercial lending rate of the Administrative Agent, as established from time to time at its principal U.S. office (which such rate is an index or base rate and will not necessarily be its lowest or best rate charged to its customers or other banks), and (c) the daily Adjusted Term SOFR (as defined in the Credit Agreement) for a one-month tenor plus 1%, plus (ii) the applicable rate, ranging from 0.5% to 1.25% (the “Base Rate”), or (B) the sum of the Adjusted Term SOFR (as defined in the Credit Agreement) plus the applicable rate, ranging from 1.4% to 2.15%, provided that such sum is subject to a 0.0% floor (such loans utilizing this interest rate, “SOFR Loans”). All E.U. borrowings under the Credit Agreement (other than swingline loans) bear interest at a rate per annum equal to the sum of the Euro Interbank Offered Rate as administered by the European Money Markets Institute (or a comparable or successor administrator approved by the Administrative Agent) plus the applicable rate, ranging from 1.5% to 2.25%, provided that such sum is subject to a 0.0% floor (such loans utilizing this interest rate, “EURIBOR Loans”). The applicable rate is based on the consolidated net leverage ratio of the Company and its subsidiaries as determined pursuant to the terms of the Credit Agreement. Default interest is 2.00% per annum in excess of the rate otherwise applicable in the case of any overdue principal or any other overdue amount.

[0000950170-23-042449:mdna:142]
In addition to paying interest on outstanding principal under the Credit Agreement, the Company is required to pay a commitment fee to the lenders under the Credit Agreement in respect of unutilized revolving loan commitments and an additional commitment ticking fee at a rate of 0.25% on the commitment amounts of each lender until the earliest of (i) the date of the Senior Credit Facilities Increase, (ii) the Company’s voluntary termination of the credit facility commitment, and (iii) December 31, 2023. The Company is also required to pay a participation fee to the Administrative Agent for the account of each lender with respect to the Company’s participation in letters of credit at the then applicable rate for SOFR Loans.

[0000950170-23-042449:mdna:143]
The Credit Agreement permits the Company to prepay any or all of the outstanding loans or to reduce the commitments under the Credit Agreement without incurring premiums or penalties (except breakage costs with respect to SOFR Loans and EURIBOR Loans). The Credit Agreement contains customary affirmative and negative covenants, including incurrence covenants and certain other limitations on the ability of the Company and the Company’s subsidiaries to incur additional debt, guarantee other obligations, grant liens on assets, make investments, dispose of assets, pay dividends or other payments on capital stock, make restricted payments, engage in mergers or consolidations, engage in transactions with affiliates, modify its organizational documents, and enter into certain restrictive agreements. It also contains customary events of default (subject to customary cure periods and materiality thresholds). Furthermore, the Credit Agreement requires that the Consolidated Total Net Leverage Ratio (as defined in the Credit Agreement) of the Company and its subsidiaries tested on the last day of each fiscal quarter not exceed 3.25 to 1.0 through September 30, 2024 and 2.75 to 1.00 from December 31, 2024 and thereafter, subject to certain exceptions. The Credit Agreement also requires that the Consolidated Interest Coverage Ratio (as defined in the Credit Agreement) of the Company and its subsidiaries tested on the last day of each fiscal quarter not fall below 3.00 to 1.00.

[0000950170-23-042449:mdna:144]
[same as prior period, unchanged from 0000950170-23-020333:mdna:130]

[0000950170-23-042449:mdna:145]
[same as prior period, unchanged from 0000950170-23-020333:mdna:131]

[0000950170-23-042449:mdna:146]
On March 29, 2023, Adtran Networks entered into a $16.1 million unsecured revolving line of credit with Norddeutsche Landesbark - Girozentrale (Nord/LB) that bears interest of Euro Short Term Rate plus 1.94%. The line of credit has a perpetual term that can be terminated by the Company or Nord/LB at any time. As of June 30, 2023, Adtran Networks borrowed $10.9 million under this facility.

[0000950170-23-042449:mdna:147]
[same as prior period, unchanged from 0000950170-23-020333:mdna:133]

[0000950170-23-042449:mdna:148]
On November 3, 2022, the Company entered into a Euro/U.S. forward contract arrangement (the “Initial Forward”) with Wells Fargo Bank, N.A. (the “Hedge Counterparty”). The Initial Forward, which is governed by the provisions of an ISDA Master Agreement (including schedules thereto and transaction confirmations that supplement such agreement) entered into between the Company and the Hedge Counterparty, enables the Company to convert a portion of its Euro denominated payment obligations under the DPLTA into U.S. Dollars. Under the Initial Forward, the Company agreed to exchange an aggregate notional amount of $160.0 million U.S. dollars for Euros at a daily fixed forward rate ranging from $0.98286 to $1.03290. The aggregate amount of $160.0 million is divided into eight quarterly tranches of $20.0 million, commencing in the fourth quarter of 2022. The Company, at its sole discretion, may exchange all

[0000950170-23-042449:mdna:149]
or part of each tranche on any given day within the applicable quarter; provided, however, that it must exchange the full tranche by the end of such quarter. The Initial Forward may be accelerated or terminated early for a number of reasons, including but not limited to (i) non-payment by the Company or the Hedge Counterparty, (ii) breach of representation or warranty or covenant by either party or (iii) insolvency or bankruptcy of either party.

[0000950170-23-042449:mdna:150]
On March 21, 2023, the Company entered into a Euro/U.S. dollar forward contract arrangement (the “Forward”) with Wells Fargo Bank, N.A. (the “Hedge Counterparty”). Under the Forward, which is governed by the provisions of an ISDA Master Agreement (including schedules thereto and transaction confirmations that supplement such agreement) entered into between the Company and the Hedge Counterparty, the Company will exchange an aggregate notional amount of $160.0 million U.S. dollars for Euros at a daily fixed forward rate of $1.085 per €1.00 in average. During the six months ended June 30, 2023, the Company settled two $20.0 million forward contract tranches and the remaining will be divided into six quarterly tranches of $20.0 million. These new forward contracts transacted on March 21, 2023 (to sell EUR/buy USD) were entered into for the purpose of unwinding the previously transacted forward contracts (to buy EUR/sell USD), transacted in November 2022. The drawdown dates of the original ratchet forwards are set to the same date as the maturity of the new offsetting forward contracts.

[0000950170-23-042449:mdna:151]
60

[0000950170-23-042449:mdna:152]
Adtran Networks Domination and Profit and Loss Transfer Agreement

[0000950170-23-042449:mdna:153]
On December 1, 2022, we, as the controlling company, entered into the DPLTA with Adtran Networks, as the controlled company. The DPLTA, which was executed on December 1, 2022, became effective on January 16, 2023, as a result of its registration with the commercial register (Handelsregister) of the local court (Amtsgericht) at the registered seat of Adtran Networks (Jena).

[0000950170-23-042449:mdna:154]
Under the DPLTA, subject to certain limitations pursuant to applicable law, (i) we are entitled to issue binding instructions to the management board of Adtran Networks, (ii) Adtran Networks will transfer all of its annual profits to us, subject to, among other things, the creation or dissolution of certain reserves, and (iii) we will generally absorb all annual losses incurred by Adtran Networks. The obligation of Adtran Networks to transfer its annual profit to us, as well as our obligation to absorb Adtran Networks annual net loss, applies for the first time to the profits or losses generated in the Adtran Networks fiscal year 2023.

[0000950170-23-042449:mdna:155]
Additionally, and subject to certain limitations pursuant to applicable law and the specific terms of the DPLTA, the DPLTA provides that Adtran Networks shareholders (other than us) be offered, at their election, (i) to put their Adtran Networks shares to the Company in exchange for compensation in cash of €17.21 per share plus guaranteed interest (the "Exit Compensation"), or (ii) to remain Adtran Networks shareholders and receive a recurring compensation in cash of €0.59 (€0.52 net under the current tax regime) per share for each full fiscal year of Adtran Networks (the “Annual Recurring Compensation”). The guaranteed interest component under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid.  The guaranteed interest rate is 5% plus a variable component that was 1.62% as of June 30, 2023.  The Annual Recurring Compensation is due on the third banking day following the ordinary general shareholders’ meeting of Adtran Networks for the respective preceding fiscal year (but in any event within eight months following expiration of the fiscal year) and is first granted for the 2023 fiscal year, payable for the first time after the ordinary general shareholders’ meeting of Adtran Networks in 2024. The adequacy of both forms of compensation have been challenged by minority shareholders of Adtran Networks via court-led appraisal proceedings under German law, and it is possible that the courts in such appraisal proceedings may adjudicate a higher Exit Compensation or Annual Recurring Compensation (in each case, including interest thereon) than agreed upon in the DPLTA. Our aggregate potential payment obligations under the DPLTA are discussed above under "Liquidity".

[0000950170-23-042449:mdna:156]
The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that have been initiated in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger).

[0000950170-23-042449:mdna:157]
We currently hold 33,957,538 no-par value bearer shares of Adtran Networks, representing 65.36% of Adtran Networks outstanding shares as of June 30, 2023.

[0000950170-23-042449:mdna:158]
The foregoing description of the DPLTA does not purport to be complete and is qualified in its entirety by reference to the DPLTA, a non-binding English translation of which incorporated by reference to Exhibit 10.5 of the 2022 Form 10-K/A.

[0000950170-23-042449:mdna:159]
As of June 30, 2023, the Company has incurred $26.2 million of transaction costs related to the Business Combination. During the three and six months ended June 30, 2023, $0.1 million of transaction costs were incurred. During the three and six months ended June 30, 2022, $1.2 million and $2.7 million of transaction costs were incurred, respectively.

[0000950170-23-042449:mdna:160]
During the three and six months ended June 30, 2023, we recognized $0.6 million and $1.4 million of integration costs related to the Business Combination, respectively, that are included in selling, general and administrative expenses in the Condensed Consolidated Statement of (Loss) Income. We expect to incur additional integration costs and costs associated with the implementation of the DPLTA during the remainder of 2023 and such costs are expected to be material.

[0000950170-23-042449:mdna:161]
During the three and six months ended June 30, 2023, we recognized $5.9 million and $8.3 million of restructuring costs relating to the Business Combination, respectively, that are included in cost of revenue, selling, general and administrative expenses and research and development expenses in the Condensed Consolidated Statement of (Loss) Income. See Note 21 of the Notes to Condensed Consolidated Financial Statements, included in Part I, Item 1 of this report for additional information.

[0000950170-23-042449:mdna:162]
[same as prior period, unchanged from 0000950170-23-020333:mdna:146]

[0000950170-23-042449:mdna:163]
During the six months ended June 30, 2023, other than the Exit Compensation payments and Annual Recurring Compensation under the DPLTA, there have been no other material changes in cash requirements from those discussed in the 2022 Form 10-K/A.

[0000950170-23-042449:mdna:164]
[same as prior period, unchanged from 0000950170-23-020333:mdna:148]

[0000950170-23-042449:mdna:165]
Certain contracts, customers and jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of June 30, 2023 and December 31, 2022, we had commitments related to these bonds totaling $12.2 million and $21.1 million, respectively, which expire at various dates through April 2031. In general, we would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which we believe is remote.

[0000950170-23-042449:mdna:166]
[same as prior period, unchanged from 0000950170-23-020333:mdna:150]

[0000950170-23-042449:mdna:167]
An accounting policy is deemed to be critical if it requires an accounting estimate to be made based on assumptions about matters that are highly uncertain at the time the estimate is made, if different estimates reasonably could have been used or if changes in the accounting estimate that are reasonably likely to occur could materially impact the results of financial operations. Several accounting policies, as described in Note 1 of Notes to the Consolidated Financial Statements included in Part I, Item 1 of this report, require material subjective or complex judgment and have a significant impact on our financial condition and results of operations, as applicable. We believe the critical accounting policies affect our more significant judgments and estimates used in the preparation of our Condensed Consolidated Financial Statements. During the six months ended June 30, 2023, other than the change in accounting policy regarding non-controlling interests as outlined in Note 1 and Note 16 to Condensed Consolidated Financial Statements included in Part I, Item 1 of this report, there were no significant changes to our critical accounting policies and estimates as described in the financial statements contained in the 2022 Form 10-K/A.

[0000950170-23-042449:mdna:168]
62
