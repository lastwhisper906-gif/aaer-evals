# ADTN note change history — 0000950170-23-020333 → 0000950170-23-042449


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2023-08-14):
[0000950170-23-042449:note_history:1]
Adtran Networks Legal Matter

- added (2023-08-14):
[0000950170-23-042449:note_history:2]
On May 8, 2023, ADVA and its subsidiary, ADVA Optical Networking North America, Inc. filed a lawsuit in the U.S District Court for the Eastern District of Texas (“EDTX”) against Huawei Technologies Co. Ltd (“Huawei”) seeking a declaration from the court that Huawei violated its commitments to negotiate in good faith and to license standard essential patents (“SEPs”), to the extent any SEPs are practiced by Adtran Networks, on Fair, Reasonable and Non-Discriminatory (“FRAND”) terms and conditions. The case also seeks to obtain a ruling by the court that Adtran Networks has complied with its own commitments and requests that the Court establish FRAND terms and conditions for obtaining a FRAND license on any SEPs to the extend they are practiced by Adtran Networks. The lawsuit also seeks to enjoin Huawei from enforcing five Huawei patents that Adtran Networks considers invalid and/or not practiced, and that Huawei has infringed an Adtran Networks patent. Adtran Networks expects Huawei to respond to the action in August 2023 and expects a trial to be scheduled for the second half of 2024. On July 20, 2023, ADVA Optical Networking SE ("ADVA Germany") was served with a complaint filed by Huawei against ADVA Germany in the District Court München I, Germany, alleging that certain of its products infringe upon one of Huawei’s patents. ADVA Germany's response in the case is due in November 2023, and the filing of a separate nullity action to invalidate the patent is also available in Germany. The Company intends to continue to vigorously defend its interests; however, these matters are subject to many uncertainties, and an adverse outcome in any one of these matters could potentially have a materially adverse impact on the Company's financial position, results of operations and cash flows. Given the current status of these matters, the Company is unable to predict the outcome of or estimate the possible loss or range of loss, if any, associated with such legal matters.

- added (2023-08-14):
[0000950170-23-042449:note_history:3]
DPLTA Exit and Recurring Compensation Costs

- added (2023-08-14):
[0000950170-23-042449:note_history:4]
Pursuant to the terms of the DPLTA, each Adtran Networks shareholder (other than the Company) has received an offer to elect either (1) to remain an Adtran Networks shareholder and receive from us an Annual Recurring Compensation payment, or (2) to receive Exit Compensation plus guaranteed interest. The guaranteed interest under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid.  The guaranteed interest rate is 5% plus a variable component that was 1.62% as of June 30, 2023. Assuming all the minority holders of currently outstanding Adtran Networks shares were to elect the second option, we would be obligated to make aggregate Exit Compensation payments, including guaranteed interest, of approximately €319.0 million or approximately $348.1 million, based on an exchange rate as of June 30, 2023 and reflecting interest accrued through June 30, 2023 at a rate of 5.0% in addition to the variable base interest rate according to the German Civil Code (currently 3.12%) during the pendency of the appraisal proceedings discussed below. Shareholders electing the first option of Annual Recurring Compensation may later elect the second option. The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that have been initiated in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger).

- added (2023-08-14):
[0000950170-23-042449:note_history:5]
Our obligation to pay Annual Recurring Compensation under the DPLTA is a continuing payment obligation, which will amount to approximately €10.6 million or $11.6 million (based on the current exchange rate) per year assuming none of the minority Adtran Networks shareholders were to elect Exit Compensation. The foregoing amounts do not reflect any potential increase in payment obligations that we may have depending on the outcome of ongoing appraisal proceedings in Germany. During the three and six months ended June 30, 2023, we accrued $2.9 million and $5.7 million in Annual Recurring Compensation, which was reflected as a reduction to retained (deficit) earnings, respectively.

- added (2023-08-14):
[0000950170-23-042449:note_history:6]
For the three and six months ended June 30, 2023, a total of approximately 46 thousand shares and 63 thousand shares, respectively, of Adtran Networks stock was tendered to the Company and Exit Compensation payments of approximately €0.8 million and €1.1 million, respectively, or approximately $0.9 million and $1.2 million, respectively, based on an exchange rate as of June 30, 2023, were paid to Adtran Networks shareholders.

- changed (2023-08-14):
[0000950170-23-042449:note_history:7]
Certain contracts, customers and jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of June 30, 2023 and December 31, 2022, we had commitments related to these bonds totaling $12.2 million and $22.0 million, respectively, which expire at various dates through April 2031. In general, we would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which we believe is remote.
  (was, 2023-05-10, similarity 0.9913):
[0000950170-23-020333:note_history:7]
Certain contracts, customers and jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of March 31, 2023 and December 31, 2022, we had commitments related to these bonds totaling $11.7 million and $22.0 million, respectively, which expire at various dates through April 2031. In general, we would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which we believe is remote.

- changed (2023-08-14):
[0000950170-23-042449:note_history:8]
The Company purchases components from a variety of suppliers and use contract manufacturers to provide manufacturing services for our products. Our inventory purchase commitments are for short-term product manufacturing requirements as well as for commitments to suppliers to secure manufacturing capacity. Certain of our inventory purchase commitments with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. As of June 30, 2023, purchase commitments totaled $377.4 million.
  (was, 2023-05-10, similarity 0.9919):
[0000950170-23-020333:note_history:8]
The Company purchases components from a variety of suppliers and use contract manufacturers to provide manufacturing services for our products. Our inventory purchase commitments are for short-term product manufacturing requirements as well as for commitments to suppliers to secure manufacturing capacity. Certain of our inventory purchase commitments with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. As of March 31, 2023, purchase commitments totaled $459.3 million.

- removed (2023-08-14):
[0000950170-23-020333:note_history:9]
DPLTA Exit Costs

- removed (2023-08-14):
[0000950170-23-020333:note_history:10]
Pursuant to the terms of the DPLTA, each ADVA shareholder (other than the Company) has received an offer to elect either (1) to remain an ADVA shareholder and receive from us an Annual Recurring Compensation payment, or (2) to receive Exit Compensation. Assuming all of the minority holders of currently outstanding ADVA shares were to elect the second option, we are obligated to make aggregate Exit Compensation payments of approximately EUR 309.5 million or approximately $335.6 million, based on an exchange rate as of March 31, 2023. Shareholders electing the first option of Annual Recurring Compensation may later elect the second option. The opportunity for outside ADVA shareholders to tender ADVA shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that have been initiated in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger).

- removed (2023-08-14):
[0000950170-23-020333:note_history:11]
Our obligation to pay Annual Recurring Compensation under the DPLTA is a continuing payment obligation, which will amount to approximately EUR 10.5 million or $11.3 million (based on the current exchange rate) per year assuming none of the minority ADVA shareholders were to elect Exit Compensation. The foregoing amounts do not reflect any potential increase in payment obligations that we may have depending on the outcome of ongoing appraisal proceedings in Germany. During the three months ended March 31, 2023, we accrued $2.8 million in Annual Recurring Compensation, which was reflected as a reduction to retained earnings.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- added (2023-08-14):
[0000950170-23-042449:note_history:12]
On May 24, 2023, at the annual general meeting of the shareholders of ADVA Optical Networking SE, a subsidiary of the Company ("ADVA"), the shareholders of ADVA approved the proposed change of its name to Adtran Networks SE ("Adtran Networks"), which was registered in the commercial register of the local court of Jena, Germany on June 8, 2023. Unless the context otherwise indicates or requires, references in this Quarterly Report on Form 10-Q to “Adtran Networks” refer to Adtran Networks SE (formerly ADVA Optical Networking SE).

- added (2023-08-14):
[0000950170-23-042449:note_history:13]
ADTRAN Holdings, Inc. solely owns ADTRAN, Inc. and is the majority shareholder of Adtran Networks. ADTRAN is a leading global provider of open, disaggregated networking and communications solutions. Adtran Networks is a global provider of network solutions for data, storage, voice and video services. The combined technology portfolio can best address current and future requirements, especially regarding the convergence of solutions at the network edge.

- changed (2023-08-14):
[0000950170-23-042449:note_history:14]
The DPLTA between the Company, as the controlling company, and Adtran Networks SE, as the controlled company, as executed on December 1, 2022, became effective on January 16, 2023, as a result of its registration with the commercial register (Handelsregister) of the local court (Amtsgericht) at the registered seat of Adtran Networks (Jena).
  (was, 2023-05-10, similarity 0.9483):
[0000950170-23-020333:note_history:14]
The DPLTA between the Company, as the controlling company, and ADVA Optical Networking SE, as the controlled company as executed on December 1, 2022, became effective on January 16, 2023, as a result of its registration with the commercial register (Handelsregister) of the local court (Amtsgericht) at the registered seat of ADVA (Jena).

- added (2023-08-14):
[0000950170-23-042449:note_history:15]
Under the DPLTA, subject to certain limitations pursuant to applicable law and the specific terms of the DPLTA, (i) the Company is entitled to issue binding instructions to the management board of Adtran Networks, (ii) Adtran Networks will transfer its annual profit to the Company, subject to, among other things, the creation or dissolution of certain reserves, and (iii) the Company will generally absorb the annual net loss incurred by Adtran Networks. The obligation of Adtran Networks to transfer its annual profit to the Company applies for the first time to the profit, if any, generated in the Adtran Networks fiscal year 2023. The obligation of the Company to absorb Adtran Networks annual net loss applies for the first time to the loss, if any, generated in the Adtran Networks fiscal year 2023.

- added (2023-08-14):
[0000950170-23-042449:note_history:16]
Pursuant to the terms of the DPLTA, each Adtran Networks shareholder (other than the Company) has received an offer to elect either (1) to remain an Adtran Networks shareholder and receive from us an Annual Recurring Compensation payment, or (2) to receive Exit Compensation plus guaranteed interest. The guaranteed interest under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid. The guaranteed interest rate is 5% plus a variable component that was 1.62% as of June 30, 2023. Assuming all the minority holders of currently outstanding Adtran Networks shares were to elect the second option, we would be obligated to make aggregate Exit Compensation payments, including guaranteed interest, of approximately €319.0 million or approximately $348.1 million, based on an exchange rate as of June 30, 2023 and reflecting interest accrued through June 30, 2023 at a rate of 5.0% in addition to the variable base interest rate according to the German Civil Code (currently 3.12%) during the pendency of the appraisal proceedings discussed below. Shareholders electing the first option of Annual Recurring Compensation may later elect the second option. The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that have been initiated in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger).

- added (2023-08-14):
[0000950170-23-042449:note_history:17]
We are also obligated to absorb any annual net loss of Adtran Networks under the DPLTA. Additionally, our obligation to pay Annual Recurring Compensation under the DPLTA is a continuing payment obligation, which will amount to approximately €10.6 million or $11.6 million (based on the current exchange rate) per year assuming none of the minority Adtran Networks shareholders were to elect Exit Compensation. The foregoing amounts do not reflect any potential increase in payment obligations that we may have depending on the outcome of ongoing appraisal proceedings in Germany. During the three and six months ended June 30, 2023, we accrued $2.9 million and $5.7 million in Annual Recurring Compensation, which was reflected as a reduction to retained (deficit) earnings, respectively. For the three and six months ended June 30, 2023, a total of approximately 46 thousand shares and 63 thousand shares, respectively, of Adtran Networks stock was tendered to the Company and Exit Compensation payments of approximately €0.8 million and €1.1 million, respectively, or approximately $0.9 million and $1.2 million, respectively, based on an exchange rate as of June 30, 2023, were paid to Adtran Networks shareholders.

- added (2023-08-14):
[0000950170-23-042449:note_history:18]
As of June 30, 2023, and as of the date of issuance of these financial statements, the Company does not have sufficient liquidity to meet payment obligations under the DPLTA pertaining to Exit Compensation assuming a substantial majority of Adtran Networks shareholders elect such option in the current period. We believe the probability that a substantial majority of Adtran Networks shareholders elect to receive Exit Compensation in the next twelve months is remote based on the diverse base of shareholders that must make this election on an individual shareholder basis, the current ongoing appraisal proceedings involving a dispute on the value of the Exit Compensation which is expected to take 24-36 months to resolve, the current guaranteed Annual Recurring Compensation payment plus the interest earned on such shares during the ongoing appraisal proceedings, and the current trading value of Adtran Networks SE shares.

- added (2023-08-14):
[0000950170-23-042449:note_history:19]
Therefore, we believe that our cash and cash equivalents, investments, working capital management initiatives and access to funds under the Wells Fargo credit facility, including additional funding provided for under the First Amendment to the Wells Fargo credit facility that was signed on August 9, 2023, (described below and as recently expanded) will be adequate to meet our operating and capital needs and our obligations under the DPLTA, including potential Exit Compensation, for at least the next 12 months, from the issuance of these financial statements, although we may need to suspend payment of dividends, reduce capital expenditures and/or take other steps to preserve working capital in order to ensure that we can meet such needs and obligations.

- added (2023-08-14):
[0000950170-23-042449:note_history:20]
On July 18, 2022, ADTRAN Holdings, Inc. and ADTRAN, Inc., as the borrower, entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (the “Credit Agreement”). The Credit Agreement allowed for borrowings of up to $100.0 million in aggregate principal amount, but the borrowings increased to up to $400.0 million in aggregate principal amount upon the DPLTA becoming effective on January 16, 2023. The Credit Agreement matures in July 2027, but provides the Company with an option to request extensions subject to customary conditions.

- added (2023-08-14):
[0000950170-23-042449:note_history:21]
On August 9, 2023, the Company, its wholly-owned direct subsidiary, ADTRAN, Inc., the lenders party thereto and Wells Fargo Bank, National Association, as administrative agent and as collateral agent, entered into a First Amendment to Credit Agreement (the “First Amendment”), which amended the Credit Agreement. See Note 22, Subsequent Events, for additional information.

- changed (2023-08-14):
[0000950170-23-042449:note_history:22]
Board Approval Purchase of Adtran Networks Common Stock
  (was, 2023-05-10, similarity 0.8687):
[0000950170-23-020333:note_history:22]
Board Approval Purchase of ADVA Common Stock

- added (2023-08-14):
[0000950170-23-042449:note_history:23]
On October 18, 2022, the Company's Board of Directors authorized the Company to purchase additional shares of Adtran Networks through open market purchases not to exceed 15,346,544 shares. For the three and six months ended June 30, 2023, a total of approximately 46 thousand shares and 63 thousand shares, respectively, of Adtran Networks stock was tendered to the Company and Exit Compensation payments of approximately €0.8 million and €1.1 million, respectively, or approximately $0.9 million and $1.2 million, respectively, based on an exchange rate as of June 30, 2023 were paid to Adtran Networks' shareholders.

- changed (2023-08-14):
[0000950170-23-042449:note_history:24]
In the opinion of management, all adjustments necessary to fairly state these interim statements have been recorded and are of a normal and recurring nature. The results of operations for an interim period are not necessarily indicative of the results for the full year. The interim financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in Amendment No. 1 to the ADTRAN Holdings, Inc. Annual Report on Form 10-K for the year ended December 31, 2022, filed with the SEC on August 14, 2023.
  (was, 2023-05-10, similarity 0.9679):
[0000950170-23-020333:note_history:24]
In the opinion of management, all adjustments necessary to fairly state these interim statements have been recorded and are of a normal and recurring nature. The results of operations for an interim period are not necessarily indicative of the results for the full year. The interim financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in ADTRAN Holdings, Inc. Annual Report on Form 10-K for the year ended December 31, 2022, filed with the SEC on March 1, 2023.

- changed (2023-08-14):
[0000950170-23-042449:note_history:25]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenue and expense during the reporting period. Significant estimates include allowance for credit losses on accounts receivable and contract assets, excess and obsolete inventory reserves, warranty reserves, customer rebates, determination and accrual of the deferred revenue related to performance obligations under contracts with customers, estimated costs to complete obligations associated with deferred and accrued revenues and network installations, estimated income tax provision and income tax contingencies, fair value of stock-based compensation, assessment of goodwill and other intangibles for impairment, estimated lives of intangible assets, estimates of intangible assets upon measurement, estimated pension liability and fair value of investments and estimated contingent liabilities. Actual amounts could differ significantly from these estimates.
  (was, 2023-05-10, similarity 0.9839):
[0000950170-23-020333:note_history:25]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenue and expense during the reporting period. Significant estimates include allowance for credit losses on accounts receivable and contract assets, excess and obsolete inventory reserves, warranty reserves, customer rebates, determination and accrual of the deferred revenue related to performance obligations under contracts with customers, estimated costs to complete obligations associated with deferred and accrued revenues and network installations, estimated income tax provision and income tax contingencies, fair value of stock-based compensation, assessment of goodwill and other intangibles for impairment, estimated lives of intangible assets, estimates of intangible assets upon measurement, estimated pension liability and fair value of investments. Actual amounts could differ significantly from these estimates.

- changed (2023-08-14):
[0000950170-23-042449:note_history:26]
We assessed certain accounting matters that generally require consideration of forecasted financial information in context with the information reasonably available to us and the unknown future impacts of supply chain constraints, inflationary pressures, the energy crisis, currency fluctuations and political tensions as of June 30, 2023, and through the date of this report. The accounting matters assessed included, but were not limited to, the allowance for credit losses, stock-based compensation, carrying value of goodwill, intangibles and other long-lived assets, financial assets, valuation allowances for tax assets, revenue recognition and costs of revenue. Future conditions related to supply chain constraints, inflationary pressures, the energy crisis, rising interest rates, instability in the financial services industry, currency fluctuations and political tensions could result in further impacts to the Company's consolidated financial statements in future reporting periods.
  (was, 2023-05-10, similarity 0.9954):
[0000950170-23-020333:note_history:26]
We assessed certain accounting matters that generally require consideration of forecasted financial information in context with the information reasonably available to us and the unknown future impacts of supply chain constraints, inflationary pressures, the energy crisis, currency fluctuations and political tensions as of March 31, 2023 and through the date of this report. The accounting matters assessed included, but were not limited to, the allowance for credit losses, stock-based compensation, carrying value of goodwill, intangibles and other long-lived assets, financial assets, valuation allowances for tax assets, revenue recognition and costs of revenue. Future conditions related to supply chain constraints, inflationary pressures, the energy crisis, rising interest rates, instability in the financial services industry, currency fluctuations and political tensions could result in further impacts to the Company's consolidated financial statements in future reporting periods.

- changed (2023-08-14):
[0000950170-23-042449:note_history:27]
As of June 30, 2023 and December 31, 2022, the Adtran Networks stockholders’ equity ownership percentage in Adtran Networks was approximately 34.6% and 34.7%, respectively.
  (was, 2023-05-10, similarity 0.8789):
[0000950170-23-020333:note_history:27]
As of March 31, 2023 and December 31, 2022, the ADVA stockholders’ equity ownership percentage in ADVA was approximately 34.6% and 34.7%, respectively.

- added (2023-08-14):
[0000950170-23-042449:note_history:28]
As a result of the effectiveness of the DPLTA on January 16, 2023, the Adtran Networks shares, representing the equity interest in Adtran Networks held by holders other than the Company, can be tendered at any time and are, therefore, redeemable and must be classified outside stockholders’ equity. Therefore, the permanent equity noncontrolling interest balance was reclassified to redeemable non-controlling interest on January 16, 2023 and was remeasured to fair value based on the trading market price of the Adtran Networks shares.

- changed (2023-08-14):
[0000950170-23-042449:note_history:29]
Subsequently, the carrying value of the RNCI is adjusted to its maximum redemption value at each reporting date when the maximum redemption value is greater than the initial carrying amount of the RNCI. However, the RNCI will be remeasured using the current exchange rate at each reporting date as long as the RNCI is currently redeemable. For the period of time that the DPLTA is in effect, the RNCI will continue to be presented as RNCI outside of stockholders’ equity in the Condensed Consolidated Balance Sheets.
  (was, 2023-05-10, similarity 0.9332):
[0000950170-23-020333:note_history:29]
Subsequently, the carrying value of the RNCI is adjusted to its maximum redemption value at each reporting date when the maximum redemption value is greater than the initial carrying amount of the redeemable noncontrolling interest. However, the RNCI will be remeasured using the current exchange rate at each reporting date as long as the RNCI is currently redeemable. For the period of time that the DPLTA is in effect, the RNCI will continue to be presented as redeemable non-controlling interest outside of stockholders’ equity in the condensed consolidated balance sheets.

- removed (2023-08-14):
[0000950170-23-020333:note_history:30]
In 2022, following the business combination (the “Business Combination”) with ADVA Optical Networking SE (“ADVA”), which included the Merger, we became the sole owner of and successor to ADTRAN, Inc. and the majority shareholder of ADVA. ADTRAN, Inc. is a leading global provider of open, disaggregated networking and communications solutions that enable voice, data, video, and internet communications across any network infrastructure. Its award-winning end-to-end fiber broadband solutions portfolio spans from OLTs to in-home services and intelligent SaaS solutions. ADVA is a global provider of open networking solutions with over 25 years of experience in optical networking, carrier Ethernet access and network synchronization. ADVA has led the industry for over two decades with open and secure networking solutions that carefully balance space, power and cost. Together, we serve customers in a broad range of industries in over 100 countries.

- removed (2023-08-14):
[0000950170-23-020333:note_history:31]
Under the DPLTA, subject to certain limitations pursuant to applicable law and the specific terms of the DPLTA, (i) the Company is entitled to issue binding instructions to the management board of ADVA, (ii) ADVA will transfer its annual profit to the Company, subject to, among other things, the creation or dissolution of certain reserves, and (iii) the Company will generally absorb the annual net loss incurred by ADVA. The obligation of ADVA to transfer its annual profit to the Company applies for the first time to the profit generated subsequent to January 16, 2023.

- removed (2023-08-14):
[0000950170-23-020333:note_history:32]
Subject to certain limitations pursuant to applicable law and the specific terms of the DPLTA, the DPLTA provides that ADVA preferred shareholders be offered, at their election, (i) to put their ADVA shares to the Company in exchange for a compensation in cash of EUR 17.21 per share (the “Exit Compensation”), or (ii) to remain ADVA preferred shareholders and receive a recurring compensation in cash of EUR 0.59 (EUR 0.52 net under the current tax regime) per share for each full fiscal year of ADVA (the “Annual Recurring Compensation”). The Annual Recurring Compensation is due on the third banking day following the ordinary general shareholders’ meeting of ADVA for the respective preceding fiscal year (but in any event within eight months following expiration of the fiscal year) and is first granted for the 2023 fiscal year, payable for the first time after the ordinary general shareholders’ meeting of ADVA in 2024. The Annual Recurring Compensation payment is similar to a cumulative dividend, which does not require Board of Director approval as it is guaranteed under the DPLTA, and is accrued as a dividend liability when it is earned.

- removed (2023-08-14):
[0000950170-23-020333:note_history:33]
The adequacy of both forms of compensation have been challenged by the preferred shareholders of ADVA via court-led appraisal proceedings under German law, and it is possible that the courts in such appraisal proceedings may adjudicate a higher Exit Compensation or Annual Recurring Compensation (in each case, including interest thereon) than agreed upon in the DPLTA.

- removed (2023-08-14):
[0000950170-23-020333:note_history:34]
The opportunity for the ADVA preferred shareholders to tender ADVA preferred shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that have been initiated in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger).

- removed (2023-08-14):
[0000950170-23-020333:note_history:35]
On October 18, 2022, the Company's Board of Directors authorized the Company to purchase additional shares of ADVA through open market purchases not to exceed 15,346,544 shares.

- removed (2023-08-14):
[0000950170-23-020333:note_history:36]
Revision of Previously Issued Financial Statements

- removed (2023-08-14):
[0000950170-23-020333:note_history:37]
During the first quarter of 2023, the Company determined that it understated total assets and total liabilities as of the year ended December 31, 2022, due to netting of deferred tax assets and deferred tax liabilities as of December 31, 2022. While the net amount of deferred tax assets and liabilities remains unchanged, the Company reported the deferred tax assets and liabilities balances without properly applying jurisdictional net reporting disclosure rules. The jurisdictional netting error was a result of the consolidation of financial statements with ADVA following the business combination, which closed on July 15, 2022. The Company revised the December 31, 2022 Consolidated Balance Sheet presented in this report by increasing deferred tax assets and total assets by $61.6 million and increasing deferred tax liability, total liabilities, and total liabilities, redeemable non-controlling interest and equity by $61.6 million. Management has determined that this misstatement was not material to any of its previously issued financial statements.

- removed (2023-08-14):
[0000950170-23-020333:note_history:38]
The following table reflects the impact of the revision to the specific line items presented in the Company’s previously reported consolidated financial statements as of and for the year-ended December 31, 2022:

- removed (2023-08-14):
[0000950170-23-020333:note_history:39]
| (In thousands) |  | As Reported |  |  | Adjustment |  |  | As Revised |  |
| Deferred tax assets |  | $ | 6,210 |  |  | $ | 61,629 |  |  | $ | 67,839 |  |
| Total assets |  | $ | 1,881,865 |  |  | $ | 61,629 |  |  | $ | 1,943,494 |  |
| Deferred tax liabilities |  | $ | — |  |  | $ | 61,629 |  |  | $ | 61,629 |  |
| Total liabilities |  | $ | 578,252 |  |  | $ | 61,629 |  |  | $ | 639,881 |  |

- removed (2023-08-14):
[0000950170-23-020333:note_history:40]
As a result of the effectiveness of the DPLTA on January 16, 2023, the ADVA shares, representing the equity interest in ADVA held by holders other than the Company, can be tendered at any time and are, therefore, redeemable and must be classified outside stockholders’ equity. Therefore, the permanent equity noncontrolling interest balance was reclassified to redeemable non-controlling interest ("RNCI") on January 16, 2023 and was remeasured to fair value based on the trading market price of the ADVA shares.


## adtn:NotesPayableDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-08-14):
[0000950170-23-042449:note_history:41]
|  |  | Fair Value as of |  |  | Carrying Value as of |  |  | Carrying Value as of |  |
| (In thousands) |  | June 30, 2023 |  |  | June 30, 2023 |  |  | December 31, 2022 |  |
| Syndicated credit agreement notes payable |  | $ | — |  |  | $ | — |  |  | $ | 24,598 |  |
| Total Notes Payable |  | $ | — |  |  | $ | — |  |  | $ | 24,598 |  |
  (was, 2023-05-10, similarity 0.9313):
[0000950170-23-020333:note_history:41]
|  |  | Fair Value as of |  |  | Carrying Value as of |  |  | Carrying Value as of |  |
| (In thousands) |  | March 31, 2023 |  |  | March 31, 2023 |  |  | December 31, 2022 |  |
| Syndicated credit agreement notes payable |  | $ | — |  |  | $ | — |  |  | $ | 24,598 |  |
| Total Notes Payable |  | $ | — |  |  | $ | — |  |  | $ | 24,598 |  |

- changed (2023-08-14):
[0000950170-23-042449:note_history:42]
In September 2018, Adtran Networks entered into a syndicated credit agreement with Bayerische Landesbank and Deutsche Bank AG Branch German Business to borrow $63.7 million. On January 31, 2023, the Company repaid the outstanding borrowings under the syndicated credit agreement note payable. No amounts are available for future borrowings.
  (was, 2023-05-10, similarity 0.9767):
[0000950170-23-020333:note_history:42]
In September 2018, ADVA entered into a syndicated credit agreement with Bayerische Landesbank and Deutsche Bank AG Branch German Business to borrow $63.7 million. On January 31, 2023, the Company repaid the outstanding borrowings under the syndicated credit agreement note payable. No amounts are available for future borrowings.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-08-14):
[0000950170-23-042449:note_history:43]
The carrying amounts of the Company's current and non-current revolving credit agreements in its Condensed Consolidated Balance Sheets were as follows:
  (was, 2023-05-10, similarity 0.9137):
[0000950170-23-020333:note_history:43]
The carrying amounts of the Company's revolving credit agreements in its Condensed Consolidated Balance Sheets were as follows:

- added (2023-08-14):
[0000950170-23-042449:note_history:44]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | June 30, 2023 |  |  | December 31, 2022 |  |
| New Nord/LB revolving line of credit |  | $ | 10,912 |  |  | $ | — |  |
| Nord/LB revolving line of credit |  |  | — |  |  |  | 16,091 |  |
| Syndicated credit agreement working capital line of credit |  |  | — |  |  |  | 10,727 |  |
| DZ bank revolving line of credit |  |  | — |  |  |  | 9,118 |  |
| Total current revolving credit agreements |  | $ | 10,912 |  |  | $ | 35,936 |  |

- added (2023-08-14):
[0000950170-23-042449:note_history:45]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | June 30, 2023 |  |  | December 31, 2022 |  |
| Wells Fargo credit agreement |  | $ | 200,000 |  |  | $ | 60,000 |  |
| Total non-current revolving credit agreement |  | $ | 200,000 |  |  | $ | 60,000 |  |

- changed (2023-08-14):
[0000950170-23-042449:note_history:46]
As of June 30, 2023, the weighted average interest rate on our revolving credit agreements was 6.4%.
  (was, 2023-05-10, similarity 0.9514):
[0000950170-23-020333:note_history:46]
As of March 31, 2023, the weighted average interest rate on our revolving credit agreements was 6.2%.

- changed (2023-08-14):
[0000950170-23-042449:note_history:47]
On July 18, 2022, ADTRAN Holdings, Inc. and ADTRAN, Inc., as the borrower, entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (the “Credit Agreement”). The Credit Agreement initially allowed for borrowings of up to $100.0 million in aggregate principal amount, but the permitted borrowings increased to up to $400.0 million in aggregate principal amount upon the DPLTA becoming effective on January 16, 2023.
  (was, 2023-05-10, similarity 0.9808):
[0000950170-23-020333:note_history:47]
On July 18, 2022, ADTRAN Holdings, Inc. and ADTRAN, Inc., as the borrower, entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (the “Credit Agreement”). The Credit Agreement allowed for borrowings of up to $100 million in aggregate principal amount, but the borrowings increased to up to $400 million in aggregate principal amount upon the DPLTA becoming effective on January 16, 2023.

- added (2023-08-14):
[0000950170-23-042449:note_history:48]
The Credit Agreement replaced the Cadence Revolving Credit Agreement and the prior Wells Fargo Revolving Credit Agreement. In connection with the entry into the Credit Agreement, all outstanding borrowings under such credit agreements have been repaid and the agreements terminated.

- added (2023-08-14):
[0000950170-23-042449:note_history:49]
As of June 30, 2023, ADTRAN, Inc.’s borrowings under the revolving line of credit were $200.0 million. The Credit Agreement matures in July 2027 but provides the Company with an option to request extensions subject to customary conditions. In addition, we may issue up to $25.0 million in letters of credit against our $400.0 million total facility. As of June 30, 2023, we had a total of $2.2 million in letters of credit under ADTRAN, Inc. outstanding against our eligible borrowings, leaving a net amount of $197.8 million available for future borrowings. Any future credit extensions under the Credit Agreement are subject to customary conditions precedent. The proceeds of any loans are expected to be used for general corporate purposes and to pay a portion of the Exchange Offer consideration.

- changed (2023-08-14):
[0000950170-23-042449:note_history:50]
All U.S. borrowings under the Credit Agreement (other than swingline loans, which bear interest at the Base Rate (as defined below)) bear interest, at the Company’s option, at a rate per annum equal to (A)(i) the highest of (a) the federal funds rate (i.e., for any day, the rate per annum equal to the weighted average of the rates on overnight federal funds transactions with members of the Federal Reserve System, as published by the Federal Reserve Bank of New York on the business day next succeeding such day) plus ½ of 1%, (b) the prime commercial lending rate of the Administrative Agent, as established from time to time at its principal U.S. office (which such rate is an index or base rate and will not necessarily be its lowest or best rate charged to its customers or other banks), and (c) the daily Adjusted Term SOFR (as defined in the Credit Agreement) for a one-month tenor plus 1%, plus (ii) the applicable rate, ranging from 0.5% to 1.25% (the “Base Rate”), or (B) the sum of the Adjusted Term SOFR (as defined in the Credit Agreement) plus the applicable rate, ranging from 1.4% to 2.15%, provided that such sum is subject to a 0.0% floor (such loans utilizing this interest rate, “SOFR Loans”). All E.U. borrowings under the Credit Agreement (other than swingline loans) bear interest at a rate per annum equal to the sum of the Euro Interbank Offered Rate as administered by the European Money Markets Institute (or a comparable or successor administrator approved by the Administrative Agent) plus the applicable rate, ranging from 1.5% to 2.25%, provided that such sum is subject to a 0.0% floor (such loans utilizing this interest rate, “EURIBOR Loans”). The applicable rate is based on the consolidated net leverage ratio of the Company and its subsidiaries as determined pursuant to the terms of the Credit Agreement. Default interest is 2.00% per annum in excess of the rate otherwise applicable in the case of any overdue principal or any other overdue amount.
  (was, 2023-05-10, similarity 0.9962):
[0000950170-23-020333:note_history:50]
All U.S. borrowings under the Credit Agreement (other than swingline loans, which will bear interest at the Base Rate (as defined below)) will bear interest, at the Company’s option, at a rate per annum equal to (A)(i) the highest of (a) the federal funds rate (i.e., for any day, the rate per annum equal to the weighted average of the rates on overnight federal funds transactions with members of the Federal Reserve System, as published by the Federal Reserve Bank of New York on the business day next succeeding such day) plus ½ of 1%, (b) the prime commercial lending rate of the Administrative Agent, as established from time to time at its principal U.S. office (which such rate is an index or base rate and will not necessarily be its lowest or best rate charged to its customers or other banks), and (c) the daily Adjusted Term SOFR (as defined in the Credit Agreement) for a one-month tenor plus 1%, plus (ii) the applicable rate, ranging from 0.5% to 1.25% (the “Base Rate”), or (B) the sum of the Adjusted Term SOFR (as defined in the Credit Agreement) plus the applicable rate, ranging from 1.4% to 2.15%, provided that such sum is subject to a 0.0% floor (such loans utilizing this interest rate, “SOFR Loans”). All E.U. borrowings under the Credit Agreement (other than swingline loans) will bear interest at a rate per annum equal to the sum of the Euro Interbank Offered Rate as administered by the European Money Markets Institute (or a comparable or successor administrator approved by the Administrative Agent) plus the applicable rate, ranging from 1.5% to 2.25%, provided that such sum is subject to a 0.0% floor (such loans utilizing this interest rate, “EURIBOR Loans”). The applicable rate is based on the consolidated net leverage ratio of the Company and its subsidiaries as determined pursuant to the terms of the Credit Agreement. Default interest is 2.00% per annum in excess of the rate otherwise applicable in the case of any overdue principal or any other overdue amount.

- changed (2023-08-14):
[0000950170-23-042449:note_history:51]
The Credit Agreement permits the Company to prepay any or all of the outstanding loans or to reduce the commitments under the Credit Agreement without incurring premiums or penalties (except breakage costs with respect to SOFR Loans and EURIBOR Loans). The Credit Agreement contains customary affirmative and negative covenants, including incurrence covenants and certain other limitations on the ability of the Company and the Company’s subsidiaries to incur additional debt, guarantee other obligations, grant liens on assets, make investments, dispose of assets, pay dividends or other payments on capital stock, make restricted payments, engage in mergers or consolidations, engage in transactions with affiliates, modify its organizational documents, and enter into certain restrictive agreements. It also contains customary events of default (subject to customary cure periods and materiality thresholds). Furthermore, the Credit Agreement requires that the consolidated total net leverage ratio (as defined in the Credit Agreement) of the Company and its subsidiaries tested on the last day of each fiscal quarter not exceed 3.25 to 1.0 through September 30, 2024 and 2.75 to 1.00 from December 31, 2024 and thereafter, subject to certain exceptions. The Credit Agreement also requires that the consolidated interest coverage ratio (as defined in the Credit Agreement) of the Company and its subsidiaries tested on the last day of each fiscal quarter not fall below 3.00 to 1.00. As of June 30, 2023, the Company was in compliance with all material covenants.
  (was, 2023-05-10, similarity 0.6035):
[0000950170-23-020333:note_history:51]
The Credit Agreement permits the Company to prepay any or all of the outstanding loans or to reduce the commitments under the Credit Agreement without incurring premiums or penalties (except breakage costs with respect to SOFR Loans and EURIBOR Loans). The Credit Agreement contains customary affirmative and negative covenants, including incurrence covenants and certain other limitations on the ability of the Company and the Company’s subsidiaries to incur additional debt, guarantee other obligations, grant liens on assets, make investments, dispose of assets, pay dividends or other payments on capital stock, make restricted payments, engage in mergers or

- changed (2023-08-14):
[0000950170-23-042449:note_history:52]
Finally, pursuant to a Collateral Agreement, dated as of July 18, 2022, among the Company, ADTRAN, Inc. and the Administrative Agent, ADTRAN, Inc.’s obligations under the Credit Agreement are secured by substantially all of the assets of ADTRAN, Inc. and the
  (was, 2023-05-10, similarity 0.6885):
[0000950170-23-020333:note_history:52]
Finally, pursuant to a Collateral Agreement, dated as of July 18, 2022, among the Company, ADTRAN, Inc. and the Administrative Agent, ADTRAN, Inc.’s obligations under the Credit Agreement are secured by substantially all of the assets of ADTRAN, Inc. and the Company. In addition, the Company has guaranteed ADTRAN, Inc.’s obligations under the Credit Agreement pursuant to a Guaranty Agreement, dated as of July 18, 2022, by ADTRAN, Inc. and the Company in favor of the Administrative Agent.

- added (2023-08-14):
[0000950170-23-042449:note_history:53]
Company. In addition, the Company has guaranteed ADTRAN, Inc.’s obligations under the Credit Agreement pursuant to a Guaranty Agreement, dated as of July 18, 2022, by ADTRAN, Inc. and the Company in favor of the Administrative Agent.

- changed (2023-08-14):
[0000950170-23-042449:note_history:54]
On March 29, 2023, Adtran Networks entered into a $16.1 million unsecured revolving line of credit with Norddeutsche Landesbark - Girozentrale (Nord/LB) that bears interest of Euro Short Term Rate plus 1.94%. The line of credit has a perpetual term that can be terminated by the Company or Nord/LB at any time. As of June 30, 2023, Adtran Networks borrowed $10.9 million under this facility.
  (was, 2023-05-10, similarity 0.9263):
[0000950170-23-020333:note_history:54]
On March 29, 2023, ADVA entered into a $16.1 million unsecured revolving line of credit with Norddeutsche Landesbark - Girozentrale (Nord/LB) that bears interest of Euro Short Term Rate plus 1.94%. The line of credit has a perpetual term that can be terminated by the Company or Nord/LB at any time. As of March 31, 2023, ADVA borrowed $10.8 million under this facility.

- changed (2023-08-14):
[0000950170-23-042449:note_history:55]
Prior Nord/LB Revolving Line of Credit
  (was, 2023-05-10, similarity 0.8919):
[0000950170-23-020333:note_history:55]
New Nord/LB Revolving Line of Credit

- added (2023-08-14):
[0000950170-23-042449:note_history:56]
On August 8, 2022, Adtran Networks entered into a $16.1 million revolving line of credit with Norddeutsche Landesbark - Girozentrale (Nord/LB) that bears interest of Euro Short Term Rate plus 1.4% and which matures in August 2023. On January 31, 2023, the Company repaid the outstanding borrowings under the Nord/LB revolving line of credit. No amounts are available for future borrowings.

- changed (2023-08-14):
[0000950170-23-042449:note_history:57]
In September 2018, Adtran Networks entered into a syndicated credit agreement with Bayerische Landesbank and Deutsche Bank AG Branch German Business to borrow up to $10.7 million as part of a working capital line of credit. On January 31, 2023, the Company repaid the outstanding borrowings under the syndicated credit agreement working capital line of credit. No amounts are available for future borrowings.
  (was, 2023-05-10, similarity 0.9807):
[0000950170-23-020333:note_history:57]
In September 2018, ADVA entered into a syndicated credit agreement with Bayerische Landesbank and Deutsche Bank AG Branch German Business to borrow up to $10.7 million as part of a working capital line of credit. On January 31, 2023, the Company repaid the outstanding borrowings under the syndicated credit agreement working capital line of credit. No amounts are available for future borrowings.

- added (2023-08-14):
[0000950170-23-042449:note_history:58]
In the fourth quarter of 2022, Adtran Networks entered into a revolving line of credit with DZ Bank to borrow up to $9.1 million. Interest on the line of credit reset monthly based on renewal of the loan and was 2.8% at the time the loan was repaid. On March 12, 2023, the Company repaid the outstanding borrowings under the DZ Bank revolving line of credit. No amounts are available for future borrowings.

- removed (2023-08-14):
[0000950170-23-020333:note_history:59]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | March 31, 2023 |  |  | December 31, 2022 |  |
| Wells Fargo credit agreement |  | $ | 180,000 |  |  | $ | 60,000 |  |
| New Nord/LB revolving line of credit |  |  | 10,843 |  |  |  | — |  |
| Nord/LB revolving line of credit |  |  | — |  |  |  | 16,091 |  |
| Syndicated credit agreement working capital line of credit |  |  | — |  |  |  | 10,727 |  |
| DZ bank revolving line of credit |  |  | — |  |  |  | 9,118 |  |
| Total revolving credit agreements |  | $ | 190,843 |  |  | $ | 95,936 |  |

- removed (2023-08-14):
[0000950170-23-020333:note_history:60]
The Credit Agreement replaced the Cadence Revolving Credit Agreement and the Wells Fargo Revolving Credit Agreement. In connection with the entry into the Credit Agreement, all outstanding borrowings under such credit agreements have been repaid and the agreements terminated.

- removed (2023-08-14):
[0000950170-23-020333:note_history:61]
As of March 31, 2023, ADTRAN, Inc.’s borrowings under the revolving line of credit were $180.0 million in tranches that mature during the second and third quarters of 2023 and can either be repaid or borrowed again for a one month, three month or six month period. In addition, we may issue up to $25.0 million in letters of credit against our $400.0 million dollar total facility. As of March 31, 2023, we had a total of $3.4 million in letters of credit under ADTRAN, Inc. outstanding against our eligible borrowings, leaving a net amount of $216.6 million available for future borrowings. Any future credit extensions under the Credit Agreement are subject to customary conditions precedent. The proceeds of any loans are expected to be used for general corporate purposes and to pay a portion of the Exchange Offer consideration.

- removed (2023-08-14):
[0000950170-23-020333:note_history:62]
consolidations, engage in transactions with affiliates, modify its organizational documents, and enter into certain restrictive agreements. It also contains customary events of default (subject to customary cure periods and materiality thresholds). Furthermore, the Credit Agreement requires that the consolidated total net leverage ratio (as defined in the Credit Agreement) of the Company and its subsidiaries tested on the last day of each fiscal quarter not exceed 3.25 to 1.0 through September 30, 2024 and 2.75 to 1.00 from December 31, 2024 and thereafter, subject to certain exceptions. The Credit Agreement also requires that the consolidated interest coverage ratio (as defined in the Credit Agreement) of the Company and its subsidiaries tested on the last day of each fiscal quarter not fall below 3.00 to 1.00. As of March 31, 2023, the Company was in compliance with all material covenants. The Credit Agreement matures in July 2027 but provides the Company with an option to request extensions subject to customary conditions.

- removed (2023-08-14):
[0000950170-23-020333:note_history:63]
On August 8, 2022, ADVA entered into a $16.1 million revolving line of credit with Norddeutsche Landesbark - Girozentrale (Nord/LB) that bears interest of Euro Short Term Rate plus 1.4% and which matures in August 2023. On January 31, 2023, the Company repaid the outstanding borrowings under the Nord/LB revolving line of credit. No amounts are available for future borrowings.

- removed (2023-08-14):
[0000950170-23-020333:note_history:64]
In the fourth quarter of 2022, ADVA entered into a revolving line of credit with DZ Bank to borrow up to $9.1 million. Interest on the line of credit reset monthly based on renewal of the loan and was 2.8% at the time the loan was repaid. On March 12, 2023, the Company repaid the outstanding borrowings under the DZ Bank revolving line of credit. No amounts are available for future borrowings.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-08-14):
[0000950170-23-042449:note_history:65]
|  |  | As of June 30, 2023 |  |
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 1,897 |  |  | $ | 1 |  |  | $ | (58 | ) |  | $ | 1,840 |  |
| Municipal fixed-rate bonds |  |  | 185 |  |  |  | — |  |  |  | (2 | ) |  |  | 183 |  |
| Asset-backed bonds |  |  | 670 |  |  |  | — |  |  |  | (22 | ) |  |  | 648 |  |
| Mortgage/Agency-backed bonds |  |  | 1,298 |  |  |  | — |  |  |  | (74 | ) |  |  | 1,224 |  |
| U.S. government bonds |  |  | 3,955 |  |  |  | — |  |  |  | (162 | ) |  |  | 3,793 |  |
| Foreign government bonds |  |  | 405 |  |  |  | — |  |  |  | (19 | ) |  |  | 386 |  |
| Available-for-sale debt securities held at fair value |  | $ | 8,410 |  |  | $ | 1 |  |  | $ | (337 | ) |  | $ | 8,074 |  |
  (was, 2023-05-10, similarity 0.989):
[0000950170-23-020333:note_history:65]
|  |  | As of March 31, 2023 |  |
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 2,218 |  |  | $ | 4 |  |  | $ | (63 | ) |  | $ | 2,159 |  |
| Municipal fixed-rate bonds |  |  | 185 |  |  |  | — |  |  |  | (4 | ) |  |  | 181 |  |
| Asset-backed bonds |  |  | 734 |  |  |  | 1 |  |  |  | (20 | ) |  |  | 715 |  |
| Mortgage/Agency-backed bonds |  |  | 1,699 |  |  |  | 1 |  |  |  | (82 | ) |  |  | 1,618 |  |
| U.S. government bonds |  |  | 4,299 |  |  |  | 5 |  |  |  | (151 | ) |  |  | 4,153 |  |
| Foreign government bonds |  |  | 406 |  |  |  | — |  |  |  | (19 | ) |  |  | 387 |  |
| Available-for-sale debt securities held at fair value |  | $ | 9,541 |  |  | $ | 11 |  |  | $ | (339 | ) |  | $ | 9,213 |  |

- changed (2023-08-14):
[0000950170-23-042449:note_history:66]
|  |  | As of June 30, 2023 |
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset-backed bonds |  |  | Mortgage/ Agency-backed bonds |  |  | U.S. government bonds |  |  | Foreign government bonds |  |  |
| Less than one year |  | $ | 470 |  |  | $ | 183 |  |  | $ | — |  |  | $ | — |  |  | $ | 2,158 |  |  | $ | 278 |  |  |
| One to two years |  |  | 1,048 |  |  |  | — |  |  |  | 218 |  |  |  | 164 |  |  |  | 1,266 |  |  |  | 108 |  |  |
| Two to three years |  |  | 322 |  |  |  | — |  |  |  | — |  |  |  | 288 |  |  |  | 249 |  |  |  | — |  |  |
| Three to five years |  |  | — |  |  |  | — |  |  |  | 287 |  |  |  | 226 |  |  |  | 120 |  |  |  | — |  |  |
| Five to ten years |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 200 |  |  |  | — |  |  |  | — |  |  |
| More than ten years |  |  | — |  |  |  | — |  |  |  | 143 |  |  |  | 346 |  |  |  | — |  |  |  | — |  |  |
| Total |  | $ | 1,840 |  |  | $ | 183 |  |  | $ | 648 |  |  | $ | 1,224 |  |  | $ | 3,793 |  |  | $ | 386 |  |  |
  (was, 2023-05-10, similarity 0.9921):
[0000950170-23-020333:note_history:66]
|  |  | As of March 31, 2023 |
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset-backed bonds |  |  | Mortgage/ Agency-backed bonds |  |  | U.S. government bonds |  |  | Foreign government bonds |  |  |
| Less than one year |  | $ | 369 |  |  | $ | 181 |  |  | $ | — |  |  | $ | — |  |  | $ | 508 |  |  | $ | — |  |  |
| One to two years |  |  | 966 |  |  |  | — |  |  |  | 169 |  |  |  | 166 |  |  |  | 3,174 |  |  |  | 387 |  |  |
| Two to three years |  |  | 824 |  |  |  | — |  |  |  | 49 |  |  |  | 600 |  |  |  | 348 |  |  |  | — |  |  |
| Three to five years |  |  | — |  |  |  | — |  |  |  | 337 |  |  |  | 242 |  |  |  | 123 |  |  |  | — |  |  |
| Five to ten years |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 238 |  |  |  | — |  |  |  | — |  |  |
| More than ten years |  |  | — |  |  |  | — |  |  |  | 160 |  |  |  | 372 |  |  |  | — |  |  |  | — |  |  |
| Total |  | $ | 2,159 |  |  | $ | 181 |  |  | $ | 715 |  |  | $ | 1,618 |  |  | $ | 4,153 |  |  | $ | 387 |  |  |

- added (2023-08-14):
[0000950170-23-042449:note_history:67]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Gross realized gain on debt securities |  | $ | — |  |  | $ | — |  |  | $ | 4 |  |  | $ | 12 |  |
| Gross realized loss on debt securities |  |  | (27 | ) |  |  | (85 | ) |  |  | (39 | ) |  |  | (125 | ) |
| Total loss recognized, net |  | $ | (27 | ) |  | $ | (85 | ) |  | $ | (35 | ) |  | $ | (113 | ) |

- changed (2023-08-14):
[0000950170-23-042449:note_history:68]
Income generated from available-for-sale debt securities was recorded as interest and dividend income in the Condensed Consolidated Statements of (Loss) Income. No allowance for credit losses was recorded for the six months ended June 30, 2023 and 2022 related to available-for-sale debt securities. The Company’s investment policy provides limitations for issuer concentration, which limits, at the time of purchase, the concentration in any one issuer to 5% of the market value of its total investment portfolio. The Company did not purchase any available-for-sale debt security with credit deterioration during the six months ended June 30, 2023.
  (was, 2023-05-10, similarity 0.9155):
[0000950170-23-020333:note_history:68]
Income generated from available-for-sale debt securities was recorded as interest and dividend income in the Condensed Consolidated Statements of Loss. No allowance for credit losses was recorded for the three months ended March 31, 2023 and 2022 related to available-for-sale debt securities. The Company’s investment policy provides limitations for issuer concentration, which limits, at the time of purchase, the concentration in any one issuer to 5% of the market value of its total investment portfolio. The Company did not purchase any available-for-sale debt security with credit deterioration during the three months ended March 31, 2023.

- added (2023-08-14):
[0000950170-23-042449:note_history:69]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Unrealized gain (loss) on equity securities held |  | $ | 1,288 |  |  | $ | (4,268 | ) |  | $ | 2,535 |  |  | $ | (7,630 | ) |
| Realized gain (loss) on equity securities sold |  |  | 1 |  |  |  | (293 | ) |  |  | 14 |  |  |  | (318 | ) |
| Total gain (loss) recognized, net |  | $ | 1,289 |  |  | $ | (4,561 | ) |  | $ | 2,549 |  |  | $ | (7,948 | ) |

- changed (2023-08-14):
[0000950170-23-042449:note_history:70]
Income generated from marketable equity securities was recorded as interest and dividend income in the Condensed Consolidated Statements of (Loss) Income. U.S. GAAP establishes a three-level valuation hierarchy based upon observable and unobservable inputs for fair value measurement of financial instruments:
  (was, 2023-05-10, similarity 0.9721):
[0000950170-23-020333:note_history:70]
Income generated from marketable equity securities was recorded as interest and dividend income in the Condensed Consolidated Statements of Loss. U.S. GAAP establishes a three-level valuation hierarchy based upon observable and unobservable inputs for fair value measurement of financial instruments:

- changed (2023-08-14):
[0000950170-23-042449:note_history:71]
|  |  |  |  |  | Fair Value Measurements as of June 30, 2023 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket for IdenticalAssets (Level 1) |  |  | SignificantOtherObservableInputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |
| U.S. government securities |  | $ | 1,019 |  |  | $ | 1,019 |  |  | $ | — |  |  | $ | — |  |
| Money market funds |  |  | 272 |  |  |  | 272 |  |  |  | — |  |  |  | — |  |
| Commercial paper |  |  | 310 |  |  |  | — |  |  |  | 310 |  |  |  | — |  |
| Total cash equivalents |  | $ | 1,601 |  |  | $ | 1,291 |  |  | $ | 310 |  |  | $ | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  | $ | 1,840 |  |  | $ | — |  |  | $ | 1,840 |  |  | $ | — |  |
| Municipal fixed-rate bonds |  |  | 183 |  |  |  | — |  |  |  | 183 |  |  |  | — |  |
| Asset-backed bonds |  |  | 648 |  |  |  | — |  |  |  | 648 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 1,224 |  |  |  | — |  |  |  | 1,224 |  |  |  | — |  |
| U.S. government bonds |  |  | 3,793 |  |  |  | 3,793 |  |  |  | — |  |  |  | — |  |
| Foreign government securities |  |  | 386 |  |  |  | — |  |  |  | 386 |  |  |  | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 858 |  |  |  | 854 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 25,395 |  |  |  | 25,395 |  |  |  | — |  |  |  | — |  |
| Total short-term and long-term investments |  | $ | 34,327 |  |  | $ | 30,042 |  |  | $ | 4,281 |  |  | $ | — |  |
| Total |  | $ | 35,928 |  |  | $ | 31,333 |  |  | $ | 4,591 |  |  | $ | — |  |
  (was, 2023-05-10, similarity 0.8827):
[0000950170-23-020333:note_history:71]
|  |  |  |  |  | Fair Value Measurements as of March 31, 2023 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket for IdenticalAssets (Level 1) |  |  | SignificantOtherObservableInputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |
| US government securities |  | $ | 175 |  |  | $ | 175 |  |  | $ | — |  |  | $ | — |  |
| Money market funds |  |  | 243 |  |  |  | 243 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 2,159 |  |  |  | — |  |  |  | 2,159 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 181 |  |  |  | — |  |  |  | 181 |  |  |  | — |  |
| Asset-backed bonds |  |  | 715 |  |  |  | — |  |  |  | 715 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 1,618 |  |  |  | — |  |  |  | 1,618 |  |  |  | — |  |
| U.S. government bonds |  |  | 4,153 |  |  |  | 4,153 |  |  |  | — |  |  |  | — |  |
| Foreign government securities |  |  | 387 |  |  |  | — |  |  |  | 387 |  |  |  | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 821 |  |  |  | 821 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 24,013 |  |  |  | 24,013 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 34,465 |  |  | $ | 29,405 |  |  | $ | 5,060 |  |  | $ | — |  |

- changed (2023-08-14):
[0000950170-23-042449:note_history:72]
|  |  |  |  |  | Fair Value Measurements as of December 31, 2022 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket for IdenticalAssets (Level 1) |  |  | SignificantOtherObservableInputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 228 |  |  | $ | 228 |  |  | $ | — |  |  | $ | — |  |
| Total cash equivalents |  | $ | 228 |  |  | $ | 228 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  | $ | 2,462 |  |  | $ | — |  |  | $ | 2,462 |  |  | $ | — |  |
| Municipal fixed-rate bonds |  |  | 180 |  |  |  | — |  |  |  | 180 |  |  |  | — |  |
| Asset-backed bonds |  |  | 795 |  |  |  | — |  |  |  | 795 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 1,748 |  |  |  | — |  |  |  | 1,748 |  |  |  | — |  |
| U.S. government bonds |  |  | 3,685 |  |  |  | 3,685 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 383 |  |  |  | — |  |  |  | 383 |  |  |  | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 810 |  |  |  | 810 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 22,942 |  |  |  | 22,942 |  |  |  | — |  |  |  | — |  |
| Total short-term and long-term investments |  | $ | 33,005 |  |  | $ | 27,437 |  |  | $ | 5,568 |  |  | $ | - |  |
| Total |  | $ | 33,233 |  |  | $ | 27,665 |  |  | $ | 5,568 |  |  | $ | — |  |
  (was, 2023-05-10, similarity 0.8991):
[0000950170-23-020333:note_history:72]
|  |  |  |  |  | Fair Value Measurements as of December 31, 2022 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket for IdenticalAssets (Level 1) |  |  | SignificantOtherObservableInputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 228 |  |  | $ | 228 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 2,462 |  |  |  | — |  |  |  | 2,462 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 180 |  |  |  | — |  |  |  | 180 |  |  |  | — |  |
| Asset-backed bonds |  |  | 795 |  |  |  | — |  |  |  | 795 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 1,748 |  |  |  | — |  |  |  | 1,748 |  |  |  | — |  |
| U.S. government bonds |  |  | 3,685 |  |  |  | 3,685 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 383 |  |  |  | — |  |  |  | 383 |  |  |  | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 804 |  |  |  | 804 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 22,942 |  |  |  | 22,942 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 33,227 |  |  | $ | 27,659 |  |  | $ | 5,568 |  |  | $ | — |  |

- removed (2023-08-14):
[0000950170-23-020333:note_history:73]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2023 |  |  | 2022 |  |
| Gross realized gain on debt securities |  | $ | 4 |  |  | $ | 12 |  |
| Gross realized loss on debt securities |  |  | (11 | ) |  |  | (40 | ) |
| Total (loss) gain recognized, net |  | $ | (7 | ) |  | $ | (28 | ) |

- removed (2023-08-14):
[0000950170-23-020333:note_history:74]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2023 |  |  | 2022 |  |
| Realized (loss) gain on equity securities sold |  | $ | 13 |  |  | $ | (25 | ) |
| Unrealized (loss) gain on equity securities held |  |  | 1,246 |  |  |  | (3,362 | ) |
| Total (loss) gain recognized, net |  | $ | 1,259 |  |  | $ | (3,387 | ) |


## us-gaap:ScheduleOfCarryingValuesAndEstimatedFairValuesOfDebtInstrumentsTableTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2023-08-14):
[0000950170-23-042449:note_history:75]
|  |  | Fair Value as of |  |  | Carrying Value as of |  |  | Carrying Value as of |  |
| (In thousands) |  | June 30, 2023 |  |  | June 30, 2023 |  |  | December 31, 2022 |  |
| Syndicated credit agreement notes payable |  | $ | — |  |  | $ | — |  |  | $ | 24,598 |  |
| Total Notes Payable |  | $ | — |  |  | $ | — |  |  | $ | 24,598 |  |
  (was, 2023-05-10, similarity 0.9313):
[0000950170-23-020333:note_history:75]
|  |  | Fair Value as of |  |  | Carrying Value as of |  |  | Carrying Value as of |  |
| (In thousands) |  | March 31, 2023 |  |  | March 31, 2023 |  |  | December 31, 2022 |  |
| Syndicated credit agreement notes payable |  | $ | — |  |  | $ | — |  |  | $ | 24,598 |  |
| Total Notes Payable |  | $ | — |  |  | $ | — |  |  | $ | 24,598 |  |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-08-14):
[0000950170-23-042449:note_history:76]
The following tables disaggregate revenue by reportable segment and revenue category. Prior year amounts presented below have been reclassified to conform to the current period revenue category presentation:
  (was, 2023-05-10, similarity 0.9324):
[0000950170-23-020333:note_history:76]
The following table disaggregates revenue by reportable segment and revenue category. Prior year amounts presented below have been reclassified to conform to the current period revenue category presentation:

- added (2023-08-14):
[0000950170-23-042449:note_history:77]
|  |  | Three Months Ended |  |
|  |  | June 30, 2023 |  |  | June 30, 2022 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Optical Networking Solutions |  | $ | 120,221 |  |  | $ | 22,775 |  |  | $ | 142,996 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Access & Aggregation Solutions |  |  | 89,263 |  |  |  | 13,454 |  |  |  | 102,717 |  |  |  | 80,821 |  |  |  | 11,467 |  |  |  | 92,288 |  |
| Subscriber Solutions |  |  | 73,518 |  |  |  | 8,147 |  |  |  | 81,665 |  |  |  | 75,171 |  |  |  | 4,579 |  |  |  | 79,750 |  |
| Total |  | $ | 283,002 |  |  | $ | 44,376 |  |  | $ | 327,378 |  |  | $ | 155,992 |  |  | $ | 16,046 |  |  | $ | 172,038 |  |

- added (2023-08-14):
[0000950170-23-042449:note_history:78]
|  |  | Six Months Ended |  |
|  |  | June 30, 2023 |  |  | June 30, 2022 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Optical Networking Solutions |  | $ | 247,798 |  |  | $ | 42,954 |  |  | $ | 290,752 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Access & Aggregation Solutions |  |  | 173,817 |  |  |  | 25,720 |  |  |  | 199,537 |  |  |  | 166,805 |  |  |  | 23,279 |  |  |  | 190,084 |  |
| Subscriber Solutions |  |  | 143,805 |  |  |  | 17,196 |  |  |  | 161,001 |  |  |  | 127,561 |  |  |  | 8,911 |  |  |  | 136,472 |  |
| Total |  | $ | 565,420 |  |  | $ | 85,870 |  |  | $ | 651,290 |  |  | $ | 294,366 |  |  | $ | 32,190 |  |  | $ | 326,556 |  |

- added (2023-08-14):
[0000950170-23-042449:note_history:79]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Optical Networking Solutions |  | $ | 142,996 |  |  | $ | — |  |  | $ | 290,752 |  |  | $ | — |  |
| Access & Aggregation Solutions |  |  | 102,717 |  |  |  | 92,288 |  |  |  | 199,537 |  |  |  | 190,084 |  |
| Subscriber Solutions |  |  | 81,665 |  |  |  | 79,750 |  |  |  | 161,001 |  |  |  | 136,472 |  |
| Total |  | $ | 327,378 |  |  | $ | 172,038 |  |  | $ | 651,290 |  |  | $ | 326,556 |  |

- removed (2023-08-14):
[0000950170-23-020333:note_history:80]
|  |  | Three Months Ended |  |
|  |  | March 31, 2023 |  |  | March 31, 2022 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Subscriber Solutions |  | $ | 70,287 |  |  | $ | 9,049 |  |  | $ | 79,336 |  |  | $ | 52,390 |  |  | $ | 4,332 |  |  | $ | 56,722 |  |
| Access & Aggregation Solutions |  |  | 84,554 |  |  |  | 12,266 |  |  |  | 96,820 |  |  |  | 85,984 |  |  |  | 11,812 |  |  |  | 97,796 |  |
| Optical Networking Solutions |  |  | 127,577 |  |  |  | 20,179 |  |  |  | 147,756 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 282,418 |  |  | $ | 41,494 |  |  | $ | 323,912 |  |  | $ | 138,374 |  |  | $ | 16,144 |  |  | $ | 154,518 |  |

- removed (2023-08-14):
[0000950170-23-020333:note_history:81]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2023 |  |  | 2022 |  |
| Subscriber Solutions |  | $ | 79,336 |  |  | $ | 56,722 |  |
| Access & Aggregation Solutions |  |  | 96,820 |  |  |  | 97,796 |  |
| Optical Networking Solutions |  |  | 147,756 |  |  |  | — |  |
| Total |  | $ | 323,912 |  |  | $ | 154,518 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2023-08-14):
[0000950170-23-042449:note_history:82]
Network Solutions Segment - Includes hardware and software products that enable a digital future which support the Company's Subscriber, Access & Aggregation, and Optical Networking Solutions.
  (was, 2023-05-10, similarity 0.9896):
[0000950170-23-020333:note_history:82]
Network Solutions Segment - Includes hardware and software products that enable a digital future which support the Company's Subscriber, Access and Aggregation, and Optical Networking Solutions.

- changed (2023-08-14):
[0000950170-23-042449:note_history:83]
Services & Support Segment - Includes network design, implementation, maintenance and cloud-hosted services supporting the Company's Subscriber, Access & Aggregation, and Optical Networking Solutions.
  (was, 2023-05-10, similarity 0.99):
[0000950170-23-020333:note_history:83]
Services & Support Segment - Includes network design, implementation, maintenance and cloud-hosted services supporting the Company's Subscriber, Access and Aggregation, and Optical Networking Solutions.

- changed (2023-08-14):
[0000950170-23-042449:note_history:84]
Prior to the Business Combination with Adtran Networks on July 15, 2022, ADTRAN reported revenue across the following three categories: (1) Access & Aggregation, (2) Subscriber Solutions & Experience and (3) Traditional & Other Products. Following the Business Combination with Adtran Networks, we have recast these revenues such that ADTRAN’s former Access & Aggregation revenue is combined with a portion of the applicable Adtran Networks solutions to create Access & Aggregation Solutions, ADTRAN’s former Subscriber Solutions & Experience revenue is combined with a portion of the applicable Adtran Networks solutions to create Subscriber Solutions, and the revenue from Traditional & Other products is now included in the applicable Access & Aggregation Solutions or Subscriber Solutions category. Optical Networking Solutions is a new revenue category added to represent a meaningful portion of Adtran Networks' portfolio.
  (was, 2023-05-10, similarity 0.9564):
[0000950170-23-020333:note_history:84]
Prior to the Business Combination with ADVA on July 15, 2022, ADTRAN reported revenue across the following three categories: (1) Access & Aggregation, (2) Subscriber Solutions & Experience and (3) Traditional & Other Products. Following the Business Combination with ADVA, we have recast these revenues such that ADTRAN’s former Access & Aggregation revenue is combined with a portion of the applicable ADVA solutions to create Access & Aggregation Solutions, ADTRAN’s former Subscriber Solutions & Experience revenue is combined with a portion of the applicable ADVA solutions to create Subscriber Solutions, and the revenue from Traditional & Other products is now included in the applicable Access & Aggregation Solutions or Subscriber Solutions category. Optical Networking Solutions is a new revenue category added to represent a meaningful portion of ADVA’s portfolio.

- changed (2023-08-14):
[0000950170-23-042449:note_history:85]
The following tables disaggregate revenue by reportable segment and revenue category. Prior year amounts presented below have been reclassified to conform to the current period revenue category presentation:
  (was, 2023-05-10, similarity 0.9324):
[0000950170-23-020333:note_history:85]
The following table disaggregates revenue by reportable segment and revenue category. Prior year amounts presented below have been reclassified to conform to the current period revenue category presentation:

- added (2023-08-14):
[0000950170-23-042449:note_history:86]
|  |  | Three Months Ended |  |
|  |  | June 30, 2023 |  |  | June 30, 2022 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Optical Networking Solutions |  | $ | 120,221 |  |  | $ | 22,775 |  |  | $ | 142,996 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Access & Aggregation Solutions |  |  | 89,263 |  |  |  | 13,454 |  |  |  | 102,717 |  |  |  | 80,821 |  |  |  | 11,467 |  |  |  | 92,288 |  |
| Subscriber Solutions |  |  | 73,518 |  |  |  | 8,147 |  |  |  | 81,665 |  |  |  | 75,171 |  |  |  | 4,579 |  |  |  | 79,750 |  |
| Total |  | $ | 283,002 |  |  | $ | 44,376 |  |  | $ | 327,378 |  |  | $ | 155,992 |  |  | $ | 16,046 |  |  | $ | 172,038 |  |

- added (2023-08-14):
[0000950170-23-042449:note_history:87]
|  |  | Six Months Ended |  |
|  |  | June 30, 2023 |  |  | June 30, 2022 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Optical Networking Solutions |  | $ | 247,798 |  |  | $ | 42,954 |  |  | $ | 290,752 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| Access & Aggregation Solutions |  |  | 173,817 |  |  |  | 25,720 |  |  |  | 199,537 |  |  |  | 166,805 |  |  |  | 23,279 |  |  |  | 190,084 |  |
| Subscriber Solutions |  |  | 143,805 |  |  |  | 17,196 |  |  |  | 161,001 |  |  |  | 127,561 |  |  |  | 8,911 |  |  |  | 136,472 |  |
| Total |  | $ | 565,420 |  |  | $ | 85,870 |  |  | $ | 651,290 |  |  | $ | 294,366 |  |  | $ | 32,190 |  |  | $ | 326,556 |  |

- changed (2023-08-14):
[0000950170-23-042449:note_history:88]
The aggregate amount of transaction price allocated to remaining performance obligations that have not been satisfied as of June 30, 2023 and December 31, 2022 related to contractual maintenance agreements, contractual SaaS and subscription services, and hardware contracts that exceed one year in duration amounted to $369.3 million and $277.2 million, respectively. As of June 30, 2023, approximately 46.5% is expected to be recognized over the next 12 months and the remainder recognized thereafter. The majority of the Company's remaining performance obligations as of June 30, 2023 are related to contracts or orders that have an original expected duration of one year or less, for which the Company is electing to utilize the practical expedient available within the guidance, and are excluded from the transaction price related to these future obligations. The Company will generally satisfy the remaining performance obligations as we transfer control of the products ordered or services to our customers, excluding maintenance services, which are satisfied over time.
  (was, 2023-05-10, similarity 0.9871):
[0000950170-23-020333:note_history:88]
The aggregate amount of transaction price allocated to remaining performance obligations that have not been satisfied as of March 31, 2023 and December 31, 2022 related to contractual maintenance agreements, contractual SaaS and subscription services, and hardware contracts that exceed one year in duration amounted to $389.0 million and $277.2 million, respectively. As of March 31, 2023, approximately 68% is expected to be recognized over the next 12 months and the remainder recognized thereafter. The majority of the Company's remaining performance obligations as of March 31, 2023 are related to contracts or orders that have an original expected duration of one year or less, for which the Company is electing to utilize the practical expedient available within the guidance, and are excluded from the transaction price related to these future obligations. The Company will generally satisfy the remaining performance obligations as we transfer control of the products ordered or services to our customers, excluding maintenance services, which are satisfied over time.

- changed (2023-08-14):
[0000950170-23-042449:note_history:89]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | June 30, 2023 |  |  | December 31, 2022 |  |
| Accounts receivable, net |  | $ | 239,565 |  |  | $ | 279,435 |  |
| Contract assets(1) |  | $ | 1,153 |  |  | $ | 1,852 |  |
| Unearned revenue |  | $ | 48,030 |  |  | $ | 41,193 |  |
| Non-current unearned revenue |  | $ | 24,111 |  |  | $ | 19,239 |  |
  (was, 2023-05-10, similarity 0.9841):
[0000950170-23-020333:note_history:89]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | March 31, 2023 |  |  | December 31, 2022 |  |
| Accounts receivable, net |  | $ | 262,043 |  |  | $ | 279,435 |  |
| Contract assets(1) |  | $ | 1,972 |  |  | $ | 1,852 |  |
| Unearned revenue |  | $ | 55,611 |  |  | $ | 41,193 |  |
| Non-current unearned revenue |  | $ | 24,907 |  |  | $ | 19,239 |  |

- changed (2023-08-14):
[0000950170-23-042449:note_history:90]
The Company is party to a receivables purchase agreement with a third-party financial institution (the “Factor”), which accelerates receivable collection and helps to better manage cash flow. Total accounts receivables sold for the six months ended June 30, 2023 and the twelve months ended December 31, 2022, totaled $14.7 million and $14.9 million, respectively, of which $1.2 million was retained by the Factor in the reserve account. The balance in the reserve account is included in other assets on the Condensed Consolidated Balance Sheets. As of June 30, 2023 and December 31, 2022, the Company had an allowance for credit losses related to factored accounts receivable totaling less than $0.1 million. The cost of the receivables purchase agreement is included in interest expense in the Condensed Consolidated Statements of (Loss) Income and totaled $0.3 million and $0.6 million for the three and six months ended June 30, 2023, respectively.
  (was, 2023-05-10, similarity 0.75):
[0000950170-23-020333:note_history:90]
The Company is party to a receivables purchase agreement with a third party financial institution (the “Factor”). As of March 31, 2023 and December 31, 2022, accounts receivable totaling $15.6 million and $14.9 million, respectively, were sold, of which $1.2 million was retained by the Factor in the reserve account. The balance in the reserve account is included in other assets on the Condensed Consolidated Balance Sheets. As of March 31, 2023 and December 31, 2022, the Company had an allowance for doubtful accounts related to factored accounts receivable totaling less than $0.1 million. The cost of receivables purchase agreement is included in interest expense in the Condensed Consolidated Statements of Loss and totaled $0.3 million for the three months ended March 31, 2023.

- added (2023-08-14):
[0000950170-23-042449:note_history:91]
Of the outstanding unearned revenue balances as of December 31, 2022, $24.8 million and $50.5 million was recognized as revenue during the three and six months ended June 30, 2023, respectively. Of the $17.7 million of outstanding unearned revenue balances as of December 31, 2021, $4.1 million and $9.5 million was recognized as revenue during the three and six months ended June 30, 2022, respectively.

- changed (2023-08-14):
[0000950170-23-042449:note_history:92]
As of June 30, 2023 and December 31, 2022, the Company’s outstanding accounts receivable balance was $239.6 million and $279.4 million, respectively. The Company assessed the need for an allowance for credit losses related to its outstanding accounts receivable using the historical loss-rate method as well as assessing asset-specific risks. The assessment of asset-specific risks included the evaluation of relevant available information, from internal and external sources, relating to current conditions that may affect a customer’s ability to pay, such as the customer’s current financial condition, credit rating by geographic location, as provided by a third party and/or by customer, if needed, and the overall macro-economic conditions in which the customer operates. The Company pooled assets by geographic location to determine if an allowance should be applied to its accounts receivable balance, assessing the specific country risk rating and overall economics of that particular country. If elevated risk existed, or customer specific risk indicated the accounts receivable balance was at risk, the Company further analyzed the need for an allowance related to specific accounts receivable balances. Additionally, the Company determined that significant changes to customer country risk rating from period-to-period and from the end of the prior year to the end of the current quarter would require further review and analysis by the Company.
  (was, 2023-05-10, similarity 0.9969):
[0000950170-23-020333:note_history:92]
As of March 31, 2023 and December 31, 2022, the Company’s outstanding accounts receivable balance was $262.0 million and $279.4 million, respectively. The Company assessed the need for an allowance for credit losses related to its outstanding accounts receivable using the historical loss-rate method as well as assessing asset-specific risks. The assessment of asset-specific risks included the evaluation of relevant available information, from internal and external sources, relating to current conditions that may affect a customer’s ability to pay, such as the customer’s current financial condition, credit rating by geographic location, as provided by a third party and/or by customer, if needed, and the overall macro-economic conditions in which the customer operates. The Company pooled assets by geographic location to determine if an allowance should be applied to its accounts receivable balance, assessing the specific country risk rating and overall economics of that particular country. If elevated risk existed, or customer specific risk indicated the accounts receivable balance was at risk, the Company further analyzed the need for an allowance related to specific accounts receivable balances. Additionally, the Company determined that significant changes to customer country risk rating from period-to-period and from the end of the prior year to the end of the current quarter would require further review and analysis by the Company.

- changed (2023-08-14):
[0000950170-23-042449:note_history:93]
The allowance for credit losses was $26 thousand and $49 thousand as of June 30, 2023 and December 31, 2022, respectively, related to accounts receivable.
  (was, 2023-05-10, similarity 0.9291):
[0000950170-23-020333:note_history:93]
The allowance for credit losses was $0.1 million and $49 thousand as of March 31, 2023 and December 31, 2022, respectively, related to accounts receivable.

- changed (2023-08-14):
[0000950170-23-042449:note_history:94]
The Company records contract assets when it has recognized revenue but has not yet billed the customer. As of June 30, 2023 and December 31, 2022, the Company’s outstanding contract asset balance was $1.2 million and $1.9 million, respectively, which is included in other receivables on the Consolidated Balance Sheets. The Company assessed the need for an allowance for credit losses related to its outstanding contract assets using the historical loss-rate method as well as asset-specific risks. The Company’s historical losses related to contract assets receivable have been immaterial as evidenced by historical write-offs due to collectability. Asset-specific risk included the evaluation of relevant available information, from internal and external sources, relating to current conditions that may affect a customer’s ability to pay once invoiced, such as the customer’s financial condition, credit rating by geographic location as provided by a third party and/or by customer, if needed, and the overall macro-economic conditions in which the customer operates. The Company pooled assets by geographic location to determine if an allowance should be applied to its contract asset balance, assessing the specific country risk rating and the overall economics of that particular country. If elevated risk existed, or customer specific risk indicated the contract balance was at risk, the Company further analyzed the need for an allowance related to specific customer balances. Additionally, the Company determined that significant changes to customer country risk rating from period-to-period and from the end of the prior year to the end of the current quarter would be subject to further review and analysis by the Company.
  (was, 2023-05-10, similarity 0.9974):
[0000950170-23-020333:note_history:94]
The Company records contract assets when it has recognized revenue but has not yet billed the customer. As of March 31, 2023 and December 31, 2022, the Company’s outstanding contract asset balance was $2.0 million and $1.9 million, respectively, which is included in other receivables on the Consolidated Balance Sheets. The Company assessed the need for an allowance for credit losses related to its outstanding contract assets using the historical loss-rate method as well as asset-specific risks. The Company’s historical losses related to contract assets receivable have been immaterial as evidenced by historical write-offs due to collectability. Asset-specific risk included the evaluation of relevant available information, from internal and external sources, relating to current conditions that may affect a customer’s ability to pay once invoiced, such as the customer’s financial condition, credit rating by geographic location as provided by a third party and/or by customer, if needed, and the overall macro-economic conditions in which the customer operates. The Company pooled assets by geographic location to determine if an allowance should be applied to its contract asset balance, assessing the specific country risk rating and the overall economics of that particular country. If elevated risk existed, or customer specific risk indicated the contract balance was at risk, the Company further analyzed the need for an allowance related to specific customer balances. Additionally, the Company determined that significant changes to customer country risk rating from period-to-period and from the end of the prior year to the end of the current quarter would be subject to further review and analysis by the Company.

- changed (2023-08-14):
[0000950170-23-042449:note_history:95]
No allowance for credit losses was recorded for the three months ended June 30, 2023 and 2022 related to contract assets.
  (was, 2023-05-10, similarity 0.9604):
[0000950170-23-020333:note_history:95]
No allowance for credit losses was recorded for the three months ended March 31, 2023 and 2022 related to contract assets.

- removed (2023-08-14):
[0000950170-23-020333:note_history:96]
|  |  | Three Months Ended |  |
|  |  | March 31, 2023 |  |  | March 31, 2022 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Subscriber Solutions |  | $ | 70,287 |  |  | $ | 9,049 |  |  | $ | 79,336 |  |  | $ | 52,390 |  |  | $ | 4,332 |  |  | $ | 56,722 |  |
| Access & Aggregation Solutions |  |  | 84,554 |  |  |  | 12,266 |  |  |  | 96,820 |  |  |  | 85,984 |  |  |  | 11,812 |  |  |  | 97,796 |  |
| Optical Networking Solutions |  |  | 127,577 |  |  |  | 20,179 |  |  |  | 147,756 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 282,418 |  |  | $ | 41,494 |  |  | $ | 323,912 |  |  | $ | 138,374 |  |  | $ | 16,144 |  |  | $ | 154,518 |  |

- removed (2023-08-14):
[0000950170-23-020333:note_history:97]
Of the outstanding unearned revenue balances as of December 31, 2022, $25.6 million was recognized as revenue during the three months ended March 31, 2023. Of the $17.7 million of outstanding unearned revenue balances as of December 31, 2021, $5.4 million was recognized as revenue during the three months ended March 31, 2022.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2023-08-14):
[0000950170-23-042449:note_history:98]
On August 6, 2023, the Company announced that its Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to the Company’s stockholders of record as of the close of business on August 21, 2023. The payment date will be September 5, 2023 in the aggregate amount of approximately $7.1 million.
  (was, 2023-05-10, similarity 0.9484):
[0000950170-23-020333:note_history:98]
On May 8, 2023, the Company announced that its Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to the Company’s stockholders of record as of the close of business on May 23, 2023. The payment date will be June 6, 2023 in the aggregate amount of approximately $7.1 million.

- added (2023-08-14):
[0000950170-23-042449:note_history:99]
Wells Fargo Credit Agreement Amendment

- added (2023-08-14):
[0000950170-23-042449:note_history:100]
On August 9, 2023, the Company, its wholly-owned direct subsidiary, ADTRAN, Inc., the lenders party thereto and the Administrative Agent entered into a First Amendment to the Credit Agreement (the “First Amendment”).

- added (2023-08-14):
[0000950170-23-042449:note_history:101]
The First Amendment, among other things, provides for:

- added (2023-08-14):
[0000950170-23-042449:note_history:102]
•
a new $50 million delayed draw term loan A tranche (“DDTL”), which is available for borrowing in the event of the purchase by the Company of at least sixty percent (60%) of the outstanding shares of Adtran Networks that are not currently owned by the Company (such event, a “Springing Covenant Event”). Proceeds of the DDTL may only be used to repurchase minority shares of Adtran Networks. The DDTL remains available for borrowing from the occurrence of a Springing Covenant Event through the period that is three consecutive fiscal quarters thereafter;

- added (2023-08-14):
[0000950170-23-042449:note_history:103]
•
a revised applicable margin, which varies based on consolidated total net leverage ratio and ranges from, (a) in the case of revolving loans, (i) 1.65%, with respect to term SOFR loans, to 2.65%, (ii) 1.75%, with respect to EURIBOR loans, to 2.75% and (iii) 0.65%, with respect to base rate loans (including swingline loans) to 1.65%, and (b) in the case of term loans, ranging from (i) 1.90%, with respect to term SOFR loans, to 2.90% and (ii) 0.90%, with respect to Base Rate Loans, to 1.90% (each as defined in the First Amendment to the Credit Agreement);

- added (2023-08-14):
[0000950170-23-042449:note_history:104]
•
a revised commitment fee, which varies based on consolidated total net leverage ratio and ranges from 0.20% to 0.25% per annum on the average daily unused portion of the revolving credit commitment of the revolving credit lenders (other than the defaulting lenders, if any) (each as defined in the credit agreement); and

- added (2023-08-14):
[0000950170-23-042449:note_history:105]
•
revised financial covenants, including (i) the addition of an automatic step up in the consolidated total net leverage ratio to 5.00:1.00 from 3.25:1.00 upon the occurrence of a Springing Covenant Event and continuing for the fiscal quarter in which the Springing Covenant Event occurs and the next three consecutive fiscal quarters thereafter (such period, a “Springing Covenant Period”) and (ii) the addition of a consolidated senior secured net leverage ratio covenant to be tested quarterly during a Springing Covenant Period and sized at 4.00:1.00 during the first quarter ending after a Springing Covenant Event, 3.75:1.00 during the second quarter ending after a Springing Covenant Event and 3.50:1.00 during the third and fourth quarters ending after a Springing Covenant Event. Further, if the Company or any of its subsidiaries incurs unsecured indebtedness under the uncapped general indebtedness basket or permitted convertible indebtedness basket of the Credit Agreement in excess of $50 million in connection with a transaction that is a Springing Covenant Event or during a Springing Covenant Period, then the maximum consolidated senior secured net leverage ratio shall be, or shall automatically step down to, 3.50:1.00 at the time of such incurrence.

- added (2023-08-14):
[0000950170-23-042449:note_history:106]
The First Amendment further added additional financial flexibility by amending the $30 million external debt capped basket to be an unlimited amount and permitting, subject to certain requirements, the incurrence of convertible indebtedness by the Company in an aggregate principal amount of up to $172.5 million. Any such convertible indebtedness must be incurred in pro forma compliance with the financial covenants in the Credit Agreement, unsecured and otherwise rank junior to borrowings under the Credit Agreement, and have a stated maturity date of at least 91 days after the latest scheduled maturity date of loans and commitments under the Credit Agreement. Net cash proceeds from any incurrence of convertible indebtedness must be used to repurchase minority shares of Adtran Networks or repay revolver borrowings under the Credit Agreement.

- added (2023-08-14):
[0000950170-23-042449:note_history:107]
Lastly, the First Amendment added market environmental, social and governance provisions and extended the required delivery date of the financial statements of the Company and its subsidiaries for the fiscal quarter ended June 30, 2023 to August 18, 2023.

- removed (2023-08-14):
[0000950170-23-020333:note_history:108]
Appointment of Ulrich Dopfer as Principal Accounting Officer

- removed (2023-08-14):
[0000950170-23-020333:note_history:109]
As previously disclosed on the Company’s Form 8-K filed on March 30, 2023, Michael Foliano, formerly Senior Vice President of Finance and Chief Financial Officer of the Company, notified the Company of his intent to retire, effective June 28, 2023. Mr. Foliano served in his role as Chief Financial Officer of the Company through April 30, 2023. In connection with his transition, the Board of Directors appointed Ulrich Dopfer as Senior Vice President and Chief Financial Officer of the Company, effective May 1, 2023; however, Mr. Foliano continued to serve as the Company’s “principal accounting officer” within the meaning of the rules of the SEC under the Exchange Act (the “Principal Accounting Officer”), and as the Company’s Treasurer and Secretary. On May 10, 2023, the Board of Directors removed Mr. Foliano from such roles, designated Mr. Dopfer as the Company’s Principal Accounting Officer, and elected Mr. Dopfer as Treasurer and Secretary of the Company, effective as of such date.

- removed (2023-08-14):
[0000950170-23-020333:note_history:110]
ADVA Legal Matter

- removed (2023-08-14):
[0000950170-23-020333:note_history:111]
On May 8, 2023, ADVA and its U.S. subsidiary, ADVA Optical Networking North America Inc., filed a lawsuit in the U.S District Court for the Eastern District of Texas against Huawei Technologies Co. Ltd (“Huawei”) seeking a declaration from the court that Huawei violated contractual commitments to negotiate in good faith and to license patents, to the extent any patents are practiced by ADVA, on Fair, Reasonable and Non-Discriminatory (“FRAND”) terms and conditions. The case also seeks to obtain a ruling by the court that ADVA has complied with its own commitments and requests that the Court establish FRAND terms and conditions for obtaining a FRAND license on any standard essential patents that ADVA does in fact practice. The lawsuit also seeks to enjoin Huawei from enforcing certain of its patents against ADVA and its affiliates in other jurisdictions, and includes allegations by ADVA that it does not infringe five Huawei patents and that Huawei has infringed an ADVA patent. Huawei has not yet filed an answer in this matter. Given the current status of this matter, the Company is unable predict the outcome of or estimate the possible loss or range of loss, if any, associated with such legal matters.
