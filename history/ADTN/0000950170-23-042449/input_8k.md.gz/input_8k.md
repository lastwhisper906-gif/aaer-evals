# ADTN 8-K — 0001193125-23-204377 filed 2023-08-07

## item codes, every 8-K on or before 2023-08-14

- 2023-08-14 0001193125-23-212439 — 2.02, 9.01 — amendment of 0001193125-23-204377
- 2023-08-10 0001193125-23-209039 — 4.02, 9.01
- 2023-08-10 0001193125-23-209024 — 2.02, 9.01 — amendment of 0001193125-23-204377
- 2023-08-07 0001193125-23-204377 — 2.02, 7.01, 9.01
- 2023-06-28 0001193125-23-177593 — 5.02, 9.01
- 2023-06-01 0001193125-23-158986 — 5.02, 9.01
- 2023-05-30 0001193125-23-156741 — 5.02
- 2023-05-15 0000950170-23-021860 — 5.07, 9.01
- 2023-05-09 0000950170-23-019145 — 2.02, 9.01
- 2023-04-11 0001193125-23-097240 — 2.02, 9.01
- 2023-04-03 0001193125-23-089517 — 5.02, 9.01
- 2023-03-30 0001193125-23-085151 — 5.02, 9.01
- 2023-02-21 0000950170-23-003277 — 2.02, 9.01
- 2023-02-08 0001193125-23-028386 — 1.02, 9.01
- 2023-01-26 0001193125-23-016354 — 5.02, 9.01
- 2023-01-19 0001193125-23-010702 — 8.01, 9.01
- 2022-12-05 0001193125-22-298171 — 1.01, 9.01
- 2022-11-09 0000950170-22-023662 — 2.02 — amendment of 0000950170-22-022906
- 2022-11-08 0000950170-22-022906 — 2.02, 9.01
- 2022-10-26 0001193125-22-269383 — 8.01
- 2022-10-25 0001193125-22-268261 — 2.02, 9.01 — amendment, the index does not say of what
- 2022-10-25 0001193125-22-267712 — 2.02, 9.01
- 2022-10-18 0001193125-22-264344 — 8.01, 9.01
- 2022-09-30 0000950170-22-019126 — 5.02, 9.01 — amendment of 0001193125-22-195093
- 2022-08-04 0000950170-22-014476 — 2.02, 9.01
- 2022-07-22 0001193125-22-200018 — 1.01, 1.02, 2.03, 9.01
- 2022-07-15 0001193125-22-195093 — 2.01, 5.02, 9.01
- 2022-07-08 0001193125-22-190213 — 2.01, 3.01, 3.03, 5.01, 5.02, 5.03, 7.01, 9.01
- 2022-07-07 0001193125-22-188934 — 7.01, 9.01
- 2022-06-30 0001193125-22-186294 — 5.04, 9.01
- 2022-05-23 0000950170-22-010455 — 1.01, 2.03, 9.01
- 2022-05-13 0000950170-22-009818 — 5.07
- 2022-05-05 0000950170-22-007563 — 2.02, 9.01
- 2022-04-06 0000950170-22-005405 — 1.01, 2.03, 9.01
- 2022-02-03 0000950170-22-000705 — 2.02, 9.01
- 2022-01-06 0001193125-22-003467 — 5.07, 7.01, 9.01
- 2021-12-28 0001193125-21-368041 — 8.01
- 2021-11-29 0000950170-21-004926 — 5.02, 9.01
- 2021-11-02 0000950170-21-002595 — 7.01, 9.01
- 2021-11-02 0000950170-21-002593 — 2.02, 9.01
- 2021-10-15 0000950170-21-002127 — 2.02, 9.01
- 2021-10-07 0000950170-21-002053 — 5.02
- 2021-09-01 0000950170-21-001615 — 5.02
- 2021-08-30 0001193125-21-260059 — 1.01, 7.01, 9.01
- 2021-08-05 0001564590-21-041127 — 2.02, 9.01
- 2021-05-18 0001564590-21-028541 — 5.07
- 2021-05-06 0001564590-21-024430 — 2.02, 9.01
- 2021-02-26 0001564590-21-009408 — 2.02, 9.01 — amendment of 0001564590-21-004167
- 2021-02-04 0001564590-21-004167 — 2.02, 9.01
- 2020-11-03 0001564590-20-049784 — 2.02, 9.01
- 2020-08-06 0001564590-20-037168 — 2.02, 9.01
- 2020-07-23 0001564590-20-033184 — 5.03, 9.01
- 2020-05-15 0001564590-20-025794 — 5.07
- 2020-05-11 0001564590-20-024328 — 5.02, 9.01
- 2020-05-07 0001564590-20-022297 — 2.02, 9.01
- 2020-02-25 0001564590-20-006448 — 2.02, 9.01
- 2020-02-06 0001564590-20-003580 — 2.02, 9.01
- 2019-10-31 0001564590-19-038936 — 2.02, 9.01
- 2019-10-10 0001564590-19-036732 — 2.02, 9.01
- 2019-09-20 0001564590-19-035144 — 2.02, 9.01
- 2019-08-21 0001564590-19-032757 — 3.01, 9.01
- 2019-07-18 0001564590-19-025186 — 2.02, 9.01
- 2019-05-09 0001564590-19-017956 — 5.07
- 2019-04-18 0001564590-19-011897 — 2.02, 9.01
- 2019-03-07 0001564590-19-006575 — 5.02, 9.01
- 2019-01-24 0001564590-19-001024 — 2.02, 9.01
- 2018-12-06 0001564590-18-030615 — 8.01, 9.01
- 2018-10-17 0001564590-18-024365 — 2.02, 9.01
- 2018-07-18 0001564590-18-016946 — 2.02, 9.01
- 2018-05-10 0001564590-18-012968 — 5.07
- 2018-04-18 0001564590-18-008361 — 2.02, 9.01
- 2018-03-21 0001564590-18-006409 — 8.01, 9.01
- 2018-01-17 0001564590-18-000519 — 2.02, 9.01
- 2017-12-29 0001564590-17-025375 — 2.02, 9.01
- 2017-11-16 0001193125-17-345232 — 5.02
- 2017-10-18 0001564590-17-019582 — 2.02, 9.01
- 2017-07-19 0001564590-17-013609 — 2.02, 9.01
- 2017-05-11 0001564590-17-010459 — 5.02, 9.01
- 2017-05-11 0001564590-17-010452 — 5.07
- 2017-04-19 0001193125-17-127926 — 2.02, 9.01
- 2017-02-07 0001193125-17-032714 — 8.01
- 2017-01-18 0001193125-17-011669 — 2.02, 9.01
- 2016-11-16 0001193125-16-769505 — 5.02, 9.01
- 2016-10-19 0001193125-16-741087 — 2.02, 9.01
- 2016-09-14 0001193125-16-709148 — 8.01, 9.01
- 2016-08-17 0001193125-16-683980 — 5.02, 9.01
- 2016-07-13 0001193125-16-646816 — 2.02, 9.01
- 2016-05-13 0001193125-16-590263 — 5.07
- 2016-04-13 0001193125-16-539019 — 2.02, 9.01
- 2016-04-08 0001193125-16-535035 — 7.01
- 2016-02-11 0001193125-16-459453 — 5.02, 9.01
- 2016-01-20 0001193125-16-432934 — 2.02, 9.01
- 2015-11-16 0001193125-15-378019 — 5.02, 9.01
- 2015-10-14 0001193125-15-343083 — 2.02, 9.01
- 2015-07-16 0001193125-15-254729 — 8.01, 9.01
- 2015-07-15 0001193125-15-253068 — 2.02, 9.01
- 2015-05-15 0001193125-15-189160 — 5.07, 9.01
- 2015-04-22 0001193125-15-140997 — 2.02, 9.01
- 2015-02-23 0001193125-15-056741 — 5.02, 9.01
- 2015-01-21 0001193125-15-015465 — 2.02, 9.01
- 2014-10-15 0001193125-14-372076 — 2.02, 9.01
- 2014-10-03 0001193125-14-363152 — 2.02, 9.01
- 2014-07-16 0001193125-14-269660 — 2.02, 9.01
- 2014-05-20 0001193125-14-205916 — 8.01, 9.01
- 2014-05-20 0001193125-14-205906 — 5.02, 9.01
- 2014-05-15 0001193125-14-201144 — 5.07
- 2014-04-16 0001193125-14-144665 — 2.02, 9.01
- 2014-04-03 0001193125-14-129578 — 2.02, 9.01
- 2014-01-22 0001157523-14-000154 — 2.02, 9.01
- 2013-10-15 0001193125-13-399540 — 5.02
- 2013-10-09 0001157523-13-004657 — 2.02, 9.01
- 2013-07-10 0001157523-13-003290 — 2.02, 9.01
- 2013-05-10 0001193125-13-213728 — 5.07
- 2013-05-03 0001193125-13-198816 — 8.01, 9.01
- 2013-04-10 0001157523-13-001730 — 2.02, 9.01
- 2013-01-16 0001157523-13-000139 — 2.02, 9.01
- 2012-10-10 0001157523-12-005081 — 2.02, 9.01
- 2012-10-03 0001193125-12-413609 — 7.01
- 2012-09-28 0001193125-12-408878 — 2.02, 9.01
- 2012-07-11 0001157523-12-003592 — 2.02, 9.01
- 2012-05-10 0001193125-12-225669 — 5.07
- 2012-05-10 0001193125-12-225639 — 8.01, 9.01
- 2012-04-11 0001157523-12-001772 — 2.02, 9.01
- 2012-03-15 0001193125-12-116494 — 2.02, 9.01
- 2012-01-18 0001157523-12-000174 — 2.02, 9.01
- 2011-12-12 0001193125-11-337271 — 7.01, 9.01
- 2011-10-13 0000950123-11-089785 — 5.03, 9.01
- 2011-10-12 0001157523-11-005682 — 2.02, 9.01
- 2011-07-13 0001157523-11-003986 — 2.02, 9.01
- 2011-05-09 0000950123-11-047191 — 5.02, 5.07, 9.01
- 2011-04-13 0001157523-11-002001 — 2.02, 9.01
- 2011-01-19 0001157523-11-000232 — 2.02, 9.01
- 2010-11-09 0000950123-10-103195 — 5.02, 9.01
- 2010-10-13 0001157523-10-005798 — 2.02, 9.01
- 2010-07-14 0001157523-10-004011 — 2.02, 9.01
- 2010-05-28 0000950123-10-053947 — 5.07
- 2010-04-14 0001157523-10-002022 — 2.02, 9.01
- 2010-01-20 0001157523-10-000200 — 2.02, 9.01
- 2009-10-28 0000950123-09-053984 — 8.01
- 2009-10-14 0001157523-09-006877 — 2.02, 9.01
- 2009-07-15 0001157523-09-004878 — 2.02, 9.01
- 2009-04-15 0001157523-09-002687 — 2.02, 9.01
- 2009-01-21 0001157523-09-000340 — 2.02, 9.01
- 2008-11-12 0001193125-08-233181 — 5.02, 9.01
- 2008-10-14 0001157523-08-007999 — 2.02, 9.01
- 2008-07-15 0001157523-08-005504 — 2.02, 9.01
- 2008-04-15 0001157523-08-002896 — 2.02, 9.01
- 2008-01-22 0001157523-08-000408 — 2.02, 9.01
- 2007-10-16 0001193125-07-219356 — 5.03, 9.01
- 2007-10-16 0001157523-07-009850 — 2.02, 9.01
- 2007-07-17 0001157523-07-006912 — 2.02, 9.01
- 2007-04-17 0001157523-07-003630 — 2.02, 9.01
- 2007-04-03 0001179022-07-000068 — 5.02
- 2007-03-28 0001179022-07-000064 — 5.02
- 2007-02-23 0001193125-07-038337 — 5.02
- 2007-02-23 0001193125-07-038335 — 5.02
- 2007-01-30 0001193125-07-015912 — 5.02, 9.01
- 2007-01-26 0001193125-07-014234 — 5.02
- 2007-01-23 0001157523-07-000494 — 2.02, 9.01 — amendment of 0001157523-07-000481
- 2007-01-23 0001157523-07-000481 — 2.02, 9.01
- 2006-10-17 0001157523-06-009945 — 2.02, 9.01
- 2006-07-18 0001157523-06-006929 — 2.02, 9.01
- 2006-06-08 0001193125-06-126486 — 1.01, 9.01
- 2006-05-10 0001193125-06-107316 — 1.01, 9.01
- 2006-04-18 0001157523-06-003699 — 2.02, 9.01
- 2006-02-03 0001179022-06-000014 — 1.01
- 2006-01-27 0001157523-06-000754 — 5.02, 9.01
- 2006-01-24 0001157523-06-000551 — 2.02, 9.01
- 2005-10-18 0001157523-05-008826 — 2.02, 9.01
- 2005-07-19 0001193125-05-143958 — 1.01, 5.02, 9.01
- 2005-07-19 0001193125-05-143957 — 2.02, 9.01
- 2005-05-20 0001193125-05-112019 — 1.01, 9.01
- 2005-04-19 0001157523-05-003418 — 2.02, 9.01
- 2005-01-25 0001193125-05-010721 — 2.02, 9.01
- 2004-10-12 0001193125-04-169652 — 2.02, 9.01
- 2004-07-13 0001193125-04-116820 — 12, 7
- 2004-04-14 0001193125-04-061547 — 12, 7
- 2004-01-21 0001193125-04-006366 — 12, 7
- 2003-10-14 0001193125-03-061018 — 12, 5, 7
- 2003-07-15 0001193125-03-019292 — 7, 9
- 2003-04-15 0000931763-03-000968 — 7, 9
- 1996-09-12 0000931763-96-000667 — 5, 7

## late-filing notifications on or before 2023-08-14

- 2023-08-10 0001193125-23-209042 — NT 10-Q, for the period ended 2023-06-30
- 2019-08-12 0001564590-19-031524 — NT 10-Q, for the period ended 2019-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001193125-23-204377:8k_2_02:1]
EX-99.1
2
d515639dex991.htm
EX-99.1

[0001193125-23-204377:8k_2_02:2]
EX-99.1

[0001193125-23-204377:8k_2_02:3]
Exhibit 99.1

[0001193125-23-204377:8k_2_02:4]
ADTRAN Holdings, Inc. reports second quarter 2023 results

[0001193125-23-204377:8k_2_02:5]
HUNTSVILLE, AL — (August 06, 2023) — ADTRAN Holdings, Inc. (NASDAQ: ADTN and FSE: QH9) (“ADTRAN Holdings” or the “Company”) today
announced its financial results for the second quarter of 2023. For the quarter, revenue was $327.4 million, up 90% year-over-year and 1% quarter-over-quarter. Net loss attributable to the Company for the second quarter of 2023 was
$33.3 million, down 1,655% year-over-year and up 3% quarter-over-quarter. Consequently, diluted loss per share attributable to the Company for the quarter was $0.43, down by 1,175% year-over-year and up 2% quarter-over-quarter. Non-GAAP net income attributable to the Company was $0.1 million, down 99% year-over-year and up 102% quarter-over-quarter. Consequently, non-GAAP diluted earnings per
share attributable to the Company was $0.00, down 99% year-over-year and up 102% quarter-over-quarter. Non-GAAP net loss and non-GAAP diluted loss per share exclude
acquisition related expenses, amortization, adjustments (consisting of intangible amortization of backlog, developed technology, customer relationships, and trade names acquired in connection with business combinations and amortization of inventory
fair value adjustments), stock-based compensation expense, amortization of pension actuarial losses, deferred compensation adjustments, integration expenses, restructuring expenses, changes in valuation allowance related to our deferred tax assets,
and the tax effect of these adjustments to net (loss) income. The reconciliations between the non-GAAP net loss measures presented herein and the respective equivalent GAAP financial measures are set forth in
the tables provided below.

[0001193125-23-204377:8k_2_02:6]
ADTRAN Holdings Chairman and Chief Executive Officer Tom Stanton stated, “Our Q2 2023 results were in line with our
expectations. Although new customer acquisitions remain near an all-time high, we anticipate the second half of 2023 will continue to present challenges due to customers optimizing inventory and the
macroeconomic environment. Nevertheless, we continue to believe that we are in the early stage of an unprecedented investment cycle and Adtran Holdings is well positioned to be one of the largest beneficiaries.”

[0001193125-23-204377:8k_2_02:7]
The Company also announced that its Board of Directors declared a cash dividend for the second quarter of 2023. The quarterly cash dividend of $0.09 per
common share is to be paid to the Company’s stockholders of record as of the close of business on August 21, 2023. The ex-dividend date is August 20, 2023, and the payment date will be
September 5, 2023.

[0001193125-23-204377:8k_2_02:8]
The Company confirmed that it will hold a conference call to discuss its second quarter results on Tuesday, August 8, 2023,
at 9:30 a.m. Central Time, or 4:30 p.m. Central European Summer Time. ADTRAN Holdings will webcast this conference call. To listen, simply visit our Investor Relations site at investors.adtran.com approximately 10 minutes prior to the start of the
call, click on the event “ADTRAN Holdings Releases 2nd Quarter 2023 Financial Results and Earnings Call”, and click on the webcast link.

[0001193125-23-204377:8k_2_02:9]
An
online replay of the Company’s conference call, as well as the transcript of the Company’s conference call, will be available on the Investor Relations site approximately 24 hours following the call and will remain available for at least
12 months. For more information, visit investors.adtran.com or email investor.relations@adtran.com.

[0001193125-23-204377:8k_2_02:10]
Cautionary Note Regarding Forward-Looking
Statements

[0001193125-23-204377:8k_2_02:11]
Explanation of Use of Non-GAAP Financial Measures

[0001193125-23-204377:8k_2_02:12]
Set forth in the tables below are reconciliations of gross profit, gross margin, operating expenses, operating (loss) income, other income (expense), net
(loss) income inclusive of the non-controlling interest, net (loss) income attributable to the Company, net loss attributable to the non-controlling interest, and (loss)
earnings per share - basic and diluted, attributable to the Company, in each case as reported based on generally accepted accounting principles in the United States (“GAAP”), to non-GAAP gross
profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income (loss),
non-GAAP other (expense) income, non-GAAP net (loss) income inclusive of the non-controlling interest, non-GAAP net income (loss) attributable to the Company, non-GAAP net loss attributable to the non-controlling interest, and non-GAAP earnings (loss) per share - basic and diluted, attributable to the Company, respectively. Such non-GAAP measures exclude acquisition related expenses, amortization
and adjustments (consisting of intangible amortization of backlog, developed technology, customer relationships, and trade names acquired in connection with business combinations and amortization of inventory fair value adjustments), stock-based
compensation expense, amortization of pension actuarial losses, deferred compensation adjustments, integration expenses, restructuring expenses, asset impairments, changes in valuation allowance related to our deferred tax assets, and the tax effect
of these adjustments to net income. These measures are used by management in our ongoing planning and annual budgeting processes. Additionally, we believe the presentation of these non-GAAP measures when
combined with the presentation of the most directly comparable GAAP financial measure, is beneficial to the overall understanding of ongoing operating performance of the Company.

[0001193125-23-204377:8k_2_02:13]
These non-GAAP financial measures are not prepared in accordance with, or an alternative for, GAAP and therefore
should not be considered in isolation or as a substitution for analysis of our results as reported under GAAP. Additionally, our calculation of non-GAAP measures may not be comparable to similar measures
calculated by other companies.

[0001193125-23-204377:8k_2_02:14]
About Adtran

[0001193125-23-204377:8k_2_02:15]
ADTRAN
Holdings, Inc. (NASDAQ: ADTN and FSE: QH9) is the parent company of Adtran, Inc., a leading global provider of open, disaggregated networking and communications solutions that enable voice, data, video and internet communications across any network
infrastructure. From the cloud edge to the subscriber edge, Adtran empowers communications service providers around the world to manage and scale services that connect people, places and things. Adtran solutions are used by service providers,
private enterprises, government organizations and millions of individual users worldwide. ADTRAN Holdings, Inc. is also the largest shareholder of Adtran Networks SE, formerly ADVA Optical Networking SE. Find more at Adtran, LinkedIn and Twitter.

[0001193125-23-204377:8k_2_02:16]
Published by

[0001193125-23-204377:8k_2_02:17]
ADTRAN Holdings, Inc.

[0001193125-23-204377:8k_2_02:18]
www.adtran.com

[0001193125-23-204377:8k_2_02:19]
For media

[0001193125-23-204377:8k_2_02:20]
Gareth Spence

[0001193125-23-204377:8k_2_02:21]
+44 1904 699 358

[0001193125-23-204377:8k_2_02:22]
public-relations@adva.com

[0001193125-23-204377:8k_2_02:23]
For investors

[0001193125-23-204377:8k_2_02:24]
Steven Williams

[0001193125-23-204377:8k_2_02:25]
+49 89 890 665 918

[0001193125-23-204377:8k_2_02:26]
investor.relations@adtran.com

[0001193125-23-204377:8k_2_02:27]
Condensed Consolidated Balance Sheets

[0001193125-23-204377:8k_2_02:28]
(Unaudited)

[0001193125-23-204377:8k_2_02:29]
(In
thousands)

[0001193125-23-204377:8k_2_02:30]
|  |  | June 30, |  |  | December 31, |  |
|  |  | 2023 |  |  | 2022 |  |
| Assets |  |  |  |  |  |  |  |  |
| Current Assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 124,294 |  |  | $ | 108,644 |  |
| Short-term investments |  |  | 3,089 |  |  |  | 340 |  |
| Accounts receivable, net |  |  | 239,565 |  |  |  | 279,435 |  |
| Other receivables |  |  | 32,394 |  |  |  | 32,831 |  |
| Inventory, net |  |  | 416,802 |  |  |  | 427,531 |  |
| Prepaid expenses and other current assets |  |  | 33,880 |  |  |  | 33,577 |  |
| Total Current Assets |  |  | 850,024 |  |  |  | 882,358 |  |
| Property, plant and equipment, net |  |  | 115,719 |  |  |  | 110,699 |  |
| Deferred tax assets |  |  | 82,076 |  |  |  | 67,839 |  |
| Goodwill |  |  | 388,163 |  |  |  | 381,724 |  |
| Intangibles, net |  |  | 355,084 |  |  |  | 401,211 |  |
| Other non-current assets |  |  | 60,634 |  |  |  | 66,998 |  |
| Long-term investments |  |  | 31,238 |  |  |  | 32,665 |  |
| Total Assets |  | $ | 1,882,938 |  |  | $ | 1,943,494 |  |
| Liabilities, Redeemable Non-Controlling Interest and Equity |  |  |  |  |  |  |  |  |
| Current Liabilities |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 171,735 |  |  | $ | 237,699 |  |
| Revolving credit agreements outstanding |  |  | 210,912 |  |  |  | 95,936 |  |
| Notes payable |  |  | — |  |  |  | 24,598 |  |
| Unearned revenue |  |  | 48,030 |  |  |  | 41,193 |  |
| Accrued expenses and other liabilities |  |  | 26,807 |  |  |  | 35,235 |  |
| Accrued wages and benefits |  |  | 36,843 |  |  |  | 44,882 |  |
| Income tax payable, net |  |  | 15,314 |  |  |  | 9,032 |  |
| Total Current Liabilities |  |  | 509,641 |  |  |  | 488,575 |  |
| Deferred tax liabilities |  |  | 44,614 |  |  |  | 61,629 |  |
| Non-current unearned revenue |  |  | 24,111 |  |  |  | 19,239 |  |
| Pension liability |  |  | 10,883 |  |  |  | 10,624 |  |
| Deferred compensation liability |  |  | 28,522 |  |  |  | 26,668 |  |
| Non-current lease obligations |  |  | 20,834 |  |  |  | 22,807 |  |
| Other non-current liabilities |  |  | 16,401 |  |  |  | 10,339 |  |
| Total Liabilities |  |  | 655,006 |  |  |  | 639,881 |  |
| Redeemable Non-Controlling Interest |  |  | 445,462 |  |  |  | — |  |
| Equity |  |  |  |  |  |  |  |  |
| Common stock |  |  | 787 |  |  |  | 781 |  |
| Additional paid-in capital |  |  | 766,428 |  |  |  | 895,834 |  |
| Accumulated other comprehensive income |  |  | 62,208 |  |  |  | 46,713 |  |
| Retained (deficit) earnings |  |  | (41,010 | ) |  |  | 55,338 |  |
| Treasury stock |  |  | (5,943 | ) |  |  | (4,125 | ) |
| Non-controlling interest |  |  | — |  |  |  | 309,072 |  |
| Total Equity |  |  | 782,470 |  |  |  | 1,303,613 |  |
| Total Liabilities, Redeemable Non-Controlling Interest and Equity |  | $ | 1,882,938 |  |  | $ | 1,943,494 |  |

[0001193125-23-204377:8k_2_02:31]
Condensed Consolidated Statements of (Loss) Income

[0001193125-23-204377:8k_2_02:32]
(Unaudited)

[0001193125-23-204377:8k_2_02:33]
(In
thousands, except per share amounts)

[0001193125-23-204377:8k_2_02:34]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
|  |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Network Solutions |  | $ | 283,002 |  |  | $ | 155,992 |  |  | $ | 565,420 |  |  | $ | 294,366 |  |
| Services & Support |  |  | 44,376 |  |  |  | 16,046 |  |  |  | 85,870 |  |  |  | 32,190 |  |
| Total Revenue |  |  | 327,378 |  |  |  | 172,038 |  |  |  | 651,290 |  |  |  | 326,556 |  |
| Cost of Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Network Solutions |  |  | 216,960 |  |  |  | 99,921 |  |  |  | 436,090 |  |  |  | 190,575 |  |
| Services & Support |  |  | 17,865 |  |  |  | 9,611 |  |  |  | 34,839 |  |  |  | 19,159 |  |
| Total Cost of Revenue |  |  | 234,825 |  |  |  | 109,532 |  |  |  | 470,929 |  |  |  | 209,734 |  |
| Gross Profit |  |  | 92,553 |  |  |  | 62,506 |  |  |  | 180,361 |  |  |  | 116,822 |  |
| Selling, general and administrative expenses |  |  | 66,583 |  |  |  | 27,873 |  |  |  | 133,980 |  |  |  | 55,766 |  |
| Research and development expenses |  |  | 70,598 |  |  |  | 26,500 |  |  |  | 140,741 |  |  |  | 52,991 |  |
| Operating (Loss) Income |  |  | (44,628 | ) |  |  | 8,133 |  |  |  | (94,360 | ) |  |  | 8,065 |  |
| Interest and dividend income |  |  | 358 |  |  |  | 217 |  |  |  | 662 |  |  |  | 421 |  |
| Interest expense |  |  | (4,064 | ) |  |  | (94 | ) |  |  | (7,351 | ) |  |  | (124 | ) |
| Net investment gain (loss) |  |  | 1,262 |  |  |  | (4,646 | ) |  |  | 2,514 |  |  |  | (8,061 | ) |
| Other income, net |  |  | 2,494 |  |  |  | 681 |  |  |  | 2,191 |  |  |  | 455 |  |
| (Loss) Income Before Income Taxes |  |  | (44,578 | ) |  |  | 4,291 |  |  |  | (96,344 | ) |  |  | 756 |  |
| Income tax benefit (expense) |  |  | 8,363 |  |  |  | (2,148 | ) |  |  | 19,676 |  |  |  | 260 |  |
| Net (Loss) Income |  | $ | (36,215 | ) |  | $ | 2,143 |  |  | $ | (76,668 | ) |  | $ | 1,016 |  |
| Less: Net Loss attributable to non-controlling interest(1) |  |  | (2,881 | ) |  |  | — |  |  |  | (8,870 | ) |  |  | — |  |
| Net (Loss) Income attributable to ADTRAN Holdings, Inc. |  | $ | (33,334 | ) |  | $ | 2,143 |  |  | $ | (67,798 | ) |  | $ | 1,016 |  |
| Weighted average shares outstanding – basic |  |  | 78,366 |  |  |  | 49,123 |  |  |  | 78,364 |  |  |  | 49,110 |  |
| Weighted average shares outstanding – diluted |  |  | 78,366 |  |  |  | 49,809 |  |  |  | 78,364 |  |  |  | 49,813 |  |
| (Loss) earnings per common share attributable to ADTRAN Holdings, Inc. – basic |  | $ | (0.43 | ) |  | $ | 0.04 |  |  | $ | (0.87 | ) |  | $ | 0.02 |  |
| (Loss) earnings per common share attributable to ADTRAN Holdings, Inc. – diluted |  | $ | (0.43 | ) |  | $ | 0.04 |  |  | $ | (0.87 | ) |  | $ | 0.02 |  |

[0001193125-23-204377:8k_2_02:35]
| (1) | For the three and six months ended June 30, 2023, we have recognized $2.9 million and $5.7 million, respectively, representing the recurring cash compensation earned by non-controlling interest shareholders post-DPLTA and an incremental $3.2 million net loss attributable to non-controlling interests pre-DPLTA for the six months ended June 30, 2023. |

[0001193125-23-204377:8k_2_02:36]
Condensed Consolidated Statements of Cash Flows

[0001193125-23-204377:8k_2_02:37]
(Unaudited)

[0001193125-23-204377:8k_2_02:38]
(In
thousands)

[0001193125-23-204377:8k_2_02:39]
|  |  | Six Months Ended |  |
|  |  | June 30, |  |
|  |  | 2023 |  |  | 2022 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net (loss) income |  | $ | (76,668 | ) |  | $ | 1,016 |  |
| Adjustments to reconcile net loss to net cash (used in) provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 67,467 |  |  |  | 7,235 |  |
| Amortization of debt issuance cost |  |  | 291 |  |  |  | — |  |
| (Gain) loss on investments |  |  | (4,530 | ) |  |  | 7,882 |  |
| Stock-based compensation expense |  |  | 8,103 |  |  |  | 3,781 |  |
| Deferred income taxes |  |  | (31,962 | ) |  |  | (93 | ) |
| Other, net |  |  | 130 |  |  |  | 27 |  |
| Inventory reserves |  |  | 20,885 |  |  |  | (4,296 | ) |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  |  | 40,975 |  |  |  | (14,315 | ) |
| Other receivables |  |  | 561 |  |  |  | 2,606 |  |
| Inventory |  |  | (6,920 | ) |  |  | (53,982 | ) |
| Prepaid expenses, other current assets and other assets |  |  | 7,105 |  |  |  | 671 |  |
| Accounts payable |  |  | (67,923 | ) |  |  | 42,968 |  |
| Accrued expenses and other liabilities |  |  | 110 |  |  |  | 2,179 |  |
| Income taxes payable, net |  |  | 6,216 |  |  |  | (1,597 | ) |
| Net cash used in by operating activities |  |  | (36,160 | ) |  |  | (5,918 | ) |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (20,118 | ) |  |  | (3,285 | ) |
| Proceeds from sales and maturities of available-for-sale investments |  |  | 2,074 |  |  |  | 25,071 |  |
| Purchases of available-for-sale investments |  |  | (580 | ) |  |  | (17,002 | ) |
| Proceeds from beneficial interests in securitized accounts receivable |  |  | 1,156 |  |  |  | — |  |
| Net cash (used in) provided by investing activities |  |  | (17,468 | ) |  |  | 4,784 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Tax withholdings related to stock-based compensation settlements |  |  | (6,315 | ) |  |  | (333 | ) |
| Proceeds from stock option exercises |  |  | 163 |  |  |  | 636 |  |
| Dividend payments |  |  | (14,156 | ) |  |  | (8,877 | ) |
| Proceeds from draw on revolving credit agreements |  |  | 163,729 |  |  |  | 28,000 |  |
| Repayment of revolving credit agreements |  |  | (49,155 | ) |  |  | (28,000 | ) |
| Non-controlling interest put option buyback |  |  | (1,202 | ) |  |  | — |  |
| Repayment of notes payable |  |  | (24,885 | ) |  |  | — |  |
| Net cash provided by (used in) financing activities |  |  | 68,179 |  |  |  | (8,574 | ) |
| Net increase (decrease) in cash and cash equivalents |  |  | 14,551 |  |  |  | (9,708 | ) |
| Effect of exchange rate changes |  |  | 1,099 |  |  |  | (3,742 | ) |
| Cash and cash equivalents, beginning of period |  |  | 108,644 |  |  |  | 56,818 |  |
| Cash and cash equivalents, end of period |  | $ | 124,294 |  |  | $ | 43,368 |  |
| Supplemental disclosure of cash financing activities: |  |  |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 4,719 |  |  | $ | 124 |  |
| Cash used in operating activities related to operating leases |  | $ | 4,502 |  |  | $ | 915 |  |
| Supplemental disclosure of non-cash investing activities: |  |  |  |  |  |  |  |  |
| Right-of-use assets obtained in exchange for lease obligations |  | $ | 515 |  |  | $ | 552 |  |
| Purchases of property, plant and equipment included in accounts payable |  | $ | 2,662 |  |  | $ | 818 |  |

[0001193125-23-204377:8k_2_02:40]
Supplemental Information

[0001193125-23-204377:8k_2_02:41]
Reconciliation of Gross Profit and Gross Margin to

[0001193125-23-204377:8k_2_02:42]
Non-GAAP Gross Profit and Non-GAAP Gross Margin

[0001193125-23-204377:8k_2_02:43]
(Unaudited)

[0001193125-23-204377:8k_2_02:44]
(In
thousands)

[0001193125-23-204377:8k_2_02:45]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30,2023 |  |  | March 31,2023 |  |  | June 30,2022 |  |  | June 30,2023 |  |  | June 30,2022 |  |
| Total Revenue |  | $ | 327,378 |  |  | $ | 323,912 |  |  | $ | 172,038 |  |  | $ | 651,290 |  |  | $ | 326,556 |  |
| Cost of Revenue |  | $ | 234,825 |  |  | $ | 236,104 |  |  | $ | 109,532 |  |  | $ | 470,929 |  |  | $ | 209,734 |  |
| Acquisition-related expenses, amortization and adjustments(1) |  |  | (33,439 | ) |  |  | (32,578 | ) |  |  | — |  |  |  | (66,017 | ) |  |  | — |  |
| Stock-based compensation expense |  |  | (335 | ) |  |  | (240 | ) |  |  | (162 | ) |  |  | (575 | ) |  |  | (321 | ) |
| Restructuring expenses(2) |  |  | — |  |  |  | (76 | ) |  |  | — |  |  |  | (76 | ) |  |  | — |  |
| Non-GAAP Cost of Revenue |  | $ | 201,051 |  |  | $ | 203,210 |  |  | $ | 109,370 |  |  | $ | 404,261 |  |  | $ | 209,413 |  |
| Gross Profit |  | $ | 92,553 |  |  | $ | 87,808 |  |  | $ | 62,506 |  |  | $ | 180,361 |  |  | $ | 116,822 |  |
| Non-GAAP Gross Profit |  | $ | 126,327 |  |  | $ | 120,702 |  |  | $ | 62,668 |  |  | $ | 247,029 |  |  | $ | 117,143 |  |
| Gross Margin |  |  | 28.3 | % |  |  | 27.1 | % |  |  | 36.3 | % |  |  | 27.7 | % |  |  | 35.8 | % |
| Non-GAAP Gross Margin |  |  | 38.6 | % |  |  | 37.3 | % |  |  | 36.4 | % |  |  | 37.9 | % |  |  | 35.9 | % |

[0001193125-23-204377:8k_2_02:46]
| (1) | Includes intangible amortization of backlog, inventory fair value adjustments, developed technology, customer relationships, and trade names acquired in connection with business combinations. |

[0001193125-23-204377:8k_2_02:47]
| (2) | Includes expenses for restructuring program designed to optimize the assets and business processes following the business combination with Adtran Networks. |

[0001193125-23-204377:8k_2_02:48]
Supplemental Information

[0001193125-23-204377:8k_2_02:49]
Reconciliation of Operating Expenses to Non-GAAP Operating Expenses

[0001193125-23-204377:8k_2_02:50]
(Unaudited)

[0001193125-23-204377:8k_2_02:51]
(In
thousands)

[0001193125-23-204377:8k_2_02:52]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | March 31, |  |  | June 30, |  |  | June 30, |  |  | June 30, |  |
|  |  | 2023 |  |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Operating Expenses |  | $ | 137,181 |  |  | $ | 137,540 |  |  | $ | 54,373 |  |  | $ | 274,721 |  |  | $ | 108,757 |  |
| Acquisition-related expenses, amortization and adjustments |  |  | (4,398 | ) (1) |  |  | (4,584 | ) (6) |  |  | (2,123 | ) (10) |  |  | (8,982 | ) (12) |  |  | (4,453 | ) (16) |
| Stock-based compensation expense |  |  | (3,974 | ) (2) |  |  | (3,458 | ) (7) |  |  | (1,726 | ) (11) |  |  | (7,432 | ) (13) |  |  | (3,460 | ) (17) |
| Restructuring expenses |  |  | (5,868 | ) (3) |  |  | (2,361 | ) (8) |  |  | — |  |  |  | (8,229 | ) (14) |  |  | (2 | ) |
| Pension adjustments |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Integration expenses |  |  | (563 | ) (4) |  |  | (849 | ) (9) |  |  | — |  |  |  | (1,412 | ) (15) |  |  | — |  |
| Deferred compensation adjustments(5) |  |  | 307 |  |  |  | (394 | ) |  |  | 3,737 |  |  |  | (87 | ) |  |  | 6,433 |  |
| Non-GAAP Operating Expenses |  | $ | 122,685 |  |  | $ | 125,894 |  |  | $ | 54,261 |  |  | $ | 248,579 |  |  | $ | 107,275 |  |

[0001193125-23-204377:8k_2_02:53]
| (1) | Includes intangible amortization of developed technology, customer relationships, and trade names acquired in connection with business combinations, of which $3.9 million is included in selling, general and administrative expenses and $0.5 million is included in research and development expenses on the condensed consolidated statements of (loss) income. |

[0001193125-23-204377:8k_2_02:54]
| (2) | $2.7 million is included in selling, general and administrative expenses and $1.3 million is included in research and development expenses on the condensed consolidated statements of (loss) income. |

[0001193125-23-204377:8k_2_02:55]
| (3) | $1.4 million is included in selling, general and administrative expenses and $4.5 million is included in research and development expenses on the condensed consolidated statements of (loss) income. |

[0001193125-23-204377:8k_2_02:56]
| (4) | $0.6 million is included in selling, general and administrative expenses on the condensed consolidated statements of (loss) income. Includes fees relating to the expansion of internal controls at Adtran Networks and the implementation of the DPLTA. |

[0001193125-23-204377:8k_2_02:57]
| (5) | Includes non-cash change in fair value of equity investments held in the ADTRAN Holdings, Inc. Deferred Compensation Program for Employees, all of which is included in selling, general and administrative expenses on the condensed consolidated statement of (loss) income. |

[0001193125-23-204377:8k_2_02:58]
| (6) | Includes intangible amortization of developed technology, customer relationships, and trade names acquired in connection with business combinations, of which $4.1 million is included in selling, general and administrative expenses and $0.5 million is included in research and development expenses on the condensed consolidated statements of (loss) income. |

[0001193125-23-204377:8k_2_02:59]
| (7) | $2.5 million is included in selling, general and administrative expenses and $1.0 million is included in research and development expenses on the condensed consolidated statements of (loss) income. |

[0001193125-23-204377:8k_2_02:60]
| (8) | $2.2 million is included in selling, general and administrative expenses and $0.2 million is included in research and development expenses on the condensed consolidated statements of (loss) income. |

[0001193125-23-204377:8k_2_02:61]
| (9) | $0.8 million is included in selling, general and administrative expenses on the condensed consolidated statements of (loss) income. Includes fees relating to the expansion of internal controls at Adtran Networks and the implementation of the DPLTA. |

[0001193125-23-204377:8k_2_02:62]
| (10) | $1.6 million is included in selling, general and administrative expenses and $0.5 million is included in research and development expenses on the condensed consolidated statements of (loss) income. |

[0001193125-23-204377:8k_2_02:63]
| (11) | $1.1 million is included in selling, general and administrative expenses and $0.6 million is included in research and development expenses on the condensed consolidated statements of (loss) income. |

[0001193125-23-204377:8k_2_02:64]
| (12) | Includes intangible amortization of developed technology, customer relationships, and trade names acquired in connection with business combinations, of which $8.0 million is included in selling, general and administrative expenses and $1.0 million is included in research and development expenses on the condensed consolidated statements of (loss) income. |

[0001193125-23-204377:8k_2_02:65]
| (13) | $5.1 million is included in selling, general and administrative expenses and $2.3 million is included in research and development expenses on the condensed consolidated statements of (loss) income. |

[0001193125-23-204377:8k_2_02:66]
| (14) | $3.5 million is included in selling, general and administrative expenses and $4.7 million is included in research and development expenses on the condensed consolidated statements of (loss) income. |

[0001193125-23-204377:8k_2_02:67]
| (15) | $1.4 million is included in selling, general and administrative expenses on the condensed consolidated statements of (loss) income. Includes fees relating to the expansion of internal controls at Adtran Networks and the implementation of the DPLTA. |

[0001193125-23-204377:8k_2_02:68]
| (16) | Includes intangible amortization of developed technology, customer relationships, and trade names acquired in connection with business combinations, of which $3.4 million is included in selling, general and administrative expenses and $1.0 million is included in research and development expenses on the condensed consolidated statements of (loss) income. |

[0001193125-23-204377:8k_2_02:69]
| (17) | $2.3 million is included in selling, general and administrative expenses and $1.2 million is included in research and development expenses on the condensed consolidated statements of (loss) income. |

[0001193125-23-204377:8k_2_02:70]
Supplemental Information

[0001193125-23-204377:8k_2_02:71]
Reconciliation of Operating (Loss) Income to Non-GAAP Operating Income (Loss)

[0001193125-23-204377:8k_2_02:72]
(Unaudited)

[0001193125-23-204377:8k_2_02:73]
(In
thousands)

[0001193125-23-204377:8k_2_02:74]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | March 30, |  |  | June 30, |  |  | June 30, |  |  | June 30, |  |
|  |  | 2023 |  |  | 2023 |  |  | 2022 |  |  | 2023 |  |  | 2022 |  |
| Operating (Loss) Income |  | $ | (44,628 | ) |  | $ | (49,732 | ) |  | $ | 8,133 |  |  | $ | (94,360 | ) |  | $ | 8,065 |  |
| Acquisition related expenses, amortization and adjustments(1) |  |  | 37,837 |  |  |  | 37,162 |  |  |  | 2,123 |  |  |  | 74,999 |  |  |  | 4,453 |  |
| Stock-based compensation expense |  |  | 4,309 |  |  |  | 3,698 |  |  |  | 1,888 |  |  |  | 8,007 |  |  |  | 3,781 |  |
| Pension adjustments |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Restructuring expenses(2) |  |  | 5,868 |  |  |  | 2,437 |  |  |  | — |  |  |  | 8,305 |  |  |  | 2 |  |
| Integration expenses |  |  | 563 |  |  |  | 849 |  |  |  | — |  |  |  | 1,412 |  |  |  | — |  |
| Deferred compensation adjustments(3) |  |  | (307 | ) |  |  | 394 |  |  |  | (3,737 | ) |  |  | 87 |  |  |  | (6,433 | ) |
| Non-GAAP Operating Income (Loss) |  | $ | 3,642 |  |  | $ | (5,192 | ) |  | $ | 8,407 |  |  | $ | (1,550 | ) |  | $ | 9,868 |  |

[0001193125-23-204377:8k_2_02:75]
| (1) | Includes intangible amortization of backlog, inventory fair value adjustments, developed technology, customer relationships, and trade names acquired in connection with business combinations. |

[0001193125-23-204377:8k_2_02:76]
| (2) | Includes expenses for restructuring program designed to optimize the assets and business processes following the business combination with Adtran Networks. |

[0001193125-23-204377:8k_2_02:77]
| (3) | Includes non-cash change in fair value of equity investments held in the ADTRAN Holdings, Inc. Deferred Compensation Program for Employees, all of which is included in selling, general and administrative expenses on the condensed consolidated statement of (loss) income. |

[0001193125-23-204377:8k_2_02:78]
Supplemental Information

[0001193125-23-204377:8k_2_02:79]
Reconciliation of Other Income (Expense) to Non-GAAP Other Expense

[0001193125-23-204377:8k_2_02:80]
(Unaudited)

[0001193125-23-204377:8k_2_02:81]
(In
thousands)

[0001193125-23-204377:8k_2_02:82]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30,2023 |  |  | March 31,2023 |  |  | June 30,2022 |  |  | June 30,2023 |  |  | June 30,2022 |  |
| Interest and dividend income |  | $ | 358 |  |  | $ | 304 |  |  | $ | 217 |  |  | $ | 662 |  |  | $ | 421 |  |
| Interest expense |  |  | (4,064 | ) |  |  | (3,287 | ) |  |  | (94 | ) |  |  | (7,351 | ) |  |  | (124 | ) |
| Net investment gain (loss) |  |  | 1,262 |  |  |  | 1,252 |  |  |  | (4,646 | ) |  |  | 2,514 |  |  |  | (8,061 | ) |
| Other income (expense), net |  |  | 2,494 |  |  |  | (303 | ) |  |  | 681 |  |  |  | 2,191 |  |  |  | 455 |  |
| Total Other Income (Expense) |  | $ | 50 |  |  | $ | (2,034 | ) |  | $ | (3,842 | ) |  | $ | (1,984 | ) |  | $ | (7,309 | ) |
| Deferred compensation adjustments (1) |  |  | (1,254 | ) |  |  | (1,250 | ) |  |  | 3,596 |  |  |  | (2,504 | ) |  |  | 5,437 |  |
| Pension expense(2) |  |  | 6 |  |  |  | 7 |  |  |  | 85 |  |  |  | 13 |  |  |  | 174 |  |
| Non-GAAP Other Expense |  | $ | (1,198 | ) |  | $ | (3,277 | ) |  | $ | (161 | ) |  | $ | (4,475 | ) |  | $ | (1,698 | ) |

[0001193125-23-204377:8k_2_02:83]
| (1) | Includes non-cash change in fair value of equity investments held in the ADTRAN Holdings, Inc. Deferred Compensation Program for Employees. |

[0001193125-23-204377:8k_2_02:84]
| (2) | Includes amortization of actuarial losses related to the Company’s pension plan for employees in certain foreign countries. |

[0001193125-23-204377:8k_2_02:85]
Supplemental Information

[0001193125-23-204377:8k_2_02:86]
Reconciliation of Net (Loss) Income inclusive of Non-Controlling Interest to

[0001193125-23-204377:8k_2_02:87]
Non-GAAP Net (Loss) Income inclusive of Non-Controlling
Interest

[0001193125-23-204377:8k_2_02:88]
(Unaudited)

[0001193125-23-204377:8k_2_02:89]
and

[0001193125-23-204377:8k_2_02:90]
Reconciliation of
Net Loss attributable to Non-Controlling Interest to

[0001193125-23-204377:8k_2_02:91]
Non-GAAP Net Loss attributable to Non-Controlling Interest

[0001193125-23-204377:8k_2_02:92]
(Unaudited)

[0001193125-23-204377:8k_2_02:93]
and

[0001193125-23-204377:8k_2_02:94]
Reconciliation of
Net (Loss) Income attributable to ADTRAN Holdings, Inc. and

[0001193125-23-204377:8k_2_02:95]
(Loss) Earnings per Common Share attributable to ADTRAN Holdings, Inc.
– Basic and Diluted to

[0001193125-23-204377:8k_2_02:96]
Non-GAAP Net Income (Loss) attributable to ADTRAN Holdings, Inc.
and

[0001193125-23-204377:8k_2_02:97]
Non-GAAP Earnings (Loss) per Common Share attributable to ADTRAN Holdings, Inc. –
Basic and Diluted

[0001193125-23-204377:8k_2_02:98]
(Unaudited)

[0001193125-23-204377:8k_2_02:99]
(In thousands, except per share amounts)

[0001193125-23-204377:8k_2_02:100]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30,2023 |  |  | March 31,2023 |  |  | June 30,2022 |  |  | June 30,2023 |  |  | June 30,2022 |  |
| Net (Loss) Income attributable to ADTRAN Holdings, Inc. |  | $ | (33,334 | ) |  | $ | (34,464 | ) |  | $ | 2,143 |  |  | $ | (67,798 | ) |  | $ | 1,016 |  |
| Plus: Net Loss attributable to non-controlling interest (1) |  |  | (2,881 | ) |  |  | (5,989 | ) |  |  | — |  |  |  | (8,870 | ) |  |  | — |  |
| Net (Loss) Income inclusive of non-controlling interest |  | $ | (36,215 | ) |  | $ | (40,453 | ) |  | $ | 2,143 |  |  | $ | (76,668 | ) |  | $ | 1,016 |  |
| Acquisition related expenses, amortization and adjustments |  |  | 37,837 |  |  |  | 37,162 |  |  |  | 2,123 |  |  |  | 74,999 |  |  |  | 4,453 |  |
| Asset impairments |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Stock-based compensation expense |  |  | 4,309 |  |  |  | 3,698 |  |  |  | 1,888 |  |  |  | 8,007 |  |  |  | 3,781 |  |
| Valuation allowance |  |  | (185 | ) |  |  | — |  |  |  | 4,289 |  |  |  | (185 | ) |  |  | 12,368 |  |
| Deferred compensation adjustments (2) |  |  | (1,561 | ) |  |  | (856 | ) |  |  | (140 | ) |  |  | (2,417 | ) |  |  | (995 | ) |
| Pension adjustments (3) |  |  | 6 |  |  |  | 7 |  |  |  | 85 |  |  |  | 13 |  |  |  | 174 |  |
| Restructuring expenses |  |  | 5,868 |  |  |  | 2,437 |  |  |  | — |  |  |  | 8,305 |  |  |  | 2 |  |
| Integration expenses |  |  | 563 |  |  |  | 849 |  |  |  | — |  |  |  | 1,412 |  |  |  | — |  |
| Tax effect of adjustments to net (loss) income |  |  | (13,426 | ) |  |  | (12,307 | ) |  |  | (680 | ) |  |  | (25,733 | ) |  |  | (1,185 | ) |
| Non-GAAP Net (Loss) Income inclusive of non-controlling interest |  | $ | (2,804 | ) |  | $ | (9,463 | ) |  | $ | 9,708 |  |  | $ | (12,267 | ) |  | $ | 19,614 |  |
| Less: Non-GAAP Net Loss attributable to non-controlling interest (1) |  |  | (2,881 | ) |  |  | (4,460 | ) |  |  | — |  |  |  | (7,341 | ) |  |  | — |  |
| Non-GAAP Net Income (Loss) attributable to ADTRAN Holdings, Inc. |  | $ | 77 |  |  | $ | (5,003 | ) |  | $ | 9,708 |  |  | $ | (4,926 | ) |  | $ | 19,614 |  |
| GAAP Net Loss attributable to non-controlling interest (1) |  | $ | (2,881 | ) |  | $ | (5,989 | ) |  | $ | — |  |  | $ | (8,870 | ) |  | $ | — |  |
| Acquisition related expenses, amortization and adjustments |  |  | — |  |  |  | 1,457 |  |  |  | — |  |  |  | 1,457 |  |  |  | — |  |
| Restructuring expenses |  |  | — |  |  |  | 29 |  |  |  | — |  |  |  | 29 |  |  |  | — |  |
| Integration expenses |  |  | — |  |  |  | 6 |  |  |  | — |  |  |  | 6 |  |  |  | — |  |
| Stock-based compensation expense |  |  | — |  |  |  | 37 |  |  |  | — |  |  |  | 37 |  |  |  | — |  |
| Pension adjustments |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Non-GAAP Net Loss attributable to non-controlling interest(1) |  | $ | (2,881 | ) |  | $ | (4,460 | ) |  | $ | — |  |  | $ | (7,341 | ) |  | $ | — |  |
| Weighted average shares outstanding – basic |  |  | 78,366 |  |  |  | 78,358 |  |  |  | 49,123 |  |  |  | 78,364 |  |  |  | 49,110 |  |
| Weighted average shares outstanding – diluted |  |  | 78,366 |  |  |  | 78,358 |  |  |  | 49,809 |  |  |  | 78,364 |  |  |  | 49,813 |  |
| (Loss) Earnings per common share attributable to ADTRAN Holdings, Inc. – basic |  | $ | (0.43 | ) |  | $ | (0.44 | ) |  | $ | 0.04 |  |  | $ | (0.87 | ) |  | $ | 0.02 |  |
| (Loss) Earnings per common share attributable to ADTRAN Holdings, Inc. – diluted |  | $ | (0.43 | ) |  | $ | (0.44 | ) |  | $ | 0.04 |  |  | $ | (0.87 | ) |  | $ | 0.02 |  |
| Non-GAAP Earnings (Loss) per common share attributable to ADTRAN – basic |  | $ | 0.00 |  |  | $ | (0.06 | ) |  | $ | 0.20 |  |  | $ | (0.06 | ) |  | $ | 0.40 |  |
| Non-GAAP Earnings (Loss) per common share attributable to ADTRAN – diluted |  | $ | 0.00 |  |  | $ | (0.06 | ) |  | $ | 0.19 |  |  | $ | (0.06 | ) |  | $ | 0.39 |  |

[0001193125-23-204377:8k_2_02:101]
| (1) | Represents the non-controlling interest portion of the Company’s ownership of Adtran Networks pre-DPLTA and the annual recurring compensation earned by redeemable non-controlling interests and accrued by the Company post-DPLTA. |

[0001193125-23-204377:8k_2_02:102]
| (2) | Includes non-cash change in fair value of equity investments held in deferred compensation plans offered to certain employees. |

[0001193125-23-204377:8k_2_02:103]
| (3) | Includes amortization of actuarial losses related to the Company’s pension plan for employees in certain foreign countries. |
