# ADTN 10-Q controls and the auditor's report


## item_4_controls

[0000950170-23-042449:item_4_controls:1]
ITEM 4. CONTROLS AND PROCEDURES

[0000950170-23-042449:item_4_controls:2]
Evaluation of Disclosure Controls and Procedures

[0000950170-23-042449:item_4_controls:3]
We maintain disclosure controls and procedures that are designed to ensure that the information required to be disclosed by us in reports that we file or submit under the Securities Exchange Act of 1934, as amended (the “Exchange Act”), is recorded, processed, summarized and reported within the time periods specified in the rules and forms promulgated by the SEC, and that such information is accumulated and communicated to our management, including our Chief Executive Officer and our Chief Financial Officer, as appropriate, to allow timely decisions regarding required disclosure.

[0000950170-23-042449:item_4_controls:4]
As of the end of the period covered by this report, an evaluation was carried out by management, including our Chief Executive Officer and Chief Financial Officer, of the effectiveness of our disclosure controls and procedures (as defined in Rules 13a-15(e) and 15d-15(e)) under the Exchange Act. Based on that evaluation, our Chief Executive Officer and Chief Financial Officer concluded that due to the material weakness in our internal control over financial reporting described below, our disclosure controls and procedures were not effective as of June 30, 2023.

[0000950170-23-042449:item_4_controls:5]
Material Weakness in Internal Control over Financial Reporting

[0000950170-23-042449:item_4_controls:6]
A material weakness is a deficiency, or a combination of deficiencies, in internal control over financial reporting, such that there is a reasonable possibility that a material misstatement of our annual or interim financial statements will not be prevented or detected on a timely basis.

[0000950170-23-042449:item_4_controls:7]
We identified that we did not design and maintain effective controls over the presentation and disclosure of debt agreements, specifically to ensure the presentation and disclosure reflect the terms of the agreements. This material weakness resulted in the restatement of our consolidated financial statements for the year ended December 31, 2022, as well as the condensed consolidated financial statements for the three and nine months ended September 30, 2022 and for the three months ended March 31, 2023. Additionally, this material weakness could result in misstatements of the accounts or disclosures that would result in a material misstatement to the annual or interim consolidated financial statements that would not be prevented or detected.

[0000950170-23-042449:item_4_controls:8]
Management’s Remediation Efforts

[0000950170-23-042449:item_4_controls:9]
To remediate the material weakness in our internal control over financial reporting, our management plans to initiate a remediation plan that includes implementing a new control over the review of new or amendments to our agreements for terms and conditions that impact the presentation or disclosure of debt. We believe that the foregoing actions will support the improvement of the Company’s internal control over financial reporting, and, through our efforts to identify, design, and implement the necessary control activities, will be effective in remediating the material weakness described above. We will continue to devote significant time and attention to these remediation efforts. As we continue to evaluate and work to improve our internal control over financial reporting, management may determine to take additional measures to address the material weakness or determine to modify the remediation plan described above. Until the remediation steps set forth above, including the efforts to implement the necessary control activities that we identify, are fully completed, and there has been time for us to conclude through testing that the control activities are operating effectively, the material weakness described above will not be considered remediated.

[0000950170-23-042449:item_4_controls:10]
Changes in Internal Control over Financial Reporting.

[0000950170-23-042449:item_4_controls:11]
On July 15, 2022, the Company acquired 33,957,538 bearer shares of Adtran Networks (formerly known as ADVA Optical Networking SE), or 65.43% of Adtran Networks outstanding bearer shares as of such date, as further described in Note 2 of the Notes to the Condensed Consolidated Financial Statements. On June 30, 2023, Adtran Networks assets represented approximately 41.0% of our consolidated assets. For the three and six months ended June 30, 2023, Adtran Networks revenues represented approximately 57.0% and 58.2% of our consolidated revenues, respectively and loss before income taxes represented approximately 71.1% and 70.0% of our consolidated loss before income taxes, respectively. As permitted by SEC guidance, we currently exclude Adtran Networks in our evaluation of internal control over financial reporting and related disclosure controls and procedures for the first year after the Business Combination. However, we are in the process of extending our oversight and monitoring processes that support our internal control over financial reporting and disclosure controls and procedures to include Adtran Networks operations. Other than the extension of our oversight and monitoring processes to include Adtran Networks operations and the ongoing remediation efforts related to the material weakness described above, there were no other changes in the Company’s internal control over financial reporting that occurred during the most recent fiscal quarter covered by this report that have materially affected, or are reasonably likely to materially affect, its internal control over financial reporting.

[0000950170-23-042449:item_4_controls:12]
65
