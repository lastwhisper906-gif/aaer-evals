# ADTN 8-K — 0001193125-26-073361 filed 2026-02-26

## item codes, every 8-K on or before 2026-02-26

- 2026-02-26 0001193125-26-073361 — 2.02, 7.01, 9.01
- 2026-01-22 0001193125-26-018367 — 2.02, 7.01, 9.01
- 2025-12-11 0001193125-25-315910 — 5.02, 9.01
- 2025-11-04 0001193125-25-263524 — 2.02, 7.01, 9.01
- 2025-09-22 0001193125-25-211271 — 1.01, 2.03, 3.02, 9.01
- 2025-09-17 0001193125-25-205483 — 1.01, 8.01, 9.01
- 2025-08-05 0000950170-25-102401 — 2.02, 7.01, 9.01
- 2025-07-30 0000950170-25-100222 — 5.07, 8.01, 9.01
- 2025-07-17 0000950170-25-096408 — 2.02, 7.01, 9.01 — amendment of 0000950170-25-096231
- 2025-07-16 0000950170-25-096231 — 2.02, 7.01, 9.01
- 2025-05-28 0000950170-25-077995 — 2.02, 9.01
- 2025-05-27 0001193125-25-127878 — 8.01, 9.01
- 2025-05-13 0000950170-25-070473 — 4.02, 8.01, 9.01
- 2025-05-12 0000950170-25-069478 — 1.01, 9.01
- 2025-05-08 0000950170-25-066343 — 2.02, 7.01, 9.01
- 2025-04-16 0001193125-25-081800 — 7.01, 9.01
- 2025-03-07 0001193125-25-048727 — 5.02, 7.01, 9.01
- 2025-02-27 0000950170-25-028352 — 2.02, 7.01, 9.01
- 2024-11-07 0000950170-24-122762 — 2.02, 7.01, 9.01
- 2024-08-30 0000950170-24-102309 — 5.02, 9.01
- 2024-08-06 0000950170-24-091207 — 2.02, 7.01, 9.01
- 2024-08-02 0000950170-24-089974 — 5.02
- 2024-06-10 0001193125-24-158388 — 1.01, 2.03, 9.01
- 2024-05-09 0000950170-24-056830 — 5.02, 5.07, 9.01
- 2024-05-07 0000950170-24-053920 — 2.02, 7.01, 9.01
- 2024-05-03 0001193125-24-130896 — 2.02, 7.01, 9.01
- 2024-04-17 0000950170-24-045151 — 2.05, 9.01
- 2024-03-15 0000950170-24-031864 — 2.02, 9.01
- 2024-02-27 0000950170-24-020613 — 2.02, 7.01, 9.01
- 2024-02-20 0001193125-24-040068 — 4.02
- 2024-01-22 0001193125-24-011697 — 1.01, 2.03, 9.01
- 2023-12-06 0001193125-23-289895 — 5.02, 9.01
- 2023-12-05 0001193125-23-289150 — 5.02, 9.01
- 2023-11-07 0001193125-23-271842 — 2.02, 7.01, 9.01
- 2023-10-24 0001193125-23-261665 — 5.02, 5.03, 9.01
- 2023-10-17 0001193125-23-257289 — 2.02, 7.01, 9.01
- 2023-09-29 0001193125-23-246498 — 5.02
- 2023-08-14 0001193125-23-212439 — 2.02, 9.01 — amendment of 0001193125-23-204377
- 2023-08-10 0001193125-23-209039 — 4.02, 9.01
- 2023-08-10 0001193125-23-209024 — 2.02, 9.01 — amendment of 0001193125-23-204377
- 2023-08-07 0001193125-23-204377 — 2.02, 7.01, 9.01
- 2023-06-28 0001193125-23-177593 — 5.02, 9.01
- 2023-06-01 0001193125-23-158986 — 5.02, 9.01
- 2023-05-30 0001193125-23-156741 — 5.02
- 2023-05-15 0000950170-23-021860 — 5.07, 9.01
- 2023-05-09 0000950170-23-019145 — 2.02, 9.01
- 2023-04-11 0001193125-23-097240 — 2.02, 9.01
- 2023-04-03 0001193125-23-089517 — 5.02, 9.01
- 2023-03-30 0001193125-23-085151 — 5.02, 9.01
- 2023-02-21 0000950170-23-003277 — 2.02, 9.01
- 2023-02-08 0001193125-23-028386 — 1.02, 9.01
- 2023-01-26 0001193125-23-016354 — 5.02, 9.01
- 2023-01-19 0001193125-23-010702 — 8.01, 9.01
- 2022-12-05 0001193125-22-298171 — 1.01, 9.01
- 2022-11-09 0000950170-22-023662 — 2.02 — amendment of 0000950170-22-022906
- 2022-11-08 0000950170-22-022906 — 2.02, 9.01
- 2022-10-26 0001193125-22-269383 — 8.01
- 2022-10-25 0001193125-22-268261 — 2.02, 9.01 — amendment, the index does not say of what
- 2022-10-25 0001193125-22-267712 — 2.02, 9.01
- 2022-10-18 0001193125-22-264344 — 8.01, 9.01
- 2022-09-30 0000950170-22-019126 — 5.02, 9.01 — amendment of 0001193125-22-195093
- 2022-08-04 0000950170-22-014476 — 2.02, 9.01
- 2022-07-22 0001193125-22-200018 — 1.01, 1.02, 2.03, 9.01
- 2022-07-15 0001193125-22-195093 — 2.01, 5.02, 9.01
- 2022-07-08 0001193125-22-190213 — 2.01, 3.01, 3.03, 5.01, 5.02, 5.03, 7.01, 9.01
- 2022-07-07 0001193125-22-188934 — 7.01, 9.01
- 2022-06-30 0001193125-22-186294 — 5.04, 9.01
- 2022-05-23 0000950170-22-010455 — 1.01, 2.03, 9.01
- 2022-05-13 0000950170-22-009818 — 5.07
- 2022-05-05 0000950170-22-007563 — 2.02, 9.01
- 2022-04-06 0000950170-22-005405 — 1.01, 2.03, 9.01
- 2022-02-03 0000950170-22-000705 — 2.02, 9.01
- 2022-01-06 0001193125-22-003467 — 5.07, 7.01, 9.01
- 2021-12-28 0001193125-21-368041 — 8.01
- 2021-11-29 0000950170-21-004926 — 5.02, 9.01
- 2021-11-02 0000950170-21-002595 — 7.01, 9.01
- 2021-11-02 0000950170-21-002593 — 2.02, 9.01
- 2021-10-15 0000950170-21-002127 — 2.02, 9.01
- 2021-10-07 0000950170-21-002053 — 5.02
- 2021-09-01 0000950170-21-001615 — 5.02
- 2021-08-30 0001193125-21-260059 — 1.01, 7.01, 9.01
- 2021-08-05 0001564590-21-041127 — 2.02, 9.01
- 2021-05-18 0001564590-21-028541 — 5.07
- 2021-05-06 0001564590-21-024430 — 2.02, 9.01
- 2021-02-26 0001564590-21-009408 — 2.02, 9.01 — amendment of 0001564590-21-004167
- 2021-02-04 0001564590-21-004167 — 2.02, 9.01
- 2020-11-03 0001564590-20-049784 — 2.02, 9.01
- 2020-08-06 0001564590-20-037168 — 2.02, 9.01
- 2020-07-23 0001564590-20-033184 — 5.03, 9.01
- 2020-05-15 0001564590-20-025794 — 5.07
- 2020-05-11 0001564590-20-024328 — 5.02, 9.01
- 2020-05-07 0001564590-20-022297 — 2.02, 9.01
- 2020-02-25 0001564590-20-006448 — 2.02, 9.01
- 2020-02-06 0001564590-20-003580 — 2.02, 9.01
- 2019-10-31 0001564590-19-038936 — 2.02, 9.01
- 2019-10-10 0001564590-19-036732 — 2.02, 9.01
- 2019-09-20 0001564590-19-035144 — 2.02, 9.01
- 2019-08-21 0001564590-19-032757 — 3.01, 9.01
- 2019-07-18 0001564590-19-025186 — 2.02, 9.01
- 2019-05-09 0001564590-19-017956 — 5.07
- 2019-04-18 0001564590-19-011897 — 2.02, 9.01
- 2019-03-07 0001564590-19-006575 — 5.02, 9.01
- 2019-01-24 0001564590-19-001024 — 2.02, 9.01
- 2018-12-06 0001564590-18-030615 — 8.01, 9.01
- 2018-10-17 0001564590-18-024365 — 2.02, 9.01
- 2018-07-18 0001564590-18-016946 — 2.02, 9.01
- 2018-05-10 0001564590-18-012968 — 5.07
- 2018-04-18 0001564590-18-008361 — 2.02, 9.01
- 2018-03-21 0001564590-18-006409 — 8.01, 9.01
- 2018-01-17 0001564590-18-000519 — 2.02, 9.01
- 2017-12-29 0001564590-17-025375 — 2.02, 9.01
- 2017-11-16 0001193125-17-345232 — 5.02
- 2017-10-18 0001564590-17-019582 — 2.02, 9.01
- 2017-07-19 0001564590-17-013609 — 2.02, 9.01
- 2017-05-11 0001564590-17-010459 — 5.02, 9.01
- 2017-05-11 0001564590-17-010452 — 5.07
- 2017-04-19 0001193125-17-127926 — 2.02, 9.01
- 2017-02-07 0001193125-17-032714 — 8.01
- 2017-01-18 0001193125-17-011669 — 2.02, 9.01
- 2016-11-16 0001193125-16-769505 — 5.02, 9.01
- 2016-10-19 0001193125-16-741087 — 2.02, 9.01
- 2016-09-14 0001193125-16-709148 — 8.01, 9.01
- 2016-08-17 0001193125-16-683980 — 5.02, 9.01
- 2016-07-13 0001193125-16-646816 — 2.02, 9.01
- 2016-05-13 0001193125-16-590263 — 5.07
- 2016-04-13 0001193125-16-539019 — 2.02, 9.01
- 2016-04-08 0001193125-16-535035 — 7.01
- 2016-02-11 0001193125-16-459453 — 5.02, 9.01
- 2016-01-20 0001193125-16-432934 — 2.02, 9.01
- 2015-11-16 0001193125-15-378019 — 5.02, 9.01
- 2015-10-14 0001193125-15-343083 — 2.02, 9.01
- 2015-07-16 0001193125-15-254729 — 8.01, 9.01
- 2015-07-15 0001193125-15-253068 — 2.02, 9.01
- 2015-05-15 0001193125-15-189160 — 5.07, 9.01
- 2015-04-22 0001193125-15-140997 — 2.02, 9.01
- 2015-02-23 0001193125-15-056741 — 5.02, 9.01
- 2015-01-21 0001193125-15-015465 — 2.02, 9.01
- 2014-10-15 0001193125-14-372076 — 2.02, 9.01
- 2014-10-03 0001193125-14-363152 — 2.02, 9.01
- 2014-07-16 0001193125-14-269660 — 2.02, 9.01
- 2014-05-20 0001193125-14-205916 — 8.01, 9.01
- 2014-05-20 0001193125-14-205906 — 5.02, 9.01
- 2014-05-15 0001193125-14-201144 — 5.07
- 2014-04-16 0001193125-14-144665 — 2.02, 9.01
- 2014-04-03 0001193125-14-129578 — 2.02, 9.01
- 2014-01-22 0001157523-14-000154 — 2.02, 9.01
- 2013-10-15 0001193125-13-399540 — 5.02
- 2013-10-09 0001157523-13-004657 — 2.02, 9.01
- 2013-07-10 0001157523-13-003290 — 2.02, 9.01
- 2013-05-10 0001193125-13-213728 — 5.07
- 2013-05-03 0001193125-13-198816 — 8.01, 9.01
- 2013-04-10 0001157523-13-001730 — 2.02, 9.01
- 2013-01-16 0001157523-13-000139 — 2.02, 9.01
- 2012-10-10 0001157523-12-005081 — 2.02, 9.01
- 2012-10-03 0001193125-12-413609 — 7.01
- 2012-09-28 0001193125-12-408878 — 2.02, 9.01
- 2012-07-11 0001157523-12-003592 — 2.02, 9.01
- 2012-05-10 0001193125-12-225669 — 5.07
- 2012-05-10 0001193125-12-225639 — 8.01, 9.01
- 2012-04-11 0001157523-12-001772 — 2.02, 9.01
- 2012-03-15 0001193125-12-116494 — 2.02, 9.01
- 2012-01-18 0001157523-12-000174 — 2.02, 9.01
- 2011-12-12 0001193125-11-337271 — 7.01, 9.01
- 2011-10-13 0000950123-11-089785 — 5.03, 9.01
- 2011-10-12 0001157523-11-005682 — 2.02, 9.01
- 2011-07-13 0001157523-11-003986 — 2.02, 9.01
- 2011-05-09 0000950123-11-047191 — 5.02, 5.07, 9.01
- 2011-04-13 0001157523-11-002001 — 2.02, 9.01
- 2011-01-19 0001157523-11-000232 — 2.02, 9.01
- 2010-11-09 0000950123-10-103195 — 5.02, 9.01
- 2010-10-13 0001157523-10-005798 — 2.02, 9.01
- 2010-07-14 0001157523-10-004011 — 2.02, 9.01
- 2010-05-28 0000950123-10-053947 — 5.07
- 2010-04-14 0001157523-10-002022 — 2.02, 9.01
- 2010-01-20 0001157523-10-000200 — 2.02, 9.01
- 2009-10-28 0000950123-09-053984 — 8.01
- 2009-10-14 0001157523-09-006877 — 2.02, 9.01
- 2009-07-15 0001157523-09-004878 — 2.02, 9.01
- 2009-04-15 0001157523-09-002687 — 2.02, 9.01
- 2009-01-21 0001157523-09-000340 — 2.02, 9.01
- 2008-11-12 0001193125-08-233181 — 5.02, 9.01
- 2008-10-14 0001157523-08-007999 — 2.02, 9.01
- 2008-07-15 0001157523-08-005504 — 2.02, 9.01
- 2008-04-15 0001157523-08-002896 — 2.02, 9.01
- 2008-01-22 0001157523-08-000408 — 2.02, 9.01
- 2007-10-16 0001193125-07-219356 — 5.03, 9.01
- 2007-10-16 0001157523-07-009850 — 2.02, 9.01
- 2007-07-17 0001157523-07-006912 — 2.02, 9.01
- 2007-04-17 0001157523-07-003630 — 2.02, 9.01
- 2007-04-03 0001179022-07-000068 — 5.02
- 2007-03-28 0001179022-07-000064 — 5.02
- 2007-02-23 0001193125-07-038337 — 5.02
- 2007-02-23 0001193125-07-038335 — 5.02
- 2007-01-30 0001193125-07-015912 — 5.02, 9.01
- 2007-01-26 0001193125-07-014234 — 5.02
- 2007-01-23 0001157523-07-000494 — 2.02, 9.01 — amendment of 0001157523-07-000481
- 2007-01-23 0001157523-07-000481 — 2.02, 9.01
- 2006-10-17 0001157523-06-009945 — 2.02, 9.01
- 2006-07-18 0001157523-06-006929 — 2.02, 9.01
- 2006-06-08 0001193125-06-126486 — 1.01, 9.01
- 2006-05-10 0001193125-06-107316 — 1.01, 9.01
- 2006-04-18 0001157523-06-003699 — 2.02, 9.01
- 2006-02-03 0001179022-06-000014 — 1.01
- 2006-01-27 0001157523-06-000754 — 5.02, 9.01
- 2006-01-24 0001157523-06-000551 — 2.02, 9.01
- 2005-10-18 0001157523-05-008826 — 2.02, 9.01
- 2005-07-19 0001193125-05-143958 — 1.01, 5.02, 9.01
- 2005-07-19 0001193125-05-143957 — 2.02, 9.01
- 2005-05-20 0001193125-05-112019 — 1.01, 9.01
- 2005-04-19 0001157523-05-003418 — 2.02, 9.01
- 2005-01-25 0001193125-05-010721 — 2.02, 9.01
- 2004-10-12 0001193125-04-169652 — 2.02, 9.01
- 2004-07-13 0001193125-04-116820 — 12, 7
- 2004-04-14 0001193125-04-061547 — 12, 7
- 2004-01-21 0001193125-04-006366 — 12, 7
- 2003-10-14 0001193125-03-061018 — 12, 5, 7
- 2003-07-15 0001193125-03-019292 — 7, 9
- 2003-04-15 0000931763-03-000968 — 7, 9
- 1996-09-12 0000931763-96-000667 — 5, 7

## late-filing notifications on or before 2026-02-26

- 2025-05-13 0000950170-25-070493 — NT 10-Q, for the period ended 2025-05-13
- 2024-02-29 0000950170-24-023141 — NT 10-K, for the period ended 2023-12-31
- 2023-08-10 0001193125-23-209042 — NT 10-Q, for the period ended 2023-06-30
- 2019-08-12 0001564590-19-031524 — NT 10-Q, for the period ended 2019-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001193125-26-073361:8k_2_02:1]
EX-99.1
2
adtn-ex99_1.htm
EX-99.1

[0001193125-26-073361:8k_2_02:2]
EX-99.1

[0001193125-26-073361:8k_2_02:3]
ADTRAN Holdings, Inc. reports fourth quarter and full year 2025 financial results

[0001193125-26-073361:8k_2_02:4]
Huntsville, Alabama, USA. — Feb. 25, 2026 — ADTRAN Holdings, Inc. (NASDAQ: ADTN and FSE: QH9) (“ADTRAN Holdings” “ADTRAN” or the “Company”) today announced its unaudited financial results for the fourth quarter ended December 31, 2025.

[0001193125-26-073361:8k_2_02:5]
•
Revenue: $291.6 million, up 20.1% year-over-year.

[0001193125-26-073361:8k_2_02:6]
•
GAAP gross margin of 39.0%; Non-GAAP gross margin of 42.5%; up 213 and 122 basis points year-over-year, respectively.

[0001193125-26-073361:8k_2_02:7]
•
Operating margin: GAAP operating margin of 1.5%; non-GAAP operating margin of 6.4%.

[0001193125-26-073361:8k_2_02:8]
•
Net cash provided by operating activities of $42.2 million.

[0001193125-26-073361:8k_2_02:9]
•
GAAP diluted loss per share of $0.02; non-GAAP diluted earnings per share of $0.16.

[0001193125-26-073361:8k_2_02:10]
•
Cash and cash equivalents of $95.7 million.

[0001193125-26-073361:8k_2_02:11]
ADTRAN Holdings Chairman and Chief Executive Officer Tom Stanton stated, “We delivered a strong fourth quarter, with revenue above our outlook and growth across all three revenue categories. Performance reflected solid execution and sustained fiber investment across our core markets.”

[0001193125-26-073361:8k_2_02:12]
Mr. Stanton added, “As we look at 2026, we see solid momentum with cloud and enterprise customers, strong broadband activity in the US and increasing high-risk vendor replacement initiatives in Europe. Our priorities remain focused on expanding operating margin, cash generation, and converting the customer opportunities we are seeing across our portfolio.”

[0001193125-26-073361:8k_2_02:13]
Business outlook1

[0001193125-26-073361:8k_2_02:14]
For the first quarter of 2026, the Company expects revenue to be within a range of $275.0 million to $295.0 million. Non-GAAP operating margin is expected to be within a range of 4.0% to 8.0%.

[0001193125-26-073361:8k_2_02:15]
1 Non-GAAP operating margin (which is calculated as non-GAAP operating income (loss) divided by revenue) is a non-GAAP financial measure. The Company has provided guidance for its first quarter 2026 non-GAAP operating margin. This measure excludes from the corresponding GAAP financial measure the effect of adjustments as described below. The Company has not provided a reconciliation of such non-GAAP guidance to  guidance presented on a GAAP basis because it cannot predict and quantify without unreasonable effort all of the adjustments that may occur during the period due to the difficulty of predicting the timing and amounts of various items within a reasonable range. In particular, non-GAAP operating margin excludes certain items, such as acquisition related expenses, amortizations and adjustments, stock-based compensation expense, restructuring expenses, integration expenses, deferred compensation adjustments, professional fees and other expenses, and goodwill impairment, that the Company is unable to quantitatively predict. Depending on the materiality of these items, they could have a significant impact on the Company's GAAP financial results.

[0001193125-26-073361:8k_2_02:16]
Conference call

[0001193125-26-073361:8k_2_02:17]
The Company will hold a conference call to discuss its fourth quarter and full year 2025 results on Thursday, February 26, 2026, at 7:30 a.m. Central Time (2:30 p.m. Central European Time). The Company will webcast this conference call at the events and presentations section of ADTRAN Holdings, Inc. Investor Relations website at  https://events.q4inc.com/attendee/203363753 approximately 10 minutes before the start of the call, or you may dial 1-888-330-2391 (Toll-Free US) or 1-240-789-2702, and use Conference ID 8936454.

[0001193125-26-073361:8k_2_02:18]
An online replay of the Company’s conference call, as well as the transcript of the call, will be available on the Investor Relations site  https://investors.adtran.com/shortly following the call and will remain available for at least

[0001193125-26-073361:8k_2_02:19]
12 months. For more information, visit investors.adtran.com or email investor.relations@adtran.com.

[0001193125-26-073361:8k_2_02:20]
Upcoming conference schedule

[0001193125-26-073361:8k_2_02:21]
March 10, 2026: Stifel 2026 One-on-One Conference – New York

[0001193125-26-073361:8k_2_02:22]
About Adtran

[0001193125-26-073361:8k_2_02:23]
ADTRAN Holdings, Inc. (NASDAQ: ADTN and FSE: QH9) is the parent company of Adtran, Inc., a leading global provider of open, disaggregated networking and communications solutions that enable voice, data, video and internet communications across any network infrastructure. From the cloud edge to the subscriber edge, Adtran empowers communications service providers around the world to manage and scale services that connect people, places and things. Adtran solutions are used by service providers, private enterprises, government organizations and millions of individual users worldwide. ADTRAN Holdings, Inc. is also the majority shareholder of Adtran Networks SE, formerly ADVA Optical Networking SE (“Adtran Networks”). Find more at Adtran.com, LinkedIn and X.

[0001193125-26-073361:8k_2_02:24]
Cautionary note regarding forward-looking statements

[0001193125-26-073361:8k_2_02:25]
Explanation of use of non-GAAP financial measures

[0001193125-26-073361:8k_2_02:26]
Set forth in the tables below under the heading “Supplemental Information” are reconciliations of gross profit, gross margin, operating expenses, operating income (loss), operating margin, other expense, net loss inclusive of the non-controlling interest, net loss attributable to the Company, and loss per share - basic and diluted, attributable to the Company, and net cash provided by operating activities, in each case as reported based on generally accepted accounting principles in the United States (“GAAP”), to non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income (loss), non-GAAP operating margin, non-GAAP other expense, non-GAAP net income (loss) inclusive of the non-controlling interest, non-GAAP net income (loss) attributable to the Company, non-GAAP net earnings (loss) per share - basic and diluted, attributable to the Company, and free cash flow, respectively. Such non-GAAP measures exclude acquisition-related expenses, amortization and adjustments (consisting of intangible amortization of backlog, inventory fair value adjustments, developed technology, customer relationships, and trade names acquired in connection with business combinations), stock-based compensation expense, restructuring expenses, integration expenses, deferred compensation adjustments, goodwill impairments, professional fees and other expenses, amortization of pension actuarial losses, the tax effect of these adjustments to net loss and purchases of property, plant and equipment, and developed technologies. These measures are used by management in our ongoing planning and annual budgeting processes. Additionally, we believe the presentation of these non-GAAP measures, when combined with the presentation of the most directly comparable GAAP financial measure, is beneficial to the overall understanding of ongoing operating performance of the Company. These non-GAAP financial measures are not prepared in accordance with, or an alternative for, GAAP and therefore should not be considered in isolation or as a substitution for analysis of our results as reported under GAAP. Additionally, our calculation of non-GAAP measures may not be comparable to similar measures calculated by other companies.

[0001193125-26-073361:8k_2_02:27]
Published by

[0001193125-26-073361:8k_2_02:28]
ADTRAN Holdings, Inc.

[0001193125-26-073361:8k_2_02:29]
www.adtran.com

[0001193125-26-073361:8k_2_02:30]
For media

[0001193125-26-073361:8k_2_02:31]
Gareth Spence

[0001193125-26-073361:8k_2_02:32]
+44 1904 699 358

[0001193125-26-073361:8k_2_02:33]
public.relations@adtran.com

[0001193125-26-073361:8k_2_02:34]
For investors

[0001193125-26-073361:8k_2_02:35]
Peter Schuman, IRC

[0001193125-26-073361:8k_2_02:36]
+1 256 963 6305

[0001193125-26-073361:8k_2_02:37]
investor.relations@adtran.com

[0001193125-26-073361:8k_2_02:38]
Condensed Consolidated Balance Sheets

[0001193125-26-073361:8k_2_02:39]
(Unaudited)

[0001193125-26-073361:8k_2_02:40]
(In thousands)

[0001193125-26-073361:8k_2_02:41]
| ASSETS |  | December 31, 2025 |  |  | December 31, 2024 |  |  |
| Current Assets |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 95,696 |  |  | $ | 76,021 |  |  |
| Accounts receivable, net |  |  | 210,687 |  |  |  | 178,030 |  |  |
| Other receivables |  |  | 7,046 |  |  |  | 9,775 |  |  |
| Inventory, net |  |  | 215,736 |  |  |  | 261,557 |  |  |
| Income tax receivable |  |  | 3,667 |  |  |  | 5,461 |  |  |
| Prepaid expenses and other current assets |  |  | 55,317 |  |  |  | 56,395 |  |  |
| Short-term investments - deferred compensation |  |  | 35,174 |  |  |  | — |  |  |
| Assets held for sale |  |  | 11,901 |  |  |  | 11,901 |  |  |
| Total Current Assets |  |  | 635,224 |  |  |  | 599,140 |  |  |
| Property, plant and equipment, net |  |  | 124,384 |  |  |  | 106,454 |  |  |
| Goodwill |  |  | 59,983 |  |  |  | 52,918 |  |  |
| Intangibles, net |  |  | 294,047 |  |  |  | 284,893 |  |  |
| Deferred tax assets |  |  | 16,481 |  |  |  | 17,826 |  |  |
| Other non-current assets |  |  | 73,352 |  |  |  | 78,128 |  |  |
| Long-term investments |  |  | 1,022 |  |  |  | 32,060 |  |  |
| Total Assets |  | $ | 1,204,493 |  |  | $ | 1,171,419 |  |  |
| LIABILITIES AND EQUITY |  |  |  |  |  |  |  |
| Current Liabilities |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 167,337 |  |  | $ | 171,825 |  |  |
| Unearned revenue |  |  | 87,541 |  |  |  | 52,701 |  |  |
| Accrued expenses and other liabilities |  |  | 33,690 |  |  |  | 34,158 |  |  |
| Accrued wages and benefits |  |  | 32,203 |  |  |  | 32,853 |  |  |
| Deferred compensation liability |  |  | 37,447 |  |  |  | — |  |  |
| Income tax payable |  |  | 3,642 |  |  |  | 1,936 |  |  |
| Total Current Liabilities |  |  | 361,860 |  |  |  | 293,473 |  |  |
| Non-current revolving credit agreement outstanding |  |  | 25,000 |  |  |  | 189,576 |  |  |
| Non-current convertible senior notes, net of debt issuance costs |  |  | 193,038 |  |  |  | — |  |  |
| Deferred tax liabilities |  |  | 27,453 |  |  |  | 30,372 |  |  |
| Non-current unearned revenue |  |  | 27,143 |  |  |  | 22,065 |  |  |
| Non-current pension liability |  |  | 6,277 |  |  |  | 8,983 |  |  |
| Non-current deferred compensation liability |  |  | — |  |  |  | 33,203 |  |  |
| Non-current lease obligations |  |  | 27,000 |  |  |  | 25,925 |  |  |
| Other non-current liabilities |  |  | 17,564 |  |  |  | 17,928 |  |  |
| Total Liabilities |  |  | 685,335 |  |  |  | 621,525 |  |  |
| Redeemable Non-Controlling Interest |  |  | 373,328 |  |  |  | 422,943 |  |  |
| Equity |  |  |  |  |  |  |  |
| Common stock |  |  | 802 |  |  |  | 795 |  |  |
| Additional paid-in capital |  |  | 801,269 |  |  |  | 808,913 |  |  |
| Accumulated other comprehensive income |  |  | 78,877 |  |  |  | 11,254 |  |  |
| Retained deficit |  |  | (730,010 | ) |  |  | (688,813 | ) |  |
| Treasury stock |  |  | (5,108 | ) |  |  | (5,198 | ) |  |
| Total Equity |  |  | 145,830 |  |  |  | 126,951 |  |  |
| Total Liabilities and Equity |  | $ | 1,204,493 |  |  | $ | 1,171,419 |  |  |

[0001193125-26-073361:8k_2_02:42]
Condensed Consolidated Statements of Loss

[0001193125-26-073361:8k_2_02:43]
(Unaudited)

[0001193125-26-073361:8k_2_02:44]
(In thousands, except per share amounts)

[0001193125-26-073361:8k_2_02:45]
|  |  | Three Months Ended |  |  | Twelve Months Ended |  |
|  |  | December 31, |  |  | December 31, |  |
|  |  | 2025 |  |  | 2024 |  |  | 2025 |  |  | 2024 |  |
| Revenue |  |  |  |  |  |  |  |  |  |  |  |  |
| Network Solutions |  | $ | 242,653 |  |  | $ | 197,009 |  |  | $ | 896,911 |  |  | $ | 738,964 |  |
| Services & Support |  |  | 48,907 |  |  |  | 45,843 |  |  |  | 186,896 |  |  |  | 183,756 |  |
| Total Revenue |  |  | 291,560 |  |  |  | 242,852 |  |  |  | 1,083,807 |  |  |  | 922,720 |  |
| Cost of Revenue |  |  |  |  |  |  |  |  |  |  |  |  |
| Network Solutions |  |  | 157,472 |  |  |  | 135,861 |  |  |  | 592,141 |  |  |  | 517,220 |  |
| Network Solutions - charges and inventory write-down |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 8,597 |  |
| Services & Support |  |  | 20,359 |  |  |  | 17,435 |  |  |  | 76,711 |  |  |  | 72,739 |  |
| Total Cost of Revenue |  |  | 177,831 |  |  |  | 153,296 |  |  |  | 668,852 |  |  |  | 598,556 |  |
| Gross Profit |  |  | 113,729 |  |  |  | 89,556 |  |  |  | 414,955 |  |  |  | 324,164 |  |
| Selling, general and administrative expenses |  |  | 57,409 |  |  |  | 57,013 |  |  |  | 226,275 |  |  |  | 232,918 |  |
| Research and development expenses |  |  | 51,842 |  |  |  | 49,314 |  |  |  | 204,276 |  |  |  | 221,458 |  |
| Goodwill impairment |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 297,353 |  |
| Operating Income (Loss) |  |  | 4,478 |  |  |  | (16,771 | ) |  |  | (15,596 | ) |  |  | (427,565 | ) |
| Interest and dividend income |  |  | 1,703 |  |  |  | 1,631 |  |  |  | 2,321 |  |  |  | 3,058 |  |
| Interest expense |  |  | (4,520 | ) |  |  | (4,870 | ) |  |  | (19,344 | ) |  |  | (22,053 | ) |
| Net investment (loss) gain |  |  | (574 | ) |  |  | (920 | ) |  |  | 3,001 |  |  |  | 3,587 |  |
| Other income (expense), net |  |  | 805 |  |  |  | 687 |  |  |  | (1,632 | ) |  |  | 246 |  |
| Income (Loss) Before Income Taxes |  |  | 1,892 |  |  |  | (20,243 | ) |  |  | (31,250 | ) |  |  | (442,727 | ) |
| Income tax expense |  |  | (3,172 | ) |  |  | (23,461 | ) |  |  | (4,993 | ) |  |  | (7,340 | ) |
| Net Loss |  | $ | (1,280 | ) |  | $ | (43,704 | ) |  | $ | (36,243 | ) |  | $ | (450,067 | ) |
| Net Income attributable to non-controlling interest (1) |  |  | 2,316 |  |  |  | 2,407 |  |  |  | 9,413 |  |  |  | 9,824 |  |
| Net Loss attributable to ADTRAN Holdings, Inc. |  | $ | (3,596 | ) |  | $ | (46,111 | ) |  | $ | (45,656 | ) |  | $ | (459,891 | ) |
| Weighted average shares outstanding – basic |  |  | 79,877 |  |  |  | 79,091 |  |  |  | 79,742 |  |  |  | 78,928 |  |
| Weighted average shares outstanding – diluted |  |  | 79,877 |  |  |  | 79,091 |  |  |  | 79,742 |  |  |  | 78,928 |  |
| Loss per common share attributable to ADTRAN Holdings, Inc. – basic |  | $ | (0.02 | ) | (2) | $ | (0.58 | ) |  | $ | (0.52 | ) | (1) | $ | (5.79 | ) |
| Loss per common share attributable to ADTRAN Holdings, Inc. – diluted |  | $ | (0.02 | ) | (2) | $ | (0.58 | ) |  | $ | (0.52 | ) | (1) | $ | (5.79 | ) |

[0001193125-26-073361:8k_2_02:46]
(1) For the three and twelve months ended December 31, 2025 we accrued $2.3 million and $9.3 million, respectively, net income attributable to non-controlling interest, representing the recurring cash compensation earned by non-controlling interest shareholders post-DPLTA. For the three and twelve months ended December 31, 2024, we accrued $2.4 million and $9.8 million, respectively, representing the recurring cash compensation earned by non-controlling interest shareholders post-DPLTA.

[0001193125-26-073361:8k_2_02:47]
(2) Loss per common share attributable to ADTRAN Holdings, Inc. - basic and diluted - reflects $2.1 million and $4.1 million effect of redemption of RNCI for the three and twelve months ended December 31, 2025 and $0 and $3.0 million effect of redemption of RNCI for the three and twelve months ended December 31, 2024.

[0001193125-26-073361:8k_2_02:48]
Condensed Consolidated Statements of Cash Flows

[0001193125-26-073361:8k_2_02:49]
(Unaudited)

[0001193125-26-073361:8k_2_02:50]
(In thousands)

[0001193125-26-073361:8k_2_02:51]
|  |  | Twelve Months Ended December 31, |  |
|  |  | 2025 |  |  | 2024 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |
| Net Loss |  | $ | (36,243 | ) |  | $ | (450,067 | ) |
| Adjustments to reconcile net loss to net cash used in operating activities: |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 92,546 |  |  |  | 90,529 |  |
| Goodwill impairment |  |  | — |  |  |  | 297,353 |  |
| Amortization of revolving credit facility issuance costs |  |  | 1,351 |  |  |  | 3,950 |  |
| Amortization of convertible notes issuance costs |  |  | 441 |  |  |  | — |  |
| Gain on investments |  |  | (4,740 | ) |  |  | (5,030 | ) |
| Net loss on disposal of property, plant and equipment |  |  | 228 |  |  |  | 1,371 |  |
| Stock-based compensation expense |  |  | 10,062 |  |  |  | 15,988 |  |
| Deferred income taxes |  |  | (3,847 | ) |  |  | 5,576 |  |
| Inventory write down - business efficiency program |  |  | — |  |  |  | 4,135 |  |
| Inventory reserves |  |  | (2,541 | ) |  |  | 5,316 |  |
| Change in operating assets and liabilities: |  |  |  |  |  |  |
| Accounts receivable, net |  |  | (18,301 | ) |  |  | 46,108 |  |
| Other receivables |  |  | 5,767 |  |  |  | 10,713 |  |
| Income taxes receivable |  |  | 2,034 |  |  |  | 648 |  |
| Inventory |  |  | 64,494 |  |  |  | 79,985 |  |
| Prepaid expenses other current assets and other assets |  |  | 19,223 |  |  |  | (13,445 | ) |
| Accounts payable |  |  | 17,982 |  |  |  | 10,238 |  |
| Accrued expenses and other liabilities |  |  | (17,967 | ) |  |  | 4,873 |  |
| Income taxes payable |  |  | (722 | ) |  |  | (4,670 | ) |
| Net cash provided by operating activities |  |  | 129,767 |  |  |  | 103,571 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (31,737 | ) |  |  | (34,501 | ) |
| Purchases of intangibles - developed technology |  |  | (37,528 | ) |  |  | (30,671 | ) |
| Proceeds from sales and maturities of available-for-sale investments |  |  | 1,019 |  |  |  | 1,240 |  |
| Purchases of available-for-sale investments |  |  | (383 | ) |  |  | (268 | ) |
| Payments for beneficial interests in securitized accounts receivable |  |  | (539 | ) |  |  | (55 | ) |
| Net cash used in investing activities |  |  | (69,168 | ) |  |  | (64,255 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |
| Tax withholdings related to stock-based compensation settlements |  |  | (1,478 | ) |  |  | (1,143 | ) |
| Proceeds from stock option exercises |  |  | 1,829 |  |  |  | 824 |  |
| Proceeds from receivables purchase agreement |  |  | — |  |  |  | 68,556 |  |
| Repayments on receivables purchase agreement |  |  | — |  |  |  | (83,772 | ) |
| Proceeds from draw on revolving credit agreements |  |  | 49,000 |  |  |  | 26,000 |  |
| Repayment of revolving credit agreements |  |  | (214,000 | ) |  |  | (31,000 | ) |
| Redemption of redeemable non-controlling interest |  |  | (46,575 | ) |  |  | (17,398 | ) |
| Payment of annual recurring compensation to non-controlling interest |  |  | (10,053 | ) |  |  | (10,084 | ) |
| Payment of debt issuance cost |  |  | (9,003 | ) |  |  | (1,994 | ) |
| Proceeds from issuance of senior convertible notes |  |  | 201,250 |  |  |  | — |  |
| Payments for capped call transactions related to convertible senior notes |  |  | (17,650 | ) |  |  | — |  |
| Net cash used in financing activities |  |  | (46,680 | ) |  |  | (50,011 | ) |
| Net increase (decrease) in cash and cash equivalents |  |  | 13,919 |  |  |  | (10,695 | ) |
| Effect of exchange rate changes |  |  | 5,756 |  |  |  | (451 | ) |
| Cash and cash equivalents, beginning of year |  |  | 76,021 |  |  |  | 87,167 |  |
| Cash and cash equivalents, end of year |  | $ | 95,696 |  |  | $ | 76,021 |  |
| Supplemental disclosure of cash financing activities: |  |  |  |  |  |  |
| Cash paid for interest |  | $ | 13,273 |  |  | $ | 20,884 |  |
| Cash used in operating activities related to operating leases |  | $ | 10,216 |  |  | $ | 9,274 |  |
| Supplemental disclosure of non-cash investing activities and financing activities: |  |  |  |  |  |  |
| Right-of-use assets obtained in exchange for lease obligations |  | $ | 6,432 |  |  | $ | 5,317 |  |
| Purchases of property, plant and equipment included in accounts payable |  | $ | 3,716 |  |  | $ | 2,635 |  |
| Purchases of property, plant and equipment included in other non-current liabilities |  | $ | 5,119 |  |  | $ | — |  |
| Redemption of redeemable non-controlling interest |  | $ | 4,085 |  |  | $ | 2,986 |  |

[0001193125-26-073361:8k_2_02:52]
Supplemental Information

[0001193125-26-073361:8k_2_02:53]
Reconciliation of Gross Profit and Gross Margin to

[0001193125-26-073361:8k_2_02:54]
Non-GAAP Gross Profit and Non-GAAP Gross Margin

[0001193125-26-073361:8k_2_02:55]
(Unaudited)

[0001193125-26-073361:8k_2_02:56]
(In thousands)

[0001193125-26-073361:8k_2_02:57]
|  |  | Three Months Ended |  |  |  | Twelve Months Ended |  |
|  |  | December 31, 2025 |  |  | September 30, 2025 |  |  | December 31, 2024 |  |  |  | December 31, 2025 |  |  | December 31, 2024 |  |
| Total Revenue |  | $ | 291,560 |  |  | $ | 279,435 |  |  | $ | 242,852 |  |  |  | $ | 1,083,807 |  |  | $ | 922,720 |  |
| Cost of Revenue |  | $ | 177,831 |  |  | $ | 172,309 |  |  | $ | 153,296 |  |  |  | $ | 668,852 |  |  | $ | 598,556 |  |
| Acquisition-related expenses, amortization and adjustments (1) |  |  | (9,964 | ) |  |  | (10,140 | ) |  |  | (9,980 | ) |  |  |  | (40,534 | ) |  |  | (40,497 | ) |
| Stock-based compensation expense |  |  | (232 | ) |  |  | (265 | ) |  |  | (317 | ) |  |  |  | (986 | ) |  |  | (1,142 | ) |
| Restructuring expenses (2) |  |  | — |  |  |  | — |  |  |  | (538 | ) |  |  |  | — |  |  |  | (14,580 | ) |
| Integration expenses (3) |  |  | — |  |  |  | — |  |  |  | 123 |  |  |  |  | — |  |  |  | 19 |  |
| Non-GAAP Cost of Revenue |  | $ | 167,635 |  |  | $ | 161,904 |  |  | $ | 142,584 |  |  |  | $ | 627,332 |  |  | $ | 542,356 |  |
| Gross Profit |  | $ | 113,729 |  |  | $ | 107,126 |  |  | $ | 89,556 |  |  |  | $ | 414,955 |  |  | $ | 324,164 |  |
| Non-GAAP Gross Profit |  | $ | 123,925 |  |  | $ | 117,531 |  |  | $ | 100,268 |  |  |  | $ | 456,475 |  |  | $ | 380,364 |  |
| Gross Margin |  |  | 39.0 | % |  |  | 38.3 | % |  |  | 36.9 | % |  |  |  | 38.3 | % |  |  | 35.1 | % |
| Non-GAAP Gross Margin |  |  | 42.5 | % |  |  | 42.1 | % |  |  | 41.3 | % |  |  |  | 42.1 | % |  |  | 41.2 | % |

[0001193125-26-073361:8k_2_02:58]
(1) Includes intangible amortization of backlog, inventory fair value adjustments, developed technology, customer relationships, and trade names acquired in connection with business combinations. We incur charges relating to the amortization of intangible assets and exclude these charges for purposes of calculating our non-GAAP measures. Such charges are significantly impacted by the timing and magnitude of our acquisitions. We exclude these charges for the purpose of calculating our non-GAAP measures, primarily because they are noncash expenses and our internal benchmarking analyses evidence that many industry participants and peers present non-GAAP financial measures excluding intangible asset amortization. Although this does not directly affect our cash position, the loss in value of intangible assets over time can have a material impact on the equivalent GAAP earnings measure.

[0001193125-26-073361:8k_2_02:59]
(2) Includes expenses for a Business Efficiency Program designed to optimize the assets and business processes following the business combination with Adtran Networks. The Business Efficiency Program was completed as of December 31, 2024.

[0001193125-26-073361:8k_2_02:60]
(3) Includes expenses related to the Company's one-time integration bonus program in connection with synergy targets as a result of the business combination with Adtran Networks, which bonus program was completed as of December 31, 2024.

[0001193125-26-073361:8k_2_02:61]
Supplemental Information

[0001193125-26-073361:8k_2_02:62]
Reconciliation of Operating Expenses to Non-GAAP Operating Expenses

[0001193125-26-073361:8k_2_02:63]
(Unaudited)

[0001193125-26-073361:8k_2_02:64]
(In thousands)

[0001193125-26-073361:8k_2_02:65]
|  | Three Months Ended |  |  | Twelve Months Ended |  |  |
|  | December 31, 2025 |  |  | September 30, 2025 |  |  | December 31, 2024 |  |  | December 31, 2025 |  |  | December 31, 2024 |  |  |
| Operating Expenses | $ | 109,251 |  |  | $ | 109,914 |  |  | $ | 106,327 |  |  | $ | 430,551 |  |  | $ | 751,729 |  |  |
| Acquisition-related expenses, amortization and adjustments (1) |  | (1,805 | ) | (2) |  | (1,898 | ) | (8) |  | (5,294 | ) | (11) |  | (8,127 | ) | (15) |  | (22,462 | ) | (19) |
| Stock-based compensation expense |  | (1,092 | ) | (3) |  | (2,589 | ) | (9) |  | (2,853 | ) | (12) |  | (9,076 | ) | (16) |  | (12,810 | ) | (20) |
| Restructuring expenses (4) |  | — |  |  |  | — |  |  |  | (3,567 | ) | (13) |  | 284 |  | (17) |  | (30,101 | ) | (21) |
| Integration expenses (5) |  | — |  |  |  | — |  |  |  | (586 | ) | (14) |  | — |  |  |  | (1,930 | ) | (22) |
| Deferred compensation adjustments (6) |  | 781 |  |  |  | (2,317 | ) |  |  | 451 |  |  |  | (3,023 | ) |  |  | (3,808 | ) |  |
| Goodwill impairment |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (297,353 | ) | (23) |
| Professional fees and other expenses |  | (1,988 | ) | (7) |  | (694 | ) | (10) |  | — |  |  |  | (5,835 | ) | (18) |  | — |  |  |
| Non-GAAP Operating Expenses | $ | 105,147 |  |  | $ | 102,416 |  |  | $ | 94,478 |  |  | $ | 404,774 |  |  | $ | 383,265 |  |  |

[0001193125-26-073361:8k_2_02:66]
(1) We incur charges relating to the amortization of intangible assets and exclude these charges for purposes of calculating our non-GAAP measures. Such charges are significantly impacted by the timing and magnitude of our acquisitions. We exclude these charges for the purpose of calculating our non-GAAP measures, primarily because they are noncash expenses and our internal benchmarking analyses evidence that many industry participants and peers present non-GAAP financial measures excluding intangible asset amortization. Although this does not directly affect our cash position, the loss in value of intangible assets over time can have a material impact on the equivalent GAAP earnings measure.

[0001193125-26-073361:8k_2_02:67]
(2) Includes intangible amortization of developed technology, customer relationships, and trade names acquired in connection with business combinations, of which $1.4 million is included in selling, general and administrative expenses and $0.4 million is included in research and development expenses on the condensed consolidated statements of loss.

[0001193125-26-073361:8k_2_02:68]
(3) $0.4 million is included in selling, general and administrative expenses and $0.7 million is included in research and development expenses on the condensed consolidated statements of loss.

[0001193125-26-073361:8k_2_02:69]
(4) Includes expenses for a Business Efficiency Program designed to optimize the assets and business processes following the business combination with Adtran Networks. The Business Efficiency Program was completed as of December 31, 2024.

[0001193125-26-073361:8k_2_02:70]
(5) Includes expenses related to the Company's one-time integration bonus program in connection with synergy targets as a result of the business combination with Adtran Networks, which was completed as of December 31, 2024.

[0001193125-26-073361:8k_2_02:71]
(6) Includes non-cash change in fair value of equity investments held in the ADTRAN Holdings, Inc. Deferred Compensation Program for Employees, all of which is included in selling, general and administrative expenses on the condensed consolidated statement of loss.

[0001193125-26-073361:8k_2_02:72]
(7) $2.0 million is included in selling, general and administrative expenses on the condensed consolidated statements of loss. Includes professional fees related to an internal investigation and a related SEC inquiry, a provision in connection with a potential 401(k) plan corrective action, and fees relating to other one-time professional fees and business expenses.

[0001193125-26-073361:8k_2_02:73]
(8) Includes intangible amortization of developed technology, customer relationships, and trade names acquired in connection with business combinations, of which $1.4 million is included in selling, general and administrative expenses and $0.5 million is included in research and development expenses on the condensed consolidated statements of loss.

[0001193125-26-073361:8k_2_02:74]
(9) $1.8 million is included in selling, general and administrative expenses and $0.8 million is included in research and development expenses on the condensed consolidated statements of loss.

[0001193125-26-073361:8k_2_02:75]
(10) $0.7 million is included in selling, general and administrative expenses on the condensed consolidated statements of loss. Includes professional fees related to an internal investigation and a related SEC inquiry as well as fees relating to other one-time professional fees and business expenses.

[0001193125-26-073361:8k_2_02:76]
(11) Includes $4.3 million of intangible amortization of developed technology, customer relationships, and trade names acquired in connection with business combinations and $1.0 million of legal and advisory fees related to a potential strategic transaction which are included in selling, general and administrative expenses on the condensed consolidated statements of loss.

[0001193125-26-073361:8k_2_02:77]
(12) $1.9 million is included in selling, general and administrative expenses and $1.0 million is included in research and development expenses on the condensed consolidated statements of loss.

[0001193125-26-073361:8k_2_02:78]
(13) $1.2 million is included in selling, general and administrative expenses and $2.4 million is included in research and development expenses on the condensed consolidated statements of loss. Includes expenses for restructuring program designed to optimize the assets and business processes following the business combination with Adtran Networks SE. The restructuring program commenced upon the closing of the business combination with Adtran Networks SE and was substantially completed in late 2024. Additionally, as part of the Business Efficiency Program, management determined to close a facility in Greifswald, Germany which occurred in December 2024. The Business Efficiency Program was completed as of December 31, 2024.

[0001193125-26-073361:8k_2_02:79]
(14) $0.6 million is included in selling, general and administrative expenses on the condensed consolidated statements of loss, and is primarily related to the Company's one-time integration bonus program in connection with synergy targets as a result of the business combination with Adtran Networks SE which bonus program was completed as of December 31, 2024.

[0001193125-26-073361:8k_2_02:80]
(15) Includes intangible amortization of developed technology, customer relationships, and trade names acquired in connection with business combinations, of which $6.4 million is included in selling, general and administrative expenses and $1.7 million is included in research and development expenses on the condensed consolidated statements of loss.

[0001193125-26-073361:8k_2_02:81]
(16) $6.0 million is included in selling, general and administrative expenses and $3.1 million is included in research and development expenses on the condensed consolidated statements of loss.

[0001193125-26-073361:8k_2_02:82]
(17) Includes a true-up of expenses on the condensed consolidated statements of loss for a Business Efficiency Program designed to optimize the assets and business processes following the business combination with Adtran Networks. The Business Efficiency Program was completed as of December 31, 2024.

[0001193125-26-073361:8k_2_02:83]
(18) $5.8 million is included in selling, general and administrative expenses on the condensed consolidated statements of loss. Includes professional fees related to an internal investigation and a related SEC inquiry, a provision in connection with a potential 401(k) plan corrective action, employee exit costs and fees relating to other one-time professional fees and business expenses.

[0001193125-26-073361:8k_2_02:84]
(19) Includes $17.6 million of intangible amortization of developed technology, customer relationships, and trade names acquired in connection with business combinations and $4.9 million of legal and advisory fees related to a potential strategic transaction which are included in selling, general and administrative expenses on the condensed consolidated statements of loss.

[0001193125-26-073361:8k_2_02:85]
(20) $9.0 million is included in selling, general and administrative expenses and $3.8 million is included in research and development expenses on the condensed consolidated statements of loss.

[0001193125-26-073361:8k_2_02:86]
(21) $9.1 million is included in selling, general and administrative expenses and $21.0 million is included in research and development expenses on the condensed consolidated statements of loss. Includes expenses for restructuring program designed to optimize the assets and business processes following the business combination with Adtran Networks SE. The restructuring program commenced upon the closing of the business combination with Adtran Networks SE and was substantially completed

[0001193125-26-073361:8k_2_02:87]
in late 2024. Additionally, as part of the Business Efficiency Program, management determined to close a facility in Greifswald, Germany which occurred in December 2024. The Business Efficiency Program was completed as of December 31, 2024.

[0001193125-26-073361:8k_2_02:88]
(22) $1.8 million is included in selling, general and administrative expenses and $0.1 million is included in research and development expenses on the condensed consolidated statements of loss, and is primarily related to the Company's one-time integration bonus program in connection with synergy targets as a result of the business combination with Adtran Networks SE.

[0001193125-26-073361:8k_2_02:89]
(23) Non-cash impairment of goodwill in our Network Solutions reporting unit, necessitated by factors such as a decrease in the Company's market capitalization, cautious service provider spending due to economic uncertainty and continued elevated customer inventory adjustments.

[0001193125-26-073361:8k_2_02:90]
Supplemental Information

[0001193125-26-073361:8k_2_02:91]
Reconciliation of Operating Income (Loss) and Operating Margin to Non-GAAP Operating Income (Loss)

[0001193125-26-073361:8k_2_02:92]
and Non-GAAP Operating Margin

[0001193125-26-073361:8k_2_02:93]
(Unaudited)

[0001193125-26-073361:8k_2_02:94]
(In thousands)

[0001193125-26-073361:8k_2_02:95]
|  | Three Months Ended |  |  | Twelve Months Ended |  |  |
|  | December 31, 2025 |  |  | September 30, 2025 |  |  | December 31, 2024 |  |  | December 31, 2025 |  |  | December 31, 2024 |  |  |
| Total Revenue | $ | 291,560 |  |  | $ | 279,435 |  |  | $ | 242,852 |  |  | $ | 1,083,807 |  |  | $ | 922,720 |  |  |
| Operating Income (Loss) | $ | 4,478 |  |  | $ | (2,788 | ) |  | $ | (16,771 | ) |  | $ | (15,596 | ) |  | $ | (427,565 | ) |  |
| Acquisition related expenses, amortizations and adjustments (1) |  | 11,769 |  |  |  | 12,038 |  |  |  | 15,274 |  |  |  | 48,661 |  |  |  | 62,959 |  |  |
| Stock-based compensation expense |  | 1,324 |  |  |  | 2,855 |  |  |  | 3,169 |  |  |  | 10,062 |  |  |  | 13,951 |  |  |
| Restructuring expenses (2) |  | — |  |  |  | — |  |  |  | 4,105 |  |  |  | (284 | ) |  |  | 44,681 |  |  |
| Integration expenses (3) |  | — |  |  |  | — |  |  |  | 464 |  |  |  | — |  |  |  | 1,911 |  |  |
| Deferred compensation adjustments (4) |  | (781 | ) |  |  | 2,317 |  |  |  | (451 | ) |  |  | 3,023 |  |  |  | 3,808 |  |  |
| Goodwill impairment (5) |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 297,353 |  |  |
| Professional fees and other expenses (6) |  | 1,988 |  |  |  | 694 |  |  |  | — |  |  |  | 5,835 |  |  |  | — |  |  |
| Non-GAAP Operating Income (Loss) | $ | 18,778 |  |  | $ | 15,116 |  |  | $ | 5,790 |  |  | $ | 51,701 |  |  | $ | (2,902 | ) |  |
| Operating Margin |  | 1.5 | % |  |  | -1.0 | % |  |  | -6.9 | % |  |  | -1.4 | % |  |  | -46.3 | % |  |
| Non-GAAP Operating Margin |  | 6.4 | % |  |  | 5.4 | % |  |  | 2.4 | % |  |  | 4.8 | % |  |  | -0.3 | % |  |

[0001193125-26-073361:8k_2_02:96]
(1) Includes intangible amortization of backlog, inventory fair value adjustments, developed technology, customer relationships, and trade names acquired in connection with business combinations. We incur charges relating to the amortization of intangible assets and exclude these charges for purposes of calculating our non-GAAP measures. Such charges are significantly impacted by the timing and magnitude of our acquisitions. We exclude these charges for the purpose of calculating our non-GAAP measures, primarily because they are noncash expenses and our internal benchmarking analyses evidence that many industry participants and peers present non-GAAP financial measures excluding intangible asset amortization. Although this does not directly affect our cash position, the loss in value of intangible assets over time can have a material impact on the equivalent GAAP earnings measure.

[0001193125-26-073361:8k_2_02:97]
(2) Includes expenses for the Company's Business Efficiency Program, which was designed to optimize the assets and business processes following the business combination with Adtran Networks. The Business Efficiency Program was completed as of December 31, 2024.

[0001193125-26-073361:8k_2_02:98]
(3) Includes expenses related to the Company's one-time integration bonus program in connection with synergy targets as a results of the business combination with Adtran Networks, which bonus program was completed as of December 31, 2024.

[0001193125-26-073361:8k_2_02:99]
(4) Includes non-cash change in fair value of equity investments held in the ADTRAN Holdings, Inc. Deferred Compensation Program for certain employees, all of which is included in selling, general and administrative expenses on the condensed consolidated statement of loss.

[0001193125-26-073361:8k_2_02:100]
(5) Non-cash impairment of goodwill in our Network Solutions reporting unit, necessitated by factors such as a decrease in the Company's market capitalization, cautious service provider spending due to economic uncertainty and continued elevated customer inventory adjustments.

[0001193125-26-073361:8k_2_02:101]
(6) Includes professional fees related to an internal investigation and a related SEC inquiry, a provision in connection with a potential 401(k) plan corrective action,  employee exit costs and fees relating to other one-time professional fees and business expenses.

[0001193125-26-073361:8k_2_02:102]
Supplemental Information

[0001193125-26-073361:8k_2_02:103]
Reconciliation of Other Expense to Non-GAAP Other Expense

[0001193125-26-073361:8k_2_02:104]
(Unaudited)

[0001193125-26-073361:8k_2_02:105]
(In thousands)

[0001193125-26-073361:8k_2_02:106]
|  |  | Three Months Ended |  |  |  | Twelve Months Ended |  |
|  |  | December 31, 2025 |  |  | September 30, 2025 |  |  | December 31, 2024 |  |  |  | December 31, 2025 |  |  | December 31, 2024 |  |
| Interest and dividend income |  | $ | 1,703 |  |  | $ | 291 |  |  | $ | 1,631 |  |  |  | $ | 2,321 |  |  | $ | 3,058 |  |
| Interest expense |  |  | (4,520 | ) |  |  | (5,499 | ) |  |  | (4,870 | ) |  |  |  | (19,344 | ) |  |  | (22,053 | ) |
| Net investment (loss) gain |  |  | (574 | ) |  |  | 2,186 |  |  |  | (920 | ) |  |  |  | 3,001 |  |  |  | 3,587 |  |
| Other income (expense), net |  |  | 805 |  |  |  | (745 | ) |  |  | 687 |  |  |  |  | (1,632 | ) |  |  | 246 |  |
| Total Other Expense |  | $ | (2,586 | ) |  | $ | (3,767 | ) |  | $ | (3,472 | ) |  |  | $ | (15,654 | ) |  | $ | (15,162 | ) |
| Deferred compensation adjustments (1) |  |  | 601 |  |  |  | (2,210 | ) |  |  | 1,090 |  |  |  |  | (2,928 | ) |  |  | (3,539 | ) |
| Pension expense (2) |  |  | 12 |  |  |  | 13 |  |  |  | 7 |  |  |  |  | 47 |  |  |  | 28 |  |
| Non-GAAP Other Expense |  | $ | (1,973 | ) |  | $ | (5,964 | ) |  | $ | (2,375 | ) |  |  | $ | (18,535 | ) |  | $ | (18,673 | ) |

[0001193125-26-073361:8k_2_02:107]
(1) Includes non-cash change in fair value of equity investments held in the ADTRAN Holdings, Inc. Deferred Compensation Program for Employees.

[0001193125-26-073361:8k_2_02:108]
(2) Includes amortization of actuarial losses related to the Company's pension plan for employees in certain foreign countries.

[0001193125-26-073361:8k_2_02:109]
Supplemental Information

[0001193125-26-073361:8k_2_02:110]
Reconciliation of Net Loss inclusive of Non-Controlling Interest to

[0001193125-26-073361:8k_2_02:111]
Non-GAAP Net Income (Loss) inclusive of Non-Controlling Interest

[0001193125-26-073361:8k_2_02:112]
(Unaudited)

[0001193125-26-073361:8k_2_02:113]
and

[0001193125-26-073361:8k_2_02:114]
Reconciliation of Net Loss attributable to ADTRAN Holdings, Inc. and

[0001193125-26-073361:8k_2_02:115]
Loss per Common Share attributable to ADTRAN Holdings, Inc. – Basic and Diluted to

[0001193125-26-073361:8k_2_02:116]
Non-GAAP Net Income (Loss) attributable to ADTRAN Holdings, Inc. and

[0001193125-26-073361:8k_2_02:117]
Non-GAAP Earnings (Loss) per Common Share attributable to ADTRAN Holdings, Inc. – Basic and Diluted

[0001193125-26-073361:8k_2_02:118]
(Unaudited)

[0001193125-26-073361:8k_2_02:119]
(In thousands, except per share amounts)

[0001193125-26-073361:8k_2_02:120]
|  |  | Three Months Ended |  |  |  | Twelve Months Ended |  |  |
|  |  | December 31, 2025 |  |  | September 30, 2025 |  |  | December 31, 2024 |  |  |  | December 31, 2025 |  |  | December 31, 2024 |  |  |
| Net Loss attributable to ADTRAN Holdings, Inc. common stockholders |  | $ | (1,521 | ) |  | $ | (9,743 | ) |  | $ | (46,106 | ) |  |  | $ | (41,571 | ) |  | $ | (456,910 | ) |  |
| Effect of redemption of RNCI (1) |  |  | (2,075 | ) |  |  | (519 | ) |  |  | (5 | ) |  |  |  | (4,085 | ) |  |  | (2,981 | ) |  |
| Net Loss attributable to ADTRAN Holdings, Inc. |  | $ | (3,596 | ) |  | $ | (10,262 | ) |  | $ | (46,111 | ) |  |  | $ | (45,656 | ) |  | $ | (459,891 | ) |  |
| Net Income attributable to non-controlling interest (2) |  |  | 2,316 |  |  |  | 2,505 |  |  |  | 2,407 |  |  |  |  | 9,413 |  |  |  | 9,824 |  |  |
| Net Loss inclusive of non-controlling interest |  | $ | (1,280 | ) |  | $ | (7,757 | ) |  | $ | (43,704 | ) |  |  | $ | (36,243 | ) |  | $ | (450,067 | ) |  |
| Acquisition related expenses, amortization and adjustments (3) |  |  | 11,769 |  |  |  | 12,038 |  |  |  | 15,274 |  |  |  |  | 48,661 |  |  |  | 62,959 |  |  |
| Stock-based compensation expense |  |  | 1,324 |  |  |  | 2,855 |  |  |  | 3,169 |  |  |  |  | 10,062 |  |  |  | 13,951 |  |  |
| Deferred compensation adjustments (4) |  |  | (180 | ) |  |  | 107 |  |  |  | 639 |  |  |  |  | 95 |  |  |  | 269 |  |  |
| Pension adjustments (5) |  |  | 12 |  |  |  | 13 |  |  |  | 7 |  |  |  |  | 47 |  |  |  | 28 |  |  |
| Restructuring expenses (6) |  |  | — |  |  |  | — |  |  |  | 4,105 |  |  |  |  | (284 | ) |  |  | 44,681 |  |  |
| Integration expenses (7) |  |  | — |  |  |  | — |  |  |  | 464 |  |  |  |  | — |  |  |  | 1,911 |  |  |
| Goodwill impairment |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  | — |  |  |  | 297,353 |  |  |
| Professional fees and other expenses (8) |  |  | 1,988 |  |  |  | 694 |  |  |  | — |  |  |  |  | 5,835 |  |  |  | — |  |  |
| Tax effect of adjustments to net loss |  |  | (628 | ) |  |  | (2,301 | ) |  |  | 20,675 |  |  |  |  | (4,521 | ) |  |  | 2,709 |  |  |
| Non-GAAP Net Income (Loss) inclusive of non-controlling interest |  | $ | 13,005 |  |  | $ | 5,649 |  |  | $ | 629 |  |  |  | $ | 23,652 |  |  | $ | (26,206 | ) |  |
| Net Income attributable to non-controlling interest (2) |  |  | 2,316 |  |  |  | 2,505 |  |  |  | 2,407 |  |  |  |  | 9,413 |  |  |  | 9,824 |  |  |
| Non-GAAP Net Income (Loss) attributable to ADTRAN Holdings, Inc. |  | $ | 10,689 |  |  | $ | 3,144 |  |  | $ | (1,778 | ) |  |  | $ | 14,239 |  |  | $ | (36,030 | ) |  |
| Effect of redemption of RNCI (1) |  |  | 2,075 |  |  |  | 519 |  |  |  | 5 |  |  |  |  | 4,085 |  |  |  | 2,981 |  |  |
| Non-GAAP Net Income (Loss) attributable to ADTRAN Holdings, Inc. common stockholders |  | $ | 12,764 |  |  | $ | 3,663 |  |  | $ | (1,773 | ) |  |  | $ | 18,324 |  |  | $ | (33,049 | ) |  |
| Weighted average shares outstanding – basic |  |  | 79,877 |  |  |  | 79,803 |  |  |  | 79,091 |  |  |  |  | 79,742 |  |  |  | 78,928 |  |  |
| Weighted average shares outstanding – diluted |  |  | 79,877 |  |  |  | 79,803 |  |  |  | 79,091 |  |  |  |  | 79,742 |  |  |  | 78,928 |  |  |
| Loss per common share attributable to ADTRAN Holdings, Inc. - basic |  | $ | (0.02 | ) |  | $ | (0.12 | ) |  | $ | (0.58 | ) |  |  | $ | (0.52 | ) |  | $ | (5.79 | ) |  |
| Loss per common share attributable to ADTRAN Holdings, Inc. - diluted |  | $ | (0.02 | ) |  | $ | (0.12 | ) |  | $ | (0.58 | ) |  |  | $ | (0.52 | ) |  | $ | (5.79 | ) |  |
| Non-GAAP Earnings (Loss) per common share attributable to ADTRAN Holdings, Inc. - basic |  | $ | 0.16 |  |  | $ | 0.05 |  |  | $ | (0.02 | ) |  |  | $ | 0.23 |  |  | $ | (0.42 | ) |  |
| Non-GAAP Earnings (Loss) per common share attributable to ADTRAN Holdings, Inc. - diluted |  | $ | 0.16 |  |  | $ | 0.05 |  |  | $ | (0.02 | ) |  |  | $ | 0.23 |  |  | $ | (0.42 | ) |  |

[0001193125-26-073361:8k_2_02:121]
(1) Loss per common share attributable to ADTRAN Holdings, Inc. - basic and diluted - reflects a $2.1 million and a $4.1 million effect of redemption of RNCI for the three and twelve months ended December 31, 2025 and a $0 and a $3.0 million effect of redemption of RNCI for the three and twelve months ended December 31, 2024.

[0001193125-26-073361:8k_2_02:122]
(2) Represents the non-controlling interest portion of the Company's ownership of Adtran Networks pre-DPLTA and the annual recurring compensation earned by redeemable non-controlling interests and accrued by the Company post-DPLTA.

[0001193125-26-073361:8k_2_02:123]
(3) We incur charges relating to the amortization of intangible assets and exclude these charges for purposes of calculating our non-GAAP measures. Such charges are significantly impacted by the timing and magnitude of our acquisitions. We exclude these charges for the purpose of calculating our non-GAAP measures, primarily because they are noncash expenses and our internal benchmarking analyses evidence that many industry participants and peers present non-GAAP financial measures excluding intangible asset amortization. Although this does not directly affect our cash position, the loss in value of intangible assets over time can have a material impact on the equivalent GAAP earnings measure.

[0001193125-26-073361:8k_2_02:124]
(4) Includes non-cash change in fair value of equity investments held in deferred compensation plans offered to certain employees.

[0001193125-26-073361:8k_2_02:125]
(5) Includes amortization of actuarial losses related to the Company's pension plan for employees in certain foreign countries.

[0001193125-26-073361:8k_2_02:126]
(6) Includes expenses for a Business Efficiency Program designed to optimize the assets and business processes following the business combination with Adtran Networks. The Business Efficiency Program was completed as of December 31, 2024.

[0001193125-26-073361:8k_2_02:127]
(7) Includes expenses related to the Company's one-time integration bonus program in connection with synergy targets as a result of the business combination with Adtran Networks. Includes fees incurred for the expansion of internal controls at Adtran Networks and the implementation of the DPLTA which was completed as of December 31, 2024.

[0001193125-26-073361:8k_2_02:128]
(8) Includes professional fees related to an internal investigation and a related SEC inquiry, a provision in connection with a potential 401(k) plan corrective action,  employee exit costs and fees relating to other one-time professional fees and business expenses.

[0001193125-26-073361:8k_2_02:129]
Supplemental Information

[0001193125-26-073361:8k_2_02:130]
Reconciliation of Net Cash Provided By Operating Activities to Free Cash Flow

[0001193125-26-073361:8k_2_02:131]
(Unaudited)

[0001193125-26-073361:8k_2_02:132]
(In thousands)

[0001193125-26-073361:8k_2_02:133]
|  |  | Three Months Ended |  |  |  | Twelve Months Ended |  |
|  |  | December 31, |  |  | September 30, |  |  | December 31, |  |  |  | December 31, |  |  | December 31, |  |
|  |  | 2025 |  |  | 2025 |  |  | 2024 |  |  |  | 2025 |  |  | 2024 |  |
| Net cash provided by operating activities |  | $ | 42,238 |  |  | $ | 12,188 |  |  | $ | 2,438 |  |  |  | $ | 129,767 |  |  | $ | 103,571 |  |
| Purchases of property, plant and equipment and developed technologies (1) |  |  | (19,708 | ) |  |  | (17,029 | ) |  |  | (14,335 | ) |  |  |  | (69,265 | ) |  |  | (65,172 | ) |
| Free cash flow (Non-GAAP) |  | $ | 22,530 |  |  | $ | (4,841 | ) |  | $ | (11,897 | ) |  |  | $ | 60,502 |  |  | $ | 38,399 |  |

[0001193125-26-073361:8k_2_02:134]
(1) Purchases related to capital expenditures and developed technologies.
