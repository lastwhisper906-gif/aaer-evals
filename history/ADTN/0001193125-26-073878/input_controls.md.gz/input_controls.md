# ADTN 10-K controls and the auditor's report


## auditors_report

[0001193125-26-073878:auditors_report:1]
Report of Independent Registered Public Accounting Firm

[0001193125-26-073878:auditors_report:2]
To the Board of Directors and Stockholders of ADTRAN Holdings, Inc.

[0001193125-26-073878:auditors_report:3]
Opinions on the Financial Statements and Internal Control over Financial Reporting

[0001193125-26-073878:auditors_report:4]
We have audited the accompanying consolidated balance sheets of ADTRAN Holdings, Inc. and its subsidiaries (the "Company") as of December 31, 2025 and 2024, and the related consolidated statements of loss, of comprehensive income (loss), of changes in equity and of cash flows for each of the three years in the period ended December 31, 2025, including the related notes and financial statement schedule listed in the accompanying index (collectively referred to as the "consolidated financial statements"). We also have audited the Company's internal control over financial reporting as of December 31, 2025, based on criteria established in Internal Control - Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO).

[0001193125-26-073878:auditors_report:5]
In our opinion, the consolidated financial statements referred to above present fairly, in all material respects, the financial position of the Company as of December 31, 2025 and 2024, and the results of its operations and its cash flows for each of the three years in the period ended December 31, 2025 in conformity with accounting principles generally accepted in the United States of America. Also in our opinion, the Company did not maintain, in all material respects, effective internal control over financial reporting as of December 31, 2025, based on criteria established in Internal Control - Integrated Framework (2013) issued by the COSO because material weaknesses in internal control over financial reporting existed as of that date as the Company did not design and maintain effective controls (i) in response to the risks of material misstatement and (ii) over financial statement preparation, presentation and disclosure commensurate with its financial reporting requirements.

[0001193125-26-073878:auditors_report:6]
A material weakness is a deficiency, or a combination of deficiencies, in internal control over financial reporting, such that there is a reasonable possibility that a material misstatement of the annual or interim financial statements will not be prevented or detected on a timely basis. The material weaknesses referred to above are described in Management’s Report on Internal Control over Financial Reporting appearing under Item 9A. We considered these material weaknesses in determining the nature, timing, and extent of audit tests applied in our audit of the 2025 consolidated financial statements, and our opinion regarding the effectiveness of the Company’s internal control over financial reporting does not affect our opinion on those consolidated financial statements.

[0001193125-26-073878:auditors_report:7]
Basis for Opinions

[0001193125-26-073878:auditors_report:8]
The Company's management is responsible for these consolidated financial statements, for maintaining effective internal control over financial reporting, and for its assessment of the effectiveness of internal control over financial reporting, included in management's report referred to above. Our responsibility is to express opinions on the Company’s consolidated financial statements and on the Company's internal control over financial reporting based on our audits. We are a public accounting firm registered with the Public Company Accounting Oversight Board (United States) (PCAOB) and are required to be independent with respect to the Company in accordance with the U.S. federal securities laws and the applicable rules and regulations of the Securities and Exchange Commission and the PCAOB.

[0001193125-26-073878:auditors_report:9]
We conducted our audits in accordance with the standards of the PCAOB. Those standards require that we plan and perform the audits to obtain reasonable assurance about whether the consolidated financial statements are free of material misstatement, whether due to error or fraud, and whether effective internal control over financial reporting was maintained in all material respects.

[0001193125-26-073878:auditors_report:10]
Our audits of the consolidated financial statements included performing procedures to assess the risks of material misstatement of the consolidated financial statements, whether due to error or fraud, and performing procedures that respond to those risks. Such procedures included examining, on a test basis, evidence regarding the amounts and disclosures in the consolidated financial statements. Our audits also included evaluating the accounting principles used and significant estimates made by management, as well as evaluating the overall presentation of the consolidated financial statements. Our audit of internal control over financial reporting included obtaining an understanding of internal control over financial reporting, assessing the risk that a material weakness exists, and testing and evaluating the design and operating effectiveness of internal control based on the assessed risk. Our audits also included performing such other procedures as we considered necessary in the circumstances. We believe that our audits provide a reasonable basis for our opinions.

[0001193125-26-073878:auditors_report:11]
Definition and Limitations of Internal Control over Financial Reporting

[0001193125-26-073878:auditors_report:12]
A company’s internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. A company’s internal control over financial reporting includes those policies and procedures that (i) pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of the company; (ii) provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of the company are being made only in accordance with authorizations of management and directors of the company; and (iii) provide reasonable assurance regarding

[0001193125-26-073878:auditors_report:13]
70

[0001193125-26-073878:auditors_report:14]
prevention or timely detection of unauthorized acquisition, use, or disposition of the company’s assets that could have a material effect on the financial statements.

[0001193125-26-073878:auditors_report:15]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0001193125-26-073878:auditors_report:16]
Critical Audit Matters

[0001193125-26-073878:auditors_report:17]
The critical audit matter communicated below is a matter arising from the current period audit of the consolidated financial statements that was communicated or required to be communicated to the audit committee and that (i) relates to accounts or disclosures that are material to the consolidated financial statements and (ii) involved our especially challenging, subjective, or complex judgments. The communication of critical audit matters does not alter in any way our opinion on the consolidated financial statements, taken as a whole, and we are not, by communicating the critical audit matter below, providing a separate opinion on the critical audit matter or on the accounts or disclosures to which it relates.

[0001193125-26-073878:auditors_report:18]
Valuation of Inventory – Estimate of Certain Excess and Obsolete Reserves

[0001193125-26-073878:auditors_report:19]
As described in Notes 1 and 5 to the consolidated financial statements, the Company’s consolidated net inventory as of December 31, 2025 was $215.7 million, of which certain inventory is subject to certain excess and obsolete reserves. Management establishes reserves for estimated excess and obsolete inventory equal to the difference between the cost of the inventory and the estimated net realizable value of the inventory based on estimated reserve percentages, which consider historical usage, known trends, inventory age, and market conditions.

[0001193125-26-073878:auditors_report:20]
The principal considerations for our determination that performing procedures relating to the valuation of inventory – estimate of certain excess and obsolete reserves is a critical audit matter are (i) the significant judgment by management when developing the estimate of certain excess and obsolete inventory reserves and (ii) a high degree of auditor judgment, subjectivity, and effort in performing procedures and evaluating management’s significant assumption related to the estimated reserve percentages.

[0001193125-26-073878:auditors_report:21]
Addressing the matter involved performing procedures and evaluating audit evidence in connection with forming our overall opinion on the consolidated financial statements. These procedures included testing the effectiveness of controls relating to certain excess and obsolete inventory reserves, including controls over the significant assumption related to estimated reserve percentages. These procedures also included, among others (i) testing management’s process for developing the estimate of certain excess and obsolete inventory reserves; (ii) evaluating the appropriateness of management’s estimation methodology; (iii) testing the completeness and accuracy of the underlying data used in developing the estimate of certain excess and obsolete inventory reserves, including historical usage, known trends, and inventory age; and (iv) evaluating the reasonableness of the significant assumption used by management related to the estimated reserve percentages. Evaluating management’s assumption related to the estimated reserve percentages involved considering (i) the current and past results of the Company; (ii) a comparison of the prior year estimate to actual activity in the current year; and (iii) whether the assumption was consistent with evidence obtained in other areas of the audit.

[0001193125-26-073878:auditors_report:22]
/s/PricewaterhouseCoopers LLP

[0001193125-26-073878:auditors_report:23]
Birmingham, Alabama

[0001193125-26-073878:auditors_report:24]
February 26, 2026

[0001193125-26-073878:auditors_report:25]
We have served as the Company’s auditor since 1986.

[0001193125-26-073878:auditors_report:26]
71

[0001193125-26-073878:auditors_report:27]
Financial Statements

[0001193125-26-073878:auditors_report:28]
ADTRAN Holdings, Inc.


## item_9a

[0001193125-26-073878:item_9a:1]
ITEM 9A. CONTROLS AND PROCEDURES

[0001193125-26-073878:item_9a:2]
Evaluation of Disclosure Controls and Procedures

[0001193125-26-073878:item_9a:3]
We maintain disclosure controls and procedures that are designed to ensure that the information required to be disclosed by us in reports that we file or submit under the Securities Exchange Act of 1934, as amended (the “Exchange Act”), is recorded, processed, summarized and reported within the time periods specified in the rules and forms promulgated by the SEC, and that such information is accumulated and communicated to our management, including our Chief Executive Officer and our Chief Financial Officer, as appropriate, to allow timely decisions regarding required disclosure.

[0001193125-26-073878:item_9a:4]
As of the end of the period covered by this report, an evaluation was carried out by management, including our Chief Executive Officer and Chief Financial Officer, of the effectiveness of our disclosure controls and procedures (as defined in Rules 13a-15(e) and 15d-15(e)) under the Exchange Act. Based on that evaluation, our Chief Executive Officer and Chief Financial Officer concluded that due to the material weaknesses in our internal control over financial reporting described below, our disclosure controls and procedures were not effective as of December 31, 2025.

[0001193125-26-073878:item_9a:5]
Management’s Report on Internal Control over Financial Reporting

[0001193125-26-073878:item_9a:6]
Management of ADTRAN Holdings, Inc. (“Adtran”) is responsible for establishing and maintaining adequate internal control over financial reporting as defined in Rules 13a-15(f) and 15d-15(f) under the Exchange Act. Adtran’s internal control over financial reporting is a process designed to provide reasonable assurance regarding the reliability of financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. Adtran’s internal control over financial reporting includes those policies and procedures that:

[0001193125-26-073878:item_9a:7]
•
pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of Adtran;

[0001193125-26-073878:item_9a:8]
•
provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of Adtran are being made only in accordance with authorizations of management and directors of Adtran; and

[0001193125-26-073878:item_9a:9]
•
provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use or disposition of Adtran’s assets that could have a material effect on the financial statements.

[0001193125-26-073878:item_9a:10]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0001193125-26-073878:item_9a:11]
Management assessed the effectiveness of Adtran’s internal control over financial reporting as of December 31, 2025. In making this assessment, management used the criteria set forth by the Committee of Sponsoring Organizations of the Treadway Commission ("COSO") in “Internal Control-Integrated Framework” (2013).

[0001193125-26-073878:item_9a:12]
A material weakness is a deficiency, or a combination of deficiencies, in internal control over financial reporting, such that there is a reasonable possibility that a material misstatement of our annual or interim financial statements will not be prevented or detected on a timely basis.

[0001193125-26-073878:item_9a:13]
Management determined the following material weaknesses existed as of December 31, 2025:

[0001193125-26-073878:item_9a:14]
•
Adtran did not design and maintain effective controls in response to the risks of material misstatement. Specifically, changes to existing controls or the implementation of new controls have not been sufficient to respond to changes to the risks of material misstatement to financial reporting. This material weakness contributed to the following additional material weakness.

[0001193125-26-073878:item_9a:15]
•
Adtran did not design and maintain effective controls over financial statement preparation, presentation and disclosure commensurate with its financial reporting requirements. Specifically, Adtran did not design and maintain effective controls over the presentation and disclosure of transactions, including non-controlling interest.

[0001193125-26-073878:item_9a:16]
The material weaknesses resulted in the restatements and revisions to our consolidated financial statements for the years ended December 31, 2022, 2023, and 2024, as well as the condensed consolidated financial statements for the quarterly and year-to-date periods ended September 30, 2022, March 31, 2023, June 30, 2023, September 30, 2023, March 31, 2024, June 30, 2024, and September 30, 2024. The material weaknesses also resulted in material adjustments that were corrected prior to the issuance of the condensed consolidated

[0001193125-26-073878:item_9a:17]
115

[0001193125-26-073878:item_9a:18]
financial statements for the quarterly period ended March 31, 2025. Additionally, these material weaknesses could result in misstatements of Adtran’s accounts or disclosures that would result in a material misstatement to the annual or interim consolidated financial statements that would not be prevented or detected.

[0001193125-26-073878:item_9a:19]
Because of these material weaknesses, management has concluded that Adtran did not maintain effective internal control over financial reporting as of December 31, 2025.

[0001193125-26-073878:item_9a:20]
The effectiveness of Adtran's internal control over financial reporting as of December 31, 2025 has been audited by PricewaterhouseCoopers LLP, an independent registered public accounting firm, as stated in their report which appears in Part II, Item 8 of this report.

[0001193125-26-073878:item_9a:21]
Remediation of Previously Identified Material Weaknesses

[0001193125-26-073878:item_9a:22]
As previously reported in our 2024 Form 10-K/A, management identified the following material weaknesses in our internal control over financial reporting, which have been remediated as of December 31, 2025:

[0001193125-26-073878:item_9a:23]
•
Adtran did not design and maintain effective controls relating to communicating accurate information internally and with those charged with governance. This includes providing information pursuant to objectives, responsibilities and functions of internal control.

[0001193125-26-073878:item_9a:24]
•
Adtran did not design and maintain effective controls to address the initial application of complex accounting standards and accounting of non-routine, unusual or complex events and transactions. Specifically, Adtran did not design and maintain effective controls to timely analyze and account for (i) non-controlling interest and (ii) a receivable purchase and servicing agreement.

[0001193125-26-073878:item_9a:25]
•
Adtran did not design and maintain effective controls over an inventory suspense account. Specifically, certain inventory activity was not reviewed at a sufficient level of precision to identify the nature and aging of the individual inventory suspense account activity.

[0001193125-26-073878:item_9a:26]
Following the identification of the material weaknesses and continuing throughout the year ended December 31, 2025, management executed its remediation plan through the following actions:

[0001193125-26-073878:item_9a:27]
•
Adtran implemented and enhanced key internal controls and communication policies, training sessions for personnel on internal control expectations, a quarterly sub-certification process, and redesigned controls over the identification and review of contracts, transactions or arrangements that may result in a financial obligation to remediate the material weakness relating to the communication of accurate information internally and with those charged with governance.

[0001193125-26-073878:item_9a:28]
•
Adtran implemented redesigned controls over the identification and review of contracts, transactions or arrangements that may result in a financial obligation including the use of an accounting or reporting third-party advisor as needed to ensure proper presentation of these items within its consolidated financial statements to remediate the material weaknesses relating to accounting for non-routine, unusual or complex events and transactions for non-controlling interest and the receivable purchase and servicing agreement.

[0001193125-26-073878:item_9a:29]
•
Adtran redesigned the reconciliation control specific to the inventory suspense account and enhanced its review procedures (including review of aged items and training sessions for personnel on reconciliation procedures) to remediate the material weakness relating to maintaining effective controls over that account.

[0001193125-26-073878:item_9a:30]
As a result of the actions taken above, management has determined that the controls were effectively designed and demonstrated effective operation for a sufficient period of time to enable the Company to conclude that these material weaknesses in internal control over financial reporting have been remediated as of December 31, 2025.

[0001193125-26-073878:item_9a:31]
Management’s On-Going Remediation Efforts

[0001193125-26-073878:item_9a:32]
As previously reported in our 2024 Form 10-K/A, management identified material weaknesses in our internal control over financial reporting, two of which continue to exist as of December 31, 2025, as disclosed above. Management has made and continues to make progress towards remediating these material weaknesses.  Remediation of the material weaknesses and strengthening our internal control environment is a top priority.

[0001193125-26-073878:item_9a:33]
To remediate the material weaknesses in Adtran’s internal control over financial reporting related to the risks of material misstatement and financial statement preparation, presentation and disclosure of transactions, including non-controlling interest, Adtran completed the following activities during the second half of 2025:

[0001193125-26-073878:item_9a:34]
•
The global identification and reassessment of all key risks, processes and controls.

[0001193125-26-073878:item_9a:35]
•
Increased training and awareness of control activities, and increased scrutiny of control performance and documentation standards.

[0001193125-26-073878:item_9a:36]
116

[0001193125-26-073878:item_9a:37]
•
Hired additional resources, enhancing global leadership in the Accounting function, and strengthening the overall technical skill set and capacity.

[0001193125-26-073878:item_9a:38]
•
Adtran enhanced existing controls over the review of Adtran’s consolidated financial statements, and in the fourth quarter of 2025 completed the implementation of additional financial statement review controls.

[0001193125-26-073878:item_9a:39]
Adtran’s management believes that the continued operation of the activities outlined above in subsequent reporting periods will be effective in remediating such material weaknesses.  The material weaknesses cannot be considered remediated until the applicable controls have operated for a sufficient period of time and management has concluded that, through testing, these controls are operating effectively.

[0001193125-26-073878:item_9a:40]
Changes in Internal Control over Financial Reporting

[0001193125-26-073878:item_9a:41]
The fourth quarter remediation activities described above are the only changes in the Company’s internal control over financial reporting during the quarter ended December 31, 2025 that have materially affected, or are reasonably likely to materially affect, the Company’s internal control over financial reporting.
