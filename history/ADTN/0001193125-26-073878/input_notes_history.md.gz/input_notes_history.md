# ADTN note change history — 0000950170-25-102561 → 0001193125-25-264157


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2025-11-04):
[0001193125-25-264157:note_history:1]
On August 4, 2025, we received a letter from the Atlanta regional office of the SEC in connection with a non-public, fact-finding inquiry, requesting that we voluntarily provide information regarding the internal investigation referenced in Note 1, “Summary of Significant Accounting Policies”. We intend to cooperate in response to the SEC’s inquiry. We cannot predict the timing or outcome of the inquiry.

- changed (2025-11-04):
[0001193125-25-264157:note_history:2]
Pursuant to the terms of the DPLTA, each Adtran Networks shareholder (other than the Company) has received an offer to elect either (1) to remain an Adtran Networks shareholder and receive from us an Annual Recurring Compensation payment, or (2) to receive Exit Compensation plus guaranteed interest. The guaranteed interest under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid. The guaranteed interest rate is 5.0% plus a variable component (according to the German Civil Code) that was 1.27% as of September 30, 2025. Assuming all the minority holders of currently outstanding Adtran Networks shares were to elect the second option, the Company would be obligated to make aggregate Exit Compensation payments, including guaranteed interest, of approximately €322.7 million or $378.7 million, based on an exchange rate as of September 30, 2025, and reflecting interest accrued through September 30, 2025, during the pendency of the appraisal proceedings discussed below. Shareholders electing the first option of Annual Recurring Compensation may later elect the second option. The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that were initiated in 2023 in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the
  (was, 2025-08-05, similarity 0.8788):
[0000950170-25-102561:note_history:2]
Pursuant to the terms of the DPLTA, each Adtran Networks shareholder (other than the Company) has received an offer to elect either (1) to remain an Adtran Networks shareholder and receive from us an Annual Recurring Compensation payment, or (2) to receive Exit Compensation plus guaranteed interest. The guaranteed interest under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid. The guaranteed interest rate is 5.0% plus a variable component (according to the German Civil Code) that was 2.27% as of June 30, 2025. Assuming all the minority holders of currently outstanding Adtran Networks shares were to elect the second option, the Company would be obligated to make aggregate Exit Compensation payments, including guaranteed interest, of approximately €326.8 million or $385.2 million, based on an exchange rate as of June 30, 2025, and reflecting interest accrued through June 30, 2025, during the pendency of the appraisal proceedings discussed below. Shareholders electing the first option of Annual Recurring Compensation may later elect the second option. The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that were initiated in 2023 in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger). The court has decided a procedural matter in the DPLTA appraisal proceedings; the parties may or may not choose to appeal such decision, if able, and the proceeding for the trial on the merits of the DPLTA will continue. It is expected to take a minimum of 12 months for a ruling of the court on the merits and such ruling will most likely be appealed, which would be expected to

- added (2025-11-04):
[0001193125-25-264157:note_history:3]
Federal Gazette (Bundesanzeiger). Following the court's decision on a procedural matter in the DPLTA appraisal proceedings on July 14, 2025, the proceeding for the trial on the merits of the DPLTA has recommenced. It is expected to take a minimum of 12 months for a ruling of the court on the merits and such ruling will most likely be appealed, which would be expected to take an additional 12-24 months to be resolved. Accordingly, the Company does not expect a final decision on the DPLTA appraisal proceedings to be rendered and published prior to 2027, and most likely not until 2028 or beyond.

- changed (2025-11-04):
[0001193125-25-264157:note_history:4]
Our obligation to pay Annual Recurring Compensation under the DPLTA is a continuing payment obligation, which will amount to approximately €8.5 million (or $10.0 million based on the exchange rate as of September 30, 2025) per year assuming none of the minority Adtran Networks shareholders were to elect Exit Compensation. The foregoing amounts do not reflect any potential increase in payment obligations that we may have depending on the outcome of ongoing appraisal proceedings in Germany. The Annual Recurring Compensation is due on the third banking day following the ordinary general shareholders’ meeting of Adtran Networks for the respective preceding fiscal year (but in any event within eight months following expiration of the fiscal year). With respect to the 2024 fiscal year, Adtran Networks’ ordinary general shareholders' meeting occurred on June 27, 2025 and, therefore, the Annual Recurring Compensation was paid on July 1, 2025. During the three months ended September 30, 2025 and 2024, we accrued $2.5 million and $2.4 million, respectively, in Annual Recurring Compensation. During the nine months ended September 30, 2025 and 2024, we accrued $7.5 million and $7.4 million, respectively, in Annual Recurring Compensation, which was reflected as an increase to retained deficit.
  (was, 2025-08-05, similarity 0.9698):
[0000950170-25-102561:note_history:4]
Our obligation to pay Annual Recurring Compensation under the DPLTA is a continuing payment obligation, which will amount to approximately €8.5 million (or $10.0 million based on the exchange rate as of June 30, 2025) per year assuming none of the minority Adtran Networks shareholders were to elect Exit Compensation. The foregoing amounts do not reflect any potential increase in payment obligations that we may have depending on the outcome of ongoing appraisal proceedings in Germany. The Annual Recurring Compensation is due on the third banking day following the ordinary general shareholders’ meeting of Adtran Networks for the respective preceding fiscal year (but in any event within eight months following expiration of the fiscal year). With respect to the 2024 fiscal year, Adtran Networks’ ordinary general shareholders meeting occurred on June 27, 2025 and, therefore, the Annual Recurring Compensation was paid on July 1, 2025. During the three months ended June 30, 2025 and 2024, we accrued $2.4 million and $2.5 million, respectively, in Annual Recurring Compensation. During the six months ended June 30, 2025 and 2024, we accrued $4.8 million and $5.0 million, respectively, in Annual Recurring Compensation, which was reflected as an increase to retained deficit.

- added (2025-11-04):
[0001193125-25-264157:note_history:5]
For the three and nine months ended September 30, 2025, less than one thousand shares and approximately 0.9 million shares, respectively, of Adtran Networks stock were tendered to the Company. This resulted in total Exit Compensation payments of approximately €16.9 million, or $19.9 million based on the applicable exchange rates at the time of the transactions, being paid to Adtran Networks shareholders. For the three and nine months ended September 30, 2024, 0.8 million shares of Adtran Networks stock were tendered to the Company. This resulted in total Exit Compensation payments of approximately €15.7 million, or approximately $17.4 million, respectively, based on the applicable exchange rates at the time of the transactions, being paid to Adtran Networks shareholders.

- changed (2025-11-04):
[0001193125-25-264157:note_history:6]
Certain contracts, customers and jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of September 30, 2025 and December 31, 2024, we had commitments related to these bonds totaling $18.0 million and $15.7 million, respectively, which expire at various dates through April 2029. In general, we would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which we believe is remote.
  (was, 2025-08-05, similarity 0.9874):
[0000950170-25-102561:note_history:6]
Certain contracts, customers and jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of June 30, 2025 and December 31, 2024, we had commitments related to these bonds totaling $16.9 million and $15.7 million, respectively, which expire at various dates through April 2029. In general, we would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which we believe is remote.

- changed (2025-11-04):
[0001193125-25-264157:note_history:7]
The Company purchases components from a variety of suppliers and uses contract manufacturers to provide manufacturing services for our products. Our inventory purchase obligations are for product manufacturing requirements, as well as for commitments to suppliers to secure manufacturing capacity. Certain of our inventory purchase obligations with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. As of September 30, 2025, purchase obligations totaled $211.2 million.
  (was, 2025-08-05, similarity 0.9882):
[0000950170-25-102561:note_history:7]
The Company purchases components from a variety of suppliers and uses contract manufacturers to provide manufacturing services for our products. Our inventory purchase obligations are for product manufacturing requirements, as well as for commitments to suppliers to secure manufacturing capacity. Certain of our inventory purchase obligations with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. As of June 30, 2025, purchase obligations totaled $192.7 million.

- removed (2025-11-04):
[0000950170-25-102561:note_history:8]
take an additional 12-24 months to be resolved. Accordingly, the Company does not expect a final decision on the DPLTA appraisal proceedings to be rendered and published prior to 2027, and most likely not until 2028 or beyond.

- removed (2025-11-04):
[0000950170-25-102561:note_history:9]
For the three and six months ended June 30, 2025, approximately 0.9 million shares, of Adtran Networks stock were tendered to the Company. This resulted in total Exit Compensation payments of approximately €16.9 million, or $19.4 million based on the applicable exchange rates at the time of the transactions, being paid to Adtran Networks shareholders. For the three and six months ended June 30, 2024, approximately one thousand shares of Adtran Networks stock were tendered to the Company. This resulted in Exit Compensation payments of approximately €19 thousand and €23 thousand, respectively, or $20 thousand and $25 thousand, respectively, based on the applicable exchange rates at the time of the transactions, being paid to Adtran Networks shareholders.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2025-11-04):
[0001193125-25-264157:note_history:10]
Liquidity, Domination and Profit and Loss Transfer Agreement, Notes Offering and Credit Facility
  (was, 2025-08-05, similarity 0.9091):
[0000950170-25-102561:note_history:10]
Liquidity, Domination and Profit and Loss Transfer Agreement and Credit Facility

- added (2025-11-04):
[0001193125-25-264157:note_history:11]
Pursuant to the terms of the DPLTA, each Adtran Networks shareholder (other than the Company) has received an offer to elect either (1) to remain an Adtran Networks shareholder and receive from us recurring compensation in cash of €0.52 per share for each full fiscal year of Adtran Networks (the "Annual Recurring Compensation"), or (2) to put their Adtran Networks shares to the Company in exchange for compensation in cash of €17.21 per share, plus guaranteed interest (the "Exit Compensation"). The guaranteed interest under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid. The guaranteed interest rate is 5.0% plus a variable component (according to the German Civil Code) that was 1.27% as of September 30, 2025. Assuming all the minority holders of currently outstanding Adtran Networks shares were to elect the second option, we would be obligated to make aggregate Exit Compensation payments, including guaranteed interest, of approximately €322.7 million or $378.7 million, based on an exchange rate as of September 30, 2025, and reflecting interest accrued through September 30, 2025 during the pendency of the appraisal proceedings discussed below. Shareholders electing the first option of Annual Recurring Compensation may later elect the second option. The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that were initiated in 2023 in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger). Following the court's decision on a procedural matter in the DPLTA appraisal proceedings on July 14, 2025, the trial on the merits of the DPLTA has recommenced. It is expected to take a minimum of 12 months for a ruling of the court on the merits and such ruling will most likely be appealed, which would be expected to take an additional 12-24 months to be resolved. Accordingly, the Company does not expect a final decision on the DPLTA appraisal proceedings to be rendered and published prior to 2027, and most likely not until 2028 or beyond.

- changed (2025-11-04):
[0001193125-25-264157:note_history:12]
Additionally, our obligation to pay Annual Recurring Compensation under the DPLTA is a continuing payment obligation, which will amount to approximately €8.5 million (or $10.0 million based on the exchange rate as of September 30, 2025) per year assuming none of the minority Adtran Networks shareholders as of September 30, 2025 were to elect Exit Compensation. The foregoing amounts do not reflect any potential increase in payment obligations that we may have depending on the outcome of ongoing appraisal proceedings in the German court. The Annual Recurring Compensation is due on the third banking day following the ordinary general shareholders’ meeting of Adtran Networks for the respective preceding fiscal year (but in any event within eight months following expiration of the fiscal year). With respect to the 2023 fiscal year, Adtran Networks’ ordinary general shareholders’ meeting occurred on June 28, 2024 and, therefore, the Annual Recurring Compensation was paid on July 3, 2024. With respect to the 2024 fiscal year, Adtran Networks’ ordinary general shareholder meeting occurred on June 27, 2025 and, therefore, the Annual Recurring Compensation was paid on July 1, 2025. During the three months ended September 30, 2025 and 2024, we accrued $2.5 million and $2.4 million, respectively, in Annual Recurring Compensation. During the nine months ended September 30, 2025 and 2024, we accrued $7.5 million and $7.4 million, respectively, in Annual Recurring Compensation. The Annual Recurring Compensation is reflected as an increase to retained deficit.
  (was, 2025-08-05, similarity 0.6342):
[0000950170-25-102561:note_history:12]
Additionally, our obligation to pay Annual Recurring Compensation under the DPLTA is a continuing payment obligation, which will amount to approximately €8.5 million (or $10.0 million based on the exchange rate as of June 30, 2025) per year assuming none of the minority Adtran Networks shareholders as of June 30, 2025 were to elect Exit Compensation. The foregoing amounts do not reflect any potential increase in payment obligations that we may have depending on the outcome of ongoing appraisal proceedings in Germany. The Annual Recurring Compensation is due on the third banking day following the ordinary general shareholders’ meeting of Adtran Networks for the respective preceding fiscal year (but in any event within eight months following expiration of the fiscal year). With respect to the 2023 fiscal year, Adtran Networks’ ordinary general shareholders’ meeting occurred on June 28, 2024 and, therefore, the Annual Recurring Compensation was paid on July 3, 2024. With respect to the 2024 fiscal year, Adtran Networks’ ordinary general shareholder meeting occurred on June 27, 2025 and, therefore, the Annual Recurring Compensation was paid on July 1, 2025. During the three months ended June 30, 2025 and 2024, we accrued $2.4 million and $2.5 million, respectively, in Annual Recurring Compensation. During the six months ended June 30, 2025 and 2024, we accrued $4.8 million and $5.0 million, respectively, in Annual Recurring Compensation. The Annual Recurring Compensation is reflected as an increase to retained deficit in the Condensed Consolidated Balance Sheets.

- changed (2025-11-04):
[0001193125-25-264157:note_history:13]
On July 18, 2022, ADTRAN, Inc., as the borrower, and ADTRAN Holdings, Inc. entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (“Credit Agreement”), which has since been amended six times. The Company had access to $319.2 million on its Credit Facility for future borrowings; however, as of September 30, 2025, the Company was limited to additional borrowings of $232.0 million based on debt covenant compliance metrics. The financial covenants under the Credit Agreement, as amended, require the Company to maintain a Consolidated Total Net Leverage Ratio of 5.00x, a Consolidated Senior Secured Net Leverage Ratio of 3.25x (4.0x to 3.5x during a Springing Covenant Period) and a Consolidated Fixed Charge Coverage Ratio of 1.25x (as such terms are defined in the Credit Agreement). In addition, during a Springing Covenant Period the cash and cash equivalents of the credit parties must be at least $50.0 million and the cash and cash equivalents of the Company and its subsidiaries must be at least $70.0 million. See Note 11, Credit Agreement for additional information regarding the terms of the Wells Fargo Credit Agreement.
  (was, 2025-08-05, similarity 0.7617):
[0000950170-25-102561:note_history:13]
On July 18, 2022, ADTRAN, Inc., as the borrower, and ADTRAN Holdings, Inc. entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (“Credit Agreement”), which has since been amended five times. The Company had access to $156.5 million on its Credit Facility for future borrowings; however, as of June 30, 2025, the Company was limited to additional borrowings of $66.8 million based on debt covenant compliance metrics. The financial covenants under the Credit Agreement, as amended, require the Company to maintain a Consolidated Total Net Leverage Ratio of 5.00x, a Consolidated Senior Secured Net Leverage Ratio of 3.25x (4.0x to 3.5x during a Springing Covenant Period) and a Consolidated Fixed Charge Coverage Ratio of 1.25x. See Note 10, Credit Agreements for additional information regarding the terms of the Wells Fargo Credit Agreement.

- added (2025-11-04):
[0001193125-25-264157:note_history:14]
As of September 30, 2025, and as of the date of issuance of these financial statements, the Company has sufficient liquidity to meet a majority of its payment obligations under the DPLTA pertaining to Exit Compensation. For the three and nine months ended September 30, 2025, less than one thousand shares and approximately 0.9 million shares, respectively, of Adtran Networks stock were tendered to the Company. This resulted in total Exit Compensation payments of approximately €16.9 million or $19.9 million based on the applicable exchange rates at the time of the transactions being paid to Adtran Networks shareholders. For the three and nine months ended September 30, 2024, approximately 0.8 million shares of Adtran Networks stock were tendered to the Company. This resulted in Exit Compensation payments of approximately €15.7 million, or $17.4 million, based on the applicable exchange rates at the time of the transactions, being paid to Adtran Networks shareholders. We believe the probability that more than a small minority of Adtran Networks shareholders elect to receive Exit Compensation in the next twelve months is remote based on the following factors: (i) the shareholders can exercise their right to receive the Exit Compensation until two months after publication of the final decision in the appraisal proceedings and we do not expect the final decision to be published within the next 12 months; (ii) the diverse base of shareholders that must make this election on an individual shareholder basis; (iii) the fact the date of a decision by the court on the merits of the case is uncertain, it will most likely take a minimum of 12 months for a ruling and, thereafter, an expected appeal process will take a further 12-24 months to resolve; (iv) the current guaranteed Annual Recurring Compensation payment; and (v) the current trading value of Adtran Networks shares.

- added (2025-11-04):
[0001193125-25-264157:note_history:15]
Moreover, on September 19, 2025, the Company issued $201.3 million aggregate principal amount of convertible senior notes due 2030 (the “Notes”). The Notes accrue interest at a rate of 3.75% per annum, payable semi-annually in arrears on March 15 and September 15 of each year, beginning March 15, 2026. Unless repurchased earlier, redeemed, or converted, the Notes will mature on September 15, 2030. After deducting the initial purchasers’ discounts, commissions, and estimated offering expenses, the Company received net proceeds of $192.8 million. As of September 30, 2025, and as of the date of issuance of these financial statements, management believes that the Company has sufficient liquidity to meet its payment obligations under the Notes through its operating cash flow and the borrowings available under the Credit Agreement.

- added (2025-11-04):
[0001193125-25-264157:note_history:16]
The Company experienced revenue declines in the year ended December 31, 2024. However, customers began replenishing their inventories to meet increasing demand, and revenue increased throughout the first three quarters of 2025. In 2023, the Company suspended dividend payments and effectuated a business efficiency program (the "Business Efficiency Program"), which targeted the reduction of ongoing operating expenses and focused on enhancing capital efficiency. The Business Efficiency Program was completed as of December 31, 2024. In addition, the Company continues to assess the probability that the sale of its headquarters in Huntsville will occur and has determined it is probable of occurring in the next twelve months.

- added (2025-11-04):
[0001193125-25-264157:note_history:17]
In summary, the Company believes that its cash, cash equivalents and restricted cash, working capital management initiatives and availability to access cash under the Wells Fargo credit facility will be adequate to meet our business operating requirements, our capital expenditures and our expected obligations under both the Notes and the DPLTA, including anticipated levels of Exit Compensation, as well as to support our ability to continue to comply with our debt covenants under the Credit Facility for at least the next twelve months,

- added (2025-11-04):
[0001193125-25-264157:note_history:18]
from the issuance of these financial statements. See Note 11, Credit Agreements, for additional information regarding the terms of the Amendments of the Credit Agreement.

- changed (2025-11-04):
[0001193125-25-264157:note_history:19]
In connection with the identification of the Adjustment, the Audit Committee oversaw an internal investigation into the circumstances surrounding the Adjustment and its impact on the Company’s historical financial statements. Based on the findings of the internal investigation, it was determined that the underlying errors giving rise to the Adjustment were not properly addressed in the Company’s previously filed financial statements as of and for the years ended December 31, 2024 and 2023 and were not communicated to the Audit Committee or the independent auditors prior to the filing of the initial 2024 Annual Report on Form 10-K. As described in Part I, Item 4 of this report, the Company is taking certain remedial actions to address the material weaknesses in its internal controls associated with these findings. On August 4, 2025, we received a letter from the Atlanta regional office of the SEC in connection with a non-public, fact-finding inquiry, requesting that we voluntarily provide information regarding the internal investigation.
  (was, 2025-08-05, similarity 0.982):
[0000950170-25-102561:note_history:19]
In connection with the identification of the Adjustment, the Audit Committee oversaw an internal investigation into the circumstances surrounding the Adjustment and its impact on the Company’s historical financial statements. Based on the findings of the internal investigation, it was determined that the underlying errors giving rise to the Adjustment were not properly addressed in the Company’s previously filed financial statements as of and for the years ended December 31, 2024 and 2023 and were not communicated to the Audit Committee or the independent auditors prior to the filing of the initial 2024 Annual Report on Form 10-K. As described in Part I, Item 4 of this report, the Company is taking certain remedial actions to address the material weaknesses in its internal controls associated with these findings. On August 4, 2025, we received a letter from the Atlanta regional office of the SEC in connection with a non-public, fact-finding inquiry, requesting that we voluntarily provide information regarding the internal investigation, which we will respond to accordingly.

- changed (2025-11-04):
[0001193125-25-264157:note_history:20]
The identified errors referenced above impacted the Condensed Consolidated Financial Statements as of and for the three and nine months ended September 30, 2024, among other periods as previously disclosed. Below is a summary description of the significant errors in the Company's Condensed Consolidated Financial Statements as of and for the three and nine months ended September 30, 2024:
  (was, 2025-08-05, similarity 0.8713):
[0000950170-25-102561:note_history:20]
The identified errors referenced above impacted the Condensed Consolidated Financial Statements as of and for the three and six months ended June 30, 2024, among other periods as previously disclosed. Below is a summary description of the significant errors in the Company's Condensed Consolidated Financial Statements as of and for the three and six months ended June 30, 2024:

- changed (2025-11-04):
[0001193125-25-264157:note_history:21]
We assessed the materiality of the errors on prior period consolidated financial statements in accordance with SEC Staff Accounting Bulletin No. 99, “Materiality,” codified in ASC Topic 250, Accounting Changes and Error Corrections. Based on this assessment, we concluded that the errors, in the aggregate, are material to the September 30, 2024 financial statements and therefore, we have restated
  (was, 2025-08-05, similarity 0.9755):
[0000950170-25-102561:note_history:21]
We assessed the materiality of the errors on prior period consolidated financial statements in accordance with SEC Staff Accounting Bulletin No. 99, “Materiality,” codified in ASC Topic 250, Accounting Changes and Error Corrections. Based on this assessment, we concluded that the errors, in the aggregate, are material to the June 30, 2024 financial statements and therefore, we have restated those

- changed (2025-11-04):
[0001193125-25-264157:note_history:22]
those financial statements herein. Furthermore, we made adjustments to correct for other previously identified immaterial errors. The Company has also restated impacted amounts within the accompanying footnotes to the Condensed Consolidated Financial Statements. See Note 20 for further information about the restatement.
  (was, 2025-08-05, similarity 0.9905):
[0000950170-25-102561:note_history:22]
financial statements herein. Furthermore, we made adjustments to correct for other previously identified immaterial errors. The Company has also restated impacted amounts within the accompanying footnotes to the Condensed Consolidated Financial Statements. See Note 18 for further information about the restatement.

- changed (2025-11-04):
[0001193125-25-264157:note_history:23]
We assessed certain accounting matters that generally require consideration of forecasted financial information in context with the information reasonably available to us and the unknown future impacts of ongoing inflationary pressures, continued elevated interest rates, currency fluctuations and political tensions as of September 30, 2025, and through the date of this report. These conditions could result in further impacts to the Company's consolidated financial statements in future reporting periods. The accounting matters assessed included, but were not limited to, the allowance for credit losses, stock-based compensation, carrying value of goodwill, intangibles and other long-lived assets, financial assets, valuation allowances for tax assets, revenue recognition and costs of revenue.
  (was, 2025-08-05, similarity 0.9918):
[0000950170-25-102561:note_history:23]
We assessed certain accounting matters that generally require consideration of forecasted financial information in context with the information reasonably available to us and the unknown future impacts of ongoing inflationary pressures, continued elevated interest rates, currency fluctuations and political tensions as of June 30, 2025, and through the date of this report. These conditions could result in further impacts to the Company's consolidated financial statements in future reporting periods. The accounting matters assessed included, but were not limited to, the allowance for credit losses, stock-based compensation, carrying value of goodwill, intangibles and other long-lived assets, financial assets, valuation allowances for tax assets, revenue recognition and costs of revenue.

- added (2025-11-04):
[0001193125-25-264157:note_history:24]
Restricted Cash

- added (2025-11-04):
[0001193125-25-264157:note_history:25]
Restricted cash consists of cash pledged as collateral, which is permitted to be withdrawn for the purpose of financing the purchase of additional outstanding shares of Equity Interests (as defined in the Credit Agreement) of Adtran Networks. See Note 11 for additional information.

- added (2025-11-04):
[0001193125-25-264157:note_history:26]
Convertible Senior Notes

- added (2025-11-04):
[0001193125-25-264157:note_history:27]
We account for our convertible senior notes with embedded conversion features in accordance with ASC 470-20, under which convertible debt instruments would only be separated into multiple components if they were issued at a substantial premium or if embedded derivatives requiring bifurcation were identified. The convertible senior notes (the "2030 Notes" or the “Notes”) were not issued at a substantial premium, and we analyzed the provisions of the 2030 Notes and did not identify any material embedded features which would require bifurcation from the host debt. As such, the 2030 Notes are accounted for entirely as a liability, net of unamortized issuance costs. The carrying amount of the liability is classified as long-term as the instrument does not mature within one year of the balance sheet date and the holder is not permitted to demand repayment of the principal within one year of the balance sheet date. However, if conditions to convertibility are met and holders are expected to convert within one year as described further in Note 12, we may be required to reclassify the carrying amount of the liability to current. Issuance costs are amortized to interest expense using the effective interest rate method.

- changed (2025-11-04):
[0001193125-25-264157:note_history:28]
During the nine months ended September 30, 2025, there were no other significant changes to our critical accounting policies as described in the financial statements contained in the 2024 Form 10-K/A.
  (was, 2025-08-05, similarity 0.9402):
[0000950170-25-102561:note_history:28]
During the six months ended June 30, 2025, there were no significant changes to our critical accounting policies as described in the financial statements contained in the 2024 Form 10-K/A.

- added (2025-11-04):
[0001193125-25-264157:note_history:29]
In September 2025, the Financial Accounting Standards Board (“FASB”) issued ASU 2025-06, "Intangibles-Goodwill and Other-Internal-Use Software (Subtopic 350-40): Targeted Improvements to the Accounting for Internal-Use Software," which is intended to modernize the accounting for the costs of internal-use software given the evolution of software development to the incremental and iterative development method. The amendments remove all references to prescriptive and sequential development stages and, instead, require an entity to start capitalizing software costs when management has authorized and committed to funding the software project, and it is probable that the project will be completed and the software will be used to perform the function intended. The amendments are effective for annual reporting periods beginning after December 15, 2027, and interim reporting periods within those annual reporting periods. Early adoption is permitted as of the beginning of an annual reporting period with the amendments to be applied using a prospective, modified or retrospective transition approach. The Company is currently evaluating the impact of adopting this guidance on the consolidated financial statements.

- changed (2025-11-04):
[0001193125-25-264157:note_history:30]
In November 2024, the FASB issued ASU 2024-03, "Disaggregation of Income Statement Expenses (DISE) (Topic 220): Improvements to Income Statement Disclosures", which applies to all public business entities and is intended to enhance disclosures about specific types of expenses included in the expense captions presented on the face of the income statement as well as disclosures about selling expenses. The amendments are effective prospectively for annual periods beginning after December 15, 2026, and early adoption and retrospective application are permitted. The Company is currently evaluating the effect that adoption of ASU 2024-03 will have on our disclosures.
  (was, 2025-08-05, similarity 0.9215):
[0000950170-25-102561:note_history:30]
In November 2024, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update ("ASU") 2024-03, "Disaggregation of Income Statement Expenses (DISE) (Topic 220): Improvements to Income Statement Disclosures", which applies to all public business entities (PBEs) and is intended to enhance disclosures about specific types of expenses included in the expense captions presented on the face of the income statement as well as disclosures about selling expenses. The amendments are effective prospectively for annual periods beginning after December 15, 2026, and early adoption and retrospective application are permitted. The Company is currently evaluating the effect that adoption of ASU 2024-03 will have on our disclosures.

- changed (2025-11-04):
[0001193125-25-264157:note_history:31]
In December 2023, the FASB issued ASU 2023-09, "Income Taxes (Topic 740): Improvements to Income Tax Disclosures", which is intended to enhance the transparency, decision usefulness and effectiveness of income tax disclosures. The amendments in this ASU require a public entity to disclose a tabular tax rate reconciliation, using both percentages and currency, with specific categories. A public entity is also required to provide a qualitative description of the states and local jurisdictions that make up the majority of the effect of the state and local income tax category and the net amount of income taxes paid, disaggregated by federal, state and foreign taxes and also disaggregated by individual jurisdictions. The amendments also remove certain disclosures that are no longer considered cost beneficial. The amendments are effective prospectively for annual periods beginning after December 15, 2024, and early adoption and retrospective application are permitted. The resulting new annual disclosure requirements will be reflected in our 2025 report on Form 10-K. The adoption of this guidance is not expected to have a material impact on our consolidated financial statements.
  (was, 2025-08-05, similarity 0.8682):
[0000950170-25-102561:note_history:31]
In December 2023, the FASB issued ASU 2023-09, "Income Taxes (Topic 740): Improvements to Income Tax Disclosures", which is intended to enhance the transparency, decision usefulness and effectiveness of income tax disclosures. The amendments in this ASU require a public entity to disclose a tabular tax rate reconciliation, using both percentages and currency, with specific categories. A public entity is also required to provide a qualitative description of the states and local jurisdictions that make up the majority of the effect of the state and local income tax category and the net amount of income taxes paid, disaggregated by federal, state and foreign taxes and also disaggregated by individual jurisdictions. The amendments also remove certain disclosures that are no longer considered cost beneficial. The amendments are effective prospectively for annual periods beginning after December 15, 2024, and early adoption and retrospective application are permitted. The Company is currently evaluating the effect that adoption of ASU 2023-09 will have on our disclosures.

- removed (2025-11-04):
[0000950170-25-102561:note_history:32]
Pursuant to the terms of the DPLTA, each Adtran Networks shareholder (other than the Company) has received an offer to elect either (1) to remain an Adtran Networks shareholder and receive from us an Annual Recurring Compensation payment, or (2) to receive Exit Compensation plus guaranteed interest. The guaranteed interest under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid. The guaranteed interest rate is 5.0% plus a variable component (according to the German Civil Code) that was 2.27% as of June 30, 2025. Assuming all the minority holders of currently outstanding Adtran Networks shares were to elect the second option, we would be obligated to make aggregate Exit Compensation payments, including guaranteed interest, of approximately €326.8 million or $385.2 million, based on an exchange rate as of June 30, 2025, and reflecting interest accrued through June 30, 2025 during the pendency of the appraisal proceedings discussed below. Shareholders electing the first option of Annual Recurring Compensation may later elect the second option. The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that were initiated in 2023 in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger). The court has decided a procedural matter in the DPLTA appraisal proceedings; the parties may or may not choose to appeal such decision, if able, and the proceeding for the trial on the merits of the DPLTA will continue. It is expected to take a minimum of 12 months for a ruling of the court on the merits and such ruling will most likely be appealed, which would be expected to take an additional 12-24 months to be resolved. Accordingly, the Company does not expect a final decision on the DPLTA appraisal proceedings to be rendered and published prior to 2027, and most likely not until 2028 or beyond.

- removed (2025-11-04):
[0000950170-25-102561:note_history:33]
As of June 30, 2025, and as of the date of issuance of these financial statements, the Company does not have sufficient liquidity to meet the substantial majority of its payment obligations under the DPLTA pertaining to Exit Compensation. For the three and six months ended June 30, 2025, approximately 0.9 million shares, of Adtran Networks stock were tendered to the Company. This resulted in total Exit Compensation payments of approximately €16.9 million or $19.4 million based on the applicable exchange rates at the time of the transactions being paid to Adtran Networks shareholders. For the three and six months ended June 30, 2024, approximately one thousand shares of Adtran Networks stock were tendered to the Company. This resulted in Exit Compensation payments of approximately €19 thousand and €23 thousand, respectively, or $20 thousand and $25 thousand, respectively, based on the applicable exchange rates at the time of the transactions, being paid to Adtran Networks shareholders. We believe the probability that more than a small minority of Adtran Networks shareholders elect to receive Exit Compensation in the next twelve months is remote based on the following factors: (i) the shareholders can exercise their right to receive the Exit Compensation until two months after publication of the final decision in the appraisal proceedings and we do not expect the final decision to be published within the next 12 months; (ii) the diverse base of shareholders that must make this election on an individual shareholder basis; (iii) the fact the date of a decision by the court on the merits of the case is uncertain, it will most likely take a minimum of 12 months for a ruling and, thereafter, an expected appeal process will take a further 12-24 months to resolve; (iv) the current guaranteed Annual Recurring Compensation payment; and (v) the current trading value of Adtran Networks shares.

- removed (2025-11-04):
[0000950170-25-102561:note_history:34]
The Company experienced revenue declines in the year ended December 31, 2024. However, customers have started to replenish their inventories to meet increasing demand. Revenue began to increase in the first half of 2025 and management expects orders and billings to continue to increase during the remainder of 2025. The Company continues to implement plans to preserve cash liquidity to maintain compliance with the Company’s covenants in case of further impacts related to customer inventory reduction initiatives and uncertain macroeconomic conditions. Additionally, the Company suspended dividend payments and effectuated a business efficiency program (the "Business Efficiency Program"), which targeted the reduction of ongoing operating expenses and focused on enhancing capital efficiency. The Business Efficiency Program was completed as of December 31, 2024. The Company has determined that it is probable that the sale of its headquarters in Huntsville will occur within the next twelve months after December 31, 2024. The Company may need to further reduce capital expenditures and/or take other steps to preserve working capital in order to ensure that it can meet its needs and obligations and maintain compliance with its debt covenants.

- removed (2025-11-04):
[0000950170-25-102561:note_history:35]
In summary, the Company believes that its cash and cash equivalents, investments, working capital management initiatives and availability to access cash under the Wells Fargo credit facility will be adequate to meet our business operating requirements, our capital expenditures and our expected obligations under the DPLTA, including anticipated levels of Exit Compensation and to support our ability to continue to comply with our debt covenants under the Credit Facility and continue as a going concern, for at least the next twelve months, from the issuance of these financial statements. See Note 10, Credit Agreements, for additional information regarding the terms of the Amendments of the Wells Fargo Credit agreement.


## adtn:ConvertibleSeniorNotesPolicyTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2025-11-04):
[0001193125-25-264157:note_history:36]
Convertible Senior Notes

- added (2025-11-04):
[0001193125-25-264157:note_history:37]
We account for our convertible senior notes with embedded conversion features in accordance with ASC 470-20, under which convertible debt instruments would only be separated into multiple components if they were issued at a substantial premium or if embedded derivatives requiring bifurcation were identified. The convertible senior notes (the "2030 Notes" or the “Notes”) were not issued at a substantial premium, and we analyzed the provisions of the 2030 Notes and did not identify any material embedded features which would require bifurcation from the host debt. As such, the 2030 Notes are accounted for entirely as a liability, net of unamortized issuance costs. The carrying amount of the liability is classified as long-term as the instrument does not mature within one year of the balance sheet date and the holder is not permitted to demand repayment of the principal within one year of the balance sheet date. However, if conditions to convertibility are met and holders are expected to convert within one year as described further in Note 12, we may be required to reclassify the carrying amount of the liability to current. Issuance costs are amortized to interest expense using the effective interest rate method.

- added (2025-11-04):
[0001193125-25-264157:note_history:38]
During the nine months ended September 30, 2025, there were no other significant changes to our critical accounting policies as described in the financial statements contained in the 2024 Form 10-K/A.


## us-gaap:ConvertibleDebtTableTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2025-11-04):
[0001193125-25-264157:note_history:39]
The outstanding principal and carrying value of the convertible senior notes were as follows:

- added (2025-11-04):
[0001193125-25-264157:note_history:40]
|  |  | As of |  |
| (In thousands) |  | September 30, 2025 |  |
| Convertible senior notes |  | $ | 201,250 |  |
| Less: unamortized debt issuance costs |  |  | (8,391 | ) |
| Non-current convertible senior notes |  | $ | 192,859 |  |


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2025-11-04):
[0001193125-25-264157:note_history:41]
11. CREDIT AGREEMENT
  (was, 2025-08-05, similarity 0.973):
[0000950170-25-102561:note_history:41]
10. CREDIT AGREEMENTS

- changed (2025-11-04):
[0001193125-25-264157:note_history:42]
The carrying value of the Company's non-current revolving credit facility was as follows:
  (was, 2025-08-05, similarity 0.7434):
[0000950170-25-102561:note_history:42]
The carrying amounts of the Company's non-current revolving credit facility in its Condensed Consolidated Balance Sheets were as follows:

- added (2025-11-04):
[0001193125-25-264157:note_history:43]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | September 30, 2025 |  |  | December 31, 2024 |  |
| Wells Fargo credit agreement |  | $ | 25,023 |  |  | $ | 189,576 |  |
| Total non-current revolving credit facility |  | $ | 25,023 |  |  | $ | 189,576 |  |

- added (2025-11-04):
[0001193125-25-264157:note_history:44]
Revolving Credit Agreement

- added (2025-11-04):
[0001193125-25-264157:note_history:45]
On July 18, 2022, ADTRAN, Inc., as the borrower ("U.S. Borrower"), and the Company entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (the “Original Credit Agreement”), as amended by the First Amendment to Credit Agreement, dated August 9, 2023 (“Amendment No. 1”), the Second Amendment to Credit Agreement, dated January 16, 2024 (“Amendment No. 2”), the Third Amendment to Credit Agreement, dated March 12, 2024 (“Amendment No. 3”), the Fourth Amendment to Credit Amendment, dated June 4, 2024 among Adtran Networks (the "German Borrower") and the parties set forth above ("Amendment No. 4") and the Fifth Amendment to Credit Agreement and Waiver, dated May 6, 2025, among the German Borrower and the parties set forth above (“Amendment No. 5”; the Original Credit Agreement as amended by Amendment No. 1, Amendment No. 2. Amendment No. 3, Amendment No. 4 and Amendment No. 5, the “Existing Credit Agreement”).

- added (2025-11-04):
[0001193125-25-264157:note_history:46]
On September 16, 2025, the U.S. Borrower, the German Borrower, and the lenders party thereto, including the Administrative Agent, entered into the Sixth Amendment and Consent to Credit Agreement, dated September 16, 2025 (“Amendment No. 6”; the Existing Credit Agreement as amended by Amendment No. 6, the “Amended Credit Agreement”). Amendment No. 6, among other things, (i) provides for a consent from the lenders to the issuance by the Company of new unsecured convertible indebtedness in an amount not to exceed $230.0 million, notwithstanding the cap on the amount of Permitted Convertible Indebtedness (as defined in the Amended Credit Agreement) the Company is permitted to incur, (ii) requires that the net cash proceeds of the new unsecured convertible indebtedness be used to (a) repay outstanding revolving credit loans under the Amended Credit Agreement, (b) pay fees, costs, and expenses related to Amendment No. 6 and the issuance of the new unsecured convertible indebtedness and (c) cash collateralize the obligations of the Company and its subsidiaries under the Amended Credit Agreement (with such cash only being permitted to be withdrawn for the purpose of financing the purchase of additional outstanding shares of Equity Interests (as defined in the Amended Credit Agreement) of the German Borrower that were not owned by the Company and its subsidiaries as of August 9, 2023 pursuant to Section 5, paragraph 1 of the DPLTA), and (iii) after the prepayment contemplated in the foregoing clause (ii)(a) and the provision of cash collateral contemplated in the foregoing clause (ii)(c), amends provisions governing the Subline (as defined below) to provide that future prepayments in respect of borrowings under the Subline will no longer permanently reduce the commitments in respect of the Subline. As of September 30, 2025, the Company had $7.5 million of cash collateral which is permitted to be withdrawn for the purpose of financing the purchase of additional outstanding shares of Adtran Networks stock as defined in the Amended Credit Agreement.

- added (2025-11-04):
[0001193125-25-264157:note_history:47]
As of September 30, 2025, the Amended Credit Agreement provided for a secured revolving credit facility of up to $350.0 million of borrowings, $50.0 million of which is solely available to the German Borrower.

- added (2025-11-04):
[0001193125-25-264157:note_history:48]
As of September 30, 2025, the Company’s borrowings under the revolving line of credit were $25.0 million, of which all was borrowed under the Subline by the German Borrower. The credit facilities provided under the Amended Credit Agreement mature in July 2027,

- changed (2025-11-04):
[0001193125-25-264157:note_history:49]
but the U.S. Borrower may request extensions subject to customary conditions. In addition, the U.S. Borrower may utilize up to $50.0 million of the $350.0 million total revolving facility for the issuance of letters of credit. As of September 30, 2025, the U.S. Borrower had a total of $5.8 million in letters of credit under the Amended Credit Agreement, leaving a net amount (after giving effect to the $25.0 million of outstanding borrowings described above) of $319.2 million available for future borrowings; however, as of September 30, 2025, the Company was limited to additional borrowings of $232.0 million based on debt covenant compliance metrics. Any future credit extensions under the Amended Credit Agreement are subject to customary conditions precedent. The proceeds of any loans may be used as described above, as well as for working capital and other general corporate purposes.
  (was, 2025-08-05, similarity 0.7076):
[0000950170-25-102561:note_history:49]
As of June 30, 2025, the Company’s borrowings under the revolving line of credit were $190.2 million, of which approximately $165.0 million were borrowed by the U.S. Borrower and $25.2 million were borrowed under the Subline by Adtran Networks, who became a party to the Amended Credit Agreement in June 2024. The credit facilities provided under the Amended Credit Agreement mature in July 2027, but the U.S. Borrower may request extensions subject to customary conditions. In addition, the U.S. Borrower may utilize up to $50.0 million of the $350.0 million total revolving facility for the issuance of letters of credit. As of June 30, 2025, the U.S. Borrower had a total of $3.3 million in letters of credit under the Amended Credit Agreement, leaving a net amount (after giving effect to the $190.2 million of outstanding borrowings described above) of $156.5 million available for future borrowings; however, as of June 30, 2025, the Company was limited to additional borrowings of $66.8 million based on debt covenant compliance metrics. Any future credit extensions under the Amended Credit Agreement are subject to customary conditions precedent. The proceeds of any loans are expected to be used for general corporate purposes and to pay a portion of the exchange offer consideration.

- changed (2025-11-04):
[0001193125-25-264157:note_history:50]
Moreover, the Amended Credit Agreement provides for a sublimit under the existing $350.0 million revolving commitments in an aggregate amount of $50.0 million (“Subline”), which Subline is available for borrowings by the German Borrower. The existing swing line sublimit and letter of credit sublimit under the Amended Credit Agreement remain available to the U.S. Borrower (and not to the German Borrower). Otherwise, the loans under the Subline are subject to substantially the same terms and conditions under the Amended Credit Agreement (including with respect to the interest rate and maturity date) as the other existing revolving commitments.
  (was, 2025-08-05, similarity 0.7193):
[0000950170-25-102561:note_history:50]
Moreover, the Amended Credit Agreement provides for a sublimit under the existing $350.0 million revolving commitments in an aggregate amount of $50.0 million (“Subline”), which Subline is available for borrowings by Adtran Networks. Prepayments of outstanding loans under the Subline that result in the remaining outstanding loans under the Subline being less than the German Commitment Reduction Threshold will result in a permanent partial reduction of the commitments in respect of the Subline. The German Commitment Reduction Threshold of $50.0 million may be lowered from time to time pursuant to the terms of the Amended Credit Agreement. The existing swing line sublimit and letter of credit sublimit under the Amended Credit Agreement remain available to the U.S. Borrower (and not to Adtran Networks). Otherwise, the loans under the Subline are subject to substantially the same terms and conditions under the Amended Credit Agreement (including with respect to the interest rate and maturity date) as the other existing revolving commitments.

- changed (2025-11-04):
[0001193125-25-264157:note_history:51]
All U.S. borrowings under the Amended Credit Agreement bear interest at a rate tied to the Base Rate (as defined in the Amended Credit Agreement) or SOFR, at the Company’s option, and all E.U. borrowings bear interest at a rate tied to the Euro Interbank Offered Rate as administered by the European Money Markets Institute (or a comparable or successor administrator approved by the Administrative Agent), in each case plus applicable margins which vary based on the consolidated net leverage ratio of the Company and its subsidiaries as determined pursuant to the terms of the Amended Credit Agreement. Default interest is 2.00% per annum in excess of the rate otherwise applicable. As of September 30, 2025, the weighted average interest rate on our revolving credit agreements was 9.50%.
  (was, 2025-08-05, similarity 0.9916):
[0000950170-25-102561:note_history:51]
All U.S. borrowings under the Amended Credit Agreement bear interest at a rate tied to the Base Rate (as defined in the Amended Credit Agreement) or SOFR, at the Company’s option, and all E.U. borrowings bear interest at a rate tied to the Euro Interbank Offered Rate as administered by the European Money Markets Institute (or a comparable or successor administrator approved by the Administrative Agent), in each case plus applicable margins which vary based on the consolidated net leverage ratio of the Company and its subsidiaries as determined pursuant to the terms of the Amended Credit Agreement. Default interest is 2.00% per annum in excess of the rate otherwise applicable. As of June 30, 2025, the weighted average interest rate on our revolving credit agreements was 8.55%.

- changed (2025-11-04):
[0001193125-25-264157:note_history:52]
The Company made certain representations and warranties to the lenders in the Amended Credit Agreement that are customary for credit arrangements of this type. The Company also agreed to maintain a Consolidated Total Net Leverage Ratio of 5.00x, a Consolidated Senior Secured Net Leverage Ratio of 3.25x (4.0x to 3.5x during a “Springing Covenant Period,” as defined below) and a Consolidated Fixed Charge Coverage Ratio of 1.25x (as such ratios are defined in the Amended Credit Agreement). A “Springing Covenant Event” occurs when at least sixty percent (60.0%) of the outstanding shares of Adtran Networks that were not owned by the Company and its subsidiaries as of August 9, 2023 have been tendered and purchased by the Company. Upon the occurrence of a Springing Covenant Event, the Company will enter a “Springing Covenant Period”, defined as the fiscal quarter in which a Springing Covenant Event occurs and the three (3) consecutive fiscal quarters thereafter. During a Springing Covenant Period, the Company’s leverage ratios are increased. In addition, the cash and cash equivalents of the credit parties must be at least $50.0 million and the cash and cash equivalents of the Company and its subsidiaries must be at least $70.0 million. As of September 30, 2025, the Company was in compliance with all covenants.
  (was, 2025-08-05, similarity 0.995):
[0000950170-25-102561:note_history:52]
The Company made certain representations and warranties to the lenders in the Amended Credit Agreement that are customary for credit arrangements of this type. The Company also agreed to maintain a Consolidated Total Net Leverage Ratio of 5.00x, a Consolidated Senior Secured Net Leverage Ratio of 3.25x (4.0x to 3.5x during a “Springing Covenant Period,” as defined below) and a Consolidated Fixed Charge Coverage Ratio of 1.25x (as such ratios are defined in the Amended Credit Agreement). A “Springing Covenant Event” occurs when at least sixty percent (60.0%) of the outstanding shares of Adtran Networks that were not owned by the Company and its subsidiaries as of August 9, 2023 have been tendered and purchased by the Company. Upon the occurrence of a Springing Covenant Event, the Company will enter a “Springing Covenant Period”, defined as the fiscal quarter in which a Springing Covenant Event occurs and the three (3) consecutive fiscal quarters thereafter. During a Springing Covenant Period, the Company’s leverage ratios are increased. In addition, the cash and cash equivalents of the credit parties must be at least $50.0 million and the cash and cash equivalents of the Company and its subsidiaries must be at least $70.0 million. As of June 30, 2025, the Company was in compliance with all covenants.

- changed (2025-11-04):
[0001193125-25-264157:note_history:53]
All obligations under the Amended Credit Agreement (including under the Subline) are guaranteed by the U.S. Borrower and certain subsidiaries of the U.S. Borrower (“Full Facility Guarantors”). To secure such guarantees, the U.S. Borrower and the Full Facility Guarantors have granted security interests in favor of the Administrative Agent over substantially all of their tangible and intangible assets, and the U.S. Borrower has granted mortgages in favor of the Administrative Agent over certain owned real estate assets. Certain of the German Borrower's subsidiaries (the “Subline Guarantors”) have also provided a guarantee solely of the obligations in respect of the Subline. Furthermore, to secure such guarantees, the German Borrower and the Subline Guarantors have granted security interests in favor of the Administrative Agent over substantially all of their tangible and intangible assets. Upon repayment in full and termination of the Subline, the guarantees by the Subline Guarantors and the liens granted by the German Borrower and the Subline Guarantors to secure obligations under the Subline will be released.
  (was, 2025-08-05, similarity 0.9567):
[0000950170-25-102561:note_history:53]
All obligations under the Amended Credit Agreement (including under the Subline) are guaranteed by the U.S. Borrower and certain subsidiaries of the U.S. Borrower (“Full Facility Guarantors”). To secure such guarantees, the U.S. Borrower and the Full Facility Guarantors have granted security interests in favor of the Administrative Agent over substantially all of their tangible and intangible assets, and the U.S. Borrower has granted mortgages in favor of the Administrative Agent over certain owned real estate assets. Certain of Adtran Networks' subsidiaries (the “Subline Guarantors”) have also provided a guarantee solely of the obligations in respect of the Subline. Furthermore, to secure such guarantees, Adtran Networks and the Subline Guarantors have granted security interests in favor of the Administrative Agent over substantially all of their tangible and intangible assets. Upon repayment in full and termination of the Subline, the guarantees by the Subline Guarantors and the liens granted by Adtran Networks and the Subline Guarantors to secure obligations under the Subline will be released.

- removed (2025-11-04):
[0000950170-25-102561:note_history:54]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | June 30, 2025 |  |  | December 31, 2024 |  |
| Wells Fargo credit agreement |  | $ | 190,180 |  |  | $ | 189,576 |  |
| Total non-current revolving credit facility |  | $ | 190,180 |  |  | $ | 189,576 |  |

- removed (2025-11-04):
[0000950170-25-102561:note_history:55]
On July 18, 2022, ADTRAN, Inc., as the borrower ("U.S. Borrower"), and the Company entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (the “Original Credit Agreement”), as amended by the First Amendment to the Credit Agreement, dated August 9, 2023 (“Amendment No. 1”), the Second Amendment to the Credit Agreement, dated January 16, 2024 (“Amendment No. 2”), the Third Amendment to the Credit Agreement, dated March 12, 2024 (“Amendment No. 3”), the Fourth Amendment to the Credit Amendment, dated June 4, 2024 ("Amendment No. 4"), and the Fifth Amendment to the Credit Agreement, dated May 6, 2025 (“Amendment No. 5” and, collectively with Amendment No. 1, Amendment No. 2, Amendment No. 3, and Amendment No. 4, the “Credit Agreement Amendments”; and the Original Credit Agreement, as amended by the Credit Agreement Amendments, the “Amended Credit Agreement”). Amendment No. 5, together with a substantially concurrent prepayment by Adtran Networks of outstanding revolving loans under the German Borrower Sublimit (as defined in the Amended Credit Agreement, which term includes Amendment No. 5 for the purposes of this note) in the amount of $24.0 million, among other things, resulted in (i) a permanent partial reduction in the total commitments under the Amended Credit Agreement from $374.0 million to $350.0 million, (ii) a reduction of the German Borrower Sublimit from $74.0 million to $50.0 million, and (iii) a reduction of the German Commitment Reduction Threshold (as defined in the Amended Credit Agreement) to $25.0 million. The lenders also waived certain events of default related to among others, inaccuracies in the financial statements that were previously delivered to the lenders by the Company with respect to the fiscal quarters ended June 30, 2024 and September 30, 2024, and breaches of the Consolidated Fixed Charge Coverage Ratio (as defined in the Amended Credit Agreement) financial covenant for the fiscal quarters ended June 30, 2024 and September 30, 2024. As of June 30, 2025, the Amended Credit Agreement provided for a secured revolving credit facility of up to $350.0 million of borrowings, $50.0 million of which is solely available to Adtran Networks as borrower pursuant to the Subline (as defined and further described below).


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- added (2025-11-04):
[0001193125-25-264157:note_history:56]
|  |  |  |  |  | Fair Value Measurements as of September 30, 2025 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket for IdenticalAssets (Level 1) |  |  | SignificantOtherObservableInputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds (1) |  | $ | 238 |  |  | $ | 238 |  |  | $ | — |  |  | $ | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities |  |  | 1,049 |  |  |  | 1,049 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 34,230 |  |  |  | 34,230 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 35,517 |  |  | $ | 35,517 |  |  | $ | — |  |  | $ | — |  |

- changed (2025-11-04):
[0001193125-25-264157:note_history:57]
(1)
The money market fund balances of $0.2 million and $5.5 million as of September 30, 2025 and December 31, 2024, respectively, are included in cash and cash equivalents on the balance sheet.
  (was, 2025-08-05, similarity 0.9687):
[0000950170-25-102561:note_history:57]
(1)
The money market fund balances of $0.2 million and $5.5 million as of June 30, 2025 and December 31, 2024, respectively, are included in cash and cash equivalents on the balance sheet.

- removed (2025-11-04):
[0000950170-25-102561:note_history:58]
|  |  |  |  |  | Fair Value Measurements as of June 30, 2025 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket for IdenticalAssets (Level 1) |  |  | SignificantOtherObservableInputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds (1) |  | $ | 238 |  |  | $ | 238 |  |  | $ | — |  |  | $ | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities |  |  | 1,072 |  |  |  | 1,072 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 32,044 |  |  |  | 32,044 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 33,354 |  |  | $ | 33,354 |  |  | $ | — |  |  | $ | — |  |


## us-gaap:LongTermDebtTextBlock (debt) — matched_by: no_prior_note, score: 0.0

- added (2025-11-04):
[0001193125-25-264157:note_history:59]
12. CONVERTIBLE SENIOR NOTES AND CAPPED CALLS

- added (2025-11-04):
[0001193125-25-264157:note_history:60]
The outstanding principal and carrying value of the convertible senior notes were as follows:

- added (2025-11-04):
[0001193125-25-264157:note_history:61]
|  |  | As of |  |
| (In thousands) |  | September 30, 2025 |  |
| Convertible senior notes |  | $ | 201,250 |  |
| Less: unamortized debt issuance costs |  |  | (8,391 | ) |
| Non-current convertible senior notes |  | $ | 192,859 |  |

- added (2025-11-04):
[0001193125-25-264157:note_history:62]
The estimated fair value of the 2030 Notes was $226.3 million as of September 30, 2025. The estimated fair value of the 2030 Notes, Level 2 inputs of the valuation hierarchy, were determined based on the quoted bid prices of the 2030 Notes in an over-the-counter market on the last trading day of the reporting period.

- added (2025-11-04):
[0001193125-25-264157:note_history:63]
The effective interest rate of the 2030 Notes over their expected life is 4.70%. The following is a summary of interest expense for the 2030 Notes:

- added (2025-11-04):
[0001193125-25-264157:note_history:64]
|  |  | Three and Nine Months Ended |  |
| (In thousands) |  | September 30, 2025 |  |
| Contractual interest |  | $ | 227 |  |
| Amortization of issuance costs |  |  | 45 |  |
| Total interest expense |  | $ | 272 |  |

- added (2025-11-04):
[0001193125-25-264157:note_history:65]
On September 19, 2025, the Company issued $201.3 million principal amount of its 3.75% convertible senior notes due September 15, 2030. The 2030 Notes were issued pursuant to, and are governed by, an indenture (the “Indenture”), dated as of September 19, 2025, between the Company and U.S. Bank Trust Company, National Association, as trustee (the “Trustee”). The 2030 Notes are the Company’s senior, unsecured obligations and bear interest at a rate of 3.75% per year payable semi-annually in arrears on March 15 and September 15 of each year, beginning on March 15, 2026. Each $1,000 principal amount of the 2030 Notes will be convertible into 86.8206 shares of the Company’s common stock, which is equivalent to a conversion price of approximately $11.52 per share, subject to adjustment upon the occurrence of specified events. In addition, if certain corporate events that constitute a “make-whole fundamental change” (as defined in the Indenture) occur, then the conversion rate will, in certain circumstances, be increased for a specified period of time.

- added (2025-11-04):
[0001193125-25-264157:note_history:66]
The 2030 Notes are convertible at the option of the holders of the 2030 Notes before June 15, 2030, only under the following circumstances: (1) during any calendar quarter (and only during such calendar quarter) commencing after the calendar quarter ending on December 31, 2025, if the last reported sale price per share of the Company’s common stock exceeds 130% of the conversion price for each of at least 20 trading days, whether or not consecutive, during the 30 consecutive trading days ending on, and including, the last trading day of the immediately preceding calendar quarter; (2) during the five consecutive business days immediately after any 10 consecutive trading day period (such 10 consecutive trading day period, the “measurement period”) if the trading price per $1,000 principal amount of the 2030 Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price per share of our common stock on such trading day and the conversion rate on such trading day; (3) upon the occurrence of certain corporate events or distributions on the Company’s common stock; or (4) if the Company calls (or is deemed to have called) the 2030 Notes for redemption. From and after June 15, 2030, noteholders may convert their 2030 Notes at any time at their election until the close of business on the second scheduled trading day immediately before the maturity date. The Company will settle conversions by paying cash up to the aggregate principal amount of the 2030 Notes to be converted and paying or delivering, as applicable, cash, shares of its common stock or a combination of cash and shares of its common stock, at the Company’s election, in respect of the remainder, if any, of its conversion obligation in excess of the aggregate principal amount of the Notes being converted, based on the applicable conversion rate.

- added (2025-11-04):
[0001193125-25-264157:note_history:67]
The 2030 Notes will be redeemable, in whole or in part (subject to certain limitations described below), at the Company’s option at any time, and from time to time, on or after September 20, 2028 and on or before the 46th scheduled trading day immediately before the maturity date, but only if (i) the Notes are “Freely Tradable” (as defined in the Indenture) as of the date the Company sends the related redemption notice, and all accrued and unpaid additional interest, if any, has been paid in full as of the most recent interest payment date occurring on or before the date the Company sends the related redemption notice; and (ii) the last reported sale price per share of the Company’s common stock exceeds 130% of the conversion price on (1) each of at least 20 trading days, whether or not consecutive, during the 30 consecutive trading days ending on, and including, the trading day immediately before the date the Company sends the related redemption notice; and (2) the trading day immediately before the date the Company sends such redemption notice. However, the Company may not redeem less than all of the outstanding Notes unless at least $70.0 million aggregate principal amount of Notes are outstanding and not called for redemption as of the time the Company sends, and after giving effect to, the related redemption notice. The redemption price will be a cash amount equal to the principal amount of the Notes to be redeemed, plus accrued and unpaid interest, if any, to, but excluding, the redemption date. In addition, calling (or the deemed calling of) any Note for redemption will constitute a “make-whole fundamental change” with respect to that Note, in which case the conversion rate applicable to the conversion of that Note will be increased in certain circumstances if it is converted during the related redemption conversion period. No sinking fund is provided for the 2030 Notes, which means the Company is not required to redeem or retire the 2030 Notes periodically.

- added (2025-11-04):
[0001193125-25-264157:note_history:68]
If certain corporate events that constitute a “fundamental change” (as defined in the Indenture) occur, then, subject to a limited exception for certain cash mergers, noteholders may require the Company to repurchase their Notes at a cash repurchase price equal to the principal amount of the Notes to be repurchased, plus accrued and unpaid interest, if any, to, but excluding, the fundamental change repurchase date. The definition of “fundamental change” includes certain business combination transactions involving the Company and certain de-listing events with respect to the Company’s common stock.

- added (2025-11-04):
[0001193125-25-264157:note_history:69]
Capped Calls

- added (2025-11-04):
[0001193125-25-264157:note_history:70]
In connection with the pricing of the 2030 Notes and the exercise of the initial purchasers’ option to purchase additional 2030 Notes, the Company entered into privately negotiated capped call transactions with one of the initial purchasers of the 2030 Notes or its affiliate and certain other financial institutions pursuant to capped call confirmations (collectively, the “Capped Calls”). The premiums paid for the purchases of the Capped Calls were approximately $17.6 million. The Capped Calls have an initial strike price of approximately $11.52 per share, subject to certain adjustments substantially similar to those applicable to the corresponding 2030 Notes. The Capped

- added (2025-11-04):
[0001193125-25-264157:note_history:71]
Calls have an initial cap price of approximately $15.51 per share, subject to certain adjustments. The Capped Calls cover, subject to anti-dilution adjustments, approximately 17.5 million shares of the Company’s common stock.

- added (2025-11-04):
[0001193125-25-264157:note_history:72]
The Capped Calls are generally expected to reduce potential dilution to the Company’s common stock and/or offset any cash payments that the Company is required to make in excess of the principal amount of any converted 2030 Notes, with such reduction and/or offset subject to a cap, based on the cap price of the Capped Calls.

- added (2025-11-04):
[0001193125-25-264157:note_history:73]
The Capped Calls are separate transactions and are not part of the terms of the 2030 Notes. The Capped Calls do not meet the criteria for separate accounting as a derivative as they are indexed to the Company's stock and meet the requirements to be classified in equity and, as such, are not remeasured each reporting period. The premiums paid for the Capped Calls were included as a net reduction to additional paid-in capital within stockholders’ equity during the quarter ended September 30, 2025.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-11-04):
[0001193125-25-264157:note_history:74]
|  |  | Three Months Ended |  |
|  |  | September 30, 2025 |  |  | September 30, 2024 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Subscriber Solutions |  | $ | 92,770 |  |  | $ | 8,368 |  |  | $ | 101,138 |  |  | $ | 81,060 |  |  | $ | 9,036 |  |  | $ | 90,096 |  |
| Access & Aggregation Solutions |  |  | 61,051 |  |  |  | 13,757 |  |  |  | 74,808 |  |  |  | 52,954 |  |  |  | 14,119 |  |  |  | 67,073 |  |
| Optical Networking Solutions |  |  | 78,722 |  |  |  | 24,767 |  |  |  | 103,489 |  |  |  | 47,474 |  |  |  | 23,061 |  |  |  | 70,535 |  |
| Total |  | $ | 232,543 |  |  | $ | 46,892 |  |  | $ | 279,435 |  |  | $ | 181,488 |  |  | $ | 46,216 |  |  | $ | 227,704 |  |
  (was, 2025-08-05, similarity 0.9583):
[0000950170-25-102561:note_history:74]
|  |  | Three Months Ended |  |
|  |  | June 30, 2025 |  |  | June 30, 2024 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Subscriber Solutions |  | $ | 75,537 |  |  | $ | 8,221 |  |  | $ | 83,758 |  |  | $ | 73,615 |  |  | $ | 8,782 |  |  | $ | 82,397 |  |
| Access & Aggregation Solutions |  |  | 77,353 |  |  |  | 13,859 |  |  |  | 91,212 |  |  |  | 54,112 |  |  |  | 15,795 |  |  |  | 69,907 |  |
| Optical Networking Solutions |  |  | 66,608 |  |  |  | 23,490 |  |  |  | 90,098 |  |  |  | 51,467 |  |  |  | 22,220 |  |  |  | 73,687 |  |
| Total |  | $ | 219,498 |  |  | $ | 45,570 |  |  | $ | 265,068 |  |  | $ | 179,194 |  |  | $ | 46,797 |  |  | $ | 225,991 |  |

- changed (2025-11-04):
[0001193125-25-264157:note_history:75]
|  |  | Nine Months Ended |  |
|  |  | September 30, 2025 |  |  | September 30, 2024 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Subscriber Solutions |  | $ | 240,055 |  |  | $ | 25,252 |  |  | $ | 265,307 |  |  | $ | 215,044 |  |  | $ | 27,218 |  |  | $ | 242,262 |  |
| Access & Aggregation Solutions |  |  | 214,251 |  |  |  | 40,905 |  |  |  | 255,156 |  |  |  | 174,843 |  |  |  | 43,449 |  |  |  | 218,292 |  |
| Optical Networking Solutions |  |  | 199,952 |  |  |  | 71,832 |  |  |  | 271,784 |  |  |  | 152,068 |  |  |  | 67,246 |  |  |  | 219,314 |  |
| Total |  | $ | 654,258 |  |  | $ | 137,989 |  |  | $ | 792,247 |  |  | $ | 541,955 |  |  | $ | 137,913 |  |  | $ | 679,868 |  |
  (was, 2025-08-05, similarity 0.6892):
[0000950170-25-102561:note_history:75]
|  |  | Six Months Ended |  |
|  |  | June 30, 2025 |  |  | June 30, 2024 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Subscriber Solutions |  | $ | 147,285 |  |  | $ | 16,884 |  |  | $ | 164,169 |  |  | $ | 133,984 |  |  | $ | 18,181 |  |  | $ | 152,165 |  |
| Access & Aggregation Solutions |  |  | 153,200 |  |  |  | 27,148 |  |  | $ | 180,348 |  |  |  | 121,889 |  |  |  | 29,330 |  |  | $ | 151,219 |  |
| Optical Networking Solutions |  |  | 121,230 |  |  |  | 47,065 |  |  | $ | 168,295 |  |  |  | 104,594 |  |  |  | 44,186 |  |  | $ | 148,780 |  |
| Total |  | $ | 421,715 |  |  | $ | 91,097 |  |  | $ | 512,812 |  |  | $ | 360,467 |  |  | $ | 91,697 |  |  | $ | 452,164 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2025-11-04):
[0001193125-25-264157:note_history:76]
|  |  | Three Months Ended |  |
|  |  | September 30, 2025 |  |  | September 30, 2024 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Subscriber Solutions |  | $ | 92,770 |  |  | $ | 8,368 |  |  | $ | 101,138 |  |  | $ | 81,060 |  |  | $ | 9,036 |  |  | $ | 90,096 |  |
| Access & Aggregation Solutions |  |  | 61,051 |  |  |  | 13,757 |  |  |  | 74,808 |  |  |  | 52,954 |  |  |  | 14,119 |  |  |  | 67,073 |  |
| Optical Networking Solutions |  |  | 78,722 |  |  |  | 24,767 |  |  |  | 103,489 |  |  |  | 47,474 |  |  |  | 23,061 |  |  |  | 70,535 |  |
| Total |  | $ | 232,543 |  |  | $ | 46,892 |  |  | $ | 279,435 |  |  | $ | 181,488 |  |  | $ | 46,216 |  |  | $ | 227,704 |  |
  (was, 2025-08-05, similarity 0.9583):
[0000950170-25-102561:note_history:76]
|  |  | Three Months Ended |  |
|  |  | June 30, 2025 |  |  | June 30, 2024 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Subscriber Solutions |  | $ | 75,537 |  |  | $ | 8,221 |  |  | $ | 83,758 |  |  | $ | 73,615 |  |  | $ | 8,782 |  |  | $ | 82,397 |  |
| Access & Aggregation Solutions |  |  | 77,353 |  |  |  | 13,859 |  |  |  | 91,212 |  |  |  | 54,112 |  |  |  | 15,795 |  |  |  | 69,907 |  |
| Optical Networking Solutions |  |  | 66,608 |  |  |  | 23,490 |  |  |  | 90,098 |  |  |  | 51,467 |  |  |  | 22,220 |  |  |  | 73,687 |  |
| Total |  | $ | 219,498 |  |  | $ | 45,570 |  |  | $ | 265,068 |  |  | $ | 179,194 |  |  | $ | 46,797 |  |  | $ | 225,991 |  |

- changed (2025-11-04):
[0001193125-25-264157:note_history:77]
|  |  | Nine Months Ended |  |
|  |  | September 30, 2025 |  |  | September 30, 2024 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Subscriber Solutions |  | $ | 240,055 |  |  | $ | 25,252 |  |  | $ | 265,307 |  |  | $ | 215,044 |  |  | $ | 27,218 |  |  | $ | 242,262 |  |
| Access & Aggregation Solutions |  |  | 214,251 |  |  |  | 40,905 |  |  |  | 255,156 |  |  |  | 174,843 |  |  |  | 43,449 |  |  |  | 218,292 |  |
| Optical Networking Solutions |  |  | 199,952 |  |  |  | 71,832 |  |  |  | 271,784 |  |  |  | 152,068 |  |  |  | 67,246 |  |  |  | 219,314 |  |
| Total |  | $ | 654,258 |  |  | $ | 137,989 |  |  | $ | 792,247 |  |  | $ | 541,955 |  |  | $ | 137,913 |  |  | $ | 679,868 |  |
  (was, 2025-08-05, similarity 0.6892):
[0000950170-25-102561:note_history:77]
|  |  | Six Months Ended |  |
|  |  | June 30, 2025 |  |  | June 30, 2024 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Subscriber Solutions |  | $ | 147,285 |  |  | $ | 16,884 |  |  | $ | 164,169 |  |  | $ | 133,984 |  |  | $ | 18,181 |  |  | $ | 152,165 |  |
| Access & Aggregation Solutions |  |  | 153,200 |  |  |  | 27,148 |  |  | $ | 180,348 |  |  |  | 121,889 |  |  |  | 29,330 |  |  | $ | 151,219 |  |
| Optical Networking Solutions |  |  | 121,230 |  |  |  | 47,065 |  |  | $ | 168,295 |  |  |  | 104,594 |  |  |  | 44,186 |  |  | $ | 148,780 |  |
| Total |  | $ | 421,715 |  |  | $ | 91,097 |  |  | $ | 512,812 |  |  | $ | 360,467 |  |  | $ | 91,697 |  |  | $ | 452,164 |  |

- added (2025-11-04):
[0001193125-25-264157:note_history:78]
The aggregate amount of transaction price allocated to remaining performance obligations (“RPO”) that have not been satisfied as of September 30, 2025 related to non-cancellable contractual maintenance agreements, non-cancellable contractual SaaS and subscription services, and non-cancellable hardware contracts amounted to $174.0 million. The Company identified an immaterial error in its 2024 RPO disclosure of $325.7 million where it incorrectly included cancellable contracts and inappropriately applied the practical expedient under ASC 606. The Company has corrected the disclosure to remove the cancellable portion of RPO amounts and to reflect the impact of discontinuing the use of the practical expedient to exclude contracts with an original expected duration of one year or less. The corrected amount of the RPO is $185.4 million as of December 31, 2024. The Company will generally satisfy the remaining performance obligations as we transfer control of the products ordered or services to our customers, excluding maintenance services, which are satisfied over time.

- changed (2025-11-04):
[0001193125-25-264157:note_history:79]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | September 30, 2025 |  |  | December 31, 2024 |  |
| Accounts receivable, net |  | $ | 178,621 |  |  | $ | 178,030 |  |
| Contract assets(1) |  | $ | 360 |  |  | $ | 631 |  |
| Unearned revenue |  | $ | 57,563 |  |  | $ | 52,701 |  |
| Non-current unearned revenue |  | $ | 23,196 |  |  | $ | 22,065 |  |
  (was, 2025-08-05, similarity 0.9279):
[0000950170-25-102561:note_history:79]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | June 30, 2025 |  |  | December 31, 2024 |  |
| Accounts receivable, net |  | $ | 164,768 |  |  | $ | 178,030 |  |
| Contract assets(1) |  | $ | 510 |  |  | $ | 631 |  |
| Unearned revenue |  | $ | 62,695 |  |  | $ | 52,701 |  |
| Non-current unearned revenue |  | $ | 24,429 |  |  | $ | 22,065 |  |

- changed (2025-11-04):
[0001193125-25-264157:note_history:80]
(1)	Included in other receivables.
  (was, 2025-08-05, similarity 0.6018):
[0000950170-25-102561:note_history:80]
(1)	Included in other receivables on the Condensed Consolidated Balance Sheets.

- changed (2025-11-04):
[0001193125-25-264157:note_history:81]
The allowance for credit losses was $1.2 million and $1.3 million as of September 30, 2025 and December 31, 2024, respectively.
  (was, 2025-08-05, similarity 0.7658):
[0000950170-25-102561:note_history:81]
The allowance for credit losses was $1.3 million as of June 30, 2025, and December 31, 2024, related to accounts receivable.

- changed (2025-11-04):
[0001193125-25-264157:note_history:82]
On July 1, 2024, the Company entered into a receivables purchase agreement (the “Factoring Agreement”) with a third-party financial institution, which accelerates receivable collection and helps to better manage cash flow. Total accounts receivables factored as of the end of September 30, 2025, totaled $23.6 million net of $3.7 million retained pursuant to the Factoring Agreement in the reserve account. Total accounts receivables factored as of the end of September 30, 2024, totaled $16.7 million net of  $3.7 million retained pursuant to the Factoring Agreement in the reserve account. The Factoring Agreement provides for up to $40.0 million in factoring capacity, subject to eligible receivables and reserve requirements, secured by the receivables. The balance in the reserve account is included in other assets. The Company at its own expense does have collection and administrative responsibilities for the sold receivables and that is its only continuing involvement with the factoring party. The Company is not compensated for the servicing of the factoring program and deems the costs of servicing the receivables sold to be immaterial.
  (was, 2025-08-05, similarity 0.6158):
[0000950170-25-102561:note_history:82]
On July 1, 2024, the Company entered into a receivables purchase agreement (the “Factoring Agreement”) with a third-party financial institution (the “Factor”), which accelerates receivable collection and helps to better manage cash flow. Total accounts receivables factored as of the end of June 30, 2025, totaled $18.4 million of which $3.7 million was retained pursuant to the Factoring Agreement in the reserve account. The Factoring Agreement provides for up to $40.0 million in factoring capacity, subject to eligible receivables and reserve requirements, secured by the receivables. The balance in the reserve account is included in other assets on the Condensed Consolidated Balance Sheets. The cost of the Factoring Agreement is included in interest expense in the Condensed Consolidated Statements of Loss and totaled $0.3 million and $0.6 million for the three months and six months ended June 30, 2025, respectively.

- added (2025-11-04):
[0001193125-25-264157:note_history:83]
During the three and nine months ended September 30, 2025, the Company received $49.2 million and $119.4 million, in cash proceeds from the Factoring Agreement, respectively, and during the three and nine months ended September 30, 2024, the Company received $39.9 million, in cash proceeds from the Factoring Agreement, which are recorded as a component of accounts receivable in operating cash flows on the Condensed Consolidated Statement of Cash Flows. The cost of the Factoring Agreement is included in interest expense in the Condensed Consolidated Statements of Loss and totaled $0.5 million and $0.3 million for the three months ended September, 30, 2025 and 2024, respectively, and $1.0 million and $0.3 million for the nine months ended September 30, 2025 and 2024, respectively.

- changed (2025-11-04):
[0001193125-25-264157:note_history:84]
On December 19, 2023, the Company entered into a receivables purchase agreement (the "Prior Factoring Agreement") with a third-party financial institution which qualified for treatment as a secured borrowing with a pledge of collateral under Accounting Standards Codification ("ASC") Topic 810, Consolidation. The Prior Factoring Agreement was terminated on July 1, 2024. For the nine months ended September 30, 2024, the Company incurred program fee expenses of $0.6 million.
  (was, 2025-08-05, similarity 0.9075):
[0000950170-25-102561:note_history:84]
On December 19, 2023, the Company entered into a receivables purchase agreement (the "Prior Factoring Agreement") with a third-party financial institution which qualified for treatment as a secured borrowing with a pledge of collateral under Accounting Standards Codification ("ASC") Topic 810, Consolidation. The Prior Factoring Agreement was terminated on July 1, 2024. For the three and six months ended June 30, 2024, the Company incurred program fee expenses of $0.3 million and $0.6 million, respectively.

- changed (2025-11-04):
[0001193125-25-264157:note_history:85]
No allowance for credit losses was recorded for the three and nine months ended September 30, 2025 and 2024, respectively, related to contract assets.
  (was, 2025-08-05, similarity 0.942):
[0000950170-25-102561:note_history:85]
No allowance for credit losses was recorded for the three and six months ended June 30, 2025 and 2024, respectively, related to contract assets.

- changed (2025-11-04):
[0001193125-25-264157:note_history:86]
Of the outstanding unearned revenue balances as of December 31, 2024, $9.3 million and $44.1 million were recognized as revenue during the three and nine months ended September 30, 2025, respectively. Of the $65.1 million of outstanding unearned revenue balances as of December 31, 2023, $10.03 million and $43.1 million were recognized as revenue during the three and nine months ended September 30, 2024, respectively.
  (was, 2025-08-05, similarity 0.872):
[0000950170-25-102561:note_history:86]
Of the outstanding unearned revenue balances as of December 31, 2024, $12.8 million and $34.7 million were recognized as revenue during the three and six months ended June 30, 2025, respectively. Of the $65.1 million of outstanding unearned revenue balances as of December 31, 2023, $13.7 million and $33.1 million were recognized as revenue during the three and six months ended June 30, 2024, respectively.

- removed (2025-11-04):
[0000950170-25-102561:note_history:87]
The aggregate amount of transaction price allocated to remaining performance obligations that have not been satisfied as of June 30, 2025 and December 31, 2024 related to contractual maintenance agreements, contractual SaaS and subscription services, and hardware contracts that exceed one year in duration amounted to $264.9 million and $325.7 million, respectively. As of June 30, 2025, approximately 62.8% is expected to be recognized over the next 12 months and the remainder recognized thereafter. The majority of the Company's remaining performance obligations as of June 30, 2025, are related to contracts or orders that have an original expected duration of one year or less and are excluded from the transaction price related to these future obligations. The Company will generally satisfy the remaining performance obligations as we transfer control of the products ordered or services to our customers, excluding maintenance services, which are satisfied over time.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2025-11-04):
[0001193125-25-264157:note_history:88]
Termination of Deferred Compensation Plans

- added (2025-11-04):
[0001193125-25-264157:note_history:89]
On November 3, 2025, in an effort to streamline the benefits offered to members of management and other key employees, the Company terminated its Deferred Compensation Program for Employees (the "Deferred Compensation Plan") and its Equity Deferral Program for Employees (together with the Deferred Compensation Plan, the "Plans"). The Plans are deferred compensation plans that have provided certain members of management or highly compensated employees, including certain of our named executive officers, with an opportunity to defer the receipt of a portion of their cash compensation, bonus, or other specified compensation. Each of the Plans has been maintained as an unfunded, nonqualified plan providing benefits based on the participant’s notional account balance at the time of retirement or separation, death or (with respect to the Deferred Compensation Plan) a change in control. The Company has also terminated its deferred compensation plans for its non-employee directors. See Part II, Item 5(a) of this report for additional information regarding the terminated deferred compensation plans.

- removed (2025-11-04):
[0000950170-25-102561:note_history:90]
Annual Recurring Compensation Payment in accordance with the DPLTA

- removed (2025-11-04):
[0000950170-25-102561:note_history:91]
On July 1, 2025, the Company paid $10.1 million with respect to the 2024 fiscal year Annual Recurring Compensation. See Note 13 for additional information on the Annual Recurring Compensation payment.

- removed (2025-11-04):
[0000950170-25-102561:note_history:92]
Enactment of the “One Big Beautiful Bill Act”

- removed (2025-11-04):
[0000950170-25-102561:note_history:93]
On July 4, 2025, the “One Big Beautiful Bill Act” (OBBBA) was signed into law, which constitutes the enactment date of the tax reconciliation bill under U.S. GAAP. Key corporate tax provisions include the restoration of 100% bonus depreciation, expensing of domestic research and experimental expenditures under Section 174A, modifications to Section 163(j) interest expense limitations, updates to the rules governing global intangible low-taxed income and foreign-derived intangible income, amendments to energy credits, and expanded Section 162(m) aggregation requirements. In accordance with ASC 740, the effects of the new tax law will be recognized in the period of enactment. The Company is currently evaluating the impact of the OBBBA, and an estimate of the financial effect is not yet available.
