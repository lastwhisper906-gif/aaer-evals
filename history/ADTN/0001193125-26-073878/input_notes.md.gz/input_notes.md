# ADTN notes — 0001193125-26-073878


## dei:DocumentsIncorporatedByReferenceTextBlock

[0001193125-26-073878:notes:1]
DOCUMENTS INCORPORATED BY REFERENCE

[0001193125-26-073878:notes:2]
Portions of the definitive Proxy Statement for the registrant's 2026 Annual Meeting of Stockholders to be filed within 120 days of the registrant's fiscal year-end are incorporated herein by reference into Part III of this report to the extent described in Part III.


## cyd:CybersecurityRiskManagementProcessesForAssessingIdentifyingAndManagingThreatsTextBlock

[0001193125-26-073878:notes:3]
Risk Management and Strategy

[0001193125-26-073878:notes:4]
We recognize the importance of establishing governance and oversight over cybersecurity risks, and we have implemented mechanisms, controls, technologies, and processes designed to help us assess, identify, and manage these risks.

[0001193125-26-073878:notes:5]
The landscape of cyber threats is constantly evolving, making it increasingly challenging to effectively defend against them or implement sufficient preventative measures. We have observed a rise in the volume, frequency, and sophistication of cyber-attacks. There can be no assurance that our controls and procedures in place to monitor and mitigate the risks of cyber threats, including the remediation of critical information security and software vulnerabilities, will be sufficient and/or timely and that we will not suffer material losses or consequences in the future. Additionally, while we have in place insurance coverage designed to address certain aspects of cyber risks, such insurance coverage may be insufficient to cover all insured losses or all types of claims that may arise. For more information regarding the cybersecurity risks that we face, see “Risks Related to Our Control Environment – Breaches of our information systems and cyberattacks could compromise our intellectual property and cause significant damage to our business and reputation” included as part of our risk factor disclosures in Part I, Item 1A of this report.

[0001193125-26-073878:notes:6]
We have adopted and continue to maintain a cybersecurity risk management program that implements various controls, technology, and procedures for the evaluation, identification, and handling of significant cybersecurity risks that could impact the confidentiality, integrity, or availability of our information systems.

[0001193125-26-073878:notes:7]
Our practices include providing ongoing security awareness training for our global workforce, conducting ransomware and phishing simulations, deploying advanced tools for detecting and analyzing anomalous network activities, and implementing robust containment and incident response procedures. We leverage threat intelligence from our security vendors, as well as from trusted sources such as CISA and the FBI, to enhance our defenses and stay ahead of emerging threats. Additionally, we are committed to staying aligned with the latest industry standards and actively participating in industry forums to exchange insights and proactively address evolving cybersecurity challenges.

[0001193125-26-073878:notes:8]
A critical component of our cybersecurity strategy is the integration of a third-party Security Operations Center support, which monitors our global network environment on a 24/7/365 basis, and is designed to rapidly identify and respond to threats. This program monitors both internally detected and externally reported vulnerabilities that could impact our products, which are then evaluated for their cybersecurity implications according to Company protocols. We also utilize third-party service providers as part of our cybersecurity risk management program and maintain a framework for managing cybersecurity risks presented by our third-party Service Providers. This framework governs the third party’s security management system and mandates that the program (i) adhere to certain information handling and asset management protocols and (ii) promptly notify us of any cybersecurity incidents that impact its systems.

[0001193125-26-073878:notes:9]
Our enterprise risk management ("ERM") framework is designed to systematically integrate the assessment, identification, and handling of cybersecurity-related risks into our broader risk management strategy. This process involves an annual evaluation of the spectrum of risks facing the enterprise, including those related to cybersecurity. When elevated cybersecurity risks are detected, designated risk owners are tasked with formulating and overseeing the execution of targeted mitigation strategies.

[0001193125-26-073878:notes:10]
We did not experience any material losses relating to cybersecurity threats or incidents for the year ended December 31, 2025. We are not aware of any risks from cybersecurity threats, including as a result of any previous cybersecurity incidents, that have materially affected us or are reasonably likely to materially affect us, including our business strategy, results of operations, or financial condition.

[0001193125-26-073878:notes:11]
Governance

[0001193125-26-073878:notes:12]
Adtran maintains a cybersecurity governance structure led by its Information Security Management "ISM" team, which oversees the Company's cybersecurity risk management efforts. The ISM team ensures that appropriate controls are in place to protect Adtran’s corporate assets, ensuring their availability, confidentiality, and integrity. This risk management approach informs strategic decision-making, resource allocation, and oversight mechanisms. The governance of Adtran’s cybersecurity program is ultimately the responsibility of the Board of Directors, with the Audit Committee providing critical oversight through regular reviews and periodic updates at least quarterly, or more frequently as needed.

[0001193125-26-073878:notes:13]
The Company’s cybersecurity leadership includes the Chief Information Officer "CIO", who is responsible for governing and protecting Adtran’s information assets, leading the cybersecurity strategy, and reporting directly to the Chief Executive Officer. The CIO is an accomplished engineering and security professional with extensive leadership experience in research and development and product security and holds a Ph.D. in electrical engineering. Additionally, the Chief Technology Officer ("CTO"), who joined the company in January 2023 following the Business Combination, plays a key role in product security oversight, drawing on prior experience as Adtran Networks' CTO leading their product management and advanced technology teams. Our CTO helps oversee our product security programs.

[0001193125-26-073878:notes:14]
Adtran employs a comprehensive cybersecurity program that integrates proactive risk management strategies to identify, assess, and mitigate cybersecurity threats. Key elements of this program include an Incident Response Plan to manage and resolve security incidents, regular vulnerability scanning to identify and address potential risks, and a structured patch management process to ensure timely remediation of security vulnerabilities. Additionally, the Company has established a dedicated Product Security Incident Response Team (PSIRT) to assess and respond to product security vulnerabilities. To strengthen its security culture, Adtran implements a Cybersecurity Testing and Awareness Program, requiring all employees to participate in quarterly cybersecurity assessments and complete mandatory annual training. This initiative ensures that employees remain well-informed about emerging cybersecurity threats and best practices, reinforcing a proactive security mindset across the organization.

[0001193125-26-073878:notes:15]
Cybersecurity risk management is integrated into Adtran’s Enterprise Risk Management "ERM" program, in order to provide for continuous oversight and executive engagement. The ERM program undergoes quarterly executive reviews and annual assessments by the Board of Directors, and the Board receives regular briefings on cybersecurity risks, regulatory compliance, and security program updates from management. Key policies include the Information Security Program, which establishes governance principles across facilities, employees, business partners, and customers; the Cybersecurity Framework, which ensures compliance with ISO 27001 and industry standards; employee handbooks outlining security best practices; and the Incident Response Plan, which includes a material impact assessment workflow to support timely regulatory disclosures.

[0001193125-26-073878:notes:16]
For additional discussion of risks associated with cybersecurity, see “Risk Factors – Breaches of our information systems and cyberattacks could compromise our intellectual property and cause significant damage to our business and reputation.


## dei:AuditorOpinionTextBlock

[0001193125-26-073878:notes:17]
We have audited the accompanying consolidated balance sheets of ADTRAN Holdings, Inc. and its subsidiaries (the "Company") as of December 31, 2025 and 2024, and the related consolidated statements of loss, of comprehensive income (loss), of changes in equity and of cash flows for each of the three years in the period ended December 31, 2025, including the related notes and financial statement schedule listed in the accompanying index (collectively referred to as the "consolidated financial statements"). We also have audited the Company's internal control over financial reporting as of December 31, 2025, based on criteria established in Internal Control - Integrated Framework (2013) issued by the Committee of Sponsoring Organizations of the Treadway Commission (COSO).

[0001193125-26-073878:notes:18]
In our opinion, the consolidated financial statements referred to above present fairly, in all material respects, the financial position of the Company as of December 31, 2025 and 2024, and the results of its operations and its cash flows for each of the three years in the period ended December 31, 2025 in conformity with accounting principles generally accepted in the United States of America. Also in our opinion, the Company did not maintain, in all material respects, effective internal control over financial reporting as of December 31, 2025, based on criteria established in Internal Control - Integrated Framework (2013) issued by the COSO because material weaknesses in internal control over financial reporting existed as of that date as the Company did not design and maintain effective controls (i) in response to the risks of material misstatement and (ii) over financial statement preparation, presentation and disclosure commensurate with its financial reporting requirements.

[0001193125-26-073878:notes:19]
A material weakness is a deficiency, or a combination of deficiencies, in internal control over financial reporting, such that there is a reasonable possibility that a material misstatement of the annual or interim financial statements will not be prevented or detected on a timely basis. The material weaknesses referred to above are described in Management’s Report on Internal Control over Financial Reporting appearing under Item 9A. We considered these material weaknesses in determining the nature, timing, and extent of audit tests applied in our audit of the 2025 consolidated financial statements, and our opinion regarding the effectiveness of the Company’s internal control over financial reporting does not affect our opinion on those consolidated financial statements.


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001193125-26-073878:notes:20]
GENERAL

[0001193125-26-073878:notes:21]
ADTRAN Holdings, Inc. (“Adtran” or the “Company”) is a leading global provider of networking and communications platforms, software, systems and services focused on the broadband access market, serving a diverse domestic and international customer base in multiple countries that includes large, medium and small Service Providers, alternative Service Providers, such as utilities, municipalities and fiber overbuilders, cable/MSOs, SMBs and distributed enterprises, including Fortune 500 companies with sophisticated business continuity applications; and federal, state and local government agencies. Our innovative solutions and services enable voice, data, video and internet-communications across a variety of network infrastructures and are currently in use by millions worldwide. We support our customers through our direct global sales organization and our distribution networks. Our success depends upon our ability to increase unit volume and market share through the introduction of new products and succeeding generations of products having optimal selling prices and increased functionality as compared to both the prior generation of a product and to the products of competitors in order to gain market share. To service our customers and grow revenue, we are continually conducting research and developing new products addressing customer needs and testing those products for the specific requirements of the particular customers. We offer a broad portfolio of flexible software and hardware network solutions and services that enable Service Providers to meet today’s service demands, while enabling them to transition to the fully converged, scalable, highly-automated, cloud-controlled voice, data, internet and video network of the future. In addition to our global headquarters in Huntsville, Alabama, and our European headquarters in Munich, Germany, we have sales and research and development facilities in strategic global locations.

[0001193125-26-073878:notes:22]
The Company solely owns ADTRAN, Inc. and is the majority shareholder of Adtran Networks SE (“Adtran Networks”). ADTRAN, Inc. is a leading global provider of open, disaggregated networking and communications solutions. Adtran Networks is a global provider of network solutions for data, storage, voice and video services. We believe that the combined technology portfolio can best address current and future customer needs for high-speed connectivity from the network core to the end consumer, especially upon the convergence of solutions at the network edge.

[0001193125-26-073878:notes:23]
Domination and Profit and Loss Transfer Agreement, Liquidity, Credit Facility and Notes Offering

[0001193125-26-073878:notes:24]
The DPLTA between the Company, as the controlling company, and Adtran Networks, as the controlled company, which was executed on December 1, 2022, became effective on January 16, 2023, as a result of its registration with the commercial register (Handelsregister) of the local court (Amtsgericht) at the registered seat of Adtran Networks (Jena).

[0001193125-26-073878:notes:25]
Under the DPLTA, subject to certain limitations pursuant to applicable law and the specific terms of the DPLTA, (i) the Company is entitled to issue binding instructions to the management board of Adtran Networks, (ii) Adtran Networks will transfer its annual profit to the Company, subject to, among other things, the creation or dissolution of certain reserves, and (iii) the Company will absorb the annual net loss incurred by Adtran Networks. The Company’s payment obligation in satisfaction of the requirement that it absorb Adtran Networks’ annual net loss applies to the net loss generated by Adtran Networks in 2025, and it will apply to any net loss generated by Adtran Networks in 2026.

[0001193125-26-073878:notes:26]
Pursuant to the terms of the DPLTA, each Adtran Networks shareholder (other than the Company) has received an offer to elect either (1) to remain an Adtran Networks shareholder and receive from us recurring compensation in cash of €0.52 per share for each full fiscal year of Adtran Networks (the "Annual Recurring Compensation"), or (2) to put their Adtran Networks shares to the Company in exchange for compensation in cash of €17.21 per share, plus guaranteed interest (the "Exit Compensation"). The guaranteed interest under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid. The guaranteed interest rate is 5.0% plus a variable component (according to the German Civil Code) that was 1.27% as of December 31, 2025. Assuming all the minority holders of currently outstanding Adtran Networks shares were to elect the second option, we would be obligated to make aggregate Exit Compensation payments, including guaranteed interest, of approximately €303.9 million or $357.0 million, based on an exchange rate as of December 31, 2025 and reflecting interest accrued through December 31, 2025 during the pendency of the appraisal proceedings discussed below. Shareholders electing the first option of Annual Recurring Compensation may later elect the second option. The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that were initiated in 2023 in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger). Following the court's decision on a procedural matter in the DPLTA appraisal proceedings on July 14, 2025, the trial on the merits of the DPLTA has recommenced. It is expected to take a minimum of 12 months for a ruling of the court on the merits and such ruling will most likely be appealed, which would be expected to take an additional 12-24 months to be resolved. Accordingly, the Company does not expect a final decision on the DPLTA appraisal proceedings to be rendered and published prior to 2027, and most likely not until 2028 or beyond.

[0001193125-26-073878:notes:27]
Additionally, our obligation to pay Annual Recurring Compensation under the DPLTA is a continuing payment obligation, which will amount to approximately €7.9 million (or $9.3 million based on the exchange rate as of December 31, 2025) per year assuming none of the minority Adtran Networks shareholders as of December 31, 2025 were to elect Exit Compensation. The foregoing amounts do not reflect any potential increase in payment obligations that we may have depending on the outcome of ongoing appraisal proceedings in the German court. The Annual Recurring Compensation is due on the third banking day following the ordinary general shareholders’ meeting of Adtran Networks for the respective preceding fiscal year (but in any event within eight months following expiration of the fiscal year). With respect to the 2023 fiscal year, Adtran Networks’ ordinary general shareholders’ meeting occurred on June 28, 2024 and, therefore, the Annual Recurring Compensation was paid on July 3, 2024. With respect to the 2024 fiscal year, Adtran Networks’ ordinary general shareholder meeting occurred on June 27, 2025 and, therefore, the Annual Recurring Compensation was paid on July 1, 2025. With respect to the 2025 fiscal year, Adtran Networks’ ordinary general shareholder meeting is scheduled for the second quarter of 2026, and the Annual Recurring Compensation will be due on the third banking day following the meeting. During the years ended December 31, 2025 and 2024, we accrued $9.3 million and $9.8 million, respectively, in Annual Recurring Compensation. The Annual Recurring Compensation is reflected as an increase to retained deficit in the Consolidated Balance Sheets.

[0001193125-26-073878:notes:28]
On July 18, 2022, ADTRAN, Inc., as the borrower, and ADTRAN Holdings, Inc. entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (“Credit Agreement”), which has since been amended six times. The Company had access to $319.2 million on its Credit Facility for future borrowings based on debt covenant compliance metrics. The financial covenants under the Credit Agreement, as amended, require the Company to maintain a Consolidated Total Net Leverage Ratio of 5.00x, a Consolidated Senior Secured Net Leverage Ratio of 3.25x (4.0x to 3.5x during a Springing Covenant Period) and a Consolidated Fixed Charge Coverage Ratio of 1.25x (as such terms are defined in the Credit Agreement). In addition, during a Springing Covenant Period the cash and cash equivalents of the credit parties must be at least $50.0 million and the cash and cash equivalents of the Company and its subsidiaries must be at least $70.0 million.

[0001193125-26-073878:notes:29]
On October 18, 2022, the Company's Board of Directors authorized the Company to purchase additional shares of Adtran Networks through open market purchases not to exceed 15,346,544 shares.

[0001193125-26-073878:notes:30]
As of December 31, 2025, and as of the date of issuance of these financial statements, the Company has sufficient liquidity to meet the majority of its payment obligations under the DPLTA pertaining to Exit Compensation. For the year ended December 31, 2025, 2.0  million shares of Adtran Networks stock were tendered to the Company. This resulted in total Exit Compensation payments of approximately €40.2 million, or approximately $46.6 million, based on exchange rates at the time of the transactions, being paid to Adtran Networks shareholders. For the year ended December 31, 2024, approximately 0.8 million shares of Adtran Networks stock were tendered to the Company and Exit Compensation payments of approximately €15.7 million or approximately $17.4 million based on an exchange rate as of December 31, 2024, were paid to Adtran Networks shareholders. We believe the probability that more than a small minority of Adtran Networks shareholders elect to receive Exit Compensation in the next twelve months is remote based on the following factors: (i) the shareholders can exercise their right to receive the Exit Compensation until two months after publication of the final decision in the appraisal proceedings and we do not expect the final decision to be published within the next 12 months; (ii) the diverse base of shareholders that must make this election on an individual shareholder basis; (iii) the fact the date of a decision by the court on the merits of the case is uncertain, it will most likely take a minimum of 12 months for a ruling and, thereafter, an expected appeal process will take a further 12-24 months to resolve; (iv) the current guaranteed Annual Recurring Compensation payment; and (v) the current trading value of Adtran Networks shares.

[0001193125-26-073878:notes:31]
Moreover, on September 19, 2025, the Company issued $201.3 million aggregate principal amount of convertible senior notes due 2030 (the “Notes”). The Notes accrue interest at a rate of 3.75% per annum, payable semi-annually in arrears on March 15 and September 15 of each year, beginning March 15, 2026. Unless repurchased earlier, redeemed, or converted, the Notes will mature on September 15, 2030. After deducting the initial purchasers’ discounts, commissions, and estimated offering expenses, the Company received net proceeds of $192.6 million.

[0001193125-26-073878:notes:32]
The Company experienced revenue declines in the year ended December 31, 2024. However, customers began replenishing their inventories to meet increasing demand, and revenue increased throughout the year ended December 31, 2025. In 2023, the Company suspended dividend payments and effectuated a business efficiency program (the "Business Efficiency Program"), which targeted the reduction of ongoing operating expenses and focused on enhancing capital efficiency. The Business Efficiency Program was completed as of December 31, 2024. In addition, the Company continues to assess the probability that the sale of its headquarters in Huntsville will occur and has determined it is probable of occurring in the next twelve months.

[0001193125-26-073878:notes:33]
In summary, the Company believes that its cash and cash equivalents, working capital management initiatives and availability to access cash under the Wells Fargo credit facility or other future sources of capital will be adequate to meet our business operating requirements, our capital expenditures and our expected obligations under both the Notes and the DPLTA, including anticipated levels of Exit Compensation, as well as to support our ability to continue to comply with our debt covenants under the Credit Facility for at least the

[0001193125-26-073878:notes:34]
next twelve months, from the issuance of these financial statements. See Note 10, Credit Agreement, for additional information regarding the terms of the Amendments of the Wells Fargo Credit Agreement.

[0001193125-26-073878:notes:35]
Note 1 - Summary Of Significant Accounting Policies

[0001193125-26-073878:notes:36]
Basis of Presentation

[0001193125-26-073878:notes:37]
The accompanying Consolidated Financial Statements have been prepared in accordance with accounting principles generally accepted in the U.S. (“U.S. GAAP”) and include the financial position, results of operations, comprehensive (loss) income, changes in equity and cash flows of Adtran and its wholly-owned subsidiaries. All intercompany accounts and transactions have been eliminated in consolidation.

[0001193125-26-073878:notes:38]
Use of Estimates

[0001193125-26-073878:notes:39]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenue and expense during the reporting period. Significant estimates include allowance for credit losses on accounts receivable and contract assets, excess and obsolete inventory reserves, determination and accrual of the deferred revenue related to performance obligations under contracts with customers, estimated costs to complete obligations associated with deferred and accrued revenue and network installations, estimated income tax provision and income tax contingencies, fair value of stock-based compensation, assessment of goodwill and other intangibles for impairment, estimated lives of intangible assets, estimates of intangible assets upon measurement, estimated pension liability and fair value of investments and estimated contingent liabilities. Actual amounts could differ significantly from these estimates.

[0001193125-26-073878:notes:40]
We assessed certain accounting matters that generally require consideration of forecasted financial information in context with the information reasonably available to us and the unknown future impacts of ongoing inflationary pressures, continued elevated interest rates, instability in the financial services industry, currency fluctuations and political tensions as of December 31, 2025, and through the date of this report. These conditions could result in further impacts to the Company's consolidated financial statements in future reporting periods. The accounting matters assessed included, but were not limited to, the allowance for credit losses, stock-based compensation, carrying value of goodwill, intangibles and other long-lived assets, financial assets, valuation allowances for tax assets, revenue recognition and costs of revenue.

[0001193125-26-073878:notes:41]
Summary of Significant Accounting Policies

[0001193125-26-073878:notes:42]
Cash and Cash Equivalents

[0001193125-26-073878:notes:43]
Cash and cash equivalents represent demand deposits, money market funds and short-term investments classified as available-for-sale with original maturities of three months or less. We maintain depository investments with certain financial institutions. As of December 31, 2025, $92.0 million of our cash and cash equivalents, primarily certain domestic money market funds and foreign depository accounts, were in excess of government provided insured depository limits. Although these depository investments may exceed government insured depository limits, we have evaluated the credit worthiness of these applicable financial institutions and determined the risk of material financial loss due to the exposure of such credit risk to be minimal.

[0001193125-26-073878:notes:44]
Fair Value of Financial Instruments

[0001193125-26-073878:notes:45]
Fair value is defined as the price that would be received to sell an asset or paid to transfer a liability in an orderly transaction between market participants at the measurement date. Where available, fair value is based on observable market prices or parameters or derived from such prices or parameters. Where observable prices or inputs are not available, valuation models may be applied. Assets and liabilities recorded at fair value in our consolidated balance sheets are categorized based upon the level of judgment associated with the inputs used to measure their fair values.

[0001193125-26-073878:notes:46]
The carrying amounts reported in the Consolidated Balance Sheets for cash and cash equivalents, accounts receivable and accounts payable approximate fair value due to the immediate or short-term maturity of these financial instruments.

[0001193125-26-073878:notes:47]
The fair value measurements of our derivative instruments are determined using models that maximize the use of the observable market inputs including interest rate curves and both forward and spot prices for currencies, and are classified as Level II under the fair value hierarchy.

[0001193125-26-073878:notes:48]
Investments with contractual maturities beyond one year may be classified as short-term based on their highly liquid nature and because such marketable securities represent the investment of cash that is available for current operations. Despite the long-term nature of their stated contractual maturities, we routinely buy and sell these securities and we believe we have the ability to quickly sell them to the remarketing agent, tender agent or issuer at par value plus accrued interest in the event we decide to liquidate our investment in a particular variable rate demand note. All income generated from these investments is recorded as interest income. We have not recorded any losses relating to variable rate demand notes.

[0001193125-26-073878:notes:49]
Short-term investments is comprised of our deferred compensation plan assets. Long-term investments is comprised of our marketable equity securities and other equity investments. Marketable equity securities are reported at fair value as determined by the most recently traded price of the securities at the balance sheet date, although the securities may not be readily marketable due to the size of the available market. Any changes in fair value are recognized in net investment gain. Realized gains and losses on sales of debt securities are computed under the specific identification method and are included in other (expense) income, net. See Note 4 for additional information.

[0001193125-26-073878:notes:50]
Accounts Receivable

[0001193125-26-073878:notes:51]
The Company records accounts receivable at amortized cost. Prior to establishing payment terms for a new customer, we evaluate the credit risk of the customer. Credit limits and payment terms established for new customers are re-evaluated periodically based on customer collection experience and other financial factors. As of December 31, 2025, no customer comprised more than 10% of our total accounts receivable balance. As of December 31, 2024, no customer comprised more than 10% of our total accounts receivable balance.

[0001193125-26-073878:notes:52]
Accounts receivable balances are considered past due when payment has not been received by the date indicated on the relevant invoice or based on agreed upon terms between the customer and the Company. The Company regularly reviews the need for an allowance for credit losses related to our outstanding accounts receivable balances using the historical loss-rate method, as well as assessing asset-specific risks. The assessment of asset-specific risks included the evaluation of relevant available information, from internal and external sources, relating to current conditions that may affect a customer’s ability to pay, such as the customer’s current financial condition or credit rating by geographic location, as provided by a third party and/or by customer, if needed, and overall macro-economic conditions in which the customer operates. The Company pools assets by geographic location to determine if an allowance should be applied to its accounts receivable balance, assessing the specific country risk rating and overall economics of that particular country. If elevated risk existed, or customer specific risk indicated the accounts receivable balance was at risk, the Company would further analyze the need for an allowance related to specific accounts receivable balances. Additionally, the Company would determine if significant changes to customer country risk rating from period-to-period and from the end of the prior year to the end of the current quarter would require further review and analysis by the Company. Based on these assessments, an allowance for credit losses would be recorded if the Company determined that, based on our historical write-offs, which have been immaterial, and such asset specific risks, there was risk in collectability of the full amount of any accounts receivable.

[0001193125-26-073878:notes:53]
Accounts Receivable Factoring

[0001193125-26-073878:notes:54]
Receivables Purchase Agreement

[0001193125-26-073878:notes:55]
On July 1, 2024, the Company entered into a receivables purchase agreement (the “Factoring Agreement”) with a third-party financial institution (the “Factor”), which accelerates receivable collection and helps to better manage cash flow. These transactions are accounted for in accordance with ASC Topic 860 and result in a reduction in accounts receivable because the Factoring Agreement transfers effective control over, and risk related to the receivables to the buyers. Trade accounts receivables balances sold are removed from the Consolidated Balance Sheets and cash received is reflected as cash flows provided by (used in) operating activities in the Consolidated Statements of Cash Flow. Factoring related interest expense is recorded to interest expense on the Consolidated Statements of Loss. On each sale date, the Factor retains from the sale price a default reserve, up to a required balance, which is held by the Factor in a reserve account and pledged to the Company. The Factor is entitled to withdraw from the reserve account the sale price of a defaulted receivable. The balance in the reserve account is included in other assets on the Consolidated Balance Sheets. The Company at its own expense does have collection and administrative responsibilities for the sold receivables and that is its only continuing involvement with the Factor. The Company is not compensated for the servicing of the factoring program and deems the costs of servicing the receivables sold to be immaterial.

[0001193125-26-073878:notes:56]
On December 19, 2023, the Company entered into a factoring agreement with a third-party financial institution to sell, on a revolving basis, undivided interests in the Company’s accounts receivable. The factoring agreement qualified for treatment as a secured borrowing with a pledge of collateral under Accounting Standards Codification ("ASC") Topic 810, Consolidations, as the Company was considered the primary beneficiary in a variable interest entity created to hold the factored receivables and the Company retained a residual claim on reserves related to the factored receivables. The receivables factored were carried in accounts receivable, less allowance for credit losses on the Consolidated Balance Sheets, the secured borrowings were carried on the Company’s Consolidated Balance Sheets as a current liability, in accounts payable, proceeds and repayments of the secured borrowings are reflected as cash flows (used in) provided by financing activities in the Consolidated Statements of Cash Flows and program fees are recorded in interest expense in the Company’s Consolidated Statements of Loss. The short-term liability classification of the secured borrowings was based on the estimated timing of the collection of the accounts receivable which were expected to be received within 12 months. The receivables purchase agreement was terminated on July 1, 2024 and there were no secured borrowings under this agreement as of December 31, 2024. See Note 2 for additional information.

[0001193125-26-073878:notes:57]
Inventory

[0001193125-26-073878:notes:58]
Inventory is carried at the lower of cost and estimated net realizable value, with cost being determined using the first-in, first-out method. Standard costs for material, labor and manufacturing overhead are used to value inventory and are updated at least quarterly. We establish reserves for estimated excess and obsolete inventory equal to the difference between the cost of the inventory and the estimated net realizable value of the inventory based on estimated reserve percentages, which consider historical usage, known trends, inventory age and market conditions. When we dispose of excess and obsolete inventories, the related disposals are charged against the inventory reserve. See Note 5 for additional information.

[0001193125-26-073878:notes:59]
Property, Plant and Equipment

[0001193125-26-073878:notes:60]
Property, plant and equipment, which is stated at cost, is depreciated using the straight-line method over the estimated useful lives of the assets. Generally, we depreciate building and land improvements from 5 to 39 years, office machinery and equipment from three to seven years, engineering machinery and equipment from three to seven years, and computer software from 3 to 5 years. Expenditures for repairs and maintenance are charged to expense as incurred. Major improvements that materially prolong the lives of the assets are capitalized. Gains and losses on the disposal of property, plant and equipment are recorded in operating loss. See Note 6 for additional information.

[0001193125-26-073878:notes:61]
Assets Held for Sale

[0001193125-26-073878:notes:62]
An asset is considered to be held for sale when all the following criteria are met: (i) management commits to a plan to sell the asset; (ii) the asset is available for immediate sale in its present condition; (iii) actions required to complete the sale of the asset have been initiated; (iv) sale of the asset is probable and the completed sale is expected to occur within one year; (v) it is unlikely that the disposal plan will be significantly modified; and (vi) the asset is actively being marketed for sale at a price that is reasonable given its current market value. The Company records assets held for sale at the lower of their carrying value or fair value.

[0001193125-26-073878:notes:63]
Intangible Assets

[0001193125-26-073878:notes:64]
Purchased intangible assets with finite lives are carried at cost less accumulated amortization. Amortization is recorded over the estimated useful lives of the respective assets. See Note 9 for additional information.

[0001193125-26-073878:notes:65]
Impairment of Long-Lived Assets and Intangibles

[0001193125-26-073878:notes:66]
Long-lived assets, such as property, plant and equipment, right of use lease assets and purchased intangibles subject to amortization, are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable. Recoverability of assets to be held and used is measured by a comparison of the carrying amount of an asset to estimated undiscounted future cash flows expected to be generated by the asset or asset group. If the carrying amount of an asset exceeds its estimated future cash flows, an impairment charge is recognized by the amount by which the carrying amount of the asset exceeds the fair value of the asset or asset group.

[0001193125-26-073878:notes:67]
There were no impairment losses for long-lived assets and intangible assets during the years ended December 31, 2025, 2024 and 2023. See Note 9 for additional information.

[0001193125-26-073878:notes:68]
Goodwill

[0001193125-26-073878:notes:69]
Goodwill represents the excess purchase price over the fair value of net assets acquired. The Company’s annual impairment assessment is done at the reporting unit level, which we determined are generally the same as our operating segments, which are identified in Note 16 to the Consolidated Financial Statements. We review goodwill for impairment annually during the fourth quarter and also test for impairment between annual tests if an event occurs or circumstances change that would more likely than not reduce the fair value of our reporting units below their carrying amount. Such events and circumstances may include among others: a significant adverse change in legal factors or in the general business climate; significant decline in our stock price and market capitalization; unanticipated competition; the testing for recoverability of a significant asset within the reporting unit; and an adverse action or assessment by a regulator. Any adverse change in these factors could have a significant impact on the recoverability of goodwill and could have a material impact on our consolidated financial statements. See Note 8 for additional information.

[0001193125-26-073878:notes:70]
Convertible Senior Notes

[0001193125-26-073878:notes:71]
We account for our convertible senior notes with embedded conversion features in accordance with ASC 470-20, under which convertible debt instruments would only be separated into multiple components if they were issued at a substantial premium or if embedded derivatives requiring bifurcation were identified. The convertible senior notes (the "2030 Notes" or the “Notes”) were not issued at a substantial premium, and we analyzed the provisions of the 2030 Notes and did not identify any material embedded features which would require bifurcation from the host debt. As such, the 2030 Notes are accounted for entirely as a liability, net of unamortized issuance costs. The carrying amount of the liability is classified as long-term as the instrument does not mature within one year of the balance sheet date and the holder is not permitted to demand repayment of the principal within one year of the balance sheet date. However, if conditions to convertibility are met and holders are expected to convert within one year as described further in Note 11, we may be required to reclassify the carrying amount of the liability to current. Issuance costs are amortized to interest expense using the effective interest rate method.

[0001193125-26-073878:notes:72]
Pension Benefit Plan Obligations

[0001193125-26-073878:notes:73]
The Company maintains a defined benefit pension plans covering employees in certain foreign countries. Pension benefit plan obligations are based on various assumptions used by our actuaries in calculating these amounts. These assumptions include discount rates, compensation rate increases, expected return on plan assets, retirement rates and mortality rates. The pension benefit plan obligation is calculated based on the actuarial present value of expected future payments as of the balance sheet date required to settle the obligation resulting from employee service rendered prior to that date. This amount is known as the projected benefit obligation. Actual results that differ from the assumptions and changes in assumptions could affect future expenses and obligations. See Note 13 for additional information.

[0001193125-26-073878:notes:74]
Lease Obligations

[0001193125-26-073878:notes:75]
The Company has operating leases for office space, automobiles and various other equipment in the U.S. and in certain international locations. Other contracts, such as manufacturing agreements and service agreements, are reviewed to determine if they contain potential embedded leases. These other contracts are specifically reviewed to determine whether we have the right to substantially all of the economic benefit from the use of any specified assets or the right to direct the use of any specified assets, either of which would indicate the existence of a lease. Some of our leases include options to renew. For those leases that are reasonably assured to be renewed, we have included the option to extend as part of our right of use asset and lease liability. The exercise of lease renewal options is at our sole discretion. The depreciable life of leased assets and leasehold improvements are limited by the expected lease term. Leases with an initial term of 12 months or less are not recorded on the balance sheet and lease expense for these leases is recognized on a straight-line basis over the lease term. For lease agreements entered into or reassessed after the adoption of Topic 842, we elected to not separate lease and non-lease components. Our lease agreements do not contain any material residual value guarantees or material restrictive covenants.

[0001193125-26-073878:notes:76]
Stock-Based Compensation

[0001193125-26-073878:notes:77]
The Company has two stock incentive plans from which stock options, performance stock units (“PSUs”), restricted stock units (“RSUs”) and restricted stock are available for grant to employees and directors. Costs related to these awards are recognized over their vesting periods. See Note 3 for additional information.

[0001193125-26-073878:notes:78]
Research and Development Costs

[0001193125-26-073878:notes:79]
Research and development costs include compensation for engineers and support personnel, contracted services, depreciation and material costs associated with new product development, enhancement of current products and product cost reductions. We continually evaluate new product opportunities and engage in intensive research for product and software development efforts. Research and development costs totaled $204.3 million, $221.5 million and $258.3 million for the years ended December 31, 2025, 2024 and 2023, respectively.

[0001193125-26-073878:notes:80]
Adtran Networks has arrangements with governmental entities for the purposes of obtaining funding for research and development activities. The Company classifies government grants received under these arrangements as a reduction to research and development expense incurred. For the years ended December 31, 2025, 2024 and 2023, the Company recognized $11.8 million, $9.2 million and $5.2 million, respectively, as a reduction of research and development expense.

[0001193125-26-073878:notes:81]
Advertising Costs

[0001193125-26-073878:notes:82]
The Company expenses all advertising costs as incurred. Advertising expenses for the years ended December 31, 2025, 2024 and 2023, totaled $0.2 million, $0.1 million and $0.2 million, respectively.

[0001193125-26-073878:notes:83]
Income Taxes

[0001193125-26-073878:notes:84]
The provision for income taxes has been determined using the asset and liability approach of accounting for income taxes. Under this approach, deferred taxes represent the future tax consequences expected to occur when the reported amounts of assets and liabilities are

[0001193125-26-073878:notes:85]
recovered or paid. The provision for income taxes represents income taxes paid or payable for the current year plus the change in deferred taxes during the year. Deferred taxes result from the difference between financial and tax basis of our assets and liabilities and are adjusted for changes in tax rates and tax laws when such changes are enacted. Valuation allowances are recorded to reduce deferred tax assets when it is more likely than not that a tax benefit will not be realized.

[0001193125-26-073878:notes:86]
In determining whether an uncertain tax position exists, the Company determines, based solely on its technical merits, whether the tax position is more likely than not to be sustained upon examination, and if so, a tax benefit is measured on a cumulative probability basis that is more likely than not to be realized upon the ultimate settlement. The Company recognizes interest and penalties related to unrecognized tax benefits through interest expense and income tax expense, respectively.

[0001193125-26-073878:notes:87]
Foreign Currency

[0001193125-26-073878:notes:88]
Transactions with customers that are denominated in foreign currencies are recorded using the appropriate exchange rates from throughout the year. Assets and liabilities denominated in foreign currencies are remeasured at the balance sheet dates using the closing rates of exchange between those foreign currencies and the functional currency with any transaction gains or losses reported in other income, net. Our primary exposures to foreign currency exchange rate movements are with our German and U.K. subsidiaries, whose functional currencies are the euro and the British pound sterling. Adjustments resulting from translating financial statements of international subsidiaries are recorded as a component of accumulated other comprehensive income.

[0001193125-26-073878:notes:89]
Revenue

[0001193125-26-073878:notes:90]
Revenue is measured based on the consideration expected to be received in exchange for transferring goods or providing services to a customer and as performance obligations under the terms of the contract are satisfied. Generally, this occurs with the transfer of control of a product to the customer. For transactions where there are multiple performance obligations, individual products and services are accounted for separately if they are distinct (if a product or service is separately identifiable from other items and if a customer can benefit from it on its own or with other resources that are readily available to the customer). The consideration, including any discounts, is allocated between separate products and services based on their stand-alone selling prices. Stand-alone selling prices are determined based on the prices at which the separate products and services are sold and are allocated based on each item’s relative value to the total value of the products and services in the arrangement. For items that are not sold separately, we estimate stand-alone selling prices primarily using the “expected cost plus a margin” approach. Payment terms are generally 30 days in the U.S. and typically longer in many geographic markets outside the U.S. Shipping fees collected are recorded as revenue and the related cost is included in cost of revenue. Revenue, value-added and other taxes collected concurrently with revenue-producing activities are excluded from revenue. Incremental costs of obtaining a contract, that are recoverable, are capitalized and amortized over the period that the related revenue is recognized if greater than one year. We have elected to account for shipping fees paid as a cost of fulfilling the related contract. We have also elected to apply the practical expedient related to the incremental costs of obtaining contracts and recognize those costs as an expense when incurred if the amortization period of the assets is one year or less. These costs are included in selling, general and administrative expenses. Capitalized costs with an amortization period greater than one year were immaterial.

[0001193125-26-073878:notes:91]
Revenue is generated by two reportable segments: Network Solutions and Services & Support.

[0001193125-26-073878:notes:92]
Network Solutions Segment - Includes hardware products and software defined next-generation virtualized solutions used in Service Provider or business networks, as well as prior generation products. The majority of the revenue from this segment is from hardware revenue.

[0001193125-26-073878:notes:93]
Hardware and Software Revenue

[0001193125-26-073878:notes:94]
Revenue from hardware sales is recognized when control is transferred to the customer, which is generally when the products are shipped. Shipping terms are generally FOB shipping point. Revenue from software license sales is recognized at delivery and transfer of control to the customer. Revenue is recognized net of estimated discounts and rebates using historical trends. Customers are typically invoiced when control is transferred and revenue is recognized. Our products generally include assurance-based warranties of 90 days to five years for product defects, which are accrued at the time products are delivered.

[0001193125-26-073878:notes:95]
Services & Support Segment - Includes a complete portfolio of maintenance, network implementation and solutions integration and managed services, which include hosted cloud services and subscription services to complement our Network Solutions segment.

[0001193125-26-073878:notes:96]
Maintenance Revenue

[0001193125-26-073878:notes:97]
Our maintenance service periods range from one month to five years. Customers are typically invoiced and pay for maintenance services at the beginning of the maintenance period. We recognize revenue for maintenance services on a straight-line basis over the maintenance period as our customers benefit evenly throughout the contract term and deferred revenue, when applicable, are recorded in current and non-current unearned revenue.

[0001193125-26-073878:notes:98]
Network Implementation Revenue

[0001193125-26-073878:notes:99]
The Company recognizes revenue for network implementation, which primarily consists of engineering, execution and enablement services at a point in time when each performance obligation is complete. If we have recognized revenue but have not billed the customer, the right to consideration is recognized as a contract asset that is included in other receivables on the Consolidated Balance Sheet. The contract asset is transferred to accounts receivable when the completed performance obligation is invoiced to the customer.

[0001193125-26-073878:notes:100]
See Notes 2 and 16 for additional information on reportable segments.

[0001193125-26-073878:notes:101]
Unearned Revenue

[0001193125-26-073878:notes:102]
Unearned revenue primarily represents customer billings on maintenance service programs and unearned revenue related to multiple element contracts where we still have contractual obligations to our customers. We currently offer maintenance contracts ranging from one month to five years. Revenue attributable to maintenance contracts is recognized on a straight-line basis over the related contract term. We currently provide software maintenance and a variety of hardware maintenance services to customers ranging from one month to five years. When we defer revenue related to multiple performance obligations where we still have contractual obligations, we also defer the related costs. Current deferred costs are included in prepaid expenses and other current assets on the accompanying Consolidated Balance Sheets and totaled $2.0 million and $2.2 million as of December 31, 2025 and 2024, respectively. Non-current deferred costs included in other non-current assets on the accompanying Consolidated Balance Sheets were less than $0.1 million as of December 31, 2025 and 2024.

[0001193125-26-073878:notes:103]
Redeemable Non-Controlling Interest

[0001193125-26-073878:notes:104]
As of December 31, 2025 and 2024, the non-controlling Adtran Networks stockholders’ equity ownership percentage in Adtran Networks was approximately 29.2% and 33.0%, respectively.

[0001193125-26-073878:notes:105]
As a result of the effectiveness of the DPLTA on January 16, 2023, the Adtran Networks shares, representing the equity interest in Adtran Networks held by holders other than the Company, can be tendered at any time and are, therefore, redeemable and must be classified outside stockholders’ equity. Therefore, the permanent equity noncontrolling interest balance was reclassified to redeemable non-controlling interest (RNCI) on January 16, 2023 and was remeasured to fair value based on the trading market price of the Adtran Networks shares.

[0001193125-26-073878:notes:106]
Subsequently, the carrying value of the RNCI is adjusted to its maximum redemption value at each reporting date when the maximum redemption value is greater than the initial carrying amount of the RNCI. For the period of time that the DPLTA is in effect, the RNCI will continue to be presented as RNCI outside of stockholders’ equity in the Consolidated Balance Sheets. See Note 15 for additional information on RNCI.

[0001193125-26-073878:notes:107]
Loss per Share

[0001193125-26-073878:notes:108]
Loss per common share and loss per common share assuming dilution are based on the weighted average number of common shares and, when dilutive, common equivalent shares outstanding during the year. See Note 18 for additional information.

[0001193125-26-073878:notes:109]
Loss per common share attributable to ADTRAN Holdings, Inc. - basic and diluted - reflects a $4.1 million and $3.0 million effect of redemption of RNCI for the years ended December 31, 2025 and 2024, respectively. There was no effect of redemption during the year ended December 31, 2023. See Note 18 for additional information.

[0001193125-26-073878:notes:110]
Recent Accounting Pronouncements Not Yet Adopted

[0001193125-26-073878:notes:111]
In September 2025, the Financial Accounting Standards Board (“FASB”) issued ASU 2025-06, "Intangibles-Goodwill and Other-Internal-Use Software (Subtopic 350-40): Targeted Improvements to the Accounting for Internal-Use Software," which is intended to modernize the accounting for the costs of internal-use software given the evolution of software development to the incremental and iterative development method. The amendments remove all references to prescriptive and sequential development stages and, instead, require an entity to start capitalizing software costs when management has authorized and committed to funding the software project, and it is probable that the project will be completed and the software will be used to perform the function intended. The amendments are effective for annual reporting periods beginning after December 15, 2027, and interim reporting periods within those annual reporting periods. Early adoption is permitted as of the beginning of an annual reporting period with the amendments to be applied using a prospective, modified or retrospective transition approach. The Company is currently evaluating the impact of adopting this guidance on the consolidated financial statements.

[0001193125-26-073878:notes:112]
In November 2024, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update ("ASU") 2024-03, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40): Disaggregation of Income Statement Expenses, as amended by ASU 2025-01, Income Statement—Reporting Comprehensive Income—Expense Disaggregation Disclosures (Subtopic 220-40): Clarifying the Effective Date, which applies to all public business entities and is intended to enhance disclosures about specific types of expenses included in the expense captions presented on the face of the income statement as well as disclosures about selling expenses. The amendments are effective prospectively in the first annual period beginning after December 15, 2026 and interim reporting periods within annual reporting periods beginning after December 15, 2027. Early adoption and retrospective application are permitted. The Company is currently evaluating the effect that adoption of ASU 2024-03 will have on our disclosures.

[0001193125-26-073878:notes:113]
Recently Adopted Accounting Pronouncements

[0001193125-26-073878:notes:114]
In December 2023, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update ("ASU") 2023-09, "Income Taxes (Topic 740): Improvements to Income Tax Disclosures", which is intended to enhance the transparency, decision usefulness and effectiveness of income tax disclosures. The amendments in this ASU require a public entity to disclose a tabular tax rate reconciliation, using both percentages and currency, with specific categories. A public entity is also required to provide a qualitative description of the states and local jurisdictions that make up the majority of the effect of the state and local income tax category and the net amount of income taxes paid, disaggregated by federal, state and foreign taxes and also disaggregated by individual jurisdictions. The amendments also remove certain disclosures that are no longer considered cost beneficial. The amendments are effective prospectively for annual periods beginning after December 15, 2024, and early adoption and retrospective application are permitted. The Company adopted the new standard with prospective application on January 1, 2025. The adoption of this standard resulted in additional footnote disclosures. The adoption of this standard did not have a material impact on our Consolidated Balance Sheet, Consolidated Statement of Income or Consolidated Statement of Cash Flows. See Note 12 for additional information.

[0001193125-26-073878:notes:115]
There have been no other recently adopted accounting pronouncements that are expected to have a material effect on the Consolidated Financial Statements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001193125-26-073878:notes:116]
Note 2 - Revenue and Receivables

[0001193125-26-073878:notes:117]
The following is a description of the principal activities from which revenue is generated by reportable segment:

[0001193125-26-073878:notes:118]
Network Solutions Segment - Includes hardware and software products that enable a digital future which support the Company's Subscriber, Access and Aggregation, and Optical Networking Solutions.

[0001193125-26-073878:notes:119]
Services & Support Segment - Includes network design, implementation, maintenance and cloud-hosted services supporting the Company's Subscriber, Access and Aggregation, and Optical Networking Solutions.

[0001193125-26-073878:notes:120]
Revenue by Category

[0001193125-26-073878:notes:121]
In addition to operating under two reportable segments, the Company also reports revenue across three categories – Subscriber Solutions, Access & Aggregation Solutions and Optical Networking Solutions.

[0001193125-26-073878:notes:122]
Our Subscriber Solutions portfolio is used by Service Providers to terminate their access services infrastructure at the customer premises while providing an immersive and interactive experience for residential, business and wholesale subscribers. This revenue category includes hardware- and software-based products and services. These solutions include fiber termination solutions for residential, business and wholesale subscribers, Wi-Fi access solutions for residential and business subscribers, Ethernet switching and network edge virtualization solutions for business subscribers, and cloud software solutions covering a mix of subscriber types.

[0001193125-26-073878:notes:123]
Our Access & Aggregation Solutions are solutions that are used by communications Service Providers to connect residential subscribers, business subscribers and mobile radio networks to the Service Providers’ metro network, primarily through fiber-based connectivity. This revenue category includes hardware- and software-based products and services. Our solutions within this category are a mix of fiber access and aggregation platforms, precision network synchronization and timing solutions, and access orchestration solutions that ensure highly reliable and efficient network performance.

[0001193125-26-073878:notes:124]
Our Optical Networking Solutions are used by communications Service Providers, internet content providers and large-scale enterprises to securely interconnect metro and regional networks over fiber. This revenue category includes hardware- and software-based products and services. Our solutions within this category include open optical terminals, open line systems, optical subsystems and modules, network infrastructure assurance systems, and automation platforms that are used to build high-scale, secure and assured optical networks.

[0001193125-26-073878:notes:125]
The following table disaggregates revenue by reportable segment and revenue category for the year ended December 31, 2025:

[0001193125-26-073878:notes:126]
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Optical Networking Solutions |  | $ | 281,771 |  |  | $ | 98,541 |  |  | $ | 380,312 |  |
| Subscriber Solutions |  |  | 336,297 |  |  |  | 32,779 |  |  |  | 369,076 |  |
| Access & Aggregation Solutions |  |  | 278,843 |  |  |  | 55,576 |  |  |  | 334,419 |  |
| Total |  | $ | 896,911 |  |  | $ | 186,896 |  |  | $ | 1,083,807 |  |

[0001193125-26-073878:notes:127]
The following table disaggregates revenue by reportable segment and revenue category for the year ended December 31, 2024:

[0001193125-26-073878:notes:128]
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Optical Networking Solutions |  | $ | 210,489 |  |  | $ | 90,447 |  |  | $ | 300,936 |  |
| Subscriber Solutions |  |  | 295,541 |  |  |  | 35,237 |  |  |  | 330,778 |  |
| Access & Aggregation Solutions |  |  | 232,934 |  |  |  | 58,072 |  |  |  | 291,006 |  |
| Total |  | $ | 738,964 |  |  | $ | 183,756 |  |  | $ | 922,720 |  |

[0001193125-26-073878:notes:129]
The following table disaggregates revenue by reportable segment and revenue category for the year ended December 31, 2023:

[0001193125-26-073878:notes:130]
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Optical Networking Solutions |  | $ | 407,123 |  |  | $ | 85,851 |  |  | $ | 492,974 |  |
| Subscriber Solutions |  |  | 263,192 |  |  |  | 34,516 |  |  |  | 297,708 |  |
| Access & Aggregation Solutions |  |  | 304,074 |  |  |  | 54,344 |  |  |  | 358,418 |  |
| Total |  | $ | 974,389 |  |  | $ | 174,711 |  |  | $ | 1,149,100 |  |

[0001193125-26-073878:notes:131]
The aggregate amount of transaction price allocated to remaining performance obligations ("RPO") that have not been satisfied as of December 31, 2025 related to non-cancellable contractual maintenance agreements, non-cancellable contractual SaaS and subscription services, and non-cancellable hardware contracts amounted to $209.7 million. The Company will generally satisfy the remaining performance obligations as we transfer control of the products ordered or services to our customers, excluding maintenance services, which are satisfied over time.

[0001193125-26-073878:notes:132]
The following table provides information about accounts receivable, contract assets and unearned revenue from contracts with customers:

[0001193125-26-073878:notes:133]
| (In thousands) |  | December 31, 2025 |  |  | December 31, 2024 |  |
| Accounts receivable |  | $ | 210,687 |  |  | $ | 178,030 |  |
| Contract assets(1) |  | $ | 432 |  |  | $ | 631 |  |
| Unearned revenue |  | $ | 87,541 |  |  | $ | 52,701 |  |
| Non-current unearned revenue |  | $ | 27,143 |  |  | $ | 22,065 |  |

[0001193125-26-073878:notes:134]
(1) Included in other receivables on the Consolidated Balance Sheets.

[0001193125-26-073878:notes:135]
The allowance for credit losses was $1.3 million as of December 31, 2025, and December 31, 2024, related to accounts receivable.

[0001193125-26-073878:notes:136]
On July 1, 2024, the Company entered into a receivables purchase agreement (the “Factoring Agreement”) with a third-party financial institution, which accelerates receivable collection and helps to better manage cash flow. Total accounts receivables factored as of the end of December 31, 2025, totaled $25.3 million net of $3.8 million retained pursuant to the Factoring Agreement in the reserve account. Total accounts receivables factored as of the end of December 31, 2024, totaled $18.3 million net of $3.7 million retained pursuant to the Factoring Agreement in the reserve account. The Factoring Agreement provides for up to $40.0 million in factoring capacity, subject to eligible receivables and reserve requirements, secured by the receivables.

[0001193125-26-073878:notes:137]
During the years ended, December 31, 2025 and 2024, the Company received $169.1 million and $78.4 million, in cash proceeds from the Factoring Agreement, respectively. The cost of the Factoring Agreement totaled $1.4 million and $0.6 million for the years ended December 31, 2025 and 2024, respectively. The Company received $103.6 million in cash proceeds and incurred costs of $0.9 million from a previous receivables purchase agreement for the year ended December 31, 2023.

[0001193125-26-073878:notes:138]
On December 19, 2023, the Company entered into a receivables purchase agreement (the “Prior Factoring Agreement”) with a third-party financial institution to replace a prior accounts receivable purchase agreement and to sell, on a revolving basis, undivided interests in the Company’s accounts receivable. The Prior Factoring Agreement provided for up to $40.0 million in borrowing capacity, subject to eligible receivables and reserve requirements, secured by the receivables. The Prior Factoring Agreement qualified for treatment as a secured borrowing with a pledge of collateral under Accounting Standards Codification ("ASC") Topic 810, Consolidations. The receivables purchase agreement was terminated on July 1, 2024 and there were no secured borrowings under this agreement as of December 31, 2024. For the year ended December 31, 2024, the Company incurred program fee expenses of $0.6 million.

[0001193125-26-073878:notes:139]
Contract Assets

[0001193125-26-073878:notes:140]
No allowance for credit losses was recorded for the years ended December 31, 2025 and 2024, respectively, related to contract assets.

[0001193125-26-073878:notes:141]
Of the outstanding unearned revenue balances as of December 31, 2024, $50.5 million were recognized as revenue during the year ended December 31, 2025. Of the outstanding unearned revenue balances as of December 31, 2023, $50.5 million were recognized as revenue during the year ended December 31, 2024.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-26-073878:notes:142]
Note 3 – Stock-Based Compensation

[0001193125-26-073878:notes:143]
2024 Stock Incentive Plans

[0001193125-26-073878:notes:144]
At the annual meeting of stockholders held on May 8, 2024, the Company’s stockholders approved, upon recommendation of the Board of Directors, the adoption of the ADTRAN Holdings, Inc. 2024 Employee Stock Incentive Plan (“2024 Employee Plan”) and the ADTRAN Holdings, Inc. 2024 Directors Stock Plan (“2024 Directors Plan”). No additional awards may be granted under the Company’s previous stock incentive plans, including the 2020 Employee Stock Incentive Plan, the 2020 Directors Stock Plan, or the 2015 Employee Stock Incentive Plan. Outstanding awards granted under the Company's prior equity incentive plans will remain subject to the terms of such applicable plans, and shares under such plans that are cancelled or forfeited will be available for issuance under the 2024 Employee Plan or the 2024 Directors Plan, as applicable.

[0001193125-26-073878:notes:145]
Under the 2024 Employee Plan, the Company is authorized to issue 4.0 million shares of common stock to certain employees, key service providers and advisors through incentive stock options, non-qualified stock options, stock appreciation rights, RSUs and restricted stock, any of which may be subject to performance-based conditions. RSUs and restricted stock granted under the 2024 Employee Plan will typically vest pursuant to a four-year vesting schedule beginning on the first anniversary of the grant date. Stock options granted under the 2024 Employee Plan will typically become exercisable beginning after one year of continued employment, normally pursuant to a four-year vesting schedule beginning on the first anniversary of the grant date and have a ten-year contractual term. Stock options, RSUs and restricted stock granted under the 2024 Employee Plan reduce the shares authorized for issuance under the 2024 Employee Plan by one share of common stock for each share underlying the award. Forfeitures, cancellations and expirations of awards granted under the prior employee stock incentive plans increase the shares authorized for issuance under the 2024 Employee Plan by one share of common stock for each share underlying the award.

[0001193125-26-073878:notes:146]
Under the 2024 Directors Plan, the Company is authorized to issue 0.7 million shares of common stock through stock options, restricted stock and RSUs to non-employee directors. Stock awards issued under the 2024 Directors Plan typically will become vested in full on the first anniversary of the grant date. Stock options issued under the 2024 Directors Plan will have a ten-year contractual term. Stock options, restricted stock and RSUs granted under the 2024 Directors Plan reduce the shares authorized for issuance under the 2024 Directors Plan by one share of common stock for each share underlying the award. Forfeitures, cancellations and expirations of awards granted under the prior directors stock plan increase the shares authorized for issuance under the 2024 Directors Plan by one share of common stock for each share underlying the award.

[0001193125-26-073878:notes:147]
As of December 31, 2025, 4.7 million shares were available for issuance pursuant to awards that may be made in the future under stockholder-approved equity plans.

[0001193125-26-073878:notes:148]
For the years ended December 31, 2025, 2024 and 2023, stock-based compensation expense was $10.1 million, $16.0 million and $16.4 million respectively.

[0001193125-26-073878:notes:149]
The following table summarizes stock-based compensation expense related to stock options, PSUs, RSUs and restricted stock for the years ended December 31, 2025, 2024 and 2023:

[0001193125-26-073878:notes:150]
| (In thousands) |  | 2025 |  |  | 2024 |  |  | 2023 |  |
| Stock-based compensation expense included in cost of revenue |  | $ | 986 |  |  | $ | 1,142 |  |  | $ | 1,293 |  |
| Selling, general and administrative expenses |  |  | 5,971 |  |  |  | 11,058 |  |  |  | 11,066 |  |
| Research and development expenses |  |  | 3,105 |  |  |  | 3,788 |  |  |  | 4,022 |  |
| Stock-based compensation expense included in operating expenses |  |  | 9,076 |  |  |  | 14,846 |  |  |  | 15,088 |  |
| Total stock-based compensation expense |  |  | 10,062 |  |  |  | 15,988 |  |  |  | 16,381 |  |
| Tax benefit for expense associated with stock based compensation |  |  | (1,267 | ) |  |  | (1,976 | ) |  |  | (3,837 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 8,795 |  |  | $ | 14,012 |  |  | $ | 12,544 |  |

[0001193125-26-073878:notes:151]
PSUs, RSUs and Restricted stock

[0001193125-26-073878:notes:152]
The following table summarizes the activity related to our PSUs, RSUs and restricted stock for the year ended December 31, 2025:

[0001193125-26-073878:notes:153]
|  |  | Number ofshares (In thousands) |  |  | WeightedAverage GrantDate Fair Value(Per Share) |  |
| Unvested PSUs, RSUs and restricted stock outstanding, December 31, 2024 |  |  | 2,335 |  |  | $ | 13.22 |  |
| PSUs, RSUs and restricted stock granted |  |  | 1,308 |  |  | $ | 10.33 |  |
| PSUs, RSUs and restricted stock vested |  |  | (572 | ) |  | $ | 12.70 |  |
| PSUs, RSUs and restricted stock forfeited |  |  | (1,104 | ) |  | $ | 13.87 |  |
| Unvested PSUs, RSUs and restricted stock outstanding, December 31, 2025 |  |  | 1,967 |  |  | $ | 10.70 |  |

[0001193125-26-073878:notes:154]
The fair value of PSUs with performance conditions, RSUs and restricted stock is equal to the closing price of the Company's stock on the date of grant. The fair value of PSUs with market conditions is calculated using a Monte Carlo simulation valuation method.

[0001193125-26-073878:notes:155]
The following table details the significant assumptions that impact the fair value estimate of the market-based PSUs:

[0001193125-26-073878:notes:156]
|  |  | 2025 |  |  | 2024 |  |  | 2023 |  |
| Estimated fair value per share |  | $ | 12.32 |  |  | $ | 8.29 |  |  | $ | 19.26 |  |
| Expected volatility |  |  | 55.09 | % |  |  | 51.34 | % |  |  | 51.52 | % |
| Risk-free interest rate |  |  | 4.22 | % |  |  | 4.12 | % |  |  | 3.93 | % |
| Expected dividend yield |  |  | — |  |  |  | — |  |  |  | 2.55 | % |

[0001193125-26-073878:notes:157]
For market-based PSUs, the number of shares of common stock earned by a recipient is subject to a market condition based on Adtran’s relative total stockholder return against all companies in the NASDAQ Telecommunications Index at the end of a three-year performance period. Depending on the relative total stockholder return over the performance period, the recipient may earn from 0% to 150% of the shares underlying the PSUs, with the shares earned distributed upon the vesting. The fair value of the award is based on the market price of our common stock on the date of grant, adjusted for the expected outcome of the impact of market conditions using a Monte Carlo Simulation valuation method. A portion of the granted PSUs vests and the underlying shares become deliverable upon the death or disability of the recipient or upon a change of control of Adtran, as defined by the 2020 Employee Plan. The recipients of the PSUs receive dividend credits based on the shares of common stock underlying the PSUs. The dividend credits vest and are earned in the same manner as the PSUs and are paid in cash upon the issuance of common stock for the PSUs.

[0001193125-26-073878:notes:158]
The fair value of RSUs and restricted stock is equal to the closing price of our stock on the grant date. RSUs and restricted stock vest ratably over four-year and one-year periods, respectively.

[0001193125-26-073878:notes:159]
We will continue to assess the assumptions and methodologies used to calculate the estimated fair value of stock-based compensation. If circumstances change, and additional data becomes available over time, we may change our assumptions and methodologies, which may materially impact our fair value determination.

[0001193125-26-073878:notes:160]
As of December 31, 2025, total unrecognized compensation expense related to the non-vested portion of market-based PSUs, RSUs and restricted stock was approximately $13.1 million, which is expected to be recognized over an average remaining recognition period of 2.4 years. Unrecognized compensation expense will be adjusted for actual forfeitures as they occur.

[0001193125-26-073878:notes:161]
Stock Options

[0001193125-26-073878:notes:162]
The following table summarizes the activity related to our stock options for the year ended December 31, 2025:

[0001193125-26-073878:notes:163]
|  |  | Number ofOptions(In thousands) |  |  | WeightedAverageExercise Price(Per share) |  |  | Weighted AverageRemainingContractual Lifein Years |  |  | AggregateIntrinsic Value(In thousands) |  |
| Stock options outstanding, December 31, 2024 |  |  | 2,944 |  |  | $ | 9.86 |  |  |  | 4.98 |  |  | $ | 3,762 |  |
| Stock options exercised |  |  | (273 | ) |  | $ | 6.70 |  |  |  |  |  |  |  |
| Stock options forfeited |  |  | (233 | ) |  | $ | 14.65 |  |  |  |  |  |  |  |
| Stock options expired |  |  | (426 | ) |  | $ | 14.01 |  |  |  |  |  |  |  |
| Stock options outstanding, December 31, 2025 |  |  | 2,012 |  |  | $ | 8.86 |  |  |  | 4.81 |  |  | $ | 3,559 |  |
| Stock options exercisable, December 31, 2025 |  |  | 1,828 |  |  | $ | 7.83 |  |  |  | 4.95 |  |  | $ | 3,559 |  |

[0001193125-26-073878:notes:164]
As of December 31, 2025, there was $0.1 million of unrecognized compensation expense related to stock options which will be recognized over the remaining weighted-average period of 0.4 years. No stock options were granted during 2025.

[0001193125-26-073878:notes:165]
The determination of the fair value of stock options was estimated using the Monte Carlo method and is affected by the historical volatility of its stock price, as well as assumptions regarding a number of complex and subjective variables that may have a significant impact on the fair value estimate. The stock option pricing model requires the use of several assumptions that impact the fair value estimate. These variables include, but are not limited to, the volatility of the Company's stock price and employee exercise behaviors.

[0001193125-26-073878:notes:166]
All of the options were previously issued at exercise prices that approximated fair market value at the date of grant.

[0001193125-26-073878:notes:167]
The aggregate intrinsic value of stock options represents the total pre-tax intrinsic value (the difference between the Company's closing stock price on the last trading day of the quarter and the exercise price, multiplied by the number of in-the-money options) that would have been received by the option holders had all option holders exercised their options on December 31, 2025. The amount of aggregate intrinsic value was $3.6 million as of December 31, 2025, which will change based on the fair market value of the Company's stock. The total pre-tax intrinsic value of options exercised during the years ended December 31, 2025 and 2024 was $0.8 million and $0.3 million, respectively.

[0001193125-26-073878:notes:168]
The following table further describes our stock options outstanding as of December 31, 2025:

[0001193125-26-073878:notes:169]
|  |  | Options Outstanding |  |  | Options Exercisable |  |
| Range ofExercise Prices (Per Share) |  | OptionsOutstanding atDecember 31, 2025(In thousands) |  |  | Weighted AverageRemainingContractual Lifein Years |  |  | WeightedAverageExercise Price(Per Share) |  |  | OptionsExercisable atDecember 31, 2025(In thousands) |  |  | WeightedAverageExercisePrice |  |
| $5.23 – $5.23 |  |  | 959 |  |  |  | 7.83 |  |  | $ | 5.23 |  |  |  | 959 |  |  | $ | 5.23 |  |
| $5.24 – $8.58 |  |  | 329 |  |  |  | 1.07 |  |  | $ | 7.95 |  |  |  | 329 |  |  | $ | 7.95 |  |
| $8.59 – $12.17 |  |  | 496 |  |  |  | 2.02 |  |  | $ | 12.10 |  |  |  | 496 |  |  | $ | 12.10 |  |
| $12.18 – $19.08 |  |  | 228 |  |  |  | 3.27 |  |  | $ | 18.34 |  |  |  | 44 |  |  | $ | 15.31 |  |
|  |  |  | 2,012 |  |  |  |  |  |  |  |  |  | 1,828 |  |  |  |  |

[0001193125-26-073878:notes:170]
The Black-Scholes option pricing model (the “Black-Scholes Model”) is used to determine the estimated fair value of stock option awards on the date of grant. The Black-Scholes Model requires the input of certain assumptions that involve judgment. Because our stock options have characteristics significantly different from those of traded options, and because changes in the input assumptions can materially affect the fair value estimate, existing models may not provide reliable measures of fair value of our stock options. The stock option pricing model requires the use of several assumptions that impact the fair value estimate. These variables include, but are not limited to, the volatility of our stock price and employee exercise behaviors.

[0001193125-26-073878:notes:171]
The stock option pricing model requires the use of several assumptions that impact the fair value estimate. These variables include, but are not limited to, the volatility of our stock price and employee exercise behaviors.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001193125-26-073878:notes:172]
Note 4 – Investments

[0001193125-26-073878:notes:173]
The Company’s cash equivalents and investments held at fair value are categorized into this hierarchy as follows:

[0001193125-26-073878:notes:174]
|  |  |  | Fair Value Measurements as of December 31, 2025 Using |  |
| (In thousands) | Classification |  | Fair Value |  |  | Quoted Pricesin ActiveMarket for IdenticalAssets (Level 1) |  |  | SignificantOtherObservableInputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | Cash and cash equivalents |  | $ | 245 |  |  | $ | 245 |  |  | $ | — |  |  | $ | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities - various industries | Long-term investments |  |  | 1,022 |  |  |  | 1,022 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets | Short-term investments - deferred compensation |  |  | 35,174 |  |  |  | 35,174 |  |  |  | — |  |  |  | — |  |
| Total |  |  | $ | 36,441 |  |  | $ | 36,441 |  |  | $ | — |  |  | $ | — |  |

[0001193125-26-073878:notes:175]
|  |  |  | Fair Value Measurements as of December 31, 2024 Using |  |
| (In thousands) | Classification |  | Fair Value |  |  | Quoted Pricesin ActiveMarket for IdenticalAssets (Level 1) |  |  | SignificantOtherObservableInputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds | Cash and cash equivalents |  | $ | 5,538 |  |  | $ | 5,538 |  |  | $ | — |  |  | $ | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities - various industries | Long-term investments |  |  | 1,068 |  |  |  | 1,068 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets | Long-term investments |  |  | 30,991 |  |  |  | 30,991 |  |  |  | — |  |  |  | — |  |
| Total |  |  | $ | 37,597 |  |  | $ | 37,597 |  |  | $ | — |  |  | $ | — |  |

[0001193125-26-073878:notes:176]
Market prices are obtained from a variety of industry standard data providers, large financial institutions and other third-party sources. These multiple market prices are used as inputs into a distribution-curve-based algorithm to determine the daily market value of each security.

[0001193125-26-073878:notes:177]
U.S. GAAP establishes a three-level valuation hierarchy based upon observable and unobservable inputs for fair value measurement of financial instruments:

[0001193125-26-073878:notes:178]
•
Level 1 – Observable outputs; values based on unadjusted quoted prices for identical assets or liabilities in an active market;

[0001193125-26-073878:notes:179]
•
Level 2 – Significant inputs that are observable; values based on quoted prices in markets that are not active or model inputs that are observable either directly or indirectly;

[0001193125-26-073878:notes:180]
•
Level 3 – Significant unobservable inputs; values based on prices or valuation techniques that require inputs that are both unobservable and significant to the overall fair value measurement; inputs could include information supplied by investees.


## us-gaap:InventoryDisclosureTextBlock

[0001193125-26-073878:notes:181]
Note 5 – Inventory

[0001193125-26-073878:notes:182]
As of December 31, 2025 and 2024, inventory, net was comprised of the following:

[0001193125-26-073878:notes:183]
| (In thousands) |  | 2025 |  |  | 2024 |  |
| Raw materials |  | $ | 78,230 |  |  | $ | 106,384 |  |
| Work in process |  |  | 12,801 |  |  |  | 9,724 |  |
| Finished goods |  |  | 124,705 |  |  |  | 145,449 |  |
| Total Inventory, net |  | $ | 215,736 |  |  | $ | 261,557 |  |

[0001193125-26-073878:notes:184]
Inventory reserves are established for estimated excess and obsolete inventory equal to the difference between the cost of the inventory and the estimated net realizable value of the inventory based on estimated reserve percentages, which consider historical usage, known trends, inventory age and market conditions.

[0001193125-26-073878:notes:185]
During the year ended December 31, 2024, the company recorded an inventory write-down of $8.6 million, as a result of a strategy shift which included discontinuance of certain product lines in connection with the Business Efficiency Program of which $4.1 million relates to inventory write-downs and $4.5 million relates to other charges all of which are included in cost of revenue in the Consolidated Statements of Loss. In connection with the Company’s restructuring efforts, during the year ended December 31, 2023, management determined that there would be a discontinuation of product lines in the Network solutions segment and, as a result, wrote-down related inventories of $24.3 million, which is included in cost of revenue in the Consolidated Statements of Loss.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001193125-26-073878:notes:186]
Note 6 – Property, Plant and Equipment, net

[0001193125-26-073878:notes:187]
As of December 31, 2025 and 2024, property, plant and equipment, net was comprised of the following:

[0001193125-26-073878:notes:188]
| (In thousands) |  | 2025 |  |  | 2024 |  |
| Engineering and other equipment |  | $ | 131,665 |  |  | $ | 184,694 |  |
| Building |  |  | 52,586 |  |  |  | 50,871 |  |
| Computer hardware and software |  |  | 109,703 |  |  |  | 113,241 |  |
| Building and land improvements |  |  | 43,271 |  |  |  | 39,979 |  |
| Furniture and fixtures |  |  | 19,287 |  |  |  | 20,994 |  |
| Land |  |  | 3,073 |  |  |  | 2,989 |  |
| Total Property, Plant and Equipment |  |  | 359,585 |  |  |  | 412,768 |  |
| Less: accumulated depreciation |  |  | (235,201 | ) |  |  | (306,314 | ) |
| Total Property, Plant and Equipment, net |  | $ | 124,384 |  |  | $ | 106,454 |  |

[0001193125-26-073878:notes:189]
Long-lived assets used in operations are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable and the undiscounted cash flows estimated to be generated by the asset are less than the asset’s carrying value. During the years ended December 31, 2025 and 2024, no impairment charges were recognized.

[0001193125-26-073878:notes:190]
Depreciation expense was $30.3 million, $27.7 million and $30.2 million for the years ended December 31, 2025, 2024 and 2023, respectively, which is recorded in cost of revenue, selling, general and administrative expenses and research and development expenses in the Consolidated Statements of Loss.

[0001193125-26-073878:notes:191]
Assets Held For Sale

[0001193125-26-073878:notes:192]
On December 31, 2025, the Company determined that it continues to meet the held for sale criteria pursuant to ASC 360, "Impairment and Disposal of Long-Live Assets" on a portion of the Company's property located at its Huntsville, Alabama campus and ceased recording depreciation on the assets. The Company continues to assess the probability that the sale of its headquarters in Huntsville will occur and has determined it is probable of occurring in the next twelve months.

[0001193125-26-073878:notes:193]
The total carrying value of assets held for sale was $11.9 million as of December 31, 2025 and 2024 and is separately recorded on the balance sheet.


## us-gaap:LessorSalesTypeLeasesTextBlock

[0001193125-26-073878:notes:194]
Note 7 – Leases

[0001193125-26-073878:notes:195]
We have operating leases for office space, automobiles and various other equipment in the U.S. and in certain international locations. As of December 31, 2025, our operating leases had remaining lease terms of 1 month to 155 months, some of which included options to extend the leases for up to one year, and some of which included options to terminate the leases within three months. Supplemental balance sheet information related to operating leases is as follows:

[0001193125-26-073878:notes:196]
|  |  |  |  | December 31, |  |  | December 31, |  |
| (In thousands) |  | Classification |  | 2025 |  |  | 2024 |  |
| Assets |  |  |  |  |  |  |  |  |
| Operating lease assets |  | Other non-current assets |  | $ | 32,072 |  |  | $ | 30,342 |  |
| Total lease asset |  |  |  | $ | 32,072 |  |  | $ | 30,342 |  |
| Liabilities |  |  |  |  |  |  |  |  |
| Current operating lease liability |  | Accrued expenses and other liabilities |  | $ | 7,092 |  |  | $ | 7,154 |  |
| Non-current lease obligations |  | Non-current lease obligations |  |  | 27,000 |  |  |  | 25,925 |  |
| Total lease liability |  |  |  | $ | 34,092 |  |  | $ | 33,079 |  |

[0001193125-26-073878:notes:197]
Lease expense related to short-term leases was approximately $0.1 million, $0.2 million and $0.1 million for the years ended December 31, 2025, 2024 and 2023, respectively, and is included in cost of revenue, selling, general and administrative expenses and research and development expenses in the Consolidated Statements of Loss. Lease expense related to variable lease payments that do not depend on an index or rate, such as real estate taxes and insurance reimbursements, was $0.1 million, $0.3 million and $0.7 million for the year ended December 31, 2025, 2024 and 2023, respectively.

[0001193125-26-073878:notes:198]
The components of lease expense included in the Consolidated Statements of Loss were as follows:

[0001193125-26-073878:notes:199]
|  |  | For the Year Ended December 31, |  |
| (In thousands) |  | 2025 |  |  | 2024 |  |  | 2023 |  |
| Cost of revenue |  | $ | 40 |  |  | $ | 150 |  |  | $ | 163 |  |
| Research and development expenses |  |  | 51 |  |  |  | 412 |  |  |  | 990 |  |
| Selling, general and administrative expenses |  |  | 9,674 |  |  |  | 9,213 |  |  |  | 9,708 |  |
| Total operating lease expense |  | $ | 9,765 |  |  | $ | 9,775 |  |  | $ | 10,861 |  |

[0001193125-26-073878:notes:200]
As of December 31, 2025, operating lease liabilities by future maturity, included on the Consolidated Balance Sheet were as follows:

[0001193125-26-073878:notes:201]
| (In thousands) |  | Amount |  |
| 2026 |  | $ | 9,395 |  |
| 2027 |  |  | 8,376 |  |
| 2028 |  |  | 7,885 |  |
| 2029 |  |  | 3,884 |  |
| 2030 |  |  | 3,236 |  |
| Thereafter |  |  | 10,648 |  |
| Total lease payments |  | $ | 43,424 |  |
| Less: Interest |  |  | (9,332 | ) |
| Present value of lease liabilities |  | $ | 34,092 |  |

[0001193125-26-073878:notes:202]
Future operating lease payments include $6.4 million related to options to extend lease terms that are reasonably certain of being exercised. There are no legally binding leases that have not yet commenced.

[0001193125-26-073878:notes:203]
An incremental borrowing rate is used based on information available at the commencement date in determining the present value of lease payments. The incremental borrowing rate is determined on a portfolio basis by grouping leases with similar terms, as well as grouping leases based on a U.S. dollar or euro functional currency. The following table provides information about our weighted average lease terms and weighted average discount rates:

[0001193125-26-073878:notes:204]
|  |  | As of December 31, |  |
| Weighted average remaining lease term (years) |  | 2025 |  |  | 2024 |  |
| Operating leases with USD functional currency |  |  | 6.8 |  |  |  | 7.3 |  |
| Operating leases with EUR functional currency |  |  | 6.5 |  |  |  | 5.9 |  |
| Weighted average discount rate |  |  |  |  |  |  |
| Operating leases with USD functional currency |  |  | 3.90 | % |  |  | 3.64 | % |
| Operating leases with EUR functional currency |  |  | 7.11 | % |  |  | 4.50 | % |


## us-gaap:GoodwillDisclosureTextBlock

[0001193125-26-073878:notes:205]
Note 8 – Goodwill

[0001193125-26-073878:notes:206]
The changes in the carrying amount of goodwill for the year ended December 31, 2025 and December 31, 2024 are as follows:

[0001193125-26-073878:notes:207]
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| As of December 31, 2023 |  | $ | 301,766 |  |  | $ | 56,384 |  |  | $ | 358,150 |  |
| Goodwill impairment |  |  | (295,298 | ) |  |  | — |  |  |  | (295,298 | ) |
| Foreign currency translation adjustments |  |  | (6,468 | ) |  |  | (3,466 | ) |  |  | (9,934 | ) |
| As of December 31, 2024 |  | $ | — |  |  | $ | 52,918 |  |  | $ | 52,918 |  |
| Foreign currency translation adjustments |  |  | — |  |  |  | 7,065 |  |  |  | 7,065 |  |
| As of December 31, 2025 |  | $ | — |  |  | $ | 59,983 |  |  | $ | 59,983 |  |

[0001193125-26-073878:notes:208]
The Company’s annual impairment test date was October 1, 2025. Based on our analysis, management concluded that there was no impairment of goodwill as of that date. Between the annual impairment date of October 1, 2025 and year-end December 31, 2025, there were no triggering events.

[0001193125-26-073878:notes:209]
During the first quarter of 2024, qualitative factors such as a decrease in the Company’s market capitalization, lower service provider spending and delayed holding patterns of inventory with respect to customers caused us to reduce our forecasts, triggering a quantitative impairment assessment for our reporting units. The Company determined the fair value of each reporting unit using a combination of an income approach and a market approach. The significant inputs and assumptions used in the determination of the fair value of our reporting units, based on future cash flows for the reporting units, requires significant judgment and the use of estimates and assumptions related to revenue growth rates, earnings before interest, taxes, depreciation and amortization ("EBITDA") margins, discount rate, peer group determination, revenue and EBITDA market multiple. The Company determined upon its quantitative impairment assessment to recognize a $297.4 million non-cash goodwill impairment charge for the Network Solutions reporting unit. The quantitative impairment analysis indicated there was no impairment of the Services & Support goodwill during the first quarter of 2024.

[0001193125-26-073878:notes:210]
The gross amount of accumulated goodwill impairment losses as of December 31, 2025 and 2024 total $297.4 million for our Network Solutions reporting unit and $37.9 million for our Services & Support reporting unit.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001193125-26-073878:notes:211]
Note 9 – Intangible Assets, net

[0001193125-26-073878:notes:212]
Intangible assets as of December 31, 2025 and 2024, consisted of the following:

[0001193125-26-073878:notes:213]
|  |  |  |  | 2025 |  |  | 2024 |  |
| (In thousands) | Weighted Average Useful Life(in years) |  |  | Gross Value |  |  | AccumulatedAmortization |  |  | Net Value |  |  | Gross Value |  |  | AccumulatedAmortization |  |  | Net Value |  |
| Customer relationships |  | 11.0 |  |  | $ | 56,244 |  |  | $ | (25,306 | ) |  | $ | 30,938 |  |  | $ | 51,165 |  |  | $ | (18,778 | ) |  | $ | 32,387 |  |
| Backlog |  | 1.7 |  |  |  | 61,081 |  |  |  | (61,081 | ) |  |  | — |  |  |  | 53,839 |  |  |  | (52,258 | ) |  |  | 1,581 |  |
| Developed technology |  | 7.5 |  |  |  | 429,329 |  |  |  | (168,073 | ) |  |  | 261,256 |  |  |  | 346,923 |  |  |  | (99,588 | ) |  |  | 247,335 |  |
| Licensed technology |  | 9.0 |  |  |  | 5,900 |  |  |  | (5,108 | ) |  |  | 792 |  |  |  | 5,900 |  |  |  | (4,452 | ) |  |  | 1,448 |  |
| Licensing agreements |  | 8.5 |  |  |  | 560 |  |  |  | (446 | ) |  |  | 114 |  |  |  | 560 |  |  |  | (407 | ) |  |  | 153 |  |
| Trade names |  | 2.8 |  |  |  | 31,598 |  |  |  | (30,651 | ) |  |  | 947 |  |  |  | 27,851 |  |  |  | (25,862 | ) |  |  | 1,989 |  |
| Total |  |  |  | $ | 584,712 |  |  | $ | (290,665 | ) |  | $ | 294,047 |  |  | $ | 486,238 |  |  | $ | (201,345 | ) |  | $ | 284,893 |  |

[0001193125-26-073878:notes:214]
Intangible assets are reviewed for impairment whenever events and circumstances indicate impairment may have occurred. During the first quarter of 2024, qualitative factors such as a decrease in the Company’s market capitalization, cautious service provider spending due to economic uncertainty and continued customer inventory adjustments triggered a quantitative reassessment of our estimated future undiscounted cash flows for the Network Solutions asset group. The significant inputs and assumptions used in the determination of the cash flows expected to be generated by the asset group, requires significant judgment and the use of estimates and assumptions related to revenue growth rates, EBITDA margins, peer group determination, and disposition exit multiple. The Company determined that our estimated future undiscounted cash flows exceeded the carrying value of our asset groups. No impairment losses of intangible assets were recorded during the years ended December 31, 2025, 2024 and 2023.

[0001193125-26-073878:notes:215]
During the year ended December 31, 2025, the Company acquired $38.8 million of developed technology assets with a weighted average amortization period of three years and with no expected residual value.

[0001193125-26-073878:notes:216]
Amortization expense was $62.9 million, $63.0 million and $82.8 million for the years ended December 31, 2025, 2024 and 2023, respectively, and was included in cost of revenue, selling, general and administrative expenses and research and development expenses in the Consolidated Statements of Loss.

[0001193125-26-073878:notes:217]
As of December 31, 2025, estimated future amortization expense of intangible assets was as follows:

[0001193125-26-073878:notes:218]
|  |  | As of |  |
| (In thousands) |  | December 31, 2025 |  |
| 2026 |  | $ | 68,285 |  |
| 2027 |  |  | 63,081 |  |
| 2028 |  |  | 54,148 |  |
| 2029 |  |  | 47,084 |  |
| 2030 |  |  | 45,249 |  |
| Thereafter |  |  | 16,200 |  |
| Total |  | $ | 294,047 |  |


## us-gaap:DebtDisclosureTextBlock

[0001193125-26-073878:notes:219]
Note 10 – Credit Agreement

[0001193125-26-073878:notes:220]
The carrying amounts of the Company's revolving credit agreement in its Consolidated Balance Sheets were as follows:

[0001193125-26-073878:notes:221]
|  |  | As of December 31, |  |
| (In thousands) |  | 2025 |  |  | 2024 |  |
| Wells Fargo credit agreement |  | $ | 25,000 |  |  | $ | 189,576 |  |
| Total non-current revolving credit facility |  | $ | 25,000 |  |  | $ | 189,576 |  |

[0001193125-26-073878:notes:222]
As of December 31, 2025 and 2024, the estimated fair value of our revolving credit agreement, approximates the carrying value. As of December 31, 2025 and 2024, the weighted average interest rate on our revolving credit agreement was 8.98% and 8.64%, respectively.

[0001193125-26-073878:notes:223]
Revolving Credit Agreement

[0001193125-26-073878:notes:224]
On July 18, 2022, ADTRAN, Inc., as the borrower ("U.S. Borrower"), and the Company entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (the “Original Credit Agreement”), as amended by the First Amendment to Credit Agreement, dated August 9, 2023 (“Amendment No. 1”), the Second Amendment to Credit Agreement, dated January 16, 2024 (“Amendment No. 2”), the Third Amendment to Credit Agreement, dated March 12, 2024 (“Amendment No. 3”), the Fourth Amendment to Credit Amendment, dated June 4, 2024 among Adtran Networks (the "German Borrower") and the parties set forth above ("Amendment No. 4") and the Fifth Amendment to Credit Agreement and Waiver, dated May 6, 2025, among the German Borrower and the parties set forth above (“Amendment No. 5”; the Original Credit Agreement as amended by Amendment No. 1, Amendment No. 2. Amendment No. 3, Amendment No. 4 and Amendment No. 5, the “Existing Credit Agreement”).

[0001193125-26-073878:notes:225]
On September 16, 2025, the U.S. Borrower, the German Borrower, and the lenders party thereto, including the Administrative Agent, entered into the Sixth Amendment and Consent to Credit Agreement, dated September 16, 2025 (“Amendment No. 6”; the Existing Credit Agreement as amended by Amendment No. 6, the “Amended Credit Agreement”). Amendment No. 6, among other things, (i) provides for a consent from the lenders to the issuance by the Company of new unsecured convertible indebtedness in an amount not to exceed $230.0 million, notwithstanding the cap on the amount of Permitted Convertible Indebtedness (as defined in the Amended Credit Agreement) the Company is permitted to incur, (ii) requires that the net cash proceeds of the new unsecured convertible indebtedness be used to (a) repay outstanding revolving credit loans under the Amended Credit Agreement, (b) pay fees, costs, and expenses related to Amendment No. 6 and the issuance of the new unsecured convertible indebtedness and (c) cash collateralize the obligations of the Company and its subsidiaries under the Amended Credit Agreement (with such cash only being permitted to be withdrawn for the purpose of financing the purchase of additional outstanding shares of Equity Interests (as defined in the Amended Credit Agreement) of the German Borrower that were not owned by the Company and its subsidiaries as of August 9, 2023 pursuant to Section 5, paragraph 1 of the DPLTA), and (iii) after the prepayment contemplated in the foregoing clause (ii)(a) and the provision of cash collateral contemplated in the foregoing clause (ii)(c), amends provisions governing the Subline (as defined below) to provide that future prepayments in respect of borrowings under the Subline will no longer permanently reduce the commitments in respect of the Subline.

[0001193125-26-073878:notes:226]
As of December 31, 2025, the Amended Credit Agreement provided for a secured revolving credit facility of up to $350.0 million of borrowings, $50.0 million of which is solely available to the German Borrower.

[0001193125-26-073878:notes:227]
As of December 31, 2025, the Company’s borrowings under the revolving line of credit were $25.0 million. The credit facilities provided under the Amended Credit Agreement mature in July 2027, but the U.S. Borrower may request extensions subject to customary conditions. In addition, the U.S. Borrower may utilize up to $50.0 million of the $350.0 million total revolving facility for the issuance of letters of credit. As of December 31, 2025, the U.S. Borrower had a total of $5.8 million in letters of credit under the Amended Credit Agreement, leaving a net amount (after giving effect to the $25.0 million of outstanding borrowings described above) of $319.2 million available for future borrowings, based on debt covenant compliance metrics. Any future credit extensions under the Amended Credit Agreement are subject to customary conditions precedent. The proceeds of any loans may be used as described above, as well as for working capital and other general corporate purposes.

[0001193125-26-073878:notes:228]
Moreover, the Amended Credit Agreement provides for a sublimit under the existing $350.0 million revolving commitments in an aggregate amount of $50.0 million (“Subline”), which Subline is available for borrowings by the German Borrower. The Company had no borrowings under the Subline as of December 31, 2025. The existing swing line sublimit and letter of credit sublimit under the Amended Credit Agreement remain available to the U.S. Borrower (and not to the German Borrower). Otherwise, the loans under the Subline are subject to substantially the same terms and conditions under the Amended Credit Agreement (including with respect to the interest rate and maturity date) as the other existing revolving commitments.

[0001193125-26-073878:notes:229]
All U.S. borrowings under the Amended Credit Agreement bear interest at a rate tied to the Base Rate (as defined in the Amended Credit Agreement) or SOFR, at the Company’s option, and all E.U. borrowings bear interest at a rate tied to the Euro Interbank Offered Rate as administered by the European Money Markets Institute (or a comparable or successor administrator approved by the Administrative Agent), in each case plus applicable margins which vary based on the consolidated net leverage ratio of the Company and its subsidiaries as determined pursuant to the terms of the Amended Credit Agreement. Default interest is 2.00% per annum in excess of the rate otherwise applicable.

[0001193125-26-073878:notes:230]
The Company made certain representations and warranties to the lenders in the Amended Credit Agreement that are customary for credit arrangements of this type. The Company also agreed to maintain a Consolidated Total Net Leverage Ratio of 5.00x, a Consolidated Senior Secured Net Leverage Ratio of 3.25x (4.0x to 3.5x during a “Springing Covenant Period,” as defined below) and a Consolidated Fixed Charge Coverage Ratio of 1.25x (as such ratios are defined in the Amended Credit Agreement). A “Springing Covenant Event” occurs when at least sixty percent (60.0%) of the outstanding shares of Adtran Networks that were not owned by the Company and its subsidiaries as of August 9, 2023 have been tendered and purchased by the Company. Upon the occurrence of a Springing Covenant Event, the Company will enter a “Springing Covenant Period”, defined as the fiscal quarter in which a Springing Covenant Event occurs and the three (3) consecutive fiscal quarters thereafter. During a Springing Covenant Period, the Company’s leverage ratios are increased. In addition, the cash and cash equivalents of the credit parties must be at least $50.0 million and the cash and cash equivalents of the Company and its subsidiaries must be at least $70.0 million. As of December 31, 2025, the Company was in compliance with all covenants under the Credit Agreement.

[0001193125-26-073878:notes:231]
The Amended Credit Agreement also contains customary events of default, such as misrepresentation and a default in the performance or observance of any covenant (subject to customary cure periods and materiality thresholds). Upon the occurrence and during the continuance of an event of default, the Administrative Agent is entitled to take various actions, including the acceleration of all amounts due under the Amended Credit Agreement.

[0001193125-26-073878:notes:232]
All obligations under the Amended Credit Agreement (including under the Subline) are guaranteed by the U.S. Borrower and certain subsidiaries of the U.S. Borrower (“Full Facility Guarantors”). To secure such guarantees, the U.S. Borrower and the Full Facility Guarantors have granted security interests in favor of the Administrative Agent over substantially all of their tangible and intangible assets, and the U.S. Borrower has granted mortgages in favor of the Administrative Agent over certain owned real estate assets. Certain of the German Borrower's subsidiaries (the “Subline Guarantors”) have also provided a guarantee solely of the obligations in respect of the Subline. Furthermore, to secure such guarantees, the German Borrower and the Subline Guarantors have granted security interests in favor of the Administrative Agent over substantially all of their tangible and intangible assets. Upon repayment in full and termination of the Subline, the guarantees by the Subline Guarantors and the liens granted by the German Borrower and the Subline Guarantors to secure obligations under the Subline will be released.


## us-gaap:LongTermDebtTextBlock

[0001193125-26-073878:notes:233]
Note 11 – Convertible Senior Notes and Capped Calls

[0001193125-26-073878:notes:234]
The outstanding principal and carrying value of the convertible senior notes were as follows:

[0001193125-26-073878:notes:235]
|  |  | As of |  |
| (In thousands) |  | December 31, 2025 |  |
| Convertible senior notes |  | $ | 201,250 |  |
| Less: unamortized debt issuance costs |  |  | (8,212 | ) |
| Non-current convertible senior notes, net of debt issuance costs |  | $ | 193,038 |  |

[0001193125-26-073878:notes:236]
The estimated fair value of the 2030 Notes was $217.5 million as of December 31, 2025. The estimated fair value of the 2030 Notes, based on Level 2 inputs of the valuation hierarchy, were determined based on the quoted bid prices of the 2030 Notes in an over-the-counter market on the last trading day of the reporting period.

[0001193125-26-073878:notes:237]
The effective interest rate of the 2030 Notes over their expected life is 4.7%. The following is a summary of interest expense for the 2030 Notes:

[0001193125-26-073878:notes:238]
|  |  | For the Year Ended |  |
| (In thousands) |  | December 31, 2025 |  |
| Contractual interest |  | $ | 2,150 |  |
| Amortization of issuance costs |  |  | 441 |  |
| Total interest expense |  | $ | 2,591 |  |

[0001193125-26-073878:notes:239]
On September 19, 2025, the Company issued $201.3 million principal amount of its 3.75% convertible senior notes due September 15, 2030. The 2030 Notes were issued pursuant to, and are governed by, an indenture (the “Indenture”), dated as of September 19, 2025, between the Company and U.S. Bank Trust Company, National Association, as trustee (the “Trustee”). The 2030 Notes are the Company’s senior, unsecured obligations and bear interest at a rate of 3.75% per year payable semi-annually in arrears on March 15 and September 15 of each year, beginning on March 15, 2026. Each $1,000 principal amount of the 2030 Notes will be convertible into 86.8206 shares of the Company’s common stock, which is equivalent to a conversion price of approximately $11.52 per share, subject to adjustment upon the occurrence of specified events. In addition, if certain corporate events that constitute a “make-whole fundamental

[0001193125-26-073878:notes:240]
change” (as defined in the Indenture) occur, then the conversion rate will, in certain circumstances, be increased for a specified period of time.

[0001193125-26-073878:notes:241]
The 2030 Notes are convertible at the option of the holders of the 2030 Notes before June 15, 2030, only under the following circumstances: (1) during any calendar quarter (and only during such calendar quarter) commencing after the calendar quarter ending on December 31, 2025, if the last reported sale price per share of the Company’s common stock exceeds 130% of the conversion price for each of at least 20 trading days, whether or not consecutive, during the 30 consecutive trading days ending on, and including, the last trading day of the immediately preceding calendar quarter; (2) during the five consecutive business days immediately after any 10 consecutive trading day period (such 10 consecutive trading day period, the “measurement period”) if the trading price per $1,000 principal amount of the 2030 Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price per share of our common stock on such trading day and the conversion rate on such trading day; (3) upon the occurrence of certain corporate events or distributions on the Company’s common stock; or (4) if the Company calls (or is deemed to have called) the 2030 Notes for redemption. From and after June 15, 2030, noteholders may convert their 2030 Notes at any time at their election until the close of business on the second scheduled trading day immediately before the maturity date. The Company will settle conversions by paying cash up to the aggregate principal amount of the 2030 Notes to be converted and paying or delivering, as applicable, cash, shares of its common stock or a combination of cash and shares of its common stock, at the Company’s election, in respect of the remainder, if any, of its conversion obligation in excess of the aggregate principal amount of the Notes being converted, based on the applicable conversion rate.

[0001193125-26-073878:notes:242]
The 2030 Notes will be redeemable, in whole or in part (subject to certain limitations described below), at the Company’s option at any time, and from time to time, on or after September 20, 2028 and on or before the 46th scheduled trading day immediately before the maturity date, but only if (i) the Notes are “Freely Tradable” (as defined in the Indenture) as of the date the Company sends the related redemption notice, and all accrued and unpaid additional interest, if any, has been paid in full as of the most recent interest payment date occurring on or before the date the Company sends the related redemption notice; and (ii) the last reported sale price per share of the Company’s common stock exceeds 130% of the conversion price on (1) each of at least 20 trading days, whether or not consecutive, during the 30 consecutive trading days ending on, and including, the trading day immediately before the date the Company sends the related redemption notice; and (2) the trading day immediately before the date the Company sends such redemption notice. However, the Company may not redeem less than all of the outstanding Notes unless at least $70.0 million aggregate principal amount of Notes are outstanding and not called for redemption as of the time the Company sends, and after giving effect to, the related redemption notice. The redemption price will be a cash amount equal to the principal amount of the Notes to be redeemed, plus accrued and unpaid interest, if any, to, but excluding, the redemption date. In addition, calling (or the deemed calling of) any Note for redemption will constitute a “make-whole fundamental change” with respect to that Note, in which case the conversion rate applicable to the conversion of that Note will be increased in certain circumstances if it is converted during the related redemption conversion period. No sinking fund is provided for the 2030 Notes, which means the Company is not required to redeem or retire the 2030 Notes periodically.

[0001193125-26-073878:notes:243]
If certain corporate events that constitute a “fundamental change” (as defined in the Indenture) occur, then, subject to a limited exception for certain cash mergers, noteholders may require the Company to repurchase their Notes at a cash repurchase price equal to the principal amount of the Notes to be repurchased, plus accrued and unpaid interest, if any, to, but excluding, the fundamental change repurchase date. The definition of “fundamental change” includes certain business combination transactions involving the Company and certain de-listing events with respect to the Company’s common stock.

[0001193125-26-073878:notes:244]
Capped Calls

[0001193125-26-073878:notes:245]
In connection with the pricing of the 2030 Notes and the exercise of the initial purchasers’ option to purchase additional 2030 Notes, the Company entered into privately negotiated capped call transactions with one of the initial purchasers of the 2030 Notes or its affiliate and certain other financial institutions pursuant to capped call confirmations (collectively, the “Capped Calls”). The premiums paid for the purchases of the Capped Calls were approximately $17.6 million. The Capped Calls have an initial strike price of approximately $11.52 per share, subject to certain adjustments substantially similar to those applicable to the corresponding 2030 Notes. The Capped Calls have an initial cap price of approximately $15.51 per share, subject to certain adjustments. The Capped Calls cover, subject to anti-dilution adjustments, approximately 17.5 million shares of the Company’s common stock.

[0001193125-26-073878:notes:246]
The Capped Calls are generally expected to reduce potential dilution to the Company’s common stock and/or offset any cash payments that the Company is required to make in excess of the principal amount of any converted 2030 Notes, with such reduction and/or offset subject to a cap, based on the cap price of the Capped Calls.

[0001193125-26-073878:notes:247]
The Capped Calls are separate transactions and are not part of the terms of the 2030 Notes. The Capped Calls do not meet the criteria for separate accounting as a derivative as they are indexed to the Company's stock and meet the requirements to be classified in equity and, as such, are not remeasured each reporting period. The premiums paid for the Capped Calls were included as a net reduction to additional paid-in capital within stockholders’ equity during the year ended December 31, 2025.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-26-073878:notes:248]
Note 12 – Income Taxes

[0001193125-26-073878:notes:249]
The components of income tax expense for the years ended December 31, 2025, 2024 and 2023 are as follows:

[0001193125-26-073878:notes:250]
| (In thousands) |  | 2025 |  |  | 2024 |  |  | 2023 |  |
| Current |  |  |  |  |  |  |  |  |  |
| Federal |  | $ | 1,042 |  |  | $ | (1,456 | ) |  | $ | 2,545 |  |
| State |  |  | 458 |  |  |  | 575 |  |  |  | 26 |  |
| International |  |  | 7,340 |  |  |  | 2,645 |  |  |  | 10,004 |  |
| Total Current |  |  | 8,840 |  |  |  | 1,764 |  |  |  | 12,575 |  |
| Deferred |  |  |  |  |  |  |  |  |  |
| Federal |  |  | 142 |  |  |  | 357 |  |  |  | 46,672 |  |
| State |  |  | 17 |  |  |  | (405 | ) |  |  | 6,607 |  |
| International |  |  | (4,006 | ) |  |  | 5,624 |  |  |  | (37,555 | ) |
| Total Deferred |  |  | (3,847 | ) |  |  | 5,576 |  |  |  | 15,724 |  |
| Total Income Tax Expense |  | $ | 4,993 |  |  | $ | 7,340 |  |  | $ | 28,299 |  |

[0001193125-26-073878:notes:251]
As further described in Note 1, Summary of Significant Accounting Policies, the Company has elected to prospectively adopt the guidance in ASU No. 2023-09, Income Taxes (Topic 740): Improvements to Income Taxes Disclosures, or ASU 2023-09. The following table presents the income taxes paid disaggregated by domestic, state and international taxes, with further disaggregation by jurisdiction in accordance with the guidance under ASU 2023-09.

[0001193125-26-073878:notes:252]
| (In thousands) |  | 2025 |  |
| Federal |  | $ | (436 | ) |
| State |  |  | 515 |  |
| International |  |  |  |
| United Kingdom |  |  | 1,607 |  |
| India |  |  | 977 |  |
| Poland |  |  | 618 |  |
| Germany |  |  | 497 |  |
| Other |  |  | 1,666 |  |
| Total cash paid for income taxes, (net of refunds) |  | $ | 5,444 |  |

[0001193125-26-073878:notes:253]
During the years ended, December 31, 2024 and 2023, the Company paid cash for income taxes, net of refunds, of $6.7 million and $18.6 million, respectively.

[0001193125-26-073878:notes:254]
The following table is a reconciliation of the U.S. federal statutory rate of 21% to the Company's effective rate for the year ended December 31, 2025 in accordance with the guidance in ASU 2023-09.

[0001193125-26-073878:notes:255]
|  | 2025 |  |
|  | Amount |  |  | Percentage |  |
| United States statutory tax rate | $ | (6,562 | ) |  |  | 21.0 | % |
| State and local income taxes, net of federal income tax effect (1) |  | 378 |  |  |  | (1.2 | ) |
| Foreign tax effects: |  |  |  |  |  |
| Germany |  |  |  |  |  |
| Change in valuation allowance |  | 8,899 |  |  |  | (28.5 | ) |
| Foreign rate differential |  | 2,586 |  |  |  | (8.3 | ) |
| Trade tax |  | (6,073 | ) |  |  | 19.5 |  |
| Adjustment of NOL deferred tax assets |  | 1,548 |  |  |  | (5.0 | ) |
| Adjustment of deferred tax liabilities |  | 441 |  |  |  | (1.4 | ) |
| Tax rate change |  | 385 |  |  |  | (1.2 | ) |
| Other |  | 527 |  |  |  | (1.7 | ) |
| India |  |  |  |  |  |
| Withholding tax |  | 559 |  |  |  | (1.8 | ) |
| Other |  | 61 |  |  |  | (0.2 | ) |
| United Kingdom |  |  |  |  |  |
| Audit assessment |  | 814 |  |  |  | (2.6 | ) |
| Other |  | 575 |  |  |  | (1.8 | ) |
| Other foreign jurisdictions |  | 193 |  |  |  | (0.6 | ) |
| Effect of cross-border tax laws: |  |  |  |  |  |
| Gross GILTI inclusion |  | 6,016 |  |  |  | (19.3 | ) |
| Subpart F income |  | 1,506 |  |  |  | (4.8 | ) |
| Tax credits: |  |  |  |  |  |
| R&D credit |  | (4,338 | ) |  |  | 13.9 |  |
| Changes in valuation allowances |  | (3,532 | ) |  |  | 11.3 |  |
| Nontaxable or nondeductible items: |  |  |  |  |  |
| Section 162(m) limitation |  | 488 |  |  |  | (1.6 | ) |
| Other |  | (167 | ) |  |  | 0.5 |  |
| Other adjustments: |  |  |  |  |  |
| Transfer pricing |  | 590 |  |  |  | (1.9 | ) |
| Other |  | 99 |  |  |  | (0.3 | ) |
| Effective Tax Rate | $ | 4,993 |  |  |  | -16.0 | % |

[0001193125-26-073878:notes:256]
(1) State taxes in Texas and Colorado made up the majority (greater than 50%) of the tax effect in this category.

[0001193125-26-073878:notes:257]
The following table is a reconciliation of the U.S. federal statutory tax rate of 21% to the Company's effective rate for the years ended December 31, 2024 and 2023 in accordance with the guidance prior to the adoption of ASU 2023-09.

[0001193125-26-073878:notes:258]
|  |  | 2024 |  |  | 2023 |  |
| Tax provision computed at the federal statutory rate |  |  | 21.0 | % |  |  | 21.0 | % |
| State income tax provision, net of federal benefit |  |  | 0.1 |  |  |  | 1.3 |  |
| Federal research credits |  |  | 0.7 |  |  |  | 3.2 |  |
| Foreign taxes |  |  | (0.0 | ) |  |  | 3.2 |  |
| Tax-exempt income |  |  | 0.0 |  |  |  | 0.1 |  |
| Change in valuation allowance |  |  | (6.5 | ) |  |  | (34.8 | ) |
| Foreign tax credits |  |  | 0.8 |  |  |  | 2.4 |  |
| Stock-based compensation |  |  | (0.4 | ) |  |  | (0.6 | ) |
| Withholding taxes |  |  | (0.1 | ) |  |  | 0.0 |  |
| Adtran Networks tax exempt income |  |  | 0.0 |  |  |  | 1.4 |  |
| Return to accrual |  |  | 0.6 |  |  |  | 0.6 |  |
| Global intangible low-taxed income ("GILTI") |  |  | (3.1 | ) |  |  | (5.8 | ) |
| Adtran Networks Goodwill Impairment |  |  | (13.8 | ) |  |  | (4.6 | ) |
| Other, net |  |  | (1.0 | ) |  |  | 0.4 |  |
| Effective Tax Rate |  |  | (1.7 | )% |  |  | (12.1 | )% |

[0001193125-26-073878:notes:259]
Loss before income taxes for the years ended December 31, 2025, 2024 and 2023 is as follows:

[0001193125-26-073878:notes:260]
| (In thousands) |  | 2025 |  |  | 2024 |  |  | 2023 |  |
| U.S. entities |  | $ | 2,943 |  |  | $ | (71,684 | ) |  | $ | (113,951 | ) |
| International entities |  |  | (34,193 | ) |  |  | (371,043 | ) |  |  | (119,656 | ) |
| Total |  | $ | (31,250 | ) |  | $ | (442,727 | ) |  | $ | (233,607 | ) |

[0001193125-26-073878:notes:261]
Loss before income taxes for international entities reflects loss based on statutory transfer pricing agreements. This amount does not correlate to consolidated international revenue, which occurs in our U.S. entity.

[0001193125-26-073878:notes:262]
Deferred income taxes on the Consolidated Balance Sheets result from temporary differences between the amount of assets and liabilities recognized for financial reporting and tax purposes. The significant components of current and non-current deferred taxes as of December 31, 2025 and 2024 consist of the following:

[0001193125-26-073878:notes:263]
| (In thousands) |  | 2025 |  |  | 2024 |  |
| Deferred tax assets: |  |  |  |  |  |  |
| Inventory |  | $ | 14,025 |  |  | $ | 14,121 |  |
| Accrued expenses |  |  | 5,127 |  |  |  | 845 |  |
| Deferred compensation |  |  | 7,964 |  |  |  | 7,093 |  |
| Stock-based compensation |  |  | 1,942 |  |  |  | 1,770 |  |
| Uncertain tax positions related to state taxes and related interest |  |  | — |  |  |  | 105 |  |
| Goodwill |  |  | 2,971 |  |  |  | 3,001 |  |
| Pensions |  |  | 5,534 |  |  |  | 5,121 |  |
| Foreign losses |  |  | 85,427 |  |  |  | 73,162 |  |
| State losses and credit carry-forwards |  |  | 4,919 |  |  |  | 4,901 |  |
| Federal loss and research carry-forwards |  |  | 23,409 |  |  |  | 20,874 |  |
| Lease liabilities |  |  | 5,706 |  |  |  | 6,153 |  |
| Capitalized research and development expenditures |  |  | 27,441 |  |  |  | 43,574 |  |
| Interest expense limitation |  |  | 10,821 |  |  |  | 6,815 |  |
| Valuation allowance |  |  | (124,451 | ) |  |  | (115,694 | ) |
| Total Deferred Tax Assets |  |  | 70,835 |  |  |  | 71,841 |  |
| Deferred tax liabilities: |  |  |  |  |  |  |
| Property, plant and equipment |  |  | (12,971 | ) |  |  | (8,368 | ) |
| Intellectual property |  |  | (59,750 | ) |  |  | (67,923 | ) |
| Right of use lease assets |  |  | (6,424 | ) |  |  | (6,175 | ) |
| Investments |  |  | (2,662 | ) |  |  | (1,921 | ) |
| Total Deferred Tax Liabilities |  |  | (81,807 | ) |  |  | (84,387 | ) |
| Net Deferred Tax Liabilities |  | $ | (10,972 | ) |  | $ | (12,546 | ) |

[0001193125-26-073878:notes:264]
As of December 31, 2025 and 2024, non-current deferred taxes reflected deferred taxes on net unrealized gains and losses on available-for-sale investments and deferred taxes on unrealized losses in our pension plan. The net change in non-current deferred taxes associated with these items, which resulted in a deferred tax benefit of $0.3 million and $0.2 million in 2025 and 2024, respectively, was recorded as an adjustment to other comprehensive income (loss), presented in the Consolidated Statements of Comprehensive Income (Loss).

[0001193125-26-073878:notes:265]
The Company continually reviews the adequacy of our valuation allowance and recognizes the benefits of deferred tax assets only as the reassessment indicates that it is more likely than not that the deferred tax assets will be realized in accordance with ASC 740, Income Taxes. Due to the decrease in revenue and profitability in 2023 and 2024 and all other positive and negative objective evidence considered as part of our analysis, our ability to consider other subjective evidence such as projections for future growth continues to be limited when evaluating whether our deferred tax assets will be realized. As such, the Company maintains its conclusion from 2024 that it is not more likely than not that our domestic deferred tax assets will be realized and a valuation allowance against certain domestic deferred tax assets remains through 2025. Additional valuation allowance was recorded against certain deferred tax assets on our foreign entities as not more likely than not realizable in the fourth quarter of 2024 and remains through 2025. The amount of the deferred tax assets considered realizable, however, could be adjusted in future periods in the event sufficient evidence is present to support a conclusion that it is more likely than not that all or a portion of our deferred tax assets will be realized.

[0001193125-26-073878:notes:266]
As of December 31, 2025 and 2024, the Company had gross deferred tax assets totaling $113.5 million offset by a valuation allowance totaling $124.5 million and gross deferred tax assets totaling $103.1 million offset by a valuation allowance of $115.7 million, respectively. Of the current valuation allowance, $82.5 million was established against our domestic deferred tax assets and the remaining $42.0 million is related to foreign tax assets where we lacked sufficient future source of taxable income to realize those deferred tax assets. The change in our valuation allowance for the year ending December 31, 2025 was an increase of $8.8 million. The change in the valuation allowance was primarily related to the decrease in deferred tax liabilities remaining from the step up in book basis from purchase accounting and the increase in deferred tax assets associated with net operating losses and interest expense limitation during the year.

[0001193125-26-073878:notes:267]
Supplemental balance sheet information related to deferred tax assets (liabilities) as of December 31, 2025 and 2024 were as follows:

[0001193125-26-073878:notes:268]
|  |  | December 31, 2025 |  |
| (In thousands) |  | Deferred Tax Assets (Liabilities) |  |  | Valuation Allowance |  |  | Deferred Tax Assets (Liabilities), net |  |
| Domestic |  | $ | 95,680 |  |  | $ | (82,428 | ) |  | $ | 13,252 |  |
| International |  |  | 17,799 |  |  |  | (42,023 | ) |  |  | (24,224 | ) |
| Total |  | $ | 113,479 |  |  | $ | (124,451 | ) |  | $ | (10,972 | ) |

[0001193125-26-073878:notes:269]
|  |  | December 31, 2024 |  |
| (In thousands) |  | Deferred Tax Assets (Liabilities) |  |  | Valuation Allowance |  |  | Deferred Tax Assets (Liabilities), net |  |
| Domestic |  | $ | 102,002 |  |  | $ | (87,030 | ) |  | $ | 14,972 |  |
| International |  |  | 1,146 |  |  |  | (28,664 | ) |  |  | (27,518 | ) |
| Total |  | $ | 103,148 |  |  | $ | (115,694 | ) |  | $ | (12,546 | ) |

[0001193125-26-073878:notes:270]
As of December 31, 2025 and 2024, the deferred tax assets for foreign and domestic loss carry-forwards, research and development tax credits, unamortized research and development costs and state credit carry-forwards totaled $141.2 million and $142.5 million, respectively. As of December 31, 2025, $30.1 million of these deferred tax assets will expire at various times between 2026 and 2041. The remaining deferred tax assets will either amortize through 2040 or carryforward indefinitely.

[0001193125-26-073878:notes:271]
As of December 31, 2025 and 2024, respectively, our cash and cash equivalents were $95.7 million and $76.0 million. Of these amounts, our foreign subsidiaries held cash of $87.5 million and $52.6 million, respectively, representing approximately 91% and 78% of available short-term liquidity, which is used to fund ongoing liquidity needs of these subsidiaries. As part of our restructuring plan, the Company’s assertion on being indefinitely reinvested changed in a particular jurisdiction in a previous year. The Company has a hypothetical withholding tax liability of $0.4 million as of December 31, 2025 and 2024. The Company maintains its assertion in all other jurisdictions that it is indefinitely reinvesting its funds held in foreign jurisdictions outside of the U.S., except to the extent any of these funds can be repatriated without withholding tax. However, if all of these funds were repatriated to the U.S., or used for U.S. operations, certain amounts could be subject to tax. Due to the timing and circumstances of repatriation of such earnings, if any, it is not practicable to determine the amount of funds subject to unrecognized deferred tax liability.

[0001193125-26-073878:notes:272]
During 2025, 2024 and 2023, no income tax benefit or expense was recorded for stock options exercised as an adjustment to equity.

[0001193125-26-073878:notes:273]
The change in the unrecognized income tax benefits for the years ended December 31, 2025, 2024 and 2023 were as follows:

[0001193125-26-073878:notes:274]
| (In thousands) |  | 2025 |  |  | 2024 |  |  | 2023 |  |
| Balance at beginning of period |  | $ | 252 |  |  | $ | 989 |  |  | $ | 17,885 |  |
| Increases for tax position related to: |  |  |  |  |  |  |  |  |  |
| Prior years |  |  | — |  |  |  | — |  |  |  | — |  |
| Current year |  |  | — |  |  |  | — |  |  |  | 129 |  |
| Decreases for tax positions related to: |  |  |  |  |  |  |  |  |  |
| Prior years |  |  | — |  |  |  | (121 | ) |  |  | (17,025 | ) |
| Expiration of applicable statute of limitations |  |  | — |  |  |  | (616 | ) |  |  | — |  |
| Balance at end of period |  | $ | 252 |  |  | $ | 252 |  |  | $ | 989 |  |

[0001193125-26-073878:notes:275]
As of December 31, 2025, 2024 and 2023, our total liability for unrecognized tax benefits was $0.3 million, $0.3 million and $1.0 million, respectively, of which $0.3 million, $0.3 million and $1.0 million, respectively, would reduce our effective tax rate if we were successful in upholding all of the uncertain positions and recognized the amounts recorded. We classify interest and penalties recognized on the liability for unrecognized tax benefits as income tax expense. There were no accrued interest and penalties as of December 31, 2025 and 2024, and $0.1 million in accrued interest and penalties as of December 31, 2023.

[0001193125-26-073878:notes:276]
We do not anticipate a single tax position generating a significant increase or decrease in our liability for unrecognized tax benefits within 12 months of this reporting date. We file income tax returns in the U.S. for federal and various state jurisdictions and several foreign jurisdictions. The Company's 2023 tax return is currently under audit by the Internal Revenue Service. Generally, we are not subject to changes in income taxes by any taxing jurisdiction for the years prior to 2019.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001193125-26-073878:notes:277]
Note 13 – Employee Benefit Plans

[0001193125-26-073878:notes:278]
Pension Benefit Plan

[0001193125-26-073878:notes:279]
We maintain defined benefit pension plans covering employees in certain foreign countries. Pension benefit plan obligations are based on various assumptions used by our actuaries in calculating these amounts. These assumptions include discount rates, compensation rate increases, expected return on plan assets, retirement rates and mortality rates. Actual results that differ from the assumptions and changes in assumptions could affect future expenses and obligations. Details regarding the pension plans are set forth below.

[0001193125-26-073878:notes:280]
•
In Germany, there are two defined benefit pension plans and two defined contribution plans. These plans provide benefits in the event of retirement, death or disability. The plan's benefits are based on age, years of service and salary. The defined benefit plans are financed by contributions paid by the Company and the defined contribution plans are financed by contributions paid by the participants.

[0001193125-26-073878:notes:281]
•
In Switzerland, there are two defined benefit pension plans. Both plans provide benefits in the event of retirement, death or disability. The plan's benefits are based on age, years of service, salary and on a participant's old age account. The plans are financed by contributions paid by the participants and by the Company.

[0001193125-26-073878:notes:282]
•
In Italy, the post-employment benefit plan is required due to statutory provisions. The plan is financed directly by the Company on a pay as you go basis. Employees receive their pension payments as a function of salary, inflation and a notional account.

[0001193125-26-073878:notes:283]
•
In Israel, there is a defined benefit pension plan that provides benefits in the event of a participant being dismissed involuntarily, retirement or death. The plan's benefits are based on the higher of the severance benefit required by law or the cash surrender value of the severance benefit component of any qualifying insurance policy or long-term employee benefit fund that is registered in the participants name. The plan is financed by contributions paid by the Company.

[0001193125-26-073878:notes:284]
•
In India, the post-employment benefit plan is required due to statutory provisions. The plan is financed directly by the Company on a pay as you go basis.

[0001193125-26-073878:notes:285]
•
In Poland, the post-employment benefit plan is required due to statutory provisions. The plan is financed directly by the Company on a pay as you go basis.

[0001193125-26-073878:notes:286]
The pension benefit plan obligations and funded status as of December 31, 2025 and 2024, were as follows:

[0001193125-26-073878:notes:287]
| (In thousands) |  | 2025 |  |  | 2024 |  |  |
| Change in projected benefit obligation: |  |  |  |  |  |  |  |
| Projected benefit obligation at beginning of period |  | $ | 63,259 |  |  | $ | 67,897 |  |  |
| Service cost |  |  | 1,669 |  |  |  | 1,664 |  |  |
| Interest cost |  |  | 570 |  |  |  | 1,902 |  |  |
| Actuarial gain - experience |  |  | (384 | ) |  |  | (238 | ) |  |
| Actuarial (gain) loss - assumptions |  |  | (3,334 | ) |  |  | 860 |  |  |
| Benefit payments |  |  | (3,607 | ) |  |  | (4,108 | ) |  |
| Plan amendments |  |  | — |  |  |  | (874 | ) |  |
| Participant contributions |  |  | 439 |  |  |  | 429 |  |  |
| Effects of foreign currency exchange rate changes |  |  | 10,089 |  |  |  | (4,273 | ) |  |
| Projected benefit obligation at end of period |  |  | 68,701 |  |  |  | 63,259 |  |  |
| Change in plan assets: |  |  |  |  |  |  |  |
| Fair value of plan assets at beginning of period |  |  | 54,490 |  |  |  | 55,218 |  |  |
| Actual gain on plan assets |  |  | 2,871 |  |  |  | 3,966 |  |  |
| Contributions |  |  | 1,314 |  |  |  | 1,288 |  |  |
| Benefit payments |  |  | (2,185 | ) |  |  | (2,244 | ) |  |
| Effects of foreign currency exchange rate changes |  |  | 7,853 |  |  |  | (3,738 | ) |  |
| Fair value of plan assets at end of period |  |  | 64,343 |  |  |  | 54,490 |  |  |
| Unfunded status at end of period |  | $ | (4,358 | ) |  | $ | (8,769 | ) |  |

[0001193125-26-073878:notes:288]
The accumulated benefit obligation was $67.9 million and $62.8 million as of December 31, 2025 and 2024, respectively. The increase in the accumulated benefit obligation, projected benefit obligation and the actuarial (gain)/loss was primarily attributable to the effect of exchange rates during the year partially offset by benefit payments to retirees.

[0001193125-26-073878:notes:289]
The net amounts recognized in the Consolidated Balance Sheets for the unfunded pension liability as of December 31, 2025 and 2024 were as follows:

[0001193125-26-073878:notes:290]
| (In thousands) |  | Balance Sheet Location |  | 2025 |  |  | 2024 |  |
| Non-current pension asset |  | Other non-current assets |  | $ | 2,291 |  |  | $ | 517 |  |
| Current pension liability |  | Accrued wages and benefits |  |  | (372 | ) |  |  | (303 | ) |
| Non-current pension liability |  | Non-current pension liability |  |  | (6,277 | ) |  |  | (8,983 | ) |
| Total |  |  |  | $ | (4,358 | ) |  | $ | (8,769 | ) |

[0001193125-26-073878:notes:291]
The components of net periodic pension cost, other than the service cost component, are included in other income, net in the Consolidated Statements of Loss. The components of net periodic pension cost and amounts recognized in other comprehensive (loss) income for the years ended December 31, 2025, 2024 and 2023 were as follows:

[0001193125-26-073878:notes:292]
| (In thousands) |  | 2025 |  |  | 2024 |  |  | 2023 |  |
| Net periodic benefit cost: |  |  |  |  |  |  |  |  |  |
| Service cost |  | $ | 1,669 |  |  | $ | 1,664 |  |  | $ | 1,579 |  |
| Interest cost |  |  | 570 |  |  |  | 1,902 |  |  |  | 1,851 |  |
| Expected return on plan assets |  |  | (1,486 | ) |  |  | (2,529 | ) |  |  | (1,750 | ) |
| Amortization of actuarial losses |  |  | 11 |  |  |  | 28 |  |  |  | 26 |  |
| Net periodic benefit cost |  |  | 764 |  |  |  | 1,065 |  |  |  | 1,706 |  |
| Other changes in plan assets and benefit obligations recognized in other comprehensive income (loss): |  |  |  |  |  |  |  |  |  |
| Net actuarial (gain) loss |  |  | (3,631 | ) |  |  | (1,640 | ) |  |  | 2,304 |  |
| Amortization of actuarial gains (losses) |  |  | (419 | ) |  |  | 233 |  |  |  | (145 | ) |
| Amount recognized in other comprehensive (income) loss |  |  | (4,050 | ) |  |  | (1,407 | ) |  |  | 2,159 |  |
| Total recognized in net periodic benefit cost and other comprehensive (income) loss |  | $ | (3,286 | ) |  | $ | (342 | ) |  | $ | 3,865 |  |

[0001193125-26-073878:notes:293]
The amounts recognized in accumulated other comprehensive income as of December 31, 2025 and 2024 were as follows:

[0001193125-26-073878:notes:294]
| (In thousands) |  | 2025 |  |  | 2024 |  |
| Net actuarial gain (loss) |  | $ | 2,226 |  |  | $ | (1,824 | ) |

[0001193125-26-073878:notes:295]
The defined benefit pension plans are accounted for on an actuarial basis, which requires the use of various assumptions, including an expected rate of return on plan assets and a discount rate. The expected return on our plan's assets is utilized in determining the benefit obligation and net periodic benefit cost is derived from periodic studies, which include a review of asset allocation strategies, anticipated future long-term performance of individual asset classes, risks using standard deviations and correlations of returns among the asset classes that comprise the plans' asset mix. While the studies give appropriate consideration to recent plan performance and historical returns, the assumptions are primarily long-term, prospective rates of return. The discount rate has been derived from the returns of high-quality, corporate bonds denominated in euro currency with durations close to the duration of our pension obligations.

[0001193125-26-073878:notes:296]
The weighted-average assumptions that were used to determine the net periodic benefit cost for the years ended December 31, 2025, 2024 and 2023 were as follows:

[0001193125-26-073878:notes:297]
|  |  | 2025 |  |  | 2024 |  |  | 2023 |  |
| Discount rate |  |  | 2.7 | % |  |  | 2.8 | % |  |  | 3.2 | % |
| Rate of compensation increase |  |  | 1.7 | % |  |  | 1.5 | % |  |  | 2.2 | % |
| Expected long-term rates of return |  |  | 4.8 | % |  |  | 4.9 | % |  |  | 4.8 | % |

[0001193125-26-073878:notes:298]
The weighted-average assumptions that were used to determine the benefit obligation as of December 31, 2025 and 2024:

[0001193125-26-073878:notes:299]
|  |  | 2025 |  |  | 2024 |  |  |
| Discount rate |  |  | 3.1 | % |  |  | 2.7 | % |  |
| Rate of compensation increase |  |  | 1.7 | % |  |  | 1.5 | % |  |

[0001193125-26-073878:notes:300]
Actuarial gains and losses are recorded in accumulated other comprehensive income. To the extent unamortized gains and losses exceed 10% of the higher of the market-related value of assets or the projected benefit obligation, the excess is amortized as a component of net periodic pension cost over the remaining service period of active participants.

[0001193125-26-073878:notes:301]
The Company anticipates making approximately $2.7 million in contributions to the pension plans in 2026.

[0001193125-26-073878:notes:302]
The following pension benefit payments, which reflect expected future service, as appropriate, are expected to be paid to participants:

[0001193125-26-073878:notes:303]
| (In thousands) |  |  |  |
| 2026 |  | $ | 3,839 |  |
| 2027 |  |  | 4,192 |  |
| 2028 |  |  | 3,697 |  |
| 2029 |  |  | 4,037 |  |
| 2030 |  |  | 3,481 |  |
| 2031 - 2035 |  |  | 19,368 |  |
| Total |  | $ | 38,614 |  |

[0001193125-26-073878:notes:304]
•
Level 3 – Significant unobservable inputs; values based on prices or valuation techniques that require inputs that are both unobservable and significant to the overall fair value measurement. These inputs could include information supplied by investees.

[0001193125-26-073878:notes:305]
We have categorized our cash equivalents and our investments held at fair value into this hierarchy as follows:

[0001193125-26-073878:notes:306]
|  |  | Fair Value Measurements at December 31, 2025 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarkets forIdentical Assets(Level 1) |  |  | SignificantOtherObservableInputs(Level 2) |  |  | SignificantUnobservableInputs(Level 3) |  |
| Cash and cash equivalents |  | $ | 1,757 |  |  | $ | 1,757 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Bond funds |  |  | 20,826 |  |  |  | 19,431 |  |  |  | 1,394 |  |  |  | — |  |
| Equity funds |  |  | 25,333 |  |  |  | 25,016 |  |  |  | 317 |  |  |  | — |  |
| Other funds |  |  | 8,538 |  |  |  | 7,313 |  |  |  | 1,225 |  |  |  | — |  |
| Real estate funds |  |  | 7,889 |  |  |  | 1,382 |  |  |  | 2,636 |  |  |  | 3,872 |  |
| Available-for-sale securities |  |  | 62,586 |  |  |  | 53,142 |  |  |  | 5,572 |  |  |  | 3,872 |  |
| Total |  | $ | 64,343 |  |  | $ | 54,899 |  |  | $ | 5,572 |  |  | $ | 3,872 |  |

[0001193125-26-073878:notes:307]
|  |  | Fair Value Measurements at December 31, 2024 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarkets forIdentical Assets(Level 1) |  |  | SignificantOtherObservableInputs(Level 2) |  |  | SignificantUnobservableInputs(Level 3) |  |
| Cash and cash equivalents |  | $ | 753 |  |  | $ | 753 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Bond funds |  |  | 18,058 |  |  |  | 16,867 |  |  |  | 1,191 |  |  |  | — |  |
| Equity funds |  |  | 21,376 |  |  |  | 21,183 |  |  |  | 193 |  |  |  | — |  |
| Other funds |  |  | 7,406 |  |  |  | 6,089 |  |  |  | 1,317 |  |  |  | — |  |
| Real estate funds |  |  | 6,897 |  |  |  | 1,737 |  |  |  | 2,106 |  |  |  | 3,054 |  |
| Available-for-sale securities |  |  | 53,737 |  |  |  | 45,876 |  |  |  | 4,807 |  |  |  | 3,054 |  |
| Total |  | $ | 54,490 |  |  | $ | 46,629 |  |  | $ | 4,807 |  |  | $ | 3,054 |  |

[0001193125-26-073878:notes:308]
Our investment policy includes various guidelines and procedures designed to ensure assets are invested in a manner necessary to meet expected future benefits earned by participants and consider a broad range of economic conditions. The objectives of the target allocations are to maintain investment portfolios that diversify risk through prudent asset allocation parameters, achieve asset returns that meet or exceed the plans’ actuarial assumptions and achieve asset returns that are competitive with like institutions employing similar investment strategies.

[0001193125-26-073878:notes:309]
The investment policy is periodically reviewed by the Company and a designated third-party fiduciary for investment matters. The policy is established and administered in a manner that is compliant at all times with applicable government regulations.

[0001193125-26-073878:notes:310]
401(k) Savings Plans

[0001193125-26-073878:notes:311]
We maintain the Adtran, Inc. 401(k) Retirement plan and the Adtran Networks 401(k) Retirement Plan (the “Savings Plans”) for the benefit of eligible employees. The Savings Plans are intended to qualify under Sections 401(a) and 401(k) of the Internal Revenue Code of 1986, as amended (the “Code”), and is intended to be a “safe harbor” 401(k) plan under Code Section 401(k)(12). The Savings Plans allows employees to save for retirement by contributing part of their compensation to the plan on a tax-deferred basis. The Savings Plans also requires us to contribute a “safe harbor” amount each year. In our legacy ADTRAN, Inc. plan, we match up to 4% of employee contributions (100% of an employee’s first 3% of contributions and 50% of their next 2% of contributions), beginning on the employee’s one-year anniversary date. All matching contributions under the legacy ADTRAN, Inc. Savings Plan vest immediately. In our legacy Adtran Networks plan, we match up to 1.5% of employee contributions (25% of an employee's first 6% of contributions). All matching contributions under the legacy Adtran Networks Savings Plan vest ratably over five years beginning on the employee's one-year anniversary date. In addition, under the legacy Adtran Networks plan, an annual matching employer contribution is made which is based on the Company's achievement against a yearly relative Pro-forma EBIT target which can range from no additional match up to an additional 50% match. In calculating our matching contributions, compensation up to the statutory maximum under the Code is used ($350,000 for 2025). Employer contribution expense and plan administration costs for both Savings Plans amounted to approximately $3.6 million, $3.5 million and $4.2 million in 2025, 2024 and 2023, respectively.

[0001193125-26-073878:notes:312]
In June 2024, the Company identified that within our Adtran, Inc. 401(k) plan for the year ended December 31, 2023, that deferrals and matching contributions should have been applied to vested equity award amounts in accordance with the plan documents. As such, we filed a voluntary correction program (“VCP”) application with the IRS and the Company is still in negotiations with the IRS regarding the appropriate corrective actions for this failure. Nonetheless, based on the current facts and circumstances surrounding the VCP negotiations, it appears likely that any corrective action to be approved by the IRS are reasonably estimated to total $1.4 million and have been accrued during the period ended December 31, 2025.

[0001193125-26-073878:notes:313]
Deferred Compensation Plans

[0001193125-26-073878:notes:314]
We have maintained two deferred compensation programs for certain executive management employees. On November 3, 2025 (the “Termination Date”), in an effort to streamline the benefits offered to members of management and other key employees, the Company terminated its Deferred Compensation Program for Employees (the “Deferred Compensation Plan”) and its Equity Deferral Program for Employees (the "Equity Deferral Program") together with the Deferred Compensation Plan, (the “Plans”). The Company has also terminated its deferred compensation plans for its non-employee directors. The payment of all benefits to each Plan’s participants and beneficiaries will be in the form of lump sum or installment distributions which are expected to occur prior to December 31, 2026, but can occur no earlier than twelve (12) months and no later than twenty-four (24) months following the Termination Date (the “Liquidation Date”). Distributions of amounts that are set to occur prior to the Liquidation Date will be made as scheduled under the terms of each Plan. Until the Liquidation Date, each of the Plans will continue to operate in the ordinary course, except that no new deferrals will be credited to the participants for compensation earned after the Termination Date.

[0001193125-26-073878:notes:315]
The Deferred Compensation Plan was offered as a supplement to our tax-qualified 401(k) plan and was available to certain executive management employees who have been designated by our Board of Directors. The Equity Deferral Program allowed participants to elect to defer all or a portion of their vested PSUs and RSUs to the plan. Such deferrals continue to be held and deemed to be invested in shares of Adtran stock unless and until the amounts are distributed or such deferrals are moved to another deemed investment pursuant to an election made by the participant.

[0001193125-26-073878:notes:316]
The Company has set aside the plan assets for all plans in a rabbi trust (the “Trust”) and all contributions are credited to bookkeeping accounts for the participants. The Trust assets are subject to the claims of our creditors in the event of bankruptcy or insolvency. The assets of the Trust are deemed to be invested in pre-approved mutual funds as directed by each participant and the participant’s bookkeeping account is credited with the earnings and losses attributable to those investments. The fair value of the assets held by the Trust and the amounts payable to the plan participants as of December 31, 2025 and 2024 were as follows:

[0001193125-26-073878:notes:317]
| (In thousands) |  | 2025 |  |  | 2024 |  |
| Fair Value of Plan Assets |  |  |  |  |  |  |
| Short term investments - deferred compensation plans |  | $ | 35,174 |  |  | $ | — |  |
| Long-term investments |  |  | — |  |  |  | 30,991 |  |
| Total Fair Value of Plan Assets |  | $ | 35,174 |  |  | $ | 30,991 |  |
| Amounts Payable to Plan Participants |  |  |  |  |  |  |
| Deferred compensation liability |  | $ | 37,447 |  |  | $ | — |  |
| Non-current deferred compensation liability |  |  | — |  |  |  | 33,203 |  |
| Total Amounts Payable to Plan Participants |  | $ | 37,447 |  |  | $ | 33,203 |  |

[0001193125-26-073878:notes:318]
Because the plans have been terminated and all assets will be liquidated or distributed to the plan participants within one year, the plan assets and liabilities have been reclassified to short-term as of December 31, 2025.

[0001193125-26-073878:notes:319]
The Trust held $2.3 million of common stock in the Company as of December 31, 2025 and 2024. Shares of the Company held by the Trust are recorded at cost and classified as treasury stock on the Consolidated Balance Sheet.

[0001193125-26-073878:notes:320]
Interest and dividend income of the Trust are included in interest and dividend income in the accompanying 2025, 2024 and 2023 Consolidated Statements of Loss. Changes in the fair value of the plan assets held by the Trust have been included in other income, net in the accompanying 2025, 2024 and 2022 Consolidated Statements of Loss. Changes in the fair value of the deferred compensation liability are included as selling, general and administrative expense in the accompanying 2025, 2024 and 2023 Consolidated Statements of Loss. Based on the changes in the total fair value of the Trust’s assets, the Company recorded deferred compensation income in 2025, 2024 and 2023 of $3.0 million, $3.4 million and $3.0 million, respectively.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001193125-26-073878:notes:321]
Note 14 – Equity

[0001193125-26-073878:notes:322]
The following table presents changes in accumulated other comprehensive income (loss), net of tax, by components of accumulated other comprehensive income (loss) for the years ended December 31, 2025, 2024 and 2023:

[0001193125-26-073878:notes:323]
| (In thousands) |  | UnrealizedGains (Losses)on Available-for-SaleSecurities |  |  | DefinedBenefit PlanAdjustments |  |  | ForeignCurrencyAdjustments |  |  | ASU 2018-02 Adoption (1) |  |  | Total |  |
| Balance as of December 31, 2022 |  | $ | (836 | ) |  | $ | (1,016 | ) |  | $ | 27,593 |  |  | $ | 385 |  |  | $ | 26,126 |  |
| Other comprehensive (loss) income before reclassifications |  |  | 734 |  |  |  | (1,590 | ) |  |  | 22,822 |  |  |  | — |  |  |  | 21,966 |  |
| Amounts reclassified from accumulated other comprehensive (loss) income |  |  | (280 | ) |  |  | 100 |  |  |  | — |  |  |  | — |  |  |  | (180 | ) |
| Net current period other comprehensive income (loss) |  |  | 454 |  |  |  | (1,490 | ) |  |  | 22,822 |  |  |  | — |  |  |  | 21,786 |  |
| Less: Other comprehensive income attributable to non-controlling interest, net of tax |  |  | — |  |  |  | — |  |  |  | 382 |  |  |  | — |  |  |  | 382 |  |
| Balance as of December 31, 2023 |  |  | (382 | ) |  |  | (2,506 | ) |  |  | 50,033 |  |  |  | 385 |  |  |  | 47,530 |  |
| Other comprehensive (loss) income before reclassifications |  |  | (160 | ) |  |  | 1,640 |  |  |  | (37,755 | ) |  |  | — |  |  |  | (36,275 | ) |
| Amounts reclassified from accumulated other comprehensive income (loss) |  |  | 160 |  |  |  | (161 | ) |  |  | — |  |  |  | — |  |  |  | (1 | ) |
| Net current period other comprehensive income (loss) |  |  | — |  |  |  | 1,479 |  |  |  | (37,755 | ) |  |  | — |  |  |  | (36,276 | ) |
| Balance as of December 31, 2024 |  |  | (382 | ) |  |  | (1,027 | ) |  |  | 12,278 |  |  |  | 385 |  |  |  | 11,254 |  |
| Other comprehensive income (loss) before reclassifications |  |  | 1 |  |  |  | 3,691 |  |  |  | 63,513 |  |  |  | — |  |  |  | 67,205 |  |
| Amounts reclassified from accumulated other comprehensive (loss) income |  |  | (1 | ) |  |  | 419 |  |  |  | — |  |  |  | — |  |  |  | 418 |  |
| Net current period other comprehensive income |  |  | — |  |  |  | 4,110 |  |  |  | 63,513 |  |  |  | — |  |  |  | 67,623 |  |
| Balance as of December 31, 2025 |  | $ | (382 | ) |  | $ | 3,083 |  |  | $ | 75,791 |  |  | $ | 385 |  |  | $ | 78,877 |  |

[0001193125-26-073878:notes:324]
(1) With the adoption of ASU 2018-02 on January 1, 2019, stranded tax effects related to the Tax Cuts and Jobs Act of 2017- were reclassified to retained earnings.

[0001193125-26-073878:notes:325]
The following tables present the details of reclassifications out of accumulated other comprehensive income (loss) for the years ended December 31, 2025, 2024 and 2023:

[0001193125-26-073878:notes:326]
| (In thousands) |  | For the year ended December 31, |  |  |  |
| Details about Accumulated Other Comprehensive (Loss)Income Components |  | 2025 |  |  | 2024 |  |  | 2023 |  |  | Affected Line Item in theStatement Where Net Loss Is Presented |
| Unrealized gains (loss) on available-for-sale securities: |  |  |  |  |  |  |  |  |  |  |  |
| Net realized (loss) gain on sales of securities |  | $ | (1 | ) |  | $ | 216 |  |  | $ | (378 | ) |  | Net investment gain |
| Defined benefit plan adjustments – actuarial gain (loss) |  |  | 419 |  |  |  | (233 | ) |  |  | 145 |  |  | Other (expense) income |
| Total reclassifications for the period, before tax |  |  | 418 |  |  |  | (17 | ) |  |  | (233 | ) |  |  |
| Tax expense |  |  | — |  |  |  | 16 |  |  |  | 53 |  |  |  |
| Total reclassifications for the period, net of tax |  | $ | 418 |  |  | $ | (1 | ) |  | $ | (180 | ) |  |  |

[0001193125-26-073878:notes:327]
The following tables present the tax effects related to the change in each component of other comprehensive income (loss) for the years ended December 31, 2025, 2024 and 2023:

[0001193125-26-073878:notes:328]
|  |  | 2025 |  |
| (In thousands) |  | Before-TaxAmount |  |  | Tax(Expense)Benefit |  |  | Net-of-TaxAmount |  |
| Unrealized gains on available-for-sale securities |  | $ | 1 |  |  | $ | — |  |  | $ | 1 |  |
| Reclassification adjustment for amounts related to available-for-sale investments included in net loss |  |  | (1 | ) |  |  | — |  |  |  | (1 | ) |
| Defined benefit plan adjustments |  |  | 3,631 |  |  |  | 60 |  |  |  | 3,691 |  |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net income |  |  | 419 |  |  |  | — |  |  |  | 419 |  |
| Foreign currency translation adjustment |  |  | 63,513 |  |  |  | — |  |  |  | 63,513 |  |
| Total Other Comprehensive Income |  | $ | 67,563 |  |  | $ | 60 |  |  | $ | 67,623 |  |

[0001193125-26-073878:notes:329]
|  |  | 2024 |  |
| (In thousands) |  | Before-TaxAmount |  |  | Tax(Expense)Benefit |  |  | Net-of-TaxAmount |  |
| Unrealized (loss) gains on available-for-sale securities |  | $ | (216 | ) |  | $ | 56 |  |  | $ | (160 | ) |
| Reclassification adjustment for amounts related to available-for-sale investments included in net income (loss) |  |  | 216 |  |  |  | (56 | ) |  |  | 160 |  |
| Defined benefit plan adjustments |  |  | 1,640 |  |  |  | — |  |  |  | 1,640 |  |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net (loss) income |  |  | (233 | ) |  |  | 72 |  |  |  | (161 | ) |
| Foreign currency translation adjustment |  |  | (37,755 | ) |  |  | — |  |  |  | (37,755 | ) |
| Total Other Comprehensive Loss |  | $ | (36,348 | ) |  | $ | 72 |  |  | $ | (36,276 | ) |

[0001193125-26-073878:notes:330]
|  |  | 2023 |  |
| (In thousands) |  | Before-TaxAmount |  |  | Tax(Expense)Benefit |  |  | Net-of-TaxAmount |  |
| Unrealized gains (loss) on available-for-sale securities |  | $ | 992 |  |  | $ | (258 | ) |  | $ | 734 |  |
| Reclassification adjustment for amounts related to available-for-sale investments included in net (loss) income |  |  | (378 | ) |  |  | 98 |  |  |  | (280 | ) |
| Defined benefit plan adjustments |  |  | (2,304 | ) |  |  | 714 |  |  |  | (1,590 | ) |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net income (loss) |  |  | 145 |  |  |  | (45 | ) |  |  | 100 |  |
| Foreign currency translation adjustment |  |  | 22,822 |  |  |  | — |  |  |  | 22,822 |  |
| Total Other Comprehensive Income |  | $ | 21,277 |  |  | $ | 509 |  |  | $ | 21,786 |  |


## us-gaap:RedeemableNoncontrollingInterestTableTextBlock

[0001193125-26-073878:notes:331]
The following table summarizes the redeemable non-controlling interest activity for the year ended December 31, 2025 and 2024:

[0001193125-26-073878:notes:332]
|  |  | For the year ended December 31, |  |  |
| (In thousands) |  | 2025 |  |  | 2024 |  |  |
| Balance at beginning of period |  | $ | 422,943 |  |  | $ | 443,327 |  |  |
| Redemption of redeemable non-controlling interests |  |  | (49,615 | ) |  |  | (20,384 | ) |  |
| Net income attributable to redeemable non-controlling interests |  |  | 9,413 |  |  |  | 9,824 |  |  |
| Annual recurring compensation earned |  |  | (9,413 | ) |  |  | (9,824 | ) |  |
| Balance at end of period |  | $ | 373,328 |  |  | $ | 422,943 |  |  |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-26-073878:notes:333]
Note 16 – Segment Information and Major Customers

[0001193125-26-073878:notes:334]
The chief operating decision maker is the Company's Chief Executive Officer who regularly reviews the Company’s financial performance based on two reportable segments: (1) Network Solutions and (2) Services & Support.

[0001193125-26-073878:notes:335]
The Network Solutions segment includes hardware and software products that enable a digital future which support the Company's Subscriber, Access and Aggregation, and Optical Networking Solutions. The Company's cloud-managed Wi-Fi gateways, virtualization software, and switches provide a mix of wired and wireless connectivity at the customer premises. In addition, its Carrier Ethernet products support a variety of applications at the network edge ranging from mobile backhaul to connecting enterprise customers (“Subscriber Solutions"). The Company's portfolio includes products for multi-gigabit service delivery over fiber or alternative media to homes and businesses.

[0001193125-26-073878:notes:336]
The Services & Support segment offers a comprehensive portfolio of network design, implementation, maintenance and cloud-hosted services supporting its Subscriber, Access and Aggregation, and Optical Networking Solutions. These services assist operators in the deployment of multi-vendor networks while reducing their cost to maintain these networks. The cloud-hosted services include a suite of SaaS applications under the Company's Mosaic One platform that manages end-to-end network and service optimization for both fiber access infrastructure and mesh Wi-Fi connectivity. The Company backs these services with a global support organization that offers on-site and off-site support services with varying SLAs.

[0001193125-26-073878:notes:337]
The performance of these segments is evaluated based on revenue, gross profit and gross margin; therefore, selling, general and administrative expenses, research and development expenses, interest and dividend income, interest expense, net investment gain, other (expense) income, net and income tax expense are reported on a Company-wide basis only. There is no inter-segment revenue. Asset information by reportable segment is not produced and, therefore, is not reported.

[0001193125-26-073878:notes:338]
Revenue and Gross Profit

[0001193125-26-073878:notes:339]
The following table presents information about revenue and gross profit of our reportable segments for each of the years ended December 31, 2025, 2024 and 2023:

[0001193125-26-073878:notes:340]
|  |  | 2025 |  |  | 2024 |  |  | 2023 |  |
| (In thousands) |  | Revenue |  |  | Cost of Revenue |  |  | Gross Profit |  |  | Revenue |  |  | Cost of Revenue |  |  | Gross Profit |  |  | Revenue |  |  | Cost of Revenue |  |  | Gross Profit |  |
| Network Solutions |  | $ | 896,911 |  |  | $ | 592,141 |  |  | $ | 304,770 |  |  | $ | 738,964 |  |  | $ | 525,817 |  |  | $ | 213,147 |  |  | $ | 974,389 |  |  | $ | 748,831 |  |  | $ | 225,558 |  |
| Services & Support |  |  | 186,896 |  |  |  | 76,711 |  |  |  | 110,185 |  |  |  | 183,756 |  |  |  | 72,739 |  |  |  | 111,017 |  |  |  | 174,711 |  |  |  | 69,142 |  |  |  | 105,569 |  |
| Total |  | $ | 1,083,807 |  |  | $ | 668,852 |  |  | $ | 414,955 |  |  | $ | 922,720 |  |  | $ | 598,556 |  |  | $ | 324,164 |  |  | $ | 1,149,100 |  |  | $ | 817,973 |  |  | $ | 331,127 |  |

[0001193125-26-073878:notes:341]
For the years ended December 31, 2025, 2024 and 2023, $5.7 million, $6.1 million and $6.5 million, respectively, of depreciation expense was included in gross profit for our Network Solutions segment. For the years ended December 31, 2025, 2024 and 2023, $0.1 million, $0.1 million and $20 thousand, respectively, of depreciation expense was included in gross profit for our Services & Support segment.

[0001193125-26-073878:notes:342]
Our Subscriber Solutions portfolio is used by Service Providers to terminate their access services infrastructure at customers' premises while providing an immersive and interactive experience for residential, business and wholesale subscribers. This revenue category includes hardware and software based products and services. These solutions include fiber termination solutions for residential, business and wholesale subscribers, Wi-Fi access solutions for residential and business subscribers, Ethernet switching and network edge virtualization solutions for business subscribers, and cloud software solutions covering a mix of subscriber types.

[0001193125-26-073878:notes:343]
Our Access & Aggregation Solutions are solutions that are used by communications Service Providers to connect residential subscribers, business subscribers and mobile radio networks to the Service Providers’ metro network, primarily through fiber-based connectivity. This revenue category includes hardware and software based products and services. Our solutions within this category are a mix of fiber access and aggregation platforms, precision network synchronization and timing solutions, and access orchestration solutions that ensure highly reliable and efficient network performance.

[0001193125-26-073878:notes:344]
Our Optical Networking Solutions are used by communications Service Providers, internet content providers and large-scale enterprises to securely interconnect metro and regional networks over fiber. This revenue category includes hardware and software based products and services. Our solutions within this category include open optical terminals, open line systems, optical subsystems and modules, network infrastructure assurance systems, and automation platforms that are used to build high-scale, secure and assured optical networks.

[0001193125-26-073878:notes:345]
The following tables disaggregate our revenue by category for the years ended December 31, 2025, 2024 and 2023:

[0001193125-26-073878:notes:346]
|  |  | 2025 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Optical Networking Solutions |  | $ | 281,771 |  |  | $ | 98,541 |  |  | $ | 380,312 |  |
| Subscriber Solutions |  |  | 336,297 |  |  |  | 32,779 |  |  |  | 369,076 |  |
| Access & Aggregation Solutions |  |  | 278,843 |  |  |  | 55,576 |  |  |  | 334,419 |  |
| Total |  | $ | 896,911 |  |  | $ | 186,896 |  |  | $ | 1,083,807 |  |

[0001193125-26-073878:notes:347]
|  |  | 2024 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Optical Networking Solutions |  | $ | 210,489 |  |  | $ | 90,447 |  |  | $ | 300,936 |  |
| Subscriber Solutions |  |  | 295,541 |  |  |  | 35,237 |  |  |  | 330,778 |  |
| Access & Aggregation Solutions |  |  | 232,934 |  |  |  | 58,072 |  |  |  | 291,006 |  |
| Total |  | $ | 738,964 |  |  | $ | 183,756 |  |  | $ | 922,720 |  |

[0001193125-26-073878:notes:348]
|  |  | 2023 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Optical Networking Solutions |  | $ | 407,123 |  |  | $ | 85,851 |  |  | $ | 492,974 |  |
| Subscriber Solutions |  |  | 263,192 |  |  |  | 34,516 |  |  |  | 297,708 |  |
| Access & Aggregation Solutions |  |  | 304,074 |  |  |  | 54,344 |  |  |  | 358,418 |  |
| Total |  | $ | 974,389 |  |  | $ | 174,711 |  |  | $ | 1,149,100 |  |

[0001193125-26-073878:notes:349]
Additional Information

[0001193125-26-073878:notes:350]
The following table presents revenue information by geographic area for the years ended December 31, 2025, 2024 and 2023:

[0001193125-26-073878:notes:351]
| (In thousands) |  | 2025 |  |  | 2024 |  |  | 2023 |  |
| United States |  | $ | 480,750 |  |  | $ | 398,170 |  |  | $ | 460,985 |  |
| United Kingdom |  |  | 213,113 |  |  |  | 196,064 |  |  |  | 214,655 |  |
| Germany |  |  | 129,734 |  |  |  | 119,976 |  |  |  | 230,922 |  |
| Other international |  |  | 260,210 |  |  |  | 208,510 |  |  |  | 242,538 |  |
| Total |  | $ | 1,083,807 |  |  | $ | 922,720 |  |  | $ | 1,149,100 |  |

[0001193125-26-073878:notes:352]
Customers comprising more than 10% of revenue can change from year to year. The Company had one customer comprising more than 10% of revenue in 2025, 2024 and 2023, respectively, at 14.2%, 12.1% and 10.4% and was included in both our Network Solutions and Services & Support segments. This customer accounted for $153.7 million, $111.8 million and $126.0 million in revenues for the years ended December 31, 2025, 2024 and 2023, respectively. Other than those with more than 10% of revenue disclosed above, our next five largest customers can change, and have historically changed, from year-to-year. The next five largest customers combined represented 20%, 22% and 28% of total revenue in 2025, 2024 and 2023, respectively.

[0001193125-26-073878:notes:353]
As of December 31, 2025, property, plant and equipment, net totaled $124.4 million, which included $49.3 million held in the U.S. and $75.1 million held outside the U.S. As of December 31, 2024, property, plant and equipment, net totaled $106.5 million, which included $46.3 million held in the U.S. and $60.2 million held outside the U.S. Property, plant and equipment, net is reported on a Company-wide, functional basis only.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-26-073878:notes:354]
Note 17 – Commitments and Contingencies

[0001193125-26-073878:notes:355]
Legal Matters

[0001193125-26-073878:notes:356]
From time to time, the Company is subject to or otherwise involved in various lawsuits, claims, investigations and legal proceedings that arise out of or are incidental to the conduct of our business (collectively, “Legal Matters”), including those relating to employment matters, patent rights, regulatory compliance matters, stockholder claims, and contractual and other commercial disputes. Such Legal Matters, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Additionally, an unfavorable outcome in a legal matter, including in a patent dispute, could require the Company to pay damages, entitle claimants to other relief, such as royalties, or could prevent the Company from selling some of its products in certain jurisdictions. The Company records an accrual for any Legal Matters that arise whenever it considers that it is probable that it is exposed to a loss contingency and the amount of the loss contingency can be reasonably estimated. Although the ultimate disposition of asserted claims cannot be predicted with certainty, it is our belief that the outcome of any such claims, either individually or on a combined basis, will not have a material adverse effect on our consolidated financial position.

[0001193125-26-073878:notes:357]
As disclosed in Amendment No. 1 to our Annual Report on Form 10-K for the fiscal year ended December 31, 2024, filed with the SEC on May 20, 2025, we identified errors in our previously issued financial statements related to the historical accounting for certain inventory and cost of goods sold transactions (“Adjustment”). The affected periods included the annual periods ended December 31, 2023 and 2024 and the interim periods ended March 31, 2024, June 30, 2024 and September 30, 2024. In connection with the identification of the Adjustment, the Audit Committee oversaw an internal investigation into the circumstances surrounding the Adjustment and its impact on the Company’s historical financial statements. Based on the findings of the internal investigation, it was determined that the underlying errors giving rise to the Adjustment were not properly addressed in the Company’s previously filed financial statements as of and for the years ended December 31, 2024 and 2023 and were not communicated to the Audit Committee or the independent auditors prior to the filing of the initial Annual Report on Form 10-K for the year ended December 31, 2024. The Company has taken certain remedial actions to address the material weaknesses in its internal controls associated with these findings. On August 4, 2025, the Company received a letter from the Atlanta regional office of the SEC in connection with a non-public, fact-finding inquiry, requesting that we voluntarily provide information regarding the internal investigation. The Company is cooperating in response to the SEC’s inquiry and cannot predict the timing or outcome of the inquiry.

[0001193125-26-073878:notes:358]
DPLTA Appraisal Proceedings

[0001193125-26-073878:notes:359]
In addition to such Legal Matters, the Company is a party to appraisal proceedings relating to the DPLTA which were originally filed with the Landgericht Meiningen (Meiningen Regional Court) on February 3, 2023. The DPLTA provides that Adtran Networks shareholders (other than the Company) be offered, at their election, (i) to put their Adtran Networks shares to the Company in exchange for compensation in cash of €17.21 per share, plus guaranteed interest or (ii) to remain Adtran Networks shareholders and receive recurring cash compensation of €0.52 per share for each full fiscal year of Adtran Networks. The appraisal proceedings, which were initiated by certain minority shareholders of Adtran Networks, challenge the adequacy of both forms of compensation. While the Company believes that the compensation offered in connection with the DPLTA is fair, it notes that German courts often adjudicate increases of the cash compensation to plaintiffs in varying amounts in connection with German appraisal proceedings. Therefore, the Company cannot rule out that the court or an appellate court may increase the cash compensation owed to the minority Adtran Networks shareholders. Given the stage of the appraisal proceedings, the Company is currently unable to predict the likely outcome or estimate the potential financial impact, if any, of the appraisal proceedings. If a ruling were to occur and be upheld upon appeal that required the Company to pay significant additional cash compensation to the Adtran Networks minority shareholders, there exists the possibility of a material adverse effect on our financial position and results of operations for the period in which the ruling occurs or future periods.

[0001193125-26-073878:notes:360]
DPLTA Exit and Recurring Compensation Costs and the Absorption of Adtran Network's Annual Net Loss

[0001193125-26-073878:notes:361]
Pursuant to the terms of the DPLTA, each Adtran Networks shareholder (other than the Company) has received an offer to elect either (1) to remain an Adtran Networks shareholder and receive from us an Annual Recurring Compensation payment, or (2) to receive Exit Compensation plus guaranteed interest. The guaranteed interest under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid. The guaranteed interest rate is 5.0% plus a variable component (according to the German Civil Code) that was 1.27% as of December 31, 2025. Assuming all the minority holders of currently outstanding Adtran Networks shares were to elect the second option, we would be obligated to make aggregate Exit Compensation payments, including guaranteed interest, of approximately €303.9 million or approximately $357.0 million, based on an exchange rate as of December 31, 2025 and reflecting interest accrued through December 31, 2025 during the pendency of the appraisal proceedings discussed below. Shareholders electing the first option of Annual Recurring Compensation may later elect the second option. The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that were initiated in 2023 in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger). Following the court's decision on a procedural matter in the DPLTA appraisal proceedings on July 14, 2025, the proceeding for the trial on the merits of the DPLTA has recommenced. It is expected to take a minimum of 12 months for a ruling of the court on the merits and such ruling will most likely be appealed, which would be expected to take an additional 12-24 months to be resolved. Accordingly, the Company does not expect a final decision on the DPLTA appraisal proceedings to be rendered and published prior to 2027, and most likely not until 2028 or beyond.

[0001193125-26-073878:notes:362]
Our obligation to pay Annual Recurring Compensation under the DPLTA is a continuing payment obligation, which will amount to approximately €7.9 million (or $9.3 million based on the exchange rate as of December 31, 2025) per year assuming none of the minority Adtran Networks shareholders were to elect Exit Compensation. The foregoing amounts do not reflect any potential increase in payment obligations that we may have depending on the outcome of ongoing appraisal proceedings in Germany. The Annual Recurring Compensation is due on the third banking day following the ordinary general shareholders’ meeting of Adtran Networks for the respective preceding fiscal year (but in any event within eight months following expiration of the fiscal year). With respect to the 2024 fiscal year, Adtran Networks’ ordinary general shareholders' meeting occurred on June 27, 2025 and, therefore, the Annual Recurring Compensation was paid on July 1, 2025. With respect to the 2025 fiscal year, Adtran Networks’ ordinary general shareholder meeting is scheduled for the second quarter of 2026, and the Annual Recurring Compensation will be due on the third banking day following the meeting. During the years ended December 31, 2025 and 2024, we accrued $9.3 million and $9.8 million, respectively, in Annual Recurring Compensation, which was reflected as an increase to retained deficit.

[0001193125-26-073878:notes:363]
For the year ended December 31, 2025, 2.0 million shares, of Adtran Networks stock were tendered to the Company. This resulted in total Exit Compensation payments of €40.2 million, or $46.6 million, based on exchange rates at the time of the transactions, being paid to Adtran Networks shareholders. For the year ended December 31, 2024, 0.8 million shares of Adtran Networks shares were tendered to the Company. This resulted in Exit Compensation payments of €15.7 million or $17.4 million, based on an exchange rate as of December 31, 2024, being paid to Adtran Networks shareholders.

[0001193125-26-073878:notes:364]
In addition, under the DPLTA, subject to certain limitations pursuant to applicable law and the specific terms of the DPLTA, (i) the Company is entitled to issue binding instructions to the management board of Adtran Networks, (ii) Adtran Networks will transfer its annual profit to the Company, subject to, among other things, the creation or dissolution of certain reserves, and (iii) the Company will absorb the annual net loss incurred by Adtran Networks. The Company’s payment obligation in satisfaction of the requirement that it

[0001193125-26-073878:notes:365]
absorb Adtran Networks’ annual net loss applies to the net loss generated by Adtran Networks in 2025, and it will apply to any net loss generated by Adtran Networks in 2026.

[0001193125-26-073878:notes:366]
Performance Bonds

[0001193125-26-073878:notes:367]
Certain contracts, customers and jurisdictions in which the Company operates require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of December 31, 2025 and December 31, 2024, the Company had commitments related to these bonds totaling $22.4 million and $15.7 million, respectively, which expire at various dates through April 2029. In general the Company would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which the Company believes is remote.

[0001193125-26-073878:notes:368]
Purchase Obligations

[0001193125-26-073878:notes:369]
The Company purchases components from a variety of suppliers and use contract manufacturers to provide manufacturing services for our products. Our inventory purchase obligations are for short-term product manufacturing requirements, as well as for obligations to suppliers to secure manufacturing capacity. Certain of our inventory purchase obligations with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. As of December 31, 2025, purchase obligations totaled $205.9 million.


## us-gaap:EarningsPerShareTextBlock

[0001193125-26-073878:notes:370]
Note 18 – Loss per Share

[0001193125-26-073878:notes:371]
The calculations of basic and diluted loss per share for the years ended December 31, 2025, 2024 and 2023 are as follows:

[0001193125-26-073878:notes:372]
| (In thousands, except for per share amounts) |  | 2025 |  |  | 2024 |  |  | 2023 |  |
| Numerator |  |  |  |  |  |  |  |  |  |
| Net loss attributable to ADTRAN Holdings, Inc. |  | $ | (45,656 | ) |  | $ | (459,891 | ) |  | $ | (268,852 | ) |
| Effect of redemption of RNCI |  |  | 4,085 |  |  |  | 2,981 |  |  |  | — |  |
| Net loss attributable to ADTRAN Holdings, Inc. common stockholders |  | $ | (41,571 | ) |  | $ | (456,910 | ) |  | $ | (268,852 | ) |
| Denominator |  |  |  |  |  |  |  |  |  |
| Weighted average number of shares – basic |  |  | 79,742 |  |  |  | 78,928 |  |  |  | 78,416 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |  |  |
| Stock options |  |  | — |  |  |  | — |  |  |  | — |  |
| PSUs, RSUs and restricted stock |  |  | — |  |  |  | — |  |  |  | — |  |
| Weighted average number of shares – diluted |  |  | 79,742 |  |  |  | 78,928 |  |  |  | 78,416 |  |
| Loss per share attributable to ADTRAN Holdings, Inc. – basic |  | $ | (0.52 | ) |  | $ | (5.79 | ) |  | $ | (3.43 | ) |
| Loss per share attributable to ADTRAN Holdings, Inc. – diluted |  | $ | (0.52 | ) |  | $ | (5.79 | ) |  | $ | (3.43 | ) |

[0001193125-26-073878:notes:373]
The following potentially dilutive shares were excluded from the calculation of the diluted weighted average number of shares outstanding as the effect would have been anti-dilutive:

[0001193125-26-073878:notes:374]
| (In thousands) |  | 2025 |  |  | 2024 |  |  | 2023 |  |
| Convertible senior notes |  |  | 4,931 |  |  |  | — |  |  |  | — |  |
| Stock options |  |  | 882 |  |  |  | 3,410 |  |  |  | 1,761 |  |
| PSUs, RSUs and restricted stock |  |  | 911 |  |  |  | 834 |  |  |  | 514 |  |


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001193125-26-073878:notes:375]
Note 19 – Restructuring

[0001193125-26-073878:notes:376]
On November 6, 2023, due to the uncertainty around the then-current macroeconomic environment and its impact on customer spending levels, the Company’s management decided to implement a Business Efficiency Program targeting the reduction of ongoing operating expenses and focusing on capital efficiency. This included certain salary reductions, an early retirement program, a site consolidation plan to include lease impairments, inventory write downs from product discontinuances, and the suspension of the quarterly dividend. The Business Efficiency Program was completed as of December 31, 2024.

[0001193125-26-073878:notes:377]
During the years ended December 31, 2024 and 2023, we recognized $44.7 million and $25.1 million, respectively, of costs related to the Business Efficiency Program. The costs recognized during the year ended December 31, 2024, included total other renegotiated charges and inventory write-down of $8.6 million as a result of a strategy shift which included discontinuance of certain items in connection with the Business Efficiency Program, of which, $4.1 million relates to inventory write-downs and $4.5 million relates to other charges, and are included in cost of revenue in the Consolidated Statements of Loss.

[0001193125-26-073878:notes:378]
For the year ended December 31, 2023, we recognized $21.5 million of restructuring costs relating to the Business Combination under the multi-year integration program and synergy realization, respectively, that are included in cost of revenue, selling, general and administrative expenses and research and development expenses in the Consolidated Statement of Loss.

[0001193125-26-073878:notes:379]
A reconciliation of the beginning and ending restructuring liability, which is included in accrued wages and benefits and accrued expenses and other liabilities in the Consolidated Balance Sheets as of December 31, 2025 and 2024, is as follows:

[0001193125-26-073878:notes:380]
| (In thousands) |  | 2025 |  |  | 2024 |  |
| Balance at beginning of period |  | $ | 10,336 |  |  | $ | 8,309 |  |
| Plus: Amounts charged to cost and expense |  |  | (284 | ) |  |  | 40,545 |  |
| Less: Amounts paid |  |  | (10,052 | ) |  |  | (38,518 | ) |
| Balance at end of period |  | $ | — |  |  | $ | 10,336 |  |

[0001193125-26-073878:notes:381]
Restructuring expenses included in the Consolidated Statements of Loss are for the years ended December 31, 2025, 2024 and 2023:

[0001193125-26-073878:notes:382]
| (In thousands) |  | 2025 |  |  | 2024 |  |  | 2023 |  |
| Network solutions - cost of revenue |  | $ | — |  |  | $ | 3,693 |  |  | $ | 2,910 |  |
| Network solutions - inventory write-down |  |  | — |  |  |  | 8,597 |  |  |  | 24,313 |  |
| Services & support - cost of revenue |  |  | — |  |  |  | 2,289 |  |  |  | — |  |
| Cost of revenue |  | $ | — |  |  | $ | 14,579 |  |  | $ | 27,223 |  |
| Selling, general and administrative expenses |  |  | — |  |  |  | 9,128 |  |  |  | 11,603 |  |
| Research and development expenses |  |  | (284 | ) |  |  | 20,973 |  |  |  | 7,728 |  |
| Total restructuring expenses |  | $ | (284 | ) |  | $ | 44,680 |  |  | $ | 46,554 |  |

[0001193125-26-073878:notes:383]
The following table represents the components of restructuring expense by geographic area for the years ended December 31, 2025, 2024 and 2023:

[0001193125-26-073878:notes:384]
| (In thousands) |  | 2025 |  |  | 2024 |  |  | 2023 |  |
| United States |  | $ | — |  |  | $ | 18,422 |  |  | $ | 34,629 |  |
| International |  |  | (284 | ) |  |  | 26,258 |  |  |  | 11,925 |  |
| Total restructuring expenses |  | $ | (284 | ) |  | $ | 44,680 |  |  | $ | 46,554 |  |


## us-gaap:SubsequentEventsTextBlock

[0001193125-26-073878:notes:385]
Note 20 – Subsequent Events

[0001193125-26-073878:notes:386]
U.S. Tariff Update

[0001193125-26-073878:notes:387]
On February 20, 2026, the United States Supreme Court issued a ruling striking down certain tariffs previously imposed under the International Emergency Economic Powers Act ("IEEPA"). The ultimate availability, timing, and amount of any potential refunds of such tariffs remain highly uncertain and are subject to further legal, regulatory, and administrative developments. Following the Supreme Court’s decision, the U.S. presidential administration announced its intention to invoke other laws to collect tariffs and announced new tariffs on imports from all countries, in addition to any existing non-IEEPA tariffs. There remains substantial uncertainty regarding the duration of existing and newly announced tariffs, potential changes or pauses to such tariffs, tariff levels, and whether additional tariffs or other retaliatory actions may be imposed, modified, or suspended, and the impacts of such actions on the Company's business. The Company continues to monitor and evaluate these developments and assess their potential impact on the Company’s business, financial condition, and results of operations.


## ecd:MtrlTermsOfTrdArrTextBlock

[0001193125-26-073878:notes:388]
ITEM 9B. OTHER INFORMATION

[0001193125-26-073878:notes:389]
(a) None.

[0001193125-26-073878:notes:390]
(b) Dr. Christoph Glingener, our Chief Technology Officer, adopted a Rule 10b5-1 trading arrangement (as defined in Item 408 of Regulation S-K) on December 12, 2025. Dr. Glingener’s trading arrangement covers the exercise of 148,392 stock options and the sale of the underlying shares of the Company’s common stock, and it is scheduled to terminate on the earlier of (i) December 31, 2026 and (ii) the date that all such options are exercised and the underlying shares are sold.

[0001193125-26-073878:notes:391]
Other than as disclosed above, during the fiscal quarter ended December 31, 2025, none of the Company’s directors or executive officers adopted or terminated any contract, instruction or written plan for the purchase or sale of Company securities that was intended to satisfy the affirmative defense conditions of Rule 10b5-1(c) or any “non-Rule 10b5-1 trading arrangement” as defined in Item 408 of Regulation S-K.


## srt:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001193125-26-073878:notes:392]
SCHEDULE II

[0001193125-26-073878:notes:393]
VALUATION AND QUALIFYING ACCOUNTS

[0001193125-26-073878:notes:394]
| (In thousands) |  | Balance atBeginningof Period |  |  | Charged toCosts &Expenses |  |  | Deductions |  |  | Balance atEnd ofPeriod |  |
| Year ended December 31, 2025 |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for Credit Losses |  | $ | 1,300 |  |  |  | 18 |  |  |  | — |  |  | $ | 1,318 |  |
| Deferred Tax Asset Valuation Allowance |  | $ | 115,694 |  |  |  | 13,463 |  |  |  | 4,706 |  |  | $ | 124,451 |  |
| Year ended December 31, 2024 |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for Credit Losses |  | $ | 400 |  |  |  | 900 |  |  |  | — |  |  | $ | 1,300 |  |
| Deferred Tax Asset Valuation Allowance |  | $ | 86,567 |  |  |  | 29,217 |  |  |  | 90 |  |  | $ | 115,694 |  |
| Year ended December 31, 2023 |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for Credit Losses |  | $ | 49 |  |  |  | 351 |  |  |  | — |  |  | $ | 400 |  |
| Deferred Tax Asset Valuation Allowance |  | $ | 5,201 |  |  |  | 81,590 |  |  |  | 224 |  |  | $ | 86,567 |  |
