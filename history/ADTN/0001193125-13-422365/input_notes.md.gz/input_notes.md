# ADTN notes — 0001193125-13-422365


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-13-422365:notes:1]
[same as prior period, unchanged from 0001193125-13-312256:notes:1]

[0001193125-13-422365:notes:2]
The following
 table summarizes the stock-based compensation expense related to
 stock options, restricted stock units (RSUs) and restricted stock
 for the three and nine months ended September 30, 2013 and
 2012, which was recognized as follows:

[0001193125-13-422365:notes:3]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
| Stock-based compensation expense included in cost of sales |  | $ | 118 |  |  | $ | 106 |  |  | $ | 334 |  |  | $ | 304 |  |
| Selling, general and administrative expense |  |  | 1,024 |  |  |  | 1,107 |  |  |  | 3,129 |  |  |  | 3,205 |  |
| Research and development expense |  |  | 1,034 |  |  |  | 1,138 |  |  |  | 3,053 |  |  |  | 3,274 |  |
| Stock-based compensation expense included in operating expenses |  |  | 2,058 |  |  |  | 2,245 |  |  |  | 6,182 |  |  |  | 6,479 |  |
| Total stock-based compensation expense |  |  | 2,176 |  |  |  | 2,351 |  |  |  | 6,516 |  |  |  | 6,783 |  |
| Tax benefit for expense associated with non-qualified options |  |  | (307 | ) |  |  | (313 | ) |  |  | (924 | ) |  |  | (916 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 1,869 |  |  | $ | 2,038 |  |  | $ | 5,592 |  |  | $ | 5,867 |  |

[0001193125-13-422365:notes:4]
The fair value
 of our stock options was estimated using the Black-Scholes model.
 The determination of the fair value of stock options on the date of
 grant using the Black-Scholes model is affected by our stock price
 as well as assumptions regarding a number of complex and subjective
 variables that may have a significant impact on the fair value
 estimate.

[0001193125-13-422365:notes:5]
There were no
 options granted during the three and nine months ended
 September 30, 2013. The weighted-average assumptions and value
 of options granted for the three and nine months ended
 September 30, 2012 are summarized as follows:

[0001193125-13-422365:notes:6]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
|  |  | 2012 |  |  | 2012 |  |
| Expected volatility |  |  | 40.20 | % |  |  | 40.20 | % |
| Risk-free interest rate |  |  | 0.63 | % |  |  | 0.63 | % |
| Expected dividend yield |  |  | 1.30 | % |  |  | 1.30 | % |
| Expected life (in years) |  |  | 4.95 |  |  |  | 4.95 |  |
| Weighted-average estimated value |  | $ | 8.69 |  |  | $ | 8.69 |  |

[0001193125-13-422365:notes:7]
The fair value
 of our RSUs is calculated using a Monte Carlo Simulation valuation
 method. There were no RSU grants during the three and nine months
 ended September 30, 2013 or 2012.

[0001193125-13-422365:notes:8]
The fair value
 of restricted stock is equal to the closing price of our stock on
 the date of grant. There were no restricted stock grants during the
 three and nine months ended September 30, 2013 or
 2012.

[0001193125-13-422365:notes:9]
Stock-based
 compensation expense recognized in our Consolidated Statements of
 Income for the three and nine months ended September 30, 2013
 and 2012 is based on options, RSUs and restricted stock ultimately
 expected to vest, and has been reduced for estimated forfeitures.
 Estimated forfeitures for stock options were based upon historical
 experience and approximate 1.7% annually. We estimated a 0%
 forfeiture rate for our RSUs and restricted stock due to the
 limited number of recipients and historical experience for these
 awards.

[0001193125-13-422365:notes:10]
As of
 September 30, 2013, total compensation expense related to
 non-vested stock options, RSUs and restricted stock not yet
 recognized was approximately $11.8 million, which is expected to be
 recognized over an average remaining recognition period of 2.1
 years.

[0001193125-13-422365:notes:11]
The following
 table is a summary of our stock options outstanding as of
 December 31, 2012 and September 30, 2013 and the changes
 that occurred during the nine months ended September 30,
 2013:

[0001193125-13-422365:notes:12]
| (In thousands, except per share amounts) |  | Number of Options |  |  | Weighted Avg. Exercise Price |  |  | Weighted Avg. Remaining Contractual Life In Years |  |  | Aggregate Intrinsic Value |  |
| Options outstanding, December 31, 2012 |  |  | 6,035 |  |  | $ | 24.81 |  |  |  | 6.69 |  |  | $ | 5,154 |  |
| Options granted |  |  | — |  |  | $ | — |  |  |  |  |  |
| Options cancelled/forfeited |  |  | (188 | ) |  | $ | 26.23 |  |  |  |  |  |
| Options exercised |  |  | (123 | ) |  | $ | 18.93 |  |  |  |  |  |
| Options outstanding, September 30, 2013 |  |  | 5,724 |  |  | $ | 24.89 |  |  |  | 5.96 |  |  | $ | 21,878 |  |
| Options exercisable, September 30, 2013 |  |  | 3,618 |  |  | $ | 25.33 |  |  |  | 4.68 |  |  | $ | 11,955 |  |

[0001193125-13-422365:notes:13]
The aggregate
 intrinsic values in the table above represent the total pre-tax
 intrinsic value (the difference between the closing of our stock on
 the last trading day of the quarter and the exercise price,
 multiplied by the number of in-the-money options) that would have
 been received by the option holders had all option holders
 exercised their options on September 30, 2013. The aggregate
 intrinsic value will change based on the fair market value of our
 stock.

[0001193125-13-422365:notes:14]
The total
 pre-tax intrinsic value of options exercised during the three and
 nine months ended September 30, 2013 was $0.5 million and $0.8
 million, respectively.

[0001193125-13-422365:notes:15]
The following
 table is a summary of our RSUs and restricted stock outstanding as
 of December 31, 2012 and September 30, 2013 and the
 changes that occurred during the nine months ended
 September 30, 2013:

[0001193125-13-422365:notes:16]
| (In thousands, except per share amounts) |  | Number of Shares |  |  | Weighted Average Grant Date Fair Value |  |
| Unvested RSUs and restricted stock outstanding, December 31, 2012 |  |  | 103 |  |  | $ | 29.25 |  |
| RSUs and restricted stock granted |  |  | — |  |  | $ | — |  |
| RSUs and restricted stock vested |  |  | — |  |  | $ | — |  |
| RSUs and restricted stock cancelled/forfeited |  |  | — |  |  | $ | — |  |
| Unvested RSUs and restricted stock, September 30, 2013 |  |  | 103 |  |  | $ | 29.25 |  |


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001193125-13-422365:notes:17]
[same as prior period, unchanged from 0001193125-13-312256:notes:16]

[0001193125-13-422365:notes:18]
Our products
 generally include warranties of 90 days to ten years for product
 defects. We accrue for warranty returns at the time revenue is
 recognized based on our estimate of the cost to repair or replace
 the defective products. We engage in extensive product quality
 programs and processes, including actively monitoring and
 evaluating the quality of our component suppliers. Our products
 continue to become more complex in both size and functionality as
 many of our product offerings migrate from line card applications
 to systems products. The increasing complexity of our products will
 cause warranty incidences, when they arise, to be more costly. Our
 estimates regarding future warranty obligations may change due to
 product failure rates, material usage, and other rework costs
 incurred in correcting a product failure. In addition, from time to
 time, specific warranty accruals may be recorded if unforeseen
 problems arise. Should our actual experience relative to these
 factors be worse than our estimates, we will be required to record
 additional warranty expense. Alternatively, if we provide for more
 reserves than we require, we will reverse a portion of such
 provisions in future periods. The liability for warranty
 obligations totaled $8.6 million at September 30, 2013 and
 $9.7 million at December 31, 2012. These liabilities are
 included in accrued expenses in the accompanying Consolidated
 Balance Sheets.

[0001193125-13-422365:notes:19]
A summary of
 warranty expense and write-off activity for the nine months ended
 September 30, 2013 and 2012 is as follows:

[0001193125-13-422365:notes:20]
|  |  | Nine Months Ended |  |
|  |  | September 30, |  |
|  |  | 2013 |  |  | 2012 |  |
| (In thousands) |  |  |  |  |  |  |
| Balance at beginning of period |  | $ | 9,653 |  |  | $ | 4,118 |  |
| Plus: Amounts charged to cost and expenses |  |  | 2,078 |  |  |  | 3,910 |  |
| Amounts assumed on acquisition |  |  | — |  |  |  | 1,932 |  |
| Less: Deductions |  |  | (3,120 | ) |  |  | (2,709 | ) |
| Balance at end of period |  | $ | 8,611 |  |  | $ | 7,251 |  |


## us-gaap:NewAccountingPronouncementsPolicyPolicyTextBlock

[0001193125-13-422365:notes:21]
Recent Accounting Pronouncements

[0001193125-13-422365:notes:22]
During the nine months ended September 30, 2013, we adopted
 the following accounting standard, which had no material effect on
 our consolidated results of operations or financial condition:

[0001193125-13-422365:notes:23]
In February 2013, the FASB issued Accounting Standards Update
 No. 2013-02, Reporting of Amounts Reclassified Out of
 Accumulated Other Comprehensive Income (ASU 2013-02). ASU 2013-02
 requires entities to provide information about the amounts
 reclassified out of accumulated other comprehensive income by
 component either on the face of the financial statements or in the
 footnotes. ASU 2013-02 does not change the current requirements for
 reporting net income or other comprehensive income in the financial
 statements. This update is effective prospectively for reporting
 periods beginning after December 15, 2012. We adopted this
 amendment during the first quarter of 2013, and we have provided
 the disclosures required for the periods ended September 30,
 2013 and 2012 in Note 10 of Notes to Consolidated Financial
 Statements.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-13-422365:notes:24]
[same as prior period, unchanged from 0001193125-13-312256:notes:23]

[0001193125-13-422365:notes:25]
We operate in two reportable segments: (1) the Carrier
 Networks Division and (2) the Enterprise Networks Division. We
 evaluate the performance of our segments based on gross profit;
 therefore, selling, general and administrative expense, research
 and development expenses, interest income and dividend income,
 interest expense, net realized investment gain/loss, other
 income/expense and provision for taxes are reported on an
 entity-wide basis only. There are no inter-segment revenues.

[0001193125-13-422365:notes:26]
The following table presents information about the reported sales
 and gross profit of our reportable segments for the three and nine
 months ended September 30, 2013 and 2012. Asset information by
 reportable segment is not reported, since we do not produce such
 information internally.

[0001193125-13-422365:notes:27]
|  |  | Three Months Ended |  |
|  |  | September 30, 2013 |  |  | September 30, 2012 |  |
| (In thousands) |  | Sales |  |  | Gross Profit |  |  | Sales |  |  | Gross Profit |  |
| Carrier Networks |  | $ | 141,278 |  |  | $ | 63,066 |  |  | $ | 131,942 |  |  | $ | 63,827 |  |
| Enterprise Networks |  |  | 36,126 |  |  |  | 19,481 |  |  |  | 30,183 |  |  |  | 16,145 |  |
| Total |  | $ | 177,404 |  |  | $ | 82,547 |  |  | $ | 162,125 |  |  | $ | 79,972 |  |

[0001193125-13-422365:notes:28]
|  |  | Nine Months Ended |  |
|  |  | September 30, 2013 |  |  | September 30, 2012 |  |
| (In thousands) |  | Sales |  |  | Gross Profit |  |  | Sales |  |  | Gross Profit |  |
| Carrier Networks |  | $ | 374,498 |  |  | $ | 172,570 |  |  | $ | 381,303 |  |  | $ | 195,448 |  |
| Enterprise Networks |  |  | 108,152 |  |  |  | 59,452 |  |  |  | 99,555 |  |  |  | 53,812 |  |
| Total |  | $ | 482,650 |  |  | $ | 232,022 |  |  | $ | 480,858 |  |  | $ | 249,260 |  |

[0001193125-13-422365:notes:29]
Sales by Product

[0001193125-13-422365:notes:30]
Our three major product categories are Carrier Systems, Business
 Networking and Loop Access.

[0001193125-13-422365:notes:31]
Carrier Systems products are used by
 communications service providers to provide data, voice and video
 services to consumers and enterprises. This category includes the
 following product areas and related services:

[0001193125-13-422365:notes:32]
[same as prior period, unchanged from 0001193125-13-312256:notes:31]

[0001193125-13-422365:notes:33]
[same as prior period, unchanged from 0001193125-13-312256:notes:32]

[0001193125-13-422365:notes:34]
[same as prior period, unchanged from 0001193125-13-312256:notes:33]

[0001193125-13-422365:notes:35]
[same as prior period, unchanged from 0001193125-13-312256:notes:34]

[0001193125-13-422365:notes:36]
[same as prior period, unchanged from 0001193125-13-312256:notes:35]

[0001193125-13-422365:notes:37]
[same as prior period, unchanged from 0001193125-13-312256:notes:36]

[0001193125-13-422365:notes:38]
[same as prior period, unchanged from 0001193125-13-312256:notes:37]

[0001193125-13-422365:notes:39]
[same as prior period, unchanged from 0001193125-13-312256:notes:38]

[0001193125-13-422365:notes:40]
[same as prior period, unchanged from 0001193125-13-312256:notes:39]

[0001193125-13-422365:notes:41]
[same as prior period, unchanged from 0001193125-13-312256:notes:40]

[0001193125-13-422365:notes:42]
[same as prior period, unchanged from 0001193125-13-312256:notes:41]

[0001193125-13-422365:notes:43]
[same as prior period, unchanged from 0001193125-13-312256:notes:42]

[0001193125-13-422365:notes:44]
[same as prior period, unchanged from 0001193125-13-312256:notes:43]

[0001193125-13-422365:notes:45]
Business Networking products provide access to
 telecommunication services and facilitate the delivery of cloud
 connectivity, enterprise communications and virtual mobility to the
 small and mid-sized enterprise (SME) market. This category includes
 the following product areas and related services:

[0001193125-13-422365:notes:46]
[same as prior period, unchanged from 0001193125-13-312256:notes:45]

[0001193125-13-422365:notes:47]
[same as prior period, unchanged from 0001193125-13-312256:notes:46]

[0001193125-13-422365:notes:48]
[same as prior period, unchanged from 0001193125-13-312256:notes:47]

[0001193125-13-422365:notes:49]
[same as prior period, unchanged from 0001193125-13-312256:notes:48]

[0001193125-13-422365:notes:50]
[same as prior period, unchanged from 0001193125-13-312256:notes:49]

[0001193125-13-422365:notes:51]
[same as prior period, unchanged from 0001193125-13-312256:notes:50]

[0001193125-13-422365:notes:52]
[same as prior period, unchanged from 0001193125-13-312256:notes:51]

[0001193125-13-422365:notes:53]
[same as prior period, unchanged from 0001193125-13-312256:notes:52]

[0001193125-13-422365:notes:54]
[same as prior period, unchanged from 0001193125-13-312256:notes:53]

[0001193125-13-422365:notes:55]
[same as prior period, unchanged from 0001193125-13-312256:notes:54]

[0001193125-13-422365:notes:56]
[same as prior period, unchanged from 0001193125-13-312256:notes:55]

[0001193125-13-422365:notes:57]
Loop Access products are used by carrier
 and enterprise customers for access to copper-based
 telecommunications networks. The Loop Access category includes the
 following product areas:

[0001193125-13-422365:notes:58]
[same as prior period, unchanged from 0001193125-13-312256:notes:57]

[0001193125-13-422365:notes:59]
[same as prior period, unchanged from 0001193125-13-312256:notes:58]

[0001193125-13-422365:notes:60]
[same as prior period, unchanged from 0001193125-13-312256:notes:59]

[0001193125-13-422365:notes:61]
[same as prior period, unchanged from 0001193125-13-312256:notes:60]

[0001193125-13-422365:notes:62]
[same as prior period, unchanged from 0001193125-13-312256:notes:61]

[0001193125-13-422365:notes:63]
The table below presents sales information by product category for
 the three and nine months ended September 30, 2013 and
 2012:

[0001193125-13-422365:notes:64]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
| Carrier Systems |  | $ | 120,778 |  |  | $ | 111,577 |  |  | $ | 319,119 |  |  | $ | 309,590 |  |
| Business Networking |  |  | 44,213 |  |  |  | 36,600 |  |  |  | 127,668 |  |  |  | 116,332 |  |
| Loop Access |  |  | 12,413 |  |  |  | 13,948 |  |  |  | 35,863 |  |  |  | 54,936 |  |
| Total |  | $ | 177,404 |  |  | $ | 162,125 |  |  | $ | 482,650 |  |  | $ | 480,858 |  |

[0001193125-13-422365:notes:65]
In addition, we identify subcategories of product revenues, which
 we divide into our core products and legacy products. Our core
 products consist of Broadband Access and Optical products (included
 in Carrier Systems) and Internetworking products (included in
 Business Networking). Our legacy products include HDSL products
 (included in Loop Access) and other products not included in the
 aforementioned core products.

[0001193125-13-422365:notes:66]
The table below presents subcategory revenues for the three and
 nine months ended September 30, 2013 and 2012:

[0001193125-13-422365:notes:67]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
| Core Products |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Broadband Access (included in Carrier Systems) |  | $ | 98,132 |  |  | $ | 94,464 |  |  | $ | 251,994 |  |  | $ | 249,988 |  |
| Optical (included in Carrier Systems) |  |  | 16,640 |  |  |  | 11,160 |  |  |  | 41,500 |  |  |  | 39,418 |  |
| Internetworking (included in Business Networking) |  |  | 43,329 |  |  |  | 35,411 |  |  |  | 124,163 |  |  |  | 111,320 |  |
| Subtotal |  |  | 158,101 |  |  |  | 141,035 |  |  |  | 417,657 |  |  |  | 400,726 |  |
| Legacy Products |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| HDSL (does not include T1) (included in Loop Access) |  |  | 11,487 |  |  |  | 12,926 |  |  |  | 33,183 |  |  |  | 51,350 |  |
| Other products (excluding HDSL) |  |  | 7,816 |  |  |  | 8,164 |  |  |  | 31,810 |  |  |  | 28,782 |  |
| Subtotal |  |  | 19,303 |  |  |  | 21,090 |  |  |  | 64,993 |  |  |  | 80,132 |  |
| Total |  | $ | 177,404 |  |  | $ | 162,125 |  |  | $ | 482,650 |  |  | $ | 480,858 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-13-422365:notes:68]
| 15. | COMMITMENTS AND CONTINGENCIES |

[0001193125-13-422365:notes:69]
In the ordinary
 course of business, we may be subject to various legal proceedings
 and claims, including employment disputes, patent claims, disputes
 over contract agreements and other commercial disputes. In some
 cases, claimants seek damages or other relief, such as royalty
 payments related to patents, which, if granted, could require
 significant expenditures. Although the outcome of any claim or
 litigation can never be certain, it is our opinion that the outcome
 of all contingencies of which we are currently aware will not
 materially affect our business, operations, financial condition or
 cash flows.

[0001193125-13-422365:notes:70]
We have
 committed to invest up to an aggregate of $7.9 million in two
 private equity funds, and we have contributed $8.4 million as of
 September 30, 2013, of which $7.7 million has been applied to
 these commitments.


## us-gaap:ScheduleOfDerivativeInstrumentsInStatementOfFinancialPositionFairValueTextBlock

[0001193125-13-422365:notes:71]
The fair values of our derivative instruments recorded in the
 Consolidated Balance Sheet as of September 30, 2013 were as
 follows:

[0001193125-13-422365:notes:72]
|  |  | September 30, 2013 |  |
| (In thousands) |  | Balance Sheet Location |  | Fair Value |  |
| Derivatives Not Designated as Hedging Instruments (Level 2): |  |  |  |  |  |  |
| Foreign exchange contracts – asset derivatives |  | Other receivables |  | $ | 40 |  |
| Foreign exchange contracts – liability derivatives |  | Accounts payable |  | $ | (6 | ) |


## us-gaap:ScheduleOfAccumulatedOtherComprehensiveIncomeLossTableTextBlock

[0001193125-13-422365:notes:73]
The following tables present changes in accumulated other
 comprehensive income, net of tax, by component for the three months
 ended September 30, 2013 and 2012:

[0001193125-13-422365:notes:74]
|  |  | Three Months Ended September 30, 2013 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | Total |  |
| Beginning balance |  | $ | 6,766 |  |  | $ | (1,952 | ) |  | $ | 1,722 |  |  | $ | 6,536 |  |
| Other comprehensive income (loss) before reclassifications |  |  | 3,522 |  |  |  | — |  |  |  | (108 | ) |  |  | 3,414 |  |
| Amounts reclassified from accumulated other comprehensive income |  |  | (960 | ) |  |  | — |  |  |  | — |  |  |  | (960 | ) |
| Net current period other comprehensive income (loss) |  |  | 2,562 |  |  |  | — |  |  |  | (108 | ) |  |  | 2,454 |  |
| Ending balance |  | $ | 9,328 |  |  | $ | (1,952 | ) |  | $ | 1,614 |  |  | $ | 8,990 |  |

[0001193125-13-422365:notes:75]
|  |  | Three Months Ended September 30, 2012 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Foreign Currency Adjustments |  |  | Total |  |
| Beginning balance |  | $ | 11,682 |  |  | $ | 2,999 |  |  | $ | 14,681 |  |
| Other comprehensive income before reclassifications |  |  | 1,905 |  |  |  | 134 |  |  |  | 2,039 |  |
| Amounts reclassified from accumulated other comprehensive income |  |  | (1,408 | ) |  |  | — |  |  |  | (1,408 | ) |
| Net current period other comprehensive income |  |  | 497 |  |  |  | 134 |  |  |  | 631 |  |
| Ending balance |  | $ | 12,179 |  |  | $ | 3,133 |  |  | $ | 15,312 |  |

[0001193125-13-422365:notes:76]
The following tables present changes in accumulated other
 comprehensive income, net of tax, by component for the nine months
 ended September 30, 2013 and 2012:

[0001193125-13-422365:notes:77]
|  |  | Nine Months Ended September 30, 2013 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | Total |  |
| Beginning balance |  | $ | 10,108 |  |  | $ | (1,952 | ) |  | $ | 3,112 |  |  | $ | 11,268 |  |
| Other comprehensive income (loss) before reclassifications |  |  | 3,174 |  |  |  | — |  |  |  | (1,498 | ) |  |  | 1,676 |  |
| Amounts reclassified from accumulated other comprehensive income |  |  | (3,954 | ) |  |  | — |  |  |  | — |  |  |  | (3,954 | ) |
| Net current period other comprehensive (loss) |  |  | (780 | ) |  |  | — |  |  |  | (1,498 | ) |  |  | (2,278 | ) |
| Ending balance |  | $ | 9,328 |  |  | $ | (1,952 | ) |  | $ | 1,614 |  |  | $ | 8,990 |  |

[0001193125-13-422365:notes:78]
|  |  | Nine Months Ended September 30, 2012 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Foreign Currency Adjustments |  |  | Total |  |
| Beginning balance |  | $ | 10,160 |  |  | $ | 2,942 |  |  | $ | 13,102 |  |
| Other comprehensive income before reclassifications |  |  | 6,230 |  |  |  | 191 |  |  |  | 6,421 |  |
| Amounts reclassified from accumulated other comprehensive income |  |  | (4,211 | ) |  |  | — |  |  |  | (4,211 | ) |
| Net current period other comprehensive income |  |  | 2,019 |  |  |  | 191 |  |  |  | 2,210 |  |
| Ending balance |  | $ | 12,179 |  |  | $ | 3,133 |  |  | $ | 15,312 |


## us-gaap:ScheduleOfEntityWideInformationRevenueFromExternalCustomersByProductsAndServicesTextBlock

[0001193125-13-422365:notes:79]
The table below presents
 sales information by product category for the three and nine months
 ended September 30, 2013 and 2012:

[0001193125-13-422365:notes:80]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
| (In thousands) |  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
| Carrier Systems |  | $ | 120,778 |  |  | $ | 111,577 |  |  | $ | 319,119 |  |  | $ | 309,590 |  |
| Business Networking |  |  | 44,213 |  |  |  | 36,600 |  |  |  | 127,668 |  |  |  | 116,332 |  |
| Loop Access |  |  | 12,413 |  |  |  | 13,948 |  |  |  | 35,863 |  |  |  | 54,936 |  |
| Total |  | $ | 177,404 |  |  | $ | 162,125 |  |  | $ | 482,650 |  |  | $ | 480,858 |  |


## us-gaap:ScheduleofFiniteLivedIntangibleAssetsFutureAmortizationExpenseTableTextBlock

[0001193125-13-422365:notes:81]
As of September 30,
 2013, the estimated future amortization expense of our intangible
 assets is as follows:

[0001193125-13-422365:notes:82]
| (In thousands) |  | Amount |  |
| Remainder of 2013 |  | $ | 618 |  |
| 2014 |  |  | 2,315 |  |
| 2015 |  |  | 2,179 |  |
| 2016 |  |  | 1,905 |  |
| 2017 |  |  | 1,291 |  |
| Thereafter |  |  | 2,770 |  |
| Total |  | $ | 11,078 |  |


## us-gaap:ScheduleOfRecognizedIdentifiedAssetsAcquiredAndLiabilitiesAssumedTableTextBlock

[0001193125-13-422365:notes:83]
The allocation of the
 purchase price to the estimated fair value of the assets acquired
 and liabilities assumed at the acquisition date is as
 follows:

[0001193125-13-422365:notes:84]
[same as prior period, unchanged from 0001193125-13-312256:notes:83]


## us-gaap:ScheduleOfCostsOfRetirementPlansTableTextBlock

[0001193125-13-422365:notes:85]
The following table
 summarizes the components of net periodic pension cost for the
 three months ended September 30, 2013 and 2012, the nine
 months ended September 30, 2013, and the period May 4,
 2012 to September 30, 2012:

[0001193125-13-422365:notes:86]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |  | May 4, 2012 to September 30, |  |
| (In thousands) |  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
| Service cost |  | $ | 297 |  |  | $ | 288 |  |  | $ | 891 |  |  | $ | 478 |  |
| Interest cost |  |  | 185 |  |  |  | 187 |  |  |  | 554 |  |  |  | 314 |  |
| Expected return on plan assets |  |  | (250 | ) |  |  | (250 | ) |  |  | (751 | ) |  |  | (415 | ) |
| Net periodic pension cost |  | $ | 232 |  |  | $ | 225 |  |  | $ | 694 |  |  | $ | 377 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001193125-13-422365:notes:87]
We have categorized our
 cash equivalents held in money market funds and our investments
 held at fair value into a three-level fair value hierarchy based on
 the priority of the inputs to the valuation technique for the cash
 equivalents and investments as follows: Level 1 – Values
 based on unadjusted, quoted prices in active markets for identical
 assets or liabilities; Level 2 – Values based on inputs other
 than quoted prices included within Level 1 that are directly or
 indirectly observable for the asset or liability; Level 3 –
 Values based on unobservable inputs for the asset or liability.
 These inputs include information supplied by investees.

[0001193125-13-422365:notes:88]
|  |  | Fair Value Measurements at September 30, 2013 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 6,594 |  |  | $ | 6,594 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 13,780 |  |  |  | 13,780 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 178,141 |  |  |  | — |  |  |  | 178,141 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 145,935 |  |  |  | — |  |  |  | 145,935 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 11,960 |  |  |  | — |  |  |  | 11,960 |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity securities – technology industry |  |  | 9,973 |  |  |  | 9,973 |  |  |  | — |  |  |  | — |  |
| Equity securities – other |  |  | 24,970 |  |  |  | 24,970 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 384,759 |  |  |  | 48,723 |  |  |  | 336,036 |  |  |  | — |  |
| Total |  | $ | 391,353 |  |  | $ | 55,317 |  |  | $ | 336,036 |  |  | $ | — |  |
|  |  | Fair Value Measurements at December 31, 2012 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 28,071 |  |  | $ | 28,071 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 11,527 |  |  |  | 11,527 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 186,412 |  |  |  | — |  |  |  | 186,412 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 175,084 |  |  |  | — |  |  |  | 175,084 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 34,375 |  |  |  | — |  |  |  | 34,375 |  |  |  | — |  |
| Fixed income bond fund |  |  | 456 |  |  |  | 456 |  |  |  | — |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity securities – technology industry |  |  | 14,099 |  |  |  | 14,099 |  |  |  | — |  |  |  | — |  |
| Equity securities – other |  |  | 21,105 |  |  |  | 21,105 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 443,058 |  |  |  | 47,187 |  |  |  | 395,871 |  |  |  | — |  |
| Total |  | $ | 471,129 |  |  | $ | 75,258 |  |  | $ | 395,871 |  |  | $ | — |  |


## us-gaap:ScheduleOfStockholdersEquityTableTextBlock

[0001193125-13-422365:notes:89]
A summary of the changes in
 stockholders’ equity for the nine months ended
 September 30, 2013 is as follows:

[0001193125-13-422365:notes:90]
| (In thousands) |  | Stockholders’ Equity |  |
| Balance, December 31, 2012 |  | $ | 692,406 |  |
| Net income |  |  | 33,954 |  |
| Dividend payments |  |  | (16,220 | ) |
| Dividends accrued for unvested restricted stock units |  |  | (23 | ) |
| Net unrealized gains (losses) on available-for-sale securities (net of tax) |  |  | (780 | ) |
| Foreign currency translation adjustment |  |  | (1,498 | ) |
| Proceeds from stock option exercises |  |  | 2,332 |  |
| Purchase of treasury stock |  |  | (104,147 | ) |
| Income tax benefit from exercise of stock options |  |  | 113 |  |
| Stock-based compensation expense |  |  | 6,516 |  |
| Balance, September 30, 2013 |  | $ | 612,653 |  |


## us-gaap:ConsolidationPolicyTextBlock

[0001193125-13-422365:notes:91]
Basis of
 Presentation

[0001193125-13-422365:notes:92]
The
 accompanying unaudited consolidated financial statements of
 ADTRAN®, Inc. and its
 subsidiaries (ADTRAN) have been prepared pursuant to the rules and
 regulations for reporting on Quarterly Reports on Form 10-Q.
 Accordingly, certain information and notes required by generally
 accepted accounting principles for complete financial statements
 are not included herein. The December 31, 2012 Consolidated
 Balance Sheet is derived from audited financial statements, but
 does not include all disclosures required by accounting principles
 generally accepted in the United States.

[0001193125-13-422365:notes:93]
In the opinion
 of management, all adjustments necessary for a fair presentation of
 these interim statements have been recorded, including the out of
 period adjustment discussed below. The results of operations for an
 interim period are not necessarily indicative of the results for
 the full year. The interim statements should be read in conjunction
 with the financial statements and notes thereto included in
 ADTRAN’s Annual Report on Form 10-K for the year ended
 December 31, 2012, filed on February 28, 2013 with the
 SEC.


## us-gaap:InventoryDisclosureTextBlock

[0001193125-13-422365:notes:94]
[same as prior period, unchanged from 0001193125-13-312256:notes:93]

[0001193125-13-422365:notes:95]
At
 September 30, 2013 and December 31, 2012, inventory
 consisted of the following:

[0001193125-13-422365:notes:96]
|  |  | September 30, |  |  | December 31, |  |
| (In thousands) |  | 2013 |  |  | 2012 |  |
| Raw materials |  | $ | 40,947 |  |  | $ | 47,054 |  |
| Work in process |  |  | 3,562 |  |  |  | 3,262 |  |
| Finished goods |  |  | 48,463 |  |  |  | 52,267 |  |
| Total |  | $ | 92,972 |  |  | $ | 102,583 |  |

[0001193125-13-422365:notes:97]
We establish
 reserves for estimated excess, obsolete, or unmarketable inventory
 equal to the difference between the cost of the inventory and the
 estimated fair value of the inventory based upon assumptions about
 future demand and market conditions. At September 30, 2013 and
 December 31, 2012, raw materials reserves totaled $15.9
 million and $9.9 million, respectively, and finished goods
 inventory reserves totaled $5.0 million and $2.1 million,
 respectively.


## us-gaap:ScheduleOfEarningsPerShareBasicAndDilutedTableTextBlock

[0001193125-13-422365:notes:98]
A summary of the
 calculation of basic and diluted earnings per share for the three
 and nine months ended September 30, 2013 and 2012 is as
 follows:

[0001193125-13-422365:notes:99]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands, except per share amounts) |  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
| Numerator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 16,205 |  |  | $ | 9,272 |  |  | $ | 33,954 |  |  | $ | 43,302 |  |
| Denominator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average number of shares – basic |  |  | 57,947 |  |  |  | 63,066 |  |  |  | 59,561 |  |  |  | 63,495 |  |
| Effect of dilutive securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock options |  |  | 613 |  |  |  | 225 |  |  |  | 321 |  |  |  | 637 |  |
| Restricted stock and restricted stock units |  |  | 57 |  |  |  | 13 |  |  |  | 47 |  |  |  | 7 |  |
| Weighted average number of shares – diluted |  |  | 58,617 |  |  |  | 63,304 |  |  |  | 59,929 |  |  |  | 64,139 |  |
| Net income per share – basic |  | $ | 0.28 |  |  | $ | 0.15 |  |  | $ | 0.57 |  |  | $ | 0.68 |  |
| Net income per share – diluted |  | $ | 0.28 |  |  | $ | 0.15 |  |  | $ | 0.57 |  |  | $ | 0.68 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001193125-13-422365:notes:100]
[same as prior period, unchanged from 0001193125-13-312256:notes:99]

[0001193125-13-422365:notes:101]
A summary of the changes in stockholders’ equity for the nine
 months ended September 30, 2013 is as follows:

[0001193125-13-422365:notes:102]
Stock Repurchase Program

[0001193125-13-422365:notes:103]
Since 1997, our Board of Directors has approved multiple share
 repurchase programs that have authorized open market repurchase
 transactions of up to 35 million shares of our common stock.
 On May 1, 2013, our Board of Directors authorized the
 repurchase of an additional 5.0 million shares of our common
 stock, which commenced upon completion of the repurchase plan
 announced on October 11, 2011. This new authorization is being
 implemented through open market or private purchases from time to
 time as conditions warrant.

[0001193125-13-422365:notes:104]
During the nine months ended September 30, 2013, we
 repurchased 4.8 million shares of our common stock at an
 average price of $21.89 per share. We currently have the authority
 to purchase an additional 4.3 million shares of our common
 stock under the current plan approved by the Board of Directors on
 May 1, 2013.

[0001193125-13-422365:notes:105]
Stock Option Exercises

[0001193125-13-422365:notes:106]
We issued 0.1 million shares of treasury stock during the nine
 months ended September 30, 2013 to accommodate employee stock
 option exercises. The stock options had exercise prices ranging
 from $15.29 to $26.06. We received proceeds totaling $2.3 million
 from the exercise of these stock options during the nine months
 ended September 30, 2013.

[0001193125-13-422365:notes:107]
Dividend Payments

[0001193125-13-422365:notes:108]
During the nine months ended September 30, 2013, we paid cash
 dividends as follows (in thousands except per share amounts):

[0001193125-13-422365:notes:109]
| Record Date |  | Payment Date |  | Per Share Amount |  |  | Total Dividend Paid |  |
| February 7, 2013 |  | February 21, 2013 |  | $ | 0.09 |  |  | $ | 5,586 |  |
| April 25, 2013 |  | May 9, 2013 |  | $ | 0.09 |  |  | $ | 5,396 |  |
| July 25, 2013 |  | August 8, 2013 |  | $ | 0.09 |  |  | $ | 5,238 |  |

[0001193125-13-422365:notes:110]
Other Comprehensive Income

[0001193125-13-422365:notes:111]
Other comprehensive income consists of unrealized gains (losses) on
 available-for-sale securities, reclassification adjustments for
 amounts included in net income related to impairments of
 available-for-sale securities and realized gains (losses) on
 available-for-sale securities, defined benefit plan adjustments and
 foreign currency translation adjustments.

[0001193125-13-422365:notes:112]
|  |  | Nine Months Ended September 30, 2012 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Foreign Currency Adjustments |  |  | Total |  |
| Beginning balance |  | $ | 10,160 |  |  | $ | 2,942 |  |  | $ | 13,102 |  |
| Other comprehensive income before reclassifications |  |  | 6,230 |  |  |  | 191 |  |  |  | 6,421 |  |
| Amounts reclassified from accumulated other comprehensive income |  |  | (4,211 | ) |  |  | — |  |  |  | (4,211 | ) |
| Net current period other comprehensive income |  |  | 2,019 |  |  |  | 191 |  |  |  | 2,210 |  |
| Ending balance |  | $ | 12,179 |  |  | $ | 3,133 |  |  | $ | 15,312 |  |

[0001193125-13-422365:notes:113]
The following tables present the details of reclassifications out
 of accumulated other comprehensive income for the three months
 ended September 30, 2013 and 2012:

[0001193125-13-422365:notes:114]
| (In thousands) |  | Three Months Ended September 30, 2013 |
| Details about Accumulated Other Comprehensive Income Components |  | Amount Reclassified from Accumulated Other Comprehensive Income |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for-sale securities: |  |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 1,583 |  |  | Net realized investment gain |
| Impairment expense |  |  | (9 | ) |  | Net realized investment gain |
| Total reclassifications for the period, before tax |  |  | 1,574 |  |  |  |
| Tax (expense) benefit |  |  | (614 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 960 |  |  |  |

[0001193125-13-422365:notes:115]
| (In thousands) |  | Three Months Ended September 30, 2012 |
| Details about Accumulated Other Comprehensive Income Components |  | Amount Reclassified from Accumulated Other Comprehensive Income |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for-sale securities: |  |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 2,939 |  |  | Net realized investment gain |
| Impairment expense |  |  | (631 | ) |  | Net realized investment gain |
| Total reclassifications for the period, before tax |  |  | 2,308 |  |  |  |
| Tax (expense) benefit |  |  | (900 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 1,408 |  |  |  |

[0001193125-13-422365:notes:116]
The following tables present the details of reclassifications out
 of accumulated other comprehensive income for the nine months ended
 September 30, 2013 and 2012:

[0001193125-13-422365:notes:117]
| (In thousands) |  | Nine Months Ended September 30, 2013 |
| Details about Accumulated Other Comprehensive Income Components |  | Amount Reclassified from Accumulated Other Comprehensive Income |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for-sale securities: |  |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 6,496 |  |  | Net realized investment gain |
| Impairment expense |  |  | (13 | ) |  | Net realized investment gain |
| Total reclassifications for the period, before tax |  |  | 6,483 |  |  |  |
| Tax (expense) benefit |  |  | (2,529 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 3,954 |  |  |  |

[0001193125-13-422365:notes:118]
| (In thousands) |  | Nine Months Ended September 30, 2012 |
| Details about Accumulated Other Comprehensive Income Components |  | Amount Reclassified from Accumulated Other Comprehensive Income |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for-sale securities: |  |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 7,567 |  |  | Net realized investment gain |
| Impairment expense |  |  | (664 | ) |  | Net realized investment gain |
| Total reclassifications for the period, before tax |  |  | 6,903 |  |  |  |
| Tax (expense) benefit |  |  | (2,692 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 4,211 |  |  |  |

[0001193125-13-422365:notes:119]
The following table presents the tax effects related to the change
 in each component of other comprehensive income for the three
 months ended September 30, 2013 and 2012:

[0001193125-13-422365:notes:120]
|  |  | Three Months Ended September 30, 2013 |  |  | Three Months Ended September 30, 2012 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |
| Unrealized gains (losses) on available-for-sale securities |  | $ | 5,774 |  |  | $ | (2,252 | ) |  | $ | 3,522 |  |  | $ | 3,123 |  |  | $ | (1,218 | ) |  | $ | 1,905 |  |
| Reclassification adjustment for amounts included in net income |  |  | (1,574 | ) |  |  | 614 |  |  |  | (960 | ) |  |  | (2,308 | ) |  |  | 900 |  |  |  | (1,408 | ) |
| Foreign currency translation adjustment |  |  | (108 | ) |  |  | — |  |  |  | (108 | ) |  |  | 134 |  |  |  | — |  |  |  | 134 |  |
| Total Other Comprehensive Income (Loss) |  | $ | 4,092 |  |  | $ | (1,638 | ) |  | $ | 2,454 |  |  | $ | 949 |  |  | $ | (318 | ) |  | $ | 631 |  |

[0001193125-13-422365:notes:121]
The following table presents the tax effects related to the change
 in each component of other comprehensive income for the nine months
 ended September 30, 2013 and 2012:

[0001193125-13-422365:notes:122]
|  |  | Nine Months Ended September 30, 2013 |  |  | Nine Months Ended September 30, 2012 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |
| Unrealized gains (losses) on available-for-sale securities |  | $ | 5,203 |  |  | $ | (2,029 | ) |  | $ | 3,174 |  |  | $ | 10,213 |  |  | $ | (3,983 | ) |  | $ | 6,230 |  |
| Reclassification adjustment for amounts included in net income |  |  | (6,483 | ) |  |  | 2,529 |  |  |  | (3,954 | ) |  |  | (6,903 | ) |  |  | 2,692 |  |  |  | (4,211 | ) |
| Foreign currency translation adjustment |  |  | (1,498 | ) |  |  | — |  |  |  | (1,498 | ) |  |  | 191 |  |  |  | — |  |  |  | 191 |  |
| Total Other Comprehensive Income (Loss) |  | $ | (2,778 | ) |  | $ | 500 |  |  | $ | (2,278 | ) |  | $ | 3,501 |  |  | $ | (1,291 | ) |  | $ | 2,210 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001193125-13-422365:notes:123]
At September 30, 2013
 and December 31, 2012, inventory consisted of the
 following:

[0001193125-13-422365:notes:124]
| (In thousands) |  | September 30, 2013 |  |  | December 31, 2012 |  |
| Raw materials |  | $ | 40,947 |  |  | $ | 47,054 |  |
| Work in process |  |  | 3,562 |  |  |  | 3,262 |  |
| Finished goods |  |  | 48,463 |  |  |  | 52,267 |  |
| Total |  | $ | 92,972 |  |  | $ | 102,583 |  |


## us-gaap:InvestmentsClassifiedByContractualMaturityDateTableTextBlock

[0001193125-13-422365:notes:125]
As of September 30,
 2013, our corporate bonds and municipal fixed-rate bonds had the
 following contractual maturities:

[0001193125-13-422365:notes:126]
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |
| Less than one year |  | $ | 66,267 |  |  | $ | 58,413 |  |
| One to two years |  |  | 32,231 |  |  |  | 18,638 |  |
| Two to three years |  |  | 76,460 |  |  |  | 58,389 |  |
| Three to five years |  |  | 3,183 |  |  |  | 10,495 |  |
| Total |  | $ | 178,141 |  |  | $ | 145,935 |  |


## us-gaap:ScheduleOfRealizedGainLossTableTextBlock

[0001193125-13-422365:notes:127]
The following table
 presents gross realized gains and losses related to our
 investments.

[0001193125-13-422365:notes:128]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
| (In thousands) |  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
| Gross realized gains |  | $ | 1,797 |  |  | $ | 3,388 |  |  | $ | 7,252 |  |  | $ | 8,688 |  |
| Gross realized losses |  | $ | (46 | ) |  | $ | (858 | ) |  | $ | (303 | ) |  | $ | (1,335 | ) |


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001193125-13-422365:notes:129]
[same as prior period, unchanged from 0001193125-13-312256:notes:126]

[0001193125-13-422365:notes:130]
We have certain international customers who are billed in their
 local currency. Changes in the monetary exchange rates may
 adversely affect our results of operations and financial condition.
 When appropriate, we enter into various derivative transactions to
 enhance our ability to manage the volatility relating to these
 typical business exposures. We do not hold or issue derivative
 instruments for trading or other speculative purposes. Our
 derivative instruments are recorded in the Consolidated Balance
 Sheets at their fair values. Our derivative instruments do not
 qualify for hedge accounting, and accordingly, all changes in the
 fair value of the instruments are recognized as other income
 (expense) in the Consolidated Statements of Income. The maximum
 contractual period for our derivatives is currently less than
 twelve months. Our derivative instruments are not subject to master
 netting arrangements and are not offset in the Consolidated Balance
 Sheets.

[0001193125-13-422365:notes:131]
As of September 30, 2013, we had forward contracts outstanding
 with notional amounts totaling €19.8 million ($26.8
 million), which mature through 2013.

[0001193125-13-422365:notes:132]
The change in the fair values of our derivative instruments
 recorded in the Consolidated Statements of Income during the three
 and nine months ended September 30, 2013 were as follows:

[0001193125-13-422365:notes:133]
| (In thousands) |  | Income Statement Location |  | Three Months Ended September 30, 2013 |  |  | Nine Months Ended September 30, 2013 |  |
| Derivatives Not Designated as Hedging Instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Other income (expense) |  | $ | 52 |  |  | $ | (34 | ) |


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001193125-13-422365:notes:134]
[same as prior period, unchanged from 0001193125-13-312256:notes:132]

[0001193125-13-422365:notes:135]
On May 4,
 2012, we acquired the NSN BBA business. This acquisition provides
 us with an established customer base in key markets and
 complementary, market-focused products and was accounted for as a
 business combination. We have included the financial results of the
 NSN BBA business in our consolidated financial statements since the
 date of acquisition. These revenues are included in the Carrier
 Networks division in the Broadband Access subcategory.

[0001193125-13-422365:notes:136]
We received a
 cash payment of $7.5 million from NSN and recorded a bargain
 purchase gain of $1.8 million, net of income taxes, in the second
 quarter of 2012, subject to customary working capital adjustments
 between the parties as defined in the purchase agreement. As of
 September 30, 2013, the parties were in the process of
 resolving the working capital adjustments. We adjusted the purchase
 price allocation during the fourth quarter of 2012 to record
 additional estimated liabilities and an estimated receivable from
 NSN related to working capital adjustments under negotiation. The
 bargain purchase gain of $1.8 million represents the excess of the
 consideration exchanged over the fair value of the assets acquired
 and liabilities assumed. We have assessed the recognition and
 measurements of the assets acquired and liabilities assumed based
 on historical and pro forma data for future periods and have
 concluded that our valuation procedures and resulting measures were
 appropriate.

[0001193125-13-422365:notes:137]
The allocation
 of the purchase price to the estimated fair value of the assets
 acquired and liabilities assumed at the acquisition date is as
 follows:

[0001193125-13-422365:notes:138]
The fair value
 of the customer relationships acquired was calculated using a
 discounted cash flow method (excess earnings) and is being
 amortized using a declining balance method derived from projected
 customer revenue over an average estimated useful life of 13 years.
 The fair value of the developed technology acquired was calculated
 using a discounted cash flow method (relief from royalty) and is
 being amortized using the straight-line method over an estimated
 useful life of five years.

[0001193125-13-422365:notes:139]
The following
 supplemental pro forma information presents the financial results
 of the acquired NSN BBA business for the nine months ended
 September 30, 2012. The pro forma results for the period
 January 1, 2012 to May 4, 2012 are not included in our
 consolidated financial statements.

[0001193125-13-422365:notes:140]
This
 supplemental pro forma information does not purport to be
 indicative of what would have occurred had the acquisition of the
 NSN BBA business been completed on January 1, 2012, nor are
 they indicative of any future results.

[0001193125-13-422365:notes:141]
|  |  | Nine Months Ended |  |
| (In thousands) |  | September 30, 2012 |  |
| Pro forma revenue |  | $ | 100,413 |  |
| Pro forma pre-tax loss |  | $ | (18,006 | ) |
| Weighted average exchange rate during the period (EURO/USD) |  | € | 1.00/$1.29 |  |

[0001193125-13-422365:notes:142]
For the three
 and nine months ended September 30, 2013, we incurred
 acquisition and integration related expenses and amortization of
 acquired intangibles of $0.6 million and $2.2 million related to
 this acquisition.


## us-gaap:ScheduleOfGoodwillTextBlock

[0001193125-13-422365:notes:143]
The change in the carrying
 value of goodwill, all of which is included in our Enterprise
 Networks division, for the nine months ended September 30,
 2013 is as follows:

[0001193125-13-422365:notes:144]
| (In thousands) |  |  |  |
| Balance, December 31, 2012 |  | $ | 3,492 |  |
| Acquisitions |  |  | — |  |
| Impairment losses |  |  | — |  |
| Balance, September 30, 2013 |  | $ | 3,492 |  |
| Balance as of September 30, 2013 |  |  |  |  |
| Goodwill |  | $ | 3,492 |  |
| Accumulated impairment losses |  |  | — |  |
| Total goodwill |  | $ | 3,492 |  |


## us-gaap:SubsequentEventsTextBlock

[0001193125-13-422365:notes:145]
| 16. | SUBSEQUENT EVENTS |

[0001193125-13-422365:notes:146]
On October 8, 2013, we announced that our Board of Directors
 declared a quarterly cash dividend of $0.09 per common share to be
 paid to stockholders of record at the close of business on
 October 24, 2013. The payment date will be November 7,
 2013. The quarterly dividend payment will be approximately $5.2
 million. In July 2003, our Board of Directors elected to begin
 declaring quarterly dividends on our common stock considering the
 tax treatment of dividends and adequate levels of Company
 liquidity.

[0001193125-13-422365:notes:147]
During the fourth quarter of 2013 and as of November 1, 2013,
 we repurchased 0.4 million shares of our common stock through
 open market purchases at an average cost of $23.85 per share. We
 currently have the authority to purchase an additional 3.9 million
 shares of our common stock under the current plan approved by the
 Board of Directors.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-13-422365:notes:148]
[same as prior period, unchanged from 0001193125-13-312256:notes:144]

[0001193125-13-422365:notes:149]
Our effective tax rate decreased from 34.9% in the nine months
 ended September 30, 2012 to 27.0% in the nine months ended
 September 30, 2013. The decrease in the effective tax
 rate between the two periods is primarily attributable to an
 acquired business that incurred losses in the prior year for which
 no tax benefit was recognized and the improved profitability for
 that business in the current year, the net effect of recording the
 benefit for the research tax credit for the 2012 tax year in
 January 2013 pursuant to the American Taxpayer Relief Act of 2012,
 and the inclusion of the benefit of the estimated 2013 research tax
 credit in the estimated annual effective rate for 2013.


## us-gaap:ScheduleOfAvailableForSaleSecuritiesReconciliationTableTextBlock

[0001193125-13-422365:notes:150]
At September 30, 2013,
 we held the following securities and investments, recorded at
 either fair value or cost.

[0001193125-13-422365:notes:151]
| (In thousands) |  | Amortized |  |  | Gross Unrealized |  |  | Carrying |  |
|  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Deferred compensation plan assets |  | $ | 11,308 |  |  | $ | 2,490 |  |  | $ | (18 | ) |  | $ | 13,780 |  |
| Corporate bonds |  |  | 177,798 |  |  |  | 446 |  |  |  | (103 | ) |  |  | 178,141 |  |
| Municipal fixed-rate bonds |  |  | 145,509 |  |  |  | 497 |  |  |  | (71 | ) |  |  | 145,935 |  |
| Municipal variable rate demand notes |  |  | 11,960 |  |  |  | — |  |  |  | — |  |  |  | 11,960 |  |
| Marketable equity securities |  |  | 22,825 |  |  |  | 12,393 |  |  |  | (275 | ) |  |  | 34,943 |  |
| Available-for-sale securities held at fair value |  | $ | 369,400 |  |  | $ | 15,826 |  |  | $ | (467 | ) |  | $ | 384,759 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 48,250 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1,753 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 434,762 |  |

[0001193125-13-422365:notes:152]
At December 31, 2012,
 we held the following securities and investments, recorded at
 either fair value or cost.

[0001193125-13-422365:notes:153]
| (In thousands) |  | Amortized |  |  | Gross Unrealized |  |  | Carrying |  |
|  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Deferred compensation plan assets |  | $ | 10,688 |  |  | $ | 846 |  |  | $ | (7 | ) |  | $ | 11,527 |  |
| Corporate bonds |  |  | 185,464 |  |  |  | 966 |  |  |  | (18 | ) |  |  | 186,412 |  |
| Municipal fixed-rate bonds |  |  | 174,530 |  |  |  | 627 |  |  |  | (73 | ) |  |  | 175,084 |  |
| Municipal variable rate demand notes |  |  | 34,375 |  |  |  | — |  |  |  | — |  |  |  | 34,375 |  |
| Fixed income bond fund |  |  | 444 |  |  |  | 12 |  |  |  | — |  |  |  | 456 |  |
| Marketable equity securities |  |  | 20,966 |  |  |  | 14,630 |  |  |  | (392 | ) |  |  | 35,204 |  |
| Available-for-sale securities held at fair value |  | $ | 426,467 |  |  | $ | 17,081 |  |  | $ | (490 | ) |  | $ | 443,058 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 48,250 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1,902 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 493,210 |  |


## us-gaap:BusinessAcquisitionProFormaInformationTextBlock

[0001193125-13-422365:notes:154]
This supplemental pro forma
 information does not purport to be indicative of what would have
 occurred had the acquisition of the NSN BBA business been completed
 on January 1, 2012, nor are they indicative of any future
 results.

[0001193125-13-422365:notes:155]
| (In thousands) |  | Nine Months Ended September 30, 2012 |  |
| Pro forma revenue |  | $ | 100,413 |  |
| Pro forma pre-tax loss |  | $ | (18,006 | ) |
| Weighted average exchange rate during the period (EURO/USD) |  | € | 1.00/$1.29 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001193125-13-422365:notes:156]
[same as prior period, unchanged from 0001193125-13-312256:notes:150]

[0001193125-13-422365:notes:157]
As a result of
 our acquisition of the NSN BBA business, we assumed a defined
 benefit obligation of $17.0 million as of May 4, 2012. We
 established a Contribution Trust Arrangement (CTA) to hold the
 pension assets, and NSN transferred assets to us equal to the
 defined benefit obligation.

[0001193125-13-422365:notes:158]
The following
 table summarizes the components of net periodic pension cost for
 the three months ended September 30, 2013 and 2012, the nine
 months ended September 30, 2013, and the period May 4,
 2012 to September 30, 2012:

[0001193125-13-422365:notes:159]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |  | May 4, 2012 to |  |
|  |  | September 30, |  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
| Service cost |  | $ | 297 |  |  | $ | 288 |  |  | $ | 891 |  |  | $ | 478 |  |
| Interest cost |  |  | 185 |  |  |  | 187 |  |  |  | 554 |  |  |  | 314 |  |
| Expected return on plan assets |  |  | (250 | ) |  |  | (250 | ) |  |  | (751 | ) |  |  | (415 | ) |
| Net periodic pension cost |  | $ | 232 |  |  | $ | 225 |  |  | $ | 694 |  |  | $ | 377 |  |


## us-gaap:EarningsPerShareTextBlock

[0001193125-13-422365:notes:160]
[same as prior period, unchanged from 0001193125-13-312256:notes:152]

[0001193125-13-422365:notes:161]
A summary of
 the calculation of basic and diluted earnings per share for the
 three and nine months ended September 30, 2013 and 2012 is as
 follows:

[0001193125-13-422365:notes:162]
Anti-dilutive
 options to purchase common stock outstanding were excluded from the
 above calculations. Anti-dilutive options totaled
 2.5 million and 4.4 million for the three months ended
 September 30, 2013 and 2012, respectively, and
 3.3 million and 2.6 million for the nine months ended
 September 30, 2013 and 2012, respectively.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001193125-13-422365:notes:163]
| 14. | RELATED PARTY TRANSACTIONS |

[0001193125-13-422365:notes:164]
We employ the
 law firm of our director emeritus for legal services. All bills for
 services rendered by this firm are reviewed and approved by our
 Chief Financial Officer. We believe that the fees for such services
 are comparable to those charged by other firms for services
 rendered to us. For the three and nine month periods ended
 September 30, 2013 and 2012, we incurred fees of $10 thousand
 per month for these legal services.


## us-gaap:ScheduleOfFiniteLivedIntangibleAssetsTableTextBlock

[0001193125-13-422365:notes:165]
The following table
 presents our intangible assets as of September 30, 2013 and
 December 31, 2012:

[0001193125-13-422365:notes:166]
| (In thousands) |  | September 30, 2013 |  |  | December 31, 2012 |  |
|  |  | Gross Value |  |  | Accumulated Amortization |  |  | Net Value |  |  | Gross Value |  |  | Accumulated Amortization |  |  | Net Value |  |
| Customer relationships |  | $ | 6,906 |  |  | $ | (1,348 | ) |  | $ | 5,558 |  |  | $ | 6,769 |  |  | $ | (766 | ) |  | $ | 6,003 |  |
| Developed technology |  |  | 6,481 |  |  |  | (2,347 | ) |  |  | 4,134 |  |  |  | 6,397 |  |  |  | (1,354 | ) |  |  | 5,043 |  |
| Intellectual property |  |  | 2,340 |  |  |  | (1,102 | ) |  |  | 1,238 |  |  |  | 2,340 |  |  |  | (851 | ) |  |  | 1,489 |  |
| Trade names |  |  | 270 |  |  |  | (130 | ) |  |  | 140 |  |  |  | 270 |  |  |  | (85 | ) |  |  | 185 |  |
| Other |  |  | 14 |  |  |  | (6 | ) |  |  | 8 |  |  |  | 13 |  |  |  | (3 | ) |  |  | 10 |  |
| Total |  | $ | 16,011 |  |  | $ | (4,933 | ) |  | $ | 11,078 |  |  | $ | 15,789 |  |  | $ | (3,059 | ) |  | $ | 12,730 |  |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001193125-13-422365:notes:167]
[same as prior period, unchanged from 0001193125-13-312256:notes:158]

[0001193125-13-422365:notes:168]
Basis of Presentation

[0001193125-13-422365:notes:169]
The accompanying unaudited consolidated financial statements of
 ADTRAN®, Inc. and its
 subsidiaries (ADTRAN) have been prepared pursuant to the rules and
 regulations for reporting on Quarterly Reports on Form 10-Q.
 Accordingly, certain information and notes required by generally
 accepted accounting principles for complete financial statements
 are not included herein. The December 31, 2012 Consolidated
 Balance Sheet is derived from audited financial statements, but
 does not include all disclosures required by accounting principles
 generally accepted in the United States.

[0001193125-13-422365:notes:170]
In the opinion of management, all adjustments necessary for a fair
 presentation of these interim statements have been recorded,
 including the out of period adjustment discussed below. The results
 of operations for an interim period are not necessarily indicative
 of the results for the full year. The interim statements should be
 read in conjunction with the financial statements and notes thereto
 included in ADTRAN’s Annual Report on Form 10-K for the year
 ended December 31, 2012, filed on February 28, 2013 with
 the SEC.

[0001193125-13-422365:notes:171]
Changes in Classifications

[0001193125-13-422365:notes:172]
Certain changes in classifications have been made to the prior
 period balances in other comprehensive income to conform to the
 current period’s presentation as a result of our adoption of
 Accounting Standards Update No. 2013-02, Reporting of Amounts
 Reclassified Out of Accumulated Comprehensive Income.

[0001193125-13-422365:notes:173]
Out of Period Adjustment

[0001193125-13-422365:notes:174]
During the three months ended September 30, 2013, we
 identified two adjustments in the acquired Nokia Siemens Networks
 Broadband Access business (NSN BBA business) relating to customer
 payment discounts for one customer, and recoverable VAT taxes on
 certain vendor freight invoices that should have been recorded in
 prior periods. These adjustments resulted from a $0.4 million
 understatement of net income in 2012 and $0.5 million
 understatement of net income in the first two quarters of 2013. We
 evaluated the impact of the adjustments on the results of our
 previously issued financial statements for each of the prior
 periods affected and concluded that the impact was not material. We
 also evaluated the impact of the cumulative effect of the
 adjustments in the current year and concluded that the impact is
 not material to our projected results for the year 2013.
 Accordingly, during the three months ended September 30, 2013
 we recorded an out of period adjustment to correct these
 issues.

[0001193125-13-422365:notes:175]
Use of Estimates

[0001193125-13-422365:notes:176]
The preparation of financial statements in conformity with
 accounting principles generally accepted in the United States of
 America requires management to make estimates and assumptions that
 affect the reported amounts of assets and liabilities, the
 disclosure of contingent assets and liabilities at the date of the
 financial statements, and the reported amounts of revenue and
 expense during the reporting period. Our more significant estimates
 include the allowance for doubtful accounts, obsolete and excess
 inventory reserves, warranty reserves, customer rebates, allowance
 for sales returns, determination of the deferred revenue components
 of multiple element sales agreements, estimated costs to complete
 obligations associated with deferred revenues, estimated income tax
 contingencies, the fair value of stock-based compensation,
 impairment of goodwill, valuation and estimated lives of intangible
 assets, estimated working capital adjustments under negotiation
 related to the Nokia Siemens Networks Broadband Access business
 acquisition, and the evaluation of other-than-temporary declines in
 the value of investments. Actual amounts could differ significantly
 from these estimates.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001193125-13-422365:notes:177]
| 6. | INVESTMENTS |

[0001193125-13-422365:notes:178]
At September 30, 2013, we held the following securities and
 investments, recorded at either fair value or cost.

[0001193125-13-422365:notes:179]
| (In thousands) |  | Amortized Cost |  |  | Gross Unrealized |  |  | Carrying Value |  |
|  |  | Gains |  |  | Losses |  |  |
| Deferred compensation plan assets |  | $ | 11,308 |  |  | $ | 2,490 |  |  | $ | (18 | ) |  | $ | 13,780 |  |
| Corporate bonds |  |  | 177,798 |  |  |  | 446 |  |  |  | (103 | ) |  |  | 178,141 |  |
| Municipal fixed-rate bonds |  |  | 145,509 |  |  |  | 497 |  |  |  | (71 | ) |  |  | 145,935 |  |
| Municipal variable rate demand notes |  |  | 11,960 |  |  |  | — |  |  |  | — |  |  |  | 11,960 |  |
| Marketable equity securities |  |  | 22,825 |  |  |  | 12,393 |  |  |  | (275 | ) |  |  | 34,943 |  |
| Available-for-sale securities held at fair value |  | $ | 369,400 |  |  | $ | 15,826 |  |  | $ | (467 | ) |  | $ | 384,759 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 48,250 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1,753 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 434,762 |  |

[0001193125-13-422365:notes:180]
At December 31, 2012, we held the following securities and
 investments, recorded at either fair value or cost.

[0001193125-13-422365:notes:181]
| (In thousands) |  | Amortized Cost |  |  | Gross Unrealized |  |  | Carrying Value |  |
|  |  | Gains |  |  | Losses |  |  |
| Deferred compensation plan assets |  | $ | 10,688 |  |  | $ | 846 |  |  | $ | (7 | ) |  | $ | 11,527 |  |
| Corporate bonds |  |  | 185,464 |  |  |  | 966 |  |  |  | (18 | ) |  |  | 186,412 |  |
| Municipal fixed-rate bonds |  |  | 174,530 |  |  |  | 627 |  |  |  | (73 | ) |  |  | 175,084 |  |
| Municipal variable rate demand notes |  |  | 34,375 |  |  |  | — |  |  |  | — |  |  |  | 34,375 |  |
| Fixed income bond fund |  |  | 444 |  |  |  | 12 |  |  |  | — |  |  |  | 456 |  |
| Marketable equity securities |  |  | 20,966 |  |  |  | 14,630 |  |  |  | (392 | ) |  |  | 35,204 |  |
| Available-for-sale securities held at fair value |  | $ | 426,467 |  |  | $ | 17,081 |  |  | $ | (490 | ) |  | $ | 443,058 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 48,250 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1,902 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 493,210 |  |

[0001193125-13-422365:notes:182]
As of September 30, 2013, our corporate bonds and municipal
 fixed-rate bonds had the following contractual maturities:

[0001193125-13-422365:notes:183]
Our investment policy provides limitations for issuer
 concentration, which limits, at the time of purchase, the
 concentration in any one issuer to 5% of the market value of our
 total investment portfolio.

[0001193125-13-422365:notes:184]
At September 30, 2013, we held a $48.3 million restricted
 certificate of deposit, which is carried at cost. This investment
 serves as a collateral deposit against the principal amount
 outstanding under loans made to ADTRAN pursuant to an Alabama State
 Industrial Development Authority revenue bond (the Bond). At
 September 30, 2013, the estimated fair value of the Bond using
 a level 2 valuation technique was approximately $44.9 million,
 based on a debt security with a comparable interest rate and
 maturity and a Standard and Poor’s credit rating of A-. For
 more information on the Bond, see “Debt” under
 “Liquidity and Capital Resources” in the
 “Management’s Discussion and Analysis of Financial
 Condition and Results of Operations” contained in Item 2
 of Part I of this report.

[0001193125-13-422365:notes:185]
We review our investment portfolio for potential
 “other-than-temporary” declines in value on an
 individual investment basis. We assess, on a quarterly basis,
 significant declines in value which may be considered
 other-than-temporary and, if necessary, recognize and record the
 appropriate charge to write-down the carrying value of such
 investments. In making this assessment, we take into consideration
 qualitative and quantitative information, including but not limited
 to the following: the magnitude and duration of historical declines
 in market prices, credit rating activity, assessments of liquidity,
 public filings, and statements made by the issuer. We generally
 begin our identification of potential other-than-temporary
 impairments by reviewing any security with a fair value that has
 declined from its original or adjusted cost basis by 25% or more
 for six or more consecutive months. We then evaluate the individual
 security based on the previously identified factors to determine
 the amount of the write-down, if any. As a result of our review, we
 recorded an other-than-temporary impairment charge of $13 thousand
 during the nine months ended September 30, 2013 related to
 five marketable securities. For the nine months ended
 September 30, 2012, we recorded an other-than-temporary
 impairment charge of $0.1 million related to 21 marketable equity
 securities.

[0001193125-13-422365:notes:186]
Realized gains and losses on sales of securities are computed under
 the specific identification method. The following table presents
 gross realized gains and losses related to our investments.

[0001193125-13-422365:notes:187]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
| Gross realized gains |  | $ | 1,797 |  |  | $ | 3,388 |  |  | $ | 7,252 |  |  | $ | 8,688 |  |
| Gross realized losses |  | $ | (46 | ) |  | $ | (858 | ) |  | $ | (303 | ) |  | $ | (1,335 | ) |

[0001193125-13-422365:notes:188]
As of September 30, 2013 and 2012, gross unrealized losses
 related to individual securities in a continuous loss position for
 12 months or longer were not significant.

[0001193125-13-422365:notes:189]
We have categorized our cash equivalents held in money market funds
 and our investments held at fair value into a three-level fair
 value hierarchy based on the priority of the inputs to the
 valuation technique for the cash equivalents and investments as
 follows: Level 1 – Values based on unadjusted, quoted prices
 in active markets for identical assets or liabilities; Level 2
 – Values based on inputs other than quoted prices included
 within Level 1 that are directly or indirectly observable for the
 asset or liability; Level 3 – Values based on
 unobservable inputs for the asset or liability. These inputs
 include information supplied by investees.

[0001193125-13-422365:notes:190]
|  |  | Fair Value Measurements at September 30, 2013 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 6,594 |  |  | $ | 6,594 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 13,780 |  |  |  | 13,780 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 178,141 |  |  |  | — |  |  |  | 178,141 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 145,935 |  |  |  | — |  |  |  | 145,935 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 11,960 |  |  |  | — |  |  |  | 11,960 |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity securities – technology industry |  |  | 9,973 |  |  |  | 9,973 |  |  |  | — |  |  |  | — |  |
| Equity securities – other |  |  | 24,970 |  |  |  | 24,970 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 384,759 |  |  |  | 48,723 |  |  |  | 336,036 |  |  |  | — |  |
| Total |  | $ | 391,353 |  |  | $ | 55,317 |  |  | $ | 336,036 |  |  | $ | — |  |

[0001193125-13-422365:notes:191]
|  |  | Fair Value Measurements at December 31, 2012 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 28,071 |  |  | $ | 28,071 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 11,527 |  |  |  | 11,527 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 186,412 |  |  |  | — |  |  |  | 186,412 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 175,084 |  |  |  | — |  |  |  | 175,084 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 34,375 |  |  |  | — |  |  |  | 34,375 |  |  |  | — |  |
| Fixed income bond fund |  |  | 456 |  |  |  | 456 |  |  |  | — |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity securities – technology industry |  |  | 14,099 |  |  |  | 14,099 |  |  |  | — |  |  |  | — |  |
| Equity securities – other |  |  | 21,105 |  |  |  | 21,105 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 443,058 |  |  |  | 47,187 |  |  |  | 395,871 |  |  |  | — |  |
| Total |  | $ | 471,129 |  |  | $ | 75,258 |  |  | $ | 395,871 |  |  | $ | — |  |

[0001193125-13-422365:notes:192]
The fair value of our Level 2 securities is calculated using a
 weighted average market price for each security. Market prices are
 obtained from a variety of industry standard data providers,
 security master files from large financial institutions, and other
 third-party sources. These multiple market prices are used as
 inputs into a distribution-curve-based algorithm to determine the
 daily market value of each security.

[0001193125-13-422365:notes:193]
Our municipal variable rate demand notes have a structure that
 implies a standard expected market price. The frequent interest
 rate resets make it reasonable to expect the price to stay at par.
 These securities are priced at the expected market price.


## us-gaap:GoodwillDisclosureTextBlock

[0001193125-13-422365:notes:194]
[same as prior period, unchanged from 0001193125-13-312256:notes:178]

[0001193125-13-422365:notes:195]
The change in
 the carrying value of goodwill, all of which is included in our
 Enterprise Networks division, for the nine months ended
 September 30, 2013 is as follows:

[0001193125-13-422365:notes:196]
We evaluate the
 carrying value of goodwill during the fourth quarter of each year
 and between annual evaluations if events occur or circumstances
 change that would more likely than not reduce the fair value of the
 reporting unit below its carrying amount. When evaluating whether
 goodwill is impaired, we first assess qualitative factors to
 determine whether it is necessary to perform the two-step
 quantitative goodwill impairment test. If we determine that the
 two-step quantitative test is necessary, then we compare the fair
 value of the reporting unit to which the goodwill is assigned to
 the reporting unit’s carrying amount, including goodwill. If
 the carrying amount of the reporting unit exceeds its fair value,
 then the amount of the impairment loss is measured. There were no
 impairment losses recorded during the nine months ended
 September 30, 2013 or 2012.

[0001193125-13-422365:notes:197]
Intangible
 assets are included in other assets in the accompanying
 Consolidated Balance Sheets and include intangibles acquired in
 conjunction with our acquisition of Objectworld Communications
 Corporation on September 15, 2009, Bluesocket, Inc. on
 August 4, 2011, and the NSN BBA business on May 4,
 2012.

[0001193125-13-422365:notes:198]
The following
 table presents our intangible assets as of September 30, 2013
 and December 31, 2012:

[0001193125-13-422365:notes:199]
Amortization
 expense, all of which relates to business acquisitions, was $0.6
 million for the three months ended September 30, 2013 and
 2012, and $1.8 million and $1.4 million for the nine months ended
 September 30, 2013 and 2012, respectively.

[0001193125-13-422365:notes:200]
As of
 September 30, 2013, the estimated future amortization expense
 of our intangible assets is as follows:


## adtn:ScheduleOfEntityWideInformationRevenueFromExternalCustomersBySubcategoryProductsAndServicesTableTextBlock

[0001193125-13-422365:notes:201]
The table below presents
 subcategory revenues for the three and nine months ended
 September 30, 2013 and 2012:

[0001193125-13-422365:notes:202]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
| (In thousands) |  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
| Core Products |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Broadband Access (included in Carrier Systems) |  | $ | 98,132 |  |  | $ | 94,464 |  |  | $ | 251,994 |  |  | $ | 249,988 |  |
| Optical (included in Carrier Systems) |  |  | 16,640 |  |  |  | 11,160 |  |  |  | 41,500 |  |  |  | 39,418 |  |
| Internetworking (included in Business Networking) |  |  | 43,329 |  |  |  | 35,411 |  |  |  | 124,163 |  |  |  | 111,320 |  |
| Subtotal |  |  | 158,101 |  |  |  | 141,035 |  |  |  | 417,657 |  |  |  | 400,726 |  |
| Legacy Products |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| HDSL (does not include T1) (included in Loop Access) |  |  | 11,487 |  |  |  | 12,926 |  |  |  | 33,183 |  |  |  | 51,350 |  |
| Other products (excluding HDSL) |  |  | 7,816 |  |  |  | 8,164 |  |  |  | 31,810 |  |  |  | 28,782 |  |
| Subtotal |  |  | 19,303 |  |  |  | 21,090 |  |  |  | 64,993 |  |  |  | 80,132 |  |
| Total |  | $ | 177,404 |  |  | $ | 162,125 |  |  | $ | 482,650 |  |  | $ | 480,858 |  |
