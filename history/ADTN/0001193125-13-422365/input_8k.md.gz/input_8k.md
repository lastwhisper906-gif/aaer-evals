# ADTN 8-K — 0001157523-13-004657 filed 2013-10-09

## item codes, every 8-K on or before 2013-11-01

- 2013-10-15 0001193125-13-399540 — 5.02
- 2013-10-09 0001157523-13-004657 — 2.02, 9.01
- 2013-07-10 0001157523-13-003290 — 2.02, 9.01
- 2013-05-10 0001193125-13-213728 — 5.07
- 2013-05-03 0001193125-13-198816 — 8.01, 9.01
- 2013-04-10 0001157523-13-001730 — 2.02, 9.01
- 2013-01-16 0001157523-13-000139 — 2.02, 9.01
- 2012-10-10 0001157523-12-005081 — 2.02, 9.01
- 2012-10-03 0001193125-12-413609 — 7.01
- 2012-09-28 0001193125-12-408878 — 2.02, 9.01
- 2012-07-11 0001157523-12-003592 — 2.02, 9.01
- 2012-05-10 0001193125-12-225669 — 5.07
- 2012-05-10 0001193125-12-225639 — 8.01, 9.01
- 2012-04-11 0001157523-12-001772 — 2.02, 9.01
- 2012-03-15 0001193125-12-116494 — 2.02, 9.01
- 2012-01-18 0001157523-12-000174 — 2.02, 9.01
- 2011-12-12 0001193125-11-337271 — 7.01, 9.01
- 2011-10-13 0000950123-11-089785 — 5.03, 9.01
- 2011-10-12 0001157523-11-005682 — 2.02, 9.01
- 2011-07-13 0001157523-11-003986 — 2.02, 9.01
- 2011-05-09 0000950123-11-047191 — 5.02, 5.07, 9.01
- 2011-04-13 0001157523-11-002001 — 2.02, 9.01
- 2011-01-19 0001157523-11-000232 — 2.02, 9.01
- 2010-11-09 0000950123-10-103195 — 5.02, 9.01
- 2010-10-13 0001157523-10-005798 — 2.02, 9.01
- 2010-07-14 0001157523-10-004011 — 2.02, 9.01
- 2010-05-28 0000950123-10-053947 — 5.07
- 2010-04-14 0001157523-10-002022 — 2.02, 9.01
- 2010-01-20 0001157523-10-000200 — 2.02, 9.01
- 2009-10-28 0000950123-09-053984 — 8.01
- 2009-10-14 0001157523-09-006877 — 2.02, 9.01
- 2009-07-15 0001157523-09-004878 — 2.02, 9.01
- 2009-04-15 0001157523-09-002687 — 2.02, 9.01
- 2009-01-21 0001157523-09-000340 — 2.02, 9.01
- 2008-11-12 0001193125-08-233181 — 5.02, 9.01
- 2008-10-14 0001157523-08-007999 — 2.02, 9.01
- 2008-07-15 0001157523-08-005504 — 2.02, 9.01
- 2008-04-15 0001157523-08-002896 — 2.02, 9.01
- 2008-01-22 0001157523-08-000408 — 2.02, 9.01
- 2007-10-16 0001193125-07-219356 — 5.03, 9.01
- 2007-10-16 0001157523-07-009850 — 2.02, 9.01
- 2007-07-17 0001157523-07-006912 — 2.02, 9.01
- 2007-04-17 0001157523-07-003630 — 2.02, 9.01
- 2007-04-03 0001179022-07-000068 — 5.02
- 2007-03-28 0001179022-07-000064 — 5.02
- 2007-02-23 0001193125-07-038337 — 5.02
- 2007-02-23 0001193125-07-038335 — 5.02
- 2007-01-30 0001193125-07-015912 — 5.02, 9.01
- 2007-01-26 0001193125-07-014234 — 5.02
- 2007-01-23 0001157523-07-000494 — 2.02, 9.01 — amendment of 0001157523-07-000481
- 2007-01-23 0001157523-07-000481 — 2.02, 9.01
- 2006-10-17 0001157523-06-009945 — 2.02, 9.01
- 2006-07-18 0001157523-06-006929 — 2.02, 9.01
- 2006-06-08 0001193125-06-126486 — 1.01, 9.01
- 2006-05-10 0001193125-06-107316 — 1.01, 9.01
- 2006-04-18 0001157523-06-003699 — 2.02, 9.01
- 2006-02-03 0001179022-06-000014 — 1.01
- 2006-01-27 0001157523-06-000754 — 5.02, 9.01
- 2006-01-24 0001157523-06-000551 — 2.02, 9.01
- 2005-10-18 0001157523-05-008826 — 2.02, 9.01
- 2005-07-19 0001193125-05-143958 — 1.01, 5.02, 9.01
- 2005-07-19 0001193125-05-143957 — 2.02, 9.01
- 2005-05-20 0001193125-05-112019 — 1.01, 9.01
- 2005-04-19 0001157523-05-003418 — 2.02, 9.01
- 2005-01-25 0001193125-05-010721 — 2.02, 9.01
- 2004-10-12 0001193125-04-169652 — 2.02, 9.01
- 2004-07-13 0001193125-04-116820 — 12, 7
- 2004-04-14 0001193125-04-061547 — 12, 7
- 2004-01-21 0001193125-04-006366 — 12, 7
- 2003-10-14 0001193125-03-061018 — 12, 5, 7
- 2003-07-15 0001193125-03-019292 — 7, 9
- 2003-04-15 0000931763-03-000968 — 7, 9
- 1996-09-12 0000931763-96-000667 — 5, 7

## late-filing notifications on or before 2013-11-01

- none on or before 2013-11-01

## item 2.02 — earnings release, exhibit 99.1

[0001157523-13-004657:8k_2_02:1]
EX-99.1
2
a50725299ex991.htm
EXHIBIT 99.1

[0001157523-13-004657:8k_2_02:2]
Exhibit 99.1

[0001157523-13-004657:8k_2_02:3]
ADTRAN,
      Inc. Reports Results for the Third Quarter 2013 and Declares Quarterly
      Cash Dividend

[0001157523-13-004657:8k_2_02:4]
HUNTSVILLE, Ala.--(BUSINESS WIRE)--October 8, 2013--ADTRAN, Inc.
      (NASDAQ:ADTN) reported results for the third quarter 2013. For the
      quarter, sales were $177,404,000 compared to $162,125,000 for the third
      quarter of 2012. Net income was $16,205,000 for the quarter compared to
      $9,272,000 for the third quarter of 2012. Earnings per share, assuming
      dilution, were $0.28 for the quarter compared to $0.15 for the third
      quarter of 2012. Non-GAAP earnings per share for the quarter were $0.32
      compared to $0.20 for the third quarter of 2012. The reconciliation
      between GAAP earnings per share, diluted, and non-GAAP earnings per
      share, diluted, is in the table provided.

[0001157523-13-004657:8k_2_02:5]
ADTRAN Chief Executive Officer Tom Stanton stated, “The performance for
      the quarter was driven by lower operating expenses combined with a
      strong performance by both our Carrier and Enterprise businesses. The
      results were positively impacted by our international business which
      achieved a record revenue level.”

[0001157523-13-004657:8k_2_02:6]
The Company also announced that its Board of Directors declared a cash
      dividend for the third quarter of 2013. The quarterly cash dividend is
      $0.09 per common share to be paid to holders of record at the close of
      business on October 24, 2013. The ex-dividend date is October 22, 2013
      and the payment date is November 7, 2013.

[0001157523-13-004657:8k_2_02:7]
The Company confirmed that its third quarter conference call will be
      held Wednesday, October 9, 2013 at 9:30 a.m. Central Time. This
      conference call will be web cast live through StreetEvents.com. To
      listen, simply visit the Investor Relations site at www.adtran.com
      or www.streetevents.com approximately 10 minutes prior to the
      start of the call and click on the conference call link provided.

[0001157523-13-004657:8k_2_02:8]
An online replay of the conference call will be available for seven days
      at www.streetevents.com. In addition, an online replay of the
      conference call, as well as the text of the Company's earnings release,
      will be available on the Investor Relations site at www.adtran.com
      for at least 12 months following the call.

[0001157523-13-004657:8k_2_02:9]
ADTRAN, Inc. is a leading global provider of networking and
      communications equipment. ADTRAN’s products enable voice, data, video
      and Internet communications across a variety of network infrastructures.
      ADTRAN solutions are currently in use by service providers, private
      enterprises, government organizations, and millions of individual users
      worldwide. For more information, please visit www.adtran.com.

[0001157523-13-004657:8k_2_02:10]
For more information, contact the company at 800 9ADTRAN (800 923-8726)
      or via email at info@adtran.com. On the Web, visit www.adtran.com.

[0001157523-13-004657:8k_2_02:11]
This press release contains forward-looking statements which reflect
      management’s best judgment based on factors currently known. However,
      these statements involve risks and uncertainties, including the
      successful development and market acceptance of new products, the degree
      of competition in the market for such products, the product and channel
      mix, component costs, manufacturing efficiencies, and other risks
      detailed in our annual report on Form 10-K for the year ended December
      31, 2012 and on Form 10-Q for the quarter ended June 30, 2013. These
      risks and uncertainties could cause actual results to differ materially
      from those in the forward-looking statements included in this press
      release.

[0001157523-13-004657:8k_2_02:12]
| Condensed Consolidated Balance Sheet (Unaudited) (In thousands) |
|  |  | September 30,2013 |  |  |  | December 31,2012 |
| Assets |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 54,311 |  |  |  | $ | 68,457 |
| Short-term investments |  |  | 136,640 |  |  |  |  | 160,481 |
| Accounts receivable, net |  |  | 108,018 |  |  |  |  | 81,194 |
| Other receivables |  |  | 20,268 |  |  |  |  | 16,253 |
| Inventory |  |  | 92,972 |  |  |  |  | 102,583 |
| Prepaid expenses |  |  | 4,693 |  |  |  |  | 4,148 |
| Deferred tax assets, net |  |  | 13,494 |  |  |  |  | 13,055 |
| Total Current Assets |  |  | 430,396 |  |  |  |  | 446,171 |
| Property, plant and equipment, net |  |  | 77,658 |  |  |  |  | 80,246 |
| Deferred tax assets, net |  |  | 11,605 |  |  |  |  | 10,261 |
| Goodwill |  |  | 3,492 |  |  |  |  | 3,492 |
| Other assets |  |  | 11,711 |  |  |  |  | 13,482 |
| Long-term investments |  |  | 298,122 |  |  |  |  | 332,729 |
| Total Assets |  | $ | 832,984 |  |  |  | $ | 886,381 |
| Liabilities and Stockholders' Equity |  |  |  |  |  |  |
| Accounts payable |  | $ | 74,172 |  |  |  | $ | 42,173 |
| Unearned revenue |  |  | 19,658 |  |  |  |  | 38,051 |
| Accrued expenses |  |  | 16,527 |  |  |  |  | 10,309 |
| Accrued wages and benefits |  |  | 16,594 |  |  |  |  | 15,022 |
| Income tax payable, net |  |  | 548 |  |  |  |  | 1,211 |
| Total Current Liabilities |  |  | 127,499 |  |  |  |  | 106,766 |
| Non-current unearned revenue |  |  | 26,373 |  |  |  |  | 23,803 |
| Other non-current liabilities |  |  | 20,459 |  |  |  |  | 17,406 |
| Bonds payable |  |  | 46,000 |  |  |  |  | 46,000 |
| Total Liabilities |  |  | 220,331 |  |  |  |  | 193,975 |
| Stockholders' Equity |  |  | 612,653 |  |  |  |  | 692,406 |
| Total Liabilities and Stockholders' Equity |  | $ | 832,984 |  |  |  | $ | 886,381 |

[0001157523-13-004657:8k_2_02:13]
| Consolidated Statements of Income (Unaudited) (In thousands, except per share data) |
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | September 30, |  | September 30, |
|  |  | 2013 |  | 2012 |  | 2013 |  | 2012 |
| Sales |  | $ | 177,404 |  |  | $ | 162,125 |  |  | $ | 482,650 |  |  | $ | 480,858 |  |
| Cost of sales |  |  | 94,857 |  |  |  | 82,153 |  |  |  | 250,628 |  |  |  | 231,598 |  |
| Gross Profit |  |  | 82,547 |  |  |  | 79,972 |  |  |  | 232,022 |  |  |  | 249,260 |  |
| Selling, general and administrative expenses |  |  | 32,794 |  |  |  | 34,114 |  |  |  | 96,082 |  |  |  | 103,130 |  |
| Research and development expenses |  |  | 32,543 |  |  |  | 35,582 |  |  |  | 98,114 |  |  |  | 92,835 |  |
| Operating Income |  |  | 17,210 |  |  |  | 10,276 |  |  |  | 37,826 |  |  |  | 53,295 |  |
| Interest and dividend income |  |  | 1,579 |  |  |  | 1,864 |  |  |  | 5,021 |  |  |  | 5,651 |  |
| Interest expense |  |  | (581 | ) |  |  | (587 | ) |  |  | (1,737 | ) |  |  | (1,756 | ) |
| Net realized investment gain |  |  | 1,751 |  |  |  | 2,530 |  |  |  | 6,949 |  |  |  | 7,353 |  |
| Other income (expense), net |  |  | 22 |  |  |  | (368 | ) |  |  | (1,521 | ) |  |  | 265 |  |
| Gain on bargain purchase of a business |  |  | - |  |  |  | - |  |  |  | - |  |  |  | 1,753 |  |
| Income before provision for income taxes |  |  | 19,981 |  |  |  | 13,715 |  |  |  | 46,538 |  |  |  | 66,561 |  |
| Provision for income taxes |  |  | (3,776 | ) |  |  | (4,443 | ) |  |  | (12,584 | ) |  |  | (23,259 | ) |
| Net Income |  | $ | 16,205 |  |  | $ | 9,272 |  |  | $ | 33,954 |  |  | $ | 43,302 |  |
| Weighted average shares outstanding - basic |  |  | 57,947 |  |  |  | 63,066 |  |  |  | 59,561 |  |  |  | 63,495 |  |
| Weighted average shares outstanding - diluted (1) |  |  | 58,617 |  |  |  | 63,304 |  |  |  | 59,929 |  |  |  | 64,139 |  |
| Earnings per common share - basic |  | $ | 0.28 |  |  | $ | 0.15 |  |  | $ | 0.57 |  |  | $ | 0.68 |  |
| Earnings per common share - diluted (1) |  | $ | 0.28 |  |  | $ | 0.15 |  |  | $ | 0.57 |  |  | $ | 0.68 |  |
| (1) Assumes exercise of dilutive stock options calculated under the treasury stock method. |

[0001157523-13-004657:8k_2_02:14]
| Consolidated Statements of Comprehensive Income (Unaudited) (In thousands) |
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | September 30, |  | September 30, |
|  |  | 2013 |  | 2012 |  | 2013 |  | 2012 |
| Net Income |  | $ | 16,205 |  |  | $ | 9,272 |  | $ | 33,954 |  |  | $ | 43,302 |
| Other Comprehensive Income (Loss), net of tax: |  |  |  |  |  |  |  |  |
| Unrealized gains (losses) on available-for-sale securities |  |  | 2,562 |  |  |  | 497 |  |  | (780 | ) |  |  | 2,019 |
| Foreign currency translation |  |  | (108 | ) |  |  | 134 |  |  | (1,498 | ) |  |  | 191 |
| Other Comprehensive Income (Loss), net of tax |  |  | 2,454 |  |  |  | 631 |  |  | (2,278 | ) |  |  | 2,210 |
| Comprehensive Income, net of tax |  | $ | 18,659 |  |  | $ | 9,903 |  | $ | 31,676 |  |  | $ | 45,512 |

[0001157523-13-004657:8k_2_02:15]
| Consolidated Statements of Cash Flows (Unaudited) (In thousands) |
|  |  | Nine Months Ended |
|  |  | September 30, |
|  |  | 2013 |  | 2012 |
| Cash flows from operating activities: |  |  |  |  |
| Net income |  | $ | 33,954 |  |  | $ | 43,302 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Depreciation and amortization |  |  | 11,021 |  |  |  | 10,366 |  |
| Amortization of net premium on available-for-sale investments |  |  | 4,688 |  |  |  | 6,343 |  |
| Net realized gain on long-term investments |  |  | (6,949 | ) |  |  | (7,353 | ) |
| Net (gain) loss on disposal of property, plant and equipment |  |  | 6 |  |  |  | (213 | ) |
| Gain on bargain purchase of a business |  |  | - |  |  |  | (1,753 | ) |
| Stock-based compensation expense |  |  | 6,516 |  |  |  | 6,783 |  |
| Deferred income taxes |  |  | (1,296 | ) |  |  | (1,156 | ) |
| Tax benefit from stock option exercises |  |  | 113 |  |  |  | 1,813 |  |
| Excess tax benefits from stock-based compensation arrangements |  |  | (106 | ) |  |  | (1,412 | ) |
| Change in operating assets and liabilities: |  |  |  |  |
| Accounts receivable, net |  |  | (25,844 | ) |  |  | (26,178 | ) |
| Other receivables |  |  | (3,724 | ) |  |  | 1,866 |  |
| Inventory |  |  | 8,584 |  |  |  | 2,142 |  |
| Prepaid expenses and other assets |  |  | (417 | ) |  |  | (1,193 | ) |
| Accounts payable |  |  | 30,960 |  |  |  | 17,607 |  |
| Accrued expenses and other liabilities |  |  | (4,839 | ) |  |  | 12,769 |  |
| Income tax payable, net |  |  | (678 | ) |  |  | 1,022 |  |
| Net cash provided by operating activities |  |  | 51,989 |  |  |  | 64,755 |  |
| Cash flows from investing activities: |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (6,510 | ) |  |  | (10,759 | ) |
| Proceeds from disposals of property, plant and equipment |  |  | - |  |  |  | 266 |  |
| Proceeds from sales and maturities of available-for-sale investments |  |  | 275,581 |  |  |  | 198,566 |  |
| Purchases of available-for-sale investments |  |  | (216,129 | ) |  |  | (220,355 | ) |
| Acquisition of business |  |  | - |  |  |  | 7,496 |  |
| Net cash provided by (used in) investing activities |  |  | 52,942 |  |  |  | (24,786 | ) |
| Cash flows from financing activities: |  |  |  |  |
| Proceeds from stock option exercises |  |  | 2,332 |  |  |  | 4,932 |  |
| Purchases of treasury stock |  |  | (104,147 | ) |  |  | (28,578 | ) |
| Dividend payments |  |  | (16,220 | ) |  |  | (17,173 | ) |
| Excess tax benefits from stock-based compensation arrangements |  |  | 106 |  |  |  | 1,412 |  |
| Net cash used in financing activities |  |  | (117,929 | ) |  |  | (39,407 | ) |
| Net increase (decrease) in cash and cash equivalents |  |  | (12,998 | ) |  |  | 562 |  |
| Effect of exchange rate changes |  |  | (1,148 | ) |  |  | (6 | ) |
| Cash and cash equivalents, beginning of period |  |  | 68,457 |  |  |  | 42,979 |  |
| Cash and cash equivalents, end of period |  | $ | 54,311 |  |  | $ | 43,535 |  |

[0001157523-13-004657:8k_2_02:16]
| Supplemental Information Acquisition Related Expenses, Amortizations and Adjustments (Unaudited) (In thousands) |
| On August 4, 2011, we closed on the acquisition of Bluesocket, Inc. and on May 4, 2012, we closed on the acquisition of the Nokia Siemens Networks Broadband Access business (NSN BBA). Acquisition related expenses, amortizations and adjustments for the three and nine months ended September 30, 2013 and 2012 for both transactions are as follows: |
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | September 30, |  | September 30, |
|  |  | 2013 |  | 2012 |  | 2013 |  | 2012 |
| Bluesocket, Inc. acquisition |  |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets and other purchase accounting adjustments |  | $ | 283 |  |  | $ | 305 |  |  | $ | 863 |  |  | $ | 1,167 |  |
| NSN BBA acquisition |  |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets |  |  | 291 |  |  |  | 300 |  |  |  | 873 |  |  |  | 472 |  |
| Amortization of other purchase accounting adjustments |  |  | 235 |  |  |  | 666 |  |  |  | 987 |  |  |  | 1,718 |  |
| Acquisition related professional fees, travel and other expenses |  |  | 93 |  |  |  | 252 |  |  |  | 329 |  |  |  | 4,537 |  |
| Subtotal |  |  | 619 |  |  |  | 1,218 |  |  |  | 2,189 |  |  |  | 6,727 |  |
| Total acquisition related expenses, amortizations and adjustments |  |  | 902 |  |  |  | 1,523 |  |  |  | 3,052 |  |  |  | 7,894 |  |
| Provision for income taxes |  |  | (302 | ) |  |  | (496 | ) |  |  | (1,015 | ) |  |  | (2,660 | ) |
| Total acquisition related expenses, amortizations and adjustments, net of tax |  | $ | 600 |  |  | $ | 1,027 |  |  | $ | 2,037 |  |  | $ | 5,234 |  |
| The acquisition related expenses, amortizations and adjustments above were recorded in the following Consolidated Statements of Income categories for the three and nine months ended September 30, 2013 and 2012: |
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | September 30, |  | September 30, |
|  |  | 2013 |  | 2012 |  | 2013 |  | 2012 |
| Revenue (adjustments to deferred revenue recognized in the period) |  | $ | 221 |  |  | $ | 497 |  |  | $ | 718 |  |  | $ | 1,151 |  |
| Cost of goods sold |  |  | (57 | ) |  |  | 126 |  |  |  | 94 |  |  |  | 932 |  |
| Subtotal |  |  | 164 |  |  |  | 623 |  |  |  | 812 |  |  |  | 2,083 |  |
| Selling, general and administrative expenses |  |  | 101 |  |  |  | 258 |  |  |  | 375 |  |  |  | 4,180 |  |
| Research and development expenses |  |  | 637 |  |  |  | 642 |  |  |  | 1,865 |  |  |  | 1,631 |  |
| Subtotal |  |  | 738 |  |  |  | 900 |  |  |  | 2,240 |  |  |  | 5,811 |  |
| Total acquisition related expenses, amortizations and adjustments |  |  | 902 |  |  |  | 1,523 |  |  |  | 3,052 |  |  |  | 7,894 |  |
| Provision for income taxes |  |  | (302 | ) |  |  | (496 | ) |  |  | (1,015 | ) |  |  | (2,660 | ) |
| Total acquisition related expenses, amortizations and adjustments, net of tax |  | $ | 600 |  |  | $ | 1,027 |  |  | $ | 2,037 |  |  | $ | 5,234 |  |

[0001157523-13-004657:8k_2_02:17]
| Supplemental Information Stock-based Compensation Expense (Unaudited) (In thousands) |
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | September 30, |  | September 30, |
|  |  | 2013 |  | 2012 |  | 2013 |  | 2012 |
| Stock-based compensation expense included in cost of sales |  | $ | 118 |  |  | $ | 106 |  |  | $ | 334 |  |  | $ | 304 |  |
| Selling, general and administrative expense |  |  | 1,024 |  |  |  | 1,107 |  |  |  | 3,129 |  |  |  | 3,205 |  |
| Research and development expense |  |  | 1,034 |  |  |  | 1,138 |  |  |  | 3,053 |  |  |  | 3,274 |  |
| Stock-based compensation expense included in operating expenses |  |  | 2,058 |  |  |  | 2,245 |  |  |  | 6,182 |  |  |  | 6,479 |  |
| Total stock-based compensation expense |  |  | 2,176 |  |  |  | 2,351 |  |  |  | 6,516 |  |  |  | 6,783 |  |
| Tax benefit for expense associated with non-qualified options |  |  | (307 | ) |  |  | (313 | ) |  |  | (924 | ) |  |  | (916 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 1,869 |  |  | $ | 2,038 |  |  | $ | 5,592 |  |  | $ | 5,867 |  |

[0001157523-13-004657:8k_2_02:18]
| Reconciliation of GAAP net income per share, diluted, to Non-GAAP net income per share, diluted (Unaudited) |
|  |  | Three Months Ended |  | Nine Months Ended |
|  |  | September 30, |  | September 30, |
|  |  | 2013 |  | 2012 |  | 2013 |  | 2012 |
| GAAP earnings per common share – diluted |  | $ | 0.28 |  | $ | 0.15 |  | $ | 0.57 |  | $ | 0.68 |  |
| Acquisition related expenses, amortizations and adjustments |  |  | 0.01 |  |  | 0.02 |  |  | 0.03 |  |  | 0.08 |  |
| Stock-based compensation expense |  |  | 0.03 |  |  | 0.03 |  |  | 0.09 |  |  | 0.09 |  |
| Gain on bargain purchase of business |  | - |  | - |  | - |  |  | (0.03 | ) |
| Non-GAAP earnings per common share – diluted |  | $ | 0.32 |  | $ | 0.20 |  | $ | 0.69 |  | $ | 0.82 |  |

[0001157523-13-004657:8k_2_02:19]
CONTACT:
ADTRAN, Inc.
Jim Matthews, 256-963-8775
Senior
      Vice President/CFO
or
Investor Services/Assistance:
Gayle
      Ellis, 256-963-8220
