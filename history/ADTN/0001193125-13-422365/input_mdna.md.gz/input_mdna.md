# ADTN MD&A — 0001193125-13-422365


## mdna

[0001193125-13-422365:mdna:1]
ITEM 2. MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND
RESULTS OF OPERATIONS

[0001193125-13-422365:mdna:2]
The following discussion should be read in conjunction with the Consolidated Financial Statements and the related notes
that appear elsewhere in this document.

[0001193125-13-422365:mdna:3]
[same as prior period, unchanged from 0001193125-13-312256:mdna:3]

[0001193125-13-422365:mdna:4]
ADTRAN, Inc. designs, manufactures and markets solutions and provides services and support for communications networks. Our solutions are widely deployed by
providers of communications services (serviced by our Carrier Networks Division), and small, mid-sized and distributed enterprises (serviced by our Enterprise Networks Division), and enable voice, data, video and Internet communications across a
variety of network infrastructures. Many of these solutions are currently in use by most major United States communication service providers, many global service providers, as well as many public, private and governmental organizations worldwide.

[0001193125-13-422365:mdna:5]
Our success depends upon our ability to increase unit volume and market share through the introduction of new products and succeeding generations of
products having lower selling prices and increased functionality as compared to both the prior generation of a product and to the products of competitors. An important part of our strategy is to reduce the cost of each succeeding product generation
and then lower the product’s selling price based on the cost savings achieved in order to gain market share and/or improve gross margins. As a part of this strategy, we seek in most instances to be a high-quality, low-cost provider of products
in our markets. Our success to date is attributable in large measure to our ability to design our products initially with a view to their subsequent redesign, allowing both increased functionality and reduced manufacturing costs in each succeeding
product generation. This strategy enables us to sell succeeding generations of products to existing customers, while increasing our market share by selling these enhanced products to new customers.

[0001193125-13-422365:mdna:6]
[same as prior period, unchanged from 0001193125-13-312256:mdna:6]

[0001193125-13-422365:mdna:7]
[same as prior period, unchanged from 0001193125-13-312256:mdna:7]

[0001193125-13-422365:mdna:8]
[same as prior period, unchanged from 0001193125-13-312256:mdna:8]

[0001193125-13-422365:mdna:9]
[same as prior period, unchanged from 0001193125-13-312256:mdna:9]

[0001193125-13-422365:mdna:10]
[same as prior period, unchanged from 0001193125-13-312256:mdna:10]

[0001193125-13-422365:mdna:11]
[same as prior period, unchanged from 0001193125-13-312256:mdna:11]

[0001193125-13-422365:mdna:12]
[same as prior period, unchanged from 0001193125-13-312256:mdna:12]

[0001193125-13-422365:mdna:13]
[same as prior period, unchanged from 0001193125-13-312256:mdna:13]

[0001193125-13-422365:mdna:14]
[same as prior period, unchanged from 0001193125-13-312256:mdna:14]

[0001193125-13-422365:mdna:15]
[same as prior period, unchanged from 0001193125-13-312256:mdna:15]

[0001193125-13-422365:mdna:16]
[same as prior period, unchanged from 0001193125-13-312256:mdna:16]

[0001193125-13-422365:mdna:17]
[same as prior period, unchanged from 0001193125-13-312256:mdna:17]

[0001193125-13-422365:mdna:18]
[same as prior period, unchanged from 0001193125-13-312256:mdna:18]

[0001193125-13-422365:mdna:19]
[same as prior period, unchanged from 0001193125-13-312256:mdna:19]

[0001193125-13-422365:mdna:20]
[same as prior period, unchanged from 0001193125-13-312256:mdna:20]

[0001193125-13-422365:mdna:21]
Business Networking products provide access to telecommunication services and facilitate the delivery of
cloud connectivity, enterprise communications and virtual mobility to the small and mid-sized enterprise (SME) market. This category includes the following product areas and related services:

[0001193125-13-422365:mdna:22]
[same as prior period, unchanged from 0001193125-13-312256:mdna:22]

[0001193125-13-422365:mdna:23]
[same as prior period, unchanged from 0001193125-13-312256:mdna:23]

[0001193125-13-422365:mdna:24]
[same as prior period, unchanged from 0001193125-13-312256:mdna:24]

[0001193125-13-422365:mdna:25]
[same as prior period, unchanged from 0001193125-13-312256:mdna:25]

[0001193125-13-422365:mdna:26]
[same as prior period, unchanged from 0001193125-13-312256:mdna:26]

[0001193125-13-422365:mdna:27]
[same as prior period, unchanged from 0001193125-13-312256:mdna:27]

[0001193125-13-422365:mdna:28]
[same as prior period, unchanged from 0001193125-13-312256:mdna:28]

[0001193125-13-422365:mdna:29]
[same as prior period, unchanged from 0001193125-13-312256:mdna:29]

[0001193125-13-422365:mdna:30]
[same as prior period, unchanged from 0001193125-13-312256:mdna:30]

[0001193125-13-422365:mdna:31]
[same as prior period, unchanged from 0001193125-13-312256:mdna:31]

[0001193125-13-422365:mdna:32]
[same as prior period, unchanged from 0001193125-13-312256:mdna:32]

[0001193125-13-422365:mdna:33]
[same as prior period, unchanged from 0001193125-13-312256:mdna:33]

[0001193125-13-422365:mdna:34]
Loop Access products are used by carrier and enterprise customers for
access to copper-based telecommunications networks. The Loop Access category includes the following product areas:

[0001193125-13-422365:mdna:35]
[same as prior period, unchanged from 0001193125-13-312256:mdna:35]

[0001193125-13-422365:mdna:36]
[same as prior period, unchanged from 0001193125-13-312256:mdna:36]

[0001193125-13-422365:mdna:37]
[same as prior period, unchanged from 0001193125-13-312256:mdna:37]

[0001193125-13-422365:mdna:38]
[same as prior period, unchanged from 0001193125-13-312256:mdna:38]

[0001193125-13-422365:mdna:39]
[same as prior period, unchanged from 0001193125-13-312256:mdna:39]

[0001193125-13-422365:mdna:40]
In addition, we identify subcategories of product revenues, which we divide
into our core products and legacy products. Our core products consist of Broadband Access and Optical products (included in Carrier Systems) and Internetworking products (included in Business Networking). Our legacy products include HDSL products
(included in Loop Access) and other products not included in the aforementioned core products. Many of our customers are migrating their networks to deliver higher bandwidth services by utilizing newer technologies. We believe that products and
services offered in our core product areas position us well for this migration. Despite occasional increases, we anticipate that revenues of many of our legacy products, including HDSL, will decline over time; however, revenues from these products
may continue for years because of the time required for our customers to transition to newer technologies.

[0001193125-13-422365:mdna:41]
See Note 12 of Notes to Consolidated Financial
Statements in this report for further information regarding these product categories.

[0001193125-13-422365:mdna:42]
Sales were $177.4 million and $482.7 million for the three and nine
months ended September 30, 2013 compared to $162.1 million and $480.9 million for the three and nine months ended September 30, 2012. Product revenues for our three core areas, Broadband Access, Optical and Internetworking, were $158.1
million and $417.7 million for the three and nine months ended September 30, 2013 compared to $141.0 million and $400.7 million for the three and nine months ended September 30, 2012. Our gross margin decreased to 46.5% and 48.1% for the
three and nine months ended September 30, 2013 from 49.3% and 51.8% for the three and nine months ended September 30, 2012. Our operating income margin increased to 9.7% for the three months ended September 30, 2013 from 6.3% for the
three months ended September 30, 2012, and decreased to 7.8% for the nine months ended September 30, 2013 from 11.1% for the nine months ended September 30, 2012. Net income was $16.2 million and $34.0 million for the three and nine
months ended September 30, 2013 compared to $9.3 million and $43.3 million for the three and nine months ended September 30, 2012. Our effective tax rate decreased to 18.9% for the three months ended September 30, 2013 from 32.4% for
the three months ended September 30, 2012 and decreased to 27.0% for the nine months ended September 30, 2013 from 34.9% for the nine months ended September 30, 2012. Earnings per share, assuming dilution, were $0.28 and $0.57 for the
three and nine months ended September 30, 2013 compared to $0.15 and $0.68 for the three and nine months ended September 30, 2012.

[0001193125-13-422365:mdna:43]
28

[0001193125-13-422365:mdna:44]
[same as prior period, unchanged from 0001193125-13-312256:mdna:44]

[0001193125-13-422365:mdna:45]
Our operating results may also fluctuate as a result of a number of other factors, including a decline in general economic and market conditions, increased
competition, customer order patterns, changes in product and services mix, timing differences between price decreases and product cost reductions, product warranty returns, expediting costs and announcements of new products by us or our competitors.
Additionally, maintaining sufficient inventory levels to assure prompt delivery of our products increases the amount of inventory that may become obsolete and increases the risk that the obsolescence of this inventory may have an adverse effect on
our business and operating results. Also, not maintaining sufficient inventory levels to assure prompt delivery of our products may cause us to incur expediting costs to meet customer delivery requirements, which may negatively impact our operating
results in a given quarter.

[0001193125-13-422365:mdna:46]
Accordingly, our historical financial performance is not necessarily a meaningful indicator of future results, and, in
general, management expects that our financial results may vary from period to period. A list of factors that could materially affect our business, financial condition or operating results is included under “Factors That Could Affect Our Future
Results” in “Management’s Discussion and Analysis of Financial Condition and Results of Operations” contained in Item 2 of Part I of this report. These factors have also been discussed in more detail in Item 1A of Part
I in our most recent Annual Report on Form 10-K for the year ended December 31, 2012, filed on February 28, 2013 with the SEC.

[0001193125-13-422365:mdna:47]
CRITICAL
ACCOUNTING POLICIES AND ESTIMATES

[0001193125-13-422365:mdna:48]
Our critical accounting policies and estimates have not changed significantly from those detailed in our most recent
Annual Report on Form 10-K for the year ended December 31, 2012, filed on February 28, 2013 with the SEC.

[0001193125-13-422365:mdna:49]
EFFECT OF RECENT ACCOUNTING
PRONOUNCEMENTS

[0001193125-13-422365:mdna:50]
See Note 1 of Notes to Consolidated Financial Statements in Item 1 of this Form 10-Q for a full description of recent accounting
pronouncements, including the expected dates of adoption and estimated effects on results of operations and financial condition, which is incorporated herein by reference.

[0001193125-13-422365:mdna:51]
[same as prior period, unchanged from 0001193125-13-312256:mdna:51]

[0001193125-13-422365:mdna:52]
On May 4, 2012, we closed on the acquisition of the Nokia Siemens Networks Broadband Access business (NSN BBA). Acquisition related expenses,
amortizations and adjustments for the three and nine months ended September 30, 2013 and 2012 for that transaction are as follows:

[0001193125-13-422365:mdna:53]
|  |  | Three Months EndedSeptember 30, |  |  | Nine Months EndedSeptember 30, |  |
|  |  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
| Amortization of acquired intangible assets |  | $ | 291 |  |  | $ | 300 |  |  | $ | 873 |  |  | $ | 472 |  |
| Amortization of other purchase accounting adjustments |  |  | 235 |  |  |  | 666 |  |  |  | 987 |  |  |  | 1,718 |  |
| Acquisition related professional fees, travel and other expenses |  |  | 93 |  |  |  | 252 |  |  |  | 329 |  |  |  | 4,537 |  |
| Total acquisition related expenses, amortizations and adjustments |  |  | 619 |  |  |  | 1,218 |  |  |  | 2,189 |  |  |  | 6,727 |  |
| Provision for income taxes |  |  | (192 | ) |  |  | (361 | ) |  |  | (679 | ) |  |  | (2,100 | ) |
| Total acquisition related expenses, amortizations and adjustments, net of tax |  | $ | 427 |  |  | $ | 857 |  |  | $ | 1,510 |  |  | $ | 4,627 |  |

[0001193125-13-422365:mdna:54]
The acquisition related expenses, amortizations and adjustments above were recorded in the following Consolidated Statements
of Income categories for the three and nine months ended September 30, 2013 and 2012:

[0001193125-13-422365:mdna:55]
|  |  | Three Months EndedSeptember 30, |  |  | Nine Months EndedSeptember 30, |  |
|  |  | 2013 |  |  | 2012 |  |  | 2013 |  |  | 2012 |  |
| Revenue (adjustments to deferred revenue recognized in the period) |  | $ | 205 |  |  | $ | 461 |  |  | $ | 657 |  |  | $ | 877 |  |
| Cost of goods sold |  |  | (57 | ) |  |  | 123 |  |  |  | 94 |  |  |  | 792 |  |
| Subtotal |  |  | 148 |  |  |  | 584 |  |  |  | 751 |  |  |  | 1,669 |  |
| Selling, general and administrative expenses |  |  | 101 |  |  |  | 259 |  |  |  | 375 |  |  |  | 4,180 |  |
| Research and development expenses |  |  | 370 |  |  |  | 375 |  |  |  | 1,063 |  |  |  | 878 |  |
| Subtotal |  |  | 471 |  |  |  | 634 |  |  |  | 1,438 |  |  |  | 5,058 |  |
| Total acquisition related expenses, amortizations and adjustments |  |  | 619 |  |  |  | 1,218 |  |  |  | 2,189 |  |  |  | 6,727 |  |
| Provision for income taxes |  |  | (192 | ) |  |  | (361 | ) |  |  | (679 | ) |  |  | (2,100 | ) |
| Total acquisition related expenses, amortizations and adjustments, net of tax |  | $ | 427 |  |  | $ | 857 |  |  | $ | 1,510 |  |  | $ | 4,627 |  |

[0001193125-13-422365:mdna:56]
[same as prior period, unchanged from 0001193125-13-312256:mdna:56]

[0001193125-13-422365:mdna:57]
30

[0001193125-13-422365:mdna:58]
RESULTS OF OPERATIONS – THREE AND NINE MONTHS ENDED SEPTEMBER 30, 2013 COMPARED TO THREE AND NINE MONTHS
ENDED SEPTEMBER 30, 2012

[0001193125-13-422365:mdna:59]
[same as prior period, unchanged from 0001193125-13-312256:mdna:59]

[0001193125-13-422365:mdna:60]
ADTRAN’s sales increased 9.4% from $162.1 million in the three months ended September 30, 2012 to $177.4 million in the three months ended
September 30, 2013, and increased 0.4% from $480.9 million in the nine months ended September 30, 2012 to $482.7 million in the nine months ended September 30, 2013. The increase in sales for the three months ended September 30,
2013 is primarily attributable to a $7.9 million increase in sales of our Internetworking products, a $5.5 million increase in sales of our Optical products, and a $3.7 million increase in sales of our Broadband Access products, partially offset by
a $1.8 million decrease in sales of our HDSL and other legacy products. The increase in sales for the nine months ended September 30, 2013 is primarily attributable to a $12.8 million increase in sales of our Internetworking products, a $2.1
million increase in sales of our Optical products, and a $2.0 million increase in sales of our Broadband Access products, partially offset by a $15.1 million decrease in sales of our HDSL and other legacy products.

[0001193125-13-422365:mdna:61]
Carrier Networks sales increased 7.1% from $131.9 million in the three months ended September 30, 2012 to $141.3 million in the three months ended
September 30, 2013, and decreased 1.8% from $381.3 million in the nine months ended September 30, 2012 to $374.5 million in the nine months ended September 30, 2013. The increase in sales for the three months ended September 30,
2013 is primarily attributable to increases in sales of our Optical products, Broadband Access products, and Internetworking products, partially offset by a decrease in sales of our HDSL products. The decrease in sales for the nine months ended
September 30, 2013 is primarily attributable to a decrease in sales of our HDSL products, partially offset by increases in sales of our Internetworking products, Broadband Access, and Optical products. The increase in sales of our Optical
products for the three and nine months ended September 30, 2013 is primarily attributable to a technology shift from Time Division Multiplexed (TDM) and SONET/SDH architectures to Ethernet-based packet networks. We offer Ethernet-based
solutions within our Optical products that address this technology change, and we expect sales of our Optical products will increase over time due to this transition. The increase in sales of our Broadband Access products for the three and nine
months ended September 30, 2013 is primarily attributable to initial VDSL2 vectoring technology shipments to Europe, partially offset by fluctuations in project installation activities at a Latin American carrier. The increase in sales of our
Internetworking products for the three and nine months ended September 30, 2013 was primarily attributable to an improved spending environment and increases in Carrier Ethernet sales and FTTH ONT sales to carriers. The decrease in sales of HDSL
and other legacy products for the three and nine months ended September 30, 2013 has been expected as customers continue to upgrade their networks to deliver higher bandwidth services by migrating to newer technologies, including to our core
products from our Broadband Access, Internetworking and Optical product lines. While we expect that revenues from HDSL and our other legacy products will continue to decline over time, these revenues may continue for years because of the time
required for our customers to transition to newer technologies.

[0001193125-13-422365:mdna:62]
Enterprise Networks sales increased 19.7% from $30.2 million in the three months ended
September 30, 2012 to $36.1 million in the three months ended September 30, 2013, and increased 8.6% from $99.6 million in the nine months ended September 30, 2012 to $108.2 million in the nine months ended September 30, 2013.
The increase in sales for the three and nine months ended September 30, 2013 is primarily attributable to increases in sales of our Internetworking products, partially offset by decreases in sales of our legacy products. The increase in sales
of our Internetworking products was primarily attributable to an improved spending environment and reflected an increase in sales to both carriers and value added resellers. The decrease in legacy products was expected and discussed further above.
Internetworking product sales attributable to Enterprise Networks were 93.7% of the division’s sales in the three and nine months ended September 30, 2013, compared to 92.3% and 91.5% in the three and nine months ended September 30,
2012, respectively. Legacy products primarily comprise the remainder of Enterprise Networks sales. Enterprise Networks sales as a percentage of total sales increased from 18.6% for the three months ended September 30, 2012 to 20.4% for the
three months ended September 30, 2013, and increased from 20.7% for the nine months ended September 30, 2012 to 22.4% for the nine months ended September 30, 2013.

[0001193125-13-422365:mdna:63]
International sales, which are included in the Carrier Networks and Enterprise Networks amounts discussed above,
increased 30.6% from $49.2 million in the three months ended September 30, 2012 to $64.2 million in the three months ended September 30, 2013, and increased 10.6% from $121.1 million in the nine months ended September 30, 2012 to
$133.8 million in the nine months ended September 30, 2013. International sales, as a percentage of total sales, increased from 30.3% for the three months ended September 30, 2012 to 36.2% for the three months ended September 30,
2013, and increased from 25.2% for the nine months ended September 30, 2012 to 27.7% for the nine months ended September 30, 2013. International sales increased in the three and nine months ended September 30, 2013 compared to the
three and nine months ended September 30, 2012 primarily due to an increase in sales in the EMEA region, partially offset by a decrease in sales in Latin America and the Asia-Pacific region.

[0001193125-13-422365:mdna:64]
Carrier System product sales increased $9.2 million and $9.5 million in the three and nine months ended September 30, 2013 compared to the three and nine
months ended September 30, 2012. The increase for the three months ended September 30, 2013 is primarily due to a $5.5 million increase in Optical product sales and a $3.7 million increase in Broadband Access product sales. The increase
for the nine months ended September 30, 2013 is primarily due to a $5.4 million increase in legacy product sales, a $2.1 million increase in Optical product sales and a $2.0 million increase in Broadband Access product sales. The changes for
the three and nine months ended September 30, 2013 are primarily attributable to the factors discussed above.

[0001193125-13-422365:mdna:65]
Business Networking product sales
increased $7.6 million and $11.3 million in the three and nine months ended September 30, 2013 compared to the three and nine months ended September 30, 2012. The increase for the three and nine months ended September 30, 2013 is
primarily due to increases in Internetworking product sales of $7.9 million and $12.8 million, respectively, across both divisions, partially offset by decreases in legacy product sales of $0.3 million and $1.5 million, respectively. The increase in
sales of our Internetworking products was primarily attributable to an improved spending environment and reflected an increase in sales to both carriers and value added resellers. The decrease in legacy products was expected and is discussed further
above.

[0001193125-13-422365:mdna:66]
Loop Access product sales decreased $1.5 million and $19.1 million in the three and nine months ended September 30, 2013 compared to the
three and nine months ended September 30, 2012. The decrease for the three and nine months ended September 30, 2013 is primarily due to a $1.4 million and $18.2 million decrease, respectively, in HDSL product sales, which was discussed
further above.

[0001193125-13-422365:mdna:67]
[same as prior period, unchanged from 0001193125-13-312256:mdna:67]

[0001193125-13-422365:mdna:68]
As a percentage
of sales, cost of sales increased from 50.7% in the three months ended September 30, 2012 to 53.5% in the three months ended September 30, 2013 and increased from 48.2% in the nine months ended September 30, 2012 to 51.9% in the nine
months ended September 30, 2013. The increase for the three months ended September 30, 2013 is primarily attributable to a higher volume of the lower gross margin product related to the acquired broadband access business, partially
offset by shifts in customer mix and higher cost absorption due to higher production volumes of certain products. The increase for the nine months ended September 30, 2013 is primarily attributable to a higher volume of the lower gross margin
product related to the acquired broadband access business, customer price movements to achieve market share position and shifts in customer mix.

[0001193125-13-422365:mdna:69]
Carrier
Networks cost of sales, as a percent of division sales, increased from 51.6% in the three months ended September 30, 2012 to 55.4% in the three months ended September 30, 2013 and increased from 48.7% in the nine months ended
September 30, 2012 to 53.9% in the nine months ended September 30, 2013. The increase for the three months ended September 30, 2013 is primarily attributable to a higher volume of the lower gross margin product related to the
acquired broadband access business, partially offset by shifts in customer mix. The increase for the nine months ended September 30, 2013 is primarily attributable to a higher volume of the lower gross margin product related to the acquired
broadband access business, customer price movements to achieve market share position and shifts in customer mix.

[0001193125-13-422365:mdna:70]
Enterprise Networks cost of sales, as a
percent of division sales, decreased from 46.5% in the three months ended September 30, 2012 to 46.1% in the three months ended September 30, 2013 and decreased from 45.9% in the nine months ended September 30, 2012 to 45.0% in the
nine months ended September 30, 2013. The decrease for the three and nine months ended September 30, 2013 is primarily attributable to shifts in customer mix and higher cost absorption due to higher production volumes.

[0001193125-13-422365:mdna:71]
An important part of our strategy is to reduce the product cost of each succeeding product generation and then to
lower the product’s price based on the cost savings achieved. This may cause variations in our gross profit percentage due to timing differences between the recognition of cost reductions and the lowering of product selling prices.

[0001193125-13-422365:mdna:72]
[same as prior period, unchanged from 0001193125-13-312256:mdna:72]

[0001193125-13-422365:mdna:73]
Selling, general and administrative expenses decreased 3.9% from $34.1 million in the three months ended September 30, 2012 to $32.8 million in the three
months ended September 30, 2013 and decreased 6.8% from $103.1 million in the nine months ended September 30, 2012 to $96.1 million in the nine months ended September 30, 2013. The decrease in selling, general and administrative
expenses for the three and nine months ended September 30, 2013 is primarily related to decreases in professional services, legal services and travel expense, which were higher in 2012 due to pre-acquisition activities related to the acquired
broadband access business, decreased independent contractor expense, and decreased headcount.

[0001193125-13-422365:mdna:74]
Selling, general and administrative expenses as a
percentage of sales decreased from 21.0% in the three months ended September 30, 2012 to 18.5% in the three months ended September 30, 2013 and decreased from 21.4% in the nine months ended September 30, 2012 to 19.9% in the nine
months ended September 30, 2013. Selling, general and administrative expenses as a percentage of sales may fluctuate whenever there is a significant fluctuation in revenues for the periods being compared.

[0001193125-13-422365:mdna:75]
[same as prior period, unchanged from 0001193125-13-312256:mdna:75]

[0001193125-13-422365:mdna:76]
Research and
development expenses decreased 8.5% from $35.6 million in the three months ended September 30, 2012 to $32.5 million in the three months ended September 30, 2013 and increased 5.7% from $92.8 million in the nine months ended
September 30, 2012 to $98.1 million in the nine months ended September 30, 2013. The decrease in research and development expenses for the three months ended September 30, 2013 is primarily related to decreased independent contractor
expense and decreased headcount. The increase in research and development expenses for the nine months ended September 30, 2013 is primarily related to increases in staffing and fringe benefit costs due to increased headcount related to the
broadband access business acquired on May 4, 2012, increases in amortization of acquired intangible assets and depreciation of acquired fixed assets, partially offset by a decrease in independent contractor expense.

[0001193125-13-422365:mdna:77]
As a percentage of sales, research and development expenses decreased from 21.9% in the three months ended September 30, 2012 to 18.3% in the three
months ended September 30, 2013 and increased from 19.3% in the nine months ended September 30, 2012 to 20.3% in the nine months ended September 30, 2013. Research and development expenses as a percentage of sales will fluctuate
whenever there are incremental product development activities or a significant fluctuation in revenues for the periods being compared.

[0001193125-13-422365:mdna:78]
We expect to
continue to incur research and development expenses in connection with our new and existing products and our expansion into international markets. We continually evaluate new product opportunities and engage in intensive research and product
development efforts which provides for new product development, enhancement of existing products and product cost reductions. We may incur significant research and development expenses prior to the receipt of revenues from a major new product group.

[0001193125-13-422365:mdna:79]
INTEREST AND DIVIDEND INCOME

[0001193125-13-422365:mdna:80]
Interest and
dividend income decreased 15.3% from $1.9 million in the three months ended September 30, 2012, to $1.6 million in the three months ended September 30, 2013, and decreased 11.1% from $5.7 million in the nine months ended September 30,
2012, to $5.0 million in the nine months ended September 30, 2013. The decrease is primarily driven by a reduction in the average rate of return on our investments as well as a decrease in our average investment balances.

[0001193125-13-422365:mdna:81]
[same as prior period, unchanged from 0001193125-13-312256:mdna:81]

[0001193125-13-422365:mdna:82]
Interest expense, which is
primarily related to our taxable revenue bond, remained constant at $0.6 million in each of the three months ended September 30, 2012 and 2013, and $1.8 million in the nine months ended September 30, 2012 and $1.7 million in the nine
months ended September 30, 2013, as we had no substantial change in our fixed-rate borrowing. See “Liquidity and Capital Resources” below for additional information on our revenue bond.

[0001193125-13-422365:mdna:83]
[same as prior period, unchanged from 0001193125-13-312256:mdna:83]

[0001193125-13-422365:mdna:84]
Net realized investment gain decreased 30.8% from $2.5 million in the three months ended September 30, 2012 to $1.8 million in the three months ended
September 30, 2013 and decreased 5.5% from $7.4 million in the nine months ended September 30, 2012 to $6.9 million in the nine months ended September 30, 2013. The lower amount of realized gains in the three and nine month periods
ended September 30, 2013 is primarily driven by lower gains from the sale of equity securities compared to the same period in 2012. See “Investing Activities” in “Liquidity and Capital Resources” below for additional
information.

[0001193125-13-422365:mdna:85]
[same as prior period, unchanged from 0001193125-13-312256:mdna:85]

[0001193125-13-422365:mdna:86]
Other income (expense), net, comprised primarily of miscellaneous income, gains and losses on foreign currency transactions, investment account management
fees, scrap raw material sales, and gains and losses on the disposal of property, plant and equipment occurring in the normal course of business, changed from $0.4 million of expense in the three months ended September 30, 2012 to $22 thousand
of income in the three months ended September 30, 2013 and changed from $0.3 million of income in the nine months ended September 30, 2012 to $1.5 million of expense in the nine months ended September 30, 2013. The change in the nine
months ended September 30, 2013 was primarily attributable to losses on foreign currency transactions during the first quarter of 2013.

[0001193125-13-422365:mdna:87]
INCOME
TAXES

[0001193125-13-422365:mdna:88]
Our effective tax rate decreased from 34.9% in the nine months ended September 30, 2012 to 27.0% in the nine months ended
September 30, 2013. The decrease in the effective tax rate between the two periods is primarily attributable to an acquired business that incurred losses in the prior year for which no tax benefit was recognized and the improved
profitability for that business in the current year, the net effect of recording the benefit for the research tax credit for the 2012 tax year in January 2013 pursuant to the American Taxpayer Relief Act of 2012, and the inclusion of the benefit of
the estimated 2013 research tax credit in the estimated annual effective rate for 2013.

[0001193125-13-422365:mdna:89]
[same as prior period, unchanged from 0001193125-13-312256:mdna:89]

[0001193125-13-422365:mdna:90]
As a result of the above factors, net income increased $6.9 million from $9.3 million in the three months ended September 30, 2012 to $16.2 million in the
three months ended September 30, 2013 and decreased $9.3 million from $43.3 million in the nine months ended September 30, 2012 to $34.0 million in the nine months ended September 30, 2013.

[0001193125-13-422365:mdna:91]
As a percentage of sales, net income increased from 5.7% in the three months ended September 30, 2012 to 9.1% in the three months ended
September 30, 2013 and decreased from 9.0% in the nine months ended September 30, 2012 to 7.0% in the nine months ended September 30, 2013.

[0001193125-13-422365:mdna:92]
[same as prior period, unchanged from 0001193125-13-312256:mdna:92]

[0001193125-13-422365:mdna:93]
[same as prior period, unchanged from 0001193125-13-312256:mdna:93]

[0001193125-13-422365:mdna:94]
We intend to finance our operations with cash flow from operations. We have used, and expect to continue to use, the cash generated from operations for working
capital, purchases of treasury stock, dividend payments, and other general corporate purposes, including (i) product development activities to enhance our existing products and develop new products and (ii) expansion of sales and marketing
activities. We believe our cash and cash equivalents, investments and cash generated from operations to be adequate to meet our operating and capital needs for the foreseeable future.

[0001193125-13-422365:mdna:95]
At September 30, 2013, cash on hand was $54.3 million and short-term investments were $136.6 million, which resulted in available short-term liquidity of
$191.0 million. At December 31, 2012, our cash on hand of $68.5 million and short-term investments of $160.5 million resulted in available short-term liquidity of $228.9 million. The decrease in short-term liquidity from December 31, 2012
to September 30, 2013 primarily reflects funds used for equipment acquisitions, share repurchases and dividends, partially offset by funds provided by our operating activities.

[0001193125-13-422365:mdna:96]
[same as prior period, unchanged from 0001193125-13-312256:mdna:96]

[0001193125-13-422365:mdna:97]
Our working capital, which consists of current assets less current liabilities, decreased 10.6% from $339.4 million as of December 31, 2012 to $303.4
million as of September 30, 2013. The quick ratio, defined as cash, cash equivalents, short-term investments, and net accounts receivable, divided by current liabilities, decreased from 2.90 as of December 31, 2012 to 2.35 as of
September 30, 2013. The current ratio, defined as current assets divided by current liabilities, decreased from 4.18 as of December 31, 2012 to 3.39 as of September 30, 2013. The decreases in our working capital, the quick ratio and
the current ratio is primarily attributable to a decrease in cash and short-term investments, which was used to fund treasury stock repurchases during the nine months ended September 30, 2013, and an increase in accounts payable.

[0001193125-13-422365:mdna:98]
Net accounts receivable increased 33.0% from $81.2 million at December 31, 2012 to $108.0 million at September 30, 2013. Our allowance for doubtful
accounts was $6 thousand at December 31, 2012 and $15 thousand at September 30, 2013. Quarterly accounts receivable days sales outstanding (DSO) increased from 53 days as of December 31, 2012 to 56 days as of September 30, 2013.
The change in net accounts receivable and DSO is due to the timing of sales and collections during the quarter, international revenue mix, and customer mix. Many of our international customers have longer payment terms than our U.S. customers.

[0001193125-13-422365:mdna:99]
Quarterly inventory turnover increased from 2.8 turns as of December 31, 2012 to 4.2 turns as of September 30, 2013. Inventory decreased 9.4% from
December 31, 2012 to September 30, 2013. We expect inventory levels to fluctuate as we attempt to maintain sufficient inventory in response to seasonal cycles of our business ensuring competitive lead times while managing the risk of
inventory obsolescence that may occur due to rapidly changing technology and customer demand.

[0001193125-13-422365:mdna:100]
Accounts payable increased 74.7% from $42.2 million at
December 31, 2012 to $73.7 million at September 30, 2013. Accounts payable will fluctuate due to variations in the timing of the receipt of supplies, inventory and services and our subsequent payments for these purchases.

[0001193125-13-422365:mdna:101]
[same as prior period, unchanged from 0001193125-13-312256:mdna:101]

[0001193125-13-422365:mdna:102]
Capital expenditures totaled
approximately $10.8 million and $6.5 million for the nine months ended September 30, 2012 and 2013, respectively. These expenditures were primarily used to purchase manufacturing and test equipment and computer software and hardware.

[0001193125-13-422365:mdna:103]
Our combined short-term and long-term investments decreased $58.4 million from $493.2 million at December 31, 2012 to $434.8 million at
September 30, 2013. This decrease reflects the impact of our cash needs for equipment acquisitions, share repurchases and dividends, as well as net realized and unrealized losses and amortization of net premiums on our combined investments,
partially offset by additional funds available for investment provided by our operating activities and stock option exercises by our employees.

[0001193125-13-422365:mdna:104]
We invest
all available cash not required for immediate use in operations primarily in securities that we believe bear minimal risk of loss. At September 30, 2013 these investments included corporate bonds of $178.1 million, municipal fixed-rate bonds of
$145.9 million and municipal variable rate demand notes of $12.0 million. At December 31, 2012, these investments included corporate bonds of $186.4 million, municipal fixed-rate bonds of $175.1 million and municipal variable rate demand notes
of $34.4 million. As of September 30, 2013, our corporate bonds, municipal fixed-rate bonds, and municipal variable rate demand notes were classified as available-for-sale and had a combined duration of 0.94 years with an average credit rating
of A+. Because our bond portfolio has a high quality rating and contractual maturities of a short duration, we are able to obtain prices for these bonds derived from observable market inputs, or for similar securities traded in an active market, on
a daily basis.

[0001193125-13-422365:mdna:105]
Our long-term investments decreased 10.4% from $332.7 million at December 31, 2012 to $298.1 million at September 30, 2013. The
primary reason for the decrease in our long-term investments during 2013 was the movement of certain long-term corporate bonds and long-term municipal bonds to short-term classification. Long-term investments at September 30, 2013 and
December 31, 2012 included an investment in a certificate of deposit of $48.3 million, which serves as collateral for our revenue bonds, as discussed below. We have various equity investments included in long-term investments at a cost of $22.8
million and $21.0 million, and with a fair value of $34.9 million and $35.2 million, at September 30, 2013 and December 31, 2012, respectively.

[0001193125-13-422365:mdna:106]
Long-term investments at September 30, 2013 also includes $13.8 million related to our deferred compensation
plans and $1.8 million of other investments carried at cost, consisting of interests in two private equity funds and an investment in a privately held telecommunications equipment manufacturer.

[0001193125-13-422365:mdna:107]
We review our investment portfolio for potential “other-than-temporary” declines in value on an individual investment basis. We assess, on a
quarterly basis, significant declines in value which may be considered other-than-temporary and, if necessary, recognize and record the appropriate charge to write-down the carrying value of such investments. In making this assessment, we take into
consideration qualitative and quantitative information, including but not limited to the following: the magnitude and duration of historical declines in market prices, credit rating activity, assessments of liquidity, public filings, and statements
made by the issuer. We generally begin our identification of potential other-than-temporary impairments by reviewing any security with a fair value that has declined from its original or adjusted cost basis by 25% or more for six or more consecutive
months. We then evaluate the individual security based on the previously identified factors to determine the amount of the write-down, if any. As a result of our review, we recorded an other-than-temporary impairment charge of $13 thousand during
the nine months ended September 30, 2013 related to five marketable securities. For the nine months ended September 30, 2012, we recorded an other-than-temporary impairment charge of $0.1 million related to 21 marketable equity securities.

[0001193125-13-422365:mdna:108]
[same as prior period, unchanged from 0001193125-13-312256:mdna:108]

[0001193125-13-422365:mdna:109]
[same as prior period, unchanged from 0001193125-13-312256:mdna:109]

[0001193125-13-422365:mdna:110]
In July 2003, our Board of Directors elected to begin declaring quarterly dividends on our common stock considering the tax treatment of dividends and adequate
levels of Company liquidity. During the nine months ended September 30, 2013, we paid dividends totaling $16.2 million.

[0001193125-13-422365:mdna:111]
[same as prior period, unchanged from 0001193125-13-312256:mdna:111]

[0001193125-13-422365:mdna:112]
We have amounts outstanding under loans made pursuant to an Alabama State Industrial Development Authority revenue bond (the Bond) which totaled
$46.5 million at September 30, 2013 and December 31, 2012. At September 30, 2013, the estimated fair value of the Bond was approximately $44.9 million, based on a debt security with a comparable interest rate and maturity
and a Standard & Poor’s credit rating of A-. Included in long-term investments are restricted funds in the amount of $48.3 million at September 30, 2013 and December 31, 2012, which is a collateral deposit against
the principal amount of the Bond. We have the right to set-off the balance of the Bond with the collateral deposit in order to reduce the balance of the indebtedness. The Bond matures on January 1, 2020, and bears interest at the rate of
5% per annum. In conjunction with this program, we are eligible to receive certain economic incentives from the state of Alabama that reduce the amount of payroll withholdings we are required to remit to the state for those employment
positions that qualify under this program. We are required to make payments in the amounts necessary to pay the interest on the amounts currently outstanding.

[0001193125-13-422365:mdna:113]
[same as prior period, unchanged from 0001193125-13-312256:mdna:114]

[0001193125-13-422365:mdna:114]
Since 1997, our Board of
Directors has approved multiple share repurchase programs that have authorized open market repurchase transactions of up to 35 million shares of our common stock. On May 1, 2013, our Board of Directors authorized the repurchase of an
additional 5.0 million shares of our common stock, which commenced upon completion of the repurchase plan announced on October 11, 2011. This new authorization is being implemented through open market or private purchases from time to time
as conditions warrant.

[0001193125-13-422365:mdna:115]
During the nine months ended September 30, 2013, we repurchased 4.8 million shares of our common stock at an average
price of $21.89 per share. We currently have the authority to purchase an additional 4.3 million shares of our common stock under the current plan approved by the Board of Directors on May 1, 2013.

[0001193125-13-422365:mdna:116]
[same as prior period, unchanged from 0001193125-13-312256:mdna:117]

[0001193125-13-422365:mdna:117]
To accommodate employee stock
option exercises, we issued 0.1 million shares of treasury stock for $2.3 million during the nine months ended September 30, 2013. During the nine months ended September 30, 2012, we issued 0.3 million shares of treasury stock
for $4.9 million.

[0001193125-13-422365:mdna:118]
[same as prior period, unchanged from 0001193125-13-312256:mdna:119]

[0001193125-13-422365:mdna:119]
We do not have off-balance sheet financing arrangements and have not engaged in any related party transactions or arrangements with unconsolidated entities or
other persons that are reasonably likely to materially affect liquidity or the availability of or requirements for capital resources. During the nine months ended September 30, 2013, there have been no material changes in contractual
obligations and commercial commitments from those discussed in our most recent Annual Report on Form 10-K for the year ended December 31, 2012 filed on February 28, 2013 with the SEC.

[0001193125-13-422365:mdna:120]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, and we have contributed $8.4 million as of September 30,
2013, of which $7.7 million has been applied to these commitments.

[0001193125-13-422365:mdna:121]
[same as prior period, unchanged from 0001193125-13-312256:mdna:122]

[0001193125-13-422365:mdna:122]
The following are some of the risks that could affect our financial performance or could cause actual results to differ materially from those expressed or
implied in our forward-looking statements:

[0001193125-13-422365:mdna:123]
[same as prior period, unchanged from 0001193125-13-312256:mdna:124]

[0001193125-13-422365:mdna:124]
[same as prior period, unchanged from 0001193125-13-312256:mdna:125]

[0001193125-13-422365:mdna:125]
|  | • |  | The failure to realize the benefits from the acquisition of the NSN BBA business as significantly as we expect may affect our future results of operations and financial condition, and could affect our stock price. |

[0001193125-13-422365:mdna:126]
[same as prior period, unchanged from 0001193125-13-312256:mdna:127]

[0001193125-13-422365:mdna:127]
[same as prior period, unchanged from 0001193125-13-312256:mdna:128]

[0001193125-13-422365:mdna:128]
[same as prior period, unchanged from 0001193125-13-312256:mdna:129]

[0001193125-13-422365:mdna:129]
[same as prior period, unchanged from 0001193125-13-312256:mdna:130]

[0001193125-13-422365:mdna:130]
[same as prior period, unchanged from 0001193125-13-312256:mdna:131]

[0001193125-13-422365:mdna:131]
[same as prior period, unchanged from 0001193125-13-312256:mdna:132]

[0001193125-13-422365:mdna:132]
[same as prior period, unchanged from 0001193125-13-312256:mdna:133]

[0001193125-13-422365:mdna:133]
[same as prior period, unchanged from 0001193125-13-312256:mdna:134]

[0001193125-13-422365:mdna:134]
[same as prior period, unchanged from 0001193125-13-312256:mdna:135]

[0001193125-13-422365:mdna:135]
[same as prior period, unchanged from 0001193125-13-312256:mdna:136]

[0001193125-13-422365:mdna:136]
[same as prior period, unchanged from 0001193125-13-312256:mdna:137]

[0001193125-13-422365:mdna:137]
[same as prior period, unchanged from 0001193125-13-312256:mdna:138]

[0001193125-13-422365:mdna:138]
[same as prior period, unchanged from 0001193125-13-312256:mdna:139]

[0001193125-13-422365:mdna:139]
[same as prior period, unchanged from 0001193125-13-312256:mdna:140]

[0001193125-13-422365:mdna:140]
[same as prior period, unchanged from 0001193125-13-312256:mdna:141]

[0001193125-13-422365:mdna:141]
[same as prior period, unchanged from 0001193125-13-312256:mdna:142]

[0001193125-13-422365:mdna:142]
[same as prior period, unchanged from 0001193125-13-312256:mdna:143]

[0001193125-13-422365:mdna:143]
37

[0001193125-13-422365:mdna:144]
[same as prior period, unchanged from 0001193125-13-312256:mdna:144]

[0001193125-13-422365:mdna:145]
[same as prior period, unchanged from 0001193125-13-312256:mdna:145]

[0001193125-13-422365:mdna:146]
[same as prior period, unchanged from 0001193125-13-312256:mdna:146]

[0001193125-13-422365:mdna:147]
|  | • |  | We may incur liabilities or become subject to litigation that would have a material effect on our business. |

[0001193125-13-422365:mdna:148]
[same as prior period, unchanged from 0001193125-13-312256:mdna:148]

[0001193125-13-422365:mdna:149]
[same as prior period, unchanged from 0001193125-13-312256:mdna:149]

[0001193125-13-422365:mdna:150]
[same as prior period, unchanged from 0001193125-13-312256:mdna:151]

[0001193125-13-422365:mdna:151]
[same as prior period, unchanged from 0001193125-13-312256:mdna:152]

[0001193125-13-422365:mdna:152]
[same as prior period, unchanged from 0001193125-13-312256:mdna:153]

[0001193125-13-422365:mdna:153]
[same as prior period, unchanged from 0001193125-13-312256:mdna:154]

[0001193125-13-422365:mdna:154]
[same as prior period, unchanged from 0001193125-13-312256:mdna:155]

[0001193125-13-422365:mdna:155]
[same as prior period, unchanged from 0001193125-13-312256:mdna:156]

[0001193125-13-422365:mdna:156]
[same as prior period, unchanged from 0001193125-13-312256:mdna:157]

[0001193125-13-422365:mdna:157]
[same as prior period, unchanged from 0001193125-13-312256:mdna:158]

[0001193125-13-422365:mdna:158]
The foregoing
list of risks is not exclusive. For a more detailed description of the risk factors associated with our business, see Item 1A of our Annual Report on Form 10-K for the year ended December 31, 2012, filed on February 28, 2013 with the
SEC.
