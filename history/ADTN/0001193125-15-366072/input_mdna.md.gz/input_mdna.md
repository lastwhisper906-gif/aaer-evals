# ADTN MD&A — 0001193125-15-366072


## mdna

[0001193125-15-366072:mdna:1]
[same as prior period, unchanged from 0001193125-15-278444:mdna:1]

[0001193125-15-366072:mdna:2]
[same as prior period, unchanged from 0001193125-15-278444:mdna:2]

[0001193125-15-366072:mdna:3]
[same as prior period, unchanged from 0001193125-15-278444:mdna:3]

[0001193125-15-366072:mdna:4]
[same as prior period, unchanged from 0001193125-15-278444:mdna:4]

[0001193125-15-366072:mdna:5]
[same as prior period, unchanged from 0001193125-15-278444:mdna:5]

[0001193125-15-366072:mdna:6]
[same as prior period, unchanged from 0001193125-15-278444:mdna:6]

[0001193125-15-366072:mdna:7]
[same as prior period, unchanged from 0001193125-15-278444:mdna:7]

[0001193125-15-366072:mdna:8]
[same as prior period, unchanged from 0001193125-15-278444:mdna:8]

[0001193125-15-366072:mdna:9]
[same as prior period, unchanged from 0001193125-15-278444:mdna:9]

[0001193125-15-366072:mdna:10]
[same as prior period, unchanged from 0001193125-15-278444:mdna:10]

[0001193125-15-366072:mdna:11]
[same as prior period, unchanged from 0001193125-15-278444:mdna:11]

[0001193125-15-366072:mdna:12]
[same as prior period, unchanged from 0001193125-15-278444:mdna:12]

[0001193125-15-366072:mdna:13]
[same as prior period, unchanged from 0001193125-15-278444:mdna:13]

[0001193125-15-366072:mdna:14]
[same as prior period, unchanged from 0001193125-15-278444:mdna:14]

[0001193125-15-366072:mdna:15]
[same as prior period, unchanged from 0001193125-15-278444:mdna:15]

[0001193125-15-366072:mdna:16]
[same as prior period, unchanged from 0001193125-15-278444:mdna:16]

[0001193125-15-366072:mdna:17]
[same as prior period, unchanged from 0001193125-15-278444:mdna:17]

[0001193125-15-366072:mdna:18]
[same as prior period, unchanged from 0001193125-15-278444:mdna:18]

[0001193125-15-366072:mdna:19]
[same as prior period, unchanged from 0001193125-15-278444:mdna:19]

[0001193125-15-366072:mdna:20]
[same as prior period, unchanged from 0001193125-15-278444:mdna:20]

[0001193125-15-366072:mdna:21]
[same as prior period, unchanged from 0001193125-15-278444:mdna:21]

[0001193125-15-366072:mdna:22]
[same as prior period, unchanged from 0001193125-15-278444:mdna:22]

[0001193125-15-366072:mdna:23]
[same as prior period, unchanged from 0001193125-15-278444:mdna:23]

[0001193125-15-366072:mdna:24]
[same as prior period, unchanged from 0001193125-15-278444:mdna:24]

[0001193125-15-366072:mdna:25]
[same as prior period, unchanged from 0001193125-15-278444:mdna:25]

[0001193125-15-366072:mdna:26]
[same as prior period, unchanged from 0001193125-15-278444:mdna:26]

[0001193125-15-366072:mdna:27]
[same as prior period, unchanged from 0001193125-15-278444:mdna:27]

[0001193125-15-366072:mdna:28]
[same as prior period, unchanged from 0001193125-15-278444:mdna:28]

[0001193125-15-366072:mdna:29]
[same as prior period, unchanged from 0001193125-15-278444:mdna:29]

[0001193125-15-366072:mdna:30]
[same as prior period, unchanged from 0001193125-15-278444:mdna:30]

[0001193125-15-366072:mdna:31]
[same as prior period, unchanged from 0001193125-15-278444:mdna:31]

[0001193125-15-366072:mdna:32]
[same as prior period, unchanged from 0001193125-15-278444:mdna:32]

[0001193125-15-366072:mdna:33]
[same as prior period, unchanged from 0001193125-15-278444:mdna:33]

[0001193125-15-366072:mdna:34]
[same as prior period, unchanged from 0001193125-15-278444:mdna:34]

[0001193125-15-366072:mdna:35]
[same as prior period, unchanged from 0001193125-15-278444:mdna:35]

[0001193125-15-366072:mdna:36]
[same as prior period, unchanged from 0001193125-15-278444:mdna:36]

[0001193125-15-366072:mdna:37]
[same as prior period, unchanged from 0001193125-15-278444:mdna:37]

[0001193125-15-366072:mdna:38]
[same as prior period, unchanged from 0001193125-15-278444:mdna:38]

[0001193125-15-366072:mdna:39]
[same as prior period, unchanged from 0001193125-15-278444:mdna:39]

[0001193125-15-366072:mdna:40]
[same as prior period, unchanged from 0001193125-15-278444:mdna:40]

[0001193125-15-366072:mdna:41]
[same as prior period, unchanged from 0001193125-15-278444:mdna:41]

[0001193125-15-366072:mdna:42]
[same as prior period, unchanged from 0001193125-15-278444:mdna:42]

[0001193125-15-366072:mdna:43]
[same as prior period, unchanged from 0001193125-15-278444:mdna:43]

[0001193125-15-366072:mdna:44]
Sales were $158.1 million and $461.1 million for the three and nine months ended September 30, 2015,
compared to $162.9 million and $486.0 million for the three and nine months ended September 30, 2014. Product revenues for our three core areas, Broadband Access, Optical and Internetworking, were $146.0 million and $427.8 million for the three
and nine months ended September 30, 2015, compared to $148.4 million and $444.8 million for the three and nine months ended September 30, 2014. Our gross margin decreased to 44.7% and 44.3% for the three and nine months ended
September 30, 2015 from 48.0% and 50.0% for the three and nine months ended September 30, 2014. Our operating income margin decreased to 5.1% and 2.3% for the three and nine months ended September 30, 2015 from 7.7% and 8.9% for
the three and nine months ended September 30, 2014. Net income was $7.1 million and $12.9 million for the three and nine months ended September 30, 2015 compared to $11.3 million and $35.3 million for the three and nine months ended
September 30, 2014. Our effective tax rate increased to 35.0% and 36.9% for the three and nine months ended September 30, 2015 from 24.8% and 31.5% for the three and nine months ended September 30, 2014. Earnings per share,
assuming dilution, were $0.14 and $0.25 for the three and nine months ended September 30, 2015 compared to $0.21 and $0.63 for the three and nine months ended September 30, 2014.

[0001193125-15-366072:mdna:45]
[same as prior period, unchanged from 0001193125-15-278444:mdna:45]

[0001193125-15-366072:mdna:46]
[same as prior period, unchanged from 0001193125-15-278444:mdna:46]

[0001193125-15-366072:mdna:47]
[same as prior period, unchanged from 0001193125-15-278444:mdna:47]

[0001193125-15-366072:mdna:48]
[same as prior period, unchanged from 0001193125-15-278444:mdna:48]

[0001193125-15-366072:mdna:49]
[same as prior period, unchanged from 0001193125-15-278444:mdna:49]

[0001193125-15-366072:mdna:50]
[same as prior period, unchanged from 0001193125-15-278444:mdna:50]

[0001193125-15-366072:mdna:51]
[same as prior period, unchanged from 0001193125-15-278444:mdna:51]

[0001193125-15-366072:mdna:52]
[same as prior period, unchanged from 0001193125-15-278444:mdna:52]

[0001193125-15-366072:mdna:53]
RESULTS OF OPERATIONS – THREE AND NINE MONTHS ENDED SEPTEMBER 30, 2015 COMPARED TO THREE AND NINE
MONTHS ENDED SEPTEMBER 30, 2014

[0001193125-15-366072:mdna:54]
[same as prior period, unchanged from 0001193125-15-278444:mdna:54]

[0001193125-15-366072:mdna:55]
ADTRAN’s sales decreased 3.0% from $162.9 million in the three months ended September 30, 2014 to $158.1 million in the three months ended
September 30, 2015, and decreased 5.1% from $486.0 million in the nine months ended September 30, 2014 to $461.1 million in the nine months ended September 30, 2015. The decrease in sales for the three months ended
September 30, 2015 is primarily attributable to a $2.4 million decrease in sales of our HDSL and other legacy products and a $2.0 million decrease in sales of our Broadband Access products. The decrease in sales for the nine months ended
September 30, 2015 is primarily attributable to an $11.1 million decrease in sales of our Internetworking products, a $7.9 million decrease in sales of our HDSL and other legacy products, and a $6.3 million decrease in sales of our Broadband
Access products.

[0001193125-15-366072:mdna:56]
Carrier Networks sales decreased 1.3% from $133.0 million in the three months ended September 30, 2014 to
$131.3 million in the three months ended September 30, 2015, and decreased 3.0% from $394.6 million in the nine months ended September 30, 2014 to $382.7 million in the nine months ended September 30, 2015. The decrease in sales for
the three and nine months ended September 30, 2015 is primarily attributable to decreases in sales of our Broadband Access products and sales of our HDSL and other legacy products, partially offset by an increase in sales of our Internetworking
products. The decrease in sales of our Broadband Access products is primarily attributable to decreased sales in the EMEA region and the impact of the strengthening of the U.S. dollar against the Euro. The decrease in sales of HDSL and other legacy
products has been expected as customers continue to upgrade their networks to deliver higher bandwidth services by migrating to newer technologies, including to our core products from our Broadband Access, Internetworking and Optical product lines.
While we expect that revenues from HDSL and our other legacy products will continue to decline over time, these revenues may fluctuate and continue for years because of the time required for our customers to transition to newer technologies. The
increase in sales of Internetworking products for this division is primarily attributable to increased sales of our FTTP ONT products.

[0001193125-15-366072:mdna:57]
Enterprise
Networks sales decreased 10.4% from $29.9 million in the three months ended September 30, 2014 to $26.8 million in the three months ended September 30, 2015, and decreased 14.3% from $91.4 million in the nine months ended
September 30, 2014 to $78.4 million in the nine months ended September 30, 2015. The decrease in sales for the three and nine months ended September 30, 2015 is primarily attributable to decreases in sales of our Internetworking
products. The decrease in sales of our Internetworking products for this division was primarily attributable to weakness in our IP gateway product segment. Internetworking product sales attributable to Enterprise Networks were 93.8% and 93.6% of the
division’s sales in the three and nine months ended September 30, 2015, compared to 93.4% and 94.2% in the three and nine months ended September 30, 2014. Legacy products primarily comprise the remainder of Enterprise Networks sales.
Enterprise Networks sales as a percentage of total sales decreased from 18.4% and 18.8% for the three and nine months ended September 30, 2014 to 17.0% for the three and nine months ended September 30, 2015.

[0001193125-15-366072:mdna:58]
International sales, which are included in the Carrier Networks and Enterprise Networks amounts discussed above, decreased 40.0% from $64.3 million in the
three months ended September 30, 2014 to $38.6 million in the three months ended September 30, 2015, and decreased 22.3% from $197.7 million in the nine months ended September 30, 2014 to $153.7 million in the nine months ended
September 30, 2015. International sales, as a percentage of total sales, decreased from 39.5% and 40.7% for the three and nine months ended September 30, 2014 to 24.4% and 33.3% for the three and nine months ended September 30, 2015.
The decrease in international sales for the three months ended September 30, 2015 is primarily attributable to a decrease in sales in the EMEA region and the Asia-Pacific region, partially offset by an increase in sales in Latin America. The
decrease in international sales for the nine months ended September 30, 2015 is primarily attributable to a decrease in sales in the EMEA region, Latin America and the Asia-Pacific region. The decrease in sales in the EMEA region is primarily
attributable to the strengthening of the U.S. dollar against the Euro during the three and nine months ended September 30, 2015.

[0001193125-15-366072:mdna:59]
Carrier System
product sales decreased $2.9 million from $114.0 million in the three months ended September 30, 2014 to $111.0 million in the three months ended September 30, 2015, and decreased $11.8 million from $342.3 million in the nine months
ended September 30, 2014 to $330.5 million in the nine months ended September 30, 2015. The decrease for the three months ended September 30, 2015 is primarily attributable to a $2.0 million decrease in Broadband Access product sales
and a $1.0 million decrease in legacy product sales. The decrease for the nine months ended September 30, 2015 is primarily attributable to a $6.3 million decrease in Broadband Access product sales and a $5.9 million decrease in
legacy product sales. The decreases for the three and nine months ended September 30, 2015 are primarily attributable to the factors discussed above.

[0001193125-15-366072:mdna:60]
Business Networking product sales decreased $0.6 million from $39.7 million in the three months ended September 30, 2014 to $39.1 million in the
three months ended September 30, 2015, and decreased $10.9 million from $119.6 million in the nine months ended September 30, 2014 to $108.7 million in the nine months ended September 30, 2015. The decrease for the three months ended
September 30, 2015 is primarily attributable to a $0.5 million decrease in Internetworking product sales. The decrease for the nine months ended September 30, 2015 is primarily attributable to an $11.1 million decrease in
Internetworking product sales. The decreases for the three and nine months ended September 30, 2015 are primarily attributable to the factors discussed above.

[0001193125-15-366072:mdna:61]
28

[0001193125-15-366072:mdna:62]
Loop Access product sales decreased $1.3 million from $9.2 million in the three months ended September 30,
2014 to $7.9 million in the three months ended September 30, 2015, and decreased $2.3 million from $24.1 million in the nine months ended September 30, 2014 to $21.8 million in the nine months ended September 30, 2015. The decrease
for the three months ended September 30, 2015 is primarily attributable to a $1.0 million decrease in HDSL product sales. The decrease for the nine months ended September 30, 2015 is primarily attributable to a $1.6 million decrease in
HDSL product sales. The decreases for the three and nine months ended September 30, 2015 are primarily attributable to the factors discussed above.

[0001193125-15-366072:mdna:63]
[same as prior period, unchanged from 0001193125-15-278444:mdna:62]

[0001193125-15-366072:mdna:64]
As a percentage of sales, cost of
sales increased from 52.0% in the three months ended September 30, 2014 to 55.3% in the three months ended September 30, 2015, and increased from 50.0% in the nine months ended September 30, 2014 to 55.7% in the nine months ended
September 30, 2015. The increase for the three months ended September 30, 2015 is primarily attributable to the strengthening of the U.S. dollar against the Euro, growth in our service-related sales in the U.S. market, and customer mix.
The increase in the nine months ended September 30, 2015 is primarily attributable to the strengthening of the U.S. dollar against the Euro, growth in our service-related sales in the U.S. market, and product mix.

[0001193125-15-366072:mdna:65]
Carrier Networks cost of sales, as a percent of division sales, increased from 53.6% in the three months ended September 30, 2014 to 57.5% in the three
months ended September 30, 2015, and increased from 51.6% in the nine months ended September 30, 2014 to 58.1% in the nine months ended September 30, 2015. The increase for the three and nine months ended September 30, 2015 is
primarily attributable to the strengthening of the U.S. dollar against the Euro, growth in service-related sales in our U.S. market, customer mix, and customer price movements to achieve market share position.

[0001193125-15-366072:mdna:66]
Enterprise Networks cost of sales, as a percent of division sales, remained consistent at 44.6% in the three months ended September 30, 2014 and 2015,
and increased from 43.4% in the nine months ended September 30, 2014 to 43.7% in the nine months ended September 30, 2015. The increase for the nine months ended September 30, 2015 is primarily attributable to the shift in product and
services mix.

[0001193125-15-366072:mdna:67]
An important part of our strategy is to reduce the product cost of each succeeding product generation and then to lower the product’s
price based on the cost savings achieved. This may cause variations in our gross profit percentage due to timing differences between the recognition of cost reductions and the lowering of product selling prices.

[0001193125-15-366072:mdna:68]
[same as prior period, unchanged from 0001193125-15-278444:mdna:67]

[0001193125-15-366072:mdna:69]
Selling, general and administrative expenses decreased 7.5% from $32.4 million in the three months ended September 30, 2014 to $30.0 million in the three
months ended September 30, 2015, and decreased 7.0% from $100.2 million in the nine months ended September 30, 2014 to $93.2 million in the nine months ended September 30, 2015. The decrease in selling, general and administrative
expenses for the three months ended September 30, 2015 is primarily attributable to decreases in compensation expense and travel expense, partially offset by restructuring charges. The decrease in selling, general and administrative expenses
for the nine months ended September 30, 2015 is primarily attributable to decreases in compensation expense, legal expense, and independent contractor expense, partially offset by restructuring charges.

[0001193125-15-366072:mdna:70]
As a percentage of sales, selling, general and administrative expenses decreased from 19.9% in the three months ended September 30, 2014 to 19.0% in the
three months ended September 30, 2015, and decreased from 20.6% in the nine months ended September 30, 2014 to 20.2% in the nine months ended September 30, 2015. Selling, general and administrative expenses as a percentage of sales
may fluctuate whenever there is a significant fluctuation in revenues for the periods being compared.

[0001193125-15-366072:mdna:71]
RESEARCH AND DEVELOPMENT EXPENSES

[0001193125-15-366072:mdna:72]
Research and development expenses decreased 2.3% from $33.3 million in the three months ended September 30, 2014 to $32.6 million in the three months
ended September 30, 2015, and increased 1.0% from $99.5 million in the nine months ended September 30, 2014 to $100.6 million in the nine months ended September 30, 2015. The decrease in research and development expenses for the three
months ended September 30, 2015 is primarily attributable to a decrease in compensation expense, partially offset by restructuring charges and an increase in engineering and testing expense. These restructuring charges were primary attributable
to the consolidation of engineering resources. The increase in research and development expense for the nine months ended September 30, 2015 is primarily attributable to restructuring charges and an increase in engineering and testing expense,
partially offset by a decrease in compensation expense.

[0001193125-15-366072:mdna:73]
As a percentage of sales, research and development expenses increased from 20.5% in the three
months ended September 30, 2014 to 20.6% in the three months ended September 30, 2015, and increased from 20.5% in the nine months ended September 30, 2014 to 21.8% in the nine months ended September 30, 2015. Research and
development expenses as a percentage of sales will fluctuate whenever there are incremental product development activities or a significant fluctuation in revenues for the periods being compared.

[0001193125-15-366072:mdna:74]
We expect to continue to incur research and development expenses in connection with our new and existing products and our expansion into international
markets. We continually evaluate new product opportunities and engage in intensive research and product development efforts which provides for new product development, enhancement of existing products and product cost reductions. We may incur
significant research and development expenses prior to the receipt of revenues from a major new product group.

[0001193125-15-366072:mdna:75]
[same as prior period, unchanged from 0001193125-15-278444:mdna:74]

[0001193125-15-366072:mdna:76]
Interest and dividend income decreased 15.4% from $1.0 million in the three months ended September 30, 2014 to $0.8 million in the three
months ended September 30, 2015, and decreased 19.8% from $3.3 million in the nine months ended September 30, 2014 to $2.7 million in the nine months ended September 30, 2015. The decreases in interest and dividend income for the
three and nine months ended September 30, 2015 are primarily attributable to a reduction in investment principal.

[0001193125-15-366072:mdna:77]
[same as prior period, unchanged from 0001193125-15-278444:mdna:76]

[0001193125-15-366072:mdna:78]
Interest expense, which is primarily related to our taxable revenue bond, remained constant at $0.2 million in the three months ended
September 30, 2014 and 2015, and $0.5 million in the nine months ended September 30, 2014 and $0.4 million in the nine months ended September 30, 2015, as we had no substantial change in our fixed-rate borrowing. See “Liquidity
and Capital Resources” below for additional information on our revenue bond.

[0001193125-15-366072:mdna:79]
[same as prior period, unchanged from 0001193125-15-278444:mdna:78]

[0001193125-15-366072:mdna:80]
Net realized investment gain decreased 23.3% from $2.7 million in the three months ended September 30, 2014 to $2.1 million in the three months ended
September 30, 2015, and increased 16.8% from $7.2 million in the nine months ended September 30, 2014 to $8.4 million in the nine months ended September 30, 2015. The decrease in realized investment gains for the three months ended
September 30, 2015 is primarily attributable to decreased gains from the sale of equity securities. The increase in realized investment gains for the nine months ended September 30, 2015 is primarily attributable to increased gains from
the sale of equity securities in the first two quarters of 2015. See “Investing Activities” in “Liquidity and Capital Resources” below for additional information.

[0001193125-15-366072:mdna:81]
[same as prior period, unchanged from 0001193125-15-278444:mdna:80]

[0001193125-15-366072:mdna:82]
Other income
(expense), net, comprised primarily of miscellaneous income, gains and losses on foreign currency transactions, investment account management fees, and scrap raw material sales, changed from $1.0 million of expense in the three months ended
September 30, 2014 to $0.1 million of income in the three months ended September 30, 2015, and changed from $1.6 million of expense in the nine months ended September 30, 2014 to $0.8 million of expense in the nine months ended
September 30, 2015. The change for the three and nine months ended September 30, 2015 is primarily attributable to gains on foreign currency transactions during the third quarter of 2015.

[0001193125-15-366072:mdna:83]
[same as prior period, unchanged from 0001193125-15-278444:mdna:82]

[0001193125-15-366072:mdna:84]
Our effective tax rate increased from 31.5% in the nine months ended September 30, 2014 to 36.9% in the nine months ended September 30, 2015. The
increase in the effective tax rate between the two periods is primarily attributable to the release of a valuation allowance attributable to a foreign subsidiary in 2014, partially offset by settlements with tax authorities and expiration of
statutes in 2015.

[0001193125-15-366072:mdna:85]
[same as prior period, unchanged from 0001193125-15-278444:mdna:84]

[0001193125-15-366072:mdna:86]
As a result of
the above factors, net income decreased $4.3 million from $11.3 million in the three months ended September 30, 2014 to $7.1 million in the three months ended September 30, 2015, and decreased $22.4 million from $35.3 million in the nine
months ended September 30, 2014 to $12.9 million in the nine months ended September 30, 2015.

[0001193125-15-366072:mdna:87]
As a percentage of sales, net income decreased
from 7.0% in the three months ended September 30, 2014 to 4.5% in the three months ended September 30, 2015, and decreased from 7.3% in the nine months ended September 30, 2014 to 2.8% in the nine months ended September 30, 2015.

[0001193125-15-366072:mdna:88]
[same as prior period, unchanged from 0001193125-15-278444:mdna:87]

[0001193125-15-366072:mdna:89]
[same as prior period, unchanged from 0001193125-15-278444:mdna:88]

[0001193125-15-366072:mdna:90]
We intend to finance our operations with cash flow from operations. We have used, and expect to continue to use, the cash generated from operations
for working capital, purchases of treasury stock, shareholder dividends, and other general corporate purposes, including (i) product development activities to enhance our existing products and develop new products and (ii) expansion of
sales and marketing activities. We believe our cash and cash equivalents, investments and cash generated from operations to be adequate to meet our operating and capital needs for at least the next 12 months.

[0001193125-15-366072:mdna:91]
At September 30, 2015, cash on hand was $83.7 million and short-term investments were $42.1 million, which resulted in available short-term liquidity of
$125.8 million. At December 31, 2014, our cash on hand of $73.4 million and short-term investments of $46.9 million resulted in available short-term liquidity of $120.4 million. The increase in short-term liquidity from December 31,
2014 to September 30, 2015 is primarily attributable to a reallocation of our investments to provide additional funds for our short-term cash needs, which includes operating activities, capital expenditures, purchase of treasury stock, and
shareholder dividends.

[0001193125-15-366072:mdna:92]
[same as prior period, unchanged from 0001193125-15-278444:mdna:91]

[0001193125-15-366072:mdna:93]
Our
working capital, which consists of current assets less current liabilities, decreased 0.9% from $232.1 million as of December 31, 2014 to $229.9 million as of September 30, 2015. The quick ratio, defined as cash, cash equivalents,
short-term investments, and net accounts receivable, divided by current liabilities, decreased from 1.75 as of December 31, 2014 to 1.67 as of September 30, 2015. The current ratio, defined as current assets divided by current liabilities,
decreased from 2.95 as of December 31, 2014 to 2.81 as of September 30, 2015. The changes in our working capital, quick ratio and current ratio are primarily attributable to increases in cash and inventory, and a decrease in unearned
revenue, partially offset by an increase in accounts payable and a decrease in short-term investments.

[0001193125-15-366072:mdna:94]
Net accounts receivable decreased 2.6% from $88.5
million at December 31, 2014 to $86.2 million at September 30, 2015. Our allowance for doubtful accounts was $0.1 million at December 31, 2014 and $21 thousand at September 30, 2015. Quarterly accounts receivable days sales
outstanding (DSO) decreased from 57 days as of December 31, 2014 to 50 days as of September 30, 2015. The change in net accounts receivable is due to changes in customer mix and the timing of sales and collections during the quarter.
Certain international customers can have longer payment terms than U.S. customers. Other receivables decreased from $33.3 million at December 31, 2014 to $20.9 million at September 30, 2015. The decrease in other receivables is primarily
attributable to the timing of filing returns and collections of VAT receivables in our international subsidiaries. Other receivables will also fluctuate due to the timing of shipments and collections for materials supplied to our contract
manufacturers during the quarter.

[0001193125-15-366072:mdna:95]
Quarterly inventory turnover stayed consistent at 3.5 turns as of December 31, 2014 and September 30,
2015. Inventory increased 16.1% from December 31, 2014 to September 30, 2015. We expect inventory levels to fluctuate as we attempt to maintain sufficient inventory in response to services activity and seasonal cycles of our business,
ensuring competitive lead times while managing the risk of inventory obsolescence that may occur due to rapidly changing technology and customer demand.

[0001193125-15-366072:mdna:96]
Accounts payable increased 23.0% from $56.4 million at December 31, 2014 to $69.4 million at September 30, 2015. Accounts payable will fluctuate due
to variations in the timing of the receipt of supplies, inventory and services and our subsequent payments for these purchases.

[0001193125-15-366072:mdna:97]
[same as prior period, unchanged from 0001193125-15-278444:mdna:96]

[0001193125-15-366072:mdna:98]
Capital expenditures totaled approximately $7.8 million and $8.2 million for the nine months ended September 30, 2015 and 2014, respectively.
These expenditures were primarily used to purchase manufacturing and test equipment and computer software and hardware.

[0001193125-15-366072:mdna:99]
Our combined short-term and
long-term investments decreased $81.0 million from $327.6 million at December 31, 2014 to $246.6 million at September 30, 2015. This decrease reflects the impact of our cash needs for capital expenditures, share repurchases, and
dividends, as well as net realized and unrealized losses and amortization of net premiums on our combined investments, partially offset by additional funds available for investment provided by our operating activities and stock option exercises by
our employees.

[0001193125-15-366072:mdna:100]
We invest all available cash not required for immediate use in operations primarily in securities that we believe bear minimal risk of
loss. At September 30, 2015 these investments included corporate bonds of $86.8 million, municipal fixed-rate bonds of $52.1 million, asset-backed bonds of $5.5 million, mortgage/agency-backed bonds of $8.4 million, and government bonds of
$14.3 million. At December 31, 2014, these investments included corporate bonds of $111.3 million, municipal fixed-rate bonds of $127.8 million, and municipal variable rate demand notes of $2.5 million. As of September 30, 2015, our
corporate bonds, municipal fixed-rate bonds, asset-backed bonds, mortgage/agency-backed bonds, and government bonds were classified as available-for-sale and had a combined duration of 1.2 years with an average credit rating of A. Because our bond
portfolio has a high quality rating and contractual maturities of a short duration, we are able to obtain prices for these bonds derived from observable market inputs, or for similar securities traded in an active market, on a daily basis.

[0001193125-15-366072:mdna:101]
Our long-term investments decreased 27.1% from $280.6 million at December 31, 2014 to $204.5 million at September 30, 2015. Long-term investments at
September 30, 2015 and December 31, 2014 included an investment in a certificate of deposit of $30.0 million, which serves as collateral for our revenue bond. See “Debt” below for additional information. We have various
equity investments included in long-term investments at a cost of $29.5 million and $26.4 million, and with a fair value of $32.6 million and $38.3 million, at September 30, 2015 and December 31, 2014, respectively.

[0001193125-15-366072:mdna:102]
Long-term investments at September 30, 2015 and December 31, 2014 also included $15.5 million and $16.3 million, respectively, related to our
deferred compensation plans, and $1.4 million and $1.5 million, respectively, of other investments carried at cost, consisting of interests in two private equity funds and an investment in a privately held telecommunications equipment manufacturer.

[0001193125-15-366072:mdna:103]
We review our investment portfolio for potential “other-than-temporary” declines in value on an individual investment basis. We assess, on a
quarterly basis, significant declines in value which may be considered other-than-temporary and, if necessary, recognize and record the appropriate charge to write-down the carrying value of such investments. In making this assessment, we take into
consideration qualitative and quantitative information, including but not limited to the following: the magnitude and duration of historical declines in market prices, credit rating activity, assessments of liquidity, public filings, and statements
made by the issuer. We generally begin our identification of potential other-than-temporary impairments by reviewing any security with a fair value that has declined from its original or adjusted cost basis by 25% or more for six or more consecutive
months. We then evaluate the individual security based on the previously identified factors to determine the amount of the write-down, if any. For the three and nine months ended September 30, 2015 and 2014, other-than-temporary impairment
charges were not significant.

[0001193125-15-366072:mdna:104]
Financing Activities

[0001193125-15-366072:mdna:105]
[same as prior period, unchanged from 0001193125-15-278444:mdna:104]

[0001193125-15-366072:mdna:106]
In July 2003, our Board of Directors elected to
begin declaring quarterly dividends on our common stock considering the tax treatment of dividends and adequate levels of Company liquidity. During the nine months ended September 30, 2015, we paid dividends totaling $14.0 million.

[0001193125-15-366072:mdna:107]
[same as prior period, unchanged from 0001193125-15-278444:mdna:106]

[0001193125-15-366072:mdna:108]
We have amounts outstanding under loans made
pursuant to an Alabama State Industrial Development Authority revenue bond (the Bond) which totaled $30.0 million at September 30, 2015 and December 31, 2014. At September 30, 2015, the estimated fair value of the Bond was
approximately $30.1 million, based on a debt security with a comparable interest rate and maturity and a Standard & Poor’s credit rating of AAA. Included in long-term investments are restricted funds in the amount of $30.0
million at September 30, 2015 and December 31, 2014, which is a collateral deposit against the principal amount of the Bond. We have the right to set-off the balance of the Bond with the collateral deposit in order to reduce the balance of
the indebtedness. The Bond matures on January 1, 2020, and bears interest at the rate of 2% per annum. In conjunction with this program, we are eligible to receive certain economic incentives from the state of Alabama that reduce the
amount of payroll withholdings we are required to remit to the state for those employment positions that qualify under this program. We are required to make payments in the amounts necessary to pay the interest on the amounts currently outstanding.
It is our intent to make annual principal payments in addition to the interest amounts that are due. In connection with this decision, $1.2 million of the Bond has been classified as a current liability in accounts payable in the Consolidated
Balance Sheet at September 30, 2015.

[0001193125-15-366072:mdna:109]
[same as prior period, unchanged from 0001193125-15-278444:mdna:108]

[0001193125-15-366072:mdna:110]
Since 1997, our Board of Directors has approved multiple share repurchase programs that have authorized open market repurchase transactions of up to
45.0 million shares of our common stock. On July 14, 2015, our Board of Directors authorized the repurchase of an additional 5.0 million shares of our common stock (bringing the total shares authorized for repurchase to 50.0 million),
which will commence upon completion of the repurchase plan announced on May 14, 2014. This new authorization will be implemented through open market or private purchases from time to time as conditions warrant.

[0001193125-15-366072:mdna:111]
During the nine months ended September 30, 2015, we repurchased 3.9 million shares of our common stock at an average price of $16.69 per share. As
of September 30, 2015, we have the authority to purchase an additional 5.8 million shares of our common stock under the current plans approved by the Board of Directors.

[0001193125-15-366072:mdna:112]
[same as prior period, unchanged from 0001193125-15-278444:mdna:110]

[0001193125-15-366072:mdna:113]
To accommodate employee stock
option exercises, we issued 0.1 million shares of treasury stock for $0.9 million during the nine months ended September 30, 2015.

[0001193125-15-366072:mdna:114]
[same as prior period, unchanged from 0001193125-15-278444:mdna:112]

[0001193125-15-366072:mdna:115]
We do not have off-balance sheet financing arrangements and have not engaged in any related party transactions or arrangements with unconsolidated entities or
other persons that are reasonably likely to materially affect liquidity or the availability of or requirements for capital resources. During the nine months ended September 30, 2015, there have been no material changes in contractual
obligations and commercial commitments from those discussed in our most recent Annual Report on Form 10-K for the year ended December 31, 2014 filed on February 24, 2015 with the SEC.

[0001193125-15-366072:mdna:116]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, and we have contributed $8.4 million as of September 30,
2015, of which $7.7 million has been applied to these commitments.

[0001193125-15-366072:mdna:117]
[same as prior period, unchanged from 0001193125-15-278444:mdna:115]

[0001193125-15-366072:mdna:118]
[same as prior period, unchanged from 0001193125-15-278444:mdna:116]

[0001193125-15-366072:mdna:119]
[same as prior period, unchanged from 0001193125-15-278444:mdna:117]

[0001193125-15-366072:mdna:120]
[same as prior period, unchanged from 0001193125-15-278444:mdna:118]

[0001193125-15-366072:mdna:121]
[same as prior period, unchanged from 0001193125-15-278444:mdna:119]

[0001193125-15-366072:mdna:122]
[same as prior period, unchanged from 0001193125-15-278444:mdna:120]

[0001193125-15-366072:mdna:123]
[same as prior period, unchanged from 0001193125-15-278444:mdna:121]

[0001193125-15-366072:mdna:124]
[same as prior period, unchanged from 0001193125-15-278444:mdna:122]

[0001193125-15-366072:mdna:125]
[same as prior period, unchanged from 0001193125-15-278444:mdna:123]

[0001193125-15-366072:mdna:126]
[same as prior period, unchanged from 0001193125-15-278444:mdna:124]

[0001193125-15-366072:mdna:127]
[same as prior period, unchanged from 0001193125-15-278444:mdna:125]

[0001193125-15-366072:mdna:128]
[same as prior period, unchanged from 0001193125-15-278444:mdna:126]

[0001193125-15-366072:mdna:129]
[same as prior period, unchanged from 0001193125-15-278444:mdna:127]

[0001193125-15-366072:mdna:130]
[same as prior period, unchanged from 0001193125-15-278444:mdna:128]

[0001193125-15-366072:mdna:131]
[same as prior period, unchanged from 0001193125-15-278444:mdna:129]

[0001193125-15-366072:mdna:132]
[same as prior period, unchanged from 0001193125-15-278444:mdna:130]

[0001193125-15-366072:mdna:133]
[same as prior period, unchanged from 0001193125-15-278444:mdna:131]

[0001193125-15-366072:mdna:134]
[same as prior period, unchanged from 0001193125-15-278444:mdna:132]

[0001193125-15-366072:mdna:135]
[same as prior period, unchanged from 0001193125-15-278444:mdna:133]

[0001193125-15-366072:mdna:136]
[same as prior period, unchanged from 0001193125-15-278444:mdna:134]

[0001193125-15-366072:mdna:137]
[same as prior period, unchanged from 0001193125-15-278444:mdna:135]

[0001193125-15-366072:mdna:138]
[same as prior period, unchanged from 0001193125-15-278444:mdna:136]

[0001193125-15-366072:mdna:139]
[same as prior period, unchanged from 0001193125-15-278444:mdna:137]

[0001193125-15-366072:mdna:140]
[same as prior period, unchanged from 0001193125-15-278444:mdna:138]

[0001193125-15-366072:mdna:141]
[same as prior period, unchanged from 0001193125-15-278444:mdna:139]

[0001193125-15-366072:mdna:142]
|  | • |  | We may incur liabilities or become subject to litigation that would have a material effect on our business. |

[0001193125-15-366072:mdna:143]
[same as prior period, unchanged from 0001193125-15-278444:mdna:141]

[0001193125-15-366072:mdna:144]
[same as prior period, unchanged from 0001193125-15-278444:mdna:142]

[0001193125-15-366072:mdna:145]
34

[0001193125-15-366072:mdna:146]
[same as prior period, unchanged from 0001193125-15-278444:mdna:143]

[0001193125-15-366072:mdna:147]
[same as prior period, unchanged from 0001193125-15-278444:mdna:144]

[0001193125-15-366072:mdna:148]
[same as prior period, unchanged from 0001193125-15-278444:mdna:145]

[0001193125-15-366072:mdna:149]
[same as prior period, unchanged from 0001193125-15-278444:mdna:146]

[0001193125-15-366072:mdna:150]
[same as prior period, unchanged from 0001193125-15-278444:mdna:147]

[0001193125-15-366072:mdna:151]
[same as prior period, unchanged from 0001193125-15-278444:mdna:148]

[0001193125-15-366072:mdna:152]
[same as prior period, unchanged from 0001193125-15-278444:mdna:149]

[0001193125-15-366072:mdna:153]
[same as prior period, unchanged from 0001193125-15-278444:mdna:150]

[0001193125-15-366072:mdna:154]
[same as prior period, unchanged from 0001193125-15-278444:mdna:151]
