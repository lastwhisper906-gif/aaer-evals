# ADTN 8-K — 0001193125-15-343083 filed 2015-10-14

## item codes, every 8-K on or before 2015-11-04

- 2015-10-14 0001193125-15-343083 — 2.02, 9.01
- 2015-07-16 0001193125-15-254729 — 8.01, 9.01
- 2015-07-15 0001193125-15-253068 — 2.02, 9.01
- 2015-05-15 0001193125-15-189160 — 5.07, 9.01
- 2015-04-22 0001193125-15-140997 — 2.02, 9.01
- 2015-02-23 0001193125-15-056741 — 5.02, 9.01
- 2015-01-21 0001193125-15-015465 — 2.02, 9.01
- 2014-10-15 0001193125-14-372076 — 2.02, 9.01
- 2014-10-03 0001193125-14-363152 — 2.02, 9.01
- 2014-07-16 0001193125-14-269660 — 2.02, 9.01
- 2014-05-20 0001193125-14-205916 — 8.01, 9.01
- 2014-05-20 0001193125-14-205906 — 5.02, 9.01
- 2014-05-15 0001193125-14-201144 — 5.07
- 2014-04-16 0001193125-14-144665 — 2.02, 9.01
- 2014-04-03 0001193125-14-129578 — 2.02, 9.01
- 2014-01-22 0001157523-14-000154 — 2.02, 9.01
- 2013-10-15 0001193125-13-399540 — 5.02
- 2013-10-09 0001157523-13-004657 — 2.02, 9.01
- 2013-07-10 0001157523-13-003290 — 2.02, 9.01
- 2013-05-10 0001193125-13-213728 — 5.07
- 2013-05-03 0001193125-13-198816 — 8.01, 9.01
- 2013-04-10 0001157523-13-001730 — 2.02, 9.01
- 2013-01-16 0001157523-13-000139 — 2.02, 9.01
- 2012-10-10 0001157523-12-005081 — 2.02, 9.01
- 2012-10-03 0001193125-12-413609 — 7.01
- 2012-09-28 0001193125-12-408878 — 2.02, 9.01
- 2012-07-11 0001157523-12-003592 — 2.02, 9.01
- 2012-05-10 0001193125-12-225669 — 5.07
- 2012-05-10 0001193125-12-225639 — 8.01, 9.01
- 2012-04-11 0001157523-12-001772 — 2.02, 9.01
- 2012-03-15 0001193125-12-116494 — 2.02, 9.01
- 2012-01-18 0001157523-12-000174 — 2.02, 9.01
- 2011-12-12 0001193125-11-337271 — 7.01, 9.01
- 2011-10-13 0000950123-11-089785 — 5.03, 9.01
- 2011-10-12 0001157523-11-005682 — 2.02, 9.01
- 2011-07-13 0001157523-11-003986 — 2.02, 9.01
- 2011-05-09 0000950123-11-047191 — 5.02, 5.07, 9.01
- 2011-04-13 0001157523-11-002001 — 2.02, 9.01
- 2011-01-19 0001157523-11-000232 — 2.02, 9.01
- 2010-11-09 0000950123-10-103195 — 5.02, 9.01
- 2010-10-13 0001157523-10-005798 — 2.02, 9.01
- 2010-07-14 0001157523-10-004011 — 2.02, 9.01
- 2010-05-28 0000950123-10-053947 — 5.07
- 2010-04-14 0001157523-10-002022 — 2.02, 9.01
- 2010-01-20 0001157523-10-000200 — 2.02, 9.01
- 2009-10-28 0000950123-09-053984 — 8.01
- 2009-10-14 0001157523-09-006877 — 2.02, 9.01
- 2009-07-15 0001157523-09-004878 — 2.02, 9.01
- 2009-04-15 0001157523-09-002687 — 2.02, 9.01
- 2009-01-21 0001157523-09-000340 — 2.02, 9.01
- 2008-11-12 0001193125-08-233181 — 5.02, 9.01
- 2008-10-14 0001157523-08-007999 — 2.02, 9.01
- 2008-07-15 0001157523-08-005504 — 2.02, 9.01
- 2008-04-15 0001157523-08-002896 — 2.02, 9.01
- 2008-01-22 0001157523-08-000408 — 2.02, 9.01
- 2007-10-16 0001193125-07-219356 — 5.03, 9.01
- 2007-10-16 0001157523-07-009850 — 2.02, 9.01
- 2007-07-17 0001157523-07-006912 — 2.02, 9.01
- 2007-04-17 0001157523-07-003630 — 2.02, 9.01
- 2007-04-03 0001179022-07-000068 — 5.02
- 2007-03-28 0001179022-07-000064 — 5.02
- 2007-02-23 0001193125-07-038337 — 5.02
- 2007-02-23 0001193125-07-038335 — 5.02
- 2007-01-30 0001193125-07-015912 — 5.02, 9.01
- 2007-01-26 0001193125-07-014234 — 5.02
- 2007-01-23 0001157523-07-000494 — 2.02, 9.01 — amendment of 0001157523-07-000481
- 2007-01-23 0001157523-07-000481 — 2.02, 9.01
- 2006-10-17 0001157523-06-009945 — 2.02, 9.01
- 2006-07-18 0001157523-06-006929 — 2.02, 9.01
- 2006-06-08 0001193125-06-126486 — 1.01, 9.01
- 2006-05-10 0001193125-06-107316 — 1.01, 9.01
- 2006-04-18 0001157523-06-003699 — 2.02, 9.01
- 2006-02-03 0001179022-06-000014 — 1.01
- 2006-01-27 0001157523-06-000754 — 5.02, 9.01
- 2006-01-24 0001157523-06-000551 — 2.02, 9.01
- 2005-10-18 0001157523-05-008826 — 2.02, 9.01
- 2005-07-19 0001193125-05-143958 — 1.01, 5.02, 9.01
- 2005-07-19 0001193125-05-143957 — 2.02, 9.01
- 2005-05-20 0001193125-05-112019 — 1.01, 9.01
- 2005-04-19 0001157523-05-003418 — 2.02, 9.01
- 2005-01-25 0001193125-05-010721 — 2.02, 9.01
- 2004-10-12 0001193125-04-169652 — 2.02, 9.01
- 2004-07-13 0001193125-04-116820 — 12, 7
- 2004-04-14 0001193125-04-061547 — 12, 7
- 2004-01-21 0001193125-04-006366 — 12, 7
- 2003-10-14 0001193125-03-061018 — 12, 5, 7
- 2003-07-15 0001193125-03-019292 — 7, 9
- 2003-04-15 0000931763-03-000968 — 7, 9
- 1996-09-12 0000931763-96-000667 — 5, 7

## late-filing notifications on or before 2015-11-04

- none on or before 2015-11-04

## item 2.02 — earnings release, exhibit 99.1

[0001193125-15-343083:8k_2_02:1]
EX-99.1
2
d77551dex991.htm
EX-99.1

[0001193125-15-343083:8k_2_02:2]
EX-99.1

[0001193125-15-343083:8k_2_02:3]
Exhibit 99.1

[0001193125-15-343083:8k_2_02:4]
ADTRAN, INC.

[0001193125-15-343083:8k_2_02:5]
REPORTS RESULTS for the THIRD QUARTER 2015 and DECLARES QUARTERLY CASH DIVIDEND

[0001193125-15-343083:8k_2_02:6]
HUNTSVILLE, Ala.—(BUSINESS WIRE)—October 13, 2015—ADTRAN, Inc. (NASDAQ:ADTN) reported results for the third quarter 2015. For the quarter,
sales were $158,078,000 compared to $160,138,000 for the second quarter of 2015. Net income was $7,067,000 compared to $2,544,000 for the second quarter of 2015. Earnings per share, assuming dilution, were $0.14 compared to $0.05 for the second
quarter of 2015. Non-GAAP earnings per share were $0.19 compared to $0.10 for the second quarter of 2015. The reconciliation between GAAP earnings per share, diluted, and non-GAAP earnings per share, diluted, is in the table provided.

[0001193125-15-343083:8k_2_02:7]
ADTRAN Chief Executive Officer Tom Stanton stated, “Our U.S. revenue in the quarter was up over 20% compared to the same period last year, driven by a
substantial increase in broadband sales. Operating income was slightly better than expected driven by improved gross margin and lower operating expenses. Looking ahead, we continue to see signs that momentum is building for 2016 as CAF and
competitive pressures refocus carriers’ investment in broadband access infrastructure.”

[0001193125-15-343083:8k_2_02:8]
The Company also announced that its Board of Directors
declared a cash dividend for the third quarter of 2015. The quarterly cash dividend is $0.09 per common share to be paid to holders of record at the close of business on October 29, 2015. The ex-dividend date is October 27, 2015 and the
payment date is November 12, 2015.

[0001193125-15-343083:8k_2_02:9]
The Company confirmed that its third quarter conference call will be held Wednesday, October 14, 2015 at
9:30 a.m. Central Time. This conference call will be web cast live through StreetEvents.com. To listen, simply visit the Investor Relations site at www.adtran.com or www.streetevents.com approximately 10 minutes prior to the start of the call
and click on the conference call link provided.

[0001193125-15-343083:8k_2_02:10]
An online replay of the conference call will be available for seven days at www.streetevents.com.
In addition, an online replay of the conference call, as well as the text of the Company’s earnings release, will be available on the Investor Relations site at www.adtran.com for at least 12 months following the call.

[0001193125-15-343083:8k_2_02:11]
ADTRAN, Inc. is a leading global provider of networking and communications equipment. ADTRAN’s products enable voice, data, video and Internet
communications across a variety of network infrastructures. ADTRAN solutions are currently in use by service providers, private enterprises, government organizations, and millions of individual users worldwide. For more information, please visit
www.adtran.com.

[0001193125-15-343083:8k_2_02:12]
For more information, contact the company at 800 9ADTRAN (800 923-8726) or via email at info@adtran.com. On the Web, visit
www.adtran.com.

[0001193125-15-343083:8k_2_02:13]
This press release contains forward-looking statements which reflect management’s best judgment based on factors currently
known. However, these statements involve risks and uncertainties, including the successful development and market acceptance of new products, the degree of competition in the market for such products, the product and channel mix, component costs,
manufacturing efficiencies, and other risks detailed in our annual report on Form 10-K for the year ended December 31, 2014 and on Form 10-Q for the quarter ended June 30, 2015. These risks and uncertainties could cause actual results to
differ materially from those in the forward-looking statements included in this press release.

[0001193125-15-343083:8k_2_02:14]
| CONTACT: Michael Foliano Senior Vice President & Interim CFO 256-963-8885 |  | INVESTOR SERVICES/ASSISTANCE: Gayle Ellis Investor Services 256-963-8220 |

[0001193125-15-343083:8k_2_02:15]
Condensed Consolidated Balance Sheet

[0001193125-15-343083:8k_2_02:16]
(Unaudited)

[0001193125-15-343083:8k_2_02:17]
(In
thousands)

[0001193125-15-343083:8k_2_02:18]
|  |  | September 30,2015 |  |  | December 31,2014 |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 83,687 |  |  | $ | 73,439 |  |
| Short-term investments |  |  | 42,081 |  |  |  | 46,919 |  |
| Accounts receivable, net |  |  | 86,176 |  |  |  | 88,502 |  |
| Other receivables |  |  | 20,858 |  |  |  | 33,295 |  |
| Inventory |  |  | 100,705 |  |  |  | 86,710 |  |
| Prepaid expenses |  |  | 5,935 |  |  |  | 5,129 |  |
| Deferred tax assets, net |  |  | 17,517 |  |  |  | 17,095 |  |
| Total Current Assets |  |  | 356,959 |  |  |  | 351,089 |  |
| Property, plant and equipment, net |  |  | 73,656 |  |  |  | 74,828 |  |
| Deferred tax assets, net |  |  | 23,341 |  |  |  | 17,694 |  |
| Goodwill |  |  | 3,492 |  |  |  | 3,492 |  |
| Other assets |  |  | 9,893 |  |  |  | 10,942 |  |
| Long-term investments |  |  | 204,513 |  |  |  | 280,649 |  |
| Total Assets |  | $ | 671,854 |  |  | $ | 738,694 |  |
| Liabilities and Stockholders’ Equity |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 69,372 |  |  | $ | 56,414 |  |
| Unearned revenue |  |  | 16,484 |  |  |  | 22,762 |  |
| Accrued expenses |  |  | 13,427 |  |  |  | 11,077 |  |
| Accrued wages and benefits |  |  | 14,842 |  |  |  | 13,855 |  |
| Income tax payable, net |  |  | 12,923 |  |  |  | 14,901 |  |
| Total Current Liabilities |  |  | 127,048 |  |  |  | 119,009 |  |
| Non-current unearned revenue |  |  | 8,685 |  |  |  | 10,948 |  |
| Other non-current liabilities |  |  | 29,680 |  |  |  | 30,924 |  |
| Bonds payable |  |  | 28,800 |  |  |  | 28,800 |  |
| Total Liabilities |  |  | 194,213 |  |  |  | 189,681 |  |
| Stockholders’ Equity |  |  | 477,641 |  |  |  | 549,013 |  |
| Total Liabilities and Stockholders’ Equity |  | $ | 671,854 |  |  | $ | 738,694 |  |

[0001193125-15-343083:8k_2_02:19]
Consolidated Statements of Income

[0001193125-15-343083:8k_2_02:20]
(Unaudited)

[0001193125-15-343083:8k_2_02:21]
(In
thousands, except per share data)

[0001193125-15-343083:8k_2_02:22]
|  |  | Three Months EndedSeptember 30, |  |  | Nine Months EndedSeptember 30, |  |
|  |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Sales |  | $ | 158,078 |  |  | $ | 162,892 |  |  | $ | 461,051 |  |  | $ | 486,025 |  |
| Cost of sales |  |  | 87,429 |  |  |  | 84,635 |  |  |  | 256,593 |  |  |  | 243,181 |  |
| Gross Profit |  |  | 70,649 |  |  |  | 78,257 |  |  |  | 204,458 |  |  |  | 242,844 |  |
| Selling, general and administrative expenses |  |  | 30,016 |  |  |  | 32,438 |  |  |  | 93,203 |  |  |  | 100,165 |  |
| Research and development expenses |  |  | 32,561 |  |  |  | 33,324 |  |  |  | 100,576 |  |  |  | 99,547 |  |
| Operating Income |  |  | 8,072 |  |  |  | 12,495 |  |  |  | 10,679 |  |  |  | 43,132 |  |
| Interest and dividend income |  |  | 839 |  |  |  | 992 |  |  |  | 2,680 |  |  |  | 3,340 |  |
| Interest expense |  |  | (151 | ) |  |  | (150 | ) |  |  | (448 | ) |  |  | (525 | ) |
| Net realized investment gain |  |  | 2,060 |  |  |  | 2,687 |  |  |  | 8,430 |  |  |  | 7,219 |  |
| Other income (expense), net |  |  | 52 |  |  |  | (963 | ) |  |  | (848 | ) |  |  | (1,615 | ) |
| Income before provision for income taxes |  |  | 10,872 |  |  |  | 15,061 |  |  |  | 20,493 |  |  |  | 51,551 |  |
| Provision for income taxes |  |  | (3,805 | ) |  |  | (3,735 | ) |  |  | (7,565 | ) |  |  | (16,223 | ) |
| Net Income |  | $ | 7,067 |  |  | $ | 11,326 |  |  | $ | 12,928 |  |  | $ | 35,328 |  |
| Weighted average shares outstanding - basic |  |  | 49,862 |  |  |  | 54,521 |  |  |  | 51,682 |  |  |  | 55,552 |  |
| Weighted average shares outstanding - diluted (1) |  |  | 49,927 |  |  |  | 54,824 |  |  |  | 51,792 |  |  |  | 55,976 |  |
| Earnings per common share - basic |  | $ | 0.14 |  |  | $ | 0.21 |  |  | $ | 0.25 |  |  | $ | 0.64 |  |
| Earnings per common share - diluted (1) |  | $ | 0.14 |  |  | $ | 0.21 |  |  | $ | 0.25 |  |  | $ | 0.63 |  |

[0001193125-15-343083:8k_2_02:23]
| (1) | Assumes exercise of dilutive stock options calculated under the treasury stock method. |

[0001193125-15-343083:8k_2_02:24]
Consolidated Statements of Comprehensive Income

[0001193125-15-343083:8k_2_02:25]
(Unaudited)

[0001193125-15-343083:8k_2_02:26]
(In
thousands)

[0001193125-15-343083:8k_2_02:27]
|  |  | Three Months EndedSeptember 30, |  |  | Nine Months EndedSeptember 30, |  |
|  |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Net Income |  | $ | 7,067 |  |  | $ | 11,326 |  |  | $ | 12,928 |  |  | $ | 35,328 |  |
| Other Comprehensive Income (Loss), net of tax: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Unrealized losses on available-for-sale securities |  |  | (4,291 | ) |  |  | (3,148 | ) |  |  | (6,577 | ) |  |  | (2,850 | ) |
| Defined benefit plan adjustments |  |  | 71 |  |  |  | — |  |  |  | 211 |  |  |  | — |  |
| Foreign currency translation |  |  | (1,351 | ) |  |  | (2,568 | ) |  |  | (3,797 | ) |  |  | (2,182 | ) |
| Other Comprehensive Loss, net of tax |  |  | (5,571 | ) |  |  | (5,716 | ) |  |  | (10,163 | ) |  |  | (5,032 | ) |
| Comprehensive Income, net of tax |  | $ | 1,496 |  |  | $ | 5,610 |  |  | $ | 2,765 |  |  | $ | 30,296 |  |

[0001193125-15-343083:8k_2_02:28]
Consolidated Statements of Cash Flows

[0001193125-15-343083:8k_2_02:29]
(Unaudited)

[0001193125-15-343083:8k_2_02:30]
(In
thousands)

[0001193125-15-343083:8k_2_02:31]
|  |  | Nine Months EndedSeptember 30, |  |
|  |  | 2015 |  |  | 2014 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 12,928 |  |  | $ | 35,328 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 10,765 |  |  |  | 11,127 |  |
| Amortization of net premium on available-for-sale investments |  |  | 2,085 |  |  |  | 3,363 |  |
| Net realized gain on long-term investments |  |  | (8,430 | ) |  |  | (7,219 | ) |
| Net loss on disposal of property, plant and equipment |  |  | 189 |  |  |  | 109 |  |
| Stock-based compensation expense |  |  | 4,788 |  |  |  | 6,296 |  |
| Deferred income taxes |  |  | (2,332 | ) |  |  | (122 | ) |
| Tax benefit from stock option exercises |  |  | (40 | ) |  |  | 71 |  |
| Excess tax benefits from stock-based compensation arrangements |  |  | 38 |  |  |  | (53 | ) |
| Change in operating assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  |  | 843 |  |  |  | (15,807 | ) |
| Other receivables |  |  | 10,532 |  |  |  | (10,726 | ) |
| Inventory |  |  | (14,945 | ) |  |  | 2,413 |  |
| Prepaid expenses and other assets |  |  | (1,665 | ) |  |  | (4,095 | ) |
| Accounts payable |  |  | 13,687 |  |  |  | 3,563 |  |
| Accrued expenses and other liabilities |  |  | (3,996 | ) |  |  | 7,507 |  |
| Income tax payable, net |  |  | (1,137 | ) |  |  | 9,265 |  |
| Net cash provided by operating activities |  |  | 23,310 |  |  |  | 41,020 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (7,843 | ) |  |  | (8,162 | ) |
| Proceeds from disposals of property, plant and equipment |  |  | 122 |  |  |  | 1 |  |
| Proceeds from sales and maturities of available-for-sale investments |  |  | 189,728 |  |  |  | 187,013 |  |
| Purchases of available-for-sale investments |  |  | (113,227 | ) |  |  | (127,074 | ) |
| Net cash provided by investing activities |  |  | 68,780 |  |  |  | 51,778 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Proceeds from stock option exercises |  |  | 907 |  |  |  | 2,311 |  |
| Purchases of treasury stock |  |  | (65,808 | ) |  |  | (62,144 | ) |
| Dividend payments |  |  | (13,989 | ) |  |  | (15,060 | ) |
| Payments on long-term debt |  |  | — |  |  |  | (16,500 | ) |
| Excess tax benefits from stock-based compensation arrangements |  |  | (38 | ) |  |  | 53 |  |
| Net cash used in financing activities |  |  | (78,928 | ) |  |  | (91,340 | ) |
| Net increase in cash and cash equivalents |  |  | 13,162 |  |  |  | 1,458 |  |
| Effect of exchange rate changes |  |  | (2,914 | ) |  |  | (1,341 | ) |
| Cash and cash equivalents, beginning of period |  |  | 73,439 |  |  |  | 58,298 |  |
| Cash and cash equivalents, end of period |  | $ | 83,687 |  |  | $ | 58,415 |  |
| Supplemental disclosure of non-cash investing activities |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment included in accounts payable |  | $ | 1,303 |  |  | $ | 598 |  |

[0001193125-15-343083:8k_2_02:32]
Supplemental Information

[0001193125-15-343083:8k_2_02:33]
Restructuring Expenses

[0001193125-15-343083:8k_2_02:34]
(Unaudited)

[0001193125-15-343083:8k_2_02:35]
(In
thousands)

[0001193125-15-343083:8k_2_02:36]
Restructuring expenses were recorded in the following Consolidated Statements of Income categories for the three and nine months ended
September 30, 2015 and 2014:

[0001193125-15-343083:8k_2_02:37]
|  |  | Three Months EndedSeptember 30, |  |  | Nine Months EndedSeptember 30, |  |
|  |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Restructuring expense included in cost of sales |  | $ | 9 |  |  | $ | — |  |  | $ | 107 |  |  | $ | — |  |
| Selling, general and administrative expense |  |  | 194 |  |  |  | — |  |  |  | 838 |  |  |  | — |  |
| Research and development expense |  |  | 712 |  |  |  | — |  |  |  | 2,095 |  |  |  | — |  |
| Restructuring expense included in operating expenses |  |  | 906 |  |  |  | — |  |  |  | 2,933 |  |  |  | — |  |
| Total restructuring expense |  |  | 915 |  |  |  | — |  |  |  | 3,040 |  |  |  | — |  |
| Provision for income taxes |  |  | (357 | ) |  |  | — |  |  |  | (1,186 | ) |  |  | — |  |
| Total restructuring expense, net of tax |  | $ | 558 |  |  | $ | — |  |  | $ | 1,854 |  |  | $ | — |  |

[0001193125-15-343083:8k_2_02:38]
Supplemental Information

[0001193125-15-343083:8k_2_02:39]
Acquisition Related Expenses, Amortizations and Adjustments

[0001193125-15-343083:8k_2_02:40]
(Unaudited)

[0001193125-15-343083:8k_2_02:41]
(In
thousands)

[0001193125-15-343083:8k_2_02:42]
On August 4, 2011, we closed on the acquisition of Bluesocket, Inc. and on May 4, 2012, we closed on the acquisition of the
Nokia Siemens Networks Broadband Access business (NSN BBA). Acquisition related expenses, amortizations and adjustments for the three and nine months ended September 30, 2015 and 2014 for both transactions are as follows:

[0001193125-15-343083:8k_2_02:43]
|  |  | Three Months EndedSeptember 30, |  |  | Nine Months EndedSeptember 30, |  |
|  |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Bluesocket, Inc. acquisition |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets and other purchase accounting adjustments |  | $ | 191 |  |  | $ | 227 |  |  | $ | 643 |  |  | $ | 699 |  |
| NSN BBA acquisition |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets |  |  | 231 |  |  |  | 287 |  |  |  | 701 |  |  |  | 884 |  |
| Amortization of other purchase accounting adjustments |  |  | 101 |  |  |  | 240 |  |  |  | 395 |  |  |  | 895 |  |
| Acquisition related professional fees, travel and other expenses |  |  | 20 |  |  |  | 24 |  |  |  | 61 |  |  |  | 89 |  |
| Subtotal |  |  | 352 |  |  |  | 551 |  |  |  | 1,157 |  |  |  | 1,868 |  |
| Total acquisition related expenses, amortizations and adjustments |  |  | 543 |  |  |  | 778 |  |  |  | 1,800 |  |  |  | 2,567 |  |
| Provision for income taxes |  |  | (183 | ) |  |  | (259 | ) |  |  | (609 | ) |  |  | (851 | ) |
| Total acquisition related expenses, amortizations and adjustments, net of tax |  | $ | 360 |  |  | $ | 519 |  |  | $ | 1,191 |  |  | $ | 1,716 |  |

[0001193125-15-343083:8k_2_02:44]
The acquisition related expenses, amortizations and adjustments above were recorded in the following Consolidated Statements
of Income categories for the three and nine months ended September 30, 2015 and 2014:

[0001193125-15-343083:8k_2_02:45]
|  |  | Three Months EndedSeptember 30, |  |  | Nine Months EndedSeptember 30, |  |
|  |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Revenue (adjustments to deferred revenue recognized in the period) |  | $ | 65 |  |  | $ | 105 |  |  | $ | 196 |  |  | $ | 528 |  |
| Cost of goods sold |  |  | 7 |  |  |  | 47 |  |  |  | 52 |  |  |  | 104 |  |
| Subtotal |  |  | 72 |  |  |  | 152 |  |  |  | 248 |  |  |  | 632 |  |
| Selling, general and administrative expenses |  |  | 23 |  |  |  | 31 |  |  |  | 74 |  |  |  | 110 |  |
| Research and development expenses |  |  | 448 |  |  |  | 595 |  |  |  | 1,478 |  |  |  | 1,825 |  |
| Subtotal |  |  | 471 |  |  |  | 626 |  |  |  | 1,552 |  |  |  | 1,935 |  |
| Total acquisition related expenses, amortizations and adjustments |  |  | 543 |  |  |  | 778 |  |  |  | 1,800 |  |  |  | 2,567 |  |
| Provision for income taxes |  |  | (183 | ) |  |  | (259 | ) |  |  | (609 | ) |  |  | (851 | ) |
| Total acquisition related expenses, amortizations and adjustments, net of tax |  | $ | 360 |  |  | $ | 519 |  |  | $ | 1,191 |  |  | $ | 1,716 |  |

[0001193125-15-343083:8k_2_02:46]
Supplemental Information

[0001193125-15-343083:8k_2_02:47]
Stock-based Compensation Expense

[0001193125-15-343083:8k_2_02:48]
(Unaudited)

[0001193125-15-343083:8k_2_02:49]
(In
thousands)

[0001193125-15-343083:8k_2_02:50]
|  |  | Three Months EndedSeptember 30, |  |  | Nine Months EndedSeptember 30, |  |
|  |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Stock-based compensation expense included in cost of sales |  | $ | 59 |  |  | $ | 124 |  |  | $ | 202 |  |  | $ | 359 |  |
| Selling, general and administrative expense |  |  | 812 |  |  |  | 1,048 |  |  |  | 2,226 |  |  |  | 3,089 |  |
| Research and development expense |  |  | 803 |  |  |  | 975 |  |  |  | 2,360 |  |  |  | 2,848 |  |
| Stock-based compensation expense included in operating expenses |  |  | 1,615 |  |  |  | 2,023 |  |  |  | 4,586 |  |  |  | 5,937 |  |
| Total stock-based compensation expense |  |  | 1,674 |  |  |  | 2,147 |  |  |  | 4,788 |  |  |  | 6,296 |  |
| Tax benefit for expense associated with non-qualified options |  |  | (218 | ) |  |  | (298 | ) |  |  | (620 | ) |  |  | (878 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 1,456 |  |  | $ | 1,849 |  |  | $ | 4,168 |  |  | $ | 5,418 |  |

[0001193125-15-343083:8k_2_02:51]
Reconciliation of GAAP net income per share, diluted, to

[0001193125-15-343083:8k_2_02:52]
Non-GAAP net income per share, diluted

[0001193125-15-343083:8k_2_02:53]
(Unaudited)

[0001193125-15-343083:8k_2_02:54]
|  |  | Three Months EndedSeptember 30, |  |  | Nine Months EndedSeptember 30, |  |
|  |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| GAAP earnings per common share – diluted |  | $ | 0.14 |  |  | $ | 0.21 |  |  | $ | 0.25 |  |  | $ | 0.63 |  |
| Restructuring expense |  |  | 0.01 |  |  |  | — |  |  |  | 0.04 |  |  |  | — |  |
| Acquisition related expenses, amortizations and adjustments |  |  | 0.01 |  |  |  | 0.01 |  |  |  | 0.02 |  |  |  | 0.03 |  |
| Stock-based compensation expense |  |  | 0.03 |  |  |  | 0.03 |  |  |  | 0.08 |  |  |  | 0.10 |  |
| Non-GAAP earnings per common share – diluted |  | $ | 0.19 |  |  | $ | 0.25 |  |  | $ | 0.39 |  |  | $ | 0.76 |  |
