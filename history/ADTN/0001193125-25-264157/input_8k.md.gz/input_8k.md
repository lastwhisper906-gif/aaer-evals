# ADTN 8-K — 0001193125-25-263524 filed 2025-11-04

## item codes, every 8-K on or before 2025-11-04

- 2025-11-04 0001193125-25-263524 — 2.02, 7.01, 9.01
- 2025-09-22 0001193125-25-211271 — 1.01, 2.03, 3.02, 9.01
- 2025-09-17 0001193125-25-205483 — 1.01, 8.01, 9.01
- 2025-08-05 0000950170-25-102401 — 2.02, 7.01, 9.01
- 2025-07-30 0000950170-25-100222 — 5.07, 8.01, 9.01
- 2025-07-17 0000950170-25-096408 — 2.02, 7.01, 9.01 — amendment of 0000950170-25-096231
- 2025-07-16 0000950170-25-096231 — 2.02, 7.01, 9.01
- 2025-05-28 0000950170-25-077995 — 2.02, 9.01
- 2025-05-27 0001193125-25-127878 — 8.01, 9.01
- 2025-05-13 0000950170-25-070473 — 4.02, 8.01, 9.01
- 2025-05-12 0000950170-25-069478 — 1.01, 9.01
- 2025-05-08 0000950170-25-066343 — 2.02, 7.01, 9.01
- 2025-04-16 0001193125-25-081800 — 7.01, 9.01
- 2025-03-07 0001193125-25-048727 — 5.02, 7.01, 9.01
- 2025-02-27 0000950170-25-028352 — 2.02, 7.01, 9.01
- 2024-11-07 0000950170-24-122762 — 2.02, 7.01, 9.01
- 2024-08-30 0000950170-24-102309 — 5.02, 9.01
- 2024-08-06 0000950170-24-091207 — 2.02, 7.01, 9.01
- 2024-08-02 0000950170-24-089974 — 5.02
- 2024-06-10 0001193125-24-158388 — 1.01, 2.03, 9.01
- 2024-05-09 0000950170-24-056830 — 5.02, 5.07, 9.01
- 2024-05-07 0000950170-24-053920 — 2.02, 7.01, 9.01
- 2024-05-03 0001193125-24-130896 — 2.02, 7.01, 9.01
- 2024-04-17 0000950170-24-045151 — 2.05, 9.01
- 2024-03-15 0000950170-24-031864 — 2.02, 9.01
- 2024-02-27 0000950170-24-020613 — 2.02, 7.01, 9.01
- 2024-02-20 0001193125-24-040068 — 4.02
- 2024-01-22 0001193125-24-011697 — 1.01, 2.03, 9.01
- 2023-12-06 0001193125-23-289895 — 5.02, 9.01
- 2023-12-05 0001193125-23-289150 — 5.02, 9.01
- 2023-11-07 0001193125-23-271842 — 2.02, 7.01, 9.01
- 2023-10-24 0001193125-23-261665 — 5.02, 5.03, 9.01
- 2023-10-17 0001193125-23-257289 — 2.02, 7.01, 9.01
- 2023-09-29 0001193125-23-246498 — 5.02
- 2023-08-14 0001193125-23-212439 — 2.02, 9.01 — amendment of 0001193125-23-204377
- 2023-08-10 0001193125-23-209039 — 4.02, 9.01
- 2023-08-10 0001193125-23-209024 — 2.02, 9.01 — amendment of 0001193125-23-204377
- 2023-08-07 0001193125-23-204377 — 2.02, 7.01, 9.01
- 2023-06-28 0001193125-23-177593 — 5.02, 9.01
- 2023-06-01 0001193125-23-158986 — 5.02, 9.01
- 2023-05-30 0001193125-23-156741 — 5.02
- 2023-05-15 0000950170-23-021860 — 5.07, 9.01
- 2023-05-09 0000950170-23-019145 — 2.02, 9.01
- 2023-04-11 0001193125-23-097240 — 2.02, 9.01
- 2023-04-03 0001193125-23-089517 — 5.02, 9.01
- 2023-03-30 0001193125-23-085151 — 5.02, 9.01
- 2023-02-21 0000950170-23-003277 — 2.02, 9.01
- 2023-02-08 0001193125-23-028386 — 1.02, 9.01
- 2023-01-26 0001193125-23-016354 — 5.02, 9.01
- 2023-01-19 0001193125-23-010702 — 8.01, 9.01
- 2022-12-05 0001193125-22-298171 — 1.01, 9.01
- 2022-11-09 0000950170-22-023662 — 2.02 — amendment of 0000950170-22-022906
- 2022-11-08 0000950170-22-022906 — 2.02, 9.01
- 2022-10-26 0001193125-22-269383 — 8.01
- 2022-10-25 0001193125-22-268261 — 2.02, 9.01 — amendment, the index does not say of what
- 2022-10-25 0001193125-22-267712 — 2.02, 9.01
- 2022-10-18 0001193125-22-264344 — 8.01, 9.01
- 2022-09-30 0000950170-22-019126 — 5.02, 9.01 — amendment of 0001193125-22-195093
- 2022-08-04 0000950170-22-014476 — 2.02, 9.01
- 2022-07-22 0001193125-22-200018 — 1.01, 1.02, 2.03, 9.01
- 2022-07-15 0001193125-22-195093 — 2.01, 5.02, 9.01
- 2022-07-08 0001193125-22-190213 — 2.01, 3.01, 3.03, 5.01, 5.02, 5.03, 7.01, 9.01
- 2022-07-07 0001193125-22-188934 — 7.01, 9.01
- 2022-06-30 0001193125-22-186294 — 5.04, 9.01
- 2022-05-23 0000950170-22-010455 — 1.01, 2.03, 9.01
- 2022-05-13 0000950170-22-009818 — 5.07
- 2022-05-05 0000950170-22-007563 — 2.02, 9.01
- 2022-04-06 0000950170-22-005405 — 1.01, 2.03, 9.01
- 2022-02-03 0000950170-22-000705 — 2.02, 9.01
- 2022-01-06 0001193125-22-003467 — 5.07, 7.01, 9.01
- 2021-12-28 0001193125-21-368041 — 8.01
- 2021-11-29 0000950170-21-004926 — 5.02, 9.01
- 2021-11-02 0000950170-21-002595 — 7.01, 9.01
- 2021-11-02 0000950170-21-002593 — 2.02, 9.01
- 2021-10-15 0000950170-21-002127 — 2.02, 9.01
- 2021-10-07 0000950170-21-002053 — 5.02
- 2021-09-01 0000950170-21-001615 — 5.02
- 2021-08-30 0001193125-21-260059 — 1.01, 7.01, 9.01
- 2021-08-05 0001564590-21-041127 — 2.02, 9.01
- 2021-05-18 0001564590-21-028541 — 5.07
- 2021-05-06 0001564590-21-024430 — 2.02, 9.01
- 2021-02-26 0001564590-21-009408 — 2.02, 9.01 — amendment of 0001564590-21-004167
- 2021-02-04 0001564590-21-004167 — 2.02, 9.01
- 2020-11-03 0001564590-20-049784 — 2.02, 9.01
- 2020-08-06 0001564590-20-037168 — 2.02, 9.01
- 2020-07-23 0001564590-20-033184 — 5.03, 9.01
- 2020-05-15 0001564590-20-025794 — 5.07
- 2020-05-11 0001564590-20-024328 — 5.02, 9.01
- 2020-05-07 0001564590-20-022297 — 2.02, 9.01
- 2020-02-25 0001564590-20-006448 — 2.02, 9.01
- 2020-02-06 0001564590-20-003580 — 2.02, 9.01
- 2019-10-31 0001564590-19-038936 — 2.02, 9.01
- 2019-10-10 0001564590-19-036732 — 2.02, 9.01
- 2019-09-20 0001564590-19-035144 — 2.02, 9.01
- 2019-08-21 0001564590-19-032757 — 3.01, 9.01
- 2019-07-18 0001564590-19-025186 — 2.02, 9.01
- 2019-05-09 0001564590-19-017956 — 5.07
- 2019-04-18 0001564590-19-011897 — 2.02, 9.01
- 2019-03-07 0001564590-19-006575 — 5.02, 9.01
- 2019-01-24 0001564590-19-001024 — 2.02, 9.01
- 2018-12-06 0001564590-18-030615 — 8.01, 9.01
- 2018-10-17 0001564590-18-024365 — 2.02, 9.01
- 2018-07-18 0001564590-18-016946 — 2.02, 9.01
- 2018-05-10 0001564590-18-012968 — 5.07
- 2018-04-18 0001564590-18-008361 — 2.02, 9.01
- 2018-03-21 0001564590-18-006409 — 8.01, 9.01
- 2018-01-17 0001564590-18-000519 — 2.02, 9.01
- 2017-12-29 0001564590-17-025375 — 2.02, 9.01
- 2017-11-16 0001193125-17-345232 — 5.02
- 2017-10-18 0001564590-17-019582 — 2.02, 9.01
- 2017-07-19 0001564590-17-013609 — 2.02, 9.01
- 2017-05-11 0001564590-17-010459 — 5.02, 9.01
- 2017-05-11 0001564590-17-010452 — 5.07
- 2017-04-19 0001193125-17-127926 — 2.02, 9.01
- 2017-02-07 0001193125-17-032714 — 8.01
- 2017-01-18 0001193125-17-011669 — 2.02, 9.01
- 2016-11-16 0001193125-16-769505 — 5.02, 9.01
- 2016-10-19 0001193125-16-741087 — 2.02, 9.01
- 2016-09-14 0001193125-16-709148 — 8.01, 9.01
- 2016-08-17 0001193125-16-683980 — 5.02, 9.01
- 2016-07-13 0001193125-16-646816 — 2.02, 9.01
- 2016-05-13 0001193125-16-590263 — 5.07
- 2016-04-13 0001193125-16-539019 — 2.02, 9.01
- 2016-04-08 0001193125-16-535035 — 7.01
- 2016-02-11 0001193125-16-459453 — 5.02, 9.01
- 2016-01-20 0001193125-16-432934 — 2.02, 9.01
- 2015-11-16 0001193125-15-378019 — 5.02, 9.01
- 2015-10-14 0001193125-15-343083 — 2.02, 9.01
- 2015-07-16 0001193125-15-254729 — 8.01, 9.01
- 2015-07-15 0001193125-15-253068 — 2.02, 9.01
- 2015-05-15 0001193125-15-189160 — 5.07, 9.01
- 2015-04-22 0001193125-15-140997 — 2.02, 9.01
- 2015-02-23 0001193125-15-056741 — 5.02, 9.01
- 2015-01-21 0001193125-15-015465 — 2.02, 9.01
- 2014-10-15 0001193125-14-372076 — 2.02, 9.01
- 2014-10-03 0001193125-14-363152 — 2.02, 9.01
- 2014-07-16 0001193125-14-269660 — 2.02, 9.01
- 2014-05-20 0001193125-14-205916 — 8.01, 9.01
- 2014-05-20 0001193125-14-205906 — 5.02, 9.01
- 2014-05-15 0001193125-14-201144 — 5.07
- 2014-04-16 0001193125-14-144665 — 2.02, 9.01
- 2014-04-03 0001193125-14-129578 — 2.02, 9.01
- 2014-01-22 0001157523-14-000154 — 2.02, 9.01
- 2013-10-15 0001193125-13-399540 — 5.02
- 2013-10-09 0001157523-13-004657 — 2.02, 9.01
- 2013-07-10 0001157523-13-003290 — 2.02, 9.01
- 2013-05-10 0001193125-13-213728 — 5.07
- 2013-05-03 0001193125-13-198816 — 8.01, 9.01
- 2013-04-10 0001157523-13-001730 — 2.02, 9.01
- 2013-01-16 0001157523-13-000139 — 2.02, 9.01
- 2012-10-10 0001157523-12-005081 — 2.02, 9.01
- 2012-10-03 0001193125-12-413609 — 7.01
- 2012-09-28 0001193125-12-408878 — 2.02, 9.01
- 2012-07-11 0001157523-12-003592 — 2.02, 9.01
- 2012-05-10 0001193125-12-225669 — 5.07
- 2012-05-10 0001193125-12-225639 — 8.01, 9.01
- 2012-04-11 0001157523-12-001772 — 2.02, 9.01
- 2012-03-15 0001193125-12-116494 — 2.02, 9.01
- 2012-01-18 0001157523-12-000174 — 2.02, 9.01
- 2011-12-12 0001193125-11-337271 — 7.01, 9.01
- 2011-10-13 0000950123-11-089785 — 5.03, 9.01
- 2011-10-12 0001157523-11-005682 — 2.02, 9.01
- 2011-07-13 0001157523-11-003986 — 2.02, 9.01
- 2011-05-09 0000950123-11-047191 — 5.02, 5.07, 9.01
- 2011-04-13 0001157523-11-002001 — 2.02, 9.01
- 2011-01-19 0001157523-11-000232 — 2.02, 9.01
- 2010-11-09 0000950123-10-103195 — 5.02, 9.01
- 2010-10-13 0001157523-10-005798 — 2.02, 9.01
- 2010-07-14 0001157523-10-004011 — 2.02, 9.01
- 2010-05-28 0000950123-10-053947 — 5.07
- 2010-04-14 0001157523-10-002022 — 2.02, 9.01
- 2010-01-20 0001157523-10-000200 — 2.02, 9.01
- 2009-10-28 0000950123-09-053984 — 8.01
- 2009-10-14 0001157523-09-006877 — 2.02, 9.01
- 2009-07-15 0001157523-09-004878 — 2.02, 9.01
- 2009-04-15 0001157523-09-002687 — 2.02, 9.01
- 2009-01-21 0001157523-09-000340 — 2.02, 9.01
- 2008-11-12 0001193125-08-233181 — 5.02, 9.01
- 2008-10-14 0001157523-08-007999 — 2.02, 9.01
- 2008-07-15 0001157523-08-005504 — 2.02, 9.01
- 2008-04-15 0001157523-08-002896 — 2.02, 9.01
- 2008-01-22 0001157523-08-000408 — 2.02, 9.01
- 2007-10-16 0001193125-07-219356 — 5.03, 9.01
- 2007-10-16 0001157523-07-009850 — 2.02, 9.01
- 2007-07-17 0001157523-07-006912 — 2.02, 9.01
- 2007-04-17 0001157523-07-003630 — 2.02, 9.01
- 2007-04-03 0001179022-07-000068 — 5.02
- 2007-03-28 0001179022-07-000064 — 5.02
- 2007-02-23 0001193125-07-038337 — 5.02
- 2007-02-23 0001193125-07-038335 — 5.02
- 2007-01-30 0001193125-07-015912 — 5.02, 9.01
- 2007-01-26 0001193125-07-014234 — 5.02
- 2007-01-23 0001157523-07-000494 — 2.02, 9.01 — amendment of 0001157523-07-000481
- 2007-01-23 0001157523-07-000481 — 2.02, 9.01
- 2006-10-17 0001157523-06-009945 — 2.02, 9.01
- 2006-07-18 0001157523-06-006929 — 2.02, 9.01
- 2006-06-08 0001193125-06-126486 — 1.01, 9.01
- 2006-05-10 0001193125-06-107316 — 1.01, 9.01
- 2006-04-18 0001157523-06-003699 — 2.02, 9.01
- 2006-02-03 0001179022-06-000014 — 1.01
- 2006-01-27 0001157523-06-000754 — 5.02, 9.01
- 2006-01-24 0001157523-06-000551 — 2.02, 9.01
- 2005-10-18 0001157523-05-008826 — 2.02, 9.01
- 2005-07-19 0001193125-05-143958 — 1.01, 5.02, 9.01
- 2005-07-19 0001193125-05-143957 — 2.02, 9.01
- 2005-05-20 0001193125-05-112019 — 1.01, 9.01
- 2005-04-19 0001157523-05-003418 — 2.02, 9.01
- 2005-01-25 0001193125-05-010721 — 2.02, 9.01
- 2004-10-12 0001193125-04-169652 — 2.02, 9.01
- 2004-07-13 0001193125-04-116820 — 12, 7
- 2004-04-14 0001193125-04-061547 — 12, 7
- 2004-01-21 0001193125-04-006366 — 12, 7
- 2003-10-14 0001193125-03-061018 — 12, 5, 7
- 2003-07-15 0001193125-03-019292 — 7, 9
- 2003-04-15 0000931763-03-000968 — 7, 9
- 1996-09-12 0000931763-96-000667 — 5, 7

## late-filing notifications on or before 2025-11-04

- 2025-05-13 0000950170-25-070493 — NT 10-Q, for the period ended 2025-05-13
- 2024-02-29 0000950170-24-023141 — NT 10-K, for the period ended 2023-12-31
- 2023-08-10 0001193125-23-209042 — NT 10-Q, for the period ended 2023-06-30
- 2019-08-12 0001564590-19-031524 — NT 10-Q, for the period ended 2019-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001193125-25-263524:8k_2_02:1]
EX-99.1
2
adtn-ex99_1.htm
EX-99.1

[0001193125-25-263524:8k_2_02:2]
EX-99.1

[0001193125-25-263524:8k_2_02:3]
ADTRAN Holdings, Inc. reports third quarter 2025 financial results

[0001193125-25-263524:8k_2_02:4]
Huntsville, Alabama, USA. — Nov. 3, 2025 — ADTRAN Holdings, Inc. (NASDAQ: ADTN and FSE: QH9) (“ADTRAN Holdings” “ADTRAN” or the “Company”) today announced its unaudited financial results for the third quarter ended September 30, 2025.

[0001193125-25-263524:8k_2_02:5]
•
Revenue: $279.4 million, higher by 23% year-over-year.

[0001193125-25-263524:8k_2_02:6]
•
Gross margin: GAAP gross margin of 38.3%; non-GAAP gross margin of 42.1%.

[0001193125-25-263524:8k_2_02:7]
•
Operating margin: GAAP operating margin of (1.0)%; non-GAAP operating margin of 5.4%.

[0001193125-25-263524:8k_2_02:8]
•
Net cash provided by operating activities of $12.2 million.

[0001193125-25-263524:8k_2_02:9]
•
GAAP diluted loss per share of $0.12; non-GAAP diluted earnings per share of $0.05.

[0001193125-25-263524:8k_2_02:10]
•
Cash, cash equivalents and restricted cash of $101.2 million.

[0001193125-25-263524:8k_2_02:11]
ADTRAN Holdings Chairman and Chief Executive Officer Tom Stanton stated, “Our third quarter revenue and operating margin were above the midpoint of our expectations, with robust sequential and year-over-year growth. The results reflect disciplined execution, broad-based growth, and continued momentum in a healthy industry environment. We’ve strengthened our capital structure, improved efficiency, and remain focused on key areas of the company.”

[0001193125-25-263524:8k_2_02:12]
Mr. Stanton added, “We look forward to a strong finish to the year. With healthy demand and a portfolio aligned to key technology transitions, we remain focused on driving sustainable growth and maximizing long-term stockholder value.”

[0001193125-25-263524:8k_2_02:13]
Business outlook1

[0001193125-25-263524:8k_2_02:14]
For the fourth quarter of 2025, the Company expects revenue to be within a range of $275.0 million to $285.0 million. Non-GAAP operating margin is expected to be within a range of 3.5% to 7.5%.

[0001193125-25-263524:8k_2_02:15]
1 Non-GAAP operating margin (which is calculated as non-GAAP operating income (loss) divided by revenue) is a non-GAAP financial measure. The Company has provided fourth quarter 2025 guidance with regard to non-GAAP operating margin. This measure excludes from the corresponding GAAP financial measure the effect of adjustments as described below. The Company has not provided a reconciliation of such non-GAAP guidance to guidance presented on a GAAP basis because it cannot predict and quantify without unreasonable effort all of the adjustments that may occur during the period due to the difficulty of predicting the timing and amounts of various items within a reasonable range. In particular, non-GAAP operating margin excludes certain items, such as acquisition related expenses, amortizations and adjustments, stock-based compensation expense, restructuring expenses, integration expenses, deferred compensation adjustments, professional fees and other expenses, and goodwill impairment, that the Company is unable to quantitatively predict. Depending on the materiality of these items, they could have a significant impact on the Company's GAAP financial results.

[0001193125-25-263524:8k_2_02:16]
Conference call

[0001193125-25-263524:8k_2_02:17]
The Company will hold a conference call to discuss its third quarter 2025 results on Tuesday, November 4, 2025, at 9:30 a.m. Central Time (4:30 p.m. Central European Time). The Company will webcast this conference call at the events and presentations section of ADTRAN Holdings, Inc. Investor Relations website at https://events.q4inc.com/attendee/495431650 approximately 10 minutes before the start of the call, or you may dial 1-888-330-2391 (Toll-Free US) or 1-240-789-2702, and use Conference ID 8936454.

[0001193125-25-263524:8k_2_02:18]
An online replay of the Company’s conference call, as well as the transcript of the call, will be available on the Investor Relations site https://investors.adtran.com/ shortly following the call and will remain available for at least 12 months. For more information, visit https://investors.adtran.com or email investor.relations@adtran.com.

[0001193125-25-263524:8k_2_02:19]
Upcoming conference schedule

[0001193125-25-263524:8k_2_02:20]
November 18, 2025: Craig-Hallum Alpha Select Conference – New York

[0001193125-25-263524:8k_2_02:21]
November 20, 2025: Needham Tech Week Conference – New York

[0001193125-25-263524:8k_2_02:22]
November 24-25, 2025: Deutsches Eigenkapitalforum – Frankfurt

[0001193125-25-263524:8k_2_02:23]
December 16, 2025: Northland Capital Conference – Virtual

[0001193125-25-263524:8k_2_02:24]
About Adtran

[0001193125-25-263524:8k_2_02:25]
ADTRAN Holdings, Inc. (NASDAQ: ADTN and FSE: QH9) is the parent company of Adtran, Inc., a leading global provider of open, disaggregated networking and communications solutions that enable voice, data, video and internet communications across any network infrastructure. From the cloud edge to the subscriber edge, Adtran empowers communications service providers around the world to manage and scale services that connect people, places and things. Adtran solutions are used by service providers, private enterprises,

[0001193125-25-263524:8k_2_02:26]
government organizations and millions of individual users worldwide. ADTRAN Holdings, Inc. is also the majority shareholder of Adtran Networks SE, formerly ADVA Optical Networking SE (“Adtran Networks”). Find more at Adtran.com, LinkedIn and X.

[0001193125-25-263524:8k_2_02:27]
Cautionary note regarding forward-looking statements

[0001193125-25-263524:8k_2_02:28]
Explanation of use of non-GAAP financial measures

[0001193125-25-263524:8k_2_02:29]
Set forth in the tables below are reconciliations of gross profit, gross margin, operating expenses, operating loss, operating margin, other expense, net loss inclusive of the non-controlling interest, net loss attributable to the Company, and loss per share - basic and diluted, attributable to the Company, and net cash provided by operating activities, in each case as reported based on generally accepted accounting principles in the United States (“GAAP”), to non-GAAP gross profit, non-GAAP gross margin, non-GAAP operating expenses, non-GAAP operating income (loss), non-GAAP operating margin, non-GAAP other expense, non-GAAP net income (loss) inclusive of the non-controlling interest, non-GAAP net income (loss) attributable to the Company, non-GAAP net earnings (loss) per share - basic and diluted, attributable to the Company, and free cash flow, respectively. Such non-GAAP measures exclude acquisition-related expenses, amortization and adjustments (consisting of intangible amortization of backlog, inventory fair value adjustments, developed technology, customer relationships, and trade names acquired in connection with business combinations), stock-based compensation expense, restructuring expenses, integration expenses, deferred compensation adjustments, goodwill impairments, professional fees and other expenses, amortization of pension actuarial losses, the tax effect of these adjustments to net loss and purchases of property, plant and equipment and developed technologies. These measures are used by management in our ongoing planning and annual budgeting processes. Additionally, we believe the presentation of these non-GAAP measures, when combined with the presentation of the most directly comparable GAAP financial measure, is beneficial to the overall understanding of ongoing operating performance of the Company. These non-GAAP financial measures are not prepared in accordance with, or an alternative for, GAAP and therefore should not be considered in isolation or as a substitution for analysis of our results as reported under GAAP. Additionally, our calculation of non-GAAP measures may not be comparable to similar measures calculated by other companies.

[0001193125-25-263524:8k_2_02:30]
Published by

[0001193125-25-263524:8k_2_02:31]
ADTRAN Holdings, Inc.

[0001193125-25-263524:8k_2_02:32]
www.adtran.com

[0001193125-25-263524:8k_2_02:33]
For media

[0001193125-25-263524:8k_2_02:34]
Gareth Spence

[0001193125-25-263524:8k_2_02:35]
+44 1904 699 358

[0001193125-25-263524:8k_2_02:36]
public.relations@adtran.com

[0001193125-25-263524:8k_2_02:37]
For investors

[0001193125-25-263524:8k_2_02:38]
Peter Schuman, IRC

[0001193125-25-263524:8k_2_02:39]
+1 256 963 6305

[0001193125-25-263524:8k_2_02:40]
investor.relations@adtran.com

[0001193125-25-263524:8k_2_02:41]
Condensed Consolidated Balance Sheets

[0001193125-25-263524:8k_2_02:42]
(Unaudited)

[0001193125-25-263524:8k_2_02:43]
(In thousands)

[0001193125-25-263524:8k_2_02:44]
|  | September 30, |  |  | December 31, |  |
|  | 2025 |  |  | 2024 |  |
| Assets |  |  |  |  |  |
| Current Assets |  |  |  |  |  |
| Cash and cash equivalents | $ | 93,682 |  |  | $ | 76,021 |  |
| Restricted cash |  | 7,547 |  |  |  | — |  |
| Accounts receivable, net |  | 178,621 |  |  |  | 178,030 |  |
| Other receivables |  | 8,709 |  |  |  | 9,775 |  |
| Inventory, net |  | 223,755 |  |  |  | 261,557 |  |
| Income tax receivable |  | 6,478 |  |  |  | 5,461 |  |
| Prepaid expenses and other current assets |  | 72,424 |  |  |  | 56,395 |  |
| Assets held for sale |  | 11,901 |  |  |  | 11,901 |  |
| Total Current Assets |  | 603,117 |  |  |  | 599,140 |  |
| Property, plant and equipment, net |  | 121,465 |  |  |  | 106,454 |  |
| Goodwill |  | 59,919 |  |  |  | 52,918 |  |
| Intangible assets, net |  | 302,281 |  |  |  | 284,893 |  |
| Deferred tax assets |  | 17,826 |  |  |  | 17,826 |  |
| Other non-current assets |  | 69,021 |  |  |  | 78,128 |  |
| Long-term investments |  | 35,279 |  |  |  | 32,060 |  |
| Total Assets | $ | 1,208,908 |  |  | $ | 1,171,419 |  |
| Liabilities, Redeemable Non-Controlling Interest and Equity |  |  |  |  |  |
| Current Liabilities |  |  |  |  |  |
| Accounts payable | $ | 188,947 |  |  | $ | 171,825 |  |
| Unearned revenue |  | 57,563 |  |  |  | 52,701 |  |
| Accrued expenses and other liabilities |  | 30,544 |  |  |  | 34,158 |  |
| Accrued wages and benefits |  | 29,245 |  |  |  | 32,853 |  |
| Income tax payable |  | 1,453 |  |  |  | 1,936 |  |
| Total Current Liabilities |  | 307,752 |  |  |  | 293,473 |  |
| Non-current revolving credit agreement |  | 25,023 |  |  |  | 189,576 |  |
| Non-current convertible senior notes, net of debt issuance costs |  | 192,859 |  |  |  | — |  |
| Deferred tax liabilities |  | 32,299 |  |  |  | 30,372 |  |
| Non-current unearned revenue |  | 23,196 |  |  |  | 22,065 |  |
| Non-current pension liability |  | 9,725 |  |  |  | 8,983 |  |
| Deferred compensation liability |  | 36,684 |  |  |  | 33,203 |  |
| Non-current lease obligations |  | 25,950 |  |  |  | 25,925 |  |
| Other non-current liabilities |  | 11,749 |  |  |  | 17,928 |  |
| Total Liabilities |  | 665,237 |  |  |  | 621,525 |  |
| Redeemable Non-Controlling Interest |  | 402,088 |  |  |  | 422,943 |  |
| Equity |  |  |  |  |  |
| Common stock |  | 801 |  |  |  | 795 |  |
| Additional paid-in capital |  | 799,949 |  |  |  | 808,913 |  |
| Accumulated other comprehensive income |  | 74,655 |  |  |  | 11,254 |  |
| Retained deficit |  | (728,714 | ) |  |  | (688,813 | ) |
| Treasury stock |  | (5,108 | ) |  |  | (5,198 | ) |
| Total Equity |  | 141,583 |  |  |  | 126,951 |  |
| Total Liabilities, Redeemable Non-Controlling Interest and Equity | $ | 1,208,908 |  |  | $ | 1,171,419 |  |

[0001193125-25-263524:8k_2_02:45]
Condensed Consolidated Statements of Loss

[0001193125-25-263524:8k_2_02:46]
(Unaudited)

[0001193125-25-263524:8k_2_02:47]
(In thousands, except per share amounts)

[0001193125-25-263524:8k_2_02:48]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |  |
|  |  | September 30, |  |  | September 30, |  |  |
|  |  | 2025 |  |  | 2024 |  |  | 2025 |  |  | 2024 |  |  |
|  |  |  |  |  | (Restated) |  |  |  |  |  | (Restated) |  |  |
| Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Network Solutions |  | $ | 232,543 |  |  | $ | 181,488 |  |  | $ | 654,258 |  |  | $ | 541,955 |  |  |
| Services & Support |  |  | 46,892 |  |  |  | 46,216 |  |  |  | 137,989 |  |  |  | 137,913 |  |  |
| Total Revenue |  |  | 279,435 |  |  |  | 227,704 |  |  |  | 792,247 |  |  |  | 679,868 |  |  |
| Cost of Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Network Solutions |  |  | 153,107 |  |  |  | 128,320 |  |  |  | 434,669 |  |  |  | 381,359 |  |  |
| Network Solutions - charges and inventory write-down |  |  | — |  |  |  | (328 | ) |  |  | — |  |  |  | 8,597 |  |  |
| Services & Support |  |  | 19,202 |  |  |  | 16,678 |  |  |  | 56,352 |  |  |  | 55,304 |  |  |
| Total Cost of Revenue |  |  | 172,309 |  |  |  | 144,670 |  |  |  | 491,021 |  |  |  | 445,260 |  |  |
| Gross Profit |  |  | 107,126 |  |  |  | 83,034 |  |  |  | 301,226 |  |  |  | 234,608 |  |  |
| Selling, general and administrative expenses |  |  | 58,234 |  |  |  | 57,550 |  |  |  | 168,866 |  |  |  | 175,905 |  |  |
| Research and development expenses |  |  | 51,680 |  |  |  | 51,577 |  |  |  | 152,434 |  |  |  | 172,144 |  |  |
| Goodwill impairment |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 297,353 |  |  |
| Operating Loss |  |  | (2,788 | ) |  |  | (26,093 | ) |  |  | (20,074 | ) |  |  | (410,794 | ) |  |
| Interest and dividend income |  |  | 291 |  |  |  | 664 |  |  |  | 618 |  |  |  | 1,427 |  |  |
| Interest expense |  |  | (5,499 | ) |  |  | (5,679 | ) |  |  | (14,824 | ) |  |  | (17,183 | ) |  |
| Net investment gain |  |  | 2,186 |  |  |  | 1,382 |  |  |  | 3,575 |  |  |  | 4,507 |  |  |
| Other income (expense), net |  |  | (745 | ) |  |  | (850 | ) |  |  | (2,437 | ) |  |  | (441 | ) |  |
| Loss Before Income Taxes |  |  | (6,555 | ) |  |  | (30,576 | ) |  |  | (33,142 | ) |  |  | (422,484 | ) |  |
| Income tax (expense) benefit |  |  | (1,202 | ) |  |  | (390 | ) |  |  | (1,821 | ) |  |  | 16,121 |  |  |
| Net Loss |  | $ | (7,757 | ) |  | $ | (30,966 | ) |  | $ | (34,963 | ) |  | $ | (406,363 | ) |  |
| Less: Net Income attributable to non-controlling interest (1) |  |  | 2,505 |  |  |  | 2,382 |  |  |  | 7,097 |  |  |  | 7,417 |  |  |
| Net Loss attributable to ADTRAN Holdings, Inc. |  | $ | (10,262 | ) |  | $ | (33,348 | ) |  | $ | (42,060 | ) |  | $ | (413,780 | ) |  |
| Weighted average shares outstanding – basic |  |  | 79,803 |  |  |  | 78,952 |  |  |  | 79,696 |  |  |  | 78,873 |  |  |
| Weighted average shares outstanding – diluted |  |  | 79,803 |  |  |  | 78,952 |  |  |  | 79,696 |  |  |  | 78,873 |  |  |
| Loss per common share attributable to ADTRAN Holdings, Inc. – basic (2) |  | $ | (0.12 | ) |  | $ | (0.38 | ) |  | $ | (0.50 | ) |  | $ | (5.21 | ) |  |
| Loss per common share attributable to ADTRAN Holdings, Inc. – diluted (2) |  | $ | (0.12 | ) |  | $ | (0.38 | ) |  | $ | (0.50 | ) |  | $ | (5.21 | ) |  |

[0001193125-25-263524:8k_2_02:49]
(1) For the three and nine months ended September 30, 2025 we accrued $2.5 million and $7.5 million, respectively, net income attributable to non-controlling interest, representing the recurring cash compensation earned by non-controlling interest shareholders post-DPLTA. For the three and nine  months ended September 30, 2024, we accrued $2.4 million and $7.4 million, respectively, representing the recurring cash compensation earned by non-controlling interest shareholders post-DPLTA.

[0001193125-25-263524:8k_2_02:50]
(2) Loss per common share attributable to ADTRAN Holdings, Inc. - basic and diluted - reflects a $0.5 million and a $2.0 million effect of redemption of RNCI for the three and nine months ended September 30, 2025 and a $3.0 million effect of redemption of RNCI for the three and nine months ended September 30, 2024.

[0001193125-25-263524:8k_2_02:51]
Condensed Consolidated Statements of Cash Flows

[0001193125-25-263524:8k_2_02:52]
(Unaudited)

[0001193125-25-263524:8k_2_02:53]
(In thousands)

[0001193125-25-263524:8k_2_02:54]
|  |  | September 30, |  |
|  |  | 2025 |  |  | 2024 |  |
|  |  |  |  |  | (Restated) |  |
| Cash flows from operating activities: |  |  |  |  |  |  |
| Net loss |  | $ | (34,963 | ) |  | $ | (406,363 | ) |
| Adjustments to reconcile net loss to net cash provided by operating activities: |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 68,316 |  |  |  | 67,894 |  |
| Goodwill impairment |  |  | — |  |  |  | 297,353 |  |
| Amortization of revolving credit facility issuance costs |  |  | 975 |  |  |  | 1,013 |  |
| Amortization of convertible notes issuance costs |  |  | 45 |  |  |  | — |  |
| Gain on investments, net |  |  | (3,828 | ) |  |  | (4,238 | ) |
| Net loss on disposal of property, plant and equipment |  |  | 38 |  |  |  | 203 |  |
| Stock-based compensation expense |  |  | 8,738 |  |  |  | 11,482 |  |
| Deferred income taxes |  |  | 715 |  |  |  | (13,399 | ) |
| Other, net |  |  | — |  |  |  | (267 | ) |
| Inventory write down - business efficiency program |  |  | — |  |  |  | 4,135 |  |
| Inventory reserves |  |  | 8,754 |  |  |  | 6,667 |  |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |
| Accounts receivable, net |  |  | 12,295 |  |  |  | 59,446 |  |
| Other receivables |  |  | 1,769 |  |  |  | 4,875 |  |
| Income taxes receivable |  |  | (752 | ) |  |  | (947 | ) |
| Inventory |  |  | 45,426 |  |  |  | 73,887 |  |
| Prepaid expenses, other current assets and other assets |  |  | 7,162 |  |  |  | (22,164 | ) |
| Accounts payable |  |  | 585 |  |  |  | 9,697 |  |
| Accrued expenses and other liabilities |  |  | (26,589 | ) |  |  | 15,034 |  |
| Income taxes payable |  |  | (1,157 | ) |  |  | (3,175 | ) |
| Net cash provided by operating activities |  |  | 87,529 |  |  |  | 101,133 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (20,066 | ) |  |  | (31,168 | ) |
| Purchases of intangibles - developed technology |  |  | (29,491 | ) |  |  | (19,669 | ) |
| Proceeds from sales and maturities of available-for-sale investments |  |  | 960 |  |  |  | 1,195 |  |
| Purchases of available-for-sale investments |  |  | (318 | ) |  |  | (195 | ) |
| Payments for beneficial interests in securitized accounts receivable |  |  | (232 | ) |  |  | 282 |  |
| Net cash used in investing activities |  |  | (49,147 | ) |  |  | (49,555 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |
| Tax withholdings related to stock-based compensation settlements |  |  | (1,313 | ) |  |  | (189 | ) |
| Proceeds from stock option exercises |  |  | 1,434 |  |  |  | 219 |  |
| Proceeds from receivables purchase agreement |  |  | — |  |  |  | 68,556 |  |
| Repayments on receivables purchase agreement |  |  | — |  |  |  | (83,772 | ) |
| Proceeds from draw on revolving credit agreement |  |  | 24,000 |  |  |  | — |  |
| Repayment of revolving credit agreement |  |  | (189,000 | ) |  |  | (5,000 | ) |
| Proceeds from issuance of convertible notes |  |  | 201,250 |  |  |  | — |  |
| Payment for redemption of redeemable non-controlling interest |  |  | (19,364 | ) |  |  | (17,395 | ) |
| Payment for annual recurring compensation to non-controlling interest |  |  | (10,053 | ) |  |  | (10,084 | ) |
| Payments for capped call transactions related to convertible senior notes |  |  | (17,650 | ) |  |  | — |  |
| Payment of debt issuance costs on revolving credit facility and convertible notes |  |  | (7,350 | ) |  |  | (1,994 | ) |
| Net cash used in financing activities |  |  | (18,046 | ) |  |  | (49,659 | ) |
| Net increase in cash and cash equivalents |  |  | 20,336 |  |  |  | 1,919 |  |
| Effect of exchange rate changes |  |  | 4,872 |  |  |  | (630 | ) |
| Cash, cash equivalents and restricted cash, beginning of period |  |  | 76,021 |  |  |  | 87,167 |  |
| Cash, cash equivalents and restricted cash, end of period |  | $ | 101,229 |  |  | $ | 88,456 |  |
| Supplemental disclosure of cash financing activities: |  |  |  |  |  |  |
| Cash paid for interest expense |  | $ | 13,335 |  |  | $ | 18,225 |  |
| Cash paid for income taxes, net of refunds |  | $ | 2,407 |  |  | $ | 9,122 |  |
| Cash used in operating activities related to operating leases |  | $ | 7,737 |  |  | $ | 7,380 |  |
| Supplemental disclosure of non-cash investing and financing activities: |  |  |  |  |  |  |
| Redemption of redeemable non-controlling interest |  | $ | 2,010 |  |  | $ | 2,976 |  |
| Right-of-use assets obtained in exchange for lease obligations |  | $ | 3,689 |  |  | $ | 2,122 |  |
| Purchases of property, plant and equipment included in accounts payable |  | $ | 4,874 |  |  | $ | 952 |  |
| Purchases of property, plant and equipment included in other non-current liabilities |  | $ | 5,157 |  |  | $ | — |  |
| Debt issuance costs included in accrued expenses and other liabilities |  | $ | 1,493 |  |  | $ | — |  |

[0001193125-25-263524:8k_2_02:55]
Supplemental Information

[0001193125-25-263524:8k_2_02:56]
Reconciliation of Gross Profit and Gross Margin to

[0001193125-25-263524:8k_2_02:57]
Non-GAAP Gross Profit and Non-GAAP Gross Margin

[0001193125-25-263524:8k_2_02:58]
(Unaudited)

[0001193125-25-263524:8k_2_02:59]
(In thousands)

[0001193125-25-263524:8k_2_02:60]
|  |  | Three Months Ended |  |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | June 30, |  |  | September 30, |  |  |  | September 30, |  |  | September 30, |  |
|  |  | 2025 |  |  | 2025 |  |  | 2024 |  |  |  | 2025 |  |  | 2024 |  |
|  |  |  |  |  |  |  |  | (Restated) |  |  |  |  |  |  | (Restated) |  |
| Total Revenue |  | $ | 279,435 |  |  | $ | 265,068 |  |  | $ | 227,704 |  |  |  | $ | 792,247 |  |  | $ | 679,868 |  |
| Cost of Revenue |  | $ | 172,309 |  |  | $ | 166,144 |  |  | $ | 144,670 |  |  |  | $ | 491,021 |  |  | $ | 445,260 |  |
| Acquisition-related expenses, amortizations and adjustments (1) |  |  | (10,140 | ) |  |  | (10,599 | ) |  |  | (10,276 | ) |  |  |  | (30,570 | ) |  |  | (30,517 | ) |
| Stock-based compensation expense |  |  | (265 | ) |  |  | (222 | ) |  |  | (270 | ) |  |  |  | (754 | ) |  |  | (825 | ) |
| Restructuring expenses (2) |  |  | — |  |  |  | — |  |  |  | (7 | ) |  |  |  | — |  |  |  | (14,042 | ) |
| Integration expenses (3) |  |  | — |  |  |  | — |  |  |  | (34 | ) |  |  |  | — |  |  |  | (104 | ) |
| Non-GAAP Cost of Revenue |  | $ | 161,904 |  |  | $ | 155,323 |  |  | $ | 134,083 |  |  |  | $ | 459,697 |  |  | $ | 399,772 |  |
| Gross Profit |  | $ | 107,126 |  |  | $ | 98,924 |  |  | $ | 83,034 |  |  |  | $ | 301,226 |  |  | $ | 234,608 |  |
| Non-GAAP Gross Profit |  | $ | 117,531 |  |  | $ | 109,745 |  |  | $ | 93,621 |  |  |  | $ | 332,550 |  |  | $ | 280,096 |  |
| Gross Margin |  |  | 38.3 | % |  |  | 37.3 | % |  |  | 36.5 | % |  |  |  | 38.0 | % |  |  | 34.5 | % |
| Non-GAAP Gross Margin |  |  | 42.1 | % |  |  | 41.4 | % |  |  | 41.1 | % |  |  |  | 42.0 | % |  |  | 41.2 | % |

[0001193125-25-263524:8k_2_02:61]
(1) Includes intangible amortization of backlog, inventory fair value adjustments, developed technology, customer relationships, and trade names acquired in connection with business combinations. We incur charges relating to the amortization of intangible assets and exclude these charges for purposes of calculating our non-GAAP measures. Such charges are significantly impacted by the timing and magnitude of our acquisitions. We exclude these charges for the purpose of calculating our non-GAAP measures, primarily because they are noncash expenses and our internal benchmarking analyses evidence that many industry participants and peers present non-GAAP financial measures excluding intangible asset amortization. Although this does not directly affect our cash position, the loss in value of intangible assets over time can have a material impact on the equivalent GAAP earnings measure.

[0001193125-25-263524:8k_2_02:62]
(2) Includes expenses for a Business Efficiency Program designed to optimize the assets and business processes following the business combination with Adtran Networks. The Business Efficiency Program was completed as of December 31, 2024.

[0001193125-25-263524:8k_2_02:63]
(3) Includes expenses related to the Company's one-time integration bonus program in connection with synergy targets as a result of the business combination with Adtran Networks, which was completed as of December 31, 2024.

[0001193125-25-263524:8k_2_02:64]
Supplemental Information

[0001193125-25-263524:8k_2_02:65]
Reconciliation of Operating Expenses to Non-GAAP Operating Expenses

[0001193125-25-263524:8k_2_02:66]
(Unaudited)

[0001193125-25-263524:8k_2_02:67]
(In thousands)

[0001193125-25-263524:8k_2_02:68]
|  |  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  |  | September 30, |  |  | June 30, |  |  | September 30, |  |  |  | September 30, |  |  | September 30, |  |  |
|  |  | 2025 |  |  | 2025 |  |  | 2024 |  |  |  | 2025 |  |  | 2024 |  |  |
|  |  |  |  |  |  |  |  | (Restated) |  |  |  |  |  |  | (Restated) |  |  |
| Operating Expenses |  | $ | 109,914 |  |  | $ | 112,242 |  |  | $ | 109,127 |  |  |  | $ | 321,300 |  |  | $ | 645,402 |  |  |
| Acquisition-related expenses, amortizations and adjustments (1) |  |  | (1,898 | ) | (2) |  | (2,175 | ) | (7) |  | (5,054 | ) | (11) |  |  | (6,322 | ) | (15) |  | (17,168 | ) | (18) |
| Stock-based compensation expense |  |  | (2,589 | ) | (3) |  | (2,451 | ) | (8) |  | (3,198 | ) | (12) |  |  | (7,983 | ) | (16) |  | (9,957 | ) | (19) |
| Restructuring expenses |  |  | — |  |  |  | 284 |  | (9) |  | (5,930 | ) | (13) |  |  | 284 |  | (9) |  | (26,534 | ) | (20) |
| Integration expenses (4) |  |  | — |  |  |  | — |  |  |  | (333 | ) | (14) |  |  | — |  |  |  | (1,344 | ) | (21) |
| Deferred compensation adjustments (5) |  |  | (2,317 | ) |  |  | (3,034 | ) |  |  | (1,471 | ) |  |  |  | (3,804 | ) |  |  | (4,259 | ) |  |
| Goodwill impairment |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  | — |  |  |  | (297,353 | ) | (22) |
| Professional fees and other expenses |  |  | (694 | ) | (6) |  | (3,153 | ) | (10) |  | — |  |  |  |  | (3,847 | ) | (17) |  | — |  |  |
| Non-GAAP Operating Expenses |  | $ | 102,416 |  |  | $ | 101,713 |  |  | $ | 93,141 |  |  |  | $ | 299,628 |  |  | $ | 288,787 |  |  |

[0001193125-25-263524:8k_2_02:69]
(1) We incur charges relating to the amortization of intangible assets and exclude these charges for purposes of calculating our non-GAAP measures. Such charges are significantly impacted by the timing and magnitude of our acquisitions. We exclude these charges for the purpose of calculating our non-GAAP measures, primarily because they are noncash expenses and our internal benchmarking analyses evidence that many industry participants and peers present non-GAAP financial measures excluding intangible asset amortization. Although this does not directly affect our cash position, the loss in value of intangible assets over time can have a material impact on the equivalent GAAP earnings measure.

[0001193125-25-263524:8k_2_02:70]
(2) Includes intangible amortization of developed technology, customer relationships, and trade names acquired in connection with business combinations, of which $1.4 million is included in selling, general and administrative expenses and $0.5 million is included in research and development expenses on the condensed consolidated statements of loss.

[0001193125-25-263524:8k_2_02:71]
(3) $1.8 million is included in selling, general and administrative expenses and $0.8 million is included in research and development expenses on the condensed consolidated statements of loss.

[0001193125-25-263524:8k_2_02:72]
(4) Includes expenses on the condensed consolidated statements of loss related to the Company's one-time integration bonus program in connection with synergy targets as a result of the business combination with Adtran Networks and which was completed as of December 31, 2024.

[0001193125-25-263524:8k_2_02:73]
(5) Includes non-cash change in fair value of equity investments held in the ADTRAN Holdings, Inc. Deferred Compensation Program for certain employees, all of which is included in selling, general and administrative expenses on the condensed consolidated statement of loss.

[0001193125-25-263524:8k_2_02:74]
(6) $0.7 million is included in selling, general and administrative expenses on the condensed consolidated statements of loss. Includes professional fees related to an internal investigation and fees relating to other one-time professional fees and business expenses.

[0001193125-25-263524:8k_2_02:75]
(7) Includes intangible amortization of developed technology, customer relationships, and trade names acquired in connection with business combinations, of which $1.7 million is included in selling, general and administrative expenses and $0.5 million is included in research and development expenses on the condensed consolidated statements of loss.

[0001193125-25-263524:8k_2_02:76]
(8) $1.8 million is included in selling, general and administrative expenses and $0.7 million is included in research and development expenses on the condensed consolidated statements of loss.

[0001193125-25-263524:8k_2_02:77]
(9) Includes a true-up of expenses on the condensed consolidated statements of loss for a Business Efficiency Program designed to optimize the assets and business processes following the business combination with Adtran Networks. The Business Efficiency Program was completed as of December 31, 2024.

[0001193125-25-263524:8k_2_02:78]
(10) $3.2 million is included in selling, general and administrative expenses on the condensed consolidated statements of loss. Includes professional fees related to an internal investigation and related employee exit costs, fees relating to other one-time professional fees and business expenses.

[0001193125-25-263524:8k_2_02:79]
(11) Includes $4.0 million of intangible amortization of developed technology, customer relationships, and trade names acquired in connection with business combinations and $0.6 million of legal and advisory fees related to a potential strategic transaction which are both included in selling, general and administrative expenses and $0.5 million is included in research and development expenses on the condensed consolidated statements of loss.

[0001193125-25-263524:8k_2_02:80]
(12) $2.3 million is included in selling, general and administrative expenses and $0.9 million is included in research and development expenses on the condensed consolidated statements of loss.

[0001193125-25-263524:8k_2_02:81]
(13) $2.7 million is included in selling, general and administrative expenses and $3.2 million is included in research and development expenses on the condensed consolidated statements of loss. Includes expenses of $3.2 million of wage related and other charges due to the Greifswald facility closure of which $0.8 million is included in selling, general and administrative and $2.4 million is included in research and development expenses on the condensed consolidated statements of loss. The Business Efficiency Program was completed as of December 31, 2024.

[0001193125-25-263524:8k_2_02:82]
(14) $0.3 million is included in selling, general and administrative expenses on the condensed consolidated statements of loss, and is primarily related to the Company's one-time integration bonus program in connection with synergy targets as a result of the business combination with Adtran Networks, which was completed as of December 31, 2024.

[0001193125-25-263524:8k_2_02:83]
(15) $4.9 million is included in selling, general and administrative expenses and $1.4 million is included in research and development expenses on the condensed consolidated statements of loss.

[0001193125-25-263524:8k_2_02:84]
(16) Includes intangible amortization of developed technology, customer relationships, and trade names acquired in connection with business combinations, of which $5.6 million is included in selling, general and administrative expenses and $2.4 million is included in research and development expenses on the condensed consolidated statements of loss.

[0001193125-25-263524:8k_2_02:85]
(17) $3.8 million is included in selling, general and administrative expenses on the condensed consolidated statements of loss. Includes professional fees related to an internal investigation and related employee exit costs, fees relating to other one-time professional fees and business expenses.

[0001193125-25-263524:8k_2_02:86]
(18) Includes intangible amortization of developed technology, customer relationships, and trade names acquired in connection with business combinations, of which $15.8 million is included in selling, general and administrative expenses and $1.4 million is included in research and development expenses on the condensed consolidated statements of loss.

[0001193125-25-263524:8k_2_02:87]
(19) $7.1 million is included in selling, general and administrative expenses and $2.8 million is included in research and development expenses on the condensed consolidated statements of loss.

[0001193125-25-263524:8k_2_02:88]
(20) $8.0 million is included in selling, general and administrative expenses and $18.6 million is included in research and development expenses on the condensed consolidated statements of loss. Includes expenses of $16.5 million of wage related and other charges due to the Greifswald facility closure of which $3.2 million is included in selling, general and administrative and $13.3 million is included in research and development expenses on the condensed consolidated statements of loss. The Business Efficiency Program was completed as of December 31, 2024.

[0001193125-25-263524:8k_2_02:89]
(21) $1.3 million is included in selling, general and administrative expenses on the condensed consolidated statements of loss. Includes fees relating to the expansion of internal controls at Adtran Networks and the implementation of the DPLTA. Additionally, includes expenses related to the Company's one-time integration bonus program in connection with synergy targets as a result of the business combination with Adtran Networks of which $0.7 million is stock compensation expense for the program.

[0001193125-25-263524:8k_2_02:90]
(22) Includes non-cash goodwill impairment charge related to our Services and Support reporting unit. The impairment primarily resulted from a decrease in projected revenue growth rates and EBITDA margins.

[0001193125-25-263524:8k_2_02:91]
Supplemental Information

[0001193125-25-263524:8k_2_02:92]
Reconciliation of Operating Loss and Operating Margin to Non-GAAP Operating Income (Loss)

[0001193125-25-263524:8k_2_02:93]
and Non-GAAP Operating Margin

[0001193125-25-263524:8k_2_02:94]
(Unaudited)

[0001193125-25-263524:8k_2_02:95]
(In thousands)

[0001193125-25-263524:8k_2_02:96]
|  |  | Three Months Ended |  |  |  | Nine Months Ended |  |  |
|  |  | September 30, |  |  | June 30, |  |  | September 30, |  |  |  | September 30, |  |  | September 30, |  |  |
|  |  | 2025 |  |  | 2025 |  |  | 2024 |  |  |  | 2025 |  |  | 2024 |  |  |
|  |  |  |  |  |  |  |  | (Restated) |  |  |  |  |  |  | (Restated) |  |  |
| Total Revenue |  | $ | 279,435 |  |  | $ | 265,068 |  |  | $ | 227,704 |  |  |  | $ | 792,247 |  |  | $ | 679,868 |  |  |
| Operating Loss |  | $ | (2,788 | ) |  | $ | (13,318 | ) |  | $ | (26,093 | ) |  |  | $ | (20,074 | ) |  | $ | (410,794 | ) |  |
| Acquisition related expenses, amortizations and adjustments (1) |  |  | 12,038 |  |  |  | 12,774 |  |  |  | 15,330 |  |  |  |  | 36,892 |  |  |  | 47,685 |  |  |
| Stock-based compensation expense |  |  | 2,855 |  |  |  | 2,673 |  |  |  | 3,468 |  |  |  |  | 8,738 |  |  |  | 10,782 |  |  |
| Restructuring expenses (2) |  |  | — |  |  |  | (284 | ) |  |  | 5,936 |  |  |  |  | (284 | ) |  |  | 40,576 |  |  |
| Integration expenses (3) |  |  | — |  |  |  | — |  |  |  | 367 |  |  |  |  | — |  |  |  | 1,447 |  |  |
| Deferred compensation adjustments (4) |  |  | 2,317 |  |  |  | 3,034 |  |  |  | 1,471 |  |  |  |  | 3,804 |  |  |  | 4,259 |  |  |
| Goodwill impairment (5) |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  | — |  |  |  | 297,353 |  |  |
| Professional fees and other expenses (6) |  |  | 694 |  |  |  | 3,153 |  |  |  | — |  |  |  |  | 3,847 |  |  |  | — |  |  |
| Non-GAAP Operating Income (Loss) |  | $ | 15,116 |  |  | $ | 8,032 |  |  | $ | 479 |  |  |  | $ | 32,923 |  |  | $ | (8,692 | ) |  |
| Operating Margin |  |  | -1.0 | % |  |  | -5.0 | % |  |  | -11.5 | % |  |  |  | -2.5 | % |  |  | -60.4 | % |  |
| Non-GAAP Operating Margin |  |  | 5.4 | % |  |  | 3.0 | % |  |  | 0.2 | % |  |  |  | 4.2 | % |  |  | -1.3 | % |  |

[0001193125-25-263524:8k_2_02:97]
(1) Includes intangible amortization of backlog, inventory fair value adjustments, developed technology, customer relationships, and trade names acquired in connection with business combinations. We incur charges relating to the amortization of intangible assets and exclude these charges for purposes of calculating our non-GAAP measures. Such charges are significantly impacted by the timing and magnitude of our acquisitions. We exclude these charges for the purpose of calculating our non-GAAP measures, primarily because they are noncash expenses and our internal benchmarking analyses evidence that many industry participants and peers present non-GAAP financial measures excluding intangible asset amortization. Although this does not directly affect our cash position, the loss in value of intangible assets over time can have a material impact on the equivalent GAAP earnings measure.

[0001193125-25-263524:8k_2_02:98]
(2) Includes expenses for the Company's  Business Efficiency Program, which was designed to optimize the assets and business processes following the business combination with Adtran Networks. The Business Efficiency Program was completed as of December 31, 2024.

[0001193125-25-263524:8k_2_02:99]
(3) Includes expenses related to the Company's one-time integration bonus program in connection with synergy targets as a results of the business combination with Adtran Networks, which was completed as of December 31, 2024.

[0001193125-25-263524:8k_2_02:100]
(4) Includes non-cash change in fair value of equity investments held in the ADTRAN Holdings, Inc. Deferred Compensation Program for certain employees, all of which is included in selling, general and administrative expenses on the condensed consolidated statement of loss.

[0001193125-25-263524:8k_2_02:101]
(5) Non-cash impairment of goodwill in our Network Solutions reporting unit, necessitated by factors such as a decrease in the Company's market capitalization, cautious service provider spending due to economic uncertainty and continued elevated customer inventory adjustments.

[0001193125-25-263524:8k_2_02:102]
(6) Includes professional fees related to an internal investigation and related employee exit costs, fees relating to other one-time professional fees and business expenses.

[0001193125-25-263524:8k_2_02:103]
Supplemental Information

[0001193125-25-263524:8k_2_02:104]
Reconciliation of Other Expense to Non-GAAP Other Expense

[0001193125-25-263524:8k_2_02:105]
(Unaudited)

[0001193125-25-263524:8k_2_02:106]
(In thousands)

[0001193125-25-263524:8k_2_02:107]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | June 30, |  |  | September 30, |  |  | September 30, |  |  | September 30, |  |
|  |  | 2025 |  |  | 2025 |  |  | 2024 |  |  | 2025 |  |  | 2024 |  |
|  |  |  |  |  |  |  |  | (Restated) |  |  |  |  |  | (Restated) |  |
| Interest and dividend income |  | $ | 291 |  |  | $ | 201 |  |  | $ | 664 |  |  | $ | 618 |  |  | $ | 1,427 |  |
| Interest expense |  |  | (5,499 | ) |  |  | (4,564 | ) |  |  | (5,679 | ) |  |  | (14,824 | ) |  |  | (17,183 | ) |
| Net investment gain |  |  | 2,186 |  |  |  | 3,075 |  |  |  | 1,382 |  |  |  | 3,575 |  |  |  | 4,507 |  |
| Other income (expense), net |  |  | (745 | ) |  |  | (2,636 | ) |  |  | (850 | ) |  |  | (2,437 | ) |  |  | (441 | ) |
| Total Other Expense |  | $ | (3,767 | ) |  | $ | (3,924 | ) |  | $ | (4,483 | ) |  | $ | (13,068 | ) |  | $ | (11,690 | ) |
| Deferred compensation adjustments (1) |  |  | (2,210 | ) |  |  | (2,968 | ) |  |  | (1,294 | ) |  |  | (3,529 | ) |  |  | (4,629 | ) |
| Pension expense (2) |  |  | 13 |  |  |  | 11 |  |  |  | 7 |  |  |  | 35 |  |  |  | 21 |  |
| Non-GAAP Other Expense |  | $ | (5,964 | ) |  | $ | (6,881 | ) |  | $ | (5,770 | ) |  | $ | (16,562 | ) |  | $ | (16,298 | ) |

[0001193125-25-263524:8k_2_02:108]
(1) Includes non-cash change in fair value of equity investments held in the ADTRAN Holdings, Inc. Deferred Compensation Program for Employees.

[0001193125-25-263524:8k_2_02:109]
(2) Includes amortization of actuarial losses related to the Company's pension plan for employees in certain foreign countries.

[0001193125-25-263524:8k_2_02:110]
Supplemental Information

[0001193125-25-263524:8k_2_02:111]
Reconciliation of Net Loss inclusive of Non-Controlling Interest to

[0001193125-25-263524:8k_2_02:112]
Non-GAAP Net Income (Loss) inclusive of Non-Controlling Interest

[0001193125-25-263524:8k_2_02:113]
(Unaudited)

[0001193125-25-263524:8k_2_02:114]
and

[0001193125-25-263524:8k_2_02:115]
Reconciliation of Net Loss attributable to ADTRAN Holdings, Inc. and

[0001193125-25-263524:8k_2_02:116]
Loss per Common Share attributable to ADTRAN Holdings, Inc. – Basic and Diluted to

[0001193125-25-263524:8k_2_02:117]
Non-GAAP Net Income (Loss) attributable to ADTRAN Holdings, Inc. and

[0001193125-25-263524:8k_2_02:118]
Non-GAAP Earnings (Loss) per Common Share attributable to ADTRAN Holdings, Inc. – Basic and Diluted

[0001193125-25-263524:8k_2_02:119]
(Unaudited)

[0001193125-25-263524:8k_2_02:120]
(In thousands, except per share amounts)

[0001193125-25-263524:8k_2_02:121]
|  |  | Three Months Ended |  |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | June 30, |  |  | September 30, |  |  |  | September 30, |  |  | September 30, |  |
|  |  | 2025 |  |  | 2025 |  |  | 2024 |  |  |  | 2025 |  |  | 2024 |  |
|  |  |  |  |  |  |  |  | (Restated) |  |  |  |  |  |  | (Restated) |  |
| Net Loss attributable to ADTRAN Holdings, Inc. common stockholders |  | $ | (9,743 | ) |  | $ | (19,037 | ) |  | $ | (30,372 | ) |  |  | $ | (40,050 | ) |  | $ | (410,804 | ) |
| Effect of redemption of RNCI (1) |  |  | (519 | ) |  |  | (1,494 | ) |  |  | (2,976 | ) |  |  |  | (2,010 | ) |  |  | (2,976 | ) |
| Net Loss attributable to ADTRAN Holdings, Inc. |  | $ | (10,262 | ) |  | $ | (20,531 | ) |  | $ | (33,348 | ) |  |  | $ | (42,060 | ) |  | $ | (413,780 | ) |
| Net Income attributable to non-controlling interest (2) |  |  | 2,505 |  |  |  | 2,273 |  |  |  | 2,382 |  |  |  |  | 7,097 |  |  |  | 7,417 |  |
| Net Loss inclusive of non-controlling interest |  | $ | (7,757 | ) |  | $ | (18,258 | ) |  | $ | (30,966 | ) |  |  | $ | (34,963 | ) |  | $ | (406,363 | ) |
| Acquisition related expenses, amortizations and adjustments (3) |  |  | 12,038 |  |  |  | 12,774 |  |  |  | 15,330 |  |  |  |  | 36,892 |  |  |  | 47,685 |  |
| Stock-based compensation expense |  |  | 2,855 |  |  |  | 2,673 |  |  |  | 3,468 |  |  |  |  | 8,738 |  |  |  | 10,782 |  |
| Deferred compensation adjustments (4) |  |  | 107 |  |  |  | 66 |  |  |  | 177 |  |  |  |  | 275 |  |  |  | (370 | ) |
| Pension adjustments (5) |  |  | 13 |  |  |  | 11 |  |  |  | 7 |  |  |  |  | 35 |  |  |  | 21 |  |
| Restructuring expenses (6) |  |  | — |  |  |  | (284 | ) |  |  | 5,936 |  |  |  |  | (284 | ) |  |  | 40,576 |  |
| Integration expenses (7) |  |  | — |  |  |  | — |  |  |  | 367 |  |  |  |  | — |  |  |  | 1,447 |  |
| Goodwill impairment |  |  | — |  |  |  | — |  |  |  | — |  |  |  |  | — |  |  |  | 297,353 |  |
| Professional fees and other expenses (8) |  |  | 694 |  |  |  | 3,153 |  |  |  | — |  |  |  |  | 3,847 |  |  |  | — |  |
| Tax effect of adjustments to net loss (9) |  |  | (2,301 | ) |  |  | 388 |  |  |  | (220 | ) |  |  |  | (3,893 | ) |  |  | (17,966 | ) |
| Non-GAAP Net Income (Loss) inclusive of non-controlling interest |  | $ | 5,649 |  |  | $ | 523 |  |  | $ | (5,901 | ) |  |  | $ | 10,647 |  |  | $ | (26,835 | ) |
| Net Income attributable to non-controlling interest (2) |  |  | 2,505 |  |  |  | 2,273 |  |  |  | 2,382 |  |  |  |  | 7,097 |  |  |  | 7,417 |  |
| Non-GAAP Net Income (Loss) attributable to ADTRAN Holdings, Inc. |  | $ | 3,144 |  |  | $ | (1,750 | ) |  | $ | (8,283 | ) |  |  | $ | 3,550 |  |  | $ | (34,252 | ) |
| Effect of redemption of RNCI (1) |  |  | 519 |  |  |  | 1,494 |  |  |  | 2,976 |  |  |  |  | 2,010 |  |  |  | 2,976 |  |
| Non-GAAP Net Income (Loss) attributable to ADTRAN Holdings, Inc. common stockholders |  | $ | 3,663 |  |  | $ | (256 | ) |  | $ | (5,307 | ) |  |  | $ | 5,560 |  |  | $ | (31,276 | ) |
| Weighted average shares outstanding – basic |  |  | 79,803 |  |  |  | 79,748 |  |  |  | 78,952 |  |  |  |  | 79,696 |  |  |  | 78,873 |  |
| Weighted average shares outstanding – diluted |  |  | 79,803 |  |  |  | 79,748 |  |  |  | 78,952 |  |  |  |  | 79,696 |  |  |  | 78,873 |  |
| Loss per common share attributable to ADTRAN Holdings, Inc. – basic |  | $ | (0.12 | ) |  | $ | (0.24 | ) |  | $ | (0.38 | ) |  |  | $ | (0.50 | ) |  | $ | (5.21 | ) |
| Loss per common share attributable to ADTRAN Holdings, Inc. – diluted |  | $ | (0.12 | ) |  | $ | (0.24 | ) |  | $ | (0.38 | ) |  |  | $ | (0.50 | ) |  | $ | (5.21 | ) |
| Non-GAAP Earnings (Loss) per common share attributable to ADTRAN – basic |  | $ | 0.05 |  |  | $ | (0.00 | ) |  | $ | (0.07 | ) |  |  | $ | 0.07 |  |  | $ | (0.40 | ) |
| Non-GAAP Earnings (Loss) per common share attributable to ADTRAN – basic |  | $ | 0.05 |  |  | $ | (0.00 | ) |  | $ | (0.07 | ) |  |  | $ | 0.07 |  |  | $ | (0.40 | ) |

[0001193125-25-263524:8k_2_02:122]
(1) Loss per common share attributable to ADTRAN Holdings, Inc. - basic and diluted - reflects a $0.5 million and a $2.0 million effect of redemption of RNCI for the three and nine months ended September 30, 2025 and a $3.0 million effect of redemption of RNCI for the three and nine months ended September 30, 2024.

[0001193125-25-263524:8k_2_02:123]
(2) Represents the non-controlling interest portion of the Company's ownership of Adtran Networks pre-DPLTA and the annual recurring compensation earned by redeemable non-controlling interests and accrued by the Company post-DPLTA.

[0001193125-25-263524:8k_2_02:124]
(3) We incur charges relating to the amortization of intangible assets and exclude these charges for purposes of calculating our non-GAAP measures. Such charges are significantly impacted by the timing and magnitude of our acquisitions. We exclude these charges for the purpose of calculating our non-GAAP measures, primarily because they are noncash expenses and our internal benchmarking analyses evidence that many industry participants and peers present non-GAAP financial measures excluding intangible asset amortization. Although this does not directly affect our cash position, the loss in value of intangible assets over time can have a material impact on the equivalent GAAP earnings measure.

[0001193125-25-263524:8k_2_02:125]
(4) Includes non-cash change in fair value of equity investments held in deferred compensation plans offered to certain employees.

[0001193125-25-263524:8k_2_02:126]
(5) Includes amortization of actuarial losses related to the Company's pension plan for employees in certain foreign countries.

[0001193125-25-263524:8k_2_02:127]
(6) Includes expenses for a Business Efficiency Program designed to optimize the assets and business processes following the business combination with Adtran Networks. The Business Efficiency Program was completed as of December 31, 2024.

[0001193125-25-263524:8k_2_02:128]
(7) Includes expenses related to the Company's one-time integration bonus program in connection with synergy targets as a results of the business combination with Adtran Networks. Includes fees incurred for the expansion of internal controls at Adtran Networks and the implementation of the DPTLA which was completed as of December 31, 2024.

[0001193125-25-263524:8k_2_02:129]
(8) Includes professional fees related to an internal investigation and related employee exit costs, fees relating to other one-time professional fees and business expenses.

[0001193125-25-263524:8k_2_02:130]
(9) Represents the tax effect of non-GAAP adjustments. Beginning in the period ended September 30, 2024, the Company changed its method of calculating non-GAAP income taxes by applying blended statutory tax rates to non-GAAP losses before income taxes in order to include current and deferred income tax expenses that are commensurate with the non-GAAP measure of profitability. The blended statutory tax rate is calculated using 0%, resulting in no tax benefits net of impact of valuation allowance, for the loss jurisdiction’s non-GAAP losses before income taxes and 30% for all remaining jurisdictions’ non-GAAP income before income taxes.

[0001193125-25-263524:8k_2_02:131]
Supplemental Information

[0001193125-25-263524:8k_2_02:132]
Reconciliation of Net Cash Provided By Operating Activities to Free Cash Flow

[0001193125-25-263524:8k_2_02:133]
(Unaudited)

[0001193125-25-263524:8k_2_02:134]
(In thousands)

[0001193125-25-263524:8k_2_02:135]
|  |  | Three Months Ended |  |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | June 30, |  |  | September 30, |  |  |  | September 30, |  |  | September 30, |  |
|  |  | 2025 |  |  | 2025 |  |  | 2024 |  |  |  | 2025 |  |  | 2024 |  |
|  |  |  |  |  |  |  |  | (Restated) |  |  |  |  |  |  | (Restated) |  |
| Net cash provided by operating activities |  | $ | 12,188 |  |  | $ | 32,160 |  |  | $ | 43,324 |  |  |  | $ | 87,529 |  |  | $ | 101,133 |  |
| Purchases of property, plant and equipment and developed technologies (1) |  |  | (17,029 | ) |  |  | (13,833 | ) |  |  | (20,141 | ) |  |  |  | (49,557 | ) |  |  | (50,837 | ) |
| Free cash flow (Non-GAAP) |  | $ | (4,841 | ) |  | $ | 18,327 |  |  | $ | 23,183 |  |  |  | $ | 37,972 |  |  | $ | 50,296 |  |

[0001193125-25-263524:8k_2_02:136]
(1) Purchases related to capital expenditures and developed technologies.
