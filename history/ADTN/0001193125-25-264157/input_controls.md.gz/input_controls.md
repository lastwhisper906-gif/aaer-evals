# ADTN 10-Q controls and the auditor's report


## item_4_controls

[0001193125-25-264157:item_4_controls:1]
ITEM 4. CONTROLS AND PROCEDURES

[0001193125-25-264157:item_4_controls:2]
Evaluation of Disclosure Controls and Procedures

[0001193125-25-264157:item_4_controls:3]
We maintain disclosure controls and procedures that are designed to ensure that the information required to be disclosed by us in reports that we file or submit under the Securities Exchange Act of 1934, as amended (the “Exchange Act”), is recorded, processed, summarized and reported within the time periods specified in the rules and forms promulgated by the SEC, and that such information is accumulated and communicated to our management, including our Chief Executive Officer and our Chief Financial Officer, as appropriate, to allow timely decisions regarding required disclosure.

[0001193125-25-264157:item_4_controls:4]
As of the end of the period covered by this report, an evaluation was carried out by management, including our Chief Executive Officer and Chief Financial Officer, of the effectiveness of our disclosure controls and procedures (as defined in Rules 13a-15(e) and 15d-15(e)) under the Exchange Act. Based on that evaluation, our Chief Executive Officer and Chief Financial Officer concluded that due to the material weaknesses in our internal control over financial reporting described below, our disclosure controls and procedures were not effective as of September 30, 2025.

[0001193125-25-264157:item_4_controls:5]
Material Weaknesses in Internal Control over Financial Reporting

[0001193125-25-264157:item_4_controls:6]
A material weakness is a deficiency, or a combination of deficiencies, in internal control over financial reporting, such that there is a reasonable possibility that a material misstatement of our annual or interim financial statements will not be prevented or detected on a timely basis. In its assessment of the effectiveness of internal control over financial reporting as of September 30, 2025, management determined that there were deficiencies in Adtran’s internal control over financial reporting that constituted material weaknesses that continue to exist as of September 30, 2025. Such material weaknesses were as follows:

[0001193125-25-264157:item_4_controls:7]
•
Adtran did not design and maintain effective controls in response to the risks of material misstatement. Specifically, changes to existing controls or the implementation of new controls have not been sufficient to respond to changes to the risks of material misstatement to financial reporting.

[0001193125-25-264157:item_4_controls:8]
•
Adtran did not design and maintain effective controls relating to communicating accurate information internally and with those charged with governance. This includes providing information pursuant to objectives, responsibilities and functions of internal control.

[0001193125-25-264157:item_4_controls:9]
These material weaknesses contributed to the following additional material weaknesses:

[0001193125-25-264157:item_4_controls:10]
•
Adtran did not design and maintain effective controls over financial statement preparation, presentation and disclosure commensurate with its financial reporting requirements. Specifically, Adtran did not design and maintain effective controls over the presentation and disclosure of transactions, including non-controlling interest.

[0001193125-25-264157:item_4_controls:11]
•
Adtran did not design and maintain effective controls to address the initial application of complex accounting standards and accounting of non-routine, unusual or complex events and transactions. Specifically, Adtran did not design and maintain effective controls to timely analyze and account for (i) non-controlling interest and (ii) the receivable purchase and servicing agreement.

[0001193125-25-264157:item_4_controls:12]
•
Adtran did not design and maintain effective controls over an inventory suspense account. Specifically, certain inventory activity was not reviewed at a sufficient level of precision to identify the nature and aging of the individual inventory suspense account activity.

[0001193125-25-264157:item_4_controls:13]
The material weaknesses resulted in the restatements and revisions of immaterial adjustments to our consolidated financial statements for the years ended December 31, 2022, December 31, 2023 and December 31, 2024, as well as the condensed consolidated financial statements for the quarterly and year-to-date periods ended September 30, 2022, March 31, 2023, June 30, 2023, September 30, 2023, March 31, 2024, June 30, 2024 and September 30, 2024. The material weaknesses also resulted in material adjustments that were corrected prior to the issuance of the condensed consolidated financial statements for the quarterly period ended March 31, 2025. Additionally, these material weaknesses could result in misstatements of Adtran’s accounts or disclosures that would result in a material misstatement to the annual or interim consolidated financial statements that would not be prevented or detected.

[0001193125-25-264157:item_4_controls:14]
Management’s Remediation Efforts

[0001193125-25-264157:item_4_controls:15]
To remediate the material weaknesses in Adtran’s internal control over financial reporting related to the risks of material misstatement, including financial statement preparation, presentation and disclosure of transactions and the non-controlling interest, Adtran has continued the implementation of its remediation plan that includes the introduction of new or enhanced controls over the review of Adtran's consolidated financial statements, global identification and reassessment of all key processes and controls, increased training and awareness of control activities, and increased scrutiny of control performance and documentation standards. Adtran's management believes that the continuation of its remediation plan along with the foregoing actions will support the improvement of the Company’s internal control over financial reporting, and, through its ongoing efforts to identify, design, and implement the necessary control activities, will be effective in remediating such material weaknesses.

[0001193125-25-264157:item_4_controls:16]
61

[0001193125-25-264157:item_4_controls:17]
To remediate the material weaknesses in Adtran’s internal control over financial reporting relating to accounting for non-routine, unusual or complex events and transactions for non-controlling interest and the receivable purchase and servicing agreement, Adtran has implemented a remediation plan that involved redesigned controls over the identification and review of contracts, transactions or arrangements that may result in a financial obligation including the use of an accounting or reporting third-party advisor as needed to ensure proper presentation of these items within its consolidated financial statements.

[0001193125-25-264157:item_4_controls:18]
To remediate the material weakness relating to the communication of accurate information internally and with those charged with governance, Adtran has implemented a remediation plan that includes the enhancement of key internal control and communication policies, training sessions for personnel on internal control expectations, the implementation of a quarterly sub-certification process, and redesigned controls over the identification and review of contracts, transactions or arrangements that may result in a financial obligation.

[0001193125-25-264157:item_4_controls:19]
To remediate the material weakness relating to maintaining effective controls over an inventory suspense account, Adtran has implemented its remediation plan that includes the redesign of the reconciliation control specific to the suspense account and enhanced its review procedures (including over aged items) and training sessions for personnel on reconciliation procedures. The redesigned control operated for each of the three months in the quarter ended September 30, 2025.

[0001193125-25-264157:item_4_controls:20]
We have implemented certain of the above-referenced controls, as and to the extent disclosed above, and are in the process of testing their effectiveness, and we continue to implement certain other controls. We will continue to devote significant time and attention to these remediation efforts. As Adtran continues to evaluate and work to improve its internal control over financial reporting, management may decide to take additional measures to address the material weaknesses or determine to modify the remediation plans described above. Until the remediation steps set forth above, including the implementation of all necessary control activities that we identify, are fully completed, and there has been time for us to conclude through testing that the control activities are operating effectively, the material weaknesses described above will not be considered remediated.

[0001193125-25-264157:item_4_controls:21]
Changes in Internal Control over Financial Reporting

[0001193125-25-264157:item_4_controls:22]
The third quarter remediation activities described above are changes in Adtran’s internal control over financial reporting that occurred during the most recent fiscal quarter covered by this report that have materially affected, or are reasonably likely to materially affect, its internal control over financial reporting.

[0001193125-25-264157:item_4_controls:23]
62
