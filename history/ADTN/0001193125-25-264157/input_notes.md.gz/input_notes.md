# ADTN notes — 0001193125-25-264157


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001193125-25-264157:notes:1]
[same as prior period, unchanged from 0000950170-25-102561:notes:1]

[0001193125-25-264157:notes:2]
[same as prior period, unchanged from 0000950170-25-102561:notes:2]

[0001193125-25-264157:notes:3]
[same as prior period, unchanged from 0000950170-25-102561:notes:3]

[0001193125-25-264157:notes:4]
Liquidity, Domination and Profit and Loss Transfer Agreement, Notes Offering and Credit Facility

[0001193125-25-264157:notes:5]
[same as prior period, unchanged from 0000950170-25-102561:notes:5]

[0001193125-25-264157:notes:6]
[same as prior period, unchanged from 0000950170-25-102561:notes:6]

[0001193125-25-264157:notes:7]
Pursuant to the terms of the DPLTA, each Adtran Networks shareholder (other than the Company) has received an offer to elect either (1) to remain an Adtran Networks shareholder and receive from us recurring compensation in cash of €0.52 per share for each full fiscal year of Adtran Networks (the "Annual Recurring Compensation"), or (2) to put their Adtran Networks shares to the Company in exchange for compensation in cash of €17.21 per share, plus guaranteed interest (the "Exit Compensation"). The guaranteed interest under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid. The guaranteed interest rate is 5.0% plus a variable component (according to the German Civil Code) that was 1.27% as of September 30, 2025. Assuming all the minority holders of currently outstanding Adtran Networks shares were to elect the second option, we would be obligated to make aggregate Exit Compensation payments, including guaranteed interest, of approximately €322.7 million or $378.7 million, based on an exchange rate as of September 30, 2025, and reflecting interest accrued through September 30, 2025 during the pendency of the appraisal proceedings discussed below. Shareholders electing the first option of Annual Recurring Compensation may later elect the second option. The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that were initiated in 2023 in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the Federal Gazette (Bundesanzeiger). Following the court's decision on a procedural matter in the DPLTA appraisal proceedings on July 14, 2025, the trial on the merits of the DPLTA has recommenced. It is expected to take a minimum of 12 months for a ruling of the court on the merits and such ruling will most likely be appealed, which would be expected to take an additional 12-24 months to be resolved. Accordingly, the Company does not expect a final decision on the DPLTA appraisal proceedings to be rendered and published prior to 2027, and most likely not until 2028 or beyond.

[0001193125-25-264157:notes:8]
Additionally, our obligation to pay Annual Recurring Compensation under the DPLTA is a continuing payment obligation, which will amount to approximately €8.5 million (or $10.0 million based on the exchange rate as of September 30, 2025) per year assuming none of the minority Adtran Networks shareholders as of September 30, 2025 were to elect Exit Compensation. The foregoing amounts do not reflect any potential increase in payment obligations that we may have depending on the outcome of ongoing appraisal proceedings in the German court. The Annual Recurring Compensation is due on the third banking day following the ordinary general shareholders’ meeting of Adtran Networks for the respective preceding fiscal year (but in any event within eight months following expiration of the fiscal year). With respect to the 2023 fiscal year, Adtran Networks’ ordinary general shareholders’ meeting occurred on June 28, 2024 and, therefore, the Annual Recurring Compensation was paid on July 3, 2024. With respect to the 2024 fiscal year, Adtran Networks’ ordinary general shareholder meeting occurred on June 27, 2025 and, therefore, the Annual Recurring Compensation was paid on July 1, 2025. During the three months ended September 30, 2025 and 2024, we accrued $2.5 million and $2.4 million, respectively, in Annual Recurring Compensation. During the nine months ended September 30, 2025 and 2024, we accrued $7.5 million and $7.4 million, respectively, in Annual Recurring Compensation. The Annual Recurring Compensation is reflected as an increase to retained deficit.

[0001193125-25-264157:notes:9]
On July 18, 2022, ADTRAN, Inc., as the borrower, and ADTRAN Holdings, Inc. entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (“Credit Agreement”), which has since been amended six times. The Company had access to $319.2 million on its Credit Facility for future borrowings; however, as of September 30, 2025, the Company was limited to additional borrowings of $232.0 million based on debt covenant compliance metrics. The financial covenants under the Credit Agreement, as amended, require the Company to maintain a Consolidated Total Net Leverage Ratio of 5.00x, a Consolidated Senior Secured Net Leverage Ratio of 3.25x (4.0x to 3.5x during a Springing Covenant Period) and a Consolidated Fixed Charge Coverage Ratio of 1.25x (as such terms are defined in the Credit Agreement). In addition, during a Springing Covenant Period the cash and cash equivalents of the credit parties must be at least $50.0 million and the cash and cash equivalents of the Company and its subsidiaries must be at least $70.0 million. See Note 11, Credit Agreement for additional information regarding the terms of the Wells Fargo Credit Agreement.

[0001193125-25-264157:notes:10]
[same as prior period, unchanged from 0000950170-25-102561:notes:10]

[0001193125-25-264157:notes:11]
As of September 30, 2025, and as of the date of issuance of these financial statements, the Company has sufficient liquidity to meet a majority of its payment obligations under the DPLTA pertaining to Exit Compensation. For the three and nine months ended September 30, 2025, less than one thousand shares and approximately 0.9 million shares, respectively, of Adtran Networks stock were tendered to the Company. This resulted in total Exit Compensation payments of approximately €16.9 million or $19.9 million based on the applicable exchange rates at the time of the transactions being paid to Adtran Networks shareholders. For the three and nine months ended September 30, 2024, approximately 0.8 million shares of Adtran Networks stock were tendered to the Company. This resulted in Exit Compensation payments of approximately €15.7 million, or $17.4 million, based on the applicable exchange rates at the time of the transactions, being paid to Adtran Networks shareholders. We believe the probability that more than a small minority of Adtran Networks shareholders elect to receive Exit Compensation in the next twelve months is remote based on the following factors: (i) the shareholders can exercise their right to receive the Exit Compensation until two months after publication of the final decision in the appraisal proceedings and we do not expect the final decision to be published within the next 12 months; (ii) the diverse base of shareholders that must make this election on an individual shareholder basis; (iii) the fact the date of a decision by the court on the merits of the case is uncertain, it will most likely take a minimum of 12 months for a ruling and, thereafter, an expected appeal process will take a further 12-24 months to resolve; (iv) the current guaranteed Annual Recurring Compensation payment; and (v) the current trading value of Adtran Networks shares.

[0001193125-25-264157:notes:12]
Moreover, on September 19, 2025, the Company issued $201.3 million aggregate principal amount of convertible senior notes due 2030 (the “Notes”). The Notes accrue interest at a rate of 3.75% per annum, payable semi-annually in arrears on March 15 and September 15 of each year, beginning March 15, 2026. Unless repurchased earlier, redeemed, or converted, the Notes will mature on September 15, 2030. After deducting the initial purchasers’ discounts, commissions, and estimated offering expenses, the Company received net proceeds of $192.8 million. As of September 30, 2025, and as of the date of issuance of these financial statements, management believes that the Company has sufficient liquidity to meet its payment obligations under the Notes through its operating cash flow and the borrowings available under the Credit Agreement.

[0001193125-25-264157:notes:13]
The Company experienced revenue declines in the year ended December 31, 2024. However, customers began replenishing their inventories to meet increasing demand, and revenue increased throughout the first three quarters of 2025. In 2023, the Company suspended dividend payments and effectuated a business efficiency program (the "Business Efficiency Program"), which targeted the reduction of ongoing operating expenses and focused on enhancing capital efficiency. The Business Efficiency Program was completed as of December 31, 2024. In addition, the Company continues to assess the probability that the sale of its headquarters in Huntsville will occur and has determined it is probable of occurring in the next twelve months.

[0001193125-25-264157:notes:14]
In summary, the Company believes that its cash, cash equivalents and restricted cash, working capital management initiatives and availability to access cash under the Wells Fargo credit facility will be adequate to meet our business operating requirements, our capital expenditures and our expected obligations under both the Notes and the DPLTA, including anticipated levels of Exit Compensation, as well as to support our ability to continue to comply with our debt covenants under the Credit Facility for at least the next twelve months,

[0001193125-25-264157:notes:15]
from the issuance of these financial statements. See Note 11, Credit Agreements, for additional information regarding the terms of the Amendments of the Credit Agreement.

[0001193125-25-264157:notes:16]
[same as prior period, unchanged from 0000950170-25-102561:notes:14]

[0001193125-25-264157:notes:17]
[same as prior period, unchanged from 0000950170-25-102561:notes:16]

[0001193125-25-264157:notes:18]
[same as prior period, unchanged from 0000950170-25-102561:notes:17]

[0001193125-25-264157:notes:19]
[same as prior period, unchanged from 0000950170-25-102561:notes:18]

[0001193125-25-264157:notes:20]
Restatement of Previously Issued Financial Statements

[0001193125-25-264157:notes:21]
[same as prior period, unchanged from 0000950170-25-102561:notes:20]

[0001193125-25-264157:notes:22]
In connection with the identification of the Adjustment, the Audit Committee oversaw an internal investigation into the circumstances surrounding the Adjustment and its impact on the Company’s historical financial statements. Based on the findings of the internal investigation, it was determined that the underlying errors giving rise to the Adjustment were not properly addressed in the Company’s previously filed financial statements as of and for the years ended December 31, 2024 and 2023 and were not communicated to the Audit Committee or the independent auditors prior to the filing of the initial 2024 Annual Report on Form 10-K. As described in Part I, Item 4 of this report, the Company is taking certain remedial actions to address the material weaknesses in its internal controls associated with these findings. On August 4, 2025, we received a letter from the Atlanta regional office of the SEC in connection with a non-public, fact-finding inquiry, requesting that we voluntarily provide information regarding the internal investigation.

[0001193125-25-264157:notes:23]
The identified errors referenced above impacted the Condensed Consolidated Financial Statements as of and for the three and nine months ended September 30, 2024, among other periods as previously disclosed. Below is a summary description of the significant errors in the Company's Condensed Consolidated Financial Statements as of and for the three and nine months ended September 30, 2024:

[0001193125-25-264157:notes:24]
[same as prior period, unchanged from 0000950170-25-102561:notes:23]

[0001193125-25-264157:notes:25]
[same as prior period, unchanged from 0000950170-25-102561:notes:24]

[0001193125-25-264157:notes:26]
[same as prior period, unchanged from 0000950170-25-102561:notes:25]

[0001193125-25-264157:notes:27]
[same as prior period, unchanged from 0000950170-25-102561:notes:26]

[0001193125-25-264157:notes:28]
[same as prior period, unchanged from 0000950170-25-102561:notes:27]

[0001193125-25-264157:notes:29]
We assessed the materiality of the errors on prior period consolidated financial statements in accordance with SEC Staff Accounting Bulletin No. 99, “Materiality,” codified in ASC Topic 250, Accounting Changes and Error Corrections. Based on this assessment, we concluded that the errors, in the aggregate, are material to the September 30, 2024 financial statements and therefore, we have restated

[0001193125-25-264157:notes:30]
those financial statements herein. Furthermore, we made adjustments to correct for other previously identified immaterial errors. The Company has also restated impacted amounts within the accompanying footnotes to the Condensed Consolidated Financial Statements. See Note 20 for further information about the restatement.

[0001193125-25-264157:notes:31]
[same as prior period, unchanged from 0000950170-25-102561:notes:30]

[0001193125-25-264157:notes:32]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenue and expense during the reporting period. Significant estimates include allowance for credit losses on accounts receivable and contract assets, excess and obsolete inventory reserves, warranty reserves, customer rebates, determination and accrual of the deferred revenue related to performance obligations under contracts with customers, estimated costs to complete obligations associated with deferred and accrued revenue and network installations, estimated income tax provision and income tax contingencies, fair value of stock-based compensation, assessment of goodwill and other intangibles for impairment, estimated lives of intangible assets, estimates of intangible assets upon measurement, estimated pension liability and fair value of investments and estimated contingent liabilities. Actual amounts could differ significantly from these estimates.

[0001193125-25-264157:notes:33]
We assessed certain accounting matters that generally require consideration of forecasted financial information in context with the information reasonably available to us and the unknown future impacts of ongoing inflationary pressures, continued elevated interest rates, currency fluctuations and political tensions as of September 30, 2025, and through the date of this report. These conditions could result in further impacts to the Company's consolidated financial statements in future reporting periods. The accounting matters assessed included, but were not limited to, the allowance for credit losses, stock-based compensation, carrying value of goodwill, intangibles and other long-lived assets, financial assets, valuation allowances for tax assets, revenue recognition and costs of revenue.

[0001193125-25-264157:notes:34]
Restricted Cash

[0001193125-25-264157:notes:35]
Restricted cash consists of cash pledged as collateral, which is permitted to be withdrawn for the purpose of financing the purchase of additional outstanding shares of Equity Interests (as defined in the Credit Agreement) of Adtran Networks. See Note 11 for additional information.

[0001193125-25-264157:notes:36]
Convertible Senior Notes

[0001193125-25-264157:notes:37]
We account for our convertible senior notes with embedded conversion features in accordance with ASC 470-20, under which convertible debt instruments would only be separated into multiple components if they were issued at a substantial premium or if embedded derivatives requiring bifurcation were identified. The convertible senior notes (the "2030 Notes" or the “Notes”) were not issued at a substantial premium, and we analyzed the provisions of the 2030 Notes and did not identify any material embedded features which would require bifurcation from the host debt. As such, the 2030 Notes are accounted for entirely as a liability, net of unamortized issuance costs. The carrying amount of the liability is classified as long-term as the instrument does not mature within one year of the balance sheet date and the holder is not permitted to demand repayment of the principal within one year of the balance sheet date. However, if conditions to convertibility are met and holders are expected to convert within one year as described further in Note 12, we may be required to reclassify the carrying amount of the liability to current. Issuance costs are amortized to interest expense using the effective interest rate method.

[0001193125-25-264157:notes:38]
During the nine months ended September 30, 2025, there were no other significant changes to our critical accounting policies as described in the financial statements contained in the 2024 Form 10-K/A.

[0001193125-25-264157:notes:39]
[same as prior period, unchanged from 0000950170-25-102561:notes:33]

[0001193125-25-264157:notes:40]
In September 2025, the Financial Accounting Standards Board (“FASB”) issued ASU 2025-06, "Intangibles-Goodwill and Other-Internal-Use Software (Subtopic 350-40): Targeted Improvements to the Accounting for Internal-Use Software," which is intended to modernize the accounting for the costs of internal-use software given the evolution of software development to the incremental and iterative development method. The amendments remove all references to prescriptive and sequential development stages and, instead, require an entity to start capitalizing software costs when management has authorized and committed to funding the software project, and it is probable that the project will be completed and the software will be used to perform the function intended. The amendments are effective for annual reporting periods beginning after December 15, 2027, and interim reporting periods within those annual reporting periods. Early adoption is permitted as of the beginning of an annual reporting period with the amendments to be applied using a prospective, modified or retrospective transition approach. The Company is currently evaluating the impact of adopting this guidance on the consolidated financial statements.

[0001193125-25-264157:notes:41]
In November 2024, the FASB issued ASU 2024-03, "Disaggregation of Income Statement Expenses (DISE) (Topic 220): Improvements to Income Statement Disclosures", which applies to all public business entities and is intended to enhance disclosures about specific types of expenses included in the expense captions presented on the face of the income statement as well as disclosures about selling expenses. The amendments are effective prospectively for annual periods beginning after December 15, 2026, and early adoption and retrospective application are permitted. The Company is currently evaluating the effect that adoption of ASU 2024-03 will have on our disclosures.

[0001193125-25-264157:notes:42]
In December 2023, the FASB issued ASU 2023-09, "Income Taxes (Topic 740): Improvements to Income Tax Disclosures", which is intended to enhance the transparency, decision usefulness and effectiveness of income tax disclosures. The amendments in this ASU require a public entity to disclose a tabular tax rate reconciliation, using both percentages and currency, with specific categories. A public entity is also required to provide a qualitative description of the states and local jurisdictions that make up the majority of the effect of the state and local income tax category and the net amount of income taxes paid, disaggregated by federal, state and foreign taxes and also disaggregated by individual jurisdictions. The amendments also remove certain disclosures that are no longer considered cost beneficial. The amendments are effective prospectively for annual periods beginning after December 15, 2024, and early adoption and retrospective application are permitted. The resulting new annual disclosure requirements will be reflected in our 2025 report on Form 10-K. The adoption of this guidance is not expected to have a material impact on our consolidated financial statements.

[0001193125-25-264157:notes:43]
Recently Adopted Accounting Pronouncements

[0001193125-25-264157:notes:44]
There are currently no recently adopted accounting pronouncements that are expected to have a material effect on the Condensed Consolidated Financial Statements.


## us-gaap:CashAndCashEquivalentsDisclosureTextBlock

[0001193125-25-264157:notes:45]
2. CASH, CASH EQUIVALENTS AND RESTRICTED CASH

[0001193125-25-264157:notes:46]
The following table provides a reconciliation of cash, cash equivalents and restricted cash reported within the Condensed Consolidated Balance Sheet that agree to the total of the same such amounts shown in the Condensed Consolidated Statement of Cash Flows:

[0001193125-25-264157:notes:47]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | September 30, 2025 |  |  | December 31, 2024 |  |
| Cash and cash equivalents |  | $ | 93,682 |  |  | $ | 76,021 |  |
| Restricted cash |  |  | 7,547 |  |  |  | — |  |
| Cash, cash equivalents and restricted cash |  | $ | 101,229 |  |  | $ | 76,021 |  |

[0001193125-25-264157:notes:48]
The Company did not have any restricted cash as of December 31, 2024. See Note 11 for additional information regarding restricted cash.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001193125-25-264157:notes:49]
3. REVENUE

[0001193125-25-264157:notes:50]
[same as prior period, unchanged from 0000950170-25-102561:notes:39]

[0001193125-25-264157:notes:51]
[same as prior period, unchanged from 0000950170-25-102561:notes:40]

[0001193125-25-264157:notes:52]
[same as prior period, unchanged from 0000950170-25-102561:notes:41]

[0001193125-25-264157:notes:53]
[same as prior period, unchanged from 0000950170-25-102561:notes:42]

[0001193125-25-264157:notes:54]
[same as prior period, unchanged from 0000950170-25-102561:notes:43]

[0001193125-25-264157:notes:55]
[same as prior period, unchanged from 0000950170-25-102561:notes:44]

[0001193125-25-264157:notes:56]
[same as prior period, unchanged from 0000950170-25-102561:notes:45]

[0001193125-25-264157:notes:57]
[same as prior period, unchanged from 0000950170-25-102561:notes:46]

[0001193125-25-264157:notes:58]
[same as prior period, unchanged from 0000950170-25-102561:notes:47]

[0001193125-25-264157:notes:59]
|  |  | Three Months Ended |  |
|  |  | September 30, 2025 |  |  | September 30, 2024 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Subscriber Solutions |  | $ | 92,770 |  |  | $ | 8,368 |  |  | $ | 101,138 |  |  | $ | 81,060 |  |  | $ | 9,036 |  |  | $ | 90,096 |  |
| Access & Aggregation Solutions |  |  | 61,051 |  |  |  | 13,757 |  |  |  | 74,808 |  |  |  | 52,954 |  |  |  | 14,119 |  |  |  | 67,073 |  |
| Optical Networking Solutions |  |  | 78,722 |  |  |  | 24,767 |  |  |  | 103,489 |  |  |  | 47,474 |  |  |  | 23,061 |  |  |  | 70,535 |  |
| Total |  | $ | 232,543 |  |  | $ | 46,892 |  |  | $ | 279,435 |  |  | $ | 181,488 |  |  | $ | 46,216 |  |  | $ | 227,704 |  |

[0001193125-25-264157:notes:60]
|  |  | Nine Months Ended |  |
|  |  | September 30, 2025 |  |  | September 30, 2024 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Subscriber Solutions |  | $ | 240,055 |  |  | $ | 25,252 |  |  | $ | 265,307 |  |  | $ | 215,044 |  |  | $ | 27,218 |  |  | $ | 242,262 |  |
| Access & Aggregation Solutions |  |  | 214,251 |  |  |  | 40,905 |  |  |  | 255,156 |  |  |  | 174,843 |  |  |  | 43,449 |  |  |  | 218,292 |  |
| Optical Networking Solutions |  |  | 199,952 |  |  |  | 71,832 |  |  |  | 271,784 |  |  |  | 152,068 |  |  |  | 67,246 |  |  |  | 219,314 |  |
| Total |  | $ | 654,258 |  |  | $ | 137,989 |  |  | $ | 792,247 |  |  | $ | 541,955 |  |  | $ | 137,913 |  |  | $ | 679,868 |  |

[0001193125-25-264157:notes:61]
The aggregate amount of transaction price allocated to remaining performance obligations (“RPO”) that have not been satisfied as of September 30, 2025 related to non-cancellable contractual maintenance agreements, non-cancellable contractual SaaS and subscription services, and non-cancellable hardware contracts amounted to $174.0 million. The Company identified an immaterial error in its 2024 RPO disclosure of $325.7 million where it incorrectly included cancellable contracts and inappropriately applied the practical expedient under ASC 606. The Company has corrected the disclosure to remove the cancellable portion of RPO amounts and to reflect the impact of discontinuing the use of the practical expedient to exclude contracts with an original expected duration of one year or less. The corrected amount of the RPO is $185.4 million as of December 31, 2024. The Company will generally satisfy the remaining performance obligations as we transfer control of the products ordered or services to our customers, excluding maintenance services, which are satisfied over time.

[0001193125-25-264157:notes:62]
[same as prior period, unchanged from 0000950170-25-102561:notes:51]

[0001193125-25-264157:notes:63]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | September 30, 2025 |  |  | December 31, 2024 |  |
| Accounts receivable, net |  | $ | 178,621 |  |  | $ | 178,030 |  |
| Contract assets(1) |  | $ | 360 |  |  | $ | 631 |  |
| Unearned revenue |  | $ | 57,563 |  |  | $ | 52,701 |  |
| Non-current unearned revenue |  | $ | 23,196 |  |  | $ | 22,065 |  |

[0001193125-25-264157:notes:64]
(1)	Included in other receivables.

[0001193125-25-264157:notes:65]
[same as prior period, unchanged from 0000950170-25-102561:notes:54]

[0001193125-25-264157:notes:66]
The allowance for credit losses was $1.2 million and $1.3 million as of September 30, 2025 and December 31, 2024, respectively.

[0001193125-25-264157:notes:67]
[same as prior period, unchanged from 0000950170-25-102561:notes:56]

[0001193125-25-264157:notes:68]
On July 1, 2024, the Company entered into a receivables purchase agreement (the “Factoring Agreement”) with a third-party financial institution, which accelerates receivable collection and helps to better manage cash flow. Total accounts receivables factored as of the end of September 30, 2025, totaled $23.6 million net of $3.7 million retained pursuant to the Factoring Agreement in the reserve account. Total accounts receivables factored as of the end of September 30, 2024, totaled $16.7 million net of  $3.7 million retained pursuant to the Factoring Agreement in the reserve account. The Factoring Agreement provides for up to $40.0 million in factoring capacity, subject to eligible receivables and reserve requirements, secured by the receivables. The balance in the reserve account is included in other assets. The Company at its own expense does have collection and administrative responsibilities for the sold receivables and that is its only continuing involvement with the factoring party. The Company is not compensated for the servicing of the factoring program and deems the costs of servicing the receivables sold to be immaterial.

[0001193125-25-264157:notes:69]
During the three and nine months ended September 30, 2025, the Company received $49.2 million and $119.4 million, in cash proceeds from the Factoring Agreement, respectively, and during the three and nine months ended September 30, 2024, the Company received $39.9 million, in cash proceeds from the Factoring Agreement, which are recorded as a component of accounts receivable in operating cash flows on the Condensed Consolidated Statement of Cash Flows. The cost of the Factoring Agreement is included in interest expense in the Condensed Consolidated Statements of Loss and totaled $0.5 million and $0.3 million for the three months ended September, 30, 2025 and 2024, respectively, and $1.0 million and $0.3 million for the nine months ended September 30, 2025 and 2024, respectively.

[0001193125-25-264157:notes:70]
On December 19, 2023, the Company entered into a receivables purchase agreement (the "Prior Factoring Agreement") with a third-party financial institution which qualified for treatment as a secured borrowing with a pledge of collateral under Accounting Standards Codification ("ASC") Topic 810, Consolidation. The Prior Factoring Agreement was terminated on July 1, 2024. For the nine months ended September 30, 2024, the Company incurred program fee expenses of $0.6 million.

[0001193125-25-264157:notes:71]
[same as prior period, unchanged from 0000950170-25-102561:notes:59]

[0001193125-25-264157:notes:72]
No allowance for credit losses was recorded for the three and nine months ended September 30, 2025 and 2024, respectively, related to contract assets.

[0001193125-25-264157:notes:73]
[same as prior period, unchanged from 0000950170-25-102561:notes:61]

[0001193125-25-264157:notes:74]
Of the outstanding unearned revenue balances as of December 31, 2024, $9.3 million and $44.1 million were recognized as revenue during the three and nine months ended September 30, 2025, respectively. Of the $65.1 million of outstanding unearned revenue balances as of December 31, 2023, $10.03 million and $43.1 million were recognized as revenue during the three and nine months ended September 30, 2024, respectively.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-25-264157:notes:75]
4. INCOME TAXES

[0001193125-25-264157:notes:76]
The Company’s effective tax rate changed from an expense of 1.4% of pre-tax loss for the three months ended September 30, 2024, to an expense of 18.3% of pre-tax loss for the three months ended September 30, 2025, and changed from a benefit of 3.9% of pre-tax loss for the nine months ended September 30, 2024, to an expense of 5.5% of pre-tax loss for the nine months ended September 30, 2025. The changes in the effective tax rate for the three and nine months ended September 30, 2025, were driven primarily by loss jurisdictions for which the recognition of tax benefits on pre-tax losses were limited due to a valuation allowance.

[0001193125-25-264157:notes:77]
The Company continually reviews the adequacy of its valuation allowance and recognizes the benefits of deferred tax assets only as the assessment indicates that it is more likely than not that the deferred tax assets will be recognized in accordance with ASC 740, Income Taxes. As of September 30, 2025, the Company had net deferred tax assets totaling $101.2 million, and a valuation allowance totaling $115.7 million against those deferred tax assets. Our assessment of the realizability of our deferred tax assets includes the evaluation of historical operating results, as well as the evaluation of evidence which requires significant judgment, including the evaluation of our three-year cumulative income position, future taxable income projections and tax planning strategies. Should management’s conclusion change in the future and an additional valuation allowance, or a partial or full release of the valuation allowance becomes necessary, it may have a material effect on our consolidated financial statements.

[0001193125-25-264157:notes:78]
On July 4, 2025, the “One Big Beautiful Bill Act” (OBBBA) was signed into law, which makes permanent many of the tax provisions enacted in 2017 as part of the Tax Cuts and Jobs Act that were set to expire at the end of 2025. In addition, the OBBBA makes changes to certain U.S. corporate tax provisions, but many are generally not effective until 2026. Due to the timing of enactment within our current period end, the Company has undergone efforts to reasonably estimate the impact of the Act on our condensed consolidated financial statements and there were no material impacts to the financial statements. We will continue to evaluate the full impact of these legislative changes as more guidance becomes available.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-25-264157:notes:79]
5. STOCK-BASED COMPENSATION

[0001193125-25-264157:notes:80]
[same as prior period, unchanged from 0000950170-25-102561:notes:67]

[0001193125-25-264157:notes:81]
[same as prior period, unchanged from 0000950170-25-102561:notes:68]

[0001193125-25-264157:notes:82]
[same as prior period, unchanged from 0000950170-25-102561:notes:69]

[0001193125-25-264157:notes:83]
Under the 2024 Directors Plan, the Company is authorized to issue 0.7 million shares of common stock through stock options, restricted stock and RSUs to non-employee directors. Stock awards issued under the 2024 Directors Plan typically will become vested in full on the first anniversary of the grant date. Stock options issued under the 2024 Directors Plan will have a ten-year contractual term. Stock options, restricted stock and RSUs granted under the 2024 Directors Plan reduce the shares authorized for issuance under the 2024 Directors Plan by one share of common stock for each share underlying the award. Forfeitures, cancellations and expirations of awards granted under the 2020 Directors Stock Plan increase the shares authorized for issuance under the 2024 Directors Plan by one share of common stock for each share underlying the award.

[0001193125-25-264157:notes:84]
As of September 30, 2025, 4.2 million shares were available for issuance pursuant to awards that may be made in the future under shareholder-approved equity plans.

[0001193125-25-264157:notes:85]
For the three months ended September 30, 2025 and 2024, stock-based compensation expense was $2.9 million and $3.7 million, respectively, and for the nine months ended September 30, 2025 and 2024, stock-based compensation expense was $8.7 million and $11.5 million, respectively.

[0001193125-25-264157:notes:86]
[same as prior period, unchanged from 0000950170-25-102561:notes:73]

[0001193125-25-264157:notes:87]
The following table summarizes the changes of the PSUs, RSUs and restricted stock outstanding during the nine months ended September 30, 2025:

[0001193125-25-264157:notes:88]
|  |  | Number of Shares(in thousands) |  |  | Weighted Avg. Grant Date Fair Value(per share) |  |
| Unvested PSUs, RSUs and restricted stock outstanding, December 31, 2024 |  |  | 2,335 |  |  | $ | 13.22 |  |
| PSUs, RSUs and restricted stock granted |  |  | 1,303 |  |  | $ | 10.34 |  |
| PSUs, RSUs and restricted stock vested |  |  | (523 | ) |  | $ | 11.78 |  |
| PSUs, RSUs and restricted stock forfeited |  |  | (156 | ) |  | $ | 14.23 |  |
| Unvested PSUs, RSUs and restricted stock outstanding, September 30, 2025 |  |  | 2,959 |  |  | $ | 11.39 |  |

[0001193125-25-264157:notes:89]
[same as prior period, unchanged from 0000950170-25-102561:notes:76]

[0001193125-25-264157:notes:90]
As of September 30, 2025, total unrecognized compensation expense related to the non-vested portion of market-based PSUs, RSUs and restricted stock was approximately $15.7 million, which will be recognized over the remaining weighted-average period of 2.6 years. As of September 30, 2025, there was $9.9 million of unrecognized compensation expense related to unvested performance-based PSUs (not considered probable), which will be recognized over the remaining requisite service period of 0.3 years if achievement of the performance obligation becomes probable. Unrecognized compensation expense will be adjusted for actual forfeitures.

[0001193125-25-264157:notes:91]
[same as prior period, unchanged from 0000950170-25-102561:notes:78]

[0001193125-25-264157:notes:92]
The following table summarizes the changes of the stock options outstanding that occurred during the nine months ended September 30, 2025:

[0001193125-25-264157:notes:93]
|  |  | Number of Stock Options(in thousands) |  |  | Weighted Avg. Exercise Price(per share) |  |  | Weighted Avg. Remaining Contractual Life(in years) |  |  | Aggregate Intrinsic Value(in thousands) |  |
| Stock options outstanding, December 31, 2024 |  |  | 2,944 |  |  | $ | 9.86 |  |  |  | 5.0 |  |  | $ | 3,762 |  |
| Stock options exercised |  |  | (216 | ) |  | $ | 6.62 |  |  |  |  |  |  |  |
| Stock options forfeited |  |  | (106 | ) |  | $ | 9.67 |  |  |  |  |  |  |  |
| Stock options expired |  |  | (18 | ) |  | $ | 14.16 |  |  |  |  |  |  |  |
| Stock options outstanding, September 30, 2025 |  |  | 2,604 |  |  | $ | 10.11 |  |  |  | 4.3 |  |  | $ | 4,600 |  |
| Stock options exercisable, September 30, 2025 |  |  | 1,705 |  |  | $ | 9.92 |  |  |  | 3.2 |  |  | $ | 2,332 |  |

[0001193125-25-264157:notes:94]
As of September 30, 2025, there was $0.7 million of unrecognized compensation expense related to stock options which will be recognized over the remaining weighted-average period of 0.4 years.

[0001193125-25-264157:notes:95]
[same as prior period, unchanged from 0000950170-25-102561:notes:82]

[0001193125-25-264157:notes:96]
[same as prior period, unchanged from 0000950170-25-102561:notes:83]

[0001193125-25-264157:notes:97]
The aggregate intrinsic value of stock options represents the total pre-tax intrinsic value (the difference between the Company's closing stock price on the last trading day of the quarter and the exercise price, multiplied by the number of in-the-money options) that would have been received by the option holders had all option holders exercised their options on September 30, 2025. The amount of aggregate intrinsic value was $4.6 million as of September 30, 2025, which will change based on the fair market value of the Company's stock. The total pre-tax intrinsic value of options exercised during the nine months ended September 30, 2025, and 2024 was $0.7 million and $34 thousand, respectively. During the three and nine months ended September 30, 2025 and 2024, 0.5 million and 0.1 million stock options vested, respectively.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001193125-25-264157:notes:98]
6. LONG TERM INVESTMENTS

[0001193125-25-264157:notes:99]
The Company has cash equivalents and investments which are held at fair value as follows:

[0001193125-25-264157:notes:100]
|  |  |  |  |  | Fair Value Measurements as of September 30, 2025 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket for IdenticalAssets (Level 1) |  |  | SignificantOtherObservableInputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds (1) |  | $ | 238 |  |  | $ | 238 |  |  | $ | — |  |  | $ | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities |  |  | 1,049 |  |  |  | 1,049 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 34,230 |  |  |  | 34,230 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 35,517 |  |  | $ | 35,517 |  |  | $ | — |  |  | $ | — |  |

[0001193125-25-264157:notes:101]
|  |  |  |  |  | Fair Value Measurements as of December 31, 2024 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket for IdenticalAssets (Level 1) |  |  | SignificantOtherObservableInputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds (1) |  | $ | 5,538 |  |  | $ | 5,538 |  |  | $ | — |  |  | $ | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities |  |  | 1,068 |  |  |  | 1,068 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 30,991 |  |  |  | 30,991 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 37,597 |  |  | $ | 37,597 |  |  | $ | — |  |  | $ | — |  |

[0001193125-25-264157:notes:102]
(1)
The money market fund balances of $0.2 million and $5.5 million as of September 30, 2025 and December 31, 2024, respectively, are included in cash and cash equivalents on the balance sheet.

[0001193125-25-264157:notes:103]
Market prices are obtained from a variety of industry standard data providers, large financial institutions and other third-party sources. These multiple market prices are used as inputs into a distribution-curve-based algorithm to determine the daily market value of each security.

[0001193125-25-264157:notes:104]
U.S. GAAP establishes a three-level valuation hierarchy based upon observable and unobservable inputs for fair value measurement of financial instruments:

[0001193125-25-264157:notes:105]
 Level 1 – Observable outputs; values based on unadjusted quoted prices for identical assets or liabilities in an active market;

[0001193125-25-264157:notes:106]
 Level 2 – Significant inputs that are observable; values based on quoted prices in markets that are not active or model inputs that are observable either directly or indirectly; and

[0001193125-25-264157:notes:107]
 Level 3 – Significant unobservable inputs; values based on prices or valuation techniques that require inputs that are both unobservable and significant to the overall fair value measurement. These inputs could include information supplied by investees.


## us-gaap:InventoryDisclosureTextBlock

[0001193125-25-264157:notes:108]
7. INVENTORY, NET

[0001193125-25-264157:notes:109]
[same as prior period, unchanged from 0000950170-25-102561:notes:96]

[0001193125-25-264157:notes:110]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | September 30, 2025 |  |  | December 31, 2024 |  |
| Raw materials |  | $ | 79,327 |  |  | $ | 106,384 |  |
| Work in process |  |  | 11,524 |  |  |  | 9,724 |  |
| Finished goods |  |  | 132,904 |  |  |  | 145,449 |  |
| Total inventory, net |  | $ | 223,755 |  |  | $ | 261,557 |  |

[0001193125-25-264157:notes:111]
[same as prior period, unchanged from 0000950170-25-102561:notes:98]

[0001193125-25-264157:notes:112]
During the twelve months ended December 31, 2024, the Company recorded an inventory write-down of $8.6 million, as a result of a strategy shift which included discontinuance of certain product lines in connection with the Business Efficiency Program of which $4.1 million relates to inventory write-downs and $4.5 million relates to other charges, all of which are included in cost of revenue in the Condensed Consolidated Statements of Loss for the nine months ended September 30, 2024.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001193125-25-264157:notes:113]
8. PROPERTY, PLANT AND EQUIPMENT, NET

[0001193125-25-264157:notes:114]
[same as prior period, unchanged from 0000950170-25-102561:notes:101]

[0001193125-25-264157:notes:115]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | September 30, 2025 |  |  | December 31, 2024 |  |
| Engineering and other equipment |  | $ | 200,593 |  |  | $ | 184,694 |  |
| Building |  |  | 52,549 |  |  |  | 50,871 |  |
| Computer hardware and software |  |  | 135,517 |  |  |  | 113,241 |  |
| Building and land improvements |  |  | 43,454 |  |  |  | 39,979 |  |
| Furniture and fixtures |  |  | 21,470 |  |  |  | 20,994 |  |
| Land |  |  | 3,072 |  |  |  | 2,989 |  |
| Total property, plant and equipment |  |  | 456,655 |  |  |  | 412,768 |  |
| Less: accumulated depreciation and amortization |  |  | (335,190 | ) |  |  | (306,314 | ) |
| Total property, plant and equipment, net |  | $ | 121,465 |  |  | $ | 106,454 |  |

[0001193125-25-264157:notes:116]
[same as prior period, unchanged from 0000950170-25-102561:notes:103]

[0001193125-25-264157:notes:117]
Depreciation and amortization expense was $7.9 million and $7.2 million for the three months ended September 30, 2025 and 2024, respectively, and $22.3 million and $21.2 million for the nine months ended September 30, 2025 and 2024, respectively, which is recorded in cost of revenue, selling, general and administrative expenses and research and development expenses in the Condensed Consolidated Statements of Loss.

[0001193125-25-264157:notes:118]
[same as prior period, unchanged from 0000950170-25-102561:notes:105]

[0001193125-25-264157:notes:119]
On December 31, 2024, the Company determined it met the held for sale criteria pursuant to ASC 360, "Impairment and Disposal of Long-Live Assets" on the Company's property located at the North and South Towers in its Huntsville, Alabama campus and ceased recording depreciation on the assets. The Company continues to assess the probability that the sale of its headquarters in Huntsville will occur and has determined it is probable of occurring in the next twelve months.

[0001193125-25-264157:notes:120]
The Company records assets held for sale at the lower of their carrying value or fair value. The total carrying value of assets held for sale was $11.9 million as of September 30, 2025 and December 31, 2024, respectively, and is separately recorded on the balance sheet.


## us-gaap:GoodwillDisclosureTextBlock

[0001193125-25-264157:notes:121]
. GOODWILL

[0001193125-25-264157:notes:122]
The changes in the carrying amount of goodwill for the nine months ended September 30, 2025 and the twelve months ended December 31, 2024, are as follows:

[0001193125-25-264157:notes:123]
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| As of December 31, 2023 |  | $ | 301,766 |  |  | $ | 56,384 |  |  | $ | 358,150 |  |
| Goodwill impairment |  |  | (295,298 | ) |  |  | — |  |  |  | (295,298 | ) |
| Foreign currency translation adjustments |  |  | (6,468 | ) |  |  | (3,466 | ) |  |  | (9,934 | ) |
| As of December 31, 2024 |  | $ | — |  |  | $ | 52,918 |  |  | $ | 52,918 |  |
| Foreign currency translation adjustments |  |  | — |  |  |  | 7,001 |  |  |  | 7,001 |  |
| As of September 30, 2025 |  | $ | — |  |  | $ | 59,919 |  |  | $ | 59,919 |  |

[0001193125-25-264157:notes:124]
Goodwill represents the excess purchase price over the fair value of net assets acquired. The Company performs its annual goodwill impairment test as of the first day of the fourth quarter. In addition, the Company performs an interim impairment assessment prior to our annual measurement date whenever events or changes in circumstances indicate that the carrying amount of such assets (or group of assets) may not be recoverable.

[0001193125-25-264157:notes:125]
No impairment of goodwill was recognized during the three and nine months ended September 30, 2025. No impairment of goodwill was recognized during the three months ended September 30, 2024. The Company determined upon its quantitative impairment assessment to recognize a goodwill impairment of $297.4 million, during the nine months ended September 30, 2024. As of September 30, 2025, accumulated goodwill impairment losses totaled $335.3 million.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001193125-25-264157:notes:126]
10. INTANGIBLE ASSETS, NET

[0001193125-25-264157:notes:127]
Intangible assets, net as of September 30, 2025, and December 31, 2024, consisted of the following:

[0001193125-25-264157:notes:128]
|  |  |  |  | As of September 30, 2025 |  |  | As of December 31, 2024 |  |
| (In thousands excluding years) | Weighted Average Useful Life(in years) |  |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Net Book Value |  |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Net Book Value |  |
| Customer relationships |  | 11.0 |  |  | $ | 56,199 |  |  | $ | (24,071 | ) |  | $ | 32,128 |  |  | $ | 51,165 |  |  | $ | (18,778 | ) |  | $ | 32,387 |  |
| Backlog |  | 1.7 |  |  |  | 61,016 |  |  |  | (61,016 | ) |  |  | — |  |  |  | 53,839 |  |  |  | (52,258 | ) |  |  | 1,581 |  |
| Developed technology |  | 7.7 |  |  |  | 420,813 |  |  |  | (152,913 | ) |  |  | 267,900 |  |  |  | 346,923 |  |  |  | (99,588 | ) |  |  | 247,335 |  |
| Licensed technology |  | 9.0 |  |  |  | 5,900 |  |  |  | (4,944 | ) |  |  | 956 |  |  |  | 5,900 |  |  |  | (4,452 | ) |  |  | 1,448 |  |
| Licensed agreements |  | 8.5 |  |  |  | 560 |  |  |  | (437 | ) |  |  | 123 |  |  |  | 560 |  |  |  | (407 | ) |  |  | 153 |  |
| Trade names |  | 2.8 |  |  |  | 31,564 |  |  |  | (30,390 | ) |  |  | 1,174 |  |  |  | 27,851 |  |  |  | (25,862 | ) |  |  | 1,989 |  |
| Total |  |  |  | $ | 576,052 |  |  | $ | (273,771 | ) |  | $ | 302,281 |  |  | $ | 486,238 |  |  | $ | (201,345 | ) |  | $ | 284,893 |  |

[0001193125-25-264157:notes:129]
No impairment losses related to intangible assets were recorded during the three and nine months ended September 30, 2025 and 2024.

[0001193125-25-264157:notes:130]
Amortization expense was $15.7 million and $16.1 million in the three months ended September 30, 2025 and 2024, respectively, and $46.4 million and $46.5 million in the nine months ended September 30, 2025 and 2024, respectively and was included in cost of revenue, selling, general and administrative expenses and research and development expenses in the Condensed Consolidated Statements of Loss.

[0001193125-25-264157:notes:131]
[same as prior period, unchanged from 0000950170-25-102561:notes:119]

[0001193125-25-264157:notes:132]
|  |  | As of |  |
| (In thousands) |  | September 30, 2025 |  |
| 2025 |  | $ | 16,609 |  |
| 2026 |  |  | 66,846 |  |
| 2027 |  |  | 61,589 |  |
| 2028 |  |  | 51,854 |  |
| 2029 |  |  | 46,164 |  |
| Thereafter |  |  | 59,219 |  |
| Total |  | $ | 302,281 |  |


## us-gaap:DebtDisclosureTextBlock

[0001193125-25-264157:notes:133]
11. CREDIT AGREEMENT

[0001193125-25-264157:notes:134]
The carrying value of the Company's non-current revolving credit facility was as follows:

[0001193125-25-264157:notes:135]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | September 30, 2025 |  |  | December 31, 2024 |  |
| Wells Fargo credit agreement |  | $ | 25,023 |  |  | $ | 189,576 |  |
| Total non-current revolving credit facility |  | $ | 25,023 |  |  | $ | 189,576 |  |

[0001193125-25-264157:notes:136]
Revolving Credit Agreement

[0001193125-25-264157:notes:137]
On July 18, 2022, ADTRAN, Inc., as the borrower ("U.S. Borrower"), and the Company entered into a credit agreement with a syndicate of banks, including Wells Fargo Bank, National Association, as administrative agent (“Administrative Agent”), and the other lenders named therein (the “Original Credit Agreement”), as amended by the First Amendment to Credit Agreement, dated August 9, 2023 (“Amendment No. 1”), the Second Amendment to Credit Agreement, dated January 16, 2024 (“Amendment No. 2”), the Third Amendment to Credit Agreement, dated March 12, 2024 (“Amendment No. 3”), the Fourth Amendment to Credit Amendment, dated June 4, 2024 among Adtran Networks (the "German Borrower") and the parties set forth above ("Amendment No. 4") and the Fifth Amendment to Credit Agreement and Waiver, dated May 6, 2025, among the German Borrower and the parties set forth above (“Amendment No. 5”; the Original Credit Agreement as amended by Amendment No. 1, Amendment No. 2. Amendment No. 3, Amendment No. 4 and Amendment No. 5, the “Existing Credit Agreement”).

[0001193125-25-264157:notes:138]
On September 16, 2025, the U.S. Borrower, the German Borrower, and the lenders party thereto, including the Administrative Agent, entered into the Sixth Amendment and Consent to Credit Agreement, dated September 16, 2025 (“Amendment No. 6”; the Existing Credit Agreement as amended by Amendment No. 6, the “Amended Credit Agreement”). Amendment No. 6, among other things, (i) provides for a consent from the lenders to the issuance by the Company of new unsecured convertible indebtedness in an amount not to exceed $230.0 million, notwithstanding the cap on the amount of Permitted Convertible Indebtedness (as defined in the Amended Credit Agreement) the Company is permitted to incur, (ii) requires that the net cash proceeds of the new unsecured convertible indebtedness be used to (a) repay outstanding revolving credit loans under the Amended Credit Agreement, (b) pay fees, costs, and expenses related to Amendment No. 6 and the issuance of the new unsecured convertible indebtedness and (c) cash collateralize the obligations of the Company and its subsidiaries under the Amended Credit Agreement (with such cash only being permitted to be withdrawn for the purpose of financing the purchase of additional outstanding shares of Equity Interests (as defined in the Amended Credit Agreement) of the German Borrower that were not owned by the Company and its subsidiaries as of August 9, 2023 pursuant to Section 5, paragraph 1 of the DPLTA), and (iii) after the prepayment contemplated in the foregoing clause (ii)(a) and the provision of cash collateral contemplated in the foregoing clause (ii)(c), amends provisions governing the Subline (as defined below) to provide that future prepayments in respect of borrowings under the Subline will no longer permanently reduce the commitments in respect of the Subline. As of September 30, 2025, the Company had $7.5 million of cash collateral which is permitted to be withdrawn for the purpose of financing the purchase of additional outstanding shares of Adtran Networks stock as defined in the Amended Credit Agreement.

[0001193125-25-264157:notes:139]
As of September 30, 2025, the Amended Credit Agreement provided for a secured revolving credit facility of up to $350.0 million of borrowings, $50.0 million of which is solely available to the German Borrower.

[0001193125-25-264157:notes:140]
As of September 30, 2025, the Company’s borrowings under the revolving line of credit were $25.0 million, of which all was borrowed under the Subline by the German Borrower. The credit facilities provided under the Amended Credit Agreement mature in July 2027,

[0001193125-25-264157:notes:141]
but the U.S. Borrower may request extensions subject to customary conditions. In addition, the U.S. Borrower may utilize up to $50.0 million of the $350.0 million total revolving facility for the issuance of letters of credit. As of September 30, 2025, the U.S. Borrower had a total of $5.8 million in letters of credit under the Amended Credit Agreement, leaving a net amount (after giving effect to the $25.0 million of outstanding borrowings described above) of $319.2 million available for future borrowings; however, as of September 30, 2025, the Company was limited to additional borrowings of $232.0 million based on debt covenant compliance metrics. Any future credit extensions under the Amended Credit Agreement are subject to customary conditions precedent. The proceeds of any loans may be used as described above, as well as for working capital and other general corporate purposes.

[0001193125-25-264157:notes:142]
Moreover, the Amended Credit Agreement provides for a sublimit under the existing $350.0 million revolving commitments in an aggregate amount of $50.0 million (“Subline”), which Subline is available for borrowings by the German Borrower. The existing swing line sublimit and letter of credit sublimit under the Amended Credit Agreement remain available to the U.S. Borrower (and not to the German Borrower). Otherwise, the loans under the Subline are subject to substantially the same terms and conditions under the Amended Credit Agreement (including with respect to the interest rate and maturity date) as the other existing revolving commitments.

[0001193125-25-264157:notes:143]
All U.S. borrowings under the Amended Credit Agreement bear interest at a rate tied to the Base Rate (as defined in the Amended Credit Agreement) or SOFR, at the Company’s option, and all E.U. borrowings bear interest at a rate tied to the Euro Interbank Offered Rate as administered by the European Money Markets Institute (or a comparable or successor administrator approved by the Administrative Agent), in each case plus applicable margins which vary based on the consolidated net leverage ratio of the Company and its subsidiaries as determined pursuant to the terms of the Amended Credit Agreement. Default interest is 2.00% per annum in excess of the rate otherwise applicable. As of September 30, 2025, the weighted average interest rate on our revolving credit agreements was 9.50%.

[0001193125-25-264157:notes:144]
The Company made certain representations and warranties to the lenders in the Amended Credit Agreement that are customary for credit arrangements of this type. The Company also agreed to maintain a Consolidated Total Net Leverage Ratio of 5.00x, a Consolidated Senior Secured Net Leverage Ratio of 3.25x (4.0x to 3.5x during a “Springing Covenant Period,” as defined below) and a Consolidated Fixed Charge Coverage Ratio of 1.25x (as such ratios are defined in the Amended Credit Agreement). A “Springing Covenant Event” occurs when at least sixty percent (60.0%) of the outstanding shares of Adtran Networks that were not owned by the Company and its subsidiaries as of August 9, 2023 have been tendered and purchased by the Company. Upon the occurrence of a Springing Covenant Event, the Company will enter a “Springing Covenant Period”, defined as the fiscal quarter in which a Springing Covenant Event occurs and the three (3) consecutive fiscal quarters thereafter. During a Springing Covenant Period, the Company’s leverage ratios are increased. In addition, the cash and cash equivalents of the credit parties must be at least $50.0 million and the cash and cash equivalents of the Company and its subsidiaries must be at least $70.0 million. As of September 30, 2025, the Company was in compliance with all covenants.

[0001193125-25-264157:notes:145]
The Amended Credit Agreement also contains customary events of default, such as misrepresentation and a default in the performance or observance of any covenant (subject to customary cure periods and materiality thresholds). Upon the occurrence and during the continuance of an event of default, the Administrative Agent is entitled to take various actions, including the acceleration of all amounts due under the Amended Credit Agreement.

[0001193125-25-264157:notes:146]
All obligations under the Amended Credit Agreement (including under the Subline) are guaranteed by the U.S. Borrower and certain subsidiaries of the U.S. Borrower (“Full Facility Guarantors”). To secure such guarantees, the U.S. Borrower and the Full Facility Guarantors have granted security interests in favor of the Administrative Agent over substantially all of their tangible and intangible assets, and the U.S. Borrower has granted mortgages in favor of the Administrative Agent over certain owned real estate assets. Certain of the German Borrower's subsidiaries (the “Subline Guarantors”) have also provided a guarantee solely of the obligations in respect of the Subline. Furthermore, to secure such guarantees, the German Borrower and the Subline Guarantors have granted security interests in favor of the Administrative Agent over substantially all of their tangible and intangible assets. Upon repayment in full and termination of the Subline, the guarantees by the Subline Guarantors and the liens granted by the German Borrower and the Subline Guarantors to secure obligations under the Subline will be released.


## us-gaap:LongTermDebtTextBlock

[0001193125-25-264157:notes:147]
12. CONVERTIBLE SENIOR NOTES AND CAPPED CALLS

[0001193125-25-264157:notes:148]
The outstanding principal and carrying value of the convertible senior notes were as follows:

[0001193125-25-264157:notes:149]
|  |  | As of |  |
| (In thousands) |  | September 30, 2025 |  |
| Convertible senior notes |  | $ | 201,250 |  |
| Less: unamortized debt issuance costs |  |  | (8,391 | ) |
| Non-current convertible senior notes |  | $ | 192,859 |  |

[0001193125-25-264157:notes:150]
The estimated fair value of the 2030 Notes was $226.3 million as of September 30, 2025. The estimated fair value of the 2030 Notes, Level 2 inputs of the valuation hierarchy, were determined based on the quoted bid prices of the 2030 Notes in an over-the-counter market on the last trading day of the reporting period.

[0001193125-25-264157:notes:151]
The effective interest rate of the 2030 Notes over their expected life is 4.70%. The following is a summary of interest expense for the 2030 Notes:

[0001193125-25-264157:notes:152]
|  |  | Three and Nine Months Ended |  |
| (In thousands) |  | September 30, 2025 |  |
| Contractual interest |  | $ | 227 |  |
| Amortization of issuance costs |  |  | 45 |  |
| Total interest expense |  | $ | 272 |  |

[0001193125-25-264157:notes:153]
On September 19, 2025, the Company issued $201.3 million principal amount of its 3.75% convertible senior notes due September 15, 2030. The 2030 Notes were issued pursuant to, and are governed by, an indenture (the “Indenture”), dated as of September 19, 2025, between the Company and U.S. Bank Trust Company, National Association, as trustee (the “Trustee”). The 2030 Notes are the Company’s senior, unsecured obligations and bear interest at a rate of 3.75% per year payable semi-annually in arrears on March 15 and September 15 of each year, beginning on March 15, 2026. Each $1,000 principal amount of the 2030 Notes will be convertible into 86.8206 shares of the Company’s common stock, which is equivalent to a conversion price of approximately $11.52 per share, subject to adjustment upon the occurrence of specified events. In addition, if certain corporate events that constitute a “make-whole fundamental change” (as defined in the Indenture) occur, then the conversion rate will, in certain circumstances, be increased for a specified period of time.

[0001193125-25-264157:notes:154]
The 2030 Notes are convertible at the option of the holders of the 2030 Notes before June 15, 2030, only under the following circumstances: (1) during any calendar quarter (and only during such calendar quarter) commencing after the calendar quarter ending on December 31, 2025, if the last reported sale price per share of the Company’s common stock exceeds 130% of the conversion price for each of at least 20 trading days, whether or not consecutive, during the 30 consecutive trading days ending on, and including, the last trading day of the immediately preceding calendar quarter; (2) during the five consecutive business days immediately after any 10 consecutive trading day period (such 10 consecutive trading day period, the “measurement period”) if the trading price per $1,000 principal amount of the 2030 Notes for each trading day of the measurement period was less than 98% of the product of the last reported sale price per share of our common stock on such trading day and the conversion rate on such trading day; (3) upon the occurrence of certain corporate events or distributions on the Company’s common stock; or (4) if the Company calls (or is deemed to have called) the 2030 Notes for redemption. From and after June 15, 2030, noteholders may convert their 2030 Notes at any time at their election until the close of business on the second scheduled trading day immediately before the maturity date. The Company will settle conversions by paying cash up to the aggregate principal amount of the 2030 Notes to be converted and paying or delivering, as applicable, cash, shares of its common stock or a combination of cash and shares of its common stock, at the Company’s election, in respect of the remainder, if any, of its conversion obligation in excess of the aggregate principal amount of the Notes being converted, based on the applicable conversion rate.

[0001193125-25-264157:notes:155]
The 2030 Notes will be redeemable, in whole or in part (subject to certain limitations described below), at the Company’s option at any time, and from time to time, on or after September 20, 2028 and on or before the 46th scheduled trading day immediately before the maturity date, but only if (i) the Notes are “Freely Tradable” (as defined in the Indenture) as of the date the Company sends the related redemption notice, and all accrued and unpaid additional interest, if any, has been paid in full as of the most recent interest payment date occurring on or before the date the Company sends the related redemption notice; and (ii) the last reported sale price per share of the Company’s common stock exceeds 130% of the conversion price on (1) each of at least 20 trading days, whether or not consecutive, during the 30 consecutive trading days ending on, and including, the trading day immediately before the date the Company sends the related redemption notice; and (2) the trading day immediately before the date the Company sends such redemption notice. However, the Company may not redeem less than all of the outstanding Notes unless at least $70.0 million aggregate principal amount of Notes are outstanding and not called for redemption as of the time the Company sends, and after giving effect to, the related redemption notice. The redemption price will be a cash amount equal to the principal amount of the Notes to be redeemed, plus accrued and unpaid interest, if any, to, but excluding, the redemption date. In addition, calling (or the deemed calling of) any Note for redemption will constitute a “make-whole fundamental change” with respect to that Note, in which case the conversion rate applicable to the conversion of that Note will be increased in certain circumstances if it is converted during the related redemption conversion period. No sinking fund is provided for the 2030 Notes, which means the Company is not required to redeem or retire the 2030 Notes periodically.

[0001193125-25-264157:notes:156]
If certain corporate events that constitute a “fundamental change” (as defined in the Indenture) occur, then, subject to a limited exception for certain cash mergers, noteholders may require the Company to repurchase their Notes at a cash repurchase price equal to the principal amount of the Notes to be repurchased, plus accrued and unpaid interest, if any, to, but excluding, the fundamental change repurchase date. The definition of “fundamental change” includes certain business combination transactions involving the Company and certain de-listing events with respect to the Company’s common stock.

[0001193125-25-264157:notes:157]
Capped Calls

[0001193125-25-264157:notes:158]
In connection with the pricing of the 2030 Notes and the exercise of the initial purchasers’ option to purchase additional 2030 Notes, the Company entered into privately negotiated capped call transactions with one of the initial purchasers of the 2030 Notes or its affiliate and certain other financial institutions pursuant to capped call confirmations (collectively, the “Capped Calls”). The premiums paid for the purchases of the Capped Calls were approximately $17.6 million. The Capped Calls have an initial strike price of approximately $11.52 per share, subject to certain adjustments substantially similar to those applicable to the corresponding 2030 Notes. The Capped

[0001193125-25-264157:notes:159]
Calls have an initial cap price of approximately $15.51 per share, subject to certain adjustments. The Capped Calls cover, subject to anti-dilution adjustments, approximately 17.5 million shares of the Company’s common stock.

[0001193125-25-264157:notes:160]
The Capped Calls are generally expected to reduce potential dilution to the Company’s common stock and/or offset any cash payments that the Company is required to make in excess of the principal amount of any converted 2030 Notes, with such reduction and/or offset subject to a cap, based on the cap price of the Capped Calls.

[0001193125-25-264157:notes:161]
The Capped Calls are separate transactions and are not part of the terms of the 2030 Notes. The Capped Calls do not meet the criteria for separate accounting as a derivative as they are indexed to the Company's stock and meet the requirements to be classified in equity and, as such, are not remeasured each reporting period. The premiums paid for the Capped Calls were included as a net reduction to additional paid-in capital within stockholders’ equity during the quarter ended September 30, 2025.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001193125-25-264157:notes:162]
13. EMPLOYEE BENEFIT PLANS

[0001193125-25-264157:notes:163]
[same as prior period, unchanged from 0000950170-25-102561:notes:132]

[0001193125-25-264157:notes:164]
We maintain a defined benefit pension plan covering employees in certain foreign countries. The net amounts of the unfunded pension liability as of September 30, 2025 and December 31, 2024 were as follows:

[0001193125-25-264157:notes:165]
|  |  |  |  | As of |  |  | As of |  |
| (In thousands) |  | Balance Sheet Location |  | September 30, 2025 |  |  | December 31, 2024 |  |
| Non-current pension asset |  | Other non-current assets |  | $ | 585 |  |  | $ | 517 |  |
| Current pension liability |  | Accrued wages and benefits |  |  | (344 | ) |  |  | (303 | ) |
| Non-current pension liability |  | Non-current pension liability |  |  | (9,725 | ) |  |  | (8,983 | ) |
| Net pension liability |  |  |  | $ | (9,484 | ) |  | $ | (8,769 | ) |

[0001193125-25-264157:notes:166]
[same as prior period, unchanged from 0000950170-25-102561:notes:135]

[0001193125-25-264157:notes:167]
[same as prior period, unchanged from 0000950170-25-102561:notes:136]

[0001193125-25-264157:notes:168]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2025 |  |  | 2024 |  |  | 2025 |  |  | 2024 |  |
| Service cost |  | $ | 434 |  |  | $ | 340 |  |  | $ | 1,244 |  |  | $ | 1,013 |  |
| Interest cost |  |  | 542 |  |  |  | 286 |  |  |  | 1,553 |  |  |  | 852 |  |
| Expected return on plan assets |  |  | (655 | ) |  |  | (360 | ) |  |  | (1,878 | ) |  |  | (1,074 | ) |
| Amortization of actuarial losses |  |  | 12 |  |  |  | 2 |  |  |  | 35 |  |  |  | 7 |  |
| Net periodic pension cost |  | $ | 333 |  |  | $ | 268 |  |  | $ | 954 |  |  | $ | 798 |  |

[0001193125-25-264157:notes:169]
The components of net periodic pension cost, other than the service cost component, are included in other income (expense), net in the Condensed Consolidated Statements of Loss. Service cost is included in cost of revenue, selling, general and administrative expenses and research and development expenses in the Condensed Consolidated Statements of Loss. The Company made cash contributions to the defined benefit pension plans totaling $3.0 million during the nine months ended September 30, 2025 and 2024, respectively. Contributions to the defined benefit pension plans for the remainder of 2025 will be limited to benefit payments to retirees which are paid out of the operating cash flows of the Company and are expected to be approximately $0.4 million.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001193125-25-264157:notes:170]
14. EQUITY

[0001193125-25-264157:notes:171]
[same as prior period, unchanged from 0000950170-25-102561:notes:140]

[0001193125-25-264157:notes:172]
[same as prior period, unchanged from 0000950170-25-102561:notes:141]

[0001193125-25-264157:notes:173]
|  |  | Three Months Ended September 30, 2025 |  |
| (In thousands) |  | Unrealized(Losses) GainsonAvailable-for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Translation Adjustments |  |  | ASU 2018-02 Adoption |  |  | Total |  |
| Balance as of June 30, 2025 |  | $ | (382 | ) |  | $ | (628 | ) |  | $ | 78,980 |  |  | $ | 385 |  |  | $ | 78,355 |  |
| Other comprehensive income (loss) before reclassifications |  |  | 19 |  |  |  | — |  |  |  | (3,694 | ) |  |  | — |  |  |  | (3,675 | ) |
| Amounts reclassified from accumulated other comprehensive loss |  |  | (19 | ) |  |  | (6 | ) |  |  | — |  |  |  | — |  |  |  | (25 | ) |
| Net current period other comprehensive loss |  |  | — |  |  |  | (6 | ) |  |  | (3,694 | ) |  |  | — |  |  |  | (3,700 | ) |
| Balance as of September 30, 2025 |  | $ | (382 | ) |  | $ | (634 | ) |  | $ | 75,286 |  |  | $ | 385 |  |  | $ | 74,655 |  |

[0001193125-25-264157:notes:174]
|  |  | Three Months Ended September 30, 2024 |  |
| (In thousands) |  | Unrealized(Losses) GainsonAvailable-for-Sale Securities |  |  | DefinedBenefit Plan Adjustments |  |  | Foreign Currency Translation Adjustments |  |  | ASU 2018-02 Adoption |  |  | Total |  |
| Balance as of June 30, 2024 |  | $ | (382 | ) |  | $ | (2,573 | ) |  | $ | 30,885 |  |  | $ | 385 |  |  | $ | 28,315 |  |
| Other comprehensive (loss) income before reclassifications |  |  | (10 | ) |  |  | — |  |  |  | 18,802 |  |  |  | — |  |  |  | 18,792 |  |
| Amounts reclassified from accumulated other comprehensive income |  |  | 10 |  |  |  | 109 |  |  |  | — |  |  |  | — |  |  |  | 119 |  |
| Net current period other comprehensive income |  |  | — |  |  |  | 109 |  |  |  | 18,802 |  |  |  | — |  |  |  | 18,911 |  |
| Balance as of September 30, 2024 (Restated) |  | $ | (382 | ) |  | $ | (2,464 | ) |  | $ | 49,687 |  |  | $ | 385 |  |  | $ | 47,226 |  |

[0001193125-25-264157:notes:175]
|  |  | Nine Months Ended September 30, 2025 |  |
| (In thousands) |  | UnrealizedGains (Losses)onAvailable-for-SaleSecurities |  |  | DefinedBenefit Plan Adjustments |  |  | Foreign Currency Translation Adjustments |  |  | ASU 2018-02 Adoption |  |  | Total |  |
| Balance as of December 31, 2024 |  | $ | (382 | ) |  | $ | (1,027 | ) |  | $ | 12,278 |  |  | $ | 385 |  |  | $ | 11,254 |  |
| Other comprehensive income before reclassifications |  |  | 39 |  |  |  | — |  |  |  | 63,008 |  |  |  | — |  |  |  | 63,047 |  |
| Amounts reclassified from accumulated other comprehensive (loss) income |  |  | (39 | ) |  |  | 393 |  |  |  | — |  |  |  | — |  |  |  | 354 |  |
| Net current period other comprehensive income |  |  | — |  |  |  | 393 |  |  |  | 63,008 |  |  |  | — |  |  |  | 63,401 |  |
| Balance as of September 30, 2025 |  | $ | (382 | ) |  | $ | (634 | ) |  | $ | 75,286 |  |  | $ | 385 |  |  | $ | 74,655 |  |

[0001193125-25-264157:notes:176]
|  |  | Nine Months Ended September 30, 2024 |  |
| (In thousands) |  | UnrealizedGains (Losses) on Available-for-Sale Securities |  |  | DefinedBenefit Plan Adjustments |  |  | Foreign Currency Translation Adjustments |  |  | ASU 2018-02 Adoption |  |  | Total |  |
| Balance as of December 31, 2023 |  | $ | (382 | ) |  | $ | (2,506 | ) |  | $ | 50,033 |  |  | $ | 385 |  |  | $ | 47,530 |  |
| Other comprehensive loss before reclassifications |  |  | (134 | ) |  |  | — |  |  |  | (346 | ) |  |  | — |  |  |  | (480 | ) |
| Amounts reclassified from accumulated other comprehensive income |  |  | 134 |  |  |  | 42 |  |  |  | — |  |  |  | — |  |  |  | 176 |  |
| Net current period other comprehensive income (loss) |  |  | — |  |  |  | 42 |  |  |  | (346 | ) |  |  | — |  |  |  | (304 | ) |
| Balance as of September 30, 2024 (Restated) |  | $ | (382 | ) |  | $ | (2,464 | ) |  | $ | 49,687 |  |  | $ | 385 |  |  | $ | 47,226 |  |

[0001193125-25-264157:notes:177]
[same as prior period, unchanged from 0000950170-25-102561:notes:146]

[0001193125-25-264157:notes:178]
|  |  | Three Months Ended September 30, 2025 |
| (In thousands) |  | Amount ReclassifiedfromAccumulated Other Comprehensive Income |  |  | Affected Line Item in theStatement Where NetLoss Is Presented |
| Unrealized gain on available-for-sale securities: |  |  |  |  |  |
| Net realized loss on sales of securities |  | $ | (26 | ) |  | Net investment gain |
| Defined benefit plan adjustments – actuarial loss |  |  | (9 | ) |  | Other income (expense) |
| Total reclassifications for the period, before tax |  |  | (35 | ) |  |  |
| Tax benefit |  |  | 10 |  |  |  |
| Total reclassifications for the period, net of tax |  | $ | (25 | ) |  |  |

[0001193125-25-264157:notes:179]
|  |  | Three Months Ended September 30, 2024 |
| (In thousands) |  | Amount ReclassifiedfromAccumulated Other Comprehensive Income |  |  | Affected Line Item in the Statement Where Net Loss Is Presented |
| Unrealized gain on available-for-sale securities: |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 14 |  |  | Net investment gain |
| Defined benefit plan adjustments – actuarial gain |  |  | 158 |  |  | Other income (expense) |
| Total reclassifications for the period, before tax |  |  | 172 |  |  |  |
| Tax expense |  |  | (53 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 119 |  |  |  |

[0001193125-25-264157:notes:180]
|  |  | Nine Months Ended September 30, 2025 |
| (In thousands) |  | Amount ReclassifiedfromAccumulated Other Comprehensive Income |  |  | Affected Line Item in the Statement Where Net LossIs Presented |
| Unrealized gain (loss) on available-for-sale securities: |  |  |  |  |  |
| Net realized loss on sales of securities |  | $ | (53 | ) |  | Net investment gain |
| Defined benefit plan adjustments – actuarial gain |  |  | 570 |  |  | Other income (expense) |
| Total reclassifications for the period, before tax |  |  | 517 |  |  |  |
| Tax expense |  |  | (163 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 354 |  |  |  |

[0001193125-25-264157:notes:181]
|  |  | Nine Months Ended September 30, 2024 |
| (In thousands) |  | Amount ReclassifiedfromAccumulated Other Comprehensive Income |  |  | Affected Line Item in the Statement Where Net LossIs Presented |
| Unrealized gain (loss) on available-for-sale securities: |  |  |  |  |  |
| Net realized loss on sales of securities |  | $ | 181 |  |  | Net investment gain |
| Defined benefit plan adjustments – actuarial loss |  |  | 61 |  |  | Other income (expense) |
| Total reclassifications for the period, before tax |  |  | 242 |  |  |  |
| Tax benefit |  |  | (66 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 176 |  |  |  |

[0001193125-25-264157:notes:182]
The following table presents the tax effects related to the change in each component of other comprehensive (loss) income:

[0001193125-25-264157:notes:183]
|  |  | Three Months Ended |  |  | Three Months Ended |  |
|  |  | September 30, 2025 |  |  | September 30, 2024(Restated) |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense)Benefit |  |  | Net-of-Tax Amount |  |  | Before-Tax Amount |  |  | Tax(Expense)Benefit |  |  | Net-of-TaxAmount |  |
| Unrealized gain (loss) on available-for-sale securities |  | $ | 26 |  |  | $ | (7 | ) |  | $ | 19 |  |  | $ | (14 | ) |  | $ | 4 |  |  |  | (10 | ) |
| Reclassification adjustment for amounts related to available-for-sale investments included in net (loss) gain |  |  | (26 | ) |  |  | 7 |  |  |  | (19 | ) |  |  | 14 |  |  |  | (4 | ) |  |  | 10 |  |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net (loss) gain |  |  | (9 | ) |  |  | 3 |  |  |  | (6 | ) |  |  | 158 |  |  |  | (49 | ) |  |  | 109 |  |
| Foreign currency translation adjustments |  |  | (3,694 | ) |  |  | — |  |  |  | (3,694 | ) |  |  | 18,802 |  |  |  |  |  |  | 18,802 |  |
| Total Other Comprehensive (Loss) Income |  | $ | (3,703 | ) |  | $ | 3 |  |  | $ | (3,700 | ) |  | $ | 18,960 |  |  | $ | (49 | ) |  | $ | 18,911 |  |

[0001193125-25-264157:notes:184]
|  |  | Nine Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, 2025 |  |  | September 30, 2024(Restated) |  |
| (In thousands) |  | Before-TaxAmount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |  | Before-Tax Amount |  |  | Tax (Expense)Benefit |  |  | Net-of-Tax Amount |  |
| Unrealized gain (loss) on available-for-sale securities |  | $ | 53 |  |  | $ | (14 | ) |  | $ | 39 |  |  | $ | (181 | ) |  | $ | 47 |  |  | $ | (134 | ) |
| Reclassification adjustment for amounts related to available-for-sale investments included in net (loss) gain |  |  | (53 | ) |  |  | 14 |  |  |  | (39 | ) |  |  | 181 |  |  |  | (47 | ) |  |  | 134 |  |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net gain |  |  | 570 |  |  |  | (177 | ) |  |  | 393 |  |  |  | 61 |  |  |  | (19 | ) |  |  | 42 |  |
| Foreign currency translation adjustments |  |  | 63,008 |  |  |  | — |  |  |  | 63,008 |  |  |  | (346 | ) |  |  | — |  |  |  | (346 | ) |
| Total Other Comprehensive Income (Loss) |  | $ | 63,578 |  |  | $ | (177 | ) |  | $ | 63,401 |  |  | $ | (285 | ) |  | $ | (19 | ) |  | $ | (304 | ) |


## us-gaap:RedeemableNoncontrollingInterestTableTextBlock

[0001193125-25-264157:notes:185]
The following table summarizes the RNCI activity for the nine months ended September 30, 2025 and for the year ended December 31, 2024:

[0001193125-25-264157:notes:186]
|  |  | Nine Months Ended |  |  | For the Year Ended |  |  |
| (In thousands) |  | September 30, 2025 |  |  | December 31, 2024 |  |  |
| Balance at beginning of period |  | $ | 422,943 |  |  | $ | 443,327 |  |  |
| Redemption of redeemable non-controlling interest |  |  | (20,855 | ) |  |  | (20,384 | ) |  |
| Net income attributable to redeemable non-controlling interests |  |  | 7,096 |  |  |  | 9,824 |  |  |
| Annual recurring compensation earned |  |  | (7,096 | ) |  |  | (9,824 | ) |  |
| Balance at end of period |  | $ | 402,088 |  |  | $ | 422,943 |  |  |


## us-gaap:EarningsPerShareTextBlock

[0001193125-25-264157:notes:187]
16. LOSS PER SHARE

[0001193125-25-264157:notes:188]
Basic net loss per share is computed by dividing net income by basic weighted-average shares outstanding during the period. Diluted net income per share is computed by dividing net income by diluted weighted-average shares outstanding during the period giving effect to all potentially dilutive securities to the extent they are dilutive. We compute the dilutive effect of shares issuable upon conversion of our 2030 notes using the if-converted method and equity awards under our employee equity incentive plans using the treasury stock method.

[0001193125-25-264157:notes:189]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands, except per share amounts) |  | 2025 |  |  | 2024 |  |  | 2025 |  |  | 2024 |  |
|  |  |  |  |  | (Restated) |  |  |  |  |  | (Restated) |  |
| Numerator |  |  |  |  |  |  |  |  |  |  |  |  |
| Net loss attributable to ADTRAN Holdings, Inc. |  | $ | (10,262 | ) |  | $ | (33,348 | ) |  | $ | (42,060 | ) |  | $ | (413,780 | ) |
| Effect of redemption of RNCI |  |  | 519 |  |  |  | 2,976 |  |  |  | 2,010 |  |  |  | 2,976 |  |
| Net loss attributable to ADTRAN Holdings, Inc. common stockholders |  | $ | (9,743 | ) |  | $ | (30,372 | ) |  | $ | (40,050 | ) |  | $ | (410,804 | ) |
| Denominator |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average number of shares – basic |  |  | 79,803 |  |  |  | 78,952 |  |  |  | 79,696 |  |  |  | 78,873 |  |
| Weighted average number of shares – diluted |  |  | 79,803 |  |  |  | 78,952 |  |  |  | 79,696 |  |  |  | 78,873 |  |
| Loss per share attributable to ADTRAN Holdings, Inc. – basic |  | $ | (0.12 | ) |  | $ | (0.38 | ) |  | $ | (0.50 | ) |  | $ | (5.21 | ) |
| Loss per share attributable to ADTRAN Holdings, Inc. – diluted |  | $ | (0.12 | ) |  | $ | (0.38 | ) |  | $ | (0.50 | ) |  | $ | (5.21 | ) |

[0001193125-25-264157:notes:190]
The following potentially dilutive shares were excluded from the calculation of the diluted weighted average number of shares outstanding as the effect would have been anti-dilutive:

[0001193125-25-264157:notes:191]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2025 |  |  | 2024 |  |  | 2025 |  |  | 2024 |  |
| Convertible senior notes |  |  | 2,089 |  |  |  | — |  |  |  | 704 |  |  |  | — |  |
| Stock options |  |  | 814 |  |  |  | 4,006 |  |  |  | 921 |  |  |  | 4,163 |  |
| PSUs, RSUs and restricted stock |  |  | 967 |  |  |  | 921 |  |  |  | 913 |  |  |  | 1,136 |  |

[0001193125-25-264157:notes:192]
In connection with the offering of the 2030 Notes, the Company entered into Capped Calls which are intended to reduce or offset the potential dilution from shares of common stock issued upon conversion. The impact of the Capped Calls is not included when calculating potentially dilutive shares since their effect is anti-dilutive. See Note 12, Convertible Senior Notes and Capped Calls for additional information.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-25-264157:notes:193]
17. SEGMENT INFORMATION

[0001193125-25-264157:notes:194]
[same as prior period, unchanged from 0000950170-25-102561:notes:163]

[0001193125-25-264157:notes:195]
[same as prior period, unchanged from 0000950170-25-102561:notes:164]

[0001193125-25-264157:notes:196]
The Services & Support segment offers a comprehensive portfolio of network design, implementation, maintenance and cloud-hosted services supporting its Subscriber, Access & Aggregation, and Optical Networking Solutions. These services assist operators in the deployment of multi-vendor networks while reducing their cost to maintain these networks. The cloud-hosted services include a suite of SaaS applications under the Company's Mosaic One platform that manages end-to-end network and service optimization for both fiber access infrastructure and mesh Wi-Fi connectivity. The Company backs these services with a global support organization that offers on-site and off-site support services with varying service level agreements.

[0001193125-25-264157:notes:197]
The performance of these segments is evaluated based on revenue, gross profit and gross margin; therefore, selling, general and administrative expenses, research and development expenses, interest and dividend income, interest expense, net investment gain, other (expense) income, net and income tax (expense) benefit are reported on a consolidated basis only. There is no inter-segment revenue. Asset information by reportable segment is not produced and, therefore, is not reported.

[0001193125-25-264157:notes:198]
[same as prior period, unchanged from 0000950170-25-102561:notes:167]

[0001193125-25-264157:notes:199]
|  |  | Three Months Ended |  |
|  |  | September 30, 2025 |  |  | September 30, 2024 |  |
| (In thousands) |  | Revenue |  |  | Cost of Revenue |  |  | Gross Profit |  |  | Revenue |  |  | Cost of Revenue |  |  | Gross Profit |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  | (Restated) |  |  | (Restated) |  |
| Network Solutions |  | $ | 232,543 |  |  | $ | 153,107 |  |  | $ | 79,436 |  |  | $ | 181,488 |  |  | $ | 127,992 |  |  | $ | 53,496 |  |
| Services & Support |  |  | 46,892 |  |  |  | 19,202 |  |  |  | 27,690 |  |  |  | 46,216 |  |  |  | 16,678 |  |  |  | 29,538 |  |
| Total |  | $ | 279,435 |  |  | $ | 172,309 |  |  | $ | 107,126 |  |  | $ | 227,704 |  |  | $ | 144,670 |  |  | $ | 83,034 |  |

[0001193125-25-264157:notes:200]
|  |  | Nine Months Ended |  |
|  |  | September 30, 2025 |  |  | September 30, 2024 |  |
| (In thousands) |  | Revenue |  |  | Cost of Revenue |  |  | Gross Profit |  |  | Revenue |  |  | Cost of Revenue |  |  | Gross Profit |  |
|  |  |  |  |  |  |  |  |  |  |  |  |  |  | (Restated) |  |  | (Restated) |  |
| Network Solutions |  | $ | 654,258 |  |  | $ | 434,669 |  |  | $ | 219,589 |  |  | $ | 541,955 |  |  | $ | 389,956 |  |  | $ | 151,999 |  |
| Services & Support |  |  | 137,989 |  |  |  | 56,352 |  |  |  | 81,637 |  |  |  | 137,913 |  |  |  | 55,304 |  |  |  | 82,609 |  |
| Total |  | $ | 792,247 |  |  | $ | 491,021 |  |  | $ | 301,226 |  |  | $ | 679,868 |  |  | $ | 445,260 |  |  | $ | 234,608 |  |

[0001193125-25-264157:notes:201]
For the three months ended September 30, 2025 and 2024, $4.0 million and $2.9 million, respectively, of depreciation and amortization expense was included in gross profit for our Network Solutions segment. For the nine months ended September 30, 2025 and 2024, $10.7 million and $7.4 million, respectively, of depreciation and amortization expense was included in gross profit for our Network Solutions segment. For the three months ended September 30, 2025 and 2024, $0.4 million and $0.1 million, respectively, of depreciation and amortization expense was included in gross profit for our Services & Support segment. For the nine months ended September 30, 2025 and 2024, $1.2 million and $0.2 million, respectively, of depreciation and amortization expense was included in gross profit for our Services & Support segment.

[0001193125-25-264157:notes:202]
[same as prior period, unchanged from 0000950170-25-102561:notes:171]

[0001193125-25-264157:notes:203]
[same as prior period, unchanged from 0000950170-25-102561:notes:172]

[0001193125-25-264157:notes:204]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2025 |  |  | 2024 |  |  | 2025 |  |  | 2024 |  |
| United States |  | $ | 120,210 |  |  | $ | 102,527 |  |  | $ | 343,739 |  |  | $ | 293,420 |  |
| United Kingdom |  |  | 49,796 |  |  |  | 49,366 |  |  |  | 168,954 |  |  |  | 145,666 |  |
| Germany |  |  | 35,429 |  |  |  | 27,270 |  |  |  | 93,822 |  |  |  | 91,553 |  |
| Other international |  |  | 74,000 |  |  |  | 48,541 |  |  |  | 185,732 |  |  |  | 149,229 |  |
| Total |  | $ | 279,435 |  |  | $ | 227,704 |  |  | $ | 792,247 |  |  | $ | 679,868 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-25-264157:notes:205]
18. COMMITMENTS AND CONTINGENCIES

[0001193125-25-264157:notes:206]
Legal Matters

[0001193125-25-264157:notes:207]
From time to time, the Company is subject to or otherwise involved in various lawsuits, claims, investigations and legal proceedings that arise out of or are incidental to the conduct of our business (collectively, “Legal Matters”), including those relating to employment matters, patent rights, regulatory compliance matters, stockholder claims, and contractual and other commercial disputes. Such Legal Matters, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Additionally, an unfavorable outcome in a legal matter, including in a patent dispute, could require the Company to pay damages, entitle claimants to other relief, such as royalties, or could prevent the Company from selling some of its products in certain jurisdictions. The Company records an accrual for any Legal Matters that arise whenever it considers that it is probable that it is exposed to a loss contingency and the amount of the loss contingency can be reasonably estimated. Although the ultimate disposition of asserted claims cannot be predicted with certainty, it is our belief that the outcome of any such claims, either individually or on a combined basis, will not have a material adverse effect on our consolidated financial position.

[0001193125-25-264157:notes:208]
On August 4, 2025, we received a letter from the Atlanta regional office of the SEC in connection with a non-public, fact-finding inquiry, requesting that we voluntarily provide information regarding the internal investigation referenced in Note 1, “Summary of Significant Accounting Policies”. We intend to cooperate in response to the SEC’s inquiry. We cannot predict the timing or outcome of the inquiry.

[0001193125-25-264157:notes:209]
DPLTA Appraisal Proceedings

[0001193125-25-264157:notes:210]
In addition to such Legal Matters, the Company is a party to appraisal proceedings relating to the DPLTA which were originally filed with the Landgericht Meiningen (Meiningen Regional Court) on February 3, 2023. The DPLTA provides that Adtran Networks shareholders (other than the Company) be offered, at their election, (i) to put their Adtran Networks shares to the Company in exchange for compensation in cash of €17.21 per share, plus guaranteed interest or (ii) to remain Adtran Networks shareholders and receive recurring cash compensation of €0.52 per share for each full fiscal year of Adtran Networks. The appraisal proceedings, which were initiated by certain minority shareholders of Adtran Networks, challenge the adequacy of both forms of compensation. While the Company believes that the compensation offered in connection with the DPLTA is fair, it notes that German courts often adjudicate increases of the cash compensation to plaintiffs in varying amounts in connection with German appraisal proceedings. Therefore, the Company cannot rule out that the court or an appellate court may increase the cash compensation owed to the minority Adtran Networks shareholders. Given the stage of the appraisal proceedings, the Company is currently unable to predict the likely outcome or estimate the potential financial impact, if any, of the appraisal proceedings. If a ruling were to occur and be upheld upon appeal that required the Company to pay significant additional cash compensation to the Adtran Networks minority shareholders, there exists the possibility of a material adverse effect on our financial position and results of operations for the period in which the ruling occurs or future periods.

[0001193125-25-264157:notes:211]
DPLTA Exit and Recurring Compensation Costs and the Absorption of Adtran Network's Annual Net Loss

[0001193125-25-264157:notes:212]
Pursuant to the terms of the DPLTA, each Adtran Networks shareholder (other than the Company) has received an offer to elect either (1) to remain an Adtran Networks shareholder and receive from us an Annual Recurring Compensation payment, or (2) to receive Exit Compensation plus guaranteed interest. The guaranteed interest under the Exit Compensation is calculated from the effective date of the DPLTA to the date the shares are tendered, less any Annual Recurring Compensation paid. The guaranteed interest rate is 5.0% plus a variable component (according to the German Civil Code) that was 1.27% as of September 30, 2025. Assuming all the minority holders of currently outstanding Adtran Networks shares were to elect the second option, the Company would be obligated to make aggregate Exit Compensation payments, including guaranteed interest, of approximately €322.7 million or $378.7 million, based on an exchange rate as of September 30, 2025, and reflecting interest accrued through September 30, 2025, during the pendency of the appraisal proceedings discussed below. Shareholders electing the first option of Annual Recurring Compensation may later elect the second option. The opportunity for outside Adtran Networks shareholders to tender Adtran Networks shares in exchange for Exit Compensation had been scheduled to expire on March 16, 2023. However, due to the appraisal proceedings that were initiated in 2023 in accordance with applicable German law, this time period for tendering shares has been extended pursuant to the German Stock Corporation Act (Aktiengesetz) and will end two months after the date on which a final decision in such appraisal proceedings has been published in the

[0001193125-25-264157:notes:213]
Federal Gazette (Bundesanzeiger). Following the court's decision on a procedural matter in the DPLTA appraisal proceedings on July 14, 2025, the proceeding for the trial on the merits of the DPLTA has recommenced. It is expected to take a minimum of 12 months for a ruling of the court on the merits and such ruling will most likely be appealed, which would be expected to take an additional 12-24 months to be resolved. Accordingly, the Company does not expect a final decision on the DPLTA appraisal proceedings to be rendered and published prior to 2027, and most likely not until 2028 or beyond.

[0001193125-25-264157:notes:214]
Our obligation to pay Annual Recurring Compensation under the DPLTA is a continuing payment obligation, which will amount to approximately €8.5 million (or $10.0 million based on the exchange rate as of September 30, 2025) per year assuming none of the minority Adtran Networks shareholders were to elect Exit Compensation. The foregoing amounts do not reflect any potential increase in payment obligations that we may have depending on the outcome of ongoing appraisal proceedings in Germany. The Annual Recurring Compensation is due on the third banking day following the ordinary general shareholders’ meeting of Adtran Networks for the respective preceding fiscal year (but in any event within eight months following expiration of the fiscal year). With respect to the 2024 fiscal year, Adtran Networks’ ordinary general shareholders' meeting occurred on June 27, 2025 and, therefore, the Annual Recurring Compensation was paid on July 1, 2025. During the three months ended September 30, 2025 and 2024, we accrued $2.5 million and $2.4 million, respectively, in Annual Recurring Compensation. During the nine months ended September 30, 2025 and 2024, we accrued $7.5 million and $7.4 million, respectively, in Annual Recurring Compensation, which was reflected as an increase to retained deficit.

[0001193125-25-264157:notes:215]
For the three and nine months ended September 30, 2025, less than one thousand shares and approximately 0.9 million shares, respectively, of Adtran Networks stock were tendered to the Company. This resulted in total Exit Compensation payments of approximately €16.9 million, or $19.9 million based on the applicable exchange rates at the time of the transactions, being paid to Adtran Networks shareholders. For the three and nine months ended September 30, 2024, 0.8 million shares of Adtran Networks stock were tendered to the Company. This resulted in total Exit Compensation payments of approximately €15.7 million, or approximately $17.4 million, respectively, based on the applicable exchange rates at the time of the transactions, being paid to Adtran Networks shareholders.

[0001193125-25-264157:notes:216]
In addition, under the DPLTA, subject to certain limitations pursuant to applicable law and the specific terms of the DPLTA, (i) the Company is entitled to issue binding instructions to the management board of Adtran Networks, (ii) Adtran Networks will transfer its annual profit to the Company, subject to, among other things, the creation or dissolution of certain reserves, and (iii) the Company will absorb the annual net loss incurred by Adtran Networks. The Company’s payment obligation in satisfaction of the requirement that it absorb Adtran Networks’ annual net loss applies to the net loss generated by Adtran Networks in 2024, and it will apply to any net loss generated by Adtran Networks in 2025.

[0001193125-25-264157:notes:217]
Performance Bonds

[0001193125-25-264157:notes:218]
Certain contracts, customers and jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of September 30, 2025 and December 31, 2024, we had commitments related to these bonds totaling $18.0 million and $15.7 million, respectively, which expire at various dates through April 2029. In general, we would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which we believe is remote.

[0001193125-25-264157:notes:219]
Purchase Obligations

[0001193125-25-264157:notes:220]
The Company purchases components from a variety of suppliers and uses contract manufacturers to provide manufacturing services for our products. Our inventory purchase obligations are for product manufacturing requirements, as well as for commitments to suppliers to secure manufacturing capacity. Certain of our inventory purchase obligations with contract manufacturers and suppliers relate to arrangements to secure supply and pricing for certain product components for multi-year periods. As of September 30, 2025, purchase obligations totaled $211.2 million.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001193125-25-264157:notes:221]
19. RESTRUCTURING

[0001193125-25-264157:notes:222]
On November 6, 2023, due to the uncertainty around the then-current macroeconomic environment and its impact on customer spending levels, the Company’s management decided to implement a Business Efficiency Program targeting the reduction of ongoing operating expenses and focusing on capital efficiency. This included certain salary reductions, an early retirement program, a site consolidation plan to include lease impairments and the sale of owned real estate (including the sale of our headquarters in Huntsville), inventory write downs from product discontinuances, and the suspension of the quarterly dividend. The Business Efficiency Program was completed as of December 31, 2024.

[0001193125-25-264157:notes:223]
During the three and nine months ended September 30, 2024, we recognized $5.9 million and $40.6 million of costs related to the Business Efficiency Program, respectively. The costs recognized during the nine months ended September 30, 2024, included total other renegotiated charges and inventory write-down of $8.6 million as a result of a strategy shift which included discontinuance of certain items in connection with the Business Efficiency Program, of which, $4.1 million relates to inventory write-downs and $4.5 million relates to other charges, and are included in cost of revenue in the Condensed Consolidated Statements of Loss.

[0001193125-25-264157:notes:224]
A reconciliation of the beginning and ending restructuring liabilities, which is included in accrued wages and benefits and accounts payable as of September 30, 2025 and December 31, 2024, is as follows:

[0001193125-25-264157:notes:225]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
| (In thousands) |  | September 30, 2025 |  |  | September 30, 2025 |  |
| Balance at beginning of period |  | $ | 2,641 |  |  | $ | 10,336 |  |
| Less: Adjusted accrued costs |  |  | — |  |  |  | (284 | ) |
| Less: Amounts paid |  |  | (1,077 | ) |  |  | (8,488 | ) |
| Balance as of September 30, 2025 |  | $ | 1,564 |  |  | $ | 1,564 |  |

[0001193125-25-264157:notes:226]
[same as prior period, unchanged from 0000950170-25-102561:notes:194]

[0001193125-25-264157:notes:227]
Restructuring expenses included in the Condensed Consolidated Statements of Loss are for the three and nine months ended September 30, 2025 and 2024:

[0001193125-25-264157:notes:228]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2025 |  |  | 2024 |  |  | 2025 |  |  | 2024 |  |
| Network Solutions - Cost of revenue |  | $ | — |  |  | $ | 517 |  |  | $ | — |  |  | $ | 3,359 |  |
| Network Solutions - charges and inventory write-down |  |  | — |  |  |  | (328 | ) |  | $ | — |  |  |  | 8,597 |  |
| Services & Support - Cost of revenue |  |  | — |  |  |  | (182 | ) |  |  | — |  |  |  | 2,086 |  |
| Cost of revenue |  | $ | — |  |  | $ | 7 |  |  | $ | — |  |  | $ | 14,042 |  |
| Selling, general and administrative expenses |  |  | — |  |  |  | 2,681 |  |  |  | — |  |  |  | 7,980 |  |
| Research and development expenses |  |  | — |  |  |  | 3,248 |  |  |  | (284 | ) |  |  | 18,554 |  |
| Total restructuring expenses |  | $ | — |  |  | $ | 5,936 |  |  | $ | (284 | ) |  | $ | 40,576 |  |

[0001193125-25-264157:notes:229]
The following table represents the components of restructuring expenses by geographic area for the three and nine months ended September 30, 2025 and 2024:

[0001193125-25-264157:notes:230]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2025 |  |  | 2024 |  |  | 2025 |  |  | 2024 |  |
| United States |  | $ | — |  |  | $ | 1,208 |  |  | $ | — |  |  | $ | 17,495 |  |
| International |  |  | — |  |  |  | 4,728 |  |  |  | (284 | ) |  |  | 23,081 |  |
| Total restructuring expenses |  | $ | — |  |  | $ | 5,936 |  |  | $ | (284 | ) |  | $ | 40,576 |  |


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001193125-25-264157:notes:231]
20. RESTATEMENT OF QUARTERLY FINANCIAL INFORMATION

[0001193125-25-264157:notes:232]
As previously disclosed in our Form 10-K/A and as discussed in Note 1 “Summary of Significant Accounting Policies”, the following tables reflect the impact of errors and other previously identified immaterial errors to the specific line items presented in our previously reported (a) Condensed Consolidated Balance Sheets; (b) Condensed Consolidated Statements of Loss and Condensed Consolidated Statements of Comprehensive Income (Loss); (c) Condensed Consolidated Statements of Changes in Equity and; (d) Condensed Consolidated Statements of Cash Flows as of and for the nine months ended September 30, 2024.

[0001193125-25-264157:notes:233]
|  |  |  | As of September 30, 2024 |  |
|  | Adj Reference |  | As Reported |  |  | Adjustment |  |  | As Restated |  |
| ASSETS |  |  |  |  |  |  |  |  |  |  |
| Current Assets |  |  |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  |  | $ | 88,456 |  |  | $ | — |  |  | $ | 88,456 |  |
| Accounts receivable, less allowance for credit losses of $420 as of September 30, 2024 |  |  |  | 172,025 |  |  |  | — |  |  |  | 172,025 |  |
| Other receivables |  |  |  | 12,871 |  |  |  | — |  |  |  | 12,871 |  |
| Income tax receivable | ADJ 4 |  |  | 13,466 |  |  |  | — |  |  |  | 13,466 |  |
| Inventory, net | ADJ 3 |  |  | 282,926 |  |  |  | (6,608 | ) |  |  | 276,318 |  |
| Prepaid expenses and other current assets |  |  |  | 69,112 |  |  |  | (2,597 | ) |  |  | 66,515 |  |
| Total Current Assets |  |  |  | 638,856 |  |  |  | (9,205 | ) |  |  | 629,651 |  |
| Property, plant and equipment, net |  |  |  | 147,428 |  |  |  | 3,124 |  |  |  | 150,552 |  |
| Goodwill | ADJ 4 |  |  | 56,884 |  |  |  | — |  |  |  | 56,884 |  |
| Intangibles, net |  |  |  | 286,098 |  |  |  | — |  |  |  | 286,098 |  |
| Deferred tax assets | ADJ 4 |  |  | 25,697 |  |  |  | — |  |  |  | 25,697 |  |
| Other non-current assets |  |  |  | 86,677 |  |  |  | — |  |  |  | 86,677 |  |
| Long-term investments |  |  |  | 31,506 |  |  |  | — |  |  |  | 31,506 |  |
| Total Assets |  |  | $ | 1,273,146 |  |  | $ | (6,081 | ) |  | $ | 1,267,065 |  |
| LIABILITIES, REDEEMABLE NON-CONTROLLING INTEREST AND EQUITY |  |  |  |  |  |  |  |  |  |  |
| Current Liabilities |  |  |  |  |  |  |  |  |  |  |
| Accounts payable |  |  | $ | 173,354 |  |  | $ | — |  |  | $ | 173,354 |  |
| Unearned revenue |  |  |  | 54,615 |  |  |  | — |  |  |  | 54,615 |  |
| Accrued expenses and other liabilities | ADJ 1 |  |  | 34,482 |  |  |  | (1 | ) |  |  | 34,481 |  |
| Accrued wages and benefits |  |  |  | 40,366 |  |  |  | — |  |  |  | 40,366 |  |
| Income tax payable, net |  |  |  | 2,007 |  |  |  | 4,887 |  |  |  | 6,894 |  |
| Total Current Liabilities |  |  |  | 304,824 |  |  |  | 4,886 |  |  |  | 309,710 |  |
| Non-current revolving credit agreement outstanding |  |  |  | 189,849 |  |  |  | — |  |  |  | 189,849 |  |
| Deferred tax liabilities | ADJ 4 |  |  | 21,483 |  |  |  | (3,726 | ) |  |  | 17,757 |  |
| Non-current unearned revenue |  |  |  | 24,901 |  |  |  | — |  |  |  | 24,901 |  |
| Non-current pension liability |  |  |  | 12,149 |  |  |  | — |  |  |  | 12,149 |  |
| Deferred compensation liability |  |  |  | 32,046 |  |  |  | — |  |  |  | 32,046 |  |
| Non-current lease obligations |  |  |  | 25,635 |  |  |  | — |  |  |  | 25,635 |  |
| Other non-current liabilities |  |  |  | 26,489 |  |  |  | — |  |  |  | 26,489 |  |
| Total Liabilities |  |  |  | 637,376 |  |  |  | 1,160 |  |  |  | 638,536 |  |
| Commitments and contingencies (see Note 18) |  |  |  |  |  |  |  |  |  |  |
| Redeemable Non-Controlling Interest |  |  |  | 421,776 |  |  |  | 1,175 |  |  |  | 422,951 |  |
| Equity |  |  |  |  |  |  |  |  |  |  |
| Common stock, par value $0.01 per share; 200,000 shares authorized; 79,233 shares issued and 78,967 outstanding as of September 30, 2024 |  |  |  | 792 |  |  |  | — |  |  |  | 792 |  |
| Additional paid-in capital |  |  |  | 806,187 |  |  |  | (645 | ) |  |  | 805,542 |  |
| Accumulated other comprehensive income | ADJ 1, 3, 4 |  |  | 47,377 |  |  |  | (151 | ) |  |  | 47,226 |  |
| Retained deficit | ADJ 1, 3, 4 |  |  | (635,164 | ) |  |  | (7,620 | ) |  |  | (642,784 | ) |
| Treasury stock at cost: 266 shares as of September 30, 2024 |  |  |  | (5,198 | ) |  |  | — |  |  |  | (5,198 | ) |
| Total Equity |  |  |  | 213,994 |  |  |  | (8,416 | ) |  |  | 205,578 |  |
| Total Liabilities, Redeemable Non-Controlling Interest and Equity |  |  | $ | 1,273,146 |  |  | $ | (6,081 | ) |  | $ | 1,267,065 |  |

[0001193125-25-264157:notes:234]
|  |  |  | Three Months Ended September 30, 2024 |  |  | Nine Months Ended September 30, 2024 |  |
|  | Adj Reference |  | As Reported |  |  | Adjustment |  |  | As Restated |  |  | As Reported |  |  | Adjustment |  |  | As Restated |  |
| Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Network Solutions |  |  | $ | 181,488 |  |  | $ | — |  |  | $ | 181,488 |  |  | $ | 541,955 |  |  | $ | — |  |  | $ | 541,955 |  |
| Services & Support |  |  |  | 46,216 |  |  |  | — |  |  |  | 46,216 |  |  |  | 137,913 |  |  |  | — |  |  |  | 137,913 |  |
| Total Revenue |  |  |  | 227,704 |  |  |  | — |  |  |  | 227,704 |  |  |  | 679,868 |  |  |  | — |  |  |  | 679,868 |  |
| Cost of Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Network Solutions | ADJ 3 |  |  | 126,103 |  |  |  | 2,217 |  |  |  | 128,320 |  |  |  | 376,886 |  |  |  | 4,473 |  |  |  | 381,359 |  |
| Network Solutions - Inventory Write Down |  |  |  | (328 | ) |  |  | — |  |  |  | (328 | ) |  |  | 8,597 |  |  |  | — |  |  |  | 8,597 |  |
| Services & Support |  |  |  | 16,678 |  |  |  | — |  |  |  | 16,678 |  |  |  | 55,304 |  |  |  | — |  |  |  | 55,304 |  |
| Total Cost of Revenue |  |  |  | 142,453 |  |  |  | 2,217 |  |  |  | 144,670 |  |  |  | 440,787 |  |  |  | 4,473 |  |  |  | 445,260 |  |
| Gross Profit |  |  |  | 85,251 |  |  |  | (2,217 | ) |  |  | 83,034 |  |  |  | 239,081 |  |  |  | (4,473 | ) |  |  | 234,608 |  |
| Selling, general and administrative expenses |  |  |  | 57,621 |  |  |  | (71 | ) |  |  | 57,550 |  |  |  | 176,214 |  |  |  | (309 | ) |  |  | 175,905 |  |
| Research and development expenses |  |  |  | 51,614 |  |  |  | (37 | ) |  |  | 51,577 |  |  |  | 172,253 |  |  |  | (109 | ) |  |  | 172,144 |  |
| Goodwill impairment | ADJ 4 |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 292,583 |  |  |  | 4,770 |  |  |  | 297,353 |  |
| Operating Loss |  |  |  | (23,984 | ) |  |  | (2,109 | ) |  |  | (26,093 | ) |  |  | (401,969 | ) |  |  | (8,825 | ) |  |  | (410,794 | ) |
| Interest and dividend income |  |  |  | 664 |  |  |  | — |  |  |  | 664 |  |  |  | 1,427 |  |  |  | — |  |  |  | 1,427 |  |
| Interest expense |  |  |  | (5,679 | ) |  |  | — |  |  |  | (5,679 | ) |  |  | (17,183 | ) |  |  | — |  |  |  | (17,183 | ) |
| Net investment gain |  |  |  | 1,382 |  |  |  | — |  |  |  | 1,382 |  |  |  | 4,507 |  |  |  | — |  |  |  | 4,507 |  |
| Other (expense), net |  |  |  | (850 | ) |  |  | — |  |  |  | (850 | ) |  |  | (441 | ) |  |  | — |  |  |  | (441 | ) |
| Loss Before Income Taxes |  |  |  | (28,467 | ) |  |  | (2,109 | ) |  |  | (30,576 | ) |  |  | (413,659 | ) |  |  | (8,825 | ) |  |  | (422,484 | ) |
| Income tax (expense) benefit |  |  |  | (390 | ) |  |  | — |  |  |  | (390 | ) |  |  | 16,121 |  |  |  | — |  |  |  | 16,121 |  |
| Net Loss |  |  | $ | (28,857 | ) |  | $ | (2,109 | ) |  | $ | (30,966 | ) |  | $ | (397,538 | ) |  | $ | (8,825 | ) |  | $ | (406,363 | ) |
| Net Income attributable to non-controlling interest (1) |  |  |  | 2,382 |  |  |  | — |  |  |  | 2,382 |  |  |  | 7,417 |  |  |  | — |  |  |  | 7,417 |  |
| Net Loss attributable to ADTRAN Holdings, Inc. |  |  | $ | (31,239 | ) |  | $ | (2,109 | ) |  | $ | (33,348 | ) |  | $ | (404,955 | ) |  | $ | (8,825 | ) |  | $ | (413,780 | ) |
| Weighted average shares outstanding – basic |  |  |  | 78,952 |  |  |  | 78,952 |  |  |  | 78,952 |  |  |  | 78,873 |  |  |  | 78,873 |  |  |  | 78,873 |  |
| Weighted average shares outstanding – diluted |  |  |  | 78,952 |  |  |  | 78,952 |  |  |  | 78,952 |  |  |  | 78,873 |  |  |  | 78,873 |  |  |  | 78,873 |  |
| Loss per common share attributable to ADTRAN Holdings, Inc. – basic |  |  | $ | (0.36 | ) |  | $ | (0.02 | ) |  | $ | (0.38 | ) |  | $ | (5.10 | ) |  | $ | (0.11 | ) |  | $ | (5.21 | ) |
| Loss per common share attributable to ADTRAN Holdings, Inc. – diluted |  |  | $ | (0.36 | ) |  | $ | (0.02 | ) |  | $ | (0.38 | ) |  | $ | (5.10 | ) |  | $ | (0.11 | ) |  | $ | (5.21 | ) |
| Net Loss |  |  | $ | (28,857 | ) |  | $ | (2,109 | ) |  | $ | (30,966 | ) |  | $ | (397,538 | ) |  | $ | (8,825 | ) |  | $ | (406,363 | ) |
| Other Comprehensive Income (Loss), net of tax |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Defined benefit plan adjustments |  |  |  | 109 |  |  |  | — |  |  |  | 109 |  |  |  | 42 |  |  |  | — |  |  |  | 42 |  |
| Foreign currency translation gain (loss) | ADJ 1, 3, 4 |  |  | 18,988 |  |  |  | (186 | ) |  |  | 18,802 |  |  |  | (130 | ) |  |  | (281 | ) |  |  | (411 | ) |
| Other Comprehensive Income (Loss), net of tax |  |  |  | 19,097 |  |  |  | (186 | ) |  |  | 18,911 |  |  |  | (88 | ) |  |  | (281 | ) |  |  | (369 | ) |
| Comprehensive Loss, net of tax |  |  |  | (9,760 | ) |  |  | (2,295 | ) |  |  | (12,055 | ) |  |  | (397,626 | ) |  |  | (9,106 | ) |  |  | (406,732 | ) |
| Less: Comprehensive Income attributable to non-controlling interest |  |  |  | 2,382 |  |  |  | — |  |  |  | 2,382 |  |  |  | 7,417 |  |  |  | — |  |  |  | 7,417 |  |
| Comprehensive Loss attributable to ADTRAN Holdings, Inc., net of tax |  |  | $ | (12,142 | ) |  | $ | (2,295 | ) |  | $ | (14,437 | ) |  | $ | (405,043 | ) |  | $ | (9,106 | ) |  | $ | (414,149 | ) |

[0001193125-25-264157:notes:235]
|  |  | Retained Deficit |  |  | Accumulated Other Comprehensive Income |  |  | Additional paid-in capital |  |
| (In thousands) |  | As Reported |  |  | Adjustment |  |  | As Restated |  |  | As Reported |  |  | Adjustment |  |  | As Restated |  |  | As Reported |  |  | Adjustment |  |  | As Restated |  |
| Balance as of June 30, 2024 |  | $ | (606,656 | ) |  | $ | (5,511 | ) |  | $ | (612,167 | ) |  | $ | 28,280 |  |  | $ | 35 |  |  | $ | 28,315 |  |  | $ | 802,737 |  |  | $ | (850 | ) |  | $ | 801,887 |  |
| Net loss |  |  | (28,857 | ) |  |  | (2,109 | ) |  |  | (30,966 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Annual recurring compensation earned |  |  | (2,382 | ) |  |  | — |  |  |  | (2,382 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Other comprehensive income, net of tax |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 19,097 |  |  |  | (186 | ) |  |  | 18,911 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| ADTRAN RSUs and restricted stock vested |  |  | (245 | ) |  |  | — |  |  |  | (245 | ) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| ADTRAN stock-based compensation expense |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 3,623 |  |  |  | — |  |  |  | 3,623 |  |
| Redemption of redeemable non-controlling interest |  |  | 2,976 |  |  |  | — |  |  |  | 2,976 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Adtran Networks stock-based compensation expense |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 17 |  |  |  | 15 |  |  |  | 32 |  |
| Modification of stock options |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | (190 | ) |  |  | 190 |  |  |  | — |  |
| Balance as of September 30, 2024 |  | $ | (635,164 | ) |  | $ | (7,620 | ) |  | $ | (642,784 | ) |  | $ | 47,377 |  |  | $ | (151 | ) |  | $ | 47,226 |  |  | $ | 806,187 |  |  | $ | (645 | ) |  | $ | 805,542 |  |

[0001193125-25-264157:notes:236]
|  |  |  | Nine Months Ended September 30, 2024 |  |
|  | Adj Reference |  | As Reported |  |  | Adjustment |  |  | As Restated |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |  |  |
| Net Loss |  |  | $ | (397,538 | ) |  | $ | (8,825 | ) |  | $ | (406,363 | ) |
| Adjustments to reconcile net loss to net cash provided by operating activities: |  |  |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  |  | 68,421 |  |  |  | (527 | ) |  |  | 67,894 |  |
| Goodwill impairment | ADJ 4 |  |  | 292,583 |  |  |  | 4,770 |  |  |  | 297,353 |  |
| Amortization of debt issuance cost |  |  |  | 1,013 |  |  |  | — |  |  |  | 1,013 |  |
| Gain loss on investments |  |  |  | (4,238 | ) |  |  | — |  |  |  | (4,238 | ) |
| Net loss on disposal of property, plant and equipment |  |  |  | 203 |  |  |  | — |  |  |  | 203 |  |
| Stock-based compensation expense |  |  |  | 11,417 |  |  |  | 65 |  |  |  | 11,482 |  |
| Deferred income taxes |  |  |  | (13,399 | ) |  |  | — |  |  |  | (13,399 | ) |
| Inventory write down |  |  |  | 4,135 |  |  |  | — |  |  |  | 4,135 |  |
| Inventory reserves |  |  |  | 6,667 |  |  |  | — |  |  |  | 6,667 |  |
| Other, net |  |  |  | (267 | ) |  |  | — |  |  |  | (267 | ) |
| Change in operating assets and liabilities: |  |  |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  |  |  | 59,446 |  |  |  | — |  |  |  | 59,446 |  |
| Other receivables |  |  |  | 4,875 |  |  |  | — |  |  |  | 4,875 |  |
| Income taxes receivable |  |  |  | (5,682 | ) |  |  | 4,735 |  |  |  | (947 | ) |
| Inventory | ADJ 3 |  |  | 69,412 |  |  |  | 4,475 |  |  |  | 73,887 |  |
| Prepaid expenses, other current assets and other assets |  |  |  | (20,083 | ) |  |  | (2,081 | ) |  |  | (22,164 | ) |
| Accounts payable |  |  |  | 9,697 |  |  |  | — |  |  |  | 9,697 |  |
| Accrued expenses and other liabilities |  |  |  | 15,039 |  |  |  | (5 | ) |  |  | 15,034 |  |
| Income taxes payable |  |  |  | (3,175 | ) |  |  | — |  |  |  | (3,175 | ) |
| Net cash provided by operating activities |  |  |  | 98,526 |  |  |  | 2,607 |  |  |  | 101,133 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  |  | (28,514 | ) |  |  | (2,654 | ) |  |  | (31,168 | ) |
| Purchases of intangibles - developed technology |  |  |  | (19,669 | ) |  |  | — |  |  |  | (19,669 | ) |
| Proceeds from sales and maturities of available-for-sale investments |  |  |  | 1,195 |  |  |  | — |  |  |  | 1,195 |  |
| Purchases of available-for-sale investments |  |  |  | (195 | ) |  |  | — |  |  |  | (195 | ) |
| Proceeds from beneficial interests in securitized accounts receivable |  |  |  | 282 |  |  |  | — |  |  |  | 282 |  |
| Net cash used in investing activities |  |  |  | (46,901 | ) |  |  | (2,654 | ) |  |  | (49,555 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |  |  |
| Tax withholdings related to stock-based compensation settlements |  |  |  | (189 | ) |  |  | — |  |  |  | (189 | ) |
| Proceeds from stock option exercises |  |  |  | 219 |  |  |  | — |  |  |  | 219 |  |
| Proceeds from receivables purchase agreement |  |  |  | 68,556 |  |  |  | — |  |  |  | 68,556 |  |
| Repayments on receivables purchase agreement |  |  |  | (83,772 | ) |  |  | — |  |  |  | (83,772 | ) |
| Repayment of revolving credit agreements |  |  |  | (5,000 | ) |  |  | — |  |  |  | (5,000 | ) |
| Payment for redemption of redeemable non-controlling interest |  |  |  | (17,395 | ) |  |  | — |  |  |  | (17,395 | ) |
| Payment of annual recurring compensation to non-controlling interest |  |  |  | (10,084 | ) |  |  | — |  |  |  | (10,084 | ) |
| Payment of debt issuance cost |  |  |  | (1,994 | ) |  |  | — |  |  |  | (1,994 | ) |
| Net cash used in financing activities |  |  |  | (49,659 | ) |  |  | — |  |  |  | (49,659 | ) |
| Net increase in cash and cash equivalents |  |  |  | 1,966 |  |  |  | (47 | ) |  |  | 1,919 |  |
| Effect of exchange rate changes |  |  |  | (677 | ) |  |  | 47 |  |  |  | (630 | ) |
| Cash, cash equivalents and restricted cash, beginning of year |  |  |  | 87,167 |  |  |  | — |  |  |  | 87,167 |  |
| Cash, cash equivalents and restricted cash, end of year |  |  | $ | 88,456 |  |  | $ | — |  |  | $ | 88,456 |  |
| Supplemental disclosure of cash financing activities |  |  |  |  |  |  |  |  |  |  |
| Cash paid for interest |  |  | $ | 18,225 |  |  | $ | — |  |  | $ | 18,225 |  |
| Cash paid for income taxes, net of refunds |  |  | $ | 9,122 |  |  | $ | — |  |  | $ | 9,122 |  |
| Cash used in operating activities related to operating leases |  |  | $ | 7,380 |  |  | $ | — |  |  | $ | 7,380 |  |
| Supplemental disclosure of non-cash investing activities: |  |  |  |  |  |  |  |  |  |  |
| Right-of-use assets obtained in exchange for lease obligations |  |  | $ | 2,122 |  |  | $ | — |  |  | $ | 2,122 |  |
| Purchases of property, plant and equipment included in accounts payable |  |  | $ | 952 |  |  | $ | — |  |  | $ | 952 |  |
| Redemption of redeemable non-controlling interest |  |  | $ | 2,976 |  |  | $ | — |  |  | $ | 2,976 |  |


## us-gaap:SubsequentEventsTextBlock

[0001193125-25-264157:notes:237]
21. SUBSEQUENT EVENTS

[0001193125-25-264157:notes:238]
Termination of Deferred Compensation Plans

[0001193125-25-264157:notes:239]
On November 3, 2025, in an effort to streamline the benefits offered to members of management and other key employees, the Company terminated its Deferred Compensation Program for Employees (the "Deferred Compensation Plan") and its Equity Deferral Program for Employees (together with the Deferred Compensation Plan, the "Plans"). The Plans are deferred compensation plans that have provided certain members of management or highly compensated employees, including certain of our named executive officers, with an opportunity to defer the receipt of a portion of their cash compensation, bonus, or other specified compensation. Each of the Plans has been maintained as an unfunded, nonqualified plan providing benefits based on the participant’s notional account balance at the time of retirement or separation, death or (with respect to the Deferred Compensation Plan) a change in control. The Company has also terminated its deferred compensation plans for its non-employee directors. See Part II, Item 5(a) of this report for additional information regarding the terminated deferred compensation plans.
