# ADTN notes — 0001564590-21-042027


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001564590-21-042027:notes:1]
[same as prior period, unchanged from 0001564590-21-025123:notes:1]

[0001564590-21-042027:notes:2]
[same as prior period, unchanged from 0001564590-21-025123:notes:2]

[0001564590-21-042027:notes:3]
[same as prior period, unchanged from 0001564590-21-025123:notes:3]

[0001564590-21-042027:notes:4]
[same as prior period, unchanged from 0001564590-21-025123:notes:4]

[0001564590-21-042027:notes:5]
[same as prior period, unchanged from 0001564590-21-025123:notes:5]

[0001564590-21-042027:notes:6]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenue and expense during the reporting period. The more significant estimates include excess and obsolete inventory reserves, warranty reserves, customer rebates, determination and accrual of deferred revenue components of multi-element sales agreements, estimated costs to complete obligations associated with deferred and accrued revenues and network installations, estimated income tax provision and income tax contingencies, fair value of stock-based compensation, assessment of goodwill and other intangibles for impairment, estimated lives of intangible assets, estimated pension liability and fair value of investments. Actual amounts could differ significantly from these estimates.

[0001564590-21-042027:notes:7]
We assessed certain accounting matters that generally require consideration of forecasted financial information in context with the information reasonably available to us and the unknown future impacts of the SARS-CoV-2 coronavirus/COVID-19 global pandemic (or variants of the SARS-CoV-2 coronavirus, including the Delta variant) as of June 30, 2021 and through the date of this report. The accounting matters assessed included, but were not limited to, the allowance for expected credit losses, stock-based compensation, carrying value of goodwill, intangibles and other long-lived assets, financial assets, valuation allowances for tax assets and revenue recognition. While there was not a material impact to our consolidated financial statements as of and for the six months ended June 30, 2021 resulting from these assessments, future conditions related to the magnitude and duration of the COVID-19 pandemic, as well as other factors, could result in material impacts to our consolidated financial statements in future reporting periods.

[0001564590-21-042027:notes:8]
[same as prior period, unchanged from 0001564590-21-025123:notes:8]

[0001564590-21-042027:notes:9]
During the three months ended March 31, 2020, it was determined that certain investments held in the Company’s stock for a deferred compensation plan accounted for as a Rabbi trust were incorrectly classified as long-term investments with the fair value of such investments incorrectly marked to market at each period end rather than classified as Treasury stock held at historical cost. This plan has been in existence since 2011. The Company corrected this misstatement as an out-of-period adjustment in the three months ended March 31, 2020 by remeasuring the investment assets to their historical cost basis through the recording of a net investment gain of $1.5 million in the unaudited Condensed Consolidated Statement of Income (Loss) and then correcting the classification by decreasing the long-term investment balance at its remeasured cost basis of $2.8 million to Treasury stock in the unaudited Condensed Consolidated Balance Sheet as of March 31, 2020. Management has determined that this misstatement was not material to any of its previously issued financial statements and that the correction of the misstatement was not material to the Company’s 2020 annual financial results on either a quantitative or qualitative basis.

[0001564590-21-042027:notes:10]
Recently Adopted Accounting Pronouncements

[0001564590-21-042027:notes:11]
We recently adopted the following accounting standards, which had the following impacts on our condensed consolidated financial statements:

[0001564590-21-042027:notes:12]
In August 2018, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2018-14, Compensation – Retirement Benefits – Defined Benefit Plans – General (Subtopic 715-20): Disclosure Framework – Changes to the Disclosure Requirements for Defined Benefit Plans, which makes changes to and clarifies the disclosure requirements related to defined benefit pension and other postretirement plans. ASU 2018-14 requires additional disclosures related to the reasons for significant gains and losses affecting the benefit obligation and an explanation of any other significant changes in the benefit obligation or plan assets that are not otherwise apparent in other disclosures required by Accounting Standards Codification (“ASC”) 715. ASU 2018-14 also clarifies the guidance in ASC 715 to require disclosure of the projected benefit obligation (“PBO”) and fair value of plan assets for pension plans with PBOs in excess of plan assets and the accumulated benefit obligation (“ABO”) and fair value of plan assets for pension plans with ABOs in excess of plan assets. ASU 2018-14 became effective for public business entities for fiscal years ending after December 15, 2020. The adoption of this standard did not have a material effect on the disclosures in the condensed consolidated financial statements.

[0001564590-21-042027:notes:13]
In December 2019, the FASB issued ASU 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes, which simplifies the accounting for income taxes by removing various exceptions, such as the exception to the incremental approach for intra-period tax allocation when there is a loss from continuing operations and income or a gain from other items. The amendments in this update also simplify the accounting for income taxes related to income-based franchise taxes and require that an entity reflect enacted tax laws or rates in the annual effective tax rate computation in the interim period that includes the enactment date. The Company early adopted ASU 2019-12 on April 1, 2020, which was applied on a prospective basis as if the Company adopted the standard on January 1, 2020. The Company early adopted the standard to take advantage of the simplification of rules for income taxes on intra-period tax allocations. Specifically, the adoption of this standard resulted in the recognition of approximately $0.1 million of tax benefit in other comprehensive income (loss) for the three months ended March 31, 2020, that otherwise would have been recognized in continuing operations had the intra-period tax allocation been completed. There were no other impacts from this standard on the condensed consolidated financial statements.

[0001564590-21-042027:notes:14]
[same as prior period, unchanged from 0001564590-21-025123:notes:14]

[0001564590-21-042027:notes:15]
There are currently no recent accounting pronouncements that have not yet been adopted and that would have a material effect, once adopted, on the condensed consolidated financial statements.


## us-gaap:CashAndCashEquivalentsDisclosureTextBlock

[0001564590-21-042027:notes:16]
[same as prior period, unchanged from 0001564590-21-025123:notes:16]

[0001564590-21-042027:notes:17]
[same as prior period, unchanged from 0001564590-21-025123:notes:17]

[0001564590-21-042027:notes:18]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | June 30, 2021 |  |  | December 31, 2020 |  |
| Cash and cash equivalents |  | $ | 69,927 |  |  | $ | 60,161 |  |
| Restricted cash |  |  | 54 |  |  |  | 18 |  |
| Cash, cash equivalents and restricted cash |  | $ | 69,981 |  |  | $ | 60,179 |  |

[0001564590-21-042027:notes:19]
See Note 18 for additional information regarding restricted cash.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001564590-21-042027:notes:20]
[same as prior period, unchanged from 0001564590-21-025123:notes:20]

[0001564590-21-042027:notes:21]
[same as prior period, unchanged from 0001564590-21-025123:notes:21]

[0001564590-21-042027:notes:22]
[same as prior period, unchanged from 0001564590-21-025123:notes:22]

[0001564590-21-042027:notes:23]
[same as prior period, unchanged from 0001564590-21-025123:notes:23]

[0001564590-21-042027:notes:24]
[same as prior period, unchanged from 0001564590-21-025123:notes:25]

[0001564590-21-042027:notes:25]
In addition to our reportable segments, revenue is also reported for the following three categories – Access & Aggregation, Subscriber Solutions & Experience and Traditional & Other Products.

[0001564590-21-042027:notes:26]
The following tables disaggregate revenue by reportable segment and revenue category:

[0001564590-21-042027:notes:27]
|  |  | Three Months Ended |  |
|  |  | June 30, 2021 |  |  | June 30, 2020 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 78,307 |  |  | $ | 12,657 |  |  | $ | 90,964 |  |  | $ | 69,721 |  |  | $ | 13,055 |  |  | $ | 82,776 |  |
| Subscriber Solutions & Experience |  |  | 45,097 |  |  |  | 2,713 |  |  |  | 47,810 |  |  |  | 38,081 |  |  |  | 2,312 |  |  |  | 40,393 |  |
| Traditional & Other Products |  |  | 2,045 |  |  |  | 2,413 |  |  |  | 4,458 |  |  |  | 3,521 |  |  |  | 2,025 |  |  |  | 5,546 |  |
| Total |  | $ | 125,449 |  |  | $ | 17,783 |  |  | $ | 143,232 |  |  | $ | 111,323 |  |  | $ | 17,392 |  |  | $ | 128,715 |  |

[0001564590-21-042027:notes:28]
|  |  | Six Months Ended |  |
|  |  | June 30, 2021 |  |  | June 30, 2020 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 138,360 |  |  | $ | 21,678 |  |  | $ | 160,038 |  |  | $ | 122,776 |  |  | $ | 25,966 |  |  | $ | 148,742 |  |
| Subscriber Solutions & Experience |  |  | 97,366 |  |  |  | 5,013 |  |  |  | 102,379 |  |  |  | 78,064 |  |  |  | 4,508 |  |  |  | 82,572 |  |
| Traditional & Other Products |  |  | 3,532 |  |  |  | 4,816 |  |  |  | 8,348 |  |  |  | 7,855 |  |  |  | 4,069 |  |  |  | 11,924 |  |
| Total |  | $ | 239,258 |  |  | $ | 31,507 |  |  | $ | 270,765 |  |  | $ | 208,695 |  |  | $ | 34,543 |  |  | $ | 243,238 |  |

[0001564590-21-042027:notes:29]
Revenue allocated to remaining performance obligations represents contract revenues that have not yet been recognized for contracts with a duration of greater than one year. As of June 30, 2021, we did not have any significant performance obligations related to customer contracts that had an original expected duration of one year or more, other than maintenance services, which are satisfied over time. As a practical expedient, for certain contracts we recognize revenue equal to the amounts that we are entitled to invoice, which correspond to the value of completed performance obligations to date. The amount related to these performance obligations was $19.7 million and $17.7 million as of June 30, 2021 and December 31, 2020, respectively. The Company expects to recognize 64% of the $19.7 million as of June 30, 2021 over the next 12 months, with the remainder to be recognized thereafter.

[0001564590-21-042027:notes:30]
[same as prior period, unchanged from 0001564590-21-025123:notes:30]

[0001564590-21-042027:notes:31]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | June 30, 2021 |  |  | December 31, 2020 |  |
| Accounts receivable, net |  | $ | 122,669 |  |  | $ | 98,827 |  |
| Contract assets(1) |  | $ | 1,036 |  |  | $ | 63 |  |
| Unearned revenue |  | $ | 15,889 |  |  | $ | 14,092 |  |
| Non-current unearned revenue |  | $ | 7,030 |  |  | $ | 6,888 |  |

[0001564590-21-042027:notes:32]
[same as prior period, unchanged from 0001564590-21-025123:notes:32]

[0001564590-21-042027:notes:33]
Of the outstanding unearned revenue balances as of December 31, 2020 $2.9 million and $7.9 million were recognized as revenue during the three and six months ended June 30, 2021, respectively.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0001564590-21-042027:notes:34]
[same as prior period, unchanged from 0001564590-21-025123:notes:34]

[0001564590-21-042027:notes:35]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Access & Aggregation |  | $ | 90,964 |  |  | $ | 82,776 |  |  | $ | 160,038 |  |  | $ | 148,742 |  |
| Subscriber Solutions & Experience |  |  | 47,810 |  |  |  | 40,393 |  |  |  | 102,379 |  |  |  | 82,572 |  |
| Traditional & Other Products |  |  | 4,458 |  |  |  | 5,546 |  |  |  | 8,348 |  |  |  | 11,924 |  |
| Total |  | $ | 143,232 |  |  | $ | 128,715 |  |  | $ | 270,765 |  |  | $ | 243,238 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-21-042027:notes:36]
[same as prior period, unchanged from 0001564590-21-025123:notes:36]

[0001564590-21-042027:notes:37]
Our effective tax rate decreased from an expense of 68.5% for the three months ended June 30, 2020, to an expense of 18.1% for the three months ended June 30, 2021 and increased from a benefit of 22.9% for the six months ended June 30, 2020 to an expense of 26.7% for the six months ended June 30, 2021. The change in the effective tax rate for the three months ended June 30, 2021 was driven by tax expense in our international operations and additional changes in the valuation allowance related to our domestic operations. The change in the effective tax rate for the six months ended June 30, 2021 was primarily driven by a tax benefit of $7.4 million recognized during the six months ended June 30, 2020 as a result of the passing of the Coronavirus Aid, Relief, and Economic Security Act (the “CARES Act”) on March 27, 2020, which allowed for the carryback of federal net operating losses, partially offset with tax expense in our international operations in the current quarter. Additionally, on February 12, 2021, the Alabama Business Tax Competitiveness Act was signed into law. As a result of the Act, we recognized an expense of $1.6 million related to the revaluation of our deferred tax assets, which was offset by changes in our valuation allowance previously recorded against our domestic deferred tax assets. The total increase in the valuation allowance against our domestic deferred tax assets was recorded in the amount of $1.6 million during the six months ended June 30, 2021.

[0001564590-21-042027:notes:38]
The Company continually reviews the adequacy of its valuation allowance and recognizes the benefits of deferred tax assets only as the reassessment indicates that it is more likely than not that the deferred tax assets will be recognized in accordance with ASC 740,

[0001564590-21-042027:notes:39]
Income Taxes. As of June 30, 2021, the Company had deferred tax assets totaling $56.9 million, and a valuation allowance totaling $47.8 million against those deferred tax assets. The remaining $9.2 million in deferred tax assets not offset by a valuation allowance are located in various foreign jurisdictions where the Company believes it is more likely than not we will realize these deferred tax assets. Our assessment of the realizability of our deferred tax assets includes the evaluation of historical operating results as well as the evaluation of evidence which requires significant judgement, including the evaluation of our three-year cumulative income position, future taxable income projections and tax planning strategies. Should management’s conclusion change in the future and an additional valuation allowance or a partial or full release of the valuation allowance becomes necessary, it could have a material effect on our consolidated financial statements.

[0001564590-21-042027:notes:40]
[same as prior period, unchanged from 0001564590-21-025123:notes:39]

[0001564590-21-042027:notes:41]
|  |  | As of June 30, 2021 |  |
| (In thousands) |  | Deferred Tax Assets |  |  | Valuation Allowance |  |  | Deferred Tax Assets, net |  |
| Domestic |  | $ | 45,383 |  |  | $ | (45,383 | ) |  | $ | — |  |
| International |  |  | 11,558 |  |  |  | (2,393 | ) |  |  | 9,165 |  |
| Total |  | $ | 56,941 |  |  | $ | (47,776 | ) |  | $ | 9,165 |  |

[0001564590-21-042027:notes:42]
[same as prior period, unchanged from 0001564590-21-025123:notes:41]


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-21-042027:notes:43]
5. STOCK-BASED COMPENSATION

[0001564590-21-042027:notes:44]
[same as prior period, unchanged from 0001564590-21-025123:notes:47]

[0001564590-21-042027:notes:45]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Stock-based compensation expense included in cost of revenue |  | $ | 125 |  |  | $ | 87 |  |  | $ | 256 |  |  | $ | 202 |  |
| Selling, general and administrative expense |  |  | 1,098 |  |  |  | 971 |  |  |  | 2,196 |  |  |  | 2,046 |  |
| Research and development expense |  |  | 585 |  |  |  | 597 |  |  |  | 1,163 |  |  |  | 1,198 |  |
| Stock-based compensation expense included in operating expenses |  |  | 1,683 |  |  |  | 1,568 |  |  |  | 3,359 |  |  |  | 3,244 |  |
| Total stock-based compensation expense |  |  | 1,808 |  |  |  | 1,655 |  |  |  | 3,615 |  |  |  | 3,446 |  |
| Tax benefit for expense associated with stock options, PSUs, RSUs and restricted stock |  |  | (452 | ) |  |  | (394 | ) |  |  | (883 | ) |  |  | (821 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 1,356 |  |  | $ | 1,261 |  |  | $ | 2,732 |  |  | $ | 2,625 |  |

[0001564590-21-042027:notes:46]
[same as prior period, unchanged from 0001564590-21-025123:notes:49]

[0001564590-21-042027:notes:47]
The following table summarizes PSUs, RSUs and restricted stock outstanding as of December 31, 2020 and June 30, 2021 and the changes that occurred during the six months ended June 30, 2021:

[0001564590-21-042027:notes:48]
|  |  | Number of Shares (in thousands) |  |  | Weighted Avg. Grant Date Fair Value (per share) |  |
| Unvested PSUs, RSUs and restricted stock outstanding, December 31, 2020 |  |  | 1,846 |  |  | $ | 11.49 |  |
| PSUs, RSUs and restricted stock granted |  |  | 357 |  |  | $ | 16.73 |  |
| PSUs, RSUs and restricted stock vested |  |  | (12 | ) |  | $ | 11.76 |  |
| PSUs, RSUs and restricted stock forfeited |  |  | (47 | ) |  | $ | 11.58 |  |
| Unvested PSUs, RSUs and restricted stock outstanding, June 30, 2021 |  |  | 2,144 |  |  | $ | 12.41 |  |

[0001564590-21-042027:notes:49]
During each of the six month periods ended June 30, 2021 and 2020, the Company granted 0.3 million performance-based PSUs to its executive officers and certain employees. The grant-date fair value of these performance-based awards was based on the closing price of the Company’s stock on the date of grant. These awards vest over two-year and three-year periods, respectively, subject to the grantee’s continued employment, with the ability to earn shares in a range of 0% to 142.8% of the awarded number of PSUs based on

[0001564590-21-042027:notes:50]
the achievement of defined performance targets. Equity-based compensation expense with respect to these awards may be adjusted over the vesting period to reflect the probability of achievement of performance targets defined in the award agreements.

[0001564590-21-042027:notes:51]
The fair value of RSUs and restricted stock is equal to the closing price of our stock on the date of grant. The fair value of PSUs with market conditions is calculated using a Monte Carlo simulation valuation method.

[0001564590-21-042027:notes:52]
As of June 30, 2021, total unrecognized compensation expense related to non-vested market-based PSUs, RSUs and restricted stock was approximately $13.2 million, which will be recognized over the remaining weighted-average period of 2.5 years. In addition, there was $7.5 million of unrecognized compensation expense related to unvested 2020 and 2021 performance-based PSUs, which will be recognized over the remaining requisite service period of 1.5 years if achievement of the performance obligation becomes probable. Unrecognized compensation expense will be adjusted for actual forfeitures.

[0001564590-21-042027:notes:53]
As of June 30, 2021, 3.5 million shares were available for issuance under stockholder-approved equity plans.

[0001564590-21-042027:notes:54]
[same as prior period, unchanged from 0001564590-21-025123:notes:56]

[0001564590-21-042027:notes:55]
The following table summarizes stock options outstanding as of December 31, 2020 and June 30, 2021 and the changes that occurred during the six months ended June 30, 2021:

[0001564590-21-042027:notes:56]
|  |  | Number of Stock Options (in thousands) |  |  | Weighted Avg. Exercise Price (per share) |  |  | Weighted Avg. Remaining Contractual Life (in years) |  |  | Aggregate Intrinsic Value (in thousands) |  |
| Stock options outstanding, December 31, 2020 |  |  | 2,718 |  |  | $ | 21.17 |  |  |  | 2.9 |  |  | $ | — |  |
| Stock options exercised |  |  | (215 | ) |  | $ | 16.53 |  |  |  |  |  |  |  | 588 |  |
| Stock options expired |  |  | (117 | ) |  | $ | 23.37 |  |  |  |  |  |  |  | 17 |  |
| Stock options outstanding, June 30, 2021 |  |  | 2,386 |  |  | $ | 21.47 |  |  |  | 2.4 |  |  | $ | 4,721 |  |
| Stock options exercisable, June 30, 2021 |  |  | 2,386 |  |  | $ | 21.47 |  |  |  | 2.4 |  |  | $ | 4,721 |  |

[0001564590-21-042027:notes:57]
As of June 30, 2021, there was no unrecognized compensation expense related to stock options as all awards vested in prior periods.

[0001564590-21-042027:notes:58]
There were no stock options granted during the six months ended June 30, 2021 or 2020. All of the options were previously issued at exercise prices that approximated fair market value at the date of grant.

[0001564590-21-042027:notes:59]
The aggregate intrinsic value of stock options represents the total pre-tax intrinsic value (the difference between ADTRAN’s closing stock price on the last trading day of the quarter and the exercise price, multiplied by the number of in-the-money options) that would have been received by the option holders had all option holders exercised their options on June 30, 2021. The amount of aggregate intrinsic value was $4.7 million as of June 30, 2021 and will change based on the fair market value of ADTRAN’s stock. The total pre-tax intrinsic value of options exercised during the six months ended June 30, 2021 was $0.6 million.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001564590-21-042027:notes:60]
6. INVESTMENTS

[0001564590-21-042027:notes:61]
Debt Securities and Other Investments

[0001564590-21-042027:notes:62]
The following debt securities and other investments were included on the Condensed Consolidated Balance Sheet and recorded at fair value:

[0001564590-21-042027:notes:63]
|  |  | As of June 30, 2021 |  |
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 14,954 |  |  | $ | 53 |  |  | $ | (6 | ) |  | $ | 15,001 |  |
| Municipal fixed-rate bonds |  |  | 2,523 |  |  |  | 15 |  |  |  | (1 | ) |  |  | 2,537 |  |
| Asset-backed bonds |  |  | 3,983 |  |  |  | 20 |  |  |  | (2 | ) |  |  | 4,001 |  |
| Mortgage/Agency-backed bonds |  |  | 11,004 |  |  |  | 50 |  |  |  | (15 | ) |  |  | 11,039 |  |
| U.S. government bonds |  |  | 10,777 |  |  |  | 51 |  |  |  | (5 | ) |  |  | 10,823 |  |
| Foreign government bonds |  |  | 546 |  |  |  | 1 |  |  |  | (1 | ) |  |  | 546 |  |
| Other |  |  | 533 |  |  |  | — |  |  |  | — |  |  |  | 533 |  |
| Available-for-sale debt securities held at fair value |  | $ | 44,320 |  |  | $ | 190 |  |  | $ | (30 | ) |  | $ | 44,480 |  |

[0001564590-21-042027:notes:64]
|  |  | As of December 31, 2020 |  |
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 11,762 |  |  | $ | 123 |  |  | $ | — |  |  | $ | 11,885 |  |
| Municipal fixed-rate bonds |  |  | 2,854 |  |  |  | 30 |  |  |  | — |  |  |  | 2,884 |  |
| Asset-backed bonds |  |  | 6,634 |  |  |  | 74 |  |  |  | — |  |  |  | 6,708 |  |
| Mortgage/Agency-backed bonds |  |  | 11,536 |  |  |  | 114 |  |  |  | (6 | ) |  |  | 11,644 |  |
| U.S. government bonds |  |  | 9,763 |  |  |  | 112 |  |  |  | — |  |  |  | 9,875 |  |
| Foreign government bonds |  |  | 1,334 |  |  |  | 4 |  |  |  | (1 | ) |  |  | 1,337 |  |
| Commercial Paper |  |  | 250 |  |  |  | — |  |  |  | — |  |  |  | 250 |  |
| Other |  |  | 533 |  |  |  | — |  |  |  | — |  |  |  | 533 |  |
| Available-for-sale debt securities held at fair value |  | $ | 44,666 |  |  | $ | 457 |  |  | $ | (7 | ) |  | $ | 45,116 |  |

[0001564590-21-042027:notes:65]
The contractual maturities related to debt securities and other investments were as follows:

[0001564590-21-042027:notes:66]
|  |  | As of June 30, 2021 |  |
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset- backed bonds |  |  | Mortgage/ Agency- backed bonds |  |  | U.S. government bonds |  |  | Foreign government bonds |  |  | Other |  |
| Less than one year |  | $ | 436 |  |  | $ | 529 |  |  | $ | 1 |  |  | $ | 254 |  |  | $ | 735 |  |  | $ | — |  |  | $ | 533 |  |
| One to two years |  |  | 4,575 |  |  |  | 496 |  |  |  | — |  |  |  | 1,865 |  |  |  | 7,240 |  |  |  | — |  |  |  | — |  |
| Two to three years |  |  | 7,518 |  |  |  | 1,103 |  |  |  | 50 |  |  |  | 1,199 |  |  |  | 1,188 |  |  |  | 546 |  |  |  | — |  |
| Three to five years |  |  | 2,472 |  |  |  | 409 |  |  |  | 1,749 |  |  |  | 165 |  |  |  | 1,660 |  |  |  | — |  |  |  | — |  |
| Five to ten years |  |  | — |  |  |  | — |  |  |  | 866 |  |  |  | 2,213 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| More than ten years |  |  | — |  |  |  | — |  |  |  | 1,335 |  |  |  | 5,343 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 15,001 |  |  | $ | 2,537 |  |  | $ | 4,001 |  |  | $ | 11,039 |  |  | $ | 10,823 |  |  | $ | 546 |  |  | $ | 533 |  |

[0001564590-21-042027:notes:67]
Actual maturities may differ from contractual maturities as some borrowers have the right to call or prepay obligations with or without call or prepayment penalties.

[0001564590-21-042027:notes:68]
Realized gains and losses on sales of debt securities are computed under the specific identification method. The following table presents the gross realized gains and losses related to our debt securities:

[0001564590-21-042027:notes:69]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Gross realized gain on debt securities |  | $ | 97 |  |  | $ | 190 |  |  | $ | 184 |  |  | $ | 233 |  |
| Gross realized loss on debt securities |  |  | (20 | ) |  |  | (19 | ) |  |  | (36 | ) |  |  | (39 | ) |
| Total gain recognized, net |  | $ | 77 |  |  | $ | 171 |  |  | $ | 148 |  |  | $ | 194 |  |

[0001564590-21-042027:notes:70]
No allowance for credit loss was recorded for the six months ended June 30, 2021 or 2020 related to available-for-sale debt securities. The Company’s investment policy provides limitations for issuer concentration, which limits, at the time of purchase, the concentration in any one issuer to 5% of the market value of our total investment portfolio. The Company did not purchase any available-for-sale debt security with credit deterioration during the six months ended June 30, 2021.

[0001564590-21-042027:notes:71]
Marketable Equity Securities

[0001564590-21-042027:notes:72]
Our marketable equity securities consist of publicly traded stock, interests in funds and certain other investments measured at fair value or cost (where appropriate).

[0001564590-21-042027:notes:73]
In March 2019, an outstanding note receivable of $4.3 million owed to the Company was repaid and reissued in the form of debt and equity. Of the outstanding $4.3 million, $3.4 million was issued as an equity investment. The Company elected to record this equity investment that does not have a readily determinable fair value using the measurement alternative. Under the measurement alternative, equity investments that do not have a readily determinable fair value can be recorded at cost less impairment, if any, adjusted for observable price changes for an identical or similar investment. During the year ended December 31, 2020, impairment charges totaling $2.6 million were recorded related to this equity investment, which was included in net investment gain (loss) on the Condensed Consolidated Statement of Income (Loss). As a result the carrying value of this investment was $0.8 million as of June 30, 2021 and December 31, 2020. The remaining amount, $0.9 million of the original $4.3 million note receivable, was reissued as a new note receivable, which is included in long-term investments on the Condensed Consolidated Balance Sheets as of June 30, 2021 and December 31, 2020. No impairment charge was recognized related to the note receivable as it is a secured loan.

[0001564590-21-042027:notes:74]
Realized and unrealized gains and losses related to marketable equity securities were as follows:

[0001564590-21-042027:notes:75]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Realized gain (loss) on equity securities sold |  | $ | (79 | ) |  | $ | 328 |  |  | $ | (55 | ) |  | $ | (2,108 | ) |
| Unrealized gain on equity securities held |  |  | 2,011 |  |  |  | 9,353 |  |  |  | 2,912 |  |  |  | 889 |  |
| Total gain (loss) recognized, net |  | $ | 1,932 |  |  | $ | 9,681 |  |  | $ | 2,857 |  |  | $ | (1,219 | ) |

[0001564590-21-042027:notes:76]
U.S. GAAP establishes a three-level valuation hierarchy based upon observable and unobservable inputs for fair value measurement of financial instruments:

[0001564590-21-042027:notes:77]
• Level 1 – Observable outputs; values based on unadjusted quoted prices for identical assets or liabilities in an active market;

[0001564590-21-042027:notes:78]
• Level 2 – Significant inputs that are observable; values based on quoted prices in markets that are not active or model inputs that are observable either directly or indirectly;

[0001564590-21-042027:notes:79]
• Level 3 – Significant unobservable inputs; values based on prices or valuation techniques that require inputs that are both unobservable and significant to the overall fair value measurement. These inputs could include information supplied by investees.

[0001564590-21-042027:notes:80]
The Company’s cash equivalents and investments held at fair value are categorized into this hierarchy as follows:

[0001564590-21-042027:notes:81]
|  |  |  |  |  |  | Fair Value Measurements as of June 30, 2021 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 615 |  |  | $ | 615 |  |  | $ | — |  |  | $ | — |  |
| Commercial paper |  |  | 1,250 |  |  |  | — |  |  |  | 1,250 |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 15,001 |  |  |  | — |  |  |  | 15,001 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 2,537 |  |  |  | — |  |  |  | 2,537 |  |  |  | — |  |
| Asset-backed bonds |  |  | 4,001 |  |  |  | — |  |  |  | 4,001 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 11,039 |  |  |  | — |  |  |  | 11,039 |  |  |  | — |  |
| U.S. government bonds |  |  | 10,823 |  |  |  | 10,823 |  |  |  | — |  |  |  | — |  |
| Foreign government securities |  |  | 546 |  |  |  | — |  |  |  | 546 |  |  |  | — |  |
| Other |  |  | 533 |  |  |  | — |  |  |  | — |  |  |  | 533 |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 12,057 |  |  |  | 12,057 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 25,917 |  |  |  | 25,917 |  |  |  | — |  |  |  | — |  |
| Other investments |  |  | 1,400 |  |  |  | 1,400 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 85,719 |  |  | $ | 50,812 |  |  | $ | 34,374 |  |  | $ | 533 |  |

[0001564590-21-042027:notes:82]
|  |  |  |  |  |  | Fair Value Measurements as of December 31, 2020 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 497 |  |  | $ | 497 |  |  | $ | — |  |  | $ | — |  |
| U.S. government bonds |  |  | 350 |  |  |  | 350 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 11,885 |  |  |  | — |  |  |  | 11,885 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 2,884 |  |  |  | — |  |  |  | 2,884 |  |  |  | — |  |
| Asset-backed bonds |  |  | 6,708 |  |  |  | — |  |  |  | 6,708 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 11,644 |  |  |  | — |  |  |  | 11,644 |  |  |  | — |  |
| U.S. government bonds |  |  | 9,875 |  |  |  | 9,875 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 1,337 |  |  |  | — |  |  |  | 1,337 |  |  |  | — |  |
| Commercial paper |  |  | 250 |  |  |  | — |  |  |  | 250 |  |  |  | — |  |
| Other |  |  | 533 |  |  |  | — |  |  |  | — |  |  |  | 533 |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 10,963 |  |  |  | 10,963 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 23,891 |  |  |  | 23,891 |  |  |  | — |  |  |  | — |  |
| Other investments |  |  | 1,400 |  |  |  | 1,400 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 82,217 |  |  | $ | 46,976 |  |  | $ | 34,708 |  |  | $ | 533 |  |

[0001564590-21-042027:notes:83]
The fair value of our Level 2 securities is calculated using a weighted average market price for each security. Market prices are obtained from a variety of industry standard data providers, large financial institutions and other third-party sources. These multiple market prices are used as inputs into a distribution-curve-based algorithm to determine the daily market value of each security.

[0001564590-21-042027:notes:84]
The fair value of Level 3 securities is calculated based on unobservable inputs. Quantitative information with respect to unobservable inputs consists of third-party valuations performed in accordance with ASC 820 – Fair Value Measurement. Inputs used in preparing the third-party valuation included the following assumptions, among others: estimated discount rates and fair market yields.


## us-gaap:InventoryDisclosureTextBlock

[0001564590-21-042027:notes:85]
7. INVENTORY

[0001564590-21-042027:notes:86]
[same as prior period, unchanged from 0001564590-21-025123:notes:88]

[0001564590-21-042027:notes:87]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | June 30, 2021 |  |  | December 31, 2020 |  |
| Raw materials |  | $ | 52,257 |  |  | $ | 47,026 |  |
| Work in process |  |  | 1,874 |  |  |  | 776 |  |
| Finished goods |  |  | 64,881 |  |  |  | 77,655 |  |
| Total inventory, net |  | $ | 119,012 |  |  | $ | 125,457 |  |

[0001564590-21-042027:notes:88]
Inventory reserves are established for estimated excess and obsolete inventory equal to the difference between the cost of the inventory and the estimated net realizable value of the inventory based on estimated reserve percentages, which consider historical usage, known trends, inventory age and market conditions. As of June 30, 2021 and December 31, 2020, inventory reserves were $42.7 million and $39.6 million, respectively.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001564590-21-042027:notes:89]
8. PROPERTY, PLANT AND EQUIPMENT

[0001564590-21-042027:notes:90]
[same as prior period, unchanged from 0001564590-21-025123:notes:92]

[0001564590-21-042027:notes:91]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | June 30, 2021 |  |  | December 31, 2020 |  |
| Land |  | $ | 4,575 |  |  | $ | 4,575 |  |
| Building and land improvements |  |  | 34,961 |  |  |  | 35,142 |  |
| Building |  |  | 68,161 |  |  |  | 68,169 |  |
| Furniture and fixtures |  |  | 19,936 |  |  |  | 19,965 |  |
| Computer hardware and software |  |  | 71,262 |  |  |  | 70,942 |  |
| Engineering and other equipment |  |  | 134,090 |  |  |  | 132,920 |  |
| Total property, plant and equipment |  |  | 332,985 |  |  |  | 331,713 |  |
| Less: accumulated depreciation |  | $ | (274,715 | ) |  | $ | (269,314 | ) |
| Total property, plant and equipment, net |  | $ | 58,270 |  |  | $ | 62,399 |  |

[0001564590-21-042027:notes:92]
Long-lived assets used in operations are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable and the undiscounted cash flows estimated to be generated by the asset are less than the asset’s carrying value. Due to the current economic environment, particularly related to COVID-19, the Company assessed impairment triggers related to long-lived assets during the second quarters of 2021 and 2020. Based on this assessment, no triggers occurred to perform an impairment test, and no impairment losses of long-lived assets were recorded for the three or six months ended June 30, 2021 or 2020.

[0001564590-21-042027:notes:93]
Depreciation expense was $3.0 million for each of the three months ended June 30, 2021 and 2020 and $6.1 million and $6.0 million for the six months ended June 30, 2021 and 2020, respectively, which is recorded in cost of revenue, selling, general and administrative expenses and research and development expenses in the Condensed Consolidated Statements of Income (Loss).


## us-gaap:GoodwillDisclosureTextBlock

[0001564590-21-042027:notes:94]
9. GOODWILL

[0001564590-21-042027:notes:95]
Goodwill was $7.0 million as of June 30, 2021 and December 31, 2020, of which $6.6 million and $0.4 million was allocated to our Network Solutions and Services & Support reportable segments, respectively.

[0001564590-21-042027:notes:96]
The Company evaluates the carrying value of goodwill during the fourth quarter of each year and between annual evaluations if events occur or circumstances change that could more likely than not reduce the fair value of the reporting unit below its carrying amount. We assess qualitative factors to determine whether the fair value of the reporting unit to which the goodwill is assigned is less than its carrying amount and recognize an impairment charge for the amount by which the carrying value exceeds the fair value of the reporting unit. Due to the current economic environment, particularly related to COVID-19, the Company performed a triggering event assessment during the second quarters of 2021 and 2020, in which no triggers were identified. Therefore, no interim impairment test of goodwill was performed as of June 30, 2021 or 2020, and no impairment of goodwill was recorded during the three or six months ended June 30, 2021 or 2020.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001564590-21-042027:notes:97]
10. INTANGIBLE ASSETS

[0001564590-21-042027:notes:98]
[same as prior period, unchanged from 0001564590-21-025123:notes:100]

[0001564590-21-042027:notes:99]
|  |  | As of June 30, 2021 |  |  | As of December 31, 2020 |  |
| (In thousands) |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Net Book Value |  |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Net Book Value |  |
| Customer relationships |  | $ | 20,985 |  |  | $ | (9,030 | ) |  | $ | 11,955 |  |  | $ | 21,123 |  |  | $ | (8,055 | ) |  | $ | 13,068 |  |
| Developed technology |  |  | 8,200 |  |  |  | (3,114 | ) |  |  | 5,086 |  |  |  | 8,200 |  |  |  | (2,546 | ) |  |  | 5,654 |  |
| Licensed technology |  |  | 5,900 |  |  |  | (2,158 | ) |  |  | 3,742 |  |  |  | 5,900 |  |  |  | (1,830 | ) |  |  | 4,070 |  |
| Supplier relationships |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 2,800 |  |  |  | (2,800 | ) |  |  | — |  |
| Licensing agreements |  |  | 560 |  |  |  | (189 | ) |  |  | 371 |  |  |  | 560 |  |  |  | (152 | ) |  |  | 408 |  |
| Patents |  |  | 500 |  |  |  | (329 | ) |  |  | 171 |  |  |  | 500 |  |  |  | (294 | ) |  |  | 206 |  |
| Trade names |  |  | 210 |  |  |  | (181 | ) |  |  | 29 |  |  |  | 210 |  |  |  | (146 | ) |  |  | 64 |  |
| Total |  | $ | 36,355 |  |  | $ | (15,001 | ) |  | $ | 21,354 |  |  | $ | 39,293 |  |  | $ | (15,823 | ) |  | $ | 23,470 |  |

[0001564590-21-042027:notes:100]
The Company evaluates the carrying value of intangible assets whenever events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable and the undiscounted cash flows estimated to be generated by the asset are less than the asset’s carrying value. Due to the current economic environment, particularly related to COVID-19, the Company assessed impairment triggers related to intangible assets during the second quarters of 2021 and 2020. Based on this assessment, no triggers occurred that required us to perform an impairment test, and no impairment losses of intangible assets were recorded for the three and six months ended June 30, 2021 or 2020.

[0001564590-21-042027:notes:101]
Amortization expense was $1.0 million in each of the three months ended June 30, 2021 and 2020 and $2.1 million and $2.4 million for the six months ended June 30, 2021 and 2020, respectively, and was included in cost of revenue, selling, general and administrative expenses and research and development expenses in the Condensed Consolidated Statements of Income (Loss).

[0001564590-21-042027:notes:102]
[same as prior period, unchanged from 0001564590-21-025123:notes:104]

[0001564590-21-042027:notes:103]
|  |  | As of |  |
| (In thousands) |  | June 30, 2021 |  |
| 2021 |  | $ | 2,028 |  |
| 2022 |  |  | 3,485 |  |
| 2023 |  |  | 3,333 |  |
| 2024 |  |  | 3,238 |  |
| 2025 |  |  | 3,029 |  |
| Thereafter |  |  | 6,241 |  |
| Total |  | $ | 21,354 |  |


## us-gaap:LessorSalesTypeLeasesTextBlock

[0001564590-21-042027:notes:104]
11. LEASES

[0001564590-21-042027:notes:105]
Net Investment in Sales-Type Leases

[0001564590-21-042027:notes:106]
We are the lessor in sales-type lease arrangements for network equipment, which consisted of the following:

[0001564590-21-042027:notes:107]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | June 30, 2021 |  |  | December 31, 2020 |  |
| Current minimum lease payments receivable(1) |  | $ | 103 |  |  | $ | 702 |  |
| Non-current minimum lease payments receivable(2) |  |  | 13 |  |  |  | 347 |  |
| Total minimum lease payments receivable |  |  | 116 |  |  |  | 1,049 |  |
| Less: Current unearned revenue |  |  | 60 |  |  |  | 218 |  |
| Less: Non-current unearned revenue |  |  | 2 |  |  |  | 50 |  |
| Net investment in sales-type leases |  | $ | 54 |  |  | $ | 781 |  |

[0001564590-21-042027:notes:108]
|  | (2) | Included in other assets on the Condensed Consolidated Balance Sheets. |


## us-gaap:DebtDisclosureTextBlock

[0001564590-21-042027:notes:109]
12. REVOLVING CREDIT AGREEMENT

[0001564590-21-042027:notes:110]
On November 4, 2020, the Company, as borrower, entered into a Revolving Credit and Security Agreement and related Promissory Note (together, the “Revolving Credit Agreement”) with Cadence Bank, N.A., as lender (the “Lender”). The Revolving Credit Agreement provides the Company with a new $10.0 million secured revolving credit facility. Loans under the Revolving Credit Agreement will bear interest at a rate equal to 1.50% over the screen rate as obtained by Reuter’s, Bloomberg or another commercially available source as may be designated by the Lender from time to time; provided, however, that in no event shall the applicable rate of interest under the Revolving Credit Agreement be less than 1.50% per annum. Such loans are secured by all of the cash, securities, securities entitlements and investment property in a certain bank account, as outlined in the Revolving Credit Agreement, at a maximum loan-to-value ratio of 75% determined by dividing the full commitment amount under the Revolving Credit Agreement on the date of testing, determined by the Lender each fiscal quarter, by the market value of the collateral. The Revolving Credit Agreement matures on November 4, 2021, subject to earlier termination upon the occurrence of certain events of default. The Company had not made any draws under the Revolving Credit Agreement as of June 30, 2021.


## adtn:IndustrialDevelopmentAuthorityFinancingAndEconomicIncentivesTextBlock

[0001564590-21-042027:notes:111]
13. ALABAMA STATE INDUSTRIAL DEVELOPMENT AUTHORITY FINANCING AND ECONOMIC INCENTIVES

[0001564590-21-042027:notes:112]
[same as prior period, unchanged from 0001564590-21-025123:notes:114]


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001564590-21-042027:notes:113]
14. STOCKHOLDERS’ EQUITY

[0001564590-21-042027:notes:114]
[same as prior period, unchanged from 0001564590-21-025123:notes:116]

[0001564590-21-042027:notes:115]
Since 1997, the Company’s Board of Directors has approved multiple share repurchase programs that have authorized repurchases of its common stock, which are implemented through open market or private purchases from time to time as conditions warrant. During the six months ended June 30, 2021, we did not repurchase any shares of our common stock. As of June 30, 2021, we had the authority to purchase an additional 2.5 million shares of our common stock under the current authorization of up to 5.0 million shares.

[0001564590-21-042027:notes:116]
Accumulated Other Comprehensive Income (Loss)

[0001564590-21-042027:notes:117]
[same as prior period, unchanged from 0001564590-21-025123:notes:119]

[0001564590-21-042027:notes:118]
|  |  | Three Months Ended June 30, 2021 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | ASU 2018-02 Adoption |  |  | Total |  |
| As of March 31, 2021 |  | $ | (160 | ) |  | $ | (9,522 | ) |  | $ | (4,298 | ) |  | $ | 385 |  |  | $ | (13,595 | ) |
| Other comprehensive income before reclassifications |  |  | (272 | ) |  |  | — |  |  |  | 338 |  |  |  | — |  |  |  | 66 |  |
| Amounts reclassified from accumulated other comprehensive income |  |  | 177 |  |  |  | 212 |  |  |  | — |  |  |  | — |  |  |  | 389 |  |
| Net current period other comprehensive income |  |  | (95 | ) |  |  | 212 |  |  |  | 338 |  |  |  | — |  |  |  | 455 |  |
| As of June 30, 2021 |  | $ | (255 | ) |  | $ | (9,310 | ) |  | $ | (3,960 | ) |  | $ | 385 |  |  | $ | (13,140 | ) |

[0001564590-21-042027:notes:119]
|  |  | Three Months Ended June 30, 2020 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | ASU 2018-02 Adoption |  |  | Total |  |
| As of March 31, 2020 |  | $ | (167 | ) |  | $ | (9,085 | ) |  | $ | (8,942 | ) |  | $ | 385 |  |  | $ | (17,809 | ) |
| Other comprehensive income before reclassifications |  |  | 881 |  |  |  | — |  |  |  | 1,899 |  |  |  | — |  |  |  | 2,780 |  |
| Amounts reclassified from accumulated other comprehensive income (loss) |  |  | (508 | ) |  |  | 191 |  |  |  | — |  |  |  | — |  |  |  | (317 | ) |
| Net current period other comprehensive income |  |  | 373 |  |  |  | 191 |  |  |  | 1,899 |  |  |  | — |  |  |  | 2,463 |  |
| As of June 30, 2020 |  | $ | 206 |  |  | $ | (8,894 | ) |  | $ | (7,043 | ) |  | $ | 385 |  |  | $ | (15,346 | ) |

[0001564590-21-042027:notes:120]
|  |  | Six Months Ended June 30, 2021 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | ASU 2018-02 Adoption |  |  | Total |  |
| As of December 31, 2020 |  | $ | 32 |  |  | $ | (9,621 | ) |  | $ | (2,435 | ) |  | $ | 385 |  |  | $ | (11,639 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | (329 | ) |  |  | — |  |  |  | (1,525 | ) |  |  | — |  |  |  | (1,854 | ) |
| Amounts reclassified from accumulated other comprehensive income |  |  | 42 |  |  |  | 311 |  |  |  | — |  |  |  | — |  |  |  | 353 |  |
| Net current period other comprehensive income (loss) |  |  | (287 | ) |  |  | 311 |  |  |  | (1,525 | ) |  |  | — |  |  |  | (1,501 | ) |
| As of June 30, 2021 |  | $ | (255 | ) |  | $ | (9,310 | ) |  | $ | (3,960 | ) |  | $ | 385 |  |  | $ | (13,140 | ) |

[0001564590-21-042027:notes:121]
|  |  | Six Months Ended June 30, 2020 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | ASU 2018-02 Adoption |  |  | Total |  |
| As of December 31, 2019 |  | $ | (284 | ) |  | $ | (9,226 | ) |  | $ | (7,292 | ) |  | $ | 385 |  |  | $ | (16,417 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | (50 | ) |  |  | — |  |  |  | 249 |  |  |  | — |  |  |  | 199 |  |
| Amounts reclassified from accumulated other comprehensive income (loss) |  |  | 540 |  |  |  | 332 |  |  |  | — |  |  |  | — |  |  |  | 872 |  |
| Amounts reclassified to retained earnings |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Net current period other comprehensive income (loss) |  |  | 490 |  |  |  | 332 |  |  |  | 249 |  |  |  | — |  |  |  | 1,071 |  |
| As of June 30, 2020 |  | $ | 206 |  |  | $ | (8,894 | ) |  | $ | (7,043 | ) |  | $ | 385 |  |  | $ | (15,346 | ) |

[0001564590-21-042027:notes:122]
The following tables present the details of reclassifications out of accumulated other comprehensive income (loss):

[0001564590-21-042027:notes:123]
|  |  | Three Months Ended June 30, 2021 |
| (In thousands) |  | Amount Reclassified from Accumulated Other Comprehensive Income (Loss) |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gain (loss) on available-for-sale securities: |  |  |  |  |  |  |
| Net realized loss on sales of securities |  | $ | (233 | ) |  | Net investment gain (loss) |
| Defined benefit plan adjustments – actuarial losses |  |  | (307 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | (540 | ) |  |  |
| Tax benefit |  |  | 151 |  |  |  |
| Total reclassifications for the period, net of tax |  | $ | (389 | ) |  |  |

[0001564590-21-042027:notes:124]
|  | (1) | A part of the computation of net periodic pension cost, which is included in other income (expense), net in the Condensed Consolidated Statements of Income (Loss). |

[0001564590-21-042027:notes:125]
|  |  | Three Months Ended June 30, 2020 |
| (In thousands) |  | Amount Reclassified from Accumulated Other Comprehensive Income (Loss) |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gain (loss) on available-for-sale securities: |  |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 686 |  |  | Net investment gain (loss) |
| Defined benefit plan adjustments – actuarial losses |  |  | (277 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | 409 |  |  |  |
| Tax expense |  |  | (92 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 317 |  |  |  |

[0001564590-21-042027:notes:126]
|  |  | Six Months Ended June 30, 2021 |
| (In thousands) |  | Amount Reclassified from Accumulated Other Comprehensive Income (Loss) |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gain (loss) on available-for-sale securities: |  |  |  |  |  |  |
| Net realized loss on sales of securities |  | $ | (55 | ) |  | Net investment gain (loss) |
| Defined benefit plan adjustments – actuarial losses |  |  | (451 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | (506 | ) |  |  |
| Tax benefit |  |  | 153 |  |  |  |
| Total reclassifications for the period, net of tax |  | $ | (353 | ) |  |  |

[0001564590-21-042027:notes:127]
|  |  | Six Months Ended June 30, 2020 |
| (In thousands) |  | Amount Reclassified from Accumulated Other Comprehensive Income (Loss) |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gain (loss) on available-for-sale securities: |  |  |  |  |  |  |
| Net realized loss on sales of securities |  | $ | (730 | ) |  | Net investment gain (loss) |
| Defined benefit plan adjustments – actuarial losses |  |  | (481 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | (1,211 | ) |  |  |
| Tax benefit |  |  | 339 |  |  |  |
| Total reclassifications for the period, net of tax |  | $ | (872 | ) |  |  |

[0001564590-21-042027:notes:128]
The following tables present the tax effects related to the change in each component of other comprehensive income (loss):

[0001564590-21-042027:notes:129]
|  |  | Three Months Ended |  |  | Three Months Ended |  |
|  |  | June 30, 2021 |  |  | June 30, 2020 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |
| Unrealized gain (loss) on available-for-sale securities |  | $ | (358 | ) |  | $ | 86 |  |  | $ | (272 | ) |  | $ | 1,191 |  |  | $ | (310 | ) |  | $ | 881 |  |
| Reclassification adjustment for amounts related to available-for-sale investments included in net income (loss) |  |  | 233 |  |  |  | (56 | ) |  |  | 177 |  |  |  | (686 | ) |  |  | 178 |  |  |  | (508 | ) |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net income (loss) |  |  | 307 |  |  |  | (95 | ) |  |  | 212 |  |  |  | 277 |  |  |  | (86 | ) |  |  | 191 |  |
| Foreign currency translation adjustment |  |  | 338 |  |  |  | — |  |  |  | 338 |  |  |  | 1,899 |  |  |  | — |  |  |  | 1,899 |  |
| Total Other Comprehensive Income |  | $ | 520 |  |  | $ | (65 | ) |  | $ | 455 |  |  | $ | 2,681 |  |  | $ | (218 | ) |  | $ | 2,463 |  |

[0001564590-21-042027:notes:130]
|  |  | Six Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, 2021 |  |  | June 30, 2020 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |
| Unrealized gain (loss) on available-for-sale securities |  | $ | (433 | ) |  | $ | 104 |  |  | $ | (329 | ) |  | $ | (68 | ) |  | $ | 18 |  |  | $ | (50 | ) |
| Reclassification adjustment for amounts related to available-for-sale investments included in net income |  |  | 55 |  |  |  | (13 | ) |  |  | 42 |  |  |  | 730 |  |  |  | (190 | ) |  |  | 540 |  |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net income |  |  | 451 |  |  |  | (140 | ) |  |  | 311 |  |  |  | 481 |  |  |  | (149 | ) |  |  | 332 |  |
| Foreign currency translation adjustment |  |  | (1,525 | ) |  |  | — |  |  |  | (1,525 | ) |  |  | 249 |  |  |  | — |  |  |  | 249 |  |
| Total Other Comprehensive Income (Loss) |  | $ | (1,452 | ) |  | $ | (49 | ) |  | $ | (1,501 | ) |  | $ | 1,392 |  |  | $ | (321 | ) |  | $ | 1,071 |  |


## us-gaap:EarningsPerShareTextBlock

[0001564590-21-042027:notes:131]
15. EARNINGS (LOSS) PER SHARE

[0001564590-21-042027:notes:132]
The calculation of basic and diluted earnings (loss) per share is as follows:

[0001564590-21-042027:notes:133]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands, except per share amounts) |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Numerator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income (loss) |  | $ | 5,086 |  |  | $ | 752 |  |  | $ | 5,982 |  |  | $ | (9,217 | ) |
| Denominator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average number of shares – basic |  |  | 48,449 |  |  |  | 47,958 |  |  |  | 48,393 |  |  |  | 47,957 |  |
| Effect of dilutive securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| PSUs, RSUs and restricted stock |  |  | 816 |  |  |  | 296 |  |  |  | 722 |  |  |  | — |  |
| Stock options |  |  | 161 |  |  |  | — |  |  |  | 110 |  |  |  | — |  |
| Weighted average number of shares – diluted |  |  | 49,426 |  |  |  | 48,254 |  |  |  | 49,225 |  |  |  | 47,957 |  |
| Earnings (loss) per share – basic |  | $ | 0.10 |  |  | $ | 0.02 |  |  | $ | 0.12 |  |  | $ | (0.19 | ) |
| Earnings (loss) per share – diluted |  | $ | 0.10 |  |  | $ | 0.02 |  |  | $ | 0.12 |  |  | $ | (0.19 | ) |

[0001564590-21-042027:notes:134]
For the three months ended June 30, 2021 and 2020, 0.4 million and 1.9 million stock options, respectively, and for the six months ended June 30, 2021 and 2020, 0.6 million and 2.3 million stock options, respectively, were outstanding but were not included in the computation of diluted earnings per share. These stock options were excluded because their exercise prices were greater than the average market price of the common shares during the applicable period, making them anti-dilutive under the treasury stock method.

[0001564590-21-042027:notes:135]
For the three months ended June 30, 2021 and 2020, one thousand and fifteen thousand shares, respectively, and for the six months ended June 30, 2021 and 2020, three thousand and 0.1 million shares, respectively, of unvested PSUs, RSUs and restricted stock were excluded from the calculation of diluted earnings per share due to their anti-dilutive effect.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-21-042027:notes:136]
16. SEGMENT INFORMATION

[0001564590-21-042027:notes:137]
The chief operating decision maker regularly reviews the Company’s financial performance based on two reportable segments: (1) Network Solutions and (2) Services & Support. Network Solutions includes hardware and software products and next-generation virtualized solutions used in service provider or business networks, as well as prior-generation products. Services & Support includes a portfolio of maintenance, network installation and solution integration services, which include hosted cloud services and subscription services.

[0001564590-21-042027:notes:138]
The performance of these segments is evaluated based on gross profit; therefore, selling, general and administrative expenses, research and development expenses, interest and dividend income, interest expense, net investment gain (loss), other income (expense), net and income tax benefit (expense) are reported on a Company-wide basis only. There is no inter-segment revenue. Asset information by reportable segment is not produced and, therefore, is not reported.

[0001564590-21-042027:notes:139]
The following tables present information about the revenue and gross profit of our reportable segments:

[0001564590-21-042027:notes:140]
|  |  | Three Months Ended |  |
|  |  | June 30, 2021 |  |  | June 30, 2020 |  |
| (In thousands) |  | Revenue |  |  | Gross Profit |  |  | Revenue |  |  | Gross Profit |  |
| Network Solutions |  | $ | 125,449 |  |  | $ | 55,435 |  |  | $ | 111,323 |  |  | $ | 47,252 |  |
| Services & Support |  |  | 17,783 |  |  |  | 7,233 |  |  |  | 17,392 |  |  |  | 6,220 |  |
| Total |  | $ | 143,232 |  |  | $ | 62,668 |  |  | $ | 128,715 |  |  | $ | 53,472 |  |

[0001564590-21-042027:notes:141]
|  |  | Six Months Ended |  |
|  |  | June 30, 2021 |  |  | June 30, 2020 |  |
| (In thousands) |  | Revenue |  |  | Gross Profit |  |  | Revenue |  |  | Gross Profit |  |
| Network Solutions |  | $ | 239,258 |  |  | $ | 104,243 |  |  | $ | 208,695 |  |  | $ | 92,998 |  |
| Services & Support |  |  | 31,507 |  |  |  | 12,026 |  |  |  | 34,543 |  |  |  | 12,074 |  |
| Total |  | $ | 270,765 |  |  | $ | 116,269 |  |  | $ | 243,238 |  |  | $ | 105,072 |  |

[0001564590-21-042027:notes:142]
[same as prior period, unchanged from 0001564590-21-025123:notes:139]

[0001564590-21-042027:notes:143]
[same as prior period, unchanged from 0001564590-21-025123:notes:140]

[0001564590-21-042027:notes:144]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| United States |  | $ | 94,656 |  |  | $ | 84,458 |  |  | $ | 181,141 |  |  | $ | 163,449 |  |
| International |  |  | 48,576 |  |  |  | 44,257 |  |  |  | 89,624 |  |  |  | 79,789 |  |
| Total |  | $ | 143,232 |  |  | $ | 128,715 |  |  | $ | 270,765 |  |  | $ | 243,238 |  |


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001564590-21-042027:notes:145]
17. LIABILITY FOR WARRANTY RETURNS

[0001564590-21-042027:notes:146]
Our products generally include warranties of 90 days to five years for product defects. We accrue for warranty returns at the time of product shipment based on our historical return rate and estimate of the cost to repair or replace the defective products. We engage in extensive product quality programs and processes, including actively monitoring and evaluating the quality of our component suppliers. The increasing complexity of our products may cause warranty incidences, when they arise, to be more costly. Estimates regarding future warranty obligations may change due to product failure rates, material usage and other rework costs incurred in correcting a product failure. In addition, from time to time, specific warranty accruals may be recorded if unforeseen problems arise. Should our actual experience relative to these factors be worse than our estimates, we will be required to record additional warranty expense. The liability for warranty obligations totaled $6.0 million and $7.1 million as of June 30, 2021 and December 31, 2020, respectively, and is included in accrued expenses and other liabilities in the Condensed Consolidated Balance Sheets. During the three and six months ended June 30, 2021 and 2020, we had a reversal of prior provisions related to warranty expirations, the impact of which is reflected in the table below:

[0001564590-21-042027:notes:147]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Balance at beginning of period |  | $ | 6,472 |  |  | $ | 7,635 |  |  | $ | 7,146 |  |  | $ | 8,394 |  |
| Plus: Amounts charged to cost and expenses |  |  | 11 |  |  |  | 393 |  |  |  | (220 | ) |  |  | 338 |  |
| Less: Deductions |  |  | (486 | ) |  |  | (734 | ) |  |  | (929 | ) |  |  | (1,438 | ) |
| Balance at end of period |  | $ | 5,997 |  |  | $ | 7,294 |  |  | $ | 5,997 |  |  | $ | 7,294 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-21-042027:notes:148]
18. COMMITMENTS AND CONTINGENCIES

[0001564590-21-042027:notes:149]
Shareholder Derivative Lawsuit

[0001564590-21-042027:notes:150]
On March 31, 2020, a shareholder derivative suit, captioned Johnson (Derivatively on behalf of ADTRAN) v. Stanton, et al., Case No. 5:20-cv-00447, was filed in the U.S. District Court for the Northern District of Alabama against two of the Company’s current executive officers, one of its former executive officers, and certain current and former members of its Board of Directors. The derivative suit alleges, among other things, that the defendants made or caused the Company to make materially false and misleading statements regarding, and/or failed to disclose material adverse facts about, the Company’s business, operations and prospects, specifically relating to the Company’s internal control over financial reporting, excess and obsolete inventory reserves, financial results and demand from certain customers. The case was temporarily stayed pending an order on the defendants’ motion to dismiss in a separate securities class action case that included similar factual allegations, Burbridge v. ADTRAN, Inc., et al., Case No. 5:20-cv-00050-LCB (N.D. Ala.). The Burbridge case was dismissed on March 31, 2021, and the time to appeal the dismissal has expired, such that the dismissal is now final.  Following the dismissal, the plaintiff in the shareholder derivative suit sent a demand letter dated June 29, 2021 to ADTRAN’s Board of Directors.  The letter contains similar allegations to those made in the plaintiff’s filed complaint and in the now dismissed securities class action, and it demands, among other things, that the Board commence an investigation into the alleged wrongdoing.  We expect that the derivative suit will remain stayed pending the Board’s response to the demand. At this time, we are unable to predict the outcome of or estimate the possible loss or range of loss, if any, associated with the derivative lawsuit or the demand letter.

[0001564590-21-042027:notes:151]
Other Legal Matters

[0001564590-21-042027:notes:152]
In addition to the litigation described above, from time to time we are subject to or otherwise involved in various lawsuits, claims, investigations and legal proceedings that arise out of or are incidental to the conduct of our business (collectively, “Legal Matters”), including those relating to patent rights, employment matters, regulatory compliance matters, stockholder claims, and contractual and other commercial disputes. Such Legal Matters, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Additionally, an unfavorable outcome in any legal matter, including in a patent dispute, could require the Company to pay damages, entitle claimants to other relief, such as royalties, or could prevent the Company from selling some of its products in certain jurisdictions. While the Company cannot predict with certainty the results of the Legal Matters in which it is currently involved, the Company does not expect that the ultimate outcome of such Legal Matters will individually or in the aggregate have a material adverse effect on its business, results of operations, financial condition or cash flows.

[0001564590-21-042027:notes:153]
Performance Bonds

[0001564590-21-042027:notes:154]
Certain contracts, customers and jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of June 30, 2021 and December 31, 2020, we had commitments related to these bonds totaling $21.2 million and $15.2 million, respectively, which expire at various dates through August 2024. Although the triggering events vary from contract to contract, in general we would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which we believe is remote.

[0001564590-21-042027:notes:155]
In June 2020, the Company entered into a letter of credit with a bank to guarantee performance obligations under a contract with a certain customer. The obligations under this customer contract will be performed over multiple years. We reached the maximum value of our minimum collateral requirement of $15.0 million during the three months ended March 31, 2021 as the Company reached certain milestones through the first quarter of 2021 as outlined in the customer contract. The letter of credit was secured by a pledge of a portion of the Company’s fixed-income securities, which totaled $18.2 million as of June 30, 2021, of which less than $0.1 million is included in restricted cash and $18.2 million is included in long-term investments on the Condensed Consolidated Balance Sheet. This pledged collateral value will fluctuate as the Company changes the mix of the pledged collateral between restricted cash and investments. Any shortfalls in the minimum collateral value are required to be restored by the Company from available cash and cash equivalents, short-term investments and/or long-term investments. The collateral under the letter of credit will be released when all obligations under the customer contract have been met. As of June 30, 2021, the Company was in compliance with all contractual requirements under the letter of credit.

[0001564590-21-042027:notes:156]
Investment Commitment

[0001564590-21-042027:notes:157]
We have committed to invest up to an aggregate of $5.0 million in a private equity fund, of which $4.9 million has been invested as of June 30, 2021.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-21-042027:notes:158]
19. RESTRUCTURING

[0001564590-21-042027:notes:159]
During the second half of 2019, the Company initiated a restructuring plan to realign its expense structure with the reduction in revenue experienced in recent years and overall Company objectives. As part of this restructuring plan, the Company announced plans to reduce its overall operating expenses, both in the U.S. and internationally. Management continued to assess the efficiency of operations during 2020 and the first half of 2021 and, in turn, consolidated locations and personnel, among other things, where possible.

[0001564590-21-042027:notes:160]
[same as prior period, unchanged from 0001564590-21-025123:notes:160]

[0001564590-21-042027:notes:161]
The cumulative amount of restructuring expenses incurred as of June 30, 2021 for the restructuring plans was $12.5 million.

[0001564590-21-042027:notes:162]
A reconciliation of the beginning and ending restructuring liability, which is included in accrued wages and benefits in the Condensed Consolidated Balance Sheets is as follows:

[0001564590-21-042027:notes:163]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
| (In thousands) |  | June 30, 2021 |  |  | June 30, 2021 |  |
| Balance at beginning of period |  | $ | 2,077 |  |  | $ | 4,186 |  |
| Plus: Amounts charged to cost and expense |  |  | 8 |  |  |  | 309 |  |
| Less: Amounts paid |  |  | (565 | ) |  |  | (2,975 | ) |
| Balance as of June 30, 2021 |  | $ | 1,520 |  |  | $ | 1,520 |  |

[0001564590-21-042027:notes:164]
| (In thousands) |  | For the Year Ended December 31, 2020 |  |
| Balance as of December 31, 2019 |  | $ | 1,568 |  |
| Plus: Amounts charged to cost and expense |  |  | 6,229 |  |
| Less: Amounts paid |  |  | (3,611 | ) |
| Balance as of December 31, 2020 |  | $ | 4,186 |  |

[0001564590-21-042027:notes:165]
[same as prior period, unchanged from 0001564590-21-025123:notes:164]

[0001564590-21-042027:notes:166]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Cost of revenue |  | $ | - |  |  | $ | 22 |  |  | $ | 15 |  |  | $ | 56 |  |
| Selling, general and administrative expenses |  |  | 3 |  |  |  | 489 |  |  |  | 145 |  |  |  | 572 |  |
| Research and development expenses |  |  | 5 |  |  |  | 681 |  |  |  | 149 |  |  |  | 1,117 |  |
| Total restructuring expenses |  | $ | 8 |  |  | $ | 1,192 |  |  | $ | 309 |  |  | $ | 1,745 |  |

[0001564590-21-042027:notes:167]
Components of restructuring expense by geographic area were as follows:

[0001564590-21-042027:notes:168]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| United States |  | $ | 3 |  |  | $ | 1,192 |  |  | $ | 212 |  |  | $ | 1,743 |  |
| International |  |  | 5 |  |  |  | — |  |  |  | 97 |  |  |  | 2 |  |
| Total restructuring expenses |  | $ | 8 |  |  | $ | 1,192 |  |  | $ | 309 |  |  | $ | 1,745 |  |


## us-gaap:SubsequentEventsTextBlock

[0001564590-21-042027:notes:169]
20. SUBSEQUENT EVENTS

[0001564590-21-042027:notes:170]
On August 4, 2021, we announced that our Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to the Company’s stockholders of record as of the close of business on August 19, 2021. The payment date will be September 2, 2021 in the aggregate amount of approximately $4.4 million.
