# ADTN 8-K — 0001564590-21-041127 filed 2021-08-05

## item codes, every 8-K on or before 2021-08-06

- 2021-08-05 0001564590-21-041127 — 2.02, 9.01
- 2021-05-18 0001564590-21-028541 — 5.07
- 2021-05-06 0001564590-21-024430 — 2.02, 9.01
- 2021-02-26 0001564590-21-009408 — 2.02, 9.01 — amendment of 0001564590-21-004167
- 2021-02-04 0001564590-21-004167 — 2.02, 9.01
- 2020-11-03 0001564590-20-049784 — 2.02, 9.01
- 2020-08-06 0001564590-20-037168 — 2.02, 9.01
- 2020-07-23 0001564590-20-033184 — 5.03, 9.01
- 2020-05-15 0001564590-20-025794 — 5.07
- 2020-05-11 0001564590-20-024328 — 5.02, 9.01
- 2020-05-07 0001564590-20-022297 — 2.02, 9.01
- 2020-02-25 0001564590-20-006448 — 2.02, 9.01
- 2020-02-06 0001564590-20-003580 — 2.02, 9.01
- 2019-10-31 0001564590-19-038936 — 2.02, 9.01
- 2019-10-10 0001564590-19-036732 — 2.02, 9.01
- 2019-09-20 0001564590-19-035144 — 2.02, 9.01
- 2019-08-21 0001564590-19-032757 — 3.01, 9.01
- 2019-07-18 0001564590-19-025186 — 2.02, 9.01
- 2019-05-09 0001564590-19-017956 — 5.07
- 2019-04-18 0001564590-19-011897 — 2.02, 9.01
- 2019-03-07 0001564590-19-006575 — 5.02, 9.01
- 2019-01-24 0001564590-19-001024 — 2.02, 9.01
- 2018-12-06 0001564590-18-030615 — 8.01, 9.01
- 2018-10-17 0001564590-18-024365 — 2.02, 9.01
- 2018-07-18 0001564590-18-016946 — 2.02, 9.01
- 2018-05-10 0001564590-18-012968 — 5.07
- 2018-04-18 0001564590-18-008361 — 2.02, 9.01
- 2018-03-21 0001564590-18-006409 — 8.01, 9.01
- 2018-01-17 0001564590-18-000519 — 2.02, 9.01
- 2017-12-29 0001564590-17-025375 — 2.02, 9.01
- 2017-11-16 0001193125-17-345232 — 5.02
- 2017-10-18 0001564590-17-019582 — 2.02, 9.01
- 2017-07-19 0001564590-17-013609 — 2.02, 9.01
- 2017-05-11 0001564590-17-010459 — 5.02, 9.01
- 2017-05-11 0001564590-17-010452 — 5.07
- 2017-04-19 0001193125-17-127926 — 2.02, 9.01
- 2017-02-07 0001193125-17-032714 — 8.01
- 2017-01-18 0001193125-17-011669 — 2.02, 9.01
- 2016-11-16 0001193125-16-769505 — 5.02, 9.01
- 2016-10-19 0001193125-16-741087 — 2.02, 9.01
- 2016-09-14 0001193125-16-709148 — 8.01, 9.01
- 2016-08-17 0001193125-16-683980 — 5.02, 9.01
- 2016-07-13 0001193125-16-646816 — 2.02, 9.01
- 2016-05-13 0001193125-16-590263 — 5.07
- 2016-04-13 0001193125-16-539019 — 2.02, 9.01
- 2016-04-08 0001193125-16-535035 — 7.01
- 2016-02-11 0001193125-16-459453 — 5.02, 9.01
- 2016-01-20 0001193125-16-432934 — 2.02, 9.01
- 2015-11-16 0001193125-15-378019 — 5.02, 9.01
- 2015-10-14 0001193125-15-343083 — 2.02, 9.01
- 2015-07-16 0001193125-15-254729 — 8.01, 9.01
- 2015-07-15 0001193125-15-253068 — 2.02, 9.01
- 2015-05-15 0001193125-15-189160 — 5.07, 9.01
- 2015-04-22 0001193125-15-140997 — 2.02, 9.01
- 2015-02-23 0001193125-15-056741 — 5.02, 9.01
- 2015-01-21 0001193125-15-015465 — 2.02, 9.01
- 2014-10-15 0001193125-14-372076 — 2.02, 9.01
- 2014-10-03 0001193125-14-363152 — 2.02, 9.01
- 2014-07-16 0001193125-14-269660 — 2.02, 9.01
- 2014-05-20 0001193125-14-205916 — 8.01, 9.01
- 2014-05-20 0001193125-14-205906 — 5.02, 9.01
- 2014-05-15 0001193125-14-201144 — 5.07
- 2014-04-16 0001193125-14-144665 — 2.02, 9.01
- 2014-04-03 0001193125-14-129578 — 2.02, 9.01
- 2014-01-22 0001157523-14-000154 — 2.02, 9.01
- 2013-10-15 0001193125-13-399540 — 5.02
- 2013-10-09 0001157523-13-004657 — 2.02, 9.01
- 2013-07-10 0001157523-13-003290 — 2.02, 9.01
- 2013-05-10 0001193125-13-213728 — 5.07
- 2013-05-03 0001193125-13-198816 — 8.01, 9.01
- 2013-04-10 0001157523-13-001730 — 2.02, 9.01
- 2013-01-16 0001157523-13-000139 — 2.02, 9.01
- 2012-10-10 0001157523-12-005081 — 2.02, 9.01
- 2012-10-03 0001193125-12-413609 — 7.01
- 2012-09-28 0001193125-12-408878 — 2.02, 9.01
- 2012-07-11 0001157523-12-003592 — 2.02, 9.01
- 2012-05-10 0001193125-12-225669 — 5.07
- 2012-05-10 0001193125-12-225639 — 8.01, 9.01
- 2012-04-11 0001157523-12-001772 — 2.02, 9.01
- 2012-03-15 0001193125-12-116494 — 2.02, 9.01
- 2012-01-18 0001157523-12-000174 — 2.02, 9.01
- 2011-12-12 0001193125-11-337271 — 7.01, 9.01
- 2011-10-13 0000950123-11-089785 — 5.03, 9.01
- 2011-10-12 0001157523-11-005682 — 2.02, 9.01
- 2011-07-13 0001157523-11-003986 — 2.02, 9.01
- 2011-05-09 0000950123-11-047191 — 5.02, 5.07, 9.01
- 2011-04-13 0001157523-11-002001 — 2.02, 9.01
- 2011-01-19 0001157523-11-000232 — 2.02, 9.01
- 2010-11-09 0000950123-10-103195 — 5.02, 9.01
- 2010-10-13 0001157523-10-005798 — 2.02, 9.01
- 2010-07-14 0001157523-10-004011 — 2.02, 9.01
- 2010-05-28 0000950123-10-053947 — 5.07
- 2010-04-14 0001157523-10-002022 — 2.02, 9.01
- 2010-01-20 0001157523-10-000200 — 2.02, 9.01
- 2009-10-28 0000950123-09-053984 — 8.01
- 2009-10-14 0001157523-09-006877 — 2.02, 9.01
- 2009-07-15 0001157523-09-004878 — 2.02, 9.01
- 2009-04-15 0001157523-09-002687 — 2.02, 9.01
- 2009-01-21 0001157523-09-000340 — 2.02, 9.01
- 2008-11-12 0001193125-08-233181 — 5.02, 9.01
- 2008-10-14 0001157523-08-007999 — 2.02, 9.01
- 2008-07-15 0001157523-08-005504 — 2.02, 9.01
- 2008-04-15 0001157523-08-002896 — 2.02, 9.01
- 2008-01-22 0001157523-08-000408 — 2.02, 9.01
- 2007-10-16 0001193125-07-219356 — 5.03, 9.01
- 2007-10-16 0001157523-07-009850 — 2.02, 9.01
- 2007-07-17 0001157523-07-006912 — 2.02, 9.01
- 2007-04-17 0001157523-07-003630 — 2.02, 9.01
- 2007-04-03 0001179022-07-000068 — 5.02
- 2007-03-28 0001179022-07-000064 — 5.02
- 2007-02-23 0001193125-07-038337 — 5.02
- 2007-02-23 0001193125-07-038335 — 5.02
- 2007-01-30 0001193125-07-015912 — 5.02, 9.01
- 2007-01-26 0001193125-07-014234 — 5.02
- 2007-01-23 0001157523-07-000494 — 2.02, 9.01 — amendment of 0001157523-07-000481
- 2007-01-23 0001157523-07-000481 — 2.02, 9.01
- 2006-10-17 0001157523-06-009945 — 2.02, 9.01
- 2006-07-18 0001157523-06-006929 — 2.02, 9.01
- 2006-06-08 0001193125-06-126486 — 1.01, 9.01
- 2006-05-10 0001193125-06-107316 — 1.01, 9.01
- 2006-04-18 0001157523-06-003699 — 2.02, 9.01
- 2006-02-03 0001179022-06-000014 — 1.01
- 2006-01-27 0001157523-06-000754 — 5.02, 9.01
- 2006-01-24 0001157523-06-000551 — 2.02, 9.01
- 2005-10-18 0001157523-05-008826 — 2.02, 9.01
- 2005-07-19 0001193125-05-143958 — 1.01, 5.02, 9.01
- 2005-07-19 0001193125-05-143957 — 2.02, 9.01
- 2005-05-20 0001193125-05-112019 — 1.01, 9.01
- 2005-04-19 0001157523-05-003418 — 2.02, 9.01
- 2005-01-25 0001193125-05-010721 — 2.02, 9.01
- 2004-10-12 0001193125-04-169652 — 2.02, 9.01
- 2004-07-13 0001193125-04-116820 — 12, 7
- 2004-04-14 0001193125-04-061547 — 12, 7
- 2004-01-21 0001193125-04-006366 — 12, 7
- 2003-10-14 0001193125-03-061018 — 12, 5, 7
- 2003-07-15 0001193125-03-019292 — 7, 9
- 2003-04-15 0000931763-03-000968 — 7, 9
- 1996-09-12 0000931763-96-000667 — 5, 7

## late-filing notifications on or before 2021-08-06

- 2019-08-12 0001564590-19-031524 — NT 10-Q, for the period ended 2019-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001564590-21-041127:8k_2_02:1]
EX-99.1
2
adtn-ex991_6.htm
EX-99.1

[0001564590-21-041127:8k_2_02:2]
adtn-ex991_6.htm

[0001564590-21-041127:8k_2_02:3]
EXHIBIT 99.1

[0001564590-21-041127:8k_2_02:4]
ADTRAN, Inc. Reports Earnings for the Second Quarter of 2021 and Declares Quarterly Cash Dividend

[0001564590-21-041127:8k_2_02:5]
HUNTSVILLE, Ala. — (August 4, 2021) — ADTRAN, Inc., (NASDAQ:ADTN) (“ADTRAN” or the “Company”), today announced financial results for the second quarter of 2021. For the quarter, revenue was $143.2 million. Net income for the second quarter of 2021 was $5.1 million and earnings per share, assuming dilution, was $0.10 per share. Non-GAAP net income was $8.1 million and non-GAAP earnings per share, assuming dilution, was $0.16 per share. Non-GAAP net income and non-GAAP earnings per share exclude acquisition-related expenses, amortizations and adjustments, stock-based compensation expense, restructuring expenses, amortization of pension actuarial losses, non-cash deferred compensation, change in valuation allowance related to our deferred tax assets, asset impairments and the tax effect of these adjustments to net income. The reconciliations between GAAP net income (loss) and earnings (loss) per share to non-GAAP net income (loss) and non-GAAP earnings (loss) per share are set forth in the table provided below.

[0001564590-21-041127:8k_2_02:6]
ADTRAN Chairman and Chief Executive Officer Tom Stanton stated, “Strong demand for fiber access continued to drive multiple segments of our business including infrastructure, in-home premises equipment and our SaaS platforms. Tier 3 regional operators, both in the U.S and Europe, showed exceptional strength with growth over 50% on a year-over-year basis. Demand continues to be strong and we believe we are in the early phases of this growth cycle.”

[0001564590-21-041127:8k_2_02:7]
The Company also announced that its Board of Directors declared a cash dividend for the second quarter of 2021. The quarterly cash dividend of $0.09 per common share is to be paid to the Company’s stockholders of record as of the close of business on August 19, 2021. The payment date will be September 2, 2021.

[0001564590-21-041127:8k_2_02:8]
The Company confirmed that it will hold a conference call to discuss its second quarter results on Thursday, August 5, 2021, at 9:30 a.m. Central Time. ADTRAN will webcast this conference call. To listen, simply visit ADTRAN’s Investor Relations site at www.adtran.com/investor approximately ten minutes prior to the start of the call, click on the event “ADTRAN to Release 2nd Quarter 2021 Financial Results and Earnings Call”, and click on the Webcast link.

[0001564590-21-041127:8k_2_02:9]
An online replay of the Company’s conference call, as well as the text of the Company's conference call, will be available on the Investor Relations site approximately 24 hours following the call and will remain available for at least 12 months. For more information, visit www.investors.adtran.com or email at investor.relations@adtran.com.

[0001564590-21-041127:8k_2_02:10]
About ADTRAN

[0001564590-21-041127:8k_2_02:11]
At ADTRAN, we believe amazing things happen when people connect. From the cloud edge to the subscriber edge, we help communications service providers around the world manage and scale services that connect people, places and things to advance human progress. Whether rural or urban, domestic or international, telco or cable, enterprise or residential—ADTRAN solutions optimize existing technology infrastructures and create new, multi-gigabit platforms that leverage cloud economics, data analytics, machine learning and open ecosystems—the future of global networking. Find more at ADTRAN.com, LinkedIn and Twitter.

[0001564590-21-041127:8k_2_02:12]
This press release contains forward-looking statements, generally identified by the use of words such as “believe,” “expect,” “intend,” “estimate,” “anticipate,” “will,” “may,” “could” and similar expressions, which forward-looking statements reflect management’s best judgment based on factors currently known. However, these statements involve risks and uncertainties, including: (i) risks and uncertainties related to the continued impact of the SARS-CoV-2 coronavirus/COVID-19 global pandemic (or variants of the SARS-CoV-2 coronavirus, including the Delta variant), including the severity and duration of the pandemic and the delivery, acceptance and effectiveness of vaccines, which could lead to a decrease in demand for the Company’s products and services, and which has disrupted, and could lead to further disruptions in, the Company’s supply chain, adversely impacting the operations and financial condition of the Company and its customers; actions that have been taken and that may be taken by the Company, its customers, suppliers and counterparties in response to the pandemic, including the implementation of alternative work arrangements for employees, which may delay the timing of some orders and expected deliveries and which may impact the Company’s ability to mitigate inefficiencies, delays and additional costs

[0001564590-21-041127:8k_2_02:13]
in the Company’s product development, sales, marketing and customer service efforts; the legal, regulatory and administrative developments that have occurred and may continue to occur at the federal, state and local levels and in foreign jurisdictions in response to the pandemic, including travel bans and restrictions, quarantines, shelter-in-place orders, and business limitations and shutdowns; potential disruptions, breaches, or other incidents affecting the proper operation, availability or security of the Company’s or its partners’ information systems; potential declines in revenues due to declining customer demand and deteriorating macroeconomic conditions; increased expenses related to labor, raw materials, freight or other expenditures; the impact of the COVID-19 pandemic on the Company’s liquidity, as well as risks associated with disruptions in the financial markets and the business of financial institutions as a result of the COVID-19 pandemic which could impact the Company from a financial perspective; the pace of recovery in our markets when the COVID-19 pandemic subsides, which could affect demand for our products; and (ii) the other risks detailed in the Company’s Annual Report on Form 10-K for the year ended December 31, 2020 and the Company’s quarterly report on Form 10-Q for the quarter ended March 31, 2021. These risks and uncertainties could cause actual results to differ materially from those in the forward-looking statements included in this press release.

[0001564590-21-041127:8k_2_02:14]
To provide additional transparency, we have disclosed in the table below non-GAAP operating income (loss), which has been reconciled to operating income (loss), and non-GAAP net income (loss) and non-GAAP earnings (loss) per share - basic and diluted, which have been reconciled to net income (loss) and earnings (loss) per share - basic and diluted, in each case as reported based on Generally Accepted Accounting Principles in the United States (“U.S. GAAP”). These non-GAAP financial measures exclude certain items which management believes are not reflective of the ongoing operating performance of the business. We believe this information is useful in providing period-to-period comparisons of the results of our ongoing operations. Additionally, these measures are used by management in our ongoing planning and annual budgeting processes. The presentation of non-GAAP operating income (loss), non-GAAP net income (loss) and non-GAAP earnings (loss) per share - basic and diluted, when combined with the U.S. GAAP presentation of operating income (loss), net income (loss) and earnings (loss) per share - basic and diluted, is beneficial to the overall understanding of ongoing operating performance of the Company.

[0001564590-21-041127:8k_2_02:15]
These non-GAAP financial measures are not prepared in accordance with, or an alternative for, U.S. GAAP and therefore should not be considered in isolation or as a substitution for analysis of our results as reported under U.S. GAAP. Additionally, our calculation of non-GAAP operating income (loss), non-GAAP net income (loss) and non-GAAP earnings (loss) per share - basic and diluted, may not be comparable to similar measures calculated by other companies.

[0001564590-21-041127:8k_2_02:16]
Condensed Consolidated Balance Sheets

[0001564590-21-041127:8k_2_02:17]
(Unaudited)

[0001564590-21-041127:8k_2_02:18]
(In thousands)

[0001564590-21-041127:8k_2_02:19]
|  | June 30, |  |  | December 31, |  |
|  | 2021 |  |  | 2020 |  |
| Assets |  |  |  |  |  |  |  |
| Current Assets |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 69,927 |  |  | $ | 60,161 |  |
| Restricted cash |  | 54 |  |  |  | 18 |  |
| Short-term investments |  | 2,818 |  |  |  | 3,131 |  |
| Accounts receivable, net |  | 122,669 |  |  |  | 98,827 |  |
| Other receivables |  | 20,187 |  |  |  | 21,531 |  |
| Inventory, net |  | 119,012 |  |  |  | 125,457 |  |
| Prepaid expenses and other current assets |  | 9,830 |  |  |  | 8,293 |  |
| Total Current Assets |  | 344,497 |  |  |  | 317,418 |  |
| Property, plant and equipment, net |  | 58,270 |  |  |  | 62,399 |  |
| Deferred tax assets, net |  | 9,165 |  |  |  | 9,869 |  |
| Goodwill |  | 6,968 |  |  |  | 6,968 |  |
| Intangibles, net |  | 21,354 |  |  |  | 23,470 |  |
| Other assets |  | 28,394 |  |  |  | 25,425 |  |
| Long-term investments |  | 82,778 |  |  |  | 80,130 |  |
| Total Assets | $ | 551,426 |  |  | $ | 525,679 |  |
| Liabilities and Stockholders' Equity |  |  |  |  |  |  |  |
| Accounts payable | $ | 66,499 |  |  | $ | 49,929 |  |
| Unearned revenue |  | 15,889 |  |  |  | 14,092 |  |
| Accrued expenses and other liabilities |  | 15,655 |  |  |  | 13,609 |  |
| Accrued wages and benefits |  | 15,681 |  |  |  | 15,262 |  |
| Income tax payable, net |  | 2,345 |  |  |  | 1,301 |  |
| Total Current Liabilities |  | 116,069 |  |  |  | 94,193 |  |
| Non-current unearned revenue |  | 7,030 |  |  |  | 6,888 |  |
| Pension liability |  | 17,566 |  |  |  | 18,664 |  |
| Deferred compensation liability |  | 28,769 |  |  |  | 25,866 |  |
| Other non-current liabilities |  | 6,477 |  |  |  | 7,124 |  |
| Total Liabilities |  | 175,911 |  |  |  | 152,735 |  |
| Stockholders' Equity |  | 375,515 |  |  |  | 372,944 |  |
| Total Liabilities and Stockholders' Equity | $ | 551,426 |  |  | $ | 525,679 |  |

[0001564590-21-041127:8k_2_02:20]
Condensed Consolidated Statements of Income (Loss)

[0001564590-21-041127:8k_2_02:21]
(Unaudited)

[0001564590-21-041127:8k_2_02:22]
(In thousands, except per share data)

[0001564590-21-041127:8k_2_02:23]
|  |  | Three Months Ended |  |  | Six Months Ended |  |  |
|  |  | June 30, |  |  | June 30, |  |  |
|  |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |  |
| Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Network Solutions |  | $ | 125,449 |  |  | $ | 111,323 |  |  | $ | 239,258 |  |  | $ | 208,695 |  |  |
| Services & Support |  |  | 17,783 |  |  |  | 17,392 |  |  |  | 31,507 |  |  |  | 34,543 |  |  |
| Total Revenue |  |  | 143,232 |  |  |  | 128,715 |  |  |  | 270,765 |  |  |  | 243,238 |  |  |
| Cost of Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Network Solutions |  |  | 70,014 |  |  |  | 64,071 |  |  |  | 135,015 |  |  |  | 115,697 |  |  |
| Services & Support |  |  | 10,550 |  |  |  | 11,172 |  |  |  | 19,481 |  |  |  | 22,469 |  |  |
| Total Cost of Revenue |  |  | 80,564 |  |  |  | 75,243 |  |  |  | 154,496 |  |  |  | 138,166 |  |  |
| Gross Profit |  |  | 62,668 |  |  |  | 53,472 |  |  |  | 116,269 |  |  |  | 105,072 |  |  |
| Selling, general and administrative expenses |  |  | 30,866 |  |  |  | 30,799 |  |  |  | 58,301 |  |  |  | 57,419 |  |  |
| Research and development expenses |  |  | 27,871 |  |  |  | 28,712 |  |  |  | 55,372 |  |  |  | 58,571 |  |  |
| Asset impairments |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 65 |  |  |
| Operating Income (Loss) |  |  | 3,931 |  |  |  | (6,039 | ) |  |  | 2,596 |  |  |  | (10,983 | ) |  |
| Interest and dividend income |  |  | 253 |  |  |  | 331 |  |  |  | 543 |  |  |  | 687 |  |  |
| Interest expense |  |  | (6 | ) |  |  | — |  |  |  | (12 | ) |  |  | (1 | ) |  |
| Net investment gain (loss) |  |  | 2,009 |  |  |  | 9,852 |  |  |  | 3,005 |  |  |  | (1,025 | ) |  |
| Other income (expense), net |  |  | 26 |  |  |  | (1,757 | ) |  |  | 2,025 |  |  |  | (628 | ) |  |
| Income (Loss) Before Income Taxes |  |  | 6,213 |  |  |  | 2,387 |  |  |  | 8,157 |  |  |  | (11,950 | ) |  |
| Income tax (expense) benefit |  |  | (1,127 | ) |  |  | (1,635 | ) |  |  | (2,175 | ) |  |  | 2,733 |  |  |
| Net Income (Loss) |  | $ | 5,086 |  |  | $ | 752 |  |  | $ | 5,982 |  |  | $ | (9,217 | ) |  |
| Weighted average shares outstanding – basic |  |  | 48,449 |  |  |  | 47,958 |  |  |  | 48,393 |  |  |  | 47,957 |  |  |
| Weighted average shares outstanding – diluted |  |  | 49,426 | (1) |  |  | 48,254 | (1) |  |  | 49,225 | (1) |  |  | 47,957 |  |  |
| Earnings (loss) per common share – basic |  | $ | 0.10 |  |  | $ | 0.02 |  |  | $ | 0.12 |  |  | $ | (0.19 | ) |  |
| Earnings (loss) per common share – diluted |  | $ | 0.10 | (1) |  | $ | 0.02 | (1) |  | $ | 0.12 | (1) |  | $ | (0.19 | ) |  |

[0001564590-21-041127:8k_2_02:24]
(1) Assumes exercise of dilutive stock awards calculated under the treasury stock method.

[0001564590-21-041127:8k_2_02:25]
Condensed Consolidated Statements of Cash Flows

[0001564590-21-041127:8k_2_02:26]
(Unaudited)

[0001564590-21-041127:8k_2_02:27]
(In thousands)

[0001564590-21-041127:8k_2_02:28]
|  |  | Six Months Ended |  |
|  |  | June 30, |  |
|  |  | 2021 |  |  | 2020 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income (loss) |  | $ | 5,982 |  |  | $ | (9,217 | ) |
| Adjustments to reconcile net income (loss) to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 8,232 |  |  |  | 8,404 |  |
| (Gain) loss on investments |  |  | (3,255 | ) |  |  | 1,025 |  |
| Stock-based compensation expense |  |  | 3,615 |  |  |  | 3,446 |  |
| Deferred income taxes |  |  | 441 |  |  |  | (5 | ) |
| Other |  |  | 53 |  |  |  | 138 |  |
| Asset impairments |  |  | — |  |  |  | 65 |  |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  |  | (24,322 | ) |  |  | (4,727 | ) |
| Other receivables |  |  | 1,412 |  |  |  | (9,468 | ) |
| Inventory, net |  |  | 5,940 |  |  |  | (7,878 | ) |
| Prepaid expenses, other current assets and other assets |  |  | (4,767 | ) |  |  | 1,444 |  |
| Accounts payable |  |  | 16,814 |  |  |  | 17,389 |  |
| Accrued expenses and other liabilities |  |  | 6,999 |  |  |  | 2,097 |  |
| Income taxes payable, net |  |  | 1,069 |  |  |  | (1,032 | ) |
| Net cash provided by operating activities |  |  | 18,213 |  |  |  | 1,681 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (2,210 | ) |  |  | (3,148 | ) |
| Proceeds from sales and maturities of available-for-sale investments |  |  | 20,597 |  |  |  | 63,318 |  |
| Purchases of available-for-sale investments |  |  | (20,121 | ) |  |  | (31,897 | ) |
| Acquisition of note receivable |  |  | — |  |  |  | (523 | ) |
| Net cash provided by (used in) investing activities |  |  | (1,734 | ) |  |  | 27,750 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Proceeds from stock option exercises |  |  | 3,552 |  |  |  | — |  |
| Tax withholdings related to stock-based compensation settlements |  |  | (113 | ) |  |  | — |  |
| Dividend payments |  |  | (8,735 | ) |  |  | (8,665 | ) |
| Repayment of bonds payable |  |  | — |  |  |  | (24,600 | ) |
| Net cash used in financing activities |  |  | (5,296 | ) |  |  | (33,265 | ) |
| Net increase (decrease) in cash, cash equivalents and restricted cash |  |  | 11,183 |  |  |  | (3,834 | ) |
| Effect of exchange rate changes |  |  | (1,381 | ) |  |  | 306 |  |
| Cash, cash equivalents and restricted cash, beginning of period |  |  | 60,179 |  |  |  | 73,773 |  |
| Cash, cash equivalents and restricted cash, end of period |  | $ | 69,981 |  |  | $ | 70,245 |  |
| Supplemental disclosure of non-cash investing activities: |  |  |  |  |  |  |  |  |
| Right-of-use assets obtained in exchange for lease obligations |  | $ | 275 |  |  | $ | 93 |  |
| Purchases of property, plant and equipment included in accounts payable |  | $ | 144 |  |  | $ | 198 |  |

[0001564590-21-041127:8k_2_02:29]
Supplemental Information

[0001564590-21-041127:8k_2_02:30]
Reconciliation of Operating Income (Loss) to Non-GAAP Operating Income (Loss)

[0001564590-21-041127:8k_2_02:31]
(Unaudited)

[0001564590-21-041127:8k_2_02:32]
|  |  | Three Months Ended June 30, |  |  |  | Six Months ended June 30, |  |  |
|  |  | 2021 |  |  | 2020 |  |  |  | 2021 |  |  | 2020 |  |  |
| Operating Income (Loss) |  | $ | 3,931 |  |  | $ | (6,039 | ) |  |  | $ | 2,596 |  |  | $ | (10,983 | ) |  |
| Acquisition-related expenses, amortizations and adjustments |  |  | 2,384 | (1) |  |  | 1,100 | (5) |  |  |  | 3,429 | (8) |  |  | 2,457 | (11) |  |
| Stock-based compensation expense |  |  | 1,808 | (2) |  |  | 1,655 | (6) |  |  |  | 3,615 | (9) |  |  | 3,446 | (12) |  |
| Restructuring expenses |  |  | 8 | (3) |  |  | 1,192 | (7) |  |  |  | 309 | (10) |  |  | 1,745 | (13) |  |
| Deferred compensation adjustments |  |  | 1,994 | (4) |  |  | 3,433 | (4) |  |  |  | 2,550 | (4) |  |  | (26 | ) (4) |  |
| Asset impairments |  |  | — |  |  |  | — |  |  |  |  | — |  |  |  | 65 | (14) |  |
| Non-GAAP Operating Income (Loss) |  | $ | 10,125 |  |  | $ | 1,341 |  |  |  | $ | 12,499 |  |  | $ | (3,296 | ) |  |

[0001564590-21-041127:8k_2_02:33]
(1) $1.9 million is included in selling, general and administrative expenses and $0.5 million is included in research and development expenses on the condensed consolidated statements of income (loss).

[0001564590-21-041127:8k_2_02:34]
(2) $0.1 million is included in total cost of revenue, $1.1 million is included in selling, general and administrative expenses and $0.6 million is included in research and development expenses on the condensed consolidated statements of income (loss).

[0001564590-21-041127:8k_2_02:35]
(3) Less than $0.1 million is included in each of selling, general and administrative expenses and research and development expenses on the condensed consolidated statements of income (loss).

[0001564590-21-041127:8k_2_02:36]
(4) Includes non-cash change in fair value of equity investments held in the ADTRAN, Inc. Deferred Compensation Program for Employees, all of which is included in selling, general and administrative expenses on the condensed consolidated statement of income (loss).

[0001564590-21-041127:8k_2_02:37]
(5) $0.6 million is included in selling, general and administrative expenses and $0.5 million is included in research and development expenses on the condensed consolidated statements of income (loss).

[0001564590-21-041127:8k_2_02:38]
(6) $0.1 million is included in total cost of revenue, $1.0 million is included in selling, general and administrative expenses and $0.6 million is included in research and development expenses on the condensed consolidated statements of income (loss).

[0001564590-21-041127:8k_2_02:39]
(7) $0.5 million is included in selling, general and administrative expenses and $0.7 million is included in research and development expenses on the condensed consolidated statements of income (loss).

[0001564590-21-041127:8k_2_02:40]
(8) $2.4 million is included in selling, general and administrative expenses and $1.0 million is included in research and development expenses on the condensed consolidated statements of income (loss).

[0001564590-21-041127:8k_2_02:41]
(9) $0.2 million is included in total cost of revenue, $2.2 million is included in selling, general and administrative expenses and $1.2 million is included in research and development expenses on the condensed consolidated statements of income (loss).

[0001564590-21-041127:8k_2_02:42]
(10) $0.1 million is included in selling, general and administrative expenses and $0.2 million is included in research and development expenses on the condensed consolidated statements of income (loss).

[0001564590-21-041127:8k_2_02:43]
(11) $0.3 million is included in total cost of revenue, $1.2 million is included in selling, general and administrative expenses and $1.0 million is included in research and development expenses on the condensed consolidated statements of income (loss).

[0001564590-21-041127:8k_2_02:44]
(12) $0.2 million is included in total cost of revenue, $2.0 million is included in selling, general and administrative expenses and $1.2 million is included in research and development expenses on the condensed consolidated statements of income (loss).

[0001564590-21-041127:8k_2_02:45]
(13) $0.1 million is included in total cost of revenue, $0.5 million is included in selling, general and administrative expenses and $1.1 million is included in research and development expenses on the condensed consolidated statements of income (loss).

[0001564590-21-041127:8k_2_02:46]
(14) Includes abandonment of certain information technology projects.

[0001564590-21-041127:8k_2_02:47]
Supplemental Information

[0001564590-21-041127:8k_2_02:48]
Reconciliation of Net Income (Loss) and Earnings (Loss) per Common Share – Basic and Diluted to Non-GAAP

[0001564590-21-041127:8k_2_02:49]
Net Income (Loss) and Non-GAAP Earnings (Loss) per Common Share – Basic and Diluted

[0001564590-21-041127:8k_2_02:50]
(Unaudited)

[0001564590-21-041127:8k_2_02:51]
|  |  | Three Months Ended June 30, |  |  |  | Six Months ended June 30, |  |  |  |  |
|  |  | 2021 |  |  | 2020 |  |  |  | 2021 |  |  | 2020 |  |  |  |  |
| Net Income (Loss) |  | $ | 5,086 |  |  | $ | 752 |  |  |  | $ | 5,982 |  |  | $ | (9,217 | ) |  |  |  |
| Acquisition-related expenses, amortizations and adjustments |  |  | 2,384 |  |  |  | 1,100 |  |  |  |  | 3,429 |  |  |  | 2,457 |  |  |  |  |
| Stock-based compensation expense |  |  | 1,808 |  |  |  | 1,655 |  |  |  |  | 3,615 |  |  |  | 3,446 |  |  |  |  |
| Restructuring expenses |  |  | 8 |  |  |  | 1,192 |  |  |  |  | 309 |  |  |  | 1,745 |  |  |  |  |
| Pension expense(1) |  |  | 275 |  |  |  | 235 |  |  |  |  | 553 |  |  |  | 472 |  |  |  |  |
| Deferred compensation adjustments(2) |  |  | 546 |  |  |  | 445 |  |  |  |  | 814 |  |  |  | (1,342 | ) (3) |  |  |  |
| Valuation allowance related to deferred tax assets |  |  | (727 | ) |  |  | (2,512 | ) |  |  |  | 1,958 |  |  |  | 3,578 |  |  |  |  |
| Asset impairments |  |  | — |  |  |  | — |  |  |  |  | — |  |  |  | 65 |  |  |  |  |
| Tax effect of adjustments to net income (loss) |  |  | (1,243 | ) |  |  | (1,233 | ) |  |  |  | (2,195 | ) |  |  | (1,810 | ) |  |  |  |
| Non-GAAP Net Income (Loss) |  | $ | 8,137 |  |  | $ | 1,634 |  |  |  | $ | 14,465 |  |  | $ | (606 | ) |  |  |  |
| Weighted average shares outstanding – basic |  |  | 48,449 |  |  |  | 47,958 |  |  |  |  | 48,393 |  |  |  | 47,957 |  |  |  |  |
| Weighted average shares outstanding – diluted |  |  | 49,426 |  |  |  | 48,254 |  |  |  |  | 49,225 |  |  |  | 47,957 |  |  |  |  |
| Earnings (loss) per common share - basic |  | $ | 0.10 |  |  | $ | 0.02 |  |  |  | $ | 0.12 |  |  | $ | (0.19 | ) |  |  |  |
| Earnings (loss) per common share - diluted |  | $ | 0.10 |  |  | $ | 0.02 |  |  |  | $ | 0.12 |  |  | $ | (0.19 | ) |  |  |  |
| Non-GAAP earnings (loss) per common share - basic |  | $ | 0.17 |  |  | $ | 0.04 |  |  |  | $ | 0.30 |  |  | $ | (0.01 | ) |  |  |  |
| Non-GAAP earnings (loss) per common share - diluted |  | $ | 0.16 |  |  | $ | 0.04 |  |  |  | $ | 0.29 |  |  | $ | (0.01 | ) |  |  |  |

[0001564590-21-041127:8k_2_02:52]
(1) Includes amortization of actuarial losses related to the Company's pension plan for employees in certain foreign countries.

[0001564590-21-041127:8k_2_02:53]
(2) Includes a non-cash change in fair value of equity investments held in deferred compensation plans offered to certain employees.

[0001564590-21-041127:8k_2_02:54]
(3) Includes a net investment gain of $1.5 million related to the out of period remeasurement to historical cost basis of certain long-term investments held in the Company's stock as part of one of the Company’s deferred compensation plans.
