# ADTN MD&A — 0001564590-21-042027


## mdna

[0001564590-21-042027:mdna:1]
[same as prior period, unchanged from 0001564590-21-025123:mdna:1]

[0001564590-21-042027:mdna:2]
[same as prior period, unchanged from 0001564590-21-025123:mdna:2]

[0001564590-21-042027:mdna:3]
This discussion is designed to provide the reader with information that will assist in understanding our condensed consolidated financial statements, the changes in certain key items in those financial statements from period to period, and the primary factors that accounted for those changes, as well as how certain accounting principles affect our condensed consolidated financial statements. See “Cautionary Note Regarding Forward-Looking Statements” on page 3 of this report for a description of important factors that could cause actual results to differ from expected results. See also Part 1, Item 1A, Risk Factors, of the 2020 Form 10‑K and Part II, Item 1A, Risk Factors of this Form 10-Q.

[0001564590-21-042027:mdna:4]
[same as prior period, unchanged from 0001564590-21-025123:mdna:4]

[0001564590-21-042027:mdna:5]
ADTRAN is a leading global provider of networking and communications platforms, systems and services focused on the broadband access market, serving a diverse domestic and international customer base in multiple countries that includes Tier-1, -2 and -3 service providers, alternative service providers, such as utilities, municipalities and fiber overbuilders, cable/MSOs, SMBs and distributed enterprises. Our innovative solutions and services enable voice, data, video and internet-communications across a variety of network infrastructures and are currently in use by millions worldwide. We support our customers through our direct global sales organization and our distribution networks. Our success depends upon our ability to increase unit volume and market share through the introduction of new products and succeeding generations of products having optimal selling prices and increased functionality as compared to both the prior generation of a product and to the products of competitors in order to gain market share. In order to service our customers and grow revenue, we are continually conducting research and development of new products addressing customer needs and testing those products for the specific requirements of the particular customers. We are focused on being a top global supplier of access infrastructure and related value-added solutions from the cloud edge to the subscriber edge. We offer a broad portfolio of flexible software and hardware network solutions and services that enable service providers to meet today’s service demands, while enabling them to transition to the fully-converged, scalable, highly-automated, cloud-controlled voice, data, internet and video network of the future. In addition to our corporate headquarters in Huntsville, Alabama, we have sales and research and development facilities in strategic global locations.

[0001564590-21-042027:mdna:6]
An important part of our strategy is to reduce the cost of each succeeding product generation and to pass on the cost savings achieved to our customers in order to gain market share and/or improve gross margins. As a part of this strategy, we seek to be a high-quality and low-cost provider of products in our markets. Our success to date is attributable in large measure to our ability to design our products initially with a view to their subsequent redesign, allowing both increased functionality and reduced manufacturing costs in each succeeding product generation. This strategy enables us to sell succeeding generations of products to existing customers, while increasing our market share by selling these enhanced products to new customers.

[0001564590-21-042027:mdna:7]
We ended the second quarter of 2021 with a year-over-year revenue increase of 11.3% as compared to the three months ended June 30, 2020, driven by increased shipments to regional service providers in the U.S., alternative network operators in Europe and international Tier-1 customers. During the second quarter of 2021, we had three 10% revenue customers geographically diversified, two U.S. distributors and one international customer. Our year-over-year domestic revenue growth of 12.1% was driven by growth in Tier-3 carrier categories due to additional fiber access deployments in both access equipment and CPE as well as a certain U.S.-based MSO. Internationally, our revenue increased by 9.8% compared to the prior year period, primarily driven by access network builds in the Asia Pacific region, with a focus on Australia, increased shipments to alternative network operators and a Tier-1 operator in Europe. Additionally, fiber access continued to experience revenue growth, and, during 2020 we announced multiple long-term Tier-1 next-generation fiber access deals in Europe and the U.S., positioning us well for the next access network upgrade investment cycle.

[0001564590-21-042027:mdna:8]
In March 2020, the World Health Organization declared the novel coronavirus (COVID-19) outbreak a global pandemic. The SARS-CoV-2 coronavirus (or variants of the SARS-CoV-2 coronavirus, including the Delta variant) continues to spread throughout the U.S. and the world and has resulted in authorities implementing varying  measures to contain the virus, including travel bans and restrictions, quarantines, shelter-in-place orders, and business limitations and shutdowns. Although vaccines have been approved and are being distributed, it cannot be predicted how long it will take before market conditions return to normal and there can be no assurance that the economic recovery will occur or offset the uncertainty and instability triggered by the pandemic. New and potentially more contagious variants of the COVID-19 virus are developing in several countries, including regions in which we have significant operations. The COVID-19 variants could further amplify the impact of the pandemic. While we are unable to accurately predict the full impact that the COVID-19 global pandemic will have on our results of operations, financial condition, liquidity and cash flows due to numerous uncertainties, including the duration and severity of the pandemic and containment measures, our compliance with these measures has impacted our day-to-day operations and could disrupt our business and operations, as well as that of our key customers, suppliers and other counterparties, for an indefinite period of time. We have experienced some impact to our supply chain given COVID-19 and the related global semiconductor chip shortage, including delays in supply chain deliveries, extended lead times and shortages of some key components, some raw material cost increases and slowdowns at certain production facilities. We have also had to increase our volume of inventory to ensure supply continuity during the pandemic. In addition, we have experienced significant increases in freight-related costs. While throughout the pandemic we have seen increased demand in networking requirements and utilization due to social distancing guidelines issued by governments, as well as COVID-19 related reductions in travel and infrastructure expenses, it is possible that we could experience some slowdown in demand, further supply chain issues and an increased impact from the ongoing semiconductor shortage and shortages of certain other key components as the pandemic continues. If the impacts of this shortage are more severe than we expect, it could result in longer lead times, inventory supply challenges and further increased costs, all of which could result in the deterioration of our results, potentially for a longer period than currently anticipated. To support the health and well-being of our employees, customers, partners and communities, many of our employees are working remotely as of the date of filing this report. However, there is risk that a number of our employees could be infected with COVID-19, including our key personnel. In addition, actions that have been taken and that may be taken by the Company, its customers, suppliers and counterparties in response to the pandemic, including the implementation of alternative work arrangements for certain employees, as well as the impacts to our supply chain, including delays in supply chain deliveries and the related global semiconductor chip shortage, have delayed and may continue to delay the timing of some orders and expected deliveries. Lastly, even after the COVID-19 pandemic has subsided, we may continue to experience adverse impacts to our business as a result of any economic recession that has occurred or may occur in the future as a result of the COVID-19 pandemic.

[0001564590-21-042027:mdna:9]
[same as prior period, unchanged from 0001564590-21-025123:mdna:9]

[0001564590-21-042027:mdna:10]
[same as prior period, unchanged from 0001564590-21-025123:mdna:10]

[0001564590-21-042027:mdna:11]
[same as prior period, unchanged from 0001564590-21-025123:mdna:11]

[0001564590-21-042027:mdna:12]
[same as prior period, unchanged from 0001564590-21-025123:mdna:12]

[0001564590-21-042027:mdna:13]
[same as prior period, unchanged from 0001564590-21-025123:mdna:13]

[0001564590-21-042027:mdna:14]
[same as prior period, unchanged from 0001564590-21-025123:mdna:14]

[0001564590-21-042027:mdna:15]
Our operating results may also fluctuate as a result of a number of other factors, including a decline in general economic and market conditions, specifically the decline that initially resulted from the COVID-19 pandemic and that may recur, foreign currency exchange rate movements, increased competition, customer order patterns, changes in product and services mix, timing differences between price decreases and product cost reductions, product warranty returns, expediting costs, tariffs and announcements of new products by us or our competitors. Additionally, maintaining sufficient inventory levels to assure prompt delivery of our products increases the amount of inventory that may become obsolete and increases the risk that the obsolescence of this inventory may have an adverse effect on our business and operating results. Also, not maintaining sufficient inventory levels to assure prompt delivery of our products may cause us to incur expediting costs to meet customer delivery requirements, which may negatively impact our operating results in a given quarter. In recent years, the Company initiated restructuring plans to realign its expense structure with the reduction in revenue experienced and with overall Company objectives. Management assessed the efficiency of our operations and consolidated locations and personnel, among other things, and implemented certain cost savings initiatives, where possible. See Note 19 of the Notes to Condensed Consolidated Financial Statements included in Part 1, Item 1 of this report for additional information on this restructuring.

[0001564590-21-042027:mdna:16]
[same as prior period, unchanged from 0001564590-21-025123:mdna:16]

[0001564590-21-042027:mdna:17]
[same as prior period, unchanged from 0001564590-21-025123:mdna:17]

[0001564590-21-042027:mdna:18]
[same as prior period, unchanged from 0001564590-21-025123:mdna:18]

[0001564590-21-042027:mdna:19]
[same as prior period, unchanged from 0001564590-21-025123:mdna:19]

[0001564590-21-042027:mdna:20]
See Note 1 of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this report for a full description of recent accounting pronouncements, including the expected dates of adoption and estimated effects on results of operations and financial condition, which is incorporated herein by reference.

[0001564590-21-042027:mdna:21]
31

[0001564590-21-042027:mdna:22]
RESULTS OF OPERATIONS – THREE AND SIX MONTHS ENDED JUNE 30, 2021 COMPARED TO THREE AND SIX MONTHS ENDED JUNE 30, 2020

[0001564590-21-042027:mdna:23]
[same as prior period, unchanged from 0001564590-21-025123:mdna:23]

[0001564590-21-042027:mdna:24]
|  |  | Three Months Ended |  |  | Six Months Ended |  |  |
|  |  | June 30, |  |  | June 30, |  |  |
|  |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |  |
| Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Network Solutions |  |  | 87.6 |  | % |  | 86.5 |  | % |  | 88.4 |  | % |  | 85.8 |  | % |
| Services & Support |  |  | 12.4 |  |  |  | 13.5 |  |  |  | 11.6 |  |  |  | 14.2 |  |  |
| Total Revenue |  |  | 100.0 |  |  |  | 100.0 |  |  |  | 100.0 |  |  |  | 100.0 |  |  |
| Cost of Revenue |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Network Solutions |  |  | 48.9 |  |  |  | 49.8 |  |  |  | 49.9 |  |  |  | 47.6 |  |  |
| Services & Support |  |  | 7.4 |  |  |  | 8.7 |  |  |  | 7.2 |  |  |  | 9.2 |  |  |
| Total Cost of Revenue |  |  | 56.2 |  |  |  | 58.5 |  |  |  | 57.1 |  |  |  | 56.8 |  |  |
| Gross Profit |  |  | 43.8 |  |  |  | 41.5 |  |  |  | 42.9 |  |  |  | 43.2 |  |  |
| Selling, general and administrative expenses |  |  | 21.5 |  |  |  | 23.9 |  |  |  | 21.5 |  |  |  | 23.6 |  |  |
| Research and development expenses |  |  | 19.5 |  |  |  | 22.3 |  |  |  | 20.5 |  |  |  | 24.1 |  |  |
| Asset impairments |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |
| Operating Income (Loss) |  |  | 2.7 |  |  |  | (4.7 | ) |  |  | 1.0 |  |  |  | (4.5 | ) |  |
| Interest and dividend income |  |  | 0.2 |  |  |  | 0.3 |  |  |  | 0.2 |  |  |  | 0.3 |  |  |
| Interest expense |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |
| Net investment gain (loss) |  |  | 1.4 |  |  |  | 7.7 |  |  |  | 1.1 |  |  |  | (0.4 | ) |  |
| Other income (expense), net |  |  | — |  |  |  | (1.4 | ) |  |  | 0.7 |  |  |  | (0.3 | ) |  |
| Income (Loss) Before Income Taxes |  |  | 4.3 |  |  |  | 1.9 |  |  |  | 3.0 |  |  |  | (4.9 | ) |  |
| Income tax (expense) benefit |  |  | (0.8 | ) |  |  | (1.3 | ) |  |  | (0.8 | ) |  |  | 1.1 |  |  |
| Net Income (Loss) |  |  | 3.6 |  | % |  | 0.6 |  | % |  | 2.2 |  | % |  | (3.8 | ) | % |

[0001564590-21-042027:mdna:25]
[same as prior period, unchanged from 0001564590-21-025123:mdna:25]

[0001564590-21-042027:mdna:26]
Our revenue increased 11.3% from $128.7 million for the three months ended June 30, 2020 to $143.2 million for the three months ended June 30, 2021 and increased 11.3% from $243.2 million for the six months ended June 30, 2020 to $270.8 million for the six months ended June 30, 2021. The increase in revenue for the three and six months ended June 30, 2021 was primarily attributable to a $8.2 million and $11.3 million increase in Access & Aggregation revenue, respectively, and a $7.4 million and $19.8 million increase in Subscriber Solutions & Experience revenue, respectively, partially offset by a $1.1 million and $3.6 million decrease in the revenue of our Traditional & Other Products, respectively.

[0001564590-21-042027:mdna:27]
Network Solutions segment revenue increased 12.7% from $111.3 million for the three months ended June 30, 2020 to $125.4 million for the three months ended June 30, 2021 and increased 14.6% from $208.7 million for the six months ended June 30, 2020 to $239.3 million for the six months ended June 30, 2021. The increase in revenue for the three and six months ended June 30, 2021 was due primarily to revenue of Subscriber Solutions & Experience and Access & Aggregation products. The increase in Subscriber Solutions & Experience revenue for the three and six months ended June 30, 2021 was primarily attributable to increased volume of network termination and Fiber CPE. The increase in the Access & Aggregation category for the three and six months ended June 30, 2021 was due to increased volume of fiber access and residential gateways. While we expect that revenue from Traditional & Other Products will continue to decline over time, this revenue may fluctuate and continue for years because of the time required for our customers to transition to newer technologies.

[0001564590-21-042027:mdna:28]
Services & Support segment revenue increased 2.2% from $17.4 million for the three months ended June 30, 2020 to $17.8 million for the three months ended June 30, 2021 and decreased 8.8% from $34.5 million for the six months ended June 30, 2020 to $31.5 million for the six months ended June 30, 2021. The increase in revenue for the three months ended June 30, 2021 was primarily attributable to increased maintenance and managed services. The decrease in revenue for the six months ended June 30, 2021 was primarily attributable to decreased network planning and implementation services partially offset by an increase in maintenance services.

[0001564590-21-042027:mdna:29]
International revenue, which is included in the amounts for both the Network Solutions and Services & Support segments discussed above, increased 9.8% from $44.3 million for the three months ended June 30, 2020 to $48.6 million for the three months ended June 30, 2021 and increased 12.3% from $79.8 million for the six months ended June 30, 2020 to $89.6 million for the six months ended June 30, 2021. International revenue, as a percentage of total revenue, decreased from 34.4% for the three months ended June 30, 2020 to 33.9% for the three months ended June 30, 2021 and increased from 32.8% for the six months ended June 30, 2020 to 33.1% for the six months ended June 30, 2021. The decrease in international revenue as a percentage of total revenue for the three months ended June 30, 2021, was primarily attributable to a reduction in shipments to two international Tier-1 customers. The increase in percentage of international revenue for the six months ended June 30, 2021, was primarily driven by access network builds in the Asia Pacific region with a focus on Australia, increased shipments to alternative network operators in Europe and revenue from a Tier-1 operator in Europe.

[0001564590-21-042027:mdna:30]
Our international revenue is largely focused on broadband infrastructure and is consequently affected by the decisions of our customers as to timing for installation of new technologies, expansion of their networks and/or network upgrades. Our international customers must make these decisions in the regulatory and political environment in which they operate – both nationally and in some instances, regionally – whether of a multi-country region or a more local region within a country. The competitive landscape in certain international markets is also affected by the increased presence of Asian manufacturers that seek to compete aggressively on price. Our revenue and operating income in some international markets can be negatively impacted by a strengthening U.S. dollar. Consequently, while we expect the global trend towards deployment of more robust broadband speeds and access to continue creating additional market opportunities for us, the factors described above may result in negative pressure on revenue and operating income.

[0001564590-21-042027:mdna:31]
[same as prior period, unchanged from 0001564590-21-025123:mdna:31]

[0001564590-21-042027:mdna:32]
As a percentage of revenue, cost of revenue decreased from 58.5% for the three months ended June 30, 2020 to 56.2% for the three months ended June 30, 2021 and increased from 56.8% for the six months ended June 30, 2020 to 57.1% for the six months ended June 30, 2021. For the three months ended June 30, 2021, the decrease was primarily attributable to changes in customer and product mix and changes in services and support mix. For the six months ended June 30, 2021, the increase was primarily attributable to changes in customer and product mix, a regional revenue shift and the negative impact of supply constraints.

[0001564590-21-042027:mdna:33]
Network Solutions cost of revenue, as a percentage of that segment’s revenue, decreased from 57.6% for the three months ended June 30, 2020 to 55.8% for the three months ended June 30, 2021 and increased from 55.4% for the six months ended June 30, 2020 to 56.4% for the six months ended June 30, 2021. The decrease in cost of revenue as a percentage of revenue for the three months ended June 30, 2021 was primarily attributable to changes in customer and product mix and changes in services and support mix. The increase in cost of revenue as a percentage of revenue for the six months ended June 30, 2021 was primarily attributable to changes in customer and product mix, a regional revenue shift, and the negative impact of supply constraints.

[0001564590-21-042027:mdna:34]
[same as prior period, unchanged from 0001564590-21-025123:mdna:34]

[0001564590-21-042027:mdna:35]
Services & Support cost of revenue, as a percentage of that segment’s revenue, decreased from 64.2% for the three months ended June 30, 2020 to 59.3% for the three months ended June 30, 2021 and decreased from 65.0% for the six months ended June 30, 2020 to 61.8% for the six months ended June 30, 2021. The decrease in cost of revenue as a percentage of revenue for the three and six months ended June 30, 2021 was primarily attributable to customer mix, changes in services and support mix.

[0001564590-21-042027:mdna:36]
Services & Support revenue is comprised of network planning and implementation, maintenance, support and cloud-based management services, with network planning and implementation being the largest and fastest growing component in the long-term. Compared to our other services, such as maintenance, support and cloud-based management services, our network planning and implementation services typically utilize a higher percentage of internal and subcontracted engineers, professionals and contractors to perform the work for customers. The additional costs incurred to perform these infrastructure and labor-intensive services inherently result in lower average gross margins as compared to maintenance and support services. Within the Services & Support segment, we do expect variability in gross margins from quarter-to-quarter based on the mix of the services recognized.

[0001564590-21-042027:mdna:37]
[same as prior period, unchanged from 0001564590-21-025123:mdna:38]

[0001564590-21-042027:mdna:38]
As a percentage of revenue, selling, general and administrative expenses decreased from 23.9% for the three months ended June 30, 2020 to 21.5% for the three months ended June 30, 2021 and decreased from 23.6% for the six months ended June 30, 2020 to 21.5% for the six months ended June 30, 2021. Selling, general and administrative expenses as a percentage of revenue will generally fluctuate whenever there is a significant fluctuation in revenue for the periods being compared.

[0001564590-21-042027:mdna:39]
Selling, general and administrative expenses increased 0.2% from $30.8 million for the three months ended June 30, 2020 to $30.9 million for the three months ended June 30, 2021 and increased 1.5% from $57.4 million for the six months ended June 30, 2020 to $58.3 million for the six months ended June 30, 2021. The increase in selling, general and administrative expenses for the three months ended June 30, 2021 was primarily attributable to increased professional and consulting fees, partially offset by the capitalization of certain costs related to our ongoing ERP implementation project. The increase in selling, general and administrative expenses for the six months ended June 30, 2021 was primarily attributable to increased deferred compensation related costs and professional and consulting fees, partially offset by decreases in travel related expense and the capitalization of certain costs related to our ongoing ERP implementation project.

[0001564590-21-042027:mdna:40]
[same as prior period, unchanged from 0001564590-21-025123:mdna:41]

[0001564590-21-042027:mdna:41]
As a percentage of revenue, research and development expenses decreased from 22.3% for the three months ended June 30, 2020 to 19.5% for the three months ended June 30, 2021 and decreased from 24.1% for the six months ended June 30, 2020 to 20.4% for the six months ended June 30, 2021. Research and development expenses as a percentage of revenue will fluctuate whenever there are incremental product development activities or significant fluctuations in revenue for the periods being compared.

[0001564590-21-042027:mdna:42]
Research and development expenses decreased 2.9% from $28.7 million for the three months ended June 30, 2020 to $27.9 million for the three months ended June 30, 2021 and decreased 5.5% from $58.6 million for the six months ended June 30, 2020 to $55.4 million for the six months ended June 30, 2021. The decrease in research and development expenses for the three and six months ended June 30, 2021 was primarily attributable to lower personnel costs which were mainly the result of our restructuring programs, partially offset by increased contract services.

[0001564590-21-042027:mdna:43]
We expect to continue to incur research and development expenses in connection with our new and existing products. We continually evaluate new product opportunities and engage in significant research and product development efforts, which provides for new product development, enhancement of existing products and product cost reductions. We may incur significant research and development expenses prior to the receipt of revenue from a major new product group.

[0001564590-21-042027:mdna:44]
[same as prior period, unchanged from 0001564590-21-025123:mdna:45]

[0001564590-21-042027:mdna:45]
Asset impairments, which were $0.1 million for the six months ended June 30, 2020, related to the abandonment of certain information technology projects in which we had previously capitalized costs. There were no asset impairments recognized during the three months ended June 30, 2020 or June 30, 2021 or for the six months ended June 30, 2021.

[0001564590-21-042027:mdna:46]
[same as prior period, unchanged from 0001564590-21-025123:mdna:47]

[0001564590-21-042027:mdna:47]
Interest and dividend income remained constant at $0.3 million for the three months ended June 30, 2020 and June 30, 2021 and decreased 21.0% from $0.7 million for the six months ended June 30, 2020 to $0.5 million for the six months ended June 30, 2021. The decrease in interest and dividend income was primarily attributable to a decline in our investment balances as well as a decrease in the rate of return on our investments due to lower interest rates. Our total investments decreased from $93.4 million as of June 30, 2020 to $85.6 million as of June 30, 2021.

[0001564590-21-042027:mdna:48]
[same as prior period, unchanged from 0001564590-21-025123:mdna:49]

[0001564590-21-042027:mdna:49]
Interest expense was less than $0.1 million for each of the three and six months ended June 30, 2021 and 2020. Interest expense during the first half of 2021 was primarily related to our Revolving Credit Agreement that we entered into during the fourth quarter of 2020.  Interest expense during the first half of 2020 was primarily related to certain taxable revenue bonds.

[0001564590-21-042027:mdna:50]
[same as prior period, unchanged from 0001564590-21-025123:mdna:51]

[0001564590-21-042027:mdna:51]
We recognized a net investment gain of $9.9 million and $2.0 million for the three months ended June 30, 2020 and June 30, 2021, respectively, and a net investment loss of $1.0 million and a net investment gain of $3.0 million for the six months ended June 30, 2020 and June 30, 2021, respectively. The fluctuations in our net investments were primarily attributable to changes in the fair value of our securities recognized during the period. We expect that any future market volatility, whether from COVID-19 or other factors, will result in continued volatility in our investment portfolio. See Note 6 of the Notes to Condensed Consolidated Financial Statements, included in Part I, Item 1 of this report, and “Investing Activities” in “Liquidity and Capital Resources” below for additional information.

[0001564590-21-042027:mdna:52]
OTHER INCOME (EXPENSE), NET

[0001564590-21-042027:mdna:53]
Other income (expense), net, which primarily consisted of gains and losses on foreign currency transactions, improved from expense of $1.8 million for the three months ended June 30, 2020 to income of less than $0.1 million for the three months ended June 30, 2021 and improved from expense of $0.6 million for the six months ended June 30, 2020 to income of $2.0 million for the six months ended June 30, 2021.

[0001564590-21-042027:mdna:54]
[same as prior period, unchanged from 0001564590-21-025123:mdna:55]

[0001564590-21-042027:mdna:55]
Our effective tax rate decreased from an expense of 68.5% for the three months ended June 30, 2020 to an expense of 18.1% for the three months ended June 30, 2021 and increased from a benefit of 22.9% for the six months ended June 30, 2020 to an expense of 26.7% for the six months ended June 30, 2021. The change in the effective tax rate for the three months ended June 30, 2021 was impacted by tax expense in our international operations and additional changes in the valuation allowance related to our domestic operations. The change in the effective tax rate for the six months ended June 30, 2021 was primarily driven by a tax benefit of $7.4 million recognized during the six months ended June 30, 2020 as a result of the enactment of the CARES Act in March 2020. See Note 4 of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this report for additional information.

[0001564590-21-042027:mdna:56]
[same as prior period, unchanged from 0001564590-21-025123:mdna:57]

[0001564590-21-042027:mdna:57]
As a result of the above factors, net income (loss) increased from net income of $0.8 million for the three months ended June 30, 2020 to net income of $5.1 million for the three months ended June 30, 2021 and improved from a net loss of $9.2 million for the six months ended June 30, 2020 to net income of $6.0 million for the six months ended June 30, 2021.

[0001564590-21-042027:mdna:58]
[same as prior period, unchanged from 0001564590-21-025123:mdna:59]

[0001564590-21-042027:mdna:59]
[same as prior period, unchanged from 0001564590-21-025123:mdna:60]

[0001564590-21-042027:mdna:60]
We have historically financed, and we currently expect to continue to finance, our ongoing business with existing cash, investments and cash flow from operations. We have used, and expect to continue to use, existing cash, investments and cash generated from operations for working capital, business acquisitions, purchases of treasury stock, shareholder dividends and other general corporate purposes, including product development activities to enhance our existing products and develop new products, expansion of our sales and marketing activities and capital expenditures. We believe that our cash and cash equivalents, investments and cash generated from operations to be adequate to meet our operating and capital needs for at least the next 12 months.

[0001564590-21-042027:mdna:61]
As of June 30, 2021, cash on hand was $69.9 million and short-term investments were $2.8 million, which resulted in available short-term liquidity of $72.7 million, of which $45.8 million was held by our foreign subsidiaries. As of December 31, 2020, cash on hand was $60.2 million and short-term investments were $3.1 million, which resulted in available short-term liquidity of $63.3 million, of which $49.7 million was held by our foreign subsidiaries. Generally, we intend to permanently reinvest funds held outside the U.S., except to the extent that any of these funds can be repatriated without withholding tax.

[0001564590-21-042027:mdna:62]
During the fourth quarter of 2020, the Company entered into a Revolving Credit and Security Agreement and related Promissory Note (together, the “Revolving Credit Agreement”) with Cadence Bank, N.A., as lender (the “Lender”). The Revolving Credit Agreement provides the Company with a new $10.0 million secured revolving credit facility. Loans under the Revolving Credit Agreement will bear interest at a rate equal to 1.50% over the screen rate as obtained by Reuter’s, Bloomberg or another commercially available source as may be designated by the Lender from time to time; provided, however, that in no event shall the applicable rate of interest under the Revolving Credit Agreement be less than 1.50% per annum. Such loans are secured by all of the cash, securities, securities entitlements and investment property in a certain bank account, as outlined in the Revolving Credit Agreement, at a maximum loan-to-value ratio of 75% determined by dividing the full commitment amount under the Revolving Credit Agreement on the date of testing, determined by the Lender each fiscal quarter, by the market value of the collateral. Based on the market value of the collateral at June 30, 2021, the Company had $10.0 million of loan availability under the revolving credit facility as of such date. The Revolving Credit Agreement matures on November 4, 2021, subject to earlier termination upon the occurrence of certain events of default. The Company entered into the Revolving Credit Agreement in order to increase the flexibility and management of its short-term liquidity. To date, the Company has not made any draws under the Revolving Credit Agreement. The Company agreed to certain negative covenants that are customary for credit arrangements of this type, including, among other things, restrictions on the Company’s ability to enter into mergers, acquisitions or other business combination transactions, grant liens or suffer a material adverse change in the condition or affairs (financial or otherwise) of the Company, which negative covenants are subject to certain exceptions. The Company must be in compliance with all covenants to be able to draw on the line of credit. As of June 30, 2021, the Company was in compliance with all covenants.

[0001564590-21-042027:mdna:63]
[same as prior period, unchanged from 0001564590-21-025123:mdna:64]

[0001564590-21-042027:mdna:64]
Our working capital, defined as current assets less current liabilities, increased 2.3% from $223.2 million as of December 31, 2020 and $228.4 million as of June 30, 2021, and our current ratio, defined as current assets divided by current liabilities, decreased from 3.37 as of December 31, 2020 to 2.97 as of June 30, 2021. The increase in our working capital and decrease in our current ratio were primarily attributable to an increase in accounts receivable, cash and cash equivalents and prepaid expenses and other current assets partially offset by an increase in accounts payable and a decrease in inventory. The quick ratio, defined as cash, cash equivalents, short-term investments, and net accounts receivable, divided by current liabilities, decreased from 1.72 as of December 31, 2020 to 1.68 as of June 30, 2021. The decrease in the quick ratio was primarily attributable to increases in accounts receivable and cash and cash equivalents partially offset by an increase in accounts payable.

[0001564590-21-042027:mdna:65]
Net accounts receivable increased 24.1% from $98.8 million as of December 31, 2020 to $122.7 million as of June 30, 2021. Our allowance for expected credit losses was $38 thousand as of December 31, 2020. There was no allowance for expected credit losses as of June 30, 2021. The increase in net accounts receivable was due to an increase in sales volume and the timing of shipments within the quarter. Quarterly accounts receivable DSO increased from 70 days as of December 31, 2020 to 78 days as of June 30, 2021. The increase in DSO was due to the timing of product shipments and customer mix.

[0001564590-21-042027:mdna:66]
Other receivables decreased 7.0% from $21.5 million as of December 31, 2020 to $20.2 million as of June 30, 2021. The decrease in other receivables was primarily attributable to a decrease in contract manufacturer purchases and tax receivables partially offset by an increase in contract assets.

[0001564590-21-042027:mdna:67]
Quarterly inventory turnover increased from 2.5 turns as of December 31, 2020 to 2.7 turns as of June 30, 2021. Inventory decreased 5.1% from $125.5 million as of December 31, 2020 to $119.0 million as of June 30, 2021. While we remain subject to COVID-19 uncertainties related to supply chain and demand, we expect inventory levels to fluctuate as we attempt to maintain sufficient inventory in response to seasonal cycles of our business and ensuring competitive lead times while managing the risk of inventory.

[0001564590-21-042027:mdna:68]
Accounts payable increased 33.2% from $49.9 million as of December 31, 2020 to $66.5 million as of June 30, 2021. Accounts payable will fluctuate due to variations in the timing of the receipt of supplies, inventory and services and our subsequent payments for these purchases.

[0001564590-21-042027:mdna:69]
[same as prior period, unchanged from 0001564590-21-025123:mdna:70]

[0001564590-21-042027:mdna:70]
Capital expenditures totaled approximately $2.2 million and $3.1 million for the six months ended June 30, 2021 and 2020, respectively. These expenditures were primarily used to purchase manufacturing and test equipment, software, computer hardware and to finance building improvements.

[0001564590-21-042027:mdna:71]
Our combined short-term and long-term investments increased $2.3 million from $83.3 million as of December 31, 2020 to $85.6 million as of June 30, 2021. This increase reflects the impact of net realized and unrealized gains and losses on our investments.

[0001564590-21-042027:mdna:72]
We typically invest all available cash not required for immediate use in operations, primarily in securities that we believe bear minimal risk of loss. See Note 6 of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this report for additional information. As of June 30, 2021, our corporate bonds, municipal bonds, asset-backed bonds, mortgage/agency bonds, U.S. government bonds, other government bonds and variable-rate demand notes were classified as available-for-sale and had a combined duration of 1.66 years with an average Standard & Poor’s credit rating of AA-. Because our investment portfolio has a high-quality rating and contractual maturities of short duration, we are able to obtain prices for these bonds derived from observable market inputs, or for similar securities traded in an active market, on a daily basis.

[0001564590-21-042027:mdna:73]
Our long-term investments increased 3.3% from $80.1 million as of December 31, 2020 to $82.8 million as of June 30, 2021.  Our investments include various marketable equity securities classified as long-term investments with a fair market value of $12.1 million and $11.0 million as of June 30, 2021 and December 31, 2020, respectively. Long-term investments as of June 30, 2021 and December 31, 2020 also included $25.9 million and $23.9 million, respectively, related to our deferred compensation plans.

[0001564590-21-042027:mdna:74]
[same as prior period, unchanged from 0001564590-21-025123:mdna:75]

[0001564590-21-042027:mdna:75]
[same as prior period, unchanged from 0001564590-21-025123:mdna:76]

[0001564590-21-042027:mdna:76]
In July 2003, our Board of Directors elected to begin declaring quarterly dividends on our common stock considering the tax treatment of dividends and adequate levels of Company liquidity. During each of the six months ended June 30, 2021 and 2020, we paid dividends totaling $8.7 million. The continued payment of dividends is at the discretion of the Company’s Board of Directors and is subject to general business conditions and ongoing financial results of the Company.

[0001564590-21-042027:mdna:77]
[same as prior period, unchanged from 0001564590-21-025123:mdna:78]

[0001564590-21-042027:mdna:78]
To accommodate employee stock option exercises, the Company issued 0.1 million and 0.2 million shares of treasury stock which resulted in proceeds of $2.3 million and $3.6 million during the three and six months ended June 30, 2021, respectively. No stock options were exercised during the three and six months ended June 30, 2020.

[0001564590-21-042027:mdna:79]
[same as prior period, unchanged from 0001564590-21-025123:mdna:80]

[0001564590-21-042027:mdna:80]
We do not have off-balance sheet financing arrangements and have not engaged in any related party transactions or arrangements with unconsolidated entities or other persons that are reasonably likely to materially affect liquidity or the availability of or requirements for capital resources.

[0001564590-21-042027:mdna:81]
[same as prior period, unchanged from 0001564590-21-025123:mdna:82]

[0001564590-21-042027:mdna:82]
Certain contracts, customers and jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of June 30, 2021 and December 31, 2020, we had commitments related to these bonds totaling $21.2 million and $15.3 million, respectively, which expire at various dates through August 2024. Although the triggering events vary from contract to contract, in general we would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which we believe is remote.

[0001564590-21-042027:mdna:83]
In June 2020, the Company entered into a letter of credit with a bank to guarantee performance obligations under a contract with a certain customer. The obligations under this customer contract will be performed over multiple years. We reached the maximum value of our minimum collateral requirement of $15.0 million during the three months ended March 31, 2021, as the Company reached certain milestones through the first quarter of 2021 as outlined in the customer contract. The letter of credit was secured by a pledge of a portion of the Company’s fixed-income securities, which totaled $18.2 million as of June 30, 2021, of which less than $0.1 million is included in restricted cash and $18.2 million is included in long-term investments on the Condensed Consolidated Balance Sheet. This pledged collateral value will fluctuate as the Company changes the mix of the pledged collateral between restricted cash and investments. Any shortfalls in the minimum collateral value are required to be restored by the Company from available cash and cash equivalents, short-term investments and/or long-term investments. The collateral under the letter of credit will be released when all obligations under the customer contract have been met. As of June 30, 2021, the Company was in compliance with all contractual requirements under the letter of credit.

[0001564590-21-042027:mdna:84]
We have committed to invest up to an aggregate of $5.0 million in a private equity fund, of which $4.9 million has been invested as of June 30, 2021.

[0001564590-21-042027:mdna:85]
During the six months ended June 30, 2021, there have been no other material changes in contractual obligations and commercial commitments from those discussed in the 2020 Form 10-K.

[0001564590-21-042027:mdna:86]
38
