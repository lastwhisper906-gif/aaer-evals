# ADTN note change history — 0001564590-21-025123 → 0001564590-21-042027


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- added (2021-08-06):
[0001564590-21-042027:note_history:1]
On March 31, 2020, a shareholder derivative suit, captioned Johnson (Derivatively on behalf of ADTRAN) v. Stanton, et al., Case No. 5:20-cv-00447, was filed in the U.S. District Court for the Northern District of Alabama against two of the Company’s current executive officers, one of its former executive officers, and certain current and former members of its Board of Directors. The derivative suit alleges, among other things, that the defendants made or caused the Company to make materially false and misleading statements regarding, and/or failed to disclose material adverse facts about, the Company’s business, operations and prospects, specifically relating to the Company’s internal control over financial reporting, excess and obsolete inventory reserves, financial results and demand from certain customers. The case was temporarily stayed pending an order on the defendants’ motion to dismiss in a separate securities class action case that included similar factual allegations, Burbridge v. ADTRAN, Inc., et al., Case No. 5:20-cv-00050-LCB (N.D. Ala.). The Burbridge case was dismissed on March 31, 2021, and the time to appeal the dismissal has expired, such that the dismissal is now final.  Following the dismissal, the plaintiff in the shareholder derivative suit sent a demand letter dated June 29, 2021 to ADTRAN’s Board of Directors.  The letter contains similar allegations to those made in the plaintiff’s filed complaint and in the now dismissed securities class action, and it demands, among other things, that the Board commence an investigation into the alleged wrongdoing.  We expect that the derivative suit will remain stayed pending the Board’s response to the demand. At this time, we are unable to predict the outcome of or estimate the possible loss or range of loss, if any, associated with the derivative lawsuit or the demand letter.

- changed (2021-08-06):
[0001564590-21-042027:note_history:2]
Certain contracts, customers and jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of June 30, 2021 and December 31, 2020, we had commitments related to these bonds totaling $21.2 million and $15.2 million, respectively, which expire at various dates through August 2024. Although the triggering events vary from contract to contract, in general we would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which we believe is remote.
  (was, 2021-05-06, similarity 0.9922):
[0001564590-21-025123:note_history:2]
Certain contracts, customers and jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of March 31, 2021 and December 31, 2020, we had commitments related to these bonds totaling $21.2 million and $15.2 million, respectively, which expire at various dates through August 2024. Although the triggering events vary from contract to contract, in general we would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which we believe is remote.

- changed (2021-08-06):
[0001564590-21-042027:note_history:3]
In June 2020, the Company entered into a letter of credit with a bank to guarantee performance obligations under a contract with a certain customer. The obligations under this customer contract will be performed over multiple years. We reached the maximum value of our minimum collateral requirement of $15.0 million during the three months ended March 31, 2021 as the Company reached certain milestones through the first quarter of 2021 as outlined in the customer contract. The letter of credit was secured by a pledge of a portion of the Company’s fixed-income securities, which totaled $18.2 million as of June 30, 2021, of which less than $0.1 million is included in restricted cash and $18.2 million is included in long-term investments on the Condensed Consolidated Balance Sheet. This pledged collateral value will fluctuate as the Company changes the mix of the pledged collateral between restricted cash and investments. Any shortfalls in the minimum collateral value are required to be restored by the Company from available cash and cash equivalents, short-term investments and/or long-term investments. The collateral under the letter of credit will be released when all obligations under the customer contract have been met. As of June 30, 2021, the Company was in compliance with all contractual requirements under the letter of credit.
  (was, 2021-05-06, similarity 0.9893):
[0001564590-21-025123:note_history:3]
In June 2020, the Company entered into a letter of credit with a bank to guarantee performance obligations under a contract with a certain customer. The obligations under this customer contract will be performed over multiple years. We reached the maximum value of our minimum collateral requirement of $15.0 million during the three months ended March 31, 2021 as the Company reached certain milestones through the first quarter of 2021 as outlined in the customer contract. The letter of credit was secured by a pledge of a portion of the Company’s fixed-income securities, which totaled $18.2 million as of March 31, 2021, of which $0.1 million is included in restricted cash and $18.1 million is included in long-term investments on the Condensed Consolidated Balance Sheet. This pledged collateral value will fluctuate as the Company changes the mix of the pledged collateral between restricted cash and investments. Any shortfalls in the minimum collateral value are required to be restored by the Company from available cash and cash equivalents, short-term investments and/or long-term investments. The collateral under the letter of credit will be released when all obligations under the customer contract have been met. As of March 31, 2021, the Company was in compliance with all contractual requirements under the letter of credit.

- changed (2021-08-06):
[0001564590-21-042027:note_history:4]
We have committed to invest up to an aggregate of $5.0 million in a private equity fund, of which $4.9 million has been invested as of June 30, 2021.
  (was, 2021-05-06, similarity 0.9353):
[0001564590-21-025123:note_history:4]
We have committed to invest up to an aggregate of $5.0 million in a private equity fund, of which $4.9 million has been applied as of March 31, 2021.

- removed (2021-08-06):
[0001564590-21-025123:note_history:5]
Securities Class Action Lawsuit

- removed (2021-08-06):
[0001564590-21-025123:note_history:6]
On March 31, 2021, the U.S. District for the Northern District of Alabama dismissed without prejudice a purported stockholder class action lawsuit, captioned Burbridge v. ADTRAN, Inc. et al, Docket No. 19-cv-09619 originally filed on October 17, 2019. This matter has been fully resolved by agreement among the parties, with no further action to be taken by the plaintiffs and each party bearing its own costs.

- removed (2021-08-06):
[0001564590-21-025123:note_history:7]
On March 31, 2020, a shareholder derivative suit, captioned Johnson (Derivatively on behalf of ADTRAN) v. T. Stanton, M. Foliano, R. Shannon, and Board of Directors, case no. 5:20-cv-00447, was filed in the U.S. District Court of Northern Alabama against two of the Company’s current executive officers, one of its former executive officers and its Board of Directors. The derivative suit, which is purportedly brought on behalf of ADTRAN, claims that the defendants made materially false and misleading statements regarding, and/or failed to disclose  material  adverse  facts  about,  the  Company’s  business,  operations  and  prospects,  specifically  relating  to  the  Company’s  internal  control  over  financial reporting, excess and obsolete inventory reserves, financial results and demand from certain customers. These are similar allegations as the shareholder class action that was dismissed without prejudice by the Court on March 31, 2021, and fully resolved by mutual agreement of the parties on May 3, 2021. The parties to the shareholder derivative suit agreed to a joint stipulation requesting a stay in the proceedings due to the resolution of the shareholder class action that remains in effect at least until May 19, 2021. The Company and its defendants disagree with the claims made in the complaint, and the defendants intend to vigorously defend against this lawsuit. At this time, we are unable to predict the outcome of or estimate the possible loss or range of loss, if any, associated with this lawsuit.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2021-08-06):
[0001564590-21-042027:note_history:8]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenue and expense during the reporting period. The more significant estimates include excess and obsolete inventory reserves, warranty reserves, customer rebates, determination and accrual of deferred revenue components of multi-element sales agreements, estimated costs to complete obligations associated with deferred and accrued revenues and network installations, estimated income tax provision and income tax contingencies, fair value of stock-based compensation, assessment of goodwill and other intangibles for impairment, estimated lives of intangible assets, estimated pension liability and fair value of investments. Actual amounts could differ significantly from these estimates.
  (was, 2021-05-06, similarity 0.936):
[0001564590-21-025123:note_history:8]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenue and expense during the reporting period. The more significant estimates include excess and obsolete inventory reserves, warranty reserves, customer rebates, determination and accrual of deferred revenue components of multiple element sales agreements, estimated costs to complete obligations associated with deferred and accrued revenues and network installations, estimated income tax provision and income tax contingencies, fair value of stock-based compensation, assessment of goodwill and other intangibles for impairment, estimated lives of intangible assets, estimated pension, and liability and fair value of investments, evaluation of other-than-temporary declines in the value of investments and the allowance for current expected credit losses. Actual amounts could differ significantly from these estimates.

- changed (2021-08-06):
[0001564590-21-042027:note_history:9]
We assessed certain accounting matters that generally require consideration of forecasted financial information in context with the information reasonably available to us and the unknown future impacts of the SARS-CoV-2 coronavirus/COVID-19 global pandemic (or variants of the SARS-CoV-2 coronavirus, including the Delta variant) as of June 30, 2021 and through the date of this report. The accounting matters assessed included, but were not limited to, the allowance for expected credit losses, stock-based compensation, carrying value of goodwill, intangibles and other long-lived assets, financial assets, valuation allowances for tax assets and revenue recognition. While there was not a material impact to our consolidated financial statements as of and for the six months ended June 30, 2021 resulting from these assessments, future conditions related to the magnitude and duration of the COVID-19 pandemic, as well as other factors, could result in material impacts to our consolidated financial statements in future reporting periods.
  (was, 2021-05-06, similarity 0.7132):
[0001564590-21-025123:note_history:9]
We assessed certain accounting matters that generally require consideration of forecasted financial information in context with the information reasonably available to us and the unknown future impacts of the novel coronavirus (“COVID-19”) as of March 31, 2021 and through the date of this report. The accounting matters assessed included, but were not limited to, the allowance for doubtful accounts, stock-based compensation, carrying value of goodwill, intangibles and other long-lived assets, financial assets, valuation allowances for tax assets and revenue recognition. While there was not a material impact to our consolidated financial statements as of and for the quarter ended March 31, 2021 resulting from these assessments, future assessments related to the COVID-19 pandemic, as well as other factors, could result in material impacts to our consolidated financial statements in future reporting periods.

- changed (2021-08-06):
[0001564590-21-042027:note_history:10]
We recently adopted the following accounting standards, which had the following impacts on our condensed consolidated financial statements:
  (was, 2021-05-06, similarity 0.9627):
[0001564590-21-025123:note_history:10]
We recently adopted the following accounting standards, which had the following impacts on our consolidated financial statements:

- changed (2021-08-06):
[0001564590-21-042027:note_history:11]
In August 2018, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2018-14, Compensation – Retirement Benefits – Defined Benefit Plans – General (Subtopic 715-20): Disclosure Framework – Changes to the Disclosure Requirements for Defined Benefit Plans, which makes changes to and clarifies the disclosure requirements related to defined benefit pension and other postretirement plans. ASU 2018-14 requires additional disclosures related to the reasons for significant gains and losses affecting the benefit obligation and an explanation of any other significant changes in the benefit obligation or plan assets that are not otherwise apparent in other disclosures required by Accounting Standards Codification (“ASC”) 715. ASU 2018-14 also clarifies the guidance in ASC 715 to require disclosure of the projected benefit obligation (“PBO”) and fair value of plan assets for pension plans with PBOs in excess of plan assets and the accumulated benefit obligation (“ABO”) and fair value of plan assets for pension plans with ABOs in excess of plan assets. ASU 2018-14 became effective for public business entities for fiscal years ending after December 15, 2020. The adoption of this standard did not have a material effect on the disclosures in the condensed consolidated financial statements.
  (was, 2021-05-06, similarity 0.9981):
[0001564590-21-025123:note_history:11]
In August 2018, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2018-14, Compensation – Retirement Benefits – Defined Benefit Plans – General (Subtopic 715-20): Disclosure Framework – Changes to the Disclosure Requirements for Defined Benefit Plans, which makes changes to and clarifies the disclosure requirements related to defined benefit pension and other postretirement plans. ASU 2018-14 requires additional disclosures related to the reasons for significant gains and losses affecting the benefit obligation and an explanation of any other significant changes in the benefit obligation or plan assets that are not otherwise apparent in other disclosures required by Accounting Standards Codification (“ASC”) 715. ASU 2018-14 also clarifies the guidance in ASC 715 to require disclosure of the projected benefit obligation (“PBO”) and fair value of plan assets for pension plans with PBOs in excess of plan assets and the accumulated benefit obligation (“ABO”) and fair value of plan assets for pension plans with ABOs in excess of plan assets. ASU 2018-14 became effective for public business entities for fiscal years ending after December 15, 2020. The adoption of this standard did not have a material effect on the disclosures in the condensed consolidation financial statements.

- changed (2021-08-06):
[0001564590-21-042027:note_history:12]
In December 2019, the FASB issued ASU 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes, which simplifies the accounting for income taxes by removing various exceptions, such as the exception to the incremental approach for intra-period tax allocation when there is a loss from continuing operations and income or a gain from other items. The amendments in this update also simplify the accounting for income taxes related to income-based franchise taxes and require that an entity reflect enacted tax laws or rates in the annual effective tax rate computation in the interim period that includes the enactment date. The Company early adopted ASU 2019-12 on April 1, 2020, which was applied on a prospective basis as if the Company adopted the standard on January 1, 2020. The Company early adopted the standard to take advantage of the simplification of rules for income taxes on intra-period tax allocations. Specifically, the adoption of this standard resulted in the recognition of approximately $0.1 million of tax benefit in other comprehensive income (loss) for the three months ended March 31, 2020, that otherwise would have been recognized in continuing operations had the intra-period tax allocation been completed. There were no other impacts from this standard on the condensed consolidated financial statements.
  (was, 2021-05-06, similarity 0.9507):
[0001564590-21-025123:note_history:12]
In December 2019, the FASB issued ASU 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes, which simplifies the accounting for income taxes by removing various exceptions, such as the exception to the incremental approach for intra-period tax allocation when there is a loss from continuing operations and income or a gain from other items. The amendments in this update also simplify the accounting for income taxes related to income-based franchise taxes and require that an entity reflect enacted tax laws or rates in the annual effective tax rate computation in the interim period that includes the enactment date. The Company early adopted ASU 2019-12 on April 1, 2020, which was applied on a prospective basis as if the Company adopted the standard on January 1, 2020. The Company early adopted the standard to take advantage of the simplification of rules for income taxes on intra-period tax allocations. Specifically, the adoption of this standard resulted in the recognition of approximately $0.1 million of tax benefit in other comprehensive income (loss) for the three months ended March 31, 2020, that otherwise would have been recognized in continuing operations had the intra-period tax allocation been completed. There were no other impacts from this standard on the Condensed Consolidated Balance Sheets, Condensed Consolidated Statements of Income (Loss) or Condensed Consolidated Statements of Cash Flows.

- changed (2021-08-06):
[0001564590-21-042027:note_history:13]
There are currently no recent accounting pronouncements that have not yet been adopted and that would have a material effect, once adopted, on the condensed consolidated financial statements.
  (was, 2021-05-06, similarity 0.7182):
[0001564590-21-025123:note_history:13]
There are currently no recent accounting pronouncements that have not yet been adopted and that would have a material effect, once adopted, on the Condensed Consolidated Balance Sheets, Condensed Consolidated Statements of Income (Loss) or Condensed Consolidated Statements of Cash Flows.


## us-gaap:DebtDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-08-06):
[0001564590-21-042027:note_history:14]
On November 4, 2020, the Company, as borrower, entered into a Revolving Credit and Security Agreement and related Promissory Note (together, the “Revolving Credit Agreement”) with Cadence Bank, N.A., as lender (the “Lender”). The Revolving Credit Agreement provides the Company with a new $10.0 million secured revolving credit facility. Loans under the Revolving Credit Agreement will bear interest at a rate equal to 1.50% over the screen rate as obtained by Reuter’s, Bloomberg or another commercially available source as may be designated by the Lender from time to time; provided, however, that in no event shall the applicable rate of interest under the Revolving Credit Agreement be less than 1.50% per annum. Such loans are secured by all of the cash, securities, securities entitlements and investment property in a certain bank account, as outlined in the Revolving Credit Agreement, at a maximum loan-to-value ratio of 75% determined by dividing the full commitment amount under the Revolving Credit Agreement on the date of testing, determined by the Lender each fiscal quarter, by the market value of the collateral. The Revolving Credit Agreement matures on November 4, 2021, subject to earlier termination upon the occurrence of certain events of default. The Company had not made any draws under the Revolving Credit Agreement as of June 30, 2021.
  (was, 2021-05-06, similarity 0.9966):
[0001564590-21-025123:note_history:14]
On November 4, 2020, the Company, as borrower, entered into a Revolving Credit and Security Agreement and related Promissory Note (together, the “Revolving Credit Agreement”) with Cadence Bank, N.A., as lender (the “Lender”). The Revolving Credit Agreement provides the Company with a new $10.0 million secured revolving credit facility. Loans under the Revolving Credit Agreement will bear interest at a rate equal to 1.50% over the screen rate as obtained by Reuter’s, Bloomberg  or  another  commercially  available  source  as  may  be  designated  by  the  Lender  from  time  to  time;  provided,  however,  that  in  no  event  shall  the applicable rate of interest under the Revolving Credit Agreement be less than 1.50% per annum. Such loans are secured by all of the cash, securities, securities entitlements  and  investment  property  in  a  certain  bank  account,  as  outlined  in  the  Revolving  Credit  Agreement,  at  a  maximum  loan-to-value  ratio  of  75% determined by dividing the full commitment amount under the Revolving Credit Agreement on the date of testing, determined by the Lender each fiscal quarter, by the market value of the collateral. The Revolving Credit Agreement matures on November 4, 2021, subject to earlier termination upon the occurrence of certain events of default. The Company had not made any draws under the Revolving Credit Agreement as of March 31, 2021.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2021-08-06):
[0001564590-21-042027:note_history:15]
The following debt securities and other investments were included on the Condensed Consolidated Balance Sheet and recorded at fair value:
  (was, 2021-05-06, similarity 0.9964):
[0001564590-21-025123:note_history:15]
The following debt securities and other investments were included on the Condensed Consolidated Balance Sheets and recorded at fair value:

- changed (2021-08-06):
[0001564590-21-042027:note_history:16]
|  |  | As of June 30, 2021 |  |
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 14,954 |  |  | $ | 53 |  |  | $ | (6 | ) |  | $ | 15,001 |  |
| Municipal fixed-rate bonds |  |  | 2,523 |  |  |  | 15 |  |  |  | (1 | ) |  |  | 2,537 |  |
| Asset-backed bonds |  |  | 3,983 |  |  |  | 20 |  |  |  | (2 | ) |  |  | 4,001 |  |
| Mortgage/Agency-backed bonds |  |  | 11,004 |  |  |  | 50 |  |  |  | (15 | ) |  |  | 11,039 |  |
| U.S. government bonds |  |  | 10,777 |  |  |  | 51 |  |  |  | (5 | ) |  |  | 10,823 |  |
| Foreign government bonds |  |  | 546 |  |  |  | 1 |  |  |  | (1 | ) |  |  | 546 |  |
| Other |  |  | 533 |  |  |  | — |  |  |  | — |  |  |  | 533 |  |
| Available-for-sale debt securities held at fair value |  | $ | 44,320 |  |  | $ | 190 |  |  | $ | (30 | ) |  | $ | 44,480 |  |
  (was, 2021-05-06, similarity 0.9863):
[0001564590-21-025123:note_history:16]
|  |  | As of March 31,2021 |  |
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 14,176 |  |  | $ | 68 |  |  | $ | (13 | ) |  | $ | 14,231 |  |
| Municipal fixed-rate bonds |  |  | 2,600 |  |  |  | 25 |  |  |  | — |  |  |  | 2,625 |  |
| Asset-backed bonds |  |  | 5,772 |  |  |  | 42 |  |  |  | (2 | ) |  |  | 5,812 |  |
| Mortgage/Agency-backed bonds |  |  | 11,775 |  |  |  | 92 |  |  |  | (22 | ) |  |  | 11,845 |  |
| U.S. government bonds |  |  | 9,704 |  |  |  | 66 |  |  |  | (1 | ) |  |  | 9,769 |  |
| Foreign government bonds |  |  | 1,331 |  |  |  | 3 |  |  |  | (2 | ) |  |  | 1,332 |  |
| Other |  |  | 533 |  |  |  | — |  |  |  | — |  |  |  | 533 |  |
| Available-for-sale debt securities held at fair value |  | $ | 45,891 |  |  | $ | 296 |  |  | $ | (40 | ) |  | $ | 46,147 |  |

- changed (2021-08-06):
[0001564590-21-042027:note_history:17]
|  |  | As of June 30, 2021 |  |
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset- backed bonds |  |  | Mortgage/ Agency- backed bonds |  |  | U.S. government bonds |  |  | Foreign government bonds |  |  | Other |  |
| Less than one year |  | $ | 436 |  |  | $ | 529 |  |  | $ | 1 |  |  | $ | 254 |  |  | $ | 735 |  |  | $ | — |  |  | $ | 533 |  |
| One to two years |  |  | 4,575 |  |  |  | 496 |  |  |  | — |  |  |  | 1,865 |  |  |  | 7,240 |  |  |  | — |  |  |  | — |  |
| Two to three years |  |  | 7,518 |  |  |  | 1,103 |  |  |  | 50 |  |  |  | 1,199 |  |  |  | 1,188 |  |  |  | 546 |  |  |  | — |  |
| Three to five years |  |  | 2,472 |  |  |  | 409 |  |  |  | 1,749 |  |  |  | 165 |  |  |  | 1,660 |  |  |  | — |  |  |  | — |  |
| Five to ten years |  |  | — |  |  |  | — |  |  |  | 866 |  |  |  | 2,213 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| More than ten years |  |  | — |  |  |  | — |  |  |  | 1,335 |  |  |  | 5,343 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 15,001 |  |  | $ | 2,537 |  |  | $ | 4,001 |  |  | $ | 11,039 |  |  | $ | 10,823 |  |  | $ | 546 |  |  | $ | 533 |  |
  (was, 2021-05-06, similarity 0.8785):
[0001564590-21-025123:note_history:17]
|  |  | As of March 31,2021 |  |
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset- backed bonds |  |  | Mortgage / Agency- backed bonds |  |  | U.S. government bonds |  | Foreign government bonds |  |  | Other |  |
| Less than one year |  | $ | 1,323 |  |  | $ | 357 |  |  | $ | 16 |  |  | $ | 296 |  |  | $ | 1,282 |  | $ | 75 |  |  | $ | 533 |  |
| One to two years |  |  | 3,758 |  |  |  | 1,130 |  |  |  | 13 |  |  |  | 2,090 |  |  |  | 6,831 |  |  | 460 |  |  |  | — |  |
| Two to three years |  |  | 7,509 |  |  |  | 1,138 |  |  |  | 272 |  |  |  | 1,740 |  |  |  | 1,656 |  |  | 497 |  |  |  | — |  |
| Three to five years |  |  | 1,641 |  |  |  | — |  |  |  | 3,445 |  |  |  | 175 |  |  |  | — |  |  | 300 |  |  |  | — |  |
| Five to ten years |  |  | — |  |  |  | — |  |  |  | 1,143 |  |  |  | 2,457 |  |  |  | — |  |  | — |  |  |  | — |  |
| More than ten years |  |  | — |  |  |  | — |  |  |  | 923 |  |  |  | 5,087 |  |  |  | — |  |  | — |  |  |  | — |  |
| Total |  | $ | 14,231 |  |  | $ | 2,625 |  |  | $ | 5,812 |  |  | $ | 11,845 |  |  | $ | 9,769 |  | $ | 1,332 |  |  | $ | 533 |  |

- changed (2021-08-06):
[0001564590-21-042027:note_history:18]
Realized gains and losses on sales of debt securities are computed under the specific identification method. The following table presents the gross realized gains and losses related to our debt securities:
  (was, 2021-05-06, similarity 0.9801):
[0001564590-21-025123:note_history:18]
Realized gains and losses on sales of debt securities are computed under the specific identification method. The following table presents gross realized gains and losses related to debt securities:

- added (2021-08-06):
[0001564590-21-042027:note_history:19]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Gross realized gain on debt securities |  | $ | 97 |  |  | $ | 190 |  |  | $ | 184 |  |  | $ | 233 |  |
| Gross realized loss on debt securities |  |  | (20 | ) |  |  | (19 | ) |  |  | (36 | ) |  |  | (39 | ) |
| Total gain recognized, net |  | $ | 77 |  |  | $ | 171 |  |  | $ | 148 |  |  | $ | 194 |  |

- changed (2021-08-06):
[0001564590-21-042027:note_history:20]
No allowance for credit loss was recorded for the six months ended June 30, 2021 or 2020 related to available-for-sale debt securities. The Company’s investment policy provides limitations for issuer concentration, which limits, at the time of purchase, the concentration in any one issuer to 5% of the market value of our total investment portfolio. The Company did not purchase any available-for-sale debt security with credit deterioration during the six months ended June 30, 2021.
  (was, 2021-05-06, similarity 0.7809):
[0001564590-21-025123:note_history:20]
The Company’s investment policy provides limitations for issuer concentration, which limits, at the time of purchase, the concentration in any one issuer to 5% of the market value of the total investment portfolio. The Company did not purchase any available-for-sale debt security with credit deterioration during the three months ended March 31, 2021.

- changed (2021-08-06):
[0001564590-21-042027:note_history:21]
Our marketable equity securities consist of publicly traded stock, interests in funds and certain other investments measured at fair value or cost (where appropriate).
  (was, 2021-05-06, similarity 0.9595):
[0001564590-21-025123:note_history:21]
Our marketable equity securities consist of publicly traded stock, funds and certain other investments measured at fair value or cost (where appropriate).

- changed (2021-08-06):
[0001564590-21-042027:note_history:22]
In March 2019, an outstanding note receivable of $4.3 million owed to the Company was repaid and reissued in the form of debt and equity. Of the outstanding $4.3 million, $3.4 million was issued as an equity investment. The Company elected to record this equity investment that does not have a readily determinable fair value using the measurement alternative. Under the measurement alternative, equity investments that do not have a readily determinable fair value can be recorded at cost less impairment, if any, adjusted for observable price changes for an identical or similar investment. During the year ended December 31, 2020, impairment charges totaling $2.6 million were recorded related to this equity investment, which was included in net investment gain (loss) on the Condensed Consolidated Statement of Income (Loss). As a result the carrying value of this investment was $0.8 million as of June 30, 2021 and December 31, 2020. The remaining amount, $0.9 million of the original $4.3 million note receivable, was reissued as a new note receivable, which is included in long-term investments on the Condensed Consolidated Balance Sheets as of June 30, 2021 and December 31, 2020. No impairment charge was recognized related to the note receivable as it is a secured loan.
  (was, 2021-05-06, similarity 0.9632):
[0001564590-21-025123:note_history:22]
In March 2019, an outstanding note receivable of $4.3 million was repaid and reissued to the Company in the form of debt and equity. Of the outstanding $4.3 million, $3.4 million was issued as an equity investment. The Company elected to record this equity investment that does not have a readily determinable fair value using the measurement alternative. Under the measurement alternative, equity investments that do not have a readily determinable fair value can be recorded at cost less impairment, if any, adjusted for observable price changes for an identical or similar investment. During the year ended December 31, 2020, impairment charges totaling $2.6 million were recorded related to this equity investment, which was included in net investment gain (loss) on the Condensed Consolidated Statement of Income (Loss). As a result, the carrying value of this investment was $0.8 million as of March 31, 2021 and December 31, 2020. The remaining amount, $0.9 million of the original $4.3 million note receivable, was reissued as a new note receivable, which is included in long-term investments on the Condensed Consolidated Balance Sheets as of March 31, 2021 and December 31, 2020. No impairment charge was recognized related to the note receivable, as it is a secured loan.

- added (2021-08-06):
[0001564590-21-042027:note_history:23]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Realized gain (loss) on equity securities sold |  | $ | (79 | ) |  | $ | 328 |  |  | $ | (55 | ) |  | $ | (2,108 | ) |
| Unrealized gain on equity securities held |  |  | 2,011 |  |  |  | 9,353 |  |  |  | 2,912 |  |  |  | 889 |  |
| Total gain (loss) recognized, net |  | $ | 1,932 |  |  | $ | 9,681 |  |  | $ | 2,857 |  |  | $ | (1,219 | ) |

- changed (2021-08-06):
[0001564590-21-042027:note_history:24]
• Level 3 – Significant unobservable inputs; values based on prices or valuation techniques that require inputs that are both unobservable and significant to the overall fair value measurement. These inputs could include information supplied by investees.
  (was, 2021-05-06, similarity 0.7659):
[0001564590-21-025123:note_history:24]
• Level 3 – Significant unobservable inputs; values based on prices or valuation techniques that require inputs that are both unobservable and significant to the overall fair value measurement; inputs could include information supplied by investees.

- changed (2021-08-06):
[0001564590-21-042027:note_history:25]
|  |  |  |  |  |  | Fair Value Measurements as of June 30, 2021 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 615 |  |  | $ | 615 |  |  | $ | — |  |  | $ | — |  |
| Commercial paper |  |  | 1,250 |  |  |  | — |  |  |  | 1,250 |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 15,001 |  |  |  | — |  |  |  | 15,001 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 2,537 |  |  |  | — |  |  |  | 2,537 |  |  |  | — |  |
| Asset-backed bonds |  |  | 4,001 |  |  |  | — |  |  |  | 4,001 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 11,039 |  |  |  | — |  |  |  | 11,039 |  |  |  | — |  |
| U.S. government bonds |  |  | 10,823 |  |  |  | 10,823 |  |  |  | — |  |  |  | — |  |
| Foreign government securities |  |  | 546 |  |  |  | — |  |  |  | 546 |  |  |  | — |  |
| Other |  |  | 533 |  |  |  | — |  |  |  | — |  |  |  | 533 |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 12,057 |  |  |  | 12,057 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 25,917 |  |  |  | 25,917 |  |  |  | — |  |  |  | — |  |
| Other investments |  |  | 1,400 |  |  |  | 1,400 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 85,719 |  |  | $ | 50,812 |  |  | $ | 34,374 |  |  | $ | 533 |  |
  (was, 2021-05-06, similarity 0.9682):
[0001564590-21-025123:note_history:25]
|  |  |  |  |  |  | Fair Value Measurements as of March 31, 2021 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 889 |  |  | $ | 889 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 14,231 |  |  |  | — |  |  |  | 14,231 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 2,625 |  |  |  | — |  |  |  | 2,625 |  |  |  | — |  |
| Asset-backed bonds |  |  | 5,812 |  |  |  | — |  |  |  | 5,812 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 11,845 |  |  |  | — |  |  |  | 11,845 |  |  |  | — |  |
| U.S. government bonds |  |  | 9,769 |  |  |  | 9,769 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 1,332 |  |  |  | — |  |  |  | 1,332 |  |  |  | — |  |
| Other |  |  | 533 |  |  |  | — |  |  |  | — |  |  |  | 533 |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 11,544 |  |  |  | 11,544 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 24,364 |  |  |  | 24,364 |  |  |  | — |  |  |  | — |  |
| Other investments |  |  | 1,400 |  |  |  | 1,400 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 84,344 |  |  | $ | 47,966 |  |  | $ | 35,845 |  |  | $ | 533 |  |

- removed (2021-08-06):
[0001564590-21-025123:note_history:26]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2021 |  |  | 2020 |  |
| Gross realized gains on debt securities |  | $ | 87 |  |  | $ | 43 |  |
| Gross realized losses on debt securities |  |  | (16 | ) |  |  | (20 | ) |
| Total gain recognized, net |  | $ | 71 |  |  | $ | 23 |  |

- removed (2021-08-06):
[0001564590-21-025123:note_history:27]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2021 |  |  | 2020 |  |
| Realized gains (losses) on equity securities sold |  | $ | 24 |  |  | $ | (2,436 | ) |
| Unrealized gains (losses) on equity securities held |  |  | 901 |  |  |  | (8,464 | ) |
| Total gain (loss) recognized, net |  | $ | 925 |  |  | $ | (10,900 | ) |


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-08-06):
[0001564590-21-042027:note_history:28]
The following tables disaggregate revenue by reportable segment and revenue category:
  (was, 2021-05-06, similarity 0.9882):
[0001564590-21-025123:note_history:28]
The following table disaggregates revenue by reportable segment and revenue category:

- changed (2021-08-06):
[0001564590-21-042027:note_history:29]
|  |  | Three Months Ended |  |
|  |  | June 30, 2021 |  |  | June 30, 2020 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 78,307 |  |  | $ | 12,657 |  |  | $ | 90,964 |  |  | $ | 69,721 |  |  | $ | 13,055 |  |  | $ | 82,776 |  |
| Subscriber Solutions & Experience |  |  | 45,097 |  |  |  | 2,713 |  |  |  | 47,810 |  |  |  | 38,081 |  |  |  | 2,312 |  |  |  | 40,393 |  |
| Traditional & Other Products |  |  | 2,045 |  |  |  | 2,413 |  |  |  | 4,458 |  |  |  | 3,521 |  |  |  | 2,025 |  |  |  | 5,546 |  |
| Total |  | $ | 125,449 |  |  | $ | 17,783 |  |  | $ | 143,232 |  |  | $ | 111,323 |  |  | $ | 17,392 |  |  | $ | 128,715 |  |
  (was, 2021-05-06, similarity 0.9585):
[0001564590-21-025123:note_history:29]
|  |  | For the Three Months Ended |  |
|  |  | March 31, 2021 |  |  | March 31, 2020 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 60,053 |  |  | $ | 9,021 |  |  | $ | 69,074 |  |  | $ | 53,055 |  |  | $ | 12,911 |  |  | $ | 65,966 |  |
| Subscriber Solutions & Experience |  |  | 52,269 |  |  |  | 2,300 |  |  |  | 54,569 |  |  |  | 39,983 |  |  |  | 2,196 |  |  |  | 42,179 |  |
| Traditional & Other Products |  |  | 1,487 |  |  |  | 2,403 |  |  |  | 3,890 |  |  |  | 4,334 |  |  |  | 2,044 |  |  |  | 6,378 |  |
| Total |  | $ | 113,809 |  |  | $ | 13,724 |  |  | $ | 127,533 |  |  | $ | 97,372 |  |  | $ | 17,151 |  |  | $ | 114,523 |  |

- added (2021-08-06):
[0001564590-21-042027:note_history:30]
|  |  | Six Months Ended |  |
|  |  | June 30, 2021 |  |  | June 30, 2020 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 138,360 |  |  | $ | 21,678 |  |  | $ | 160,038 |  |  | $ | 122,776 |  |  | $ | 25,966 |  |  | $ | 148,742 |  |
| Subscriber Solutions & Experience |  |  | 97,366 |  |  |  | 5,013 |  |  |  | 102,379 |  |  |  | 78,064 |  |  |  | 4,508 |  |  |  | 82,572 |  |
| Traditional & Other Products |  |  | 3,532 |  |  |  | 4,816 |  |  |  | 8,348 |  |  |  | 7,855 |  |  |  | 4,069 |  |  |  | 11,924 |  |
| Total |  | $ | 239,258 |  |  | $ | 31,507 |  |  | $ | 270,765 |  |  | $ | 208,695 |  |  | $ | 34,543 |  |  | $ | 243,238 |  |

- changed (2021-08-06):
[0001564590-21-042027:note_history:31]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2021 |  |  | 2020 |  |  | 2021 |  |  | 2020 |  |
| Access & Aggregation |  | $ | 90,964 |  |  | $ | 82,776 |  |  | $ | 160,038 |  |  | $ | 148,742 |  |
| Subscriber Solutions & Experience |  |  | 47,810 |  |  |  | 40,393 |  |  |  | 102,379 |  |  |  | 82,572 |  |
| Traditional & Other Products |  |  | 4,458 |  |  |  | 5,546 |  |  |  | 8,348 |  |  |  | 11,924 |  |
| Total |  | $ | 143,232 |  |  | $ | 128,715 |  |  | $ | 270,765 |  |  | $ | 243,238 |  |
  (was, 2021-05-06, similarity 0.6973):
[0001564590-21-025123:note_history:31]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2021 |  |  | 2020 |  |
| Access & Aggregation |  | $ | 69,074 |  |  | $ | 65,966 |  |
| Subscriber Solutions & Experience |  |  | 54,569 |  |  |  | 42,179 |  |
| Traditional & Other Products |  |  | 3,890 |  |  |  | 6,378 |  |
| Total Revenue |  | $ | 127,533 |  |  | $ | 114,523 |  |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2021-08-06):
[0001564590-21-042027:note_history:32]
In addition to our reportable segments, revenue is also reported for the following three categories – Access & Aggregation, Subscriber Solutions & Experience and Traditional & Other Products.
  (was, 2021-05-06, similarity 0.9816):
[0001564590-21-025123:note_history:32]
In addition to our reporting segments, revenue is also reported for the following three categories – Access & Aggregation, Subscriber Solutions & Experience and Traditional & Other Products.

- changed (2021-08-06):
[0001564590-21-042027:note_history:33]
The following tables disaggregate revenue by reportable segment and revenue category:
  (was, 2021-05-06, similarity 0.9882):
[0001564590-21-025123:note_history:33]
The following table disaggregates revenue by reportable segment and revenue category:

- changed (2021-08-06):
[0001564590-21-042027:note_history:34]
|  |  | Three Months Ended |  |
|  |  | June 30, 2021 |  |  | June 30, 2020 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 78,307 |  |  | $ | 12,657 |  |  | $ | 90,964 |  |  | $ | 69,721 |  |  | $ | 13,055 |  |  | $ | 82,776 |  |
| Subscriber Solutions & Experience |  |  | 45,097 |  |  |  | 2,713 |  |  |  | 47,810 |  |  |  | 38,081 |  |  |  | 2,312 |  |  |  | 40,393 |  |
| Traditional & Other Products |  |  | 2,045 |  |  |  | 2,413 |  |  |  | 4,458 |  |  |  | 3,521 |  |  |  | 2,025 |  |  |  | 5,546 |  |
| Total |  | $ | 125,449 |  |  | $ | 17,783 |  |  | $ | 143,232 |  |  | $ | 111,323 |  |  | $ | 17,392 |  |  | $ | 128,715 |  |
  (was, 2021-05-06, similarity 0.9585):
[0001564590-21-025123:note_history:34]
|  |  | For the Three Months Ended |  |
|  |  | March 31, 2021 |  |  | March 31, 2020 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 60,053 |  |  | $ | 9,021 |  |  | $ | 69,074 |  |  | $ | 53,055 |  |  | $ | 12,911 |  |  | $ | 65,966 |  |
| Subscriber Solutions & Experience |  |  | 52,269 |  |  |  | 2,300 |  |  |  | 54,569 |  |  |  | 39,983 |  |  |  | 2,196 |  |  |  | 42,179 |  |
| Traditional & Other Products |  |  | 1,487 |  |  |  | 2,403 |  |  |  | 3,890 |  |  |  | 4,334 |  |  |  | 2,044 |  |  |  | 6,378 |  |
| Total |  | $ | 113,809 |  |  | $ | 13,724 |  |  | $ | 127,533 |  |  | $ | 97,372 |  |  | $ | 17,151 |  |  | $ | 114,523 |  |

- added (2021-08-06):
[0001564590-21-042027:note_history:35]
|  |  | Six Months Ended |  |
|  |  | June 30, 2021 |  |  | June 30, 2020 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 138,360 |  |  | $ | 21,678 |  |  | $ | 160,038 |  |  | $ | 122,776 |  |  | $ | 25,966 |  |  | $ | 148,742 |  |
| Subscriber Solutions & Experience |  |  | 97,366 |  |  |  | 5,013 |  |  |  | 102,379 |  |  |  | 78,064 |  |  |  | 4,508 |  |  |  | 82,572 |  |
| Traditional & Other Products |  |  | 3,532 |  |  |  | 4,816 |  |  |  | 8,348 |  |  |  | 7,855 |  |  |  | 4,069 |  |  |  | 11,924 |  |
| Total |  | $ | 239,258 |  |  | $ | 31,507 |  |  | $ | 270,765 |  |  | $ | 208,695 |  |  | $ | 34,543 |  |  | $ | 243,238 |  |

- changed (2021-08-06):
[0001564590-21-042027:note_history:36]
Revenue allocated to remaining performance obligations represents contract revenues that have not yet been recognized for contracts with a duration of greater than one year. As of June 30, 2021, we did not have any significant performance obligations related to customer contracts that had an original expected duration of one year or more, other than maintenance services, which are satisfied over time. As a practical expedient, for certain contracts we recognize revenue equal to the amounts that we are entitled to invoice, which correspond to the value of completed performance obligations to date. The amount related to these performance obligations was $19.7 million and $17.7 million as of June 30, 2021 and December 31, 2020, respectively. The Company expects to recognize 64% of the $19.7 million as of June 30, 2021 over the next 12 months, with the remainder to be recognized thereafter.
  (was, 2021-05-06, similarity 0.978):
[0001564590-21-025123:note_history:36]
Revenue allocated to remaining performance obligations represents contract revenue that have not yet been recognized for contracts with a duration greater than one year. As of March 31, 2021, we did not have any significant performance obligations related to customer contracts that had an original expected duration of one year or more, other than maintenance services, which are satisfied over time. As a practical expedient, for certain contracts we recognize revenue equal to the amounts we are entitled to invoice which correspond to the value of completed performance obligations to date. The amount related to these performance obligations was $19.0 million and $17.7 million as of March 31, 2021 and December 31, 2020, respectively. The Company expects to recognize 63% of the $19.0 million as of March 31, 2021 over the next 12 months with the remainder to be recognized thereafter.

- changed (2021-08-06):
[0001564590-21-042027:note_history:37]
|  |  | As of |  |  | As of |  |
| (In thousands) |  | June 30, 2021 |  |  | December 31, 2020 |  |
| Accounts receivable, net |  | $ | 122,669 |  |  | $ | 98,827 |  |
| Contract assets(1) |  | $ | 1,036 |  |  | $ | 63 |  |
| Unearned revenue |  | $ | 15,889 |  |  | $ | 14,092 |  |
| Non-current unearned revenue |  | $ | 7,030 |  |  | $ | 6,888 |  |
  (was, 2021-05-06, similarity 0.8743):
[0001564590-21-025123:note_history:37]
| (In thousands) |  | As of March 31, 2021 |  |  | As of December 31, 2020 |  |
| Accounts receivable, net |  | $ | 103,201 |  |  | $ | 98,827 |  |
| Contract assets(1) |  | $ | 906 |  |  | $ | 63 |  |
| Unearned revenue |  | $ | 14,457 |  |  | $ | 14,092 |  |
| Non-current unearned revenue |  | $ | 7,040 |  |  | $ | 6,888 |  |

- changed (2021-08-06):
[0001564590-21-042027:note_history:38]
Of the outstanding unearned revenue balances as of December 31, 2020 $2.9 million and $7.9 million were recognized as revenue during the three and six months ended June 30, 2021, respectively.
  (was, 2021-05-06, similarity 0.8391):
[0001564590-21-025123:note_history:38]
Of the outstanding unearned revenue balances as of December 31, 2020, $5.0 million was recognized as revenue during the three months ended March 31, 2021.

- removed (2021-08-06):
[0001564590-21-025123:note_history:39]
See Note 17 for additional information on reportable segments.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2021-08-06):
[0001564590-21-042027:note_history:40]
On August 4, 2021, we announced that our Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to the Company’s stockholders of record as of the close of business on August 19, 2021. The payment date will be September 2, 2021 in the aggregate amount of approximately $4.4 million.
  (was, 2021-05-06, similarity 0.9468):
[0001564590-21-025123:note_history:40]
On May 5, 2021, we announced that our Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to the Company’s stockholders of record as of the close of business on May 20, 2021. The payment date will be June 3, 2021 in the aggregate amount of approximately $4.4 million.
