# ADTN MD&A — 0001564590-20-023537


## mdna

[0001564590-20-023537:mdna:1]
[same as prior period, unchanged from 0001564590-19-040490:mdna:1]

[0001564590-20-023537:mdna:2]
The following discussion should be read in conjunction with the consolidated financial statements and the related notes that appear in Part I, Item 1 of this document.  In addition, the following discussion should be read in conjunction with our audited consolidated financial statements for the year ended December 31, 2019, Part II, Item 7, Management’s Discussion and Analysis of Financial Condition and Results of Operations, Part I, Item 1, Business, and Item 1A, Risk Factors, included in our Annual Report on Form 10-K for the year ended December 31, 2019, filed with the SEC on February 25, 2020 (the “2019 Form 10-K”).

[0001564590-20-023537:mdna:3]
This discussion is designed to provide the reader with information that will assist in understanding our condensed consolidated financial statements, the changes in certain key items in those financial statements from period to period, and the primary factors that accounted for those changes, as well as how certain accounting principles affect our condensed consolidated financial statements. See “Cautionary Note Regarding Forward-Looking Statements” on page 3 of this report for a description of important factors that could cause actual results to differ from expected results.  See also Part 1, Item 1A, Risk Factors, of the 2019 Form 10‑K and Part II, Item 1A, Risk Factors, of this Form 10-Q.

[0001564590-20-023537:mdna:4]
[same as prior period, unchanged from 0001564590-19-040490:mdna:5]

[0001564590-20-023537:mdna:5]
ADTRAN is a leading global provider of networking and communications equipment, serving a diverse domestic and international customer base in multiple countries that includes Tier-1, -2 and -3 service providers, cable/MSOs and distributed enterprises. Our innovative solutions and services enable voice, data, video and internet communications across a variety of network infrastructures and are currently in use by millions worldwide. We support our customers through our direct global sales organization and our distribution networks. Our success depends upon our ability to increase unit volume and market share through the introduction of new products and succeeding generations of products having lower selling prices and increased functionality as compared to both the prior generation of a product and to the products of competitors. In order to service our customers and grow revenue, we are constantly conducting research and development of new products addressing customer needs and testing those products for the particular specifications of the particular customers. We are focused on being a top global supplier of access infrastructure and related value-added solutions from the cloud edge to the subscriber edge. We offer a broad portfolio of flexible software and hardware network solutions and services that enable service providers to meet today’s service demands, while enabling them to transition to the fully-converged, scalable, highly-automated, cloud-controlled voice, data, internet and video network of the future. In addition to our corporate headquarters in Huntsville, Alabama, we have research and development facilities in strategic global locations.

[0001564590-20-023537:mdna:6]
[same as prior period, unchanged from 0001564590-19-040490:mdna:7]

[0001564590-20-023537:mdna:7]
While we ended the first quarter of 2020 with a year-over-year revenue decrease of 20.4%, we continued to have good geographical diversity with 31.0% of our revenue coming from international markets.  Additionally, we had three 10% revenue customers geographically diversified with two in the U.S and one in Europe. Our domestic revenue grew 8.9% during the three months ended March 31, 2020 compared to the same quarter in the prior year, which was driven by an increase in sales to RSPs and additional fiber deployments across all customers. In addition, we saw an increase in sales to a Tier-1 customer with diversified business among our fiber access and CPE, service provider CPE and services as well as sales to Tier-3 customers. In Europe, we saw an increase in revenue from a Tier-1 customer as its spending increased after a slow-down in spending during the second half of 2019. Additionally, the same Tier-1 customer continued expansion of its vectoring and super-vectoring VDSL2 solutions and we experienced continued increases in our service provider CPE business during the three months ended March 31, 2020.

[0001564590-20-023537:mdna:8]
During the first quarter of 2020, there was a downturn in the global financial markets and a slowdown in the global economy due to the COVID-19 pandemic. In March 2020, the World Health Organization declared the outbreak of COVID-19 a pandemic. COVID-19 continues to spread throughout the U.S. and the world and has resulted in authorities implementing numerous measures to contain the virus, including travel bans and restrictions, quarantines, shelter-in-place orders, and business limitations and shutdowns. While we are unable to accurately predict the full impact that COVID-19 will have on our results from operations, financial condition, liquidity and cash flows due to numerous uncertainties, including the duration and severity of the pandemic and containment measures, our compliance with these measures has impacted our day-to-day operations and could disrupt our business and operations, as well as that of our key customers, suppliers and other counterparties, for an indefinite period of time. We have experienced some impact to our supply chain, including a slow-down in supply chain deliveries and some raw material and freight-related cost increases. Additionally, COVID-19 had some impact on our financial results for the first quarter. In the early stages of the downturn, we have seen increased demand in networking requirements and utilization due to social distancing guidelines issued by governments. While we expect that we may experience some slow-down in demand and potential supply-chain issues, as the pandemic continues, we do not at this time expect the overall impact of COVID-19 to materially impact our operations, results of operations and cash flows.

[0001564590-20-023537:mdna:9]
Among our customers, we made progress with our fiber and fiber-extension solutions, including Gfast and PON, while also continuing to engage various Services & Support opportunities that we expect will contribute in 2020 and beyond. In addition, we believe we are at the beginning of a significant investment cycle for fiber deployment driven by technology advancements, regulatory influences and vendor disruption. The transition to next-generation network architectures is beginning, and we are seeing demand for our next-generation SD-Access solutions. In the latter part of 2020, we anticipate that payments to service providers under government funding programs such as the FCC Rural Digital Opportunity Fund will begin.

[0001564590-20-023537:mdna:10]
In addition to classifying our operations into two reportable segments, we report revenue across three categories of products and services – (1) Access & Aggregation, (2) Subscriber Solutions & Experience and (3) Traditional & Other Products.

[0001564590-20-023537:mdna:11]
Our Access & Aggregation solutions are used by CSPs to connect their network infrastructure to subscribers. This revenue category includes hardware- and software-based products and services that aggregate and/or originate access technologies. ADTRAN solutions within this category include a wide array of modular or fixed platforms designed to deliver the best technology and economy based on subscriber density and environmental conditions.

[0001564590-20-023537:mdna:12]
Our Subscriber Solutions & Experience portfolio is used by service providers to terminate their infrastructure at the customer’s premises while providing an immersive and interactive experience for the subscriber. These solutions include copper and fiber WAN termination, LAN switching, Wi-Fi access, and cloud software services, for both residential and business markets.

[0001564590-20-023537:mdna:13]
Our Traditional & Other Products category generally includes a mix of prior-generation technologies’ products and services, as well as other products and services that do not fit within the other revenue categories.

[0001564590-20-023537:mdna:14]
Our operating results have fluctuated, and may continue to fluctuate, on a quarterly basis due to a number of factors, including customer order activity and backlog. A substantial portion of our shipments in any fiscal period relates to orders received and shipped within that fiscal period for customers under agreements containing non-binding purchase commitments. Further, a significant percentage of orders require delivery within a few days. These factors normally result in a varying order backlog and limited order flow visibility. Additionally, backlog levels may vary because of seasonal trends, the timing of customer projects, and other factors that affect customer order lead times. Because many of our customers require prompt delivery of products, we are required to maintain sufficient inventory levels to satisfy anticipated customer demand. If near-term demand for our products declines, or if potential sales in any quarter do not occur as anticipated, our financial results could be adversely affected. Operating expenses are relatively fixed in the short term; therefore, a shortfall in quarterly revenues could significantly impact our financial results in a given quarter.

[0001564590-20-023537:mdna:15]
Our operating results may also fluctuate as a result of a number of other factors, including a decline in general economic and market conditions, specifically the decline that has resulted from the COVID-19 pandemic, foreign currency exchange rate movements, increased competition, customer order patterns, changes in product and services mix, timing differences between price decreases and product cost reductions, product warranty returns, expediting costs, tariffs and announcements of new products by us or our competitors. Additionally, maintaining sufficient inventory levels to assure prompt delivery of our products increases the amount of inventory that may become obsolete and increases the risk that the obsolescence of this inventory may have an adverse effect on our business and operating results. Also, not maintaining sufficient inventory levels to assure prompt delivery of our products may cause us to incur expediting costs to meet customer delivery requirements, which may negatively impact our operating results in a given quarter. During 2019, the Company implemented restructuring plans to realign its expense structure with the reduction in revenue experienced in recent years and with overall Company objectives. Management assessed the efficiency of our operations and consolidated locations and personnel, among other things, and has implemented certain cost savings initiatives, where possible. We expect to continue to see a reduction in our operating expenses, both in the U.S. and internationally, as a result of our implementation of these restructuring plans.

[0001564590-20-023537:mdna:16]
Our historical financial performance is not necessarily a meaningful indicator of future results, and in general, management expects that our financial results may vary from period to period. Factors that could materially affect our business, financial condition or operating results are included in Part I, Item 1A of the 2019 Form 10-K and in Part II, Item 1A of this Form 10-Q.

[0001564590-20-023537:mdna:17]
[same as prior period, unchanged from 0001564590-19-040490:mdna:20]

[0001564590-20-023537:mdna:18]
There have been no material changes to our critical accounting policies and estimates from those disclosed in our 2019 Form 10-K.

[0001564590-20-023537:mdna:19]
[same as prior period, unchanged from 0001564590-19-040490:mdna:23]

[0001564590-20-023537:mdna:20]
[same as prior period, unchanged from 0001564590-19-040490:mdna:24]

[0001564590-20-023537:mdna:21]
RESULTS OF OPERATIONS – THREE MONTHS ENDED MARCH 31, 2020 COMPARED TO THREE MONTHS ENDED MARCH 31, 2019

[0001564590-20-023537:mdna:22]
The following table presents selected financial information derived from our Condensed Consolidated Statements of Income (Loss) expressed as a percentage of sales for the periods indicated. Amounts may not foot due to rounding.

[0001564590-20-023537:mdna:23]
|  |  | Three Months Ended |  |  |
|  |  | March 31, |  |  |
|  |  | 2020 |  |  | 2019 |  |  |
| Sales |  |  |  |  |  |  |  |  |  |
| Network Solutions |  |  | 85.0 |  | % |  | 87.5 |  | % |
| Services & Support |  |  | 15.0 |  |  |  | 12.5 |  |  |
| Total Sales |  |  | 100.0 |  |  |  | 100.0 |  |  |
| Cost of Sales |  |  |  |  |  |  |  |  |  |
| Network Solutions |  |  | 45.1 |  |  |  | 49.2 |  |  |
| Services & Support |  |  | 9.9 |  |  |  | 8.7 |  |  |
| Total Cost of Sales |  |  | 54.9 |  |  |  | 57.8 |  |  |
| Gross Profit |  |  | 45.1 |  |  |  | 42.2 |  |  |
| Selling, general and administrative expenses |  |  | 23.2 |  |  |  | 24.4 |  |  |
| Research and development expenses |  |  | 26.1 |  |  |  | 22.0 |  |  |
| Asset impairments |  |  | 0.1 |  |  |  | — |  |  |
| Operating Loss |  |  | (4.3 | ) |  |  | (4.3 | ) |  |
| Interest and dividend income |  |  | 0.3 |  |  |  | 0.4 |  |  |
| Interest expense |  |  | — |  |  |  | (0.1 | ) |  |
| Net investment gain (loss) |  |  | (9.5 | ) |  |  | 4.1 |  |  |
| Other income, net |  |  | 1.0 |  |  |  | 0.6 |  |  |
| Income (Loss) Before Income Taxes |  |  | (12.5 | ) |  |  | 0.7 |  |  |
| Income tax (expense) benefit |  |  | 3.8 |  |  |  | (0.2 | ) |  |
| Net Income (Loss) |  |  | (8.7 | ) | % |  | 0.5 |  | % |

[0001564590-20-023537:mdna:24]
[same as prior period, unchanged from 0001564590-19-040490:mdna:28]

[0001564590-20-023537:mdna:25]
Our sales decreased 20.4% from $143.8 million for the three months ended March 31, 2019 to $114.5 million for the three months ended March 31, 2020. The decrease in sales for the three months ended March 31, 2020 was primarily attributable to a $33.8 million decrease in Access & Aggregation sales and a $0.9 million decrease in sales of our Traditional & Other Products, partially offset by a $5.4 million increase in Subscriber Solutions & Experience sales.

[0001564590-20-023537:mdna:26]
Network Solutions segment sales decreased 22.6% from $125.8 million for the three months ended March 31, 2019 to $97.4 million for the three months ended March 31, 2020. The decrease in sales for the three months ended March 31, 2020 was primarily attributable to the slowdown in shipments to two Tier-1 customers. For the three months ended March 31, 2020, sales in the Access & Aggregation and Traditional & Other Products categories decreased, partially offset by an increase in Subscriber Solutions & Experience category sales. The decrease in Access & Aggregation sales for the three months ended March 31, 2020 was primarily attributable to decreased sales of FTTN products.  The increase in Subscriber Solutions & Experience sales for the three months ended March 31, 2020 was primarily attributable to increased sales of SP Business CPE Network Termination and Fiber CPE. While we expect that revenue from Traditional & Other Products will continue to decline over time, this revenue may fluctuate and continue for years because of the time required for our customers to transition to newer technologies.

[0001564590-20-023537:mdna:27]
Services & Support segment sales decreased 4.6% from $18.0 million for the three months ended March 31, 2019 to $17.2 million for the three months ended March 31, 2020. The decrease in sales for the three months ended March 31, 2020 was primarily attributable to a decrease in maintenance services for Access & Aggregation products.

[0001564590-20-023537:mdna:28]
International sales, which are included in the amounts for both the Network Solutions and Services & Support segments discussed above, decreased 50.1% from $71.3 million for the three months ended March 31, 2019 to $35.5 million for the three months ended March 31, 2020. International sales, as a percentage of total sales, decreased from 49.6% for the three months ended March 31, 2019 to 31.0% for the three months ended March 31, 2020. The decrease in sales for the three months ended March 31, 2020, was primarily attributable the slowdown in shipments to two international Tier-1 customers.

[0001564590-20-023537:mdna:29]
Our international revenue is largely focused on broadband infrastructure and is affected by the decisions of our customers as to timing for installation of new technologies, expansion of their networks and/or network upgrades. Our international customers must make these decisions in the regulatory and political environment in which they operate – both nationally and in some instances, regionally – whether of a multi-country region or a more local region within a country. The competitive landscape in certain international markets is also affected by the increased presence of Asian manufacturers that seek to compete aggressively on price. Our revenue and operating income in some international markets have been, and may continue to be, negatively impacted by a strengthening U.S. dollar, adverse changes in trade policy and disruptions in international trade due to the COVID-19 pandemic. Consequently, while we expect the global trend towards deployment of more robust broadband speeds and access to continue creating additional market opportunities for us in the long-run, the factors described above may result in negative pressure on revenue and operating income.

[0001564590-20-023537:mdna:30]
[same as prior period, unchanged from 0001564590-19-040490:mdna:35]

[0001564590-20-023537:mdna:31]
As a percentage of sales, cost of sales decreased from 57.8% for the three months ended March 31, 2019 to 54.9% for the three months ended March 31, 2020. The decrease was primarily attributable to changes in customer and product mix, a regional revenue shift, changes in services and support mix and a decrease in fixed personnel costs as a result of a restructuring program initiated in 2019.

[0001564590-20-023537:mdna:32]
Network Solutions cost of sales, as a percentage of that segment’s sales, decreased from 56.2% for the three months ended March 31, 2019 to 53.0% for the three months ended March 31, 2020. The decrease in cost of sales as a percentage of sales for the three months ended March 31, 2020 was primarily attributable to changes in customer and product mix, a regional revenue shift and a decrease in fixed personnel costs as a result of a restructuring program initiated in 2019.

[0001564590-20-023537:mdna:33]
[same as prior period, unchanged from 0001564590-19-040490:mdna:38]

[0001564590-20-023537:mdna:34]
Services & Support cost of sales, as a percentage of that segment’s sales, decreased from 69.3% for the three months ended March 31, 2019 to 65.9% for the three months ended March 31, 2020. The decrease in cost of sales as a percentage of sales for the three months ended March 31, 2020 was primarily attributable to customer mix, changes in services and support mix and a decrease in fixed personnel costs as a result of a restructuring program initiated in 2019.

[0001564590-20-023537:mdna:35]
Services & Support revenue is comprised of network planning and implementation, maintenance, support and cloud-based management services, with network planning and implementation being the largest and fastest growing component in the long-term. Compared to our other services, such as maintenance, support and cloud-based management services, our network planning and implementation services typically utilize a higher percentage of internal and subcontracted engineers, professionals and contractors to perform the work for customers. The additional costs incurred to perform these infrastructure and labor-intensive services inherently result in lower average gross margins as compared to maintenance and support services.

[0001564590-20-023537:mdna:36]
[same as prior period, unchanged from 0001564590-19-040490:mdna:41]

[0001564590-20-023537:mdna:37]
[same as prior period, unchanged from 0001564590-19-040490:mdna:42]

[0001564590-20-023537:mdna:38]
As a percentage of sales, selling, general and administrative expenses decreased from 24.4% for the three months ended March 31, 2019 to 23.2% for the three months ended March 31, 2020. Selling, general and administrative expenses as a percentage of sales will generally fluctuate whenever there is a significant fluctuation in revenue for the periods being compared.

[0001564590-20-023537:mdna:39]
Selling, general and administrative expenses decreased 24.2% from $35.1 million for the three months ended March 31, 2019 to $26.6 million for the three months ended March 31, 2020. The decrease in selling, general and administrative expenses for the three months ended March 31, 2020 was primarily attributable to lower deferred compensation related costs and labor expense partially due to the restructuring program initiated in 2019, partially offset by increases in costs for contract services related to an enterprise resource planning implementation project.

[0001564590-20-023537:mdna:40]
[same as prior period, unchanged from 0001564590-19-040490:mdna:45]

[0001564590-20-023537:mdna:41]
As a percentage of sales, research and development expenses increased from 22.0% for the three months ended March 31, 2019 to 26.1% for the three months ended March 31, 2020. Research and development expenses as a percentage of sales will fluctuate whenever there are incremental product development activities or significant fluctuations in revenue for the periods being compared.

[0001564590-20-023537:mdna:42]
Research and development expenses decreased 5.6% from $31.6 million for the three months ended March 31, 2019 to $29.9 million for the three months ended March 31, 2020. The decrease in research and development expenses for the three months ended March 31, 2020 was primarily attributable to lower labor expense and other expenses which were mainly as result of a restructuring program initiated in 2019.

[0001564590-20-023537:mdna:43]
We expect to continue to incur research and development expenses in connection with our new and existing products and our continued expansion into international markets. We continually evaluate new product opportunities and engage in significant research and product development efforts, which provides for new product development, enhancement of existing products and product cost reductions. We may incur significant research and development expenses prior to the receipt of revenue from a major new product group.

[0001564590-20-023537:mdna:44]
[same as prior period, unchanged from 0001564590-19-040490:mdna:49]

[0001564590-20-023537:mdna:45]
Asset impairments, which were $0.1 million for the three months ended March 31, 2020, relate to the abandonment of certain information technology projects in which we had previously capitalized costs. There were no asset impairments recognized during the three months ended March 31, 2019.

[0001564590-20-023537:mdna:46]
[same as prior period, unchanged from 0001564590-19-040490:mdna:53]

[0001564590-20-023537:mdna:47]
Interest and dividend income decreased 39.8% from $0.6 million for the three months ended March 31, 2019 to $0.4 million for the three months ended March 31, 2020. The decrease in interest and dividend income was primarily attributable to a decrease in interest income as a result of a decline in our investment balances primarily due to the maturity of our certificate of deposit which served as collateral for our taxable revenue bonds. Our total investments decreased from $116.5 million as of March 31, 2019 to $85.1 million as of March 31, 2020.

[0001564590-20-023537:mdna:48]
[same as prior period, unchanged from 0001564590-19-040490:mdna:55]

[0001564590-20-023537:mdna:49]
Interest expense, which is primarily related to our taxable revenue bonds, decreased by $0.1 million in the three months ended March 31, 2020 compared to the three months ended March 31, 2019. The decrease was due to the fact that the outstanding principal balance of the taxable revenue bonds was paid off upon maturity in January 2020. See “Liquidity and Capital Resources” below for additional information on our revenue bond.

[0001564590-20-023537:mdna:50]
[same as prior period, unchanged from 0001564590-19-040490:mdna:57]

[0001564590-20-023537:mdna:51]
We recognized a net investment gain of $5.9 million for the three months ended March 31, 2019 and a net investment loss of $10.9 million for the three months ended March 31, 2020. The fluctuations in our net investments were primarily attributable to changes in the fair value of our securities recognized during the period. For the three months ended March 31, 2020, our investments were negatively impacted by the market conditions due to the COVID-19 pandemic, which resulted in a sharp downturn in the markets during the quarter. We expect that any future market volatility, whether from COVID-19 or other factors, will result in continued volatility in our investment portfolio. See Note 6 of the Notes to Condensed Consolidated Financial Statements, included in Part I, Item 1 of this report, and “Investing Activities” in “Liquidity and Capital Resources” below for additional information.

[0001564590-20-023537:mdna:52]
OTHER INCOME, NET

[0001564590-20-023537:mdna:53]
Other income, net increased from income of $0.9 million for the three months ended March 31, 2019 to income of $1.1 million for the three months ended March 31, 2020. For the three months ended March 31, 2020, other income, net consisted mainly of gains and losses on foreign currency transactions. For the three months ended March 31, 2019, other income, net consisted mainly of the receipt of insurance proceeds from a life insurance policy.

[0001564590-20-023537:mdna:54]
INCOME TAX EXPENSE (BENEFIT)

[0001564590-20-023537:mdna:55]
Our effective tax rate decreased from an expense of 28.6% for the three months ended March 31, 2019 to a benefit of 30.5% for the three months ended March 31, 2020. The decrease in the effective tax rate was primarily driven by the impact recorded from the Coronavirus Aid, Relief, and Economic Security (the “CARES Act”) Act signed into law on March 27, 2020, partially offset by tax expense in our international operations and changes in our valuation allowance related to our domestic operations. See Note 3 of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this report for additional information.

[0001564590-20-023537:mdna:56]
[same as prior period, unchanged from 0001564590-19-040490:mdna:65]

[0001564590-20-023537:mdna:57]
As a result of the above factors, net income (loss) decreased from net income of $0.8 million for the three months ended March 31, 2019 to a net loss of $10.0 million for the three months ended March 31, 2020.

[0001564590-20-023537:mdna:58]
[same as prior period, unchanged from 0001564590-19-040490:mdna:67]

[0001564590-20-023537:mdna:59]
[same as prior period, unchanged from 0001564590-19-040490:mdna:68]

[0001564590-20-023537:mdna:60]
We have historically financed, and we currently expect to continue to finance, our ongoing business with existing cash, investments and cash flow from operations. We have used, and expect to continue to use, existing cash, investments and cash generated from operations for working capital, business acquisitions, purchases of treasury stock, shareholder dividends and other general corporate purposes, including product development activities to enhance our existing products and develop new products, expansion of our sales and marketing activities and capital expenditures. We believe our cash and cash equivalents, investments and cash generated from operations to be adequate to meet our operating and capital needs for at least the next 12 months.

[0001564590-20-023537:mdna:61]
As of March 31, 2020, cash on hand was $71.3 million and short-term investments were $6.0 million, which resulted in available short-term liquidity of $77.3 million, of which $47.5 million was held by our foreign subsidiaries. As of December 31, 2019, cash on hand was $73.8 million and short-term investments were $33.2 million, which resulted in available short-term liquidity of $107.0 million, of which $52.3 million was held by our foreign subsidiaries. The decrease in short-term liquidity from December 31, 2019 to March 31, 2020 is primarily attributable to the maturity of a certificate of deposit of $25.6 million that served as collateral for our revenue bond, which matured in January 2020.

[0001564590-20-023537:mdna:62]
[same as prior period, unchanged from 0001564590-19-040490:mdna:71]

[0001564590-20-023537:mdna:63]
Our working capital, defined as current assets less current liabilities, decreased 1.6% from $207.6 million as of December 31, 2019 to $204.4 million as of March 31, 2020, and our current ratio, defined as current assets divided by current liabilities, increased from 2.84 as of December 31, 2019 to 3.29 as of March 31, 2020. The decrease in our working capital and increase in our current ratio were primarily attributable to decreases in accounts receivable, and short-term investments, which consisted of a certificate of deposit related to our taxable revenue bond and the related bonds payable, partially offset by increases in other receivables and accounts payable. The quick ratio, defined as cash, cash equivalents, short-term investments, and net accounts receivable, divided by current liabilities, increased from 1.75 as of December 31, 2019 to 1.83 as of March 31, 2020. The increase in the quick ratio was primarily attributable to the payment of our bond payable upon maturity in January 2020, partially offset by a decrease in accounts receivable and cash and cash equivalents along with an increase in accounts payable.

[0001564590-20-023537:mdna:64]
Net accounts receivable decreased 4.5% from $90.5 million as of December 31, 2019 to $86.5 million as of March 31, 2020. Our allowance for doubtful accounts was $38 thousand as of December 31, 2019 and March 31, 2020. The decrease in net accounts receivable was due to a decrease in sales volume. Quarterly accounts receivable DSO decreased from 72 days as of December 31, 2019 to 69 days as of March 31, 2020. The decrease in DSO was due to the timing of product shipments and customer mix.

[0001564590-20-023537:mdna:65]
Other receivables increased 39.6% from $16.6 million as of December 31, 2019 to $23.1 million as of March 31, 2020. The increase in other receivables was primarily attributable to an increase in income tax receivables related to the CARES Act partially offset by a decrease in contract assets.

[0001564590-20-023537:mdna:66]
Quarterly inventory turnover decreased from 2.70 turns as of December 31, 2019 to 2.54 turns as of March 31, 2020. Inventory increased 1.2% from $98.3 million as of December 31, 2019 to $99.5 million as of March 31, 2020. Barring COVID-19 uncertainties related to supply chain and demand, we expect inventory levels to fluctuate as we attempt to maintain sufficient inventory in response to seasonal cycles of our business and ensuring competitive lead times while managing the risk of inventory.

[0001564590-20-023537:mdna:67]
Accounts payable increased 6.3% from $44.9 million as of December 31, 2019 to $47.7 million as of March 31, 2020. Accounts payable will fluctuate due to variations in the timing of the receipt of supplies, inventory and services and our subsequent payments for these purchases.

[0001564590-20-023537:mdna:68]
[same as prior period, unchanged from 0001564590-19-040490:mdna:77]

[0001564590-20-023537:mdna:69]
Capital expenditures totaled approximately $1.4 million and $1.9 million for the three months ended March 31, 2020 and 2019, respectively. These expenditures were primarily used to purchase manufacturing and test equipment, software, computer hardware and to finance building improvements.

[0001564590-20-023537:mdna:70]
Our combined short-term and long-term investments decreased $42.6 million from $127.7 million as of December 31, 2019 to $85.1 million as of March 31, 2020. This decrease reflects the maturity of a certificate deposit which served as collateral for our revenue bond and the impact of net realized and unrealized gains and losses on our investments.

[0001564590-20-023537:mdna:71]
We typically invest all available cash not required for immediate use in operations, primarily in securities that we believe bear minimal risk of loss. See Note 6 of the Notes to Condensed Consolidated Financial Statements included in Part I, Item 1 of this report for additional information. As of March 31, 2020, investments were classified as available-for-sale and had a combined duration of 1.64 years with an average Standard & Poor’s credit rating of AA. Because our investment portfolio has a high-quality rating and contractual maturities of short duration, we are able to obtain prices for these bonds derived from observable market inputs, or for similar securities traded in an active market, on a daily basis.

[0001564590-20-023537:mdna:72]
Our long-term investments decreased 16.2% from $94.5 million as of December 31, 2019 to $79.1 million as of March 31, 2020.  Our investments include various marketable equity securities classified as long-term investments with a fair market value of $24.8 million and $35.8 million, as of March 31, 2020 and December 31, 2019, respectively. Long-term investments as of March 31, 2020 and December 31, 2019 also included $17.1 million and $21.7 million, respectively, related to our deferred compensation plans, and $0.3 million for both years, of other investments, consisting of interests in two private equity funds.

[0001564590-20-023537:mdna:73]
[same as prior period, unchanged from 0001564590-19-040490:mdna:83]

[0001564590-20-023537:mdna:74]
[same as prior period, unchanged from 0001564590-19-040490:mdna:84]

[0001564590-20-023537:mdna:75]
In July 2003, our Board of Directors elected to begin declaring quarterly dividends on our common stock considering the tax treatment of dividends and adequate levels of Company liquidity. During the three months ended March 31, 2020 and 2019, we paid dividends totaling $4.3 million. The continued payment of dividends is at the discretion of the Company’s Board of Directors and is subject to general business conditions and ongoing financial results of the Company.

[0001564590-20-023537:mdna:76]
[same as prior period, unchanged from 0001564590-19-040490:mdna:86]

[0001564590-20-023537:mdna:77]
In conjunction with the 1995 expansion of our Huntsville, Alabama, facility, we were approved for participation in an incentive program offered by the State of Alabama Industrial Development Authority (the “Authority”). Pursuant to the program, in January 1995, the Authority issued $20.0 million of its taxable revenue bonds and loaned the proceeds from the sale of these taxable revenue bonds to the Company. Further advances on the taxable revenue bonds were made by the Authority, bringing the total amount outstanding to $50.0 million. The bonds matured on January 1, 2020, and the outstanding balance of $24.6 million was repaid in full on January 2, 2020.

[0001564590-20-023537:mdna:78]
[same as prior period, unchanged from 0001564590-19-040490:mdna:88]

[0001564590-20-023537:mdna:79]
Since 1997, our Board of Directors has approved multiple share repurchase programs that have authorized repurchases of our common stock, which are implemented through open market or private purchases from time to time as conditions warrant. We currently have authorization to repurchase an additional 2.5 million shares of our common stock under the current authorization of up to 5.0 million shares. During the three months ended March 31, 2020, there were no common stock repurchases. During the three months ended March 31, 2019, we repurchased 13,000 shares of our common stock for $0.2 million at an average price of $14.06 per share.

[0001564590-20-023537:mdna:80]
[same as prior period, unchanged from 0001564590-19-040490:mdna:92]

[0001564590-20-023537:mdna:81]
We do not have off-balance sheet financing arrangements and have not engaged in any related party transactions or arrangements with unconsolidated entities or other persons that are reasonably likely to materially affect liquidity or the availability of or requirements for capital resources. During the three months ended March 31, 2020, there have been no material changes in contractual obligations and commercial commitments from those discussed in the 2019 Form 10-K.

[0001564590-20-023537:mdna:82]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, of which $7.7 million has been applied as of March 31, 2020.
