# ADTN notes — 0001564590-20-023537


## us-gaap:SignificantAccountingPoliciesTextBlock

[0001564590-20-023537:notes:1]
[same as prior period, unchanged from 0001564590-19-040490:notes:1]

[0001564590-20-023537:notes:2]
[same as prior period, unchanged from 0001564590-19-040490:notes:2]

[0001564590-20-023537:notes:3]
The accompanying unaudited condensed consolidated financial statements of ADTRAN®, Inc. and its subsidiaries (“ADTRAN”, the “Company”, “we”, “our” or “us”) have been prepared pursuant to the rules and regulations of the Securities and Exchange Commission (the “SEC”) applicable to interim financial information presented in Quarterly Reports on Form 10-Q. Accordingly, certain information and notes required by generally accepted accounting principles in the United States of America (“U.S. GAAP”) for complete financial statements are not included herein. The December 31, 2019 Condensed Consolidated Balance Sheet is derived from audited financial statements but does not include all disclosures required by U.S. GAAP.

[0001564590-20-023537:notes:4]
In the opinion of management, all adjustments necessary to fairly state these interim statements have been recorded and are of a normal and recurring nature. The results of operations for an interim period are not necessarily indicative of the results for the full year. The interim financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in ADTRAN’s Annual Report on Form 10-K for the year ended December 31, 2019, filed with the SEC on February 25, 2020.

[0001564590-20-023537:notes:5]
[same as prior period, unchanged from 0001564590-19-040490:notes:5]

[0001564590-20-023537:notes:6]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenue and expense during the reporting period. The more significant estimates include excess and obsolete inventory reserves, warranty reserves, customer rebates, determination and accrual of deferred revenue components of element sales agreements, estimated costs to complete obligations associated with deferred and accrued revenues and network installations, estimated income tax provision and income tax contingencies, fair value of stock-based compensation, assessment of goodwill and other intangibles for impairment, estimated lives of intangible assets, estimated pension liability and fair value of investments. Actual amounts could differ significantly from these estimates.

[0001564590-20-023537:notes:7]
We assessed certain accounting matters that generally require consideration of forecasted financial information in context with the information reasonably available to us and the unknown future impacts of the novel coronavirus (“COVID-19”) as of March 31, 2020 and through the date of this report. The accounting matters assessed included, but were not limited to, the allowance for doubtful accounts, stock-based compensation, carrying value of goodwill, intangibles and other long-lived assets, financial assets, valuation allowances for tax assets and revenue recognition. While there was not a material impact to our consolidated financial statements as of and for the quarter ended March 31, 2020 resulting from these assessments, future assessments of our current expectations at that time of the magnitude and duration of the COVID-19 pandemic, as well as other factors, could result in material impacts to our consolidated financial statements in future reporting periods.

[0001564590-20-023537:notes:8]
[same as prior period, unchanged from 0001564590-19-040490:notes:8]

[0001564590-20-023537:notes:9]
During the three months ended June 30, 2019, it was determined that a $1.0 million cash inflow related to an insurance recovery was incorrectly classified as a cash flow from operations instead of a cash flow from investing activities within the unaudited Condensed Consolidated Statement of Cash Flows for the three months ended March 31, 2019. The Company corrected this misstatement in the unaudited Condensed Consolidated Statement of Cash Flows as an out of period adjustment as of and for the six months ended June 30, 2019 to correctly reflect the $1.0 million insurance recovery as a cash inflow from investing activities. Management had previously determined that this misstatement was not material to any of its previously issued financial statements on either a quantitative or qualitative basis.

[0001564590-20-023537:notes:10]
During the three months ended March 31, 2020, it was determined that certain investments held in the Company’s stock for a deferred compensation plan accounted for as a Rabbi trust were incorrectly classified as Long-term investments with the fair value of such investments incorrectly marked to market at each period end rather than classified as Treasury stock held at historical cost. This plan has been in existence since 2011. The Company corrected this misstatement as an out of period adjustment in the three months ended March 31, 2020 by remeasuring the investment assets to their historical cost basis through the recording of a Net investment gain of $1.5 million in the unaudited Condensed Consolidated Statement of Income (Loss) and then correcting the classification by decreasing the Long-term investment balance at its remeasured cost basis of $2.8 million to Treasury stock in the unaudited Condensed Consolidated Balance Sheet as of March 31, 2020. Management has determined that this misstatement was not material to any of its previously issued financial statements and that correction of the misstatement is also not expected to be material to the 2020 annual financial results on either a quantitative or qualitative basis.

[0001564590-20-023537:notes:11]
Recently Adopted Accounting Pronouncements

[0001564590-20-023537:notes:12]
During 2020, we adopted the following accounting standards, which had the following impacts on our consolidated financial statements:

[0001564590-20-023537:notes:13]
In June 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. ASU 2016-13 requires the measurement and recognition of expected credit losses for financial instruments held at amortized cost. In November 2018, the FASB issued ASU 2018-19, Codification Improvements to Topic 326 Financial Instruments – Credit Losses, that clarifies receivables arising from operating leases are not within the scope of the credit losses standard, but rather should be accounted for in accordance with the standard for leases. In April 2019, the FASB issued ASU 2019-04, Codification Improvements to Topic 326, Financial Instruments–Credit Losses, Topic 815, Derivatives and Hedging, and Topic 825, Financial Instruments, which clarifies the accounting for transfers between classifications of debt securities and clarifies that entities should include expected recoveries on financial assets in the calculation of the current expected credit loss allowance. In addition, renewal options that are not unconditionally cancelable should be considered in the determination of expected credit losses. In May 2019, the FASB issued ASU 2019-05, Financial Instruments – Credit Losses (Topic 326): Targeted Transition Relief, which amends ASU 2016-13 to allow companies, upon adoption, to elect the fair value option on financial instruments that were previously recorded at amortized cost if they meet certain criteria. In November 2019, the FASB issued ASU 2019-11, Codification improvements to Topic 326, Financial Instruments – Credit Losses, which makes various narrow-scope amendments to the new credit losses standard, such as providing disclosure relief for accrued interest receivables. All of these ASUs were codified as part of ASC Topic 326 and were effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. The Company adopted this standard on January 1, 2020, using a modified-retrospective approach and, therefore, elected to carry forward legacy disclosures for comparative periods and did not adjust the comparative period financial information. Additionally, the Company made an accounting policy election, at the class of financing receivable, not to measure the allowance for credit losses for accrued interest receivables, as the Company writes off the uncollectable accrued interest receivable by reversing any previously recorded interest income in a timely manner (as soon as these amounts are determined to be uncollectable). The adoption of this standard did not have a material effect on our consolidated financial statements. See Note 18 for additional information.

[0001564590-20-023537:notes:14]
In January 2017, the FASB issued ASU 2017-04, Intangibles – Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment. ASU 2017-04 simplifies the measurement of goodwill by eliminating step 2 of the goodwill impairment test. Under ASU 2017-04, entities are required to compare the fair value of a reporting unit to its carrying amount and recognize an impairment charge for the amount by which the carrying amount exceeds the reporting unit’s fair value. ASU 2017-04 was effective for annual or interim impairment tests performed in fiscal years beginning after December 15, 2019. The Company adopted ASU 2017-04 on January 1, 2020, and the amendments were applied prospectively. The adoption of this standard did not have a material effect on our consolidated financial statements.

[0001564590-20-023537:notes:15]
In August 2018, the FASB issued ASU 2018-13, Fair Value Measurement (Topic 820): Disclosure Framework – Changes to the Disclosure Requirements for Fair Value Measurement, which changes the fair value measurement disclosure requirements of ASC 820, Fair Value Measurement. The amendments in this ASU are the result of a broader disclosure project, Concepts Statement No. 8 — Conceptual Framework for Financial Reporting — Chapter 8 — Notes to Financial Statements, which the FASB finalized on August 28, 2018. The FASB used the guidance in the Concepts Statement to improve the effectiveness of ASC 820’s disclosure requirements. ASU 2018-13 provides users of financial statements with information about assets and liabilities measured at fair value in the statement of financial position or disclosed in the notes to the financial statements. More specifically, ASU 2018-13 requires disclosures about the valuation techniques and inputs that are used to arrive at measures of fair value, including judgments and assumptions that are made in determining fair value. In addition, ASU 2018-13 requires disclosures regarding the uncertainty in the fair value measurements as of the reporting date and how changes in fair value measurements affect performance and cash flows. The Company adopted ASU 2018-13 on January 1, 2020, and the adoption of this standard did not have a material effect on our consolidated financial statements.

[0001564590-20-023537:notes:16]
In August 2018, the FASB issued ASU 2018-15, Intangibles-Goodwill and Other-Internal – Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract.  ASU 2018-15 clarifies certain aspects of ASU 2015-05, Customer’s Accounting for Fees Paid in a Cloud Computing Arrangement. Specifically, ASU 2018-15 aligns the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementations costs incurred to develop or obtain internal use software. The Company adopted ASU 2018-15 on January 1, 2020, retrospectively. The adoption of this standard resulted in a reclassification of $5.6 million from property, plant and equipment to other assets for certain previously capitalized costs related to information technology implementation projects that had not yet been placed in service on the consolidated balance sheet as of March 31, 2020 and December 31, 2019. There was minimal impact to previously reported net cash provided by (used in) operations on the statement of cash flows and no impact to the statements of income (loss) as no portion of the capitalized asset was depreciated in prior periods.

[0001564590-20-023537:notes:17]
The following table illustrates the impact of adoption of ASU 2018-15 on the Condensed Consolidated Balance Sheet as of December 31, 2019:

[0001564590-20-023537:notes:18]
|  |  | As of December 31, 2019 |  |
| (In thousands) |  | Pre-Adoption |  |  | Effect of Adoption |  |  | As Presented Now |  |
| Condensed Consolidated Balance Sheet |  |  |  |  |  |  |  |  |  |  |  |  |
| Property, plant and equipment, net |  | $ | 73,708 |  |  | $ | (5,622 | ) |  | $ | 68,086 |  |
| Other assets |  | $ | 14,261 |  |  | $ | 5,622 |  |  | $ | 19,883 |  |

[0001564590-20-023537:notes:19]
The following table illustrates the impact of adoption of ASU 2018-15 on the Condensed Consolidated Statement of Income and Condensed Consolidated Statement of Cash Flows for the three months ended March 31, 2019:

[0001564590-20-023537:notes:20]
|  |  | Three Months Ended March 31, 2019 |  |
| (In thousands) |  | Pre-Adoption |  |  | Effect of Adoption |  |  | As Presented Now |  |
| Condensed Consolidated Statement of Income |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 770 |  |  | $ | — |  |  | $ | 770 |  |
| Condensed Consolidated Statement of Cash Flows |  |  |  |  |  |  |  |  |  |  |  |  |
| Net cash provided by operating activities |  | $ | 9,712 |  |  | $ | — |  |  | $ | 9,712 |  |

[0001564590-20-023537:notes:21]
[same as prior period, unchanged from 0001564590-19-040490:notes:10]

[0001564590-20-023537:notes:22]
In August 2018, the FASB issued ASU 2018-14, Compensation – Retirement Benefits – Defined Benefit Plans – General (Subtopic 715-20): Disclosure Framework-Changes to the Disclosure Requirements for Defined Benefit Plans, which makes changes to and clarifies the disclosure requirements related to defined benefit pension and other postretirement plans. ASU 2018-14 requires additional disclosures related to the reasons for significant gains and losses affecting the benefit obligation and an explanation of any other significant changes in the benefit obligation or plan assets that are not otherwise apparent in other disclosures required by ASC 715. ASU 2018-14 also clarifies the guidance in ASC 715 to require disclosure of the projected benefit obligation (“PBO”) and fair value of plan assets for pension plans with PBOs in excess of plan assets and the accumulated benefit obligation (“ABO”) and fair value of plan assets for pension plans with ABOs in excess of plan assets. ASU 2018-14 is effective for public business entities for fiscal years ending after December 15, 2020. The Company is currently evaluating the impact this guidance will have on its related disclosures.

[0001564590-20-023537:notes:23]
In December 2019, the FASB issued ASU 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes, which simplifies the accounting for income taxes by removing various exceptions, such as the exception to the incremental approach for intra-period tax allocation when there is a loss from continuing operations and income or a gain from other items. The amendments in this update also simplify the accounting for income taxes related to income-based franchise taxes and require that an entity reflect enacted tax laws or rates in the annual effective tax rate computation in the interim period that includes the enactment date. ASU 2019-12 is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2020, with early adoption permitted. The Company is currently evaluating the impact of this new standard on its consolidated financial statements.


## us-gaap:RevenueFromContractWithCustomerTextBlock

[0001564590-20-023537:notes:24]
2. REVENUE

[0001564590-20-023537:notes:25]
The following is a description of the principal activities from which revenue is generated by reportable segment:

[0001564590-20-023537:notes:26]
Network Solutions Segment - Includes hardware products and software-defined next-generation virtualized solutions used in service provider or business networks, as well as prior generation products.

[0001564590-20-023537:notes:27]
Services & Support Segment - Includes maintenance, network implementation, solutions integration and managed services, which include hosted cloud services and subscription services.

[0001564590-20-023537:notes:28]
See Note 15 for additional information on reportable segments.

[0001564590-20-023537:notes:29]
[same as prior period, unchanged from 0001564590-19-040490:notes:45]

[0001564590-20-023537:notes:30]
In addition to our reporting segments, revenue is also reported for the following three categories – Access & Aggregation, Subscriber Solutions & Experience and Traditional & Other Products.

[0001564590-20-023537:notes:31]
The following table disaggregates revenue by reportable segment and revenue category for the three months ended March 31, 2020 and 2019:

[0001564590-20-023537:notes:32]
|  |  | Three Months Ended |  |
|  |  | March 31, 2020 |  |  | March 31, 2019 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 53,055 |  |  | $ | 12,911 |  |  | $ | 65,966 |  |  | $ | 85,673 |  |  | $ | 14,105 |  |  | $ | 99,778 |  |
| Subscriber Solutions & Experience |  |  | 39,983 |  |  |  | 2,196 |  |  |  | 42,179 |  |  |  | 34,719 |  |  |  | 2,034 |  |  |  | 36,753 |  |
| Traditional & Other Products |  |  | 4,334 |  |  |  | 2,044 |  |  |  | 6,378 |  |  |  | 5,430 |  |  |  | 1,830 |  |  |  | 7,260 |  |
| Total |  | $ | 97,372 |  |  | $ | 17,151 |  |  | $ | 114,523 |  |  | $ | 125,822 |  |  | $ | 17,969 |  |  | $ | 143,791 |  |

[0001564590-20-023537:notes:33]
Revenue allocated to remaining performance obligations represents contract revenues that have not yet been recognized for contracts with a duration greater than one year. As of March 31, 2020, we did not have any significant performance obligations related to customer contracts that had an original expected duration of one year or more, other than maintenance services, which are satisfied over time. As a practical expedient, for certain contracts we recognize revenue equal to the amounts we are entitled to invoice which correspond to the value of completed performance obligations to date. The amount related to these performance obligations was $14.3 million and $13.6 million as of March 31, 2020 and December 31, 2019, respectively. The Company expects to recognize 69% of the $14.3 million as of March 31, 2020 over the next 12 months with the remainder to be recognized thereafter.

[0001564590-20-023537:notes:34]
[same as prior period, unchanged from 0001564590-19-040490:notes:53]

[0001564590-20-023537:notes:35]
| (In thousands) |  | March 31, 2020 |  |  | December 31, 2019 |  |
| Accounts receivable, net |  | $ | 86,465 |  |  | $ | 90,531 |  |
| Contract assets(1) |  | $ | 1,354 |  |  | $ | 2,812 |  |
| Unearned revenue |  | $ | 12,465 |  |  | $ | 11,963 |  |
| Non-current unearned revenue |  | $ | 4,476 |  |  | $ | 6,012 |  |

[0001564590-20-023537:notes:36]
|  | (1) | Included in other receivables on the Condensed Consolidated Balance Sheets. |

[0001564590-20-023537:notes:37]
Of the outstanding unearned revenue balances as of December 31, 2019 and December 31, 2018, $5.7 million and $6.9 million was recognized as revenue during the three months ended March 31, 2020 and March 31, 2019, respectively.


## us-gaap:DisaggregationOfRevenueTableTextBlock

[0001564590-20-023537:notes:38]
The table below presents sales information by category for the three months ended March 31, 2020 and 2019:

[0001564590-20-023537:notes:39]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2020 |  |  | 2019 |  |
| Access & Aggregation |  | $ | 65,966 |  |  | $ | 99,778 |  |
| Subscriber Solutions & Experience |  |  | 42,179 |  |  |  | 36,753 |  |
| Traditional & Other Products |  |  | 6,378 |  |  |  | 7,260 |  |
| Total |  | $ | 114,523 |  |  | $ | 143,791 |  |


## us-gaap:IncomeTaxDisclosureTextBlock

[0001564590-20-023537:notes:40]
3. INCOME TAXES

[0001564590-20-023537:notes:41]
Our effective tax rate decreased from an expense of 28.6% for the three months ended March 31, 2019, to a benefit of 30.5% for the three months ended March 31, 2020. The decrease in the effective tax rate between the two periods was primarily driven by a tax benefit of $7.4 million recognized during the three months ended March 31, 2020 as a result of the Coronavirus Aid, Relief, and Economic Security Act (the “CARES Act”) signed into law on March 27, 2020, which allowed for the carryback of federal net operating losses, partially offset with tax expense in our international operations and changes in our valuation allowance related to our domestic operations. The increase in the valuation allowance against our domestic deferred tax assets was recorded in the amount of $6.1 million during the three months ended March 31, 2020.

[0001564590-20-023537:notes:42]
The Company continually reviews the adequacy of its valuation allowance and recognizes the benefits of deferred tax assets only as the reassessment indicates that it is more likely than not that the deferred tax assets will be recognized in accordance with ASC 740, Income Taxes. As of March 31, 2020, the Company had deferred tax assets totaling $62.2 million, and a valuation allowance totaling $54.7 million had been established against those deferred tax assets. The remaining $7.4 million in deferred tax assets not offset by a valuation allowance is located in various foreign jurisdictions where the Company believes it is more likely than not we will realize these deferred tax assets. Our assessment of the realizability of our deferred tax assets includes the evaluation of evidence, some of which requires significant judgement, including historical operating results, the evaluation of our three-year cumulative income position, future taxable income projections and tax planning strategies. Should management’s conclusion change in the future and additional valuation allowance or a partial or full release of the valuation allowance is necessary, it could have a material effect on our consolidated financial statements.

[0001564590-20-023537:notes:43]
Supplemental balance sheet information related to deferred tax assets as of March 31, 2020 and December 31, 2019 is as follows:

[0001564590-20-023537:notes:44]
|  |  | March 31, 2020 |  |
| (In thousands) |  | Deferred Tax Assets |  |  | Valuation Allowance |  |  | Deferred Tax Assets, net |  |
| Domestic |  | $ | 52,355 |  |  | $ | (52,355 | ) |  | $ | — |  |
| International |  |  | 9,797 |  |  |  | (2,350 | ) |  |  | 7,447 |  |
| Total |  | $ | 62,152 |  |  | $ | (54,705 | ) |  | $ | 7,447 |  |

[0001564590-20-023537:notes:45]
|  |  | December 31, 2019 |  |
| (In thousands) |  | Deferred Tax Assets |  |  | Valuation Allowance |  |  | Deferred Tax Assets, net |  |
| Domestic |  | $ | 46,266 |  |  | $ | (46,266 | ) |  | $ | — |  |
| International |  |  | 9,911 |  |  |  | (2,350 | ) |  |  | 7,561 |  |
| Total |  | $ | 56,177 |  |  | $ | (48,616 | ) |  | $ | 7,561 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001564590-20-023537:notes:46]
4. PENSION BENEFIT PLAN

[0001564590-20-023537:notes:47]
The following table summarizes the components of net periodic pension cost related to a defined benefit pension plan covering employees in certain foreign countries for the three months ended March 31, 2020 and 2019:

[0001564590-20-023537:notes:48]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2020 |  |  | 2019 |  |
| Service cost |  | $ | 310 |  |  | $ | 375 |  |
| Interest cost |  |  | 108 |  |  |  | 162 |  |
| Expected return on plan assets |  |  | (410 | ) |  |  | (355 | ) |
| Amortization of actuarial losses |  |  | 237 |  |  |  | 203 |  |
| Net periodic pension cost |  | $ | 245 |  |  | $ | 385 |  |

[0001564590-20-023537:notes:49]
The components of net periodic pension cost, other than the service cost component, are included in other income (expense), net in the Condensed Consolidated Statements of Income (Loss). Service cost is included in cost of sales, selling, general and administrative expenses and research and development expenses in the Condensed Consolidated Statements of Income (Loss).


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001564590-20-023537:notes:50]
5. STOCK-BASED COMPENSATION

[0001564590-20-023537:notes:51]
The following table summarizes stock-based compensation expense related to stock options, performance stock units (“PSUs”), restricted stock units (“RSUs”) and restricted stock for the three months ended March 31, 2020 and 2019:

[0001564590-20-023537:notes:52]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2020 |  |  | 2019 |  |
| Stock-based compensation expense included in cost of sales |  | $ | 115 |  |  | $ | 104 |  |
| Selling, general and administrative expense |  |  | 1,075 |  |  |  | 1,063 |  |
| Research and development expense |  |  | 601 |  |  |  | 692 |  |
| Stock-based compensation expense included in operating expenses |  |  | 1,676 |  |  |  | 1,755 |  |
| Total stock-based compensation expense |  |  | 1,791 |  |  |  | 1,859 |  |
| Tax benefit for expense associated with stock options, PSUs, RSUs and restricted stock |  |  | (427 | ) |  |  | (443 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 1,364 |  |  | $ | 1,416 |  |

[0001564590-20-023537:notes:53]
[same as prior period, unchanged from 0001564590-19-040490:notes:81]

[0001564590-20-023537:notes:54]
The following table summarizes PSUs, RSUs and restricted stock outstanding as of December 31, 2019 and March 31, 2020 and the changes that occurred during the three months ended March 31, 2020.

[0001564590-20-023537:notes:55]
|  |  | Number of Shares (in thousands) |  |  | Weighted Avg. Grant Date Fair Value (per share) |  |
| Unvested PSUs, RSUs and restricted stock outstanding, December 31, 2019 |  |  | 1,891 |  |  | $ | 14.58 |  |
| PSUs, RSUs and restricted stock granted |  |  | 394 |  |  | $ | 8.18 |  |
| PSUs, RSUs and restricted stock vested |  |  | (13 | ) |  | $ | 12.32 |  |
| PSUs, RSUs and restricted stock forfeited |  |  | (422 | ) |  | $ | 21.12 |  |
| Unvested PSUs, RSUs and restricted stock outstanding, March 31, 2020 |  |  | 1,850 |  |  | $ | 11.75 |  |

[0001564590-20-023537:notes:56]
During the three months ended March 31, 2020, the Company issued 0.3 million performance-based PSUs to its executive officers and certain employees. The grant-date fair value of these performance-based awards is based on the closing price of the Company’s stock on the date of grant. These awards vest over a three-year period, subject to the grantee’s continued employment, with the ability to earn shares in a range of 0% to 142.8% of the awarded number of PSUs based on the achievement of defined performance targets. Equity-based compensation expense with respect to these awards will be adjusted over the vesting period to reflect the probability of achievement of performance targets defined in the award agreements.

[0001564590-20-023537:notes:57]
The fair value of RSUs and restricted stock is equal to the closing price of our stock on the business day immediately preceding the grant date. The fair value of PSUs with market conditions is calculated using a Monte Carlo simulation valuation method.

[0001564590-20-023537:notes:58]
As of March 31, 2020, total unrecognized compensation expense related to non-vested market-based PSUs, RSUs and restricted stock was approximately $15.3 million, which will be recognized over the remaining weighted-average period of 2.6 years. Unrecognized compensation expense will be adjusted for actual forfeitures.

[0001564590-20-023537:notes:59]
As of March 31, 2020, 1.4 million shares were available for issuance under shareholder-approved equity plans in connection with the grant and exercise of stock options, PSUs, RSUs or restricted stock.

[0001564590-20-023537:notes:60]
[same as prior period, unchanged from 0001564590-19-040490:notes:73]

[0001564590-20-023537:notes:61]
The following table summarizes stock options outstanding as of December 31, 2019 and March 31, 2020 and the changes that occurred during the three months ended March 31, 2020:

[0001564590-20-023537:notes:62]
|  |  | Number of Stock Options (in thousands) |  |  | Weighted Avg. Exercise Price (per share) |  |  | Weighted Avg. Remaining Contractual Life (in years) |  |  | Aggregate Intrinsic Value (in thousands) |  |
| Stock options outstanding, December 31, 2019 |  |  | 3,572 |  |  | $ | 22.88 |  |  |  | 3.4 |  |  | $ | — |  |
| Stock options exercised |  |  | — |  |  | $ | — |  |  |  |  |  |  |  |  |  |
| Stock options forfeited |  |  | — |  |  | $ | — |  |  |  |  |  |  |  |  |  |
| Stock options expired |  |  | (125 | ) |  | $ | 23.49 |  |  |  |  |  |  |  |  |  |
| Stock options outstanding, March 31, 2020 |  |  | 3,447 |  |  | $ | 22.86 |  |  |  | 3.1 |  |  | $ | — |  |
| Stock options exercisable, March 31, 2020 |  |  | 3,444 |  |  | $ | 22.86 |  |  |  | 3.1 |  |  | $ | — |  |

[0001564590-20-023537:notes:63]
As of March 31, 2020, total unrecognized compensation expense related to non-vested stock options was approximately $7 thousand, which will be recognized over the remaining weighted-average period of 0.6 years. Unrecognized compensation expense will be adjusted for actual forfeitures.

[0001564590-20-023537:notes:64]
There were no stock options granted during the three months ended March 31, 2020 and 2019. All of the options were previously issued at exercise prices that approximated fair market value at the date of grant.

[0001564590-20-023537:notes:65]
The aggregate intrinsic value of stock options represents the total pre-tax intrinsic value (the difference between ADTRAN’s closing stock price on the last trading day of the quarter and the exercise price, multiplied by the number of in-the-money options) that would have been received by the option holders had all option holders exercised their options on March 31, 2020. The amount of aggregate intrinsic value will change based on the fair market value of ADTRAN’s stock and was zero as of March 31, 2020. The total pre-tax intrinsic value of options exercised during the three months ended March 31, 2020 was zero.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001564590-20-023537:notes:66]
6. INVESTMENTS

[0001564590-20-023537:notes:67]
Debt Securities and Other Investments

[0001564590-20-023537:notes:68]
As of March 31, 2020, the following debt securities and other investments were included on the Condensed Consolidated Balance Sheet and recorded at fair value:

[0001564590-20-023537:notes:69]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 8,967 |  |  | $ | 43 |  |  | $ | (87 | ) |  | $ | 8,923 |  |
| Municipal fixed-rate bonds |  |  | 931 |  |  |  | 3 |  |  |  | — |  |  |  | 934 |  |
| Asset-backed bonds |  |  | 6,052 |  |  |  | 17 |  |  |  | (76 | ) |  |  | 5,993 |  |
| Mortgage/Agency-backed bonds |  |  | 8,389 |  |  |  | 140 |  |  |  | (62 | ) |  |  | 8,467 |  |
| U.S. government bonds |  |  | 12,788 |  |  |  | 319 |  |  |  | (6 | ) |  |  | 13,101 |  |
| Other |  |  | 442 |  |  |  | — |  |  |  | — |  |  |  | 442 |  |
| Available-for-sale debt securities held at fair value |  | $ | 37,569 |  |  | $ | 522 |  |  | $ | (231 | ) |  | $ | 37,860 |  |

[0001564590-20-023537:notes:70]
As of December 31, 2019, the following debt securities and other investments were included on the Condensed Consolidated Balance sheet and recorded at fair value:

[0001564590-20-023537:notes:71]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 9,304 |  |  | $ | 80 |  |  | $ | — |  |  | $ | 9,384 |  |
| Municipal fixed-rate bonds |  |  | 930 |  |  |  | — |  |  |  | — |  |  |  | 930 |  |
| Asset-backed bonds |  |  | 6,867 |  |  |  | 26 |  |  |  | (3 | ) |  |  | 6,890 |  |
| Mortgage/Agency-backed bonds |  |  | 6,944 |  |  |  | 26 |  |  |  | (8 | ) |  |  | 6,962 |  |
| U.S. government bonds |  |  | 12,311 |  |  |  | 21 |  |  |  | (9 | ) |  |  | 12,323 |  |
| Foreign government bonds |  |  | 372 |  |  |  | — |  |  |  | (1 | ) |  |  | 371 |  |
| Variable rate demand notes |  |  | 800 |  |  |  | — |  |  |  | — |  |  |  | 800 |  |
| Available-for-sale debt securities held at fair value |  | $ | 37,528 |  |  | $ | 153 |  |  | $ | (21 | ) |  | $ | 37,660 |  |

[0001564590-20-023537:notes:72]
As of March 31, 2020, contractual maturities related to debt securities and other investments were as follows:

[0001564590-20-023537:notes:73]
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset- backed bonds |  |  | Mortgage / Agency- backed bonds |  |  | U.S. government bonds |  |  | Other |  |
| Less than one year |  | $ | 3,274 |  |  | $ | — |  |  | $ | 101 |  |  | $ | — |  |  | $ | 61 |  |  | $ | 442 |  |
| One to two years |  |  | 3,702 |  |  |  | 934 |  |  |  | 389 |  |  |  | 584 |  |  |  | 5,376 |  |  |  | — |  |
| Two to three years |  |  | 1,947 |  |  |  | — |  |  |  | 1,559 |  |  |  | 1,769 |  |  |  | 7,285 |  |  |  | — |  |
| Three to five years |  |  | — |  |  |  | — |  |  |  | 2,174 |  |  |  | 107 |  |  |  | 379 |  |  |  | — |  |
| Five to ten years |  |  | — |  |  |  | — |  |  |  | 1,505 |  |  |  | 1,655 |  |  |  | — |  |  |  | — |  |
| More than ten years |  |  | — |  |  |  | — |  |  |  | 265 |  |  |  | 4,352 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 8,923 |  |  | $ | 934 |  |  | $ | 5,993 |  |  | $ | 8,467 |  |  | $ | 13,101 |  |  | $ | 442 |  |

[0001564590-20-023537:notes:74]
Actual maturities may differ from contractual maturities as some borrowers have the right to call or prepay obligations with or without call or prepayment penalties.

[0001564590-20-023537:notes:75]
Realized gains and losses on sales of debt securities are computed under the specific identification method. The following table presents gross realized gains and losses related to our debt securities:

[0001564590-20-023537:notes:76]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2020 |  |  | 2019 |  |
| Gross realized gains on debt securities |  | $ | 43 |  |  | $ | 41 |  |
| Gross realized losses on debt securities |  |  | (20 | ) |  |  | (19 | ) |
| Total gain recognized, net |  | $ | 23 |  |  | $ | 22 |  |

[0001564590-20-023537:notes:77]
The Company’s investment policy provides limitations for issuer concentration, which limits, at the time of purchase, the concentration in any one issuer to 5% of the market value of our total investment portfolio. The Company did not purchase any available-for-sale debt security with credit deterioration during the three months ended March 31, 2020.

[0001564590-20-023537:notes:78]
Marketable Equity Securities

[0001564590-20-023537:notes:79]
Our marketable equity securities consist of publicly traded stock, funds and certain other investments measured at fair value or cost (where appropriate).

[0001564590-20-023537:notes:80]
During the three months ended March 31, 2019, an outstanding note receivable of $4.3 million was repaid and reissued in the form of debt and equity. Of the outstanding $4.3 million, $3.4 million was issued as an equity investment, which represented a non-cash investing activity. We elected to record this equity investment that does not have a readily determinable fair value using the measurement alternative. Under the measurement alternative, equity investments that do not have a readily determinable fair value can be recorded at cost less impairment, if any, adjusted for observable price changes for an identical or similar investment. The carrying value of this investment under the measurement alternative was $3.4 million as of December 31, 2019. During the three months ended March 31, 2020, an impairment charge of $1.6 million was recorded related to this equity investment, which is included in net investment gain (loss) on the Condensed Consolidated Statement of Income (Loss). As a result, the carrying value of this investment was $1.8 million as of March 31, 2020. The remaining amount, $0.9 million of the original $4.3 million note receivable, was reissued as a new note receivable, which is included in long-term investments on the Condensed Consolidated Balance Sheets as of March 31, 2020 and December 31, 2019, and represented a non-cash operating activity during the three months ended March 31, 2019. No impairment charge was recognized related to the note receivable as it is a secured loan.

[0001564590-20-023537:notes:81]
Realized and unrealized gains and losses related to marketable equity securities for the three months ended March 31, 2020 and 2019 were as follows:

[0001564590-20-023537:notes:82]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2020 |  |  | 2019 |  |
| Realized losses on equity securities sold |  | $ | (2,436 | ) |  | $ | (14 | ) |
| Unrealized gains (losses) on equity securities held |  |  | (8,464 | ) |  |  | 5,918 |  |
| Total gain (loss) recognized, net |  | $ | (10,900 | ) |  | $ | 5,904 |  |

[0001564590-20-023537:notes:83]
U.S. GAAP establishes a three-level valuation hierarchy based upon observable and unobservable inputs for fair value measurement of financial instruments:

[0001564590-20-023537:notes:84]
• Level 1 – Observable outputs; values based on unadjusted quoted prices for identical assets or liabilities in an active market;

[0001564590-20-023537:notes:85]
• Level 2 – Significant inputs that are observable; values based on quoted prices in markets that are not active or model inputs that are observable either directly or indirectly;

[0001564590-20-023537:notes:86]
• Level 3 – Significant unobservable inputs; values based on prices or valuation techniques that require inputs that are both unobservable and significant to the overall fair value measurement. These inputs could include information supplied by investees.

[0001564590-20-023537:notes:87]
The Company’s cash equivalents and investments held at fair value are categorized into this hierarchy as follows:

[0001564590-20-023537:notes:88]
|  |  |  |  |  |  | Fair Value Measurements as of March 31, 2020 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 4,826 |  |  | $ | 4,826 |  |  | $ | — |  |  | $ | — |  |
| Commercial paper |  |  | 500 |  |  |  | — |  |  |  | 500 |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 8,923 |  |  |  | — |  |  |  | 8,923 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 934 |  |  |  | — |  |  |  | 934 |  |  |  | — |  |
| Asset-backed bonds |  |  | 5,993 |  |  |  | — |  |  |  | 5,993 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 8,467 |  |  |  | — |  |  |  | 8,467 |  |  |  | — |  |
| U.S. government bonds |  |  | 13,101 |  |  |  | 13,101 |  |  |  | — |  |  |  | — |  |
| Other |  |  | 442 |  |  |  | — |  |  |  | — |  |  |  | 442 |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 24,823 |  |  |  | 24,823 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 17,349 |  |  |  | 17,349 |  |  |  | — |  |  |  | — |  |
| Other investments |  |  | 2,106 |  |  |  | 2,106 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 87,464 |  |  | $ | 62,205 |  |  | $ | 24,817 |  |  | $ | 442 |  |

[0001564590-20-023537:notes:89]
|  |  |  |  |  |  | Fair Value Measurements as of December 31, 2019 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,309 |  |  | $ | 1,309 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 9,384 |  |  |  | — |  |  |  | 9,384 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 930 |  |  |  | — |  |  |  | 930 |  |  |  | — |  |
| Asset-backed bonds |  |  | 6,890 |  |  |  | — |  |  |  | 6,890 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 6,962 |  |  |  | — |  |  |  | 6,962 |  |  |  | — |  |
| U.S. government bonds |  |  | 12,323 |  |  |  | 12,323 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 371 |  |  |  | — |  |  |  | 371 |  |  |  | — |  |
| Variable rate demand notes |  |  | 800 |  |  |  | — |  |  |  | 800 |  |  |  | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 35,501 |  |  |  | 35,501 |  |  |  | — |  |  |  | — |  |
| Equity in escrow |  |  | 298 |  |  |  | 298 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 21,698 |  |  |  | 21,698 |  |  |  | — |  |  |  | — |  |
| Other investments |  |  | 2,442 |  |  |  | 2,442 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 98,908 |  |  | $ | 73,571 |  |  | $ | 25,337 |  |  | $ | — |  |

[0001564590-20-023537:notes:90]
The fair value of our Level 2 securities is calculated using a weighted average market price for each security. Market prices are obtained from a variety of industry standard data providers, large financial institutions and other third-party sources. These multiple market prices are used as inputs into a distribution-curve-based algorithm to determine the daily market value of each security.

[0001564590-20-023537:notes:91]
The fair value of Level 3 securities is calculated based on unobservable inputs. Quantitative information with respect to unobservable inputs consists of third-party valuations performed in accordance with ASC 820 – Fair Value Measurement. Inputs used in preparing the third-party valuation included the following assumptions, among others: estimated discount rates and fair market yields.


## us-gaap:InventoryDisclosureTextBlock

[0001564590-20-023537:notes:92]
7. INVENTORY

[0001564590-20-023537:notes:93]
As of March 31, 2020 and December 31, 2019, inventory consisted of the following:

[0001564590-20-023537:notes:94]
|  |  | March 31, |  |  | December 31, |  |
| (In thousands) |  | 2020 |  |  | 2019 |  |
| Raw materials |  | $ | 35,922 |  |  | $ | 36,987 |  |
| Work in process |  |  | 778 |  |  |  | 1,085 |  |
| Finished goods |  |  | 62,815 |  |  |  | 60,233 |  |
| Total inventory, net |  | $ | 99,515 |  |  | $ | 98,305 |  |

[0001564590-20-023537:notes:95]
Inventory reserves are established for estimated excess and obsolete inventory equal to the difference between the cost of the inventory and the estimated net realizable value of the inventory based on estimated reserve percentages, which consider historical usage, known trends, inventory age and market conditions. As of March 31, 2020 and December 31, 2019, inventory reserves were $35.0 million and $34.1 million, respectively.


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001564590-20-023537:notes:96]
8. PROPERTY, PLANT AND EQUIPMENT

[0001564590-20-023537:notes:97]
At March 31, 2020 and December 31, 2019, property, plant and equipment consisted of the following:

[0001564590-20-023537:notes:98]
|  |  | March 31, |  |  | December 31, |  |
| (In thousands) |  | 2020 |  |  | 2019 |  |
| Land |  | $ | 4,575 |  |  | $ | 4,575 |  |
| Building and land improvements |  |  | 34,805 |  |  |  | 34,797 |  |
| Building |  |  | 68,141 |  |  |  | 68,157 |  |
| Furniture and fixtures |  |  | 19,964 |  |  |  | 19,959 |  |
| Computer hardware and software |  |  | 68,957 |  |  |  | 68,777 |  |
| Engineering and other equipment |  |  | 131,140 |  |  |  | 130,430 |  |
| Total property, plant and equipment |  |  | 327,582 |  |  |  | 326,695 |  |
| Less: accumulated depreciation |  |  | (261,082 | ) |  |  | (258,609 | ) |
| Total property, plant and equipment, net |  | $ | 66,500 |  |  | $ | 68,086 |  |

[0001564590-20-023537:notes:99]
Long-lived assets used in operations are reviewed for impairment whenever events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable and the undiscounted cash flows estimated to be generated by the asset are less than the asset’s carrying value. Due to the current economic environment, particularly related to COVID-19, the Company assessed impairment triggers related to long-lived assets during the first quarter of 2020. Based on this assessment, no triggers occurred to perform an impairment test, and no impairment losses of long-lived assets were recorded.

[0001564590-20-023537:notes:100]
Depreciation expense was $3.0 million and $3.2 million for the three months ended March 31, 2020 and 2019, respectively, which is recorded in cost of sales, selling, general and administrative expenses and research and development expenses in the Condensed Consolidated Statements of Income (Loss).


## us-gaap:GoodwillDisclosureTextBlock

[0001564590-20-023537:notes:101]
9. GOODWILL

[0001564590-20-023537:notes:102]
Goodwill was $7.0 million as of March 31, 2020 and December 31, 2019, of which $6.6 million and $0.4 million was allocated to our Network Solutions and Services & Support reportable segments, respectively.

[0001564590-20-023537:notes:103]
The Company evaluates the carrying value of goodwill during the fourth quarter of each year and between annual evaluations if events occur or circumstances change that could more likely than not reduce the fair value of the reporting unit below its carrying amount. We assess qualitative factors to determine whether the fair value of the reporting unit to which the goodwill is assigned is less than its carrying amount and recognize an impairment charge for the amount by which the carrying value exceeds the fair value of the reporting unit. Due to the current economic environment, particularly related to COVID-19, the Company performed a triggering event assessment, in which no triggers were identified. Therefore, no interim impairment test of goodwill was performed as of March 31, 2020 and no impairment of goodwill was recorded.


## us-gaap:IntangibleAssetsDisclosureTextBlock

[0001564590-20-023537:notes:104]
10. INTANGIBLE ASSETS

[0001564590-20-023537:notes:105]
Intangible assets as of March 31, 2020 and December 31, 2019 consisted of the following:

[0001564590-20-023537:notes:106]
|  |  | March 31, 2020 |  |  | December 31, 2019 |  |
| (In thousands) |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Net Book Value |  |  | Gross Carrying Amount |  |  | Accumulated Amortization |  |  | Net Book Value |  |
| Customer relationships |  | $ | 20,665 |  |  | $ | (6,099 | ) |  | $ | 14,566 |  |  | $ | 22,356 |  |  | $ | (7,233 | ) |  | $ | 15,123 |  |
| Developed technology |  |  | 8,200 |  |  |  | (1,693 | ) |  |  | 6,507 |  |  |  | 10,170 |  |  |  | (3,379 | ) |  |  | 6,791 |  |
| Licensed technology |  |  | 5,900 |  |  |  | (1,338 | ) |  |  | 4,562 |  |  |  | 5,900 |  |  |  | (1,174 | ) |  |  | 4,726 |  |
| Supplier relationships |  |  | 2,800 |  |  |  | (2,800 | ) |  |  | — |  |  |  | 2,800 |  |  |  | (2,508 | ) |  |  | 292 |  |
| Licensing agreements |  |  | 560 |  |  |  | (97 | ) |  |  | 463 |  |  |  | 560 |  |  |  | (79 | ) |  |  | 481 |  |
| Patents |  |  | 500 |  |  |  | (243 | ) |  |  | 257 |  |  |  | 500 |  |  |  | (226 | ) |  |  | 274 |  |
| Trade names |  |  | 210 |  |  |  | (93 | ) |  |  | 117 |  |  |  | 310 |  |  |  | (176 | ) |  |  | 134 |  |
| Total |  | $ | 38,835 |  |  | $ | (12,363 | ) |  | $ | 26,472 |  |  | $ | 42,596 |  |  | $ | (14,775 | ) |  | $ | 27,821 |  |

[0001564590-20-023537:notes:107]
The Company evaluates the carrying value of intangible assets whenever events or changes in circumstances indicate that the carrying amount of an asset may not be recoverable and the undiscounted cash flows estimated to be generated by the asset are less than the asset’s carrying value. Due to the current economic environment, particularly related to COVID-19, the Company assessed impairment triggers related to intangible assets during the first quarter of 2020. Based on this assessment, no triggers occurred to perform an impairment test, and no impairment losses of intangible assets were recorded.

[0001564590-20-023537:notes:108]
Amortization expense was $1.3 million for the three months ended March 31, 2020 and 2019 and was included in cost of sales, selling, general and administrative expenses and research and development expenses in the Condensed Consolidated Statements of Income (Loss).

[0001564590-20-023537:notes:109]
As of March 31, 2020, estimated future amortization expense of intangible assets was as follows:

[0001564590-20-023537:notes:110]
| (In thousands) |  |  |  |  |
| 2020 |  | $ | 3,111 |  |
| 2021 |  |  | 4,091 |  |
| 2022 |  |  | 3,467 |  |
| 2023 |  |  | 3,316 |  |
| 2024 |  |  | 3,223 |  |
| Thereafter |  |  | 9,264 |  |
| Total |  | $ | 26,472 |  |


## adtn:LeasesDisclosureTextBlock

[0001564590-20-023537:notes:111]
11. LEASES

[0001564590-20-023537:notes:112]
[same as prior period, unchanged from 0001564590-19-040490:notes:131]

[0001564590-20-023537:notes:113]
Operating leases consist of office space, automobiles and various other equipment in the U.S. and in certain international locations in which we do business. Other contracts, such as manufacturing agreements and service agreements, are reviewed to determine if they contain any embedded leases. As of March 31, 2020, the operating leases had remaining lease terms of one month to five years, some of which include options to extend the leases for up to nine years, and some of which include options to terminate the leases within three months. As of March 31, 2020 and December 31, 2019, the Company’s operating lease assets and operating lease liabilities were as follows:

[0001564590-20-023537:notes:114]
| (In thousands) |  | Classification |  | March 31, 2020 |  |  | December 31, 2019 |  |
| Assets |  |  |  |  |  |  |  |  |  |  |
| Operating lease asset |  | Other assets |  | $ | 7,474 |  |  | $ | 8,452 |  |
| Total lease asset |  |  |  | $ | 7,474 |  |  | $ | 8,452 |  |
| Liabilities |  |  |  |  |  |  |  |  |  |  |
| Current operating lease liability |  | Accrued expenses |  | $ | 2,506 |  |  | $ | 2,676 |  |
| Non-current operating lease liability |  | Other non-current liabilities |  |  | 5,012 |  |  |  | 5,818 |  |
| Total lease liability |  |  |  | $ | 7,518 |  |  | $ | 8,494 |  |

[0001564590-20-023537:notes:115]
Lease expense related to short-term leases (initial term of less than 12 months) was $9 thousand and $0.2 million for the three months ended March 31, 2020 and 2019, respectively, and was included in cost of sales, selling, general and administrative expenses and research and development expenses in the Condensed Consolidated Statements of Income (Loss). Lease expense related to variable lease payments that do not depend on an index or rate, such as real estate taxes and insurance reimbursements, was $0.2 million and $0.1 million for the three months ended March 31, 2020 and 2019, respectively.

[0001564590-20-023537:notes:116]
Components of lease expense included in the Condensed Consolidated Statements of Income (Loss) for the three months ended March 31, 2020 and 2019 were as follows:

[0001564590-20-023537:notes:117]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2020 |  |  | 2019 |  |
| Selling, general and administrative expenses |  | $ | 327 |  |  | $ | 349 |  |
| Research and development expenses |  |  | 425 |  |  |  | 454 |  |
| Cost of sales |  |  | 21 |  |  |  | 16 |  |
| Total operating lease expense |  | $ | 773 |  |  | $ | 819 |  |

[0001564590-20-023537:notes:118]
As of March 31, 2020 and December 31, 2019, operating lease liabilities included on the Condensed Consolidated Balance Sheets by future maturity were as follows:

[0001564590-20-023537:notes:119]
| (In thousands) |  | March 31, 2020 |  |  | December 31, 2019 |  |
| 2020 |  | $ | 2,066 |  |  | $ | 2,856 |  |
| 2021 |  |  | 2,326 |  |  |  | 2,412 |  |
| 2022 |  |  | 1,630 |  |  |  | 1,705 |  |
| 2023 |  |  | 1,076 |  |  |  | 1,160 |  |
| 2024 |  |  | 468 |  |  |  | 482 |  |
| Thereafter |  |  | 259 |  |  |  | 264 |  |
| Total lease payments |  |  | 7,825 |  |  |  | 8,879 |  |
| Less: Interest |  |  | (307 | ) |  |  | (385 | ) |
| Present value of lease liabilities |  | $ | 7,518 |  |  | $ | 8,494 |  |

[0001564590-20-023537:notes:120]
Future operating lease payments include $0.6 million related to options to extend lease terms that are reasonably certain of being exercised. There are no legally binding leases that have not yet commenced.

[0001564590-20-023537:notes:121]
An incremental borrowing rate is used based on information available at the commencement date in determining the present value of lease payments. The incremental borrowing rate was determined on a portfolio basis by grouping leases with similar terms as well as grouping leases based on a U.S. dollar or Euro functional currency.  The actual rate is then determined based on a credit spread over LIBOR as well as the Bloomberg Curve Matrix for the U.S. Communications section. The following table provides information about the weighted average lease terms and weighted average discount rates as of March 31, 2020:

[0001564590-20-023537:notes:122]
|  |  | As of March 31, 2020 |  |
| Weighted average remaining lease term (in years) |  |  |  |  |
| Operating leases with USD functional currency |  |  | 2.2 |  |
| Operating leases with Euro functional currency |  |  | 4.2 |  |
| Weighted average discount rate |  |  |  |  |
| Operating leases with USD functional currency |  |  | 3.87 | % |
| Operating leases with Euro functional currency |  |  | 1.83 | % |

[0001564590-20-023537:notes:123]
[same as prior period, unchanged from 0001564590-19-040490:notes:147]

[0001564590-20-023537:notes:124]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2020 |  |  | 2019 |  |
| Cash paid for amounts included in the measurement of operating lease assets / liabilities |  |  |  |  |  |  |  |  |
| Cash used in operating activities related to operating leases |  | $ | 707 |  |  | $ | 811 |  |
| Right-of-use assets obtained in exchange for lease obligations |  | $ | 85 |  |  | $ | 10,387 |  |

[0001564590-20-023537:notes:125]
Net Investment in Sales-Type Leases

[0001564590-20-023537:notes:126]
We are the lessor in sales-type lease arrangements for network equipment, which have initial terms of up to five years, and consisted of the following as of March 31, 2020 and December 31, 2019

[0001564590-20-023537:notes:127]
| (In thousands) |  | March 31, 2020 |  |  | December 31, 2019 |  |
| Current minimum lease payments receivable(1) |  | $ | 1,049 |  |  | $ | 1,201 |  |
| Non-current minimum lease payments receivable(2) |  |  | 715 |  |  |  | 889 |  |
| Total minimum lease payments receivable |  |  | 1,764 |  |  |  | 2,090 |  |
| Less: Current unearned revenue |  |  | 298 |  |  |  | 365 |  |
| Less: Non-current unearned revenue |  |  | 124 |  |  |  | 163 |  |
| Net investment in sales-type leases |  | $ | 1,342 |  |  | $ | 1,562 |  |

[0001564590-20-023537:notes:128]
|  | (2) | Included in other assets on the Condensed Consolidated Balance Sheets. |

[0001564590-20-023537:notes:129]
Components of gross profit related to sales-type leases recognized at the lease commencement date and interest and dividend income included in the Condensed Consolidated Statements of Income (Loss) for the three months ended March 31, 2020 and 2019 were as follows:

[0001564590-20-023537:notes:130]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2020 |  |  | 2019 |  |
| Sales - Network Solutions |  | $ | 38 |  |  | $ | 1,512 |  |
| Less: Cost of sales - Network Solutions |  |  | 16 |  |  |  | 591 |  |
| Gross profit |  | $ | 22 |  |  | $ | 921 |  |
| Interest and dividend income |  | $ | 13 |  |  | $ | 87 |  |


## adtn:IndustrialDevelopmentAuthorityFinancingAndEconomicIncentivesTextBlock

[0001564590-20-023537:notes:131]
12. ALABAMA STATE INDUSTRIAL DEVELOPMENT AUTHORITY FINANCING AND ECONOMIC INCENTIVES

[0001564590-20-023537:notes:132]
In conjunction with the 1995 expansion of our Huntsville, Alabama facility, we were approved for participation in an incentive program offered by the State of Alabama Industrial Development Authority (the “Authority”). Pursuant to the program, in January 1995, the Authority issued $20.0 million of its taxable revenue bonds (the “Taxable Revenue Bonds”) and loaned the proceeds from the sale of the Taxable Revenue Bonds to the Company. Further advances on the Taxable Revenue Bonds were made by the Authority, bringing the total amount to $50.0 million. The Taxable Revenue Bonds’ bore interest, payable monthly with an interest rate of 2% per annum. The Taxable Revenue Bonds’ aggregate principal amount outstanding as of December 31, 2019 of $24.6 million matured on January 1, 2020 and was repaid in full on January 2, 2020, using the funds held in a certificate of deposit by the Company. This certificate of deposit, which totaled $25.6 million, was included in short-term investments on the Condensed Consolidated Balance Sheet as of December 31, 2019.


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001564590-20-023537:notes:133]
[same as prior period, unchanged from 0001564590-19-040490:notes:157]

[0001564590-20-023537:notes:134]
[same as prior period, unchanged from 0001564590-19-040490:notes:158]

[0001564590-20-023537:notes:135]
Since 1997, the Company’s Board of Directors has approved multiple share repurchase programs that have authorized repurchases of its common stock, which are implemented through open market or private purchases from time to time as conditions warrant. During the three months ended March 31, 2020, we did not repurchase shares of our common stock. As of March 31, 2020, we had the authority to purchase an additional 2.5 million shares of our common stock under the current authorization of up to 5.0 million shares.

[0001564590-20-023537:notes:136]
Other Comprehensive Loss

[0001564590-20-023537:notes:137]
The following tables present the changes in accumulated other comprehensive loss, net of tax, by component for the three months ended March 31, 2020 and 2019:

[0001564590-20-023537:notes:138]
|  |  | Three Months Ended March 31, 2020 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | ASU 2018-02 Adoption (1) |  |  | Total |  |
| As of December 31, 2019 |  | $ | (284 | ) |  | $ | (9,226 | ) |  | $ | (7,292 | ) |  | $ | 385 |  |  | $ | (16,417 | ) |
| Other comprehensive loss before reclassifications |  |  | (931 | ) |  |  | — |  |  |  | (1,650 | ) |  |  | — |  |  |  | (2,581 | ) |
| Amounts reclassified from accumulated other comprehensive income (loss) |  |  | 1,048 |  |  |  | 141 |  |  |  | — |  |  |  | — |  |  |  | 1,189 |  |
| Net current period other comprehensive income (loss) |  |  | 117 |  |  |  | 141 |  |  |  | (1,650 | ) |  |  | — |  |  |  | (1,392 | ) |
| As of March 31, 2020 |  | $ | (167 | ) |  | $ | (9,085 | ) |  | $ | (8,942 | ) |  | $ | 385 |  |  | $ | (17,809 | ) |

[0001564590-20-023537:notes:139]
|  |  | Three Months Ended March 31, 2019 |  |
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | ASU 2018-02 Adoption (1) |  |  | Total |  |
| As of December 31, 2018 |  | $ | (563 | ) |  | $ | (8,041 | ) |  | $ | (5,812 | ) |  | $ | — |  |  | $ | (14,416 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | 231 |  |  |  | — |  |  |  | (1,160 | ) |  |  | — |  |  |  | (929 | ) |
| Amounts reclassified from accumulated other comprehensive income (loss) |  |  | (46 | ) |  |  | 121 |  |  |  | — |  |  |  | — |  |  |  | 75 |  |
| Amounts reclassified to retained earnings (1) |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 385 |  |  |  | 385 |  |
| Net current period other comprehensive income (loss) |  |  | 185 |  |  |  | 121 |  |  |  | (1,160 | ) |  |  | 385 |  |  |  | (469 | ) |
| As of March 31, 2019 |  | $ | (378 | ) |  | $ | (7,920 | ) |  | $ | (6,972 | ) |  | $ | 385 |  |  | $ | (14,885 | ) |

[0001564590-20-023537:notes:140]
|  | (1) | With the adoption of ASU 2018-02 on January 1, 2019, stranded tax effects related to the Tax Cuts and Jobs Act of 2017 were reclassified to retained earnings. |

[0001564590-20-023537:notes:141]
The following tables present the details of reclassifications out of accumulated other comprehensive loss for the three months ended March 31, 2020 and 2019:

[0001564590-20-023537:notes:142]
|  |  | Three Months Ended March 31, 2020 |
| (In thousands) |  | Amount Reclassified from Accumulated Other Comprehensive Income (Loss) |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for-sale securities: |  |  |  |  |  |  |
| Net realized losses on sales of securities |  | $ | (1,416 | ) |  | Net investment gain (loss) |
| Defined benefit plan adjustments – actuarial losses |  |  | (204 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | (1,620 | ) |  |  |
| Tax benefit |  |  | 431 |  |  |  |
| Total reclassifications for the period, net of tax |  | $ | (1,189 | ) |  |  |

[0001564590-20-023537:notes:143]
|  | (1) | Included in the computation of net periodic pension cost. See Note 4. |

[0001564590-20-023537:notes:144]
|  |  | Three Months Ended March 31, 2019 |
| (In thousands) |  | Amount Reclassified from Accumulated Other Comprehensive Income (Loss) |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for-sale securities: |  |  |  |  |  |  |
| Net realized gains on sales of securities |  | $ | 62 |  |  | Net investment gain (loss) |
| Defined benefit plan adjustments – actuarial losses |  |  | (175 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | (113 | ) |  |  |
| Tax benefit |  |  | 38 |  |  |  |
| Total reclassifications for the period, net of tax |  | $ | (75 | ) |  |  |

[0001564590-20-023537:notes:145]
The following table presents the tax effects related to the change in each component of other comprehensive loss for the three months ended March 31, 2020 and 2019:

[0001564590-20-023537:notes:146]
|  |  | Three Months Ended |  |  | Three Months Ended |  |
|  |  | March 31, 2020 |  |  | March 31, 2019 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |
| Unrealized gain (loss) on available-for-sale securities |  | $ | (1,258 | ) |  | $ | 327 |  |  | $ | (931 | ) |  | $ | 312 |  |  | $ | (81 | ) |  | $ | 231 |  |
| Reclassification adjustment for amounts related to available-for-sale investments included in net income (loss) |  |  | 1,416 |  |  |  | (368 | ) |  |  | 1,048 |  |  |  | (62 | ) |  |  | 16 |  |  |  | (46 | ) |
| Reclassification adjustment for amounts related to defined benefit plan adjustments included in net income (loss) |  |  | 204 |  |  |  | (63 | ) |  |  | 141 |  |  |  | 175 |  |  |  | (54 | ) |  |  | 121 |  |
| Foreign currency translation adjustment |  |  | (1,650 | ) |  |  | — |  |  |  | (1,650 | ) |  |  | (1,160 | ) |  |  | — |  |  |  | (1,160 | ) |
| Total Other Comprehensive Loss |  | $ | (1,288 | ) |  | $ | (104 | ) |  | $ | (1,392 | ) |  | $ | (735 | ) |  | $ | (119 | ) |  | $ | (854 | ) |


## us-gaap:EarningsPerShareTextBlock

[0001564590-20-023537:notes:147]
[same as prior period, unchanged from 0001564590-19-040490:notes:180]

[0001564590-20-023537:notes:148]
A summary of the calculation of basic and diluted earnings (loss) per share for the three months ended March 31, 2020 and 2019 is as follows:

[0001564590-20-023537:notes:149]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands, except per share amounts) |  | 2020 |  |  | 2019 |  |
| Numerator |  |  |  |  |  |  |  |  |
| Net income (loss) |  | $ | (9,969 | ) |  | $ | 770 |  |
| Denominator |  |  |  |  |  |  |  |  |
| Weighted average number of shares – basic |  |  | 47,957 |  |  |  | 47,782 |  |
| Effect of dilutive securities |  |  |  |  |  |  |  |  |
| PSUs, RSUs and restricted stock |  |  | — |  |  |  | 71 |  |
| Weighted average number of shares – diluted |  |  | 47,957 |  |  |  | 47,853 |  |
| Earnings (loss) per share – basic |  | $ | (0.21 | ) |  | $ | 0.02 |  |
| Earnings (loss) per share – diluted |  | $ | (0.21 | ) |  | $ | 0.02 |  |

[0001564590-20-023537:notes:150]
For the three months ended March 31, 2020, 0.4 million shares of unvested PSUs, RSUs and restricted stock were excluded from the calculation of diluted earnings per share due to their anti-dilutive effect.

[0001564590-20-023537:notes:151]
For the three months ended March 31, 2020 and 2019, 5.9 million and 2.9 million stock options, respectively, were outstanding but were not included in the computation of diluted earnings per share. These stock options were excluded because their exercise prices were greater than the average market price of the common shares during the quarter, therefore making them anti-dilutive under the treasury stock method.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001564590-20-023537:notes:152]
[same as prior period, unchanged from 0001564590-19-040490:notes:185]

[0001564590-20-023537:notes:153]
The chief operating decision maker regularly reviews the Company’s financial performance based on two reportable segments: (1) Network Solutions and (2) Services & Support. Network Solutions includes hardware and software products and next-generation virtualized solutions used in service provider or business networks, as well as prior-generation products. Services & Support includes a portfolio of maintenance, network installation and solution integration services, which include hosted cloud services and subscription services.

[0001564590-20-023537:notes:154]
The performance of our segments is evaluated based on gross profit; therefore, selling, general and administrative expenses, research and development expenses, interest and dividend income, interest expense, net investment gain (loss), other income (expense) and (provision) benefit for income taxes are reported on a company-wide basis only. There is no inter-segment revenue. Asset information by reportable segment is not produced and, therefore, is not reported.

[0001564590-20-023537:notes:155]
The following table presents information about the sales and gross profit of our reportable segments for the three months ended March 31, 2020 and 2019.

[0001564590-20-023537:notes:156]
|  |  | Three Months Ended |  |
|  |  | March 31, 2020 |  |  | March 31, 2019 |  |
| (In thousands) |  | Sales |  |  | Gross Profit |  |  | Sales |  |  | Gross Profit |  |
| Network Solutions |  | $ | 97,372 |  |  | $ | 45,746 |  |  | $ | 125,822 |  |  | $ | 55,088 |  |
| Services & Support |  |  | 17,151 |  |  |  | 5,854 |  |  |  | 17,969 |  |  |  | 5,524 |  |
| Total |  | $ | 114,523 |  |  | $ | 51,600 |  |  | $ | 143,791 |  |  | $ | 60,612 |  |

[0001564590-20-023537:notes:157]
Sales by Geographic Area

[0001564590-20-023537:notes:158]
The following table presents sales information by geographic area for the three months ended March 31, 2020 and 2019:

[0001564590-20-023537:notes:159]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2020 |  |  | 2019 |  |
| United States |  | $ | 78,991 |  |  | $ | 72,528 |  |
| International |  |  | 35,532 |  |  |  | 71,263 |  |
| Total |  | $ | 114,523 |  |  | $ | 143,791 |  |


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001564590-20-023537:notes:160]
[same as prior period, unchanged from 0001564590-19-040490:notes:194]

[0001564590-20-023537:notes:161]
Our products generally include warranties of 90 days to five years for product defects. Warranty returns are accrued at the time revenue is recognized based on an estimate of the cost to repair or replace the defective products. We engage in extensive product quality programs and processes, including actively monitoring and evaluating the quality of our component suppliers. Products continue to become more complex in both size and functionality as many of our product offerings migrate from line card applications to total systems. The increasing complexity of products will cause warranty incidences, when they arise, to be more costly. Estimates regarding future warranty obligations may change due to product failure rates, material usage and other rework costs incurred in correcting a product failure. In addition, from time to time, specific warranty accruals may be recorded if unforeseen problems arise. Should actual experience relative to these factors be worse than estimated, additional warranty expense will be incurred. Alternatively, if actual costs incurred are less than estimated, a portion of the warranty reserves will be reversed in future periods. The liability for warranty obligations totaled $7.6 million and $8.4 million as of March 31, 2020 and December 31, 2019, respectively, and are included in accrued expenses and other liabilities in the accompanying Condensed Consolidated Balance Sheets. During the three months ended March 31, 2020, we had a reversal of prior provisions related to warranty expirations, the impact of which is reflected in the table below.

[0001564590-20-023537:notes:162]
A reconciliation of warranty expense and related write-off activity for the three months ended March 31, 2020 and 2019 is as follows:

[0001564590-20-023537:notes:163]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2020 |  |  | 2019 |  |
| Balance at beginning of period |  | $ | 8,394 |  |  | $ | 8,623 |  |
| Plus: Amounts charged to cost and expenses |  |  | (55 | ) |  |  | 1,131 |  |
| Less: Deductions |  |  | (704 | ) |  |  | (952 | ) |
| Balance at end of period |  | $ | 7,635 |  |  | $ | 8,802 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001564590-20-023537:notes:164]
17. COMMITMENTS AND CONTINGENCIES

[0001564590-20-023537:notes:165]
Securities Class Action Lawsuit

[0001564590-20-023537:notes:166]
On October 17, 2019, a purported stockholder class action lawsuit, captioned Burbridge v. ADTRAN, Inc. et al., Docket No. 19-cv-09619, was filed in the United States District Court for the Southern District of New York against the Company, two of its current executive officers and one of its former executive officers. The complaint alleges violations of federal securities laws and seeks unspecified compensatory damages on behalf of purported purchasers of ADTRAN securities between February 28, 2019 and October 9, 2019. The lawsuit claims that the defendants made materially false and misleading statements regarding, and/or failed to disclose material adverse facts about, the Company’s business, operations and prospects, specifically relating to the Company’s internal control over financial reporting, excess and obsolete inventory reserves, financial results and demand from certain customers. The lawsuit was transferred to the U.S. District Court for the Northern District of Alabama on January 7, 2020, and co-lead plaintiffs have been appointed to represent the putative class. The plaintiffs filed an amended complaint on April 30, 2020. The defendants intend to file a motion to dismiss the amended complaint. We deny the allegations in the complaint, as amended, and intend to vigorously defend against this lawsuit. At this time, we are unable to predict the outcome of or estimate the possible loss or range of loss, if any, associated with this lawsuit.

[0001564590-20-023537:notes:167]
Shareholder Derivative Lawsuit

[0001564590-20-023537:notes:168]
On March 31, 2020, a shareholder derivative suit, captioned Johnson (Derivatively on behalf of ADTRAN) v. T. Stanton, M. Foliano, R. Shannon, and Board of Directors, case no. 5:20-cv-00447, was filed in the U.S. District Court of Northern Alabama against two of the Company’s current executive officers, one of its former executive officers and its Board of Directors. The derivative suit, which is purportedly brought on behalf of ADTRAN, makes similar allegations as the shareholder class action and accuses the directors and officers of breaches of fiduciary duty in connection with those allegations. The Company expects that the derivative lawsuit will be stayed by the Court pending resolution of the class action. The Company and its defendants disagree with the claims made in the complaint, and the defendants intend to vigorously defend against this lawsuit. At this time, we are unable to predict the outcome of or estimate the possible loss or range of loss, if any, associated with this lawsuit.

[0001564590-20-023537:notes:169]
Other Legal Matters

[0001564590-20-023537:notes:170]
In addition to the litigation described above, from time to time we are subject to or otherwise involved in various lawsuits, claims, investigations and legal proceedings that arise out of or are incidental to the conduct of our business (collectively, “Legal Matters”), including those relating to employment matters, patent rights, regulatory compliance matters, stockholder claims, and contractual and other commercial disputes. Such Legal Matters, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Additionally, an unfavorable outcome in any legal matter, including in a patent dispute, could require the Company to pay damages, entitle claimants to other relief, such as royalties, or could prevent the Company from selling some of its products in certain jurisdictions. While the Company cannot predict with certainty the results of the Legal Matters in which it is currently involved, the Company does not expect that the ultimate outcome of such Legal Matters will individually or in the aggregate have a material adverse effect on its business, results of operations, financial condition or cash flows.

[0001564590-20-023537:notes:171]
Performance Bonds

[0001564590-20-023537:notes:172]
Certain contracts, customers and/or jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of March 31, 2020 and December 31, 2019, we had commitments related to these bonds totaling $7.6 million and $9.3 million, respectively, which expire at various dates through August 2024. Although the triggering events vary from contract to contract, in general we would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which we believe is remote.

[0001564590-20-023537:notes:173]
Investment Commitment

[0001564590-20-023537:notes:174]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, of which $7.7 million has been applied as of March 31, 2020


## us-gaap:CreditLossFinancialInstrumentTextBlock

[0001564590-20-023537:notes:175]
18. CURRENT EXPECTED CREDIT LOSSES

[0001564590-20-023537:notes:176]
Under ASC 326 – Financial Instruments – Credit Losses, the Company estimates credit losses for the contractual life of assets that are measured at amortized cost and are within the scope of this guidance, which included its account receivable, net investment in sales-type leases, contract assets under the revenue recognition model and outstanding note receivable. Where appropriate, the Company pooled assets if similar risk characteristics existed. Additionally, the Company analyzed its available-for-sale debt securities to determine if any were impaired and, therefore, a credit loss was needed.

[0001564590-20-023537:notes:177]
Assets Measured at Amortized Cost

[0001564590-20-023537:notes:178]
Accounts Receivable

[0001564590-20-023537:notes:179]
The Company records accounts receivable in the normal course of business as products are shipped or services are performed and invoiced, but payment has not yet been remitted by the customer. As of January 1, 2020 and March 31, 2020, the Company’s outstanding accounts receivable balance was $90.5 million and $86.5 million, respectively. The Company assessed the need for an allowance for credit losses related to its outstanding accounts receivable using the historical loss-rate method as well as assessing asset-specific risks. The Company’s historical losses related to accounts receivable have been immaterial as evidenced by its historical allowance and write-offs due to uncollectability. The assessment of asset-specific risks included the evaluation of relevant available information, from internal and external sources, relating to current conditions that may affect a customer’s ability to pay, such as the customer’s current financial condition, credit rating by geographic location, as provided by a third party and/or by customer, if needed, and overall macro-economic conditions in which the customer operates. The Company pooled assets by geographic location to determine if an allowance should be applied to its accounts receivable balance, assessing the specific country risk rating and overall economics of that particular country. If elevated risk existed, or customer specific risk indicated the accounts receivable balance was at risk, the Company further analyzed the need for an allowance related to specific accounts receivable balances. Additionally, the Company determined that significant changes to customer country risk rating from period-to-period and from the end of the prior year to the end of the current quarter would require further review and analysis by the Company.

[0001564590-20-023537:notes:180]
Accounts receivable balances are considered past due when payment has not been received by the date indicated on the relevant invoice or based on agreed upon terms between the customer and the Company.

[0001564590-20-023537:notes:181]
No allowance for credit loss was recorded on January 1, 2020 (the “implementation date”) or during the three months ended March 31, 2020 related to accounts receivable. The Company’s allowance for credit losses related to accounts receivable was $38 thousand as of March 31, 2020 and December 31, 2019, all of which was expensed prior to January 1, 2020.

[0001564590-20-023537:notes:182]
Contract Assets

[0001564590-20-023537:notes:183]
The Company records contract assets when it has recognized revenue but has not yet billed the customer. As of January 1, 2020 and March 31, 2020, the Company’s outstanding contract asset balance was $2.8 million and $1.4 million, respectively, which is included in other receivables on the Condensed Consolidated Balance Sheets as of March 31, 2020 and December 31, 2019. The Company assessed the need for an allowance for credit losses related to its outstanding contract assets using the historical loss-rate method as well as asset-specific risks. The Company’s historical losses related to contract assets receivable have been immaterial as evidenced by historical write-offs due to uncollectability. Asset-specific risk included the evaluation of relevant available information, from internal and external sources, relating to current conditions that may affect a customer’s ability to pay once invoiced, such as the customer’s financial condition, credit rating by geographic location as provided by a third party and/or by customer, if needed, and overall macro-economic conditions in which the customer operates. The Company pooled assets by geographic location to determine if an allowance should be applied to its contract asset balance, assessing the specific country risk rating and overall economics of that particular country. If elevated risk existed, or customer specific risk indicated the contract balance was at risk, the Company further analyzed the need for an allowance related to specific customer balances. Additionally, the Company determined that significant changes to customer country risk rating from period-to-period and from the end of the prior year to the end of the current quarter would require further review and analysis by the Company.

[0001564590-20-023537:notes:184]
No allowance for credit loss was recorded on the implementation date or during the three months ended March 31, 2020 related to contract assets.

[0001564590-20-023537:notes:185]
The Company is the lessor in sales-type lease arrangements for network equipment. As of January 1, 2020 and March 31, 2020, the Company’s outstanding net investment in sales-type leases was $1.6 million and $1.3 million, respectively, which is included in other receivables and other assets on the Condensed Consolidated Balance Sheets as of March 31, 2020 and December 31, 2019. The Company assessed the need for an allowance for credit losses related to future receivables under its outstanding sales-type leases using the historical loss-rate method as well as asset-specific risks. The Company’s historical losses related to contract assets receivable have been immaterial as evidenced by historical write-offs due to uncollectability. Asset-specific risk included the evaluation of relevant available information, from internal and external sources, relating to current conditions that may affect a customer’s ability to pay once invoiced, such as the customers financial condition, credit rating by geographic location as provided by a third party and/or by customer, if needed, and overall macro-economic conditions in which the customer operates.

[0001564590-20-023537:notes:186]
The following table presents amortized cost basis in sales-type leases based on payment activity:

[0001564590-20-023537:notes:187]
|  |  | Sales-Type Leases Amortized Cost Basis by Origination Year |  |
| (In thousands) |  | 2020 |  |  | 2019 |  |  | 2018 |  |  | 2017 |  |  | 2016 |  |  | Prior |  |  | Total |  |
| Payment performance |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Performing |  | $ | 36 |  |  | $ | 294 |  |  | $ | 582 |  |  | $ | 231 |  |  | $ | 165 |  |  | $ | 34 |  |  | $ | 1,342 |  |
| Non-performing |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 36 |  |  | $ | 294 |  |  | $ | 582 |  |  | $ | 231 |  |  | $ | 165 |  |  | $ | 34 |  |  | $ | 1,342 |  |

[0001564590-20-023537:notes:188]
Sales-type lease receivables are considered past due when payment has not been received based on agreed upon terms between the customer and the Company. No allowance for credit loss was recorded on the implementation date or during the three months ended March 31, 2020 related to sales-type leases.

[0001564590-20-023537:notes:189]
Secured Loan Receivable

[0001564590-20-023537:notes:190]
The Company has a secured loan receivable totaling $0.9 million as of March 31, 2020 and January 1, 2020, which originated in February 2019, and is included in long-term investments on the Condensed Consolidated Balance Sheets as of March 31, 2020 and December 31, 2019. The Company assessed the need for an allowance for credit loss related to its secured loan receivable using the historical loss-rate method as well as asset-specific risks. The Company’s historical losses related to this receivable have been $0. Asset-specific risks included the evaluation of relevant available information, from internal and external sources, relating to current conditions that may affect the customer’s ability to repay the loan upon maturity, such as the customer’s current financial condition, credit rating specific to the customer as determined by a third party and current overall economic conditions, as well as a company valuation prepared by a third party which was based on reasonable and supportable forecasts as provided by management. Accrued interest receivable on the secured loan receivable, which is included in other receivables on the Condensed Consolidated Balance Sheets as of March 31, 2020 and December 31, 2019, totaled $24 thousand and $41 thousand as of January 1, 2020 and March 31, 2020, respectively, and was excluded from the estimate of credit losses for both periods based on the Company’s accounting policy election.

[0001564590-20-023537:notes:191]
No allowance for credit loss was recorded on the implementation date or during the three months ended March 31, 2020 related to the secured loan receivable.

[0001564590-20-023537:notes:192]
Off-Balance Sheet Arrangements

[0001564590-20-023537:notes:193]
The Company did not have any off-balance sheet arrangements as of January 1, 2020 or March 31, 2020.

[0001564590-20-023537:notes:194]
Available-for-Sale Debt Securities

[0001564590-20-023537:notes:195]
As of January 1, 2020 and March 31, 2020, the Company’s available-for-sale debt securities totaled $37.7 million and $37.9 million, respectively. These securities were analyzed at the individual investment level, by CUSIP, to limit credit losses, if applicable, to reflect only the amount by which the fair value of the security was less than its amortized cost. The Company noted that, as of January 1, 2020 and March 31, 2020, there was no intent to sell any of its available-for-sale debt securities before maturity and therefore, the Company assessed the need for an allowance for each of its available-for-sale debt securities in which the fair value was less than its amortized cost as of January 1, 2020 and March 31, 2020. Accrued interest receivable on available-for-sale debt securities, which is included in other receivables on the Condensed Consolidated Balance Sheets as of March 31, 2020 and December 31, 2019, totaled $0.1 million as of January 1, 2020 and March 31, 2020, and was excluded from the estimate of credit losses for both periods based on the Company’s accounting policy election.

[0001564590-20-023537:notes:196]
The following table outlines the available-for-sale debt securities in an unrealized loss position as of January 1, 2020:

[0001564590-20-023537:notes:197]
| (In thousands) |  | Continuous Unrealized Loss Position for Less than 12 Months |  |  | Continuous Unrealized Loss Position for 12 Months or Greater |  |  | Total |  |
|  |  | Fair Value |  |  | Unrealized Losses |  |  | Fair Value |  |  | Unrealized Losses |  |  | Fair Value |  |  | Unrealized Losses |  |
| Corporate bonds |  |  | 203 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 203 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 930 |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 930 |  |  |  | — |  |
| Asset-backed bonds |  |  | 797 |  |  |  | (3 | ) |  |  | — |  |  |  | — |  |  |  | 797 |  |  |  | (3 | ) |
| Mortgage/Agency-backed bonds |  |  | 2,594 |  |  |  | (6 | ) |  |  | 136 |  |  |  | (2 | ) |  |  | 2,730 |  |  |  | (8 | ) |
| U.S. government bonds |  |  | 4,070 |  |  |  | (9 | ) |  |  | — |  |  |  | — |  |  |  | 4,070 |  |  |  | (9 | ) |
| Total |  | $ | 8,594 |  |  | $ | (18 | ) |  | $ | 136 |  |  | $ | (2 | ) |  | $ | 8,730 |  |  | $ | (20 | ) |

[0001564590-20-023537:notes:198]
The Company had 60 positions in available-for-sale debt securities that were in an unrealized loss position as of March 31, 2020, which are presented in the table below:

[0001564590-20-023537:notes:199]
| (In thousands) |  | Continuous Unrealized Loss Position for Less than 12 Months |  |  | Continuous Unrealized Loss Position for 12 Months or Greater |  |  | Total |  |
|  |  | Fair Value |  |  | Unrealized Losses |  |  | Fair Value |  |  | Unrealized Losses |  |  | Fair Value |  |  | Unrealized Losses |  |
| Corporate bonds |  |  | 4,166 |  |  |  | (87 | ) |  |  | — |  |  |  | — |  |  |  | 4,166 |  |  |  | (87 | ) |
| Municipal fixed-rate bonds |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Asset-backed bonds |  |  | 3,901 |  |  |  | (76 | ) |  |  | — |  |  |  | — |  |  |  | 3,901 |  |  |  | (76 | ) |
| Mortgage/Agency-backed bonds |  |  | 1,577 |  |  |  | (62 | ) |  |  | — |  |  |  | — |  |  |  | 1,577 |  |  |  | (62 | ) |
| U.S. government bonds |  |  | 1,242 |  |  |  | (6 | ) |  |  | — |  |  |  | — |  |  |  | 1,242 |  |  |  | (6 | ) |
| Total |  | $ | 10,886 |  |  | $ | (231 | ) |  | $ | — |  |  | $ | — |  |  | $ | 10,886 |  |  | $ | (231 | ) |

[0001564590-20-023537:notes:200]
For those available-for-sale debt securities whose fair value was less than its amortized cost basis, the Company analyzed additional criteria such as adverse conditions specifically related to the security, an industry or geographic area, failure of the issuer of the security to make scheduled interest or principal payments, if applicable, and any changes to the rating of the security by a rating agency to determine if a credit loss existed. The Company used information provided by its investment manager to determine if any scheduled interest or principal payments had not been received and used a third party to determine if any changes to credit ratings had occurred. The Company noted that all principal and interest payments had been received as scheduled and that there had been no changes in credit ratings year-over-year or period-over-period that warranted further review.

[0001564590-20-023537:notes:201]
No allowance for credit loss was recorded on the implementation date or during the three months ended March 31, 2020 related to the Company’s available-for-sale debt securities.


## us-gaap:RestructuringAndRelatedActivitiesDisclosureTextBlock

[0001564590-20-023537:notes:202]
19. RESTRUCTURING

[0001564590-20-023537:notes:203]
During the second half of 2019, the Company implemented a restructuring plan to realign its expense structure with the reduction in revenue experienced in recent years and overall Company objectives. Management assessed the efficiency of operations and, in turn, consolidated locations and personnel, among other things, where possible. As part of this restructuring plan, the Company announced plans to reduce its overall operating expenses, both in the U.S. and internationally.

[0001564590-20-023537:notes:204]
In February 2019, the Company announced the restructuring of certain of our workforce predominantly in Germany, which included the closure of our office location in Munich, Germany accompanied by relocation or severance benefits for the affected employees. Voluntary early retirement was offered to certain other employees, which was announced in March 2019.

[0001564590-20-023537:notes:205]
A reconciliation of the beginning and ending restructuring liability, which is included in accrued wages and benefits in the Consolidated Balance Sheets as of March 31, 2020 and December 31, 2019, is as follows:

[0001564590-20-023537:notes:206]
| (In thousands) |  | March 31, 2020 |  |
| Balance as of December 31, 2019 |  | $ | 1,568 |  |
| Plus: Amounts charged to cost and expense |  |  | 553 |  |
| Less: Amounts paid |  |  | (1,988 | ) |
| Balance as of March 31, 2020 |  | $ | 133 |  |

[0001564590-20-023537:notes:207]
| (In thousands) |  | December 31, 2019 |  |
| Balance as of December 31, 2018 |  | $ | 185 |  |
| Plus: Amounts charged to cost and expense |  |  | 6,014 |  |
| Less: Amounts paid |  |  | (4,631 | ) |
| Balance as of December 31, 2019 |  | $ | 1,568 |  |

[0001564590-20-023537:notes:208]
Restructuring expenses included in the Condensed Consolidated Statements of Income (Loss) were as follows:

[0001564590-20-023537:notes:209]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2020 |  |  | 2019 |  |
| Selling, general and administrative expenses |  | $ | 83 |  |  | $ | 844 |  |
| Research and development expenses |  |  | 436 |  |  |  | 584 |  |
| Cost of sales |  |  | 34 |  |  |  | 635 |  |
| Total restructuring expenses |  | $ | 553 |  |  | $ | 2,063 |  |

[0001564590-20-023537:notes:210]
The following table represents the components of restructuring expense by geographic area:

[0001564590-20-023537:notes:211]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2020 |  |  | 2019 |  |
| Domestic |  | $ | 551 |  |  | $ | 284 |  |
| International |  |  | 2 |  |  |  | 1,779 |  |
| Total restructuring expenses |  | $ | 553 |  |  | $ | 2,063 |  |


## us-gaap:SubsequentEventsTextBlock

[0001564590-20-023537:notes:212]
20. SUBSEQUENT EVENTS

[0001564590-20-023537:notes:213]
On May 6, 2020, we announced that our Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to the Company’s stockholders of record as of the close of business on May 21, 2020. The payment date will be June 4, 2020 in the aggregate amount of approximately $4.3 million.
