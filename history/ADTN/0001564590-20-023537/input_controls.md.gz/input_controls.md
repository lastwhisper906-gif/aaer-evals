# ADTN 10-Q controls and the auditor's report


## item_4_controls

[0001564590-20-023537:item_4_controls:1]
ITEM 4. CONTROLS AND PROCEDURES

[0001564590-20-023537:item_4_controls:2]
Evaluation of Disclosure Controls and Procedures

[0001564590-20-023537:item_4_controls:3]
We maintain disclosure controls and procedures that are designed to provide reasonable assurance that the information required to be disclosed by us in reports that we file or submit under the Securities Exchange Act of 1934, as amended (the “Exchange Act”), is recorded, processed, summarized and reported within the time periods specified in the rules and forms promulgated by the SEC, and that such information is accumulated and communicated to our management, including our Chief Executive Officer and our Chief Financial Officer, as appropriate, to allow timely decisions regarding required disclosure. Because of the inherent limitations to the effectiveness of any system of disclosure controls and procedures, no evaluation of disclosure controls and procedures can provide absolute assurance that all control issues, if any, with a company have been prevented or detected on a timely basis. Even disclosure controls and procedures determined to be effective can only provide reasonable assurance that their objectives are achieved.

[0001564590-20-023537:item_4_controls:4]
As of the end of the period covered by this report, an evaluation was carried out by management, including our Chief Executive Officer and our Chief Financial Officer, of the effectiveness of our disclosure controls and procedures (as defined in Exchange Act Rule 13a-15(e)) pursuant to Rule 13a-15 of the Exchange Act. Based on that evaluation, our Chief Executive Officer and our Chief Financial Officer concluded that our disclosure controls and procedures were not effective as of March 31, 2020 due to the material weakness in our internal control over financial reporting described below.

[0001564590-20-023537:item_4_controls:5]
Material Weakness

[0001564590-20-023537:item_4_controls:6]
A material weakness is a significant deficiency, or combination of significant deficiencies, in internal control over financial reporting, such that there is a reasonable possibility that a material misstatement of the Company’s annual or interim financial statements will not be prevented or detected on a timely basis. In its assessment of the effectiveness of internal control over financial reporting as of March 31, 2020, management determined that there was a deficiency in ADTRAN’s internal control over financial reporting that constituted a material weakness. Specifically, management determined that the Company did not design and maintain effective internal control over the valuation of inventory:

[0001564590-20-023537:item_4_controls:7]
|  | • | Management determined that controls were not effectively designed and maintained over the determination of the estimated reserve for excess and obsolete inventory including the review of significant inputs and assumptions used to determine our excess and obsolete inventory reserve, and to ensure the completeness and accuracy of key reports and related data used in the calculation of this reserve. |

[0001564590-20-023537:item_4_controls:8]
Despite the existence of this material weakness, we believe that the consolidated financial statements included in this report present fairly, in all material respects, our financial position, results of operations and cash flows for the periods presented, in conformity with generally accepted accounting principles in the United States of America. This material weakness did not result in any material misstatements of the Company’s financial statements or disclosures for any period presented in the accompanying consolidated financial statements. While the above material weakness did not result in a material misstatement of the Company’s consolidated financial statements, the material weakness could result in a misstatement of the Company’s interim or annual consolidated financial statements and disclosures that would result in a material misstatement that would not be prevented or detected.

[0001564590-20-023537:item_4_controls:9]
Management’s Remediation Initiatives

[0001564590-20-023537:item_4_controls:10]
The Company has been working to redesign and implement enhanced controls and procedures related to the review of significant inputs and assumptions used to determine our excess and obsolete inventory reserve, and to ensure the completeness and accuracy of key reports and related data used in the calculation of the excess and obsolete inventory reserve. Key reports and calculations have been redesigned and fully integrated into our enterprise resource planning system to ensure completeness and the accuracy of significant inputs. New controls and procedures have also been established by the Company around the consideration of historical usage, known trends, market conditions, and estimated net realizable value of the inventory. The implementation of these measures is ongoing, and, while we believe that they will be effective in remediating the material weakness, management has concluded that, as of March 31, 2020, our controls related to our excess and obsolete inventory reserve were not effectively designed and maintained, and the material weakness related to these controls continued to exist.

[0001564590-20-023537:item_4_controls:11]
Changes in Internal Control over Financial Reporting

[0001564590-20-023537:item_4_controls:12]
Except as noted in the preceding paragraphs, there were no changes in our internal control over financial reporting that occurred during the fiscal quarter ended March 31, 2020 that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting.

[0001564590-20-023537:item_4_controls:13]
41
