# ADTN 8-K — 0001564590-20-022297 filed 2020-05-07

## item codes, every 8-K on or before 2020-05-08

- 2020-05-07 0001564590-20-022297 — 2.02, 9.01
- 2020-02-25 0001564590-20-006448 — 2.02, 9.01
- 2020-02-06 0001564590-20-003580 — 2.02, 9.01
- 2019-10-31 0001564590-19-038936 — 2.02, 9.01
- 2019-10-10 0001564590-19-036732 — 2.02, 9.01
- 2019-09-20 0001564590-19-035144 — 2.02, 9.01
- 2019-08-21 0001564590-19-032757 — 3.01, 9.01
- 2019-07-18 0001564590-19-025186 — 2.02, 9.01
- 2019-05-09 0001564590-19-017956 — 5.07
- 2019-04-18 0001564590-19-011897 — 2.02, 9.01
- 2019-03-07 0001564590-19-006575 — 5.02, 9.01
- 2019-01-24 0001564590-19-001024 — 2.02, 9.01
- 2018-12-06 0001564590-18-030615 — 8.01, 9.01
- 2018-10-17 0001564590-18-024365 — 2.02, 9.01
- 2018-07-18 0001564590-18-016946 — 2.02, 9.01
- 2018-05-10 0001564590-18-012968 — 5.07
- 2018-04-18 0001564590-18-008361 — 2.02, 9.01
- 2018-03-21 0001564590-18-006409 — 8.01, 9.01
- 2018-01-17 0001564590-18-000519 — 2.02, 9.01
- 2017-12-29 0001564590-17-025375 — 2.02, 9.01
- 2017-11-16 0001193125-17-345232 — 5.02
- 2017-10-18 0001564590-17-019582 — 2.02, 9.01
- 2017-07-19 0001564590-17-013609 — 2.02, 9.01
- 2017-05-11 0001564590-17-010459 — 5.02, 9.01
- 2017-05-11 0001564590-17-010452 — 5.07
- 2017-04-19 0001193125-17-127926 — 2.02, 9.01
- 2017-02-07 0001193125-17-032714 — 8.01
- 2017-01-18 0001193125-17-011669 — 2.02, 9.01
- 2016-11-16 0001193125-16-769505 — 5.02, 9.01
- 2016-10-19 0001193125-16-741087 — 2.02, 9.01
- 2016-09-14 0001193125-16-709148 — 8.01, 9.01
- 2016-08-17 0001193125-16-683980 — 5.02, 9.01
- 2016-07-13 0001193125-16-646816 — 2.02, 9.01
- 2016-05-13 0001193125-16-590263 — 5.07
- 2016-04-13 0001193125-16-539019 — 2.02, 9.01
- 2016-04-08 0001193125-16-535035 — 7.01
- 2016-02-11 0001193125-16-459453 — 5.02, 9.01
- 2016-01-20 0001193125-16-432934 — 2.02, 9.01
- 2015-11-16 0001193125-15-378019 — 5.02, 9.01
- 2015-10-14 0001193125-15-343083 — 2.02, 9.01
- 2015-07-16 0001193125-15-254729 — 8.01, 9.01
- 2015-07-15 0001193125-15-253068 — 2.02, 9.01
- 2015-05-15 0001193125-15-189160 — 5.07, 9.01
- 2015-04-22 0001193125-15-140997 — 2.02, 9.01
- 2015-02-23 0001193125-15-056741 — 5.02, 9.01
- 2015-01-21 0001193125-15-015465 — 2.02, 9.01
- 2014-10-15 0001193125-14-372076 — 2.02, 9.01
- 2014-10-03 0001193125-14-363152 — 2.02, 9.01
- 2014-07-16 0001193125-14-269660 — 2.02, 9.01
- 2014-05-20 0001193125-14-205916 — 8.01, 9.01
- 2014-05-20 0001193125-14-205906 — 5.02, 9.01
- 2014-05-15 0001193125-14-201144 — 5.07
- 2014-04-16 0001193125-14-144665 — 2.02, 9.01
- 2014-04-03 0001193125-14-129578 — 2.02, 9.01
- 2014-01-22 0001157523-14-000154 — 2.02, 9.01
- 2013-10-15 0001193125-13-399540 — 5.02
- 2013-10-09 0001157523-13-004657 — 2.02, 9.01
- 2013-07-10 0001157523-13-003290 — 2.02, 9.01
- 2013-05-10 0001193125-13-213728 — 5.07
- 2013-05-03 0001193125-13-198816 — 8.01, 9.01
- 2013-04-10 0001157523-13-001730 — 2.02, 9.01
- 2013-01-16 0001157523-13-000139 — 2.02, 9.01
- 2012-10-10 0001157523-12-005081 — 2.02, 9.01
- 2012-10-03 0001193125-12-413609 — 7.01
- 2012-09-28 0001193125-12-408878 — 2.02, 9.01
- 2012-07-11 0001157523-12-003592 — 2.02, 9.01
- 2012-05-10 0001193125-12-225669 — 5.07
- 2012-05-10 0001193125-12-225639 — 8.01, 9.01
- 2012-04-11 0001157523-12-001772 — 2.02, 9.01
- 2012-03-15 0001193125-12-116494 — 2.02, 9.01
- 2012-01-18 0001157523-12-000174 — 2.02, 9.01
- 2011-12-12 0001193125-11-337271 — 7.01, 9.01
- 2011-10-13 0000950123-11-089785 — 5.03, 9.01
- 2011-10-12 0001157523-11-005682 — 2.02, 9.01
- 2011-07-13 0001157523-11-003986 — 2.02, 9.01
- 2011-05-09 0000950123-11-047191 — 5.02, 5.07, 9.01
- 2011-04-13 0001157523-11-002001 — 2.02, 9.01
- 2011-01-19 0001157523-11-000232 — 2.02, 9.01
- 2010-11-09 0000950123-10-103195 — 5.02, 9.01
- 2010-10-13 0001157523-10-005798 — 2.02, 9.01
- 2010-07-14 0001157523-10-004011 — 2.02, 9.01
- 2010-05-28 0000950123-10-053947 — 5.07
- 2010-04-14 0001157523-10-002022 — 2.02, 9.01
- 2010-01-20 0001157523-10-000200 — 2.02, 9.01
- 2009-10-28 0000950123-09-053984 — 8.01
- 2009-10-14 0001157523-09-006877 — 2.02, 9.01
- 2009-07-15 0001157523-09-004878 — 2.02, 9.01
- 2009-04-15 0001157523-09-002687 — 2.02, 9.01
- 2009-01-21 0001157523-09-000340 — 2.02, 9.01
- 2008-11-12 0001193125-08-233181 — 5.02, 9.01
- 2008-10-14 0001157523-08-007999 — 2.02, 9.01
- 2008-07-15 0001157523-08-005504 — 2.02, 9.01
- 2008-04-15 0001157523-08-002896 — 2.02, 9.01
- 2008-01-22 0001157523-08-000408 — 2.02, 9.01
- 2007-10-16 0001193125-07-219356 — 5.03, 9.01
- 2007-10-16 0001157523-07-009850 — 2.02, 9.01
- 2007-07-17 0001157523-07-006912 — 2.02, 9.01
- 2007-04-17 0001157523-07-003630 — 2.02, 9.01
- 2007-04-03 0001179022-07-000068 — 5.02
- 2007-03-28 0001179022-07-000064 — 5.02
- 2007-02-23 0001193125-07-038337 — 5.02
- 2007-02-23 0001193125-07-038335 — 5.02
- 2007-01-30 0001193125-07-015912 — 5.02, 9.01
- 2007-01-26 0001193125-07-014234 — 5.02
- 2007-01-23 0001157523-07-000494 — 2.02, 9.01 — amendment of 0001157523-07-000481
- 2007-01-23 0001157523-07-000481 — 2.02, 9.01
- 2006-10-17 0001157523-06-009945 — 2.02, 9.01
- 2006-07-18 0001157523-06-006929 — 2.02, 9.01
- 2006-06-08 0001193125-06-126486 — 1.01, 9.01
- 2006-05-10 0001193125-06-107316 — 1.01, 9.01
- 2006-04-18 0001157523-06-003699 — 2.02, 9.01
- 2006-02-03 0001179022-06-000014 — 1.01
- 2006-01-27 0001157523-06-000754 — 5.02, 9.01
- 2006-01-24 0001157523-06-000551 — 2.02, 9.01
- 2005-10-18 0001157523-05-008826 — 2.02, 9.01
- 2005-07-19 0001193125-05-143958 — 1.01, 5.02, 9.01
- 2005-07-19 0001193125-05-143957 — 2.02, 9.01
- 2005-05-20 0001193125-05-112019 — 1.01, 9.01
- 2005-04-19 0001157523-05-003418 — 2.02, 9.01
- 2005-01-25 0001193125-05-010721 — 2.02, 9.01
- 2004-10-12 0001193125-04-169652 — 2.02, 9.01
- 2004-07-13 0001193125-04-116820 — 12, 7
- 2004-04-14 0001193125-04-061547 — 12, 7
- 2004-01-21 0001193125-04-006366 — 12, 7
- 2003-10-14 0001193125-03-061018 — 12, 5, 7
- 2003-07-15 0001193125-03-019292 — 7, 9
- 2003-04-15 0000931763-03-000968 — 7, 9
- 1996-09-12 0000931763-96-000667 — 5, 7

## late-filing notifications on or before 2020-05-08

- 2019-08-12 0001564590-19-031524 — NT 10-Q, for the period ended 2019-06-30

## item 2.02 — earnings release, exhibit 99.1

[0001564590-20-022297:8k_2_02:1]
EX-99.1
2
adtn-ex991_6.htm
EX-99.1

[0001564590-20-022297:8k_2_02:2]
adtn-ex991_6.htm

[0001564590-20-022297:8k_2_02:3]
EXHIBIT 99.1

[0001564590-20-022297:8k_2_02:4]
ADTRAN, Inc. Reports Earnings for the First Quarter of 2020 and Declares Quarterly Cash Dividend

[0001564590-20-022297:8k_2_02:5]
May 6, 2020

[0001564590-20-022297:8k_2_02:6]
HUNTSVILLE, Ala. — (BUSINESS WIRE) — May 6, 2020 -- ADTRAN, Inc. (NASDAQ:ADTN) (“ADTRAN” or the “Company”) today announced financial results for the first quarter of 2020. For the quarter, revenue was $114.5 million compared to $143.8 million for the first quarter of 2019. Earnings for the first quarter of 2020 were a net loss of $10.0 million compared to net income of $0.8 million for the first quarter of 2019. Earnings per share was a loss of $0.21 per share compared to earnings of $0.02 per share, assuming dilution, for the first quarter of 2019. Non-GAAP earnings were a net loss of $2.2 million compared to a non-GAAP net income of $4.9 million for the first quarter of 2019. Non-GAAP earnings per share was a loss of $0.05 per share compared to a non-GAAP earnings of $0.10 per share, assuming dilution, for the first quarter of 2019. Non-GAAP net income (loss) and non-GAAP earnings (loss) per share exclude stock-based compensation expense, acquisition related expenses, amortizations and adjustments, restructuring expenses, amortization of pension actuarial losses, valuation allowance related to our deferred tax assets, asset impairments and deferred compensation related adjustments. The reconciliations between GAAP net income (loss) and earnings (loss) per share to non-GAAP net income (loss) and non-GAAP earnings (loss) per share are set forth in the table provided below.

[0001564590-20-022297:8k_2_02:7]
ADTRAN Chairman and Chief Executive Officer Tom Stanton stated, “While COVID-19 has certainly impacted the way we work and live, it has also underscored the value and integral role the telecommunications industry plays in keeping everyone connected. For ADTRAN, the first quarter came in largely as anticipated. We experienced solid demand, and even in a challenging supply chain environment we had solid growth in our domestic regional and emerging service provider market segments. In addition, several Tier 1 operators have recently selected ADTRAN as their software-defined access platform and solution integration partner for their next generation fiber networks.”

[0001564590-20-022297:8k_2_02:8]
The Company also announced that its Board of Directors declared a cash dividend for the first quarter of 2020. The quarterly cash dividend is $0.09 per common share, to be paid to the Company’s stockholders of record as of the close of business on May 21, 2020. The payment date will be June 4, 2020.

[0001564590-20-022297:8k_2_02:9]
The Company confirmed that it will hold a conference call to discuss its first quarter results on Thursday, May 7, 2020, at 9:30 a.m. Central Time. ADTRAN will webcast this conference call. To listen, visit the Investor Relations site at www.investors.adtran.com approximately ten minutes prior to the start of the call and click on the conference call link provided.

[0001564590-20-022297:8k_2_02:10]
An online replay of the Company’s conference call, as well as the text of the Company's conference call, will be available on the Investor Relations site approximately 24 hours following the call and will remain available for at least 12 months. For more information, visit www.investors.adtran.com or email at investor.relations@adtran.com.

[0001564590-20-022297:8k_2_02:11]
At ADTRAN, we believe amazing things happen when people connect. From the cloud edge to the subscriber edge, we help communications service providers around the world manage and scale services that connect people, places and things to advance human progress. Whether rural or urban, domestic or international, telco or cable, enterprise or residential—ADTRAN solutions optimize existing technology infrastructures and create new, multi-gigabit platforms that leverage cloud economics, data analytics, machine learning and open ecosystems—the future of global networking. Find more at ADTRAN.com, LinkedIn and Twitter.

[0001564590-20-022297:8k_2_02:12]
This press release contains forward-looking statements, generally identified by the use of words such as “believe,” “expect,” “intend,” “estimate,” “anticipate,” “will,” “may,” “could” and similar expressions, which forward-looking statements reflect management’s best judgment based on factors currently known. However, these statements involve risks and uncertainties, including the continued spread and extent of the impact of the COVID-19 global pandemic, including the speed, depth, geographic reach and duration of the spread, which could lead to a decrease in demand for the Company’s products and services, and which has disrupted, and could lead to further disruptions in, the Company’s supply chain, adversely impacting the operations and financial condition of our customers and the Company; actions to be taken by the Company in response to the pandemic; the legal, regulatory and administrative developments that occur at the federal, state and local levels and in foreign jurisdictions in response to the pandemic; potential disruptions, breaches, or other incidents affecting the proper operation, availability, or security of the Company’s or its partners’ information systems; declines in revenues due to declining customer demand and deteriorating macroeconomic conditions; potential increased expenses related to labor or other expenditures; the impact of the COVID-19 pandemic on our liquidity, as well as risks associated with disruptions in the financial markets and the business of financial institutions as a result of the COVID-19 pandemic which could impact us from a financial perspective, and the exacerbation of other risks detailed in our Annual Report on Form 10-K for the year ended December 31, 2019. These risks and uncertainties could cause actual results to differ materially from those in the forward-looking statements included in this press release.

[0001564590-20-022297:8k_2_02:13]
To provide additional transparency, we have disclosed in the table below non-GAAP operating income (loss), which has been reconciled to operating loss, and non-GAAP net income (loss) and non-GAAP earnings (loss) per share - basic and diluted, which have been reconciled to net income (loss) and earnings (loss) per share - basic and diluted, in each case as reported based on Generally Accepted Accounting Principles in the United States (“U.S. GAAP”). These non-GAAP financial measures exclude certain items which management believes are not reflective of the ongoing operating performance of the business. We believe this information is useful in providing period-to-period comparisons of the results of our ongoing operations. Additionally, these measures are used by management in our ongoing planning and annual budgeting processes. The presentation of non-GAAP operating income (loss), non-GAAP net income (loss) and non-GAAP income (loss) per share - basic and diluted, when combined with the U.S. GAAP presentation of operating loss, net income (loss) and net income (loss) per share - basic and diluted, is beneficial to the overall understanding of ongoing operating performance of the Company.

[0001564590-20-022297:8k_2_02:14]
These non-GAAP financial measures are not prepared in accordance with, or an alternative for, U.S. GAAP and therefore should not be considered in isolation or as a substitution for analysis of our results as reported under U.S. GAAP. Additionally, our calculation of non-GAAP operating income (loss), non-GAAP net income (loss) and non-GAAP earnings (loss) per share - basic and diluted may not be comparable to similar measures calculated by other companies.

[0001564590-20-022297:8k_2_02:15]
Condensed Consolidated Balance Sheets

[0001564590-20-022297:8k_2_02:16]
(Unaudited)

[0001564590-20-022297:8k_2_02:17]
(In thousands)

[0001564590-20-022297:8k_2_02:18]
|  | March 31, |  |  | December 31, |  |
|  | 2020 |  |  | 2019 |  |
| Assets |  |  |  |  |  |  |  |
| Cash and cash equivalents | $ | 71,285 |  |  | $ | 73,773 |  |
| Short-term investments |  | 5,984 |  |  |  | 33,243 |  |
| Accounts receivable, net |  | 86,465 |  |  |  | 90,531 |  |
| Other receivables |  | 23,121 |  |  |  | 16,566 |  |
| Inventory, net |  | 99,515 |  |  |  | 98,305 |  |
| Prepaid expenses and other current assets |  | 7,419 |  |  |  | 7,892 |  |
| Total Current Assets |  | 293,789 |  |  |  | 320,310 |  |
| Property, plant and equipment, net |  | 66,500 |  |  |  | 68,086 |  |
| Deferred tax assets, net |  | 7,447 |  |  |  | 7,561 |  |
| Goodwill |  | 6,968 |  |  |  | 6,968 |  |
| Intangibles, net |  | 26,472 |  |  |  | 27,821 |  |
| Other assets |  | 17,958 |  |  |  | 19,883 |  |
| Long-term investments |  | 79,136 |  |  |  | 94,489 |  |
| Total Assets | $ | 498,270 |  |  | $ | 545,118 |  |
| Liabilities and Stockholders' Equity |  |  |  |  |  |  |  |
| Accounts payable | $ | 47,685 |  |  | $ | 44,870 |  |
| Bonds payable |  | — |  |  |  | 24,600 |  |
| Unearned revenue |  | 12,465 |  |  |  | 11,963 |  |
| Accrued expenses and other liabilities |  | 12,748 |  |  |  | 13,876 |  |
| Accrued wages and benefits |  | 13,247 |  |  |  | 13,890 |  |
| Income tax payable, net |  | 3,273 |  |  |  | 3,512 |  |
| Total Current Liabilities |  | 89,418 |  |  |  | 112,711 |  |
| Non-current unearned revenue |  | 4,476 |  |  |  | 6,012 |  |
| Pension liability |  | 15,546 |  |  |  | 15,886 |  |
| Deferred compensation liability |  | 18,321 |  |  |  | 21,698 |  |
| Other non-current liabilities |  | 6,794 |  |  |  | 8,385 |  |
| Total Liabilities |  | 134,555 |  |  |  | 164,692 |  |
| Stockholders' Equity |  | 363,715 |  |  |  | 380,426 |  |
| Total Liabilities and Stockholders' Equity | $ | 498,270 |  |  | $ | 545,118 |  |

[0001564590-20-022297:8k_2_02:19]
Condensed Consolidated Statements of Income (Loss)

[0001564590-20-022297:8k_2_02:20]
(Unaudited)

[0001564590-20-022297:8k_2_02:21]
(In thousands, except per share data)

[0001564590-20-022297:8k_2_02:22]
|  |  | Three Months Ended |  |  |
|  |  | March 31, |  |  |
|  |  | 2020 |  |  | 2019 |  |  |
| Sales |  |  |  |  |  |  |  |  |  |
| Network Solutions |  | $ | 97,372 |  |  | $ | 125,822 |  |  |
| Services & Support |  |  | 17,151 |  |  |  | 17,969 |  |  |
| Total Sales |  |  | 114,523 |  |  |  | 143,791 |  |  |
| Cost of Sales |  |  |  |  |  |  |  |  |  |
| Network Solutions |  |  | 51,626 |  |  |  | 70,734 |  |  |
| Services & Support |  |  | 11,297 |  |  |  | 12,445 |  |  |
| Total Cost of Sales |  |  | 62,923 |  |  |  | 83,179 |  |  |
| Gross Profit |  |  | 51,600 |  |  |  | 60,612 |  |  |
| Selling, general and administrative expenses |  |  | 26,620 |  |  |  | 35,132 |  |  |
| Research and development expenses |  |  | 29,859 |  |  |  | 31,647 |  |  |
| Asset impairments |  |  | 65 |  |  |  | — |  |  |
| Operating Loss |  |  | (4,944 | ) |  |  | (6,167 | ) |  |
| Interest and dividend income |  |  | 356 |  |  |  | 591 |  |  |
| Interest expense |  |  | (1 | ) |  |  | (127 | ) |  |
| Net investment gain (loss) |  |  | (10,877 | ) |  |  | 5,926 |  |  |
| Other income, net |  |  | 1,129 |  |  |  | 855 |  |  |
| Income (Loss) Before Income Taxes |  |  | (14,337 | ) |  |  | 1,078 |  |  |
| Income tax (expense) benefit |  |  | 4,368 |  |  |  | (308 | ) |  |
| Net Income (Loss) |  | $ | (9,969 | ) |  | $ | 770 |  |  |
| Weighted average shares outstanding – basic |  |  | 47,957 |  |  |  | 47,782 |  |  |
| Weighted average shares outstanding – diluted |  |  | 47,957 |  |  |  | 47,853 |  | (1) |
| Earnings (loss) per common share – basic |  | $ | (0.21 | ) |  | $ | 0.02 |  |  |
| Earnings (loss) per common share – diluted |  | $ | (0.21 | ) |  | $ | 0.02 |  | (1) |

[0001564590-20-022297:8k_2_02:23]
(1) Assumes exercise of dilutive stock options calculated under the treasury stock method.

[0001564590-20-022297:8k_2_02:24]
Condensed Consolidated Statements of Cash Flows

[0001564590-20-022297:8k_2_02:25]
(Unaudited)

[0001564590-20-022297:8k_2_02:26]
(In thousands)

[0001564590-20-022297:8k_2_02:27]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
|  |  | 2020 |  |  | 2019 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income (loss) |  | $ | (9,969 | ) |  | $ | 770 |  |
| Adjustments to reconcile net income (loss) to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 4,365 |  |  |  | 4,496 |  |
| Asset impairments |  |  | 65 |  |  |  | — |  |
| Amortization of net premium on available-for-sale investments |  |  | 61 |  |  |  | 6 |  |
| Net (gain) loss on long-term investments |  |  | 10,877 |  |  |  | (5,926 | ) |
| Net (gain) loss on disposal of property, plant and equipment |  |  | 52 |  |  |  | (6 | ) |
| Stock-based compensation expense |  |  | 1,791 |  |  |  | 1,859 |  |
| Deferred income taxes |  |  | (63 | ) |  |  | 235 |  |
| Changes in operating assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  |  | 3,052 |  |  |  | 170 |  |
| Other receivables |  |  | (6,707 | ) |  |  | 2,001 |  |
| Inventory, net |  |  | (1,598 | ) |  |  | 5,974 |  |
| Prepaid expenses and other assets |  |  | 2,206 |  |  |  | 2,809 |  |
| Accounts payable, net |  |  | 2,712 |  |  |  | 166 |  |
| Accrued expenses and other liabilities |  |  | (6,680 | ) |  |  | (2,355 | ) |
| Income taxes payable |  |  | (188 | ) |  |  | (487 | ) |
| Net cash provided by (used in) operating activities |  |  | (24 | ) |  |  | 9,712 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (1,406 | ) |  |  | (1,872 | ) |
| Proceeds from sales and maturities of available-for-sale investments |  |  | 46,440 |  |  |  | 17,039 |  |
| Purchases of available-for-sale investments |  |  | (16,879 | ) |  |  | (15,318 | ) |
| Acquisition of note receivable |  |  | (523 | ) |  |  | — |  |
| Net cash provided by (used in) investing activities |  |  | 27,632 |  |  |  | (151 | ) |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Purchases of treasury stock |  |  | — |  |  |  | (184 | ) |
| Dividend payments |  |  | (4,328 | ) |  |  | (4,301 | ) |
| Repayment of bonds payable |  |  | (24,600 | ) |  |  | — |  |
| Net cash used in financing activities |  |  | (28,928 | ) |  |  | (4,485 | ) |
| Net increase (decrease) in cash and cash equivalents |  |  | (1,320 | ) |  |  | 5,076 |  |
| Effect of exchange rate changes |  |  | (1,168 | ) |  |  | (1,461 | ) |
| Cash and cash equivalents, beginning of period |  |  | 73,773 |  |  |  | 105,504 |  |
| Cash and cash equivalents, end of period |  | $ | 71,285 |  |  | $ | 109,119 |  |
| Supplemental disclosure of non-cash investing activities: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment included in accounts payable |  | $ | 302 |  |  | $ | 273 |  |

[0001564590-20-022297:8k_2_02:28]
Supplemental Information

[0001564590-20-022297:8k_2_02:29]
Reconciliation of Operating Loss to Non-GAAP Operating Income (Loss)

[0001564590-20-022297:8k_2_02:30]
(Unaudited)

[0001564590-20-022297:8k_2_02:31]
|  |  | Three Months ended March 31, |  |  |
|  |  | 2020 |  |  | 2019 |  |  |
| Operating Loss |  | $ | (4,944 | ) |  | $ | (6,167 | ) |  |
| Acquisition related expenses, amortizations and adjustments |  |  | 1,358 |  | (1) |  | 1,497 |  | (6) |
| Stock-based compensation expense |  |  | 1,791 |  | (2) |  | 1,859 |  | (7) |
| Restructuring expenses |  |  | 553 |  | (3) |  | 2,063 |  | (8) |
| Deferred compensation adjustments |  |  | (3,460 | ) | (4) |  | 2,124 |  | (4) |
| Asset impairments |  |  | 65 |  | (5) |  | — |  |  |
| Non-GAAP Operating Income (Loss) |  | $ | (4,637 | ) |  | $ | 1,376 |  |  |

[0001564590-20-022297:8k_2_02:32]
(1) $0.3 million is included in total cost of sales, $0.6 million is included in selling, general and administrative expenses and $0.5 million is included in research and development expenses on the condensed consolidated statements of income (loss).

[0001564590-20-022297:8k_2_02:33]
(2) $0.1 million is included in total cost of sales, $1.1 million is included in selling, general and administrative expenses and $0.6 million is included in research and development expenses on the condensed consolidated statements of income (loss).

[0001564590-20-022297:8k_2_02:34]
(3) $0.1 million is included in selling, general and administrative expenses and $0.5 million is included in research and development expenses on the condensed consolidated statements of income (loss).

[0001564590-20-022297:8k_2_02:35]
(4) Includes a non-cash change in fair value of equity investments held in deferred compensation plans offered to certain employees which is included in selling, general and administrative expenses on the condensed consolidated statements of income (loss).

[0001564590-20-022297:8k_2_02:36]
(5) Includes abandonment of certain information technology projects.

[0001564590-20-022297:8k_2_02:37]
(6) $0.5 million is included in total cost of sales, $0.5 million is included in selling, general and administrative expenses and $0.5 million is included in research and development expenses on the condensed consolidated statements of income (loss).

[0001564590-20-022297:8k_2_02:38]
(7) $0.1 million is included in total cost of sales, $1.1 million is included in selling, general and administrative expenses and $0.7 million is included in research and development expenses on the condensed consolidated statements of income (loss).

[0001564590-20-022297:8k_2_02:39]
(8) $0.6 million is included in total cost of sales, $0.8 million is included in selling, general and administrative expenses and $0.6 million is included in research and development expenses on the condensed consolidated statements of income (loss).

[0001564590-20-022297:8k_2_02:40]
Supplemental Information

[0001564590-20-022297:8k_2_02:41]
Reconciliation of Net Income (Loss) and Earnings (Loss) per Common Share – Basic and Diluted to Non-GAAP

[0001564590-20-022297:8k_2_02:42]
Net Income (Loss) and Non-GAAP Earnings (Loss) per Common Share – Basic and Diluted

[0001564590-20-022297:8k_2_02:43]
(Unaudited)

[0001564590-20-022297:8k_2_02:44]
|  |  | Three Months Ended March 31, |  |
|  |  | 2020 |  |  | 2019 |  |
| Net Income (Loss) |  | $ | (9,969 | ) |  | $ | 770 |  |
| Acquisition related expenses, amortizations and adjustments |  |  | 1,358 |  |  |  | 1,497 |  |
| Stock-based compensation expense |  |  | 1,791 |  |  |  | 1,859 |  |
| Restructuring expenses |  |  | 553 |  |  |  | 2,063 |  |
| Deferred compensation adjustments (1) |  |  | (1,787 | ) |  |  | — |  |
| Asset impairments |  |  | 65 |  |  |  | — |  |
| Pension expense (2) |  |  | 237 |  |  |  | 203 |  |
| Valuation allowance |  |  | 6,090 |  |  |  | — |  |
| Tax effect of adjustments to net income (loss) |  |  | (578 | ) |  |  | (1,524 | ) |
| Non-GAAP Net Income (Loss) |  | $ | (2,240 | ) |  | $ | 4,868 |  |
| Weighted average shares outstanding – basic |  |  | 47,957 |  |  |  | 47,782 |  |
| Weighted average shares outstanding – diluted |  |  | 47,957 |  |  |  | 47,853 |  |
| Earnings (loss) per common share - basic |  | $ | (0.21 | ) |  | $ | 0.02 |  |
| Earnings (loss) per common share - diluted |  | $ | (0.21 | ) |  | $ | 0.02 |  |
| Non-GAAP earnings (loss) per common share - basic |  | $ | (0.05 | ) |  | $ | 0.10 |  |
| Non-GAAP earnings (loss) per common share - diluted |  | $ | (0.05 | ) |  | $ | 0.10 |  |

[0001564590-20-022297:8k_2_02:45]
(1) Includes a non-cash change in fair value of equity investments held in deferred compensation plans offered to certain employees and a net investment gain of $1.5 million related to the out of period remeasurement to historical cost basis of certain long-term investments held in the Company's stock as part of one of these deferred compensation plans.

[0001564590-20-022297:8k_2_02:46]
(2) Includes amortization of actuarial losses related to the Company's pension plan for employees in certain foreign countries.
