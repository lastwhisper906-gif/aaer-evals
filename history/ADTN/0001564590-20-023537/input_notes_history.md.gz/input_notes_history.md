# ADTN note change history — 0001564590-19-040490 → 0001564590-20-023537


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2020-05-08):
[0001564590-20-023537:note_history:1]
On October 17, 2019, a purported stockholder class action lawsuit, captioned Burbridge v. ADTRAN, Inc. et al., Docket No. 19-cv-09619, was filed in the United States District Court for the Southern District of New York against the Company, two of its current executive officers and one of its former executive officers. The complaint alleges violations of federal securities laws and seeks unspecified compensatory damages on behalf of purported purchasers of ADTRAN securities between February 28, 2019 and October 9, 2019. The lawsuit claims that the defendants made materially false and misleading statements regarding, and/or failed to disclose material adverse facts about, the Company’s business, operations and prospects, specifically relating to the Company’s internal control over financial reporting, excess and obsolete inventory reserves, financial results and demand from certain customers. The lawsuit was transferred to the U.S. District Court for the Northern District of Alabama on January 7, 2020, and co-lead plaintiffs have been appointed to represent the putative class. The plaintiffs filed an amended complaint on April 30, 2020. The defendants intend to file a motion to dismiss the amended complaint. We deny the allegations in the complaint, as amended, and intend to vigorously defend against this lawsuit. At this time, we are unable to predict the outcome of or estimate the possible loss or range of loss, if any, associated with this lawsuit.
  (was, 2019-11-05, similarity 0.7801):
[0001564590-19-040490:note_history:1]
On October 17, 2019, a purported stockholder class action lawsuit, captioned Burbridge v. ADTRAN, Inc. et al., Docket No. 19-cv-09619, was filed in the United States District Court for the Southern District of New York against the Company, two of its current executive officers and one of its former executive officers.  The complaint alleges violations of federal securities laws and seeks unspecified compensatory damages on behalf of purported purchasers of ADTRAN securities between February 28, 2019 and October 9, 2019.  The lawsuit claims that the defendants made materially false and misleading statements regarding, and/or failed to disclose material adverse facts about, the Company’s business, operations and prospects, specifically relating to the Company’s internal control over financial reporting, excess and obsolete inventory reserves, financial results and shipments from a Latin American customer.  Investors in ADTRAN securities have until December 16, 2019 to move the court to serve as lead plaintiff in this action.  We disagree with the claims made in the complaint and intend to vigorously defend against this lawsuit.  At this time, we are unable to predict the outcome of or estimate the possible loss or range of loss, if any, associated with this lawsuit.

- added (2020-05-08):
[0001564590-20-023537:note_history:2]
Shareholder Derivative Lawsuit

- added (2020-05-08):
[0001564590-20-023537:note_history:3]
On March 31, 2020, a shareholder derivative suit, captioned Johnson (Derivatively on behalf of ADTRAN) v. T. Stanton, M. Foliano, R. Shannon, and Board of Directors, case no. 5:20-cv-00447, was filed in the U.S. District Court of Northern Alabama against two of the Company’s current executive officers, one of its former executive officers and its Board of Directors. The derivative suit, which is purportedly brought on behalf of ADTRAN, makes similar allegations as the shareholder class action and accuses the directors and officers of breaches of fiduciary duty in connection with those allegations. The Company expects that the derivative lawsuit will be stayed by the Court pending resolution of the class action. The Company and its defendants disagree with the claims made in the complaint, and the defendants intend to vigorously defend against this lawsuit. At this time, we are unable to predict the outcome of or estimate the possible loss or range of loss, if any, associated with this lawsuit.

- changed (2020-05-08):
[0001564590-20-023537:note_history:4]
In addition to the litigation described above, from time to time we are subject to or otherwise involved in various lawsuits, claims, investigations and legal proceedings that arise out of or are incidental to the conduct of our business (collectively, “Legal Matters”), including those relating to employment matters, patent rights, regulatory compliance matters, stockholder claims, and contractual and other commercial disputes. Such Legal Matters, even if not meritorious, could result in the expenditure of significant financial and managerial resources. Additionally, an unfavorable outcome in any legal matter, including in a patent dispute, could require the Company to pay damages, entitle claimants to other relief, such as royalties, or could prevent the Company from selling some of its products in certain jurisdictions. While the Company cannot predict with certainty the results of the Legal Matters in which it is currently involved, the Company does not expect that the ultimate outcome of such Legal Matters will individually or in the aggregate have a material adverse effect on its business, results of operations, financial condition or cash flows.
  (was, 2019-11-05, similarity 0.9991):
[0001564590-19-040490:note_history:4]
In addition to the litigation described above, from time to time we are subject to or otherwise involved in various lawsuits, claims, investigations and legal proceedings that arise out of or are incidental to the conduct of our business (collectively, “Legal Matters”), including those relating to employment matters, patent rights, regulatory compliance matters, stockholder claims, and contractual and other commercial disputes.  Such Legal Matters, even if not meritorious, could result in the expenditure of significant financial and managerial resources.  Additionally, an unfavorable outcome in a legal matter, including in a patent dispute, could require the Company to pay damages, entitle claimants to other relief, such as royalties, or could prevent the Company from selling some of its products in certain jurisdictions.  While the Company cannot predict with certainty the results of the Legal Matters in which it is currently involved, the Company does not expect that the ultimate outcome of such Legal Matters will individually or in the aggregate have a material adverse effect on its business, results of operations, financial condition or cash flows.

- added (2020-05-08):
[0001564590-20-023537:note_history:5]
Performance Bonds

- added (2020-05-08):
[0001564590-20-023537:note_history:6]
Certain contracts, customers and/or jurisdictions in which we do business require us to provide various guarantees of performance such as bid bonds, performance bonds and customs bonds. As of March 31, 2020 and December 31, 2019, we had commitments related to these bonds totaling $7.6 million and $9.3 million, respectively, which expire at various dates through August 2024. Although the triggering events vary from contract to contract, in general we would only be liable for the amount of these guarantees in the event of default under each contract, the probability of which we believe is remote.

- changed (2020-05-08):
[0001564590-20-023537:note_history:7]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, of which $7.7 million has been applied as of March 31, 2020
  (was, 2019-11-05, similarity 0.9653):
[0001564590-19-040490:note_history:7]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, of which $7.7 million has been applied as of September 30, 2019.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2020-05-08):
[0001564590-20-023537:note_history:8]
The accompanying unaudited condensed consolidated financial statements of ADTRAN®, Inc. and its subsidiaries (“ADTRAN”, the “Company”, “we”, “our” or “us”) have been prepared pursuant to the rules and regulations of the Securities and Exchange Commission (the “SEC”) applicable to interim financial information presented in Quarterly Reports on Form 10-Q. Accordingly, certain information and notes required by generally accepted accounting principles in the United States of America (“U.S. GAAP”) for complete financial statements are not included herein. The December 31, 2019 Condensed Consolidated Balance Sheet is derived from audited financial statements but does not include all disclosures required by U.S. GAAP.
  (was, 2019-11-05, similarity 0.9866):
[0001564590-19-040490:note_history:8]
The accompanying unaudited condensed consolidated financial statements of ADTRAN®, Inc. and its subsidiaries (“ADTRAN”, the “Company”, “we”, “our” or “us”) have been prepared pursuant to the rules and regulations of the Securities and Exchange Commission (the “SEC”) applicable to interim financial information presented in Quarterly Reports on Form 10-Q. Accordingly, certain information and notes required by generally accepted accounting principles in the United States of America (“GAAP”) for complete financial statements are not included herein. The December 31, 2018 Condensed Consolidated Balance Sheet is derived from audited financial statements, but does not include all disclosures required by GAAP.

- changed (2020-05-08):
[0001564590-20-023537:note_history:9]
In the opinion of management, all adjustments necessary to fairly state these interim statements have been recorded and are of a normal and recurring nature. The results of operations for an interim period are not necessarily indicative of the results for the full year. The interim financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in ADTRAN’s Annual Report on Form 10-K for the year ended December 31, 2019, filed with the SEC on February 25, 2020.
  (was, 2019-11-05, similarity 0.9549):
[0001564590-19-040490:note_history:9]
In the opinion of management, all adjustments necessary to fairly state these interim statements have been recorded and are of a normal and recurring nature. The results of operations for an interim period are not necessarily indicative of the results for the full year. The interim financial statements should be read in conjunction with the consolidated financial statements and notes thereto included in ADTRAN’s Annual Report on Form 10-K for the year ended December 31, 2018, filed with the SEC on February 28, 2019 (as amended on September 20, 2019, the “2018 Form 10-K”).

- added (2020-05-08):
[0001564590-20-023537:note_history:10]
The preparation of financial statements in conformity with U.S. GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenue and expense during the reporting period. The more significant estimates include excess and obsolete inventory reserves, warranty reserves, customer rebates, determination and accrual of deferred revenue components of element sales agreements, estimated costs to complete obligations associated with deferred and accrued revenues and network installations, estimated income tax provision and income tax contingencies, fair value of stock-based compensation, assessment of goodwill and other intangibles for impairment, estimated lives of intangible assets, estimated pension liability and fair value of investments. Actual amounts could differ significantly from these estimates.

- added (2020-05-08):
[0001564590-20-023537:note_history:11]
We assessed certain accounting matters that generally require consideration of forecasted financial information in context with the information reasonably available to us and the unknown future impacts of the novel coronavirus (“COVID-19”) as of March 31, 2020 and through the date of this report. The accounting matters assessed included, but were not limited to, the allowance for doubtful accounts, stock-based compensation, carrying value of goodwill, intangibles and other long-lived assets, financial assets, valuation allowances for tax assets and revenue recognition. While there was not a material impact to our consolidated financial statements as of and for the quarter ended March 31, 2020 resulting from these assessments, future assessments of our current expectations at that time of the magnitude and duration of the COVID-19 pandemic, as well as other factors, could result in material impacts to our consolidated financial statements in future reporting periods.

- added (2020-05-08):
[0001564590-20-023537:note_history:12]
During the three months ended June 30, 2019, it was determined that a $1.0 million cash inflow related to an insurance recovery was incorrectly classified as a cash flow from operations instead of a cash flow from investing activities within the unaudited Condensed Consolidated Statement of Cash Flows for the three months ended March 31, 2019. The Company corrected this misstatement in the unaudited Condensed Consolidated Statement of Cash Flows as an out of period adjustment as of and for the six months ended June 30, 2019 to correctly reflect the $1.0 million insurance recovery as a cash inflow from investing activities. Management had previously determined that this misstatement was not material to any of its previously issued financial statements on either a quantitative or qualitative basis.

- added (2020-05-08):
[0001564590-20-023537:note_history:13]
During the three months ended March 31, 2020, it was determined that certain investments held in the Company’s stock for a deferred compensation plan accounted for as a Rabbi trust were incorrectly classified as Long-term investments with the fair value of such investments incorrectly marked to market at each period end rather than classified as Treasury stock held at historical cost. This plan has been in existence since 2011. The Company corrected this misstatement as an out of period adjustment in the three months ended March 31, 2020 by remeasuring the investment assets to their historical cost basis through the recording of a Net investment gain of $1.5 million in the unaudited Condensed Consolidated Statement of Income (Loss) and then correcting the classification by decreasing the Long-term investment balance at its remeasured cost basis of $2.8 million to Treasury stock in the unaudited Condensed Consolidated Balance Sheet as of March 31, 2020. Management has determined that this misstatement was not material to any of its previously issued financial statements and that correction of the misstatement is also not expected to be material to the 2020 annual financial results on either a quantitative or qualitative basis.

- changed (2020-05-08):
[0001564590-20-023537:note_history:14]
In June 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. ASU 2016-13 requires the measurement and recognition of expected credit losses for financial instruments held at amortized cost. In November 2018, the FASB issued ASU 2018-19, Codification Improvements to Topic 326 Financial Instruments – Credit Losses, that clarifies receivables arising from operating leases are not within the scope of the credit losses standard, but rather should be accounted for in accordance with the standard for leases. In April 2019, the FASB issued ASU 2019-04, Codification Improvements to Topic 326, Financial Instruments–Credit Losses, Topic 815, Derivatives and Hedging, and Topic 825, Financial Instruments, which clarifies the accounting for transfers between classifications of debt securities and clarifies that entities should include expected recoveries on financial assets in the calculation of the current expected credit loss allowance. In addition, renewal options that are not unconditionally cancelable should be considered in the determination of expected credit losses. In May 2019, the FASB issued ASU 2019-05, Financial Instruments – Credit Losses (Topic 326): Targeted Transition Relief, which amends ASU 2016-13 to allow companies, upon adoption, to elect the fair value option on financial instruments that were previously recorded at amortized cost if they meet certain criteria. In November 2019, the FASB issued ASU 2019-11, Codification improvements to Topic 326, Financial Instruments – Credit Losses, which makes various narrow-scope amendments to the new credit losses standard, such as providing disclosure relief for accrued interest receivables. All of these ASUs were codified as part of ASC Topic 326 and were effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. The Company adopted this standard on January 1, 2020, using a modified-retrospective approach and, therefore, elected to carry forward legacy disclosures for comparative periods and did not adjust the comparative period financial information. Additionally, the Company made an accounting policy election, at the class of financing receivable, not to measure the allowance for credit losses for accrued interest receivables, as the Company writes off the uncollectable accrued interest receivable by reversing any previously recorded interest income in a timely manner (as soon as these amounts are determined to be uncollectable). The adoption of this standard did not have a material effect on our consolidated financial statements. See Note 18 for additional information.
  (was, 2019-11-05, similarity 0.6695):
[0001564590-19-040490:note_history:14]
In June 2016, the Financial Accounting Standards Board (“FASB”) issued Accounting Standards Update (“ASU”) 2016-13, Financial Instruments – Credit Losses (Topic 326): Measurement of Credit Losses on Financial Instruments. ASU 2016-13 requires the measurement and recognition of expected credit losses for financial instruments held at amortized cost. In November 2018, the FASB issued ASU 2018-19, Codification Improvements to Topic 326 Financial Instruments – Credit Losses, that clarifies receivables arising from operating leases are not within the scope of the credit losses standard, but rather should be accounted for in accordance with the leases standard. In April 2019, the FASB issued ASU 2019-04, Codification Improvements to Topic 326, Financial Instruments–Credit Losses, Topic 815, Derivatives and Hedging, and Topic 825, Financial Instruments, which clarifies the accounting for transfers between classifications of debt securities and clarifies that entities should include expected recoveries on financial assets in the calculation of the current expected credit loss allowance. In addition, renewal options that are not unconditionally cancelable should be considered in the determination of expected credit losses. In May 2019, the FASB issued ASU 2019-05, Financial Instruments – Credit Losses (Topic 326): Targeted Transition Relief, which amends ASU 2016-13 to allow companies, upon adoption, to elect the fair value option on financial instruments that were previously recorded at amortized cost if they meet certain criteria. All of these ASUs are effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019, with early adoption permitted. We are currently evaluating the effect these ASUs will have on our consolidated financial statements.

- changed (2020-05-08):
[0001564590-20-023537:note_history:15]
In January 2017, the FASB issued ASU 2017-04, Intangibles – Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment. ASU 2017-04 simplifies the measurement of goodwill by eliminating step 2 of the goodwill impairment test. Under ASU 2017-04, entities are required to compare the fair value of a reporting unit to its carrying amount and recognize an impairment charge for the amount by which the carrying amount exceeds the reporting unit’s fair value. ASU 2017-04 was effective for annual or interim impairment tests performed in fiscal years beginning after December 15, 2019. The Company adopted ASU 2017-04 on January 1, 2020, and the amendments were applied prospectively. The adoption of this standard did not have a material effect on our consolidated financial statements.
  (was, 2019-11-05, similarity 0.7023):
[0001564590-19-040490:note_history:15]
In January 2017, the FASB issued ASU 2017-04, Intangibles – Goodwill and Other (Topic 350): Simplifying the Test for Goodwill Impairment. ASU 2017-04 simplifies the measurement of goodwill by eliminating step 2 of the goodwill impairment test. Under ASU 2017-04, entities will be required to compare the fair value of a reporting unit to its carrying amount and recognize an impairment charge for the amount by which the carrying amount exceeds the reporting unit’s fair value. ASU 2017-04 is effective for annual or interim impairment tests performed in fiscal years beginning after December 15, 2019, with early adoption permitted for annual or interim impairment tests performed on testing dates after January 1, 2017. The amendments should be applied prospectively. We are currently evaluating whether to early adopt ASU 2017-04, but do not expect it will have a material effect on our consolidated financial statements.

- changed (2020-05-08):
[0001564590-20-023537:note_history:16]
In August 2018, the FASB issued ASU 2018-13, Fair Value Measurement (Topic 820): Disclosure Framework – Changes to the Disclosure Requirements for Fair Value Measurement, which changes the fair value measurement disclosure requirements of ASC 820, Fair Value Measurement. The amendments in this ASU are the result of a broader disclosure project, Concepts Statement No. 8 — Conceptual Framework for Financial Reporting — Chapter 8 — Notes to Financial Statements, which the FASB finalized on August 28, 2018. The FASB used the guidance in the Concepts Statement to improve the effectiveness of ASC 820’s disclosure requirements. ASU 2018-13 provides users of financial statements with information about assets and liabilities measured at fair value in the statement of financial position or disclosed in the notes to the financial statements. More specifically, ASU 2018-13 requires disclosures about the valuation techniques and inputs that are used to arrive at measures of fair value, including judgments and assumptions that are made in determining fair value. In addition, ASU 2018-13 requires disclosures regarding the uncertainty in the fair value measurements as of the reporting date and how changes in fair value measurements affect performance and cash flows. The Company adopted ASU 2018-13 on January 1, 2020, and the adoption of this standard did not have a material effect on our consolidated financial statements.
  (was, 2019-11-05, similarity 0.8671):
[0001564590-19-040490:note_history:16]
In August 2018, the FASB issued ASU 2018-13, Fair Value Measurement (Topic 820): Disclosure Framework-Changes to the Disclosure Requirements for Fair Value Measurement, which changes the fair value measurement disclosure requirements of ASC 820, Fair Value Measurement. The amendments in this ASU are the result of a broader disclosure project, Concepts Statement No. 8 — Conceptual Framework for Financial Reporting — Chapter 8 — Notes to Financial Statements, which the FASB finalized on August 28, 2018. The FASB used the guidance in the Concepts Statement to improve the effectiveness of ASC 820’s disclosure requirements. ASU 2018-13 provides users of financial statements with information about assets and liabilities measured at fair value in the statement of financial position or disclosed in the notes to the financial statements. More specifically, ASU 2018-13 requires disclosures about the valuation techniques and inputs that are used to arrive at measures of fair value, including judgments and assumptions that are made in determining fair value. In addition, ASU 2018-13 requires disclosures regarding the uncertainty in the fair value measurements as of the reporting date and how changes in fair value measurements affect performance and cash flows. ASU 2018-13 is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019. We are currently evaluating the effect of ASU 2018-13, but do not expect it will have a material effect on our financial statement disclosures.

- added (2020-05-08):
[0001564590-20-023537:note_history:17]
In August 2018, the FASB issued ASU 2018-15, Intangibles-Goodwill and Other-Internal – Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract.  ASU 2018-15 clarifies certain aspects of ASU 2015-05, Customer’s Accounting for Fees Paid in a Cloud Computing Arrangement. Specifically, ASU 2018-15 aligns the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementations costs incurred to develop or obtain internal use software. The Company adopted ASU 2018-15 on January 1, 2020, retrospectively. The adoption of this standard resulted in a reclassification of $5.6 million from property, plant and equipment to other assets for certain previously capitalized costs related to information technology implementation projects that had not yet been placed in service on the consolidated balance sheet as of March 31, 2020 and December 31, 2019. There was minimal impact to previously reported net cash provided by (used in) operations on the statement of cash flows and no impact to the statements of income (loss) as no portion of the capitalized asset was depreciated in prior periods.

- added (2020-05-08):
[0001564590-20-023537:note_history:18]
The following table illustrates the impact of adoption of ASU 2018-15 on the Condensed Consolidated Balance Sheet as of December 31, 2019:

- added (2020-05-08):
[0001564590-20-023537:note_history:19]
|  |  | As of December 31, 2019 |  |
| (In thousands) |  | Pre-Adoption |  |  | Effect of Adoption |  |  | As Presented Now |  |
| Condensed Consolidated Balance Sheet |  |  |  |  |  |  |  |  |  |  |  |  |
| Property, plant and equipment, net |  | $ | 73,708 |  |  | $ | (5,622 | ) |  | $ | 68,086 |  |
| Other assets |  | $ | 14,261 |  |  | $ | 5,622 |  |  | $ | 19,883 |  |

- added (2020-05-08):
[0001564590-20-023537:note_history:20]
The following table illustrates the impact of adoption of ASU 2018-15 on the Condensed Consolidated Statement of Income and Condensed Consolidated Statement of Cash Flows for the three months ended March 31, 2019:

- added (2020-05-08):
[0001564590-20-023537:note_history:21]
|  |  | Three Months Ended March 31, 2019 |  |
| (In thousands) |  | Pre-Adoption |  |  | Effect of Adoption |  |  | As Presented Now |  |
| Condensed Consolidated Statement of Income |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 770 |  |  | $ | — |  |  | $ | 770 |  |
| Condensed Consolidated Statement of Cash Flows |  |  |  |  |  |  |  |  |  |  |  |  |
| Net cash provided by operating activities |  | $ | 9,712 |  |  | $ | — |  |  | $ | 9,712 |  |

- changed (2020-05-08):
[0001564590-20-023537:note_history:22]
In August 2018, the FASB issued ASU 2018-14, Compensation – Retirement Benefits – Defined Benefit Plans – General (Subtopic 715-20): Disclosure Framework-Changes to the Disclosure Requirements for Defined Benefit Plans, which makes changes to and clarifies the disclosure requirements related to defined benefit pension and other postretirement plans. ASU 2018-14 requires additional disclosures related to the reasons for significant gains and losses affecting the benefit obligation and an explanation of any other significant changes in the benefit obligation or plan assets that are not otherwise apparent in other disclosures required by ASC 715. ASU 2018-14 also clarifies the guidance in ASC 715 to require disclosure of the projected benefit obligation (“PBO”) and fair value of plan assets for pension plans with PBOs in excess of plan assets and the accumulated benefit obligation (“ABO”) and fair value of plan assets for pension plans with ABOs in excess of plan assets. ASU 2018-14 is effective for public business entities for fiscal years ending after December 15, 2020. The Company is currently evaluating the impact this guidance will have on its related disclosures.
  (was, 2019-11-05, similarity 0.8885):
[0001564590-19-040490:note_history:22]
In August 2018, the FASB issued ASU 2018-14, Compensation-Retirement Benefits-Defined Benefit Plans-General (Subtopic 715-20): Disclosure Framework-Changes to the Disclosure Requirements for Defined Benefit Plans, which makes changes to and clarifies the disclosure requirements related to defined benefit pension and other postretirement plans. ASU 2018-14 requires additional disclosures related to the reasons for significant gains and losses affecting the benefit obligation and an explanation of any other significant changes in the benefit obligation or plan assets that are not otherwise apparent in other disclosures required by ASC 715. ASU 2018-14 also clarifies the guidance in ASC 715 to require disclosure of the projected benefit obligation (“PBO”) and fair value of plan assets for pension plans with PBOs in excess of plan assets and the accumulated benefit obligation (“ABO”) and fair value of plan assets for pension plans with ABOs in excess of plan assets. ASU 2018-14 is effective for public business entities for fiscal years ending after December 15, 2020. We are currently evaluating the effect of ASU 2018-14, but do not expect it will have a material effect on our financial statement disclosures.

- added (2020-05-08):
[0001564590-20-023537:note_history:23]
In December 2019, the FASB issued ASU 2019-12, Income Taxes (Topic 740): Simplifying the Accounting for Income Taxes, which simplifies the accounting for income taxes by removing various exceptions, such as the exception to the incremental approach for intra-period tax allocation when there is a loss from continuing operations and income or a gain from other items. The amendments in this update also simplify the accounting for income taxes related to income-based franchise taxes and require that an entity reflect enacted tax laws or rates in the annual effective tax rate computation in the interim period that includes the enactment date. ASU 2019-12 is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2020, with early adoption permitted. The Company is currently evaluating the impact of this new standard on its consolidated financial statements.

- removed (2020-05-08):
[0001564590-19-040490:note_history:24]
The preparation of financial statements in conformity with GAAP requires management to make estimates and assumptions that affect the reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenue and expense during the reporting period. Our more significant estimates include the excess and obsolete inventory reserves, warranty reserves, customer rebates, determination of the deferred and accrued revenue components of multiple performance obligations sales agreements, estimated costs to complete obligations associated with deferred and accrued revenue, estimated income tax provision and income tax contingencies, the fair value of stock-based compensation, impairment of goodwill, valuation and estimated lives of intangible assets, estimated pension liability, fair value of investments and the evaluation of other-than-temporary declines in the value of investments. Actual amounts could differ significantly from these estimates.

- removed (2020-05-08):
[0001564590-19-040490:note_history:25]
During the three months ended June 30, 2019, the Company revised the methodology used in estimating its excess and obsolete inventory reserves. Under the revised methodology, we establish reserves for estimated excess and obsolete inventory equal to the difference between the cost of the inventory and the estimated net realizable value of the inventory based on historical usage, known trends, inventory age, and market conditions. When we dispose of excess and obsolete inventories, the related disposals are charged against the inventory reserves. See Note 8 for additional information.

- removed (2020-05-08):
[0001564590-19-040490:note_history:26]
During the three months ended June 30, 2019, the Company determined that there was an immaterial misstatement of its excess and obsolete inventory reserves in its previously issued annual and interim financial statements. The Company corrected this misstatement by recognizing a $0.8 million out-of-period adjustment during the three months ended June 30, 2019, which increased its excess and obsolete inventory reserves and cost of goods sold for the period. For the six months ended June 30, 2019, the out-of-period adjustment was a cumulative $0.2 million reduction in the Company’s excess and obsolete inventory reserves and cost of goods sold. In addition, the Company determined that a $1.0 million cash inflow related to an insurance recovery was incorrectly classified as a cash flow from operations instead of a cash flow from investing activities within the unaudited Condensed Consolidated Statement of Cash Flows for the three months ended March 31, 2019. The Company has corrected this misstatement in the Unaudited Condensed Consolidated Statement of Cash Flows for the nine months ended September 30, 2019 to correctly reflect the $1.0 million insurance recovery as a cash inflow from investing activities. Management has determined that these misstatements were not material to any of its previously issued financial statements and that correction of the misstatements is also not material to the current or estimated annual 2019 financial results on either a quantitative and qualitative basis.

- removed (2020-05-08):
[0001564590-19-040490:note_history:27]
In August 2018, the FASB issued ASU 2018-15, Intangibles-Goodwill and Other-Internal-Use Software (Subtopic 350-40): Customer’s Accounting for Implementation Costs Incurred in a Cloud Computing Arrangement That Is a Service Contract.  ASU 2018-15 clarifies certain aspects of ASU 2015-05, Customer’s Accounting for Fees Paid in a Cloud Computing Arrangement. Specifically, ASU 2018-15 aligns the requirements for capitalizing implementation costs incurred in a hosting arrangement that is a service contract with the requirements for capitalizing implementations costs incurred to develop or obtain internal use software. ASU 2018-15 is effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2019, with early adoption permitted. We are currently evaluating the effect of ASU 2018-15, but do not expect it will have a material effect on our consolidated financial statements.

- removed (2020-05-08):
[0001564590-19-040490:note_history:28]
In February 2016, the FASB issued ASU 2016-02, Leases (Topic 842), which requires an entity to recognize right-of-use assets and lease liabilities on the balance sheet and to disclose key information about the entity’s leasing arrangements. In July 2018, the FASB issued ASU 2018-10, Codification Improvements to Topic 842, Leases, which clarified certain aspects of ASU 2016-02, as well as ASU 2018-11, Leases (Topic 842), Targeted Improvements, which provided for an optional transition method allowing for the application of the legacy lease guidance, Leases (Topic 840), including its disclosure requirements, for the comparative periods presented in the year of adoption, with the cumulative effect of initially applying the new lease standard recognized as an adjustment to retained earnings as of the date of adoption. In March 2019, the FASB issued ASU 2019-01, Leases (Topic 842) Codification Improvements, which removed the requirement for an entity to disclose in the interim periods after adoption, the effect of the change on income from continuing operations, net income, any other affected financial statement line item, and any affected per share amount. For lessors, the new leasing standard requires leases to be classified as sales-type, direct financing or operating leases. These criteria focus on the transfer of control of the underlying lease asset. This standard and related updates were effective for fiscal years beginning after December 15, 2018, and interim periods within those fiscal years.

- removed (2020-05-08):
[0001564590-19-040490:note_history:29]
The Company adopted the new standard on January 1, 2019, the effective date of our initial application, using the optional transition method. At that time, the Company elected to carry forward the legacy ASC 840 disclosures for comparative periods and, therefore, did not adjust the comparative period financial information prior to January 1, 2019. In addition, the Company elected the package of practical expedients which allows for companies to not reassess whether any expired or existing contracts are or contain leases, not reassess historical lease classifications for expired or existing contracts and not reassess initial direct costs for existing leases. Additionally, the Company elected the practical expedients which allow the use of hindsight when determining the lease term, the short-term lease recognition exemption and the option to not separate lease and non-lease components. The adoption of this standard resulted in the recognition of a right-of-use asset and corresponding right-of-use liability on our Condensed Consolidated Balance Sheet of $10.3 million as of January 1, 2019, primarily related to our operating leases for office space, automobiles and other equipment.

- removed (2020-05-08):
[0001564590-19-040490:note_history:30]
As a lessee, the adoption of this standard did not have a material impact on our Condensed Consolidated Statement of Income or Statement of Cash Flows. See Note 12 for additional information.

- removed (2020-05-08):
[0001564590-19-040490:note_history:31]
As a lessor, the adoption of this standard did not have a material impact on the Company’s Condensed Consolidated Balance Sheet, Condensed Consolidated Statement of Income or Condensed Consolidated Statement of Cash Flows. Prior to and after adoption, all of our leases in which we are the lessor were classified as sales-type leases.

- removed (2020-05-08):
[0001564590-19-040490:note_history:32]
In March 2017, the FASB issued ASU 2017-08, Receivables – Nonrefundable Fees and Other Costs (Subtopic 310-20): Premium Amortization on Purchased Callable Debt Securities, which shortened the amortization period for the premium on certain purchased callable debt securities to the earliest call date. ASU 2017-08 was effective for fiscal years and interim periods within those fiscal years, beginning after December 15, 2018. The amendments were required to be applied through a modified-retrospective transition approach that required a cumulative-effect adjustment directly to retained earnings as of the beginning of the period of adoption. The Company adopted ASU 2017-08 on January 1, 2019, and the adoption of this standard did not have a material effect on our consolidated financial statements.

- removed (2020-05-08):
[0001564590-19-040490:note_history:33]
In August 2017, the FASB issued ASU 2017-12, Derivatives and Hedging (Topic 815): Targeted Improvements to Accounting for Hedging Activities. ASU 2017-12 expanded and refined hedge accounting for both financial and non-financial risk components, aligned the recognition and presentation of the effects of hedging instruments and hedge items in the financial statements, and included certain targeted improvements to ease the application of current guidance related to the assessment of hedge effectiveness.  In October 2018, the FASB issued ASU 2018-16, Derivatives and Hedging (Topic 815): Inclusion of the Secured Overnight Financing Rate (“SOFR”) Overnight Index Swap (“OIS”) Rate as a Benchmark Interest Rate for Hedge Accounting, which permits the OIS rate based on SOFR as a U.S. benchmark interest rate. Both ASU 2017-12 and ASU 2018-16 were effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2018. The Company adopted ASU 2017-12 on January 1, 2019, and the adoption of this standard did not have a material effect on our consolidated financial statements as we did not have any hedging instruments as of the date of adoption.

- removed (2020-05-08):
[0001564590-19-040490:note_history:34]
In February 2018, the FASB issued ASU 2018-02, Income Statement – Reporting Comprehensive Income (Topic 220): Reclassification of Certain Tax Effects from Accumulated Comprehensive Income. ASU 2018-02 allowed for an optional reclassification from accumulated other comprehensive income to retained earnings for stranded tax effects resulting from the Tax Cuts and Jobs Act of 2017. ASU 2018-02 was effective for fiscal years, and interim periods within those fiscal years, beginning after December 15, 2018. The Company adopted ASU 2018-02 on January 1, 2019, and upon adoption reclassified $0.4 million of stranded tax effects created by rate changes related to the Tax Cuts and Jobs Act of 2017 to retained earnings. See Note 13 for additional information.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2020-05-08):
[0001564590-20-023537:note_history:35]
As of March 31, 2020, the following debt securities and other investments were included on the Condensed Consolidated Balance Sheet and recorded at fair value:
  (was, 2019-11-05, similarity 0.664):
[0001564590-19-040490:note_history:35]
At December 31, 2018, we held the following debt securities and other investments, recorded at fair value:

- changed (2020-05-08):
[0001564590-20-023537:note_history:36]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 8,967 |  |  | $ | 43 |  |  | $ | (87 | ) |  | $ | 8,923 |  |
| Municipal fixed-rate bonds |  |  | 931 |  |  |  | 3 |  |  |  | — |  |  |  | 934 |  |
| Asset-backed bonds |  |  | 6,052 |  |  |  | 17 |  |  |  | (76 | ) |  |  | 5,993 |  |
| Mortgage/Agency-backed bonds |  |  | 8,389 |  |  |  | 140 |  |  |  | (62 | ) |  |  | 8,467 |  |
| U.S. government bonds |  |  | 12,788 |  |  |  | 319 |  |  |  | (6 | ) |  |  | 13,101 |  |
| Other |  |  | 442 |  |  |  | — |  |  |  | — |  |  |  | 442 |  |
| Available-for-sale debt securities held at fair value |  | $ | 37,569 |  |  | $ | 522 |  |  | $ | (231 | ) |  | $ | 37,860 |  |
  (was, 2019-11-05, similarity 0.9527):
[0001564590-19-040490:note_history:36]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 20,777 |  |  | $ | 19 |  |  | $ | (112 | ) |  | $ | 20,684 |  |
| Municipal fixed-rate bonds |  |  | 1,339 |  |  |  | — |  |  |  | (26 | ) |  |  | 1,313 |  |
| Asset-backed bonds |  |  | 5,230 |  |  |  | 5 |  |  |  | (14 | ) |  |  | 5,221 |  |
| Mortgage/Agency-backed bonds |  |  | 3,833 |  |  |  | 2 |  |  |  | (44 | ) |  |  | 3,791 |  |
| U.S. government bonds |  |  | 9,271 |  |  |  | 1 |  |  |  | (66 | ) |  |  | 9,206 |  |
| Foreign government bonds |  |  | 592 |  |  |  | — |  |  |  | (8 | ) |  |  | 584 |  |
| Available-for-sale debt securities held at fair value |  | $ | 41,042 |  |  | $ | 27 |  |  | $ | (270 | ) |  | $ | 40,799 |  |

- changed (2020-05-08):
[0001564590-20-023537:note_history:37]
As of December 31, 2019, the following debt securities and other investments were included on the Condensed Consolidated Balance sheet and recorded at fair value:
  (was, 2019-11-05, similarity 0.6848):
[0001564590-19-040490:note_history:37]
At September 30, 2019, we held the following debt securities and other investments, recorded at fair value:

- changed (2020-05-08):
[0001564590-20-023537:note_history:38]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 9,304 |  |  | $ | 80 |  |  | $ | — |  |  | $ | 9,384 |  |
| Municipal fixed-rate bonds |  |  | 930 |  |  |  | — |  |  |  | — |  |  |  | 930 |  |
| Asset-backed bonds |  |  | 6,867 |  |  |  | 26 |  |  |  | (3 | ) |  |  | 6,890 |  |
| Mortgage/Agency-backed bonds |  |  | 6,944 |  |  |  | 26 |  |  |  | (8 | ) |  |  | 6,962 |  |
| U.S. government bonds |  |  | 12,311 |  |  |  | 21 |  |  |  | (9 | ) |  |  | 12,323 |  |
| Foreign government bonds |  |  | 372 |  |  |  | — |  |  |  | (1 | ) |  |  | 371 |  |
| Variable rate demand notes |  |  | 800 |  |  |  | — |  |  |  | — |  |  |  | 800 |  |
| Available-for-sale debt securities held at fair value |  | $ | 37,528 |  |  | $ | 153 |  |  | $ | (21 | ) |  | $ | 37,660 |  |
  (was, 2019-11-05, similarity 0.9419):
[0001564590-19-040490:note_history:38]
|  |  | Amortized |  |  | Gross Unrealized |  |  | Fair |  |
| (In thousands) |  | Cost |  |  | Gains |  |  | Losses |  |  | Value |  |
| Corporate bonds |  | $ | 10,733 |  |  | $ | 95 |  |  | $ | — |  |  | $ | 10,828 |  |
| Municipal fixed-rate bonds |  |  | 931 |  |  |  | — |  |  |  | (1 | ) |  |  | 930 |  |
| Asset-backed bonds |  |  | 7,222 |  |  |  | 35 |  |  |  | (2 | ) |  |  | 7,255 |  |
| Mortgage/Agency-backed bonds |  |  | 7,366 |  |  |  | 29 |  |  |  | (7 | ) |  |  | 7,388 |  |
| U.S. government bonds |  |  | 9,160 |  |  |  | 4 |  |  |  | (21 | ) |  |  | 9,143 |  |
| Foreign government bonds |  |  | 372 |  |  |  | — |  |  |  | (3 | ) |  |  | 369 |  |
| Available-for-sale debt securities held at fair value |  | $ | 35,784 |  |  | $ | 163 |  |  | $ | (34 | ) |  | $ | 35,913 |  |

- added (2020-05-08):
[0001564590-20-023537:note_history:39]
As of March 31, 2020, contractual maturities related to debt securities and other investments were as follows:

- changed (2020-05-08):
[0001564590-20-023537:note_history:40]
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset- backed bonds |  |  | Mortgage / Agency- backed bonds |  |  | U.S. government bonds |  |  | Other |  |
| Less than one year |  | $ | 3,274 |  |  | $ | — |  |  | $ | 101 |  |  | $ | — |  |  | $ | 61 |  |  | $ | 442 |  |
| One to two years |  |  | 3,702 |  |  |  | 934 |  |  |  | 389 |  |  |  | 584 |  |  |  | 5,376 |  |  |  | — |  |
| Two to three years |  |  | 1,947 |  |  |  | — |  |  |  | 1,559 |  |  |  | 1,769 |  |  |  | 7,285 |  |  |  | — |  |
| Three to five years |  |  | — |  |  |  | — |  |  |  | 2,174 |  |  |  | 107 |  |  |  | 379 |  |  |  | — |  |
| Five to ten years |  |  | — |  |  |  | — |  |  |  | 1,505 |  |  |  | 1,655 |  |  |  | — |  |  |  | — |  |
| More than ten years |  |  | — |  |  |  | — |  |  |  | 265 |  |  |  | 4,352 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 8,923 |  |  | $ | 934 |  |  | $ | 5,993 |  |  | $ | 8,467 |  |  | $ | 13,101 |  |  | $ | 442 |  |
  (was, 2019-11-05, similarity 0.8514):
[0001564590-19-040490:note_history:40]
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset- backed bonds |  |  | Mortgage / Agency- backed bonds |  |  | U.S. government bonds |  |  | Foreign government bonds |  |
| Less than one year |  | $ | 3,154 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| One to two years |  |  | 4,316 |  |  |  | 930 |  |  |  | 941 |  |  |  | 215 |  |  |  | — |  |  |  | — |  |
| Two to three years |  |  | 3,068 |  |  |  | — |  |  |  | 2,475 |  |  |  | 1,072 |  |  |  | 7,528 |  |  |  | — |  |
| Three to five years |  |  | 290 |  |  |  | — |  |  |  | 1,593 |  |  |  | 920 |  |  |  | 1,615 |  |  |  | 369 |  |
| Five to ten years |  |  | — |  |  |  | — |  |  |  | 1,666 |  |  |  | 680 |  |  |  | — |  |  |  | — |  |
| More than ten years |  |  | — |  |  |  | — |  |  |  | 580 |  |  |  | 4,501 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 10,828 |  |  | $ | 930 |  |  | $ | 7,255 |  |  | $ | 7,388 |  |  | $ | 9,143 |  |  | $ | 369 |  |

- changed (2020-05-08):
[0001564590-20-023537:note_history:41]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2020 |  |  | 2019 |  |
| Gross realized gains on debt securities |  | $ | 43 |  |  | $ | 41 |  |
| Gross realized losses on debt securities |  |  | (20 | ) |  |  | (19 | ) |
| Total gain recognized, net |  | $ | 23 |  |  | $ | 22 |  |
  (was, 2019-11-05, similarity 0.7554):
[0001564590-19-040490:note_history:41]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Gross realized gains on debt securities |  | $ | 36 |  |  | $ | 24 |  |  | $ | 85 |  |  | $ | 49 |  |
| Gross realized losses on debt securities |  |  | (7 | ) |  |  | (50 | ) |  |  | (40 | ) |  |  | (365 | ) |
| Total gain (loss) recognized, net |  | $ | 29 |  |  | $ | (26 | ) |  | $ | 45 |  |  | $ | (316 | ) |

- changed (2020-05-08):
[0001564590-20-023537:note_history:42]
The Company’s investment policy provides limitations for issuer concentration, which limits, at the time of purchase, the concentration in any one issuer to 5% of the market value of our total investment portfolio. The Company did not purchase any available-for-sale debt security with credit deterioration during the three months ended March 31, 2020.
  (was, 2019-11-05, similarity 0.7309):
[0001564590-19-040490:note_history:42]
Our investment policy provides limitations for issuer concentration, which limits, at the time of purchase, the concentration in any one issuer to 5% of the market value of our total investment portfolio.

- added (2020-05-08):
[0001564590-20-023537:note_history:43]
During the three months ended March 31, 2019, an outstanding note receivable of $4.3 million was repaid and reissued in the form of debt and equity. Of the outstanding $4.3 million, $3.4 million was issued as an equity investment, which represented a non-cash investing activity. We elected to record this equity investment that does not have a readily determinable fair value using the measurement alternative. Under the measurement alternative, equity investments that do not have a readily determinable fair value can be recorded at cost less impairment, if any, adjusted for observable price changes for an identical or similar investment. The carrying value of this investment under the measurement alternative was $3.4 million as of December 31, 2019. During the three months ended March 31, 2020, an impairment charge of $1.6 million was recorded related to this equity investment, which is included in net investment gain (loss) on the Condensed Consolidated Statement of Income (Loss). As a result, the carrying value of this investment was $1.8 million as of March 31, 2020. The remaining amount, $0.9 million of the original $4.3 million note receivable, was reissued as a new note receivable, which is included in long-term investments on the Condensed Consolidated Balance Sheets as of March 31, 2020 and December 31, 2019, and represented a non-cash operating activity during the three months ended March 31, 2019. No impairment charge was recognized related to the note receivable as it is a secured loan.

- changed (2020-05-08):
[0001564590-20-023537:note_history:44]
Realized and unrealized gains and losses related to marketable equity securities for the three months ended March 31, 2020 and 2019 were as follows:
  (was, 2019-11-05, similarity 0.8966):
[0001564590-19-040490:note_history:44]
Realized and unrealized gains and losses for our marketable equity securities for the three and nine months ended September 30, 2019 and 2018 were as follows:

- added (2020-05-08):
[0001564590-20-023537:note_history:45]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2020 |  |  | 2019 |  |
| Realized losses on equity securities sold |  | $ | (2,436 | ) |  | $ | (14 | ) |
| Unrealized gains (losses) on equity securities held |  |  | (8,464 | ) |  |  | 5,918 |  |
| Total gain (loss) recognized, net |  | $ | (10,900 | ) |  | $ | 5,904 |  |

- added (2020-05-08):
[0001564590-20-023537:note_history:46]
U.S. GAAP establishes a three-level valuation hierarchy based upon observable and unobservable inputs for fair value measurement of financial instruments:

- added (2020-05-08):
[0001564590-20-023537:note_history:47]
• Level 1 – Observable outputs; values based on unadjusted quoted prices for identical assets or liabilities in an active market;

- added (2020-05-08):
[0001564590-20-023537:note_history:48]
• Level 2 – Significant inputs that are observable; values based on quoted prices in markets that are not active or model inputs that are observable either directly or indirectly;

- added (2020-05-08):
[0001564590-20-023537:note_history:49]
• Level 3 – Significant unobservable inputs; values based on prices or valuation techniques that require inputs that are both unobservable and significant to the overall fair value measurement. These inputs could include information supplied by investees.

- added (2020-05-08):
[0001564590-20-023537:note_history:50]
The Company’s cash equivalents and investments held at fair value are categorized into this hierarchy as follows:

- changed (2020-05-08):
[0001564590-20-023537:note_history:51]
|  |  |  |  |  |  | Fair Value Measurements as of March 31, 2020 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 4,826 |  |  | $ | 4,826 |  |  | $ | — |  |  | $ | — |  |
| Commercial paper |  |  | 500 |  |  |  | — |  |  |  | 500 |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 8,923 |  |  |  | — |  |  |  | 8,923 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 934 |  |  |  | — |  |  |  | 934 |  |  |  | — |  |
| Asset-backed bonds |  |  | 5,993 |  |  |  | — |  |  |  | 5,993 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 8,467 |  |  |  | — |  |  |  | 8,467 |  |  |  | — |  |
| U.S. government bonds |  |  | 13,101 |  |  |  | 13,101 |  |  |  | — |  |  |  | — |  |
| Other |  |  | 442 |  |  |  | — |  |  |  | — |  |  |  | 442 |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 24,823 |  |  |  | 24,823 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 17,349 |  |  |  | 17,349 |  |  |  | — |  |  |  | — |  |
| Other investments |  |  | 2,106 |  |  |  | 2,106 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 87,464 |  |  | $ | 62,205 |  |  | $ | 24,817 |  |  | $ | 442 |  |
  (was, 2019-11-05, similarity 0.8565):
[0001564590-19-040490:note_history:51]
|  |  |  |  |  |  | Fair Value Measurements at September 30, 2019 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,817 |  |  | $ | 1,817 |  |  | $ | — |  |  | $ | — |  |
| Commercial paper |  |  | 1,295 |  |  |  | — |  |  |  | 1,295 |  |  |  | — |  |
| Cash equivalents |  |  | 3,112 |  |  |  | 1,817 |  |  |  | 1,295 |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 10,828 |  |  |  | — |  |  |  | 10,828 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 930 |  |  |  | — |  |  |  | 930 |  |  |  | — |  |
| Asset-backed bonds |  |  | 7,255 |  |  |  | — |  |  |  | 7,255 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 7,388 |  |  |  | — |  |  |  | 7,388 |  |  |  | — |  |
| U.S. government bonds |  |  | 9,143 |  |  |  | 9,143 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 369 |  |  |  | — |  |  |  | 369 |  |  |  | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 32,543 |  |  |  | 32,543 |  |  |  | — |  |  |  | — |  |
| Equity in escrow |  |  | 165 |  |  |  | 165 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 20,580 |  |  |  | 20,580 |  |  |  | — |  |  |  | — |  |
| Total debt and equity securities at fair value |  |  | 89,201 |  |  |  | 62,431 |  |  |  | 26,770 |  |  |  | — |  |
| Total |  | $ | 92,313 |  |  | $ | 64,248 |  |  | $ | 28,065 |  |  | $ | — |  |

- changed (2020-05-08):
[0001564590-20-023537:note_history:52]
|  |  |  |  |  |  | Fair Value Measurements as of December 31, 2019 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,309 |  |  | $ | 1,309 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 9,384 |  |  |  | — |  |  |  | 9,384 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 930 |  |  |  | — |  |  |  | 930 |  |  |  | — |  |
| Asset-backed bonds |  |  | 6,890 |  |  |  | — |  |  |  | 6,890 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 6,962 |  |  |  | — |  |  |  | 6,962 |  |  |  | — |  |
| U.S. government bonds |  |  | 12,323 |  |  |  | 12,323 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 371 |  |  |  | — |  |  |  | 371 |  |  |  | — |  |
| Variable rate demand notes |  |  | 800 |  |  |  | — |  |  |  | 800 |  |  |  | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 35,501 |  |  |  | 35,501 |  |  |  | — |  |  |  | — |  |
| Equity in escrow |  |  | 298 |  |  |  | 298 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 21,698 |  |  |  | 21,698 |  |  |  | — |  |  |  | — |  |
| Other investments |  |  | 2,442 |  |  |  | 2,442 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 98,908 |  |  | $ | 73,571 |  |  | $ | 25,337 |  |  | $ | — |  |
  (was, 2019-11-05, similarity 0.662):
[0001564590-19-040490:note_history:52]
|  |  |  |  |  |  | Fair Value Measurements at December 31, 2018 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,554 |  |  | $ | 1,554 |  |  | $ | — |  |  | $ | — |  |
| Cash equivalents |  |  | 1,554 |  |  |  | 1,554 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 20,684 |  |  |  | — |  |  |  | 20,684 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 1,313 |  |  |  | — |  |  |  | 1,313 |  |  |  | — |  |
| Asset-backed bonds |  |  | 5,221 |  |  |  | — |  |  |  | 5,221 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 3,791 |  |  |  | — |  |  |  | 3,791 |  |  |  | — |  |
| U.S. government bonds |  |  | 9,206 |  |  |  | 9,206 |  |  |  | — |  |  |  | — |  |
| Foreign government bonds |  |  | 584 |  |  |  | — |  |  |  | 584 |  |  |  | — |  |
| Marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – various industries |  |  | 26,763 |  |  |  | 26,763 |  |  |  | — |  |  |  | — |  |
| Equity in escrow |  |  | 253 |  |  |  | 253 |  |  |  | — |  |  |  | — |  |
| Deferred compensation plan assets |  |  | 18,256 |  |  |  | 18,256 |  |  |  | — |  |  |  | — |  |
| Total debt and equity securities at fair value |  |  | 86,071 |  |  |  | 54,478 |  |  |  | 31,593 |  |  |  | — |  |
| Total |  | $ | 87,625 |  |  | $ | 56,032 |  |  | $ | 31,593 |  |  | $ | — |  |

- changed (2020-05-08):
[0001564590-20-023537:note_history:53]
The fair value of our Level 2 securities is calculated using a weighted average market price for each security. Market prices are obtained from a variety of industry standard data providers, large financial institutions and other third-party sources. These multiple market prices are used as inputs into a distribution-curve-based algorithm to determine the daily market value of each security.
  (was, 2019-11-05, similarity 0.9987):
[0001564590-19-040490:note_history:53]
The fair value of our Level 2 securities is calculated using a weighted average market price for each security. Market prices are obtained from a variety of industry standard data providers, large financial institutions, and other third-party sources. These multiple market prices are used as inputs into a distribution-curve-based algorithm to determine the daily market value of each security.

- added (2020-05-08):
[0001564590-20-023537:note_history:54]
The fair value of Level 3 securities is calculated based on unobservable inputs. Quantitative information with respect to unobservable inputs consists of third-party valuations performed in accordance with ASC 820 – Fair Value Measurement. Inputs used in preparing the third-party valuation included the following assumptions, among others: estimated discount rates and fair market yields.

- removed (2020-05-08):
[0001564590-19-040490:note_history:55]
As of September 30, 2019, our debt securities had the following contractual maturities:

- removed (2020-05-08):
[0001564590-19-040490:note_history:56]
At September 30, 2019, we held a $25.6 million restricted certificate of deposit that is carried at cost and matures on January 8, 2020. This investment serves as a collateral deposit against the principal amount outstanding under loans made to ADTRAN pursuant to an Alabama State Industrial Development Authority revenue bond (the “Bond”), which totaled $25.6 million at September 30, 2019 and December 31, 2018. At September 30, 2019 and December 31, 2018, the estimated fair value of the Bond using a level 2 valuation technique was approximately $25.6 million and $25.4 million, respectively, based on a debt security with a comparable interest rate and maturity and a Standard and Poor’s credit rating of AA+. We have the right to offset the balance of the Bond with the collateral deposit in order to reduce the balance of the indebtedness. The Bond matures on January 1, 2020, and bears interest at the rate of 2% per annum. In conjunction with this program, we are eligible to receive certain economic incentives from the State of Alabama that reduce the amount of payroll withholdings we are required to remit to the state for those employment positions that qualify under this program. We are required to make payments in the amounts necessary to pay the interest on the amounts currently outstanding. We have made annual principal payments in addition to the interest amounts that are due. The restricted funds held as collateral against the outstanding principal amount of the Bond will be used to pay the outstanding principal and interest upon the Bond’s maturity.

- removed (2020-05-08):
[0001564590-19-040490:note_history:57]
On January 1, 2018, we adopted ASU 2016-01, which requires us to measure all equity investments that do not result in consolidation and are not accounted for under the equity method at fair value, with any changes in fair value recognized in net investment gain (loss). Upon adoption, we reclassified $3.2 million of net unrealized gains related to marketable equity securities from accumulated other comprehensive income (loss) to retained earnings.

- removed (2020-05-08):
[0001564590-19-040490:note_history:58]
ASU 2016-01 also provides a measurement alternative for equity investments that do not have a readily determinable fair value in which investments can be recorded at cost less impairment, if any, adjusted for observable price changes for an identical or similar investment. We elected to record our equity investment that does not have a readily determinable fair value using the measurement alternative method. As of December 31, 2018, the Company had a note receivable of approximately $4.3 million, which was included in other receivables on the Condensed Consolidated Balance Sheet. During the three months ended March 31, 2019, this amount was repaid and reissued in the form of debt and equity. Approximately $3.4 million was issued as an equity investment, which represented a non-cash investing activity. The carrying value of this investment under the measurement alternative was $3.4 million as of September 30, 2019. The remaining amount, approximately $0.9 million, was converted into a new note receivable, which is included in other receivables on the Condensed Consolidated Balance Sheet and represents a non-cash operating activity.

- removed (2020-05-08):
[0001564590-19-040490:note_history:59]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Realized gains (losses) on equity securities sold |  | $ | (20 | ) |  | $ | 1,240 |  |  | $ | (83 | ) |  | $ | 1,587 |  |
| Unrealized gains (losses) on equity securities held |  |  | (225 | ) |  |  | 3,293 |  |  |  | 8,233 |  |  |  | 4,129 |  |
| Total gain (loss) recognized, net |  | $ | (245 | ) |  | $ | 4,533 |  |  | $ | 8,150 |  |  | $ | 5,716 |  |

- removed (2020-05-08):
[0001564590-19-040490:note_history:60]
As of September 30, 2019 and 2018, gross unrealized losses related to individual investments in a continuous loss position for twelve months or longer were not material.

- removed (2020-05-08):
[0001564590-19-040490:note_history:61]
We have categorized our cash equivalents and our investments held at fair value into a three-level fair value hierarchy based on the priority of the inputs to the valuation technique for the cash equivalents and investments as follows: Level 1 - Values based on unadjusted quoted prices for identical assets or liabilities in an active market; Level 2 - Values based on quoted prices in markets that are not active or model inputs that are observable either directly or indirectly; Level 3 - Values based on prices or valuation techniques that require inputs that are both unobservable and significant to the overall fair value measurement. These inputs include information supplied by investees.


## us-gaap:DisaggregationOfRevenueTableTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-05-08):
[0001564590-20-023537:note_history:62]
The following table disaggregates revenue by reportable segment and revenue category for the three months ended March 31, 2020 and 2019:
  (was, 2019-11-05, similarity 0.947):
[0001564590-19-040490:note_history:62]
The following table disaggregates our revenue by reportable segment and revenue category for the three months ended September 30, 2019 and 2018:

- changed (2020-05-08):
[0001564590-20-023537:note_history:63]
|  |  | Three Months Ended |  |
|  |  | March 31, 2020 |  |  | March 31, 2019 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 53,055 |  |  | $ | 12,911 |  |  | $ | 65,966 |  |  | $ | 85,673 |  |  | $ | 14,105 |  |  | $ | 99,778 |  |
| Subscriber Solutions & Experience |  |  | 39,983 |  |  |  | 2,196 |  |  |  | 42,179 |  |  |  | 34,719 |  |  |  | 2,034 |  |  |  | 36,753 |  |
| Traditional & Other Products |  |  | 4,334 |  |  |  | 2,044 |  |  |  | 6,378 |  |  |  | 5,430 |  |  |  | 1,830 |  |  |  | 7,260 |  |
| Total |  | $ | 97,372 |  |  | $ | 17,151 |  |  | $ | 114,523 |  |  | $ | 125,822 |  |  | $ | 17,969 |  |  | $ | 143,791 |  |
  (was, 2019-11-05, similarity 0.9578):
[0001564590-19-040490:note_history:63]
|  |  | Three Months Ended |  |
|  |  | September 30, 2019 |  |  | September 30, 2018 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 48,902 |  |  | $ | 16,212 |  |  | $ | 65,114 |  |  | $ | 76,046 |  |  | $ | 15,855 |  |  | $ | 91,901 |  |
| Subscriber Solutions & Experience(1) |  |  | 40,382 |  |  |  | 2,094 |  |  |  | 42,476 |  |  |  | 37,313 |  |  |  | 1,239 |  |  |  | 38,552 |  |
| Traditional & Other Products |  |  | 4,734 |  |  |  | 1,768 |  |  |  | 6,502 |  |  |  | 7,684 |  |  |  | 2,198 |  |  |  | 9,882 |  |
| Total |  | $ | 94,018 |  |  | $ | 20,074 |  |  | $ | 114,092 |  |  | $ | 121,043 |  |  | $ | 19,292 |  |  | $ | 140,335 |  |

- changed (2020-05-08):
[0001564590-20-023537:note_history:64]
The table below presents sales information by category for the three months ended March 31, 2020 and 2019:
  (was, 2019-11-05, similarity 0.9091):
[0001564590-19-040490:note_history:64]
The table below presents sales information by category for the three and nine months ended September 30, 2019 and 2018:

- changed (2020-05-08):
[0001564590-20-023537:note_history:65]
|  |  | Three Months Ended |  |
|  |  | March 31, |  |
| (In thousands) |  | 2020 |  |  | 2019 |  |
| Access & Aggregation |  | $ | 65,966 |  |  | $ | 99,778 |  |
| Subscriber Solutions & Experience |  |  | 42,179 |  |  |  | 36,753 |  |
| Traditional & Other Products |  |  | 6,378 |  |  |  | 7,260 |  |
| Total |  | $ | 114,523 |  |  | $ | 143,791 |  |
  (was, 2019-11-05, similarity 0.7686):
[0001564590-19-040490:note_history:65]
|  |  | Three Months Ended |  |  | Nine Months Ended |  |
|  |  | September 30, |  |  | September 30, |  |
| (In thousands) |  | 2019 |  |  | 2018 |  |  | 2019 |  |  | 2018 |  |
| Access & Aggregation |  | $ | 65,114 |  |  | $ | 91,901 |  |  | $ | 274,313 |  |  | $ | 258,323 |  |
| Subscriber Solutions & Experience |  |  | 42,476 |  |  |  | 38,552 |  |  |  | 119,731 |  |  |  | 103,213 |  |
| Traditional & Other Products |  |  | 6,502 |  |  |  | 9,882 |  |  |  | 20,230 |  |  |  | 27,653 |  |
| Total |  | $ | 114,092 |  |  | $ | 140,335 |  |  | $ | 414,274 |  |  | $ | 389,189 |  |

- removed (2020-05-08):
[0001564590-19-040490:note_history:66]
|  | (1) | Subscriber Solutions & Experience was formerly reported as Customer Devices. With the increasing focus on enhancing the customer experience for both our business and consumer broadband customers and the addition of SmartRG during the fourth quarter of 2018, Subscriber Solutions & Experience more accurately represents this revenue category. |

- removed (2020-05-08):
[0001564590-19-040490:note_history:67]
The following table disaggregates our revenue by reportable segment and revenue category for the nine months ended September 30, 2019 and 2018:

- removed (2020-05-08):
[0001564590-19-040490:note_history:68]
|  |  | Nine Months Ended |  |
|  |  | September 30, 2019 |  |  | September 30, 2018 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 230,837 |  |  | $ | 43,476 |  |  | $ | 274,313 |  |  | $ | 220,653 |  |  | $ | 37,670 |  |  | $ | 258,323 |  |
| Subscriber Solutions & Experience(1) |  |  | 113,545 |  |  |  | 6,186 |  |  |  | 119,731 |  |  |  | 99,396 |  |  |  | 3,817 |  |  |  | 103,213 |  |
| Traditional & Other Products |  |  | 14,625 |  |  |  | 5,605 |  |  |  | 20,230 |  |  |  | 21,310 |  |  |  | 6,343 |  |  |  | 27,653 |  |
| Total |  | $ | 359,007 |  |  | $ | 55,267 |  |  | $ | 414,274 |  |  | $ | 341,359 |  |  | $ | 47,830 |  |  | $ | 389,189 |  |

- removed (2020-05-08):
[0001564590-19-040490:note_history:69]
|  | (1) | Subscriber Solutions & Experience was formerly reported as Customer Devices. With the increasing focus on enhancing the customer experience for both our business and consumer broadband customers and the addition of SmartRG during the fourth quarter of 2018, Subscriber Solutions & Experience more accurately represents this revenue category. |


## us-gaap:RevenueFromContractWithCustomerTextBlock (revenue_recognition_policy) — matched_by: tag_name, score: 1.0

- changed (2020-05-08):
[0001564590-20-023537:note_history:70]
The following is a description of the principal activities from which revenue is generated by reportable segment:
  (was, 2019-11-05, similarity 0.8908):
[0001564590-19-040490:note_history:70]
The following is a description of the principal activities from which we generate our revenue by reportable segment.

- added (2020-05-08):
[0001564590-20-023537:note_history:71]
Network Solutions Segment - Includes hardware products and software-defined next-generation virtualized solutions used in service provider or business networks, as well as prior generation products.

- added (2020-05-08):
[0001564590-20-023537:note_history:72]
Services & Support Segment - Includes maintenance, network implementation, solutions integration and managed services, which include hosted cloud services and subscription services.

- added (2020-05-08):
[0001564590-20-023537:note_history:73]
See Note 15 for additional information on reportable segments.

- changed (2020-05-08):
[0001564590-20-023537:note_history:74]
In addition to our reporting segments, revenue is also reported for the following three categories – Access & Aggregation, Subscriber Solutions & Experience and Traditional & Other Products.
  (was, 2019-11-05, similarity 0.939):
[0001564590-19-040490:note_history:74]
In addition to our reporting segments, we also report revenue in the following three categories – Access & Aggregation, Subscriber Solutions & Experience and Traditional & Other Products.

- changed (2020-05-08):
[0001564590-20-023537:note_history:75]
The following table disaggregates revenue by reportable segment and revenue category for the three months ended March 31, 2020 and 2019:
  (was, 2019-11-05, similarity 0.947):
[0001564590-19-040490:note_history:75]
The following table disaggregates our revenue by reportable segment and revenue category for the three months ended September 30, 2019 and 2018:

- changed (2020-05-08):
[0001564590-20-023537:note_history:76]
|  |  | Three Months Ended |  |
|  |  | March 31, 2020 |  |  | March 31, 2019 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 53,055 |  |  | $ | 12,911 |  |  | $ | 65,966 |  |  | $ | 85,673 |  |  | $ | 14,105 |  |  | $ | 99,778 |  |
| Subscriber Solutions & Experience |  |  | 39,983 |  |  |  | 2,196 |  |  |  | 42,179 |  |  |  | 34,719 |  |  |  | 2,034 |  |  |  | 36,753 |  |
| Traditional & Other Products |  |  | 4,334 |  |  |  | 2,044 |  |  |  | 6,378 |  |  |  | 5,430 |  |  |  | 1,830 |  |  |  | 7,260 |  |
| Total |  | $ | 97,372 |  |  | $ | 17,151 |  |  | $ | 114,523 |  |  | $ | 125,822 |  |  | $ | 17,969 |  |  | $ | 143,791 |  |
  (was, 2019-11-05, similarity 0.9578):
[0001564590-19-040490:note_history:76]
|  |  | Three Months Ended |  |
|  |  | September 30, 2019 |  |  | September 30, 2018 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 48,902 |  |  | $ | 16,212 |  |  | $ | 65,114 |  |  | $ | 76,046 |  |  | $ | 15,855 |  |  | $ | 91,901 |  |
| Subscriber Solutions & Experience(1) |  |  | 40,382 |  |  |  | 2,094 |  |  |  | 42,476 |  |  |  | 37,313 |  |  |  | 1,239 |  |  |  | 38,552 |  |
| Traditional & Other Products |  |  | 4,734 |  |  |  | 1,768 |  |  |  | 6,502 |  |  |  | 7,684 |  |  |  | 2,198 |  |  |  | 9,882 |  |
| Total |  | $ | 94,018 |  |  | $ | 20,074 |  |  | $ | 114,092 |  |  | $ | 121,043 |  |  | $ | 19,292 |  |  | $ | 140,335 |  |

- added (2020-05-08):
[0001564590-20-023537:note_history:77]
Revenue allocated to remaining performance obligations represents contract revenues that have not yet been recognized for contracts with a duration greater than one year. As of March 31, 2020, we did not have any significant performance obligations related to customer contracts that had an original expected duration of one year or more, other than maintenance services, which are satisfied over time. As a practical expedient, for certain contracts we recognize revenue equal to the amounts we are entitled to invoice which correspond to the value of completed performance obligations to date. The amount related to these performance obligations was $14.3 million and $13.6 million as of March 31, 2020 and December 31, 2019, respectively. The Company expects to recognize 69% of the $14.3 million as of March 31, 2020 over the next 12 months with the remainder to be recognized thereafter.

- changed (2020-05-08):
[0001564590-20-023537:note_history:78]
| (In thousands) |  | March 31, 2020 |  |  | December 31, 2019 |  |
| Accounts receivable, net |  | $ | 86,465 |  |  | $ | 90,531 |  |
| Contract assets(1) |  | $ | 1,354 |  |  | $ | 2,812 |  |
| Unearned revenue |  | $ | 12,465 |  |  | $ | 11,963 |  |
| Non-current unearned revenue |  | $ | 4,476 |  |  | $ | 6,012 |  |
  (was, 2019-11-05, similarity 0.9183):
[0001564590-19-040490:note_history:78]
| (In thousands) |  | September 30, 2019 |  |  | December 31, 2018 |  |
| Accounts receivable, net |  | $ | 90,647 |  |  | $ | 99,385 |  |
| Contract assets(1) |  | $ | 2,434 |  |  | $ | 3,766 |  |
| Unearned revenue |  | $ | 14,022 |  |  | $ | 17,940 |  |
| Non-current unearned revenue |  | $ | 4,581 |  |  | $ | 5,296 |  |

- changed (2020-05-08):
[0001564590-20-023537:note_history:79]
|  | (1) | Included in other receivables on the Condensed Consolidated Balance Sheets. |
  (was, 2019-11-05, similarity 0.9942):
[0001564590-19-040490:note_history:79]
|  | (1) | Included in other receivables on the Condensed Consolidated Balance Sheet. |

- changed (2020-05-08):
[0001564590-20-023537:note_history:80]
Of the outstanding unearned revenue balances as of December 31, 2019 and December 31, 2018, $5.7 million and $6.9 million was recognized as revenue during the three months ended March 31, 2020 and March 31, 2019, respectively.
  (was, 2019-11-05, similarity 0.8519):
[0001564590-19-040490:note_history:80]
Of the outstanding unearned revenue balance at December 31, 2018, $1.2 million and $11.7 million was recognized as revenue during the three and nine months ended September 30, 2019, respectively.

- removed (2020-05-08):
[0001564590-19-040490:note_history:81]
Network Solutions Segment

- removed (2020-05-08):
[0001564590-19-040490:note_history:82]
Network Solutions includes hardware products and software-defined next-generation virtualized solutions used in service provider or business networks, as well as prior generation products. The majority of the revenue from this segment is from hardware sales. In certain transactions, we are also the lessor in sales-type lease arrangements for network equipment. These arrangements typically include network equipment, network implementation services and maintenance services. Network implementation services and maintenance services are included in the Services & Support segment discussed below. See Note 12 for additional information.

- removed (2020-05-08):
[0001564590-19-040490:note_history:83]
Services & Support Segment

- removed (2020-05-08):
[0001564590-19-040490:note_history:84]
To complement our Network Solutions segment, we offer a complete portfolio of maintenance, network implementation, solutions integration and managed services, which include hosted cloud services and subscription services.

- removed (2020-05-08):
[0001564590-19-040490:note_history:85]
|  | (1) | Subscriber Solutions & Experience was formerly reported as Customer Devices. With the increasing focus on enhancing the customer experience for both our business and consumer broadband customers and the addition of SmartRG during the fourth quarter of 2018, Subscriber Solutions & Experience more accurately represents this revenue category. |

- removed (2020-05-08):
[0001564590-19-040490:note_history:86]
The following table disaggregates our revenue by reportable segment and revenue category for the nine months ended September 30, 2019 and 2018:

- removed (2020-05-08):
[0001564590-19-040490:note_history:87]
|  |  | Nine Months Ended |  |
|  |  | September 30, 2019 |  |  | September 30, 2018 |  |
| (In thousands) |  | Network Solutions |  |  | Services & Support |  |  | Total |  |  | Network Solutions |  |  | Services & Support |  |  | Total |  |
| Access & Aggregation |  | $ | 230,837 |  |  | $ | 43,476 |  |  | $ | 274,313 |  |  | $ | 220,653 |  |  | $ | 37,670 |  |  | $ | 258,323 |  |
| Subscriber Solutions & Experience(1) |  |  | 113,545 |  |  |  | 6,186 |  |  |  | 119,731 |  |  |  | 99,396 |  |  |  | 3,817 |  |  |  | 103,213 |  |
| Traditional & Other Products |  |  | 14,625 |  |  |  | 5,605 |  |  |  | 20,230 |  |  |  | 21,310 |  |  |  | 6,343 |  |  |  | 27,653 |  |
| Total |  | $ | 359,007 |  |  | $ | 55,267 |  |  | $ | 414,274 |  |  | $ | 341,359 |  |  | $ | 47,830 |  |  | $ | 389,189 |  |

- removed (2020-05-08):
[0001564590-19-040490:note_history:88]
|  | (1) | Subscriber Solutions & Experience was formerly reported as Customer Devices. With the increasing focus on enhancing the customer experience for both our business and consumer broadband customers and the addition of SmartRG during the fourth quarter of 2018, Subscriber Solutions & Experience more accurately represents this revenue category. |

- removed (2020-05-08):
[0001564590-19-040490:note_history:89]
Revenue is measured based on the consideration we expect to receive in exchange for transferring goods or providing services to a customer and as performance obligations under the terms of the contract are satisfied. For transactions where there are multiple performance obligations, we account for individual products and services separately if they are distinct (if a product or service is separately identifiable from other items and if a customer can benefit from it on its own or with other resources that are readily available to the customer). As of September 30, 2019, we did not have any significant performance obligations related to customer contracts that had an original expected duration of one year or more, other than maintenance services, which are satisfied over time.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- changed (2020-05-08):
[0001564590-20-023537:note_history:90]
On May 6, 2020, we announced that our Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to the Company’s stockholders of record as of the close of business on May 21, 2020. The payment date will be June 4, 2020 in the aggregate amount of approximately $4.3 million.
  (was, 2019-11-05, similarity 0.9436):
[0001564590-19-040490:note_history:90]
On October 30, 2019, we announced that our Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid to the Company’s stockholders of record as of the close of business on November 14, 2019. The payment date will be December 2, 2019 in the aggregate amount of approximately $4.3 million.
