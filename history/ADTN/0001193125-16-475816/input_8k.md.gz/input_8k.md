# ADTN 8-K — 0001193125-16-432934 filed 2016-01-20

## item codes, every 8-K on or before 2016-02-24

- 2016-02-11 0001193125-16-459453 — 5.02, 9.01
- 2016-01-20 0001193125-16-432934 — 2.02, 9.01
- 2015-11-16 0001193125-15-378019 — 5.02, 9.01
- 2015-10-14 0001193125-15-343083 — 2.02, 9.01
- 2015-07-16 0001193125-15-254729 — 8.01, 9.01
- 2015-07-15 0001193125-15-253068 — 2.02, 9.01
- 2015-05-15 0001193125-15-189160 — 5.07, 9.01
- 2015-04-22 0001193125-15-140997 — 2.02, 9.01
- 2015-02-23 0001193125-15-056741 — 5.02, 9.01
- 2015-01-21 0001193125-15-015465 — 2.02, 9.01
- 2014-10-15 0001193125-14-372076 — 2.02, 9.01
- 2014-10-03 0001193125-14-363152 — 2.02, 9.01
- 2014-07-16 0001193125-14-269660 — 2.02, 9.01
- 2014-05-20 0001193125-14-205916 — 8.01, 9.01
- 2014-05-20 0001193125-14-205906 — 5.02, 9.01
- 2014-05-15 0001193125-14-201144 — 5.07
- 2014-04-16 0001193125-14-144665 — 2.02, 9.01
- 2014-04-03 0001193125-14-129578 — 2.02, 9.01
- 2014-01-22 0001157523-14-000154 — 2.02, 9.01
- 2013-10-15 0001193125-13-399540 — 5.02
- 2013-10-09 0001157523-13-004657 — 2.02, 9.01
- 2013-07-10 0001157523-13-003290 — 2.02, 9.01
- 2013-05-10 0001193125-13-213728 — 5.07
- 2013-05-03 0001193125-13-198816 — 8.01, 9.01
- 2013-04-10 0001157523-13-001730 — 2.02, 9.01
- 2013-01-16 0001157523-13-000139 — 2.02, 9.01
- 2012-10-10 0001157523-12-005081 — 2.02, 9.01
- 2012-10-03 0001193125-12-413609 — 7.01
- 2012-09-28 0001193125-12-408878 — 2.02, 9.01
- 2012-07-11 0001157523-12-003592 — 2.02, 9.01
- 2012-05-10 0001193125-12-225669 — 5.07
- 2012-05-10 0001193125-12-225639 — 8.01, 9.01
- 2012-04-11 0001157523-12-001772 — 2.02, 9.01
- 2012-03-15 0001193125-12-116494 — 2.02, 9.01
- 2012-01-18 0001157523-12-000174 — 2.02, 9.01
- 2011-12-12 0001193125-11-337271 — 7.01, 9.01
- 2011-10-13 0000950123-11-089785 — 5.03, 9.01
- 2011-10-12 0001157523-11-005682 — 2.02, 9.01
- 2011-07-13 0001157523-11-003986 — 2.02, 9.01
- 2011-05-09 0000950123-11-047191 — 5.02, 5.07, 9.01
- 2011-04-13 0001157523-11-002001 — 2.02, 9.01
- 2011-01-19 0001157523-11-000232 — 2.02, 9.01
- 2010-11-09 0000950123-10-103195 — 5.02, 9.01
- 2010-10-13 0001157523-10-005798 — 2.02, 9.01
- 2010-07-14 0001157523-10-004011 — 2.02, 9.01
- 2010-05-28 0000950123-10-053947 — 5.07
- 2010-04-14 0001157523-10-002022 — 2.02, 9.01
- 2010-01-20 0001157523-10-000200 — 2.02, 9.01
- 2009-10-28 0000950123-09-053984 — 8.01
- 2009-10-14 0001157523-09-006877 — 2.02, 9.01
- 2009-07-15 0001157523-09-004878 — 2.02, 9.01
- 2009-04-15 0001157523-09-002687 — 2.02, 9.01
- 2009-01-21 0001157523-09-000340 — 2.02, 9.01
- 2008-11-12 0001193125-08-233181 — 5.02, 9.01
- 2008-10-14 0001157523-08-007999 — 2.02, 9.01
- 2008-07-15 0001157523-08-005504 — 2.02, 9.01
- 2008-04-15 0001157523-08-002896 — 2.02, 9.01
- 2008-01-22 0001157523-08-000408 — 2.02, 9.01
- 2007-10-16 0001193125-07-219356 — 5.03, 9.01
- 2007-10-16 0001157523-07-009850 — 2.02, 9.01
- 2007-07-17 0001157523-07-006912 — 2.02, 9.01
- 2007-04-17 0001157523-07-003630 — 2.02, 9.01
- 2007-04-03 0001179022-07-000068 — 5.02
- 2007-03-28 0001179022-07-000064 — 5.02
- 2007-02-23 0001193125-07-038337 — 5.02
- 2007-02-23 0001193125-07-038335 — 5.02
- 2007-01-30 0001193125-07-015912 — 5.02, 9.01
- 2007-01-26 0001193125-07-014234 — 5.02
- 2007-01-23 0001157523-07-000494 — 2.02, 9.01 — amendment of 0001157523-07-000481
- 2007-01-23 0001157523-07-000481 — 2.02, 9.01
- 2006-10-17 0001157523-06-009945 — 2.02, 9.01
- 2006-07-18 0001157523-06-006929 — 2.02, 9.01
- 2006-06-08 0001193125-06-126486 — 1.01, 9.01
- 2006-05-10 0001193125-06-107316 — 1.01, 9.01
- 2006-04-18 0001157523-06-003699 — 2.02, 9.01
- 2006-02-03 0001179022-06-000014 — 1.01
- 2006-01-27 0001157523-06-000754 — 5.02, 9.01
- 2006-01-24 0001157523-06-000551 — 2.02, 9.01
- 2005-10-18 0001157523-05-008826 — 2.02, 9.01
- 2005-07-19 0001193125-05-143958 — 1.01, 5.02, 9.01
- 2005-07-19 0001193125-05-143957 — 2.02, 9.01
- 2005-05-20 0001193125-05-112019 — 1.01, 9.01
- 2005-04-19 0001157523-05-003418 — 2.02, 9.01
- 2005-01-25 0001193125-05-010721 — 2.02, 9.01
- 2004-10-12 0001193125-04-169652 — 2.02, 9.01
- 2004-07-13 0001193125-04-116820 — 12, 7
- 2004-04-14 0001193125-04-061547 — 12, 7
- 2004-01-21 0001193125-04-006366 — 12, 7
- 2003-10-14 0001193125-03-061018 — 12, 5, 7
- 2003-07-15 0001193125-03-019292 — 7, 9
- 2003-04-15 0000931763-03-000968 — 7, 9
- 1996-09-12 0000931763-96-000667 — 5, 7

## late-filing notifications on or before 2016-02-24

- none on or before 2016-02-24

## item 2.02 — earnings release, exhibit 99.1

[0001193125-16-432934:8k_2_02:1]
EX-99.1
2
d123232dex991.htm
EX-99.1

[0001193125-16-432934:8k_2_02:2]
EX-99.1

[0001193125-16-432934:8k_2_02:3]
EXHIBIT 99.1

[0001193125-16-432934:8k_2_02:4]
ADTRAN, INC.

[0001193125-16-432934:8k_2_02:5]
REPORTS RESULTS for the FOURTH QUARTER 2015 and DECLARES QUARTERLY CASH DIVIDEND

[0001193125-16-432934:8k_2_02:6]
HUNTSVILLE, Ala.—(BUSINESS WIRE)—January 19, 2016—ADTRAN, Inc. (NASDAQ:ADTN) reported results for the fourth quarter 2015. For the quarter,
sales were $139,013,000 compared to $143,982,000 for the fourth quarter of 2014. Net income was $5,718,000 compared to $9,292,000 for the fourth quarter of 2014. Earnings per share, assuming dilution, were $0.12 compared to $0.17 for the fourth
quarter of 2014. Non-GAAP earnings per share were $0.16 compared to $0.19 for the fourth quarter of 2014. The reconciliation between GAAP earnings per share, diluted, and non-GAAP earnings per share, diluted, is in the table provided.

[0001193125-16-432934:8k_2_02:7]
ADTRAN Chief Executive Officer Tom Stanton stated, “Revenue in the quarter came in better than expected, driven by growth in our U.S. Tier 1 and Tier 2
carrier business. Compared to the same period last year, Q4 domestic revenue was up over 20% due to a significant increase in our broadband sales. Additionally, improved gross margins and lower operating expenses helped us achieve better than
expected operating income. We expect further improvement in the carrier environment as customers accelerate investments in upgrading their network infrastructure.”

[0001193125-16-432934:8k_2_02:8]
The Company also announced that its Board of Directors declared a cash dividend for the fourth quarter of 2015. The quarterly cash dividend is $0.09 per
common share to be paid to holders of record at the close of business on February 4, 2016. The ex-dividend date is February 2, 2016 and the payment date is February 18, 2016.

[0001193125-16-432934:8k_2_02:9]
The Company confirmed that its fourth quarter conference call will be held Wednesday, January 20, 2016 at 9:30 a.m. Central Time. This conference call
will be web cast live through StreetEvents.com. To listen, simply visit the Investor Relations site at www.adtran.com or www.streetevents.com approximately 10 minutes prior to the start of the call and click on the conference call link
provided.

[0001193125-16-432934:8k_2_02:10]
An online replay of the conference call will be available for seven days at www.streetevents.com. In addition, an online replay of the
conference call, as well as the text of the Company’s earnings release, will be available on the Investor Relations site at www.adtran.com for at least 12 months following the call.

[0001193125-16-432934:8k_2_02:11]
ADTRAN, Inc. is a leading global provider of networking and communications equipment. ADTRAN’s products enable voice, data, video and Internet
communications across a variety of network infrastructures. ADTRAN solutions are currently in use by service providers, private enterprises, government organizations, and millions of individual users worldwide. For more information, please visit
www.adtran.com.

[0001193125-16-432934:8k_2_02:12]
For more information, contact the company at 800 9ADTRAN (800 923-8726) or via email at info@adtran.com. On the Web, visit
www.adtran.com.

[0001193125-16-432934:8k_2_02:13]
This press release contains forward-looking statements which reflect management’s best judgment based on factors currently
known. However, these statements involve risks and uncertainties, including the successful development and market acceptance of new products, the degree of competition in the market for such products, the product and channel mix, component costs,
manufacturing efficiencies, and other risks detailed in our annual report on Form 10-K for the year ended December 31, 2014 and on Form 10-Q for the quarter ended September 30, 2015. These risks and uncertainties could cause actual results
to differ materially from those in the forward-looking statements included in this press release.

[0001193125-16-432934:8k_2_02:14]
| CONTACT: Roger Shannon Senior Vice President & CFO 256-963-8775 |  | INVESTOR SERVICES/ASSISTANCE: Gayle Ellis Investor Services 256-963-8220 |

[0001193125-16-432934:8k_2_02:15]
Condensed Consolidated Balance Sheet

[0001193125-16-432934:8k_2_02:16]
(Unaudited)

[0001193125-16-432934:8k_2_02:17]
(In
thousands)

[0001193125-16-432934:8k_2_02:18]
|  |  | December 31,2015 |  |  | December 31,2014 |  |
| Assets |  |  |  |  |  |  |  |  |
| Cash and cash equivalents |  | $ | 84,550 |  |  | $ | 73,439 |  |
| Short-term investments |  |  | 34,396 |  |  |  | 46,919 |  |
| Accounts receivable, net |  |  | 71,917 |  |  |  | 88,502 |  |
| Other receivables |  |  | 19,321 |  |  |  | 33,295 |  |
| Inventory |  |  | 96,735 |  |  |  | 86,710 |  |
| Prepaid expenses |  |  | 4,943 |  |  |  | 5,129 |  |
| Deferred tax assets, net |  |  | 18,924 |  |  |  | 17,095 |  |
| Total Current Assets |  |  | 330,786 |  |  |  | 351,089 |  |
| Property, plant and equipment, net |  |  | 73,233 |  |  |  | 74,828 |  |
| Deferred tax assets, net |  |  | 18,091 |  |  |  | 17,694 |  |
| Goodwill |  |  | 3,492 |  |  |  | 3,492 |  |
| Other assets |  |  | 9,276 |  |  |  | 10,942 |  |
| Long-term investments |  |  | 198,026 |  |  |  | 280,649 |  |
| Total Assets |  | $ | 632,904 |  |  | $ | 738,694 |  |
| Liabilities and Stockholders’ Equity |  |  |  |  |  |  |  |  |
| Accounts payable |  | $ | 48,668 |  |  | $ | 56,414 |  |
| Unearned revenue |  |  | 16,615 |  |  |  | 22,762 |  |
| Accrued expenses |  |  | 12,108 |  |  |  | 11,077 |  |
| Accrued wages and benefits |  |  | 12,857 |  |  |  | 13,855 |  |
| Income tax payable, net |  |  | 2,395 |  |  |  | 14,901 |  |
| Total Current Liabilities |  |  | 92,643 |  |  |  | 119,009 |  |
| Non-current unearned revenue |  |  | 7,965 |  |  |  | 10,948 |  |
| Other non-current liabilities |  |  | 24,236 |  |  |  | 30,924 |  |
| Bonds payable |  |  | 27,900 |  |  |  | 28,800 |  |
| Total Liabilities |  |  | 152,744 |  |  |  | 189,681 |  |
| Stockholders’ Equity |  |  | 480,160 |  |  |  | 549,013 |  |
| Total Liabilities and Stockholders’ Equity |  | $ | 632,904 |  |  | $ | 738,694 |  |

[0001193125-16-432934:8k_2_02:19]
Consolidated Statements of Income

[0001193125-16-432934:8k_2_02:20]
(Unaudited)

[0001193125-16-432934:8k_2_02:21]
(In
thousands, except per share data)

[0001193125-16-432934:8k_2_02:22]
|  |  | Three Months EndedDecember 31, |  |  | Twelve Months EndedDecember 31, |  |
|  |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Sales |  | $ | 139,013 |  |  | $ | 143,982 |  |  | $ | 600,064 |  |  | $ | 630,007 |  |
| Cost of sales |  |  | 76,574 |  |  |  | 75,499 |  |  |  | 333,167 |  |  |  | 318,680 |  |
| Gross Profit |  |  | 62,439 |  |  |  | 68,483 |  |  |  | 266,897 |  |  |  | 311,327 |  |
| Selling, general and administrative expenses |  |  | 30,339 |  |  |  | 31,793 |  |  |  | 123,542 |  |  |  | 131,958 |  |
| Research and development expenses |  |  | 29,300 |  |  |  | 32,711 |  |  |  | 129,876 |  |  |  | 132,258 |  |
| Operating Income |  |  | 2,800 |  |  |  | 3,979 |  |  |  | 13,479 |  |  |  | 47,111 |  |
| Interest and dividend income |  |  | 1,273 |  |  |  | 1,679 |  |  |  | 3,953 |  |  |  | 5,019 |  |
| Interest expense |  |  | (148 | ) |  |  | (152 | ) |  |  | (596 | ) |  |  | (677 | ) |
| Net realized investment gain |  |  | 1,907 |  |  |  | 59 |  |  |  | 10,337 |  |  |  | 7,278 |  |
| Other income (expense), net (1) |  |  | (617 | ) |  |  | 2,790 |  |  |  | (1,465 | ) |  |  | 1,175 |  |
| Income before provision for income taxes |  |  | 5,215 |  |  |  | 8,355 |  |  |  | 25,708 |  |  |  | 59,906 |  |
| Provision for income taxes |  |  | 503 |  |  |  | 937 |  |  |  | (7,062 | ) |  |  | (15,286 | ) |
| Net Income |  | $ | 5,718 |  |  | $ | 9,292 |  |  | $ | 18,646 |  |  | $ | 44,620 |  |
| Weighted average shares outstanding—basic |  |  | 49,552 |  |  |  | 53,835 |  |  |  | 51,145 |  |  |  | 55,120 |  |
| Weighted average shares outstanding—diluted (2) |  |  | 49,643 |  |  |  | 54,085 |  |  |  | 51,267 |  |  |  | 55,482 |  |
| Earnings per common share—basic |  | $ | 0.12 |  |  | $ | 0.17 |  |  | $ | 0.36 |  |  | $ | 0.81 |  |
| Earnings per common share—diluted (2) |  | $ | 0.12 |  |  | $ | 0.17 |  |  | $ | 0.36 |  |  | $ | 0.80 |  |

[0001193125-16-432934:8k_2_02:23]
| (1) | Results for the three and twelve months ended December 31, 2014 include a $2.4 million gain related to the settlement of working capital items from an acquisition that closed in 2012. |

[0001193125-16-432934:8k_2_02:24]
| (2) | Assumes exercise of dilutive stock options calculated under the treasury stock method. |

[0001193125-16-432934:8k_2_02:25]
Consolidated Statements of Comprehensive Income

[0001193125-16-432934:8k_2_02:26]
(Unaudited)

[0001193125-16-432934:8k_2_02:27]
(In
thousands)

[0001193125-16-432934:8k_2_02:28]
|  |  | Three Months Ended |  |  | Twelve Months Ended |  |
|  |  | December 31, |  |  | December 31, |  |
|  |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Net Income |  | $ | 5,718 |  |  | $ | 9,292 |  |  | $ | 18,646 |  |  | $ | 44,620 |  |
| Other Comprehensive Income (Loss), net of tax: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Unrealized gains (losses) on available-for-sale securities |  |  | (455 | ) |  |  | 1,077 |  |  |  | (7,032 | ) |  |  | (1,773 | ) |
| Defined benefit plan adjustments |  |  | 1,651 |  |  |  | (4,866 | ) |  |  | 1,862 |  |  |  | (4,866 | ) |
| Foreign currency translation |  |  | 73 |  |  |  | (2,007 | ) |  |  | (3,724 | ) |  |  | (4,189 | ) |
| Other Comprehensive Income (Loss), net of tax |  |  | 1,269 |  |  |  | (5,796 | ) |  |  | (8,894 | ) |  |  | (10,828 | ) |
| Comprehensive Income, net of tax |  | $ | 6,987 |  |  | $ | 3,496 |  |  | $ | 9,752 |  |  | $ | 33,792 |  |

[0001193125-16-432934:8k_2_02:29]
Consolidated Statements of Cash Flows

[0001193125-16-432934:8k_2_02:30]
(Unaudited)

[0001193125-16-432934:8k_2_02:31]
(In
thousands)

[0001193125-16-432934:8k_2_02:32]
|  |  | Twelve Months EndedDecember 31, |  |
|  |  | 2015 |  |  | 2014 |  |
| Cash flows from operating activities: |  |  |  |  |  |  |  |  |
| Net income |  | $ | 18,646 |  |  | $ | 44,620 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |  |  |  |  |
| Depreciation and amortization |  |  | 14,245 |  |  |  | 14,845 |  |
| Amortization of net premium on available-for-sale investments |  |  | 2,402 |  |  |  | 4,360 |  |
| Net realized gain on long-term investments |  |  | (10,336 | ) |  |  | (7,278 | ) |
| Net loss on disposal of property, plant and equipment |  |  | 644 |  |  |  | 142 |  |
| Stock-based compensation expense |  |  | 6,712 |  |  |  | 8,563 |  |
| Deferred income taxes |  |  | (692 | ) |  |  | (5,526 | ) |
| Tax impact from stock option exercises |  |  | (40 | ) |  |  | 81 |  |
| Excess tax benefits from stock-based compensation arrangements |  |  | (3 | ) |  |  | (63 | ) |
| Change in operating assets and liabilities: |  |  |  |  |  |  |  |  |
| Accounts receivable, net |  |  | 14,918 |  |  |  | (3,910 | ) |
| Other receivables |  |  | 11,704 |  |  |  | (19,298 | ) |
| Inventory |  |  | (11,323 | ) |  |  | 1,953 |  |
| Prepaid expenses and other assets |  |  | (625 | ) |  |  | (3,627 | ) |
| Accounts payable |  |  | (5,826 | ) |  |  | 9,973 |  |
| Accrued expenses and other liabilities |  |  | (10,289 | ) |  |  | (166 | ) |
| Income tax payable, net |  |  | (11,590 | ) |  |  | 11,168 |  |
| Net cash provided by operating activities |  |  | 18,547 |  |  |  | 55,837 |  |
| Cash flows from investing activities: |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (11,753 | ) |  |  | (11,256 | ) |
| Proceeds from disposals of property, plant and equipment |  |  | 183 |  |  |  | 1 |  |
| Proceeds from sales and maturities of available-for-sale investments |  |  | 280,435 |  |  |  | 230,019 |  |
| Purchases of available-for-sale investments |  |  | (188,921 | ) |  |  | (142,695 | ) |
| Net cash provided by investing activities |  |  | 79,944 |  |  |  | 76,069 |  |
| Cash flows from financing activities: |  |  |  |  |  |  |  |  |
| Proceeds from stock option exercises |  |  | 961 |  |  |  | 2,839 |  |
| Purchases of treasury stock |  |  | (66,160 | ) |  |  | (80,576 | ) |
| Dividend payments |  |  | (18,449 | ) |  |  | (19,947 | ) |
| Payments on long-term debt |  |  | (1,100 | ) |  |  | (16,500 | ) |
| Excess tax benefits from stock-based compensation arrangements |  |  | 3 |  |  |  | 63 |  |
| Net cash used in financing activities |  |  | (84,745 | ) |  |  | (114,121 | ) |
| Net increase in cash and cash equivalents |  |  | 13,746 |  |  |  | 17,785 |  |
| Effect of exchange rate changes |  |  | (2,635 | ) |  |  | (2,644 | ) |
| Cash and cash equivalents, beginning of period |  |  | 73,439 |  |  |  | 58,298 |  |
| Cash and cash equivalents, end of period |  | $ | 84,550 |  |  | $ | 73,439 |  |
| Supplemental disclosure of non-cash investing activities |  |  |  |  |  |  |  |  |
| Purchases of property, plant and equipment included in accounts payable |  | $ | 598 |  |  | $ | 467 |  |

[0001193125-16-432934:8k_2_02:33]
Supplemental Information

[0001193125-16-432934:8k_2_02:34]
Restructuring Expenses

[0001193125-16-432934:8k_2_02:35]
(Unaudited)

[0001193125-16-432934:8k_2_02:36]
(In
thousands)

[0001193125-16-432934:8k_2_02:37]
Restructuring expenses were recorded in the following Consolidated Statements of Income categories for the three and twelve months ended
December 31, 2015 and 2014:

[0001193125-16-432934:8k_2_02:38]
|  |  | Three Months EndedDecember 31, |  |  | Twelve Months EndedDecember 31, |  |
|  |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Restructuring expense included in cost of sales |  | $ | 5 |  |  | $ | — |  |  | $ | 112 |  |  | $ | — |  |
| Selling, general and administrative expense |  |  | 8 |  |  |  | — |  |  |  | 846 |  |  |  | — |  |
| Research and development expense |  |  | 13 |  |  |  | — |  |  |  | 2,108 |  |  |  | — |  |
| Restructuring expense included in operating expenses |  |  | 21 |  |  |  | — |  |  |  | 2,954 |  |  |  | — |  |
| Total restructuring expense |  |  | 26 |  |  |  | — |  |  |  | 3,066 |  |  |  | — |  |
| Provision for income taxes |  |  | (10 | ) |  |  | — |  |  |  | (1,196 | ) |  |  | — |  |
| Total restructuring expense, net of tax |  | $ | 16 |  |  | $ | — |  |  | $ | 1,870 |  |  | $ | — |  |

[0001193125-16-432934:8k_2_02:39]
Supplemental Information

[0001193125-16-432934:8k_2_02:40]
Acquisition Related Expenses, Amortizations and Adjustments

[0001193125-16-432934:8k_2_02:41]
(Unaudited)

[0001193125-16-432934:8k_2_02:42]
(In
thousands)

[0001193125-16-432934:8k_2_02:43]
On August 4, 2011, we closed on the acquisition of Bluesocket, Inc. and on May 4, 2012, we closed on the acquisition of the
Nokia Siemens Networks Broadband Access business (NSN BBA). Acquisition related expenses, amortizations and adjustments for the three and twelve months ended December 31, 2015 and 2014 for both transactions are as follows:

[0001193125-16-432934:8k_2_02:44]
|  |  | Three MonthsEnded |  |  | Twelve MonthsEnded |  |
|  |  | December 31, |  |  | December 31, |  |
|  |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Bluesocket, Inc. acquisition |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets and other purchase accounting adjustments |  | $ | 174 |  |  | $ | 226 |  |  | $ | 817 |  |  | $ | 925 |  |
| NSN BBA acquisition |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Amortization of acquired intangible assets |  |  | 227 |  |  |  | 269 |  |  |  | 928 |  |  |  | 1,153 |  |
| Amortization of other purchase accounting adjustments |  |  | 48 |  |  |  | 222 |  |  |  | 443 |  |  |  | 1,117 |  |
| Acquisition related professional fees, travel and other expenses |  |  | 14 |  |  |  | 193 |  |  |  | 75 |  |  |  | 282 |  |
| Subtotal |  |  | 289 |  |  |  | 684 |  |  |  | 1,446 |  |  |  | 2,552 |  |
| Total acquisition related expenses, amortizations and adjustments |  |  | 463 |  |  |  | 910 |  |  |  | 2,263 |  |  |  | 3,477 |  |
| Provision for income taxes |  |  | (158 | ) |  |  | (300 | ) |  |  | (767 | ) |  |  | (1,151 | ) |
| Total acquisition related expenses, amortizations and adjustments, net of tax |  | $ | 305 |  |  | $ | 610 |  |  | $ | 1,496 |  |  | $ | 2,326 |  |

[0001193125-16-432934:8k_2_02:45]
The acquisition related expenses, amortizations and adjustments above were recorded in the following Consolidated Statements
of Income categories for the three and twelve months ended December 31, 2015 and 2014:

[0001193125-16-432934:8k_2_02:46]
|  |  | Three MonthsEnded |  |  | Twelve MonthsEnded |  |
|  |  | December 31, |  |  | December 31, |  |
|  |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Revenue (adjustments to deferred revenue recognized in the period) |  | $ | 16 |  |  | $ | 73 |  |  | $ | 212 |  |  | $ | 601 |  |
| Cost of goods sold |  |  | 3 |  |  |  | 67 |  |  |  | 55 |  |  |  | 171 |  |
| Subtotal |  |  | 19 |  |  |  | 140 |  |  |  | 267 |  |  |  | 772 |  |
| Selling, general and administrative expenses |  |  | 18 |  |  |  | 200 |  |  |  | 92 |  |  |  | 310 |  |
| Research and development expenses |  |  | 426 |  |  |  | 570 |  |  |  | 1,904 |  |  |  | 2,395 |  |
| Subtotal |  |  | 444 |  |  |  | 770 |  |  |  | 1,996 |  |  |  | 2,705 |  |
| Total acquisition related expenses, amortizations and adjustments |  |  | 463 |  |  |  | 910 |  |  |  | 2,263 |  |  |  | 3,477 |  |
| Provision for income taxes |  |  | (158 | ) |  |  | (300 | ) |  |  | (767 | ) |  |  | (1,151 | ) |
| Total acquisition related expenses, amortizations and adjustments, net of tax |  | $ | 305 |  |  | $ | 610 |  |  | $ | 1,496 |  |  | $ | 2,326 |  |

[0001193125-16-432934:8k_2_02:47]
Supplemental Information

[0001193125-16-432934:8k_2_02:48]
Stock-based Compensation Expense

[0001193125-16-432934:8k_2_02:49]
(Unaudited)

[0001193125-16-432934:8k_2_02:50]
(In
thousands)

[0001193125-16-432934:8k_2_02:51]
|  |  | Three Months EndedDecember 31, |  |  | Twelve Months EndedDecember 31, |  |
|  |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Stock-based compensation expense included in cost of sales |  | $ | 78 |  |  | $ | 120 |  |  | $ | 280 |  |  | $ | 479 |  |
| Selling, general and administrative expense |  |  | 1,035 |  |  |  | 1,096 |  |  |  | 3,261 |  |  |  | 4,185 |  |
| Research and development expense |  |  | 811 |  |  |  | 1,051 |  |  |  | 3,171 |  |  |  | 3,899 |  |
| Stock-based compensation expense included in operating expenses |  |  | 1,846 |  |  |  | 2,147 |  |  |  | 6,432 |  |  |  | 8,084 |  |
| Total stock-based compensation expense |  |  | 1,924 |  |  |  | 2,267 |  |  |  | 6,712 |  |  |  | 8,563 |  |
| Tax benefit for expense associated with non-qualified options |  |  | (242 | ) |  |  | (279 | ) |  |  | (862 | ) |  |  | (1,157 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 1,682 |  |  | $ | 1,988 |  |  | $ | 5,850 |  |  | $ | 7,406 |  |

[0001193125-16-432934:8k_2_02:52]
Reconciliation of GAAP net income per share, diluted, to

[0001193125-16-432934:8k_2_02:53]
Non-GAAP net income per share, diluted

[0001193125-16-432934:8k_2_02:54]
(Unaudited)

[0001193125-16-432934:8k_2_02:55]
|  |  | Three Months EndedDecember 31, |  |  | Twelve Months EndedDecember 31, |  |
|  |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| GAAP earnings per common share – diluted |  | $ | 0.12 |  |  | $ | 0.17 |  |  | $ | 0.36 |  |  | $ | 0.80 |  |
| Restructuring expense |  |  | — |  |  |  | — |  |  |  | 0.04 |  |  |  | — |  |
| Acquisition related expenses, amortizations and adjustments |  |  | 0.01 |  |  |  | 0.01 |  |  |  | 0.03 |  |  |  | 0.04 |  |
| Settlement of acquisition related working capital items |  |  | — |  |  |  | (0.03 | ) |  |  | — |  |  |  | (0.03 | ) |
| Stock-based compensation expense |  |  | 0.03 |  |  |  | 0.04 |  |  |  | 0.11 |  |  |  | 0.13 |  |
| Non-GAAP earnings per common share – diluted |  | $ | 0.16 |  |  | $ | 0.19 |  |  | $ | 0.54 |  |  | $ | 0.94 |  |
