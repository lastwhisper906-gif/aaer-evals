# ADTN MD&A — 0001193125-16-475816


## mdna

[0001193125-16-475816:mdna:1]
| ITEM 7. | MANAGEMENT’S DISCUSSION AND ANALYSIS OF FINANCIAL CONDITION AND RESULTS OF OPERATIONS |

[0001193125-16-475816:mdna:2]
Overview

[0001193125-16-475816:mdna:3]
ADTRAN, Inc. is a leading global provider of networking and communications equipment. Our solutions enable voice, data, video and Internet communications
across a variety of network infrastructures. These solutions are deployed by many of the United States’ and the world’s largest SPs, distributed enterprises and small and medium-sized businesses, public and private enterprises, and
millions of individual users worldwide.

[0001193125-16-475816:mdna:4]
Our success depends upon our ability to increase unit volume and market share through the introduction of new
products and succeeding generations of products having lower selling prices and increased functionality as compared to both the prior generation of a product and to the products of competitors. An important part of our strategy is to reduce the cost
of each succeeding product generation and then lower the product’s selling price based on the cost savings achieved in order to gain market share and/or improve gross margins. As a part of this strategy, we seek in most instances to be a
high-quality, low-cost provider of products in our markets. Our success to date is attributable in large measure to our ability to design our products initially with a view to their subsequent redesign, allowing both increased functionality and
reduced manufacturing costs in each succeeding product generation. This strategy enables us to sell succeeding generations of products to existing customers, while increasing our market share by selling these enhanced products to new customers.

[0001193125-16-475816:mdna:5]
Our three major product categories are Carrier Systems, Business Networking and Loop Access.

[0001193125-16-475816:mdna:6]
Carrier Systems products are used by communications SPs to provide data, voice, and video services to consumers and enterprises. This category includes
the following product areas and related services:

[0001193125-16-475816:mdna:7]
|  | • |  | Broadband Access |

[0001193125-16-475816:mdna:8]
|  | • |  | Total Access 5000 Series of Multi-Service Access Node (MSANs) |

[0001193125-16-475816:mdna:9]
|  | • |  | hiX 5600 Series of MSANs |

[0001193125-16-475816:mdna:10]
|  | • |  | Total Access 1100/1200 Series of Fiber to the Node (FTTN) products |

[0001193125-16-475816:mdna:11]
|  | • |  | hiX 1100 Series of FTTN products |

[0001193125-16-475816:mdna:12]
|  | • |  | VDSL2 Vectoring based Digital Subscriber Line Access Multiplexer (DSLAM) products |

[0001193125-16-475816:mdna:13]
|  | • |  | ADTRAN 500 Series of FTTdp G.fast Distribution Point Units (DPU) |

[0001193125-16-475816:mdna:14]
|  | • |  | Optical |

[0001193125-16-475816:mdna:15]
|  | • |  | Optical Networking Edge (ONE) |

[0001193125-16-475816:mdna:16]
|  | • |  | NetVanta 8000 Series of Fiber Ethernet Access Devices (EAD) |

[0001193125-16-475816:mdna:17]
|  | • |  | NetVanta 8400 Series of 10Gig Multi-service Edge Switches |

[0001193125-16-475816:mdna:18]
|  | • |  | OPTI-6100 and Total Access 3000 optical Multi-Service Provisioning Platforms (MSPP) |

[0001193125-16-475816:mdna:19]
|  | • |  | Pluggable Optical Products, including Small Form Factor Pluggable (SFP), 10-Gigabit Fiber Small Form Factor Pluggable (XFP), and SFP+ |

[0001193125-16-475816:mdna:20]
|  | • |  | Time Division Multiplexed (TDM) systems |

[0001193125-16-475816:mdna:21]
Business Networking products provide access to communication
services and facilitate the delivery of cloud connectivity and enterprise communications to the small and mid-sized enterprise (SME) market. This category includes the following product areas and related services:

[0001193125-16-475816:mdna:22]
|  | • |  | Internetworking products |

[0001193125-16-475816:mdna:23]
|  | • |  | Total Access IP Business Gateways |

[0001193125-16-475816:mdna:24]
|  | • |  | Optical Network Terminals (ONTs) |

[0001193125-16-475816:mdna:25]
|  | • |  | Bluesocket virtual Wireless LAN (vWLAN) |

[0001193125-16-475816:mdna:26]
|  | • |  | NetVanta |

[0001193125-16-475816:mdna:27]
|  | • |  | Access Routers |

[0001193125-16-475816:mdna:28]
|  | • |  | Enterprise Session Border Controllers (eSBC) |

[0001193125-16-475816:mdna:29]
|  | • |  | Managed Ethernet Switches |

[0001193125-16-475816:mdna:30]
|  | • |  | IP Business Gateways |

[0001193125-16-475816:mdna:31]
|  | • |  | Unified Communications (UC) solutions |

[0001193125-16-475816:mdna:32]
|  | • |  | Carrier Ethernet Network Termination Equipment (NTE) |

[0001193125-16-475816:mdna:33]
|  | • |  | Carrier Ethernet Routers and Gateways |

[0001193125-16-475816:mdna:34]
|  | • |  | Network Management Solutions |

[0001193125-16-475816:mdna:35]
Loop Access products are used by carrier and enterprise customers for access to copper-based
communications networks. This category includes the following product areas and related services:

[0001193125-16-475816:mdna:36]
|  | • |  | High bit-rate Digital Subscriber Line (HDSL) products |

[0001193125-16-475816:mdna:37]
|  | • |  | Digital Data Service (DDS) |

[0001193125-16-475816:mdna:38]
|  | • |  | Integrated Services Digital Network (ISDN) products |

[0001193125-16-475816:mdna:39]
In addition, we identify subcategories of product
revenues, which we divide into Core products and Legacy products. Our Core products consist of Broadband Access and Optical products (included in Carrier Systems) and Internetworking products (included in Business Networking). Our Legacy products
include HDSL products (included in Loop Access) and other products not included in the aforementioned Core products. Many of our customers are migrating their networks to deliver higher bandwidth services by utilizing newer technologies. We believe
that products and services offered in our core product areas position us well for this migration. Despite occasional increases, we anticipate that revenues of many of our Legacy products, including HDSL, will decline over time; however, revenues
from these products may continue for years because of the time required for our customers to transition to newer technologies.

[0001193125-16-475816:mdna:40]
Sales were $600.1 million
in 2015 compared to $630.0 million in 2014 and $641.7 million in 2013. Total sales of products in our three core areas, Broadband Access, Optical and Internetworking, decreased 3.3% in 2015 compared to 2014 and increased 2.8% in 2014 compared to
2013. Our gross profit margin was 44.5% in 2015 compared to 49.4% in 2014 and 48.1% in 2013. Net income was $18.6 million in 2015 compared to $44.6 million in 2014 and $45.8 million in 2013. Earnings per share, assuming dilution, were $0.36 in 2015
compared to $0.80 in 2014 and $0.77 in 2013. Earnings per share in 2015, 2014 and 2013 include the effect of the repurchase of 4.0 million, 3.7 million and 5.6 million shares of our stock in those years, respectively.

[0001193125-16-475816:mdna:41]
Our operating results have fluctuated on a quarterly basis in the past, and may vary significantly in future periods due to a number of factors, including
customer order activity and backlog. Backlog levels vary because of seasonal trends, the timing of customer projects and other factors that affect customer order lead times. Many of our customers require prompt delivery of products. This requires us
to maintain sufficient inventory levels to satisfy anticipated customer demand. If near-term demand for our products declines, or if potential sales in any quarter do not occur as anticipated, our financial results could be adversely affected.
Operating expenses are relatively fixed in the short term; therefore, a shortfall in quarterly revenues could significantly impact our financial results in a given quarter.

[0001193125-16-475816:mdna:42]
Our operating results may also fluctuate as a result of a number of other factors, including a decline in general economic and market conditions, increased
competition, customer order patterns, changes in product and services mix, foreign currency exchange rate movements, timing differences between price decreases and product cost reductions, product warranty returns, expediting costs, and
announcements of new products by us or our competitors. Additionally, maintaining sufficient inventory levels to assure prompt delivery of our products increases the amount of inventory that may become obsolete and increases the risk that the
obsolescence of this inventory may have an adverse effect on our business and operating results. Also, not maintaining sufficient inventory levels to assure prompt delivery of our products may cause us to incur expediting costs to meet customer
delivery requirements, which may negatively impact our operating results in a given quarter.

[0001193125-16-475816:mdna:43]
Accordingly, our historical financial performance is
not necessarily a meaningful indicator of future results, and, in general, management expects that our financial results may vary from period to period. See Note 14 of Notes to Consolidated Financial Statements for additional information. For a
discussion of risks associated with our operating results, see Item 1A of this report.

[0001193125-16-475816:mdna:44]
Critical Accounting Policies and Estimates

[0001193125-16-475816:mdna:45]
An accounting policy is deemed to be critical if it requires an accounting estimate to be made based on assumptions about matters that are highly uncertain at
the time the estimate is made, if different estimates reasonably could have been used, or if changes in the accounting estimate that are reasonably likely to occur could materially impact the results of financial operations. We believe the following
critical accounting policies affect our more significant judgments and estimates used in the preparation of our consolidated financial statements. These policies have been consistently applied across our two reportable segments: (1) Carrier
Networks Division and (2) Enterprise Networks Division.

[0001193125-16-475816:mdna:46]
|  | • |  | Revenue is generally recognized when persuasive evidence of an arrangement exists, delivery has occurred, the product price is fixed or determinable, collection of the resulting receivable is reasonably assured, and product returns are reasonably estimable. For product sales, revenue is generally recognized upon shipment of the product to our customer in accordance with the title transfer terms of the sales agreement, generally Ex Works, per International Commercial Terms. In the case of consigned inventory, revenue is recognized when the end customer assumes ownership of the product. Contracts that contain multiple deliverables are evaluated to determine the units of accounting, and the consideration from the arrangement is allocated to each unit of accounting based on the relative selling price and corresponding terms of the contract. We use vendor-specific objective evidence of selling price. When this evidence is not available, we are generally not able to determine third-party evidence of selling price because of the extent of customization among competing products or services from other companies. In these instances, we use best estimates to allocate consideration to each respective unit of accounting. These estimates include analysis of respective bills of material and review and analysis of similar product and service offerings. We record revenue associated with installation services when respective contractual obligations are complete. In instances where customer acceptance is required, revenue is deferred until respective acceptance criteria have been met. Contracts that include both installation services and product sales are evaluated for revenue recognition in accordance with contract terms. As a result, installation services may be considered a separate deliverable or may be considered a combined single unit of accounting with the delivered product. Generally, either the purchaser, ADTRAN, or a third party can perform the installation of our products. Sales taxes invoiced to customers are included in revenue, and represent less than one percent of total revenues. The corresponding sales taxes paid are included in cost of goods sold. Value added taxes collected from customers in international jurisdictions are recorded in accrued expenses as a liability. Revenue is recorded net of discounts. Sales returns are accrued based on historical sales return experience, which we believe provides a reasonable estimate of future returns. |

[0001193125-16-475816:mdna:47]
A significant portion of Enterprise Networks products are sold in
the United States through a non-exclusive distribution network of major technology distributors. These organizations then distribute or provide fulfillment services to an extensive network of VARs and SIs. VARs and SIs may be affiliated with us as a
channel partner, or they may purchase from the distributor on an unaffiliated basis. Additionally, with certain limitations, our distributors may return unused and unopened product for stock-balancing purposes when these returns are accompanied by
offsetting orders for products of equal or greater value.

[0001193125-16-475816:mdna:48]
|  | • |  | We carry our inventory at the lower of cost or market, with cost being determined using the first-in, first-out method. We use standard costs for material, labor, and manufacturing overhead to value our inventory. Our standard costs are updated on at least a quarterly basis and any variances are expensed in the current period; therefore, our inventory costs approximate actual costs at the end of each reporting period. We write down our inventory for estimated obsolescence or unmarketable inventory by an amount equal to the difference between the cost of inventory and the estimated fair value based upon assumptions about future demand and market conditions. If actual future demand or market conditions are less favorable than those projected by management, we may be required to make additional inventory write-downs. Our reserve for excess and obsolete inventory was $26.7 million and $24.7 million at December 31, 2015 and 2014, respectively. Inventory disposals charged against the reserve were $0.2 million, $2.1 million and $0.4 million for the years ended December 31, 2015, 2014 and 2013, respectively. |

[0001193125-16-475816:mdna:49]
31

[0001193125-16-475816:mdna:50]
|  | • |  | For purposes of determining the estimated fair value of our stock option awards on the date of grant, we use the Black-Scholes Model. This model requires the input of certain assumptions that require subjective judgment. These assumptions include, but are not limited to, expected stock price volatility over the term of the awards and actual and projected employee stock option exercise behaviors. Because our stock option awards have characteristics significantly different from those of traded options, and because changes in the input assumptions can materially affect the fair value estimate, the existing model may not provide a reliable, single measure of the fair value of our stock option awards. For purposes of determining the estimated fair value of our performance-based restricted stock unit (RSU) awards on the date of grant, we use a Monte Carlo Simulation valuation method. The RSUs are subject to a market condition based on the relative total shareholder return of ADTRAN against all of the companies in the NASDAQ Telecommunications Index and vest at the end of a three-year performance period. The fair value of restricted stock issued to our Directors is equal to the closing price of our stock on the date of grant. Management will continue to assess the assumptions and methodologies used to calculate the estimated fair value of stock-based compensation. Circumstances may change and additional data may become available over time, which could result in changes to these assumptions and methodologies and thereby materially impact our fair value determination. If factors change in future periods, the compensation expense that we record may differ significantly from what we have recorded in the current period. |

[0001193125-16-475816:mdna:51]
|  | • |  | We estimate our income tax provision or benefit in each of the jurisdictions in which we operate, including estimating exposures related to examinations by taxing authorities. We also make judgments regarding the realization of deferred tax assets, and establish valuation allowances where we believe it is more likely than not that future taxable income in certain jurisdictions will be insufficient to realize these deferred tax assets. Our estimates regarding future taxable income and income tax provision or benefit may vary due to changes in market conditions, changes in tax laws, or other factors. If our assumptions, and consequently our estimates, change in the future, the valuation allowances we have established may be increased or decreased, impacting future income tax expense. At December 31, 2015 and 2014 respectively, the valuation allowance was $7.3 million and $7.5 million. As of December 31, 2015, we have state research tax credit carry-forwards of $4.2 million, which will expire between 2016 and 2030. These carry-forwards were caused by tax credits in excess of our annual tax liabilities to an individual state where we no longer generate sufficient state income. In addition, as of December 31, 2015, we have a deferred tax asset of $8.7 million relating to net operating loss carry-forwards which will expire between 2016 and 2030. These carry-forwards are the result of acquisitions in 2009 and in 2011. The acquired net operating losses are in excess of the amount of estimated earnings. We believe it is more likely than not that we will not realize the full benefits of our deferred tax asset arising from these credits and net operating losses, and accordingly, have provided a valuation allowance against them. This valuation allowance is included in non-current deferred tax liabilities in the accompanying balance sheets. |

[0001193125-16-475816:mdna:52]
We establish reserves to remove some or all of the tax benefit of any of our tax positions at the time we determine that the positions become
uncertain. We adjust these reserves, including any impact on the related interest and penalties, as facts and circumstances change.

[0001193125-16-475816:mdna:53]
|  | • |  | Our products generally include warranties of 90 days to ten years for product defects. We accrue for warranty returns at the time revenue is recognized based on our estimate of the cost to repair or replace the defective products. We engage in extensive product quality programs and processes, including actively monitoring and evaluating the quality of our component suppliers. Our products continue to become more complex in both size and functionality as many of our product offerings migrate from line card applications to total systems. The increasing complexity of our products will cause warranty incidences, when they arise, to be more costly. Our estimates regarding future warranty obligations may change due to product failure rates, material usage, and other rework costs incurred in correcting a product failure. In addition, from time to time, specific warranty accruals may be recorded if unforeseen problems arise. Should our actual experience relative to these factors be worse than our estimates, we will be required to record additional warranty expense. Alternatively, if we provide for more reserves than we require, we will reverse a portion of such provisions in future periods. The liability for warranty obligations totaled $8.7 million and $8.4 million at December 31, 2015 and 2014, respectively. These liabilities are included in accrued expenses in the accompanying consolidated balance sheets. |

[0001193125-16-475816:mdna:54]
|  | • |  | Pension benefit plan obligations are based on various assumptions used by our actuaries in calculating these amounts. These assumptions include discount rates, compensation rate increases, expected return on plan assets, retirement rates, and mortality rates. Actual results that differ from the assumptions and changes in assumptions could affect future expenses and obligations. Our net pension liability totaled $7.6 million and $10.2 million at December 31, 2015 and 2014, respectively. This liability is included in other non-current liabilities in the accompanying Consolidated Balance Sheets. |

[0001193125-16-475816:mdna:55]
|  | • |  | We evaluate the carrying value of goodwill during the fourth quarter of each year and between annual evaluations if events occur or circumstances change that would more likely than not reduce the fair value of the reporting unit below its carrying amount. When evaluating whether goodwill is impaired, we first assess qualitative factors to determine whether it is necessary to perform the two-step quantitative goodwill impairment test. If we determine that the two-step quantitative test is necessary, then we compare the fair value of the reporting unit to which the goodwill is assigned to the reporting unit’s carrying amount, including goodwill. If the carrying amount of the reporting unit exceeds its fair value, then the amount of the impairment loss is measured. Our assessment of relevant qualitative factors enabled us to confirm that the fair value of the reporting unit exceeded the carrying amount in 2015; therefore, we did not complete a quantitative assessment. As a result, there were no impairment losses recognized during 2015, 2014 or 2013. |

[0001193125-16-475816:mdna:56]
Results of Operations

[0001193125-16-475816:mdna:57]
The following table presents selected financial information derived from our consolidated statements of income expressed as a percentage of sales for
the years indicated.

[0001193125-16-475816:mdna:58]
| Year Ended December 31, |  | 2015 |  |  | 2014 |  |  | 2013 |  |
| Sales |  |  |  |  |  |  |  |  |  |  |  |  |
| Carrier Networks Division Enterprise Networks Division |  |  | 83.2 | % |  |  | 81.0 | % |  |  | 78.0 | % |
| Enterprise Networks Division |  |  | 16.8 |  |  |  | 19.0 |  |  |  | 22.0 |  |
| Total sales |  |  | 100.0 | % |  |  | 100.0 | % |  |  | 100.0 | % |
| Cost of sales |  |  | 55.5 |  |  |  | 50.6 |  |  |  | 51.9 |  |
| Gross profit |  |  | 44.5 |  |  |  | 49.4 |  |  |  | 48.1 |  |
| Selling, general and administrative expenses |  |  | 20.6 |  |  |  | 20.9 |  |  |  | 20.2 |  |
| Research and development expenses |  |  | 21.6 |  |  |  | 21.0 |  |  |  | 20.4 |  |
| Operating income |  |  | 2.2 |  |  |  | 7.5 |  |  |  | 7.6 |  |
| Interest and dividend income |  |  | 0.7 |  |  |  | 0.8 |  |  |  | 1.1 |  |
| Interest expense |  |  | (0.1 | ) |  |  | (0.1 | ) |  |  | (0.4 | ) |
| Net realized investment gain |  |  | 1.7 |  |  |  | 1.2 |  |  |  | 1.3 |  |
| Other income (expense), net |  |  | (0.2 | ) |  |  | 0.2 |  |  |  | (0.1 | ) |
| Income before provision for income taxes |  |  | 4.3 |  |  |  | 9.5 |  |  |  | 9.5 |  |
| Provision for income taxes |  |  | (1.2 | ) |  |  | (2.4 | ) |  |  | (2.3 | ) |
| Net income |  |  | 3.1 | % |  |  | 7.1 | % |  |  | 7.1 | % |

[0001193125-16-475816:mdna:59]
2015 Compared to 2014

[0001193125-16-475816:mdna:60]
Sales

[0001193125-16-475816:mdna:61]
Our sales decreased 4.8% from $630.0 million in
2014 to $600.1 million in 2015. The decrease in sales is primarily attributable to a $16.5 million decrease in sales of our Internetworking products, a $10.8 million decrease in sales of our HDSL and other legacy products, and a $3.9 million
decrease in sales of our Broadband Access products.

[0001193125-16-475816:mdna:62]
Carrier Networks sales decreased 2.1% from $510.4 million in 2014 to $499.4 million in 2015. The
decrease in sales is primarily attributable to decreases in sales of Broadband Access products and HDSL and other legacy products. The decrease in sales of our Broadband Access products is primarily attributable to decreased sales in the EMEA region
and the impact of the strengthening U.S. dollar against the Euro. The decreases in sales of HDSL and other legacy products in North America have been expected as customers continue to upgrade their networks to deliver higher bandwidth services by
migrating to newer technologies, including to our core products from our Broadband Access, Internetworking and Optical product lines. While we expect that revenues from HDSL and our other legacy products will continue to decline over time, these
revenues may continue for years because of the time required for our customers to transition to newer technologies.

[0001193125-16-475816:mdna:63]
Enterprise Networks sales decreased
15.9% from $119.6 million in 2014 to $100.7 million in 2015. The decrease is attributable to a decrease in sales of our Internetworking products. The decrease in sales of our Internetworking products for this division is primarily attributable to
weakness in sales of IP gateway products to the CLEC and MSO markets. Internetworking product sales attributable to Enterprise Networks were 93.8% and 93.6% of the division’s sales in 2015 and 2014. Legacy products primarily comprise the
remainder of Enterprise Networks sales. Enterprise Networks sales as a percentage of total sales decreased from 19.0% in 2014 to 16.8% in 2015.

[0001193125-16-475816:mdna:64]
International sales, which are included in the Carrier Networks and Enterprise Networks amounts discussed above,
decreased 27.3% from $248.6 million in 2014 to $180.7 million in 2015. International sales, as a percentage of total sales, decreased from 39.5% in 2014 to 30.1% in 2015. The decrease in international sales is primarily attributable to decreases in
sales in the EMEA region, Latin America, and the Asia-Pacific region.

[0001193125-16-475816:mdna:65]
Carrier Systems product sales decreased $9.3 million in 2015 compared to 2014
primarily due to a $3.9 million decrease in Broadband Access product sales and a $6.6 million decrease in legacy product sales. The decrease in Carrier Systems product sales is primarily attributable to the factors discussed above.

[0001193125-16-475816:mdna:66]
Business Networking product sales decreased $17.3 million in 2015 compared to 2014 primarily due to a $17.6 million decrease in Internetworking product sales
in the EN division, partially offset by a $1.1 million increase in Internetworking product sales in the CN division. The changes in sales of our Internetworking products in both of our divisions are primarily attributable to the factors discussed
above.

[0001193125-16-475816:mdna:67]
Loop Access product sales decreased $3.4 million in 2015 compared to 2014 primarily due to a $2.5 million decrease in HDSL product sales, which is
further discussed above.

[0001193125-16-475816:mdna:68]
Cost of Sales

[0001193125-16-475816:mdna:69]
As a
percentage of sales, cost of sales increased from 50.6% in 2014 to 55.5% in 2015. The increase is primarily attributable to the strengthening of the U.S. dollar against the Euro, growth in our service-related material sales in the U.S. market, and
customer and product mix.

[0001193125-16-475816:mdna:70]
Carrier Networks cost of sales increased from 52.3% of sales in 2014 to 58.1% of sales in 2015. The increase in Carrier
Networks cost of sales as a percentage of sales is primarily attributable to the strengthening of the U.S. dollar against the Euro, growth in our service-related material sales in the U.S. market, and customer and product mix.

[0001193125-16-475816:mdna:71]
Enterprise Networks cost of sales decreased from 43.1% of sales in 2014 to 42.8% of sales in 2015. The decrease in Enterprise Networks cost of sales as a
percentage of sales is primarily attributable to product to services mix.

[0001193125-16-475816:mdna:72]
An important part of our strategy is to reduce the product cost of each
succeeding product generation and then to lower the product’s price based on the cost savings achieved. This may cause variations in our gross profit percentage due to timing differences between the recognition of cost reductions and the
lowering of product selling prices.

[0001193125-16-475816:mdna:73]
Selling, General and Administrative Expenses

[0001193125-16-475816:mdna:74]
Selling, general and administrative expenses decreased 6.4% from $132.0 million in 2014 to $123.5 million in 2015. Selling, general and administrative expenses
include personnel costs for administration, finance, information systems, human resources, sales and marketing, and general management, as well as rent, utilities, legal and accounting expenses, bad debt expense, advertising, promotional material,
trade show expenses, and related travel costs. The decrease in selling, general and administrative expenses is primarily attributable to decreases in compensation expense, travel expense, and independent contractor expense, partially offset by an
increase in professional services and restructuring charges.

[0001193125-16-475816:mdna:75]
Selling, general and administrative expenses as a percentage of sales decreased from 20.9%
for the year ended December 31, 2014 to 20.6% for the year ended December 31, 2015. Selling, general and administrative expenses as a percentage of sales will generally fluctuate whenever there is a significant fluctuation in revenues for
the periods being compared.

[0001193125-16-475816:mdna:76]
Research and Development Expenses

[0001193125-16-475816:mdna:77]
Research and development expenses decreased 1.8% from $132.3 million in 2014 to $129.9 million in 2015. The decrease in research and development expenses is
primarily attributable to decreases in compensation expense and independent contractors, partially offset by an increase in engineering and testing expense and restructuring charges.

[0001193125-16-475816:mdna:78]
Research and development expenses as a percentage of sales increased from 21.0% for the year ended December 31, 2014 to 21.6% for the year ended
December 31, 2015. Research and development expenses as a percentage of sales will fluctuate whenever there are incremental product development activities or a significant fluctuation in revenues for the periods being compared.

[0001193125-16-475816:mdna:79]
We expect to continue to incur research and development expenses in connection with our new and existing products
and our expansion into international markets. We continually evaluate new product opportunities and engage in intensive research and product development efforts which provide for new product development, enhancement of existing products and product
cost reductions. We may incur significant research and development expenses prior to the receipt of revenues from a major new product group.

[0001193125-16-475816:mdna:80]
Interest
and Dividend Income

[0001193125-16-475816:mdna:81]
Interest and dividend income decreased from $5.0 million in 2014 to $4.0 million in 2015. The decrease in interest and dividend
income is primarily attributable to a reduction in the average rate of return on our investments as well as a decrease in our average investment balances.

[0001193125-16-475816:mdna:82]
Interest Expense

[0001193125-16-475816:mdna:83]
Interest expense, which is primarily
related to our taxable revenue bond, decreased from $0.7 million in 2014 to $0.6 million in 2015. The decrease is primarily attributable to a reduction in the principal and the impact of an interest rate reduction, which occurred during the first
quarter of 2014. See “Financing Activities” in “Liquidity and Capital Resources” below for additional information on our taxable revenue bond.

[0001193125-16-475816:mdna:84]
Net Realized Investment Gain

[0001193125-16-475816:mdna:85]
Net realized investment
gain increased from $7.3 million in 2014 to $10.3 million in 2015. The increase in realized investment gains is primarily attributable to larger gains from the sale of equity securities in 2015. See “Investing Activities” in
“Liquidity and Capital Resources” below for additional information.

[0001193125-16-475816:mdna:86]
Other Income (Expense), net

[0001193125-16-475816:mdna:87]
Other income (expense), net, comprised primarily of miscellaneous income, gains and losses resulting from foreign currency exchange rate movements, and
investment account management fees, changed from $1.2 million of income in 2014 to $1.5 million of expense in 2015. The change is primarily attributable to a $2.4 million gain recorded in the fourth quarter of 2014 related to the settlement of
working capital items from an acquisition transaction that closed in 2012.

[0001193125-16-475816:mdna:88]
Income Taxes

[0001193125-16-475816:mdna:89]
Our effective tax rate increased from 25.5% in 2014 to 27.5% in 2015. The increase in the effective tax rate between the two periods is primarily attributable
to a foreign tax benefit from the elimination of a valuation allowance in 2014, partially offset by a benefit from the closure of an audit and a higher R&D credit in 2015.

[0001193125-16-475816:mdna:90]
Net Income

[0001193125-16-475816:mdna:91]
As a result of the above factors, net income
decreased from $44.6 million in 2014 to $18.6 million in 2015. As a percentage of sales, net income decreased from 7.1% in 2014 to 3.1% in 2015.

[0001193125-16-475816:mdna:92]
2014
Compared to 2013

[0001193125-16-475816:mdna:93]
Sales

[0001193125-16-475816:mdna:94]
Our sales decreased 1.8%
from $641.7 million in 2013 to $630.0 million in 2014. The decrease in sales is primarily attributable to a $27.2 million decrease in sales of our HDSL and other legacy products and a $12.2 million decrease in sales of our Internetworking products,
partially offset by a $27.9 million increase in sales of our Broadband Access products.

[0001193125-16-475816:mdna:95]
Carrier Networks sales increased 1.9% from $500.7 million in 2013 to $510.4 million in 2014. The increase in
sales is primarily attributable to increases in sales of Broadband Access products, Internetworking products, and Optical products, partially offset by a decrease in sales of our HDSL and other legacy products. The increase in sales of our Broadband
Access products is primarily attributable to an increase in hiX product sales in the EMEA region. The increase in sales of our Internetworking products is primarily attributable to increases in Carrier Ethernet sales and FTTP ONT sales to carriers
in North America. The increase in sales of our Optical products is primarily attributable to increased sales of Optical products for broadband access globally and increased sales of our OPTI-6100 products to a domestic tier 1 carrier for Ethernet
services to enterprises for wireless backhaul. The decreases in sales of HDSL and other legacy products in North America have been expected as customers continue to upgrade their networks to deliver higher bandwidth services by migrating to newer
technologies, including to our core products from our Broadband Access, Internetworking and Optical product lines. While we expect that revenues from HDSL and our other legacy products will continue to decline over time, these revenues may continue
for years because of the time required for our customers to transition to newer technologies.

[0001193125-16-475816:mdna:96]
Enterprise Networks sales decreased 15.2% from $141.0
million in 2013 to $119.6 million in 2014. The decrease is attributable to a decrease in sales of our Internetworking products. The decrease in sales of our Internetworking products for this division is primarily attributable to softer demand in
North America and an inventory reduction, primarily at two distribution partners. Internetworking product sales attributable to Enterprise Networks were 93.6% of the division’s sales in 2014 and 2013. Legacy products primarily comprise the
remainder of Enterprise Networks sales. Enterprise Networks sales as a percentage of total sales decreased from 22.0% in 2013 to 19.0% in 2014.

[0001193125-16-475816:mdna:97]
International sales, which are included in the Carrier Networks and Enterprise Networks amounts discussed above, increased 33.9% from $185.7 million in 2013
to $248.6 million in 2014. International sales, as a percentage of total sales, increased from 28.9% in 2013 to 39.5% in 2014. The increase in international sales is primarily attributable to increases in sales in the EMEA region and Latin America,
partially offset by a decrease in sales in the Asia-Pacific region.

[0001193125-16-475816:mdna:98]
Carrier Systems product sales increased $14.8 million in 2014 compared to 2013
primarily due to a $27.9 million increase in Broadband Access product sales, partially offset by a $12.8 million decrease in legacy product sales. The increase in Carrier Systems product sales is primarily attributable to the factors discussed
above.

[0001193125-16-475816:mdna:99]
Business Networking product sales decreased $11.9 million in 2014 compared to 2013 primarily due to a $19.9 million decrease in Internetworking
product sales in the EN division, partially offset by a $7.7 million increase in Internetworking product sales in the CN division. The changes in sales of our Internetworking products in both of our divisions are primarily attributable to the
factors discussed above.

[0001193125-16-475816:mdna:100]
Loop Access product sales decreased $14.7 million in 2014 compared to 2013 primarily due to a $13.8 million decrease in HDSL
product sales, which is further discussed above.

[0001193125-16-475816:mdna:101]
Cost of Sales

[0001193125-16-475816:mdna:102]
As a percentage of sales, cost of sales decreased from 51.9% in 2013 to 50.6% in 2014. The decrease is primarily attributable to improving gross margins in our
international business, primarily related to lower product costs, partially offset by shifts in domestic customer mix and a higher services mix.

[0001193125-16-475816:mdna:103]
Carrier
Networks cost of sales decreased from 53.4% of sales in 2013 to 52.3% of sales in 2014. The decrease in Carrier Networks cost of sales as a percentage of sales is primarily attributable to improving gross margins in our international business,
partially offset by shifts in domestic customer mix and a higher services mix.

[0001193125-16-475816:mdna:104]
Enterprise Networks cost of sales decreased from 46.3% of sales in 2013 to
43.1% of sales in 2014. The decrease in Enterprise Networks cost of sales as a percentage of sales is primarily attributable to shifts in customer mix and lower product costs.

[0001193125-16-475816:mdna:105]
An important part of our strategy is to reduce the product cost of each succeeding product generation and then to lower the product’s price based on the
cost savings achieved. This may cause variations in our gross profit percentage due to timing differences between the recognition of cost reductions and the lowering of product selling prices.

[0001193125-16-475816:mdna:106]
Selling, General and Administrative Expenses

[0001193125-16-475816:mdna:107]
Selling, general and administrative expenses increased 2.0% from $129.4 million in 2013 to $132.0 million in 2014. Selling, general and administrative expenses
include personnel costs for administration, finance, information systems, human resources, sales and marketing, and general management, as well as rent, utilities, legal and accounting expenses, bad debt expense, advertising, promotional material,
trade show expenses, and related travel costs. The increase in selling, general and administrative expenses is primarily attributable to increases in travel expenses, marketing expenses, contract services, and legal expenses, partially offset by a
decrease in compensation expense. The increase in travel and marketing expenses is primarily attributable to our increased participation in trade shows in the U.S. and the EMEA region.

[0001193125-16-475816:mdna:108]
Selling, general and administrative expenses as a percentage of sales increased from 20.2% for the year ended December 31, 2013 to 20.9% for the year
ended December 31, 2014. Selling, general and administrative expenses as a percentage of sales will generally fluctuate whenever there is a significant fluctuation in revenues for the periods being compared.

[0001193125-16-475816:mdna:109]
Research and Development Expenses

[0001193125-16-475816:mdna:110]
Research and
development expenses increased 0.9% from $131.1 million in 2013 to $132.3 million in 2014. The increase in research and development expenses is primarily attributable to increases in compensation costs and travel expenses, partially offset by a
decrease in independent contractor expense.

[0001193125-16-475816:mdna:111]
Research and development expenses as a percentage of sales increased from 20.4% for the year ended
December 31, 2013 to 21.0% for the year ended December 31, 2014. Research and development expenses as a percentage of sales will fluctuate whenever there are incremental product development activities or a significant fluctuation in
revenues for the periods being compared.

[0001193125-16-475816:mdna:112]
We expect to continue to incur research and development expenses in connection with our new and existing
products and our expansion into international markets. We continually evaluate new product opportunities and engage in intensive research and product development efforts which provide for new product development, enhancement of existing products and
product cost reductions. We may incur significant research and development expenses prior to the receipt of revenues from a major new product group.

[0001193125-16-475816:mdna:113]
Interest and Dividend Income

[0001193125-16-475816:mdna:114]
Interest and dividend
income decreased from $7.0 million in 2013 to $5.0 million in 2014. The decrease in interest and dividend income is primarily attributable to an $18.3 million reduction of restricted funds that serves as a collateral deposit against our taxable
revenue bond during the first quarter of 2014 and a reduction in the interest rate of that investment from 4.8% to 1.6% (see “Interest Expense” below for corresponding decrease in the interest rate of our taxable revenue bond). See
“Financing Activities” in “Liquidity and Capital Resources” below for additional information on our taxable revenue bond.

[0001193125-16-475816:mdna:115]
Interest
Expense

[0001193125-16-475816:mdna:116]
Interest expense, which is primarily related to our taxable revenue bond, decreased from $2.3 million in 2013 to $0.7 million in 2014. The
decrease is primarily attributable to a $16.5 million principal payment made on our taxable revenue bond during the first quarter of 2014. In connection with this payment, we negotiated a reduction in the interest rate of that bond from 5.0% to
2.0%, and, as noted above, a reduction in the interest rate on the collateral supporting the bond. See “Financing Activities” in “Liquidity and Capital Resources” below for additional information on our taxable revenue bond.

[0001193125-16-475816:mdna:117]
Net Realized Investment Gain

[0001193125-16-475816:mdna:118]
Net realized investment
gain decreased from $8.6 million in 2013 to $7.3 million in 2014. The decrease in realized investment gains is primarily attributable to lower gains from the sale of equity securities in 2014. See “Investing Activities” in “Liquidity
and Capital Resources” below for additional information.

[0001193125-16-475816:mdna:119]
Other Income (Expense), net

[0001193125-16-475816:mdna:120]
Other income (expense), net, comprised primarily of miscellaneous income, gains and losses resulting from foreign currency exchange rate movements, and
investment account management fees, changed from $0.9 million of expense in 2013 to $1.2 million of income in 2014. The change is primarily attributable to a $2.4 million gain recorded in the fourth quarter of 2014 related to the settlement of
working capital items from an acquisition transaction that closed in 2012, partially offset by investment account management fees.

[0001193125-16-475816:mdna:121]
Income Taxes

[0001193125-16-475816:mdna:122]
Our effective tax rate increased from 24.7% in 2013 to 25.5% in 2014. The increase in the effective tax rate between the two periods is primarily attributable
to two years of research tax credits being recognized in 2013, partially offset by an additional foreign tax benefit from the elimination of a valuation allowance recorded in 2014. Based upon our results of operations in 2014 and expected
profitability in future years in a certain international jurisdiction, we concluded that it is more likely than not certain foreign deferred tax assets will be realized.

[0001193125-16-475816:mdna:123]
Net Income

[0001193125-16-475816:mdna:124]
As a result of the above factors, net income
decreased from $45.8 million in 2013 to $44.6 million in 2014. As a percentage of sales, net income was 7.1% in 2013 and 2014.

[0001193125-16-475816:mdna:125]
Liquidity and Capital
Resources

[0001193125-16-475816:mdna:126]
Liquidity

[0001193125-16-475816:mdna:127]
We intend to finance our
operations with cash flow from operations. We have used, and expect to continue to use, the cash generated from operations for working capital, purchases of treasury stock, shareholder dividends, and other general corporate purposes, including
(i) product development activities to enhance our existing products and develop new products and (ii) expansion of sales and marketing activities. We believe our cash and cash equivalents, investments and cash generated from operations to
be adequate to meet our operating and capital needs for at least the next 12 months.

[0001193125-16-475816:mdna:128]
At December 31, 2015, cash on hand was $84.6 million and
short-term investments were $34.4 million, which placed our short-term liquidity at $118.9 million. At December 31, 2014, our cash on hand of $73.4 million and short-term investments of $46.9 million placed our short-term liquidity at $120.4
million. The decrease in short-term liquidity from 2014 to 2015 primarily reflects the timing of short-term cash management requirements.

[0001193125-16-475816:mdna:129]
Operating
Activities

[0001193125-16-475816:mdna:130]
Our working capital, which consists of current assets less current liabilities, increased 2.6% from $232.1 million as of December 31,
2014 to $238.1 million as of December 31, 2015. The quick ratio, defined as cash and cash equivalents, short-term investments, and net accounts receivable, divided by current liabilities, increased from 1.75 as of December 31, 2014 to 2.06
as of December 31, 2015. The current ratio, defined as current assets divided by current liabilities, increased from 2.95 as of December 31, 2014 to 3.57 as of December 31, 2015. The changes in our working capital, quick ratio and
current ratio are primarily attributable to a decrease in accounts payable, income taxes payable, and an increase in inventory, partially offset by a decrease in short-term investments, accounts receivable, and other receivables. The decrease in
income taxes payable is primarily attributable to tax payments made in foreign jurisdictions during 2015. The decrease in short term investments is primarily attributable to share repurchases during 2015.

[0001193125-16-475816:mdna:131]
Net accounts receivable decreased 18.7% from $88.5 million at December 31, 2014 to $71.9 million at December 31, 2015. Our allowance for doubtful
accounts was $0.1 million at December 31, 2014 and $19 thousand at December 31, 2015. Quarterly accounts receivable DSO decreased from 57 days as of December 31, 2014 to 48 days as of December 31, 2015. The change in net accounts
receivable and DSO is due to changes in customer mix and the timing of sales and collections during the quarter. Certain international customers can have longer payment terms than U.S. customers. Other receivables decreased from $33.3 million at
December 31, 2014 to $19.3 million at December 31, 2015. The decrease in other receivables is primarily attributable to the timing of filing returns and collections of value-added tax receivables in our international subsidiaries and the
collection of a receivable for additional consideration due from NSN for settlement of the working capital items at December 31, 2014. Other receivables will also fluctuate due to the timing of shipments and collections for materials supplied
to our contract manufacturers during the quarter.

[0001193125-16-475816:mdna:132]
Quarterly inventory turnover decreased from 3.5 turns as of December 31, 2014 to 3.3 turns as of
December 31, 2015. Inventory increased 6.5% from December 31, 2014 to December 31, 2015. We expect inventory levels to fluctuate as we attempt to maintain sufficient inventory in response to seasonal cycles of our business ensuring
competitive lead times while managing the risk of inventory obsolescence that may occur due to rapidly changing technology and customer demand.

[0001193125-16-475816:mdna:133]
Accounts
payable decreased 13.7% from $56.4 million at December 31, 2014 to $48.7 million at December 31, 2015. Accounts payable will fluctuate due to variations in the timing of the receipt of supplies, inventory and services and our subsequent
payments for these purchases.

[0001193125-16-475816:mdna:134]
Investing Activities

[0001193125-16-475816:mdna:135]
Capital expenditures totaled approximately $11.8 million, $11.3 million and $8.2 million for the years ended December 31, 2015, 2014 and 2013,
respectively. These expenditures were primarily used to purchase computer hardware, software, manufacturing and test equipment, and building improvements.

[0001193125-16-475816:mdna:136]
Our combined short-term and long-term investments decreased $95.1 million from $327.6 million at December 31, 2014 to $232.4 million at December 31,
2015. This decrease reflects the impact of our cash needs for share repurchases, shareholder dividends, equipment acquisitions, as well as net realized and unrealized losses, and amortization of net premiums on our combined investments, partially
offset by additional funds available for investment provided by our operating activities and stock option exercises by our employees.

[0001193125-16-475816:mdna:137]
We invest all
available cash not required for immediate use in operations primarily in securities that we believe bear minimal risk of loss. At December 31, 2015, these investments included corporate bonds of $57.6 million, municipal fixed-rate bonds of
$26.4 million, asset-backed bonds of $19.2 million, mortgage/agency-backed bonds of $15.4 million and government bonds of $35.4 million. At December 31, 2014, these investments included corporate bonds of $111.3 million, municipal fixed-rate
bonds of $127.8 million and municipal variable rate demand notes of $2.5 million. As of December 31, 2015, our corporate bonds, municipal fixed-rate bonds, asset-backed bonds, mortgage/agency-backed bonds, and government bonds were classified
as available-for-sale and had a combined duration of 1.5 years with an average credit rating of A+. Because our bond portfolio has a high quality rating and contractual maturities of a short duration, we are able to obtain prices for these bonds
derived from observable market inputs, or for similar securities traded in an active market, on a daily basis.

[0001193125-16-475816:mdna:138]
Our long-term investments decreased 29.4%
from $280.6 million at December 31, 2014 to $198.0 million at December 31, 2015. Long-term investments at December 31, 2015 and December 31, 2014 included an investment in a certificate of deposit of $30.0 million, which serves
as collateral for our revenue bond, as discussed below. We have investments in various marketable equity securities classified as long-term investments at a cost of $31.6 million and $26.4 million, and with a fair value of $34.3 million and $38.3
million, at December 31, 2015 and December 31, 2014, respectively.

[0001193125-16-475816:mdna:139]
Long-term investments at December 31, 2015 and 2014 also included $12.8
million and $16.3 million, respectively, related to our deferred compensation plan, and $1.3 million and $1.5 million, respectively, of other investments carried at cost, consisting of interests in two private equity funds and an investment in a
privately held telecommunications equipment manufacturer.

[0001193125-16-475816:mdna:140]
We review our investment portfolio for potential “other-than-temporary” declines in
value on an individual investment basis. We assess, on a quarterly basis, significant declines in value which may be considered other-than-temporary and, if necessary, recognize and record the appropriate charge to write-down the carrying value of
such investments. In making this assessment, we take into consideration qualitative and quantitative information, including but not limited to the following: the magnitude and duration of historical declines in market prices, credit rating activity,
assessments of liquidity, public filings, and statements made by the issuer. We generally begin our identification of potential other-than-temporary impairments by reviewing any security with a fair value that has declined from its original or
adjusted cost basis by 25% or more for six or more consecutive months. We then evaluate the individual security based on the previously identified factors to determine the amount of the write-down, if any. For the years ended December 31, 2015,
2014, and 2013, we recorded charges of $0.2 million, $0.1 million and $25 thousand, respectively, related to the other-than-temporary impairment of certain publicly traded equity securities and our deferred compensation plan assets.

[0001193125-16-475816:mdna:141]
Financing Activities

[0001193125-16-475816:mdna:142]
In conjunction with an expansion of our Huntsville, Alabama, facility, we were approved for participation in an incentive program offered by the State of
Alabama Industrial Development Authority (the “Authority”). Pursuant to the program, on January 13, 1995, the Authority issued $20.0 million of its taxable revenue bonds and loaned the proceeds from the sale of the bonds to ADTRAN.
The bonds were originally purchased by AmSouth Bank of Alabama, Birmingham, Alabama (the “Bank”). Wachovia Bank, N.A., Nashville, Tennessee (formerly First Union National Bank of Tennessee) (the “Bondholder”), which was acquired
by Wells Fargo & Company on December 31, 2008, purchased the original bonds from the Bank and made further advances to the Authority, bringing the total amount outstanding to $50.0 million. An Amended and Restated Taxable Revenue Bond
(“Amended and Restated Bond”) was issued and the original financing agreement was amended. The Amended and Restated Bond bears interest, payable monthly. The interest rate is 2% per annum. The Amended and Restated Bond matures on
January 1, 2020, and is currently outstanding in the aggregate principal amount of $28.9 million. The estimated fair value of the bond using a level 2 valuation technique at December 31, 2015 was approximately $28.7 million, based on a
debt security with a comparable interest rate and maturity and a Standard & Poor’s credit rating of AAA. We are required to make payments to the Authority in amounts necessary to pay the interest on the Amended and Restated Bond.
Included in long-term investments at December 31, 2015 is $30.0 million which is invested in a restricted certificate of deposit. These funds serve as a collateral deposit against the principal of this bond, and we have the right to set-off the
balance of the Bond with the collateral deposit in order to reduce the balance of the indebtedness.

[0001193125-16-475816:mdna:143]
In conjunction with this program, we are eligible to
receive certain economic incentives from the state of Alabama that reduce the amount of payroll withholdings that we are required to remit to the state for those employment positions that qualify under the program. We realized economic incentives
related to payroll withholdings totaling $1.3 million for each of the years ended December 31, 2015, 2014 and 2013.

[0001193125-16-475816:mdna:144]
We made a principal payment of
$1.1 million and $16.5 million for the years ended December 31, 2015 and 2014, respectively, and we anticipate making a principal payment in 2016. At December 31, 2015, $1.0 million of the bond debt was classified as a current liability in
accounts payable in the Consolidated Balance Sheets.

[0001193125-16-475816:mdna:145]
Dividends

[0001193125-16-475816:mdna:146]
During 2015, 2014 and 2013, we paid shareholder dividends totaling $18.4 million, $19.9 million and $21.4 million, respectively. The Board of Directors
presently anticipates that it will declare a regular quarterly dividend so long as the present tax treatment of dividends exists and adequate levels of liquidity are maintained. The following table shows dividends paid to our shareholders in each
quarter of 2015, 2014 and 2013.

[0001193125-16-475816:mdna:147]
| Dividends per Common Share |  |
|  |  |  | 2015 |  |  |  | 2014 |  |  |  | 2013 |  |
| First Quarter |  | $ | 0.09 |  |  | $ | 0.09 |  |  | $ | 0.09 |  |
| Second Quarter |  | $ | 0.09 |  |  | $ | 0.09 |  |  | $ | 0.09 |  |
| Third Quarter |  | $ | 0.09 |  |  | $ | 0.09 |  |  | $ | 0.09 |  |
| Fourth Quarter |  | $ | 0.09 |  |  | $ | 0.09 |  |  | $ | 0.09 |  |

[0001193125-16-475816:mdna:148]
Stock Repurchase Program

[0001193125-16-475816:mdna:149]
Since 1997, our Board of Directors has approved multiple share repurchase programs that have authorized open market repurchase transactions of up to
45.0 million shares of our common stock. On July 14, 2015, our Board of Directors authorized the repurchase of an additional 5.0 million shares of our common stock (bringing the total shares authorized for repurchase to 50.0 million),
which will commence upon completion of the repurchase plan announced on May 14, 2014. This new authorization will be implemented through open market or private purchases from time to time as conditions warrant. For the years 2015, 2014 and
2013, we repurchased 4.0 million shares, 3.7 million shares and 5.6 million shares, respectively, for a cost of $66.2 million, $80.6 million and $124.3 million, respectively, at an average price of $16.68, $21.96 and $22.16 per share,
respectively. We currently have the authority to purchase an additional 5.8 million shares of our common stock under the current plans approved by the Board of Directors.

[0001193125-16-475816:mdna:150]
Stock Option Exercises

[0001193125-16-475816:mdna:151]
To accommodate employee stock
option exercises, we issued 0.1 million shares of treasury stock for $1.0 million during the year ended December 31, 2015, 0.1 million shares of treasury stock for $2.8 million during the year ended December 31, 2014, and
0.2 million shares of treasury stock for $3.6 million during the year ended December 31, 2013.

[0001193125-16-475816:mdna:152]
Off-Balance Sheet Arrangements and Contractual Obligations

[0001193125-16-475816:mdna:153]
We do not have off-balance sheet financing arrangements and have not engaged in any related party transactions or arrangements with unconsolidated entities or
other persons that are reasonably likely to materially affect liquidity or the availability of or requirements for capital resources.

[0001193125-16-475816:mdna:154]
We have various
contractual obligations and commercial commitments. The following table sets forth, in millions, the annual payments we are required to make under contractual cash obligations and other commercial commitments at December 31, 2015.

[0001193125-16-475816:mdna:155]
Contractual Obligations

[0001193125-16-475816:mdna:156]
| (In millions) |  | Total |  |  | 2016 |  |  | 2017 |  |  | 2018 |  |  | 2019 |  |  | After2019 |  |
| Long-term debt |  | $ | 28.9 |  |  | $ | 1.0 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |  | $ | 27.9 |  |
| Interest on long-term debt |  |  | 2.3 |  |  |  | 0.6 |  |  |  | 0.6 |  |  |  | 0.6 |  |  |  | 0.5 |  |  |  | — |  |
| Purchase obligations |  |  | 102.2 |  |  |  | 99.8 |  |  |  | 1.7 |  |  |  | 0.6 |  |  |  | 0.1 |  |  |  | — |  |
| Operating lease obligations |  |  | 13.7 |  |  |  | 3.8 |  |  |  | 3.1 |  |  |  | 1.8 |  |  |  | 0.9 |  |  |  | 4.1 |  |
| Totals |  | $ | 147.1 |  |  | $ | 105.2 |  |  | $ | 5.4 |  |  | $ | 3.0 |  |  | $ | 1.5 |  |  | $ | 32.0 |  |

[0001193125-16-475816:mdna:157]
We are required to make payments necessary to pay the interest on the Amended and Restated Bond, currently outstanding in the
aggregate principal amount of $28.9 million. The bond matures on January 1, 2020, and bears interest at the rate of 2% per annum. Included in long-term investments are $30.0 million of restricted funds, which is a collateral deposit
against the principal amount of this bond. We made a principal payment of $1.1 million and $16.5 million for the years ended December 31, 2015 and 2014, respectively. We anticipate making a principal payment in 2016. At December 31, 2015
and 2014, $1.0 million and $1.2 million, respectively, of the bond debt were classified as a current liability in accounts payable in the Consolidated Balance Sheets. See Note 8 of Notes to Consolidated Financial Statements for additional
information.

[0001193125-16-475816:mdna:158]
Purchase obligations primarily relate to open purchase orders to our contract manufacturers, component suppliers, and other vendors.

[0001193125-16-475816:mdna:159]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, and we have contributed $8.4 million as of December 31, 2015,
of which $7.7 million has been applied to these commitments. The additional $0.2 million commitment has been excluded from the table above due to uncertainty of when it will be applied.

[0001193125-16-475816:mdna:160]
We also have obligations related to uncertain income tax positions that have been excluded from the table above due to the uncertainty of when the related
expense will be recognized. See Note 9 of Notes to Consolidated Financial Statements for additional information.

[0001193125-16-475816:mdna:161]
Effect of Recent Accounting
Pronouncements

[0001193125-16-475816:mdna:162]
In May 2014, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update No. 2014-09, Revenue from
Contracts with Customers (ASU 2014-09), which supersedes the revenue recognition requirements in Topic 605, Revenue Recognition, including most industry-specific revenue recognition guidance throughout the Industry Topics of the
Codification. The core principle of ASU 2014-09 is to recognize revenues when promised goods or services are transferred to customers in an amount that reflects the consideration that is expected to be received for those goods or services. In August
2015, the FASB issued ASU 2015-14, which deferred the effective date of ASU 2014-09 to fiscal years beginning after December 31, 2017, including interim periods within those years. ASU 2014-09 allows for either full retrospective or modified
retrospective adoption. We are currently evaluating the transition method that will be elected and the impact that the adoption of ASU 2014-09 will have on our financial position, results of operations and cash flows.

[0001193125-16-475816:mdna:163]
In April 2015, the FASB issued Accounting Standards Update No. 2015-05, Intangibles – Goodwill and Other – Internal-Use Software (Subtopic
350-40): Customer’s Accounting for Fees Paid in a Cloud Computing Arrangement (ASU 2015-05), which provides guidance on accounting for fees paid by a customer in a cloud computing arrangement. If a cloud computing arrangement includes a
software license, then the customer should account for the software license element of the arrangement consistent with the acquisition of other software licenses. If a cloud computing arrangement does not include a software license, the customer
should account for the arrangement as a service contract. ASU 2015-05 is effective for annual reporting periods beginning after December 15, 2015, including interim periods within those years. Early adoption is permitted. The guidance may be
applied either prospectively to all arrangements entered into or materially modified after the effective date or retrospectively. We do not believe the adoption of ASU 2015-05 will have a material impact on our financial position, results of
operations and cash flows.

[0001193125-16-475816:mdna:164]
In July 2015, the FASB issued Accounting Standards Update No. 2015-11, Inventory (Topic 330): Simplifying the
Measurement of Inventory (ASU 2015-11). Currently, Topic 330, Inventory, requires an entity to measure inventory at the lower of cost or market. Market could be replacement cost, net realizable value, or net realizable value less an
approximately normal profit margin. ASU 2015-11 does not apply to inventory that is measured using last-in, first-out (LIFO) or the retail inventory method. The amendments apply to all other inventory, which includes inventory that is measured using
first-in, first-out (FIFO) or average cost. ASU 2015-11 requires an entity to measure in scope inventory at the lower of cost and net realizable value. Net realizable value is the estimated selling prices in the ordinary course of business, less
reasonably predictable costs of completion, disposal, and transportation. ASU 2015-11 is effective for annual reporting periods beginning after December 15, 2016, including interim periods within those years. The guidance should be applied
prospectively with earlier application permitted as of the beginning of an interim or annual reporting period. We do not believe the adoption of ASU 2015-05 will have a material impact on our financial position, results of operations and cash flows.

[0001193125-16-475816:mdna:165]
In November 2015, the FASB issued Accounting Standards Update No. 2015-17, Balance Sheet Classification of Deferred Taxes (ASU 2015-17). ASU
2015-17 amends the existing guidance on income taxes to require the classification of all deferred tax assets and liabilities as non-current on the balance sheet. ASU 2015-17 is effective for fiscal years beginning after December 15, 2016,
including interim periods within those years. Early adoption is permitted. The guidance may be applied either prospectively, for all deferred tax assets and liabilities, or retrospectively to all periods presented. We have not selected a transition
method or determined whether to early adopt ASU 2015-17 in 2016. Other than the revised balance sheet presentation of current deferred tax assets and liabilities, we do not believe the adoption of ASU 2015-17 will have a material impact on our
financial position, results of operations and cash flows.

[0001193125-16-475816:mdna:166]
Subsequent Events

[0001193125-16-475816:mdna:167]
On January 19, 2016, the Board declared a quarterly cash dividend of $0.09 per common share to be paid to shareholders of record at the close of business
on February 4, 2016. The quarterly dividend payment was $4.4 million and was paid on February 18, 2016.

[0001193125-16-475816:mdna:168]
On February 8, 2016, the Board
appointed Anthony Melone as a director filling a previously existing vacancy until the 2016 Annual Meeting of Stockholders.

[0001193125-16-475816:mdna:169]
During the first quarter and
as of February 24, 2016, we have repurchased 0.6 million shares of our common stock through open market purchases at an average cost of $18.38 per share. We currently have the authority to purchase an additional 5.2 million shares of
our common stock under the current plan approved by the Board of Directors.

[0001193125-16-475816:mdna:170]
We are currently evaluating the way the Company’s chief operating
decision maker reviews and measures performance of the business. The conclusions of this evaluation may have an impact on our future presentation of our reportable segments.
