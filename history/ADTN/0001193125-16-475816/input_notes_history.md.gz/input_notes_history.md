# ADTN note change history — 0001193125-15-278444 → 0001193125-15-366072


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock (contingencies) — matched_by: tag_name, score: 1.0

- changed (2015-11-04):
[0001193125-15-366072:note_history:1]
We have committed to invest up to an aggregate of $7.9 million in
 two private equity funds, and we have contributed $8.4 million as
 of September 30, 2015, of which $7.7 million has been applied
 to these commitments.
  (was, 2015-08-05, similarity 0.9726):
[0001193125-15-278444:note_history:1]
We have committed to invest up to an aggregate of $7.9 million in
 two private equity funds, and we have contributed $8.4 million as
 of June 30, 2015, of which $7.7 million has been applied to
 these commitments.


## us-gaap:SignificantAccountingPoliciesTextBlock (critical_accounting_estimates) — matched_by: tag_name, score: 1.0

- changed (2015-11-04):
[0001193125-15-366072:note_history:2]
In connection with the preparation of our Condensed Consolidated
 Financial Statements, we recorded corrections of certain out of
 period, immaterial misstatements that occurred in prior periods,
 the most significant of which resulted in an increase in Other
 Expense of $1.3 million in the first quarter of 2015. The aggregate
 impact of the corrections was a $0.8 million reduction to pre-tax
 income for the nine months ended September 30, 2015 and is not
 expected to be material to the current year annual results.
  (was, 2015-08-05, similarity 0.8954):
[0001193125-15-278444:note_history:2]
In connection with the preparation of our Condensed Consolidated
 Financial Statements, we recorded corrections of certain out of
 period, immaterial misstatements that occurred in prior periods,
 the most significant of which resulted in an increase in Other
 Expense of $1.3 million in the first quarter of 2015. The aggregate
 impact of the corrections was a $0.8 million reduction to pre-tax
 income for the six months ended June 30, 2015 and is not
 expected to be material to the current year annual results.

- added (2015-11-04):
[0001193125-15-366072:note_history:3]
In May 2014, the Financial Accounting Standards Board (FASB) issued
 Accounting Standards Update No. 2014-09, Revenue from
 Contracts with Customers (ASU 2014-09), which supersedes the
 revenue recognition requirements in Topic 605, Revenue
 Recognition, including most industry-specific revenue
 recognition guidance throughout the Industry Topics of the
 Codification. The core principle of ASU 2014-09 is to recognize
 revenues when promised goods or services are transferred to
 customers in an amount that reflects the consideration that is
 expected to be received for those goods or services. In August
 2015, the FASB issued ASU 2015-14, which deferred the effective
 date of ASU 2014-09 to fiscal years beginning after
 December 31, 2017, and interim periods within those fiscal
 years. ASU 2014-09 allows for either full retrospective or modified
 retrospective adoption. We are currently evaluating the transition
 method that will be elected and the impact that the adoption of ASU
 2014-09 will have on our financial position, results of operations
 and cash flows.

- removed (2015-11-04):
[0001193125-15-278444:note_history:4]
In May 2014, the Financial Accounting Standards Board (FASB) issued
 Accounting Standards Update No. 2014-09, Revenue from
 Contracts with Customers (ASU 2014-09), which supersedes the
 revenue recognition requirements in Topic 605, Revenue
 Recognition, including most industry-specific revenue
 recognition guidance throughout the Industry Topics of the
 Codification. The core principle of ASU 2014-09 is to recognize
 revenues when promised goods or services are transferred to
 customers in an amount that reflects the consideration that is
 expected to be received for those goods or services. ASU 2014-09 is
 effective for annual reporting periods beginning after
 December 15, 2017, including interim periods within that
 reporting period, and early application is not permitted. ASU
 2014-09 allows for either full retrospective or modified
 retrospective adoption. We are currently evaluating the transition
 method that will be elected and the impact that the adoption of ASU
 2014-09 will have on our financial position, results of operations
 and cash flows.


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock (debt) — matched_by: tag_name, score: 1.0

- changed (2015-11-04):
[0001193125-15-366072:note_history:5]
At September 30, 2015, we held the following securities and
 investments, recorded at either fair value or cost.
  (was, 2015-08-05, similarity 0.9463):
[0001193125-15-278444:note_history:5]
At June 30, 2015, we held the following securities and
 investments, recorded at either fair value or cost.

- changed (2015-11-04):
[0001193125-15-366072:note_history:6]
| (In thousands) |  | Amortized Cost |  |  | Gross Unrealized |  |  | Carrying Value |  |
|  |  | Gains |  |  | Losses |  |  |
| Deferred compensation plan assets |  | $ | 14,226 |  |  | $ | 1,536 |  |  | $ | (221 | ) |  | $ | 15,541 |  |
| Corporate bonds |  |  | 87,555 |  |  |  | 38 |  |  |  | (790 | ) |  |  | 86,803 |  |
| Municipal fixed-rate bonds |  |  | 51,971 |  |  |  | 129 |  |  |  | (20 | ) |  |  | 52,080 |  |
| Asset-backed bonds |  |  | 5,490 |  |  |  | — |  |  |  | (3 | ) |  |  | 5,487 |  |
| Mortgage/Agency-backed bonds |  |  | 8,422 |  |  |  | 21 |  |  |  | (15 | ) |  |  | 8,428 |  |
| Government bonds |  |  | 14,217 |  |  |  | 74 |  |  |  | (2 | ) |  |  | 14,289 |  |
| Marketable equity securities |  |  | 29,508 |  |  |  | 5,462 |  |  |  | (2,375 | ) |  |  | 32,595 |  |
| Available-for-sale securities held at fair value |  | $ | 211,389 |  |  | $ | 7,260 |  |  | $ | (3,426 | ) |  | $ | 215,223 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 30,000 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1,371 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 246,594 |  |
  (was, 2015-08-05, similarity 0.8895):
[0001193125-15-278444:note_history:6]
| (In thousands) |  | Amortized Cost |  |  | Gross Unrealized |  |  | Carrying Value |  |
|  |  | Gains |  |  | Losses |  |  |
| Deferred compensation plan assets |  | $ | 13,897 |  |  | $ | 2,409 |  |  | $ | (12 | ) |  | $ | 16,294 |  |
| Corporate bonds |  |  | 111,261 |  |  |  | 186 |  |  |  | (186 | ) |  |  | 111,261 |  |
| Municipal fixed-rate bonds |  |  | 127,341 |  |  |  | 480 |  |  |  | (34 | ) |  |  | 127,787 |  |
| Municipal variable rate demand notes |  |  | 2,465 |  |  |  | — |  |  |  | — |  |  |  | 2,465 |  |
| Marketable equity securities |  |  | 26,399 |  |  |  | 12,395 |  |  |  | (539 | ) |  |  | 38,255 |  |
| Available-for-sale securities held at fair value |  | $ | 281,363 |  |  | $ | 15,470 |  |  | $ | (771 | ) |  | $ | 296,062 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 30,000 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1,506 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 327,568 |  |

- changed (2015-11-04):
[0001193125-15-366072:note_history:7]
As of September 30, 2015, our corporate bonds, municipal
 fixed-rate bonds, asset-backed bonds, mortgage/agency-backed bonds,
 and government bonds had the following contractual maturities:
  (was, 2015-08-05, similarity 0.6944):
[0001193125-15-278444:note_history:7]
As of June 30, 2015, our corporate bonds and municipal
 fixed-rate bonds had the following contractual maturities:

- added (2015-11-04):
[0001193125-15-366072:note_history:8]
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset- backed bonds |  |  | Mortgage / Agency- backed bonds |  |  | Government bonds |  |
| Less than one year |  | $ | 23,732 |  |  | $ | 16,034 |  |  | $ | — |  |  | $ | 775 |  |  | $ | — |  |
| One to two years |  |  | 35,429 |  |  |  | 27,312 |  |  |  | — |  |  |  | — |  |  |  | 4,198 |  |
| Two to three years |  |  | 27,642 |  |  |  | 7,310 |  |  |  | 1,065 |  |  |  | 1,000 |  |  |  | 1,878 |  |
| Three to five years |  |  | — |  |  |  | 1,424 |  |  |  | 4,422 |  |  |  | — |  |  |  | 8,213 |  |
| Five to ten years |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 684 |  |  |  | — |  |
| More than ten years |  |  | — |  |  |  | — |  |  |  | — |  |  |  | 5,969 |  |  |  | — |  |
| Total |  | $ | 86,803 |  |  | $ | 52,080 |  |  | $ | 5,487 |  |  | $ | 8,428 |  |  | $ | 14,289 |  |

- changed (2015-11-04):
[0001193125-15-366072:note_history:9]
At September 30, 2015, we held a $30.0 million restricted
 certificate of deposit, which is carried at cost. This investment
 serves as a collateral deposit against the principal amount
 outstanding under loans made to ADTRAN pursuant to an Alabama State
 Industrial Development Authority revenue bond (the Bond). At
 September 30, 2015, the estimated fair value of the Bond using
 a level 2 valuation technique was approximately $30.1 million,
 based on a debt security with a comparable interest rate and
 maturity and a Standard and Poor’s credit rating of AAA. For
 more information on the Bond, see “Debt” under
 “Liquidity and Capital Resources” in the
 “Management’s Discussion and Analysis of Financial
 Condition and Results of Operations” contained in Item 2
 of Part I of this report.
  (was, 2015-08-05, similarity 0.9829):
[0001193125-15-278444:note_history:9]
At June 30, 2015, we held a $30.0 million restricted
 certificate of deposit, which is carried at cost. This investment
 serves as a collateral deposit against the principal amount
 outstanding under loans made to ADTRAN pursuant to an Alabama State
 Industrial Development Authority revenue bond (the Bond). At
 June 30, 2015, the estimated fair value of the Bond using a
 level 2 valuation technique was approximately $29.9 million, based
 on a debt security with a comparable interest rate and maturity and
 a Standard and Poor’s credit rating of AAA. For more
 information on the Bond, see “Debt” under
 “Liquidity and Capital Resources” in the
 “Management’s Discussion and Analysis of Financial
 Condition and Results of Operations” contained in Item 2
 of Part I of this report.

- changed (2015-11-04):
[0001193125-15-366072:note_history:10]
We review our investment portfolio for potential
 “other-than-temporary” declines in value on an
 individual investment basis. We assess, on a quarterly basis,
 significant declines in value which may be considered
 other-than-temporary and, if necessary, recognize and record the
 appropriate charge to write-down the carrying value of such
 investments. In making this assessment, we take into consideration
 qualitative and quantitative information, including but not limited
 to the following: the magnitude and duration of historical declines
 in market prices, credit rating activity, assessments of liquidity,
 public filings, and statements made by the issuer. We generally
 begin our identification of potential other-than-temporary
 impairments by reviewing any security with a fair value that has
 declined from its original or adjusted cost basis by 25% or more
 for six or more consecutive months. We then evaluate the individual
 security based on the previously identified factors to determine
 the amount of the write-down, if any. For the three and nine months
 ended September 30, 2015 and 2014, other-than-temporary
 impairment charges were not significant.
  (was, 2015-08-05, similarity 0.979):
[0001193125-15-278444:note_history:10]
We review our investment portfolio for potential
 “other-than-temporary” declines in value on an
 individual investment basis. We assess, on a quarterly basis,
 significant declines in value which may be considered
 other-than-temporary and, if necessary, recognize and record the
 appropriate charge to write-down the carrying value of such
 investments. In making this assessment, we take into consideration
 qualitative and quantitative information, including but not limited
 to the following: the magnitude and duration of historical declines
 in market prices, credit rating activity, assessments of liquidity,
 public filings, and statements made by the issuer. We generally
 begin our identification of potential other-than-temporary
 impairments by reviewing any security with a fair value that has
 declined from its original or adjusted cost basis by 25% or more
 for six or more consecutive months. We then evaluate the individual
 security based on the previously identified factors to determine
 the amount of the write-down, if any. For the three and six months
 ended June 30, 2015 and 2014, other-than-temporary impairment
 charges were not significant.

- changed (2015-11-04):
[0001193125-15-366072:note_history:11]
|  |  | Three Months Ended September 30, |  |  | Nine Months Ended September 30, |  |
| (In thousands) |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Gross realized gains |  | $ | 2,251 |  |  | $ | 2,728 |  |  | $ | 8,856 |  |  | $ | 7,363 |  |
| Gross realized losses |  | $ | (191 | ) |  | $ | (41 | ) |  | $ | (426 | ) |  | $ | (144 | ) |
  (was, 2015-08-05, similarity 0.8057):
[0001193125-15-278444:note_history:11]
|  |  | Three Months Ended June 30, |  |  | Six Months Ended June 30, |  |
| (In thousands) |  | 2015 |  |  | 2014 |  |  | 2015 |  |  | 2014 |  |
| Gross realized gains |  | $ | 3,459 |  |  | $ | 2,407 |  |  | $ | 6,604 |  |  | $ | 4,635 |  |
| Gross realized losses |  | $ | (204 | ) |  | $ | (67 | ) |  | $ | (234 | ) |  | $ | (103 | ) |

- changed (2015-11-04):
[0001193125-15-366072:note_history:12]
As of September 30, 2015 and 2014, gross unrealized losses
 related to individual securities in a continuous loss position for
 12 months or longer were not significant.
  (was, 2015-08-05, similarity 0.9644):
[0001193125-15-278444:note_history:12]
As of June 30, 2015 and 2014, gross unrealized losses related
 to individual securities in a continuous loss position for 12
 months or longer were not significant.

- changed (2015-11-04):
[0001193125-15-366072:note_history:13]
We have categorized our cash equivalents held in money market funds
 and our investments held at fair value into a three-level fair
 value hierarchy based on the priority of the inputs to the
 valuation technique for the cash equivalents and investments as
 follows: Level 1 - Values based on unadjusted quoted prices for
 identical assets or liabilities in an active market; Level 2 -
 Values based on quoted prices in markets that are not active or
 model inputs that are observable either directly or indirectly;
 Level 3 - Values based on prices or valuation techniques that
 require inputs that are both unobservable and significant to the
 overall fair value measurement. These inputs include information
 supplied by investees.
  (was, 2015-08-05, similarity 0.9917):
[0001193125-15-278444:note_history:13]
We have categorized our cash equivalents held in money market funds
 and our investments held at fair value into a three-level fair
 value hierarchy based on the priority of the inputs to the
 valuation technique for the cash equivalents and investments as
 follows: Level 1—Values based on unadjusted quoted prices for
 identical assets or liabilities in an active market; Level
 2—Values based on quoted prices in markets that are not
 active or model inputs that are observable either directly or
 indirectly; Level 3—Values based on prices or valuation
 techniques that require inputs that are both unobservable and
 significant to the overall fair value measurement. These inputs
 include information supplied by investees.

- changed (2015-11-04):
[0001193125-15-366072:note_history:14]
|  |  | Fair Value Measurements at September 30, 2015 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 6,171 |  |  | $ | 6,171 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 15,541 |  |  |  | 15,541 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 86,803 |  |  |  | — |  |  |  | 86,803 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 52,080 |  |  |  | — |  |  |  | 52,080 |  |  |  | — |  |
| Asset-backed bonds |  |  | 5,487 |  |  |  | — |  |  |  | 5,487 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 8,428 |  |  |  | — |  |  |  | 8,428 |  |  |  | — |  |
| Government bonds |  |  | 14,289 |  |  |  | 13,289 |  |  |  | 1,000 |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – technology industry |  |  | 5,701 |  |  |  | 5,701 |  |  |  | — |  |  |  | — |  |
| Marketable equity securities – other |  |  | 26,894 |  |  |  | 26,894 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 215,223 |  |  |  | 61,425 |  |  |  | 153,798 |  |  |  | — |  |
| Total |  | $ | 221,394 |  |  | $ | 67,596 |  |  | $ | 153,798 |  |  | $ | — |  |
  (was, 2015-08-05, similarity 0.9074):
[0001193125-15-278444:note_history:14]
|  |  | Fair Value Measurements at June 30, 2015 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Market for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,087 |  |  | $ | 1,087 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 16,534 |  |  |  | 16,534 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 114,430 |  |  |  | — |  |  |  | 114,430 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 67,387 |  |  |  | — |  |  |  | 67,387 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 3,695 |  |  |  | — |  |  |  | 3,695 |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – technology industry |  |  | 7,786 |  |  |  | 7,786 |  |  |  | — |  |  |  | — |  |
| Marketable equity securities – other |  |  | 29,514 |  |  |  | 29,514 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 239,346 |  |  |  | 53,834 |  |  |  | 185,512 |  |  |  | — |  |
| Total |  | $ | 240,433 |  |  | $ | 54,921 |  |  | $ | 185,512 |  |  | $ | — |  |

- removed (2015-11-04):
[0001193125-15-278444:note_history:15]
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |
| Less than one year |  | $ | 32,179 |  |  | $ | 18,254 |  |
| One to two years |  |  | 42,510 |  |  |  | 35,462 |  |
| Two to three years |  |  | 39,741 |  |  |  | 12,460 |  |
| Three to five years |  |  | — |  |  |  | 1,211 |  |
| Total |  | $ | 114,430 |  |  | $ | 67,387 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock (related_parties) — matched_by: tag_name, score: 1.0

- changed (2015-11-04):
[0001193125-15-366072:note_history:16]
During 2014, we employed the law firm of our director emeritus for
 legal services. All bills for services rendered by this firm were
 reviewed and approved by our Chief Financial Officer. We believe
 that the fees for such services were comparable to those charged by
 other firms for services rendered to us. The services of our
 director emeritus ended with his death on September 7, 2014.
 For the three and nine months ended September 30, 2014, we
 incurred fees of $10 thousand and $70 thousand, respectively, for
 these legal services.
  (was, 2015-08-05, similarity 0.9136):
[0001193125-15-278444:note_history:16]
During 2014, we employed the law firm of our director emeritus for
 legal services. All bills for services rendered by this firm were
 reviewed and approved by our Chief Financial Officer. We believe
 that the fees for such services were comparable to those charged by
 other firms for services rendered to us. The services of our
 director emeritus ended with his death on September 7, 2014.
 For the three and six months ended June 30, 2014, we incurred
 fees of $10 thousand per month for these legal services.


## us-gaap:SubsequentEventsTextBlock (subsequent_events) — matched_by: tag_name, score: 1.0

- added (2015-11-04):
[0001193125-15-366072:note_history:17]
On October 13, 2015, we announced that our Board of Directors
 declared a quarterly cash dividend of $0.09 per common share to be
 paid to stockholders of record at the close of business on
 October 29, 2015. The payment date will be November 12,
 2015. The quarterly dividend payment will be approximately $4.5
 million. In July 2003, our Board of Directors elected to begin
 declaring quarterly dividends on our common stock considering the
 tax treatment of dividends and adequate levels of Company
 liquidity.

- removed (2015-11-04):
[0001193125-15-278444:note_history:18]
On July 14, 2015, we announced that our Board of Directors
 declared a quarterly cash dividend of $0.09 per common share to be
 paid to stockholders of record at the close of business on
 July 30, 2015. The payment date will be August 13, 2015.
 The quarterly dividend payment will be approximately $4.5 million.
 In July 2003, our Board of Directors elected to begin declaring
 quarterly dividends on our common stock considering the tax
 treatment of dividends and adequate levels of Company
 liquidity.

- removed (2015-11-04):
[0001193125-15-278444:note_history:19]
On July 14, 2015, our Board of Directors authorized the
 repurchase of an additional 5.0 million shares of our common
 stock (bringing the total shares authorized for repurchase to 50.0
 million), which will commence upon completion of the repurchase
 plan announced May 14, 2014. This new authorization will be
 implemented through open market or private purchases from time to
 time as conditions warrant.

- removed (2015-11-04):
[0001193125-15-278444:note_history:20]
During the third quarter and as of August 5, 2015, we have
 repurchased 0.8 million shares of our common stock through
 open market purchases at an average cost of $16.31 per share. We
 currently have the authority to purchase an additional
 6.0 million shares of our common stock under the current plan
 approved by the Board of Directors.
