# ADTN notes — 0001193125-16-475816


## us-gaap:DividendsDeclaredTableTextBlock

[0001193125-16-475816:notes:1]
The following table shows dividends paid to our shareholders in
 each quarter of 2015, 2014 and 2013.

[0001193125-16-475816:notes:2]
| Dividends per Common Share |  |
|  |  | 2015 |  |  | 2014 |  |  | 2013 |  |
| First Quarter |  | $ | 0.09 |  |  | $ | 0.09 |  |  | $ | 0.09 |  |
| Second Quarter |  | $ | 0.09 |  |  | $ | 0.09 |  |  | $ | 0.09 |  |
| Third Quarter |  | $ | 0.09 |  |  | $ | 0.09 |  |  | $ | 0.09 |  |
| Fourth Quarter |  | $ | 0.09 |  |  | $ | 0.09 |  |  | $ | 0.09 |  |


## us-gaap:FairValueAssetsMeasuredOnRecurringBasisTextBlock

[0001193125-16-475816:notes:3]
We have categorized our cash equivalents and our investments held
 at fair value into a three-level fair value hierarchy based on the
 priority of the inputs to the valuation technique for the cash
 equivalents and investments as follows: Level 1 - Values based on
 unadjusted quoted prices for identical assets or liabilities in an
 active market; Level 2 - Values based on quoted prices in markets
 that are not active or model inputs that are observable either
 directly or indirectly; Level 3 - Values based on prices or
 valuation techniques that require inputs that are both unobservable
 and significant to the overall fair value measurement. These inputs
 include information supplied by investees.

[0001193125-16-475816:notes:4]
|  |  | Fair Value Measurements at December 31, 2015 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,271 |  |  | $ | 1,271 |  |  | $ | — |  |  | $ | — |  |
| Commercial paper |  |  | 11,696 |  |  |  | — |  |  |  | 11,696 |  |  |  | — |  |
| Cash equivalents |  |  | 12,967 |  |  |  | 1,271 |  |  |  | 11,696 |  |  |  | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 12,834 |  |  |  | 12,834 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 57,614 |  |  |  | — |  |  |  | 57,614 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 26,424 |  |  |  | — |  |  |  | 26,424 |  |  |  | — |  |
| Asset-backed bonds |  |  | 19,239 |  |  |  | — |  |  |  | 19,239 |  |  |  | — |  |
| Mortgage/Agency-backed bonds |  |  | 15,373 |  |  |  | — |  |  |  | 15,373 |  |  |  | — |  |
| Government bonds |  |  | 35,398 |  |  |  | 35,398 |  |  |  | — |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – technology industry |  |  | 5,384 |  |  |  | 5,384 |  |  |  | — |  |  |  | — |  |
| Marketable equity securities – other |  |  | 28,867 |  |  |  | 28,867 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 201,133 |  |  |  | 82,483 |  |  |  | 118,650 |  |  |  | — |  |
| Total |  | $ | 214,100 |  |  | $ | 83,754 |  |  | $ | 130,346 |  |  | $ | — |  |

[0001193125-16-475816:notes:5]
|  |  | Fair Value Measurements at December 31, 2014 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 1,163 |  |  | $ | 1,163 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 16,294 |  |  |  | 16,294 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 111,261 |  |  |  | — |  |  |  | 111,261 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 127,787 |  |  |  | — |  |  |  | 127,787 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 2,465 |  |  |  | — |  |  |  | 2,465 |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Marketable equity securities – technology industry |  |  | 9,661 |  |  |  | 9,661 |  |  |  | — |  |  |  | — |  |
| Marketable equity securities – other |  |  | 28,594 |  |  |  | 28,594 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 296,062 |  |  |  | 54,549 |  |  |  | 241,513 |  |  |  | — |  |
| Total |  | $ | 297,225 |  |  | $ | 55,712 |  |  | $ | 241,513 |  |  | $ | — |  |


## us-gaap:ScheduleOfDeferredTaxAssetsAndLiabilitiesTableTextBlock

[0001193125-16-475816:notes:6]
Deferred income taxes on the balance sheet result from temporary
 differences between the amount of assets and liabilities recognized
 for financial reporting and tax purposes. The principal components
 of our current and non-current deferred taxes are as follows:

[0001193125-16-475816:notes:7]
| (In thousands) |  | 2015 |  |  | 2014 |  |
| Current deferred tax assets |  |  |  |  |  |  |  |  |
| Accounts receivable |  | $ | 7 |  |  | $ | 53 |  |
| Inventory |  |  | 12,558 |  |  |  | 10,405 |  |
| Accrued expenses |  |  | 6,359 |  |  |  | 6,637 |  |
| Total Current Deferred Tax Assets |  |  | 18,924 |  |  |  | 17,095 |  |
| Non-current deferred tax assets |  |  |  |  |  |  |  |  |
| Accrued expenses |  |  | — |  |  |  | 1,232 |  |
| Deferred compensation |  |  | 5,072 |  |  |  | 6,424 |  |
| Stock-based compensation |  |  | 4,704 |  |  |  | 5,832 |  |
| Uncertain tax positions related to state taxes and related interest |  |  | 1,026 |  |  |  | 1,176 |  |
| Pensions |  |  | 5,729 |  |  |  | 4,844 |  |
| Foreign losses |  |  | 5,389 |  |  |  | 3,547 |  |
| State losses and credit carry-forwards |  |  | 4,187 |  |  |  | 4,023 |  |
| Federal loss and research carry-forwards |  |  | 5,886 |  |  |  | 6,998 |  |
| Valuation allowance |  |  | (7,250 | ) |  |  | (7,463 | ) |
| Total Non-current Deferred Tax Assets |  |  | 24,743 |  |  |  | 26,613 |  |
| Total Deferred Tax Assets |  | $ | 43,667 |  |  | $ | 43,708 |  |
| Non-current deferred tax liabilities |  |  |  |  |  |  |  |  |
| Property, plant and equipment |  | $ | (3,315 | ) |  | $ | (3,632 | ) |
| Accrued expenses |  |  | (2,791 | ) |  |  | — |  |
| Intellectual property |  |  | (476 | ) |  |  | (711 | ) |
| Investments |  |  | (70 | ) |  |  | (4,576 | ) |
| Total Non-current Deferred Tax Liabilities |  | $ | (6,652 | ) |  | $ | (8,919 | ) |
| Net Deferred Tax Assets |  | $ | 37,015 |  |  | $ | 34,789 |  |


## us-gaap:ScheduleOfIncomeBeforeIncomeTaxDomesticAndForeignTableTextBlock

[0001193125-16-475816:notes:8]
Income before provision for income taxes for the years ended
 December 31, 2015, 2014 and 2013 is as follows:

[0001193125-16-475816:notes:9]
| (In thousands) |  | 2015 |  |  | 2014 |  |  | 2013 |  |
| U.S. entities |  | $ | 27,400 |  |  | $ | 23,812 |  |  | $ | 51,752 |  |
| International entities |  |  | (1,692 | ) |  |  | 36,094 |  |  |  | 9,103 |  |
| Total |  | $ | 25,708 |  |  | $ | 59,906 |  |  | $ | 60,855 |  |


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001193125-16-475816:notes:10]
Note 10 – Employee Benefit Plans

[0001193125-16-475816:notes:11]
Pension Benefit Plan

[0001193125-16-475816:notes:12]
We maintain a defined benefit pension plan covering employees in
 certain foreign countries.

[0001193125-16-475816:notes:13]
The pension benefit plan obligations and funded status at
 December 31, 2015 and 2014, are as follows:

[0001193125-16-475816:notes:14]
| (In thousands) |  | 2015 |  |  | 2014 |  |
| Change in projected benefit obligation: |  |  |  |  |  |  |  |  |
| Projected benefit obligation at beginning of period |  | $ | (30,507 | ) |  | $ | (23,354 | ) |
| Service cost |  |  | (1,314 | ) |  |  | (1,189 | ) |
| Interest cost |  |  | (615 | ) |  |  | (836 | ) |
| Actuarial gain (loss) |  |  | 2,325 |  |  |  | (8,166 | ) |
| Benefit payments |  |  | 81 |  |  |  | 2 |  |
| Effects of foreign currency exchange rate changes |  |  | 3,179 |  |  |  | 3,036 |  |
| Projected benefit obligation at end of period |  | $ | (26,851 | ) |  | $ | (30,507 | ) |
| Change in plan assets: |  |  |  |  |  |  |  |  |
| Fair value of plan assets at beginning of period |  | $ | 20,338 |  |  | $ | 20,773 |  |
| Actual return on plan assets |  |  | 988 |  |  |  | 2,315 |  |
| Effects of foreign currency exchange rate changes |  |  | (2,113 | ) |  |  | (2,750 | ) |
| Fair value of plan assets at end of period |  | $ | 19,213 |  |  | $ | 20,338 |  |
| Funded (unfunded) status at end of period |  | $ | (7,638 | ) |  | $ | (10,169 | ) |

[0001193125-16-475816:notes:15]
The accumulated benefit obligation was $25.1 million and $29.2
 million at December 31, 2015 and 2014, respectively. The
 decrease in the accumulated benefit obligation and the change in
 actuarial gain (loss) is primarily attributable to an increase in
 the discount rate used in 2015 to determine the accumulated benefit
 obligation.

[0001193125-16-475816:notes:16]
The net amounts recognized in the balance sheet for the unfunded
 pension liability as of December 31, 2015 and 2014 are as
 follows:

[0001193125-16-475816:notes:17]
| (In thousands) |  | 2015 |  |  | 2014 |  |
| Current liability |  | $ | — |  |  | $ | — |  |
| Non-current liability |  |  | (7,638 | ) |  |  | (10,169 | ) |
| Total |  | $ | (7,638 | ) |  | $ | (10,169 | ) |

[0001193125-16-475816:notes:18]
The components of net periodic pension cost and amounts recognized
 in other comprehensive income for the years ended December 31,
 2015, 2014 and 2013 are as follows:

[0001193125-16-475816:notes:19]
| (In thousands) |  | 2015 |  |  | 2014 |  |  | 2013 |  |
| Net periodic benefit cost: |  |  |  |  |  |  |  |  |  |  |  |  |
| Service cost |  | $ | 1,314 |  |  | $ | 1,189 |  |  | $ | 1,198 |  |
| Interest cost |  |  | 615 |  |  |  | 836 |  |  |  | 745 |  |
| Expected return on plan assets |  |  | (1,011 | ) |  |  | (1,086 | ) |  |  | (1,010 | ) |
| Amortization of actuarial losses |  |  | 407 |  |  |  | — |  |  |  | — |  |
| Net periodic benefit cost |  |  | 1,325 |  |  |  | 939 |  |  |  | 933 |  |
| Other changes in plan assets and benefit obligations recognized in other comprehensive income: |  |  |  |  |  |  |  |  |  |  |  |  |
| Net actuarial (gain) loss |  |  | (2,303 | ) |  |  | 7,052 |  |  |  | (1,061 | ) |
| Amortization of actuarial losses |  |  | (396 | ) |  |  | — |  |  |  | — |  |
| Amount recognized in other comprehensive income |  |  | (2,699 | ) |  |  | 7,052 |  |  |  | (1,061 | ) |
| Total recognized in net periodic benefit cost and other comprehensive income |  | $ | (1,374 | ) |  | $ | 7,991 |  |  | $ | (128 | ) |

[0001193125-16-475816:notes:20]
The amounts recognized in accumulated other comprehensive income as
 of December 31, 2015 and 2014 are as follows:

[0001193125-16-475816:notes:21]
| (In thousands) |  | 2015 |  |  | 2014 |  |
| Net actuarial (gain) loss |  | $ | 5,245 |  |  | $ | 7,943 |  |

[0001193125-16-475816:notes:22]
The defined benefit pension plan is accounted for on an actuarial
 basis, which requires the selection of various assumptions,
 including an expected rate of return on plan assets and a discount
 rate. The expected return on our German plan assets that is
 utilized in determining the benefit obligation and net periodic
 benefit cost is derived from periodic studies, which include a
 review of asset allocation strategies, anticipated future long-term
 performance of individual asset classes, risks using standard
 deviations and correlations of returns among the asset classes that
 comprise the plans’ asset mix. While the studies give
 appropriate consideration to recent plan performance and historical
 returns, the assumptions are primarily long-term, prospective rates
 of return.

[0001193125-16-475816:notes:23]
Another key assumption in determining net pension expense is the
 assumed discount rate to be used to discount plan obligations. The
 discount rate has been derived from the returns of high-quality,
 corporate bonds denominated in Euro currency with durations close
 to the duration of our pension obligations.

[0001193125-16-475816:notes:24]
The weighted-average assumptions that were used to determine the
 net periodic benefit cost for the years ended December 31,
 2015, 2014 and 2013 are as follows:

[0001193125-16-475816:notes:25]
|  |  | 2015 |  |  | 2014 |  |  | 2013 |  |
| Discount rates |  |  | 2.20 | % |  |  | 3.70 | % |  |  | 3.50 | % |
| Rate of compensation increase |  |  | 2.25 | % |  |  | 2.25 | % |  |  | 2.25 | % |
| Expected long-term rates of return |  |  | 5.40 | % |  |  | 5.40 | % |  |  | 5.40 | % |

[0001193125-16-475816:notes:26]
The weighted-average assumptions that were used to determine the
 benefit obligation at December 31, 2015 and 2014:

[0001193125-16-475816:notes:27]
|  |  | 2015 |  |  | 2014 |  |
| Discount rates |  |  | 2.64 | % |  |  | 2.20 | % |
| Rate of compensation increase |  |  | 2.25 | % |  |  | 2.25 | % |

[0001193125-16-475816:notes:28]
Actuarial gains and losses are recorded in accumulated other
 comprehensive income. To the extent unamortized gains and losses
 exceed 10% of the higher of the market-related value of assets or
 the projected benefit obligation, the excess is amortized as a
 component of net periodic pension cost over the remaining service
 period of active participants. We estimate that $0.2 million will
 be amortized from accumulated other comprehensive income into net
 periodic pension cost in 2016 for the net actuarial loss.

[0001193125-16-475816:notes:29]
We do not anticipate making a contribution to this pension plan in
 2016. The following pension benefit payments, which reflect
 expected future service, as appropriate, are expected to be paid to
 participants:

[0001193125-16-475816:notes:30]
| (In thousands) |  |  |  |
| 2016 |  | $ | 242 |  |
| 2017 |  |  | 401 |  |
| 2018 |  |  | 563 |  |
| 2019 |  |  | 739 |  |
| 2020 |  |  | 999 |  |
| 2021 – 2025 |  |  | 5,054 |  |
| Total |  | $ | 7,998 |  |

[0001193125-16-475816:notes:31]
|  |  | Fair Value Measurements at December 31, 2015 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  | $ | 3 |  |  | $ | 3 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Bond funds: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 11,633 |  |  |  | 11,633 |  |  |  | — |  |  |  | — |  |
| Government bonds |  |  | 1,960 |  |  |  | 1,960 |  |  |  | — |  |  |  | — |  |
| Equity funds: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Large cap blend |  |  | 4,604 |  |  |  | 4,604 |  |  |  | — |  |  |  | — |  |
| Large cap value |  |  | 258 |  |  |  | 258 |  |  |  | — |  |  |  | — |  |
| Balanced fund |  |  | 755 |  |  |  | 755 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 19,210 |  |  |  | 19,210 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 19,213 |  |  | $ | 19,213 |  |  | $ | — |  |  | $ | — |  |

[0001193125-16-475816:notes:32]
|  |  | Fair Value Measurements at December 31, 2014 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Prices in Active Markets for Identical Assets (Level 1) |  |  | Significant Other Observable Inputs (Level 2) |  |  | Significant Unobservable Inputs (Level 3) |  |
| Cash equivalents |  | $ | 4 |  |  | $ | 4 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Bond funds: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 12,587 |  |  |  | 12,587 |  |  |  | — |  |  |  | — |  |
| Government bonds |  |  | 2,172 |  |  |  | 2,172 |  |  |  | — |  |  |  | — |  |
| Equity funds: |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Large cap blend |  |  | 4,488 |  |  |  | 4,488 |  |  |  | — |  |  |  | — |  |
| Large cap value |  |  | 268 |  |  |  | 268 |  |  |  | — |  |  |  | — |  |
| Balanced fund |  |  | 819 |  |  |  | 819 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 20,334 |  |  |  | 20,334 |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 20,338 |  |  | $ | 20,338 |  |  | $ | — |  |  | $ | — |  |

[0001193125-16-475816:notes:33]
Our investment policy includes various guidelines and procedures
 designed to ensure assets are invested in a manner necessary to
 meet expected future benefits earned by participants. The
 investments guidelines consider a broad range of economic
 conditions. Central to the policy are target allocation ranges by
 asset class, which is currently 75% for bond funds and 25% for
 equity funds.

[0001193125-16-475816:notes:34]
The objectives of the target allocations are to maintain investment
 portfolios that diversify risk through prudent asset allocation
 parameters, achieve asset returns that meet or exceed the
 plans’ actuarial assumptions, and achieve asset returns that
 are competitive with like institutions employing similar investment
 strategies.

[0001193125-16-475816:notes:35]
The investment policy is periodically reviewed by us and a
 designated third-party fiduciary for investment matters. The policy
 is established and administered in a manner that is compliant at
 all times with applicable government regulations.

[0001193125-16-475816:notes:36]
401(k) Savings Plan

[0001193125-16-475816:notes:37]
We maintain the ADTRAN, Inc. 401(k) Retirement Plan (Savings Plan)
 for the benefit of our eligible employees. The Savings Plan is
 intended to qualify under Sections 401(a) and 401(k) of the
 Internal Revenue Code of 1986, as amended (Code), and is intended
 to be a “safe harbor” 401(k) plan under Code
 Section 401(k)(12). The Savings Plan allows employees to save
 for retirement by contributing part of their compensation to the
 plan on a tax-deferred basis. The Savings Plan also requires us to
 contribute a “safe harbor” amount each year. We match
 up to 4% of employee contributions (100% of an employee’s
 first 3% of contributions and 50% of their next 2% of
 contributions), beginning on the employee’s one year
 anniversary date. In calculating our matching contribution, we only
 use compensation up to the statutory maximum under the Code ($265
 thousand for 2015). All contributions under the Savings Plan are
 100% vested. Expenses recorded for employer contributions and plan
 administration costs for the Savings Plan amounted to approximately
 $4.7 million, $4.5 million and $4.5 million in 2015, 2014 and 2013,
 respectively.

[0001193125-16-475816:notes:38]
Deferred Compensation Plans

[0001193125-16-475816:notes:39]
We maintain four deferred compensation programs for certain
 executive management employees and our Board of Directors.

[0001193125-16-475816:notes:40]
For our executive management employees, the ADTRAN, Inc. Deferred
 Compensation Program for Employees is offered as a supplement to
 our tax-qualified 401(k) plan and is available to certain executive
 management employees who have been designated by our Board of
 Directors. This deferred compensation plan allows participants to
 defer all or a portion of certain specified bonuses and up to 25%
 of remaining cash compensation, and permits us to make matching
 contributions on a discretionary basis, without the limitations
 that apply to the 401(k) plan. To date, we have not made any
 matching contributions under this plan. We also maintain the
 ADTRAN, Inc. Equity Deferral Program for Employees. Under this
 plan, participants may elect to defer all or a portion of their
 vested Performance Share awards to the Plan. Such deferrals shall
 continue to be held and deemed to be invested in shares of ADTRAN
 stock unless and until the amounts are distributed or such
 deferrals are moved to another deemed investment pursuant to an
 election made by the Participant.

[0001193125-16-475816:notes:41]
For our Board of Directors, we maintain the ADTRAN, Inc. Deferred
 Compensation Program for Directors. This program allows our Board
 of Directors to defer all or a portion of monetary remuneration
 paid to the Director, including, but not limited to, meeting fees
 and annual retainers. We also maintain the ADTRAN, Inc. Equity
 Deferral Program for Directors. Under this plan, participants may
 elect to defer all or a portion of their vested employer stock
 awards. Such deferrals shall continue to be held and deemed to be
 invested in shares of ADTRAN stock unless and until the amounts are
 distributed or such deferrals are moved to another deemed
 investment pursuant to an election made by the Director.

[0001193125-16-475816:notes:42]
We have set aside the plan assets for all plans in a rabbi trust
 (Trust) and all contributions are credited to bookkeeping accounts
 for the participants. The Trust assets are subject to the claims of
 our creditors in the event of bankruptcy or insolvency. The assets
 of the Trust are deemed to be invested in pre-approved mutual funds
 as directed by each participant, and the participant’s
 bookkeeping account is credited with the earnings and losses
 attributable to those investments. Benefits are scheduled to be
 distributed six months after termination of employment in a single
 lump sum payment or annual installments paid over a three or ten
 year term. Distributions will be made on a pro rata basis from each
 of the hypothetical investments of the Participant’s account
 in cash. Any whole shares of ADTRAN, Inc. common stock that are
 distributed will be distributed in-kind.

[0001193125-16-475816:notes:43]
Assets of the Trust are deemed invested in mutual funds that cover
 an investment spectrum ranging from equities to money market
 instruments. These mutual funds are publicly quoted and reported at
 fair value. The fair value of the assets held by the Trust and the
 amounts payable to the plan participants are as follows:

[0001193125-16-475816:notes:44]
| (In thousands) |  | 2015 |  |  | 2014 |  |
| Fair Value of Plan Assets |  |  |  |  |  |  |  |  |
| Long-term Investments |  | $ | 12,834 |  |  | $ | 16,294 |  |
| Total Fair Value of Plan Assets |  | $ | 12,834 |  |  | $ | 16,294 |  |
| Amounts Payable to Plan Participants |  |  |  |  |  |  |  |  |
| Non-current Liabilities |  | $ | 12,834 |  |  | $ | 16,294 |  |
| Total Amounts Payable to Plan Participants |  | $ | 12,834 |  |  | $ | 16,294 |  |

[0001193125-16-475816:notes:45]
Interest and dividend income of the Trust have been included in
 interest and dividend income in the accompanying 2015, 2014 and
 2013 Consolidated Statements of Income. Changes in the fair value
 of the plan assets held by the Trust have been included in
 accumulated other comprehensive income in the accompanying 2015 and
 2014 Consolidated Balance Sheets. Changes in the fair value of the
 deferred compensation liability are included as selling, general
 and administrative expense in the accompanying 2015, 2014 and 2013
 Consolidated Statements of Income. Based on the changes in the
 total fair value of the Trust’s assets, we recorded deferred
 compensation income (expense) in 2015, 2014 and 2013 of $0.3
 million, $(0.7) million and $(2.8) million, respectively.

[0001193125-16-475816:notes:46]
Retiree Medical Coverage

[0001193125-16-475816:notes:47]
We provide medical, dental and prescription drug coverage to one
 retired former officer and his spouse, for his life, on the same
 terms as provided to our active officers, and to the spouse of a
 former deceased officer for up to 30 years. At December 31,
 2015 and 2014, this liability totaled $0.2 million.


## us-gaap:ScheduleOfComponentsOfIncomeTaxExpenseBenefitTableTextBlock

[0001193125-16-475816:notes:48]
A summary of the components of the provision for income taxes for
 the years ended December 31, 2015, 2014 and 2013 is as
 follows:

[0001193125-16-475816:notes:49]
| (In thousands) |  | 2015 |  |  | 2014 |  |  | 2013 |  |
| Current |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  | $ | 7,504 |  |  | $ | 7,626 |  |  | $ | 15,641 |  |
| State |  |  | 279 |  |  |  | 599 |  |  |  | 2,041 |  |
| International |  |  | (29 | ) |  |  | 12,587 |  |  |  | 1,437 |  |
| Total Current |  |  | 7,754 |  |  |  | 20,812 |  |  |  | 19,119 |  |
| Deferred |  |  |  |  |  |  |  |  |  |  |  |  |
| Federal |  |  | (585 | ) |  |  | (1,083 | ) |  |  | (3,606 | ) |
| State |  |  | (66 | ) |  |  | (123 | ) |  |  | (412 | ) |
| International |  |  | (41 | ) |  |  | (4,320 | ) |  |  | (40 | ) |
| Total Deferred |  |  | (692 | ) |  |  | (5,526 | ) |  |  | (4,058 | ) |
| Total Provision for Income Taxes |  | $ | 7,062 |  |  | $ | 15,286 |  |  | $ | 15,061 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001193125-16-475816:notes:50]
Note 3 – Investments

[0001193125-16-475816:notes:51]
At December 31, 2015, we held the following securities and
 investments, recorded at either fair value or cost:

[0001193125-16-475816:notes:52]
|  |  | Amortized Cost |  |  | Gross Unrealized |  |  | Fair Value / Carrying Value |  |
| (In thousands) |  |  | Gains |  |  | Losses |  |  |
| Deferred compensation plan assets |  | $ | 11,325 |  |  | $ | 1,575 |  |  | $ | (66 | ) |  | $ | 12,834 |  |
| Corporate bonds |  |  | 58,328 |  |  |  | 20 |  |  |  | (734 | ) |  |  | 57,614 |  |
| Municipal fixed-rate bonds |  |  | 26,414 |  |  |  | 28 |  |  |  | (18 | ) |  |  | 26,424 |  |
| Asset-backed bonds |  |  | 19,281 |  |  |  | 2 |  |  |  | (44 | ) |  |  | 19,239 |  |
| Mortgage/Agency-backed bonds |  |  | 15,463 |  |  |  | 1 |  |  |  | (91 | ) |  |  | 15,373 |  |
| Government bonds |  |  | 35,646 |  |  |  | — |  |  |  | (248 | ) |  |  | 35,398 |  |
| Marketable equity securities |  |  | 31,643 |  |  |  | 4,301 |  |  |  | (1,693 | ) |  |  | 34,251 |  |
| Available-for-sale securities held at fair value |  | $ | 198,100 |  |  | $ | 5,927 |  |  | $ | (2,894 | ) |  | $ | 201,133 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 30,000 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1,289 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 232,422 |  |

[0001193125-16-475816:notes:53]
At December 31, 2014, we held the following securities and
 investments, recorded at either fair value or cost:

[0001193125-16-475816:notes:54]
| (In thousands) |  | Amortized Cost |  |  | Gross Unrealized |  |  | Fair Value / Carrying Value |  |
|  |  | Gains |  |  | Losses |  |  |
| Deferred compensation plan assets |  | $ | 13,897 |  |  | $ | 2,409 |  |  | $ | (12 | ) |  | $ | 16,294 |  |
| Corporate bonds |  |  | 111,261 |  |  |  | 186 |  |  |  | (186 | ) |  |  | 111,261 |  |
| .Municipal fixed-rate bonds |  |  | 127,341 |  |  |  | 480 |  |  |  | (34 | ) |  |  | 127,787 |  |
| Municipal variable rate demand notes |  |  | 2,465 |  |  |  | — |  |  |  | — |  |  |  | 2,465 |  |
| Marketable equity securities |  |  | 26,399 |  |  |  | 12,395 |  |  |  | (539 | ) |  |  | 38,255 |  |
| Available-for-sale securities held at fair value |  | $ | 281,363 |  |  | $ | 15,470 |  |  | $ | (771 | ) |  | $ | 296,062 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 30,000 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 1,506 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 327,568 |  |

[0001193125-16-475816:notes:55]
As of December 31, 2015, corporate and municipal fixed-rate
 bonds had the following contractual maturities:

[0001193125-16-475816:notes:56]
| (In thousands) |  | Corporate bonds |  |  | Municipal fixed-rate bonds |  |  | Asset-backed bonds |  |  | Mortgage / Agency-backed bonds |  |  | Government bonds |  |
| Less than one year |  | $ | 14,852 |  |  | $ | 19,544 |  |  | $ | — |  |  | $ | — |  |  | $ | — |  |
| One to two years |  |  | 23,364 |  |  |  | 4,982 |  |  |  | 238 |  |  |  | 1,000 |  |  |  | 2,949 |  |
| Two to three years |  |  | 19,398 |  |  |  | 1,679 |  |  |  | 6,126 |  |  |  | 2,495 |  |  |  | 17,264 |  |
| Three to five years |  |  | — |  |  |  | 219 |  |  |  | 9,337 |  |  |  | — |  |  |  | 15,185 |  |
| Five to ten years |  |  | — |  |  |  | — |  |  |  | 3,235 |  |  |  | 603 |  |  |  | — |  |
| More than ten years |  |  | — |  |  |  | — |  |  |  | 303 |  |  |  | 11,275 |  |  |  | — |  |
| Total |  | $ | 57,614 |  |  | $ | 26,424 |  |  | $ | 19,239 |  |  | $ | 15,373 |  |  | $ | 35,398 |  |

[0001193125-16-475816:notes:57]
Our investment policy provides limitations for issuer
 concentration, which limits, at the time of purchase, the
 concentration in any one issuer to 5% of the market value of our
 total investment portfolio.

[0001193125-16-475816:notes:58]
We review our investment portfolio for potential
 “other-than-temporary” declines in value on an
 individual investment basis. We assess, on a quarterly basis,
 significant declines in value which may be considered
 other-than-temporary and, if necessary, recognize and record the
 appropriate charge to write-down the carrying value of such
 investments. In making this assessment, we take into consideration
 qualitative and quantitative information, including but not limited
 to the following: the magnitude and duration of historical declines
 in market prices, credit rating activity, assessments of liquidity,
 public filings, and statements made by the issuer. We generally
 begin our identification of potential other-than-temporary
 impairments by reviewing any security with a fair value that has
 declined from its original or adjusted cost basis by 25% or more
 for six or more consecutive months. We then evaluate the individual
 security based on the previously identified factors to determine
 the amount of the write-down, if any. For each of the years ended
 December 31, 2015, 2014 and 2013, we recorded a charge of $0.2
 million, $0.1 million and $25 thousand, respectively, related to
 the other-than-temporary impairment of certain marketable equity
 securities and our deferred compensation plan assets.

[0001193125-16-475816:notes:59]
Realized gains and losses on sales of securities are computed under
 the specific identification method. The following table presents
 gross realized gains and losses related to our investments for the
 years ended December 31, 2015, 2014 and 2013:

[0001193125-16-475816:notes:60]
| Year Ended December 31, (In thousands) |  | 2015 |  |  | 2014 |  |  | 2013 |  |
| Gross realized gains |  | $ | 10,906 |  |  | $ | 7,586 |  |  | $ | 8,932 |  |
| Gross realized losses |  | $ | (569 | ) |  | $ | (308 | ) |  | $ | (318 | ) |

[0001193125-16-475816:notes:61]
The following table presents the breakdown of investments with
 unrealized losses at December 31, 2015:

[0001193125-16-475816:notes:62]
| (In thousands) |  | Continuous Unrealized Loss Position for Less than 12 Months |  |  | Continuous Unrealized Loss Position for 12 Months or Greater |  |  | Total |  |
|  |  | Fair Value |  |  | Unrealized Losses |  |  | Fair Value |  |  | Unrealized Losses |  |  | Fair Value |  |  | Unrealized Losses |  |
| Deferred compensation plan assets |  | $ | 1,243 |  |  | $ | (53 | ) |  | $ | 92 |  |  | $ | (13 | ) |  | $ | 1,335 |  |  | $ | (66 | ) |
| Corporate bonds |  |  | 35,952 |  |  |  | (566 | ) |  |  | 3,042 |  |  |  | (168 | ) |  |  | 38,994 |  |  |  | (734 | ) |
| Municipal fixed-rate bonds |  |  | 9,160 |  |  |  | (18 | ) |  |  | — |  |  |  | — |  |  |  | 9,160 |  |  |  | (18 | ) |
| Asset-backed bonds |  |  | 16,857 |  |  |  | (44 | ) |  |  | — |  |  |  | — |  |  |  | 16,857 |  |  |  | (44 | ) |
| Mortgage/Agency-backed bonds |  |  | 15,216 |  |  |  | (91 | ) |  |  | — |  |  |  | — |  |  |  | 15,216 |  |  |  | (91 | ) |
| Government bonds |  |  | 35,397 |  |  |  | (248 | ) |  |  | — |  |  |  | — |  |  |  | 35,397 |  |  |  | (248 | ) |
| Marketable equity securities |  |  | 14,364 |  |  |  | (1,564 | ) |  |  | 374 |  |  |  | (129 | ) |  |  | 14,738 |  |  |  | (1,693 | ) |
| Total |  | $ | 128,189 |  |  | $ | (2,584 | ) |  | $ | 3,508 |  |  | $ | (310 | ) |  | $ | 131,697 |  |  | $ | (2,894 | ) |

[0001193125-16-475816:notes:63]
The following table presents the breakdown of investments with
 unrealized losses at December 31, 2014:

[0001193125-16-475816:notes:64]
| (In thousands) |  | Continuous Unrealized Loss Position for Less than 12 Months |  |  | Continuous Unrealized Loss Position for 12 Months or Greater |  |  | Total |  |
|  |  | Fair Value |  |  | Unrealized Losses |  |  | Fair Value |  |  | Unrealized Losses |  |  | Fair Value |  |  | Unrealized Losses |  |
| Deferred compensation plan assets |  | $ | 49 |  |  | $ | (3 | ) |  | $ | 278 |  |  | $ | (9 | ) |  | $ | 327 |  |  | $ | (12 | ) |
| Corporate bonds |  |  | 31,021 |  |  |  | (186 | ) |  |  | — |  |  |  | — |  |  |  | 31,021 |  |  |  | (186 | ) |
| Municipal fixed-rate bonds |  |  | 30,339 |  |  |  | (34 | ) |  |  | — |  |  |  | — |  |  |  | 30,339 |  |  |  | (34 | ) |
| Marketable equity securities |  |  | 4,824 |  |  |  | (478 | ) |  |  | 208 |  |  |  | (61 | ) |  |  | 5,032 |  |  |  | (539 | ) |
| Total |  | $ | 66,233 |  |  | $ | (701 | ) |  | $ | 486 |  |  | $ | (70 | ) |  | $ | 66,719 |  |  | $ | (771 | ) |

[0001193125-16-475816:notes:65]
The increase in unrealized losses during 2015, as reflected in the
 table above results from changes in market positions associated
 with our equity investment portfolio. At December 31, 2015, a
 total of 594 of our marketable equity securities were in an
 unrealized loss position.

[0001193125-16-475816:notes:66]
The fair value of our Level 2 securities is calculated using a
 weighted average market price for each security. Market prices are
 obtained from a variety of industry standard data providers,
 security master files from large financial institutions, and other
 third-party sources. These multiple market prices are used as
 inputs into a distribution-curve-based algorithm to determine the
 daily market value of each security.

[0001193125-16-475816:notes:67]
Our municipal variable rate demand notes have a structure that
 implies a standard expected market price. The frequent interest
 rate resets make it reasonable to expect the price to stay at par.
 These securities are priced at the expected market price.


## us-gaap:ScheduleOfDerivativeInstrumentsInStatementOfFinancialPositionFairValueTextBlock

[0001193125-16-475816:notes:68]
The fair values of our derivative instruments recorded in the
 Consolidated Balance Sheet as of December 31, 2015 and 2014
 were as follows:

[0001193125-16-475816:notes:69]
| (In thousands) |  | Balance Sheet Location |  | 2015 |  |  | 2014 |  |
| Derivatives Not Designated as Hedging Instruments (Level 2): |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts – asset derivatives |  | Other receivables |  | $ | — |  |  | $ | 249 |  |
| Foreign exchange contracts – liability derivatives |  | Accounts payable |  | $ | — |  |  | $ | (10 | ) |


## us-gaap:ScheduleofFiniteLivedIntangibleAssetsFutureAmortizationExpenseTableTextBlock

[0001193125-16-475816:notes:70]
As of December 31, 2015, the estimated future amortization
 expense of intangible assets is as follows:

[0001193125-16-475816:notes:71]
| (In thousands) |  | Amount |  |
| 2016 |  | $ | 1,657 |  |
| 2017 |  |  | 1,150 |  |
| 2018 |  |  | 694 |  |
| 2019 |  |  | 301 |  |
| 2020 |  |  | 279 |  |
| Thereafter |  |  | 1,002 |  |
| Total |  | $ | 5,083 |  |


## us-gaap:RevenueRecognitionPolicyTextBlock

[0001193125-16-475816:notes:72]
Revenue Recognition

[0001193125-16-475816:notes:73]
Revenue is generally recognized when persuasive evidence of an
 arrangement exists, delivery has occurred, the product price is
 fixed or determinable, collection of the resulting receivable is
 reasonably assured, and product returns are reasonably estimable.
 For product sales, revenue is generally recognized upon shipment of
 the product to our customer in accordance with the title transfer
 terms of the sales agreement, generally Ex Works, per International
 Commercial Terms. In the case of consigned inventory, revenue is
 recognized when the end customer assumes ownership of the product.
 Contracts that contain multiple deliverables are evaluated to
 determine the units of accounting, and the consideration from the
 arrangement is allocated to each unit of accounting based on the
 relative selling price and corresponding terms of the contract. We
 use vendor-specific objective evidence of selling price. When this
 evidence is not available, we are generally not able to determine
 third-party evidence of selling price because of the extent of
 customization among competing products or services from other
 companies. In these instances, we use best estimates to allocate
 consideration to each respective unit of accounting. These
 estimates include analysis of respective bills of material and
 review and analysis of similar product and service offerings. We
 record revenue associated with installation services when
 respective contractual obligations are complete. In instances where
 customer acceptance is required, revenue is deferred until
 respective acceptance criteria have been met. Contracts that
 include both installation services and product sales are evaluated
 for revenue recognition in accordance with contract terms. As a
 result, installation services may be considered a separate
 deliverable or may be considered a combined single unit of
 accounting with the delivered product. Generally, either the
 purchaser, ADTRAN, or a third party can perform the installation of
 our products. Shipping fees are recorded as revenue and the related
 cost is included in cost of sales. Sales taxes invoiced to
 customers are included in revenues, and represent less than one
 percent of total revenues. The corresponding sales taxes paid are
 included in cost of goods sold. Value added taxes collected from
 customers in international jurisdictions are recorded in accrued
 expenses as a liability. Revenue is recorded net of discounts.
 Sales returns are accrued based on historical sales return
 experience, which we believe provides a reasonable estimate of
 future returns.

[0001193125-16-475816:notes:74]
A portion of Enterprise Networks products are sold to a
 non-exclusive distribution network of major technology distributors
 in the United States. These large organizations then distribute or
 provide fulfillment services to an extensive network of VARs and
 SIs. VARs and SIs may be affiliated with us as a channel partner,
 or they may purchase from the distributor in an unaffiliated
 fashion. Additionally, with certain limitations our distributors
 may return unused and unopened product for stock-balancing purposes
 when such returns are accompanied by offsetting orders for products
 of equal or greater value.

[0001193125-16-475816:notes:75]
We participate in cooperative advertising and market development
 programs with certain customers. We use these programs to reimburse
 customers for certain forms of advertising, and in general, to
 allow our customers credits up to a specified percentage of their
 net purchases. Our costs associated with these programs are
 estimated and included in marketing expenses in our consolidated
 statements of income. We also participate in rebate programs to
 provide sales incentives for certain products. Our costs associated
 with these programs are estimated and accrued at the time of sale,
 and are recorded as a reduction of sales in our consolidated
 statements of income.


## us-gaap:ReceivablesPolicyTextBlock

[0001193125-16-475816:notes:76]
Accounts Receivable

[0001193125-16-475816:notes:77]
We record accounts receivable at net realizable value. Prior to
 issuing payment terms to a new customer, we perform a detailed
 credit review of the customer. Credit limits and payment terms are
 established for each new customer, and are reviewed periodically
 based on customer collection experience and other financial
 factors, for revision. At December 31, 2015, three customers
 accounted for 37.3% of our total accounts receivable. At
 December 31, 2014, two customers accounted for 24.5% of our
 total accounts receivable.

[0001193125-16-475816:notes:78]
We maintain an allowance for doubtful accounts for losses resulting
 from the inability of our customers to make required payments. We
 regularly review the allowance for doubtful accounts and consider
 factors such as the age of accounts receivable balances, the
 current economic conditions that may affect a customer’s
 ability to pay, significant one-time events and our historical
 experience. If the financial condition of a customer deteriorates,
 resulting in an impairment of their ability to make payments, we
 may be required to record an allowance for doubtful accounts. If
 circumstances change with regard to individual receivable balances
 that have previously been determined to be uncollectible (and for
 which a specific reserve has been established), a reduction in our
 allowance for doubtful accounts may be required. Our allowance for
 doubtful accounts was $19 thousand and $0.1 million at
 December 31, 2015 and December 31, 2014,
 respectively.


## us-gaap:PropertyPlantAndEquipmentPolicyTextBlock

[0001193125-16-475816:notes:79]
Property, Plant and Equipment

[0001193125-16-475816:notes:80]
Property, plant and equipment, which is stated at cost, is
 depreciated using the straight-line method over the estimated
 useful lives of the assets. We depreciate building and land
 improvements from five to 39 years, office machinery and equipment
 from three to seven years, engineering machinery and equipment from
 three to seven years, and computer software from three to five
 years. Expenditures for repairs and maintenance are charged to
 expense as incurred. Betterments that materially prolong the lives
 of the assets are capitalized. Gains and losses on the disposal of
 property, plant and equipment are recorded in operating expenses.
 See Note 6 of Notes to Consolidated Financial Statements for
 additional information.


## us-gaap:SummaryOfIncomeTaxContingenciesTextBlock

[0001193125-16-475816:notes:81]
The change in the unrecognized income tax benefits for the years
 ended December 31, 2015, 2014 and 2013 is reconciled
 below:

[0001193125-16-475816:notes:82]
| (In thousands) |  | 2015 |  |  | 2014 |  |  | 2013 |  |
| Balance at beginning of period |  | $ | 3,334 |  |  | $ | 3,240 |  |  | $ | 2,926 |  |
| Increases for tax position related to: |  |  |  |  |  |  |  |  |  |  |  |  |
| Prior years |  |  | — |  |  |  | — |  |  |  | 89 |  |
| Current year |  |  | 280 |  |  |  | 522 |  |  |  | 549 |  |
| Decreases for tax positions related to: |  |  |  |  |  |  |  |  |  |  |  |  |
| Prior years |  |  | (29 | ) |  |  | — |  |  |  | — |  |
| Settlements with taxing authorities |  |  | (103 | ) |  |  | — |  |  |  | (141 | ) |
| Expiration of applicable statute of limitations |  |  | (945 | ) |  |  | (428 | ) |  |  | (183 | ) |
| Balance at end of period |  | $ | 2,537 |  |  | $ | 3,334 |  |  | $ | 3,240 |  |


## us-gaap:InventoryPolicyTextBlock

[0001193125-16-475816:notes:83]
Inventory

[0001193125-16-475816:notes:84]
Inventory is carried at the lower of cost or market, with cost
 being determined using the first-in, first-out method. Standard
 costs for material, labor and manufacturing overhead are used to
 value inventory. Standard costs are updated at least quarterly;
 therefore, inventory costs approximate actual costs at the end of
 each reporting period. We establish reserves for estimated excess,
 obsolete or unmarketable inventory equal to the difference between
 the cost of the inventory and the estimated fair value of the
 inventory based upon assumptions about future demand and market
 conditions. When we dispose of excess and obsolete inventories, the
 related disposals are charged against the inventory reserve. See
 Note 5 of Notes to Consolidated Financial Statements for additional
 information.


## us-gaap:ScheduleOfProductWarrantyLiabilityTableTextBlock

[0001193125-16-475816:notes:85]
A summary of warranty expense and write-off activity for the years
 ended December 31, 2015, 2014 and 2013 is as follows:

[0001193125-16-475816:notes:86]
| Year Ended December 31, |  | 2015 |  |  | 2014 |  |  | 2013 |  |
| (In thousands) |  |  |  |  |  |  |  |  |  |
| Balance at beginning of period |  | $ | 8,415 |  |  | $ | 8,977 |  |  | $ | 9,653 |  |
| Plus: Amounts charged to cost and expenses |  |  | 2,998 |  |  |  | 3,103 |  |  |  | 4,051 |  |
| Less: Deductions |  |  | (2,674 | ) |  |  | (3,665 | ) |  |  | (4,727 | ) |
| Balance at end of period |  | $ | 8,739 |  |  | $ | 8,415 |  |  | $ | 8,977 |  |


## us-gaap:ScheduleOfSharebasedCompensationRestrictedStockAndRestrictedStockUnitsActivityTableTextBlock

[0001193125-16-475816:notes:87]
The following table is a summary of our RSUs and restricted stock
 outstanding as of December 31, 2014 and 2015 and the changes
 that occurred during 2015:

[0001193125-16-475816:notes:88]
| (In thousands, except per share amounts) |  | Number of shares |  |  | Weighted Average Grant Date Fair Value |  |
| Unvested RSUs and restricted stock outstanding, December 31, 2014 |  |  | 104 |  |  | $ | 22.81 |  |
| RSUs and restricted stock granted |  |  | 57 |  |  | $ | 17.47 |  |
| RSUs and restricted stock vested |  |  | (38 | ) |  | $ | 20.71 |  |
| RSUs and restricted stock forfeited |  |  | (12 | ) |  | $ | 23.10 |  |
| Adjustments to shares granted due to shares earned at vesting |  |  | (5 | ) |  | $ | 19.90 |  |
| Unvested RSUs and restricted stock outstanding, December 31, 2015 |  |  | 106 |  |  | $ | 21.09 |  |


## us-gaap:GoodwillAndIntangibleAssetsDisclosureTextBlock

[0001193125-16-475816:notes:89]
Note 7 – Goodwill and Intangible Assets

[0001193125-16-475816:notes:90]
Goodwill, all of which relates to our acquisition of Bluesocket,
 Inc. and is included in our Enterprise Networks division, was $3.5
 million at December 31, 2015 and 2014. We evaluate the
 carrying value of goodwill during the fourth quarter of each year
 and between annual evaluations if events occur or circumstances
 change that would more likely than not reduce the fair value of the
 reporting unit below its carrying amount. We have elected to first
 assess the qualitative factors to determine whether it is more
 likely than not that the fair value of the reporting unit to which
 the goodwill is assigned is less than its carrying amount as a
 basis for determining whether it is necessary to perform the
 two-step impairment test. If we determine that it is more likely
 than not that its fair value is less than its carrying amount, then
 the two-step impairment test will be performed. Based on the
 results of our qualitative assessment in 2015, we concluded that it
 was not necessary to perform the two-step impairment test. There
 have been no impairment losses recognized since the acquisition in
 2011.

[0001193125-16-475816:notes:91]
Intangible assets are included in other assets in the accompanying
 Consolidated Balance Sheets and include intangible assets acquired
 in conjunction with our acquisition of Objectworld Communications
 Corporation on September 15, 2009, Bluesocket, Inc. on
 August 4, 2011, and the NSN BBA business on May 4,
 2012.

[0001193125-16-475816:notes:92]
The following table presents our intangible assets as of
 December 31, 2015 and 2014:

[0001193125-16-475816:notes:93]
| (In thousands) |  | 2015 |  |  | 2014 |  |
|  |  | Gross Value |  |  | Accumulated Amortization |  |  | Net Value |  |  | Gross Value |  |  | Accumulated Amortization |  |  | Net Value |  |
| Customer relationships |  | $ | 5,828 |  |  | $ | (2,627 | ) |  | $ | 3,201 |  |  | $ | 6,310 |  |  | $ | (2,136 | ) |  | $ | 4,174 |  |
| Developed technology |  |  | 5,720 |  |  |  | (4,329 | ) |  |  | 1,391 |  |  |  | 6,005 |  |  |  | (3,577 | ) |  |  | 2,428 |  |
| Intellectual property |  |  | 2,340 |  |  |  | (1,854 | ) |  |  | 486 |  |  |  | 2,340 |  |  |  | (1,520 | ) |  |  | 820 |  |
| Trade names |  |  | 270 |  |  |  | (265 | ) |  |  | 5 |  |  |  | 270 |  |  |  | (205 | ) |  |  | 65 |  |
| Other |  |  | 11 |  |  |  | (11 | ) |  |  | — |  |  |  | 12 |  |  |  | (11 | ) |  |  | 1 |  |
| Total |  | $ | 14,169 |  |  | $ | (9,086 | ) |  | $ | 5,083 |  |  | $ | 14,937 |  |  | $ | (7,449 | ) |  | $ | 7,488 |  |

[0001193125-16-475816:notes:94]
Amortization expense was $1.9 million, $2.3 million and $2.4
 million for the years ended December 31, 2015, 2014 and 2013,
 respectively.


## us-gaap:ComprehensiveIncomePolicyPolicyTextBlock

[0001193125-16-475816:notes:95]
Other Comprehensive Income

[0001193125-16-475816:notes:96]
Other comprehensive income consists of unrealized gains (losses) on
 available-for-sale securities, reclassification adjustments for
 amounts included in net income related to impairments of
 available-for-sale securities and realized gains (losses) on
 available-for-sale securities, defined benefit plan adjustments and
 foreign currency translation adjustments.

[0001193125-16-475816:notes:97]
The following table presents changes in accumulated other
 comprehensive income, net of tax, by component for the years ended
 December 31, 2013, 2014 and 2015:

[0001193125-16-475816:notes:98]
| (In thousands) |  | Unrealized Gains (Losses) on Available- for-Sale Securities |  |  | Defined Benefit Plan Adjustments |  |  | Foreign Currency Adjustments |  |  | Total |  |
| Balance at December 31, 2012 |  | $ | 10,108 |  |  | $ | (1,952 | ) |  | $ | 3,112 |  |  | $ | 11,268 |  |
| Other comprehensive income (loss) before reclassifications |  |  | 5,508 |  |  |  | 1,061 |  |  |  | (2,205 | ) |  |  | 4,364 |  |
| Amounts reclassified from accumulated other comprehensive income |  |  | (4,879 | ) |  |  | — |  |  |  | — |  |  |  | (4,879 | ) |
| Balance at December 31, 2013 |  | $ | 10,737 |  |  | $ | (891 | ) |  | $ | 907 |  |  | $ | 10,753 |  |
| Other comprehensive income (loss) before reclassifications |  |  | 2,363 |  |  |  | (4,866 | ) |  |  | (4,189 | ) |  |  | (6,692 | ) |
| Amounts reclassified from accumulated other comprehensive income |  |  | (4,136 | ) |  |  | — |  |  |  | — |  |  |  | (4,136 | ) |
| Balance at December 31, 2014 |  | $ | 8,964 |  |  | $ | (5,757 | ) |  | $ | (3,282 | ) |  | $ | (75 | ) |
| Other comprehensive income (loss) before reclassifications |  |  | (844 | ) |  |  | 1,589 |  |  |  | (3,724 | ) |  |  | (2,979 | ) |
| Amounts reclassified from accumulated other comprehensive income |  |  | (6,188 | ) |  |  | 273 |  |  |  | — |  |  |  | (5,915 | ) |
| Balance at December 31, 2015 |  | $ | 1,932 |  |  | $ | (3,895 | ) |  | $ | (7,006 | ) |  | $ | (8,969 | ) |

[0001193125-16-475816:notes:99]
The following tables present the details of reclassifications out
 of accumulated other comprehensive income for the years ended
 December 31, 2015, 2014 and 2013:

[0001193125-16-475816:notes:100]
| (In thousands) |  | 2015 |
| Details about Accumulated Other Comprehensive Income Components |  | Amount Reclassified from Accumulated Other Comprehensive Income |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for-sale securities: |  |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 10,348 |  |  | Net realized investment gain |
| Impairment expense |  |  | (203 | ) |  | Net realized investment gain |
| Defined benefit plan adjustments – actuarial losses |  |  | (396 | ) |  | (1) |
| Total reclassifications for the period, before tax |  |  | 9,749 |  |  |  |
| Tax (expense) benefit |  |  | (3,834 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 5,915 |  |  |  |

[0001193125-16-475816:notes:101]
| (1) | Included in the computation of net periodic pension cost. See Note 10 of Notes to Consolidated Financial Statements. |

[0001193125-16-475816:notes:102]
| (In thousands) |  | 2014 |
| Details about Accumulated Other Comprehensive Income Components |  | Amount Reclassified from Accumulated Other Comprehensive Income |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for-sale securities: |  |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 6,895 |  |  | Net realized investment gain |
| Impairment expense |  |  | (115 | ) |  | Net realized investment gain |
| Total reclassifications for the period, before tax |  |  | 6,780 |  |  |  |
| Tax (expense) benefit |  |  | (2,644 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 4,136 |  |  |  |

[0001193125-16-475816:notes:103]
| (In thousands) |  | 2013 |
| Details about Accumulated Other Comprehensive Income Components |  | Amount Reclassified from Accumulated Other Comprehensive Income |  |  | Affected Line Item in the Statement Where Net Income Is Presented |
| Unrealized gains (losses) on available-for-sale securities: |  |  |  |  |  |  |
| Net realized gain on sales of securities |  | $ | 8,023 |  |  | Net realized investment gain |
| Impairment expense |  |  | (25 | ) |  | Net realized investment gain |
| Total reclassifications for the period, before tax |  |  | 7,998 |  |  |  |
| Tax (expense) benefit |  |  | (3,119 | ) |  |  |
| Total reclassifications for the period, net of tax |  | $ | 4,879 |  |  |  |

[0001193125-16-475816:notes:104]
The following tables present the tax effects related to the change
 in each component of other comprehensive income for the years ended
 December 31, 2015, 2014 and 2013:

[0001193125-16-475816:notes:105]
|  |  | 2015 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |
| Unrealized gains (losses) on available-for-sale securities |  | $ | (1,384 | ) |  | $ | 540 |  |  | $ | (844 | ) |
| Reclassification adjustment for amounts included in net income |  |  | (9,749 | ) |  |  | 3,834 |  |  |  | (5,915 | ) |
| Defined benefit plan adjustments |  |  | 2,303 |  |  |  | (714 | ) |  |  | 1,589 |  |
| Foreign currency translation adjustment |  |  | (3,724 | ) |  |  | — |  |  |  | (3,724 | ) |
| Total Other Comprehensive Income (Loss) |  | $ | (12,554 | ) |  | $ | 3,660 |  |  | $ | (8,894 | ) |

[0001193125-16-475816:notes:106]
|  |  | 2014 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |
| Unrealized gains (losses) on available-for-sale securities |  | $ | 3,874 |  |  | $ | (1,511 | ) |  | $ | 2,363 |  |
| Reclassification adjustment for amounts included in net income |  |  | (6,780 | ) |  |  | 2,644 |  |  |  | (4,136 | ) |
| Defined benefit plan adjustments |  |  | (7,052 | ) |  |  | 2,186 |  |  |  | (4,866 | ) |
| Foreign currency translation adjustment |  |  | (4,189 | ) |  |  | — |  |  |  | (4,189 | ) |
| Total Other Comprehensive Income (Loss) |  | $ | (14,147 | ) |  | $ | 3,319 |  |  | $ | (10,828 | ) |

[0001193125-16-475816:notes:107]
|  |  | 2013 |  |
| (In thousands) |  | Before-Tax Amount |  |  | Tax (Expense) Benefit |  |  | Net-of-Tax Amount |  |
| Unrealized gains (losses) on available-for-sale securities |  | $ | 9,030 |  |  | $ | (3,522 | ) |  | $ | 5,508 |  |
| Reclassification adjustment for amounts included in net income |  |  | (7,998 | ) |  |  | 3,119 |  |  |  | (4,879 | ) |
| Defined benefit plan adjustments |  |  | 1,061 |  |  |  | — |  |  |  | 1,061 |  |
| Foreign currency translation adjustment |  |  | (2,205 | ) |  |  | — |  |  |  | (2,205 | ) |
| Total Other Comprehensive Income (Loss) |  | $ | (112 | ) |  | $ | (403 | ) |  | $ | (515 | ) |


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001193125-16-475816:notes:108]
Note 1 – Nature of Business and Summary of Significant
 Accounting Policies

[0001193125-16-475816:notes:109]
ADTRAN, Inc. is a leading global provider of networking and
 communications equipment. Our solutions enable voice, data, video
 and Internet communications across a variety of network
 infrastructures. These solutions are deployed by many of the United
 States’ and the world’s largest SPs, distributed
 enterprises and small and medium-sized businesses, public and
 private enterprises, and millions of individual users
 worldwide.

[0001193125-16-475816:notes:110]
Principles of Consolidation

[0001193125-16-475816:notes:111]
Our consolidated financial statements include ADTRAN and its wholly
 owned subsidiaries. All inter-company accounts and transactions
 have been eliminated in consolidation.

[0001193125-16-475816:notes:112]
Changes in Classifications

[0001193125-16-475816:notes:113]
We reclassified $2.3 million from other receivables to accounts
 receivable and $0.8 million from inventory to prepaid expenses and
 other current assets at December 31, 2014 to conform to the
 current period presentation.

[0001193125-16-475816:notes:114]
Out of Period Adjustment

[0001193125-16-475816:notes:115]
In connection with the preparation of our Consolidated Financial
 Statements, we recorded corrections of certain out of period,
 immaterial misstatements that occurred in prior periods, the most
 significant of which resulted in an increase in Other Expense of
 $1.3 million in the first quarter of 2015. The aggregate impact of
 the corrections was a $0.3 million reduction to pre-tax income for
 the year ended December 31, 2015 and was not material to the
 current or prior year’s annual results.

[0001193125-16-475816:notes:116]
Use of Estimates

[0001193125-16-475816:notes:117]
The preparation of financial statements in conformity with
 accounting principles generally accepted in the United States of
 America requires management to make estimates and assumptions that
 affect the reported amounts of assets and liabilities, the
 disclosure of contingent assets and liabilities at the date of the
 financial statements, and the reported amounts of revenue and
 expense during the reporting period. Our more significant estimates
 include the obsolete and excess inventory reserves, warranty
 reserves, customer rebates, determination of the deferred revenue
 components of multiple element sales agreements, estimated costs to
 complete obligations associated with deferred revenues, estimated
 income tax provision and income tax contingencies, the fair value
 of stock-based compensation, impairment of goodwill, valuation and
 estimated lives of intangible assets, estimated pension liability,
 fair value of investments, and the evaluation of
 other-than-temporary declines in the value of investments. Actual
 amounts could differ significantly from these estimates.

[0001193125-16-475816:notes:118]
Cash and Cash Equivalents

[0001193125-16-475816:notes:119]
Cash and cash equivalents represent demand deposits, money market
 funds, and short-term investments classified as available-for-sale
 with original maturities of three months or less. We maintain
 depository investments with certain financial institutions.
 Although these depository investments may exceed government insured
 depository limits, we have evaluated the credit worthiness of these
 applicable financial institutions, and determined the risk of
 material financial loss due to the exposure of such credit risk to
 be minimal. As of December 31, 2015, $80.8 million of our cash
 and cash equivalents, primarily certain domestic money market funds
 and foreign depository accounts, were in excess of government
 provided insured depository limits.

[0001193125-16-475816:notes:120]
Financial Instruments

[0001193125-16-475816:notes:121]
The carrying amounts reported in the consolidated balance sheets
 for cash and cash equivalents, accounts receivable, and accounts
 payable approximate fair value due to the immediate or short-term
 maturity of these financial instruments. The carrying amount
 reported for bonds payable was $28.9 million, compared to an
 estimated fair value of $28.7 million, based on a debt security
 with a comparable interest rate and maturity and a
 Standard & Poor’s credit rating of AAA.

[0001193125-16-475816:notes:122]
Investments with contractual maturities beyond one year, such as
 our municipal variable rate demand notes, may be classified as
 short-term based on their highly liquid nature and because such
 marketable securities represent the investment of cash that is
 available for current operations. Despite the long-term nature of
 their stated contractual maturities, we routinely buy and sell
 these securities and we believe we have the ability to quickly sell
 them to the remarketing agent, tender agent, or issuer at par value
 plus accrued interest in the event we decide to liquidate our
 investment in a particular variable rate demand note. All income
 generated from these investments was recorded as interest income.
 We have not been required to record any losses relating to
 municipal variable rate demand notes.

[0001193125-16-475816:notes:123]
Long-term investments represent a restricted certificate of deposit
 held at cost, deferred compensation plan assets, corporate bonds,
 municipal fixed-rate bonds, asset-backed bonds, mortgage/agency
 backed bonds, government bonds, marketable equity securities, and
 other equity investments. Marketable equity securities are reported
 at fair value as determined by the most recently traded price of
 the securities at the balance sheet date, although the securities
 may not be readily marketable due to the size of the available
 market. Unrealized gains and losses, net of tax, are reported as a
 separate component of stockholders’ equity. Realized gains
 and losses on sales of securities are computed under the specific
 identification method and are included in current income. We
 periodically review our investment portfolio for investments
 considered to have sustained an other-than-temporary decline in
 value. Impairment charges for other-than-temporary declines in
 value are recorded as realized losses in the accompanying
 consolidated statements of income. All of our investments at
 December 31, 2015 and 2014 are classified as
 available-for-sale securities. See Note 3 of Notes to Consolidated
 Financial Statements for additional information.

[0001193125-16-475816:notes:124]
Other Receivables

[0001193125-16-475816:notes:125]
Other receivables are comprised primarily of amounts due from
 subcontract manufacturers for product component transfers, accrued
 interest on investments and on a restricted certificate of deposit,
 amounts due from various jurisdictions for value-added tax, and
 amounts due from employee stock option exercises. At
 December 31, 2014, other receivables also included a
 receivable due from NSN related to working capital items settled
 during the fourth quarter of 2014 and collected in January
 2015.

[0001193125-16-475816:notes:126]
Liability for Warranty

[0001193125-16-475816:notes:127]
Our products generally include warranties of 90 days to ten years
 for product defects. We accrue for warranty returns at the time
 revenue is recognized based on our estimate of the cost to repair
 or replace the defective products. We engage in extensive product
 quality programs and processes, including actively monitoring and
 evaluating the quality of our component suppliers. Our products
 continue to become more complex in both size and functionality as
 many of our product offerings migrate from line card applications
 to total systems. The increasing complexity of our products will
 cause warranty incidences, when they arise, to be more costly. Our
 estimates regarding future warranty obligations may change due to
 product failure rates, material usage, and other rework costs
 incurred in correcting a product failure. In addition, from time to
 time, specific warranty accruals may be recorded if unforeseen
 problems arise. Should our actual experience relative to these
 factors be worse than our estimates, we will be required to record
 additional warranty expense. Alternatively, if we provide for more
 reserves than we require, we will reverse a portion of such
 provisions in future periods. The liability for warranty
 obligations totaled $8.7 million and $8.4 million at
 December 31, 2015 and 2014, respectively. These liabilities
 are included in accrued expenses in the accompanying consolidated
 balance sheets.

[0001193125-16-475816:notes:128]
Pension Benefit Plan Obligations

[0001193125-16-475816:notes:129]
We maintain a defined benefit pension plan covering employees in
 certain foreign countries. Pension benefit plan obligations are
 based on various assumptions used by our actuaries in calculating
 these amounts. These assumptions include discount rates,
 compensation rate increases, expected return on plan assets,
 retirement rates and mortality rates. Actual results that differ
 from the assumptions and changes in assumptions could affect future
 expenses and obligations.

[0001193125-16-475816:notes:130]
Stock-Based Compensation

[0001193125-16-475816:notes:131]
We have two Board and stockholder approved stock option plans from
 which stock options and other awards are available for grant to
 employees and directors. All employee and director stock options
 granted under our stock option plans have an exercise price equal
 to the fair market value of the award, as defined in the plan, of
 the underlying common stock on the grant date. There are currently
 no vesting provisions tied to performance or market conditions for
 any option awards. Vesting for all outstanding option grants is
 based only on continued service as an employee or director of
 ADTRAN. All of our outstanding stock option awards are classified
 as equity awards.

[0001193125-16-475816:notes:132]
Under the provisions of our approved plans, we made grants of
 performance-based restricted stock units to certain of our
 executive officers in 2015, 2014, and 2013. The restricted stock
 units are subject to a market condition based on the relative total
 shareholder return of ADTRAN against all the companies in the
 NASDAQ Telecommunications Index and vest at the end of a three-year
 performance period. The restricted stock units are converted into
 shares of common stock upon vesting. Depending on the relative
 total shareholder return over the performance period, the executive
 officers may earn from 0% to 150% of the number of restricted stock
 units granted. The fair value of the award is based on the market
 price of our common stock on the date of grant, adjusted for the
 expected outcome of the impact of market conditions using a Monte
 Carlo Simulation valuation method. The recipients of the restricted
 stock units also earn dividend credits during the performance
 period, which will be paid in cash upon the issuance of common
 stock for the restricted stock units.

[0001193125-16-475816:notes:133]
Stock-based compensation expense recognized in 2015, 2014 and 2013
 was approximately $6.7 million, $8.6 million and $9.1 million,
 respectively. As of December 31, 2015, total compensation cost
 related to non-vested stock options, restricted stock units and
 restricted stock not yet recognized was approximately $14.8
 million, which is expected to be recognized over an average
 remaining recognition period of 2.7 years. See Note 2 of Notes to
 Consolidated Financial Statements for additional information.

[0001193125-16-475816:notes:134]
Impairment of Long-Lived Assets

[0001193125-16-475816:notes:135]
We review long-lived assets used in operations for impairment
 whenever events or changes in circumstances indicate that the
 carrying amount of an asset may not be recoverable and the
 undiscounted cash flows estimated to be generated by the asset are
 less than the asset’s carrying value. An impairment loss
 would be recognized in the amount by which the recorded value of
 the asset exceeds the fair value of the asset, measured by the
 quoted market price of an asset or an estimate based on the best
 information available in the circumstances. There were no
 impairment losses recognized during 2015, 2014 or 2013.

[0001193125-16-475816:notes:136]
Goodwill and Purchased Intangible Assets

[0001193125-16-475816:notes:137]
We evaluate the carrying value of goodwill during the fourth
 quarter of each year and between annual evaluations if events occur
 or circumstances change that would more likely than not reduce the
 fair value of the reporting unit below its carrying amount. When
 evaluating whether goodwill is impaired, we first assess
 qualitative factors to determine whether it is necessary to perform
 the two-step quantitative goodwill impairment test. If we determine
 that the two-step quantitative test is necessary, then we compare
 the fair value of the reporting unit to which the goodwill is
 assigned to the reporting unit’s carrying amount, including
 goodwill. If the carrying amount of the reporting unit exceeds its
 fair value, then the amount of the impairment loss is measured.
 There were no impairment losses recognized during 2015, 2014 or
 2013. Purchased intangible assets with finite lives are carried at
 cost, less accumulated amortization. Amortization is recorded over
 the estimated useful lives of the respective assets, which is 2.5
 to 14 years.

[0001193125-16-475816:notes:138]
Research and Development Costs

[0001193125-16-475816:notes:139]
Research and development costs include compensation for engineers
 and support personnel, outside contracted services, depreciation
 and material costs associated with new product development, the
 enhancement of current products, and product cost reductions. We
 continually evaluate new product opportunities and engage in
 intensive research and product development efforts. Research and
 development costs totaled $129.9 million, $132.3 million and $131.1
 million for the years ended December 31, 2015, 2014 and 2013,
 respectively.

[0001193125-16-475816:notes:140]
Income Taxes

[0001193125-16-475816:notes:141]
The provision for income taxes has been determined using the asset
 and liability approach of accounting for income taxes. Under this
 approach, deferred taxes represent the future tax consequences
 expected to occur when the reported amounts of assets and
 liabilities are recovered or paid. The provision for income taxes
 represents income taxes paid or payable for the current year plus
 the change in deferred taxes during the year. Deferred taxes result
 from the difference between financial and tax bases of our assets
 and liabilities and are adjusted for changes in tax rates and tax
 laws when such changes are enacted. Valuation allowances are
 recorded to reduce deferred tax assets when it is more likely than
 not that a tax benefit will not be realized.

[0001193125-16-475816:notes:142]
We establish reserves to remove some or all of the tax benefit of
 any of our tax positions at the time we determine that the
 positions become uncertain. We adjust these reserves, including any
 impact on the related interest and penalties, as facts and
 circumstances change.

[0001193125-16-475816:notes:143]
Foreign Currency

[0001193125-16-475816:notes:144]
We record transactions denominated in foreign currencies on a
 monthly basis using exchange rates from throughout the year. Assets
 and liabilities denominated in foreign currencies are translated at
 the balance sheet dates using the closing rates of exchange between
 those foreign currencies and the functional currency with any
 transaction gains or losses reported in other income (expense). Our
 primary exposures to foreign currency exchange rate movements are
 with our Mexican subsidiary, whose functional currency is the
 United States dollar, German subsidiary, whose functional currency
 is the Euro, and our Australian subsidiary, whose functional
 currency is the Australian dollar. Adjustments resulting from
 translating financial statements of international subsidiaries are
 recorded as a component of accumulated other comprehensive income
 (loss).

[0001193125-16-475816:notes:145]
Unearned Revenue

[0001193125-16-475816:notes:146]
Unearned revenue primarily represents customer billings on our
 maintenance service programs and unearned revenues relating to
 multiple element contracts where we still have contractual
 obligations to our customers. We currently offer maintenance
 contracts ranging from one to five years, primarily on Enterprise
 Networks Division products sold through distribution channels.
 Revenue attributable to maintenance contracts is recognized on a
 straight-line basis over the related contract term. In addition, we
 provide software maintenance and a variety of hardware maintenance
 services to Carrier Networks Division customers under contracts
 with terms up to ten years. When we defer revenue related to
 multiple-element contracts where we still have contractual
 obligations, we also defer the related costs. Deferred costs are
 included in prepaid expenses and other assets and totaled $5.2
 million and $0.8 million at December 31, 2015 and 2014,
 respectively.

[0001193125-16-475816:notes:147]
Other Income (Expense), Net

[0001193125-16-475816:notes:148]
Other income (expense), net, is comprised primarily of
 miscellaneous income and expense, gains and losses on foreign
 currency transactions, and investment account management fees. For
 the year ended December 31, 2014, other income (expense), net
 included a $2.4 million gain related to the settlement of working
 capital items from an acquisition transaction that closed in
 2012.

[0001193125-16-475816:notes:149]
Earnings per Share

[0001193125-16-475816:notes:150]
Earnings per common share, and earnings per common share assuming
 dilution, are based on the weighted average number of common shares
 and, when dilutive, common equivalent shares outstanding during the
 year. See Note 13 of Notes to Consolidated Financial Statements for
 additional information.

[0001193125-16-475816:notes:151]
Dividends

[0001193125-16-475816:notes:152]
During 2015, 2014 and 2013, we paid shareholder dividends totaling
 $18.4 million, $19.9 million and $21.4 million, respectively. The
 Board of Directors presently anticipates that it will declare a
 regular quarterly dividend so long as the present tax treatment of
 dividends exists and adequate levels of liquidity are maintained.
 The following table shows dividends paid to our shareholders in
 each quarter of 2015, 2014 and 2013.

[0001193125-16-475816:notes:153]
On January 19, 2016, the Board of Directors declared a
 quarterly cash dividend of $0.09 per common share to be paid to
 shareholders of record at the close of business on February 4,
 2016. The ex-dividend date was February 2, 2016 and the
 payment date was February 18, 2016. The quarterly dividend
 payment was $4.4 million.

[0001193125-16-475816:notes:154]
Business Combinations

[0001193125-16-475816:notes:155]
We use the acquisition method to account for business combinations.
 Under the acquisition method of accounting, we recognize the assets
 acquired and liabilities assumed at their fair value on the
 acquisition date. Goodwill is measured as the excess of the
 consideration transferred over the net assets acquired. Costs
 incurred to complete the business combination, such as legal,
 accounting or other professional fees, are charged to general and
 administrative expenses as they are incurred.

[0001193125-16-475816:notes:156]
Recently Issued Accounting Standards

[0001193125-16-475816:notes:157]
In May 2014, the Financial Accounting Standards Board (FASB) issued
 Accounting Standards Update No. 2014-09, Revenue from Contracts with
 Customers (ASU
 2014-09), which supersedes the revenue recognition requirements in
 Topic 605, Revenue Recognition,
 including most industry-specific revenue recognition guidance
 throughout the Industry Topics of the Codification. The core
 principle of ASU 2014-09 is to recognize revenues when promised
 goods or services are transferred to customers in an amount that
 reflects the consideration that is expected to be received for
 those goods or services. In August 2015, the FASB issued ASU
 2015-14, which deferred the effective date of ASU 2014-09 to fiscal
 years beginning after December 31, 2017, including interim
 periods within those years. ASU 2014-09 allows for either full
 retrospective or modified retrospective adoption. We are currently
 evaluating the transition method that will be elected and the
 impact that the adoption of ASU 2014-09 will have on our financial
 position, results of operations and cash flows.

[0001193125-16-475816:notes:158]
In April 2015, the FASB issued Accounting Standards Update
 No. 2015-05, Intangibles –
 Goodwill and Other – Internal-Use Software (Subtopic 350-40):
 Customer’s Accounting for Fees Paid in a Cloud Computing
 Arrangement (ASU 2015-05), which provides
 guidance on accounting for fees paid by a customer in a cloud
 computing arrangement. If a cloud computing arrangement includes a
 software license, then the customer should account for the software
 license element of the arrangement consistent with the acquisition
 of other software licenses. If a cloud computing arrangement does
 not include a software license, the customer should account for the
 arrangement as a service contract. ASU 2015-05 is effective for
 annual reporting periods beginning after December 15, 2015,
 including interim periods within those years. Early adoption is
 permitted. The guidance may be applied either prospectively to all
 arrangements entered into or materially modified after the
 effective date or retrospectively. We do not believe the adoption
 of ASU 2015-05 will have a material impact on our financial
 position, results of operations and cash flows.

[0001193125-16-475816:notes:159]
In July 2015, the FASB issued Accounting Standards Update No.
 2015-11, Inventory (Topic 330):
 Simplifying the Measurement of Inventory (ASU 2015-11). Currently,
 Topic 330, Inventory, requires an entity to measure inventory at
 the lower of cost or market. Market could be replacement cost, net
 realizable value, or net realizable value less an approximately
 normal profit margin. ASU 2015-11 does not apply to inventory that
 is measured using last-in, first-out (LIFO) or the retail inventory
 method. The amendments apply to all other inventory, which includes
 inventory that is measured using first-in, first-out (FIFO) or
 average cost. ASU 2015-11 requires an entity to measure in scope
 inventory at the lower of cost and net realizable value. Net
 realizable value is the estimated selling prices in the ordinary
 course of business, less reasonably predictable costs of
 completion, disposal, and transportation. ASU 2015-11 is effective
 for annual reporting periods beginning after December 15,
 2016, including interim periods within those years. The guidance
 should be applied prospectively with earlier application permitted
 as of the beginning of an interim or annual reporting period. We do
 not believe the adoption of ASU 2015-05 will have a material impact
 on our financial position, results of operations and cash
 flows.

[0001193125-16-475816:notes:160]
In November 2015, the FASB issued Accounting Standards Update
 No. 2015-17, Balance Sheet
 Classification of Deferred Taxes (ASU 2015-17). ASU 2015-17
 amends the existing guidance on income taxes to require the
 classification of all deferred tax assets and liabilities as
 non-current on the balance sheet. ASU 2015-17 is effective for
 fiscal years beginning after December 15, 2016, including
 interim periods within those years. Early adoption is permitted.
 The guidance may be applied either prospectively, for all deferred
 tax assets and liabilities, or retrospectively to all periods
 presented. We have not selected a transition method or determined
 whether to early adopt ASU 2015-17 in 2016. Other than the revised
 balance sheet presentation of current deferred tax assets and
 liabilities, we do not believe the adoption of ASU 2015-17 will
 have a material impact on our financial position, results of
 operations and cash flows.


## us-gaap:ScheduleOfDerivativeInstrumentsGainLossInStatementOfFinancialPerformanceTextBlock

[0001193125-16-475816:notes:161]
The change in the fair values of our derivative instruments
 recorded in the Consolidated Statements of Income during the years
 ended December 31, 2015 and 2014 were as follows:

[0001193125-16-475816:notes:162]
| (In thousands) |  | Income Statement Location |  | 2015 |  |  | 2014 |  |
| Derivatives Not Designated as Hedging Instruments: |  |  |  |  |  |  |  |  |  |  |
| Foreign exchange contracts |  | Other income (expense) |  | $ | 511 |  |  | $ | 1,852 |  |


## us-gaap:PropertyPlantAndEquipmentDisclosureTextBlock

[0001193125-16-475816:notes:163]
Note 6 – Property, Plant and Equipment

[0001193125-16-475816:notes:164]
At December 31, 2015 and 2014, property, plant and equipment
 were comprised of the following:

[0001193125-16-475816:notes:165]
| (In thousands) |  | 2015 |  |  | 2014 |  |
| Land |  | $ | 4,575 |  |  | $ | 4,575 |  |
| Building and land improvements |  |  | 25,667 |  |  |  | 22,374 |  |
| Building |  |  | 68,301 |  |  |  | 68,301 |  |
| Furniture and fixtures |  |  | 17,347 |  |  |  | 16,468 |  |
| Computer hardware and software |  |  | 76,389 |  |  |  | 74,603 |  |
| Engineering and other equipment |  |  | 112,132 |  |  |  | 109,501 |  |
| Total Property, Plant and Equipment |  |  | 304,411 |  |  |  | 295,822 |  |
| Less accumulated depreciation |  |  | (231,178 | ) |  |  | (220,994 | ) |
| Total Property, Plant and Equipment, net |  | $ | 73,233 |  |  | $ | 74,828 |  |

[0001193125-16-475816:notes:166]
Depreciation expense was $12.3 million, $12.5 million and $12.2
 million in 2015, 2014, and 2013, respectively.


## us-gaap:QuarterlyFinancialInformationTextBlock

[0001193125-16-475816:notes:167]
Note 14 – Summarized Quarterly Financial Data
 (Unaudited)

[0001193125-16-475816:notes:168]
The following table presents unaudited quarterly operating results
 for each of our last eight fiscal quarters. This information has
 been prepared on a basis consistent with our audited financial
 statements and includes all adjustments, consisting only of normal
 recurring adjustments, considered necessary for a fair presentation
 of the data.

[0001193125-16-475816:notes:169]
Unaudited Quarterly Operating Results

[0001193125-16-475816:notes:170]
(In thousands, except for per share amounts)

[0001193125-16-475816:notes:171]
| Three Months Ended |  | March 31, 2015 |  |  | June 30, 2015 |  |  | September 30, 2015 |  |  | December 31, 2015 |  |
| Net sales |  | $ | 142,835 |  |  | $ | 160,138 |  |  | $ | 158,078 |  |  | $ | 139,013 |  |
| Gross profit |  | $ | 65,563 |  |  | $ | 68,246 |  |  | $ | 70,649 |  |  | $ | 62,439 |  |
| Operating income |  | $ | 1,963 |  |  | $ | 644 |  |  | $ | 8,072 |  |  | $ | 2,800 |  |
| Net income |  | $ | 3,317 |  |  | $ | 2,544 |  |  | $ | 7,067 |  |  | $ | 5,718 |  |
| Earnings per common share |  | $ | 0.06 |  |  | $ | 0.05 |  |  | $ | 0.14 |  |  | $ | 0.12 |  |
| Earnings per common share assuming dilution (1) |  | $ | 0.06 |  |  | $ | 0.05 |  |  | $ | 0.14 |  |  | $ | 0.12 |  |
| Three Months Ended |  | March 31, 2014 |  |  | June 30, 2014 |  |  | September 30, 2014 |  |  | December 31, 2014 |  |
| Net sales |  | $ | 147,004 |  |  | $ | 176,129 |  |  | $ | 162,892 |  |  | $ | 143,982 |  |
| Gross profit |  | $ | 77,790 |  |  | $ | 86,797 |  |  | $ | 78,257 |  |  | $ | 68,483 |  |
| Operating income |  | $ | 11,298 |  |  | $ | 19,339 |  |  | $ | 12,495 |  |  | $ | 3,979 |  |
| Net income |  | $ | 9,607 |  |  | $ | 14,395 |  |  | $ | 11,326 |  |  | $ | 9,292 |  |
| Earnings per common share |  | $ | 0.17 |  |  | $ | 0.26 |  |  | $ | 0.21 |  |  | $ | 0.17 |  |
| Earnings per common share assuming dilution (1) |  | $ | 0.17 |  |  | $ | 0.26 |  |  | $ | 0.21 |  |  | $ | 0.17 |  |

[0001193125-16-475816:notes:172]
| (1) | Assumes exercise of dilutive stock options calculated under the treasury stock method. |


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-16-475816:notes:173]
Note 11 – Segment Information and Major Customers

[0001193125-16-475816:notes:174]
We operate in two reportable segments: (1) the Carrier
 Networks Division and (2) the Enterprise Networks Division.
 The accounting policies of the segments are the same as those
 described in the “Nature of Business and Summary of
 Significant Accounting Policies” (see Note 1) to the extent
 that such policies affect the reported segment information. We
 evaluate the performance of our segments based on gross profit;
 therefore, selling, general and administrative expense, research
 and development expenses, interest income and dividend income,
 interest expense, net realized investment gain/loss, other
 income/expense and provision for taxes are reported on an
 entity-wide basis only. There are no inter-segment revenues.

[0001193125-16-475816:notes:175]
The following table presents information about the reported sales
 and gross profit of our reportable segments for each of the years
 ended December 31, 2015, 2014 and 2013. Asset information by
 reportable segment is not reported, since we do not produce such
 information internally.

[0001193125-16-475816:notes:176]
Sales and Gross Profit by Market Segment

[0001193125-16-475816:notes:177]
| (In thousands) |  | 2015 |  |  | 2014 |  |  | 2013 |  |
|  |  | Sales |  |  | Gross Profit |  |  | Sales |  |  | Gross Profit |  |  | Sales |  |  | Gross Profit |  |
| Carrier Networks |  | $ | 499,402 |  |  | $ | 209,284 |  |  | $ | 510,373 |  |  | $ | 243,211 |  |  | $ | 500,733 |  |  | $ | 233,206 |  |
| Enterprise Networks |  |  | 100,662 |  |  |  | 57,613 |  |  |  | 119,634 |  |  |  | 68,116 |  |  |  | 141,011 |  |  |  | 75,680 |  |
| Total |  | $ | 600,064 |  |  | $ | 266,897 |  |  | $ | 630,007 |  |  | $ | 311,327 |  |  | $ | 641,744 |  |  | $ | 308,886 |  |

[0001193125-16-475816:notes:178]
Sales by Product

[0001193125-16-475816:notes:179]
Our three major product categories are Carrier Systems, Business
 Networking and Loop Access.

[0001193125-16-475816:notes:180]
Carrier Systems products are used by communications SPs to
 provide data, voice, and video services to consumers and
 enterprises. This category includes the following product areas and
 related services:

[0001193125-16-475816:notes:181]
|  | • |  | Broadband Access |

[0001193125-16-475816:notes:182]
|  | • |  | Total Access 5000 Series of Multi-Service Access Node (MSANs) |

[0001193125-16-475816:notes:183]
|  | • |  | hiX 5600 Series of MSANs |

[0001193125-16-475816:notes:184]
|  | • |  | Total Access 1100/1200 Series of Fiber to the Node (FTTN) products |

[0001193125-16-475816:notes:185]
|  | • |  | hiX 1100 Series of FTTN products |

[0001193125-16-475816:notes:186]
|  | • |  | VDSL2 Vectoring based Digital Subscriber Line Access Multiplexer (DSLAM) products |

[0001193125-16-475816:notes:187]
|  | • |  | ADTRAN 500 Series of FTTdp G.fast Distribution Point Units (DPU) |

[0001193125-16-475816:notes:188]
|  | • |  | Optical |

[0001193125-16-475816:notes:189]
|  | • |  | Optical Networking Edge (ONE) |

[0001193125-16-475816:notes:190]
|  | • |  | NetVanta 8000 Series of Fiber Ethernet Access Devices (EAD) |

[0001193125-16-475816:notes:191]
|  | • |  | NetVanta 8400 Series of 10Gig Multi-service Edge Switches |

[0001193125-16-475816:notes:192]
|  | • |  | OPTI-6100 and Total Access 3000 optical Multi-Service Provisioning Platforms (MSPP) |

[0001193125-16-475816:notes:193]
|  | • |  | Pluggable Optical Products, including Small Form Factor Pluggable (SFP), 10-Gigabit Fiber Small Form Factor Pluggable (XFP), and SFP+ |

[0001193125-16-475816:notes:194]
|  | • |  | Time Division Multiplexed (TDM) systems |

[0001193125-16-475816:notes:195]
Business Networking products provide access to communication
 services and facilitate the delivery of cloud connectivity and
 enterprise communications to the small and mid-sized enterprise
 (SME) market. This category includes the following product areas
 and related services:

[0001193125-16-475816:notes:196]
|  | • |  | Internetworking products |

[0001193125-16-475816:notes:197]
|  | • |  | Total Access IP Business Gateways |

[0001193125-16-475816:notes:198]
|  | • |  | Optical Network Terminals (ONTs) |

[0001193125-16-475816:notes:199]
|  | • |  | Bluesocket virtual Wireless LAN (vWLAN) |

[0001193125-16-475816:notes:200]
|  | • |  | NetVanta |

[0001193125-16-475816:notes:201]
|  | • |  | Access Routers |

[0001193125-16-475816:notes:202]
|  | • |  | Enterprise Session Border Controllers (eSBC) |

[0001193125-16-475816:notes:203]
|  | • |  | Managed Ethernet Switches |

[0001193125-16-475816:notes:204]
|  | • |  | IP Business Gateways |

[0001193125-16-475816:notes:205]
|  | • |  | Unified Communications (UC) solutions |

[0001193125-16-475816:notes:206]
|  | • |  | Carrier Ethernet Network Termination Equipment (NTE) |

[0001193125-16-475816:notes:207]
|  | • |  | Carrier Ethernet Routers and Gateways |

[0001193125-16-475816:notes:208]
|  | • |  | Network Management Solutions |

[0001193125-16-475816:notes:209]
Loop Access products are used by carrier and enterprise
 customers for access to copper-based communications networks. This
 category includes the following product areas and related
 services:

[0001193125-16-475816:notes:210]
|  | • |  | High bit-rate Digital Subscriber Line (HDSL) products |

[0001193125-16-475816:notes:211]
|  | • |  | Digital Data Service (DDS) |

[0001193125-16-475816:notes:212]
|  | • |  | Integrated Services Digital Network (ISDN) products |

[0001193125-16-475816:notes:213]
The table below presents sales information by product category for
 the years ended December 31, 2015, 2014 and 2013:

[0001193125-16-475816:notes:214]
| (In thousands) |  | 2015 |  |  | 2014 |  |  | 2013 |  |
| Carrier Systems |  | $ | 433,373 |  |  | $ | 442,664 |  |  | $ | 427,850 |  |
| Business Networking |  |  | 139,693 |  |  |  | 156,980 |  |  |  | 168,871 |  |
| Loop Access |  |  | 26,998 |  |  |  | 30,363 |  |  |  | 45,023 |  |
| Total |  | $ | 600,064 |  |  | $ | 630,007 |  |  | $ | 641,744 |  |

[0001193125-16-475816:notes:215]
In addition, we identify subcategories of product revenues, which
 we divide into core products and legacy products. Our core products
 consist of Broadband Access and Optical products (included in
 Carrier Systems), and Internetworking products (included in
 Business Networking). Our legacy products include HDSL products
 (included in Loop Access) and other products not included in the
 aforementioned core products.

[0001193125-16-475816:notes:216]
The table below presents subcategory revenues for the years ended
 December 31, 2015, 2014 and 2013:

[0001193125-16-475816:notes:217]
| (In thousands) |  | 2015 |  |  | 2014 |  |  | 2013 |  |
| Core Products |  |  |  |  |  |  |  |  |  |  |  |  |
| Broadband Access (included in Carrier Systems) |  | $ | 364,537 |  |  | $ | 368,464 |  |  | $ | 340,560 |  |
| Optical (included in Carrier Systems) |  |  | 56,615 |  |  |  | 55,374 |  |  |  | 55,615 |  |
| Internetworking (NetVanta & Multi-service Access Gateways) (included in Business Networking) |  |  | 135,720 |  |  |  | 152,223 |  |  |  | 164,422 |  |
| Subtotal |  | $ | 556,872 |  |  | $ | 576,061 |  |  | $ | 560,597 |  |
| Legacy Products |  |  |  |  |  |  |  |  |  |  |  |  |
| HDSL (does not include T1) (included in Loop Access) |  |  | 25,349 |  |  |  | 27,829 |  |  |  | 41,666 |  |
| Other products (excluding HDSL) |  |  | 17,843 |  |  |  | 26,117 |  |  |  | 39,481 |  |
| Subtotal |  | $ | 43,192 |  |  | $ | 53,946 |  |  | $ | 81,147 |  |
| Total |  | $ | 600,064 |  |  | $ | 630,007 |  |  | $ | 641,744 |  |

[0001193125-16-475816:notes:218]
The following table presents sales information by geographic area
 for the years ended December 31, 2015, 2014 and 2013.
 International sales correlate to shipments with a non-U.S.
 destination.

[0001193125-16-475816:notes:219]
| (In thousands) |  | 2015 |  |  | 2014 |  |  | 2013 |  |
| United States |  | $ | 419,366 |  |  | $ | 381,382 |  |  | $ | 455,996 |  |
| Germany |  |  | 111,666 |  |  |  | 150,987 |  |  |  | 97,151 |  |
| Other international |  |  | 69,032 |  |  |  | 97,638 |  |  |  | 88,597 |  |
| Total |  | $ | 600,064 |  |  | $ | 630,007 |  |  | $ | 641,744 |  |

[0001193125-16-475816:notes:220]
Customers comprising more than 10% of revenue can change from year
 to year. Single customers comprising more than 10% of our revenue
 in 2015 included three customers at 20%, 17% and 14%. Single
 customers comprising more than 10% of our revenue in 2014 included
 two customers at 21% and 14%. Single customers comprising more than
 10% of our revenue in 2013 included two customers at 17% and 14%.
 No other customer accounted for 10% or more of our sales in 2015,
 2014 or 2013. Our five largest customers, other than those with
 more than 10 percent of revenues disclosed above, can change from
 year to year. These customers represented 14%, 22%, and 22% of
 total revenue in 2015, 2014 and 2013, respectively. Revenues in
 this disclosure do not include distributor agents, who
 predominately provide fulfillment services to end users. In such
 cases where known, that revenue is associated with the end
 user.

[0001193125-16-475816:notes:221]
As of December 31, 2015, long-lived assets, net totaled $73.2
 million, which includes $68.8 million held in the United States and
 $4.4 million held outside the United States. As of
 December 31, 2014, long-lived assets, net totaled $74.8
 million, which includes $70.0 million held in the United States and
 $4.8 million held outside the United States.


## us-gaap:ScheduleOfEarningsPerShareBasicAndDilutedTableTextBlock

[0001193125-16-475816:notes:222]
A summary of the calculation of basic and diluted earnings per
 share (EPS) for the years ended December 31, 2015, 2014 and
 2013 is as follows:

[0001193125-16-475816:notes:223]
| (In thousands, except for per share amounts) |  | 2015 |  |  | 2014 |  |  | 2013 |  |
| Numerator |  |  |  |  |  |  |  |  |  |
| Net Income |  | $ | 18,646 |  |  | $ | 44,620 |  |  | $ | 45,794 |  |
| Denominator |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average number of shares – basic |  |  | 51,145 |  |  |  | 55,120 |  |  |  | 59,001 |  |
| Effect of dilutive securities: |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock options |  |  | 81 |  |  |  | 304 |  |  |  | 390 |  |
| Restricted stock and restricted stock units |  |  | 41 |  |  |  | 58 |  |  |  | 33 |  |
| Weighted average number of shares – diluted |  |  | 51,267 |  |  |  | 55,482 |  |  |  | 59,424 |  |
| Net income per share – basic |  | $ | 0.36 |  |  | $ | 0.81 |  |  | $ | 0.78 |  |
| Net income per share – diluted |  | $ | 0.36 |  |  | $ | 0.80 |  |  | $ | 0.77 |  |


## us-gaap:ScheduleOfEmployeeServiceShareBasedCompensationAllocationOfRecognizedPeriodCostsTextBlock

[0001193125-16-475816:notes:224]
The following table summarizes stock-based compensation expense
 related to stock options, RSUs and restricted stock for the years
 ended December 31, 2015, 2014 and 2013, which was recognized
 as follows:

[0001193125-16-475816:notes:225]
| (In thousands) |  | 2015 |  |  | 2014 |  |  | 2013 |  |
| Stock-based compensation expense included in cost of sales |  | $ | 280 |  |  | $ | 479 |  |  | $ | 465 |  |
| Selling, general and administrative expense |  |  | 3,261 |  |  |  | 4,185 |  |  |  | 4,443 |  |
| Research and development expense |  |  | 3,171 |  |  |  | 3,899 |  |  |  | 4,165 |  |
| Stock-based compensation expense included in operating expenses |  |  | 6,432 |  |  |  | 8,084 |  |  |  | 8,608 |  |
| Total stock-based compensation expense |  |  | 6,712 |  |  |  | 8,563 |  |  |  | 9,073 |  |
| Tax benefit for expense associated with non-qualified options |  |  | (862 | ) |  |  | (1,157 | ) |  |  | (1,298 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 5,850 |  |  | $ | 7,406 |  |  | $ | 7,775 |  |


## us-gaap:ScheduleOfInventoryCurrentTableTextBlock

[0001193125-16-475816:notes:226]
At December 31, 2015 and 2014, inventory was comprised of the
 following:

[0001193125-16-475816:notes:227]
| (In thousands) |  | 2015 |  |  | 2014 |  |
| Raw materials |  | $ | 34,223 |  |  | $ | 34,831 |  |
| Work in process |  |  | 2,893 |  |  |  | 3,750 |  |
| Finished goods |  |  | 54,417 |  |  |  | 47,367 |  |
| Total Inventory, net |  | $ | 91,533 |  |  | $ | 85,948 |  |


## us-gaap:ScheduleOfShareBasedCompensationSharesAuthorizedUnderStockOptionPlansByExercisePriceRangeTextBlock

[0001193125-16-475816:notes:228]
The following table further describes our stock options outstanding
 as of December 31, 2015:

[0001193125-16-475816:notes:229]
|  |  | Options Outstanding |  |  | Options Exercisable |  |
| Range of Exercise Prices |  | Options Outstanding at 12/31/15 (In thousands) |  |  | Weighted Avg. Remaining Contractual Life in Years |  |  | Weighted Average Exercise Price |  |  | Options Exercisable at 12/31/15 (In thousands) |  |  | Weighted Average Exercise Price |  |
| $14.88 – 16.96 |  |  | 1,628 |  |  |  | 8.03 |  |  | $ | 15.32 |  |  |  | 430 |  |  | $ | 15.27 |  |
| $16.97 – 18.97 |  |  | 1,798 |  |  |  | 8.02 |  |  | $ | 18.14 |  |  |  | 827 |  |  | $ | 17.63 |  |
| $18.98 – 23.46 |  |  | 1,290 |  |  |  | 2.65 |  |  | $ | 23.08 |  |  |  | 1,288 |  |  | $ | 23.08 |  |
| $23.47 – 29.71 |  |  | 967 |  |  |  | 7.43 |  |  | $ | 24.15 |  |  |  | 536 |  |  | $ | 24.38 |  |
| $29.72 – 41.92 |  |  | 1,425 |  |  |  | 5.29 |  |  | $ | 31.94 |  |  |  | 1,425 |  |  | $ | 31.94 |  |
|  |  |  | 7,108 |  |  |  |  |  |  |  |  |  |  |  | 4,506 |  |  |  |  |  |


## us-gaap:ScheduleOfValuationAndQualifyingAccountsDisclosureTextBlock

[0001193125-16-475816:notes:230]
SCHEDULE II

[0001193125-16-475816:notes:231]
VALUATION AND QUALIFYING ACCOUNTS

[0001193125-16-475816:notes:232]
| Column A |  | Column B |  |  | Column C |  |  | Column D |  |  | Column E |  |
| (In thousands) |  | Balance at Beginning of Period |  |  | Charged to Costs & Expenses |  |  | Deductions |  |  | Balance at End of Period |  |
| Year ended December 31, 2015 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for Doubtful Accounts |  | $ | 136 |  |  |  | 19 |  |  |  | 136 |  |  | $ | 19 |  |
| Inventory Reserve |  | $ | 24,682 |  |  |  | 2,225 |  |  |  | 232 |  |  | $ | 26,675 |  |
| Warranty Liability |  | $ | 8,415 |  |  |  | 2,998 |  |  |  | 2,674 |  |  | $ | 8,739 |  |
| Deferred Tax Asset Valuation Allowance |  | $ | 7,463 |  |  |  | 81 |  |  |  | 294 |  |  | $ | 7,250 |  |
| Year ended December 31, 2014 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for Doubtful Accounts |  | $ | 130 |  |  |  | 23 |  |  |  | 17 |  |  | $ | 136 |  |
| Inventory Reserve |  | $ | 22,993 |  |  |  | 2,549 |  |  |  | 860 |  |  | $ | 24,682 |  |
| Warranty Liability |  | $ | 8,977 |  |  |  | 3,103 |  |  |  | 3,665 |  |  | $ | 8,415 |  |
| Deferred Tax Asset Valuation Allowance |  | $ | 8,842 |  |  |  | 283 |  |  |  | 1,662 |  |  | $ | 7,463 |  |
| Year ended December 31, 2013 |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Allowance for Doubtful Accounts |  | $ | 6 |  |  |  | 136 |  |  |  | 12 |  |  | $ | 130 |  |
| Inventory Reserve |  | $ | 11,957 |  |  |  | 11,457 |  |  |  | 421 |  |  | $ | 22,993 |  |
| Warranty Liability |  | $ | 9,653 |  |  |  | 4,051 |  |  |  | 4,727 |  |  | $ | 8,977 |  |
| Deferred Tax Asset Valuation Allowance |  | $ | 10,939 |  |  |  | (1,056 | ) |  |  | 1,041 |  |  | $ | 8,842 |  |


## us-gaap:InventoryDisclosureTextBlock

[0001193125-16-475816:notes:233]
Note 5 – Inventory

[0001193125-16-475816:notes:234]
We establish reserves for estimated excess, obsolete, or
 unmarketable inventory equal to the difference between the cost of
 the inventory and the estimated fair value of the inventory based
 upon assumptions about future demand and market conditions. At
 December 31, 2015 and 2014, raw materials reserves totaled
 $17.5 million and $16.9 million, respectively, and finished goods
 inventory reserves totaled $9.2 million and $7.8 million,
 respectively.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-16-475816:notes:235]
Note 9 – Income Taxes

[0001193125-16-475816:notes:236]
Our effective income tax rate differs from the federal statutory
 rate due to the following:

[0001193125-16-475816:notes:237]
|  |  | 2015 |  |  | 2014 |  |  | 2013 |  |
| Tax provision computed at the federal statutory rate |  |  | 35.00 | % |  |  | 35.00 | % |  |  | 35.00 | % |
| State income tax provision, net of federal benefit |  |  | 4.86 |  |  |  | 2.69 |  |  |  | 3.98 |  |
| Federal research credits |  |  | (12.55 | ) |  |  | (4.05 | ) |  |  | (9.24 | ) |
| Foreign taxes |  |  | 2.10 |  |  |  | (7.26 | ) |  |  | (2.93 | ) |
| Tax-exempt income |  |  | (1.94 | ) |  |  | (1.25 | ) |  |  | (1.11 | ) |
| State tax incentives |  |  | (5.04 | ) |  |  | (2.21 | ) |  |  | (2.19 | ) |
| Stock-based compensation |  |  | 6.91 |  |  |  | 3.06 |  |  |  | 2.97 |  |
| Domestic production activity deduction |  |  | (3.17 | ) |  |  | (1.15 | ) |  |  | (1.80 | ) |
| Other, net |  |  | 1.30 |  |  |  | 0.69 |  |  |  | 0.07 |  |
| Effective Tax Rate |  |  | 27.47 | % |  |  | 25.52 | % |  |  | 24.75 | % |

[0001193125-16-475816:notes:238]
Income before provision for income taxes for international entities
 reflects income based on statutory transfer pricing agreements.
 This amount does not correlate to consolidated international
 revenues, many of which occur from our U.S. entity.

[0001193125-16-475816:notes:239]
At December 31, 2015 and 2014, non-current deferred taxes
 related to our investments and our defined benefit pension plan,
 reflect deferred taxes on the net unrealized gains on
 available-for-sale investments and deferred taxes on unrealized
 losses in our pension plan. The net change in non-current deferred
 taxes associated with these items, a deferred tax benefit of $3.7
 million and $3.3 million in 2015 and 2014, respectively, is
 recorded as an adjustment to other comprehensive income, presented
 in the Consolidated Statements of Comprehensive Income.

[0001193125-16-475816:notes:240]
Based upon our results of operations in 2015 and expected
 profitability in future years in a certain international
 jurisdiction, we concluded that it is more likely than not certain
 foreign deferred tax assets will be realized. A reversal of the
 valuation allowance on these deferred tax assets, which includes a
 change in estimate of the years beginning balance, resulted in a
 deferred income tax benefit totaling $4.6 million in 2014. As of
 December 31, 2015, the remaining valuation allowance primarily
 relates to deferred tax assets related to state credit
 carry-forwards from tax credits in excess of our annual tax
 liability to an individual state where we do not generate
 sufficient state income to offset the credit and net operating
 losses in foreign jurisdictions. We believe it is more likely than
 not that we will not realize the full benefits of the deferred tax
 assets arising from these losses and credits, and accordingly, we
 have provided a valuation allowance against these deferred tax
 assets. The deferred tax assets for foreign and domestic
 carry-forwards, unamortized research and development costs, and
 state credit carry-forwards of $16.3 million will expire between
 2016 and 2030. The loss carry-forwards were acquired through
 acquisitions in 2009 and 2011. We will continue to assess the
 realization of our deferred tax assets and related valuations
 allowances. We do not provide for U.S. income tax on undistributed
 earnings of our foreign operations, whose earnings are intended to
 be permanently reinvested. These earnings are not required to
 service debt or fund our U.S. operations. It is impracticable to
 determine the amount of any unrecognized deferred tax liability for
 temporary differences related to investments in foreign
 subsidiaries.

[0001193125-16-475816:notes:241]
During 2015, 2014 and 2013, we recorded an income tax benefit
 (expense) of ($40) thousand, $0.1 million and $0.2 million,
 respectively, as an adjustment to equity. This deduction is
 calculated on the difference between the exercise price of stock
 option exercises and the market price of the underlying common
 stock upon exercise.

[0001193125-16-475816:notes:242]
As of December 31, 2015, 2014, and 2013, our total liability
 for unrecognized tax benefits was $2.5 million, $3.3 million, and
 $3.2 million, respectively, of which $1.8 million, $2.6 million,
 and $2.5 million, respectively, would reduce our effective tax rate
 if we were successful in upholding all of the uncertain positions
 and recognized the amounts recorded. We classify interest and
 penalties recognized on the liability for unrecognized tax benefits
 as income tax expense. As of December 31, 2015, 2014 and 2013,
 the balances of accrued interest and penalties were $0.9 million,
 $1.0 million and $1.0 million, respectively.

[0001193125-16-475816:notes:243]
We do not anticipate a single tax position generating a significant
 increase or decrease in our liability for unrecognized tax benefits
 within 12 months of this reporting date. We file income tax returns
 in the U.S. federal and various state jurisdictions and several
 foreign jurisdictions. We are currently under audit by the Internal
 Revenue Service. Generally, we are not subject to changes in income
 taxes by any taxing jurisdiction for the years prior to 2013.


## us-gaap:ScheduleOfShareBasedCompensationStockOptionsActivityTableTextBlock

[0001193125-16-475816:notes:244]
The following table is a summary of our stock options outstanding
 as of December 31, 2014 and 2015 and the changes that occurred
 during 2015:

[0001193125-16-475816:notes:245]
| (In thousands, except per share amounts) |  | Number of Options |  |  | Weighted Average Exercise Price |  |  | Weighted Avg. Remaining Contractual Life in Years |  |  | Aggregate Intrinsic Value |  |
| Options outstanding, December 31, 2014 |  |  | 6,981 |  |  | $ | 23.62 |  |  |  | 6.45 |  |  | $ | 10,625 |  |
| Options granted |  |  | 1,204 |  |  | $ | 15.35 |  |  |  |  |  |  |  |  |  |
| Options exercised |  |  | (60 | ) |  | $ | 16.00 |  |  |  |  |  |  |  |  |  |
| Options forfeited |  |  | (289 | ) |  | $ | 20.86 |  |  |  |  |  |  |  |  |  |
| Options expired |  |  | (728 | ) |  | $ | 27.75 |  |  |  |  |  |  |  |  |  |
| Options outstanding, December 31, 2015 |  |  | 7,108 |  |  | $ | 21.97 |  |  |  | 6.42 |  |  | $ | 3,284 |  |
| Options vested and expected to vest, December 31, 2015 |  |  | 6,954 |  |  | $ | 22.09 |  |  |  | 6.35 |  |  | $ | 3,094 |  |
| Options exercisable, December 31, 2015 |  |  | 4,506 |  |  | $ | 24.29 |  |  |  | 4.93 |  |  | $ | 978 |  |


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-16-475816:notes:246]
Note 12 – Commitments and Contingencies

[0001193125-16-475816:notes:247]
In the ordinary course of business, we may be subject to various
 legal proceedings and claims, including employment disputes, patent
 claims, disputes over contract agreements and other commercial
 disputes. In some cases, claimants seek damages or other relief,
 such as royalty payments related to patents, which, if granted,
 could require significant expenditures. Although the outcome of any
 claim or litigation can never be certain, it is our opinion that
 the outcome of all contingencies of which we are currently aware
 will not materially affect our business, operations, financial
 condition or cash flows.

[0001193125-16-475816:notes:248]
We lease office space and equipment under operating leases which
 expire at various dates through 2025. As of December 31, 2015,
 future minimum rental payments under non-cancelable operating
 leases with original maturities of greater than 12 months are as
 follows:

[0001193125-16-475816:notes:249]
| (In thousands) |  |  |  |
| 2016 |  | $ | 3,827 |  |
| 2017 |  |  | 3,155 |  |
| 2018 |  |  | 1,773 |  |
| 2019 |  |  | 869 |  |
| Thereafter |  |  | 4,121 |  |
| Total |  | $ | 13,745 |  |

[0001193125-16-475816:notes:250]
Rental expense was $4.9 million, $4.7 million and $4.8 million for
 the years ended December 31, 2015, 2014 and 2013,
 respectively.


## us-gaap:DerivativeInstrumentsAndHedgingActivitiesDisclosureTextBlock

[0001193125-16-475816:notes:251]
Note 4 – Derivative Instruments and Hedging
 Activities

[0001193125-16-475816:notes:252]
We have certain international customers who are billed in their
 local currency. Changes in the monetary exchange rates may
 adversely affect our results of operations and financial condition.
 When appropriate, we enter into various derivative transactions to
 enhance our ability to manage the volatility relating to these
 typical business exposures. We do not hold or issue derivative
 instruments for trading or other speculative purposes. Our
 derivative instruments are recorded in the Consolidated Balance
 Sheets at their fair values. Our derivative instruments do not
 qualify for hedge accounting, and accordingly, all changes in the
 fair value of the instruments are recognized as other income
 (expense) in the Consolidated Statements of Income. The maximum
 contractual period for our derivatives is currently less than
 twelve months. Our derivative instruments are not subject to master
 netting arrangements and are not offset in the Consolidated Balance
 Sheets.

[0001193125-16-475816:notes:253]
As of December 31, 2015, we had no forward contracts
 outstanding.


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-16-475816:notes:254]
Note 2 – Stock Incentive Plans

[0001193125-16-475816:notes:255]
Stock Incentive Program Descriptions

[0001193125-16-475816:notes:256]
On January 23, 2006, the Board of Directors adopted the
 ADTRAN, Inc. 2006 Employee Stock Incentive Plan (2006 Plan), which
 authorized 13.0 million shares of common stock for issuance to
 certain employees and officers through incentive stock options and
 non-qualified stock options, stock appreciation rights, restricted
 stock and restricted stock units. The 2006 Plan was adopted by
 stockholder approval at our annual meeting of stockholders held on
 May 9, 2006. Options granted under the 2006 Plan typically
 become exercisable beginning after one year of continued
 employment, normally pursuant to a four-year vesting schedule
 beginning on the first anniversary of the grant date, and have a
 ten-year contractual term. The 2006 Plan was replaced on
 May 13, 2015 by the ADTRAN, Inc. 2015 Employee Stock Incentive
 Plan (2015 Plan). Expiration dates of options outstanding at
 December 31, 2015 under the 2006 Plan range from 2016 to
 2025.

[0001193125-16-475816:notes:257]
Our stockholders approved the 2010 Directors Stock Plan (2010
 Directors Plan) on May 5, 2010, under which 0.5 million
 shares of common stock have been reserved. This plan replaces the
 2005 Directors Stock Option Plan. The 2010 Directors Plan provides
 that the Company may issue stock options, restricted stock and
 restricted stock units to our non-employee directors. Stock awards
 issued under the 2010 Directors Plan normally become vested in full
 on the first anniversary of the grant date. Options issued under
 the 2010 Directors Plan have a ten-year contractual term.
 Expiration dates of options outstanding under both plans at
 December 31, 2015 range from 2016 to 2019.

[0001193125-16-475816:notes:258]
On January 20, 2015, the Board of Directors adopted the 2015
 Plan, which authorizes 7.7 million shares of common stock for
 issuance to certain employees and officers through incentive stock
 options and non-qualified stock options, stock appreciation rights,
 restricted stock and restricted stock units. The 2015 Plan was
 adopted by stockholder approval at our annual meeting of
 stockholders held on May 13, 2015. Restricted stock and
 restricted stock units granted under the 2015 Plan reduce the
 shares authorized for issuance under the 2015 Plan by 2.5 shares of
 common stock for each share underlying the award. Options granted
 under the 2015 Plan typically become exercisable beginning after
 one year of continued employment, normally pursuant to a four-year
 vesting schedule beginning on the first anniversary of the grant
 date, and have a ten-year contractual term. Expiration dates of
 options outstanding at December 31, 2015 under the 2015 Plan
 are in the year 2025.

[0001193125-16-475816:notes:259]
At December 31, 2015, total compensation cost related to
 non-vested stock options not yet recognized was approximately $13.3
 million, which is expected to be recognized over an average
 remaining recognition period of 2.8 years.

[0001193125-16-475816:notes:260]
Stock Options

[0001193125-16-475816:notes:261]
All of the options above were issued at exercise prices that
 approximated fair market value at the date of grant. At
 December 31, 2015, 6.7 million options were available for
 grant under the shareholder approved plans.

[0001193125-16-475816:notes:262]
The aggregate intrinsic values in the table above represent the
 total pre-tax intrinsic value (the difference between
 ADTRAN’s closing stock price on the last trading day of 2015
 and the exercise price, multiplied by the number of in-the-money
 options) that would have been received by the option holders had
 all option holders exercised their options on December 31,
 2015. The amount of aggregate intrinsic value will change based on
 the fair market value of ADTRAN’s stock.

[0001193125-16-475816:notes:263]
The total pre-tax intrinsic value of options exercised during 2015,
 2014 and 2013 was $0.1 million, $0.7 million and $1.1 million,
 respectively. The fair value of options fully vesting during 2015,
 2014 and 2013 was $6.6 million, $7.7 million and $7.7 million,
 respectively.

[0001193125-16-475816:notes:264]
Restricted Stock and RSUs

[0001193125-16-475816:notes:265]
Under the 2015 Plan, awards other than stock options, including
 restricted stock and RSUs, may be granted to certain employees and
 officers. The number of shares of common stock earned by a
 recipient pursuant to the RSUs is subject to a market condition
 based on ADTRAN’s relative total shareholder return against
 all companies in the NASDAQ Telecommunications Index at the end of
 a three-year performance period. Depending on the relative total
 shareholder return over the performance period, the recipient may
 earn from 0% to 150% of the shares underlying the RSUs, with the
 shares earned distributed upon the vesting of the RSUs at the end
 of the three-year performance period. The fair value of the award
 is based on the market price of our common stock on the date of
 grant, adjusted for the expected outcome of the impact of market
 conditions using a Monte Carlo Simulation valuation method. A
 portion of the granted RSUs also vest and the underlying shares
 become deliverable upon the death or disability of the recipient or
 upon a change of control of ADTRAN, as defined by the 2015 Plan.
 The recipients of the RSUs receive dividend credits based on the
 shares of common stock underlying the RSUs. The dividend credits
 are vested and earned in the same manner as the RSUs and are paid
 in cash upon the issuance of common stock for the RSUs.

[0001193125-16-475816:notes:266]
At December 31, 2015, total compensation cost related to the
 non-vested portion of RSUs and restricted stock not yet recognized
 was approximately $1.5 million, which is expected to be recognized
 over an average remaining recognition period of 1.9 years.

[0001193125-16-475816:notes:267]
Valuation and Expense Information

[0001193125-16-475816:notes:268]
We use the Black-Scholes option pricing model (Black-Scholes Model)
 for the purpose of determining the estimated fair value of stock
 option awards on the date of grant. The Black-Scholes Model
 requires the input of certain assumptions that involve judgment.
 Because our stock options have characteristics significantly
 different from those of traded options, and because changes in the
 input assumptions can materially affect the fair value estimate,
 existing models may not provide reliable measures of fair value of
 our stock options. We use a Monte Carlo Simulation valuation method
 to value our performance-based RSUs. The fair value of restricted
 stock issued is equal to the closing price of our stock on the date
 of grant. We will continue to assess the assumptions and
 methodologies used to calculate the estimated fair value of
 stock-based compensation. If circumstances change, and additional
 data becomes available over time, we may change our assumptions and
 methodologies, which may materially impact our fair value
 determination.

[0001193125-16-475816:notes:269]
The stock option pricing model requires the use of several
 assumptions that impact the fair value estimate. These variables
 include, but are not limited to, the volatility of our stock price
 and employee exercise behaviors. There were no changes made during
 2015 to the methodology used to determine our assumptions.

[0001193125-16-475816:notes:270]
The weighted-average estimated fair value of stock options granted
 to employees during the years ended December 31, 2015, 2014
 and 2013 was $4.28 per share, $6.31 per share and $8.35 per share,
 respectively, with the following weighted-average assumptions:

[0001193125-16-475816:notes:271]
|  |  | 2015 |  |  | 2014 |  |  | 2013 |  |
| Expected volatility |  |  | 34.57 | % |  |  | 39.05 | % |  |  | 39.92 | % |
| Risk-free interest rate |  |  | 1.81 | % |  |  | 1.79 | % |  |  | 1.71 | % |
| Expected dividend yield |  |  | 2.35 | % |  |  | 1.90 | % |  |  | 1.52 | % |
| Expected life (in years) |  |  | 6.23 |  |  |  | 6.33 |  |  |  | 6.36 |  |

[0001193125-16-475816:notes:272]
We based our estimate of expected volatility for the years ended
 December 31, 2015, 2014 and 2013 on the sequential historical
 daily trading data of our common stock for a period equal to the
 expected life of the options granted. The selection of the
 historical volatility method was based on available data indicating
 our historical volatility is as equally representative of our
 future stock price trends as is our implied volatility. We have no
 reason to believe the future volatility of our stock price is
 likely to differ from its past volatility.

[0001193125-16-475816:notes:273]
The risk-free interest rate assumption is based upon implied yields
 of U.S. Treasury zero-coupon bonds on the date of grant having a
 remaining term equal to the expected life of the options granted.
 The dividend yield is based on our historical and expected dividend
 payouts. The expected life of our stock options is based upon
 historical exercise and cancellation activity of our previous
 stock-based grants with a ten-year contractual term.

[0001193125-16-475816:notes:274]
The RSU pricing model also requires the use of several significant
 assumptions that impact the fair value estimate. The estimated fair
 value of the RSUs granted to employees during the years ended
 December 31, 2015, 2014 and 2013 was $17.64 per share, $22.11
 per share and $27.72 per share, respectively, with the following
 assumptions:

[0001193125-16-475816:notes:275]
|  |  | 2015 |  |  | 2014 |  |  | 2013 |  |
| Expected volatility |  |  | 31.34 | % |  |  | 36.40 | % |  |  | 38.83 | % |
| Risk-free interest rate |  |  | 1.20 | % |  |  | 0.96 | % |  |  | 0.61 | % |
| Expected dividend yield |  |  | 2.35 | % |  |  | 1.89 | % |  |  | 1.52 | % |

[0001193125-16-475816:notes:276]
Stock-based compensation expense recognized in our Consolidated
 Statements of Income for the years ended December 31, 2015,
 2014 and 2013 is based on RSUs and options ultimately expected to
 vest, and has been reduced for estimated forfeitures. Estimates for
 forfeiture rates are based upon historical experience and are
 evaluated quarterly. We expect our forfeiture rate for stock option
 awards to be approximately 3.7% annually. We estimated a 0%
 forfeiture rate for our RSUs and restricted stock due to the
 limited number of recipients and historical experience for these
 awards.


## us-gaap:EarningsPerShareTextBlock

[0001193125-16-475816:notes:277]
Note 13 – Earnings per Share

[0001193125-16-475816:notes:278]
For each of the years ended December 31, 2015, 2014 and 2013,
 6.1 million, 4.4 million and 3.2 million stock
 options were outstanding but were not included in the computation
 of that year’s diluted EPS because the options’
 exercise prices were greater than the average market price of the
 common shares, therefore making them anti-dilutive under the
 treasury stock method.


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001193125-16-475816:notes:279]
Note 15 – Related Party Transactions

[0001193125-16-475816:notes:280]
We employed the law firm of our director emeritus for legal
 services. All bills for services rendered by this firm were
 reviewed and approved by our Chief Financial Officer. We believe
 that the fees for such services are comparable to those charged by
 other firms for services rendered to us. The services of our
 director emeritus ended with his death on September 7, 2014.
 For the years ended 2014 and 2013, we incurred fees of $0.1 million
 for these legal services.


## us-gaap:SubsequentEventsTextBlock

[0001193125-16-475816:notes:281]
Note 16 – Subsequent Events

[0001193125-16-475816:notes:282]
On January 19, 2016, the Board declared a quarterly cash
 dividend of $0.09 per common share to be paid to shareholders of
 record at the close of business on February 4, 2016. The
 quarterly dividend payment was $4.4 million and was paid on
 February 18, 2016. In July 2003, our Board of Directors
 elected to begin declaring quarterly dividends on our common stock
 considering the tax treatment of dividends and adequate levels of
 Company liquidity.

[0001193125-16-475816:notes:283]
On February 8, 2016, the Board appointed Anthony Melone as a
 director filling a previously existing vacancy until the 2016
 Annual Meeting of Stockholders.

[0001193125-16-475816:notes:284]
During the first quarter and as of February 24, 2016, we have
 repurchased 0.6 million shares of our common stock through
 open market purchases at an average cost of $18.38 per share. We
 currently have the authority to purchase an additional
 5.2 million shares of our common stock under the current plan
 approved by the Board of Directors.

[0001193125-16-475816:notes:285]
We are currently evaluating the way the Company’s chief
 operating decision maker reviews and measures performance of the
 business. The conclusions of this evaluation may have an impact on
 our future presentation of our reportable segments.


## adtn:IndustrialDevelopmentAuthorityFinancingAndEconomicIncentivesTextBlock

[0001193125-16-475816:notes:286]
Note 8 – Alabama State Industrial Development Authority
 Financing and Economic Incentives

[0001193125-16-475816:notes:287]
In conjunction with an expansion of our Huntsville, Alabama,
 facility, we were approved for participation in an incentive
 program offered by the State of Alabama Industrial Development
 Authority (the “Authority”). Pursuant to the program,
 on January 13, 1995, the Authority issued $20.0 million of its
 taxable revenue bonds and loaned the proceeds from the sale of the
 bonds to ADTRAN. The bonds were originally purchased by AmSouth
 Bank of Alabama, Birmingham, Alabama (the “Bank”).
 Wachovia Bank, N.A., Nashville, Tennessee (formerly First Union
 National Bank of Tennessee) (the “Bondholder”), which
 was acquired by Wells Fargo & Company on December 31,
 2008, purchased the original bonds from the Bank and made further
 advances to the Authority, bringing the total amount outstanding to
 $50.0 million. An Amended and Restated Taxable Revenue Bond
 (“Amended and Restated Bond”) was issued and the
 original financing agreement was amended. The Amended and Restated
 Bond bears interest, payable monthly. The interest rate is
 2% per annum. The Amended and Restated Bond matures on
 January 1, 2020, and is currently outstanding in the aggregate
 principal amount of $28.9 million. The estimated fair value of the
 bond using a level 2 valuation technique at December 31, 2015
 was approximately $28.7 million, based on a debt security with a
 comparable interest rate and maturity and a Standard &
 Poor’s credit rating of AAA. We are required to make payments
 to the Authority in amounts necessary to pay the interest on the
 Amended and Restated Bond. Included in long-term investments at
 December 31, 2015 is $30.0 million which is invested in a
 restricted certificate of deposit. These funds serve as a
 collateral deposit against the principal of this bond, and we have
 the right to set-off the balance of the Bond with the collateral
 deposit in order to reduce the balance of the indebtedness.

[0001193125-16-475816:notes:288]
In conjunction with this program, we are eligible to receive
 certain economic incentives from the state of Alabama that reduce
 the amount of payroll withholdings that we are required to remit to
 the state for those employment positions that qualify under the
 program. We realized economic incentives related to payroll
 withholdings totaling $1.3 million for each of the years ended
 December 31, 2015, 2014 and 2013.

[0001193125-16-475816:notes:289]
We made a principal payment of $1.1 million and $16.5 million for
 the years ended December 31, 2015 and 2014, respectively. At
 December 31, 2015, $1.0 million of the bond debt was
 classified as a current liability in accounts payable in the
 Consolidated Balance Sheets.
