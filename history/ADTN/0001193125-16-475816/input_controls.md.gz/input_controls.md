# ADTN 10-K controls and the auditor's report


## auditors_report

10-K auditors_report: 2 candidate headings, none whose body matches 'critical audit matter'.


## item_9a

[0001193125-16-475816:item_9a:1]
ITEM 9A. CONTROLS AND PROCEDURES

[0001193125-16-475816:item_9a:2]
| (a) | Internal control over financial reporting. Section 404 of the Sarbanes-Oxley Act of 2002 requires management to include in this Annual Report on Form 10-K a report on management’s assessment of the effectiveness of our internal control over financial reporting, as well as a report from our independent registered public accounting firm on the effectiveness of internal control over financial reporting. Management’s report on internal control over financial reporting is included below and the related report from our independent registered public accounting firm is located in Item 8 “Financial Statements and Supplementary Data” of this report. |

[0001193125-16-475816:item_9a:3]
| (b) | Evaluation of disclosure controls and procedures. Our Chief Executive Officer and Chief Financial Officer are responsible for establishing and maintaining “disclosure controls and procedures” (as defined in the Securities Exchange Act of 1934 Rules 13a-15(e) and 15d-15(e)) for the company. Our Chief Executive Officer and Chief Financial Officer, after evaluating the effectiveness of our disclosure controls and procedures as of the end of the period covered by this annual report, have concluded that our disclosure controls and procedures are effective. |

[0001193125-16-475816:item_9a:4]
| (c) | Changes in internal control over financial reporting. There were no changes in our internal control over financial reporting that occurred during our most recent fiscal quarter that have materially affected, or are reasonably likely to materially affect, our internal control over financial reporting. |

[0001193125-16-475816:item_9a:5]
MANAGEMENT’S REPORT ON
INTERNAL CONTROL OVER FINANCIAL REPORTING

[0001193125-16-475816:item_9a:6]
Management of ADTRAN, Inc. is responsible for establishing and maintaining adequate internal control over
financial reporting as defined in Rules 13a-15(f) and 15d-15(f) under the Securities Exchange Act of 1934, as amended. ADTRAN’s internal control over financial reporting is designed to provide reasonable assurance regarding the reliability of
financial reporting and the preparation of financial statements for external purposes in accordance with generally accepted accounting principles. ADTRAN’s internal control over financial reporting includes those policies and procedures that:

[0001193125-16-475816:item_9a:7]
|  | • |  | pertain to the maintenance of records that, in reasonable detail, accurately and fairly reflect the transactions and dispositions of the assets of ADTRAN; |

[0001193125-16-475816:item_9a:8]
|  | • |  | provide reasonable assurance that transactions are recorded as necessary to permit preparation of financial statements in accordance with generally accepted accounting principles, and that receipts and expenditures of ADTRAN are being made only in accordance with authorizations of management and directors of ADTRAN; and |

[0001193125-16-475816:item_9a:9]
|  | • |  | provide reasonable assurance regarding prevention or timely detection of unauthorized acquisition, use or disposition of ADTRAN’s assets that could have a material effect on the financial statements. |

[0001193125-16-475816:item_9a:10]
Because of its inherent limitations, internal control over financial reporting may not prevent or detect misstatements. Also, projections
of any evaluation of effectiveness to future periods are subject to the risk that controls may become inadequate because of changes in conditions, or that the degree of compliance with the policies or procedures may deteriorate.

[0001193125-16-475816:item_9a:11]
Management assessed the effectiveness of ADTRAN’s internal control over financial reporting as of December 31, 2015. In making this
assessment, management used the criteria set forth by the Committee of Sponsoring Organizations of the Treadway Commission (COSO) in Internal Control-Integrated Framework (2013).

[0001193125-16-475816:item_9a:12]
Based on our assessment and those criteria, management has concluded that ADTRAN maintained effective internal control over financial reporting as of
December 31, 2015.

[0001193125-16-475816:item_9a:13]
The effectiveness of our internal control over financial reporting has been audited by PricewaterhouseCoopers LLP, an independent
registered public accounting firm, as stated in their report which appears herein.

[0001193125-16-475816:item_9a:14]
80
