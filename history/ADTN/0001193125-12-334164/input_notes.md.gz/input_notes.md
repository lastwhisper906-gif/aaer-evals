# ADTN notes — 0001193125-12-334164


## us-gaap:OrganizationConsolidationAndPresentationOfFinancialStatementsDisclosureTextBlock

[0001193125-12-334164:notes:1]
[same as prior period, unchanged from 0001193125-12-220696:notes:70]

[0001193125-12-334164:notes:2]
Basis of Presentation

[0001193125-12-334164:notes:3]
The accompanying unaudited consolidated financial statements of
   ADTRAN®, Inc. and its subsidiaries (ADTRAN) have been prepared pursuant to the rules and regulations for
   reporting on Quarterly Reports on Form 10-Q. Accordingly, certain information and notes required by generally accepted accounting principles for complete financial statements are not included herein. The December 31, 2011 Consolidated Balance
   Sheet is derived from audited financial statements, but does not include all disclosures required by accounting principles generally accepted in the United States.

[0001193125-12-334164:notes:4]
In the opinion of management, all adjustments necessary for a fair presentation of these interim statements have been included and are of a normal and recurring nature. The results of operations for an
   interim period are not necessarily indicative of the results for the full year. The interim statements should be read in conjunction with the financial statements and notes thereto included in ADTRAN’s Annual Report on Form 10-K for the year
   ended December 31, 2011, filed on February 29, 2012 with the SEC.

[0001193125-12-334164:notes:5]
[same as prior period, unchanged from 0001193125-12-220696:notes:71]

[0001193125-12-334164:notes:6]
The preparation of financial statements in conformity with accounting principles generally accepted in the United States of America requires management to make estimates and assumptions that affect the
   reported amounts of assets and liabilities, the disclosure of contingent assets and liabilities at the date of the financial statements, and the reported amounts of revenue and expense during the reporting period. Our more significant estimates
   include the allowance for doubtful accounts, obsolete and excess inventory reserves, warranty reserves, customer rebates, allowance for sales returns, determination of the deferred revenue components of multiple element sales agreements, estimated
   costs to complete obligations associated with deferred revenues, estimated income tax contingencies, the fair value of stock-based compensation, impairment of goodwill, value and estimated lives of intangible assets, and the evaluation of
   other-than-temporary declines in the value of investments. Actual amounts could differ significantly from these estimates.

[0001193125-12-334164:notes:7]
[same as prior period, unchanged from 0001193125-12-220696:notes:73]

[0001193125-12-334164:notes:8]
During the six months ended June 30, 2012, we adopted the following accounting standards, which had no material effect on our consolidated results of operations or financial condition:

[0001193125-12-334164:notes:9]
In June 2011, the Financial Accounting Standards Board (FASB) issued Accounting Standards Update
   No. 2011-05, Presentation of Comprehensive Income (ASU 2011-05). ASU 2011-05 requires companies to present the components of net income and other comprehensive income either as one continuous statement or as two consecutive statements. ASU
   2011-05 eliminates the option to present the components of other comprehensive income as part of the statement of changes in stockholders’ equity. While ASU 2011-05 changes the presentation of comprehensive income, it does not change the
   components that are recognized in net income or comprehensive income under current accounting guidance. This update is effective for fiscal years, and interim periods within those years, ending after December 15, 2011, with early adoption
   permitted. We adopted this amendment during the first quarter of 2012, and we have provided the disclosures required for the three and six months ended June 30, 2012 and 2011.

[0001193125-12-334164:notes:10]
In December 2011, the FASB issued Accounting Standards Update No. 2011-12, Deferral of the Effective Date for Amendments to the Presentation of Reclassifications of Items Out of Accumulated Other
   Comprehensive Income in Accounting Standards Update No. 2011-05 (ASU 2011-12). ASU 2011-12 defers the effective date for certain presentation requirements that relate to reclassification adjustments and the effect of those reclassification
   adjustments on the financial statements. This update is effective for fiscal years, and interim periods within those years, ending after December 15, 2011, with early adoption permitted. We adopted this amendment during the first quarter of
   2012. The adoption of this amendment had no effect on our consolidated results of operations and financial condition for the three and six months ended June 30, 2012.

[0001193125-12-334164:notes:11]
In May 2011, the FASB issued Accounting Standards Update No. 2011-04, Amendments to
   Achieve Common Fair Value Measurement and Disclosure Requirements in U.S. GAAP and IFRSs (ASU 2011-04). ASU 2011-04 is intended to improve the comparability of fair value measurements presented and disclosed in financial statements prepared in
   accordance with U.S. GAAP and IFRS. The amendments are of two types: (i) those that clarify the Board’s intent about the application of existing fair value measurement and disclosure requirements and (ii) those that change a
   particular principle or requirement for measuring fair value or for disclosing information about fair value measurements. This update is effective for annual periods beginning after December 15, 2011. We adopted this amendment during the first
   quarter of 2012. The adoption of this amendment had no effect on our consolidated results of operations and financial condition for the three and six months ended June 30, 2012.


## us-gaap:BusinessCombinationDisclosureTextBlock

[0001193125-12-334164:notes:12]
[same as prior period, unchanged from 0001193125-12-220696:notes:5]

[0001193125-12-334164:notes:13]
On May 4, 2012, we acquired the Nokia Siemens Networks (NSN) Broadband Access business (NSN BBA business). This acquisition
   provides us with an established customer base in key markets and complementary, market-focused products and was accounted for as a business combination. We have included the financial results of the NSN BBA business in our consolidated financial
   statements since the date of acquisition.

[0001193125-12-334164:notes:14]
We received a cash payment of $7.5 million from NSN and recorded a bargain purchase gain of $1.8
   million, net of income taxes, subject to customary working capital adjustments between the parties. The bargain purchase gain represents the excess of the consideration exchanged over the fair value of the assets acquired and liabilities assumed. We
   have assessed the recognition and measurements of the assets acquired and liabilities assumed based on historical and pro forma data for future periods and have concluded that our valuation procedures and resulting measures were appropriate. The
   gain is included in the line item “Gain on bargain purchase of a business” in the 2012 Consolidated Statements of Income.

[0001193125-12-334164:notes:15]
The
   preliminary allocation of the purchase price to the estimated fair value of the assets acquired and liabilities assumed at the acquisition date is as follows:

[0001193125-12-334164:notes:16]
| (In Thousands) |  |  |  |
| Other receivables |  | $ | 395 |  |
| Inventory |  |  | 22,278 |  |
| Property, plant and equipment |  |  | 5,035 |  |
| Accounts payable |  |  | (5,194 | ) |
| Unearned revenue |  |  | (13,579 | ) |
| Accrued expenses |  |  | (1,931 | ) |
| Accrued wages and benefits |  |  | (2,251 | ) |
| Deferred tax liability |  |  | (788 | ) |
| Non-current unearned revenue |  |  | (18,059 | ) |
| Net liabilities assumed |  |  | (14,094 | ) |
| Customer relationships |  |  | 5,162 |  |
| Developed technology |  |  | 3,176 |  |
| Other |  |  | 13 |  |
| Gain on bargain purchase of a business, net of tax |  |  | (1,753 | ) |
| Net consideration received by buyer |  | $ | (7,496 | ) |

[0001193125-12-334164:notes:17]
The fair value of the customer relationships acquired was calculated using a discounted cash flow method (excess earnings) and is being
   amortized using a declining balance method derived from projected customer revenue over an average estimated useful life of 13 years. The fair value of the developed technology acquired was calculated using a discounted cash flow method (relief from
   royalty) and is being amortized using the straight-line method over an estimated useful life of five years.

[0001193125-12-334164:notes:18]
The following supplemental pro forma
   information presents the financial results as if the acquisition of the NSN BBA business had occurred on January 1, 2011. This supplemental pro forma information does not purport to be indicative of what would have occurred had the acquisition
   of the NSN BBA business been completed on January 1, 2011, nor are they indicative of any future results.

[0001193125-12-334164:notes:19]
The actual revenue and pre-tax
   income excluding the bargain purchase gain included in our Consolidated Statements of Income from May 4, 2012 to June 30, 2012 was $22.6 million and $(0.4) million, respectively.

[0001193125-12-334164:notes:20]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |
| Pro forma revenue |  | $ | 40,164 |  |  | $ | 46,951 |  |  | $ | 74,070 |  |  | $ | 108,285 |  |
| Pro forma pre-tax income |  | $ | (3,813 | ) |  | $ | (14,138 | ) |  | $ | (15,458 | ) |  | $ | (21,040 | ) |
| Weighted average exchange rate during the period (EURO/USD) |  | € | 1.00/$1.29 |  |  | € | 1.00/$1.44 |  |  | € | 1.00/$1.30 |  |  | € | 1.00/$1.40 |  |

[0001193125-12-334164:notes:21]
For the three and six months ended June 30, 2012, we incurred acquisition and integration related expenses and amortization of
   acquired intangibles of $3.9 million and $5.5 million, respectively, related to this acquisition.

[0001193125-12-334164:notes:22]
On August 4, 2011, we acquired all of
   the outstanding stock of Bluesocket, Inc., a provider of wireless network solutions with virtual control, for $23.7 million in cash. The acquisition provides us with IEEE802.11N enterprise class wireless LAN expertise, technology, and products to
   address the growing transition within small-medium enterprises and large enterprises to wireless networks and mobile devices. We have included the financial results of Bluesocket in our consolidated financial statements since the date of
   acquisition. Pro forma results of operations prior to the closing date for the acquisition have not been presented because the effect of the acquisition was not material to our financial results.

[0001193125-12-334164:notes:23]
The allocation of the purchase price to the estimated fair value of the assets acquired and liabilities assumed at the acquisition date is as follows:

[0001193125-12-334164:notes:24]
[same as prior period, unchanged from 0001193125-12-220696:notes:7]

[0001193125-12-334164:notes:25]
During the fourth quarter of 2011, the purchase price and purchase price allocation were adjusted for our final valuations. The
   adjustments resulted in a decrease to the goodwill recognized in the transaction.

[0001193125-12-334164:notes:26]
The net deferred tax assets acquired are primarily related
   to net operating losses and previously capitalized and unamortized research and development expense for tax deduction purposes.

[0001193125-12-334164:notes:27]
The fair value of the customer
   relationships, developed technology and intellectual property acquired was calculated using an income approach (excess earnings method) and is being amortized using the straight-line method. The customer relationships and intellectual property are
   being amortized over an estimated useful life of 7 years and the developed technology is being amortized over an average estimated useful life of 4.5 years.

[0001193125-12-334164:notes:28]
The fair value of the trade names acquired was calculated using an income approach (relief from royalty method) and is being amortized using the straight-line method over the estimate useful life of 4.5
   years.

[0001193125-12-334164:notes:29]
The goodwill of $3.5 million generated from this acquisition is primarily related to expected synergies and was assigned to our
   Enterprise Networks division. The goodwill will not be deductible for U.S. federal income tax purposes.

[0001193125-12-334164:notes:30]
For the three and six months ended
   June 30, 2012, we incurred acquisition and integration related expenses and amortization of acquired intangibles of $0.4 million and $0.9 million, respectively, related to this acquisition.


## us-gaap:IncomeTaxDisclosureTextBlock

[0001193125-12-334164:notes:31]
[same as prior period, unchanged from 0001193125-12-220696:notes:49]

[0001193125-12-334164:notes:32]
Our effective tax rate increased from 32.5% in the six months ended June 30, 2011 to 35.6% in the six months ended June 30,
   2012. The tax provision rate in the six months ended June 30, 2012 did not include the benefit of the research tax credit, which expired on December 31, 2011. The exclusion of this benefit during the six months ended June 30,
   2012 resulted in a 2.2 percentage point increase in our effective tax rate. Also, decreased benefits from a lower volume of stock option exercises in the six months ended June 30, 2012 resulted in a 1.4 percentage point increase in our
   effective tax rate. Finally, the closure of an audit resulted in a 0.4 percentage point decrease in our effective tax rate for the six months ended June 30, 2012.

[0001193125-12-334164:notes:33]
During the three months ended June 30, 2012, we acquired the NSN BBA business, which resulted in a bargain purchase gain reported on the income statement. The bargain purchase gain is presented net
   of tax in the income statement and a deferred tax liability was established in the opening balance sheet for the acquired entity.


## us-gaap:PensionAndOtherPostretirementBenefitsDisclosureTextBlock

[0001193125-12-334164:notes:34]
4. PENSION BENEFIT PLAN

[0001193125-12-334164:notes:35]
As a result of our acquisition of the NSN BBA business, we assumed a defined benefit obligation plan from NSN. As a result, we
   established a Contribution Trust Arrangement (CTA) as a vehicle to hold the pension assets. NSN has estimated the amount of the defined benefit obligation to be approximately $17.8 million. We are in the process of verifying the estimated defined
   benefit obligation in order to determine the value of assets to be transferred from NSN to us to fund the pension obligation. We anticipate the assets to be transferred will be equal to the defined benefit obligation as of the date of the
   acquisition.

[0001193125-12-334164:notes:36]
The following table summarizes the components of net periodic pension cost for the period May 4, 2012 to June 30,
   2012:

[0001193125-12-334164:notes:37]
|  |  | May 4, 2012 to |  |
| (In thousands) |  | June 30, 2012 |  |
| Service cost |  | $ | 190 |  |
| Interest cost |  |  | 127 |  |
| Expected return on plan assets |  |  | (165 | ) |
| Net periodic pension cost |  | $ | 152 |  |


## us-gaap:DisclosureOfCompensationRelatedCostsShareBasedPaymentsTextBlock

[0001193125-12-334164:notes:38]
5. STOCK-BASED COMPENSATION

[0001193125-12-334164:notes:39]
The following table summarizes the stock-based compensation expense related to stock options, restricted stock units (RSUs) and
   restricted stock for the three and six months ended June 30, 2012 and 2011, which was recognized as follows:

[0001193125-12-334164:notes:40]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |
| Stock-based compensation expense included in cost of sales |  | $ | 97 |  |  | $ | 89 |  |  | $ | 198 |  |  | $ | 180 |  |
| Selling, general and administrative expense |  |  | 1,047 |  |  |  | 999 |  |  |  | 2,098 |  |  |  | 2,006 |  |
| Research and development expense |  |  | 1,067 |  |  |  | 988 |  |  |  | 2,136 |  |  |  | 1,979 |  |
| Stock-based compensation expense included in operating expenses |  |  | 2,114 |  |  |  | 1,987 |  |  |  | 4,234 |  |  |  | 3,985 |  |
| Total stock-based compensation expense |  |  | 2,211 |  |  |  | 2,076 |  |  |  | 4,432 |  |  |  | 4,165 |  |
| Tax benefit for expense associated with non-qualified options |  |  | (302 | ) |  |  | (276 | ) |  |  | (603 | ) |  |  | (716 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 1,909 |  |  | $ | 1,800 |  |  | $ | 3,829 |  |  | $ | 3,449 |  |

[0001193125-12-334164:notes:41]
The fair value of our stock options was estimated using the Black-Scholes model. The determination of the fair value of stock options
   on the date of grant using the Black-Scholes model is affected by our stock price as well as assumptions regarding a number of complex and subjective variables that may have a significant impact on the fair value estimate.

[0001193125-12-334164:notes:42]
There were no options granted during the three and six months ended June 30, 2012. The weighted-average assumptions and value of options granted for
   the three and six months ended June 30, 2011 are summarized as follows:

[0001193125-12-334164:notes:43]
|  |  | Three Months |  |  | Six Months |  |
|  |  | Ended |  |  | Ended |  |
|  |  | June 30,2011 |  |  | June 30,2011 |  |
| Expected volatility |  |  | 37.68 | % |  |  | 37.68 | % |
| Risk-free interest rate |  |  | 2.18 | % |  |  | 2.18 | % |
| Expected dividend yield |  |  | 0.86 | % |  |  | 0.86 | % |
| Expected life (in years) |  |  | 4.94 |  |  |  | 4.94 |  |
| Weighted-average estimated value |  | $ | 13.93 |  |  | $ | 13.93 |  |

[0001193125-12-334164:notes:44]
The fair value of our RSUs is calculated using a Monte Carlo Simulation valuation method. There were no RSU grants during the six
   months ended June 30, 2012 or 2011.

[0001193125-12-334164:notes:45]
The fair value of restricted stock is equal to the closing price of our stock on the date of grant.
   There were no restricted stock grants during the six months ended June 30, 2012 or 2011.

[0001193125-12-334164:notes:46]
Stock-based compensation expense recognized in
   our Consolidated Statements of Income for the three and six months ended June 30, 2012 and 2011 is based on options, RSUs and restricted stock ultimately expected to vest, and has been reduced for estimated forfeitures. Estimated forfeitures
   for stock options were based upon historical experience and approximate 1.6% annually. We estimated a 0% forfeiture rate for our RSUs and restricted stock due to the limited number of recipients and historical experience for these awards.

[0001193125-12-334164:notes:47]
As of June 30, 2012, total compensation expense related to non-vested stock options, RSUs and restricted stock not yet recognized was
   approximately $17.3 million, which is expected to be recognized over an average remaining recognition period of 2.5 years.

[0001193125-12-334164:notes:48]
The following table is a summary of
   our stock options outstanding as of December 31, 2011 and June 30, 2012 and the changes that occurred during the six months ended June 30, 2012:

[0001193125-12-334164:notes:49]
| (In thousands, except per share amounts) |  | Number ofOptions |  |  | Weighted Avg.Exercise Price |  |  | Weighted Avg.RemainingContractualLife In Years |  |  | AggregateIntrinsicValue |  |
| Options outstanding, December 31, 2011 |  |  | 5,400 |  |  | $ | 25.66 |  |  |  | 6.78 |  |  | $ | 27,270 |  |
| Options granted |  |  | — |  |  | $ | — |  |  |  |  |  |  |  |  |  |
| Options cancelled/forfeited |  |  | (32 | ) |  | $ | 26.31 |  |  |  |  |  |  |  |  |  |
| Options exercised |  |  | (225 | ) |  | $ | 19.25 |  |  |  |  |  |  |  |  |  |
| Options outstanding, June 30, 2012 |  |  | 5,143 |  |  | $ | 25.94 |  |  |  | 6.36 |  |  | $ | 25,607 |  |
| Options exercisable, June 30, 2012 |  |  | 2,833 |  |  | $ | 23.83 |  |  |  | 4.74 |  |  | $ | 19,317 |  |

[0001193125-12-334164:notes:50]
The aggregate intrinsic values in the table above represent the total pre-tax intrinsic value (the difference between ADTRAN’s
   closing stock price on the last trading day of the quarter and the exercise price, multiplied by the number of in-the-money options) that would have been received by the option holders had all option holders exercised their options on June 30,
   2012. The aggregate intrinsic value will change based on the fair market value of ADTRAN’s stock.

[0001193125-12-334164:notes:51]
The total pre-tax intrinsic value of
   options exercised during the three and six month periods ended June 30, 2012 was $0.6 million and $3.6 million, respectively.

[0001193125-12-334164:notes:52]
The
   following table is a summary of our RSUs and restricted stock outstanding as of December 31, 2011 and June 30, 2012 and the changes that occurred during the six months ended June 30, 2012:

[0001193125-12-334164:notes:53]
| (In thousands, except per share amounts) |  | Numberof Shares |  |  | WeightedAverageGrant DateFair Value |  |
| Unvested RSUs and restricted stock outstanding, December 31, 2011 |  |  | 90 |  |  | $ | 34.21 |  |
| RSUs and restricted stock granted |  |  | — |  |  | $ | — |  |
| RSUs and restricted stock vested |  |  | — |  |  | $ | — |  |
| RSUs and restricted stock cancelled/forfeited |  |  | — |  |  | $ | — |  |
| Unvested RSUs and restricted stock, June 30, 2012 |  |  | 90 |  |  | $ | 34.21 |  |


## us-gaap:InvestmentsInDebtAndMarketableEquitySecuritiesAndCertainTradingAssetsDisclosureTextBlock

[0001193125-12-334164:notes:54]
6. INVESTMENTS

[0001193125-12-334164:notes:55]
At June 30, 2012, we held the following securities and investments, recorded at either fair value or cost.

[0001193125-12-334164:notes:56]
| (In thousands) |  | AmortizedCost |  |  | Gross Unrealized |  |  | CarryingValue |  |
|  |  | Gains |  |  | Losses |  |  |
| Deferred compensation plan assets |  | $ | 10,598 |  |  | $ | 392 |  |  | $ | (190 | ) |  | $ | 10,800 |  |
| Corporate bonds |  |  | 183,282 |  |  |  | 786 |  |  |  | (333 | ) |  |  | 183,735 |  |
| Municipal fixed-rate bonds |  |  | 188,845 |  |  |  | 696 |  |  |  | (23 | ) |  |  | 189,518 |  |
| Municipal variable rate demand notes |  |  | 46,790 |  |  |  | — |  |  |  | — |  |  |  | 46,790 |  |
| Fixed income bond fund |  |  | 846 |  |  |  | — |  |  |  | — |  |  |  | 846 |  |
| Marketable equity securities |  |  | 18,052 |  |  |  | 18,423 |  |  |  | (603 | ) |  |  | 35,872 |  |
| Available-for-sale securities held at fair value |  | $ | 448,413 |  |  | $ | 20,297 |  |  | $ | (1,149 | ) |  | $ | 467,561 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 48,250 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 2,062 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 517,873 |  |

[0001193125-12-334164:notes:57]
At December 31, 2011, we held the following securities and investments, recorded at either fair value or cost.

[0001193125-12-334164:notes:58]
| (In thousands) |  | AmortizedCost |  |  | Gross Unrealized |  |  | CarryingValue |  |
|  |  | Gains |  |  | Losses |  |  |
| Deferred compensation plan assets |  | $ | 7,994 |  |  | $ | 119 |  |  | $ | (401 | ) |  | $ | 7,712 |  |
| Corporate bonds |  |  | 159,077 |  |  |  | 181 |  |  |  | (2,505 | ) |  |  | 156,753 |  |
| Municipal fixed-rate bonds |  |  | 174,300 |  |  |  | 579 |  |  |  | (53 | ) |  |  | 174,826 |  |
| Municipal variable rate demand notes |  |  | 69,660 |  |  |  | — |  |  |  | — |  |  |  | 69,660 |  |
| Fixed income bond fund |  |  | 527 |  |  |  | 194 |  |  |  | — |  |  |  | 721 |  |
| Marketable equity securities |  |  | 12,771 |  |  |  | 19,098 |  |  |  | (559 | ) |  |  | 31,310 |  |
| Available-for-sale securities held at fair value |  | $ | 424,329 |  |  | $ | 20,171 |  |  | $ | (3,518 | ) |  | $ | 440,982 |  |
| Restricted investment held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 48,250 |  |
| Other investments held at cost |  |  |  |  |  |  |  |  |  |  |  |  |  |  | 2,123 |  |
| Total carrying value of available-for-sale investments |  |  |  |  |  |  |  |  |  |  |  |  |  | $ | 491,355 |  |

[0001193125-12-334164:notes:59]
As of June 30, 2012, our corporate bonds and municipal fixed-rate bonds had the following contractual maturities:

[0001193125-12-334164:notes:60]
| (In thousands) |  | Corporatebonds |  |  | Municipalfixed-ratebonds |  |
| Less than one year |  | $ | 39,614 |  |  | $ | 83,045 |  |
| One to two years |  |  | 114,900 |  |  |  | 56,268 |  |
| Two to three years |  |  | 29,221 |  |  |  | 7,210 |  |
| Three to five years |  |  | — |  |  |  | 42,995 |  |
| Total |  | $ | 183,735 |  |  | $ | 189,518 |  |

[0001193125-12-334164:notes:61]
Our investment policy provides limitations for issuer concentration, which limits, at the time of purchase, the concentration in any
   one issuer to 5% of the market value of our total investment portfolio.

[0001193125-12-334164:notes:62]
We review our investment portfolio for
   potential “other-than-temporary” declines in value on an individual investment basis. We assess, on a quarterly basis, significant declines in value which may be considered other-than-temporary and, if necessary, recognize and record the
   appropriate charge to write-down the carrying value of such investments. In making this assessment, we take into consideration qualitative and quantitative information, including but not limited to the following: the magnitude and duration of
   historical declines in market prices, credit rating activity, assessments of liquidity, public filings, and statements made by the issuer. We generally begin our identification of potential other-than-temporary impairments by reviewing any security
   with a fair value that has declined from its original or adjusted cost basis by 25% or more for six or more consecutive months. We then evaluate the individual security based on the previously identified factors to determine the amount of the
   write-down, if any. As a result of our review, we recorded an other-than-temporary impairment charge of $33 thousand during the six months ended June 30, 2012 related to eight marketable equity securities. For the six months ended June 30,
   2011, we recorded an other-than-temporary impairment charge of $12 thousand related to three marketable equity securities.

[0001193125-12-334164:notes:63]
Realized gains and
   losses on sales of securities are computed under the specific identification method. The following table presents gross realized gains and losses related to our investments.

[0001193125-12-334164:notes:64]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |
| Gross realized gains |  | $ | 2,631 |  |  | $ | 3,505 |  |  | $ | 5,300 |  |  | $ | 6,369 |  |
| Gross realized losses |  | $ | (275 | ) |  | $ | (133 | ) |  | $ | (477 | ) |  | $ | (230 | ) |

[0001193125-12-334164:notes:65]
As of June 30, 2012 and 2011, gross unrealized losses related to individual securities that had been in a continuous loss position
   for 12 months or longer were not significant.

[0001193125-12-334164:notes:66]
In accordance with the Fair Value Measurements and Disclosures Topic of the FASB ASC, we have
   categorized our cash equivalents held in money market funds and our investments held at fair value into a three-level fair value hierarchy based on the priority of the inputs to the valuation technique for the cash equivalents and investments as
   follows: Level 1 – Values based on unadjusted quoted prices for identical assets or liabilities in an active market; Level 2 – Values based on quoted prices in markets that are not active or model inputs that are observable either directly
   or indirectly; Level 3 – Values based on prices or valuation techniques that require inputs that are both unobservable and significant to the overall fair value measurement. These inputs include information supplied by investees.

[0001193125-12-334164:notes:67]
|  |  | Fair Value Measurements at June 30, 2012 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket forIdenticalAssets (Level 1) |  |  | SignificantOtherObservableInputs (Level 2) |  |  | SignificantUnobservableInputs(Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 9,250 |  |  | $ | 9,250 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 10,800 |  |  |  | 10,800 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 183,735 |  |  |  | — |  |  |  | 183,735 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 189,518 |  |  |  | — |  |  |  | 189,518 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 46,790 |  |  |  | — |  |  |  | 46,790 |  |  |  | — |  |
| Fixed income bond fund |  |  | 846 |  |  |  | 846 |  |  |  | — |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity securities – technology industry |  |  | 18,053 |  |  |  | 18,053 |  |  |  | — |  |  |  | — |  |
| Equity securities – other |  |  | 17,819 |  |  |  | 17,819 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 467,561 |  |  |  | 47,518 |  |  |  | 420,043 |  |  |  | — |  |
| Total |  | $ | 476,811 |  |  | $ | 56,768 |  |  | $ | 420,043 |  |  | $ | — |  |

[0001193125-12-334164:notes:68]
|  |  | Fair Value Measurements at December 31, 2011 Using |  |
| (In thousands) |  | Fair Value |  |  | Quoted Pricesin ActiveMarket forIdenticalAssets (Level 1) |  |  | SignificantOtherObservableInputs (Level 2) |  |  | SignificantUnobservableInputs(Level 3) |  |
| Cash equivalents |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Money market funds |  | $ | 13,696 |  |  | $ | 13,696 |  |  | $ | — |  |  | $ | — |  |
| Available-for-sale securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Deferred compensation plan assets |  |  | 7,712 |  |  |  | 7,712 |  |  |  | — |  |  |  | — |  |
| Available-for-sale debt securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Corporate bonds |  |  | 156,753 |  |  |  | — |  |  |  | 156,753 |  |  |  | — |  |
| Municipal fixed-rate bonds |  |  | 174,826 |  |  |  | — |  |  |  | 174,826 |  |  |  | — |  |
| Municipal variable rate demand notes |  |  | 69,660 |  |  |  | — |  |  |  | 69,660 |  |  |  | — |  |
| Fixed income bond fund |  |  | 721 |  |  |  | 721 |  |  |  | — |  |  |  | — |  |
| Available-for-sale marketable equity securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Equity securities – technology industry |  |  | 18,743 |  |  |  | 18,743 |  |  |  | — |  |  |  | — |  |
| Equity securities – other |  |  | 12,567 |  |  |  | 12,567 |  |  |  | — |  |  |  | — |  |
| Available-for-sale securities |  |  | 440,982 |  |  |  | 39,743 |  |  |  | 401,239 |  |  |  | — |  |
| Total |  | $ | 454,678 |  |  | $ | 53,439 |  |  | $ | 401,239 |  |  | $ | — |  |

[0001193125-12-334164:notes:69]
The fair value of our Level 2 securities is calculated using a weighted average market price for each security. Market prices are
   obtained from a variety of industry standard data providers, security master files from large financial institutions, and other third-party sources. These multiple market prices are used as inputs into a distribution-curve-based algorithm to
   determine the daily market value of each security.

[0001193125-12-334164:notes:70]
Our municipal variable rate demand
   notes have a structure that implies a standard expected market price. The frequent interest rate resets make it reasonable to expect the price to stay at par. These securities are priced at the expected market price.


## us-gaap:InventoryDisclosureTextBlock

[0001193125-12-334164:notes:71]
7. INVENTORY

[0001193125-12-334164:notes:72]
At June 30, 2012 and December 31, 2011, inventory consisted of the following:

[0001193125-12-334164:notes:73]
|  |  | June 30, |  |  | December 31, |  |
| (In thousands) |  | 2012 |  |  | 2011 |  |
| Raw materials |  | $ | 49,669 |  |  | $ | 44,588 |  |
| Work in process |  |  | 4,272 |  |  |  | 3,954 |  |
| Finished goods |  |  | 49,835 |  |  |  | 39,258 |  |
| Total |  | $ | 103,776 |  |  | $ | 87,800 |  |

[0001193125-12-334164:notes:74]
We establish reserves for estimated excess, obsolete, or unmarketable inventory equal to the difference between the cost of the
   inventory and the estimated fair value of the inventory based upon assumptions about future demand and market conditions. At June 30, 2012 and December 31, 2011, raw materials reserves totaled $8.6 million and $7.9 million, respectively,
   and finished goods inventory reserves totaled $1.6 million and $1.5 million, respectively.


## us-gaap:GoodwillDisclosureTextBlock

[0001193125-12-334164:notes:75]
8. GOODWILL AND INTANGIBLE ASSETS

[0001193125-12-334164:notes:76]
The changes in the carrying value of goodwill, all of which is included in our Enterprise Networks division, for the six months ended
   June 30, 2012 are as follows:

[0001193125-12-334164:notes:77]
| (In thousands) |  |  |  |
| Balance, December 31, 2011 |  | $ | 3,492 |  |
| Acquisitions |  |  | — |  |
| Impairment losses |  |  | — |  |
| Balance, June 30, 2012 |  | $ | 3,492 |  |
| Balance as of June 30, 2012 |  |  |  |  |
| Goodwill |  | $ | 3,492 |  |
| Accumulated impairment losses |  |  | — |  |
| Total goodwill |  | $ | 3,492 |  |

[0001193125-12-334164:notes:78]
We evaluate the carrying value of goodwill during the fourth quarter of each year and between annual evaluations if events occur or
   circumstances change that would more likely than not reduce the fair value of the reporting unit below its carrying amount. When evaluating whether goodwill is impaired, we first assess qualitative factors to determine whether it is necessary to
   perform the two-step quantitative goodwill impairment test. If we determine that the two-step quantitative test is necessary, then we compare the fair value of the reporting unit to which the goodwill is assigned to the reporting unit’s
   carrying amount, including goodwill. If the carrying amount of the reporting unit exceeds its fair value, then the amount of the impairment loss is measured. There were no impairment losses during the six months ended June 30, 2012.

[0001193125-12-334164:notes:79]
The following table presents our
   intangible assets as of June 30, 2012 and December 31, 2011. Intangible assets are included in other assets in the accompanying Consolidated Balance Sheets and include intangibles acquired in conjunction with our acquisition of Objectworld
   Communications Corporation on September 15, 2009, Bluesocket, Inc. on August 4, 2011, and the NSN BBA business on May 4, 2012.

[0001193125-12-334164:notes:80]
|  |  | June 30, 2012 |  |  | December 31, 2011 |  |
| (In thousands) |  | GrossValue |  |  | AccumulatedAmortization |  |  | Net Value |  |  | GrossValue |  |  | AccumulatedAmortization |  |  | Net Value |  |
| Customer relationships |  | $ | 6,559 |  |  | $ | (361 | ) |  | $ | 6,198 |  |  | $ | 1,623 |  |  | $ | (194 | ) |  | $ | 1,429 |  |
| Developed technology |  |  | 6,267 |  |  |  | (704 | ) |  |  | 5,563 |  |  |  | 3,230 |  |  |  | (303 | ) |  |  | 2,927 |  |
| Intellectual property |  |  | 2,340 |  |  |  | (684 | ) |  |  | 1,656 |  |  |  | 2,340 |  |  |  | (525 | ) |  |  | 1,815 |  |
| Trade names |  |  | 270 |  |  |  | (55 | ) |  |  | 215 |  |  |  | 270 |  |  |  | (28 | ) |  |  | 242 |  |
| Other |  |  | 13 |  |  |  | (1 | ) |  |  | 12 |  |  |  | — |  |  |  | — |  |  |  | — |  |
| Total |  | $ | 15,449 |  |  | $ | (1,805 | ) |  | $ | 13,644 |  |  | $ | 7,463 |  |  | $ | (1,050 | ) |  | $ | 6,413 |  |

[0001193125-12-334164:notes:81]
Amortization expense was $0.5 million and $0.1 million for the three months ended June 30, 2012 and 2011, respectively, and $0.8
   million and $0.1 million for the six months ended June 30, 2012 and 2011, respectively.

[0001193125-12-334164:notes:82]
As of June 30, 2012, the estimated future
   amortization expense of our intangible assets is as follows:

[0001193125-12-334164:notes:83]
| (In thousands) |  | Amount |  |
| Remainder of 2012 |  | $ | 1,145 |  |
| 2013 |  |  | 2,291 |  |
| 2014 |  |  | 2,141 |  |
| 2015 |  |  | 2,036 |  |
| 2016 |  |  | 1,796 |  |
| Thereafter |  |  | 4,235 |  |
| Total |  | $ | 13,644 |  |


## us-gaap:StockholdersEquityNoteDisclosureTextBlock

[0001193125-12-334164:notes:84]
9. STOCKHOLDERS’ EQUITY

[0001193125-12-334164:notes:85]
A summary of the changes in stockholders’ equity for the six months ended June 30, 2012 is as follows:

[0001193125-12-334164:notes:86]
| (In thousands) |  | Stockholders’ Equity |  |
| Balance, December 31, 2011 |  | $ | 692,131 |  |
| Net income |  |  | 34,031 |  |
| Dividend payments |  |  | (11,476 | ) |
| Dividends accrued for unvested restricted stock units |  |  | (15 | ) |
| Net change in unrealized gains and losses on marketable securities (net of deferred taxes) |  |  | 1,701 |  |
| Reclassification adjustment for amounts included in net income (net of deferred taxes) |  |  | (179 | ) |
| Foreign currency translation adjustment |  |  | 58 |  |
| Proceeds from stock option exercises |  |  | 4,328 |  |
| Purchase of treasury stock |  |  | (13,432 | ) |
| Tax benefits from stock option exercises |  |  | 1,701 |  |
| Stock-based compensation expense |  |  | 4,432 |  |
| Balance, June 30, 2012 |  | $ | 713,280 |  |

[0001193125-12-334164:notes:87]
[same as prior period, unchanged from 0001193125-12-220696:notes:104]

[0001193125-12-334164:notes:88]
Since 1997, our Board of Directors has approved multiple share repurchase programs that have authorized open market repurchase transactions of up to 35 million shares of our common stock. During the
   six months ended June 30, 2012, we repurchased 0.5 million shares of our common stock at an average price of $29.51 per share. We have the authority to purchase an additional 5.4 million shares of our common stock under plans approved
   by the Board of Directors on April 14, 2008 and October 11, 2011.

[0001193125-12-334164:notes:89]
[same as prior period, unchanged from 0001193125-12-220696:notes:106]

[0001193125-12-334164:notes:90]
We issued 0.2 million shares of treasury stock during the six months ended June 30, 2012 to accommodate employee stock option
   exercises. The stock options had exercise prices ranging from $8.70 to $33.70. We received proceeds totaling $4.3 million from the exercise of these stock options during the six months ended June 30, 2012.

[0001193125-12-334164:notes:91]
[same as prior period, unchanged from 0001193125-12-220696:notes:108]

[0001193125-12-334164:notes:92]
During the six months
   ended June 30, 2012, we paid cash dividends as follows (in thousands except per share amount):

[0001193125-12-334164:notes:93]
| Record Date |  | Payment Date |  | Per Share Amount |  |  | Total Dividend Paid |  |
| February 2, 2012 |  | February 16, 2012 |  | $ | 0.09 |  |  | $ | 5,739 |  |
| April 26, 2012 |  | May 10, 2012 |  | $ | 0.09 |  |  | $ | 5,737 |  |

[0001193125-12-334164:notes:94]
[same as prior period, unchanged from 0001193125-12-220696:notes:110]

[0001193125-12-334164:notes:95]
Other comprehensive income consists of the net change in unrealized gains and losses on marketable securities, reclassification adjustments for amounts included in net income related to realized gains on
   previously impaired marketable securities and foreign currency translation adjustments.

[0001193125-12-334164:notes:96]
The components of other comprehensive income for the
   three months ended June 30, 2012 and 2011 are as follows:

[0001193125-12-334164:notes:97]
|  |  | Three Months Ended June 30, 2012 |  |  | Three Months Ended June 30, 2011 |  |
| (In thousands) |  | Before-TaxAmount |  |  | Tax(Expense)Benefit |  |  | Net-of-TaxAmount |  |  | Before-TaxAmount |  |  | Tax(Expense)Benefit |  |  | Net-of-TaxAmount |  |
| Net change in unrealized gains (losses) related to marketable securities |  | $ | (8,285 | ) |  | $ | 3,231 |  |  | $ | (5,054 | ) |  | $ | (5,169 | ) |  | $ | 2,029 |  |  | $ | (3,140 | ) |
| Reclassification adjustment for amounts included in net income |  |  | (297 | ) |  |  | 116 |  |  |  | (181 | ) |  |  | (382 | ) |  |  | 146 |  |  |  | (236 | ) |
| Foreign currency translation adjustment |  |  | (96 | ) |  |  | — |  |  |  | (96 | ) |  |  | 369 |  |  |  | — |  |  |  | 369 |  |
| Total Other Comprehensive Income (Loss) |  | $ | (8,678 | ) |  | $ | 3,347 |  |  | $ | (5,331 | ) |  | $ | (5,182 | ) |  | $ | 2,175 |  |  | $ | (3,007 | ) |

[0001193125-12-334164:notes:98]
The components of other comprehensive income for the six months ended June 30, 2012 and 2011 are as follows:

[0001193125-12-334164:notes:99]
|  |  | Six Months Ended June 30, 2012 |  |  | Six Months Ended June 30, 2011 |  |
| (In thousands) |  | Before-TaxAmount |  |  | Tax(Expense)Benefit |  |  | Net-of-TaxAmount |  |  | Before-TaxAmount |  |  | Tax(Expense)Benefit |  |  | Net-of-TaxAmount |  |
| Net change in unrealized gains (losses) related to marketable securities |  | $ | 2,789 |  |  | $ | (1,088 | ) |  | $ | 1,701 |  |  | $ | (8,493 | ) |  | $ | 2,702 |  |  | $ | (5,791 | ) |
| Reclassification adjustment for amounts included in net income |  |  | (294 | ) |  |  | 115 |  |  |  | (179 | ) |  |  | (581 | ) |  |  | 186 |  |  |  | (395 | ) |
| Foreign currency translation adjustment |  |  | 58 |  |  |  | — |  |  |  | 58 |  |  |  | 456 |  |  |  | — |  |  |  | 456 |  |
| Total Other Comprehensive Income (Loss) |  | $ | 2,553 |  |  | $ | (973 | ) |  | $ | 1,580 |  |  | $ | (8,618 | ) |  | $ | 2,888 |  |  | $ | (5,730 | ) |


## us-gaap:EarningsPerShareTextBlock

[0001193125-12-334164:notes:100]
10. EARNINGS PER SHARE

[0001193125-12-334164:notes:101]
A summary of the calculation of basic and diluted earnings per share for the three and six months ended June 30, 2012 and 2011 is
   as follows:

[0001193125-12-334164:notes:102]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands, except per share amounts) |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |
| Numerator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Net income |  | $ | 21,070 |  |  | $ | 36,943 |  |  | $ | 34,031 |  |  | $ | 71,201 |  |
| Denominator |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Weighted average number of shares – basic |  |  | 63,619 |  |  |  | 64,690 |  |  |  | 63,720 |  |  |  | 64,441 |  |
| Effect of dilutive securities |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Stock options |  |  | 720 |  |  |  | 1,387 |  |  |  | 865 |  |  |  | 1,547 |  |
| Restricted stock and restricted stock units |  |  | 54 |  |  |  | 58 |  |  |  | 43 |  |  |  | 56 |  |
| Weighted average number of shares – diluted |  |  | 64,393 |  |  |  | 66,135 |  |  |  | 64,628 |  |  |  | 66,044 |  |
| Net income per share – basic |  | $ | 0.33 |  |  | $ | 0.57 |  |  | $ | 0.53 |  |  | $ | 1.10 |  |
| Net income per share – diluted |  | $ | 0.33 |  |  | $ | 0.56 |  |  | $ | 0.53 |  |  | $ | 1.08 |  |

[0001193125-12-334164:notes:103]
Anti-dilutive options to purchase common stock outstanding were excluded from the above calculations. Anti-dilutive options
   totaled 2.5 million and 0.9 million for the three months ended June 30, 2012 and 2011, respectively, and 2.1 million and 0.9 million for the six months ended June 30, 2012 and 2011, respectively.


## us-gaap:SegmentReportingDisclosureTextBlock

[0001193125-12-334164:notes:104]
11. SEGMENT INFORMATION

[0001193125-12-334164:notes:105]
We operate in two reportable segments: (1) the Carrier Networks Division and (2) the Enterprise Networks Division. We
   evaluate the performance of our segments based on gross profit; therefore, selling, general and administrative expense, research and development expenses, interest income and dividend income, interest expense, net realized investment gain/loss,
   other income/expense and provision for taxes are reported on an entity-wide basis only. There are no inter-segment revenues.

[0001193125-12-334164:notes:106]
The following
   table presents information about the reported sales and gross profit of our reportable segments for the three and six months ended June 30, 2012 and 2011. Asset information by reportable segment is not reported, since we do not produce such
   information internally.

[0001193125-12-334164:notes:107]
|  |  | Three Months Ended |  |
|  |  | June 30, 2012 |  |  | June 30, 2011 |  |
| (In thousands) |  | Sales |  |  | Gross Profit |  |  | Sales |  |  | Gross Profit |  |
| Carrier Networks |  | $ | 152,707 |  |  | $ | 78,738 |  |  | $ | 150,492 |  |  | $ | 87,465 |  |
| Enterprise Networks |  |  | 31,291 |  |  |  | 16,463 |  |  |  | 33,735 |  |  |  | 19,362 |  |
| Total |  | $ | 183,998 |  |  | $ | 95,201 |  |  | $ | 184,227 |  |  | $ | 106,827 |  |
|  |  | Six Months Ended |  |
|  |  | June 30, 2012 |  |  | June 30, 2011 |  |
| (In thousands) |  | Sales |  |  | Gross Profit |  |  | Sales |  |  | Gross Profit |  |
| Carrier Networks |  | $ | 249,361 |  |  | $ | 131,621 |  |  | $ | 282,852 |  |  | $ | 166,963 |  |
| Enterprise Networks |  |  | 69,372 |  |  |  | 37,667 |  |  |  | 66,897 |  |  |  | 38,659 |  |
| Total |  | $ | 318,733 |  |  | $ | 169,288 |  |  | $ | 349,749 |  |  | $ | 205,622 |  |

[0001193125-12-334164:notes:108]
[same as prior period, unchanged from 0001193125-12-220696:notes:92]

[0001193125-12-334164:notes:109]
Our three major product categories are Carrier Systems, Business Networking and Loop Access.

[0001193125-12-334164:notes:110]
Carrier Systems products are used by communications service providers to provide data, voice and video services to consumers
   and enterprises. The Carrier Systems category includes our broadband access products comprised of Total Access®
   5000 multi-service access and aggregation platform products, Total Access 1100/1200 Series Fiber-To-The-Node (FTTN) products, hiX 5600 Series Multi-Service Access Node (MSAN), Ultra Broadband Ethernet (UBE) and Digital Subscriber Line Access
   Multiplexer (DSLAM) products. Our broadband access products are used by service providers around the world to deliver high-speed Internet access, Plain Old Telephone Service (POTS), Voice over Internet Protocol (VoIP), IP Television (IPTV), and/or
   Ethernet services from the central office or remote terminal locations to customer premises. The Carrier Systems category also includes our optical products. These products consist of optical multiplexers and transceivers including those used in our
   Optical Networking Edge (ONE) products, NetVanta 8000 series products, and our family of OPTI products. Optical products are used to deliver higher bandwidth services, aggregate large numbers of low bandwidth services, or transport wavelength
   services across a fiber optic infrastructure. Total Access 1500 products, 303 concentrator products, M13 multiplexer products, and a number of mobile backhaul products are also included in the Carrier Systems product category.

[0001193125-12-334164:notes:111]
Business Networking products provide access to telecommunication services, facilitating the delivery of converged services and Unified
   Communications to the small and mid-sized enterprises (SME) market. The Business Networking category includes Internetworking products and Integrated Access Devices (IADs). Internetworking products consist of our Total Access IP Business Gateways,
   Optical Network Terminals (ONTs), Virtual Wireless LAN products and NetVanta product lines. NetVanta products include multi-service routers, managed Ethernet switches, IP Private Branch Exchange (PBX) products, IP phone products, Unified
   Communications solutions, Unified Threat Management (UTM) solutions, and Carrier Ethernet Network Terminating Equipment (NTE). IAD products consist of our Total Access 600 Series and the Total Access 850.

[0001193125-12-334164:notes:112]
Loop Access products are used by carrier and enterprise customers for access to copper-based telecommunications networks. The Loop Access category
   includes products such as: Digital Data Service (DDS) and Integrated Services Digital Network (Total Reach) products, High bit-rate Digital Subscriber Line (HDSL) products including Total Access 3000 HDSL and Time Division Multiplexed-Symmetrical
   HDSL (TDM-SHDSL) products, T1/E1/T3, Channel Service Units/Data Service Units, and TRACER fixed wireless products.

[0001193125-12-334164:notes:113]
The table below presents
   sales information by product category for the three and six months ended June 30, 2012 and 2011.

[0001193125-12-334164:notes:114]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |
| Carrier Systems |  | $ | 126,755 |  |  | $ | 112,289 |  |  | $ | 198,013 |  |  | $ | 199,039 |  |
| Business Networking |  |  | 36,590 |  |  |  | 35,699 |  |  |  | 79,732 |  |  |  | 72,062 |  |
| Loop Access |  |  | 20,653 |  |  |  | 36,239 |  |  |  | 40,988 |  |  |  | 78,648 |  |
| Total |  | $ | 183,998 |  |  | $ | 184,227 |  |  | $ | 318,733 |  |  | $ | 349,749 |  |

[0001193125-12-334164:notes:115]
In addition, we identify subcategories of product revenues, which we divide into our core products and legacy products. Our core
   products consist of Broadband Access and Optical products (included in Carrier Systems) and Internetworking products (included in Business Networking) and our legacy products include HDSL products (included in Loop Access) and other products not
   included in the aforementioned core products.

[0001193125-12-334164:notes:116]
Subcategory revenues included in the
   above are as follows:

[0001193125-12-334164:notes:117]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
|  |  | June 30, |  |  | June 30, |  |
| (In thousands) |  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |
| Core Products |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| Broadband Access (included in Carrier Systems) |  | $ | 106,042 |  |  | $ | 77,062 |  |  | $ | 155,524 |  |  | $ | 128,844 |  |
| Optical (included in Carrier Systems) |  |  | 14,003 |  |  |  | 22,008 |  |  |  | 28,258 |  |  |  | 42,924 |  |
| Internetworking (NetVanta & Multi-service Access Gateways) (included in Business Networking) |  |  | 34,935 |  |  |  | 33,029 |  |  |  | 75,909 |  |  |  | 65,912 |  |
| Subtotal |  |  | 154,980 |  |  |  | 132,099 |  |  |  | 259,691 |  |  |  | 237,680 |  |
| Legacy Products |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |  |
| HDSL (does not include T1) (included in Loop Access) |  |  | 19,465 |  |  |  | 34,049 |  |  |  | 38,424 |  |  |  | 74,994 |  |
| Other products (excluding HDSL) |  |  | 9,553 |  |  |  | 18,079 |  |  |  | 20,618 |  |  |  | 37,075 |  |
| Subtotal |  |  | 29,018 |  |  |  | 52,128 |  |  |  | 59,042 |  |  |  | 112,069 |  |
| Total |  | $ | 183,998 |  |  | $ | 184,227 |  |  | $ | 318,733 |  |  | $ | 349,749 |  |

[0001193125-12-334164:notes:118]
[same as prior period, unchanged from 0001193125-12-220696:notes:100]

[0001193125-12-334164:notes:119]
The table below presents sales information by geographic area for the three and six months ended June 30, 2012 and 2011. International sales correlate to shipments with a non-U.S. destination.

[0001193125-12-334164:notes:120]
|  |  | Three Months Ended |  |  | Six Months Ended |  |
| (In thousands) |  | June 30, |  |  | June 30, |  |
|  | 2012 |  |  | 2011 |  |  | 2012 |  |  | 2011 |  |
| United States |  | $ | 130,389 |  |  | $ | 160,804 |  |  | $ | 246,832 |  |  | $ | 313,917 |  |
| International |  |  | 53,609 |  |  |  | 23,423 |  |  |  | 71,901 |  |  |  | 35,832 |  |
| Total |  | $ | 183,998 |  |  | $ | 184,227 |  |  | $ | 318,733 |  |  | $ | 349,749 |  |


## us-gaap:ProductWarrantyDisclosureTextBlock

[0001193125-12-334164:notes:121]
12. LIABILITY FOR WARRANTY RETURNS

[0001193125-12-334164:notes:122]
Our products generally include warranties of 90 days to ten years for product defects. We accrue for warranty returns at the time
   revenue is recognized based on our estimate of the cost to repair or replace the defective products. We engage in extensive product quality programs and processes, including actively monitoring and evaluating the quality of our component suppliers.
   Our products continue to become more complex in both size and functionality as many of our product offerings migrate from line card applications to systems products. The increasing complexity of our products will cause warranty incidences, when they
   arise, to be more costly. Our estimates regarding future warranty obligations may change due to product failure rates, material usage, and other rework costs incurred in correcting a product failure. In addition, from time to time, specific warranty
   accruals may be recorded if unforeseen problems arise. Should our actual experience relative to these factors be worse than our estimates, we will be required to record additional warranty expense. Alternatively, if we provide for more reserves than
   we require, we will reverse a portion of such provisions in future periods. The liability for warranty obligations totaled $7.2 million at June 30, 2012 and $4.1 million at December 31, 2011. These liabilities are included in accrued
   expenses in the accompanying Consolidated Balance Sheets.

[0001193125-12-334164:notes:123]
A summary of warranty expense and write-off activity for the six months ended
   June 30, 2012 and 2011 is as follows:

[0001193125-12-334164:notes:124]
| Six Months Ended June 30, (In thousands) |  | 2012 |  |  | 2011 |  |
| Balance at beginning of period |  | $ | 4,118 |  |  | $ | 3,304 |  |
| Plus: Amounts charged to cost and expenses |  |  | 3,313 |  |  |  | 1,525 |  |
| Amounts assumed on acquisition |  |  | 1,932 |  |  |  | — |  |
| Less: Deductions |  |  | (2,137 | ) |  |  | (1,183 | ) |
| Balance at end of period |  | $ | 7,226 |  |  | $ | 3,646 |  |


## us-gaap:RelatedPartyTransactionsDisclosureTextBlock

[0001193125-12-334164:notes:125]
13. RELATED PARTY TRANSACTIONS

[0001193125-12-334164:notes:126]
We employ the law firm of our director emeritus for legal services. All bills for services rendered by this firm are reviewed and
   approved by our Chief Financial Officer. We believe that the fees for such services are comparable to those charged by other firms for services rendered to us. For the three and six month periods ended June 30, 2012 and 2011, we incurred fees
   of $10 thousand per month for these legal services.


## us-gaap:CommitmentsAndContingenciesDisclosureTextBlock

[0001193125-12-334164:notes:127]
14. COMMITMENTS AND CONTINGENCIES

[0001193125-12-334164:notes:128]
In the ordinary course of business, we may be subject to various legal proceedings and claims, including employment disputes, patent
   claims, disputes over contract agreements and other commercial disputes. In some cases, claimants seek damages or other relief, such as royalty payments related to patents, which, if granted, could require significant expenditures. Although the
   outcome of any claim or litigation can never be certain, it is our opinion that the outcome of all contingencies of which we are currently aware will not materially affect our business, operations, financial condition or cash flows.

[0001193125-12-334164:notes:129]
We have committed to invest up to an aggregate of $7.9 million in two private equity funds, and we have contributed $8.4 million as of June 30,
   2012, of which $7.7 million has been applied to these commitments.


## us-gaap:SubsequentEventsTextBlock

[0001193125-12-334164:notes:130]
15. SUBSEQUENT EVENTS

[0001193125-12-334164:notes:131]
On July 10, 2012, we announced that our Board of Directors declared a quarterly cash dividend of $0.09 per common share to be paid
   to stockholders of record at the close of business on July 26, 2012. The payment date will be August 9, 2012. The quarterly dividend payment will be approximately $5.7 million. In July 2003, our Board of Directors elected to begin
   declaring quarterly dividends on our common stock considering the tax treatment of dividends and adequate levels of Company liquidity.

[0001193125-12-334164:notes:132]
During
   the third quarter of 2012 and as of August 3, 2012, we repurchased 0.5 million shares of our common stock through open market purchases at an average cost of $21.08 per share. We have the authority to purchase an additional
   4.9 million shares of our common stock under plans approved by the Board of Directors on April 14, 2008 and October 11, 2011.
