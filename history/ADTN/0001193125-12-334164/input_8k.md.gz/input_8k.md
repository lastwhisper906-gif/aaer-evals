# ADTN 8-K — 0001157523-12-003592 filed 2012-07-11

## item codes, every 8-K on or before 2012-08-03

- 2012-07-11 0001157523-12-003592 — 2.02, 9.01
- 2012-05-10 0001193125-12-225669 — 5.07
- 2012-05-10 0001193125-12-225639 — 8.01, 9.01
- 2012-04-11 0001157523-12-001772 — 2.02, 9.01
- 2012-03-15 0001193125-12-116494 — 2.02, 9.01
- 2012-01-18 0001157523-12-000174 — 2.02, 9.01
- 2011-12-12 0001193125-11-337271 — 7.01, 9.01
- 2011-10-13 0000950123-11-089785 — 5.03, 9.01
- 2011-10-12 0001157523-11-005682 — 2.02, 9.01
- 2011-07-13 0001157523-11-003986 — 2.02, 9.01
- 2011-05-09 0000950123-11-047191 — 5.02, 5.07, 9.01
- 2011-04-13 0001157523-11-002001 — 2.02, 9.01
- 2011-01-19 0001157523-11-000232 — 2.02, 9.01
- 2010-11-09 0000950123-10-103195 — 5.02, 9.01
- 2010-10-13 0001157523-10-005798 — 2.02, 9.01
- 2010-07-14 0001157523-10-004011 — 2.02, 9.01
- 2010-05-28 0000950123-10-053947 — 5.07
- 2010-04-14 0001157523-10-002022 — 2.02, 9.01
- 2010-01-20 0001157523-10-000200 — 2.02, 9.01
- 2009-10-28 0000950123-09-053984 — 8.01
- 2009-10-14 0001157523-09-006877 — 2.02, 9.01
- 2009-07-15 0001157523-09-004878 — 2.02, 9.01
- 2009-04-15 0001157523-09-002687 — 2.02, 9.01
- 2009-01-21 0001157523-09-000340 — 2.02, 9.01
- 2008-11-12 0001193125-08-233181 — 5.02, 9.01
- 2008-10-14 0001157523-08-007999 — 2.02, 9.01
- 2008-07-15 0001157523-08-005504 — 2.02, 9.01
- 2008-04-15 0001157523-08-002896 — 2.02, 9.01
- 2008-01-22 0001157523-08-000408 — 2.02, 9.01
- 2007-10-16 0001193125-07-219356 — 5.03, 9.01
- 2007-10-16 0001157523-07-009850 — 2.02, 9.01
- 2007-07-17 0001157523-07-006912 — 2.02, 9.01
- 2007-04-17 0001157523-07-003630 — 2.02, 9.01
- 2007-04-03 0001179022-07-000068 — 5.02
- 2007-03-28 0001179022-07-000064 — 5.02
- 2007-02-23 0001193125-07-038337 — 5.02
- 2007-02-23 0001193125-07-038335 — 5.02
- 2007-01-30 0001193125-07-015912 — 5.02, 9.01
- 2007-01-26 0001193125-07-014234 — 5.02
- 2007-01-23 0001157523-07-000494 — 2.02, 9.01 — amendment of 0001157523-07-000481
- 2007-01-23 0001157523-07-000481 — 2.02, 9.01
- 2006-10-17 0001157523-06-009945 — 2.02, 9.01
- 2006-07-18 0001157523-06-006929 — 2.02, 9.01
- 2006-06-08 0001193125-06-126486 — 1.01, 9.01
- 2006-05-10 0001193125-06-107316 — 1.01, 9.01
- 2006-04-18 0001157523-06-003699 — 2.02, 9.01
- 2006-02-03 0001179022-06-000014 — 1.01
- 2006-01-27 0001157523-06-000754 — 5.02, 9.01
- 2006-01-24 0001157523-06-000551 — 2.02, 9.01
- 2005-10-18 0001157523-05-008826 — 2.02, 9.01
- 2005-07-19 0001193125-05-143958 — 1.01, 5.02, 9.01
- 2005-07-19 0001193125-05-143957 — 2.02, 9.01
- 2005-05-20 0001193125-05-112019 — 1.01, 9.01
- 2005-04-19 0001157523-05-003418 — 2.02, 9.01
- 2005-01-25 0001193125-05-010721 — 2.02, 9.01
- 2004-10-12 0001193125-04-169652 — 2.02, 9.01
- 2004-07-13 0001193125-04-116820 — 12, 7
- 2004-04-14 0001193125-04-061547 — 12, 7
- 2004-01-21 0001193125-04-006366 — 12, 7
- 2003-10-14 0001193125-03-061018 — 12, 5, 7
- 2003-07-15 0001193125-03-019292 — 7, 9
- 2003-04-15 0000931763-03-000968 — 7, 9
- 1996-09-12 0000931763-96-000667 — 5, 7

## late-filing notifications on or before 2012-08-03

- none on or before 2012-08-03

## item 2.02 — earnings release, exhibit 99.1

[0001157523-12-003592:8k_2_02:1]
EX-99.1
2
a50337208_ex991.htm
EXHIBIT 99.1

[0001157523-12-003592:8k_2_02:2]
Exhibit 99.1

[0001157523-12-003592:8k_2_02:3]
ADTRAN,
      Inc. Reports Results for the Second Quarter 2012 and Declares Quarterly
      Cash Dividend

[0001157523-12-003592:8k_2_02:4]
HUNTSVILLE, Ala.--(BUSINESS WIRE)--July 10, 2012--ADTRAN, Inc.
      (NASDAQ:ADTN) reported results for the second quarter 2012. For the
      quarter, sales were $183,998,000 compared to $184,227,000 for the second
      quarter of 2011. Net income was $21,070,000 for the quarter compared to
      $36,943,000 for the second quarter of 2011. Earnings per share, assuming
      dilution, were $0.33 for the quarter compared to $0.56 for the second
      quarter of 2011. Non-GAAP earnings per share for the quarter were $0.38
      compared to $0.59 for the second quarter of 2011. Non-GAAP earnings per
      share exclude the effect of acquisition related expenses, amortizations
      and adjustments related to the acquisitions of the NSN Broadband Access
      business and Bluesocket, Inc. and stock compensation expense. The
      reconciliation between GAAP earnings per share, diluted, and non-GAAP
      earnings per share, diluted, is in the table provided.

[0001157523-12-003592:8k_2_02:5]
ADTRAN Chief Executive Officer Tom Stanton stated, “Our results for the
      second quarter reflect a tightening spending environment. Total
      quarterly revenues grew 37% sequentially, with organic revenues
      (excluding the recently acquired NSN BBA business) up 20%, representing
      a flat year over year performance. Our Broadband Access category grew
      38% (8% organic) over the same period last year. Our Internetworking
      category grew 6% over the same period last year. Total core products
      which include Broadband Access, Optical and Internetworking, grew 17%
      (flat organically) over the same period last year and now represent 84%
      of total revenues. Decreasing visibility leaves us cautious for the near
      term but we are confident that our strong customer alignment and
      increasing global footprint will deliver long term growth for the
      company.”

[0001157523-12-003592:8k_2_02:6]
The Company also announced that its Board of Directors declared a cash
      dividend for the second quarter of 2012. The quarterly cash dividend is
      $0.09 per common share to be paid to holders of record at the close of
      business on July 26, 2012. The ex-dividend date is July 24, 2012 and the
      payment date is August 9, 2012.

[0001157523-12-003592:8k_2_02:7]
The Company confirmed that its second quarter conference call will be
      held Wednesday, July 11, 2012 at 9:30 a.m. Central Time. This conference
      call will be web cast live through StreetEvents.com. To listen, simply
      visit the Investor Relations site at http://www.adtran.com or http://streetevents.com
      approximately 10 minutes prior to the start of the call and click on the
      conference call link provided.

[0001157523-12-003592:8k_2_02:8]
An online replay of the conference call will be available for seven days
      at http://streetevents.com. In addition, an online replay of the
      conference call, as well as the text of the Company’s earnings release,
      will be available on the Investor Relations site at http://www.adtran.com
      for at least 12 months following the call.

[0001157523-12-003592:8k_2_02:9]
ADTRAN, Inc. is a leading global provider of networking and
      communications equipment, with a portfolio of more than 1,700 solutions.
      ADTRAN’s products enable voice, data, video, and Internet communications
      across a variety of network infrastructures. ADTRAN solutions are
      currently in use by service providers, private enterprises, government
      organizations, and millions of individual users worldwide.

[0001157523-12-003592:8k_2_02:10]
For more information, contact the company at 800 9ADTRAN (800 923-8726)
      or via email at info@adtran.com. On the Web, visit www.adtran.com.

[0001157523-12-003592:8k_2_02:11]
To supplement our consolidated financial statements presented on a GAAP
      basis, ADTRAN, Inc. uses non-GAAP measures of net income per share,
      which are adjusted to exclude certain costs and expenses we believe
      appropriate to enhance an overall understanding of our past financial
      performance. The presentation of this additional information is not
      meant to be considered in isolation or as a substitute for diluted net
      income per share prepared in accordance with generally accepted
      accounting principles in the United States.

[0001157523-12-003592:8k_2_02:12]
This press release contains forward-looking statements which reflect
      management’s best judgment based on factors currently known. However,
      these statements involve risks and uncertainties, including the
      successful development and market acceptance of new products, the degree
      of competition in the market for such products, the product and channel
      mix, component costs, manufacturing efficiencies, and other risks
      detailed in our annual report on Form 10-K for the year ended December
      31, 2011, and Form 10-Q for the quarter ended March 31, 2012. These
      risks and uncertainties could cause actual results to differ materially
      from those in the forward-looking statements included in this press
      release.

[0001157523-12-003592:8k_2_02:13]
| Condensed Consolidated Balance Sheet |
| (Unaudited) |
| (In thousands) |
|  |  | June 30,2012 |  | December 31,2011 |
| Assets |  |  |  |  |
| Cash and cash equivalents |  | $ | 36,968 |  | $ | 42,979 |
| Short-term investments |  |  | 169,449 |  |  | 159,347 |
| Accounts receivable, net |  |  | 118,511 |  |  | 76,130 |
| Other receivables |  |  | 8,124 |  |  | 9,743 |
| Inventory |  |  | 103,776 |  |  | 87,800 |
| Prepaid expenses |  |  | 4,670 |  |  | 3,119 |
| Deferred tax assets, net |  |  | 12,803 |  |  | 12,125 |
| Total Current Assets |  |  | 454,301 |  |  | 391,243 |
| Property, plant and equipment, net |  |  | 81,981 |  |  | 75,295 |
| Deferred tax assets, net |  |  | 8,368 |  |  | 8,345 |
| Goodwill |  |  | 3,492 |  |  | 3,492 |
| Other assets |  |  | 14,323 |  |  | 7,131 |
| Long-term investments |  |  | 348,424 |  |  | 332,008 |
| Total Assets |  | $ | 910,889 |  | $ | 817,514 |
| Liabilities and Stockholders' Equity |  |  |  |  |
| Accounts payable |  | $ | 46,978 |  | $ | 29,404 |
| Unearned revenue |  |  | 27,251 |  |  | 9,965 |
| Accrued expenses |  |  | 12,577 |  |  | 5,876 |
| Accrued wages and benefits |  |  | 15,709 |  |  | 13,518 |
| Income tax payable, net |  |  | 10,677 |  |  | 3,169 |
| Total Current Liabilities |  |  | 113,192 |  |  | 61,932 |
| Non-current unearned revenue |  |  | 23,009 |  |  | 4,874 |
| Other non-current liabilities |  |  | 14,908 |  |  | 12,077 |
| Bonds payable |  |  | 46,500 |  |  | 46,500 |
| Total Liabilities |  |  | 197,609 |  |  | 125,383 |
| Stockholders' Equity |  |  | 713,280 |  |  | 692,131 |
| Total Liabilities and Stockholders' Equity |  | $ | 910,889 |  | $ | 817,514 |

[0001157523-12-003592:8k_2_02:14]
| Consolidated Statements of Income |
| (Unaudited) |
| (In thousands, except per share data) |
|  |  |  | Three Months Ended |  | Six Months Ended |
|  |  |  | June 30, |  | June 30, |
|  |  |  | 2012 |  | 2011 |  | 2012 |  | 2011 |
| Sales |  | $ | 183,998 |  |  | $ | 184,227 |  |  | $ | 318,733 |  |  | $ | 349,749 |  |
| Cost of sales |  |  | 88,797 |  |  |  | 77,400 |  |  |  | 149,445 |  |  |  | 144,127 |  |
| Gross Profit |  |  | 95,201 |  |  |  | 106,827 |  |  |  | 169,288 |  |  |  | 205,622 |  |
| Selling, general and administrative expenses |  |  | 35,905 |  |  |  | 30,898 |  |  |  | 69,017 |  |  |  | 60,450 |  |
| Research and development expenses |  |  | 32,458 |  |  |  | 24,619 |  |  |  | 57,252 |  |  |  | 48,256 |  |
| Operating Income |  |  | 26,838 |  |  |  | 51,310 |  |  |  | 43,019 |  |  |  | 96,916 |  |
| Interest and dividend income |  |  | 1,926 |  |  |  | 2,003 |  |  |  | 3,787 |  |  |  | 3,792 |  |
| Interest expense |  |  | (581 | ) |  |  | (594 | ) |  |  | (1,168 | ) |  |  | (1,196 | ) |
| Net realized investment gain |  |  | 2,356 |  |  |  | 3,372 |  |  |  | 4,823 |  |  |  | 6,139 |  |
| Other expense, net |  |  | 492 |  |  |  | (117 | ) |  |  | 633 |  |  |  | (242 | ) |
| Gain on bargain purchase of a business |  |  | 1,753 |  |  |  | - |  |  |  | 1,753 |  |  |  | - |  |
| Income before provision for income taxes |  |  | 32,784 |  |  |  | 55,974 |  |  |  | 52,847 |  |  |  | 105,409 |  |
| Provision for income taxes |  |  | (11,714 | ) |  |  | (19,031 | ) |  |  | (18,816 | ) |  |  | (34,208 | ) |
| Net Income |  | $ | 21,070 |  |  | $ | 36,943 |  |  | $ | 34,031 |  |  | $ | 71,201 |  |
| Weighted average shares outstanding - basic |  |  | 63,619 |  |  |  | 64,690 |  |  |  | 63,720 |  |  |  | 64,441 |  |
| Weighted average shares outstanding - diluted(1) |  |  | 64,393 |  |  |  | 66,135 |  |  |  | 64,628 |  |  |  | 66,044 |  |
| Earnings per common share - basic |  | $ | 0.33 |  |  | $ | 0.57 |  |  | $ | 0.53 |  |  | $ | 1.10 |  |
| Earnings per common share - diluted(1) |  | $ | 0.33 |  |  | $ | 0.56 |  |  | $ | 0.53 |  |  | $ | 1.08 |  |
| (1) Assumes exercise of dilutive stock options calculated under the treasury stock method. |

[0001157523-12-003592:8k_2_02:15]
| Consolidated Statements of Comprehensive Income |
| (Unaudited) |
| (In thousands) |
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | June 30, |  | June 30, |
|  |  | 2012 |  | 2011 |  | 2012 |  | 2011 |
| Net Income |  | $ | 21,070 |  |  | $ | 36,943 |  |  | $ | 34,031 |  |  | $ | 71,201 |  |
| Other Comprehensive Income (Loss), net of tax: |  |  |  |  |  |  |  |  |
| Net change in unrealized gains (losses) on marketable securities |  |  | (5,054 | ) |  |  | (3,140 | ) |  |  | 1,701 |  |  |  | (5,791 | ) |
| Reclassification adjustments for amounts Included in net income |  |  | (181 | ) |  |  | (236 | ) |  |  | (179 | ) |  |  | (395 | ) |
| Foreign currency translation |  |  | (96 | ) |  |  | 369 |  |  |  | 58 |  |  |  | 456 |  |
| Other Comprehensive Income (Loss), net of tax |  |  | (5,331 | ) |  |  | (3,007 | ) |  |  | 1,580 |  |  |  | (5,730 | ) |
| Comprehensive Income, net of tax |  | $ | 15,739 |  |  | $ | 33,936 |  |  | $ | 35,611 |  |  | $ | 65,471 |  |

[0001157523-12-003592:8k_2_02:16]
| Consolidated Statements of Cash Flows |
| (Unaudited) |
| (In thousands) |
|  |  | Six Months Ended |
|  |  | June 30, |
|  |  | 2012 |  | 2011 |
| Cash flows from operating activities: |  |  |  |  |
| Net income |  | $ | 34,031 |  |  | $ | 71,201 |  |
| Adjustments to reconcile net income to net cash provided by operating activities: |  |  |  |  |
| Depreciation and amortization |  |  | 6,615 |  |  |  | 5,469 |  |
| Amortization of net premium on available-for-sale investments |  |  | 4,330 |  |  |  | 2,992 |  |
| Net realized gain on long-term investments |  |  | (4,823 | ) |  |  | (6,139 | ) |
| Net (gain) loss on disposal of property, plant and equipment |  |  | (204 | ) |  |  | 17 |  |
| Gain on bargain purchase of a business |  |  | (1,753 | ) |  |  | - |  |
| Stock-based compensation expense |  |  | 4,432 |  |  |  | 4,165 |  |
| Deferred income taxes |  |  | (2,427 | ) |  |  | (192 | ) |
| Tax benefit from stock option exercises |  |  | 1,701 |  |  |  | 10,318 |  |
| Excess tax benefits from stock-based compensation arrangements |  |  | (1,346 | ) |  |  | (9,180 | ) |
| Change in operating assets and liabilities: |  |  |  |  |
| Accounts receivable, net |  |  | (43,062 | ) |  |  | (12,373 | ) |
| Other receivables |  |  | 1,997 |  |  |  | (6,463 | ) |
| Income tax receivable, net |  |  | - |  |  |  | 1,936 |  |
| Inventory |  |  | 5,548 |  |  |  | (12,402 | ) |
| Prepaid expenses and other assets |  |  | (1,527 | ) |  |  | (176 | ) |
| Accounts payable |  |  | 12,877 |  |  |  | 14,703 |  |
| Accrued expenses and other liabilities |  |  | 13,099 |  |  |  | 1,870 |  |
| Income tax payable, net |  |  | 7,508 |  |  |  | - |  |
| Net cash provided by operating activities |  |  | 36,996 |  |  |  | 65,746 |  |
| Cash flows from investing activities: |  |  |  |  |
| Purchases of property, plant and equipment |  |  | (7,787 | ) |  |  | (6,287 | ) |
| Proceeds from disposals of property, plant and equipment |  |  | 266 |  |  |  | - |  |
| Proceeds from sales and maturities of available-for-sale investments |  |  | 138,307 |  |  |  | 237,459 |  |
| Purchases of available-for-sale investments |  |  | (161,849 | ) |  |  | (335,870 | ) |
| Acquisition of business |  |  | 7,496 |  |  |  | - |  |
| Net cash used in investing activities |  |  | (23,567 | ) |  |  | (104,698 | ) |
| Cash flows from financing activities: |  |  |  |  |
| Proceeds from stock option exercises |  |  | 4,328 |  |  |  | 33,022 |  |
| Purchases of treasury stock |  |  | (13,432 | ) |  |  | - |  |
| Dividend payments |  |  | (11,476 | ) |  |  | (11,596 | ) |
| Excess tax benefits from stock-based compensation arrangements |  |  | 1,346 |  |  |  | 9,180 |  |
| Net cash provided by (used in) financing activities |  |  | (19,234 | ) |  |  | 30,606 |  |
| Net decrease in cash and cash equivalents |  |  | (5,805 | ) |  |  | (8,346 | ) |
| Effect of exchange rate changes |  |  | (206 | ) |  |  | 456 |  |
| Cash and cash equivalents, beginning of period |  |  | 42,979 |  |  |  | 31,677 |  |
| Cash and cash equivalents, end of period |  | $ | 36,968 |  |  | $ | 23,787 |  |

[0001157523-12-003592:8k_2_02:17]
| Supplemental Information |
| Acquisition Related Expenses, Amortizations and Adjustments |
| (Unaudited) |
| (In thousands) |
| On August 4, 2011, we closed on the acquisition of Bluesocket, Inc. and on May 4, 2012, we closed on the acquisition of the Nokia Siemens Networks Broadband Access business (NSN BBA). Acquisition related expenses, amortizations and adjustments for the three and six months ended June 30, 2012 for both transactions are as follows: |
|  |  | Three Months Ended June 30, 2012 |  | Six Months Ended June 30, 2012 |
| Bluesocket, Inc. acquisition |  |  |  |  |
| Amortization of acquired intangible assets |  | $ | 267 |  |  | $ | 485 |  |
| Amortization of other purchase accounting adjustments |  |  | 111 |  |  |  | 377 |  |
| Subtotal |  |  | 378 |  |  |  | 862 |  |
| NSN BBA acquisition |  |  |  |  |
| Amortization of acquired intangible assets |  |  | 172 |  |  |  | 172 |  |
| Amortization of other purchase accounting adjustments |  |  | 1,052 |  |  |  | 1,052 |  |
| Acquisition related professional fees, travel and other expenses |  |  | 2,705 |  |  |  | 4,285 |  |
| Subtotal |  |  | 3,929 |  |  |  | 5,509 |  |
| Total acquisition related expenses, amortizations and adjustments |  |  | 4,307 |  |  |  | 6,371 |  |
| Tax effect |  |  | (1,361 | ) |  |  | (2,039 | ) |
| Total acquisition related expenses, amortizations and adjustments, net of tax |  | $ | 2,946 |  |  | $ | 4,332 |  |
| The acquisition related expenses, amortizations and adjustments above were recorded in the following Consolidated Statements of Income categories for the three and six months ended June 30, 2012: |
|  |  | Three Months Ended June 30, 2012 |  | Six Months Ended June 30, 2012 |
| Revenue (adjustments to deferred revenue recognized in the period) |  | $ | 508 |  |  | $ | 654 |  |
| Cost of goods sold |  |  | 669 |  |  |  | 806 |  |
| Subtotal |  |  | 1,177 |  |  |  | 1,460 |  |
| Selling, general and administrative expenses |  |  | 2,361 |  |  |  | 3,922 |  |
| Research and development expenses |  |  | 769 |  |  |  | 989 |  |
| Subtotal |  |  | 3,130 |  |  |  | 4,911 |  |
| Total acquisition related expenses, amortizations and adjustments |  |  | 4,307 |  |  |  | 6,371 |  |
| Tax effect |  |  | (1,361 | ) |  |  | (2,039 | ) |
| Total acquisition related expenses, amortizations and adjustments, net of tax |  | $ | 2,946 |  |  | $ | 4,332 |  |

[0001157523-12-003592:8k_2_02:18]
| Supplemental Information |
| Stock-based Compensation Expense |
| (Unaudited) |
| (In thousands) |
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | June 30, |  | June 30, |
|  |  | 2012 |  | 2011 |  | 2012 |  | 2011 |
| Stock-based compensation expense included in cost of sales |  | $ | 97 |  |  | $ | 89 |  |  | $ | 198 |  |  | $ | 180 |  |
| Selling, general and administrative expense |  |  | 1,047 |  |  |  | 999 |  |  |  | 2,098 |  |  |  | 2,006 |  |
| Research and development expense |  |  | 1,067 |  |  |  | 988 |  |  |  | 2,136 |  |  |  | 1,979 |  |
| Stock-based compensation expense included in operating expenses |  |  | 2,114 |  |  |  | 1,987 |  |  |  | 4,234 |  |  |  | 3,985 |  |
| Total stock-based compensation expense |  |  | 2,211 |  |  |  | 2,076 |  |  |  | 4,432 |  |  |  | 4,165 |  |
| Tax benefit for expense associated with non-qualified options |  |  | (302 | ) |  |  | (276 | ) |  |  | (603 | ) |  |  | (716 | ) |
| Total stock-based compensation expense, net of tax |  | $ | 1,909 |  |  | $ | 1,800 |  |  | $ | 3,829 |  |  | $ | 3,449 |  |

[0001157523-12-003592:8k_2_02:19]
| Reconciliation of GAAP net income per share, diluted, to |
| Non-GAAP net income per share, diluted |
| (Unaudited) |
|  |  | Three Months Ended |  | Six Months Ended |
|  |  | June 30, |  | June 30, |
|  |  | 2012 |  | 2011 |  | 2012 |  | 2011 |
| GAAP earnings per common share – diluted |  | $ | 0.33 |  |  | $ | 0.56 |  | $ | 0.53 |  |  | $ | 1.08 |
| Acquisition related expenses, amortizations and adjustments |  |  | 0.05 |  |  |  | - |  |  | 0.07 |  |  |  | - |
| Stock-based compensation expense |  |  | 0.03 |  |  |  | 0.03 |  |  | 0.06 |  |  |  | 0.05 |
| Bargain purchase gain – NSN BBA acquisition |  |  | (0.03 | ) |  |  | - |  |  | (0.03 | ) |  |  | - |
| Non-GAAP earnings per common share – diluted |  | $ | 0.38 |  |  | $ | 0.59 |  | $ | 0.63 |  |  | $ | 1.13 |

[0001157523-12-003592:8k_2_02:20]
CONTACT:
ADTRAN, Inc.
Jim Matthews, Senior Vice President/CFO,
      256-963-8775
or
Investor Services/Assistance:
Gayle Ellis,
      256-963-8220
